import { xchacha20poly1305 } from '@noble/ciphers/chacha';
import { x25519 } from '@noble/curves/ed25519';
import { secp256k1 } from '@noble/curves/secp256k1';
import { hkdf } from '@noble/hashes/hkdf';
import { sha256 } from '@noble/hashes/sha2';
import { bytesToHex, concatBytes, hexToBytes, randomBytes, utf8ToBytes } from '@noble/hashes/utils';
import {
  DkgError, dkgFinalize, dkgRound1, dkgRound2, dkgSessionId,
  type DkgParams, type DkgResult, type DkgRound1Package, type DkgShareMessage,
} from './dkg.js';
import { Point, bytesToScalar, pointToBytes, scalarToBytes, wipe, type PointT } from './frost.js';

/**
 * The DKG's transport: authenticated broadcast and encrypted point-to-point delivery, so the
 * protocol in `dkg.ts` can actually run between two machines.
 *
 * WHY THIS EXISTS. `dkg.ts` checks every commitment, proof, share and transcript, and its header
 * says plainly what it cannot do: "a library without networking" needs the caller to provide an
 * authenticated broadcast for round 1 and authenticated, encrypted channels for round 2. Until
 * this file, nobody provided them - the examples passed objects in process, so a browser and the
 * co-signer had no way to generate a key together. Everything here is about the CHANNEL; not one
 * line of the protocol moved, and `dkgRound1` / `dkgRound2` / `dkgFinalize` are unchanged and
 * still usable on their own.
 *
 * WHAT TRAVELS. Three rounds of `DkgWireMessage`, which is JSON of hex strings: put it in an HTTP
 * body, a WebSocket frame or a postMessage, unchanged.
 *
 *   round 1   broadcast   the party's Feldman commitments, its proof of possession, and a fresh
 *                         X25519 public key that round 2 will encrypt to
 *   round 2   to one peer the party's evaluation f_i(l) and its round-1 transcript hash, sealed
 *                         to that peer's X25519 key from round 1
 *   round 3   to one peer the group key and DKG transcript this party derived - the out-of-band
 *                         comparison `dkg.ts` asks for, done in band and signed
 *
 * WHAT IS SIGNED. Every message, by its sender's LONG-TERM key, over
 *
 *     SHA256( DST || version || round || sessionId || from || to || transcript || SHA256(payload) )
 *
 * The signature scheme is the caller's (`DkgAuth`): the co-signer signs with the ECDSA key its
 * accounts already name, a browser with a per-run key its passkey authorised, and tests with
 * `secp256k1Auth`. This layer only decides WHAT is signed, and refuses anything whose signature
 * does not verify under the key it holds for that party.
 *
 * WHAT THE TRANSCRIPT BINDS, and why each part is in it:
 *
 *     SHA256( DST || version || sessionId || n || for each party, ascending:
 *             id || len || long-term public key || len || its round-1 payload )
 *
 *   - the SESSION ID, which `dkg.ts` derives from the context, the threshold and the participant
 *     set: a message cannot be replayed into a run with different parameters;
 *   - every party's LONG-TERM PUBLIC KEY: a run is bound to WHO is in it, so a recorded message
 *     cannot be replayed into a later run where one identity was swapped;
 *   - every party's ROUND-1 PAYLOAD, in full: the commitments, the proof of possession AND the
 *     X25519 key round 2 encrypts to. So a party that shows different commitments to different
 *     peers - equivocation, which is what turns an honest DKG into two different group keys -
 *     gives them different transcripts, and round 2 aborts naming it. Binding the X25519 key here
 *     too means a peer cannot be steered onto an encryption key the others never saw.
 *
 * Every round-2 and round-3 message carries that hash and signs it, so neither side can be shown
 * a different transcript than the other without one of them stopping. The DKG's own transcript
 * (`DkgShareMessage.transcript`, over the round-1 packages alone) travels INSIDE the sealed
 * payload and is checked by `dkgFinalize`: two independent equivocation checks, one of which is
 * the protocol's own.
 *
 * WHAT IS ENCRYPTED. Only round 2, which is the only secret: f_i(l) is a share of the group
 * secret. The sender draws a fresh X25519 ephemeral, does an X25519 to the recipient's round-1
 * key, derives a one-message key with HKDF-SHA256 (salt: the session id; info: the domain, both
 * party ids, the transcript and both public keys) and seals with XChaCha20-Poly1305 under
 * associated data repeating the envelope. So the server never sees the device's share and the
 * device never sees the server's: the ciphertext is opened only by the key from round 1, and a
 * relay - or the HTTP service itself, if the two halves ever ran through one - carries bytes it
 * cannot read. The signature is over the CIPHERTEXT, so authentication does not depend on
 * decryption, and a tampered ciphertext is refused before any key is derived.
 *
 * WHAT IS REFUSED, always by aborting the session and naming the party at fault:
 *
 *   session-reused         a session id already used by this party in this process
 *   replayed               a message byte-identical to one already accepted
 *   duplicate              a second message from a party that already sent one this round
 *   missing                a party that sent nothing where the round needs everyone
 *   wrong-round            a round arriving out of order, or a session method called out of order
 *   wrong-session          a message from another run
 *   misrouted              a message addressed to another party
 *   unexpected-sender      a party that is not in this run, or this party's own id
 *   unauthenticated        a signature that does not verify under that party's long-term key
 *   malformed              a payload of the wrong length, an invalid point, a scalar out of range
 *   inconsistent-transcript  the sender saw a different round 1 than we did
 *   undecryptable          the sealed share does not open, or its tag fails
 *   protocol               `dkg.ts` itself rejected a proof, a share or a transcript
 *
 * A failed session is dead: every further call throws. That is `dkg.ts`'s rule - a failed DKG is
 * abandoned, never retried with the same polynomial - carried into the transport.
 *
 * UNAUDITED, like the rest of this package.
 */

/* ------------------------------------------------------------------ constants */

export const DKG_TRANSPORT_VERSION = 1;

const DST = 'FROST-secp256k1-SHA256-v1/dkg-transport/v1';
const DST_TRANSCRIPT = utf8ToBytes(`${DST}/transcript`);
const DST_AUTH = utf8ToBytes(`${DST}/auth`);
const DST_KDF = utf8ToBytes(`${DST}/share-key`);
const DST_AAD = utf8ToBytes(`${DST}/share-aad`);

/** X25519 public key, XChaCha20-Poly1305 nonce, and the sealed 64-byte plaintext with its tag. */
const X25519_BYTES = 32;
const NONCE_BYTES = 24;
const SEALED_BYTES = 32 + 32 + 16;
const ROUND2_BYTES = X25519_BYTES + NONCE_BYTES + SEALED_BYTES;
const ROUND3_BYTES = 33 + 32;
const ZERO_TRANSCRIPT = '0'.repeat(64);

/* ------------------------------------------------------------------ types */

export type DkgWireRound = 1 | 2 | 3;

/**
 * One message on the wire. Hex without `0x`, as `dkg.ts` writes its session ids; JSON-safe, and
 * nothing in it is secret except the round-2 payload, which is sealed.
 */
export interface DkgWireMessage {
  readonly v: number;
  readonly session: string;
  readonly round: DkgWireRound;
  readonly from: number;
  /** The recipient, or 0 for a broadcast. */
  readonly to: number;
  /** The sender's transport transcript hash; 32 zero bytes in round 1, where none exists yet. */
  readonly transcript: string;
  readonly payload: string;
  readonly signature: string;
}

/**
 * The long-term signing key of each party, as this layer uses it. `sign` is this party's; `verify`
 * must know every other party's public key and return false for anything else - a `verify` that
 * trusts the message's own `from` field authenticates nothing.
 */
export interface DkgAuth {
  sign(digest: Uint8Array): Uint8Array | Promise<Uint8Array>;
  verify(party: number, digest: Uint8Array, signature: Uint8Array): boolean | Promise<boolean>;
}

export interface DkgSessionOptions {
  /** This party's identifier, one of `params.participants`. */
  readonly party: number;
  readonly params: DkgParams;
  /**
   * Every party's long-term public key, this party's included, as the bytes both ends agree on:
   * a compressed secp256k1 key, an Ethereum address, a certificate hash - this layer only binds
   * them into the transcript, and `auth.verify` is what interprets them.
   */
  readonly identities: ReadonlyMap<number, Uint8Array>;
  readonly auth: DkgAuth;
}

export type DkgTransportCode =
  | 'session-reused' | 'replayed' | 'duplicate' | 'missing' | 'wrong-round' | 'wrong-session'
  | 'misrouted' | 'unexpected-sender' | 'unauthenticated' | 'malformed' | 'inconsistent-transcript'
  | 'undecryptable' | 'protocol' | 'invalid-parameters' | 'aborted';

/** An abort. `party` is the participant at fault, or undefined when the fault is this party's own. */
export class DkgTransportError extends Error {
  override readonly name = 'DkgTransportError';

  constructor(readonly code: DkgTransportCode, readonly party: number | undefined, message: string,
    readonly cause?: unknown) {
    super(party === undefined ? `DKG transport: ${message}` : `DKG transport: participant ${party}: ${message}`);
  }
}

export type DkgStage = 'new' | 'round1' | 'round2' | 'finished' | 'confirmed' | 'failed';

/* ------------------------------------------------------------------ encoding helpers */

const u8 = (n: number) => Uint8Array.of(n & 0xff);

function u16(n: number): Uint8Array {
  const out = new Uint8Array(2);
  new DataView(out.buffer).setUint16(0, n, false);
  return out;
}

function u32(n: number): Uint8Array {
  const out = new Uint8Array(4);
  new DataView(out.buffer).setUint32(0, n, false);
  return out;
}

const equalBytes = (a: Uint8Array, b: Uint8Array) => a.length === b.length && a.every((v, i) => v === b[i]);

function hex(value: unknown, bytes: number | undefined, party: number | undefined, what: string): Uint8Array {
  if (typeof value !== 'string' || !/^[0-9a-f]*$/.test(value) || value.length % 2 !== 0) {
    throw new DkgTransportError('malformed', party, `${what} is not lower-case hex`);
  }
  if (bytes !== undefined && value.length !== bytes * 2) {
    throw new DkgTransportError('malformed', party, `${what} must be ${bytes} bytes`);
  }
  return hexToBytes(value);
}

/**
 * The digest every message of a run is signed over, exactly as `DkgSession` computes it. Exported because
 * "what is signed" should be checkable without reading the class - a caller writing its own transport, or a
 * test building a hostile message, needs the same function the honest path uses.
 */
export function dkgAuthDigest(o: {
  session: string; round: number; from: number; to: number; transcript: string; payload: Uint8Array;
}): Uint8Array {
  return sha256(concatBytes(
    DST_AUTH, u8(DKG_TRANSPORT_VERSION), u8(o.round), hexToBytes(o.session),
    u32(o.from), u32(o.to), hexToBytes(o.transcript), sha256(o.payload),
  ));
}

/* ------------------------------------------------------------------ single-use session ids */

/**
 * Session ids already opened by this process, as `sessionId:party`. A DKG session runs once: the
 * same id twice would mean two polynomials committed under one transcript, and a peer could be
 * handed evaluations of both. A service that must survive a restart keeps its own record - the
 * co-signer refuses a second DKG for an account that already has a share - and this catches the
 * mistake inside one process, where the round state that matters lives anyway.
 *
 * Bounded, because a long-running service would otherwise grow one entry per run for ever. The
 * oldest are dropped; a session id from before that is refused by the service's own record, not
 * by this set.
 */
const opened = new Set<string>();
const MAX_REMEMBERED_SESSIONS = 100_000;

/* ------------------------------------------------------------------ the session */

interface Round1Local {
  readonly payload: Uint8Array;
  readonly pkg: DkgRound1Package;
  readonly x25519Public: Uint8Array;
}

export class DkgSession {
  readonly party: number;
  readonly sessionId: string;
  private readonly params: DkgParams;
  private readonly participants: readonly number[];
  private readonly identities: ReadonlyMap<number, Uint8Array>;
  private readonly auth: DkgAuth;
  private readonly sessionBytes: Uint8Array;
  /** Round-1 payloads by party, ours included: what the transcript is computed over. */
  private readonly round1 = new Map<number, Round1Local>();
  private readonly accepted = new Set<string>();
  private x25519Secret?: Uint8Array;
  private state: DkgStage = 'new';
  private r1State?: ReturnType<typeof dkgRound1>['state'];
  private r2State?: ReturnType<typeof dkgRound2>['state'];
  private transportTranscript?: string;
  private outcome?: DkgResult;

  private constructor(o: DkgSessionOptions, sessionId: string) {
    this.party = o.party;
    this.params = o.params;
    this.participants = [...o.params.participants].sort((a, b) => a - b);
    this.identities = o.identities;
    this.auth = o.auth;
    this.sessionId = sessionId;
    this.sessionBytes = hexToBytes(sessionId);
  }

  /**
   * Open a session for one run. Validates the parameters through `dkgSessionId`, requires a
   * long-term key for every participant, and refuses a session id this process already opened
   * for this party.
   */
  static open(o: DkgSessionOptions): DkgSession {
    const sessionId = dkgSessionId(o.params);
    if (!o.params.participants.includes(o.party)) {
      throw new DkgTransportError('invalid-parameters', undefined, `${o.party} is not among the participants`);
    }
    for (const id of o.params.participants) {
      const key = o.identities.get(id);
      if (!(key instanceof Uint8Array) || key.length === 0 || key.length > 0xffff) {
        throw new DkgTransportError('invalid-parameters', id, 'has no long-term public key for this run: '
          + 'an authenticated broadcast needs every party\'s key, known before the run starts');
      }
    }
    const handle = `${sessionId}:${o.party}`;
    if (opened.has(handle)) {
      throw new DkgTransportError('session-reused', undefined, `session ${sessionId} was already opened by `
        + `participant ${o.party} in this process: a DKG session runs once - start a new run with a new context`);
    }
    opened.add(handle);
    while (opened.size > MAX_REMEMBERED_SESSIONS) opened.delete(opened.values().next().value as string);
    return new DkgSession(o, sessionId);
  }

  get stage(): DkgStage {
    return this.state;
  }

  /** The transport transcript, once round 1 is complete on this side. Compare it out of band too. */
  get transcript(): string | undefined {
    return this.transportTranscript;
  }

  /** This party's key material, once `finish` succeeded. */
  get result(): DkgResult | undefined {
    return this.outcome;
  }

  /* ---------------------------------------------------------------- round 1 */

  /** Round 1: this party's signed broadcast. Send it to every other participant. */
  async broadcast(): Promise<DkgWireMessage> {
    this.expect('new', 'round 1');
    try {
      const { state, broadcast } = dkgRound1(this.party, this.params);
      this.r1State = state;
      this.x25519Secret = x25519.utils.randomSecretKey();
      const x25519Public = x25519.getPublicKey(this.x25519Secret);
      const payload = concatBytes(
        x25519Public,
        ...broadcast.commitments.map(pointToBytes),
        pointToBytes(broadcast.proof.R),
        scalarToBytes(broadcast.proof.mu),
      );
      this.round1.set(this.party, { payload, pkg: broadcast, x25519Public });
      this.state = 'round1';
      return await this.seal(1, 0, ZERO_TRANSCRIPT, payload);
    } catch (e) {
      throw this.fail(e);
    }
  }

  /* ---------------------------------------------------------------- round 2 */

  /**
   * Round 2: verify every other party's broadcast, compute the transcript, and seal this party's
   * evaluation to each peer. One message per other participant, each signed and encrypted to that
   * peer alone.
   */
  async round2(received: readonly DkgWireMessage[]): Promise<DkgWireMessage[]> {
    this.expect('round1', 'round 2');
    try {
      const packages: DkgRound1Package[] = [];
      for (const msg of received) {
        const from = await this.accept(msg, 1, 0);
        const { pkg, x25519Public, payload } = this.parseRound1(from, hex(msg.payload, undefined, from, 'payload'));
        this.round1.set(from, { payload, pkg, x25519Public });
        packages.push(pkg);
      }
      for (const id of this.participants) {
        if (!this.round1.has(id)) {
          throw new DkgTransportError('missing', id, 'sent no round-1 broadcast: the transcript cannot be '
            + 'computed, and a DKG that continues without one party\'s commitments is not this protocol');
        }
      }
      this.transportTranscript = this.computeTranscript();

      // dkg.ts checks every proof of possession here and aborts naming each party at fault.
      const { state, messages } = dkgRound2(this.r1State!, packages);
      this.r2State = state;
      const out: DkgWireMessage[] = [];
      for (const message of messages) {
        const to = this.round1.get(message.to)!;
        out.push(await this.seal(2, message.to, this.transportTranscript,
          this.sealShare(message, to.x25519Public)));
      }
      this.state = 'round2';
      return out;
    } catch (e) {
      throw this.fail(e);
    }
  }

  /* ---------------------------------------------------------------- finish */

  /**
   * Open every peer's sealed share, finalize, and produce this party's signed confirmation of the
   * group key and the DKG transcript. `dkgFinalize` checks each share against its sender's
   * commitments and each sender's view of round 1, and names whoever is at fault.
   */
  async finish(received: readonly DkgWireMessage[]): Promise<{ result: DkgResult; confirmation: DkgWireMessage }> {
    this.expect('round2', 'finish');
    try {
      const shares: DkgShareMessage[] = [];
      for (const msg of received) {
        const from = await this.accept(msg, 2, this.party);
        shares.push(this.openShare(from, hex(msg.payload, ROUND2_BYTES, from, 'payload')));
      }
      const result = dkgFinalize(this.r2State!, shares);
      this.outcome = result;
      // Every share is open: the X25519 secret has nothing left to decrypt (I-15).
      wipe(this.x25519Secret);
      this.x25519Secret = undefined;
      const payload = concatBytes(pointToBytes(result.publicKeys.groupPublicKey), hexToBytes(result.publicKeys.transcript));
      const confirmation = await this.seal(3, this.otherParty(), this.transportTranscript!, payload);
      this.state = 'finished';
      return { result, confirmation };
    } catch (e) {
      throw this.fail(e);
    }
  }

  /**
   * Check every other party's confirmation against what this party derived. The group key is
   * public, so this proves nothing about their shares - it proves they finished THE SAME RUN, which
   * is the check `dkg.ts` tells the caller to do out of band before funds go to the key.
   */
  async confirm(received: readonly DkgWireMessage[]): Promise<void> {
    this.expect('finished', 'confirm');
    try {
      const expected = concatBytes(
        pointToBytes(this.outcome!.publicKeys.groupPublicKey),
        hexToBytes(this.outcome!.publicKeys.transcript),
      );
      const seen = new Set<number>();
      for (const msg of received) {
        const from = await this.accept(msg, 3, this.party);
        seen.add(from);
        const payload = hex(msg.payload, ROUND3_BYTES, from, 'payload');
        if (!equalBytes(payload, expected)) {
          throw new DkgTransportError('inconsistent-transcript', from,
            'finished with a different group key or DKG transcript: the run did not agree, and the key must not be used');
        }
      }
      for (const id of this.participants) {
        if (id !== this.party && !seen.has(id)) {
          throw new DkgTransportError('missing', id, 'sent no confirmation of the group key it derived');
        }
      }
      this.state = 'confirmed';
    } catch (e) {
      throw this.fail(e);
    }
  }

  /* ---------------------------------------------------------------- envelope */

  private expect(stage: DkgStage, what: string): void {
    if (this.state === 'failed') {
      throw new DkgTransportError('aborted', undefined, `this session aborted; ${what} cannot run - start a new run with a new context`);
    }
    if (this.state !== stage) {
      throw new DkgTransportError('wrong-round', undefined, `${what} runs after ${stage}, and this session is at ${this.state}`);
    }
  }

  private fail(e: unknown): unknown {
    this.state = 'failed';
    if (e instanceof DkgTransportError) return e;
    if (e instanceof DkgError) {
      // Keep dkg.ts's own verdict, and name the first participant it blamed.
      return new DkgTransportError('protocol', e.faults[0]?.participant, `${e.code}: ${e.message}`, e);
    }
    return new DkgTransportError('malformed', undefined, e instanceof Error ? e.message : String(e), e);
  }

  private authDigest(round: number, from: number, to: number, transcript: string, payload: Uint8Array): Uint8Array {
    return dkgAuthDigest({ session: this.sessionId, round, from, to, transcript, payload });
  }

  private async seal(round: DkgWireRound, to: number, transcript: string, payload: Uint8Array): Promise<DkgWireMessage> {
    const signature = await this.auth.sign(this.authDigest(round, this.party, to, transcript, payload));
    if (!(signature instanceof Uint8Array) || signature.length === 0) {
      throw new DkgTransportError('unauthenticated', undefined, 'this party\'s own signer returned no signature');
    }
    return Object.freeze({
      v: DKG_TRANSPORT_VERSION, session: this.sessionId, round, from: this.party, to,
      transcript, payload: bytesToHex(payload), signature: bytesToHex(signature),
    });
  }

  /**
   * The envelope's checks, in the order that leaks least: who it claims to be from, then the
   * signature under that party's long-term key, then everything the signature covers.
   */
  private async accept(msg: DkgWireMessage, round: DkgWireRound, to: number): Promise<number> {
    if (!msg || typeof msg !== 'object') throw new DkgTransportError('malformed', undefined, 'a message must be an object');
    const from = msg.from;
    if (!Number.isSafeInteger(from) || !this.participants.includes(from) || from === this.party) {
      throw new DkgTransportError('unexpected-sender', Number.isSafeInteger(from) ? from : undefined,
        from === this.party ? 'a message claiming to be our own' : 'not a participant of this run');
    }
    if (msg.v !== DKG_TRANSPORT_VERSION) throw new DkgTransportError('malformed', from, `transport version ${String(msg.v)} is not ${DKG_TRANSPORT_VERSION}`);
    if (!Number.isSafeInteger(msg.to) || msg.to < 0) throw new DkgTransportError('malformed', from, 'the recipient must be a participant identifier, or 0 for a broadcast');
    if (msg.round !== round) throw new DkgTransportError('wrong-round', from, `round ${String(msg.round)} arrived where round ${round} was expected`);
    const payload = hex(msg.payload, undefined, from, 'payload');
    const signature = hex(msg.signature, undefined, from, 'signature');
    const transcript = typeof msg.transcript === 'string' && /^[0-9a-f]{64}$/.test(msg.transcript)
      ? msg.transcript : undefined;
    if (transcript === undefined) throw new DkgTransportError('malformed', from, 'transcript must be 32 bytes of hex');
    if (typeof msg.session !== 'string') throw new DkgTransportError('malformed', from, 'session must be hex');

    // The signature is over OUR session id, so a message from another run fails here rather than
    // on a field comparison: there is nothing to compare until it is known to be authentic.
    let ok = false;
    try {
      ok = await this.auth.verify(from, this.authDigest(round, from, msg.to, transcript, payload), signature);
    } catch {
      ok = false;
    }
    if (!ok) {
      throw new DkgTransportError('unauthenticated', from, 'its signature does not verify under the long-term key '
        + 'this run holds for it, over this session, round, recipient, transcript and payload');
    }
    if (msg.session !== this.sessionId) throw new DkgTransportError('wrong-session', from, 'a message from another run');
    if (msg.to !== to) {
      throw new DkgTransportError('misrouted', from, to === 0 ? `a broadcast addressed to ${String(msg.to)}` : `addressed to ${String(msg.to)}, not to us`);
    }
    const fingerprint = `${round}:${from}:${msg.signature}`;
    if (this.accepted.has(fingerprint)) {
      throw new DkgTransportError('replayed', from, `this round-${round} message was already accepted`);
    }
    for (const seen of this.accepted) {
      if (seen.startsWith(`${round}:${from}:`)) {
        throw new DkgTransportError('duplicate', from, `a second round-${round} message`);
      }
    }
    if (round === 1 && this.round1.has(from)) throw new DkgTransportError('duplicate', from, 'a second round-1 broadcast');
    if (round > 1 && transcript !== this.transportTranscript) {
      throw new DkgTransportError('inconsistent-transcript', from,
        'signed a different round-1 transcript than we computed: it, or another participant, showed '
        + 'different round-1 broadcasts to different peers');
    }
    this.accepted.add(fingerprint);
    return from;
  }

  /* ---------------------------------------------------------------- payloads */

  private parseRound1(from: number, payload: Uint8Array): Round1Local {
    const t = this.params.threshold;
    if (payload.length !== X25519_BYTES + 33 * (t + 1) + 32) {
      throw new DkgTransportError('malformed', from,
        `a round-1 payload for a ${t}-of-${this.participants.length} run is ${X25519_BYTES + 33 * (t + 1) + 32} bytes, got ${payload.length}`);
    }
    const x25519Public = payload.slice(0, X25519_BYTES);
    let at = X25519_BYTES;
    const points: PointT[] = [];
    try {
      for (let i = 0; i < t + 1; i++) {
        points.push(Point.fromBytes(payload.slice(at, at + 33)));
        at += 33;
      }
    } catch {
      throw new DkgTransportError('malformed', from, 'a commitment or proof point is not a valid compressed secp256k1 point');
    }
    const mu = bytesToScalar(payload.slice(at, at + 32));
    const pkg: DkgRound1Package = Object.freeze({
      from, session: this.sessionId, commitments: Object.freeze(points.slice(0, t)),
      proof: Object.freeze({ R: points[t]!, mu }),
    });
    return { payload, pkg, x25519Public };
  }

  private computeTranscript(): string {
    const parts: Uint8Array[] = [DST_TRANSCRIPT, u8(DKG_TRANSPORT_VERSION), this.sessionBytes, u32(this.participants.length)];
    for (const id of this.participants) {
      const identity = this.identities.get(id)!;
      const { payload } = this.round1.get(id)!;
      parts.push(u32(id), u16(identity.length), identity, u16(payload.length), payload);
    }
    return bytesToHex(sha256(concatBytes(...parts)));
  }

  /** A fresh X25519 ephemeral, one derived key, one message. */
  private sealShare(message: DkgShareMessage, recipientPublic: Uint8Array): Uint8Array {
    const ephemeralSecret = x25519.utils.randomSecretKey();
    const ephemeralPublic = x25519.getPublicKey(ephemeralSecret);
    const nonce = randomBytes(NONCE_BYTES);
    const key = this.shareKey(ephemeralSecret, recipientPublic, ephemeralPublic, recipientPublic, message.from, message.to);
    const aad = this.shareAad(message.from, message.to, ephemeralPublic, nonce);
    const shareBytes = scalarToBytes(message.share);
    const plaintext = concatBytes(shareBytes, hexToBytes(message.transcript));
    try {
      return concatBytes(ephemeralPublic, nonce, xchacha20poly1305(key, nonce, aad).encrypt(plaintext));
    } finally {
      wipe(shareBytes, plaintext, key, ephemeralSecret); // I-15
    }
  }

  private openShare(from: number, payload: Uint8Array): DkgShareMessage {
    const ephemeralPublic = payload.slice(0, X25519_BYTES);
    const nonce = payload.slice(X25519_BYTES, X25519_BYTES + NONCE_BYTES);
    const sealed = payload.slice(X25519_BYTES + NONCE_BYTES);
    const ownPublic = this.round1.get(this.party)!.x25519Public;
    let plaintext: Uint8Array;
    let key: Uint8Array | undefined;
    try {
      key = this.shareKey(this.x25519Secret!, ephemeralPublic, ephemeralPublic, ownPublic, from, this.party);
      plaintext = xchacha20poly1305(key, nonce, this.shareAad(from, this.party, ephemeralPublic, nonce)).decrypt(sealed);
    } catch {
      throw new DkgTransportError('undecryptable', from, 'its sealed share does not open under the X25519 key we '
        + 'published in round 1: the ciphertext, its tag or its ephemeral key is not the one it signed for us');
    } finally {
      wipe(key);
    }
    const shareBytes = plaintext.slice(0, 32);
    const share = bytesToScalar(shareBytes);
    const transcript = bytesToHex(plaintext.slice(32));
    wipe(shareBytes, plaintext); // I-15
    return Object.freeze({ from, to: this.party, session: this.sessionId, transcript, share });
  }

  private shareKey(secret: Uint8Array, peer: Uint8Array, ephemeralPublic: Uint8Array, recipientPublic: Uint8Array,
    from: number, to: number): Uint8Array {
    let shared: Uint8Array;
    try {
      shared = x25519.getSharedSecret(secret, peer);
    } catch {
      throw new DkgTransportError('undecryptable', from, 'its X25519 public key has no usable shared secret');
    }
    try {
      return hkdf(sha256, shared, this.sessionBytes, concatBytes(
        DST_KDF, u32(from), u32(to), hexToBytes(this.transportTranscript!), ephemeralPublic, recipientPublic,
      ), 32);
    } finally {
      wipe(shared); // I-15
    }
  }

  private shareAad(from: number, to: number, ephemeralPublic: Uint8Array, nonce: Uint8Array): Uint8Array {
    return concatBytes(
      DST_AAD, u8(DKG_TRANSPORT_VERSION), this.sessionBytes, u32(from), u32(to),
      hexToBytes(this.transportTranscript!), ephemeralPublic, nonce,
    );
  }

  private otherParty(): number {
    // Confirmations are point-to-point; with more than two parties each peer gets its own copy.
    return this.participants.find((id) => id !== this.party)!;
  }

  /** With more than two parties, `finish` returns one confirmation; this addresses it to each peer. */
  async confirmationFor(to: number): Promise<DkgWireMessage> {
    if (this.state !== 'finished') {
      throw new DkgTransportError('wrong-round', undefined, `a confirmation exists only after finish, and this session is at ${this.state}`);
    }
    if (!this.participants.includes(to) || to === this.party) {
      throw new DkgTransportError('unexpected-sender', to, 'is not another participant of this run');
    }
    const payload = concatBytes(
      pointToBytes(this.outcome!.publicKeys.groupPublicKey),
      hexToBytes(this.outcome!.publicKeys.transcript),
    );
    return this.seal(3, to, this.transportTranscript!, payload);
  }
}

/* ------------------------------------------------------------------ a default signature scheme */

/**
 * `DkgAuth` over plain secp256k1 ECDSA (compact, 64 bytes, over the digest as given): the default
 * for a party that has no key of its own already - a test, a CLI, or a browser that mints a
 * per-run key and has its passkey authorise it.
 *
 * `publicKeys` must come from outside the protocol. That is the whole of authentication here:
 * this layer refuses any message that does not verify under the key it was GIVEN for that party,
 * and nothing a message says can change which key that is.
 */
export function secp256k1Auth(o: {
  secretKey: Uint8Array;
  publicKeys: ReadonlyMap<number, Uint8Array>;
}): DkgAuth {
  return {
    sign: (digest) => secp256k1.sign(digest, o.secretKey, { prehash: false }).toBytes('compact'),
    verify: (party, digest, signature) => {
      const key = o.publicKeys.get(party);
      if (!key || signature.length !== 64) return false;
      try {
        return secp256k1.verify(signature, digest, key, { prehash: false });
      } catch {
        return false;
      }
    },
  };
}

/** A fresh secp256k1 key pair for `secp256k1Auth`. The public key is compressed, 33 bytes. */
export function generateDkgKey(): { secretKey: Uint8Array; publicKey: Uint8Array } {
  const secretKey = secp256k1.utils.randomSecretKey();
  return { secretKey, publicKey: secp256k1.getPublicKey(secretKey, true) };
}
