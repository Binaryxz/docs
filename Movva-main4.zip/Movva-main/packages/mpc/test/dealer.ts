import { randomBytes } from '@noble/hashes/utils';
import { Point, bytesToScalar, publicShareOf, type AggregateCheck, type KeyShare, type PointT, type Scalar } from '../src/frost.js';

/**
 * TEST FIXTURE ONLY: trusted-dealer key generation.
 *
 * A dealer draws the group secret on one machine and Shamir-splits it, so that machine holds
 * the whole key while this runs. That is exactly the property the DKG in `src/dkg.ts` exists to
 * remove, which is why this is no longer in `src/`, is not exported by `@mova/mpc`, and must not
 * be imported by anything that holds funds. `test/dkg.test.ts` asserts the package exports no
 * dealer.
 *
 * It stays for the signing tests, which want many keys quickly and sometimes a KNOWN secret
 * (to check Lagrange interpolation recovers it) - a DKG, by design, cannot give them one.
 */

const Fn = Point.Fn;

export interface KeyGenResult {
  readonly shares: readonly KeyShare[];
  readonly groupPublicKey: PointT;
}

export function trustedDealerKeygen(threshold: number, total: number): KeyGenResult {
  return split(threshold, total, Fn.create(bytesToScalar(randomBytes(32))));
}

/** Split a caller-chosen secret. A key made this way is exactly as secret as the literal. */
export function trustedDealerKeygenFromSecretForTesting(
  threshold: number,
  total: number,
  secret: Scalar,
): KeyGenResult {
  return split(threshold, total, secret);
}

function split(threshold: number, total: number, secret: Scalar): KeyGenResult {
  if (threshold < 1 || threshold > total) {
    throw new Error(`invalid threshold ${threshold} of ${total}`);
  }
  if (Fn.create(secret) === 0n) throw new Error('the group secret must not be zero');
  const coeffs: Scalar[] = [Fn.create(secret)];
  for (let i = 1; i < threshold; i++) {
    coeffs.push(Fn.create(bytesToScalar(randomBytes(32))));
  }
  const groupPublicKey = Point.BASE.multiply(Fn.create(secret));
  const shares: KeyShare[] = [];
  for (let id = 1; id <= total; id++) {
    let y = 0n;
    for (let k = coeffs.length - 1; k >= 0; k--) {
      y = Fn.create(y * BigInt(id) + coeffs[k]!);
    }
    shares.push({ id, share: y, groupPublicKey });
  }
  return { shares, groupPublicKey };
}

/** What `aggregate` checks against (I-10): the threshold, and every share's public counterpart. */
export function checkOf(shares: readonly KeyShare[], threshold: number): AggregateCheck {
  return { threshold, verificationShares: new Map(shares.map((s) => [s.id, publicShareOf(s)])) };
}
