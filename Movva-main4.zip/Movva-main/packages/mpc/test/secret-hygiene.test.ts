import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { nonceGenerate, randomScalar, wipe } from '../src/index.js';

const src = (f: string) => readFileSync(join(__dirname, '../src', f), 'utf8');

/** v2.0 I-15: what JavaScript allows - byte forms of secrets wiped, secret multiplications constant-time. */
describe('secret hygiene', () => {
  it('multiplies secret scalars only with the constant-time multiply', () => {
    for (const f of ['frost.ts', 'dkg.ts', 'dkg-transport.ts']) expect(src(f)).not.toMatch(/\.multiplyUnsafe\(/);
  });

  it('wipes what it is given, and nonce generation is unchanged by wiping its own buffers', () => {
    const a = new Uint8Array([1, 2, 3]);
    const b = new Uint8Array([4]);
    wipe(a, undefined, b);
    expect([...a, ...b]).toEqual([0, 0, 0, 0]);
    const share = randomScalar();
    const random = new Uint8Array(32).fill(7);
    expect(nonceGenerate(share, random)).toBe(nonceGenerate(share, random));
    expect(random).toEqual(new Uint8Array(32).fill(7));
  });

  it('wipes the byte forms where secrets pass through: the DKG\'s sealed shares and X25519 key, the passkey-sealed share', () => {
    expect(src('dkg-transport.ts')).toMatch(/wipe\(shareBytes, plaintext, key, ephemeralSecret\)/);
    expect(src('dkg-transport.ts')).toMatch(/wipe\(this\.x25519Secret\)/);
    expect(readFileSync(join(__dirname, '../../smart-account/src/sealed-share.ts'), 'utf8')).toMatch(/plaintext\.fill\(0\)/);
  });
});
