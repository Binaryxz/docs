import { describe, expect, it } from 'vitest';
import { bytesToHex, hexToBytes } from '@noble/hashes/utils';
import { Point, bindingFactorInput, bindingFactors, nonceGenerate, scalarToBytes, type Commitment } from '../src/frost.js';

/**
 * RFC 9591 Appendix E.5, FROST(secp256k1, SHA-256), verbatim (v2.0 I-09). Nonce generation (H3), the binding factor
 * input (H4, H5 and the commitment list encoding) and the binding factors (H1) match the RFC byte for byte. The
 * signature shares do not: the challenge H2 is the on-chain verifier's (src/frost.ts, H2).
 */
const V = {
  groupPublicKey: '02f37c34b66ced1fb51c34a90bdae006901f10625cc06c4f64663b0eae87d87b4f',
  message: '74657374',
  p1: {
    share: '08f89ffe80ac94dcb920c26f3f46140bfc7f95b493f8310f5fc1ea2b01f4254c',
    hidingRandomness: '7ea5ed09af19f6ff21040c07ec2d2adbd35b759da5a401d4c99dd26b82391cb2',
    bindingRandomness: '47acab018f116020c10cb9b9abdc7ac10aae1b48ca6e36dc15acb6ec9be5cdc5',
    hiding: '841d3a6450d7580b4da83c8e618414d0f024391f2aeb511d7579224420aa81f0',
    binding: '8d2624f532af631377f33cf44b5ac5f849067cae2eacb88680a31e77c79b5a80',
    hidingCommitment: '03c699af97d26bb4d3f05232ec5e1938c12f1e6ae97643c8f8f11c9820303f1904',
    bindingCommitment: '02fa2aaccd51b948c9dc1a325d77226e98a5a3fe65fe9ba213761a60123040a45e',
    bindingFactorInput: '02f37c34b66ced1fb51c34a90bdae006901f10625cc06c4f64663b0eae87d87b4fff9b5210ffbb3c07a73a7c8935be4a8c62cf015f6cf7ade6efac09a6513540fc3f5a816aaebc2114a811a415d7a55db7c5cbc1cf27183e79dd9def941b5d48010000000000000000000000000000000000000000000000000000000000000001',
    bindingFactor: '3e08fe561e075c653cbfd46908a10e7637c70c74f0a77d5fd45d1a750c739ec6',
  },
  p3: {
    share: '00e95d59dd0d46b0e303e500b62b7ccb0e555d49f5b849f5e748c071da8c0dbc',
    hidingRandomness: 'e6cc56ccbd0502b3f6f831d91e2ebd01c4de0479e0191b66895a4ffd9b68d544',
    bindingRandomness: '7203d55eb82a5ca0d7d83674541ab55f6e76f1b85391d2c13706a89a064fd5b9',
    hiding: '2b19b13f193f4ce83a399362a90cdc1e0ddcd83e57089a7af0bdca71d47869b2',
    binding: '7a443bde83dc63ef52dda354005225ba0e553243402a4705ce28ffaafe0f5b98',
    hidingCommitment: '03077507ba327fc074d2793955ef3410ee3f03b82b4cdc2370f71d865beb926ef6',
    bindingCommitment: '02ad53031ddfbbacfc5fbda3d3b0c2445c8e3e99cbc4ca2db2aa283fa68525b135',
    bindingFactorInput: '02f37c34b66ced1fb51c34a90bdae006901f10625cc06c4f64663b0eae87d87b4fff9b5210ffbb3c07a73a7c8935be4a8c62cf015f6cf7ade6efac09a6513540fc3f5a816aaebc2114a811a415d7a55db7c5cbc1cf27183e79dd9def941b5d48010000000000000000000000000000000000000000000000000000000000000003',
    bindingFactor: '93f79041bb3fd266105be251adaeb5fd7f8b104fb554a4ba9a0becea48ddbfd7',
  },
} as const;

const scalar = (h: string) => BigInt(`0x${h}`);
const hex = (s: bigint) => bytesToHex(scalarToBytes(s));

describe('RFC 9591 FROST(secp256k1, SHA-256) test vectors (I-09)', () => {
  it('nonce_generate is H3(random || share): the RFC\'s hiding and binding nonces and their commitments', () => {
    for (const p of [V.p1, V.p3]) {
      const hiding = nonceGenerate(scalar(p.share), hexToBytes(p.hidingRandomness));
      const binding = nonceGenerate(scalar(p.share), hexToBytes(p.bindingRandomness));
      expect(hex(hiding)).toBe(p.hiding);
      expect(hex(binding)).toBe(p.binding);
      expect(bytesToHex(Point.BASE.multiply(hiding).toBytes(true))).toBe(p.hidingCommitment);
      expect(bytesToHex(Point.BASE.multiply(binding).toBytes(true))).toBe(p.bindingCommitment);
    }
  });

  it('the binding factor input and the binding factors (H1, H4, H5) are the RFC\'s', () => {
    const pk = Point.fromHex(V.groupPublicKey);
    const list: Commitment[] = [
      { id: 1, hiding: Point.fromHex(V.p1.hidingCommitment), binding: Point.fromHex(V.p1.bindingCommitment) },
      { id: 3, hiding: Point.fromHex(V.p3.hidingCommitment), binding: Point.fromHex(V.p3.bindingCommitment) },
    ];
    const m = hexToBytes(V.message);
    expect(bytesToHex(bindingFactorInput(list, m, pk, 1))).toBe(V.p1.bindingFactorInput);
    expect(bytesToHex(bindingFactorInput(list, m, pk, 3))).toBe(V.p3.bindingFactorInput);
    const f = bindingFactors(list, m, pk);
    expect(hex(f.get(1)!)).toBe(V.p1.bindingFactor);
    expect(hex(f.get(3)!)).toBe(V.p3.bindingFactor);
  });
});
