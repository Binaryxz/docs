import { describe, expect, it } from 'vitest';
import { bytesToHex, hexToBytes } from '@noble/hashes/utils';
import { secp256k1 } from '@noble/curves/secp256k1';
import { sha256 } from '@noble/hashes/sha2';
import { dkgContext } from '../src/dkg.js';
import {
  DkgSession, DkgTransportError, dkgAuthDigest, generateDkgKey, secp256k1Auth,
  type DkgWireMessage,
} from '../src/dkg-transport.js';
import { aggregate, commit, sign, verify, type KeyShare, publicShareOf } from '../src/frost.js';

/**
 * The DKG over a transport: a fake one here, HTTP in packages/cosigner.
 *
 * Every refusal in the module's header gets a test, because the whole point of the layer is what it REFUSES:
 * a run that quietly continues after a bad signature, a replay or an equivocation is worse than one that
 * stops, and the two halves would end up with different keys or with a key the attacker chose.
 */

interface Party {
  id: number;
  secretKey: Uint8Array;
  publicKey: Uint8Array;
  session: DkgSession;
}

function open(ids: number[], threshold: number, label: string): Map<number, Party> {
  const keys = new Map(ids.map((id) => [id, generateDkgKey()]));
  const identities = new Map([...keys].map(([id, k]) => [id, k.publicKey]));
  const params = { context: dkgContext(label), threshold, participants: ids };
  return new Map(ids.map((id) => [id, {
    id, ...keys.get(id)!,
    session: DkgSession.open({
      party: id, params, identities,
      auth: secp256k1Auth({ secretKey: keys.get(id)!.secretKey, publicKeys: identities }),
    }),
  }]));
}

/** One complete run over a transport that only moves objects around. */
async function run(parties: Map<number, Party>): Promise<Map<number, KeyShare>> {
  const round1: DkgWireMessage[] = [];
  for (const p of parties.values()) round1.push(await p.session.broadcast());
  const round2: DkgWireMessage[] = [];
  for (const p of parties.values()) round2.push(...await p.session.round2(round1.filter((m) => m.from !== p.id)));
  const confirmations: DkgWireMessage[] = [];
  const shares = new Map<number, KeyShare>();
  for (const p of parties.values()) {
    const { result } = await p.session.finish(round2.filter((m) => m.to === p.id));
    shares.set(p.id, result.keyShare);
    for (const other of parties.keys()) if (other !== p.id) confirmations.push(await p.session.confirmationFor(other));
  }
  for (const p of parties.values()) await p.session.confirm(confirmations.filter((m) => m.to === p.id));
  return shares;
}

function frostSign(signers: KeyShare[], digest: Uint8Array) {
  const rounds = signers.map((s) => ({ share: s, ...commit(s) }));
  const commitments = rounds.map((r) => r.commitment);
  return aggregate(commitments, rounds.map((r) => sign(r.share, r.nonces, commitments, digest)), digest, signers[0]!.groupPublicKey, { threshold: signers.length, verificationShares: new Map(signers.map((s) => [s.id, publicShareOf(s)])) });
}

/** Rewrite a message and sign it again with the sender's own key: a party that is dishonest, not a forger. */
function resign(msg: DkgWireMessage, secretKey: Uint8Array, over: Partial<DkgWireMessage> = {}): DkgWireMessage {
  const next = { ...msg, ...over };
  const digest = dkgAuthDigest({
    session: next.session, round: next.round, from: next.from, to: next.to,
    transcript: next.transcript, payload: hexToBytes(next.payload),
  });
  return { ...next, signature: bytesToHex(secp256k1.sign(digest, secretKey, { prehash: false }).toBytes('compact')) };
}

async function refuses(p: Promise<unknown>, code: string, party?: number): Promise<DkgTransportError> {
  try {
    await p;
  } catch (e) {
    if (!(e instanceof DkgTransportError)) throw e;
    expect(`${e.code}${party === undefined ? '' : `/${e.party}`}`).toBe(`${code}${party === undefined ? '' : `/${party}`}`);
    return e;
  }
  throw new Error(`expected ${code}, but it was accepted`);
}

describe('the DKG over a transport: a full run', () => {
  it('2-of-2: device and server agree on one group key, one transcript, and sign under it', async () => {
    const parties = open([1, 2], 2, 'transport-2of2');
    const shares = await run(parties);
    const [device, server] = [shares.get(1)!, shares.get(2)!];
    expect(device.groupPublicKey.equals(server.groupPublicKey)).toBe(true);
    expect(device.share).not.toBe(server.share);
    expect(parties.get(1)!.session.transcript).toBe(parties.get(2)!.session.transcript);
    expect([...parties.values()].map((p) => p.session.stage)).toEqual(['confirmed', 'confirmed']);
    const digest = sha256(new TextEncoder().encode('a SafeOp digest'));
    expect(verify(frostSign([device, server], digest), digest, device.groupPublicKey)).toBe(true);
    // One party alone does not.
    expect(verify(frostSign([device], digest), digest, device.groupPublicKey)).toBe(false);
  });

  it('2-of-3 with three parties: every pair signs under the key the run produced', async () => {
    const shares = await run(open([1, 2, 3], 2, 'transport-2of3'));
    const digest = sha256(new TextEncoder().encode('three parties'));
    for (const pair of [[1, 2], [1, 3], [2, 3]]) {
      const signers = pair.map((id) => shares.get(id)!);
      expect(verify(frostSign(signers, digest), digest, signers[0]!.groupPublicKey)).toBe(true);
    }
  });

  it('the round-2 payload carries no share in the clear', async () => {
    const parties = open([1, 2], 2, 'transport-opaque');
    const r1 = [await parties.get(1)!.session.broadcast(), await parties.get(2)!.session.broadcast()];
    const [toServer] = await parties.get(1)!.session.round2([r1[1]!]);
    const [toDevice] = await parties.get(2)!.session.round2([r1[0]!]);
    const { result } = await parties.get(1)!.session.finish([toDevice!]);
    // The device's own share, and the evaluation it sent the server, appear nowhere in what travelled.
    const wire = `${toServer!.payload}${toDevice!.payload}`;
    expect(wire).not.toContain(result.keyShare.share.toString(16));
    expect(toServer!.payload.length / 2).toBe(32 + 24 + 64 + 16);
  });
});

describe('the DKG over a transport: what it refuses', () => {
  it('a session id used twice by one party', () => {
    const params = { context: dkgContext('transport-reuse'), threshold: 2, participants: [1, 2] };
    const key = generateDkgKey();
    const identities = new Map([[1, key.publicKey], [2, generateDkgKey().publicKey]]);
    const auth = secp256k1Auth({ secretKey: key.secretKey, publicKeys: identities });
    DkgSession.open({ party: 1, params, identities, auth });
    expect(() => DkgSession.open({ party: 1, params, identities, auth })).toThrow(/session-reused|already opened/);
    // The OTHER party's session under the same id is a different handle, and is allowed: both halves of one
    // run open the same session id, once each.
    expect(DkgSession.open({ party: 2, params, identities, auth }).stage).toBe('new');
  });

  it('a party with no long-term key in the run', () => {
    const params = { context: dkgContext('transport-no-key'), threshold: 2, participants: [1, 2] };
    const key = generateDkgKey();
    const identities = new Map([[1, key.publicKey]]);
    expect(() => DkgSession.open({
      party: 1, params, identities, auth: secp256k1Auth({ secretKey: key.secretKey, publicKeys: identities }),
    })).toThrow(/long-term public key/);
  });

  it('a round-1 broadcast signed by the wrong key, and one whose payload was edited in flight', async () => {
    const parties = open([1, 2], 2, 'transport-forged');
    const [device, server] = [parties.get(1)!, parties.get(2)!];
    const honest = await device.session.broadcast();
    await server.session.broadcast();
    const stranger = generateDkgKey();
    await refuses(server.session.round2([resign(honest, stranger.secretKey)]), 'unauthenticated', 1);
    // The session is dead after an abort, exactly as a failed DKG is abandoned.
    await refuses(server.session.round2([honest]), 'aborted');

    const other = open([1, 2], 2, 'transport-tampered');
    const broadcast = await other.get(1)!.session.broadcast();
    await other.get(2)!.session.broadcast();
    const edited = { ...broadcast, payload: `00${broadcast.payload.slice(2)}` };
    await refuses(other.get(2)!.session.round2([edited]), 'unauthenticated', 1);
  });

  it('a party index repeated: two round-1 broadcasts from one party', async () => {
    const parties = open([1, 2, 3], 2, 'transport-repeat');
    const one = await parties.get(1)!.session.broadcast();
    await parties.get(2)!.session.broadcast();
    await parties.get(3)!.session.broadcast();
    await refuses(parties.get(3)!.session.round2([one, one]), 'replayed', 1);
    const again = open([1, 2, 3], 2, 'transport-repeat-2');
    const a = await again.get(1)!.session.broadcast();
    await again.get(2)!.session.broadcast();
    await again.get(3)!.session.broadcast();
    // A second, DIFFERENT broadcast from the same party: the sender equivocating about its own commitments.
    const twin = resign(a, again.get(1)!.secretKey, { payload: `${a.payload.slice(0, -2)}${a.payload.slice(-2) === '00' ? '01' : '00'}` });
    await refuses(again.get(3)!.session.round2([a, twin]), 'duplicate', 1);
  });

  it('a round out of order, in the messages and in the calls', async () => {
    const parties = open([1, 2], 2, 'transport-order');
    const [device, server] = [parties.get(1)!, parties.get(2)!];
    // finish before round 2.
    await refuses(device.session.finish([]), 'wrong-round');
    const fresh = open([1, 2], 2, 'transport-order-2');
    const d = fresh.get(1)!;
    const s = fresh.get(2)!;
    await refuses(d.session.round2([]), 'wrong-round');
    const r1d = await d.session.broadcast();
    const r1s = await s.session.broadcast();
    const [toServer] = await d.session.round2([r1s]);
    await s.session.round2([r1d]);
    // A round-2 message where round 1 was expected, and a round-1 message where round 2 was expected.
    const third = open([1, 2], 2, 'transport-order-3');
    await third.get(2)!.session.broadcast();
    await refuses(third.get(2)!.session.round2([toServer!]), 'wrong-round', 1);
    await refuses(s.session.finish([r1d]), 'wrong-round', 1);
    void device; void server;
  });

  it('a share replayed, and a share addressed to someone else', async () => {
    const parties = open([1, 2, 3], 2, 'transport-replay');
    const r1: DkgWireMessage[] = [];
    for (const p of parties.values()) r1.push(await p.session.broadcast());
    const r2 = new Map<number, DkgWireMessage[]>();
    for (const p of parties.values()) r2.set(p.id, await p.session.round2(r1.filter((m) => m.from !== p.id)));
    const forOne = [...r2.values()].flat().filter((m) => m.to === 1);
    await refuses(parties.get(1)!.session.finish([forOne[0]!, forOne[0]!]), 'replayed', forOne[0]!.from);
    // A share participant 2 addressed to participant 1, handed to participant 3.
    const misrouted = r2.get(2)!.find((m) => m.to === 1)!;
    await refuses(parties.get(3)!.session.finish([misrouted]), 'misrouted', 2);
  });

  it('a message from another run', async () => {
    const a = open([1, 2], 2, 'transport-other-run-a');
    const b = open([1, 2], 2, 'transport-other-run-b');
    await a.get(1)!.session.broadcast();
    const stray = await b.get(1)!.session.broadcast();
    await a.get(2)!.session.broadcast();
    // The signature is over the OTHER run's session id, so it fails to authenticate against this one.
    await refuses(a.get(2)!.session.round2([stray]), 'unauthenticated', 1);
    // ...and a message re-signed for this session id by its own key is still from a party whose key differs.
    const c = open([1, 2], 2, 'transport-other-run-c');
    await c.get(2)!.session.broadcast();
    await refuses(c.get(2)!.session.round2([resign(stray, b.get(1)!.secretKey, { session: c.get(1)!.session.sessionId })]), 'unauthenticated', 1);
  });

  it('a party that shows different round-1 broadcasts to different peers', async () => {
    const parties = open([1, 2, 3], 2, 'transport-equivocation');
    const honest = new Map<number, DkgWireMessage>();
    for (const p of parties.values()) honest.set(p.id, await p.session.broadcast());
    // Participant 1 shows participant 3 a broadcast with a different X25519 key: internally valid, and a
    // different transcript. Its own signature is over it, so it authenticates - and is caught in round 2.
    const twisted = resign(honest.get(1)!, parties.get(1)!.secretKey, {
      payload: `${'aa'.repeat(32)}${honest.get(1)!.payload.slice(64)}`,
    });
    const r2: DkgWireMessage[] = [];
    r2.push(...await parties.get(1)!.session.round2([honest.get(2)!, honest.get(3)!]));
    r2.push(...await parties.get(2)!.session.round2([honest.get(1)!, honest.get(3)!]));
    r2.push(...await parties.get(3)!.session.round2([twisted, honest.get(2)!]));
    // Participant 2 saw the honest broadcast; participant 3's transcript differs, and 2 stops, naming 3.
    await refuses(parties.get(2)!.session.finish(r2.filter((m) => m.to === 2)), 'inconsistent-transcript', 3);
  });

  it('a round-1 package with a proof of possession that does not hold: dkg.ts refuses, and the party is named', async () => {
    const parties = open([1, 2], 2, 'transport-bad-pop');
    const [device, server] = [parties.get(1)!, parties.get(2)!];
    const honest = await device.session.broadcast();
    await server.session.broadcast();
    // The last 32 bytes are mu, the proof's scalar. The sender signs the edited package itself.
    const bad = resign(honest, device.secretKey, { payload: `${honest.payload.slice(0, -64)}${'11'.repeat(32)}` });
    const e = await refuses(server.session.round2([bad]), 'protocol', 1);
    expect(e.message).toContain('bad-proof-of-possession');
  });

  it('a sealed share whose ciphertext was edited', async () => {
    const parties = open([1, 2], 2, 'transport-tamper-share');
    const [device, server] = [parties.get(1)!, parties.get(2)!];
    const r1d = await device.session.broadcast();
    const r1s = await server.session.broadcast();
    const [toServer] = await device.session.round2([r1s]);
    await server.session.round2([r1d]);
    const flipped = resign(toServer!, device.secretKey, {
      payload: `${toServer!.payload.slice(0, -2)}${toServer!.payload.slice(-2) === 'ff' ? '00' : 'ff'}`,
    });
    await refuses(server.session.finish([flipped]), 'undecryptable', 1);
  });

  it('a party that sends nothing at all', async () => {
    const parties = open([1, 2, 3], 2, 'transport-missing');
    const one = await parties.get(1)!.session.broadcast();
    await parties.get(2)!.session.broadcast();
    await parties.get(3)!.session.broadcast();
    await refuses(parties.get(3)!.session.round2([one]), 'missing', 2);
  });

  it('a confirmation for a different group key', async () => {
    const parties = open([1, 2], 2, 'transport-bad-confirm');
    const [device, server] = [parties.get(1)!, parties.get(2)!];
    const r1d = await device.session.broadcast();
    const r1s = await server.session.broadcast();
    const [toServer] = await device.session.round2([r1s]);
    const [toDevice] = await server.session.round2([r1d]);
    const deviceDone = await device.session.finish([toDevice!]);
    const serverDone = await server.session.finish([toServer!]);
    expect(deviceDone.result.publicKeys.groupPublicKey.equals(serverDone.result.publicKeys.groupPublicKey)).toBe(true);
    const lie = resign(serverDone.confirmation, server.secretKey, {
      payload: `${serverDone.confirmation.payload.slice(0, 2)}${'bb'.repeat(32)}${serverDone.confirmation.payload.slice(66)}`,
    });
    await refuses(device.session.confirm([lie]), 'inconsistent-transcript', 2);
  });
});
