import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import {
  commit, sign, aggregate,
  verify, verifyShare, publicShareOf, lagrangeCoefficient, bindingFactors, groupCommitment,
  challenge, nonceGenerate, Point, ORDER, scalarToBytes,
} from '../src/frost.js';
// Signing tests want many keys quickly, and one wants a KNOWN secret; a DKG gives neither, by
// design. The dealer is a test fixture now - see test/dealer.ts and test/dkg.test.ts.
import { checkOf, trustedDealerKeygen, trustedDealerKeygenFromSecretForTesting } from './dealer.js';

const msg = (s: string) => new TextEncoder().encode(s);

/** Run a full 2-of-2 signing session and return everything for inspection. */
function session(text: string, threshold = 2, total = 2, signers = [1, 2]) {
  const { shares, groupPublicKey } = trustedDealerKeygen(threshold, total);
  const chosen = signers.map((id) => shares.find((s) => s.id === id)!);
  const rounds = chosen.map((s) => ({ share: s, ...commit(s) }));
  const commitments = rounds.map((r) => r.commitment);
  const m = msg(text);
  const sigShares = rounds.map((r) => sign(r.share, r.nonces, commitments, m));
  const check = checkOf(shares, threshold);
  const signature = aggregate(commitments, sigShares, m, groupPublicKey, check);
  return { shares, chosen, rounds, commitments, sigShares, signature, groupPublicKey, m, check };
}

describe('FROST 2-of-2: it signs', () => {
  it('produces a signature both parties made and neither could alone', () => {
    const { signature, groupPublicKey, m } = session('pay R$ 250,00');
    expect(verify(signature, m, groupPublicKey)).toBe(true);
  });

  it('works for many random keys and messages', () => {
    for (let i = 0; i < 25; i++) {
      const { signature, groupPublicKey, m } = session(`msg-${i}-${Math.random()}`);
      expect(verify(signature, m, groupPublicKey)).toBe(true);
    }
  });

  it('rejects the signature against any other message', () => {
    const { signature, groupPublicKey } = session('withdraw 100');
    expect(verify(signature, msg('withdraw 10000'), groupPublicKey)).toBe(false);
  });

  it('rejects the signature against any other key', () => {
    const { signature, m } = session('hello');
    const other = trustedDealerKeygen(2, 2).groupPublicKey;
    expect(verify(signature, m, other)).toBe(false);
  });
});

describe('FROST: the secret is never assembled', () => {
  it('gives each party a share that is not the group key', () => {
    const { shares, groupPublicKey } = trustedDealerKeygen(2, 2);
    for (const s of shares) {
      // A share's public counterpart is not the group public key. If it were, that party
      // would hold the whole key and the scheme would be pointless.
      expect(publicShareOf(s).toHex(true)).not.toBe(groupPublicKey.toHex(true));
    }
  });

  it('never lets a signature share reveal the secret share', () => {
    // z_i is masked by two secret nonces, so the same share signing twice yields unrelated
    // scalars. If nonces were reused, the difference would leak the share by algebra.
    const a = session('same message');
    const b = session('same message');
    expect(a.sigShares[0]!.z).not.toBe(b.sigShares[0]!.z);
  });

  it('produces different nonces on every commit, from the same share', () => {
    const { shares } = trustedDealerKeygen(2, 2);
    const seen = new Set<string>();
    for (let i = 0; i < 20; i++) {
      // The nonces are not readable from the handle; their commitments are G times them, so
      // 40 distinct points means 40 distinct nonces - none repeated, none shared by a pair.
      const { commitment } = commit(shares[0]!);
      seen.add(commitment.hiding.toHex(true));
      seen.add(commitment.binding.toHex(true));
    }
    expect(seen.size).toBe(40);
  });
});

describe('FROST: one party alone cannot sign', () => {
  it('a single share does not aggregate into a valid signature', () => {
    const { commitments, sigShares, groupPublicKey, m, check } = session('solo attempt');
    // Party 1 tries to finish without party 2. Aggregation refuses on the count, and even
    // forcing it through produces something verify() rejects.
    expect(() => aggregate(commitments, [sigShares[0]!], m, groupPublicKey, check)).toThrow();
    const forged = { R: groupCommitment(commitments, bindingFactors(commitments, m, groupPublicKey)), z: sigShares[0]!.z };
    expect(verify(forged, m, groupPublicKey)).toBe(false);
  });

  it('a party cannot sign with only its own commitment', () => {
    const { chosen, groupPublicKey, check } = session('lonely');
    const m = msg('lonely');
    // Fresh nonces: the session's are spent, and reusing them would now (rightly) throw.
    const mine = commit(chosen[0]!);
    const alone = [mine.commitment];
    const soloShare = sign(chosen[0]!, mine.nonces, alone, m);
    // Signing against a one-party commitment list yields a signature for a DIFFERENT key
    // (lambda over {1} is 1, so this is a signature under party 1's share, not the group).
    // I-10: aggregate refuses a signing set below the threshold outright...
    expect(() => aggregate(alone, [soloShare], m, groupPublicKey, check)).toThrow(/below the group's threshold of 2/);
    // ...and a coordinator that sums it anyway gets a signature verify() rejects.
    const solo = { R: groupCommitment(alone, bindingFactors(alone, m, groupPublicKey)), z: soloShare.z };
    expect(verify(solo, m, groupPublicKey)).toBe(false);
  });

  it('refuses a share from a party that never committed', () => {
    const { commitments, sigShares, groupPublicKey, m, check } = session('outsider');
    const outsider = { id: 99, z: sigShares[0]!.z };
    expect(() => aggregate(commitments, [sigShares[0]!, outsider], m, groupPublicKey, check))
      .toThrow(/uncommitted participant 99/);
  });
});

describe('FROST: binding factors defend the nonce', () => {
  it('makes every factor depend on the whole commitment list', () => {
    const { commitments, groupPublicKey, m } = session('bind');
    const base = bindingFactors(commitments, m, groupPublicKey);

    // Change ONE party's commitment; the OTHER party's binding factor must change too.
    // That is what stops a party who commits second from steering the group nonce.
    const tweaked = [
      commitments[0]!,
      { ...commitments[1]!, binding: commitments[1]!.binding.add(Point.BASE) },
    ];
    const after = bindingFactors(tweaked, m, groupPublicKey);
    expect(after.get(1)).not.toBe(base.get(1));
    expect(after.get(2)).not.toBe(base.get(2));
  });

  it('makes every factor depend on the message', () => {
    const { commitments, groupPublicKey } = session('bind-msg');
    const a = bindingFactors(commitments, msg('one'), groupPublicKey);
    const b = bindingFactors(commitments, msg('two'), groupPublicKey);
    expect(a.get(1)).not.toBe(b.get(1));
  });

  it('is order-independent, so the coordinator cannot change the outcome by reordering', () => {
    const { commitments, groupPublicKey, m } = session('order');
    const forward = bindingFactors(commitments, m, groupPublicKey);
    const reversed = bindingFactors([...commitments].reverse(), m, groupPublicKey);
    expect(reversed.get(1)).toBe(forward.get(1));
    expect(groupCommitment([...commitments].reverse(), reversed).toHex(true))
      .toBe(groupCommitment(commitments, forward).toHex(true));
  });

  it('a share computed for one message does not validate against another', () => {
    const { chosen, sigShares, commitments, groupPublicKey } = session('m1');
    const forOne = sigShares[0]!;
    expect(verifyShare(forOne, commitments, msg('m1'), groupPublicKey, publicShareOf(chosen[0]!)))
      .toBe(true);
    expect(verifyShare(forOne, commitments, msg('m2'), groupPublicKey, publicShareOf(chosen[0]!)))
      .toBe(false);
  });
});

describe('FROST: per-share verification identifies the culprit', () => {
  it('accepts honest shares', () => {
    const { chosen, commitments, sigShares, groupPublicKey, m } = session('honest');
    sigShares.forEach((s, i) => {
      expect(verifyShare(s, commitments, m, groupPublicKey, publicShareOf(chosen[i]!))).toBe(true);
    });
  });

  it('names the party whose share is wrong', () => {
    const { chosen, commitments, sigShares, groupPublicKey, m, check } = session('tampered');
    const bad = { id: sigShares[1]!.id, z: sigShares[1]!.z + 1n };
    expect(verifyShare(sigShares[0]!, commitments, m, groupPublicKey, publicShareOf(chosen[0]!))).toBe(true);
    expect(verifyShare(bad, commitments, m, groupPublicKey, publicShareOf(chosen[1]!))).toBe(false);
    // ...and aggregate names it rather than returning an invalid signature (I-10).
    expect(() => aggregate(commitments, [sigShares[0]!, bad], m, groupPublicKey, check))
      .toThrow(/participant 2's signature share is invalid/);
  });
});

describe('FROST: thresholds and Lagrange', () => {
  it('signs 2-of-3 with any pair', () => {
    for (const pair of [[1, 2], [1, 3], [2, 3]]) {
      const { shares, groupPublicKey } = trustedDealerKeygen(2, 3);
      const chosen = pair.map((id) => shares.find((s) => s.id === id)!);
      const rounds = chosen.map((s) => ({ share: s, ...commit(s) }));
      const commitments = rounds.map((r) => r.commitment);
      const m = msg(`pair-${pair.join('')}`);
      const sig = aggregate(
        commitments, rounds.map((r) => sign(r.share, r.nonces, commitments, m)), m, groupPublicKey, checkOf(shares, 2),
      );
      expect(verify(sig, m, groupPublicKey)).toBe(true);
    }
  });

  it('cannot sign 2-of-3 with only one party', () => {
    const { shares, groupPublicKey } = trustedDealerKeygen(2, 3);
    const one = shares[0]!;
    const { nonces, commitment } = commit(one);
    const m = msg('one of three');
    expect(() => aggregate([commitment], [sign(one, nonces, [commitment], m)], m, groupPublicKey, checkOf(shares, 2)))
      .toThrow(/below the group's threshold/);
  });

  it('Lagrange coefficients reconstruct the constant term', () => {
    const secret = 123456789n;
    const { shares } = trustedDealerKeygenFromSecretForTesting(2, 3, secret);
    for (const set of [[1, 2], [1, 3], [2, 3]]) {
      const recovered = set.reduce((acc, id) => {
        const s = shares.find((x) => x.id === id)!;
        return (acc + lagrangeCoefficient(id, set) * s.share) % ORDER;
      }, 0n);
      expect(recovered % ORDER).toBe(secret);
    }
  });

  it('rejects a nonsensical threshold', () => {
    expect(() => trustedDealerKeygen(3, 2)).toThrow(/invalid threshold/);
    expect(() => trustedDealerKeygen(0, 2)).toThrow(/invalid threshold/);
  });

  it('refuses a Lagrange coefficient for a non-signer', () => {
    expect(() => lagrangeCoefficient(4, [1, 2])).toThrow(/not in the signing set/);
  });
});

describe('FROST: encoding', () => {
  it('encodes scalars big-endian in 32 bytes', () => {
    expect(Array.from(scalarToBytes(1n)).slice(-1)).toEqual([1]);
    expect(scalarToBytes(1n).length).toBe(32);
    expect(scalarToBytes(0n).every((b) => b === 0)).toBe(true);
  });

  it('derives a challenge that depends on R, the key and the message', () => {
    const { signature, groupPublicKey, m } = session('chal');
    const c = challenge(signature.R, groupPublicKey, m);
    expect(challenge(signature.R, groupPublicKey, msg('other'))).not.toBe(c);
    expect(challenge(signature.R.add(Point.BASE), groupPublicKey, m)).not.toBe(c);
  });
});

/** Two parties' round one, ready for round two. */
function roundOne() {
  const { shares, groupPublicKey } = trustedDealerKeygen(2, 2);
  const [a, b] = [commit(shares[0]!), commit(shares[1]!)];
  return { shares, groupPublicKey, a, b, list: [a.commitment, b.commitment] };
}

describe('FROST: nonces are single-use', () => {
  /**
   * Reusing a nonce pair across two signatures reveals the share by algebra. `sign` used to
   * accept the same nonces as often as it was handed them.
   */
  it('refuses to sign a second message with the same nonces', () => {
    const { shares, a, list, groupPublicKey } = roundOne();
    const first = sign(shares[0]!, a.nonces, list, msg('pay 100'));
    expect(verifyShare(first, list, msg('pay 100'), groupPublicKey, publicShareOf(shares[0]!))).toBe(true);
    expect(() => sign(shares[0]!, a.nonces, list, msg('pay 100000'))).toThrow(/already used/);
  });

  it('refuses even the same message again', () => {
    const { shares, a, list } = roundOne();
    sign(shares[0]!, a.nonces, list, msg('same'));
    expect(() => sign(shares[0]!, a.nonces, list, msg('same'))).toThrow(/already used/);
  });

  it('reports whether a handle has been spent', () => {
    const { shares, a, list } = roundOne();
    expect(a.nonces.used).toBe(false);
    sign(shares[0]!, a.nonces, list, msg('x'));
    expect(a.nonces.used).toBe(true);
  });

  /// A copy, a deserialised object or a restored backup is exactly how nonces get reused.
  it('refuses nonces that were copied rather than produced by commit()', () => {
    const { shares, a, list } = roundOne();
    expect(() => sign(shares[0]!, { ...a.nonces }, list, msg('x'))).toThrow(/not produced by commit/);
    expect(() => sign(shares[0]!, JSON.parse(JSON.stringify(a.nonces)), list, msg('x')))
      .toThrow(/not produced by commit/);
    // ...and the refusal did not spend the real ones.
    expect(a.nonces.used).toBe(false);
  });

  it('refuses nonces made for another participant', () => {
    const { shares, b, list } = roundOne();
    expect(() => sign(shares[0]!, b.nonces, list, msg('x'))).toThrow(/participant 2's share/);
  });

  it('does not spend nonces on a request it refuses, since nothing was computed', () => {
    const { shares, a, b, list, groupPublicKey } = roundOne();
    expect(() => sign(shares[0]!, a.nonces, [b.commitment], msg('x'))).toThrow();
    expect(a.nonces.used).toBe(false);
    const z = sign(shares[0]!, a.nonces, list, msg('x'));
    const zb = sign(shares[1]!, b.nonces, list, msg('x'));
    expect(verify(aggregate(list, [z, zb], msg('x'), groupPublicKey, checkOf(shares, 2)), msg('x'), groupPublicKey)).toBe(true);
  });
});

describe('FROST: a signer checks the commitment list it is given', () => {
  it('refuses a list without its own commitment', () => {
    const { shares, a, b } = roundOne();
    expect(() => sign(shares[0]!, a.nonces, [b.commitment], msg('x')))
      .toThrow(/own commitment is not among the commitments/);
  });

  it('refuses a list with its own commitment twice', () => {
    const { shares, a, b } = roundOne();
    expect(() => sign(shares[0]!, a.nonces, [a.commitment, a.commitment, b.commitment], msg('x')))
      .toThrow(/repeats a participant identifier/);
  });

  /// Otherwise a coordinator could have this party sign against a nonce it never made.
  it('refuses a list carrying a different commitment under its own identifier', () => {
    const { shares, a, b } = roundOne();
    const swapped = { ...a.commitment, binding: a.commitment.binding.add(Point.BASE) };
    expect(() => sign(shares[0]!, a.nonces, [swapped, b.commitment], msg('x')))
      .toThrow(/not the one it made/);
    const other = commit(shares[0]!).commitment;
    expect(() => sign(shares[0]!, a.nonces, [other, b.commitment], msg('x')))
      .toThrow(/not the one it made/);
  });

  it('refuses a repeated identifier for another participant', () => {
    const { shares, a, b } = roundOne();
    expect(() => sign(shares[0]!, a.nonces, [a.commitment, b.commitment, b.commitment], msg('x')))
      .toThrow(/repeats a participant identifier/);
  });

  it('refuses the identity point and a non-positive identifier', () => {
    const { shares, a, b } = roundOne();
    expect(() => sign(shares[0]!, a.nonces, [a.commitment, { ...b.commitment, hiding: Point.ZERO }], msg('x')))
      .toThrow(/identity point/);
    expect(() => sign(shares[0]!, a.nonces, [a.commitment, { ...b.commitment, id: 0 }], msg('x')))
      .toThrow(/invalid participant identifier/);
  });
});

describe('FROST: nonce generation (RFC 9591 §4.1)', () => {
  const r1 = new Uint8Array(32).fill(1);
  const r2 = new Uint8Array(32).fill(2);

  /// Known randomness without the share does not give the nonce: the hedge.
  it('mixes the secret share into the randomness', () => {
    expect(nonceGenerate(5n, r1)).not.toBe(nonceGenerate(6n, r1));
    expect(nonceGenerate(5n, r1)).not.toBe(nonceGenerate(5n, r2));
  });

  /**
   * And the limit of the hedge, stated as a test so nobody re-reads it as more: the same
   * randomness with the same share is the same nonce, whatever the message. A repeating RNG
   * therefore repeats nonces; only fresh randomness and single use prevent that.
   */
  it('does not protect against randomness that repeats', () => {
    expect(nonceGenerate(5n, r1)).toBe(nonceGenerate(5n, r1));
  });

  it('offers no way to feed commit() chosen randomness', () => {
    expect(commit.length).toBe(1);
  });
});

describe('FROST: the test dealer', () => {
  it('always generates the secret itself', () => {
    expect(trustedDealerKeygen.length).toBe(2);
    // A stray third argument no longer chooses the key.
    const { groupPublicKey } = (trustedDealerKeygen as (...a: unknown[]) => ReturnType<typeof trustedDealerKeygen>)(2, 2, 5n);
    expect(groupPublicKey.equals(Point.BASE.multiply(5n))).toBe(false);
  });

  it('keeps the known-secret variant for tests, and refuses a zero secret', () => {
    const { groupPublicKey } = trustedDealerKeygenFromSecretForTesting(2, 2, 5n);
    expect(groupPublicKey.equals(Point.BASE.multiply(5n))).toBe(true);
    expect(() => trustedDealerKeygenFromSecretForTesting(2, 2, 0n)).toThrow(/must not be zero/);
    expect(() => trustedDealerKeygenFromSecretForTesting(2, 2, ORDER)).toThrow(/must not be zero/);
  });
});

/**
 * The vectors `contracts/test/SchnorrVerifier.t.sol` checks on-chain, checked here too. They
 * are final signatures (key, R, z, digest), so how the nonces behind them were generated
 * does not enter verification: changing nonce generation did not require regenerating them,
 * and this is the evidence.
 */
describe('FROST: the on-chain differential vectors', () => {
  const src = readFileSync(new URL('../../../contracts/test/SchnorrVerifier.t.sol', import.meta.url), 'utf8');
  const vectors = [...src.matchAll(/Vector\(\{([^}]*)\}\)/g)].map((m) => {
    const f = (k: string) => BigInt(new RegExp(`${k}:\\s*(0x[0-9a-f]+)`).exec(m[1]!)![1]!);
    return { gx: f('groupX'), gy: f('groupY'), rx: f('rx'), ry: f('ry'), z: f('z'), digest: f('digest') };
  });

  it('still verify under the TypeScript verifier', () => {
    expect(vectors.length).toBeGreaterThanOrEqual(3);
    for (const v of vectors) {
      const pk = Point.fromAffine({ x: v.gx, y: v.gy });
      const R = Point.fromAffine({ x: v.rx, y: v.ry });
      // Raw bytes, not scalarToBytes: a digest is not reduced modulo the curve order.
      const digest = Uint8Array.from(Buffer.from(v.digest.toString(16).padStart(64, '0'), 'hex'));
      expect(verify({ R, z: v.z }, digest, pk)).toBe(true);
      expect(verify({ R, z: v.z + 1n }, digest, pk)).toBe(false);
    }
  });
});

describe('FROST: z outside (0, n) is invalid, as on-chain (v2.0 I-11)', () => {
  it('rejects z + n and z = 0 instead of reducing them', () => {
    const { signature, groupPublicKey, m } = session('I-11');
    expect(verify(signature, m, groupPublicKey)).toBe(true);
    expect(verify({ ...signature, z: signature.z + ORDER }, m, groupPublicKey)).toBe(false);
    expect(verify({ ...signature, z: 0n }, m, groupPublicKey)).toBe(false);
  });
});
