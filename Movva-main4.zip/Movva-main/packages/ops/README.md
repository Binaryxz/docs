# @mova/ops — monitoring and admin tooling

Three binaries and the packaging to run them. Both exist because production hardening is mostly
about the hours when nobody is watching: one tool that notices, and one that makes a
privileged change reviewable before it happens.

## The monitor

Sweeps the contracts on an interval and exposes what it found.

```bash
RPC_URL=https://... PP_ENTRYPOINT=0x… ORACLE=0x… VAULT=0x… \
RELAYER=0x… PAYMASTER=0x… ALERT_WEBHOOK=https://hooks.slack.com/… \
  npm run -w @mova/ops monitor
```

Every target is optional; it watches what it is given. It holds no key and sends no
transaction — `eth_call` and `eth_getBalance` only — which is what makes it safe to replicate
on hardware you do not control.

| Endpoint | Question it answers |
|---|---|
| `/healthz` | Is this process alive? Always 200 while it runs — see below |
| `/readyz` | Has it completed a sweep yet? 503 until the first one |
| `/status` | The verdict, what is firing, and every reading |
| `/metrics` | Prometheus exposition |

**`/healthz` deliberately ignores the chain's health.** A monitor that marks itself unhealthy
when the thing it watches breaks gets restarted by its supervisor at exactly the moment it had
something to say. The chain's verdict lives in `/status`, and the alerts go to the webhook.

### Checks

`oracle_freshness`, `asset_oracle:<asset>`, `asp_root_age`, `relayer_gas`, `paymaster_deposit`, `paymaster_stake`,
`paymaster_global_cap` (an OwnerlessPaymaster's deposit against 3 × its `MAX_COST_GLOBAL`, `PAYMASTER_GLOBAL_CAP_WINDOWS`),
`pyth_keeper_gas:<address>` (`PYTH_KEEPERS`), `vault_drawdown`, `vault_liquidity`, `pool_reachable`,
the `movva_*` checks and the `node_rewards_*` checks. What each one means when it fires, and what to do, is in
[`docs/runbook-incidents.md`](../../docs/runbook-incidents.md).

**An LP node's per-payer caps** (`LP_NODE_STATUS_URL`, optionally `LP_NODE_NAME`; packages/lp-node `caps.ts`).
Set these only for a node whose operator HAS configured caps - a node without them is a policy choice, not a fault:

| Check | Fires when | What to do |
|---|---|---|
| `lp_node_caps` | fail: the node's `/status` reports no caps at all (the `caps` section is gone from its `LP_CONFIG`, or this is not the node you think); fail: it is counting into another Brasília day than today, so every daily limit resets at the wrong hour; fail: it attributed BRL to a payer more than `LP_NODE_CAPS_STALE_SECONDS` (300) after its cap ledger was last written. warn: it keeps a ledger no tier puts a limit on | No caps: put the section back and restart it - meanwhile that LP applies no limit to anyone. Wrong day: fix the node's clock or timezone. Stale ledger: check `STATE_FILE` is writable and is the journal it has been running on. No limits: set the numbers in `config.caps.tiers` |

**Node-provider rewards** (`NODE_REWARDS`, optionally `FEE_SPLITTER`; SR2-36):

| Check | Fires when | What to do |
|---|---|---|
| `node_rewards_balance` | fail: NodeRewards holds less of its token than it has booked, so claims revert | Only a claim moves tokens out: look at the reward token itself (a fee, a freeze, a rebase) |
| `node_rewards_unclaimed` | warn: an epoch has been finalizable for `REWARDS_FINALIZE_WARN_SECONDS` (2 days) and nobody finalized it; or more than `REWARDS_UNCLAIMED_FLOOR_CENTS` (R$ 100,00) is owed and no LP has claimed for `REWARDS_UNCLAIMED_WARN_SECONDS` (30 days) | Anyone may send `rewards:finalize`; ask LPs whether their nodes run with `rewards.claim`. Nothing expires |
| `node_rewards_wiring` | warn: no registry bound while there is something to share, or the splitter funds another contract or splits another token | `rewards:registry` to bind the ramp's registry; `splitter:rewards` through the delay |

**The LP network** (`LP_REGISTRY` with `LP_NETWORK_FROM_BLOCK`, its deployment block - default `WATCH_FROM_BLOCK`; the
escrows are `ESCROW` and `OFFRAMP_ESCROW`, or `LP_ESCROWS`; `LP_NETWORK_LPS` adds LPs the history does not name;
`src/lp-network.ts`). It reads the registry's and escrows' logs from that block once, keeps a cursor, and reads state for
each LP every sweep:

| Check | Fires when | What to do |
|---|---|---|
| `lp_network` | unknown: the registry or its logs could not be read. Otherwise `ok`, a summary: phase, LPs by tier, exposure live, changes queued | - |
| `lp_credit:<lp>` | warn: the LP uses `LP_CREDIT_WARN_PERCENT` (80) of its limit (live exposure plus credit carved out for affiliates); fail at `LP_CREDIT_FAIL_PERCENT` (100): it can quote nothing new | Look at its record (`lp:status <lp>`); raise with `lp:credit` (delayed) only on settled volume |
| `lp_disputes:<lp>` | warn: an open dispute on either escrow against an order or sale of this LP (`lp_disputes:unattributed` for one the history cannot place) | The arbitration desk rules; a pattern is `lp:suspend` first |
| `lp_change:<id>` | warn: a scheduled registry change is ready and within `LP_CHANGE_EXPIRY_WARN_SECONDS` (3 days) of expiring unexecuted; warn while an expired one is still queued | `lp:execute <id>`, or `lp:cancel <id>` - `--finalize` refuses while anything is queued |
| `lp_slash:<lp>` | PermissionlessLPRegistry only. fail: for `LP_SLASH_ALERT_SECONDS` (1 day) after the LP lost a dispute - a `Slashed` / `DisputeLost` log, or a `disputesLost` that rose between sweeps - its whole bond is gone; `lp_slash:unattributed` for a `totalSlashed` rise no known LP explains | Check the ruling on the arbitration desk; a slash cannot be undone. Anyone may close the LP's offers (`closeOffer`) |
| `lp_exit:<lp>` | PermissionlessLPRegistry only. warn: the LP asked to leave and still has exposure live (detail: `withdrawableFrom`, exposure by escrow); fail: `withdrawableFrom` has passed and exposure is still live | End its positions: `closeOffer`, `reclaimExpired` / `releaseStaleClaim`, `expireDispute` after the timeout |

On a PermissionlessLPRegistry (`LP_REGISTRY` answering `MIN_BOND` and `escrowsBound`) there are no tiers, phases or
`lp_change:*` checks; `lp_network` warns while its escrows are unbound, LPs are found from `Joined`, and the escrows are
read from the registry.

Both contracts join the event watcher's governed set, and a scheduled `setLpRewardShare`, `setRewardLimits`, `setRegistry`,
`setExcluded`, `setTreasury`, `setRewards` or `setRewardsHook` is decoded in its alert.

**An FX rate sleeps at night.** PythFxOracle's rate is Pyth's FX.USD/BRL, which trades weekdays 08:00-17:00
New York time, so it ages and then refuses every weekday night and weekend by design. `oracle_freshness`
and the `movva_*` checks judge such a leg by FxMarketHours' core session (13:30-21:00 UTC): a stale or
refused rate inside it alerts and names the Pyth keeper; outside it, a band that still prices the last close
is `ok` and says the market is closed, and a band that refuses too alerts.

### Three states, not two

A check returns `ok`, `warn`, `fail` — or **`unknown`**, which is the one that matters. A
check whose call threw has not passed; it has failed to run. Collapsing that into `ok` is how
a dashboard stays green while the chain is on fire. `unknown` alerts on its own, after a
five-minute grace period so one flaky call is not a page.

### Alerts are edges

Entering a bad state fires once. Staying there is silent. Recovering sends a resolution. A
monitor that pages every sixty seconds gets muted, and a muted monitor buys silence rather
than safety.

## The admin tool

Every governor, guardian and keeper function in `contracts/ramp` and `contracts/yield` (the
escrows, registry, verifiers, oracles and vault) — and
none of them fires without `--execute`. `test/admin.test.ts` reads those contracts and fails
when a guarded function has no command, so the claim is checked. Not covered: the
`SponsorPaymaster` owner functions.

```bash
# Dry run: prints the call, the risk, the calldata and a pasteable cast send
npm run -w @mova/ops admin -- lp:tier $REGISTRY $LP AFFILIATED 500000

# Send it (or omit --execute and hand the calldata to the multisig)
npm run -w @mova/ops admin -- lp:tier $REGISTRY $LP AFFILIATED 500000 --execute

# Submit a ruling exactly as the arbitration desk handed it over
curl -H "authorization: Bearer $OPERATOR_TOKEN" $DESK/cases/$CASE/submission > ruling.json
npm run -w @mova/ops admin -- escrow:resolve $ESCROW ruling.json
```

Node-provider rewards have their own commands: `splitter:share`, `splitter:treasury`, `splitter:rewards` and
`splitter:split` on the FeeSplitter; `rewards:registry`, `rewards:limits`, `rewards:exclude`, `rewards:void` and
`rewards:finalize` on NodeRewards; `lp:rewards-hook` on the registry. Raising the LPs' share, the rate or the per-LP cap,
lowering the minimum, a new treasury, rewards contract, hook or (once funded) registry, and reinstating an excluded LP go through
`gov:schedule` / `gov:execute`; the dry run says which way a share or limits change goes. `splitter:split` and
`rewards:finalize` are open to anyone and read `SUBMITTER_KEY`.

`npm run -w @mova/ops admin` with no arguments lists every command. Tiers are the registry's
enum by name — `NONE`, `RETAIL`, `AFFILIATED`, `INSTITUTIONAL`, `SUSPENDED` — and anything
else, including a bare number, is refused. Keeper and guardian commands read `KEEPER_KEY` or
`GUARDIAN_KEY` instead of `GOVERNOR_KEY`.

**The governance timelock.** Risk-increasing calls (adding arbitrators, verifiers or
witnesses, lowering thresholds, listing assets or feeds, adding adapters, changing the keeper,
raising tiers or caps, advancing the network phase) are moving to schedule → execute after
48 hours. Those commands still call the direct function today; the list, and how to add the
schedule/execute pairs, is the TODO above `COMMANDS` in `src/bin/admin.ts`.

**Why the dry run is the default.** These commands decide whose attestation releases escrowed
money, what an LP may hold, and who governs the contracts. A tool that acts first and reports
afterwards gets used quickly and reviewed never. In production the governor should be a
multisig, in which case the dry run *is* the workflow: it prints the calldata to approve.

With `--execute` the call is simulated before it is sent, so a revert costs nothing and an
operator is never left guessing whether a change took effect.

## The LP tool

`src/bin/lp.ts` automates [`docs/runbook-lp-onboarding.md`](../../docs/runbook-lp-onboarding.md): admitting, re-crediting,
suspending and removing LPs, moving the network phase, an institution sponsoring affiliates, and the network's status.
It reads the deployment record (`--rail`, default `deployments/sepolia-movva-only-rail.json`) and builds every call with
the admin tool's command table (`lp:tier`, `lp:phase`, `gov:schedule`, `gov:execute`, `gov:cancel`).

```bash
npm run -w @mova/ops lp -- lp:status [lp] [--node <url>]          # tier, credit, exposure, available, record, disputes, pending, gateway, node
npm run -w @mova/ops lp -- lp:pending                             # every scheduled registry change, readyAt and expiry
npm run -w @mova/ops lp -- lp:admit <lp> INSTITUTIONAL <centavos> # checks, then schedule setTier; prints id and readyAt
npm run -w @mova/ops lp -- lp:execute <id>                        # after GOVERNANCE_DELAY, within 14 days (lp:cancel <id> drops it)
npm run -w @mova/ops lp -- lp:credit <lp> <centavos>              # raise = scheduled, cut = instant
npm run -w @mova/ops lp -- lp:suspend <lp>                        # instant
npm run -w @mova/ops lp -- lp:remove <lp> [--force --reason "<why>"]  # instant; refused while exposure is live
npm run -w @mova/ops lp -- lp:phase <A|B|C>                       # open = scheduled, close = instant; warns before finalization
npm run -w @mova/ops lp -- lp:sponsor <affiliate> <centavos>      # phase B, from the institution's LP_KEY (lp:unsponsor ends it)
```

Every command is a dry run until `--execute --confirm <subject>`: the subject is what the command acts on - the LP's
address, the phase letter, the change id - so a pasted line aimed at the wrong LP fails closed. `--execute` reads
`GOVERNOR_KEY` (`LP_KEY` for sponsorship), refuses unless that key is the registry's governor (or the sponsor), simulates,
sends, and records the transaction (and a forced removal's reason) in the ledger. The ledger is the registry's and
escrows' history folded with a cursor - which addresses are LPs, what each scheduled change contains, which disputes
are open - at `deployments/<rail>/lp-ledger.json` by default (`--ledger`, `LP_LEDGER`); against a local node it stays in
memory unless named. Reads page `eth_getLogs` down to 10 blocks when the provider refuses wider (Alchemy's free plan).

`examples/lp-onboarding-fork.ts` rehearses an admission end to end on an anvil fork of Sepolia (ports 8966-8967):
schedule, warp 48 h, execute, status, suspend, every refusal checked, then the monitor's LP checks.

## The hedge-sleeve tool

The delta-neutral hedge sleeve's funding path (docs/delta-neutral.md section 12) as Safe transactions. The sleeve is
Movva's OWN capital: since the principal-locked reserve (client rule, 21 October 2026) MovvaReserve's USDT leaves only by
redemption and, as yield above max(principal, the target's liabilities), by `harvestYield` to Mova's yield recipient. It
has no `withdrawToHedge`, no hedge queue and no treasurer, and `reserve:withdraw` / `reserve:queue` / `reserve:execute`
are gone with them.

- **Out:** Movva moves its own USDT to the hedge Safe (the sub-wallet's `TREASURY`), and the hedge Safe funds the
  sub-wallet.
- **Home:** the hedge Safe calls `withdrawToTreasury`. It may then `recapitalize` the reserve - one way: that USDT
  becomes principal and leaves the reserve only by redemption.

`reconcile` and `coverage` report the reserve (the backing, with its principal and harvestable yield) and, separately,
Movva's capital on the hedge path, which is never counted as backing or added to a coverage ratio.

```bash
npm run -w @mova/ops hedge-sleeve -- status
npm run -w @mova/ops hedge-sleeve -- sleeve:fund <usdt>          # hedge Safe: approve + fund in ONE Safe tx (MultiSendCallOnly)
npm run -w @mova/ops hedge-sleeve -- sleeve:unwind [bandBps]     # hedge Safe: both legs closed at its own limits, no keeper
npm run -w @mova/ops hedge-sleeve -- sleeve:withdraw <usdt|all>  # hedge Safe
npm run -w @mova/ops hedge-sleeve -- reserve:recapitalize <usdt> # hedge Safe: approve + recapitalize in one Safe tx (one way: principal)
```

**Dry run by default.** It prints the checks, the inner calls, and the Safe transaction with its
nonce and `safeTxHash` for the owners to sign. `--json` prints it as a Safe{Wallet} Transaction
Builder file instead.

**Sending it.** `--execute --confirm <subject>` needs `SAFE_SIGNER_KEYS` (the owners' keys, at least
the threshold) and `SAFE_SUBMITTER_KEY`, or `SENDER_KEY` where the role is a plain key. Before sending
it checks the chain's own `getTransactionHash` against the hash it computed, and simulates.
`--impersonate` works on an anvil fork only.

**Addresses** come from `deployments/sepolia-final-hedge-sleeve.json` (`--record`), or from `--reserve` and
`--wallet` (`reconcile` and `coverage` take `--reserve` alone, with `--hedge-safe` for the Safe to report beside it).

## Running it in production

`Dockerfile` builds one image for the monitor, the matcher and the arbitration desk;
`docker-compose.yml` runs them locally in production shape (the desk, which holds a key, only
under `--profile arbitration`); `flux/` holds the Flux application specs for the two keyless
services and — more importantly —
[which services can be replicated on machines you do not control, and which cannot](flux/README.md).

Every launch site runs a production entrypoint with `node --import tsx`:
`src/bin/monitor.ts`, `packages/ramp/src/bin/matcher.ts` and
`packages/ramp/src/bin/arbitration.ts`. The matcher and the desk refuse to start on missing
or malformed configuration and name every variable at fault; the monitor refuses to start
with nothing to watch. `test/packaging.test.ts` checks, without Docker, that each launched
script exists and is not a demo, and that the launcher survives `npm ci --omit=dev`.

**No raw error leaves a service.** `src/redact.ts` cuts every URL in an error to scheme and
host and removes configured secrets (RPC_URL, ALERT_WEBHOOK, tokens). It is applied to check
details, `/status`, the alert webhook and console sink, the matcher's `/health`, the desk's
error responses, and every bin's logs — because a viem transport error contains the RPC URL,
and a hosted RPC URL contains its API key.

## Tests

```bash
npx vitest run packages/ops
```

`test/lp.test.ts` and `test/lp-network.test.ts` cover the LP tool against a fake chain: every command's calldata
(checked against the admin tool's), the dry-run default, each refusal, the paged log reader and the status and monitor
aggregation. The ones worth reading are the alert-transition tests, which pin the edge behaviour,
and `checks.test.ts`'s "a read that throws" — the property the whole design rests on.
