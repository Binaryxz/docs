/**
 * `fx_parity`: Chainlink BRL/USD against Pyth FX.USD/BRL, side by side - the "run in parallel" step before the
 * reserve's FX leg moves from Pyth (PythFxOracle) to Chainlink (ChainlinkFxOracle). Read-only: one `eth_call`
 * pair on a mainnet RPC and one Hermes request per sweep. `scripts/fx-parity.ts` is the one-shot version.
 *
 * ## What it compares
 *
 * Both as reais per US dollar. Chainlink quotes the other way round (US dollars per real, 8 decimals), so its
 * figure is the reciprocal, as ChainlinkFxOracle computes it. Pyth's is `price x 10^expo` from Hermes - the
 * price Mova's keeper would post, not whatever was last posted on-chain. The divergence is signed:
 * `(chainlink / pyth - 1) x 10,000` bps, positive when Chainlink says the dollar buys more reais.
 *
 * ## What to expect, and the thresholds
 *
 * While the market trades, Chainlink's answer moves only when it deviates 0.5% from its last round, or on its
 * daily heartbeat; Pyth's moves every few hundred milliseconds. So up to ~50 bps of divergence inside the
 * session is Chainlink's design, not a fault - it is exactly the lag a ChainlinkFxOracle leg would mint and
 * redeem at (ChainlinkFxOracle, "The deviation threshold"). `fxParityWarnBps` (50) warns past it: a
 * divergence the deviation threshold does not explain. `fxParityFailBps` (300, the divergence breaker's
 * default band) fails: one of the two is wrong by more than the breaker would tolerate.
 *
 * While the market is closed both sit on a last close: Pyth's stops at the close, Chainlink's heartbeat keeps
 * re-posting it (and may post the final close hours later). The divergence is still reported and judged, and
 * the detail says the market is closed, so a weekend gap is read as two closes, not as a live disagreement.
 * Closed means Hermes' own `market_hours` for the feed when it answers, FxMarketHours' core session otherwise.
 *
 * Ages: a Chainlink answer older than `fxParityChainlinkMaxAgeSeconds` (26 h, ChainlinkFxOracle's MAX_AGE)
 * has missed its heartbeat and warns; a Pyth price older than `fxParityPythMaxAgeSeconds` (5 min) while
 * Hermes says the market is open warns.
 */
import type { Address, Hex, PublicClient } from 'viem';
import { hermesSource, type PythUpdateSource } from '@mova/yield/src/pyth-keeper.js';
import type { CheckResult, Level } from './checks.js';

/** Chainlink BRL/USD on Ethereum mainnet: the live proxy, from Chainlink's feed list (verified 19 October 2026). */
export const CHAINLINK_BRL_USD_MAINNET = '0x3126E7F38D5f60f4E2B6ec3511C7bdbD79317Df1' as Address;
/** The retired proxy the September 2026 finding was about: last updated 25 August 2023, "No access" to contracts. */
export const CHAINLINK_BRL_USD_RETIRED = '0x0eBDc65E7e9132Cb41ac5cbD0101B799D7aDb475' as Address;
/** Pyth's FX.USD/BRL price id: reais per US dollar. The same on every chain. */
export const PYTH_FX_USD_BRL_ID = '0xd2db4dbf1aea74e0f666b0e8f73b9580d407f5e5cf931940b06dc633d7a95906' as Hex;

export interface FxParityThresholds {
  fxParityWarnBps: number;
  fxParityFailBps: number;
  fxParityChainlinkMaxAgeSeconds: number;
  fxParityPythMaxAgeSeconds: number;
}

export const DEFAULT_FX_PARITY_THRESHOLDS: FxParityThresholds = {
  fxParityWarnBps: 50,
  fxParityFailBps: 300,
  fxParityChainlinkMaxAgeSeconds: 26 * 3600,
  fxParityPythMaxAgeSeconds: 300,
};

export interface FxParityTargets {
  /** A client on Ethereum MAINNET: the only chain with the feed. Often not the monitor's own RPC. */
  client: PublicClient;
  /** Default: CHAINLINK_BRL_USD_MAINNET. */
  feed?: Address;
  /** Hermes, as the Pyth keeper reads it: `fxParityHermes(url, apiKey)`. */
  hermes: PythUpdateSource;
  /** Default: PYTH_FX_USD_BRL_ID. */
  pythId?: Hex;
}

export interface FxParityReading {
  now: number;
  chainlink: {
    feed: Address; answer: bigint; decimals: number; updatedAt: number; ageSeconds: number;
    /** Reais per dollar: 10^decimals / answer. */
    brlPerUsd: number;
  };
  pyth: {
    price: bigint; conf: bigint; expo: number; publishTime: number; ageSeconds: number;
    /** Reais per dollar: price x 10^expo. */
    brlPerUsd: number;
    /** Hermes' `market_hours.is_open`, when Hermes says. */
    marketOpen?: boolean;
  };
  /** (chainlink / pyth - 1) x 10,000. */
  divergenceBps: number;
  /** FxMarketHours' core session at `now`, as the contracts compute it. */
  coreSession: boolean;
  /** Hermes' market hours when it answered, the core session otherwise. */
  marketOpen: boolean;
}

const AGGREGATOR_ABI = [
  {
    type: 'function', name: 'latestRoundData', stateMutability: 'view', inputs: [],
    outputs: [
      { name: 'roundId', type: 'uint80' }, { name: 'answer', type: 'int256' }, { name: 'startedAt', type: 'uint256' },
      { name: 'updatedAt', type: 'uint256' }, { name: 'answeredInRound', type: 'uint80' },
    ],
  },
  { type: 'function', name: 'decimals', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint8' }] },
] as const;

/** Hermes for the parity check. The key goes in the Authorization header and never into an error. */
export function fxParityHermes(url: string, apiKey?: string, fetchImpl?: typeof fetch): PythUpdateSource {
  return hermesSource({ url, apiKey, ...(fetchImpl ? { fetch: fetchImpl } : {}) });
}

/**
 * FxMarketHours.inCoreSession, transcribed: 13:30-21:00 UTC, Monday to Friday, not 25 December or 1 January.
 * test/fx-parity.test.ts pins it to the Solidity test's dates.
 */
export function inCoreSession(t: number): boolean {
  const secondOfDay = ((t % 86_400) + 86_400) % 86_400;
  if (secondOfDay < 13 * 3600 + 30 * 60 || secondOfDay >= 21 * 3600) return false;
  const d = new Date(t * 1000);
  const weekday = d.getUTCDay();
  if (weekday === 0 || weekday === 6) return false;
  const month = d.getUTCMonth() + 1;
  const day = d.getUTCDate();
  return !((month === 12 && day === 25) || (month === 1 && day === 1));
}

/** Both sources, once. A failed read throws: the caller reports it `unknown`. */
export async function readFxParity(t: FxParityTargets, nowSeconds: number = Math.floor(Date.now() / 1000)): Promise<FxParityReading> {
  const feed = t.feed ?? CHAINLINK_BRL_USD_MAINNET;
  const id = t.pythId ?? PYTH_FX_USD_BRL_ID;
  const [round, decimals, pyth, hours] = await Promise.all([
    t.client.readContract({ address: feed, abi: AGGREGATOR_ABI, functionName: 'latestRoundData' }),
    t.client.readContract({ address: feed, abi: AGGREGATOR_ABI, functionName: 'decimals' }),
    t.hermes.latest(id),
    // Market hours are a note, never the reading: a Hermes that cannot say falls back to the core session.
    t.hermes.marketHours ? t.hermes.marketHours(id).catch(() => undefined) : Promise.resolve(undefined),
  ]);
  const answer = round[1];
  const updatedAt = Number(round[3]);
  if (answer <= 0n) throw new Error(`Chainlink ${feed} answers ${answer}: not a price`);
  if (pyth.price <= 0n) throw new Error(`Hermes answers ${pyth.price} for FX.USD/BRL: not a price`);
  const dec = Number(decimals);
  const clBrlPerUsd = 10 ** dec / Number(answer);
  const pyBrlPerUsd = Number(pyth.price) * 10 ** pyth.expo;
  const coreSession = inCoreSession(nowSeconds);
  return {
    now: nowSeconds,
    chainlink: { feed, answer, decimals: dec, updatedAt, ageSeconds: nowSeconds - updatedAt, brlPerUsd: clBrlPerUsd },
    pyth: {
      price: pyth.price, conf: pyth.conf, expo: pyth.expo, publishTime: pyth.publishTime,
      ageSeconds: nowSeconds - pyth.publishTime, brlPerUsd: pyBrlPerUsd,
      ...(hours ? { marketOpen: hours.isOpen } : {}),
    },
    divergenceBps: (clBrlPerUsd / pyBrlPerUsd - 1) * 10_000,
    coreSession,
    marketOpen: hours ? hours.isOpen : coreSession,
  };
}

const RANK: Level[] = ['ok', 'unknown', 'warn', 'fail'];
const worse = (a: Level, b: Level): Level => (RANK.indexOf(b) > RANK.indexOf(a) ? b : a);
const hm = (s: number) => (s >= 3600 ? `${(s / 3600).toFixed(1)} h` : `${Math.max(0, Math.round(s))} s`);

/** The verdict on one reading. Pure: the tests drive it. */
export function judgeFxParity(r: FxParityReading, th: FxParityThresholds = DEFAULT_FX_PARITY_THRESHOLDS): CheckResult {
  const abs = Math.abs(r.divergenceBps);
  let level: Level = abs > th.fxParityFailBps ? 'fail' : abs > th.fxParityWarnBps ? 'warn' : 'ok';
  const notes: string[] = [];
  if (r.chainlink.ageSeconds > th.fxParityChainlinkMaxAgeSeconds) {
    level = worse(level, 'warn');
    notes.push(`Chainlink's answer is ${hm(r.chainlink.ageSeconds)} old, past its heartbeat: a ChainlinkFxOracle leg would refuse`);
  }
  if (r.pyth.marketOpen === true && r.pyth.ageSeconds > th.fxParityPythMaxAgeSeconds) {
    level = worse(level, 'warn');
    notes.push(`Hermes says the market is open but its price is ${hm(r.pyth.ageSeconds)} old`);
  }
  if (!r.marketOpen) {
    notes.push('the FX market is closed: both are last closes (Chainlink\'s re-posted by its heartbeat), and neither leg would mint on it');
  } else if (abs > th.fxParityWarnBps) {
    notes.push(`beyond the ${th.fxParityWarnBps} bps the 0.5% deviation threshold explains`);
  }
  const sign = r.divergenceBps >= 0 ? '+' : '';
  return {
    id: 'fx_parity', level, value: Number(r.divergenceBps.toFixed(2)), threshold: th.fxParityWarnBps,
    detail: `Chainlink BRL/USD R$ ${r.chainlink.brlPerUsd.toFixed(6)} per dollar (${hm(r.chainlink.ageSeconds)} old) vs `
      + `Pyth FX.USD/BRL R$ ${r.pyth.brlPerUsd.toFixed(6)} (${hm(r.pyth.ageSeconds)} old): ${sign}${r.divergenceBps.toFixed(2)} bps`
      + `${notes.length ? `; ${notes.join('; ')}` : ''}`,
  };
}

export async function fxParityCheck(
  t: FxParityTargets, th: FxParityThresholds = DEFAULT_FX_PARITY_THRESHOLDS, nowSeconds?: number,
): Promise<CheckResult> {
  return judgeFxParity(await readFxParity(t, nowSeconds), th);
}
