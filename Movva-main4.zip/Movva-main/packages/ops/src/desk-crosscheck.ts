/**
 * The arbitration desk's answer to "which of these posted rulings did I never sign", asked over its
 * public HTTP routes, for `EventWatcher`'s `unsignedByDesk`.
 *
 * ## Why this matters
 *
 * Anyone may submit a signed ruling, so a stolen arbitrator key - or, with the arbitrator Safe, two of its
 * three owner keys - needs no other access. The thief locks an order as the taker, disputes it, signs
 * RELEASE and posts. The ruling waits RULING_DELAY (one day) before it can execute, and revoking the
 * arbitrator in that day voids it. The only signal is a `RulingPosted` that the desk has no record of,
 * and this is what compares the two. Without it every posted ruling reads as a routine `warn`.
 *
 * ## What counts as signed by the desk
 *
 * The desk's `/health` names its arbitrator: a key's address, or the arbitrator Safe's. A ruling posted
 * under any other arbitrator is not this desk's to vouch for, and is left to the plain `warn`. For one
 * posted under the desk's arbitrator, `GET /cases?escrow=&orderId=` must find a case for exactly that
 * order whose ruling the desk has COMPLETED (status RULED), with the same evidence root and the same
 * direction (`RELEASE` is the outcome that favours the counterparty on both escrows). Anything else is
 * reported as unsigned:
 *  - no case;
 *  - a case still OPEN;
 *  - a case PROPOSED: the owners had not reached the threshold, so no signature existed to post;
 *  - a different evidence root or direction.
 *
 * Only public routes are used, so the monitor holds no desk credential. A desk that cannot be reached, or
 * answers anything but a case or a 404, throws: the watcher reports `desk_crosscheck` unknown and keeps
 * the rulings at `warn`, rather than declaring them signed or forged on no evidence.
 */
import { getAddress, type Address } from 'viem';
import type { PostedRuling } from './watch.js';

export interface DeskCrosscheckOptions {
  /** The desk's base URL, e.g. http://arbitration:8082. */
  url: string;
  /** Per-request timeout. Default 10 s. */
  timeoutMs?: number;
  fetch?: typeof fetch;
}

interface DeskCaseView {
  status?: string;
  escrow?: string;
  orderId?: string;
  ruling?: { outcome?: string } | null;
  evidenceRoot?: string | null;
}

export function deskCrosscheck(o: DeskCrosscheckOptions): (posted: PostedRuling[]) => Promise<PostedRuling[]> {
  const base = o.url.replace(/\/+$/, '');
  const f = o.fetch ?? fetch;
  const get = async (path: string): Promise<{ status: number; body: unknown }> => {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), o.timeoutMs ?? 10_000);
    try {
      const r = await f(`${base}${path}`, { signal: ctl.signal, headers: { accept: 'application/json' } });
      const text = await r.text();
      let body: unknown;
      try { body = JSON.parse(text); } catch { throw new Error(`desk answered ${r.status} with no JSON on ${path.split('?')[0]}`); }
      return { status: r.status, body };
    } finally {
      clearTimeout(timer);
    }
  };

  return async (posted) => {
    const health = await get('/health');
    const arb = (health.body as { arbitrator?: string }).arbitrator;
    if (health.status !== 200 || typeof arb !== 'string') throw new Error(`desk /health answered ${health.status} without its arbitrator`);
    const mine = getAddress(arb as Address);

    const unsigned: PostedRuling[] = [];
    for (const p of posted) {
      if (getAddress(p.arbitrator) !== mine) continue;
      const r = await get(`/cases?escrow=${encodeURIComponent(p.escrow)}&orderId=${encodeURIComponent(p.orderId)}`);
      if (r.status === 404) { unsigned.push(p); continue; }
      if (r.status !== 200) throw new Error(`desk answered ${r.status} for a case lookup`);
      const c = r.body as DeskCaseView;
      const same = c.status === 'RULED'
        && typeof c.escrow === 'string' && getAddress(c.escrow as Address) === getAddress(p.escrow)
        && c.orderId?.toLowerCase() === p.orderId.toLowerCase()
        && c.evidenceRoot?.toLowerCase() === p.evidenceRoot.toLowerCase()
        && (c.ruling?.outcome === 'RELEASE') === p.favoursCounterparty;
      if (!same) unsigned.push(p);
    }
    return unsigned;
  };
}
