/**
 * The LP's own side of PermissionlessLPRegistry (contracts/ramp/PermissionlessLPRegistry.sol): join by bonding MOVVA,
 * top up, ask to leave, withdraw after the unbonding period. Nobody else's key is involved - there is no governor -
 * so every command here is sent from the LP's key (LP_KEY), and the checks are the registry's own rules read from the
 * chain. Design: docs/permissionless-registry.md.
 *
 *   npm run -w @mova/ops lp -- bond:status [lp] --registry <addr>
 *   npm run -w @mova/ops lp -- bond:join 5000 --registry <addr> --from <lp>          # dry run: checks, calldata
 *   npm run -w @mova/ops lp -- bond:join 5000 --registry <addr> --execute --confirm <lp>    # with LP_KEY
 *   npm run -w @mova/ops lp -- bond:topup 2500 | bond:exit | bond:withdraw ...
 *
 * The same conventions as the rest of the `lp` tool: a dry run is the default and prints what it checked, the calldata
 * and pasteable `cast send` lines; `--execute` needs LP_KEY and `--confirm <the LP's address>`, simulates each call,
 * and sends them in order (an `approve` first when the allowance is short). Amounts are in MOVVA (`5000`, `5000.50`):
 * one MOVVA is R$ 1,00 of credit.
 */
import { encodeFunctionData, formatUnits, getAddress, isAddressEqual, parseAbi, parseUnits, type Address, type Hex, type PublicClient } from 'viem';
import { reais } from './reais.js';

export const BOND_REGISTRY_ABI = parseAbi([
  'function MOVVA() view returns (address)',
  'function PREDECESSOR() view returns (address)',
  'function MIN_BOND() view returns (uint256)',
  'function UNBONDING_PERIOD() view returns (uint64)',
  'function UNBONDING_MARGIN() view returns (uint64)',
  'function ESCROW_RULING_DELAY() view returns (uint64)',
  'function DEPLOYER() view returns (address)',
  'function fiatEscrow() view returns (address)',
  'function offRampEscrow() view returns (address)',
  'function escrowsBound() view returns (bool)',
  'function totalBonded() view returns (uint256)',
  'function totalSlashed() view returns (uint256)',
  'function bonds(address) view returns (uint256 amount, uint256 exposureCents, uint256 settledCents, uint64 exitRequestedAt, uint32 settlements, uint32 disputesLost)',
  'function capOf(address) view returns (uint256)',
  'function availableCents(address) view returns (uint256)',
  'function withdrawableFrom(address) view returns (uint256)',
  'function canQuote(address lp, uint256 brlCents) view returns (bool)',
  'function reservedBy(address escrow, address lp) view returns (uint256)',
  'function join(uint256 amount)',
  'function topUp(uint256 amount)',
  'function requestExit()',
  'function withdraw()',
]);
export const ERC20_ABI = parseAbi([
  'function balanceOf(address) view returns (uint256)',
  'function allowance(address owner, address spender) view returns (uint256)',
  'function approve(address spender, uint256 amount) returns (bool)',
]);
const ESCROW_ABI = parseAbi(['function REGISTRY() view returns (address)', 'function DISPUTE_TIMEOUT() view returns (uint64)']);

export type BondClient = Pick<PublicClient, 'readContract'>;

export interface BondCtx {
  client: BondClient;
  registry: Address;
  /** The chain's clock: the latest block's timestamp. */
  now: number;
}

export interface BondRegistryReading {
  registry: Address;
  movva: Address;
  predecessor: Address;
  minBond: bigint;
  unbondingSeconds: bigint;
  marginSeconds: bigint;
  rulingDelaySeconds: bigint;
  deployer: Address;
  escrowsBound: boolean;
  fiatEscrow: Address;
  offRampEscrow: Address;
  totalBonded: bigint;
  totalSlashed: bigint;
  /** Each bound escrow: whether it names this registry back, and its dispute timeout. */
  escrows: { role: 'on-ramp' | 'off-ramp'; address: Address; pointsBack: boolean; disputeTimeout: bigint }[];
}

export interface BondReading {
  lp: Address;
  amount: bigint;
  exposureCents: bigint;
  settledCents: bigint;
  exitRequestedAt: bigint;
  settlements: number;
  disputesLost: number;
  capCents: bigint;
  availableCents: bigint;
  withdrawableFrom: bigint;
  balance: bigint;
  allowance: bigint;
}

export interface BondTx { to: Address; data: Hex; fn: string; signature: string; args: readonly unknown[] }

export interface BondPlan {
  command: string;
  what: string;
  risk: string;
  facts: string[];
  checks: { ok: boolean; text: string }[];
  warnings: string[];
  /** Sent in order, each simulated first. */
  txs: BondTx[];
  /** What `--confirm` must name: the LP's address. */
  confirm: string;
  lp: Address;
  refused: boolean;
}

export class BondUsageError extends Error {}

const ZERO = '0x0000000000000000000000000000000000000000';
const iso = (s: bigint | number) => new Date(Number(s) * 1000).toISOString().replace('.000Z', 'Z');
const days = (s: bigint) => {
  const d = (Number(s) / 86_400).toFixed(2).replace(/\.00$/, '');
  return `${d} ${d === '1' ? 'day' : 'days'}`;
};
export const movva = (wei: bigint) => `${formatUnits(wei, 18)} MOVVA`;

/** `5000` or `5000.50` MOVVA to base units; refuses anything else. */
export function parseMovva(s: string | undefined): bigint {
  if (s === undefined || !/^\d+(\.\d{1,18})?$/.test(s)) throw new BondUsageError(`amount must be MOVVA, e.g. 5000 or 5000.50 (R$ 1,00 each); got ${s ?? 'nothing'}`);
  return parseUnits(s, 18);
}

export async function readBondRegistry(client: BondClient, registry: Address): Promise<BondRegistryReading> {
  const r = <T>(functionName: string, args: readonly unknown[] = []) =>
    client.readContract({ address: registry, abi: BOND_REGISTRY_ABI, functionName, args } as never) as Promise<T>;
  const [mv, predecessor, minBond, unbonding, margin, rulingDelay, deployer, bound, fiat, off, totalBonded, totalSlashed] = await Promise.all([
    r<Address>('MOVVA'), r<Address>('PREDECESSOR'), r<bigint>('MIN_BOND'), r<bigint>('UNBONDING_PERIOD'), r<bigint>('UNBONDING_MARGIN'),
    r<bigint>('ESCROW_RULING_DELAY'), r<Address>('DEPLOYER'), r<boolean>('escrowsBound'), r<Address>('fiatEscrow'), r<Address>('offRampEscrow'),
    r<bigint>('totalBonded'), r<bigint>('totalSlashed'),
  ]);
  const escrows: BondRegistryReading['escrows'] = [];
  for (const [role, address] of [['on-ramp', fiat], ['off-ramp', off]] as const) {
    if (isAddressEqual(address, ZERO)) continue;
    const [back, timeout] = await Promise.all([
      client.readContract({ address, abi: ESCROW_ABI, functionName: 'REGISTRY' }) as Promise<Address>,
      client.readContract({ address, abi: ESCROW_ABI, functionName: 'DISPUTE_TIMEOUT' }) as Promise<bigint>,
    ]);
    escrows.push({ role, address: getAddress(address), pointsBack: isAddressEqual(back, registry), disputeTimeout: BigInt(timeout) });
  }
  return {
    registry, movva: getAddress(mv), predecessor: getAddress(predecessor), minBond: BigInt(minBond), unbondingSeconds: BigInt(unbonding),
    marginSeconds: BigInt(margin), rulingDelaySeconds: BigInt(rulingDelay), deployer: getAddress(deployer), escrowsBound: bound,
    fiatEscrow: getAddress(fiat), offRampEscrow: getAddress(off), totalBonded: BigInt(totalBonded), totalSlashed: BigInt(totalSlashed), escrows,
  };
}

export async function readBond(client: BondClient, reg: BondRegistryReading, lp: Address): Promise<BondReading> {
  const r = <T>(functionName: string) =>
    client.readContract({ address: reg.registry, abi: BOND_REGISTRY_ABI, functionName, args: [lp] } as never) as Promise<T>;
  const [b, cap, avail, from, balance, allowance] = await Promise.all([
    r<readonly [bigint, bigint, bigint, bigint, number, number]>('bonds'), r<bigint>('capOf'), r<bigint>('availableCents'), r<bigint>('withdrawableFrom'),
    client.readContract({ address: reg.movva, abi: ERC20_ABI, functionName: 'balanceOf', args: [lp] }) as Promise<bigint>,
    client.readContract({ address: reg.movva, abi: ERC20_ABI, functionName: 'allowance', args: [lp, reg.registry] }) as Promise<bigint>,
  ]);
  return {
    lp, amount: BigInt(b[0]), exposureCents: BigInt(b[1]), settledCents: BigInt(b[2]), exitRequestedAt: BigInt(b[3]), settlements: Number(b[4]),
    disputesLost: Number(b[5]), capCents: BigInt(cap), availableCents: BigInt(avail), withdrawableFrom: BigInt(from), balance: BigInt(balance),
    allowance: BigInt(allowance),
  };
}

function tx(to: Address, abi: typeof BOND_REGISTRY_ABI | typeof ERC20_ABI, fn: string, args: readonly unknown[]): BondTx {
  const item = (abi as readonly { type: string; name?: string; inputs?: readonly { type: string }[] }[]).find((x) => x.type === 'function' && x.name === fn)!;
  return { to, fn, args, data: encodeFunctionData({ abi, functionName: fn, args } as never), signature: `${fn}(${(item.inputs ?? []).map((x) => x.type).join(',')})` };
}

function registryChecks(reg: BondRegistryReading): { ok: boolean; text: string }[] {
  const checks = [{ ok: reg.escrowsBound, text: reg.escrowsBound ? `escrows bound: on-ramp ${reg.fiatEscrow}, off-ramp ${reg.offRampEscrow} (setup closed for good)` : 'the escrows are not bound yet: the registry refuses join (NotBound) and gives no credit' }];
  for (const e of reg.escrows) {
    checks.push({ ok: e.pointsBack, text: e.pointsBack ? `the ${e.role} escrow names this registry as its REGISTRY` : `the ${e.role} escrow ${e.address} does NOT name this registry: do not bond against it` });
  }
  return checks;
}

function bondFacts(reg: BondRegistryReading, b: BondReading): string[] {
  const exiting = b.exitRequestedAt !== 0n;
  return [
    `${b.lp}: bonded ${movva(b.amount)}; credit ${reais(b.capCents)}; live ${reais(b.exposureCents)}; available ${reais(b.availableCents)}`,
    `  ${exiting ? `LEAVING since ${iso(b.exitRequestedAt)}; withdrawable from ${iso(b.withdrawableFrom)} once nothing is live` : 'not leaving'}; settled ${reais(b.settledCents)} over ${b.settlements}; disputes lost ${b.disputesLost}`,
    `  wallet ${movva(b.balance)}; allowance to the registry ${movva(b.allowance)}; minimum bond ${movva(reg.minBond)}; unbonding ${days(reg.unbondingSeconds)}`,
  ];
}

function finish(p: Omit<BondPlan, 'refused'>): BondPlan {
  return { ...p, refused: p.checks.some((c) => !c.ok) };
}

/** Approve exactly what is missing, if anything, then the call itself. */
function withAllowance(reg: BondRegistryReading, b: BondReading, amount: bigint, call: BondTx): BondTx[] {
  return b.allowance >= amount ? [call] : [tx(reg.movva, ERC20_ABI, 'approve', [reg.registry, amount]), call];
}

const SLASH_WARNING = 'a dispute ruled against you (an off-ramp REFUND, or a dispute you raised and lose or let time out) takes the WHOLE bond, automatically, and it is never returned: bond only what you mean to have at risk';

/** `bond:join <amountMOVVA>`: post at least MIN_BOND and take that much credit. */
export async function planJoin(ctx: BondCtx, argv: string[], lp: Address | undefined): Promise<BondPlan> {
  const amount = parseMovva(argv[0]);
  const who = need(lp);
  const reg = await readBondRegistry(ctx.client, ctx.registry);
  const b = await readBond(ctx.client, reg, who);
  const checks = [
    ...registryChecks(reg),
    { ok: b.exitRequestedAt === 0n, text: b.exitRequestedAt === 0n ? 'not leaving' : `leaving since ${iso(b.exitRequestedAt)}: withdraw first (bond:withdraw), then join again (Exiting)` },
    { ok: b.amount === 0n, text: b.amount === 0n ? 'no bond posted' : `already bonded with ${movva(b.amount)}: add to it with bond:topup (AlreadyBonded)` },
    { ok: amount >= reg.minBond, text: amount >= reg.minBond ? `${movva(amount)} is at least the minimum ${movva(reg.minBond)}` : `${movva(amount)} is below the minimum bond ${movva(reg.minBond)} (BelowMinBond)` },
    { ok: b.balance >= amount, text: b.balance >= amount ? `the wallet holds ${movva(b.balance)}` : `the wallet holds only ${movva(b.balance)}` },
  ];
  const warnings = [SLASH_WARNING];
  if (b.exposureCents > 0n) warnings.push(`${reais(b.exposureCents)} from before is still live and counts against the new credit at once`);
  if (b.disputesLost > 0) warnings.push(`this address has lost ${b.disputesLost} dispute(s) before; the record stays public`);
  return finish({
    command: 'bond:join', lp: who, what: `${who} joins with ${movva(amount)}: ${reais(amount / 10n ** 16n)} of credit`,
    risk: 'the bond answers for every position the LP takes; nobody can remove it, and only a lost dispute takes it',
    facts: bondFacts(reg, b), checks, warnings, txs: withAllowance(reg, b, amount, tx(ctx.registry, BOND_REGISTRY_ABI, 'join', [amount])), confirm: who,
  });
}

/** `bond:topup <amountMOVVA>`: add to a bond, and to the credit. */
export async function planTopUp(ctx: BondCtx, argv: string[], lp: Address | undefined): Promise<BondPlan> {
  const amount = parseMovva(argv[0]);
  const who = need(lp);
  const reg = await readBondRegistry(ctx.client, ctx.registry);
  const b = await readBond(ctx.client, reg, who);
  const checks = [
    ...registryChecks(reg),
    { ok: b.amount > 0n, text: b.amount > 0n ? `bonded with ${movva(b.amount)}` : 'no bond to add to: bond:join with at least the minimum (NotBonded)' },
    { ok: b.exitRequestedAt === 0n, text: b.exitRequestedAt === 0n ? 'not leaving' : 'leaving: a bond cannot grow during the exit (Exiting)' },
    { ok: amount > 0n, text: amount > 0n ? `adds ${movva(amount)}` : 'nothing to add (ZeroAmount)' },
    { ok: b.balance >= amount, text: b.balance >= amount ? `the wallet holds ${movva(b.balance)}` : `the wallet holds only ${movva(b.balance)}` },
  ];
  return finish({
    command: 'bond:topup', lp: who, what: `${who} adds ${movva(amount)}: credit ${reais(b.capCents)} -> ${reais((b.amount + amount) / 10n ** 16n)}`,
    risk: 'more credit, all of it at risk to a lost dispute', facts: bondFacts(reg, b), checks, warnings: [SLASH_WARNING],
    txs: withAllowance(reg, b, amount, tx(ctx.registry, BOND_REGISTRY_ABI, 'topUp', [amount])), confirm: who,
  });
}

/** `bond:exit`: credit to zero now; the bond is withdrawable after the unbonding period, once nothing is live. */
export async function planExit(ctx: BondCtx, _argv: string[], lp: Address | undefined): Promise<BondPlan> {
  const who = need(lp);
  const reg = await readBondRegistry(ctx.client, ctx.registry);
  const b = await readBond(ctx.client, reg, who);
  const from = BigInt(ctx.now) + reg.unbondingSeconds;
  const checks = [
    { ok: b.amount > 0n, text: b.amount > 0n ? `bonded with ${movva(b.amount)}` : 'nothing bonded (NotBonded)' },
    { ok: b.exitRequestedAt === 0n, text: b.exitRequestedAt === 0n ? 'not leaving yet' : `already leaving since ${iso(b.exitRequestedAt)} (Exiting)` },
  ];
  const warnings = [
    'your credit is 0 from this block: no new order, sale or offer, and ANYONE may close your standing offers (the liquidity goes to you)',
    `the bond is withdrawable from ${iso(from)} if sent now (${days(reg.unbondingSeconds)}), and only once nothing is live; until then a lost dispute still takes it`,
    'there is no cancelling an exit: to come back, withdraw and join again',
  ];
  if (b.exposureCents > 0n) warnings.push(`${reais(b.exposureCents)} is live now: it must settle, expire or be closed before you can withdraw`);
  return finish({
    command: 'bond:exit', lp: who, what: `${who} asks to leave`, risk: 'immediate: stops new business; live positions run off',
    facts: bondFacts(reg, b), checks, warnings, txs: [tx(ctx.registry, BOND_REGISTRY_ABI, 'requestExit', [])], confirm: who,
  });
}

/** `bond:withdraw`: take the bond back after the unbonding period, with nothing live. */
export async function planWithdraw(ctx: BondCtx, _argv: string[], lp: Address | undefined): Promise<BondPlan> {
  const who = need(lp);
  const reg = await readBondRegistry(ctx.client, ctx.registry);
  const b = await readBond(ctx.client, reg, who);
  const now = BigInt(ctx.now);
  const exiting = b.exitRequestedAt !== 0n;
  const checks = [
    { ok: exiting, text: exiting ? `leaving since ${iso(b.exitRequestedAt)}` : 'not leaving: bond:exit first (NotExiting)' },
    ...(exiting ? [{ ok: now >= b.withdrawableFrom, text: now >= b.withdrawableFrom ? `unbonded since ${iso(b.withdrawableFrom)}` : `still unbonding until ${iso(b.withdrawableFrom)} (in ${days(b.withdrawableFrom - now)}) (StillUnbonding)` }] : []),
    { ok: b.exposureCents === 0n, text: b.exposureCents === 0n ? 'nothing live' : `${reais(b.exposureCents)} is still live: close your offers and let orders and sales end first (ExposureLive)` },
  ];
  const warnings = b.amount === 0n && exiting ? ['the bond is empty (a lost dispute took it): this only ends the exit, so the address can join again'] : [];
  return finish({
    command: 'bond:withdraw', lp: who, what: `${who} withdraws ${movva(b.amount)}`, risk: 'none: the LP leaves the registry',
    facts: bondFacts(reg, b), checks, warnings, txs: [tx(ctx.registry, BOND_REGISTRY_ABI, 'withdraw', [])], confirm: who,
  });
}

/** `bond:status [lp]`: the registry's parameters and trust facts, and one LP's bond. */
export async function bondStatus(ctx: BondCtx, lp: Address | undefined): Promise<{ registry: BondRegistryReading; bond?: BondReading }> {
  const registry = await readBondRegistry(ctx.client, ctx.registry);
  return { registry, ...(lp ? { bond: await readBond(ctx.client, registry, lp) } : {}) };
}

export function renderBondStatus(s: { registry: BondRegistryReading; bond?: BondReading }): string {
  const g = s.registry;
  const L = [
    `PermissionlessLPRegistry ${g.registry}: no owner, no governor, no pause (setup ${g.escrowsBound ? 'CLOSED: escrows bound for good' : `OPEN: deployer ${g.deployer} has not bound the escrows`})`,
    `  bond token ${g.movva}; minimum bond ${movva(g.minBond)}; credit = bond (R$ 1,00 per MOVVA); a lost dispute takes the whole bond`,
    `  unbonding ${days(g.unbondingSeconds)} (dispute window + ruling delay ${days(g.rulingDelaySeconds)} + margin ${days(g.marginSeconds)} must be shorter)`,
    `  predecessor ${isAddressEqual(g.predecessor, ZERO) ? 'none' : g.predecessor} (its spent bank transaction ids stay spent here)`,
    `  bonded ${movva(g.totalBonded)}; slashed and locked for ever ${movva(g.totalSlashed)}`,
  ];
  for (const e of g.escrows) {
    const window = e.disputeTimeout + g.rulingDelaySeconds + g.marginSeconds;
    L.push(`  ${e.role} ${e.address}: ${e.pointsBack ? 'names this registry' : 'DOES NOT name this registry'}; dispute timeout ${days(e.disputeTimeout)}; window ${days(window)} ${window < g.unbondingSeconds ? '<' : '>='} unbonding`);
  }
  if (s.bond) L.push('', ...bondFacts(g, s.bond));
  return L.join('\n');
}

export function renderBondPlan(p: BondPlan): string {
  const L = [`\n${p.what}`, `  risk      ${p.risk}`];
  for (const f of p.facts) L.push(`  now       ${f}`);
  for (const c of p.checks) L.push(`  ${c.ok ? 'check ok ' : 'REFUSED  '} ${c.text}`);
  for (const w of p.warnings) L.push(`  WARNING   ${w}`);
  if (p.refused) {
    L.push('\nREFUSED - nothing printed to send: the registry would revert, or the call is not safe to make.');
    return L.join('\n');
  }
  L.push(`  role      the LP itself (${p.lp}), LP_KEY`);
  p.txs.forEach((t, i) => {
    L.push(`  tx ${i + 1}      ${t.fn}(${t.args.map(String).join(', ')}) on ${t.to}`);
    L.push(`  calldata  ${t.data}`);
  });
  L.push('');
  for (const t of p.txs) L.push(`  cast send ${t.to} "${t.signature}" ${t.args.map(String).join(' ')} --rpc-url $RPC_URL --private-key $LP_KEY`);
  return L.join('\n');
}

/** Why `--execute` must not send this plan, or undefined when it may. */
export function bondSendRefusal(p: BondPlan, o: { key?: string; confirm?: string; signer?: Address }): string | undefined {
  if (p.refused) return 'the plan is refused (see above)';
  if (!p.txs.length) return 'nothing to send';
  if (!o.key) return 'LP_KEY is not set; refusing to execute';
  if (!o.confirm) return `--execute needs --confirm ${p.confirm} (the LP's address), to send it`;
  if (o.confirm.toLowerCase() !== p.confirm.toLowerCase()) return `--confirm ${o.confirm} does not name the LP (${p.confirm}); refusing`;
  if (o.signer && !isAddressEqual(o.signer, p.lp)) return `LP_KEY is ${o.signer}, not the LP ${p.lp}: a bond is only ever its own key's`;
  return undefined;
}

function need(lp: Address | undefined): Address {
  if (!lp) throw new BondUsageError('which LP? pass --from <lp> for a dry run, or set LP_KEY');
  return lp;
}

export const BOND_PLANNERS: Record<string, (ctx: BondCtx, argv: string[], lp: Address | undefined) => Promise<BondPlan>> = {
  'bond:join': planJoin,
  'bond:topup': planTopUp,
  'bond:exit': planExit,
  'bond:withdraw': planWithdraw,
};
export const BOND_COMMANDS = [...Object.keys(BOND_PLANNERS), 'bond:status'];

export const BOND_HELP: [string, string, string][] = [
  ['bond:status', '[lp] --registry <permissionless registry>', 'the registry\'s parameters, its escrows and whether they point back, and one LP\'s bond, credit and exit'],
  ['bond:join', '<amountMOVVA> --registry <addr> [--from <lp>]', 'bond at least MIN_BOND and take that much credit (approve, then join) - LP_KEY'],
  ['bond:topup', '<amountMOVVA> --registry <addr> [--from <lp>]', 'add to a bond (approve, then topUp) - LP_KEY'],
  ['bond:exit', '--registry <addr> [--from <lp>]', 'credit to 0 now; bond withdrawable after UNBONDING_PERIOD, once nothing is live - LP_KEY'],
  ['bond:withdraw', '--registry <addr> [--from <lp>]', 'take the bond back after the unbonding period - LP_KEY'],
];
