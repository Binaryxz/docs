import { createHash } from 'node:crypto';

/**
 * The canonical association-set CID (SRM1-14).
 *
 * `AspRootQuorum` counts a vote under the exact `(round, root, ipfsCID)`, so two honest ASPs that agree on the
 * root but write the CID differently - CIDv0 against CIDv1, another chunker, another multibase, upper case - never
 * reach a quorum. This is the one procedure every ASP follows, so that agreeing on the set means agreeing on
 * the string, byte for byte:
 *
 * 1. **The document.** `canonicalAssociationSet` writes the set as UTF-8 text, LF line endings, no blank lines,
 *    a final LF and nothing else:
 *
 *        movva-association-set/1
 *        chain-id <decimal, no leading zeros>
 *        entrypoint <0x + 40 lower-case hex>
 *        root <0x + 64 lower-case hex>
 *        count <decimal: the number of label lines>
 *        <label: 0x + 64 lower-case hex>        one line per label, in insertion order
 *
 *    The labels are in the order they were inserted into the association-set LeanIMT: the order fixes the
 *    root, so it is part of the set. A label appears once. Every value is a BN254 field element.
 * 2. **The CID.** `aspCid` is CIDv1, multicodec `raw` (0x55), multihash `sha2-256` (0x12, 32 bytes), multibase
 *    base32 lower case without padding (prefix `b`): always 59 characters starting `bafkrei`, inside the
 *    Entrypoint's 32-64. It is computed from the document's bytes here, never read back from an IPFS client,
 *    whose defaults (CIDv0, dag-pb chunking, raw leaves or not) are exactly what differs between ASPs.
 * 3. **Publishing.** Pin the document as ONE raw block (`ipfs block put --cid-codec raw --mhtype sha2-256`, or a
 *    pinning service's raw-block upload) and check the CID it reports equals `aspCid`. Not `ipfs add`: that
 *    wraps files above its chunk size in dag-pb and yields another CID. A raw block is at most 1 MiB by
 *    default (2 MiB with `--allow-big-block`), about 13,000 labels; beyond that this format needs a v2.
 * 4. **Voting.** Before voting, each ASP rebuilds the root from the labels with its own LeanIMT (pass it as
 *    `rootOf` to have this refuse a mismatch), then votes `AspRootQuorum.vote(root, associationSetCid(set))`.
 */

/** The BN254 scalar field: Privacy Pools labels and roots are elements of it. */
export const SNARK_SCALAR_FIELD = 21888242871839275222246405745257275088548364400416034343698204186575808495617n;

export const ASSOCIATION_SET_FORMAT = 'movva-association-set/1';

export interface AssociationSet {
  chainId: bigint | number;
  /** The Entrypoint the root is posted to. Any case; it is written lower case. */
  entrypoint: string;
  /** The LeanIMT root over `labels`, as posted. */
  root: bigint;
  /** Approved labels, in insertion order. */
  labels: readonly bigint[];
}

export class AspCidRefused extends Error {}

const hex32 = (v: bigint): string => `0x${v.toString(16).padStart(64, '0')}`;

function fieldElement(v: bigint, what: string): bigint {
  if (typeof v !== 'bigint') throw new AspCidRefused(`${what} must be a bigint`);
  if (v < 0n || v >= SNARK_SCALAR_FIELD) throw new AspCidRefused(`${what} is not a BN254 field element`);
  return v;
}

/** The canonical document for an association set: the exact bytes every ASP hashes. */
export function canonicalAssociationSet(set: AssociationSet, rootOf?: (labels: readonly bigint[]) => bigint): Uint8Array {
  const chainId = typeof set.chainId === 'number' ? BigInt(set.chainId) : set.chainId;
  if (typeof chainId !== 'bigint' || chainId <= 0n) throw new AspCidRefused('chain id must be a positive integer');
  if (!/^0x[0-9a-fA-F]{40}$/.test(set.entrypoint)) throw new AspCidRefused('entrypoint must be a 20-byte hex address');
  const root = fieldElement(set.root, 'root');
  if (root === 0n) throw new AspCidRefused('root must not be zero (the Entrypoint refuses it)');
  if (set.labels.length === 0) throw new AspCidRefused('an association set has at least one label');
  const seen = new Set<bigint>();
  const lines = [
    ASSOCIATION_SET_FORMAT,
    `chain-id ${chainId.toString(10)}`,
    `entrypoint ${set.entrypoint.toLowerCase()}`,
    `root ${hex32(root)}`,
    `count ${set.labels.length}`,
  ];
  for (const [i, label] of set.labels.entries()) {
    fieldElement(label, `label ${i}`);
    if (seen.has(label)) throw new AspCidRefused(`label ${i} appears twice`);
    seen.add(label);
    lines.push(hex32(label));
  }
  if (rootOf && rootOf(set.labels) !== root) throw new AspCidRefused('the labels do not rebuild the root');
  return new TextEncoder().encode(`${lines.join('\n')}\n`);
}

const BASE32 = 'abcdefghijklmnopqrstuvwxyz234567';

/** RFC 4648 base32, lower case, no padding: multibase `b` without its prefix. */
function base32(bytes: Uint8Array): string {
  let out = '';
  let buffer = 0;
  let bits = 0;
  for (const b of bytes) {
    buffer = (buffer << 8) | b;
    bits += 8;
    while (bits >= 5) {
      out += BASE32[(buffer >>> (bits - 5)) & 31];
      bits -= 5;
    }
    buffer &= (1 << bits) - 1;
  }
  if (bits > 0) out += BASE32[(buffer << (5 - bits)) & 31];
  return out;
}

/** CIDv1, raw codec, sha2-256, base32 lower case: the CID of `bytes` as one raw IPFS block. */
export function aspCid(bytes: Uint8Array): string {
  const digest = createHash('sha256').update(bytes).digest();
  const cid = new Uint8Array(4 + digest.length);
  cid.set([0x01, 0x55, 0x12, 0x20]);
  cid.set(digest, 4);
  return `b${base32(cid)}`;
}

/** The CID an ASP votes for: `aspCid(canonicalAssociationSet(set))`. */
export function associationSetCid(set: AssociationSet, rootOf?: (labels: readonly bigint[]) => bigint): string {
  return aspCid(canonicalAssociationSet(set, rootOf));
}

/** True for a string of the canonical CID form (it says nothing about which document it names). */
export function isCanonicalAspCid(cid: string): boolean {
  return /^bafkrei[a-z2-7]{52}$/.test(cid);
}
