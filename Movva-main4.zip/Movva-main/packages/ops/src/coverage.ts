/**
 * `reserve_coverage`: MOVVA's live coverage, as Movva publishes it (docs/delta-neutral.md §12.9).
 *
 * The client's ask, after Ethena: a live coverage ratio, the delta-neutral position reported separately, and Movva
 * committing to top up before coverage falls below 100%. So, from ONE block-pinned read (`readReconciliation`, the same
 * read `hedge-sleeve reconcile` makes) and the same sums (`reconcile`):
 *
 *  - **coverage**: MovvaReserve's own ratio, `totalUsdt()` (idle and in its yield vault) over MOVVA's supply at the
 *    reserve's rate - the backing, and the only figure any coverage ratio here counts;
 *  - **the principal-locked reserve** (client rule, 21 October 2026): its principal, the yield harvestable now (only to
 *    Mova's yield recipient, only above max(principal, the target's liabilities)) and that recipient;
 *  - **Movva's own capital, separately**: the hedge-treasury Safe, the sub-wallet's idle USDT, its equity at the trading
 *    venue (cash and margin) and its spot leg at the venue's mark. It is NOT backing - the reserve cannot fund it and
 *    nothing here adds it to a coverage figure - and it is reported beside the reserve so a reader sees both;
 *  - **the top-up Movva owes** for the reserve to stand at 100%, and at the top-up point.
 *
 * Without a sub-wallet the read is the reserve alone: Movva's capital is the hedge-treasury Safe's balance when one is
 * named (`hedgeSafe`), and every sub-wallet and venue figure is 0.
 *
 * ## Levels
 *
 *  - `ok` at or above the reserve's target ratio (`targetCollateralRatioBps`, 108%); between the top-up point and the
 *    target it is still `ok`, and the detail says it is under target (`movva_collateral_ratio` warns there);
 *  - `warn` below the top-up point - `topUpThresholdBps`, default `DEFAULT_TOP_UP_THRESHOLD_BPS` (103%, the withdraw
 *    floor the reserve had before the principal-locked rule, kept as Movva's policy): where its commitment says to
 *    top up, before 100% is near;
 *  - `fail` below 100% on-chain: under-backed, a redemption pays its pro-rata share and not R$ 1,00.
 *
 * ## A stale rate
 *
 * The reserve refuses to price itself (`StaleRate`) once the FX leg is older than its max age - every night and weekend,
 * by design. Then the figures are the reserve's own arithmetic on the LAST POSTED rate (`readReconciliation`'s
 * fallback), and the report says so: `rate.stale`, the posting time and its age, and a detail that opens with STALE.
 * The level is judged on those figures - a stale reading is never presented as a live `ok` - and a last posting older
 * than `staleWarnSeconds` (default four days, PythFxOracle's MAX_CLOSED_MAX_AGE) warns on its own.
 *
 * Read-only: `eth_call`s pinned to one block, nothing signed or sent.
 */
import { getAddress, type Address, type PublicClient } from 'viem';
import type { CheckResult, Level } from './checks.js';
import { readReconciliation, reconcile, type OnchainLimits, type ReconInputs, type ReconRate, type Reconciliation, type SleeveClient } from './hedge-sleeve.js';
import { redact, redactError } from './redact.js';

export const RESERVE_COVERAGE_CHECK_ID = 'reserve_coverage';
/** 2: the hedge path became `movvaCapital` (not backing), `combined` was removed and `principal` added (21 October 2026). */
export const COVERAGE_SCHEMA = 'movva-coverage/2';
/** Where Movva's commitment says to top up, by default: 103%, the reserve's withdraw floor before the principal-locked rule. */
export const DEFAULT_TOP_UP_THRESHOLD_BPS = 10_300;

const BPS = 10_000n;

export interface CoverageThresholds {
  /** Below this on-chain ratio Movva's commitment says to top up: `warn`. Default `DEFAULT_TOP_UP_THRESHOLD_BPS`. */
  topUpThresholdBps?: number;
  /** A last-posted rate older than this warns on its own. Default 4 days. */
  staleWarnSeconds: number;
}

export const DEFAULT_COVERAGE_THRESHOLDS: CoverageThresholds = { staleWarnSeconds: 4 * 24 * 3600 };

/** Where coverage stands against the commitment. */
export type CoverageState = 'no-supply' | 'at-or-above-target' | 'below-target' | 'top-up-due' | 'under-backed';

/**
 * The published coverage report. Amounts are decimal strings in the stablecoin's units (USDT, 6 decimals) or in reais;
 * ratios are basis points (`null` with no MOVVA in circulation) and, beside them, percentages as text.
 */
export interface CoverageReport {
  schema: typeof COVERAGE_SCHEMA;
  chainId: number;
  reserve: Address;
  /** The sleeve's sub-wallet read with the reserve, or null for the reserve alone. */
  subWallet: Address | null;
  block: string;
  /** The block's own time, unix seconds and ISO: what "now" means for every figure here. */
  blockTimestamp: number;
  blockTime: string;
  /** When this report was produced (wall clock). */
  generatedAt: string;
  rate: {
    /** Reais per whole USDT, as MovvaReserve crosses its two legs. */
    brlPerUsdt: string;
    brlPerUsdtE18: string;
    /** 'reserve': the contract priced itself at this block. 'last-posted': it refused (stale FX leg); this is the last posted rate. */
    source: ReconRate['source'];
    stale: boolean;
    /** The FX leg's publish time, when the rate is the last posted one. */
    postedAt: string | null;
    ageSeconds: number | null;
  };
  liabilities: { brl: string; usdt: string };
  /** The backing: the reserve's USDT, idle and in its yield vault. The only coverage figure. */
  onchain: { usdt: string; ratioBps: number | null; ratio: string | null };
  /**
   * The principal-locked reserve: its cost basis, the yield `harvestYield` would pay now (null while the reserve refuses
   * to price) and the only address it pays. Null for a reserve built before the rule.
   */
  principal: { usdt: string; harvestableYield: string | null; yieldRecipient: Address | null } | null;
  /** Movva's own capital on the hedge path. NOT backing: never added to any coverage figure. */
  movvaCapital: {
    backing: false;
    /** True when a sub-wallet was read; false: the hedge-treasury Safe alone (when named). */
    subWalletRead: boolean;
    hedgeSafe: string;
    subWalletIdle: string;
    venueCash: string;
    marginEquity: string;
    /** Cash plus margin equity at the trading venue. */
    venueEquity: string;
    spotAtMark: string;
    total: string;
    /** The sub-wallet's own value against what it was funded with, net of what it returned. */
    sleeve: { value: string; netFunded: string; result: string };
  };
  topUp: {
    /** USDT Movva would add (recapitalize) for the reserve to stand at 100%. */
    onchainFor100: string;
    /** USDT for the reserve to stand back at the top-up point. */
    onchainForTopUpPoint: string;
  };
  policy: {
    targetRatioBps: number;
    topUpThresholdBps: number;
    minMintRatioBps: number;
    commitment: string;
  };
  state: CoverageState;
}

const COMMITMENT = 'Movva commits to top up the reserve before its on-chain coverage falls below 100%: below the top-up point, it tops up.';

/** `x` base units as a decimal string with every decimal: 50009460000 -> "50009.460000". */
export function units(x: bigint, decimals: number): string {
  const neg = x < 0n;
  const a = neg ? -x : x;
  const d = 10n ** BigInt(decimals);
  const frac = decimals ? `.${(a % d).toString().padStart(decimals, '0')}` : '';
  return `${neg ? '-' : ''}${(a / d).toString()}${frac}`;
}

const pctOf = (bps: bigint) => `${(bps / 100n).toString()}.${(bps % 100n).toString().padStart(2, '0')}%`;
const pos = (x: bigint) => (x > 0n ? x : 0n);
const ceilDiv = (a: bigint, b: bigint) => (a + b - 1n) / b;

export interface CoverageReading {
  block: bigint;
  blockTimestamp: number;
  rate: ReconRate;
  inputs: ReconInputs;
  limits: OnchainLimits;
}

/** Pure: the report from one reading. `now` is the wall clock, unix seconds. */
export function coverageReport(
  read: CoverageReading,
  meta: { chainId: number; reserve: Address; subWallet?: Address; now: number; topUpThresholdBps?: number },
): CoverageReport {
  const i = read.inputs;
  const r: Reconciliation = reconcile(i);
  const dec = i.decimals;
  const u = (x: bigint) => units(x, dec);
  const supply = i.liabilitiesBrlE18 > 0n;
  const threshold = meta.topUpThresholdBps ?? DEFAULT_TOP_UP_THRESHOLD_BPS;
  const target = read.limits.reserve.targetRatioBps;
  const onchain = r.onchainRatioBps;
  const state: CoverageState = !supply ? 'no-supply'
    : onchain < BPS ? 'under-backed'
      : onchain < BigInt(threshold) ? 'top-up-due'
        : onchain < BigInt(target) ? 'below-target' : 'at-or-above-target';
  const stale = read.rate.source !== 'reserve';
  const postedAt = read.rate.fxPublishTime;
  return {
    schema: COVERAGE_SCHEMA,
    chainId: meta.chainId,
    reserve: meta.reserve,
    subWallet: meta.subWallet ?? null,
    block: read.block.toString(),
    blockTimestamp: read.blockTimestamp,
    blockTime: new Date(read.blockTimestamp * 1000).toISOString(),
    generatedAt: new Date(meta.now * 1000).toISOString(),
    rate: {
      brlPerUsdt: units(read.rate.brlPerUsdtE18, 18).replace(/0+$/, '').replace(/\.$/, ''),
      brlPerUsdtE18: read.rate.brlPerUsdtE18.toString(),
      source: read.rate.source,
      stale,
      postedAt: stale && postedAt !== undefined ? new Date(Number(postedAt) * 1000).toISOString() : null,
      ageSeconds: stale && postedAt !== undefined ? Math.max(0, read.blockTimestamp - Number(postedAt)) : null,
    },
    liabilities: { brl: units(i.liabilitiesBrlE18 / 10n ** 16n, 2), usdt: u(r.liabilitiesUsdt) },
    onchain: { usdt: u(r.inReserve), ratioBps: supply ? Number(onchain) : null, ratio: supply ? pctOf(onchain) : null },
    principal: r.principal
      ? {
        usdt: u(r.principal.usdt),
        harvestableYield: r.principal.harvestableYield === undefined ? null : u(r.principal.harvestableYield),
        yieldRecipient: read.limits.reserve.yieldRecipient ?? null,
      }
      : null,
    movvaCapital: {
      backing: false,
      subWalletRead: meta.subWallet !== undefined,
      hedgeSafe: u(r.movvaCapital.hedgeSafe),
      subWalletIdle: u(r.movvaCapital.subWalletIdle),
      venueCash: u(r.movvaCapital.venueCash),
      marginEquity: u(r.movvaCapital.marginEquity),
      venueEquity: u(r.movvaCapital.venueCash + r.movvaCapital.marginEquity),
      spotAtMark: u(r.movvaCapital.spotValue),
      total: u(r.movvaCapital.total),
      sleeve: { value: u(r.sleeve.value), netFunded: u(r.sleeve.netFunded), result: u(r.sleeve.pnl) },
    },
    topUp: {
      onchainFor100: u(r.onchainShortfall),
      onchainForTopUpPoint: u(pos(ceilDiv(r.liabilitiesUsdt * BigInt(threshold), BPS) - r.inReserve)),
    },
    policy: {
      targetRatioBps: target,
      topUpThresholdBps: threshold,
      minMintRatioBps: read.limits.reserve.minMintRatioBps,
      commitment: COMMITMENT,
    },
    state,
  };
}

const RANK: Level[] = ['ok', 'unknown', 'warn', 'fail'];
const worse = (a: Level, b: Level): Level => (RANK.indexOf(b) > RANK.indexOf(a) ? b : a);
const usdt = (s: string) => `${Number(s).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USDT`;
const pctBps = (bps: number) => `${(bps / 100).toFixed(2)}%`;
const age = (s: number) => (s >= 3600 ? `${(s / 3600).toFixed(1)} h` : `${s} s`);

/** The verdict on one report. Pure: the monitor and the tests share it. */
export function judgeCoverage(rep: CoverageReport, th: CoverageThresholds = DEFAULT_COVERAGE_THRESHOLDS): CheckResult {
  const p = rep.policy;
  const h = rep.movvaCapital;
  const stale = rep.rate.stale
    ? `STALE: the reserve refuses to price itself (FX market closed?), so these are its figures at the last posted rate, R$ ${rep.rate.brlPerUsdt} per USDT`
      + `${rep.rate.postedAt ? ` (posted ${rep.rate.postedAt}, ${age(rep.rate.ageSeconds ?? 0)} before this block)` : ''}; `
    : '';
  const path = `Movva's own hedge capital ${usdt(h.total)}, reported separately and NOT backing (hedge Safe ${usdt(h.hedgeSafe)}`
    + (h.subWalletRead ? `, sub-wallet ${usdt(h.subWalletIdle)}, venue equity ${usdt(h.venueEquity)}, spot at mark ${usdt(h.spotAtMark)})` : '; no sub-wallet configured)');
  const pr = rep.principal;
  const locked = pr
    ? `; principal ${usdt(pr.usdt)} (locked: it leaves only by redemption), harvestable yield ${pr.harvestableYield === null ? 'n/a while the rate is stale' : usdt(pr.harvestableYield)}`
    : '; this reserve predates the principal-locked rule (no principalUsdt())';
  if (rep.state === 'no-supply') {
    return {
      id: RESERVE_COVERAGE_CHECK_ID, level: 'ok', threshold: p.topUpThresholdBps,
      detail: `${stale}no MOVVA in circulation: the reserve holds ${usdt(rep.onchain.usdt)} against nothing owed${locked}; ${path}`,
    };
  }
  const onchain = rep.onchain.ratioBps!;
  let level: Level = rep.state === 'under-backed' ? 'fail' : rep.state === 'top-up-due' ? 'warn' : 'ok';
  const head = rep.state === 'under-backed'
    ? `MOVVA is UNDER-BACKED on-chain at ${rep.onchain.ratio}: a redemption pays its pro-rata share, not R$ 1,00. Movva owes ${usdt(rep.topUp.onchainFor100)} to restore 100% now`
    : rep.state === 'top-up-due'
      ? `on-chain coverage ${rep.onchain.ratio} is below the ${pctBps(p.topUpThresholdBps)} top-up point: Movva's commitment says top up now (${usdt(rep.topUp.onchainForTopUpPoint)} back to ${pctBps(p.topUpThresholdBps)})`
      : rep.state === 'below-target'
        ? `on-chain coverage ${rep.onchain.ratio}, under the ${pctBps(p.targetRatioBps)} target but above the ${pctBps(p.topUpThresholdBps)} top-up point`
        : `on-chain coverage ${rep.onchain.ratio} (target ${pctBps(p.targetRatioBps)}, top-up point ${pctBps(p.topUpThresholdBps)})`;
  const notes: string[] = [];
  if (rep.rate.stale && rep.rate.ageSeconds !== null && rep.rate.ageSeconds > th.staleWarnSeconds) {
    level = worse(level, 'warn');
    notes.push(`the last posted rate is ${age(rep.rate.ageSeconds)} old, past ${age(th.staleWarnSeconds)}: see movva_rate and the Pyth keeper`);
  }
  return {
    id: RESERVE_COVERAGE_CHECK_ID, level, value: onchain, threshold: p.topUpThresholdBps,
    detail: `${stale}${head}${locked}; ${path}; top-up owed for 100%: ${usdt(rep.topUp.onchainFor100)}${notes.length ? `; ${notes.join('; ')}` : ''}`,
  };
}

export interface CoverageTargets {
  client: SleeveClient & Pick<PublicClient, 'getBlockNumber'>;
  chainId: number;
  reserve: Address;
  /** The sleeve's HedgeSubWallet; omitted, the reserve alone. */
  subWallet?: Address;
  /** Without a sub-wallet: the hedge-treasury Safe whose balance is reported as Movva's capital. */
  hedgeSafe?: Address;
}

/**
 * The sub-wallet a hedge-sleeve deployment record names (scripts/deploy-hedge-sleeve.ts writes `contracts.reserve` and
 * `contracts.subWallet`), refused when the record is for another reserve: a sleeve reported beside the wrong reserve
 * would misstate Movva's capital next to it.
 */
export function subWalletFromRecord(record: unknown, reserve: Address): Address | undefined {
  const c = (record as { contracts?: { reserve?: unknown; subWallet?: unknown } } | null)?.contracts;
  if (!c || typeof c.reserve !== 'string') throw new Error('not a hedge-sleeve record: no contracts.reserve');
  if (c.reserve.toLowerCase() !== reserve.toLowerCase()) throw new Error(`the record's sleeve is on reserve ${c.reserve}, not ${reserve}`);
  if (c.subWallet === undefined) return undefined;
  if (typeof c.subWallet !== 'string' || !/^0x[0-9a-fA-F]{40}$/.test(c.subWallet)) throw new Error('contracts.subWallet is not an address');
  return getAddress(c.subWallet);
}

/** One block-pinned read, with that block's time. A failed read throws. */
export async function readCoverage(t: CoverageTargets, opts: { now?: number; topUpThresholdBps?: number } = {}): Promise<CoverageReport> {
  const read = await readReconciliation({ client: t.client, addresses: { reserve: t.reserve, wallet: t.subWallet, hedgeSafe: t.hedgeSafe } });
  const block = await t.client.getBlock({ blockNumber: read.block });
  return coverageReport({ ...read, blockTimestamp: Number(block.timestamp) }, {
    chainId: t.chainId, reserve: t.reserve, subWallet: t.subWallet, now: opts.now ?? Math.floor(Date.now() / 1000), topUpThresholdBps: opts.topUpThresholdBps,
  });
}

/** The report as an operator reads it in a terminal. */
export function renderCoverage(rep: CoverageReport): string {
  const h = rep.movvaCapital;
  const pr = rep.principal;
  return [
    `MOVVA coverage at block ${rep.block} (${rep.blockTime}), chain ${rep.chainId}`,
    rep.rate.stale
      ? `  rate R$ ${rep.rate.brlPerUsdt} per USDT - STALE: the last posted FX rate (${rep.rate.postedAt ?? '?'}), crossed as the reserve would`
      : `  rate R$ ${rep.rate.brlPerUsdt} per USDT (the reserve's own)`,
    `  owed to MOVVA holders   R$ ${rep.liabilities.brl} = ${usdt(rep.liabilities.usdt)}`,
    `  coverage                ${rep.onchain.ratio ?? 'n/a'}   (${usdt(rep.onchain.usdt)} in the reserve, idle and in its yield vault: the backing)`,
    pr
      ? `  principal (locked)      ${usdt(pr.usdt)}; harvestable yield ${pr.harvestableYield === null ? 'n/a (stale rate)' : usdt(pr.harvestableYield)}, paid only to ${pr.yieldRecipient ?? '?'}`
      : '  principal               n/a: this reserve predates the principal-locked rule',
    `  Movva's hedge capital   ${usdt(h.total)} - NOT backing, not in the coverage: hedge Safe ${usdt(h.hedgeSafe)}${h.subWalletRead ? `, sub-wallet ${usdt(h.subWalletIdle)}, venue equity ${usdt(h.venueEquity)}, spot at mark ${usdt(h.spotAtMark)}` : ' (no sub-wallet read)'}`,
    `  top-up owed for 100%    ${usdt(rep.topUp.onchainFor100)}`,
    `  policy                  target ${pctBps(rep.policy.targetRatioBps)}, top-up point ${pctBps(rep.policy.topUpThresholdBps)}; state: ${rep.state}`,
  ].join('\n');
}

/** `reserve_coverage` across sweeps: the check, and the last report for `/status` and `/coverage`. */
export class ReserveCoverageMonitor {
  last?: CoverageReport;
  lastError?: string;

  constructor(private readonly o: CoverageTargets & {
    thresholds?: Partial<CoverageThresholds>;
    redactValues?: readonly (string | undefined)[];
    now?: () => number;
  }) {}

  async check(): Promise<CheckResult> {
    const th: CoverageThresholds = { ...DEFAULT_COVERAGE_THRESHOLDS, ...Object.fromEntries(Object.entries(this.o.thresholds ?? {}).filter(([, v]) => v !== undefined)) };
    let rep: CoverageReport;
    try {
      rep = await readCoverage(this.o, { now: this.o.now?.(), topUpThresholdBps: th.topUpThresholdBps });
    } catch (e) {
      this.lastError = redactError(e, this.o.redactValues);
      return { id: RESERVE_COVERAGE_CHECK_ID, level: 'unknown', detail: `could not be read: ${this.lastError}` };
    }
    this.last = rep;
    this.lastError = undefined;
    const r = judgeCoverage(rep, th);
    return { ...r, detail: redact(r.detail, this.o.redactValues) };
  }
}
