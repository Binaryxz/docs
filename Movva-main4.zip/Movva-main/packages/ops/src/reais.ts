/**
 * Centavos as reais. Its own module so `bond.ts` and `lp-network.ts` can both use it without importing each other:
 * `lp-network.ts` reads the permissionless registry through `bond.ts`, and `bond.ts` printed amounts with this.
 */

/** Centavos as reais, pt-BR: R$ 1.234,56. */
export function reais(cents: bigint): string {
  const neg = cents < 0n;
  const c = neg ? -cents : cents;
  const whole = (c / 100n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  return `${neg ? '-' : ''}R$ ${whole},${String(c % 100n).padStart(2, '0')}`;
}
