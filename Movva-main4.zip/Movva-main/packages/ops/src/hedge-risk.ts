/**
 * `hedge_risk`: Movva's delta-neutral hedge sleeve, judged by the venue-neutral risk engine.
 *
 * The sleeve is Movva's OWN capital, funded through the hedge Safe: since the principal-locked reserve (client rule,
 * 21 October 2026) MovvaReserve cannot fund it, and its allocation limit is the config's absolute caps
 * (`allocation.maxSleeveUsd`, per venue, per asset) - no longer a share of the reserve's `hedgeLimitBps()`, which is gone.
 * The reserve is not read here.
 *
 * Each sweep assembles a snapshot of every yield sub-wallet (`collectSnapshot`, which fails closed on
 * a venue it cannot read) and runs `evaluateSleeve` (packages/yield/src/hedge-risk). The check reports the engine's
 * verdict and names the worst limit:
 *
 *  - `ok`: every limit inside its warn bound; the detail names the limit closest to its bound;
 *  - `warn`: a limit past its warn bound, or a funding exit in progress;
 *  - `fail`: a limit past its fail bound, or a venue unreachable, stale or off its oracle (fail closed);
 *  - `unknown`: the sweep itself could not run (a bug or a dead config), not a venue outage - a venue
 *    the monitor cannot reach is the engine's `fail`, because the keeper would halt on it too.
 *
 * The funding regime (the hysteresis) is kept in this process across sweeps; after a restart the
 * engine starts in `hold`, which never unwinds on its own.
 *
 * The engine plans; nothing here executes. `status()` is the JSON summary - findings past their warn
 * bound, the ordered action plan a keeper would run, per-sub-wallet metrics and add permissions - and
 * `serveHedgeRiskStatus` serves it on `/status` for operators.
 *
 * Read-only, like the rest of the monitor: precompile `eth_call`s on HyperEVM, the public info API,
 * and views on Ethereum - including, for an `onchain-perps` venue, the `IHedgeVenue` contract and its
 * `HedgeSubWallet` accounts (on Sepolia, the TEST-ONLY `SimHedgeVenue`).
 */
import { createServer, type Server } from 'node:http';
import { createPublicClient, getAddress, http, type Address, type PublicClient } from 'viem';
import {
  HyperliquidVenue, OnchainHedgeVenue, collectSnapshot, evaluateSleeve, resolveRiskLimits, summarizeReport,
  type HedgeVenue, type HlMarketSpec, type OnchainMarketSpec, type ReferencePrice, type RiskLimits, type RiskLimitsInput,
  type RiskMemory, type RiskReport, type SleeveSnapshot, type SubWalletConfig,
} from '@mova/yield/src/hedge-risk/index.js';
import type { CheckResult, Level } from './checks.js';
import { redact, redactError } from './redact.js';

export const HEDGE_RISK_CHECK_ID = 'hedge_risk';

const usd = (x: number) => `$${Math.round(x).toLocaleString('en-US')}`;

/** The check a report maps to. Pure: the monitor and the tests share it. */
export function hedgeRiskResult(r: RiskReport): CheckResult {
  const w = r.worst;
  const kinds = new Map<string, number>();
  for (const a of r.actions) kinds.set(a.kind, (kinds.get(a.kind) ?? 0) + 1);
  const plan = kinds.size ? `plan: ${[...kinds].map(([k, n]) => `${n} ${k}`).join(', ')}` : 'no action planned';
  const size = `sleeve ${usd(r.sleeve.capitalUsd)} of Movva's own capital (cap ${usd(r.sleeve.capUsd)}) in ${r.wallets.length} sub-wallet(s)`;
  if (!w) return { id: HEDGE_RISK_CHECK_ID, level: 'ok', detail: `${size}; nothing to judge` };
  const head = r.level === 'ok'
    ? `all limits inside their bounds; closest: ${w.limit} at ${(Math.min(w.utilization, 9.99) * 100).toFixed(0)}% of its bound (${w.detail})`
    : `worst limit ${w.limit} [${w.level}]: ${w.detail}`;
  const others = r.findings.filter((f) => f.level !== 'ok').length - (r.level === 'ok' ? 0 : 1);
  return {
    id: HEDGE_RISK_CHECK_ID,
    level: r.level as Level,
    detail: `${head}${others > 0 ? `; ${others} more past a bound` : ''}; ${plan}; ${size}`,
    value: w.value !== undefined && Number.isFinite(w.value) ? w.value : undefined,
    threshold: w.threshold !== undefined && Number.isFinite(w.threshold) ? w.threshold : undefined,
  };
}

export interface HedgeRiskMonitorOptions {
  /** Assemble the current snapshot. Throwing makes the check `unknown`. */
  snapshot: () => Promise<SleeveSnapshot>;
  limits: RiskLimits;
  /** Values that must never appear in a detail or the status JSON. */
  redactValues?: readonly (string | undefined)[];
}

export class HedgeRiskMonitor {
  private memory: RiskMemory = { funding: {} };
  last?: RiskReport;
  lastError?: string;

  constructor(private readonly o: HedgeRiskMonitorOptions) {}

  /** One sweep: snapshot, evaluate, keep the regime, report. */
  async check(): Promise<CheckResult> {
    let snap: SleeveSnapshot;
    try {
      snap = await this.o.snapshot();
    } catch (e) {
      this.lastError = redactError(e, this.o.redactValues);
      return { id: HEDGE_RISK_CHECK_ID, level: 'unknown', detail: `could not assemble the sleeve snapshot: ${this.lastError}` };
    }
    const report = evaluateSleeve(snap, this.o.limits, this.memory);
    this.memory = report.memory;
    this.last = report;
    this.lastError = undefined;
    const r = hedgeRiskResult(report);
    return { ...r, detail: redact(r.detail, this.o.redactValues) };
  }

  /** The JSON summary of the last sweep (`/status`), redacted. */
  status(): unknown {
    if (!this.last) return { ready: false, error: this.lastError ?? null };
    const text = JSON.stringify(summarizeReport(this.last));
    return JSON.parse(redact(text, this.o.redactValues));
  }
}

/** Serve `/status` (the JSON summary) and `/healthz` for a HedgeRiskMonitor. */
export function serveHedgeRiskStatus(m: HedgeRiskMonitor): { server: Server; listen: (port?: number, host?: string) => Promise<number>; close: () => Promise<void> } {
  const server = createServer((rq, rs) => {
    const path = new URL(rq.url ?? '/', 'http://localhost').pathname;
    const json = (code: number, body: unknown) => {
      rs.writeHead(code, { 'content-type': 'application/json' });
      rs.end(JSON.stringify(body, null, 2));
    };
    if (path === '/healthz') return json(200, { ok: true });
    if (path === '/status') return json(m.last ? 200 : 503, m.status());
    return json(404, { error: 'not found', routes: ['/healthz', '/status'] });
  });
  return {
    server,
    listen: (port = 0, host?: string) => new Promise<number>((resolve) => {
      const done = () => {
        const a = server.address();
        resolve(typeof a === 'object' && a ? a.port : port);
      };
      // I-60: loopback unless a host is named (HOST).
      server.listen(port, host ?? '127.0.0.1', done);
    }),
    close: () => new Promise<void>((resolve) => server.close(() => resolve())),
  };
}

/*//////////////////////////////////////////////////////////////
                         READING ETHEREUM
//////////////////////////////////////////////////////////////*/

const AGGREGATOR_ABI = [
  { type: 'function', name: 'decimals', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint8' }] },
  {
    type: 'function', name: 'latestRoundData', stateMutability: 'view', inputs: [],
    outputs: [
      { name: 'roundId', type: 'uint80' }, { name: 'answer', type: 'int256' }, { name: 'startedAt', type: 'uint256' },
      { name: 'updatedAt', type: 'uint256' }, { name: 'answeredInRound', type: 'uint80' },
    ],
  },
] as const;

type Reader = Pick<PublicClient, 'readContract'>;

/** Independent reference prices from Chainlink-style aggregators, by asset. */
export function referenceReader(client: Reader, feeds: Record<string, Address>): () => Promise<Record<string, ReferencePrice>> {
  return async () => {
    const out: Record<string, ReferencePrice> = {};
    await Promise.all(Object.entries(feeds).map(async ([asset, feed]) => {
      const [decimals, round] = await Promise.all([
        client.readContract({ address: feed, abi: AGGREGATOR_ABI, functionName: 'decimals' }),
        client.readContract({ address: feed, abi: AGGREGATOR_ABI, functionName: 'latestRoundData' }),
      ]);
      const answer = round[1];
      if (answer <= 0n) throw new Error(`reference feed for ${asset} answered ${answer}`);
      out[asset] = { price: Number(answer) / 10 ** Number(decimals), time: Number(round[3]) * 1000 };
    }));
    return out;
  };
}

/*//////////////////////////////////////////////////////////////
                            CONFIG
//////////////////////////////////////////////////////////////*/

/**
 * HEDGE_RISK_CONFIG, a JSON file:
 *
 *   {
 *     "limits": { "margin": { "maxLeverage": 3 }, ... },        // RiskLimitsInput, merged over the defaults
 *     "venues": [{ "id": "hyperliquid", "kind": "hyperliquid", "markets": [HlMarketSpec, ...] },
 *                { "id": "sim-sepolia", "kind": "onchain-perps", "venue": "0x…", "stable": "0x…",
 *                  "markets": [{ "asset": "ETH", "id": "ETH" }] }],     // IHedgeVenue on RPC_URL
 *     "wallets": [{ "id": "hl-eth-1", "venue": "hyperliquid", "account": "0x…", "assets": ["ETH"] }],
 *     "reserve": "0x…",                                       // optional, recorded only: the sleeve is not sized from the reserve
 *     "referenceFeeds": { "ETH": "0x…" }                      // optional Chainlink-style feeds on RPC_URL
 *   }
 *
 * Two kinds have a reader: `hyperliquid` (the HyperCore precompiles on HYPEREVM_RPC_URL) and
 * `onchain-perps` (an `IHedgeVenue` contract on the monitor's own Ethereum client, whose accounts are
 * `HedgeSubWallet` contracts: a wallet's `account` is the sub-wallet's address). Any other kind is
 * refused rather than silently skipped, since a sub-wallet nobody reads is risk nobody sees.
 */
export type HedgeRiskVenueConfig =
  | { id: string; kind: 'hyperliquid'; markets: HlMarketSpec[] }
  | { id: string; kind: 'onchain-perps'; venue: Address; stable: Address; markets: OnchainMarketSpec[] };

export interface HedgeRiskConfig {
  limits: RiskLimits;
  venues: HedgeRiskVenueConfig[];
  wallets: SubWalletConfig[];
  reserve?: Address;
  referenceFeeds: Record<string, Address>;
}

export function parseHedgeRiskConfig(text: string): HedgeRiskConfig {
  let j: Record<string, unknown>;
  try {
    j = JSON.parse(text) as Record<string, unknown>;
  } catch (e) {
    throw new Error(`HEDGE_RISK_CONFIG is not JSON: ${e instanceof Error ? e.message : String(e)}`);
  }
  if (typeof j !== 'object' || j === null || Array.isArray(j)) throw new Error('HEDGE_RISK_CONFIG must be a JSON object');
  const known = new Set(['limits', 'venues', 'wallets', 'reserve', 'referenceFeeds']);
  for (const k of Object.keys(j)) if (!known.has(k)) throw new Error(`HEDGE_RISK_CONFIG: unknown key "${k}"`);
  const limits = resolveRiskLimits((j.limits ?? {}) as RiskLimitsInput);
  if (!Array.isArray(j.venues) || j.venues.length === 0) throw new Error('HEDGE_RISK_CONFIG: "venues" must list at least one venue');
  const venues = j.venues.map((v: Record<string, unknown>, i: number): HedgeRiskVenueConfig => {
    if (typeof v.id !== 'string' || !v.id) throw new Error(`HEDGE_RISK_CONFIG: venues[${i}].id is missing`);
    if (v.kind !== 'hyperliquid' && v.kind !== 'onchain-perps') {
      throw new Error(`HEDGE_RISK_CONFIG: venue "${v.id}" is of kind "${String(v.kind)}", which has no reader yet (only "hyperliquid" and "onchain-perps")`);
    }
    if (!Array.isArray(v.markets) || v.markets.length === 0) throw new Error(`HEDGE_RISK_CONFIG: venue "${v.id}" lists no markets`);
    if (v.kind === 'onchain-perps') {
      for (const f of ['venue', 'stable'] as const) {
        if (typeof v[f] !== 'string' || !/^0x[0-9a-fA-F]{40}$/.test(v[f] as string)) throw new Error(`HEDGE_RISK_CONFIG: venue "${v.id}".${f} must be an address`);
      }
      const markets = (v.markets as Record<string, unknown>[]).map((m, k) => {
        if (typeof m.asset !== 'string' || !m.asset) throw new Error(`HEDGE_RISK_CONFIG: venue "${v.id}" markets[${k}].asset is missing`);
        if (m.id !== undefined && (typeof m.id !== 'string' || !m.id || new TextEncoder().encode(m.id).length > 32)) {
          throw new Error(`HEDGE_RISK_CONFIG: venue "${v.id}" markets[${k}].id must be a label of at most 32 bytes`);
        }
        return { asset: m.asset, ...(m.id !== undefined ? { id: m.id as string } : {}) };
      });
      return { id: v.id, kind: 'onchain-perps', venue: getAddress(v.venue as string), stable: getAddress(v.stable as string), markets };
    }
    const markets = (v.markets as Record<string, unknown>[]).map((m, k) => {
      for (const f of ['perp', 'spotMarket', 'spotToken', 'perpSzDecimals', 'spotSzDecimals', 'spotWeiDecimals', 'maxLeverage'] as const) {
        if (typeof m[f] !== 'number' || !Number.isInteger(m[f]) || (m[f] as number) < 0) {
          throw new Error(`HEDGE_RISK_CONFIG: venue "${v.id}" markets[${k}].${f} must be a non-negative integer`);
        }
      }
      if (typeof m.asset !== 'string' || !m.asset) throw new Error(`HEDGE_RISK_CONFIG: venue "${v.id}" markets[${k}].asset is missing`);
      if ((m.maxLeverage as number) < 1) throw new Error(`HEDGE_RISK_CONFIG: venue "${v.id}" markets[${k}].maxLeverage must be at least 1`);
      return m as unknown as HlMarketSpec;
    });
    return { id: v.id, kind: 'hyperliquid', markets };
  });
  if (!Array.isArray(j.wallets) || j.wallets.length === 0) throw new Error('HEDGE_RISK_CONFIG: "wallets" must list at least one sub-wallet');
  const ids = new Set<string>();
  const wallets = j.wallets.map((w: Record<string, unknown>, i: number) => {
    if (typeof w.id !== 'string' || !w.id) throw new Error(`HEDGE_RISK_CONFIG: wallets[${i}].id is missing`);
    if (ids.has(w.id)) throw new Error(`HEDGE_RISK_CONFIG: sub-wallet "${w.id}" is listed twice`);
    ids.add(w.id);
    const venue = venues.find((v) => v.id === w.venue);
    if (!venue) throw new Error(`HEDGE_RISK_CONFIG: sub-wallet "${w.id}" names venue "${String(w.venue)}", which is not configured`);
    if (typeof w.account !== 'string') throw new Error(`HEDGE_RISK_CONFIG: sub-wallet "${w.id}" has no account`);
    const account = getAddress(w.account);
    if (!Array.isArray(w.assets) || w.assets.length === 0 || !w.assets.every((a) => typeof a === 'string')) {
      throw new Error(`HEDGE_RISK_CONFIG: sub-wallet "${w.id}" must list its assets`);
    }
    for (const a of w.assets as string[]) {
      if (!venue.markets.some((m) => m.asset === a)) throw new Error(`HEDGE_RISK_CONFIG: sub-wallet "${w.id}" trades ${a}, which venue "${venue.id}" has no market for`);
    }
    return { id: w.id, venue: venue.id, account, assets: w.assets as string[] };
  });
  const feeds: Record<string, Address> = {};
  if (j.referenceFeeds !== undefined) {
    if (typeof j.referenceFeeds !== 'object' || j.referenceFeeds === null) throw new Error('HEDGE_RISK_CONFIG: "referenceFeeds" must map assets to feed addresses');
    for (const [a, f] of Object.entries(j.referenceFeeds as Record<string, unknown>)) feeds[a] = getAddress(String(f));
  }
  return {
    limits, venues, wallets, referenceFeeds: feeds,
    reserve: typeof j.reserve === 'string' ? getAddress(j.reserve) : undefined,
  };
}

/**
 * Build the monitor from a parsed config: Hyperliquid venues on `hyperEvmRpc`; `onchain-perps`
 * venues and the reference feeds on the monitor's own Ethereum client. The reserve is not read: the sleeve is
 * Movva's own capital, capped absolutely (`deps.reserve` and the config's `reserve` are accepted, and unused).
 */
export function hedgeRiskMonitorFrom(c: HedgeRiskConfig, deps: {
  ethClient: Reader & Partial<Pick<PublicClient, 'getBlock'>>;
  hyperEvmRpc: string;
  reserve?: Address;
  redactValues?: readonly (string | undefined)[];
  hyperEvmClient?: Pick<PublicClient, 'call' | 'getBlock'>;
  /** The info API's fetch, for tests. */
  fetchImpl?: typeof fetch;
}): HedgeRiskMonitor {
  let hyper: Pick<PublicClient, 'call' | 'getBlock'> | undefined = deps.hyperEvmClient;
  const venues: HedgeVenue[] = c.venues.map((v) => {
    if (v.kind === 'onchain-perps') {
      const eth = deps.ethClient;
      if (!eth.getBlock) throw new Error(`venue "${v.id}" (onchain-perps) needs an Ethereum client that can read blocks`);
      return new OnchainHedgeVenue({ client: eth as Pick<PublicClient, 'readContract' | 'getBlock'>, venue: v.venue, stable: v.stable, markets: v.markets, id: v.id });
    }
    hyper ??= createPublicClient({ transport: http(deps.hyperEvmRpc) });
    return new HyperliquidVenue({ client: hyper, markets: v.markets, id: v.id, fetchImpl: deps.fetchImpl });
  });
  const secrets = [...(deps.redactValues ?? []), deps.hyperEvmRpc];
  return new HedgeRiskMonitor({
    limits: c.limits,
    redactValues: secrets,
    snapshot: async () => collectSnapshot(venues, c.wallets, {
      referencePx: Object.keys(c.referenceFeeds).length ? referenceReader(deps.ethClient, c.referenceFeeds) : undefined,
    }, {
      describeError: (e) => redactError(e, secrets),
      fundingLookbackHours: c.limits.funding.smoothingWindowHours + Math.max(c.limits.funding.adverseExitPeriods, c.limits.funding.reentryPeriods) + 24,
    }),
  });
}
