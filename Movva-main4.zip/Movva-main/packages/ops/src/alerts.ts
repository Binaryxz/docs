/**
 * Alert transitions.
 *
 * ## Why this is not "post whatever is failing, every poll"
 *
 * A monitor that re-sends the same page every thirty seconds trains its operators to mute
 * it, and a muted monitor is worse than none: it costs money and buys silence. So alerts
 * are edges, not levels. A check that enters a bad state fires once; a check that stays
 * there stays quiet; a check that recovers fires a resolution so the person who silenced
 * their phone learns it is over without going to look.
 *
 * ## Flapping, and why `unknown` has a longer fuse
 *
 * One failed RPC call is not an outage. `unknown` therefore has to persist for
 * `unknownGraceMs` before it is worth anyone's attention, which turns a flaky endpoint from
 * a pager storm into a single alert if it is genuinely down. Real `fail` and `warn`
 * transitions are reported immediately - the contracts they watch move faster than a grace
 * period.
 */
import type { CheckResult, Level } from './checks.js';
import { redact, redactError } from './redact.js';

export interface Alert {
  id: string;
  /** `firing` on entering a bad state, `resolved` on returning to ok. */
  kind: 'firing' | 'resolved';
  level: Level;
  detail: string;
  at: number;
  value?: number;
  threshold?: number;
}

export type AlertSink = (alert: Alert) => void | Promise<void>;

const BAD: readonly Level[] = ['warn', 'fail', 'unknown'];
const isBad = (l: Level) => BAD.includes(l);

interface Tracked {
  level: Level;
  /** When this check first entered its current bad state. */
  since: number;
  /** Whether we have already fired for this episode. */
  fired: boolean;
}

export interface AlerterOptions {
  /** How long `unknown` must persist before it is worth alerting on. Default 5 minutes. */
  unknownGraceMs?: number;
}

export class Alerter {
  private readonly state = new Map<string, Tracked>();
  private readonly grace: number;

  constructor(private readonly sink: AlertSink, opts: AlerterOptions = {}) {
    this.grace = opts.unknownGraceMs ?? 5 * 60_000;
  }

  /**
   * Feed one sweep's results in; emit only what changed.
   *
   * Returns the alerts emitted, so a caller can log or count them without wrapping the sink.
   */
  async observe(results: readonly CheckResult[], now = Date.now()): Promise<Alert[]> {
    const emitted: Alert[] = [];

    for (const r of results) {
      const prev = this.state.get(r.id);

      if (!isBad(r.level)) {
        // Recovery only counts if we actually told someone there was a problem.
        if (prev?.fired) {
          emitted.push({
            id: r.id, kind: 'resolved', level: r.level, detail: r.detail, at: now,
            value: r.value, threshold: r.threshold,
          });
        }
        this.state.delete(r.id);
        continue;
      }

      // Still bad, and the same kind of bad: keep the original start time so the grace
      // period measures the episode rather than restarting on every poll.
      const since = prev && prev.level === r.level ? prev.since : now;
      const held = now - since;
      const ready = r.level === 'unknown' ? held >= this.grace : true;
      const alreadyFired = prev?.fired === true && prev.level === r.level;

      if (ready && !alreadyFired) {
        emitted.push({
          id: r.id, kind: 'firing', level: r.level, detail: r.detail, at: now,
          value: r.value, threshold: r.threshold,
        });
        this.state.set(r.id, { level: r.level, since, fired: true });
      } else {
        this.state.set(r.id, { level: r.level, since, fired: alreadyFired });
      }
    }

    for (const a of emitted) await this.sink(a);
    return emitted;
  }

  /** Checks currently in a bad state, for the health endpoint. */
  get firing(): string[] {
    return [...this.state.entries()].filter(([, v]) => v.fired).map(([k]) => k);
  }
}

/**
 * Post alerts to a webhook (Slack-shaped, but any JSON endpoint works).
 *
 * Failures to deliver are reported to `onError` rather than thrown: an alerting system that
 * crashes the service it monitors has inverted its own purpose.
 */
export function webhookSink(
  url: string,
  opts: {
    fetchImpl?: typeof fetch;
    /** Receives delivery failures, already redacted: callers log it, and logs are read. */
    onError?: (e: Error) => void;
    /** Values that must never be posted, typically RPC_URL. The webhook URL is always one. */
    redactValues?: readonly (string | undefined)[];
  } = {},
): AlertSink {
  const f = opts.fetchImpl ?? fetch;
  const secrets = [url, ...(opts.redactValues ?? [])];
  return async (raw) => {
    // The alert goes to a third-party chat service, often into a channel wider than the
    // on-call rota; a detail carrying the RPC key would be published there.
    const alert = { ...raw, detail: redact(raw.detail, secrets) };
    const mark = alert.kind === 'resolved' ? 'RESOLVED' : alert.level.toUpperCase();
    const text = `[${mark}] ${alert.id}: ${alert.detail}`;
    try {
      const res = await f(url, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ text, alert }),
      });
      if (!res.ok) opts.onError?.(new Error(`alert webhook returned HTTP ${res.status}`));
    } catch (e) {
      // A fetch failure can name the URL it failed on, and a webhook URL is its own secret.
      opts.onError?.(new Error(`alert webhook delivery failed: ${redactError(e, secrets)}`));
    }
  };
}

/** Write alerts to stdout. The default when no webhook is configured. */
export function consoleSinkRedacting(secrets: readonly (string | undefined)[] = []): AlertSink {
  return (alert) => {
    const mark = alert.kind === 'resolved' ? 'RESOLVED' : alert.level.toUpperCase();
    console.log(`[${mark}] ${alert.id}: ${redact(alert.detail, secrets)}`);
  };
}

/** `consoleSinkRedacting` with no configured values: URLs are still cut to their host. */
export const consoleSink: AlertSink = consoleSinkRedacting();
