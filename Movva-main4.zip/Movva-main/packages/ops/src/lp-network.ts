/**
 * The LP network, read: who is admitted, at what credit, how much of it is live, what is disputed, and which registry
 * changes are scheduled - shared by the `lp` CLI (`bin/lp.ts`) and the monitor's LP checks.
 *
 * ## Two sources, each for what it is good at
 *
 * **State** answers everything about one LP: `lps(lp)`, `capOf`, `availableCents`, `carvedOutCents`,
 * `groupExposureCents`, and the reserve's `isGateway`. It is the truth, and it is cheap.
 *
 * **History** answers the two questions state cannot: *which* addresses are LPs (the registry keeps a mapping, not a
 * list), and *what* a scheduled change contains (`readyAt` is keyed by `keccak256(call)`; the calldata itself is only in
 * the `ChangeScheduled` log). Open disputes are history too: the escrows record a dispute against an order or sale, and
 * only their logs say which LP that order belongs to. So this folds the registry's and the escrows' logs into a ledger,
 * keeps a block cursor, and reads only the blocks since. A pending change is always confirmed against `readyAt(id)`
 * before it is reported, so a ledger that lags never invents one.
 *
 * ## Free RPC plans
 *
 * Alchemy's free plan answers `eth_getLogs` for at most 10 blocks per call. The reader starts wide, narrows to 10 when
 * the provider says the range is too large (the same rule as `scripts/privilege-inventory.ts`), runs narrow windows a
 * few at a time, and backs off on rate limits. A day of Sepolia is ~7,200 blocks: ~720 calls the first time, and only
 * the new blocks after that, because the cursor is kept.
 *
 * ## Two registries
 *
 * The curated `LPRegistry` and `PermissionlessLPRegistry` both sit behind the same, unchanged escrows
 * (`registry-kind.ts` tells them apart). Everything escrow-side here - offers, orders, sales, disputes - is the same for
 * both. Registry-side, the permissionless one has no governor, tiers, phases or scheduled changes: an LP is discovered
 * from `Joined` (and `ToppedUp`, `ExitRequested`, `Slashed`), its state is `bonds(lp)`, and the history the ledger keeps
 * is its exits (`ExitRequested` / `Withdrawn`) and slashes (`Slashed` / `DisputeLost`). Its monitor checks are
 * `permissionlessLpChecks`, with two of their own: `lp_slash:<lp>` and `lp_exit:<lp>`.
 *
 * ## The ledger is a cache plus an audit trail
 *
 * Everything chain-derived in it can be rebuilt from `fromBlock`; if the block at the cursor no longer has the hash the
 * ledger saw (a reorg, or a ledger written against a fork), the chain-derived part is dropped and rebuilt. `actions` -
 * what the CLI itself sent, and the reason given for a forced removal - is kept across a rebuild.
 */
import {
  getAddress, isAddressEqual, parseAbi, parseEventLogs, decodeFunctionData, type Address, type Hex, type Log, type PublicClient,
} from 'viem';
import { movva, readBondRegistry, type BondRegistryReading } from './bond.js';
import type { CheckResult, Level } from './checks.js';
import { BURN } from './orphans.js';
import { reais } from './reais.js';
import { redactError } from './redact.js';
import { detectRegistryKind, readBondedLp, type BondedLpReading, type RegistryKind } from './registry-kind.js';

/** `LPRegistry.Tier` in declaration order (the index is the ABI value). `test/lp-network.test.ts` pins it to admin.ts's TIERS. */
export const TIER_NAMES = ['NONE', 'RETAIL', 'AFFILIATED', 'INSTITUTIONAL', 'SUSPENDED'] as const;
export type TierName = typeof TIER_NAMES[number];
/** `LPRegistry.Phase`. */
export const PHASE_NAMES = ['A', 'B', 'C'] as const;
export type PhaseName = typeof PHASE_NAMES[number];

export const REGISTRY_ABI = parseAbi([
  'function phase() view returns (uint8)',
  'function governor() view returns (address)',
  'function setupComplete() view returns (bool)',
  'function GOVERNANCE_DELAY() view returns (uint256)',
  'function EXECUTION_WINDOW() view returns (uint256)',
  'function readyAt(bytes32 id) view returns (uint256)',
  'function lps(address lp) view returns (uint8 tier, uint256 settledCents, uint32 settlements, uint32 disputesLost, uint256 manualCapCents, address sponsor, uint256 exposureCents)',
  'function capOf(address lp) view returns (uint256)',
  'function availableCents(address lp) view returns (uint256)',
  'function carvedOutCents(address sponsor) view returns (uint256)',
  'function groupExposureCents(address lp) view returns (uint256)',
]);

export const RESERVE_GATEWAY_ABI = parseAbi(['function isGateway(address gateway) view returns (bool)']);

/** The registry's delayable setters (`LPRegistry._isDelayable`): what a scheduled change on it can contain. */
export const REGISTRY_SETTERS = parseAbi([
  'function setTier(address lp, uint8 tier, uint256 manualCapCents)',
  'function setPhase(uint8 next)',
  'function setEscrow(address escrow, bool allowed)',
  'function setRewardsHook(address hook)',
]);

/** The registry's events (DelayedGovernance's queue included) and the escrows' events that place an LP and its disputes. */
export const LP_EVENTS = parseAbi([
  'event ChangeScheduled(bytes32 indexed id, bytes4 indexed selector, bytes call, uint256 readyAt, uint256 expiresAt)',
  'event ChangeCancelled(bytes32 indexed id)',
  'event ChangeExecuted(bytes32 indexed id, bytes4 indexed selector)',
  'event TierChanged(address indexed lp, uint8 from, uint8 to, uint256 creditCents)',
  'event Registered(address indexed lp, uint8 tier)',
  'event AffiliateSponsored(address indexed sponsor, address indexed affiliate, uint256 creditCents)',
  'event AffiliateRevoked(address indexed sponsor, address indexed affiliate)',
  'event PhaseSet(uint8 from, uint8 to)',
  // PermissionlessLPRegistry. Its DisputeLost carries no newCap, so its topic is not LPRegistry's.
  'event EscrowsBound(address indexed fiatEscrow, address indexed offRampEscrow)',
  'event Joined(address indexed lp, uint256 amount)',
  'event ToppedUp(address indexed lp, uint256 amount, uint256 bond)',
  'event ExitRequested(address indexed lp, uint256 withdrawableFrom)',
  'event Withdrawn(address indexed lp, uint256 amount)',
  'event Slashed(address indexed lp, address indexed escrow, uint256 amount)',
  'event DisputeLost(address indexed lp, uint32 total)',
  // FiatEscrow
  'event OfferPosted(bytes32 indexed offerId, address indexed lp, uint256 wei_, uint256 price)',
  'event OrderLocked(bytes32 indexed orderId, bytes32 indexed offerId, address indexed taker, uint256 brlCents)',
  'event OrderDisputed(bytes32 indexed orderId, address by, string reason)',
  // OffRampEscrow
  'event SaleClaimed(bytes32 indexed saleId, address indexed lp, uint64 payBy)',
  'event SaleDisputed(bytes32 indexed saleId, address by, string reason)',
  // Both escrows: identical types, so identical topics (the flag is releasedToTaker on one, paidLP on the other).
  'event DisputeResolved(bytes32 indexed orderId, bool favoursCounterparty, address indexed arbitrator, bytes32 evidenceRoot)',
  'event DisputeTimedOut(bytes32 indexed orderId)',
]);

/*//////////////////////////////////////////////////////////////
                              LEDGER
//////////////////////////////////////////////////////////////*/

export interface LedgerChange {
  id: Hex;
  /** The scheduled calldata: what `execute` must be sent with. '0x' when only its cancellation or execution was seen. */
  call: Hex;
  readyAt: string;
  expiresAt: string;
  scheduledBlock: string;
  scheduledTx?: Hex;
  status: 'pending' | 'executed' | 'cancelled';
  closedBlock?: string;
}

export interface LedgerDispute {
  id: Hex;
  escrow: Address;
  kind: 'order' | 'sale';
  /** Undefined when the order's offer (or the sale's claim) predates the scanned range. */
  lp?: Address;
  raisedBlock: string;
  status: 'open' | 'resolved' | 'timed-out';
}

/** A permissionless LP's request to leave, and its withdrawal once it came. */
export interface LedgerExit {
  lp: Address;
  requestedBlock: string;
  /** As `ExitRequested` stated it: unix seconds. */
  withdrawableFrom: string;
  status: 'pending' | 'withdrawn';
  withdrawnBlock?: string;
  withdrawnWei?: string;
}

/** A dispute a permissionless LP lost: `Slashed` (the bond taken) and `DisputeLost` from the same transaction. */
export interface LedgerSlash {
  lp: Address;
  /** The escrow whose ruling or timeout reported it. Absent for a lost dispute that found no bond to take. */
  escrow?: Address;
  /** MOVVA base units taken; '0' when the bond was already empty. */
  amountWei: string;
  /** The LP's lifetime count after this one, from `DisputeLost`. */
  disputesLost?: number;
  block: string;
  tx?: Hex;
  /** The block's timestamp, filled in by `syncLedger`: when the alert's clock starts. */
  at?: string;
}

export interface LedgerAction {
  at: string;
  command: string;
  chainId?: number;
  tx?: Hex;
  block?: string;
  lp?: Address;
  id?: Hex;
  readyAt?: string;
  expiresAt?: string;
  reason?: string;
  note?: string;
}

export interface LpLedger {
  version: 1;
  chainId?: number;
  registry: Address;
  escrows: Address[];
  /** The first block folded: the registry's deployment block. */
  fromBlock?: string;
  /** The last block folded, and its hash (a mismatch on the next sync drops the chain-derived state). */
  scannedTo?: string;
  scannedToHash?: Hex;
  phase?: number;
  /** What the registry is, once detected. A ledger from before both kinds existed is a curated one. */
  kind?: RegistryKind;
  lps: Record<string, { address: Address; firstSeenBlock: string; via: string }>;
  changes: Record<string, LedgerChange>;
  offers: Record<string, Address>;
  orders: Record<string, Address>;
  sales: Record<string, Address>;
  disputes: Record<string, LedgerDispute>;
  /** PermissionlessLPRegistry only: exits, oldest first. Absent on a curated ledger. */
  exits?: LedgerExit[];
  /** PermissionlessLPRegistry only: lost disputes and what each took, oldest first. */
  slashes?: LedgerSlash[];
  /** What the CLI sent, with reasons: kept across a rebuild. */
  actions: LedgerAction[];
}

export function emptyLedger(o: { registry: Address; escrows?: Address[]; fromBlock?: bigint; chainId?: number }): LpLedger {
  return {
    version: 1, chainId: o.chainId, registry: getAddress(o.registry), escrows: (o.escrows ?? []).map((a) => getAddress(a)),
    fromBlock: o.fromBlock?.toString(), lps: {}, changes: {}, offers: {}, orders: {}, sales: {}, disputes: {}, actions: [],
  };
}

/** Forget everything the chain told the ledger, keep what the CLI recorded. */
export function resetChainState(l: LpLedger): void {
  Object.assign(l, {
    scannedTo: undefined, scannedToHash: undefined, phase: undefined, lps: {}, changes: {}, offers: {}, orders: {}, sales: {}, disputes: {},
    exits: undefined, slashes: undefined,
  });
}

const key = (x: string) => x.toLowerCase();

function addLp(l: LpLedger, lp: Address, block: bigint, via: string): void {
  if (/^0x0{40}$/i.test(lp)) return;
  const k = key(lp);
  if (!l.lps[k]) l.lps[k] = { address: getAddress(lp), firstSeenBlock: block.toString(), via };
}

export type DecodedLog = Log<bigint, number, false> & { eventName: string; args: Record<string, unknown> };

/** Fold decoded logs into the ledger, in chain order. Pure: the tests drive it with hand-made logs. */
export function foldLogs(l: LpLedger, logs: readonly DecodedLog[]): void {
  const sorted = [...logs].sort((a, b) => (a.blockNumber === b.blockNumber ? (a.logIndex ?? 0) - (b.logIndex ?? 0) : a.blockNumber! < b.blockNumber! ? -1 : 1));
  const escrows = new Set(l.escrows.map(key));
  for (const log of sorted) {
    const at = log.blockNumber ?? 0n;
    const a = log.args;
    const from = key(log.address);
    if (from === key(l.registry)) {
      switch (log.eventName) {
        case 'ChangeScheduled': {
          const id = a.id as Hex;
          l.changes[key(id)] = {
            id, call: a.call as Hex, readyAt: String(a.readyAt), expiresAt: String(a.expiresAt), scheduledBlock: at.toString(),
            ...(log.transactionHash ? { scheduledTx: log.transactionHash } : {}), status: 'pending',
          };
          const target = lpOfCall(a.call as Hex);
          if (target) addLp(l, target, at, 'scheduled setTier');
          break;
        }
        case 'ChangeCancelled':
        case 'ChangeExecuted': {
          const id = a.id as Hex;
          const c = l.changes[key(id)] ?? { id, call: '0x', readyAt: '0', expiresAt: '0', scheduledBlock: '0', status: 'pending' as const };
          c.status = log.eventName === 'ChangeCancelled' ? 'cancelled' : 'executed';
          c.closedBlock = at.toString();
          l.changes[key(id)] = c;
          break;
        }
        case 'TierChanged': addLp(l, a.lp as Address, at, 'TierChanged'); break;
        case 'Registered': addLp(l, a.lp as Address, at, 'Registered'); break;
        case 'AffiliateSponsored':
          addLp(l, a.sponsor as Address, at, 'AffiliateSponsored (sponsor)');
          addLp(l, a.affiliate as Address, at, 'AffiliateSponsored');
          break;
        case 'PhaseSet': l.phase = Number(a.to); break;
        // PermissionlessLPRegistry.
        case 'Joined': addLp(l, a.lp as Address, at, 'Joined'); break;
        case 'ToppedUp': addLp(l, a.lp as Address, at, 'ToppedUp'); break;
        case 'ExitRequested':
          addLp(l, a.lp as Address, at, 'ExitRequested');
          (l.exits ??= []).push({ lp: getAddress(a.lp as Address), requestedBlock: at.toString(), withdrawableFrom: String(a.withdrawableFrom), status: 'pending' });
          break;
        case 'Withdrawn': {
          addLp(l, a.lp as Address, at, 'Withdrawn');
          const open = [...(l.exits ?? [])].reverse().find((e) => e.status === 'pending' && isAddressEqual(e.lp, a.lp as Address));
          if (open) Object.assign(open, { status: 'withdrawn', withdrawnBlock: at.toString(), withdrawnWei: String(a.amount) });
          break;
        }
        case 'Slashed':
          addLp(l, a.lp as Address, at, 'Slashed');
          (l.slashes ??= []).push({
            lp: getAddress(a.lp as Address), escrow: getAddress(a.escrow as Address), amountWei: String(a.amount), block: at.toString(),
            ...(log.transactionHash ? { tx: log.transactionHash } : {}),
          });
          break;
        case 'DisputeLost': {
          addLp(l, a.lp as Address, at, 'DisputeLost');
          // The registry emits Slashed then DisputeLost in one call; a lost dispute that found the bond empty emits only this.
          // Block and LP are enough to pair them: a second loss in the same block finds the bond empty and emits no Slashed.
          const same = (l.slashes ?? []).find((x) => x.disputesLost === undefined && isAddressEqual(x.lp, a.lp as Address) && x.block === at.toString());
          if (same) same.disputesLost = Number(a.total);
          else {
            (l.slashes ??= []).push({
              lp: getAddress(a.lp as Address), amountWei: '0', disputesLost: Number(a.total), block: at.toString(),
              ...(log.transactionHash ? { tx: log.transactionHash } : {}),
            });
          }
          break;
        }
        default: break;
      }
      continue;
    }
    if (!escrows.has(from)) continue;
    switch (log.eventName) {
      case 'OfferPosted': l.offers[key(a.offerId as Hex)] = getAddress(a.lp as Address); break;
      case 'OrderLocked': {
        const lp = l.offers[key(a.offerId as Hex)];
        if (lp) l.orders[key(a.orderId as Hex)] = lp;
        break;
      }
      case 'SaleClaimed': l.sales[key(a.saleId as Hex)] = getAddress(a.lp as Address); break;
      case 'OrderDisputed':
      case 'SaleDisputed': {
        const order = log.eventName === 'OrderDisputed';
        const id = (order ? a.orderId : a.saleId) as Hex;
        const lp = order ? l.orders[key(id)] : l.sales[key(id)];
        l.disputes[key(id)] = { id, escrow: getAddress(log.address), kind: order ? 'order' : 'sale', ...(lp ? { lp } : {}), raisedBlock: at.toString(), status: 'open' };
        break;
      }
      case 'DisputeResolved':
      case 'DisputeTimedOut': {
        const d = l.disputes[key(a.orderId as Hex)];
        if (d) d.status = log.eventName === 'DisputeResolved' ? 'resolved' : 'timed-out';
        break;
      }
      default: break;
    }
  }
}

/*//////////////////////////////////////////////////////////////
                         PAGED LOG READER
//////////////////////////////////////////////////////////////*/

export type LogClient = Pick<PublicClient, 'getLogs' | 'getBlockNumber' | 'getBlock'>;

export interface ReadLogsOptions {
  /** First window size. Default 2,000 blocks; narrowed to 10 when the provider refuses. */
  span?: bigint;
  /** Narrow windows (<= 100 blocks) in flight at once. Default 4. */
  concurrency?: number;
  /** Called after each batch: blocks done so far, of total. */
  onProgress?: (done: bigint, total: bigint) => void;
  /** Sleep, for the tests. */
  sleep?: (ms: number) => Promise<void>;
}

const RANGE_REFUSAL = /block range|range limit|\b10 block|too many blocks|exceed|query returned more than|range is too large|max range/i;
const RATE_LIMIT = /429|rate limit|too many requests|compute units|capacity|throughput/i;
const errText = (e: unknown) => { const x = e as { message?: string; details?: string; shortMessage?: string }; return `${x?.shortMessage ?? ''} ${x?.details ?? ''} ${x?.message ?? String(e)}`; };

/**
 * Every log the addresses emitted in [from, to], decoded against `LP_EVENTS` (logs of other events are dropped), in
 * windows the provider accepts.
 */
export async function readLogsPaged(
  client: Pick<PublicClient, 'getLogs'>, addresses: readonly Address[], from: bigint, to: bigint, o: ReadLogsOptions = {},
): Promise<DecodedLog[]> {
  const sleep = o.sleep ?? ((ms: number) => new Promise<void>((r) => setTimeout(r, ms)));
  const out: Log[] = [];
  let span = o.span ?? 2_000n;
  const fetchWindow = async (a: bigint, b: bigint): Promise<Log[]> => {
    for (let attempt = 0; ; attempt++) {
      try {
        return await client.getLogs({ address: [...addresses], fromBlock: a, toBlock: b } as never) as Log[];
      } catch (e) {
        if (!RANGE_REFUSAL.test(errText(e)) && RATE_LIMIT.test(errText(e)) && attempt < 6) { await sleep(500 * 2 ** attempt); continue; }
        throw e;
      }
    }
  };
  for (let cursor = from; cursor <= to;) {
    const width = span <= 100n ? Math.max(1, o.concurrency ?? 4) : 1;
    const windows: [bigint, bigint][] = [];
    for (let c = cursor; windows.length < width && c <= to; c += span) windows.push([c, c + span - 1n > to ? to : c + span - 1n]);
    try {
      const got = await Promise.all(windows.map(([a, b]) => fetchWindow(a, b)));
      for (const g of got) out.push(...g);
      cursor = windows[windows.length - 1]![1] + 1n;
      o.onProgress?.(cursor - from, to - from + 1n);
    } catch (e) {
      if (span > 10n && RANGE_REFUSAL.test(errText(e))) { span = span > 1_000n ? 1_000n : 10n; continue; }
      throw e;
    }
  }
  return parseEventLogs({ abi: LP_EVENTS, logs: out }) as unknown as DecodedLog[];
}

/** Bring the ledger up to `toBlock` (default the head). Returns what was read; `skipped` when no starting block is known. */
export async function syncLedger(
  client: LogClient, l: LpLedger, o: ReadLogsOptions & { toBlock?: bigint } = {},
): Promise<{ skipped?: true; from?: bigint; to?: bigint; logs: number; rebuilt?: true }> {
  // Uncached: viem keeps a block number for 4 s, and a sweep right after a transaction must see its block.
  const head = o.toBlock ?? await client.getBlockNumber({ cacheTime: 0 });
  let rebuilt: true | undefined;
  if (l.scannedTo !== undefined && l.scannedToHash) {
    const b = await client.getBlock({ blockNumber: BigInt(l.scannedTo) });
    if (b.hash?.toLowerCase() !== l.scannedToHash.toLowerCase()) { resetChainState(l); rebuilt = true; }
  }
  const from = l.scannedTo !== undefined ? BigInt(l.scannedTo) + 1n : l.fromBlock !== undefined ? BigInt(l.fromBlock) : undefined;
  if (from === undefined) return { skipped: true, logs: 0 };
  if (from > head) return { from, to: head, logs: 0, ...(rebuilt ? { rebuilt } : {}) };
  const logs = await readLogsPaged(client, [l.registry, ...l.escrows], from, head, o);
  foldLogs(l, logs);
  // A slash's alert runs from when it happened, so a monitor that was down still sees one that is recent.
  for (const x of l.slashes ?? []) if (x.at === undefined) x.at = String((await client.getBlock({ blockNumber: BigInt(x.block) })).timestamp);
  l.scannedTo = head.toString();
  l.scannedToHash = (await client.getBlock({ blockNumber: head })).hash ?? undefined;
  return { from, to: head, logs: logs.length, ...(rebuilt ? { rebuilt } : {}) };
}

/*//////////////////////////////////////////////////////////////
                              READING
//////////////////////////////////////////////////////////////*/

export type ReadClient = Pick<PublicClient, 'readContract'>;

export interface RegistryReading {
  registry: Address;
  phase: PhaseName;
  phaseIndex: number;
  governor: Address;
  setupComplete: boolean;
  delaySeconds: bigint;
  windowSeconds: bigint;
  /** The governor is 0x...dEaD: `--finalize` ran, and no tier, credit or phase can ever change again. */
  finalized: boolean;
}

export async function readRegistry(client: ReadClient, registry: Address): Promise<RegistryReading> {
  const r = <T>(functionName: string) => client.readContract({ address: registry, abi: REGISTRY_ABI, functionName } as never) as Promise<T>;
  const [phase, governor, setupComplete, delay, window] = await Promise.all([
    r<number | bigint>('phase'), r<Address>('governor'), r<boolean>('setupComplete'), r<bigint>('GOVERNANCE_DELAY'), r<bigint>('EXECUTION_WINDOW'),
  ]);
  const i = Number(phase);
  return {
    registry, phase: PHASE_NAMES[i] ?? (`?${i}` as PhaseName), phaseIndex: i, governor: getAddress(governor), setupComplete,
    delaySeconds: BigInt(delay), windowSeconds: BigInt(window), finalized: isAddressEqual(governor, BURN),
  };
}

export interface LpReading {
  lp: Address;
  tier: TierName;
  tierIndex: number;
  /** INSTITUTIONAL: the governor-set limit. AFFILIATED: the credit its sponsor carved out. Kept while SUSPENDED. */
  creditCents: bigint;
  /** `capOf`: what the limit is right now (0 while suspended, or for a tier the phase has closed). */
  capCents: bigint;
  exposureCents: bigint;
  availableCents: bigint;
  /** INSTITUTIONAL: credit given to its affiliates, and its own plus its affiliates' exposure. */
  carvedOutCents: bigint;
  groupExposureCents: bigint;
  settledCents: bigint;
  settlements: number;
  disputesLost: number;
  sponsor?: Address;
  suspended: boolean;
  /** `MovvaReserve.isGateway`, when a reserve was given. */
  gateway?: boolean;
}

export async function readLp(client: ReadClient, registry: Address, lp: Address, reserve?: Address): Promise<LpReading> {
  const r = <T>(functionName: string, args: readonly unknown[]) =>
    client.readContract({ address: registry, abi: REGISTRY_ABI, functionName, args } as never) as Promise<T>;
  const [row, cap, available, carved, group, gateway] = await Promise.all([
    r<readonly [number, bigint, number, number, bigint, Address, bigint]>('lps', [lp]),
    r<bigint>('capOf', [lp]), r<bigint>('availableCents', [lp]), r<bigint>('carvedOutCents', [lp]), r<bigint>('groupExposureCents', [lp]),
    reserve ? client.readContract({ address: reserve, abi: RESERVE_GATEWAY_ABI, functionName: 'isGateway', args: [lp] }) as Promise<boolean> : Promise.resolve(undefined),
  ]);
  const [tier, settledCents, settlements, disputesLost, manualCapCents, sponsor, exposureCents] = row;
  const t = Number(tier);
  return {
    lp: getAddress(lp), tier: TIER_NAMES[t] ?? (`?${t}` as TierName), tierIndex: t, creditCents: BigInt(manualCapCents),
    capCents: BigInt(cap), exposureCents: BigInt(exposureCents), availableCents: BigInt(available), carvedOutCents: BigInt(carved),
    groupExposureCents: BigInt(group), settledCents: BigInt(settledCents), settlements: Number(settlements), disputesLost: Number(disputesLost),
    ...(/^0x0{40}$/i.test(sponsor) ? {} : { sponsor: getAddress(sponsor) }), suspended: t === 4,
    ...(gateway !== undefined ? { gateway } : {}),
  };
}

/** Exposure the LP must see settle or expire before it is removed: its own, and (for a sponsor) its affiliates'. */
export const liveExposure = (r: LpReading): bigint => (r.groupExposureCents > r.exposureCents ? r.groupExposureCents : r.exposureCents);

/**
 * One LP as either registry keeps it, in the terms both share: the limit, what is live, what is left, the record.
 * `standing` is the curated tier (INSTITUTIONAL, SUSPENDED, ...) or the permissionless standing (BONDED, EXITING,
 * SLASHED, NONE); `curated` / `bond` carry the kind's own reading for whatever only that kind has.
 */
export interface LpView {
  lp: Address;
  kind: RegistryKind;
  standing: string;
  capCents: bigint;
  availableCents: bigint;
  exposureCents: bigint;
  settledCents: bigint;
  settlements: number;
  disputesLost: number;
  curated?: LpReading;
  bond?: BondedLpReading;
}

/** `lps(lp)` or `bonds(lp)`, whichever the registry has, as one shape. */
export async function readLpView(client: ReadClient, registry: Address, lp: Address, o: { reserve?: Address } = {}): Promise<LpView> {
  const kind = await detectRegistryKind(client, registry);
  if (kind === 'curated') {
    const r = await readLp(client, registry, lp, o.reserve);
    return {
      lp: r.lp, kind, standing: r.tier, capCents: r.capCents, availableCents: r.availableCents, exposureCents: liveExposure(r),
      settledCents: r.settledCents, settlements: r.settlements, disputesLost: r.disputesLost, curated: r,
    };
  }
  const reg = await readBondRegistry(client, registry);
  const b = await readBondedLp(client, reg, lp);
  return {
    lp: b.lp, kind, standing: b.standing, capCents: b.capCents, availableCents: b.availableCents, exposureCents: b.exposureCents,
    settledCents: b.settledCents, settlements: b.settlements, disputesLost: b.disputesLost, bond: b,
  };
}

/*//////////////////////////////////////////////////////////////
                         SCHEDULED CHANGES
//////////////////////////////////////////////////////////////*/

export { reais };

export function decodeRegistryCall(call: Hex): { fn: string; args: readonly unknown[] } | undefined {
  if (!call || call === '0x') return undefined;
  try {
    const d = decodeFunctionData({ abi: REGISTRY_SETTERS, data: call });
    return { fn: d.functionName, args: d.args ?? [] };
  } catch {
    return undefined;
  }
}

/** The LP a scheduled setTier names. */
export function lpOfCall(call: Hex): Address | undefined {
  const d = decodeRegistryCall(call);
  return d?.fn === 'setTier' ? getAddress(d.args[0] as Address) : undefined;
}

/** A scheduled call as an operator reads it: `setTier(0x…, INSTITUTIONAL, R$ 1.000,00)`. */
export function describeRegistryCall(call: Hex): string {
  const d = decodeRegistryCall(call);
  if (!d) return call === '0x' ? 'a change whose calldata was not in the scanned logs' : `an undecodable call ${call.slice(0, 10)}`;
  switch (d.fn) {
    case 'setTier': return `setTier(${d.args[0]}, ${TIER_NAMES[Number(d.args[1])] ?? d.args[1]}, ${reais(d.args[2] as bigint)})`;
    case 'setPhase': return `setPhase(${PHASE_NAMES[Number(d.args[0])] ?? d.args[0]})`;
    case 'setEscrow': return `setEscrow(${d.args[0]}, ${d.args[1]})`;
    default: return `${d.fn}(${d.args.join(', ')})`;
  }
}

export interface PendingChange extends LedgerChange {
  description: string;
  lp?: Address;
  /** `readyAt(id)` as the chain answers now: 0 means the ledger lags (it ran or was cancelled since). */
  onChainReadyAt: bigint;
  state: 'waiting' | 'ready' | 'expired' | 'gone';
}

/** Every change the ledger holds as pending, each confirmed against `readyAt(id)` on-chain. */
export async function pendingChanges(client: ReadClient, l: LpLedger, nowSeconds: number): Promise<PendingChange[]> {
  const pending = Object.values(l.changes).filter((c) => c.status === 'pending');
  const ready = await Promise.all(pending.map((c) =>
    client.readContract({ address: l.registry, abi: REGISTRY_ABI, functionName: 'readyAt', args: [c.id] }) as Promise<bigint>));
  return pending.map((c, i) => {
    const on = BigInt(ready[i]!);
    const now = BigInt(nowSeconds);
    const state: PendingChange['state'] = on === 0n ? 'gone' : now < on ? 'waiting' : now <= BigInt(c.expiresAt) ? 'ready' : 'expired';
    const lp = lpOfCall(c.call);
    return { ...c, description: describeRegistryCall(c.call), ...(lp ? { lp } : {}), onChainReadyAt: on, state };
  }).sort((a, b) => (BigInt(a.readyAt) < BigInt(b.readyAt) ? -1 : 1));
}

export const openDisputesOf = (l: LpLedger, lp: Address) =>
  Object.values(l.disputes).filter((d) => d.status === 'open' && d.lp && isAddressEqual(d.lp, lp));

/*//////////////////////////////////////////////////////////////
                           THE LP NODE
//////////////////////////////////////////////////////////////*/

export interface NodeSummary {
  ok: boolean;
  httpStatus?: number;
  ready?: boolean;
  account?: string;
  chainId?: number;
  lastTickAt?: string;
  lastTickError?: string;
  credit?: { capCents: string; availableCents: string };
  unresolvedPayments?: number;
  openOrders?: number;
  openSales?: number;
  disputedSales?: number;
  held?: number;
  unreconciledCredits?: number;
  gateway?: boolean;
  rewardsNotCounting?: string;
  /** What disagrees with the chain: the node runs as another account, or on another chain. */
  mismatches: string[];
  error?: string;
}

/**
 * The LP node's private `/status`, summarised. Never its payer data: the caps section carries payer hashes and totals,
 * which belong on the LP's side; this reads only what an operator needs to see the node is the one for this LP and alive.
 */
export async function fetchNodeStatus(
  baseUrl: string, expect: { lp?: Address; chainId?: number }, deps: { fetch?: typeof fetch; timeoutMs?: number } = {},
): Promise<NodeSummary> {
  const f = deps.fetch ?? fetch;
  const url = `${baseUrl.replace(/\/+$/, '')}/status`;
  try {
    const res = await f(url, { signal: AbortSignal.timeout(deps.timeoutMs ?? 5_000) });
    const text = await res.text();
    let j: Record<string, any>;
    try { j = JSON.parse(text) as Record<string, any>; } catch { return { ok: false, httpStatus: res.status, mismatches: [], error: 'the node answered something other than JSON' }; }
    const orders = (j.onramp?.orders ?? []) as { hold?: unknown }[];
    const sales = (j.offramp?.sales ?? []) as { disputed?: unknown; hold?: unknown }[];
    const s: NodeSummary = {
      ok: res.ok, httpStatus: res.status, ready: j.ready === true, account: j.account, chainId: j.chainId === undefined ? undefined : Number(j.chainId),
      lastTickAt: j.lastTick?.at, ...(j.lastTick?.error ? { lastTickError: String(j.lastTick.error) } : {}),
      ...(j.credit ? { credit: { capCents: String(j.credit.capCents), availableCents: String(j.credit.availableCents) } } : {}),
      unresolvedPayments: Array.isArray(j.unresolvedPayments) ? j.unresolvedPayments.length : Number(j.unresolvedPayments ?? 0),
      openOrders: orders.length, openSales: sales.length, disputedSales: sales.filter((x) => x.disputed).length,
      held: [...orders, ...sales].filter((x) => x.hold).length,
      unreconciledCredits: j.onramp?.unreconciledCredits === undefined ? undefined : Number(j.onramp.unreconciledCredits),
      gateway: j.gateway !== null && j.gateway !== undefined,
      ...(j.rewards?.notCounting ? { rewardsNotCounting: String(j.rewards.notCounting) } : {}),
      mismatches: [],
    };
    if (expect.lp && s.account && !isAddressEqual(s.account as Address, expect.lp)) s.mismatches.push(`the node runs as ${s.account}, not ${expect.lp}`);
    if (expect.chainId !== undefined && s.chainId !== undefined && s.chainId !== expect.chainId) s.mismatches.push(`the node is on chain ${s.chainId}, not ${expect.chainId}`);
    return s;
  } catch (e) {
    return { ok: false, mismatches: [], error: redactError(e, [baseUrl]) };
  }
}

/*//////////////////////////////////////////////////////////////
                          MONITOR CHECKS
//////////////////////////////////////////////////////////////*/

export interface LpNetworkThresholds {
  /** `lp_credit:<lp>` warns once this share of the LP's limit is used (live or carved out for affiliates). */
  creditWarnPercent: number;
  /** ...and fails at this share: at 100 the LP can quote nothing new. */
  creditFailPercent: number;
  /** `lp_change:<id>` warns when a ready change has less than this left before it expires unexecuted. */
  changeExpiryWarnSeconds: number;
  /** PermissionlessLPRegistry: `lp_slash:<lp>` fails for this long after a lost dispute, then reports ok with the record. */
  slashAlertSeconds: number;
}

export const DEFAULT_LP_NETWORK_THRESHOLDS: LpNetworkThresholds = {
  creditWarnPercent: 80,
  creditFailPercent: 100,
  changeExpiryWarnSeconds: 3 * 24 * 60 * 60,
  slashAlertSeconds: 24 * 60 * 60,
};

const iso = (s: bigint | number) => new Date(Number(s) * 1000).toISOString().replace('.000Z', 'Z');
const hours = (s: bigint | number) => `${(Number(s) / 3600).toFixed(1)}h`;
const shortId = (id: string) => `${id.slice(0, 10)}…`;

/** Share of the limit in use, in percent: what is live plus what a sponsor carved out, i.e. 100 - available/cap. */
export function creditUsedPercent(r: Pick<LpReading, 'capCents' | 'availableCents'>): number | undefined {
  if (r.capCents === 0n) return undefined;
  const used = r.capCents > r.availableCents ? r.capCents - r.availableCents : 0n;
  return Number((used * 10_000n) / r.capCents) / 100;
}

/**
 * The LP network's checks, from readings already taken. Pure, so the tests drive every branch.
 *
 *  - `lp_network`: the summary - phase, how many LPs of each tier, what is live, what is scheduled.
 *  - `lp_credit:<lp>`: warn at `creditWarnPercent` of the limit in use, fail at `creditFailPercent` (it can quote nothing).
 *  - `lp_disputes:<lp>`: warn while the LP has an open dispute on either escrow (for an LP that ever had one).
 *  - `lp_disputes:unattributed`: warn while a dispute is open on an order or sale the ledger cannot place.
 *  - `lp_change:<id>`: every scheduled registry change; warn when it is ready and about to expire unexecuted, and while
 *    an expired one sits in the queue (it can never run, and `--finalize` refuses while anything is queued).
 */
export function lpNetworkChecks(
  input: { registry: RegistryReading; ledger: LpLedger; readings: LpReading[]; pending: PendingChange[]; nowSeconds: number },
  th: LpNetworkThresholds = DEFAULT_LP_NETWORK_THRESHOLDS,
): CheckResult[] {
  const { registry, ledger, readings, pending, nowSeconds } = input;
  const out: CheckResult[] = [];
  const tiers = new Map<string, number>();
  let live = 0n;
  for (const r of readings) { tiers.set(r.tier, (tiers.get(r.tier) ?? 0) + 1); live += r.exposureCents; }
  const tierText = [...tiers.entries()].filter(([t]) => t !== 'NONE').map(([t, n]) => `${n} ${t.toLowerCase()}`).join(', ') || 'no LP admitted';
  const live_ = pending.filter((p) => p.state !== 'gone');
  out.push({
    id: 'lp_network', level: 'ok', value: readings.filter((r) => r.tier !== 'NONE').length,
    detail: `LP network in phase ${registry.phase}: ${tierText}; ${reais(live)} live; ${live_.length} scheduled registry change(s)`
      + `${registry.finalized ? '; governance FINALIZED (renounced): nothing here can change again' : ''}`,
  });

  for (const r of readings) {
    const id = `lp_credit:${r.lp.toLowerCase()}`;
    const pct = creditUsedPercent(r);
    if (pct === undefined) {
      const why = r.tier === 'SUSPENDED' ? 'suspended' : r.tier === 'NONE' ? 'not admitted' : `${r.tier.toLowerCase()} with no credit in phase ${registry.phase}`;
      out.push({ id, level: 'ok', detail: `${r.lp} is ${why}${r.exposureCents > 0n ? `, with ${reais(r.exposureCents)} still live (running off)` : ''}` });
      continue;
    }
    const level: Level = pct >= th.creditFailPercent ? 'fail' : pct >= th.creditWarnPercent ? 'warn' : 'ok';
    const carved = r.carvedOutCents > 0n ? `, ${reais(r.carvedOutCents)} carved out for affiliates (group live ${reais(r.groupExposureCents)})` : '';
    const base = `${r.lp} (${r.tier.toLowerCase()}) uses ${pct}% of its ${reais(r.capCents)} limit: ${reais(r.exposureCents)} live${carved}, ${reais(r.availableCents)} available`;
    out.push({
      id, level, value: pct, threshold: th.creditWarnPercent,
      detail: level === 'ok' ? base
        : level === 'fail' ? `${base}. It can take no new offer, order or sale: raise its credit (lp:credit, delayed) if its record justifies it, or let positions settle`
        : `${base}. Near its limit: new positions start failing at 100%`,
    });
  }

  out.push(...disputeChecks(ledger, readings));

  for (const p of pending) {
    if (p.state === 'gone') continue;
    const id = `lp_change:${p.id.toLowerCase()}`;
    const expires = BigInt(p.expiresAt);
    if (p.state === 'waiting') {
      out.push({ id, level: 'ok', value: Number(p.onChainReadyAt) - nowSeconds, detail: `scheduled ${p.description}: executable from ${iso(p.onChainReadyAt)}, until ${iso(expires)}` });
    } else if (p.state === 'ready') {
      const left = Number(expires) - nowSeconds;
      out.push({
        id, value: left, threshold: th.changeExpiryWarnSeconds,
        level: left <= th.changeExpiryWarnSeconds ? 'warn' : 'ok',
        detail: left <= th.changeExpiryWarnSeconds
          ? `scheduled ${p.description} is executable and EXPIRES UNEXECUTED in ${hours(left)} (${iso(expires)}): lp:execute ${p.id}, or lp:cancel it if it is no longer wanted`
          : `scheduled ${p.description}: executable now, until ${iso(expires)}`,
      });
    } else {
      out.push({
        id, level: 'warn', value: nowSeconds - Number(expires), threshold: 0,
        detail: `scheduled ${p.description} EXPIRED unexecuted at ${iso(expires)}: it can never run. lp:cancel ${p.id} clears it `
          + '(deploy-movva-rail --finalize refuses while a change is queued); schedule it again if it is still wanted',
      });
    }
  }
  return out;
}

/** `lp_disputes:<lp>` and `lp_disputes:unattributed`: the escrows' disputes, the same for either registry. */
function disputeChecks(ledger: LpLedger, readings: readonly { lp: Address; disputesLost: number }[], slashNote?: string): CheckResult[] {
  const out: CheckResult[] = [];
  const byLp = new Map<string, LedgerDispute[]>();
  const unattributed: LedgerDispute[] = [];
  for (const d of Object.values(ledger.disputes)) {
    if (!d.lp) { if (d.status === 'open') unattributed.push(d); continue; }
    const k = d.lp.toLowerCase();
    byLp.set(k, [...(byLp.get(k) ?? []), d]);
  }
  for (const r of readings) if (r.disputesLost > 0 && !byLp.has(r.lp.toLowerCase())) byLp.set(r.lp.toLowerCase(), []);
  for (const [k, ds] of byLp) {
    const open = ds.filter((d) => d.status === 'open');
    const lost = readings.find((r) => r.lp.toLowerCase() === k)?.disputesLost;
    const lostText = lost !== undefined ? `; ${lost} lost in total` : '';
    out.push({
      id: `lp_disputes:${k}`, level: open.length ? 'warn' : 'ok', value: open.length, threshold: 0,
      detail: open.length
        ? `${getAddress(k)} has ${open.length} open dispute(s): ${open.map((d) => `${d.kind} ${shortId(d.id)} on ${d.escrow}`).join(', ')}${lostText}. `
          + `The arbitration desk rules; nobody ruling within DISPUTE_TIMEOUT refunds to origin${slashNote ?? ''}`
        : `${getAddress(k)} has no open dispute${lostText}`,
    });
  }
  if (unattributed.length) {
    out.push({
      id: 'lp_disputes:unattributed', level: 'warn', value: unattributed.length, threshold: 0,
      detail: `${unattributed.length} open dispute(s) the ledger cannot place with an LP (the offer or claim predates the scanned range): `
        + `${unattributed.map((d) => `${d.kind} ${shortId(d.id)} on ${d.escrow}`).join(', ')}`,
    });
  }
  return out;
}

/** Evidence that a permissionless LP lost a dispute: a `Slashed`/`DisputeLost` in the ledger, or a count the monitor saw rise. */
export interface SlashEvidence {
  /** Undefined: `totalSlashed` rose with no known LP's record explaining it. */
  lp?: Address;
  /** Unix seconds: the block's time for an event, the sweep's for an observed increase. */
  at: number;
  amountWei: bigint;
  /** Where it came from, for the detail. */
  via: string;
}

const days = (s: bigint | number) => `${(Number(s) / 86_400).toFixed(1)} days`;
const movvaValue = (wei: bigint) => Number(wei / 10n ** 16n) / 100;

/**
 * The permissionless registry's checks, from readings already taken. Pure, so the tests drive every branch.
 *
 *  - `lp_network`: the summary - bonded, leaving, slashed, live. Warns while the escrows are unbound (nobody can join,
 *    credit is 0) or an escrow does not name the registry back.
 *  - `lp_credit:<lp>`: as for the curated registry - warn at `creditWarnPercent` of the bond's credit in use, fail at
 *    `creditFailPercent`.
 *  - `lp_disputes:<lp>`, `lp_disputes:unattributed`: the escrows' open disputes, as for the curated registry.
 *  - `lp_slash:<lp>`: FAIL for `slashAlertSeconds` after the LP lost a dispute (its whole bond is gone - or, if it was
 *    already empty, nothing more was taken), then ok with the record. `lp_slash:unattributed` the same, for a rise in
 *    `totalSlashed` no known LP accounts for. A fail, not a warn: an LP's whole bond is gone, which is either an LP
 *    that cheated or a ruling that wronged an honest one, and both need a person today.
 *  - `lp_exit:<lp>`: an LP that asked to leave. Ok with nothing live; WARN while it still has exposure live (it cannot
 *    withdraw, and a dispute on that exposure can still slash it), with `withdrawableFrom` and the exposure by escrow;
 *    FAIL once `withdrawableFrom` has passed and exposure is still live - positions that should have ended have not.
 */
export function permissionlessLpChecks(
  input: { registry: BondRegistryReading; ledger: LpLedger; readings: BondedLpReading[]; slashes: SlashEvidence[]; nowSeconds: number },
  th: LpNetworkThresholds = DEFAULT_LP_NETWORK_THRESHOLDS,
): CheckResult[] {
  const { registry: g, ledger, readings, slashes, nowSeconds } = input;
  const out: CheckResult[] = [];
  const count = (st: string) => readings.filter((r) => r.standing === st).length;
  const live = readings.reduce((s, r) => s + r.exposureCents, 0n);
  const problems = [
    ...(g.escrowsBound ? [] : [`setup OPEN: the deployer ${g.deployer} has not bound the escrows, so nobody can join and every credit is 0`]),
    ...g.escrows.filter((e) => !e.pointsBack).map((e) => `the ${e.role} escrow ${e.address} does NOT name this registry`),
  ];
  out.push({
    id: 'lp_network', level: problems.length ? 'warn' : 'ok', value: count('BONDED'),
    detail: `permissionless LP registry ${g.registry} (no governor): ${count('BONDED')} bonded, ${count('EXITING')} leaving, ${count('SLASHED')} slashed and not back; `
      + `${movva(g.totalBonded)} bonded, ${movva(g.totalSlashed)} slashed for good; ${reais(live)} live${problems.length ? `. ${problems.join('; ')}` : ''}`,
  });

  for (const r of readings) {
    const id = `lp_credit:${r.lp.toLowerCase()}`;
    const pct = creditUsedPercent(r);
    if (pct === undefined) {
      const why = r.standing === 'EXITING' ? `leaving (withdrawable from ${iso(r.withdrawableFrom)})`
        : r.standing === 'SLASHED' ? 'slashed: its bond is gone and it has not bonded again'
        : r.bondWei > 0n ? 'bonded, with no credit while the escrows are unbound' : 'not bonded';
      out.push({ id, level: 'ok', detail: `${r.lp} is ${why}${r.exposureCents > 0n ? `, with ${reais(r.exposureCents)} still live (running off)` : ''}` });
      continue;
    }
    const level: Level = pct >= th.creditFailPercent ? 'fail' : pct >= th.creditWarnPercent ? 'warn' : 'ok';
    const base = `${r.lp} (bonded ${movva(r.bondWei)}) uses ${pct}% of its ${reais(r.capCents)} credit: ${reais(r.exposureCents)} live, ${reais(r.availableCents)} available`;
    out.push({
      id, level, value: pct, threshold: th.creditWarnPercent,
      detail: level === 'ok' ? base
        : level === 'fail' ? `${base}. It can take no new offer, order or sale: the LP can add to its bond (bond:topup), or let positions settle`
        : `${base}. Near its limit: new positions start failing at 100%`,
    });
  }

  out.push(...disputeChecks(ledger, readings, '; a ruling against the LP slashes its whole bond'));

  const byLp = new Map<string, SlashEvidence[]>();
  for (const e of slashes) {
    const k = e.lp ? e.lp.toLowerCase() : 'unattributed';
    byLp.set(k, [...(byLp.get(k) ?? []), e]);
  }
  for (const r of readings) if (r.disputesLost > 0 && !byLp.has(r.lp.toLowerCase())) byLp.set(r.lp.toLowerCase(), []);
  for (const [k, es] of byLp) {
    const id = `lp_slash:${k}`;
    const latest = es.reduce<SlashEvidence | undefined>((m, e) => (!m || e.at > m.at ? e : m), undefined);
    const taken = es.reduce((s, e) => s + e.amountWei, 0n);
    const r = readings.find((x) => x.lp.toLowerCase() === k);
    const who = k === 'unattributed' ? 'the registry' : getAddress(k);
    const record = r ? `; ${r.disputesLost} dispute(s) lost in total, bond now ${movva(r.bondWei)}` : '';
    if (latest && nowSeconds - latest.at < th.slashAlertSeconds) {
      const what = k === 'unattributed'
        ? `totalSlashed rose by ${movva(latest.amountWei)} by ${iso(latest.at)} and no known LP's record explains it (an LP the scanned history does not name: add it to LP_NETWORK_LPS)`
        : latest.amountWei > 0n
          ? `${who} LOST A DISPUTE at ${iso(latest.at)} (${latest.via}): ${movva(latest.amountWei)} of bond slashed and locked for ever`
          : `${who} LOST A DISPUTE at ${iso(latest.at)} (${latest.via}); its bond was already empty, so nothing more was taken`;
      out.push({
        id, level: 'fail', value: movvaValue(taken), threshold: 0,
        detail: `${what}${record}. Its credit is 0 until it bonds again, and anyone may close its standing offers (closeOffer). `
          + 'Check the ruling on the arbitration desk: a slash cannot be undone',
      });
    } else {
      out.push({
        id, level: 'ok', value: movvaValue(taken), threshold: 0,
        detail: latest ? `${who}: last lost dispute at ${iso(latest.at)}, ${movva(taken)} slashed in the scanned history${record}` : `${who}: lost disputes before the scanned history${record}`,
      });
    }
  }

  for (const r of readings) {
    if (!r.exiting) continue;
    const id = `lp_exit:${r.lp.toLowerCase()}`;
    const where = r.reservedBy.filter((x) => x.cents > 0n).map((x) => `${x.role} ${reais(x.cents)}`).join(', ');
    const due = nowSeconds >= Number(r.withdrawableFrom);
    if (r.exposureCents === 0n) {
      out.push({
        id, level: 'ok', value: 0, threshold: 0,
        detail: due ? `${r.lp} is leaving: unbonded since ${iso(r.withdrawableFrom)} with nothing live - it can withdraw ${movva(r.bondWei)} now (bond:withdraw)`
          : `${r.lp} is leaving with nothing live: ${movva(r.bondWei)} withdrawable from ${iso(r.withdrawableFrom)} (in ${days(Number(r.withdrawableFrom) - nowSeconds)})`,
      });
    } else if (!due) {
      out.push({
        id, level: 'warn', value: Number(r.exposureCents), threshold: 0,
        detail: `${r.lp} is LEAVING with ${reais(r.exposureCents)} still live${where ? ` (${where})` : ''}: withdrawable from ${iso(r.withdrawableFrom)} `
          + `(in ${days(Number(r.withdrawableFrom) - nowSeconds)}) only once that has settled or ended; until then a dispute on it can still slash its ${movva(r.bondWei)} bond. `
          + 'Its credit is 0: anyone may close its standing offers (closeOffer)',
      });
    } else {
      out.push({
        id, level: 'fail', value: Number(r.exposureCents), threshold: 0,
        detail: `${r.lp}'s unbonding ended at ${iso(r.withdrawableFrom)} but ${reais(r.exposureCents)} is STILL LIVE${where ? ` (${where})` : ''}: the ${movva(r.bondWei)} bond cannot leave `
          + 'and stays answerable. End the positions: closeOffer on its offers, reclaimExpired / releaseStaleClaim on expired orders and claims, expireDispute once a dispute times out',
      });
    }
  }
  return out;
}

export interface LpNetworkWatchOptions {
  client: LogClient & ReadClient;
  registry: Address;
  /** FiatEscrow and OffRampEscrow, for disputes. */
  escrows?: Address[];
  /** MovvaReserve, for each LP's gateway status (shown in details only). */
  reserve?: Address;
  /** The registry's deployment block. */
  fromBlock: bigint;
  /** LPs to watch even if the scanned history never names them. */
  lps?: Address[];
  /** Start from this ledger (the CLI's, say) instead of reading from `fromBlock`; it is synced forward from its cursor. */
  ledger?: LpLedger;
  thresholds?: Partial<LpNetworkThresholds>;
  read?: ReadLogsOptions;
  redactValues?: readonly (string | undefined)[];
}

/**
 * The monitor's LP-network watcher: keeps a ledger in memory across sweeps (the first sweep reads from `fromBlock`) and
 * reports `lpNetworkChecks`, or `permissionlessLpChecks` when the registry is a PermissionlessLPRegistry (detected on
 * the first sweep that can read it). A change that executes or is cancelled, and an exit that ends, is reported `ok`
 * once, resolving its alert, then forgotten; a sync or read failure is `unknown`, never `ok`.
 *
 * On a permissionless registry it also compares each sweep with the one before: an LP whose `disputesLost` rose, or a
 * `totalSlashed` that rose, with no `Slashed`/`DisputeLost` in the newly scanned blocks to explain it (a log the ledger
 * could not read, an LP it does not know), is a slash all the same, and `lp_slash:*` fails on it.
 */
export class LpNetworkWatcher {
  readonly ledger: LpLedger;
  private reported = new Set<string>();
  private readonly th: LpNetworkThresholds;
  private kind?: RegistryKind;
  /** Permissionless: the previous sweep's view, and the slashes seen only as a count that rose. */
  private last?: { totalSlashed: bigint; lost: Map<string, number>; bond: Map<string, bigint> };
  private observed: SlashEvidence[] = [];

  constructor(private readonly o: LpNetworkWatchOptions) {
    this.ledger = o.ledger ?? emptyLedger({ registry: o.registry, escrows: o.escrows, fromBlock: o.fromBlock });
    this.th = { ...DEFAULT_LP_NETWORK_THRESHOLDS, ...o.thresholds };
  }

  async sweep(nowSeconds: number = Math.floor(Date.now() / 1000)): Promise<CheckResult[]> {
    const secrets = this.o.redactValues ?? [];
    try {
      this.kind ??= await detectRegistryKind(this.o.client, this.o.registry);
    } catch (e) {
      return [{ id: 'lp_network', level: 'unknown', detail: `the LP network could not be read: ${redactError(e, secrets)}` }];
    }
    this.ledger.kind = this.kind;
    return this.kind === 'permissionless' ? this.sweepPermissionless(nowSeconds, secrets) : this.sweepCurated(nowSeconds, secrets);
  }

  private addresses(): Address[] {
    const addresses = new Map<string, Address>();
    for (const v of Object.values(this.ledger.lps)) addresses.set(v.address.toLowerCase(), v.address);
    for (const a of this.o.lps ?? []) addresses.set(a.toLowerCase(), getAddress(a));
    return [...addresses.values()];
  }

  /** Ids reported last sweep and absent now: `ok` once, so their alert resolves, then forgotten. */
  private settle(results: CheckResult[], prefixes: string[], gone: (id: string) => string): void {
    const now = new Set(results.filter((r) => prefixes.some((p) => r.id.startsWith(p))).map((r) => r.id));
    for (const id of this.reported) {
      if (now.has(id)) continue;
      results.push({ id, level: 'ok', detail: gone(id) });
      this.reported.delete(id);
    }
    for (const id of now) this.reported.add(id);
  }

  private async sweepCurated(nowSeconds: number, secrets: readonly (string | undefined)[]): Promise<CheckResult[]> {
    let registry: RegistryReading;
    let pending: PendingChange[];
    try {
      await syncLedger(this.o.client, this.ledger, this.o.read);
      registry = await readRegistry(this.o.client, this.o.registry);
      pending = await pendingChanges(this.o.client, this.ledger, nowSeconds);
    } catch (e) {
      return [{ id: 'lp_network', level: 'unknown', detail: `the LP network could not be read: ${redactError(e, secrets)}` }];
    }
    const readings: LpReading[] = [];
    const failed: CheckResult[] = [];
    await Promise.all(this.addresses().map(async (lp) => {
      try { readings.push(await readLp(this.o.client, this.o.registry, lp, this.o.reserve)); } catch (e) {
        failed.push({ id: `lp_credit:${lp.toLowerCase()}`, level: 'unknown', detail: `${lp} could not be read: ${redactError(e, secrets)}` });
      }
    }));
    readings.sort((a, b) => a.lp.localeCompare(b.lp));
    const results = [...lpNetworkChecks({ registry, ledger: this.ledger, readings, pending, nowSeconds }, this.th), ...failed];
    this.settle(results, ['lp_change:'], (id) => {
      const c = this.ledger.changes[id.slice('lp_change:'.length)];
      return `scheduled ${c ? describeRegistryCall(c.call) : 'change'} ${c?.status === 'executed' ? 'executed' : c?.status === 'cancelled' ? 'was cancelled' : 'is no longer queued'}`;
    });
    return results;
  }

  private async sweepPermissionless(nowSeconds: number, secrets: readonly (string | undefined)[]): Promise<CheckResult[]> {
    let registry: BondRegistryReading;
    const before = this.ledger.slashes?.length ?? 0;
    try {
      registry = await readBondRegistry(this.o.client, this.o.registry);
      // The escrows a permissionless registry is bound to are fixed for ever and are the only ones that can report its
      // LPs' disputes, so they are read from it rather than trusted to configuration - before the first scan, so the
      // scan covers them from the start.
      if (this.ledger.scannedTo === undefined && registry.escrowsBound) {
        this.ledger.escrows = [registry.fiatEscrow, registry.offRampEscrow].map((a) => getAddress(a));
      }
      await syncLedger(this.o.client, this.ledger, this.o.read);
    } catch (e) {
      return [{ id: 'lp_network', level: 'unknown', detail: `the LP network could not be read: ${redactError(e, secrets)}` }];
    }
    const readings: BondedLpReading[] = [];
    const failed: CheckResult[] = [];
    await Promise.all(this.addresses().map(async (lp) => {
      try { readings.push(await readBondedLp(this.o.client, registry, lp)); } catch (e) {
        failed.push({ id: `lp_credit:${lp.toLowerCase()}`, level: 'unknown', detail: `${lp} could not be read: ${redactError(e, secrets)}` });
      }
    }));
    readings.sort((a, b) => a.lp.localeCompare(b.lp));

    const fresh = (this.ledger.slashes ?? []).slice(before);
    if (this.last) {
      let explained = fresh.reduce((s, x) => s + BigInt(x.amountWei), 0n);
      for (const r of readings) {
        const k = r.lp.toLowerCase();
        const was = this.last.lost.get(k);
        if (was === undefined || r.disputesLost <= was || fresh.some((x) => isAddressEqual(x.lp, r.lp))) continue;
        const prevBond = this.last.bond.get(k) ?? 0n;
        const took = prevBond > r.bondWei ? prevBond - r.bondWei : 0n;
        explained += took;
        this.observed.push({ lp: r.lp, at: nowSeconds, amountWei: took, via: `disputesLost rose from ${was} to ${r.disputesLost} between sweeps` });
      }
      const rose = registry.totalSlashed - this.last.totalSlashed;
      if (rose > explained) this.observed.push({ at: nowSeconds, amountWei: rose - explained, via: 'totalSlashed rose between sweeps' });
    }
    this.last = {
      totalSlashed: registry.totalSlashed,
      lost: new Map(readings.map((r) => [r.lp.toLowerCase(), r.disputesLost])),
      bond: new Map(readings.map((r) => [r.lp.toLowerCase(), r.bondWei])),
    };
    // Forget what no longer matters: an observation past its alert window is history the ledger or the record keeps.
    this.observed = this.observed.filter((e) => nowSeconds - e.at < this.th.slashAlertSeconds);
    const slashes: SlashEvidence[] = [
      ...(this.ledger.slashes ?? []).map((x) => ({
        lp: x.lp, at: Number(x.at ?? nowSeconds), amountWei: BigInt(x.amountWei),
        via: x.escrow ? `Slashed by ${x.escrow} in block ${x.block}` : `DisputeLost in block ${x.block}`,
      })),
      ...this.observed,
    ];
    const results = [...permissionlessLpChecks({ registry, ledger: this.ledger, readings, slashes, nowSeconds }, this.th), ...failed];
    this.settle(results, ['lp_exit:', 'lp_slash:'], (id) => {
      if (id.startsWith('lp_slash:')) return `${id.slice('lp_slash:'.length)}: the slash is past its alert window (LP_SLASH_ALERT_SECONDS)`;
      const lp = id.slice('lp_exit:'.length);
      const done = [...(this.ledger.exits ?? [])].reverse().find((e) => e.lp.toLowerCase() === lp && e.status === 'withdrawn');
      return `${getAddress(lp)} is no longer leaving${done ? `: withdrew ${movva(BigInt(done.withdrawnWei ?? '0'))} in block ${done.withdrawnBlock}` : ''}`;
    });
    return results;
  }
}
