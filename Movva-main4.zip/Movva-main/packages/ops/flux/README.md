# Running the off-chain services on Flux

Rev. 2 §9 puts the relayers, watchers and keepers on Flux, replicated. This
directory holds the application specifications and what you need to know to register them.

## What can and cannot be replicated

The premise that makes Flux workable here is that **most of these services hold no key**.

| Service | Holds a key? | Safe to replicate on machines you do not control |
|---|---|---|
| Monitor | No — `eth_call` and `eth_getBalance` only | Yes. A compromised replica leaks public data and can move nothing. |
| Matcher | No — rebuilds the order book from logs, answers quotes | Yes. A lying matcher routes someone to a worse price; the escrow re-checks at lock time. |
| Note vault | No — stores ciphertext, never receives a viewing key; every request proves its sender | Yes. A compromised replica leaks record counts and timing, and can refuse to serve; it cannot widen what an auditor reads. Wallets file with every replica. |
| Relayer | **Yes** — pays gas, submits withdrawals | Only with a per-instance key and a spend limit. See below. |
| Arbitration desk | **Yes** — signs rulings | Not as-is. See below. |
| ASP postman | **Yes** — publishes association-set roots | Not as-is. See below. |
| Co-signer | **Yes** — an owner of every user's Safe and the co-signer of every Kernel account, plus FROST shares | **Never.** See below. |

**The ones that cannot simply be replicated, and why.** Replication means the key exists on
every node running the app. Flux nodes are operated by strangers, so a key placed in an
application's environment should be treated as disclosed:

- **The arbitration desk** signs rulings that move disputed escrow to one side. Its key must
  live in your own infrastructure, with only its public address registered on-chain via
  `admin escrow:arbitrator`. That is why there is no `arbitration.json` here: self-host it
  with `docker compose --profile arbitration` (see `../docker-compose.yml`), which runs
  `packages/ramp/src/bin/arbitration.ts` from the same image.
- **The ASP postman** decides which deposits are withdrawable by proof. Same reasoning.
- **The co-signer** (`packages/cosigner`) holds the server half of every user's 2-of-2 account: an ECDSA key
  that is a Safe owner and a PasskeyCoSignerValidator co-signer, and the server's FROST shares. On its own it
  can only refuse, but that key plus one stolen passkey spends immediately, and a Flux operator who read it
  would hold the server half of every account at once. It runs only in your own infrastructure, with the key
  in a KMS or HSM (`COSIGNER_KMS_MODULE`; a key file is refused in production mode unless explicitly allowed):
  `docker compose --profile cosigner`, which runs `packages/cosigner/src/bin/cosigner.ts` from the same
  image, one instance per key and audit log. There is no `cosigner.json` here, and
  `packages/ops/test/packaging.test.ts` fails if any Flux spec launches it.

Neither can move funds on its own, but neither being down is free. A `DISPUTED` order moves only
on a ruling signed by a registered arbitrator - which anyone may submit, and which waits
`RULING_DELAY` (a day) in public before it executes - or, once `DISPUTE_TIMEOUT` passes with no
ruling (30 days by default, fixed at deployment between 7 and 90), on `expireDispute`, which anyone
may send (`admin escrow:expire-dispute`) and which refunds to origin: on-ramp liquidity to the LP's
offer, off-ramp crypto to the seller's refund address. So a dead desk freezes disputed escrow until
that timeout, and then the funds go back without the dispute being decided. And a dead postman
leaves ragequit as the exit, which for our users is a Safe transaction that needs the server
co-signer.
`docs/availability.md` sets out exactly what survives each service dying, and what does not.

**The relayer** sits in between. Replicating it needs one key per instance, each funded with
a small float, so a compromised node costs that float and nothing more. Do not run several
instances from one key: they will race on nonces and stall each other.

## Registering the applications

You need a Flux account, a small FLUX balance for the registration and collateral, and a
published container image. The specs here are the declarative half; the rest is done in the
Flux dashboard or via `flux-cli`.

```bash
# Build and push the shared image (from the repository root)
docker build -f packages/ops/Dockerfile -t <registry>/mova-ops:<tag> .
docker push <registry>/mova-ops:<tag>

# Then register each app with the spec files here, substituting your image reference.
```

`monitor.json`, `matcher.json` and `vault.json` are complete specs for the three keyless services. Each
declares:

- **the health endpoint** Flux polls to decide whether an instance is alive (`/healthz`
  for the monitor, `/health` for the matcher — the matcher returns 503 when its own sync is
  broken, which is the behaviour you want a load balancer to see);
- **three instances**, so the loss of one node is invisible;
- **environment variables** by name only. Fill the values at registration time; the RPC URL
  carries an API key and does not belong in a file in this repository. The matcher also
  needs `FROM_BLOCK`, the escrow's deployment block, and refuses to start without it.

Both run production entrypoints (`packages/ops/src/bin/monitor.ts`,
`packages/ramp/src/bin/matcher.ts`), never anything under `examples/`: those deploy mock
contracts with well-known test keys. `packages/ops/test/packaging.test.ts` fails if a spec,
the compose file or the Dockerfile points at a script that is missing, lives in `examples/`,
or launches something the `--omit=dev` image does not install.

The keepers - `vault-keeper.json`, `hl-keeper.json` and `pyth-keeper.json` - hold a
signing key each, and run on Flux only because no keeper key can pay itself. Register each spec **once per
replica**, with `instances: 1`, its own `REPLICA_INDEX` and its own key: Flux gives every instance of one app
the same environment, so three instances would share one key. What a leaked key costs is in each spec's
`_notes`: for the vault keeper, churn bounded by `KeeperGate`'s turnover budget; for the HyperEVM keeper, the
bounded rebalances; for the Pyth keeper, nothing but the gas float, because Pyth's `updatePriceFeeds` is open
to anyone and the key holds no role, so nothing is registered on-chain for it - it is safe to replicate on nodes
you do not control.

The Pyth keeper keeps FX.USD/BRL posted on Ethereum, so `PythFxOracle` - the reserve's FX leg and the
ramps' USDT and ETH bands - has a rate while the FX market trades; if every replica is down, minting and
redeeming wait and the bands refuse inside the core session, and anyone can post an update to recover. It
also carries Mova's Hermes credential, as the Flux secret `HERMES_API_KEY`: Hermes' hosted gateway refuses
price updates without one. A leaked credential costs a rotation at Pyth, not funds.

Neither service returns a raw error to a caller: an RPC failure's message carries the RPC URL
and so the provider's API key, and `/status`, `/health` and the alert webhook all pass error
text through `src/redact.ts`, which cuts every URL down to scheme and host.

## After registering

1. Point your monitoring at `https://<app>.app.runonflux.io/metrics` and confirm the series
   appear. A scrape that returns 503 means no sweep has completed yet — wait one interval.
2. Set `ALERT_WEBHOOK` so alerts reach a channel someone reads. Without it the monitor logs
   to stdout, which on a replicated deployment means nobody sees them.
3. Check `/status` once by hand. It reports the verdict, the firing checks and every reading,
   which is the fastest way to confirm the addresses were configured correctly — a monitor
   watching nothing reports `ok` forever and that is indistinguishable from health.
