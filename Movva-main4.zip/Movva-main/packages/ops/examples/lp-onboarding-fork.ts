/**
 * LP ONBOARDING REHEARSAL on an anvil fork of Sepolia: the `lp` CLI admits a second test LP to the live MOVVA-only rail's
 * registry end to end - schedule -> warp GOVERNANCE_DELAY -> execute -> status shows it -> suspend - and the monitor's LP
 * network checks are run against the result. Nothing is sent to Sepolia: every transaction goes to the fork.
 *
 *   npx tsx packages/ops/examples/lp-onboarding-fork.ts [--port 8966|8967] [--rail <record>] [--out <json>]
 *
 * Env (the process first, then the repo's .env): SEPOLIA_RPC (the fork's upstream) and the rail's governor key,
 * SEPOLIA_RAIL2_DEPLOYER_KEY (the MOVVA-only rail's deployer, which still governs it). Neither is ever printed: every
 * line of output, the CLI's included, passes through a redaction of every .env value.
 *
 * Each step runs the real CLI (`packages/ops/src/bin/lp.ts`) as a subprocess with RPC_URL pointed at the fork and
 * GOVERNOR_KEY set, so what is rehearsed is exactly what an operator runs; the steps that must be refused are checked to
 * be refused, with the exit code the CLI gives them. The ledger is a scratch file, never the rail's.
 */
import { spawn, type ChildProcess } from 'node:child_process';
import { mkdtempSync, readFileSync, writeFileSync, existsSync } from 'node:fs';
import { createServer } from 'node:net';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createPublicClient, http, isAddressEqual, type Hex } from 'viem';
import { generatePrivateKey, privateKeyToAccount } from 'viem/accounts';
import { LpNetworkWatcher, liveExposure, readLp, readRegistry, type LpLedger } from '../src/lp-network.js';
import { parseRail } from '../src/bin/lp.js';

const ROOT = fileURLToPath(new URL('../../../', import.meta.url));
const ANVIL = join(ROOT, '.foundry-pinned/v0.3.0/anvil');
const CLI = join(ROOT, 'packages/ops/src/bin/lp.ts');
const TSX = join(ROOT, 'node_modules/.bin/tsx');
/** This script's ports: other sessions use anvil's defaults and 8968-8969. */
const PORTS = [8966, 8967];

const DOTENV: Record<string, string> = (() => {
  const f = join(ROOT, '.env');
  if (!existsSync(f)) return {};
  const out: Record<string, string> = {};
  for (const line of readFileSync(f, 'utf8').split('\n')) {
    const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/.exec(line);
    if (m) out[m[1]!] = m[2]!.replace(/^["']|["']$/g, '');
  }
  return out;
})();
const env = (k: string) => process.env[k] || DOTENV[k] || undefined;
const SECRETS = [...Object.values(DOTENV), env('SEPOLIA_RPC')].filter((s): s is string => !!s && s.length >= 8);
const redact = (t: string) => SECRETS.reduce((x, s) => x.split(s).join('[redacted]'), t);
const say = (...p: unknown[]) => console.log(redact(p.map(String).join(' ')));
const arg = (name: string) => { const i = process.argv.indexOf(name); return i > 0 ? process.argv[i + 1] : undefined; };

async function rpc<T>(url: string, method: string, params: unknown[] = []): Promise<T> {
  const r = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ jsonrpc: '2.0', id: 1, method, params }) });
  const j = await r.json() as { result?: T; error?: { message: string } };
  if (j.error) throw new Error(j.error.message);
  return j.result as T;
}

const portBusy = (port: number) => new Promise<boolean>((resolve) => {
  const s = createServer().once('error', () => resolve(true)).once('listening', () => s.close(() => resolve(false))).listen(port, '127.0.0.1');
});

async function startFork(upstream: string, port: number, work: string): Promise<{ url: string; child: ChildProcess }> {
  if (!PORTS.includes(port)) throw new Error(`--port ${port}: this rehearsal uses ${PORTS.join(', ')} only`);
  if (await portBusy(port)) throw new Error(`port ${port} is in use: pick another of ${PORTS.join(', ')}`);
  const child = spawn(ANVIL, ['--fork-url', upstream, '--port', String(port), '--host', '127.0.0.1', '--retries', '10', '--fork-retry-backoff', '1000'], { stdio: ['ignore', 'pipe', 'pipe'] });
  let log = '';
  child.stdout?.on('data', (b) => (log += b));
  child.stderr?.on('data', (b) => (log += b));
  child.on('close', () => writeFileSync(join(work, 'anvil.log'), redact(log)));
  const url = `http://127.0.0.1:${port}`;
  for (let i = 0; i < 120; i++) {
    if (child.exitCode !== null) throw new Error(`anvil exited ${child.exitCode}; see ${join(work, 'anvil.log')}`);
    try { await rpc(url, 'eth_chainId'); return { url, child }; } catch { await new Promise((r) => setTimeout(r, 500)); }
  }
  child.kill();
  throw new Error('anvil did not answer within 60 s');
}

interface Step { name: string; argv: string[]; code: number; expect: number; ok: boolean; out: string }

async function main(): Promise<void> {
  const railPath = arg('--rail') ?? join(ROOT, 'deployments/sepolia-movva-only-rail.json');
  const port = Number(arg('--port') ?? 8966);
  const work = mkdtempSync(join(tmpdir(), 'lp-onboarding-fork-'));
  const out = arg('--out') ?? join(work, 'record.json');
  const upstream = env('SEPOLIA_RPC');
  const govKey = env('SEPOLIA_RAIL2_DEPLOYER_KEY') as Hex | undefined;
  if (!upstream) throw new Error('SEPOLIA_RPC is not set (process env or .env)');
  if (!govKey) throw new Error('SEPOLIA_RAIL2_DEPLOYER_KEY is not set (process env or .env)');
  const rail = parseRail(railPath, readFileSync(railPath, 'utf8'));
  if (!rail.registry) throw new Error(`${railPath} names no registry`);
  const registry = rail.registry;
  const governor = privateKeyToAccount(govKey).address;
  const ledgerPath = join(work, 'lp-ledger.json');

  const fork = await startFork(upstream, port, work);
  const steps: Step[] = [];
  const started = new Date().toISOString();
  try {
    const client = createPublicClient({ transport: http(fork.url) });
    const forkBlock = await client.getBlockNumber();
    say(`anvil fork of Sepolia on ${fork.url} at block ${forkBlock}; registry ${registry}; work dir ${work}`);
    const reg0 = await readRegistry(client, registry);
    if (!isAddressEqual(reg0.governor, governor)) throw new Error(`the registry's governor is ${reg0.governor}, not the key's ${governor}`);
    say(`governor ${governor} (the key's address matches); phase ${reg0.phase}; delay ${reg0.delaySeconds} s`);
    // The fork's copy of the governor pays for its own transactions; top it up on the fork only.
    await rpc(fork.url, 'anvil_setBalance', [governor, '0x8AC7230489E80000']);

    const lpKey = generatePrivateKey();
    const lp = privateKeyToAccount(lpKey).address;
    const credit = '1000000'; // R$ 10.000,00
    say(`second test LP: ${lp} (a fresh key, fork only), credit ${credit} centavos`);

    const cli = async (name: string, argv: string[], expect = 0): Promise<Step> => {
      const child = spawn(TSX, [CLI, ...argv, '--rail', railPath], {
        cwd: ROOT, env: { ...process.env, RPC_URL: fork.url, GOVERNOR_KEY: govKey, LP_LEDGER: ledgerPath }, stdio: ['ignore', 'pipe', 'pipe'],
      });
      let text = '';
      child.stdout.on('data', (b) => (text += b));
      child.stderr.on('data', (b) => (text += b));
      const code: number = await new Promise((r) => child.on('close', (c) => r(c ?? -1)));
      const s: Step = { name, argv, code, expect, ok: code === expect, out: redact(text) };
      steps.push(s);
      say(`\n===== ${name}: lp ${argv.join(' ')}  -> exit ${code}${s.ok ? '' : ` (EXPECTED ${expect})`}`);
      say(s.out.trimEnd().split('\n').map((l) => `  | ${l}`).join('\n'));
      if (!s.ok) throw new Error(`step "${name}" exited ${code}, expected ${expect}`);
      return s;
    };

    await cli('status before (reads the registry\'s history from its deploy block)', ['lp:status']);
    await cli('admit, dry run', ['lp:admit', lp, 'INSTITUTIONAL', credit]);
    await cli('admit with --execute but no --confirm: refused', ['lp:admit', lp, 'INSTITUTIONAL', credit, '--execute'], 2);
    await cli('admit with --confirm naming another LP: refused', ['lp:admit', lp, 'INSTITUTIONAL', credit, '--execute', '--confirm', rail.lps[0] ?? registry], 2);
    const admit = await cli('admit: schedule setTier', ['lp:admit', lp, 'INSTITUTIONAL', credit, '--execute', '--confirm', lp]);
    const id = /scheduled id (0x[0-9a-f]{64})/.exec(admit.out)?.[1] as Hex | undefined;
    if (!id) throw new Error('the admission printed no scheduled id');
    await cli('pending: the admission waits', ['lp:pending']);
    await cli('execute before readyAt: refused', ['lp:execute', id, '--execute', '--confirm', id], 1);
    await cli('admit again while scheduled: refused', ['lp:admit', lp, 'INSTITUTIONAL', credit], 1);

    const warp = Number(reg0.delaySeconds) + 60;
    await rpc(fork.url, 'evm_increaseTime', [warp]);
    await rpc(fork.url, 'evm_mine', []);
    say(`\n[warp] the fork's clock moves ${warp} s (GOVERNANCE_DELAY + 60 s)`);

    await cli('execute, dry run', ['lp:execute', id]);
    await cli('execute', ['lp:execute', id, '--execute', '--confirm', id]);
    const admitted = await cli('status: the new LP', ['lp:status', lp]);
    const afterAdmit = await readLp(client, registry, lp, rail.reserve);
    if (afterAdmit.tier !== 'INSTITUTIONAL' || afterAdmit.creditCents !== BigInt(credit)) throw new Error(`after execute the LP is ${afterAdmit.tier} with ${afterAdmit.creditCents}`);
    if (!/INSTITUTIONAL/.test(admitted.out) || !/credit R\$ 10\.000,00/.test(admitted.out)) throw new Error('lp:status did not show the admitted LP');

    await cli('credit raise, dry run (scheduled)', ['lp:credit', lp, '2000000']);
    await cli('credit cut: instant', ['lp:credit', lp, '500000', '--execute', '--confirm', lp]);
    if ((await readLp(client, registry, lp)).creditCents !== 500_000n) throw new Error('the credit cut did not apply');
    if (rail.lps[0]) await cli('remove the existing test LP, dry run (refused if it has exposure live)', ['lp:remove', rail.lps[0]], liveExposure(await readLp(client, registry, rail.lps[0])) > 0n ? 1 : 0);
    await cli('phase B, dry run (shows the before-finalization warning)', ['lp:phase', 'B']);

    await cli('suspend', ['lp:suspend', lp, '--execute', '--confirm', lp]);
    const suspended = await cli('status: suspended', ['lp:status', lp]);
    const afterSuspend = await readLp(client, registry, lp);
    if (afterSuspend.tier !== 'SUSPENDED' || !/suspended: yes/.test(suspended.out)) throw new Error(`after suspend the LP is ${afterSuspend.tier}`);
    await cli('remove the suspended LP, dry run (nothing live, so not refused)', ['lp:remove', lp]);

    // The monitor: its LP network checks over the same ledger, then a change left to approach its expiry.
    const ledger = JSON.parse(readFileSync(ledgerPath, 'utf8')) as LpLedger;
    const watcher = new LpNetworkWatcher({ client, registry, escrows: rail.escrows, reserve: rail.reserve, fromBlock: rail.fromBlock ?? 0n, ledger, lps: rail.lps });
    const now = async () => Number((await client.getBlock()).timestamp);
    const sweep1 = await watcher.sweep(await now());
    say('\n===== monitor sweep after the onboarding');
    for (const r of sweep1) say(`  ${r.level.padEnd(7)} ${r.id}: ${r.detail}`);
    const raise = await cli('schedule its reinstatement, to leave it near expiry', ['lp:admit', lp, 'INSTITUTIONAL', '100', '--reinstate', '--execute', '--confirm', lp]);
    const raiseId = /scheduled id (0x[0-9a-f]{64})/.exec(raise.out)?.[1] as Hex;
    const near = Number(reg0.delaySeconds) + Number(reg0.windowSeconds) - 2 * 86_400;
    await rpc(fork.url, 'evm_increaseTime', [near]);
    await rpc(fork.url, 'evm_mine', []);
    say(`\n[warp] ${near} s: the change is ready and two days from expiring`);
    const sweep2 = await watcher.sweep(await now());
    say('===== monitor sweep with a change about to expire unexecuted');
    for (const r of sweep2) say(`  ${r.level.padEnd(7)} ${r.id}: ${r.detail}`);
    const expiring = sweep2.find((r) => r.id === `lp_change:${raiseId.toLowerCase()}`);
    if (expiring?.level !== 'warn') throw new Error(`lp_change for ${raiseId} is ${expiring?.level}, expected warn`);
    await cli('cancel it', ['lp:cancel', raiseId, '--execute', '--confirm', raiseId]);
    await cli('pending: nothing waits', ['lp:pending']);

    const record = {
      rehearsal: 'LP onboarding on an anvil fork of Sepolia (nothing sent to Sepolia)', started, finished: new Date().toISOString(),
      rail: railPath.replace(ROOT, ''), registry, forkBlock: forkBlock.toString(), governor, lp, credit,
      changeId: id, steps: steps.map(({ name, argv, code, expect, ok }) => ({ name, argv: argv.map((a) => (a === govKey ? '[redacted]' : a)), code, expect, ok })),
      final: { tier: afterSuspend.tier, creditCents: afterSuspend.creditCents.toString() },
      monitor: { afterOnboarding: sweep1, nearExpiry: sweep2.filter((x) => x.id.startsWith('lp_change')) },
    };
    writeFileSync(out, redact(JSON.stringify(record, (_k, v) => (typeof v === 'bigint' ? v.toString() : v), 2)));
    say(`\nREHEARSAL PASSED: ${steps.length} CLI steps (${steps.filter((s) => s.expect !== 0).length} refusals as expected); record ${out}`);
  } finally {
    fork.child.kill();
  }
}

main().catch((e) => {
  console.error(`\nREHEARSAL FAILED: ${redact(String((e as Error)?.message ?? e))}`);
  process.exit(1);
});
