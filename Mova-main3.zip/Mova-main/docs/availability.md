# Availability — what survives a service dying

The handoff states an invariant for every off-chain service:

> if any service dies or is compromised, no user loses funds or access

This document records, service by service, whether that is true. **It holds for the account
layer** as long as three conditions are met: the account has the delayed recovery module
installed (installed at creation), the user's seed comes from a PRF passkey or the 2-of-3
recoverable split, and the service failure comes alone. **It still does not hold for the ramp**,
and some combinations of failures still cost funds. The account-layer detail, including
the full failure matrix, is in [wallet-custody.md](wallet-custody.md).

What holds:

- **No single compromised service can take a user's funds held by the account.** Spending needs
  both Safe owners (passkey and server), or both FROST shares. The server alone cannot queue,
  veto or execute early on the recovery module.
- **The server co-signer dying costs a delay, not funds or access.** The passkey alone queues
  any Safe transaction on a Zodiac Delay module. After a 7-day cooldown anyone executes it:
  a ragequit, a rescue, or `swapOwner` to replace the dead server. This is performed on mainnet
  state in `contracts/test/PasskeyRecoveryFork.t.sol`.
- **A private withdrawal of an ASP-approved deposit needs no service of ours and no account
  signature.** It needs only the spending key, a posted ASP root, and gas from any address.
- **Losing the server's seed share no longer loses a non-PRF user's funds.** The seed is split
  2-of-3 (device, server, recovery code), and any two rebuild it.

What does not hold:

- **Some combinations still cost funds.** Server dead *and* passkey compromised: the attacker's
  queued drain cannot be vetoed. Server and passkey both compromised: that is the 2-of-2 itself.
- **Accounts outside the conditions above keep the old failure modes.** A Safe created without
  the recovery module still freezes non-ASP deposits when the server dies. A legacy
  `SplitSeedSource` (XOR) wallet not yet migrated still loses its seed with the server share.
- **A compromised passkey on a PRF wallet loses ASP-approved shielded funds at once.** The PRF
  yields the spending key, and a withdrawal needs no account signature. No account-layer control
  can intervene.
- **The ramp:** colluding zkTLS witnesses can release an LP's escrow without a payment. A
  compromised arbitrator key can misallocate disputed escrow if nobody revokes it within the
  day its rulings wait before executing. Disputed escrow is frozen at most `DISPUTE_TIMEOUT`
  (30 days by default), then anyone refunds it to origin.

The sections below give the mechanism for each, and the summary table at the end is the short
form.

## Private withdrawal: needs no account signature

`PrivacyPool.withdraw` checks three things: a groth16 proof over the user's own commitment
secrets, an ASP root that contains the deposit's label, and that the caller is the
`processooor` named in the proof. A relayed withdrawal names the Entrypoint as processooor and
the relayer submits it. A self-submitted one names whatever address sends it. **Neither is signed
by the user's account**: not by the Safe, not by a FROST group, not by the co-signer. The user
builds the proof offline from the spending key and signs nothing on-chain
(`packages/viewing-key/examples/relayed-withdraw.ts` asserts the recipient ends up funded with a
transaction count of zero).

So losing the co-signer, the relayer or the paymaster does not stop a private withdrawal. The
ASP does: with no root containing the deposit, there is no withdrawal by proof.

The same property cuts the other way. **Whoever holds the spending key can withdraw
ASP-approved notes**, and for a PRF wallet the spending key is derived from the passkey alone.

## Ragequit: the escape hatch, and who can pull it

Reading the contract, `PrivacyPool.ragequit` requires:

- `depositors[label] == msg.sender`: the caller **is the original depositor** of the label,
- a valid `commitment` proof over the depositor's own secrets,
- the commitment is present in the tree and its nullifier unspent.

It does **not** require an ASP root, a relayer, a bundler, a paymaster, an indexer, or any key
material we hold. That makes it the exit when the ASP will not approve a deposit.
`packages/viewing-key/examples/escape-hatch.ts` proves the mechanism end to end on a mainnet
fork with every service of ours off, for an EOA depositor.

**For our users the depositor is a Safe with two owners, passkey and server.** A Safe transaction
needs both. Without anything more, ragequit therefore needed the server, and a dead server with
a deposit not in an ASP root meant frozen funds. The same held for `FiatEscrow.rescueShielded`,
which requires `msg.sender == recipient` (as did `ShieldedYieldRouter.rescue`, removed with savings by client
decision D1, 14 October 2026).

**The recovery module removes that dependency** (`packages/smart-account/src/recovery.ts`):

```
Safe ──module──▶ Zodiac Delay Modifier 1.1.1 (owner = avatar = target = the Safe)
                     ▲ module
                     └── the passkey's SafeWebAuthnSigner

passkey alone signs a queue request ─▶ any address relays it ─▶ TransactionAdded (public)
7-day cooldown: the owners (passkey + server) may veto with setTxNonce
after it: anyone calls executeNextTx ─▶ the call runs AS THE SAFE (msg.sender == depositor)
```

`contracts/test/PasskeyRecoveryFork.t.sol` runs against the real Safe 1.4.1, Safe4337Module,
SafeWebAuthnSigner and Delay 1.1.1 on mainnet state. It proves each of the following:

- the passkey alone queues;
- execution is refused one second before the cooldown ends and accepted at it;
- a depositor-only exit returns the funds to the Safe with no server signature;
- `swapOwner` replaces a dead server and spending resumes with the new pair;
- the owners veto a queued drain;
- the server alone cannot queue (not directly, not with its own signature, not with a forged
  passkey signature), veto, reconfigure, or execute early or substituted;
- a failing queued call expires instead of blocking recovery forever.

`packages/smart-account/examples/passkey-recovery.ts` runs the same flow through the
TypeScript helpers against the deployed bytecode.

Two conditions to be precise about:

- **It must be installed while both owners are available.** `encodeRecoverySetup` installs it
  in one UserOperation, bundled with the Safe's deployment in the example. A Safe without it has
  the old failure mode.
- **Queueing and executing need gas from some address.** The Safe's balance cannot pay without
  the server, and `SponsorPaymaster` is ours. Roughly 330–360k gas queues a transaction and
  about 72k executes an exit.

A ragequit is also **public**: it reveals the commitment, the label and the value, and links
them to the depositor address. It is the fire exit, not the front door. The invariant we can
defend is *no user loses funds*, not *no user loses privacy*.

## The seed

Every proof, withdrawal or ragequit, needs the spending key, which is derived from the seed.

- **With a PRF-capable passkey** (`PrfSeedSource`), the seed is recomputed from the
  authenticator and survives device loss through platform passkey sync. No service of ours holds
  anything needed to rebuild it. Losing the passkey with no sync is loss of shielded funds, and
  no replication changes that. That is a user-side loss, not a service failure.
- **Without PRF, new wallets use `RecoverableSplitSeedSource`.** The seed's raw secret is split
  2-of-3: a device share, a server share, and a 64-character recovery code the user writes down.
  Device plus code rebuilds the seed with the server gone. Server plus code rebuilds it on a new
  device. Any single share is uniformly random. The price is that the code is as sensitive as
  the device share.
- **The legacy `SplitSeedSource` (device XOR server) still loses funds with the server share.**
  `RecoverableSplitSeedSource.fromLegacySplit` re-splits an existing wallet 2-of-3 without
  changing its seed (tested). It needs both legacy shares, so it must run before the server
  share is lost.

## The server co-signer

The default spending path is a **Safe 2-of-2**: the passkey's WebAuthn signer and a server key,
two on-chain owners. The FROST option (`packages/smart-account/examples/mpc-owner.ts`) makes the
Safe's single owner a 2-of-2 FROST group from a **distributed key generation**, so the server
never held the group secret. It stores the device's share sealed under the passkey PRF. FROST is
unaudited and not the default. Everything below applies to both configurations, because both
make the server a required signer of every ordinary Safe transaction, and both use the same
recovery module.

| Co-signer… | Effect (recovery installed) |
|---|---|
| dies or loses its key | Ordinary spending stops. **Recovery:** the passkey queues ragequit, rescues, transfers, or `swapOwner` to a new co-signer; each executes after the 7-day cooldown. A private withdrawal of ASP-approved deposits works throughout. Funds are delayed by up to one cooldown, plus one execution window per queued call that fails, and are not lost. |
| dies **and** a deposit is not in an ASP root | The same: ragequit through recovery after the cooldown. This combination used to freeze funds with no exit. |
| is compromised | It cannot spend, queue, veto, reconfigure the Delay, or execute early. It **can refuse to co-sign**, which is the same as dying: recovery swaps it out after the cooldown. Its FROST share or seed share alone reveals nothing. |
| dies **and** the passkey is compromised | **Loss.** The attacker queues a drain and nobody can veto without the server; the queue executes in order. For a PRF wallet, ASP-approved notes are lost regardless. |
| is compromised **and** colludes with a passkey thief | **Loss**: that is the 2-of-2. |

A **server-alone veto** would close the "dies and passkey compromised" row. It would also
reopen the one this design removes, because a compromised server could freeze every recovery.
That trade is not made.

**2-of-3 remains an option for access without any delay.** The option is device plus two
independently operated co-signers, or device plus a user-held key.
`packages/mpc/examples/two-of-three.ts` shows it for FROST, with keys now from the DKG: every
pair signs under one group key, and any single loss is survived. What it needs is a genuinely
independent second operator, which is a provisioning question rather than a code one. Two servers
run by the same team in the same account are 2-of-3 on paper and 2-of-2 in practice.

## The monitor, and who notices a stolen passkey

The recovery module turns a stolen passkey into a **public, delayed** event. The passkey signs a
queue request and the Delay emits `TransactionAdded`; nothing executes for 7 days. That only
helps if someone looks. The monitor should alarm on `TransactionAdded` from any user's Delay
(topic0 `0x4c8a9c74…f031`; details in wallet-custody.md §4). The wallet app should show the
pending queue on every open. Subscribing `packages/ops` to these events is **not yet wired**.
Until it is, noticing depends on the user.

## The ASP postman

`PrivacyPool.withdraw` checks the proof against an association-set root posted by the postman
role. If no fresh root is posted, private withdrawals of newer deposits stop for everyone. The
exit is ragequit, which for our users now goes through the recovery module if the co-signer is
also unavailable.

This is inherent to the Privacy Pools design and recorded as a trust assumption in
`audit-scope.md`. A compromised postman can withhold or mis-approve roots, but it cannot move
funds. What is *not* addressed is liveness: one operator whose outage silently degrades every
user to the public exit.

## The ramp: escrow, zkTLS witnesses, arbitration

| Service | Dies | Compromised |
|---|---|---|
| Matcher | No quotes. The book is on-chain; a taker can rebuild it with `indexer.ts` and lock an order directly. | Misreports offers or prices. The escrow re-checks the oracle band at lock time; no funds move. |
| zkTLS witnesses (Reclaim) - the only settlement path for PIX, boleto and TED (SR2-34) | Bank-rail orders cannot settle by proof. Unpaid on-ramp orders return to the LP after `payBy` via the permissionless `reclaimExpired`; stale off-ramp claims are cleared by `releaseStaleClaim`. | **M colluding witnesses can sign a claim about a bank session that never happened and release escrowed crypto.** Bounded by order size and the LP's credit cap; the loss is real. Witness changes wait out the governance delay. |
| Arbitration desk | **Frozen at most `DISPUTE_TIMEOUT`** (30 days by default, 7-90 per deployment). Rulings need neither the governor nor the desk to submit: anyone posts a signed ruling, which executes a day later. With no ruling, anyone calls `expireDispute` after the timeout and the escrow refunds to origin - the LP on the on-ramp (its offer, or its own address after a taker's dispute), the seller on the off-ramp. Nothing is lost or frozen past that. A side that paid inside the window and can prove it settles by proof despite the dispute (SRM1-3); only one that paid and cannot prove loses the trade if no ruling arrives in time. A taker's dispute holds none of the LP's credit (SRM1-4). | Can sign wrong rulings for orders already `DISPUTED`. Each is public for a day before it executes (`RulingPosted`), and revoking the arbitrator voids it - which needs someone watching and a governor acting within the day. |
| The USD/BRL rate: Pyth's FX.USD/BRL and Mova's Pyth keeper (SR2-35) | The feed goes stale. The Movva reserve refuses mint, redeem and hedge withdrawals at once; holders' Movva is untouched. Inside the FX core session the bands refuse too, so new offers, locks and sales halt; outside it they run on the last posted price for up to `closedMaxAge`. Orders already locked still settle. Posting Pyth updates is permissionless: anyone with Hermes access and gas restores the feed. Replicas take turns and any of them posts out of turn past two thirds of `maxAge`; the monitor's `pyth_keeper_gas` warns before a replica's float runs out. | The keeper can only post updates Pyth's publishers and the Wormhole guardians signed, or not post: it has no power over the price. A compromise of Pyth's publishers moves the bands and, **on the Movva reserve, value**: a gateway mints and redeems at the rate, bounded as `docs/security-review-movva.md` ("The rate") sets out. Repointing the feed or loosening its limits waits out the governance delay (SR2-30). A deployment on `SignedPriceOracle` instead has the same shape with named publishers. |
| A Movva gateway's LP node | Its Movva offers are not refilled and its buy-backs not claimed; other gateways and LPs keep trading, and Movva already delivered sits in the user's shielded balance. | The LP's key can mint and redeem only as any gateway can (the ratio floor, the supply cap, its slippage bound) and move its own offers; it cannot touch a holder's Movva or send reserve USDT anywhere but to itself for Movva it burns. Removing a gateway is instant. |

The governor is not a service, but the same question applies: a compromised governor can
register a hostile verifier or arbitrator. The governance timelock gives users a 48-hour window
to exit before a risk-increasing change executes.

## What is genuinely redundant

These can die with no user impact beyond a retry:

| Service | Effect of it dying |
|---|---|
| Relayer | User self-submits the withdrawal from any address with gas. The recipient stays private; the submitting address becomes the processooor. |
| Bundler (Alto) | Any ERC-4337 bundler works; the account is a standard Safe. Recovery needs no bundler. |
| `SponsorPaymaster` | User pays their own gas. Sponsorship is a convenience, and the contract holds no user funds. |
| Indexer | `IndexedPoolState` rebuilds from L1 logs against any RPC endpoint. State is derived, never authoritative. |
| Vault | Note *contents* are lost, but lineages, indices and balances rebuild from L1 events, and `ShieldedNoteLog` restores the itemised history on-chain with no vault at all. |
| Grant registry reader | Snapshot-and-serve; a stale read fails closed (a grant reads as not live). |
| Monitor | No effect on funds. A queued recovery transaction the user did not start then goes unannounced, and noticing depends on the wallet app showing the queue. |
| Yield vault keeper | No new allocation or harvest. Withdrawals draw on idle assets plus what adapters return instantly; a position that exits only through a queue waits for a keeper or guardian. A compromised replica key is bounded by `KeeperGate`'s daily turnover budget and revoked by the guardian instantly. |
| HyperEVM keeper | No rebalance or harvest. Exits do not need it: `requestRedeem`, `processExits` and `claim` work with the keeper offline, and `deleverage` is open to anyone. A compromised keeper can only trigger the bounded rebalances in `docs/delta-neutral.md`. |

## Summary

"Recovery" below means the Delay module installed at account creation.

| Property | Status |
|---|---|
| No single compromised service can take funds held by the account | **Holds.** Spending needs both owners, and the server alone cannot queue, veto or execute early (fork-tested). |
| Private withdrawal survives co-signer, relayer, paymaster, bundler, indexer or vault loss | **Holds**, for deposits in a posted ASP root. It needs no account signature. |
| Ragequit works with every service off | **Holds, after the cooldown**, for Safes with recovery: the passkey queues it, and anyone executes it after 7 days. Immediately, only for an EOA depositor. |
| No user loses **funds** if the co-signer dies | **Holds with recovery**, including for deposits not in an ASP root, delayed by the cooldown. **Does not hold** for Safes without recovery, whose non-ASP deposits freeze. |
| No user loses **access** if the co-signer dies | **Holds with recovery**: `swapOwner` to a new co-signer after the cooldown (fork-tested). Access is delayed, not lost. |
| No user loses funds if the co-signer is **compromised** | **Holds.** It can only refuse, which recovery routes around. |
| No user loses **funds** if the server seed share is lost | **Holds** for PRF users and `RecoverableSplitSeedSource` users (device + recovery code). **Does not hold** for legacy `SplitSeedSource` wallets not yet migrated. |
| Co-signer dies **and** passkey compromised | **Does not hold**: the queued drain cannot be vetoed. |
| Co-signer **and** passkey both compromised | **Does not hold**, by construction of a 2-of-2. |
| A compromised passkey alone takes nothing | **Holds for Safe-held and non-ASP funds** (public for 7 days, and the owners veto). **Does not hold for ASP-approved notes of a PRF wallet**: the PRF yields the spending key. |
| No user loses **access** if the ASP postman dies | **Does not hold** for private withdrawal of newer deposits. Ragequit remains, directly or through recovery. |
| Disputed escrow survives the arbitration desk dying | **Holds after `DISPUTE_TIMEOUT`**: refund to origin, triggerable by anyone. |
| No LP loses funds if the zkTLS witnesses are compromised | **Does not hold**: colluding witnesses can sign a bank session that never happened, bounded by order size and LP cap. |
| No user loses **privacy** if every service dies | Does not hold, by design: the escape hatch is public. |
