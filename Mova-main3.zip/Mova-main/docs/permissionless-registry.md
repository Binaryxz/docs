# The permissionless LP registry

`contracts/ramp/PermissionlessLPRegistry.sol` is an LP registry with no curator and no admin. It implements
`ILPRegistry` exactly as the audited escrows use it, so the **unchanged** `FiatEscrow` and `OffRampEscrow` bytecode can
be redeployed against it. The curated `LPRegistry` stays as it is: this is a second registry, not a change to the first.

The client approved it on 19 Oct 2026 with these requirements:

| Requirement (verbatim) | Where it is met |
|---|---|
| any LP can join by posting the required bond and meeting on-chain rules | `join(amount)`: at least `MIN_BOND` MOVVA, escrows bound, the address not already bonded or leaving |
| any LP can exit after an unbonding period | `requestExit()`, then `withdraw()` once `UNBONDING_PERIOD` has passed and nothing is live |
| the escrow accepts LPs dynamically, with no curator and no admin | `capOf(lp)` is a pure function of the LP's bond; there is no list to be put on |
| a misbehaving LP loses its bond automatically | `recordDispute(lp)`, which the escrows call when a dispute is ruled against the LP, takes the whole bond in the same transaction |
| no admin key is needed to add or remove an LP | there is no admin key at all |

The audit freeze held: `git diff 3f63b7e -- contracts/ramp/FiatEscrow.sol contracts/ramp/OffRampEscrow.sol
contracts/ramp/RulingLib.sol contracts/ramp/ILPRegistry.sol` is empty. No requirement needed an escrow or interface change.

## The rules

| Action | Who | What happens |
|---|---|---|
| `join(amount)` | any address | at least `MIN_BOND` MOVVA is pulled into the registry; credit = the bond in centavos |
| `topUp(amount)` | a bonded LP that is not leaving | more MOVVA in, more credit |
| `requestExit()` | a bonded LP | credit is 0 **in the same block**; the unbonding clock starts |
| `withdraw()` | a leaving LP | after `UNBONDING_PERIOD` **and** with no exposure live: the whole bond back; the address may join again |
| `reserveExposure` / `releaseExposure` | the two bound escrows | as in `LPRegistry`: one credit across both escrows, each escrow releases only what it reserved |
| `recordSettled` | the two bound escrows | counts settled volume. A record only: it moves no limit and pays no reward |
| `recordDispute` | the two bound escrows | the whole bond is slashed and locked in the registry for ever |
| `consumeBankTxId` | the two bound escrows | spends a bank transaction id, refused if this registry **or its predecessor** spent it |

There is no cancelling an exit and no partial unbonding: an LP that wants back in withdraws and joins again. An LP
whose bond a slash took joins again with at least `MIN_BOND`; its record (settled volume, disputes lost) stays public.

## Parameters, and why

| Parameter | Value | Kind | Why |
|---|---|---|---|
| Bond asset | MOVVA | immutable | R$ 1,00 each, already the rail's unit; 18 decimals (checked in the constructor) |
| Credit per bond | 1 centavo per 1e16 MOVVA base units (credit = bond value), rounded down | constant | see "Credit is the bond" |
| Slash | the whole bond, per lost dispute | constant | see "A lost dispute takes the whole bond" |
| `MIN_BOND` | 5.000 MOVVA (R$ 5.000,00) by default in the deploy script | immutable | the curated registry's starting retail limit (`LPRegistry.BASE_CAP_CENTS`). Constructor floor R$ 1,00, whole centavos |
| `UNBONDING_PERIOD` | 36 days on the live rail (`DISPUTE_TIMEOUT` 30 days + 1 + 4 + 1) | immutable | strictly longer than the escrows' whole dispute window; `bindEscrows` re-checks it on-chain |
| `ESCROW_RULING_DELAY` | 1 day | constant | the escrows' `RULING_DELAY`; `bindEscrows` checks OffRampEscrow's public value against it (FiatEscrow's is the same value, internal for size) |
| `UNBONDING_MARGIN` | 4 days | constant | FiatEscrow's longest pay window (a boleto's 1 h to issue + 3 days to pay) for a position open when the exit is asked, plus most of a day for inclusion |
| `MAX_UNBONDING_PERIOD` | 365 days | constant | so a typo cannot lock every bond for good |
| `PREDECESSOR` | the live `LPRegistry` | immutable | see "Bank transaction ids across registries" |

### Credit is the bond

The worst a lost dispute can cost a counterparty is the disputed position's own BRL value. On the on-ramp, an LP that
disputes an order the taker really paid, and is never ruled against in time, keeps both the taker's BRL and its crypto
(`FiatEscrow.expireDispute`). On the off-ramp the seller's crypto always comes back, so the worst there is the time it
was frozen. Every such position is exposure reserved in the registry (an LP's own dispute keeps it reserved until the
dispute ends), and the escrows cannot reserve more than the credit. So everything an LP could take from counterparties
at once is at most its credit, which is its bond. Because a lost dispute takes the whole bond, misbehaving never pays:
the LP gains at most its exposure and loses at least its bond.

A ratio above 1:1 (more credit than bond) would break that. A ratio below 1:1, a haircut, would cover MOVVA trading
under its peg. That choice belongs to the client (see below).

### A lost dispute takes the whole bond

`recordDispute(lp)` carries no amount and no counterparty, and `ILPRegistry` is frozen with the escrows. So the slash
cannot be sized to the disputed position, and it cannot be paid to the victim. Of the rules that need neither, only
"the whole bond" keeps the guarantee above. A fixed share (say half) would let an LP whose one disputed position is
bigger than that share come out ahead. "The whole bond" is also what the client wrote.

What triggers a slash is exactly what the escrows report:
- an off-ramp REFUND ruling, meaning the LP claimed a sale and did not pay it;
- a dispute the LP raised itself, on either escrow, that it then loses or lets time out.

A counterparty's unanswered dispute never reaches the registry, so nobody can cost an LP its bond by disputing while
the desk is down. Once the bond is gone, later lost disputes take nothing more. That is still sound: the first slash
took at least everything the LP could have gained across all of them. If the LP joins again, the new bond answers for
any dispute still waiting for a ruling.

### Where slashed MOVVA goes

Nowhere. It stays in the registry, counted in `totalSlashed`, and no function can move it. Every option that would move
it is worse:
- Movva can only be burned by its reserve, out of the reserve's own balance.
- A transfer to `address(0)` reverts.
- Paying it to Mova would give the party whose arbitrators decide disputes a stake in the outcome.
- `recordDispute` does not name the victim, so it cannot go to them.

The effect is a burn in all but `totalSupply`. It benefits every holder, because the reserve's backing now stands
behind fewer tokens that can ever be redeemed, and it benefits nobody in particular. `MovvaReserve.collateralRatioBps`
still counts the locked tokens as supply, so it understates the ratio, which is the conservative direction. MOVVA sent
to the registry directly is locked the same way.

### Exit: why "nothing live" is the rule that closes it

`withdraw` needs both the unbonding period and zero exposure. The second condition is the one that matters. Every
escrow path that ends in `recordDispute` holds the position's exposure until the transaction that reports the dispute:
the off-ramp releases it immediately before, and the on-ramp keeps an LP-disputed order inside its offer's reservation.
A taker's on-ramp dispute gives the credit back at once, and none of its outcomes records a lost dispute. Once the credit
is zero, nothing new can be reserved.

So when an LP's exposure is zero, no dispute can still slash its bond. The unbonding period is the client's rule and a
public notice period on top of that. Time alone would not be enough: a LOCKED order nobody reclaims can be disputed long
after its pay window. `PermissionlessRampIntegration.t.sol` (`test_AnExitCannotOutrunALiveDispute`) runs this exact case.

Exposure always reaches zero without the LP's help, because every position can be ended by anyone:
- once the LP's credit is 0, `closeOffer` returns its standing offers' free liquidity to it;
- `reclaimExpired` and `releaseStaleClaim` end positions whose pay window has passed;
- `expireDispute` ends a dispute after its timeout.

### No admin, and the one-shot binding

The registry has no owner, governor, curator, pause, upgrade or setter. The escrows cannot be immutables, because each
escrow takes the registry's address in its constructor, so the registry has to exist first. `bindEscrows(onramp,
offramp)` solves that once:
- only `DEPLOYER` may call it, and only once;
- each escrow must already exist and name this registry as its `REGISTRY`;
- each escrow's `DISPUTE_TIMEOUT` + `ESCROW_RULING_DELAY` + `UNBONDING_MARGIN` must be shorter than `UNBONDING_PERIOD`;
- after it, `escrowsBound()` is true for ever and `DEPLOYER` has no power left;
- before it, `join` reverts and `capOf` is 0, so no bond is ever at risk from a binding its LP could not see first.

To check on-chain that setup is closed, read `escrowsBound()`, `fiatEscrow()` and `offRampEscrow()`, and read
`REGISTRY()` on each escrow. `lp bond:status` prints all of it. The escrow set never changes: a new escrow pair needs a
new registry, which names this one as its `PREDECESSOR`.

### Bank transaction ids across registries

`consumeBankTxId` refuses, and `usedBankTxId` reports, any id that this registry has spent or that `PREDECESSOR` reports
as spent. The check is transitive, so a successor of this registry inherits both sets.
`test_ABankTxIdSpentUnderTheOldRegistrySettlesNothingHere` replays an id spent under the old `LPRegistry` against both
new escrows, and both refuse it (`ReceiptReplayed`).

The other direction cannot be closed from here. The old registry does not consult its successor, so an id spent here
could still settle a position on the **old** escrows. That needs a live position on the old pair, which the cutover
prevents.

### Rewards: none

`NodeRewards` pays only INSTITUTIONAL and AFFILIATED LPs. Its farming bounds rest on contracted identities (SR2-36): an
LP that settles with itself from a second address breaches a contract with a named counterparty. A permissionless LP has
no such counterparty. The best a hook could report is RETAIL, which `NodeRewards` ignores. So there is no hook, and
`recordSettled` only counts and emits `Settled`. Rewards for bonded LPs would need a new contract with its own bounds.

### MUST-NOT-revert paths, reentrancy, transfers, rounding

- `releaseExposure`, `recordSettled` and `recordDispute` make no external call and write a fixed number of slots. Each
  returns quietly for any caller that is not a bound escrow, and `releaseExposure` subtracts with saturation. The
  measured cost is under 40k / 70k / 70k gas (`test_TheMustNotRevertPathsAreCheapAndBounded`). The invariant suite
  counts any revert on these paths, and the count stays zero.
- MOVVA moves only in `join`, `topUp` and `withdraw`, on the LP's own call, with effects before the transfer. Movva is a
  plain OpenZeppelin ERC20: no hook, no fee, no rebase. The amount sent is the amount received, and no transfer can call
  back in. The only other external calls are views: the predecessor's `usedBankTxId`, and the escrows' getters during
  `bindEscrows`.
- Rounding: credit rounds down (never more credit than bond). The escrows round exposure up. Both directions go against
  the LP.

## Trust model

Nobody can add, remove, re-credit or slash an LP except through the rules above, and nobody can move a bond except its
own LP, through `withdraw`. What is still trusted is what was trusted before: **the escrows' dispute process**. An
arbitrator's ruling decides a lost dispute, and the escrows' governors choose the arbitrators. Adding an arbitrator
waits out the escrows' `GOVERNANCE_DELAY` in public. A malicious arbitrator could burn bonds by ruling REFUND on
disputed off-ramp sales, but it could not take them. An LP that paid a seller and can prove it settles by proof, even
on a disputed sale, before any ruling.

## Deploying (not done; dry run only)

`contracts/script/DeployPermissionlessRegistry.s.sol` deploys the registry and then a new escrow pair from the unchanged
escrow code pointing at it. In order:

1. Deploys the registry with the live pair's registry as `PREDECESSOR`, the live MOVVA, `MIN_BOND` (default 5.000
   MOVVA) and `UNBONDING_PERIOD` (default: the pair's longest `DISPUTE_TIMEOUT` + 6 days).
2. Deploys a FiatEscrow and an OffRampEscrow pointing at it.
3. Calls `bindEscrows`.
4. Copies the live pair's setup, as `DeployEscrowPair` does: MOVVA's listing and cap, ETH's listing, the zkTLS verifier
   and the arbitrators.
5. Closes the escrows' setup and hands them to the live governor.
6. Asserts everything, EIP-170 sizes included.

`DeployPermissionlessRegistry.t.sol` runs it against a local copy of the live rail.

```bash
OLD_ONRAMP=0x.. OLD_OFFRAMP=0x.. MOVVA_TOKEN=0x.. ZKTLS_VERIFIER=0x.. ARBITRATORS=0x.. \
  forge script contracts/script/DeployPermissionlessRegistry.s.sol:DeployPermissionlessRegistry --rpc-url $RPC_URL
```

Sizes (runtime, EIP-170 limit 24,576 B):

| Contract | Runtime size |
|---|---|
| PermissionlessLPRegistry | 6,446 B |
| OffRampEscrow | 19,753 B |
| FiatEscrow | **24,576 B, exactly at the limit**. It is frozen and unchanged; the limit is inclusive, and it is deployed on Sepolia at that size |

### Cutover (a governed step, not in the script)

1. Deploy as above; record `contracts.ramp.permissionlessRegistry` (and the new pair) in the rail record.
2. On the **old** `LPRegistry`, suspend every LP (`lp:suspend`, instant), or close the phases. The old pair then opens
   no new position. This is what keeps a bank transaction id spent on the new ramp from settling on the old one.
3. Let the old pair's live positions run off: sweep expired orders (`reclaimExpired`) and stale claims, and expire
   disputes after their timeout. Then retire the old pair (`setEscrow(old, false)`).
4. Point the app, the LP nodes (`capOf`, `availableCents` and `canQuote` read the same) and the indexer at the new
   pair. The indexer's and the examples' `lps(lp)` reads are specific to the curated registry; on the new one the
   equivalent is `bonds(lp)`.

## LP tooling

`npm run -w @mova/ops lp -- bond:<command>` (`packages/ops/src/bond.ts`, dispatched from `bin/lp.ts`). Every command is
a dry run unless `--execute --confirm <lp>` is passed with `LP_KEY` set to that LP's own key. Each call is simulated
before it is sent. Amounts are in MOVVA.

| Command | What it checks before it builds anything |
|---|---|
| `bond:status [lp]` | read-only: no-admin facts, whether setup is closed, each escrow points back, each dispute window against the unbonding period, total bonded and slashed, one LP's bond |
| `bond:join <MOVVA>` | escrows bound and pointing back; not bonded; not leaving; at least `MIN_BOND`; wallet balance. Sends `approve` (if short) then `join` |
| `bond:topup <MOVVA>` | bonded; not leaving; not zero; balance. `approve` (if short) then `topUp` |
| `bond:exit` | bonded; not leaving. Warns: credit 0 at once, anyone may close the LP's offers, no cancel, withdrawable date |
| `bond:withdraw` | leaving; unbonding over; nothing live |

The registry is `--registry <addr>`, or `contracts.ramp.permissionlessRegistry` in the rail record. It was smoke-tested
end to end on a local anvil (join, top up, exit, a refused early withdrawal, then withdraw after the period).

## What the client must still decide

1. **`MIN_BOND`.** The script defaults to R$ 5.000,00. It is immutable once deployed.
2. **The credit ratio.** 1:1 is the most credit that keeps misbehaving unprofitable. A haircut (for example 80%: R$ 1,00
   of MOVVA for R$ 0,80 of credit) protects against MOVVA trading under its peg. It is one constant, set before
   deployment.
3. **Whole-bond slashing.** This follows the requirement's wording and is the only amount-blind rule that keeps the
   guarantee. The client should accept it knowingly: one wrong ruling, or one LP-raised dispute that the desk lets time
   out, costs an honest LP everything it bonded. LPs should bond only what they mean to have at risk. Proportional
   slashing would need `recordDispute` to carry an amount, which means an `ILPRegistry` and escrow change and so a new
   audit.
4. **Slashed MOVVA is locked for ever.** It could instead go to a fixed, immutable sink, for example a compensation fund
   with its own rules. That would be a new contract and a new decision.
5. **Rewards.** Permissionless LPs earn no node rewards. Sharing fees with them needs a rewards design that holds up
   against self-trading without contracted identities.
6. **Arbitrators.** The bond is exactly as safe as the escrows' arbitration. Whoever governs the escrows' arbitrator set
   now decides who can burn LP bonds.
7. **Cutover timing,** and whether the curated registry keeps running beside the new one for institutional LPs. They
   are separate escrow pairs; an LP's credit on one is not credit on the other.
