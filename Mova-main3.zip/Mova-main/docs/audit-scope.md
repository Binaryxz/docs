# Audit scope — Phase 1

For an external reviewer. This says what to look at, what not to bother with, what we
already believe is wrong, and where the sharp edges are. It is written to save an auditor
the week of orientation that usually comes first.

*Brought up to date on 18 October 2026 against `5cfa0cc` (branch `phase-1-shielded-rail`). Every status below names its
source in this repository.*

## Which commit

The code on Sepolia was built from three commits, and the audit should freeze one tag that covers all three
(`docs/audit-readiness.md`, "Freeze the commit first"):

| What | Commit | Record |
|---|---|---|
| The MOVVA-only rail, deployed 15 October 2026: 20 contracts, Etherscan-verified 20/20 | `84e97d0` | `docs/deployments.md`, "The MOVVA-only rail on Sepolia" |
| The escrow pair that replaces the deployed one (SRM1-3, SRM1-4, SRM1-22 and the suspended-LP lever). Built, rehearsed on a fork, **not yet on Sepolia**: it waits for the client's approval | `5cfa0cc` | `docs/deployments.md`, "The EIP-1271 escrow pair" |
| The hedge sleeve, deployed 17 October 2026: `SimHedgeVenue` (TEST ONLY) and one ETH `HedgeSubWallet`, Etherscan-verified 2/2 | `a90c78f` | `docs/deployments.md`, "The hedge sleeve on Sepolia" |
| The account stack, deployed 14 October 2026: the three Kernel modules, `OwnerlessPaymaster`, `AuditGrantRegistry`, `ShieldedNoteLog` | `5290121` | `docs/deployments.md`, "Task 2 — accounts, ownerless paymaster, viewing keys" |

Between `84e97d0` and `5cfa0cc` the only contract changes are `FiatEscrow`, `OffRampEscrow`, `RulingLib`,
`ILPRegistry` (it now declares `capOf`, which the deployed `LPRegistry` already exposes), the new `contracts/hedge/`
and the new `contracts/script/DeployEscrowPair.s.sol` (`git diff --stat 84e97d0 5cfa0cc -- contracts`). Between
`a90c78f` and `5cfa0cc`, `contracts/hedge/` did not change.

## What is in scope

Everything in this repo that we wrote. **How the lines were counted:** `wc -l` over every `.sol`, `.ts` and `.tsx`
file under the path, excluding `*.test.ts` and `*.t.sol`, at `5cfa0cc` (18 October 2026). Comments and blank lines
are included. `contracts/test/` and `contracts/script/` are excluded from the contract rows.

| Component | Lines | What it is |
|---|---|---|
| `contracts/AuditGrantRegistry.sol` | 240 | Public lifecycle for disclosure grants. No funds, no admin. A fresh copy is on Sepolia in the account stack (14 October 2026). |
| `contracts/ShieldedNoteLog.sol` | 112 | Append-only encrypted note records. No funds, no admin. A fresh copy is on Sepolia in the account stack. |
| `contracts/AspRootQuorum.sol` | 126 | **The Entrypoint's ASP postman as an immutable k-of-n quorum of fixed ASPs.** A root reaches the Entrypoint only when a strict majority votes for exactly that root and CID. No owner, no setter. Client decision of 12 October 2026 (commit `7f4d433`); 3 ASPs, threshold 2 (14 October 2026, commit `ccdc79d`). On the live rail it is the only `ASP_POSTMAN` (`0x7f8B…46bD`); its three ASPs are test identities until the client names independent entities. |
| `contracts/OwnerlessPaymaster.sol` | 448 | **ERC-4337 gas sponsor with no owner, signer, pause, setter or withdrawal path**; an account qualifies by CREATE2 provenance from the Safe 1.4.1 or Kernel v3.1 factory, under per-op, per-account and global caps. Client decision B1 of 14 October 2026 (`docs/ownerless-paymaster.md`). Live on Sepolia, 1 ETH stake locked for good. |
| `contracts/SponsorPaymaster.sol` | 322 | ERC-4337 gas sponsor with an owner. **Superseded by `OwnerlessPaymaster` on the account stack and not deployed there**; its only deployment is the abandoned 8 September stack. |
| `contracts/SponsorGate.sol` | 317 | SponsorPaymaster's owner as a contract: revocable operator keys that may only sponsor, within a daily count budget. Not deployed (superseded with SponsorPaymaster). |
| `packages/viewing-key/src` | 7,376 | The audit viewing key: key tree, note encryption, disclosure, reconciliation, indexer. |
| `packages/smart-account/src` | 2,550 | Passkey/PRF seed derivation, Safe 2-of-2 over ERC-4337, WebAuthn signer encoding; **the passkey-sealed FROST device share** (`sealed-share.ts`), **the 2-of-3 recoverable seed split** (`seed-source.ts`), and **the delayed passkey-only recovery module** (`recovery.ts`, Zodiac Delay 1.1.1). Kernel v3.1 accounts beside Safe (`kernel.ts`, `kernel-validators.ts`, `kernel-recovery.ts`). See `docs/wallet-custody.md`. |
| `packages/smart-account/contracts/src` | 662 (556 in the four modules; the rest is `testing/` stand-ins and the `IKernel` interface) | **Kernel validators, unaudited, and a separate Foundry project.** `PasskeyCoSignerValidator` enforces the passkey + server 2-of-2 inside one validator (Kernel lets every installed validator authorise alone, so on Kernel the 2-of-2 is this contract, not Safe's audited threshold); `FrostValidator` accepts a FROST group signature through `SchnorrVerifier`; `KernelAvatarAdapter` lets the Zodiac Delay recovery queue calls into a Kernel account through an open fallback selector that checks its caller; `UserOpChallenge`. Both validators sign a validity window over the bare `userOpHash`. All three modules are on Sepolia (account stack). What Kernel cannot match of the Safe design: `docs/wallet-custody.md` §10.3. |
| `packages/mpc/src` | 1,690 | **FROST threshold Schnorr (RFC 9591, `frost.ts`), its distributed key generation (PedPoP, `dkg.ts`) and the DKG's transport (`dkg-transport.ts`: signed envelopes, a transcript hash, round 2 sealed to the recipient). Unaudited cryptography written from the specification — review this first.** |
| `contracts/ramp/*.sol` | 5,582 | **The BRL ramp. Holds LP liquidity and seller escrow — the contracts with the most value at risk.** Two escrows (`FiatEscrow` 1,380, `OffRampEscrow` 780; PIX, TED and boleto; an offer or sale opens only on a verifier that proves the bank session - SR2-34), `LPRegistry` (shared spent-bank-tx-id set across escrows, SRM1-12), one attestor verifier (`ReclaimZkTlsVerifier`, zkTLS for bank payments), five price oracles behind the governance delay (SR2-30) - among them `PythFxOracle`, the USD/BRL rate with a band reading for the closed market (SR2-35) - and a keyless sixth, `ChainlinkFxOracle`, the alternative USD/BRL leg from Chainlink BRL/USD (19 October 2026), `IBandPriceOracle`/`BandRead`, `RulingLib`, `SafeTransferLib`, the interfaces (`IAttestorVerifier` keeps its name; its `Rail` enum lost `CARD`), and **`NodeRewards`**, node-provider rewards paid from Mova's fees in proportion to settled volume, fed by `LPRegistry`'s rewards hook (SR2-36). The card rail and the attestor quorum were removed on 24 September 2026 (`docs/card-rail-removal.md`). On the MOVVA-only rail only the Movva escrow pair, `LPRegistry`, `ReclaimZkTlsVerifier`, `PythFxOracle` and `NodeRewards` are deployed. |
| … in particular, the escrow changes since the deployed pair | (in the above) | **In the `5cfa0cc` pair, not in the deployed `84e97d0` pair:** a valid proof settles a DISPUTED order or sale before the dispute deadline (SRM1-3, `2810368`); a taker's dispute takes the order out of its offer and frees the LP's credit at once (SRM1-4, `2810368`); **`RulingLib`'s EIP-1271 path**: a ruling signature that is not 65 bytes is `arbitrator ‖ signature`, accepted only if that registered contract's `isValidSignature` returns the magic value under STATICCALL, so the 2-of-3 arbitrator Safe can rule (SRM1-22, `a5d2b6a`); **the suspended-LP lever**: locking an order (`lockOrder`, `lockOrderByBoleto`, through `_lock`) refuses an LP whose registry `capOf` is 0 (`FiatEscrow._credited`, `LPNotEligible`), and anyone may `closeOffer` for such an LP, the liquidity going to the LP (`5cfa0cc`). **Already in the deployed pair:** one bank tx id per settlement across escrows (SRM1-12) and a seller can always cancel a claim past `payBy`, with a 30-minute re-claim cooldown (SRM1-13), both `f3c372d`. `FiatEscrow` is now 24,576 bytes deployed, exactly the EIP-170 limit (`5cfa0cc` commit message). |
| `packages/ramp/src` | 4,894 | Off-chain matching (holds nothing, signs nothing), the rails, order terms and PIX-key commitments (`attestor.ts`; the EIP-712 attestor client went with the card rail), zkTLS client, boleto validation, price publisher, arbitration desk and its service. The desk can run with the 2-of-3 arbitrator Safe and then holds no key (`bb64be9`). |
| `contracts/SchnorrVerifier.sol` | 227 | **On-chain FROST verification via an `ecrecover` construction, plus the ERC-1271 signer. Unaudited.** |
| `contracts/hedge/IHedgeVenue.sol`, `HedgeSubWallet.sol` | 167 + 842 | **The venue-neutral delta-neutral sleeve** (`docs/delta-neutral.md` §12; commit `2edad0d`). `IHedgeVenue` is everything the sleeve needs from a venue; `HedgeSubWallet` is one asset on one venue (long spot, short the perp) whose stablecoin can only be in the contract, in its venue account, or at the immutable `TREASURY` (the hedge-treasury 2-of-3 Safe); a trade-only keeper with argument-free `rebalance()`/`harvest()`; `DelayedGovernance`. **No venue is chosen** (`docs/delta-neutral.md` §12.8). Deployed on Sepolia 17 October 2026 at `a90c78f`, not funded. |
| `contracts/hedge/SimHedgeVenue.sol` | 764 | **TEST ONLY.** A simulated spot + perps venue for Sepolia whose operator sets funding, basis, spread and fee within fixed bounds. It refuses to deploy on the main networks it knows. It is not a venue and is never to be deployed on mainnet; review it only as far as the sleeve's tests depend on it. |
| `contracts/yield/YieldVault.sol` | 480 | Phase 3 ERC-4626 over governor-listed adapters: allocation caps, deposit cap, drawdown breaker. Built to hold the Movva reserve's idle USDT (`MovvaReserve.setYieldVault`); its yield is Mova's, not users'. **Not deployed on the M1 rail: the reserve's yield vault is address 0** (`deployments/sepolia-movva-only-rail/VERIFICATION.md`, "yield vault: none"). |
| `contracts/yield/adapters/*.sol` | 1,017 | ERC-4626 (sUSDS; Aave v3's USDT wrapper), Lido (wstETH, Curve instant exit, withdrawal queue, Chainlink depeg guard), Superstate USTB (NAV-bounded). Not deployed. |
| `contracts/yield/LimitedYieldVault.sol`, `KeeperGate.sol`, `IYieldAdapter.sol` | 161 + 166 + 69 | `YieldVault` plus a per-owner daily limit and an announce-then-anyone-executes timelock above it, with no cancel (SRM-17); one revocable operator key per keeper replica, with a daily turnover budget. Not deployed. |
| `contracts/common/ShieldedDepositLabel.sol` | 54 | Recomputes the label a pool just assigned. Used by the escrow's rescue index. |
| `contracts/common/DelayedGovernance.sol`, `IssuerFreeze.sol`, `FxMarketHours.sol` | 316 | **The base every governed contract uses**: risk-raising changes are scheduled in public and wait `GOVERNANCE_DELAY`; risk-reducing ones are instant. `IssuerFreeze` asks Tether or Circle before anything new starts in a freezable token. `FxMarketHours` decides from a timestamp alone whether the FX market is certainly trading (SR2-35). |
| `contracts/movva/{Movva,MovvaReserve,IMovvaReserve,ScaledFxBandOracle,FeeSplitter}.sol` | 1,313 | **Movva: the first contract here that creates money.** `MovvaReserve` mints and redeems a BRL-pegged token at Chainlink USDT/USD x Pyth's FX.USD/BRL (or a signed rate) against a USDT reserve, refusing a stale rate while its band takes the last close (SRM-15); surplus above the target stays in the reserve as backing (there is no distribution: savings and `SavingsMovva` were removed by client decision D1, 14 October 2026); hedge withdrawals above the daily limit go through `queueHedgeWithdrawal` / `executeHedgeWithdrawal`; `ScaledFxBandOracle`; `FeeSplitter`, the reserve's fee recipient, which forwards the LPs' share of the fees to `NodeRewards`. See `docs/security-review-movva.md`. |
| `contracts/movva/DivergenceBreaker.sol`, `IPriceSource.sol`, `sources/*.sol` | 318 | **Keyless, self-clearing circuit breaker for `MovvaReserve`** (SRM-16): no owner, no setter, no role; its only state is dead-source claims anyone may open with `poke()`; mint, redeem and hedge withdrawals revert while independent rate sources (a Chainlink cross, a Uniswap v3 TWAP) disagree beyond a deploy-time band. A thin TWAP that trips it is a denial-of-service lever (docs/movva.md). **Not deployed on the Sepolia rail** (`MOVVA_RAIL_BREAKER=off`); on by default for mainnet. SRM1-7 (a dead source halted it for good) is fixed in the contracts after the review: a source dead for `DEAD_AFTER` stops counting for redemptions. |
| `contracts/hyperliquid/*.sol` | 1,459 | A delta-neutral vault on HyperEVM trading HyperCore through CoreWriter; the keeper triggers only bounded actions. **One optional venue adapter, not the chosen venue** (no venue is chosen: `docs/delta-neutral.md`). Never traded on real HyperCore, not deployed. |
| `packages/movva/src` | 4,063 | The issuer's hedge desk: hedge and treasury arithmetic in bigints, signed and chained hedge statements, the desk server and hedge queue. Holds no treasury key and sends no transaction; the only key it reads is the statement key (`packages/movva/README.md`). |
| `packages/lp-node/src` | 11,392 | **The LP's daemon. Holds the LP's key and moves the LP's BRL.** Offers inside the band, payment instructions, PIX/boleto matching, off-ramp payouts with an idempotency key persisted before every bank call. |
| `packages/wallet/src` | 7,432 | The BRL-only boundary an app calls: balances in reais, PIX BR Codes, deposit quotes, audit grants, the tax year, and sub-wallets with independent BIP-39 seeds (`docs/wallet-custody.md` §12). |
| `packages/cosigner/src` | 6,879 | **The server half of every user's 2-of-2. Holds the co-signer key (KMS in production).** It must never produce a signature a request can use without a user-verified passkey signature over the exact operation it computes itself, against the passkey read from the chain (Safe WebAuthn signer or `PasskeyCoSignerValidator`), never from the request. Refuses authority changes (owners, modules, validators, upgrades, the Delay's configuration, co-signer rotation) except the recovery setup and listed rotations; allowlists targets and approvals; windows ≤ 30 min; replay and rate limits; an fsynced audit record before each signature; the recovery veto; the server side of the DKG transport (`/v1/frost/dkg/*`). TypeScript WebAuthn and P-256 verification is checked against the deployed factory's verdicts in `examples/cosigner-live.ts`. Two optional modules: **sponsorship** at enrolment through `SponsorGate` from a separate operator transaction key (§11.1), and **recovery alerts** (a watcher of each account's Delay, Web Push with VAPID and aes128gcm implemented on node:crypto, §11.2). See `docs/wallet-custody.md` §11. |
| `packages/app/src` | 5,828 | The PWA. Holds the seed in memory while unlocked (from the passkey's PRF), seals what it stores under a key derived from it, proves withdrawals in a Web Worker, and verifies every LP node answer on-chain before showing it. No server of Mova's sees a key. |
| `packages/yield/src` | 5,292 | Read-only Hyperliquid client and the delta-neutral backtest; **the venue-neutral risk engine** (`hedge-risk/`, 2,523 lines: plans only, with read-only venue readers, among them `OnchainHedgeVenue` for `IHedgeVenue` + `HedgeSubWallet`); **three keepers that sign**: the vault keeper (through `KeeperGate`), the HyperEVM keeper, and the Pyth keeper (posts Pyth's signed FX.USD/BRL updates, open to anyone; its key holds no role). None can pay itself. Nothing here runs the `HedgeSubWallet` keeper: on Sepolia that key is the deployer (`docs/delta-neutral.md` §12.8). |
| `packages/ops/src` | 7,258 | The monitor (among its checks: oracle bands, ASP root age, the orphaned-stack watch, the LP network, `hedge_risk`, and posted rulings cross-checked against the arbitration desk) and the `hedge-sleeve` CLI, which builds each funding-path step as a Safe transaction and, only with `--execute --confirm`, signs it with `SAFE_SIGNER_KEYS`. |
| `scripts/deploy-movva-rail.ts`, `privilege-inventory.ts`, `redeploy-escrows.ts`, `deploy-account-stack.ts`, `deploy-hedge-sleeve.ts`; `contracts/script/*.s.sol` | 5,297 + 2,268 | **Deploy and finalize safety logic**: `--finalize` and its guards (SRM1-1, -8, -9, -10), the privilege inventory, the three-step escrow replacement. A mistaken configuration here becomes permanent at finalization. |

Shielded transfers (Rev. 3 §5.3, Option A) are not in scope: the client removed them from the product on
12 October 2026, so users deposit and withdraw only. `ShieldedTransferRouter` and the wallet's transfer path
(`packages/viewing-key/src/transfer.ts`) were deleted.

Savings is not in scope either: client decision D1 (14 October 2026) removed it from M1. `SavingsMovva` (sMovva),
its shielded pool, `ShieldedYieldRouter`, `packages/zap-relayer` and the Movva distribution keeper were deleted, and
`MovvaReserve` lost `distribute`, `previewDistribute`, `setSavings` and the distribution fee. The scope is deposit PIX,
mint Movva, hold it as shielded notes, withdraw to PIX. `YieldVault` and its adapters stay in the code, as the
reserve's own yield, but the M1 rail deploys none.

Cards are not in scope: the card rail, `AttestorQuorumVerifier`, its three PSP attestor keys and `packages/attestor`
were deleted on 24 September 2026 (`docs/card-rail-removal.md`).

The ETH/USDT ramp pair is not on the M1 rail: D1 removed it, and `DeployRamp.s.sol` runs with `MAIN_PAIR=off` (no
ETH/USDT escrows, no ETH or USDT band oracle). The code paths remain in the escrows: the Movva pair lists native ETH at
construction and delists it during setup (`docs/deployments.md`, "The MOVVA-only rail").

The highest-value targets, in order:

0. **`packages/mpc/src/frost.ts`.** The only from-specification cryptography in the repo.
   Everything else is either audited upstream code or application logic where a bug costs
   correctness; here a subtle mistake costs the key. Attack the nonce handling first: the
   binding factors are what stop the second party to commit from grinding the group nonce
   (Drijvers/ROS), and `commit()` must never be able to return a repeated nonce.

   Then **`packages/mpc/src/dkg.ts`**, which replaced the trusted dealer (the dealer is now a
   test fixture outside the package's exports). Attack the proof of possession's binding (id,
   session, context, threshold, participant set), the equivocation check (a transcript hash in
   every round-2 message), blame assignment, and whether any path computes or returns a group
   secret. Then **`packages/mpc/src/dkg-transport.ts`**, the channel it assumes: what the signed
   envelope and the transcript bind (session id, every party's long-term key, every party's whole
   round-1 payload), whether any refusal can be bypassed, and the round-2 sealing (X25519 to the
   recipient's round-1 key, HKDF-SHA256, XChaCha20-Poly1305 over the envelope as AAD) - including
   whether a key can ever be derived twice.

   Then `contracts/SchnorrVerifier.sol`, which is the same cryptography on-chain. Two
   specific things to attack: the `ecrecover` construction compares a 160-bit **address**
   rather than the full x-coordinate, and the challenge is recomputed in Solidity and must
   match the TypeScript exactly (a differential test pins it, but the test is ours too).

   Then **`packages/smart-account/src/sealed-share.ts`** (the device share sealed under the
   passkey PRF: salt and KDF separation from the pool seed, what the AEAD binds) and the GF(2^8)
   Shamir split and recovery code in **`seed-source.ts`**.

   And the recovery module's **reliance on Zodiac's signature-based module authentication**
   (`SignatureChecker`, ERC-1271): the passkey queues through it, and its only audit is the June
   2026 patch review, which covered the fix alone. The Delay's queue, cooldown and veto logic is
   audited; this path is not. `docs/wallet-custody.md` §7–8 has our reading and the audited
   alternative, and `contracts/test/PasskeyRecoveryFork.t.sol` attacks it.
1. **`contracts/movva/MovvaReserve.sol`, and the rate it mints at.** A wrong number here is
   value, not a nuisance. Try to mint below full backing, redeem above `min(1, ratio)`, move reserve USDT
   anywhere but a redeeming gateway, the yield vault or the fixed hedge treasury, or change the rate's
   feed, limits, signers or sources without the public delay (`PythFxOracle`, `SignedPriceOracle`,
   `ChainlinkSignedFxOracle`). Then the off-hours split (SRM-15, SR2-35): `mint`, `redeem`,
   `withdrawToHedge`, `executeHedgeWithdrawal`, the ratios and the previews must read the strict rate, and only
   `brlCentsPerUnit` and `bandBrlPerUsdtE18` the band. Find a value-moving path that reaches `BandRead`,
   or a band reading that returns a price the strict reading would refuse for another reason. Then
   `PythFxOracle` and `FxMarketHours` themselves: the core session's edges (13:30 and 21:00 UTC,
   weekends, 25 December, 1 January, leap years), a last close stamped current for up to
   `closedMaxAge`, exponent and confidence handling, updates that go backwards. And the alternative leg,
   `contracts/ramp/ChainlinkFxOracle.sol` (keyless, added 19 October 2026): a rate that prices outside the core
   session on a weekend heartbeat round, the reciprocal's rounding, decimals changed behind the proxy, the band
   stamped current inside the session as well as outside it. Then Aave rounding at
   par (SRM-6) and Tether freezing the reserve (SRM-4). Residual risks already recorded, not findings: a
   gateway posting the most favourable Pyth update signed since the last post, a keeper outage outside
   the core session reading as a closure, about two hours a day misread as closed (bands only), and a
   band that jumps at the reopening.
2. **The escrows' dispute and ruling paths, and the bank-rail checks** in `FiatEscrow` and `OffRampEscrow`.
   - **Rulings** (`RulingLib`, both escrows). The EIP-1271 contract-arbitrator path (SRM1-22): replay across
     escrows, a Safe's owner set changing between posting and executing a ruling, `ArbitratorNewerThanDispute`
     for a contract arbitrator, and whether a non-65-byte signature can ever be read as anything but
     `arbitrator ‖ signature`. Then the ping-pong between rulings and what a stolen arbitrator key can still do
     (SRM1-2, accepted).
   - **Disputes against proofs** (SRM1-3, SRM1-4): a valid proof now settles a disputed order or sale, but only
     for a payment inside the order's own window and before the dispute deadline; a taker's dispute frees the LP's
     credit and an unpaid end pays the LP directly. Look for a dispute that buys time to pay, and for credit
     released twice.
   - **The suspended-LP lever** (`5cfa0cc`): `lockOrder` refuses an LP whose `capOf` is 0, and anyone may close
     such an LP's offer. Try to route the liquidity anywhere but the LP, or to close a live LP's offer.
   - **The bank-rail checks in `FiatEscrow.postOffer` and `OffRampEscrow.openSale`** (SR2-34). A PIX, boleto or
     TED offer or sale must open only on a verifier whose `provesBankSession()` is true. Find any path around it:
     an order or top-up on an offer that should never have opened, a verifier revoked after an offer opened. The
     answer is read when an offer or sale opens, not at settlement; revoking a verifier is the lever against a
     broken one (and is gone after `--finalize`). Residual: colluding zkTLS witnesses can still sign a session
     that never happened, bounded by order size and LP credit.
3. **`contracts/ramp/NodeRewards.sol`, `contracts/movva/FeeSplitter.sol` and the hook in `LPRegistry.recordSettled`**
   (SR2-36). Try to claim more than an epoch's budget, than was funded, or past the per-LP cap; to make a void or an
   exclusion raise another LP's share; to change the share, the rate, the cap, the hook or a funded registry without the
   delay; to make the hook block or starve a settlement - revert, loop, return a mountain of data, re-enter the registry,
   or submit the release with a gas limit that leaves the hook short (it must revert, never skip); and to break the books
   (`accounted == carry + outstanding + unfinalized funding`) through donations, epochs never finalized, or rounding.
   Residual risks already recorded, not findings: an eligible LP settling with itself within the caps, affiliates each with
   their own cap, and the instant first binding of a registry while NodeRewards holds nothing.
4. **`contracts/AspRootQuorum.sol` with the Entrypoint, and `contracts/OwnerlessPaymaster.sol` under ERC-7562.**
   For the quorum: liveness and safety at 2-of-3, root rollback, stale votes (SRM1-14, fixed in the contracts after the review: `unvote` and `VOTE_TTL`), and the fact that the
   Entrypoint's `latestRoot` is global across pools. For the paymaster: the window and grace binding, the `postOp`
   charge against EntryPoint v0.7's real debit, storage access under bundler simulation with Sepolia's pricing, and
   the unbounded fee per gas (SRM1-5; fixed in the wallet only).
5. **`packages/viewing-key/src/keys.ts` and `pool/scheme.ts`.** The whole read-only claim
   rests on the key tree's shape and on the withdrawal witness never leaving the spend
   branch. If this is wrong, nothing else matters.
6. **`disclosure.ts` + `audit.ts` + `reconcile.ts`.** Scope enforcement and the correctness
   of a fiscal report. A wrong balance here is handed to a tax authority.
7. **`contracts/hedge/HedgeSubWallet.sol`.** Try to move the stablecoin anywhere but the contract, its venue
   account or `TREASURY`; to make the keeper choose a size, price, direction or venue; to trade outside the band or on
   a stale reference; to leave an allowance standing; to loosen a bound without the 48 h delay. Assume a hostile
   venue within `IHedgeVenue`: that is what the interface promises nothing more than. `SimHedgeVenue` is TEST ONLY.
8. **`vault.ts`.** Access control on ciphertext release.
9. **`YieldVault.sol` and `LidoStakingAdapter.sol`** (Phase 3), **only if a vault will be deployed**: the M1 rail
   has none. For the vault, try to strand a holder, since two of Phase 3's three bugs were on exit paths. For the Lido
   adapter, try to get an instant exit filled at a price the oracle would not allow, or to make a depeg invisible to
   the share price. `docs/security-review-phase3.md` lists what we checked.

`docs/security-review-m1.md` §11 orders the M1 on-chain scope the same way, with the finalized state first.

## What is out of scope

`protocol/` is upstream's Privacy Pools. Its contracts and circuits are unmodified: `npm run verify` diffs them against
a fresh upstream clone and hash-checks every zk artifact the fork keeps (11; the three dev-setup proving keys were
removed, as `protocol/FORK.md` records - `docs/security-review-m1.md` §3); all three circuits recompile to
byte-identical R1CS. `protocol/relayer` differs from upstream only in `package.json` and one `tsconfig.json` path, and
`protocol/contracts/script/` only by the removed Gnosis contracts (`docs/security-review-m1.md` §3). It carries its own
Oxorio and Auditware reports in `protocol/audit/`. Auditing it again would duplicate that work — but **do** check our
*use* of it, especially `reconcile.ts` and `pool/indexer.ts`, where two bugs have already been found.

## Start here

```bash
npm install && npm run verify      # upstream provenance, the audited suites, circuits; what each check does: TESTING.md
npm test                           # vitest: 2,303 passed at ae9cade (18 October 2026, its commit message)
FORGE=$(bash scripts/foundry.sh path) && "$FORGE" test   # forge: 948/948 at 5cfa0cc (its commit message)
npm run slither                    # static analysis over contracts/ (the CI gate; see the note below)
bash scripts/mythril.sh            # symbolic execution, both modes, about 90 minutes on four jobs
```

`.github/workflows/verify.yml` (as at `5cfa0cc`) runs these in CI: every job but Mythril on every push, and every
job, Mythril included, on pull requests (the integration job skips pull requests from forks), on manual dispatch and
nightly (03:00 UTC); Mythril also runs on pushes to `master`. A caveat on what that proves: on 24 September 2026
we recorded that every CI job had been failing since 20 September with no runner assigned, which points at exhausted
Actions minutes (`docs/client-feedback-immutability.md`, proposal 7). There is no later record that this was fixed,
so treat a CI claim as unproven until a recent green run is shown. Locally, Slither has been run one file at a time,
because the repo script cannot read the pinned Foundry's build-info here (`docs/security-review-m1.md` §7.3,
`docs/security-tooling.md` §2).

Live deployments with verified sources: `docs/deployments.md`. The MOVVA-only rail is Etherscan-verified 20/20, the
hedge sleeve 2/2 and the 8 September stack 8/8. **The account stack's six contracts are not Etherscan-verified**: its
record holds the `forge verify-contract` commands, not run (`deployments/sepolia-account-stack.json`). Its bytecode is
instead checked read-only by its own 48 checks, which compare each address's code with its init code executed by
`eth_call`.

## Things we already believe are true and would like challenged

These are the load-bearing claims. If any is false, tell us first.

1. **A viewing key cannot spend.** Viewing material is an HKDF child of the spending
   secret; the withdrawal witness `(nullifier, secret)` derives from the spend branch and
   never enters a note or bundle; `assertNoWitness` walks payloads recursively at seal time.
2. **Scope is cryptographic, not filtered.** A record outside a grant's epochs is encrypted
   under a key the auditor was never given. The vault filter is defence in depth.
3. **Revocation stops future access only.** Rotation makes post-revocation notes
   permanently unreadable to the ex-auditor. Nothing retracts what was already decrypted,
   and we do not claim otherwise.
4. **A truncated disclosure is detectable only against an on-chain anchor.** A hash chain
   prefix is a valid hash chain; `anchorChain` commits head and count so the auditor can
   compare, including whether the anchored head is a prefix of a longer attested chain (SRM1-15).
   This was sharpened by a property test that failed.
5. **No paymaster we wrote can touch user funds, and `OwnerlessPaymaster` cannot lose its stake or deposit to
   anyone.** Everything sent to either forwards to the EntryPoint deposit; `OwnerlessPaymaster` has no function that
   withdraws, no DELEGATECALL, CALLCODE or SELFDESTRUCT, and none of the EntryPoint's withdraw selectors in its code
   (the account stack's checks, `docs/deployments.md`). The worst outcome from a bug is draining gas.
6. **No bank payment settles on anyone's word.** No PIX, boleto or TED offer or sale opens on a verifier whose
   `provesBankSession()` is false (SR2-34), and since 24 September 2026 the only verifier is the zkTLS one.
7. **Nothing moves value at a closed market's price.** `MovvaReserve`'s mint, redeem,
   `withdrawToHedge` and `executeHedgeWithdrawal` refuse an FX leg older than `fxMaxAge` at any hour; only bands
   take the last close (SR2-35, SRM-15).
8. **A contract arbitrator rules only by its own EIP-1271 approval.** A non-65-byte ruling counts only if the
   registered contract's `isValidSignature`, under STATICCALL, returns the magic value; the escrows then apply the same
   checks as for a key (`arbitratorSince`, `ArbitratorNewerThanDispute`, `RULING_DELAY`, revocation) (SRM1-22).
9. **A suspended LP's offers take no new orders, and closing them pays only the LP** (`5cfa0cc`). The lever reads
   the registry's own verdict, not a governor, so it survives `--finalize`.
10. **The hedge sleeve's stablecoin reaches only the sub-wallet, its venue account or `TREASURY`.** No function takes
    a recipient and the keeper's calls take no arguments (`docs/delta-neutral.md` §12.2).
11. **No root reaches the Entrypoint without a strict majority of the fixed ASPs** (`AspRootQuorum`).

## Known issues, already recorded

Do not spend time rediscovering these — `docs/security-review-phase1.md` and `docs/security-review-m1.md` §6 have
the detail.

- **`HedgeSubWallet` sized new exposure as if a margin deficit were zero (found 20 October 2026, fixed in the
  source).** After a liquidation leaves the venue account with negative equity and no position, the keeper's next
  `rebalance` moved in margin for a 2x book, but part of it only paid the deficit, so the book opened near 6x against
  the 3x cap. The sleeve's invariant suite found it (`invariant_TheKeeperStaysInsideItsBounds`, seed-dependent).
  `_marginGap` now counts the deficit in `_chunk`, `_addExposure` and `_deleverage`, and NAV nets it; the
  counterexample is a regression test (`contracts/test/HedgeSleeveDeficitRegression.t.sol`). The sub-wallet on Sepolia
  (17 October) has the old code; it needs a venue bankruptcy to show.
- **The deployed escrow pair predates SRM1-3, SRM1-4, SRM1-22 and the suspended-LP lever.** Those fixes reach the
  rail only as the `5cfa0cc` pair, which waits for the client's approval (`docs/deployments.md`). On the deployed pair
  the arbitrator is one ECDSA test key, a Safe cannot rule, and a suspended LP's standing offers still take orders.
- **The rail is not finalized.** The deployer still holds the governors and `OWNER_ROLE`; only the ASP postman is final
  (`docs/deployments.md`). `--finalize` refuses while any permanent role is a seed-derived test identity (SRM1-1).
- **Open M1 findings** (`docs/security-review-m1.md` §6): SRM1-2 (a stolen arbitrator key drains the on-ramp book after
  renunciation; accepted), SRM1-11 (the treasurer can lower backing to 103%), SRM1-16 (the Sepolia paymaster's global
  cap is above its deposit), SRM1-17 (the app cannot build the ownerless paymaster's data yet) and SRM1-21. SRM1-7 (a
  dead breaker source), SRM1-14 (stale quorum votes; byte-exact CIDs) and SRM1-20 (an instant max-age freeze before
  finalize) are fixed in the contracts after the review, for the next deployment; the Sepolia contracts keep the old
  code.
- **`FiatEscrow` is exactly at the EIP-170 limit** (24,576 bytes at `5cfa0cc`). Any further change to it needs bytes
  found elsewhere first.
- **`terms.accounts` is an attestation, not a proof.** A deposit from an undeclared account
  is undetectable on-chain. Mitigation is a KYC'd ramp that does not exist yet.
- **Paymaster budget overshoot.** Several operations in one bundle each pass validation
  before any settles, so an account can exceed its budget by up to one bundle, bounded by
  `maxCostAllowed`. Accepted deliberately; the alternative adds failure modes to `postOp`,
  which must never revert.
- **A paymaster must be staked, and `SponsorPaymaster`'s budget is enforced through `validAfter`.** Public
  bundlers apply ERC-7562 to validation. An unstaked paymaster may not read its own storage
  there or return a context (STO-031, EREP-050), so an unstaked `SponsorPaymaster` is refused by
  every one of them; the stake is an operational requirement (`docs/runbook-mainnet-deploy.md`,
  3c). `OwnerlessPaymaster` is staked 1 ETH on Sepolia, locked for good. TIMESTAMP is banned in validation for every
  entity (OP-011), and `SponsorPaymaster`'s budget check used to read it. Validation now reads no block data: an
  operation that does not fit the account's current window returns `validAfter` = the window's end, the EntryPoint
  enforces it, and `postOp` opens the next window. Checked with Rundler v0.11.0 on geth
  (`packages/smart-account/examples/erc7562-live.ts`). Worth an auditor's look: the argument in
  `validatePaymasterUserOp`'s comment that a window which ended but was not settled can only
  delay an operation, never admit one the budget refuses.
- **ASP operator trust.** Withdrawals need an association-set root posted by the postman
  role. On the M1 rail that is `AspRootQuorum`, 2 of 3 fixed ASPs: two colluding ASPs can censor, admit or roll back
  the root, and losing two of the three keys freezes the root for good (later deposits can only ragequit). On Sepolia
  the three are test identities. See `docs/availability.md` and `docs/security-review-m1.md` §8.
- **The server co-signer (Safe owner or FROST share) is required for ordinary spending.**
  Its loss is handled by the delayed recovery module: the passkey alone queues any Safe
  transaction (ragequit, rescue, `swapOwner`), executable by anyone after 7 days, vetoable by
  both owners. What still loses funds is the combination *server dead and passkey compromised*
  (no veto), accepted deliberately because a server-alone veto would let a compromised server
  freeze recovery. 2-of-3 with an independent operator remains an option. `docs/availability.md`,
  `docs/wallet-custody.md` §6.
- **Two high-severity findings in Phase 2 are already fixed and worth reading first** —
  `docs/security-review-phase2.md`. Both were in `rescueShielded`, and both had the same
  shape: a comment asserting a property the code did not have. Attack the seams where a
  claim is made in prose rather than in a test.
- **BRL/USD on Ethereum mainnet: Pyth by decision, Chainlink as a built alternative.** Pyth publishes
  FX.USD/BRL and it is live on Hermes, but Pyth is pull-based: on mainnet the contract answers
  `PriceFeedNotFound` until someone posts it. Mova decided (14 September 2026) to keep the Pyth pull warm: its
  Pyth keeper (`packages/yield`) posts updates, permissionlessly and with a key that holds no role, and
  `PythFxOracle` reads them. Reading Hermes's hosted gateway needs a credential, so the keeper needs one too (or
  its own Hermes). On Sepolia, real Hermes updates were posted by the Task 1 script on 14 and 15 October 2026
  (`docs/deployments.md`).
  **Chainlink BRL/USD is live and contract-readable on mainnet** (verified 19 October 2026): proxy
  `0x3126E7F38D5f60f4E2B6ec3511C7bdbD79317Df1`, "BRL / USD", 8 decimals, heartbeat 86,400 s, deviation 0.5%, last
  round 18 October 2026 19:14 UTC at 0.1975293 US$ per real. The earlier claim here - gated to EOA readers, stale
  since August 2023 - was true of a **retired** proxy, `0x0eBDc65E7e9132Cb41ac5cbD0101B799D7aDb475` (last updated
  25 August 2023; a contract gets `No access`), which the Feed Registry still returns and the repository tested in
  September. `ChainlinkFxOracle` (in scope, below) is the reserve's FX leg from the live feed, keyless, its rate
  refusing outside the core session; `DeployMovva` deploys it with `MOVVA_FX_SOURCE=chainlink`, Pyth remaining the
  default. Sepolia has no Chainlink BRL/USD feed. `packages/ramp/examples/brl-price.ts` and `scripts/fx-parity.ts`
  report the live state; `contracts/test/ChainlinkFxFork.t.sol` reads the live feed, and
  `contracts/test/{PythFork,OracleFork}.t.sol` pin the unposted Pyth state and the retired proxy.
  `SignedPriceOracle` remains a supported alternative (`FX_SOURCE=signed`).
- **A Chainlink FX leg lags by up to its deviation threshold.** Inside the session the on-chain answer can be up to
  ~0.5% from the market before a round lands, against mint and redeem fees of 10 bps: a contracted gateway can gain
  up to ~40 bps of a trade at the reserve's expense. Bounded by the threshold per trade and by the supply cap;
  closing it is the client's choice (fees of at least 50 bps, or an independent second source in the breaker with a
  band near the threshold). `docs/movva.md`, "The rate".
- **The FX market is closed about 73% of the week** (SR2-35, SRM-15). Pyth publishes FX.USD/BRL on
  weekdays 08:00-17:00 New York time only. Bands (`IBandPriceOracle`/`BandRead`, `ScaledFxBandOracle`,
  the reserve's `brlCentsPerUnit`) take the last close outside `FxMarketHours`' core session;
  everything that moves value refuses. Recorded residual risks: a move while closed reaches no band
  until the reopening; a keeper outage outside the core session looks like a closure for up to
  `closedMaxAge` (four days); about two hours a day are misread as closed, for bands only; a holiday
  Pyth adds fails closed and needs a new `PythFxOracle`; whoever posts may choose among updates signed
  since the last post; `BandRead` falls back to the strict reading on any revert of the band reading.
- **LP limits are denominated in BRL centavos, not asset units.** Once the escrow holds more
  than one asset, a "wei" limit is meaningless - the same number is 5 ETH or 0.000005 USDC.
  Worth checking the conversion at every call site. (The M1 pair lists MOVVA only.)
- **Fee-on-transfer and rebasing tokens are rejected, not supported.** `receiveToken`
  measures the balance actually received and reverts on a shortfall. Listing such a token
  would break the escrow's accounting in a way no transfer wrapper repairs.
- **One attestor verifier remains, and it has real trust.** `ReclaimZkTlsVerifier` verifies a zkTLS claim about a TLS
  session with a named bank host; its `provesBankSession()` is true, and it is the only verifier a PIX, boleto or TED
  offer or sale can name. Colluding witnesses can censor, and can still sign a claim about a session that never
  happened - a broader and more public set than named PSPs, not no trust. (`AttestorQuorumVerifier`, the M-of-N PSP
  quorum, was deleted with the card rail on 24 September 2026.) Nothing settles by a real PIX or boleto until a
  Reclaim application credential and per-bank templates exist; on Sepolia the witnesses are seed-derived test keys
  and the bank endpoint is illustrative. Attack the zkTLS context reader first: it parses a JSON document an attacker
  partly controls, and the identifier recomputation is what stops a genuine claim being re-pointed at another order.
- **MPC is implemented but is not the default, by decision.** Safe 2-of-2 (passkey owner +
  server owner) delivers "no single party can spend" with audited contracts and no unaudited
  code in the spending path, and remains the recommended production configuration. FROST
  (DKG keys, device share sealed under the passkey, one on-chain signature via `FrostSigner`) is
  the option for when single-signature indistinguishability is required, gated on this audit.
  The trade-off is worth challenging: two signatures are public where MPC would show one.
- **The passkey authenticator is simulated** in the test suite and in the Sepolia Task 2 run (a software P-256 key).
  The on-chain half is real and exercised on Sepolia; `packages/smart-account/browser/passkey-check.html` covers real
  hardware but is manual. It accepts cross-platform authenticators (a USB security key is
  enough), so no mobile device is required to exercise it.
- **The no-PRF fallback is written but is a policy decision.** `SeedSource` offers
  `PrfSeedSource` (seed never exists at rest) and `RecoverableSplitSeedSource` (seed
  reconstructable from any two of device share, server share and a user-held recovery code).
  The legacy `SplitSeedSource` (device ⊕ server) lost funds with the server share and is kept
  only for migration, which preserves the seed. The split is strictly weaker than PRF and marked
  as such; whether to enable it or require a PRF-capable authenticator has not been decided.
  Worth reviewing the split construction and, more importantly, the rule that PRF and split
  must never be migrated between silently — they yield different wallets.
- **Sponsor key custody is unspecified for `SponsorPaymaster`.** Its owner controls the allowlist and can
  withdraw the deposit. Not user funds, but real operational risk with no documented procedure. The account stack
  avoids it: `OwnerlessPaymaster` has no key at all.
- **The hedge sleeve has no chosen venue.** On Sepolia the venue is `SimHedgeVenue` (TEST ONLY), whose oracle and
  the sub-wallet's reference are the same Chainlink feed, so the price band catches only the operator's basis there.
  Nothing about a real venue's fees, liquidation, solvency or custody is proven (`docs/delta-neutral.md` §12.5).
- **Upstream leaves the relayer's fee-commitment validation untested.** Three tests in
  `protocol/relayer/test/unit/privacyPoolRelayer.service.spec.ts` are `it.skip` with empty
  bodies: expired commitment, unverified commitment, and a fee lower than calculated. Those
  are exactly the paths deciding whether the relayer accepts an underpaying or replayed
  request. We have not written them either; they are upstream's file and we have kept it
  byte-identical. Worth an auditor's attention.

### Slither triage

`npm run slither` gates on **medium impact or worse** (`--fail-medium`). The latest recorded runs are per file: the
M1 review's (14 October 2026, `docs/security-review-m1.md` §7.3: 0 high, 0 medium with the in-source suppressions over
the 15 in-scope files and the four smart-account modules; with the suppressions shown, 5 high and 25 medium, every one
re-read and a false positive) and the hedge sleeve's (`docs/delta-neutral.md` §12.7: no high; two mediums fixed, one
false positive). The escrow fixes since record no new finding (commits `f3c372d`, `2810368`, `a5d2b6a`); the
suspended-LP lever (`5cfa0cc`) records no Slither run. The table below
is the older whole-tree triage, kept because each entry still applies:

| Finding | Assessment |
|---|---|
| `timestamp` in `AuditGrantRegistry.register` / `isLive` | Intended. Grants are time-boxed by design; validity windows are hours to days, while miner timestamp influence is seconds. |
| `timestamp` in `SponsorPaymaster.postOp`, `spentSoFar`, `_windowEnd` and `validatePaymasterUserOp` | Intended in the first three: `postOp` settles the budget window and `spentSoFar` is an off-chain view. A window is a day, and skewing it by seconds changes nothing an attacker benefits from. A false positive in `validatePaymasterUserOp`: it compares a stored window start plus the window with validAfter's 48-bit limit, and reads no block data, which ERC-7562 forbids there (OP-011; checked with Rundler). Run per file, clean at medium. |
| `contracts/SponsorGate.sol`, run per file | Clean at medium. Its one medium finding, `uninitialized-local` on `sponsorBatch`'s counter, was fixed by initializing it. Remaining low and informational findings: `timestamp` in `remainingSponsorships`, `windowEndsAt` and `_consume` (a one-day budget window; timestamp influence is seconds); `calls-loop` in `sponsorBatch` (static calls to the immutable paymaster, at most 100); `missing-zero-check` on the guardian (zero means no guardian, on purpose); `naming-convention` on the immutable `PAYMASTER`. |
| `naming-convention` on `ENTRYPOINT` | Cosmetic. Upper case for an immutable, matching upstream Privacy Pools' own convention. |
| `timestamp` in `LidoStakingAdapter.marketPrice` | Intended. Oracle staleness is judged in hours; timestamp influence is seconds. (`ShieldedYieldRouter.zap` was listed here until the router was removed, D1.) |
| `calls-loop` in `YieldVault.totalAssets` / `liquidAssets` | Intended. Adapters are governor-listed and capped at 8, and their views must not revert (`IYieldAdapter`). |
| `reentrancy-benign` in `YieldVault.allocate/deallocate/harvest`, `LidoStakingAdapter.requestExit` | The order is forced. The checkpoint must follow the deposit it measures. Every entry point is `nonReentrant`. (The removed router's `zap/_shield` were listed here too.) |
| `dead-code` on `YieldVault._deposit` / `_withdraw` | False positive. They override OpenZeppelin's ERC-4626 hooks, and OpenZeppelin calls them. |
| `costly-loop` in `YieldVault.removeAdapter`, `LidoStakingAdapter.claimExit` | Bounded: at most 8 adapters, and one swap-and-pop over outstanding requests. |
| `low-level-calls` in `LidoStakingAdapter.deposit` | Intended. Sending ETH to wstETH is how it stakes and wraps in one call, verified on mainnet. |
| `cyclomatic-complexity` in `LidoStakingAdapter.withdraw` | Accepted. One function, so the oracle check, sizing, unwrap and sale share one set of locals. Covered by fork tests. |
| Medium findings on Phase 3 contracts | Each suppression sits next to its reason. `reentrancy-balance` and `unused-return` are on balance-delta measurement and on returns re-read from balances. `arbitrary-send-eth` is on the Lido adapter wrapping its exit ETH into the immutable WETH (the removed router's payees bound by the user's proof were the other case). `divide-before-multiply` was fixed, not suppressed (SR3-3). |
| Medium findings on `packages/smart-account/contracts` | Suppressed with reasons, analysed by `scripts/slither-smart-account.sh` (the root script never sees this separate Foundry project). `locked-ether` on all three modules: `onInstall`, `onUninstall` and `validateUserOp` are payable because Kernel's `IModule`/`IValidator` declare them so, and Kernel sends no value. `unused-return` on `KernelAvatarAdapter`'s `executeFromExecutor` (single-call mode reverts on failure) and on `ECDSA.tryRecover` in `PasskeyCoSignerValidator` (the error and the recovered address are both checked). Informational `naming-convention` and `too-many-digits` (the P-256 constants) remain. |
| `contracts/hedge/*`, run per file | No high. Medium `reentrancy-balance` in `withdrawToTreasury` and `reentrancy-no-eth` in `_addExposure` were fixed; `arbitrary-send-erc20` in `fund` is a false positive (`from` is the immutable treasury, the only caller). Lows and informationals accepted with reasons in `docs/delta-neutral.md` §12.7. |

`contracts/script/` is excluded from analysis, and that choice is worth knowing rather than
discovering: it produced one guaranteed **high**-impact false positive — `arbitrary-send-eth`
for a deploy script funding the paymaster it created in the same transaction. Keeping it in
meant either a permanently failing check or a per-finding suppression; excluding deployment
tooling and analysing what actually gets deployed is the more honest of the three. If you
disagree, the script is four lines and worth a look.

We would rather hear that this triage is wrong than have it silently agreed with.

## A third bug, of a different kind

The first two were logic. This one was worse in a way worth understanding, because it means
an earlier version of this document was making a claim it could not support.

An unanchored `lib/` in `.gitignore` matched at every depth, and silently excluded three
files of **audited protocol source** — `src/contracts/lib/{Constants,ProofLib,DeployLib}.sol`
— from every commit. Everything built and verified locally, because the files were on disk.
The published repository could not build at all, and "the fork is byte-identical to
upstream" was true of the working tree and false of what anyone else could clone.

Found by CI on the run after the lockfile was committed. Not findable by testing harder
locally — the machine that had the missing pieces was the machine doing the testing.

The rules are now anchored, and `.gitignore` carries the check to run before adding an
unanchored pattern. If you review one thing about the repo's hygiene, review that file.

## Where the bugs have actually been

Two real bugs were found in Phase 1, and both had the same shape: **the model and the test
agreed with each other because the same assumption produced and checked the value.**

- `labelOf` used Poseidon where the contract uses `keccak256`. Every test passed for two
  tasks, because `LocalPrivacyPool` generated labels with our function and checked them with
  our function.
- Ragequit exits were invisible to reconciliation, because the L1 event carries no nullifier
  hash and the RPC decoder fabricated one. The in-process model knows the hash, so only the
  real path was wrong. It would have **overstated a balance in a report to a tax authority**.

Both were found by comparing what the model believes against what the chain emits. If you
have limited time, that is the seam to attack: anywhere our TypeScript reproduces something
a contract computes. `test/scheme-onchain.test.ts` pins the known cases with vectors
captured from a deployed pool.

## What we have not done

- **No formal verification.** Symbolic execution exists, bounded: `scripts/mythril.sh` runs Mythril 0.24.8 in two
  modes (from the constructor, and from arbitrary storage) over 25 contracts, gated on an allowlist and a 20% runtime
  coverage floor. It does not analyse `contracts/hedge/*`, `DivergenceBreaker` and its sources, `LimitedYieldVault`,
  `SchnorrVerifier`, `contracts/hyperliquid/*` or the smart-account modules (the list in the script). The latest
  recorded run is the M1 review's, 14 October 2026, over 14 in-scope contracts (`docs/security-review-m1.md` §7.4);
  the escrows' coverage there (30-46%) left most of the dispute and ruling logic unexplored. Bounded at two
  transactions, it proves nothing.
- **No fuzzing beyond Foundry's.** Foundry fuzz tests and handler-based invariant suites (escrows, Movva supply, the
  hedge queue, NodeRewards, SponsorGate, the hedge sleeve), with runs and depth set per suite. No invariant spans
  `YieldVault` and its adapters together.
- No timing or side-channel analysis. We use `@noble`, which is constant-time by design, but
  have not audited our own usage.
- No dependency supply-chain review. `package-lock.json` is committed (lockfile v3, 1,054 resolved packages counted
  as its non-link `node_modules` entries on 18 October 2026) so the versions are at least pinned and `npm ci` is
  reproducible, but nothing has audited what is in them.
- No review of operational security for the relayer or sponsor signing keys.
- Property-based testing covers the key tree, note encryption, chain integrity
  (`test/properties.test.ts`), reconciliation (`test/reconcile-properties.test.ts`) and the
  matcher (`packages/ramp/test/orderbook-properties.test.ts` — conservation, rounding
  against the taker, rail and asset separation, ranking totality). It does not cover the
  vault's access control or the relayer.
- Nothing has run on mainnet, under adversarial conditions, or at load.

## Contact points in the code

| Question | Read |
|---|---|
| Why does the key tree look like this? | `src/keys.ts`, header comment |
| Why keccak and not Poseidon for labels? | `src/pool/scheme.ts`, `labelOf` |
| What does a grant actually commit to? | `src/disclosure.ts`, `GrantTerms` |
| How is a report reconciled against the pool? | `src/reconcile.ts` |
| Why is the registry reader synchronous? | `src/chain-registry.ts`, header |
| Why does the vault bound its registry age? | `src/vault.ts`, `maxRegistryAgeSeconds` |
| Why is `postOp` inert-by-construction? | `contracts/SponsorPaymaster.sol` |
| Why can nobody withdraw the ownerless paymaster's stake? | `contracts/OwnerlessPaymaster.sol`, `docs/ownerless-paymaster.md` |
| How does a contract arbitrator sign a ruling? | `contracts/ramp/RulingLib.sol`, header; `docs/security-review-m1.md`, SRM1-22 |
| What did we change in the fork, and why? | `protocol/FORK.md` |
| Why is stETH valued at the lower of two prices? | `contracts/yield/adapters/LidoStakingAdapter.sol`, header |
| Why is a rescue keyed by label and not commitment? | `docs/security-review-phase3.md`, SR3-2 |
| What does a real hedge venue need to implement? | `contracts/hedge/IHedgeVenue.sol`; `docs/delta-neutral.md` §12.6 |
