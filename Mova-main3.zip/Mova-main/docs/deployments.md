# Deployments

## Sepolia (chain 11155111)

First deployment of the full stack to a public network, 8 September 2026. Everything below
was exercised end to end against these addresses, not against a fork.

| Contract | Address |
|---|---|
| Privacy Pools Entrypoint (proxy) | [`0x3f77697b1FEA98b3dba2eC30245227a810aaf683`](https://sepolia.etherscan.io/address/0x3f77697b1FEA98b3dba2eC30245227a810aaf683) |
| PrivacyPoolSimple (ETH) | [`0x29A361A64eE5F6CD4a7A4435ffFd0014652da542`](https://sepolia.etherscan.io/address/0x29A361A64eE5F6CD4a7A4435ffFd0014652da542) |
| Entrypoint implementation | [`0xd9aa8716dea3c5be3bf8f3caf3423a144205a792`](https://sepolia.etherscan.io/address/0xd9aa8716dea3c5be3bf8f3caf3423a144205a792) |
| WithdrawalVerifier | [`0x590e0826a8EAb2222c00e1F531762d23aBDEa7da`](https://sepolia.etherscan.io/address/0x590e0826a8EAb2222c00e1F531762d23aBDEa7da) |
| CommitmentVerifier (ragequit) | [`0x40D117cfd63982Dc2c1c77a27245A609c5bF7019`](https://sepolia.etherscan.io/address/0x40D117cfd63982Dc2c1c77a27245A609c5bF7019) |
| AuditGrantRegistry | [`0xe47e3C1E3f3A483ccF7682c2097b6824E646234E`](https://sepolia.etherscan.io/address/0xe47e3C1E3f3A483ccF7682c2097b6824E646234E) |
| ShieldedNoteLog | [`0x5aF4173b47E8C257e5B74a8324a24770A107c9A6`](https://sepolia.etherscan.io/address/0x5aF4173b47E8C257e5B74a8324a24770A107c9A6) |
| SponsorPaymaster | [`0x0b2BD9D208Bd74871C39553A0151A80De855dB39`](https://sepolia.etherscan.io/address/0x0b2BD9D208Bd74871C39553A0151A80De855dB39) |

> The deployed `AuditGrantRegistry` predates `registerAndRotate` (SR-5 in the Phase 1 review).
> Until it is redeployed, clients seal a grant's chains with `register` followed by `rotateEpoch`.

Pool scope: `15900931614510895967748594847791203562993156150573618263799806512390512015325`
Deployment block: `11662524`

### Administrative roles — rotated 12 September 2026

The key that deployed the stack was exposed when the development server was compromised on
11 September (see `HANDOVER.md`). The contracts themselves were untouched and did not need
redeploying — the pools and `AuditGrantRegistry` have no admin at all — but every role the
exposed key held has moved:

| Role | Holder now |
|---|---|
| `OWNER_ROLE` on the Entrypoint (also authorises proxy upgrades) | `0x941fb8cfa62968c5aE5A5F3FCD15311e8d23d659` |
| `ASP_POSTMAN` on the Entrypoint | `0x66d7BBB531e45073D8777719362d8D4329331AF1` |
| `SponsorPaymaster` owner | `0x941fb8cfa62968c5aE5A5F3FCD15311e8d23d659` |
| Relayer signer / fee receiver | `0x22e42Ceb2B03a51c13C4e13abd3c8d6e62f1D73e` |

The exposed deployer `0x5261f18F0D9685490Db55D28eA139395F8607Ad1` now holds no role,
including `DEFAULT_ADMIN_ROLE`, and no meaningful balance. `scripts/rotate-sepolia.sh`
performed the rotation and re-checks the end state; it grants to the new holders before
revoking from the old key, because `OWNER_ROLE` administers itself and nothing else on this
deployment could grant it back.

Canonical infrastructure was already present on Sepolia and is not ours: EntryPoint v0.7,
CreateX, the Safe 1.4.1 factory and singleton, `Safe4337Module` 0.3.0, `SafeModuleSetup`,
`SafeWebAuthnSignerFactory` and `FCLP256Verifier`.

### What was verified on-chain

**Deposit → shielded balance → withdrawal** (`examples/live-pool.ts`)

```
deposit 0.05 ETH              block 11662540
root (ours, from L1 logs)  ==  root (from the contract)
label = keccak256(scope, nonce) % p reproduced, nonce 1
groth16 proof generated in 6.5s
withdrawal accepted ON-CHAIN by the verifier, block 11662547
roots still match after the spend; nullifier spent, successor in tree
```

**Passkey as an on-chain Safe owner** (`examples/passkey-owner.ts`)

```
WebAuthn signer deployed at its predicted address
passkey alone            rejected
server co-signer alone   rejected
assertion over the wrong digest   rejected on-chain
passkey + co-signer      executed, P-256 verified ON-CHAIN, block 11662558
gas used 919636          (P-256 in Solidity; no RIP-7212 on Sepolia)
```

**Private (relayed) withdrawal** (`examples/relayed-withdraw.ts`)

```
quoted fee            141 bps  (10 base + gas)
groth16 proof         built offline; the user sends no transaction
relayed               tx 0x5dc59842...
recipient             0.049295 ETH, transaction count 0
relayer paid          0.000512 ETH of gas
roots still match; nullifier spent
```

The recipient is generated fresh each run and asserted to have zero balance and zero
transactions beforehand, so being funded afterwards with a transaction count still at zero
is the unlinkability property itself, not a proxy for it.

**The fee ceiling bit in practice.** The pool deployed with `maxRelayFeeBPS = 100`, and the
relayer quoted **141 bps** for a 0.05 ETH withdrawal at Sepolia gas prices - 10 bps of base
fee and the rest gas. Every relay would have reverted with `RelayFeeGreaterThanMax()`. Gas
is a fixed cost spread over the withdrawn amount, so a ceiling chosen for large tickets
makes small ones unrelayable, and BRL tickets are small. It was raised to 1000 bps here:

```bash
cast send $ENTRYPOINT "updatePoolConfiguration(address,uint256,uint256,uint256)" \
  $ASSET 1000000000000000 100 1000 --private-key $OWNER_KEY
```

This is the operational decision FORK.md warned about, now measured rather than predicted.

**Audit viewing key against the deployed registry** (`examples/live-audit.ts`)

```
grant registered on AuditGrantRegistry and reported live
auditor read grant status FROM CHAIN (snapshot at block 11662859)
on-chain subject == bundle signer
fiscal report: R$ 594,00, poolVerified true
user revoked on-chain -> auditor refused: "grant revoked at ..."
```

The auditor side uses `ChainGrantRegistry`, which snapshots the registry at a block and then
answers locally. That is deliberate: a verification issuing fresh RPC calls as it walks a
disclosure can observe the registry changing underneath it and report differently depending
on when each call landed.

The run also produced three `undisclosed_deposit` errors and `complete: false` - correctly.
Earlier test deposits from the same declared account were not part of that grant's scope,
and the deposit-coverage check found them in real chain data. That is the completeness
guarantee doing its job rather than a failure.

### Operational notes

The deployer key is generated on the build machine and lives in `.env`. **That is
acceptable for a testnet and not for mainnet** — a mainnet deployer key must be generated
and held somewhere you control, and never touch a build environment.

That same key is currently the `SponsorPaymaster` owner, which controls the sponsorship
allowlist and can withdraw the gas deposit. Set `PAYMASTER_OWNER` at deploy time to
something else for any real deployment.

**No public bundler will carry this paymaster's operations as it stands.** Read from the EntryPoint on
15 September 2026: staked 0.02 ETH, unstake delay 86400 s, gas deposit 0 ETH. The contract reads its own
storage and returns a context during validation, which ERC-7562 allows only a staked paymaster, and a bundler
counts a stake only from its own floor (Rundler's default is 1 ETH). It was also deployed from a build that reads
TIMESTAMP in validation when budgets are on, which bundlers refuse outright
(`packages/smart-account/examples/erc7562-live.ts`). Redeploy from the current source rather than topping it up.
`docs/runbook-mainnet-deploy.md` section 3c has the requirements, and the monitor's `paymaster_stake` check reports them.

**All eight contracts are verified on Etherscan** — sources published and matched against
the deployed bytecode. That is worth more than a formality: Etherscan recompiles the
submitted source and rejects it unless the output matches what is actually on-chain, so it
is independent confirmation that the deployed pool is the audited upstream code and the
deployed registry is the code in this repo.

Verification was done after the fact with `forge verify-contract`, so no contract was
redeployed and no state was disturbed:

```bash
forge verify-contract <address> <path>:<Contract> --chain sepolia \
  --etherscan-api-key $ETHERSCAN_API_KEY --watch --compiler-version 0.8.28
# SponsorPaymaster additionally needs:
#   --constructor-args $(cast abi-encode "constructor(address,address)" $ENTRYPOINT $OWNER)
```

Note this used a current foundry (1.8.x) rather than the pinned v0.3.0, which predates the
Etherscan V2 API. That is fine: verification does not touch the test baseline, and the pin
exists to keep the audited suite reproducible, not to constrain unrelated tooling.

### Reproducing

```bash
# protocol
cd protocol/contracts
OWNER_ADDRESS=$A POSTMAN_ADDRESS=$A DEPLOYER_ADDRESS=$A ETHERSCAN_API_KEY=unset \
  forge script script/Deploy.s.sol:EthereumSepolia --rpc-url $ETHEREUM_SEPOLIA_RPC \
  --broadcast --private-key $SEPOLIA_DEPLOYER_KEY --slow

# ours
forge script contracts/script/Deploy.s.sol:Deploy          --rpc-url ... --broadcast
PAYMASTER_OWNER=$A forge script contracts/script/Deploy.s.sol:DeployPaymaster ... --broadcast
cast send $PAYMASTER "addStake(uint32)" 86400 --value 0.02ether ...   # what was sent; a redeployment stakes 1 ETH (3c)

# flows
export DEPLOYER_KEY=... CHAIN_ID=11155111 CHAIN_NAME=sepolia RPC_URL=$ETHEREUM_SEPOLIA_RPC
DEPOSIT_ETH=0.05 WITHDRAW_ETH=0.02 \
  npx tsx packages/viewing-key/examples/live-pool.ts $PP_ENTRYPOINT $PP_POOL $RPC_URL
FUND_ETH=0.06 STAKE_ETH=0.03 DEPOSIT_ETH=0.03 \
  npx tsx packages/smart-account/examples/passkey-owner.ts $PP_ENTRYPOINT $PP_POOL
```

## The hedge sleeve on Sepolia (B7, deployed 17 October 2026)

`scripts/deploy-hedge-sleeve.ts` deploys the venue-neutral delta-neutral sleeve's Sepolia demo
(docs/delta-neutral.md section 12):

- `SimHedgeVenue`, a **TEST-ONLY simulated venue**. No venue is chosen; it refuses the main networks
  it knows.
- One ETH `HedgeSubWallet`. Its treasury is the hedge-treasury Safe `0x4464eddDd3c021BFa48f5e6c7E96163056806Cdb`
  and its guardian is the custody guardian Safe `0xd67DDA7D07CAa45d6f8e7C1dD0a170585e6B086c`.

**Deployed 17 October 2026** from `0x4D0dF9bB92883cf5584c812EB84AABA55d688853` (`SEPOLIA_HEDGE_DEPLOYER_KEY`), at commit
`a90c78f`. Only the rehearsal record was dirty, and the init code on chain matches that build byte for byte.

| Contract | Address | Etherscan |
|---|---|---|
| `SimHedgeVenue` (TEST ONLY) | `0x2eeacd0d4b690748d30fd608347d232825dd0d12` | verified |
| `HedgeSubWallet` (ETH) | `0xef351ee80fdc6a84aec78cbaa2de2354f45b9b5e` | verified |

- **Transactions:** 7 sent, 7 succeeded. They used 59,222,167 gas, exactly the projection, and cost under 0.000004 ETH
  at about 54 wei.
- **Checks:** 19/19 pass read-only on Sepolia.
- **Records:**
  - the deployment: `deployments/sepolia-hedge-sleeve.json`;
  - the monitor config: `deployments/sepolia-hedge-sleeve.hedge-risk.json`;
  - the Etherscan V2 submissions: `deployments/sepolia-hedge-sleeve/etherscan-verified.json` (2/2).
- **Funded and hedged, 19 October 2026** (`deployments/sepolia-hedge-sleeve-funding.json`).
  - The path: 50,000 USDT minted into the reserve (Task 1), 6,000 USDT of issuer capital, the treasurer Safe sending
    3,500 USDT to the hedge Safe, and the hedge Safe funding the sub-wallet. Each Safe step was a real 2-of-3
    execTransaction.
  - The keeper's one argument-free `rebalance()` opened the book: 0.9656 ETH short, 0.9656 ETH spot, 2.00x at $2,392.28.
    The next call answers `NothingToDo`.
  - `hedge_risk` reads OK on the live sleeve. The closest limit is the allocation, at 83% of its cap (warn at 90%).
  - Harvest, withdrawal and recapitalization of the yield follow in a later session.

*Before the deploy:* dry run clean, 19/19 checks on a fork. The rehearsal record is
`deployments/sepolia-hedge-sleeve.rehearsal.json`; the live one will be `deployments/sepolia-hedge-sleeve.json`,
with the monitor config `deployments/sepolia-hedge-sleeve.hedge-risk.json`.

- **Deployer: a NEW key the user funds.** The script reads `SEPOLIA_HEDGE_DEPLOYER_KEY` (to broadcast) or
  `SEPOLIA_HEDGE_DEPLOYER_ADDRESS` (for a dry run from the real nonce). It never generates, prints or
  stores a key.
- **Roles.** The keeper defaults to the deployer (`SEPOLIA_HEDGE_KEEPER` overrides it); the governor too
  (`SEPOLIA_HEDGE_GOVERNOR`). The venue operator is the deployer.
- **Cost, measured** by replaying the seven transactions on Sepolia itself with `eth_simulateV1`
  (2026-10-17, block 11,930,773): **59,222,167 gas**, 6.8x the pinned Foundry's 8,685,709 (both creations
  ~7x).
  - At Sepolia's price then (21 wei) x 1.5: 0.0000000019 ETH.
  - At the 2 gwei reference x 1.5: **0.178 ETH**. Fund at least that; Sepolia's fees swing by orders of
    magnitude.
- **Limits above 2^24.** Both creations need a gas limit above 2^24, which Sepolia accepts for
  state-creation gas: the rail's MovvaReserve creation used 41,258,173.
- **The ETH/USD feed** is `0x694AA1769357215DE4FAC081bf1f309aDC325306`, read-only checked ("ETH / USD",
  8 decimals). The address in the B-milestone brief, `…309aDF325306`, has no code on Sepolia and fails
  its EIP-55 checksum: a one-character typo of this one, which `scripts/deploy-movva-rail.ts` already
  uses.
- **The funding path's custody precondition is met:** phase 2 executed `setHedgeTreasury(hedge Safe)` on
  17 October 2026. A hedge withdrawal still needs a fresh FX rate, so it waits for the FX market to be open.

```bash
SEPOLIA_HEDGE_DEPLOYER_ADDRESS=<address> npx tsx scripts/deploy-hedge-sleeve.ts          # dry run (default)
HEDGE_SLEEVE_CONFIRM=deploy-hedge-sleeve-to-sepolia-from-<address, lowercase> \
  npx tsx scripts/deploy-hedge-sleeve.ts --broadcast-sepolia                              # the real run
npx tsx scripts/hedge-sleeve-rehearsal.ts                                                 # the whole funding path, on a fork
npm run -w @mova/ops hedge-sleeve -- status                                               # afterwards, read-only
```

## Custody rotation rehearsal — test keys to Safe multisigs (Sepolia, prepared 14 October 2026)

`scripts/custody-rehearsal.ts` rehearses the custody model the client approved (12/14 October) on the live 6 October
rail, as M1 requires before any mainnet finalization. **Status: rehearsed on a fork of Sepolia (129/129 checks, both
phases); not yet broadcast.** The live record will be `deployments/sepolia-custody-rehearsal.json`: the Safes, the signers'
addresses (never keys), every transaction hash, the scheduled ids and times, every check.

**Rotated here**, only with setters the contracts already have, from seed-derived test keys to a Safe 1.4.1 2-of-3 per role.
The Safes come from the canonical SafeProxyFactory and singleton, with a CREATE2 salt, so a rerun finds them. Each is a
plain custody Safe: no module, CompatibilityFallbackHandler. Each has three independent signer keys,
`custody/<role>/signer/0..2`. The deployer submits Safe transactions, so the signers hold no ETH.

| Role | Safe | Setter | Speed |
|---|---|---|---|
| guardian | `0xd67DDA7D07CAa45d6f8e7C1dD0a170585e6B086c` | `MovvaReserve.setGuardian` (MovvaReserve.sol:691) | instant: phase 1 |
| treasurer | `0x6C41c72A11fAf1E9FB0c462F9A3C32e3B1D26561` | `setTreasurer` (:701) | delayed 48 h: scheduled in phase 1, executed in phase 2 |
| hedge treasury | `0x4464eddDd3c021BFa48f5e6c7E96163056806Cdb` | `setHedgeTreasury` (:708) | delayed 48 h: as the treasurer |
| arbitrator | `0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7` (deployed) | `setArbitrator` on the four escrows | **held**: see below |

**Phases.** Phase 1 (now) deploys the Safes and calls `setGuardian` (instant). The guardian Safe then proves itself:
it pauses minting with 2 of 3 signatures and the governor resumes at once (one block). Phase 1 also schedules
`setTreasurer` and `setHedgeTreasury`. Phase 2 opens at `readyAt` = the schedule's block time + 172,800 s and must run
before `readyAt` + 14 days (`EXECUTION_WINDOW`), or the schedule expires and phase 1 reschedules it. Phase 2 executes
both changes. Each change replaces its test key in one call, so no role is ever empty, and the test keys keep working
until then. Each step is idempotent from chain state.

**The guardian Safe is pre-finalization only** (SRM1-23). Client decision C2 retires the guardian at finalization:
`--finalize` replaces this Safe with `0x…dEaD` (`setGuardian`, before the reserve's governor goes), so from then on
nobody can pause minting. Until then two of its three signers can pause. A pause landing while finalize's
`setGuardian` is in flight no longer becomes permanent: finalize stops before any renunciation and the governor can
resume (SRM1-8). The treasurer and hedge-treasury Safes outlive finalization and must be declared to `--finalize`'s
exact-set checks (the deployment JSON's `expectedHolders`).

**What the fork rehearsal proved**, in one run with the 48 h warped:
- The Safes are 2-of-3 over the right signers.
- Each Safe acts as its role with 2 signatures: the guardian Safe's `pauseMint` was really sent; the treasurer's
  `withdrawToHedge` and the hedge Safe's token call were probed, not sent.
- One signature is refused (`GS020`), and an owner plus a non-owner is refused (`GS026`). A signer alone fails the
  role's gate.
- After rotation the old test keys fail the gates: `NotGuardianOrGovernor`, `NotTreasurer`.
- The delayed setters refuse to run early (`NotReadyYet`) or directly (`ChangeMustBeScheduled`).

Every transaction the rehearsal sent was replayed on Sepolia itself (`eth_simulateV1`, phase 2 as a later block) and
succeeds. Sepolia charges far more gas than the fork for new state: 1.48M gas against 306k per Safe. Phase 1 is
6.44M gas (9 transactions) and phase 2 is 98k gas (2 transactions), all paid by the deployer. That was under 0.00001 ETH
at Sepolia's 0.001 gwei on 14 October, and about 0.13 ETH even at 20 gwei.

**The arbitrator is not rotated: it cannot be, on these escrows.** `FiatEscrow` and `OffRampEscrow` accept a ruling only
as a 65-byte ECDSA signature recovered with `ecrecover` (`RulingLib._recover`, RulingLib.sol:130-137). A Safe has no key,
so it can never rule. The script proves this read-only on all four escrows, with an `eth_call` of `resolveDispute` against
a dispute that exists only as a state override:
- the test arbitrator's ruling is admitted;
- the arbitrator Safe's 2-of-3 approval of the ruling is a valid EIP-1271 signature (`isValidSignature` returns
  `0x1626ba7e`), but the escrow rejects it as `MalformedSignature`;
- one Safe signer alone is rejected as `NotArbitrator`.

On the fork, inside a snapshot that is reverted afterwards, the script also plays the whole rotation: schedule the add,
wait 48 h, execute. The registered Safe still cannot rule, and removing the test key would leave no key able to rule:
RELEASE becomes impossible, and only `expireDispute` refunds after 30 days. So the test arbitrator stays. Rotating it
needs either new escrows that verify EIP-1271 (a code change; the escrows are not upgradeable) or, on these escrows, an
interim ECDSA arbitrator key held in a KMS/HSM. That choice is the client's.

*Since 17 October: the first option is built* (SRM1-22, see "The EIP-1271 escrow pair" below). Once the rail record names
the new pair, the same read-only proof checks the opposite: the Safe's 2-of-3 ruling is admitted, the test key is no
arbitrator, and one Safe signer alone is still refused. The what-if step has nothing left to play, and the
"arbitrator not rotated" blocker clears. On a fork copy of the rail record naming the rehearsed pair, all 100 checks pass.

**Planned, not rotated here.** The script prints and records each of these with its current on-chain state and exact
calldata. The calldata is filled in once the addresses are supplied in `CUSTODY_KMS_GATEWAY`,
`CUSTODY_RECLAIM_WITNESSES`, `CUSTODY_RECLAIM_THRESHOLD` and `CUSTODY_LPS`.
- **Gateway → KMS/HSM** (`MovvaReserve`; `mint` and `redeem` are `onlyGateway`).
  - Needs: the KMS secp256k1 key's Ethereum address (signer normalises low-s and recovers v), funded with ETH, with its
    USDT allowance to the reserve.
  - Calls: `schedule(setGateway(KMS, true))` (delayed, :683), then after 48 h `execute`, then
    `setGateway(lp/0, false)` (instant).
- **zkTLS witnesses → Reclaim's production set** (`ReclaimZkTlsVerifier`, now 3 test witnesses, threshold 2).
  - Needs: Reclaim's published witness addresses for the current epoch, how many witnesses sign a production claim,
    and real bank endpoint templates (the four illustrative ones go too).
  - Calls: `schedule(setWitness(w, true))` for each witness (delayed, :579), plus `schedule(setThreshold(t))` if `t` is
    lower (delayed, :590; raising is instant). After 48 h, execute the adds, then the threshold. Then remove the test
    witnesses one by one (instant).
  - Never remove a witness below the threshold: removal neither lowers nor checks it, so every receipt would become
    unprovable.
- **LPs → their own keys** (`LPRegistry`).
  - Calls: `schedule(setTier(LP, INSTITUTIONAL, credit))` (delayed, :228), then after 48 h `execute`. Once lp/0 has
    nothing open (exposure 0), `setTier(lp/0, SUSPENDED, 0)` (instant).

The deployer stays governor of every contract. The FeeSplitter treasury (`treasury/0`) is also still a test key; neither
is on the custody list.

```sh
npx tsx scripts/custody-rehearsal.ts                       # fork rehearsal, both phases (warped)
CUSTODY_CONFIRM=rotate-on-sepolia-from-0xd24912278743ec80c4183cfa17091f6521ba73d1 \
  npx tsx scripts/custody-rehearsal.ts --broadcast-sepolia --phase 1      # now
CUSTODY_CONFIRM=rotate-on-sepolia-from-0xd24912278743ec80c4183cfa17091f6521ba73d1 \
  npx tsx scripts/custody-rehearsal.ts --broadcast-sepolia --phase 2      # >= 48 h later, within 14 days
```
Each broadcast first rehearses on a fresh fork and replays that rehearsal on Sepolia. It refuses unless both pass and the
deployer holds twice the phase's projected gas. A stopped run continues with `--resume`.

## Withdraw to PIX demonstrated live — the client's whole flow (Sepolia, 14 October 2026)

`scripts/task3-withdraw-to-pix.ts` (commit `d949691`); record `deployments/sepolia-task3-withdraw.json`; 83/83 checks,
re-checked on Sepolia afterwards. With Task 1 this runs deposit PIX -> mint MOVVA -> hold as a shielded note ->
withdraw to PIX on the live contracts.

- **Private withdrawal**: 200 of the Task 1 note's 502.1563 MOVVA, a real Groth16 proof (withdraw circuit, final keys)
  relayed through `Entrypoint.relay` (`0x2f085ae8…c4b2`) to a fresh Safe `0x4F8E96A9…a9d5` that never held ETH: 199 MOVVA
  to it, 1 MOVVA (50 bps) to the relayer. The nullifier is spent; 302.1563 MOVVA stays shielded as a change note, which
  a fresh wallet finds from the seed and the chain. user/0 sent nothing.
- **Sale**: the Safe, sponsored by the OwnerlessPaymaster, approved the escrow and opened a sale on the Movva
  OffRampEscrow: 199 MOVVA for R$ 197,01 to a salted PIX-key commitment (sale `0x6741c1bb…e2c0`).
- **Settled**: lp/0 claimed (`0xb4452e63…80a9`) and settled with a pix-sent receipt signed by 2 of the 3 test witnesses
  (`0x328b365a…2d03`); the escrow released the 199 MOVVA to the LP and the receipt is burnt. lp/0 then redeemed it at the
  reserve for 39.51033 USDT (`0xe680a87f…5180`), burning 198.801 MOVVA.
- **Stand-ins**: seed-derived witnesses and an illustrative bank endpoint instead of Reclaim and a real bank; the PIX
  payment is simulated; the deployer is relayer and bundler. **Privacy on Sepolia is nominal**: the pool held one
  deposit, so the withdrawal is attributable by elimination though the proof hides which note was spent.

## Task 2 demonstrated live — sponsored accounts and a viewing key (Sepolia, 14 October 2026)

`scripts/task2-live-demo.ts` (commit `0dc652a`); record `deployments/sepolia-task2-demo.json`; 95/95 checks, re-checked on
Sepolia afterwards. The script was the bundler (`EntryPoint.handleOps` from the deployer); the passkey is a software
P-256 key standing in for a device authenticator, verified on-chain by the real WebAuthn path.

- **Sponsored by the OwnerlessPaymaster**, every account holding 0 ETH throughout: the primary Safe 2-of-2 (passkey +
  co-signer) `0x687Ac975…8dd5`, first op with initCode and a later op; the sub-wallet Safe 1-of-1 `0xC3ef5319…05a4`,
  first and later op; the primary Kernel `0x79aEF6B0…c6B4`, two ops. The deposit fell 0.1 -> 0.09315 ETH, exactly the
  sum of the six ops' `actualGasCost`. A Safe from another factory and a wrong salt were refused (AA33 `NotFromFactory`),
  proven by simulation only.
- **Viewing key** over the Task 1 note: user/0 appended the encrypted note record to the ShieldedNoteLog and registered
  a grant scoped to its sub-wallet, the Movva pool and 14 October 2026 (`0x46dbacca…92e3`, live). From the grant and
  chain data alone the auditor rebuilt the statement: one deposit of 502.1563 MOVVA, R$ 502,15, complete and
  pool-verified. A September grant (`0x3112143e…c281`) discloses nothing, and its key does not open the October record.
- **Found**: the wallet's executors sign a fixed 1 gwei priority fee, so on Sepolia (base fee ~0.001 gwei) the paymaster
  reimburses the bundler at ~1 gwei - its deposit drains far faster than the gas actually costs. To fix in the wallet.

## The EIP-1271 escrow pair (SRM1-22; built 17 October 2026, not yet on Sepolia)

**Why.** The Movva `FiatEscrow` / `OffRampEscrow` pair deployed on 15 October verifies rulings with `ecrecover` only.
The client-approved 2-of-3 arbitrator Safe can never rule there (SRM1-22). It also predates SRM1-3/4: a valid proof
settles a disputed order, and a taker's dispute frees the LP's credit. And it predates the suspension lever: there,
a suspended LP's standing offers still take orders. In the new pair `lockOrder` refuses an LP whose registry `capOf`
is 0, and anyone may close such an offer, the liquidity going to the LP. The escrows are not upgradeable, so both fixes
reach the rail only as a new pair.

**What changes.** Only the escrows. The new pair is built by `contracts/script/DeployEscrowPair.s.sol` from the live
pair's own on-chain state:
- the same oracle (the reserve), registry, Privacy Pool entrypoint and pool, band, 48 h governance delay and 30-day
  dispute timeout;
- the same MOVVA listing and cap, with native ETH delisted;
- the same zkTLS verifier.

Its arbitrator is the custody arbitrator Safe `0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7` (Safe 1.4.1, 2 of 3) alone.
The test arbitrator key is not registered. Setup is closed before it is handed to the governor, and the script asserts
every copied value against the live pair.

**The steps** (`scripts/redeploy-escrows.ts`; each step is a dry run unless `--execute`, sends from
`SEPOLIA_RAIL2_DEPLOYER_KEY`, and adopts on a rerun what already happened):

| Step | Sends | What happens |
|---|---|---|
| `deploy --execute` | 2 creations and their setup (about 13.2M gas estimated) | The pair exists, unregistered. It refuses every offer and claim (`reserveExposure` reverts `NotEscrow`), so nothing changes for anyone. Its on-chain checks print. |
| `schedule --execute` | `LPRegistry.schedule(setEscrow(new, true))` x2 (51k gas each) | Public notice. Executable 48 h later, for 14 days. |
| `activate --execute` (after 48 h) | `execute` x2 (81k), `setEscrow(old, false)` x2 (28k, instant) | The registry accepts only the new pair. The rail record then names it, and keeps the old pair under `contracts.ramp.retired`. |

Retiring the old pair is safe while it still holds orders: `releaseExposure` is not gated on registration, and
`consumeBankTxId` checks `wasEscrow`. Its open orders still settle, refund and expire; it takes no new ones.

**Rehearsed on a Sepolia fork, 17 October 2026.** Every step ran on the fork. `activate` before readyAt was refused
("too early"), then ran after `--warp`. `status` then showed the old pair unregistered, the new pair registered, and the
Safe as its arbitrator. The custody rehearsal against that pair passed all 100 checks.

**Live, when the client approves:**

```bash
set -a && . ./.env && set +a   # SEPOLIA_RAIL2_DEPLOYER_KEY, SEPOLIA_RPC
npx tsx scripts/redeploy-escrows.ts deploy                # dry run: the addresses and checks
npx tsx scripts/redeploy-escrows.ts deploy --execute
npx tsx scripts/redeploy-escrows.ts schedule --execute
# >= 48 h later, within 14 days:
npx tsx scripts/redeploy-escrows.ts activate --execute
```

The record goes to `deployments/sepolia-movva-only-escrows-v2.json`. After `activate`:
- re-run `--verify`, the privilege inventory and the Etherscan V2 submission for the two new contracts;
- re-point the LP node and the monitor at the new pair;
- each LP re-posts its offers on the new on-ramp.

Building from a dirty `contracts/ramp` is refused: the live pair is built from a commit.

## The MOVVA-only rail on Sepolia (15 October 2026) — the M1 deployment

**Deployed from commit `84e97d0`** (clean tree; the code frozen for the audit, pending only the client's arbitrator
decision) by a fresh deployer `0x3c43F785CA057Df159F2e15E7CC44aB2986C2779`. Record: `deployments/sepolia-movva-only-rail.json`;
report, privilege inventory, 20 ABIs and the Etherscan script in `deployments/sepolia-movva-only-rail/`.
**Verification: 247 pass, 3 expected (Sepolia's Pyth FX.USD/BRL is stale outside market hours), 0 fail; 176 functions
classified, 0 unknown.** 59 transactions, 249.8M gas. Not finalized: the deployer holds the governors and
OWNER_ROLE until the client signs off; the ASP postman is already the 2-of-3 AspRootQuorum.

| | Address |
|---|---|
| Entrypoint (proxy) | `0xa185426022108E054D8F2F3f6FB3C96A46452288` |
| Movva Privacy Pool | `0x3072cA3AaE4911D55245e46ce3aA45EEB2d0DaCB` |
| MovvaReserve (no savings path) | `0x975e0F416f04012e64ED680cFBA9586acB4acBEc` |
| MOVVA token | `0x619806B8C015cb90D3fc83a4573F2e0959cBE74c` |
| AspRootQuorum (ASP postman, 2 of 3) | `0x7f8Bb7B988F866f280e4999Ea4259cFBd24846bD` |
| LPRegistry (one bank tx id per settlement across escrows) | `0xf2Cfbb21Df5Af92807679cC9451098Dc9d2b901D` |
| ReclaimZkTlsVerifier | `0xdb7332B360E49aa5f3fcDFC76C738b38ea5D8cA4` |
| FiatEscrow (MOVVA on-ramp) | `0x4F9cf3E102184480A89771B1414CD0636368e2cf` |
| OffRampEscrow (MOVVA off-ramp) | `0xCE38e6f13E9a1Dea7A206eb4E4B7De2e08383381` |

**Source verified on Etherscan: 20/20** (15 October; `deployments/sepolia-movva-only-rail/etherscan-verified.json`). The generated `etherscan-verify.sh` calls Etherscan's retired V1 API through the pinned Foundry v0.3.0, so `scripts/etherscan-verify-v2.py` takes forge's standard-JSON input for each of its commands and submits it to the V2 API instead.

No sMovva, no savings pool, no ETH/USDT ramps and no ETH band oracle; the reserve's `distribute`, `savings` and
`previewDistribute` do not exist. The 6 October rail (`deployments/sepolia-movva-rail.json`) is superseded by this one.

## The full flow on the MOVVA-only rail (15 October 2026)

The client's flow re-run on the final rail (`5034e52` scripts, `deployments/sepolia-movva-only-rail.json`):

- **Task 1** (`deployments/sepolia-movva-only-task1-mint.json`, 53 checks): FX.USD/BRL R$ 5.0519 posted, 504.62 MOVVA
  minted for 100 USDT, deposited as a 504.12 MOVVA note; its label approved by **2 of the 3 ASPs through the
  AspRootQuorum** (the first root posted by the quorum, not a single key).
- **Task 2** (`deployments/sepolia-movva-only-task2-demo.json`, 96 checks): fresh primary Safe 2-of-2, sub-wallet Safe
  and Kernel accounts, six ops sponsored by the OwnerlessPaymaster (accounts held 0 ETH); a viewing-key grant over the
  new note (15 October) from which the auditor rebuilt R$ 504,11; a September grant disclosed nothing.
- **Task 3** (`deployments/sepolia-movva-only-task3-withdraw.json`, 84 checks): 200 MOVVA withdrawn privately (Groth16,
  relayed) to a fresh sponsored Safe, 304.12 MOVVA left shielded; a sale of 199 MOVVA for R$ 197,01 on the new
  OffRampEscrow, claimed and settled by zkTLS (the bank tx id consumed in the LPRegistry, SRM1-12), then redeemed.
- **Custody phase 1** (`deployments/sepolia-movva-only-custody-rehearsal.json`, 56 checks): the guardian is the 2-of-3
  Safe (pauseMint proven), treasurer and hedge treasury scheduled; phase 2 from 17 October 12:08 UTC.
- **Custody phase 2** (same record, 104 checks, 17 October 2026 20:53 UTC): `execute(setTreasurer)`
  `0xca190a4d…8305` and `execute(setHedgeTreasury)` `0x23841103…b670`. The reserve's guardian, treasurer and hedge
  treasury are now the three 2-of-3 Safes. The old test keys are refused, and 1-of-3 is refused (GS020).
  - The arbitrator stays held on this escrow pair (ECDSA only). The EIP-1271 pair (`scripts/redeploy-escrows.ts`)
    rotates it.
  - The end-to-end probe of a hedge withdrawal through the Safes stopped at the reserve's stale-FX check: the FX
    market is closed at weekends. It did not stop at the custody gate.

## Task 1 — a fresh BRL price, a mint, and MOVVA held as a shielded note (Sepolia, 14 October 2026)

`scripts/task1-mint-and-shield.ts` (commit `44e3770`), on the 6 October rail; record `deployments/sepolia-task1-mint.json`.
9 transactions, 3.53M gas, rehearsed first on a fork (44/44) and re-checked on Sepolia afterwards.

- **Price**: Pyth FX.USD/BRL R$ 5.0323 per US$ from Hermes, posted with `updatePriceFeeds`
  (`0xdb420104…27c1`). The reserve then quoted R$ 5.0316 per USDT (crossed with the USDC/USD stand-in leg).
- **Mint**: the gateway minted 502.6589 MOVVA for 100 stand-in USDT, to the test user (`0x53ce3904…385f`); fee 10 bps.
- **Shielded**: the user deposited it into the Movva Privacy Pool through the wallet's own code (`0x4e6074cc…e5b6`).
  The pool holds the note, 502.1563 MOVVA after the 10 bps vetting fee; the user holds no MOVVA in the open; a fresh
  wallet from the same seed recovers the note from chain data alone.
- **ASP**: the postman posted a root containing the note's label (`0x67265c31…0fc6`), so it can be withdrawn privately.

## Task 2 — accounts, ownerless paymaster, viewing keys (Sepolia)

**Live since 14 October 2026** (record: `deployments/sepolia-account-stack.json`; deployer
`0xD24912278743Ec80c4183CfA17091f6521BA73D1`, commit `5290121`, broadcast from a clean worktree). 8 transactions,
37.4M gas; verification 48 pass, 0 fail, re-checked independently against Sepolia afterwards.

| Contract | Address |
|---|---|
| PasskeyCoSignerValidator | `0x7Ecc6B0edF79CACC4DaB559830111cC1c8702990` |
| FrostValidator | `0x58997113b2572F9Bc6ca243a0Ffff0C1924AB223` |
| KernelAvatarAdapter (recovery) | `0x8214602c7991b48dEa1A5Cd58b06dCCF7840fAb0` |
| OwnerlessPaymaster (1 ETH stake locked for good, 0.1 ETH deposit) | `0x98a488006bB816a03930Edfec76Fda95a8ee069d` |
| AuditGrantRegistry | `0x8BcCa7574d7A87Ea225DFB4ab1Ced6947e33414A` |
| ShieldedNoteLog | `0x9eE65d4b3B55A545721138B814d1227e7DFdB1a5` |

EntryPoint v0.7, Safe 1.4.1 and its factory, the Safe 4337 module and WebAuthn signer factory, and Kernel v3.1 with
its factory were already on Sepolia and were checked against the vendored fixtures, not deployed.

**21 September stack renounced the same day** (`scripts/renounce-sepolia-2026-09-21.sh --send`): ASP_POSTMAN
`0x6a202bf7…3329`, OWNER_ROLE `0x025f16a5…ae8c`, PythFxOracle governor to 0x…dEaD `0xdb018934…7fb9` (blocks
11,913,080-82; full hashes in `deployments/abandoned-sepolia-2026-09-21.json`, whose watch baseline is now block 11,913,082).

**Rehearsed on a Sepolia fork (14 October 2026), not broadcast.** One command deploys what the wallet's accounts
need that is ours, the ownerless gas sponsor, and the viewing-key contracts: `scripts/deploy-account-stack.ts`,
driving `contracts/script/DeployAccountStack.s.sol` and `contracts/script/Deploy.s.sol:Deploy`.
`SponsorPaymaster` and `SponsorGate` are not deployed. The ownerless paymaster supersedes them here.

### Already on Sepolia: checked, not deployed

`DeployAccountStack.check()` proves each of these is at its mainnet address with the code of
`packages/smart-account/fixtures/canonical`. All 13 contracts and all 3 deployers were present on 14 October.

| Contract | Address | Check |
|---|---|---|
| EntryPoint v0.7 | `0x0000000071727De22E5E9d8BAf0edAc6f37da032` | runtime keccak = fixture (= mainnet) |
| Safe 1.4.1 singleton / SafeProxyFactory | `0x41675C099F32341bf84BFc5382aF534df5C7461a` / `0x4e1DCf7AD4e460CfD30791CCC4F9c8a4f820ec67` | same |
| MultiSendCallOnly 1.4.1 | `0x9641d764fc13c8B624c04430C7356C1C7C8102e2` | same |
| SafeModuleSetup / Safe4337Module 0.3.0 | `0x2dd68b007B46fBe91B9A7c3EDa5A7a1063cB5b47` / `0x75cf11467937ce3F2f357CE24ffc3DBF8fD5c226` | same |
| SafeWebAuthnSignerFactory / FCL P-256 verifier 0.2.1 | `0x1d31F259eE307358a26dFb23EB365939E8641195` / `0xA86e0054C51E4894D88762a017ECc5E5235f5DBA` | same |
| Zodiac Delay 1.1.1 / ModuleProxyFactory 1.2.0 | `0x824175b945838d127C1ca83CbcE11D8e44F6dF01` / `0x000000000000aDdB49795b0f9bA5BC298cDda236` | same |
| Kernel v3.1 | `0xBAC849bB641841b44E965fB01A4Bf5F074f84b4D` | the fixture's init code, run again on Sepolia through the same deployer and salt (in a discarded snapshot), gives byte for byte the code on Sepolia. Its chain-id immutables make the mainnet hash inapplicable. |
| KernelFactory / meta factory (FactoryStaker) | `0xaac5D4240AF87249B3f71BC8E4A2cae074A3E419` / `0xd703aaE79538628d27099B8c4f621bE4CCd142d5` | runtime keccak = fixture; the factory clones Kernel v3.1; the meta factory approves it |
| Arachnid, Safe singleton factory, EIP-2470 deployers | `0x4e59b448…956C`, `0x914d7Fec…43d7`, `0xce0042B8…cf9f` | runtime keccak = fixture |

### What it deploys

| # | Contract | Address on the fork | How |
|---|---|---|---|
| 1 | PasskeyCoSignerValidator(SafeWebAuthnSignerFactory) | `0x7Ecc6B0edF79CACC4DaB559830111cC1c8702990` | `fixtures/mova` through Arachnid, salt 0: the same address on every chain |
| 2 | FrostValidator | `0x58997113b2572F9Bc6ca243a0Ffff0C1924AB223` | same |
| 3 | KernelAvatarAdapter (Kernel recovery through the Zodiac Delay) | `0x8214602c7991b48dEa1A5Cd58b06dCCF7840fAb0` | same |
| 4 | OwnerlessPaymaster | `0x98a488006bB816a03930Edfec76Fda95a8ee069d` | CREATE from the deployer at nonce 90 |
| 5-6 | `addStake()` 1 ETH, `deposit()` 0.1 ETH | | from the deployer |
| 7 | AuditGrantRegistry | `0x8BcCa7574d7A87Ea225DFB4ab1Ced6947e33414A` | `Deploy.s.sol:Deploy` |
| 8 | ShieldedNoteLog | `0x9eE65d4b3B55A545721138B814d1227e7DFdB1a5` | same |

Rows 1-3 land at those addresses on Sepolia whatever the deployer does. Rows 4, 7 and 8 do so only if
`0xD24912278743Ec80c4183CfA17091f6521BA73D1` sends nothing else first: its nonce was 87 at the rehearsal. Before
deploying, `FixturesTest` in `packages/smart-account/contracts` must pass, which proves `fixtures/mova` is the current
build of the validators.

**The paymaster's policy** (each value can be overridden by env, in wei or seconds): `OWNERLESS_WINDOW` 86400,
`OWNERLESS_GRACE` 3600, `OWNERLESS_MAX_COST_PER_OP` 0.01 ETH, `OWNERLESS_MAX_OPS_PER_ACCOUNT` 10,
`OWNERLESS_MAX_COST_PER_ACCOUNT` 0.02 ETH, `OWNERLESS_MAX_COST_GLOBAL` 0.2 ETH, `OWNERLESS_UNSTAKE_DELAY` 86400,
`OWNERLESS_STAKE_WEI` 1 ETH, `OWNERLESS_DEPOSIT_WEI` 0.1 ETH. Its two provenance roots are derived from the factories
as deployed on Sepolia, the way `OwnerlessPaymaster.t.sol` derives them:

- Safe: `0x76733d70…a4adfb`, which is `keccak256(SafeProxyFactory.proxyCreationCode() ++ uint256(Safe 1.4.1))`;
- Kernel: `0x85d96aa1…0f03e6`, which is `keccak256(Solady ERC-1967 proxy over KernelFactory.implementation())`.

Both are asserted against the published values. The script then proves them in simulation, never broadcast, with a
Safe from `SafeProxyFactory` and a Kernel account from `KernelFactory`: both land where `accountAddress` says.

**The deposit must cover 3 × `MAX_COST_GLOBAL` (SRM1-16).** The live deployment's 0.1 ETH deposit was half of its
0.2 ETH global cap, so the cap that bounds the drain never bound: ten Sybil ops in one window reserve the whole
deposit. In any n windows' worth of time the paymaster pays at most (n + 2) × `MAX_COST_GLOBAL`: the windows, one
more from fixed-window alignment and one from the grace period. For one window that is 3 × the cap, so k = 3 is the
least deposit at which the cap, not the deposit, ends a worst-case burst. Fund (n + 2) × the cap for n windows of
loss you are willing to pay for. Since then:

- `deploy-account-stack.ts` defaults `OWNERLESS_DEPOSIT_WEI` to 3 × `OWNERLESS_MAX_COST_GLOBAL` (0.6 ETH) and refuses
  less before anything runs; `DeployAccountStack.s.sol` has the same default and `require`;
- `--verify` fails a deployed paymaster whose deposit is under 3 × its `MAX_COST_GLOBAL()` and prints the exact top-up;
- the ops monitor's `paymaster_global_cap` warns under 3 × the cap and fails under one cap
  (`PAYMASTER_GLOBAL_CAP_WINDOWS`, docs/runbook-incidents.md).

**Top-up pending (a human runs it; nothing was broadcast).** Read from Sepolia at block 11,940,224 (18 October 2026):
the deposit is 0.089484605742290609 ETH (89,484,605,742,290,609 wei), the stake 1 ETH, `MAX_COST_GLOBAL` 0.2 ETH.
3 × 0.2 ETH = 0.6 ETH, so the top-up is **510,515,394,257,709,391 wei (0.510515394257709391 ETH)**, sent from any
funded key (anyone may fund it; nothing can take it back out):

```bash
cast send 0x0000000071727De22E5E9d8BAf0edAc6f37da032 'depositTo(address)' 0x98a488006bB816a03930Edfec76Fda95a8ee069d \
  --value 510515394257709391 --rpc-url "$SEPOLIA_RPC" --private-key "$FUNDED_KEY"
```

The deposit only falls between now and then (as sponsored gas), so run `--verify` first: its
`deposit covers 3 x MAX_COST_GLOBAL` line prints the amount for the block it reads, and passes once the top-up lands.
Sending a little more than that is harmless.

### Verification (48 checks, 0 fail)

Verification is read-only and runs after every deployment, and again with `--verify`:

- every canonical address has the fixture's code;
- each deployed address's code equals its init code (fixture, or `forge-out` with the recorded constructor arguments)
  executed now with `eth_call`, so every immutable is covered;
- each paymaster immutable, read one by one;
- the paymaster's EntryPoint deposit (0.1 ETH right after deployment; afterwards anything, since anyone may top it up)
  and stake (staked, 1 ETH, 86400 s delay, not unlocking);
- the deposit covers 3 × `MAX_COST_GLOBAL` (SRM1-16; added after the live run, so the live record's 48 checks predate it);
- **nothing can withdraw:**
  - the only state-changing functions are `validatePaymasterUserOp`, `postOp`, `deposit` and `addStake`;
  - there is no DELEGATECALL, CALLCODE or SELFDESTRUCT in the runtime code;
  - none of EntryPoint's `withdrawTo`, `withdrawStake` or `unlockStake` selectors appears in it;
  - `validatePaymasterUserOp` and `postOp` called from the deployer revert with `NotEntryPoint`;
- both viewing-key contracts have no admin function and hold no ETH.

### End to end on the fork, with no bundler service

The script acts as the bundler. It calls `EntryPoint.handleOps` from a funded fork key, with the wallet's own
`SafeExecutor` and `KernelExecutor`. Every op is sponsored by the new paymaster. The accounts hold 0 wei.

| Row | Operation | handleOps gas (fork) | Paid by the paymaster | Gas used on Sepolia (simulated) |
|---|---|---|---|---|
| a | Primary Safe 2-of-2 (passkey signer + co-signer): first op, initCode through SafeProxyFactory | 693,938 | 0.000893 ETH | 2,157,904 |
| b | Primary Safe: a later op | 349,784 | 0.000553 ETH | 386,544 |
| c1 | Sub-wallet Safe 1-of-1, same factory: first op (initCode) | 427,340 | 0.000630 ETH | 1,713,006 |
| c2 | Sub-wallet Safe: a later op | 127,412 | 0.000334 ETH | 154,712 |
| d1 | A Safe 1.4.1 from *another* SafeProxyFactory instance | refused: `AA33 reverted: NotFromFactory(sender)` | | |
| d2 | The sub-wallet naming a salt that does not produce it | refused: `AA33 reverted: NotFromFactory(sender)` | | |
| e1 | Primary Kernel v3.1 (PasskeyCoSignerValidator), created by a plain transaction to KernelFactory: first op | 409,709 | 0.000613 ETH | 695,929 |
| e2 | Primary Kernel: a later op | 378,741 | 0.000582 ETH | 503,321 |

The deposit went from 0.1 to 0.096394 ETH. The EntryPoint debited exactly 0.003606 ETH, and the paymaster's global
counter holds 0.003997 ETH. That is the sum it charged, at least what it paid. The Sepolia column comes from running
the same `handleOps` with `eth_simulateV1` on Sepolia's state, overridden with the fork's pre-state.

**Found on Sepolia, not on the fork.** Sepolia charges about 105k gas to write a storage slot from zero; the pinned
Foundry charges 22k. The paymaster's validation writes one fresh slot for an account's first op and two for its very
first op ever. With `paymasterVerificationGasLimit` = 150k, row a failed on Sepolia with `AA33 reverted` and no data
(out of gas in validation). It got through only when the bundle's own gas limit was above the 16,777,216
per-transaction cap, where Sepolia's state-gas reservoir pays instead. The rows above sign **300k**. The wallet should
too, on Sepolia: the "100,000 to 200,000" in `docs/ownerless-paymaster.md` holds for the pinned EVM only. It does
since SRM1-17: `ownerlessVerificationGas(11155111)` is 300k (packages/wallet/src/ownerless-paymaster.ts), and this
script reads its figure from there.

The ops sign 3.0M + 0.5M + 0.2M gas plus 300k + 60k for the paymaster. `maxCost` is therefore 4.06M × `maxFeePerGas`.
The executors set the fee at 2 × base fee + 1 gwei. So `MAX_COST_PER_OP` (0.01 ETH) refuses these ops once Sepolia's
base fee is above about 0.73 gwei. On 14 October it was 18 wei.

### Cost of the real run

Every deployment transaction is also run on Sepolia itself, read-only:

- `eth_estimateGas` gives the gas limit each one needs. A transaction that calls a contract the run creates is given
  that contract's fork code as a state override.
- `eth_simulateV1` runs the whole sequence on Sepolia's state and gives the gas each one uses.

| Transaction | Fork gas | Sepolia gas used | Sepolia limit needed |
|---|---|---|---|
| create2 PasskeyCoSignerValidator | 994,505 | 6,930,441 | 7,042,784 |
| create2 FrostValidator | 1,031,014 | 7,225,006 | 7,342,025 |
| create2 KernelAvatarAdapter | 518,766 | 3,541,594 | 3,600,146 |
| create OwnerlessPaymaster | 1,490,353 | 10,440,155 | 10,524,181 |
| addStake() (1 ETH) | 57,983 | 148,803 | 151,151 |
| deposit() (0.1 ETH) | 54,963 | 145,783 | 148,107 |
| create AuditGrantRegistry | 856,001 | 5,965,553 | 6,014,066 |
| create ShieldedNoteLog | 442,101 | 2,988,383 | 3,013,268 |
| **Total** | **5,445,686** | **37,385,718** | 37,835,728 |

**At 2 gwei: 0.0748 ETH of gas + 1.1 ETH stake and deposit = 1.1748 ETH, inside the 1.2 ETH budget.** At Sepolia's
price on 14 October (about 0.001 gwei) the gas is negligible. The deployer held 1.598 ETH.

Forge sends each transaction with 10× its own estimate as the gas limit, as `deploy-movva-rail.ts` does. The largest
ratio measured was 7.07×, on the PasskeyCoSignerValidator create2. The script raises the multiplier if a projection
ever needs more.

### Running it

```bash
# rehearsal: a fresh anvil fork of SEPOLIA_RPC (ports 8966-8969 only), the e2e above, and the Sepolia projection
npx tsx scripts/deploy-account-stack.ts                 # record: deployments/sepolia-account-stack.rehearsal.json

# the real run, from a clean checkout of the commit to deploy, with .env holding SEPOLIA_RPC,
# SEPOLIA_DEPLOYER_ADDRESS and SEPOLIA_DEPLOYER_KEY
ACCOUNT_STACK_CONFIRM=deploy-to-sepolia-from-0xd24912278743ec80c4183cfa17091f6521ba73d1 \
  npx tsx scripts/deploy-account-stack.ts --broadcast-sepolia

# afterwards, any time, read-only
npx tsx scripts/deploy-account-stack.ts --verify deployments/sepolia-account-stack.json
```

`--broadcast-sepolia` refuses unless all of the following hold:

- the RPC answers chain id 11155111 and is not a local node;
- the confirmation names the deployer;
- the key is the deployer's;
- the working tree has no uncommitted file outside `deployments/`;
- a full rehearsal (deploy, verify, projection and e2e) passes on a fresh fork;
- the deployer holds the stake and deposit plus twice the projected gas at Sepolia's current price.

It writes `deployments/sepolia-account-stack.json` after every step. That record holds:

- the addresses, the pre-existing contracts and what proved each;
- each transaction's hash, gas and value;
- the constructor arguments, decoded and encoded;
- the 48 checks;
- one `forge verify-contract` command per contract. These are not run.

Forge's broadcasts and logs go to `~/.cache/mova-deploy/sepolia-account-stack/`, out of the repository, because
forge's resume cache there holds the RPC URL. If the run stops part-way, rerun the same command with `--resume`:

- an interrupted forge broadcast continues with forge's own `--resume`;
- a finished one is adopted, never sent again;
- a paymaster an earlier attempt created is reused (`OWNERLESS_PAYMASTER`), and its stake and deposit are only topped
  up to their targets.

The live path (forge signing with a key, the 1000% multiplier, its own cache, resuming by adoption) was exercised
against a local fork with anvil's published dev key #0. No transaction went to Sepolia.

## The MOVVA-only rail (client decisions of 14 October 2026)

**Rehearsed on a Sepolia fork, not broadcast.** The client's written decisions of 14 October 2026 change what
`scripts/deploy-movva-rail.ts` deploys. The 6 October deployment below and every earlier record keep their shape; they
are historical.

**`--verify` and old records.** This build has no `SavingsMovva` artifact and a `MovvaReserve` without the savings path,
so `scripts/deploy-movva-rail.ts --verify <record>` **refuses** any record that carries an sMovva (`contracts.movva.savings`
or `pools.savings`): that is every record under `deployments/` today - the live 6 October rail
(`deployments/sepolia-movva-rail.json`) and both 19 September rehearsal records. Its bytecode comparison could only fail.
Verify such a record from the commit it was deployed from (the record names it; every commit up to `4d0f568` still has
`SavingsMovva`), for example `git worktree add ../mova-<commit> <commit>`, then `npm ci` and `--verify` there. The record
layout, optional savings fields included, is still parsed.

**D1, MOVVA only.** The product flow is deposit PIX, mint Movva, hold it as shielded notes in the Movva Privacy Pool,
and withdraw to PIX through the Movva `FiatEscrow` / `OffRampEscrow` pair. The rail no longer deploys:

- **sMovva, and the savings path itself.** *As first rehearsed (below)*, `DeployMovva.s.sol` took `MOVVA_SAVINGS=off`
  and the reserve kept dormant savings code (`distribute` reverting `NoSavings`, `setSavings` a delayed change).
  **Since 15 October 2026 the code has no savings path at all:** `SavingsMovva.sol`, `ShieldedYieldRouter.sol`,
  `@mova/zap-relayer` and the Movva distribution keeper are deleted; `MovvaReserve` has no `distribute`,
  `previewDistribute`, `savings`/`setSavings` or distribution fee, and `setFees` / `setLimits` take two arguments.
  `DeployMovva.s.sol` has no `MOVVA_SAVINGS`, `MOVVA_DISTRIBUTION_FEE_BPS`, `MOVVA_MAX_DISTRIBUTION_BPS_PER_DAY` or
  `MOVVA_VESTING_SECONDS`, and the rail deploys the Movva pool only. The reserve's surplus above its target stays in it
  as backing (Mova's, reached only through the hedge path). The rail's verification checks that the removed entry
  points do not answer. `MovvaReserve`'s runtime went from 22,907 to 20,969 bytes.
- **The ETH/USDT on/off-ramp.** `DeployRamp.s.sol` takes `MAIN_PAIR=off`: no ETH/USDT `FiatEscrow` / `OffRampEscrow`
  pair, no ETH band oracle, no USDT band oracle, no ramp FX leg. It deploys the `LPRegistry`, the
  `ReclaimZkTlsVerifier` and the Movva pair, and refuses `ORACLE_KIND`, `USD_FEED_ASSETS` and `ASSETS` (which would
  configure the pair it does not deploy).

The reserve still mints against USDT: the stand-in USDT on Sepolia, priced by Chainlink USDC/USD as its USD leg and the
Pyth FX leg. Those stay. `DeployMovva` still deploys the centavo band adapter (`ScaledFxBandOracle`); it has no
governance and nothing on this rail reads it.

**The Movva escrows' constructor oracle.** Both escrows take an `oracle` constructor argument, stored as the immutable
`ORACLE`. That argument has exactly one use: the constructor lists native ETH with it
(`assets[address(0)] = {oracle, 18, enabled}`). No function reads `ORACLE`, and every band check reads the asset's own
`assets[asset].oracle` (`FiatEscrow.sol` and `OffRampEscrow.sol`, constructors and `_requireWithinBand`). So the Movva pair is
now constructed with **the reserve** as that argument, in both modes of `DeployRamp`. `_wireMovva` delists native ETH
during setup, as before, and the script and the rail's verification both assert it delisted and `ORACLE() == reserve`.
No ETH band oracle is deployed, and the rail has no Chainlink ETH/USD dependency. Re-enabling native ETH would be a
risk-increasing `setAsset` that waits out the delay. After `--finalize` nobody can do it. No ETH or USDT is listed on
any deployed escrow; the verification checks both.

**Upstream's ETH pool.** The `protocol` step is still upstream's `script/Deploy.s.sol:EthereumSepolia`, unedited, and it
deploys and registers an ETH `PrivacyPoolSimple`. That pool is upstream's. The product does not use it, and no escrow
points at it.

**A1, the ASP registry.** A new `asp` step runs after `pools`. It deploys `contracts/AspRootQuorum.sol` with n = 3 and
k = 2, bound to the new Entrypoint. It then sends `grantRole(ASP_POSTMAN, quorum)` and `revokeRole(ASP_POSTMAN,
deployer)` and checks that the quorum is the only holder, so the deployment already has its final postman. On Sepolia
the three ASPs are test identities, `movva-rail/<seed>/asp/<i>` for i = 0..2. `asp/0` stands for Movva; `asp/1` and
`asp/2` stand in until the client confirms two independent entities. The quorum has no owner and no setter, so a real
set of ASPs means a new quorum, granted ASP_POSTMAN before `--finalize`. The verification checks its `ENTRYPOINT`,
`THRESHOLD` = 2, `ASP_COUNT` = 3, the three ASP addresses in order, and that ASP_POSTMAN is held by the quorum and
nobody else (every account a `RoleGranted` event ever named is re-checked). The privilege inventory catalogues it:
`vote` is gated to the fixed ASPs (`NotAnAsp`), and it has nothing else that changes state. `--finalize` refuses unless
ASP_POSTMAN is held by the recorded quorum and nobody else, its runtime code is this build's `AspRootQuorum`
(immutables masked), and its `ENTRYPOINT`, `THRESHOLD`, `ASP_COUNT` and `asps()` are the recorded ones: a strict
majority of at least two, without the deployer (SRM1-9; see "The `--finalize` guards" below).

**C2, the guardian goes at finalization.** The reserve's guardian has one power, `pauseMint`, which only the guardian
and the governor pass. `setGuardian` is governor-only. It is **instant** even after setup (`_authorizeChange(false)`:
the reserve classes rotating the guardian as removing risk), and it refuses only `address(0)`. So `--finalize` sends
`setGuardian(0x...dEaD)` in the same run, **before** the reserve's `transferGovernor`. No schedule and no second run are
needed. It refuses to renounce the reserve's governor while the guardian is anything else. It refuses to finalize at all
while minting is paused, because nobody could ever resume it. Since the SRM1-8 fix `setGuardian` is the first thing
finalize sends, and `mintPaused` is read immediately before it, again after it lands, and again before the reserve's
`transferGovernor`: a pause that slips in stops the run while the governor can still `resumeMint`. Afterwards the verification checks that the guardian is
`0x...dEaD` and minting is not paused. The inventory checks that every probed caller gets `NotGuardianOrGovernor` from
`pauseMint`: the stranger, the deployer, the ASPs and every other holder. Redemptions never could be paused. The
divergence breaker, where one is deployed, still halts by itself (Sepolia has none: `MOVVA_RAIL_BREAKER=off`).

**Deploying it for real needs a fresh deployer.** `0xD249…73D1` used its CreateX salts on 6 October, so its protocol
step would collide (`CreateCollision`). The rehearsals below ran as a fresh, impersonated address. The Pyth keeper now
has one leg to keep fresh: `PYTH_FX_ORACLE=<contracts.movva.fxLeg from the JSON>`.

**Rehearsals, 14 October 2026.** (Before the savings code was removed: the reserve then still carried the dormant
savings path; the re-run on the current code is "Rehearsals, 15 October 2026" below the tables.) Two runs
on fresh anvil forks of Sepolia (blocks 11,912,383 and 11,912,439), from commit `6d6658d` with this work uncommitted, as the fresh impersonated deployer
`0x6e10066B02154aD4845eabaaD29E639764CE9b16`, with `MOVVA_RAIL_BREAKER=off`. Their records were written outside the
repository; nothing under `deployments/` changed. Both runs produced the same 20 addresses, all running this build
(build hash `bb37c473807ea25d6eabc9394271d8864ff5662eb9314d65f1ea3993b6e445f3`).

| Step | Txs | Gas |
|---|---:|---:|
| `protocol` (upstream, unchanged) | 6 | 5,963,104 |
| `usdt` | 1 | 576,311 |
| `movva` (no sMovva) | 20 | 12,040,534 |
| `pools` (Movva only) | 2 | 1,907,293 |
| `asp` (quorum, grant, revoke) | 3 | 788,071 |
| `ramp` (`MAIN_PAIR=off`) | 26 | 16,046,175 |
| `bind` | 1 | 42,862 |
| **total** | **59** | **37,364,350** |
| `finalize` (OWNER_ROLE, guardian, 8 governors) | 10 | 290,776 |

| Run | Checks | Privileges |
|---|---|---|
| as is | 240 pass, 7 expected, 1 fail | 177 functions classified, 0 unknown; 8 governors and OWNER_ROLE with the deployer; ASP_POSTMAN with the quorum alone |
| `--finalize` | 250 pass, 7 expected, 1 fail | 177 classified, 0 unknown; 8/8 governors and the guardian `0x...dEaD`; OWNER_ROLE held by nobody; ASP_POSTMAN with the quorum alone; nobody passes `pauseMint` |

The 7 expected are every reader of Sepolia's stale Pyth FX.USD/BRL (publishTime 1783080563), each refusing with exactly
`StaleRate`. The one failure in both runs is the record's "the commit is clean for every build input": a concurrent
session had `foundry.toml` uncommitted (an `fs_permissions` entry for its own tests, which changes no bytecode). The
real run refuses a dirty tree anyway.

The 20 addresses: the Entrypoint (proxy and implementation), both verifiers, upstream's ETH pool, PoseidonT3/T4
(pre-existing), the stand-in USDT, MovvaReserve, Movva, the Movva FX leg (`PythFxOracle`), the band adapter,
`FeeSplitter`, `NodeRewards`, the Movva pool, the `AspRootQuorum`, `LPRegistry`, `ReclaimZkTlsVerifier`, and the Movva
`FiatEscrow` and `OffRampEscrow`. Eight are `DelayedGovernance` contracts, down from 14.

**Rehearsals, 15 October 2026 (the current, savings-free code).** Two runs on fresh anvil forks of Sepolia (blocks
11,918,707 and later), from commit `4d0f568` with the savings removal uncommitted, as the same fresh impersonated
deployer with `MOVVA_RAIL_BREAKER=off` (and `MOVVA_FINALIZE_ALLOW_TEST_KEYS=yes-this-is-a-rehearsal` for the finalized
run); records outside the repository. The same 20 addresses, all running this build.

| Step | Txs | Gas |
|---|---:|---:|
| `protocol` | 6 | 5,963,104 |
| `usdt` | 1 | 576,311 |
| `movva` (no savings path) | 20 | 11,620,586 |
| `pools` (Movva only) | 2 | 1,907,293 |
| `asp` | 3 | 788,071 |
| `ramp` (`MAIN_PAIR=off`) | 26 | 16,342,330 |
| `bind` | 1 | 42,862 |
| **total** | **59** | **37,240,557** |
| `finalize` | 10 | 290,709 |

| Run | Checks | Privileges |
|---|---|---|
| as is | 246 pass, 3 expected, 1 fail | 176 functions classified, 0 unknown; 8 governors and OWNER_ROLE with the deployer; ASP_POSTMAN with the quorum alone |
| `--finalize` | 283 pass, 3 expected, 1 fail | 176 classified, 0 unknown; 8/8 governors renounced; OWNER_ROLE held by nobody; ASP_POSTMAN with the quorum alone |

The 3 expected are Sepolia's stale Pyth FX.USD/BRL; the one failure is again "the commit is clean for every build
input" (the removal was uncommitted). New checks: the reserve answers none of `distribute()`, `previewDistribute()`,
`savings()` or `distributionFeeBps()` (each reverts with no data), and its fees are mint and redeem only.

## The Movva rail on Sepolia (6 October 2026)

**Deployed, not finalized.** The whole rail is on Sepolia from a fresh deployer, `0xD24912278743Ec80c4183CfA17091f6521BA73D1`,
which still holds every governor and the Entrypoint's `OWNER_ROLE` and `ASP_POSTMAN`: `--finalize` has not been run. No
funds have been deposited. The divergence breaker is not deployed (`MOVVA_RAIL_BREAKER=off`: Sepolia has no second BRL
price source to read).

| | |
|---|---|
| Record | `deployments/sepolia-movva-rail.json`; report, privileges, ABIs and Etherscan script in `deployments/sepolia-movva-rail/` |
| Deployed from | `793415112ef9fdd9d001e742f07f1bfe3d61e17a` (contracts, circuits and build configuration) |
| Resumed on | five later commits that change only `scripts/`; the report lists them and every file that differs |
| Build hash | `96e4bfd977cbfdf5101553921dab70c6936bd306f47d005781cc7106e4dc1f36`, the same as the rehearsals' |
| Verification (live, read from Sepolia) | **315 pass, 10 expected (Sepolia's stale Pyth FX.USD/BRL), 0 fail**; 27 addresses, all running this build |
| Transactions | 86 succeeded, blocks 11,857,082 to 11,857,686, 364.4M gas, 0.401 ETH; plus one that reverted (below) |

**This rail predates the savings removal** (client decision D1, 14 October 2026). It carries `SavingsMovva` and an sMovva
pool, which stay on Sepolia; the current code has neither, and a rail deployed from it has no sMovva at all.

Per step: protocol 6 transactions (0.045 ETH), stand-in USDT 1 (0.005), Movva 22 (0.095), pools 4 (0.026), ramp 52
(0.231), bind 1. The deployer started with 0.8 ETH and holds 0.398.

Key addresses (the full table, with source and runtime hashes, is in `VERIFICATION.md`):

| | Address |
|---|---|
| Entrypoint (proxy) | `0x9197AD4F1eE2b141De302f9CD4729f0F15006Fc2` |
| ETH pool | `0xD74624725243035eF59CF7B5e8Be47B154d59391` |
| Movva pool / sMovva pool | `0xf083E3FACd02E4EEBeC72c3B96A822d95cC97468` / `0x1031ff88044CBd080E5041581f9ac4FF4440478B` |
| MovvaReserve / Movva / SavingsMovva | `0xA82Eb875f4899F6eaa5516cE3954000924D4975c` / `0x3a6cBaF56E26D851292a102b61dBd6f0e6087695` / `0xa8e9987aC585c1e72b8b4e351558473E968Cbfae` |
| Stand-in USDT | `0x9Ab5d6ee8aC68E670e86AA88DD77A5B3F4c09b0c` |
| LPRegistry / ReclaimZkTlsVerifier | `0xa35eC3abAef03B224298168aAb5eCDe3AD5A7717` / `0x3b27Ce4CCeBf6FAB0ed78da1bdb53E7d1Ab2d2e3` |
| FiatEscrow / OffRampEscrow (ETH, USDT) | `0xAAF76B540E4920DBf64634F11264495748246874` / `0xcf5b6e27FebB8Eb166775290f29CD2DC7a02b5F0` |
| FiatEscrow / OffRampEscrow (Movva) | `0x834D7D0c20B081561b7Af63f311f979881cD8aa3` / `0xb15268a0B9F2e71CF6bb37A1f0c61EA07F1DcF6c` |

What happened on the way, all in the deploy tooling and none in a contract:

- **Gas.** The first transaction (`0x63093acc…824a`, the CreateX deploy of the withdrawal verifier, nonce 0) reverted
  with `FailedContractCreation`. Sepolia now prices state creation about five times higher than the pinned Foundry
  (v0.3.0) models: forge estimated 661k, the node needed 3.28M. Live forge runs now send ten times forge's estimate as the
  gas limit (unused gas is refunded). The reverted transaction created nothing.
- **Resuming.** RPC hiccups stopped the run three times (a read before the node had the block, a lost receipt, a
  throttled request). The script now resumes on a later commit only when nothing outside `scripts/` and `docs/` changed,
  and records each such commit (`resumedOnCommits`); the pools step skips a pool already deployed and registered and
  carries over its recorded transactions; an interrupted forge broadcast continues with forge's `--resume`, from its own
  cache path; a finished broadcast is adopted rather than run again. The "no build input changed" check compares the
  commits' diff against the build inputs, so it still fails if a contract, a circuit or the build configuration moved.
- **RPC limits.** The inventory reads event logs in windows the provider accepts (Alchemy's free plan allows 10 blocks)
  and retries throttled calls.

Re-run the verification at any time, read-only, **from the deploy commit** (`7934151`, or any commit up to `4d0f568`):
`npx tsx scripts/deploy-movva-rail.ts --verify deployments/sepolia-movva-rail.json --record-dir <dir>`. The current
checkout refuses this record because it carries an sMovva (see "The MOVVA-only rail", "`--verify` and old records").

## A partial rail deployment found on Sepolia (21 September 2026)

Found on 6 October 2026, while rehearsing the real run, and **superseded by the deployment above**, which uses a fresh
deployer. It was run by the repository's owner on 21 September; this repository's records had said the rail was "not on
Sepolia yet", and why it stopped is not recorded here. On-chain
(Etherscan lists the deployer `0x4C0A…d214`'s transactions) the deployer was funded with 0.5 ETH from `0xeb9A…1191` on
21 September and between 08:14 and 08:16 UTC sent:

- the **protocol step, complete**: five CreateX deployments (both verifiers, the two Poseidon libraries, the Entrypoint
  implementation), the Entrypoint proxy, and `registerPool` for the ETH pool;
- the **stand-in USDT**, at `0xc241A572883241946a6780E996808C321b06baB0` (symbol USDT, 6 decimals);
- the **first contract of the Movva step**, a `PythFxOracle` at `0x6A7Fa8E2A5CfA74DacFf15C6ed9674b55DbAB96A`, whose
  governor is the deployer; the step did not go further.

At 08:54 it sent 0.4914 ETH back to `0xeb9A…1191`. The addresses are exactly those our rehearsals predicted, because the
CreateX salts are bound to the deployer:

| | Address (Sepolia) |
|---|---|
| Entrypoint (proxy) | `0x25efe3a412a69a2848AA1e2A90c0f0080d2de469` |
| Entrypoint implementation | `0xD726E05f28A27c5af85A1890244a00B29dE9449E` |
| ETH pool (registered: minimum 0.001 ETH, vetting 100 bps, relay cap 100 bps) | `0x8fD2422a51f400e88aB40065343f9eBF892bec91` |
| WithdrawalVerifier | `0xa6a4327FC63c88EA69372A388217f0BA7d42f897` |
| CommitmentVerifier | `0xB1c6d175d5D8aF7330FC35fc9579b67153ebcD41` |
| PoseidonT3 / PoseidonT4 | `0x8ffdA7Ed8B4aD98C2C34f54B76821711F4a6f2C5` / `0xe393dd7287Db9982e6f845824854Baf8b8e823AF` |

**The deployer still holds `OWNER_ROLE` and `ASP_POSTMAN` on that Entrypoint**, and no association-set root has been
posted. Consequences for the real run:

- The deploy script's protocol step cannot be repeated from this key: it collides on the CreateX salts
  (`CreateCollision`). `--resume` now continues from a record that has the protocol step done, in rehearsal as well as
  in the broadcast.
- This RPC keeps about a day and a half of history, so the privilege inventory cannot scan the role events of a stack
  deployed before that window (`pruned history unavailable`). A complete inventory of a resumed deployment needs an
  archive-capable RPC. A fresh deployment, whose events are all recent, does not.
- A rehearsal of everything after the protocol step, on a fork of Sepolia as of 6 October, passes: 86 transactions,
  54.1M gas (about 0.06 ETH at 1.1 gwei), 143 checks pass, 10 expected (Sepolia's stale Pyth price), 0 fail. Nothing was
  broadcast.

## Sepolia rehearsal of the Movva rail (14 September 2026; record added 19 September)

**The real deployment is in "The Movva rail on Sepolia (6 October 2026)" above; this section is the rehearsal that preceded it.** The whole Movva rail is one command, `scripts/deploy-movva-rail.ts`. That command
has run in full against an anvil fork of Sepolia at block 11,705,375, as the real testnet deployer
`0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214` (impersonated, nonce 0). The deployer holds 0 ETH on
Sepolia, so the real run is waiting for funding. On 19 September it ran again on fresh forks, with the deployment
record and the privilege inventory, once as is and once with `--finalize`. Both produced the same 28 addresses. See
"The deployment record" and "Privileges, and `--finalize`" below.

### What it deploys, in order, and what each step cost on the fork

| Step | What | Txs | Gas |
|---|---|---:|---:|
| `protocol` | Privacy Pools, upstream's `script/Deploy.s.sol:EthereumSepolia` (owner and postman = deployer): both verifiers, the Entrypoint behind its proxy, the ETH pool | 6 | 5,963,068 |
| `usdt` | the stand-in USDT (see substitutions) | 1 | 576,311 |
| `movva` | `DeployMovva.s.sol`: MovvaReserve and Movva, sMovva, a `PythFxOracle` on Sepolia's Pyth (`0xDd24F84d36BF92C65F92307595335bdFab5Bbd21`, FX.USD/BRL), the centavo band adapter, `FeeSplitter` and `NodeRewards`. Fees at their defaults (0.10% / 0.10% / 20%), LP reward share 0, the test LP as gateway, supply cap 1,000,000 Movva | 22 | 12,937,638 |
| `pools` | Movva and sMovva `PrivacyPoolComplex`. Deployed through CreateX with upstream `DeployComplexPool`'s salt (the script skips its interactive prompts), linked to the Poseidon libraries already on Sepolia, and registered on the new Entrypoint: minimum 1 Movva / 1e24 sMovva shares, vetting 10 bps, relay cap 100 bps | 4 | 3,814,616 |
| `ramp` | `DeployRamp.s.sol`: `ORACLE_KIND=signed-fx` over its own Pyth leg. ETH band on Chainlink ETH/USD (max age 4,500 s). Stand-in USDT band on Chainlink USDC/USD (90,000 s), capped at 250,000 per escrow. The four `receiptTemplates` pages as zkTLS endpoints, the boleto pages widened to BOLETO. 3 witnesses and 3 card attestors (threshold 2), an arbitrator, the test LP institutional with R$ 50.000 credit, the Movva pair (300 bps), and `NODE_REWARDS` | 59 | 32,192,237 |
| `bind` | `admin rewards:registry <NodeRewards> <registry>`: `packages/ops` builds the call (class: immediate, never funded), the script checks the calldata, and the governor sends it | 1 | 42,862 |
| **total** | | **93** | **55,526,732** |

The deployer governs everything (a testnet, so no multisig). Governance delay 48 h, dispute timeout 30 days.
The Movva pools' 100 bps relay cap is the value the live examples register. The 8 September run above measured a
141 bps relayer quote for a 0.05 ETH withdrawal at Sepolia gas prices, so small relayed Movva withdrawals will revert
`RelayFeeGreaterThanMax()` until the deployer raises the cap with `updatePoolConfiguration`, as was done for ETH.
Every address, block, transaction and check is in `deployments/sepolia-movva-rail.rehearsal.json`.

### Verification: 149 wiring checks pass, 10 expected, 0 fail

After deploying, the script runs a read-only pass (the record then adds its own checks: see "The deployment record"):

- code at all 28 addresses;
- all 14 governed contracts have the deployer as governor, setup closed and a 48 h delay: the reserve, both Pyth legs, the
  splitter, NodeRewards, the ETH and USDT oracles, the registry, both verifiers and all four escrows;
- the Entrypoint's owner and postman roles; the ETH, Movva and sMovva pools registered with their parameters and bound
  to their assets;
- the reserve's wiring (token, stand-in USDT, USDC/USD feed, FX leg, sMovva, fees paid to the splitter, fee bps,
  cap, gateway); both Pyth legs' feed id and limits; splitter to NodeRewards, paid in Movva; NodeRewards bound to
  the registry, and the registry's hook pointing at NodeRewards;
- the registry in Phase A, accepting all four escrows. Each escrow has both verifiers, the arbitrator and the 30-day
  timeout; the test LP is INSTITUTIONAL. Stand-in USDT is listed (oracle, 6, enabled) and capped on the main pair.
  On the Movva pair, Movva is listed with the reserve as its band and native ETH is delisted. Both on-ramps point at
  the Entrypoint and their pools;
- `provesBankSession()` is true on `ReclaimZkTlsVerifier` and false on `AttestorQuorumVerifier`. There are 4
  endpoints, with rails 2, 2, 4 and 4, at `https://api.banco-lp.example/`;
- Chainlink ETH/USD and USDC/USD are fresh for their max ages.

**The 10 expected.** Sepolia's FX.USD/BRL was last posted on 2026-07-03 at 12:09:23 UTC (publishTime 1783080563).
Every reader of the Pyth leg refused with exactly `StaleRate(1783080563)`:

- both `PythFxOracle` rates and the ramp leg's band reading;
- both centavo adapters;
- the ETH and USDT bands (the cross passes the leg's error through; their Chainlink legs were fresh);
- the reserve's `brlPerUsdtE18` and `bandBrlPerUsdtE18`.

That is the contracts refusing a price that is months old, not a deployment fault. The check fails if any of these
readers reverts for any other reason, or returns a price while Pyth's is stale.

### Substitutions (rehearsal only)

- **USDT.** Sepolia has no canonical USDT, so the rehearsal uses `TetherLike` from
  `contracts/test/ERC4626Adapter.t.sol`. It has 6 decimals and Tether's `isBlackListed`/pause/fee surface, so
  DeployRamp still demands a cap. Unlike Tether, anyone can mint, pause or blacklist it, so its balances mean nothing.
- **USDT/USD.** Chainlink USDC/USD on Sepolia (`0xA2F78ab2355fe2f984D808B5CeE7FD0A93D5270E`, updating every ~86,436 s),
  used by both the reserve and the ramp's USDT band.
- **People.** The witnesses, card attestors, arbitrator, LP (institutional LP and Movva gateway) and the reserve's
  guardian, treasurer, hedge treasury and treasury are all test keys: `keccak256("movva-rail/<seed>/<role>/<i>")`.
  The fork used the public seed `public-sepolia-rehearsal`. The real run refuses that seed and requires a secret
  `MOVVA_TEST_KEY_SEED`.
- **Bank endpoints.** The illustrative receipt templates from `packages/ramp` (`receiptTemplates`, hashed with
  `hashProviderParams`), not a real bank's.
- **Privacy Pools.** A fresh upstream stack owned by the deployer. Registering the Movva pools needs `OWNER_ROLE`,
  and on the 8 September Entrypoint that role is held by a key that is not on this machine. The upstream script
  overwrites `protocol/contracts/deployments/11155111.json`; the rehearsal script restores that tracked file and
  keeps the new manifest in its work directory.

### Measured cost

| Gas price (55,526,732 gas) | Cost | With a 2x margin |
|---|---:|---:|
| the fork's `eth_gasPrice` at the start, 2.043 gwei (anvil adds its default priority fee to the fork's base fee) | 0.1134 ETH | 0.2269 ETH |
| Sepolia's `eth_gasPrice` after the run, 0.999 gwei | 0.0555 ETH | 0.1110 ETH |

A second full run went through `--broadcast-sepolia` on a fresh fork, with a different seed. It:

- measured 55,526,744 gas;
- verified with 0 failures;
- produced the same contract addresses;
- then refused: `fund 0x4C0A... with at least 0.117968556373863104 more Sepolia ETH` (2x at 1.062 gwei).

Nothing was broadcast, and the deployer's Sepolia nonce is still 0. Every address depends only on the deployer and its
nonce (CREATE) or on upstream's salt and init code (CreateX). A real run from nonce 0 should therefore land at the
addresses in the rehearsal JSON.

**Fund the deployer with 0.25 Sepolia ETH.** That covers the higher row, margin included.

The gas sponsor is not in that figure. Redeploying `SponsorPaymaster` so that public bundlers accept it (see
"Operational notes" above) needs its gas deposit (`DEPOSIT_WEI`, default 0.05 ETH) plus a 1 ETH stake sent by
its owner (`DeployPaymaster`'s `STAKE_WEI` default). With that, fund about **1.3 Sepolia ETH**.
The stake is locked, not spent: it comes back after `unlockStake` and one day.

### Running it for real

Once `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214` holds that ETH, run from a machine whose `.env` has `SEPOLIA_RPC`,
`SEPOLIA_DEPLOYER_ADDRESS` and `SEPOLIA_DEPLOYER_KEY`:

```bash
# keep the seed secret and keep it: it re-derives the witness, attestor, arbitrator, LP and reserve-role keys
export MOVVA_TEST_KEY_SEED=$(openssl rand -hex 32)
MOVVA_RAIL_CONFIRM=deploy-to-sepolia-from-0x4c0aa1208f8e3e1664edacc9e0275c18363ed214 \
  npx tsx scripts/deploy-movva-rail.ts --broadcast-sepolia
```

It refuses to broadcast unless all of these hold:

- the RPC answers chain id 11155111 and is not an anvil or hardhat node;
- the confirmation matches;
- the key belongs to the deployer;
- the seed is set and is not the public one;
- a full rehearsal of the same run, on a fresh fork, passes with zero failed checks;
- the balance covers that rehearsal's gas twice over at Sepolia's current gas price.

Every one of these refusals was exercised on 14 September.

The script writes `deployments/sepolia-movva-rail.json` after every step and keeps forge's logs and broadcasts in
`deployments/sepolia-movva-rail-<time>/`. If it stops part-way, fix the cause and rerun the same command with
`--resume`.

Then post the price. Nothing prices until FX.USD/BRL is fresh on Sepolia, which needs a Hermes API key:

```bash
RPC_URL=$SEPOLIA_RPC PYTH_FX_ORACLE=<contracts.ramp.fxSource from the JSON> KEEPER_KEY=0x<a funded key, no role> \
HERMES_API_KEY_FILE=/path/to/hermes_api_key \
  node --import tsx packages/yield/src/bin/pyth-keeper.ts
npx tsx scripts/deploy-movva-rail.ts --verify deployments/sepolia-movva-rail.json   # from a pre-D1 commit: see below
```

(Since the savings removal, `--verify` on a record that carries sMovva must run from a commit up to `4d0f568`: see
"The MOVVA-only rail", "`--verify` and old records".)

One keeper serves both Pyth legs, because both read the same feed. Once it posts, inside the FX core session
(13:30-21:00 UTC, weekdays) the 10 expected checks become passes. Outside it, the bands take the last close and the
rates still refuse, by design.

### The deployment record

Every run now ends with a `record` step (`scripts/deployment-record.ts`, `scripts/privilege-inventory.ts`,
`scripts/rail-artifacts.ts`). It writes the following into the deployment JSON's `record`, and into
`deployments/<name>/`:

| What | Where |
|---|---|
| chain id and name; for a rehearsal, the fork and its block | `record.chain` |
| the git commit and branch, and every uncommitted file with its sha256. A file that is a build input of a deployed contract fails a check | `record.git`, check "the commit is clean for every build input" |
| forge's version; per build, the solc version (and the binary's sha256), optimizer, EVM version, viaIR, metadata hash, remappings | `record.toolchain` |
| the build hash, and every contract's runtime-bytecode sha256 (see below) | `record.buildHash` |
| per address: contract, artifact, source file and its sha256, runtime sha256, on-chain code sha256, the match, creation transaction, constructor arguments (raw and decoded), the `forge verify-contract` command and its dry-run | `record.contracts` |
| the ABI of every deployed contract (the Entrypoint proxy's callable ABI is `Entrypoint.json`) | `deployments/<name>/abi/<Contract>.json` |
| the privilege inventory, before and after `--finalize` | `privileges` (summary); `deployments/<name>/privileges.json` (full) |
| the report: what, where, the build hash, every check grouped, the privileges in plain words, what remains and why, and what was not verified | `deployments/<name>/VERIFICATION.md` |
| the Etherscan commands: NOT run | `deployments/<name>/etherscan-verify.sh` |

**The build hash** is sha256 over the runtime bytecode of every distinct deployed contract, as compiled (library
placeholders as 20 zero bytes, immutables as the compiler's zeros), concatenated in order of their hex. It depends on
the build alone. `npx tsx scripts/deployment-record.ts build-hash <deployment.json>` recomputes it from a checkout and
says whether it equals the recorded one. At `dbeec90` it is
`7cee8f879cbd15e9c97bdbf0ce3c82a88bc0e1a95e7de03b9b6ec9029bec9f21`, over 22 contracts. Every run on 19 September got
the same value.

**The bytecode match.** Every address's code must equal its artifact's runtime code byte for byte, except at the
immutable positions the compiler reports. Libraries are linked to the recorded Poseidon addresses, and a library's own
address sits in its first PUSH20. All 28 match. Each creation transaction's init code must be the build's creation code
followed by the constructor arguments. It is, for every contract this run created: 25, CreateX's included. Movva is
created inside MovvaReserve's constructor, and the Poseidon libraries were already on Sepolia. All 110 source files
the deployed contracts were compiled from hash on disk to the keccak256 their build metadata recorded. The root build
appends CBOR metadata, so there a match pins the exact source text. The protocol build does not
(`bytecode_hash = "none"`), so there it pins the bytecode.

**Etherscan, dry-run.** For each address, forge writes the standard-JSON input the verify command would submit
(`--show-standard-json-input`; nothing is sent). solc 0.8.28 compiles it, and the result must equal the code at the
address and, with the arguments, the init code. All 28 pass. Building it found one trap. The pools' `--libraries` must
be spelled through the remapping (`poseidon-solidity/PoseidonT3.sol:PoseidonT3:<address>`). Forge 0.3.0 writes any
other spelling into the input as a path solc does not match, and the pools then compile unlinked. The generated
commands use the right spelling, and the dry-run fails an input left unlinked.

**Clean tree.** `--broadcast-sepolia` now refuses unless the working tree is a commit: nothing uncommitted outside
`deployments/`. A rehearsal records its dirt instead. The 19 September rehearsals ran with this work and another
session's test files uncommitted. The record lists them, and none is a build input of a deployed contract. A second
snapshot at the end of the run must show no build input changed while it ran.

| Run | Output | Transactions | Checks |
|---|---|---:|---|
| as is | `deployments/sepolia-movva-rail.rehearsal.json`, `deployments/sepolia-movva-rail.rehearsal/` | 93 (55,526,732 gas) | 329 pass, 10 expected, 0 fail: 149 wiring, 56 bytecode, 28 Etherscan, 96 privileges |
| `--finalize` | `deployments/sepolia-movva-rail.finalized.rehearsal.json`, `deployments/sepolia-movva-rail.finalized.rehearsal/` | 108 (55,955,169 gas) | 344 pass, 10 expected, 0 fail: 149 wiring, 56 bytecode, 28 Etherscan, 111 privileges |

The 10 expected are the stale Pyth price, as above. To re-run the read-only checks against a rehearsal, keep its fork:
`npx tsx scripts/deploy-movva-rail.ts --keep-fork`, then
`npx tsx scripts/deploy-movva-rail.ts --verify <json> --rpc http://127.0.0.1:8953 --record-dir <dir>` (for these records,
which carry sMovva, from a commit up to `4d0f568`). The same record for any deployment in this JSON layout, on any chain, without the Sepolia-specific wiring checks, is
`npx tsx scripts/deployment-record.ts record <json> --rpc <url>`.

### Privileges, and `--finalize`

**The inventory.** For each of the 28 addresses it reads, from the chain:

- every role holder: address getters, plus every address the contract's own events named, each re-checked against the
  current mapping;
- the governor, `setupComplete` and any pending scheduled change;
- the Entrypoint's AccessControl roles and their admins;
- every switch (mint paused, phase, thresholds, a pool's `dead`);
- the EIP-1967 implementation, admin and beacon slots;
- every state-changing function.

The function list comes from the build's ABI. `CATALOG` in `scripts/privilege-inventory.ts` classifies each function
(who may call it, how fast, what it does). A function the ABI has and the catalog lacks fails the check as UNKNOWN,
and so does a catalog entry the ABI lacks. The first run caught one: `FiatEscrow.receive()`, which accepts ETH from
anyone. It is meant for ragequit proceeds; ETH sent any other way is credited to nobody and cannot be taken out. Each
function is also `eth_call`ed with zero arguments from a stranger, the deployer and every holder. A revert with the
contract's own authorization error is "refused"; anything else got past the gate. That proves on-chain who passes
each gate. 254 functions are classified; 0 are unknown.

**`--finalize`** is off by default. It uses only functions the contracts already have:

(This describes the 19 September runs. Since 14 October 2026 it also sends the reserve's guardian to `0x...dEaD`
before the reserve's governor, and the postman it requires is the rail's own `AspRootQuorum`: see "The MOVVA-only
rail" above.)


1. **The Entrypoint.** (Superseded in part by "The `--finalize` guards" below: it now refuses an OWNER_ROLE or
   DEFAULT_ADMIN_ROLE holder other than the deployer instead of revoking it, and requires the recorded quorum
   exactly.) It refuses unless the ETH, Movva and sMovva pools are registered and someone holds
   ASP_POSTMAN. Since 12 October 2026 it also refuses unless every ASP_POSTMAN holder is an `AspRootQuorum`
   (`contracts/AspRootQuorum.sol`) bound to this Entrypoint, of at least two ASPs with a strict-majority threshold:
   once OWNER_ROLE is gone the postman can never be replaced, so a single key there would be a permanent single
   point of failure (client decision, 12 October 2026: the ASP moves to a registry of independent ASPs outside the
   audited core). The quorum has no owner and no setter; its ASP set and threshold are fixed at deployment. It revokes OWNER_ROLE and DEFAULT_ADMIN_ROLE from anyone but the deployer (there was nobody), and
   renounces DEFAULT_ADMIN_ROLE if held (it never is: `initialize` grants only OWNER_ROLE and ASP_POSTMAN). Then it
   renounces OWNER_ROLE. OWNER_ROLE is the admin of every role (`Entrypoint.sol:80-82`), so afterwards nobody can
   upgrade the Entrypoint (`_authorizeUpgrade`, `:308`), add or change pools, take fees, or grant any role.
2. **Setup.** `completeSetup()` where still open. The forge scripts close it on all 14, so there was nothing to do.
3. **Governors.** Every DelayedGovernance governor goes to `0x000000000000000000000000000000000000dEaD`.
   `transferGovernor` (`DelayedGovernance.sol:125`) is one step and instant, and refuses only `address(0)`. So this
   is a real renunciation, not a pending two-step transfer.

It cost 15 transactions and 428,437 gas on the fork. Afterwards, the checks prove that the deployer passes none of the
governor or owner gates on any contract.

**What remains, by necessity** (`VERIFICATION.md`, "What remains, and why", has the lines):

- the **ASP postman**. A private withdrawal must prove the latest root (`PrivacyPool.sol:59`), and only the postman
  posts one. After finalizing, nobody can replace or remove it, and on this rail it cannot renounce either: the postman
  is the `AspRootQuorum`, which has no path to `renounceRole` (SRM1-21);
- the **arbitrator** on each escrow. A ruling reaches only a disputed order and pays one of its two counterparties;
- the **zkTLS witnesses and card attestors**;
- the Movva **gateway and treasurer**. Not the guardian: `--finalize` sends it to `0x…dEaD` (C2, SRM1-23), after the custody
  plan has held it on a 2-of-3 Safe until then;
- the registry's **LPs**.

No keeper holds an on-chain role. Pyth updates are permissionless, and so are `distribute`, `split`, `sync` and
`finalize`. (`distribute` no longer exists since the savings removal, D1.)

**What finalizing costs.** Every "instant" brake in the runbook's "If something is wrong after deployment" is a
governor call, and so is recovering from a lost gateway. After `--finalize` nobody can:

- revoke a leaked witness, attestor or arbitrator key (FiatEscrow's own NatSpec, at `FiatEscrow.sol:833`, says a
  stolen arbitrator key can drain every offer, and revoking it is the defence);
- revoke a verifier or endpoint, delist an asset or lower a cap;
- suspend an LP or open Phase B;
- resume minting after the guardian pauses it (the pause becomes permanent);
- add or remove a Movva gateway. If every gateway key is lost, nobody can redeem Movva again;
- repoint the reserve's oracle when Pyth retires the feed;
- withdraw the Entrypoint's vetting fees (they stay there for good);
- raise a pool's relay-fee cap.

### The `--finalize` guards (SRM1-1, -8, -9, -10)

Since the M1 security review (`docs/security-review-m1.md`), `stepFinalize` in `scripts/deploy-movva-rail.ts` runs in
two phases, and **no refusal can fire after an irreversible step**.

**Phase A: every check, read-only, before the first send.** One run lists every problem it finds, then refuses with
nothing renounced:
- every pool the record names is registered (registering needs OWNER_ROLE);
- the privilege inventory taken before finalizing passes `privilegeChecks`: every function classified, every gate
  refusing a stranger, no proxy or initializer surprise, no pending scheduled change, OWNER_ROLE with the deployer alone,
  ASP_POSTMAN with the recorded quorum alone, no unknown role (SRM1-9);
- every role holder is exactly the recorded set, with no extra holder (`exactHolderChecks`): the reserve's gateways,
  treasurer, hedge treasury, fee recipient, sMovva (records made before D1; the current rail has none) and yield vault; the FeeSplitter's treasury and rewards; NodeRewards'
  registry and exclusions; the registry's escrows, rewards hook and LPs; the verifier's witnesses and endpoints; each
  escrow's arbitrators, verifiers and listed assets; the quorum's ASPs. A legitimate change since deployment (say a
  custody rotation) is declared in the deployment JSON's `expectedHolders` (SRM1-9);
- the `asp` step's own `grantRole`/`revokeRole` transactions are among the role logs fetched, so a provider returning
  partial logs cannot hide a holder (SRM1-9);
- the ASP_POSTMAN holder is the recorded `AspRootQuorum`, running this build's code, with the recorded getters (SRM1-9);
- no hedge withdrawal is queued and unexecuted on the reserve. These are read from storage (`hedgeRequestCount`,
  `hedgeRequests(id)`), not logs. A queued request never expires, survives every renunciation, and anyone could
  execute it later (SRM1-10). The inventory now records the queue, and a finalized rail with one fails its verification;
- no role that remains for ever is a test identity, and no zkTLS endpoint is an illustrative template (SRM1-1). The roles
  checked are the witnesses, the arbitrators, the registry's LPs, the reserve's gateways, treasurer and hedge treasury,
  the FeeSplitter's treasury, and the ASPs. A holder counts as a test identity if any test seed this run knows derives
  it (`witness/*`, `arbitrator/*`, `lp/*`, `guardian/*`, `treasurer/*`, `hedge-treasury/*`, `treasury/*`, `asp/*`, and
  the custody rehearsal's `custody/<role>/signer/*`). So does a Safe whose threshold of owners are such keys. An
  endpoint is illustrative if it is one of `packages/ramp`'s receipt templates, or if its URL is on a reserved test
  domain (`https://api.banco-lp.example/`);
- minting is not paused, and the reserve's governor is not already gone while its guardian lives;
- every governor is the deployer or already `0x…dEaD`. Calldata for any other governor is printed only once every other
  check passes.

**The rehearsal opt-out.** `MOVVA_FINALIZE_ALLOW_TEST_KEYS=yes-this-is-a-rehearsal` (process environment only, never
`.env`) lets a rehearsal or a testnet demonstration finalize with the test identities in place. It is refused on chain
id 1 whatever it says. A run that uses it prints every such role with `!!!`. It records the run as a substitution
(`FINALIZED WITH TEST KEYS …`) and in `finalize.testKeys`. `VERIFICATION.md` shows a summary row, a banner and a
Substitutions section.

**Phase B: the renunciations, least reversible last.**
1. **`setGuardian(0x…dEaD)` on the reserve** (C2). This is reversible while the governor lives. `mintPaused` is read
   immediately before it and again after it lands.
2. **The Entrypoint's OWNER_ROLE** (and DEFAULT_ADMIN_ROLE if held), renounced by the deployer.
3. **Every governor**, the reserve's first. Its `transferGovernor` is sent only after its guardian (`0x…dEaD`) and
   `mintPaused` (false) are read once more.

**The guardian at finalization (SRM1-23).** The custody rehearsal's guardian Safe exists only until finalization:
`--finalize` replaces it with `0x…dEaD` (decision C2). **The pause race is closed (SRM1-8).** Before, `mintPaused` was
read once, and a guardian's `pauseMint` landing before `setGuardian` would have been made permanent by the governor's
renunciation. Now such a pause stops the run before anything irreversible. The governor is still the deployer and can
`resumeMint`, then rerun.

**Rehearsed on 15 October 2026.** These runs used anvil forks of Sepolia, ports 8966-8967. The deployer was the fresh,
impersonated `0xefEf…437F`, with the public seed and `MOVVA_RAIL_BREAKER=off`. A plain MOVVA-only rail was deployed on
8966 (fork block 11,916,583; 245 pass, 3 expected, 0 fail; 20 addresses). Each scenario then forked that fork on 8967
and ran `--finalize --resume`. State changes were made on 8966 between `evm_snapshot` and `evm_revert`.

| # | Scenario | Result |
|---|---|---|
| 1 | Test keys, no opt-out | **Refused before any send**, listing 17 findings: 3 witnesses, the arbitrator on both escrows, the LP (registry and gateway), treasurer, hedge treasury, FeeSplitter treasury, 3 ASPs, 4 endpoints on `api.banco-lp.example`. Afterwards the deployer still holds OWNER_ROLE and all 8 governors; the guardian is unchanged |
| 2 | Test keys, with the opt-out | **Finalized.** 69/69 privilege checks and 27/27 exact-set checks passed before the first send. 10 transactions (290,776 gas): setGuardian, OWNER_ROLE, 8 governors with the reserve's first. Verification: **283 pass, 3 expected (stale Pyth), 0 fail**, including 107 privilege checks (27 exact-set; "no queued hedge withdrawal"). The substitution and the banner are in the record |
| 3 | A queued 40,000 USDT hedge withdrawal (written into the reserve's storage, since the stale Pyth price makes `queueHedgeWithdrawal` revert on the fork) | **Refused before any send** (`#0: 40000000000 USDT units to <hedge treasury>, executable from …`). The deployer still holds OWNER_ROLE and every governor |
| 4a | An extra ASP_POSTMAN holder, granted by the deployer and found through `RoleGranted` | **Refused before any send** (the inventory's "postman alone" check and the exact-postman check) |
| 4b | An impostor at the quorum's address (`anvil_setCode`) that answers `ENTRYPOINT`, `THRESHOLD`, `ASP_COUNT`, `asps()` and `isAsp` exactly like the real one, but lets one ASP post alone | All 69 inventory checks and 27 exact-set checks still passed. **Refused** by the bytecode check alone ("1220 bytes on chain, 2189 in the build"), before any send |
| 5 | A guardian front-runs `setGuardian`: interval mining, and a watcher sends `pauseMint` from the old guardian with a higher tip as soon as `setGuardian` is in the pool | Both landed in block 11,916,647, pause first. **Stopped right after `setGuardian`**: OWNER_ROLE and all 8 governors still the deployer's, guardian `0x…dEaD`, minting paused. The governor's `resumeMint` then succeeded |

**The decision is the client's.** No contract change is needed to renounce: both paths exist. What cannot be had
without a change is renounced *upgrade and add-risk* powers with the *brakes* kept. That would need a new function
in `DelayedGovernance`: say, `renounceRiskIncreasing()`, after which `_authorizeChange(true)` always reverts while
risk-reducing calls (revoke, remove, delist, lower, pause, rotate a compromised key) stay with a governor. Plus, on the
Entrypoint, either a new owner model or a governed contract holding OWNER_ROLE. That is a contract change for the
client to approve, and this repo has not made it.
