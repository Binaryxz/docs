# Handover — Mova BRL rail, Phases 1–2 plus yield infrastructure

Prepared 2026-09-12, against MVP Scope **Rev. 2** (7 September 2026), which was the authoritative document when this
work began.

**Rev. 3 (14 September 2026) supersedes it**, and the client sent it on 17 September. It is checked section by section
in [rev3-conformance.md](rev3-conformance.md): most of it is built, and two things are not - sub-wallets with
independent seed phrases, and MOVVA minted only by the escrow, which conflicts with the reserve design the client chose
on 14 September and needs a decision before code.

**Update, 15 October 2026: savings removed.** Client decision D1 (14 October 2026) took savings out of M1: "Remove
savings (sMovva, its shielded pool, the savings relayer) ... from M1. The scope is: deposit PIX -> mint MOVVA -> hold as
shielded notes -> withdraw to PIX. ... yield is entirely Movva's, not a user-facing product." Deleted: `SavingsMovva`
(sMovva) and its pool, `ShieldedYieldRouter`, `@mova/zap-relayer`, the Movva distribution keeper (`movva-keeper`), the
router demos (`shielded-yield*.ts`), the wallet's savings and zap code, the app's Savings screen and the viewing key's
sMovva leg. `MovvaReserve` lost `distribute`, `previewDistribute`, `setSavings` and the 20% distribution fee; the surplus
above its target now stays in the reserve as backing and is Mova's, reached only through the hedge path. Kept as the
reserve's own yield: `YieldVault`, `LimitedYieldVault`, `KeeperGate`, the adapters, the HyperEVM vault and the vault,
HyperEVM and Pyth keepers. The dated passes below are left as written and marked where they describe savings.

Everything below is checkable from this repository. Where a number appears, the command that
produces it is named, so nothing in this document has to be taken on trust.

## What is delivered

| Rev. 2 scope | State |
|---|---|
| **Phase 1** — Privacy Pools fork, ERC-4337 smart accounts (passkey + MPC), relayer, audit viewing key | **Delivered.** Deployed and exercised on Sepolia. |
| **Phase 2** — ramp escrow, zkTLS proofs of bank payments, oracle sanity bands, LP registry and matching | **Delivered.** Tested against a mainnet fork; on Sepolia since the MOVVA-only rail of 15 October 2026, not finalized ([deployments.md](deployments.md)). |
| **Post-MVP** — yield (staking, ERC-4626 vaults) | **Infrastructure delivered early, as the reserve's.** Rev. 2 defers this; the vault and adapters are built, tested and documented and invest the Movva reserve's USDT. The user-facing shielded yield (router, share pool, sMovva) was built and then removed by client decision D1, 14 October 2026. |
| **Phase 3** — PIX/boleto on-ramp end to end with Phase A institutional LPs | **Software built, not started operationally.** The LP node, the Movva gateway and the wallet run the whole flow on real bytecode (fifth pass, below). Needs real LPs, bank accounts and a Reclaim credential — see "What we need from you". |
| **Phase 4** — shielded internal transfers | **Removed from scope** by the client on 12 October 2026 (Rev. 3 §5.3): users deposit and withdraw only. The contract and wallet flow were built and proven on a mainnet fork, then deleted; [security-review-phase4.md](security-review-phase4.md) is the record. |
| **Phase 4** — PIX off-ramp with LPs, dashboard, tier limits, accounting exports | **Off-ramp and accounting exports built** (LP node payouts, wallet sale, IRPF figures and CSV). Dashboard not built. Per-user daily caps are built in the LP node, off unless an LP configures them (see below). |
| **Production hardening** — monitoring, alerting, admin tooling, deployment packaging, runbooks | **Delivered.** See below. |
| Off-chain services replicated on Flux | **Specs delivered, not deployed.** Needs your Flux account and collateral. |

Phases 1 and 2 together are the spine of the product: a user can hold a shielded BRL balance,
prove it selectively to an auditor, and move value in and out through the ramp contracts.
What is missing for the MVP is the *operational* half — real liquidity providers, the
customer-facing dashboard and exports, and replication.

## How to verify it, in about ten minutes

```bash
npm ci
npx tsc --noEmit        # type check
npm test                # library + EVM harness
npm run slither         # static analysis over our contracts
$(bash scripts/foundry.sh path) test      # Solidity suite
```

Current results on a clean checkout of `6b559f9`:

| Check | Result |
|---|---|
| Solidity tests | **286 passed**, 0 failed (24 suites) |
| TypeScript tests | **499 passed** (40 files) |
| Type check | clean |
| slither (fails on medium or worse) | **exit 0** |

CI is set up to run the same checks on every push, so a green badge would mean they passed on a clean machine rather
than on ours. **On 18 October 2026 no job runs:** every job fails with zero steps, and GitHub's annotation says *"The
job was not started because recent account payments have failed or your spending limit needs to be increased"*.
That is the GitHub account's billing, not the code. Until it is fixed, the latest full runs are local (forge 948/948,
vitest 2,303/2,303).

`TESTING.md` walks the rest: a local mainnet fork exercising every flow including the parts
that need a bundler, the Sepolia run, and the hardware passkey check that cannot be automated.

## What is proven on-chain

**Sepolia**, deployed 8 September 2026, verified sources, addresses in
[deployments.md](deployments.md):

- deposit → shielded balance → withdrawal, with a real groth16 proof accepted by the deployed
  verifier;
- a passkey as a real Safe owner, P-256 verified on-chain;
- a relayed private withdrawal: the user signs nothing and the recipient address has never
  transacted.

**Mainnet fork**, with real third-party contracts rather than mocks:

- the BRL on-ramp and off-ramp end to end, with our rebuilt Merkle root checked against the
  pool contract's own;
- shielded yield: 10,000 USDS shielded, moved into the live Sky savings rate, left untouched
  for 180 days (3.60% annualised), and moved back out as more shielded USDS — the user sending
  no transaction after the first deposit (a record of the router path, which was removed with
  savings on 14 October 2026, D1; the vault and adapters it used remain, as the reserve's);
- the Lido staking adapter against real Lido, Curve and Chainlink, including a manipulated
  Curve pool being refused by an oracle-anchored minimum.

## Production hardening

Built so the rail can be operated by someone who did not write it.

- **A monitor** (`packages/ops`) that sweeps the contracts and alerts on what matters: oracle
  staleness, an ASP postman that has gone quiet, relayer and paymaster gas running out, and
  the yield vault's drawdown and liquidity. It holds no key and sends no transaction, so it
  is safe to replicate anywhere. Prometheus metrics on `/metrics`, the verdict on `/status`.
- **An admin tool** covering every privileged function on the ramp, the oracles and the vault
  - a test scans the contracts and fails if one is missing - including the
  schedule/execute queue for changes behind the governance delay. It is a **dry run by default**: it prints the call, its risk and the calldata,
  which is exactly what a multisig needs in order to approve a change. Nothing fires without
  `--execute`.
- **Three runbooks**: [mainnet deployment](runbook-mainnet-deploy.md) with a go/no-go
  checklist, [LP onboarding](runbook-lp-onboarding.md) for Phase A, and
  [incident response](runbook-incidents.md) keyed to each alert — what the user experiences,
  and what to do.
- **Deployment packaging**: one container image for the read-only services, a compose file,
  and Flux application specs — including a plain statement of
  [which services can be replicated on machines you do not control and which cannot](../packages/ops/flux/README.md).
  The arbitration desk and the ASP postman hold keys, so they stay in your own infrastructure.
- **[Audit readiness](audit-readiness.md)**: what to send an auditor, which commit to freeze,
  and the known issues stated up front rather than left to be discovered.

Two checks in that monitor are worth knowing about, because they encode judgements:

- **A check that could not run reports `unknown`, never `ok`.** A dashboard that goes green
  because its RPC call failed is worse than no dashboard.
- **Alerts fire on the edge, not every poll.** A monitor that pages every minute gets muted,
  and a muted monitor buys silence rather than safety.

## Security posture

Three internal reviews, one per phase, each listing what was found and fixed:
[phase 1](security-review-phase1.md), [phase 2](security-review-phase2.md),
[phase 3](security-review-phase3.md). [audit-scope.md](audit-scope.md) is written for an
external auditor: what to attack first, what we already believe is wrong, and where the bugs
have actually been.

**There has been no external audit.** Rev. 2 §10.2 requires one before mainnet launch, for the
fork deltas, the escrow contracts and the account modules. That remains the single largest gap
and is a third-party cost that is not included in this work.

**`packages/mpc` and `contracts/SchnorrVerifier.sol` are unaudited from-specification
cryptography.** Safe 2-of-2 is available as the conservative alternative and is what we
recommend until that code is reviewed.

## Changes since this handover, 13 September 2026

A review against the original handoff found the audit viewing key incomplete for its stated
purpose and several defects in the ramp. What changed:

**Audit viewing key (the first feature request).** The auditor's statement was wrong for any
user with activity outside the audited period, and a dishonest user could obtain a "complete"
statement with false balances. Now:
- the statement gives opening balance, movements and closing balance, all evaluated **as of**
  the period;
- spend state is **proven** with upstream's audited commitment circuit (no new circuit);
- lineages, dates, kinds and BRL amounts are checked against chain events instead of trusted;
- **expiry is cryptographic**: issuing a grant seals the chains it reads
  (`AuditGrantRegistry.registerAndRotate`);
- the note vault never receives keys or balances, and now runs as a replicable service
  (`packages/ops/flux/vault.json`);
- transfer tickets are signed.

Findings SR-4 to SR-8 in [security-review-phase1.md](security-review-phase1.md);
design in [audit-viewing-key.md](audit-viewing-key.md). The deployed Sepolia registry predates
`registerAndRotate`.

**Ramp and yield contracts.** See [security-review-phase2.md](security-review-phase2.md) and
[security-review-phase3.md](security-review-phase3.md).
- **zkTLS binding.** zkTLS proofs are bound to an allowlisted bank endpoint, with payment
  fields read from what the witness extracted. Before this, a session with any server settled
  an order.
- **Governance delay.** Risk-raising governance changes go through a schedule/execute delay
  (default 48h). Risk-reducing ones stay instant.
- **Arbitration.** An arbitrator must predate a dispute to rule for the counterparty.
- **Asset decimals.** Decimals are pinned per offer.
- **LP phases.** LP onboarding follows the phases in the handoff: A is institutional only,
  B adds sponsored affiliates ("vinculados"), C adds open retail. Credit limits apply to total
  exposure across both escrows.
- **Oracle handover.** The deploy script hands over the oracle's governor role.

**Off-chain services.**
- The arbitration desk reads parties from the escrow and refuses caller-chosen defaults.
- Secrets are redacted from every status endpoint and alert.
- The container image runs production entrypoints instead of demos.
- The admin tool's tier mapping is fixed, and the tool covers every privileged function
  including the governance queue.
- FROST nonces are single-use and hedged.
- [availability.md](availability.md) no longer claims the service-death invariant holds for
  funds.

**Second pass, the same day.** Each item the first pass left open as "needs a decision" was
built with a conservative default, recorded where it is made:

- **Wallet custody** ([wallet-custody.md](wallet-custody.md)). FROST keys come from a PedPoP DKG,
  so no dealer ever holds the group secret. The device share is sealed under the passkey PRF.
  If the server co-signer dies, the passkey alone can queue a Safe transaction through a Zodiac
  Delay module (1.1.1, canonical deployment) and execute it after 7 days; the owners can veto.
  Fork-tested against mainnet Safe contracts. PRF-less devices get a 2-of-3 split with a
  recovery code instead of losing funds with the server share.
- **Disputes** cannot freeze funds indefinitely. Anyone submits an arbitrator-signed ruling; it
  executes a day later, so a stolen arbitrator key can be revoked in time. After
  `DISPUTE_TIMEOUT` (30 days) anyone refunds a dispute to origin.
- **Boleto** works both ways: an LP issues a boleto for a locked on-ramp order, and an off-ramp
  sale can pay a user's boleto. FEBRABAN line validation, including the 2025 due-date factor
  rollover, and attestation bound to the exact boleto and amount.
- **Tokenised T-bills**: Superstate USTB, chosen for atomic on-chain subscription and redemption,
  behind a NAV-bounded adapter fork-tested against the real fund.
- **Delta-neutral on Hyperliquid** ([delta-neutral.md](delta-neutral.md)): the collateral is held
  by a contract on HyperEVM, not by a trading key; the keeper can only trigger bounded actions.
- **Keepers** as replicable services behind `KeeperGate` (one revocable key per replica, a daily
  turnover budget), with Flux specs.
- **Audits**: a reference USD/BRL price (Banco Central PTAX x Chainlink history) so BRL figures
  can be verified, and owner-side IRPF figures at acquisition cost with an accountant's CSV.
- **The BRL-only boundary** as code (`packages/wallet`): amounts typed as reais, PIX BR Codes,
  deposit quotes in reais, proven audit grants and the tax year behind one API.
- **Monitoring** of scheduled governance changes and posted rulings, one alert per item.
- **Slither** is back to no medium-or-worse findings, and CI now fails a contract over EIP-170.
  The HyperEVM vault was 29 KB and passed every test; its trading logic now lives in a linked
  library, leaving the vault at 20 KB.

### Third pass, 14 September 2026: USDT, the LP node, balances at today's price

Checked against the product flow (PIX/boleto in → USDT → yield in vaults → sell USDT to LPs →
BRL out). What that flow needed and did not depend on the open product questions:

- **USDT on both ramps**, proven against the real token, Chainlink's USDT/USD and 0xbow's live
  Entrypoint and USDT pool (`UsdtRampFork.t.sol`, 22 tests). The L1 band is
  `ChainlinkSignedFxOracle`: the quorum signs only BRL/USD and each asset's Chainlink USD feed is
  crossed with it. Tether's powers were exercised from its real owner address and each outcome is
  recorded (SR2-20 to SR2-29); the two that had no way out are addressed in the fourth pass below.
- **The matcher** never quotes a shielded leg below the pool's minimum deposit (a 10 USDT shielded
  order locks and can never settle, SR2-27) and drops offers from LPs Tether has frozen (SR2-24).
- **USDT yield** through Aave v3's USDT wrapper behind the existing `ERC4626Adapter`, fork-tested
  (`AaveUSDTFork.t.sol`, 15 tests) for accrual, the supply cap, borrowed-out liquidity, frozen and
  paused reserves, and USDT's fee, blacklist and pause. That work found and fixed three adapter
  bugs (SR3-8 to SR3-11). A 10,000 USDT note zapped into it with real proofs through 0xbow's live
  pool came back as 10,147.44 USDT after 180 days and reached a fresh wallet as 10,096.70 USDT.
  On Mova's own deployment (decided below) the share pool is registered by Mova's governance. *(Removed 14 October 2026 with savings, client decision D1.)*
- **The LP node** (`packages/lp-node`) replaces operating the ramp by hand: offers inside the band,
  signed payment instructions for takers, PIX and boleto matching, off-ramp payouts only after
  confirmations, and an idempotency key persisted before every bank call so a crash never pays
  twice. It holds the LP's key and moves the LP's BRL, so each LP runs its own instance, never
  Flux. Receiving uses the Banco Central API Pix; sending needs an adapter per bank. Not yet:
  zkTLS proving on the off-ramp, TED payouts, PIX reversals (MED), journal compaction.
- **The wallet's balance** is now what the holdings are worth at today's price beside what they
  cost, instead of the reais booked at each movement - which was wrong for USDT and hid yield.
  Vault shares were valued as the assets they redeem for *(removed with savings, D1: there is no
  user-facing yield)*. Cost is the same weighted average the IRPF sheet declares.

Verified on this machine (at the time): 999 TypeScript and 563 Solidity tests, 81 mainnet and HyperEVM fork tests
plus the rescue fork test against 0xbow's pools, the LP node live run, the shielded USDT round trip,
the EIP-170 gate and Slither with no medium-or-worse findings.

### Fourth pass, 14 September 2026: Tether's freeze, bounded

The client accepted Tether's blacklist as inherent to USDT, on condition that the damage is bounded
in code, and chose Mova's own Privacy Pools deployment over 0xbow's. What changed:

- **Nothing new starts in frozen USDT.** A shared check (`contracts/common/IssuerFreeze.sol`) asks the
  token's issuer - Tether or Circle - before anything new begins. The escrows refuse offers, top-ups,
  sales, orders and claims while Tether has listed them, and refuse to lock an order toward a listed LP,
  a listed direct recipient, or a listed Entrypoint or pool. The yield vault refuses deposits and
  reports no room while listed. All of it resumes by itself if Tether unlists before burning anything.
- **A paid user is never stranded by a failed shielded delivery.** `takeDeliveryDirect` lets the
  rescue address named at lock take the order in the open instead - after a proof or a ruling. Proven
  against real Tether, 0xbow's Entrypoint and its owner raising the pool minimum after lock.
- **Shielded orders below the pool minimum are refused at lock** (SR2-27, previously matcher-only).
- **Each escrow's holding of a freezable token is capped** (`assetCap`). The deploy script refuses to
  list USDT without one; the monitor warns at 80% and fails at the cap. A cap is the most one listing
  can take.
- **The optimizer now runs at 1,000, not 10,000,** to make room: FiatEscrow was 148 bytes under the
  size limit. Measured cost: under 100 gas (about 0.03%) per escrow call.

Verified on this machine: 22 fork tests of the ramps against real Tether, 0xbow's Entrypoint and its
owner, with 11 offline equivalents that CI runs; the vault's freeze on Aave's real USDT wrapper; the
probe against real USDT, USDC and WETH (whose fallback would burn all gas without the cap); 582
Solidity and 1,000 TypeScript tests, 85 fork tests in all, the LP node's live run, the shielded USDT
round trip with real proofs, the EIP-170 gate and Slither with no medium-or-worse findings.

**Still open — each needs a decision, an account or an input that is not code:**

| Item | What is needed |
|---|---|
| Superstate onboarding | Superstate must allowlist the vault, and its eligibility rules do not list Brazil today. USDY is the fallback candidate. Whether a freezable fund belongs in a privacy product is also the client's call. |
| HyperEVM strategy | It has never traded on real HyperCore; a staged launch with small caps is the next step. Connecting it to the shielded vault needs a bridge, and trusting that bridge is the client's decision. |
| A user interface | Platform and design. `packages/wallet` is the API it would call. |
| Real bank zkTLS templates | **Required for PIX and boleto** since 14 September 2026, when bank payments were decided to settle only on zkTLS proofs (SR2-34): a Reclaim application credential and per-bank templates that extract the payment fields (the boleto barcode hashed). Until they exist nothing settles by PIX or boleto. |
| Licensed PSP attestors | **Card captures only** since 14 September 2026 (SR2-34). The service is built (`packages/attestor`); what is needed is the card partner's PSPs - at least threshold + 2 - reading captures from the acquirer, each registered through the verifier's delay (`docs/runbook-psp-attestor.md`). The earlier route, PSPs attesting PIX over API Pix or Open Finance, was replaced by zkTLS-only bank rails; those readers remain as bank-fact sources. |
| The USD/BRL rate | **Decided (14 September 2026): Pyth's FX.USD/BRL**, posted on Ethereum by Mova's keeper; while the FX market is closed trading continues on the last close and minting and redeeming wait (SR2-35, [movva.md](movva.md) "The rate"). Needs a Hermes API credential, a funded keeper key, and the keeper running before launch. |
| Per-user daily caps | **Built in the LP node, 17 September 2026**, off unless configured (`packages/lp-node/src/caps.ts`, its README's "Per-payer caps"): tiers 0-4 with daily and monthly limits in Brasília days, keyed on the payer the LP's bank names (`payerRef`, the existing hash under `PAYER_REF_SECRET`), accounted in the node's journal and enforced before the asset or the BRL moves. What is still needed: the tier numbers, and a bank adapter that reports the payer - API Pix 2.10.0 carries no payer document, so an LP receiving only through it can attribute nothing. |
| Sepolia redeployment | A funded testnet key. One is generated on this machine (`.env`, gitignored) at `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214`; send it Sepolia ETH. |
| What Movva is | **Decided (14 September 2026): a BRL-pegged token**, backed by a USDT reserve whose dollar exposure the issuer (a traditional legal entity) hedges on B3, with an on-chain buffer as backstop; users hold only Movva. Design in [movva.md](movva.md). Open: fee numbers, token symbol, freeze capability and authorization (legal), hedge broker and policy. |
| Mova's fees | **Decided (14 September 2026): benchmarked to traditional finance** - 0.10% to mint and 0.10% to redeem (a fiat stablecoin issuer's acquisition and redemption fee), 20% of each yield distribution (about a renda fixa fund's management fee at the reserve's yield). `DeployMovva`'s defaults; raising any waits out the governance delay, under hard caps. Revisit with real volumes ([movva.md](movva.md), "Fees"). *The distribution fee was removed with savings (D1, 14 October 2026); 0.10% / 0.10% remain.* |
| Card on-ramp | **Built** on-chain, in the attestor and in the LP node (SR2-32): card-only offers of institutional LPs, captured charges only, reversals exactly once. An adapter exists for Stone's Pagar.me (sandbox run pending). What is needed is the partner: a contract assigning chargebacks to it, its Pagar.me account (or an adapter for another acquirer), 3-D Secure, and Mova's ASP policy for card-funded deposits. |
| USDT cap sizes | Accepted as inherent and bounded (fourth pass). What remains is the number: the most each escrow may hold in USDT, i.e. the most Mova will lose to one listing. |
| Mova's Privacy Pools deployment | **Decided: Mova's own** (its own ASP policy, fees and pool registration). Needs the ASP postman and relayer operators, and a plan for the smaller anonymity set at launch. |
| Flux, LPs, multisig, external audit | Unchanged from "What we need from you" below. |

### Fifth pass, 14 September 2026: the Movva flow, end to end

Checked against the flow as the client wrote it - PIX, boleto and card in; BRL to USDT; mint Movva; the wallet;
USDT earning in segregated vaults; selling to LP nodes; burning Movva; yield back to the Movva wallet; Mova earning
the fee on transactions with node providers and on yield. *(Yield back to the wallet - savings, zaps and distribution -
was removed by client decision D1, 14 October 2026; the bullets below that describe it are a record.)* Movva's contracts, hedge desk and monitor checks were
already built ([movva.md](movva.md), [security-review-movva.md](security-review-movva.md)); what the flow still
lacked is below.

- **The LP node is a Movva gateway** (`packages/lp-node`, "The Movva gateway"). It mints Movva from USDT only to
  what its Movva offer needs, prices offers and sales from what Movva actually costs to mint and pays to redeem,
  and redeems (burns) Movva it bought back - never below par by default. Every refusal the reserve would make is
  checked before simulating; a crash, lost send or reorg never mints twice for one need.
- **The wallet runs the user's side** (`packages/wallet`): a balance in reais - Movva at par, savings at sMovva's
  share price, yield as value less cost, and a **backing status** that is never `full` unless the reserve is
  readable, fresh and at or above 100%. Buying by PIX, boleto or card from a smart account or an EOA verifies the
  LP's instructions against the chain before anything is payable (a card checkout must open the offer's merchant
  commitment and sit on an allowlisted https host); saving and withdrawing savings are zaps with real proofs;
  selling opens from an unlinked account funded by a relayed exit. `examples/movva-wallet-live.ts` is the client's
  whole flow in one run - the LP mints Movva from USDT, the user buys by PIX, boleto and card, saves, earns yield,
  sells back, the LP burns what it bought - with supply, reserve USDT and Mova's fees checked against the reserve's
  events at every step. *(Savings, zaps and the saving and earning steps were removed with savings, D1, 14 October
  2026; the wallet is single-ledger, Movva only.)*
- **The audit viewing key covers Movva.** Nearly every Movva note is deposited by the ramp escrow or the yield
  router, not the user. The auditor now reads who each deposit was for from those contracts' own state, so an
  omitted purchase or zap is caught as for a direct deposit; purchase cost is checked against what the order
  required. Four existing viewing-key bugs were found and fixed on the way (SR-9 to SR-12 in
  [security-review-phase1.md](security-review-phase1.md)), one of which would have overstated a recovered balance.
  Design: [audit-viewing-key.md](audit-viewing-key.md), "Deposits a contract made". An auditor combines the Movva
  and sMovva statements into **one statement for the fiscal period**, each still verified on its own, and a
  second device can no longer seal new notes to rotations a grant already covers. *(The sMovva leg and the router
  attribution were removed with savings, D1; the escrow attribution stays.)*
- **Yield reaches savers without anyone remembering to send it.** A distribution keeper calls `distribute()` when a
  vest has ended and the amount is worth a vest (`packages/ops/flux/movva-keeper.json`); its key holds no role, so a
  leaked one costs its gas float. The monitor warns when a distribution has waited too long. *(Removed 14 October 2026 with savings, client decision D1.)*
- **The oracles' own governance is delayed** (SR2-30 in [security-review-phase2.md](security-review-phase2.md)). The
  reserve mints at the signed rate, and its governor could add a publisher and lower the threshold in one block.
  All four oracles now schedule such changes in public, refuse to price until their setup is closed, and removal
  no longer lowers a threshold. One quorum signature can no longer freeze a signed oracle for good (SR2-31).
- **Card on-ramp** (SR2-32). On-chain, only an institutional LP's card-only offer takes the card rail, re-checked at
  lock, and nobody is paid out by card; attestors sign only a captured charge for the order's amount plus the card fee
  the offer commits to. The LP
  node runs it through a `CardAcquirer` plugin (a `MockAcquirer` states the rules a real adapter must meet): a
  checkout for the exact amount once the lock is deep enough, release on capture, and every charge that bought
  nothing voided or refunded exactly once. A card order releases against the real `FiatEscrow` in
  `lp-node-live.ts`.
- **The LP node's operational gaps are closed**: stuck transactions are replaced at the same nonce with a fee cap;
  the journal compacts into a snapshot without ever leaving an unreadable file; the API Pix webhook triggers an
  immediate match but every payment fact is re-fetched from the bank's API, authenticated by HMAC or proxy mTLS;
  and disputed orders and sales file salted evidence commitments with the arbitration desk, never the facts.
- **Movva's escrow pair defaults to a 300 bps band, not 100** (SRM-14 in security-review-movva.md). At 100 bps,
  under partial backing no LP could buy a holder's Movva back without paying above what redeeming pays, so exits
  would have stalled exactly when holders want out.
- **Gas headroom on every sender** (SR3-12 in [security-review-phase3.md](security-review-phase3.md)). The keepers,
  the LP node and the wallet sent with the node's exact gas estimate; a transaction included a second later could run
  out of gas - proven at the Movva distribution's daily boundary, where one second costs 5 more gas. Each now adds
  bounded headroom, and a revert that still happens is reported with its reason.
- **CI runs the live examples** - the LP node, the LP node as a gateway, and the Movva wallet with real proofs - on
  a local anvil, with no RPC or secrets.

Verified on this machine, on the final tree: `npx tsc --noEmit` clean with every package's examples now included; `npm test`
**1,491 passed** (101 files); the Solidity suite **648 passed**, 0 failed (53 suites, fork suites excluded - there is no
mainnet RPC here); every contract under EIP-170 (`FiatEscrow` 23,333 bytes); Slither with no medium-or-worse finding;
and the three live examples CI now runs, against real bytecode on anvil - the LP node (38 checks, PIX, boleto, card,
off-ramp and a crash mid-payment), the LP node as a Movva gateway (30), and the Movva wallet's whole flow with real
proofs (77). Not run: the mainnet and HyperEVM fork suites, and the fork-only examples (type-checked only).

### Sixth pass, 14 September 2026: the client's decisions on fees, card fees and partners

The client chose the traditional method for the open commercial items: fees benchmarked to traditional finance, and
partners integrated through the standard, published APIs of traditional providers.

- **Fees** ([movva.md](movva.md), "Fees"). `DeployMovva` now deploys 0.10% to mint and 0.10% to redeem - a fiat
  stablecoin issuer's acquisition and redemption fee (Tether: 0.1% each) - and 20% of each yield distribution, which at
  the reserve's measured ~3.2% Aave yield is about 0.64% of savers' balances a year, the order of ANBIMA's 0.62%
  average renda fixa fund fee (September 2024). All stay under the hard caps and can only rise through the delay.
  *(The distribution fee was removed with savings, D1, 14 October 2026.)*
- **Card fees are a separate, disclosed charge at checkout** (SR2-32). Movva's ±3% band had room for a card fee of only
  about 1.7%. A card offer is now priced like PIX and the checkout adds the fee (`R$ 100,00 + card fee R$ 3,50 =
  R$ 103,50`), as Lei 13.455/2017 allows. The rate is committed on-chain inside the offer's merchant commitment, so the
  wallet and the attestors check it and no node can raise it after posting. The wallet run buys by card at 3.5% on the
  300 bps Movva pair, which the old pricing could not post.
- **The card fee is in the user's audit and tax figures.** The escrow records only the order, so a card purchase's note
  carries the fee beside its settlement, with the opening of the offer's commitment; the auditor verifies the rate and the
  rounding against the chain (`card_fee_mismatch`), and the IRPF cost is order plus fee (`taxa_cartao_brl` in the CSV).
- **A traditional bank adapter: Banco Inter** (`packages/lp-node/src/banks/`). Built from Inter's public API reference and
  OpenAPI documents (Banco do Brasil's portal was not readable), against a mock built from them: PIX payouts with Inter's
  idempotency header, boleto payment behind a look-up (Inter has no idempotency for it), boleto registration and
  cancellation, balance, and boleto credits from the statement, with API Pix for everything received. Two findings to
  act on before an LP uses it. **Inter's API Pix lists only Pix paid against a charge**, so static-code credits may never
  be seen: the node now serves the Banco Central's standard per-order charges (`onramp.pixCharge: "cob"`, one charge per
  order, matched by its txid), the Inter adapter routes them to Inter's `/cob/{txid}` (scopes `cob.read`/`cob.write`), and
  the wallet verifies the PSP's signed charge before showing its dynamic code - the signed key must be the one that opens
  the offer's commitment. Production wallets still need a registered QR-site certificate
  source and a revocation service. And **the adapter's own journal must be as durable as the node's**, because Inter cannot look a
  payment up by its idempotency id. Unverified until the sandbox: static-code visibility, list lag, and whether a repeated
  POST with the same idempotency id returns the original payment.
- **Licensed PSP attestors** (`packages/attestor`, SR2-33), the partner route for proving payments instead of depending on
  Reclaim zkTLS credentials. Each PSP runs one service holding one key in the attestor quorum. It reads the order from the
  chain, observes the payment in its own records - the standard API Pix, Open Finance Brasil account data under the LP's
  consent (implemented from the published Accounts 2.4.2 and Consents 3.3.1 specifications), a boleto ledger plugin, or an
  acquirer's read methods - and signs only what both show. Two independent services release a PIX and a card order on a
  2-of-2 against the real contracts, and one PSP seeing R$ 1,00 less keeps the order locked. Not verifiable without being a
  participant: Open Finance directory enrolment and consent authorisation, and a real PSP's read-only scopes. An Open
  Finance attestation carries the bank's transaction id, not the PIX end-to-end id, so an LP must use one id scheme per rail.
- **A card acquirer adapter: Stone's Pagar.me API v5** (`packages/lp-node/src/acquirers/`). Cielo (no idempotency, no
  sandbox, no lookup before payment), Rede (documentation unreadable) and Getnet (no documented refund of a payment-link
  charge) were evaluated first. The adapter keeps the node's rules - one checkout per order across crashes, one installment
  only, refunds of anything captured after the link expires, one refund per charge - and is tested against a mock and through
  the real node. Pagar.me's documentation site refuses automated readers, so field names come from its official SDK: **a
  sandbox run must confirm order creation with the partner's customer record before go-live**.

Verified on this machine, on the final tree of this pass: `npx tsc --noEmit` clean (examples included); `npm test` **1,733
passed** (115 files); the Solidity suite **648 passed**, 0 failed (fork suites excluded - no mainnet RPC here), every contract
under EIP-170; and four live runs against real bytecode on anvil - the LP node (45 checks: PIX by static code and by
charge, boleto, card with its disclosed fee, off-ramp, a crash mid-payment), the Movva gateway (30), the Movva wallet's whole
flow with real proofs (86), and the PSP attestors (47: PIX and card on an API Pix 2-of-2, a PSP seeing a different amount
refusing, and an Open Finance 2-of-2 releasing under the bank's transaction id). Not run: the provider sandboxes (Banco
Inter, Pagar.me, Open Finance), which need the client's credentials, and the fork suites.

### Seventh pass, 14 September 2026: the architecture diagram, checked and decided

The flow was checked against the client's architecture diagram: PIX, boleto and card in; BRL to USDT; mint Movva; the
wallet; yield; sell to node providers; burn Movva; BRL out by PIX or boleto; Pyth/Chainlink USD/BRL sanity bands; attestors
proving payments with zkTLS; and the invariant that no service failure costs a user funds. Where the code differed the
client decided:

- **Movva stays R$ 1,00.** The diagram's "mint Movva 1:1 with USDT" and "burn back to USDT (1:1)" were not adopted; the
  reasons, and the two other deliberate differences (yield to savers - since removed, D1 - and fees at the reserve), are in
  [movva.md](movva.md), "Where this differs from the architecture diagram".
- **PIX, boleto and TED settle only on a zkTLS proof of the bank session** (SR2-34). `IAttestorVerifier.provesBankSession()`:
  the escrows refuse to open a bank-rail offer or any sale on a verifier that does not prove the session, so a colluding
  attestor quorum can no longer release a bank payment that never happened. The quorum and `packages/attestor` serve card
  captures only; the attestor's PIX and boleto signing is removed and its API Pix and Open Finance readers stay as
  bank-fact sources. The LP node proves its own bank session on both ramps (local witness keys in development). **This
  reverses the sixth pass's route of licensed PSPs attesting PIX**, and makes a Reclaim credential and per-bank templates
  a launch precondition.
- **The USD/BRL rate comes from Pyth** (SR2-35). `PythFxOracle` reads FX.USD/BRL, which Mova's new Pyth keeper
  (`packages/yield`, with a compose service, a Flux spec, admin commands and monitor checks) posts on Ethereum. Both
  deploy scripts use it by default; `SignedPriceOracle` remains the alternative.
- **While the FX market is closed, trading continues on the last close and minting waits** (SRM-15). Pyth publishes
  FX.USD/BRL only on weekdays, 08:00-17:00 New York - about 73% of the week closed. The rate the reserve mints, redeems,
  hedges and distributes at (no distribution since D1) refuses when stale; bands (`ScaledFxBandOracle`, `MovvaReserve.brlCentsPerUnit`, new
  `bandBrlPerUsdtE18`) take the last close outside `FxMarketHours`' core session. The wallet states backing at the close
  and says so; the monitor tells a closed market from a dead keeper inside the core session.
- **Users can receive BRL by having a bill paid** ("Receive BRL via PIX or boleto"). The wallet sells Movva to pay a
  boleto for exactly its amount, refusing an overdue bill, one with no due date and a mistyped line before any exit, and
  prices the sale so a bill's exact amount opens.

Verified on this machine, on the final tree of this pass:
- **`npx tsc --noEmit`:** clean.
- **`npm test`:** all 1,839 tests pass (118 files). One flaky wallet assertion is fixed: a random order id could contain 15
  decimal digits in a row. Its four files were re-run three times.
- **Solidity suite:** 671 passed, 0 failed (56 suites). With the fork suites, which skip without an RPC, it is 762.
- **EIP-170:** every contract fits. `FiatEscrow` is 23,488 bytes and `PythFxOracle` 6,130.
- **Slither:** no medium-or-worse finding on any contract this pass changed. It ran per file with solc 0.8.28, because
  Slither 0.11.6 cannot read this Foundry version's build output, so the repository-wide script was not run here.
- **Four live runs against real bytecode on anvil:**
  - the LP node, 54 checks: PIX, boleto and card in; PIX and a bill paid out; every bank payment proven by zkTLS; a
    quorum-verified PIX offer refused;
  - the Movva gateway, 41 checks, including a weekend on which it holds minting and redeeming while a purchase still
    settles;
  - the Movva wallet's whole flow with real proofs, 97 checks, including a bill paid by selling Movva and a weekend with
    backing at Friday's close and minting refused;
  - the PSP attestors on card captures, 35 checks.

Not run: the fork suites and fork-only examples (there is no mainnet RPC here), a real Reclaim session, a real Hermes
update posted to Pyth, and the provider sandboxes.

Open from this pass:
- **Pyth update gas is unmeasured.** The keeper's float guidance assumes 200,000 gas.
- **A monitoring gap of about an hour or two a day.** In that window the FX market is open but outside `FxMarketHours`'
  core session, and a keeper that dies then is not reported until the core session starts.

### Eighth pass, 15 September 2026: the wallet, the services and the incentives, completed

The seventh pass checked the flow against the architecture diagram. This pass builds what was still missing from its
wallet, services and incentives, and runs each piece against real bytecode.

**Accounts and custody**
- **Kernel v3.1 beside Safe.** `PasskeyCoSignerValidator` requires the passkey AND the co-signer inside one validator,
  because Kernel lets every installed validator authorise alone. There is also `FrostValidator`, and `KernelAvatarAdapter`,
  which drives the same Zodiac Delay recovery. They are a separate Foundry project whose vendored fixtures rebuild byte for
  byte. Safe 2-of-2 stays the default ([wallet-custody.md](wallet-custody.md) §10).
- **The Movva flow from a smart account.** `movva-wallet-live.ts` with `MOVVA_ACCOUNT=safe|kernel`:
  - every lock, cancel and audit grant is a sponsored UserOperation through EntryPoint v0.7, the Alto bundler and
    SponsorPaymaster;
  - LP node requests verify through ERC-1271, and through ERC-6492 for a Kernel account not yet deployed;
  - each sale runs from a fresh smart account.
- **The server co-signer, `packages/cosigner`.** It computes each digest itself and signs only after verifying a
  user-verified passkey signature over it, against the passkey key read from the chain.
  - Its policy refuses authority changes, allowlists targets and approvals, and keeps validity windows short.
  - It serves the recovery veto and two-party FROST.
  - Custody: a KMS in production; an fsynced audit record before every signature.
  - See §11.
- **FROST keys are generated with the device, not handed to it.** `packages/mpc/src/dkg-transport.ts` gives the PedPoP
  key generation the channel it always assumed: every message signed by its sender's long-term key over a transcript
  binding the session, both parties' keys and both round-1 payloads, and round-2 shares sealed to the recipient's
  one-run X25519 key (HKDF-SHA256, XChaCha20-Poly1305). Equivocation, a replay, a repeated party, a round out of order
  and a bad signature each abort naming the participant at fault. The co-signer serves it on `/v1/frost/dkg/*`, the
  device runs its half from `RemoteCoSigner.runDkg` in a browser and seals the share under the passkey's PRF, and one
  completed run per account is allowed - a run that stops halfway leaves a share that can never sign. `cosigner-live.ts`
  runs a real key generation over HTTP whose key becomes a Kernel FROST account that signs through the bundler.
  Unaudited, and ranked with `dkg.ts` in [audit-scope.md](audit-scope.md).
- **Sponsorship without a hot paymaster owner.** `SponsorGate` owns SponsorPaymaster. Its operators may only sponsor,
  within a daily count budget, and only while the paymaster bounds each account's gas. The co-signer sponsors each account
  at enrolment from its own operator key, never from the co-signer key (§11.1).
- **Recovery alerts while the app is closed.** The co-signer watches every enrolled account's Delay for
  `TransactionAdded`. It sends Web Push alerts (VAPID, aes128gcm, checked against RFC 8291's test vector) until the queued
  transaction is vetoed, executed or expires. Unsubscribing is refused while a recovery is queued, so a thief holding the
  passkey cannot silence the alerts (§11.2).
- **ERC-7562, checked for the first time.** The check ran on a rule-enforcing bundler: Rundler v0.11.0 in safe mode on
  geth `--dev`, through `packages/smart-account/examples/erc7562-live.ts`.
  - SponsorPaymaster read `block.timestamp` during validation whenever budgets were on, which public bundlers refuse. It
    is fixed: the budget window is now expressed through `validAfter`, and `postOp` settles it.
  - The paymaster must be staked: at least 1 ETH with a one-day unstake delay. `Deploy.s.sol` now defaults to that, and
    the monitor's new `paymaster_stake` check fails without it.
  - Safe accounts were accepted in every scenario. Kernel's first operation through Kernel's meta factory is refused
    whatever the stake (Rundler's CREATE2 rule), so a Kernel account must be deployed by a plain transaction before its
    first operation. The co-signer's sponsorship now sends that transaction at enrolment, from the deployment the
    enrolment itself verified and never from anything a request supplied; row B0 of the same run shows Rundler accepting
    the first operation that follows.

**The wallet**
- **Sales that stop half-way resume.** `pendingSales` and `resumeSale` work from a journal written before every step that
  cannot be undone. They check the chain first, so nothing is exited or opened twice.
- **Movva left in the open goes back into the pool.** `reshieldSale` covers a cancelled or refunded sale, and
  `reshieldDelivery` a delivery taken in the open. The note shows as pending until the ASP approves it. The viewing key ties
  a re-shielded sale refund back to the user from chain facts (`reshielded_sale_refund`), so the auditor no longer flags
  it.
- **Bills.** A bill due today with under an hour left before midnight in Brasília is refused before anything moves
  (`boleto_due_today_too_late`).
- **Several notes.** A sale across several notes is opt-in (`acrossNotes`), because those exits become visibly one
  person's.
- **Browser-ready libraries.**
  - Fetch is bound, `Buffer` is gone, and circuit artifacts load by URL.
  - `@mova/wallet`, `@mova/ramp` and `@mova/viewing-key` have browser entries whose import graph reaches no Node built-in.
  - A recovery bug is fixed: a new wallet's first deposit could fall outside a later restore's scan.
- **Relayers.**
  - `ProtocolRelayer` is a client for the Privacy Pools relayer. It quotes an exit's fee before anything is proven.
  - `@mova/zap-relayer` is the production service for savings zaps, which that relayer cannot submit. It builds the
    calldata itself, simulates before sending, and keeps daily gas budgets and a journal, with KMS custody. *(Removed 14 October 2026 with savings, client decision D1.)*
  - `RoutingRelayer` sends exits to the first and zaps to the second. *(Zaps removed with savings, D1.)*

**The app, `packages/app`.** A PWA in Portuguese, built on `MovvaWallet`.
- **Account.** The user is a Safe 2-of-2 by default, Kernel optional. Onboarding takes both the seed (PRF) and the Safe
  owner key from one passkey, enrols the account with the co-signer, waits for its sponsorship, and installs the recovery
  Delay in the first operation.
- **Screens.**
  - buying by PIX, boleto or card, and selling to a PIX key or to pay a bill;
  - savings, audit grants and the tax year (the Savings screen was removed with savings, D1, 14 October 2026);
  - the recovery queue with its veto, and the alerts switch with the service worker;
  - pending sales, re-shielding, and the several-notes opt-in;
  - the delivery escape hatch (`takeDeliveryDirect`), offered when the chain shows a shielded delivery has become
    impossible.
- **End-to-end tests.** Playwright drives headless Chromium with a virtual passkey authenticator.

**Services and incentives**
- **Node-provider rewards (SR2-36).** `NodeRewards`, `FeeSplitter` and `LPRegistry`'s rewards hook pay LPs a share of
  Mova's fees in proportion to settled volume. The share is 0 at deployment, and the LP node claims.
- **CORS.** The LP node's counterparty API (`API_ALLOWED_ORIGINS`) and the matcher (`ALLOWED_ORIGINS`) take explicit origin
  lists, empty by default.
- **Sepolia.** The whole Movva rail is one command, `scripts/deploy-movva-rail.ts`. It was rehearsed in full on a Sepolia
  fork: 93 transactions, 149 checks pass ([deployments.md](deployments.md)). It is waiting for a funded deployer. The
  SponsorPaymaster already on Sepolia predates this pass's fix and must be redeployed.
- **Packaging and CI.**
  - The co-signer and the zap relayer run as compose services in their own profiles, never on Flux, with monitor checks.
    *(The zap relayer was removed with savings, D1.)*
  - CI gains a Chromium job for the app and an ERC-7562 job. The live examples now include the Kernel wallet run and the
    co-signer.
  - `scripts/slither-smart-account.sh` analyses the Kernel contracts.

Verified on this machine, on the final tree of this pass:
- **`npx tsc --noEmit`:** clean.
- **`npm test`:** all 2,340 tests pass (161 files).
- **Solidity suite:** 729 passed outside the fork suites, 820 with them (76 suites, 0 failed; the fork suites pass by skipping
  without an RPC). The smart-account project passes 53, and its vendored fixtures still rebuild byte for byte.
- **EIP-170:** every contract fits. `FiatEscrow` is 23,488 bytes, `SponsorGate` 7,537 and `SponsorPaymaster` 5,456.
- **Slither:** no medium-or-worse finding on `SponsorGate`, `SponsorPaymaster` or the four smart-account contracts. It ran
  per file with solc 0.8.28 and through `scripts/slither-smart-account.sh`; the repository-wide script cannot read this
  Foundry version's build output here.
- **Live runs against real bytecode, each on its own anvil:**

  | Run | Checks |
  |---|---|
  | The LP node | 54 OK |
  | The LP node as a Movva gateway | 54 OK |
  | The PSP attestors on card captures | 35 OK |
  | Safe and Kernel accounts through the bundler | 65 OK |
  | The co-signer service | 98 OK |
  | ERC-7562 on Rundler in safe mode | 52 OK, 2 known (Kernel's meta factory) |
  | The Movva wallet as an EOA / Kernel account / Safe | 126 / 163 / 163 OK |

  The audit demo and both MPC demos ran as well, and no run failed a check on the final tree. One Safe run earlier in the
  pass failed step 14 with 6 deposits instead of 7. The example had ended the audit period at viem's cached block number,
  which the in-process zap relayer can leave one block before the zap it has just returned. The example now ends the period
  at a fresh head, never before the zap's block, and prints each note's time, block and whether it was served and counted
  if a statement check fails. After the fix, three Safe runs and a run with the cache deliberately left stale all pass.
  The libraries were not at fault: the auditor correctly left out a note mined after the period it was given.
- **The app:** it builds. All 21 Playwright tests pass in Chromium (5.2 to 7.1 minutes), and the smoke run passes its 19 checks.
- **The services image** builds with podman, and the co-signer, zap relayer, LP node and monitor entrypoints start in it.
  *(The zap relayer entrypoint was removed with savings, D1.)*

Not run:
- the fork suites (there is no mainnet RPC here);
- a hosted bundler, or a browser vendor's push service;
- a real Reclaim session, a real Hermes update posted to Pyth, or the provider sandboxes;
- any broadcast to Sepolia.

Open from this pass:
- **Hosted bundlers** (Pimlico, Alchemy, Etherspot, Candide) and a real push service have not been tried.
- **Off-chain linkage.** The co-signer and the sponsor both see a user's account and each sale account enrolled from the
  same client, close together in time. On-chain, nothing links them, and each sponsorship names only the account.
- **Device-local sale state.** Sale-account keys and the sale journal live on the device that sold, so a lost device
  loses whatever sits at a sale account.
- **Undetected delivery failures.** The app offers the escape hatch only when a chain read shows the shielded delivery is
  impossible. A release that reverts for any other reason is not detected.
- **One zap relayer per key.** It has no high availability, fee sweeping is manual, and only Movva-to-sMovva zaps have
  run live. *(Moot since 14 October 2026: the zap relayer was removed with savings, D1.)*
- **The app's period end comes from the device clock.** A device whose clock runs behind the chain can end a statement
  just before a movement mined seconds earlier. That movement then appears in the next period's grant, and the auditor
  warns about it.
- **Dynamic PIX charges** (API Pix `cob`) cannot be verified in a browser, so LP nodes serving app users must use static BR
  Codes.

### Ninth pass, 5 October 2026: what the client's answers settled, built

The client answered the open questions on 24 September ([client-questions.md](client-questions.md)) and reviewed the
Sepolia deployment against M1 ([m1-status.md](m1-status.md)). This pass builds what those answers settled and leaves
the undecided alone: who mints MOVVA, the ASP architecture and who governs the fee parameters.

- **Cards and the attestor keys are deleted.** The client confirmed cards stay out of the MVP, so
  `AttestorQuorumVerifier`, `packages/attestor`, the card branch of `FiatEscrow` and every card path in the LP node,
  wallet, viewing key and app are gone; bank rails and `ReclaimZkTlsVerifier` are unchanged. `FiatEscrow` shrank from
  23,488 to 23,076 bytes, and no privileged function was added. Rail masks are no longer checked for the card bit on
  `openSale`, since nothing can attest it. What was removed, and how to restore it from history:
  [card-rail-removal.md](card-rail-removal.md).
- **Sub-wallets with independent seed phrases** (Rev. 3 §6.2, §6.3, VK-7, T-10). Each has its own BIP-39 seed from
  fresh entropy, its own shielded keys and account, and uses the same Movva and sMovva pools (Movva only since D1). Seeds share nothing with
  the primary or each other. The phrase is shown once with a backup check, a lost seed is a lost sub-wallet, and one
  audit package can combine selected sub-wallets, reporting completeness across them as unverifiable by design. A live
  run funds two sub-wallets through the real on-ramp, restores one from its phrase alone, and shows that a leaked
  phrase opens none of the other 14 notes. Moves between sub-wallets stay V2, as the client said.
- **A self-clearing divergence breaker.** `DivergenceBreaker` is a separate contract with no owner, no setter and no
  state: while the reserve's rate and the sources that may trip it disagree beyond a band, mint, redeem, distribute and
  hedge withdrawals revert (`distribute` no longer exists since D1), and they resume by themselves when the sources agree. Band, sources and whether redemption
  halts are deploy-time choices. This amends the reserve's old rule that nobody can pause redemptions, because the
  rule guarded against a key freezing exits and the breaker is not a key. **A thin-pool TWAP that can trip a halt is a
  denial-of-service lever** (SRM-16); a median-of-three that stops the TWAP from halting alone was not built, because
  it would change how the audited core prices.
- **A timelock above a daily limit, no multisig.** A reserve hedge withdrawal above its daily limit is announced and
  executable by anyone after a day, with no way to cancel; `LimitedYieldVault` adds a per-owner daily limit and a
  delayed redeem. Open: a gateway redeem above a daily amount, per-address against global limits, and whether a
  mistaken request may be cancelled by its owner.
- **The abandoned Sepolia stack is monitored.** `orphan_watch` alerts if the lost owner key ever acts, and a repo test
  fails if any file names those addresses ([deployments/abandoned-sepolia-2026-09-08.json]).

Open from this pass:
- **Sub-wallets in the app use their own account key, funded by the dev stack's gas endpoint.** The co-signer's
  sponsorship is tied to passkey enrolment, so a key-owned account has no paymaster path on a real deployment; that
  needs a decision.
- **The device keeps each sub-wallet's derived root sealed under the primary's unlock**, so someone holding the device
  and the primary's unlock could open every sub-wallet without a phrase. A leaked phrase still opens only its own.
  Rev. 3 KI-5 suggests larger balances live where the seed is not kept on an everyday device; a per-sub-wallet choice
  between convenience and typing the phrase each time is the client's call.
- **The Sepolia deploy script has no default price source for the breaker**, because no Sepolia BRL/USD feed or BRL
  pool address could be verified; one source address must be supplied.
- **The rail is still not on Sepolia.** The deployer holds 0.0000352 ETH, so the Movva token has no code there; the
  client reviewed the 8 September stack, which predates it.

## Security incident, 11 September 2026

The development server was compromised through an unrelated project hosted on it (a file-upload
bug in a gift-card application, exploited to write a root cron job). The attacker had root for
roughly six hours and read `.env` files across the machine.

**What this means for this project:** the Sepolia deployer and relayer keys were exposed. They
have been rotated. On-chain, `OWNER_ROLE` (which also authorises proxy upgrades), `ASP_POSTMAN`
and `SponsorPaymaster` ownership now sit on newly generated addresses, and the exposed key holds
no role and no funds. Details are in [deployments.md](deployments.md).

**No mainnet funds were involved** — this project has never been deployed to mainnet, and the
Sepolia balances were testnet ETH, recovered in full. The RPC and Etherscan API keys were also
read and should be rotated with those providers.

## What we need from you to continue

Rev. 2 Phase 3 cannot start without these, and none of them is code:

1. **Liquidity providers** — real people or companies with real bank accounts and PIX keys,
   for the Phase A institutional set.
2. **A Reclaim application credential and a provider template per bank.** Required: since 14 September 2026
   PIX and boleto settle only on a zkTLS proof of the bank session (SR2-34). A proof attests to a session
   between a real person and their real bank, so it cannot be manufactured for them. The card rail and the
   PSP attestor quorum were deleted on 24 September 2026 ([card-rail-removal.md](card-rail-removal.md)), so no
   licensed PSP is needed.
3. **A Pyth Hermes credential and a funded keeper key.** The USD/BRL rate is Pyth's FX.USD/BRL, which is
   absent from Ethereum until someone posts it; Mova's keeper does (SR2-35). Correction, verified 19 October
   2026: Chainlink's BRL/USD IS live and contract-readable on mainnet, at `0x3126E7F38D5f60f4E2B6ec3511C7bdbD79317Df1`
   (8 decimals, 24 h heartbeat, 0.5% deviation). The "gated to EOA readers and stale since August 2023" that stood
   here is the retired proxy `0x0eBDc65E7e9132Cb41ac5cbD0101B799D7aDb475` (last update 25 August 2023, `No access`
   to contracts). `ChainlinkFxOracle` (keyless; `MOVVA_FX_SOURCE=chainlink`) is a built alternative leg that needs
   no keeper and no credential; Sepolia has no such feed. Named price publishers are needed only for a deployment
   that chooses the signed alternative (`FX_SOURCE=signed`).
4. **Funding and keys for the services this pass added.**
   - About 1.3 Sepolia ETH for the Movva rail and the SponsorPaymaster redeploy.
   - A 1 ETH paymaster stake wherever the paymaster runs.
   - KMS keys for the co-signer and its sponsor operator.
   - A VAPID key and contact address for recovery alerts.
   - An account with a hosted bundler, so the smart-account flow can be run there.
5. **Admin roles on a multisig.** The escrow governor, the ASP postman and the yield vault's
   governor/guardian/keeper should be yours, not a developer's key.
6. **Decisions recorded in the phase 3 review**: fee levels, and whether tokenised T-bills are wanted (they need the issuer to allowlist the
   vault).

## Honest limitations

- Nothing has run on mainnet, under adversarial conditions, or at load.
- There are no transfers between users or between sub-wallets: the client removed shielded
  transfers (Phase 4, Rev. 3 §5.3) from scope on 12 October 2026, and `ShieldedTransferRouter`
  was deleted. A user deposits and withdraws.
- There is no user-facing yield and no savings product: the client removed savings (sMovva, its shielded pool and the
  savings relayer) on 14 October 2026 (D1). The reserve's yield is Mova's, kept in the reserve as surplus backing and
  reached only through the hedge path.
- Per-user daily caps (Rev. 2 §10.1, Tier 0-4) are enforced in the LP node, not on-chain: a cap binds the payer the
  LP's bank names, because on-chain a user is deliberately unlinkable and an address-keyed cap would cap nothing. They
  are off unless an LP configures them, they do not compose across LPs (two LPs each holding R$ 2.000 a day means
  R$ 4.000 across both), and they need a bank adapter that reports the payer, which the standard API Pix does not.
  `releaseWithProof` being permissionless, a refusal is the LP declining to prove, release and keep the BRL, not a
  promise that no order can settle; such a release is counted, so that payer's next payment is refused too.
- Owner-side accounting exports exist (IRPF figures and CSV); invoices and a dashboard do not.
- The delta-neutral vault is built and simulator-tested but has never traded on HyperCore.
- Services have Flux specs but are not deployed on Flux.
- **Smart accounts beyond local bundlers.** Safe and Kernel accounts run end to end on anvil through the Alto bundler,
  in the wallet's live run and in the app in Chromium. ERC-7562's rules have been checked only against a local Rundler on
  geth. No hosted bundler and no public network has carried these operations.
- **Recovery alerts** have been delivered only to a local push endpoint, never through a browser vendor's push service.
- The gateway and the wallet run against real bytecode on anvil with a mock bank; no real bank has been connected.
  The card rail was removed on 24 September 2026, so there is no card checkout, acquirer or attestor to connect.
- PIX and boleto settle only on zkTLS proofs, and every run here proves with local witness keys over a mock bank:
  no real Reclaim session has produced a proof the verifier accepted.
- FX.USD/BRL has never been posted on a mainnet fork from real Hermes updates. On Sepolia, real Hermes updates of FX.USD/BRL were posted by the
  Task 1 script on 14 and 15 October 2026 ([deployments.md](deployments.md)); no keeper service runs there.
- While the FX market is closed - about 73% of the week - gateways cannot mint or redeem. An LP that runs out of
  Movva stops quoting until the market reopens.
