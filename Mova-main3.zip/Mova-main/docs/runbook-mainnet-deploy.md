# Runbook — mainnet deployment

For the person doing the deployment, start to finish. Every command here has been run against
a fork, except posting the Pyth leg's price, which needs a Hermes credential (see "Rehearse on a fork");
the only thing that changes on the day is the RPC URL and who signs. The whole Movva rail - Privacy Pools,
Movva with node-provider rewards, the Movva pools, the ramp, the `rewards:registry` binding and a read-only
verification - is also one command on Sepolia, rehearsed on a Sepolia fork: `scripts/deploy-movva-rail.ts`
(`docs/deployments.md`, "Sepolia rehearsal of the Movva rail").

**Nothing in this runbook may be run from the development server.** It was compromised on
11 September 2026 and has not been rebuilt. A mainnet key must never touch it. Use a clean
machine that has never held this repository's `.env`, or sign from the multisig directly.

## Before the day

| Gate | How to confirm it |
|---|---|
| External audit complete, findings resolved | Auditor's final report, and a commit that closes each finding |
| Scope frozen | A tag on the audited commit; deploy that tag, not `HEAD` |
| Multisig ready | It exists on mainnet, the signers can reach it, and a test transaction has been executed from it |
| Pyth keeper ready | The Pyth keeper (`packages/yield`) runs on a machine you control, with Hermes access (Hermes's hosted gateway needs a credential, or run your own Hermes) and a key funded for gas and Pyth's update fee, with someone watching that balance; it has posted FX.USD/BRL on the rehearsal fork. Its key holds no role. **Nothing prices until it has posted on mainnet** - see "Prices" below. With `FX_SOURCE=signed` instead: the publishers' addresses, each having signed a test rate with `PricePublisher.signFx` (`packages/ramp/src/price-publisher.ts`) |
| USDT risks accepted | The client has read SR2-20 to SR2-29 in `security-review-phase2.md`, in particular SR2-25: if Tether blacklists an escrow, every USDT position on it is frozen, with no path out |
| Privacy Pools Entrypoint chosen | Either 0xbow's mainnet Entrypoint (`0x6818809EefCe719E480a7526D76bD3e561526b46`: USDT pool `0xe859C0bD25f260BaEE534Fb52e307D3b64D24572`, ETH pool `0xF241d57C6DebAe225c0F2e6eA1529373C9A9C9fB`) or our own. With 0xbow's, their owner role sets each pool's minimum deposit and vetting fee (SR2-27) |
| zkTLS credentialed, bank endpoints agreed | A Reclaim application credential, and for each Phase A LP's bank: the provider template, its `providerHash`, the URL prefix and the rails it proves (`ZKTLS_ENDPOINT_RAILS`). Reviewed as described under "zkTLS endpoints" below. **Without them nothing settles by PIX or boleto** (SR2-34) |
| Governance delay agreed | Default 48 hours. Must exceed the time users need to exit, including the yield vault's slowest withdrawal queue |
| Governance end-state decided | The client has read "What --finalize renounced" and "What remains, and why" in `deployments/sepolia-movva-rail.finalized.rehearsal/VERIFICATION.md`, and chosen: governors on the multisig (this runbook as written), or renounced (section 2c). Renouncing cannot be undone, and it removes every instant brake in "If something is wrong after deployment" |
| Deploying a clean tag | `git status` shows nothing outside `deployments/`. `deploy-movva-rail.ts --broadcast-sepolia` refuses otherwise, and the record names the commit and fails on any uncommitted build input |
| Phase A LPs onboarded on testnet | At least two, each having completed a full on-ramp and off-ramp by PIX, settled on a zkTLS proof of its own bank session |
| zkTLS witnesses | `ZKTLS_WITNESSES`: the current Reclaim witness set, at least threshold + 2. Cards and the attestor quorum were removed on 24 September 2026 (`docs/card-rail-removal.md`), so there are no other attestor keys |
| Monitoring ready | The monitor runs against Sepolia, its alerts reach a channel someone reads, and it alerts on every `ChangeScheduled` event |
| Node-provider rewards decided | `MOVVA_LP_REWARD_SHARE_BPS` (0 unless Mova has chosen a share) and the `MOVVA_LP_REWARD_*` limits in `DeployMovva.s.sol`'s header; who will send `admin rewards:registry` from the multisig right after DeployRamp (section 3b, step 4). Without that binding NodeRewards counts no settlement at all |
| Whole rail rehearsed on Sepolia | `scripts/deploy-movva-rail.ts` has passed on a Sepolia fork from the machine that will deploy - protocol, Movva, pools, ramp with `NODE_REWARDS`, the `rewards:registry` binding and the read-only verification with zero failures - and its gas figure is recorded (`docs/deployments.md`, "Sepolia rehearsal of the Movva rail") |
| Gas funded | The whole rail measured 55.5M gas over 93 transactions on the Sepolia rehearsal (protocol 6.0M, Movva with rewards 12.9M, two pools 3.8M, ramp with the Movva pair 32.2M, binding 43k): multiply by the day's gas price and fund twice that for the deploy, plus the relayer float, the paymaster deposit, and the Pyth keeper's gas and update fees. Without our own Privacy Pools stack (0xbow's Entrypoint), subtract the protocol and pool steps |

If any row is unconfirmed, stop. Every one of them is cheaper to fix before deployment than
after.

## How governance works after deployment

Read this before the day, because it changes what "fix it after deploying" means.

Every contract that holds value or decides what releases it - both escrows, the LP registry,
both verifiers, the price oracles, the Movva reserve and the yield vault - delays **risk-increasing** changes by
`GOVERNANCE_DELAY`. Such a change is **scheduled** on-chain with its exact calldata, becomes
executable after the delay, and expires 14 days after that. **Risk-reducing** changes are
instant, so incident response is as fast as the multisig can sign.

| Waits out the delay | Instant |
|---|---|
| allowing a verifier; adding an arbitrator | revoking either |
| listing an asset, re-enabling it, changing its oracle | delisting |
| adding an attestor or witness; lowering a threshold | removing one; raising a threshold |
| allowing a zkTLS bank endpoint | revoking one |
| registering an escrow with the registry | removing one |
| admitting an institution, raising credit, reinstating an LP | cutting credit, `SUSPENDED`, `NONE` |
| opening network Phase B or C | closing back to an earlier phase |
| oracle: adding a publisher, lowering its threshold | removing a publisher (never lowers the threshold), raising it |
| oracle: repointing a feed or leg (`PythFxOracle.setFeed`, `setLegs`), loosening a limit (`PythFxOracle.setLimits`: a longer `maxAge` or `closedMaxAge`, a wider confidence bound) | tightening an age or the confidence bound |
| vault: adding an adapter, raising its cap or reactivating it, changing the keeper, raising the deposit cap, widening the drawdown band | deactivating/removing an adapter, lowering caps, tightening the band, pausing, resuming, changing the guardian |

`transferGovernor` is instant and one step: handing it to `0x...dEaD` renounces governance for good (section 2c). The oracles are delayed too (SR2-30 in
`docs/security-review-phase2.md`): Movva mints and redeems at the FX rate, so which feed it reads and
how old a price it takes - or, on a signed leg, who signs it - and where a band's price comes from are
no longer only a band's business. Two consequences for operations: a dead feed stays dead until a
scheduled repoint executes, so schedule one when a deprecation is announced; and on a signed leg,
removing publishers below the threshold freezes the rate until a lower threshold executes, so run that
quorum with headroom (N ≥ M + 2). An oracle refuses to price until its
`completeSetup()`, so a consumer can never lean on one whose governor still has instant power.

To make a delayed change, the multisig submits `schedule(bytes)` with the setter's calldata,
waits, then submits `execute(bytes)` with the **same** calldata:

```bash
CALL=$(cast calldata "setVerifier(address,bool)" $NEW_VERIFIER true)
cast send $ESCROW "schedule(bytes)" $CALL          # via the multisig
cast call $ESCROW "readyAt(bytes32)(uint256)" $(cast keccak $CALL)
# ... GOVERNANCE_DELAY later, and within 14 days:
cast send $ESCROW "execute(bytes)" $CALL           # via the multisig
cast send $ESCROW "cancel(bytes)" $CALL            # instant, if you change your mind
```

Calling a delayed setter directly reverts with `ChangeMustBeScheduled(selector)`. That is the
contract working, not a broken transaction.

## zkTLS endpoints

**PIX, boleto and TED settle only through this path** (SR2-34 in `docs/security-review-phase2.md`).
`IAttestorVerifier.provesBankSession()` is true for `ReclaimZkTlsVerifier`, the only verifier. `FiatEscrow.postOffer`
and `OffRampEscrow.openSale` refuse a verifier that returns false (`BankRailNeedsZkTls`). So a Reclaim application credential and a reviewed template for each
LP's bank are launch preconditions: without them the ramp opens with nothing that settles a bank payment.

A zkTLS proof settles only against an allowlisted bank endpoint: the Reclaim `providerHash` of
the bank's provider template, and a URL prefix its `url` must start with. There is **no
default** - `DeployRamp.s.sol` refuses to deploy without one. Each endpoint also carries the rails it
may prove (`ZKTLS_ENDPOINT_RAILS`, one mask per endpoint over `IAttestorVerifier.Rail`): PIX only (2)
unless set, 6 for PIX and BOLETO. The LP proves its own bank session - on the on-ramp the credit it
received, on the off-ramp the PIX it sent or the boleto it paid - so the template reads the LP's side.

Before listing an endpoint, check, and have a second person check:

- the prefix is `https://<exact lowercase host>/...` for the bank's real API host;
- the template's `responseMatches` capture **every** field the verifier reads (`bankTxId`,
  `payeeKeyHash`, `payerRef`, `amountBrlCents`, `paidAt`, `rail`) from parts of the response
  the payer cannot write. A template that captures nothing lets the prover supply those
  fields - see SR2-11 in `security-review-phase2.md`;
- `providerHash` is what `hashProviderParams` in `packages/ramp/src/reclaim.ts` computes for
  that template;
- the BOLETO rail is set only where the template captures the paid barcode, hashed, and the amount
  from the bank-written receipt: a bank response shows the barcode, not a salted commitment to it
  ("Open risks" in `security-review-phase2.md`).

## Prices: Pyth's FX rate, a Chainlink feed per asset

Two BRL/USD sources exist on Ethereum mainnet (verified 19 October 2026):

- **Pyth's FX.USD/BRL**, the default and Mova's decision of 14 September 2026. It exists on Ethereum only once
  someone posts it there (`PythFork.t.sol`); Mova's keeper does.
- **Chainlink's BRL/USD**, proxy `0x3126E7F38D5f60f4E2B6ec3511C7bdbD79317Df1` in Chainlink's feed list
  (`reference-data-directory.vercel.app/feeds-mainnet.json`): "BRL / USD", 8 decimals, heartbeat 86,400 s,
  deviation threshold 0.5%, aggregator `0x3A9763662BFCa861340d1D40bA5e5A2a29Bc5f3e`. Contracts can read it
  (`ChainlinkFxFork.t.sol`). On 19 October 2026 its last round was 18 October 19:14 UTC, 0.1975293 US$ per real
  (R$ 5,0625 per dollar). An alternative FX leg for the reserve: "The Chainlink FX leg" below.

The September conclusion that Chainlink's BRL/USD was unusable on L1 read the wrong address.
`0x0eBDc65E7e9132Cb41ac5cbD0101B799D7aDb475`, which Chainlink's Feed Registry still returns for BRL/USD and which
`OracleFork.t.sol` and `packages/ramp/examples/brl-price.ts` used, is a **retired** proxy: last updated
25 August 2023, and a contract reading it gets `revert: No access`. Never configure it. Sepolia has no Chainlink
BRL/USD feed at all, so Sepolia stays on Pyth.

On mainnet the deployment uses `ORACLE_KIND=signed-fx` (the name predates Pyth) with the default
`FX_SOURCE=pyth`:

- **The FX leg.** A `PythFxOracle` over Pyth's FX.USD/BRL (`PYTH_USD_BRL_ID`, defaulting to
  `0xd2db4dbf1aea74e0f666b0e8f73b9580d407f5e5cf931940b06dc633d7a95906`) on the mainnet Pyth contract
  (`PYTH=0x4305FB66699C3B2702D4d05CF36551390A4c69C6`), in reais per dollar at 1e-6, behind a
  `ScaledFxBandOracle` that gives the bands centavos per dollar (about 540 at R$5.40). **Mova's Pyth
  keeper (`packages/yield`) posts the feed, and nothing prices until it has posted it on the chain.**
  Posting is permissionless and its key holds no role; it needs Hermes access, gas and Pyth's update fee.
- **Or a signed leg** (`FX_SOURCE=signed`): a `SignedPriceOracle` whose `PRICE_PUBLISHERS` sign the
  BRL/USD rate in centavos per US dollar, and nothing else. A supported alternative.
- **ETH's band.** A `ChainlinkSignedFxOracle`: Chainlink ETH/USD times the FX leg.
- **Each token in `USD_FEED_ASSETS`.** Its own `ChainlinkSignedFxOracle` with its Chainlink feed.
  USDT uses the USDT/USD proxy `0x3E7d1eAB13ad0104d2750B8863b489D65364e32D`. The script reads the
  token's decimals from the token and lists it on both escrows.

Each Chainlink leg's max age must fit that feed's heartbeat, so the script has no default for it.
The values below come from the feeds at block 25,971,545:

| Feed | Update intervals read | Max age to use |
|---|---|---|
| USDT/USD | 86,400 - 86,448 s (fourteen in a row): a daily heartbeat while the peg holds | `USD_FEED_MAX_AGES=90000` (25 h) |
| ETH/USD | up to 3,636 s over sixteen rounds | `ETH_USD_MAX_AGE=4500` (75 min) |

The Pyth leg's limits: `FX_MAX_AGE` (default 3600) is the oldest price that is still the rate, at any
hour; `FX_CLOSED_MAX_AGE` (default 345600, four days, also the most the script accepts) is the oldest
last close a band takes while the market is closed; `PYTH_MAX_CONF_BPS` (default 100) refuses a price
whose confidence interval is wider than 1% of it. The escrows refuse any price older than one hour
anyway, and each cross reports the FX leg's time, so **the keeper must post at least hourly while the
market trades**, or every asset stops trading. A Chainlink leg past its own max age stops only that
asset: its oracle reverts `StaleLeg(feed, updatedAt)`.

### The FX market closes; PIX does not

Pyth publishes FX.USD/BRL only on weekdays, 08:00-17:00 New York time, and not on 25 December or
1 January: about 73% of the week is closed. `PythFxOracle` reads it two ways (SR2-35):

- **the rate** (`brlCentsPerUnit`) refuses a price older than `maxAge`, at any hour;
- **a band's reading** (`brlCentsPerUnitForBand`) is the rate inside the core session and, outside it,
  the last close up to `closedMaxAge` old, stamped with the current block. `FxMarketHours` names the core
  session without daylight-saving rules: 13:30-21:00 UTC, Monday to Friday, except 25 December and 1 January.

What follows, on the day and after:

- the ramps' bands, Movva's included, keep trading at night and at weekends on the last close;
- the Movva reserve mints, redeems and withdraws to the hedge only at the rate, so all three
  wait for the market. Gateways should hold the Movva their offers need before each close;
- inside the core session a stale price means the keeper is down, and the bands refuse too; outside it a
  stale rate is the market closed, and a keeper that died before the close cannot be told from a closure
  until the next core session. `runbook-incidents.md` ("`oracle_freshness`") has the split.

The script refuses to deploy if a feed reverts when read, answers zero or less, or is already
older than its max age. It also refuses a `USD_FEED_ASSETS` address with no code.

**Every token whose issuer can freeze addresses needs a cap** (`ASSET_CAP_TOKENS` / `ASSET_CAPS`, base
units, applied to both escrows). The script refuses to list USDT or USDC without one. The cap is the
most Mova is willing to lose if Tether lists an escrow: what is inside at that moment is frozen with no
path out (SR2-25). Choose it before the rehearsal; lowering it later is instant, raising it waits out
the governance delay.

### The Chainlink FX leg (an alternative to Pyth, not the default)

`ChainlinkFxOracle` (`contracts/ramp/ChainlinkFxOracle.sol`) is the reserve's FX leg from Chainlink BRL/USD: reais
per dollar at 1e-6, `floor(10^14 / answer)`. It is **keyless** - every setting immutable, no governor - because the
Chainlink proxy is already the indirection (aggregator upgrades happen behind it) and replacing the leg is the
reserve's own delayed `setOracle`. `DeployMovva` deploys it with:

```bash
MOVVA_FX_SOURCE=chainlink MOVVA_CHAINLINK_BRL_USD=0x3126E7F38D5f60f4E2B6ec3511C7bdbD79317Df1 \
MOVVA_FX_MAX_AGE=93600 MOVVA_FX_CLOSED_MAX_AGE=345600 \
  ...the other MOVVA_ variables, as for Pyth... \
  $(bash scripts/foundry.sh path) script contracts/script/DeployMovva.s.sol:DeployMovva --rpc-url $RPC_URL
```

`MOVVA_FX_MAX_AGE` defaults to 93,600 s (26 h) on this path and is both the leg's `MAX_AGE` and the reserve's
`fxMaxAge`: the feed posts on a 0.5% move or its 24 h heartbeat, so the Pyth figure of an hour would refuse a healthy,
quiet feed for most of every day. The script refuses, before sending anything: a feed with no code, one that refuses
a contract (`No access`, as the retired proxy does), a description other than "BRL / USD", decimals other than
`MOVVA_CHAINLINK_BRL_USD_DECIMALS` (8), no answer within the max age on the target chain, an answer that inverts
outside `MOVVA_CHAINLINK_FX_MIN_E6`-`_MAX_E6` (default R$ 1-100, the reserve's own bounds: an immutable bound
tighter than the market might go would stop a keyless leg for good), a max age outside 25 h to 2 days, and a breaker
whose `MOVVA_BREAKER_BRL_USD_FEED` is the same feed (it would compare the leg with itself). It then checks the
reserve prices through the leg: the band reading at any hour, the rate inside the core session. Simulated against a
mainnet fork on 19 October 2026 (no `--broadcast`): it deployed and passed every check, and refused the retired
proxy by name.

What changes for operations:

- **Market hours.** Chainlink's heartbeat posts at weekends - rounds on Saturday 17 and Sunday 18 October 2026 at
  19:13 UTC, the Saturday one carrying a +0.23% move from after Friday's last round - so the answer's age never says the market is closed.
  The leg's **rate refuses outside FxMarketHours' core session** (`MarketClosed`), which is what keeps the 14 September
  decision: without it the reserve would mint and redeem all weekend at Friday's close. The **band** reading is
  stamped current at every hour (inside the session too: the escrows allow a band an hour, the feed posts daily),
  up to `MAX_AGE` old inside the session and `CLOSED_MAX_AGE` outside.
- **No keeper.** Chainlink pushes; nothing to fund or run. A missed heartbeat inside the session stops minting,
  redeeming and the bands (`StaleAnswer`).
- **The lag.** Inside the session the rate can be up to ~0.5% (the deviation threshold) from the market before a
  round lands - against fees of 10 bps each way. That bounded leak and its mitigations are in `docs/movva.md`,
  "The rate". The fees are the client's decision and unchanged.
- **The ramps** read the same leg through this deployment's `ScaledFxBandOracle` (`band adapter (cents)` in the log):
  point their USDT and ETH crosses at it with the delayed `oracle:fx-legs` change. `DeployRamp.s.sol` itself still
  deploys only a Pyth or a signed leg.
- **The monitor**: `MOVVA_RATE_WARN_SECONDS=90000 MOVVA_RATE_FAIL_SECONDS=93600`, since the rate is the feed's
  last round; `MarketClosed` is read as the closed market, as `StaleRate` is for Pyth.

**Run in parallel first.** Before switching, compare the two sources for a few weeks, inside and outside the session:
`npx tsx scripts/fx-parity.ts` once, or the monitor's `fx_parity` check (`FX_PARITY=true`, with `FX_PARITY_RPC_URL`
on mainnet and Hermes' `HERMES_API_KEY`). It reports the divergence in bps and each source's age, warns past 50 bps
(more than the deviation threshold explains) and fails past 300, and says when the market is closed. First run,
19 October 2026 17:25 UTC (a Monday, inside the session): Chainlink R$ 5,062540 (its round 22.2 h old, Sunday's
heartbeat) against Pyth R$ 5,061800, **+1.46 bps**.

## 1. Rehearse on a fork

The rehearsal is the test. Run it on the day, against a fork of current mainnet, from the
machine that will do the real deployment - and inside the FX core session (13:30-21:00 UTC on a
weekday). Outside it the rate refuses by design, and the rehearsal then exercises only the bands.

```bash
anvil --fork-url $ETHEREUM_MAINNET_RPC &
export RPC_URL=http://127.0.0.1:8545

# Deploy the ramp exactly as production will: ETH and USDT, one FX leg from Pyth
USDT=0xdAC17F958D2ee523a2206206994597C13D831ec7
GOVERNOR=$MULTISIG PP_ENTRYPOINT=$PP_ENTRYPOINT PP_POOL=$PP_POOL \
ARBITRATOR=$ARBITRATOR ZKTLS_WITNESSES=$ZKTLS_WITNESSES \
ORACLE_KIND=signed-fx PYTH=0x4305FB66699C3B2702D4d05CF36551390A4c69C6 \
FX_MAX_AGE=3600 FX_CLOSED_MAX_AGE=345600 PYTH_MAX_CONF_BPS=100 \
CHAINLINK_ETH_USD=0x5f4eC3Df9cbd43714FE2740f5E3616155c5b8419 ETH_USD_MAX_AGE=4500 \
USD_FEED_ASSETS=$USDT USD_FEEDS=0x3E7d1eAB13ad0104d2750B8863b489D65364e32D USD_FEED_MAX_AGES=90000 \
ASSET_CAP_TOKENS=$USDT ASSET_CAPS=$USDT_ESCROW_CAP_BASE_UNITS \
ZKTLS_PROVIDER_HASHES=$BANK_PROVIDER_HASHES ZKTLS_URL_PREFIXES=$BANK_URL_PREFIXES \
ZKTLS_ENDPOINT_RAILS=$BANK_ENDPOINT_RAILS \
GOVERNANCE_DELAY=172800 \
INSTITUTIONAL_LPS=$PHASE_A_LPS INSTITUTIONAL_CREDIT_CENTS=$PHASE_A_CREDITS \
  $(bash scripts/foundry.sh path) script contracts/script/DeployRamp.s.sol \
  --rpc-url $RPC_URL --broadcast
```

`ZKTLS_WITNESSES` is required (and `ZKTLS_THRESHOLD`, default 2). The log
names each oracle: `oracle` (ETH), `fx leg (BRL/USD)` (the centavo adapter, `$FX_LEG` below) with
`over PythFxOracle` (the governed Pyth leg, `$FX_SOURCE`), and `asset` with `its oracle` for USDT. No
band prices until the feed is posted on the chain. Start the Pyth keeper against the fork, or post one
update by hand - anyone can:

```bash
PYTH=0x4305FB66699C3B2702D4d05CF36551390A4c69C6
USD_BRL=0xd2db4dbf1aea74e0f666b0e8f73b9580d407f5e5cf931940b06dc633d7a95906
# the latest signed update, as hex, from the Hermes endpoint the keeper uses
UPDATE=0x$(curl -s "$HERMES_URL/v2/updates/price/latest?ids[]=$USD_BRL&encoding=hex" | jq -r '.binary.data[0]')
FEE=$(cast call $PYTH "getUpdateFee(bytes[])(uint256)" "[$UPDATE]" --rpc-url $RPC_URL)
cast send $PYTH "updatePriceFeeds(bytes[])" "[$UPDATE]" --value $FEE --rpc-url $RPC_URL --private-key $ANY_FUNDED_KEY
cast call $FX_SOURCE "brlCentsPerUnit()(uint256,uint64)" --rpc-url $RPC_URL   # ~5400000, published within FX_MAX_AGE
```

The Pyth leg has been deployed against a mock Pyth contract (`DeployRamp.t.sol` 2b: deployed by default,
handed over, pricing once posted) and, on 14 September 2026, against Sepolia's real Pyth on a Sepolia fork
as part of the whole rail (`scripts/deploy-movva-rail.ts`, "Sepolia rehearsal of the Movva rail" in
`docs/deployments.md`): deployed, handed over, and refusing with `StaleRate` exactly as it must while
Sepolia's FX.USD/BRL is months old. Nothing has posted a fresh price to it yet, because that needs a Hermes
credential. It has not been rehearsed on a mainnet fork. Do that before the day, with the keeper posting,
and record the same figures as the signed rehearsal below.

The Sepolia rehearsal is the order of section 3b end to end, and its verification is section 3's checks as
code. Run it on a fork before any Sepolia deployment, and use its sequence and checks as the model for the
mainnet day - the script itself is Sepolia's: its feeds, Pyth, stand-in USDT and test identities are
hard-coded for that chain:

```bash
npx tsx scripts/deploy-movva-rail.ts --port 8953          # a fork of SEPOLIA_RPC; writes deployments/sepolia-movva-rail.rehearsal.json
npx tsx scripts/deploy-movva-rail.ts --verify <deployment.json> --rpc $RPC_URL   # the read-only checks alone (a record that
                                                                                 # carries sMovva - any made before D1 - from its own commit)
```

With `FX_SOURCE=signed` (and `PRICE_PUBLISHERS`, `PRICE_THRESHOLD` in place of the Pyth variables), the
publishers post the first rate right after deploying:

```ts
// Each publisher signs what it observed, in the direction it observed it; signFx converts and
// refuses an inverted or mis-scaled quote before signing.
const a = await new PricePublisher(KEY_A, 1, FX_LEG).signFx({ brlPerUsd: '5.4049' }, now, now);
const b = await new PricePublisher(KEY_B, 1, FX_LEG).signFx({ usdPerBrl: '0.18502' }, now, now);
const q = collectQuorum([a, b]); // then FX_LEG.submit(q.brlCentsPerUnit, q.publishedAt, q.sequence, q.signatures)
```

Rehearsed on 2026-09-14, before the Pyth decision and SR2-34, with the signed leg against an anvil fork
of mainnet at block 25,971,704, with 0xbow's Entrypoint and the variables above (the signed ones in
place of Pyth's):

- the script deployed, wired, closed setup and handed over every contract, all three oracles
  included: 32 transactions, 21,943,045 gas;
- a rate signed through `signFx` by two publishers, one quoting `brlPerUsd` and one `usdPerBrl`,
  submitted as 540. The USDT band then read 540 and the ETH band 1,341,189;
- both escrows' `assets(USDT)` returned `(usdt oracle, 6, true)`;
- a Phase A LP posted a real 1,000 USDT offer at 540 (437,145 gas), and an offer at 600 reverted
  `PriceOutsideBand`;
- a seller opened a 100 USDT sale for R$540.00 (299,736 gas).

Both predate SR2-34: a PIX offer or sale must now name the zkTLS verifier, and the escrow refuses any
verifier that does not prove the bank session (`BankRailNeedsZkTls`).

`INSTITUTIONAL_LPS` is optional. LPs admitted there are admitted during setup, in the public
deployment transactions, and can trade as soon as the deployment lands. Anyone admitted later
waits out `GOVERNANCE_DELAY`.

The script wires everything, closes setup on every delayed contract, hands every governor -
**including the oracles', the Pyth leg's too** - to `GOVERNOR`, and reverts if any of that did not happen.

Then run the end-to-end demos against those addresses — `onramp.ts`, `offramp.ts`,
`full-rail.ts`. A rehearsal that deploys but never trades has tested the deployment script,
not the deployment. Settle at least one on-ramp and one off-ramp by PIX with a zkTLS proof from a
real bank session, through an endpoint you are about to allowlist: it is the only way a bank payment
settles. On the fork, practise one delayed change end to end: schedule it,
`cast rpc evm_increaseTime 172800`, execute it.

Record the gas used. The ramp measured ~12.4M gas in test deployments before the governance
delay was added. With the delay, `signed-fx` and USDT, the rehearsal above measured 21.9M gas over
32 transactions - before the oracles gained their own governance delay, which adds a `completeSetup`
per oracle (three for `signed-fx` with USDT, on either FX source; the Pyth leg also deploys its centavo
adapter), and a Movva escrow pair adds about twelve more. Measure
again on the day, and check the current base fee before you start to decide whether to wait.

The USDT path's behaviour against the real token, feed, Entrypoint and pool, including every power
Tether holds over it, is `contracts/test/UsdtRampFork.t.sol`. Run it on the day too:

```bash
FORK_RPC=$ETHEREUM_MAINNET_RPC $(bash scripts/foundry.sh path) test --match-path contracts/test/UsdtRampFork.t.sol
```

## 2. Deploy

Same command, real RPC, real signer. Deploy the **tagged audited commit**, from a clean checkout.

## 2b. The record, before anything else

Write every address, the deployer, the first block and the transaction hashes into a deployment JSON in the rail's
layout (`contracts.protocol`, `.movva`, `.pools`, `.ramp`, `deployer`, `firstBlock`, `steps.<name>.txs[].hash`: see
`deployments/sepolia-movva-rail.rehearsal.json`). On Sepolia, `scripts/deploy-movva-rail.ts` writes it itself. With
0xbow's Entrypoint, leave `contracts.protocol` and `contracts.pools` out: that code is 0xbow's, not this build's. Then:

```bash
npx tsx scripts/deployment-record.ts record deployments/mainnet-movva-rail.json --rpc $RPC_URL
```

It is read-only. It writes `deployments/mainnet-movva-rail/`:

- `VERIFICATION.md`;
- `privileges.json`;
- `etherscan-verify.sh`;
- `abi/`.

It checks every address's code against this checkout's build (immutables masked, libraries linked), every creation
transaction's init code and constructor arguments, and every source file's hash against the build metadata. It
records the build hash, and fails if a build input is uncommitted. It dry-runs each `forge verify-contract` command:
forge writes the standard-JSON input it would submit, solc compiles it, and the result must equal the code at the
address. It then takes the privilege inventory: every role holder, switch and EIP-1967 slot, and every state-changing
function from the ABI, probed from a stranger, the deployer and each holder. **Stop on any failure.**

Then verify the sources on Etherscan, so the client and any reviewer can read what was deployed:

```bash
ETHERSCAN_API_KEY=... bash deployments/mainnet-movva-rail/etherscan-verify.sh
```

The script checks that HEAD is the recorded commit. Library paths in it are spelled through the remapping
(`poseidon-solidity/PoseidonT3.sol:...`); do not "fix" them to a file path, or forge submits the pools unlinked and
Etherscan cannot match them.

Anyone can recompute the build hash from the tag: `npx tsx scripts/deployment-record.ts build-hash <json>`.
`npx tsx scripts/privilege-inventory.ts <json> --rpc $RPC_URL` re-reads the privileges at any time.

## 2c. Renouncing governance, if the client chose it

`--finalize` does this on Sepolia (`deploy-movva-rail.ts --broadcast-sepolia --finalize`; rehearsed in
`deployments/sepolia-movva-rail.finalized.rehearsal/`). On mainnet the same calls go from the multisig, and only after
section 3 passes and the first trade (section 5) settled:

1. The Entrypoint (our own stack only; 0xbow's is theirs): check `assetConfig` for every asset's pool, and that
   `hasRole(ASP_POSTMAN, <postman>)` is true. Then `renounceRole(OWNER_ROLE, <owner>)`. OWNER_ROLE is the admin of
   every role, so afterwards no role can be granted or revoked, the postman cannot be replaced, the Entrypoint cannot
   be upgraded, pools cannot be added or reconfigured, and vetting fees can never be withdrawn.
2. Every DelayedGovernance contract: `completeSetup()` if `setupComplete()` is false, then
   `transferGovernor(0x000000000000000000000000000000000000dEaD)`. It is one step and instant; there is no acceptance.
3. Re-run the record (section 2b). It must show every governor at `0x...dEaD`, nobody holding OWNER_ROLE, and the
   deployer (and the multisig) refused by every governor and owner function.

What stays: the ASP postman, the arbitrators, the witnesses, the Movva gateways, treasurer and guardian,
and the LPs. Their keys can never be rotated or revoked again. Read "If something is wrong after deployment" with that
in mind: after this section, no row of it can be carried out.

## 3. Check the wiring before any money moves

```bash
# $FX_SOURCE is the governed FX leg: the PythFxOracle ("over PythFxOracle" in the log), or with
# FX_SOURCE=signed the SignedPriceOracle, which is then $FX_LEG itself. The centavo adapter has no governor.
for C in $ESCROW $OFFRAMP $REGISTRY $ZKTLS $ORACLE $FX_SOURCE $USDT_ORACLE; do
  cast call $C "governor()(address)" --rpc-url $RPC_URL        # the multisig, every one
done
for C in $ESCROW $OFFRAMP $REGISTRY $ZKTLS $ORACLE $FX_SOURCE $USDT_ORACLE; do
  cast call $C "setupComplete()(bool)" --rpc-url $RPC_URL      # true: changes are delayed (oracles: and prices readable)
  cast call $C "GOVERNANCE_DELAY()(uint256)" --rpc-url $RPC_URL
done
cast call $ESCROW   "POOL()(address)"                     --rpc-url $RPC_URL
cast call $REGISTRY "phase()(uint8)"                      --rpc-url $RPC_URL   # 0 = Phase A
cast call $ZKTLS    "endpointCount()(uint256)"            --rpc-url $RPC_URL
cast call $ZKTLS    "endpointRails(bytes32)(uint16)" $PROVIDER_HASH --rpc-url $RPC_URL   # 2 = PIX, 6 = PIX + BOLETO
cast call $ZKTLS    "provesBankSession()(bool)"           --rpc-url $RPC_URL   # true: PIX, boleto and TED settle here
# The Pyth leg
cast call $FX_LEG    "SOURCE()(address)"                  --rpc-url $RPC_URL   # $FX_SOURCE
cast call $FX_SOURCE "PYTH()(address)"                    --rpc-url $RPC_URL   # 0x4305FB66699C3B2702D4d05CF36551390A4c69C6
cast call $FX_SOURCE "usdBrlId()(bytes32)"                --rpc-url $RPC_URL   # 0xd2db...5906, FX.USD/BRL
cast call $FX_SOURCE "maxAge()(uint64)"                   --rpc-url $RPC_URL   # 3600
cast call $FX_SOURCE "closedMaxAge()(uint64)"             --rpc-url $RPC_URL   # 345600
cast call $FX_SOURCE "maxConfBps()(uint16)"               --rpc-url $RPC_URL   # 100
cast call $ORACLE   "brlCentsPerUnit()(uint256,uint64)"   --rpc-url $RPC_URL   # once the keeper has posted
# USDT: listed on both escrows with its own oracle and 6 decimals, crossed with the one FX leg
cast call $ESCROW  "assets(address)(address,uint8,bool)" $USDT --rpc-url $RPC_URL   # $USDT_ORACLE, 6, true
cast call $OFFRAMP "assets(address)(address,uint8,bool)" $USDT --rpc-url $RPC_URL   # the same
cast call $USDT_ORACLE "usdBrl()(address)"     --rpc-url $RPC_URL   # $FX_LEG
cast call $USDT_ORACLE "assetUsd()(address)"   --rpc-url $RPC_URL   # 0x3E7d1eAB13ad0104d2750B8863b489D65364e32D
cast call $USDT_ORACLE "assetMaxAge()(uint64)" --rpc-url $RPC_URL   # 90000
cast call $USDT_ORACLE "brlCentsPerUnit()(uint256,uint64)" --rpc-url $RPC_URL   # ~540 at R$5.40
cast call $PP_ENTRYPOINT "assetConfig(address)(address,uint256,uint256,uint256)" $USDT --rpc-url $RPC_URL
#   pool, minimum deposit (25 USDT on 0xbow's today), vetting fee bps, max relay fee bps
```

Oracles listed through `ASSETS`/`ASSET_ORACLES` were deployed elsewhere, and the script neither
holds nor checks their governors. Check each by hand, the same way - including `setupComplete()`
and `GOVERNANCE_DELAY()`: an oracle still in setup refuses to price, and one whose delay is shorter than
the escrows' is the weakest link.

Every governor must be the multisig, not the deploying key - the oracle included; an earlier
version of the script left it with the deployer. A contract whose `setupComplete()` is false
accepts no business and still allows instant changes: close it with `completeSetup()` from
the multisig before announcing the deployment.

**The rate must be posted and fresh before anything is announced.** With the keeper running, inside a
core session (`cast call $FX_SOURCE "inCoreSession()(bool)"` answers true):

```bash
cast call $FX_SOURCE   "brlCentsPerUnit()(uint256,uint64)" --rpc-url $RPC_URL   # does not revert; published within maxAge
cast call $USDT_ORACLE "brlCentsPerUnit()(uint256,uint64)" --rpc-url $RPC_URL   # ~540 at R$5.40
```

Read both again after a few of the keeper's cycles: the publish time must move. A leg that answers only
outside the core session is answering with a close, which proves nothing about the keeper.

## 3b. Movva: the reserve, then its own escrow pair

Design and parameters: `docs/movva.md`. Order matters, because each step reads what the one before
deployed:

1. **`DeployMovva.s.sol`** with the `MOVVA_*` environment in its header (`MOVVA_SUPPLY_CAP` is required;
   the defaults are the sized parameters: 108% target, 103% withdraw floor, 8% daily hedge limit, and the fees
   benchmarked to traditional finance: 0.10% to mint, 0.10% to redeem). There is no savings option: sMovva and the
   distribution fee were removed by client decision D1 (14 October 2026). It
   deploys the reserve (which deploys the token) and the millionths FX leg - closes every setup,
   hands over, and prints `MOVVA_RESERVE=` and `MOVVA_TOKEN=`. The FX leg is, by default, a `PythFxOracle`
   on `MOVVA_PYTH` (`MOVVA_PYTH_USD_BRL_ID` defaults to FX.USD/BRL, `MOVVA_PYTH_MAX_CONF_BPS` to 100,
   `MOVVA_FX_CLOSED_MAX_AGE` to four days; `MOVVA_FX_MAX_AGE`, 3600, is the rate's max age on the reserve
   and the leg alike). A new Pyth leg prices only once the keeper has posted the feed on that chain.
   `MOVVA_FX_E6_ORACLE` names an existing leg instead, or `MOVVA_FX_PUBLISHERS` deploys a signed one; an
   existing leg still in setup, or with a shorter governance delay than the reserve's, is refused.
   It also deploys node-provider rewards - a `FeeSplitter` as the reserve's fee recipient and `NodeRewards` - closed and
   handed over like the reserve, and prints `NodeRewards` (the `NODE_REWARDS` of step 3).
2. **The Movva Privacy Pool** (Movva only; there is no sMovva pool since D1), registered on Mova's own Entrypoint by Mova's governance.
   Upstream's `DeployComplexPool.s.sol` prompts for each token; `scripts/deploy-movva-rail.ts` (step `pools`) does
   the same CreateX deployment with upstream's salt, then `registerPool`, without the prompts.
3. **`DeployRamp.s.sol`** with `MOVVA_RESERVE` and `MOVVA_TOKEN` exactly as printed, `MOVVA_PP_ENTRYPOINT`,
   `NODE_REWARDS` (the `NodeRewards` DeployMovva printed: the registry's rewards hook is set to it during setup, and the
   script refuses one with no code, setup open, a shorter governance delay, or paying anything but `MOVVA_TOKEN`),
   and optionally `MOVVA_BAND_BPS` (default 300). Movva gets a **second** `FiatEscrow` / `OffRampEscrow`
   pair: `BAND_BPS` is immutable per escrow and 5% around R$ 1,00 is no peg. The pair shares the LP
   registry, verifiers and arbitrator (so an LP's credit is one number across both pairs), lists Movva
   with the reserve as its oracle and delists native ETH. At 300 bps an offer passes at 97-103 centavos
   while fully backed, and below par an LP can still buy a holder's Movva under what redeeming pays - at
   100 bps it could not, and exits would stall exactly when holders want out (see the script's header). The script refuses a token that is
   not the reserve's (or whose minter is not the reserve), decimals other than 18, a reserve or FX leg
   still in setup or with a shorter delay, an Entrypoint with no Movva pool, and a band under 100 bps or
   not tighter than the main pair's.
4. **Bind node-provider rewards to the registry DeployRamp printed**, from the multisig that governs NodeRewards:

   ```bash
   npm run -w @mova/ops admin -- rewards:registry $NODE_REWARDS $REGISTRY   # dry run: the call, its class, the calldata
   ```

   DeployRamp logs this exact line. The binding is immediate while NodeRewards has never been funded and holds no
   token (the dry run's `class` line says which); after the first `split()` or any donation it is a scheduled change
   (`gov:schedule rewards:registry ...`, then `gov:execute` after the delay). Until it lands the registry's hook reports
   every settlement and NodeRewards counts none of them, so bind it before the first trade. Check both halves:
   `cast call $REGISTRY "rewardsHook()(address)"` answers `$NODE_REWARDS`, and `cast call $NODE_REWARDS "registry()(address)"`
   answers `$REGISTRY`. `scripts/deploy-movva-rail.ts` runs this step (`bind`) after DeployRamp, on Sepolia and its fork.
5. **Seed the buffer before opening any gateway**: `recapitalize` to the 108% target, so the reserve starts
   at rest (docs/movva.md, "Sizing the buffer").
6. **Keepers and monitor**: the Pyth keeper, already running (nothing prices without it); the vault keeper
   for the reserve's `YieldVault`, and the monitor with `MOVVA_RESERVE` - its watcher follows the
   reserve's FX leg and alerts on every change scheduled on either.

```bash
cast call $MOVVA_RESERVE "setupComplete()(bool)"              --rpc-url $RPC_URL   # true
cast call $MOVVA_RESERVE "governor()(address)"                --rpc-url $RPC_URL   # the multisig
# Inside the core session: the rate and the ratio refuse outside it, by design
cast call $MOVVA_RESERVE "brlPerUsdtE18()(uint256,uint64)"    --rpc-url $RPC_URL   # ~5.4e18 once the keeper has posted
cast call $MOVVA_RESERVE "bandBrlPerUsdtE18()(uint256,uint64)" --rpc-url $RPC_URL  # the same; off-hours, the last close
cast call $MOVVA_RESERVE "collateralRatioBps()(uint256)"      --rpc-url $RPC_URL   # >= 10800 before gateways open
for E in $MOVVA_ONRAMP $MOVVA_OFFRAMP; do
  cast call $E "BAND_BPS()(uint256)"                          --rpc-url $RPC_URL   # 300
  cast call $E "assets(address)(address,uint8,bool)" $MOVVA_TOKEN --rpc-url $RPC_URL   # $MOVVA_RESERVE, 18, true
  cast call $E "assets(address)(address,uint8,bool)" 0x0000000000000000000000000000000000000000 --rpc-url $RPC_URL   # enabled = false
  cast call $E "setupComplete()(bool)"                        --rpc-url $RPC_URL   # true
done
```

Gateways (the LPs that mint and redeem) are admitted with `admin movva:gateway`, which waits out the delay
unless listed in `MOVVA_GATEWAYS` at deploy. Onboarding one is `runbook-lp-onboarding.md`; operating the
hedge is `runbook-movva-hedge.md`.

Gateways mint and redeem only while the rate is fresh, which off-hours it is not. Seed the buffer and open
gateways inside a core session, and have each gateway hold the Movva its offers need before every close:
off-hours its offers sell what it holds, and one that runs out stops quoting until the market reopens
(`docs/movva.md`, "The rate").

## 3c. The gas sponsor: stake it, or no public bundler carries it

Public bundlers (Pimlico, Alchemy, Etherspot, Candide) run each operation's validation under ERC-7562's
rules before accepting it, and drop what breaks them. `SponsorPaymaster` passes only with a **stake at the
EntryPoint**: its validation reads its own storage (`maxCostAllowed`, the budget settings; ERC-7562
STO-031) and returns a context for `postOp` (EREP-050), and ERC-7562 allows both only to a staked
paymaster. Unstaked, every sponsored operation is refused. Rundler answers `entity stake/unstake delay too
low` (`packages/smart-account/examples/erc7562-live.ts`, rows P3 and P4). `DeployPaymaster` funds the gas
deposit but does not stake, because only the owner can.

| Setting | Value | Why |
|---|---|---|
| Unstake delay | 86400 s or more | ERC-7562's `MIN_UNSTAKE_DELAY`. Rundler refuses less by default; each hosted bundler sets its own floor |
| Stake | 1 ETH or more, unless every bundler you use publishes a lower minimum | Rundler's default `min_stake_value` is 1 ETH; ERC-7562 recommends "roughly $1000 equivalent". `DeployPaymaster` prints the stake to send (`STAKE_WEI`, default 1 ETH) and refuses an `UNSTAKE_DELAY` under 86400 |
| Gas deposit | separate from the stake | The stake pays for no gas. Fund both: the "Gas funded" gate above covers the deposit, and the stake is 1 ETH on top, locked rather than spent |

SponsorGate owns the paymaster, so its governor sends the stake through the gate, which forwards `addStake`.
Without `--execute` the tool prints the call for the multisig:

```bash
npm run -w @mova/ops admin -- paymaster:add-stake $SPONSOR_GATE 86400 1000000000000000000
cast call 0x0000000071727De22E5E9d8BAf0edAc6f37da032 \
  'getDepositInfo(address)((uint256,bool,uint112,uint32,uint48))' $PAYMASTER
# expect: (deposit, true, stake >= 1e18, 86400 or more, 0)
```

From then on the monitor's `paymaster_stake` check (section 4, with `PAYMASTER` set) fails when the stake is
missing, unlocked, under `PAYMASTER_MIN_STAKE_WEI` (default 1 ETH) or on a delay under
`PAYMASTER_MIN_UNSTAKE_DELAY_SECONDS` (default 86400). Set the floor to the highest of the bundlers the wallet uses.

**Never `unlockStake` (`admin paymaster:unlock-stake`) while the paymaster sponsors anyone.** The EntryPoint marks the stake unstaked in
that block, and bundlers refuse every sponsored operation from then on. The withdrawal itself only opens
after the delay.

What an operator will also meet:

- **An account past its gas budget is refused as "not valid yet", not as a rule violation.** The
  paymaster answers an operation that does not fit the account's current window with `validAfter` = the
  window's end, which the EntryPoint enforces (AA32). Bundlers turn it away until then. Sponsorship for
  that account resumes at `windowStartedAt(account) + budgetWindow`.
- **Deploy only a build with the ERC-7562 fix.** Earlier builds read TIMESTAMP during validation when
  budgets are on, and bundlers refuse all of their operations (Rundler: `paymaster uses banned opcode:
  TIMESTAMP`).
- **`postOp` must pay for two new storage slots.** The wallet signs `paymasterPostOpGasLimit` = 150,000,
  enough at Osaka's prices. Under a later fork's gas schedule (geth's dev genesis enables one), the same
  `postOp` ran out of gas, and the EntryPoint then reverts the user's calls. Re-measure before any fork that
  reprices storage reaches mainnet.
- **Kernel accounts:** Rundler-based bundlers refuse a Kernel v3.1 account's first operation when it
  carries initCode through ZeroDev's meta factory. Deploy such an account with a plain transaction first
  (`docs/wallet-custody.md` §10.3). Safe accounts are unaffected.

## 4. Start the keeper and the monitor before the first trade

The Pyth keeper (`packages/yield`) must already be running: it is what makes anything price. It posts
FX.USD/BRL from Hermes. Posting is permissionless and its key holds no role, so a leaked key costs its
float and nothing else; what it needs is Hermes access, gas, and Pyth's update fee on every post. Fund it
for weeks, not days, and have someone watch that balance: an empty keeper inside the core session stops
every band and the Movva reserve within `FX_MAX_AGE`.

```bash
RPC_URL=$MAINNET_RPC PP_ENTRYPOINT=$PP_ENTRYPOINT ORACLE=$FX_LEG \
ESCROW=$ESCROW OFFRAMP_ESCROW=$OFFRAMP VAULT=$VAULT RELAYER=$RELAYER PAYMASTER=$PAYMASTER \
ASSETS=0x0000000000000000000000000000000000000000,$USDT \
USDT=$USDT USDT_POOL=0xe859C0bD25f260BaEE534Fb52e307D3b64D24572 \
ALERT_WEBHOOK=$SLACK_WEBHOOK \
  npm run -w @mova/ops monitor
```

The monitor runs three price and token checks:

- **`oracle_freshness`** reads the FX leg as the bands read it (`ORACLE=$FX_LEG`, the centavo adapter,
  not the `PythFxOracle` under it, whose rate refuses every night by design): Pyth's last price inside
  the core session, the last close outside it.
- **`asset_oracle:<asset>`** runs per asset in `ASSETS` (the zero address is ETH). It uses the
  oracle each escrow actually has configured for that asset. It warns at 30 minutes and fails at
  two hours, and fails at once, naming the leg, if the oracle reverts.
- **`usdt_state`** fails if Tether pauses USDT, switches on its fee, deprecates it, or blacklists
  either escrow, the Entrypoint or the USDT pool - and, with `USDT_VAULT` and `USDT_YIELD_ADAPTERS`
  set, the USDT yield vault or its adapters.

Confirm by hand, once: `curl $MONITOR/status` should list every check with a reading. A
monitor watching nothing reports `ok` forever, and that is indistinguishable from health.

A `ChangeScheduled` event nobody on your side scheduled means the governor key is
compromised. The delay is your window: revoke, suspend and pause are instant; tell LPs and
users to exit; `cancel` if you still control the key.

## 5. First trade, deliberately small

Trade at the smallest amount the pool's `minimumDepositAmount` allows, with an LP who knows
it is a test. Watch the whole path: the order locks, the zkTLS proof of the LP's bank session
verifies, the escrow releases, the shielded balance appears, the monitor stays quiet. Do it in ETH and in USDT. The
USDT pool's minimum is 25 USDT, and **a shielded order below it locks but can never settle**
(SR2-27). Have LPs quoting USDT for shielded delivery set their minimum order to at least 25 USDT,
and confirm the client refuses smaller shielded orders.

Then do it in reverse — an off-ramp — and confirm the BRL lands in a real bank account and the LP's
proof of its own payout settles the sale.

## 6. Raise the limits deliberately

Start in Phase A with low institutional credit, and raise it as volume proves the path. A
credit limit is the most an LP may have live **in total**, across every offer, order and
claimed sale on both escrows. Raising one is a delayed change:

```bash
CALL=$(cast calldata "setTier(address,uint8,uint256)" $LP 3 5000000)   # 3 = INSTITUTIONAL, R$50.000
cast send $REGISTRY "schedule(bytes)" $CALL     # multisig; execute after GOVERNANCE_DELAY
```

Tier indices: `0 NONE, 1 RETAIL, 2 AFFILIATED, 3 INSTITUTIONAL, 4 SUSPENDED`. Opening Phase B
(`setPhase(uint8)` with 1) and Phase C (2) is scheduled the same way; see
`runbook-lp-onboarding.md`.

## If something is wrong after deployment

Mova's contracts are immutable by design: no proxy, no upgrade path, no admin withdrawal. The one upgradeable
contract is the Privacy Pools Entrypoint (upstream's UUPS proxy), and only while someone holds its OWNER_ROLE. The
deployment record lists every such power (section 2b). What you have instead - and every action in this table is
**instant** - is the governor. **After section 2c (renouncing), nobody can take any of these actions.**

| Problem | Action |
|---|---|
| A verifier is wrong or compromised | `setVerifier(<verifier>, false)` on both escrows — stops new settlements through it immediately. Revoking the zkTLS verifier stops every PIX and boleto settlement: there is no other verifier a bank payment can settle on |
| A zkTLS bank endpoint is wrong | `revokeEndpoint(<providerHash>)` on the zkTLS verifier |
| A witness key leaked | `setWitness(<key>, false)`. The threshold does NOT drop with it: if proofs stop verifying, schedule a lower threshold or a replacement, and use disputes for stranded orders |
| An arbitrator key leaked | `setArbitrator(<key>, false)`. A replacement waits out the delay and can then refund, but not release, disputes raised before it was added - keep a second arbitrator registered |
| The BRL price is wrong | On the Pyth leg nothing inside the oracle repoints at once: tighten `setLimits` where a lower confidence bound or age would refuse the price (instant), pause Movva minting (the guardian, instant), and delist any asset whose band admits bad offers (instant); `setFeed` to another feed waits out the delay. On a signed leg, `setPublisher` to remove a publisher, or raise its threshold. Existing escrows settle or refund normally |
| The Pyth keeper is down (`oracle_freshness` or `movva_rate` stale inside the core session) | Restart it, or post an update by hand from any funded key ("Rehearse on a fork"): posting is permissionless and needs no governance. Top up its gas and fee float |
| One asset's Chainlink leg is dead or wrong (`asset_oracle:<asset>` failing with `StaleLeg` or `BadPrice`) | `setLegs(<feed>, <fxLeg>, <assetMaxAge>, <fxMaxAge>)` on that asset's oracle (`admin oracle:fx-legs`) to point at a working feed. Do not raise the max age past the feed's heartbeat to make the alert go away |
| Tether paused USDT or switched on its fee (`usdt_state`) | Tell takers not to pay USDT orders. A taker who already paid disputes before the pay window closes, and the `RELEASE` executes once USDT moves again (SR2-22, SR2-23). New USDT offers are refused by the escrows on their own while a fee is on |
| Tether blacklisted an escrow (`usdt_state`) | The escrow already refuses new USDT offers, sales, orders and claims by itself. Delist USDT on it anyway (`setAsset(<usdt>, <oracle>, 6, false)`) so the book is honest, and tell LPs and sellers: what it held is frozen, at most its `assetCap` (SR2-25) |
| Tether blacklisted the Entrypoint (`usdt_state`) | New shielded USDT orders are refused by the escrow. Takers who already paid for one call `takeDeliveryDirect(orderId)` from their rescue address, then release as usual; the wallet should offer this (SR2-26) |
| Tether blacklisted the USDT pool (`usdt_state`) | New shielded USDT orders are refused. Every note in the pool is frozen, ragequit included; nothing in our contracts can move them (SR2-26) |
| Tether blacklisted the USDT yield vault (`usdt_state`) | The vault already refuses deposits and reports no room; nothing to do on-chain. Tell holders their USDT is frozen until Tether unlists it (SR3-9) |
| An escrow is at its USDT cap (`asset_cap:<usdt>`) | New USDT offers and sales on it are refused. Raising the cap is a scheduled change (`gov:schedule escrow:asset-cap ...`); decide whether the exposure is acceptable first |
| Tether deprecated USDT (`usdt_state`) | Delist USDT and review the successor contract before relisting, which is delayed (SR2-29) |
| The yield vault is losing value | `pauseDeposits()` — deposits stop, withdrawals stay open. `updateAdapter(<adapter>, 0, false)` stops the keeper allocating to it |
| An LP is misbehaving | `setTier(<lp>, 4, 0)` (`SUSPENDED`). Suspending an institution also stops its affiliates taking new exposure |
| Retail or affiliate onboarding is being abused | `setPhase(<earlier phase>)` — stops new registrations and new positions for those tiers; live positions run off |
| Something worse | Parameter changes ship as a new deployment with explicit user migration. Users can always exit: escrow timeouts refund permissionlessly and pool ragequit needs no service at all |

Re-enabling anything in this table is a delayed change.
