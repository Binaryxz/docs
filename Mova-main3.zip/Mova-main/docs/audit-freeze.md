# Audit freeze, 20 October 2026

For the client's auditors. It names the commit to audit and the final addresses on Sepolia, and says contract by
contract whether the code at each address is the code in that commit.

## The commit

The frozen commit is the git tag **`audit-freeze-2026-10-20`**: `2e442a40ab377d9b8a12c95ac6aafe5d6f53812f`, branch
`phase-1-shielded-rail`. Every contract below was deployed from it. Commits after the tag add deployment records
and documentation only: `git diff audit-freeze-2026-10-20 HEAD -- contracts packages/smart-account/contracts/src protocol/contracts/src`
is empty.

It replaces `audit-freeze-2026-10-19` (`60e4db7`), which was never sent. Since that tag:
- a `HedgeSubWallet` sizing fix found by the invariant suite ([audit-scope.md](audit-scope.md), "Known issues");
- the permissionless LP registry ([permissionless-registry.md](permissionless-registry.md)), audited separately;
- deploy tooling for the final rail.

The escrows are byte-identical in both tags.

**In scope first: the escrows**, by the client's decision of 19 October (audit order (ii)): `FiatEscrow`,
`OffRampEscrow` and `RulingLib`, with `ILPRegistry` and the `LPRegistry` they call. The permissionless registry
(`PermissionlessLPRegistry`) is in the commit and is audited separately, after it is built into a rail. The rest of
the repository is described in [audit-scope.md](audit-scope.md).

## Rebuilding and checking it

```bash
git checkout audit-freeze-2026-10-20
eval "$(bash scripts/foundry.sh export)"          # the pinned Foundry
forge build                                       # contracts/ -> forge-out/ (solc 0.8.28, optimizer 1000, cancun)
(cd protocol/contracts && forge build)            # the Privacy Pools fork -> out/
(cd packages/smart-account/contracts && forge build)
forge test                                        # 99 suites, 1,085 tests, all passing at the freeze
npx vitest run                                    # TypeScript: 172 files, 2,389 tests, all passing at the freeze
RPC_URL=<a Sepolia node> python3 scripts/compare-deployed.py \
  deployments/sepolia-movva-final-rail/etherscan-verify.sh \
  deployments/sepolia-final-hedge-sleeve/etherscan-verify.sh \
  deployments/sepolia-account-stack-frost-v2/etherscan-verify.sh \
  deployments/sepolia-account-stack/etherscan-verify.sh
```

`scripts/compare-deployed.py` compares the runtime code at each address with this build. It masks immutables
and linked-library slots, and separates the code from the metadata hash. The rail's own record does more:
`deployments/sepolia-movva-final-rail/VERIFICATION.md` has every source hash, the creation code and constructor
arguments of each creation transaction, a privilege inventory of every function, and 247 passing checks. Every
contract is source-verified on Etherscan.

## The final rail

Deployed on 20 October 2026 from `0x4D0dF9bB92883cf5584c812EB84AABA55d688853`, the governor of every governed
contract. The 2-of-3 custody Safes have held their roles since the first transaction:

| Role | Safe (1.4.1, 2 of 3) |
|---|---|
| Escrows' only arbitrator | [`0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7`](https://sepolia.etherscan.io/address/0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7) |
| Reserve guardian | [`0xd67DDA7D07CAa45d6f8e7C1dD0a170585e6B086c`](https://sepolia.etherscan.io/address/0xd67DDA7D07CAa45d6f8e7C1dD0a170585e6B086c) |
| Reserve treasurer | [`0x6C41c72A11fAf1E9FB0c462F9A3C32e3B1D26561`](https://sepolia.etherscan.io/address/0x6C41c72A11fAf1E9FB0c462F9A3C32e3B1D26561) |
| Hedge treasury (also the sub-wallet's `TREASURY`) | [`0x4464eddDd3c021BFa48f5e6c7E96163056806Cdb`](https://sepolia.etherscan.io/address/0x4464eddDd3c021BFa48f5e6c7E96163056806Cdb) |

The registry admits two INSTITUTIONAL LPs with R$ 50.000 of credit each: the rail's test LP and the client's test LP
`0xf491FA29debC0D12d8F7c57B17995C2346F025AD`. The rail is not finalized: the governor and the Entrypoint's
`OWNER_ROLE` are still the deployer's.

## Every contract on Sepolia, against the frozen source

**The final rail (20 October 2026)** (`deployments/sepolia-movva-final-rail/`)

| Contract | Address | Matches the frozen source | Note |
|---|---|---|---|
| ERC1967Proxy | [`0x73f7f0DF3D2D99014B0ef66441254b6428069CBd`](https://sepolia.etherscan.io/address/0x73f7f0DF3D2D99014B0ef66441254b6428069CBd#code) | yes, byte for byte |  |
| Entrypoint | [`0x639C9134b89b2C11d0727C28c9485b4e08D02015`](https://sepolia.etherscan.io/address/0x639C9134b89b2C11d0727C28c9485b4e08D02015#code) | yes, byte for byte |  |
| WithdrawalVerifier | [`0x9911c1AD91E8e858a1575355D018B9865F0Bb169`](https://sepolia.etherscan.io/address/0x9911c1AD91E8e858a1575355D018B9865F0Bb169#code) | yes, byte for byte |  |
| CommitmentVerifier | [`0x68f98d2F64B90bA37FfC6bEda67285c7450b8bbC`](https://sepolia.etherscan.io/address/0x68f98d2F64B90bA37FfC6bEda67285c7450b8bbC#code) | yes, byte for byte |  |
| PrivacyPoolSimple | [`0xaFB7928bd0D9a0EFbe1b190100404f5860C972d7`](https://sepolia.etherscan.io/address/0xaFB7928bd0D9a0EFbe1b190100404f5860C972d7#code) | yes, byte for byte |  |
| PoseidonT3 | [`0x8ffdA7Ed8B4aD98C2C34f54B76821711F4a6f2C5`](https://sepolia.etherscan.io/address/0x8ffdA7Ed8B4aD98C2C34f54B76821711F4a6f2C5#code) | **no** | Pre-existing public library the pools link to. This script reads the protocol build's artifact; the deployment record recompiles the library's own verify-contract input and matches it exactly (`deployments/sepolia-movva-final-rail/VERIFICATION.md`). |
| PoseidonT4 | [`0xe393dd7287Db9982e6f845824854Baf8b8e823AF`](https://sepolia.etherscan.io/address/0xe393dd7287Db9982e6f845824854Baf8b8e823AF#code) | **no** | As PoseidonT3. |
| TetherLike | [`0x964b674998B95077A7411939508Eb1b44c49006a`](https://sepolia.etherscan.io/address/0x964b674998B95077A7411939508Eb1b44c49006a#code) | yes, byte for byte |  |
| MovvaReserve | [`0xb7a8bb1cBD2348c5d27546058d2fb3435cCd11B6`](https://sepolia.etherscan.io/address/0xb7a8bb1cBD2348c5d27546058d2fb3435cCd11B6#code) | yes, byte for byte |  |
| Movva | [`0x22E1e640752eB91461566B70e6D8099583588f04`](https://sepolia.etherscan.io/address/0x22E1e640752eB91461566B70e6D8099583588f04#code) | yes, byte for byte |  |
| PythFxOracle | [`0xa2D3eD9D27eb2dD85d654DF2930beC35DA6408Dc`](https://sepolia.etherscan.io/address/0xa2D3eD9D27eb2dD85d654DF2930beC35DA6408Dc#code) | yes, byte for byte |  |
| ScaledFxBandOracle | [`0x903EadfB122b93F93410BF365BFD6580592bb752`](https://sepolia.etherscan.io/address/0x903EadfB122b93F93410BF365BFD6580592bb752#code) | yes, byte for byte |  |
| FeeSplitter | [`0xd9CDC14b8eF222fb6da29Be38f5b5aeC535f94Fc`](https://sepolia.etherscan.io/address/0xd9CDC14b8eF222fb6da29Be38f5b5aeC535f94Fc#code) | yes, byte for byte |  |
| NodeRewards | [`0x28eCd6562C4CdD6B45Aa41e863a2621e27f5E70d`](https://sepolia.etherscan.io/address/0x28eCd6562C4CdD6B45Aa41e863a2621e27f5E70d#code) | yes, byte for byte |  |
| PrivacyPoolComplex | [`0x026Ec9F01973F219Ecc30148209e1FFb9C995DDa`](https://sepolia.etherscan.io/address/0x026Ec9F01973F219Ecc30148209e1FFb9C995DDa#code) | yes, byte for byte |  |
| AspRootQuorum | [`0xBb7098C0465455e3C2074894Ddc6c475496909af`](https://sepolia.etherscan.io/address/0xBb7098C0465455e3C2074894Ddc6c475496909af#code) | yes, byte for byte |  |
| LPRegistry | [`0x3C7f5f7dDF970af011f549C67C50BB7d14670248`](https://sepolia.etherscan.io/address/0x3C7f5f7dDF970af011f549C67C50BB7d14670248#code) | yes, byte for byte |  |
| ReclaimZkTlsVerifier | [`0x9970AF29DDFc335ad337eBF4eAe9f01800845712`](https://sepolia.etherscan.io/address/0x9970AF29DDFc335ad337eBF4eAe9f01800845712#code) | yes, byte for byte |  |
| FiatEscrow | [`0xA61613d65fD6F7cb5B59BcA2f59E649d55386e09`](https://sepolia.etherscan.io/address/0xA61613d65fD6F7cb5B59BcA2f59E649d55386e09#code) | yes, byte for byte |  |
| OffRampEscrow | [`0xaff85ba17C001a7aE3A806AE5fE143dD17a47892`](https://sepolia.etherscan.io/address/0xaff85ba17C001a7aE3A806AE5fE143dD17a47892#code) | yes, byte for byte |  |

**The hedge sleeve on the final reserve (20 October 2026)** (`deployments/sepolia-final-hedge-sleeve/`)

| Contract | Address | Matches the frozen source | Note |
|---|---|---|---|
| SimHedgeVenue | [`0x0956f02fb0d74795f33d0ff68b063b727474b33b`](https://sepolia.etherscan.io/address/0x0956f02fb0d74795f33d0ff68b063b727474b33b#code) | yes, byte for byte |  |
| HedgeSubWallet | [`0x0121fe4ca2f134d0246d65d9b5a9073bd7eb58a1`](https://sepolia.etherscan.io/address/0x0121fe4ca2f134d0246d65d9b5a9073bd7eb58a1#code) | yes, byte for byte |  |

**The corrected FrostValidator (20 October 2026)** (`deployments/sepolia-account-stack-frost-v2/`)

| Contract | Address | Matches the frozen source | Note |
|---|---|---|---|
| FrostValidator | [`0xBb6Bb2779FAd749F87342d7E471513272c901158`](https://sepolia.etherscan.io/address/0xBb6Bb2779FAd749F87342d7E471513272c901158#code) | yes, byte for byte |  |

**The account stack (14 October 2026)** (`deployments/sepolia-account-stack/`)

| Contract | Address | Matches the frozen source | Note |
|---|---|---|---|
| PasskeyCoSignerValidator | [`0x7Ecc6B0edF79CACC4DaB559830111cC1c8702990`](https://sepolia.etherscan.io/address/0x7Ecc6B0edF79CACC4DaB559830111cC1c8702990#code) | yes, byte for byte |  |
| FrostValidator | [`0x58997113b2572F9Bc6ca243a0Ffff0C1924AB223`](https://sepolia.etherscan.io/address/0x58997113b2572F9Bc6ca243a0Ffff0C1924AB223#code) | **no** | Superseded by the corrected FrostValidator above (SRM1-21); new accounts use that one. |
| KernelAvatarAdapter | [`0x8214602c7991b48dEa1A5Cd58b06dCCF7840fAb0`](https://sepolia.etherscan.io/address/0x8214602c7991b48dEa1A5Cd58b06dCCF7840fAb0#code) | yes, byte for byte |  |
| OwnerlessPaymaster | [`0x98a488006bB816a03930Edfec76Fda95a8ee069d`](https://sepolia.etherscan.io/address/0x98a488006bB816a03930Edfec76Fda95a8ee069d#code) | yes (code; metadata differs: comments) | Kept: its code is the frozen code; redeploying it would lock another 1 ETH stake for nothing. |
| AuditGrantRegistry | [`0x8BcCa7574d7A87Ea225DFB4ab1Ced6947e33414A`](https://sepolia.etherscan.io/address/0x8BcCa7574d7A87Ea225DFB4ab1Ced6947e33414A#code) | yes, byte for byte |  |
| ShieldedNoteLog | [`0x9eE65d4b3B55A545721138B814d1227e7DFdB1a5`](https://sepolia.etherscan.io/address/0x9eE65d4b3B55A545721138B814d1227e7DFdB1a5#code) | yes, byte for byte |  |
## The earlier rails

The rails of 6 October and 15 October (`deployments/sepolia-movva-only-rail.json`, with the escrow pair of
19 October, `deployments/sepolia-movva-only-escrows-v2.json`) and their hedge sleeve are superseded and kept as
records. Their `MovvaReserve`, `AspRootQuorum` and old escrow pair predate fixes in the frozen source. `MOVVA`'s minter
is immutable, so the corrected reserve could only reach Sepolia as a new rail.
