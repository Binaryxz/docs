/**
 * The co-signer: the server half of the account's 2-of-2, and nothing more.
 *
 * THE RULE. No signature - ECDSA co-signature or FROST signature share - leaves this service unless, in the
 * same request, a user-verified passkey assertion verifies over the exact digest the service is about to
 * sign, for the passkey the account itself trusts. The digest is recomputed here from the operation (or the
 * typed data); nothing a request calls a hash is ever signed. So a request without the user, or with the
 * user's signature over anything else, gets a refusal - and the veto is no exception: the server never
 * vetoes alone (docs/wallet-custody.md §6, "the trade that is not made").
 *
 * THE ORDER, for every signing route:
 *
 *   1. shape, chain, enrolment                      malformed / wrong_chain / not_enrolled / wrong_account_kind
 *   2. the digest, recomputed                       (from userOp + window, or typed data)
 *   3. the passkey over that digest                 passkey_required / bad_passkey_signature
 *   4. idempotency: this digest was co-signed       -> the same answer again (reused), counted once
 *   5. per-account rate limit                       rate_limited (after 3, so a stranger cannot empty it)
 *   6. the account is still what was enrolled       enrolment_stale / not_deployed
 *   7. window and nonce                             window_unbounded / expired / window_too_long / replayed
 *   8. policy (co-sign) or the veto rule (veto)     policy.ts codes / not_a_veto / nothing_to_veto / ...
 *   9. daily limits                                 daily_limit_exceeded
 *  10. audit record, fsynced                        then, and only then, the signature
 *
 * FROST sessions are single-use at this layer as well as in packages/mpc: a session is removed from the table
 * before anything is checked, so a refused or failed request burns its nonces and the device commits again.
 *
 * KEY GENERATION (`dkg.ts`) is the one route family with no account behind it: a FROST account's address
 * commits to the group key the run is about to make, so `dkgStart`/`dkgRound2`/`dkgConfirm` are keyed by the
 * passkey's signer address and authorised by two assertions - one over the run, one over the key it
 * produced. The share a run makes is stored unusable until that second assertion arrives.
 */
import {
  getAddress, hashTypedData, hexToBytes, isAddress, isHex, size, toHex,
  type Address, type Hex,
} from 'viem';
import {
  encodeKernelErc1271Signature, encodeKernelUserOpSignature, encodePasskeyCoSignerSignature, encodeSafeSignatures,
  kernelWrappedHash,
} from '@mova/smart-account';
import { safeMessageHash } from '@mova/wallet/src/executor.js';
import { randomBytes } from '@noble/hashes/utils';
import { Point, commit, sign as frostSign, type Commitment, type KeyShare, type Nonces } from '@mova/mpc';
import { passkeyId, type AuditLog, type DecisionRecord, type DkgRecord, type Enrolment, type Route } from './audit.js';
import type { AccountReader, DelayQueue } from './chain.js';
import {
  DEFAULT_ALLOWED_VERIFIERS, ENROLMENT_TYPEHASH, enrolmentChallenge, resolveBinding, sameBinding,
  type Binding, type DeploymentAddresses, type EnrolRequest,
} from './enrolment.js';
import { DkgRefusal, FrostDkg, dkgAccountRef } from './dkg.js';
import {
  dkgConfirmChallenge, dkgStartChallenge,
  type DkgConfirmRequest, type DkgConfirmResult, type DkgRound2Request, type DkgRound2Result,
  type DkgStartRequest, type DkgStartResult,
} from './dkg-proof.js';
import { isFrostShareWriter, type FrostShareStore } from './frost-shares.js';
import type { CoSignerKey } from './key.js';
import { CoSignerMetrics } from './metrics.js';
import {
  decodeKernelCallData, decodeSafeCallData, kernelOperationDigest, safeOperationDigest, userOpFromWire, windowFromWire,
  type DecodedCall, type UnsignedUserOp, type ValidityWindow,
} from './operation.js';
import {
  checkWindow, evaluateCalls, evaluateMessage, evaluateVeto, summarise,
  type Policy, type PolicyAccount, type PolicyVerdict, type Spend, type TypedDataInput,
} from './policy.js';
import { RateLimiter } from './rate-limit.js';
import type { AlertSubscribeRequest, AlertUnsubscribeRequest, RecoveryAlerts } from './recovery-alerts.js';
import { Refusal, type RefusalCode } from './refusal.js';
import type { SponsorshipModule, SponsorshipView } from './sponsorship.js';
import { verifyWebAuthnSignature } from './webauthn.js';

export interface Logger {
  info(message: string): void;
  warn(message: string): void;
  error(message: string): void;
}

const silent: Logger = { info: () => {}, warn: () => {}, error: () => {} };

export interface CoSignerServiceOptions {
  chainId: number;
  key: CoSignerKey;
  frostShares?: FrostShareStore;
  chain: AccountReader;
  policy: Policy;
  deployment: DeploymentAddresses;
  audit: AuditLog;
  /** Unix seconds, wall clock: enrolment proofs and the audit log. Windows are checked against the chain's head. */
  now?: () => bigint;
  /** Milliseconds, for rate limits and FROST session expiry. */
  nowMs?: () => number;
  enrolmentMaxSkewSeconds?: number;
  frostSessionSeconds?: number;
  maxFrostSessionsPerAccount?: number;
  /** How long one distributed key generation may stay open. Default 300 s (dkg.ts). */
  dkgSessionSeconds?: number;
  /** Key generations open at once, across every account. Default 32. */
  maxDkgSessions?: number;
  /** How long a check of the account's on-chain signers is reused. Default 15 s. */
  bindingCacheMs?: number;
  allowedVerifiers?: readonly bigint[];
  /**
   * Readies each enrolled account for its first sponsored operation from its own operator key (sponsorship.ts): through
   * SponsorGate, or for an OwnerlessPaymaster by creating the passkey signer or Kernel account alone. Optional.
   */
  sponsorship?: SponsorshipModule;
  /** Recovery alerts: the subscription routes (recovery-alerts.ts). The watcher runs beside the service. Optional. */
  alerts?: RecoveryAlerts;
  /** Shared with the sponsorship module and the recovery watcher, so /metrics shows all of them. Default: a new set. */
  metrics?: CoSignerMetrics;
  log?: Logger;
}

export interface Caller {
  /** The API client's name, or 'anonymous' on a public API. */
  client: string;
}

export type SigningKind = 'safe-operation' | 'kernel-operation' | 'safe-message' | 'kernel-message';

export interface SigningPayload {
  chainId: number;
  account: Address;
  kind: SigningKind;
  userOp?: UnsignedUserOp;
  window?: ValidityWindow;
  typedData?: TypedDataInput;
  passkeySignature: Hex;
  requestId?: string;
}

export interface CosignResult {
  digest: Hex;
  coSigner: Address;
  coSignature: Hex;
  /** The whole signature the account checks: `userOp.signature`, or the ERC-1271 bytes. */
  signature: Hex;
  reused: boolean;
}

export interface FrostCommitResult {
  sessionId: Hex;
  commitment: { id: number; hiding: Hex; binding: Hex };
  expiresAt: number;
}

export interface FrostSignRequest extends SigningPayload {
  sessionId: Hex;
  route: 'cosign' | 'veto';
  commitments: Commitment[];
}

export interface FrostSignResult {
  digest: Hex;
  share: { id: number; z: Hex };
  reused: boolean;
}

export interface QueueView extends DelayQueue {
  account: Address;
  /** The `setTxNonce` argument that vetoes everything queued now; undefined when nothing is. */
  vetoNonce?: bigint;
}

interface FrostSession {
  account: string;
  share: KeyShare;
  nonces: Nonces;
  commitment: Commitment;
  expiresAtMs: number;
}

const same = (a: Address | undefined, b: Address | undefined) => !!a && !!b && a.toLowerCase() === b.toLowerCase();
const accountKey = (chainId: number, account: Address) => `${chainId}:${account.toLowerCase()}`;
/** Refusals about the request's shape or an unknown account: counted, never written to the audit log. */
const UNAUDITED: ReadonlySet<RefusalCode> = new Set(['malformed', 'wrong_chain', 'not_enrolled', 'not_ready', 'rate_limited']);

export class CoSignerService {
  ready = false;
  readonly metrics: CoSignerMetrics;
  private readonly accountLimiter: RateLimiter;
  private readonly sessions = new Map<string, FrostSession>();
  /** Present when the share store can be written to: this service then generates keys with devices. */
  private readonly dkg?: FrostDkg;
  private readonly bindingChecked = new Map<string, number>();
  private readonly log: Logger;

  constructor(private readonly o: CoSignerServiceOptions) {
    this.metrics = o.metrics ?? new CoSignerMetrics();
    this.log = o.log ?? silent;
    this.accountLimiter = new RateLimiter({ ...o.policy.rateLimit, now: o.nowMs });
    this.dkg = isFrostShareWriter(o.frostShares)
      ? new FrostDkg({
        chainId: o.chainId, key: o.key, shares: o.frostShares, sessionSeconds: o.dkgSessionSeconds,
        maxSessions: o.maxDkgSessions, nowMs: o.nowMs, now: o.now,
      })
      : undefined;
    this.metrics.set('mova_cosigner_enrolments', o.audit.enrolled);
    this.metrics.set('mova_cosigner_audit_records', o.audit.records);
  }

  get address(): Address {
    return this.o.key.address;
  }

  private now(): bigint {
    return this.o.now ? this.o.now() : BigInt(Math.floor(Date.now() / 1000));
  }

  private nowMs(): number {
    return this.o.nowMs ? this.o.nowMs() : Date.now();
  }

  /** Public description: addresses, policy and limits. No key material, no account data. */
  info() {
    const p = this.o.policy;
    return {
      service: 'mova-cosigner',
      chainId: this.o.chainId,
      coSigner: this.address,
      custody: this.o.key.custody,
      frost: this.o.frostShares ? { custody: this.o.frostShares.custody, dkg: !!this.dkg } : null,
      entryPoint: this.o.deployment.entryPoint,
      deployment: this.o.deployment,
      enrolmentTypehash: ENROLMENT_TYPEHASH,
      policy: {
        targets: p.targets, tokens: p.tokens, nativeDailyLimit: p.nativeDailyLimit ?? null, rotationCoSigners: p.rotationCoSigners,
        maxValiditySeconds: p.maxValiditySeconds, vetoMaxValiditySeconds: p.vetoMaxValiditySeconds, rateLimit: p.rateLimit,
        webauthn: p.webauthn,
      },
      sponsorship: this.o.sponsorship ? {
        gate: this.o.sponsorship.gate ?? null, ownerlessPaymaster: this.o.sponsorship.ownerlessPaymaster ?? null,
        operator: this.o.sponsorship.operator, dailyCap: this.o.sponsorship.dailyCap,
      } : null,
      alerts: this.o.alerts ? this.o.alerts.info() : null,
    };
  }

  status() {
    return {
      ready: this.ready, chainId: this.o.chainId, coSigner: this.address, custody: this.o.key.custody,
      enrolments: this.o.audit.enrolled, auditRecords: this.o.audit.records, frostSessionsOpen: this.sessions.size,
      dkgSessionsOpen: this.dkg?.open ?? 0,
      sponsorship: !!this.o.sponsorship, alerts: !!this.o.alerts,
    };
  }

  private bindingContext() {
    return {
      chain: this.o.chain, coSigner: this.address, deployment: this.o.deployment, frostShares: this.o.frostShares,
      allowedVerifiers: this.o.allowedVerifiers ?? DEFAULT_ALLOWED_VERIFIERS,
    };
  }

  /* ------------------------------------------------------------------ enrolment */

  async enrol(req: EnrolRequest, caller: Caller): Promise<{ enrolment: Enrolment; created: boolean; sponsorship?: SponsorshipView }> {
    const route: Route = 'enrol';
    try {
      this.assertReady(req.chainId);
      const skew = BigInt(this.o.enrolmentMaxSkewSeconds ?? 300);
      const issuedAt = BigInt(req.issuedAt);
      const now = this.now();
      if (issuedAt > now + skew || issuedAt < now - skew) {
        throw new Refusal('enrolment_expired', `the enrolment proof must be issued within ${skew} seconds of now`);
      }
      const binding = await resolveBinding(this.bindingContext(), req);
      this.assertDkgBinding(binding);
      this.verifyPasskey(binding, enrolmentChallenge(req.chainId, binding.account, this.address, req.issuedAt), req.passkeySignature);
      if (!this.accountLimiter.take(accountKey(req.chainId, binding.account))) throw new Refusal('rate_limited', 'too many requests for this account');
      const existing = this.o.audit.enrolment(req.chainId, binding.account);
      if (existing && sameBinding(existing, binding)) {
        this.count(route, 'served');
        return { enrolment: existing, created: false, ...(await this.sponsor(existing, caller)) };
      }
      const head = await this.o.chain.head();
      const enrolment: Enrolment = { ...binding, fromBlock: head.number, enrolledAt: now };
      this.o.audit.append({ t: 'enrol', at: now, client: caller.client, enrolment });
      this.bindingChecked.delete(accountKey(req.chainId, binding.account));
      this.metrics.set('mova_cosigner_enrolments', this.o.audit.enrolled);
      this.metrics.set('mova_cosigner_audit_records', this.o.audit.records);
      this.count(route, 'enrolled');
      this.log.info(`enrolled ${binding.kind} ${binding.account} on chain ${req.chainId}${existing ? ' (replacing a stale enrolment)' : ''}`);
      return { enrolment, created: true, ...(await this.sponsor(enrolment, caller)) };
    } catch (e) {
      throw this.refused(e, route);
    }
  }

  /**
   * After a verified enrolment: ask the sponsorship module to sponsor the account. Its answer rides along with the
   * enrolment's; a failure there never undoes the enrolment.
   */
  private async sponsor(e: Enrolment, caller: Caller): Promise<{ sponsorship?: SponsorshipView }> {
    if (!this.o.sponsorship) return {};
    try {
      return { sponsorship: await this.o.sponsorship.request(e, caller) };
    } catch (err) {
      this.log.error(`sponsorship of ${e.account}: ${err instanceof Error ? err.message : String(err)}`);
      return { sponsorship: { chainId: e.chainId, account: e.account, status: 'failed', code: 'chain_unavailable', retryable: true, message: 'sponsorship could not be requested' } };
    }
  }

  /** The account's sponsorship as this service knows it. */
  async sponsorship(req: { chainId: number; account: Address }, caller: Caller): Promise<SponsorshipView> {
    try {
      this.assertReady(req.chainId);
      if (!this.o.sponsorship) throw new Refusal('sponsorship_disabled', 'this co-signer does not sponsor accounts');
      const e = this.enrolmentFor(req);
      this.count('sponsorship', 'served');
      void caller;
      return this.o.sponsorship.view(e.chainId, e.account);
    } catch (err) {
      throw this.refused(err, 'sponsorship');
    }
  }

  /* ------------------------------------------------------------------ recovery alerts */

  async subscribeAlerts(req: AlertSubscribeRequest, caller: Caller): Promise<{ subscribed: true; created: boolean; pending: number }> {
    try {
      this.assertReady(req.chainId);
      if (!this.o.alerts) throw new Refusal('alerts_disabled', 'this co-signer does not send recovery alerts');
      const r = await this.o.alerts.subscribe(req, this.enrolmentFor(req), caller);
      this.count('alerts-subscribe', 'served');
      return r;
    } catch (err) {
      throw this.refused(err, 'alerts-subscribe');
    }
  }

  async unsubscribeAlerts(req: AlertUnsubscribeRequest, caller: Caller): Promise<{ unsubscribed: true }> {
    try {
      this.assertReady(req.chainId);
      if (!this.o.alerts) throw new Refusal('alerts_disabled', 'this co-signer does not send recovery alerts');
      const r = await this.o.alerts.unsubscribe(req, this.enrolmentFor(req), caller);
      this.count('alerts-unsubscribe', 'served');
      return r;
    } catch (err) {
      throw this.refused(err, 'alerts-unsubscribe');
    }
  }

  /* ------------------------------------------------------------------ co-signing */

  /** Co-sign an operation or an ERC-1271 message for a passkey + co-signer account. */
  cosign(req: SigningPayload, caller: Caller): Promise<CosignResult> {
    return this.ecdsa('cosign', req, caller);
  }

  /** Co-sign the owners' veto of queued recovery transactions: `setTxNonce`, alone, with a fresh passkey signature. */
  veto(req: SigningPayload, caller: Caller): Promise<CosignResult> {
    return this.ecdsa('veto', req, caller);
  }

  private async ecdsa(route: 'cosign' | 'veto', req: SigningPayload, caller: Caller): Promise<CosignResult> {
    let enrolment: Enrolment | undefined;
    let digest: Hex | undefined;
    try {
      this.assertReady(req.chainId);
      enrolment = this.enrolmentFor(req);
      if (enrolment.kind.endsWith('frost')) throw new Refusal('wrong_account_kind', 'a FROST account signs through /v1/frost/commit and /v1/frost/sign');
      digest = this.digestOf(enrolment, req);
      const checked = await this.checkSigning(route, enrolment, req, digest, caller);
      const coSignature = await this.o.key.signDigest(digest);
      const signature = this.assemble(enrolment, req, coSignature);
      this.metrics.inc('mova_cosigner_signatures_total', { kind: enrolment.kind });
      this.count(route, checked.reused ? 'reused' : 'signed');
      return { digest, coSigner: this.address, coSignature, signature, reused: checked.reused };
    } catch (e) {
      throw this.refused(e, route, enrolment, digest, req, caller);
    }
  }

  /** Steps 3-10 of the header, shared by the ECDSA and FROST routes. Returns after the audit record is durable. */
  private async checkSigning(route: 'cosign' | 'veto', e: Enrolment, req: SigningPayload, digest: Hex, caller: Caller): Promise<{ reused: boolean }> {
    const isMessage = req.kind.endsWith('message');
    if (route === 'veto' && isMessage) throw new Refusal('not_a_veto', 'a veto is an operation, not a message');
    this.verifyPasskey(e, digest, req.passkeySignature);

    const deployed = await this.o.chain.hasCode(e.account);
    let verdict: PolicyVerdict | undefined;
    let calls: DecodedCall[] | undefined;
    const prior = this.o.audit.signedFor(digest);

    if (!prior && !this.accountLimiter.take(accountKey(e.chainId, e.account))) throw new Refusal('rate_limited', 'too many requests for this account');
    await this.assertBinding(e, deployed);
    const pa = this.policyAccount(e, deployed && await this.o.chain.hasCode(e.delay));

    if (!isMessage) {
      const op = req.userOp!;
      const w = req.window!;
      const head = await this.o.chain.head();
      checkWindow(w, head.timestamp, route === 'veto' ? this.o.policy.vetoMaxValiditySeconds : this.o.policy.maxValiditySeconds);
      const key = op.nonce >> 64n;
      if (e.kind.startsWith('kernel') && key !== 0n) throw new Refusal('unsupported_validator', 'only operations for the account\'s root validator (nonce key 0) are co-signed');
      if (deployed) {
        if (op.initCode !== '0x') throw new Refusal('replayed', 'the account already exists: this operation would deploy it again');
        const current = await this.o.chain.entryPointNonce(e.account, key);
        if (op.nonce < current) throw new Refusal('replayed', 'the operation\'s nonce has already been used');
      } else if (op.initCode === '0x') {
        throw new Refusal('not_deployed', 'the account does not exist and the operation does not deploy it');
      }
      calls = e.kind.startsWith('safe') ? decodeSafeCallData(op.callData) : decodeKernelCallData(op.callData);
      if (route === 'veto') {
        const view = await this.o.chain.delay(e.delay);
        if (!view || !same(view.owner, e.account)) throw new Refusal('no_recovery_module', 'the account has no recovery Delay to veto on');
        evaluateVeto(pa, calls, view);
      } else {
        verdict = evaluateCalls(this.o.policy, pa, calls);
      }
    } else {
      evaluateMessage(this.o.policy, this.o.chainId, pa, req.typedData!);
    }

    if (prior) {
      this.audit({ route, e, req, digest, caller, decision: 'reused', calls });
      return { reused: true };
    }
    const spend = verdict?.spend ?? [];
    this.checkLimits(e, spend);
    this.audit({ route, e, req, digest, caller, decision: 'signed', calls, spend, flow: verdict?.flow ?? (route === 'veto' ? 'veto' : isMessage ? 'message' : undefined) });
    return { reused: false };
  }

  private checkLimits(e: Enrolment, spend: readonly Spend[]): void {
    for (const s of spend) {
      const limit = s.asset === 'native' ? this.o.policy.nativeDailyLimit : this.o.policy.tokens.find((t) => same(t.address, s.asset as Address))?.dailyLimit;
      if (limit === undefined) continue;
      const already = this.o.audit.spentToday(e.chainId, e.account, s.asset);
      if (already + s.amount > limit) {
        const label = s.asset === 'native' ? 'native value' : this.o.policy.tokens.find((t) => same(t.address, s.asset as Address))?.label;
        throw new Refusal('daily_limit_exceeded', `this operation would take the account past its 24-hour limit for ${label}`);
      }
    }
  }

  /* ------------------------------------------------------------------ FROST */

  async frostCommit(req: { chainId: number; account: Address }, caller: Caller): Promise<FrostCommitResult> {
    const route: Route = 'frost-commit';
    let enrolment: Enrolment | undefined;
    try {
      this.assertReady(req.chainId);
      enrolment = this.enrolmentFor(req);
      if (!enrolment.kind.endsWith('frost') || !enrolment.groupKey) throw new Refusal('wrong_account_kind', 'this account is not a FROST account');
      const share = this.o.frostShares?.shareFor(Point.fromBytes(hexToBytes(enrolment.groupKey)));
      if (!share) throw new Refusal('no_share', 'this service holds no FROST share of the account\'s group key');
      this.pruneSessions();
      const key = accountKey(req.chainId, enrolment.account);
      const open = [...this.sessions.values()].filter((s) => s.account === key).length;
      if (open >= (this.o.maxFrostSessionsPerAccount ?? 4)) throw new Refusal('rate_limited', 'too many open FROST sessions for this account');
      const { nonces, commitment } = commit(share);
      const sessionId = toHex(randomBytes(32));
      const expiresAtMs = this.nowMs() + (this.o.frostSessionSeconds ?? 120) * 1000;
      this.sessions.set(sessionId, { account: key, share, nonces, commitment, expiresAtMs });
      this.metrics.set('mova_cosigner_frost_sessions_open', this.sessions.size);
      this.count(route, 'served');
      void caller;
      return {
        sessionId, expiresAt: Math.floor(expiresAtMs / 1000),
        commitment: { id: commitment.id, hiding: toHex(commitment.hiding.toBytes(true)), binding: toHex(commitment.binding.toBytes(true)) },
      };
    } catch (e) {
      throw this.refused(e, route);
    }
  }

  async frostSign(req: FrostSignRequest, caller: Caller): Promise<FrostSignResult> {
    const route: Route = 'frost-sign';
    // Single use before anything else: whatever happens below, this session's nonces never sign twice.
    const session = this.sessions.get(req.sessionId.toLowerCase());
    this.sessions.delete(req.sessionId.toLowerCase());
    this.metrics.set('mova_cosigner_frost_sessions_open', this.sessions.size);
    let enrolment: Enrolment | undefined;
    let digest: Hex | undefined;
    try {
      this.assertReady(req.chainId);
      enrolment = this.enrolmentFor(req);
      if (!session || session.expiresAtMs < this.nowMs() || session.account !== accountKey(req.chainId, enrolment.account)) {
        throw new Refusal('session_unknown', 'no open FROST session with that id for this account: commit again');
      }
      if (!enrolment.kind.endsWith('frost')) throw new Refusal('wrong_account_kind', 'this account is not a FROST account');
      this.checkCommitments(session, req.commitments);
      digest = this.digestOf(enrolment, req);
      const checked = await this.checkSigning(req.route, enrolment, req, digest, caller);
      let z: bigint;
      try {
        z = frostSign(session.share, session.nonces, req.commitments, hexToBytes(digest)).z;
      } catch {
        throw new Refusal('frost_invalid', 'the commitment list was refused by the signer');
      }
      this.metrics.inc('mova_cosigner_signatures_total', { kind: enrolment.kind });
      this.count(route, checked.reused ? 'reused' : 'signed');
      return { digest, share: { id: session.share.id, z: toHex(z, { size: 32 }) }, reused: checked.reused };
    } catch (e) {
      throw this.refused(e, route, enrolment, digest, req, caller);
    }
  }

  /** RFC 9591 §5.2's checks, before the audit record: two distinct positive ids, this party's own commitment unchanged. */
  private checkCommitments(session: FrostSession, list: readonly Commitment[]): void {
    if (list.length !== 2) throw new Refusal('frost_invalid', 'a 2-of-2 session has exactly two commitments');
    const ids = list.map((c) => c.id);
    if (new Set(ids).size !== 2 || ids.some((id) => !Number.isSafeInteger(id) || id < 1)) throw new Refusal('frost_invalid', 'commitment ids must be distinct positive integers');
    if (list.some((c) => c.hiding.is0() || c.binding.is0())) throw new Refusal('frost_invalid', 'a commitment is the identity point');
    const own = list.find((c) => c.id === session.share.id);
    if (!own || !own.hiding.equals(session.commitment.hiding) || !own.binding.equals(session.commitment.binding)) {
      throw new Refusal('frost_invalid', 'the list does not carry this service\'s own commitment unchanged');
    }
  }

  private pruneSessions(): void {
    const now = this.nowMs();
    for (const [id, s] of this.sessions) if (s.expiresAtMs < now) this.sessions.delete(id);
    this.metrics.set('mova_cosigner_frost_sessions_open', this.sessions.size);
  }

  /* ------------------------------------------------------------------ distributed key generation */

  /**
   * Round 1 of a key generation with one device (dkg.ts): the device's broadcast in, this service's out.
   *
   * There is no account yet - a FROST account's address commits to the group key this run is about to
   * produce - so the subject is the passkey: its SafeWebAuthnSigner address is the account reference the run
   * is keyed by, and exactly what enrolment will later read back as the account's recovery signer. The user
   * authorises the run with one assertion over `dkgStartChallenge`, which binds the chain, this service, the
   * passkey, the device's per-run signing key and the context the session id derives from.
   */
  async dkgStart(req: DkgStartRequest, caller: Caller): Promise<DkgStartResult> {
    const route: Route = 'frost-dkg-start';
    let accountRef: string | undefined;
    let fingerprint: Hex | undefined;
    try {
      this.assertReady(req.chainId);
      const dkg = this.requireDkg();
      if (!(this.o.allowedVerifiers ?? DEFAULT_ALLOWED_VERIFIERS).includes(req.passkey.verifiers)) {
        throw new Refusal('not_a_cosigner', 'that passkey uses a P-256 verifier this service does not accept');
      }
      const skew = BigInt(this.o.enrolmentMaxSkewSeconds ?? 300);
      const issuedAt = BigInt(req.issuedAt);
      const now = this.now();
      if (issuedAt > now + skew || issuedAt < now - skew) {
        throw new Refusal('enrolment_expired', `the key generation proof must be issued within ${skew} seconds of now`);
      }
      accountRef = dkgAccountRef(req.chainId, await this.o.chain.webAuthnSignerAddress(req.passkey));
      fingerprint = passkeyId(req.passkey);
      this.verifyPasskey({ passkey: req.passkey }, dkgStartChallenge({
        chainId: req.chainId, coSigner: this.address, passkey: req.passkey,
        deviceKey: req.deviceKey, context: req.context, issuedAt: req.issuedAt,
      }), req.passkeySignature);
      if (!this.accountLimiter.take(accountRef)) throw new Refusal('rate_limited', 'too many requests for this account');
      const r = await dkg.begin(req, { accountRef, passkeyId: fingerprint });
      this.auditDkg({ client: caller.client, chainId: req.chainId, accountRef, passkeyId: fingerprint, session: r.sessionId, event: 'started' });
      this.metrics.set('mova_cosigner_dkg_sessions_open', dkg.open);
      this.count(route, 'served');
      return r;
    } catch (e) {
      throw this.refusedDkg(e, route, req.chainId, accountRef, fingerprint, caller);
    }
  }

  /**
   * Round 2: the device's sealed share in, this service's out, with the group key it derived. The share is
   * stored PENDING - it cannot sign until the device confirms the same key in round 3.
   */
  async dkgRound2(req: DkgRound2Request, caller: Caller): Promise<DkgRound2Result> {
    const route: Route = 'frost-dkg-round2';
    let run;
    try {
      this.assertReady(req.chainId);
      const dkg = this.requireDkg();
      run = dkg.describe(req.sessionId);
      if (!run || run.stage !== 'round1') throw new Refusal('session_unknown', 'no key generation is open at round 2 with that id: start again');
      if (!this.accountLimiter.take(run.accountRef)) throw new Refusal('rate_limited', 'too many requests for this account');
      const r = await dkg.advance(req);
      const derived = dkg.describe(req.sessionId);
      this.auditDkg({
        client: caller.client, chainId: req.chainId, accountRef: run.accountRef, passkeyId: run.passkeyId,
        session: req.sessionId, event: 'round2', groupKey: derived?.groupKey, transcript: derived?.transcript,
      });
      this.metrics.set('mova_cosigner_dkg_sessions_open', dkg.open);
      this.count(route, 'served');
      return r;
    } catch (e) {
      throw this.refusedDkg(e, route, req.chainId, run?.accountRef, run?.passkeyId, caller, req.sessionId);
    }
  }

  /**
   * Round 3: the device's confirmation, and a second assertion over the group key and transcript. Only if
   * they equal this service's own does its share become one that can sign.
   */
  async dkgConfirm(req: DkgConfirmRequest, caller: Caller): Promise<DkgConfirmResult> {
    const route: Route = 'frost-dkg-confirm';
    let run;
    try {
      this.assertReady(req.chainId);
      const dkg = this.requireDkg();
      run = dkg.describe(req.sessionId);
      if (!run || run.stage !== 'finished' || !run.groupKey || !run.transcript) {
        throw new Refusal('session_unknown', 'no key generation is waiting for a confirmation with that id: start again');
      }
      this.verifyPasskey({ passkey: run.passkey }, dkgConfirmChallenge({
        chainId: req.chainId, coSigner: this.address, session: req.sessionId, groupKey: run.groupKey, transcript: run.transcript,
      }), req.passkeySignature);
      if (!this.accountLimiter.take(run.accountRef)) throw new Refusal('rate_limited', 'too many requests for this account');
      const r = await dkg.settle(req);
      this.auditDkg({
        client: caller.client, chainId: req.chainId, accountRef: run.accountRef, passkeyId: run.passkeyId,
        session: req.sessionId, event: 'completed', groupKey: r.groupKey, transcript: r.transcript,
      });
      this.metrics.inc('mova_cosigner_dkg_total', { result: 'completed' });
      this.metrics.set('mova_cosigner_dkg_sessions_open', dkg.open);
      this.count(route, 'served');
      this.log.info(`a FROST key generation completed for ${run.accountRef}: group key ${r.groupKey}`);
      return r;
    } catch (e) {
      throw this.refusedDkg(e, route, req.chainId, run?.accountRef, run?.passkeyId, caller, req.sessionId);
    }
  }

  private requireDkg(): FrostDkg {
    if (!this.dkg) {
      throw new Refusal('dkg_disabled', 'this co-signer does not generate FROST keys: its share store cannot be written to');
    }
    return this.dkg;
  }

  /** A group key this service generated belongs to the passkey its run was for, and to no other account. */
  private assertDkgBinding(b: Binding): void {
    const run = b.groupKey ? this.o.audit.dkgFor(b.groupKey) : undefined;
    if (run && run.accountRef !== dkgAccountRef(b.chainId, b.passkeySigner)) {
      throw new Refusal('dkg_invalid', 'this service generated that group key for a different passkey: the account\'s '
        + 'recovery signer is not the one the key generation was for');
    }
  }

  private auditDkg(r: Omit<DkgRecord, 't' | 'at'>): void {
    this.o.audit.append({ t: 'dkg', at: this.now(), ...r });
    this.metrics.set('mova_cosigner_audit_records', this.o.audit.records);
  }

  /** Count, audit (once the run's account reference is known) and return the refusal to throw. */
  private refusedDkg(e: unknown, route: Route, chainId: number, accountRef: string | undefined,
    fingerprint: Hex | undefined, caller: Caller, session?: Hex): Refusal {
    const refusal = this.refused(e, route);
    this.metrics.inc('mova_cosigner_dkg_total', { result: 'refused' });
    if (accountRef && !UNAUDITED.has(refusal.code)) {
      try {
        this.auditDkg({
          client: caller.client, chainId, accountRef, passkeyId: fingerprint, session, event: 'refused',
          code: refusal.code, party: e instanceof DkgRefusal ? e.party : undefined,
        });
      } catch (err) {
        this.log.error(`audit log append failed for a refusal: ${err instanceof Error ? err.message : String(err)}`);
      }
    }
    return refusal;
  }

  /* ------------------------------------------------------------------ the queue */

  async queue(req: { chainId: number; account: Address }, caller: Caller): Promise<QueueView> {
    try {
      this.assertReady(req.chainId);
      const e = this.enrolmentFor(req);
      const view = await this.o.chain.delay(e.delay);
      if (!view || !same(view.owner, e.account)) throw new Refusal('no_recovery_module', 'the account has no recovery Delay installed');
      const q = await this.o.chain.delayQueue(e.delay, e.fromBlock);
      this.count('queue', 'served');
      void caller;
      return { ...q, account: e.account, vetoNonce: q.queueNonce > q.txNonce ? q.queueNonce : undefined };
    } catch (err) {
      throw this.refused(err, 'queue');
    }
  }

  /* ------------------------------------------------------------------ pieces */

  private assertReady(chainId: number): void {
    if (!this.ready) throw new Refusal('not_ready', 'the co-signer has not finished its startup checks');
    if (chainId !== this.o.chainId) throw new Refusal('wrong_chain', `this co-signer serves chain ${this.o.chainId}`);
  }

  private enrolmentFor(req: { chainId: number; account: Address }): Enrolment {
    const e = this.o.audit.enrolment(req.chainId, req.account);
    if (!e) throw new Refusal('not_enrolled', 'the account is not enrolled with this co-signer');
    return e;
  }

  private digestOf(e: Enrolment, req: SigningPayload): Hex {
    const family = e.kind.startsWith('safe') ? 'safe' : 'kernel';
    if (!req.kind.startsWith(family)) throw new Refusal('wrong_account_kind', `the account is a ${family === 'safe' ? 'Safe' : 'Kernel account'}`);
    if (req.kind.endsWith('operation')) {
      if (!req.userOp || !req.window) throw new Refusal('malformed', 'an operation request carries userOp, validAfter and validUntil');
      if (!same(req.userOp.sender, e.account)) throw new Refusal('malformed', 'userOp.sender is not the account');
      return family === 'safe'
        ? safeOperationDigest(req.userOp, req.window, this.o.chainId)
        : kernelOperationDigest(req.userOp, req.window, this.o.chainId, e.validator!, this.o.deployment.entryPoint);
    }
    if (!req.typedData) throw new Refusal('malformed', 'a message request carries typedData');
    let hash: Hex;
    try {
      hash = hashTypedData(stripDomainType(req.typedData) as never);
    } catch {
      throw new Refusal('malformed', 'typedData does not hash as EIP-712');
    }
    return family === 'safe' ? safeMessageHash(e.account, this.o.chainId, hash) : kernelWrappedHash(e.account, this.o.chainId, hash);
  }

  private verifyPasskey(e: Pick<Binding, 'passkey'>, digest: Hex, passkeySignature: Hex): void {
    if (!passkeySignature || passkeySignature === '0x') {
      throw new Refusal('passkey_required', 'every co-signature needs the passkey\'s signature over the same digest: the server never signs alone');
    }
    const verdict = verifyWebAuthnSignature(digest, passkeySignature, e.passkey, this.o.policy.webauthn);
    if (!verdict.ok) throw new Refusal('bad_passkey_signature', verdict.reason);
  }

  /** The account's on-chain signers are still the enrolled ones. Undeployed accounts are bound by CREATE2 and need no re-check. */
  private async assertBinding(e: Enrolment, deployed: boolean): Promise<void> {
    if (!deployed) return;
    const key = accountKey(e.chainId, e.account);
    const at = this.bindingChecked.get(key);
    if (at !== undefined && this.nowMs() - at < (this.o.bindingCacheMs ?? 15_000)) return;
    let current: Binding;
    try {
      // A FROST account names its passkey on-chain only once its recovery Delay exists; until then its binding is the
      // passkey it enrolled with, which the policy holds to installing that Delay first (enrolment.ts passkeyOfDelay).
      current = await resolveBinding(this.bindingContext(), {
        chainId: e.chainId, account: e.account, type: e.kind.startsWith('safe') ? 'safe' : 'kernel', ...(e.kind.endsWith('frost') ? { passkey: e.passkey } : {}),
      });
    } catch (err) {
      if (err instanceof Refusal) throw new Refusal('enrolment_stale', `the account's signers changed since enrolment (${err.code}): enrol again`);
      throw err;
    }
    if (!sameBinding({ ...current, counterfactual: e.counterfactual }, e)) {
      throw new Refusal('enrolment_stale', 'the account\'s signers changed since enrolment: enrol again');
    }
    this.bindingChecked.set(key, this.nowMs());
  }

  private policyAccount(e: Enrolment, recoveryInstalled: boolean): PolicyAccount {
    return {
      account: e.account, kind: e.kind, coSigner: this.address, passkey: e.passkey, passkeySigner: e.passkeySigner, delay: e.delay,
      validator: e.validator, kernelAdapter: this.o.deployment.kernelAdapter, recoveryInstalled,
    };
  }

  private assemble(e: Enrolment, req: SigningPayload, coSignature: Hex): Hex {
    const parts = [
      { owner: e.passkeySigner, kind: 'contract' as const, signature: req.passkeySignature },
      { owner: this.address, kind: 'eoa' as const, signature: coSignature },
    ];
    switch (req.kind) {
      case 'safe-operation': return encodeSafeSignatures(req.window!.validAfter, req.window!.validUntil, parts);
      case 'safe-message': return `0x${encodeSafeSignatures(0, 0, parts).slice(2 + 24)}` as Hex;
      case 'kernel-operation': return encodeKernelUserOpSignature(req.window!.validAfter, req.window!.validUntil, encodePasskeyCoSignerSignature(req.passkeySignature, coSignature));
      case 'kernel-message': return encodeKernelErc1271Signature(encodePasskeyCoSignerSignature(req.passkeySignature, coSignature));
    }
  }

  private audit(a: {
    route: Route; e: Enrolment; req: SigningPayload; digest?: Hex; caller: Caller; decision: DecisionRecord['decision'];
    code?: RefusalCode; calls?: readonly DecodedCall[]; spend?: readonly Spend[]; flow?: string;
  }): void {
    this.o.audit.append({
      t: 'decision', at: this.now(), client: a.caller.client, route: a.route, chainId: a.e.chainId, account: a.e.account, kind: a.req.kind,
      passkeyId: passkeyId(a.e.passkey), digest: a.digest, decision: a.decision, code: a.code,
      nonce: a.req.userOp?.nonce, validUntil: a.req.window?.validUntil, flow: a.flow,
      calls: a.calls ? summarise(a.calls) : undefined, spend: a.spend?.length ? [...a.spend] : undefined,
      requestId: a.req.requestId,
    });
    this.metrics.set('mova_cosigner_audit_records', this.o.audit.records);
  }

  private count(route: string, result: string): void {
    this.metrics.inc('mova_cosigner_requests_total', { route, result });
  }

  /** Count, audit (for an enrolled account) and return the refusal to throw. Anything else becomes `internal`. */
  private refused(e: unknown, route: string, enrolment?: Enrolment, digest?: Hex, req?: SigningPayload, caller?: Caller): Refusal {
    const refusal = e instanceof Refusal ? e : new Refusal('internal', 'internal error');
    if (!(e instanceof Refusal)) this.log.error(`${route}: ${e instanceof Error ? e.message : String(e)}`);
    this.metrics.inc('mova_cosigner_refusals_total', { code: refusal.code });
    this.count(route, 'refused');
    if (enrolment && req && caller && !UNAUDITED.has(refusal.code)) {
      try {
        this.audit({ route: route as Route, e: enrolment, req, digest, caller, decision: 'refused', code: refusal.code });
      } catch (err) {
        this.log.error(`audit log append failed for a refusal: ${err instanceof Error ? err.message : String(err)}`);
      }
    }
    return refusal;
  }
}

/* ------------------------------------------------------------------ wire parsing */

function obj(v: unknown, what: string): Record<string, unknown> {
  if (!v || typeof v !== 'object' || Array.isArray(v)) throw new Refusal('malformed', `${what} must be a JSON object`);
  return v as Record<string, unknown>;
}

const KINDS: readonly SigningKind[] = ['safe-operation', 'kernel-operation', 'safe-message', 'kernel-message'];

export function parseSigningPayload(body: unknown): SigningPayload {
  const o = obj(body, 'the request');
  if (!Number.isSafeInteger(o.chainId)) throw new Refusal('malformed', 'chainId must be an integer');
  if (typeof o.account !== 'string' || !isAddress(o.account, { strict: false })) throw new Refusal('malformed', 'account must be an address');
  if (!KINDS.includes(o.kind as SigningKind)) throw new Refusal('malformed', `kind must be one of ${KINDS.join(', ')}`);
  const passkeySignature = o.passkeySignature ?? '0x';
  if (typeof passkeySignature !== 'string' || !isHex(passkeySignature) || size(passkeySignature) > 8 * 1024) throw new Refusal('malformed', 'passkeySignature must be hex');
  if (o.requestId !== undefined && (typeof o.requestId !== 'string' || !/^[A-Za-z0-9._:-]{1,64}$/.test(o.requestId))) {
    throw new Refusal('malformed', 'requestId must be 1-64 characters of [A-Za-z0-9._:-]');
  }
  const kind = o.kind as SigningKind;
  const out: SigningPayload = { chainId: o.chainId as number, account: getAddress(o.account), kind, passkeySignature: passkeySignature as Hex, requestId: o.requestId as string | undefined };
  if (kind.endsWith('operation')) {
    out.userOp = userOpFromWire(o.userOp);
    out.window = windowFromWire(o);
  } else {
    out.typedData = parseTypedData(o.typedData);
  }
  return out;
}

export function parseFrostSignRequest(body: unknown): FrostSignRequest {
  const o = obj(body, 'the request');
  const payload = parseSigningPayload(o);
  if (typeof o.sessionId !== 'string' || !isHex(o.sessionId) || size(o.sessionId) !== 32) throw new Refusal('malformed', 'sessionId must be 32 bytes of hex');
  const route = o.route ?? 'cosign';
  if (route !== 'cosign' && route !== 'veto') throw new Refusal('malformed', 'route must be "cosign" or "veto"');
  if (!Array.isArray(o.commitments) || o.commitments.length !== 2) throw new Refusal('malformed', 'commitments must be the two commitments of the session');
  const commitments = o.commitments.map((c: unknown, i) => {
    const x = obj(c, `commitments[${i}]`);
    try {
      if (!Number.isSafeInteger(x.id)) throw new Error('id');
      return { id: x.id as number, hiding: Point.fromBytes(hexToBytes(x.hiding as Hex)), binding: Point.fromBytes(hexToBytes(x.binding as Hex)) };
    } catch {
      throw new Refusal('malformed', `commitments[${i}] must be { id, hiding, binding } with compressed points`);
    }
  });
  return { ...payload, sessionId: o.sessionId.toLowerCase() as Hex, route, commitments };
}

export function parseAccountRequest(body: unknown): { chainId: number; account: Address } {
  const o = obj(body, 'the request');
  const chainId = typeof o.chainId === 'string' && /^\d{1,12}$/.test(o.chainId) ? Number(o.chainId) : o.chainId;
  if (!Number.isSafeInteger(chainId)) throw new Refusal('malformed', 'chainId must be an integer');
  if (typeof o.account !== 'string' || !isAddress(o.account, { strict: false })) throw new Refusal('malformed', 'account must be an address');
  return { chainId: chainId as number, account: getAddress(o.account) };
}

const INT_TYPE = /^u?int(\d{1,3})?$/;

/**
 * Typed data from JSON: integers arrive as decimal strings (or safe numbers) and are revived by their
 * declared type, so the hash computed here is the hash the wallet computed with bigints.
 */
export function parseTypedData(raw: unknown): TypedDataInput {
  const o = obj(raw, 'typedData');
  const types = obj(o.types, 'typedData.types') as Record<string, unknown>;
  const cleanTypes: Record<string, { name: string; type: string }[]> = {};
  for (const [name, fields] of Object.entries(types)) {
    if (!Array.isArray(fields) || fields.length > 64) throw new Refusal('malformed', `typedData.types.${name} must be a field list`);
    cleanTypes[name] = fields.map((f: unknown) => {
      const x = obj(f, `typedData.types.${name}[]`);
      if (typeof x.name !== 'string' || typeof x.type !== 'string') throw new Refusal('malformed', `typedData.types.${name} fields are { name, type }`);
      return { name: x.name, type: x.type };
    });
  }
  if (typeof o.primaryType !== 'string' || !cleanTypes[o.primaryType]) throw new Refusal('malformed', 'typedData.primaryType must name one of its types');
  const domainRaw = obj(o.domain, 'typedData.domain');
  const domain: TypedDataInput['domain'] = {};
  if (domainRaw.name !== undefined) domain.name = String(domainRaw.name);
  if (domainRaw.version !== undefined) domain.version = String(domainRaw.version);
  if (domainRaw.chainId !== undefined) {
    const c = domainRaw.chainId;
    if (!(Number.isSafeInteger(c) || (typeof c === 'string' && /^\d{1,20}$/.test(c)))) throw new Refusal('malformed', 'typedData.domain.chainId must be an integer');
    domain.chainId = Number(c);
  }
  if (domainRaw.verifyingContract !== undefined) {
    if (typeof domainRaw.verifyingContract !== 'string' || !isAddress(domainRaw.verifyingContract, { strict: false })) throw new Refusal('malformed', 'typedData.domain.verifyingContract must be an address');
    domain.verifyingContract = getAddress(domainRaw.verifyingContract);
  }
  if (domainRaw.salt !== undefined) {
    if (typeof domainRaw.salt !== 'string' || !isHex(domainRaw.salt)) throw new Refusal('malformed', 'typedData.domain.salt must be hex');
    domain.salt = domainRaw.salt as Hex;
  }
  const revive = (type: string, value: unknown, depth: number): unknown => {
    if (depth > 8) throw new Refusal('malformed', 'typedData nests too deeply');
    const array = /^(.*)\[(\d*)\]$/.exec(type);
    if (array) {
      if (!Array.isArray(value)) throw new Refusal('malformed', `typedData value of type ${type} must be an array`);
      return value.map((v) => revive(array[1]!, v, depth + 1));
    }
    if (INT_TYPE.test(type)) {
      if (typeof value === 'string' && /^-?\d{1,78}$/.test(value)) return BigInt(value);
      if (Number.isSafeInteger(value)) return BigInt(value as number);
      throw new Refusal('malformed', `typedData value of type ${type} must be an integer string`);
    }
    const struct = cleanTypes[type];
    if (struct) {
      const v = obj(value, `typedData value of type ${type}`);
      return Object.fromEntries(struct.map((f) => [f.name, revive(f.type, v[f.name], depth + 1)]));
    }
    return value;
  };
  const message = revive(o.primaryType, o.message, 0) as Record<string, unknown>;
  return { domain, types: cleanTypes, primaryType: o.primaryType, message };
}

function stripDomainType(td: TypedDataInput): TypedDataInput {
  const { EIP712Domain: _ignored, ...types } = td.types;
  return { ...td, types };
}
