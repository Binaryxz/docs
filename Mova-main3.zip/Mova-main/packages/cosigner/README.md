# @mova/cosigner

The server half of the wallet's 2-of-2 accounts. [docs/wallet-custody.md](../../docs/wallet-custody.md) specifies the custody model. This service puts its "server co-signer" on a real process:

- the second owner of a Safe 1.4.1, where the passkey's `SafeWebAuthnSigner` is the first;
- the `coSigner` of a Kernel v3.1 account whose root validator is `PasskeyCoSignerValidator`;
- the server participant in two-party FROST signing, for a `FrostSigner` Safe or a `FrostValidator` Kernel account;
- the server participant in the **distributed key generation** that makes those FROST keys, so a group key is created between a browser and this service and no machine ever holds the secret behind it.

## The rule

A signature leaves this service only in one case. In the same request, a user-verified passkey assertion must verify over the exact digest the service is about to sign, for the passkey the account trusts on-chain. The signature can be an ECDSA co-signature or a FROST signature share.

- **The digest is computed by the service**, from the UserOperation and its window (a Safe `SafeOp`, a Kernel `UserOpChallenge`) or from the typed data (ERC-1271). The service never signs a hash it did not compute.
- **The service reads the passkey from the chain, never from the request.** It comes from one of these:
  - a Safe owner's `getConfiguration()`, with its address checked against the factory's CREATE2;
  - `PasskeyCoSignerValidator.configOf(account)`;
  - for a FROST account, the only module of the account's recovery Delay.

  An account that does not exist yet is bound through the CREATE2 address that commits to its owners or its validator configuration.
  A FROST account's passkey is the one it enrolled with until its recovery Delay exists - before the account does, and also
  after the sponsorship module created a Kernel account at enrolment - and for that time the policy co-signs nothing but an
  operation that starts by installing recovery for exactly that passkey. Code at the Delay's address that is not the
  account's own Delay is refused (`enrolment_stale`).
- **The veto follows the same rule.** The server never vetoes alone. `setTxNonce` is co-signed only through `/v1/veto`, alone in its operation, for a queue that has something in it, with a fresh passkey signature and a window of at most 15 minutes.

The order of checks is in `src/service.ts`. The passkey is always checked before rate limits, policy or signing.

## Running it

```bash
RPC_URL=https://... CHAIN_ID=11155111 COSIGNER_MODE=production \
COSIGNER_KMS_MODULE=/app/plugins/aws-kms.js COSIGNER_KMS_SETTINGS_FILE=/app/config/kms.json \
COSIGNER_POLICY_FILE=/app/config/policy.json COSIGNER_AUDIT_LOG=/app/data/cosigner-audit.jsonl \
COSIGNER_API_KEYS_FILE=/run/secrets/cosigner/api_keys PORT=8495 OPS_PORT=9495 \
node --import tsx packages/cosigner/src/bin/cosigner.ts

# or, self-hosted from the shared image
docker compose -f packages/ops/docker-compose.yml --profile cosigner up --build
```

`src/config.ts` documents every variable. The entrypoint refuses to start in any of these cases:

- no key custody is configured;
- a key file is used in production mode without `COSIGNER_ALLOW_FILE_KEY_IN_PRODUCTION=1`;
- a key is placed in the environment;
- the RPC serves a chain other than `CHAIN_ID`;
- EntryPoint v0.7 is missing, or a Kernel contract named in the policy is missing;
- the audit log does not load;
- there are no API keys and `COSIGNER_PUBLIC_API=1` is not set.

It prints its address and never the key.

**The co-signer never runs on Flux.** Its key belongs to every user's account (`packages/ops/flux/README.md`), and `packages/ops/test/packaging.test.ts` enforces this. Run **one instance per key and audit log**: the audit log is the service's memory of what it co-signed.

## HTTP API

| Route | Body / query | Answer |
|---|---|---|
| `GET /v1/info` | | co-signer address, chain, EntryPoint, deployment addresses, policy and limits, custody label, enrolment typehash |
| `POST /v1/enrol` | `{ chainId, account, type: "safe"\|"kernel", issuedAt, passkeySignature, passkey?, safe?: { owners, threshold, saltNonce }, kernel?: { initData, salt } }` | `{ created, enrolment, sponsorship? }` |
| `POST /v1/cosign` | `{ chainId, account, kind, userOp?, validAfter?, validUntil?, typedData?, passkeySignature, requestId? }` | `{ digest, coSigner, coSignature, signature, reused }` |
| `POST /v1/veto` | same as `/v1/cosign`; the operation is exactly one `setTxNonce` on the account's Delay | same |
| `GET /v1/queue` | `?chainId=&account=` | `{ delay, txNonce, queueNonce, cooldown, expiration, vetoNonce?, pending: [{ nonce, txHash, createdAt, executableAt, expiresAt, call? }] }` |
| `POST /v1/frost/commit` | `{ chainId, account }` | `{ sessionId, commitment: { id, hiding, binding }, expiresAt }` |
| `POST /v1/frost/sign` | cosign fields plus `{ sessionId, route: "cosign"\|"veto", commitments: [2] }` | `{ digest, share: { id, z }, reused }` |
| `POST /v1/frost/dkg/start` | `{ chainId, passkey: { x, y, verifiers }, deviceKey, context, issuedAt, passkeySignature, round1 }` | `{ sessionId, accountRef, coSigner, device, server, round1, expiresAt }` |
| `POST /v1/frost/dkg/round2` | `{ chainId, sessionId, message }` | `{ message, confirmation }` |
| `POST /v1/frost/dkg/confirm` | `{ chainId, sessionId, confirmation, passkeySignature }` | `{ accountRef, groupKey, transcript, verificationShares, complete }` |
| `GET /v1/sponsorship` | `?chainId=&account=` | `{ status: "pending"\|"sponsored"\|"refused"\|"failed"\|"none", code?, retryable?, signerTx?, accountTx?, sponsorTx? }` (when sponsorship is on) |
| `POST /v1/alerts/subscribe` | `{ chainId, account, subscription: { endpoint, keys: { p256dh, auth } }, issuedAt, passkeySignature }` | `{ subscribed, created, pending }` (when alerts are on) |
| `POST /v1/alerts/unsubscribe` | `{ chainId, account, endpoint, issuedAt, passkeySignature }` | `{ unsubscribed }`; refused (`recovery_pending`) while a recovery is queued |
| `GET /healthz`, `/readyz` | | liveness, readiness (both listeners) |
| `GET /status`, `/metrics` | | ops listener only. Prometheus metrics are prefixed `mova_cosigner_`. |

Field formats:

- `kind` is `safe-operation`, `kernel-operation`, `safe-message` or `kernel-message`.
- `userOp` is the packed v0.7 operation without its signature, with integers as decimal strings.
- `passkeySignature` is `encodeWebAuthnSignature(assertion)` over the digest.
- `signature` is the whole `userOp.signature` or ERC-1271 bytes, assembled exactly as the executors assemble them.

The enrolment proof is an assertion over `keccak256(abi.encode(keccak256("MovaCoSignerEnrolment(uint256 chainId,address account,address coSigner,uint64 issuedAt)"), ...))`, issued within 5 minutes.

Every refusal is `{ error: <code>, message }` with an HTTP status, and the codes are listed in `src/refusal.ts`. For example: `bad_passkey_signature`, `passkey_required`, `expired`, `window_too_long`, `target_not_allowed`, `authority_change`, `use_veto_route`, `replayed`, `rate_limited`, `daily_limit_exceeded`, `nothing_to_veto`, `session_unknown`.

**Authentication has two layers.**

- **The user.** Every enrolment and signing request carries a passkey signature. Nothing else can make the service sign.
- **The client.** `Authorization: Bearer` API keys, one per client, gate every `/v1` route. They are compared as SHA-256 digests in constant time. The client's name appears in the audit log.

Other protections:

- A per-client-address token bucket runs before a body is read.
- Bodies are limited to 64 KiB and must be `application/json`.
- CORS headers are sent only for `CORS_ORIGINS`.
- Every response is redacted against the RPC URL and the API keys.

No response contains key material. The co-signature is the only signature returned, and without the passkey's signature it is useless.

## Key generation (`/v1/frost/dkg/*`)

A FROST account's key is generated **with the device**, over three signed rounds, using the transport in
`@mova/mpc` (`src/dkg-transport.ts`). Neither half ever holds the group secret, and this service stores only
its own share.

```
start    device round-1 broadcast in  ->  this service's round-1 broadcast out
round2   the device's share, sealed   ->  this service's share, sealed, and its signed view of the key
confirm  the device's confirmation    ->  the group key, transcript and verification shares
```

- **Authenticated.** Every message is signed by its sender's long-term key: this service signs with the
  co-signer ECDSA key its accounts already name on-chain, which the device checks by recovery against the
  address from `GET /v1/info`; the device signs with a per-run key that one user-verified passkey assertion
  authorises at `start`. Both keys, both round-1 payloads and both X25519 keys are bound into the transcript
  every later message signs, so neither side can be shown a different run than the other.
- **Encrypted.** The round-2 shares are sealed to the X25519 key the recipient published in round 1
  (X25519 + HKDF-SHA256 + XChaCha20-Poly1305), so this service never sees the device's share and the device
  never sees this service's.
- **Which account?** None yet: a FROST account's address commits to the group key the run is about to produce.
  The run is keyed by `chainId:passkeySigner` - the `SafeWebAuthnSigner` address of the passkey, which is
  exactly what the account will name as its recovery Delay's only module and what enrolment reads back from
  the chain. `enrol` refuses a group key this service generated for a different passkey (`dkg_invalid`).
- **One key per account.** A second run for a reference that already has a share is refused (`dkg_exists`).
  A run that reached round 2 leaves a share stored but **not complete**; such a share never signs and is not
  returned by `FrostShareStore.shareFor`, so `enrol` and `/v1/frost/commit` answer `no_share` until the device
  confirms. An expired run's pending share is discarded, and the account may start again.
- **Refusals**, all before anything is stored: `dkg_disabled` (no writable share store), `dkg_exists`,
  `session_unknown` (never started, already past that round, expired, or replayed), `dkg_invalid` (a bad
  signature, a replay, a round out of order, a different transcript, a share that does not match its
  commitments - the message names the participant at fault), `passkey_required`, `bad_passkey_signature`,
  `rate_limited` (per account reference, after the passkey verified).
- **Storage.** `COSIGNER_FROST_SHARES_FILE` must be set, and the file need not exist yet. Each record carries
  the account reference, the DKG transcript, when it was made, and whether it is complete. Open runs are in
  memory only: a restart mid-run loses it and the device starts again.
- **Audited.** Every round and every refusal is a `dkg` record in the audit log, with the account reference,
  the passkey fingerprint, the session id and - once complete - the group key and transcript. Never a share.

## Sponsorship (optional): gasless onboarding without the paymaster owner's key

With `COSIGNER_SPONSOR_GATE` set, every successful enrolment asks `src/sponsorship.ts` to sponsor the account through
`contracts/SponsorGate.sol`, which owns `SponsorPaymaster` (docs/wallet-custody.md §11.1). Before that, it creates
whatever the account's first operation needs on-chain:

1. **A Kernel account that does not exist yet** is created with a plain transaction to `KernelFactory.createAccount`.
   A public bundler refuses a Kernel first operation whose initCode creates the account through Kernel's meta factory
   (`account uses banned opcode: CREATE2`; docs/wallet-custody.md §10.3), so the account must exist first. The
   client then carries no initCode: `KernelExecutor` omits it once the account has code, and the app waits for the
   code before its first operation. Safe accounts are admitted from their first operation and are not deployed here.
2. **A Safe whose `SafeWebAuthnSigner` is not deployed** gets it, through the canonical factory: the Safe validates
   its first operation through that contract.
3. Then `SponsorGate.sponsor(account)`.

- **It never sends factory calldata from a request.** The only deployment it will send is the `initData` and `salt`
  the enrolment itself verified and recorded (`Enrolment.kernelDeployment`, written only after
  `predictKernelAddress` matched the enrolled address). The module recomputes that address before sending and
  refuses with `deployment_mismatch`, without sending anything, if it is not the enrolled account. It re-reads the
  account's code immediately before the send, so a second enrolment, another replica or a deployment the user sent
  themselves all stop it: an account is never created twice.
- **Its own key.** Every transaction comes from the module's operator key (`COSIGNER_SPONSOR_KMS_MODULE`, or
  `COSIGNER_SPONSOR_KEY_FILE` in development). A key file is refused in production unless
  `COSIGNER_ALLOW_SPONSOR_FILE_KEY_IN_PRODUCTION=1`. The entrypoint refuses an operator key that is the co-signer key.
- **Sending.** Transactions go out one at a time through lp-node's `TxSender`, with capped fees and replacement of a
  stuck transaction.
- **Limits.** A global rate limit and a per-client rate limit. A daily cap (`COSIGNER_SPONSOR_DAILY_CAP`) that must stay
  below the gate's budget, or the entrypoint refuses to start. The cap is rebuilt from the audit log.
- **Answers.** The enrol answer carries `sponsorship`. `GET /v1/sponsorship` follows it, and
  `RemoteCoSigner.waitForSponsorship(account)` waits until the account can transact. Refusal codes:
  `rate_limited`, `daily_cap`, `gate_budget_exhausted`, `operator_revoked`, `operator_unfunded`,
  `paymaster_not_gated`, `paymaster_unbounded`, `sponsorship_revoked` (never re-added), `deployment_mismatch`,
  `transaction_failed`, `chain_unavailable`.
- **Without a gate (OwnerlessPaymaster).** With `COSIGNER_SPONSOR_OWNERLESS_PAYMASTER=<address>` instead of
  `COSIGNER_SPONSOR_GATE` (one or the other), steps 1 and 2 run and step 3 does not: the paymaster admits accounts by
  their CREATE2 address, so nothing is allowlisted and no gate is read. The entrypoint refuses to start if the address
  does not answer `WINDOW()` and `MAX_COST_PER_OP()`. The daily cap then counts every account the module sends a
  transaction for, which bounds the operator key's spend to that many signer or Kernel creations a day. The record's
  outcome is `prepared`, the view's status is still `sponsored` (the account can transact), and `/v1/info` reports
  `sponsorship.gate: null, ownerlessPaymaster`. Why the co-signer does this rather than the first operation:
  docs/ownerless-paymaster.md, "Onboarding without a SponsorGate".
- **Idempotent.** Enrolling again sends nothing new: no second deployment, no second sponsorship. Every decision is an
  audit record (`t: "sponsor"`), carrying `accountTx` (the Kernel account's creation), `signerTx` (a Safe's passkey
  signer) and `sponsorTx`, whichever this service sent.
- **Nothing from the user.** No identifier beyond the enrolment: limits are keyed by API client and globally. The
  residual linkage between a user's account and the sale accounts it enrols, by client and timing, is described in
  docs/wallet-custody.md §11.1.

## Recovery alerts (optional): a queued recovery reaches the user with the app closed

With `COSIGNER_ALERTS_VAPID_KEY_FILE` set, the service serves `/v1/alerts/*` and runs `RecoveryWatcher`
(`src/recovery-alerts.ts`). The watcher follows every enrolled account's Delay for `TransactionAdded`, after
`COSIGNER_ALERTS_CONFIRMATIONS` blocks, with its cursor and subscriptions in `COSIGNER_ALERTS_STATE`.

- **When.** It pushes at once, every `COSIGNER_ALERTS_REALERT_SECONDS`, and within `COSIGNER_ALERTS_FINAL_NOTICE_SECONDS`
  of the cooldown's end, until the transaction is vetoed, executed or expired.
- **What.** "Uma recuperação foi solicitada na sua conta Movva" and when the transaction becomes executable: no amount,
  no address.
- **How.** Encryption is aes128gcm (RFC 8291) and authentication is VAPID (RFC 8292), both in `src/webpush.ts` on
  node:crypto. The encryption is tested against RFC 8291's vector.
- **Endpoints.** They must be on a known push service (`COSIGNER_PUSH_ALLOWED_HOSTS`). 404 and 410 remove a subscription;
  429 and 5xx are retried.

Subscribing and unsubscribing each need a fresh passkey assertion for the account. Unsubscribing is refused while a
recovery is queued. The browser side is in `@mova/cosigner/client`:

```ts
// In the page, from a user gesture (the browser asks for notification permission):
await subscribeRecoveryAlerts(await navigator.serviceWorker.ready, { cosigner, account, coSigner, sign: passkeyGet });

// In the service worker:
self.addEventListener('push', (event) => { if (!handleRecoveryPush(event, { url: '/' })) { /* the app's own messages */ } });
self.addEventListener('notificationclick', (event) => { handleRecoveryNotificationClick(event); });
```

## `RemoteCoSigner`: swapping the local server key for the service

The executors ask the server for a signature over a *digest* (`SafeOwner.signHash`, the `passkeyCoSignerSigner` callback), and the service refuses to sign a bare digest. So the client's stand-ins return a placeholder of the right length. The operation is co-signed in the submitter, just before the bundler, where all of it exists. The submitter:

1. reads the passkey's half out of the signature;
2. sends the operation to `/v1/veto` if it is exactly one `setTxNonce`, and to `/v1/cosign` otherwise;
3. checks that the answer recovers to the pinned co-signer over the digest it computes itself;
4. puts the answer in the placeholder's place and forwards the operation.

`wrap` does the same for `signTypedData`, including Kernel's ERC-6492 wrapper.

```ts
const cosigner = new RemoteCoSigner({ url: COSIGNER_URL, chainId, apiKey });
const { coSigner } = await cosigner.info();                   // pin it; it is also the address the account names

// Safe 2-of-2
await cosigner.enrol({ account: safe, type: 'safe', coSigner, passkey: pk, sign: passkeyGet, safe: { owners, threshold: 2, saltNonce } });
const remote = cosigner.safe({ safe, passkeySigner, coSigner });
const executor = remote.wrap(new SafeExecutor({
  safe, chainId, publicClient, deploy: { owners, threshold: 2, saltNonce }, paymasterAndData,
  owners: [passkeySafeOwner(passkeySigner, passkeyGet), remote.owner],
  submitter: remote.submitter(new BundlerSubmitter({ url: BUNDLER_URL, publicClient })),
}));

// Kernel + PasskeyCoSignerValidator
const k = cosigner.kernel({ account, validator, coSigner });
const kernelExecutor = k.wrap(new KernelExecutor({ ..., submitter: k.submitter(bundler),
  signer: passkeyCoSignerSigner({ validator, passkey: passkeyGet, coSigner: k.coSign }) }));

// FROST, once: generate the group key with the service. Two assertions; seal what comes back.
const dkg = await cosigner.runDkg({ passkey: pk, sign: passkeyGet, coSigner, label: 'mova-wallet' });
const sealed = await sealShare(dkg.keyShare, prfOutput, credentialId);   // @mova/smart-account
// ...then the account: a Kernel whose root validator is FrostValidator over dkg.groupKey, or a Safe whose
// only owner is a FrostSigner deployed with it. Enrol it, and sign with the two shares:
const f = cosigner.frostSafe({ safe, frostSigner, device: openedShare, passkey: passkeyGet });

// The recovery queue, to show on every open, and the veto
const q = await cosigner.queue(safe);
if (q.vetoNonce) await executor.execute([{ to: q.delay, data: encodeVeto(q.vetoNonce) }]);
```

`src/client.ts` imports nothing from node, so a browser can use it. An operation without a placeholder passes through the submitter untouched.

## Policy (`COSIGNER_POLICY_FILE`)

```json
{ "chainId": 11155111,
  "deployment": { "passkeyCoSignerValidator": "0x...", "frostValidator": "0x...", "kernelAvatarAdapter": "0x..." },
  "targets": [ { "address": "0x...", "label": "FiatEscrow" }, { "address": "0x...", "label": "PrivacyPoolEntrypoint" } ],
  "tokens":  [ { "address": "0x...", "label": "USDT", "transfer": false, "dailyLimit": "5000000000" } ],
  "nativeDailyLimit": "0",
  "rotation": { "coSigners": [] },
  "window": { "maxSeconds": 1800, "vetoMaxSeconds": 900 },
  "rateLimit": { "burst": 10, "perMinute": 30 },
  "webauthn": { "rpIds": ["movva.app"], "origins": ["https://movva.app"] } }
```

**Defaults** (`src/policy.ts`) are an allowlist; everything not named is refused.

- **Targets.** The deployment's own contracts: escrows, the Privacy Pools entrypoint and pools, the yield router, the audit grant registry. Any call to them is allowed, and native value counts against `nativeDailyLimit`.
- **Tokens.** `approve` or `increaseAllowance` to a listed target only. `transfer` only where `"transfer": true`. Nothing else on a token. Approvals and transfers count against `dailyLimit`, over a rolling 24 hours rebuilt from the audit log.
- **Authority changes** are refused on any target, including the account calling itself:
  - Safe: `addOwnerWithThreshold`, `removeOwner`, `swapOwner`, `changeThreshold`, `enableModule`, `disableModule`, `setFallbackHandler`, `setGuard`;
  - Kernel: `installModule`, `uninstallModule`, `changeRootValidator`, `upgradeTo`, `installValidations`, `invalidateNonce`, `grantAccess`;
  - the Delay: `setTxCooldown`, `setTxExpiration`, `setAvatar`, `setTarget`, `transferOwnership`;
  - our validators: `rotateCoSigner`, `rotateGroupKey`.

  Three documented flows are the only exceptions:
  - **Recovery setup:** exactly `recoverySetupCalls` or `kernelRecoverySetupCalls`, for this account and its passkey, with the default 7-day cooldown and expiration, at the start of the operation. A FROST account's operations *must* start with it until its recovery Delay exists (`recovery_setup_required`) - its first, whether or not the account was already created by the sponsorship module - because that is what binds its passkey on-chain.
  - **Rotation:** `swapOwner(prev, thisCoSigner, new)` or `rotateCoSigner(new)`, alone, to an address in `rotation.coSigners` (empty by default).
  - **The veto** described above.
- **Window.** It is required, `validUntil` 0 is refused, and `validUntil - now` must be at most 1800 s (900 s for a veto). "Now" is the chain head's timestamp. A deployment cannot configure more than 3600 s.
- **Execution modes.** DELEGATECALL is allowed only for a Safe batch through the canonical MultiSendCallOnly. Kernel operations must be `execute` in SINGLE or BATCH mode with revert-on-failure.
- **ERC-1271 messages** must name a listed verifying contract on this chain. Anything typed as a permit, approval, allowance or delegation is refused.
- **Replay and idempotency.** An operation whose EntryPoint nonce is already used is `replayed`. So is an operation that would deploy an account that already exists. An identical request for a digest already co-signed gets the same answer again (`reused`), counted once. FROST sessions are single-use, and a refused request burns its session.
- **Freshness.** The account's on-chain signers are re-read (cached for 15 s). If they changed, the answer is `enrolment_stale`.

## Key custody (`src/key.ts`)

```ts
interface CoSignerKey { address: Address; custody: string; signDigest(digest: Hex): Promise<Hex> } // 65 bytes, low s, v 27/28, raw digest
```

- **`kmsKey(backend)`: production.** It takes any secp256k1 KMS or HSM as `KmsBackend { custody, publicKey(), sign(digest) }`. The public key may be raw or DER SPKI, and the signature DER or compact. It normalises s, recovers v, and verifies every signature against the key before returning it. `COSIGNER_KMS_MODULE` names a module exporting `createKmsBackend(settings)`. AWS KMS (`ECC_SECG_P256K1`), GCP KMS and PKCS#11 map onto it as described in the source. No provider SDK is bundled.
- **`fileKey`: development.** It refuses production mode unless explicitly allowed, and refuses a file readable by group or others.
- **`localKey`: tests only.**

No implementation exposes the key: `JSON.stringify` and `util.inspect` show only the address and the custody label. FROST shares sit behind `FrostShareStore`, and the ones the DKG generates are written through `FrostShareWriter`. The file store is for development, with the same production rule, and is checked against verification shares on load. In production, envelope-encrypt shares with a KMS data key; a store that is not a writer simply makes this service refuse key generation (`dkg_disabled`).

## Audit log

The audit log is append-only JSON lines, fsynced before the answer leaves the process. It uses lp-node's `JsonlJournal` and is never compacted.

- **Who:** the account, the API client's name, and a fingerprint of the passkey key.
- **What:** the digest, the EntryPoint nonce, `validUntil`, the flow, and each call's target, selector and value. Also the amounts counted against limits.
- **Decision:** `signed`, `reused` or `refused` with its code.

It never contains a passkey signature, a co-signature or key material. On restart it rebuilds the enrolments, the co-signed digests and the last 24 hours of spend.

## Threat model

These points follow docs/wallet-custody.md §3 and §6. Every account must have recovery installed at creation, and the policy and `examples/cosigner-live.ts` both assume it.

**A compromised co-signer, alone (key, host or code), can only refuse.**

It cannot:
- spend, because the account needs the passkey's P-256 assertion and the co-signer cannot forge one;
- queue on the Delay, because it is not a module;
- veto or reconfigure the Delay, because the Delay's owner is the 2-of-2 account;
- execute early.

Refusing to co-sign is equivalent to the service being dead. The user's passkey queues an exit or a `swapOwner`/`rotateCoSigner` and waits out the 7-day cooldown.

What it does gain:
- it sees which accounts use it and what they do: operations, typed data, the timing of each;
- it can deny service;
- it can produce co-signatures over anything, which are useless without a matching passkey signature.

A leaked API key gives no more than any client has: requests that still need the passkey, and the rate limit.

**A compromised passkey, with this service honest**, gets what the policy allows, and only as fast as the rate and daily limits allow. That means calls to the deployment's own contracts and approvals to them. Everything else is refused with a code and recorded in the audit log.

Two losses remain, and the policy cannot remove either:
- **PRF users lose ASP-approved shielded notes immediately.** The passkey derives the pool seed, and a withdrawal needs no account signature.
- **A drain queued through the Delay stays pending for 7 days.** The monitor and the wallet's `/v1/queue` view must surface it so the user vetoes it. The thief holds the same passkey, so the thief can also sign vetoes; neither party can use recovery against the other while the co-signer is honest.

**A compromised passkey and a compromised co-signer together hold the whole 2-of-2.** The policy, the limits and the audit log run inside the compromised party, so none of them applies. Everything in the account is lost, as §6 states. The defences here are keeping the key in a KMS/HSM, so that a host compromise signs only while it lasts, and monitoring for signatures the audit log does not explain.

**A compromised co-signer host that edits the audit log** counts as a compromised co-signer. The log is evidence, not a control.

## Not built here

- **Provider-specific KMS backends.** The interface and the module hook exist; no AWS or GCP SDK is bundled.
- **A KMS-backed share store.** The DKG writes to `FrostShareWriter`; only the file store implements it, and it is development custody. In production, envelope-encrypt shares with a KMS data key and implement the same interface.
- **Durable DKG sessions.** An open run lives in memory, so a restart between rounds loses it; the device starts again and nothing is stranded.
- **Authenticator-counter clone detection.** Synced passkeys report 0.
- **High availability.** Run one instance per key and audit log.
- **A monitor check for alerts.** Watch `mova_cosigner_push_total`, `mova_cosigner_recovery_pending` and
  `mova_cosigner_recovery_watch_block` on `/metrics` (docs/runbook-incidents.md).
- **The app's integration.** See below.

## What the app needs to use it

- **Co-signer URL** (behind TLS), an **API key** for the app as a client, and the **co-signer address** from `GET /v1/info`. The address becomes the Safe's second owner or the Kernel validator's `coSigner` at account creation.
- **Bundler URL** for `BundlerSubmitter`, wrapped by `remote.submitter(...)`.
- **Paymaster.** The `SponsorPaymaster` address and the `paymasterAndData` it expects (paymaster, verification gas and postOp gas). With sponsorship on, the account is allowlisted by this service at enrolment - and a Kernel account is also created by it - so: `enrol`, then `waitForSponsorship(account)` before the first operation, and for Kernel check the account has code before sending anything (`KernelExecutor` then carries no initCode).
- **Recovery alerts.** A service worker calling `handleRecoveryPush`, and `subscribeRecoveryAlerts` once per device, from a user gesture.
- **Key generation, for a FROST account only.** `cosigner.runDkg({ passkey, sign, coSigner })` once, before the account exists: two user-verified assertions, and what comes back is the device's share, which the app seals with `sealShare(...)` from `@mova/smart-account` and never stores in the clear. The group key it returns is what the account is created with (`frostInstallData(groupKey)` for a Kernel `FrostValidator`, or a `FrostSigner` deployed with it for a Safe), so the address follows from the key and the DKG comes first.
- **Enrolment** at account creation. The call carries the counterfactual deployment and one passkey assertion.
- **Recovery setup** in the first operation, which the policy allows.
- **The queue**, shown on every open (`cosigner.queue(account)`), and the veto through the same executor.
- **Configuration:** `CORS_ORIGINS` for the wallet's origin, `webauthn.rpIds` and `webauthn.origins` pinned to the app, and the deployment's contracts and tokens in the policy file.

## Verification

- `npx vitest run packages/cosigner` runs unit tests for every refusal. They cover:
  - a forged passkey signature, a missing one, one over a different operation, one smuggling a second challenge;
  - expired, unbounded and long windows;
  - a disallowed target, a disallowed spender, a direct transfer;
  - every authority change, on Safe and on Kernel;
  - replay and idempotency, the rate limit, the daily limit (which survives a restart), and stale enrolment;
  - server-alone veto attempts and out-of-range vetoes;
  - FROST session reuse, commitment substitution, and expiry;
  - key generation end to end through the HTTP routes and `RemoteCoSigner.runDkg`, then the key used to enrol a Kernel `FrostValidator` account that signs; and every refusal: a second run for the same passkey, a second run while one is open, no passkey, an assertion over something else, a stale proof, a confirmation for a different key, a share whose run never confirmed, a replayed round 2, an unknown or expired session, a forged device signature (naming the participant), another chain, a malformed device key or context, a service with no writable share store, and a group key enrolled against a different passkey;
  - HTTP authentication, body limits, and no secret in any response;
  - the file-key production guard and KMS normalisation;
  - sponsorship: the Safe's signer created, a counterfactual Kernel account created through KernelFactory from the enrolment's own initData and salt (and refused when that does not create the enrolled address), then the account sponsored from the operator key; idempotency, never re-adding a removed account, the daily cap across a restart, every gate refusal, no user identifier;
  - Web Push: RFC 8291's test vector byte for byte, the VAPID JWT, endpoint checks and delivery outcomes;
  - recovery alerts: fresh passkey proofs, unsubscribing refused while queued, confirmations, the cursor across a restart, the re-alert schedule, stopping at veto or expiry, gone subscriptions, the browser helpers.

  The client is tested in place of a local key inside the real `SafeExecutor` and `KernelExecutor`, and produces byte-identical signatures.
- `npx tsx packages/cosigner/examples/cosigner-live.ts` runs everything on anvil (ports 8930–8934) against mainnet's bytecode, the bundler, the paymaster and a SponsorGate:
  - it runs the production entrypoint as a child process;
  - it checks the TypeScript passkey verifier against the deployed verifier;
  - a Safe and a Kernel account each run their first sponsored operation, co-signed over HTTP;
  - a device and the service run a real DKG over HTTP, the group key becomes a Kernel `FrostValidator` account, and that account's first operation and an ERC-1271 message are signed by device + server shares through the bundler;
  - it checks ERC-1271;
  - it attempts refused authority changes;
  - a stolen passkey's queued drain is shown and vetoed with a fresh passkey signature;
  - it attempts the server-alone veto and a replay;
  - the gate owns the paymaster; the co-signer's operator sponsors a Safe (creating its signer) and a Kernel account at enrolment (creating the account itself, so its first operation carries no initCode, and a second enrolment sends nothing);
  - a queued drain reaches a local push endpoint as an encrypted Web Push, decrypted with the subscription's keys, and again a day later and a day before the cooldown's end;
  - the co-signer's own cap refuses a third account; the operator key alone adds what the gate's window allows and no more, and is refused every owner power; the guardian revokes it and the co-signer refuses the next sponsorship;
  - it reads the audit log and the metrics.
