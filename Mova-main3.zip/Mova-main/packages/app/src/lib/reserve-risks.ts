/**
 * "Reserva e riscos": what backs the balance, what the reserve's yield strategy risks, and the one rule the contracts
 * apply if the reserve ever fell short. One copy, shown in onboarding (src/ui/Onboarding.tsx), on its own screen
 * linked from Início (#/reserva) and in Ajustes, through src/ui/ReserveRisks.tsx.
 *
 * Plain on purpose, and generic about where the strategy runs: no trading venue has been chosen, so none is named.
 * The pro-rata rule is MovvaReserve's: under-backed, a redemption pays the redeemer's pro-rata share of the reserve
 * (contracts/movva/MovvaReserve.sol), the same for every holder.
 */
export const RESERVE_RISKS = {
  title: 'Reserva e riscos',
  /** The user is shielded from FX. */
  fx: 'Você não fica exposto ao câmbio: seu saldo é em reais, a R$ 1,00 por Movva. A reserva guarda USDT (dólar digital) e é ela que absorve a variação do dólar contra o real.',
  /** Part of the reserve may go into the delta-neutral strategy; its yield goes back to the reserve. */
  strategy: 'Parte da reserva pode ser aplicada numa estratégia delta-neutra, que não aposta na alta nem na queda do dólar. O rendimento, em dólar, volta para a reserva e ajuda a compensar essa variação.',
  risksIntro: 'Essa estratégia tem riscos:',
  risks: [
    'a taxa de financiamento (funding) pode ficar negativa, e aí a estratégia custa em vez de render;',
    'risco da plataforma de negociação: ela pode falhar, suspender saques ou perder os fundos depositados;',
    'risco de contrato inteligente: um erro nos contratos pode causar perdas.',
  ],
  /** Movva covers a shortfall with its own capital. */
  shortfall: 'Se a reserva ficar curta, a Movva cobre a diferença com capital próprio.',
  /** The contracts' equal-treatment rule below 100%. */
  equalTreatment: 'Uma regra que você precisa conhecer: os contratos tratam todos os titulares igualmente. Se a reserva um dia ficasse abaixo de 100%, cada resgate pagaria a sua parte proporcional da reserva, e não R$ 1,00 por Movva. Por isso a Movva se compromete a recompor a reserva antes que isso aconteça.',
} as const;
