/**
 * What the app connects to: one Movva deployment (chain, contracts) and the services around it (RPC, matcher, LP
 * nodes, relayer, ASP, note vault), from a deployment JSON. Endpoints may be relative; they are resolved against the
 * URL the JSON was loaded from, so the same file works behind any host. The dev stack writes one
 * (scripts/dev-stack.ts); the settings screen loads another or overrides endpoints.
 */
import { getAddress, isAddress, isHex, size, type Address, type Hex } from 'viem';
import type { MovvaDeployment } from '@mova/wallet';

export interface LpNodeEndpoint {
  lp: Address;
  url: string;
  name?: string;
}

export interface AppServices {
  matcher: string;
  lpNodes: LpNodeEndpoint[];
  relayer: string;
  asp: string;
  /** The note vault the wallet files its encrypted notes with, and restores them from on a new device. */
  vault?: string;
  /** Holds the server share of a wallet opened without PRF (the recovery-code path). */
  shares?: string;
}

export interface AppDeployment {
  name: string;
  chainId: number;
  rpcUrl: string;
  contracts: MovvaDeployment & {
    /** The deployment's ReclaimZkTlsVerifier: sales settle only through it. */
    saleVerifier: Address;
    auditGrantRegistry: Address;
  };
  services: AppServices;
  trust: {
    /** Listed PIX charge (API Pix) hosts. Not used in the browser: see README, "What does not run in the browser". */
    pixLocationHosts: string[];
  };
  policy: { exitRelayFeeBps: bigint; saleDiscountBps: bigint };
  /** Who the user is: a Safe 2-of-2 or a Kernel account (passkey + the deployment's co-signer), or an EOA. */
  account: { kind: 'eoa' } | SmartAccountConfig;
  /** Present only on a local demo stack: its dev panel's API. */
  dev?: { url: string };
  /** Absolute URL the JSON came from. */
  source: string;
}

export type SmartAccountKind = 'safe' | 'kernel';

/**
 * The user's smart account: a Safe 1.4.1 whose owners are the passkey's WebAuthn signer and the co-signer, 2-of-2
 * (the default), or a Kernel v3.1 account whose root validator is PasskeyCoSignerValidator with the same two keys
 * (docs/wallet-custody.md). Every call it makes is a UserOperation the passkey signs in the browser, the co-signer
 * completes over HTTP, a bundler submits and the paymaster pays for.
 */
export interface SmartAccountConfig {
  /** The kind a new wallet gets. */
  kind: SmartAccountKind;
  /** The kinds onboarding offers. */
  kinds: SmartAccountKind[];
  /** ERC-4337 bundler JSON-RPC (EntryPoint v0.7). */
  bundler: string;
  /**
   * SponsorPaymaster ++ verification gas (16 bytes) ++ postOp gas (16 bytes), as each operation carries it. Exactly one
   * of this and `ownerlessPaymaster` is set.
   */
  paymasterAndData?: Hex;
  /**
   * contracts/OwnerlessPaymaster.sol (docs/ownerless-paymaster.md). Its data names the account's CREATE2 salt and the
   * current window, so the wallet builds the 91 bytes for every operation (`ownerlessPaymasterAndData`); the window
   * length and the per-operation cap are read from the contract. The gas limits default to the wallet's per chain
   * (`ownerlessVerificationGas`: 300k on Sepolia).
   */
  ownerlessPaymaster?: OwnerlessPaymasterConfig;
  /** The co-signer service; `address` is pinned: /v1/info must name it. */
  cosigner: { url: string; apiKey?: string; address: Address };
  /** Kernel's contracts: its root validator and the recovery adapter. Required when kernel is offered. */
  kernel?: { passkeyValidator: Address; adapter: Address };
  /** Gas limits every operation signs (a P-256 check in Solidity costs about 1M). */
  gas: { verificationGasLimit: bigint; callGasLimit: bigint; preVerificationGas: bigint };
}

export interface OwnerlessPaymasterConfig {
  address: Address;
  verificationGasLimit?: bigint;
  postOpGasLimit?: bigint;
}

export const DEFAULT_SMART_ACCOUNT_GAS = Object.freeze({ verificationGasLimit: 2_500_000n, callGasLimit: 2_500_000n, preVerificationGas: 400_000n });

export class DeploymentInvalid extends Error {}

const CONTRACTS = ['movva', 'reserve', 'onramp', 'offramp', 'entrypoint', 'movvaPool', 'saleVerifier', 'auditGrantRegistry'] as const;

const obj = (v: unknown, what: string): Record<string, unknown> => {
  if (!v || typeof v !== 'object' || Array.isArray(v)) throw new DeploymentInvalid(`${what} ausente ou inválido`);
  return v as Record<string, unknown>;
};
const str = (v: unknown, what: string): string => {
  if (typeof v !== 'string' || v.trim() === '') throw new DeploymentInvalid(`${what} ausente ou inválido`);
  return v.trim();
};
const address = (v: unknown, what: string): Address => {
  if (typeof v !== 'string' || !isAddress(v, { strict: false })) throw new DeploymentInvalid(`${what}: endereço inválido`);
  return getAddress(v);
};
const url = (v: unknown, what: string, base: string): string => {
  const s = str(v, what);
  try {
    const u = new URL(s, base);
    if (u.protocol !== 'http:' && u.protocol !== 'https:') throw new Error('protocol');
    return u.href.replace(/\/$/, '');
  } catch {
    throw new DeploymentInvalid(`${what}: URL inválida (${s})`);
  }
};
const integer = (v: unknown, what: string): bigint => {
  const s = typeof v === 'number' && Number.isSafeInteger(v) ? String(v) : v;
  if (typeof s !== 'string' || !/^\d+$/.test(s)) throw new DeploymentInvalid(`${what}: número inteiro inválido`);
  return BigInt(s);
};
const hosts = (v: unknown, what: string): string[] => {
  if (v === undefined) return [];
  if (!Array.isArray(v) || v.some((h) => typeof h !== 'string')) throw new DeploymentInvalid(`${what}: lista de hosts inválida`);
  return v as string[];
};

/** Parse and check a deployment JSON loaded from `sourceUrl` (absolute). */
export function parseDeployment(json: unknown, sourceUrl: string): AppDeployment {
  const j = obj(json, 'deployment');
  if (j.version !== 1) throw new DeploymentInvalid('versão do arquivo de deployment não suportada (esperada: 1)');
  const chainId = Number(integer(j.chainId, 'chainId'));
  if (!Number.isSafeInteger(chainId) || chainId <= 0) throw new DeploymentInvalid('chainId inválido');
  const c = obj(j.contracts, 'contracts');
  const contracts = Object.fromEntries(CONTRACTS.map((k) => [k, address(c[k], `contracts.${k}`)])) as Record<(typeof CONTRACTS)[number], Address>;
  const s = obj(j.services, 'services');
  if (!Array.isArray(s.lpNodes) || s.lpNodes.length === 0) throw new DeploymentInvalid('services.lpNodes: informe ao menos um nó de LP');
  const lpNodes = s.lpNodes.map((n, i) => {
    const node = obj(n, `services.lpNodes[${i}]`);
    return { lp: address(node.lp, `services.lpNodes[${i}].lp`), url: url(node.url, `services.lpNodes[${i}].url`, sourceUrl), name: typeof node.name === 'string' ? node.name : undefined };
  });
  const trust = j.trust === undefined ? {} : obj(j.trust, 'trust');
  const policy = j.policy === undefined ? {} : obj(j.policy, 'policy');
  const accountJson = j.account === undefined ? { kind: 'eoa' } : obj(j.account, 'account');
  const account = parseAccount(accountJson, sourceUrl);
  const dev = j.dev === undefined ? undefined : { url: url(obj(j.dev, 'dev').url, 'dev.url', sourceUrl) };
  return {
    name: typeof j.name === 'string' ? j.name : `chain ${chainId}`,
    chainId,
    rpcUrl: url(j.rpcUrl, 'rpcUrl', sourceUrl),
    contracts: { chainId, ...contracts, fromBlock: integer(j.fromBlock, 'fromBlock') },
    services: {
      matcher: url(s.matcher, 'services.matcher', sourceUrl),
      lpNodes,
      relayer: url(s.relayer, 'services.relayer', sourceUrl),
      asp: url(s.asp, 'services.asp', sourceUrl),
      vault: s.vault === undefined ? undefined : url(s.vault, 'services.vault', sourceUrl),
      shares: s.shares === undefined ? undefined : url(s.shares, 'services.shares', sourceUrl),
    },
    trust: { pixLocationHosts: hosts(trust.pixLocationHosts, 'trust.pixLocationHosts') },
    policy: {
      exitRelayFeeBps: policy.exitRelayFeeBps === undefined ? 50n : integer(policy.exitRelayFeeBps, 'policy.exitRelayFeeBps'),
      saleDiscountBps: policy.saleDiscountBps === undefined ? 100n : integer(policy.saleDiscountBps, 'policy.saleDiscountBps'),
    },
    account,
    dev,
    source: sourceUrl,
  };
}

const isKind = (v: unknown): v is SmartAccountKind => v === 'safe' || v === 'kernel';

function parseAccount(a: Record<string, unknown>, sourceUrl: string): AppDeployment['account'] {
  if (a.kind === 'eoa') return { kind: 'eoa' };
  if (!isKind(a.kind)) throw new DeploymentInvalid(`account.kind "${String(a.kind)}" não é aceito: use "safe" (recomendado), "kernel" ou "eoa"`);
  const kinds = a.kinds === undefined ? [a.kind] : a.kinds;
  if (!Array.isArray(kinds) || kinds.length === 0 || !kinds.every(isKind)) throw new DeploymentInvalid('account.kinds: lista inválida (use "safe" e/ou "kernel")');
  if (!kinds.includes(a.kind)) throw new DeploymentInvalid('account.kinds precisa incluir account.kind');
  if ((a.paymasterAndData === undefined) === (a.ownerlessPaymaster === undefined)) {
    throw new DeploymentInvalid('account: informe o paymaster, em account.paymasterAndData (SponsorPaymaster) ou em account.ownerlessPaymaster, e só um dos dois');
  }
  let ownerlessPaymaster: OwnerlessPaymasterConfig | undefined;
  if (a.ownerlessPaymaster !== undefined) {
    const o = obj(a.ownerlessPaymaster, 'account.ownerlessPaymaster');
    ownerlessPaymaster = {
      address: address(o.address, 'account.ownerlessPaymaster.address'),
      ...(o.verificationGasLimit === undefined ? {} : { verificationGasLimit: integer(o.verificationGasLimit, 'account.ownerlessPaymaster.verificationGasLimit') }),
      ...(o.postOpGasLimit === undefined ? {} : { postOpGasLimit: integer(o.postOpGasLimit, 'account.ownerlessPaymaster.postOpGasLimit') }),
    };
  } else if (typeof a.paymasterAndData !== 'string' || !isHex(a.paymasterAndData) || size(a.paymasterAndData) < 52) {
    throw new DeploymentInvalid('account.paymasterAndData: esperado o paymaster e os dois limites de gás (ao menos 52 bytes em hex)');
  }
  const c = obj(a.cosigner, 'account.cosigner (o serviço cossignatário)');
  if (c.apiKey !== undefined && typeof c.apiKey !== 'string') throw new DeploymentInvalid('account.cosigner.apiKey inválida');
  let kernel: SmartAccountConfig['kernel'];
  if ((kinds as SmartAccountKind[]).includes('kernel')) {
    const k = obj(a.kernel, 'account.kernel (a conta Kernel precisa do PasskeyCoSignerValidator e do KernelAvatarAdapter)');
    kernel = { passkeyValidator: address(k.passkeyValidator, 'account.kernel.passkeyValidator'), adapter: address(k.adapter, 'account.kernel.adapter') };
  }
  const g = a.gas === undefined ? {} : obj(a.gas, 'account.gas');
  const gas = (k: keyof typeof DEFAULT_SMART_ACCOUNT_GAS) => (g[k] === undefined ? DEFAULT_SMART_ACCOUNT_GAS[k] : integer(g[k], `account.gas.${k}`));
  return {
    kind: a.kind,
    kinds: [...new Set(kinds as SmartAccountKind[])],
    bundler: url(a.bundler, 'account.bundler', sourceUrl),
    ...(ownerlessPaymaster ? { ownerlessPaymaster } : { paymasterAndData: a.paymasterAndData as Hex }),
    cosigner: {
      url: url(c.url, 'account.cosigner.url', sourceUrl),
      ...(typeof c.apiKey === 'string' ? { apiKey: c.apiKey } : {}),
      address: address(c.address, 'account.cosigner.address'),
    },
    ...(kernel ? { kernel } : {}),
    gas: { verificationGasLimit: gas('verificationGasLimit'), callGasLimit: gas('callGasLimit'), preVerificationGas: gas('preVerificationGas') },
  };
}

export const isSmartAccount = (a: AppDeployment['account']): a is SmartAccountConfig => a.kind !== 'eoa';

/** Endpoints the user changed in settings, over the deployment's own. */
export interface EndpointOverrides {
  rpcUrl?: string;
  matcher?: string;
  relayer?: string;
  asp?: string;
  vault?: string;
  bundler?: string;
  cosigner?: string;
  lpNodes?: LpNodeEndpoint[];
}

export function withOverrides(d: AppDeployment, o: EndpointOverrides): AppDeployment {
  const base = d.source;
  const account = isSmartAccount(d.account) ? {
    ...d.account,
    bundler: o.bundler ? url(o.bundler, 'bundler', base) : d.account.bundler,
    cosigner: { ...d.account.cosigner, url: o.cosigner ? url(o.cosigner, 'cossignatário', base) : d.account.cosigner.url },
  } : d.account;
  return {
    ...d,
    account,
    rpcUrl: o.rpcUrl ? url(o.rpcUrl, 'RPC', base) : d.rpcUrl,
    services: {
      ...d.services,
      matcher: o.matcher ? url(o.matcher, 'matcher', base) : d.services.matcher,
      relayer: o.relayer ? url(o.relayer, 'relayer', base) : d.services.relayer,
      asp: o.asp ? url(o.asp, 'ASP', base) : d.services.asp,
      vault: o.vault ? url(o.vault, 'cofre de notas', base) : d.services.vault,
      lpNodes: o.lpNodes && o.lpNodes.length > 0
        ? o.lpNodes.map((n, i) => ({ lp: address(n.lp, `nó de LP ${i + 1}`), url: url(n.url, `nó de LP ${i + 1}`, base), name: n.name }))
        : d.services.lpNodes,
    },
  };
}
