/**
 * "Reserva e riscos" (src/lib/reserve-risks.ts): a card for onboarding and Ajustes, and the screen Início links to.
 */
import { RESERVE_RISKS } from '../lib/reserve-risks.js';

export function ReserveRisksCard({ sunken, heading = true }: { sunken?: boolean; heading?: boolean }) {
  const r = RESERVE_RISKS;
  return (
    <div className={`card${sunken ? ' sunken' : ''}`} data-testid="reserve-risks">
      {heading && <h2>{r.title}</h2>}
      <p>{r.fx}</p>
      <p>{r.strategy}</p>
      <p>{r.risksIntro}</p>
      <ul className="plain-list">
        {r.risks.map((x) => <li key={x}>{x}</li>)}
      </ul>
      <p>{r.shortfall}</p>
      <p>{r.equalTreatment}</p>
    </div>
  );
}

export function ReserveRisks() {
  return (
    <>
      <h1>{RESERVE_RISKS.title}</h1>
      <ReserveRisksCard heading={false} />
      <a href="#/inicio">Voltar ao saldo</a>
    </>
  );
}
