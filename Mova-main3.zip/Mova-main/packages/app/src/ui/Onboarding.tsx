import { useState } from 'react';
import { isSmartAccount, type AppDeployment, type SmartAccountKind } from '../lib/deployment.js';
import {
  PrfUnsupported, createWithPasskey, createWithRecoveryCode, loadIdentity, passkeySupport, unlockWithPasskey, unlockWithShares,
  type StoredIdentity,
} from '../passkey/seed.js';
import type { KeyValue } from '../wallet/stores.js';
import { ErrorNotice, Field, Notice, Spinner } from './components.js';
import { useAction } from './hooks.js';
import { ReserveRisksCard } from './ReserveRisks.js';

export const RECOVERY_EXPLAINED =
  'Sua carteira não tem senha nem frase secreta. A chave dela é calculada pela sua passkey cada vez que você desbloqueia, e nunca fica gravada neste aparelho. '
  + 'Se perder o aparelho, abra o app em outro com a mesma passkey (sincronizada pela sua conta Google ou Apple, pelo seu gerenciador de senhas, ou uma chave de segurança física): '
  + 'a carteira recalcula a mesma chave, reencontra seus saldos na blockchain e baixa o seu histórico, criptografado, do cofre de notas. '
  + 'Se perder a única passkey e ela não estiver sincronizada em lugar nenhum, o acesso à carteira se perde.';

export const RECOVERY_CODE_EXPLAINED =
  'Caminho alternativo, mais fraco, para autenticadores sem a extensão PRF: a chave passa a existir e é dividida em três partes. '
  + 'Uma fica guardada neste navegador, outra no servidor de partes da Movva, e a terceira é um código de recuperação que você anota. '
  + 'Duas partes quaisquer abrem a carteira; uma sozinha não abre nada. Quem tiver o código e acesso a este navegador tem a carteira: guarde o código no papel, longe do aparelho.';

export interface OnboardingProps {
  deployment: AppDeployment;
  kv: KeyValue;
  opening: boolean;
  error?: unknown;
  onUnlocked: (seed: Uint8Array, identity: StoredIdentity) => void;
}

export function Onboarding({ deployment, kv, opening, error, onUnlocked }: OnboardingProps) {
  const [identity, setIdentity] = useState(() => loadIdentity(kv));
  const [mode, setMode] = useState<'start' | 'code-create' | 'code-restore'>('start');
  const [code, setCode] = useState('');
  const [shownCode, setShownCode] = useState<{ code: string; seed: Uint8Array; identity: StoredIdentity }>();
  const [wroteDown, setWroteDown] = useState(false);
  const support = passkeySupport();
  const sharesUrl = deployment.services.shares;
  const smart = isSmartAccount(deployment.account) ? deployment.account : undefined;
  const [accountKind, setAccountKind] = useState<SmartAccountKind | undefined>(smart?.kind);

  const create = useAction(async () => {
    const r = await createWithPasskey(kv, { accountKind });
    onUnlocked(r.seed, r.identity);
  });
  const restore = useAction(async () => {
    const r = await unlockWithPasskey(kv, identity?.kind === 'webauthn-prf' ? identity : undefined);
    setIdentity(r.identity);
    onUnlocked(r.seed, r.identity);
  });
  const createCode = useAction(async () => {
    const r = await createWithRecoveryCode(kv, sharesUrl);
    setIdentity(r.identity);
    setShownCode({ code: r.recoveryCode, seed: r.seed, identity: r.identity });
  });
  const unlockShares = useAction(async () => {
    const r = await unlockWithShares(kv, { identity: identity?.kind === 'split-share' ? identity : undefined, recoveryCode: code || undefined, sharesUrl });
    setIdentity(r.identity);
    onUnlocked(r.seed, r.identity);
  });
  const busy = opening || create.busy || restore.busy || createCode.busy || unlockShares.busy;
  const prfMissing = create.error instanceof PrfUnsupported;

  if (shownCode) {
    return (
      <div className="card">
        <h1>Anote o código de recuperação</h1>
        <p>Ele aparece só agora. Junto com este aparelho ou com o servidor de partes, ele abre a sua carteira.</p>
        <div className="recovery-code" data-testid="recovery-code">{shownCode.code}</div>
        <label className="field" style={{ display: 'flex', gap: 8, alignItems: 'center', marginTop: 12 }}>
          <input type="checkbox" style={{ width: 'auto' }} checked={wroteDown} onChange={(e) => setWroteDown(e.target.checked)} />
          <span style={{ margin: 0 }}>Anotei o código num lugar seguro, longe do aparelho</span>
        </label>
        <button type="button" disabled={!wroteDown || opening} onClick={() => onUnlocked(shownCode.seed, shownCode.identity)}>Continuar</button>
      </div>
    );
  }

  return (
    <>
      <h1>Movva</h1>
      <p className="muted">Reais protegidos: compre Movva por PIX ou boleto e venda quando quiser, com o saldo privado.</p>
      <div className="card sunken">
        <h2>Como a recuperação funciona</h2>
        <p data-testid="recovery-explained">{RECOVERY_EXPLAINED}</p>
      </div>
      {opening && <Spinner label="Abrindo a carteira: lendo os pools e o cofre de notas..." />}
      <ErrorNotice error={error} />

      {mode === 'start' && identity && (
        <div className="card">
          <h2>Desbloquear</h2>
          {identity.kind === 'webauthn-prf' ? (
            <button type="button" disabled={busy} onClick={() => void restore.run()}>Desbloquear com a passkey</button>
          ) : (
            <>
              <p className="faint">Esta carteira usa o código de recuperação (sem PRF).</p>
              <button type="button" disabled={busy} onClick={() => void unlockShares.run()}>Desbloquear neste aparelho</button>
              <button type="button" className="link" onClick={() => setMode('code-restore')}>Usar o código de recuperação</button>
            </>
          )}
          <ErrorNotice error={restore.error ?? unlockShares.error} onAction={() => void (identity.kind === 'webauthn-prf' ? restore.run() : unlockShares.run())} />
        </div>
      )}

      {mode === 'start' && !identity && <ReserveRisksCard sunken />}

      {mode === 'start' && !identity && (
        <div className="card">
          <h2>Começar</h2>
          {support.available ? (
            <>
              {smart && smart.kinds.length > 1 && (
                <Field label="Tipo de conta" hint="As duas exigem a sua passkey e o cossignatário para cada operação, e têm recuperação com prazo de 7 dias. A Safe usa só contratos auditados; a Kernel depende de um validador próprio, ainda sem auditoria.">
                  <select aria-label="Tipo de conta" value={accountKind} onChange={(e) => setAccountKind(e.target.value as SmartAccountKind)}>
                    {smart.kinds.map((k) => <option key={k} value={k}>{k === 'safe' ? 'Safe 2-de-2 (recomendada)' : 'Kernel'}</option>)}
                  </select>
                </Field>
              )}
              <div className="actions" style={{ flexDirection: 'column' }}>
                <button type="button" disabled={busy} onClick={() => void create.run()}>Criar carteira com passkey</button>
                <button type="button" className="secondary" disabled={busy} onClick={() => void restore.run()}>Já tenho: restaurar com a passkey</button>
              </div>
              <ErrorNotice error={prfMissing ? undefined : create.error ?? restore.error} onAction={() => void restore.run()} />
            </>
          ) : (
            <Notice tone="warn" title="Passkeys indisponíveis">
              <p>{support.reason}</p>
            </Notice>
          )}
          {prfMissing && (
            <Notice tone="warn" title="Seu autenticador não tem PRF">
              <p>A passkey foi criada, mas não deriva a chave da carteira. Você pode usar o caminho com código de recuperação abaixo, ou outro autenticador (uma chave de segurança física, por exemplo).</p>
            </Notice>
          )}
        </div>
      )}

      {mode === 'start' && !identity && (
        <div className="card">
          <h2>Sem passkey com PRF</h2>
          <Notice tone="warn" title="Caminho com código de recuperação">
            <p>{RECOVERY_CODE_EXPLAINED}</p>
          </Notice>
          <div className="actions" style={{ flexDirection: 'column' }}>
            <button type="button" className="secondary" disabled={busy || !sharesUrl} onClick={() => setMode('code-create')}>Criar carteira com código de recuperação</button>
            <button type="button" className="secondary" disabled={busy} onClick={() => setMode('code-restore')}>Restaurar com código de recuperação</button>
          </div>
          {!sharesUrl && <p className="faint">Este deployment não tem servidor de partes.</p>}
        </div>
      )}

      {mode === 'code-create' && (
        <div className="card">
          <h2>Criar com código de recuperação</h2>
          <p>{RECOVERY_CODE_EXPLAINED}</p>
          {createCode.busy ? <Spinner label="Gerando as partes..." /> : <button type="button" onClick={() => void createCode.run()}>Gerar as partes e o código</button>}
          <button type="button" className="link" onClick={() => setMode('start')}>Voltar</button>
          <ErrorNotice error={createCode.error} />
        </div>
      )}

      {mode === 'code-restore' && (
        <form className="card" onSubmit={(e) => { e.preventDefault(); void unlockShares.run(); }}>
          <h2>Restaurar com código de recuperação</h2>
          <Field label="Código de recuperação" hint="Letras e números em grupos de oito; maiúsculas, espaços e hífens tanto faz.">
            <textarea value={code} onChange={(e) => setCode(e.target.value)} autoComplete="off" />
          </Field>
          <button type="submit" disabled={busy || !code.trim()}>Restaurar</button>
          <button type="button" className="link" onClick={() => setMode('start')}>Voltar</button>
          <ErrorNotice error={unlockShares.error} />
        </form>
      )}
    </>
  );
}
