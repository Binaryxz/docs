import { LedgerRefused, type MovvaBalance } from '@mova/wallet';
import { RAIL_LABEL, backingView, brasiliaIsoDate, buyStatusView, formatBRL, formatDateTime, saleStatusView } from '../lib/format.js';
import { AWAITING_APPROVAL_EXPLAINED, IN_SALES_EXPLAINED, balanceFigures } from '../lib/pending.js';
import { ErrorNotice, Notice, Row, Spinner, StatusBadge } from './components.js';
import { useAction, useActivity, useAsync, useInterval, useWallet } from './hooks.js';
import { InTheOpenCard, PendingSalesCard } from './PendingSales.js';
import { BlockedDeliveriesCard } from './Delivery.js';
import { RecoveryAlertsOffer } from './Alerts.js';
import { RESERVE_RISKS } from '../lib/reserve-risks.js';

export function BalanceCard({ balance }: { balance: MovvaBalance }) {
  const backing = backingView(balance.backing);
  const figures = balanceFigures(balance);
  return (
    <>
      <div className="card">
        <div className="faint">Total</div>
        <div className="big" data-testid="total">{balance.totalFormatted}</div>
        {backing.conditional && <div className="faint" data-testid="conditional">Valores a R$ 1,00 por Movva, o que depende do lastro abaixo.</div>}
        <div style={{ marginTop: 12 }}>
          <div className="faint">Disponível</div>
          <div className="num" data-testid="available">{figures.spendableFormatted}</div>
        </div>
        {figures.awaitingApproval && (
          <div data-testid="pending-approval">
            <Row label="Aguardando aprovação" value={<span data-testid="awaiting-approval">{figures.awaitingApproval}</span>} />
            <p className="faint">Já está no total, mas ainda não pode ser vendido: a ASP ainda não aprovou o depósito de volta ao saldo.</p>
            <details>
              <summary>Detalhes técnicos</summary>
              <p className="faint">{AWAITING_APPROVAL_EXPLAINED}</p>
            </details>
          </div>
        )}
        {figures.inSales && (
          <div data-testid="pending-in-sales">
            <Row label={`Em vendas em andamento (${figures.inSales.count})`} value={<a href="#/vender" data-testid="in-sales">{figures.inSales.formatted}</a>} />
            <p className="faint">{IN_SALES_EXPLAINED}</p>
          </div>
        )}
      </div>
      <Notice tone={backing.tone} title={backing.title}>
        <p>{backing.detail}</p>
        {backing.closedMarket && <p className="faint" data-testid="market-closed">{backing.closedMarket}</p>}
        {backing.technical && (
          <details>
            <summary>Detalhes técnicos</summary>
            <span className="mono">{backing.technical}</span>
          </details>
        )}
        <p className="faint"><a href="#/reserva" data-testid="reserve-risks-link">{RESERVE_RISKS.title}</a></p>
      </Notice>
    </>
  );
}

export function ActivityList() {
  const w = useWallet();
  useActivity(w);
  const now = w.now();
  const today = brasiliaIsoDate(now);
  const orders = w.orders().slice(0, 6);
  const sales = w.sales().slice(0, 6);
  const reshields = w.reshields().slice(0, 4);
  if (orders.length + sales.length + reshields.length === 0) return <p className="faint">Nenhuma movimentação ainda.</p>;
  return (
    <div className="card">
      <h2>Movimentações</h2>
      {orders.map((o) => {
        const view = o.status ? buyStatusView(o.status, now) : { label: 'Aguardando pagamento', tone: 'info' as const, done: false };
        return (
          <div className="list-item" key={o.orderId}>
            <div className="row">
              <a className="label" href={`#/comprar/${o.orderId}`}>Compra por {RAIL_LABEL[o.rail]} · {formatBRL(o.amount)}</a>
              <StatusBadge view={view} />
            </div>
            <div className="faint">{formatDateTime(o.createdAt)}</div>
          </div>
        );
      })}
      {sales.map((s) => {
        const view = s.status ? saleStatusView(s.status, now, today) : { label: 'Aberta', tone: 'info' as const, done: false };
        return (
          <div className="list-item" key={s.saleId}>
            <div className="row">
              <a className="label" href="#/vender">{s.rail === 'boleto' ? 'Boleto pago com Movva' : 'Venda por PIX'} · {formatBRL(s.receive)}</a>
              <StatusBadge view={view} />
            </div>
            <div className="faint">{formatDateTime(s.createdAt)}</div>
          </div>
        );
      })}
      {reshields.map((r) => (
        <div className="list-item" key={r.transactionHash}>
          <div className="row">
            <span className="label">Devolvido ao saldo protegido · {formatBRL(r.amount)}</span>
            <span className="faint">taxa do pool {formatBRL(r.fee)}</span>
          </div>
          <div className="faint">{r.source === 'rescue_address' ? 'De um pedido entregue fora do saldo' : 'Da conta de uma venda desfeita'} · {formatDateTime(r.createdAt)}</div>
        </div>
      ))}
    </div>
  );
}

const shortAddress = (a?: string) => (a ? `${a.slice(0, 6)}…${a.slice(-4)}` : 'um contrato');

/**
 * The account's recovery queue, on every open: a transaction queued through the recovery Delay can be executed after
 * the cooldown by anyone, so one the user did not queue - a stolen passkey's - must be seen and vetoed before then.
 */
export function RecoveryQueueCard() {
  const w = useWallet();
  const queue = useAsync(async () => (w.recoveryQueue ? w.recoveryQueue() : undefined), [w]);
  useInterval(queue.reload, 15_000);
  const veto = useAction(async () => {
    await w.vetoRecovery!();
    queue.reload();
    return true;
  });
  if (!w.recoveryQueue || w.accountKind === 'eoa') return null;
  const q = queue.data;
  if (queue.error && !q) return <ErrorNotice error={queue.error} onAction={() => queue.reload()} />;
  if (!q || q.pending.length === 0) {
    return veto.result ? (
      <div data-testid="recovery-vetoed">
        <Notice tone="ok" title="Recuperação vetada">
          <p>Nada mais está na fila de recuperação da sua conta.</p>
        </Notice>
      </div>
    ) : null;
  }
  return (
    <div data-testid="recovery-queue">
      <Notice tone="danger" title="Recuperação pendente na sua conta">
        <p>
          Há {q.pending.length === 1 ? 'uma transação' : `${q.pending.length} transações`} na fila de recuperação da sua conta. Quem tem a sua
          passkey pode fazer isso, e depois do prazo qualquer um executa. Se não foi você, vete agora: o veto usa a sua passkey e o cossignatário.
        </p>
        {q.pending.map((p) => (
          <Row key={String(p.nonce)} label={`Transação ${String(p.nonce)}`} value={`para ${shortAddress(p.to)} · executável a partir de ${formatDateTime(p.executableAt)}`} />
        ))}
        <div className="actions">
          <button type="button" className="danger" disabled={veto.busy} onClick={() => void veto.run()}>{veto.busy ? 'Vetando...' : 'Vetar a recuperação'}</button>
        </div>
        <ErrorNotice error={veto.error} />
      </Notice>
    </div>
  );
}

export function Home({ restored }: { restored?: { positions: number; notes: number } }) {
  const w = useWallet();
  const balance = useAsync(async () => {
    await w.refreshActivity();
    return w.balance();
  }, [w]);
  useInterval(balance.reload, 15_000);
  return (
    <>
      <h1>Seu saldo</h1>
      {restored && (restored.positions > 0 || restored.notes > 0) && (
        <Notice tone="ok" title="Carteira restaurada neste aparelho">
          <p>{restored.positions} posição(ões) reencontrada(s) na blockchain e {restored.notes} nota(s) do histórico baixada(s) do cofre.</p>
        </Notice>
      )}
      <RecoveryQueueCard />
      <RecoveryAlertsOffer />
      {balance.data ? <BalanceCard balance={balance.data} /> : balance.error ? null : <Spinner label="Lendo seu saldo..." />}
      <ErrorNotice
        error={balance.error}
        onAction={() => void (balance.error instanceof LedgerRefused ? w.resyncFromVault().catch(() => 0) : Promise.resolve(0)).then(balance.reload)}
      />
      <BlockedDeliveriesCard />
      <PendingSalesCard onSettled={balance.reload} />
      <InTheOpenCard onSettled={balance.reload} />
      <div className="actions">
        <a className="button" href="#/comprar">Comprar</a>
        <a className="button secondary" href="#/vender">Vender</a>
      </div>
      <div style={{ marginTop: 12 }}>
        <ActivityList />
      </div>
    </>
  );
}
