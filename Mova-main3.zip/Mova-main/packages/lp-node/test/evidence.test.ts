import { afterEach, describe, expect, it } from 'vitest';
import type { Hex } from 'viem';
import { generatePrivateKey, privateKeyToAccount } from 'viem/accounts';
import {
  ArbitrationDesk, ArbitrationService, Arbitrator, MemoryCaseStore, Rail, newPixSalt, pixKeyCommitment, railMask,
  type EscrowReader,
} from '@mova/ramp';
import { OrderState, SaleState } from '../src/abi.js';
import { NATIVE } from '../src/chain.js';
import { createServer } from 'node:http';
import { ArbitrationClient, ArbitrationDeskTooOld, evidenceCommitment, evidenceMaterial } from '../src/evidence.js';
import { MemoryJournal } from '../src/journal.js';
import { pixTxidForOrder } from '../src/onramp.js';
import { Store, type LpRecord } from '../src/store.js';
import { OFFRAMP, ONRAMP, type FakeChain } from './fake-chain.js';
import { LP, LP_KEY, LP_PIX_KEY, harness, type Harness } from './harness.js';

/**
 * Dispute evidence (evidence.ts) against the real arbitration desk service: the desk reads the parties from
 * the (fake) escrow, recovers the submitting side from the LP's signature, and records what arrived. Every
 * byte the node sends is captured and searched for the payment's data.
 */

const SELLER_KEY = '+5511987654321';
let closers: (() => Promise<void>)[] = [];
afterEach(async () => {
  for (const c of closers) await c();
  closers = [];
});

interface Desk {
  url: string; desk: ArbitrationDesk; sent: string[]; down: { on: boolean };
  /** Every case the desk holds (the desk itself has no listing; its store does). */
  cases(): ReturnType<MemoryCaseStore['all']>;
  attach(chain: FakeChain): void;
}

async function deskService(): Promise<Desk> {
  let chain: FakeChain | undefined;
  const reader: EscrowReader = {
    read: async ({ leg, orderId }) => {
      const now = Number(chain!.time());
      if (leg === 'onramp') {
        const ord = await chain!.order(orderId);
        const offer = await chain!.offer(ord.offerId);
        return { disputed: ord.state === OrderState.DISPUTED, parties: { taker: ord.taker, lp: offer.lp }, disputedAt: now, expiresAt: now + 30 * 86_400 };
      }
      const sale = await chain!.sale(orderId);
      return { disputed: sale.state === SaleState.DISPUTED, parties: { seller: sale.seller, lp: sale.lp }, disputedAt: now, expiresAt: now + 30 * 86_400 };
    },
  };
  const store = new MemoryCaseStore();
  const desk = new ArbitrationDesk(
    store, new Arbitrator(generatePrivateKey()),
    { chainId: 31337, escrows: [{ address: ONRAMP, leg: 'onramp' }, { address: OFFRAMP, leg: 'offramp' }], reader },
    () => Number(chain!.time()),
  );
  const svc = new ArbitrationService({ desk });
  const port = await svc.listen(0);
  closers.push(() => svc.close());
  const sent: string[] = [];
  const down = { on: false };
  return { url: `http://127.0.0.1:${port}`, desk, sent, down, cases: () => store.all(), attach: (c) => { chain = c; } };
}

/** A fetch that records every request body, and refuses connections while the desk is "down". */
const capturing = (d: Desk): typeof fetch => async (input, init) => {
  if (d.down.on) throw new TypeError('fetch failed');
  if (typeof init?.body === 'string') d.sent.push(init.body);
  return fetch(input, init);
};

function withDesk(d: Desk, o: Parameters<typeof harness>[0] = {}): Harness {
  const h = harness({
    ...o,
    tweak: (opts) => {
      opts.arbitration = { client: new ArbitrationClient(d.url, capturing(d)), signer: privateKeyToAccount(LP_KEY) };
      o.tweak?.(opts);
    },
  });
  d.attach(h.chain);
  return h;
}

/** A PIX order the taker paid, whose proof never came, disputed by the taker. */
/**
 * A paid order the node cannot prove (two witnesses missing), disputed by its taker. The proof stays unavailable:
 * a DISPUTED order is still released by a valid proof (SRM1-3), and these tests are about the evidence. `restore`
 * puts the witnesses back, as a restart needs them.
 */
async function disputedOrder(h: Harness): Promise<{
  orderId: Hex; brlCents: bigint; credit: ReturnType<Harness['bank']['receivePix']>; restore: () => void;
}> {
  await h.tick();
  const orderId = h.chain.lockOrder(h.node.offers!.status.get(NATIVE)!.activeOfferId!, 10n ** 17n);
  const brlCents = (await h.chain.order(orderId)).brlCents;
  const saved = h.witnesses.splice(0, 2);
  const credit = h.bank.receivePix({ amountCents: brlCents, creditedKey: LP_PIX_KEY, txid: pixTxidForOrder(orderId), payerId: '52998224725' });
  await h.tick();
  h.chain.raiseDisputeAs('onramp', orderId);
  return { orderId, brlCents, credit, restore: () => { h.witnesses.push(...saved); } };
}

describe('dispute evidence', () => {
  it('files a signed commitment to the credit the node matched - and nothing about the payment leaves the node', async () => {
    const d = await deskService();
    const h = withDesk(d, { offramp: false, confirmations: 1 });
    const { orderId, brlCents, credit } = await disputedOrder(h);
    await h.tick();

    const [rec] = await d.cases();
    expect(rec.case.orderId).toBe(orderId.toLowerCase());
    expect(rec.case.raisedBy).toBe('lp');
    expect(rec.case.evidence).toHaveLength(1);
    const ev = h.node.store.evidenceFor('onramp', orderId)!;
    expect(rec.case.evidence[0]).toMatchObject({ kind: 'pix-credit', submittedBy: 'lp', submitter: LP, digest: ev.items[0].digest });
    // The LP can regenerate the material from its journal, and it is what the digest commits to.
    const payment = h.node.store.getOrder(orderId)!.payment!;
    expect(evidenceCommitment('pix-credit', payment, ev.items[0].salt)).toBe(ev.items[0].digest);
    expect(evidenceMaterial('pix-credit', payment, ev.items[0].salt)).toContain(credit.bankTxId);

    const wire = d.sent.join('\n');
    // (Not the PIX txid: it is the order id's first 25 hex digits, and the order id is public and must name the case.)
    for (const secret of [LP_PIX_KEY, credit.bankTxId, '52998224725', ev.items[0].salt.slice(2), brlCents.toString(),
      ...[...h.node.store.offerSalts.values()].map((x) => x.salt.slice(2))]) {
      expect(wire).not.toContain(secret);
    }
    expect(wire).not.toContain('"uri"');
    expect(h.node.metrics.get('mova_lp_evidence_submitted_total', { leg: 'onramp' })).toBe(1);
  });

  it('files into the case the taker already opened, found by escrow and order, without trying to open another', async () => {
    const d = await deskService();
    const h = withDesk(d, { offramp: false, confirmations: 1 });
    const { orderId } = await disputedOrder(h);
    const opened = await d.desk.open({ orderId, escrow: ONRAMP, raisedBy: 'taker', reason: 'I paid' });
    await h.tick();
    expect(d.sent.some((b) => b.includes('"raisedBy"'))).toBe(false); // looked up, never opened
    expect(await d.cases()).toHaveLength(1);
    const rec = await d.desk.get(opened.caseId);
    expect(rec?.case.evidence.map((e) => e.submittedBy)).toEqual(['lp']);
    expect(h.node.store.evidenceFor('onramp', orderId)?.caseId).toBe(opened.caseId);
  });

  it('files a commitment to the LP\'s payout on a disputed sale, without the seller\'s key or the bank ids', async () => {
    const d = await deskService();
    const h = withDesk(d, { onramp: false, confirmations: 1 });
    const salt = newPixSalt();
    const saleId = h.chain.openSale({ amount: 10n ** 17n, brlCents: 198_000n, payeeKeyHash: pixKeyCommitment(SELLER_KEY, salt), railMask: railMask(Rail.PIX) });
    await h.node.offramp!.submitPayee(saleId, { pixKey: SELLER_KEY, salt });
    h.witnesses.splice(0, 2);
    await h.tick(); // claim
    await h.tick(); // pay; the proof fails
    expect(h.bank.outgoing).toHaveLength(1);
    h.chain.raiseDisputeAs('offramp', saleId);
    await h.tick();
    const [rec] = await d.cases();
    expect(rec.case.evidence).toMatchObject([{ kind: 'lp-payment', submittedBy: 'lp' }]);
    expect((await h.chain.sale(saleId)).state).toBe(SaleState.DISPUTED);
    const wire = d.sent.join('\n');
    for (const secret of [SELLER_KEY, salt.slice(2), h.bank.outgoing[0].result.bankTxId!, '198000']) expect(wire).not.toContain(secret);
  });

  it('files once: not again next tick, nor after a restart', async () => {
    const d = await deskService();
    const h = withDesk(d, { offramp: false, confirmations: 1 });
    const { orderId, restore } = await disputedOrder(h);
    await h.tick();
    const posts = d.sent.length;
    await h.tick();
    restore();
    h.restart();
    await h.tick();
    await h.tick();
    expect(d.sent.length).toBe(posts);
    expect((await d.cases())[0].case.evidence).toHaveLength(1);
    expect(h.node.store.evidenceFor('onramp', orderId)?.items[0].submitted).toBe(true);
  });

  it('a desk that is down is tried again, and the same commitment is filed once it is back', async () => {
    const d = await deskService();
    const h = withDesk(d, { offramp: false, confirmations: 1 });
    const { orderId } = await disputedOrder(h);
    d.down.on = true;
    await h.tick();
    await h.tick();
    expect(h.node.metrics.get('mova_lp_evidence_errors_total', { leg: 'onramp' })).toBe(2);
    const prepared = h.node.store.evidenceFor('onramp', orderId)!.items[0].digest;
    d.down.on = false;
    await h.tick();
    expect((await d.cases())[0].case.evidence.map((e: { digest: Hex }) => e.digest)).toEqual([prepared]);
  });

  it('a desk without the lookup by order is reported as too old, and nothing is guessed from its errors', async () => {
    // The unknown-route answer of arbitration-service.ts before the lookup existed.
    const old = createServer((rq, rs) => {
      rs.writeHead(404, { 'content-type': 'application/json' });
      rs.end(JSON.stringify({ error: 'not found', routes: ['GET /health', 'POST /cases', 'GET /cases/:id'] }));
    });
    await new Promise<void>((r) => old.listen(0, '127.0.0.1', () => r()));
    closers.push(() => new Promise<void>((r) => old.close(() => r())));
    const port = (old.address() as { port: number }).port;
    const client = new ArbitrationClient(`http://127.0.0.1:${port}`);
    const ref = { orderId: `0x${'ab'.repeat(32)}` as Hex, escrow: ONRAMP, leg: 'onramp' as const, chainId: 31337 };
    await expect(client.caseFor(ref)).rejects.toBeInstanceOf(ArbitrationDeskTooOld);
    await expect(client.caseFor(ref)).rejects.toThrow(/no case lookup by order .* upgrade it/);

    const d = await deskService();
    const h = withDesk(d, { offramp: false, confirmations: 1, tweak: (o) => { o.arbitration = { client, signer: privateKeyToAccount(LP_KEY) }; } });
    await disputedOrder(h);
    await h.tick();
    expect(h.node.metrics.get('mova_lp_evidence_errors_total', { leg: 'onramp', reason: 'desk_too_old' })).toBe(1);
    expect(h.logs.some((l) => /no case lookup by order/.test(l))).toBe(true);
  });

  it('what was prepared and filed survives a compacted journal', async () => {
    const d = await deskService();
    const h = withDesk(d, { offramp: false, confirmations: 1 });
    const { orderId } = await disputedOrder(h);
    await h.tick();
    const j = new MemoryJournal<LpRecord>();
    j.load();
    j.append(h.node.store.snapshot({ now: h.chain.time() }));
    const after = new Store(j);
    after.load();
    expect(after.evidenceFor('onramp', orderId)).toEqual(h.node.store.evidenceFor('onramp', orderId));
  });
});
