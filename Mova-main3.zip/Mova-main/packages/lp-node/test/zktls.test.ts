import { describe, expect, it } from 'vitest';
import type { Address, Hex } from 'viem';
import { generatePrivateKey, privateKeyToAccount } from 'viem/accounts';
import {
  Rail, boletoCommitment, brasiliaToday, buildBankBoleto, buildCollectionBoleto, decodeProof, encodeProof, hashProviderParams,
  newBoletoSalt, newPixSalt, parseBoleto, pixKeyCommitment, proofEndpoint, proofPayment, proofSigners, railMask, receiptTemplate,
  sortSignatures, type OrderTerms,
} from '@mova/ramp';
import { OrderState, SaleState } from '../src/abi.js';
import { ProofUnavailable } from '../src/attestation.js';
import { MockBank, bankTxIdHash } from '../src/bank.js';
import { ChainRevert, NATIVE } from '../src/chain.js';
import { PayeeError } from '../src/offramp.js';
import { pixTxidForOrder } from '../src/onramp.js';
import { LocalWitnessSession, ZkTlsProver, type ZkTlsSession } from '../src/zktls.js';
import { FAKE_DISPUTE_TIMEOUT, USDT } from './fake-chain.js';
import {
  LP_PIX_KEY, RECEIPT_TEMPLATES, VERIFIER, WITNESS_KEYS, ZKTLS_ENDPOINTS, ZKTLS_VERIFIER, allowZkTls, harness, type Harness,
} from './harness.js';

/**
 * zkTLS on the bank rails (zktls.ts): what `ZkTlsProver` refuses before a proof costs a transaction, and, through the
 * node against the fake escrows' ReclaimZkTlsVerifier checks, that PIX and boleto settle only this way on both ramps -
 * the quorum is refused for them - and that a proof is bound to the one order or sale it was made for.
 */

const SALT: Hex = `0x${'5a'.repeat(32)}`;
const PAYER_REF: Hex = `0x${'77'.repeat(32)}`;
const ORDER: Hex = `0x${'0a'.repeat(32)}`;
const OTHER: Hex = `0x${'0b'.repeat(32)}`;
const SELLER_KEY = 'vendedor@pix.example';
const WITNESSES = { addresses: WITNESS_KEYS.map((k) => privateKeyToAccount(k).address), threshold: 2 };
const sorted = (xs: readonly string[]) => xs.map((x) => x.toLowerCase()).sort();

/** A bank holding one PIX credit to the LP, a session over it, and a prover configured as the verifier is. */
function world(o: { session?: (s: LocalWitnessSession, bank: MockBank) => ZkTlsSession; keys?: Hex[] } = {}) {
  const bank = new MockBank({ now: () => 1_030n });
  const credit = bank.receivePix({ amountCents: 10_000n, creditedKey: LP_PIX_KEY });
  const keys = o.keys ?? [...WITNESS_KEYS];
  const local = new LocalWitnessSession({ witnessKeys: keys, receipts: bank, templates: RECEIPT_TEMPLATES, now: () => 1_031n });
  const prover = new ZkTlsProver(ZKTLS_VERIFIER, o.session ? o.session(local, bank) : local, { witnesses: WITNESSES, endpoints: ZKTLS_ENDPOINTS });
  const terms: OrderTerms = { orderId: ORDER, payeeKeyHash: pixKeyCommitment(LP_PIX_KEY, SALT), brlCents: 10_000n, lockedAt: 1_000n, acceptedRails: [Rail.PIX] };
  const claim = { bankTxId: credit.bankTxId, pixKey: LP_PIX_KEY, salt: SALT, payerRef: PAYER_REF, amountBrlCents: 10_000n, paidAt: credit.paidAt, leg: 'onramp' as const };
  return { bank, credit, keys, local, prover, terms, claim };
}

describe('ZkTlsProver: a claim about the bank\'s page, checked as the verifier will check it', () => {
  it('proves a PIX credit from the bank\'s own record: the received-payment page, bound to the order, signed by the witnesses', async () => {
    const w = world();
    // The node's claim is a pointer to the receipt: what is signed is what the bank's record says, not what the node recorded.
    const proof = decodeProof(await w.prover.provePix(w.terms, { ...w.claim, amountBrlCents: 99_999_999n, paidAt: 5n }));
    expect(proofPayment(proof)).toEqual({
      orderId: ORDER, bankTxId: bankTxIdHash(w.credit.bankTxId), payeeKeyHash: w.terms.payeeKeyHash, payerRef: PAYER_REF,
      amountBrlCents: 10_000n, paidAt: 1_030n, rail: Rail.PIX,
    });
    expect(proofEndpoint(proof).providerHash).toBe(hashProviderParams(RECEIPT_TEMPLATES['pix-received']));
    expect(sorted(await proofSigners(proof))).toEqual(sorted(WITNESSES.addresses));
    expect(w.prover.rails).toEqual([Rail.PIX, Rail.BOLETO]);
  });

  it('refuses a payment the bank does not show, and one that does not prove the order', async () => {
    const w = world();
    await expect(w.prover.provePix(w.terms, { ...w.claim, bankTxId: 'E00000000202609141200NOSUCHPIX1' }))
      .rejects.toThrow(/^the bank shows no settled PIX credit under that id$/);
    await expect(w.prover.provePix({ ...w.terms, brlCents: 10_001n }, w.claim)).rejects.toThrow(/attests 10000 centavos, less than the order's 10001/);
    await expect(w.prover.provePix({ ...w.terms, payeeKeyHash: pixKeyCommitment('outra@lp.example', SALT) }, w.claim))
      .rejects.toThrow(/attests a payment to another payee than the order commits to/);
    await expect(w.prover.provePix({ ...w.terms, acceptedRails: [Rail.BOLETO] }, w.claim)).rejects.toThrow(/a rail the order does not accept/);
  });

  it('refuses a claim bound to another order or sale before it costs a transaction', async () => {
    const w = world({ session: (s) => ({ prove: (req) => s.prove({ ...req, binding: OTHER }) }) });
    const attempt = w.prover.provePix(w.terms, w.claim);
    await expect(attempt).rejects.toBeInstanceOf(ProofUnavailable);
    await expect(attempt).rejects.toThrow(/bound to another order or sale \(OrderMismatch\)/);
  });

  it('refuses a claim signed by too few witnesses, or by keys outside the verifier\'s set', async () => {
    const few = world({ keys: [WITNESS_KEYS[0]] });
    await expect(few.prover.provePix(few.terms, few.claim)).rejects.toThrow(/1 distinct witness signature\(s\), 2 needed \(NotEnoughSignatures\)/);
    const stranger = world({ keys: [WITNESS_KEYS[0], generatePrivateKey()] });
    await expect(stranger.prover.provePix(stranger.terms, stranger.claim)).rejects.toThrow(/outside the verifier's witness set \(UnknownWitness\)/);
    const none = world({ keys: [] });
    await expect(none.prover.provePix(none.terms, none.claim)).rejects.toThrow(/^no witness answered$/);
  });

  it('refuses a page the verifier does not allowlist, or allowlists for another rail', async () => {
    const elsewhere = world({
      session: (_s, bank) => new LocalWitnessSession({
        witnessKeys: WITNESS_KEYS, receipts: bank, now: () => 1_031n,
        templates: { ...RECEIPT_TEMPLATES, 'pix-received': receiptTemplate('https://api.outro-banco.example/', 'pix-received') },
      }),
    });
    await expect(elsewhere.prover.provePix(elsewhere.terms, elsewhere.claim)).rejects.toThrow(/not allowlisted on the verifier \(EndpointNotAllowed\)/);

    // A boleto the LP registered, paid - proven from the PIX page's template, which may attest PIX alone.
    const bank = new MockBank({ now: () => 1_030n });
    const { line } = await bank.registerBoleto({ idempotencyKey: 'order-boleto-1', amountCents: 10_000n, dueDate: '2030-01-10' });
    const paid = bank.payRegisteredBoleto(line);
    const session = new LocalWitnessSession({
      witnessKeys: WITNESS_KEYS, receipts: bank, now: () => 1_031n, templates: { ...RECEIPT_TEMPLATES, 'boleto-received': RECEIPT_TEMPLATES['pix-received'] },
    });
    const prover = new ZkTlsProver(ZKTLS_VERIFIER, session, { witnesses: WITNESSES, endpoints: ZKTLS_ENDPOINTS });
    const terms: OrderTerms = { orderId: ORDER, payeeKeyHash: boletoCommitment(line, SALT), brlCents: 10_000n, lockedAt: 1_000n, acceptedRails: [Rail.BOLETO] };
    const claim = { bankTxId: paid.bankTxId, line, salt: SALT, payerRef: PAYER_REF, amountBrlCents: 10_000n, paidAt: paid.paidAt, leg: 'onramp' as const };
    await expect(prover.proveBoleto(terms, claim)).rejects.toThrow(/its page is not allowlisted for BOLETO \(RailNotAllowedForEndpoint\)/);
    // From the boleto page, it proves.
    const right = new ZkTlsProver(ZKTLS_VERIFIER, new LocalWitnessSession({ witnessKeys: WITNESS_KEYS, receipts: bank, templates: RECEIPT_TEMPLATES }), { witnesses: WITNESSES, endpoints: ZKTLS_ENDPOINTS });
    expect(proofPayment(decodeProof(await right.proveBoleto(terms, claim)))).toMatchObject({ rail: Rail.BOLETO, payeeKeyHash: terms.payeeKeyHash });
  });

  it('needs to know which page to open, and once it has proven one payment for an order it proves no other', async () => {
    const w = world();
    const { leg: _leg, ...withoutLeg } = w.claim;
    await expect(w.prover.provePix(w.terms, withoutLeg)).rejects.toThrow(/must say whether the LP received the payment \(onramp\) or made it \(offramp\)/);
    const first = await w.prover.provePix(w.terms, w.claim);
    const second = w.bank.receivePix({ amountCents: 10_000n, creditedKey: LP_PIX_KEY });
    await expect(w.prover.provePix(w.terms, { ...w.claim, bankTxId: second.bankTxId })).rejects.toThrow(/a different PIX payment than the one this node already proved for this order/);
    expect(decodeProof(await w.prover.provePix(w.terms, w.claim)).claimInfo).toEqual(decodeProof(first).claimInfo);
  });
});

/** Capture what the node submits to an escrow. */
function capture(h: Harness, fn: 'releaseWithProof' | 'settleWithProof'): Hex[] {
  const sent: Hex[] = [];
  const original = h.chain[fn].bind(h.chain);
  h.chain[fn] = async (id: Hex, proof: Hex) => { sent.push(proof); return original(id, proof); };
  return sent;
}

describe('bank rails settle on zkTLS only: the node, against the escrows\' checks', () => {
  it('on-ramp: a PIX offer naming a verifier that does not prove the bank session never posts - pulled before the post, or refused by the escrow', async () => {
    const h = harness({ offramp: false, tweak: (o) => { o.onramp!.assets[1].verifier = VERIFIER; } });
    await h.tick();
    expect(h.node.offers!.status.get(USDT.toLowerCase())).toMatchObject({ quoting: false, reason: 'bank_rail_needs_zktls' });
    expect(h.node.offers!.status.get(NATIVE)?.quoting).toBe(true);
    expect(h.chain.writes.filter((w) => w === 'postOffer')).toHaveLength(1);
    await expect(h.chain.postOffer({
      asset: USDT, amount: 100n * 10n ** 6n, priceBrlCentsPerUnit: 555n, pixKeyHash: pixKeyCommitment(LP_PIX_KEY, newPixSalt()),
      minOrder: 10n ** 6n, maxOrder: 10n ** 7n, verifier: VERIFIER, railMask: railMask(Rail.PIX),
    })).rejects.toMatchObject({ errorName: 'BankRailNeedsZkTls' });

    // With no prover for that verifier the node does try, and the escrow's refusal pulls the book instead of retrying.
    const bare = harness({
      offramp: false,
      tweak: (o) => { o.onramp!.assets[1].verifier = VERIFIER; o.provers = o.provers!.filter((p) => p.verifier === ZKTLS_VERIFIER); },
    });
    await bare.tick();
    expect(bare.node.offers!.status.get(USDT.toLowerCase())).toMatchObject({ quoting: false, reason: 'bank_rail_needs_zktls' });
  });

  it('on-ramp: the LP proves the PIX it received from its received-payment page, and a proof bound to one order releases no other', async () => {
    const h = harness({ offramp: false, confirmations: 1 });
    h.witnesses.splice(0, 2); // the node's own proof waits, so both orders stay locked
    await h.tick();
    const offerId = h.node.offers!.status.get(NATIVE)!.activeOfferId!;
    const [a, b] = [h.chain.lockOrder(offerId, 10n ** 17n), h.chain.lockOrder(offerId, 10n ** 17n)];
    await h.tick();
    const credit = h.bank.receivePix({ amountCents: (await h.chain.order(a)).brlCents, creditedKey: LP_PIX_KEY, txid: pixTxidForOrder(a) });
    await h.tick();
    expect(h.node.store.getOrder(a)?.payment?.bankTxId).toBe(credit.bankTxId);

    const salt = h.node.store.saltFor((await h.chain.offer(offerId)).pixKeyHash)!;
    const session = new LocalWitnessSession({ witnessKeys: WITNESS_KEYS, receipts: h.bank, templates: RECEIPT_TEMPLATES, now: () => h.chain.time() });
    const forA = encodeProof(await sortSignatures(await session.prove({
      leg: 'onramp', rail: Rail.PIX, receipt: 'pix-received', binding: a, bankTxId: credit.bankTxId, salt, payerRef: PAYER_REF,
    })));
    const refused = await h.chain.releaseWithProof(b, forA).catch((e: unknown) => e);
    expect(refused).toBeInstanceOf(ChainRevert);
    expect((refused as ChainRevert).errorName).toBe('OrderMismatch');

    const sent = capture(h, 'releaseWithProof');
    h.witnesses.push(...WITNESS_KEYS);
    await h.tick();
    expect((await h.chain.order(a)).state).toBe(OrderState.RELEASED);
    expect((await h.chain.order(b)).state).toBe(OrderState.LOCKED);
    const proof = decodeProof(sent[0]);
    expect(proofPayment(proof)).toMatchObject({ orderId: a, rail: Rail.PIX, bankTxId: bankTxIdHash(credit.bankTxId) });
    expect(proofEndpoint(proof).providerHash).toBe(hashProviderParams(RECEIPT_TEMPLATES['pix-received']));
  });

  it('off-ramp: a sale cannot name a verifier that does not prove the bank session, and a sale on a verifier with no prover here is never claimed', async () => {
    const h = harness({ onramp: false });
    const salt = newPixSalt();
    const sale = { amount: 10n ** 17n, brlCents: 198_000n, payeeKeyHash: pixKeyCommitment(SELLER_KEY, salt), railMask: railMask(Rail.PIX) };
    expect(() => h.chain.openSale({ ...sale, verifier: VERIFIER })).toThrow(expect.objectContaining({ errorName: 'BankRailNeedsZkTls' }));

    allowZkTls(h.chain, OTHER_ZKTLS, WITNESS_KEYS, 2);
    const saleId = h.chain.openSale({ ...sale, verifier: OTHER_ZKTLS });
    await h.node.offramp!.submitPayee(saleId, { pixKey: SELLER_KEY, salt });
    await h.tick();
    expect(h.node.offramp!.skipped.get(saleId.toLowerCase())).toBe('verifier_unsupported');
    expect(h.chain.writes).not.toContain('claimSale');
  });

  it('off-ramp PIX: the LP proves the PIX it sent, from its sent-payment page, bound to the sale', async () => {
    const h = harness({ onramp: false, confirmations: 1 });
    const salt = newPixSalt();
    const saleId = h.chain.openSale({ amount: 10n ** 17n, brlCents: 198_000n, payeeKeyHash: pixKeyCommitment(SELLER_KEY, salt), railMask: railMask(Rail.PIX) });
    const sent = capture(h, 'settleWithProof');
    await h.node.offramp!.submitPayee(saleId, { pixKey: SELLER_KEY, salt });
    await h.tick();
    await h.tick();
    expect((await h.chain.sale(saleId)).state).toBe(SaleState.SETTLED);
    const proof = decodeProof(sent[0]);
    expect(proofPayment(proof)).toMatchObject({
      orderId: saleId, rail: Rail.PIX, payeeKeyHash: pixKeyCommitment(SELLER_KEY, salt), amountBrlCents: 198_000n,
      bankTxId: bankTxIdHash(h.bank.outgoing[0].result.bankTxId!),
    });
    expect(proofEndpoint(proof)).toEqual({ providerHash: hashProviderParams(RECEIPT_TEMPLATES['pix-sent']), url: RECEIPT_TEMPLATES['pix-sent'].url });
    expect(sorted(await proofSigners(proof))).toEqual(sorted(WITNESSES.addresses));
  });

  it('off-ramp boleto: the LP proves the bill it paid, from its paid-bill page, which the verifier allowlists for BOLETO', async () => {
    const h = harness({ onramp: false, confirmations: 1 });
    const cents = 38_990n;
    const bill = buildBankBoleto({
      bankCode: '341', amountCents: cents, freeField: '1234567890123456789012345',
      dueDate: brasiliaToday(new Date(Number(h.chain.time() + 10n * 86_400n) * 1000)),
    });
    const salt = newBoletoSalt();
    const saleId = h.chain.openSale({
      amount: (cents * 10n ** 18n) / 1_970_000n, brlCents: cents, payeeKeyHash: boletoCommitment(bill, salt), railMask: railMask(Rail.BOLETO),
    });
    const sent = capture(h, 'settleWithProof');
    await h.node.offramp!.submitPayee(saleId, { boletoLine: bill.line, salt });
    await h.tick();
    await h.tick();
    expect(h.bank.outgoing[0]).toMatchObject({ kind: 'BOLETO', destination: bill.barcode, amountCents: cents });
    expect((await h.chain.sale(saleId)).state).toBe(SaleState.SETTLED);
    const proof = decodeProof(sent[0]);
    expect(proofPayment(proof)).toMatchObject({ orderId: saleId, rail: Rail.BOLETO, payeeKeyHash: boletoCommitment(bill, salt), amountBrlCents: cents });
    expect(proofEndpoint(proof).providerHash).toBe(hashProviderParams(RECEIPT_TEMPLATES['boleto-paid']));
  });

  it('off-ramp: at a bank that pays a bill only with its due date, a bill without one is not claimed, and one with one is', async () => {
    const h = harness({ onramp: false, confirmations: 1, bank: { boletoNeedsDueDate: true } });
    const cents = 38_990n;
    const due = brasiliaToday(new Date(Number(h.chain.time() + 10n * 86_400n) * 1000));
    const collection = buildCollectionBoleto({ segment: 3, valueIdentifier: 8, value: cents, rest: `0056${due.replace(/-/g, '')}00000000987654321` });
    expect(parseBoleto(collection.line).dueDate).toBeUndefined(); // a collection line carries no due date
    const dated = buildBankBoleto({ bankCode: '341', amountCents: cents, freeField: '1234567890123456789012345', dueDate: due });
    const open = (line: string, salt: Hex) => h.chain.openSale({
      amount: (cents * 10n ** 18n) / 1_970_000n, brlCents: cents, payeeKeyHash: boletoCommitment(line, salt), railMask: railMask(Rail.BOLETO),
    });
    const [s1, s2] = [newBoletoSalt(), newBoletoSalt()];
    const undatedSale = open(collection.line, s1);
    const datedSale = open(dated.line, s2);
    await h.node.offramp!.submitPayee(undatedSale, { boletoLine: collection.line, salt: s1 });
    await h.node.offramp!.submitPayee(datedSale, { boletoLine: dated.line, salt: s2 });
    await h.tick();
    await h.tick();
    expect(h.node.offramp!.skipped.get(undatedSale.toLowerCase())).toBe('boleto_no_due_date');
    expect((await h.chain.sale(undatedSale)).state).toBe(SaleState.OPEN);
    expect((await h.chain.sale(datedSale)).state).toBe(SaleState.SETTLED);
    expect(h.bank.outgoing).toHaveLength(1);
    expect(h.node.metrics.get('mova_lp_offramp_skipped_total', { reason: 'boleto_no_due_date' })).toBe(1);
  });

  it('off-ramp: the payee intake refuses a disclosure on a rail this node does not pay, and stores nothing', async () => {
    const cents = 38_990n;
    const pixOnly = harness({ onramp: false, tweak: (o) => { o.offramp!.rails = ['PIX']; } });
    const bill = buildBankBoleto({
      bankCode: '341', amountCents: cents, freeField: '1234567890123456789012345',
      dueDate: brasiliaToday(new Date(Number(pixOnly.chain.time() + 10n * 86_400n) * 1000)),
    });
    const salt = newBoletoSalt();
    const boletoSale = pixOnly.chain.openSale({
      amount: (cents * 10n ** 18n) / 1_970_000n, brlCents: cents, payeeKeyHash: boletoCommitment(bill, salt), railMask: railMask(Rail.BOLETO),
    });
    const refused = await pixOnly.node.offramp!.submitPayee(boletoSale, { boletoLine: bill.line, salt }).catch((e: unknown) => e);
    expect(refused).toBeInstanceOf(PayeeError);
    expect(refused).toMatchObject({ status: 422, message: 'this node does not pay boletos' });
    expect(pixOnly.node.store.getSale(boletoSale)?.payee).toBeUndefined();

    const boletoOnly = harness({ onramp: false, tweak: (o) => { o.offramp!.rails = ['BOLETO']; } });
    const pixSalt = newPixSalt();
    const pixSale = boletoOnly.chain.openSale({ amount: 10n ** 17n, brlCents: 198_000n, payeeKeyHash: pixKeyCommitment(SELLER_KEY, pixSalt), railMask: railMask(Rail.PIX) });
    await expect(boletoOnly.node.offramp!.submitPayee(pixSale, { pixKey: SELLER_KEY, salt: pixSalt })).rejects.toMatchObject({ status: 422, message: 'this node does not pay by PIX' });
  });
});

/** A second zkTLS verifier, for sales this node has the wrong prover for. */
const OTHER_ZKTLS: Address = '0x0000000000000000000000000000000000002c76';

describe('a dispute does not silence the node\'s proof (SRM1-3, SRM1-4)', () => {
  it('on-ramp: a taker\'s dispute frees the LP\'s credit at once, and the payment the node holds still releases the order', async () => {
    const h = harness({ offramp: false, confirmations: 1 });
    const saved = h.witnesses.splice(0, 2); // the proof is unavailable for now
    await h.tick();
    const offerId = h.node.offers!.status.get(NATIVE)!.activeOfferId!;
    const orderId = h.chain.lockOrder(offerId, 10n ** 17n);
    await h.tick();
    h.bank.receivePix({ amountCents: (await h.chain.order(orderId)).brlCents, creditedKey: LP_PIX_KEY, txid: pixTxidForOrder(orderId) });
    await h.tick();
    const before = (await h.chain.credit()).availableCents;
    h.chain.raiseDisputeAs('onramp', orderId);
    expect((await h.chain.credit()).availableCents).toBeGreaterThan(before);
    h.witnesses.push(...saved);
    await h.tick();
    expect((await h.chain.order(orderId)).state).toBe(OrderState.RELEASED);
    expect(h.node.store.getOrder(orderId)?.releasedTx).toBeDefined();
  });

  it('on-ramp: a credit that came after the order\'s window does not settle the dispute, and costs no transaction', async () => {
    const h = harness({ offramp: false, confirmations: 1 });
    await h.tick();
    const orderId = h.chain.lockOrder(h.node.offers!.status.get(NATIVE)!.activeOfferId!, 10n ** 17n);
    h.chain.raiseDisputeAs('onramp', orderId);
    const ord = await h.chain.order(orderId);
    h.bank.receivePix({ amountCents: ord.brlCents, creditedKey: LP_PIX_KEY, txid: pixTxidForOrder(orderId), paidAt: ord.payBy + 1n });
    h.chain.warp(31n * 60n);
    h.chain.mine();
    await h.tick();
    await h.tick();
    expect(h.chain.writes).not.toContain('releaseWithProof');
    expect((await h.chain.order(orderId)).state).toBe(OrderState.DISPUTED);
  });

  it('off-ramp: the seller disputes ahead of the LP\'s proof, and the proof still settles the sale', async () => {
    const h = harness({ onramp: false, confirmations: 1 });
    const salt = newPixSalt();
    const saleId = h.chain.openSale({ amount: 10n ** 17n, brlCents: 198_000n, payeeKeyHash: pixKeyCommitment(SELLER_KEY, salt), railMask: railMask(Rail.PIX) });
    await h.node.offramp!.submitPayee(saleId, { pixKey: SELLER_KEY, salt });
    const saved = h.witnesses.splice(0, 2);
    await h.tick(); // claim
    await h.tick(); // pay; the proof fails
    expect(h.bank.outgoing).toHaveLength(1);
    h.chain.raiseDisputeAs('offramp', saleId);
    h.witnesses.push(...saved);
    await h.tick();
    expect((await h.chain.sale(saleId)).state).toBe(SaleState.SETTLED);
    expect(h.chain.writes).not.toContain('raiseDispute'); // nothing left to dispute
  });

  it('off-ramp: after the dispute\'s deadline the node sends no proof - only the timeout applies', async () => {
    const h = harness({ onramp: false, confirmations: 1 });
    const salt = newPixSalt();
    const saleId = h.chain.openSale({ amount: 10n ** 17n, brlCents: 198_000n, payeeKeyHash: pixKeyCommitment(SELLER_KEY, salt), railMask: railMask(Rail.PIX) });
    await h.node.offramp!.submitPayee(saleId, { pixKey: SELLER_KEY, salt });
    const saved = h.witnesses.splice(0, 2);
    await h.tick();
    await h.tick();
    h.chain.raiseDisputeAs('offramp', saleId);
    h.chain.warp(FAKE_DISPUTE_TIMEOUT);
    h.chain.mine();
    h.witnesses.push(...saved);
    await h.tick();
    expect(h.chain.writes).not.toContain('settleWithProof');
    expect((await h.chain.sale(saleId)).state).toBe(SaleState.DISPUTED);
  });
});
