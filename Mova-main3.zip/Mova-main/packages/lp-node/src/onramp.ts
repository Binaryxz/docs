/**
 * The LP's side of an on-ramp order, from lock to the last centavo.
 *
 * ## What the contract actually asks of the LP
 *
 * Reading FiatEscrow, an LP's on-chain obligations are fewer than the flow suggests, and the
 * off-chain ones are where money is lost:
 *
 *  - **PIX/TED order** (`lockOrder`). Nothing on-chain is required. The taker has PAY_WINDOW (30
 *    minutes) from the lock to have payment proven; `releaseWithProof` is callable by anyone, and
 *    the crypto goes to the destination fixed at lock. But the taker cannot pay without knowing
 *    WHERE: the offer carries only a salted commitment to the LP's PIX key. So the LP must hand
 *    the taker its key, the salt (to check it opens the commitment) and the exact amount - this
 *    node serves that, as a BR Code, to the order's taker only (server.ts).
 *  - **Boleto order** (`lockOrderByBoleto`). The LP must register a boleto for exactly
 *    `brlCents` at its bank and commit to it with `issueBoleto` within one hour
 *    (BOLETO_ISSUE_WINDOW), then hand the taker line and salt. Missing the hour costs the LP
 *    nothing on-chain - the order expires back to the offer - but it is an SLA breach.
 *  - **Proof.** A PIX or boleto offer names a zkTLS verifier - `postOffer` refuses any other
 *    (`BankRailNeedsZkTls`) - and the LP, whose bank shows the credit, proves it: a zkTLS claim about
 *    its received-payment page, bound to the order id (`ZkTlsProver`, zktls.ts), submitted as a
 *    courier. Without a prover that proves the order's rail the node is passive here, and the taker
 *    may prove from their own bank session.
 *  - **Expiry.** An order not proven by `payBy` can be returned to the offer by anyone
 *    (`reclaimExpired`); until then its liquidity and credit stay reserved. The node reclaims its
 *    own. While an expired order is still LOCKED the taker may `raiseDispute`; after a reclaim it
 *    cannot.
 *  - **Disputes.** A dispute does not silence a proof (SRM1-3): a payment made inside the order's
 *    window, [lockedAt, payBy], still releases a DISPUTED order until `disputedAt + DISPUTE_TIMEOUT`,
 *    with the receipt's age taken at `disputedAt`. So the node keeps proving a payment it holds while
 *    the order is in dispute. A taker's dispute takes the order out of its offer and gives the LP's
 *    credit back at once (SRM1-4); if it then ends unpaid (REFUND, timeout) the liquidity is paid to
 *    the LP's wallet, not back into the offer. An LP's own dispute leaves both in the offer.
 *
 * ## Penalties, per the contract
 *
 * On this leg the LP owes the taker nothing an arbitrator could find it failed to pay: a REFUND
 * ruling records nothing against the LP, a taker's dispute that times out costs it nothing, and a
 * RELEASE counts as settled volume. What does cost the LP is holding BRL for an order that did
 * not release - that money is the taker's. So the rule here is: BRL matched to an order that ends
 * CANCELLED (expired, cancelled, refunded by ruling or timeout) is refunded to its payer, and only
 * once the cancellation is confirmed - a refund sent while the order could still be released by a
 * dispute ruling would pay the taker twice.
 *
 * ## Matching a credit to an order
 *
 * A PIX credit matches by txid first: the BR Code the node serves carries one derived from the
 * order id, as the wallet derives it (`BrlWallet.paymentInstructions`). A credit without a txid
 * matches only if its amount equals exactly one open order's and it post-dates that order's lock;
 * anything ambiguous is left for a human and counted in `mova_lp_unreconciled_credits`, because
 * guessing wrong proves one taker's payment against another taker's order. A boleto credit matches
 * the order whose registered barcode it paid.
 *
 * ## PIX charges (`pixCharge: "cob"`)
 *
 * Some PSPs' API Pix lists only Pix paid to a charge (Banco Inter documents `GET /pix` so), and a credit to the static
 * code above may never be seen there. In `cob` mode each PIX order gets an API Pix immediate charge instead (API Pix
 * 2.10.0 `PUT /cob/{txid}`; Manual de Padrões para Iniciação do Pix 2.10.0 §2.7; both read 2026-09-14):
 *
 *  - **Only for a lock N blocks deep**, as a boleto: a charge is a document a payer's bank app will pay.
 *  - **The txid is derived** - `idempotencyKey('order-cob', chainId, escrow, orderId)`, 33 of the 26-35 letters and
 *    digits a cob txid may have, one per order for good (Annex I §5.3.1 forbids reuse, even after removal) - and
 *    fsynced (`order.cob.intent`) BEFORE the PSP is called. Any later attempt, and every restart, asks `GET /cob/{txid}`
 *    first and PUTs only when the PSP has none, so a lost response or a crash never makes a second charge (a repeated
 *    PUT is idempotent by the spec besides, Annex I footnote 85).
 *  - **The charge is the order**: `valor.original` = `brlCents` with `modalidadeAlteracao` 0, `chave` = the LP's key,
 *    `calendario.expiracao` ending `cobMarginSeconds` before `payBy` by the later of the chain's and the wall clock.
 *    What the PSP returns is checked against that - txid, amount, fixed, key, expiry by `payBy`, a location and a
 *    code - and a charge that differs is removed and the order held.
 *  - **Instructions** carry the PSP's `pixCopiaECola`, its `location`, the `txid` and `expiresAt`, beside the key and
 *    salt that open the offer's commitment; the wallet reads the signed payload at the location and checks it names
 *    that key, the amount and the txid (@mova/wallet pix-cob.ts). 409 until the charge exists.
 *  - **Matching is by the charge's txid only**: in `cob` mode nothing is matched by amount.
 *  - **An order that ends without releasing** - cancelled, expired, or a lock reorged away - has its charge removed
 *    (`PATCH /cob/{txid}` to `REMOVIDA_PELO_USUARIO_RECEBEDOR`) once that is N blocks deep; a credit that lands anyway
 *    is refunded like any other. A released order's charge is closed too (normally it is `CONCLUIDA` already).
 *
 * A PIX webhook (server.ts) only says which end-to-end ids to look at: `hint` queues them, the next match
 * fetches each from the bank itself (`getIncoming`), and the webhook body's amounts, keys and txids are
 * never used. Polling `listIncoming` stays the source of truth; a lost or forged webhook costs latency or
 * one bank lookup, nothing else.
 *
 * ## Per-payer caps
 *
 * With a `caps` section configured (caps.ts), the credit matched to an order is the first and only
 * moment this node knows WHO is buying - nothing before it identifies a person without linking
 * addresses, which this rail exists not to do. So the cap is decided there, in `release`, before any
 * proof is fetched and before the asset moves: allowed, the credit is counted against that payer's
 * Brasília day; refused, the order is left to expire and the BRL is refunded to its payer on the
 * cancellation path below, which gives the payer's allowance back. A node with no caps configured
 * takes none of these branches.
 */
import type { Address, Hex } from 'viem';
import {
  Rail, assertPayableBoleto, boletoCommitment, brasiliaToday, newBoletoSalt, normalizePixKey,
  parseBoleto, railsFromMask,
} from '@mova/ramp';
import { buildPixBrCode, formatReais } from '@mova/wallet';
import { ONRAMP_RECEIPT_MAX_AGE, OrderState } from './abi.js';
import { payerRef } from './attestation.js';
import type { IncomingPayment, PixCharge } from './bank.js';
import { CAP_REFUSAL_CODE, UNKNOWN_PAYER_REFUSAL_CODE, capRefusalMessage } from './caps.js';
import type { EvidenceItem } from './evidence.js';
import {
  ChainRevert, sameAddress, type OnChainBoleto, type OnChainOffer, type OnChainOrder, type RampEvent,
} from './chain.js';
import { errorText, short, type NodeContext, type TickView } from './context.js';
import { idempotencyKey, type OrderTrack } from './store.js';

export interface OnrampOptions {
  escrow: Address;
  /** The LP's PIX key, the one every offer commits to. */
  pixKey: string;
  /** Shown in the BR Code; bank apps display it to the payer. */
  receiver: { name: string; city: string };
  /** Return expired, unproven orders to the offer. */
  reclaimExpired: boolean;
  /** Refund, by PIX devolução, BRL received for orders that ended cancelled. */
  autoRefund: boolean;
  /** Due date of registered boletos, in days from issue. BOLETO_PAY_WINDOW is three. */
  boletoDueDays: number;
  /** An order id that reads NONE this many blocks after it was seen was reorged away. */
  reorgWindow: bigint;
  /** Keep a cancelled order matchable this long after its deadline, for a late payment. */
  lateCreditGraceSeconds: number;
  /**
   * How a PIX order is charged: `static` (the default) serves a BR Code for `pixKey` built here; `cob` creates an API
   * Pix immediate charge per order and serves the PSP's dynamic BR Code. `cob` is required where the PSP's API Pix
   * lists only charge-paid Pix (Banco Inter), and needs a bank adapter with `createCharge` and `getCharge`.
   */
  pixCharge?: 'static' | 'cob';
  /** With `cob`: a charge expires this long before `payBy`. Default 300. */
  cobMarginSeconds?: number;
}

/** The PIX txid for an order, exactly as `BrlWallet.paymentInstructions` derives it. */
export function pixTxidForOrder(orderId: string): string {
  return orderId.replace(/^0x/, '').replace(/[^A-Za-z0-9]/g, '').slice(0, 25);
}

/**
 * The txid of an order's API Pix charge (`pixCharge: "cob"`): 33 of the 26-35 letters and digits a cob txid may have,
 * from the chain, the escrow and the order - as @mova/wallet's `pixCobTxidForOrder` derives it.
 */
export function pixCobTxidForOrder(chainId: number, escrow: Address, orderId: Hex): string {
  return idempotencyKey('order-cob', chainId, escrow, orderId);
}

export type PaymentInstructions =
  | {
    rail: 'PIX'; orderId: Hex; amountCents: string; amount: string; pixKey: string; salt: Hex;
    payeeCommitment: Hex; txid: string; pixCopiaECola: string; receiver: { name: string; city: string };
    payBy: number;
    /**
     * Present for an API Pix charge (`pixCharge: "cob"`): `pixCopiaECola` is then the PSP's dynamic BR Code, `location`
     * the URL in it (no protocol prefix), `txid` the charge's, and `expiresAt` its expiry (unix seconds, the PSP's clock).
     */
    charge?: 'cob'; location?: string; expiresAt?: number;
  }
  | {
    rail: 'BOLETO'; orderId: Hex; amountCents: string; amount: string; line: string; salt: Hex;
    commitment: Hex; payBy: number;
  };

export class InstructionsError extends Error {
  /** A stable code the wallet can act on, beside the sentence; absent where only the sentence matters. */
  constructor(readonly status: number, message: string, readonly code?: string) { super(message); }
}

const UNRECONCILED_AFTER_SECONDS = 300n;
const DEFAULT_COB_MARGIN_SECONDS = 300;
/** A charge with less time than this to run is not worth creating: the order expires instead. */
const MIN_COB_SECONDS = 60n;

export class OnrampHandler {
  /** Recent credits that match no order; bank ids only, for a human to look up. */
  unreconciled: { bankTxId: string; amountCents: bigint; paidAt: bigint }[] = [];
  private readonly warned = new Set<string>();
  /** Disputed orders whose proof the escrow refused: not proven again; the desk or the timeout decides them. */
  private readonly refusedInDispute = new Set<string>();
  /** Whether an order was locked by boleto: fixed at lock, so read once. */
  private readonly boletoOrder = new Map<string, boolean>();
  private readonly pixKey: string;
  /** End-to-end ids a webhook named, to fetch from the bank at the next match. Bounded. */
  private readonly hints = new Set<string>();
  static readonly MAX_HINTS = 1_000;

  constructor(private readonly ctx: NodeContext, private readonly o: OnrampOptions) {
    this.pixKey = normalizePixKey(o.pixKey).key;
  }

  /** Start following my offers and the orders locked against them. */
  onEvents(events: readonly RampEvent[]): void {
    const { store, chain } = this.ctx;
    for (const e of events) {
      if (e.kind === 'OfferPosted' && sameAddress(e.lp, chain.account) && !store.isMyOffer(e.offerId)) {
        store.record({ t: 'offer.mine', offerId: e.offerId });
      } else if (e.kind === 'OrderLocked' && store.isMyOffer(e.offerId) && !store.getOrder(e.orderId)) {
        store.record({ t: 'order.seen', orderId: e.orderId, offerId: e.offerId, block: e.block });
        this.ctx.log.info(`on-ramp: order ${short(e.orderId)} locked against ${short(e.offerId)} for ${e.brlCents} centavos`);
      }
    }
  }

  async tick(view: TickView): Promise<void> {
    const { chain, store, metrics } = this.ctx;
    const open = store.openOrders();
    const read: { t: OrderTrack; ord: OnChainOrder }[] = [];
    for (const t of open) {
      try {
        read.push({ t, ord: await chain.order(t.orderId) });
      } catch (e) {
        metrics.inc('mova_lp_tick_errors_total', { stage: 'onramp_read' });
        this.ctx.log.error(`on-ramp: reading ${short(t.orderId)}: ${errorText(e)}`);
      }
    }

    await this.reconcile(read, view);

    metrics.reset('mova_lp_onramp_orders');
    for (const { t, ord } of read) {
      metrics.inc('mova_lp_onramp_orders', { state: OrderState[ord.state] ?? 'UNKNOWN' });
      if (t.hold) continue;
      try {
        await this.step(t, ord, view);
      } catch (e) {
        metrics.inc('mova_lp_tick_errors_total', { stage: 'onramp' });
        this.ctx.log.error(`on-ramp: order ${short(t.orderId)}: ${errorText(e)}`);
      }
    }
  }

  /*//////////////////////////////////////////////////////////////
                               MATCHING
  //////////////////////////////////////////////////////////////*/

  /** Queue bank ids a webhook named. Returns how many were new. Nothing about the payment is taken from the caller. */
  hint(bankTxIds: readonly string[]): number {
    let added = 0;
    for (const id of bankTxIds) {
      if (this.hints.size >= OnrampHandler.MAX_HINTS) break;
      if (this.ctx.store.consumedCredits.has(id) || this.hints.has(id)) continue;
      this.hints.add(id);
      added++;
    }
    return added;
  }

  private async reconcile(read: { t: OrderTrack; ord: OnChainOrder }[], view: TickView): Promise<void> {
    const { bank, store, metrics } = this.ctx;
    const matchable: typeof read = [];
    for (const x of read) {
      if (!(x.ord.state === OrderState.LOCKED || x.ord.state === OrderState.CANCELLED || x.ord.state === OrderState.DISPUTED)) continue;
      matchable.push(x);
    }
    if (matchable.length === 0) {
      this.hints.clear(); // nothing a credit could pay: polling will see it if an order appears
      this.unreconciled = [];
      metrics.set('mova_lp_unreconciled_credits', 0);
      return;
    }
    const since = matchable.reduce((m, { ord }) => (ord.lockedAt < m ? ord.lockedAt : m), matchable[0].ord.lockedAt) - 600n;
    let credits: IncomingPayment[];
    try {
      credits = await bank.listIncoming({ since });
    } catch (e) {
      metrics.inc('mova_lp_bank_errors_total', { op: 'listIncoming' });
      throw e;
    }
    // Webhook hints: each id looked up at the bank, once. A listing that already has it needs no lookup.
    const hinted = [...this.hints];
    this.hints.clear();
    if (bank.getIncoming) {
      const listed = new Set(credits.map((c) => c.bankTxId));
      for (const id of hinted) {
        if (listed.has(id)) continue;
        try {
          const c = await bank.getIncoming(id);
          if (c) credits.push(c);
        } catch {
          metrics.inc('mova_lp_bank_errors_total', { op: 'getIncoming' });
        }
      }
    }
    const boletoOrders = new Map<string, OrderTrack>();
    for (const { t } of matchable) {
      if (t.boleto?.line) boletoOrders.set(parseBoleto(t.boleto.line).barcode, t);
    }

    const unmatched: IncomingPayment[] = [];
    for (const c of [...credits].sort((a, b) => (a.paidAt < b.paidAt ? -1 : a.paidAt > b.paidAt ? 1 : 0))) {
      if (store.consumedCredits.has(c.bankTxId)) continue;
      let target: OrderTrack | undefined;
      if (c.rail === 'BOLETO') {
        const barcode = c.boletoLine ? safeBarcode(c.boletoLine) : undefined;
        target = barcode ? boletoOrders.get(barcode) : undefined;
      } else {
        if (c.creditedKey && safeKey(c.creditedKey) !== this.pixKey) continue; // not the ramp's key
        // An order with a charge is paid under the charge's txid and only that; any other under its static code's.
        const byTxid = c.txid && c.txid !== '***'
          ? matchable.find(({ t }) => (t.cob ? t.cob.txid : pixTxidForOrder(t.orderId)) === c.txid)
          : undefined;
        if (byTxid) {
          target = byTxid.t;
        } else if ((!c.txid || c.txid === '***') && this.o.pixCharge !== 'cob') {
          const byAmount = [];
          for (const x of matchable) {
            if (x.t.payment || x.t.cob || x.ord.state !== OrderState.LOCKED || x.ord.brlCents !== c.amountCents) continue;
            if (c.paidAt < x.ord.lockedAt || c.paidAt > x.ord.payBy) continue;
            // A PIX credit cannot pay a boleto order, even before its boleto is registered.
            if (await this.isBoletoOrder(x.t.orderId)) continue;
            byAmount.push(x);
          }
          if (byAmount.length === 1) target = byAmount[0].t;
        }
      }
      if (target && !target.payment) {
        store.record({ t: 'order.payment', orderId: target.orderId, payment: c });
        metrics.inc('mova_lp_onramp_brl_received_cents_total', {}, Number(c.amountCents));
        this.ctx.log.info(`on-ramp: ${c.rail} credit of ${c.amountCents} centavos matched to ${short(target.orderId)}`);
      } else if (view.wallNow > c.paidAt + UNRECONCILED_AFTER_SECONDS) {
        unmatched.push(c);
      }
    }
    this.unreconciled = unmatched.map((c) => ({ bankTxId: c.bankTxId, amountCents: c.amountCents, paidAt: c.paidAt }));
    metrics.set('mova_lp_unreconciled_credits', unmatched.length);
  }

  private async isBoletoOrder(orderId: Hex): Promise<boolean> {
    const k = orderId.toLowerCase();
    let v = this.boletoOrder.get(k);
    if (v === undefined) {
      v = (await this.ctx.chain.boleto(orderId)).issueBy !== 0n;
      this.boletoOrder.set(k, v);
    }
    return v;
  }

  /*//////////////////////////////////////////////////////////////
                              PER ORDER
  //////////////////////////////////////////////////////////////*/

  private async step(t: OrderTrack, ord: OnChainOrder, view: TickView): Promise<void> {
    switch (ord.state) {
      case OrderState.NONE:
        // Seen in a log, absent from storage: the lock was reorged away (or never mined).
        if (view.head.number > t.seenBlock + this.o.reorgWindow) {
          if (t.boleto?.bankRef && !t.boleto.cancelled) await this.cancelBoleto(t);
          if (t.cob && !t.cob.closed) await this.closeCharge(t);
          this.ctx.store.record({ t: 'order.done', orderId: t.orderId, state: OrderState.NONE });
        }
        return;
      case OrderState.LOCKED:
        return this.locked(t, ord, view);
      case OrderState.RELEASED:
        this.countCapRefusedButReleased(t, view);
        // Paid, so normally CONCLUIDA already; one released by some other payment must not take a second.
        if (t.cob && !t.cob.closed) await this.closeCharge(t);
        this.ctx.store.record({ t: 'order.done', orderId: t.orderId, state: OrderState.RELEASED });
        return;
      case OrderState.CANCELLED:
        return this.cancelled(t, ord, view);
      case OrderState.DISPUTED: {
        const items: EvidenceItem[] = [];
        if (t.payment) items.push({ kind: t.payment.rail === 'BOLETO' ? 'boleto-credit' : 'pix-credit', facts: t.payment });
        this.once(`dispute:${t.orderId}`, () => this.ctx.log.warn(
          `on-ramp: order ${short(t.orderId)} is DISPUTED; the arbitration desk decides it`
          + (items.length === 0 ? ', and this node holds no payment for it'
            : this.ctx.evidence ? '; filing commitments to the payment it holds' : ' (a payment was received: file it as evidence by hand)'),
        ));
        if (this.ctx.evidence && items.length) await this.ctx.evidence.disputed('onramp', this.o.escrow, t.orderId, items);
        // A dispute does not silence a proof (SRM1-3): a payment this node holds, made inside the order's window,
        // still releases the order until the dispute's deadline - whoever disputed it.
        const fresh = this.ctx.store.getOrder(t.orderId)!;
        if (fresh.payment && !fresh.releasedTx && !this.refusedInDispute.has(t.orderId.toLowerCase())) {
          const { chain } = this.ctx;
          const [offer, bol, d] = await Promise.all([
            chain.offer(ord.offerId), chain.boleto(t.orderId), chain.dispute('onramp', t.orderId),
          ]);
          if (view.chainNow < d.deadline) await this.release(fresh, ord, offer, bol, view, d.disputedAt);
        }
        return;
      }
      default:
        return;
    }
  }

  private async locked(t: OrderTrack, ord: OnChainOrder, view: TickView): Promise<void> {
    const { chain } = this.ctx;
    const [offer, bol] = await Promise.all([chain.offer(ord.offerId), chain.boleto(t.orderId)]);

    if (view.chainNow > ord.payBy) {
      // Too late for any proof. Return the liquidity; a matched payment is refunded once the
      // cancellation is confirmed (see `cancelled`).
      if (this.o.reclaimExpired) await this.reclaim(t);
      return;
    }
    if (bol.issueBy !== 0n) await this.ensureBoleto(t, ord, bol, view);
    else if (this.o.pixCharge === 'cob' && !t.cob?.location) await this.ensureCharge(t, ord, view);
    const fresh = this.ctx.store.getOrder(t.orderId)!;
    if (fresh.payment && !fresh.releasedTx) await this.release(fresh, ord, offer, await chain.boleto(t.orderId), view);
  }

  private async ensureBoleto(t: OrderTrack, ord: OnChainOrder, bol: OnChainBoleto, view: TickView): Promise<void> {
    const { chain, bank, store, metrics, log } = this.ctx;
    if (bol.issuedAt !== 0n) return;
    if (view.chainNow > bol.issueBy) return; // the hour passed; the order will expire, costing nothing
    if (!bank.registerBoleto) {
      return this.hold(t, 'a boleto order was locked but the bank adapter cannot register boletos: drop BOLETO from the offer rails');
    }
    // A boleto is an off-chain document the payer can pay; register it only for a lock that
    // survives the reorg window.
    const confirmed = await chain.order(t.orderId, view.confirmedBlock);
    if (confirmed.state !== OrderState.LOCKED) return;

    if (!t.boleto) {
      store.record({
        t: 'order.boleto.intent', orderId: t.orderId,
        idempotencyKey: idempotencyKey('order-boleto', chain.chainId, this.o.escrow, t.orderId), salt: newBoletoSalt(),
      });
    }
    const b = store.getOrder(t.orderId)!.boleto!;
    if (!b.line) {
      const now = new Date(Number(view.wallNow) * 1000);
      const dueDate = brasiliaToday(new Date(now.getTime() + this.o.boletoDueDays * 86_400_000));
      let reg;
      try {
        reg = await bank.registerBoleto({ idempotencyKey: b.idempotencyKey, amountCents: ord.brlCents, dueDate, reference: t.orderId });
      } catch (e) {
        metrics.inc('mova_lp_bank_errors_total', { op: 'registerBoleto' });
        throw e;
      }
      try {
        // The bank's line must be the document asked for: exactly this amount, not overdue.
        assertPayableBoleto(reg.line, ord.brlCents, { now });
      } catch (e) {
        if (bank.cancelBoleto) await bank.cancelBoleto(reg.bankRef).catch(() => undefined);
        return this.hold(t, `the bank registered a boleto that does not match the order: ${errorText(e)}`);
      }
      store.record({
        t: 'order.boleto.registered', orderId: t.orderId, bankRef: reg.bankRef, line: reg.line,
        commitment: boletoCommitment(reg.line, b.salt),
      });
    }
    const reg = store.getOrder(t.orderId)!.boleto!;
    try {
      const r = await chain.issueBoleto(t.orderId, reg.commitment!);
      store.record({ t: 'order.boleto.issued', orderId: t.orderId, tx: r.hash });
      metrics.inc('mova_lp_boletos_issued_total');
      log.info(`on-ramp: boleto issued for ${short(t.orderId)}`);
    } catch (e) {
      if (e instanceof ChainRevert && e.errorName === 'BadBoleto') {
        return this.hold(t, 'the escrow refused the boleto commitment (already used)');
      }
      throw e;
    }
  }

  /** `pixCharge: "cob"`: the order's API Pix charge, created once, for a confirmed lock. See the header. */
  private async ensureCharge(t: OrderTrack, ord: OnChainOrder, view: TickView): Promise<void> {
    const { chain, bank, store, metrics, log } = this.ctx;
    if (!bank.createCharge || !bank.getCharge) {
      return this.hold(t, 'pixCharge is "cob" but the bank adapter cannot create PIX charges (createCharge/getCharge): use an API Pix receiver, or pixCharge "static"');
    }
    // A charge is a document a payer's bank app pays: only for a lock that survives the reorg window.
    const confirmed = await chain.order(t.orderId, view.confirmedBlock);
    if (confirmed.state !== OrderState.LOCKED) return;
    const deadline = ord.payBy - BigInt(this.o.cobMarginSeconds ?? DEFAULT_COB_MARGIN_SECONDS);
    // The PSP counts expiracao from its own clock: start from the later of the chain's and the wall's.
    const expiresIn = deadline - (view.wallNow > view.chainNow ? view.wallNow : view.chainNow);

    let fresh = false;
    if (!t.cob) {
      if (expiresIn < MIN_COB_SECONDS) return; // too late to pay and prove: nothing is created, the order expires
      store.record({ t: 'order.cob.intent', orderId: t.orderId, txid: pixCobTxidForOrder(chain.chainId, this.o.escrow, t.orderId) });
      fresh = true;
    }
    const { txid } = store.getOrder(t.orderId)!.cob!;
    let charge: PixCharge | undefined;
    try {
      // Not the first attempt: the PSP may already hold it (a lost response, a crash before the record). Ask first.
      if (!fresh) charge = await bank.getCharge(txid);
      if (!charge) {
        if (expiresIn < MIN_COB_SECONDS) return;
        charge = await bank.createCharge({ txid, amountCents: ord.brlCents, pixKey: this.pixKey, expiresInSeconds: Number(expiresIn) });
      }
    } catch (e) {
      metrics.inc('mova_lp_bank_errors_total', { op: 'createCharge' });
      throw e;
    }
    const problem = charge.txid !== txid ? 'another txid'
      : charge.amountCents !== ord.brlCents ? 'another amount'
        : !charge.amountFixed ? 'an amount the payer may change'
          : safeKey(charge.pixKey) !== this.pixKey ? 'another PIX key'
            : charge.expiresAt > ord.payBy ? 'an expiry after the order\'s pay window'
              : !charge.location || !charge.pixCopiaECola ? 'no location or BR Code'
                : charge.status === 'REMOVIDA_PELO_USUARIO_RECEBEDOR' || charge.status === 'REMOVIDA_PELO_PSP' ? `status ${charge.status}`
                  : undefined;
    if (problem) {
      const removable = charge.status === 'ATIVA' && !!bank.cancelCharge;
      if (removable) await bank.cancelCharge!(txid).catch(() => undefined);
      return this.hold(t, `the PSP holds a charge for this order with ${problem}${removable ? '; removed it' : ''}: its txid cannot be reused, so the order is left to expire`);
    }
    store.record({
      t: 'order.cob.created', orderId: t.orderId, location: charge.location!, pixCopiaECola: charge.pixCopiaECola!,
      expiresAt: charge.expiresAt, amountCents: charge.amountCents, revisao: charge.revisao,
    });
    log.info(`on-ramp: PIX charge ready for ${short(t.orderId)}, expiring ${charge.expiresInSeconds}s after creation`);
  }

  /** Stop the order's charge taking payments (`PATCH` to `REMOVIDA_PELO_USUARIO_RECEBEDOR`), and record how it ended. */
  private async closeCharge(t: OrderTrack): Promise<void> {
    const { bank, store, metrics, log } = this.ctx;
    // Without cancelCharge the charge still expires cobMarginSeconds before payBy; a payment before that is refunded.
    if (!t.cob || t.cob.closed || !bank.cancelCharge) return;
    let status;
    try {
      status = await bank.cancelCharge(t.cob.txid);
    } catch (e) {
      metrics.inc('mova_lp_bank_errors_total', { op: 'cancelCharge' });
      throw e;
    }
    store.record({ t: 'order.cob.closed', orderId: t.orderId, status: status ?? 'NONE' });
    if (status === 'REMOVIDA_PELO_USUARIO_RECEBEDOR') log.info(`on-ramp: removed the unpaid PIX charge of ${short(t.orderId)}`);
  }

  /**
   * The per-payer cap, decided once for this order and fsynced. Returns true when the order may go on.
   * The decision is taken here, at the credit, because a credit is the first thing that names a person -
   * and before any proof, so a refusal costs the LP's asset nothing.
   */
  private async capAllows(t: OrderTrack, p: IncomingPayment, view: TickView): Promise<boolean> {
    const { caps, store, log } = this.ctx;
    if (!caps) return true;
    const decided = store.getOrder(t.orderId)?.cap;
    if (decided?.refused) return false;
    if (decided?.counted) return true;
    const verdict = await caps.check(
      { leg: 'onramp', rail: p.rail, payerId: p.payerId }, p.amountCents, view.wallNow,
    );
    if (!verdict.ok) {
      // No count: nothing moved for this payer, and the BRL goes back on the cancellation path.
      store.record({ t: 'order.cap', orderId: t.orderId, decision: 'refused', day: verdict.day, period: verdict.period });
      log.warn(`on-ramp: ${short(t.orderId)} is not released: ${verdict.period === 'unknown_payer'
        ? 'the bank named no payer for its credit, and this node applies per-payer caps'
        : `the payer's ${verdict.period === 'day' ? 'daily' : 'monthly'} limit of ${verdict.limitCents} centavos is reached`}`
        + '; it will expire and the BRL be refunded');
      return false;
    }
    // Nobody to hold it against (`unknownPayer: "allow"`, or nothing limited): let it through, uncounted.
    if (!verdict.payer) return true;
    // Counted first, marked second: a crash between them counts twice, which refuses more, never less.
    const day = caps.count(verdict.payer, p.amountCents, view.wallNow, 'onramp');
    store.record({ t: 'order.cap', orderId: t.orderId, decision: 'counted', day, cents: p.amountCents });
    return true;
  }

  /**
   * An order this node refused on a cap that released all the same. `releaseWithProof` is permissionless and
   * a taker who paid can prove it from their own bank session, so the LP keeps the BRL and the crypto is
   * gone. It is counted - otherwise the payer's next purchase would find their whole allowance free, and the
   * cap would be defeated by paying and proving.
   */
  private countCapRefusedButReleased(t: OrderTrack, view: TickView): void {
    const { caps, store, log } = this.ctx;
    const o = store.getOrder(t.orderId);
    if (!caps || !o?.cap?.refused || o.cap.counted) return;
    const cents = o.payment?.amountCents;
    const payer = caps.identify(o.payment?.payerId);
    if (!payer || cents === undefined) return;
    const day = caps.count(payer, cents, view.wallNow, 'onramp');
    store.record({ t: 'order.cap', orderId: t.orderId, decision: 'counted', day, cents });
    log.warn(`on-ramp: ${short(t.orderId)} was over its payer's cap and released anyway - releaseWithProof is `
      + 'permissionless, and the taker proved their own bank session. This LP keeps the BRL, so the payment is counted against that payer');
  }

  /** A refunded payment did not consume anyone's allowance: give it back, once. */
  private uncountRefund(t: OrderTrack): void {
    const { caps, store } = this.ctx;
    const cap = store.getOrder(t.orderId)?.cap;
    if (!caps || !cap?.counted || cap.uncounted) return;
    const payer = caps.identify(t.payment?.payerId);
    if (!payer) return;
    caps.uncount(payer, cap.counted.cents, cap.counted.day, 'onramp');
    store.record({ t: 'order.cap.uncounted', orderId: t.orderId });
  }

  /**
   * `frozenAt`: for a DISPUTED order, when the dispute froze it. The escrow then takes the receipt's age at that
   * moment, and the payment must still have been made by `payBy` (SRM1-3).
   */
  private async release(
    t: OrderTrack, ord: OnChainOrder, offer: OnChainOffer, bol: OnChainBoleto, view: TickView, frozenAt?: bigint,
  ): Promise<void> {
    const { chain, store, provers, metrics, log } = this.ctx;
    const asOf = frozenAt ?? view.chainNow;
    const p = t.payment!;
    if (!(await this.capAllows(t, p, view))) return;
    const boleto = bol.issueBy !== 0n;
    const prover = provers.get(offer.verifier.toLowerCase());
    if (!prover?.rails.includes(boleto ? Rail.BOLETO : Rail.PIX)) {
      // No prover for this verifier, or one that proves another rail: the taker may still prove from their own bank.
      this.once(`passive:${t.orderId}`, () => log.info(`on-ramp: ${short(t.orderId)} paid; no prover here proves ${boleto ? 'BOLETO' : 'PIX'} for its verifier, awaiting the taker's own proof`));
      return;
    }
    const since = boleto ? bol.issuedAt : ord.lockedAt;
    const unprovable = p.amountCents < ord.brlCents ? 'the credit is less than the order'
      : boleto && p.amountCents !== ord.brlCents ? 'a boleto credit must equal the order exactly'
        : boleto && bol.issuedAt === 0n ? 'the boleto was never issued on-chain'
          : p.paidAt < since ? 'the credit predates the order on the escrow\'s clock'
            : p.paidAt > ord.payBy ? 'the credit came after the order\'s pay window'
              : !boleto && p.paidAt + ONRAMP_RECEIPT_MAX_AGE < asOf ? 'the credit is older than RECEIPT_MAX_AGE'
                : undefined;
    if (unprovable) {
      this.once(`unprovable:${t.orderId}`, () => log.warn(
        `on-ramp: ${short(t.orderId)} cannot be proven (${unprovable}); `
        + (frozenAt === undefined ? 'it will expire and the BRL be refunded' : 'the dispute decides it'),
      ));
      return;
    }

    const terms = {
      orderId: t.orderId,
      payeeKeyHash: boleto ? bol.commitment : offer.pixKeyHash,
      brlCents: ord.brlCents,
      lockedAt: since,
      acceptedRails: boleto ? [Rail.BOLETO] : railsFromMask(offer.railMask).filter((r) => r !== Rail.BOLETO),
    };
    const ref = payerRef(p.payerId, this.ctx.payerRefSecret);
    let proof: Hex;
    try {
      if (boleto) {
        proof = await prover.proveBoleto(terms, {
          bankTxId: p.bankTxId, line: p.boletoLine ?? t.boleto!.line!, salt: t.boleto!.salt,
          payerRef: ref, amountBrlCents: p.amountCents, paidAt: p.paidAt, leg: 'onramp',
        });
      } else {
        const salt = store.saltFor(offer.pixKeyHash);
        if (!salt) return this.hold(t, 'the offer\'s PIX-key salt is not in the journal: this node did not post it');
        proof = await prover.provePix(terms, {
          bankTxId: p.bankTxId, pixKey: p.creditedKey ?? this.pixKey, salt,
          payerRef: ref, amountBrlCents: p.amountCents, paidAt: p.paidAt, leg: 'onramp',
        });
      }
    } catch (e) {
      metrics.inc('mova_lp_proof_failures_total', { leg: 'onramp' });
      log.warn(`on-ramp: no proof yet for ${short(t.orderId)}: ${errorText(e)}`);
      return;
    }
    try {
      const r = await chain.releaseWithProof(t.orderId, proof);
      store.record({ t: 'order.released', orderId: t.orderId, tx: r.hash });
      metrics.inc('mova_lp_onramp_released_total');
      log.info(`on-ramp: released ${short(t.orderId)}${frozenAt === undefined ? '' : ', in dispute,'} in block ${r.blockNumber}`);
    } catch (e) {
      if (e instanceof ChainRevert && e.errorName === 'WrongState') return; // someone else released it first
      if (frozenAt !== undefined && e instanceof ChainRevert) {
        // DisputeExpired, a late or stale receipt, a replayed id: no retry will change it.
        this.refusedInDispute.add(t.orderId.toLowerCase());
        log.warn(`on-ramp: the escrow refused the proof of disputed ${short(t.orderId)} (${e.errorName}); the dispute decides it`);
        return;
      }
      throw e;
    }
  }

  private async reclaim(t: OrderTrack): Promise<void> {
    try {
      await this.ctx.chain.reclaimExpired(t.orderId);
      this.ctx.metrics.inc('mova_lp_onramp_reclaimed_total');
      this.ctx.log.info(`on-ramp: reclaimed expired ${short(t.orderId)}`);
    } catch (e) {
      if (e instanceof ChainRevert && (e.errorName === 'WrongState' || e.errorName === 'WindowStillOpen')) return;
      throw e;
    }
  }

  private async cancelled(t: OrderTrack, ord: OnChainOrder, view: TickView): Promise<void> {
    const { chain, bank, store, metrics, log } = this.ctx;
    // Nothing irreversible off-chain on a cancellation that a reorg could still undo.
    const confirmed = await chain.order(t.orderId, view.confirmedBlock);
    if (confirmed.state !== OrderState.CANCELLED) return;

    if (t.boleto?.bankRef && !t.boleto.cancelled) await this.cancelBoleto(t);
    if (t.cob && !t.cob.closed) await this.closeCharge(t);

    if (!t.payment) {
      // Linger, so a PIX that lands after the deadline still finds its order and is refunded.
      if (view.chainNow > ord.payBy + BigInt(this.o.lateCreditGraceSeconds)) {
        store.record({ t: 'order.done', orderId: t.orderId, state: OrderState.CANCELLED });
      }
      return;
    }
    const p = t.payment;
    if (!this.o.autoRefund || p.rail !== 'PIX' || !bank.refundIncoming) {
      return this.hold(t, `${p.amountCents} centavos were received for an order that did not release; refund the payer by hand`);
    }
    if (!t.refund) {
      store.record({
        t: 'order.refund.intent', orderId: t.orderId,
        idempotencyKey: idempotencyKey('order-refund', chain.chainId, this.o.escrow, t.orderId),
      });
    }
    const refund = store.getOrder(t.orderId)!.refund!;
    let result = refund.result;
    if (!result || result.status === 'PENDING') {
      try {
        result = (result ? await bank.getOutgoing(refund.idempotencyKey) : undefined)
          ?? await bank.refundIncoming({
            idempotencyKey: refund.idempotencyKey, bankTxId: p.bankTxId, amountCents: p.amountCents,
            reason: 'Mova on-ramp order did not settle',
          });
      } catch (e) {
        metrics.inc('mova_lp_bank_errors_total', { op: 'refundIncoming' });
        throw e;
      }
      store.record({ t: 'order.refund.result', orderId: t.orderId, result });
      metrics.inc('mova_lp_refunds_total', { status: result.status });
    }
    if (result.status === 'SETTLED') {
      log.info(`on-ramp: refunded ${p.amountCents} centavos for cancelled ${short(t.orderId)}`);
      this.uncountRefund(t);
      store.record({ t: 'order.done', orderId: t.orderId, state: OrderState.CANCELLED });
    } else if (result.status === 'FAILED') {
      this.hold(t, `the refund failed at the bank (${result.failureReason ?? 'no reason given'}); refund by hand`);
    }
  }

  private async cancelBoleto(t: OrderTrack): Promise<void> {
    const { bank, store, metrics } = this.ctx;
    if (!bank.cancelBoleto || !t.boleto?.bankRef) return;
    try {
      await bank.cancelBoleto(t.boleto.bankRef);
      store.record({ t: 'order.boleto.cancelled', orderId: t.orderId });
    } catch (e) {
      metrics.inc('mova_lp_bank_errors_total', { op: 'cancelBoleto' });
      throw e;
    }
  }

  private hold(t: OrderTrack, reason: string): void {
    this.ctx.store.record({ t: 'order.hold', orderId: t.orderId, reason });
    this.ctx.log.error(`on-ramp: HOLD ${short(t.orderId)}: ${reason}`);
  }

  private once(key: string, fn: () => void): void {
    if (this.warned.has(key)) return;
    this.warned.add(key);
    fn();
  }

  /*//////////////////////////////////////////////////////////////
                         PAYMENT INSTRUCTIONS
  //////////////////////////////////////////////////////////////*/

  /**
   * What the order's taker needs to pay. The caller (server.ts) has already checked the request
   * is signed by `taker`; this re-reads the order so it never serves instructions for an order
   * that is not live, or not against this LP's offer.
   */
  async instructions(orderId: Hex): Promise<{ taker: Address; body: PaymentInstructions }> {
    const { chain, store } = this.ctx;
    const ord = await chain.order(orderId);
    if (ord.state === OrderState.NONE) throw new InstructionsError(404, 'no such order');
    const offer = await chain.offer(ord.offerId);
    if (!sameAddress(offer.lp, chain.account)) throw new InstructionsError(404, 'no such order');
    if (ord.state !== OrderState.LOCKED) throw new InstructionsError(409, `order is ${OrderState[ord.state]}, not awaiting payment`);
    // A cap refusal is told plainly, and only that: how much this payer has already moved is the LP's.
    const refused = store.getOrder(orderId)?.cap?.refused;
    if (refused) {
      const v = { ok: false as const, period: refused.period, tier: 0 as const, day: refused.day };
      throw new InstructionsError(409, capRefusalMessage(v), refused.period === 'unknown_payer' ? UNKNOWN_PAYER_REFUSAL_CODE : CAP_REFUSAL_CODE);
    }
    const bol = await chain.boleto(orderId);
    const amount = formatReais(ord.brlCents);

    if (bol.issueBy !== 0n) {
      const b = store.getOrder(orderId)?.boleto;
      if (bol.issuedAt === 0n || !b?.line) throw new InstructionsError(409, 'the boleto for this order is not issued yet; retry shortly');
      return {
        taker: ord.taker,
        body: {
          rail: 'BOLETO', orderId, amountCents: ord.brlCents.toString(), amount, line: b.line, salt: b.salt,
          commitment: bol.commitment, payBy: Number(ord.payBy),
        },
      };
    }
    const salt = store.saltFor(offer.pixKeyHash);
    if (!salt) throw new InstructionsError(503, 'this node does not hold the salt for that offer');
    if (this.o.pixCharge === 'cob') {
      const cob = store.getOrder(orderId)?.cob;
      if (!cob?.location || !cob.pixCopiaECola || cob.expiresAt === undefined) {
        throw new InstructionsError(409, 'the PIX charge for this order is not ready yet; retry shortly');
      }
      if (cob.amountCents !== ord.brlCents) throw new InstructionsError(503, 'the PIX charge on record does not charge this order\'s amount');
      return {
        taker: ord.taker,
        body: {
          rail: 'PIX', orderId, amountCents: ord.brlCents.toString(), amount, pixKey: this.pixKey, salt,
          payeeCommitment: offer.pixKeyHash, txid: cob.txid, pixCopiaECola: cob.pixCopiaECola, receiver: this.o.receiver,
          payBy: Number(ord.payBy), charge: 'cob', location: cob.location, expiresAt: Number(cob.expiresAt),
        },
      };
    }
    const txid = pixTxidForOrder(orderId);
    return {
      taker: ord.taker,
      body: {
        rail: 'PIX', orderId, amountCents: ord.brlCents.toString(), amount, pixKey: this.pixKey, salt,
        payeeCommitment: offer.pixKeyHash, txid,
        pixCopiaECola: buildPixBrCode({
          key: this.pixKey, amountCents: ord.brlCents, merchantName: this.o.receiver.name,
          merchantCity: this.o.receiver.city, txid,
        }),
        receiver: this.o.receiver, payBy: Number(ord.payBy),
      },
    };
  }
}

function safeBarcode(line: string): string | undefined {
  try { return parseBoleto(line).barcode; } catch { return undefined; }
}

function safeKey(key: string): string | undefined {
  try { return normalizePixKey(key).key; } catch { return undefined; }
}
