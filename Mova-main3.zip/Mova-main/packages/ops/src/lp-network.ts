/**
 * The LP network, read: who is admitted, at what credit, how much of it is live, what is disputed, and which registry
 * changes are scheduled - shared by the `lp` CLI (`bin/lp.ts`) and the monitor's LP checks.
 *
 * ## Two sources, each for what it is good at
 *
 * **State** answers everything about one LP: `lps(lp)`, `capOf`, `availableCents`, `carvedOutCents`,
 * `groupExposureCents`, and the reserve's `isGateway`. It is the truth, and it is cheap.
 *
 * **History** answers the two questions state cannot: *which* addresses are LPs (the registry keeps a mapping, not a
 * list), and *what* a scheduled change contains (`readyAt` is keyed by `keccak256(call)`; the calldata itself is only in
 * the `ChangeScheduled` log). Open disputes are history too: the escrows record a dispute against an order or sale, and
 * only their logs say which LP that order belongs to. So this folds the registry's and the escrows' logs into a ledger,
 * keeps a block cursor, and reads only the blocks since. A pending change is always confirmed against `readyAt(id)`
 * before it is reported, so a ledger that lags never invents one.
 *
 * ## Free RPC plans
 *
 * Alchemy's free plan answers `eth_getLogs` for at most 10 blocks per call. The reader starts wide, narrows to 10 when
 * the provider says the range is too large (the same rule as `scripts/privilege-inventory.ts`), runs narrow windows a
 * few at a time, and backs off on rate limits. A day of Sepolia is ~7,200 blocks: ~720 calls the first time, and only
 * the new blocks after that, because the cursor is kept.
 *
 * ## The ledger is a cache plus an audit trail
 *
 * Everything chain-derived in it can be rebuilt from `fromBlock`; if the block at the cursor no longer has the hash the
 * ledger saw (a reorg, or a ledger written against a fork), the chain-derived part is dropped and rebuilt. `actions` -
 * what the CLI itself sent, and the reason given for a forced removal - is kept across a rebuild.
 */
import {
  getAddress, isAddressEqual, parseAbi, parseEventLogs, decodeFunctionData, type Address, type Hex, type Log, type PublicClient,
} from 'viem';
import type { CheckResult, Level } from './checks.js';
import { BURN } from './orphans.js';
import { redactError } from './redact.js';

/** `LPRegistry.Tier` in declaration order (the index is the ABI value). `test/lp-network.test.ts` pins it to admin.ts's TIERS. */
export const TIER_NAMES = ['NONE', 'RETAIL', 'AFFILIATED', 'INSTITUTIONAL', 'SUSPENDED'] as const;
export type TierName = typeof TIER_NAMES[number];
/** `LPRegistry.Phase`. */
export const PHASE_NAMES = ['A', 'B', 'C'] as const;
export type PhaseName = typeof PHASE_NAMES[number];

export const REGISTRY_ABI = parseAbi([
  'function phase() view returns (uint8)',
  'function governor() view returns (address)',
  'function setupComplete() view returns (bool)',
  'function GOVERNANCE_DELAY() view returns (uint256)',
  'function EXECUTION_WINDOW() view returns (uint256)',
  'function readyAt(bytes32 id) view returns (uint256)',
  'function lps(address lp) view returns (uint8 tier, uint256 settledCents, uint32 settlements, uint32 disputesLost, uint256 manualCapCents, address sponsor, uint256 exposureCents)',
  'function capOf(address lp) view returns (uint256)',
  'function availableCents(address lp) view returns (uint256)',
  'function carvedOutCents(address sponsor) view returns (uint256)',
  'function groupExposureCents(address lp) view returns (uint256)',
]);

export const RESERVE_GATEWAY_ABI = parseAbi(['function isGateway(address gateway) view returns (bool)']);

/** The registry's delayable setters (`LPRegistry._isDelayable`): what a scheduled change on it can contain. */
export const REGISTRY_SETTERS = parseAbi([
  'function setTier(address lp, uint8 tier, uint256 manualCapCents)',
  'function setPhase(uint8 next)',
  'function setEscrow(address escrow, bool allowed)',
  'function setRewardsHook(address hook)',
]);

/** The registry's events (DelayedGovernance's queue included) and the escrows' events that place an LP and its disputes. */
export const LP_EVENTS = parseAbi([
  'event ChangeScheduled(bytes32 indexed id, bytes4 indexed selector, bytes call, uint256 readyAt, uint256 expiresAt)',
  'event ChangeCancelled(bytes32 indexed id)',
  'event ChangeExecuted(bytes32 indexed id, bytes4 indexed selector)',
  'event TierChanged(address indexed lp, uint8 from, uint8 to, uint256 creditCents)',
  'event Registered(address indexed lp, uint8 tier)',
  'event AffiliateSponsored(address indexed sponsor, address indexed affiliate, uint256 creditCents)',
  'event AffiliateRevoked(address indexed sponsor, address indexed affiliate)',
  'event PhaseSet(uint8 from, uint8 to)',
  // FiatEscrow
  'event OfferPosted(bytes32 indexed offerId, address indexed lp, uint256 wei_, uint256 price)',
  'event OrderLocked(bytes32 indexed orderId, bytes32 indexed offerId, address indexed taker, uint256 brlCents)',
  'event OrderDisputed(bytes32 indexed orderId, address by, string reason)',
  // OffRampEscrow
  'event SaleClaimed(bytes32 indexed saleId, address indexed lp, uint64 payBy)',
  'event SaleDisputed(bytes32 indexed saleId, address by, string reason)',
  // Both escrows: identical types, so identical topics (the flag is releasedToTaker on one, paidLP on the other).
  'event DisputeResolved(bytes32 indexed orderId, bool favoursCounterparty, address indexed arbitrator, bytes32 evidenceRoot)',
  'event DisputeTimedOut(bytes32 indexed orderId)',
]);

/*//////////////////////////////////////////////////////////////
                              LEDGER
//////////////////////////////////////////////////////////////*/

export interface LedgerChange {
  id: Hex;
  /** The scheduled calldata: what `execute` must be sent with. '0x' when only its cancellation or execution was seen. */
  call: Hex;
  readyAt: string;
  expiresAt: string;
  scheduledBlock: string;
  scheduledTx?: Hex;
  status: 'pending' | 'executed' | 'cancelled';
  closedBlock?: string;
}

export interface LedgerDispute {
  id: Hex;
  escrow: Address;
  kind: 'order' | 'sale';
  /** Undefined when the order's offer (or the sale's claim) predates the scanned range. */
  lp?: Address;
  raisedBlock: string;
  status: 'open' | 'resolved' | 'timed-out';
}

export interface LedgerAction {
  at: string;
  command: string;
  chainId?: number;
  tx?: Hex;
  block?: string;
  lp?: Address;
  id?: Hex;
  readyAt?: string;
  expiresAt?: string;
  reason?: string;
  note?: string;
}

export interface LpLedger {
  version: 1;
  chainId?: number;
  registry: Address;
  escrows: Address[];
  /** The first block folded: the registry's deployment block. */
  fromBlock?: string;
  /** The last block folded, and its hash (a mismatch on the next sync drops the chain-derived state). */
  scannedTo?: string;
  scannedToHash?: Hex;
  phase?: number;
  lps: Record<string, { address: Address; firstSeenBlock: string; via: string }>;
  changes: Record<string, LedgerChange>;
  offers: Record<string, Address>;
  orders: Record<string, Address>;
  sales: Record<string, Address>;
  disputes: Record<string, LedgerDispute>;
  /** What the CLI sent, with reasons: kept across a rebuild. */
  actions: LedgerAction[];
}

export function emptyLedger(o: { registry: Address; escrows?: Address[]; fromBlock?: bigint; chainId?: number }): LpLedger {
  return {
    version: 1, chainId: o.chainId, registry: getAddress(o.registry), escrows: (o.escrows ?? []).map((a) => getAddress(a)),
    fromBlock: o.fromBlock?.toString(), lps: {}, changes: {}, offers: {}, orders: {}, sales: {}, disputes: {}, actions: [],
  };
}

/** Forget everything the chain told the ledger, keep what the CLI recorded. */
export function resetChainState(l: LpLedger): void {
  Object.assign(l, { scannedTo: undefined, scannedToHash: undefined, phase: undefined, lps: {}, changes: {}, offers: {}, orders: {}, sales: {}, disputes: {} });
}

const key = (x: string) => x.toLowerCase();

function addLp(l: LpLedger, lp: Address, block: bigint, via: string): void {
  if (/^0x0{40}$/i.test(lp)) return;
  const k = key(lp);
  if (!l.lps[k]) l.lps[k] = { address: getAddress(lp), firstSeenBlock: block.toString(), via };
}

export type DecodedLog = Log<bigint, number, false> & { eventName: string; args: Record<string, unknown> };

/** Fold decoded logs into the ledger, in chain order. Pure: the tests drive it with hand-made logs. */
export function foldLogs(l: LpLedger, logs: readonly DecodedLog[]): void {
  const sorted = [...logs].sort((a, b) => (a.blockNumber === b.blockNumber ? (a.logIndex ?? 0) - (b.logIndex ?? 0) : a.blockNumber! < b.blockNumber! ? -1 : 1));
  const escrows = new Set(l.escrows.map(key));
  for (const log of sorted) {
    const at = log.blockNumber ?? 0n;
    const a = log.args;
    const from = key(log.address);
    if (from === key(l.registry)) {
      switch (log.eventName) {
        case 'ChangeScheduled': {
          const id = a.id as Hex;
          l.changes[key(id)] = {
            id, call: a.call as Hex, readyAt: String(a.readyAt), expiresAt: String(a.expiresAt), scheduledBlock: at.toString(),
            ...(log.transactionHash ? { scheduledTx: log.transactionHash } : {}), status: 'pending',
          };
          const target = lpOfCall(a.call as Hex);
          if (target) addLp(l, target, at, 'scheduled setTier');
          break;
        }
        case 'ChangeCancelled':
        case 'ChangeExecuted': {
          const id = a.id as Hex;
          const c = l.changes[key(id)] ?? { id, call: '0x', readyAt: '0', expiresAt: '0', scheduledBlock: '0', status: 'pending' as const };
          c.status = log.eventName === 'ChangeCancelled' ? 'cancelled' : 'executed';
          c.closedBlock = at.toString();
          l.changes[key(id)] = c;
          break;
        }
        case 'TierChanged': addLp(l, a.lp as Address, at, 'TierChanged'); break;
        case 'Registered': addLp(l, a.lp as Address, at, 'Registered'); break;
        case 'AffiliateSponsored':
          addLp(l, a.sponsor as Address, at, 'AffiliateSponsored (sponsor)');
          addLp(l, a.affiliate as Address, at, 'AffiliateSponsored');
          break;
        case 'PhaseSet': l.phase = Number(a.to); break;
        default: break;
      }
      continue;
    }
    if (!escrows.has(from)) continue;
    switch (log.eventName) {
      case 'OfferPosted': l.offers[key(a.offerId as Hex)] = getAddress(a.lp as Address); break;
      case 'OrderLocked': {
        const lp = l.offers[key(a.offerId as Hex)];
        if (lp) l.orders[key(a.orderId as Hex)] = lp;
        break;
      }
      case 'SaleClaimed': l.sales[key(a.saleId as Hex)] = getAddress(a.lp as Address); break;
      case 'OrderDisputed':
      case 'SaleDisputed': {
        const order = log.eventName === 'OrderDisputed';
        const id = (order ? a.orderId : a.saleId) as Hex;
        const lp = order ? l.orders[key(id)] : l.sales[key(id)];
        l.disputes[key(id)] = { id, escrow: getAddress(log.address), kind: order ? 'order' : 'sale', ...(lp ? { lp } : {}), raisedBlock: at.toString(), status: 'open' };
        break;
      }
      case 'DisputeResolved':
      case 'DisputeTimedOut': {
        const d = l.disputes[key(a.orderId as Hex)];
        if (d) d.status = log.eventName === 'DisputeResolved' ? 'resolved' : 'timed-out';
        break;
      }
      default: break;
    }
  }
}

/*//////////////////////////////////////////////////////////////
                         PAGED LOG READER
//////////////////////////////////////////////////////////////*/

export type LogClient = Pick<PublicClient, 'getLogs' | 'getBlockNumber' | 'getBlock'>;

export interface ReadLogsOptions {
  /** First window size. Default 2,000 blocks; narrowed to 10 when the provider refuses. */
  span?: bigint;
  /** Narrow windows (<= 100 blocks) in flight at once. Default 4. */
  concurrency?: number;
  /** Called after each batch: blocks done so far, of total. */
  onProgress?: (done: bigint, total: bigint) => void;
  /** Sleep, for the tests. */
  sleep?: (ms: number) => Promise<void>;
}

const RANGE_REFUSAL = /block range|range limit|\b10 block|too many blocks|exceed|query returned more than|range is too large|max range/i;
const RATE_LIMIT = /429|rate limit|too many requests|compute units|capacity|throughput/i;
const errText = (e: unknown) => { const x = e as { message?: string; details?: string; shortMessage?: string }; return `${x?.shortMessage ?? ''} ${x?.details ?? ''} ${x?.message ?? String(e)}`; };

/**
 * Every log the addresses emitted in [from, to], decoded against `LP_EVENTS` (logs of other events are dropped), in
 * windows the provider accepts.
 */
export async function readLogsPaged(
  client: Pick<PublicClient, 'getLogs'>, addresses: readonly Address[], from: bigint, to: bigint, o: ReadLogsOptions = {},
): Promise<DecodedLog[]> {
  const sleep = o.sleep ?? ((ms: number) => new Promise<void>((r) => setTimeout(r, ms)));
  const out: Log[] = [];
  let span = o.span ?? 2_000n;
  const fetchWindow = async (a: bigint, b: bigint): Promise<Log[]> => {
    for (let attempt = 0; ; attempt++) {
      try {
        return await client.getLogs({ address: [...addresses], fromBlock: a, toBlock: b } as never) as Log[];
      } catch (e) {
        if (!RANGE_REFUSAL.test(errText(e)) && RATE_LIMIT.test(errText(e)) && attempt < 6) { await sleep(500 * 2 ** attempt); continue; }
        throw e;
      }
    }
  };
  for (let cursor = from; cursor <= to;) {
    const width = span <= 100n ? Math.max(1, o.concurrency ?? 4) : 1;
    const windows: [bigint, bigint][] = [];
    for (let c = cursor; windows.length < width && c <= to; c += span) windows.push([c, c + span - 1n > to ? to : c + span - 1n]);
    try {
      const got = await Promise.all(windows.map(([a, b]) => fetchWindow(a, b)));
      for (const g of got) out.push(...g);
      cursor = windows[windows.length - 1]![1] + 1n;
      o.onProgress?.(cursor - from, to - from + 1n);
    } catch (e) {
      if (span > 10n && RANGE_REFUSAL.test(errText(e))) { span = span > 1_000n ? 1_000n : 10n; continue; }
      throw e;
    }
  }
  return parseEventLogs({ abi: LP_EVENTS, logs: out }) as unknown as DecodedLog[];
}

/** Bring the ledger up to `toBlock` (default the head). Returns what was read; `skipped` when no starting block is known. */
export async function syncLedger(
  client: LogClient, l: LpLedger, o: ReadLogsOptions & { toBlock?: bigint } = {},
): Promise<{ skipped?: true; from?: bigint; to?: bigint; logs: number; rebuilt?: true }> {
  // Uncached: viem keeps a block number for 4 s, and a sweep right after a transaction must see its block.
  const head = o.toBlock ?? await client.getBlockNumber({ cacheTime: 0 });
  let rebuilt: true | undefined;
  if (l.scannedTo !== undefined && l.scannedToHash) {
    const b = await client.getBlock({ blockNumber: BigInt(l.scannedTo) });
    if (b.hash?.toLowerCase() !== l.scannedToHash.toLowerCase()) { resetChainState(l); rebuilt = true; }
  }
  const from = l.scannedTo !== undefined ? BigInt(l.scannedTo) + 1n : l.fromBlock !== undefined ? BigInt(l.fromBlock) : undefined;
  if (from === undefined) return { skipped: true, logs: 0 };
  if (from > head) return { from, to: head, logs: 0, ...(rebuilt ? { rebuilt } : {}) };
  const logs = await readLogsPaged(client, [l.registry, ...l.escrows], from, head, o);
  foldLogs(l, logs);
  l.scannedTo = head.toString();
  l.scannedToHash = (await client.getBlock({ blockNumber: head })).hash ?? undefined;
  return { from, to: head, logs: logs.length, ...(rebuilt ? { rebuilt } : {}) };
}

/*//////////////////////////////////////////////////////////////
                              READING
//////////////////////////////////////////////////////////////*/

export type ReadClient = Pick<PublicClient, 'readContract'>;

export interface RegistryReading {
  registry: Address;
  phase: PhaseName;
  phaseIndex: number;
  governor: Address;
  setupComplete: boolean;
  delaySeconds: bigint;
  windowSeconds: bigint;
  /** The governor is 0x...dEaD: `--finalize` ran, and no tier, credit or phase can ever change again. */
  finalized: boolean;
}

export async function readRegistry(client: ReadClient, registry: Address): Promise<RegistryReading> {
  const r = <T>(functionName: string) => client.readContract({ address: registry, abi: REGISTRY_ABI, functionName } as never) as Promise<T>;
  const [phase, governor, setupComplete, delay, window] = await Promise.all([
    r<number | bigint>('phase'), r<Address>('governor'), r<boolean>('setupComplete'), r<bigint>('GOVERNANCE_DELAY'), r<bigint>('EXECUTION_WINDOW'),
  ]);
  const i = Number(phase);
  return {
    registry, phase: PHASE_NAMES[i] ?? (`?${i}` as PhaseName), phaseIndex: i, governor: getAddress(governor), setupComplete,
    delaySeconds: BigInt(delay), windowSeconds: BigInt(window), finalized: isAddressEqual(governor, BURN),
  };
}

export interface LpReading {
  lp: Address;
  tier: TierName;
  tierIndex: number;
  /** INSTITUTIONAL: the governor-set limit. AFFILIATED: the credit its sponsor carved out. Kept while SUSPENDED. */
  creditCents: bigint;
  /** `capOf`: what the limit is right now (0 while suspended, or for a tier the phase has closed). */
  capCents: bigint;
  exposureCents: bigint;
  availableCents: bigint;
  /** INSTITUTIONAL: credit given to its affiliates, and its own plus its affiliates' exposure. */
  carvedOutCents: bigint;
  groupExposureCents: bigint;
  settledCents: bigint;
  settlements: number;
  disputesLost: number;
  sponsor?: Address;
  suspended: boolean;
  /** `MovvaReserve.isGateway`, when a reserve was given. */
  gateway?: boolean;
}

export async function readLp(client: ReadClient, registry: Address, lp: Address, reserve?: Address): Promise<LpReading> {
  const r = <T>(functionName: string, args: readonly unknown[]) =>
    client.readContract({ address: registry, abi: REGISTRY_ABI, functionName, args } as never) as Promise<T>;
  const [row, cap, available, carved, group, gateway] = await Promise.all([
    r<readonly [number, bigint, number, number, bigint, Address, bigint]>('lps', [lp]),
    r<bigint>('capOf', [lp]), r<bigint>('availableCents', [lp]), r<bigint>('carvedOutCents', [lp]), r<bigint>('groupExposureCents', [lp]),
    reserve ? client.readContract({ address: reserve, abi: RESERVE_GATEWAY_ABI, functionName: 'isGateway', args: [lp] }) as Promise<boolean> : Promise.resolve(undefined),
  ]);
  const [tier, settledCents, settlements, disputesLost, manualCapCents, sponsor, exposureCents] = row;
  const t = Number(tier);
  return {
    lp: getAddress(lp), tier: TIER_NAMES[t] ?? (`?${t}` as TierName), tierIndex: t, creditCents: BigInt(manualCapCents),
    capCents: BigInt(cap), exposureCents: BigInt(exposureCents), availableCents: BigInt(available), carvedOutCents: BigInt(carved),
    groupExposureCents: BigInt(group), settledCents: BigInt(settledCents), settlements: Number(settlements), disputesLost: Number(disputesLost),
    ...(/^0x0{40}$/i.test(sponsor) ? {} : { sponsor: getAddress(sponsor) }), suspended: t === 4,
    ...(gateway !== undefined ? { gateway } : {}),
  };
}

/** Exposure the LP must see settle or expire before it is removed: its own, and (for a sponsor) its affiliates'. */
export const liveExposure = (r: LpReading): bigint => (r.groupExposureCents > r.exposureCents ? r.groupExposureCents : r.exposureCents);

/*//////////////////////////////////////////////////////////////
                         SCHEDULED CHANGES
//////////////////////////////////////////////////////////////*/

/** Centavos as reais, pt-BR: R$ 1.234,56. */
export function reais(cents: bigint): string {
  const neg = cents < 0n;
  const c = neg ? -cents : cents;
  const whole = (c / 100n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  return `${neg ? '-' : ''}R$ ${whole},${String(c % 100n).padStart(2, '0')}`;
}

export function decodeRegistryCall(call: Hex): { fn: string; args: readonly unknown[] } | undefined {
  if (!call || call === '0x') return undefined;
  try {
    const d = decodeFunctionData({ abi: REGISTRY_SETTERS, data: call });
    return { fn: d.functionName, args: d.args ?? [] };
  } catch {
    return undefined;
  }
}

/** The LP a scheduled setTier names. */
export function lpOfCall(call: Hex): Address | undefined {
  const d = decodeRegistryCall(call);
  return d?.fn === 'setTier' ? getAddress(d.args[0] as Address) : undefined;
}

/** A scheduled call as an operator reads it: `setTier(0x…, INSTITUTIONAL, R$ 1.000,00)`. */
export function describeRegistryCall(call: Hex): string {
  const d = decodeRegistryCall(call);
  if (!d) return call === '0x' ? 'a change whose calldata was not in the scanned logs' : `an undecodable call ${call.slice(0, 10)}`;
  switch (d.fn) {
    case 'setTier': return `setTier(${d.args[0]}, ${TIER_NAMES[Number(d.args[1])] ?? d.args[1]}, ${reais(d.args[2] as bigint)})`;
    case 'setPhase': return `setPhase(${PHASE_NAMES[Number(d.args[0])] ?? d.args[0]})`;
    case 'setEscrow': return `setEscrow(${d.args[0]}, ${d.args[1]})`;
    default: return `${d.fn}(${d.args.join(', ')})`;
  }
}

export interface PendingChange extends LedgerChange {
  description: string;
  lp?: Address;
  /** `readyAt(id)` as the chain answers now: 0 means the ledger lags (it ran or was cancelled since). */
  onChainReadyAt: bigint;
  state: 'waiting' | 'ready' | 'expired' | 'gone';
}

/** Every change the ledger holds as pending, each confirmed against `readyAt(id)` on-chain. */
export async function pendingChanges(client: ReadClient, l: LpLedger, nowSeconds: number): Promise<PendingChange[]> {
  const pending = Object.values(l.changes).filter((c) => c.status === 'pending');
  const ready = await Promise.all(pending.map((c) =>
    client.readContract({ address: l.registry, abi: REGISTRY_ABI, functionName: 'readyAt', args: [c.id] }) as Promise<bigint>));
  return pending.map((c, i) => {
    const on = BigInt(ready[i]!);
    const now = BigInt(nowSeconds);
    const state: PendingChange['state'] = on === 0n ? 'gone' : now < on ? 'waiting' : now <= BigInt(c.expiresAt) ? 'ready' : 'expired';
    const lp = lpOfCall(c.call);
    return { ...c, description: describeRegistryCall(c.call), ...(lp ? { lp } : {}), onChainReadyAt: on, state };
  }).sort((a, b) => (BigInt(a.readyAt) < BigInt(b.readyAt) ? -1 : 1));
}

export const openDisputesOf = (l: LpLedger, lp: Address) =>
  Object.values(l.disputes).filter((d) => d.status === 'open' && d.lp && isAddressEqual(d.lp, lp));

/*//////////////////////////////////////////////////////////////
                           THE LP NODE
//////////////////////////////////////////////////////////////*/

export interface NodeSummary {
  ok: boolean;
  httpStatus?: number;
  ready?: boolean;
  account?: string;
  chainId?: number;
  lastTickAt?: string;
  lastTickError?: string;
  credit?: { capCents: string; availableCents: string };
  unresolvedPayments?: number;
  openOrders?: number;
  openSales?: number;
  disputedSales?: number;
  held?: number;
  unreconciledCredits?: number;
  gateway?: boolean;
  rewardsNotCounting?: string;
  /** What disagrees with the chain: the node runs as another account, or on another chain. */
  mismatches: string[];
  error?: string;
}

/**
 * The LP node's private `/status`, summarised. Never its payer data: the caps section carries payer hashes and totals,
 * which belong on the LP's side; this reads only what an operator needs to see the node is the one for this LP and alive.
 */
export async function fetchNodeStatus(
  baseUrl: string, expect: { lp?: Address; chainId?: number }, deps: { fetch?: typeof fetch; timeoutMs?: number } = {},
): Promise<NodeSummary> {
  const f = deps.fetch ?? fetch;
  const url = `${baseUrl.replace(/\/+$/, '')}/status`;
  try {
    const res = await f(url, { signal: AbortSignal.timeout(deps.timeoutMs ?? 5_000) });
    const text = await res.text();
    let j: Record<string, any>;
    try { j = JSON.parse(text) as Record<string, any>; } catch { return { ok: false, httpStatus: res.status, mismatches: [], error: 'the node answered something other than JSON' }; }
    const orders = (j.onramp?.orders ?? []) as { hold?: unknown }[];
    const sales = (j.offramp?.sales ?? []) as { disputed?: unknown; hold?: unknown }[];
    const s: NodeSummary = {
      ok: res.ok, httpStatus: res.status, ready: j.ready === true, account: j.account, chainId: j.chainId === undefined ? undefined : Number(j.chainId),
      lastTickAt: j.lastTick?.at, ...(j.lastTick?.error ? { lastTickError: String(j.lastTick.error) } : {}),
      ...(j.credit ? { credit: { capCents: String(j.credit.capCents), availableCents: String(j.credit.availableCents) } } : {}),
      unresolvedPayments: Array.isArray(j.unresolvedPayments) ? j.unresolvedPayments.length : Number(j.unresolvedPayments ?? 0),
      openOrders: orders.length, openSales: sales.length, disputedSales: sales.filter((x) => x.disputed).length,
      held: [...orders, ...sales].filter((x) => x.hold).length,
      unreconciledCredits: j.onramp?.unreconciledCredits === undefined ? undefined : Number(j.onramp.unreconciledCredits),
      gateway: j.gateway !== null && j.gateway !== undefined,
      ...(j.rewards?.notCounting ? { rewardsNotCounting: String(j.rewards.notCounting) } : {}),
      mismatches: [],
    };
    if (expect.lp && s.account && !isAddressEqual(s.account as Address, expect.lp)) s.mismatches.push(`the node runs as ${s.account}, not ${expect.lp}`);
    if (expect.chainId !== undefined && s.chainId !== undefined && s.chainId !== expect.chainId) s.mismatches.push(`the node is on chain ${s.chainId}, not ${expect.chainId}`);
    return s;
  } catch (e) {
    return { ok: false, mismatches: [], error: redactError(e, [baseUrl]) };
  }
}

/*//////////////////////////////////////////////////////////////
                          MONITOR CHECKS
//////////////////////////////////////////////////////////////*/

export interface LpNetworkThresholds {
  /** `lp_credit:<lp>` warns once this share of the LP's limit is used (live or carved out for affiliates). */
  creditWarnPercent: number;
  /** ...and fails at this share: at 100 the LP can quote nothing new. */
  creditFailPercent: number;
  /** `lp_change:<id>` warns when a ready change has less than this left before it expires unexecuted. */
  changeExpiryWarnSeconds: number;
}

export const DEFAULT_LP_NETWORK_THRESHOLDS: LpNetworkThresholds = {
  creditWarnPercent: 80,
  creditFailPercent: 100,
  changeExpiryWarnSeconds: 3 * 24 * 60 * 60,
};

const iso = (s: bigint | number) => new Date(Number(s) * 1000).toISOString().replace('.000Z', 'Z');
const hours = (s: bigint | number) => `${(Number(s) / 3600).toFixed(1)}h`;
const shortId = (id: string) => `${id.slice(0, 10)}…`;

/** Share of the limit in use, in percent: what is live plus what a sponsor carved out, i.e. 100 - available/cap. */
export function creditUsedPercent(r: LpReading): number | undefined {
  if (r.capCents === 0n) return undefined;
  const used = r.capCents > r.availableCents ? r.capCents - r.availableCents : 0n;
  return Number((used * 10_000n) / r.capCents) / 100;
}

/**
 * The LP network's checks, from readings already taken. Pure, so the tests drive every branch.
 *
 *  - `lp_network`: the summary - phase, how many LPs of each tier, what is live, what is scheduled.
 *  - `lp_credit:<lp>`: warn at `creditWarnPercent` of the limit in use, fail at `creditFailPercent` (it can quote nothing).
 *  - `lp_disputes:<lp>`: warn while the LP has an open dispute on either escrow (for an LP that ever had one).
 *  - `lp_disputes:unattributed`: warn while a dispute is open on an order or sale the ledger cannot place.
 *  - `lp_change:<id>`: every scheduled registry change; warn when it is ready and about to expire unexecuted, and while
 *    an expired one sits in the queue (it can never run, and `--finalize` refuses while anything is queued).
 */
export function lpNetworkChecks(
  input: { registry: RegistryReading; ledger: LpLedger; readings: LpReading[]; pending: PendingChange[]; nowSeconds: number },
  th: LpNetworkThresholds = DEFAULT_LP_NETWORK_THRESHOLDS,
): CheckResult[] {
  const { registry, ledger, readings, pending, nowSeconds } = input;
  const out: CheckResult[] = [];
  const tiers = new Map<string, number>();
  let live = 0n;
  for (const r of readings) { tiers.set(r.tier, (tiers.get(r.tier) ?? 0) + 1); live += r.exposureCents; }
  const tierText = [...tiers.entries()].filter(([t]) => t !== 'NONE').map(([t, n]) => `${n} ${t.toLowerCase()}`).join(', ') || 'no LP admitted';
  const live_ = pending.filter((p) => p.state !== 'gone');
  out.push({
    id: 'lp_network', level: 'ok', value: readings.filter((r) => r.tier !== 'NONE').length,
    detail: `LP network in phase ${registry.phase}: ${tierText}; ${reais(live)} live; ${live_.length} scheduled registry change(s)`
      + `${registry.finalized ? '; governance FINALIZED (renounced): nothing here can change again' : ''}`,
  });

  for (const r of readings) {
    const id = `lp_credit:${r.lp.toLowerCase()}`;
    const pct = creditUsedPercent(r);
    if (pct === undefined) {
      const why = r.tier === 'SUSPENDED' ? 'suspended' : r.tier === 'NONE' ? 'not admitted' : `${r.tier.toLowerCase()} with no credit in phase ${registry.phase}`;
      out.push({ id, level: 'ok', detail: `${r.lp} is ${why}${r.exposureCents > 0n ? `, with ${reais(r.exposureCents)} still live (running off)` : ''}` });
      continue;
    }
    const level: Level = pct >= th.creditFailPercent ? 'fail' : pct >= th.creditWarnPercent ? 'warn' : 'ok';
    const carved = r.carvedOutCents > 0n ? `, ${reais(r.carvedOutCents)} carved out for affiliates (group live ${reais(r.groupExposureCents)})` : '';
    const base = `${r.lp} (${r.tier.toLowerCase()}) uses ${pct}% of its ${reais(r.capCents)} limit: ${reais(r.exposureCents)} live${carved}, ${reais(r.availableCents)} available`;
    out.push({
      id, level, value: pct, threshold: th.creditWarnPercent,
      detail: level === 'ok' ? base
        : level === 'fail' ? `${base}. It can take no new offer, order or sale: raise its credit (lp:credit, delayed) if its record justifies it, or let positions settle`
        : `${base}. Near its limit: new positions start failing at 100%`,
    });
  }

  const byLp = new Map<string, LedgerDispute[]>();
  const unattributed: LedgerDispute[] = [];
  for (const d of Object.values(ledger.disputes)) {
    if (!d.lp) { if (d.status === 'open') unattributed.push(d); continue; }
    const k = d.lp.toLowerCase();
    byLp.set(k, [...(byLp.get(k) ?? []), d]);
  }
  for (const r of readings) if (r.disputesLost > 0 && !byLp.has(r.lp.toLowerCase())) byLp.set(r.lp.toLowerCase(), []);
  for (const [k, ds] of byLp) {
    const open = ds.filter((d) => d.status === 'open');
    const lost = readings.find((r) => r.lp.toLowerCase() === k)?.disputesLost;
    const lostText = lost !== undefined ? `; ${lost} lost in total` : '';
    out.push({
      id: `lp_disputes:${k}`, level: open.length ? 'warn' : 'ok', value: open.length, threshold: 0,
      detail: open.length
        ? `${getAddress(k)} has ${open.length} open dispute(s): ${open.map((d) => `${d.kind} ${shortId(d.id)} on ${d.escrow}`).join(', ')}${lostText}. `
          + 'The arbitration desk rules; nobody ruling within DISPUTE_TIMEOUT refunds to origin'
        : `${getAddress(k)} has no open dispute${lostText}`,
    });
  }
  if (unattributed.length) {
    out.push({
      id: 'lp_disputes:unattributed', level: 'warn', value: unattributed.length, threshold: 0,
      detail: `${unattributed.length} open dispute(s) the ledger cannot place with an LP (the offer or claim predates the scanned range): `
        + `${unattributed.map((d) => `${d.kind} ${shortId(d.id)} on ${d.escrow}`).join(', ')}`,
    });
  }

  for (const p of pending) {
    if (p.state === 'gone') continue;
    const id = `lp_change:${p.id.toLowerCase()}`;
    const expires = BigInt(p.expiresAt);
    if (p.state === 'waiting') {
      out.push({ id, level: 'ok', value: Number(p.onChainReadyAt) - nowSeconds, detail: `scheduled ${p.description}: executable from ${iso(p.onChainReadyAt)}, until ${iso(expires)}` });
    } else if (p.state === 'ready') {
      const left = Number(expires) - nowSeconds;
      out.push({
        id, value: left, threshold: th.changeExpiryWarnSeconds,
        level: left <= th.changeExpiryWarnSeconds ? 'warn' : 'ok',
        detail: left <= th.changeExpiryWarnSeconds
          ? `scheduled ${p.description} is executable and EXPIRES UNEXECUTED in ${hours(left)} (${iso(expires)}): lp:execute ${p.id}, or lp:cancel it if it is no longer wanted`
          : `scheduled ${p.description}: executable now, until ${iso(expires)}`,
      });
    } else {
      out.push({
        id, level: 'warn', value: nowSeconds - Number(expires), threshold: 0,
        detail: `scheduled ${p.description} EXPIRED unexecuted at ${iso(expires)}: it can never run. lp:cancel ${p.id} clears it `
          + '(deploy-movva-rail --finalize refuses while a change is queued); schedule it again if it is still wanted',
      });
    }
  }
  return out;
}

export interface LpNetworkWatchOptions {
  client: LogClient & ReadClient;
  registry: Address;
  /** FiatEscrow and OffRampEscrow, for disputes. */
  escrows?: Address[];
  /** MovvaReserve, for each LP's gateway status (shown in details only). */
  reserve?: Address;
  /** The registry's deployment block. */
  fromBlock: bigint;
  /** LPs to watch even if the scanned history never names them. */
  lps?: Address[];
  /** Start from this ledger (the CLI's, say) instead of reading from `fromBlock`; it is synced forward from its cursor. */
  ledger?: LpLedger;
  thresholds?: Partial<LpNetworkThresholds>;
  read?: ReadLogsOptions;
  redactValues?: readonly (string | undefined)[];
}

/**
 * The monitor's LP-network watcher: keeps a ledger in memory across sweeps (the first sweep reads from `fromBlock`) and
 * reports `lpNetworkChecks`. A change that executes or is cancelled is reported `ok` once, resolving its alert, then
 * forgotten; a sync or read failure is `unknown`, never `ok`.
 */
export class LpNetworkWatcher {
  readonly ledger: LpLedger;
  private reported = new Set<string>();
  private readonly th: LpNetworkThresholds;

  constructor(private readonly o: LpNetworkWatchOptions) {
    this.ledger = o.ledger ?? emptyLedger({ registry: o.registry, escrows: o.escrows, fromBlock: o.fromBlock });
    this.th = { ...DEFAULT_LP_NETWORK_THRESHOLDS, ...o.thresholds };
  }

  async sweep(nowSeconds: number = Math.floor(Date.now() / 1000)): Promise<CheckResult[]> {
    const secrets = this.o.redactValues ?? [];
    let registry: RegistryReading;
    let pending: PendingChange[];
    try {
      await syncLedger(this.o.client, this.ledger, this.o.read);
      registry = await readRegistry(this.o.client, this.o.registry);
      pending = await pendingChanges(this.o.client, this.ledger, nowSeconds);
    } catch (e) {
      return [{ id: 'lp_network', level: 'unknown', detail: `the LP network could not be read: ${redactError(e, secrets)}` }];
    }
    const addresses = new Map<string, Address>();
    for (const v of Object.values(this.ledger.lps)) addresses.set(v.address.toLowerCase(), v.address);
    for (const a of this.o.lps ?? []) addresses.set(a.toLowerCase(), getAddress(a));
    const readings: LpReading[] = [];
    const failed: CheckResult[] = [];
    await Promise.all([...addresses.values()].map(async (lp) => {
      try { readings.push(await readLp(this.o.client, this.o.registry, lp, this.o.reserve)); } catch (e) {
        failed.push({ id: `lp_credit:${lp.toLowerCase()}`, level: 'unknown', detail: `${lp} could not be read: ${redactError(e, secrets)}` });
      }
    }));
    readings.sort((a, b) => a.lp.localeCompare(b.lp));
    const results = [...lpNetworkChecks({ registry, ledger: this.ledger, readings, pending, nowSeconds }, this.th), ...failed];
    const now = new Set(results.filter((r) => r.id.startsWith('lp_change:')).map((r) => r.id));
    for (const id of this.reported) {
      if (now.has(id)) continue;
      const c = this.ledger.changes[id.slice('lp_change:'.length)];
      results.push({ id, level: 'ok', detail: `scheduled ${c ? describeRegistryCall(c.call) : 'change'} ${c?.status === 'executed' ? 'executed' : c?.status === 'cancelled' ? 'was cancelled' : 'is no longer queued'}` });
      this.reported.delete(id);
    }
    for (const id of now) this.reported.add(id);
    return results;
  }
}
