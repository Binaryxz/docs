/**
 * The hedge sleeve's funding path (task B5), as transactions for the roles that sign them:
 *
 *   out:   MovvaReserve.withdrawToHedge (treasurer Safe; above the daily limit queueHedgeWithdrawal, then
 *          executeHedgeWithdrawal by anyone)  ->  hedge-treasury Safe  ->  HedgeSubWallet.fund (hedge Safe)
 *   home:  HedgeSubWallet.withdrawToTreasury (hedge Safe)  ->  hedge-treasury Safe  ->  MovvaReserve.recapitalize
 *          (hedge Safe); HedgeSubWallet.unwind first to bring the whole book home
 *
 * Every planner reads the chain, checks the preconditions the contracts will enforce (the hedge limit,
 * the reserve's hedge treasury being the sub-wallet's treasury, balances, roles), and returns the exact
 * calls. Who executes them is read from the chain too: a role held by a contract is treated as a Safe
 * (its owners, threshold and nonce are read, and the plan carries the Safe transaction and its EIP-712
 * hash for the signers), a role held by a plain key gets a plain transaction. Several calls by one Safe
 * (approve + fund, approve + recapitalize) go out as ONE Safe transaction through Safe 1.4.1's canonical
 * MultiSendCallOnly, which can only CALL - the one DELEGATECALL target used, checked by code hash.
 *
 * Nothing here signs or sends. `bin/hedge-sleeve.ts` prints a plan (the dry run, and the multisig
 * workflow: hand the Safe transaction to the signers) and, with `--execute --confirm`, signs and sends it.
 */
import {
  concat, encodeFunctionData, encodePacked, getAddress, hashTypedData, keccak256, parseAbi, size, type Address, type Hex, type PublicClient,
} from 'viem';

export const MULTISEND_CALL_ONLY: Address = getAddress('0x9641d764fc13c8B624c04430C7356C1C7C8102e2');
/** Its runtime code hash on mainnet and Sepolia (packages/smart-account RECOVERY_CODEHASHES). */
export const MULTISEND_CALL_ONLY_CODEHASH: Hex = '0xecd5bd14a08c5d2122379900b2f272bdf107a7e92423c10dd5fe3254386c9939';

export const RESERVE_HEDGE_ABI = parseAbi([
  'function treasurer() view returns (address)',
  'function hedgeTreasury() view returns (address)',
  'function hedgeWithdrawable() view returns (uint256)',
  'function hedgeLimitBps() view returns (uint16)',
  'function totalUsdt() view returns (uint256)',
  'function hedgeRequestCount() view returns (uint256)',
  'function hedgeRequests(uint256) view returns (address to, uint64 executeAfter, bool executed, uint256 usdt)',
  'function HEDGE_QUEUE_DELAY() view returns (uint64)',
  'function setupComplete() view returns (bool)',
  'function withdrawToHedge(uint256 usdt)',
  'function queueHedgeWithdrawal(uint256 usdt) returns (uint256 id)',
  'function executeHedgeWithdrawal(uint256 id)',
  'function recapitalize(uint256 usdt)',
]);

export const SLEEVE_ABI = parseAbi([
  'function STABLE() view returns (address)',
  'function VENUE() view returns (address)',
  'function ASSET() view returns (bytes32)',
  'function TREASURY() view returns (address)',
  'function REFERENCE() view returns (address)',
  'function keeper() view returns (address)',
  'function guardian() view returns (address)',
  'function governor() view returns (address)',
  'function setupComplete() view returns (bool)',
  'function exposurePaused() view returns (bool)',
  'function fundingEmaE8() view returns (int256)',
  'function remainingTurnover() view returns (uint256)',
  'function totalFunded() view returns (uint256)',
  'function totalWithdrawn() view returns (uint256)',
  'function getParams() view returns ((uint16 targetLeverageBps, uint16 maxLeverageBps, uint16 deltaToleranceBps, uint16 slippageBps, uint16 priceBandBps, int32 fundingPauseE8, int32 fundingExitE8, uint32 fundingTau, uint32 minActionInterval, uint32 maxReferenceAge, uint64 maxOrderNotional, uint64 maxWindowTurnover, uint64 allocationCap))',
  'function fund(uint256 amount)',
  'function withdrawToTreasury(uint256 amount) returns (uint256 paid)',
  'function unwind(uint256 sellLimitPx, uint256 buyLimitPx)',
  'function pauseExposure()',
  'function rebalance()',
  'function harvest()',
  'function deleverage()',
  'error NothingToDo()',
  'error TooSoon(uint256 readyAt)',
  'error NotKeeper()',
  'error NotTreasury()',
  'error TurnoverExhausted(uint256 wanted, uint256 remaining)',
  'error OutOfBand(uint8 which, uint256 px, uint256 ref)',
  'error StaleReference(uint256 updatedAt)',
  'error StaleVenuePrice(uint256 updatedAt)',
  'error BadReference(int256 answer)',
  'error InsufficientLiquid(uint256 wanted, uint256 available)',
  'error FillOutsideLimit(uint256 avgPx, uint256 limitPx)',
  'error SetupIncomplete()',
]);

export const SLEEVE_VENUE_ABI = parseAbi([
  'function cash(address account) view returns (uint256)',
  'function spotBalance(address account, bytes32 asset) view returns (uint256)',
  'function perpPosition(address account, bytes32 asset) view returns ((int256 size, uint256 entryPx))',
  'function marginAccount(address account) view returns ((int256 equity, uint256 maintenance, uint256 initial, uint256 withdrawable))',
  'function prices(bytes32 asset) view returns ((uint256 mark, uint256 index, uint256 spot, uint256 updatedAt))',
  'function fundingRate(bytes32 asset) view returns (int256)',
]);

const ERC20_ABI = parseAbi([
  'function balanceOf(address) view returns (uint256)',
  'function allowance(address owner, address spender) view returns (uint256)',
  'function approve(address spender, uint256 amount)',
]);

const FEED_ABI = parseAbi([
  'function decimals() view returns (uint8)',
  'function latestRoundData() view returns (uint80, int256, uint256, uint256, uint80)',
]);

export const SAFE_ABI = parseAbi([
  'function getOwners() view returns (address[])',
  'function getThreshold() view returns (uint256)',
  'function nonce() view returns (uint256)',
  'function VERSION() view returns (string)',
  'function getTransactionHash(address to, uint256 value, bytes data, uint8 operation, uint256 safeTxGas, uint256 baseGas, uint256 gasPrice, address gasToken, address refundReceiver, uint256 _nonce) view returns (bytes32)',
  'function execTransaction(address to, uint256 value, bytes data, uint8 operation, uint256 safeTxGas, uint256 baseGas, uint256 gasPrice, address gasToken, address refundReceiver, bytes signatures) payable returns (bool)',
  'function approveHash(bytes32 hashToApprove)',
  'event ExecutionSuccess(bytes32 txHash, uint256 payment)',
  'event ExecutionFailure(bytes32 txHash, uint256 payment)',
]);

const MULTISEND_ABI = parseAbi(['function multiSend(bytes transactions) payable']);
const ZERO: Address = '0x0000000000000000000000000000000000000000';

export type SleeveClient = Pick<PublicClient, 'readContract' | 'getBlock' | 'getCode'>;

export interface SleeveAddresses {
  reserve: Address;
  wallet: Address;
}

export interface SleeveCtx {
  client: SleeveClient;
  chainId: number;
  addresses: SleeveAddresses;
}

export interface InnerCall {
  to: Address;
  data: Hex;
  /** `name(type,...)`, for people. */
  fn: string;
  args: readonly unknown[];
}

/** A Safe transaction as Safe 1.4.1 hashes it (no refund: the submitter pays gas). */
export interface SafeTx {
  to: Address;
  value: bigint;
  data: Hex;
  operation: 0 | 1;
  safeTxGas: bigint;
  baseGas: bigint;
  gasPrice: bigint;
  gasToken: Address;
  refundReceiver: Address;
  nonce: bigint;
}

export interface SafeInfo {
  address: Address;
  owners: Address[];
  threshold: number;
  nonce: bigint;
  version: string;
}

export type Role = 'treasurer' | 'hedge-treasury' | 'anyone';

export interface SleevePlan {
  command: string;
  what: string;
  role: Role;
  /** Who executes: the role's address (a Safe or a key), or nobody in particular. */
  actor?: Address;
  actorKind: 'safe' | 'eoa' | 'anyone';
  calls: InnerCall[];
  /** The one transaction the actor sends (or the Safe executes): a single call, or a MultiSendCallOnly batch. */
  tx: { to: Address; data: Hex; operation: 0 | 1 };
  safe?: SafeInfo & { tx: SafeTx; safeTxHash: Hex };
  facts: string[];
  checks: { ok: boolean; text: string }[];
  warnings: string[];
  /** What `--confirm` must name. */
  confirm: string;
  refused: boolean;
}

const usd = (x: bigint) => `${(Number(x) / 1e6).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USDT`;
const same = (a?: string, b?: string) => !!a && !!b && a.toLowerCase() === b.toLowerCase();

function call(to: Address, abi: readonly unknown[], functionName: string, args: readonly unknown[], fn: string): InnerCall {
  return { to, data: encodeFunctionData({ abi, functionName, args } as never), fn, args };
}

/** MultiSendCallOnly's packed format: operation(1) to(20) value(32) length(32) data. CALLs only. */
export function encodeMultiSend(calls: readonly InnerCall[]): Hex {
  const packed = concat(calls.map((c) => encodePacked(['uint8', 'address', 'uint256', 'uint256', 'bytes'], [0, c.to, 0n, BigInt(size(c.data)), c.data])));
  return encodeFunctionData({ abi: MULTISEND_ABI, functionName: 'multiSend', args: [packed] });
}

/** Safe 1.4.1's EIP-712 hash of a transaction: what each signer signs. */
export function safeTxHash(chainId: number, safe: Address, tx: SafeTx): Hex {
  return hashTypedData({
    domain: { chainId, verifyingContract: safe },
    types: {
      SafeTx: [
        { name: 'to', type: 'address' }, { name: 'value', type: 'uint256' }, { name: 'data', type: 'bytes' }, { name: 'operation', type: 'uint8' },
        { name: 'safeTxGas', type: 'uint256' }, { name: 'baseGas', type: 'uint256' }, { name: 'gasPrice', type: 'uint256' },
        { name: 'gasToken', type: 'address' }, { name: 'refundReceiver', type: 'address' }, { name: 'nonce', type: 'uint256' },
      ],
    },
    primaryType: 'SafeTx',
    message: { ...tx },
  });
}

/** `execTransaction` calldata carrying `signatures` (65 bytes each, sorted by owner). */
export function encodeExecTransaction(tx: SafeTx, signatures: Hex): Hex {
  return encodeFunctionData({
    abi: SAFE_ABI, functionName: 'execTransaction',
    args: [tx.to, tx.value, tx.data, tx.operation, tx.safeTxGas, tx.baseGas, tx.gasPrice, tx.gasToken, tx.refundReceiver, signatures],
  });
}

/**
 * Safe's "approved hash" signatures (v = 1, r = the owner): valid for an owner that called
 * `approveHash(safeTxHash)` or that submits the transaction itself. What the fork rehearsal uses with
 * impersonated owners, so no signer key is needed there; signers on a live Safe use ECDSA instead.
 */
export function approvedHashSignatures(owners: readonly Address[]): Hex {
  const sorted = [...owners].sort((a, b) => (BigInt(a) < BigInt(b) ? -1 : 1));
  return concat(sorted.map((o) => encodePacked(['bytes32', 'bytes32', 'uint8'], [`0x${o.slice(2).toLowerCase().padStart(64, '0')}`, `0x${'0'.repeat(64)}`, 1])));
}

/** Sort ECDSA signatures by their signer, as Safe requires. */
export function sortedSignatures(sigs: readonly { signer: Address; signature: Hex }[]): Hex {
  return concat([...sigs].sort((a, b) => (BigInt(a.signer) < BigInt(b.signer) ? -1 : 1)).map((s) => s.signature));
}

async function isContract(c: SleeveClient, a: Address): Promise<boolean> {
  const code = await c.getCode({ address: a });
  return !!code && code !== '0x';
}

export async function readSafe(c: SleeveClient, safe: Address): Promise<SafeInfo> {
  const r = <T>(functionName: string) => c.readContract({ address: safe, abi: SAFE_ABI, functionName } as never) as Promise<T>;
  const [owners, threshold, nonce, version] = await Promise.all([r<Address[]>('getOwners'), r<bigint>('getThreshold'), r<bigint>('nonce'), r<string>('VERSION')]);
  return { address: safe, owners: [...owners], threshold: Number(threshold), nonce, version };
}

/** The facts every plan rests on. */
export async function readSleeve(ctx: SleeveCtx) {
  const { client: c, addresses: { reserve, wallet } } = ctx;
  const R = <T>(functionName: string, args: readonly unknown[] = []) => c.readContract({ address: reserve, abi: RESERVE_HEDGE_ABI, functionName, args } as never) as Promise<T>;
  const W = <T>(functionName: string) => c.readContract({ address: wallet, abi: SLEEVE_ABI, functionName } as never) as Promise<T>;
  const [treasurer, hedgeTreasury, withdrawable, limitBps, totalUsdt, walletTreasury, stable, venue, asset, paused, setupComplete, keeper, guardian] = await Promise.all([
    R<Address>('treasurer'), R<Address>('hedgeTreasury'), R<bigint>('hedgeWithdrawable'), R<number>('hedgeLimitBps'), R<bigint>('totalUsdt'),
    W<Address>('TREASURY'), W<Address>('STABLE'), W<Address>('VENUE'), W<Hex>('ASSET'), W<boolean>('exposurePaused'), W<boolean>('setupComplete'),
    W<Address>('keeper'), W<Address>('guardian'),
  ]);
  const T = <T>(functionName: string, args: readonly unknown[]) => c.readContract({ address: stable, abi: ERC20_ABI, functionName, args } as never) as Promise<T>;
  const [treasuryBalance, walletIdle] = await Promise.all([T<bigint>('balanceOf', [walletTreasury]), T<bigint>('balanceOf', [wallet])]);
  return { treasurer, hedgeTreasury, withdrawable, limitBps, totalUsdt, walletTreasury, stable, venue, asset, paused, setupComplete, keeper, guardian, treasuryBalance, walletIdle };
}

/** The actor's side of a plan: a Safe transaction (multisend for several calls) or a plain one. */
async function actorTx(ctx: SleeveCtx, actor: Address, calls: InnerCall[], checks: SleevePlan['checks']): Promise<Pick<SleevePlan, 'tx' | 'safe' | 'actorKind'>> {
  const batch = calls.length > 1;
  const tx = batch ? { to: MULTISEND_CALL_ONLY, data: encodeMultiSend(calls), operation: 1 as const } : { to: calls[0].to, data: calls[0].data, operation: 0 as const };
  if (!(await isContract(ctx.client, actor))) {
    if (batch) checks.push({ ok: true, text: `${actor} is a plain key: the ${calls.length} calls are sent one by one, in order` });
    return { actorKind: 'eoa', tx: batch ? { to: calls[0].to, data: calls[0].data, operation: 0 } : tx };
  }
  const safe = await readSafe(ctx.client, actor);
  checks.push({ ok: safe.version.startsWith('1.4'), text: `${actor} is a Safe ${safe.version}, ${safe.threshold}-of-${safe.owners.length}, nonce ${safe.nonce}` });
  if (batch) {
    const code = await ctx.client.getCode({ address: MULTISEND_CALL_ONLY });
    const ok = !!code && keccak256(code) === MULTISEND_CALL_ONLY_CODEHASH;
    checks.push({ ok, text: ok ? `MultiSendCallOnly 1.4.1 at ${MULTISEND_CALL_ONLY} (code hash checked): the batch can only CALL` : `MultiSendCallOnly at ${MULTISEND_CALL_ONLY} is missing or not the canonical code` });
  }
  const st: SafeTx = { ...tx, value: 0n, safeTxGas: 0n, baseGas: 0n, gasPrice: 0n, gasToken: ZERO, refundReceiver: ZERO, nonce: safe.nonce };
  return { actorKind: 'safe', tx, safe: { ...safe, tx: st, safeTxHash: safeTxHash(ctx.chainId, actor, st) } };
}

const finish = (p: Omit<SleevePlan, 'refused'>): SleevePlan => ({ ...p, refused: p.checks.some((c) => !c.ok) });

/** The common check: the reserve pays the Safe the sub-wallet will take money from and return it to. */
function treasuryLinked(s: Awaited<ReturnType<typeof readSleeve>>): { ok: boolean; text: string } {
  return same(s.hedgeTreasury, s.walletTreasury)
    ? { ok: true, text: `the reserve's hedgeTreasury is the sub-wallet's TREASURY (${s.walletTreasury})` }
    : { ok: false, text: `the reserve's hedgeTreasury is ${s.hedgeTreasury}, but the sub-wallet's TREASURY is ${s.walletTreasury}: execute the scheduled setHedgeTreasury first (custody rehearsal phase 2)` };
}

/** `reserve:withdraw <usdt>`: the treasurer moves USDT to the hedge treasury, inside the daily hedge limit. */
export async function planReserveWithdraw(ctx: SleeveCtx, amount: bigint): Promise<SleevePlan> {
  const s = await readSleeve(ctx);
  const checks: SleevePlan['checks'] = [
    { ok: amount > 0n, text: 'a positive amount' },
    treasuryLinked(s),
    amount <= s.withdrawable
      ? { ok: true, text: `${usd(amount)} is inside the hedge limit's room now (${usd(s.withdrawable)}; ${s.limitBps} bps of ${usd(s.totalUsdt)} per 24 h)` }
      : { ok: false, text: `${usd(amount)} is over the hedge limit's room (${usd(s.withdrawable)}): use reserve:queue, which waits HEDGE_QUEUE_DELAY` },
  ];
  const calls = [call(ctx.addresses.reserve, RESERVE_HEDGE_ABI, 'withdrawToHedge', [amount], 'withdrawToHedge(uint256)')];
  return finish({
    command: 'reserve:withdraw', what: `MovvaReserve pays ${usd(amount)} to the hedge treasury ${s.hedgeTreasury}`, role: 'treasurer', actor: s.treasurer,
    calls, ...(await actorTx(ctx, s.treasurer, calls, checks)),
    facts: [`the reserve also re-checks the collateral-ratio floor and the divergence breaker; a stale FX rate makes it revert`],
    checks, warnings: [], confirm: amount.toString(),
  });
}

/** `reserve:queue <usdt>`: above the daily limit. Executable by anyone after HEDGE_QUEUE_DELAY; nobody can cancel it. */
export async function planReserveQueue(ctx: SleeveCtx, amount: bigint): Promise<SleevePlan> {
  const s = await readSleeve(ctx);
  const delay = await ctx.client.readContract({ address: ctx.addresses.reserve, abi: RESERVE_HEDGE_ABI, functionName: 'HEDGE_QUEUE_DELAY' }) as bigint;
  const checks: SleevePlan['checks'] = [{ ok: amount > 0n, text: 'a positive amount' }, treasuryLinked(s)];
  const calls = [call(ctx.addresses.reserve, RESERVE_HEDGE_ABI, 'queueHedgeWithdrawal', [amount], 'queueHedgeWithdrawal(uint256)')];
  return finish({
    command: 'reserve:queue', what: `announce ${usd(amount)} to the hedge treasury, payable by anyone ${Number(delay) / 3600} h later`, role: 'treasurer', actor: s.treasurer,
    calls, ...(await actorTx(ctx, s.treasurer, calls, checks)),
    facts: ['nobody can cancel, change or reorder a queued hedge withdrawal; users have the whole delay to redeem'],
    checks, warnings: [], confirm: amount.toString(),
  });
}

/** `reserve:execute <id>`: pay a queued hedge withdrawal. Anyone may. */
export async function planReserveExecute(ctx: SleeveCtx, id: bigint): Promise<SleevePlan> {
  const r = await ctx.client.readContract({ address: ctx.addresses.reserve, abi: RESERVE_HEDGE_ABI, functionName: 'hedgeRequests', args: [id] }) as readonly [Address, bigint, boolean, bigint];
  const now = (await ctx.client.getBlock()).timestamp;
  const checks: SleevePlan['checks'] = [
    { ok: r[0] !== ZERO, text: r[0] !== ZERO ? `request ${id}: ${usd(r[3])} to ${r[0]}` : `no hedge request ${id}` },
    { ok: !r[2], text: r[2] ? 'already executed' : 'not executed yet' },
    { ok: now >= r[1], text: now >= r[1] ? 'its delay has passed' : `not executable until ${new Date(Number(r[1]) * 1000).toISOString()}` },
  ];
  const calls = [call(ctx.addresses.reserve, RESERVE_HEDGE_ABI, 'executeHedgeWithdrawal', [id], 'executeHedgeWithdrawal(uint256)')];
  return finish({ command: 'reserve:execute', what: `pay hedge request ${id}`, role: 'anyone', actorKind: 'anyone', calls, tx: { to: calls[0].to, data: calls[0].data, operation: 0 }, facts: [], checks, warnings: [], confirm: id.toString() });
}

/** USDT's approve refuses to move a non-zero allowance to another non-zero one: reset it first when needed. */
async function approveCalls(ctx: SleeveCtx, token: Address, owner: Address, spender: Address, amount: bigint): Promise<InnerCall[]> {
  const current = await ctx.client.readContract({ address: token, abi: ERC20_ABI, functionName: 'allowance', args: [owner, spender] }) as bigint;
  const out: InnerCall[] = [];
  if (current !== 0n) out.push(call(token, ERC20_ABI, 'approve', [spender, 0n], 'approve(address,uint256)'));
  out.push(call(token, ERC20_ABI, 'approve', [spender, amount], 'approve(address,uint256)'));
  return out;
}

/** `sleeve:fund <usdt>`: the hedge Safe approves the sub-wallet and funds it, in one Safe transaction. */
export async function planFund(ctx: SleeveCtx, amount: bigint): Promise<SleevePlan> {
  const s = await readSleeve(ctx);
  const checks: SleevePlan['checks'] = [
    { ok: amount > 0n, text: 'a positive amount' },
    { ok: s.setupComplete, text: s.setupComplete ? 'the sub-wallet finished setup' : 'the sub-wallet is still in setup: fund() reverts until completeSetup()' },
    { ok: amount <= s.treasuryBalance, text: `the hedge treasury holds ${usd(s.treasuryBalance)}` },
  ];
  const calls = [...await approveCalls(ctx, s.stable, s.walletTreasury, ctx.addresses.wallet, amount),
    call(ctx.addresses.wallet, SLEEVE_ABI, 'fund', [amount], 'fund(uint256)')];
  return finish({
    command: 'sleeve:fund', what: `the hedge treasury funds the sub-wallet with ${usd(amount)}`, role: 'hedge-treasury', actor: s.walletTreasury,
    calls, ...(await actorTx(ctx, s.walletTreasury, calls, checks)),
    facts: [`the keeper may deploy it only through rebalance(), bounded on-chain; it can come back only to ${s.walletTreasury}`],
    checks, warnings: s.paused ? ['exposure is paused: the funds will sit idle until the governor resumes'] : [], confirm: amount.toString(),
  });
}

/** `sleeve:withdraw <usdt|all>`: the hedge Safe takes money home from the sub-wallet. */
export async function planWithdrawToTreasury(ctx: SleeveCtx, amount: bigint | 'all'): Promise<SleevePlan> {
  const s = await readSleeve(ctx);
  const n = amount === 'all' ? 2n ** 256n - 1n : amount;
  const checks: SleevePlan['checks'] = [{ ok: n > 0n, text: 'a positive amount' }];
  const warnings = [`only margin above the max-leverage requirement comes out: unwind first (sleeve:unwind) to take everything`];
  const calls = [call(ctx.addresses.wallet, SLEEVE_ABI, 'withdrawToTreasury', [n], 'withdrawToTreasury(uint256)')];
  return finish({
    command: 'sleeve:withdraw', what: `the sub-wallet pays ${amount === 'all' ? 'everything available' : usd(n)} to ${s.walletTreasury}`, role: 'hedge-treasury', actor: s.walletTreasury,
    calls, ...(await actorTx(ctx, s.walletTreasury, calls, checks)),
    facts: [`idle in the sub-wallet now: ${usd(s.walletIdle)}`], checks, warnings, confirm: amount === 'all' ? 'all' : n.toString(),
  });
}

/** `sleeve:unwind [bandBps]`: close both legs at the treasury's own limits around the reference price. */
export async function planUnwind(ctx: SleeveCtx, bandBps = 100): Promise<SleevePlan> {
  const s = await readSleeve(ctx);
  const ref = await ctx.client.readContract({ address: ctx.addresses.wallet, abi: SLEEVE_ABI, functionName: 'REFERENCE' }) as Address;
  const [dec, round] = await Promise.all([
    ctx.client.readContract({ address: ref, abi: FEED_ABI, functionName: 'decimals' }) as Promise<number>,
    ctx.client.readContract({ address: ref, abi: FEED_ABI, functionName: 'latestRoundData' }) as Promise<readonly [bigint, bigint, bigint, bigint, bigint]>,
  ]);
  const px = round[1] * 10n ** BigInt(18 - Number(dec));
  const sell = (px * BigInt(10_000 - bandBps)) / 10_000n;
  const buy = (px * BigInt(10_000 + bandBps)) / 10_000n;
  const checks: SleevePlan['checks'] = [{ ok: bandBps > 0 && bandBps <= 2_000, text: `limits ${bandBps} bps either side of the reference ($${(Number(px) / 1e18).toFixed(2)})` }];
  const calls = [call(ctx.addresses.wallet, SLEEVE_ABI, 'unwind', [sell, buy], 'unwind(uint256,uint256)')];
  return finish({
    command: 'sleeve:unwind', what: `close both legs (sell at >= $${(Number(sell) / 1e18).toFixed(2)}, buy back at <= $${(Number(buy) / 1e18).toFixed(2)}) and pause exposure`, role: 'hedge-treasury', actor: s.walletTreasury,
    calls, ...(await actorTx(ctx, s.walletTreasury, calls, checks)),
    facts: ['needs neither the keeper nor a fresh reference: the limits are the treasury\'s own, fixed when signed', 'a Safe transaction signed now carries these limits: re-plan if the price moves past them'],
    checks, warnings: [], confirm: 'unwind',
  });
}

/** `reserve:recapitalize <usdt>`: the hedge Safe returns USDT to MovvaReserve, in one Safe transaction. */
export async function planRecapitalize(ctx: SleeveCtx, amount: bigint): Promise<SleevePlan> {
  const s = await readSleeve(ctx);
  const checks: SleevePlan['checks'] = [
    { ok: amount > 0n, text: 'a positive amount' },
    { ok: amount <= s.treasuryBalance, text: `the hedge treasury holds ${usd(s.treasuryBalance)}` },
  ];
  const calls = [...await approveCalls(ctx, s.stable, s.walletTreasury, ctx.addresses.reserve, amount),
    call(ctx.addresses.reserve, RESERVE_HEDGE_ABI, 'recapitalize', [amount], 'recapitalize(uint256)')];
  return finish({
    command: 'reserve:recapitalize', what: `the hedge treasury returns ${usd(amount)} to MovvaReserve`, role: 'hedge-treasury', actor: s.walletTreasury,
    calls, ...(await actorTx(ctx, s.walletTreasury, calls, checks)),
    facts: ['recapitalize takes USDT in and pays nothing out; it works with a stale rate'], checks, warnings: [], confirm: amount.toString(),
  });
}

/** `sleeve:pause`: the hedge Safe (or guardian, or governor) stops new exposure at once. */
export async function planPause(ctx: SleeveCtx): Promise<SleevePlan> {
  const s = await readSleeve(ctx);
  const checks: SleevePlan['checks'] = [{ ok: !s.paused, text: s.paused ? 'already paused' : 'exposure is live' }];
  const calls = [call(ctx.addresses.wallet, SLEEVE_ABI, 'pauseExposure', [], 'pauseExposure()')];
  return finish({
    command: 'sleeve:pause', what: 'stop adding exposure; the keeper unwinds within its bounds', role: 'hedge-treasury', actor: s.walletTreasury,
    calls, ...(await actorTx(ctx, s.walletTreasury, calls, checks)),
    facts: [`the guardian ${s.guardian} can send the same call directly`], checks, warnings: [], confirm: 'pause',
  });
}

/*//////////////////////////////////////////////////////////////
                               EXECUTION
//////////////////////////////////////////////////////////////*/

export type Signer = { address: Address; sign: (a: { hash: Hex }) => Promise<Hex> };

/**
 * How a plan is executed:
 *  - `keys`: owners' keys sign the safeTxHash (ECDSA, any `threshold` of them), `submitter` sends
 *    execTransaction (it needs ETH, not ownership); for a plain-key role `submitter` IS the role's key;
 *  - `impersonate`: ANVIL FORKS ONLY - the role (or `threshold` owners of its Safe) is impersonated, the
 *    owners `approveHash` the real safeTxHash and execTransaction carries approved-hash signatures. The
 *    Safe's own threshold check runs for real; no key exists or is needed.
 */
export type ExecMode =
  | { kind: 'keys'; signers: Signer[]; submitter: Signer & { sendTransaction: (tx: { to: Address; data: Hex }) => Promise<Hex> } }
  | { kind: 'impersonate'; rpc: (method: string, params: unknown[]) => Promise<unknown>; owners?: Address[] };

export interface Executed { hashes: Hex[]; safeTxHash?: Hex }

type ExecClient = Pick<PublicClient, 'waitForTransactionReceipt' | 'readContract' | 'call'>;

async function mined(c: ExecClient, hash: Hex, what: string) {
  const rc = await c.waitForTransactionReceipt({ hash });
  if (rc.status !== 'success') throw new Error(`${what}: reverted on chain (${hash})`);
  return rc;
}

const EXEC_SUCCESS = keccak256(new TextEncoder().encode('ExecutionSuccess(bytes32,uint256)'));

/** Execute a plan the planners above produced. Refuses a refused plan. */
export async function executeSleevePlan(c: ExecClient, p: SleevePlan, mode: ExecMode): Promise<Executed> {
  if (p.refused) throw new Error(`${p.command}: refused by its checks; nothing sent`);
  const hashes: Hex[] = [];
  const sendAs = async (from: Address, to: Address, data: Hex, what: string): Promise<Hex> => {
    let hash: Hex;
    if (mode.kind === 'keys') {
      if (!same(mode.submitter.address, from) && p.actorKind !== 'safe') throw new Error(`${what}: the key is ${mode.submitter.address}, but ${from} must send it`);
      await c.call({ account: mode.submitter.address, to, data });
      hash = await mode.submitter.sendTransaction({ to, data });
    } else {
      await mode.rpc('anvil_impersonateAccount', [from]);
      await mode.rpc('anvil_setBalance', [from, '0x8ac7230489e80000']);
      hash = await mode.rpc('eth_sendTransaction', [{ from, to, data }]) as Hex;
    }
    await mined(c, hash, what);
    hashes.push(hash);
    return hash;
  };

  if (p.actorKind !== 'safe') {
    const from = p.actor ?? (mode.kind === 'keys' ? mode.submitter.address : undefined);
    if (!from) throw new Error(`${p.command}: impersonating "anyone" needs a sender`);
    for (const k of p.calls) await sendAs(mode.kind === 'keys' ? mode.submitter.address : from, k.to, k.data, `${p.command} ${k.fn}`);
    return { hashes };
  }

  const s = p.safe!;
  const onChain = await c.readContract({
    address: s.address, abi: SAFE_ABI, functionName: 'getTransactionHash',
    args: [s.tx.to, s.tx.value, s.tx.data, s.tx.operation, s.tx.safeTxGas, s.tx.baseGas, s.tx.gasPrice, s.tx.gasToken, s.tx.refundReceiver, s.tx.nonce],
  }) as Hex;
  if (onChain !== s.safeTxHash) throw new Error(`${p.command}: the Safe hashes this transaction as ${onChain}, not ${s.safeTxHash} (nonce moved? re-plan)`);
  let signatures: Hex;
  let submitter: Address;
  if (mode.kind === 'keys') {
    const owners = mode.signers.filter((k) => s.owners.some((o) => same(o, k.address)));
    if (owners.length < s.threshold) throw new Error(`${p.command}: ${owners.length} of the keys given own the Safe; it needs ${s.threshold}`);
    const sigs = await Promise.all(owners.slice(0, s.threshold).map(async (k) => ({ signer: k.address, signature: await k.sign({ hash: s.safeTxHash }) })));
    signatures = sortedSignatures(sigs);
    submitter = mode.submitter.address;
  } else {
    const owners = (mode.owners ?? s.owners).slice(0, s.threshold);
    for (const o of owners) await sendAs(o, s.address, encodeFunctionData({ abi: SAFE_ABI, functionName: 'approveHash', args: [s.safeTxHash] }), `${p.command} approveHash by ${o}`);
    signatures = approvedHashSignatures(owners);
    submitter = owners[0];
  }
  const data = encodeExecTransaction(s.tx, signatures);
  const hash = await sendAs(submitter, s.address, data, `${p.command} execTransaction`);
  const rc = await c.waitForTransactionReceipt({ hash });
  const ok = rc.logs.some((l) => same(l.address, s.address) && l.topics[0] === EXEC_SUCCESS);
  if (!ok) throw new Error(`${p.command}: the Safe ran the transaction but its inner call failed (ExecutionFailure)`);
  return { hashes, safeTxHash: s.safeTxHash };
}

/** Safe{Wallet}'s Transaction Builder file for a plan: the inner calls, which it batches itself. */
export function txBuilderJson(p: SleevePlan, chainId: number): unknown {
  return {
    version: '1.0', chainId: String(chainId), createdAt: Date.now(),
    meta: { name: p.command, description: p.what, createdFromSafeAddress: p.actor },
    transactions: p.calls.map((c) => ({ to: c.to, value: '0', data: c.data })),
  };
}

export function renderSleevePlan(p: SleevePlan, chainId: number): string {
  const L: string[] = [`${p.command}: ${p.what}`, `  role: ${p.role}${p.actor ? ` (${p.actor}, ${p.actorKind})` : ''}`];
  for (const f of p.facts) L.push(`  - ${f}`);
  L.push('  checks:');
  for (const c of p.checks) L.push(`    [${c.ok ? 'ok' : 'NO'}] ${c.text}`);
  for (const w of p.warnings) L.push(`  warning: ${w}`);
  L.push('  calls:');
  for (const c of p.calls) L.push(`    ${c.to} ${c.fn} (${c.args.map(String).join(', ')})\n      ${c.data}`);
  if (p.safe) {
    L.push(`  Safe transaction (Safe ${p.safe.address}, ${p.safe.threshold}-of-${p.safe.owners.length}, nonce ${p.safe.tx.nonce}, chain ${chainId}):`);
    L.push(`    to ${p.safe.tx.to}  operation ${p.safe.tx.operation === 1 ? '1 (DELEGATECALL to MultiSendCallOnly)' : '0 (CALL)'}  value 0`);
    L.push(`    data ${p.safe.tx.data}`);
    L.push(`    safeTxHash ${p.safe.safeTxHash}   <- each of ${p.safe.threshold} owners signs this`);
  } else if (p.actorKind === 'eoa') {
    L.push(`  plain transaction${p.calls.length > 1 ? 's, in order' : ''} from ${p.actor}`);
  }
  if (p.refused) L.push('  REFUSED: a check above failed');
  return L.join('\n');
}

/*//////////////////////////////////////////////////////////////
                         RESERVE RECONCILIATION
//////////////////////////////////////////////////////////////*/

const RESERVE_BOOK_ABI = parseAbi([
  'function liabilitiesUsdt() view returns (uint256)',
  'function liabilitiesBrlE18() view returns (uint256)',
  'function collateralRatioBps() view returns (uint256)',
  'function targetCollateralRatioBps() view returns (uint16)',
  'function minMintCollateralRatioBps() view returns (uint16)',
  'function minWithdrawCollateralRatioBps() view returns (uint16)',
  'function hedgeLimitBps() view returns (uint16)',
  'function fxOracle() view returns (address)',
  'function usdtUsdFeed() view returns (address)',
]);

const PYTH_FX_ABI = parseAbi([
  'function PYTH() view returns (address)',
  'function usdBrlId() view returns (bytes32)',
]);
const PYTH_ABI = parseAbi(['function getPriceUnsafe(bytes32 id) view returns ((int64 price, uint64 conf, int32 expo, uint256 publishTime))']);

/**
 * The reserve's rate, or - when it refuses (its FX leg is older than `fxMaxAge`, as outside FX hours) - the
 * same crossing done off-chain on the LAST POSTED rate, so a reconciliation can be read at any hour. The
 * fallback reads a Pyth-backed leg's raw price; any other leg refuses with the reason.
 */
export interface ReconRate {
  /** Reais per whole USDT at 1e18, as MovvaReserve crosses it. */
  brlPerUsdtE18: bigint;
  /** 'reserve': the contract's own figures. 'last-posted': the reserve refused; this is its last rate, stale. */
  source: 'reserve' | 'last-posted';
  /** Unix seconds of the FX leg's publish time (only for 'last-posted'). */
  fxPublishTime?: bigint;
}

/** Everything the reconciliation adds up, as the chain reports it, in the stablecoin's base units unless named. */
export interface ReconInputs {
  decimals: number;
  /** MovvaReserve.liabilitiesUsdt(): what MOVVA's supply is owed at R$ 1,00, in USDT at the current rate (rounded up). */
  liabilitiesUsdt: bigint;
  liabilitiesBrlE18: bigint;
  /** MovvaReserve.totalUsdt(), the only figure its on-chain ratio counts. */
  reserveUsdt: bigint;
  onchainRatioBps: bigint;
  /** The hedge-treasury Safe's balance: out of the reserve, not yet in the sub-wallet (or on its way home). */
  hedgeSafeUsdt: bigint;
  walletIdle: bigint;
  venueCash: bigint;
  /** Signed: a bankrupt margin account is negative. Spot balances are not in it. */
  marginEquity: bigint;
  spotQtyWad: bigint;
  markWad: bigint;
  totalFunded: bigint;
  totalWithdrawn: bigint;
}

export interface Reconciliation {
  liabilitiesUsdt: bigint;
  liabilitiesBrlE18: bigint;
  inReserve: bigint;
  onchainRatioBps: bigint;
  outside: { hedgeSafe: bigint; subWalletIdle: bigint; venueCash: bigint; marginEquity: bigint; spotValue: bigint; total: bigint };
  /** The sub-wallet's own value (idle + venue), against what it was funded with net of what it returned. */
  sleeve: { value: bigint; netFunded: bigint; pnl: bigint };
  /** Reserve plus everything outside it, over the liabilities. Off-chain: only `onchainRatioBps` binds the contracts. */
  combinedRatioBps: bigint;
  /** USDT Movva would have to add for the reserve ALONE to stand at 100% (0 when it does). */
  onchainShortfall: bigint;
  /** The same, counting what is out on the hedge path as if it were home. */
  combinedShortfall: bigint;
}

/** Pure: the sums, so the CLI and the tests share them. The spot leg is valued at the venue's mark. */
export function reconcile(i: ReconInputs): Reconciliation {
  const spotValue = (i.spotQtyWad * i.markWad * 10n ** BigInt(i.decimals)) / 10n ** 36n;
  const value = i.walletIdle + i.venueCash + i.marginEquity + spotValue;
  const total = i.hedgeSafeUsdt + value;
  const netFunded = i.totalFunded - i.totalWithdrawn;
  const combined = i.reserveUsdt + total;
  const pos = (x: bigint) => (x > 0n ? x : 0n);
  return {
    liabilitiesUsdt: i.liabilitiesUsdt,
    liabilitiesBrlE18: i.liabilitiesBrlE18,
    inReserve: i.reserveUsdt,
    onchainRatioBps: i.onchainRatioBps,
    outside: { hedgeSafe: i.hedgeSafeUsdt, subWalletIdle: i.walletIdle, venueCash: i.venueCash, marginEquity: i.marginEquity, spotValue, total },
    sleeve: { value, netFunded, pnl: value - netFunded },
    combinedRatioBps: i.liabilitiesUsdt === 0n ? 0n : (combined * 10_000n) / i.liabilitiesUsdt,
    onchainShortfall: pos(i.liabilitiesUsdt - i.reserveUsdt),
    combinedShortfall: pos(i.liabilitiesUsdt - combined),
  };
}

/** The limits in force on-chain: the reserve's ratio floors and hedge rate limit, and the sub-wallet's own params. */
export interface OnchainLimits {
  reserve: { targetRatioBps: number; minMintRatioBps: number; minWithdrawRatioBps: number; hedgeLimitBps: number };
  subWallet: {
    targetLeverageBps: number; maxLeverageBps: number; deltaToleranceBps: number; slippageBps: number; priceBandBps: number;
    fundingPauseE8: number; fundingExitE8: number; fundingTau: number; minActionInterval: number; maxReferenceAge: number;
    maxOrderNotional: bigint; maxWindowTurnover: bigint; allocationCap: bigint;
  };
}

/** One consistent read (pinned to one block) of everything `reconcile` needs, plus the limits. */
export async function readReconciliation(ctx: SleeveCtx & { client: SleeveClient & Pick<PublicClient, 'getBlockNumber'> }): Promise<{ block: bigint; rate: ReconRate; inputs: ReconInputs; limits: OnchainLimits }> {
  const c = ctx.client;
  const blockNumber = await c.getBlockNumber();
  const { reserve, wallet } = ctx.addresses;
  const rd = <T>(address: Address, abi: readonly unknown[], functionName: string, args: readonly unknown[] = []) =>
    c.readContract({ address, abi, functionName, args, blockNumber } as never) as Promise<T>;
  const [stable, venue, asset, hedgeTreasury] = await Promise.all([
    rd<Address>(wallet, SLEEVE_ABI, 'STABLE'), rd<Address>(wallet, SLEEVE_ABI, 'VENUE'), rd<Hex>(wallet, SLEEVE_ABI, 'ASSET'), rd<Address>(reserve, RESERVE_HEDGE_ABI, 'hedgeTreasury'),
  ]);
  const [decimals, liabilitiesBrlE18, reserveUsdt, hedgeSafeUsdt, walletIdle, venueCash, margin, spotQtyWad, px, totalFunded, totalWithdrawn,
    targetRatio, minMint, minWithdraw, hedgeLimit, params] = await Promise.all([
    rd<number>(stable, parseAbi(['function decimals() view returns (uint8)']), 'decimals'),
    rd<bigint>(reserve, RESERVE_BOOK_ABI, 'liabilitiesBrlE18'),
    rd<bigint>(reserve, RESERVE_HEDGE_ABI, 'totalUsdt'),
    rd<bigint>(stable, ERC20_ABI, 'balanceOf', [hedgeTreasury]), rd<bigint>(stable, ERC20_ABI, 'balanceOf', [wallet]),
    rd<bigint>(venue, SLEEVE_VENUE_ABI, 'cash', [wallet]),
    rd<{ equity: bigint }>(venue, SLEEVE_VENUE_ABI, 'marginAccount', [wallet]),
    rd<bigint>(venue, SLEEVE_VENUE_ABI, 'spotBalance', [wallet, asset]),
    rd<{ mark: bigint }>(venue, SLEEVE_VENUE_ABI, 'prices', [asset]),
    rd<bigint>(wallet, SLEEVE_ABI, 'totalFunded'), rd<bigint>(wallet, SLEEVE_ABI, 'totalWithdrawn'),
    rd<number>(reserve, RESERVE_BOOK_ABI, 'targetCollateralRatioBps'), rd<number>(reserve, RESERVE_BOOK_ABI, 'minMintCollateralRatioBps'),
    rd<number>(reserve, RESERVE_BOOK_ABI, 'minWithdrawCollateralRatioBps'), rd<number>(reserve, RESERVE_BOOK_ABI, 'hedgeLimitBps'),
    rd<OnchainLimits['subWallet']>(wallet, SLEEVE_ABI, 'getParams'),
  ]);
  let liabilitiesUsdt: bigint;
  let onchainRatioBps: bigint;
  let rate: ReconRate;
  try {
    const [l, r, [x]] = await Promise.all([
      rd<bigint>(reserve, RESERVE_BOOK_ABI, 'liabilitiesUsdt'), rd<bigint>(reserve, RESERVE_BOOK_ABI, 'collateralRatioBps'),
      rd<readonly [bigint, bigint]>(reserve, parseAbi(['function brlPerUsdtE18() view returns (uint256, uint64)']), 'brlPerUsdtE18'),
    ]);
    liabilitiesUsdt = l; onchainRatioBps = r; rate = { brlPerUsdtE18: x, source: 'reserve' };
  } catch {
    rate = await lastPostedRate(rd, reserve);
    ({ liabilitiesUsdt, onchainRatioBps } = bookAt(reserveUsdt, liabilitiesBrlE18, rate.brlPerUsdtE18));
  }
  return {
    block: blockNumber,
    rate,
    inputs: { decimals, liabilitiesUsdt, liabilitiesBrlE18, reserveUsdt, onchainRatioBps, hedgeSafeUsdt, walletIdle, venueCash, marginEquity: margin.equity, spotQtyWad, markWad: px.mark, totalFunded, totalWithdrawn },
    limits: {
      reserve: { targetRatioBps: targetRatio, minMintRatioBps: minMint, minWithdrawRatioBps: minWithdraw, hedgeLimitBps: hedgeLimit },
      subWallet: { ...params },
    },
  };
}

/** MovvaReserve's own arithmetic on a given rate: liabilities rounded up, reserve then ratio rounded down. */
export function bookAt(reserveUsdt: bigint, supplyBrlE18: bigint, brlPerUsdtE18: bigint): { liabilitiesUsdt: bigint; onchainRatioBps: bigint } {
  if (brlPerUsdtE18 === 0n) throw new Error('a zero rate');
  const liabilitiesUsdt = (supplyBrlE18 * 1_000_000n + brlPerUsdtE18 - 1n) / brlPerUsdtE18;
  const onchainRatioBps = supplyBrlE18 === 0n ? 0n : (((reserveUsdt * brlPerUsdtE18) / 1_000_000n) * 10_000n) / supplyBrlE18;
  return { liabilitiesUsdt, onchainRatioBps };
}

/** Pyth's price (x 10^expo) as reais per dollar at 1e-6, floored, as PythFxOracle converts it. */
export function pythToBrlPerUsdE6(price: bigint, expo: number): bigint {
  if (price <= 0n) throw new Error(`a non-positive FX price (${price})`);
  const shift = expo + 6;
  return shift >= 0 ? price * 10n ** BigInt(shift) : price / 10n ** BigInt(-shift);
}

async function lastPostedRate(
  rd: <T>(address: Address, abi: readonly unknown[], functionName: string, args?: readonly unknown[]) => Promise<T>, reserve: Address,
): Promise<ReconRate> {
  const [fx, feed] = await Promise.all([rd<Address>(reserve, RESERVE_BOOK_ABI, 'fxOracle'), rd<Address>(reserve, RESERVE_BOOK_ABI, 'usdtUsdFeed')]);
  let pyth: Address, id: Hex;
  try {
    [pyth, id] = await Promise.all([rd<Address>(fx, PYTH_FX_ABI, 'PYTH'), rd<Hex>(fx, PYTH_FX_ABI, 'usdBrlId')]);
  } catch {
    throw new Error(`the reserve refuses to price itself (its FX leg ${fx} is stale) and that leg is not Pyth-backed, so there is no last-posted rate to fall back on: post a fresh rate first`);
  }
  const [p, [, usd], dec] = await Promise.all([
    rd<{ price: bigint; expo: number; publishTime: bigint }>(pyth, PYTH_ABI, 'getPriceUnsafe', [id]),
    rd<readonly [bigint, bigint, bigint, bigint, bigint]>(feed, FEED_ABI, 'latestRoundData'),
    rd<number>(feed, FEED_ABI, 'decimals'),
  ]);
  const brlPerUsdE6 = pythToBrlPerUsdE6(p.price, p.expo);
  return { brlPerUsdtE18: (usd * brlPerUsdE6 * 10n ** 12n) / 10n ** BigInt(dec), source: 'last-posted', fxPublishTime: p.publishTime };
}

/** The reconciliation as an operator (or the client's finance team) reads it. */
export function renderReconciliation(r: Reconciliation, limits: OnchainLimits, decimals: number, block: bigint, rate?: ReconRate): string {
  const u = (x: bigint) => `${(Number(x) / 10 ** decimals).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USDT`;
  const pct = (bps: bigint | number) => `${(Number(bps) / 100).toFixed(2)}%`;
  const brl = (Number(r.liabilitiesBrlE18 / 10n ** 16n) / 100).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const s = limits.subWallet;
  const apr = (e8: number) => `${((e8 * 8760) / 1e6).toFixed(2)}% APR`;
  return [
    `reserve reconciliation at block ${block}`,
    ...(rate ? [rate.source === 'reserve'
      ? `  rate R$ ${(Number(rate.brlPerUsdtE18 / 10n ** 12n) / 1e6).toFixed(4)} per USDT (the reserve's own)`
      : `  rate R$ ${(Number(rate.brlPerUsdtE18 / 10n ** 12n) / 1e6).toFixed(4)} per USDT - STALE: the reserve refuses to price itself, so this is the last posted FX rate (${rate.fxPublishTime ? new Date(Number(rate.fxPublishTime) * 1000).toISOString() : '?'}), crossed off-chain as the reserve would`] : []),
    `  owed to MOVVA holders      R$ ${brl}  =  ${u(r.liabilitiesUsdt)} at the current rate`,
    `  in the reserve (on-chain)  ${u(r.inReserve)}   ratio ${pct(r.onchainRatioBps)}   <- the only figure the contracts count`,
    `  out on the hedge path      ${u(r.outside.total)}`,
    `    hedge Safe               ${u(r.outside.hedgeSafe)}`,
    `    sub-wallet idle          ${u(r.outside.subWalletIdle)}`,
    `    venue cash               ${u(r.outside.venueCash)}`,
    `    margin equity            ${u(r.outside.marginEquity)}`,
    `    spot leg at mark         ${u(r.outside.spotValue)}`,
    `  sleeve: worth ${u(r.sleeve.value)}, funded net ${u(r.sleeve.netFunded)}, result ${r.sleeve.pnl >= 0n ? '+' : ''}${u(r.sleeve.pnl)}`,
    `  combined (reserve + out)   ${u(r.inReserve + r.outside.total)}   ratio ${pct(r.combinedRatioBps)}`,
    `  Movva top-up needed for 100%: on-chain ${u(r.onchainShortfall)}, combined ${u(r.combinedShortfall)}`,
    `limits in force (on-chain)`,
    `  reserve: target ratio ${pct(limits.reserve.targetRatioBps)}; mint refused below ${pct(limits.reserve.minMintRatioBps)}; a hedge withdrawal must leave at least ${pct(limits.reserve.minWithdrawRatioBps)}; at most ${pct(limits.reserve.hedgeLimitBps)} of the reserve per 24 h to the hedge`,
    `  sub-wallet: leverage target ${(s.targetLeverageBps / 10_000).toFixed(2)}x, max ${(s.maxLeverageBps / 10_000).toFixed(2)}x; delta tolerance ${pct(s.deltaToleranceBps)}; slippage ${pct(s.slippageBps)}; price band ${pct(s.priceBandBps)}`,
    `              funding: no new exposure below ${apr(s.fundingPauseE8)}, unwind below ${apr(s.fundingExitE8)}; keeper every ${s.minActionInterval} s at most`,
    `              allocation cap ${u(s.allocationCap)}; max order ${u(s.maxOrderNotional)}; max keeper turnover ${u(s.maxWindowTurnover)} per window`,
  ].join('\n');
}
