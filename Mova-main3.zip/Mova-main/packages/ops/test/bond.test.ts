import { describe, expect, it } from 'vitest';
import { decodeFunctionData, getAddress, parseUnits } from 'viem';
import {
  BOND_COMMANDS, BOND_REGISTRY_ABI, BondUsageError, ERC20_ABI, bondSendRefusal, bondStatus, parseMovva, planExit, planJoin, planTopUp, planWithdraw,
  renderBondPlan, renderBondStatus, type BondCtx, type BondPlan,
} from '../src/bond.js';
import { LP_COMMANDS, parseArgs, parseRail } from '../src/bin/lp.js';

const REG = getAddress('0x1111111111111111111111111111111111111111');
const MOVVA = getAddress('0x2222222222222222222222222222222222222222');
const ONRAMP = getAddress('0x6666666666666666666666666666666666666666');
const OFFRAMP = getAddress('0x7777777777777777777777777777777777777777');
const OLD = getAddress('0x8888888888888888888888888888888888888888');
const LP = getAddress('0x3333333333333333333333333333333333333333');
const OTHER = getAddress('0x4444444444444444444444444444444444444444');
const ZERO = '0x0000000000000000000000000000000000000000';
const NOW = 1_800_000_000;
const DAY = 86_400n;
const M = (n: number | string) => parseUnits(String(n), 18);

interface Bond { amount?: bigint; exposure?: bigint; settled?: bigint; exitAt?: bigint; settlements?: number; lost?: number }
interface Chain {
  bound: boolean; minBond: bigint; unbonding: bigint; pointsBack: boolean;
  bonds: Record<string, Bond>; balance: Record<string, bigint>; allowance: Record<string, bigint>;
}

function chain(over: Partial<Chain> = {}): Chain {
  return { bound: true, minBond: M(5000), unbonding: 36n * DAY, pointsBack: true, bonds: {}, balance: {}, allowance: {}, ...over };
}

/** The registry's views as the contract computes them, from the state above. */
function fake(c: Chain) {
  const b = (lp: unknown): Required<Bond> => ({ amount: 0n, exposure: 0n, settled: 0n, exitAt: 0n, settlements: 0, lost: 0, ...c.bonds[String(lp).toLowerCase()] });
  const cap = (lp: unknown) => { const x = b(lp); return !c.bound || x.exitAt !== 0n || x.amount < c.minBond ? 0n : x.amount / 10n ** 16n; };
  return {
    readContract: async ({ address, functionName, args }: any): Promise<any> => {
      const a = String(address).toLowerCase();
      if (a === MOVVA.toLowerCase()) {
        if (functionName === 'balanceOf') return c.balance[String(args[0]).toLowerCase()] ?? 0n;
        if (functionName === 'allowance') return c.allowance[String(args[0]).toLowerCase()] ?? 0n;
      }
      if (a === ONRAMP.toLowerCase() || a === OFFRAMP.toLowerCase()) {
        if (functionName === 'REGISTRY') return c.pointsBack ? REG : OTHER;
        if (functionName === 'DISPUTE_TIMEOUT') return 30n * DAY;
      }
      if (a !== REG.toLowerCase()) throw new Error(`no contract at ${address}`);
      switch (functionName) {
        case 'MOVVA': return MOVVA;
        case 'PREDECESSOR': return OLD;
        case 'MIN_BOND': return c.minBond;
        case 'UNBONDING_PERIOD': return c.unbonding;
        case 'UNBONDING_MARGIN': return 4n * DAY;
        case 'ESCROW_RULING_DELAY': return DAY;
        case 'DEPLOYER': return OTHER;
        case 'escrowsBound': return c.bound;
        case 'fiatEscrow': return c.bound ? ONRAMP : ZERO;
        case 'offRampEscrow': return c.bound ? OFFRAMP : ZERO;
        case 'totalBonded': return Object.values(c.bonds).reduce((s, x) => s + (x.amount ?? 0n), 0n);
        case 'totalSlashed': return M(20000);
        case 'bonds': { const x = b(args[0]); return [x.amount, x.exposure, x.settled, x.exitAt, x.settlements, x.lost]; }
        case 'capOf': return cap(args[0]);
        case 'availableCents': { const k = cap(args[0]); const e = b(args[0]).exposure; return k > e ? k - e : 0n; }
        case 'withdrawableFrom': { const x = b(args[0]); return x.exitAt === 0n ? 0n : x.exitAt + c.unbonding; }
        default: throw new Error(`unexpected read ${functionName}`);
      }
    },
  };
}

const ctxOf = (c: Chain, now = NOW): BondCtx => ({ client: fake(c) as never, registry: REG, now });
const lo = (a: string) => a.toLowerCase();
const failing = (p: BondPlan) => p.checks.filter((x) => !x.ok).map((x) => x.text).join(' | ');
const decode = (p: BondPlan) => p.txs.map((t) => decodeFunctionData({ abi: [...BOND_REGISTRY_ABI, ...ERC20_ABI], data: t.data }));

describe('bond:join', () => {
  it('approves what is missing, then joins, and says the whole bond is at risk', async () => {
    const p = await planJoin(ctxOf(chain({ balance: { [lo(LP)]: M(10000) } })), ['5000'], LP);
    expect(p.refused, failing(p)).toBe(false);
    const calls = decode(p);
    expect(calls.map((x) => x.functionName)).toEqual(['approve', 'join']);
    expect(calls[0]!.args).toEqual([REG, M(5000)]);
    expect(p.txs[0]!.to).toBe(MOVVA);
    expect(calls[1]!.args).toEqual([M(5000)]);
    expect(p.txs[1]!.to).toBe(REG);
    expect(p.what).toMatch(/R\$ 5\.000,00 of credit/);
    expect(p.warnings.join(' ')).toMatch(/WHOLE bond/);
    expect(p.confirm).toBe(LP);
  });

  it('skips the approve when the allowance already covers it', async () => {
    const p = await planJoin(ctxOf(chain({ balance: { [lo(LP)]: M(9000) }, allowance: { [lo(LP)]: M(9000) } })), ['6000.5'], LP);
    expect(decode(p).map((x) => x.functionName)).toEqual(['join']);
    expect(decode(p)[0]!.args).toEqual([M('6000.5')]);
  });

  it('refuses what the registry would: below the minimum, already bonded, leaving, short wallet, unbound escrows', async () => {
    expect(failing(await planJoin(ctxOf(chain({ balance: { [lo(LP)]: M(1e6) } })), ['4999.99'], LP))).toMatch(/below the minimum bond 5000 MOVVA \(BelowMinBond\)/);
    expect(failing(await planJoin(ctxOf(chain({ balance: { [lo(LP)]: M(1e6) }, bonds: { [lo(LP)]: { amount: M(5000) } } })), ['5000'], LP))).toMatch(/bond:topup \(AlreadyBonded\)/);
    expect(failing(await planJoin(ctxOf(chain({ balance: { [lo(LP)]: M(1e6) }, bonds: { [lo(LP)]: { exitAt: 1n } } })), ['5000'], LP))).toMatch(/withdraw first.*\(Exiting\)/);
    expect(failing(await planJoin(ctxOf(chain({ balance: { [lo(LP)]: M(10) } })), ['5000'], LP))).toMatch(/holds only 10 MOVVA/);
    expect(failing(await planJoin(ctxOf(chain({ bound: false, balance: { [lo(LP)]: M(1e6) } })), ['5000'], LP))).toMatch(/NotBound/);
    expect(failing(await planJoin(ctxOf(chain({ pointsBack: false, balance: { [lo(LP)]: M(1e6) } })), ['5000'], LP))).toMatch(/does NOT name this registry/);
  });

  it('warns that live exposure from before counts against the new credit', async () => {
    const p = await planJoin(ctxOf(chain({ balance: { [lo(LP)]: M(1e6) }, bonds: { [lo(LP)]: { exposure: 150_000n, lost: 1 } } })), ['5000'], LP);
    expect(p.refused).toBe(false);
    expect(p.warnings.join(' ')).toMatch(/R\$ 1\.500,00 from before is still live/);
    expect(p.warnings.join(' ')).toMatch(/lost 1 dispute/);
  });
});

describe('bond:topup', () => {
  it('adds to a live bond', async () => {
    const c = chain({ balance: { [lo(LP)]: M(1e6) }, allowance: { [lo(LP)]: M(1e6) }, bonds: { [lo(LP)]: { amount: M(5000) } } });
    const p = await planTopUp(ctxOf(c), ['2500'], LP);
    expect(p.refused, failing(p)).toBe(false);
    expect(decode(p).map((x) => [x.functionName, x.args])).toEqual([['topUp', [M(2500)]]]);
    expect(p.what).toMatch(/R\$ 5\.000,00 -> R\$ 7\.500,00/);
  });

  it('refuses with no bond, while leaving, or for nothing', async () => {
    expect(failing(await planTopUp(ctxOf(chain({ balance: { [lo(LP)]: M(1e6) } })), ['1'], LP))).toMatch(/NotBonded/);
    const leaving = chain({ balance: { [lo(LP)]: M(1e6) }, bonds: { [lo(LP)]: { amount: M(5000), exitAt: 1n } } });
    expect(failing(await planTopUp(ctxOf(leaving), ['1'], LP))).toMatch(/Exiting/);
    expect(failing(await planTopUp(ctxOf(chain({ balance: { [lo(LP)]: M(1e6) }, bonds: { [lo(LP)]: { amount: M(5000) } } })), ['0'], LP))).toMatch(/ZeroAmount/);
  });
});

describe('bond:exit', () => {
  it('requests the exit and says what it does at once and when the bond can leave', async () => {
    const p = await planExit(ctxOf(chain({ bonds: { [lo(LP)]: { amount: M(5000), exposure: 10_000n } } })), [], LP);
    expect(p.refused, failing(p)).toBe(false);
    expect(decode(p).map((x) => x.functionName)).toEqual(['requestExit']);
    const w = p.warnings.join(' ');
    expect(w).toMatch(/credit is 0 from this block/);
    expect(w).toMatch(/ANYONE may close your standing offers/);
    expect(w).toMatch(new RegExp(new Date((NOW + 36 * 86_400) * 1000).toISOString().replace('.000Z', 'Z')));
    expect(w).toMatch(/no cancelling an exit/);
    expect(w).toMatch(/R\$ 100,00 is live now/);
  });

  it('refuses with nothing bonded or when already leaving', async () => {
    expect(failing(await planExit(ctxOf(chain()), [], LP))).toMatch(/NotBonded/);
    expect(failing(await planExit(ctxOf(chain({ bonds: { [lo(LP)]: { amount: M(5000), exitAt: 5n } } })), [], LP))).toMatch(/already leaving/);
  });
});

describe('bond:withdraw', () => {
  const asked = BigInt(NOW) - 10n * DAY;
  const leaving = (b: Bond = {}) => chain({ bonds: { [lo(LP)]: { amount: M(5000), exitAt: asked, ...b } } });

  it('refuses before the unbonding period ends, and says when it does', async () => {
    const p = await planWithdraw(ctxOf(leaving()), [], LP);
    expect(failing(p)).toMatch(/still unbonding until .* \(in 26 days\) \(StillUnbonding\)/);
  });

  it('refuses while anything is live, even after the period', async () => {
    const p = await planWithdraw(ctxOf(leaving({ exposure: 1n }), Number(asked + 36n * DAY)), [], LP);
    expect(failing(p)).toMatch(/still live.*\(ExposureLive\)/);
  });

  it('withdraws once both hold', async () => {
    const p = await planWithdraw(ctxOf(leaving(), Number(asked + 36n * DAY)), [], LP);
    expect(p.refused, failing(p)).toBe(false);
    expect(decode(p).map((x) => x.functionName)).toEqual(['withdraw']);
    expect(p.what).toMatch(/withdraws 5000 MOVVA/);
  });

  it('says a slashed bond withdraws nothing and only ends the exit', async () => {
    const p = await planWithdraw(ctxOf(leaving({ amount: 0n }), Number(asked + 36n * DAY)), [], LP);
    expect(p.refused).toBe(false);
    expect(p.warnings.join(' ')).toMatch(/bond is empty.*join again/);
  });

  it('refuses an LP that is not leaving', async () => {
    expect(failing(await planWithdraw(ctxOf(chain({ bonds: { [lo(LP)]: { amount: M(5000) } } })), [], LP))).toMatch(/NotExiting/);
  });
});

describe('bond:status and the send rules', () => {
  it('reports the trust facts: no admin, the escrows and whether they point back, the window against the unbonding', async () => {
    const s = await bondStatus(ctxOf(chain({ bonds: { [lo(LP)]: { amount: M(5000), settled: 12_345n, settlements: 2 } } })), LP);
    const t = renderBondStatus(s);
    expect(t).toMatch(/no owner, no governor, no pause \(setup CLOSED/);
    expect(t).toMatch(/minimum bond 5000 MOVVA/);
    expect(t).toMatch(/unbonding 36 days/);
    expect(t).toMatch(new RegExp(`on-ramp ${ONRAMP}: names this registry; dispute timeout 30 days; window 35 days < unbonding`));
    expect(t).toMatch(new RegExp(`predecessor ${OLD}`));
    expect(t).toMatch(/slashed and locked for ever 20000 MOVVA/);
    expect(t).toMatch(/credit R\$ 5\.000,00/);
    const open = renderBondStatus(await bondStatus(ctxOf(chain({ bound: false })), undefined));
    expect(open).toMatch(/setup OPEN/);
  });

  it('sends only from the LP\'s own key, with --confirm naming it', async () => {
    const p = await planExit(ctxOf(chain({ bonds: { [lo(LP)]: { amount: M(5000) } } })), [], LP);
    expect(bondSendRefusal(p, {})).toMatch(/LP_KEY is not set/);
    expect(bondSendRefusal(p, { key: '0x1' })).toMatch(/needs --confirm/);
    expect(bondSendRefusal(p, { key: '0x1', confirm: OTHER })).toMatch(/does not name the LP/);
    expect(bondSendRefusal(p, { key: '0x1', confirm: LP, signer: OTHER })).toMatch(/not the LP/);
    expect(bondSendRefusal(p, { key: '0x1', confirm: LP.toLowerCase(), signer: LP })).toBeUndefined();
    const refused = await planExit(ctxOf(chain()), [], LP);
    expect(bondSendRefusal(refused, { key: '0x1', confirm: LP, signer: LP })).toMatch(/refused/);
  });

  it('prints calldata and cast lines in order, and nothing to send for a refused plan', async () => {
    const p = await planJoin(ctxOf(chain({ balance: { [lo(LP)]: M(1e6) } })), ['5000'], LP);
    const text = renderBondPlan(p);
    expect(text.indexOf('approve(address,uint256)')).toBeLessThan(text.indexOf('join(uint256)'));
    expect(text).toMatch(/--private-key \$LP_KEY/);
    const refused = renderBondPlan(await planJoin(ctxOf(chain()), ['5000'], LP));
    expect(refused).toMatch(/REFUSED - nothing printed to send/);
    expect(refused).not.toMatch(/cast send/);
  });

  it('parses MOVVA amounts strictly, and needs an LP', async () => {
    expect(parseMovva('5000')).toBe(M(5000));
    expect(parseMovva('0.000000000000000001')).toBe(1n);
    for (const bad of ['', '-1', '1e3', '5,000', '1.0000000000000000001', undefined]) expect(() => parseMovva(bad as string)).toThrow(BondUsageError);
    await expect(planExit(ctxOf(chain()), [], undefined)).rejects.toThrow(/which LP\?/);
  });

  it('is wired into the lp tool: the commands are known, --from names the LP, and a rail record can name the registry', () => {
    for (const c of BOND_COMMANDS) expect(LP_COMMANDS).not.toContain(c);
    expect(BOND_COMMANDS).toEqual(['bond:join', 'bond:topup', 'bond:exit', 'bond:withdraw', 'bond:status']);
    const a = parseArgs(['bond:join', '5000', '--registry', REG, '--from', LP, '--execute', '--confirm', LP]);
    expect(a).toMatchObject({ name: 'bond:join', positional: ['5000'], flags: { from: LP, execute: true, confirm: LP }, opts: { registry: REG } });
    const rail = parseRail('x.json', JSON.stringify({ chainId: 11155111, contracts: { ramp: { registry: OLD, permissionlessRegistry: REG, movvaOnramp: ONRAMP } } }));
    expect(rail.permissionlessRegistry).toBe(REG);
    expect(rail.registry).toBe(OLD);
    expect(rail.escrows).toEqual([ONRAMP]);
  });
});

