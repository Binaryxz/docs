import { describe, expect, it } from 'vitest';
import type { Hex } from 'viem';
import { runChecks, DEFAULT_THRESHOLDS } from '../src/checks.js';
import {
  CHAINLINK_BRL_USD_MAINNET, DEFAULT_FX_PARITY_THRESHOLDS, PYTH_FX_USD_BRL_ID, fxParityHermes, inCoreSession, judgeFxParity,
  readFxParity, type FxParityReading,
} from '../src/fx-parity.js';

/** Monday 19 October 2026, 17:01:11 UTC: the moment the parity script first ran, inside the core session. */
const NOW = 1_792_429_271;
/** The real feed's round of Sunday 18 October 2026, 19:14:11 UTC: 0.1975293 US$ per real. */
const CL_AT = 1_792_350_851;

function chain(o: { answer?: bigint; at?: number; decimals?: number; fail?: boolean } = {}) {
  return {
    readContract: async (a: { address: string; functionName: string }) => {
      if (o.fail) throw new Error('fetch failed');
      expect(a.address).toBe(CHAINLINK_BRL_USD_MAINNET);
      if (a.functionName === 'latestRoundData') return [1n, o.answer ?? 19_752_930n, 0n, BigInt(o.at ?? CL_AT), 1n];
      if (a.functionName === 'decimals') return o.decimals ?? 8;
      throw new Error(`unexpected ${a.functionName}`);
    },
  } as never;
}

function hermes(o: { price?: bigint; expo?: number; publishTime?: number; open?: boolean; hoursFail?: boolean } = {}) {
  return {
    latest: async (id: Hex) => {
      expect(id).toBe(PYTH_FX_USD_BRL_ID);
      return { id, price: o.price ?? 506_000n, conf: 30n, expo: o.expo ?? -5, publishTime: o.publishTime ?? NOW - 1, data: [] };
    },
    marketHours: async () => {
      if (o.hoursFail) throw new Error('Hermes answered HTTP 503');
      return o.open === undefined ? undefined : { isOpen: o.open };
    },
  };
}

const reading = (over: Partial<FxParityReading> = {}): FxParityReading => ({
  now: NOW,
  chainlink: { feed: CHAINLINK_BRL_USD_MAINNET, answer: 19_752_930n, decimals: 8, updatedAt: CL_AT, ageSeconds: NOW - CL_AT, brlPerUsd: 5.0625 },
  pyth: { price: 506_000n, conf: 30n, expo: -5, publishTime: NOW, ageSeconds: 0, brlPerUsd: 5.06, marketOpen: true },
  divergenceBps: 10,
  coreSession: true,
  marketOpen: true,
  ...over,
});

describe('inCoreSession, as FxMarketHours computes it', () => {
  it('matches the Solidity tests\' dates', () => {
    // contracts/test/PythFxOracle.t.sol, FxMarketHoursTest.
    expect(inCoreSession(1_789_570_800)).toBe(true); // Wednesday 16 September 2026, 15:00 UTC
    expect(inCoreSession(1_789_565_399)).toBe(false); // 13:29:59
    expect(inCoreSession(1_789_565_400)).toBe(true); // 13:30:00
    expect(inCoreSession(1_789_592_399)).toBe(true); // 20:59:59
    expect(inCoreSession(1_789_592_400)).toBe(false); // 21:00:00
    expect(inCoreSession(1_789_830_000)).toBe(false); // Saturday
    expect(inCoreSession(1_789_830_000 + 86_400)).toBe(false); // Sunday
    expect(inCoreSession(1_798_210_800)).toBe(false); // 25 December 2026, a Friday
    expect(inCoreSession(1_798_815_600)).toBe(false); // 1 January 2027, a Friday
    expect(inCoreSession(1_798_124_400)).toBe(true); // 24 December, an ordinary Thursday
    expect(inCoreSession(NOW)).toBe(true);
  });
});

describe('readFxParity', () => {
  it('inverts Chainlink, scales Pyth, and signs the divergence', async () => {
    const r = await readFxParity({ client: chain(), hermes: hermes({ open: true }) }, NOW);
    expect(r.chainlink.brlPerUsd).toBeCloseTo(1e8 / 19_752_930, 9);
    expect(r.chainlink.ageSeconds).toBe(NOW - CL_AT);
    expect(r.pyth.brlPerUsd).toBeCloseTo(5.06, 12);
    // 5.062540 / 5.06 - 1 = +5.02 bps: Chainlink says the dollar buys more reais.
    expect(r.divergenceBps).toBeCloseTo((1e8 / 19_752_930 / 5.06 - 1) * 10_000, 9);
    expect(r.divergenceBps).toBeGreaterThan(5);
    expect(r.marketOpen).toBe(true);
    expect(r.coreSession).toBe(true);
  });

  it('falls back to the core session when Hermes cannot say whether the market is open', async () => {
    const sat = 1_789_830_000;
    const r = await readFxParity({ client: chain({ at: sat - 3600 }), hermes: hermes({ hoursFail: true, publishTime: sat - 2 * 86_400 }) }, sat);
    expect(r.marketOpen).toBe(false);
    expect(r.pyth.marketOpen).toBeUndefined();
  });

  it('refuses a non-positive answer from either side', async () => {
    await expect(readFxParity({ client: chain({ answer: 0n }), hermes: hermes() }, NOW)).rejects.toThrow(/not a price/);
    await expect(readFxParity({ client: chain(), hermes: hermes({ price: -1n }) }, NOW)).rejects.toThrow(/not a price/);
  });
});

describe('judgeFxParity', () => {
  it('is ok inside the deviation threshold, warns past it and fails past the breaker band', () => {
    expect(judgeFxParity(reading({ divergenceBps: 49.9 })).level).toBe('ok');
    const w = judgeFxParity(reading({ divergenceBps: -51 }));
    expect(w.level).toBe('warn');
    expect(w.detail).toContain('-51.00 bps');
    expect(w.detail).toContain('beyond the 50 bps');
    expect(judgeFxParity(reading({ divergenceBps: 301 })).level).toBe('fail');
    expect(judgeFxParity(reading({ divergenceBps: 60 }), { ...DEFAULT_FX_PARITY_THRESHOLDS, fxParityWarnBps: 75 }).level).toBe('ok');
  });

  it('names each source\'s age and the market being closed', () => {
    const c = judgeFxParity(reading({ marketOpen: false, divergenceBps: 20, pyth: { ...reading().pyth, ageSeconds: 2 * 86_400, marketOpen: false } }));
    expect(c.level).toBe('ok');
    expect(c.detail).toContain('the FX market is closed');
    expect(c.detail).toContain('48.0 h old');
    expect(c.detail).toContain('21.8 h old');
    expect(c.value).toBe(20);
  });

  it('warns on a missed Chainlink heartbeat and on a stale Hermes while the market is open', () => {
    const late = judgeFxParity(reading({ chainlink: { ...reading().chainlink, ageSeconds: 26 * 3600 + 1 } }));
    expect(late.level).toBe('warn');
    expect(late.detail).toContain('past its heartbeat');
    const stale = judgeFxParity(reading({ pyth: { ...reading().pyth, ageSeconds: 301, marketOpen: true } }));
    expect(stale.level).toBe('warn');
    expect(stale.detail).toContain('Hermes says the market is open');
  });
});

describe('fx_parity in runChecks', () => {
  it('runs only when configured, and a failed read is unknown, not ok', async () => {
    const off = await runChecks({ client: chain() }, DEFAULT_THRESHOLDS, NOW);
    expect(off.find((r) => r.id === 'fx_parity')).toBeUndefined();
    const [on] = await runChecks({ client: chain(), fxParity: { client: chain(), hermes: hermes({ open: true }) } }, DEFAULT_THRESHOLDS, NOW);
    expect(on.id).toBe('fx_parity');
    expect(on.level).toBe('ok');
    const [down] = await runChecks({ client: chain(), fxParity: { client: chain({ fail: true }), hermes: hermes() } }, DEFAULT_THRESHOLDS, NOW);
    expect(down.level).toBe('unknown');
  });

  it('takes its thresholds from Thresholds when set', async () => {
    const [r] = await runChecks(
      { client: chain(), fxParity: { client: chain(), hermes: hermes({ open: true }) } },
      { ...DEFAULT_THRESHOLDS, fxParityWarnBps: 1 }, NOW,
    );
    expect(r.level).toBe('warn');
  });

  it('never puts the Hermes key into an error', async () => {
    const key = 'k3y-that-must-not-leak';
    let sent: string | undefined;
    const f = (async (_u: string, init: RequestInit) => {
      sent = (init.headers as Record<string, string>).authorization;
      return new Response('unauthorized', { status: 401 });
    }) as unknown as typeof fetch;
    const [r] = await runChecks(
      { client: chain(), fxParity: { client: chain(), hermes: fxParityHermes('https://hermes.example', key, f) } },
      DEFAULT_THRESHOLDS, NOW,
    );
    expect(sent).toBe(`Bearer ${key}`);
    expect(r.level).toBe('unknown');
    expect(r.detail).toContain('HTTP 401');
    expect(r.detail).not.toContain(key);
  });
});
