/* eslint-disable @typescript-eslint/no-explicit-any */
import { afterEach, describe, expect, it } from 'vitest';
import { decodeAbiParameters, encodeAbiParameters, getAddress, type Hex } from 'viem';
import {
  DEFAULT_RISK_LIMITS, HL_PRECOMPILE, SimulatedVenue, collectSnapshot, evaluateSleeve, type SleeveSnapshot,
} from '@mova/yield/src/hedge-risk/index.js';
import {
  HEDGE_RISK_CHECK_ID, HedgeRiskMonitor, hedgeRiskMonitorFrom, hedgeRiskResult, parseHedgeRiskConfig, reserveReader,
  serveHedgeRiskStatus,
} from '../src/hedge-risk.js';

const H = 3_600_000;
const T0 = Date.UTC(2026, 0, 1);
const NOW = T0 + 400 * H;
const ACCOUNT = '0x00000000000000000000000000000000000000aA';
const RESERVE = '0x00000000000000000000000000000000000000Bb';

/** A delta-neutral 2x ETH book on the simulated venue, with 400 h of 10.95% APR funding. */
function sim(o: { price?: number; reachable?: boolean } = {}) {
  const v = new SimulatedVenue({ id: 'hl', now: () => NOW });
  v.listMarket('ETH', {
    markPx: 2000, priceTime: NOW,
    funding: Array.from({ length: 400 }, (_, i) => ({ time: T0 + i * H, hourlyRate: 0.0000125 })),
  });
  v.openAccount('w1', { collateralUsd: 100_000, spot: { ETH: 100 }, perp: { ETH: { qty: -100, entryPx: 2000 } } });
  if (o.price) v.setPrice('ETH', o.price, { time: NOW });
  v.reachable = o.reachable ?? true;
  return () => collectSnapshot([v], [{ id: 'w1', venue: 'hl', account: 'w1', assets: ['ETH'] }], {
    reserve: async () => ({ collateralUsd: 10_000_000, hedgeLimitBps: 800, observedAt: NOW }),
  }, { now: () => NOW }) as Promise<SleeveSnapshot>;
}

describe('the hedge_risk check', () => {
  it('is ok on a healthy book and names the limit closest to its bound', async () => {
    const r = hedgeRiskResult(evaluateSleeve(await sim()(), DEFAULT_RISK_LIMITS));
    expect(r.id).toBe(HEDGE_RISK_CHECK_ID);
    expect(r.level).toBe('ok');
    expect(r.detail).toMatch(/all limits inside their bounds; closest: /);
    expect(r.detail).toMatch(/no action planned; sleeve \$300,000 \(cap \$800,000\) in 1 sub-wallet/);
  });

  it('fails on a rally toward liquidation, with the worst limit, its numbers and the plan', async () => {
    const r = hedgeRiskResult(evaluateSleeve(await sim({ price: 2500 })(), DEFAULT_RISK_LIMITS));
    expect(r.level).toBe('fail');
    expect(r.detail).toMatch(/^worst limit (margin\.leverage|margin\.ratio|liquidation\.distance) \[fail\]/);
    expect(r.detail).toMatch(/plan: 1 reduce/);
    expect(r.value).toBeDefined();
    expect(r.threshold).toBeDefined();
  });

  it('fails closed on an unreachable venue: fail, not unknown', async () => {
    const r = hedgeRiskResult(evaluateSleeve(await sim({ reachable: false })(), DEFAULT_RISK_LIMITS));
    expect(r.level).toBe('fail');
    expect(r.detail).toMatch(/worst limit health\.reachable/);
  });

  it('is unknown when the snapshot cannot be assembled at all, with secrets redacted', async () => {
    const secret = 'https://rpc.example/KEY123';
    const m = new HedgeRiskMonitor({
      limits: DEFAULT_RISK_LIMITS, redactValues: [secret],
      snapshot: async () => { throw new Error(`fetch ${secret} failed`); },
    });
    const r = await m.check();
    expect(r.level).toBe('unknown');
    expect(r.detail).not.toContain('KEY123');
    expect(m.status()).toMatchObject({ ready: false });
  });

  it('keeps the funding regime across sweeps', async () => {
    const m = new HedgeRiskMonitor({ limits: DEFAULT_RISK_LIMITS, snapshot: sim() });
    await m.check();
    expect(m.last?.memory.funding['hl:ETH'].regime).toBe('on');
    await m.check();
    expect(m.last?.funding['hl:ETH'].changed).toBe(false);
  });
});

describe('the status endpoint', () => {
  let close: (() => Promise<void>) | undefined;
  afterEach(async () => { await close?.(); close = undefined; });

  it('serves 503 before the first sweep, then the JSON summary', async () => {
    const m = new HedgeRiskMonitor({ limits: DEFAULT_RISK_LIMITS, snapshot: sim({ price: 2500 }) });
    const s = serveHedgeRiskStatus(m);
    close = s.close;
    const base = `http://127.0.0.1:${await s.listen(0, '127.0.0.1')}`;
    expect((await fetch(`${base}/healthz`)).status).toBe(200);
    expect((await fetch(`${base}/status`)).status).toBe(503);
    await m.check();
    const res = await fetch(`${base}/status`);
    expect(res.status).toBe(200);
    const body = await res.json() as any;
    expect(body.level).toBe('fail');
    expect(body.actions.map((a: any) => a.kind)).toEqual(['reduce']);
    expect(body.wallets[0]).toMatchObject({ id: 'w1', venue: 'hl', reachable: true });
    expect(body.permissions[0]).toMatchObject({ mayAdd: false });
    expect(body.breaches.length).toBeGreaterThan(0);
  });
});

const CONFIG = {
  limits: { margin: { maxLeverage: 2.8, warnLeverage: 2.4 } },
  venues: [{ id: 'hyperliquid', kind: 'hyperliquid', markets: [{ asset: 'ETH', perp: 1, spotMarket: 151, spotToken: 221, perpSzDecimals: 4, spotSzDecimals: 4, spotWeiDecimals: 9, maxLeverage: 25 }] }],
  wallets: [{ id: 'hl-eth-1', venue: 'hyperliquid', account: ACCOUNT, assets: ['ETH'] }],
};

describe('HEDGE_RISK_CONFIG', () => {
  it('parses limits over the defaults, venues and sub-wallets', () => {
    const c = parseHedgeRiskConfig(JSON.stringify(CONFIG));
    expect(c.limits.margin.maxLeverage).toBe(2.8);
    expect(c.limits.margin.targetLeverage).toBe(2);
    expect(c.wallets[0].account).toBe(getAddress(ACCOUNT));
  });

  it('refuses what it cannot watch rather than skipping it', () => {
    const bad = (patch: object) => () => parseHedgeRiskConfig(JSON.stringify({ ...CONFIG, ...patch }));
    expect(bad({ venues: [{ ...CONFIG.venues[0], kind: 'cex' }] })).toThrow(/no reader yet/);
    expect(bad({ wallets: [{ ...CONFIG.wallets[0], venue: 'other' }] })).toThrow(/not configured/);
    expect(bad({ wallets: [{ ...CONFIG.wallets[0], assets: ['BTC'] }] })).toThrow(/no market for/);
    expect(bad({ wallets: [CONFIG.wallets[0], CONFIG.wallets[0]] })).toThrow(/listed twice/);
    expect(bad({ limits: { margin: { maxLeverage: 0.5 } } })).toThrow(/invalid hedge risk limits/);
    expect(bad({ extra: 1 })).toThrow(/unknown key/);
  });
});

describe('wired end to end over the Hyperliquid read path', () => {
  const u64 = (x: bigint) => encodeAbiParameters([{ type: 'uint64' }], [x]);
  const hyperEvmClient = {
    getBlock: async () => ({ timestamp: BigInt(Math.floor(Date.now() / 1000)) }),
    call: async ({ to, data }: { to: string; data: Hex }) => {
      const t = to.toLowerCase();
      if (t === HL_PRECOMPILE.position.toLowerCase()) {
        return { data: encodeAbiParameters([{ type: 'int64' }, { type: 'uint64' }, { type: 'int64' }, { type: 'uint32' }, { type: 'bool' }], [-1_000_000n, 200_000_000_000n, 0n, 2, false]) };
      }
      if (t === HL_PRECOMPILE.spotBalance.toLowerCase()) {
        // 100 UETH (9 decimals); no USDC.
        const [, token] = decodeAbiParameters([{ type: 'address' }, { type: 'uint64' }], data);
        return { data: encodeAbiParameters([{ type: 'uint64' }, { type: 'uint64' }, { type: 'uint64' }], [token === 0n ? 0n : 100_000_000_000n, 0n, 0n]) };
      }
      if (t === HL_PRECOMPILE.markPx.toLowerCase() || t === HL_PRECOMPILE.oraclePx.toLowerCase()) return { data: u64(200_000n) };
      if (t === HL_PRECOMPILE.spotPx.toLowerCase()) return { data: u64(20_000_000n) };
      if (t === HL_PRECOMPILE.accountMarginSummary.toLowerCase()) {
        return { data: encodeAbiParameters([{ type: 'int64' }, { type: 'uint64' }, { type: 'uint64' }, { type: 'int64' }], [100_000_000_000n, 0n, 200_000_000_000n, 0n]) };
      }
      throw new Error('unexpected');
    },
  };
  const fetchImpl = (async (_u: string, init?: { body?: string }) => {
    const body = JSON.parse(String(init?.body));
    const now = Date.now();
    const json = body.type === 'fundingHistory'
      ? Array.from({ length: 360 }, (_, i) => ({ time: now - (360 - i) * H, fundingRate: '0.0000125' })).filter((r) => r.time >= body.startTime)
      : [['ETH', [['HlPerp', { fundingRate: '0.0000125', nextFundingTime: now + H, fundingIntervalHours: 1 }]]]];
    return { ok: true, status: 200, json: async () => json };
  }) as unknown as typeof fetch;
  const ethClient = {
    readContract: async ({ functionName }: { functionName: string }) => (functionName === 'totalUsdt' ? 10_000_000_000_000n : 800),
  } as any;

  it('reads the reserve hedge limit and the sub-wallet, and judges a 2x book ok', async () => {
    const m = hedgeRiskMonitorFrom(parseHedgeRiskConfig(JSON.stringify({ ...CONFIG, reserve: RESERVE })), {
      ethClient, hyperEvmRpc: 'https://hyperevm.example/SECRET', hyperEvmClient: hyperEvmClient as any, fetchImpl,
    });
    const r = await m.check();
    expect(r.level).toBe('ok');
    expect(m.last?.wallets[0]).toMatchObject({ id: 'hl-eth-1', capitalUsd: 300_000, leverage: 2 });
    expect(m.last?.sleeve.reserveCapUsd).toBeCloseTo(800_000, 6);
    expect(JSON.stringify(m.status())).not.toContain('SECRET');
  });

  it('reads MovvaReserve in its own units', async () => {
    expect(await reserveReader(ethClient, RESERVE, () => 5)()).toEqual({ collateralUsd: 10_000_000, hedgeLimitBps: 800, observedAt: 5 });
  });
});

const VENUE_ADDR = '0x00000000000000000000000000000000000000C1';
const STABLE_ADDR = '0x00000000000000000000000000000000000000C2';
const ONCHAIN = {
  limits: { health: { maxPriceAgeSeconds: 7_200 }, funding: { minHistoryHours: 1 } },
  venues: [{ id: 'sim-sepolia', kind: 'onchain-perps', venue: VENUE_ADDR, stable: STABLE_ADDR, markets: [{ asset: 'ETH' }] }],
  wallets: [{ id: 'eth-1', venue: 'sim-sepolia', account: ACCOUNT, assets: ['ETH'] }],
};

describe('an onchain-perps venue (IHedgeVenue + HedgeSubWallet)', () => {
  it('parses, and refuses a venue or stablecoin that is not an address, or an over-long market id', () => {
    const c = parseHedgeRiskConfig(JSON.stringify(ONCHAIN));
    expect(c.venues[0]).toEqual({ id: 'sim-sepolia', kind: 'onchain-perps', venue: getAddress(VENUE_ADDR), stable: getAddress(STABLE_ADDR), markets: [{ asset: 'ETH' }] });
    const bad = (v: object) => () => parseHedgeRiskConfig(JSON.stringify({ ...ONCHAIN, venues: [{ ...ONCHAIN.venues[0], ...v }] }));
    expect(bad({ venue: 'nope' })).toThrow(/venue must be an address/);
    expect(bad({ stable: undefined })).toThrow(/stable must be an address/);
    expect(bad({ markets: [{ asset: 'ETH', id: 'x'.repeat(33) }] })).toThrow(/at most 32 bytes/);
  });

  it('reads the sub-wallet on the monitor\'s own Ethereum client and judges a 2x book ok', async () => {
    const now = BigInt(Math.floor(Date.now() / 1000));
    const E18 = 10n ** 18n;
    const ethClient = {
      getBlock: async () => ({ number: 10n, timestamp: now }),
      readContract: async ({ functionName }: { functionName: string }) => {
        switch (functionName) {
          case 'totalUsdt': return 10_000_000_000_000n;
          case 'hedgeLimitBps': return 800;
          case 'decimals': return 6;
          case 'balanceOf': return 2_000_000_000n;
          case 'cash': return 0n;
          case 'marginAccount': return { equity: 100_000_000_000n, maintenance: 10_000_000_000n, initial: 20_000_000_000n, withdrawable: 0n };
          case 'prices': return { mark: 2_000n * E18, index: 2_000n * E18, spot: 2_000n * E18, updatedAt: now - 600n };
          case 'perpPosition': return { size: -100n * E18, entryPx: 2_000n * E18 };
          case 'spotBalance': return 100n * E18;
          case 'maxLeverageBps': return 100_000n;
          case 'fundingRate': return 12_500_000_000_000n;
          case 'fundingHistory': return [[now - 48n * 3600n], [12_500_000_000_000n]];
          default: throw new Error(`unexpected ${functionName}`);
        }
      },
    } as any;
    const m = hedgeRiskMonitorFrom(parseHedgeRiskConfig(JSON.stringify({ ...ONCHAIN, reserve: RESERVE })), { ethClient, hyperEvmRpc: 'unused' });
    const r = await m.check();
    expect(r.level, r.detail).toBe('ok');
    expect(m.last?.wallets[0]).toMatchObject({ id: 'eth-1', venue: 'sim-sepolia', leverage: 2 });
    expect(m.last?.wallets[0].capitalUsd).toBeCloseTo(302_000, 6);
  });

  it('fails closed when the venue cannot be read', async () => {
    const ethClient = { getBlock: async () => ({ number: 1n, timestamp: 1n }), readContract: async () => { throw new Error('execution reverted'); } } as any;
    const m = hedgeRiskMonitorFrom(parseHedgeRiskConfig(JSON.stringify(ONCHAIN)), { ethClient, hyperEvmRpc: 'unused' });
    const r = await m.check();
    expect(r.level).toBe('fail');
    expect(r.detail).toMatch(/health\.reachable/);
  });
});
