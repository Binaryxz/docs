/* eslint-disable @typescript-eslint/no-explicit-any */
import { describe, expect, it } from 'vitest';
import {
  ContractFunctionExecutionError, ContractFunctionRevertedError, ContractFunctionZeroDataError, encodeErrorResult, hashTypedData, parseAbi,
} from 'viem';
import { privateKeyToAccount } from 'viem/accounts';
import {
  runChecks, worst, movvaStatementLoader, lpNodeCapsLoader, DEFAULT_THRESHOLDS, MOVVA_STATEMENT_TYPES,
  type LpNodeCapsReading, type MonitorTargets,
} from '../src/checks.js';

const A = (n: number) => `0x${n.toString(16).padStart(40, '0')}` as const;
const ORACLE = A(1), ENTRYPOINT = A(2), POOL = A(3), VAULT = A(4), RELAYER = A(5),
  PAYMASTER = A(6), AA = A(7), ESCROW = A(8), OFFRAMP = A(9), USDT = A(10), USDT_ORACLE = A(11),
  ETH_ORACLE = A(12), USDT_POOL = A(13), FEED = A(14);
const ZERO = A(0);

const NOW = 1_800_000_000;

/**
 * Views a monitor asks only to learn what kind of contract it reads: market hours, a band reading, a
 * reserve's FX leg. Unconfigured, they answer as the chain does for a contract without them - no data -
 * so every other test reads a SignedPriceOracle-like source, as before.
 */
const PROBES = new Set(['inCoreSession', 'brlCentsPerUnitForBand', 'fxOracle', 'bandBrlPerUsdtE18', 'MAX_COST_GLOBAL']);

/**
 * A chain that answers whatever the test says, including by throwing. Real RPC behaviour is
 * covered by the fork tests; what matters here is the decision each reading produces.
 */
function chain(answers: Record<string, unknown>, balances: Record<string, bigint> = {}) {
  return {
    readContract: async ({ address, functionName, args }: any) => {
      const key = `${String(address).toLowerCase()}:${functionName}`;
      // A read with arguments may be answered per argument: `0xescrow:assets:0xtoken`.
      const withArgs = args?.length ? `${key}:${args.map((x: unknown) => String(x).toLowerCase()).join(',')}` : key;
      const v = withArgs in answers ? answers[withArgs] : answers[key];
      if (v instanceof Error) throw v;
      if (v === undefined && PROBES.has(functionName)) throw new ContractFunctionZeroDataError({ functionName });
      if (v === undefined) throw new Error(`no answer configured for ${key}`);
      return v;
    },
    getBalance: async ({ address }: any) => {
      const v = balances[String(address).toLowerCase()];
      if (v === undefined) throw new Error(`no balance for ${address}`);
      return v;
    },
  } as unknown as MonitorTargets['client'];
}

const by = (rs: Awaited<ReturnType<typeof runChecks>>, id: string) => {
  const r = rs.find((x) => x.id === id);
  if (!r) throw new Error(`no check ${id}; got ${rs.map((x) => x.id).join(', ')}`);
  return r;
};

describe('oracle freshness', () => {
  const at = (updatedAt: number) => chain({
    [`${ORACLE.toLowerCase()}:brlCentsPerUnit`]: [1_500_000n, BigInt(updatedAt)],
  });

  it('passes on a fresh price', async () => {
    const rs = await runChecks({ client: at(NOW - 60), oracle: ORACLE }, DEFAULT_THRESHOLDS, NOW);
    expect(by(rs, 'oracle_freshness').level).toBe('ok');
    expect(by(rs, 'oracle_freshness').value).toBe(60);
  });

  it('warns before the escrow would reject the price, not after', async () => {
    const rs = await runChecks({ client: at(NOW - 3600), oracle: ORACLE }, DEFAULT_THRESHOLDS, NOW);
    expect(by(rs, 'oracle_freshness').level).toBe('warn');
  });

  it('fails once the price is hours old', async () => {
    const rs = await runChecks({ client: at(NOW - 10 * 3600), oracle: ORACLE }, DEFAULT_THRESHOLDS, NOW);
    expect(by(rs, 'oracle_freshness').level).toBe('fail');
  });
});

/**
 * The distinction the whole design rests on: a check that could not run has NOT passed.
 * A monitor reporting green because its RPC threw is the failure mode this exists to avoid.
 */
describe('a read that throws', () => {
  it('reports unknown rather than ok', async () => {
    const rs = await runChecks({
      client: chain({ [`${ORACLE.toLowerCase()}:brlCentsPerUnit`]: new Error('RPC 503') }),
      oracle: ORACLE,
    }, DEFAULT_THRESHOLDS, NOW);
    expect(by(rs, 'oracle_freshness').level).toBe('unknown');
    expect(by(rs, 'oracle_freshness').detail).toContain('RPC 503');
  });

  it('does not stop the other checks in the sweep', async () => {
    const rs = await runChecks({
      client: chain(
        { [`${ORACLE.toLowerCase()}:brlCentsPerUnit`]: new Error('down') },
        { [RELAYER.toLowerCase()]: 10n ** 18n },
      ),
      oracle: ORACLE, relayer: RELAYER,
    }, DEFAULT_THRESHOLDS, NOW);
    expect(by(rs, 'oracle_freshness').level).toBe('unknown');
    expect(by(rs, 'relayer_gas').level).toBe('ok');
  });
});

describe('ASP root', () => {
  it('fails outright when no root was ever posted', async () => {
    const rs = await runChecks({
      client: chain({ [`${ENTRYPOINT.toLowerCase()}:latestRoot`]: 0n }),
      entrypoint: ENTRYPOINT,
    }, DEFAULT_THRESHOLDS, NOW);
    expect(by(rs, 'asp_root_age').level).toBe('fail');
    expect(by(rs, 'asp_root_age').detail).toContain('private withdrawal');
  });

  it('warns when the postman has gone quiet, if the age is tracked', async () => {
    const rs = await runChecks({
      client: chain({ [`${ENTRYPOINT.toLowerCase()}:latestRoot`]: 123n }),
      entrypoint: ENTRYPOINT,
      lastRootPostedAt: () => NOW - 8 * 3600,
    }, DEFAULT_THRESHOLDS, NOW);
    expect(by(rs, 'asp_root_age').level).toBe('warn');
  });

  it('does not invent an age when nothing tracks it', async () => {
    const rs = await runChecks({
      client: chain({ [`${ENTRYPOINT.toLowerCase()}:latestRoot`]: 123n }),
      entrypoint: ENTRYPOINT,
    }, DEFAULT_THRESHOLDS, NOW);
    const r = by(rs, 'asp_root_age');
    expect(r.level).toBe('ok');
    expect(r.value).toBeUndefined();
  });
});

describe('gas floors', () => {
  it('warns below the floor and fails well below it', async () => {
    const warn = await runChecks({
      client: chain({}, { [RELAYER.toLowerCase()]: 15_000_000_000_000_000n }),
      relayer: RELAYER,
    }, DEFAULT_THRESHOLDS, NOW);
    expect(by(warn, 'relayer_gas').level).toBe('warn');

    const fail = await runChecks({
      client: chain({}, { [RELAYER.toLowerCase()]: 1_000_000_000_000_000n }),
      relayer: RELAYER,
    }, DEFAULT_THRESHOLDS, NOW);
    expect(by(fail, 'relayer_gas').level).toBe('fail');
  });

  it('reads the paymaster deposit from the ERC-4337 EntryPoint, not its address balance', async () => {
    const rs = await runChecks({
      client: chain({ [`${AA.toLowerCase()}:balanceOf`]: 10n ** 18n }),
      paymaster: PAYMASTER, aaEntrypoint: AA,
    }, DEFAULT_THRESHOLDS, NOW);
    expect(by(rs, 'paymaster_deposit').level).toBe('ok');
  });

  it('alerts while an OwnerlessPaymaster\'s deposit does not cover 3 x MAX_COST_GLOBAL, and fails under one (SRM1-16)', async () => {
    const cap = 2n * 10n ** 17n; // Sepolia's MAX_COST_GLOBAL, 0.2 ETH
    const withDeposit = (deposit: bigint, th = DEFAULT_THRESHOLDS) => runChecks({
      client: chain({ [`${AA.toLowerCase()}:balanceOf`]: deposit, [`${PAYMASTER.toLowerCase()}:MAX_COST_GLOBAL`]: cap }),
      paymaster: PAYMASTER, aaEntrypoint: AA,
    }, th, NOW).then((rs) => by(rs, 'paymaster_global_cap'));

    // Sepolia's paymaster on 18 October 2026: 0.0895 ETH, under one window's cap.
    const sepolia = await withDeposit(89_484_605_742_290_609n);
    expect(sepolia.level).toBe('fail');
    expect(sepolia.threshold).toBe(0.6);
    expect(sepolia.detail).toMatch(/under 3 x MAX_COST_GLOBAL \(0\.6000 ETH\).*Top up 510515394257709391 wei.*EntryPoint\.depositTo/);
    // The 0.1 ETH it was deployed with: also under the cap.
    expect((await withDeposit(10n ** 17n)).level).toBe('fail');
    expect((await withDeposit(cap)).level).toBe('warn');
    expect((await withDeposit(3n * cap - 1n)).level).toBe('warn');
    expect((await withDeposit(3n * cap)).level).toBe('ok');
    expect((await withDeposit(3n * cap, { ...DEFAULT_THRESHOLDS, paymasterGlobalCapWindows: 5 })).level).toBe('warn');
  });

  it('has no global cap to cover on a paymaster without MAX_COST_GLOBAL, and is unknown when the read fails', async () => {
    const sponsor = await runChecks({
      client: chain({ [`${AA.toLowerCase()}:balanceOf`]: 10n ** 18n }), paymaster: PAYMASTER, aaEntrypoint: AA,
    }, DEFAULT_THRESHOLDS, NOW);
    expect(by(sponsor, 'paymaster_global_cap')).toMatchObject({ level: 'ok', detail: expect.stringMatching(/not an OwnerlessPaymaster/) });
    const broken = await runChecks({
      client: chain({ [`${AA.toLowerCase()}:balanceOf`]: 10n ** 18n, [`${PAYMASTER.toLowerCase()}:MAX_COST_GLOBAL`]: new Error('connection refused') }),
      paymaster: PAYMASTER, aaEntrypoint: AA,
    }, DEFAULT_THRESHOLDS, NOW);
    expect(by(broken, 'paymaster_global_cap').level).toBe('unknown');
  });

  it('fails the paymaster stake while it is missing, unlocked, under the floor or on a short delay', async () => {
    const withStake = (info: Record<string, unknown>, th = DEFAULT_THRESHOLDS) => runChecks({
      client: chain({
        [`${AA.toLowerCase()}:balanceOf`]: 10n ** 18n,
        [`${AA.toLowerCase()}:getDepositInfo`]: { deposit: 10n ** 18n, staked: true, stake: 10n ** 18n, unstakeDelaySec: 86_400, withdrawTime: 0, ...info },
      }),
      paymaster: PAYMASTER, aaEntrypoint: AA,
    }, th, NOW).then((rs) => by(rs, 'paymaster_stake'));

    expect((await withStake({})).level).toBe('ok');
    const unstaked = await withStake({ staked: false, stake: 0n, unstakeDelaySec: 0 });
    expect(unstaked.level).toBe('fail');
    expect(unstaked.detail).toMatch(/is not staked.*ERC-7562/);
    // unlockStake: the EntryPoint stops counting the stake at once, long before it can be withdrawn.
    const unlocked = await withStake({ staked: false, withdrawTime: NOW + 86_400 });
    expect(unlocked.level).toBe('fail');
    expect(unlocked.detail).toMatch(/unlocked/);
    // Sepolia's paymaster today: 0.02 ETH, which a bundler with a 1 ETH floor counts as no stake.
    const small = await withStake({ stake: 2n * 10n ** 16n });
    expect(small.level).toBe('fail');
    expect(small.detail).toMatch(/0\.0200 ETH is under 1\.0000 ETH/);
    expect((await withStake({ unstakeDelaySec: 3_600 })).detail).toMatch(/unstake delay 3600 s is under 86400 s/);
    // The floor follows the bundlers in use.
    expect((await withStake({ stake: 2n * 10n ** 16n }, { ...DEFAULT_THRESHOLDS, paymasterMinStakeWei: 10n ** 16n })).level).toBe('ok');
  });
});

describe('vault', () => {
  const vault = (price: bigint, high: bigint, paused = false, total = 100n, liquid = 100n) => chain({
    [`${VAULT.toLowerCase()}:assetsPerShare`]: price,
    [`${VAULT.toLowerCase()}:highWaterAssetsPerShare`]: high,
    [`${VAULT.toLowerCase()}:depositsPaused`]: paused,
    [`${VAULT.toLowerCase()}:totalAssets`]: total,
    [`${VAULT.toLowerCase()}:liquidAssets`]: liquid,
  });

  it('is quiet while the share price is at its high-water mark', async () => {
    const rs = await runChecks({ client: vault(1_000_000n, 1_000_000n), vault: VAULT }, DEFAULT_THRESHOLDS, NOW);
    expect(by(rs, 'vault_drawdown').level).toBe('ok');
  });

  it('warns on a drawdown before the breaker trips', async () => {
    const rs = await runChecks({ client: vault(960_000n, 1_000_000n), vault: VAULT }, DEFAULT_THRESHOLDS, NOW);
    const r = by(rs, 'vault_drawdown');
    expect(r.level).toBe('warn');
    expect(r.value).toBe(400);
  });

  /** A tripped breaker is not a warning: deposits have already stopped. */
  it('fails when the breaker has already paused deposits', async () => {
    const rs = await runChecks({ client: vault(900_000n, 1_000_000n, true), vault: VAULT }, DEFAULT_THRESHOLDS, NOW);
    const r = by(rs, 'vault_drawdown');
    expect(r.level).toBe('fail');
    expect(r.detail).toContain('PAUSED');
  });

  it('warns when little of the vault can be withdrawn right now', async () => {
    const rs = await runChecks({ client: vault(1n, 1n, false, 1000n, 50n), vault: VAULT }, DEFAULT_THRESHOLDS, NOW);
    expect(by(rs, 'vault_liquidity').level).toBe('warn');
    expect(by(rs, 'vault_liquidity').value).toBe(5);
  });
});

/** How viem surfaces a contract's own revert from `readContract`: an execution error wrapping it. */
function reverted(signature: string, args: readonly unknown[]) {
  const abi = parseAbi([signature]);
  const data = encodeErrorResult({ abi, errorName: (abi[0] as { name: string }).name, args } as never);
  return new ContractFunctionExecutionError(
    new ContractFunctionRevertedError({ abi, data, functionName: 'brlCentsPerUnit' }),
    { abi, functionName: 'brlCentsPerUnit', contractAddress: USDT_ORACLE },
  );
}

describe('each listed asset\'s oracle', () => {
  const k = (addr: string, fn: string, arg?: string) => `${addr.toLowerCase()}:${fn}${arg ? `:${arg.toLowerCase()}` : ''}`;
  const listing = (usdtOracle: string = USDT_ORACLE, offrampUsdtOracle: string = usdtOracle) => ({
    [k(ESCROW, 'assets', ZERO)]: [ETH_ORACLE, 18, true],
    [k(OFFRAMP, 'assets', ZERO)]: [ETH_ORACLE, 18, true],
    [k(ESCROW, 'assets', USDT)]: [usdtOracle, 6, true],
    [k(OFFRAMP, 'assets', USDT)]: [offrampUsdtOracle, 6, true],
    [k(ETH_ORACLE, 'brlCentsPerUnit')]: [1_341_189n, BigInt(NOW - 120)],
  });
  const targets = (client: MonitorTargets['client']): MonitorTargets => ({
    client, escrow: ESCROW, offrampEscrow: OFFRAMP, assets: [ZERO, USDT],
  });

  /** The oracle checked is the one the escrow will call, read from the escrow, per asset. */
  it('checks every asset through the oracle each escrow has configured', async () => {
    const rs = await runChecks(targets(chain({
      ...listing(), [k(USDT_ORACLE, 'brlCentsPerUnit')]: [540n, BigInt(NOW - 60)],
    })), DEFAULT_THRESHOLDS, NOW);
    const usdt = by(rs, `asset_oracle:${USDT.toLowerCase()}`);
    expect(usdt.level).toBe('ok');
    expect(usdt.value).toBe(60);
    expect(by(rs, `asset_oracle:${ZERO}`).detail).toBe('ETH price is 120s old');
  });

  /**
   * An oracle that REVERTS is not an unreadable check: the escrows make the same call before
   * every offer, so trading in that asset has stopped. It fails, and names the refusal.
   */
  it('fails, naming the stale leg, when an asset\'s oracle refuses to price', async () => {
    const rs = await runChecks(targets(chain({
      ...listing(),
      [k(USDT_ORACLE, 'brlCentsPerUnit')]: reverted('error StaleLeg(address leg, uint256 updatedAt)', [FEED, 1_789_328_171n]),
    })), DEFAULT_THRESHOLDS, NOW);
    const r = by(rs, `asset_oracle:${USDT.toLowerCase()}`);
    expect(r.level).toBe('fail');
    expect(r.detail).toContain('StaleLeg');
    expect(r.detail.toLowerCase()).toContain(FEED);
    expect(r.detail.match(/refuses to price/g), 'one oracle, reported once').toHaveLength(1);
    expect(by(rs, `asset_oracle:${ZERO}`).level, 'the other asset is unaffected').toBe('ok');
  });

  it('still reports a failed read as unknown, not fail', async () => {
    const rs = await runChecks(targets(chain({
      ...listing(), [k(USDT_ORACLE, 'brlCentsPerUnit')]: new Error('RPC 503'),
    })), DEFAULT_THRESHOLDS, NOW);
    expect(by(rs, `asset_oracle:${USDT.toLowerCase()}`).level).toBe('unknown');
  });

  /** SR2-25: at `assetCap` an escrow refuses new USDT, which LPs see as an outage. Tokens only. */
  it('warns as an escrow nears its cap for a token and fails at it', async () => {
    const caps = (onHeld: bigint, offHeld: bigint, offCap = 1_000_000_000n) => ({
      ...listing(), [k(USDT_ORACLE, 'brlCentsPerUnit')]: [540n, BigInt(NOW - 60)],
      [k(ESCROW, 'assetCap', USDT)]: 1_000_000_000n, [k(OFFRAMP, 'assetCap', USDT)]: offCap,
      [k(USDT, 'balanceOf', ESCROW)]: onHeld, [k(USDT, 'balanceOf', OFFRAMP)]: offHeld,
    });
    const id = `asset_cap:${USDT.toLowerCase()}`;
    const ok = await runChecks(targets(chain(caps(500_000_000n, 0n))), DEFAULT_THRESHOLDS, NOW);
    expect(by(ok, id)).toMatchObject({ level: 'ok', value: 50 });
    expect(ok.some((r) => r.id === `asset_cap:${ZERO}`), 'no cap check for ETH').toBe(false);

    const near = by(await runChecks(targets(chain(caps(850_000_000n, 0n))), DEFAULT_THRESHOLDS, NOW), id);
    expect(near.level).toBe('warn');
    expect(near.detail).toContain('85% of its cap');

    const full = by(await runChecks(targets(chain(caps(0n, 1_000_000_000n))), DEFAULT_THRESHOLDS, NOW), id);
    expect(full.level).toBe('fail');
    expect(full.detail).toContain(`escrow ${OFFRAMP} is AT its cap`);

    const uncapped = by(await runChecks(targets(chain(caps(900_000_000n, 5n, 0n))), DEFAULT_THRESHOLDS, NOW), id);
    expect(uncapped.level).toBe('warn');
    expect(uncapped.detail).toContain(`escrow ${OFFRAMP} has no cap`);
  });

  it('warns on a signed rate going stale, before the escrows refuse it', async () => {
    const rs = await runChecks(targets(chain({
      ...listing(), [k(USDT_ORACLE, 'brlCentsPerUnit')]: [540n, BigInt(NOW - 45 * 60)],
    })), DEFAULT_THRESHOLDS, NOW);
    expect(by(rs, `asset_oracle:${USDT.toLowerCase()}`).level).toBe('warn');
  });

  it('warns when a monitored asset is not listed on one of the escrows', async () => {
    const rs = await runChecks(targets(chain({
      ...listing(USDT_ORACLE, ZERO), [k(USDT_ORACLE, 'brlCentsPerUnit')]: [540n, BigInt(NOW - 60)],
    })), DEFAULT_THRESHOLDS, NOW);
    const r = by(rs, `asset_oracle:${USDT.toLowerCase()}`);
    expect(r.level).toBe('warn');
    expect(r.detail).toContain(`not listed on escrow ${OFFRAMP}`);
  });

  it('warns when the two escrows band an asset with different oracles', async () => {
    const other = A(99);
    const rs = await runChecks(targets(chain({
      ...listing(USDT_ORACLE, other),
      [k(USDT_ORACLE, 'brlCentsPerUnit')]: [540n, BigInt(NOW - 60)],
      [k(other, 'brlCentsPerUnit')]: [541n, BigInt(NOW - 60)],
    })), DEFAULT_THRESHOLDS, NOW);
    const r = by(rs, `asset_oracle:${USDT.toLowerCase()}`);
    expect(r.level).toBe('warn');
    expect(r.detail).toContain('different oracles');
  });

  /** The single-oracle check classifies a revert the same way. */
  it('fails the plain oracle check on a revert too', async () => {
    const rs = await runChecks({
      client: chain({ [k(ORACLE, 'brlCentsPerUnit')]: reverted('error NoPriceYet()', []) }), oracle: ORACLE,
    }, DEFAULT_THRESHOLDS, NOW);
    expect(by(rs, 'oracle_freshness').level).toBe('fail');
    expect(by(rs, 'oracle_freshness').detail).toContain('NoPriceYet');
  });

  it('is skipped without an escrow to read the listing from', async () => {
    const rs = await runChecks({ client: chain({}), assets: [USDT] }, DEFAULT_THRESHOLDS, NOW);
    expect(rs).toEqual([]);
  });
});

/**
 * PythFxOracle's rate is FX.USD/BRL, closed every weekday night and weekend: old, then refused, by design,
 * while its band reading serves the last close. Judged by the core session, never paged on every night.
 */
describe('an oracle with FX market hours (PythFxOracle)', () => {
  const k = (fn: string) => `${ORACLE.toLowerCase()}:${fn}`;
  const staleRate = (t: number) => reverted('error StaleRate(uint256 publishTime)', [BigInt(t)]);
  const freshness = (answers: Record<string, unknown>) =>
    runChecks({ client: chain(answers), oracle: ORACLE }, DEFAULT_THRESHOLDS, NOW).then((rs) => by(rs, 'oracle_freshness'));

  it('is ok while the market is closed and the band trades on the last close, and says so', async () => {
    const r = await freshness({ [k('brlCentsPerUnit')]: staleRate(NOW - 5 * 3600), [k('inCoreSession')]: false, [k('brlCentsPerUnitForBand')]: [5_401_200n, BigInt(NOW)] });
    expect(r.level).toBe('ok');
    expect(r.detail).toMatch(/the FX market is closed - its rate is refused \(StaleRate\(1799982000\)\), and the bands trade on the last close until the reopening/);
    // Old but not yet refused after the close: the same, with the age.
    const old = await freshness({
      [k('brlCentsPerUnit')]: [5_401_200n, BigInt(NOW - 45 * 60)], [k('inCoreSession')]: false, [k('brlCentsPerUnitForBand')]: [5_401_200n, BigInt(NOW - 45 * 60)],
    });
    expect(old).toMatchObject({ level: 'ok', value: 45 * 60 });
  });

  it('alerts inside the core session, naming the Pyth keeper: fail on a refusal, warn on an old rate', async () => {
    const r = await freshness({ [k('brlCentsPerUnit')]: staleRate(NOW - 5 * 3600), [k('inCoreSession')]: true });
    expect(r.level).toBe('fail');
    expect(r.detail).toMatch(/inside the FX market's core session: the Pyth keeper is down or behind/);
    const old = await freshness({ [k('brlCentsPerUnit')]: [5_401_200n, BigInt(NOW - 45 * 60)], [k('inCoreSession')]: true });
    expect(old.level).toBe('warn');
    expect(old.detail).toMatch(/Pyth keeper/);
  });

  it('fails outside the core session when the band refuses too: the bands have stopped', async () => {
    const r = await freshness({ [k('brlCentsPerUnit')]: staleRate(NOW - 5 * 86_400), [k('inCoreSession')]: false, [k('brlCentsPerUnitForBand')]: staleRate(NOW - 5 * 86_400) });
    expect(r.level).toBe('fail');
    expect(r.detail).toMatch(/refuses to price even as a band outside the core session .*past closedMaxAge/);
  });

  it('is unknown, never ok, when the session or the band cannot be read', async () => {
    expect((await freshness({ [k('brlCentsPerUnit')]: staleRate(NOW - 5 * 3600), [k('inCoreSession')]: new Error('RPC 503') })).level).toBe('unknown');
    expect((await freshness({ [k('brlCentsPerUnit')]: staleRate(NOW - 5 * 3600), [k('inCoreSession')]: false, [k('brlCentsPerUnitForBand')]: new Error('RPC 503') })).level).toBe('unknown');
  });

  it('points at the Pyth keeper when a cross over it refuses StaleRate', async () => {
    const rs = await runChecks({
      client: chain({
        [`${ESCROW.toLowerCase()}:assets:${USDT.toLowerCase()}`]: [USDT_ORACLE, 6, true],
        [`${USDT_ORACLE.toLowerCase()}:brlCentsPerUnit`]: staleRate(NOW - 2 * 3600),
      }),
      escrow: ESCROW, assets: [USDT],
    }, DEFAULT_THRESHOLDS, NOW);
    const r = by(rs, `asset_oracle:${USDT.toLowerCase()}`);
    expect(r.level).toBe('fail');
    expect(r.detail).toMatch(/StaleRate\(1799992800\); StaleRate is PythFxOracle's refusal: .*Pyth keeper/);
  });
});

describe('the Pyth keeper\'s float', () => {
  it('warns below the keeper\'s floor and fails below half, one check per replica', async () => {
    const [a, b, c] = [A(31), A(32), A(33)];
    const rs = await runChecks({
      client: chain({}, { [a.toLowerCase()]: 6n * 10n ** 16n, [b.toLowerCase()]: 3n * 10n ** 16n, [c.toLowerCase()]: 10n ** 16n }),
      pythKeepers: [a, b, c],
    }, DEFAULT_THRESHOLDS, NOW);
    expect(rs.map((r) => [r.id, r.level])).toEqual([
      [`pyth_keeper_gas:${a.toLowerCase()}`, 'ok'], [`pyth_keeper_gas:${b.toLowerCase()}`, 'warn'], [`pyth_keeper_gas:${c.toLowerCase()}`, 'fail'],
    ]);
    expect(by(rs, `pyth_keeper_gas:${c.toLowerCase()}`).detail).toMatch(/holds 0.0100 ETH: fund it.*refused an hour after the last post/);
  });

  it('is unknown when the balance cannot be read', async () => {
    const rs = await runChecks({ client: chain({}), pythKeepers: [A(34)] }, DEFAULT_THRESHOLDS, NOW);
    expect(rs[0].level).toBe('unknown');
  });
});

/** Tether's powers over escrowed USDT, each exercised on a mainnet fork in UsdtRampFork.t.sol. */
describe('USDT state', () => {
  const k = (fn: string, arg?: string) => `${USDT.toLowerCase()}:${fn}${arg ? `:${arg.toLowerCase()}` : ''}`;
  const healthy = {
    [k('paused')]: false, [k('basisPointsRate')]: 0n, [k('maximumFee')]: 0n, [k('deprecated')]: false,
    [k('isBlackListed', ESCROW)]: false, [k('isBlackListed', OFFRAMP)]: false,
    [k('isBlackListed', ENTRYPOINT)]: false, [k('isBlackListed', USDT_POOL)]: false,
  };
  const run = (overrides: Record<string, unknown>) => runChecks({
    client: chain({ ...healthy, ...overrides }),
    usdt: USDT, escrow: ESCROW, offrampEscrow: OFFRAMP, entrypoint: ENTRYPOINT, usdtPool: USDT_POOL,
  }, DEFAULT_THRESHOLDS, NOW).then((rs) => by(rs, 'usdt_state'));

  it('is quiet while Tether has done nothing', async () => {
    const r = await run({ [`${ENTRYPOINT.toLowerCase()}:latestRoot`]: 1n });
    expect(r.level).toBe('ok');
    expect(r.value).toBe(0);
  });

  it('fails on a pause, a fee, or a deprecation', async () => {
    expect((await run({ [k('paused')]: true, [`${ENTRYPOINT.toLowerCase()}:latestRoot`]: 1n })).detail).toContain('PAUSED');
    const fee = await run({ [k('basisPointsRate')]: 19n, [k('maximumFee')]: 49_000_000n, [`${ENTRYPOINT.toLowerCase()}:latestRoot`]: 1n });
    expect(fee.level).toBe('fail');
    expect(fee.detail).toContain('19 bps');
    const dep = await run({ [k('deprecated')]: true, [k('upgradedAddress')]: A(77), [`${ENTRYPOINT.toLowerCase()}:latestRoot`]: 1n });
    expect(dep.detail).toContain(`DEPRECATED to ${A(77)}`);
  });

  /** The one with no way out: see SR2-25. */
  it('fails, naming it, when an escrow, the entrypoint or the USDT pool is blacklisted', async () => {
    const escrow = await run({ [k('isBlackListed', OFFRAMP)]: true, [`${ENTRYPOINT.toLowerCase()}:latestRoot`]: 1n });
    expect(escrow.level).toBe('fail');
    expect(escrow.detail).toContain(`off-ramp escrow ${OFFRAMP}`);
    const pool = await run({ [k('isBlackListed', USDT_POOL)]: true, [`${ENTRYPOINT.toLowerCase()}:latestRoot`]: 1n });
    expect(pool.detail).toContain('every shielded USDT note is frozen');
    const ep = await run({ [k('isBlackListed', ENTRYPOINT)]: true, [`${ENTRYPOINT.toLowerCase()}:latestRoot`]: 1n });
    expect(ep.detail).toContain('shielded USDT delivery cannot settle');
  });

  /** SR3-9: a frozen vault refuses deposits by itself; the alert is so holders are told. */
  it('watches the USDT yield vault and its adapters when they are configured', async () => {
    const VAULT = A(91); const ADAPTER = A(92);
    const yieldRun = (overrides: Record<string, unknown>) => runChecks({
      client: chain({
        ...healthy, [`${ENTRYPOINT.toLowerCase()}:latestRoot`]: 1n,
        [k('isBlackListed', VAULT)]: false, [k('isBlackListed', ADAPTER)]: false,
        ...overrides,
      }),
      usdt: USDT, escrow: ESCROW, offrampEscrow: OFFRAMP, entrypoint: ENTRYPOINT, usdtPool: USDT_POOL,
      usdtYield: { vault: VAULT, adapters: [ADAPTER] },
    }, DEFAULT_THRESHOLDS, NOW).then((rs) => by(rs, 'usdt_state'));

    expect((await yieldRun({})).level).toBe('ok');
    const vault = await yieldRun({ [k('isBlackListed', VAULT)]: true });
    expect(vault.level).toBe('fail');
    expect(vault.detail).toContain(`USDT yield vault ${VAULT}`);
    expect(vault.detail).toContain('refuses new deposits by itself');
    expect((await yieldRun({ [k('isBlackListed', ADAPTER)]: true })).detail).toContain('exits still pay out');
  });

  it('is unknown, not ok, when the token cannot be read', async () => {
    const r = await run({ [k('paused')]: new Error('RPC 503'), [`${ENTRYPOINT.toLowerCase()}:latestRoot`]: 1n });
    expect(r.level).toBe('unknown');
  });
});

describe('an LP node\'s per-payer caps', () => {
  // NOW is 2027-01-15T08:00:00Z: 05:00 on the 15th in Brasília, which is the day the node must be counting into.
  const TODAY = '2027-01-15';
  const reading = (o: Partial<LpNodeCapsReading> = {}): LpNodeCapsReading => ({
    enabled: true, limiting: true, day: TODAY, rows: 4, lastCountAt: NOW - 30, lastMoneyAt: NOW - 30, unknownPayer: 'refuse', ...o,
  });
  const run = async (o: Partial<LpNodeCapsReading> | Error) => by(await runChecks({
    client: chain({}),
    lpNode: { name: 'lp-1', caps: async () => { if (o instanceof Error) throw o; return reading(o); } },
  }, DEFAULT_THRESHOLDS, NOW), 'lp_node_caps');

  it('is ok while the node is counting into today\'s Brasília day', async () => {
    const r = await run({});
    expect(r.level).toBe('ok');
    expect(r.detail).toMatch(/lp-1 is accounting per-payer caps for 2027-01-15: 4 ledger rows/);
  });

  it('is unknown, not ok, when the node cannot be asked', async () => {
    expect((await run(new Error('LP node /status answered HTTP 503'))).level).toBe('unknown');
  });

  it('fails when the node reports no caps at all: the section is gone, or it is another node', async () => {
    const r = await run({ enabled: false, limiting: false, day: '', rows: 0 });
    expect(r.level).toBe('fail');
    expect(r.detail).toMatch(/running with no per-payer caps.*no daily or monthly limit to anyone/s);
  });

  it('fails when the node counts into another day than Brasília\'s: its limits reset at the wrong hour', async () => {
    const r = await run({ day: '2027-01-14' });
    expect(r.level).toBe('fail');
    expect(r.detail).toMatch(/counting caps into the Brasília day 2027-01-14, and it is 2027-01-15/);
  });

  it('fails when money was attributed long after the ledger was last written: a stuck or replaced journal', async () => {
    const r = await run({ lastCountAt: NOW - 4_000, lastMoneyAt: NOW - 60 });
    expect(r.level).toBe('fail');
    expect(r.value).toBe(3_940);
    expect(r.detail).toMatch(/more recently than its cap ledger was last written.*STATE_FILE/s);
    // Inside the window, and a node that has counted nothing since its restart, are both fine.
    expect((await run({ lastCountAt: NOW - 200, lastMoneyAt: NOW - 60 })).level).toBe('ok');
    expect((await run({ lastCountAt: undefined, lastMoneyAt: undefined, rows: 0 })).level).toBe('ok');
  });

  it('warns while a ledger exists but no tier states a limit: nothing is ever refused', async () => {
    const r = await run({ limiting: false });
    expect(r.level).toBe('warn');
    expect(r.detail).toMatch(/no tier states a limit.*config.caps.tiers/s);
  });

  it('reads /status over HTTP, and refuses an answer that is not a caps block', async () => {
    const answer = (status: number, body: unknown) => async () => new Response(JSON.stringify(body), { status });
    const seen: string[] = [];
    const ok = await lpNodeCapsLoader('https://lp-1.internal:9480/', {
      fetch: (async (u: string) => { seen.push(u); return answer(200, { caps: { enabled: true, limiting: true, day: TODAY, rows: 2, lastCountAt: NOW, lastMoneyAt: NOW, unknownPayer: 'allow' } })(); }) as never,
    })();
    expect(seen).toEqual(['https://lp-1.internal:9480/status']);
    expect(ok).toMatchObject({ enabled: true, limiting: true, day: TODAY, rows: 2, unknownPayer: 'allow' });
    // A node running without caps answers 200 with none: that is `enabled: false`, which the check fails on.
    expect(await lpNodeCapsLoader('https://lp-1.internal:9480', { fetch: answer(200, { caps: null }) as never })()).toMatchObject({ enabled: false });
    await expect(lpNodeCapsLoader('https://lp-1.internal:9480', { fetch: answer(503, {}) as never })()).rejects.toThrow(/HTTP 503/);
    await expect(lpNodeCapsLoader('https://lp-1.internal:9480', { fetch: answer(200, { caps: { day: 'today', rows: 1 } }) as never })()).rejects.toThrow(/caps.day/);
  });
});

describe('targets left unset', () => {
  it('are skipped rather than reported as failures', async () => {
    const rs = await runChecks({ client: chain({}, { [RELAYER.toLowerCase()]: 10n ** 18n }), relayer: RELAYER });
    expect(rs.map((r) => r.id)).toEqual(['relayer_gas']);
  });
});

describe('worst()', () => {
  it('ranks fail above warn above unknown above ok', () => {
    expect(worst([{ id: 'a', level: 'ok', detail: '' }, { id: 'b', level: 'unknown', detail: '' }])).toBe('unknown');
    expect(worst([{ id: 'a', level: 'unknown', detail: '' }, { id: 'b', level: 'warn', detail: '' }])).toBe('warn');
    expect(worst([{ id: 'a', level: 'warn', detail: '' }, { id: 'b', level: 'fail', detail: '' }])).toBe('fail');
    expect(worst([])).toBe('ok');
  });
});

/*//////////////////////////////////////////////////////////////
                             MOVVA
//////////////////////////////////////////////////////////////*/

describe('Movva', () => {
  const RESERVE = A(0xaa);
  const E18 = 10n ** 18n;
  const RATE = 5_400_000_000_000_000_000n; // R$ 5.40 per USDT
  const L = 10_000_000n * E18; // R$ 10M of Movva
  const LIAB_USDT = 1_851_851_851_851n; // 10M / 5.40
  const HEAD = 1_000_000n;
  const blockHashOf = (n: bigint) => `0x${n.toString(16).padStart(64, '0')}` as `0x${string}`;
  const issuerKey = `0x${'42'.repeat(32)}` as const;
  const issuer = privateKeyToAccount(issuerKey);

  /**
   * A reserve answering by function name, or `name@block` for a historical read; `getBlock` and
   * `getLogs` for the snapshot and the 24h withdrawal count.
   */
  function reserve(answers: Record<string, unknown>, opts: { logs?: { blockNumber: bigint; usdt: bigint }[] } = {}) {
    const calls: string[] = [];
    const client = {
      readContract: async ({ functionName, blockNumber }: any) => {
        const key = blockNumber === undefined ? functionName : `${functionName}@${blockNumber}`;
        calls.push(key);
        const v = key in answers ? answers[key] : answers[functionName];
        if (v instanceof Error) throw v;
        if (v === undefined && PROBES.has(functionName)) throw new ContractFunctionZeroDataError({ functionName });
        if (v === undefined) throw new Error(`no answer configured for ${key}`);
        return v;
      },
      getBlock: async ({ blockNumber }: any) => {
        const n = blockNumber ?? HEAD;
        const v = answers[`block@${n}`];
        if (v instanceof Error) throw v;
        return { number: n, hash: blockHashOf(n), timestamp: BigInt(NOW) - (HEAD - n) * 12n };
      },
      getLogs: async ({ fromBlock, toBlock }: any) => { calls.push('getLogs'); return (opts.logs ?? [])
        .filter((l) => l.blockNumber >= fromBlock && l.blockNumber <= toBlock)
        .map((l) => ({ blockNumber: l.blockNumber, args: { usdt: l.usdt } })); },
    } as unknown as MonitorTargets['client'];
    return { client, calls };
  }

  /**
   * A reserve at `ratioBps` with the deployment defaults since the 14 September 2026 review - target
   * 108%, withdraw floor 103%, 24h hedge limit 8% - its USDT what that ratio needs at R$ 5.40, and a
   * full 24h bucket (`hedgeWithdrawable()` = 8% of it).
   */
  const healthy = (ratioBps = 10_800n, over: Record<string, unknown> = {}) => {
    const totalUsdt = (L * ratioBps / 10_000n) * 1_000_000n / RATE + 1n;
    return {
      collateralRatioBps: ratioBps, targetCollateralRatioBps: 10_800, minMintCollateralRatioBps: 10_000, minWithdrawCollateralRatioBps: 10_300,
      brlPerUsdtE18: [RATE, BigInt(NOW - 60)], totalUsdt, liabilitiesBrlE18: L, liabilitiesUsdt: LIAB_USDT,
      hedgeWithdrawable: totalUsdt * 800n / 10_000n, hedgeLimitBps: 800,
      ...over,
    };
  };

  const revertedReserve = (signature: string, args: readonly unknown[], functionName: string) => {
    const abi = parseAbi([signature]);
    const data = encodeErrorResult({ abi, errorName: (abi[0] as { name: string }).name, args } as never);
    return new ContractFunctionExecutionError(
      new ContractFunctionRevertedError({ abi, data, functionName }),
      { abi, functionName, contractAddress: RESERVE },
    );
  };

  const run = (
    client: MonitorTargets['client'], movva: Partial<NonNullable<MonitorTargets['movva']>> = {}, redactValues?: string[],
    th: Partial<typeof DEFAULT_THRESHOLDS> = {},
  ) => runChecks({ client, movva: { reserve: RESERVE, chainId: 1, ...movva }, redactValues }, { ...DEFAULT_THRESHOLDS, ...th }, NOW);

  const SNAP_BLOCK = HEAD - 300n;
  /** A statement document as the desk publishes it, signed by `key`. */
  async function statement(over: {
    key?: `0x${string}`; sequence?: bigint; asOf?: bigint; netShort?: bigint; contracts?: bigint; previous?: `0x${string}`;
    liabilities?: bigint; chainId?: number; freeCents?: bigint;
  } = {}) {
    const account = privateKeyToAccount(over.key ?? issuerKey);
    const contracts = over.contracts ?? 185n;
    const message = {
      issuer: issuer.address, sequence: over.sequence ?? 1n, asOf: over.asOf ?? BigInt(NOW - 3600), reserveBlock: SNAP_BLOCK,
      reserveBlockHash: blockHashOf(SNAP_BLOCK), reserveBrlPerUsdtE18: RATE, reserveLiabilitiesUsdt: over.liabilities ?? LIAB_USDT,
      positions: [{ instrument: 'WDO', ticker: 'WDOV26', expiry: '2026-10-01', side: 'short', contracts, contractSizeUsd: 10_000n, averagePriceBrlPerUsdE6: 5_420_000n }],
      netShortUsdE6: over.netShort ?? contracts * 10_000n * 1_000_000n,
      marginBalanceBrlCents: 99_900_000n + (over.freeCents ?? 0n), marginRequiredBrlCents: 99_900_000n,
      brokerStatementSha256: `0x${'ab'.repeat(32)}` as `0x${string}`,
      previousStatementHash: over.previous ?? `0x${'00'.repeat(32)}` as `0x${string}`,
    };
    const domain = { name: 'Movva Hedge Statement', version: '1', chainId: over.chainId ?? 1, verifyingContract: RESERVE } as const;
    const typed = { domain, types: MOVVA_STATEMENT_TYPES, primaryType: 'HedgeStatement', message } as const;
    const signature = await account.signTypedData(typed);
    const str = (x: bigint) => x.toString();
    return {
      hash: hashTypedData(typed),
      text: JSON.stringify({
        format: 'movva-hedge-statement/v1', domain,
        message: {
          ...message, sequence: str(message.sequence), asOf: str(message.asOf), reserveBlock: str(message.reserveBlock),
          reserveBrlPerUsdtE18: str(message.reserveBrlPerUsdtE18), reserveLiabilitiesUsdt: str(message.reserveLiabilitiesUsdt),
          positions: message.positions.map((p) => ({ ...p, contracts: str(p.contracts), contractSizeUsd: str(p.contractSizeUsd), averagePriceBrlPerUsdE6: str(p.averagePriceBrlPerUsdE6) })),
          netShortUsdE6: str(message.netShortUsdE6), marginBalanceBrlCents: str(message.marginBalanceBrlCents), marginRequiredBrlCents: str(message.marginRequiredBrlCents),
        },
        hash: hashTypedData(typed), signature,
      }),
    };
  }
  const atSnapshot = { [`brlPerUsdtE18@${SNAP_BLOCK}`]: [RATE, BigInt(NOW - 4000)], [`liabilitiesUsdt@${SNAP_BLOCK}`]: LIAB_USDT };
  const withStatement = (text: string | undefined, memory = {}) => ({ statement: { load: async () => text, issuer: issuer.address, memory } });

  describe('collateral ratio', () => {
    it('is ok at or above target, warns below it, and fails under-backed', async () => {
      expect(by(await run(reserve(healthy(10_900n)).client), 'movva_collateral_ratio')).toMatchObject({ level: 'ok', value: 10_900, threshold: 10_800 });
      const below = by(await run(reserve(healthy(10_500n)).client), 'movva_collateral_ratio');
      expect(below.level).toBe('warn');
      expect(below.detail).toMatch(/below the 108.00% target; recapitalize/);
      const noMint = by(await run(reserve(healthy(10_500n, { minMintCollateralRatioBps: 10_600, minWithdrawCollateralRatioBps: 10_700 })).client), 'movva_collateral_ratio');
      expect(noMint.detail).toMatch(/target: mint is refused; recapitalize/);
      // A -10% day from the 108% target: 97.20%.
      const under = by(await run(reserve(healthy(9_720n)).client), 'movva_collateral_ratio');
      expect(under.level).toBe('fail');
      expect(under.detail).toMatch(/UNDER-BACKED at 97.20%: redeem pays 97.20%/);
    });

    /** The parameters the review replaced: a 105% withdraw floor above a 102% target. */
    it('warns on ratios out of order, even with the ratio itself healthy', async () => {
      const r = by(await run(reserve(healthy(10_300n, { targetCollateralRatioBps: 10_200, minWithdrawCollateralRatioBps: 10_500 })).client), 'movva_collateral_ratio');
      expect(r.level).toBe('warn');
      expect(r.detail).toMatch(/RATIOS OUT OF ORDER: mint floor 100.00%, withdraw floor 105.00%, target 102.00%/);
    });

    it('fails when the reserve refuses to compute it, is unknown when the read fails, and is quiet with no supply', async () => {
      const refused = by(await run(reserve(healthy(10_200n, {
        collateralRatioBps: revertedReserve('error StaleLeg(address leg, uint256 updatedAt)', [FEED, 1n], 'collateralRatioBps'),
      })).client), 'movva_collateral_ratio');
      expect(refused.level).toBe('fail');
      expect(refused.detail).toMatch(/StaleLeg/);
      expect(by(await run(reserve(healthy(10_200n, { collateralRatioBps: new Error('RPC 503') })).client), 'movva_collateral_ratio').level).toBe('unknown');
      expect(by(await run(reserve(healthy(2n ** 256n - 1n)).client), 'movva_collateral_ratio')).toMatchObject({ level: 'ok', detail: 'no Movva in circulation' });
    });
  });

  describe('rate', () => {
    it('ages like the oracle it is built from', async () => {
      expect(by(await run(reserve(healthy()).client), 'movva_rate')).toMatchObject({ level: 'ok', value: 60 });
      expect(by(await run(reserve(healthy(10_200n, { brlPerUsdtE18: [RATE, BigInt(NOW - 40 * 60)] })).client), 'movva_rate').level).toBe('warn');
      expect(by(await run(reserve(healthy(10_200n, { brlPerUsdtE18: [RATE, BigInt(NOW - 2 * 3600)] })).client), 'movva_rate').level).toBe('fail');
    });

    it('fails on a revert, naming it, and on a mis-scaled rate', async () => {
      const r = by(await run(reserve(healthy(10_200n, {
        brlPerUsdtE18: revertedReserve('error StaleLeg(address leg, uint256 updatedAt)', [FEED, 1_789_000_000n], 'brlPerUsdtE18'),
      })).client), 'movva_rate');
      expect(r.level).toBe('fail');
      expect(r.detail).toMatch(/refuses to price \(StaleLeg\(.*1789000000\)\)/);
      const inverted = by(await run(reserve(healthy(10_200n, { brlPerUsdtE18: [185_000_000_000_000_000n, BigInt(NOW)] })).client), 'movva_rate');
      expect(inverted).toMatchObject({ level: 'fail' });
      expect(inverted.detail).toMatch(/mis-scaled or inverted/);
      expect(by(await run(reserve(healthy(10_200n, { brlPerUsdtE18: new Error('RPC 503') })).client), 'movva_rate').level).toBe('unknown');
    });
  });

  describe('hedge statement', () => {
    it('passes a fresh statement signed by the issuer that matches its snapshot, reporting the hedge ratio', async () => {
      const s = await statement();
      const r = by(await run(reserve(healthy(10_200n, atSnapshot)).client, withStatement(s.text)), 'movva_hedge_statement');
      // 185 WDO = 1,850,000 against 1,851,851.85: 99.90%
      expect(r).toMatchObject({ level: 'ok', value: 9_990, threshold: 200 });
      expect(r.detail).toMatch(/statement #1 signed by the issuer, 60 min old; hedge ratio 99.90%/);
    });

    it('fails when there is no statement, or it is not one', async () => {
      expect(by(await run(reserve(healthy()).client, withStatement(undefined)), 'movva_hedge_statement')).toMatchObject({ level: 'fail' });
      const junk = by(await run(reserve(healthy()).client, withStatement('<html>502</html>')), 'movva_hedge_statement');
      expect(junk.level).toBe('fail');
      expect(junk.detail).toMatch(/invalid/);
    });

    it('fails a statement signed by anyone but the issuer, or for another chain', async () => {
      const forged = await statement({ key: `0x${'43'.repeat(32)}` });
      const r = by(await run(reserve(healthy(10_200n, atSnapshot)).client, withStatement(forged.text)), 'movva_hedge_statement');
      expect(r.level).toBe('fail');
      expect(r.detail).toMatch(/NOT signed by the issuer's statement key/);
      const otherChain = await statement({ chainId: 5 });
      expect(by(await run(reserve(healthy(10_200n, atSnapshot)).client, withStatement(otherChain.text)), 'movva_hedge_statement').level).toBe('fail');
    });

    it('fails a stale statement', async () => {
      const s = await statement({ asOf: BigInt(NOW - 27 * 3600) });
      const r = by(await run(reserve(healthy(10_200n, atSnapshot)).client, withStatement(s.text)), 'movva_hedge_statement');
      expect(r.level).toBe('fail');
      expect(r.detail).toMatch(/27h old, past 26h/);
    });

    it('warns when the hedge ratio is outside the policy band', async () => {
      const s = await statement({ contracts: 170n }); // 1,700,000 / 1,851,851.85 = 91.80%
      const r = by(await run(reserve(healthy(10_200n, atSnapshot)).client, withStatement(s.text)), 'movva_hedge_statement');
      expect(r).toMatchObject({ level: 'warn', value: 9_180 });
      expect(r.detail).toMatch(/outside the ±2.00% policy band/);
    });

    it('fails a statement that does not match the reserve at its snapshot block, and checks it once', async () => {
      const lying = await statement({ liabilities: LIAB_USDT / 2n });
      const r = by(await run(reserve(healthy(10_200n, atSnapshot)).client, withStatement(lying.text)), 'movva_hedge_statement');
      expect(r.level).toBe('fail');
      expect(r.detail).toMatch(/does not match the reserve at block/);

      const s = await statement();
      const { client, calls } = reserve(healthy(10_200n, atSnapshot));
      const memory = {};
      await run(client, withStatement(s.text, memory));
      await run(client, withStatement(s.text, memory));
      expect(calls.filter((c) => c === `liabilitiesUsdt@${SNAP_BLOCK}`)).toHaveLength(1);
    });

    it('is unknown, not ok, when the snapshot needs an archive node the RPC is not, and redacts the error', async () => {
      const s = await statement();
      const r = by(await run(reserve(healthy(10_200n, {
        [`liabilitiesUsdt@${SNAP_BLOCK}`]: new Error('missing trie node at https://rpc.example/v2/SECRETKEY12345'),
        [`brlPerUsdtE18@${SNAP_BLOCK}`]: [RATE, 1n],
      })).client, withStatement(s.text), ['https://rpc.example/v2/SECRETKEY12345']), 'movva_hedge_statement');
      expect(r.level).toBe('unknown');
      expect(r.detail).toMatch(/could not be checked \(archive node\?\)/);
      expect(r.detail).not.toContain('SECRETKEY12345');
    });

    it('remembers the chain across sweeps: a replaced, rewound or unlinked statement fails', async () => {
      const one = await statement({ sequence: 1n });
      const memory = {};
      const client = reserve(healthy(10_200n, atSnapshot)).client;
      expect(by(await run(client, withStatement(one.text, memory)), 'movva_hedge_statement').level).toBe('ok');

      const replaced = await statement({ sequence: 1n, freeCents: 1n });
      expect(by(await run(client, withStatement(replaced.text, memory)), 'movva_hedge_statement').detail).toMatch(/#1 was REPLACED/);

      const unlinked = await statement({ sequence: 2n, asOf: BigInt(NOW - 60), previous: `0x${'11'.repeat(32)}` });
      expect(by(await run(client, withStatement(unlinked.text, memory)), 'movva_hedge_statement').detail).toMatch(/does not link to #1/);

      const two = await statement({ sequence: 2n, asOf: BigInt(NOW - 60), previous: one.hash });
      expect(by(await run(client, withStatement(two.text, memory)), 'movva_hedge_statement').level).toBe('ok');
      expect(by(await run(client, withStatement(one.text, memory)), 'movva_hedge_statement').detail).toMatch(/went BACKWARDS from #2 to #1/);
    });

    it('is unknown when the statement cannot be fetched, without leaking the URL', async () => {
      const r = by(await run(reserve(healthy()).client, {
        statement: { load: async () => { throw new Error('fetch failed: https://issuer.example/statements/latest.json?token=TOPSECRET99'); }, issuer: issuer.address, memory: {} },
      }, ['https://issuer.example/statements/latest.json?token=TOPSECRET99']), 'movva_hedge_statement');
      expect(r.level).toBe('unknown');
      expect(r.detail).not.toContain('TOPSECRET99');
    });

    it('loads from a URL (404 is missing, 500 is a read failure) or a file (absent is missing)', async () => {
      const fetchWith = (status: number, body = '{}') => (async () => new Response(body, { status })) as unknown as typeof fetch;
      expect(await movvaStatementLoader({ url: 'https://x/latest.json' }, { fetch: fetchWith(200, 'doc') })()).toBe('doc');
      expect(await movvaStatementLoader({ url: 'https://x/latest.json' }, { fetch: fetchWith(404) })()).toBeUndefined();
      await expect(movvaStatementLoader({ url: 'https://x/latest.json' }, { fetch: fetchWith(500) })()).rejects.toThrow(/HTTP 500/);
      const enoent = Object.assign(new Error('ENOENT'), { code: 'ENOENT' });
      expect(await movvaStatementLoader({ file: '/x' }, { readFile: async () => { throw enoent; } })()).toBeUndefined();
      await expect(movvaStatementLoader({ file: '/x' }, { readFile: async () => { throw new Error('EACCES'); } })()).rejects.toThrow(/EACCES/);
    });
  });

  describe('withdraw headroom', () => {
    /**
     * At 108%, assumed fully hedged at liabilitiesUsdt (1,851,851.85): a +5% move (5.40 -> 5.67) costs
     * 1,851,851.85 x 0.27 = R$ 500,000 plus R$ 50,000 of initial margin. The reserve's bucket holds
     * 8% x 2,000,000 = 160,000 USDT (under the floor's 183,421.52), = 160,000 x 5.67 x 0.997 = R$ 904,478.40.
     */
    it('is ok when the reserve\'s own 24h bucket covers a 5% rally', async () => {
      const r = by(await run(reserve(healthy()).client), 'movva_withdraw_headroom');
      expect(r).toMatchObject({ level: 'ok', value: 100, threshold: 100 });
      expect(r.detail).toMatch(/needs R\$ 550.000,00 of margin, covered/);
      expect(r.detail).toMatch(/R\$ 904.478,40 after the move \(the 24h limit binds; the reserve's hedgeWithdrawable\(\) holds 160000 USDT of its 8.00%\/24h limit\)/);
      expect(r.detail).toMatch(/assumed at liabilitiesUsdt/);
    });

    /** +10%: R$ 1,100,000 against 160,000 x 5.94 x 0.997 = R$ 947,548.80: 86%, R$ 152,451.20 from the issuer. */
    it('warns when a 10% rally would need more margin than the bucket releases', async () => {
      const r = by(await run(reserve(healthy()).client, {}, undefined, { movvaShockBps: 1_000 }), 'movva_withdraw_headroom');
      expect(r).toMatchObject({ level: 'warn', value: 86 });
      expect(r.detail).toMatch(/would need R\$ 1.100.000,00 of margin; withdrawToHedge covers 86%, the issuer would fund R\$ 152.451,20/);
    });

    /** 10,000 USDT left in the bucket: 10,000 x 5.67 x 0.997 = R$ 56,529.90 of R$ 550,000 = 10%. */
    it('prefers the reserve\'s bucket to the configured limit and the event count, and says when configuration disagrees', async () => {
      const logs = [{ blockNumber: HEAD - 100n, usdt: 1n }];
      const { client, calls } = reserve(healthy(10_800n, { hedgeWithdrawable: 10_000_000_000n }), { logs });
      const r = by(await run(client, {}, undefined, { movvaWithdrawDailyLimitBps: 200 }), 'movva_withdraw_headroom');
      expect(r).toMatchObject({ level: 'warn', value: 10 });
      expect(r.detail).toMatch(/holds 10000 USDT of its 8.00%\/24h limit \(MOVVA_WITHDRAW_DAILY_LIMIT_BPS says 2.00%: update it\)/);
      expect(calls).not.toContain('getLogs');
    });

    it('falls back to the configured limit less what was withdrawn in the last 24h for a reserve without the views', async () => {
      // At 130%: 8% of 2,407,407.41 = 192,592.59 USDT, less 20,000 inside the window (5 outside it); the floor allows 590,828.92.
      const logs = [{ blockNumber: HEAD - 100n, usdt: 20_000_000_000n }, { blockNumber: HEAD - 7_300n, usdt: 5_000_000_000n }];
      const noView = revertedReserve('error NotImplemented()', [], 'hedgeWithdrawable');
      const { client, calls } = reserve(healthy(13_000n, { hedgeWithdrawable: noView, hedgeLimitBps: noView }), { logs });
      const r = by(await run(client), 'movva_withdraw_headroom');
      expect(r.detail).toMatch(/24h limit binds; the reserve exposes no hedgeWithdrawable\(\): assumed 8.00%\/24h less 20000 USDT withdrawn in 24h/);
      expect(calls).toContain('getLogs');
      // A view that fails to READ is not a reserve without it: unknown, not a silent fallback.
      const flaky = by(await run(reserve(healthy(13_000n, { hedgeWithdrawable: new Error('RPC 503') })).client), 'movva_withdraw_headroom');
      expect(flaky.level).toBe('unknown');
    });

    /**
     * At 110% with the statement's 185 WDO (US$ 1,850,000), R$ 400,000 of free margin and a +10% stress:
     * the call is 999,000 + 99,900 - 400,000 = R$ 698,900. The bucket (8% of 2,037,037.04 = 162,962.96
     * USDT) releases 162,962.96 x 5.94 x 0.997 = R$ 965,091: covered. Without the statement, assumed
     * fully hedged with no free margin: R$ 1,100,000, 87%.
     */
    it('uses the verified statement\'s short and free margin, and is ok when they cover the call', async () => {
      const s = await statement({ freeCents: 40_000_000n });
      const stress = { movvaShockBps: 1_000 };
      const r = by(await run(reserve(healthy(11_000n, atSnapshot)).client, withStatement(s.text), undefined, stress), 'movva_withdraw_headroom');
      expect(r).toMatchObject({ level: 'ok', value: 100 });
      expect(r.detail).toMatch(/needs R\$ 698.900,00 of margin, covered: short 1,850,000 USD \(statement #1\)/);
      expect(by(await run(reserve(healthy(11_000n)).client, {}, undefined, stress), 'movva_withdraw_headroom')).toMatchObject({ level: 'warn', value: 87 });
    });

    it('warns, naming the refusal, while the reserve cannot price', async () => {
      const r = by(await run(reserve(healthy(10_800n, {
        brlPerUsdtE18: revertedReserve('error NoPriceYet()', [], 'brlPerUsdtE18'),
      })).client), 'movva_withdraw_headroom');
      expect(r.level).toBe('warn');
      expect(r.detail).toMatch(/unavailable while the reserve refuses to price \(NoPriceYet\(\)\)/);
    });
  });

  /**
   * Friday night with a PythFxOracle leg: every view that prices refuses StaleRate, and the band reads the close.
   * Mova's decision, not an outage: nothing pages, and what can be computed is, at the close, saying so.
   */
  describe('while the FX market is closed', () => {
    const LEG = A(0xf7);
    const staleRate = (fn: string) => revertedReserve('error StaleRate(uint256 publishTime)', [BigInt(NOW - 5 * 3600)], fn);
    const closed = (over: Record<string, unknown> = {}) => healthy(10_800n, {
      brlPerUsdtE18: staleRate('brlPerUsdtE18'), collateralRatioBps: staleRate('collateralRatioBps'),
      liabilitiesUsdt: staleRate('liabilitiesUsdt'),
      fxOracle: LEG, inCoreSession: false, bandBrlPerUsdtE18: [RATE, BigInt(NOW)], ...over,
    });

    it('reports the rate ok, saying the market is closed, and the ratio and headroom at the last close', async () => {
      const rs = await run(reserve(closed()).client);
      const rate = by(rs, 'movva_rate');
      expect(rate.level).toBe('ok');
      expect(rate.detail).toMatch(/the FX market is closed: the reserve refuses to price value \(StaleRate\(1799982000\)\), so mint, redeem and withdrawToHedge wait for the reopening, while Movva's band on the ramps reads the last close, R\$ 5,4000 per USDT/);
      const ratio = by(rs, 'movva_collateral_ratio');
      expect(ratio).toMatchObject({ level: 'ok', value: 10_800 });
      expect(ratio.detail).toMatch(/collateral ratio 108.00% \(target 108.00%\) at the last close, R\$ 5,4000 per USDT \(the FX market is closed/);
      const headroom = by(rs, 'movva_withdraw_headroom');
      expect(headroom).toMatchObject({ level: 'ok', value: 100 });
      expect(headroom.detail).toMatch(/needs R\$ 550.000,00 of margin, covered: .*Priced at the last close, R\$ 5,4000 per USDT: the FX market is closed and withdrawToHedge waits/);
    });

    it('computes an under-backed ratio at the close, and still fails it', async () => {
      const under = by(await run(reserve(closed({ totalUsdt: 1_800_000_000_000n })).client), 'movva_collateral_ratio');
      expect(under.level).toBe('fail');
      expect(under.detail).toMatch(/UNDER-BACKED at 97.20% at the last close/);
    });

    it('reports the hedge ratio at the last close, rounded as the reserve rounds liabilitiesUsdt', async () => {
      const s = await statement();
      const r = by(await run(reserve(closed(atSnapshot)).client, withStatement(s.text)), 'movva_hedge_statement');
      expect(r).toMatchObject({ level: 'ok', value: 9_989 });
      expect(r.detail).toMatch(/hedge ratio 99.89% at the last close \(the FX market is closed\)/);
    });

    it('inside the core session a refused rate is an outage, and names the Pyth keeper', async () => {
      const rs = await run(reserve(closed({ inCoreSession: true, bandBrlPerUsdtE18: staleRate('bandBrlPerUsdtE18') })).client);
      expect(by(rs, 'movva_rate').level).toBe('fail');
      expect(by(rs, 'movva_rate').detail).toMatch(/Check the Pyth keeper - inside the FX market's core session it keeps .* feed posted/);
      expect(by(rs, 'movva_collateral_ratio').level).toBe('fail');
      expect(by(rs, 'movva_withdraw_headroom').level).toBe('warn');
    });

    /**
     * A ChainlinkFxOracle leg: its rate refuses MarketClosed outside the core session (the heartbeat keeps the answer
     * young, so the clock decides), and inside it the rate is the feed's last round, hours old by design.
     */
    it('reads a ChainlinkFxOracle leg\'s MarketClosed as the closed market, and its day-old round by MOVVA_RATE_*', async () => {
      const marketClosed = (fn: string) => revertedReserve('error MarketClosed(uint256 timestamp)', [BigInt(NOW)], fn);
      const rs = await run(reserve(closed({
        brlPerUsdtE18: marketClosed('brlPerUsdtE18'), collateralRatioBps: marketClosed('collateralRatioBps'),
        liabilitiesUsdt: marketClosed('liabilitiesUsdt'),
      })).client);
      expect(by(rs, 'movva_rate').level).toBe('ok');
      expect(by(rs, 'movva_rate').detail).toMatch(/the FX market is closed: the reserve refuses to price value \(MarketClosed\(1800000000\)\)/);

      const dayOld = { brlPerUsdtE18: [RATE, BigInt(NOW - 20 * 3600)], fxOracle: LEG, inCoreSession: true };
      const chainlink = { movvaRateWarnSeconds: 90_000, movvaRateFailSeconds: 93_600 };
      const ok = by(await run(reserve(healthy(10_800n, dayOld)).client, {}, undefined, chainlink), 'movva_rate');
      expect(ok).toMatchObject({ level: 'ok', value: 20 * 3600 });
      const pythDefaults = by(await run(reserve(healthy(10_800n, dayOld)).client), 'movva_rate');
      expect(pythDefaults.level).toBe('fail');
      expect(pythDefaults.detail).toMatch(/ChainlinkFxOracle leg there is no keeper/);
    });

    it('a stale USDT/USD feed at night is not the market: the band refuses too, and it fails', async () => {
      const feed = revertedReserve('error StaleLeg(address leg, uint256 updatedAt)', [FEED, 1n], 'bandBrlPerUsdtE18');
      const rs = await run(reserve(closed({ brlPerUsdtE18: revertedReserve('error StaleLeg(address leg, uint256 updatedAt)', [FEED, 1n], 'brlPerUsdtE18'), bandBrlPerUsdtE18: feed })).client);
      expect(by(rs, 'movva_rate').level).toBe('fail');
      expect(by(rs, 'movva_rate').detail).toMatch(/Check the USDT\/USD feed, and whether .*closedMaxAge \(the band refuses too: StaleLeg/);
    });

    it('an old rate is ok after the close, and warns inside the core session naming the Pyth keeper; a leg without hours names the publishers', async () => {
      const old = { brlPerUsdtE18: [RATE, BigInt(NOW - 40 * 60)], fxOracle: LEG };
      const after = by(await run(reserve(healthy(10_800n, { ...old, inCoreSession: false, bandBrlPerUsdtE18: [RATE, BigInt(NOW - 40 * 60)] })).client), 'movva_rate');
      expect(after).toMatchObject({ level: 'ok', value: 40 * 60 });
      expect(after.detail).toMatch(/the FX market is closed, so no newer price comes until it reopens/);
      const inside = by(await run(reserve(healthy(10_800n, { ...old, inCoreSession: true })).client), 'movva_rate');
      expect(inside.level).toBe('warn');
      expect(inside.detail).toMatch(/Check the Pyth keeper/);
      const signed = by(await run(reserve(healthy(10_800n, { brlPerUsdtE18: [RATE, BigInt(NOW - 40 * 60)] })).client), 'movva_rate');
      expect(signed.detail).toMatch(/Check the FX publishers and the USDT\/USD feed/);
    });

    it('is unknown, never ok, when the leg\'s session or the band cannot be read', async () => {
      const rs = await run(reserve(closed({ inCoreSession: new Error('RPC 503') })).client);
      for (const id of ['movva_rate', 'movva_collateral_ratio', 'movva_withdraw_headroom']) expect(by(rs, id).level, id).toBe('unknown');
      expect(by(await run(reserve(closed({ bandBrlPerUsdtE18: new Error('RPC 503') })).client), 'movva_rate').level).toBe('unknown');
    });
  });

  it('runs nothing for Movva unless a reserve is configured, and the statement check only with a source', async () => {
    const rs = await run(reserve(healthy()).client);
    expect(rs.map((r) => r.id).sort()).toEqual(['movva_collateral_ratio', 'movva_rate', 'movva_withdraw_headroom']);
  });
});

describe('node-provider rewards', () => {
  const REWARDS = A(0x7e1), SPLITTER = A(0x7e2), TOKEN = A(0x7e3), REGISTRY = A(0x7e4);
  const E18 = 10n ** 18n;
  const at = (k: string) => `${REWARDS.toLowerCase()}:${k}`;
  const base = (over: Record<string, unknown> = {}) => ({
    [at('REWARD_TOKEN')]: TOKEN, [at('TOKEN_PER_CENT')]: 10n ** 16n, [at('registry')]: REGISTRY,
    [at('accounted')]: 1_000n * E18, [at('outstanding')]: 40n * E18, [at('carry')]: 960n * E18, [at('totalFunded')]: 1_000n * E18,
    [at('nextToFinalize')]: 5n, [at('finalizableEpochs')]: 0n, [at('lastClaimAt')]: BigInt(NOW - 3_600),
    [`${at('finalizableAt')}:5`]: BigInt(NOW + 86_400), [`${at('finalizableAt')}:0`]: BigInt(NOW - 40 * 86_400),
    [`${TOKEN.toLowerCase()}:balanceOf:${REWARDS.toLowerCase()}`]: 1_000n * E18,
    [`${SPLITTER.toLowerCase()}:TOKEN`]: TOKEN, [`${SPLITTER.toLowerCase()}:rewards`]: REWARDS, [`${SPLITTER.toLowerCase()}:lpRewardShareBps`]: 2_000,
    ...over,
  });
  const run = async (over: Record<string, unknown> = {}, splitter = true) =>
    runChecks({ client: chain(base(over)), rewards: { contract: REWARDS, ...(splitter ? { splitter: SPLITTER } : {}) } }, DEFAULT_THRESHOLDS, NOW);

  it('is quiet when the pool holds what it booked, epochs are finalized and LPs claim', async () => {
    const rs = await run();
    expect(by(rs, 'node_rewards_balance')).toMatchObject({ level: 'ok', value: 100_000 });
    expect(by(rs, 'node_rewards_balance').detail).toMatch(/R\$ 40,00 owed to LPs for finalized epochs, R\$ 960,00 rolling forward/);
    expect(by(rs, 'node_rewards_unclaimed').level).toBe('ok');
    expect(by(rs, 'node_rewards_wiring')).toMatchObject({ level: 'ok' });
    expect(by(rs, 'node_rewards_wiring').detail).toMatch(/forwards 2000 bps/);
  });

  it('fails when the pool holds less than it has booked', async () => {
    const r = by(await run({ [`${TOKEN.toLowerCase()}:balanceOf:${REWARDS.toLowerCase()}`]: 999n * E18 }), 'node_rewards_balance');
    expect(r.level).toBe('fail');
    expect(r.detail).toMatch(/claims will revert/);
  });

  it('warns when nobody finalizes an epoch long after its review, and when rewards sit unclaimed for weeks', async () => {
    const stuck = by(await run({ [at('finalizableEpochs')]: 2n, [`${at('finalizableAt')}:5`]: BigInt(NOW - 3 * 86_400) }), 'node_rewards_unclaimed');
    expect(stuck.level).toBe('warn');
    expect(stuck.detail).toMatch(/epoch 5 could be finalized 72h ago and nobody has \(2 epoch\(s\) waiting\)/);
    const quiet = by(await run({ [at('lastClaimAt')]: BigInt(NOW - 40 * 86_400), [at('outstanding')]: 500n * E18 }), 'node_rewards_unclaimed');
    expect(quiet.level).toBe('warn');
    expect(quiet.detail).toMatch(/R\$ 500,00 of finalized LP rewards is unclaimed and no LP has claimed for 40 days/);
    // Never claimed, but under the floor: not a notice.
    expect(by(await run({ [at('lastClaimAt')]: 0n, [at('outstanding')]: 99n * E18 }), 'node_rewards_unclaimed').level).toBe('ok');
  });

  it('warns when settlements cannot count or the splitter funds something else', async () => {
    const unbound = by(await run({ [at('registry')]: ZERO }), 'node_rewards_wiring');
    expect(unbound.level).toBe('warn');
    expect(unbound.detail).toMatch(/no registry is bound/);
    const elsewhere = by(await run({ [`${SPLITTER.toLowerCase()}:rewards`]: A(0xbad) }), 'node_rewards_wiring');
    expect(elsewhere.detail).toMatch(/the FeeSplitter funds .* not this NodeRewards/);
    // Unbound with nothing ever funded and no splitter configured: nothing is waiting, so nothing to say.
    expect(by(await run({ [at('registry')]: ZERO, [at('totalFunded')]: 0n }, false), 'node_rewards_wiring').level).toBe('ok');
  });

  it('reports unknown, not ok, when it cannot read', async () => {
    const rs = await runChecks({ client: chain({}), rewards: { contract: REWARDS } }, DEFAULT_THRESHOLDS, NOW);
    for (const id of ['node_rewards_balance', 'node_rewards_unclaimed', 'node_rewards_wiring']) expect(by(rs, id).level, id).toBe('unknown');
  });
});

describe('the sponsor gate', () => {
  const GATE = A(51);
  const PM = A(52);
  const OP = A(53);
  const gateChain = (o: { max?: number; remaining?: bigint; endsAt?: bigint; owner?: string; isOperator?: boolean; balance?: bigint } = {}) => chain({
    [`${GATE.toLowerCase()}:maxSponsorsPerWindow`]: o.max ?? 100,
    [`${GATE.toLowerCase()}:remainingSponsorships`]: o.remaining ?? 90n,
    [`${GATE.toLowerCase()}:windowEndsAt`]: o.endsAt ?? BigInt(NOW + 3600),
    [`${GATE.toLowerCase()}:PAYMASTER`]: PM,
    [`${PM.toLowerCase()}:owner`]: o.owner ?? GATE,
    [`${GATE.toLowerCase()}:isOperator:${OP.toLowerCase()}`]: o.isOperator ?? true,
  }, { [OP.toLowerCase()]: o.balance ?? 10n ** 18n });
  const run = async (client: MonitorTargets['client'], operators: `0x${string}`[] = []) =>
    runChecks({ client, sponsorGate: { gate: GATE, operators } }, DEFAULT_THRESHOLDS, NOW);

  it('reports the window\'s accounts left: ok, warn past the warn share, fail when spent, saying when it refills and what to do', async () => {
    expect(by(await run(gateChain()), 'sponsor_gate_budget')).toMatchObject({ level: 'ok', value: 10, threshold: 80 });
    expect(by(await run(gateChain({ remaining: 15n })), 'sponsor_gate_budget')).toMatchObject({ level: 'warn', value: 85 });
    const spent = by(await run(gateChain({ remaining: 0n, endsAt: BigInt(NOW + 600) })), 'sponsor_gate_budget');
    expect(spent.level).toBe('fail');
    expect(spent.detail).toMatch(/all 100 accounts this window.*600s.*sponsor-gate:budget.*sponsor-gate:operator <gate> <key> false/);
  });

  it('warns when the budget is zero or the paymaster is not owned by the gate, and is unknown when the gate cannot be read', async () => {
    expect(by(await run(gateChain({ max: 0, remaining: 0n })), 'sponsor_gate_budget')).toMatchObject({ level: 'warn' });
    const ungated = by(await run(gateChain({ owner: A(99) })), 'sponsor_gate_budget');
    expect(ungated.level).toBe('warn');
    expect(ungated.detail).toMatch(/not the gate: operators cannot sponsor/);
    expect(by(await run(chain({})), 'sponsor_gate_budget').level).toBe('unknown');
  });

  it('watches each operator\'s gas, and says when a watched key is no longer an operator', async () => {
    const at = async (balance: bigint, isOperator = true) => by(await run(gateChain({ balance, isOperator }), [OP]), `sponsor_operator_gas:${OP.toLowerCase()}`);
    expect((await at(10n ** 17n)).level).toBe('ok');
    expect((await at(15n * 10n ** 15n)).level).toBe('warn');
    const low = await at(5n * 10n ** 15n);
    expect(low.level).toBe('fail');
    expect(low.detail).toMatch(/holds 0.0050 ETH: fund it.*operator_unfunded/);
    const revoked = await at(10n ** 17n, false);
    expect(revoked.level).toBe('warn');
    expect(revoked.detail).toMatch(/no longer an operator of the gate.*operator_revoked/);
  });
});
