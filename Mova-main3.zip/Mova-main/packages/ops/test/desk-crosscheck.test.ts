import { describe, expect, it } from 'vitest';
import { deskCrosscheck } from '../src/desk-crosscheck.js';
import type { PostedRuling } from '../src/watch.js';

const ARB = '0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7';
const OTHER = '0x1111111111111111111111111111111111111111';
const ESCROW = '0x00000000000000000000000000000000000000e5';
const posted = (o: Partial<PostedRuling> = {}): PostedRuling => ({
  escrow: ESCROW, orderId: `0x${'a1'.repeat(32)}`, arbitrator: ARB, evidenceRoot: `0x${'7d'.repeat(32)}`,
  favoursCounterparty: true, executableAt: 1_800_000_000, ...o,
});

/** A desk that answers /health and one case lookup table. */
function fakeDesk(cases: Record<string, { status: number; body: unknown }>, health: unknown = { ok: true, arbitrator: ARB }) {
  const seen: string[] = [];
  const f = (async (url: string) => {
    const u = new URL(url);
    seen.push(u.pathname + u.search);
    const r = u.pathname === '/health' ? { status: 200, body: health } : cases[u.searchParams.get('orderId') ?? ''] ?? { status: 404, body: { error: 'no such case' } };
    return new Response(JSON.stringify(r.body), { status: r.status });
  }) as unknown as typeof fetch;
  return { f, seen };
}

const ruled = (o: Record<string, unknown> = {}) => ({
  status: 200,
  body: { status: 'RULED', escrow: ESCROW, orderId: `0x${'a1'.repeat(32)}`, ruling: { outcome: 'RELEASE' }, evidenceRoot: `0x${'7d'.repeat(32)}`, ...o },
});

describe('desk cross-check of posted rulings', () => {
  it('passes a ruling the desk completed, with the same evidence and direction', async () => {
    const { f } = fakeDesk({ [`0x${'a1'.repeat(32)}`]: ruled() });
    expect(await deskCrosscheck({ url: 'http://desk/', fetch: f })([posted()])).toEqual([]);
  });

  it('flags a ruling the desk has no case for, or only a draft of, or decided another way', async () => {
    const check = (c: { status: number; body: unknown } | undefined) => deskCrosscheck({ url: 'http://desk', fetch: fakeDesk(c ? { [`0x${'a1'.repeat(32)}`]: c } : {}).f })([posted()]);
    expect(await check(undefined)).toHaveLength(1);                                   // no case: 404
    expect(await check(ruled({ status: 'PROPOSED', ruling: { outcome: 'RELEASE' } }))).toHaveLength(1); // the Safe had not approved
    expect(await check(ruled({ status: 'OPEN', ruling: null }))).toHaveLength(1);
    expect(await check(ruled({ ruling: { outcome: 'REFUND' } }))).toHaveLength(1);     // flipped direction
    expect(await check(ruled({ evidenceRoot: `0x${'00'.repeat(32)}` }))).toHaveLength(1);
  });

  it('leaves rulings under another arbitrator to the plain warning, without asking about them', async () => {
    const { f, seen } = fakeDesk({});
    expect(await deskCrosscheck({ url: 'http://desk', fetch: f })([posted({ arbitrator: OTHER })])).toEqual([]);
    expect(seen).toEqual(['/health']);
  });

  it('throws, rather than guessing, when the desk cannot answer', async () => {
    await expect(deskCrosscheck({ url: 'http://desk', fetch: fakeDesk({}, { ok: true }).f })([posted()])).rejects.toThrow(/without its arbitrator/);
    const broken = fakeDesk({ [`0x${'a1'.repeat(32)}`]: { status: 500, body: { error: 'boom' } } }).f;
    await expect(deskCrosscheck({ url: 'http://desk', fetch: broken })([posted()])).rejects.toThrow(/answered 500/);
  });
});
