import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { existsSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  createPublicClient, createTestClient, createWalletClient, decodeFunctionData, encodeFunctionData, getAddress, http, keccak256, parseAbi, stringToHex,
  type Abi, type Address, type Hex, type PrivateKeyAccount, type PublicClient,
} from 'viem';
import { generatePrivateKey, privateKeyToAccount } from 'viem/accounts';
import { COMMANDS, amountOf, parseArgs, sendRefusal } from '../src/bin/hedge-sleeve.js';
import {
  MULTISEND_CALL_ONLY, MULTISEND_CALL_ONLY_CODEHASH, approvedHashSignatures, encodeMultiSend, executeSleevePlan, planFund, planRecapitalize, planReserveWithdraw,
  planWithdrawToTreasury, readSleeve, renderSleevePlan, txBuilderJson, type ExecMode, type SleeveCtx, type SleevePlan,
} from '../src/hedge-sleeve.js';
import { anvilBinary, startAnvil } from '../../yield/test/anvil.js';

describe('the funding-path CLI, pure parts', () => {
  it('reads whole USDT by default and refuses what is not an amount', () => {
    expect(amountOf('10000', false)).toBe(10_000_000_000n);
    expect(amountOf('1.5', false)).toBe(1_500_000n);
    expect(amountOf('15', true)).toBe(15n);
    expect(() => amountOf('1.1234567', false)).toThrow(/up to 6 decimals/);
    expect(() => amountOf('-1', false)).toThrow();
    expect(() => amountOf('1.5', true)).toThrow(/integers/);
  });

  it('parses commands and flags, and knows every step of the path', () => {
    const a = parseArgs(['sleeve:fund', '10000', '--execute', '--confirm', '10000000000', '--record', 'x.json']);
    expect(a).toMatchObject({ name: 'sleeve:fund', positional: ['10000'], execute: true, confirm: '10000000000', opts: { record: 'x.json' } });
    expect(() => parseArgs(['--nope'])).toThrow(/unknown option/);
    expect(Object.keys(COMMANDS)).toEqual(['reserve:withdraw', 'reserve:queue', 'reserve:execute', 'sleeve:fund', 'sleeve:withdraw', 'sleeve:unwind', 'sleeve:pause', 'reserve:recapitalize']);
  });

  it('refuses to send without the confirmation, the keys, or off a fork when impersonating', () => {
    const p = { refused: false, confirm: '42', actorKind: 'safe' } as SleevePlan;
    expect(sendRefusal(p, { impersonate: false, local: false })).toMatch(/needs --confirm 42/);
    expect(sendRefusal(p, { confirm: '43', impersonate: false, local: false })).toMatch(/does not name/);
    expect(sendRefusal(p, { confirm: '42', impersonate: false, local: false })).toMatch(/SAFE_SIGNER_KEYS/);
    expect(sendRefusal(p, { confirm: '42', impersonate: true, local: false })).toMatch(/local anvil fork only/);
    expect(sendRefusal(p, { confirm: '42', impersonate: true, local: true })).toBeUndefined();
    expect(sendRefusal({ ...p, actorKind: 'eoa' }, { confirm: '42', impersonate: false, local: false, signerKeys: 'k' })).toMatch(/SENDER_KEY/);
    expect(sendRefusal({ ...p, refused: true }, { confirm: '42', impersonate: false, local: false })).toMatch(/check failed/);
  });

  it('packs MultiSendCallOnly batches as CALLs, and approved-hash signatures sorted by owner', () => {
    const to = getAddress('0x00000000000000000000000000000000000000aa');
    const data = encodeMultiSend([{ to, data: '0x1234', fn: 'x()', args: [] }, { to, data: '0x', fn: 'y()', args: [] }]);
    const inner = decodeFunctionData({ abi: parseAbi(['function multiSend(bytes)']), data }).args[0] as Hex;
    // op(1) to(20) value(32) len(32) data(2), then op to value len(0).
    expect(inner.length).toBe(2 + 2 * (1 + 20 + 32 + 32 + 2) + 2 * (1 + 20 + 32 + 32));
    expect(inner.slice(2, 4)).toBe('00');
    const s = approvedHashSignatures(['0x00000000000000000000000000000000000000Bb', '0x00000000000000000000000000000000000000aA']);
    expect(s.length).toBe(2 + 2 * 130);
    expect(s.slice(2 + 62, 2 + 64)).toBe('aa');
    expect(s.slice(2 + 128, 2 + 130)).toBe('01');
  });
});

/*//////////////////////////////////////////////////////////////
       THE WHOLE PATH THROUGH REAL SAFE 1.4.1 CODE (anvil 8964)
//////////////////////////////////////////////////////////////*/

const ROOT = fileURLToPath(new URL('../../../', import.meta.url));
const OUT = join(ROOT, 'forge-out');
const FIX = join(ROOT, 'packages/smart-account/fixtures/canonical');
const ANVIL = anvilBinary();
interface Artifact { abi: Abi; bytecode: Hex }
const artifact = (file: string, name: string): Artifact | undefined => {
  const p = join(OUT, file, `${name}.json`);
  if (!existsSync(p)) return undefined;
  const j = JSON.parse(readFileSync(p, 'utf8')) as { abi: Abi; bytecode: { object: Hex } };
  return { abi: j.abi, bytecode: j.bytecode.object };
};
const fixture = (name: string) => JSON.parse(readFileSync(join(FIX, `${name}.json`), 'utf8')) as { abi: Abi; initCode: Hex; address: Address };
const USDT = artifact('ERC4626Adapter.t.sol', 'TetherLike');
const FEED = artifact('HedgeSleeveBase.sol', 'HedgeFeed');
const VENUE = artifact('SimHedgeVenue.sol', 'SimHedgeVenue');
const WALLET = artifact('HedgeSubWallet.sol', 'HedgeSubWallet');
const RESERVE = artifact('HedgeReserveStub.sol', 'HedgeReserveStub');
const E6 = 1_000_000n;

describe.skipIf(!ANVIL || !USDT || !FEED || !VENUE || !WALLET || !RESERVE)('reserve -> Safe -> fund, and back, through real Safe 1.4.1 code (anvil)', () => {
  let node: Awaited<ReturnType<typeof startAnvil>> | undefined;
  let client: PublicClient;
  let test: ReturnType<typeof createTestClient>;
  let me: PrivateKeyAccount;
  const owners = [0, 1, 2].map(() => privateKeyToAccount(generatePrivateKey()));
  let usdt: Address;
  let reserve: Address;
  let wallet: Address;
  let hedgeSafe: Address;
  let treasurerSafe: Address;
  let ctx: SleeveCtx;

  const send = async (to: Address | undefined, data: Hex) => {
    const w = createWalletClient({ account: me, transport: http(node!.rpcUrl) });
    const hash = await w.sendTransaction({ to, data, chain: null } as never);
    const rc = await client.waitForTransactionReceipt({ hash });
    if (rc.status !== 'success') throw new Error('reverted');
    return rc;
  };
  const deploy = async (a: Artifact, args: unknown[]) => {
    const w = createWalletClient({ account: me, transport: http(node!.rpcUrl) });
    const hash = await w.deployContract({ abi: a.abi, bytecode: a.bytecode, args, chain: null } as never);
    return (await client.waitForTransactionReceipt({ hash })).contractAddress!;
  };
  /** A fresh Safe 1.4.1, 2-of-3: the singleton's runtime code at a new address, set up once. */
  const newSafe = async (n: number): Promise<Address> => {
    const safe = fixture('Safe');
    const runtime = await client.call({ data: safe.initCode });
    const at = getAddress(`0x${(0xa0 + n).toString(16).padStart(40, '0')}`);
    await test.setCode({ address: at, bytecode: runtime.data! });
    await send(at, encodeFunctionData({ abi: safe.abi, functionName: 'setup', args: [owners.map((o) => o.address), 2n, '0x0000000000000000000000000000000000000000', '0x', '0x0000000000000000000000000000000000000000', '0x0000000000000000000000000000000000000000', 0n, '0x0000000000000000000000000000000000000000'] }));
    return at;
  };
  const keys = (signers: PrivateKeyAccount[]): ExecMode => {
    const w = createWalletClient({ account: me, transport: http(node!.rpcUrl) });
    return { kind: 'keys', signers, submitter: Object.assign(me, { sendTransaction: (tx: { to: Address; data: Hex }) => w.sendTransaction({ ...tx, chain: null }) }) };
  };
  const bal = (a: Address) => client.readContract({ address: usdt, abi: USDT!.abi, functionName: 'balanceOf', args: [a] }) as Promise<bigint>;

  beforeAll(async () => {
    node = await startAnvil(ANVIL!, Number(process.env.HEDGE_SLEEVE_ANVIL_PORT ?? 8964), { timestamp: 1_800_000_000 });
    const transport = http(node.rpcUrl);
    client = createPublicClient({ transport }) as PublicClient;
    test = createTestClient({ mode: 'anvil', transport });
    me = privateKeyToAccount(generatePrivateKey());
    await test.setBalance({ address: me.address, value: 10n ** 20n });
    // The canonical MultiSendCallOnly at its canonical address, from its own init code.
    const ms = await client.call({ data: fixture('MultiSendCallOnly').initCode });
    await test.setCode({ address: MULTISEND_CALL_ONLY, bytecode: ms.data! });
    hedgeSafe = await newSafe(1);
    treasurerSafe = await newSafe(2);
    usdt = await deploy(USDT!, []);
    const feed = await deploy(FEED!, [250_000_000_000n, 8]);
    const venue = await deploy(VENUE!, [usdt, me.address, 3_600n, 5, 5]);
    await send(venue, encodeFunctionData({ abi: VENUE!.abi, functionName: 'listMarket', args: [stringToHex('ETH', { size: 32 }), feed, 100_000, 0n] }));
    reserve = await deploy(RESERVE!, [usdt, treasurerSafe, hedgeSafe]);
    await send(usdt, encodeFunctionData({ abi: USDT!.abi, functionName: 'mint', args: [reserve, 1_000_000n * E6] }));
    const params = {
      targetLeverageBps: 20_000, maxLeverageBps: 30_000, deltaToleranceBps: 200, slippageBps: 50, priceBandBps: 100, fundingPauseE8: 0, fundingExitE8: -1_141,
      fundingTau: 302_400, minActionInterval: 60, maxReferenceAge: 3_600, maxOrderNotional: 50_000n * E6, maxWindowTurnover: 2_000_000n * E6, allocationCap: 5_000_000n * E6,
    };
    wallet = await deploy(WALLET!, [usdt, venue, stringToHex('ETH', { size: 32 }), feed, hedgeSafe, me.address, me.address, me.address, 172_800n, params]);
    await send(wallet, encodeFunctionData({ abi: WALLET!.abi, functionName: 'completeSetup' }));
    ctx = { client, chainId: await client.getChainId(), addresses: { reserve, wallet } };
  }, 60_000);

  afterAll(async () => { await node?.stop(); });

  it('checks the canonical MultiSendCallOnly by code hash', async () => {
    expect(keccak256((await client.getCode({ address: MULTISEND_CALL_ONLY }))!)).toBe(MULTISEND_CALL_ONLY_CODEHASH);
  });

  it('refuses a withdrawal over the hedge limit, and one 1-of-3 signature', async () => {
    const over = await planReserveWithdraw(ctx, 80_001n * E6);
    expect(over.refused).toBe(true);
    expect(renderSleevePlan(over, ctx.chainId)).toMatch(/over the hedge limit's room .*reserve:queue/);
    const ok = await planReserveWithdraw(ctx, 10_000n * E6);
    await expect(executeSleevePlan(client, ok, keys([owners[0]]))).rejects.toThrow(/1 of the keys given own the Safe; it needs 2/);
  });

  it('runs the path: withdrawToHedge -> fund -> withdrawToTreasury -> recapitalize, each one Safe transaction', async () => {
    const out = await planReserveWithdraw(ctx, 10_000n * E6);
    expect(out.actorKind).toBe('safe');
    expect(out.safe!.threshold).toBe(2);
    await executeSleevePlan(client, out, keys([owners[2], owners[0]]));
    expect(await bal(hedgeSafe)).toBe(10_000n * E6);

    const fund = await planFund(ctx, 10_000n * E6);
    expect(fund.tx.to).toBe(MULTISEND_CALL_ONLY);
    expect(fund.tx.operation).toBe(1);
    expect(fund.calls.map((c) => c.fn)).toEqual(['approve(address,uint256)', 'fund(uint256)']);
    expect((txBuilderJson(fund, ctx.chainId) as { transactions: unknown[] }).transactions).toHaveLength(2);
    await executeSleevePlan(client, fund, keys([owners[1], owners[2]]));
    expect(await bal(wallet)).toBe(10_000n * E6);
    expect((await readSleeve(ctx)).walletIdle).toBe(10_000n * E6);

    const home = await planWithdrawToTreasury(ctx, 'all');
    await executeSleevePlan(client, home, keys([owners[0], owners[1]]));
    expect(await bal(hedgeSafe)).toBe(10_000n * E6);

    const back = await planRecapitalize(ctx, 10_000n * E6);
    await executeSleevePlan(client, back, keys([owners[0], owners[2]]));
    expect(await bal(hedgeSafe)).toBe(0n);
    expect(await bal(reserve)).toBe(1_000_000n * E6);
  });

  it('re-plans rather than sending a stale Safe nonce', async () => {
    const a = await planFund(ctx, 1n);
    const b = await planFund(ctx, 1n);
    expect(a.safe!.safeTxHash).toBe(b.safe!.safeTxHash);
    // The hedge Safe now holds nothing: the plan is refused by its own balance check.
    expect(a.refused).toBe(true);
  });
});
