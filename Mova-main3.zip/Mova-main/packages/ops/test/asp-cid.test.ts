import { describe, expect, it } from 'vitest';
import {
  ASSOCIATION_SET_FORMAT, AspCidRefused, SNARK_SCALAR_FIELD, aspCid, associationSetCid, canonicalAssociationSet,
  isCanonicalAspCid, type AssociationSet,
} from '../src/asp-cid.js';

const ENTRYPOINT = '0x6818809EefCe719E480a7526D76bD3e561526b46';
const SET: AssociationSet = {
  chainId: 11_155_111n,
  entrypoint: ENTRYPOINT,
  root: 0x2a5bn,
  labels: [0x1234n, 7n, SNARK_SCALAR_FIELD - 1n],
};
const text = (b: Uint8Array) => new TextDecoder().decode(b);

describe('aspCid: CIDv1, raw, sha2-256, base32', () => {
  it('matches the CIDs IPFS gives the same raw blocks', () => {
    // `ipfs block put --cid-codec raw --mhtype sha2-256` of an empty file, and of "hello world" (no newline).
    expect(aspCid(new Uint8Array())).toBe('bafkreihdwdcefgh4dqkjv67uzcmw7ojee6xedzdetojuzjevtenxquvyku');
    expect(aspCid(new TextEncoder().encode('hello world'))).toBe('bafkreifzjut3te2nhyekklss27nh3k72ysco7y32koao5eei66wof36n5e');
  });
  it('is always 59 characters of the canonical form, inside the Entrypoint\'s 32 to 64', () => {
    for (let n = 0; n < 70; n += 7) {
      const cid = aspCid(new Uint8Array(n).fill(n));
      expect(cid).toHaveLength(59);
      expect(isCanonicalAspCid(cid)).toBe(true);
    }
    expect(isCanonicalAspCid('bafybeigdyrzt5sfp7udm7hu76uh7y26nf3efuylqabf3oclgtqy55fbzdi')).toBe(false); // dag-pb
    expect(isCanonicalAspCid('QmbWqxBEKC3P8tqsKc98xmWNzrzDtRLMiMPL8wBuTGsMnR')).toBe(false); // CIDv0
    expect(isCanonicalAspCid('BAFKREIHDWDCEFGH4DQKJV67UZCMW7OJEE6XEDZDETOJUZJEVTENXQUVYKU')).toBe(false); // upper case
  });
});

describe('canonicalAssociationSet', () => {
  it('writes exactly the documented bytes', () => {
    expect(text(canonicalAssociationSet(SET))).toBe([
      ASSOCIATION_SET_FORMAT,
      'chain-id 11155111',
      'entrypoint 0x6818809eefce719e480a7526d76bd3e561526b46',
      `root 0x${'2a5b'.padStart(64, '0')}`,
      'count 3',
      `0x${'1234'.padStart(64, '0')}`,
      `0x${'7'.padStart(64, '0')}`,
      `0x${(SNARK_SCALAR_FIELD - 1n).toString(16).padStart(64, '0')}`,
      '',
    ].join('\n'));
  });

  it('two honest ASPs writing the same set differently get the same CID, byte for byte', () => {
    const a = associationSetCid(SET);
    const b = associationSetCid({ chainId: 11_155_111, entrypoint: ENTRYPOINT.toLowerCase(), root: 10843n, labels: [4660n, 7n, SNARK_SCALAR_FIELD - 1n] });
    expect(b).toBe(a);
    expect(isCanonicalAspCid(a)).toBe(true);
  });

  it('anything that changes the set changes the CID: order, a label, the root, the chain, the Entrypoint', () => {
    const a = associationSetCid(SET);
    const variants: AssociationSet[] = [
      { ...SET, labels: [7n, 0x1234n, SNARK_SCALAR_FIELD - 1n] },
      { ...SET, labels: [0x1234n, 7n] },
      { ...SET, root: 0x2a5cn },
      { ...SET, chainId: 1n },
      { ...SET, entrypoint: '0x0000000000000000000000000000000000000001' },
    ];
    for (const v of variants) expect(associationSetCid(v)).not.toBe(a);
  });

  it('refuses what is not an association set, rather than write some other string', () => {
    const bad: [Partial<AssociationSet>, RegExp][] = [
      [{ labels: [] }, /at least one label/],
      [{ labels: [7n, 7n] }, /appears twice/],
      [{ labels: [SNARK_SCALAR_FIELD] }, /field element/],
      [{ labels: [-1n] }, /field element/],
      [{ root: 0n }, /zero/],
      [{ root: SNARK_SCALAR_FIELD }, /field element/],
      [{ chainId: 0n }, /chain id/],
      [{ entrypoint: '0x1234' }, /20-byte/],
    ];
    for (const [patch, why] of bad) {
      expect(() => canonicalAssociationSet({ ...SET, ...patch })).toThrow(AspCidRefused);
      expect(() => canonicalAssociationSet({ ...SET, ...patch })).toThrow(why);
    }
  });

  it('with the ASP\'s own tree, refuses labels that do not rebuild the root', () => {
    const rootOf = (labels: readonly bigint[]) => labels.reduce((x, y) => (x * 31n + y) % SNARK_SCALAR_FIELD, 1n);
    const root = rootOf(SET.labels);
    expect(associationSetCid({ ...SET, root }, rootOf)).toBe(associationSetCid({ ...SET, root }));
    expect(() => associationSetCid(SET, rootOf)).toThrow(/do not rebuild the root/);
  });
});
