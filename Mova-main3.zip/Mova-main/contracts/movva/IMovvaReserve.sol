// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/**
 * @title IMovvaReserve
 * @notice The reserve behind Movva, a BRL-pegged token backed by USDT whose dollar exposure is
 *         hedged off-chain by the issuer. Design and rationale: docs/movva.md.
 *
 * This interface is the contract between the on-chain reserve and everything that reads or
 * operates it: the ramps (its price as a band oracle), the issuer's hedge desk tooling
 * (`packages/movva`), the monitor and the wallet. Units, throughout:
 *
 *  - Movva: 18 decimals, 1e18 = R$ 1,00.
 *  - USDT: 6 decimals.
 *  - Rates: `brlPerUsdtE18` is reais per whole USDT, scaled by 1e18 (R$ 5,4012 = 5.4012e18).
 *  - Ratios and fees: basis points, 10_000 = 100%.
 */
interface IMovvaReserve {
    /*//////////////////////////////////////////////////////////////
                                  EVENTS
    //////////////////////////////////////////////////////////////*/

    event Minted(address indexed gateway, address indexed to, uint256 usdtIn, uint256 movvaOut, uint256 brlPerUsdtE18);
    event Redeemed(address indexed gateway, address indexed to, uint256 movvaIn, uint256 usdtOut, uint256 brlPerUsdtE18);
    /// @notice USDT sent to the issuer's hedge account, to meet margin when the real weakens.
    event WithdrawnToHedge(address indexed treasury, uint256 usdt, uint256 collateralRatioBpsAfter);
    /// @notice USDT added without minting: hedge gains brought back, or the issuer's own capital.
    event Recapitalized(address indexed from, uint256 usdt, uint256 collateralRatioBpsAfter);

    /*//////////////////////////////////////////////////////////////
                                   VIEWS
    //////////////////////////////////////////////////////////////*/

    function MOVVA() external view returns (address);
    function USDT() external view returns (address);

    /// @notice Reais per whole USDT from the oracle legs, scaled 1e18. Reverts if a leg is stale.
    function brlPerUsdtE18() external view returns (uint256 rate, uint64 updatedAt);

    /// @notice USDT the reserve holds, idle plus what its yield position redeems for (conservative).
    /// @dev Idle USDT counts as zero while USDT's issuer has frozen the reserve: it cannot be paid out.
    function totalUsdt() external view returns (uint256);

    /// @notice `totalUsdt()` in reais, 18 decimals. Reverts if the rate is stale.
    function reserveBrlE18() external view returns (uint256);

    /// @notice Movva in circulation, including Movva held by Privacy Pools and escrows.
    function liabilitiesBrlE18() external view returns (uint256);

    /// @notice reserve / liabilities in basis points; type(uint256).max with no supply.
    function collateralRatioBps() external view returns (uint256);

    /// @notice Reais of reserve above `targetCollateralRatioBps`, zero when at or below it. It stays in
    ///         the reserve as backing: nothing mints or distributes it.
    function surplusBrlE18() external view returns (uint256);

    /// @notice What the Movva in circulation is worth in USDT at the current rate, 6 decimals.
    /// @dev The dollar amount the issuer hedges: the reserve is long this many dollars against
    ///      real-denominated liabilities. USDT above it is surplus, and is not hedged.
    function liabilitiesUsdt() external view returns (uint256);

    function isGateway(address account) external view returns (bool);

    function mintFeeBps() external view returns (uint16);
    function redeemFeeBps() external view returns (uint16);

    function targetCollateralRatioBps() external view returns (uint16);
    function minMintCollateralRatioBps() external view returns (uint16);
    function minWithdrawCollateralRatioBps() external view returns (uint16);

    // Added with the implementation (2026-09-14). Additive: nothing above changed.
    // (14 October 2026, client decision D1: `distribute`, `previewDistribute`, `distributionFeeBps` and
    // `maxDistributionBpsPerDay` were removed with sMovva. The surplus is never minted.)

    /// @notice Most Movva that may exist, 18 decimals. Bounds `mint`.
    function supplyCap() external view returns (uint256);
    /// @notice `withdrawToHedge` rate limit: this share of `totalUsdt()` per 24 hours, refilling continuously.
    function hedgeLimitBps() external view returns (uint16);
    /// @notice True while the guardian or governor has paused `mint`. There is no pause for redemptions
    ///         (MovvaReserve, "Who can stop a redemption", says what can still stop one).
    function mintPaused() external view returns (bool);
    /// @notice True while USDT's issuer has frozen the reserve. Idle USDT then counts as zero.
    function frozenByAssetIssuer() external view returns (bool);

    // Added 2026-09-14 with Pyth's FX leg. Additive.

    /// @notice The rate as the ramps' band reads it: `brlPerUsdtE18` while the FX market trades, and its
    ///         last close, stamped current, while it is closed. For bands and display only: nothing that
    ///         moves value prices at it, and minting and redeeming wait for the market instead.
    function bandBrlPerUsdtE18() external view returns (uint256 rate, uint64 updatedAt);

    /// @notice Movva a gateway's `mint(usdtIn)` would deliver now, and the fee minted beside it.
    ///         Ignores pauses, caps, freezes and the ratio floor; use it to set `minMovvaOut`.
    function previewMint(uint256 usdtIn) external view returns (uint256 movvaOut, uint256 fee);
    /// @notice USDT `redeem(movvaIn)` would pay now, and the Movva fee. Ignores liquidity.
    function previewRedeem(uint256 movvaIn) external view returns (uint256 usdtOut, uint256 fee);
    /// @notice USDT `withdrawToHedge` may send now under the rate limit, before the ratio floor.
    function hedgeWithdrawable() external view returns (uint256);
    /// @notice The only address `withdrawToHedge` pays, and the role allowed to call it.
    function hedgeTreasury() external view returns (address);
    function treasurer() external view returns (address);

    /*//////////////////////////////////////////////////////////////
                                  ACTIONS
    //////////////////////////////////////////////////////////////*/

    /// @notice Gateway only: deposit USDT, receive Movva worth it at the oracle rate, less the mint fee.
    function mint(uint256 usdtIn, address to, uint256 minMovvaOut) external returns (uint256 movvaOut);

    /// @notice Gateway only: burn Movva, receive USDT worth min(1, collateral ratio) of it, less the redeem fee.
    function redeem(uint256 movvaIn, address to, uint256 minUsdtOut) external returns (uint256 usdtOut);

    /// @notice Treasurer only, bounded: send USDT to the hedge treasury without breaching the withdraw floor.
    function withdrawToHedge(uint256 usdt) external;

    /// @notice Anyone: add USDT without minting.
    function recapitalize(uint256 usdt) external;
}
