// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Governed} from "./utils/Governed.sol";
import {EscrowStub} from "./utils/PermissionlessRegistryKit.sol";
import {FiatEscrow} from "../ramp/FiatEscrow.sol";
import {OffRampEscrow} from "../ramp/OffRampEscrow.sol";
import {LPRegistry} from "../ramp/LPRegistry.sol";
import {PermissionlessLPRegistry} from "../ramp/PermissionlessLPRegistry.sol";
import {IAttestorVerifier} from "../ramp/IAttestorVerifier.sol";
import {IPriceOracle} from "../ramp/IPriceOracle.sol";
import {RulingLib} from "../ramp/RulingLib.sol";
import {Movva} from "../movva/Movva.sol";

contract PlrVerifier is IAttestorVerifier {
    mapping(bytes32 => Payment) internal canned;
    mapping(bytes32 => bool) internal bound;

    function setProof(bytes32 id, Payment memory p) external {
        canned[id] = p;
        bound[id] = true;
    }

    function verifyPayment(bytes32 id, bytes calldata) external view returns (Payment memory) {
        require(bound[id], "proof not bound to this position");
        return canned[id];
    }

    function attestorKind() external pure returns (string memory) {
        return "mock/permissionless";
    }

    function provesBankSession() external pure returns (bool) {
        return true;
    }
}

contract PlrOracle is IPriceOracle {
    function brlCentsPerUnit() external view returns (uint256, uint64) {
        return (1_500_000, uint64(block.timestamp)); // 1 ETH = R$ 15.000,00
    }
}

/// Entrypoint and pool in one, only so the escrow has nonzero addresses; DIRECT deliveries never reach it.
contract PlrPool {
    function assetConfig(address) external view returns (address, uint256, uint256, uint256) {
        return (address(this), 0, 0, 0);
    }
}

/**
 * The UNCHANGED FiatEscrow and OffRampEscrow, deployed against PermissionlessLPRegistry: an LP joins by bonding MOVVA,
 * posts an offer, a taker's order settles by proof, the LP claims a sale and does not pay, the arbitrator's REFUND
 * slashes its whole bond in the ruling's own transaction, the escrows' suspension lever closes its standing offer, and
 * an LP that leaves waits out the unbonding period and its last position before its bond comes back. Plus: a bank
 * transaction id spent under the old (curated) registry settles nothing here, and an exit cannot outrun a dispute.
 */
contract PermissionlessRampIntegrationTest is Governed {
    Movva movva;
    LPRegistry old;
    EscrowStub oldEscrow;
    PermissionlessLPRegistry reg;
    FiatEscrow onramp;
    OffRampEscrow offramp;
    PlrVerifier verifier;
    PlrOracle oracle;
    PlrPool pool;

    address governor = makeAddr("escrow governor");
    address lp = makeAddr("lp");
    address taker = makeAddr("taker");
    address payout = makeAddr("payout");
    address seller = makeAddr("seller");
    address refund = makeAddr("refund");
    address stranger = makeAddr("stranger");
    uint256 arbKey = 0xA2B;

    uint256 constant MIN_BOND = 5_000e18;
    uint256 constant UNBONDING = DISPUTE_TIMEOUT + 6 days; // 30 + 1 ruling delay + 4 margin + 1
    bytes32 constant LP_PIX = keccak256("lp pix commitment");
    bytes32 constant SELLER_PIX = keccak256("seller pix commitment");
    bytes32 constant SPENT_ON_OLD_RAMP = keccak256("a PIX that settled an order on the old ramp");
    uint16 constant PIX_MASK = uint16(1 << uint8(IAttestorVerifier.Rail.PIX));

    function setUp() public {
        vm.warp(1_800_000_000);
        movva = new Movva(); // this test is its reserve: it mints the LPs' bonds

        // The registry being replaced, with a bank transaction it has already spent.
        old = new LPRegistry(governor, DELAY);
        oldEscrow = new EscrowStub(address(old), uint64(DISPUTE_TIMEOUT));
        vm.startPrank(governor);
        old.setEscrow(address(oldEscrow), true);
        old.completeSetup();
        vm.stopPrank();
        assertTrue(oldEscrow.consume(SPENT_ON_OLD_RAMP));

        oracle = new PlrOracle();
        verifier = new PlrVerifier();
        pool = new PlrPool();
        reg = new PermissionlessLPRegistry(address(movva), address(old), MIN_BOND, UNBONDING);
        onramp = new FiatEscrow(
            address(oracle),
            address(reg),
            address(pool),
            address(pool),
            500,
            governor,
            DELAY,
            DISPUTE_TIMEOUT
        );
        offramp =
            new OffRampEscrow(address(oracle), address(reg), 500, governor, DELAY, DISPUTE_TIMEOUT);
        reg.bindEscrows(address(onramp), address(offramp));

        vm.startPrank(governor);
        onramp.setVerifier(address(verifier), true);
        offramp.setVerifier(address(verifier), true);
        onramp.setArbitrator(vm.addr(arbKey), true);
        offramp.setArbitrator(vm.addr(arbKey), true);
        onramp.completeSetup();
        offramp.completeSetup();
        vm.stopPrank();
        vm.warp(block.timestamp + 1); // the arbitrator predates every dispute

        movva.mint(lp, 100_000e18);
        vm.prank(lp);
        movva.approve(address(reg), type(uint256).max);
        vm.deal(lp, 10 ether);
        vm.deal(seller, 10 ether);
    }

    /*//////////////////////////////////////////////////////////////
                                HELPERS
    //////////////////////////////////////////////////////////////*/

    function _bond(address who) internal view returns (uint256 amount) {
        (amount,,,,,) = reg.bonds(who);
    }

    function _exposure(address who) internal view returns (uint256 e) {
        (, e,,,,) = reg.bonds(who);
    }

    function _post(uint256 amount) internal returns (bytes32) {
        vm.prank(lp);
        return onramp.postOffer{value: amount}(
            address(0), amount, 1_500_000, LP_PIX, 0.01 ether, amount, address(verifier), PIX_MASK
        );
    }

    function _lock(bytes32 offerId, uint256 amount) internal returns (bytes32) {
        vm.prank(taker);
        return onramp.lockOrder(offerId, amount, FiatEscrow.Delivery.DIRECT, payout, 0);
    }

    function _pay(bytes32 id, bytes32 bankTxId, bytes32 payee, uint256 cents) internal {
        verifier.setProof(
            id,
            IAttestorVerifier.Payment({
                bankTxId: bankTxId,
                payeeKeyHash: payee,
                payerRef: bytes32(uint256(1)),
                amountBrlCents: cents,
                paidAt: uint64(block.timestamp),
                rail: IAttestorVerifier.Rail.PIX
            })
        );
    }

    function _openSale(uint256 amount, uint256 cents) internal returns (bytes32) {
        vm.prank(seller);
        return offramp.openSale{value: amount}(
            address(0), amount, cents, SELLER_PIX, address(verifier), PIX_MASK, refund
        );
    }

    function _signed(address escrow, bytes32 id, string memory outcome)
        internal
        view
        returns (RulingLib.Ruling memory r, bytes memory sig)
    {
        r = RulingLib.Ruling({
            orderId: id,
            outcome: outcome,
            evidenceRoot: keccak256("evidence"),
            rationale: "the LP's bank statement shows no payment to the seller",
            ruledAt: uint64(block.timestamp),
            byDefault: false
        });
        bytes32 structHash = keccak256(
            abi.encode(
                keccak256(
                    "Ruling(bytes32 orderId,address escrow,string outcome,bytes32 evidenceRoot,string rationale,uint64 ruledAt,bool byDefault)"
                ),
                r.orderId,
                escrow,
                keccak256(bytes(r.outcome)),
                r.evidenceRoot,
                keccak256(bytes(r.rationale)),
                r.ruledAt,
                r.byDefault
            )
        );
        bytes32 domain = keccak256(
            abi.encode(
                keccak256(
                    "EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)"
                ),
                keccak256("PrivacyPoolsBRL-Dispute"),
                keccak256("1"),
                block.chainid,
                escrow
            )
        );
        (uint8 v, bytes32 rr, bytes32 ss) =
            vm.sign(arbKey, keccak256(abi.encodePacked("\x19\x01", domain, structHash)));
        sig = abi.encodePacked(rr, ss, v);
    }

    /*//////////////////////////////////////////////////////////////
                        THE WHOLE LIFE OF AN LP
    //////////////////////////////////////////////////////////////*/

    function test_JoinOfferOrderSettleDisputeLostSlashExitUnbondWithdraw() public {
        // 1. Join: R$ 20.000,00 of MOVVA is R$ 20.000,00 of credit. No admin, no schedule, no delay.
        vm.prank(lp);
        reg.join(20_000e18);
        assertEq(reg.capOf(lp), 2_000_000);

        // 2. Offer: 1 ETH at R$ 15.000,00 reserves R$ 15.000,00 of that credit.
        bytes32 offerId = _post(1 ether);
        assertEq(_exposure(lp), 1_500_000);
        assertEq(reg.reservedBy(address(onramp), lp), 1_500_000);

        // 3. Order and settlement by proof.
        bytes32 orderId = _lock(offerId, 0.5 ether);
        _pay(orderId, keccak256("pix e2e 1"), LP_PIX, 750_000);
        onramp.releaseWithProof(orderId, "");
        assertEq(payout.balance, 0.5 ether);
        assertEq(_exposure(lp), 750_000, "the settled half's credit is back");
        (,, uint256 settled,, uint32 settlements,) = reg.bonds(lp);
        assertEq(settled, 750_000);
        assertEq(settlements, 1);

        // 4. The LP claims a sale on the off-ramp and never pays the seller.
        bytes32 saleId = _openSale(0.1 ether, 150_000);
        vm.prank(lp);
        offramp.claimSale(saleId);
        assertEq(_exposure(lp), 900_000, "one credit across both escrows");
        vm.warp(block.timestamp + 20 minutes);
        vm.prank(seller);
        offramp.raiseDispute(saleId, "no PIX arrived");

        // 5. Dispute lost: the arbitrator's REFUND, posted then executed after RULING_DELAY. The bond goes in the
        //    executing transaction itself - no step by anyone after the ruling.
        (RulingLib.Ruling memory r, bytes memory sig) = _signed(address(offramp), saleId, "REFUND");
        offramp.resolveDispute(saleId, r, sig);
        assertEq(_bond(lp), 20_000e18, "posting the ruling moves nothing");
        vm.warp(block.timestamp + offramp.RULING_DELAY());
        vm.prank(stranger); // anyone may carry the ruling
        offramp.resolveDispute(saleId, r, sig);
        assertEq(refund.balance, 0.1 ether, "the seller's crypto came back");
        assertEq(_bond(lp), 0, "the whole bond is gone");
        assertEq(reg.totalSlashed(), 20_000e18);
        assertEq(reg.capOf(lp), 0);
        assertEq(movva.balanceOf(address(reg)), 20_000e18, "locked in the registry for ever");
        assertEq(_exposure(lp), 750_000, "the on-ramp offer is still live");

        // 6. The escrows' suspension lever: no new order, and anyone may close the standing offer - to the LP.
        vm.prank(taker);
        vm.expectRevert(FiatEscrow.LPNotEligible.selector);
        onramp.lockOrder(offerId, 0.1 ether, FiatEscrow.Delivery.DIRECT, payout, 0);
        uint256 lpEth = lp.balance;
        vm.prank(stranger);
        onramp.closeOffer(offerId);
        assertEq(lp.balance - lpEth, 0.5 ether);
        assertEq(_exposure(lp), 0);

        // 7. Rejoin with a fresh bond, quote again, then exit.
        vm.prank(lp);
        reg.join(10_000e18);
        bytes32 second = _post(0.5 ether);
        vm.prank(lp);
        reg.requestExit();
        assertEq(reg.capOf(lp), 0, "exit stops new business at once");
        vm.prank(taker);
        vm.expectRevert(FiatEscrow.LPNotEligible.selector);
        onramp.lockOrder(second, 0.1 ether, FiatEscrow.Delivery.DIRECT, payout, 0);
        bytes32 sale2 = _openSale(0.1 ether, 150_000);
        vm.prank(lp);
        vm.expectRevert(OffRampEscrow.LPNotEligible.selector);
        offramp.claimSale(sale2);
        vm.prank(stranger);
        onramp.closeOffer(second);
        assertEq(_exposure(lp), 0);

        // 8. Unbond, withdraw.
        uint256 from = reg.withdrawableFrom(lp);
        vm.prank(lp);
        vm.expectRevert(
            abi.encodeWithSelector(PermissionlessLPRegistry.StillUnbonding.selector, from)
        );
        reg.withdraw();
        vm.warp(from);
        uint256 before = movva.balanceOf(lp);
        vm.prank(lp);
        reg.withdraw();
        assertEq(movva.balanceOf(lp) - before, 10_000e18);
        assertEq(reg.totalBonded(), 0);
        assertEq(movva.balanceOf(address(reg)), 20_000e18, "only the slash remains");
    }

    /// The LP disputes an order a taker paid, then asks to leave. The bond cannot leave while that dispute can still
    /// be lost, and by the end of the unbonding period the dispute is past its deadline: it can only be expired, and
    /// expiring an LP's own dispute is a lost dispute.
    function test_AnExitCannotOutrunALiveDispute() public {
        vm.prank(lp);
        reg.join(10_000e18);
        bytes32 offerId = _post(0.5 ether);
        bytes32 orderId = _lock(offerId, 0.2 ether);
        vm.prank(lp);
        onramp.raiseDispute(orderId, "payment reversed (MED)");
        vm.prank(lp);
        reg.requestExit();
        vm.prank(stranger);
        onramp.closeOffer(offerId); // frees the free liquidity; the disputed order stays in the offer
        assertEq(_exposure(lp), 300_000, "the LP's own dispute keeps its credit reserved");

        vm.warp(reg.withdrawableFrom(lp));
        vm.prank(lp);
        vm.expectRevert(
            abi.encodeWithSelector(PermissionlessLPRegistry.ExposureLive.selector, 300_000)
        );
        reg.withdraw();

        assertGt(block.timestamp, onramp.disputedAt(orderId) + onramp.DISPUTE_TIMEOUT());
        vm.prank(stranger);
        onramp.expireDispute(orderId);
        assertEq(_bond(lp), 0, "the LP's unanswered dispute cost it the bond");
        assertEq(reg.totalSlashed(), 10_000e18);

        vm.prank(stranger);
        onramp.closeOffer(offerId); // the expired order's liquidity went back to the offer: sweep it to the LP
        assertEq(_exposure(lp), 0);
        uint256 before = movva.balanceOf(lp);
        vm.prank(lp);
        reg.withdraw();
        assertEq(movva.balanceOf(lp), before, "nothing left to withdraw, and the exit is over");
    }

    function test_ATakersDisputeCostsTheLPNothing() public {
        vm.prank(lp);
        reg.join(10_000e18);
        bytes32 offerId = _post(0.5 ether);
        bytes32 orderId = _lock(offerId, 0.2 ether);
        vm.prank(taker);
        onramp.raiseDispute(orderId, "I paid");
        vm.warp(block.timestamp + DISPUTE_TIMEOUT);
        onramp.expireDispute(orderId);
        assertEq(_bond(lp), 10_000e18);
        assertEq(reg.totalSlashed(), 0);
    }

    function test_AnHonestSaleSettlesAndCostsNoBond() public {
        vm.prank(lp);
        reg.join(10_000e18);
        bytes32 saleId = _openSale(0.1 ether, 150_000);
        vm.prank(lp);
        offramp.claimSale(saleId);
        _pay(saleId, keccak256("pix e2e sale"), SELLER_PIX, 150_000);
        uint256 before = lp.balance;
        offramp.settleWithProof(saleId, "");
        assertEq(lp.balance - before, 0.1 ether);
        assertEq(_exposure(lp), 0);
        assertEq(_bond(lp), 10_000e18);
        (,, uint256 settled,,,) = reg.bonds(lp);
        assertEq(settled, 150_000);
    }

    /*//////////////////////////////////////////////////////////////
                    BANK TRANSACTION IDS ACROSS REGISTRIES
    //////////////////////////////////////////////////////////////*/

    function test_ABankTxIdSpentUnderTheOldRegistrySettlesNothingHere() public {
        vm.prank(lp);
        reg.join(10_000e18);
        assertTrue(
            onramp.usedBankTxId(SPENT_ON_OLD_RAMP),
            "the escrow reads the registry's view, predecessor and all"
        );
        assertTrue(offramp.usedBankTxId(SPENT_ON_OLD_RAMP));

        bytes32 offerId = _post(0.5 ether);
        bytes32 orderId = _lock(offerId, 0.2 ether);
        _pay(orderId, SPENT_ON_OLD_RAMP, LP_PIX, 300_000);
        vm.expectRevert(FiatEscrow.ReceiptReplayed.selector);
        onramp.releaseWithProof(orderId, "");

        bytes32 saleId = _openSale(0.1 ether, 150_000);
        vm.prank(lp);
        offramp.claimSale(saleId);
        _pay(saleId, SPENT_ON_OLD_RAMP, SELLER_PIX, 150_000);
        vm.expectRevert(OffRampEscrow.ReceiptReplayed.selector);
        offramp.settleWithProof(saleId, "");

        // A fresh id settles; spent here, it then settles nothing on the other escrow either.
        bytes32 fresh = keccak256("pix e2e fresh");
        _pay(orderId, fresh, LP_PIX, 300_000);
        onramp.releaseWithProof(orderId, "");
        _pay(saleId, fresh, SELLER_PIX, 150_000);
        vm.expectRevert(OffRampEscrow.ReceiptReplayed.selector);
        offramp.settleWithProof(saleId, "");
        assertTrue(reg.spentHere(fresh));
        assertFalse(
            old.usedBankTxId(fresh), "the old registry does not see this one: see docs, Cutover"
        );
    }

    /*//////////////////////////////////////////////////////////////
                                 SIZES
    //////////////////////////////////////////////////////////////*/

    /// `forge test` does not enforce EIP-170 (HyperCoreContractSize.t.sol), so this does. The limit is inclusive:
    /// FiatEscrow, frozen, compiles to exactly 24,576 bytes - 0 to spare, unchanged by the new registry.
    function test_EveryContractFitsEip170AndEip3860() public view {
        assertLe(address(reg).code.length, 24_576, "PermissionlessLPRegistry runtime");
        assertLe(address(onramp).code.length, 24_576, "FiatEscrow runtime");
        assertLe(address(offramp).code.length, 24_576, "OffRampEscrow runtime");
        assertLe(
            type(PermissionlessLPRegistry).creationCode.length,
            49_152,
            "PermissionlessLPRegistry initcode"
        );
        assertLe(type(FiatEscrow).creationCode.length, 49_152, "FiatEscrow initcode");
        assertLe(type(OffRampEscrow).creationCode.length, 49_152, "OffRampEscrow initcode");
    }
}
