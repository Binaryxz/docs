// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {MovvaBase} from "./MovvaReserve.t.sol";
import {MockPriceSource} from "./MovvaBreaker.t.sol";
import {Movva} from "../movva/Movva.sol";
import {MovvaReserve} from "../movva/MovvaReserve.sol";
import {DivergenceBreaker} from "../movva/DivergenceBreaker.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";

/**
 * M1 written security review (14 October 2026), the MOVVA issuer contracts.
 *
 * Every test here PASSES on the current code. Each either demonstrates a behaviour the review reports
 * as a finding (named M1-MOVVA-n in the report), or pins a property the review relied on ("HELD").
 *
 * The reserve is built in the M1 end-state shape: no savings path at all (client decision D1, 14 October
 * 2026, removed sMovva and `distribute` from the reserve), no yield vault (the rail sets none), one
 * gateway, setup complete; then, where the test says so, the
 * guardian and the governor sent to 0x...dEaD exactly as `deploy-movva-rail.ts --finalize` does.
 */
contract ReviewM1MovvaTest is MovvaBase {
    address constant DEAD = 0x000000000000000000000000000000000000dEaD;

    /// A fresh reserve in the M1 shape (no vault), replacing the base's.
    function _m1Reserve(address breaker) internal {
        MovvaReserve.Config memory c = _config();
        c.breaker = breaker;
        reserve = new MovvaReserve(c);
        movva = Movva(reserve.MOVVA());
        vm.startPrank(gov);
        reserve.setGateway(gateway, true);
        reserve.completeSetup();
        vm.stopPrank();
        vm.startPrank(gateway);
        usdt.approve(address(reserve), type(uint256).max);
        movva.approve(address(reserve), type(uint256).max);
        vm.stopPrank();
        assertEq(address(reserve.yieldVault()), address(0));
    }

    /// `--finalize`, as the rail script does it: guardian first, then the governor.
    function _finalize() internal {
        vm.startPrank(gov);
        reserve.setGuardian(DEAD);
        reserve.transferGovernor(DEAD);
        vm.stopPrank();
        assertEq(reserve.governor(), DEAD);
        assertEq(reserve.guardian(), DEAD);
    }

    /// From rest at 108%: 1,000,000 USDT minted against, 80,000 recapitalized.
    function _atRest() internal {
        _mint(1_000_000 * U);
        vm.prank(gateway);
        reserve.recapitalize(80_000 * U);
    }

    /*//////////////////////////////////////////////////////////////
          M1-MOVVA-1: a queued hedge withdrawal outlives everything
    //////////////////////////////////////////////////////////////*/

    /// A request queued before `--finalize` survives revoking the treasurer AND renouncing the governor,
    /// has no expiry, and any stranger can execute it a year later. Its destination is the hedge
    /// treasury of record (not the stranger), and the 103% floor still binds - so this is low severity -
    /// but `--finalize` does not look for such requests, and nothing after it can stop one.
    function test_M1_1_AQueuedHedgeRequestSurvivesRevocationAndRenunciationAndNeverExpires() public {
        _m1Reserve(address(0));
        _atRest();

        vm.prank(treasurer);
        uint256 id = reserve.queueHedgeWithdrawal(40_000 * U);

        // The strongest brakes there are, both instant: revoke the treasurer, then renounce.
        vm.prank(gov);
        reserve.setTreasurer(address(0));
        _finalize();
        assertEq(reserve.treasurer(), address(0));
        vm.prank(treasurer);
        vm.expectRevert(MovvaReserve.NotTreasurer.selector);
        reserve.withdrawToHedge(1 * U);

        // A year on (DelayedGovernance's own scheduled changes expire after 14 days; this does not).
        _warp(365 days);
        uint256 before = usdt.balanceOf(hedge);
        vm.prank(stranger);
        reserve.executeHedgeWithdrawal(id);
        assertEq(usdt.balanceOf(hedge) - before, 40_000 * U, "paid in full, a year later, by a stranger");
        assertGe(reserve.collateralRatioBps(), reserve.minWithdrawCollateralRatioBps(), "the floor still binds");
    }

    /*//////////////////////////////////////////////////////////////
       M1-MOVVA-2 (SRM1-7), fixed: a tripping breaker source that dies
       stops counting for redemptions after DEAD_AFTER
    //////////////////////////////////////////////////////////////*/

    /// With the mainnet default (a breaker, HALTS_REDEEM=true), one tripping source that is retired -
    /// a Chainlink BRL/USD feed deprecated, a BRL pool drained below MIN_LIQUIDITY or migrated - used
    /// to halt redeem, withdrawToHedge and executeHedgeWithdrawal for ever, with every USDT locked.
    /// Now: anyone pokes the breaker, which records the claim; for DEAD_AFTER (DeployMovva: 30 days)
    /// everything still halts; after it redemptions price without the dead source. Mint and hedge
    /// withdrawals stay halted on it (the reserve winds down to redemptions), and recapitalize works.
    function test_M1_2_Fixed_ADeadTrippingSourceNoLongerLocksExits() public {
        MockPriceSource src = new MockPriceSource();
        src.set(FX * 1e12); // in band with Chainlink $1.00 x R$ 5,40
        DivergenceBreaker.SourceConfig[] memory cfg = new DivergenceBreaker.SourceConfig[](1);
        cfg[0] = DivergenceBreaker.SourceConfig(src, true);
        DivergenceBreaker brk = new DivergenceBreaker(300, true, 30 days, cfg); // DeployMovva's defaults
        _m1Reserve(address(brk));
        _atRest();
        _finalize();

        vm.prank(treasurer);
        uint256 id = reserve.queueHedgeWithdrawal(10_000 * U);

        src.fail(); // the source is retired: it reverts from now on
        vm.prank(stranger);
        brk.poke();
        _warp(30 days - 1);
        vm.prank(gateway);
        vm.expectRevert(abi.encodeWithSelector(DivergenceBreaker.SourceUnavailable.selector, 0));
        reserve.redeem(1e18, gateway, 0);

        _warp(365 days);
        uint256 before = usdt.balanceOf(gateway);
        _redeem(1_000e18);
        assertGt(usdt.balanceOf(gateway), before, "exits are open again, with the governor renounced");
        vm.prank(treasurer);
        vm.expectRevert(abi.encodeWithSelector(DivergenceBreaker.SourceUnavailable.selector, 0));
        reserve.withdrawToHedge(1 * U);
        vm.expectRevert(abi.encodeWithSelector(DivergenceBreaker.SourceUnavailable.selector, 0));
        reserve.executeHedgeWithdrawal(id);
        vm.prank(gateway);
        vm.expectRevert(abi.encodeWithSelector(DivergenceBreaker.SourceUnavailable.selector, 0));
        reserve.mint(1 * U, gateway, 0);
        vm.prank(gateway);
        reserve.recapitalize(1 * U);
        assertTrue(reserve.breakerTripped(), "the mint verdict: still tripped");
    }

    /*//////////////////////////////////////////////////////////////
       M1-MOVVA-3 (SRM1-19), fixed by removal: the savings path is gone
    //////////////////////////////////////////////////////////////*/

    /// SRM1-19 was `previewDistribute` reporting a mint that `distribute` refused (`NoSavings`). Both,
    /// with `savings`, `setSavings` and the distribution fee and cap, were removed with sMovva (client
    /// decision D1). A call to either now falls through the dispatcher: it reverts with no data. The
    /// surplus above target stays in the reserve, and nothing mints it.
    function test_M1_3_FixedByRemoval_NoPreviewAndNoDistribution() public {
        _m1Reserve(address(0));
        _mint(1_000_000 * U);
        vm.prank(gateway);
        reserve.recapitalize(200_000 * U); // 120%: well above the 108% target
        _warp(1 days);
        uint256 supply = movva.totalSupply();
        string[3] memory gone = ["previewDistribute()", "distribute()", "savings()"];
        for (uint256 i; i < gone.length; ++i) {
            (bool ok, bytes memory ret) = address(reserve).call(abi.encodeWithSignature(gone[i]));
            assertFalse(ok, gone[i]);
            assertEq(ret.length, 0, "no such function");
        }
        assertGt(reserve.surplusBrlE18(), 0, "the surplus is there");
        assertEq(movva.totalSupply(), supply, "and nothing minted it");
    }

    /*//////////////////////////////////////////////////////////////
       M1-MOVVA-4 (SRM1-20, informational, pre-finalize only): the max-age
       lever is closed; removing every gateway remains
    //////////////////////////////////////////////////////////////*/

    /// A max age of one second was classed as risk-reducing (instant) and froze every redemption, with
    /// the undo waiting the delay. Now max ages have floors: a day for USDT/USD, 15 minutes for FX.
    /// Tightening to the floors is still instant and leaves a live deployment's legs fresh. Removing
    /// every gateway (instant) still stops redemptions before finalize; after it nobody can.
    function test_M1_4_Fixed_AMaxAgeCanNoLongerFreezeRedemptions() public {
        _m1Reserve(address(0));
        _atRest();
        vm.startPrank(gov);
        vm.expectRevert(MovvaReserve.BadMaxAge.selector);
        reserve.setOracle(address(feed), address(fx), 1, 1);
        vm.expectRevert(MovvaReserve.BadMaxAge.selector);
        reserve.setOracle(address(feed), address(fx), 1 days - 1, FX_MAX_AGE);
        vm.expectRevert(MovvaReserve.BadMaxAge.selector);
        reserve.setOracle(address(feed), address(fx), USDT_USD_MAX_AGE, 15 minutes - 1);
        reserve.setOracle(address(feed), address(fx), 1 days, 15 minutes); // the floors: instant
        vm.stopPrank();
        vm.warp(block.timestamp + 10 minutes); // no leg re-published: both still inside the floors
        _redeem(1e18);

        // What remains before finalize: removing every gateway, instantly.
        vm.prank(gov);
        reserve.setGateway(gateway, false);
        vm.prank(gateway);
        vm.expectRevert(MovvaReserve.NotGateway.selector);
        reserve.redeem(1e18, gateway, 0);
    }

    /*//////////////////////////////////////////////////////////////
                    HELD: properties the review relied on
    //////////////////////////////////////////////////////////////*/

    /// A change scheduled before `--finalize` can never be executed after it: `execute` is governor-only.
    function test_Held_AChangeScheduledBeforeFinalizeIsDeadAfterIt() public {
        _m1Reserve(address(0));
        address newGateway = makeAddr("new gateway");
        bytes memory call = abi.encodeCall(MovvaReserve.setGateway, (newGateway, true));
        vm.prank(gov);
        reserve.schedule(call);
        _finalize();
        vm.warp(block.timestamp + DELAY + 1);
        address[3] memory callers = [stranger, gov, treasurer];
        for (uint256 i; i < callers.length; ++i) {
            vm.prank(callers[i]);
            vm.expectRevert(DelayedGovernance.NotGovernor.selector);
            reserve.execute(call);
        }
        assertFalse(reserve.isGateway(newGateway));
        assertGt(reserve.readyAt(keccak256(call)), 0, "still recorded, but unexecutable");
    }

    /// After `--finalize`: nobody can pause minting, add a gateway, or move USDT out by governance.
    function test_Held_AfterFinalizeNoGovernancePathIsOpen() public {
        _m1Reserve(address(0));
        _atRest();
        _finalize();
        address[3] memory callers = [stranger, gov, guardian];
        for (uint256 i; i < callers.length; ++i) {
            vm.startPrank(callers[i]);
            vm.expectRevert(MovvaReserve.NotGuardianOrGovernor.selector);
            reserve.pauseMint();
            vm.expectRevert(DelayedGovernance.NotGovernor.selector);
            reserve.setGateway(stranger, true);
            vm.expectRevert(DelayedGovernance.NotGovernor.selector);
            reserve.setHedgeTreasury(stranger);
            vm.expectRevert(DelayedGovernance.NotGovernor.selector);
            reserve.pullFromVault(1);
            vm.expectRevert(DelayedGovernance.NotGovernor.selector);
            reserve.schedule(abi.encodeCall(MovvaReserve.setYieldVault, (stranger)));
            vm.stopPrank();
        }
        assertFalse(reserve.mintPaused());
    }
}
