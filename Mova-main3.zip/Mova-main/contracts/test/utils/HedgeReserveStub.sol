// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";

/**
 * MovvaReserve's hedge path and nothing else, for the funding-path CLI's anvil test
 * (packages/ops/test/hedge-sleeve.test.ts): the same function names, the same "only the treasurer,
 * only to the hedge treasury, only within the limit" rules, none of the oracle or token machinery.
 * The fork rehearsal (scripts/hedge-sleeve-rehearsal.ts) runs the real reserve.
 */
contract HedgeReserveStub {
    using SafeERC20 for IERC20;

    IERC20 public immutable USDT;
    address public treasurer;
    address public hedgeTreasury;
    uint16 public hedgeLimitBps = 800;
    uint64 public constant HEDGE_QUEUE_DELAY = 1 days;
    uint256 public usedToday;

    constructor(IERC20 usdt, address treasurer_, address hedgeTreasury_) {
        (USDT, treasurer, hedgeTreasury) = (usdt, treasurer_, hedgeTreasury_);
    }

    function totalUsdt() public view returns (uint256) {
        return USDT.balanceOf(address(this));
    }

    function hedgeWithdrawable() public view returns (uint256) {
        uint256 limit = (totalUsdt() * hedgeLimitBps) / 10_000;
        return limit > usedToday ? limit - usedToday : 0;
    }

    function withdrawToHedge(uint256 usdt) external {
        require(msg.sender == treasurer, "NotTreasurer");
        require(usdt <= hedgeWithdrawable(), "HedgeLimitExceeded");
        usedToday += usdt;
        USDT.safeTransfer(hedgeTreasury, usdt);
    }

    function recapitalize(uint256 usdt) external {
        USDT.safeTransferFrom(msg.sender, address(this), usdt);
    }
}
