// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {HedgeSleeveBase, HedgeFeed} from "./utils/HedgeSleeveBase.sol";
import {TetherLike} from "./ERC4626Adapter.t.sol";
import {SimHedgeVenue} from "../hedge/SimHedgeVenue.sol";
import {HedgeSubWallet} from "../hedge/HedgeSubWallet.sol";

/// Drives the sleeve with everything every role may do, prices and the operator's knobs included.
contract HedgeSleeveHandler is Test {
    TetherLike immutable usdt;
    HedgeFeed immutable venueFeed;
    HedgeFeed immutable refFeed;
    SimHedgeVenue immutable venue;
    HedgeSubWallet immutable wallet;
    address immutable keeper;
    address immutable treasury;
    address immutable operator;
    address immutable stranger;
    bytes32 constant ETH = "ETH";

    uint256 public treasuryMinted;
    uint256 public treasuryFunded;
    uint256 public treasuryReceived;
    /// Set if a keeper step ever grew the short past max leverage.
    bool public keeperOverLevered;
    uint256 public keeperSteps;

    constructor(
        TetherLike u,
        HedgeFeed vf,
        HedgeFeed rf,
        SimHedgeVenue v,
        HedgeSubWallet w,
        address k,
        address t,
        address o,
        address s
    ) {
        (usdt, venueFeed, refFeed, venue, wallet, keeper, treasury, operator, stranger) =
            (u, vf, rf, v, w, k, t, o, s);
    }

    function _short() internal view returns (uint256) {
        int256 x = venue.perpPosition(address(wallet), ETH).size;
        return x < 0 ? uint256(-x) : 0;
    }

    function _tick(uint256 dt) internal {
        vm.warp(block.timestamp + dt);
        venueFeed.set(venueFeed.answer(), block.timestamp);
        refFeed.set(refFeed.answer(), block.timestamp);
    }

    function rebalance(uint256 dt) external {
        _tick(bound(dt, 61, 6 hours));
        uint256 before = _short();
        vm.prank(keeper);
        try wallet.rebalance() {
            ++keeperSteps;
            if (_short() > before) {
                int256 eq = venue.marginAccount(address(wallet)).equity;
                uint256 ntl = (_short() * venue.prices(ETH).mark) / 1e30;
                if (eq <= 0 || (ntl * 10_000) / uint256(eq) > 30_000) keeperOverLevered = true;
            }
        } catch {}
    }

    function harvest(uint256 dt) external {
        _tick(bound(dt, 61, 1 days));
        vm.prank(keeper);
        try wallet.harvest() {} catch {}
    }

    function deleverage() external {
        vm.prank(stranger);
        try wallet.deleverage() {} catch {}
    }

    function liquidate() external {
        vm.prank(stranger);
        try venue.liquidate(address(wallet)) {} catch {}
    }

    function movePrice(uint256 bps, bool up) external {
        uint256 b = bound(bps, 0, 1_500);
        int256 px = venueFeed.answer();
        px = up ? (px * int256(10_000 + b)) / 10_000 : (px * int256(10_000 - b)) / 10_000;
        if (px < 1_000e8 || px > 6_000e8) return;
        venueFeed.set(px, block.timestamp);
        refFeed.set(px, block.timestamp);
    }

    /// The operator's knobs, each within the simulator's hard bounds. Funding is the full range;
    /// basis and costs mostly stay where the keeper can still trade, so the run explores trading.
    function operatorFunding(int256 rate) external {
        vm.prank(operator);
        venue.setFundingRate(ETH, bound(rate, -5e14, 5e14));
    }

    function operatorBasis(int16 markBasis, int16 spotBasis) external {
        vm.prank(operator);
        venue.setBasis(ETH, int16(bound(markBasis, -150, 150)), int16(bound(spotBasis, -150, 150)));
    }

    function operatorFees(uint16 spread, uint16 fee) external {
        vm.prank(operator);
        venue.setFees(uint16(bound(spread, 0, 60)), uint16(bound(fee, 0, 10)));
    }

    function fund(uint256 amount) external {
        amount = bound(amount, 1e6, 500_000e6);
        usdt.mint(treasury, amount);
        treasuryMinted += amount;
        vm.startPrank(treasury);
        usdt.approve(address(wallet), 0);
        usdt.approve(address(wallet), amount);
        try wallet.fund(amount) {
            treasuryFunded += amount;
        } catch {}
        vm.stopPrank();
    }

    function withdraw(uint256 amount, bool all) external {
        amount = all ? type(uint256).max : bound(amount, 1, 200_000e6);
        vm.prank(treasury);
        try wallet.withdrawToTreasury(amount) returns (uint256 paid) {
            treasuryReceived += paid;
        } catch {}
    }

    function unwind() external {
        uint256 px = uint256(refFeed.answer()) * 1e10;
        vm.prank(treasury);
        try wallet.unwind((px * 95) / 100, (px * 105) / 100) {} catch {}
    }

    /// The governor lifts a pause (the treasury's unwind sets one), so a run keeps trading after it.
    function resume() external {
        vm.prank(wallet.governor());
        wallet.resume();
    }

    function sample() external {
        vm.prank(stranger);
        wallet.sampleFunding();
    }
}

/**
 * Whatever the keeper, the operator, the market and the treasury do, in any order:
 *  - stablecoin leaves the sleeve only to the treasury (no other role ever holds any);
 *  - the treasury's books close: what it holds is what it minted, less what it funded, plus what
 *    `withdrawToTreasury` paid it, and the sub-wallet's counters agree;
 *  - the keeper's window never exceeds its budget, and no keeper step grows the short past max
 *    leverage;
 *  - no allowance to the venue is ever left standing;
 *  - the funding average stays within the venue's rate bound.
 */
contract HedgeSleeveInvariantTest is HedgeSleeveBase {
    HedgeSleeveHandler handler;

    function setUp() public override {
        super.setUp();
        handler = new HedgeSleeveHandler(
            usdt, venueFeed, refFeed, venue, wallet, keeper, treasury, operator, stranger
        );
        targetContract(address(handler));
        // Every run starts from a book the keeper built, so every state checked has one open.
        _fund(200_000e6);
        _rebalanceUntilDone(20);
        assertGt(_short(), 0);
    }

    function invariant_FundsLeaveOnlyToTheTreasury() public view {
        assertEq(usdt.balanceOf(keeper), 0);
        assertEq(usdt.balanceOf(guardian), 0);
        assertEq(usdt.balanceOf(gov), 0);
        assertEq(usdt.balanceOf(stranger), 0);
        assertEq(usdt.balanceOf(address(handler)), 0);
    }

    function invariant_TheTreasurysBooksClose() public view {
        assertEq(
            usdt.balanceOf(treasury),
            handler.treasuryMinted() - handler.treasuryFunded() + handler.treasuryReceived()
        );
        assertEq(wallet.totalFunded(), 200_000e6 + handler.treasuryFunded());
        assertEq(wallet.totalWithdrawn(), handler.treasuryReceived());
    }

    function invariant_TheKeeperStaysInsideItsBounds() public view {
        assertLe(wallet.windowUsed(), wallet.getParams().maxWindowTurnover);
        assertFalse(handler.keeperOverLevered(), "a keeper step levered past the cap");
    }

    function invariant_NoAllowanceIsLeftStanding() public view {
        assertEq(usdt.allowance(address(wallet), address(venue)), 0);
    }

    function invariant_TheFundingAverageIsBounded() public view {
        int256 e = wallet.fundingEmaE18();
        assertLe(e, 5e14);
        assertGe(e, -5e14);
    }
}
