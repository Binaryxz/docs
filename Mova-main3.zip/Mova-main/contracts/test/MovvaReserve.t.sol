// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Governed} from "./utils/Governed.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {IERC4626} from "@openzeppelin/contracts/interfaces/IERC4626.sol";
import {IERC20Errors} from "@openzeppelin/contracts/interfaces/draft-IERC6093.sol";
import {TetherLike, StataLike} from "./ERC4626Adapter.t.sol";
import {FxTestFeed} from "./ChainlinkSignedFxOracle.t.sol";
import {StableOracle, MockVerifier3} from "./RampErc20.t.sol";
import {YieldVault} from "../yield/YieldVault.sol";
import {ERC4626Adapter} from "../yield/adapters/ERC4626Adapter.sol";
import {SignedPriceOracle} from "../ramp/SignedPriceOracle.sol";
import {ChainlinkSignedFxOracle} from "../ramp/ChainlinkSignedFxOracle.sol";
import {IPriceOracle} from "../ramp/IPriceOracle.sol";
import {FiatEscrow} from "../ramp/FiatEscrow.sol";
import {LPRegistry} from "../ramp/LPRegistry.sol";
import {IAttestorVerifier} from "../ramp/IAttestorVerifier.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";
import {Movva} from "../movva/Movva.sol";
import {MovvaReserve} from "../movva/MovvaReserve.sol";
import {IMovvaReserve} from "../movva/IMovvaReserve.sol";
import {ScaledFxBandOracle} from "../movva/ScaledFxBandOracle.sol";

/// An FX leg whose answer and timestamp the test sets directly, including ones SignedPriceOracle
/// would refuse to store.
contract SettableFx is IPriceOracle {
    uint256 public price;
    uint64 public at;

    function set(uint256 p, uint64 t) external {
        (price, at) = (p, t);
    }

    function brlCentsPerUnit() external view returns (uint256, uint64) {
        return (price, at);
    }
}

/**
 * The reserve wired as the deploy script wires it, offline: a Tether-like USDT (no return values,
 * sender-only blacklist, fee switch), a settable Chainlink USDT/USD feed, a real SignedPriceOracle
 * signed in millionths by two test publishers, and a real `YieldVault(USDT)` + `ERC4626Adapter` over
 * an Aave-wrapper-like target whose liquidity the test controls. The same behaviours against real
 * USDT, Chainlink and Aave are in MovvaFork.t.sol.
 */
abstract contract MovvaBase is Governed {
    uint256 internal constant P1 = 0xA11;
    uint256 internal constant P2 = 0xB22;
    uint64 internal constant USDT_USD_MAX_AGE = 25 hours;
    uint64 internal constant FX_MAX_AGE = 1 hours;
    /// R$ 5,40 per US dollar, at 1e-6.
    uint256 internal constant FX = 5_400_000;
    uint256 internal constant CAP = 100_000_000e18;
    uint256 internal constant U = 1e6;

    TetherLike usdt;
    FxTestFeed feed;
    SignedPriceOracle fx;
    MovvaReserve reserve;
    Movva movva;
    YieldVault vault;
    StataLike stata;
    ERC4626Adapter adapter;

    address gov = makeAddr("gov");
    address guardian = makeAddr("guardian");
    address treasurer = makeAddr("treasurer");
    address hedge = makeAddr("hedge treasury");
    address feeTo = makeAddr("fee recipient");
    address gateway = makeAddr("gateway");
    address keeper = makeAddr("vault keeper");
    address stranger = makeAddr("stranger");

    uint64 internal fxSeq;
    uint256 internal fxNow;

    function setUp() public virtual {
        vm.warp(1_800_000_000);
        usdt = new TetherLike();
        feed = new FxTestFeed(1e8, 8); // $1.00000000
        address[] memory pubs = new address[](2);
        (pubs[0], pubs[1]) = (vm.addr(P1), vm.addr(P2));
        fx = new SignedPriceOracle(gov, DELAY, pubs, 2);
        _publishFx(FX);

        reserve = new MovvaReserve(_config());
        movva = Movva(reserve.MOVVA());
        stata = new StataLike(IERC20(address(usdt)));
        vault = new YieldVault(IERC20(address(usdt)), "Shielded Yield USDT", "syUSDT", gov, guardian, keeper, 1e15, 100, DELAY);
        adapter = new ERC4626Adapter(address(vault), IERC4626(address(stata)), "stata");

        vm.startPrank(gov);
        fx.completeSetup(); // a leg in setup refuses to price: see MovvaRateTest
        vault.addAdapter(adapter, 10_000);
        vault.completeSetup();
        reserve.setGateway(gateway, true);
        reserve.setYieldVault(address(vault));
        reserve.completeSetup();
        vm.stopPrank();

        usdt.mint(gateway, 100_000_000 * U);
        vm.startPrank(gateway);
        usdt.approve(address(reserve), type(uint256).max);
        movva.approve(address(reserve), type(uint256).max);
        vm.stopPrank();
    }

    function _config() internal view virtual returns (MovvaReserve.Config memory) {
        return MovvaReserve.Config({
            usdt: address(usdt),
            usdtUsdFeed: address(feed),
            fxOracle: address(fx),
            usdtUsdMaxAge: USDT_USD_MAX_AGE,
            fxMaxAge: FX_MAX_AGE,
            governor: gov,
            governanceDelay: DELAY,
            guardian: guardian,
            treasurer: treasurer,
            hedgeTreasury: hedge,
            feeRecipient: feeTo,
            supplyCap: CAP,
            breaker: address(0),
            hedgeQueueDelay: 1 days
        });
    }

    /*//////////////////////////////////////////////////////////////
                                 HELPERS
    //////////////////////////////////////////////////////////////*/

    /// Two publishers sign BRL per US dollar at 1e-6, published now.
    function _publishFx(uint256 e6) internal {
        uint64 at = uint64(block.timestamp);
        bytes32 d = fx.digest(e6, at, ++fxSeq);
        (uint256 lo, uint256 hi) = vm.addr(P1) < vm.addr(P2) ? (P1, P2) : (P2, P1);
        bytes[] memory sigs = new bytes[](2);
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(lo, d);
        sigs[0] = abi.encodePacked(r, s, v);
        (v, r, s) = vm.sign(hi, d);
        sigs[1] = abi.encodePacked(r, s, v);
        fx.submit(e6, at, fxSeq, sigs);
        fxNow = e6;
    }

    /// A second millionths FX leg signed by the same two publishers, setup open or closed.
    function _newFxLeg(bool closeSetup) internal returns (SignedPriceOracle leg) {
        address[] memory pubs = new address[](2);
        (pubs[0], pubs[1]) = (vm.addr(P1), vm.addr(P2));
        leg = new SignedPriceOracle(gov, DELAY, pubs, 2);
        if (closeSetup) _completeSetup(address(leg));
    }

    /// Both publishers sign `e6` into `leg`, published now.
    function _publishInto(SignedPriceOracle leg, uint256 e6, uint64 seq) internal {
        uint64 at = uint64(block.timestamp);
        bytes32 d = leg.digest(e6, at, seq);
        (uint256 lo, uint256 hi) = vm.addr(P1) < vm.addr(P2) ? (P1, P2) : (P2, P1);
        bytes[] memory sigs = new bytes[](2);
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(lo, d);
        sigs[0] = abi.encodePacked(r, s, v);
        (v, r, s) = vm.sign(hi, d);
        sigs[1] = abi.encodePacked(r, s, v);
        leg.submit(e6, at, seq, sigs);
    }

    /// Move the clock, with both legs re-published as a live deployment would keep them.
    function _warp(uint256 dt) internal {
        vm.warp(block.timestamp + dt);
        feed.set(feed.answer(), block.timestamp);
        _publishFx(fxNow);
    }

    function _mint(uint256 usdtIn) internal returns (uint256 out) {
        vm.prank(gateway);
        out = reserve.mint(usdtIn, gateway, 0);
    }

    function _redeem(uint256 movvaIn) internal returns (uint256 out) {
        vm.prank(gateway);
        out = reserve.redeem(movvaIn, gateway, 0);
    }

    function _rate() internal view returns (uint256 r) {
        (r,) = reserve.brlPerUsdtE18();
    }

    /// The vault's keeper moves `amount` of the vault's idle USDT into the Aave-like target.
    function _allocate(uint256 amount) internal {
        vm.prank(keeper);
        vault.allocate(adapter, amount);
    }

    function _fund(address who, uint256 amount) internal {
        usdt.mint(who, amount);
        vm.prank(who);
        usdt.approve(address(reserve), type(uint256).max);
    }
}

contract MovvaTokenTest is MovvaBase {
    function test_TheTokenIsMovvaWithEighteenDecimalsAndTheReserveAsMinter() public view {
        assertEq(movva.name(), "Movva");
        assertEq(movva.symbol(), "MOVVA");
        assertEq(movva.decimals(), 18);
        assertEq(movva.RESERVE(), address(reserve), "the reserve deployed the token and is its minter");
        assertEq(reserve.MOVVA(), address(movva));
        assertEq(reserve.USDT(), address(usdt));
    }

    function test_OnlyTheReserveMintsAndBurns() public {
        vm.prank(gov);
        vm.expectRevert(Movva.NotReserve.selector);
        movva.mint(gov, 1);
        vm.prank(gateway);
        vm.expectRevert(Movva.NotReserve.selector);
        movva.burn(0);
    }

    /// `burn` takes the reserve's own balance: there is no path that destroys Movva someone else holds.
    function test_TheReserveCanOnlyBurnWhatItHolds() public {
        _mint(1_000 * U);
        assertEq(movva.balanceOf(address(reserve)), 0);
        vm.prank(address(reserve));
        vm.expectRevert(abi.encodeWithSelector(IERC20Errors.ERC20InsufficientBalance.selector, address(reserve), 0, 1));
        movva.burn(1);
        assertEq(movva.balanceOf(gateway), 5_400e18, "the gateway's balance is untouched");
    }

    /// A gateway that never called approve redeems with a signed permit.
    function test_APermitReplacesTheApproval() public {
        uint256 key = 0x6A7E;
        address lp = vm.addr(key);
        vm.prank(gov);
        reserve.schedule(abi.encodeCall(MovvaReserve.setGateway, (lp, true)));
        vm.warp(block.timestamp + DELAY);
        vm.prank(gov);
        reserve.execute(abi.encodeCall(MovvaReserve.setGateway, (lp, true)));
        _warp(0);
        _fund(lp, 100 * U);
        vm.prank(lp);
        reserve.mint(100 * U, lp, 0);

        bytes32 digest = keccak256(
            abi.encodePacked(
                "\x19\x01",
                movva.DOMAIN_SEPARATOR(),
                keccak256(
                    abi.encode(
                        keccak256("Permit(address owner,address spender,uint256 value,uint256 nonce,uint256 deadline)"),
                        lp,
                        address(reserve),
                        540e18,
                        movva.nonces(lp),
                        block.timestamp
                    )
                )
            )
        );
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(key, digest);
        movva.permit(lp, address(reserve), 540e18, block.timestamp, v, r, s);
        vm.prank(lp);
        assertEq(reserve.redeem(540e18, lp, 100 * U), 100 * U);
    }
}

contract MovvaRateTest is MovvaBase {
    /// $0.99972163 x R$ 5,4012 by hand: 99972163 x 5401200 x 1e12 / 1e8 = 5.399696467956e18.
    function test_TheRateCrossesChainlinkWithTheSignedLeg() public {
        feed.set(99_972_163, block.timestamp);
        _publishFx(5_401_200);
        (uint256 rate, uint64 at) = reserve.brlPerUsdtE18();
        assertEq(rate, 5_399_696_467_956_000_000, "reais per USDT at 1e18");
        assertEq(at, uint64(block.timestamp), "reported freshness is the signed leg's");
    }

    function test_AFeedWithOtherDecimalsScalesTheSame() public {
        FxTestFeed f18 = new FxTestFeed(1e18, 18);
        FxTestFeed f6 = new FxTestFeed(1e6, 6);
        _afterDelay(address(reserve), abi.encodeCall(MovvaReserve.setOracle, (address(f18), address(fx), USDT_USD_MAX_AGE, FX_MAX_AGE)));
        f18.set(1e18, block.timestamp);
        _publishFx(FX);
        assertEq(_rate(), 5.4e18);
        _afterDelay(address(reserve), abi.encodeCall(MovvaReserve.setOracle, (address(f6), address(fx), USDT_USD_MAX_AGE, FX_MAX_AGE)));
        f6.set(1e6, block.timestamp);
        _publishFx(FX);
        assertEq(_rate(), 5.4e18);
    }

    /// Each leg is judged on its own clock: a day-old Chainlink answer is fine, a two-hour-old FX rate is not.
    function test_EachLegHasItsOwnMaxAge() public {
        vm.warp(block.timestamp + USDT_USD_MAX_AGE);
        _publishFx(FX);
        assertEq(_rate(), 5.4e18, "the feed at exactly its max age still prices");
        vm.warp(block.timestamp + 1);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.StaleLeg.selector, address(feed), block.timestamp - USDT_USD_MAX_AGE - 1));
        reserve.brlPerUsdtE18();

        feed.set(1e8, block.timestamp);
        _publishFx(FX);
        uint256 published = block.timestamp;
        vm.warp(block.timestamp + FX_MAX_AGE + 1);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.StaleLeg.selector, address(fx), published));
        reserve.brlPerUsdtE18();
        // Every action that prices anything refuses with it.
        vm.prank(gateway);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.StaleLeg.selector, address(fx), published));
        reserve.mint(1 * U, gateway, 0);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.StaleLeg.selector, address(fx), published));
        reserve.brlCentsPerUnit();
    }

    function test_ZeroNegativeAndFutureAnswersAreRefused() public {
        feed.set(0, block.timestamp);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.BadPrice.selector, address(feed), int256(0)));
        reserve.brlPerUsdtE18();
        feed.set(-1, block.timestamp);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.BadPrice.selector, address(feed), int256(-1)));
        reserve.brlPerUsdtE18();
        feed.set(1e8, 0);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.StaleLeg.selector, address(feed), 0));
        reserve.brlPerUsdtE18();
        feed.set(1e8, block.timestamp + 5 minutes + 1);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.LegFromFuture.selector, address(feed), block.timestamp + 5 minutes + 1));
        reserve.brlPerUsdtE18();
        feed.set(1e8, block.timestamp);

        SettableFx leg = new SettableFx();
        _afterDelay(address(reserve), abi.encodeCall(MovvaReserve.setOracle, (address(feed), address(leg), USDT_USD_MAX_AGE, FX_MAX_AGE)));
        feed.set(1e8, block.timestamp);
        leg.set(FX, uint64(block.timestamp + 5 minutes + 1));
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.LegFromFuture.selector, address(leg), block.timestamp + 5 minutes + 1));
        reserve.brlPerUsdtE18();
        leg.set(0, uint64(block.timestamp));
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.FxOutOfRange.selector, 0));
        reserve.brlPerUsdtE18();
    }

    /**
     * The unit guard. The ramps' FX instance is signed in centavos (540); this one in millionths. A
     * reserve pointed at the centavo instance, or a publisher signing the wrong unit, is off by 10^4 -
     * and refused, never priced.
     */
    function test_AnFxRateInTheWrongUnitIsRefused() public {
        _publishFx(540); // centavos per dollar, signed into the millionths instance
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.FxOutOfRange.selector, 540));
        reserve.brlPerUsdtE18();
        _publishFx(540_000_000); // R$ 5,40 at 1e-8
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.FxOutOfRange.selector, 540_000_000));
        reserve.brlPerUsdtE18();
        _publishFx(1e6);
        assertEq(_rate(), 1e18, "R$ 1 per dollar is the lowest accepted");
        _publishFx(100e6);
        assertEq(_rate(), 100e18, "R$ 100 the highest");
    }

    /**
     * SRM1-21: the USDT/USD leg's own sanity bound, US$ 0.50 to 1.50. A feed that is not a dollar
     * stablecoin's - ETH/USD, BRL/USD, an inverted pair - would make every mint a gift or every
     * redemption an over-payment; it is refused. A real depeg inside the band is priced as reported.
     */
    function test_AUsdtUsdAnswerOutsideItsBandIsRefused() public {
        int256[5] memory bad = [int256(49_999_999), 150_000_001, 3_000e8, 18_518_518, 1e16];
        for (uint256 i; i < bad.length; ++i) {
            feed.set(bad[i], block.timestamp);
            vm.expectRevert(abi.encodeWithSelector(MovvaReserve.UsdtUsdOutOfRange.selector, bad[i]));
            reserve.brlPerUsdtE18();
            vm.prank(gateway);
            vm.expectRevert(abi.encodeWithSelector(MovvaReserve.UsdtUsdOutOfRange.selector, bad[i]));
            reserve.mint(1 * U, gateway, 0);
        }
        feed.set(50_000_000, block.timestamp);
        assertEq(_rate(), FX * 1e12 / 2, "US$ 0.50 is the lowest accepted");
        feed.set(150_000_000, block.timestamp);
        assertEq(_rate(), FX * 1e12 * 3 / 2, "US$ 1.50 the highest");
        feed.set(87_000_000, block.timestamp); // USDC, March 2023
        assertEq(_rate(), FX * 1e12 * 87 / 100);
        // Any decimals: the bound is on the dollar value, not the raw answer.
        FxTestFeed f18 = new FxTestFeed(0.4e18, 18);
        _afterDelay(address(reserve), abi.encodeCall(MovvaReserve.setOracle, (address(f18), address(fx), USDT_USD_MAX_AGE, FX_MAX_AGE)));
        f18.set(0.4e18, block.timestamp);
        _publishFx(FX);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.UsdtUsdOutOfRange.selector, int256(0.4e18)));
        reserve.brlPerUsdtE18();
        f18.set(type(int256).max, block.timestamp);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.UsdtUsdOutOfRange.selector, type(int256).max));
        reserve.brlPerUsdtE18();
        f18.set(1e18, block.timestamp);
        assertEq(_rate(), FX * 1e12);
    }

    function testFuzz_TheUsdtUsdBandIsExactlyHalfToOneAndAHalfDollars(int256 answer, uint8 dec) public {
        dec = uint8(bound(dec, 0, 18));
        answer = bound(answer, 1, type(int256).max);
        FxTestFeed f = new FxTestFeed(answer, dec);
        _afterDelay(address(reserve), abi.encodeCall(MovvaReserve.setOracle, (address(f), address(fx), USDT_USD_MAX_AGE, FX_MAX_AGE)));
        f.set(answer, block.timestamp);
        _publishFx(FX);
        uint256 one = 10 ** dec;
        bool inside = uint256(answer) * 2 >= one && uint256(answer) * 2 <= 3 * one;
        try reserve.brlPerUsdtE18() returns (uint256 rate, uint64) {
            assertTrue(inside, "priced outside the band");
            assertGt(rate, 0);
        } catch (bytes memory err) {
            // Inside the band only a rate that rounds to zero may still refuse (a 0-decimal feed).
            if (inside) assertEq(bytes4(err), MovvaReserve.PriceRoundsToZero.selector);
            else assertEq(bytes4(err), MovvaReserve.UsdtUsdOutOfRange.selector);
        }
    }

    function test_AnFxOracleWithNoPriceYetReverts() public {
        SignedPriceOracle empty = _newFxLeg(true);
        _afterDelay(address(reserve), abi.encodeCall(MovvaReserve.setOracle, (address(feed), address(empty), USDT_USD_MAX_AGE, FX_MAX_AGE)));
        feed.set(1e8, block.timestamp);
        vm.expectRevert(SignedPriceOracle.NoPriceYet.selector);
        reserve.brlPerUsdtE18();
    }

    /**
     * An FX leg whose setup is still open is refused like one with no price: every action that
     * prices reverts - the rate, the band, a mint, a redemption - though the leg holds a fresh,
     * in-range rate. Nothing is minted or redeemed at a rate whose signers its governor could still
     * change instantly. Once the leg's setup closes, the same rate prices.
     */
    function test_AnFxLegStillInSetupIsRefused() public {
        _mint(1_000 * U);
        SignedPriceOracle open = _newFxLeg(false);
        _afterDelay(address(reserve), abi.encodeCall(MovvaReserve.setOracle, (address(feed), address(open), USDT_USD_MAX_AGE, FX_MAX_AGE)));
        feed.set(1e8, block.timestamp);
        _publishInto(open, FX, 1);
        assertTrue(reserve.setupComplete(), "the refusals below are the leg's, not the reserve's");

        vm.expectRevert(DelayedGovernance.SetupIncomplete.selector);
        reserve.brlPerUsdtE18();
        vm.expectRevert(DelayedGovernance.SetupIncomplete.selector);
        reserve.brlCentsPerUnit();
        vm.prank(gateway);
        vm.expectRevert(DelayedGovernance.SetupIncomplete.selector);
        reserve.mint(1 * U, gateway, 0);
        vm.prank(gateway);
        vm.expectRevert(DelayedGovernance.SetupIncomplete.selector);
        reserve.redeem(1e18, gateway, 0);

        _completeSetup(address(open));
        assertEq(_rate(), 5.4e18);
        assertEq(_mint(1 * U), 5.4e18);
    }

    function test_FeedDecimalsAboveEighteenAreRefused() public {
        FxTestFeed odd = new FxTestFeed(1e19, 19);
        _afterDelay(address(reserve), abi.encodeCall(MovvaReserve.setOracle, (address(odd), address(fx), USDT_USD_MAX_AGE, FX_MAX_AGE)));
        odd.set(1e19, block.timestamp);
        _publishFx(FX);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.FeedDecimalsOutOfRange.selector, address(odd), 19));
        reserve.brlPerUsdtE18();
    }

    /// A USDT depeg reaches the ratio through the feed, with no publisher involved.
    function test_ADepegOnTheFeedLowersTheRatio() public {
        _mint(1_000_000 * U);
        assertEq(reserve.collateralRatioBps(), 10_000);
        feed.set(95_000_000, block.timestamp);
        assertEq(reserve.collateralRatioBps(), 9_500, "USDT at $0.95: the reserve backs 95%");
        assertEq(reserve.liabilitiesUsdt(), 1_052_631_578_948, "5,400,000 / (0.95 x 5.40), rounded up");
    }
}

contract MovvaAccountingTest is MovvaBase {
    function test_AnEmptyReserveReportsAnUnboundedRatioAndNothingOwed() public view {
        assertEq(reserve.collateralRatioBps(), type(uint256).max);
        assertEq(reserve.liabilitiesBrlE18(), 0);
        assertEq(reserve.liabilitiesUsdt(), 0);
        assertEq(reserve.surplusBrlE18(), 0);
        assertEq(reserve.totalUsdt(), 0);
    }

    /// 1,000,000 USDT at R$ 5,40 backs 5,400,000 Movva; the real moving 10% either way moves the ratio 10%.
    function test_TheRatioFollowsTheRealBothWays() public {
        _mint(1_000_000 * U);
        assertEq(reserve.totalUsdt(), 1_000_000 * U);
        assertEq(reserve.reserveBrlE18(), 5_400_000e18);
        assertEq(reserve.liabilitiesBrlE18(), 5_400_000e18);
        assertEq(reserve.liabilitiesUsdt(), 1_000_000 * U, "the dollars the issuer hedges");
        assertEq(reserve.collateralRatioBps(), 10_000);
        assertEq(reserve.surplusBrlE18(), 0);

        _publishFx(5_940_000); // the real weakens 10%
        assertEq(reserve.collateralRatioBps(), 11_000);
        assertEq(reserve.surplusBrlE18(), 5_940_000e18 - 5_832_000e18, "above 108% of liabilities");
        assertEq(reserve.liabilitiesUsdt(), 909_090_909_091, "fewer dollars now cover the same reais, rounded up");

        _publishFx(4_860_000); // the real strengthens 10%
        assertEq(reserve.collateralRatioBps(), 9_000);
        assertEq(reserve.surplusBrlE18(), 0);
    }

    /// USDT in the vault and in the vault's Aave-like source counts at what an exit pays.
    function test_TheVaultPositionCountsAtPreviewRedeem() public {
        _mint(1_000_000 * U);
        assertEq(usdt.balanceOf(address(reserve)), 0, "the mint went into the vault");
        _allocate(900_000 * U);
        assertEq(reserve.totalUsdt(), vault.previewRedeem(vault.balanceOf(address(reserve))));
        stata.earn(usdt, 9_000 * U); // 1% interest on the allocated part
        assertApproxEqAbs(reserve.totalUsdt(), 1_009_000 * U, 2, "interest raises the reserve, rounded down");
        assertLe(reserve.totalUsdt(), 1_009_000 * U);
        assertGt(reserve.collateralRatioBps(), 10_000);
    }

    function test_PreviewsMatchTheActions() public {
        _mint(1_000_000 * U);
        vm.prank(gov);
        reserve.setFees(0, 0);
        _afterDelay(address(reserve), abi.encodeCall(MovvaReserve.setFees, (30, 40)));
        _warp(0);
        (uint256 out, uint256 fee) = reserve.previewMint(10_000 * U);
        vm.prank(gateway);
        assertEq(reserve.mint(10_000 * U, gateway, 0), out);
        assertEq(fee, 162e18, "30 bps of 54,000, rounded up");
        (uint256 usdtOut, uint256 rfee) = reserve.previewRedeem(54_000e18);
        assertEq(_redeem(54_000e18), usdtOut);
        assertEq(rfee, 216e18, "40 bps of 54,000");
    }
}

contract MovvaMintTest is MovvaBase {
    function test_AGatewayMintsAtTheRateIntoTheVault() public {
        vm.expectEmit(address(reserve));
        emit IMovvaReserve.Minted(gateway, stranger, 1_000 * U, 5_400e18, 5.4e18);
        vm.prank(gateway);
        uint256 out = reserve.mint(1_000 * U, stranger, 5_400e18);
        assertEq(out, 5_400e18);
        assertEq(movva.balanceOf(stranger), 5_400e18);
        assertEq(usdt.balanceOf(address(reserve)), 0);
        assertEq(vault.totalAssets(), 1_000 * U, "deposited into YieldVault(USDT)");
        assertEq(usdt.allowance(address(reserve), address(vault)), 0, "no allowance left standing");
    }

    function test_OnlyGatewaysMint() public {
        _fund(stranger, 1_000 * U);
        vm.prank(stranger);
        vm.expectRevert(MovvaReserve.NotGateway.selector);
        reserve.mint(1_000 * U, stranger, 0);
    }

    function test_NoMintBelowTheMintFloor() public {
        _mint(1_000 * U);
        _publishFx(5_399_999);
        vm.prank(gateway);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.CollateralRatioTooLow.selector, 9_999, 10_000));
        reserve.mint(1_000 * U, gateway, 0);
        _publishFx(FX);
        _mint(1_000 * U);
    }

    function test_TheSlippageBoundIsEnforced() public {
        vm.prank(gateway);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.Slippage.selector, 5_400e18, 5_400e18 + 1));
        reserve.mint(1_000 * U, gateway, 5_400e18 + 1);
    }

    /// The fee is minted to the fee recipient, so the reserve still backs every Movva at 100%.
    function test_TheMintFeeIsMintedToTheFeeRecipient() public {
        _afterDelay(address(reserve), abi.encodeCall(MovvaReserve.setFees, (50, 0)));
        _warp(0);
        uint256 out = _mint(1_000 * U);
        assertEq(movva.balanceOf(feeTo), 27e18, "50 bps of 5,400");
        assertEq(out, 5_373e18);
        assertEq(movva.totalSupply(), 5_400e18);
        assertEq(reserve.collateralRatioBps(), 10_000);
    }

    function test_TheSupplyCapBoundsMinting() public {
        vm.prank(gov);
        reserve.setLimits(10_000e18, 800);
        _mint(1_000 * U);
        vm.prank(gateway);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.SupplyCapExceeded.selector, 10_800e18, 10_000e18));
        reserve.mint(1_000 * U, gateway, 0);
    }

    function test_TheGuardianPausesMintAndOnlyTheGovernorResumes() public {
        _mint(1_000 * U);
        vm.prank(stranger);
        vm.expectRevert(MovvaReserve.NotGuardianOrGovernor.selector);
        reserve.pauseMint();
        vm.expectEmit(address(reserve));
        emit MovvaReserve.MintPaused(guardian);
        vm.prank(guardian);
        reserve.pauseMint();
        vm.prank(gateway);
        vm.expectRevert(MovvaReserve.MintIsPaused.selector);
        reserve.mint(1 * U, gateway, 0);

        // Redemptions are not paused: there is no function that could pause them.
        assertEq(_redeem(540e18), 100 * U);

        vm.prank(guardian);
        vm.expectRevert(DelayedGovernance.NotGovernor.selector);
        reserve.resumeMint();
        vm.prank(gov);
        reserve.resumeMint();
        _mint(1 * U);
    }

    function test_NoIntakeWhileTetherHasFrozenTheReserve() public {
        usdt.addBlackList(address(reserve));
        vm.prank(gateway);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.FrozenByAssetIssuer.selector, address(reserve)));
        reserve.mint(1_000 * U, gateway, 0);
        _fund(stranger, 1_000 * U);
        vm.prank(stranger);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.FrozenByAssetIssuer.selector, address(reserve)));
        reserve.recapitalize(1_000 * U);
        usdt.removeBlackList(address(reserve));
        _mint(1_000 * U);
    }

    /// Tether's fee switch: Movva would be minted for USDT that never arrived.
    function test_ATransferFeeOnIntakeIsRefused() public {
        usdt.setParams(19, 49);
        vm.prank(gateway);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.TransferFeeCharged.selector, 10_000 * U, 10_000 * U - 19 * U));
        reserve.mint(10_000 * U, gateway, 0);
        _fund(stranger, 10_000 * U);
        vm.prank(stranger);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.TransferFeeCharged.selector, 10_000 * U, 10_000 * U - 19 * U));
        reserve.recapitalize(10_000 * U);
    }

    function test_ZeroAmountsAndAddressesAreRefused() public {
        vm.startPrank(gateway);
        vm.expectRevert(MovvaReserve.ZeroAmount.selector);
        reserve.mint(0, gateway, 0);
        vm.expectRevert(DelayedGovernance.ZeroAddress.selector);
        reserve.mint(1, address(0), 0);
        vm.expectRevert(MovvaReserve.ZeroAmount.selector);
        reserve.redeem(0, gateway, 0);
        vm.expectRevert(DelayedGovernance.ZeroAddress.selector);
        reserve.redeem(1, address(0), 0);
        vm.stopPrank();
    }

    function test_NothingBeforeSetupCompletes() public {
        MovvaReserve fresh = new MovvaReserve(_config());
        vm.prank(gov);
        fresh.setGateway(gateway, true);
        vm.prank(gateway);
        vm.expectRevert(DelayedGovernance.SetupIncomplete.selector);
        fresh.mint(1 * U, gateway, 0);
        vm.expectRevert(DelayedGovernance.SetupIncomplete.selector);
        fresh.recapitalize(1 * U);
        vm.prank(treasurer);
        vm.expectRevert(DelayedGovernance.SetupIncomplete.selector);
        fresh.withdrawToHedge(1 * U);
    }

    /// The vault paused (its own guardian, or its drawdown breaker): new USDT waits idle, and still counts.
    function test_AVaultThatAcceptsNothingLeavesTheUsdtIdle() public {
        vm.prank(guardian);
        vault.pauseDeposits();
        _mint(1_000 * U);
        assertEq(usdt.balanceOf(address(reserve)), 1_000 * U);
        assertEq(reserve.collateralRatioBps(), 10_000);
        vm.prank(gov);
        vault.resumeDeposits();
        _mint(1_000 * U);
        assertEq(usdt.balanceOf(address(reserve)), 0, "the next intake sweeps idle USDT in");
        assertEq(vault.totalAssets(), 2_000 * U);
    }

    /// Minting never lowers what backs each Movva: fuzzed over amounts, rates and interest.
    function testFuzz_MintNeverDilutesAFullyBackedReserve(uint256 a, uint256 b, uint256 e6, uint256 interest) public {
        a = bound(a, 1, 10_000_000 * U);
        b = bound(b, 1, 10_000_000 * U);
        e6 = bound(e6, 1e6, 100e6);
        _publishFx(e6);
        vm.prank(gateway);
        try reserve.mint(a, gateway, 0) {} catch { return; }
        if (vault.totalAssets() > 1) _allocate(vault.totalAssets() / 2);
        stata.earn(usdt, bound(interest, 0, a / 10));
        uint256 ratio = reserve.collateralRatioBps();
        uint256 supply = movva.totalSupply();
        uint256 total = reserve.totalUsdt();
        vm.prank(gateway);
        try reserve.mint(b, gateway, 0) returns (uint256 out) {
            assertLe(out, (b * _rate()) / 1e6, "never more than the USDT in, at the rate");
            // Minted only while backed, and minting at the rate cannot make the reserve under-backed.
            assertGe(ratio, 10_000);
            assertGe(reserve.collateralRatioBps(), 10_000, "still fully backed after the mint");
            assertGe(reserve.totalUsdt(), total + b - 2, "the USDT arrived, less at most vault rounding");
            assertGe(movva.totalSupply(), supply);
        } catch {}
    }
}

contract MovvaRedeemTest is MovvaBase {
    function setUp() public override {
        super.setUp();
        _mint(1_000_000 * U);
    }

    function test_RedeemPaysParWhenFullyBacked() public {
        vm.expectEmit(address(reserve));
        emit IMovvaReserve.Redeemed(gateway, stranger, 540_000e18, 100_000 * U, 5.4e18);
        vm.prank(gateway);
        uint256 out = reserve.redeem(540_000e18, stranger, 100_000 * U);
        assertEq(out, 100_000 * U);
        assertEq(usdt.balanceOf(stranger), 100_000 * U);
        assertEq(movva.totalSupply(), 4_860_000e18, "burned");
        assertEq(movva.balanceOf(address(reserve)), 0);
        assertEq(reserve.collateralRatioBps(), 10_000);
    }

    /// Under-backed by 10%: a redeemer gets 90% of par, which is exactly its pro-rata share, and
    /// the ratio for everyone who stays is unchanged.
    function test_AnUnderBackedRedemptionPaysProRata() public {
        _publishFx(4_860_000);
        assertEq(reserve.collateralRatioBps(), 9_000);
        (uint256 preview,) = reserve.previewRedeem(540_000e18);
        assertEq(preview, 100_000 * U, "10% of the supply takes 10% of the reserve, not 111,111 at par");
        assertEq(_redeem(540_000e18), 100_000 * U);
        assertEq(reserve.collateralRatioBps(), 9_000, "stayers are no worse off");
        assertEq(_redeem(4_860_000e18), 900_000 * U, "the last redeemer gets the same fraction");
        assertEq(reserve.totalUsdt(), 0);
    }

    /// Over-backed: par, and the surplus stays for everyone else.
    function test_AnOverBackedRedemptionPaysParAndKeepsTheSurplus() public {
        _publishFx(5_940_000);
        assertEq(_redeem(594_000e18), 100_000 * U);
        assertEq(reserve.collateralRatioBps(), 11_123, "900,000 x 5.94 / 4,806,000");
    }

    function test_TheRedeemFeeIsKeptAsMovvaByTheFeeRecipient() public {
        _afterDelay(address(reserve), abi.encodeCall(MovvaReserve.setFees, (0, 100)));
        _warp(0);
        uint256 out = _redeem(540_000e18);
        assertEq(movva.balanceOf(feeTo), 5_400e18, "1% of the Movva");
        assertEq(out, 99_000 * U);
        assertEq(movva.totalSupply(), 4_860_000e18 + 5_400e18);
        assertEq(reserve.collateralRatioBps(), 10_000);
    }

    function test_TheSlippageBoundIsEnforced() public {
        _publishFx(4_860_000);
        vm.prank(gateway);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.Slippage.selector, 100_000 * U, 111_111 * U));
        reserve.redeem(540_000e18, gateway, 111_111 * U);
    }

    function test_OnlyGatewaysRedeemAndARemovedGatewayCannot() public {
        vm.prank(gateway);
        movva.transfer(stranger, 540e18);
        vm.prank(stranger);
        vm.expectRevert(MovvaReserve.NotGateway.selector);
        reserve.redeem(540e18, stranger, 0);
        vm.prank(gov);
        reserve.setGateway(gateway, false);
        vm.prank(gateway);
        vm.expectRevert(MovvaReserve.NotGateway.selector);
        reserve.redeem(540e18, gateway, 0);
    }

    /// Idle first, then the vault - paid from the vault straight to the recipient.
    function test_RedemptionsDrawIdleFirstThenTheVault() public {
        vm.prank(gov);
        reserve.pullFromVault(50_000 * U);
        assertEq(usdt.balanceOf(address(reserve)), 50_000 * U);
        _allocate(900_000 * U);
        _redeem(540_000e18); // 100,000 USDT: 50,000 idle, 50,000 from the vault's own idle
        assertEq(usdt.balanceOf(address(reserve)), 0);
        assertEq(usdt.balanceOf(gateway), 100_000_000 * U - 1_000_000 * U + 100_000 * U);
        assertApproxEqAbs(vault.totalAssets(), 900_000 * U, 1);
        _redeem(1_080_000e18); // 200,000 more: the vault pulls from its Aave-like source
        assertApproxEqAbs(adapter.totalValue(), 700_000 * U, 2);
    }

    /// Aave's liquidity borrowed out: a redemption larger than what can move now is refused up
    /// front, naming what is available, and nothing moves.
    function test_ARedemptionBeyondInstantLiquidityRefusesCleanly() public {
        _allocate(900_000 * U);
        stata.setLiquidity(200_000 * U);
        uint256 available = 100_000 * U + 200_000 * U;
        vm.prank(gateway);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.InsufficientLiquidity.selector, 400_000 * U, available));
        reserve.redeem(2_160_000e18, gateway, 0);
        assertEq(movva.totalSupply(), 5_400_000e18, "nothing burned");
        assertEq(_redeem(1_620_000e18), 300_000 * U, "exactly what was available still exits");
    }

    function test_NobodyIsPaidIntoAFrozenAddress() public {
        usdt.addBlackList(stranger);
        vm.prank(gateway);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.FrozenByAssetIssuer.selector, stranger));
        reserve.redeem(540e18, stranger, 0);
    }

    /// SRM1-21: a gateway Tether froze could still redeem, paying its exit to an address that is not
    /// frozen - routing a blacklisted party's value out of the reserve, and a reason for Tether to
    /// freeze the reserve itself. The redeeming gateway is now checked as the recipient is.
    function test_AFrozenGatewayCannotRedeemToAnotherAddress() public {
        _mint(1_000 * U);
        usdt.addBlackList(gateway);
        vm.prank(gateway);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.FrozenByAssetIssuer.selector, gateway));
        reserve.redeem(540e18, stranger, 0);
        assertEq(usdt.balanceOf(stranger), 0);
        // Lifted, it redeems again, to anyone not frozen.
        usdt.removeBlackList(gateway);
        vm.prank(gateway);
        assertGt(reserve.redeem(540e18, stranger, 0), 0);
    }

    /**
     * Tether freezes the reserve with USDT both idle and in the vault. The idle USDT cannot be paid,
     * so it stops counting; the vault still pays, straight to the redeemer, pro rata to what is
     * payable. Unfrozen, the idle USDT counts again.
     */
    function test_AFrozenReservePaysRedemptionsFromTheVaultProRata() public {
        vm.prank(gov);
        reserve.pullFromVault(400_000 * U);
        usdt.addBlackList(address(reserve));
        assertTrue(reserve.frozenByAssetIssuer());
        assertEq(reserve.totalUsdt(), 600_000 * U, "frozen idle USDT counts for nothing");
        assertEq(reserve.collateralRatioBps(), 6_000);
        assertEq(_redeem(540_000e18), 60_000 * U, "10% of the supply, 10% of what can be paid");
        assertEq(usdt.balanceOf(address(reserve)), 400_000 * U, "the frozen USDT did not move");

        // Unfrozen, the idle USDT counts again. The redeemer was paid on the conservative figure, so
        // the stayers now hold more than par: 940,000 x 5.40 / 4,860,000.
        usdt.removeBlackList(address(reserve));
        assertEq(reserve.totalUsdt(), 940_000 * U);
        assertEq(reserve.collateralRatioBps(), 10_444);
    }

    function testFuzz_RedeemNeverPaysMoreThanMinOfParAndProRata(uint256 amount, uint256 e6, uint256 depeg) public {
        e6 = bound(e6, 1e6, 100e6);
        _publishFx(e6);
        feed.set(int256(bound(depeg, 50_000_000, 110_000_000)), block.timestamp);
        amount = bound(amount, 1, movva.balanceOf(gateway));
        uint256 rate = _rate();
        uint256 total = reserve.totalUsdt();
        uint256 supply = movva.totalSupply();
        vm.prank(gateway);
        try reserve.redeem(amount, gateway, 0) returns (uint256 out) {
            assertLe(out, (amount * 1e6) / rate, "never above par");
            assertLe(out, (amount * total) / supply, "never above the pro-rata share");
        } catch (bytes memory reason) {
            assertEq(bytes4(reason), MovvaReserve.Slippage.selector, "only dust refuses");
        }
    }
}

contract MovvaHedgeTest is MovvaBase {
    /// At rest: 1,000,000 USDT minted at R$ 5,40, plus the 8% buffer the issuer seeds at launch, so
    /// the reserve starts at the 108% target the hedge desk keeps it at.
    function setUp() public override {
        super.setUp();
        _mint(1_000_000 * U);
        vm.prank(gateway);
        reserve.recapitalize(80_000 * U);
        assertEq(reserve.collateralRatioBps(), 10_800, "at rest");
    }

    /// The real weakens 10% (ratio 118.8%): a full day's limit, 8% of 1,080,000, goes to the hedge
    /// account and leaves 993,600 x 5.94 / 5,400,000 = 109.29%, above the 103% floor.
    function test_TheTreasurerWithdrawsSurplusToTheHedgeTreasury() public {
        _publishFx(5_940_000);
        assertEq(reserve.collateralRatioBps(), 11_880);
        assertEq(reserve.hedgeWithdrawable(), 86_400 * U, "8% of the reserve");
        vm.expectEmit(address(reserve));
        emit IMovvaReserve.WithdrawnToHedge(hedge, 86_400 * U, 10_929);
        vm.prank(treasurer);
        reserve.withdrawToHedge(86_400 * U);
        assertEq(usdt.balanceOf(hedge), 86_400 * U);
        assertEq(reserve.collateralRatioBps(), 10_929);
    }

    function test_OnlyTheTreasurer() public {
        for (uint256 i; i < 3; ++i) {
            address who = [gov, guardian, gateway][i];
            vm.prank(who);
            vm.expectRevert(MovvaReserve.NotTreasurer.selector);
            reserve.withdrawToHedge(1 * U);
        }
    }

    /**
     * The design case (docs/movva.md, "Sizing the buffer"). From rest, the dollar rallies 5% in a
     * day: the ratio reads 113.4%. The issuer's B3 short on the 1,000,000 hedged dollars loses
     * R$ 270.000 of variation margin. Withdrawing the reserve back to its 108% target releases
     * 51,428.571428 USDT - worth R$ 291.600, more than the call - inside one day's 86,400 limit. The
     * rest of the limit, above the 103% floor, is there for the initial margin the broker adds on a
     * larger notional (a 10% placeholder: R$ 27.000 more, 4,762 USDT).
     */
    function test_AFivePercentDollarRallyFromRestIsWithdrawnToTargetInOneDay() public {
        uint256 hedgedUsd = reserve.liabilitiesUsdt();
        assertEq(hedgedUsd, 1_000_000 * U);
        _publishFx(5_670_000);
        assertEq(reserve.collateralRatioBps(), 11_340);

        uint256 toTarget = 51_428_571_428;
        uint256 variationBrl = (hedgedUsd * (5_670_000 - FX) * 1e12) / 1e6;
        assertEq(variationBrl, 270_000e18);
        assertGe((toTarget * _rate()) / 1e6, variationBrl, "back to target pays the variation margin");
        assertLe(toTarget, reserve.hedgeWithdrawable(), "within one day's limit");

        vm.prank(treasurer);
        reserve.withdrawToHedge(toTarget);
        assertEq(reserve.collateralRatioBps(), 10_800, "back at the target");
        // One unit more would have left it below target: this is exactly the surplus the rally made.
        assertEq((1_080_000 * U - toTarget - 1) * _rate() / 1e6 * 10_000 / movva.totalSupply(), 10_799);

        vm.prank(treasurer);
        reserve.withdrawToHedge(4_762 * U);
        assertGe(reserve.collateralRatioBps(), reserve.minWithdrawCollateralRatioBps(), "and the margin add-on, above the floor");
        assertGt(reserve.hedgeWithdrawable(), 0, "still inside the day's limit");
    }

    /**
     * The other way: from rest, the dollar falls 5% (R$ 5,13). The reserve reads 1,080,000 x 5.13 /
     * 5,400,000 = 102.6% - still fully backed, so minting continues and redemptions pay par, while the
     * short's R$ 270.000 gain waits at the broker to be brought back. Nothing goes to the hedge below
     * the 103% floor.
     */
    function test_AFivePercentDollarFallFromRestStaysFullyBacked() public {
        _publishFx(5_130_000);
        uint256 ratio = reserve.collateralRatioBps();
        assertEq(ratio, 10_260);
        assertGe(ratio, 10_000);
        uint256 minted = _mint(1_000 * U);
        assertEq(minted, 5_130e18, "minting continues, at the rate");
        assertEq(_redeem(5_130e18), 1_000 * U, "redemptions pay par");
        vm.prank(treasurer);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.CollateralRatioTooLow.selector, 10_259, 10_300));
        reserve.withdrawToHedge(1);
    }

    /// The limit is a bucket: one limit at once, refilling continuously over 24 hours. At +10%, where
    /// the floor is far below and only the limit binds.
    function test_TheLimitRefillsContinuously() public {
        _publishFx(5_940_000);
        vm.prank(treasurer);
        reserve.withdrawToHedge(86_400 * U);
        vm.prank(treasurer);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.HedgeLimitExceeded.selector, 1, 0));
        reserve.withdrawToHedge(1);

        _warp(12 hours);
        // 8% of the smaller reserve, 993,600, is 79,488 a day: 39,744 drained in 12 hours from a bucket
        // at 86,400 leaves 46,656 used, and 32,832 of room.
        assertEq(reserve.hedgeWithdrawable(), 32_832 * U);
        vm.prank(treasurer);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.HedgeLimitExceeded.selector, 32_833 * U, 32_832 * U));
        reserve.withdrawToHedge(32_833 * U);
        vm.prank(treasurer);
        reserve.withdrawToHedge(32_832 * U);

        // The bucket stands at 79,488 against a limit that shrank with the reserve (960,768) to
        // 76,861.44. A day drains one limit, leaving 2,626.56 used: a shrinking reserve refills a
        // little slower.
        _warp(24 hours);
        assertEq(reserve.hedgeWithdrawable(), 76_861_440_000 - 2_626_560_000);
        _warp(1 hours);
        assertEq(reserve.hedgeWithdrawable(), 76_861_440_000, "empty again");
    }

    /**
     * The stated worst case: a full bucket, then a day of refill, is at most two limits inside 24
     * hours. At +50% (R$ 8,10), so the 103% floor never binds; the reserve shrinking by 8% a day makes
     * the refill slower, and hourly withdrawals reach about 1.75 limits.
     */
    function test_AtMostTwoLimitsInAnyDay() public {
        _publishFx(8_100_000);
        uint256 moved;
        for (uint256 i; i <= 24; ++i) {
            uint256 room = reserve.hedgeWithdrawable();
            if (room != 0) {
                vm.prank(treasurer);
                reserve.withdrawToHedge(room);
                moved += room;
            }
            if (i < 24) _warp(1 hours);
        }
        uint256 limit = (1_080_000 * U * 800) / 10_000;
        assertLe(moved, 2 * limit, "two limits of the starting reserve");
        assertGt(moved, (175 * limit) / 100, "and 1.75 of them, with the reserve shrinking");
    }

    /// Down to the 103% floor to the unit, and not one unit further. From rest that is 50,000 USDT.
    function test_NeverBelowTheWithdrawFloor() public {
        vm.prank(treasurer);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.CollateralRatioTooLow.selector, 10_299, 10_300));
        reserve.withdrawToHedge(50_000 * U + 1);
        vm.prank(treasurer);
        reserve.withdrawToHedge(50_000 * U);
        assertEq(reserve.collateralRatioBps(), 10_300);

        vm.prank(treasurer);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.CollateralRatioTooLow.selector, 10_299, 10_300));
        reserve.withdrawToHedge(1);
        assertEq(reserve.hedgeWithdrawable(), 32_400 * U, "the floor bound, not the limit: 8% of 1,030,000 less 50,000");
    }

    function test_AFrozenHedgeTreasuryIsNotPaid() public {
        usdt.addBlackList(hedge);
        vm.prank(treasurer);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.FrozenByAssetIssuer.selector, hedge));
        reserve.withdrawToHedge(1_000 * U);
    }

    function test_HedgeWithdrawalsPayFromTheVault() public {
        _allocate(1_075_000 * U); // the vault keeps 5,000 idle
        vm.prank(treasurer);
        reserve.withdrawToHedge(15_000 * U);
        assertEq(usdt.balanceOf(hedge), 15_000 * U);
        assertApproxEqAbs(adapter.totalValue(), 1_065_000 * U, 2, "10,000 of it from the Aave-like source");
    }
}

contract MovvaRecapitalizeTest is MovvaBase {
    function test_AnyoneRecapitalizesAndTheRatioRecovers() public {
        _mint(1_000_000 * U);
        _publishFx(4_860_000); // 90%
        _fund(stranger, 111_112 * U);
        vm.expectEmit(address(reserve));
        emit IMovvaReserve.Recapitalized(stranger, 111_112 * U, 10_000);
        vm.prank(stranger);
        reserve.recapitalize(111_112 * U);
        assertEq(reserve.collateralRatioBps(), 10_000);
        assertEq(movva.totalSupply(), 5_400_000e18, "nothing minted");
        assertEq(usdt.balanceOf(address(reserve)), 0, "into the vault");
    }

    /// Adding backing never waits on an oracle. The event's ratio is zero: not readable.
    function test_RecapitalizingWorksWithAStaleRate() public {
        _mint(1_000 * U);
        vm.warp(block.timestamp + 2 hours);
        _fund(stranger, 100 * U);
        vm.expectEmit(address(reserve));
        emit IMovvaReserve.Recapitalized(stranger, 100 * U, 0);
        vm.prank(stranger);
        reserve.recapitalize(100 * U);
        assertEq(vault.totalAssets(), 1_100 * U);
    }

    function test_ZeroIsRefused() public {
        vm.expectRevert(MovvaReserve.ZeroAmount.selector);
        reserve.recapitalize(0);
    }
}

/// Client decision D1 (14 October 2026): no savings product. The surplus above target is never minted;
/// it stays in the reserve as backing, and the removed entry points are not there to call.
contract MovvaNoDistributionTest is MovvaBase {
    function test_TheSurplusStaysInTheReserve() public {
        _mint(5_000_000 * U);
        vm.prank(gateway);
        reserve.recapitalize(1_000_000 * U);
        uint256 supply = movva.totalSupply();
        uint256 surplus = reserve.surplusBrlE18();
        assertGt(surplus, 0, "recapitalized above target");
        _warp(30 days);
        assertEq(movva.totalSupply(), supply, "nothing minted the surplus");
        assertEq(reserve.surplusBrlE18(), surplus, "and it is all still there");
    }

    /// No such function: the call falls through the dispatcher and reverts with no data, where an existing
    /// one would answer, or refuse with a named error.
    function test_TheSavingsEntryPointsAreGone() public {
        bytes[9] memory gone = [
            abi.encodeWithSignature("distribute()"),
            abi.encodeWithSignature("previewDistribute()"),
            abi.encodeWithSignature("savings()"),
            abi.encodeWithSignature("setSavings(address)", stranger),
            abi.encodeWithSignature("distributionFeeBps()"),
            abi.encodeWithSignature("maxDistributionBpsPerDay()"),
            abi.encodeWithSignature("lastDistributionAt()"),
            abi.encodeWithSignature("setFees(uint16,uint16,uint16)", 0, 0, 0),
            abi.encodeWithSignature("setLimits(uint256,uint16,uint16)", 0, 0, 0)
        ];
        for (uint256 i; i < gone.length; ++i) {
            vm.prank(gov);
            (bool ok, bytes memory ret) = address(reserve).call(gone[i]);
            assertFalse(ok);
            assertEq(ret.length, 0, "no function answered");
        }
    }
}

contract MovvaBandOracleTest is MovvaBase {
    function test_OneRealWhileFullyBacked() public {
        (uint256 price, uint64 at) = reserve.brlCentsPerUnit();
        assertEq(price, 100, "an empty reserve owes nothing: par");
        assertEq(at, uint64(block.timestamp));
        _mint(1_000_000 * U);
        (price,) = reserve.brlCentsPerUnit();
        assertEq(price, 100);
    }

    function test_NeverAboveOneRealAndFollowsTheRatioBelow() public {
        _mint(1_000_000 * U);
        _publishFx(8_100_000);
        (uint256 price,) = reserve.brlCentsPerUnit();
        assertEq(price, 100, "150% backed is still R$ 1,00");
        _publishFx(4_860_000);
        (price,) = reserve.brlCentsPerUnit();
        assertEq(price, 90);
        _publishFx(5_373_000); // 99.50%
        (price,) = reserve.brlCentsPerUnit();
        assertEq(price, 100, "nearest centavo: 99.5 rounds up");
        _publishFx(5_372_999); // 99.49%
        (price,) = reserve.brlCentsPerUnit();
        assertEq(price, 99);
    }

    function test_TheBandRevertsWhenTheRateIsStale() public {
        vm.warp(block.timestamp + FX_MAX_AGE + 1);
        vm.expectRevert();
        reserve.brlCentsPerUnit();
    }

    /**
     * Movva listed on a real FiatEscrow with the reserve as its oracle and a 1% band. The escrow
     * prices per whole token of the asset's decimals (18): a Movva offer at 100 centavos posts while
     * the reserve is fully backed, and the same offer is outside the band once the ratio reads 90%.
     */
    function test_TheReserveIsMovvasBandOnTheOnRamp() public {
        MockVerifier3 verifier = new MockVerifier3();
        LPRegistry registry = new LPRegistry(gov, DELAY);
        FiatEscrow onramp = new FiatEscrow(
            address(new StableOracle()), address(registry), makeAddr("entrypoint"), makeAddr("pool"), 100, gov, DELAY, DISPUTE_TIMEOUT
        );
        vm.startPrank(gov);
        registry.setEscrow(address(onramp), true);
        registry.setTier(gateway, LPRegistry.Tier.INSTITUTIONAL, 100_000_000);
        registry.completeSetup();
        onramp.setVerifier(address(verifier), true);
        onramp.setAsset(address(movva), address(reserve), 18, true);
        onramp.completeSetup();
        vm.stopPrank();

        _mint(1_000_000 * U);
        uint16 pix = uint16(1 << uint8(IAttestorVerifier.Rail.PIX));
        vm.startPrank(gateway);
        movva.approve(address(onramp), type(uint256).max);
        onramp.postOffer(address(movva), 10_000e18, 100, keccak256("pix"), 1e18, 10_000e18, address(verifier), pix);
        vm.stopPrank();
        assertEq(movva.balanceOf(address(onramp)), 10_000e18);

        _publishFx(4_860_000);
        vm.prank(gateway);
        vm.expectRevert(FiatEscrow.PriceOutsideBand.selector);
        onramp.postOffer(address(movva), 10_000e18, 100, keccak256("pix"), 1e18, 10_000e18, address(verifier), pix);
        vm.prank(gateway);
        onramp.postOffer(address(movva), 10_000e18, 90, keccak256("pix"), 1e18, 10_000e18, address(verifier), pix);
    }
}

contract ScaledFxBandOracleTest is MovvaBase {
    function test_MillionthsBecomeCentavosToTheNearest() public {
        ScaledFxBandOracle band = new ScaledFxBandOracle(fx);
        _publishFx(5_401_200);
        (uint256 cents, uint64 at) = band.brlCentsPerUnit();
        assertEq(cents, 540);
        assertEq(at, uint64(block.timestamp), "the source's publish time, unchanged");
        _publishFx(5_405_000);
        (cents,) = band.brlCentsPerUnit();
        assertEq(cents, 541, "half a centavo rounds up");
        _publishFx(5_404_999);
        (cents,) = band.brlCentsPerUnit();
        assertEq(cents, 540);
    }

    function test_ZeroCentavosAndNoPriceAreRefused() public {
        SettableFx src = new SettableFx();
        ScaledFxBandOracle band = new ScaledFxBandOracle(src);
        src.set(4_999, uint64(block.timestamp));
        vm.expectRevert(ScaledFxBandOracle.PriceRoundsToZero.selector);
        band.brlCentsPerUnit();

        // A source still in setup refuses through the adapter; then, with no price, so does that.
        SignedPriceOracle source = _newFxLeg(false);
        ScaledFxBandOracle unpublished = new ScaledFxBandOracle(source);
        vm.expectRevert(DelayedGovernance.SetupIncomplete.selector);
        unpublished.brlCentsPerUnit();
        _completeSetup(address(source));
        vm.expectRevert(SignedPriceOracle.NoPriceYet.selector);
        unpublished.brlCentsPerUnit();

        vm.expectRevert(ScaledFxBandOracle.ZeroAddress.selector);
        new ScaledFxBandOracle(IPriceOracle(address(0)));
    }

    /**
     * Publishers sign once. The ramps' USDT band (ChainlinkSignedFxOracle) reads the reserve's own
     * millionths instance through the adapter, so one signature moves the reserve's rate and the
     * ramps' band together - and the cross checks the leg's age and future skew as before.
     */
    function test_TheRampsCrossAndTheReserveReadTheSameSignature() public {
        ScaledFxBandOracle band = new ScaledFxBandOracle(fx);
        ChainlinkSignedFxOracle usdtBand =
            new ChainlinkSignedFxOracle(address(feed), address(band), USDT_USD_MAX_AGE, FX_MAX_AGE, gov, DELAY);
        _completeSetup(address(usdtBand));
        feed.set(99_972_163, block.timestamp);
        _publishFx(5_401_200);
        (uint256 cents,) = usdtBand.brlCentsPerUnit();
        assertEq(cents, 540, "0.99972163 x 540 = 539.85 -> 540");
        assertEq(_rate(), 5_399_696_467_956_000_000);

        _publishFx(5_940_000);
        (cents,) = usdtBand.brlCentsPerUnit();
        assertEq(cents, 594, "0.99972163 x 594 = 593.83 -> 594");
        assertEq(_rate(), (uint256(99_972_163) * 5_940_000 * 1e12) / 1e8);

        vm.warp(block.timestamp + FX_MAX_AGE + 1);
        vm.expectRevert(abi.encodeWithSelector(ChainlinkSignedFxOracle.StaleLeg.selector, address(band), block.timestamp - FX_MAX_AGE - 1));
        usdtBand.brlCentsPerUnit();
    }
}

/// Every privileged function: who may call it, and whether it waits out the delay.
contract MovvaGovernanceTest is MovvaBase {
    function _mustSchedule(bytes memory call) internal {
        vm.prank(gov);
        (bool ok, bytes memory ret) = address(reserve).call(call);
        assertFalse(ok, "a risk-increasing change went through without the delay");
        assertEq(ret, abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, bytes4(call)));
        _afterDelay(address(reserve), call);
    }

    function _instant(bytes memory call) internal {
        vm.prank(stranger);
        (bool ok, bytes memory ret) = address(reserve).call(call);
        assertFalse(ok, "a stranger changed governance");
        assertEq(bytes4(ret), DelayedGovernance.NotGovernor.selector);
        vm.prank(gov);
        (ok, ret) = address(reserve).call(call);
        assertTrue(ok, string(ret));
    }

    function test_AddingAGatewayWaitsRemovingDoesNot() public {
        address lp = makeAddr("lp2");
        _mustSchedule(abi.encodeCall(MovvaReserve.setGateway, (lp, true)));
        assertTrue(reserve.isGateway(lp));
        _instant(abi.encodeCall(MovvaReserve.setGateway, (lp, false)));
        assertFalse(reserve.isGateway(lp));
        vm.prank(gov);
        vm.expectRevert(DelayedGovernance.ZeroAddress.selector);
        reserve.setGateway(address(0), false);
    }

    function test_TheGuardianRotatesInstantly() public {
        _instant(abi.encodeCall(MovvaReserve.setGuardian, (stranger)));
        assertEq(reserve.guardian(), stranger);
        vm.prank(gov);
        vm.expectRevert(DelayedGovernance.ZeroAddress.selector);
        reserve.setGuardian(address(0));
    }

    function test_ANewTreasurerWaitsRevokingDoesNot() public {
        address t2 = makeAddr("treasurer2");
        _mustSchedule(abi.encodeCall(MovvaReserve.setTreasurer, (t2)));
        assertEq(reserve.treasurer(), t2);
        _instant(abi.encodeCall(MovvaReserve.setTreasurer, (address(0))));
        _warp(0);
        _mint(1_000 * U);
        vm.prank(t2);
        vm.expectRevert(MovvaReserve.NotTreasurer.selector);
        reserve.withdrawToHedge(1);
    }

    function test_TheHedgeTreasuryAndFeeRecipientWait() public {
        address h2 = makeAddr("hedge2");
        _mustSchedule(abi.encodeCall(MovvaReserve.setHedgeTreasury, (h2)));
        assertEq(reserve.hedgeTreasury(), h2);
        _mustSchedule(abi.encodeCall(MovvaReserve.setFeeRecipient, (h2)));
        assertEq(reserve.feeRecipient(), h2);
        bytes[2] memory zero =
            [abi.encodeCall(MovvaReserve.setHedgeTreasury, (address(0))), abi.encodeCall(MovvaReserve.setFeeRecipient, (address(0)))];
        for (uint256 i; i < 2; ++i) {
            vm.prank(gov);
            reserve.schedule(zero[i]);
        }
        vm.warp(block.timestamp + DELAY);
        for (uint256 i; i < 2; ++i) {
            vm.prank(gov);
            vm.expectRevert(DelayedGovernance.ZeroAddress.selector);
            reserve.execute(zero[i]);
        }
    }

    function test_RaisingAFeeWaitsLoweringDoesNotAndTheCapsHold() public {
        _mustSchedule(abi.encodeCall(MovvaReserve.setFees, (100, 100)));
        assertEq(reserve.mintFeeBps(), 100);
        assertEq(reserve.redeemFeeBps(), 100);
        _instant(abi.encodeCall(MovvaReserve.setFees, (50, 100)));
        _mustSchedule(abi.encodeCall(MovvaReserve.setFees, (60, 90))); // one up is enough to wait
        _instant(abi.encodeCall(MovvaReserve.setFees, (10, 20)));
        _mustSchedule(abi.encodeCall(MovvaReserve.setFees, (10, 21)));

        // Above a hard cap, not even through the delay.
        bytes[2] memory over =
            [abi.encodeCall(MovvaReserve.setFees, (101, 0)), abi.encodeCall(MovvaReserve.setFees, (0, 101))];
        for (uint256 i; i < 2; ++i) {
            vm.prank(gov);
            reserve.schedule(over[i]);
        }
        vm.warp(block.timestamp + DELAY);
        for (uint256 i; i < 2; ++i) {
            vm.prank(gov);
            vm.expectRevert(MovvaReserve.FeeTooHigh.selector);
            reserve.execute(over[i]);
        }
    }

    /// A floor protects by being high: lowering one waits, raising one does not.
    function test_TheDefaultsAreTheSizedOnesAndInOrder() public view {
        assertEq(reserve.targetCollateralRatioBps(), 10_800);
        assertEq(reserve.minWithdrawCollateralRatioBps(), 10_300);
        assertEq(reserve.minMintCollateralRatioBps(), 10_000);
        assertEq(reserve.hedgeLimitBps(), 800);
        assertLe(reserve.minMintCollateralRatioBps(), reserve.minWithdrawCollateralRatioBps());
        assertLe(reserve.minWithdrawCollateralRatioBps(), reserve.targetCollateralRatioBps());
    }

    function test_LoweringACollateralRatioWaitsRaisingDoesNot() public {
        _instant(abi.encodeCall(MovvaReserve.setCollateralRatios, (11_000, 10_100, 10_500)));
        assertEq(reserve.targetCollateralRatioBps(), 11_000);
        assertEq(reserve.minMintCollateralRatioBps(), 10_100);
        assertEq(reserve.minWithdrawCollateralRatioBps(), 10_500);
        _mustSchedule(abi.encodeCall(MovvaReserve.setCollateralRatios, (10_900, 10_100, 10_500)));
        _mustSchedule(abi.encodeCall(MovvaReserve.setCollateralRatios, (10_900, 10_000, 10_500)));
        _mustSchedule(abi.encodeCall(MovvaReserve.setCollateralRatios, (10_900, 10_000, 10_300)));
        _mustSchedule(abi.encodeCall(MovvaReserve.setCollateralRatios, (11_000, 10_000, 10_200))); // mixed waits
    }

    /// Each way of breaking mint floor <= withdraw floor <= target reverts. These only RAISE ratios, so
    /// they take the instant path: the rule, not the delay, is what refuses them.
    function test_RatiosOutOfOrderAreRefused() public {
        bytes[3] memory calls = [
            // the mint floor above the withdraw floor
            abi.encodeCall(MovvaReserve.setCollateralRatios, (10_800, 10_400, 10_300)),
            // the withdraw floor above the target
            abi.encodeCall(MovvaReserve.setCollateralRatios, (10_800, 10_000, 10_900)),
            // the mint floor above the target (and so above the withdraw floor)
            abi.encodeCall(MovvaReserve.setCollateralRatios, (10_800, 10_900, 10_500))
        ];
        for (uint256 i; i < 3; ++i) {
            vm.prank(gov);
            (bool ok, bytes memory ret) = address(reserve).call(calls[i]);
            assertFalse(ok, "out of order went through");
            assertEq(ret, abi.encodeWithSelector(MovvaReserve.RatiosOutOfOrder.selector));
        }
        assertEq(reserve.targetCollateralRatioBps(), 10_800, "nothing changed");
        assertEq(reserve.minMintCollateralRatioBps(), 10_000);
        assertEq(reserve.minWithdrawCollateralRatioBps(), 10_300);
    }

    /// Through the delay too, re-checked when the change executes. The first proposal - target 102%
    /// under a 105% withdraw floor - is exactly such a change, and can no longer be made.
    function test_TheFirstProposalIsRefusedThroughTheDelay() public {
        bytes memory call = abi.encodeCall(MovvaReserve.setCollateralRatios, (10_200, 10_000, 10_500));
        vm.prank(gov);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, MovvaReserve.setCollateralRatios.selector));
        reserve.setCollateralRatios(10_200, 10_000, 10_500);
        vm.prank(gov);
        reserve.schedule(call);
        vm.warp(block.timestamp + DELAY);
        vm.prank(gov);
        vm.expectRevert(MovvaReserve.RatiosOutOfOrder.selector);
        reserve.execute(call);
    }

    /// Equal values are in order: all three at 108% instantly (raising two floors), all three at 100%
    /// through the delay (lowering two), and the classification is unchanged by the rule.
    function test_EqualRatiosAreAllowed() public {
        _instant(abi.encodeCall(MovvaReserve.setCollateralRatios, (10_800, 10_800, 10_800)));
        assertEq(reserve.minMintCollateralRatioBps(), 10_800);
        assertEq(reserve.minWithdrawCollateralRatioBps(), 10_800);
        _mustSchedule(abi.encodeCall(MovvaReserve.setCollateralRatios, (10_000, 10_000, 10_000)));
        assertEq(reserve.targetCollateralRatioBps(), 10_000);
        assertEq(reserve.minWithdrawCollateralRatioBps(), 10_000);
        _instant(abi.encodeCall(MovvaReserve.setCollateralRatios, (10_800, 10_000, 10_300)));
    }

    function test_NoRatioBelowOneHundredPercent() public {
        bytes memory call = abi.encodeCall(MovvaReserve.setCollateralRatios, (9_999, 9_999, 9_999));
        vm.prank(gov);
        reserve.schedule(call);
        vm.warp(block.timestamp + DELAY);
        vm.prank(gov);
        vm.expectRevert(MovvaReserve.BadBps.selector);
        reserve.execute(call);
    }

    function test_RaisingALimitWaitsLoweringDoesNot() public {
        _instant(abi.encodeCall(MovvaReserve.setLimits, (1_000e18, 100)));
        assertEq(reserve.supplyCap(), 1_000e18);
        assertEq(reserve.hedgeLimitBps(), 100);
        _mustSchedule(abi.encodeCall(MovvaReserve.setLimits, (1_001e18, 100)));
        _mustSchedule(abi.encodeCall(MovvaReserve.setLimits, (1_001e18, 101)));
        bytes memory bad = abi.encodeCall(MovvaReserve.setLimits, (0, 10_001));
        vm.prank(gov);
        reserve.schedule(bad);
        vm.warp(block.timestamp + DELAY);
        vm.prank(gov);
        vm.expectRevert(MovvaReserve.BadBps.selector);
        reserve.execute(bad);
    }

    function test_RepointingAnOracleWaitsTighteningAnAgeDoesNot() public {
        _instant(abi.encodeCall(MovvaReserve.setOracle, (address(feed), address(fx), USDT_USD_MAX_AGE - 1, FX_MAX_AGE - 1)));
        assertEq(reserve.usdtUsdMaxAge(), USDT_USD_MAX_AGE - 1);
        _mustSchedule(abi.encodeCall(MovvaReserve.setOracle, (address(feed), address(fx), USDT_USD_MAX_AGE, FX_MAX_AGE - 1)));
        SettableFx other = new SettableFx();
        _mustSchedule(abi.encodeCall(MovvaReserve.setOracle, (address(feed), address(other), USDT_USD_MAX_AGE, FX_MAX_AGE)));
        assertEq(address(reserve.fxOracle()), address(other));
        FxTestFeed f2 = new FxTestFeed(1e8, 8);
        _mustSchedule(abi.encodeCall(MovvaReserve.setOracle, (address(f2), address(other), USDT_USD_MAX_AGE, FX_MAX_AGE)));
        assertEq(address(reserve.usdtUsdFeed()), address(f2));
        vm.prank(gov);
        vm.expectRevert(MovvaReserve.BadMaxAge.selector);
        reserve.setOracle(address(f2), address(other), 0, FX_MAX_AGE);
    }

    /// A new vault waits; removing one is instant, but only once it is empty, so no value leaves the books.
    function test_TheYieldVaultChangesOnlyWhenEmpty() public {
        _mint(1_000 * U);
        vm.prank(gov);
        vm.expectRevert(MovvaReserve.VaultNotEmpty.selector);
        reserve.setYieldVault(address(0));

        _instant(abi.encodeCall(MovvaReserve.pullFromVault, (type(uint256).max)));
        assertEq(usdt.balanceOf(address(reserve)), 1_000 * U);
        assertTrue(reserve.vaultDepositsPaused(), "pulling also stops the next intake sweeping it back");
        _instant(abi.encodeCall(MovvaReserve.setYieldVault, (address(0))));
        assertEq(address(reserve.yieldVault()), address(0));
        assertEq(reserve.totalUsdt(), 1_000 * U);

        YieldVault v2 = new YieldVault(IERC20(address(usdt)), "v2", "v2", gov, guardian, keeper, 1e15, 100, DELAY);
        _mustSchedule(abi.encodeCall(MovvaReserve.setYieldVault, (address(v2))));
        MovvaReserve noVault = new MovvaReserve(_config());
        vm.prank(gov);
        vm.expectRevert(MovvaReserve.NoVault.selector);
        noVault.pullFromVault(1);

        StataLike wrongAsset = new StataLike(IERC20(address(movva)));
        bytes memory call = abi.encodeCall(MovvaReserve.setYieldVault, (address(wrongAsset)));
        _instant(abi.encodeCall(MovvaReserve.setYieldVault, (address(0))));
        vm.prank(gov);
        reserve.schedule(call);
        vm.warp(block.timestamp + DELAY);
        vm.prank(gov);
        vm.expectRevert(MovvaReserve.AssetMismatch.selector);
        reserve.execute(call);
    }

    function test_VaultDepositsPauseAndResumeInstantly() public {
        _instant(abi.encodeCall(MovvaReserve.setVaultDepositsPaused, (true)));
        _mint(1_000 * U);
        assertEq(usdt.balanceOf(address(reserve)), 1_000 * U);
        _instant(abi.encodeCall(MovvaReserve.setVaultDepositsPaused, (false)));
        _mint(1 * U);
        assertEq(usdt.balanceOf(address(reserve)), 0);
    }

    function test_PullingFromTheVaultIsRefusedWhileFrozen() public {
        _mint(1_000 * U);
        usdt.addBlackList(address(reserve));
        vm.prank(gov);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.FrozenByAssetIssuer.selector, address(reserve)));
        reserve.pullFromVault(1);
    }

    /// Only governance setters can be queued: the self-call cannot be aimed at money.
    function test_OnlyGovernanceFunctionsCanBeScheduled() public {
        bytes[5] memory calls = [
            abi.encodeCall(MovvaReserve.mint, (1, gov, 0)),
            abi.encodeCall(MovvaReserve.withdrawToHedge, (1)),
            abi.encodeCall(MovvaReserve.pullFromVault, (1)),
            abi.encodeCall(MovvaReserve.pauseMint, ()),
            abi.encodeCall(MovvaReserve.recapitalize, (1))
        ];
        for (uint256 i; i < calls.length; ++i) {
            vm.prank(gov);
            vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.NotDelayable.selector, bytes4(calls[i])));
            reserve.schedule(calls[i]);
        }
    }

    function test_AStrangerCannotSetAnything() public {
        bytes[10] memory calls = [
            abi.encodeCall(MovvaReserve.setGateway, (stranger, true)),
            abi.encodeCall(MovvaReserve.setTreasurer, (stranger)),
            abi.encodeCall(MovvaReserve.setHedgeTreasury, (stranger)),
            abi.encodeCall(MovvaReserve.setFeeRecipient, (stranger)),
            abi.encodeCall(MovvaReserve.setFees, (0, 0)),
            abi.encodeCall(MovvaReserve.setCollateralRatios, (20_000, 20_000, 20_000)),
            abi.encodeCall(MovvaReserve.setLimits, (0, 0)),
            abi.encodeCall(MovvaReserve.setYieldVault, (address(0))),
            abi.encodeCall(MovvaReserve.setVaultDepositsPaused, (true)),
            abi.encodeCall(MovvaReserve.resumeMint, ())
        ];
        for (uint256 i; i < calls.length; ++i) {
            vm.prank(stranger);
            (bool ok, bytes memory ret) = address(reserve).call(calls[i]);
            assertFalse(ok);
            assertEq(bytes4(ret), DelayedGovernance.NotGovernor.selector);
        }
    }

    function test_TheConstructorRefusesMissingAddressesAndAges() public {
        MovvaReserve.Config memory c = _config();
        c.hedgeTreasury = address(0);
        vm.expectRevert(DelayedGovernance.ZeroAddress.selector);
        new MovvaReserve(c);
        c = _config();
        c.feeRecipient = address(0);
        vm.expectRevert(DelayedGovernance.ZeroAddress.selector);
        new MovvaReserve(c);
        c = _config();
        c.usdtUsdFeed = address(0);
        vm.expectRevert(DelayedGovernance.ZeroAddress.selector);
        new MovvaReserve(c);
        c = _config();
        c.fxMaxAge = 0;
        vm.expectRevert(MovvaReserve.BadMaxAge.selector);
        new MovvaReserve(c);
        c = _config();
        c.governanceDelay = 1 hours;
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.BadGovernanceDelay.selector, 1 hours));
        new MovvaReserve(c);
    }

    /// SRM1-21: at zero the hedge queue would be an instant bypass of the daily limit. The constructor
    /// now enforces DeployMovva's own 1 hour to 30 days, so a hand-rolled deployment is held to it too.
    function test_TheConstructorBoundsTheHedgeQueueDelay() public {
        MovvaReserve.Config memory c = _config();
        uint64[4] memory bad = [uint64(0), 1 hours - 1, 30 days + 1, type(uint64).max];
        for (uint256 i; i < bad.length; ++i) {
            c.hedgeQueueDelay = bad[i];
            vm.expectRevert(MovvaReserve.BadHedgeQueueDelay.selector);
            new MovvaReserve(c);
        }
        c.hedgeQueueDelay = 1 hours;
        assertEq(new MovvaReserve(c).HEDGE_QUEUE_DELAY(), 1 hours);
        c.hedgeQueueDelay = 30 days;
        assertEq(new MovvaReserve(c).HEDGE_QUEUE_DELAY(), 30 days);
    }

    /// SRM1-20: tightening a max age is instant, so a max age of one second froze every redemption
    /// at once. Now neither age can go under its floor, by any path: constructor, instant or scheduled.
    function test_MaxAgesHaveFloorsOnEveryPath() public {
        MovvaReserve.Config memory c = _config();
        c.usdtUsdMaxAge = 1 days - 1;
        vm.expectRevert(MovvaReserve.BadMaxAge.selector);
        new MovvaReserve(c);
        c = _config();
        c.fxMaxAge = 15 minutes - 1;
        vm.expectRevert(MovvaReserve.BadMaxAge.selector);
        new MovvaReserve(c);

        vm.startPrank(gov);
        vm.expectRevert(MovvaReserve.BadMaxAge.selector);
        reserve.setOracle(address(feed), address(fx), 1, 1);
        vm.expectRevert(MovvaReserve.BadMaxAge.selector);
        reserve.setOracle(address(feed), address(fx), 1 days - 1, FX_MAX_AGE);
        vm.expectRevert(MovvaReserve.BadMaxAge.selector);
        reserve.setOracle(address(feed), address(fx), USDT_USD_MAX_AGE, 15 minutes - 1);
        // The floors themselves are a tightening, so instant.
        reserve.setOracle(address(feed), address(fx), 1 days, 15 minutes);
        vm.stopPrank();
        assertEq(reserve.usdtUsdMaxAge(), 1 days);
        assertEq(reserve.fxMaxAge(), 15 minutes);
        // A scheduled change is held to them too.
        bytes memory low = abi.encodeCall(MovvaReserve.setOracle, (address(feed), address(fx), 1 days, 1));
        vm.prank(gov);
        reserve.schedule(low);
        vm.warp(block.timestamp + DELAY);
        vm.prank(gov);
        vm.expectRevert(MovvaReserve.BadMaxAge.selector);
        reserve.execute(low);
    }

    function testFuzz_NoMaxAgeUnderItsFloorIsEverStored(uint64 feedAge, uint64 fxAge) public {
        vm.prank(gov);
        try reserve.setOracle(address(feed), address(fx), feedAge, fxAge) {
            assertGe(feedAge, reserve.MIN_USDT_USD_MAX_AGE());
            assertGe(fxAge, reserve.MIN_FX_MAX_AGE());
        } catch {}
        assertGe(reserve.usdtUsdMaxAge(), 1 days);
        assertGe(reserve.fxMaxAge(), 15 minutes);
    }
}

/**
 * Who signs the rate the reserve mints at. The reserve delays repointing its FX leg; the leg now
 * delays changing who signs it. Its governor - here the same multisig, compromised - cannot add a
 * key of its own and cut the threshold to one without publishing both for GOVERNANCE_DELAY, and
 * until the delay ends every mint and redemption is priced by the publishers already there.
 */
contract MovvaFxLegGovernanceTest is MovvaBase {
    uint256 internal constant THIEF = 0x7415F;

    /// The thief signs `e6` alone, one sequence ahead of the honest publishers.
    function _thiefSigns(uint256 e6) internal view returns (uint64 at, uint64 seq, bytes[] memory sigs) {
        (at, seq) = (uint64(block.timestamp), fxSeq + 1);
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(THIEF, fx.digest(e6, at, seq));
        sigs = new bytes[](1);
        sigs[0] = abi.encodePacked(r, s, v);
    }

    function test_APendingPublisherChangeCannotMoveTheMintPriceBeforeTheDelay() public {
        address thief = vm.addr(THIEF);
        bytes memory add = abi.encodeCall(SignedPriceOracle.setPublisher, (thief, true));
        bytes memory cut = abi.encodeCall(SignedPriceOracle.setThreshold, (1));

        // 1. Neither change can be made directly. Scheduled, both are public from this block.
        vm.startPrank(gov);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, SignedPriceOracle.setPublisher.selector)
        );
        fx.setPublisher(thief, true);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, SignedPriceOracle.setThreshold.selector)
        );
        fx.setThreshold(1);
        fx.schedule(add);
        fx.schedule(cut);
        vm.stopPrank();
        uint256 ready = fx.readyAt(keccak256(add));
        assertEq(ready, block.timestamp + DELAY);

        // 2. The thief's R$ 100 per dollar - a 1,752% over-mint - cannot even be submitted.
        (uint64 at, uint64 seq, bytes[] memory sigs) = _thiefSigns(100e6);
        vm.expectRevert(abi.encodeWithSelector(SignedPriceOracle.NotEnoughSignatures.selector, 1, 2));
        fx.submit(100e6, at, seq, sigs);

        // 3. One second before the delay ends, a gateway mints at the publishers' R$ 5,40, to the wei:
        //    1,000 USDT at $1,00 x 5.4 = 5,400 Movva. Executing early is refused.
        _warp(DELAY - 1);
        assertEq(_rate(), 5.4e18);
        assertEq(_mint(1_000 * U), 5_400e18, "priced by the honest quorum while the change is pending");
        vm.prank(gov);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.NotReadyYet.selector, keccak256(add), ready));
        fx.execute(add);
        (at, seq, sigs) = _thiefSigns(100e6);
        vm.expectRevert(abi.encodeWithSelector(SignedPriceOracle.NotEnoughSignatures.selector, 1, 2));
        fx.submit(100e6, at, seq, sigs);

        // The notice was usable: a holder exits at the honest rate inside the window.
        assertEq(_redeem(5_400e18), 1_000 * U, "redeemed at par before the change could run");

        // 4. The delay is notice, not a veto: nobody cancelled, so once it ends the governor can run
        //    both, and only from then does a rate signed by the thief alone price a mint.
        vm.warp(ready);
        vm.startPrank(gov);
        fx.execute(add);
        fx.execute(cut);
        vm.stopPrank();
        feed.set(1e8, block.timestamp);
        (at, seq, sigs) = _thiefSigns(10e6);
        fx.submit(10e6, at, seq, sigs);
        fxSeq = seq;
        assertEq(_rate(), 10e18);
        assertEq(_mint(1_000 * U), 10_000e18, "the thief's rate, but only after the public delay");
    }
}
