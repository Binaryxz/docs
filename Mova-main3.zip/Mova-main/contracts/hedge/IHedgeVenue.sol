// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";

/**
 * @title IHedgeVenue
 * @notice What the reserve's delta-neutral hedge sleeve needs from a venue, and nothing more. The
 *         venue is NOT chosen (docs/delta-neutral.md §12): every real venue - an on-chain perps
 *         exchange, a CEX behind an attested bridge, Hyperliquid through HyperCore - gets an adapter
 *         contract that implements this, and `HedgeSubWallet` is written against this alone.
 *
 * ## The account is the caller
 *
 * Every mutating function acts on `msg.sender`'s account: the sub-wallet contract IS the account on
 * the venue, so no API key or agent key exists that could trade it. An adapter for a venue whose
 * accounts are keyed off-chain must keep that property on its side (the adapter contract owns the
 * venue account and only ever acts for the sub-wallet that called it).
 *
 * ## Units
 *
 *  - Money (cash, margin, equity) is in the collateral token's own base units, so it compares
 *    directly with `collateral().balanceOf`. Equity is signed: a bankrupt account is negative.
 *  - Asset quantities (spot balances, perp sizes) are WAD: 1e18 = one whole unit of the asset.
 *    Perp size is signed; negative is short.
 *  - Prices are WAD USD per whole unit (2,500 USD = 2_500e18), whatever the oracle's decimals.
 *  - Funding is a rate per HOUR, WAD (1e18 = 100% per hour), positive when longs pay shorts - what
 *    the short leg EARNS - whatever the venue's own funding interval.
 *
 * ## Orders
 *
 * Every order is immediate-or-cancel against its limit price: it MUST NOT fill at a worse price than
 * the limit; it MAY fill partially and returns what filled; it MAY revert when nothing can fill. A
 * sub-wallet checks the returned fill against its own limit and size anyway. `reducePerp` is
 * reduce-only by construction and never opens or flips a position.
 *
 * Prices are ALL-IN: the reported `avgPx`, and the limit it is held to, include every fee of the
 * fill. That is what lets a caller bound the whole cost of an order by its limit alone. An adapter
 * for a venue that charges fees separately must fold them into both before comparing.
 *
 * The interface is SYNCHRONOUS: an order has filled (or not) when the call returns. A venue that
 * settles later (an order book on another chain, a keeper-executed perp DEX) needs an adapter that
 * hides that, or a sub-wallet with a settle window like `HyperCoreDeltaNeutralVault`'s.
 *
 * ## Reads
 *
 * A read MUST revert rather than return zeros it does not know: an account read as empty because a
 * venue could not answer would look perfectly hedged (the same rule as the off-chain `HedgeVenue`,
 * packages/yield/src/hedge-risk/types.ts). `prices` returns the venue's own timestamp so the caller
 * judges freshness.
 */
interface IHedgeVenue {
    /// @notice One market's prices, WAD USD per whole unit.
    struct Prices {
        /// The perp mark: what positions are valued, margined and liquidated at.
        uint256 mark;
        /// The index (oracle) price the venue funds against.
        uint256 index;
        /// The spot market's price.
        uint256 spot;
        /// When the index was last updated, unix seconds.
        uint256 updatedAt;
    }

    struct PerpPosition {
        /// WAD, signed: negative is short.
        int256 size;
        /// Average entry price, WAD USD.
        uint256 entryPx;
    }

    /// @notice The account's cross-margin account, in collateral units. Spot balances are NOT in it.
    struct MarginAccount {
        /// Collateral plus unrealised PnL and accrued funding, across every market.
        int256 equity;
        /// Below this the account may be liquidated.
        uint256 maintenance;
        /// What open positions require before new exposure may be added.
        uint256 initial;
        /// What `transferMargin` may move back to cash now.
        uint256 withdrawable;
    }

    /// @notice The stablecoin all money on this venue is denominated and settled in.
    function collateral() external view returns (IERC20);

    /*//////////////////////////////////////////////////////////////
                               COLLATERAL
    //////////////////////////////////////////////////////////////*/

    /// @notice Pull `amount` of `collateral()` from the caller into its cash balance.
    function deposit(uint256 amount) external;

    /// @notice Pay `amount` of the caller's cash balance to the caller.
    function withdraw(uint256 amount) external;

    /// @notice Move money between the caller's cash and its margin account: positive into margin,
    ///         negative back to cash (at most `withdrawable`).
    function transferMargin(int256 amount) external;

    /*//////////////////////////////////////////////////////////////
                                 ORDERS
    //////////////////////////////////////////////////////////////*/

    /// @notice Buy `qty` spot from cash, at no more than `limitPx`.
    function buySpot(bytes32 asset, uint256 qty, uint256 limitPx)
        external
        returns (uint256 filled, uint256 avgPx);

    /// @notice Sell `qty` spot for cash, at no less than `limitPx`.
    function sellSpot(bytes32 asset, uint256 qty, uint256 limitPx)
        external
        returns (uint256 filled, uint256 avgPx);

    /// @notice Grow (or open) a perp position in direction `isLong` by `size`: a long buys at no
    ///         more than `limitPx`, a short sells at no less. Reverts on a position the other way.
    function increasePerp(bytes32 asset, bool isLong, uint256 size, uint256 limitPx)
        external
        returns (uint256 filled, uint256 avgPx);

    /// @notice Shrink the perp position by up to `size`, reduce-only: a short buys back at no more
    ///         than `limitPx`, a long sells at no less.
    function reducePerp(bytes32 asset, uint256 size, uint256 limitPx)
        external
        returns (uint256 filled, uint256 avgPx);

    /*//////////////////////////////////////////////////////////////
                                 READS
    //////////////////////////////////////////////////////////////*/

    /// @notice Collateral the account holds outside its margin account.
    function cash(address account) external view returns (uint256);

    function spotBalance(address account, bytes32 asset) external view returns (uint256);

    function perpPosition(address account, bytes32 asset)
        external
        view
        returns (PerpPosition memory);

    function marginAccount(address account) external view returns (MarginAccount memory);

    /// @notice Reverts for an unknown asset.
    function prices(bytes32 asset) external view returns (Prices memory);

    /// @notice The rate accruing now, per hour, WAD, positive when longs pay shorts.
    function fundingRate(bytes32 asset) external view returns (int256);

    /// @notice The most the venue lets a position be levered, in bps (100_000 = 10x).
    function maxLeverageBps(bytes32 asset) external view returns (uint256);
}

/// @notice The Chainlink AggregatorV3 subset the sleeve reads (the venue simulator's oracle, and the
///         sub-wallet's independent reference price).
interface IHedgePriceFeed {
    function decimals() external view returns (uint8);
    function latestRoundData()
        external
        view
        returns (
            uint80 roundId,
            int256 answer,
            uint256 startedAt,
            uint256 updatedAt,
            uint80 answeredInRound
        );
}
