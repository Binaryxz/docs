// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Script} from "forge-std/Script.sol";
import {console2} from "forge-std/console2.sol";
import {FiatEscrow} from "../ramp/FiatEscrow.sol";
import {OffRampEscrow} from "../ramp/OffRampEscrow.sol";
import {PermissionlessLPRegistry} from "../ramp/PermissionlessLPRegistry.sol";

/**
 * @title DeployPermissionlessRegistry
 * @notice A PermissionlessLPRegistry, and a NEW FiatEscrow / OffRampEscrow pair from the unchanged, audited escrow
 *         code pointing at it, configured exactly as the live pair it runs beside. Design:
 *         docs/permissionless-registry.md. Not run against any live network from this repository's tooling: it is a
 *         dry run (no --broadcast) until the client signs off the parameters there.
 *
 * ## Order, and the one-shot binding
 *
 *  1. The registry, with the live pair's registry as PREDECESSOR (so every bank transaction id it has spent stays
 *     spent), MOVVA as the bond, MIN_BOND, and an UNBONDING_PERIOD derived from the live pair's dispute timeout:
 *     DISPUTE_TIMEOUT + RULING_DELAY (1 day) + UNBONDING_MARGIN (4 days) + 1 day, strictly longer than both escrows'
 *     whole dispute window, which `bindEscrows` re-checks on-chain.
 *  2. The escrow pair, each taking the registry's address in its constructor - the reason the registry cannot hold
 *     them as immutables.
 *  3. `bindEscrows(onramp, offramp)` from the same key: the deployer's one power over the registry, spent here. From
 *     this transaction on `escrowsBound()` is true and the registry has no admin of any kind.
 *  4. The pair's own setup, copied from the live pair as DeployEscrowPair copies it (MOVVA's listing and asset cap,
 *     native ETH as listed there, ZKTLS_VERIFIER, ARBITRATORS), then setup closed and the pair handed to the live
 *     pair's governor. The escrows keep their DelayedGovernance: verifiers, arbitrators and assets are theirs, and
 *     unchanged by this registry.
 *
 * Nothing on the live pair or its registry changes. The cutover (suspending LPs on the old registry so it opens no new
 * positions, retiring the old pair) is a separate, governed step: docs/permissionless-registry.md, "Cutover".
 *
 *   OLD_ONRAMP=0x.. OLD_OFFRAMP=0x.. MOVVA_TOKEN=0x.. ZKTLS_VERIFIER=0x.. ARBITRATORS=0x..[,0x..] \
 *   [MIN_BOND=5000000000000000000000] [UNBONDING_PERIOD=<seconds>] \
 *   forge script contracts/script/DeployPermissionlessRegistry.s.sol:DeployPermissionlessRegistry --rpc-url ..
 */
contract DeployPermissionlessRegistry is Script {
    /// @notice R$ 5.000,00: the curated registry's base retail limit (LPRegistry.BASE_CAP_CENTS).
    uint256 public constant DEFAULT_MIN_BOND = 5_000e18;
    uint256 internal constant EIP170 = 24_576;

    struct Deployed {
        PermissionlessLPRegistry registry;
        FiatEscrow onramp;
        OffRampEscrow offramp;
    }

    /// @dev Everything read before the broadcast, in one struct for the stack.
    struct Inputs {
        FiatEscrow oldOn;
        OffRampEscrow oldOff;
        address movva;
        address zktls;
        address[] arbitrators;
        uint256 minBond;
        uint256 unbonding;
        address governor;
    }

    /// @notice The forge-script entry point: everything from the environment (see the header).
    function run() external returns (Deployed memory) {
        Inputs memory p;
        p.oldOn = FiatEscrow(payable(vm.envAddress("OLD_ONRAMP")));
        p.oldOff = OffRampEscrow(payable(vm.envAddress("OLD_OFFRAMP")));
        p.movva = vm.envAddress("MOVVA_TOKEN");
        p.zktls = vm.envAddress("ZKTLS_VERIFIER");
        p.arbitrators = vm.envAddress("ARBITRATORS", ",");
        p.minBond = vm.envOr("MIN_BOND", DEFAULT_MIN_BOND);
        p.unbonding = vm.envOr("UNBONDING_PERIOD", uint256(0));
        return deploy(p);
    }

    /**
     * @notice The same deployment from explicit inputs (the tests call this: the environment is one per process, and
     *         forge runs tests in parallel). `unbonding` zero derives it from the live pair; `governor` is ignored
     *         and read from the live pair.
     */
    function deploy(Inputs memory p) public returns (Deployed memory d) {
        _refuseBadInputs(p.oldOn, p.oldOff, p.movva, p.zktls, p.arbitrators);
        if (p.unbonding == 0) {
            uint256 a = p.oldOn.DISPUTE_TIMEOUT();
            uint256 b = p.oldOff.DISPUTE_TIMEOUT();
            // The longest dispute window of the pair, plus RULING_DELAY, UNBONDING_MARGIN and a day: strictly longer.
            p.unbonding = (a > b ? a : b) + 1 days + 4 days + 1 days;
        }
        p.governor = p.oldOn.governor();

        vm.startBroadcast();
        // The address the transactions come from: msg.sender under forge script, asked rather than assumed so that
        // it also holds when DeployPermissionlessRegistry.t.sol runs the script (as DeployRamp does).
        (, address deployer,) = vm.readCallers();
        d.registry = new PermissionlessLPRegistry(
            p.movva, address(p.oldOn.REGISTRY()), p.minBond, p.unbonding
        );
        d.onramp = _newOnramp(p.oldOn, address(d.registry), deployer);
        d.offramp = _newOfframp(p.oldOff, address(d.registry), deployer);
        d.registry.bindEscrows(address(d.onramp), address(d.offramp));
        _configure(p, d, deployer);
        vm.stopBroadcast();

        _assertDeployed(d, p);
        console2.log("PermissionlessLPRegistry", address(d.registry));
        console2.log("movva FiatEscrow        ", address(d.onramp));
        console2.log("movva OffRampEscrow     ", address(d.offramp));
        console2.log("MIN_BOND (MOVVA wei)    ", p.minBond);
        console2.log("UNBONDING_PERIOD (s)    ", p.unbonding);
    }

    function _newOnramp(FiatEscrow o, address registry, address deployer)
        private
        returns (FiatEscrow)
    {
        return new FiatEscrow(
            address(o.ORACLE()),
            registry,
            o.POOL_ENTRYPOINT(),
            o.POOL(),
            o.BAND_BPS(),
            deployer,
            o.GOVERNANCE_DELAY(),
            o.DISPUTE_TIMEOUT()
        );
    }

    function _newOfframp(OffRampEscrow o, address registry, address deployer)
        private
        returns (OffRampEscrow)
    {
        return new OffRampEscrow(
            address(o.ORACLE()),
            registry,
            o.BAND_BPS(),
            deployer,
            o.GOVERNANCE_DELAY(),
            o.DISPUTE_TIMEOUT()
        );
    }

    /// @dev The pair's own setup, as DeployEscrowPair does it: instant while setup is open, then closed and handed over.
    function _configure(Inputs memory p, Deployed memory d, address deployer) private {
        _copyAsset(address(p.oldOn), address(d.onramp), address(0));
        _copyAsset(address(p.oldOff), address(d.offramp), address(0));
        _copyAsset(address(p.oldOn), address(d.onramp), p.movva);
        _copyAsset(address(p.oldOff), address(d.offramp), p.movva);
        d.onramp.setVerifier(p.zktls, true);
        d.offramp.setVerifier(p.zktls, true);
        for (uint256 i; i < p.arbitrators.length; ++i) {
            d.onramp.setArbitrator(p.arbitrators[i], true);
            d.offramp.setArbitrator(p.arbitrators[i], true);
        }
        d.onramp.completeSetup();
        d.offramp.completeSetup();
        if (p.governor != deployer) {
            d.onramp.transferGovernor(p.governor);
            d.offramp.transferGovernor(p.governor);
        }
    }

    function _refuseBadInputs(
        FiatEscrow oldOn,
        OffRampEscrow oldOff,
        address movva,
        address zktls,
        address[] memory arbitrators
    ) private view {
        require(
            address(oldOn).code.length > 0 && address(oldOff).code.length > 0,
            "OLD_ONRAMP / OLD_OFFRAMP: no code"
        );
        require(oldOn.REGISTRY() == oldOff.REGISTRY(), "the live pair is on two registries");
        require(oldOn.governor() == oldOff.governor(), "the live pair has two governors");
        require(movva.code.length > 0, "MOVVA_TOKEN: no code");
        require(
            oldOn.allowedVerifier(zktls) && oldOff.allowedVerifier(zktls),
            "ZKTLS_VERIFIER: not allowed on the live pair"
        );
        (,, bool onEnabled) = _assetOf(address(oldOn), movva);
        (,, bool offEnabled) = _assetOf(address(oldOff), movva);
        require(onEnabled && offEnabled, "MOVVA_TOKEN: not listed on the live pair");
        require(
            arbitrators.length > 0, "ARBITRATORS: none; every dispute would wait out the timeout"
        );
        for (uint256 i; i < arbitrators.length; ++i) {
            require(arbitrators[i] != address(0), "ARBITRATORS: zero address");
            for (uint256 j; j < i; ++j) {
                require(arbitrators[i] != arbitrators[j], "ARBITRATORS: duplicate");
            }
        }
    }

    function _copyAsset(address from, address to, address asset) private {
        (address oracle, uint8 dec, bool enabled) = _assetOf(from, asset);
        require(dec != 0, "the live pair never configured this asset");
        FiatEscrow(payable(to)).setAsset(asset, oracle, dec, enabled);
        uint256 cap = FiatEscrow(payable(from)).assetCap(asset);
        if (cap != 0) FiatEscrow(payable(to)).setAssetCap(asset, cap);
    }

    function _assertDeployed(Deployed memory d, Inputs memory p) private view {
        PermissionlessLPRegistry r = d.registry;
        require(r.escrowsBound(), "registry: escrows not bound");
        require(
            r.fiatEscrow() == address(d.onramp) && r.offRampEscrow() == address(d.offramp),
            "registry: wrong pair"
        );
        require(address(r.MOVVA()) == p.movva, "registry: wrong bond token");
        require(
            address(r.PREDECESSOR()) == address(p.oldOn.REGISTRY()), "registry: wrong predecessor"
        );
        require(
            r.MIN_BOND() == p.minBond && r.UNBONDING_PERIOD() == p.unbonding,
            "registry: wrong parameters"
        );
        require(
            r.UNBONDING_PERIOD()
                > uint256(d.onramp.DISPUTE_TIMEOUT()) + d.offramp.RULING_DELAY() + r.UNBONDING_MARGIN()
                && r.UNBONDING_PERIOD()
                    > uint256(d.offramp.DISPUTE_TIMEOUT()) + d.offramp.RULING_DELAY() + r.UNBONDING_MARGIN(),
            "registry: unbonding not longer than the dispute window"
        );
        _assertPair(address(p.oldOn), address(d.onramp), address(r), p, "on-ramp");
        _assertPair(address(p.oldOff), address(d.offramp), address(r), p, "off-ramp");
        require(
            d.onramp.POOL_ENTRYPOINT() == p.oldOn.POOL_ENTRYPOINT()
                && d.onramp.POOL() == p.oldOn.POOL(),
            "on-ramp: not on the live pair's pool"
        );
        require(d.onramp.ORACLE() == p.oldOn.ORACLE(), "on-ramp: oracle differs");
        require(d.offramp.ORACLE() == p.oldOff.ORACLE(), "off-ramp: oracle differs");
        require(address(r).code.length <= EIP170, "registry: over EIP-170");
        require(address(d.onramp).code.length <= EIP170, "on-ramp: over EIP-170");
        require(address(d.offramp).code.length <= EIP170, "off-ramp: over EIP-170");
    }

    /// @dev Both escrows' getters share selectors (assets, assetCap, governor, ...), so FiatEscrow's serve both.
    function _assertPair(
        address from,
        address to,
        address registry,
        Inputs memory p,
        string memory name
    ) private view {
        FiatEscrow o = FiatEscrow(payable(from));
        FiatEscrow n = FiatEscrow(payable(to));
        require(address(n.REGISTRY()) == registry, string.concat(name, ": not on the new registry"));
        require(
            n.governor() == p.governor, string.concat(name, ": not handed to the live governor")
        );
        require(n.setupComplete(), string.concat(name, ": setup still open"));
        require(
            n.GOVERNANCE_DELAY() == o.GOVERNANCE_DELAY(),
            string.concat(name, ": governance delay differs")
        );
        require(
            n.DISPUTE_TIMEOUT() == o.DISPUTE_TIMEOUT(),
            string.concat(name, ": dispute timeout differs")
        );
        require(n.BAND_BPS() == o.BAND_BPS(), string.concat(name, ": band differs"));
        require(n.allowedVerifier(p.zktls), string.concat(name, ": verifier not allowed"));
        require(
            _sameAsset(from, to, address(0)) && _sameAsset(from, to, p.movva),
            string.concat(name, ": an asset listing or cap differs")
        );
        for (uint256 i; i < p.arbitrators.length; ++i) {
            require(
                n.arbitratorSince(p.arbitrators[i]) != 0,
                string.concat(name, ": an arbitrator is missing")
            );
        }
    }

    function _sameAsset(address from, address to, address a) private view returns (bool) {
        (address oo, uint8 od, bool oe) = _assetOf(from, a);
        (address no, uint8 nd, bool ne) = _assetOf(to, a);
        return oo == no && od == nd && oe == ne
            && FiatEscrow(payable(from)).assetCap(a) == FiatEscrow(payable(to)).assetCap(a);
    }

    function _assetOf(address escrow, address token)
        private
        view
        returns (address oracle, uint8 dec, bool enabled)
    {
        (bool ok, bytes memory ret) =
            escrow.staticcall(abi.encodeWithSignature("assets(address)", token));
        require(ok && ret.length >= 96, "assets(): unreadable");
        (oracle, dec, enabled) = abi.decode(ret, (address, uint8, bool));
    }
}
