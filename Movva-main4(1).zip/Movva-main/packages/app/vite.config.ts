/**
 * The Movva web app: Vite, React, no framework plugin (esbuild compiles the JSX).
 *
 *  - **The libraries' browser entries.** @mova/wallet, @mova/viewing-key and @mova/ramp map the `browser` condition of
 *    their package.json "exports" (and "imports") to entries without their servers and Node-only modules, and Vite
 *    resolves with that condition: nothing here aliases a Node built-in. One alias is left, for a third-party import:
 *    the Privacy Pools SDK's `import 'assert'` (src/shims/assert.ts); its `import 'buffer'` is the npm package.
 *  - **The circuit artifacts are served by the app** under `circuits/sdk/artifacts/`, copied from the Privacy
 *    Pools SDK the Node prover uses (the same bytes), and cached by the service worker after first use. The withdrawal
 *    prover's worker passes that URL to `SdkWithdrawalProver`; audit grants fetch the commitment circuit from it.
 *  - **Workers are ES modules**, so the withdrawal prover (src/wallet/prover.worker.ts) can import the SDK.
 *  - **The service worker is built from src/sw/worker.ts** into dist/sw.js, one classic script (IIFE), after the app:
 *    it imports the co-signer client's push handlers, and only what they use is kept (no module side effects).
 */
import { createRequire } from 'node:module';
import { existsSync, readFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { build as viteBuild, defineConfig, type Plugin } from 'vite';

const here = dirname(fileURLToPath(import.meta.url));
const GATEWAY = process.env.MOVA_GATEWAY ?? 'http://127.0.0.1:8981';

const ARTIFACTS = ['commitment.wasm', 'commitment.zkey', 'commitment.vkey', 'withdraw.wasm', 'withdraw.zkey', 'withdraw.vkey'];

/** The SDK's artifacts directory, found from its entry point as packages/viewing-key does. */
function sdkArtifactsDir(): string {
  const require_ = createRequire(import.meta.url);
  let dir = dirname(require_.resolve('@0xbow/privacy-pools-core-sdk'));
  for (let i = 0; i < 6; i++) {
    for (const candidate of [join(dir, 'artifacts'), join(dir, 'node', 'artifacts')]) {
      if (ARTIFACTS.every((a) => existsSync(join(candidate, a)))) return candidate;
    }
    dir = dirname(dir);
  }
  throw new Error('circuit artifacts not found in @0xbow/privacy-pools-core-sdk');
}

function movaCircuits(): Plugin {
  const dir = sdkArtifactsDir();
  const type = (name: string) => (name.endsWith('.wasm') ? 'application/wasm' : name.endsWith('.vkey') ? 'application/json' : 'application/octet-stream');
  return {
    name: 'mova-circuits',
    configureServer(server) {
      server.middlewares.use('/circuits/sdk/artifacts/', (req, res, next) => {
        const name = (req.url ?? '').replace(/^\//, '').split('?')[0];
        if (!ARTIFACTS.includes(name)) return next();
        res.setHeader('content-type', type(name));
        res.end(readFileSync(join(dir, name)));
      });
    },
    generateBundle() {
      for (const name of ARTIFACTS) {
        this.emitFile({ type: 'asset', fileName: `circuits/sdk/artifacts/${name}`, source: readFileSync(join(dir, name)) });
      }
    },
  };
}

/** dist/sw.js from src/sw/worker.ts: its own build, a single classic script, since a service worker registered as one cannot import. */
function movaServiceWorker(): Plugin {
  let outDir = resolve(here, 'dist');
  return {
    name: 'mova-service-worker',
    apply: 'build',
    configResolved(config) {
      outDir = resolve(config.root, config.build.outDir);
    },
    async closeBundle() {
      await viteBuild({
        configFile: false, root: here, logLevel: 'warn', publicDir: false,
        define: { 'process.env.NODE_ENV': JSON.stringify('production') },
        resolve: { alias: [{ find: /^assert$/, replacement: resolve(here, 'src/shims/assert.ts') }] },
        build: {
          outDir, emptyOutDir: false, target: 'es2022', reportCompressedSize: false, copyPublicDir: false,
          lib: { entry: resolve(here, 'src/sw/worker.ts'), formats: ['iife'], name: 'movvaServiceWorker', fileName: () => 'sw.js' },
          rollupOptions: { treeshake: { moduleSideEffects: false } },
        },
      });
    },
  };
}

/**
 * v2.0 I-54: a Content-Security-Policy on the built page (not the dev server, whose HMR injects inline scripts).
 * Scripts only from the app's origin, plus WebAssembly for the prover; connections to the app's origin, https/wss
 * endpoints and a local stack (the deployment's endpoints are https outside localhost, M-23); no plugins, no <base>,
 * no form posts. `frame-ancestors` cannot be set from a meta tag: the host's header must add it.
 */
export const CSP = [
  "default-src 'self'",
  "script-src 'self' 'wasm-unsafe-eval'",
  "worker-src 'self' blob:",
  "connect-src 'self' https: wss: http://localhost:* http://127.0.0.1:*",
  "img-src 'self' data: blob:",
  "style-src 'self' 'unsafe-inline'",
  "font-src 'self' data:",
  "object-src 'none'",
  "base-uri 'none'",
  "form-action 'none'",
].join('; ');

function movaCsp(): Plugin {
  return {
    name: 'mova-csp',
    apply: 'build',
    transformIndexHtml: () => [{ tag: 'meta', attrs: { 'http-equiv': 'Content-Security-Policy', content: CSP }, injectTo: 'head-prepend' }],
  };
}

export default defineConfig({
  root: here,
  base: './',
  plugins: [movaCircuits(), movaServiceWorker(), movaCsp()],
  resolve: {
    alias: [{ find: /^assert$/, replacement: resolve(here, 'src/shims/assert.ts') }],
  },
  worker: { format: 'es' },
  build: { target: 'es2022', outDir: 'dist', emptyOutDir: true, chunkSizeWarningLimit: 6_000, reportCompressedSize: false },
  server: { port: 8980, strictPort: true, proxy: { '/api': GATEWAY } },
  preview: { port: 8987, strictPort: true, proxy: { '/api': GATEWAY } },
});
