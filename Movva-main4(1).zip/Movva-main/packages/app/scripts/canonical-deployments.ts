/**
 * Generates src/lib/canonical-deployments.generated.ts, the contract addresses the bundle trusts per chain (audit
 * M-23), from the repository's deployment records. `npm run build -w @mova/app` runs it before Vite, so the bundle is
 * always built from the records. test/canonical-deployments.test.ts fails when the committed file and the records
 * disagree.
 *
 *   npx tsx packages/app/scripts/canonical-deployments.ts           # write the file
 *   npx tsx packages/app/scripts/canonical-deployments.ts --check   # exit 1 if it is stale
 *
 * Sepolia (11155111) comes from three records, each required to be live with no failed check:
 *   deployments/sepolia-movva-v6-rail.json      token, reserve, both escrows, Entrypoint, Movva pool, zkTLS verifier,
 *                                                  LP registry, ASP quorum, first block
 *   deployments/sepolia-v6-hedge-sleeve.json    the hedge sub-wallet and its venue contract (same reserve)
 *   deployments/sepolia-account-stack.json         OwnerlessPaymaster (and what the overlay below does not replace)
 *   deployments/sepolia-account-stack-v6.json      AuditGrantRegistry, Kernel validator and adapter, redeployed for v2.0
 *                                                  (I-30, I-31, I-32) by scripts/redeploy-account-contracts.ts
 * No record names the deployment's co-signer address. When one does (`coSigner` or `cosigner.address` at the top
 * level of any of the three), it is pinned too.
 */
import { readFileSync, writeFileSync } from 'node:fs';
import { dirname, join, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { getAddress, isAddress, type Address } from 'viem';
import type { CanonicalDeployment } from '../src/lib/canonical-types.js';

const here = dirname(fileURLToPath(import.meta.url));
export const REPO_ROOT = join(here, '..', '..', '..');
export const GENERATED = join(here, '..', 'src', 'lib', 'canonical-deployments.generated.ts');

export const SEPOLIA_RECORDS = {
  rail: 'deployments/sepolia-movva-v6-rail.json',
  hedge: 'deployments/sepolia-v6-hedge-sleeve.json',
  account: 'deployments/sepolia-account-stack.json',
  accountV6: 'deployments/sepolia-account-stack-v6.json',
} as const;

type Json = Record<string, unknown>;
export type ReadRecord = (path: string) => unknown;

const at = (o: unknown, path: string, record: string): unknown => {
  let v = o;
  for (const k of path.split('.')) {
    if (!v || typeof v !== 'object') throw new Error(`${record}: ${path} is missing`);
    v = (v as Json)[k];
  }
  if (v === undefined) throw new Error(`${record}: ${path} is missing`);
  return v;
};
const addr = (o: unknown, path: string, record: string): Address => {
  const v = at(o, path, record);
  if (typeof v !== 'string' || !isAddress(v, { strict: false })) throw new Error(`${record}: ${path} is not an address`);
  return getAddress(v);
};
const optionalCoSigner = (o: Json): Address | undefined => {
  const v = o.coSigner ?? (o.cosigner && typeof o.cosigner === 'object' ? (o.cosigner as Json).address : undefined);
  return typeof v === 'string' && isAddress(v, { strict: false }) ? getAddress(v) : undefined;
};

/** A record the bundle may trust: on the chain, live, every check passed. */
function liveRecord(read: ReadRecord, path: string, chainId: number): Json {
  const r = read(path) as Json;
  if (!r || typeof r !== 'object') throw new Error(`${path}: not a deployment record`);
  if (r.chainId !== chainId) throw new Error(`${path}: chainId ${String(r.chainId)}, expected ${chainId}`);
  if (r.mode !== 'live') throw new Error(`${path}: mode ${String(r.mode)}, expected live`);
  const fail = (r.verification as Json | undefined)?.fail;
  if (fail !== 0) throw new Error(`${path}: verification.fail is ${String(fail)}, expected 0`);
  return r;
}

export function sepoliaCanonical(read: ReadRecord): CanonicalDeployment {
  const chainId = 11155111;
  const rail = liveRecord(read, SEPOLIA_RECORDS.rail, chainId);
  const hedge = liveRecord(read, SEPOLIA_RECORDS.hedge, chainId);
  const account = liveRecord(read, SEPOLIA_RECORDS.account, chainId);
  const accountV6 = liveRecord(read, SEPOLIA_RECORDS.accountV6, chainId);
  const steps = at(rail, 'steps', SEPOLIA_RECORDS.rail) as Record<string, { status?: string }>;
  for (const [name, step] of Object.entries(steps)) {
    if (step.status !== 'done') throw new Error(`${SEPOLIA_RECORDS.rail}: step ${name} is ${String(step.status)}, expected done`);
  }
  const reserve = addr(rail, 'contracts.movva.reserve', SEPOLIA_RECORDS.rail);
  if (addr(hedge, 'contracts.reserve', SEPOLIA_RECORDS.hedge) !== reserve) {
    throw new Error(`${SEPOLIA_RECORDS.hedge}: its reserve is not the final rail's ${reserve}`);
  }
  const firstBlock = at(rail, 'firstBlock', SEPOLIA_RECORDS.rail);
  if (!(typeof firstBlock === 'number' && Number.isSafeInteger(firstBlock) && firstBlock > 0) && !(typeof firstBlock === 'string' && /^[1-9]\d*$/.test(firstBlock))) {
    throw new Error(`${SEPOLIA_RECORDS.rail}: firstBlock is not a block number`);
  }
  const coSigners = [rail, hedge, account, accountV6].map(optionalCoSigner).filter((x): x is Address => x !== undefined);
  if (new Set(coSigners).size > 1) throw new Error(`the Sepolia records name different co-signers: ${coSigners.join(', ')}`);
  return {
    chainId,
    name: String(rail.name ?? 'Sepolia'),
    sources: [SEPOLIA_RECORDS.rail, SEPOLIA_RECORDS.hedge, SEPOLIA_RECORDS.account, SEPOLIA_RECORDS.accountV6],
    fromBlock: String(firstBlock),
    contracts: {
      movva: addr(rail, 'contracts.movva.token', SEPOLIA_RECORDS.rail),
      reserve,
      onramp: addr(rail, 'contracts.ramp.movvaOnramp', SEPOLIA_RECORDS.rail),
      offramp: addr(rail, 'contracts.ramp.movvaOfframp', SEPOLIA_RECORDS.rail),
      entrypoint: addr(rail, 'contracts.protocol.entrypoint', SEPOLIA_RECORDS.rail),
      movvaPool: addr(rail, 'contracts.pools.movva', SEPOLIA_RECORDS.rail),
      saleVerifier: addr(rail, 'contracts.ramp.zktls', SEPOLIA_RECORDS.rail),
      auditGrantRegistry: addr(accountV6, 'contracts.auditGrantRegistry', SEPOLIA_RECORDS.accountV6),
      lpRegistry: addr(rail, 'contracts.ramp.registry', SEPOLIA_RECORDS.rail),
      aspQuorum: addr(rail, 'contracts.asp.quorum', SEPOLIA_RECORDS.rail),
      hedgeSubWallet: addr(hedge, 'contracts.subWallet', SEPOLIA_RECORDS.hedge),
      hedgeVenue: addr(hedge, 'contracts.venue', SEPOLIA_RECORDS.hedge),
    },
    account: {
      ...(coSigners[0] ? { coSigner: coSigners[0] } : {}),
      ownerlessPaymaster: addr(account, 'contracts.ownerlessPaymaster', SEPOLIA_RECORDS.account),
      kernel: {
        passkeyValidator: addr(accountV6, 'contracts.passkeyCoSignerValidator', SEPOLIA_RECORDS.accountV6),
        adapter: addr(accountV6, 'contracts.kernelAvatarAdapter', SEPOLIA_RECORDS.accountV6),
      },
    },
  };
}

export const readFromRepo: ReadRecord = (path) => JSON.parse(readFileSync(join(REPO_ROOT, path), 'utf8')) as unknown;

export function canonicalDeployments(read: ReadRecord = readFromRepo): Record<number, CanonicalDeployment> {
  const sepolia = sepoliaCanonical(read);
  return { [sepolia.chainId]: sepolia };
}

/** The generated module's source: deterministic, so a stale file shows up as a diff. */
export function renderModule(table: Record<number, CanonicalDeployment>): string {
  return [
    '// GENERATED by packages/app/scripts/canonical-deployments.ts from the deployment records named in each entry\'s',
    '// `sources`. Do not edit: run `npx tsx packages/app/scripts/canonical-deployments.ts` (the app\'s build does).',
    'import type { CanonicalDeployment } from \'./canonical-types.js\';',
    '',
    `export const CANONICAL_DEPLOYMENTS: Readonly<Record<number, CanonicalDeployment>> = Object.freeze(${JSON.stringify(table, null, 2)});`,
    '',
  ].join('\n');
}

const isMain = !!process.argv[1] && fileURLToPath(import.meta.url) === resolve(process.argv[1]);
if (isMain) {
  const source = renderModule(canonicalDeployments());
  const current = (() => { try { return readFileSync(GENERATED, 'utf8'); } catch { return ''; } })();
  if (process.argv.includes('--check')) {
    if (current !== source) {
      console.error(`${relative(process.cwd(), GENERATED)} is stale: run npx tsx packages/app/scripts/canonical-deployments.ts`);
      process.exit(1);
    }
    console.log(`${relative(process.cwd(), GENERATED)} matches the deployment records`);
  } else if (current !== source) {
    writeFileSync(GENERATED, source);
    console.log(`wrote ${relative(process.cwd(), GENERATED)}`);
  }
}
