/**
 * The user's passkey, asked before a sale account signs (v2.0 I-56).
 *
 * A sale account's owner is a P-256 key this page made for the sale and holds (session.ts `newSaleAccount`), so that
 * nothing on-chain ties the sale to the user's account. That key signs without any prompt: a script running in the page
 * could open, cancel or give up a sale with it and the user would see nothing. So before a sale account moves anything,
 * the user's own passkey signs a challenge naming what it is about to do. A browser shows that as a passkey prompt, and
 * no script can answer one without the user. The assertion is checked here: the passkey's key, user verification, and
 * this challenge.
 *
 * A sub-wallet has no passkey of its own: its session confirms with the passkey that unlocked the app, the primary
 * wallet's (`OpenSessionArgs.confirmWith`). An EOA deployment confirms with the same passkey. Only a session opened with
 * no passkey at all (a script) has none to ask.
 */
import { sha256 } from '@noble/hashes/sha2';
import { verifyAssertion } from '@mova/smart-account';
import { SaleRefused } from '@mova/wallet';
import type { AccountOwnerKey } from './account.js';

export type SaleAccountAction = 'sell' | 'cancel' | 'resume' | 'reshield';

const DOMAIN = 'movva:sale-account-confirmation:v1';

/** What the passkey signs for one sale-account action: a digest of the action and its details, domain-separated. */
export function saleConfirmationChallenge(action: SaleAccountAction, details: Record<string, string>): Uint8Array {
  const sorted = Object.fromEntries(Object.entries(details).sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0)));
  return sha256(new TextEncoder().encode(`${DOMAIN}\n${action}\n${JSON.stringify(sorted)}`));
}

const base64url = (b: Uint8Array): string => btoa(String.fromCharCode(...b)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');

/** Ask the user's passkey to confirm a sale-account action, and check its answer. Refuses with `sale_not_confirmed`. */
export async function confirmSaleWithPasskey(owner: AccountOwnerKey, action: SaleAccountAction, details: Record<string, string>): Promise<void> {
  const challenge = saleConfirmationChallenge(action, details);
  let assertion;
  try {
    assertion = await owner.sign(challenge);
  } catch {
    throw new SaleRefused('the passkey did not confirm: the sale account signs nothing without it', 'sale_not_confirmed');
  }
  let signed: { type?: string; challenge?: string };
  try {
    signed = JSON.parse(new TextDecoder().decode(assertion.clientDataJSON)) as typeof signed;
  } catch {
    throw new SaleRefused('the passkey answered with something that is not an assertion', 'sale_not_confirmed');
  }
  const userVerified = (assertion.authenticatorData[32] ?? 0) & 0x04;
  if (signed.type !== 'webauthn.get' || signed.challenge !== base64url(challenge) || !userVerified || !verifyAssertion(assertion, owner.publicKey)) {
    throw new SaleRefused('the passkey\'s answer does not confirm this action', 'sale_not_confirmed');
  }
}
