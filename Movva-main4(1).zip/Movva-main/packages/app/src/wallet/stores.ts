/**
 * What the wallet keeps on this device, sealed.
 *
 * The viewing-key service's notes and lineage, each ledger's reservations, each sale's payee and salt, the sale
 * accounts' keys and the audit grants issued are private: together they are the user's financial history. They are
 * kept in the browser's storage encrypted with XChaCha20-Poly1305 under a key derived from the wallet's root seed,
 * which exists only in memory while the wallet is unlocked (the passkey recomputes it). The record's name is the
 * AEAD's associated data, so a record cannot be swapped for another. Nothing here moves funds: the spending keys are
 * re-derived from the seed, never stored.
 *
 * Rollback (v2.0 I-57): every write takes the next generation of a sealed manifest, and the record is sealed with its
 * name AND that generation. The manifest remembers each record's latest generation, so an older copy of a record put
 * back in storage - a sale journal from before an exit, a reservation since released - opens to nothing: it is refused,
 * as is a removed record put back. A rollback of the whole storage at once, manifest included, can only be seen from
 * outside it: `GenerationAnchor` is where a deployment keeps the latest generation somewhere else.
 */
import { xchacha20poly1305 } from '@noble/ciphers/chacha';
import { hkdf } from '@noble/hashes/hkdf';
import { sha256 } from '@noble/hashes/sha2';
import { bytesToHex, hexToBytes, randomBytes, utf8ToBytes } from '@noble/hashes/utils';
import type { WalletSnapshot, WalletStore } from '@mova/viewing-key';
import type { Hex } from 'viem';
import type { LedgerSnapshot, LedgerStore, LegacyPixSaleRecord, SaleRecord, SaleStore } from '@mova/wallet';
import { parse, stringify } from '../lib/json.js';

/** Synchronous key-value storage: the wallet's stores are synchronous. */
export interface KeyValue {
  get(key: string): string | null;
  set(key: string, value: string): void;
  remove(key: string): void;
  keys(): string[];
}

export class MemoryKeyValue implements KeyValue {
  private readonly m = new Map<string, string>();
  get(key: string) { return this.m.get(key) ?? null; }
  set(key: string, value: string) { this.m.set(key, value); }
  remove(key: string) { this.m.delete(key); }
  keys() { return [...this.m.keys()]; }
}

export function browserKeyValue(storage: Storage = globalThis.localStorage): KeyValue {
  return {
    get: (k) => storage.getItem(k),
    set: (k, v) => storage.setItem(k, v),
    remove: (k) => storage.removeItem(k),
    keys: () => Array.from({ length: storage.length }, (_, i) => storage.key(i)).filter((k): k is string => k !== null),
  };
}

export class StoreUnreadable extends Error {}

/** A record, or the whole store, is older than what this wallet has already written (I-57). */
export class StoreRolledBack extends StoreUnreadable {}

/**
 * Somewhere outside the browser's storage that keeps the store's latest generation (I-57): a whole-storage rollback
 * brings the manifest back with everything else, and only an anchor it cannot reach shows it.
 */
export interface GenerationAnchor {
  read(): number | undefined;
  write(generation: number): void;
}

interface Manifest {
  /** The last generation handed out. */
  g: number;
  /** Per record, the generation of its latest write - or of its removal, a tombstone. */
  r: Record<string, number>;
}

const MANIFEST = '__manifest';

/** The sealing key for this wallet's local records, from its root seed. */
export function storeKeyFromSeed(rootSeed: Uint8Array): Uint8Array {
  return hkdf(sha256, rootSeed, utf8ToBytes('Mova/app/v1/local-store'), utf8ToBytes('seal'), 32);
}

export class SealedStore {
  constructor(
    private readonly kv: KeyValue,
    private readonly key: Uint8Array,
    readonly prefix: string,
    private readonly anchor?: GenerationAnchor,
  ) {
    if (key.length !== 32) throw new Error('a store key is 32 bytes');
  }

  private id(name: string): string { return `${this.prefix}${name}`; }

  /** Version 1 records, from before I-57, are sealed under the name alone; version 2 under the name and generation. */
  private ad(name: string, g?: number): Uint8Array { return utf8ToBytes(g === undefined ? this.id(name) : `${this.id(name)}#${g}`); }

  private open(name: string, raw: string, ad: Uint8Array): string {
    const { n, c } = JSON.parse(raw) as { n: string; c: string };
    return new TextDecoder().decode(xchacha20poly1305(this.key, hexToBytes(n), ad).decrypt(hexToBytes(c)));
  }

  private seal(name: string, text: string, g: number): string {
    const n = randomBytes(24);
    const c = xchacha20poly1305(this.key, n, this.ad(name, g)).encrypt(utf8ToBytes(text));
    return JSON.stringify({ v: 2, g, n: bytesToHex(n), c: bytesToHex(c) });
  }

  /** Read fresh every time: another tab of the app writes to the same storage. */
  private manifest(): Manifest {
    const raw = this.kv.get(this.id(MANIFEST));
    let m: Manifest = { g: 0, r: {} };
    if (raw !== null) {
      try {
        m = JSON.parse(this.open(MANIFEST, raw, this.ad(MANIFEST))) as Manifest;
      } catch {
        throw new StoreUnreadable('o índice dos registros locais não abre com esta chave: foi alterado, ou pertence a outra carteira');
      }
    }
    const anchored = this.anchor?.read();
    if (anchored !== undefined && anchored > m.g) {
      throw new StoreRolledBack('os registros locais voltaram a um estado anterior ao que esta carteira já gravou');
    }
    return m;
  }

  private saveManifest(m: Manifest): void {
    const n = randomBytes(24);
    const c = xchacha20poly1305(this.key, n, this.ad(MANIFEST)).encrypt(utf8ToBytes(JSON.stringify(m)));
    this.kv.set(this.id(MANIFEST), JSON.stringify({ v: 1, n: bytesToHex(n), c: bytesToHex(c) }));
    this.anchor?.write(m.g);
  }

  has(name: string): boolean { return this.kv.get(this.id(name)) !== null; }

  read<T>(name: string): T | undefined {
    const raw = this.kv.get(this.id(name));
    if (raw === null) return undefined;
    const m = this.manifest();
    let g: number | undefined;
    let text: string;
    try {
      g = (JSON.parse(raw) as { g?: number }).g;
      text = this.open(name, raw, this.ad(name, g));
    } catch {
      throw new StoreUnreadable(`o registro local "${name}" não abre com esta chave: foi alterado, ou pertence a outra carteira`);
    }
    const known = m.r[name];
    if (known !== undefined && (g ?? 0) < known) {
      throw new StoreRolledBack(`o registro local "${name}" é uma cópia anterior à última que esta carteira gravou`);
    }
    // A record newer than the manifest says: written just before a crash, or by another tab racing this one's manifest.
    // Or one from before generations: sealed again under one, so the old copy is refused from now on.
    if (g === undefined) this.write(name, parse<unknown>(text));
    else if (known === undefined || g > known) this.saveManifest({ g: Math.max(m.g, g), r: { ...m.r, [name]: g } });
    return parse<T>(text);
  }

  write(name: string, value: unknown): void {
    const m = this.manifest();
    const g = m.g + 1;
    this.kv.set(this.id(name), this.seal(name, stringify(value), g));
    this.saveManifest({ g, r: { ...m.r, [name]: g } });
  }

  /** The record goes, and a tombstone stays in the manifest: a copy put back later is refused. */
  remove(name: string): void {
    const m = this.manifest();
    this.kv.remove(this.id(name));
    this.saveManifest({ g: m.g + 1, r: { ...m.r, [name]: m.g + 1 } });
  }

  /** Every record of this wallet, to forget the device. */
  clear(): void {
    for (const k of this.kv.keys()) if (k.startsWith(this.prefix)) this.kv.remove(k);
  }

  walletStore(name: string): WalletStore {
    return { load: () => this.read<WalletSnapshot>(name), save: (s) => this.write(name, s) };
  }

  ledgerStore(name: string): LedgerStore {
    return { load: () => this.read<LedgerSnapshot>(name), save: (s) => this.write(name, s) };
  }

  saleStore(name = 'sales'): SaleStore {
    return {
      put: (r: SaleRecord) => {
        const all = this.read<Record<string, SaleRecord>>(name) ?? {};
        all[r.saleId.toLowerCase()] = r;
        this.write(name, all);
      },
      get: (saleId: Hex): SaleRecord | LegacyPixSaleRecord | undefined => this.read<Record<string, SaleRecord>>(name)?.[saleId.toLowerCase()],
    };
  }

  /** A list kept under one name, newest first. */
  list<T>(name: string): T[] { return this.read<T[]>(name) ?? []; }

  upsert<T>(name: string, item: T, same: (a: T) => boolean): void {
    const all = this.list<T>(name);
    const i = all.findIndex(same);
    if (i >= 0) all[i] = item; else all.unshift(item);
    this.write(name, all);
  }
}
