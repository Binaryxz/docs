/*
 * Movva's service worker (built to dist/sw.js by vite.config.ts): what makes the app installable, open offline, and
 * reachable with the app closed.
 *
 *  - the app shell (index.html, the hashed bundles, icons) is cached, so the app opens without a network;
 *  - the circuit artifacts (about 24 MB) are cached after the first proof, so they are downloaded once;
 *  - nothing under api/ is ever cached: balances, quotes and payment instructions always come from the network, and
 *    an answer from a cache would be an answer the wallet did not check;
 *  - a recovery alert pushed by the co-signer is shown as a notification, and clicking it opens the app (handlers.ts).
 */
import { onNotificationClick, onPush } from './handlers.js';

type Waitable = { waitUntil(promise: Promise<unknown>): void };
type FetchEventLike = Waitable & { request: Request; respondWith(response: Promise<Response> | Response): void };

interface WorkerScope {
  registration: { scope: string; showNotification(title: string, options?: Record<string, unknown>): Promise<void> };
  clients: Parameters<typeof onNotificationClick>[1] & { claim(): Promise<void> };
  location: Location;
  skipWaiting(): Promise<void>;
  addEventListener(type: 'install' | 'activate', listener: (event: Waitable) => void): void;
  addEventListener(type: 'fetch', listener: (event: FetchEventLike) => void): void;
  addEventListener(type: 'push', listener: (event: Parameters<typeof onPush>[0]) => void): void;
  addEventListener(type: 'notificationclick', listener: (event: Parameters<typeof onNotificationClick>[0]) => void): void;
}

const sw = self as unknown as WorkerScope;
const SHELL = 'movva-shell-v1';
// v2: v1 could hold an HTML page in place of an artifact (a server's index fallback for a file missing mid-deploy).
const CIRCUITS = 'movva-circuits-v2';
const SHELL_FILES = ['./', './index.html', './manifest.webmanifest', './icons/icon.svg', './icons/icon-192.png', './icons/icon-512.png'];

sw.addEventListener('install', (event) => {
  event.waitUntil(caches.open(SHELL).then((c) => c.addAll(SHELL_FILES)).then(() => sw.skipWaiting()));
});

sw.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== SHELL && k !== CIRCUITS).map((k) => caches.delete(k))))
      .then(() => sw.clients.claim()),
  );
});

/**
 * Cache-first, keeping only what `keep` accepts. A circuit artifact is never HTML: a server that answers a missing file
 * with its index page and a 200 (an app host's fallback, a deploy in progress) would otherwise be cached as the circuit,
 * and every proof would fail until the cache was cleared.
 */
async function cacheFirst(cacheName: string, request: Request, keep: (r: Response) => boolean = () => true): Promise<Response> {
  const cache = await caches.open(cacheName);
  const hit = await cache.match(request);
  if (hit) return hit;
  const response = await fetch(request);
  if (response.ok && keep(response)) {
    // Caching is a saving, never a condition: a cache that cannot take it (the origin's storage quota, a private window)
    // must not turn a good download into "Failed to fetch".
    await cache.put(request, response.clone()).catch(() => undefined);
  }
  return response;
}

const notHtml = (r: Response) => !(r.headers.get('content-type') ?? '').toLowerCase().includes('text/html');

sw.addEventListener('fetch', (event) => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== sw.location.origin) return;
  const path = url.pathname.slice(new URL(sw.registration.scope).pathname.length);
  if (path.startsWith('api/')) return;
  if (path.startsWith('circuits/')) {
    event.respondWith(cacheFirst(CIRCUITS, request, notHtml));
    return;
  }
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((response) => {
          // L-28: only the app's own page becomes the offline shell - not a 4xx or 5xx, a redirect, an opaque answer, or
          // a proxy's error page served as HTML.
          if (response.ok && response.type === 'basic' && !response.redirected && !notHtml(response)) {
            const copy = response.clone();
            void caches.open(SHELL).then((c) => c.put('./index.html', copy));
          }
          return response;
        })
        .catch(() => caches.match('./index.html').then((r) => r ?? Response.error())),
    );
    return;
  }
  if (path.startsWith('assets/') || path.startsWith('icons/')) event.respondWith(cacheFirst(SHELL, request));
});

sw.addEventListener('push', (event) => {
  // Recovery alerts only; the app sends no other push messages today.
  onPush(event, sw.registration);
});

sw.addEventListener('notificationclick', (event) => {
  onNotificationClick(event, sw.clients);
});
