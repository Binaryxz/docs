/**
 * Every refusal the wallet can make, said in Portuguese, with what to do next.
 *
 * The wallet refuses with codes (`PaymentRefused.code`, `SaleRefused.code`) and English messages written for
 * developers. The user reads these instead; the English message is kept as "detalhes técnicos". The two tables are
 * `Record`s over the wallet's own code unions, so a code added to the wallet without a sentence here fails the type
 * check rather than reaching a user untranslated.
 */
import {
  AspRefused, BuyRefused, ExecutionFailed, LedgerRefused, LpNodeError, MovvaWalletRefused, PartialLock, PaymentRefused, ProofRefused,
  ReshieldRefused, SaleRefused, type RefusalCode, type SaleRefusalCode,
} from '@mova/wallet';
import { AmountInputError, InputInvalid, type Tone } from './format.js';
import { DeploymentInvalid } from './deployment.js';
import { DeploymentNotCanonical } from './canonical.js';
import { SeedSourceMismatchError, SeedUnavailableError } from '@mova/smart-account';
import { CoSignerRefused, SponsorshipNotGranted } from '@mova/cosigner/client';
import { AlertsUnavailableHere } from '../wallet/alerts.js';
import { AccountSetupError } from '../wallet/account.js';
import { PasskeyUnavailable, PrfUnsupported } from '../passkey/seed.js';
import { RemoteServiceError } from '../wallet/remote.js';
import { StoreUnreadable } from '../wallet/stores.js';
import { SaleInterrupted, SaleKeyMissing } from '../wallet/sale-errors.js';

export type SuggestedAction = 'cancelOrder' | 'cancelSale' | 'retry' | 'wait';

export interface ErrorView {
  tone: Tone;
  title: string;
  detail: string;
  action?: SuggestedAction;
  actionLabel?: string;
  code?: string;
  /** The library's own message, for "detalhes técnicos". */
  technical?: string;
}

/**
 * Why the co-signer - the account's second key - did not sign (packages/cosigner/src/refusal.ts). Nothing moved: an
 * operation it refuses never reaches the bundler.
 */
export const COSIGNER_REFUSALS: Record<string, { title: string; detail: string; action?: SuggestedAction }> = {
  rate_limited: { title: 'Muitas operações seguidas', detail: 'O cossignatário limita quantas operações uma conta faz por minuto. Espere um pouco e tente de novo.', action: 'retry' },
  passkey_required: { title: 'Falta a assinatura da passkey', detail: 'O cossignatário só assina junto com a sua passkey. Tente de novo e confirme a passkey.', action: 'retry' },
  bad_passkey_signature: { title: 'Assinatura da passkey recusada', detail: 'A assinatura não é da passkey desta conta, ou não é desta operação. Nada foi enviado.', action: 'retry' },
  expired: { title: 'Operação expirada', detail: 'A operação demorou demais para ser assinada. Tente de novo.', action: 'retry' },
  window_too_long: { title: 'Operação com prazo longo demais', detail: 'O cossignatário só assina operações válidas por pouco tempo.' },
  window_unbounded: { title: 'Operação sem prazo', detail: 'O cossignatário só assina operações com prazo de validade.' },
  replayed: { title: 'Operação já enviada', detail: 'Esta operação já foi assinada e enviada antes. Atualize e tente de novo.', action: 'retry' },
  not_enrolled: { title: 'Conta não registrada no cossignatário', detail: 'Bloqueie e desbloqueie a carteira para registrar a conta de novo.' },
  enrolment_stale: { title: 'As chaves da conta mudaram', detail: 'As chaves da conta na blockchain não são mais as registradas no cossignatário. Bloqueie e desbloqueie a carteira.' },
  target_not_allowed: { title: 'Operação fora da política da conta', detail: 'A conta só pode chamar os contratos deste deployment. Nada foi enviado.' },
  spender_not_allowed: { title: 'Aprovação fora da política da conta', detail: 'A conta só aprova tokens para os contratos deste deployment. Nada foi enviado.' },
  token_transfer_refused: { title: 'Transferência não permitida', detail: 'A conta não envia tokens diretamente: o dinheiro sai pelos contratos do Movva. Nada foi enviado.' },
  token_call_refused: { title: 'Operação de token não permitida', detail: 'A conta só aprova tokens para os contratos deste deployment. Nada foi enviado.' },
  authority_change: { title: 'Mudança de controle da conta recusada', detail: 'Ninguém muda quem controla a conta por uma operação comum, nem com a sua passkey: isso só acontece pela recuperação, com prazo de 7 dias.' },
  daily_limit_exceeded: { title: 'Limite diário atingido', detail: 'A conta chegou ao limite de valor de 24 horas. Tente de novo mais tarde.' },
  message_not_allowed: { title: 'Assinatura não permitida', detail: 'A conta não assina esse tipo de mensagem.' },
  nothing_to_veto: { title: 'Nada para vetar', detail: 'A fila de recuperação já está vazia.' },
  no_recovery_module: { title: 'Recuperação ainda não instalada', detail: 'A recuperação é instalada pela primeira operação da conta.' },
  sponsorship_disabled: { title: 'Patrocínio indisponível', detail: 'O cossignatário deste deployment não patrocina contas novas, então ninguém paga o gás da primeira operação. Nada foi enviado.' },
  alerts_disabled: { title: 'Alertas indisponíveis', detail: 'O cossignatário deste deployment não envia alertas de recuperação.' },
  proof_expired: { title: 'Confirmação expirada', detail: 'A confirmação com a passkey demorou demais, ou o relógio deste aparelho está errado. Tente de novo.', action: 'retry' },
  push_endpoint_refused: { title: 'Serviço de notificações recusado', detail: 'O cossignatário não envia alertas para o serviço de notificações deste navegador. Nada foi alterado.' },
  recovery_pending: { title: 'Recuperação pendente: alertas mantidos', detail: 'Há uma recuperação na fila da sua conta, e enquanto ela não for vetada ou resolvida os alertas não podem ser desativados: quem tem a sua passkey poderia silenciá-los. Vete a recuperação no Início.' },
  subscription_unknown: { title: 'Alertas já desativados', detail: 'Este aparelho não estava inscrito nos alertas de recuperação desta conta.' },
  too_many_subscriptions: { title: 'Aparelhos demais', detail: 'Esta conta já tem o máximo de aparelhos inscritos nos alertas de recuperação. Desative os alertas num aparelho que você não usa mais.' },
};

/**
 * Why the co-signer did not sponsor a new account (packages/cosigner/src/sponsorship.ts, `SponsorshipNotGranted`): the
 * paymaster pays each operation only for an account it allowlists, so nothing is sent until it does.
 */
export const SPONSORSHIP_REFUSALS: Record<string, { detail: string; retry?: boolean }> = {
  pending: { detail: 'O patrocínio da conta ainda não foi confirmado na blockchain. Tente de novo em instantes.', retry: true },
  rate_limited: { detail: 'Há muitos pedidos de patrocínio agora. Espere um minuto e tente de novo.', retry: true },
  daily_cap: { detail: 'O cossignatário já patrocinou o máximo de contas novas das últimas 24 horas. Tente de novo mais tarde.', retry: true },
  gate_budget_exhausted: { detail: 'O orçamento de contas novas do paymaster para hoje acabou. Tente de novo amanhã.', retry: true },
  operator_revoked: { detail: 'A chave com que o cossignatário patrocina contas foi desativada pelo governo do paymaster. Tente de novo mais tarde.', retry: true },
  operator_unfunded: { detail: 'A chave com que o cossignatário patrocina contas está sem saldo para o gás. Tente de novo mais tarde.', retry: true },
  paymaster_not_gated: { detail: 'O paymaster deste deployment não está sob o contrato de patrocínio (SponsorGate), então o cossignatário não patrocina contas.' },
  paymaster_unbounded: { detail: 'O paymaster não limita o gás de cada conta, e o contrato de patrocínio se recusa a patrocinar assim.' },
  sponsorship_revoked: { detail: 'O patrocínio desta conta foi removido na blockchain, e o cossignatário não o devolve: só o governo do paymaster pode.' },
  transaction_failed: { detail: 'A transação de patrocínio falhou. Tente de novo.', retry: true },
  chain_unavailable: { detail: 'O cossignatário não conseguiu ler a blockchain para patrocinar a conta. Tente de novo.', retry: true },
};

const CANCEL_FREE = 'O que fazer: cancele o pedido. Enquanto ele está travado, cancelar é gratuito e nada foi cobrado.';

/** Why a payment's instructions were not shown as payable. Each one means: do not pay. */
export const PAYMENT_REFUSALS: Record<RefusalCode, string> = {
  instructions_for_another_order: 'O nó do provedor de liquidez respondeu com instruções de outro pedido.',
  order_not_ours: 'Este pedido não foi travado pela sua conta.',
  order_not_awaiting_payment: 'O pedido não está mais aguardando pagamento: um pagamento agora não seria liquidado.',
  pay_window_closed: 'O prazo para pagar este pedido terminou: um pagamento agora não seria liquidado.',
  wrong_rail: 'O provedor enviou instruções para outro meio de pagamento, não o escolhido.',
  malformed: 'As instruções recebidas estão incompletas ou malformadas.',
  pix_key_does_not_open_commitment: 'A chave PIX enviada pelo provedor não é a que a oferta registrou na blockchain. Pagar essa chave poderia mandar seu dinheiro para outra pessoa.',
  amount_mismatch: 'O valor informado pelo provedor não é o valor do pedido.',
  brcode_mismatch: 'O código PIX do provedor não confere com a chave, o valor ou o identificador do pedido.',
  txid_mismatch: 'O código PIX do provedor traz o identificador (txid) de outro pedido, não o deste. Pago, o banco registraria o pagamento para esse outro pedido, e o provedor poderia liquidá-lo no lugar do seu.',
  boleto_not_issued: 'O boleto deste pedido ainda não foi emitido.',
  boleto_does_not_open_commitment: 'A linha digitável não é a do boleto que o provedor registrou para este pedido na blockchain.',
  boleto_amount_mismatch: 'O valor do boleto não é o valor do pedido.',
  boleto_overdue: 'O boleto já venceu (horário de Brasília).',
  boleto_due_after_pay_by: 'O boleto vence depois do prazo do pedido: pago no vencimento, chegaria tarde demais.',
  boleto_unpayable: 'Este boleto não pode ser pago.',
  verifier_not_zktls: 'A oferta liberaria os Movva sem uma prova zkTLS da sessão do banco, só pela palavra de atestadores.',
  pix_location_not_https: 'A cobrança PIX dinâmica não usa conexão segura (https).',
  pix_location_host_not_allowed: 'O código é uma cobrança PIX dinâmica num site de PSP que esta carteira não verifica. No navegador não é possível conferir o certificado desse site, então cobranças dinâmicas não são aceitas: o provedor precisa oferecer um código PIX estático.',
  pix_location_unverifiable: 'O código é uma cobrança PIX dinâmica, e conferir uma exige ver o certificado do site do PSP, o que um navegador não permite. Cobranças dinâmicas não são aceitas aqui: o provedor precisa oferecer um código PIX estático.',
  pix_location_unreachable: 'Não foi possível ler a cobrança PIX dinâmica no site do PSP.',
  pix_location_certificate_invalid: 'O certificado do site da cobrança PIX não é válido.',
  pix_certificate_revoked: 'Um certificado da cobrança PIX foi revogado.',
  pix_certificate_status_unknown: 'Não foi possível confirmar que os certificados da cobrança PIX não foram revogados.',
  pix_jws_invalid: 'A assinatura da cobrança PIX não está no formato exigido pelo Banco Central.',
  pix_jws_algorithm_not_allowed: 'A cobrança PIX foi assinada com um algoritmo não permitido.',
  pix_jws_key_off_domain: 'A chave que assinou a cobrança PIX está em outro domínio.',
  pix_jws_key_invalid: 'A chave que assinou a cobrança PIX é inválida.',
  pix_jws_certificate_invalid: 'O certificado da chave que assinou a cobrança PIX é inválido.',
  pix_jws_signature_invalid: 'A assinatura da cobrança PIX não confere.',
  charge_key_mismatch: 'A cobrança PIX paga outra chave, não a registrada na oferta.',
  charge_amount_mismatch: 'A cobrança PIX é de outro valor, ou deixa o valor ser alterado.',
  charge_txid_mismatch: 'A cobrança PIX tem outro identificador, não o deste pedido.',
  charge_not_payable: 'A cobrança PIX não está ativa.',
  charge_expired: 'A cobrança PIX expirou.',
  charge_outlives_order: 'A cobrança PIX aceitaria pagamento depois do prazo do pedido.',
};

/** Why a sale was refused - every one before any money moved, except the chain checks after it. */
export const SALE_REFUSALS: Record<SaleRefusalCode, { title: string; detail: string; action?: SuggestedAction }> = {
  bad_request: { title: 'Venda incompleta', detail: 'Informe um valor e uma chave PIX, ou uma linha digitável de boleto.' },
  relay_fee_above_policy: { title: 'Relayer mais caro que o previsto', detail: 'O relayer que envia a saída pede agora uma tarifa acima da que esta carteira paga, e recusaria a transação. Nada foi movimentado nem provado. Tente de novo mais tarde.', action: 'retry' },
  boleto_due_today_too_late: { title: 'Boleto vence hoje e já é tarde', detail: 'Este boleto vence hoje e falta menos tempo do que um provedor precisa para pagá-lo antes da meia-noite (horário de Brasília); depois disso ele estaria vencido e nenhum provedor paga. Nada foi vendido: pague por outro meio ou peça ao emissor um boleto com nova data.' },
  exit_pending: { title: 'Venda anterior em andamento', detail: 'Uma venda anterior que não terminou enviou ao relayer a saída de uma nota de que esta venda precisa, e essa saída ainda pode entrar na blockchain. Continue ou cancele essa venda em Vendas em andamento antes de vender de novo.', action: 'wait' },
  price_moved: { title: 'O preço mudou', detail: 'Desde que os Movva saíram do saldo, a faixa de preço do escrow mudou e não aceita mais o preço desta venda. A venda foi desfeita e os Movva voltaram ao seu saldo protegido.' },
  no_pending_sale: { title: 'Venda não encontrada neste aparelho', detail: 'Este aparelho não tem registro de uma venda em andamento com esse identificador.' },
  nothing_to_reshield: { title: 'Nada a devolver ao saldo', detail: 'A conta não tem Movva para devolver ao saldo protegido, ou eles já foram devolvidos.' },
  reshield_below_minimum: { title: 'Valor abaixo do mínimo do pool', detail: 'O valor é menor que o depósito mínimo do pool de Movva, que recusaria o depósito. Os Movva continuam na conta.' },
  not_in_the_open: { title: 'Nada fora do saldo protegido', detail: 'Essa venda ou esse pedido não deixou Movva fora do saldo protegido nesta conta: a venda foi liquidada ou continua no escrow, ou o pedido foi entregue no saldo protegido.' },
  sale_account_linked: { title: 'Conta de venda com histórico', detail: 'Toda venda sai de uma conta nova, para não ligar a venda às suas compras. Tente de novo: o app cria outra conta.', action: 'retry' },
  pix_key_invalid: { title: 'Chave PIX inválida', detail: 'O banco não aceitaria esta chave. Confira o CPF, CNPJ, e-mail, telefone (+55...) ou a chave aleatória.' },
  boleto_invalid: { title: 'Linha digitável inválida', detail: 'Os dígitos verificadores não conferem, ou o boleto não é em reais. Confira a linha.' },
  boleto_collection: { title: 'Guia de arrecadação', detail: 'Esta é uma conta de consumo, tributo ou multa (arrecadação). Ela não tem data de vencimento, e o banco dos provedores só paga boletos que têm.' },
  boleto_no_amount: { title: 'Boleto sem valor', detail: 'Este boleto não traz o valor. A venda paga um boleto exatamente pelo valor escrito nele, então não há o que cotar.' },
  boleto_no_due_date: { title: 'Boleto sem vencimento', detail: 'Este boleto não tem data de vencimento (fator 0000). O banco dos provedores não paga boleto sem vencimento, então nenhum provedor aceitaria a venda.' },
  boleto_overdue: { title: 'Boleto vencido', detail: 'O vencimento já passou (horário de Brasília). Pago com atraso, o boleto custa mais do que diz, e nenhum provedor paga boleto vencido. Peça ao emissor um boleto atualizado.' },
  boleto_amount_mismatch: { title: 'Valor diferente do boleto', detail: 'O valor informado não é o do boleto. A venda paga o boleto exatamente pelo valor escrito nele.' },
  verifier_not_zktls: { title: 'Verificador de vendas inseguro', detail: 'O verificador configurado não prova a sessão do banco (zkTLS), e o escrow recusaria a venda. Nada foi vendido.' },
  verifier_unreadable: { title: 'Verificador indisponível', detail: 'Não foi possível consultar o verificador de vendas. Nada foi vendido; tente de novo.', action: 'retry' },
  pool_mismatch: { title: 'Configuração inconsistente', detail: 'O pool de Movva ou a tarifa do relayer não conferem com a blockchain. Nada foi vendido.' },
  no_price: { title: 'Sem preço agora', detail: 'Não há um preço atual do Movva para vender, porque o lastro não pôde ser confirmado. Nada foi vendido; tente mais tarde.', action: 'retry' },
  below_smallest_sale: { title: 'Valor abaixo do mínimo', detail: 'O valor é menor que a menor venda possível ao preço de agora.' },
  amount_unpriceable: { title: 'Valor não precificável agora', detail: 'Ao preço de agora, o valor exato deste boleto não cabe na faixa de preço do escrow. Tente mais tarde.', action: 'retry' },
  note_too_small: { title: 'Valor maior que uma nota', detail: 'Cada venda é paga por uma única nota do seu saldo, e a sua maior nota é menor que esse valor. Venda um valor menor, ou permita usar várias notas.' },
  balance_empty: { title: 'Saldo vazio', detail: 'Seu saldo disponível está vazio.' },
  chain_mismatch: { title: 'A blockchain não confirma a venda', detail: 'O que a blockchain mostra não é o que a carteira pediu. Não repita a venda: confira os detalhes técnicos.' },
  no_payee_record: { title: 'Destinatário não encontrado', detail: 'Este aparelho não guarda para quem é esta venda.' },
  not_seller: { title: 'Venda de outra conta', detail: 'Esta venda não foi aberta por esta conta.' },
  sale_claimed: { title: 'Um provedor já está pagando', detail: 'Um provedor assumiu a venda e pode já ter pago: ela não pode ser cancelada agora.', action: 'wait' },
  sale_not_open: { title: 'Venda não está aberta', detail: 'Só uma venda aberta pode ser cancelada.' },
  no_such_sale: { title: 'Venda não encontrada', detail: 'Esta venda não existe na blockchain.' },
  sale_not_confirmed: { title: 'Passkey não confirmou', detail: 'A conta de venda só assina depois que a sua passkey confirma. Nada foi enviado; tente de novo e confirme a passkey.', action: 'retry' },
  asp_root_rolled_back: { title: 'Lista de aprovação antiga', detail: 'A lista de depósitos aprovados voltou a uma versão que esta carteira já viu substituída. Nada foi provado nem enviado; tente de novo quando a versão atual for publicada.', action: 'retry' },
};

/**
 * Putting Movva back into the shielded balance is refused with the sale's codes (`ReshieldRefused`). Where the sale's
 * sentence would speak of a sale, these speak of the deposit that did not happen.
 */
export const RESHIELD_REFUSALS: Partial<Record<SaleRefusalCode, { title: string; detail: string; action?: SuggestedAction }>> = {
  nothing_to_reshield: { title: 'Nada a devolver ao saldo', detail: 'A conta não guarda Movva para devolver ao saldo protegido, guarda menos do que devia, ou eles já foram devolvidos. Nada foi enviado.' },
  reshield_below_minimum: { title: 'Valor abaixo do mínimo do pool', detail: 'O valor é menor que o depósito mínimo do pool de Movva, que recusaria o depósito. Nada foi enviado, e os Movva continuam na conta.' },
  pool_mismatch: { title: 'Configuração inconsistente', detail: 'O pool de Movva registrado na blockchain não é o desta carteira: o depósito cairia onde a carteira não procura. Nada foi enviado.' },
  chain_mismatch: { title: 'A blockchain não confirma o depósito', detail: 'A transação não mostra o depósito que a carteira pediu. Não repita: confira os detalhes técnicos.' },
  exit_pending: { title: 'Aguardando o relayer', detail: 'Uma saída que paga esta venda está com o relayer e ainda pode entrar na blockchain. Nada é devolvido nem enviado de novo até ela entrar, ou até não poder mais entrar.', action: 'wait' },
  not_in_the_open: { title: 'Nada fora do saldo protegido', detail: 'Essa venda ou esse pedido não deixou Movva fora do saldo protegido nesta conta: a venda foi paga ou continua no escrow, ou o pedido foi entregue no saldo protegido. Nada foi enviado.' },
  sale_claimed: { title: 'Um provedor já está pagando', detail: 'Um provedor assumiu a venda, ou ela está em disputa: os Movva estão no escrow, não na conta da venda. Nada foi enviado.', action: 'wait' },
};

const lowerFirst = (s: string) => s.charAt(0).toLowerCase() + s.slice(1);
const AMOUNT = String.raw`R\$ [\d.]+,\d{2}`;

/** A sale's (or a re-shield's) refusal in words, with the wallet's figures where its message states them. */
function saleRefusalView(e: SaleRefused): { title: string; detail: string; action?: SuggestedAction } {
  if (!e.code) return { title: 'Venda recusada', detail: 'A venda foi recusada.' };
  const r = (e instanceof ReshieldRefused ? RESHIELD_REFUSALS[e.code] : undefined) ?? SALE_REFUSALS[e.code];
  if (e.code === 'reshield_below_minimum') {
    const m = new RegExp(`(${AMOUNT}) of Movva is under the pool's minimum deposit of (${AMOUNT})`).exec(e.message);
    if (m) return { ...r, detail: `São ${m[1]} em Movva, abaixo do depósito mínimo do pool, de ${m[2]}: o pool recusaria o depósito. Nada foi enviado, e os Movva continuam na conta.` };
  }
  if (e.code === 'note_too_small') {
    const m = /at most (\d+) notes/.exec(e.message);
    if (m) return { ...r, detail: `Nem somando até ${m[1]} notas do seu saldo o valor fecha. Venda um valor menor.` };
  }
  return r;
}

/** Why a rail could not be quoted (`BuyOptions.unavailable`), in words. */
export function unavailableReason(reason: string): string {
  if (/no liquidity/.test(reason)) return 'Sem liquidez neste meio de pagamento agora.';
  if (/cannot fill a deposit of that size/.test(reason)) return 'As ofertas não comportam esse valor; tente um valor menor.';
  return 'Indisponível no momento.';
}

function buyRefusal(message: string): Omit<ErrorView, 'tone' | 'technical'> {
  if (/quote has expired/.test(message)) return { title: 'Cotação expirada', detail: 'A cotação expirou. Cote de novo.', action: 'retry' };
  if (/prices its leg differently|no longer an active Movva offer/.test(message)) return { title: 'As ofertas mudaram', detail: 'As ofertas mudaram desde a cotação. Cote de novo; nada foi travado.', action: 'retry' };
  if (/minimum deposit/.test(message)) return { title: 'Valor abaixo do mínimo', detail: 'Uma parte do pedido ficaria abaixo do depósito mínimo do pool. Escolha um valor maior.' };
  if (/no LP node is known/.test(message)) return { title: 'Provedor sem nó conhecido', detail: 'Não há nó conhecido para o provedor desta oferta, e ninguém diria onde pagar. Confira os nós de LP em Ajustes.' };
  if (/not visible yet/.test(message)) return { title: 'Quase lá', detail: 'O pedido foi liberado; o depósito ainda está chegando ao pool.', action: 'wait' };
  if (/does not prove the bank session/.test(message)) return { title: 'Oferta insegura recusada', detail: PAYMENT_REFUSALS.verifier_not_zktls + ' Nada foi travado.' };
  if (/only the rescue address named at lock can take delivery/.test(message)) return { title: 'Entrega fora do saldo recusada', detail: 'Só a conta que travou o pedido pode receber os Movva fora do saldo protegido.' };
  if (/can switch to direct delivery/.test(message)) return { title: 'A entrega não pode mais mudar', detail: 'Só um pedido travado ou em disputa, ainda para entrega no saldo protegido, pode passar a ser entregue na sua conta. Ele pode já ter sido liberado, cancelado ou expirado.' };
  if (/only a locked order can be cancelled/.test(message)) return { title: 'Não é possível cancelar', detail: 'Só um pedido travado, ainda não pago, pode ser cancelado.' };
  return { title: 'Compra recusada', detail: 'A compra foi recusada antes de travar o pedido.' };
}

/**
 * By the `name` a browser gives its own errors (a DOMException's `NotAllowedError`). Never for our classes: a production
 * build minifies class names (`class lo extends Error`) and they set no `name`, so those are matched with `instanceof`.
 */
const named = (e: unknown, name: string): boolean => (e instanceof Error || e instanceof DOMException) && e.name === name;

export function describeError(e: unknown): ErrorView {
  const technical = e instanceof Error ? ((e as { shortMessage?: string }).shortMessage ?? e.message) : String(e);
  if (e instanceof PaymentRefused) {
    return {
      tone: 'danger', code: e.code, technical, title: 'Não pague: as instruções não conferem',
      detail: `${PAYMENT_REFUSALS[e.code]}${e.suggestion ? ` ${CANCEL_FREE}` : ''}`,
      ...(e.suggestion ? { action: 'cancelOrder' as const, actionLabel: 'Cancelar pedido (gratuito)' } : {}),
    };
  }
  if (e instanceof SaleInterrupted) {
    // No "try again": selling again from the start would begin a second sale while this one's Movva waits.
    const inner = describeError(e.reason);
    return {
      tone: 'warn', title: 'Venda interrompida', technical: inner.technical ?? technical, ...(inner.code ? { code: inner.code } : {}),
      detail: `A venda parou depois que a saída do seu saldo foi enviada (${lowerFirst(inner.title)}). Nada se perde e nada é repetido sem você: continue ou cancele esta venda em Vendas em andamento.`,
    };
  }
  if (e instanceof SaleRefused) {
    const r = saleRefusalView(e);
    return { tone: 'danger', code: e.code, technical, ...r, ...(r.action === 'retry' ? { actionLabel: 'Tentar de novo' } : {}) };
  }
  if (e instanceof SaleKeyMissing) {
    return {
      tone: 'danger', technical, title: 'Chave da conta da venda ausente',
      detail: 'Este aparelho não guarda a chave da conta desta venda, e só ela abre, cancela ou devolve ao saldo o que está nessa conta. Use o aparelho em que a venda foi feita.',
    };
  }
  if (e instanceof LpNodeError) {
    // A coded refusal is final: the node is saying no, not "not yet", so it must never be polled like the 409 below.
    // Which leg it came from decides what happens next: on a purchase the user has already paid and is refunded; on a
    // sale nothing has moved and another provider may take it.
    if (e.code === 'cap_reached' || e.code === 'payer_unidentified') {
      const sale = /offramp/.test(e.message);
      const why = e.code === 'cap_reached'
        ? 'Este parceiro atingiu o limite que ele mantém para o seu CPF.'
        : 'O banco do parceiro não identificou quem pagou.';
      return sale
        ? { tone: 'warn', technical, code: e.code, title: 'Este parceiro não vai receber esta venda', detail: `${why} Nada saiu do seu saldo. Peça uma nova cotação: os limites de cada parceiro são dele.` }
        : {
          tone: 'warn', technical, code: e.code, title: 'Este parceiro não vai concluir a compra',
          detail: `${why} A compra não será concluída e o valor pago será devolvido por Pix para a mesma conta de origem. Para comprar agora, peça uma nova cotação e escolha outro parceiro.`,
        };
    }
    if (e.status === 409) return { tone: 'info', technical, title: 'Aguardando o provedor', detail: 'O provedor de liquidez ainda está preparando o pagamento (boleto ou cobrança).', action: 'wait' };
    return { tone: 'danger', technical, title: 'O provedor de liquidez não respondeu como deveria', detail: 'O nó do provedor recusou ou falhou. Tente de novo; se persistir, cancele o pedido.', action: 'retry', actionLabel: 'Tentar de novo' };
  }
  if (e instanceof MovvaWalletRefused) {
    const partial = /is ([\d,]+%) backed/.exec(e.message);
    if (partial) return { tone: 'warn', technical, title: 'Compras suspensas: lastro parcial', detail: `O Movva está com lastro de ${partial[1]} agora. Comprar a R$ 1,00 pagaria por um lastro que não existe; as compras voltam quando o lastro for integral.` };
    if (/backing cannot be confirmed/.test(e.message)) return { tone: 'warn', technical, title: 'Compras suspensas: lastro não confirmado', detail: 'Não foi possível confirmar o lastro do Movva agora. As compras voltam quando a leitura das reservas voltar.', action: 'retry', actionLabel: 'Tentar de novo' };
    if (/no activity in that period/.test(e.message)) return { tone: 'info', technical, title: 'Nada a compartilhar', detail: 'O seu saldo não teve movimentação nesse período.' };
    if (/1 to 366 days/.test(e.message)) return { tone: 'warn', technical, title: 'Validade inválida', detail: 'Um compartilhamento vale de 1 a 366 dias.' };
    return { tone: 'danger', technical, title: 'A carteira recusou', detail: 'A carteira recusou a operação.' };
  }
  if (e instanceof PartialLock) {
    return { tone: 'warn', technical, title: 'Pedido travado em parte', detail: `${e.locked.length} parte(s) do pedido foram travadas e o restante não. Pague ou cancele cada parte travada abaixo.` };
  }
  if (e instanceof BuyRefused) {
    const r = buyRefusal(e.message);
    // A buy refused for its quote (expired, or the offers moved) is undone by quoting again: say so on the button.
    return { tone: 'danger', technical, ...r, ...(r.action === 'retry' ? { actionLabel: 'Cotar de novo' } : {}) };
  }
  if (e instanceof AspRefused) {
    return /has not approved/.test(e.message)
      ? { tone: 'info', technical, title: 'Aguardando aprovação', detail: 'Seu depósito mais recente ainda não foi aprovado pela ASP (o conjunto de associação). Tente de novo em alguns instantes.', action: 'retry', actionLabel: 'Tentar de novo' }
      : { tone: 'info', technical, title: 'Lista da ASP desatualizada', detail: 'A lista de aprovações ainda não reflete a blockchain. Tente de novo em alguns instantes.', action: 'retry', actionLabel: 'Tentar de novo' };
  }
  if (e instanceof ProofRefused) return { tone: 'danger', technical, title: 'Prova recusada', detail: 'A prova gerada não diz o que a carteira pediu, então não foi enviada. Tente de novo.', action: 'retry', actionLabel: 'Tentar de novo' };
  if (e instanceof LedgerRefused) {
    return {
      tone: 'danger', technical, title: 'Histórico incompleto neste aparelho', action: 'retry', actionLabel: 'Baixar o histórico do cofre de novo',
      detail: 'As notas deste aparelho não conferem com as posições do pool, então nenhum valor é mostrado. Se a carteira foi usada há pouco em outro aparelho, o histórico pode ainda estar chegando ao cofre.',
    };
  }
  if (e instanceof SponsorshipNotGranted) {
    const s = e.sponsorship;
    const r = SPONSORSHIP_REFUSALS[s.code ?? s.status] ?? { detail: 'O cossignatário não patrocinou a conta, e sem patrocínio o paymaster não paga o gás da primeira operação.', retry: s.retryable === true };
    return {
      tone: 'danger', technical, ...(s.code ? { code: s.code } : {}), title: 'Conta não patrocinada', detail: `${r.detail} Nada foi enviado.`,
      ...(r.retry ? { action: 'retry' as const, actionLabel: 'Tentar de novo' } : {}),
    };
  }
  if (e instanceof AlertsUnavailableHere) {
    return {
      tone: 'warn', technical, title: 'Alertas indisponíveis aqui',
      detail: e.reason === 'eoa' ? 'Uma conta simples (EOA) não tem recuperação com prazo, então não há o que alertar.'
        : e.reason === 'cosigner' ? COSIGNER_REFUSALS.alerts_disabled!.detail
          : 'Este navegador não recebe notificações do app: abra o app instalado (ou a versão compilada) num navegador com notificações push.',
    };
  }
  if (e instanceof CoSignerRefused) {
    const r = COSIGNER_REFUSALS[e.code];
    return {
      tone: 'danger', technical, code: e.code, title: r?.title ?? 'O cossignatário recusou a operação', detail: r?.detail ?? 'O segundo signatário da conta não assinou. Nada foi enviado.',
      ...(r?.action ? { action: r.action, actionLabel: 'Tentar de novo' } : {}),
    };
  }
  if (e instanceof AccountSetupError) return { tone: 'danger', technical, title: 'Conta não configurada', detail: e.message };
  if (e instanceof ExecutionFailed) {
    // BundlerSubmitter: the bundler answered the submission with an error, so the operation never reached the chain.
    if (/^eth_sendUserOperation:/.test(e.message)) {
      return { tone: 'danger', technical, title: 'Operação não enviada', detail: 'O bundler não aceitou a operação, então nada foi enviado por ela.', action: 'retry', actionLabel: 'Tentar de novo' };
    }
    return { tone: 'danger', technical, title: 'Transação revertida', detail: 'A transação foi recusada pela blockchain.' };
  }
  if (e instanceof AmountInputError) return { tone: 'warn', title: 'Valor inválido', detail: e.message };
  if (e instanceof InputInvalid) return { tone: 'warn', title: e.title, detail: e.message };
  if (e instanceof DeploymentNotCanonical) return { tone: 'danger', technical, title: 'Deployment não confere com o registro', detail: `O arquivo foi recusado: ${e.message}.` };
  if (e instanceof DeploymentInvalid) return { tone: 'danger', technical, title: 'Deployment inválido', detail: e.message };
  if (e instanceof RemoteServiceError) return { tone: 'danger', technical, title: 'Serviço indisponível', detail: 'Um serviço da rede Movva não respondeu. Tente de novo.', action: 'retry', actionLabel: 'Tentar de novo' };
  if (e instanceof StoreUnreadable) return { tone: 'danger', technical, title: 'Dados locais ilegíveis', detail: e instanceof Error ? e.message : '' };
  if (e instanceof SeedSourceMismatchError) return { tone: 'danger', technical, title: 'Outra origem de chave', detail: 'Esta carteira foi criada com outra forma de desbloqueio. Usar esta abriria uma carteira diferente e vazia: use a passkey original.' };
  if (e instanceof PrfUnsupported) return { tone: 'warn', technical, title: 'Passkey sem PRF', detail: 'Seu autenticador não calcula a chave da carteira (extensão PRF), e não há outro caminho. Use outro navegador ou aparelho, ou uma chave de segurança física com PRF.' };
  if (e instanceof PasskeyUnavailable) return { tone: 'warn', technical, title: 'Passkey indisponível', detail: e instanceof Error ? e.message : '' };
  if (named(e, 'NotAllowedError')) return { tone: 'warn', technical, title: 'Passkey não confirmada', detail: 'A passkey foi cancelada ou o tempo acabou. Tente de novo.', action: 'retry', actionLabel: 'Tentar de novo' };
  if (e instanceof SeedUnavailableError) {
    return { tone: 'danger', technical, title: 'Não foi possível abrir a carteira', detail: 'A passkey usada não devolveu a extensão PRF, que calcula a chave da carteira. Use a mesma passkey com que a carteira foi criada, sincronizada neste aparelho, num navegador com PRF.' };
  }
  if (/no liquidity on the requested rails/.test(technical)) return { tone: 'warn', technical, title: 'Sem liquidez', detail: 'Não há oferta nesse meio de pagamento agora.' };
  if (/cannot fill a deposit of that size/.test(technical)) return { tone: 'warn', technical, title: 'Valor alto demais', detail: 'As ofertas não comportam esse valor agora. Tente um valor menor.' };
  return { tone: 'danger', technical, title: 'Algo deu errado', detail: 'A operação não foi concluída.' };
}
