import { useCallback, useEffect, useMemo, useRef, useState, type ReactElement } from 'react';
import type { Hex } from 'viem';
import { circuitsBaseUrl } from '../circuits.js';
import { DeploymentInvalid, parseDeployment, requireSecureUrl, withOverrides, type AppDeployment, type EndpointOverrides } from '../lib/deployment.js';
import { assessDeployment, loadAccepted, saveAccepted, type DeploymentVerdict } from '../lib/deployment-trust.js';
import { InputInvalid } from '../lib/format.js';
import { browserAccountOwner, forgetIdentity, saveIdentity, type StoredIdentity } from '../passkey/seed.js';
import { WalletSession, type RestoreSummary } from '../wallet/session.js';
import { browserPushRegistration } from '../wallet/push.js';
import { browserKeyValue } from '../wallet/stores.js';
import { WorkerWithdrawalProver } from '../wallet/worker-prover.js';
import { Audit } from './Audit.js';
import { Buy } from './Buy.js';
import { ErrorNotice, Spinner } from './components.js';
import { DeploymentConfirm } from './DeploymentConfirm.js';
import { DevPanel } from './DevPanel.js';
import { Home } from './Home.js';
import { WalletContext } from './hooks.js';
import { Onboarding } from './Onboarding.js';
import { ReserveRisks } from './ReserveRisks.js';
import { Sell } from './Sell.js';
import { Settings } from './Settings.js';
import { SubWallets } from './SubWallets.js';
import { SubWalletManager } from '../wallet/subwallets.js';

const DEPLOYMENT_URL = 'mova:deployment-url';
const DEPLOYMENT_JSON = 'mova:deployment-json';
const OVERRIDES = 'mova:endpoint-overrides';

const defaultDeploymentUrl = () => new URL('api/deployment.json', document.baseURI).href;

async function fetchDeployment(url: string): Promise<AppDeployment> {
  let parsed: URL;
  try {
    parsed = new URL(url, document.baseURI);
  } catch {
    throw new DeploymentInvalid(`URL inválida (${url})`);
  }
  requireSecureUrl(parsed, 'URL do deployment');
  const abs = parsed.href;
  let res: Response;
  try {
    res = await fetch(abs);
  } catch {
    throw new DeploymentInvalid(`não foi possível acessar ${abs}`);
  }
  if (!res.ok) throw new DeploymentInvalid(`não foi possível carregar ${abs} (HTTP ${res.status})`);
  return parseDeployment(await res.json(), abs);
}

/** A deployment waiting for the user's confirmation (deployment-trust.ts), and what to save once confirmed. */
interface PendingDeployment {
  /** The deployment as loaded, without the device's endpoint overrides. */
  deployment: AppDeployment;
  /** As it will be used: with the overrides. What the user is shown and what is remembered as accepted (M-23). */
  effective: AppDeployment;
  verdict: Extract<DeploymentVerdict, { kind: 'confirm' }>;
  persist: () => void;
}

const applied = (d: AppDeployment, o: EndpointOverrides): AppDeployment => {
  try {
    return withOverrides(d, o);
  } catch {
    return d;
  }
};

type Route = { path: string; param?: string };
const parseHash = (hash: string): Route => {
  const [path = 'inicio', param] = hash.replace(/^#\/?/, '').split('/');
  return { path: path || 'inicio', param };
};

function useHashRoute(): Route {
  const [route, setRoute] = useState(() => parseHash(location.hash));
  useEffect(() => {
    const on = () => setRoute(parseHash(location.hash));
    window.addEventListener('hashchange', on);
    return () => window.removeEventListener('hashchange', on);
  }, []);
  return route;
}

type Phase =
  | { kind: 'loading' }
  | { kind: 'setup' }
  | { kind: 'locked'; error?: unknown }
  | { kind: 'opening' }
  | { kind: 'ready'; session: WalletSession; identity: StoredIdentity; restore: RestoreSummary };

const NAV: { path: string; label: string; icon: string }[] = [
  { path: 'inicio', label: 'Início', icon: '◉' },
  { path: 'comprar', label: 'Comprar', icon: '＋' },
  { path: 'vender', label: 'Vender', icon: '－' },
  { path: 'auditoria', label: 'Auditoria', icon: '§' },
  { path: 'ajustes', label: 'Ajustes', icon: '⚙' },
  { path: 'subcarteiras', label: 'Sub-carteiras', icon: '⊞' },
];

export function App() {
  const kv = useMemo(() => browserKeyValue(), []);
  const [base, setBase] = useState<AppDeployment>();
  const [deploymentError, setDeploymentError] = useState<unknown>();
  const [overrides, setOverrides] = useState<EndpointOverrides>(() => {
    try {
      return JSON.parse(kv.get(OVERRIDES) ?? '{}') as EndpointOverrides;
    } catch {
      return {};
    }
  });
  // Read through a ref by `consider`, so saving overrides does not re-run the start-up load.
  const overridesRef = useRef(overrides);
  overridesRef.current = overrides;
  const [phase, setPhase] = useState<Phase>({ kind: 'loading' });
  const [pending, setPending] = useState<PendingDeployment>();
  const prover = useRef<WorkerWithdrawalProver | undefined>(undefined);
  /** Sub-wallets of the unlocked wallet, and the one the app is showing (none: the primary). */
  const subs = useRef<SubWalletManager | undefined>(undefined);
  const [activeSub, setActiveSub] = useState<{ id: string; session: WalletSession }>();
  const route = useHashRoute();

  const deployment = useMemo(() => {
    if (!base) return undefined;
    try {
      return withOverrides(base, overrides);
    } catch {
      return base;
    }
  }, [base, overrides]);

  const lock = useCallback(() => {
    prover.current?.terminate();
    prover.current = undefined;
    subs.current = undefined;
    setActiveSub(undefined);
    setPhase({ kind: 'locked' });
  }, []);

  const adopt = useCallback((d: AppDeployment) => {
    setBase(d);
    setDeploymentError(undefined);
    lock();
  }, [lock]);

  /**
   * Use `d` if this device accepted exactly it before, or if it is its chain's canonical deployment and none was
   * accepted yet; otherwise ask first. A file that contradicts its chain's canonical record throws.
   */
  const consider = useCallback((d: AppDeployment, persist: () => void, o: { fromDefaultSource?: boolean; overrides?: EndpointOverrides } = {}) => {
    // Judged as it will be used, overrides included, so neither a file nor Ajustes can change an endpoint unasked (M-23).
    const effective = applied(d, o.overrides ?? overridesRef.current);
    const verdict = assessDeployment(effective, loadAccepted(kv), undefined, { fromDefaultSource: o.fromDefaultSource ?? false });
    if (verdict.kind === 'use') {
      persist();
      saveAccepted(kv, effective);
      adopt(d);
    } else {
      setPending({ deployment: d, effective, verdict, persist });
    }
  }, [kv, adopt]);

  useEffect(() => {
    void (async () => {
      try {
        // A saved file is not trusted for being saved: it is checked and compared like any other.
        const saved = kv.get(DEPLOYMENT_JSON);
        const fromDefaultSource = !saved && !kv.get(DEPLOYMENT_URL);
        consider(saved ? parseDeployment(JSON.parse(saved), location.href) : await fetchDeployment(kv.get(DEPLOYMENT_URL) ?? defaultDeploymentUrl()), () => {}, { fromDefaultSource });
      } catch (e) {
        setDeploymentError(e);
        setPhase({ kind: 'setup' });
      }
    })();
  }, [kv, consider]);

  const onUnlocked = useCallback(async (seed: Uint8Array, identity: StoredIdentity) => {
    if (!deployment) return;
    setPhase({ kind: 'opening' });
    try {
      prover.current ??= new WorkerWithdrawalProver({ circuitsBaseUrl: circuitsBaseUrl() });
      const session = await WalletSession.open({
        deployment, rootSeed: seed, kv, prover: prover.current, circuitsBaseUrl: circuitsBaseUrl(), pushRegistration: browserPushRegistration,
        owner: browserAccountOwner(identity), accountKind: identity.account,
      });
      let current = identity;
      // Its address depends on its kind: keep the one this wallet turned out to be.
      if (session.accountKind !== 'eoa' && identity.account !== session.accountKind) {
        current = { ...identity, account: session.accountKind };
        saveIdentity(kv, current);
      }
      await session.ensureGas().catch(() => undefined);
      subs.current = new SubWalletManager({
        kv, deployment, primarySeed: seed, primaryAddress: session.address, now: () => Math.floor(Date.now() / 1000),
        open: (subSeed) => WalletSession.open({
          deployment, rootSeed: subSeed, kv, prover: prover.current!, circuitsBaseUrl: circuitsBaseUrl(), subWallet: true,
          // I-56: a sub-wallet's sale accounts sign only after the passkey that unlocked the app confirms.
          confirmWith: browserAccountOwner(identity),
        }),
      });
      const restore = await session.restoreOrFile();
      setPhase({ kind: 'ready', session, identity: current, restore });
      if (!location.hash) location.hash = '#/inicio';
    } catch (e) {
      setPhase({ kind: 'locked', error: e });
    }
  }, [deployment, kv]);

  const settings = (session?: { session: WalletSession; identity: StoredIdentity }) => (
    <Settings
      deployment={deployment}
      deploymentError={deploymentError}
      defaultUrl={kv.get(DEPLOYMENT_URL) ?? defaultDeploymentUrl()}
      overrides={overrides}
      onLoadUrl={async (url) => {
        const d = await fetchDeployment(url);
        consider(d, () => {
          kv.set(DEPLOYMENT_URL, d.source);
          kv.remove(DEPLOYMENT_JSON);
        });
      }}
      onLoadJson={async (text) => {
        let json: unknown;
        try {
          json = JSON.parse(text);
        } catch {
          throw new DeploymentInvalid('o arquivo não é JSON');
        }
        const d = parseDeployment(json, location.href);
        consider(d, () => kv.set(DEPLOYMENT_JSON, text));
      }}
      onSaveOverrides={(o) => {
        const save = () => {
          kv.set(OVERRIDES, JSON.stringify(o));
          setOverrides(o);
        };
        // An override is a change of endpoint like any other: confirmed against what was accepted (M-23).
        if (base) consider(base, save, { overrides: o });
        else save();
        lock();
      }}
      session={session && {
        address: session.session.address, accountKind: session.session.accountKind, coSigner: session.session.coSigner,
        vaultFailures: session.session.vaultFailures(), onLock: lock,
        onForget: () => { session.session.forgetDevice(); forgetIdentity(kv); lock(); },
      }}
    />
  );

  let body;
  if (pending) {
    body = (
      <DeploymentConfirm
        deployment={pending.effective} verdict={pending.verdict} hasCurrent={!!base}
        onConfirm={() => {
          pending.persist();
          saveAccepted(kv, pending.effective);
          setPending(undefined);
          adopt(pending.deployment);
        }}
        onCancel={() => {
          setPending(undefined);
          if (!base) {
            setDeploymentError(new InputInvalid('Deployment recusado', 'Carregue outro abaixo, por URL ou arquivo.'));
            setPhase({ kind: 'setup' });
          }
        }}
      />
    );
  } else if (phase.kind === 'loading') {
    body = <Spinner label="Carregando..." />;
  } else if (phase.kind === 'setup' || !deployment) {
    body = settings();
  } else if (phase.kind !== 'ready') {
    body = route.path === 'ajustes'
      ? settings()
      : <Onboarding deployment={deployment} kv={kv} opening={phase.kind === 'opening'} error={phase.kind === 'locked' ? phase.error : undefined} onUnlocked={(s, i) => void onUnlocked(s, i)} />;
  } else {
    const { session } = phase;
    const screens: Record<string, () => ReactElement> = {
      inicio: () => <Home restored={phase.restore.restored ? phase.restore : undefined} />,
      comprar: () => <Buy orderId={route.param as Hex | undefined} />,
      vender: () => <Sell />,
      auditoria: () => <Audit />,
      ajustes: () => settings(phase),
      reserva: () => <ReserveRisks />,
      subcarteiras: () => (subs.current
        ? <SubWallets manager={subs.current} activeId={activeSub?.id} now={session.now()}
            onSwitch={(id) => { if (!id) setActiveSub(undefined); else void subs.current!.open(id).then((s) => setActiveSub({ id, session: s as WalletSession })); }} />
        : <Spinner label="Carregando..." />),
      dev: () => <DevPanel />,
    };
    body = (
      <WalletContext.Provider value={route.path === 'subcarteiras' ? session : (activeSub?.session ?? session)}>
        {activeSub && route.path !== 'subcarteiras' && (
          <div className="notice info" role="status" data-testid="subwallet-banner">
            Você está em uma sub-carteira ({subs.current?.list().find((x) => x.id === activeSub.id)?.label}). <a href="#/subcarteiras">Trocar</a>
          </div>
        )}
        {(screens[route.path] ?? screens.inicio)()}
        <nav className="nav" aria-label="Navegação">
          <ul>
            {NAV.map((n) => (
              <li key={n.path}>
                <a href={`#/${n.path}`} aria-current={route.path === n.path ? 'page' : undefined}>
                  <span className="icon" aria-hidden="true">{n.icon}</span>{n.label}
                </a>
              </li>
            ))}
            {session.dev && (
              <li><a href="#/dev" aria-current={route.path === 'dev' ? 'page' : undefined}><span className="icon" aria-hidden="true">⚑</span>Teste</a></li>
            )}
          </ul>
        </nav>
      </WalletContext.Provider>
    );
  }

  return (
    <div className="shell">
      <header className="topbar">
        <span className="brand">Movva</span>
        <span className="meta">
          {deployment ? deployment.name : 'sem deployment'}
          {phase.kind === 'ready' && <><br /><a href="#/ajustes" onClick={lock}>Bloquear</a></>}
        </span>
      </header>
      {phase.kind === 'setup' && !deployment && <ErrorNotice error={deploymentError} />}
      {body}
    </div>
  );
}
