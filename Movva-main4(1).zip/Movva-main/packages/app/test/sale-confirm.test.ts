import { describe, expect, it } from 'vitest';
import { newSoftwarePasskeyKey, softwarePasskey } from '@mova/smart-account';
import { SaleRefused } from '@mova/wallet';
import { confirmSaleWithPasskey, saleConfirmationChallenge } from '../src/wallet/sale-confirm.js';
import type { AccountOwnerKey } from '../src/wallet/account.js';

const SITE = { rpId: 'app.movva.example', origin: 'https://app.movva.example' };

/** v2.0 I-56: a sale account signs only after the user's passkey confirmed what it is about to do. */
describe('sale-account confirmation by the user\'s passkey', () => {
  const owner = () => softwarePasskey({ privateKey: newSoftwarePasskeyKey(), ...SITE });

  it('signs a challenge naming the action and its details, domain-separated, whatever their order', async () => {
    const asked: Uint8Array[] = [];
    const o = owner();
    const spy: AccountOwnerKey = { ...o, sign: (c) => { asked.push(c); return o.sign(c); } };
    await confirmSaleWithPasskey(spy, 'sell', { receive: '9900', pixKey: 'a@b.example' });
    expect(asked).toEqual([saleConfirmationChallenge('sell', { pixKey: 'a@b.example', receive: '9900' })]);
    expect(saleConfirmationChallenge('cancel', { receive: '9900', pixKey: 'a@b.example' })).not.toEqual(asked[0]);
    expect(saleConfirmationChallenge('sell', { receive: '9901', pixKey: 'a@b.example' })).not.toEqual(asked[0]);
  });

  it('refuses when the passkey declines, answers for another challenge or key, or without user verification', async () => {
    const o = owner();
    const refused = (k: AccountOwnerKey) => confirmSaleWithPasskey(k, 'cancel', { saleId: '0x01' }).then(() => undefined, (e: unknown) => e);

    expect(await refused({ ...o, sign: async () => { throw new Error('NotAllowedError'); } })).toMatchObject({ code: 'sale_not_confirmed' });
    expect(await refused({ ...o, sign: () => o.sign(new Uint8Array(32)) })).toBeInstanceOf(SaleRefused);
    const other = owner();
    expect(await refused({ ...o, sign: (c) => other.sign(c) })).toMatchObject({ code: 'sale_not_confirmed' });
    // Presence without verification (flags UP only): not a confirmation.
    const noUv: AccountOwnerKey = {
      ...o,
      sign: async (c) => {
        const a = await o.sign(c);
        const authenticatorData = a.authenticatorData.slice();
        authenticatorData[32] = 0x01;
        return { ...a, authenticatorData };
      },
    };
    expect(await refused(noUv)).toMatchObject({ code: 'sale_not_confirmed' });
    expect(await refused(o)).toBeUndefined();
  });
});
