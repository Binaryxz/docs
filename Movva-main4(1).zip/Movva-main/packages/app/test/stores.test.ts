import { describe, expect, it } from 'vitest';
import { privateKeyToAccount } from 'viem/accounts';
import { parse, stringify } from '../src/lib/json.js';
import { deriveAccountKey } from '../src/wallet/keys.js';
import { MemoryKeyValue, SealedStore, StoreRolledBack, StoreUnreadable, storeKeyFromSeed, type GenerationAnchor } from '../src/wallet/stores.js';
import { VaultAnchor } from '../src/wallet/remote.js';
import { Auditor, LocalGrantRegistry, NoteVault, VaultService } from '@mova/viewing-key';
import { xchacha20poly1305 } from '@noble/ciphers/chacha';
import { bytesToHex, randomBytes, utf8ToBytes } from '@noble/hashes/utils';

const seed = (b: number) => new Uint8Array(32).fill(b);

describe('JSON with bigints', () => {
  it('round-trips bigints anywhere, and nothing else changes', () => {
    const v = { a: 1n, b: [2n, 'x', { c: 10n ** 30n }], d: -5n, e: null, f: 'text' };
    expect(parse(stringify(v))).toEqual(v);
  });

  it('an object that merely has a $bigint field among others stays an object', () => {
    expect(parse('{"$bigint":"1","other":true}')).toEqual({ $bigint: '1', other: true });
  });
});

describe('the sealed local store', () => {
  it('keeps records encrypted, and reads them back with the same seed', () => {
    const kv = new MemoryKeyValue();
    const store = new SealedStore(kv, storeKeyFromSeed(seed(1)), 'mova:test:');
    store.write('activity:sales', [{ payee: '+5511987654321', receive: 2_000n }]);
    const raw = kv.get('mova:test:activity:sales')!;
    expect(raw).not.toContain('5511987654321');
    expect(store.read('activity:sales')).toEqual([{ payee: '+5511987654321', receive: 2_000n }]);
  });

  it('another seed cannot read them', () => {
    const kv = new MemoryKeyValue();
    new SealedStore(kv, storeKeyFromSeed(seed(1)), 'mova:test:').write('x', { secret: 1 });
    expect(() => new SealedStore(kv, storeKeyFromSeed(seed(2)), 'mova:test:').read('x')).toThrow(StoreUnreadable);
  });

  it('a record moved under another name does not open: the name is bound to the ciphertext', () => {
    const kv = new MemoryKeyValue();
    const store = new SealedStore(kv, storeKeyFromSeed(seed(1)), 'mova:test:');
    store.write('sale-keys', { a: '0xkey' });
    kv.set('mova:test:activity:orders', kv.get('mova:test:sale-keys')!);
    expect(() => store.read('activity:orders')).toThrow(StoreUnreadable);
  });

  it('sale records by id, whatever the case; lists upsert newest first; clear forgets only this wallet', () => {
    const kv = new MemoryKeyValue();
    kv.set('other:app', 'kept');
    const store = new SealedStore(kv, storeKeyFromSeed(seed(1)), 'mova:test:');
    const sales = store.saleStore();
    const record = { saleId: '0xABCDEF' as const, account: '0x0000000000000000000000000000000000000001' as const, payee: { kind: 'pix' as const, pixKey: 'a@b.c' }, salt: '0x01' as const, receiveCents: '100' };
    sales.put(record);
    expect(sales.get('0xabcdef')).toEqual(record);
    store.upsert('l', { id: 1, v: 'a' }, (x: { id: number }) => x.id === 1);
    store.upsert('l', { id: 2, v: 'b' }, (x: { id: number }) => x.id === 2);
    store.upsert('l', { id: 1, v: 'c' }, (x: { id: number }) => x.id === 1);
    expect(store.list('l')).toEqual([{ id: 2, v: 'b' }, { id: 1, v: 'c' }]);
    store.clear();
    expect(kv.keys()).toEqual(['other:app']);
  });
});

describe('the sealed local store refuses old copies (I-57)', () => {
  const make = (kv = new MemoryKeyValue(), anchor?: GenerationAnchor) => ({ kv, store: new SealedStore(kv, storeKeyFromSeed(seed(1)), 'mova:test:', anchor) });

  it('an older copy of a record put back is refused, the latest opens', () => {
    const { kv, store } = make();
    store.write('sale-journal', { exits: ['planned'] });
    const before = kv.get('mova:test:sale-journal')!;
    store.write('sale-journal', { exits: ['submitted'] });
    store.write('other', 1);
    expect(store.read('sale-journal')).toEqual({ exits: ['submitted'] });
    kv.set('mova:test:sale-journal', before);
    expect(() => store.read('sale-journal')).toThrow(StoreRolledBack);
    expect(store.read('other')).toBe(1);
  });

  it('a removed record put back is refused: removal leaves a tombstone', () => {
    const { kv, store } = make();
    store.write('reservation', { index: 7 });
    const copy = kv.get('mova:test:reservation')!;
    store.remove('reservation');
    expect(store.read('reservation')).toBeUndefined();
    kv.set('mova:test:reservation', copy);
    expect(() => store.read('reservation')).toThrow(StoreRolledBack);
    store.write('reservation', { index: 8 });
    expect(store.read('reservation')).toEqual({ index: 8 });
  });

  it('a record written before a crash that lost the manifest\'s update still opens, and is then known', () => {
    const { kv, store } = make();
    store.write('a', 1);
    const manifest = kv.get('mova:test:__manifest')!;
    store.write('a', 2);
    kv.set('mova:test:__manifest', manifest); // the crash: the record landed, the manifest did not
    expect(store.read('a')).toBe(2);
    store.write('b', 3);
    expect(store.read('a')).toBe(2);
  });

  it('a record from before generations opens once, is sealed again, and its old copy is refused after', () => {
    const { kv, store } = make();
    const key = storeKeyFromSeed(seed(1));
    const n = randomBytes(24);
    const legacy = JSON.stringify({ v: 1, n: bytesToHex(n), c: bytesToHex(xchacha20poly1305(key, n, utf8ToBytes('mova:test:old')).encrypt(utf8ToBytes('{"x":1}'))) });
    kv.set('mova:test:old', legacy);
    expect(store.read('old')).toEqual({ x: 1 });
    expect(JSON.parse(kv.get('mova:test:old')!)).toMatchObject({ v: 2 });
    kv.set('mova:test:old', legacy);
    expect(() => store.read('old')).toThrow(StoreRolledBack);
  });

  it('with an anchor outside the storage, a rollback of the whole storage is seen', () => {
    let kept: number | undefined;
    const anchor: GenerationAnchor = { read: () => kept, write: (g) => { kept = g; } };
    const { kv, store } = make(new MemoryKeyValue(), anchor);
    store.write('a', 1);
    const snapshot = new Map(kv.keys().map((k) => [k, kv.get(k)!]));
    store.write('a', 2);
    for (const [k, v] of snapshot) kv.set(k, v);
    expect(() => store.read('a')).toThrow(StoreRolledBack);
  });
});

describe('the anchor at the note vault (I-57)', () => {
  it('sees a rollback of the whole local storage once the vault holds a newer generation', async () => {
    const registry = new LocalGrantRegistry();
    const service = new VaultService({ vault: new NoteVault(registry), now: () => 1_800_000_000 });
    const port = await service.listen(0, '127.0.0.1');
    try {
      const url = `http://127.0.0.1:${port}`;
      const identityPriv = new Uint8Array(32).fill(9);
      const o = { url, poolId: 'pp:11155111:0xpool#device:abc', owner: new Auditor(identityPriv).publicKey, identityPriv, now: () => 1_800_000_000 };
      const kv = new MemoryKeyValue();
      const first = await VaultAnchor.open(o);
      const store = new SealedStore(kv, storeKeyFromSeed(seed(1)), 'mova:test:', first);
      store.write('a', 1);
      const snapshot = new Map(kv.keys().map((k) => [k, kv.get(k)!]));
      store.write('a', 2);
      await first.settled();
      expect(first.failures).toBe(0);

      // The whole storage put back as it was, then a fresh session: the vault remembers the later generation.
      for (const [k, v] of snapshot) kv.set(k, v);
      const reopened = new SealedStore(kv, storeKeyFromSeed(seed(1)), 'mova:test:', await VaultAnchor.open(o));
      expect(() => reopened.read('a')).toThrow(StoreRolledBack);
      // Another device of the same seed has its own anchor, and is not mistaken for a rollback.
      const other = new SealedStore(new MemoryKeyValue(), storeKeyFromSeed(seed(1)), 'mova:test:', await VaultAnchor.open({ ...o, poolId: 'pp:11155111:0xpool#device:def' }));
      other.write('a', 1);
      expect(other.read('a')).toBe(1);
    } finally {
      await service.close();
    }
  });
});

describe('keys derived from the seed', () => {
  it('the account key is recomputed from the seed, and is not the store key', () => {
    const k = deriveAccountKey(seed(9));
    expect(deriveAccountKey(seed(9))).toBe(k);
    expect(deriveAccountKey(seed(8))).not.toBe(k);
    expect(k.slice(2)).not.toBe(Buffer.from(storeKeyFromSeed(seed(9))).toString('hex'));
    expect(privateKeyToAccount(k).address).toMatch(/^0x[0-9a-fA-F]{40}$/);
  });
});
