import { describe, expect, it } from 'vitest';
import { getAddress } from 'viem';
import { DeploymentInvalid, parseDeployment, withOverrides } from '../src/lib/deployment.js';

const a = (n: number) => `0x${n.toString(16).padStart(40, '0')}`;
const SOURCE = 'http://127.0.0.1:8981/api/deployment.json';

const json = () => ({
  version: 1,
  name: 'Movva · demonstração local (anvil)',
  chainId: 31337,
  rpcUrl: '/api/rpc',
  fromBlock: '42',
  contracts: {
    movva: a(1), reserve: a(3), onramp: a(4), offramp: a(5), entrypoint: a(6), movvaPool: a(7),
    saleVerifier: a(10), auditGrantRegistry: a(11),
  },
  services: { matcher: '/api/matcher', lpNodes: [{ lp: a(12), url: '/api/lp', name: 'LP' }], relayer: '/api/relayer', asp: '/api/asp', vault: '/api/vault', shares: '/api/shares' },
  trust: { pixLocationHosts: [] },
  policy: { exitRelayFeeBps: '50', saleDiscountBps: '100' },
  account: { kind: 'eoa' },
  dev: { url: '/api/dev' },
});

describe('deployment JSON', () => {
  it('resolves relative endpoints against where the file was loaded from', () => {
    const d = parseDeployment(json(), SOURCE);
    expect(d.rpcUrl).toBe('http://127.0.0.1:8981/api/rpc');
    expect(d.services.lpNodes[0]).toEqual({ lp: getAddress(a(12)), url: 'http://127.0.0.1:8981/api/lp', name: 'LP' });
    expect(d.contracts.movva).toBe(getAddress(a(1)));
    expect(d.services.vault).toBe('http://127.0.0.1:8981/api/vault');
    expect(d.dev?.url).toBe('http://127.0.0.1:8981/api/dev');
    expect(d.contracts.fromBlock).toBe(42n);
    expect(d.contracts.chainId).toBe(31337);
    expect(d.policy).toEqual({ exitRelayFeeBps: 50n, saleDiscountBps: 100n });
    // An older file's share server (the removed recovery-code path) is read past, never used.
    expect(d.services).not.toHaveProperty('shares');
  });

  it('refuses what it cannot use, naming the field, in Portuguese', () => {
    const bad = json();
    bad.contracts.movva = '0x1234';
    expect(() => parseDeployment(bad, SOURCE)).toThrow(new DeploymentInvalid('contracts.movva: endereço inválido'));
    expect(() => parseDeployment({ ...json(), version: 2 }, SOURCE)).toThrow('versão do arquivo de deployment não suportada (esperada: 1)');
    expect(() => parseDeployment({ ...json(), services: { ...json().services, lpNodes: [] } }, SOURCE)).toThrow('services.lpNodes: informe ao menos um nó de LP');
    expect(() => parseDeployment({ ...json(), rpcUrl: 'ftp://x' }, SOURCE)).toThrow('rpcUrl: URL inválida (ftp://x)');
  });

  it('optionally names the delta-neutral sub-wallet and its venue contract; a file without them reads as before', () => {
    const plain = parseDeployment(json(), SOURCE);
    expect('hedgeSubWallet' in plain.contracts).toBe(false);
    expect('hedgeVenue' in plain.contracts).toBe(false);
    const sleeve = parseDeployment({ ...json(), contracts: { ...json().contracts, hedgeSubWallet: a(30), hedgeVenue: a(31) } }, SOURCE);
    expect(sleeve.contracts.hedgeSubWallet).toBe(getAddress(a(30)));
    expect(sleeve.contracts.hedgeVenue).toBe(getAddress(a(31)));
    expect(parseDeployment({ ...json(), contracts: { ...json().contracts, hedgeSubWallet: a(30) } }, SOURCE).contracts.hedgeVenue).toBeUndefined();
    expect(() => parseDeployment({ ...json(), contracts: { ...json().contracts, hedgeSubWallet: '0x12' } }, SOURCE)).toThrow('contracts.hedgeSubWallet: endereço inválido');
    expect(() => parseDeployment({ ...json(), contracts: { ...json().contracts, hedgeVenue: a(31) } }, SOURCE)).toThrow(/contracts.hedgeVenue sem contracts.hedgeSubWallet/);
  });

  const smart = () => ({
    kind: 'safe', kinds: ['safe', 'kernel'], bundler: '/api/bundler', paymasterAndData: `0x${'ab'.repeat(20)}${'00'.repeat(32)}`,
    cosigner: { url: 'http://localhost:8986', address: a(20) },
    kernel: { passkeyValidator: a(21), adapter: a(22) }, gas: { verificationGasLimit: '2500000' }, sponsor: '/api/dev/sponsor',
  });

  it('reads a smart account: the kinds offered, the bundler, the pinned co-signer, the paymaster and the gas every operation signs; no sponsor endpoint', () => {
    const d = parseDeployment({ ...json(), account: smart() }, SOURCE);
    expect(d.account).toEqual({
      kind: 'safe', kinds: ['safe', 'kernel'], bundler: 'http://127.0.0.1:8981/api/bundler', paymasterAndData: smart().paymasterAndData,
      cosigner: { url: 'http://localhost:8986', address: getAddress(a(20)) },
      kernel: { passkeyValidator: getAddress(a(21)), adapter: getAddress(a(22)) },
      gas: { verificationGasLimit: 2_500_000n, callGasLimit: 2_500_000n, preVerificationGas: 400_000n },
    });
    // An old deployment's demo `sponsor` endpoint is ignored: accounts are sponsored by the co-signer at enrolment.
    expect(d.account).not.toHaveProperty('sponsor');
    expect(parseDeployment(json(), SOURCE).account).toEqual({ kind: 'eoa' });
    const moved = withOverrides(parseDeployment({ ...json(), account: smart() }, SOURCE), { bundler: 'https://bundler.example/rpc', cosigner: 'https://cosigner.example' });
    expect(moved.account).toMatchObject({ bundler: 'https://bundler.example/rpc', cosigner: { url: 'https://cosigner.example', address: getAddress(a(20)) } });
  });

  it('refuses a co-signer API key in the public deployment file (I-55)', () => {
    const withKey = { ...smart(), cosigner: { ...smart().cosigner, apiKey: 'k'.repeat(48) } };
    expect(() => parseDeployment({ ...json(), account: withKey }, SOURCE)).toThrow(/account.cosigner.apiKey: este arquivo é público/);
  });

  it('reads an ownerless paymaster instead of fixed paymasterAndData: the address, and gas limits only when given', () => {
    const { paymasterAndData: _p, ...noFixed } = smart();
    const d = parseDeployment({ ...json(), account: { ...noFixed, ownerlessPaymaster: { address: a(23) } } }, SOURCE);
    expect(d.account).toMatchObject({ ownerlessPaymaster: { address: getAddress(a(23)) } });
    expect(d.account).not.toHaveProperty('paymasterAndData');
    expect((d.account as { ownerlessPaymaster: object }).ownerlessPaymaster).toEqual({ address: getAddress(a(23)) });
    const tuned = parseDeployment({ ...json(), account: { ...noFixed, ownerlessPaymaster: { address: a(23), verificationGasLimit: '300000', postOpGasLimit: 60000 } } }, SOURCE);
    expect(tuned.account).toMatchObject({ ownerlessPaymaster: { address: getAddress(a(23)), verificationGasLimit: 300_000n, postOpGasLimit: 60_000n } });
    // One paymaster, never both, never neither.
    expect(() => parseDeployment({ ...json(), account: { ...smart(), ownerlessPaymaster: { address: a(23) } } }, SOURCE)).toThrow(/só um dos dois/);
    expect(() => parseDeployment({ ...json(), account: noFixed }, SOURCE)).toThrow(/informe o paymaster/);
    expect(() => parseDeployment({ ...json(), account: { ...noFixed, ownerlessPaymaster: { address: '0x12' } } }, SOURCE)).toThrow('account.ownerlessPaymaster.address: endereço inválido');
  });

  it('refuses a smart account missing what it needs, naming the field', () => {
    const { kernel: _k, ...noKernel } = smart();
    expect(() => parseDeployment({ ...json(), account: noKernel }, SOURCE)).toThrow(/account.kernel/);
    expect(() => parseDeployment({ ...json(), account: { ...smart(), bundler: undefined } }, SOURCE)).toThrow('account.bundler ausente ou inválido');
    expect(() => parseDeployment({ ...json(), account: { ...smart(), cosigner: { url: 'https://x', address: '0x12' } } }, SOURCE)).toThrow('account.cosigner.address: endereço inválido');
    expect(() => parseDeployment({ ...json(), account: { ...smart(), paymasterAndData: '0x1234' } }, SOURCE)).toThrow(/account.paymasterAndData/);
    expect(() => parseDeployment({ ...json(), account: { ...smart(), kind: 'kernel', kinds: ['safe'] } }, SOURCE)).toThrow('account.kinds precisa incluir account.kind');
    expect(() => parseDeployment({ ...json(), account: { kind: 'frost' } }, SOURCE)).toThrow(/account.kind "frost" não é aceito/);
  });

  it('endpoints changed in settings override the file\'s', () => {
    const d = withOverrides(parseDeployment(json(), SOURCE), { matcher: 'https://matcher.movva.example', lpNodes: [{ lp: a(13) as `0x${string}`, url: 'https://lp.example/node' }] });
    expect(d.services.matcher).toBe('https://matcher.movva.example');
    expect(d.services.lpNodes).toEqual([{ lp: getAddress(a(13)), url: 'https://lp.example/node', name: undefined }]);
    expect(d.rpcUrl).toBe('http://127.0.0.1:8981/api/rpc');
  });
});
