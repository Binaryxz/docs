/**
 * Onboarding on the ownerless paymaster with NO SponsorGate anywhere (SRM1-17's open items), end to end on anvil:
 *
 *  - **A fresh passkey account, Safe and Kernel.** The app's own `openSmartAccount` + `prepare()` enrols it over HTTP
 *    with the real co-signer service, whose sponsorship module runs without a gate (`ViemSponsorChain` with no `gate`,
 *    `ownerlessPaymaster` named): from its own operator key, through lp-node's TxSender, it creates the Safe's passkey
 *    signer or the Kernel account and allowlists nothing. Then the account's first operation (recovery setup + a call),
 *    passkey-signed and co-signed by the service, goes through the canonical EntryPoint v0.7 into OwnerlessPaymaster.
 *  - **A sub-wallet.** Its account is the 1-of-1 Safe of its own key (`subWalletSafe`), opened as the app opens it
 *    (`openSoleOwnerSafe`): no passkey, no co-signer, no enrolment. Its first operation carries the Safe's initCode and is
 *    sponsored; so is that of a sale account a sub-wallet opens the same way.
 *
 * The contracts are the real ones: packages/smart-account/fixtures through `deployAccountContracts` (mainnet's init
 * code at mainnet's addresses: EntryPoint, Safe 1.4.1, the passkey signer factory, Kernel v3.1, Zodiac Delay; our
 * validator and adapter), and OwnerlessPaymaster from the root build. The bundler is `EntryPoint.handleOps` from a
 * funded key; ERC-7562 admission of the same shapes is packages/smart-account/examples/erc7562-ownerless.ts.
 *
 * Skipped without anvil (the pinned toolchain, or ANVIL) or without the root build's OwnerlessPaymaster and
 * SponsorPaymaster artifacts (the shared stack deploys the latter, unused here); OWNERLESS_ANVIL_REQUIRED=1 makes that a
 * failure. Port: OWNERLESS_ONBOARDING_ANVIL_PORT, default 8958 (8955-8959 only).
 */
import { spawn, type ChildProcess } from 'node:child_process';
import { existsSync, readFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import {
  BaseError, concat, createPublicClient, createWalletClient, decodeErrorResult, decodeEventLog, defineChain, encodeFunctionData, getAddress, http,
  keccak256, pad, parseAbi, parseEther, toHex,
  type Abi, type Address, type Hex, type Log, type PublicClient,
} from 'viem';
import { generatePrivateKey, privateKeyToAccount } from 'viem/accounts';
import { KERNEL_V3_1, MAINNET, kernelProxyInitCode, newSoftwarePasskeyKey, softwarePasskey, ENTRYPOINT_ABI, type PackedUserOperation } from '@mova/smart-account';
import {
  OWNERLESS_PAYMASTER_ABI, createSubWallet, soleOwnerSafe, subWalletSafe, subWalletSaltNonce,
  type Executed, type UserOpSubmitter,
} from '@mova/wallet';
import { MemoryJournal } from '@mova/lp-node/src/journal.js';
import { TxSender } from '@mova/lp-node/src/tx-sender.js';
import {
  AuditLog, CoSignerService, SponsorshipModule, ViemAccountReader, ViemSponsorChain, localKey, operatorAccount, policyOf, serveCoSigner,
  type AuditRecord, type SponsorRecord,
} from '@mova/cosigner';
import { connectCoSigner, openSmartAccount, openSoleOwnerSafe } from '../src/wallet/account.js';
import { DEFAULT_SMART_ACCOUNT_GAS, type SmartAccountConfig } from '../src/lib/deployment.js';
import { deployAccountContracts, type AccountContracts } from '../../smart-account/examples/_account-stack.js';

const ROOT = fileURLToPath(new URL('../../../', import.meta.url));
const OUT = resolve(ROOT, process.env.FOUNDRY_OUT ?? 'forge-out');
const OWNERLESS_ARTIFACT = join(OUT, 'OwnerlessPaymaster.sol/OwnerlessPaymaster.json');
const SPONSOR_ARTIFACT = join(OUT, 'SponsorPaymaster.sol/SponsorPaymaster.json');
const PORT = Number(process.env.OWNERLESS_ONBOARDING_ANVIL_PORT ?? 8958);
const CHAIN_ID = 31_337;

function anvilBinary(): string | undefined {
  if (process.env.ANVIL) return existsSync(process.env.ANVIL) ? process.env.ANVIL : undefined;
  try {
    const p = join(ROOT, '.foundry-pinned', readFileSync(join(ROOT, 'foundry-version'), 'utf8').trim(), 'anvil');
    return existsSync(p) ? p : undefined;
  } catch {
    return undefined;
  }
}

const ANVIL = anvilBinary();
const missing = [
  !ANVIL && 'anvil (bash scripts/foundry.sh, or ANVIL)',
  !existsSync(OWNERLESS_ARTIFACT) && `${OWNERLESS_ARTIFACT} (forge build at the root)`,
  !existsSync(SPONSOR_ARTIFACT) && `${SPONSOR_ARTIFACT} (forge build at the root)`,
].filter(Boolean);
if (missing.length > 0 && process.env.OWNERLESS_ANVIL_REQUIRED === '1') throw new Error(`OWNERLESS_ANVIL_REQUIRED=1, but missing: ${missing.join(', ')}`);
if (!(PORT >= 8955 && PORT <= 8959)) throw new Error(`OWNERLESS_ONBOARDING_ANVIL_PORT must be in 8955-8959, got ${PORT}`);

// anvil's development keys: #0 deploys and funds, #1 bundles, #2 is the co-signer, #3 its sponsorship operator.
const funder = privateKeyToAccount('0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80');
const bundlerKey = privateKeyToAccount('0x59c6995e998f97a5a0044966f0945389dc9e86dae88c7a8412f4603b6b78690d');
const COSIGNER_KEY: Hex = '0x5de4111afa1a4b94908f83103eb1f1706367c2e68ca870fc3fb9a804cdab365a';
const OPERATOR_KEY: Hex = '0x7c852118294e51e653712a81e05800f419141751be58f605c371e15141b007a6';
const WEBAUTHN = { rpId: 'wallet.brl.example', origin: 'https://wallet.brl.example' };
/** The one call each first operation makes besides the recovery setup: allowlisted in the co-signer's policy. */
const TARGET = getAddress('0x000000000000000000000000000000000000cafe');
const NOTHING = [{ to: TARGET, data: '0x' as Hex }];
const WINDOW = 86_400n;

const chain = defineChain({
  id: CHAIN_ID, name: 'anvil', nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
  rpcUrls: { default: { http: [`http://127.0.0.1:${PORT}`] } },
});
const rpcUrl = `http://127.0.0.1:${PORT}`;

const EVENTS = parseAbi([
  'event UserOperationEvent(bytes32 indexed userOpHash, address indexed sender, address indexed paymaster, uint256 nonce, bool success, uint256 actualGasCost, uint256 actualGasUsed)',
  'event Sponsored(address indexed account, uint48 accountWindow, uint48 globalWindow, uint256 charged)',
]);
const EP_ERRORS = parseAbi(['error FailedOp(uint256 opIndex, string reason)', 'error FailedOpWithRevert(uint256 opIndex, string reason, bytes inner)']);

let anvil: ChildProcess | undefined;
let pub: PublicClient;
let stack: AccountContracts;
let pm: Address;
let config: SmartAccountConfig;
let audit: AuditLog;
let journal: MemoryJournal<AuditRecord>;
let module: SponsorshipModule;
let service: CoSignerService;
let closeServer: (() => Promise<void>) | undefined;

/** Every bundle handleOps sent, in order. */
const bundles: Log[][] = [];

/** EntryPoint.handleOps from a funded key, as a bundler sends it; a refusal says the EntryPoint's reason. */
class HandleOps implements UserOpSubmitter {
  async submit(op: PackedUserOperation): Promise<Executed> {
    const data = encodeFunctionData({ abi: ENTRYPOINT_ABI, functionName: 'handleOps', args: [[op], bundlerKey.address] });
    try {
      await pub.call({ account: bundlerKey.address, to: MAINNET.entryPoint, data, gas: 15_000_000n });
    } catch (e) {
      throw new Error(`handleOps refused: ${reason(e)}`);
    }
    const wallet = createWalletClient({ account: bundlerKey, chain, transport: http(rpcUrl) });
    const r = await pub.waitForTransactionReceipt({ hash: await wallet.sendTransaction({ account: bundlerKey, chain, to: MAINNET.entryPoint, data, gas: 15_000_000n }) });
    if (r.status !== 'success') throw new Error(`handleOps ${r.transactionHash} reverted`);
    bundles.push(r.logs);
    return { transactionHash: r.transactionHash, blockNumber: r.blockNumber, logs: r.logs };
  }
}

function reason(e: unknown): string {
  const data = e instanceof BaseError ? (e.walk((x) => typeof (x as { data?: unknown }).data === 'string') as { data?: Hex } | null)?.data : undefined;
  if (data) {
    try {
      const err = decodeErrorResult({ abi: EP_ERRORS, data });
      return err.errorName === 'FailedOp' ? err.args[1] : `${err.args[1]} ${err.args[2]}`;
    } catch { /* not the EntryPoint's */ }
  }
  return e instanceof Error ? e.message.split('\n')[0]! : String(e);
}

/** What the last bundle's one operation reported, and what the paymaster said it counted. */
function lastSettlement() {
  const decoded = bundles[bundles.length - 1]!.flatMap((l) => {
    try {
      return [decodeEventLog({ abi: EVENTS, data: l.data, topics: l.topics })];
    } catch {
      return [];
    }
  });
  const op = decoded.find((e) => e.eventName === 'UserOperationEvent');
  const sponsored = decoded.find((e) => e.eventName === 'Sponsored');
  return { op: op?.eventName === 'UserOperationEvent' ? op.args : undefined, sponsored: sponsored?.eventName === 'Sponsored' ? sponsored.args : undefined };
}

async function rpc<T>(method: string, params: unknown[] = []): Promise<T> {
  const res = await fetch(rpcUrl, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ jsonrpc: '2.0', id: 1, method, params }) });
  const body = await res.json() as { result?: T; error?: { message: string } };
  if (body.error) throw new Error(`${method}: ${body.error.message}`);
  return body.result as T;
}

const hasCode = async (address: Address) => ((await pub.getCode({ address })) ?? '0x') !== '0x';

async function startStack(): Promise<void> {
  anvil = spawn(ANVIL!, ['--port', String(PORT), '--chain-id', String(CHAIN_ID), '--quiet'], { stdio: ['ignore', 'ignore', 'pipe'] });
  let stderr = '';
  anvil.stderr!.on('data', (d: Buffer) => { stderr += d.toString(); });
  const deadline = Date.now() + 20_000;
  for (;;) {
    if (anvil.exitCode !== null) throw new Error(`anvil exited (${anvil.exitCode}): ${stderr}`);
    try {
      await rpc('eth_chainId');
      break;
    } catch {
      if (Date.now() > deadline) throw new Error(`anvil did not answer on port ${PORT}: ${stderr}`);
      await new Promise((r) => setTimeout(r, 100));
    }
  }
  pub = createPublicClient({ chain, transport: http(rpcUrl), pollingInterval: 100 }) as PublicClient;
  const quiet = { ok: () => {}, info: () => {}, fail: (what: string) => { throw new Error(what); } };
  stack = await deployAccountContracts({
    rpc: rpcUrl, chain, publicClient: pub, funder, report: quiet, paymasterArtifact: new URL(`file://${SPONSOR_ARTIFACT}`),
    paymasterDeposit: 0n, paymasterStake: 0n,
  });

  // OwnerlessPaymaster, both provenance roots read from the factories on this chain, as DeployAccountStack.s.sol does.
  const artifact = JSON.parse(readFileSync(OWNERLESS_ARTIFACT, 'utf8')) as { abi: Abi; bytecode: { object: Hex } };
  const proxyCreationCode = await pub.readContract({
    address: MAINNET.safeProxyFactory, abi: parseAbi(['function proxyCreationCode() pure returns (bytes)']), functionName: 'proxyCreationCode',
  });
  const wallet = createWalletClient({ chain, transport: http(rpcUrl) });
  const created = await pub.waitForTransactionReceipt({ hash: await wallet.deployContract({
    account: funder, chain, abi: artifact.abi, bytecode: artifact.bytecode.object, args: [MAINNET.entryPoint, {
      factory0: MAINNET.safeProxyFactory, proxyInitCodeHash0: keccak256(concat([proxyCreationCode, pad(MAINNET.safeSingleton, { size: 32 })])),
      factory1: KERNEL_V3_1.factory, proxyInitCodeHash1: keccak256(kernelProxyInitCode()),
      window: WINDOW, grace: 3_600n, maxCostPerOp: parseEther('0.05'), maxOpsPerAccount: 10n,
      maxCostPerAccount: parseEther('0.2'), maxCostGlobal: parseEther('2'), unstakeDelaySec: 86_400,
    }],
  }) });
  if (created.status !== 'success' || !created.contractAddress) throw new Error('OwnerlessPaymaster deployment reverted');
  pm = getAddress(created.contractAddress);
  const deposit = await pub.waitForTransactionReceipt({ hash: await wallet.sendTransaction({
    account: funder, chain, to: pm, data: encodeFunctionData({ abi: parseAbi(['function deposit() payable']), functionName: 'deposit' }), value: parseEther('5'),
  }) });
  if (deposit.status !== 'success') throw new Error('the paymaster deposit reverted');

  // The co-signer service, as src/bin/cosigner.ts builds it with COSIGNER_SPONSOR_OWNERLESS_PAYMASTER and no gate.
  const operator = localKey(OPERATOR_KEY);
  const sender = new TxSender(pub, createWalletClient({ account: operatorAccount(operator), chain, transport: http(rpcUrl) }), {
    replaceAfterBlocks: 3, bumpBps: 1_250, waitBlocks: 30, maxFeePerGasWei: 300n * 10n ** 9n, maxPriorityFeePerGasWei: 5n * 10n ** 9n,
  });
  journal = new MemoryJournal<AuditRecord>();
  const now = () => BigInt(Math.floor(Date.now() / 1000));
  audit = new AuditLog(journal, { now });
  audit.load();
  module = new SponsorshipModule({
    chainId: CHAIN_ID, chain: new ViemSponsorChain({ client: pub as never, sender, operator: operator.address }), audit, dailyCap: 10,
    ownerlessPaymaster: pm, now,
  });
  service = new CoSignerService({
    chainId: CHAIN_ID, key: localKey(COSIGNER_KEY), chain: new ViemAccountReader(pub as never, { entryPoint: MAINNET.entryPoint }),
    policy: policyOf({ targets: [{ address: TARGET, label: 'Vault' }] }),
    deployment: { entryPoint: MAINNET.entryPoint, passkeyValidator: stack.passkeyValidator, kernelAdapter: stack.adapter },
    audit, now, sponsorship: module,
  });
  service.ready = true;
  // The browser's API: open, as a key in the public deployment would be public anyway (I-55).
  const server = serveCoSigner(service, { mode: 'api', publicApi: true });
  const port = await server.listen(0, '127.0.0.1');
  closeServer = server.close;

  config = {
    kind: 'safe', kinds: ['safe', 'kernel'], bundler: 'http://bundler.invalid', ownerlessPaymaster: { address: pm },
    cosigner: { url: `http://127.0.0.1:${port}`, address: localKey(COSIGNER_KEY).address },
    kernel: { passkeyValidator: stack.passkeyValidator, adapter: stack.adapter }, gas: DEFAULT_SMART_ACCOUNT_GAS,
  };
}

const sponsorRecords = () => journal.load().filter((r): r is SponsorRecord => r.t === 'sponsor');

describe.skipIf(missing.length > 0)('the ownerless paymaster with no SponsorGate: passkey accounts and sub-wallets (anvil, real bytecode)', () => {
  beforeAll(startStack, 240_000);
  afterAll(async () => {
    await closeServer?.();
    if (anvil && anvil.exitCode === null) {
      const exited = new Promise((r) => anvil!.once('exit', r));
      anvil.kill('SIGTERM');
      await exited;
    }
  });

  it('the co-signer runs without a gate: it names the ownerless paymaster, and no SponsorGate exists on this chain', async () => {
    const cosigner = await connectCoSigner(config, CHAIN_ID, fetch);
    const info = await cosigner.info();
    expect(info.sponsorship).toEqual({ gate: null, ownerlessPaymaster: pm, operator: localKey(OPERATOR_KEY).address, dailyCap: 10 });
    expect(module.gated).toBe(false);
  });

  for (const kind of ['safe', 'kernel'] as const) {
    it(`a fresh passkey ${kind === 'safe' ? 'Safe' : 'Kernel account'}: enrolled, readied by the co-signer's operator, and its first operation sponsored`, async () => {
      const cosigner = await connectCoSigner(config, CHAIN_ID, fetch);
      const owner = softwarePasskey({ privateKey: newSoftwarePasskeyKey(), ...WEBAUTHN });
      const account = await openSmartAccount({ config, chainId: CHAIN_ID, publicClient: pub, cosigner, bundler: new HandleOps(), sponsorshipTimeoutMs: 60_000 },
        { kind, owner, salt: BigInt(toHex(crypto.getRandomValues(new Uint8Array(16)))) });
      expect(await hasCode(account.address)).toBe(false);
      expect(await hasCode(account.passkeySigner)).toBe(false);

      // Enrolment and the co-signer's preparation, as the app runs them before a first operation.
      expect(await account.prepare()).toEqual({ enrolled: true, sponsored: true });
      const record = sponsorRecords().at(-1)!;
      expect(record).toMatchObject({ outcome: 'prepared', account: account.address, kind: `${kind}-passkey`, operator: localKey(OPERATOR_KEY).address });
      expect(record.sponsorTx).toBeUndefined();
      if (kind === 'safe') {
        // The Safe validates its first operation through this contract, so it exists now; the Safe itself does not.
        expect(record.signerTx).toBeDefined();
        expect(await hasCode(account.passkeySigner)).toBe(true);
        expect(await hasCode(account.address)).toBe(false);
      } else {
        // The Kernel account exists before its first operation, which then carries no initCode.
        expect(record.accountTx).toBeDefined();
        expect(await hasCode(account.address)).toBe(true);
      }
      expect(await pub.readContract({ address: pm, abi: OWNERLESS_PAYMASTER_ABI, functionName: 'remaining', args: [account.address] }))
        .toEqual([10n, parseEther('0.2'), expect.any(BigInt)]);

      // The first operation: recovery setup, then the call; passkey and co-signer sign; the paymaster pays.
      const depositBefore = await pub.readContract({ address: pm, abi: OWNERLESS_PAYMASTER_ABI, functionName: 'getDeposit' });
      await account.executor.execute(NOTHING);
      const first = lastSettlement();
      expect(first.op).toMatchObject({ sender: account.address, paymaster: pm, success: true, nonce: 0n });
      expect(first.sponsored).toMatchObject({ account: account.address });
      expect(depositBefore - await pub.readContract({ address: pm, abi: OWNERLESS_PAYMASTER_ABI, functionName: 'getDeposit' })).toBe(first.op!.actualGasCost);
      expect(await hasCode(account.address)).toBe(true);
      expect(await pub.getBalance({ address: account.address })).toBe(0n);
      expect((await account.queue()).installed).toBe(true);

      // A later operation, sponsored the same way.
      await account.executor.execute(NOTHING);
      expect(lastSettlement().op).toMatchObject({ sender: account.address, paymaster: pm, success: true, nonce: 1n });
    }, 240_000);
  }

  it('a sub-wallet\'s account: its own key\'s 1-of-1 Safe, no enrolment, its first operation (initCode) sponsored; and a sale account like it', async () => {
    const { keys } = createSubWallet();
    const env = { config, chainId: CHAIN_ID, publicClient: pub, bundler: new HandleOps() };
    const executor = await openSoleOwnerSafe(env, keys.account, subWalletSaltNonce(keys.seed));
    expect(executor.kind).toBe('safe');
    expect(executor.address).toBe(subWalletSafe(keys).address);
    expect(await hasCode(executor.address)).toBe(false);
    const enrolmentsBefore = audit.enrolled;

    await executor.execute(NOTHING);
    const first = lastSettlement();
    expect(first.op).toMatchObject({ sender: executor.address, paymaster: pm, success: true, nonce: 0n });
    expect(first.sponsored).toMatchObject({ account: executor.address });
    expect(await hasCode(executor.address)).toBe(true);
    expect(await pub.getBalance({ address: executor.address })).toBe(0n);
    expect(await pub.readContract({ address: executor.address, abi: parseAbi(['function getOwners() view returns (address[])']), functionName: 'getOwners' }))
      .toEqual([keys.account.address]);
    await executor.execute(NOTHING);
    expect(lastSettlement().op).toMatchObject({ sender: executor.address, paymaster: pm, success: true, nonce: 1n });

    // A sale the sub-wallet opens: a fresh key, a random salt, the same sponsorship (the session's `newSaleAccount`).
    const saleKey = privateKeyToAccount(generatePrivateKey());
    const salt = BigInt(toHex(crypto.getRandomValues(new Uint8Array(32))));
    const sale = await openSoleOwnerSafe(env, saleKey, salt);
    expect(sale.address).toBe(soleOwnerSafe(saleKey.address, salt).address);
    await sale.execute(NOTHING);
    expect(lastSettlement().op).toMatchObject({ sender: sale.address, paymaster: pm, success: true, nonce: 0n });

    // Nothing of this touched the co-signer.
    expect(audit.enrolled).toBe(enrolmentsBefore);
  }, 180_000);
});
