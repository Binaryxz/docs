import { describe, expect, it } from 'vitest';
import { bankTxIdHash, normalizeBankTxId } from '../src/bank.js';

/** v2.0 I-21: one bank transaction, one hash, however its id is written. */
describe('bank transaction ids are normalised before they are hashed', () => {
  it('ignores case and whitespace, so one PIX end-to-end id cannot be spent twice under two spellings', () => {
    const e2e = 'E1234567820261027123000abcdefghij';
    expect(normalizeBankTxId(` ${e2e.toLowerCase()}\n`)).toBe(e2e.toUpperCase());
    expect(bankTxIdHash(e2e)).toBe(bankTxIdHash(e2e.toLowerCase()));
    expect(bankTxIdHash('1234 5678 9012')).toBe(bankTxIdHash('123456789012'));
  });

  it('refuses what is not an id rather than hashing it', () => {
    for (const bad of ['', '   ', 'E123/456', 'E123\u00e9456', 'E123"456', 'x'.repeat(65)]) {
      expect(() => normalizeBankTxId(bad)).toThrow(/not a bank transaction id/);
    }
  });
});
