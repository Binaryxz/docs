/**
 * One LP node wired to the in-memory chain, a MockBank on the chain's clock, a memory journal and the
 * provers the contracts allow per rail: bank rails (PIX, boleto) on a zkTLS verifier proven by
 * `ZkTlsProver` over a `LocalWitnessSession` - two local witness keys signing Reclaim claims over
 * MockBank's own records, on the receipt templates the fake verifier allowlists.
 *
 * `restart()` builds a fresh node over the SAME journal, chain and bank - the crash tests use it -
 * and `tick()` runs one tick and returns what the chain received. `witnesses` is read
 * on every proof: splice keys out of it and that rail's proofs stop coming.
 *
 * `gateway: true` makes it a Movva gateway quoting Movva only, on both legs, at par, with
 * `gatewayOptions()` - tests change a policy through `tweak`.
 */
import type { Address, Hex } from 'viem';
import { privateKeyToAccount } from 'viem/accounts';
import {
  RECEIPT_KINDS, Rail, hashProviderParams, receiptRail, receiptRailMask, receiptRequiresOrderTxid, receiptTemplates,
} from '@mova/ramp';
import { MockBank } from '../src/bank.js';
import { NATIVE } from '../src/chain.js';
import type { Logger } from '../src/context.js';
import { MemoryJournal } from '../src/journal.js';
import { LpNode, type LpNodeOptions } from '../src/node.js';
import type { GatewayOptions } from '../src/gateway.js';
import { pixTxidForOrder } from '../src/onramp.js';
import { ParPriceFeed, type PriceFeed } from '../src/price-feed.js';
import type { PricePoint } from '../src/pricing.js';
import type { LpRecord } from '../src/store.js';
import { LocalWitnessSession, ZkTlsProver, type ZkTlsEndpoint } from '../src/zktls.js';
import { FakeChain, MOVVA, OFFRAMP, ONRAMP, REGISTRY, RESERVE, REWARDS, USDT } from './fake-chain.js';

export const E18 = 10n ** 18n;
export const U = 10n ** 6n;
export const MOVVA_LIQUIDITY = 10_000n * E18;

/** A gateway with room to work: caps well above one offer's need, a 1.000 Movva working balance. */
export function gatewayOptions(): GatewayOptions {
  return {
    reserve: RESERVE, usdt: USDT, movva: MOVVA,
    mint: {
      enabled: true, maxSlippageBps: 10, minMintUsdt: 1n * U, maxMintUsdt: 5_000n * U, maxMintUsdtPerDay: 20_000n * U,
      keepUsdt: 0n, maxFeeBps: 50, usdtCostBps: 0,
    },
    redeem: {
      enabled: true, keepMovva: 1_000n * E18, minRedeemMovva: 10n * E18, maxRedeemMovva: 50_000n * E18,
      maxRedeemMovvaPerDay: 200_000n * E18, maxSlippageBps: 10, minCollateralRatioBps: 10_000, maxFeeBps: 50, usdtSaleBps: 30,
    },
    maxRateDeviationBps: 100, maxReferenceAgeSeconds: 300,
  };
}

export const LP_KEY: Hex = '0x59c6995e998f97a5a0044966f0945389dc9e86dae88c7a8412f4603b6b78690d';
export const LP = privateKeyToAccount(LP_KEY).address;
/** A verifier that takes named parties' word (the removed attestor quorum's kind): `provesBankSession()` is false, so no offer or sale may name it. */
export const VERIFIER: Address = '0x000000000000000000000000000000000000a77e';
/** The ReclaimZkTlsVerifier: every PIX and boleto offer, and every sale. */
export const ZKTLS_VERIFIER: Address = '0x0000000000000000000000000000000000002c75';
/** Where the LP's bank serves its receipt pages; the verifier allowlists the templates under it. */
export const BANK_URL_PREFIX = 'https://api.banco-lp.example/';
export const RECEIPT_TEMPLATES = receiptTemplates(BANK_URL_PREFIX);
/** The verifier's allowlist: the PIX pages for PIX, the boleto pages for BOLETO, `pix-received` flagged for the order's txid (M-03). */
export const ZKTLS_ENDPOINTS: ZkTlsEndpoint[] = RECEIPT_KINDS.map((k) => ({
  providerHash: hashProviderParams(RECEIPT_TEMPLATES[k]), urlPrefix: BANK_URL_PREFIX, rails: [receiptRail(k)],
  requiresOrderTxid: receiptRequiresOrderTxid(k),
}));
export const LP_PIX_KEY = 'liquidez@lp.example';
export const WITNESS_KEYS: Hex[] = [
  '0x47e179ec197488593b187f80a00eb0da91f1b9d0b13f8733639f19c30a34926a',
  '0x8b3a350cf5c34c9194ca85829a2df0ec3153be0318b5e2d3348e872092edffba',
];

/** A feed tests can move: by default it tracks the fake oracle's price at chain time. */
export class MovableFeed implements PriceFeed {
  override?: PricePoint | undefined | null;
  constructor(private readonly chain: FakeChain, private readonly asset: Address) {}
  async price(): Promise<PricePoint | undefined> {
    if (this.override === null) return undefined;
    if (this.override) return this.override;
    const cfg = await this.chain.asset('onramp', this.asset);
    const p = await this.chain.oraclePrice(cfg.oracle);
    return { price: p.price, updatedAt: this.chain.time() };
  }
}

/** The txid the node's static BR Code carries for an on-ramp order, as a payer's bank records it (M-03). */
export const orderTxidOf = (h: { chain: FakeChain }, orderId: Hex): string => pixTxidForOrder(h.chain.chainId, ONRAMP, orderId);

/** Register `verifier` on the fake chain as a ReclaimZkTlsVerifier with these witnesses and the harness's endpoints. */
export function allowZkTls(chain: FakeChain, verifier: Address, witnessKeys: readonly Hex[], threshold: number): void {
  chain.zktls.set(verifier.toLowerCase(), {
    witnesses: new Set(witnessKeys.map((k) => privateKeyToAccount(k).address.toLowerCase())),
    threshold,
    endpoints: new Map(RECEIPT_KINDS.map((k) => [
      hashProviderParams(RECEIPT_TEMPLATES[k]).toLowerCase(),
      { urlPrefix: BANK_URL_PREFIX, railMask: receiptRailMask(k), requiresOrderTxid: receiptRequiresOrderTxid(k) },
    ])),
  });
}

export interface Harness {
  chain: FakeChain;
  bank: MockBank;
  journal: MemoryJournal<LpRecord>;
  node: LpNode;
  feeds: { eth: MovableFeed; usdt: MovableFeed; movva: PriceFeed };
  /** The zkTLS witnesses' keys, as the session signs with them. */
  witnesses: Hex[];
  session: LocalWitnessSession;
  logs: string[];
  tick(): Promise<void>;
  restart(): LpNode;
}

export function harness(o: {
  confirmations?: number;
  onramp?: boolean;
  offramp?: boolean;
  logSink?: string[];
  gateway?: boolean;
  /** Claim node-provider rewards from the fake NodeRewards (`chain.rewards`). */
  rewards?: boolean;
  /** Options for the MockBank, e.g. a bank that pays boletos only with a due date. */
  bank?: ConstructorParameters<typeof MockBank>[0];
  /** The chain's genesis timestamp, which is also the node's and the bank's clock: for tests about a date. */
  t0?: bigint;
  tweak?: (opts: LpNodeOptions) => void;
} = {}): Harness {
  const chain = new FakeChain(LP, ZKTLS_VERIFIER, { verifiers: [VERIFIER], t0: o.t0 });
  const witnesses = [...WITNESS_KEYS];
  allowZkTls(chain, ZKTLS_VERIFIER, witnesses, 2);
  chain.mine(1);
  const bank = new MockBank({ now: () => chain.time(), ...o.bank });
  const session = new LocalWitnessSession({ witnessKeys: witnesses, receipts: bank, templates: RECEIPT_TEMPLATES, owner: LP, now: () => chain.time() });
  const journal = new MemoryJournal<LpRecord>();
  const feeds = { eth: new MovableFeed(chain, NATIVE), usdt: new MovableFeed(chain, USDT), movva: new ParPriceFeed(() => chain.time()) };
  const logs = o.logSink ?? [];
  const log: Logger = {
    info: (m) => logs.push(`info ${m}`), warn: (m) => logs.push(`warn ${m}`), error: (m) => logs.push(`error ${m}`),
  };

  const make = (): LpNode => {
    const opts: LpNodeOptions = {
      chain, bank, journal, log,
      provers: [
        new ZkTlsProver(ZKTLS_VERIFIER, session, {
          witnesses: { addresses: WITNESS_KEYS.map((k) => privateKeyToAccount(k).address), threshold: 2 }, endpoints: ZKTLS_ENDPOINTS,
          escrows: { chainId: chain.chainId, onramp: ONRAMP, offramp: OFFRAMP },
        }),
      ],
      confirmations: o.confirmations ?? 3,
      fromBlock: 1n,
      reorgWindow: 12n,
      payerRefSecret: `0x${'ab'.repeat(32)}`,
      lpPayerId: '12345678000195',
      wallClock: () => chain.time(),
      onramp: o.onramp === false ? undefined : {
        escrow: ONRAMP, pixKey: LP_PIX_KEY, receiver: { name: 'LP Liquidez Ltda', city: 'Sao Paulo' },
        reclaimExpired: true, autoRefund: true, boletoDueDays: 3, reorgWindow: 12n, lateCreditGraceSeconds: 3600,
        assets: [
          {
            asset: NATIVE, symbol: 'ETH', liquidity: 5n * 10n ** 18n, minOrder: 10n ** 16n, maxOrder: 2n * 10n ** 18n,
            verifier: ZKTLS_VERIFIER, rails: [Rail.PIX, Rail.BOLETO], refillBelowBps: 5_000, feed: feeds.eth,
            pricing: {
              spreadBps: 100, minSpreadBps: 30, maxOracleDeviationBps: 200, bandMarginBps: 100, refreshDriftBps: 50,
              maxReferenceAgeSeconds: 120, oracleStaleMarginSeconds: 300,
            },
          },
          {
            asset: USDT, symbol: 'USDT', liquidity: 20_000n * 10n ** 6n, minOrder: 10n * 10n ** 6n, maxOrder: 5_000n * 10n ** 6n,
            verifier: ZKTLS_VERIFIER, rails: [Rail.PIX], refillBelowBps: 5_000, feed: feeds.usdt,
            pricing: {
              spreadBps: 80, minSpreadBps: 20, maxOracleDeviationBps: 200, bandMarginBps: 100, refreshDriftBps: 50,
              maxReferenceAgeSeconds: 120, oracleStaleMarginSeconds: 300,
            },
          },
        ],
      },
      offramp: o.offramp === false ? undefined : {
        escrow: OFFRAMP, rails: ['PIX', 'BOLETO'], maxOpenClaims: 3, minTimeToPaySeconds: 20 * 60,
        disputeMarginSeconds: 7 * 60, bankClockSkewSeconds: 0, raiseDisputeWhenUnproven: true, reorgWindow: 12n,
        assets: [
          { asset: NATIVE, symbol: 'ETH', minSaleBrlCents: 100n, maxSaleBrlCents: 10_000_000n, feed: feeds.eth,
            pricing: { minMarginBps: 50, maxOracleDeviationBps: 200, maxReferenceAgeSeconds: 120, oracleStaleMarginSeconds: 300 } },
          { asset: USDT, symbol: 'USDT', minSaleBrlCents: 100n, maxSaleBrlCents: 10_000_000n, feed: feeds.usdt,
            pricing: { minMarginBps: 50, maxOracleDeviationBps: 200, maxReferenceAgeSeconds: 120, oracleStaleMarginSeconds: 300 } },
        ],
      },
    };
    if (o.gateway) {
      opts.gateway = gatewayOptions();
      if (opts.onramp) {
        opts.onramp.assets = [{
          asset: MOVVA, symbol: 'MOVVA', liquidity: MOVVA_LIQUIDITY, minOrder: 10n * E18, maxOrder: 5_000n * E18,
          verifier: ZKTLS_VERIFIER, rails: [Rail.PIX], refillBelowBps: 5_000, feed: feeds.movva,
          pricing: {
            spreadBps: 100, minSpreadBps: 50, maxOracleDeviationBps: 100, bandMarginBps: 100, refreshDriftBps: 50,
            maxReferenceAgeSeconds: 120, oracleStaleMarginSeconds: 300,
          },
        }];
      }
      if (opts.offramp) {
        opts.offramp.assets = [{
          asset: MOVVA, symbol: 'MOVVA', minSaleBrlCents: 100n, maxSaleBrlCents: 10_000_000n, feed: feeds.movva,
          pricing: { minMarginBps: 50, maxOracleDeviationBps: 100, maxReferenceAgeSeconds: 120, oracleStaleMarginSeconds: 300 },
        }];
      }
    }
    if (o.rewards) opts.rewards = { contract: REWARDS, registry: REGISTRY, claim: true, minClaim: 0n, lookbackEpochs: 12 };
    o.tweak?.(opts);
    return new LpNode(opts);
  };

  const h: Harness = {
    chain, bank, journal, feeds, witnesses, session, logs,
    node: make(),
    tick: () => h.node.tick(),
    restart: () => {
      h.node = make();
      return h.node;
    },
  };
  return h;
}
