import { afterEach, beforeAll, describe, expect, it } from 'vitest';
import { execFileSync } from 'node:child_process';
import { mkdtempSync, readFileSync, writeFileSync } from 'node:fs';
import { createServer as createHttpServer, type Server } from 'node:http';
import { createServer as createHttpsServer } from 'node:https';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { assertPayableBoleto, buildBankBoleto, buildCollectionBoleto } from '@mova/ramp';
import type { BankAdapter } from '../../src/bank.js';
import { MemoryJournal } from '../../src/journal.js';
import {
  InterApiError, InterClient, InterSendingAdapter, centsOf, createInterBank, interPixIdempotencyId, interTime, parseInterJson,
  type InterBankOptions, type InterBoletoPayer, type InterIndexRecord,
} from '../../src/banks/inter.js';
import { createBankAdapter, redactingBank } from '../../src/banks/inter-module.js';
import { INTER_SPEC, MockInter, type Recorded } from './inter-mock.js';

/**
 * The Inter adapter against a mock built from Inter's published documents (inter-mock.ts): the
 * BankAdapter rules (idempotency, settlement, the bank's ids and times), OAuth2 and mTLS, the documented
 * limits and errors, paging, and every request checked against the OpenAPI excerpt.
 */

const PAYER: InterBoletoPayer = {
  cpfCnpj: '12345678000195', tipoPessoa: 'JURIDICA', nome: 'LP Liquidez Ltda', endereco: 'Avenida Paulista, 1000',
  cidade: 'Sao Paulo', uf: 'SP', cep: '01310100',
};
/** Node keys are a letter and 32 hex digits of a hash; these vary in the leading digits, as hashes do. */
const KEY = (n: number, letter = 'S') => `${letter}${n.toString(16).padStart(4, '0')}${'a'.repeat(28)}`;
const SELLER = '+5511987654321';

let servers: Server[] = [];
afterEach(async () => {
  for (const s of servers) await new Promise<void>((r) => s.close(() => r()));
  servers = [];
});

async function listen(s: Server): Promise<number> {
  servers.push(s);
  await new Promise<void>((r) => s.listen(0, '127.0.0.1', () => r()));
  const a = s.address();
  return typeof a === 'object' && a ? a.port : 0;
}

class Clock {
  ms = Date.parse('2026-09-14T15:00:00Z');
  readonly slept: number[] = [];
  now = () => this.ms;
  sleep = async (ms: number) => {
    this.slept.push(ms);
    this.ms += ms;
  };
  advance(ms: number) {
    this.ms += ms;
  }
}

async function setup(o: { payer?: boolean; limits?: 'off' | 'production' | 'sandbox'; account?: string; clientOpts?: Partial<ConstructorParameters<typeof InterClient>[0]>; bankOpts?: Partial<InterBankOptions> } = {}) {
  const clock = new Clock();
  const inter = new MockInter(clock.now);
  const port = await listen(createHttpServer((rq, rs) => void inter.handler(rq, rs)));
  const journal = new MemoryJournal<InterIndexRecord>();
  const client = () => new InterClient({
    baseUrl: `http://127.0.0.1:${port}`, clientId: inter.clientId, clientSecret: inter.clientSecret, now: clock.now, sleep: clock.sleep,
    limits: o.limits ?? 'off', account: o.account, ...o.clientOpts,
  });
  const opts = (): InterBankOptions => ({
    client: client(), journal, boletoPayer: o.payer === false ? undefined : PAYER, registrationPollMs: 5, ...o.bankOpts,
  });
  // A "restart" is a new adapter, with a new client, over the same journal.
  return { clock, inter, port, journal, client, sending: () => new InterSendingAdapter(opts()), bank: () => createInterBank(opts()) };
}

const bankBoleto = (cents: bigint, dueDate = '2026-09-19', free = '1234567890123456789012345') =>
  buildBankBoleto({ bankCode: '341', amountCents: cents, dueDate, freeField: free });

describe('Inter transport: OAuth2, limits, errors, money', () => {
  it('asks for one token with the credentials in the form body, and reuses it until a minute before it expires', async () => {
    const { inter, clock, client } = await setup();
    const c = client();
    await c.request('saldo');
    await c.request('saldo');
    expect(inter.tokensIssued).toBe(1);
    const tok = inter.ofOp('token')[0];
    const form = new URLSearchParams(tok.raw);
    expect(tok.headers['content-type']).toBe('application/x-www-form-urlencoded');
    expect(tok.headers.authorization).toBeUndefined();
    expect([form.get('client_id'), form.get('client_secret'), form.get('grant_type')]).toEqual([inter.clientId, inter.clientSecret, 'client_credentials']);
    expect(form.get('scope')!.split(' ')).toEqual(expect.arrayContaining(['pagamento-pix.write', 'pagamento-boleto.read', 'extrato.read', 'pix.read']));
    clock.advance(3540_000 + 1);
    await c.request('saldo');
    expect(inter.tokensIssued).toBe(2);
  });

  it('renews a revoked token once, and refuses a call whose scope the integration lacks before sending it', async () => {
    const { inter, client, sending, journal } = await setup();
    const c = client();
    await c.request('saldo');
    inter.fault('saldo', '401');
    await c.request('saldo');
    expect(inter.tokensIssued).toBe(2);

    inter.integrationScopes = ['extrato.read', 'pagamento-pix.read'];
    const s = sending();
    await expect(s.sendPix({ idempotencyKey: KEY(1), pixKey: SELLER, amountCents: 100n })).rejects.toThrow(/not granted pagamento-pix.write/);
    expect(inter.ofOp('pixPay')).toHaveLength(0);
    expect(journal.load().map((r) => r.t)).toEqual(['intent', 'attempt', 'unsent']);
  });

  it('on 429 waits the Retry-After for a read and for the Pix POST, and never repeats a boleto POST inside the call', async () => {
    const { inter, clock, client, sending } = await setup();
    const c = client();
    inter.fault('saldo', '429', { retryAfter: '2' });
    await c.request('saldo');
    expect(clock.slept).toContain(2000);
    expect(inter.ofOp('saldo')).toHaveLength(2);

    const s = sending();
    inter.fault('pixPay', '429', { retryAfter: '1' });
    expect((await s.sendPix({ idempotencyKey: KEY(2), pixKey: SELLER, amountCents: 500n })).status).toBe('SETTLED');
    expect(inter.pixMoves).toBe(1);

    const line = bankBoleto(38_990n).line;
    inter.fault('boletoPay', '429');
    const err = await s.payBoleto({ idempotencyKey: KEY(3), line, amountCents: 38_990n }).catch((e: unknown) => e);
    expect(err).toBeInstanceOf(InterApiError);
    expect(err).toMatchObject({ status: 429 });
    expect(inter.ofOp('boletoPay')).toHaveLength(1);
    // Nothing reached the bank's application, so the next call is a first attempt, not a repeat to wait on.
    expect((await s.payBoleto({ idempotencyKey: KEY(3), line, amountCents: 38_990n })).status).toBe('SETTLED');
    expect(inter.boletoMoves).toBe(1);
  });

  it('keeps the documented limits itself: one Pix payment a second, and no eleventh balance read in a minute', async () => {
    const { inter, clock, client, sending } = await setup({ limits: 'production' });
    const s = sending();
    await s.sendPix({ idempotencyKey: KEY(4), pixKey: SELLER, amountCents: 100n });
    const before = clock.slept.length;
    await s.sendPix({ idempotencyKey: KEY(5), pixKey: SELLER, amountCents: 100n });
    expect(clock.slept.slice(before).reduce((a, b) => a + b, 0)).toBeGreaterThanOrEqual(1000);

    const c = client();
    for (let i = 0; i < 10; i++) await c.request('saldo');
    const sent = inter.ofOp('saldo').length;
    await expect(c.request('saldo')).rejects.toMatchObject({ status: 429 });
    expect(inter.ofOp('saldo')).toHaveLength(sent);
  });

  it('keeps the status, title and violated property names of a documented error, never the values it echoes', async () => {
    const { client } = await setup();
    const err = await client().request('boletoPay', {
      body: { codBarraLinhaDigitavel: '99887766554433', valorPagar: '10.00', dataVencimento: '2026-09-20' },
    }).catch((e: unknown) => e);
    expect(err).toBeInstanceOf(InterApiError);
    expect(err).toMatchObject({ status: 400, title: 'Dados inválidos.', properties: ['codBarraLinhaDigitavel'] });
    expect((err as Error).message).not.toContain('99887766554433');
    expect((err as Error).message).not.toContain('tamanho');
  });

  it('reads money exactly and times in Brasília when no zone is given', async () => {
    expect(parseInterJson('{"a":0.1,"b":[1234567890.12,-3],"s":"x\\"1.5","t":true}')).toEqual({ a: '0.1', b: ['1234567890.12', '-3'], s: 'x"1.5', t: true });
    expect(centsOf('0.1', 'v')).toBe(10n);
    expect(centsOf('2850.55', 'v')).toBe(285_055n);
    expect(() => centsOf('1.234', 'v')).toThrow();
    expect(() => centsOf('1e3', 'v')).toThrow();
    expect(interTime('2019-10-10 13:00:00')).toBe(BigInt(Date.parse('2019-10-10T16:00:00Z') / 1000));
    expect(interTime('2023-10-23T13:10:47.149543-03:00')).toBe(BigInt(Math.floor(Date.parse('2023-10-23T16:10:47Z') / 1000)));
    expect(interTime('2020-09-10T13:03:33.902Z')).toBe(1_599_743_013n);
    expect(interTime('2019-10-10')).toBeUndefined();

    const { inter, sending } = await setup();
    inter.balanceCents = 123_456_789_012_345n;
    expect(await sending().balanceCents()).toBe(123_456_789_012_345n);
  });
});

describe('Inter sendPix: the idempotency header, and settlement read back', () => {
  it('is SETTLED only once Inter reports PAGO with the end-to-end id; the POST answer is only acceptance', async () => {
    const { inter, clock, sending } = await setup();
    inter.pixSettle = 'manual';
    const s = sending();
    const key = KEY(10);
    const first = await s.sendPix({ idempotencyKey: key, pixKey: SELLER, amountCents: 198_000n, description: 'Mova' });
    expect(first).toMatchObject({ status: 'PENDING', amountCents: 198_000n, creditedKey: SELLER });
    expect(first.bankTxId).toBeUndefined();
    const post = inter.ofOp('pixPay')[0];
    expect(post.raw).toContain('"valor":1980.00');
    expect(post.body).toEqual({ valor: 1980, descricao: 'Mova', destinatario: { tipo: 'CHAVE', chave: SELLER } });
    expect(post.headers['x-id-idempotente']).toBe(interPixIdempotencyId(key));
    expect(interPixIdempotencyId(key)).toMatch(/^[0-9a-f]{8}-[0-9a-f]{4}-5[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/);

    clock.advance(4000);
    inter.settlePix();
    const settled = await s.getOutgoing(key);
    expect(settled).toMatchObject({ status: 'SETTLED', amountCents: 198_000n, creditedKey: SELLER, paidAt: BigInt(Math.floor(clock.ms / 1000)) });
    expect(settled!.bankTxId).toMatch(/^E00416968\w{23}$/);
  });

  it('waits for a manual approval as PENDING, and a rejection is FAILED for good', async () => {
    const { inter, sending } = await setup();
    inter.approvals = true;
    const s = sending();
    const key = KEY(11);
    expect((await s.sendPix({ idempotencyKey: key, pixKey: SELLER, amountCents: 1_000n })).status).toBe('PENDING');
    inter.rejectPix([...inter.pix.keys()][0]);
    expect(await s.getOutgoing(key)).toMatchObject({ status: 'FAILED', failureReason: 'Inter REPROVADO' });
    inter.settlePix();
    expect((await sending().getOutgoing(key))!.status).toBe('FAILED');
    expect(inter.pixMoves).toBe(0);
  });

  it('moves money once for a key: a repeat answers the first result without a second POST', async () => {
    const { inter, sending } = await setup();
    const s = sending();
    const a = await s.sendPix({ idempotencyKey: KEY(12), pixKey: SELLER, amountCents: 2_500n });
    const b = await sending().sendPix({ idempotencyKey: KEY(12), pixKey: SELLER, amountCents: 2_500n });
    expect(b).toEqual(a);
    expect(inter.ofOp('pixPay')).toHaveLength(1);
    expect(inter.pixMoves).toBe(1);
    await expect(s.sendPix({ idempotencyKey: KEY(12), pixKey: SELLER, amountCents: 2_501n })).rejects.toThrow(/different payment/);
  });

  it('a lost response: getOutgoing does not know the key, and the repeat carries the same header, which Inter absorbs', async () => {
    const { inter, sending } = await setup();
    const key = KEY(13);
    inter.fault('pixPay', 'lose');
    await expect(sending().sendPix({ idempotencyKey: key, pixKey: SELLER, amountCents: 7_700n })).rejects.toThrow();
    expect(inter.pixMoves).toBe(1);
    const restarted = sending();
    expect(await restarted.getOutgoing(key)).toBeUndefined();
    expect((await restarted.sendPix({ idempotencyKey: key, pixKey: SELLER, amountCents: 7_700n })).status).toBe('SETTLED');
    expect(inter.pixMoves).toBe(1);
    const posts = inter.ofOp('pixPay');
    expect(posts).toHaveLength(2);
    expect(posts[1].headers['x-id-idempotente']).toBe(posts[0].headers['x-id-idempotente']);
    expect((await sending().getOutgoing(key))!.status).toBe('SETTLED');
  });

  it('a refusal of a first attempt is FAILED; the same refusal of a repeat is thrown, since the first may have paid', async () => {
    const { inter, sending } = await setup();
    inter.unknownKeys.add('nobody@pix.example');
    expect(await sending().sendPix({ idempotencyKey: KEY(14), pixKey: 'nobody@pix.example', amountCents: 100n }))
      .toMatchObject({ status: 'FAILED', failureReason: expect.stringMatching(/refused by Inter: Inter 422/) });

    inter.fault('pixPay', '500');
    const s = sending();
    await expect(s.sendPix({ idempotencyKey: KEY(15), pixKey: 'other@pix.example', amountCents: 100n })).rejects.toThrow(/Inter 500/);
    inter.unknownKeys.add('other@pix.example');
    await expect(s.sendPix({ idempotencyKey: KEY(15), pixKey: 'other@pix.example', amountCents: 100n })).rejects.toThrow(/Inter 422/);
    expect(await s.getOutgoing(KEY(15))).toBeUndefined();
  });
});

describe('Inter payBoleto: a look-up by barcode before paying', () => {
  it('looks the barcode up, pays once, and SETTLES on REALIZADO with the authentication code and time', async () => {
    const { inter, clock, sending } = await setup();
    const s = sending();
    const bill = bankBoleto(38_990n);
    const key = KEY(20);
    const r = await s.payBoleto({ idempotencyKey: key, line: bill.line, amountCents: 38_990n });
    expect(r).toMatchObject({ status: 'SETTLED', amountCents: 38_990n, paidAt: BigInt(Math.floor(clock.ms / 1000)) });
    expect(r.bankTxId).toMatch(/^3140899\d{23}$/);
    expect(inter.requests.filter((x) => x.op !== 'token').map((x) => x.op)).toEqual(['boletoPayList', 'boletoPay', 'boletoPayList']);
    const lookup = inter.ofOp('boletoPayList')[0].query;
    expect([lookup.get('codBarraLinhaDigitavel'), lookup.get('filtrarDataPor'), lookup.get('dataFim')]).toEqual([bill.barcode, 'INCLUSAO', '2026-09-14']);
    expect(inter.ofOp('boletoPay')[0].body).toEqual({ codBarraLinhaDigitavel: bill.barcode, valorPagar: '389.90', dataVencimento: '2026-09-19' });
    expect(await sending().payBoleto({ idempotencyKey: key, line: bill.line, amountCents: 38_990n })).toEqual(r);
    expect(inter.ofOp('boletoPay')).toHaveLength(1);
  });

  it('a lost response: does not repeat while the payment may be invisible, then finds it by barcode and never pays twice', async () => {
    const { inter, clock, sending } = await setup();
    inter.paymentListLagMs = 60_000;
    const bill = bankBoleto(12_345n);
    const key = KEY(21);
    inter.fault('boletoPay', 'lose');
    await expect(sending().payBoleto({ idempotencyKey: key, line: bill.line, amountCents: 12_345n })).rejects.toThrow();
    expect(inter.boletoMoves).toBe(1);
    const restarted = sending();
    expect(await restarted.getOutgoing(key)).toBeUndefined();
    await expect(restarted.payBoleto({ idempotencyKey: key, line: bill.line, amountCents: 12_345n })).rejects.toThrow(/not yet visible/);
    clock.advance(11 * 60_000);
    expect((await restarted.payBoleto({ idempotencyKey: key, line: bill.line, amountCents: 12_345n })).status).toBe('SETTLED');
    expect(inter.ofOp('boletoPay')).toHaveLength(1);
    expect(inter.boletoMoves).toBe(1);
  });

  it('refuses before calling Inter a different amount or a collection line without a due date; a first 406 is FAILED', async () => {
    const { inter, sending } = await setup();
    const s = sending();
    const bill = bankBoleto(50_000n);
    expect(await s.payBoleto({ idempotencyKey: KEY(22), line: bill.line, amountCents: 50_001n })).toMatchObject({ status: 'FAILED', failureReason: 'amount differs from the boleto' });
    const utility = buildCollectionBoleto({ segment: 3, valueIdentifier: 8, value: 38_990n, rest: '00562026092400000000987654321' });
    expect(await s.payBoleto({ idempotencyKey: KEY(23), line: utility.line, amountCents: 38_990n })).toMatchObject({ status: 'FAILED', failureReason: expect.stringMatching(/dataVencimento/) });
    expect(inter.ofOp('boletoPay')).toHaveLength(0);

    // Someone paid this bill moments ago, not yet listed: Inter refuses it as already settled.
    inter.paymentListLagMs = 60_000;
    await s.payBoleto({ idempotencyKey: KEY(24), line: bill.line, amountCents: 50_000n });
    expect(await s.payBoleto({ idempotencyKey: KEY(25), line: bill.line, amountCents: 50_000n })).toMatchObject({ status: 'FAILED', failureReason: expect.stringMatching(/406/) });
    expect(inter.boletoMoves).toBe(1);
  });

  it('a payment waiting for approval is PENDING until approved', async () => {
    const { inter, sending } = await setup();
    inter.approvals = true;
    const s = sending();
    const bill = bankBoleto(9_900n);
    expect((await s.payBoleto({ idempotencyKey: KEY(26), line: bill.line, amountCents: 9_900n })).status).toBe('PENDING');
    inter.approveBoletos();
    expect((await s.getOutgoing(KEY(26)))!.status).toBe('SETTLED');
  });
});

describe('Inter boleto registration, cancellation and credits', () => {
  it('registers a charge for exactly the order, waits out EM_PROCESSAMENTO, and returns a payable line', async () => {
    const { inter, clock, sending } = await setup();
    inter.emissionGets = 2;
    const key = KEY(30, 'B');
    const reg = await sending().registerBoleto({ idempotencyKey: key, amountCents: 150_000n, dueDate: '2026-09-17', reference: '0x01' });
    expect(reg.bankRef).toBe([...inter.cobrancas.keys()][0]);
    expect(() => assertPayableBoleto(reg.line, 150_000n, { now: new Date(clock.ms) })).not.toThrow();
    const create = inter.ofOp('cobrancaCreate')[0];
    expect(create.raw).toContain('"valorNominal":1500.00');
    expect(create.body).toEqual({
      seuNumero: key.slice(0, 15), valorNominal: 1500, dataVencimento: '2026-09-17', numDiasAgenda: 0, pagador: PAYER, formasRecebimento: ['BOLETO'],
    });
    const lookup = inter.ofOp('cobrancaList')[0].query;
    expect([lookup.get('seuNumero'), lookup.get('dataInicial'), lookup.get('dataFinal'), lookup.get('filtrarDataPor')]).toEqual([key.slice(0, 15), '2026-09-17', '2026-09-17', 'VENCIMENTO']);
    expect(inter.ofOp('cobrancaGet').length).toBeGreaterThanOrEqual(2);
    await expect(sending().registerBoleto({ idempotencyKey: KEY(31, 'B'), amountCents: 249n, dueDate: '2026-09-17', reference: '0x02' })).rejects.toThrow(/R\$ 2,50/);
  });

  it('survives a lost response by finding the charge by seuNumero, across pages, instead of issuing a second', async () => {
    const { inter, sending } = await setup({ bankOpts: { listPageSize: 2 } });
    // Keys that share their first 15 characters share a seuNumero: the look-up must page past the other amounts.
    const sharing = (tail: string) => `B0049aaaaaaaaaa${tail.repeat(18)}`;
    for (let i = 1; i <= 4; i++) await sending().registerBoleto({ idempotencyKey: sharing(String(i)), amountCents: 10_000n + BigInt(i), dueDate: '2026-09-17', reference: '0x' });
    const key = sharing('f');
    inter.fault('cobrancaCreate', 'lose');
    await expect(sending().registerBoleto({ idempotencyKey: key, amountCents: 10_000n, dueDate: '2026-09-17', reference: '0x' })).rejects.toThrow();
    const reg = await sending().registerBoleto({ idempotencyKey: key, amountCents: 10_000n, dueDate: '2026-09-17', reference: '0x' });
    expect(inter.cobrancas.size).toBe(5);
    expect(inter.ofOp('cobrancaCreate')).toHaveLength(5);
    expect(inter.cobrancas.get(reg.bankRef)!.seuNumero).toBe(key.slice(0, 15));
    const pages = inter.ofOp('cobrancaList').slice(-3).map((r) => r.query.get('paginacao.paginaAtual'));
    expect(pages).toEqual(['0', '1', '2']);
  });

  it('cancels an open charge once, and leaves a cancelled, paid or unknown one alone', async () => {
    const { inter, sending } = await setup();
    const s = sending();
    const open = await s.registerBoleto({ idempotencyKey: KEY(50, 'B'), amountCents: 10_000n, dueDate: '2026-09-17', reference: '0x' });
    await s.cancelBoleto(open.bankRef);
    await s.cancelBoleto(open.bankRef);
    expect(inter.ofOp('cobrancaCancel')).toHaveLength(1);
    expect((inter.ofOp('cobrancaCancel')[0].body as { motivoCancelamento: string }).motivoCancelamento.length).toBeLessThanOrEqual(50);
    expect(inter.cobrancas.get(open.bankRef)!.situacao).toBe('CANCELADO');
    const paid = await s.registerBoleto({ idempotencyKey: KEY(51, 'B'), amountCents: 10_000n, dueDate: '2026-09-17', reference: '0x' });
    inter.payCobranca(paid.bankRef);
    await s.cancelBoleto(paid.bankRef);
    await s.cancelBoleto('00000000-0000-4000-8000-000000000000');
    expect(inter.ofOp('cobrancaCancel')).toHaveLength(1);
  });

  it('lists a paid boleto as a BOLETO credit with its Brasília time, beside API Pix credits, reading the statement at most once a minute', async () => {
    const { inter, clock, bank } = await setup({ bankOpts: { listPageSize: 2, pixPageSize: 1 } });
    const b = bank();
    const regs = [];
    for (let i = 0; i < 3; i++) regs.push(await b.registerBoleto!({ idempotencyKey: KEY(60 + i, 'B'), amountCents: 20_000n + BigInt(i), dueDate: '2026-09-17', reference: '0x' }));
    clock.advance(3600_000);
    for (const r of regs) inter.payCobranca(r.bankRef);
    inter.received.push({ endToEndId: 'E12345678202609141200abcdefghijk', txid: 'movaorder1', valor: '10.50', chave: 'liquidez@lp.example', horario: new Date(clock.ms).toISOString() });
    inter.received.push({ endToEndId: 'E12345678202609141200abcdefghijl', valor: '1.00', horario: new Date(clock.ms).toISOString() });
    const since = BigInt(Math.floor(clock.ms / 1000)) - 7200n;
    const credits = await b.listIncoming({ since });
    const boletos = credits.filter((c) => c.rail === 'BOLETO');
    expect(boletos).toHaveLength(3);
    const c0 = inter.cobrancas.get(regs[0].bankRef)!;
    expect(boletos[0]).toEqual({ rail: 'BOLETO', bankTxId: c0.nossoNumero, amountCents: 20_000n, paidAt: BigInt(Math.floor(clock.ms / 1000)), boletoLine: c0.barcode });
    expect(credits.filter((c) => c.rail === 'PIX').map((c) => c.bankTxId)).toEqual(['E12345678202609141200abcdefghijk', 'E12345678202609141200abcdefghijl']);
    expect(inter.ofOp('extrato').map((r) => r.query.get('pagina'))).toEqual(['0', '1']);
    expect(inter.ofOp('pixList').map((r) => r.query.get('paginacao.paginaAtual'))).toEqual(['0', '1']);
    await b.listIncoming({ since });
    expect(inter.ofOp('extrato')).toHaveLength(2);
    clock.advance(61_000);
    await b.listIncoming({ since });
    expect(inter.ofOp('extrato')).toHaveLength(4);
  });

  it('without a configured payer, the adapter offers no boleto registration', async () => {
    const { bank } = await setup({ payer: false });
    const b = bank();
    expect(b.registerBoleto).toBeUndefined();
    expect(b.cancelBoleto).toBeUndefined();
  });
});

/*//////////////////////////////////////////////////////////////
                  EVERY REQUEST, AGAINST THE DOCUMENTS
//////////////////////////////////////////////////////////////*/

type Schema = { type?: string; format?: string; pattern?: string; minLength?: number; maxLength?: number; minimum?: number; maximum?: number; enum?: unknown[];
  required?: string[]; properties?: Record<string, Schema>; items?: Schema; oneOf?: Schema[]; anyOf?: Schema[]; allOf?: Schema[] };

/** The subset of JSON Schema the excerpt uses. Returns the violations, by path. */
function violations(s: Schema, v: unknown, at = '$'): string[] {
  const out: string[] = [];
  if (s.allOf) for (const sub of s.allOf) out.push(...violations(sub, v, at));
  if (s.oneOf && !s.oneOf.some((sub) => violations(sub, v, at).length === 0)) out.push(`${at}: matches no alternative`);
  if (s.anyOf && !s.anyOf.some((sub) => violations(sub, v, at).length === 0)) out.push(`${at}: matches no alternative`);
  if (v === undefined) return out;
  const type = Array.isArray(v) ? 'array' : v === null ? 'null' : typeof v;
  if (s.type === 'integer' ? !Number.isInteger(v) : s.type && s.type !== type) out.push(`${at}: ${type} is not ${s.type}`);
  if (s.enum && !s.enum.includes(v)) out.push(`${at}: not in enum`);
  if (typeof v === 'string') {
    if (s.pattern && !new RegExp(s.pattern.replace(/\\\\/g, '\\')).test(v)) out.push(`${at}: pattern`);
    if (s.minLength !== undefined && v.length < s.minLength) out.push(`${at}: minLength`);
    if (s.maxLength !== undefined && v.length > s.maxLength) out.push(`${at}: maxLength`);
    if (s.format === 'date' && !/^\d{4}-\d{2}-\d{2}$/.test(v)) out.push(`${at}: date`);
  }
  if (typeof v === 'number') {
    if (s.minimum !== undefined && v < s.minimum) out.push(`${at}: minimum`);
    if (s.maximum !== undefined && v > s.maximum) out.push(`${at}: maximum`);
  }
  if (type === 'object') {
    const o = v as Record<string, unknown>;
    for (const r of s.required ?? []) if (o[r] === undefined) out.push(`${at}.${r}: required`);
    for (const [k, sub] of Object.entries(s.properties ?? {})) out.push(...violations(sub, o[k], `${at}.${k}`));
  }
  if (Array.isArray(v) && s.items) v.forEach((x, i) => out.push(...violations(s.items!, x, `${at}[${i}]`)));
  return out;
}

function checkRequest(r: Recorded): string[] {
  const d = INTER_SPEC.operations[r.op];
  if (!d) return [`${r.method} ${r.path}: not a documented operation`];
  const out: string[] = [];
  if (d.method !== r.method) out.push(`${r.op}: method ${r.method}`);
  const headerOf = (n: string) => r.headers[n.toLowerCase()];
  for (const p of d.parameters) {
    const value = p.in === 'query' ? r.query.get(p.name) ?? undefined : p.in === 'header' ? headerOf(p.name) : p.in === 'path' ? 'present' : undefined;
    if (p.required && value === undefined) out.push(`${r.op}: ${p.in} ${p.name} required`);
    if (value !== undefined && p.in !== 'path') {
      const typed = p.schema.type === 'integer' ? Number(value) : value;
      out.push(...violations(p.schema as Schema, typed, `${r.op} ${p.name}`));
    }
  }
  const known = new Set(d.parameters.filter((p) => p.in === 'query').map((p) => p.name));
  for (const k of r.query.keys()) if (!known.has(k)) out.push(`${r.op}: undocumented query ${k}`);
  if (r.op !== 'token' && !/^Bearer \S+$/.test(r.headers.authorization ?? '')) out.push(`${r.op}: no bearer token`);
  if (d.requestBody) {
    if (r.headers['content-type'] !== d.requestBody.contentType) out.push(`${r.op}: content-type ${r.headers['content-type']}`);
    const body = d.requestBody.contentType.includes('form') ? Object.fromEntries(new URLSearchParams(r.raw)) : r.body;
    if (d.requestBody.required && body === undefined) out.push(`${r.op}: body required`);
    out.push(...violations(d.requestBody.schema as Schema, body, r.op));
  } else if (r.raw) {
    out.push(`${r.op}: a body where none is documented`);
  }
  return out;
}

describe('Inter API Pix charges (cob), for onramp.pixCharge: "cob"', () => {
  const KEY_LP = 'liquidez@lp.example';

  it('creates one charge per txid across a restart, reads it back, removes an unpaid one and leaves a paid one CONCLUIDA', async () => {
    const { inter, clock, bank } = await setup();
    const txid = `Q${'0123456789abcdef'.repeat(2)}`;
    const created = await bank().createCharge!({ txid, amountCents: 40_481n, pixKey: KEY_LP, expiresInSeconds: 1_500 });
    expect(created).toMatchObject({ txid, status: 'ATIVA', amountCents: 40_481n, amountFixed: true, pixKey: KEY_LP, expiresInSeconds: 1_500 });
    // A restarted node repeats the PUT for the same txid: still one charge.
    await bank().createCharge!({ txid, amountCents: 40_481n, pixKey: KEY_LP, expiresInSeconds: 1_500 });
    expect(inter.charges.size).toBe(1);
    expect(inter.ofOp('cobPut').map((r) => r.path)).toEqual([`/pix/v2/cob/${txid}`, `/pix/v2/cob/${txid}`]);
    expect(await bank().getCharge!(`Q${'9'.repeat(32)}`)).toBeUndefined();
    expect(await bank().cancelCharge!(txid)).toBe('REMOVIDA_PELO_USUARIO_RECEBEDOR');

    const paid = `Q${'fedcba9876543210'.repeat(2)}`;
    await bank().createCharge!({ txid: paid, amountCents: 1_000n, pixKey: KEY_LP, expiresInSeconds: 1_500 });
    inter.payCob(paid);
    expect(await bank().cancelCharge!(paid)).toBe('CONCLUIDA');
    expect(inter.ofOp('cobPatch')).toHaveLength(1); // the paid charge was read, never revised
    // And the paid charge is what Inter's GET /pix lists: the credit carries the charge's txid.
    const credits = await bank().listIncoming({ since: BigInt(Math.floor(clock.ms / 1000)) - 60n });
    expect(credits.find((c) => c.txid === paid)).toMatchObject({ rail: 'PIX', amountCents: 1_000n });
  });

  it('refuses a charge call the integration was not granted cob.write for, before sending it', async () => {
    const { inter, bank } = await setup();
    inter.integrationScopes = ['pagamento-pix.write', 'pagamento-pix.read', 'pagamento-boleto.write', 'pagamento-boleto.read', 'extrato.read', 'pix.read', 'pix.write', 'cob.read'];
    await expect(bank().createCharge!({ txid: `Q${'1'.repeat(32)}`, amountCents: 100n, pixKey: KEY_LP, expiresInSeconds: 600 })).rejects.toThrow();
    expect(inter.ofOp('cobPut')).toHaveLength(0);
  });
});

describe('Inter requests match the published OpenAPI documents', () => {
  it(`sends every operation as documented (excerpt read ${INTER_SPEC.retrieved})`, async () => {
    const { inter, clock, bank } = await setup({ account: '12345678', bankOpts: { pixPageSize: 5 } });
    const b = bank();
    inter.pixSettle = 'manual';
    await b.sendPix({ idempotencyKey: KEY(70), pixKey: SELLER, amountCents: 198_000n, description: 'Mova' });
    inter.settlePix();
    await b.getOutgoing(KEY(70));
    await b.payBoleto({ idempotencyKey: KEY(71), line: bankBoleto(38_990n).line, amountCents: 38_990n });
    await b.balanceCents!();
    const reg = await b.registerBoleto!({ idempotencyKey: KEY(72, 'B'), amountCents: 150_000n, dueDate: '2026-09-17', reference: '0x' });
    const other = await b.registerBoleto!({ idempotencyKey: KEY(73, 'B'), amountCents: 150_001n, dueDate: '2026-09-17', reference: '0x' });
    await b.cancelBoleto!(reg.bankRef);
    inter.payCobranca(other.bankRef);
    const e2e = 'E12345678202609141200abcdefghijk';
    inter.received.push({ endToEndId: e2e, txid: 'movaorder1', valor: '10.50', chave: 'liquidez@lp.example', horario: new Date(clock.ms).toISOString() });
    await b.listIncoming({ since: BigInt(Math.floor(clock.ms / 1000)) - 3600n });
    await b.getIncoming!(e2e);
    await b.refundIncoming!({ idempotencyKey: 'R0123456789abcdef', bankTxId: e2e, amountCents: 1_050n, reason: 'Mova on-ramp order did not settle' });
    const txid = `Q${'ab12'.repeat(8)}`;
    await b.createCharge!({ txid, amountCents: 40_481n, pixKey: 'liquidez@lp.example', expiresInSeconds: 1_500 });
    await b.cancelCharge!(txid);

    const problems = inter.requests.flatMap(checkRequest);
    expect(problems).toEqual([]);
    expect(new Set(inter.requests.map((r) => r.op))).toEqual(new Set(Object.keys(INTER_SPEC.operations)));
    expect(inter.requests.filter((r) => r.op !== 'token').every((r) => r.headers['x-conta-corrente'] === '12345678')).toBe(true);
  });

  it('the checker itself catches a request that breaks the documents', () => {
    const bad: Recorded = {
      op: 'pixPay', method: 'POST', path: '/banking/v2/pix', query: new URLSearchParams('extra=1'), raw: '{}',
      headers: { authorization: 'Bearer t', 'content-type': 'application/json', 'x-id-idempotente': 'not-a-uuid' },
      body: { valor: '12.00', destinatario: { tipo: 'CHAVE' }, descricao: 'x'.repeat(141) },
    };
    const found = checkRequest(bad).join('\n');
    for (const want of ['x-id-idempotente', 'undocumented query extra', '$.valor', 'maxLength', 'no alternative']) expect(found).toContain(want.replace('$', 'pixPay'));
  });
});

/*//////////////////////////////////////////////////////////////
                         THE MODULE
//////////////////////////////////////////////////////////////*/

describe('Inter BANK_MODULE', () => {
  const dir = mkdtempSync(join(tmpdir(), 'inter-module-'));
  const f = (name: string, content: string) => {
    const p = join(dir, name);
    writeFileSync(p, content);
    return p;
  };
  const PEM = '-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC7\n-----END PRIVATE KEY-----\n';

  it('reads secrets only from files, refuses them in the environment, and names problems without their values', () => {
    const env = {
      INTER_API_URL: 'http://inter.example', INTER_CLIENT_ID: 'id', INTER_CLIENT_SECRET: 'direct-secret-value-123',
      INTER_CERT_FILE: '/nonexistent/cert', INTER_ACCOUNT: '0123',
    };
    const err = (() => {
      try {
        createBankAdapter(env);
      } catch (e) {
        return e as Error & { problems: string[] };
      }
      throw new Error('accepted');
    })();
    const text = err.problems.join('\n');
    for (const want of ['INTER_CLIENT_SECRET must be read from INTER_CLIENT_SECRET_FILE', 'INTER_API_URL must be https', 'INTER_CLIENT_SECRET_FILE is required',
      'INTER_CERT_FILE could not be read', 'INTER_CERT_KEY_FILE is required', 'INTER_STATE_PATH is required', 'INTER_ACCOUNT must be']) expect(text).toContain(want);
    expect(err.message).not.toContain('direct-secret-value-123');
    expect(err.message).not.toContain('/nonexistent/cert');
  });

  /// M-13: the adapter's record lost while the node's journal survives - a repeated Pix would rest on x-id-idempotente,
  /// which Inter does not document. Refused until restored, or reconciled by hand and acknowledged.
  it('refuses to start when its record of what it sent is gone but the node\'s journal is not', () => {
    const base = {
      INTER_API_URL: 'https://inter.example', INTER_CLIENT_ID: 'id', INTER_CLIENT_SECRET_FILE: f('secret2', 'a-client-secret-of-the-integration\n'),
      INTER_CERT_FILE: f('cert2.pem', 'cert'), INTER_CERT_KEY_FILE: f('key2.pem', PEM), INTER_STATE_PATH: join(dir, 'lost.jsonl'),
      STATE_FILE: f('node.jsonl', '{"t":"payout.intent"}\n'),
    };
    const problems = (env: Record<string, string>) => {
      try {
        createBankAdapter(env);
        return '';
      } catch (e) {
        return ((e as { problems?: string[] }).problems ?? []).join('\n');
      }
    };
    expect(problems(base)).toMatch(/INTER_STATE_RECONCILED=1/);
    expect(problems({ ...base, INTER_STATE_RECONCILED: '1' })).toBe('');
    expect(problems({ ...base, STATE_FILE: join(dir, 'no-node-journal-yet.jsonl') })).toBe('');
  });

  it('builds a working adapter from files, and its errors never carry the secret, the key or a token', async () => {
    const clock = new Clock();
    const inter = new MockInter(clock.now);
    const port = await listen(createHttpServer((rq, rs) => void inter.handler(rq, rs)));
    const bank = createBankAdapter({
      INTER_API_URL: `http://127.0.0.1:${port}`, INTER_CLIENT_ID: inter.clientId, INTER_CLIENT_SECRET_FILE: f('secret', `${inter.clientSecret}\n`),
      INTER_CERT_FILE: f('cert.pem', 'not used over http'), INTER_CERT_KEY_FILE: f('key.pem', PEM), INTER_STATE_PATH: join(dir, 'state.jsonl'),
      INTER_BOLETO_PAYER_FILE: f('payer.json', JSON.stringify(PAYER)),
    });
    expect((await bank.sendPix({ idempotencyKey: KEY(80), pixKey: SELLER, amountCents: 1n })).status).toBe('SETTLED');
    expect(readFileSync(join(dir, 'state.jsonl'), 'utf8')).toContain(KEY(80));
    expect(bank.registerBoleto).toBeDefined();

    const token = 'inter-token-1-xxxxxxxxxxxxxxxxxxxxxxxx';
    const leaky: BankAdapter = {
      listIncoming: async () => { throw Object.assign(new Error(`boom ${inter.clientSecret} ${token} MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC7`), { status: 503 }); },
      sendPix: async () => ({ idempotencyKey: 'k', status: 'PENDING' }), payBoleto: async () => ({ idempotencyKey: 'k', status: 'PENDING' }),
      getOutgoing: async () => undefined,
    };
    const err = (await redactingBank(leaky, () => [inter.clientSecret, token, PEM, 'MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC7']).listIncoming({ since: 0n })
      .catch((e: unknown) => e)) as Error & { status?: number };
    expect(err.message).not.toContain(inter.clientSecret);
    expect(err.message).not.toContain(token);
    expect(err.message).not.toContain('MIIEvQ');
    expect(err.status).toBe(503);
  });
});

/*//////////////////////////////////////////////////////////////
                              mTLS
//////////////////////////////////////////////////////////////*/

const hasOpenssl = (() => {
  try { execFileSync('openssl', ['version'], { stdio: 'ignore' }); return true; } catch { return false; }
})();

describe.skipIf(!hasOpenssl)('Inter over mTLS', () => {
  let pki: Record<'ca' | 'serverCert' | 'serverKey' | 'clientCert' | 'clientKey' | 'strangerCert' | 'strangerKey', Buffer>;

  beforeAll(() => {
    const d = mkdtempSync(join(tmpdir(), 'inter-pki-'));
    const ossl = (...args: string[]) => execFileSync('openssl', args, { cwd: d, stdio: 'ignore' });
    ossl('req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-keyout', 'ca.key', '-out', 'ca.pem', '-days', '2', '-subj', '/CN=Test Inter CA');
    const leaf = (name: string, ext: string, ca = 'ca') => {
      ossl('req', '-newkey', 'rsa:2048', '-nodes', '-keyout', `${name}.key`, '-out', `${name}.csr`, '-subj', `/CN=${name}`);
      writeFileSync(join(d, `${name}.ext`), ext);
      ossl('x509', '-req', '-in', `${name}.csr`, '-CA', `${ca}.pem`, '-CAkey', `${ca}.key`, '-CAcreateserial', '-out', `${name}.pem`, '-days', '2', '-extfile', `${name}.ext`);
    };
    leaf('server', 'subjectAltName=IP:127.0.0.1');
    leaf('client', 'extendedKeyUsage=clientAuth');
    ossl('req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-keyout', 'rogue.key', '-out', 'rogue.pem', '-days', '2', '-subj', '/CN=Rogue CA');
    leaf('stranger', 'extendedKeyUsage=clientAuth', 'rogue');
    const r = (n: string) => readFileSync(join(d, n));
    pki = {
      ca: r('ca.pem'), serverCert: r('server.pem'), serverKey: r('server.key'), clientCert: r('client.pem'), clientKey: r('client.key'),
      strangerCert: r('stranger.pem'), strangerKey: r('stranger.key'),
    };
  });

  it('authenticates the token request and every call with the integration certificate, and gets nowhere without it', async () => {
    const inter = new MockInter();
    const port = await listen(createHttpsServer({ key: pki.serverKey, cert: pki.serverCert, ca: pki.ca, requestCert: true, rejectUnauthorized: true },
      (rq, rs) => void inter.handler(rq, rs)));
    const make = (tls: { cert?: Buffer; key?: Buffer; ca: Buffer }) => new InterSendingAdapter({
      client: new InterClient({ baseUrl: `https://127.0.0.1:${port}`, clientId: inter.clientId, clientSecret: inter.clientSecret, tls: tls as never, limits: 'off' }),
      journal: new MemoryJournal<InterIndexRecord>(),
    });
    const good = make({ cert: pki.clientCert, key: pki.clientKey, ca: pki.ca });
    expect((await good.sendPix({ idempotencyKey: KEY(90), pixKey: SELLER, amountCents: 1n })).status).toBe('SETTLED');
    expect(inter.requests.map((r) => [r.op, r.clientCert])).toEqual([['token', true], ['pixPay', true], ['pixPayGet', true]]);
    const refused = /certificate|alert|ECONNRESET|socket hang up/i;
    await expect(make({ ca: pki.ca }).balanceCents()).rejects.toThrow(refused);
    await expect(make({ cert: pki.strangerCert, key: pki.strangerKey, ca: pki.ca }).balanceCents()).rejects.toThrow(refused);
    expect(inter.pixMoves).toBe(1);
  });
});
