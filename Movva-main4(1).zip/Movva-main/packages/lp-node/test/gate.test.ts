import { afterEach, describe, expect, it } from 'vitest';
import { generatePrivateKey, privateKeyToAccount } from 'viem/accounts';
import { verifyTypedData, type Hex } from 'viem';
import { OrderState } from '../src/abi.js';
import { NATIVE } from '../src/chain.js';
import { GATE_REQUEST_TYPES } from '../src/gate.js';
import { instructionsDomain, serveLpNode } from '../src/server.js';
import { ONRAMP } from './fake-chain.js';
import { harness, type Harness } from './harness.js';

/** v2.0 H-04: this node gates its offers and approves locks, one at a time, within its limits. */
const closers: (() => Promise<void>)[] = [];
afterEach(async () => { while (closers.length) await closers.pop()!(); });

const GATE_KEY = generatePrivateKey();

function gated(o: { maxOpenPerTaker?: number; perTakerPerHour?: number } = {}) {
  return harness({ offramp: false, tweak: (opts) => { opts.takerGate = { key: GATE_KEY, ...o }; } });
}

async function offerOf(h: Harness): Promise<Hex> {
  for (let i = 0; i < 4 && h.node.store.offers.size === 0; i++) await h.tick();
  for (const t of h.node.store.offers.values()) if ((await h.chain.offer(t.offerId)).asset === NATIVE) return t.offerId;
  throw new Error('no ETH offer');
}

async function api(h: Harness): Promise<string> {
  const s = serveLpNode(h.node, {
    mode: 'api', now: () => Number(h.chain.time()),
    verifyTypedData: (args) => verifyTypedData(args as Parameters<typeof verifyTypedData>[0]),
  });
  closers.push(s.close);
  return `http://127.0.0.1:${await s.listen(0)}`;
}

async function ask(h: Harness, base: string, taker: ReturnType<typeof privateKeyToAccount>, offerId: Hex, weiAmount: bigint, o: { signer?: ReturnType<typeof privateKeyToAccount> } = {}) {
  const issuedAt = Number(h.chain.time());
  const message = { offerId, weiAmount, recipient: taker.address, boleto: false, issuedAt: BigInt(issuedAt) };
  const signature = await (o.signer ?? taker).signTypedData({
    domain: instructionsDomain(h.chain.chainId, ONRAMP), types: GATE_REQUEST_TYPES, primaryType: 'TakerGateRequest', message,
  });
  return fetch(`${base}/v1/onramp/gate`, {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ offerId, taker: taker.address, weiAmount: weiAmount.toString(), recipient: taker.address, boleto: false, issuedAt, signature }),
  });
}

describe('the taker gate (H-04)', () => {
  it('gates every offer it posts with its own key, never the LP\'s', async () => {
    const h = gated();
    const offerId = await offerOf(h);
    expect(await h.chain.takerGate(offerId)).toBe(privateKeyToAccount(GATE_KEY).address);
    expect(h.node.gate!.address).not.toBe(h.chain.account);
    // An ungated lock is refused by the escrow.
    expect(() => h.chain.lockOrder(offerId, 10n ** 17n)).toThrow(/GateRequired/);
  });

  it('approves one lock for the taker who signs, which the escrow takes once', async () => {
    const h = gated();
    const offerId = await offerOf(h);
    const base = await api(h);
    const taker = privateKeyToAccount(generatePrivateKey());
    const res = await ask(h, base, taker, offerId, 10n ** 17n);
    expect(res.status).toBe(200);
    const approval = await res.json() as { gate: string; deadline: number; signature: Hex };
    expect(approval.gate).toBe(h.node.gate!.address);
    const orderId = await h.chain.lockOrderGated(offerId, 10n ** 17n, { taker: taker.address, deadline: approval.deadline, signature: approval.signature });
    expect((await h.chain.order(orderId)).state).toBe(OrderState.LOCKED);
    await expect(h.chain.lockOrderGated(offerId, 10n ** 17n, { taker: taker.address, deadline: approval.deadline, signature: approval.signature }))
      .rejects.toThrow(/GateApprovalInvalid/);
    // Another amount, or another taker, under the same approval: refused.
    await expect(h.chain.lockOrderGated(offerId, 2n * 10n ** 17n, { taker: taker.address, deadline: approval.deadline, signature: approval.signature }))
      .rejects.toThrow(/GateApprovalInvalid/);
  });

  it('refuses a request not signed by the taker, and holds each taker to its limits', async () => {
    const h = gated({ maxOpenPerTaker: 2, perTakerPerHour: 3 });
    const offerId = await offerOf(h);
    const base = await api(h);
    const taker = privateKeyToAccount(generatePrivateKey());
    expect((await ask(h, base, taker, offerId, 10n ** 17n, { signer: privateKeyToAccount(generatePrivateKey()) })).status).toBe(401);

    // Two approvals outstanding: a third is refused until one is used and paid or cancelled.
    expect((await ask(h, base, taker, offerId, 10n ** 17n)).status).toBe(200);
    expect((await ask(h, base, taker, offerId, 10n ** 17n)).status).toBe(200);
    const third = await ask(h, base, taker, offerId, 10n ** 17n);
    expect(third.status).toBe(429);
    expect(await third.json()).toMatchObject({ code: 'gate_too_many_open' });
    // Another taker is not held to the first one's limit.
    expect((await ask(h, base, privateKeyToAccount(generatePrivateKey()), offerId, 10n ** 17n)).status).toBe(200);

    // Once the approvals expire, the hourly budget still binds: three an hour.
    h.chain.warp(200n);
    h.chain.mine();
    expect((await ask(h, base, taker, offerId, 10n ** 17n)).status).toBe(200);
    h.chain.warp(200n);
    h.chain.mine();
    const late = await ask(h, base, taker, offerId, 10n ** 17n);
    expect(late.status).toBe(429);
    expect(await late.json()).toMatchObject({ code: 'gate_rate_limited' });
  });
});
