import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { getAddress } from 'viem';
import { Rail } from '@mova/ramp';
import { payerRef } from '../src/attestation.js';
import { ConfigError, lpNodeConfigFromEnv } from '../src/config.js';

/**
 * The entrypoint's configuration. Importing the bin also proves it does not start on import - a
 * bin that ran `main()` at module load would try to reach an RPC from the test.
 */
const RPC = 'https://eth-mainnet.g.alchemy.com/v2/AbCdEfGhIjKlMnOp0123456789';
const KEY = `0x${'33'.repeat(32)}`;
const SECRET = `0x${'44'.repeat(32)}`;

const strategy = {
  registry: '0x00000000000000000000000000000000000000e6',
  fromBlock: '21000000',
  confirmations: 5,
  reorgWindow: 64,
  lpPayerId: '12345678000195',
  onramp: {
    escrow: '0x00000000000000000000000000000000000000e5',
    pixKey: '12.345.678/0001-95',
    receiver: { name: 'LP Liquidez Ltda', city: 'Sao Paulo' },
    assets: [{
      asset: '0x0000000000000000000000000000000000000000', symbol: 'ETH', liquidity: '5000000000000000000',
      minOrder: '10000000000000000', maxOrder: '2000000000000000000', verifier: '0x00000000000000000000000000000000000000a7',
      rails: ['PIX', 'BOLETO'], spreadBps: 80, minSpreadBps: 30, price: { source: 'http', url: 'https://prices.example/eth-brl' },
    }],
  },
  offramp: {
    escrow: '0x00000000000000000000000000000000000000e7',
    rails: ['PIX'],
    assets: [{ asset: '0xdAC17F958D2ee523a2206206994597C13D831ec7', symbol: 'USDT', minMarginBps: 40, maxSaleBrlCents: '500000', price: { source: 'oracle' } }],
  },
};

const env = {
  RPC_URL: RPC, LP_KEY_FILE: '/run/secrets/lp', PAYER_REF_SECRET: SECRET, STATE_FILE: '/data/lp.jsonl', LP_CONFIG: '/cfg/lp.json',
  BANK_MODULE: '/plugins/bank.js', BANK_CLIENT_SECRET: 'bank-client-secret-value',
};
const reader = (doc: unknown) => (p: string) => {
  if (p === '/cfg/lp.json') return JSON.stringify(doc);
  if (p === '/run/secrets/lp') return KEY;
  throw new Error('ENOENT');
};
const problems = (fn: () => unknown): string[] => {
  try {
    fn();
  } catch (e) {
    if (e instanceof ConfigError) return e.problems;
    throw e;
  }
  throw new Error('expected a ConfigError');
};

describe('the lp-node entrypoint configuration', () => {
  it('reads secrets from the environment and strategy from the file', () => {
    const cfg = lpNodeConfigFromEnv(env, reader(strategy));
    expect(cfg).toMatchObject({ rpcUrl: RPC, key: KEY, payerRefSecret: SECRET, confirmations: 5, reorgWindow: 64n, fromBlock: 21_000_000n, port: 9480 });
    expect(cfg.onramp!.assets[0]).toMatchObject({ liquidity: 5n * 10n ** 18n, rails: [Rail.PIX, Rail.BOLETO], price: { source: 'http' } });
    expect(cfg.onramp!.assets[0].pricing).toMatchObject({ spreadBps: 80, minSpreadBps: 30, maxOracleDeviationBps: 200, bandMarginBps: 50 });
    expect(cfg.offramp).toMatchObject({ rails: ['PIX'], maxOpenClaims: 2, raiseDisputeWhenUnproven: true });
    expect(cfg.offramp!.assets[0].asset).toBe('0xdAC17F958D2ee523a2206206994597C13D831ec7');
    // Everything secret-shaped is on the redaction list, the bank plugin's credential included.
    for (const s of [RPC, KEY, SECRET, 'bank-client-secret-value']) expect(cfg.secrets).toContain(s);
  });

  /// M-12: the ops listener is loopback by default, and one listener serving /status and /metrics on a public
  /// address is refused unless it is a decision.
  it('keeps /status and /metrics off public addresses unless told otherwise', () => {
    expect(lpNodeConfigFromEnv(env, reader(strategy))).toMatchObject({ host: '127.0.0.1', apiHost: '0.0.0.0' });
    expect(problems(() => lpNodeConfigFromEnv({ ...env, HOST: '0.0.0.0' }, reader(strategy))).join('\n')).toMatch(/LP_NODE_PUBLIC_OPS/);
    expect(lpNodeConfigFromEnv({ ...env, HOST: '0.0.0.0', API_PORT: '8480' }, reader(strategy)).host).toBe('0.0.0.0');
    expect(lpNodeConfigFromEnv({ ...env, HOST: '0.0.0.0', LP_NODE_PUBLIC_OPS: '1' }, reader(strategy)).host).toBe('0.0.0.0');
  });

  it('names every problem at once, by path, without echoing values', () => {
    const bad = {
      ...strategy, registry: 'nope', confirmations: 0,
      onramp: { ...strategy.onramp, pixKey: '000.000.000-00', assets: [{ ...strategy.onramp.assets[0], minOrder: '0', rails: ['CARRIER_PIGEON'] }] },
      offramp: { ...strategy.offramp, minTimeToPaySeconds: 60, disputeMarginSeconds: 120 },
    };
    const p = problems(() => lpNodeConfigFromEnv({ ...env, RPC_URL: 'ftp://node/SECRETKEY123' }, reader(bad)));
    const text = p.join('\n');
    for (const want of [/RPC_URL must be an http/, /config.registry must be an address/, /confirmations must be at least 1/,
      /pixKey is not a valid PIX key/, /minOrder <= maxOrder/, /rails must be a non-empty list/, /disputeMarginSeconds must be below/]) {
      expect(text).toMatch(want);
    }
    expect(text).not.toContain('SECRETKEY123');
    expect(text).not.toContain('000.000.000-00');
  });

  it('charges PIX with a static code unless onramp.pixCharge says cob', () => {
    expect(lpNodeConfigFromEnv(env, reader(strategy)).onramp).toMatchObject({ pixCharge: 'static', cobMarginSeconds: 300 });
    const cob = lpNodeConfigFromEnv(env, reader({ ...strategy, onramp: { ...strategy.onramp, pixCharge: 'cob', cobMarginSeconds: 600 } }));
    expect(cob.onramp).toMatchObject({ pixCharge: 'cob', cobMarginSeconds: 600 });
    const p = problems(() => lpNodeConfigFromEnv(env, reader({ ...strategy, onramp: { ...strategy.onramp, pixCharge: 'dynamic', cobMarginSeconds: 1_800 } })));
    expect(p.join('\n')).toMatch(/pixCharge must be "static" or "cob"/);
    expect(p.join('\n')).toMatch(/cobMarginSeconds must be an integer from 0 to 1500/);
  });

  it('allows no browser origin by default, and reads API_ALLOWED_ORIGINS as an explicit, normalized list', () => {
    expect(lpNodeConfigFromEnv(env, reader(strategy)).apiAllowedOrigins).toEqual([]);
    const cfg = lpNodeConfigFromEnv({ ...env, API_ALLOWED_ORIGINS: ' https://Wallet.Example/ , http://localhost:8981,' }, reader(strategy));
    expect(cfg.apiAllowedOrigins).toEqual(['https://wallet.example', 'http://localhost:8981']);
    const p = problems(() => lpNodeConfigFromEnv({ ...env, API_ALLOWED_ORIGINS: '*,https://wallet.example/pay?x=SECRET1' }, reader(strategy))).join('\n');
    expect(p).toMatch(/API_ALLOWED_ORIGINS entry 1 is '\*': refused/);
    expect(p).toMatch(/API_ALLOWED_ORIGINS entry 2 must be an origin only/);
    expect(p).not.toContain('SECRET1');
  });

  it('refuses to start with neither leg enabled, or without a journal', () => {
    const p = problems(() => lpNodeConfigFromEnv({ ...env, STATE_FILE: '' }, reader({ ...strategy, onramp: undefined, offramp: undefined })));
    expect(p.join('\n')).toMatch(/STATE_FILE is required/);
    expect(p.join('\n')).toMatch(/enable onramp, offramp, or both/);
  });

  it('holds its key only in variables it deletes, and the bin does not run on import', async () => {
    const src = readFileSync(new URL('../src/bin/lp-node.ts', import.meta.url), 'utf8');
    expect(src).toMatch(/delete process\.env\[name\]/);
    const mod = await import('../src/bin/lp-node.js');
    expect(typeof mod.isMain).toBe('function');
    // Importing the entrypoint loads the node's whole module graph: 3.7 s alone on a fast machine, over
    // vitest's 5 s default under a loaded CI runner. The assertion is about what the import does, not how fast.
  }, 30_000);
});

describe('the development provers, and bank rails on zkTLS', () => {
  const ZKTLS = '0x0000000000000000000000000000000000002c75';
  const WITNESS = `0x${'55'.repeat(32)}`;
  const files: Record<string, unknown> = {
    '/dev/witnesses.json': { verifier: ZKTLS, threshold: 1, keys: [WITNESS], urlPrefix: 'https://api.banco-lp.example/' },
  };
  const devReader = (doc: unknown, extra: Record<string, unknown> = {}) => (p: string) => {
    const f = { ...files, ...extra }[p];
    return f === undefined ? reader(doc)(p) : JSON.stringify(f);
  };
  const devEnv = { ...env, LP_NODE_DEV: '1', ZKTLS_WITNESS_KEYS_FILE: '/dev/witnesses.json' };
  const onZkTls = { ...strategy, onramp: { ...strategy.onramp, assets: [{ ...strategy.onramp.assets[0], verifier: ZKTLS }] } };

  it('reads the witnesses from their file in development, and redacts their keys', () => {
    const cfg = lpNodeConfigFromEnv(devEnv, devReader(onZkTls));
    expect(cfg.devProvers).toMatchObject({
      zktls: { verifier: getAddress(ZKTLS), threshold: 1, urlPrefix: 'https://api.banco-lp.example/' },
    });
    expect(cfg.secrets).toContain(WITNESS);
  });

  it('refuses the files outside development, beside PROVER_MODULE, or malformed', () => {
    const { LP_NODE_DEV: _dev, ...prod } = devEnv;
    expect(problems(() => lpNodeConfigFromEnv(prod, devReader(onZkTls))).join('\n')).toMatch(/ZKTLS_WITNESS_KEYS_FILE is for LP_NODE_DEV=1 only/);
    expect(problems(() => lpNodeConfigFromEnv({ ...devEnv, PROVER_MODULE: '/plugins/provers.js' }, devReader(onZkTls))).join('\n')).toMatch(/set PROVER_MODULE or ZKTLS_WITNESS_KEYS_FILE, not both/);
    const bad = problems(() => lpNodeConfigFromEnv(devEnv, devReader(onZkTls, {
      '/dev/witnesses.json': { verifier: ZKTLS, threshold: 3, keys: [WITNESS], urlPrefix: 'https://api.banco-lp.example' },
    }))).join('\n');
    expect(bad).toMatch(/ZKTLS_WITNESS_KEYS_FILE\.threshold must be an integer from 1 to the number of keys/);
    expect(bad).toMatch(/ZKTLS_WITNESS_KEYS_FILE\.urlPrefix must be https:\/\/<lowercase host>\/\[path\/\]/);
    expect(bad).not.toContain(WITNESS.slice(2));
  });
});

describe('the gateway section', () => {
  const movva = '0x0000000000000000000000000000000000004d56'; // already checksummed: no letters to case
  const gateway = {
    reserve: '0x00000000000000000000000000000000000000e8', usdt: '0xdAC17F958D2ee523a2206206994597C13D831ec7', movva,
    mint: { maxMintUsdt: '50000000000', maxMintUsdtPerDay: '200000000000', usdtCostBps: 30, maxFeeBps: 10 },
    redeem: { keepMovva: '1000000000000000000000', maxRedeemMovva: '100000000000000000000000', maxRedeemMovvaPerDay: '500000000000000000000000', usdtSaleBps: 30 },
  };
  const movvaOffer = {
    asset: movva, symbol: 'MOVVA', liquidity: '10000000000000000000000', minOrder: '10000000000000000000', maxOrder: '5000000000000000000000',
    verifier: '0x00000000000000000000000000000000000000a7', rails: ['PIX'], spreadBps: 100, minSpreadBps: 50, price: { source: 'par' },
  };

  it('reads the policy, with defaults only where a default is the cautious choice', () => {
    const cfg = lpNodeConfigFromEnv(env, reader({ ...strategy, gateway, onramp: { ...strategy.onramp, assets: [...strategy.onramp.assets, movvaOffer] } }));
    expect(cfg.gateway).toMatchObject({
      movva,
      mint: { enabled: true, maxSlippageBps: 10, minMintUsdt: 1_000_000n, maxMintUsdt: 50_000_000_000n, maxMintUsdtPerDay: 200_000_000_000n, keepUsdt: 0n, maxFeeBps: 10, usdtCostBps: 30 },
      redeem: { enabled: true, keepMovva: 1_000n * 10n ** 18n, minRedeemMovva: 10n * 10n ** 18n, maxSlippageBps: 10, minCollateralRatioBps: 10_000, maxFeeBps: 0, usdtSaleBps: 30 },
      maxRateDeviationBps: 100, maxReferenceAgeSeconds: 300,
    });
    expect(cfg.gateway!.usdtPrice).toBeUndefined();
    expect(cfg.onramp!.assets[1].price).toEqual({ source: 'par' });
  });

  it('refuses an enabled side without its limits and costs, unsafe bounds, and "par" on anything but Movva', () => {
    const bad = {
      ...strategy,
      gateway: { reserve: gateway.usdt, usdt: gateway.usdt, movva, mint: { maxSlippageBps: 0 }, redeem: { minCollateralRatioBps: 4_000 }, usdtPrice: { source: 'oracle' } },
      offramp: { ...strategy.offramp, assets: [{ ...strategy.offramp.assets[0], price: { source: 'par' } }] },
    };
    const text = problems(() => lpNodeConfigFromEnv(env, reader(bad))).join('\n');
    for (const want of [
      /gateway.mint.maxMintUsdt is required/, /gateway.mint.maxMintUsdtPerDay is required/, /gateway.mint.usdtCostBps is required/,
      /gateway.redeem.maxRedeemMovva is required/, /gateway.redeem.usdtSaleBps is required/, /mint.maxSlippageBps must be at least 1/,
      /minCollateralRatioBps must be from 5000/, /three different addresses/, /usdtPrice must be/,
      /offramp.assets\[0\].price: "par" is only for the gateway's Movva/,
    ]) expect(text).toMatch(want);
  });

  it('a disabled side needs no limits, and "par" without a gateway is refused', () => {
    const cfg = lpNodeConfigFromEnv(env, reader({ ...strategy, gateway: { ...gateway, mint: { enabled: false }, redeem: { enabled: false } } }));
    expect(cfg.gateway).toMatchObject({ mint: { enabled: false }, redeem: { enabled: false } });
    const p = problems(() => lpNodeConfigFromEnv(env, reader({ ...strategy, onramp: { ...strategy.onramp, assets: [movvaOffer] } })));
    expect(p.join('\n')).toMatch(/"par" is only for the gateway's Movva/);
  });
});

describe('cards were removed on 24 September 2026', () => {
  const cardAsset = { ...strategy.onramp.assets[0], rails: ['CARD'] };

  it('refuses, rather than ignores, a configuration that still names the card rail or the attestor quorum', () => {
    const section = problems(() => lpNodeConfigFromEnv(env, reader({ ...strategy, onramp: { ...strategy.onramp, card: { acquirerId: '01027058000191', merchantId: 'M', feeBps: 350 } } }))).join('\n');
    expect(section).toMatch(/config\.onramp\.card is gone: the card rail was removed on 24 September 2026/);
    expect(problems(() => lpNodeConfigFromEnv({ ...env, ACQUIRER_MODULE: '/plugins/acquirer.js' }, reader(strategy))).join('\n')).toMatch(/ACQUIRER_MODULE is gone/);
    expect(problems(() => lpNodeConfigFromEnv({ ...env, ATTESTOR_KEYS_FILE: '/dev/attestors.json' }, reader(strategy))).join('\n')).toMatch(/ATTESTOR_KEYS_FILE is gone/);
    const rails = problems(() => lpNodeConfigFromEnv(env, reader({ ...strategy, onramp: { ...strategy.onramp, assets: [cardAsset] } }))).join('\n');
    expect(rails).toMatch(/rails must be a non-empty list of PIX, BOLETO, TED/);
  });
});

describe('the tx section', () => {
  it('reads the replacement policy with its cap, and refuses a bump nodes would refuse or no cap', () => {
    const cfg = lpNodeConfigFromEnv(env, reader({ ...strategy, tx: { maxFeePerGasWei: '200000000000', maxPriorityFeePerGasWei: '3000000000' } }));
    expect(cfg.tx).toEqual({
      replaceAfterBlocks: 3, bumpBps: 1_250, maxFeePerGasWei: 200_000_000_000n, maxPriorityFeePerGasWei: 3_000_000_000n, waitBlocks: 30, gasHeadroomPercent: 20,
    });
    expect(lpNodeConfigFromEnv(env, reader(strategy)).tx).toBeUndefined();
    const text = problems(() => lpNodeConfigFromEnv(env, reader({ ...strategy, tx: { bumpBps: 500 } }))).join('\n');
    expect(text).toMatch(/config.tx.maxFeePerGasWei is required/);
    expect(text).toMatch(/bumpBps must be at least 1000/);
  });
});

describe('the webhook section', () => {
  it('takes the HMAC secret from the environment only, and proxy-mtls with its defaults', () => {
    const hmac = lpNodeConfigFromEnv({ ...env, PIX_WEBHOOK_SECRET: 's'.repeat(40) }, reader({ ...strategy, webhook: { auth: 'hmac', secret: 'in-the-file' } }));
    expect(hmac.webhook).toEqual({ auth: 'hmac', secret: 's'.repeat(40) });
    expect(hmac.secrets).toContain('s'.repeat(40));
    const proxy = lpNodeConfigFromEnv({ ...env, PIX_WEBHOOK_SECRET: 'p'.repeat(40) }, reader({ ...strategy, webhook: { auth: 'proxy-mtls' } }));
    expect(proxy.webhook).toEqual({ auth: 'proxy-mtls', header: 'x-ssl-client-verify', value: 'SUCCESS', secret: 'p'.repeat(40) });
    expect(proxy.secrets).toContain('p'.repeat(40));
    // I-24: the proxy's constant header is not enough on its own.
    expect(problems(() => lpNodeConfigFromEnv(env, reader({ ...strategy, webhook: { auth: 'proxy-mtls' } }))).join('\n'))
      .toMatch(/PIX_WEBHOOK_SECRET_FILE \(or PIX_WEBHOOK_SECRET\) is required/);
    const text = [
      ...problems(() => lpNodeConfigFromEnv(env, reader({ ...strategy, webhook: { auth: 'hmac' } }))),
      ...problems(() => lpNodeConfigFromEnv({ ...env, PIX_WEBHOOK_SECRET: 'short' }, reader({ ...strategy, webhook: { auth: 'hmac' } }))),
      ...problems(() => lpNodeConfigFromEnv(env, reader({ ...strategy, webhook: { auth: 'none' } }))),
    ].join('\n');
    expect(text).toMatch(/PIX_WEBHOOK_SECRET_FILE \(or PIX_WEBHOOK_SECRET\) is required/);
    expect(text).toMatch(/PIX_WEBHOOK_SECRET must be at least 32 characters/);
    expect(text).toMatch(/webhook.auth must be "hmac" or "proxy-mtls"/);
    expect(text).not.toContain('short');
  });
});

describe('the rewards section', () => {
  const contract = '0x000000000000000000000000000000000000a3a4';

  it('claims by default, anything above zero, from the last 12 finalized epochs', () => {
    const cfg = lpNodeConfigFromEnv(env, reader({ ...strategy, rewards: { contract } }));
    expect(cfg.rewards).toEqual({ contract: getAddress(contract), claim: true, minClaim: 0n, lookbackEpochs: 12 });
    const custom = lpNodeConfigFromEnv(env, reader({
      ...strategy, rewards: { contract, claim: false, minClaim: '100000000000000000000', lookbackEpochs: 104, to: strategy.onramp.escrow },
    }));
    expect(custom.rewards).toMatchObject({ claim: false, minClaim: 100n * 10n ** 18n, lookbackEpochs: 104, to: getAddress(strategy.onramp.escrow) });
  });

  it('refuses a missing or mistaken contract and an impossible look-back, naming each', () => {
    const p = problems(() => lpNodeConfigFromEnv(env, reader({
      ...strategy, rewards: { lookbackEpochs: 0, minClaim: '-1' },
    })));
    expect(p.join('\n')).toMatch(/config.rewards.contract must be an address/);
    expect(p.join('\n')).toMatch(/config.rewards.lookbackEpochs must be from 1 to 104/);
    expect(p.join('\n')).toMatch(/config.rewards.minClaim must be a non-negative integer/);
    expect(problems(() => lpNodeConfigFromEnv(env, reader({ ...strategy, rewards: { contract: strategy.registry } }))).join('\n'))
      .toMatch(/config.rewards.contract is the registry/);
    expect(problems(() => lpNodeConfigFromEnv(env, reader({ ...strategy, rewards: { contract, lookbackEpochs: 105 } }))).join('\n'))
      .toMatch(/lookbackEpochs must be an integer from 0 to 104/);
  });
});

describe('the caps section', () => {
  it('is absent by default, and a section with no numbers is a ledger that refuses nothing', () => {
    expect(lpNodeConfigFromEnv(env, reader(strategy)).caps).toBeUndefined();
    const cfg = lpNodeConfigFromEnv(env, reader({ ...strategy, caps: {} }));
    expect(cfg.caps).toEqual({ tiers: {}, defaultTier: 0, payerTiers: new Map(), unknownPayer: 'refuse' });
  });

  it('reads tiers 0-4 with their daily and monthly limits, and the default tier', () => {
    const cfg = lpNodeConfigFromEnv(env, reader({
      ...strategy,
      caps: {
        defaultTier: 1, unknownPayer: 'allow',
        tiers: { 0: { dailyBrlCents: '200000' }, 1: { dailyBrlCents: '500000', monthlyBrlCents: '2000000' }, 4: {} },
      },
    }));
    expect(cfg.caps).toMatchObject({ defaultTier: 1, unknownPayer: 'allow' });
    expect(cfg.caps!.tiers[0]).toEqual({ dailyBrlCents: 200_000n });
    expect(cfg.caps!.tiers[1]).toEqual({ dailyBrlCents: 500_000n, monthlyBrlCents: 2_000_000n });
    expect(cfg.caps!.tiers[4]).toEqual({}); // stated, and unlimited
    expect(cfg.caps!.tiers[2]).toBeUndefined();
  });

  it('takes a payer list by hash, hashes a document instead of keeping it, and refuses both at once', () => {
    const ref = `0x${'7e'.repeat(32)}`;
    const cfg = lpNodeConfigFromEnv(env, reader({
      ...strategy,
      caps: { tiers: { 3: { dailyBrlCents: '1000000' } }, payers: [{ payerRef: ref, tier: 3 }, { payer: '529.982.247-25', tier: 3 }] },
    }));
    expect(cfg.caps!.payerTiers.get(ref)).toBe(3);
    expect(cfg.caps!.payerTiers.size).toBe(2);
    // The document itself is nowhere in the parsed configuration: only its hash under PAYER_REF_SECRET.
    expect(JSON.stringify([...cfg.caps!.payerTiers])).not.toContain('529982247');
    expect([...cfg.caps!.payerTiers.keys()]).toContain(payerRef('529.982.247-25', SECRET as `0x${string}`).toLowerCase());

    const p = problems(() => lpNodeConfigFromEnv(env, reader({
      ...strategy, caps: { payers: [{ payerRef: ref, payer: 'x', tier: 1 }] },
    })));
    expect(p.join('\n')).toMatch(/config.caps.payers\[0\]: give payerRef or payer, not both/);
  });

  it('names every mistake by path, without echoing a document', () => {
    const p = problems(() => lpNodeConfigFromEnv(env, reader({
      ...strategy,
      caps: {
        defaultTier: 7, unknownPayer: 'sometimes',
        tiers: { 0: { dailyBrlCents: '500000', monthlyBrlCents: '100000' }, 9: {} },
        payers: [{ tier: 2 }, { payer: '529.982.247-25', tier: 9 }],
      },
    })));
    const all = p.join('\n');
    expect(all).toMatch(/config.caps.defaultTier must be a tier 0-4/);
    expect(all).toMatch(/config.caps.unknownPayer must be "refuse"/);
    expect(all).toMatch(/config.caps.tiers has key "9"/);
    expect(all).toMatch(/config.caps.tiers.0: monthlyBrlCents is below dailyBrlCents/);
    expect(all).toMatch(/config.caps.payers\[0\] must name payerRef/);
    expect(all).toMatch(/config.caps.payers\[1\].tier must be a tier 0-4/);
    expect(all).not.toContain('529.982.247-25');
  });

  it('refuses TIER_MODULE without a caps section: it would tier nothing', () => {
    expect(problems(() => lpNodeConfigFromEnv({ ...env, TIER_MODULE: '/plugins/tiers.js' }, reader(strategy))).join('\n'))
      .toMatch(/TIER_MODULE names a source of per-payer tiers, and there is no config.caps/);
    expect(lpNodeConfigFromEnv({ ...env, TIER_MODULE: '/plugins/tiers.js' }, reader({ ...strategy, caps: {} })).tierModule)
      .toBe('/plugins/tiers.js');
  });
});
