/**
 * An in-memory ramp: FiatEscrow, OffRampEscrow, LPRegistry and an oracle per asset, with blocks.
 *
 * It exists to test ORDERING, which a live node makes hard: every write mines a block, state is
 * snapshotted per block so reads "at" a block see exactly that block, `mine()` adds confirmations
 * one at a time, and `reorg(depth)` throws the last blocks away. The checks the node's safety
 * leans on are modelled after the Solidity - band and staleness at post and lock, windows,
 * payee/amount/rail/receipt-time at settlement, replay, exposure reservation - and proofs are decoded
 * and checked as their verifier checks them, so a node that builds a wrong proof fails here as it
 * would on-chain:
 *
 *  - a `ReclaimZkTlsVerifier` proof (`zktls`, per verifier) as that contract reads one: provider `http`,
 *    the identifier recomputed, witness signatures over the serialised claim, known and strictly
 *    ascending and at least the threshold, the endpoint's template hash allowlisted with its URL prefix,
 *    `contextMessage` equal to the order or sale id (`OrderMismatch`), the extracted rail one the
 *    endpoint may attest (`RailNotAllowedForEndpoint`), and - on an endpoint that requires it - an
 *    extracted `txid` that is the order's for the escrow asking (`MissingField`, `OrderTxidMismatch`, M-03).
 *
 * Bank rails need zkTLS as the escrows say: `postOffer` and `openSale` refuse a verifier that is not in `zktls` (`BankRailNeedsZkTls`). Anything not listed is not
 * modelled; the live example (examples/lp-node-live.ts) runs the real contracts.
 *
 * ## The FX leg, and off-hours
 *
 * `FakeReserve.fxLeg` is `signed` by default: one reading, refused once older than `maxAge` (`StaleLeg`).
 * `pyth` models PythFxOracle behind MovvaReserve: the rate is refused once old (`StaleRate`), and the band -
 * `bandBrlPerUsdtE18`, and Movva's price on the escrows - takes a price up to `closedMaxAge` old as the last
 * close, stamped with the block's time, outside FxMarketHours' core session (13:30-21:00 UTC on weekdays).
 *
 * ## The Movva reserve, and the LP's nonce
 *
 * `MovvaReserve.mint` and `redeem` are modelled refusal by refusal, in the contract's order, with its
 * rounding (fees up, amounts down, redemptions at min(par, pro rata)) and Movva listed on both escrows
 * with the reserve as its band. USDT's approve refuses a non-zero to non-zero change, as TetherToken does.
 * A gateway send goes to a mempool with the nonce it was given: it is mined in the next block, or held
 * (`holdSends`), dropped (`dropPending`), re-injected after a reorg, or broadcast with its response lost
 * (`loseNextSendResponse`) - the cases gateway.ts's intents exist for. Every LP write consumes a nonce.
 * `attempts` records every simulated or sent mint and redemption with what the contract would refuse at
 * that moment, so a test can show the node never even tried. The live example
 * (examples/lp-node-movva-live.ts) runs the real reserve.
 */
import {
  decodeAbiParameters, encodeAbiParameters, keccak256, recoverAddress, recoverMessageAddress, recoverTypedDataAddress, toHex,
  type Address, type Hex,
} from 'viem';
import { takerGateMessage } from '../src/gate.js';
import {
  Rail, claimDigest, claimIdentifier, decodeProof, isOrderTxid, proofEndpoint, proofPayment, type ReclaimProof,
} from '@mova/ramp';
import {
  BOLETO_ISSUE_WINDOW, BOLETO_PAY_WINDOW, MAX_PRICE_AGE, OFFRAMP_PAY_WINDOW, OFFRAMP_RECEIPT_MAX_AGE,
  ONRAMP_PAY_WINDOW, ONRAMP_RECEIPT_MAX_AGE, OrderState, SaleState,
} from '../src/abi.js';
import {
  ChainRevert, NATIVE, sameAddress,
  type AssetConfig, type BlockRef, type Credit, type GatewayAddresses, type GatewayChain, type Leg, type OnChainBoleto,
  type OnChainDispute, type OnChainOffer, type OnChainOrder, type OnChainSale, type OraclePrice, type PostOfferArgs,
  type RampChain, type RampEvent,
  type ReserveView, type RewardsChain, type RewardsView, type TxOutcome, type TxResult,
} from '../src/chain.js';

const BOLETO_BIT = 1 << Rail.BOLETO;
/** Both escrows' DISPUTE_TIMEOUT, as the rail deploys them: an LP's dispute, and every off-ramp dispute. */
export const FAKE_DISPUTE_TIMEOUT = 30n * 24n * 60n * 60n;
/** The on-ramp's TAKER_DISPUTE_TIMEOUT (H-04): a dispute its taker raised ends on this shorter clock. */
export const FAKE_TAKER_DISPUTE_TIMEOUT = 5n * 24n * 60n * 60n;
/** FiatEscrow.disputeDeadline: the clock depends on who raised the dispute. */
const deadlineOf = (d: { at: bigint; byTaker: boolean }) => d.at + (d.byTaker ? FAKE_TAKER_DISPUTE_TIMEOUT : FAKE_DISPUTE_TIMEOUT);
const ceilDiv = (a: bigint, b: bigint) => (a === 0n ? 0n : (a - 1n) / b + 1n);
const BPS = 10_000n;
const USDT_UNIT = 1_000_000n;
const E18 = 10n ** 18n;
const MAX_UINT = 2n ** 256n - 1n;

/** MovvaReserve's state, as far as mint, redeem and the band read it. */
export interface FakeReserve {
  isGateway: boolean;
  setupComplete: boolean;
  mintPaused: boolean;
  /** Tether has frozen the reserve. */
  frozen: boolean;
  /** Tether has frozen the LP. */
  lpFrozen: boolean;
  rateE18: bigint;
  rateUpdatedAt: bigint;
  maxAge: bigint;
  /** `signed`: one reading, `StaleLeg` once old. `pyth`: PythFxOracle's two readings - see the header. */
  fxLeg: 'signed' | 'pyth';
  /** With `pyth`: how old a price the band takes as the last close outside the core session. */
  closedMaxAge: bigint;
  /** A rate refusal other than staleness, e.g. 'FxOutOfRange'. */
  rateError?: string;
  totalUsdt: bigint;
  /** What `_pay` could pay now: idle plus the vault's maxWithdraw. */
  liquidUsdt: bigint;
  supply: bigint;
  supplyCap: bigint;
  mintFeeBps: bigint;
  redeemFeeBps: bigint;
  minMintRatioBps: bigint;
  /** USDT a vault's rounding keeps from each mint's intake. */
  vaultRounding: bigint;
}

interface PendingTx { hash: Hex; nonce: number; kind: 'mint' | 'redeem'; amount: bigint; minOut: bigint; maxFee: bigint }

export interface GatewayReceipt { hash: Hex; kind: 'mint' | 'redeem'; nonce: number; ok: boolean; amountIn: bigint; amountOut?: bigint; error?: string }

/** A mint or redemption the LP simulated or sent, and the world as it was at that moment. */
export interface GatewayAttempt {
  kind: 'mint' | 'redeem';
  phase: 'simulate' | 'send';
  amount: bigint;
  minOut: bigint;
  hash?: Hex;
  /** What MovvaReserve would refuse right now, whatever the amount. Empty is the node's claim. */
  refusals: string[];
  head: bigint;
  time: bigint;
  walletMovva: bigint;
  /** Unlocked Movva in the LP's active offers. */
  activeAvailable: bigint;
  /** What this mint would deliver against the head's state. */
  expectedOut: bigint;
  rateE18: bigint;
  /** Other gateway transactions in the mempool when this one was sent. */
  mempoolGateway: number;
  /** The highest block holding a gateway receipt when this one was sent. */
  lastGatewayReceiptBlock?: bigint;
}

const allowanceKey = (token: Address, spender: Address) => `${token.toLowerCase()}:${spender.toLowerCase()}`;
const ratioOf = (r: FakeReserve, rate: bigint) => (r.supply === 0n ? MAX_UINT : (((r.totalUsdt * rate) / USDT_UNIT) * BPS) / r.supply);

interface State {
  offers: Map<string, OnChainOffer>;
  offerExposure: Map<string, bigint>;
  orders: Map<string, OnChainOrder>;
  boletos: Map<string, OnChainBoleto>;
  usedBoleto: Set<string>;
  sales: Map<string, OnChainSale>;
  /** By order or sale id: when it was disputed, and whether by the on-ramp taker (which detaches it, SRM1-4). */
  disputes: Map<string, { at: bigint; byTaker: boolean }>;
  usedBankTx: Set<string>;
  assets: Map<string, AssetConfig & { price: bigint; updatedAt: bigint }>;
  balances: Map<string, bigint>;
  capCents: bigint;
  exposureCents: bigint;
  allowedVerifiers: Set<string>;
  nonce: bigint;
  /** The LP account's transaction count. */
  lpNonce: number;
  /** The LP's allowances, by token and spender. */
  allowances: Map<string, bigint>;
  reserve: FakeReserve;
  /** FiatEscrow.takerGate, by offer (H-04). */
  takerGates: Map<string, Address>;
  usedGateApprovals: Set<string>;
}

interface Block extends BlockRef {
  state: State;
  events: RampEvent[];
  receipts: Map<string, GatewayReceipt>;
  /** Mempool transactions this block took: mined, or discarded because their nonce was spent. */
  included: PendingTx[];
}

export const ONRAMP: Address = '0x00000000000000000000000000000000000e5c01';
export const OFFRAMP: Address = '0x00000000000000000000000000000000000e5c02';
export const USDT: Address = '0x000000000000000000000000000000000000d6d7';
export const MOVVA: Address = '0x0000000000000000000000000000000000004d56';
export const RESERVE: Address = '0x00000000000000000000000000000000000e5e7e';
const assetKey = (leg: Leg, a: Address) => `${leg}:${a.toLowerCase()}`;

/** A ReclaimZkTlsVerifier as the fake escrows consult it. */
export interface FakeZkTlsVerifier {
  /** Lowercase witness addresses. */
  witnesses: Set<string>;
  threshold: number;
  /**
   * Lowercase providerHash => the URL prefix its `url` must start with, the rails it may attest (a mask over Rail), and
   * whether its non-boleto payments must carry the order's txid of the calling escrow (`endpointRequiresOrderTxid`).
   */
  endpoints: Map<string, { urlPrefix: string; railMask: number; requiresOrderTxid?: boolean }>;
}

/** FxMarketHours.inCoreSession: 13:30-21:00 UTC, Monday to Friday, not 25 December or 1 January. */
export function inFxCoreSession(t: bigint): boolean {
  const second = t % 86_400n;
  if (second < 48_600n || second >= 75_600n) return false;
  const day = t / 86_400n;
  const weekday = (day + 4n) % 7n; // 1 January 1970 was a Thursday
  if (weekday === 0n || weekday === 6n) return false;
  const d = new Date(Number(day) * 86_400_000);
  const [month, date] = [d.getUTCMonth() + 1, d.getUTCDate()];
  return !((month === 12 && date === 25) || (month === 1 && date === 1));
}

/**
 * NodeRewards as one LP sees it. Not per block: rewards are claimed at head, and a claim is idempotent on-chain. Tests
 * set epochs directly; `rewardsView` and the writes apply the contract's arithmetic and refusals.
 */
export interface FakeRewards {
  registry: Address;
  excluded: boolean;
  currentEpoch: bigint;
  nextToFinalize: bigint;
  /** Epochs whose review has ended and nobody finalized. */
  finalizable: bigint;
  tokenPerCent: bigint;
  /** By epoch: this LP's counted volume, the epoch's, the epoch's budget and per-LP cap (set at finalization). */
  epochs: Map<bigint, { lpVolume: bigint; volume: bigint; budget: bigint; lpCap: bigint }>;
  claimed: Set<bigint>;
  /** Everything claims have paid this LP. */
  paid: bigint;
}

export class FakeChain implements RampChain, GatewayChain, RewardsChain {
  readonly rewards: FakeRewards = {
    registry: REGISTRY, excluded: false, currentEpoch: 0n, nextToFinalize: 0n, finalizable: 0n, tokenPerCent: 10n ** 16n,
    epochs: new Map(), claimed: new Set(), paid: 0n,
  };

  readonly chainId = 31337;
  readonly onramp = ONRAMP;
  readonly offramp = OFFRAMP;
  readonly blocks: Block[] = [];
  private fork = 0;
  private nextGap = 12n;
  /** zkTLS verifiers, by lowercase address: the only ones a bank-rail offer or a sale may name. */
  readonly zktls = new Map<string, FakeZkTlsVerifier>();
  /** Called on every write the LP sends: tests count and fail them. */
  writes: string[] = [];
  failNext?: { fn: string; error: Error };
  /** Gateway sends wait in the mempool until a block is mined (by `mine` or any other write). */
  holdSends = false;
  /** The next gateway send is broadcast, and then its response is lost: the node sees a throw. */
  loseNextSendResponse = false;
  /** Runs once, after the next gateway send is broadcast and before it is mined. */
  onBroadcast?: () => void;
  /** Every RPC read of the reserve fails, as a dead node would. */
  reserveUnreadable = false;
  readonly attempts: GatewayAttempt[] = [];
  /** A block takes a mempool transaction only while its fee is at least this. */
  baseFee = 0n;
  /** What a new gateway send offers. */
  feeEstimate = 1_000_000_000n;
  /** The TxPolicy the gateway's replacements run under. */
  txPolicy = { replaceAfterBlocks: 0, bumpBps: 1_250, maxFeePerGasWei: 100_000_000_000n };
  /** The next replacement is broadcast, and its response lost. */
  loseNextReplaceResponse = false;
  /** Approvals USDT refused for changing a non-zero allowance to another non-zero one. */
  approveQuirkHits = 0;
  /** The escrows' band around their oracle, as `bandBps` reads it and post, lock and sale enforce it. */
  band_ = 500n;
  private mempool: PendingTx[] = [];
  private sendSeq = 0;

  /**
   * `verifier`: the default a sale names, allowed on both escrows. `verifiers`: more allowed from genesis. Whether each
   * proves the bank session is `zktls`'s to say.
   */
  constructor(readonly account: Address, readonly verifier: Address, opts: { t0?: bigint; verifiers?: Address[] } = {}) {
    const state: State = {
      offers: new Map(), offerExposure: new Map(), orders: new Map(), boletos: new Map(), usedBoleto: new Set(),
      sales: new Map(), disputes: new Map(), usedBankTx: new Set(), assets: new Map(), balances: new Map(), capCents: 100_000_000n,
      exposureCents: 0n, nonce: 0n, lpNonce: 0, allowances: new Map(), takerGates: new Map(), usedGateApprovals: new Set(),
      allowedVerifiers: new Set([verifier, ...(opts.verifiers ?? [])].map((v) => v.toLowerCase())),
      // At rest at the 108% target: R$ 1.000.000 of Movva backed by 200.000 USDT at R$ 5,40.
      reserve: {
        isGateway: true, setupComplete: true, mintPaused: false, frozen: false, lpFrozen: false,
        rateE18: 5_400_000_000_000_000_000n, rateUpdatedAt: opts.t0 ?? 1_800_000_000n, maxAge: 3_600n, fxLeg: 'signed', closedMaxAge: 0n,
        totalUsdt: 200_000n * USDT_UNIT, liquidUsdt: 200_000n * USDT_UNIT, supply: 1_000_000n * E18,
        supplyCap: 100_000_000n * E18, mintFeeBps: 0n, redeemFeeBps: 0n, minMintRatioBps: 10_000n, vaultRounding: 0n,
      },
    };
    const t0 = opts.t0 ?? 1_800_000_000n;
    for (const leg of ['onramp', 'offramp'] as const) {
      state.assets.set(assetKey(leg, NATIVE), { oracle: '0x00000000000000000000000000000000000000e1', decimals: 18, enabled: true, price: 2_000_000n, updatedAt: t0 });
      state.assets.set(assetKey(leg, USDT), { oracle: '0x00000000000000000000000000000000000000e2', decimals: 6, enabled: true, price: 550n, updatedAt: t0 });
      // Movva's band is the reserve itself: `price` is unused, the reserve is read.
      state.assets.set(assetKey(leg, MOVVA), { oracle: RESERVE, decimals: 18, enabled: true, price: 100n, updatedAt: t0 });
    }
    state.balances.set(`${NATIVE}:${account.toLowerCase()}`, 100n * 10n ** 18n);
    state.balances.set(`${USDT}:${account.toLowerCase()}`, 1_000_000n * 10n ** 6n);
    this.blocks.push({ number: 0n, hash: this.hashOf(0n), timestamp: t0, state, events: [], receipts: new Map(), included: [] });
  }

  private hashOf(n: bigint): Hex {
    return keccak256(toHex(`${this.fork}:${n}`));
  }

  private get tip(): Block {
    return this.blocks[this.blocks.length - 1];
  }

  /** Chain time: the head's timestamp. */
  time(): bigint {
    return this.tip.timestamp;
  }

  /*------------------------------ block control ------------------------------*/

  private mineWith(mutate: (s: State, now: bigint) => RampEvent[], o: { beforeMempool?: boolean } = {}): Block {
    const now = this.tip.timestamp + this.nextGap;
    const state = structuredClone(this.tip.state);
    const number = this.tip.number + 1n;
    let events: RampEvent[] = o.beforeMempool ? mutate(state, now) : [];
    // The LP's queued transactions first, in nonce order, as a block builder takes an account's queue.
    const receipts = new Map<string, GatewayReceipt>();
    const included: PendingTx[] = [];
    for (const p of [...this.mempool].sort((a, b) => a.nonce - b.nonce)) {
      if (p.nonce < state.lpNonce) {
        included.push(p); // its nonce went to another transaction: it can never mine
        continue;
      }
      if (p.nonce > state.lpNonce) break;
      if (p.maxFee < this.baseFee) break; // underpriced: stays in the mempool, and holds everything after it
      const r: GatewayReceipt = { hash: p.hash, kind: p.kind, nonce: p.nonce, ok: true, amountIn: p.amount };
      try {
        r.amountOut = p.kind === 'mint' ? this.applyMint(state, now, p.amount, p.minOut) : this.applyRedeem(state, now, p.amount, p.minOut);
      } catch (e) {
        if (!(e instanceof ChainRevert)) throw e;
        r.ok = false;
        r.error = e.errorName;
      }
      state.lpNonce++;
      receipts.set(p.hash.toLowerCase(), r);
      included.push(p);
    }
    if (!o.beforeMempool) events = mutate(state, now);
    events = events.map((e) => ({ ...e, block: number }));
    this.mempool = this.mempool.filter((p) => !included.includes(p));
    this.nextGap = 12n; // only once the block exists: a reverted write does not consume a warp
    const b: Block = { number, hash: this.hashOf(number), timestamp: now, state, events, receipts, included };
    this.blocks.push(b);
    return b;
  }

  /** Mine empty blocks: confirmations for whatever came before. */
  mine(n = 1): void {
    for (let i = 0; i < n; i++) this.mineWith(() => []);
  }

  /** The next block comes this many seconds after the head. */
  warp(seconds: bigint): void {
    this.nextGap = seconds;
  }

  /**
   * Throw away the last `depth` blocks. New blocks after this get new hashes. With `reinject`, the
   * gateway transactions they held go back to the mempool, as a node re-queues reorged transactions.
   */
  reorg(depth: number, o: { reinject?: boolean } = {}): void {
    const gone = this.blocks.splice(this.blocks.length - depth, depth);
    this.fork++;
    if (o.reinject) for (const b of gone) for (const p of b.included) if (!this.mempool.includes(p)) this.mempool.push(p);
  }

  /*------------------------------ the reserve's world ------------------------------*/

  setReserve(patch: Partial<FakeReserve>, o: { beforeMempool?: boolean } = {}): void {
    this.mineWith((s) => { Object.assign(s.reserve, patch); return []; }, o);
  }

  /** The FX publishers sign again, optionally a new rate. */
  publishRate(rateE18?: bigint): void {
    this.mineWith((s, now) => {
      if (rateE18 !== undefined) s.reserve.rateE18 = rateE18;
      s.reserve.rateUpdatedAt = now;
      s.reserve.rateError = undefined;
      return [];
    });
  }

  reserveState(): FakeReserve {
    return this.tip.state.reserve;
  }

  /** Someone sends the LP Movva that already existed, backed at the rate. */
  giveMovva(amount: bigint): void {
    this.mineWith((s) => {
      this.credit_(s, MOVVA, amount);
      s.reserve.supply += amount;
      const usdt = (amount * USDT_UNIT) / s.reserve.rateE18;
      s.reserve.totalUsdt += usdt;
      s.reserve.liquidUsdt += usdt;
      return [];
    });
  }

  /** An allowance left from earlier: a crashed process's approval, say. */
  setAllowance(token: Address, spender: Address, amount: bigint): void {
    this.mineWith((s) => { s.allowances.set(allowanceKey(token, spender), amount); return []; });
  }

  pending(): readonly PendingTx[] {
    return this.mempool;
  }

  dropPending(): void {
    this.mempool = [];
  }

  /** A copy of a dropped transaction surfaces again. */
  reinject(p: PendingTx): void {
    this.mempool.push(p);
  }

  /** Gateway receipts on the canonical chain. */
  executed(kind?: 'mint' | 'redeem'): (GatewayReceipt & { block: bigint; time: bigint })[] {
    return this.blocks.flatMap((b) => [...b.receipts.values()]
      .filter((r) => r.ok && (!kind || r.kind === kind)).map((r) => ({ ...r, block: b.number, time: b.timestamp })));
  }

  /*---------------------------- the rest of the world ----------------------------*/

  setOracle(asset: Address, price: bigint, updatedAt?: bigint): void {
    this.mineWith((s, now) => {
      for (const leg of ['onramp', 'offramp'] as const) {
        const a = s.assets.get(assetKey(leg, asset))!;
        a.price = price;
        a.updatedAt = updatedAt ?? now;
      }
      return [];
    });
  }

  setCap(capCents: bigint): void {
    this.mineWith((s) => { s.capCents = capCents; return []; });
  }

  revokeVerifier(v: Address): void {
    this.mineWith((s) => { s.allowedVerifiers.delete(v.toLowerCase()); return []; });
  }

  private id(s: State, tag: string): Hex {
    s.nonce++;
    return keccak256(encodeAbiParameters([{ type: 'string' }, { type: 'uint256' }], [tag, s.nonce]));
  }

  private band(s: State, leg: Leg, asset: Address, price: bigint, now: bigint): void {
    const a = s.assets.get(assetKey(leg, asset));
    if (!a?.enabled) throw new ChainRevert('AssetNotEnabled');
    const mid = sameAddress(a.oracle, RESERVE) ? this.reserveBand(s, now) : { price: a.price, updatedAt: a.updatedAt };
    if (now > mid.updatedAt + MAX_PRICE_AGE) throw new ChainRevert('StalePrice');
    const diff = price > mid.price ? price - mid.price : mid.price - price;
    if (diff * 10_000n > mid.price * this.band_) throw new ChainRevert('PriceOutsideBand');
  }

  /** MovvaReserve.brlCentsPerUnit: min(1, ratio) of 100 centavos, nearest, at the band's rate; reverts while it does. */
  private reserveBand(s: State, now: bigint): OraclePrice {
    const band = this.bandRateOf(s, now);
    let ratio = ratioOf(s.reserve, band.e18);
    if (ratio > BPS) ratio = BPS;
    const price = (ratio * 100n + BPS / 2n) / BPS;
    if (price === 0n) throw new ChainRevert('PriceRoundsToZero');
    return { price, updatedAt: band.updatedAt };
  }

  /** `brlPerUsdtE18`: what mint, redeem and the previews price at. Refused once old, at any hour. */
  private rateOf(s: State, now: bigint): bigint {
    const r = s.reserve;
    if (r.rateError) throw new ChainRevert(r.rateError);
    if (now > r.rateUpdatedAt + r.maxAge) throw new ChainRevert(r.fxLeg === 'pyth' ? 'StaleRate' : 'StaleLeg');
    return r.rateE18;
  }

  /** `bandBrlPerUsdtE18`: the rate, or, with a Pyth leg outside the core session, the last close stamped `now`. */
  private bandRateOf(s: State, now: bigint): { e18: bigint; updatedAt: bigint } {
    const r = s.reserve;
    if (r.rateError) throw new ChainRevert(r.rateError);
    if (now <= r.rateUpdatedAt + r.maxAge) return { e18: r.rateE18, updatedAt: r.rateUpdatedAt };
    if (r.fxLeg === 'pyth' && !inFxCoreSession(now) && now <= r.rateUpdatedAt + r.closedMaxAge) return { e18: r.rateE18, updatedAt: now };
    throw new ChainRevert(r.fxLeg === 'pyth' ? 'StaleRate' : 'StaleLeg');
  }

  /** `IAttestorVerifier.provesBankSession`. */
  provesBankSession(verifier: Address): boolean {
    return this.zktls.has(verifier.toLowerCase());
  }

  /**
   * `FiatEscrow.lockOrderGated` (H-04): the gate's EIP-191 approval over this lock, once. The recipient is the taker,
   * as `lockOrder` here makes it.
   */
  async lockOrderGated(offerId: Hex, amount: bigint, a: { taker: Address; boleto?: boolean; deadline: number; signature: Hex }): Promise<Hex> {
    const gate = this.tip.state.takerGates.get(offerId.toLowerCase());
    const digest = takerGateMessage({
      chainId: this.chainId, escrow: ONRAMP, offerId, taker: a.taker, weiAmount: amount, recipient: a.taker,
      boleto: a.boleto ?? false, deadline: BigInt(a.deadline),
    });
    const signer = await recoverMessageAddress({ message: { raw: digest }, signature: a.signature }).catch(() => undefined);
    if (!gate || !signer || !sameAddress(signer, gate) || this.time() > BigInt(a.deadline)) throw new ChainRevert('GateApprovalInvalid');
    const used = `${digest}`.toLowerCase();
    if (this.tip.state.usedGateApprovals.has(used)) throw new ChainRevert('GateApprovalInvalid');
    return this.lockOrder(offerId, amount, { boleto: a.boleto, taker: a.taker, gated: used });
  }

  lockOrder(offerId: Hex, amount: bigint, o: { boleto?: boolean; taker?: Address; gated?: string } = {}): Hex {
    let orderId: Hex = '0x';
    this.mineWith((s, now) => {
      const off = s.offers.get(offerId.toLowerCase());
      if (!o.gated && s.takerGates.has(offerId.toLowerCase())) throw new ChainRevert('GateRequired');
      if (o.gated) s.usedGateApprovals.add(o.gated);
      if (!off?.active) throw new ChainRevert('OfferInactive');
      if (amount < off.minOrderWei || amount > off.maxOrderWei) throw new ChainRevert('AmountOutOfRange');
      if (amount > off.availableWei) throw new ChainRevert('InsufficientLiquidity');
      if ((off.railMask & (o.boleto ? BOLETO_BIT : ~BOLETO_BIT & 0xffff)) === 0) throw new ChainRevert('RailNotAccepted');
      this.band(s, 'onramp', off.asset, off.priceBrlCentsPerEth, now);
      off.availableWei -= amount;
      off.lockedWei += amount;
      orderId = this.id(s, 'order');
      const brlCents = ceilDiv(amount * off.priceBrlCentsPerEth, 10n ** BigInt(off.decimals));
      const payBy = now + (o.boleto ? BOLETO_ISSUE_WINDOW : ONRAMP_PAY_WINDOW);
      const taker = o.taker ?? '0x0000000000000000000000000000000000007a4e';
      s.orders.set(orderId, { offerId, taker, weiAmount: amount, brlCents, lockedAt: now, payBy, state: OrderState.LOCKED, delivery: 0, recipient: taker });
      const events: RampEvent[] = [{ kind: 'OrderLocked', block: 0n, orderId, offerId, taker, brlCents }];
      if (o.boleto) {
        s.boletos.set(orderId, { issueBy: payBy, issuedAt: 0n, commitment: `0x${'0'.repeat(64)}` });
        events.push({ kind: 'BoletoRequested', block: 0n, orderId, issueBy: payBy });
      }
      return events;
    });
    return orderId;
  }

  lockOrderByBoleto(offerId: Hex, amount: bigint): Hex {
    return this.lockOrder(offerId, amount, { boleto: true });
  }

  cancelOrder(orderId: Hex): void {
    this.mineWith((s) => {
      const ord = s.orders.get(orderId)!;
      if (ord.state !== OrderState.LOCKED) throw new ChainRevert('WrongState');
      this.unlock(s, ord);
      return [{ kind: 'touched', block: 0n, leg: 'onramp', id: orderId }];
    });
  }

  /** The counterparty disputes: the on-ramp taker, or the off-ramp seller. */
  raiseDisputeAs(leg: Leg, id: Hex): void {
    this.mineWith((s, now) => {
      if (leg === 'onramp') {
        const ord = s.orders.get(id)!;
        if (ord.state !== OrderState.LOCKED) throw new ChainRevert('WrongState');
        // H-04: a taker disputes only inside the order's pay window.
        if (now > ord.payBy) throw new ChainRevert('WindowExpired');
        ord.state = OrderState.DISPUTED;
        s.disputes.set(id.toLowerCase(), { at: now, byTaker: true });
        // A taker's dispute takes the order out of its offer and gives its credit back (SRM1-4).
        const o = s.offers.get(ord.offerId.toLowerCase())!;
        o.lockedWei -= ord.weiAmount;
        this.releaseOfferExposure(s, ord.offerId, o);
      } else {
        const sale = s.sales.get(id)!;
        if (sale.state !== SaleState.CLAIMED) throw new ChainRevert('WrongState');
        sale.state = SaleState.DISPUTED;
        s.disputes.set(id.toLowerCase(), { at: now, byTaker: false });
      }
      return [{ kind: 'touched', block: 0n, leg, id }];
    });
  }

  /** FiatEscrow._releaseExposure: give back credit for liquidity that has left the offer. */
  private releaseOfferExposure(s: State, offerId: Hex, o: OnChainOffer): void {
    const target = this.exposureOf(o);
    const held = s.offerExposure.get(offerId.toLowerCase()) ?? 0n;
    if (target < held) { s.exposureCents -= held - target; s.offerExposure.set(offerId.toLowerCase(), target); }
  }

  /**
   * Where a proof's clock stands for an order or sale in `state` (SRM1-3): a LOCKED order or CLAIMED sale is proven
   * before payBy, a DISPUTED one before its deadline with the receipt's age taken at the freeze. Returns `asOf`.
   */
  private proofClock(s: State, id: Hex, disputed: boolean, payBy: bigint, now: bigint): bigint {
    if (!disputed) {
      if (now > payBy) throw new ChainRevert('WindowExpired');
      return now;
    }
    const d = s.disputes.get(id.toLowerCase())!;
    if (now >= deadlineOf(d)) throw new ChainRevert('DisputeExpired');
    return d.at;
  }

  openSale(o: { asset?: Address; amount: bigint; brlCents: bigint; payeeKeyHash: Hex; railMask: number; verifier?: Address }): Hex {
    let saleId: Hex = '0x';
    this.mineWith((s, now) => {
      const asset = o.asset ?? NATIVE;
      const cfg = s.assets.get(assetKey('offramp', asset))!;
      if (o.railMask & BOLETO_BIT && o.railMask !== BOLETO_BIT) throw new ChainRevert('BadSale');
      // Every payout is a bank payment: a sale settles only on a proof of the bank session.
      if (!this.provesBankSession(o.verifier ?? this.verifier)) throw new ChainRevert('BankRailNeedsZkTls');
      this.band(s, 'offramp', asset, (o.brlCents * 10n ** BigInt(cfg.decimals)) / o.amount, now);
      saleId = this.id(s, 'sale');
      s.sales.set(saleId, {
        seller: '0x00000000000000000000000000000000005e11e7', asset, weiAmount: o.amount, brlCents: o.brlCents,
        payeeKeyHash: o.payeeKeyHash, verifier: o.verifier ?? this.verifier, railMask: o.railMask,
        lp: NATIVE, claimedAt: 0n, payBy: 0n, refundTo: '0x00000000000000000000000000000000005e11e7', state: SaleState.OPEN,
      });
      return [{ kind: 'SaleOpened', block: 0n, saleId }];
    });
    return saleId;
  }

  releaseStaleClaimAs(saleId: Hex): void {
    this.mineWith((s, now) => {
      const sale = s.sales.get(saleId)!;
      if (sale.state !== SaleState.CLAIMED) throw new ChainRevert('WrongState');
      if (now <= sale.payBy) throw new ChainRevert('ClaimStillLive');
      const lp = sale.lp;
      Object.assign(sale, { lp: NATIVE, claimedAt: 0n, payBy: 0n, state: SaleState.OPEN });
      s.exposureCents -= sale.brlCents;
      return [{ kind: 'SaleUnclaimed', block: 0n, saleId, lp }];
    });
  }

  /** Someone other than the LP settles an order, e.g. the taker with their own proof. */
  releaseAsOther(orderId: Hex): void {
    this.mineWith((s) => {
      const ord = s.orders.get(orderId)!;
      if (ord.state !== OrderState.LOCKED) throw new ChainRevert('WrongState');
      ord.state = OrderState.RELEASED;
      s.offers.get(ord.offerId.toLowerCase())!.lockedWei -= ord.weiAmount;
      return [{ kind: 'touched', block: 0n, leg: 'onramp', id: orderId }];
    });
  }

  private unlock(s: State, ord: OnChainOrder): void {
    ord.state = OrderState.CANCELLED;
    const off = s.offers.get(ord.offerId.toLowerCase())!;
    off.lockedWei -= ord.weiAmount;
    off.availableWei += ord.weiAmount;
  }

  /*----------------------------------- reads -----------------------------------*/

  private at(at?: bigint): State {
    if (at === undefined) return this.tip.state;
    const b = this.blocks.find((x) => x.number === at);
    if (!b) throw new Error(`no state at block ${at}`);
    return b.state;
  }

  async head(): Promise<BlockRef> {
    const { number, hash, timestamp } = this.tip;
    return { number, hash, timestamp };
  }

  async block(number: bigint): Promise<BlockRef | undefined> {
    const b = this.blocks.find((x) => x.number === number);
    return b && { number: b.number, hash: b.hash, timestamp: b.timestamp };
  }

  async events(from: bigint, to: bigint): Promise<RampEvent[]> {
    return this.blocks.filter((b) => b.number >= from && b.number <= to).flatMap((b) => b.events);
  }

  async offer(id: Hex, at?: bigint): Promise<OnChainOffer> {
    return this.at(at).offers.get(id.toLowerCase()) ?? {
      lp: NATIVE, asset: NATIVE, availableWei: 0n, lockedWei: 0n, priceBrlCentsPerEth: 0n, pixKeyHash: `0x${'0'.repeat(64)}`,
      minOrderWei: 0n, maxOrderWei: 0n, verifier: NATIVE, railMask: 0, active: false, decimals: 0,
    };
  }

  async order(id: Hex, at?: bigint): Promise<OnChainOrder> {
    return this.at(at).orders.get(id) ?? {
      offerId: `0x${'0'.repeat(64)}`, taker: NATIVE, weiAmount: 0n, brlCents: 0n, lockedAt: 0n, payBy: 0n,
      state: OrderState.NONE, delivery: 0, recipient: NATIVE,
    };
  }

  async boleto(id: Hex, at?: bigint): Promise<OnChainBoleto> {
    return this.at(at).boletos.get(id) ?? { issueBy: 0n, issuedAt: 0n, commitment: `0x${'0'.repeat(64)}` };
  }

  async sale(id: Hex, at?: bigint): Promise<OnChainSale> {
    return this.at(at).sales.get(id) ?? {
      seller: NATIVE, asset: NATIVE, weiAmount: 0n, brlCents: 0n, payeeKeyHash: `0x${'0'.repeat(64)}`, verifier: NATIVE,
      railMask: 0, lp: NATIVE, claimedAt: 0n, payBy: 0n, refundTo: NATIVE, state: SaleState.NONE,
    };
  }

  async asset(leg: Leg, asset: Address): Promise<AssetConfig> {
    const a = this.tip.state.assets.get(assetKey(leg, asset));
    return a ? { oracle: a.oracle, decimals: a.decimals, enabled: a.enabled } : { oracle: NATIVE, decimals: 0, enabled: false };
  }

  async oraclePrice(oracle: Address): Promise<OraclePrice> {
    if (sameAddress(oracle, RESERVE)) return this.reserveBand(this.tip.state, this.tip.timestamp);
    for (const a of this.tip.state.assets.values()) {
      if (sameAddress(a.oracle, oracle)) return { price: a.price, updatedAt: a.updatedAt };
    }
    throw new ChainRevert('NoPriceYet');
  }

  async bandBps(): Promise<bigint> {
    return this.band_;
  }

  async verifierAllowed(_leg: Leg, verifier: Address): Promise<boolean> {
    return this.tip.state.allowedVerifiers.has(verifier.toLowerCase());
  }

  async credit(): Promise<Credit> {
    const s = this.tip.state;
    return { capCents: s.capCents, availableCents: s.capCents > s.exposureCents ? s.capCents - s.exposureCents : 0n, setupComplete: true };
  }

  async balance(asset: Address): Promise<bigint> {
    return this.bal(this.tip.state, asset);
  }

  private bal(s: State, asset: Address): bigint {
    return s.balances.get(`${asset.toLowerCase()}:${this.account.toLowerCase()}`) ?? 0n;
  }

  exposure(): bigint {
    return this.tip.state.exposureCents;
  }

  /*----------------------------------- writes -----------------------------------*/

  private fault(fn: string): void {
    if (this.failNext?.fn === fn) {
      const e = this.failNext.error;
      this.failNext = undefined;
      throw e;
    }
  }

  private tx(fn: string, mutate: (s: State, now: bigint) => RampEvent[]): TxResult {
    this.fault(fn);
    const b = this.mineWith((s, now) => {
      const events = mutate(s, now);
      s.lpNonce++;
      return events;
    });
    this.writes.push(fn);
    return { hash: keccak256(toHex(`tx:${this.fork}:${b.number}:${fn}`)), blockNumber: b.number };
  }

  private reserve(s: State, cents: bigint): void {
    if (s.exposureCents + cents > s.capCents) throw new ChainRevert('LPNotEligible');
    s.exposureCents += cents;
  }

  private exposureOf(o: OnChainOffer): bigint {
    return ceilDiv((o.availableWei + o.lockedWei) * o.priceBrlCentsPerEth, 10n ** BigInt(o.decimals));
  }

  private debit(s: State, asset: Address, amount: bigint): void {
    const k = `${asset.toLowerCase()}:${this.account.toLowerCase()}`;
    const bal = s.balances.get(k) ?? 0n;
    if (bal < amount) throw new ChainRevert('TransferFromFailed');
    s.balances.set(k, bal - amount);
  }

  private credit_(s: State, asset: Address, amount: bigint): void {
    const k = `${asset.toLowerCase()}:${this.account.toLowerCase()}`;
    s.balances.set(k, (s.balances.get(k) ?? 0n) + amount);
  }

  async postOffer(a: PostOfferArgs): Promise<TxResult & { offerId: Hex }> {
    let offerId: Hex = '0x';
    const r = this.tx('postOffer', (s, now) => {
      const cfg = s.assets.get(assetKey('onramp', a.asset));
      if (!cfg?.enabled) throw new ChainRevert('AssetNotEnabled');
      if (a.amount === 0n || a.priceBrlCentsPerUnit === 0n || a.minOrder === 0n || a.maxOrder < a.minOrder || a.maxOrder > a.amount) {
        throw new ChainRevert('BadOffer');
      }
      if (!s.allowedVerifiers.has(a.verifier.toLowerCase())) throw new ChainRevert('VerifierNotAllowed');
      if (!this.provesBankSession(a.verifier)) throw new ChainRevert('BankRailNeedsZkTls');
      this.band(s, 'onramp', a.asset, a.priceBrlCentsPerUnit, now);
      offerId = this.id(s, 'offer');
      const o: OnChainOffer = {
        lp: this.account, asset: a.asset, availableWei: a.amount, lockedWei: 0n, priceBrlCentsPerEth: a.priceBrlCentsPerUnit,
        pixKeyHash: a.pixKeyHash, minOrderWei: a.minOrder, maxOrderWei: a.maxOrder, verifier: a.verifier, railMask: a.railMask,
        active: true, decimals: cfg.decimals,
      };
      const exp = this.exposureOf(o);
      this.reserve(s, exp);
      s.offerExposure.set(offerId.toLowerCase(), exp);
      this.debit(s, a.asset, a.amount);
      s.offers.set(offerId.toLowerCase(), o);
      return [{ kind: 'OfferPosted', block: 0n, offerId, lp: this.account }];
    });
    return { ...r, offerId };
  }

  async fundOffer(offerId: Hex, asset: Address, amount: bigint): Promise<TxResult> {
    return this.tx('fundOffer', (s) => {
      const o = s.offers.get(offerId.toLowerCase());
      if (!o || !sameAddress(o.lp, this.account)) throw new ChainRevert('NotLP');
      if (!o.active) throw new ChainRevert('OfferInactive');
      o.availableWei += amount;
      const target = this.exposureOf(o);
      const held = s.offerExposure.get(offerId.toLowerCase()) ?? 0n;
      if (target > held) {
        this.reserve(s, target - held);
        s.offerExposure.set(offerId.toLowerCase(), target);
      }
      this.debit(s, asset, amount);
      return [];
    });
  }

  async takerGate(offerId: Hex): Promise<Address> {
    return this.tip.state.takerGates.get(offerId.toLowerCase()) ?? '0x0000000000000000000000000000000000000000';
  }

  async setTakerGate(offerId: Hex, gate: Address): Promise<TxResult> {
    return this.tx('setTakerGate', (s) => {
      const o = s.offers.get(offerId.toLowerCase());
      if (!o || !sameAddress(o.lp, this.account)) throw new ChainRevert('NotLP');
      s.takerGates.set(offerId.toLowerCase(), gate);
      return [];
    });
  }

  async closeOffer(offerId: Hex): Promise<TxResult> {
    return this.tx('closeOffer', (s) => {
      const o = s.offers.get(offerId.toLowerCase());
      if (!o || !sameAddress(o.lp, this.account)) throw new ChainRevert('NotLP');
      const amount = o.availableWei;
      o.availableWei = 0n;
      o.active = false;
      const target = this.exposureOf(o);
      const held = s.offerExposure.get(offerId.toLowerCase()) ?? 0n;
      if (target < held) {
        s.exposureCents -= held - target;
        s.offerExposure.set(offerId.toLowerCase(), target);
      }
      this.credit_(s, o.asset, amount);
      return [];
    });
  }

  async issueBoleto(orderId: Hex, commitment: Hex): Promise<TxResult> {
    return this.tx('issueBoleto', (s, now) => {
      const ord = s.orders.get(orderId);
      const b = s.boletos.get(orderId);
      if (!ord || !sameAddress(s.offers.get(ord.offerId.toLowerCase())?.lp, this.account)) throw new ChainRevert('NotLP');
      if (ord.state !== OrderState.LOCKED || !b || b.issueBy === 0n || b.issuedAt !== 0n) throw new ChainRevert('WrongState');
      if (now > b.issueBy) throw new ChainRevert('WindowExpired');
      if (s.usedBoleto.has(commitment)) throw new ChainRevert('BadBoleto');
      s.usedBoleto.add(commitment);
      Object.assign(b, { commitment, issuedAt: now });
      ord.payBy = now + BOLETO_PAY_WINDOW;
      return [{ kind: 'touched', block: 0n, leg: 'onramp', id: orderId }];
    });
  }

  private async verify(orderId: Hex, verifier: Address, proof: Hex, escrow: Address) {
    const zk = this.zktls.get(verifier.toLowerCase());
    if (zk) return this.verifyZkTls(orderId, zk, proof, escrow);
    // A verifier that proves no bank session settles nothing: no offer or sale can name one (BankRailNeedsZkTls).
    throw new ChainRevert('UnknownVerifier');
  }

  /** ReclaimZkTlsVerifier.verifyPayment, check by check in the contract's order (not its byte-level JSON reader). */
  private async verifyZkTls(orderId: Hex, v: FakeZkTlsVerifier, bytes: Hex, escrow: Address) {
    let p: ReclaimProof;
    try {
      p = decodeProof(bytes);
    } catch {
      throw new ChainRevert('MalformedProof');
    }
    if (p.claimInfo.provider !== 'http') throw new ChainRevert('ProviderNotAllowed');
    if (claimIdentifier(p.claimInfo) !== p.signedClaim.claim.identifier.toLowerCase()) throw new ChainRevert('IdentifierMismatch');
    const sigs = p.signedClaim.signatures;
    if (sigs.length < v.threshold) throw new ChainRevert('NotEnoughSignatures');
    const digest = claimDigest(p.signedClaim.claim);
    let last = 0n;
    for (const signature of sigs) {
      const signer = await recoverAddress({ hash: digest, signature });
      if (!v.witnesses.has(signer.toLowerCase())) throw new ChainRevert('UnknownWitness');
      if (BigInt(signer) <= last) throw new ChainRevert('SignaturesUnsorted');
      last = BigInt(signer);
    }
    let endpoint: ReturnType<typeof proofEndpoint>;
    let pay: ReturnType<typeof proofPayment>;
    try {
      endpoint = proofEndpoint(p);
      pay = proofPayment(p);
    } catch {
      throw new ChainRevert('MissingField');
    }
    const allowed = v.endpoints.get(endpoint.providerHash.toLowerCase());
    if (!allowed) throw new ChainRevert('EndpointNotAllowed');
    if (!endpoint.url.startsWith(allowed.urlPrefix)) throw new ChainRevert('UrlNotAllowed');
    if (pay.orderId.toLowerCase() !== orderId.toLowerCase()) throw new ChainRevert('OrderMismatch');
    if (((allowed.railMask >> pay.rail) & 1) === 0) throw new ChainRevert('RailNotAllowedForEndpoint');
    if (allowed.requiresOrderTxid && pay.rail !== Rail.BOLETO) {
      if (pay.txid === undefined) throw new ChainRevert('MissingField');
      if (!isOrderTxid(pay.txid, this.chainId, escrow, orderId)) throw new ChainRevert('OrderTxidMismatch');
    }
    return {
      bankTxId: pay.bankTxId.toLowerCase() as Hex, payeeKeyHash: pay.payeeKeyHash.toLowerCase() as Hex,
      amountBrlCents: pay.amountBrlCents, paidAt: pay.paidAt, rail: Number(pay.rail),
    };
  }

  async releaseWithProof(orderId: Hex, proof: Hex): Promise<TxResult> {
    const ord0 = this.tip.state.orders.get(orderId);
    const off0 = ord0 && this.tip.state.offers.get(ord0.offerId.toLowerCase());
    const p = off0 ? await this.verify(orderId, off0.verifier, proof, ONRAMP) : undefined;
    return this.tx('releaseWithProof', (s, now) => {
      const ord = s.orders.get(orderId);
      const disputed = ord?.state === OrderState.DISPUTED;
      if (!ord || (ord.state !== OrderState.LOCKED && !disputed)) throw new ChainRevert('WrongState');
      const asOf = this.proofClock(s, orderId, disputed, ord.payBy, now);
      const o = s.offers.get(ord.offerId.toLowerCase())!;
      if (!s.allowedVerifiers.has(o.verifier.toLowerCase())) throw new ChainRevert('VerifierNotAllowed');
      const b = s.boletos.get(orderId);
      const boleto = !!b && b.issueBy !== 0n;
      if (boleto && b!.issuedAt === 0n) throw new ChainRevert('BoletoNotIssued');
      if (p!.payeeKeyHash !== (boleto ? b!.commitment : o.pixKeyHash)) throw new ChainRevert('WrongPayee');
      if (p!.amountBrlCents < ord.brlCents) throw new ChainRevert('Underpaid');
      if (boleto && p!.amountBrlCents !== ord.brlCents) throw new ChainRevert('WrongAmount');
      const mask = boleto ? BOLETO_BIT : o.railMask & ~BOLETO_BIT;
      if (p!.rail === 0 || !(mask & (1 << p!.rail))) throw new ChainRevert('RailNotAccepted');
      if (p!.paidAt < (boleto ? b!.issuedAt : ord.lockedAt)) throw new ChainRevert('ReceiptPredatesOrder');
      if (p!.paidAt > ord.payBy) throw new ChainRevert('WindowExpired');
      if (!boleto && p!.paidAt + ONRAMP_RECEIPT_MAX_AGE < asOf) throw new ChainRevert('ReceiptTooOld');
      if (s.usedBankTx.has(p!.bankTxId)) throw new ChainRevert('ReceiptReplayed');
      s.usedBankTx.add(p!.bankTxId);
      ord.state = OrderState.RELEASED;
      // A taker's dispute already took the order out of its offer (SRM1-4).
      if (!(disputed && s.disputes.get(orderId.toLowerCase())!.byTaker)) {
        o.lockedWei -= ord.weiAmount;
        this.releaseOfferExposure(s, ord.offerId, o);
      }
      return [{ kind: 'touched', block: 0n, leg: 'onramp', id: orderId }];
    });
  }

  async reclaimExpired(orderId: Hex): Promise<TxResult> {
    return this.tx('reclaimExpired', (s, now) => {
      const ord = s.orders.get(orderId);
      if (!ord || ord.state !== OrderState.LOCKED) throw new ChainRevert('WrongState');
      if (now <= ord.payBy) throw new ChainRevert('WindowStillOpen');
      this.unlock(s, ord);
      return [{ kind: 'touched', block: 0n, leg: 'onramp', id: orderId }];
    });
  }

  async claimSale(saleId: Hex): Promise<TxResult> {
    return this.tx('claimSale', (s, now) => {
      const sale = s.sales.get(saleId);
      if (!sale || sale.state !== SaleState.OPEN) throw new ChainRevert(sale?.state === SaleState.CLAIMED ? 'AlreadyClaimed' : 'WrongState');
      Object.assign(sale, { lp: this.account, claimedAt: now, payBy: now + OFFRAMP_PAY_WINDOW, state: SaleState.CLAIMED });
      this.reserve(s, sale.brlCents);
      return [{ kind: 'touched', block: 0n, leg: 'offramp', id: saleId }];
    });
  }

  async abandonClaim(saleId: Hex): Promise<TxResult> {
    return this.tx('abandonClaim', (s) => {
      const sale = s.sales.get(saleId);
      if (!sale || sale.state !== SaleState.CLAIMED) throw new ChainRevert('WrongState');
      if (!sameAddress(sale.lp, this.account)) throw new ChainRevert('NotClaimant');
      Object.assign(sale, { lp: NATIVE, payBy: 0n, state: SaleState.OPEN });
      s.exposureCents -= sale.brlCents;
      return [{ kind: 'SaleUnclaimed', block: 0n, saleId, lp: this.account }];
    });
  }

  async settleWithProof(saleId: Hex, proof: Hex): Promise<TxResult> {
    const sale0 = this.tip.state.sales.get(saleId);
    const p = sale0 ? await this.verify(saleId, sale0.verifier, proof, OFFRAMP) : undefined;
    return this.tx('settleWithProof', (s, now) => {
      const sale = s.sales.get(saleId);
      const disputed = sale?.state === SaleState.DISPUTED;
      if (!sale || (sale.state !== SaleState.CLAIMED && !disputed)) throw new ChainRevert('WrongState');
      const asOf = this.proofClock(s, saleId, disputed, sale.payBy, now);
      if (p!.payeeKeyHash !== sale.payeeKeyHash) throw new ChainRevert('WrongPayee');
      if (p!.amountBrlCents < sale.brlCents) throw new ChainRevert('Underpaid');
      if (p!.rail === Rail.BOLETO && p!.amountBrlCents !== sale.brlCents) throw new ChainRevert('WrongAmount');
      if (p!.rail === 0 || !(sale.railMask & (1 << p!.rail))) throw new ChainRevert('RailNotAccepted');
      if (s.usedBankTx.has(p!.bankTxId)) throw new ChainRevert('ReceiptReplayed');
      if (p!.paidAt < sale.claimedAt) throw new ChainRevert('ReceiptPredatesClaim');
      if (p!.paidAt > sale.payBy) throw new ChainRevert('WindowExpired');
      if (p!.paidAt + OFFRAMP_RECEIPT_MAX_AGE < asOf) throw new ChainRevert('ReceiptTooOld');
      s.usedBankTx.add(p!.bankTxId);
      sale.state = SaleState.SETTLED;
      s.exposureCents -= sale.brlCents;
      this.credit_(s, sale.asset, sale.weiAmount);
      return [{ kind: 'touched', block: 0n, leg: 'offramp', id: saleId }];
    });
  }

  /** The LP disputes: its credit stays reserved on either leg. */
  async raiseDispute(leg: Leg, id: Hex): Promise<TxResult> {
    return this.tx('raiseDispute', (s, now) => {
      if (leg === 'onramp') {
        const ord = s.orders.get(id);
        if (!ord || ord.state !== OrderState.LOCKED) throw new ChainRevert('WrongState');
        ord.state = OrderState.DISPUTED;
      } else {
        const sale = s.sales.get(id);
        if (!sale || sale.state !== SaleState.CLAIMED) throw new ChainRevert('WrongState');
        // H-04: the LP disputes an off-ramp sale only while its claim is live.
        if (now > sale.payBy) throw new ChainRevert('WindowExpired');
        sale.state = SaleState.DISPUTED;
      }
      s.disputes.set(id.toLowerCase(), { at: now, byTaker: false });
      return [{ kind: 'touched', block: 0n, leg, id }];
    });
  }

  async dispute(_leg: Leg, id: Hex): Promise<OnChainDispute> {
    const d = this.tip.state.disputes.get(id.toLowerCase());
    return d ? { disputedAt: d.at, deadline: deadlineOf(d) } : { disputedAt: 0n, deadline: 0n };
  }

  /*------------------------------ NodeRewards, as RewardsChain ------------------------------*/

  /** NodeRewards._owed: the pro-rata share, and what the cap lets through. */
  private rewardOwed(e: bigint): { share: bigint; pay: bigint } {
    const ep = this.rewards.epochs.get(e);
    if (!ep || ep.volume === 0n) return { share: 0n, pay: 0n };
    const share = (ep.budget * ep.lpVolume) / ep.volume;
    return { share, pay: share < ep.lpCap ? share : ep.lpCap };
  }

  async rewardsView(_rewards: Address, lookbackEpochs: number): Promise<RewardsView> {
    this.fault('rewardsView');
    const r = this.rewards;
    const back = BigInt(lookbackEpochs);
    const from = r.nextToFinalize > back ? r.nextToFinalize - back : 0n;
    const epochs: bigint[] = [];
    let claimable = 0n;
    for (let e = from; e < r.nextToFinalize; e++) {
      const ep = r.epochs.get(e);
      if (!ep || r.claimed.has(e) || ep.lpVolume === 0n) continue;
      const { share, pay } = this.rewardOwed(e);
      if (share === 0n) continue;
      epochs.push(e);
      claimable += pay;
    }
    return {
      registry: r.registry, excluded: r.excluded, currentEpoch: r.currentEpoch, nextToFinalize: r.nextToFinalize,
      finalizableEpochs: r.finalizable, tokenPerCent: r.tokenPerCent, currentVolumeCents: r.epochs.get(r.currentEpoch)?.lpVolume ?? 0n,
      claimable, epochs,
    };
  }

  async finalizeRewards(_rewards: Address, maxEpochs: bigint): Promise<TxResult> {
    return this.tx('finalizeRewards', () => {
      const n = maxEpochs < this.rewards.finalizable ? maxEpochs : this.rewards.finalizable;
      this.rewards.nextToFinalize += n;
      this.rewards.finalizable -= n;
      return [];
    });
  }

  async claimRewards(_rewards: Address, epochs: readonly bigint[], _to: Address): Promise<TxResult & { paid: bigint }> {
    const r = this.rewards;
    // NodeRewards.claim's refusals, in its order: the node must have simulated these away.
    for (const e of epochs) {
      if (e >= r.nextToFinalize) throw new ChainRevert('NotFinalized');
      if (r.claimed.has(e)) throw new ChainRevert('AlreadyClaimed');
      if (!r.epochs.get(e)?.lpVolume) throw new ChainRevert('NothingToClaim');
    }
    let paid = 0n;
    const res = this.tx('claimRewards', () => {
      for (const e of epochs) {
        paid += this.rewardOwed(e).pay;
        r.claimed.add(e);
      }
      r.paid += paid;
      return [];
    });
    return { ...res, paid };
  }

  /*------------------------------ the reserve, as GatewayChain ------------------------------*/

  /** MovvaReserve.mint, refusal by refusal in the contract's order; mutates only once nothing can refuse. */
  private applyMint(s: State, now: bigint, usdtIn: bigint, minOut: bigint): bigint {
    const r = s.reserve;
    if (!r.isGateway) throw new ChainRevert('NotGateway');
    if (!r.setupComplete) throw new ChainRevert('SetupIncomplete');
    if (r.mintPaused) throw new ChainRevert('MintIsPaused');
    if (usdtIn === 0n) throw new ChainRevert('ZeroAmount');
    if (r.frozen) throw new ChainRevert('FrozenByAssetIssuer');
    const rate = this.rateOf(s, now);
    if (ratioOf(r, rate) < r.minMintRatioBps) throw new ChainRevert('CollateralRatioTooLow');
    // _pull: TetherToken.transferFrom requires an unfrozen sender, and underflows on a short allowance.
    const ak = allowanceKey(USDT, RESERVE);
    const allowed = s.allowances.get(ak) ?? 0n;
    if (r.lpFrozen || allowed < usdtIn || this.bal(s, USDT) < usdtIn) throw new ChainRevert('SafeERC20FailedOperation');
    // N-27: the fee is USDT, paid out before anything is booked; Movva is minted for the rest.
    const fee = ceilDiv(usdtIn * r.mintFeeBps, BPS);
    const net = usdtIn - fee;
    const booked = net > r.vaultRounding ? net - r.vaultRounding : 0n;
    const out = (booked * rate) / USDT_UNIT;
    if (out === 0n || out < minOut) throw new ChainRevert('Slippage');
    if (r.supply + out > r.supplyCap) throw new ChainRevert('SupplyCapExceeded');
    s.allowances.set(ak, allowed - usdtIn);
    this.debit(s, USDT, usdtIn);
    this.credit_(s, MOVVA, out);
    r.totalUsdt += booked;
    r.liquidUsdt += booked;
    r.supply += out;
    return out;
  }

  /** MovvaReserve._redeemAmounts: what movvaIn is worth (min of par and pro rata), the USDT fee out of it (N-27). */
  private redeemAmounts(r: FakeReserve, movvaIn: bigint, rate: bigint): { usdtOut: bigint; fee: bigint } {
    if (r.supply === 0n) return { usdtOut: 0n, fee: 0n };
    const atPar = (movvaIn * USDT_UNIT) / rate;
    const proRata = (movvaIn * r.totalUsdt) / r.supply;
    const worth = atPar < proRata ? atPar : proRata;
    const fee = ceilDiv(worth * r.redeemFeeBps, BPS);
    return { usdtOut: worth - fee, fee };
  }

  /** MovvaReserve.redeem, likewise. */
  private applyRedeem(s: State, now: bigint, movvaIn: bigint, minOut: bigint): bigint {
    const r = s.reserve;
    if (!r.isGateway) throw new ChainRevert('NotGateway');
    if (!r.setupComplete) throw new ChainRevert('SetupIncomplete');
    if (movvaIn === 0n) throw new ChainRevert('ZeroAmount');
    if (r.lpFrozen) throw new ChainRevert('FrozenByAssetIssuer');
    const rate = this.rateOf(s, now);
    const { usdtOut, fee } = this.redeemAmounts(r, movvaIn, rate);
    if (usdtOut === 0n || usdtOut < minOut) throw new ChainRevert('Slippage');
    const ak = allowanceKey(MOVVA, RESERVE);
    const allowed = s.allowances.get(ak) ?? 0n;
    if (allowed < movvaIn) throw new ChainRevert('ERC20InsufficientAllowance');
    if (this.bal(s, MOVVA) < movvaIn) throw new ChainRevert('ERC20InsufficientBalance');
    if (r.liquidUsdt < usdtOut) throw new ChainRevert('InsufficientLiquidity');
    s.allowances.set(ak, allowed - movvaIn);
    this.debit(s, MOVVA, movvaIn);
    r.supply -= movvaIn; // every Movva redeemed is burned; the fee leaves in USDT (N-27)
    r.totalUsdt -= usdtOut + fee;
    r.liquidUsdt -= usdtOut + fee;
    this.credit_(s, USDT, usdtOut);
    return usdtOut;
  }

  /** What the contract would refuse now for any amount: the node must never have tried. */
  private refusals(kind: 'mint' | 'redeem'): string[] {
    const s = this.tip.state;
    const r = s.reserve;
    const out: string[] = [];
    if (!r.isGateway) out.push('not_gateway');
    if (!r.setupComplete) out.push('setup_incomplete');
    if (r.lpFrozen) out.push('lp_frozen');
    let rate: bigint | undefined;
    try {
      rate = this.rateOf(s, this.tip.timestamp);
    } catch {
      out.push('rate');
    }
    if (kind === 'mint') {
      if (r.mintPaused) out.push('mint_paused');
      if (r.frozen) out.push('reserve_frozen');
      if (rate !== undefined && ratioOf(r, rate) < r.minMintRatioBps) out.push('below_mint_ratio');
      if (r.supply >= r.supplyCap) out.push('supply_cap');
    } else if (rate !== undefined && ratioOf(r, rate) < BPS) {
      out.push('below_par');
    }
    return out;
  }

  private attempt(kind: 'mint' | 'redeem', phase: 'simulate' | 'send', amount: bigint, minOut: bigint, hash?: Hex): void {
    const s = this.tip.state;
    let rate = 0n;
    let expectedOut = 0n;
    try {
      rate = this.rateOf(s, this.tip.timestamp);
      if (kind === 'mint') {
        const net = amount - ceilDiv(amount * s.reserve.mintFeeBps, BPS);
        expectedOut = ((net > s.reserve.vaultRounding ? net - s.reserve.vaultRounding : 0n) * rate) / USDT_UNIT;
      } else {
        expectedOut = this.redeemAmounts(s.reserve, amount, rate).usdtOut;
      }
    } catch {
      // a stale rate: recorded as a refusal
    }
    let activeAvailable = 0n;
    for (const o of s.offers.values()) {
      if (o.active && sameAddress(o.lp, this.account) && sameAddress(o.asset, MOVVA)) activeAvailable += o.availableWei;
    }
    let last: bigint | undefined;
    for (const b of this.blocks) if (b.receipts.size > 0) last = b.number;
    this.attempts.push({
      kind, phase, amount, minOut, hash, refusals: this.refusals(kind), head: this.tip.number, time: this.tip.timestamp,
      walletMovva: this.bal(s, MOVVA), activeAvailable, expectedOut, rateE18: rate,
      mempoolGateway: this.mempool.length, lastGatewayReceiptBlock: last,
    });
  }

  async reserveView(_g: GatewayAddresses, at?: bigint): Promise<ReserveView> {
    this.fault('reserveView');
    if (this.reserveUnreadable) throw new Error('fetch failed');
    const s = this.at(at);
    const r = s.reserve;
    let rate: ReserveView['rate'];
    let collateralRatioBps: bigint | undefined;
    try {
      const e18 = this.rateOf(s, this.tip.timestamp);
      rate = { e18, updatedAt: r.rateUpdatedAt };
      collateralRatioBps = ratioOf(r, e18);
    } catch (e) {
      rate = { error: (e as ChainRevert).errorName };
    }
    let band: ReserveView['band'];
    try {
      const b = this.bandRateOf(s, this.tip.timestamp);
      band = { e18: b.e18, updatedAt: b.updatedAt, collateralRatioBps: ratioOf(r, b.e18) };
    } catch (e) {
      band = { error: (e as ChainRevert).errorName };
    }
    return {
      isGateway: r.isGateway, setupComplete: r.setupComplete, mintPaused: r.mintPaused, reserveFrozen: r.frozen, lpFrozen: r.lpFrozen,
      supply: r.supply, supplyCap: r.supplyCap, mintFeeBps: Number(r.mintFeeBps), redeemFeeBps: Number(r.redeemFeeBps),
      minMintCollateralRatioBps: Number(r.minMintRatioBps), totalUsdt: r.totalUsdt, liquidUsdt: r.liquidUsdt, rate, collateralRatioBps, band,
    };
  }

  async previewMint(_reserve: Address, usdtIn: bigint): Promise<{ movvaOut: bigint; fee: bigint }> {
    this.fault('previewMint');
    const r = this.tip.state.reserve;
    const fee = ceilDiv(usdtIn * r.mintFeeBps, BPS);
    return { movvaOut: ((usdtIn - fee) * this.rateOf(this.tip.state, this.tip.timestamp)) / USDT_UNIT, fee };
  }

  async previewRedeem(_reserve: Address, movvaIn: bigint): Promise<{ usdtOut: bigint; fee: bigint }> {
    this.fault('previewRedeem');
    return this.redeemAmounts(this.tip.state.reserve, movvaIn, this.rateOf(this.tip.state, this.tip.timestamp));
  }

  async allowance(token: Address, spender: Address): Promise<bigint> {
    return this.tip.state.allowances.get(allowanceKey(token, spender)) ?? 0n;
  }

  async approve(token: Address, spender: Address, amount: bigint): Promise<TxResult> {
    return this.tx('approve', (s) => {
      const k = allowanceKey(token, spender);
      const current = s.allowances.get(k) ?? 0n;
      // TetherToken.approve: require(!((_value != 0) && (allowed[msg.sender][_spender] != 0)))
      if (sameAddress(token, USDT) && amount !== 0n && current !== 0n) {
        this.approveQuirkHits++;
        throw new ChainRevert('reverted');
      }
      s.allowances.set(k, amount);
      return [];
    });
  }

  async nonces(confirmedBlock: bigint): Promise<{ confirmed: number; pending: number }> {
    this.fault('nonces');
    let pending = this.tip.state.lpNonce;
    const queued = new Set(this.mempool.map((p) => p.nonce));
    while (queued.has(pending)) pending++;
    return { confirmed: this.at(confirmedBlock).lpNonce, pending };
  }

  async simulateMint(_reserve: Address, usdtIn: bigint, minMovvaOut: bigint): Promise<void> {
    this.fault('simulateMint');
    this.attempt('mint', 'simulate', usdtIn, minMovvaOut);
    this.applyMint(structuredClone(this.tip.state), this.tip.timestamp, usdtIn, minMovvaOut);
  }

  async simulateRedeem(_reserve: Address, movvaIn: bigint, minUsdtOut: bigint): Promise<void> {
    this.fault('simulateRedeem');
    this.attempt('redeem', 'simulate', movvaIn, minUsdtOut);
    this.applyRedeem(structuredClone(this.tip.state), this.tip.timestamp, movvaIn, minUsdtOut);
  }

  private async send(kind: 'mint' | 'redeem', amount: bigint, minOut: bigint, nonce: number): Promise<Hex> {
    this.fault(kind === 'mint' ? 'sendMint' : 'sendRedeem');
    const { pending } = await this.nonces(this.tip.number);
    if (nonce !== pending) throw new Error(`nonce ${nonce} is not the account's next (${pending})`);
    // viem's writeContract estimates gas first: a transaction that would revert is refused before broadcast.
    if (kind === 'mint') this.applyMint(structuredClone(this.tip.state), this.tip.timestamp, amount, minOut);
    else this.applyRedeem(structuredClone(this.tip.state), this.tip.timestamp, amount, minOut);
    const hash = keccak256(toHex(`send:${this.fork}:${nonce}:${++this.sendSeq}`));
    this.attempt(kind, 'send', amount, minOut, hash);
    const cap = this.txPolicy.maxFeePerGasWei;
    this.mempool.push({ hash, nonce, kind, amount, minOut, maxFee: this.feeEstimate < cap ? this.feeEstimate : cap });
    const hook = this.onBroadcast;
    this.onBroadcast = undefined;
    hook?.();
    if (!this.holdSends) this.mine();
    if (this.loseNextSendResponse) {
      this.loseNextSendResponse = false;
      throw new Error('socket hang up');
    }
    return hash;
  }

  async sendMint(_reserve: Address, usdtIn: bigint, minMovvaOut: bigint, nonce: number): Promise<Hex> {
    return this.send('mint', usdtIn, minMovvaOut, nonce);
  }

  async sendRedeem(_reserve: Address, movvaIn: bigint, minUsdtOut: bigint, nonce: number): Promise<Hex> {
    return this.send('redeem', movvaIn, minUsdtOut, nonce);
  }

  get replaceAfterBlocks(): number {
    return this.txPolicy.replaceAfterBlocks;
  }

  reserveNonces(): void {}

  /** TxSender.replace, over the mempool: same nonce and payload, fee bumped by bumpBps, never past the cap. */
  async replace(hash: Hex): Promise<{ hash: Hex } | { capped: true } | { gone: true }> {
    this.fault('replace');
    const i = this.mempool.findIndex((p) => p.hash === hash);
    if (i < 0) return { gone: true };
    const p = this.mempool[i];
    const bumped = (p.maxFee * (10_000n + BigInt(this.txPolicy.bumpBps)) + 9_999n) / 10_000n;
    const want = bumped > this.feeEstimate ? bumped : this.feeEstimate;
    const fee = want < this.txPolicy.maxFeePerGasWei ? want : this.txPolicy.maxFeePerGasWei;
    if (fee * 10_000n < p.maxFee * 11_000n) return { capped: true };
    const next: PendingTx = { ...p, hash: keccak256(toHex(`replace:${this.fork}:${p.nonce}:${++this.sendSeq}`)), maxFee: fee };
    this.mempool.splice(i, 1, next);
    if (this.loseNextReplaceResponse) {
      this.loseNextReplaceResponse = false;
      throw new Error('socket hang up');
    }
    return { hash: next.hash };
  }

  async outcome(hash: Hex): Promise<TxOutcome> {
    this.fault('outcome');
    for (const b of this.blocks) {
      const r = b.receipts.get(hash.toLowerCase());
      if (r) return { state: 'mined', ok: r.ok, blockNumber: b.number, amountOut: r.amountOut };
    }
    return this.mempool.some((p) => p.hash === hash) ? { state: 'pending' } : { state: 'unknown' };
  }

}

/** The registry the harness's node is configured with, and the NodeRewards it claims from. */
export const REGISTRY: Address = '0x00000000000000000000000000000000000000e6';
export const REWARDS: Address = '0x000000000000000000000000000000000000a3a4';
