/**
 * The LP node against a PermissionlessLPRegistry, on anvil, with the real bytecode: the registry and the UNCHANGED
 * FiatEscrow and OffRampEscrow from the root build (`forge-out`), bound together; an LP bonds MOVVA with `join`; the
 * node - `LpNode` over the real `ViemRampChain`, exactly as bin/lp-node.ts wires it - reads `capOf` / `availableCents`
 * from the registry, decides it may quote, and posts an on-ramp offer sized to the bond's credit. Then the LP asks to
 * leave (`requestExit`): the registry's credit is 0 in that block, the node reads it, refuses to quote, and closes its
 * offer, which releases the exposure.
 *
 * Why it exists: the node read `setupComplete()` from the registry with every credit read, which the permissionless
 * registry does not have, so against one the node had no credit at all and quoted nothing (viem-chain.ts).
 *
 * The bond token is the kit's 18-decimal TestMovva (anyone may mint, MOVVA's transfer semantics); the oracle, the
 * verifier and the pool are the permissionless integration suite's stand-ins (PlrOracle at R$ 15.000,00 per ETH,
 * PlrVerifier proving the bank session, PlrPool as the nonzero pool addresses FiatEscrow's constructor requires).
 *
 * Without anvil (the pinned toolchain, or ANVIL) or without the artifacts the suite is skipped, as the other anvil
 * suites are; LP_NODE_ANVIL_REQUIRED=1 turns the skip into a failure. Port: LP_NODE_ANVIL_PORT, default 8956, and it
 * must be within 8955-8959 (this repository's anvil suites' range).
 */
import { spawn, type ChildProcess } from 'node:child_process';
import { existsSync, readFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import {
  createPublicClient, createWalletClient, defineChain, http, parseAbi, parseEther,
  type Abi, type Address, type Hex, type PublicClient,
} from 'viem';
import { privateKeyToAccount } from 'viem/accounts';
import { Rail } from '@mova/ramp';
import { MockBank } from '../src/bank.js';
import { NATIVE } from '../src/chain.js';
import { MemoryJournal } from '../src/journal.js';
import { LpNode } from '../src/node.js';
import type { PricePoint } from '../src/pricing.js';
import type { LpRecord } from '../src/store.js';
import { ViemRampChain } from '../src/viem-chain.js';

const ROOT = fileURLToPath(new URL('../../../', import.meta.url));
const OUT = resolve(ROOT, process.env.FOUNDRY_OUT ?? 'forge-out');
const PORT = Number(process.env.LP_NODE_ANVIL_PORT ?? 8956);
if (!(PORT >= 8955 && PORT <= 8959)) throw new Error(`LP_NODE_ANVIL_PORT must be in 8955-8959, got ${PORT}`);
const CHAIN_ID = 31_337;

const ARTIFACTS = {
  registry: ['PermissionlessLPRegistry.sol', 'PermissionlessLPRegistry'],
  onramp: ['FiatEscrow.sol', 'FiatEscrow'],
  offramp: ['OffRampEscrow.sol', 'OffRampEscrow'],
  movva: ['PermissionlessRegistryKit.sol', 'TestMovva'],
  oracle: ['PermissionlessRampIntegration.t.sol', 'PlrOracle'],
  verifier: ['PermissionlessRampIntegration.t.sol', 'PlrVerifier'],
  pool: ['PermissionlessRampIntegration.t.sol', 'PlrPool'],
  // The escrows link these (both sit near EIP-170, so the shared code is deployed once).
  rulingLib: ['RulingLib.sol', 'RulingLib'],
  safeTransferLib: ['SafeTransferLib.sol', 'SafeTransferLib'],
} as const;
const artifactPath = ([file, name]: readonly [string, string]) => join(OUT, file, `${name}.json`);

function anvilBinary(): string | undefined {
  if (process.env.ANVIL) return existsSync(process.env.ANVIL) ? process.env.ANVIL : undefined;
  try {
    const p = join(ROOT, '.foundry-pinned', readFileSync(join(ROOT, 'foundry-version'), 'utf8').trim(), 'anvil');
    return existsSync(p) ? p : undefined;
  } catch {
    return undefined;
  }
}

const ANVIL = anvilBinary();
const missing = [
  !ANVIL && 'anvil (bash scripts/foundry.sh, or ANVIL)',
  ...Object.values(ARTIFACTS).map(artifactPath).filter((p) => !existsSync(p)).map((p) => `${p} (forge build at the root)`),
].filter(Boolean);
if (missing.length > 0 && process.env.LP_NODE_ANVIL_REQUIRED === '1') throw new Error(`LP_NODE_ANVIL_REQUIRED=1, but missing: ${missing.join(', ')}`);

// anvil's development keys: #0 deploys and governs the escrows; #1 is the LP.
const deployer = privateKeyToAccount('0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80');
const lpKey = privateKeyToAccount('0x59c6995e998f97a5a0044966f0945389dc9e86dae88c7a8412f4603b6b78690d');

const chain = defineChain({
  id: CHAIN_ID, name: 'anvil', nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
  rpcUrls: { default: { http: [`http://127.0.0.1:${PORT}`] } },
});

const MIN_BOND = parseEther('5000');
const DAY = 86_400n;
const UNBONDING = 36n * DAY; // DISPUTE_TIMEOUT 30 days + ruling delay 1 + margin 4 + 1
const GOVERNANCE_DELAY = 48n * 3600n;
const DISPUTE_TIMEOUT = 30n * DAY;
/** FiatEscrow's TAKER_DISPUTE_TIMEOUT (H-04) and MAX_VETTING_FEE_BPS (H-02): the deploy scripts' defaults. */
const TAKER_DISPUTE_TIMEOUT = 5n * 24n * 3600n;
const MAX_VETTING_FEE_BPS = 10n;
const ORACLE_PRICE = 1_500_000n; // PlrOracle: R$ 15.000,00 per ETH

const REG = parseAbi([
  'function bindEscrows(address fiat, address offRamp)',
  'function join(uint256 amount)',
  'function requestExit()',
  'function capOf(address) view returns (uint256)',
  'function availableCents(address) view returns (uint256)',
  'function canQuote(address lp, uint256 brlCents) view returns (bool)',
  'function bonds(address) view returns (uint256 amount, uint256 exposureCents, uint256 settledCents, uint64 exitRequestedAt, uint32 settlements, uint32 disputesLost)',
  'function reservedBy(address escrow, address lp) view returns (uint256)',
  'function withdrawableFrom(address) view returns (uint256)',
]);
const ESCROW = parseAbi(['function setVerifier(address verifier, bool allowed)', 'function completeSetup()']);
const TOKEN = parseAbi(['function mint(address to, uint256 amount)', 'function approve(address spender, uint256 amount) returns (bool)']);

let anvil: ChildProcess | undefined;
let pub: PublicClient;
let addr: Record<keyof typeof ARTIFACTS, Address>;

const deployerWallet = () => createWalletClient({ account: deployer, chain, transport: http() });
const lpWallet = () => createWalletClient({ account: lpKey, chain, transport: http() });

/** Linked libraries deployed so far, by name. */
const libs: Record<string, Address> = {};

async function deploy(which: keyof typeof ARTIFACTS, args: unknown[]): Promise<Address> {
  const a = JSON.parse(readFileSync(artifactPath(ARTIFACTS[which]), 'utf8')) as {
    abi: Abi; bytecode: { object: Hex; linkReferences?: Record<string, Record<string, { start: number; length: number }[]>> };
  };
  let code = a.bytecode.object.slice(2);
  for (const byName of Object.values(a.bytecode.linkReferences ?? {})) {
    for (const [name, sites] of Object.entries(byName)) {
      const at = libs[name];
      if (!at) throw new Error(`${which} links ${name}, which is not deployed yet`);
      for (const { start, length } of sites) code = code.slice(0, start * 2) + at.slice(2).toLowerCase() + code.slice((start + length) * 2);
    }
  }
  const hash = await deployerWallet().deployContract({ abi: a.abi, bytecode: `0x${code}`, args: args as never });
  const r = await pub.waitForTransactionReceipt({ hash });
  if (r.status !== 'success' || !r.contractAddress) throw new Error(`${which} did not deploy`);
  return r.contractAddress;
}

async function send(w: ReturnType<typeof lpWallet>, to: Address, abi: Abi, functionName: string, args: unknown[] = []): Promise<void> {
  const hash = await w.writeContract({ address: to, abi, functionName, args } as never);
  const r = await pub.waitForTransactionReceipt({ hash });
  if (r.status !== 'success') throw new Error(`${functionName} reverted`);
}

const read = <T>(functionName: string, args: unknown[]) =>
  pub.readContract({ address: addr.registry, abi: REG, functionName, args } as never) as Promise<T>;

async function startChain(): Promise<void> {
  anvil = spawn(ANVIL!, ['--port', String(PORT), '--chain-id', String(CHAIN_ID), '--quiet'], { stdio: ['ignore', 'ignore', 'pipe'] });
  let stderr = '';
  anvil.stderr!.on('data', (d: Buffer) => { stderr += d.toString(); });
  pub = createPublicClient({ chain, transport: http() });
  const deadline = Date.now() + 20_000;
  for (;;) {
    if (anvil.exitCode !== null) throw new Error(`anvil exited (${anvil.exitCode}): ${stderr}`);
    try {
      await pub.getChainId();
      break;
    } catch {
      if (Date.now() > deadline) throw new Error(`anvil did not answer on port ${PORT}: ${stderr}`);
      await new Promise((r) => setTimeout(r, 100));
    }
  }

  const movva = await deploy('movva', [18]);
  const oracle = await deploy('oracle', []);
  const verifier = await deploy('verifier', []);
  const pool = await deploy('pool', []);
  const registry = await deploy('registry', [movva, '0x0000000000000000000000000000000000000000', MIN_BOND, UNBONDING, 1_000n]);
  libs.RulingLib = await deploy('rulingLib', []);
  libs.SafeTransferLib = await deploy('safeTransferLib', []);
  const onramp = await deploy('onramp', [oracle, registry, pool, pool, 500n, deployer.address, GOVERNANCE_DELAY, DISPUTE_TIMEOUT, TAKER_DISPUTE_TIMEOUT, MAX_VETTING_FEE_BPS]);
  const offramp = await deploy('offramp', [oracle, registry, 500n, deployer.address, GOVERNANCE_DELAY, DISPUTE_TIMEOUT]);
  addr = { movva, oracle, verifier, pool, registry, onramp, offramp, rulingLib: libs.RulingLib!, safeTransferLib: libs.SafeTransferLib! };
  const gov = deployerWallet();
  await send(gov, registry, REG, 'bindEscrows', [onramp, offramp]);
  for (const e of [onramp, offramp]) {
    await send(gov, e, ESCROW, 'setVerifier', [verifier, true]);
    await send(gov, e, ESCROW, 'completeSetup');
  }
  await send(gov, movva, TOKEN, 'mint', [lpKey.address, parseEther('10000')]);
}

/** The node as bin/lp-node.ts builds it, on-ramp only: the real chain adapter, a mock bank, a memory journal. */
async function makeNode(): Promise<{ node: LpNode; chain: ViemRampChain }> {
  const rampChain = new ViemRampChain({
    publicClient: pub, walletClient: lpWallet(), registry: addr.registry, onramp: addr.onramp, offramp: addr.offramp, receiptWaitMs: 20_000,
  });
  const now = () => BigInt(Math.floor(Date.now() / 1000));
  // A reference that agrees with the oracle, stamped now: the node's own feed check is not what this suite is about.
  const feed = { price: async (): Promise<PricePoint> => ({ price: ORACLE_PRICE, updatedAt: now() }) };
  const node = new LpNode({
    chain: rampChain, bank: new MockBank({ now }), journal: new MemoryJournal<LpRecord>(), confirmations: 1, reorgWindow: 12n,
    fromBlock: await pub.getBlockNumber(), payerRefSecret: `0x${'ab'.repeat(32)}`, lpPayerId: '12345678000195', wallClock: now,
    onramp: {
      escrow: addr.onramp, pixKey: 'liquidez@lp.example', receiver: { name: 'LP Liquidez Ltda', city: 'Sao Paulo' },
      reclaimExpired: true, autoRefund: true, boletoDueDays: 3, reorgWindow: 12n, lateCreditGraceSeconds: 3600,
      assets: [{
        asset: NATIVE, symbol: 'ETH', liquidity: parseEther('5'), minOrder: parseEther('0.01'), maxOrder: parseEther('2'),
        verifier: addr.verifier, rails: [Rail.PIX], refillBelowBps: 5_000, feed,
        pricing: {
          spreadBps: 100, minSpreadBps: 30, maxOracleDeviationBps: 200, bandMarginBps: 100, refreshDriftBps: 50,
          maxReferenceAgeSeconds: 120, oracleStaleMarginSeconds: 300,
        },
      }],
    },
  });
  return { node, chain: rampChain };
}

describe.skipIf(missing.length > 0)('the LP node on a PermissionlessLPRegistry (anvil, real bytecode)', () => {
  beforeAll(startChain, 120_000);
  afterAll(async () => {
    if (anvil && anvil.exitCode === null) {
      const exited = new Promise((r) => anvil!.once('exit', r));
      anvil.kill('SIGTERM');
      await exited;
    }
  });

  it('reads no credit before the LP bonds, and so quotes nothing', async () => {
    const { node, chain: c } = await makeNode();
    expect(await c.registryKindOf()).toBe('permissionless');
    expect(await c.credit()).toEqual({
      capCents: 0n, availableCents: 0n, setupComplete: true, registry: 'permissionless', bond: { amountWei: 0n, withdrawableFrom: 0n },
    });
    await node.tick();
    expect(node.offers!.status.get(NATIVE)).toMatchObject({ quoting: false, reason: 'not_eligible' });
  }, 60_000);

  it('bonds, quotes up to the bond, and stops the block the LP asks to leave', async () => {
    const lp = lpWallet();
    await send(lp, addr.movva, TOKEN, 'approve', [addr.registry, MIN_BOND]);
    await send(lp, addr.registry, REG, 'join', [MIN_BOND]);
    const cap = await read<bigint>('capOf', [lpKey.address]);
    expect(cap).toBe(450_000n); // 5.000 MOVVA = R$ 4.500,00 of credit, after the 10% haircut (L-03)
    expect(await read<boolean>('canQuote', [lpKey.address, cap])).toBe(true);

    const { node, chain: c } = await makeNode();
    expect(await c.credit()).toMatchObject({ capCents: 450_000n, availableCents: 450_000n, setupComplete: true, bond: { amountWei: MIN_BOND, withdrawableFrom: 0n } });
    await node.tick();
    const quoting = node.offers!.status.get(NATIVE)!;
    expect(quoting, JSON.stringify(quoting, (_k, v) => (typeof v === 'bigint' ? v.toString() : v))).toMatchObject({ quoting: true });
    // 5 ETH configured, but the bond's credit is what bounds it: R$ 5.000,00 at the node's ask buys about 0.33 ETH.
    const offer = await c.offer(quoting.activeOfferId!);
    expect(offer.active).toBe(true);
    const valueCents = (offer.availableWei * offer.priceBrlCentsPerEth + 10n ** 18n - 1n) / 10n ** 18n;
    expect(offer.availableWei).toBeLessThan(parseEther('1'));
    expect(valueCents).toBeLessThanOrEqual(cap);
    expect(valueCents).toBeGreaterThan(cap - 100n); // within a real of the whole credit
    const [, exposure] = await read<readonly [bigint, bigint]>('bonds', [lpKey.address]);
    expect(exposure).toBe(valueCents);
    expect(await read<bigint>('reservedBy', [addr.onramp, lpKey.address])).toBe(valueCents);
    expect(await read<boolean>('canQuote', [lpKey.address, cap])).toBe(false); // the offer holds it
    expect(node.status().credit).toMatchObject({ capCents: 450_000n, registry: 'permissionless' });

    await send(lp, addr.registry, REG, 'requestExit');
    expect(await read<bigint>('capOf', [lpKey.address])).toBe(0n);
    expect(await read<boolean>('canQuote', [lpKey.address, 1n])).toBe(false);
    const from = await read<bigint>('withdrawableFrom', [lpKey.address]);
    expect(from).toBeGreaterThan(0n);
    expect(await c.credit()).toMatchObject({ capCents: 0n, availableCents: 0n, bond: { amountWei: MIN_BOND, withdrawableFrom: from } });

    await node.tick();
    expect(node.offers!.status.get(NATIVE)).toMatchObject({ quoting: false, reason: 'not_eligible' });
    expect((await c.offer(quoting.activeOfferId!)).active).toBe(false);
    // Closing the offer released its reservation: nothing is live, so the bond is withdrawable once the period ends.
    expect((await read<readonly [bigint, bigint]>('bonds', [lpKey.address]))[1]).toBe(0n);
    expect(node.status().credit).toMatchObject({ capCents: 0n, bond: { withdrawableFrom: from } });
  }, 120_000);
});
