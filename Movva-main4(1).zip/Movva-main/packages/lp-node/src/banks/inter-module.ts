/**
 * Banco Inter as a `BANK_MODULE`: `createBankAdapter(env)` for `bin/lp-node.ts`.
 *
 *   BANK_MODULE=packages/lp-node/src/banks/inter-module.ts
 *   INTER_API_URL=https://cdpj.partners.bancointer.com.br        # or https://cdpj-sandbox.partners.uatinter.co
 *   INTER_CLIENT_ID=<client id of the integration>
 *   INTER_CLIENT_SECRET_FILE=/run/secrets/inter_client_secret
 *   INTER_CERT_FILE=/run/secrets/inter.crt                       # downloaded with the integration
 *   INTER_CERT_KEY_FILE=/run/secrets/inter.key
 *   INTER_STATE_PATH=/app/data/inter-bank.jsonl                  # the adapter's record of what it sent
 *   INTER_ACCOUNT=12345678                                       # optional: x-conta-corrente
 *   INTER_CA_FILE=...                                            # optional: a CA for Inter's server
 *   INTER_SCOPES="pagamento-pix.write ..."                       # optional: the scopes to request
 *   INTER_BOLETO_PAYER_FILE=/app/config/inter-boleto-payer.json  # optional: enables boleto registration
 *
 * ## Why it is strict
 *
 * The client secret and the certificate's private key move the LP's money, so they are read ONLY from
 * files (a mounted secret is not in `docker inspect`), and a module started with `INTER_CLIENT_SECRET`
 * or `INTER_CERT_KEY` in the environment refuses rather than guess which one the operator meant.
 * Every problem is collected before failing, naming variables and never their values.
 *
 * The node redacts what it knows - its environment's secret-shaped variables - but not what a plugin
 * reads from files, nor the access tokens it is issued. So every method of the returned adapter passes
 * its errors through `@mova/ops/redact` with those values (the secret, the key, each token issued, and
 * every secret-shaped variable in `env`) before the node, its logs or `/status` can see them.
 *
 * `INTER_STATE_PATH` is required: without the adapter's record, a boleto payment whose response was
 * lost could only be found by barcode, and a Pix accepted before a crash only by repeating it. It is
 * state like the node's journal - persistent, backed up, one process per file.
 *
 * And it must not go missing (v2.0 M-13). A repeated Pix whose first response was lost is absorbed only by
 * `x-id-idempotente`, whose behaviour on a repeat Inter does not document. So when this record is absent or
 * empty while the node's own journal (`STATE_FILE`) is not - the record was lost, moved or never restored - the
 * module refuses to start, rather than let the node repeat payouts the bank may already have made. Restore it
 * from the backup; or reconcile every pending payout in the Internet Banking and start once with
 * `INTER_STATE_RECONCILED=1`.
 *
 * The payer file holds the `pagador` Cobrança writes on every registered boleto (`cpfCnpj`,
 * `tipoPessoa`, `nome`, `endereco`, `cidade`, `uf`, `cep`, and optionally `bairro`, `numero`,
 * `complemento`, `email`, `ddd`, `telefone`). Whose data that is, is the LP's compliance decision.
 */
import { readFileSync } from 'node:fs';
import { redactError } from '@mova/ops/redact';
import type { BankAdapter } from '../bank.js';
import type { Env } from '../config.js';
import { JsonlJournal } from '../journal.js';
import { INTER_DEFAULT_SCOPES, InterClient, createInterBank, type InterBoletoPayer, type InterIndexRecord } from './inter.js';

const SECRET_NAME = /(KEY|SECRET|TOKEN|PASSWORD|CREDENTIAL)/i;
const PAYER_REQUIRED = ['cpfCnpj', 'tipoPessoa', 'nome', 'endereco', 'cidade', 'uf', 'cep'] as const;
const PAYER_OPTIONAL = ['bairro', 'numero', 'complemento', 'email', 'ddd', 'telefone'] as const;

export class InterModuleConfigError extends Error {
  constructor(readonly problems: string[]) {
    super(`refusing to create the Inter bank adapter:\n  - ${problems.join('\n  - ')}`);
  }
}

/** Every method's errors through `redact`, keeping an HTTP status when there is one. */
export function redactingBank(bank: BankAdapter, secrets: () => readonly string[]): BankAdapter {
  const out: Record<string, unknown> = {};
  for (const [name, fn] of Object.entries(bank)) {
    if (typeof fn !== 'function') continue;
    out[name] = async (...args: unknown[]) => {
      try {
        return await (fn as (...a: unknown[]) => Promise<unknown>)(...args);
      } catch (e) {
        const r = new Error(redactError(e, secrets())) as Error & { status?: number };
        if (e && typeof e === 'object' && typeof (e as { status?: unknown }).status === 'number') r.status = (e as { status: number }).status;
        throw r;
      }
    };
  }
  return out as unknown as BankAdapter;
}

/** A file's size through `readFile`, 0 when it is absent or unreadable. */
function sizeOf(readFile: (path: string) => Buffer, path: string): number {
  try {
    return readFile(path).length;
  } catch {
    return 0;
  }
}

export function createBankAdapter(env: Env, readFile: (path: string) => Buffer = (p) => readFileSync(p)): BankAdapter {
  const problems: string[] = [];
  const need = (name: string, what: string): string => {
    const v = env[name]?.trim();
    if (!v) problems.push(`${name} is required: ${what}`);
    return v ?? '';
  };
  const file = (name: string, what: string, optional = false): Buffer | undefined => {
    const path = env[`${name}_FILE`]?.trim();
    if (!path) {
      if (!optional) problems.push(`${name}_FILE is required: ${what}`);
      return undefined;
    }
    try {
      const b = readFile(path);
      if (b.length === 0) problems.push(`${name}_FILE is empty`);
      return b;
    } catch {
      problems.push(`${name}_FILE could not be read`);
      return undefined;
    }
  };

  for (const direct of ['INTER_CLIENT_SECRET', 'INTER_CERT_KEY']) {
    if (env[direct]?.trim()) problems.push(`${direct} must be read from ${direct}_FILE, not set in the environment`);
  }
  const apiUrl = need('INTER_API_URL', 'the Inter host (production or sandbox)');
  if (apiUrl) {
    try {
      const u = new URL(apiUrl);
      const loopback = ['127.0.0.1', 'localhost', '[::1]'].includes(u.hostname);
      if (u.protocol !== 'https:' && !(u.protocol === 'http:' && loopback)) problems.push('INTER_API_URL must be https');
      if (u.pathname.replace(/\/+$/, '') !== '' || u.search || u.username) problems.push('INTER_API_URL must be the host only; paths carry the API and version');
    } catch {
      problems.push('INTER_API_URL is not a URL');
    }
  }
  const clientId = need('INTER_CLIENT_ID', 'the client id of the integration');
  const clientSecret = file('INTER_CLIENT_SECRET', 'the client secret of the integration')?.toString('utf8').trim();
  const cert = file('INTER_CERT', 'the certificate downloaded with the integration (mTLS)');
  const key = file('INTER_CERT_KEY', 'the private key of that certificate');
  const ca = file('INTER_CA', '', true);
  const statePath = need('INTER_STATE_PATH', "the adapter's record of what it sent: persistent, one process per file");
  const nodeJournal = env.STATE_FILE?.trim();
  const reconciled = /^(1|true|yes)$/i.test(env.INTER_STATE_RECONCILED?.trim() ?? '');
  if (statePath && nodeJournal && !reconciled && sizeOf(readFile, nodeJournal) > 0 && sizeOf(readFile, statePath) === 0) {
    problems.push("INTER_STATE_PATH is missing or empty while the node's journal (STATE_FILE) is not: the adapter's record of "
      + 'what it sent was lost or moved, and a repeated Pix would rely on x-id-idempotente, which Inter does not document (M-13). '
      + 'Restore it from the backup, or reconcile every pending payout in the Internet Banking and start once with INTER_STATE_RECONCILED=1');
  }
  const account = env.INTER_ACCOUNT?.trim() || undefined;
  if (account && !/^[1-9]\d*$/.test(account)) problems.push('INTER_ACCOUNT must be the account digits with the check digit, no leading zeros');

  let payer: InterBoletoPayer | undefined;
  const payerRaw = file('INTER_BOLETO_PAYER', '', true);
  if (payerRaw) {
    try {
      const j = JSON.parse(payerRaw.toString('utf8')) as Record<string, unknown>;
      for (const f of PAYER_REQUIRED) if (typeof j[f] !== 'string' || !(j[f] as string).trim()) problems.push(`INTER_BOLETO_PAYER_FILE: ${f} is required`);
      if (j.tipoPessoa !== undefined && j.tipoPessoa !== 'FISICA' && j.tipoPessoa !== 'JURIDICA') problems.push('INTER_BOLETO_PAYER_FILE: tipoPessoa is FISICA or JURIDICA');
      const unknown = Object.keys(j).filter((k) => !(PAYER_REQUIRED as readonly string[]).includes(k) && !(PAYER_OPTIONAL as readonly string[]).includes(k));
      if (unknown.length) problems.push(`INTER_BOLETO_PAYER_FILE: unknown fields ${unknown.join(', ')}`);
      payer = j as unknown as InterBoletoPayer;
    } catch {
      problems.push('INTER_BOLETO_PAYER_FILE is not JSON');
    }
  }
  if (problems.length) throw new InterModuleConfigError(problems);

  const keyText = key!.toString('utf8');
  const tokens: string[] = [];
  const secrets = (): string[] => [
    clientSecret!, keyText, ...keyText.split(/\r?\n/).filter((l) => l.length >= 16 && !l.startsWith('-----')), ...tokens,
    ...Object.entries(env).filter(([k, v]) => SECRET_NAME.test(k) && !k.endsWith('_FILE') && !!v && v.length >= 8).map(([, v]) => v!),
  ];
  const scopes = env.INTER_SCOPES?.trim()
    ? env.INTER_SCOPES.trim().split(/\s+/)
    : INTER_DEFAULT_SCOPES.filter((s) => payer || !s.startsWith('boleto-cobranca.'));
  const client = new InterClient({
    baseUrl: apiUrl, clientId, clientSecret: clientSecret!, scopes, account, tls: { cert: cert!, key: key!, ca },
    onSecret: (t) => {
      tokens.push(t);
      if (tokens.length > 4) tokens.shift();
    },
  });
  const bank = createInterBank({ client, journal: new JsonlJournal<InterIndexRecord>(statePath), boletoPayer: payer });
  return redactingBank(bank, secrets);
}
