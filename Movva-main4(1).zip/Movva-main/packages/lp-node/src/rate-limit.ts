/**
 * Token buckets keyed by client address, for the counterparty routes (v2.0 L-14): taken before the body is parsed or
 * the chain read, so a flood of unsigned requests cannot spend the node's RPC budget. The number of buckets is
 * bounded: the oldest is evicted past `maxKeys`. The same bucket as the co-signer's (packages/cosigner rate-limit.ts).
 */
export class RateLimiter {
  private readonly buckets = new Map<string, { tokens: number; at: number }>();

  constructor(private readonly o: { burst: number; perMinute: number; now?: () => number; maxKeys?: number }) {
    if (!(o.burst >= 1) || !(o.perMinute > 0)) throw new Error('a rate limit needs a burst of at least 1 and a positive rate');
  }

  /** Take one token for `key`; false when none is left. */
  take(key: string): boolean {
    const now = this.o.now ? this.o.now() : Date.now();
    const b = this.buckets.get(key) ?? { tokens: this.o.burst, at: now };
    b.tokens = Math.min(this.o.burst, b.tokens + ((now - b.at) / 60_000) * this.o.perMinute);
    b.at = now;
    const ok = b.tokens >= 1;
    if (ok) b.tokens -= 1;
    this.buckets.delete(key);
    this.buckets.set(key, b);
    const max = this.o.maxKeys ?? 20_000;
    while (this.buckets.size > max) this.buckets.delete(this.buckets.keys().next().value as string);
    return ok;
  }
}

/** The client address: the socket's, or behind `hops` trusted proxies the X-Forwarded-For entry that many from the right. */
export function clientAddress(headers: Record<string, string | string[] | undefined>, socketAddress: string | undefined, hops: number): string {
  const forwarded = headers['x-forwarded-for'];
  if (hops > 0 && typeof forwarded === 'string' && forwarded.trim()) {
    const parts = forwarded.split(',').map((x) => x.trim()).filter(Boolean);
    const entry = parts[parts.length - hops];
    if (entry) return entry;
  }
  return socketAddress ?? 'unknown';
}
