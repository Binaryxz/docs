/**
 * The taker gate (v2.0 H-04): this node's half of `FiatEscrow.lockOrderGated`.
 *
 * A taker escrows nothing, so locking an order costs nothing, and an order locked and never paid holds an offer's
 * liquidity until it expires - or, disputed, until the taker's dispute times out. An offer with a taker gate takes
 * locks only with the gate's one-use approval, and this is the gate: it approves a lock for one taker, one amount, one
 * recipient and one rail, for `ttlSeconds`, and only within limits per taker - how many approvals an hour, and how many
 * orders open at once on this node's offers. Those limits are what the escrow cannot know.
 *
 * THE KEY is its own (`TAKER_GATE_KEY`), never the LP's: it signs approvals and nothing else, and the LP names it
 * on-chain per offer (`setTakerGate`), which this node does for every offer it posts. A leaked gate key lets someone
 * approve locks, which is what an ungated offer allows anyone; it cannot move funds.
 *
 * THE REQUEST is signed by the taker (EIP-712, ERC-1271 for a smart account), so a stranger cannot spend another
 * taker's allowance by asking in their name.
 */
import { encodeAbiParameters, keccak256, type Address, type Hex } from 'viem';
import { privateKeyToAccount, type PrivateKeyAccount } from 'viem/accounts';
import { OrderState } from './abi.js';
import type { RampChain } from './chain.js';
import { RateLimiter } from './rate-limit.js';
import type { Store } from './store.js';

export interface TakerGateOptions {
  /** The gate's private key: not the LP's. */
  key: Hex;
  /** How long an approval may be used. Default 120 s: the wallet asks just before it locks. */
  ttlSeconds?: number;
  /** Approvals per taker per hour. Default 6. */
  perTakerPerHour?: number;
  /** Orders a taker may have open (locked or disputed) on this node's offers at once, approvals outstanding included. Default 2. */
  maxOpenPerTaker?: number;
}

export const GATE_REQUEST_TYPES = {
  TakerGateRequest: [
    { name: 'offerId', type: 'bytes32' },
    { name: 'weiAmount', type: 'uint256' },
    { name: 'recipient', type: 'address' },
    { name: 'boleto', type: 'bool' },
    { name: 'issuedAt', type: 'uint64' },
  ],
} as const;

/**
 * What `RulingLib.gateApproval` recovers the gate from: the EIP-191 hash of keccak256(abi.encode("PrivacyPoolsBRL/
 * taker-gate/v1", chainid, escrow, offerId, taker, weiAmount, recipient, boleto, deadline)).
 */
export function takerGateMessage(a: {
  chainId: number; escrow: Address; offerId: Hex; taker: Address; weiAmount: bigint; recipient: Address; boleto: boolean; deadline: bigint;
}): Hex {
  return keccak256(encodeAbiParameters(
    [{ type: 'string' }, { type: 'uint256' }, { type: 'address' }, { type: 'bytes32' }, { type: 'address' }, { type: 'uint256' },
      { type: 'address' }, { type: 'bool' }, { type: 'uint64' }],
    ['PrivacyPoolsBRL/taker-gate/v1', BigInt(a.chainId), a.escrow, a.offerId, a.taker, a.weiAmount, a.recipient, a.boleto, a.deadline],
  ));
}

export class GateRefused extends Error {
  constructor(readonly status: number, readonly code: 'offer_not_gated' | 'gate_rate_limited' | 'gate_too_many_open' | 'bad_request', message: string) {
    super(message);
  }
}

export interface GateApproval {
  gate: Address;
  deadline: number;
  signature: Hex;
}

export class TakerGate {
  private readonly signer: PrivateKeyAccount;
  private readonly hourly: RateLimiter;
  /** Approvals handed out and not yet expired, by taker: an approval not yet used is an order that may be locked. */
  private readonly outstanding = new Map<string, number[]>();

  constructor(
    private readonly o: TakerGateOptions,
    private readonly ctx: { chain: RampChain; store: Store; now: () => number },
  ) {
    this.signer = privateKeyToAccount(o.key);
    const perHour = o.perTakerPerHour ?? 6;
    this.hourly = new RateLimiter({ burst: perHour, perMinute: perHour / 60, now: () => ctx.now() * 1000 });
  }

  get address(): Address {
    return this.signer.address;
  }

  /** One approval for one lock. Throws `GateRefused`. */
  async approve(req: { offerId: Hex; taker: Address; weiAmount: bigint; recipient: Address; boleto: boolean }): Promise<GateApproval> {
    const { chain } = this.ctx;
    if (!chain.onramp || !chain.takerGate) throw new GateRefused(404, 'offer_not_gated', 'this node runs no on-ramp');
    const gate = await chain.takerGate(req.offerId);
    if (gate.toLowerCase() !== this.address.toLowerCase()) {
      throw new GateRefused(409, 'offer_not_gated', 'that offer is not gated by this node\'s key: lock it without an approval, or ask its own node');
    }
    const now = this.ctx.now();
    const taker = req.taker.toLowerCase();
    const live = (this.outstanding.get(taker) ?? []).filter((d) => d >= now);
    const open = await this.openOrdersOf(req.taker);
    if (open + live.length >= (this.o.maxOpenPerTaker ?? 2)) {
      throw new GateRefused(429, 'gate_too_many_open', 'this taker already has as many orders open, or approved, as this LP allows: pay or cancel one first');
    }
    if (!this.hourly.take(taker)) throw new GateRefused(429, 'gate_rate_limited', 'this taker has asked for too many approvals this hour');
    const deadline = now + (this.o.ttlSeconds ?? 120);
    const signature = await this.signer.signMessage({
      message: {
        raw: takerGateMessage({
          chainId: chain.chainId, escrow: chain.onramp, offerId: req.offerId, taker: req.taker, weiAmount: req.weiAmount,
          recipient: req.recipient, boleto: req.boleto, deadline: BigInt(deadline),
        }),
      },
    });
    live.push(deadline);
    this.outstanding.set(taker, live);
    return { gate: this.address, deadline, signature };
  }

  /** Orders of this taker still open on this node's offers, as the chain says. */
  private async openOrdersOf(taker: Address): Promise<number> {
    let n = 0;
    for (const t of this.ctx.store.openOrders()) {
      const ord = await this.ctx.chain.order(t.orderId);
      if (ord.taker.toLowerCase() === taker.toLowerCase() && (ord.state === OrderState.LOCKED || ord.state === OrderState.DISPUTED)) n++;
    }
    return n;
  }
}
