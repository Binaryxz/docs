/**
 * The LP as a Movva gateway: it mints Movva from its own USDT to fund Movva offers, and redeems the
 * Movva it buys on the off-ramp back into USDT. Design: docs/movva.md; the contract:
 * contracts/movva/MovvaReserve.sol.
 *
 * ## What the reserve refuses, checked before anything is simulated
 *
 * `mint(usdtIn, to, minMovvaOut)` and `redeem(movvaIn, to, minUsdtOut)` are gateway-only. Mint refuses
 * while setup is open, while paused, while Tether has frozen the reserve, while a rate leg is stale,
 * under `minMintCollateralRatioBps`, past `supplyCap`, and below `minMovvaOut`. Redeem cannot be paused,
 * but pays only min(1, ratio) of par less `redeemFeeBps`, refuses a frozen payee, and reverts
 * `InsufficientLiquidity` when idle USDT plus what the yield vault releases falls short. Each of these
 * is read here first and reported by name (`mova_lp_gateway_blocked{op,reason}`, `/status`), so an
 * operator sees WHY the node is not minting instead of a revert. A read that fails is
 * `reserve_unreadable`, never a pass.
 *
 * ## When it mints: to a need, never ahead of one
 *
 * Only the offer manager asks (`fund`), with what the Movva offer would take now - its liquidity target
 * less what is posted, within credit and the offer cap - and only after it has a price it stands
 * behind. The mint covers that less the Movva already in the wallet, capped per mint, per day, by the
 * USDT the wallet may spend and by the reserve's supply headroom. Movva is minted because an offer
 * wanted it, and a mint exceeds the shortfall by at most one USDT base unit of rounding.
 * `minMovvaOut` is `previewMint` less `maxSlippageBps`: the rate can move between signing and
 * inclusion, and `mint` prices what the vault books, which can be a rounding unit under the preview.
 *
 * ## When it redeems: above the working balance, and not below par by default
 *
 * At the end of a tick - after sales settled and offers took what they needed - Movva in the wallet
 * above `keepMovva`, and above what the Movva offer wanted and could not post, is redeemed. While the
 * reserve would pay less than `minCollateralRatioBps` of par (default: 100%), the node holds instead.
 * Redeeming then turns a shortfall the ratio may recover from into a loss, and a gateway rushing the
 * exit is how a scare becomes a run. The hold is judged twice: on the ratio the reserve reports, and on
 * what `previewRedeem` would actually pay. It raises `mova_lp_gateway_held`, not an error.
 *
 * ## Off-hours: selling goes on, minting and redeeming wait
 *
 * The reserve's FX leg is Pyth's FX.USD/BRL, which trades weekdays 08:00-17:00 New York time; PIX never
 * closes. Mova decided (14 September 2026) that trading continues and value creation waits, and the
 * contracts say which reading is which: `brlPerUsdtE18` - what mint, redeem and their previews price at -
 * refuses a rate older than its limit at any hour (PythFxOracle `StaleRate`), while `bandBrlPerUsdtE18` and
 * the Movva band on the escrows take the last close while the market is closed. So a band that reads while
 * the rate does not IS the market closed (`marketClosed`, chain.ts), and then:
 *
 *  - neither mint nor redeem is planned: both report `market_closed`, and the gateway raises
 *    `mova_lp_gateway_held{reason="market_closed"}` - at info, not error, because a weekend is not an
 *    incident - with `mova_lp_gateway_market_closed` 1;
 *  - the Movva offer keeps being priced and posted, from the close: its cost at the band's rate, its
 *    oracle the escrow band itself (the reserve's `brlCentsPerUnit`, stamped current). It can only post what
 *    the wallet already holds, since nothing mints;
 *  - Movva sales are valued at the band's rate and ratio, and Movva bought meanwhile waits in the wallet;
 *  - when the market reopens and a keeper posts the day's first price, the rate reads again and the next
 *    tick mints and redeems as usual.
 *
 * A rate AND band both refused is not a closed market: it is a feed nobody keeps, and stays `rate_stale`.
 *
 * ## At most one transaction per intent
 *
 * A mint moves the LP's own money on-chain, and unlike an escrow write it is not safe to repeat after a
 * crash: the next plan cannot see a mint still in the mempool, and would mint for the same need again.
 *
 *  1. The intent - amounts, the need it serves, and the NONCE it will use, read BEFORE the balances it
 *     is sized from - is fsynced before anything is signed.
 *  2. The hash is fsynced the moment the node hands it back, before waiting for the receipt.
 *  3. An intent is final only once its outcome is `confirmations` deep. While one is open, nothing new
 *     is planned, mint or redeem.
 *
 * A transaction still unmined `replaceAfterBlocks` after it was sent is replaced at its nonce with bumped
 * fees, capped (tx-sender.ts): `gateway.replacing` is fsynced before the broadcast and the new hash after it,
 * so every hash that could mint for an intent is known - or the intent is marked as having one that is not.
 *
 * An open intent resolves from its receipts - any of its hashes - and otherwise from its nonce. Spent
 * at the confirmed block: nothing more can ever mine for it. Held pending: wait. Free: nothing this node
 * can see was broadcast, and the next transaction from this key takes that very nonce, so no copy of
 * the old one can mine beside it. A pending nonce BELOW the intent's is a gap the node cannot reason
 * about - the intent could still mine once it fills - so it holds for a human. Reading the nonce before
 * the balances closes the last window: a mint that lands in between makes the new send fail on its
 * nonce instead of minting twice. Approvals are not intents: the allowance is re-read before each plan,
 * and an allowance to the reserve can only be spent by this key's own mints.
 */
import { randomBytes } from 'node:crypto';
import { toHex, type Address, type Hex } from 'viem';
import { ChainRevert, marketClosed, type GatewayChain, type ReserveView } from './chain.js';
import { errorText, short, type NodeContext, type TickView } from './context.js';
import type { PriceFeed } from './price-feed.js';
import { deviationBps, mintCostCentsE18, redeemValueCentsE18, type CostQuote } from './pricing.js';
import type { GatewayOpKind, GatewayOpTrack, GatewayOutcome } from './store.js';

const BPS = 10_000n;
const USDT_UNIT = 1_000_000n;
const DAY = 86_400n;
/** Movva base units per centavo; also reais x 1e18 per centavo. */
const CENTS = 10n ** 16n;
const ceilDiv = (a: bigint, b: bigint) => (a === 0n ? 0n : (a - 1n) / b + 1n);

export interface GatewayMintPolicy {
  enabled: boolean;
  /** `minMovvaOut` = `previewMint` less this. At least 1: the preview ignores the vault's rounding. */
  maxSlippageBps: number;
  /** A shortfall that needs less USDT than this is not worth a mint. */
  minMintUsdt: bigint;
  maxMintUsdt: bigint;
  /** Over the trailing 24 hours of wall time, counting every mint that may have moved money. */
  maxMintUsdtPerDay: bigint;
  /** USDT the wallet keeps and never mints. */
  keepUsdt: bigint;
  /** Refuse to mint while the reserve charges more than this. */
  maxFeeBps: number;
  /** What the LP pays for USDT above the reserve's rate: its cost, for pricing Movva offers. */
  usdtCostBps: number;
}

export interface GatewayRedeemPolicy {
  enabled: boolean;
  /** The Movva working balance the wallet keeps. */
  keepMovva: bigint;
  minRedeemMovva: bigint;
  maxRedeemMovva: bigint;
  maxRedeemMovvaPerDay: bigint;
  maxSlippageBps: number;
  /** Hold while the reserve pays less than this share of par. 10_000: never below par. */
  minCollateralRatioBps: number;
  maxFeeBps: number;
  /** What the LP loses selling USDT for reais below the reserve's rate: for valuing Movva sales. */
  usdtSaleBps: number;
}

export interface GatewayOptions {
  reserve: Address;
  usdt: Address;
  movva: Address;
  mint: GatewayMintPolicy;
  redeem: GatewayRedeemPolicy;
  /**
   * The LP's own USDT price, centavos per whole USDT. With it, a reserve rate further than
   * `maxRateDeviationBps` from it stops both mint and redeem (a low rate under-mints the LP, a high one
   * under-pays its redemptions), and its cost and value use the worse of the two. Without it, the node
   * takes the reserve's rate - that is, the FX publishers' word - as the market.
   */
  usdtFeed?: PriceFeed;
  maxRateDeviationBps: number;
  maxReferenceAgeSeconds: number;
}

export type GatewayBlock =
  | 'disabled' | 'reserve_unreadable' | 'tx_pending' | 'nonce_gap'
  | 'not_gateway' | 'setup_incomplete' | 'mint_paused' | 'reserve_frozen' | 'lp_frozen'
  /** The FX market is closed: the rate is refused and the band reads the last close. See "Off-hours". */
  | 'market_closed'
  | 'rate_stale' | 'rate_unavailable' | 'reference_unavailable' | 'rate_deviates'
  /** The reserve's keyless breaker is halting mint and redeem because its price sources disagree; it clears itself. */
  | 'breaker_tripped'
  | 'below_mint_ratio' | 'supply_cap' | 'fee_too_high' | 'below_par'
  | 'daily_cap' | 'insufficient_usdt' | 'below_minimum' | 'insufficient_liquidity' | 'refused';

export const GATEWAY_BLOCKS: readonly GatewayBlock[] = [
  'disabled', 'reserve_unreadable', 'tx_pending', 'nonce_gap', 'not_gateway', 'setup_incomplete', 'mint_paused',
  'reserve_frozen', 'lp_frozen', 'market_closed', 'rate_stale', 'rate_unavailable', 'reference_unavailable', 'rate_deviates', 'breaker_tripped',
  'below_mint_ratio', 'supply_cap', 'fee_too_high', 'below_par', 'daily_cap', 'insufficient_usdt', 'below_minimum',
  'insufficient_liquidity', 'refused',
];

/** A rate refused for its age - the Chainlink leg's or the FX leg's - as opposed to refused for its value. */
const STALE_RATE = new Set(['StaleLeg', 'StaleRate']);

/** What the offer manager asks of the gateway, for its Movva asset. */
export interface OfferFunding {
  /** Bring the wallet's Movva up to `want` if the gateway can; returns once what it sent is mined. */
  fund(want: bigint, view: TickView): Promise<void>;
  /** What one whole Movva costs the LP to mint; undefined when minting is off. */
  offerCost(view: TickView): Promise<CostQuote | undefined>;
  /** Movva the offer wanted this tick and did not post: not to be redeemed from under it. */
  holdForOffers(amount: bigint): void;
}

/** What the off-ramp asks of it. */
export interface SaleValuation {
  /** What one whole Movva is worth redeemed; undefined when redeeming is off. */
  saleValue(view: TickView): Promise<CostQuote | undefined>;
}

/** Contract refusals, by error name, as the reason the node reports. */
const REFUSALS: Record<string, GatewayBlock> = {
  NotGateway: 'not_gateway', SetupIncomplete: 'setup_incomplete', MintIsPaused: 'mint_paused',
  StaleLeg: 'rate_stale', StaleRate: 'rate_stale', BadPrice: 'rate_unavailable', FxOutOfRange: 'rate_unavailable', LegFromFuture: 'rate_unavailable',
  UsdtUsdOutOfRange: 'rate_unavailable',
  FeedDecimalsOutOfRange: 'rate_unavailable', PriceRoundsToZero: 'rate_unavailable', NoPriceYet: 'rate_unavailable',
  ConfidenceTooWide: 'rate_unavailable', PriceFromFuture: 'rate_unavailable', ExponentOutOfRange: 'rate_unavailable',
  PriceFeedNotFound: 'rate_unavailable',
  // The DivergenceBreaker's own errors, bubbled through the reserve's call to it: a hold that clears when the sources agree.
  SourcesDiverge: 'breaker_tripped', SourceUnavailable: 'breaker_tripped',
  CollateralRatioTooLow: 'below_mint_ratio', SupplyCapExceeded: 'supply_cap', InsufficientLiquidity: 'insufficient_liquidity',
};

type MintPlan = { usdtIn: bigint; minOut: bigint; need: bigint; expectedOut: bigint } | { block: GatewayBlock } | { none: true };
type RedeemPlan = { movvaIn: bigint; minOut: bigint; need: bigint; expectedOut: bigint } | { block: GatewayBlock } | { none: true };

export class GatewayManager implements OfferFunding, SaleValuation {
  /** The reserve as last read this tick; `epoch` changes at each tick and after each send. */
  private snap?: { epoch: number; view?: ReserveView; refE18?: bigint; refAt?: bigint };
  private epoch = 0;
  private reservedForOffers = 0n;
  /** Refusals found while sizing this tick, on top of the standing checks. */
  private sizing: Record<GatewayOpKind, GatewayBlock[]> = { mint: [], redeem: [] };
  private held?: { reason: GatewayBlock; detail: string };
  /** Last tick's hold, so a hold is logged once when it starts and once when it clears. */
  private heldBefore?: GatewayBlock;
  private lastLogged: Record<GatewayOpKind, string> = { mint: '', redeem: '' };
  private survey_?: {
    at: string; balances?: { usdt: bigint; movva: bigint }; blocked: Record<GatewayOpKind, GatewayBlock[]>;
  };

  constructor(private readonly ctx: NodeContext, private readonly chain: GatewayChain, readonly o: GatewayOptions) {}

  /*//////////////////////////////////////////////////////////////
                                  TICK
  //////////////////////////////////////////////////////////////*/

  /** First in a tick, before any handler writes: settle what earlier ticks or a crashed process left open. */
  async begin(view: TickView): Promise<void> {
    this.epoch++;
    this.reservedForOffers = 0n;
    this.sizing = { mint: [], redeem: [] };
    this.held = undefined;
    await this.resolve(view);
  }

  /** Last in a tick: redeem what is above the working balance, then publish the state. */
  async tick(view: TickView): Promise<void> {
    try {
      await this.redeem(view);
    } finally {
      await this.survey(view);
    }
  }

  /*//////////////////////////////////////////////////////////////
                             OPEN INTENTS
  //////////////////////////////////////////////////////////////*/

  private async resolve(view: TickView): Promise<void> {
    const open = this.ctx.store.openGatewayOps();
    this.chain.reserveNonces(open.map((op) => op.nonce));
    if (open.length === 0) return;
    let nonces: { confirmed: number; pending: number } | undefined;
    for (const op of open) {
      if (op.txs.length > 0) {
        let pending = false;
        let mined: Extract<Awaited<ReturnType<GatewayChain['outcome']>>, { state: 'mined' }> | undefined;
        for (const tx of op.txs) {
          const out = await this.chain.outcome(tx, this.o.reserve, false);
          if (out.state === 'mined') { mined = out; break; }
          if (out.state === 'pending') pending = true;
        }
        if (mined) {
          // Final only N blocks deep: a reorg could still put it back in the mempool, or drop it.
          if (mined.blockNumber <= view.confirmedBlock) {
            this.finish(op, mined.ok ? 'MINED' : 'REVERTED', view, mined.amountOut, mined.blockNumber, mined.why);
          }
          continue;
        }
        if (pending) {
          await this.replaceIfStuck(op, view);
          continue;
        }
      }
      nonces ??= await this.chain.nonces(view.confirmedBlock);
      if (nonces.confirmed > op.nonce) {
        // The nonce is spent for good. With every hash known and none mined, by another transaction: this
        // intent never moved anything. With a hash never recorded, it may have been this one.
        this.finish(op, op.txs.length > 0 && !op.replacing ? 'DROPPED' : 'CONSUMED', view);
      } else if (nonces.pending > op.nonce) {
        continue; // something holds that nonce: in the mempool, or in a block not yet final
      } else if (nonces.pending === op.nonce) {
        this.finish(op, 'DROPPED', view);
      } else {
        this.hold('nonce_gap', `${op.op} ${short(op.opId)} was planned at nonce ${op.nonce} but the account's next nonce is `
          + `${nonces.pending}: a lower transaction was dropped and this one could still mine once the gap fills. `
          + 'Check the account\'s pending transactions; nothing new is minted or redeemed until it resolves');
      }
    }
  }

  /** Past `replaceAfterBlocks` unmined: the same transaction at the same nonce, fees bumped, capped. */
  private async replaceIfStuck(op: GatewayOpTrack, view: TickView): Promise<void> {
    const after = this.chain.replaceAfterBlocks;
    if (after <= 0 || op.sentBlock === undefined || view.head.number - op.sentBlock < BigInt(after)) return;
    const { store, metrics, log } = this.ctx;
    const from = op.txs[op.txs.length - 1];
    store.record({ t: 'gateway.replacing', opId: op.opId, from });
    const r = await this.chain.replace(from);
    if ('hash' in r) {
      store.record({ t: 'gateway.sent', opId: op.opId, tx: r.hash, block: view.head.number });
      metrics.inc('mova_lp_tx_replacements_total', { kind: 'gateway' });
      log.warn(`gateway: ${op.op} ${short(op.opId)} unmined for ${after}+ blocks: replaced ${short(from)} with ${short(r.hash)} at nonce ${op.nonce}`);
      return;
    }
    store.record({ t: 'gateway.replace.skipped', opId: op.opId, block: view.head.number, why: 'capped' in r ? 'capped' : 'gone' });
    if ('capped' in r) {
      metrics.inc('mova_lp_tx_fee_capped_total', { kind: 'gateway' });
      log.error(`gateway: ${op.op} ${short(op.opId)} is stuck at nonce ${op.nonce} and the fee cap allows no higher bump`);
    }
  }

  private finish(op: GatewayOpTrack, outcome: GatewayOutcome, view: TickView, amountOut?: bigint, block?: bigint, why?: string): void {
    const { store, metrics, log } = this.ctx;
    store.record({ t: 'gateway.result', opId: op.opId, outcome, amountOut, block });
    metrics.inc(op.op === 'mint' ? 'mova_lp_gateway_mints_total' : 'mova_lp_gateway_redeems_total', { outcome: outcome.toLowerCase() });
    if (outcome === 'MINED') {
      const out = amountOut ?? 0n;
      if (op.op === 'mint') {
        metrics.inc('mova_lp_gateway_usdt_minted_units_total', {}, Number(op.amountIn));
        metrics.inc('mova_lp_gateway_movva_minted_cents_total', {}, Number(out / CENTS));
        metrics.set('mova_lp_gateway_last_mint_timestamp_seconds', Number(view.wallNow));
      } else {
        metrics.inc('mova_lp_gateway_movva_redeemed_cents_total', {}, Number(op.amountIn / CENTS));
        metrics.inc('mova_lp_gateway_usdt_redeemed_units_total', {}, Number(out));
        metrics.set('mova_lp_gateway_last_redeem_timestamp_seconds', Number(view.wallNow));
      }
    }
    const line = `gateway: ${op.op} ${short(op.opId)} ${outcome}${op.tx ? ` (${short(op.tx)})` : ''}${why ? `: ${why}` : ''}`;
    if (outcome === 'MINED' || outcome === 'DROPPED') log.info(line);
    else log.warn(outcome === 'CONSUMED' ? `${line}: its nonce was spent before its hash was recorded; counted as if it moved` : line);
  }

  /*//////////////////////////////////////////////////////////////
                                READING
  //////////////////////////////////////////////////////////////*/

  private async read(): Promise<ReserveView | undefined> {
    if (this.snap?.epoch === this.epoch) return this.snap.view;
    const snap: NonNullable<typeof this.snap> = { epoch: this.epoch };
    this.snap = snap;
    try {
      snap.view = await this.chain.reserveView(this.o);
    } catch (e) {
      this.ctx.metrics.inc('mova_lp_tick_errors_total', { stage: 'gateway_read' });
      this.ctx.log.error(`gateway: reading the reserve: ${errorText(e)}`);
    }
    if (this.o.usdtFeed) {
      const p = await this.o.usdtFeed.price().catch(() => undefined);
      if (p && p.price > 0n) {
        snap.refE18 = p.price * CENTS;
        snap.refAt = p.updatedAt;
      }
    }
    return snap.view;
  }

  /** The LP's own USDT price in reais x 1e18, when fresh by wall clock. */
  private freshRef(view: TickView): bigint | undefined {
    const s = this.snap;
    if (s?.refE18 === undefined || s.refAt === undefined) return undefined;
    return view.wallNow > s.refAt + BigInt(this.o.maxReferenceAgeSeconds) ? undefined : s.refE18;
  }

  /** Every standing reason `op` cannot happen now, whatever its size. */
  private standing(op: GatewayOpKind, v: ReserveView | undefined, view: TickView): GatewayBlock[] {
    const out: GatewayBlock[] = [];
    if (!(op === 'mint' ? this.o.mint.enabled : this.o.redeem.enabled)) out.push('disabled');
    if (this.held?.reason === 'nonce_gap') out.push('nonce_gap');
    else if (this.ctx.store.openGatewayOps().length > 0) out.push('tx_pending');
    if (!v) {
      out.push('reserve_unreadable');
      return out;
    }
    if (!v.isGateway) out.push('not_gateway');
    if (!v.setupComplete) out.push('setup_incomplete');
    if (v.lpFrozen) out.push('lp_frozen');
    if ('error' in v.rate) {
      if (marketClosed(v)) out.push('market_closed');
      else out.push(STALE_RATE.has(v.rate.error) ? 'rate_stale' : 'rate_unavailable');
    } else if (this.o.usdtFeed) {
      const ref = this.freshRef(view);
      if (ref === undefined) out.push('reference_unavailable');
      else if (deviationBps(v.rate.e18, ref) > BigInt(this.o.maxRateDeviationBps)) out.push('rate_deviates');
    }
    if (op === 'mint') {
      if (v.mintPaused) out.push('mint_paused');
      if (v.reserveFrozen) out.push('reserve_frozen');
      if (v.collateralRatioBps !== undefined && v.collateralRatioBps < BigInt(v.minMintCollateralRatioBps)) out.push('below_mint_ratio');
      if (v.supply >= v.supplyCap) out.push('supply_cap');
      if (v.mintFeeBps > this.o.mint.maxFeeBps) out.push('fee_too_high');
    } else {
      if (v.redeemFeeBps > this.o.redeem.maxFeeBps) out.push('fee_too_high');
      if (v.collateralRatioBps !== undefined && v.collateralRatioBps < BigInt(this.o.redeem.minCollateralRatioBps)) out.push('below_par');
    }
    return out;
  }

  /** Mints and redemptions, by kind, that may have moved money within the last 24 hours. */
  private spentToday(kind: GatewayOpKind, view: TickView): bigint {
    let sum = 0n;
    for (const op of this.ctx.store.gatewayOps.values()) {
      if (op.op !== kind || op.wallAt + DAY <= view.wallNow) continue;
      const outcome = op.result?.outcome;
      if (outcome === 'DROPPED' || outcome === 'REVERTED') continue;
      sum += op.amountIn;
    }
    return sum;
  }

  /*//////////////////////////////////////////////////////////////
                                 PRICING
  //////////////////////////////////////////////////////////////*/

  /**
   * The rate and ratio a Movva offer or sale is priced at: the reserve's, or - while the FX market is closed - the
   * band's last close, which is what the escrows check Movva against meanwhile. Undefined when neither reads.
   */
  private pricingRate(v: ReserveView | undefined): { e18: bigint; collateralRatioBps: bigint } | undefined {
    if (!v) return undefined;
    if (!('error' in v.rate)) return v.collateralRatioBps === undefined ? undefined : { e18: v.rate.e18, collateralRatioBps: v.collateralRatioBps };
    return marketClosed(v) ? (v.band as { e18: bigint; collateralRatioBps: bigint }) : undefined;
  }

  async offerCost(view: TickView): Promise<CostQuote | undefined> {
    if (!this.o.mint.enabled) return undefined;
    const at = this.pricingRate(await this.read());
    const v = this.snap?.view;
    if (!at || !v) return { ok: false };
    let pay = at.e18;
    if (this.o.usdtFeed) {
      const ref = this.freshRef(view);
      if (ref === undefined) return { ok: false };
      if (ref > pay) pay = ref; // the worse of the two for a buyer of USDT
    }
    pay = ceilDiv(pay * (BPS + BigInt(this.o.mint.usdtCostBps)), BPS);
    return { ok: true, centsE18: mintCostCentsE18({ rateE18: at.e18, payRateE18: pay, mintFeeBps: v.mintFeeBps }) };
  }

  async saleValue(view: TickView): Promise<CostQuote | undefined> {
    if (!this.o.redeem.enabled) return undefined;
    const at = this.pricingRate(await this.read());
    const v = this.snap?.view;
    if (!at || !v) return { ok: false };
    // Movva the node could not redeem under its own policy has no redemption value to buy against. Off-hours it is
    // redeemed once the market reopens, at a rate nobody knows yet: the close is the best estimate there is.
    if (!v.isGateway || v.lpFrozen || v.redeemFeeBps > this.o.redeem.maxFeeBps
      || at.collateralRatioBps < BigInt(this.o.redeem.minCollateralRatioBps)) return { ok: false };
    let sell = at.e18;
    if (this.o.usdtFeed) {
      const ref = this.freshRef(view);
      if (ref === undefined) return { ok: false };
      if (ref < sell) sell = ref; // the worse of the two for a seller of USDT
    }
    sell = (sell * (BPS - BigInt(this.o.redeem.usdtSaleBps))) / BPS;
    return {
      ok: true,
      centsE18: redeemValueCentsE18({
        rateE18: at.e18, sellRateE18: sell, redeemFeeBps: v.redeemFeeBps, collateralRatioBps: at.collateralRatioBps,
      }),
    };
  }

  holdForOffers(amount: bigint): void {
    this.reservedForOffers = amount > 0n ? amount : 0n;
  }

  /*//////////////////////////////////////////////////////////////
                                 MINTING
  //////////////////////////////////////////////////////////////*/

  async fund(want: bigint, view: TickView): Promise<void> {
    if (want <= 0n) return;
    const { chain, o, ctx } = this;
    const v = await this.read();
    const standing = this.standing('mint', v, view);
    if (standing.length > 0 || !v) return this.refuse('mint', standing);

    const first = await this.sized(() => this.planMint(want, v, view));
    if (!('usdtIn' in first)) return 'block' in first ? this.refuse('mint', [first.block]) : undefined;
    await this.approveAtLeast(o.usdt, first.usdtIn);
    // The nonce BEFORE the balances the plan is sized from: see the header.
    const { pending: nonce } = await chain.nonces(view.confirmedBlock);
    const plan = await this.sized(() => this.planMint(want, v, view, first.usdtIn));
    if (!('usdtIn' in plan)) return 'block' in plan ? this.refuse('mint', [plan.block]) : undefined;

    try {
      await chain.simulateMint(o.reserve, plan.usdtIn, plan.minOut);
    } catch (e) {
      return this.refused('mint', e);
    }
    const opId = toHex(randomBytes(32));
    ctx.store.record({
      t: 'gateway.intent', opId, op: 'mint', amountIn: plan.usdtIn, minOut: plan.minOut, need: plan.need, nonce, wallAt: view.wallNow,
    });
    const hash = await chain.sendMint(o.reserve, plan.usdtIn, plan.minOut, nonce);
    ctx.store.record({ t: 'gateway.sent', opId, tx: hash, block: view.head.number });
    this.epoch++;
    ctx.log.info(`gateway: minting ${short(hash)}: ${plan.usdtIn} USDT units for ${plan.expectedOut} Movva units `
      + `(need ${plan.need}, at least ${plan.minOut})`);
    const out = await chain.outcome(hash, o.reserve, true);
    if (out.state === 'mined' && !out.ok) ctx.log.warn(`gateway: mint ${short(hash)} reverted at inclusion: ${out.why ?? 'unknown'}`);
  }

  /**
   * The USDT that mints the wallet up to `want`: the least whose USDT, after the fee the reserve takes in USDT
   * (v3.1 N-27), mints Movva covering the shortfall, then capped. A cap that leaves less than `minMintUsdt` is the
   * reason nothing is minted.
   */
  private async planMint(want: bigint, v: ReserveView, view: TickView, approved?: bigint): Promise<MintPlan> {
    const { chain, o } = this;
    if ('error' in v.rate) return { block: 'rate_unavailable' };
    const [movva, usdt] = await Promise.all([chain.balance(o.movva), chain.balance(o.usdt)]);
    if (movva >= want) return { none: true };
    const need = want - movva;
    const rate = v.rate.e18;
    const fee = BigInt(v.mintFeeBps);
    const net = ceilDiv(need * USDT_UNIT, rate);
    let usdtIn = ceilDiv(net * BPS, BPS - fee);
    while (usdtIn - ceilDiv(usdtIn * fee, BPS) < net) usdtIn++;

    let binding: GatewayBlock = 'below_minimum';
    const cap = (limit: bigint, why: GatewayBlock) => {
      if (limit < usdtIn) {
        usdtIn = limit > 0n ? limit : 0n;
        binding = why;
      }
    };
    cap(o.mint.maxMintUsdt, 'below_minimum'); // a partial mint, not a refusal
    cap(o.mint.maxMintUsdtPerDay - this.spentToday('mint', view), 'daily_cap');
    cap(usdt - o.mint.keepUsdt, 'insufficient_usdt');
    // Movva minted is at most floor(usdtIn x rate / 1e6), the fee taken first, so this much USDT never mints past the cap.
    cap(((v.supplyCap - v.supply) * USDT_UNIT) / rate, 'supply_cap');
    if (approved !== undefined) cap(approved, binding);
    if (usdtIn === 0n || usdtIn < o.mint.minMintUsdt) return { block: binding };

    const preview = await chain.previewMint(o.reserve, usdtIn);
    if (preview.movvaOut === 0n) return { block: 'below_minimum' };
    // The reserve's own arithmetic decides the cap, not this plan's: refuse rather than send a revert.
    if (v.supply + preview.movvaOut > v.supplyCap) return { block: 'supply_cap' };
    const minOut = (preview.movvaOut * (BPS - BigInt(o.mint.maxSlippageBps))) / BPS;
    return { usdtIn, minOut, need, expectedOut: preview.movvaOut };
  }

  /*//////////////////////////////////////////////////////////////
                                REDEEMING
  //////////////////////////////////////////////////////////////*/

  private keep(): bigint {
    return this.o.redeem.keepMovva > this.reservedForOffers ? this.o.redeem.keepMovva : this.reservedForOffers;
  }

  private async redeem(view: TickView): Promise<void> {
    const { chain, o, ctx } = this;
    const v = await this.read();
    // Whatever there is to redeem or mint, it waits for the market; a nonce gap stays the hold a human must see.
    if (marketClosed(v) && this.held?.reason !== 'nonce_gap') this.holdMarketClosed(v!);
    const movva = await chain.balance(o.movva);
    const excess = movva > this.keep() ? movva - this.keep() : 0n;
    if (excess === 0n || excess < o.redeem.minRedeemMovva) return; // nothing worth a transaction

    const standing = this.standing('redeem', v, view);
    if (standing.includes('below_par')) this.holdBelowPar(v);
    if (standing.length > 0 || !v) return this.refuse('redeem', standing);

    const first = await this.sized(() => this.planRedeem(excess, v, view));
    if (!('movvaIn' in first)) {
      if ('block' in first && first.block === 'below_par') this.holdBelowPar(v);
      return 'block' in first ? this.refuse('redeem', [first.block]) : undefined;
    }
    await this.approveAtLeast(o.movva, first.movvaIn);
    const { pending: nonce } = await chain.nonces(view.confirmedBlock);
    const now = await chain.balance(o.movva);
    // Re-read after the approval: the wallet must still hold what was planned, above the working balance.
    if (now < this.keep() + first.movvaIn) return;
    const plan = first;

    try {
      await chain.simulateRedeem(o.reserve, plan.movvaIn, plan.minOut);
    } catch (e) {
      return this.refused('redeem', e);
    }
    const opId = toHex(randomBytes(32));
    ctx.store.record({
      t: 'gateway.intent', opId, op: 'redeem', amountIn: plan.movvaIn, minOut: plan.minOut, need: plan.need, nonce, wallAt: view.wallNow,
    });
    const hash = await chain.sendRedeem(o.reserve, plan.movvaIn, plan.minOut, nonce);
    ctx.store.record({ t: 'gateway.sent', opId, tx: hash, block: view.head.number });
    this.epoch++;
    ctx.log.info(`gateway: redeeming ${short(hash)}: ${plan.movvaIn} Movva units for ${plan.expectedOut} USDT units (at least ${plan.minOut})`);
    const out = await chain.outcome(hash, o.reserve, true);
    if (out.state === 'mined' && !out.ok) ctx.log.warn(`gateway: redemption ${short(hash)} reverted at inclusion: ${out.why ?? 'unknown'}`);
  }

  private async planRedeem(excess: bigint, v: ReserveView, view: TickView): Promise<RedeemPlan> {
    const { chain, o } = this;
    if ('error' in v.rate) return { block: 'rate_unavailable' };
    let movvaIn = excess < o.redeem.maxRedeemMovva ? excess : o.redeem.maxRedeemMovva;
    const left = o.redeem.maxRedeemMovvaPerDay - this.spentToday('redeem', view);
    if (left < movvaIn) movvaIn = left > 0n ? left : 0n;
    if (movvaIn === 0n || movvaIn < o.redeem.minRedeemMovva) return { block: 'daily_cap' };

    let preview = await chain.previewRedeem(o.reserve, movvaIn);
    // Judged on what the reserve would pay, not only on the ratio it reports: at or above par the Movva is worth
    // exactly movvaIn / rate, of which the USDT fee is taken (N-27), and anything less (a unit of pro-rata rounding
    // aside) is a haircut.
    const floorBps = BigInt(o.redeem.minCollateralRatioBps) < BPS ? BigInt(o.redeem.minCollateralRatioBps) : BPS;
    const par = (movvaIn * USDT_UNIT) / v.rate.e18;
    if ((preview.usdtOut + preview.fee + 1n) * BPS < par * floorBps) return { block: 'below_par' };

    if (preview.usdtOut > v.liquidUsdt) {
      // Take what the reserve can pay now; the rest waits for the vault's liquidity.
      movvaIn = (movvaIn * v.liquidUsdt) / preview.usdtOut;
      if (movvaIn === 0n || movvaIn < o.redeem.minRedeemMovva) return { block: 'insufficient_liquidity' };
      preview = await chain.previewRedeem(o.reserve, movvaIn);
      if (preview.usdtOut > v.liquidUsdt) return { block: 'insufficient_liquidity' };
    }
    const minOut = (preview.usdtOut * (BPS - BigInt(o.redeem.maxSlippageBps))) / BPS;
    if (preview.usdtOut === 0n || minOut === 0n) return { block: 'below_minimum' };
    return { movvaIn, minOut, need: excess, expectedOut: preview.usdtOut };
  }

  /*//////////////////////////////////////////////////////////////
                                 HELPERS
  //////////////////////////////////////////////////////////////*/

  /** USDT refuses to move a non-zero allowance to another non-zero value (TetherToken.approve): zero first. */
  private async approveAtLeast(token: Address, amount: bigint): Promise<void> {
    const current = await this.chain.allowance(token, this.o.reserve);
    if (current >= amount) return;
    if (current > 0n) await this.chain.approve(token, this.o.reserve, 0n);
    await this.chain.approve(token, this.o.reserve, amount);
  }

  /** A preview that reverts (the rate went stale since the view) is a refusal, not a crash. */
  private async sized<T>(plan: () => Promise<T | { block: GatewayBlock }>): Promise<T | { block: GatewayBlock }> {
    try {
      return await plan();
    } catch (e) {
      if (!(e instanceof ChainRevert)) throw e;
      return { block: REFUSALS[e.errorName] ?? 'refused' };
    }
  }

  private refused(op: GatewayOpKind, e: unknown): void {
    if (!(e instanceof ChainRevert)) throw e;
    let reason = REFUSALS[e.errorName] ?? 'refused';
    if (e.errorName === 'FrozenByAssetIssuer') reason = op === 'mint' ? 'reserve_frozen' : 'lp_frozen';
    this.ctx.log.warn(`gateway: the reserve refused the ${op} in simulation (${e.errorName}); nothing was sent`);
    this.refuse(op, [reason]);
  }

  private refuse(op: GatewayOpKind, blocks: GatewayBlock[]): void {
    for (const b of blocks) if (!this.sizing[op].includes(b)) this.sizing[op].push(b);
    const key = blocks.join(',');
    if (this.lastLogged[op] !== key) {
      this.lastLogged[op] = key;
      this.ctx.log.warn(`gateway: not ${op === 'mint' ? 'minting' : 'redeeming'} (${key})`);
    }
  }

  private holdBelowPar(v: ReserveView | undefined): void {
    this.hold('below_par', `holding Movva: the reserve is at ${v?.collateralRatioBps ?? '?'} bps and would pay under `
      + `${this.o.redeem.minCollateralRatioBps} bps of par; redeeming now would take the haircut`);
  }

  private holdMarketClosed(v: ReserveView): void {
    const rateError = 'error' in v.rate ? v.rate.error : '?';
    const close = v.band && !('error' in v.band) ? `R$ ${Number(v.band.e18 / 10n ** 12n) / 1e6}` : '?';
    this.hold('market_closed', `the FX market is closed: the reserve refuses its rate (${rateError}) and its band reads the `
      + `last close, ${close} per USDT. Minting and redeeming wait for the market to reopen; the Movva offer keeps selling `
      + 'what the wallet holds, priced from the close');
  }

  private hold(reason: GatewayBlock, detail: string): void {
    if (this.held?.reason !== reason && this.heldBefore !== reason) {
      // A closed market is the calendar, not an incident.
      if (reason === 'market_closed') this.ctx.log.info(`gateway: waiting: ${detail}`);
      else this.ctx.log.error(`gateway: HOLD: ${detail}`);
    }
    this.held = { reason, detail };
  }

  /** Metrics and /status, from the standing checks plus whatever sizing refused this tick. */
  private async survey(view: TickView): Promise<void> {
    const { metrics, store } = this.ctx;
    const { chain } = this;
    const v = await this.read();
    let balances: { usdt: bigint; movva: bigint } | undefined;
    try {
      const [usdt, movva] = await Promise.all([chain.balance(this.o.usdt), chain.balance(this.o.movva)]);
      balances = { usdt, movva };
      metrics.set('mova_lp_gateway_usdt_balance_units', Number(usdt));
      metrics.set('mova_lp_gateway_movva_balance_cents', Number(movva / CENTS));
    } catch (e) {
      this.ctx.log.error(`gateway: reading balances: ${errorText(e)}`);
    }
    const blocked: Record<GatewayOpKind, GatewayBlock[]> = { mint: [], redeem: [] };
    metrics.reset('mova_lp_gateway_blocked');
    for (const op of ['mint', 'redeem'] as const) {
      for (const b of [...this.standing(op, v, view), ...this.sizing[op]]) if (!blocked[op].includes(b)) blocked[op].push(b);
      for (const b of blocked[op]) metrics.set('mova_lp_gateway_blocked', 1, { op, reason: b });
    }
    metrics.reset('mova_lp_gateway_held');
    if (this.held) metrics.set('mova_lp_gateway_held', 1, { reason: this.held.reason });
    else if (this.heldBefore) this.ctx.log.info(`gateway: no longer holding (${this.heldBefore})`);
    this.heldBefore = this.held?.reason;
    metrics.set('mova_lp_gateway_pending', store.openGatewayOps().length);
    const readable = !!v && !('error' in v.rate);
    metrics.set('mova_lp_gateway_rate_readable', readable ? 1 : 0);
    metrics.set('mova_lp_gateway_market_closed', marketClosed(v) ? 1 : 0);
    if (v?.collateralRatioBps !== undefined) {
      metrics.set('mova_lp_gateway_collateral_ratio_bps', Number(v.collateralRatioBps > 1_000_000n ? 1_000_000n : v.collateralRatioBps));
    }
    this.survey_ = { at: new Date().toISOString(), balances, blocked };
  }

  /** On-chain facts, amounts and reasons only: nothing here is a secret. */
  status(): Record<string, unknown> {
    const s = this.survey_;
    const v = this.snap?.view;
    const ops = [...this.ctx.store.gatewayOps.values()];
    const last = (kind: GatewayOpKind) => {
      const op = ops.filter((x) => x.op === kind && x.result?.outcome === 'MINED').at(-1);
      return op ? {
        tx: op.tx ?? null, amountIn: op.amountIn, amountOut: op.result!.amountOut ?? null, block: op.result!.block ?? null,
        at: new Date(op.result!.at).toISOString(),
      } : null;
    };
    return {
      reserve: this.o.reserve, usdt: this.o.usdt, movva: this.o.movva,
      surveyedAt: s?.at ?? null,
      /** The FX market as the reserve shows it; null before the reserve was read. */
      market: v ? (marketClosed(v) ? 'closed' : 'error' in v.rate ? 'unreadable' : 'open') : null,
      mint: {
        enabled: this.o.mint.enabled, canMint: !!s && s.blocked.mint.length === 0, blocked: s?.blocked.mint ?? null,
        last: last('mint'),
      },
      redeem: {
        enabled: this.o.redeem.enabled, canRedeem: !!s && s.blocked.redeem.length === 0, blocked: s?.blocked.redeem ?? null,
        held: this.held ? { reason: this.held.reason, detail: this.held.detail } : null, last: last('redeem'),
        keepMovva: this.o.redeem.keepMovva,
      },
      balances: s?.balances ?? null,
      reserveState: v ? {
        collateralRatioBps: v.collateralRatioBps ?? null,
        rate: 'error' in v.rate ? { error: v.rate.error } : { brlPerUsdtE18: v.rate.e18, updatedAt: v.rate.updatedAt },
        band: !v.band ? null : 'error' in v.band ? { error: v.band.error }
          : { brlPerUsdtE18: v.band.e18, updatedAt: v.band.updatedAt, collateralRatioBps: v.band.collateralRatioBps },
        isGateway: v.isGateway, mintPaused: v.mintPaused, reserveFrozen: v.reserveFrozen, lpFrozen: v.lpFrozen,
        supply: v.supply, supplyCap: v.supplyCap, mintFeeBps: v.mintFeeBps, redeemFeeBps: v.redeemFeeBps,
        liquidUsdt: v.liquidUsdt,
      } : null,
      pending: this.ctx.store.openGatewayOps().map((op) => ({
        opId: op.opId, op: op.op, amountIn: op.amountIn, nonce: op.nonce, tx: op.tx ?? null,
      })),
    };
  }
}
