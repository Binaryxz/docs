/**
 * The contract surface the LP node uses, and nothing more.
 *
 * Transcribed from contracts/ramp/FiatEscrow.sol, OffRampEscrow.sol, LPRegistry.sol and
 * IPriceOracle.sol rather than loaded from forge artifacts: the production image carries no
 * `forge-out`, and a daemon that holds an LP's key should not resolve its ABI from whatever
 * build directory happens to be on disk. The cost of transcription is drift, so
 * `test/abi.test.ts` compares every selector, event topic and getter layout here against the
 * compiled artifacts whenever they are present, and `examples/lp-node-live.ts` drives the node
 * against contracts deployed from those artifacts.
 *
 * Getter outputs are positional. `offers`, `orders` and `sales` are decoded by index, and an
 * earlier change to `Sale` (adding `asset`) shifted every field after it - which is exactly
 * the kind of change a hand-written tuple does not survive silently. The artifact test pins
 * the output types in order.
 *
 * Every custom error both escrows can raise is listed, so a simulated revert decodes to a name
 * (`StalePrice`, `LPNotEligible`, `WindowExpired`) the node can act on, instead of raw bytes.
 */
import { parseAbi } from 'viem';

/**
 * PythFxOracle's refusals: the FX leg's, surfaced through anything that reads it - the reserve's rate and
 * previews, and, through ScaledFxBandOracle and a ChainlinkSignedFxOracle, an escrow's band check. `StaleRate` is
 * the one that matters most: it is the reserve refusing to mint or redeem while the FX market is closed.
 * `PriceFeedNotFound` is Pyth's own, before the feed has ever been posted on this chain.
 */
const PYTH_FX_ERRORS = [
  'error StaleRate(uint256 publishTime)',
  'error ConfidenceTooWide(uint64 conf, int64 price)',
  'error PriceFromFuture(uint256 publishTime)',
  'error ExponentOutOfRange(int32 expo)',
  'error BadPrice(int64 price)',
  'error PriceFeedNotFound()',
] as const;

/** ReclaimZkTlsVerifier's refusals, surfaced through `verifyPayment` in a release or a settlement. */
const ZKTLS_VERIFIER_ERRORS = [
  'error IdentifierMismatch()',
  'error ProviderNotAllowed()',
  'error EndpointNotAllowed(bytes32 providerHash)',
  'error UrlNotAllowed()',
  'error RailNotAllowedForEndpoint(bytes32 providerHash, uint8 rail)',
  'error MalformedJson()',
  'error MissingField(string key)',
  'error DuplicateKey(string key)',
  'error EscapedKey()',
  'error EscapedValue(string key)',
  'error BadNumber(string key)',
  // M-03: a flagged endpoint's PIX credit carries another order's txid (or the call is not from the escrow).
  'error OrderTxidMismatch()',
  // v3.1 N-08: the page proves money moving the other way (a payout page for the on-ramp, a credit page for the
  // off-ramp), or is unclassified; L-12: a substituted template value carries a path.
  'error EndpointNotForConsumer(bytes32 providerHash, uint8 direction)',
  'error BadParamValue()',
  // v2.0 I-22: a claim from another epoch, too old or dated ahead, with no owner; I-65: fewer witnesses than the threshold.
  'error ClaimOutOfTime(uint32 timestampS)',
  'error WrongEpoch(uint32 epoch)',
  'error NoProver()',
  'error QuorumBelowThreshold(uint256 witnessCount, uint256 threshold)',
] as const;

const ESCROW_ERRORS = [
  'error NotArbitrator(address signer)',
  'error ArbitratorNewerThanDispute(address signer)',
  'error RulingForAnotherOrder()',
  'error BadDisputeTimeout(uint256 timeout)',
  'error DisputeExpired(uint64 deadline)',
  'error DisputeStillOpen(uint64 deadline)',
  'error BoletoNotIssued()',
  'error BadBoleto()',
  'error WrongAmount()',
  'error RulingNotReady(uint64 executableAt)',
  'error RulingOutOfTime(uint64 ruledAt)',
  'error NotLP()',
  'error NotTaker()',
  'error Reentrancy()',
  'error BadOffer()',
  'error BadOrder()',
  'error OfferInactive()',
  'error VerifierNotAllowed()',
  'error AmountOutOfRange()',
  'error InsufficientLiquidity()',
  'error PriceOutsideBand()',
  'error AssetNotEnabled(address asset)',
  'error WrongMsgValue()',
  'error StalePrice()',
  'error WindowExpired()',
  'error WindowStillOpen()',
  'error WrongPayee()',
  'error Underpaid()',
  'error RailNotAccepted()',
  // A bank-rail offer, and every sale, names a verifier that proves the bank session (zkTLS), never a quorum's word.
  'error BankRailNeedsZkTls()',
  'error ReceiptReplayed()',
  'error ReceiptPredatesOrder()',
  'error ReceiptTooOld()',
  'error WrongState()',
  'error LPNotEligible()',
  'error TransferFailed()',
  'error DecimalsFixed(address asset, uint8 decimals)',
  // The issuer-freeze screen and the per-asset cap (SR2-24 to SR2-27).
  'error FrozenByAssetIssuer(address who)',
  'error AssetCapExceeded(address asset, uint256 cap)',
  'error BelowPoolMinimum(uint256 minimum)',
  // A SHIELDED lock toward a pool whose vetting fee is above the escrow's MAX_VETTING_FEE_BPS (H-02).
  'error VettingFeeAboveCap(uint256 feeBps)',
  'error NotSeller()',
  'error NotClaimant()',
  'error BadSale()',
  'error AlreadyClaimed()',
  'error ClaimStillLive()',
  'error ClaimCoolingDown(uint64 claimableAt)',
  'error ReceiptPredatesClaim()',
  // v2.0 I-22: the session was not the LP's own; H-04: the offer has a taker gate; I-68: a pending ruling stands.
  'error WrongProver(address prover)',
  'error GateRequired()',
  'error GateApprovalInvalid()',
  'error RulingAlreadyPosted()',
  // RulingLib, surfaced through resolveDispute.
  'error BadOutcome()',
  'error MalformedSignature()',
  'error ContractSignatureRejected(address arbitrator)',
  // DelayedGovernance: every user entry point refuses business until setup is complete.
  'error SetupIncomplete()',
  'error ZeroAddress()',
  // SafeTransferLib, on a token that refuses a pull or an approval. (Its three-argument
  // TransferFailed overloads the escrows' own and is left out, so decoding stays unambiguous.)
  'error TransferFromFailed(address token, address from, uint256 amount)',
  'error ApproveFailed(address token, address spender)',
  'error UnexpectedAmountReceived(uint256 expected, uint256 got)',
  // ReclaimZkTlsVerifier, surfaced through verifyPayment.
  'error NotEnoughSignatures(uint256 got, uint256 need)',
  'error SignaturesUnsorted()',
  'error MalformedProof()',
  'error UnknownWitness(address signer)',
  'error OrderMismatch()',
  ...ZKTLS_VERIFIER_ERRORS,
  // The band check reads the asset's oracle: a ChainlinkSignedFxOracle's legs, and behind it the FX leg.
  'error StaleLeg(address leg, uint256 updatedAt)',
  'error LegFromFuture(address leg, uint256 updatedAt)',
  'error BadPrice(address leg, int256 answer)',
  'error FeedDecimalsOutOfRange(address feed, uint8 decimals)',
  'error PriceRoundsToZero()',
  'error NoPriceYet()',
  ...PYTH_FX_ERRORS,
] as const;

export const FIAT_ESCROW_ABI = parseAbi([
  'function offers(bytes32) view returns (address lp, address asset, uint256 availableWei, uint256 lockedWei, uint256 priceBrlCentsPerEth, bytes32 pixKeyHash, uint256 minOrderWei, uint256 maxOrderWei, address verifier, uint16 railMask, bool active, uint8 decimals)',
  'function orders(bytes32) view returns (bytes32 offerId, address taker, uint256 weiAmount, uint256 brlCents, uint64 lockedAt, uint64 payBy, uint8 state, uint8 delivery, address recipient, uint256 precommitment, uint256 commitment)',
  'function boletoOf(bytes32) view returns (uint64 issueBy, uint64 issuedAt, bytes32 commitment)',
  'function assets(address) view returns (address oracle, uint8 decimals, bool enabled)',
  'function allowedVerifier(address) view returns (bool)',
  'function BAND_BPS() view returns (uint256)',
  'function REGISTRY() view returns (address)',
  // A disputed order still settles by proof until its deadline (SRM1-3): disputedAt plus DISPUTE_TIMEOUT for the
  // LP's own dispute, TAKER_DISPUTE_TIMEOUT for a taker's (H-04). `disputeDeadline` says which; escrows from before
  // H-04 lack it and run every dispute on DISPUTE_TIMEOUT.
  'function disputedAt(bytes32) view returns (uint64)',
  'function DISPUTE_TIMEOUT() view returns (uint64)',
  'function disputeDeadline(bytes32) view returns (uint64)',
  'function postOffer(address asset, uint256 amount, uint256 priceBrlCentsPerEth, bytes32 pixKeyHash, uint256 minOrderWei, uint256 maxOrderWei, address verifier, uint16 railMask) payable returns (bytes32 offerId)',
  'function fundOffer(bytes32 offerId, uint256 amount) payable',
  'function closeOffer(bytes32 offerId)',
  'function takerGate(bytes32) view returns (address)',
  'function setTakerGate(bytes32 offerId, address gate)',
  'function issueBoleto(bytes32 orderId, bytes32 commitment)',
  'function releaseWithProof(bytes32 orderId, bytes proof)',
  'function reclaimExpired(bytes32 orderId)',
  'function raiseDispute(bytes32 orderId, string reason)',
  'event OfferPosted(bytes32 indexed offerId, address indexed lp, uint256 wei_, uint256 price)',
  'event OfferFunded(bytes32 indexed offerId, uint256 addedWei)',
  'event OfferClosed(bytes32 indexed offerId, uint256 returnedWei)',
  'event OrderLocked(bytes32 indexed orderId, bytes32 indexed offerId, address indexed taker, uint256 brlCents)',
  'event OrderReleased(bytes32 indexed orderId, bytes32 bankTxId, uint256 weiAmount)',
  'event OrderCancelled(bytes32 indexed orderId, bool byTaker)',
  'event OrderDisputed(bytes32 indexed orderId, address by, string reason)',
  'event DisputeResolved(bytes32 indexed orderId, bool releasedToTaker, address indexed arbitrator, bytes32 evidenceRoot)',
  'event DisputeTimedOut(bytes32 indexed orderId)',
  'event BoletoRequested(bytes32 indexed orderId, uint64 issueBy)',
  'event BoletoIssued(bytes32 indexed orderId, bytes32 commitment, uint64 payBy)',
  ...ESCROW_ERRORS,
]);

export const OFFRAMP_ESCROW_ABI = parseAbi([
  'function sales(bytes32) view returns (address seller, address asset, uint256 weiAmount, uint256 brlCents, bytes32 payeeKeyHash, address verifier, uint16 railMask, address lp, uint64 claimedAt, uint64 payBy, address refundTo, uint8 state)',
  'function assets(address) view returns (address oracle, uint8 decimals, bool enabled)',
  'function allowedVerifier(address) view returns (bool)',
  'function BAND_BPS() view returns (uint256)',
  'function PAY_WINDOW() view returns (uint64)',
  'function REGISTRY() view returns (address)',
  'function disputedAt(bytes32) view returns (uint64)',
  'function DISPUTE_TIMEOUT() view returns (uint64)',
  'function claimSale(bytes32 saleId)',
  'function abandonClaim(bytes32 saleId)',
  'function settleWithProof(bytes32 saleId, bytes proof)',
  'function raiseDispute(bytes32 saleId, string reason)',
  'event SaleOpened(bytes32 indexed saleId, uint256 weiAmount, uint256 brlCents, uint16 railMask)',
  'event SaleClaimed(bytes32 indexed saleId, address indexed lp, uint64 payBy)',
  'event SaleUnclaimed(bytes32 indexed saleId, address indexed lp, bool expired)',
  'event SaleSettled(bytes32 indexed saleId, address indexed lp, bytes32 bankTxId, uint8 rail)',
  'event SaleCancelled(bytes32 indexed saleId)',
  'event SaleDisputed(bytes32 indexed saleId, address by, string reason)',
  'event DisputeResolved(bytes32 indexed saleId, bool paidLP, address indexed arbitrator, bytes32 evidenceRoot)',
  'event DisputeTimedOut(bytes32 indexed saleId)',
  ...ESCROW_ERRORS,
]);

export const REGISTRY_ABI = parseAbi([
  'function availableCents(address lp) view returns (uint256)',
  'function capOf(address lp) view returns (uint256)',
  'function setupComplete() view returns (bool)',
]);

/**
 * PermissionlessLPRegistry (contracts/ramp/PermissionlessLPRegistry.sol): the same `capOf` / `availableCents` /
 * `canQuote` as REGISTRY_ABI, but no `setupComplete` - its setup is `escrowsBound`, and an LP's state is `bonds(lp)`.
 * `MIN_BOND` and `escrowsBound` are what only it answers, which is how the node tells the two apart (viem-chain.ts).
 */
export const PERMISSIONLESS_REGISTRY_ABI = parseAbi([
  'function availableCents(address lp) view returns (uint256)',
  'function capOf(address lp) view returns (uint256)',
  'function canQuote(address lp, uint256 brlCents) view returns (bool)',
  'function escrowsBound() view returns (bool)',
  'function MIN_BOND() view returns (uint256)',
  'function withdrawableFrom(address lp) view returns (uint256)',
  'function bonds(address lp) view returns (uint256 amount, uint256 exposureCents, uint256 settledCents, uint64 exitRequestedAt, uint32 settlements, uint32 disputesLost)',
]);

/**
 * An escrow's asset oracle, as the node reads it for the band: a ChainlinkSignedFxOracle crossing Chainlink with the
 * FX leg (USDT, ETH), or MovvaReserve (Movva). Both already read the FX leg as a band does, so while the FX market
 * is closed this returns the last close, stamped with the block's time, and offers keep being priced 24/7.
 */
export const ORACLE_ABI = parseAbi([
  'function brlCentsPerUnit() view returns (uint256 price, uint64 updatedAt)',
]);

/**
 * What the entrypoint asks a verifier before it lets an asset quote on it: whether it proves the bank session
 * (`IAttestorVerifier.provesBankSession`). `postOffer` asks the same, and a PIX or boleto offer on a verifier that
 * answers false - or has no such function - never posts.
 */
// `pure`, as both verifiers implement them (IAttestorVerifier declares `view`, and requires the answer be constant).
export const VERIFIER_ABI = parseAbi([
  'function provesBankSession() pure returns (bool)',
  'function attestorKind() pure returns (string)',
]);

/** PythFxOracle's refusals, as `ESCROW_ERRORS` and `RESERVE_ABI` decode them; `test/abi.test.ts` pins them to the artifact. */
export const PYTH_FX_ERRORS_ABI = parseAbi(PYTH_FX_ERRORS);

/** ReclaimZkTlsVerifier's refusals, as the escrows' ABIs decode them; pinned to the artifact the same way. */
export const ZKTLS_VERIFIER_ERRORS_ABI = parseAbi(ZKTLS_VERIFIER_ERRORS);

export const ERC20_ABI = parseAbi([
  'function balanceOf(address) view returns (uint256)',
  'function totalSupply() view returns (uint256)',
  'function allowance(address owner, address spender) view returns (uint256)',
  'function approve(address spender, uint256 amount) returns (bool)',
]);

/**
 * `MovvaReserve` as a gateway uses it (contracts/movva/MovvaReserve.sol): the views `mint` and
 * `redeem` check, the two actions and their events, and every error either can raise - its own, the
 * FX leg's (`NoPriceYet`, and PythFxOracle's `StaleRate` while the FX market is closed), OpenZeppelin's
 * on a refused pull, and Movva's own ERC-20 errors - so a refusal decodes to a reason the node can
 * report. `bandBrlPerUsdtE18` is the rate as the band reads it, which keeps a closing price while the
 * market is closed: the node prices Movva from it then, and never mints or redeems on it.
 * `test/abi.test.ts` pins it to the artifact.
 */
export const RESERVE_ABI = parseAbi([
  'function MOVVA() view returns (address)',
  'function USDT() view returns (address)',
  'function brlPerUsdtE18() view returns (uint256 rate, uint64 updatedAt)',
  'function bandBrlPerUsdtE18() view returns (uint256 rate, uint64 updatedAt)',
  'function brlCentsPerUnit() view returns (uint256 price, uint64 updatedAt)',
  'function totalUsdt() view returns (uint256)',
  'function collateralRatioBps() view returns (uint256)',
  'function isGateway(address account) view returns (bool)',
  'function mintFeeBps() view returns (uint16)',
  'function redeemFeeBps() view returns (uint16)',
  'function minMintCollateralRatioBps() view returns (uint16)',
  'function supplyCap() view returns (uint256)',
  'function mintPaused() view returns (bool)',
  'function frozenByAssetIssuer() view returns (bool)',
  'function yieldVault() view returns (address)',
  'function setupComplete() view returns (bool)',
  'function previewMint(uint256 usdtIn) view returns (uint256 movvaOut, uint256 fee)',
  'function previewRedeem(uint256 movvaIn) view returns (uint256 usdtOut, uint256 fee)',
  'function mint(uint256 usdtIn, address to, uint256 minMovvaOut) returns (uint256 movvaOut)',
  'function redeem(uint256 movvaIn, address to, uint256 minUsdtOut) returns (uint256 usdtOut)',
  // v3.1 N-02: a working gateway says so, which keeps the keyless exit's gateway clock from running out.
  'function gatewayHeartbeat()',
  'function exitStatus() view returns (bool gatewaysQuiet, bool rateDead)',
  'function TRADE_FX_MAX_AGE() view returns (uint64)',
  'event Minted(address indexed gateway, address indexed to, uint256 usdtIn, uint256 movvaOut, uint256 brlPerUsdtE18)',
  'event Redeemed(address indexed gateway, address indexed to, uint256 movvaIn, uint256 usdtOut, uint256 brlPerUsdtE18)',
  'error NotGateway()',
  'error SetupIncomplete()',
  'error ZeroAddress()',
  'error ZeroAmount()',
  'error MintIsPaused()',
  // Raised by the reserve's DivergenceBreaker and bubbled through mint and redeem; it clears itself, so it is a hold.
  'error SourcesDiverge(uint256 low, uint256 high, uint256 bandBps)',
  'error SourceUnavailable(uint256 index)',
  // The breaker refusing a redemption read starved of gas (SRM1-7): send with more gas.
  'error InsufficientGas()',
  'error BadPrice(address leg, int256 answer)',
  'error FxOutOfRange(uint256 brlPerUsdE6)',
  // A USDT/USD answer outside US$ 0.50 to 1.50 (SRM1-21): not a dollar stablecoin's feed, or a collapse.
  'error UsdtUsdOutOfRange(int256 answer)',
  'error StaleLeg(address leg, uint256 updatedAt)',
  'error LegFromFuture(address leg, uint256 updatedAt)',
  'error FeedDecimalsOutOfRange(address feed, uint8 decimals)',
  'error PriceRoundsToZero()',
  'error CollateralRatioTooLow(uint256 ratioBps, uint256 minimumBps)',
  'error SupplyCapExceeded(uint256 supply, uint256 cap)',
  'error Slippage(uint256 out, uint256 minOut)',
  // v3.1 N-06: a mint after a redemption, or the reverse, by the same gateway inside TRADE_FX_MAX_AGE (or one block).
  'error RoundTripTooSoon(uint256 allowedAt)',
  'error BadRecipient()',
  'error InsufficientLiquidity(uint256 wanted, uint256 available)',
  'error TransferFeeCharged(uint256 amount, uint256 received)',
  'error FrozenByAssetIssuer(address who)',
  'error ReentrancyGuardReentrantCall()',
  'error SafeERC20FailedOperation(address token)',
  'error NoPriceYet()',
  'error ERC20InsufficientAllowance(address spender, uint256 allowance, uint256 needed)',
  'error ERC20InsufficientBalance(address sender, uint256 balance, uint256 needed)',
  ...PYTH_FX_ERRORS,
]);

/**
 * `NodeRewards` as an LP's node uses it (contracts/ramp/NodeRewards.sol): the views that say whether its settlements
 * count and what it can claim, `finalize` and `claim`, the `Claimed` event a claim pays through, and every refusal
 * either write can raise. `test/abi.test.ts` pins it to the artifact.
 */
export const NODE_REWARDS_ABI = parseAbi([
  'function REWARD_TOKEN() view returns (address)',
  'function TOKEN_PER_CENT() view returns (uint256)',
  'function registry() view returns (address)',
  'function excluded(address lp) view returns (bool)',
  'function currentEpoch() view returns (uint256)',
  'function nextToFinalize() view returns (uint256)',
  'function finalizableEpochs() view returns (uint256)',
  'function volumeOf(uint256 epoch, address lp) view returns (uint256)',
  'function claimableIn(address lp, uint256 fromEpoch, uint256 count) view returns (uint256 total, uint256[] epochIds)',
  'function setupComplete() view returns (bool)',
  'function finalize(uint256 maxEpochs) returns (uint256 count)',
  'function claim(uint256[] epochIds, address to) returns (uint256 paid)',
  'event Claimed(uint256 indexed epoch, address indexed lp, address to, uint256 paid, uint256 rolledForward)',
  'error NotFinalized(uint256 epoch)',
  'error AlreadyClaimed(uint256 epoch)',
  'error NothingToClaim(uint256 epoch)',
  'error TooManyEpochs()',
  'error ZeroAddress()',
  'error SetupIncomplete()',
  'error ReentrancyGuardReentrantCall()',
  'error SafeERC20FailedOperation(address token)',
]);

/** Only what the reserve's liquidity needs from its yield vault. */
export const ERC4626_ABI = parseAbi(['function maxWithdraw(address owner) view returns (uint256)']);

/**
 * The two issuer blacklists `IssuerFreeze` probes: Tether's `isBlackListed`, Circle's
 * `isBlacklisted`. Decoded as a word compared with zero, as IssuerFreeze does, so an odd `bool`
 * encoding cannot make the read throw.
 */
export const TETHER_FREEZE_ABI = parseAbi(['function isBlackListed(address) view returns (uint256)']);
export const CIRCLE_FREEZE_ABI = parseAbi(['function isBlacklisted(address) view returns (uint256)']);

/** Both escrows refuse to trade against a price older than this (`MAX_PRICE_AGE`, 1 hour). */
export const MAX_PRICE_AGE = 3600n;
/** FiatEscrow.PAY_WINDOW: a PIX order's taker has this long to have payment proven. */
export const ONRAMP_PAY_WINDOW = 30n * 60n;
/** FiatEscrow.BOLETO_ISSUE_WINDOW (internal): the LP's deadline to commit to a boleto. */
export const BOLETO_ISSUE_WINDOW = 60n * 60n;
/** FiatEscrow.BOLETO_PAY_WINDOW (internal): from issue, the taker's deadline for a boleto. */
export const BOLETO_PAY_WINDOW = 3n * 24n * 60n * 60n;
/** FiatEscrow.RECEIPT_MAX_AGE: a PIX/TED receipt older than this cannot settle an order. */
export const ONRAMP_RECEIPT_MAX_AGE = 24n * 60n * 60n;
/** OffRampEscrow.PAY_WINDOW: once the LP claims a sale, it must have payment proven in this. */
export const OFFRAMP_PAY_WINDOW = 45n * 60n;
/** OffRampEscrow.RECEIPT_MAX_AGE. */
export const OFFRAMP_RECEIPT_MAX_AGE = 2n * 24n * 60n * 60n;

/** FiatEscrow.OrderState. */
export enum OrderState { NONE = 0, LOCKED = 1, RELEASED = 2, CANCELLED = 3, DISPUTED = 4 }
/** OffRampEscrow.SaleState. */
export enum SaleState { NONE = 0, OPEN = 1, CLAIMED = 2, SETTLED = 3, CANCELLED = 4, DISPUTED = 5 }
/** FiatEscrow.Delivery. */
export enum Delivery { DIRECT = 0, SHIELDED = 1 }
