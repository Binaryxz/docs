/**
 * The LP's side of an off-ramp sale: decide, claim, pay BRL, prove, collect.
 *
 * ## What the contract asks, and what it does to an LP that misses it
 *
 * OffRampEscrow inverts the on-ramp: the SELLER escrows crypto and the LP pays fiat.
 *
 *  - `claimSale` gives the LP exclusivity and reserves `brlCents` of its registry credit. From
 *    the claim, the LP has PAY_WINDOW (45 minutes) to have payment PROVEN: `settleWithProof`
 *    reverts `WindowExpired` after `payBy`.
 *  - The proof must show a payment to the sale's committed payee (a salted PIX key, or for a
 *    BOLETO-only sale a salted barcode), on a rail the sale accepts, for at least `brlCents`
 *    (exactly, for a boleto), made AFTER the claim (`ReceiptPredatesClaim`) and at most
 *    RECEIPT_MAX_AGE old.
 *  - A claim nobody settles goes stale at `payBy`; anyone may `releaseStaleClaim` and the sale
 *    reopens, and the seller may `cancelSale` it at once. There is no on-chain penalty for that, and
 *    `abandonClaim` before it is free - but a stale claim froze a seller's money, which is what the
 *    SLA is about. Either way nobody may claim the sale again for CLAIM_COOLDOWN (`ClaimCoolingDown`).
 *  - The trap: BRL paid under a claim that then goes stale cannot settle the sale, not even under
 *    a new claim, because the receipt predates it. The only path left is a dispute, which needs
 *    the sale CLAIMED by this LP, and whose default on timeout is a refund to the seller AND a lost
 *    dispute for the LP that raised it. So an LP that has paid must either prove before `payBy`
 *    or raise the dispute while it still holds the claim.
 *  - A dispute does not silence a proof (SRM1-3). Once the sale is DISPUTED - by this node or by
 *    the seller - a payment made inside the claim's window, [claimedAt, payBy], still settles it
 *    until `disputedAt + DISPUTE_TIMEOUT`, with the receipt's age taken at `disputedAt`, and costs
 *    the LP nothing. So the node keeps proving a payment it made while the sale is in dispute; a
 *    payment made after `payBy` cannot settle it, dispute or not.
 *
 * ## The order of operations, which is the safety argument
 *
 * 1. Claim only a sale the node can finish: it holds the payee's opening (the seller discloses key
 *    and salt off-chain; server.ts takes them and checks them against the commitment), it pays on the
 *    sale's rail - and a boleto its bank can pay (`boleto_no_due_date`) - it has a prover for the
 *    sale's verifier that proves that rail, the price is a buy by both the reference and the oracle
 *    (pricing.ts), and credit, bank balance and the open-claim cap allow it.
 *
 *    Every sale settles on zkTLS: `openSale` refuses a verifier that does not prove the bank session
 *    (`BankRailNeedsZkTls`). So the prover is a `ZkTlsProver`, and what it proves is the LP's own
 *    payment - the PIX it sent the seller (`pix-sent`) or the bill it paid (`boleto-paid`) - bound to
 *    the sale id. A sale whose verifier's prover is a quorum is one the node cannot prove, and skips.
 * 2. Pay only once the claim is CONFIRMED: the sale reads CLAIMED by this LP, with the same
 *    `claimedAt`, at `head - confirmations + 1`. A claim that is reorged away after the BRL left
 *    would leave the LP paid out with no claim at all.
 * 3. Before the bank is called, persist the payment intent and its idempotency key (fsync). One
 *    key per sale, derived from the sale id, for the life of the node: a restart finds the intent
 *    and asks the bank what happened to that key, or repeats the call under the same key - never
 *    a new one. A sale whose payment definitively FAILED is abandoned and held, not retried under
 *    a fresh key, because "failed" reported by a bank is not a guarantee nothing moved.
 * 4. Prove and settle. If that cannot happen before `payBy - disputeMarginSeconds`, raise the
 *    dispute while the claim is still held, and leave the evidence to a human.
 *
 * ## Per-payer caps
 *
 * With a `caps` section (caps.ts), the seller's PIX key IS their bank identity, and it is known at the
 * disclosure - before anything is claimed. So the cap is checked twice where it costs nothing: the
 * intake refuses the disclosure and says why, and `decide` refuses the claim (`payer_cap`), leaving the
 * sale open for another LP. It is committed against the payer's Brasília day with the payment intent, at
 * the moment the money is about to move, and given back if the bank reports the payment FAILED.
 */
import type { Address, Hex } from 'viem';
import {
  Rail, normalizePixKey, parseBoleto, pixKeyCommitment, railsFromMask, verifyBoletoCommitment,
} from '@mova/ramp';
import { SaleState } from './abi.js';
import { payerRef } from './attestation.js';
import { bankTxIdHash, type BankRail, type OutgoingPaymentResult } from './bank.js';
import { CAP_REFUSAL_CODE, capRefusalMessage, payerIdForPayee } from './caps.js';
import { ChainRevert, sameAddress, type OnChainSale, type RampEvent } from './chain.js';
import { errorText, short, type NodeContext, type TickView } from './context.js';
import type { SaleValuation } from './gateway.js';
import type { PriceFeed } from './price-feed.js';
import { evaluateSale, type NoQuoteReason, type SalePricing } from './pricing.js';
import { idempotencyKey, type Payee, type SaleTrack } from './store.js';

const BOLETO_BIT = 1 << Rail.BOLETO;
const PIX_BIT = 1 << Rail.PIX;

export interface OfframpAssetConfig {
  asset: Address;
  symbol: string;
  pricing: SalePricing;
  minSaleBrlCents: bigint;
  maxSaleBrlCents: bigint;
  feed: PriceFeed;
  /** Set by the node on the gateway's Movva only: a sale must also be a buy against its redemption value. */
  value?: SaleValuation;
}

export interface OfframpOptions {
  escrow: Address;
  assets: readonly OfframpAssetConfig[];
  /** How this LP can pay sellers. TED is not supported: it needs account details, not a key. */
  rails: readonly BankRail[];
  maxOpenClaims: number;
  /** After the claim confirms, at least this long must remain before `payBy` to start paying. */
  minTimeToPaySeconds: number;
  /** Paid but not yet proven this close to `payBy`: raise the dispute while the claim is held. */
  disputeMarginSeconds: number;
  /** Do not pay until wall time is this far past `claimedAt`: the receipt must post-date it. */
  bankClockSkewSeconds: number;
  raiseDisputeWhenUnproven: boolean;
  /** Most BRL to pay out in any 24 hours, across sales. */
  dailyBudgetCents?: bigint;
  reorgWindow: bigint;
}

export type SkipReason = NoQuoteReason | 'price_too_high' | 'asset_not_configured' | 'asset_disabled' | 'no_payee'
  | 'rail_unsupported' | 'verifier_unsupported' | 'verifier_revoked' | 'amount_out_of_range'
  | 'too_many_claims' | 'insufficient_credit' | 'insufficient_bank_balance' | 'daily_budget' | 'boleto_unpayable'
  /** A bill whose line carries no due date (a collection boleto), at a bank that pays only with one. */
  | 'boleto_no_due_date'
  /** A bill this node already paid for another sale, or issued for an order (I-66): one document is paid once. */
  | 'boleto_reused'
  /** The payee's own daily or monthly limit at this LP is reached (caps.ts). */
  | 'payer_cap';

export class PayeeError extends Error {
  /** A stable code the wallet can act on, beside the sentence; absent where only the sentence matters. */
  constructor(readonly status: number, message: string, readonly code?: string) { super(message); }
}

export class OfframpHandler {
  /** Latest reason each open sale was not claimed, for /status. */
  readonly skipped = new Map<string, SkipReason>();
  private readonly warned = new Set<string>();
  /** Disputed sales whose proof the escrow refused: not proven again; the desk or the timeout decides them. */
  private readonly refusedInDispute = new Set<string>();

  constructor(private readonly ctx: NodeContext, private readonly o: OfframpOptions) {}

  onEvents(events: readonly RampEvent[]): void {
    const { store } = this.ctx;
    for (const e of events) {
      if ((e.kind === 'SaleOpened' || e.kind === 'SaleUnclaimed') && !store.getSale(e.saleId)?.seenBlock) {
        store.record({ t: 'sale.seen', saleId: e.saleId, block: e.block });
      }
    }
  }

  async tick(view: TickView): Promise<void> {
    const { chain, store, metrics } = this.ctx;
    const read: { t: SaleTrack; s: OnChainSale }[] = [];
    for (const t of store.openSales()) {
      try {
        read.push({ t, s: await chain.sale(t.saleId) });
      } catch (e) {
        metrics.inc('mova_lp_tick_errors_total', { stage: 'offramp_read' });
        this.ctx.log.error(`off-ramp: reading ${short(t.saleId)}: ${errorText(e)}`);
      }
    }
    const mine = (s: OnChainSale) => sameAddress(s.lp, chain.account);
    let claims = read.filter(({ s }) => s.state === SaleState.CLAIMED && mine(s)).length;

    metrics.reset('mova_lp_offramp_sales');
    for (const { t, s } of read) {
      const state = s.state === SaleState.CLAIMED && !mine(s) ? 'CLAIMED_BY_OTHER' : SaleState[s.state] ?? 'UNKNOWN';
      metrics.inc('mova_lp_offramp_sales', { state });
    }

    // Finish what is already claimed before taking on anything new.
    const ordered = [...read].sort((a, b) => Number(b.s.state === SaleState.CLAIMED) - Number(a.s.state === SaleState.CLAIMED));
    for (const { t, s } of ordered) {
      if (t.hold) continue;
      try {
        if (s.state === SaleState.OPEN && !t.pay) {
          if (await this.maybeClaim(t, s, view, claims)) claims++;
        } else {
          await this.step(t, s, view);
        }
      } catch (e) {
        metrics.inc('mova_lp_tick_errors_total', { stage: 'offramp' });
        this.ctx.log.error(`off-ramp: sale ${short(t.saleId)}: ${errorText(e)}`);
      }
    }
    metrics.set('mova_lp_payments_unresolved', store.unresolvedPayments());
  }

  private async step(t: SaleTrack, s: OnChainSale, view: TickView): Promise<void> {
    const { chain, store, log } = this.ctx;
    const mine = sameAddress(s.lp, chain.account);
    switch (s.state) {
      case SaleState.NONE:
        if (view.head.number > t.seenBlock + this.o.reorgWindow) store.record({ t: 'sale.done', saleId: t.saleId, state: SaleState.NONE });
        return;
      case SaleState.OPEN:
        // Here only with a payment on record: this LP paid, and its claim went stale.
        if (t.pay?.result?.status === 'SETTLED') {
          log.warn(`off-ramp: paid ${short(t.saleId)} but the claim went stale; re-claiming to dispute`);
          const r = await chain.claimSale(t.saleId);
          store.record({ t: 'sale.claimed', saleId: t.saleId, tx: r.hash });
          return;
        }
        if (t.pay && t.pay.result?.status !== 'FAILED') {
          await this.resolve(t, s, view, false);
          return;
        }
        store.record({ t: 'sale.done', saleId: t.saleId, state: SaleState.OPEN });
        return;
      case SaleState.CLAIMED:
        if (!mine) {
          if (t.pay?.result?.status === 'SETTLED') this.hold(t, 'this LP paid the seller, but another LP now holds the claim');
          return;
        }
        return this.claimed(t, s, view);
      case SaleState.SETTLED:
        store.record({ t: 'sale.done', saleId: t.saleId, state: SaleState.SETTLED });
        return;
      case SaleState.CANCELLED:
        if (t.pay?.result?.status === 'SETTLED') {
          return this.hold(t, 'this LP paid the seller, and the sale ended refunded to the seller');
        }
        store.record({ t: 'sale.done', saleId: t.saleId, state: SaleState.CANCELLED });
        return;
      case SaleState.DISPUTED:
        if (!mine) {
          store.record({ t: 'sale.done', saleId: t.saleId, state: SaleState.DISPUTED });
          return;
        }
        this.once(`disputed:${t.saleId}`, () => log.warn(
          `off-ramp: sale ${short(t.saleId)} is DISPUTED; ${this.ctx.evidence && t.pay ? 'filing a commitment to the LP\'s payment' : 'submit the payment evidence to the arbitration desk'}`,
        ));
        if (this.ctx.evidence && t.pay) {
          await this.ctx.evidence.disputed('offramp', this.o.escrow, t.saleId, [{
            kind: 'lp-payment',
            facts: { rail: t.pay.rail, amountCents: t.pay.amountCents, claimedAt: t.pay.claimedAt, result: t.pay.result, payeeCommitment: s.payeeKeyHash },
          }]);
        }
        // A dispute does not silence a proof (SRM1-3): this LP's payment, made inside the claim's window, still
        // settles the sale until the dispute's deadline - whether the seller or this node raised it.
        if (t.pay?.result?.status === 'SETTLED' && !t.settledTx && !this.refusedInDispute.has(t.saleId.toLowerCase())) {
          const d = await chain.dispute('offramp', t.saleId);
          if (view.chainNow < d.deadline) await this.settle(t, s, view, true);
        }
        return;
      default:
        return;
    }
  }

  /*//////////////////////////////////////////////////////////////
                                DECIDING
  //////////////////////////////////////////////////////////////*/

  private async maybeClaim(t: SaleTrack, s: OnChainSale, view: TickView, claims: number): Promise<boolean> {
    const { chain, store, metrics, log } = this.ctx;
    const why = await this.decide(t, s, view, { claims, forClaim: true });
    if (why) {
      if (this.skipped.get(t.saleId.toLowerCase()) !== why) {
        this.skipped.set(t.saleId.toLowerCase(), why);
        metrics.inc('mova_lp_offramp_skipped_total', { reason: why });
      }
      return false;
    }
    this.skipped.delete(t.saleId.toLowerCase());
    try {
      const r = await chain.claimSale(t.saleId);
      store.record({ t: 'sale.claimed', saleId: t.saleId, tx: r.hash });
      metrics.inc('mova_lp_offramp_claims_total');
      log.info(`off-ramp: claimed ${short(t.saleId)} (${s.brlCents} centavos) in block ${r.blockNumber}`);
      return true;
    } catch (e) {
      // ClaimCoolingDown: the sale's last claim ended unsettled moments ago (SRM1-13); try a later tick.
      if (e instanceof ChainRevert && (e.errorName === 'AlreadyClaimed' || e.errorName === 'WrongState' || e.errorName === 'ClaimCoolingDown')) return false;
      if (e instanceof ChainRevert && e.errorName === 'LPNotEligible') {
        metrics.inc('mova_lp_offramp_skipped_total', { reason: 'insufficient_credit' });
        return false;
      }
      throw e;
    }
  }

  /**
   * Whether to take (or, with `forClaim` false, keep going with) this sale. Everything checkable
   * before money moves is checked here, so a claim is only ever taken on a sale the node can pay,
   * prove and afford.
   */
  async decide(t: SaleTrack, s: OnChainSale, view: TickView, o: { claims: number; forClaim: boolean }): Promise<SkipReason | undefined> {
    const { chain, bank, provers } = this.ctx;
    const a = this.o.assets.find((x) => sameAddress(x.asset, s.asset));
    if (!a) return 'asset_not_configured';
    if (!t.payee) return 'no_payee';

    const boletoSale = s.railMask === BOLETO_BIT;
    if (boletoSale ? !this.o.rails.includes('BOLETO') : !(s.railMask & PIX_BIT && this.o.rails.includes('PIX'))) {
      return 'rail_unsupported';
    }
    if ((boletoSale ? t.payee.kind !== 'boleto' : t.payee.kind !== 'pix')) return 'no_payee';
    if (!provers.get(s.verifier.toLowerCase())?.rails.includes(boletoSale ? Rail.BOLETO : Rail.PIX)) return 'verifier_unsupported';
    if (t.payee.kind === 'boleto') {
      const owner = this.ctx.store.boletoOwner(t.payee.line);
      if (owner !== undefined && owner !== `sale:${t.saleId.toLowerCase()}`) return 'boleto_reused';
    }
    if (t.payee.kind === 'boleto' && bank.boletoNeedsDueDate) {
      let due: string | undefined;
      try {
        due = parseBoleto(t.payee.line).dueDate;
      } catch {
        return 'boleto_unpayable';
      }
      if (!due) return 'boleto_no_due_date';
    }
    if (s.brlCents < a.minSaleBrlCents || s.brlCents > a.maxSaleBrlCents) return 'amount_out_of_range';
    // Before the claim, and again at the pay gate: a sale already counted (its intent is written) never
    // reaches either, so this never refuses a sale on its own count.
    if (this.ctx.caps && !t.cap?.counted && !(await this.capVerdict(t.payee, s.brlCents, view.wallNow)).ok) return 'payer_cap';

    if (o.forClaim) {
      if (o.claims >= this.o.maxOpenClaims) return 'too_many_claims';
      if (!(await chain.verifierAllowed('offramp', s.verifier))) return 'verifier_revoked';
      const credit = await chain.credit();
      if (!credit.setupComplete || credit.availableCents < s.brlCents) return 'insufficient_credit';
      if (bank.balanceCents && (await bank.balanceCents()) < s.brlCents) return 'insufficient_bank_balance';
      if (this.o.dailyBudgetCents !== undefined && this.paidLast24h(view) + s.brlCents > this.o.dailyBudgetCents) {
        return 'daily_budget';
      }
    }

    const cfg = await chain.asset('offramp', s.asset);
    if (!cfg.enabled && o.forClaim) return 'asset_disabled';
    const [oracle, reference, value] = await Promise.all([
      chain.oraclePrice(cfg.oracle).catch(() => undefined), a.feed.price(), a.value ? a.value.saleValue(view) : undefined,
    ]);
    const verdict = evaluateSale({
      brlCents: s.brlCents, amount: s.weiAmount, decimals: cfg.decimals, reference, oracle,
      chainNow: view.chainNow, wallNow: view.wallNow, cfg: a.pricing, value,
    });
    if (!verdict.ok) return verdict.reason;

    try {
      if (t.payee.kind === 'boleto') {
        verifyBoletoCommitment({
          line: t.payee.line, salt: t.payee.salt, commitment: s.payeeKeyHash, brlCents: s.brlCents,
          now: new Date(Number(view.wallNow) * 1000),
        });
      } else if (pixKeyCommitment(t.payee.pixKey, t.payee.salt).toLowerCase() !== s.payeeKeyHash.toLowerCase()) {
        return 'no_payee';
      }
    } catch {
      return 'boleto_unpayable';
    }
    return undefined;
  }

  /**
   * The per-payer cap for a sale, keyed on the payee - which on the off-ramp is who receives the BRL, and
   * so who the limit is about. Reads the ledger; writes nothing.
   */
  private async capVerdict(payee: Payee, cents: bigint, wallNow: bigint) {
    return this.ctx.caps!.check(
      { leg: 'offramp', rail: payee.kind === 'pix' ? 'PIX' : 'BOLETO', payerId: payerIdForPayee(payee) },
      cents, wallNow,
    );
  }

  private paidLast24h(view: TickView): bigint {
    let sum = 0n;
    for (const s of this.ctx.store.sales.values()) {
      const r = s.pay?.result;
      if (s.pay && r?.status !== 'FAILED' && (r?.paidAt ?? view.wallNow) + 86_400n > view.wallNow) sum += s.pay.amountCents;
    }
    return sum;
  }

  /*//////////////////////////////////////////////////////////////
                          CLAIMED: PAY AND PROVE
  //////////////////////////////////////////////////////////////*/

  private async claimed(t: SaleTrack, s: OnChainSale, view: TickView): Promise<void> {
    const status = t.pay?.result?.status;
    if (status === 'SETTLED') return this.settle(t, s, view);
    if (status === 'FAILED') {
      await this.abandon(t, 'the bank reported the payment failed');
      return this.hold(t, 'the payment failed at the bank; not retrying under a new key - check the bank, then clear by hand');
    }
    if (t.pay) return this.resolve(t, s, view, true);
    // No intent on record. Before anything else, ask the bank about this sale's key: a journal
    // restored from an old backup, or lost, must not lead the node to give back a claim it has
    // already paid for - nor to pay it again.
    const key = idempotencyKey('sale-pay', this.ctx.chain.chainId, this.o.escrow, t.saleId);
    let prior: OutgoingPaymentResult | undefined;
    try {
      prior = await this.ctx.bank.getOutgoing(key);
    } catch (e) {
      this.ctx.metrics.inc('mova_lp_bank_errors_total', { op: 'getOutgoing' });
      throw e;
    }
    if (prior) {
      this.ctx.log.error(`off-ramp: the bank already holds a payment for ${short(t.saleId)} that the journal does not; adopting it`);
      this.ctx.store.record({
        t: 'sale.pay.intent', saleId: t.saleId, idempotencyKey: key, rail: s.railMask === BOLETO_BIT ? 'BOLETO' : 'PIX',
        amountCents: prior.amountCents ?? s.brlCents, claimedAt: s.claimedAt,
      });
      return this.resolve(this.ctx.store.getSale(t.saleId)!, s, view, true);
    }
    return this.pay(t, s, view);
  }

  /** The claim is ours on-chain, N blocks deep, and unchanged since. */
  private async claimConfirmed(s: OnChainSale, saleId: Hex, view: TickView): Promise<boolean> {
    const c = await this.ctx.chain.sale(saleId, view.confirmedBlock);
    return c.state === SaleState.CLAIMED && sameAddress(c.lp, this.ctx.chain.account) && c.claimedAt === s.claimedAt;
  }

  private async pay(t: SaleTrack, s: OnChainSale, view: TickView): Promise<void> {
    const { chain, store, metrics, log } = this.ctx;
    // Gate 1: never pay against a claim a reorg could still take back.
    if (!(await this.claimConfirmed(s, t.saleId, view))) return;
    // Gate 2: enough of the window left to pay, attest and settle.
    if (view.chainNow + BigInt(this.o.minTimeToPaySeconds) > s.payBy) {
      return this.abandon(t, 'too little of the pay window left to pay and prove');
    }
    // Gate 3: the bank's settlement time must post-date the claim, or the proof is refused.
    if (view.wallNow < s.claimedAt + BigInt(this.o.bankClockSkewSeconds)) return;
    // Gate 4: still a sale worth paying - the price may have moved since the claim.
    const why = await this.decide(t, s, view, { claims: 0, forClaim: false });
    if (why) return this.abandon(t, `no longer a buy: ${why}`);

    const payee = t.payee!;
    const key = idempotencyKey('sale-pay', chain.chainId, this.o.escrow, t.saleId);
    // Counted here, where the money is about to move: `decide` above has just checked it, and a sale whose
    // count is written never goes through `decide` again. Counted before the intent, so a crash between the
    // two counts a payment that never went out - which refuses more, never less, and the FAILED path gives it back.
    if (this.ctx.caps && !t.cap?.counted) {
      const verdict = await this.capVerdict(payee, s.brlCents, view.wallNow);
      if (!verdict.ok) return this.abandon(t, `no longer a buy: ${verdict.period === 'unknown_payer' ? 'the payee names no payer' : `the payee's ${verdict.period} limit is reached`}`);
      if (verdict.payer) {
        const day = this.ctx.caps.count(verdict.payer, s.brlCents, view.wallNow, 'offramp');
        store.record({ t: 'sale.cap', saleId: t.saleId, day, cents: s.brlCents });
      }
    }
    store.record({
      t: 'sale.pay.intent', saleId: t.saleId, idempotencyKey: key, rail: payee.kind === 'pix' ? 'PIX' : 'BOLETO',
      amountCents: s.brlCents, claimedAt: s.claimedAt,
    });
    log.info(`off-ramp: paying ${short(t.saleId)}: ${s.brlCents} centavos by ${payee.kind === 'pix' ? 'PIX' : 'boleto'}`);
    const result = await this.send(key, payee, s.brlCents);
    this.recordResult(t, result);
    if (result.status === 'SETTLED') metrics.inc('mova_lp_offramp_brl_paid_cents_total', {}, Number(result.amountCents ?? s.brlCents));
    if (result.status !== 'PENDING') await this.claimed(store.getSale(t.saleId)!, s, view);
  }

  /**
   * An intent without a final result: a crash, a lost response, or a PENDING transfer. Ask the
   * bank about THIS key; if it has never heard of it, repeat the call under the same key - but only
   * while a confirmed claim still stands behind it.
   */
  private async resolve(t: SaleTrack, s: OnChainSale, view: TickView, claimed: boolean): Promise<void> {
    const { bank, metrics, log } = this.ctx;
    const pay = t.pay!;
    let result: OutgoingPaymentResult | undefined;
    try {
      result = await bank.getOutgoing(pay.idempotencyKey);
    } catch (e) {
      metrics.inc('mova_lp_bank_errors_total', { op: 'getOutgoing' });
      throw e;
    }
    if (!result) {
      const stillOurs = claimed && s.claimedAt === pay.claimedAt && await this.claimConfirmed(s, t.saleId, view)
        && view.chainNow + BigInt(this.o.minTimeToPaySeconds) <= s.payBy;
      if (!stillOurs) {
        if (claimed) await this.abandon(t, 'payment outcome unknown and too late to retry');
        return this.hold(t, `the bank has no record of key ${pay.idempotencyKey} and the claim cannot cover a retry; confirm nothing was paid`);
      }
      log.warn(`off-ramp: no record of ${short(t.saleId)}'s payment at the bank; repeating under the same key`);
      result = await this.send(pay.idempotencyKey, t.payee!, pay.amountCents);
    }
    if (result.status === 'PENDING' && pay.result?.status === 'PENDING') return; // still settling
    this.recordResult(t, result);
    if (result.status === 'SETTLED') metrics.inc('mova_lp_offramp_brl_paid_cents_total', {}, Number(result.amountCents ?? pay.amountCents));
    if (claimed && result.status !== 'PENDING') await this.claimed(this.ctx.store.getSale(t.saleId)!, s, view);
  }

  private async send(key: string, payee: Payee, amountCents: bigint): Promise<OutgoingPaymentResult> {
    const { bank, metrics } = this.ctx;
    try {
      return payee.kind === 'pix'
        ? await bank.sendPix({ idempotencyKey: key, pixKey: normalizePixKey(payee.pixKey).key, amountCents, description: 'Mova' })
        : await bank.payBoleto({ idempotencyKey: key, line: parseBoleto(payee.line).line, amountCents });
    } catch (e) {
      metrics.inc('mova_lp_bank_errors_total', { op: payee.kind === 'pix' ? 'sendPix' : 'payBoleto' });
      throw e;
    }
  }

  private recordResult(t: SaleTrack, result: OutgoingPaymentResult): void {
    this.ctx.store.record({ t: 'sale.pay.result', saleId: t.saleId, result });
    // The bank says nothing moved: give the payee's allowance back. (`FAILED` is still held and looked at
    // by hand - see `claimed` - because a bank's "failed" is not a guarantee.)
    const { caps, store } = this.ctx;
    const cap = store.getSale(t.saleId)?.cap;
    if (result.status !== 'FAILED' || !caps || !cap?.counted || cap.uncounted) return;
    const payer = caps.identify(t.payee ? payerIdForPayee(t.payee) : undefined);
    if (!payer) return;
    caps.uncount(payer, cap.counted.cents, cap.counted.day, 'offramp');
    store.record({ t: 'sale.cap.uncounted', saleId: t.saleId });
  }

  /**
   * `disputed`: the sale is DISPUTED and before its deadline. The proof is still worth sending (SRM1-3) - the escrow
   * then wants the payment made by `payBy`, not the proof - and there is no dispute left to raise if it cannot be.
   */
  private async settle(t: SaleTrack, s: OnChainSale, view: TickView, disputed = false): Promise<void> {
    const { chain, store, provers, metrics, log } = this.ctx;
    const res = t.pay!.result!;
    const nearDeadline = !disputed && view.chainNow + BigInt(this.o.disputeMarginSeconds) >= s.payBy;
    const giveUp = (why: string) => (disputed ? this.unprovableInDispute(t, why) : this.dispute(t, why));
    const payee = t.payee;
    if (!payee) {
      // Paid, but the disclosure that opens the commitment is gone (a lost journal). The seller can
      // disclose again (the intake accepts a sale this LP holds); until then there is nothing to prove.
      if (nearDeadline) return this.dispute(t, 'payee disclosure lost before the proof');
      this.once(`nopayee:${t.saleId}`, () => log.error(`off-ramp: ${short(t.saleId)} is paid but its payee disclosure is missing; ask the seller to disclose again`));
      return;
    }
    if (res.paidAt === undefined || res.bankTxId === undefined) {
      return this.hold(t, 'the bank reported SETTLED without a settlement time or end-to-end id');
    }
    if (res.paidAt < s.claimedAt) return giveUp('receipt predates the current claim');
    if (res.paidAt > s.payBy) return giveUp('the payment was made after the claim\'s window');
    if (!disputed && view.chainNow > s.payBy) return this.dispute(t, 'the pay window closed before the proof');
    const prover = provers.get(s.verifier.toLowerCase());
    if (!prover?.rails.includes(payee.kind === 'pix' ? Rail.PIX : Rail.BOLETO)) {
      return giveUp('no prover for the sale verifier proves this rail');
    }

    // The sale id is what settleWithProof binds the proof to: a zkTLS claim's contextMessage.
    const terms = {
      orderId: t.saleId, payeeKeyHash: s.payeeKeyHash, brlCents: s.brlCents, lockedAt: s.claimedAt,
      acceptedRails: railsFromMask(s.railMask),
    };
    const ref = payerRef(this.ctx.lpPayerId, this.ctx.payerRefSecret);
    const amount = res.amountCents ?? t.pay!.amountCents;
    let proof: Hex;
    try {
      proof = payee.kind === 'pix'
        ? await prover.provePix(terms, {
          bankTxId: res.bankTxId, pixKey: res.creditedKey ?? payee.pixKey, salt: payee.salt,
          payerRef: ref, amountBrlCents: amount, paidAt: res.paidAt, leg: 'offramp',
        })
        : await prover.proveBoleto(terms, {
          bankTxId: res.bankTxId, line: payee.line, salt: payee.salt, payerRef: ref,
          amountBrlCents: amount, paidAt: res.paidAt, leg: 'offramp',
        });
    } catch (e) {
      metrics.inc('mova_lp_proof_failures_total', { leg: 'offramp' });
      log.warn(`off-ramp: no proof yet for ${short(t.saleId)}: ${errorText(e)}`);
      if (nearDeadline) await this.dispute(t, 'proof unavailable before payBy');
      return;
    }
    try {
      const r = await chain.settleWithProof(t.saleId, proof);
      store.record({ t: 'sale.settled', saleId: t.saleId, tx: r.hash });
      metrics.inc('mova_lp_offramp_settled_total');
      log.info(`off-ramp: settled ${short(t.saleId)}${disputed ? ', in dispute,' : ''} in block ${r.blockNumber}`);
    } catch (e) {
      const name = e instanceof ChainRevert ? e.errorName : '';
      if (name === 'WrongState') return; // re-read next tick
      log.error(`off-ramp: settlement of ${short(t.saleId)} refused: ${errorText(e)}`);
      // In dispute (DisputeExpired, a stale receipt, a replayed id): no retry will change it.
      if (disputed) {
        if (name) this.unprovableInDispute(t, `settlement refused (${name})`);
        return;
      }
      if (nearDeadline || name === 'WindowExpired') await this.dispute(t, `settlement refused (${name || 'error'})`);
    }
  }

  /** A disputed sale this node cannot prove: stop trying, and leave it to the desk or the timeout. */
  private unprovableInDispute(t: SaleTrack, why: string): void {
    this.refusedInDispute.add(t.saleId.toLowerCase());
    this.ctx.log.error(`off-ramp: disputed ${short(t.saleId)} cannot be settled by proof (${why}); file the payment evidence with the arbitration desk`);
  }

  private async abandon(t: SaleTrack, reason: string): Promise<void> {
    const { chain, store, metrics, log } = this.ctx;
    try {
      const r = await chain.abandonClaim(t.saleId);
      store.record({ t: 'sale.abandoned', saleId: t.saleId, tx: r.hash, reason });
      metrics.inc('mova_lp_offramp_abandoned_total', { reason: reason.startsWith('no longer a buy') ? 'repriced' : 'other' });
      log.warn(`off-ramp: gave back ${short(t.saleId)}: ${reason}`);
    } catch (e) {
      if (e instanceof ChainRevert && (e.errorName === 'WrongState' || e.errorName === 'NotClaimant')) return;
      throw e;
    }
  }

  private async dispute(t: SaleTrack, why: string): Promise<void> {
    const { chain, store, metrics, log } = this.ctx;
    if (t.disputedTx) return;
    if (!this.o.raiseDisputeWhenUnproven) return this.hold(t, `paid but unproven (${why}); disputes are disabled - act by hand now`);
    const res = t.pay?.result;
    // Public, permanent calldata: a hash of the bank id, never the id, a key or an amount.
    const reason = `LP paid; unproven: ${why}; bankTxId ${res?.bankTxId ? bankTxIdHash(res.bankTxId) : 'unknown'}`;
    try {
      const r = await chain.raiseDispute('offramp', t.saleId, reason);
      store.record({ t: 'sale.disputed', saleId: t.saleId, tx: r.hash, reason: why });
      metrics.inc('mova_lp_disputes_raised_total', { leg: 'offramp' });
      log.error(`off-ramp: raised a dispute on ${short(t.saleId)} (${why}); file the payment evidence with the arbitration desk`);
    } catch (e) {
      // H-04: the escrow takes an LP's dispute only while the claim is live (block.timestamp <= payBy).
      if (e instanceof ChainRevert && e.errorName === 'WindowExpired') {
        return this.hold(t, `paid but unproven (${why}), and the claim's window has closed: the escrow no longer takes this LP's dispute, so the payment has no on-chain route; settle it with the seller off-chain`);
      }
      this.hold(t, `paid but unproven (${why}), and the dispute could not be raised: ${errorText(e)}`);
    }
  }

  private hold(t: SaleTrack, reason: string): void {
    this.ctx.store.record({ t: 'sale.hold', saleId: t.saleId, reason });
    this.ctx.log.error(`off-ramp: HOLD ${short(t.saleId)}: ${reason}`);
  }

  private once(key: string, fn: () => void): void {
    if (this.warned.has(key)) return;
    this.warned.add(key);
    fn();
  }

  /*//////////////////////////////////////////////////////////////
                               PAYEE INTAKE
  //////////////////////////////////////////////////////////////*/

  /**
   * A seller (or anyone they gave it to) discloses the payee behind a sale's commitment. No
   * signature is needed: only someone who knows the key or barcode AND the secret salt can open
   * the commitment, and an opening that does not match is refused. Messages never repeat the
   * submitted key or line.
   */
  async submitPayee(saleId: Hex, input: { pixKey?: unknown; boletoLine?: unknown; salt?: unknown }): Promise<void> {
    const { chain, store } = this.ctx;
    if (typeof input.salt !== 'string' || !/^0x[0-9a-fA-F]{64}$/.test(input.salt)) {
      throw new PayeeError(400, 'salt must be 32 bytes of 0x-prefixed hex');
    }
    const salt = input.salt as Hex;
    const hasKey = typeof input.pixKey === 'string' && input.pixKey.length > 0;
    const hasLine = typeof input.boletoLine === 'string' && input.boletoLine.length > 0;
    if (hasKey === hasLine) throw new PayeeError(400, 'give exactly one of pixKey or boletoLine');

    const s = await chain.sale(saleId);
    if (s.state === SaleState.NONE) throw new PayeeError(404, 'no such sale');
    if (!(s.state === SaleState.OPEN || (s.state === SaleState.CLAIMED && sameAddress(s.lp, chain.account)))) {
      throw new PayeeError(409, `sale is ${SaleState[s.state]}`);
    }
    const boletoSale = s.railMask === BOLETO_BIT;
    // A disclosure this node would never act on is refused, not stored: the seller should take the sale elsewhere.
    if (hasLine && !this.o.rails.includes('BOLETO')) throw new PayeeError(422, 'this node does not pay boletos');
    if (hasKey && !this.o.rails.includes('PIX')) throw new PayeeError(422, 'this node does not pay by PIX');
    let payee: Payee;
    if (hasKey) {
      if (boletoSale) throw new PayeeError(422, 'this sale pays a boleto, not a PIX key');
      let commitment: Hex;
      let key: string;
      try {
        key = normalizePixKey(input.pixKey as string).key;
        commitment = pixKeyCommitment(key, salt);
      } catch {
        throw new PayeeError(422, 'not a valid PIX key and salt');
      }
      if (commitment.toLowerCase() !== s.payeeKeyHash.toLowerCase()) {
        throw new PayeeError(422, 'that key and salt do not open the sale\'s payee commitment');
      }
      payee = { kind: 'pix', pixKey: key, salt };
    } else {
      if (!boletoSale) throw new PayeeError(422, 'this sale pays a PIX key, not a boleto');
      try {
        const b = verifyBoletoCommitment({
          line: input.boletoLine as string, salt, commitment: s.payeeKeyHash, brlCents: s.brlCents,
        });
        payee = { kind: 'boleto', line: b.line, salt };
      } catch {
        throw new PayeeError(422, 'that boleto and salt do not open the sale\'s payee commitment for its amount, or it is overdue');
      }
    }
    // Per-payer caps, at the one moment on this leg that costs nobody anything: the sale stays open and
    // another LP may take it. The refusal names the rule, never how much this payee has already moved.
    if (this.ctx.caps && !store.getSale(saleId)?.cap?.counted) {
      const verdict = await this.capVerdict(payee, s.brlCents, this.ctx.wallClock());
      if (!verdict.ok) throw new PayeeError(409, capRefusalMessage(verdict), CAP_REFUSAL_CODE);
    }
    if (!store.getSale(saleId)?.seenBlock) {
      store.record({ t: 'sale.seen', saleId, block: (await chain.head()).number });
    }
    store.record({ t: 'sale.payee', saleId, payee });
  }
}
