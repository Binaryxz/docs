/**
 * The service's half of a distributed key generation: three rounds with one device, over HTTP.
 *
 * WHAT THIS BUYS. Until now a FROST account's group key had to be made somewhere else and its server share
 * dropped into the share file by hand. So either one machine ran both halves - which is the trusted dealer
 * that `packages/mpc` deleted - or FROST accounts could not be created at all. Here the device and this
 * service each sample their own polynomial and neither ever holds the group secret, which is the whole claim
 * of docs/wallet-custody.md §5, made true from the first key onwards.
 *
 * THE RUN, and what each call costs the device:
 *
 *   POST /v1/frost/dkg/start    the device's round-1 broadcast, plus a user-verified passkey assertion over
 *                               the run (chain, co-signer, passkey, the device's per-run key, the context).
 *                               The service answers with its own round-1 broadcast, signed by the co-signer
 *                               key the account will name on-chain
 *   POST /v1/frost/dkg/round2   the device's share for the service, sealed to the X25519 key in the
 *                               service's round 1. The service opens it, produces its own sealed share and
 *                               its signed view of the group key, and stores its share PENDING
 *   POST /v1/frost/dkg/confirm  the device's signed confirmation, plus a second passkey assertion over the
 *                               group key and transcript. Only if they equal the service's own does the
 *                               share become usable
 *
 * WHICH ACCOUNT. None yet: a FROST account's address commits to the group key, so it does not exist until
 * the run finishes. The run is keyed by the one identifier that exists beforehand - `chainId:passkeySigner`,
 * the SafeWebAuthnSigner address of the passkey, which is exactly what the account will name as its recovery
 * Delay's only module and what enrolment reads back from the chain. One completed run per such reference:
 * a second is refused, because a second group key for an account that already has one is either a mistake or
 * an attempt to have this service co-own two keys for one user, and the first may already hold funds.
 *
 * WHAT IS REFUSED, all of it before any share is stored:
 *
 *   dkg_disabled     this service has no writable share store, so it does not generate keys
 *   dkg_exists       that account reference already has a COMPLETE share, or a run for it is open
 *   session_unknown  no open run with that id (never started, already finished, expired, or replayed)
 *   dkg_invalid      the transport refused a message: a bad signature, a replay, a round out of order, a
 *                    different transcript, a share that does not match its commitments. The message names
 *                    the participant at fault, because a DKG that quietly continues is worse than one that
 *                    stops
 *   no_share         the share of a run that never confirmed: it is stored, and it never signs
 *
 * NOT DURABLE ACROSS A RESTART. An open run lives in memory; a restart mid-run loses it and the device
 * starts again (nothing was stored, so nothing is stranded). A run that reached round 2 leaves a PENDING
 * share in the store, which survives; it cannot sign, and the next start for the same account discards it -
 * it was never enrolled, so no account can exist under that group key.
 */
import {
  DkgSession, DkgTransportError, MIN_DKG_CONTEXT_BYTES, generateDkgKey,
  type DkgAuth, type DkgResult, type DkgWireMessage,
} from '@mova/mpc';
import { secp256k1 } from '@noble/curves/secp256k1';
import { getAddress, hexToBytes, isAddress, isHex, size, toHex, type Address, type Hex } from 'viem';
import {
  DKG_DEVICE, DKG_SERVER, DKG_THRESHOLD,
  type DkgConfirmRequest, type DkgConfirmResult, type DkgPasskey, type DkgRound2Request, type DkgRound2Result,
  type DkgStartRequest, type DkgStartResult, type DkgTransportKey, type DkgWire, dkgTransportKeyDigest,
} from './dkg-proof.js';
import type { FrostShareWriter } from './frost-shares.js';
import type { CoSignerKey } from './key.js';
import { Refusal, type RefusalCode } from './refusal.js';

/** A refusal from a DKG round, carrying the participant the transport blamed, when it named one. */
export class DkgRefusal extends Refusal {
  constructor(code: RefusalCode, message: string, readonly party?: number) {
    super(code, message);
  }
}

export const MAX_DKG_CONTEXT_BYTES = 128;

export interface FrostDkgOptions {
  chainId: number;
  key: CoSignerKey;
  shares: FrostShareWriter;
  /** How long an open run lives. Default 300 s: two round trips and two authenticator prompts. */
  sessionSeconds?: number;
  /** Open runs across all accounts. Default 32; each holds one polynomial and one X25519 key. */
  maxSessions?: number;
  nowMs?: () => number;
  now?: () => bigint;
}

interface OpenRun {
  readonly sessionId: Hex;
  readonly accountRef: string;
  readonly session: DkgSession;
  readonly deviceRound1: DkgWireMessage;
  readonly passkey: DkgPasskey;
  readonly passkeyId: Hex;
  expiresAtMs: number;
  stage: 'round1' | 'finished';
  result?: DkgResult;
}

/** What the service knows about an open run: enough to check the device's proofs and to audit it. */
export interface DkgRunView {
  accountRef: string;
  passkey: DkgPasskey;
  passkeyId: Hex;
  stage: 'round1' | 'finished';
  /** Present once round 2 has run: the key this service derived, which the device must confirm. */
  groupKey?: Hex;
  transcript?: Hex;
}

export class FrostDkg {
  private readonly runs = new Map<string, OpenRun>();
  /**
   * The key this service signs DKG messages with (v2.0 L-08): never the co-signer key, which signs only the
   * certificate naming this one. In memory, for the life of the process, as the runs are.
   */
  private readonly transport = generateDkgKey();
  private certificate?: Promise<Hex>;

  constructor(private readonly o: FrostDkgOptions) {}

  /** The transport key and the co-signer key's certificate over it, which a device checks before it starts. */
  async transportKey(): Promise<DkgTransportKey> {
    const key = toHex(this.transport.publicKey);
    this.certificate ??= this.o.key.signDigest(dkgTransportKeyDigest({ chainId: this.o.chainId, coSigner: this.o.key.address, transportKey: key }));
    try {
      return { key, certificate: await this.certificate };
    } catch (e) {
      this.certificate = undefined;
      throw e;
    }
  }

  get transportPublicKey(): Hex {
    return toHex(this.transport.publicKey);
  }

  get open(): number {
    this.prune();
    return this.runs.size;
  }

  private nowMs(): number {
    return this.o.nowMs ? this.o.nowMs() : Date.now();
  }

  private now(): number {
    return Number(this.o.now ? this.o.now() : BigInt(Math.floor(Date.now() / 1000)));
  }

  private prune(): void {
    const now = this.nowMs();
    for (const [id, r] of this.runs) {
      if (r.expiresAtMs < now) {
        // A run that reached round 2 left a pending share; it is no use to anybody and is dropped with it.
        if (r.result) this.o.shares.discardPending(r.result.publicKeys.groupPublicKey);
        this.runs.delete(id);
      }
    }
  }

  /**
   * The service's signing and verification for one run: it signs with its transport key, which the co-signer key
   * certified (L-08), and accepts the device only under the per-run key its passkey authorised in `start`.
   */
  private auth(deviceKey: Uint8Array): DkgAuth {
    return {
      sign: (digest) => secp256k1.sign(digest, this.transport.secretKey, { prehash: false }).toBytes('compact'),
      verify: (party, digest, signature) => {
        if (party !== DKG_DEVICE || signature.length !== 64) return false;
        try {
          return secp256k1.verify(signature, digest, deviceKey, { prehash: false });
        } catch {
          return false;
        }
      },
    };
  }

  /** The DKG's view of who the parties are: the device's per-run key, and this service's transport key. */
  private identities(deviceKey: Uint8Array): Map<number, Uint8Array> {
    return new Map([[DKG_DEVICE, deviceKey], [DKG_SERVER, this.transport.publicKey]]);
  }

  /**
   * Round 1. `accountRef` is the account this run is for; the caller has already verified the passkey over
   * `dkgStartChallenge` and rate-limited by that reference.
   */
  async begin(req: DkgStartRequest, o: { accountRef: string; passkeyId: Hex }): Promise<DkgStartResult> {
    this.prune();
    const records = this.o.shares.forAccountAll(o.accountRef);
    const complete = records.filter((r) => r.complete);
    if (req.rotates === undefined && complete.length > 0) {
      throw new Refusal('dkg_exists', 'this service already holds a FROST share for this account: a second key '
        + 'generation would strand the first, which may already hold funds. To replace the key, run a rotation (rotates)');
    }
    if (req.rotates !== undefined) {
      // L-07: a rotation replaces the one key the account signs with; the old share signs on until the account
      // adopts the new key on-chain (FrostValidator.rotateGroupKey) and re-enrols, which retires it.
      const current = complete.find((r) => toHex(r.share.groupPublicKey.toBytes(true)) === req.rotates);
      if (!current) throw new Refusal('dkg_invalid', 'a rotation names the account\'s current group key, and this service holds no share of that key for this passkey');
      if (complete.length > 1) {
        throw new Refusal('dkg_exists', 'a rotation already produced a key this account has not adopted: rotate to it on-chain, or re-enrol, first');
      }
    }
    for (const r of this.runs.values()) {
      if (r.accountRef === o.accountRef) throw new Refusal('dkg_exists', 'a key generation for this account is already open');
    }
    for (const r of records) {
      // A pending share whose run is gone: it expired, or this service restarted between rounds. It was
      // never enrolled - enrolment needs a COMPLETE share - so no account can exist under that group key.
      // Dropping it lets the device start again instead of stranding the account for ever.
      if (!r.complete) this.o.shares.discardPending(r.share.groupPublicKey);
    }
    if (this.runs.size >= (this.o.maxSessions ?? 32)) throw new Refusal('rate_limited', 'too many key generations are open on this service');

    const deviceKey = hexToBytes(req.deviceKey);
    const params = { context: hexToBytes(req.context), threshold: DKG_THRESHOLD, participants: [DKG_DEVICE, DKG_SERVER] };
    let session: DkgSession;
    try {
      session = DkgSession.open({ party: DKG_SERVER, params, identities: this.identities(deviceKey), auth: this.auth(deviceKey) });
    } catch (e) {
      throw this.refuse(e, 'the run could not be opened');
    }
    if (`0x${session.sessionId}` !== this.sessionIdOf(req)) {
      throw new Refusal('dkg_invalid', 'the device\'s round-1 message is not for the session its context derives');
    }
    const sessionId = `0x${session.sessionId}` as Hex;
    if (this.runs.has(sessionId)) throw new Refusal('dkg_exists', 'that session id is already open');
    // The run is recorded BEFORE the broadcast is signed: signing is asynchronous (a KMS round trip),
    // and without this two requests that arrive together would both pass the checks above and open two
    // key generations for one account.
    const expiresAtMs = this.nowMs() + (this.o.sessionSeconds ?? 300) * 1000;
    this.runs.set(sessionId, {
      sessionId, accountRef: o.accountRef, session, deviceRound1: req.round1 as DkgWireMessage,
      passkey: req.passkey, passkeyId: o.passkeyId, expiresAtMs, stage: 'round1',
    });
    let round1: DkgWireMessage;
    try {
      round1 = await session.broadcast();
    } catch (e) {
      this.runs.delete(sessionId);
      throw this.refuse(e, 'this service could not produce its round-1 broadcast');
    }
    return {
      sessionId, accountRef: getAddress(o.accountRef.slice(o.accountRef.indexOf(':') + 1)), coSigner: this.o.key.address,
      device: DKG_DEVICE, server: DKG_SERVER, round1, expiresAt: Math.floor(expiresAtMs / 1000),
    };
  }

  /**
   * Round 2: open the device's sealed share, seal ours, and store the share this run produced - PENDING,
   * because the device has not yet said it derived the same key.
   */
  async advance(req: DkgRound2Request): Promise<DkgRound2Result> {
    const run = this.take(req.sessionId, 'round1');
    try {
      const ours = await run.session.round2([run.deviceRound1]);
      const { result, confirmation } = await run.session.finish([req.message as DkgWireMessage]);
      // Stored first (the envelope store wraps a data key, a KMS round trip), and only then is the run at its
      // confirmation stage: a confirmation cannot arrive for a share that is not yet written.
      await this.o.shares.putPending({
        share: result.keyShare, accountRef: run.accountRef,
        // The DKG's own transcript, which is what both halves publish and what the device's second
        // assertion signs. The transport transcript is stronger - it covers the identities and the X25519
        // keys too - but it is signed into every round-2 and round-3 envelope already, and never published.
        transcript: result.publicKeys.transcript, createdAt: this.now(),
      });
      run.result = result;
      run.stage = 'finished';
      return { message: ours[0]!, confirmation };
    } catch (e) {
      this.runs.delete(req.sessionId);
      throw this.refuse(e, 'round 2 was refused');
    }
  }

  /** Round 3: the device's confirmation. Only now does the share become one that can sign. */
  async settle(req: DkgConfirmRequest): Promise<DkgConfirmResult> {
    const run = this.take(req.sessionId, 'finished');
    const result = run.result!;
    try {
      await run.session.confirm([req.confirmation as DkgWireMessage]);
    } catch (e) {
      // The device derived a different key, or could not authenticate: the share is worthless, and kept
      // by nobody.
      this.o.shares.discardPending(result.publicKeys.groupPublicKey);
      this.runs.delete(req.sessionId);
      throw this.refuse(e, 'the device did not confirm the key this run produced');
    }
    this.runs.delete(req.sessionId);
    await this.o.shares.complete(result.publicKeys.groupPublicKey);
    return {
      accountRef: getAddress(run.accountRef.slice(run.accountRef.indexOf(':') + 1)),
      groupKey: toHex(result.publicKeys.groupPublicKey.toBytes(true)),
      transcript: `0x${result.publicKeys.transcript}`,
      verificationShares: [...result.publicKeys.verificationShares].map(([id, p]) => ({ id, point: toHex(p.toBytes(true)) })),
      complete: true,
    };
  }

  /** An open run, for the caller's passkey check and its audit record. Undefined when there is none. */
  describe(sessionId: Hex): DkgRunView | undefined {
    const run = this.runs.get(sessionId.toLowerCase());
    if (!run) return undefined;
    return {
      accountRef: run.accountRef, passkey: run.passkey, passkeyId: run.passkeyId, stage: run.stage,
      ...(run.result ? {
        groupKey: toHex(run.result.publicKeys.groupPublicKey.toBytes(true)),
        transcript: `0x${run.result.publicKeys.transcript}` as Hex,
      } : {}),
    };
  }

  private take(sessionId: Hex, stage: OpenRun['stage']): OpenRun {
    this.prune();
    const run = this.runs.get(sessionId.toLowerCase());
    if (!run || run.stage !== stage) {
      throw new Refusal('session_unknown', 'no key generation is open at that round with that id: start again');
    }
    return run;
  }

  private sessionIdOf(req: DkgStartRequest): string {
    const round1 = req.round1;
    return `0x${round1.session}`;
  }

  /** Every transport failure becomes one refusal, naming the participant at fault. */
  private refuse(e: unknown, what: string): Refusal {
    if (e instanceof Refusal) return e;
    if (e instanceof DkgTransportError) {
      return new DkgRefusal('dkg_invalid', `${what}: ${e.code}: ${e.message}`, e.party);
    }
    return new DkgRefusal('dkg_invalid', `${what}: ${e instanceof Error ? e.message : String(e)}`);
  }
}

/* ------------------------------------------------------------------ wire parsing */

function obj(v: unknown, what: string): Record<string, unknown> {
  if (!v || typeof v !== 'object' || Array.isArray(v)) throw new Refusal('malformed', `${what} must be a JSON object`);
  return v as Record<string, unknown>;
}

const HEX = /^[0-9a-f]*$/;

/** One transport message: hex fields only, bounded, and nothing believed beyond its shape. */
export function parseDkgWire(raw: unknown, what: string): DkgWire {
  const o = obj(raw, what);
  const int = (k: string, max: number): number => {
    const v = o[k];
    if (!Number.isSafeInteger(v) || (v as number) < 0 || (v as number) > max) throw new Refusal('malformed', `${what}.${k} must be an integer in 0..${max}`);
    return v as number;
  };
  const hex = (k: string, maxBytes: number): string => {
    const v = o[k];
    if (typeof v !== 'string' || v.length > maxBytes * 2 || v.length % 2 !== 0 || !HEX.test(v)) {
      throw new Refusal('malformed', `${what}.${k} must be at most ${maxBytes} bytes of lower-case hex, without 0x`);
    }
    return v;
  };
  return {
    v: int('v', 255), session: hex('session', 32), round: int('round', 3), from: int('from', 0xffffffff),
    to: int('to', 0xffffffff), transcript: hex('transcript', 32), payload: hex('payload', 4096), signature: hex('signature', 256),
  };
}

const chainOf = (o: Record<string, unknown>): number => {
  if (!Number.isSafeInteger(o.chainId)) throw new Refusal('malformed', 'chainId must be an integer');
  return o.chainId as number;
};

const bigintOf = (v: unknown, what: string): bigint => {
  if (typeof v === 'string' && /^(0|[1-9]\d{0,77})$/.test(v)) return BigInt(v);
  if (typeof v === 'string' && isHex(v) && v.length <= 66) return BigInt(v);
  throw new Refusal('malformed', `${what} must be an integer string`);
};

export function parseDkgStartRequest(body: unknown): DkgStartRequest {
  const o = obj(body, 'the request');
  const p = obj(o.passkey, 'passkey');
  if (typeof o.deviceKey !== 'string' || !isHex(o.deviceKey) || size(o.deviceKey) !== 33) {
    throw new Refusal('malformed', 'deviceKey must be a 33-byte compressed secp256k1 public key');
  }
  try {
    secp256k1.Point.fromBytes(hexToBytes(o.deviceKey as Hex)).assertValidity();
  } catch {
    throw new Refusal('malformed', 'deviceKey is not a point on secp256k1');
  }
  if (typeof o.context !== 'string' || !isHex(o.context) || size(o.context) < MIN_DKG_CONTEXT_BYTES || size(o.context) > MAX_DKG_CONTEXT_BYTES) {
    throw new Refusal('malformed', `context must be ${MIN_DKG_CONTEXT_BYTES}-${MAX_DKG_CONTEXT_BYTES} bytes of hex, fresh for this run`);
  }
  if (!Number.isSafeInteger(o.issuedAt)) throw new Refusal('malformed', 'issuedAt must be unix seconds');
  const passkeySignature = o.passkeySignature ?? '0x';
  if (typeof passkeySignature !== 'string' || !isHex(passkeySignature) || size(passkeySignature) > 8 * 1024) throw new Refusal('malformed', 'passkeySignature must be hex');
  if (o.rotates !== undefined && (typeof o.rotates !== 'string' || !isHex(o.rotates) || size(o.rotates) !== 33)) {
    throw new Refusal('malformed', 'rotates must be the current 33-byte compressed group key');
  }
  return {
    chainId: chainOf(o),
    passkey: { x: bigintOf(p.x, 'passkey.x'), y: bigintOf(p.y, 'passkey.y'), verifiers: bigintOf(p.verifiers, 'passkey.verifiers') },
    deviceKey: o.deviceKey as Hex, context: o.context as Hex, issuedAt: o.issuedAt as number,
    passkeySignature: passkeySignature as Hex, round1: parseDkgWire(o.round1, 'round1'),
    ...(o.rotates !== undefined ? { rotates: (o.rotates as string).toLowerCase() as Hex } : {}),
  };
}

const sessionIdOf = (o: Record<string, unknown>): Hex => {
  if (typeof o.sessionId !== 'string' || !isHex(o.sessionId) || size(o.sessionId) !== 32) throw new Refusal('malformed', 'sessionId must be 32 bytes of hex');
  return o.sessionId.toLowerCase() as Hex;
};

export function parseDkgRound2Request(body: unknown): DkgRound2Request {
  const o = obj(body, 'the request');
  return { chainId: chainOf(o), sessionId: sessionIdOf(o), message: parseDkgWire(o.message, 'message') };
}

export function parseDkgConfirmRequest(body: unknown): DkgConfirmRequest {
  const o = obj(body, 'the request');
  const passkeySignature = o.passkeySignature ?? '0x';
  if (typeof passkeySignature !== 'string' || !isHex(passkeySignature) || size(passkeySignature) > 8 * 1024) throw new Refusal('malformed', 'passkeySignature must be hex');
  return {
    chainId: chainOf(o), sessionId: sessionIdOf(o),
    confirmation: parseDkgWire(o.confirmation, 'confirmation'), passkeySignature: passkeySignature as Hex,
  };
}

/** `chainId:address`, lower-case: how a run, and the share it produces, name the account they are for. */
export const dkgAccountRef = (chainId: number, passkeySigner: Address): string => {
  if (!isAddress(passkeySigner, { strict: false })) throw new Refusal('malformed', 'the account reference must be an address');
  return `${chainId}:${passkeySigner.toLowerCase()}`;
};
