/**
 * What a device signs with its passkey to run a DKG with this service, and the shapes both halves exchange.
 *
 * Browser-safe on purpose: `client.ts` and `dkg.ts` both import it, so the challenge a wallet signs is the
 * one the service recomputes, byte for byte, and neither side owns the definition.
 *
 * TWO ASSERTIONS PER RUN, and no more. A DKG is three signed messages in each direction, and asking the
 * authenticator for one per message would be three user-verification prompts to make one key. Instead:
 *
 *   start    the passkey signs the run itself - the chain, the co-signer, the passkey, the device's per-run
 *            signing key and the context the session id derives from. That is what AUTHORISES the per-run
 *            key: from there the device's long-term key is that passkey, and the run's key is its delegate,
 *            good for this session id and nothing else
 *   confirm  the passkey signs the group key and transcript the device derived. The service compares them
 *            with its own before the share it generated is allowed to sign anything
 *
 * A stolen API key therefore cannot make this service generate a key with anything but the user's
 * authenticator, and cannot finish a run the user did not confirm.
 */
import { encodeAbiParameters, getAddress, keccak256, toHex, type Address, type Hex } from 'viem';

/** The device is participant 1, the service participant 2, as everywhere else in this package. */
export const DKG_DEVICE = 1;
export const DKG_SERVER = 2;
/** 2-of-2: both halves sign, always. */
export const DKG_THRESHOLD = 2;

export const DKG_START_TYPEHASH = keccak256(toHex(
  'MovaFrostDkgStart(uint256 chainId,address coSigner,bytes32 passkeyId,bytes32 deviceKeyHash,bytes32 serverKeyHash,bytes32 contextHash,uint64 issuedAt,bytes32 rotatesKeyHash)'));
/**
 * v2.0 L-08: the service does not sign DKG messages with the co-signer key the accounts name on-chain. It runs the
 * transport under a key of its own, and the co-signer key signs this once: a certificate naming that key, under a
 * type hash no transaction, operation or other challenge uses.
 */
export const DKG_TRANSPORT_KEY_TYPEHASH = keccak256(toHex(
  'MovaFrostDkgTransportKey(uint256 chainId,address coSigner,bytes32 transportKeyHash)'));
export const DKG_CONFIRM_TYPEHASH = keccak256(toHex(
  'MovaFrostDkgConfirm(uint256 chainId,address coSigner,bytes32 session,bytes32 groupKeyHash,bytes32 transcript)'));

export interface DkgPasskey {
  x: bigint;
  y: bigint;
  verifiers: bigint;
}

/** The fingerprint of a passkey, as the audit log writes it. */
export const dkgPasskeyId = (pk: { x: bigint; y: bigint }): Hex =>
  keccak256(encodeAbiParameters([{ type: 'uint256' }, { type: 'uint256' }], [pk.x, pk.y]));

/**
 * What the passkey signs to start a run. A 32-byte type hash leads the preimage, so it never collides with
 * an EIP-712 digest, an enrolment challenge or an operation digest.
 */
export function dkgStartChallenge(o: {
  chainId: number; coSigner: Address; passkey: { x: bigint; y: bigint }; deviceKey: Hex; serverKey: Hex; context: Hex; issuedAt: number;
  /** For a rotation (L-07): the group key the account signs with now, which the new key will replace. */
  rotates?: Hex;
}): Hex {
  return keccak256(encodeAbiParameters(
    [{ type: 'bytes32' }, { type: 'uint256' }, { type: 'address' }, { type: 'bytes32' }, { type: 'bytes32' }, { type: 'bytes32' }, { type: 'bytes32' }, { type: 'uint64' }, { type: 'bytes32' }],
    [DKG_START_TYPEHASH, BigInt(o.chainId), getAddress(o.coSigner), dkgPasskeyId(o.passkey),
      keccak256(o.deviceKey), keccak256(o.serverKey), keccak256(o.context), BigInt(o.issuedAt),
      o.rotates ? keccak256(o.rotates) : `0x${'00'.repeat(32)}`],
  ));
}

/** The service's DKG transport key, and the co-signer key's certificate over it (`GET /v1/frost/dkg/key`). */
export interface DkgTransportKey {
  /** 33-byte compressed secp256k1 public key. */
  key: Hex;
  /** The co-signer key's 65-byte signature over `dkgTransportKeyDigest`. */
  certificate: Hex;
}

/** What the co-signer key signs to name its DKG transport key. */
export function dkgTransportKeyDigest(o: { chainId: number; coSigner: Address; transportKey: Hex }): Hex {
  return keccak256(encodeAbiParameters(
    [{ type: 'bytes32' }, { type: 'uint256' }, { type: 'address' }, { type: 'bytes32' }],
    [DKG_TRANSPORT_KEY_TYPEHASH, BigInt(o.chainId), getAddress(o.coSigner), keccak256(o.transportKey)],
  ));
}

/** What the passkey signs to accept the key the run produced. */
export function dkgConfirmChallenge(o: {
  chainId: number; coSigner: Address; session: Hex; groupKey: Hex; transcript: Hex;
}): Hex {
  return keccak256(encodeAbiParameters(
    [{ type: 'bytes32' }, { type: 'uint256' }, { type: 'address' }, { type: 'bytes32' }, { type: 'bytes32' }, { type: 'bytes32' }],
    [DKG_CONFIRM_TYPEHASH, BigInt(o.chainId), getAddress(o.coSigner), o.session, keccak256(o.groupKey), o.transcript],
  ));
}

/* ------------------------------------------------------------------ the wire */

/** `DkgWireMessage` from @mova/mpc, as JSON carries it. Repeated here so the client's types need no import. */
export interface DkgWire {
  v: number;
  session: string;
  round: number;
  from: number;
  to: number;
  transcript: string;
  payload: string;
  signature: string;
}

export interface DkgStartRequest {
  chainId: number;
  /** The passkey that will be the account's recovery signer: the account this run is for. */
  passkey: DkgPasskey;
  /** The device's per-run signing key, compressed secp256k1, authorised by the assertion below. */
  deviceKey: Hex;
  /** The DKG context, at least 16 bytes: the session id derives from it, the threshold and the parties. */
  context: Hex;
  issuedAt: number;
  passkeySignature: Hex;
  round1: DkgWire;
  /**
   * A rotation (v2.0 L-07): the account's current group key, compressed, which this service holds a complete share
   * of for the same passkey. Without it, a run for a passkey that already has a key is refused (`dkg_exists`).
   */
  rotates?: Hex;
}

export interface DkgStartResult {
  sessionId: Hex;
  /** The account reference the run is keyed by: `chainId:passkeySigner`. */
  accountRef: Address;
  coSigner: Address;
  device: number;
  server: number;
  round1: DkgWire;
  /** Unix seconds; the run is abandoned after it. */
  expiresAt: number;
}

export interface DkgRound2Request {
  chainId: number;
  sessionId: Hex;
  /** The device's sealed share for the service. */
  message: DkgWire;
}

export interface DkgRound2Result {
  /** The service's sealed share for the device. */
  message: DkgWire;
  /** The service's view of the group key and DKG transcript, signed. */
  confirmation: DkgWire;
}

export interface DkgConfirmRequest {
  chainId: number;
  sessionId: Hex;
  confirmation: DkgWire;
  passkeySignature: Hex;
}

export interface DkgConfirmResult {
  accountRef: Address;
  /** Compressed secp256k1, what a FrostValidator or FrostSigner is installed with. */
  groupKey: Hex;
  transcript: Hex;
  /** Y_j for each participant, compressed; the device checks its own against its share. */
  verificationShares: { id: number; point: Hex }[];
  complete: true;
}
