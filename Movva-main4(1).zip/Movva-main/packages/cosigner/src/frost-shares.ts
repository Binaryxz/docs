/**
 * The server's FROST shares, for accounts whose owner is a FrostSigner (Safe) or whose root validator is a
 * FrostValidator (Kernel): one share of a 2-of-2 group per account, from the DKG in packages/mpc.
 *
 * A share alone signs nothing and reveals nothing about the group secret (docs/wallet-custody.md §5), but a
 * share plus the device's opened share is the account. A KMS cannot run FROST, so unlike the ECDSA key the
 * share has to be in this process to sign; what custody can still do is keep it off the disk in the clear:
 *
 *   encryptedFrostShares   ENVELOPE ENCRYPTION, the production store. Each share is encrypted under its own
 *                          random data key (AES-256-GCM); the data key is wrapped by a `ShareKeyWrapper` - a
 *                          KMS key that never leaves the KMS - and only the wrapped form is written. The AAD
 *                          binds the ciphertext to its record (`frostShareAad`). Shares are opened once, at
 *                          start-up, into memory.
 *   fileFrostShares        the PLAINTEXT file, for development. Production mode refuses it unless
 *                          COSIGNER_ALLOW_FROST_SHARE_FILE_IN_PRODUCTION=1 - a flag of its own, separate from
 *                          the signing key's COSIGNER_ALLOW_FILE_KEY_IN_PRODUCTION
 *   memoryFrostShares      tests and examples
 *
 * Wrappers: a KMS through a plugin module (`COSIGNER_FROST_KMS_MODULE` exporting `createShareKeyWrapper`), the
 * way the co-signer key's KMS backend is loaded; or `fileShareKeyWrapper`, a local AES-256 wrapping key in a
 * 0600 file, for development - it sits on the same disk as the shares, so production treats it as it treats
 * the plaintext file.
 *
 * WHAT THIS PROTECTS. The disk, its backups and snapshots, a volume mounted elsewhere: with a KMS wrapper,
 * none of them holds a usable share. It does not protect a running, compromised host, which can ask the KMS
 * to unwrap and read the process's memory - the same limit as any key that must be in memory to be used.
 *
 * WRITING. `dkg.ts` runs the DKG with the device over HTTP and stores its half here, so the store has a write
 * half (`FrostShareWriter`) and every record carries what the DKG bound it to:
 *
 *   accountRef    the account the DKG was run for. A FROST account has no address until the group key
 *                 exists - the address commits to the key - so the DKG is keyed by the one identifier that
 *                 exists beforehand: `chainId:passkeySigner`, the account's future recovery signer
 *   transcript    the DKG transcript both parties derived and the device's passkey signed, so the record says
 *                 WHICH run made it, and an auditor can line it up against the device's own record
 *   complete      false until the device confirmed the same group key and transcript. `shareFor` returns
 *                 only complete shares, so a DKG that stopped halfway leaves a share that cannot sign
 *
 * FILE FORMAT. A JSON array. Every entry has { "id": 2, "groupPublicKey": "0x<33 bytes compressed>",
 * "verificationShare": "0x<33 bytes compressed>", "accountRef": "31337:0x..", "transcript": "<64 hex>",
 * "createdAt": 1750000000, "complete": true } - the last four optional: an entry without them is a share placed
 * by hand, complete and bound to no account - and then ONE of:
 *
 *   "share": "0x<32 bytes>"                                     plaintext (fileFrostShares; legacy)
 *   "sealed": { "v": 1, "alg": "AES-256-GCM", "keyId": "..",    envelope (encryptedFrostShares)
 *               "wrappedKey": "0x..", "iv": "0x<12 bytes>",
 *               "ciphertext": "0x<32 bytes>", "tag": "0x<16 bytes>" }
 *
 * The verification share is public (the share times the generator) and is checked against the share once it is
 * read or opened, so a truncated, mismatched or wrongly decrypted entry refuses to start instead of producing
 * invalid signature shares. MIGRATION: `encryptedFrostShares` reads plaintext entries too - in development with
 * a warning, in production only with the flag above - and rewrites them sealed at once.
 */
import { createCipheriv, createDecipheriv, createHash, randomBytes } from 'node:crypto';
import { chmodSync, readFileSync, renameSync, statSync, writeFileSync } from 'node:fs';
import { Point, publicShareOf, type KeyShare, type PointT } from '@mova/mpc';
import { hexToBytes, isHex, toHex, type Hex } from 'viem';
import { KeyCustodyError } from './key.js';

/** One stored share, with what the DKG bound it to. */
export interface FrostShareRecord {
  readonly share: KeyShare;
  /** `chainId:passkeySigner`, lower-case; undefined for a share placed in the file by hand. */
  readonly accountRef?: string;
  /** The DKG transcript of the run that produced it, hex without `0x`. */
  readonly transcript?: string;
  /** Unix seconds. */
  readonly createdAt?: number;
  /** False while the device has not confirmed the group key: such a share never signs. */
  readonly complete: boolean;
}

export interface FrostShareStore {
  readonly custody: string;
  /** The share of `groupPublicKey`, if this service holds one AND its DKG completed. */
  shareFor(groupPublicKey: PointT): KeyShare | undefined;
}

/**
 * A store the DKG can write to. Every store here is a writer; one that is not simply means the service does not
 * offer the DKG routes.
 */
export interface FrostShareWriter extends FrostShareStore {
  /**
   * Record a share the DKG just produced, not yet confirmed by the device. Replaces a pending one. Durable when it
   * returns (or its promise resolves: the envelope store wraps a new data key first).
   */
  putPending(record: Omit<FrostShareRecord, 'complete'>): void | Promise<void>;
  /** Mark a pending share complete. Throws if there is none. The envelope store reseals it first (N-17). */
  complete(groupPublicKey: PointT): FrostShareRecord | Promise<FrostShareRecord>;
  /** Drop a pending share; a complete one is never dropped. */
  discardPending(groupPublicKey: PointT): void;
  record(groupPublicKey: PointT): FrostShareRecord | undefined;
  /** The record this service holds for an account reference, complete or not. */
  forAccount(accountRef: string): FrostShareRecord | undefined;
  /**
   * Every record for an account reference (v2.0 L-07): after a rotation's key generation an account has two complete
   * shares, the one it signs with and the one it is rotating to, until it adopts the new one and the old is retired.
   */
  forAccountAll(accountRef: string): FrostShareRecord[];
  /** Drop a complete share the account no longer names on-chain (L-07): it rotated to another this service holds. */
  retire(groupPublicKey: PointT): void;
}

export const isFrostShareWriter = (s: FrostShareStore | undefined): s is FrostShareWriter =>
  !!s && typeof (s as FrostShareWriter).putPending === 'function';

const keyOf = (p: PointT) => toHex(p.toBytes(true));
const INSPECT = Symbol.for('nodejs.util.inspect.custom');

function harden<T extends object>(o: T, label: () => string, json: () => unknown): T {
  Object.defineProperty(o, 'toJSON', { value: json, enumerable: false });
  Object.defineProperty(o, INSPECT, { value: label, enumerable: false });
  return Object.freeze(o);
}

function store(records: FrostShareRecord[], custody: string, persist?: (all: readonly FrostShareRecord[]) => void): FrostShareWriter {
  const byGroup = new Map(records.map((r) => [keyOf(r.share.groupPublicKey), r]));
  const save = () => persist?.([...byGroup.values()]);
  const w: FrostShareWriter = {
    custody,
    shareFor: (g) => {
      const r = byGroup.get(keyOf(g));
      return r?.complete ? r.share : undefined;
    },
    record: (g) => byGroup.get(keyOf(g)),
    forAccount: (accountRef) => [...byGroup.values()].find((r) => r.accountRef === accountRef),
    forAccountAll: (accountRef) => [...byGroup.values()].filter((r) => r.accountRef === accountRef),
    retire: (g) => {
      if (byGroup.delete(keyOf(g))) save();
    },
    putPending: (r) => {
      const key = keyOf(r.share.groupPublicKey);
      if (byGroup.get(key)?.complete) throw new KeyCustodyError('this service already holds a complete share of that group key');
      byGroup.set(key, { ...r, complete: false });
      save();
    },
    complete: (g) => {
      const r = byGroup.get(keyOf(g));
      if (!r) throw new KeyCustodyError('no share of that group key to complete');
      const done: FrostShareRecord = { ...r, complete: true };
      byGroup.set(keyOf(g), done);
      save();
      return done;
    },
    discardPending: (g) => {
      const r = byGroup.get(keyOf(g));
      if (r && !r.complete) {
        byGroup.delete(keyOf(g));
        save();
      }
    },
  };
  return harden(w, () => `FrostShareStore(${custody}, ${byGroup.size} groups)`, () => ({ custody, groups: byGroup.size }));
}

/** Shares held in memory. Tests, examples, and the in-memory half of the file stores. */
export function memoryFrostShares(shares: readonly KeyShare[] = [], custody = 'memory'): FrostShareWriter {
  return store(shares.map((share) => ({ share, complete: true })), custody);
}

/** The public half of an entry: everything but the share. */
function publicJson(r: FrostShareRecord): Record<string, unknown> {
  return {
    id: r.share.id,
    groupPublicKey: keyOf(r.share.groupPublicKey),
    verificationShare: keyOf(publicShareOf(r.share)),
    ...(r.accountRef ? { accountRef: r.accountRef } : {}),
    ...(r.transcript ? { transcript: r.transcript } : {}),
    ...(r.createdAt ? { createdAt: r.createdAt } : {}),
    complete: r.complete,
  };
}

/** The JSON one PLAINTEXT entry of the share file is. */
export function frostShareJson(r: FrostShareRecord): Record<string, unknown> {
  const { id, ...rest } = publicJson(r);
  return { id, share: toHex(r.share.share, { size: 32 }), ...rest };
}

/* ------------------------------------------------------------------ envelope encryption */

/**
 * Wraps and unwraps the data key of one share: a KMS key, which never leaves the KMS. `context` is the record's
 * AAD (`frostShareAad`); a wrapper must bind it, so a wrapped key unwraps only for the record it was made for.
 * Map a provider onto this:
 *
 *   AWS KMS   wrap = Encrypt(KeyId, Plaintext: dataKey, EncryptionContext: { "mova:frost-share": hex(context) })
 *             unwrap = Decrypt(CiphertextBlob, KeyId, the same EncryptionContext)
 *   GCP KMS   encrypt / decrypt with additionalAuthenticatedData = context
 *   PKCS#11   CKM_AES_KEY_WRAP_KWP, or CKM_AES_GCM with the context as AAD
 *
 * A plugin module named by COSIGNER_FROST_KMS_MODULE exports `createShareKeyWrapper(settings)` returning one.
 */
export interface ShareKeyWrapper {
  /** e.g. 'kms:aws', 'local'. Shown in /v1/info and the start-up log. Never key material. */
  readonly custody: string;
  /** Names the wrapping key (a KMS key ARN, a local key's fingerprint). Written beside every wrapped data key. */
  readonly keyId: string;
  wrap(dataKey: Uint8Array, context: Uint8Array): Promise<Uint8Array>;
  /** `keyId` is the one stored with the record, so a wrapper holding several keys (rotation) can pick. */
  unwrap(wrapped: Uint8Array, context: Uint8Array, keyId: string): Promise<Uint8Array>;
}

export const FROST_SHARE_AAD_DOMAIN = 'mova/cosigner/frost-share/v1';
/** v2 (v3.1 N-17): the AAD also binds whether the DKG completed, and its transcript. */
export const FROST_SHARE_AAD_DOMAIN_V2 = 'mova/cosigner/frost-share/v2';
export const FROST_SHARE_ALG = 'AES-256-GCM';

/**
 * The AAD of one sealed share: `domain ‖ 0x00 ‖ groupKey (33 bytes, compressed) ‖ accountRef (UTF-8; empty for
 * a share placed by hand) ‖ id (4 bytes, big-endian)`. Both ends are fixed-width, so it parses one way only. A
 * ciphertext moved to another group key, account reference or participant id does not decrypt.
 */
export function frostShareAad(groupPublicKey: PointT | Uint8Array, accountRef: string | undefined, id: number): Uint8Array {
  const g = groupPublicKey instanceof Uint8Array ? groupPublicKey : groupPublicKey.toBytes(true);
  if (g.length !== 33) throw new KeyCustodyError('a group key is 33 bytes, compressed');
  if (!Number.isSafeInteger(id) || id < 1 || id > 0xffff_ffff) throw new KeyCustodyError('a participant id is a positive 32-bit integer');
  const ref = Buffer.from(accountRef ?? '', 'utf8');
  const idBytes = Buffer.alloc(4);
  idBytes.writeUInt32BE(id);
  return Buffer.concat([Buffer.from(FROST_SHARE_AAD_DOMAIN, 'utf8'), Buffer.from([0]), g, ref, idBytes]);
}

/**
 * The v2 AAD: the v1 fields under the v2 domain, then `complete (1 byte) ‖ transcript (32 bytes; zero when absent)`.
 * So nobody with write access to the file can promote a pending share from an unconfirmed DKG to complete, or swap
 * the transcript that is its audit trail, without the share failing to open (N-17).
 */
export function frostShareAadV2(
  groupPublicKey: PointT | Uint8Array, accountRef: string | undefined, id: number, complete: boolean, transcript: string | undefined,
): Uint8Array {
  const v1 = frostShareAad(groupPublicKey, accountRef, id);
  const t = transcript === undefined ? Buffer.alloc(32) : Buffer.from(transcript, 'hex');
  if (t.length !== 32) throw new KeyCustodyError('a transcript is 32 bytes');
  const domain1 = Buffer.from(FROST_SHARE_AAD_DOMAIN, 'utf8').length;
  return Buffer.concat([Buffer.from(FROST_SHARE_AAD_DOMAIN_V2, 'utf8'), v1.subarray(domain1), Buffer.from([complete ? 1 : 0]), t]);
}

const aadOf = (v: 1 | 2, at: { groupPublicKey: PointT; accountRef?: string; id: number; complete?: boolean; transcript?: string }) =>
  v === 1 ? frostShareAad(at.groupPublicKey, at.accountRef, at.id) : frostShareAadV2(at.groupPublicKey, at.accountRef, at.id, at.complete ?? false, at.transcript);

interface Gcm { iv: Uint8Array; ciphertext: Uint8Array; tag: Uint8Array }

function gcmSeal(key: Uint8Array, plaintext: Uint8Array, aad: Uint8Array): Gcm {
  const iv = randomBytes(12);
  const c = createCipheriv('aes-256-gcm', key, iv);
  c.setAAD(aad);
  const ciphertext = Buffer.concat([c.update(plaintext), c.final()]);
  return { iv, ciphertext, tag: c.getAuthTag() };
}

/** Throws (a KeyCustodyError naming nothing secret) when the tag does not verify under this key and AAD. */
function gcmOpen(key: Uint8Array, g: Gcm, aad: Uint8Array, what: string): Buffer {
  // N-33: the tag is 16 bytes, exactly; Node would otherwise accept a truncated one, down to 4.
  if (g.tag.length !== 16) throw new KeyCustodyError(`${what} does not decrypt: its tag is not 16 bytes`);
  try {
    const d = createDecipheriv('aes-256-gcm', key, g.iv, { authTagLength: 16 });
    d.setAAD(aad);
    d.setAuthTag(g.tag);
    return Buffer.concat([d.update(g.ciphertext), d.final()]);
  } catch {
    throw new KeyCustodyError(`${what} does not decrypt: wrong key, or the record was altered or moved`);
  }
}

/** A sealed share, as written in the file. */
export interface SealedShareJson {
  /** 1: the AAD binds the group key, account and id. 2 (N-17): also `complete` and the transcript. */
  v: 1 | 2;
  alg: typeof FROST_SHARE_ALG;
  keyId: string;
  wrappedKey: Hex;
  iv: Hex;
  ciphertext: Hex;
  tag: Hex;
}

/** Encrypt one share under a fresh data key, and wrap that key (v2: `complete` and the transcript in the AAD). */
export async function sealFrostShare(
  r: Omit<FrostShareRecord, 'complete'> & { complete?: boolean }, wrapper: ShareKeyWrapper,
): Promise<SealedShareJson> {
  const aad = frostShareAadV2(r.share.groupPublicKey, r.accountRef, r.share.id, r.complete ?? false, r.transcript);
  const dataKey = randomBytes(32);
  const plaintext = Buffer.from(hexToBytes(toHex(r.share.share, { size: 32 })));
  try {
    const g = gcmSeal(dataKey, plaintext, aad);
    const wrapped = await wrapper.wrap(dataKey, aad);
    return { v: 2, alg: FROST_SHARE_ALG, keyId: wrapper.keyId, wrappedKey: toHex(wrapped), iv: toHex(g.iv), ciphertext: toHex(g.ciphertext), tag: toHex(g.tag) };
  } finally {
    dataKey.fill(0);
    plaintext.fill(0);
  }
}

/** Unwrap the data key and decrypt the share of one entry, under the AAD its public fields give. */
export async function openFrostShare(
  sealed: SealedShareJson, at: { groupPublicKey: PointT; accountRef?: string; id: number; complete?: boolean; transcript?: string },
  wrapper: ShareKeyWrapper, what = 'the FROST share',
): Promise<bigint> {
  const aad = aadOf(sealed.v, at);
  let dataKey: Uint8Array;
  try {
    dataKey = await wrapper.unwrap(hexToBytes(sealed.wrappedKey), aad, sealed.keyId);
  } catch (e) {
    if (e instanceof KeyCustodyError) throw new KeyCustodyError(`${what}: ${e.message}`);
    throw new KeyCustodyError(`${what}: its data key could not be unwrapped (${wrapper.custody}, key ${sealed.keyId})`);
  }
  if (dataKey.length !== 32) throw new KeyCustodyError(`${what}: the unwrapped data key is not 32 bytes`);
  const plaintext = gcmOpen(dataKey, { iv: hexToBytes(sealed.iv), ciphertext: hexToBytes(sealed.ciphertext), tag: hexToBytes(sealed.tag) }, aad, what);
  try {
    if (plaintext.length !== 32) throw new KeyCustodyError(`${what} is not 32 bytes`);
    return BigInt(`0x${plaintext.toString('hex')}`);
  } finally {
    plaintext.fill(0);
    dataKey.fill(0);
  }
}

/**
 * A wrapper whose key is in this process: AES-256-GCM over the data key with the record's AAD, `iv ‖ ct ‖ tag`.
 * Development, tests, and the inside of `fileShareKeyWrapper`. Its keyId is a fingerprint of the key, never
 * the key.
 */
export function localShareKeyWrapper(key: Uint8Array, custody = 'local'): ShareKeyWrapper {
  if (key.length !== 32) throw new KeyCustodyError('a wrapping key is 32 bytes');
  const k = Buffer.from(key);
  const keyId = `local:${createHash('sha256').update('mova/cosigner/frost-kek-id\0').update(k).digest('hex').slice(0, 16)}`;
  const wrapper: ShareKeyWrapper = {
    custody, keyId,
    wrap: async (dataKey, context) => {
      const g = gcmSeal(k, dataKey, context);
      return Buffer.concat([g.iv, g.ciphertext, g.tag]);
    },
    unwrap: async (wrapped, context, id) => {
      if (id !== keyId) throw new KeyCustodyError(`its data key was wrapped under ${id}, not under this wrapping key (${keyId})`);
      if (wrapped.length !== 12 + 32 + 16) throw new KeyCustodyError('its wrapped data key is not 60 bytes');
      return gcmOpen(k, { iv: wrapped.subarray(0, 12), ciphertext: wrapped.subarray(12, 44), tag: wrapped.subarray(44) }, context, 'its data key');
    },
  };
  return harden(wrapper, () => `ShareKeyWrapper(${custody}, ${keyId})`, () => ({ custody, keyId }));
}

/**
 * A local wrapping key in a file: 32 bytes of hex, mode 0600. For development. It lies on the same host as the
 * shares it protects, so production mode refuses it unless `allowInProduction`
 * (COSIGNER_ALLOW_FROST_SHARE_FILE_IN_PRODUCTION=1), exactly as it refuses the plaintext store.
 */
export function fileShareKeyWrapper(o: {
  path: string; production: boolean; allowInProduction?: boolean;
  readFile?: (p: string) => string; fileMode?: (p: string) => number;
}): ShareKeyWrapper {
  if (o.production && !o.allowInProduction) {
    throw new KeyCustodyError('a local FROST wrapping key file sits on the same disk as the shares and production mode refuses it: '
      + 'use COSIGNER_FROST_KMS_MODULE, or set COSIGNER_ALLOW_FROST_SHARE_FILE_IN_PRODUCTION=1 to accept it explicitly');
  }
  let raw: string;
  try {
    if (((o.fileMode ?? ((p) => statSync(p).mode))(o.path) & 0o077) !== 0) {
      throw new KeyCustodyError('the FROST wrapping key file is readable by group or others: chmod 600 it');
    }
    raw = (o.readFile ?? ((p) => readFileSync(p, 'utf8')))(o.path).trim();
  } catch (e) {
    if (e instanceof KeyCustodyError) throw e;
    throw new KeyCustodyError('the FROST wrapping key file could not be read');
  }
  const hex = (raw.startsWith('0x') ? raw : `0x${raw}`) as Hex;
  if (!isHex(hex) || hex.length !== 66) throw new KeyCustodyError('the FROST wrapping key file must hold 32 bytes of hex');
  return localShareKeyWrapper(hexToBytes(hex), 'local-file');
}

/** A wrapper from a plugin: the shape checked, and one round trip run, before any share is trusted to it. */
export async function checkShareKeyWrapper(w: unknown): Promise<ShareKeyWrapper> {
  const x = w as Partial<ShareKeyWrapper> | undefined;
  if (!x || typeof x.custody !== 'string' || typeof x.keyId !== 'string' || !x.keyId || typeof x.wrap !== 'function' || typeof x.unwrap !== 'function') {
    throw new KeyCustodyError('the FROST share wrapper must have custody, keyId, wrap(dataKey, context) and unwrap(wrapped, context, keyId)');
  }
  const probe = randomBytes(32);
  const context = Buffer.from(`${FROST_SHARE_AAD_DOMAIN}/self-test`, 'utf8');
  try {
    const back = await x.unwrap(await x.wrap(probe, context), context, x.keyId);
    if (Buffer.compare(Buffer.from(back), probe) !== 0) throw new Error('mismatch');
  } catch {
    throw new KeyCustodyError(`the FROST share wrapper (${x.custody}) failed its start-up round trip`);
  } finally {
    probe.fill(0);
  }
  return x as ShareKeyWrapper;
}

/* ------------------------------------------------------------------ the file */

interface ParsedEntry {
  id: number;
  groupPublicKey: PointT;
  verificationShare: PointT;
  accountRef?: string;
  transcript?: string;
  createdAt?: number;
  complete: boolean;
  share?: bigint;
  sealed?: SealedShareJson;
}

interface FileOptions {
  path: string;
  readFile?: (p: string) => string;
  fileMode?: (p: string) => number;
  /** Replaced in tests; by default the file is rewritten through a 0600 temporary file and renamed. */
  writeFile?: (p: string, content: string) => void;
  /** No file yet: an empty store the DKG fills. Default false, so a typo in the path is loud. */
  createIfMissing?: boolean;
}

function readEntries(o: FileOptions): ParsedEntry[] {
  let raw: unknown;
  try {
    if (((o.fileMode ?? ((p) => statSync(p).mode))(o.path) & 0o077) !== 0) {
      throw new KeyCustodyError('the FROST share file is readable by group or others: chmod 600 it');
    }
    raw = JSON.parse((o.readFile ?? ((p) => readFileSync(p, 'utf8')))(o.path));
  } catch (e) {
    if (e instanceof KeyCustodyError) throw e;
    if (o.createIfMissing && (e as NodeJS.ErrnoException)?.code === 'ENOENT') raw = [];
    else throw new KeyCustodyError('the FROST share file could not be read as JSON');
  }
  if (!Array.isArray(raw)) throw new KeyCustodyError('the FROST share file must be a JSON array');
  return raw.map((entry: unknown, i): ParsedEntry => {
    const e = (entry ?? {}) as Record<string, unknown>;
    const hex = (v: unknown, k: string, bytes: number): Hex => {
      if (typeof v !== 'string' || !isHex(v) || hexToBytes(v).length !== bytes) throw new KeyCustodyError(`FROST share [${i}].${k} must be ${bytes} bytes of hex`);
      return v;
    };
    if (!Number.isSafeInteger(e.id) || (e.id as number) < 1) throw new KeyCustodyError(`FROST share [${i}].id must be a positive integer`);
    let groupPublicKey: PointT;
    let verificationShare: PointT;
    try {
      groupPublicKey = Point.fromBytes(hexToBytes(hex(e.groupPublicKey, 'groupPublicKey', 33)));
      verificationShare = Point.fromBytes(hexToBytes(hex(e.verificationShare, 'verificationShare', 33)));
    } catch (err) {
      if (err instanceof KeyCustodyError) throw err;
      throw new KeyCustodyError(`FROST share [${i}] is not a valid share`);
    }
    if (e.accountRef !== undefined && typeof e.accountRef !== 'string') throw new KeyCustodyError(`FROST share [${i}].accountRef must be a string`);
    if (e.transcript !== undefined && (typeof e.transcript !== 'string' || !/^[0-9a-f]{64}$/.test(e.transcript))) throw new KeyCustodyError(`FROST share [${i}].transcript must be 32 bytes of hex`);
    if ((e.share === undefined) === (e.sealed === undefined)) throw new KeyCustodyError(`FROST share [${i}] must carry exactly one of share (plaintext) and sealed (encrypted)`);
    const out: ParsedEntry = {
      id: e.id as number, groupPublicKey, verificationShare,
      accountRef: e.accountRef as string | undefined, transcript: e.transcript as string | undefined,
      createdAt: Number.isSafeInteger(e.createdAt) ? (e.createdAt as number) : undefined,
      // An entry written by hand, before this file had a DKG behind it, is a complete share.
      complete: e.complete === undefined ? true : e.complete === true,
    };
    if (e.share !== undefined) {
      out.share = BigInt(hex(e.share, 'share', 32));
    } else {
      const s = (e.sealed ?? {}) as Record<string, unknown>;
      if ((s.v !== 1 && s.v !== 2) || s.alg !== FROST_SHARE_ALG) throw new KeyCustodyError(`FROST share [${i}].sealed is not a version this service reads (v 1 or 2, ${FROST_SHARE_ALG})`);
      if (typeof s.keyId !== 'string' || !s.keyId) throw new KeyCustodyError(`FROST share [${i}].sealed.keyId must name the wrapping key`);
      if (typeof s.wrappedKey !== 'string' || !isHex(s.wrappedKey) || s.wrappedKey.length < 4 || s.wrappedKey.length > 2 + 2 * 4096) {
        throw new KeyCustodyError(`FROST share [${i}].sealed.wrappedKey must be hex`);
      }
      out.sealed = {
        v: s.v as 1 | 2, alg: FROST_SHARE_ALG, keyId: s.keyId, wrappedKey: s.wrappedKey as Hex,
        iv: hex(s.iv, 'sealed.iv', 12), ciphertext: hex(s.ciphertext, 'sealed.ciphertext', 32), tag: hex(s.tag, 'sealed.tag', 16),
      };
    }
    return out;
  });
}

/** The share an entry carries, checked against its verification share. */
function toRecord(p: ParsedEntry, share: bigint, i: number): FrostShareRecord {
  const s: KeyShare = { id: p.id, share, groupPublicKey: p.groupPublicKey };
  let ok = false;
  try {
    ok = share > 0n && publicShareOf(s).equals(p.verificationShare);
  } catch {
    ok = false;
  }
  if (!ok) throw new KeyCustodyError(`FROST share [${i}] does not match its verification share`);
  return { share: s, accountRef: p.accountRef, transcript: p.transcript, createdAt: p.createdAt, complete: p.complete };
}

const defaultWrite = (p: string, content: string) => {
  const tmp = `${p}.tmp`;
  writeFileSync(tmp, content, { mode: 0o600 });
  chmodSync(tmp, 0o600);
  renameSync(tmp, p);
};

/**
 * The PLAINTEXT share file. Development only: production mode refuses it unless `allowInProduction`
 * (COSIGNER_ALLOW_FROST_SHARE_FILE_IN_PRODUCTION=1). It refuses a file with sealed entries - those need the
 * wrapper they were sealed under, through `encryptedFrostShares`.
 */
export function fileFrostShares(o: FileOptions & { production: boolean; allowInProduction?: boolean; warn?: (message: string) => void }): FrostShareWriter {
  if (o.production && !o.allowInProduction) {
    throw new KeyCustodyError('a plaintext FROST share file refuses to start in production mode: use an envelope-encrypted store '
      + '(COSIGNER_FROST_KMS_MODULE), or set COSIGNER_ALLOW_FROST_SHARE_FILE_IN_PRODUCTION=1 to accept plaintext shares on disk explicitly');
  }
  const entries = readEntries(o);
  const records = entries.map((p, i) => {
    if (p.sealed) {
      throw new KeyCustodyError(`FROST share [${i}] is sealed: open this file with its wrapping key (COSIGNER_FROST_KMS_MODULE or COSIGNER_FROST_WRAPPING_KEY_FILE)`);
    }
    return toRecord(p, p.share!, i);
  });
  o.warn?.(`FROST shares are stored in PLAINTEXT at ${o.path}: set COSIGNER_FROST_KMS_MODULE (production) or `
    + 'COSIGNER_FROST_WRAPPING_KEY_FILE (development) to encrypt them');
  const write = o.writeFile ?? defaultWrite;
  return store(records, 'file', (all) => write(o.path, `${JSON.stringify(all.map(frostShareJson), null, 2)}\n`));
}

/**
 * The ENVELOPE-ENCRYPTED share file: every share sealed under its own data key, wrapped by `wrapper`. Opens every
 * share at start-up (one unwrap each) and refuses to start if any does not open or does not match its
 * verification share.
 *
 * Plaintext entries - a file from before encryption - are read and sealed at once: in development with a warning,
 * in production only with `allowPlaintextInProduction` (COSIGNER_ALLOW_FROST_SHARE_FILE_IN_PRODUCTION=1).
 */
export async function encryptedFrostShares(o: FileOptions & {
  wrapper: ShareKeyWrapper;
  production: boolean;
  allowPlaintextInProduction?: boolean;
  warn?: (message: string) => void;
}): Promise<FrostShareWriter> {
  const wrapper = await checkShareKeyWrapper(o.wrapper);
  const entries = readEntries(o);
  const sealedBy = new Map<string, SealedShareJson>();
  const records: FrostShareRecord[] = [];
  let migrated = 0;
  for (const [i, p] of entries.entries()) {
    if (p.sealed) {
      const share = await openFrostShare(p.sealed, p, wrapper, `FROST share [${i}]`);
      const r = toRecord(p, share, i);
      records.push(r);
      // A v1 envelope left `complete` and the transcript unauthenticated: resealed as v2 at once (N-17).
      if (p.sealed.v === 1) {
        sealedBy.set(keyOf(r.share.groupPublicKey), await sealFrostShare(r, wrapper));
        migrated++;
      } else {
        sealedBy.set(keyOf(r.share.groupPublicKey), p.sealed);
      }
      continue;
    }
    if (o.production && !o.allowPlaintextInProduction) {
      throw new KeyCustodyError(`FROST share [${i}] is stored in plaintext and production mode refuses plaintext shares: migrate the file `
        + 'in development mode, or set COSIGNER_ALLOW_FROST_SHARE_FILE_IN_PRODUCTION=1 to migrate it here');
    }
    const r = toRecord(p, p.share!, i);
    records.push(r);
    sealedBy.set(keyOf(r.share.groupPublicKey), await sealFrostShare(r, wrapper));
    migrated++;
  }
  const write = o.writeFile ?? defaultWrite;
  const persist = (all: readonly FrostShareRecord[]) => write(o.path, `${JSON.stringify(all.map((r) => {
    const sealed = sealedBy.get(keyOf(r.share.groupPublicKey));
    if (!sealed) throw new KeyCustodyError('a FROST share has no sealed form to write');
    return { ...publicJson(r), sealed };
  }), null, 2)}\n`);
  const custody = `envelope:${wrapper.custody}`;
  const base = store(records, custody, persist);
  if (migrated > 0) {
    persist(records);
    o.warn?.(`${migrated} plaintext or v1-sealed FROST share(s) in ${o.path} were read and rewritten sealed (v2) under ${wrapper.keyId}; `
      + 'delete any copy or backup of the old file');
  }
  const w: FrostShareWriter = {
    custody,
    shareFor: base.shareFor,
    record: base.record,
    forAccount: base.forAccount,
    forAccountAll: base.forAccountAll,
    retire: (g) => {
      sealedBy.delete(keyOf(g));
      base.retire(g);
    },
    // Resealed with complete = true before the flag is written, so the file can only ever say "complete" in an
    // envelope the wrapper sealed that way (N-17).
    complete: async (g) => {
      const r = base.record(g);
      if (!r) throw new KeyCustodyError('no share of that group key to complete');
      sealedBy.set(keyOf(g), await sealFrostShare({ ...r, complete: true }, wrapper));
      return base.complete(g);
    },
    discardPending: base.discardPending,
    putPending: async (r) => {
      if (base.record(r.share.groupPublicKey)?.complete) throw new KeyCustodyError('this service already holds a complete share of that group key');
      // Sealed (and the data key wrapped by the KMS) before anything is written: the file never holds the share.
      const sealed = await sealFrostShare(r, wrapper);
      sealedBy.set(keyOf(r.share.groupPublicKey), sealed);
      base.putPending(r);
    },
  };
  return harden(w, () => `FrostShareStore(${custody})`, () => ({ custody }));
}
