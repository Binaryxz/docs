/**
 * The co-signer service, end to end, on a chain that has nothing on it until this script puts it there.
 *
 *   0. chain      its own anvil on 8930, the accounts stack from packages/smart-account/examples/_account-stack.ts
 *                 (mainnet's EntryPoint v0.7, Safe 1.4.1, Safe4337Module, passkey signer factory, Zodiac Delay,
 *                 Kernel v3.1; our validators and adapter; SponsorPaymaster; Alto on 8931), TestToken and TestVault
 *   0b. gate      SponsorGate (3 accounts a day) deployed and made the paymaster's owner; the governor sets the
 *                 paymaster's budgets through it and adds the co-signer's operator key; the old owner is refused
 *   1. service    the production entrypoint, src/bin/cosigner.ts, as a child process on 8932 (ops 8933): a
 *                 development key file (0600), a policy file allowlisting TestVault and approvals of TestToken
 *                 to it, API keys, an audit log; the sponsorship module (its own operator key file, at most 2
 *                 accounts a day) and recovery alerts (a VAPID key file, a state journal). A production-mode start
 *                 with a key file is refused, and so is one with a sponsorship key file. No key is ever printed.
 *   2. passkey    the service's TypeScript WebAuthn verdict against the deployed SafeWebAuthnSignerFactory's, for
 *                 a genuine assertion, its high-s twin, one over another digest, and one without user verification
 *   3. Safe       2-of-2 passkey signer + the service: enrolled over HTTP before it exists, which has the co-signer's
 *                 operator key create its passkey signer and sponsor it through the gate; its first operation
 *                 (recovery setup + approve + deposit) co-signed through the bundler; ERC-1271 through the service;
 *                 an owner addition and a direct token transfer refused; a device subscribed to recovery alerts;
 *                 a stolen passkey's queued drain pushed to a local push endpoint on 8934 and decrypted with the
 *                 subscription's keys - again a day later and within a day of the cooldown's end; unsubscribing
 *                 refused while it is queued; vetoed with a fresh passkey signature through /v1/veto, after which
 *                 the alerts stop; the server-alone veto attempts and the veto replayed refused; after the cooldown
 *                 the drain cannot execute
 *   4. Kernel     PasskeyCoSignerValidator with the service as co-signer, sponsored by the co-signer at enrolment,
 *                 which also creates the account itself through KernelFactory - so its first operation carries no
 *                 initCode, which is what a public bundler's rules need (docs/wallet-custody.md §10.3) - and a second
 *                 enrolment sends nothing; then the same as the Safe, with installModule and a rotateCoSigner to a
 *                 stranger refused
 *   4b. budget    the co-signer's own cap refusing a third account; the operator key used directly, as a thief would:
 *                 the gate admits what is left of its window and refuses the next account, and refuses the key every
 *                 owner power; the guardian revokes it, and the co-signer's next sponsorship is refused
 *   4c. DKG       a device and the service generate a FROST group key together over /v1/frost/dkg/*: three signed
 *                 rounds, the round-2 shares sealed to X25519 keys from round 1, two passkey assertions. The key
 *                 becomes a Kernel FrostValidator account, which signs its first operation and an ERC-1271 message
 *                 with device + server shares through the bundler; a second key generation for the same passkey is
 *                 refused, and the share file holds the server's half, complete, bound to the account and sealed
 *                 (AES-256-GCM under a per-share data key, wrapped by a development wrapping key file)
 *   5. records    the audit log (every decision, sponsorship and alert, codes, no key), /metrics, a clean SIGTERM
 *
 * The authenticator is software (real P-256 over the real WebAuthn payload); nothing else is simulated.
 * Every check prints OK or FAIL; the exit code is non-zero if any failed.
 *
 *   forge build                                    # at the root, for SponsorPaymaster's and SponsorGate's artifacts
 *   npx tsx packages/cosigner/examples/cosigner-live.ts
 *
 * ANVIL_PORT, BUNDLER_PORT, COSIGNER_PORT, COSIGNER_OPS_PORT and PUSH_PORT override the ports, within 8930-8939.
 * SPONSOR_GATE_ARTIFACT (or FOUNDRY_OUT) points at a SponsorGate artifact built somewhere other than forge-out.
 */
import { spawn, type ChildProcess } from 'node:child_process';
import { createECDH } from 'node:crypto';
import { chmodSync, existsSync, mkdtempSync, readFileSync, writeFileSync } from 'node:fs';
import { createServer, type IncomingHttpHeaders, type Server } from 'node:http';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { p256 } from '@noble/curves/nist';
import { sha256 } from '@noble/hashes/sha2';
import {
  createPublicClient, createWalletClient, defineChain, encodeFunctionData, formatEther, getAddress, hexToBytes, http, keccak256,
  parseAbi, parseEther, slice, toHex,
  type Address, type Hex, type LocalAccount,
} from 'viem';
import { generatePrivateKey, privateKeyToAccount } from 'viem/accounts';
import { INSTRUCTIONS_TYPES, KernelExecutor, SafeExecutor, instructionsDomain, passkeySafeOwner, type UserOpSubmitter } from '@mova/wallet';
import {
  DEFAULT_RECOVERY, DELAY_ABI, FROST_VALIDATOR_ABI, KERNEL_ABI, KERNEL_FACTORY_ABI, KERNEL_V3_1, PASSKEY, PASSKEY_COSIGNER_VALIDATOR_ABI, SIGNER_FACTORY_ABI, PasskeyAuthenticator,
  buildQueueRequest, encodeExecuteNextTx, encodeRotateCoSigner, encodeSignedQueue, encodeVeto, encodeWebAuthnSignature, frostInstallData,
  kernelInitData, kernelRecoverySetupCalls, parseTransactionAdded, passkeyCoSignerInstallData, passkeyCoSignerSigner, predictKernelAddress,
  predictSafeAddress, predictSignerAddress, recoverySetupCalls, verifiersValue,
  type KernelDeployment, type ModuleCall, type PackedUserOperation, type WebAuthnAssertion,
} from '@mova/smart-account';
import { LIVE_GAS, answers, deployAccountStack, jsonRpc, waitFor, type AccountStack } from '../../smart-account/examples/_account-stack.js';
import { Point } from '@mova/mpc';
import {
  CoSignerRefused, RemoteCoSigner, SPONSOR_GATE_ABI, WEBAUTHN_FACTORY_VERIFY_ABI, decryptPushPayload, generateVapidKeys, splitSafeSignature, userOpToWire,
  verifyWebAuthnSignature, type RecoveryAlertPayload,
} from '../src/index.js';

const ROOT = new URL('../../../', import.meta.url);
const port = (name: string, fallback: number) => {
  const p = Number(process.env[name] ?? fallback);
  if (!Number.isInteger(p) || p < 8930 || p > 8939) {
    console.error(`${name} must be within 8930-8939, got ${process.env[name]}`);
    process.exit(2);
  }
  return p;
};
const ANVIL_PORT = port('ANVIL_PORT', 8930);
const BUNDLER_PORT = port('BUNDLER_PORT', 8931);
const COSIGNER_PORT = port('COSIGNER_PORT', 8932);
const COSIGNER_OPS_PORT = port('COSIGNER_OPS_PORT', 8933);
const PUSH_PORT = port('PUSH_PORT', 8934);
const RPC = `http://127.0.0.1:${ANVIL_PORT}`;
const CHAIN_ID = 31337;
const chain = defineChain({ id: CHAIN_ID, name: 'cosigner-live', nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 }, rpcUrls: { default: { http: [RPC] } } });
const pub = createPublicClient({ chain, transport: http(RPC), pollingInterval: 250 });
// v2.0 I-61: this file signs with anvil's published dev keys, which anyone can use: refuse any chain but a local one.
void pub.getChainId().then((id) => {
  if (id !== 31_337 && id !== 1_337) { console.error(`refusing: anvil's public dev keys on chain ${id}; this runs on a local node only (I-61)`); process.exit(2); }
});
const wallet = createWalletClient({ chain, transport: http(RPC) });
// anvil's published dev key #0 deploys and sponsors; #8 and #9 are the bundler's (_account-stack.ts).
const funder = privateKeyToAccount('0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80');

/* ------------------------------------------------------------------ reporting */

let passed = 0;
let failed = 0;
const step = (s: string) => console.log(`\n\x1b[1m${s}\x1b[0m`);
const ok = (s: string) => { passed++; console.log(`  \x1b[32mOK\x1b[0m    ${s}`); };
const fail = (s: string) => { failed++; console.log(`  \x1b[31mFAIL\x1b[0m  ${s}`); };
const check = (condition: boolean, s: string, otherwise?: string) => (condition ? ok(s) : fail(otherwise ? `${s} - ${otherwise}` : s));
const info = (k: string, v: unknown) => console.log(`        ${k.padEnd(30)} ${v}`);
const message = (e: unknown) => (e instanceof Error ? e.message : String(e)).replace(/\s+/g, ' ');

async function refusedBy(label: string, code: string, run: () => Promise<unknown>): Promise<void> {
  try {
    await run();
    fail(`${label} was ACCEPTED`);
  } catch (e) {
    if (e instanceof CoSignerRefused && e.code === code) ok(`${label} - refused by the co-signer (${code})`);
    else fail(`${label} failed for another reason: ${message(e).slice(0, 300)}`);
  }
}

async function revertsWith(label: string, pattern: RegExp, run: () => Promise<unknown>): Promise<void> {
  try {
    await run();
    fail(`${label} was ACCEPTED`);
  } catch (e) {
    const m = message(e);
    if (pattern.test(m)) ok(`${label} - reverted (${m.match(pattern)![0]})`);
    else fail(`${label} failed for another reason: ${m.slice(0, 300)}`);
  }
}

async function section(title: string, body: () => Promise<void>): Promise<void> {
  step(title);
  try {
    await body();
  } catch (e) {
    fail(`${title.replace(/^\d+\.\s*/, '')} stopped: ${message(e).slice(0, 400)}`);
  }
}

/* ------------------------------------------------------------------ processes */

const children: ChildProcess[] = [];
let pushServer: Server | undefined;
const stopChildren = () => { for (const c of children) if (c.exitCode === null) c.kill('SIGTERM'); pushServer?.close(); };
process.on('exit', stopChildren);
process.on('SIGINT', () => { stopChildren(); process.exit(130); });

const rpc = <T>(method: string, params: unknown[] = []) => jsonRpc<T>(RPC, method, params);
const warp = async (seconds: number) => { await rpc('evm_increaseTime', [seconds]); await rpc('evm_mine'); };

async function send(to: Address, data: Hex, o: { value?: bigint; from?: LocalAccount; gas?: bigint } = {}) {
  const hash = await wallet.sendTransaction({ account: o.from ?? funder, chain, to, data, value: o.value ?? 0n, gas: o.gas });
  const receipt = await pub.waitForTransactionReceipt({ hash });
  if (receipt.status !== 'success') throw new Error(`transaction to ${to} reverted`);
  return receipt;
}

const TOKEN_ABI = parseAbi([
  'function mint(address to, uint256 amount)', 'function approve(address spender, uint256 amount) returns (bool)',
  'function transfer(address to, uint256 amount) returns (bool)', 'function balanceOf(address) view returns (uint256)',
]);
const VAULT_ABI = parseAbi(['function deposit(address token, uint256 amount)', 'function exit(address token)', 'function deposited(address depositor, address token) view returns (uint256)']);
const SAFE_ABI = parseAbi(['function addOwnerWithThreshold(address owner, uint256 threshold)', 'function getOwners() view returns (address[])']);
const PAYMASTER_ADMIN_ABI = parseAbi([
  'function owner() view returns (address)', 'function transferOwnership(address to)', 'function setSponsored(address account, bool isSponsored)',
  'function sponsored(address account) view returns (bool)', 'function withdrawTo(address to, uint256 amount)', 'error NotOwner()',
]);
const GATE_GOV_ABI = parseAbi([
  'function setBudget(uint256 window, uint256 perAccount)', 'function setMaxCostAllowed(uint256 maxCost)', 'function setOperator(address operator, bool allowed)',
  'function setMaxSponsorsPerWindow(uint32 count)', 'function setSponsored(address account, bool isSponsored)',
  'error NotGovernor()', 'error NotOperator()', 'error SponsorBudgetExhausted(uint256 wanted, uint256 remaining)',
]);
const GATE_BUDGET = 3;
const SPONSOR_CAP = 2;
const ZERO: Address = '0x0000000000000000000000000000000000000000';

/** A recording submitter in front of the bundler, so the script can replay what was sent. */
function recording(inner: UserOpSubmitter): UserOpSubmitter & { ops: PackedUserOperation[] } {
  const ops: PackedUserOperation[] = [];
  return { ops, submit: (op) => { ops.push(op); return inner.submit(op); } };
}

/* ------------------------------------------------------------------ the run */

async function main(): Promise<void> {
  let stack: AccountStack | undefined;
  let token: Address = '0x0000000000000000000000000000000000000000';
  let vault: Address = token;
  const relayer = privateKeyToAccount(generatePrivateKey());
  const stranger = privateKeyToAccount(generatePrivateKey()).address;
  const work = mkdtempSync(join(tmpdir(), 'cosigner-live-'));
  const serverKey = generatePrivateKey();
  const coSignerAddress = privateKeyToAccount(serverKey).address;
  const apiKey = toHex(crypto.getRandomValues(new Uint8Array(24))).slice(2);
  let childOutput = '';
  let cosignerProcess: ChildProcess | undefined;
  let remote: RemoteCoSigner | undefined;
  const auditLog = join(work, 'data', 'cosigner-audit.jsonl');
  // The DKG routes write the server's half of each group key here. There is no file until the first run.
  const frostShareFile = join(work, 'data', 'frost-shares.json');
  // Sponsorship: the co-signer's own operator key, a guardian who can revoke it, the gate once deployed.
  const operatorKey = generatePrivateKey();
  const operator = privateKeyToAccount(operatorKey);
  const guardian = privateKeyToAccount(generatePrivateKey());
  let gate: Address = ZERO;
  // Recovery alerts: the service's VAPID key, and what a local push service received.
  const vapid = generateVapidKeys();
  const pushes: { path: string; headers: IncomingHttpHeaders; body: Buffer }[] = [];
  const waitForPushes = async (n: number, timeoutMs = 30_000) => {
    const deadline = Date.now() + timeoutMs;
    while (pushes.length < n) {
      if (Date.now() > deadline) throw new Error(`expected ${n} push message(s), the push endpoint received ${pushes.length}`);
      await new Promise((r) => setTimeout(r, 200));
    }
  };
  const remaining = () => pub.readContract({ address: gate, abi: SPONSOR_GATE_ABI, functionName: 'remainingSponsorships' });
  const isSponsored = (account: Address) => pub.readContract({ address: stack!.paymaster, abi: PAYMASTER_ADMIN_ABI, functionName: 'sponsored', args: [account] });

  const mint = (to: Address, amount: bigint) => send(token, encodeFunctionData({ abi: TOKEN_ABI, functionName: 'mint', args: [to, amount] }));
  const balanceOf = (who: Address) => pub.readContract({ address: token, abi: TOKEN_ABI, functionName: 'balanceOf', args: [who] });
  const deposited = (who: Address) => pub.readContract({ address: vault, abi: VAULT_ABI, functionName: 'deposited', args: [who, token] });
  const approveAndDeposit = (amount: bigint) => [
    { to: token, data: encodeFunctionData({ abi: TOKEN_ABI, functionName: 'approve', args: [vault, amount] }) },
    { to: vault, data: encodeFunctionData({ abi: VAULT_ABI, functionName: 'deposit', args: [token, amount] }) },
  ];
  const typed = () => ({
    domain: instructionsDomain(CHAIN_ID, vault), types: INSTRUCTIONS_TYPES, primaryType: 'PaymentInstructionsRequest' as const,
    message: { orderId: keccak256(toHex(`order ${Date.now()} ${Math.random()}`)), issuedAt: BigInt(Math.floor(Date.now() / 1000)) },
  });
  const passkeyQueue = async (delay: Address, passkeySigner: Address, passkey: PasskeyAuthenticator, call: ModuleCall) => {
    const request = buildQueueRequest(delay, BigInt(CHAIN_ID), call);
    const receipt = await send(delay, encodeSignedQueue(request, passkeySigner, encodeWebAuthnSignature(passkey.sign(hexToBytes(request.hash)))), { from: relayer, gas: 2_000_000n });
    const added = receipt.logs.map((l) => parseTransactionAdded(l)).find((e) => e !== null);
    if (!added) throw new Error('queued, but no TransactionAdded event');
    return added;
  };
  const cosignerEnv = (over: Record<string, string> = {}) => ({
    PATH: process.env.PATH ?? '', HOME: process.env.HOME ?? '',
    RPC_URL: RPC, CHAIN_ID: String(CHAIN_ID), COSIGNER_MODE: 'development',
    COSIGNER_KEY_FILE: join(work, 'cosigner_key'), COSIGNER_POLICY_FILE: join(work, 'policy.json'), COSIGNER_API_KEYS_FILE: join(work, 'api_keys'),
    COSIGNER_AUDIT_LOG: auditLog, COSIGNER_FROST_SHARES_FILE: frostShareFile, COSIGNER_FROST_WRAPPING_KEY_FILE: join(work, 'frost_wrapping_key'),
    HOST: '127.0.0.1', PORT: String(COSIGNER_PORT), OPS_PORT: String(COSIGNER_OPS_PORT),
    COSIGNER_SPONSOR_GATE: gate, COSIGNER_SPONSOR_KEY_FILE: join(work, 'sponsor_key'), COSIGNER_SPONSOR_DAILY_CAP: String(SPONSOR_CAP),
    COSIGNER_SPONSOR_RATE_BURST: '10', COSIGNER_SPONSOR_CLIENT_RATE_BURST: '10',
    COSIGNER_ALERTS_VAPID_KEY_FILE: join(work, 'vapid.json'), COSIGNER_ALERTS_SUBJECT: 'mailto:ops@wallet.brl.example',
    COSIGNER_ALERTS_STATE: join(work, 'data', 'alerts.jsonl'), COSIGNER_ALERTS_CONFIRMATIONS: '2', COSIGNER_ALERTS_POLL_MS: '500',
    COSIGNER_PUSH_ALLOW_INSECURE: '1', ...over,
  });
  const bin = new URL('packages/cosigner/src/bin/cosigner.ts', ROOT).pathname;

  await section('0. A private chain, the accounts stack, a paymaster and a real bundler', async () => {
    for (const p of [ANVIL_PORT, COSIGNER_PORT, COSIGNER_OPS_PORT, PUSH_PORT]) {
      if (await answers(`http://127.0.0.1:${p}`)) throw new Error(`port ${p} is already in use; refusing to share another process's service`);
    }
    const anvilBin = new URL('.foundry-pinned/v0.3.0/anvil', ROOT).pathname;
    if (!existsSync(anvilBin)) throw new Error('no pinned anvil: run `bash scripts/foundry.sh path` first');
    const anvil = spawn(anvilBin, ['--port', String(ANVIL_PORT), '--chain-id', String(CHAIN_ID), '--silent'], { stdio: 'ignore' });
    children.push(anvil);
    await waitFor('anvil', async () => (await rpc<string>('eth_chainId')) === toHex(CHAIN_ID), anvil, 20_000);
    ok(`anvil ${await rpc<string>('web3_clientVersion')} on :${ANVIL_PORT}, chain ${CHAIN_ID}, empty`);
    const deployed = await deployAccountStack({ rpc: RPC, chain, publicClient: pub, funder, bundlerPort: BUNDLER_PORT, report: { ok, fail, info } });
    token = await deployed.deployMova('TestToken');
    vault = await deployed.deployMova('TestVault');
    ok('and for this run, from fixtures/mova: TestToken, TestVault');
    await send(relayer.address, '0x', { value: parseEther('1') });
    stack = deployed;
  });
  if (!stack) return;
  const { passkeyValidator, frostValidator, adapter, paymasterAndData, gasDeposit, bundlerLog } = stack;

  await section('0b. SponsorGate: the paymaster\'s owner, so the co-signer sponsors without the owner\'s key', async () => {
    const path = process.env.SPONSOR_GATE_ARTIFACT
      ?? join(process.env.FOUNDRY_OUT ? resolve(ROOT.pathname, process.env.FOUNDRY_OUT) : new URL('forge-out', ROOT).pathname, 'SponsorGate.sol', 'SponsorGate.json');
    if (!existsSync(path)) throw new Error(`${path} is missing: run \`forge build\` at the root, or set SPONSOR_GATE_ARTIFACT`);
    const artifact = JSON.parse(readFileSync(path, 'utf8')) as { bytecode: { object: Hex } };
    const hash = await wallet.deployContract({
      account: funder, chain, bytecode: artifact.bytecode.object, args: [stack!.paymaster, funder.address, guardian.address, GATE_BUDGET],
      abi: parseAbi(['constructor(address paymaster_, address governor_, address guardian_, uint32 maxSponsorsPerWindow_)']),
    });
    const deployedGate = getAddress((await pub.waitForTransactionReceipt({ hash })).contractAddress!);
    await send(stack!.paymaster, encodeFunctionData({ abi: PAYMASTER_ADMIN_ABI, functionName: 'transferOwnership', args: [deployedGate] }));
    // The governor (the old owner, here; a multisig in production) configures the paymaster through the gate. The gate
    // refuses operators while the paymaster bounds nothing, so the budgets come first.
    await send(deployedGate, encodeFunctionData({ abi: GATE_GOV_ABI, functionName: 'setBudget', args: [86_400n, parseEther('1')] }));
    await send(deployedGate, encodeFunctionData({ abi: GATE_GOV_ABI, functionName: 'setMaxCostAllowed', args: [parseEther('0.5')] }));
    await send(deployedGate, encodeFunctionData({ abi: GATE_GOV_ABI, functionName: 'setOperator', args: [operator.address, true] }));
    await send(operator.address, '0x', { value: parseEther('2') });
    await send(guardian.address, '0x', { value: parseEther('1') });
    gate = deployedGate;
    const [owner, budget, isOp] = await Promise.all([
      pub.readContract({ address: stack!.paymaster, abi: PAYMASTER_ADMIN_ABI, functionName: 'owner' }),
      pub.readContract({ address: gate, abi: SPONSOR_GATE_ABI, functionName: 'maxSponsorsPerWindow' }),
      pub.readContract({ address: gate, abi: SPONSOR_GATE_ABI, functionName: 'isOperator', args: [operator.address] }),
    ]);
    check(getAddress(owner) === gate && budget === GATE_BUDGET && isOp,
      `SponsorGate ${gate} owns the paymaster: ${budget} new accounts a day for operators; the co-signer's operator ${operator.address}; guardian ${guardian.address}`);
    await revertsWith('the old owner calling the paymaster directly', /NotOwner/, () => pub.simulateContract({
      account: funder, address: stack!.paymaster, abi: PAYMASTER_ADMIN_ABI, functionName: 'setSponsored', args: [stranger, true],
    }));
  });
  if (gate === ZERO) return;

  await section('1. The co-signer service: the production entrypoint, a development key file', async () => {
    writeFileSync(join(work, 'cosigner_key'), `${serverKey}\n`, { mode: 0o600 });
    chmodSync(join(work, 'cosigner_key'), 0o600);
    writeFileSync(join(work, 'api_keys'), `movva-live:${apiKey}\n`, { mode: 0o600 });
    writeFileSync(join(work, 'sponsor_key'), `${operatorKey}\n`, { mode: 0o600 });
    // The development wrapping key the FROST share file is sealed under (production: COSIGNER_FROST_KMS_MODULE).
    writeFileSync(join(work, 'frost_wrapping_key'), `${toHex(crypto.getRandomValues(new Uint8Array(32)))}\n`, { mode: 0o600 });
    writeFileSync(join(work, 'vapid.json'), JSON.stringify(vapid), { mode: 0o600 });
    writeFileSync(join(work, 'policy.json'), JSON.stringify({
      chainId: CHAIN_ID,
      deployment: { passkeyCoSignerValidator: passkeyValidator, frostValidator, kernelAvatarAdapter: adapter },
      targets: [{ address: vault, label: 'TestVault' }],
      tokens: [{ address: token, label: 'TestToken', transfer: false, dailyLimit: parseEther('5000').toString() }],
      window: { maxSeconds: 1800, vetoMaxSeconds: 900 },
      rateLimit: { burst: 20, perMinute: 60 },
      webauthn: { rpIds: ['wallet.brl.example'], origins: ['https://wallet.brl.example'] },
    }, null, 2));

    // Production mode refuses a key file unless the operator says so explicitly.
    const refused = spawn(process.execPath, ['--import', 'tsx', bin], { cwd: ROOT.pathname, env: cosignerEnv({ COSIGNER_MODE: 'production', PORT: String(COSIGNER_PORT), OPS_PORT: String(COSIGNER_OPS_PORT) }), stdio: ['ignore', 'pipe', 'pipe'] });
    let refusedOutput = '';
    refused.stdout!.on('data', (d) => { refusedOutput += d; });
    refused.stderr!.on('data', (d) => { refusedOutput += d; });
    const code = await new Promise<number | null>((resolve) => refused.on('exit', resolve));
    check(code === 2 && /production mode refuses it/.test(refusedOutput) && !refusedOutput.includes(serverKey.slice(2)),
      'COSIGNER_MODE=production with a key file: refuses to start (exit 2), naming the flag, never the key', `exit ${code}: ${refusedOutput.slice(0, 200)}`);
    // The co-signer's key file accepted explicitly, the sponsorship key file still refused: each key has its own flag.
    const sponsorRefused = spawn(process.execPath, ['--import', 'tsx', bin], {
      cwd: ROOT.pathname, env: cosignerEnv({ COSIGNER_MODE: 'production', COSIGNER_ALLOW_FILE_KEY_IN_PRODUCTION: '1', COSIGNER_PUSH_ALLOW_INSECURE: '' }), stdio: ['ignore', 'pipe', 'pipe'],
    });
    let sponsorRefusedOutput = '';
    sponsorRefused.stdout!.on('data', (d) => { sponsorRefusedOutput += d; });
    sponsorRefused.stderr!.on('data', (d) => { sponsorRefusedOutput += d; });
    const sponsorCode = await new Promise<number | null>((resolve) => sponsorRefused.on('exit', resolve));
    check(sponsorCode === 2 && /COSIGNER_SPONSOR_KEY_FILE is a development key custody/.test(sponsorRefusedOutput) && !sponsorRefusedOutput.includes(operatorKey.slice(2)),
      'production with the co-signer key file allowed but a sponsorship key file: still refused (exit 2), naming its own flag', `exit ${sponsorCode}: ${sponsorRefusedOutput.slice(0, 300)}`);
    check(/COSIGNER_FROST_WRAPPING_KEY_FILE keeps the wrapping key on the same disk/.test(sponsorRefusedOutput)
      && /COSIGNER_ALLOW_FROST_SHARE_FILE_IN_PRODUCTION=1/.test(sponsorRefusedOutput),
      'and the FROST share file\'s local wrapping key is refused too: the co-signer key\'s flag does not cover FROST shares', sponsorRefusedOutput.slice(0, 400));

    cosignerProcess = spawn(process.execPath, ['--import', 'tsx', bin], { cwd: ROOT.pathname, env: cosignerEnv(), stdio: ['ignore', 'pipe', 'pipe'] });
    children.push(cosignerProcess);
    cosignerProcess.stdout!.on('data', (d) => { childOutput += d; });
    cosignerProcess.stderr!.on('data', (d) => { childOutput += d; });
    await waitFor('the co-signer', async () => (await fetch(`http://127.0.0.1:${COSIGNER_OPS_PORT}/readyz`)).status === 200, cosignerProcess, 60_000);
    remote = new RemoteCoSigner({ url: `http://127.0.0.1:${COSIGNER_PORT}`, chainId: CHAIN_ID, apiKey });
    const i = await remote.info();
    check(getAddress(i.coSigner) === coSignerAddress && i.custody === 'file' && i.chainId === CHAIN_ID,
      `src/bin/cosigner.ts on :${COSIGNER_PORT} (ops :${COSIGNER_OPS_PORT}): co-signer ${i.coSigner}, custody ${i.custody}`);
    check(childOutput.includes(coSignerAddress) && !childOutput.includes(serverKey.slice(2)), 'the startup line names the address; the key is never printed');
    check(i.sponsorship?.gate === gate && i.sponsorship.operator === operator.address && i.sponsorship.dailyCap === SPONSOR_CAP && i.alerts?.vapidPublicKey === vapid.publicKey,
      `/v1/info: sponsorship through the gate from ${operator.address} (at most ${i.sponsorship?.dailyCap} a day), recovery alerts under VAPID key ${vapid.publicKey.slice(0, 12)}...`);
    check(childOutput.includes(operator.address) && !childOutput.includes(operatorKey.slice(2)) && !childOutput.includes(vapid.privateKey),
      'the startup lines name the operator\'s address; neither the operator key nor the VAPID private key is printed');
    // A local push service, standing in for FCM or Mozilla's: it keeps what it receives, encrypted, and answers 201.
    pushServer = createServer((rq, rs) => {
      const chunks: Buffer[] = [];
      rq.on('data', (c: Buffer) => chunks.push(c));
      rq.on('end', () => { pushes.push({ path: rq.url ?? '', headers: rq.headers, body: Buffer.concat(chunks) }); rs.writeHead(201); rs.end(); });
    });
    await new Promise<void>((r) => pushServer!.listen(PUSH_PORT, '127.0.0.1', () => r()));
    ok(`a local push endpoint on :${PUSH_PORT}`);
    const anonymous = await fetch(`http://127.0.0.1:${COSIGNER_PORT}/v1/info`);
    check(anonymous.status === 401, 'the API refuses a client without an API key (401)');
  });
  if (!remote) return;
  const cosigner = remote;

  await section('2. The passkey half: the service\'s TypeScript verdict against the deployed verifier\'s', async () => {
    const passkey = PasskeyAuthenticator.create('wallet.brl.example');
    const pk = passkey.publicKey();
    const digest = keccak256(toHex('a digest'));
    const onChain = async (a: WebAuthnAssertion) => (await pub.readContract({
      address: PASSKEY.signerFactory, abi: WEBAUTHN_FACTORY_VERIFY_ABI, functionName: 'isValidSignatureForSigner',
      args: [digest, encodeWebAuthnSignature(a), pk.x, pk.y, verifiersValue()],
    })) === '0x1626ba7e';
    const offChain = (a: WebAuthnAssertion) => verifyWebAuthnSignature(digest, encodeWebAuthnSignature(a), pk).ok;
    const N = p256.Point.Fn.ORDER;
    const genuine = passkey.sign(hexToBytes(digest));
    const resign = (flags: number): WebAuthnAssertion => {
      const authenticatorData = genuine.authenticatorData.slice();
      authenticatorData[32] = flags;
      const payload = new Uint8Array([...authenticatorData, ...sha256(genuine.clientDataJSON)]);
      const s = p256.sign(sha256(payload), passkey.export().privateKey, { prehash: false });
      return { ...genuine, authenticatorData, r: s.r, s: s.s };
    };
    const cases: [string, WebAuthnAssertion, boolean][] = [
      ['a genuine assertion', genuine, true],
      ['its high-s twin', { ...genuine, s: N - genuine.s }, true],
      ['an assertion over another digest', passkey.sign(hexToBytes(keccak256(toHex('another')))), false],
      ['an assertion without user verification', resign(0x01), false],
    ];
    for (const [what, a, expected] of cases) {
      const [c, t] = [await onChain(a), offChain(a)];
      check(c === expected && t === expected, `${what}: chain ${c ? 'accepts' : 'refuses'}, co-signer ${t ? 'accepts' : 'refuses'}`);
    }
  });

  /* ------------------------------------------------------------------ 3. Safe */

  await section('3. Safe 1.4.1 - passkey signer + the co-signer service, 2-of-2', async () => {
    const passkey = PasskeyAuthenticator.create('wallet.brl.example');
    const pk = passkey.publicKey();
    const signer = await predictSignerAddress(pub, pk);
    const owners = [signer, coSignerAddress];
    const saltNonce = BigInt(Date.now());
    const safe = await predictSafeAddress(pub, owners, 2, saltNonce);
    info('safe (counterfactual)', safe);
    await mint(safe, parseEther('1000'));
    const signerCodeBefore = await pub.getCode({ address: signer });

    const enrolled = await cosigner.enrol({ account: safe, type: 'safe', coSigner: coSignerAddress, passkey: pk, sign: (c) => passkey.sign(c), safe: { owners, threshold: 2, saltNonce } });
    check(enrolled.created && enrolled.enrolment.kind === 'safe-passkey' && getAddress(enrolled.enrolment.passkeySigner as string) === signer,
      'enrolled before it exists: bound to the passkey its CREATE2 address commits to, proven by a passkey assertion');
    check((!signerCodeBefore || signerCodeBefore === '0x') && !(await isSponsored(safe)) && enrolled.sponsorship?.status === 'pending',
      'the enrolment answers with its sponsorship pending: nobody had sponsored the Safe or created its passkey signer');
    const sponsorship = await cosigner.waitForSponsorship(safe, { timeoutMs: 90_000, intervalMs: 300 });
    const [signerTx, sponsorTx] = await Promise.all([pub.getTransaction({ hash: sponsorship.signerTx! }), pub.getTransaction({ hash: sponsorship.sponsorTx! })]);
    check(((await pub.getCode({ address: signer })) ?? '0x').length > 2 && getAddress(signerTx.from) === operator.address && getAddress(signerTx.to!) === PASSKEY.signerFactory,
      `the co-signer's operator key created the Safe's passkey signer through the canonical factory (${sponsorship.signerTx})`);
    check(await isSponsored(safe) && getAddress(sponsorTx.from) === operator.address && getAddress(sponsorTx.to!) === gate && getAddress(signerTx.from) !== coSignerAddress,
      `and sponsored it with SponsorGate.sponsor from the same key, never the co-signer key (${sponsorship.sponsorTx}); ${await remaining()} of ${GATE_BUDGET} left in the gate's window`);

    const cs = cosigner.safe({ safe, passkeySigner: signer, coSigner: coSignerAddress });
    const bundler = recording(stack!.submitter);
    const executor = cs.wrap(new SafeExecutor({
      safe, chainId: CHAIN_ID, owners: [passkeySafeOwner(signer, (c) => passkey.sign(c)), cs.owner], publicClient: pub, submitter: cs.submitter(bundler),
      deploy: { owners, threshold: 2, saltNonce }, gas: LIVE_GAS, paymasterAndData,
    }));

    const { delay, calls: recovery } = recoverySetupCalls(safe, signer);
    const before = await gasDeposit();
    const created = await executor.execute([...recovery, ...approveAndDeposit(parseEther('400'))]);
    info('first operation, bundle', created.transactionHash);
    const spent = before - await gasDeposit();
    check((await pub.getCode({ address: safe }))!.length > 2 && await deposited(safe) === parseEther('400'),
      'the first operation - recovery setup + approve + deposit - co-signed by the service over HTTP, through the bundler');
    check(await pub.getBalance({ address: safe }) === 0n && spent > 0n, `sponsored: the Safe holds 0 ETH; the paymaster paid ${formatEther(spent)} ETH`);
    check(await pub.readContract({ address: delay, abi: DELAY_ABI, functionName: 'isModuleEnabled', args: [signer] }), 'recovery installed by the same operation (the documented setup the policy allows)');

    const request = typed();
    check(await pub.verifyTypedData({ address: safe, signature: await executor.signTypedData(request), ...request }), 'ERC-1271: the owners\' SafeMessage signature, co-signed by the service, verifies');

    const sentBefore = bundler.ops.length;
    await refusedBy('adding an owner, signed by the genuine passkey', 'authority_change', () => executor.execute([
      { to: safe, data: encodeFunctionData({ abi: SAFE_ABI, functionName: 'addOwnerWithThreshold', args: [stranger, 1n] }) },
    ]));
    await refusedBy('a direct token transfer to a stranger', 'token_transfer_refused', () => executor.execute([
      { to: token, data: encodeFunctionData({ abi: TOKEN_ABI, functionName: 'transfer', args: [stranger, 1n] }) },
    ]));
    const safeOwners = await pub.readContract({ address: safe, abi: SAFE_ABI, functionName: 'getOwners' });
    check(bundler.ops.length === sentBefore && safeOwners.length === 2, 'nothing refused reached the bundler; the Safe still has its two owners');

    // The user's device subscribes to the Safe's recovery alerts: its push subscription and a fresh passkey assertion.
    const device = createECDH('prime256v1');
    device.generateKeys();
    const deviceAuth = crypto.getRandomValues(new Uint8Array(16));
    const endpoint = `http://127.0.0.1:${PUSH_PORT}/push/${toHex(crypto.getRandomValues(new Uint8Array(8))).slice(2)}`;
    const subscribed = await cosigner.subscribeAlerts({
      account: safe, coSigner: coSignerAddress, sign: (c) => passkey.sign(c),
      subscription: { endpoint, keys: { p256dh: device.getPublicKey('base64url'), auth: Buffer.from(deviceAuth).toString('base64url') } },
    });
    check(subscribed.created && subscribed.pending === 0, 'a device subscribed to the Safe\'s recovery alerts through /v1/alerts/subscribe, proven by a fresh passkey assertion');
    const readPush = (i: number) => JSON.parse(decryptPushPayload({ body: pushes[i]!.body, privateKey: device.getPrivateKey(), auth: deviceAuth }).toString('utf8')) as RecoveryAlertPayload;

    // A stolen passkey queues a drain. The wallet shows it; the user vetoes it with a fresh passkey signature.
    const drain: ModuleCall = { to: token, value: 0n, data: encodeFunctionData({ abi: TOKEN_ABI, functionName: 'transfer', args: [stranger, parseEther('600')] }) };
    const stolen = await passkeyQueue(delay, signer, passkey, drain);
    const queue = await cosigner.queue(safe);
    check(queue.pending.length === 1 && queue.pending[0]!.call?.data === drain.data && queue.vetoNonce === stolen.queueNonce + 1n,
      `/v1/queue shows the queued drain (nonce ${stolen.queueNonce}, executable after ${DEFAULT_RECOVERY.cooldownSeconds / 86400} days) and the veto nonce`);

    // With the app closed: the watcher sees TransactionAdded after two confirmations and pushes to the device.
    await rpc('evm_mine');
    await rpc('evm_mine');
    await waitForPushes(1);
    const alert = readPush(0);
    const createdAt = await pub.readContract({ address: delay, abi: DELAY_ABI, functionName: 'txCreatedAt', args: [stolen.queueNonce] }) as bigint;
    const auth = String(pushes[0]!.headers.authorization);
    check(pushes[0]!.path === new URL(endpoint).pathname && pushes[0]!.headers['content-encoding'] === 'aes128gcm' && auth.startsWith('vapid t=') && auth.endsWith(`k=${vapid.publicKey}`)
      && alert.type === 'mova.recovery-requested' && alert.body === 'Uma recuperação foi solicitada na sua conta Movva' && alert.kind === 'queued'
      && BigInt(alert.executableAt!) === createdAt + BigInt(DEFAULT_RECOVERY.cooldownSeconds),
      `the queued drain reached the device as a Web Push (aes128gcm, VAPID) once confirmed; decrypted with the subscription's keys: "${alert.body}", executable at ${alert.executableAt}`);
    const plain = JSON.stringify(alert).toLowerCase();
    check(Object.keys(alert).every((k) => ['v', 'type', 'title', 'body', 'kind', 'executableAt', 'tag'].includes(k))
      && !plain.includes(safe.slice(2).toLowerCase()) && !plain.includes(stranger.slice(2).toLowerCase()) && !pushes[0]!.body.includes(Buffer.from('recupera')),
      'the alert names no amount and no address, and the push service carried only ciphertext');
    await refusedBy('turning the Safe\'s alerts off while the drain is queued (a thief holding the passkey silencing them)', 'recovery_pending',
      () => cosigner.unsubscribeAlerts({ account: safe, coSigner: coSignerAddress, endpoint, sign: (c) => passkey.sign(c) }));
    await warp(86_400 + 120);
    await waitForPushes(2);
    const head = await pub.getBlock();
    await warp(Number(BigInt(alert.executableAt!) - 23n * 3600n - head.timestamp) + 10);
    await waitForPushes(3);
    check(readPush(1).kind === 'daily' && readPush(2).kind === 'final' && pushes.length === 3,
      `re-alerted a day later (${readPush(1).kind}) and within a day of the cooldown's end (${readPush(2).kind}), while a veto still works`);

    const vetoOp = await (async () => {
      await executor.execute([{ to: delay, data: encodeVeto(queue.vetoNonce!) }]);
      return bundler.ops.at(-1)!;
    })();
    const [txNonce, queueNonce] = await Promise.all([
      pub.readContract({ address: delay, abi: DELAY_ABI, functionName: 'txNonce' }),
      pub.readContract({ address: delay, abi: DELAY_ABI, functionName: 'queueNonce' }),
    ]);
    check(txNonce === queueNonce && (await cosigner.queue(safe)).pending.length === 0, 'vetoed through /v1/veto: setTxNonce past the queue, co-signed only with the passkey\'s fresh signature, sponsored');
    await rpc('evm_mine');
    await rpc('evm_mine');
    await new Promise((r) => setTimeout(r, 2_000));

    const { signature: _s, ...unsigned } = vetoOp;
    const validAfter = Number(BigInt(slice(vetoOp.signature, 0, 6)));
    const validUntil = Number(BigInt(slice(vetoOp.signature, 6, 12)));
    const passkeyHalf = splitSafeSignature(vetoOp.signature).entries.find((e) => e.kind === 'contract')!.signature;
    const firstOp = bundler.ops[0]!;
    const oldApproval = splitSafeSignature(firstOp.signature).entries.find((e) => e.kind === 'contract')!.signature;
    const payload = { kind: 'safe-operation' as const, account: safe, userOp: userOpToWire(unsigned), validAfter, validUntil };
    await refusedBy('a veto request with no passkey signature (the server alone)', 'passkey_required', () => cosigner.veto({ ...payload, passkeySignature: '0x' }));
    await refusedBy('a veto request carrying the passkey\'s old approval of another operation', 'bad_passkey_signature', () => cosigner.veto({ ...payload, passkeySignature: oldApproval }));
    await refusedBy('the executed veto, replayed with its genuine passkey signature', 'replayed', () => cosigner.veto({ ...payload, passkeySignature: passkeyHalf }));

    await warp(DEFAULT_RECOVERY.cooldownSeconds + 1);
    await revertsWith('executing the vetoed drain after the cooldown', /queue is empty|hashes do not match/i, () => pub.simulateContract({
      account: relayer.address, address: delay, abi: DELAY_ABI, functionName: 'executeNextTx', args: [drain.to, drain.value, drain.data, 0],
    }));
    check(await balanceOf(stranger) === 0n && await balanceOf(safe) === parseEther('600'), 'the thief got nothing; 600 tBRL still in the Safe');
    check(pushes.length === 3, `the alerts stopped once the drain was vetoed: ${pushes.length} pushes in all, none after the veto`);
    void encodeExecuteNextTx;
    void SIGNER_FACTORY_ABI;
  });

  /* ------------------------------------------------------------------ 4. Kernel */

  await section('4. Kernel v3.1 - PasskeyCoSignerValidator with the service as co-signer', async () => {
    const passkey = PasskeyAuthenticator.create('wallet.brl.example');
    const pk = passkey.publicKey();
    const deploy: KernelDeployment = {
      initData: kernelInitData({ rootValidator: passkeyValidator, validatorData: passkeyCoSignerInstallData({ passkey: pk, coSigner: coSignerAddress, site: { rpId: 'wallet.example.br', origin: 'https://wallet.example.br' } }) }),
      salt: toHex(BigInt(Date.now()), { size: 32 }),
    };
    const account = predictKernelAddress(deploy);
    info('kernel account (counterfactual)', account);
    await mint(account, parseEther('1000'));
    const codeBefore = await pub.getCode({ address: account });
    const enrolled = await cosigner.enrol({ account, type: 'kernel', coSigner: coSignerAddress, passkey: pk, sign: (c) => passkey.sign(c), kernel: { initData: deploy.initData, salt: deploy.salt as Hex } });
    check(enrolled.created && enrolled.enrolment.kind === 'kernel-passkey', 'enrolled before it exists: the validator configuration its address commits to names this co-signer');
    check((!codeBefore || codeBefore === '0x') && enrolled.sponsorship?.status === 'pending', 'the enrolment answers with its sponsorship pending: the account had no code');
    const sponsorship = await cosigner.waitForSponsorship(account, { timeoutMs: 90_000, intervalMs: 300 });
    const sponsorTx = await pub.getTransaction({ hash: sponsorship.sponsorTx! });
    check(!sponsorship.signerTx && getAddress(sponsorTx.from) === operator.address && await isSponsored(account),
      `sponsored by the co-signer's operator at enrolment, with no signer transaction (the Kernel account's first operation creates its signer) (${sponsorship.sponsorTx})`);
    // The account itself, deployed by the co-signer before any operation: a public bundler refuses a Kernel first
    // operation whose initCode creates the account through Kernel's meta factory (docs/wallet-custody.md §10.3).
    const accountTx = await pub.getTransaction({ hash: sponsorship.accountTx! });
    check(((await pub.getCode({ address: account })) ?? '0x').length > 2 && getAddress(accountTx.from) === operator.address
      && getAddress(accountTx.to!) === KERNEL_V3_1.factory && getAddress(accountTx.from) !== coSignerAddress,
      `the co-signer's operator key created the Kernel account itself through KernelFactory, before its first operation (${sponsorship.accountTx})`);
    check(getAddress(await pub.readContract({ address: KERNEL_V3_1.factory, abi: KERNEL_FACTORY_ABI, functionName: 'getAddress', args: [deploy.initData, deploy.salt as Hex] })) === account,
      'and it is exactly the account the enrolment checked: KernelFactory.getAddress over the enrolled initData and salt');

    // Enrolled again, now that it exists: nothing new is sent, and the sponsorship is reported as it stands.
    const operatorNonceBefore = await pub.getTransactionCount({ address: operator.address });
    const again = await cosigner.enrol({ account, type: 'kernel', coSigner: coSignerAddress, passkey: pk, sign: (c) => passkey.sign(c) });
    const afterAgain = await cosigner.sponsorship(account);
    check(!again.created && afterAgain.status === 'sponsored' && await pub.getTransactionCount({ address: operator.address }) === operatorNonceBefore,
      'a second enrolment of the same account deploys nothing and sponsors nothing: the operator key sent no further transaction');

    const cs = cosigner.kernel({ account, validator: passkeyValidator, coSigner: coSignerAddress });
    const bundler = recording(stack!.submitter);
    const executor = cs.wrap(new KernelExecutor({
      account, chainId: CHAIN_ID, publicClient: pub, submitter: cs.submitter(bundler), deploy, gas: LIVE_GAS, paymasterAndData,
      signer: passkeyCoSignerSigner({ validator: passkeyValidator, passkey: (c) => passkey.sign(c), coSigner: cs.coSign }),
    }));
    const passkeySigner = await predictSignerAddress(pub, pk);
    const { delay, calls: recovery } = kernelRecoverySetupCalls({ account, passkey: pk, passkeySigner, adapter, validator: passkeyValidator });
    const before = await gasDeposit();
    await executor.execute([...recovery, ...approveAndDeposit(parseEther('400'))]);
    const spent = before - await gasDeposit();
    const config = await pub.readContract({ address: passkeyValidator, abi: PASSKEY_COSIGNER_VALIDATOR_ABI, functionName: 'configOf', args: [account] });
    check(config.coSigner === coSignerAddress && await deposited(account) === parseEther('400'),
      'the first operation - recovery setup + approve + deposit - co-signed by the service, through the bundler');
    check(bundler.ops.length === 1 && bundler.ops[0]!.initCode === '0x' && bundler.ops[0]!.nonce === 0n,
      'and it carried no initCode: the account already existed, so the rules a public bundler enforces have nothing to refuse',
      `initCode ${bundler.ops[0]?.initCode?.slice(0, 20)}`);
    check(await pub.getBalance({ address: account }) === 0n && spent > 0n, `sponsored: the account holds 0 ETH; the paymaster paid ${formatEther(spent)} ETH`);
    const request = typed();
    check(await pub.verifyTypedData({ address: account, signature: await executor.signTypedData(request), ...request }), 'ERC-1271 over Kernel\'s wrapped hash, co-signed by the service, verifies');

    await refusedBy('installModule on the account, signed by the genuine passkey', 'authority_change', () => executor.execute([
      { to: account, data: encodeFunctionData({ abi: KERNEL_ABI, functionName: 'installModule', args: [1n, stranger, '0x'] }) },
    ]));
    await refusedBy('rotateCoSigner to a key the deployment does not list', 'authority_change', () => executor.execute([
      { to: passkeyValidator, data: encodeRotateCoSigner(stranger) },
    ]));
    const still = await pub.readContract({ address: passkeyValidator, abi: PASSKEY_COSIGNER_VALIDATOR_ABI, functionName: 'configOf', args: [account] });
    check(still.coSigner === coSignerAddress, 'the co-signer on-chain is unchanged');

    const drain: ModuleCall = { to: token, value: 0n, data: encodeFunctionData({ abi: TOKEN_ABI, functionName: 'transfer', args: [stranger, parseEther('600')] }) };
    await passkeyQueue(delay, passkeySigner, passkey, drain);
    const queue = await cosigner.queue(account);
    check(queue.pending.length === 1 && queue.vetoNonce === 1n, '/v1/queue shows the stolen passkey\'s queued drain');
    await executor.execute([{ to: delay, data: encodeVeto(queue.vetoNonce!) }]);
    check((await cosigner.queue(account)).pending.length === 0, 'vetoed through /v1/veto with a fresh passkey signature');
    await warp(DEFAULT_RECOVERY.cooldownSeconds + 1);
    await revertsWith('executing the vetoed drain after the cooldown', /queue is empty|hashes do not match/i, () => pub.simulateContract({
      account: relayer.address, address: delay, abi: DELAY_ABI, functionName: 'executeNextTx', args: [drain.to, drain.value, drain.data, 0],
    }));
    check(await balanceOf(stranger) === 0n, 'the thief got nothing');
  });

  /* ------------------------------------------------------------------ 4b. the budget, a stolen key, revocation */

  await section('4b. SponsorGate\'s budget, a stolen operator key, and revocation', async () => {
    const enrolNewSafe = async () => {
      const passkey = PasskeyAuthenticator.create('wallet.brl.example');
      const pk = passkey.publicKey();
      const owners = [await predictSignerAddress(pub, pk), coSignerAddress];
      const saltNonce = BigInt(Date.now()) * 1_000n + BigInt(Math.floor(Math.random() * 1_000));
      const safe = await predictSafeAddress(pub, owners, 2, saltNonce);
      return cosigner.enrol({ account: safe, type: 'safe', coSigner: coSignerAddress, passkey: pk, sign: (c) => passkey.sign(c), safe: { owners, threshold: 2, saltNonce } });
    };
    const third = await enrolNewSafe();
    check(third.sponsorship?.status === 'refused' && third.sponsorship.code === 'daily_cap',
      `a third account in 24 hours: the co-signer's own cap (${SPONSOR_CAP}) refuses it (daily_cap) before the gate's (${GATE_BUDGET}) is reached`, JSON.stringify(third.sponsorship));

    // The operator key stolen, and used directly against the gate.
    const left = await remaining();
    const victims = Array.from({ length: Number(left) }, () => privateKeyToAccount(generatePrivateKey()).address);
    for (const v of victims) await send(gate, encodeFunctionData({ abi: SPONSOR_GATE_ABI, functionName: 'sponsor', args: [v] }), { from: operator });
    check(await remaining() === 0n && (await Promise.all(victims.map(isSponsored))).every(Boolean),
      `with the operator key alone, a thief adds only the ${left} account(s) left in the gate's window: ${GATE_BUDGET} in the window in all`);
    const extra = privateKeyToAccount(generatePrivateKey()).address;
    await revertsWith(`the ${GATE_BUDGET + 1}th account in the window, from the same key`, /SponsorBudgetExhausted/, () => pub.simulateContract({
      account: operator, address: gate, abi: SPONSOR_GATE_ABI, functionName: 'sponsor', args: [extra],
    }));
    await revertsWith('the operator key withdrawing the gas deposit through the gate', /NotGovernor/, () => pub.simulateContract({
      account: operator, address: gate, abi: SPONSOR_GATE_ABI, functionName: 'withdrawTo', args: [operator.address, parseEther('1')],
    }));
    await revertsWith('the operator key withdrawing it from the paymaster directly', /NotOwner/, () => pub.simulateContract({
      account: operator, address: stack!.paymaster, abi: PAYMASTER_ADMIN_ABI, functionName: 'withdrawTo', args: [operator.address, parseEther('1')],
    }));
    await revertsWith('the operator key raising the gate\'s budget', /NotGovernor/, () => pub.simulateContract({
      account: operator, address: gate, abi: GATE_GOV_ABI, functionName: 'setMaxSponsorsPerWindow', args: [1_000],
    }));
    await revertsWith('the operator key lifting the paymaster\'s per-account gas budget', /NotGovernor/, () => pub.simulateContract({
      account: operator, address: gate, abi: GATE_GOV_ABI, functionName: 'setBudget', args: [0n, 0n],
    }));

    // The guardian revokes the key. The gate refuses it, and so does the co-signer, even in a fresh window.
    await send(gate, encodeFunctionData({ abi: GATE_GOV_ABI, functionName: 'setOperator', args: [operator.address, false] }), { from: guardian });
    await revertsWith('the revoked key sponsoring again', /NotOperator/, () => pub.simulateContract({
      account: operator, address: gate, abi: SPONSOR_GATE_ABI, functionName: 'sponsor', args: [extra],
    }));
    await warp(86_400 + 1);
    const nonceBefore = await pub.getTransactionCount({ address: operator.address });
    const fourth = await enrolNewSafe();
    await new Promise((r) => setTimeout(r, 1_000));
    check(fourth.sponsorship?.status === 'refused' && fourth.sponsorship.code === 'operator_revoked' && await pub.getTransactionCount({ address: operator.address }) === nonceBefore,
      'revoked by the guardian: in a fresh window the co-signer refuses the next sponsorship (operator_revoked) and sends nothing', JSON.stringify(fourth.sponsorship));
    await send(gate, encodeFunctionData({ abi: GATE_GOV_ABI, functionName: 'setSponsored', args: [extra, true] }));
    check(await isSponsored(extra), 'the governor still sponsors directly through the gate, outside the operators\' budget');
  });

  /* ------------------------------------------------------------------ 4c. a key generated with the device */

  await section('4c. Kernel v3.1 - FrostValidator, from a DKG the device and the service ran over HTTP', async () => {
    const passkey = PasskeyAuthenticator.create('wallet.brl.example');
    const pk = { ...passkey.publicKey(), verifiers: verifiersValue() };

    // The key generation itself: three signed rounds over /v1/frost/dkg/*, the shares sealed to X25519 keys
    // exchanged in round 1, and two user-verified assertions - one authorising the run, one accepting its key.
    const before = Date.now();
    const generated = await cosigner.runDkg({ passkey: pk, sign: (c) => passkey.sign(c), coSigner: coSignerAddress, label: 'cosigner-live' });
    const passkeySigner = await predictSignerAddress(pub, pk);
    info('group key', generated.groupKey);
    info('DKG transcript', generated.transcript);
    check(generated.keyShare.id === 1 && getAddress(generated.accountRef) === passkeySigner
      && toHex(generated.keyShare.groupPublicKey.toBytes(true)) === generated.groupKey,
      `a device and the service generated a 2-of-2 FROST key in ${Date.now() - before} ms: the device holds share 1, `
      + `the service share 2, and the run is keyed by the account's future recovery signer ${passkeySigner}`);
    const deviceVerification = generated.verificationShares.get(1)!;
    check(deviceVerification.equals(Point.BASE.multiply(generated.keyShare.share)),
      'the device\'s share matches the verification share both sides derived; neither half ever saw the other\'s');
    const sharesOnDisk = JSON.parse(readFileSync(frostShareFile, 'utf8')) as { id: number; groupPublicKey: string; accountRef: string; complete: boolean; transcript: string; share?: string; sealed?: { alg: string; keyId: string } }[];
    const stored = sharesOnDisk.find((r) => r.groupPublicKey.toLowerCase() === generated.groupKey.toLowerCase());
    check(sharesOnDisk.length === 1 && stored?.id === 2 && stored.complete === true
      && stored.accountRef === `${CHAIN_ID}:${passkeySigner.toLowerCase()}` && `0x${stored.transcript}` === generated.transcript,
      `the service stored its half in ${frostShareFile}: participant 2, complete, bound to the account and to this run's transcript`,
      JSON.stringify(sharesOnDisk.map((r) => ({ ...r, share: '<redacted>' }))));
    check(!!stored && stored.share === undefined && stored.sealed?.alg === 'AES-256-GCM' && /^local:/.test(stored.sealed.keyId),
      'sealed, not in the clear: AES-256-GCM under its own data key, wrapped by the wrapping key, bound to the group key, account and id',
      JSON.stringify(stored?.sealed ? { alg: stored.sealed.alg, keyId: stored.sealed.keyId } : { share: stored?.share === undefined ? 'absent' : 'PRESENT' }));
    check(!readFileSync(frostShareFile, 'utf8').includes(generated.keyShare.share.toString(16)),
      'and the DEVICE\'s share is nowhere in it: the two halves are different scalars, and neither side sent its own');
    await refusedBy('a second key generation for the same passkey', 'dkg_exists',
      () => cosigner.runDkg({ passkey: pk, sign: (c) => passkey.sign(c), coSigner: coSignerAddress }));

    // The key becomes an account: a Kernel v3.1 whose root validator is FrostValidator over the group key.
    const deploy: KernelDeployment = {
      initData: kernelInitData({ rootValidator: frostValidator, validatorData: frostInstallData(generated.keyShare.groupPublicKey) }),
      salt: toHex(BigInt(Date.now()), { size: 32 }),
    };
    const account = predictKernelAddress(deploy);
    info('kernel FROST account', account);
    const enrolled = await cosigner.enrol({ account, type: 'kernel', coSigner: coSignerAddress, passkey: pk, sign: (c) => passkey.sign(c), kernel: { initData: deploy.initData, salt: deploy.salt as Hex } });
    check(enrolled.created && enrolled.enrolment.kind === 'kernel-frost' && (enrolled.enrolment.groupKey as string).toLowerCase() === generated.groupKey.toLowerCase(),
      'enrolled by the group key its address commits to: the service holds a share of it, and the run was for this passkey');
    // The gate's governor pays this one's gas directly: 4b revoked the co-signer's operator key, so the
    // sponsorship module can neither allowlist it nor create it, and its first operation carries initCode.
    await send(gate, encodeFunctionData({ abi: GATE_GOV_ABI, functionName: 'setSponsored', args: [account, true] }));
    await mint(account, parseEther('1000'));

    const cs = cosigner.frostKernel({ account, validator: frostValidator, device: generated.keyShare, passkey: (c) => passkey.sign(c) });
    const bundler = recording(stack!.submitter);
    const executor = cs.wrap(new KernelExecutor({
      account, chainId: CHAIN_ID, publicClient: pub, submitter: cs.submitter(bundler), deploy, gas: LIVE_GAS, paymasterAndData,
      signer: cs.signer,
    }));
    const { calls: recovery } = kernelRecoverySetupCalls({ account, passkey: pk, passkeySigner, adapter, validator: frostValidator });
    const spentBefore = await gasDeposit();
    await executor.execute([...recovery, ...approveAndDeposit(parseEther('250'))]);
    const spent = spentBefore - await gasDeposit();
    const groupOnChain = await pub.readContract({ address: frostValidator, abi: FROST_VALIDATOR_ABI, functionName: 'groupKeyOf', args: [account] });
    check(await deposited(account) === parseEther('250') && bundler.ops.length === 1,
      'its first operation - recovery setup + approve + deposit - signed by device + server FROST shares, through the bundler');
    check(toHex(Point.fromAffine({ x: groupOnChain.x, y: groupOnChain.y }).toBytes(true)) === generated.groupKey,
      'and the FrostValidator on-chain holds exactly the key the DKG produced');
    check(await pub.getBalance({ address: account }) === 0n && spent > 0n, `sponsored: the account holds 0 ETH; the paymaster paid ${formatEther(spent)} ETH`);
    const request = typed();
    check(await pub.verifyTypedData({ address: account, signature: await executor.signTypedData(request), ...request }),
      'ERC-1271 over Kernel\'s wrapped hash, signed by the same two shares, verifies');
    await refusedBy('a direct token transfer out of the FROST account', 'token_transfer_refused', () => executor.execute([
      { to: token, data: encodeFunctionData({ abi: TOKEN_ABI, functionName: 'transfer', args: [stranger, parseEther('10')] }) },
    ]));
    check(await balanceOf(stranger) === 0n, 'the policy refuses a FROST account exactly as it refuses a co-signed one');
  });

  /* ------------------------------------------------------------------ 5. records */

  await section('5. The audit log, the metrics, and a clean stop', async () => {
    const lines = readFileSync(auditLog, 'utf8').trim().split('\n');
    const records = lines.map((l) => JSON.parse(l) as { t: string; route?: string; decision?: string; code?: string; client?: string });
    const decisions = records.filter((r) => r.t === 'decision');
    const signed = (route: string) => decisions.filter((d) => d.route === route && d.decision === 'signed').length;
    const codes = new Set(decisions.filter((d) => d.decision === 'refused').map((d) => d.code));
    info('audit records', `${records.length} (${records.filter((r) => r.t === 'enrol').length} enrolments, ${decisions.length} decisions)`);
    // Per account: the first operation and one ERC-1271 message on /v1/cosign, and one veto on /v1/veto.
    check(signed('cosign') === 6 && signed('veto') === 2,
      `every co-signature is on record: ${signed('cosign')} signed (3 operations, 3 messages; the last two are the FROST account's), ${signed('veto')} vetoes`);
    check(['authority_change', 'token_transfer_refused', 'passkey_required', 'bad_passkey_signature', 'replayed'].every((c) => codes.has(c)) && decisions.every((d) => d.client === 'movva-live'),
      `every refusal is on record with its code: ${[...codes].join(', ')}`);
    check(!lines.some((l) => l.includes(serverKey.slice(2)) || l.includes(apiKey)), 'the audit log holds no key and no API key');
    const dkgs = records.filter((r) => r.t === 'dkg') as unknown as { event: string; code?: string; accountRef: string; groupKey?: string; transcript?: string }[];
    const completed = dkgs.filter((r) => r.event === 'completed');
    check(dkgs.filter((r) => r.event === 'started').length === 1 && completed.length === 1
      && dkgs.some((r) => r.event === 'refused' && r.code === 'dkg_exists')
      && dkgs.every((r) => /^\d+:0x[0-9a-f]{40}$/.test(r.accountRef)),
      `key generation on record: ${dkgs.map((r) => r.code ?? r.event).join(', ')}, for ${completed[0]?.accountRef}`);
    const storedShares = JSON.parse(readFileSync(frostShareFile, 'utf8')) as { groupPublicKey: string; sealed: { ciphertext: string; wrappedKey: string } }[];
    check(completed[0]?.groupKey === storedShares[0]?.groupPublicKey
      && !lines.some((l) => l.includes(storedShares[0]!.sealed.ciphertext.slice(2)) || l.includes(storedShares[0]!.sealed.wrappedKey.slice(2))),
      'the audit log names the group key the run produced and never the share behind it, sealed or not');
    const sponsors = records.filter((r) => r.t === 'sponsor') as unknown as { outcome: string; code?: string; signerTx?: string; operator?: string }[];
    const granted = sponsors.filter((r) => r.outcome === 'sponsored');
    check(granted.length === 2 && granted.some((r) => r.signerTx) && granted.every((r) => r.operator === operator.address)
      && ['daily_cap', 'operator_revoked'].every((c) => sponsors.some((r) => r.code === c)),
      `sponsorships on record: ${sponsors.map((r) => r.code ?? r.outcome).join(', ')}`);
    const alertRecords = records.filter((r) => r.t === 'alert') as unknown as { event: string; alert?: string; delivered?: number; outcome?: string; code?: string }[];
    check(alertRecords.filter((r) => r.event === 'sent').map((r) => `${r.alert}:${r.delivered}`).join(',') === 'queued:1,daily:1,final:1'
      && alertRecords.some((r) => r.event === 'subscribed') && alertRecords.some((r) => r.event === 'refused' && r.code === 'recovery_pending')
      && alertRecords.some((r) => r.event === 'closed' && r.outcome === 'vetoed-or-executed'),
      `alerts on record: ${alertRecords.map((r) => r.alert ?? r.code ?? r.outcome ?? r.event).join(', ')}`);
    check(!lines.some((l) => l.includes(operatorKey.slice(2)) || l.includes(vapid.privateKey) || l.includes('/push/')), 'no operator key, VAPID key or push endpoint in the audit log');
    const metrics = await (await fetch(`http://127.0.0.1:${COSIGNER_OPS_PORT}/metrics`)).text();
    const authority = Number(/mova_cosigner_refusals_total\{code="authority_change"\} (\d+)/.exec(metrics)?.[1] ?? 0);
    check(authority >= 3 && /mova_cosigner_signatures_total\{kind="safe-passkey"\} \d+/.test(metrics)
      && /mova_cosigner_signatures_total\{kind="kernel-frost"\} 2\b/.test(metrics) && !metrics.includes(serverKey.slice(2)),
      `/metrics: ${authority} authority_change refusals, signatures by account kind (2 by the FROST account), no key`);
    check(/mova_cosigner_dkg_total\{result="completed"\} 1\b/.test(metrics) && /mova_cosigner_dkg_sessions_open 0\b/.test(metrics),
      '/metrics: 1 key generation completed, none still open');
    check(/mova_cosigner_sponsorships_total\{result="sponsored"\} 2\b/.test(metrics) && /mova_cosigner_push_total\{result="delivered"\} 3\b/.test(metrics) && /mova_cosigner_push_subscriptions 1\b/.test(metrics),
      '/metrics: 2 accounts sponsored, 3 alerts delivered, 1 device subscribed');
    cosignerProcess!.kill('SIGTERM');
    const code = await new Promise<number | null>((resolve) => (cosignerProcess!.exitCode !== null ? resolve(cosignerProcess!.exitCode) : cosignerProcess!.on('exit', resolve)));
    check(code === 0 && !childOutput.includes(serverKey.slice(2)) && !childOutput.includes(operatorKey.slice(2)) && !childOutput.includes(vapid.privateKey),
      'SIGTERM: the co-signer stopped cleanly, and its whole output never contained a key');
  });

  if (failed > 0 && bundlerLog) console.log(`\n  bundler log: ${bundlerLog}\n  co-signer output:\n${childOutput.split('\n').map((l) => `    ${l}`).join('\n')}`);
}

main()
  .catch((e) => fail(`unexpected: ${message(e)}`))
  .finally(() => {
    console.log(`\n  ${passed} OK, ${failed} FAIL`);
    stopChildren();
    process.exit(failed > 0 ? 1 : 0);
  });
