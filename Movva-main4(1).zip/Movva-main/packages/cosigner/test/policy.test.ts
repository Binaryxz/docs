import { describe, expect, it } from 'vitest';
import { concat, encodeAbiParameters, encodeFunctionData, getAddress, pad, parseAbi, toHex, type Address, type Hex } from 'viem';
import {
  DEFAULT_RECOVERY, KERNEL_ABI, MODULE_ABI, MULTISEND_CALL_ONLY, encodeKernelExecute, encodeRotateCoSigner, encodeVeto,
  kernelRecoverySetupCalls, predictDelayAddress, recoverySetupCalls,
} from '@mova/smart-account';
import { SafeExecutor } from '@mova/wallet/src/executor.js';
import {
  checkWindow, decodeKernelCallData, decodeSafeCallData, evaluateCalls, evaluateMessage, evaluateVeto,
  placeholderSignature, spliceSignature, splitSafeSignature, type DecodedCall, type PolicyAccount,
} from '../src/index.js';
import { Refusal } from '../src/refusal.js';
import {
  ADAPTER, CHAIN_ID, DEFAULT_TEST_POLICY, ESCROW, FCL_VERIFIERS, OTHER, PASSKEY_VALIDATOR, SAFE_ADMIN_ABI, SERVER, STRANGER, TOKEN,
  TOKEN_ABI, VAULT, approve, deposit, fakeSignerAddress,
} from './harness.js';

const policy = DEFAULT_TEST_POLICY();
const pk = { x: 0x1234n, y: 0x5678n, verifiers: FCL_VERIFIERS };
const passkeySigner = fakeSignerAddress(pk);
const safe = getAddress(`0x${'5a'.repeat(19)}fe`);
const kernel = getAddress(`0x${'4b'.repeat(19)}fe`);
const safeAccount: PolicyAccount = { account: safe, kind: 'safe-passkey', coSigner: SERVER, passkey: pk, passkeySigner, delay: predictDelayAddress(safe, DEFAULT_RECOVERY), recoveryInstalled: true };
const kernelAccount: PolicyAccount = { account: kernel, kind: 'kernel-passkey', coSigner: SERVER, passkey: pk, passkeySigner, delay: predictDelayAddress(kernel, DEFAULT_RECOVERY), validator: PASSKEY_VALIDATOR, kernelAdapter: ADAPTER, recoveryInstalled: true };

const call = (to: Address, data: Hex, value = 0n): DecodedCall => ({ to, data, value, operation: 0 });
const code = (f: () => unknown): string => {
  try {
    f();
  } catch (e) {
    if (e instanceof Refusal) return e.code;
    throw e;
  }
  return 'accepted';
};

describe('the call policy', () => {
  it('co-signs approve-to-a-target plus a call to that target, and counts the approval', () => {
    const v = evaluateCalls(policy, safeAccount, [approve(VAULT, 400n), deposit(400n)].map((c) => call(c.to, c.data)));
    expect(v.flow).toBe('calls');
    expect(v.spend).toEqual([{ asset: TOKEN, amount: 400n }]);
  });

  it('refuses a call to a contract the deployment does not list', () => {
    expect(code(() => evaluateCalls(policy, safeAccount, [call(STRANGER, '0x12345678')]))).toBe('target_not_allowed');
    expect(code(() => evaluateCalls(policy, safeAccount, [call(STRANGER, '0x', 1n)]))).toBe('target_not_allowed');
  });

  it('refuses an approval to anyone but a listed contract, a direct transfer, and any other token call', () => {
    expect(code(() => evaluateCalls(policy, safeAccount, [call(TOKEN, approve(STRANGER, 1n).data)]))).toBe('spender_not_allowed');
    expect(code(() => evaluateCalls(policy, safeAccount, [call(TOKEN, encodeFunctionData({ abi: TOKEN_ABI, functionName: 'transfer', args: [STRANGER, 1n] }))]))).toBe('token_transfer_refused');
    expect(code(() => evaluateCalls(policy, safeAccount, [call(TOKEN, '0x23b872dd')]))).toBe('token_call_refused');
  });

  it('refuses every authority change, on the account itself or on an allowlisted target', () => {
    const cases: [string, DecodedCall][] = [
      ['addOwnerWithThreshold', call(safe, encodeFunctionData({ abi: SAFE_ADMIN_ABI, functionName: 'addOwnerWithThreshold', args: [STRANGER, 1n] }))],
      ['swapOwner to an unlisted co-signer', call(safe, encodeFunctionData({ abi: SAFE_ADMIN_ABI, functionName: 'swapOwner', args: [passkeySigner, SERVER, STRANGER] }))],
      ['changeThreshold', call(safe, encodeFunctionData({ abi: SAFE_ADMIN_ABI, functionName: 'changeThreshold', args: [1n] }))],
      ['enableModule', call(safe, encodeFunctionData({ abi: SAFE_ADMIN_ABI, functionName: 'enableModule', args: [STRANGER] }))],
      ['setFallbackHandler', call(safe, encodeFunctionData({ abi: SAFE_ADMIN_ABI, functionName: 'setFallbackHandler', args: [STRANGER] }))],
      ['transferOwnership on a listed target', call(VAULT, encodeFunctionData({ abi: TOKEN_ABI, functionName: 'transferOwnership', args: [STRANGER] }))],
      ['the Delay\'s setTxCooldown', call(safeAccount.delay, encodeFunctionData({ abi: parseAbi(['function setTxCooldown(uint256)']), args: [0n] }))],
    ];
    for (const [what, c] of cases) expect(code(() => evaluateCalls(policy, safeAccount, [deposit(1n), c].map((x) => call(x.to, x.data)))), what).toBe('authority_change');
    const kernelCases: [string, DecodedCall][] = [
      ['installModule', call(kernel, encodeFunctionData({ abi: KERNEL_ABI, functionName: 'installModule', args: [1n, STRANGER, '0x'] }))],
      ['changeRootValidator', call(kernel, encodeFunctionData({ abi: KERNEL_ABI, functionName: 'changeRootValidator', args: [concat(['0x01', STRANGER]), '0x0000000000000000000000000000000000000000', '0x', '0x'] }))],
      ['upgradeTo', call(kernel, encodeFunctionData({ abi: parseAbi(['function upgradeTo(address)']), args: [STRANGER] }))],
      ['rotateCoSigner to an unlisted key', call(PASSKEY_VALIDATOR, encodeRotateCoSigner(STRANGER))],
    ];
    for (const [what, c] of kernelCases) expect(code(() => evaluateCalls(policy, kernelAccount, [c])), what).toBe('authority_change');
  });

  it('refuses installModule/upgradeTo as a Kernel operation\'s own callData, not only inside execute', () => {
    const data = encodeFunctionData({ abi: KERNEL_ABI, functionName: 'installModule', args: [1n, STRANGER, '0x'] });
    expect(code(() => decodeKernelCallData(data))).toBe('authority_change');
  });

  it('allows the documented recovery setup, exactly, at the start of the first operation', () => {
    const setup = recoverySetupCalls(safe, passkeySigner).calls.map((c) => call(c.to, c.data, c.value));
    const v = evaluateCalls(policy, safeAccount, [...setup, call(VAULT, deposit(1n).data)]);
    expect(v.flow).toBe('recovery-setup');
    const wrongSigner = recoverySetupCalls(safe, STRANGER).calls.map((c) => call(c.to, c.data, c.value));
    expect(code(() => evaluateCalls(policy, safeAccount, wrongSigner))).not.toBe('accepted');
    const shorter = recoverySetupCalls(safe, passkeySigner, { cooldownSeconds: DEFAULT_RECOVERY.cooldownSeconds + 1, expirationSeconds: DEFAULT_RECOVERY.expirationSeconds }).calls.map((c) => call(c.to, c.data, c.value));
    expect(code(() => evaluateCalls(policy, safeAccount, shorter))).not.toBe('accepted');
    const kernelSetup = kernelRecoverySetupCalls({ account: kernel, passkey: pk, passkeySigner, adapter: ADAPTER, validator: PASSKEY_VALIDATOR }).calls.map((c) => call(c.to, c.data));
    expect(evaluateCalls(policy, kernelAccount, kernelSetup).flow).toBe('recovery-setup');
  });

  it('allows a rotation only to a listed co-signer, and only alone', () => {
    const swap = call(safe, encodeFunctionData({ abi: SAFE_ADMIN_ABI, functionName: 'swapOwner', args: [passkeySigner, SERVER, OTHER] }));
    expect(evaluateCalls(policy, safeAccount, [swap]).flow).toBe('rotation');
    expect(code(() => evaluateCalls(policy, safeAccount, [swap, call(VAULT, deposit(1n).data)]))).toBe('authority_change');
    const swapPasskey = call(safe, encodeFunctionData({ abi: SAFE_ADMIN_ABI, functionName: 'swapOwner', args: [SERVER, passkeySigner, OTHER] }));
    expect(code(() => evaluateCalls(policy, safeAccount, [swapPasskey]))).toBe('authority_change');
    expect(evaluateCalls(policy, kernelAccount, [call(PASSKEY_VALIDATOR, encodeRotateCoSigner(OTHER))]).flow).toBe('rotation');
  });

  it('sends setTxNonce to the veto route, and requires a FROST account\'s first operation to install recovery', () => {
    expect(code(() => evaluateCalls(policy, safeAccount, [call(safeAccount.delay, encodeVeto(1n))]))).toBe('use_veto_route');
    const frost: PolicyAccount = { ...safeAccount, kind: 'safe-frost', recoveryInstalled: false };
    expect(code(() => evaluateCalls(policy, frost, [call(VAULT, deposit(1n).data)]))).toBe('recovery_setup_required');
  });
});

describe('the veto rule', () => {
  it('is exactly one setTxNonce on the account\'s Delay, skipping queued transactions', () => {
    const q = { txNonce: 0n, queueNonce: 1n };
    expect(evaluateVeto(safeAccount, [call(safeAccount.delay, encodeVeto(1n))], q)).toEqual({ nonce: 1n });
    expect(code(() => evaluateVeto(safeAccount, [call(safeAccount.delay, encodeVeto(1n))], { txNonce: 1n, queueNonce: 1n }))).toBe('nothing_to_veto');
    expect(code(() => evaluateVeto(safeAccount, [call(safeAccount.delay, encodeVeto(2n))], q))).toBe('veto_out_of_range');
    expect(code(() => evaluateVeto(safeAccount, [call(STRANGER, encodeVeto(1n))], q))).toBe('not_a_veto');
    expect(code(() => evaluateVeto(safeAccount, [call(safeAccount.delay, encodeVeto(1n)), call(VAULT, deposit(1n).data)], q))).toBe('not_a_veto');
    expect(code(() => evaluateVeto(safeAccount, [call(VAULT, deposit(1n).data)], q))).toBe('not_a_veto');
  });
});

describe('the validity window', () => {
  it('must exist, be open, and be short', () => {
    expect(code(() => checkWindow({ validAfter: 0, validUntil: 0 }, 1000n, 1800))).toBe('window_unbounded');
    expect(code(() => checkWindow({ validAfter: 0, validUntil: 1000 }, 1000n, 1800))).toBe('expired');
    expect(code(() => checkWindow({ validAfter: 0, validUntil: 1000 + 1801 }, 1000n, 1800))).toBe('window_too_long');
    expect(code(() => checkWindow({ validAfter: 0, validUntil: 1000 + 900 }, 1000n, 1800))).toBe('accepted');
  });
});

describe('messages', () => {
  const td = (verifyingContract: Address, primaryType = 'PaymentInstructionsRequest') => ({
    domain: { name: 'Mova-LP-Node', version: '1', chainId: CHAIN_ID, verifyingContract },
    types: { [primaryType]: [{ name: 'orderId', type: 'bytes32' }] }, primaryType, message: { orderId: pad('0x01', { size: 32 }) },
  });
  it('co-signs typed data for a listed contract on this chain, and never a permit', () => {
    expect(code(() => evaluateMessage(policy, CHAIN_ID, safeAccount, td(ESCROW)))).toBe('accepted');
    expect(code(() => evaluateMessage(policy, CHAIN_ID, safeAccount, td(STRANGER)))).toBe('message_not_allowed');
    expect(code(() => evaluateMessage(policy, CHAIN_ID, safeAccount, td(ESCROW, 'Permit')))).toBe('message_not_allowed');
    expect(code(() => evaluateMessage(policy, 1, safeAccount, td(ESCROW)))).toBe('message_not_allowed');
  });
});

describe('decoding what the executors build', () => {
  it('reads a Safe batch through MultiSendCallOnly and refuses any other DELEGATECALL', () => {
    const calls = decodeSafeCallData(SafeExecutor.callData([approve(VAULT, 5n), deposit(5n)]));
    expect(calls.map((c) => c.to)).toEqual([TOKEN, VAULT]);
    const rogue = encodeFunctionData({ abi: MODULE_ABI, functionName: 'executeUserOp', args: [STRANGER, 0n, '0x', 1] });
    expect(code(() => decodeSafeCallData(rogue))).toBe('delegatecall_refused');
    const multisendWithValue = encodeFunctionData({ abi: MODULE_ABI, functionName: 'executeUserOp', args: [MULTISEND_CALL_ONLY, 1n, '0x', 1] });
    expect(code(() => decodeSafeCallData(multisendWithValue))).toBe('delegatecall_refused');
  });

  it('reads Kernel SINGLE and BATCH, and refuses DELEGATECALL mode', () => {
    expect(decodeKernelCallData(encodeKernelExecute([deposit(1n)]))[0]!.to).toBe(VAULT);
    expect(decodeKernelCallData(encodeKernelExecute([approve(VAULT, 1n), deposit(1n)]))).toHaveLength(2);
    const delegate = encodeFunctionData({ abi: KERNEL_ABI, functionName: 'execute', args: [pad('0xff', { dir: 'right', size: 32 }), concat([STRANGER, '0x'])] });
    expect(code(() => decodeKernelCallData(delegate))).toBe('delegatecall_refused');
    const tryMode = encodeFunctionData({ abi: KERNEL_ABI, functionName: 'execute', args: [pad('0x0001', { dir: 'right', size: 32 }), concat([VAULT, pad(toHex(0n), { size: 32 })])] });
    expect(code(() => decodeKernelCallData(tryMode))).toBe('unsupported_call');
  });

  it('splits a Safe signature holding a placeholder, and splices the real one in exactly once', () => {
    const digest = pad('0xabcdef', { size: 32 });
    const placeholder = placeholderSignature(digest);
    const contractSig = encodeAbiParameters([{ type: 'bytes' }], ['0xdeadbeef']);
    const blob = concat([pad(toHex(0), { size: 6 }), pad(toHex(99), { size: 6 }),
      concat([pad(passkeySigner, { size: 32 }), pad(toHex(130), { size: 32 }), '0x00']), placeholder,
      pad(toHex(64), { size: 32 }), contractSig]);
    const split = splitSafeSignature(blob);
    expect(split.validUntil).toBe(99);
    expect(split.entries.map((e) => e.kind)).toEqual(['contract', 'eoa']);
    expect(split.entries[0]!.owner).toBe(passkeySigner);
    const real = `0x${'11'.repeat(64)}1b` as Hex;
    expect(spliceSignature(blob, placeholder, real)).toContain(real.slice(2));
    expect(() => spliceSignature(concat([blob, placeholder]), placeholder, real)).toThrow(/ambiguous/);
  });
});
