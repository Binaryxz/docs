import { afterEach, describe, expect, it } from 'vitest';
import { serveCoSigner } from '../src/index.js';
import { world } from './harness.js';

const TOKEN = 'proxy-client-token-0123456789abcdefghij';
const closers: (() => Promise<void>)[] = [];
afterEach(async () => { while (closers.length) await closers.pop()!(); });

/** One GET /v1/info with the given X-Forwarded-For, as a client behind the proxy sends it. */
async function info(port: number, forwarded: string): Promise<number> {
  const r = await fetch(`http://127.0.0.1:${port}/v1/info`, {
    headers: { authorization: `Bearer ${TOKEN}`, 'x-forwarded-for': forwarded },
  });
  await r.arrayBuffer();
  return r.status;
}

/**
 * v3.1 N-12: behind a proxy the client address is the entry the proxy appended - the right-most, or `hops` from the
 * right - never the left-most, which the client writes. A forged left part no longer buys a fresh rate-limit bucket.
 */
describe('the client address behind a trusted proxy (N-12)', () => {
  it('reads the hop the proxy appended, so a forged X-Forwarded-For shares one bucket', async () => {
    const s = serveCoSigner(world().service, {
      mode: 'api', apiKeys: [{ name: 'wallet', token: TOKEN }], trustProxy: 1, clientRateLimit: { burst: 2, perMinute: 1 },
    });
    const port = await s.listen(0);
    closers.push(s.close);
    expect(await info(port, '10.0.0.1, 203.0.113.5')).toBe(200);
    expect(await info(port, '10.0.0.2, 203.0.113.5')).toBe(200);
    // Another forged left-most address, the same real client: refused.
    expect(await info(port, '10.0.0.3, 203.0.113.5')).toBe(429);
    // Another real client has its own bucket.
    expect(await info(port, '10.0.0.3, 203.0.113.6')).toBe(200);
  });

  it('two proxies: the entry two hops from the right', async () => {
    const s = serveCoSigner(world().service, {
      mode: 'api', apiKeys: [{ name: 'wallet', token: TOKEN }], trustProxy: 2, clientRateLimit: { burst: 1, perMinute: 1 },
    });
    const port = await s.listen(0);
    closers.push(s.close);
    expect(await info(port, 'forged, 198.51.100.9, 10.1.1.1')).toBe(200);
    expect(await info(port, 'forged-again, 198.51.100.9, 10.1.1.2')).toBe(429);
  });
});
