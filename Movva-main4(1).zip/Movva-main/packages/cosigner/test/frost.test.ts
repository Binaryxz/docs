import { describe, expect, it } from 'vitest';
import { getAddress, hexToBytes, pad, toHex, type Address, type Hex } from 'viem';
import { Point, aggregate, commit, sign, verify, type Commitment, type KeyShare, twoOfTwoCheck } from '@mova/mpc';
import { encodeVeto, frostInstallData, kernelInitData, kernelRecoverySetupCalls, predictKernelAddress, recoverySetupCalls } from '@mova/smart-account';
import { parseFrostCommitRequest, policyOf, type CoSignerServiceOptions, type FrostCommitRequest, type FrostSignRequest } from '../src/index.js';
import {
  CHAIN_ID, FROST_VALIDATOR, ADAPTER, DEFAULT_TEST_POLICY, TOKEN, deposit, dkg, enrolmentProof, expectRefusal, fakeSignerAddress, kernelOp, safeOp,
  sig, world, type World,
} from './harness.js';

const k = (a: string) => a.toLowerCase();
const FROST_SIGNER = getAddress(`0x${'f5'.repeat(20)}`);

async function frostSafe(o: { rateLimit?: { burst: number; perMinute: number }; service?: Partial<CoSignerServiceOptions> } = {}) {
  const [device, server] = dkg('cosigner frost safe');
  const policy = o.rateLimit ? policyOf({ ...DEFAULT_TEST_POLICY(), rateLimit: o.rateLimit }) : undefined;
  const w = world({ frostShares: [server], policy, extra: () => o.service ?? {} });
  const account = getAddress(`0x${'5f'.repeat(20)}`);
  const g = device.groupPublicKey.toAffine();
  w.chain.code.add(k(account));
  w.chain.code.add(k(FROST_SIGNER));
  w.chain.safes.set(k(account), { owners: [FROST_SIGNER], threshold: 1n, modules: [] });
  w.chain.frostSigners.set(k(FROST_SIGNER), { x: g.x, y: g.y });
  const passkeySigner = w.chain.deploySigner(w.pk);
  const delay = w.chain.installDelay(account, passkeySigner);
  const { enrolment } = await w.service.enrol({ chainId: CHAIN_ID, account, type: 'safe', ...enrolmentProof(w, account) }, w.caller);
  return { w, device, server, account, delay, enrolment };
}

const wire = (c: Commitment) => c;

/**
 * Both rounds as the device runs them: the commit carries the payload and an assertion over `digest`; the sign
 * carries the same assertion unless `passkeySignature` stands in for it.
 */
async function session(w: World, device: KeyShare, account: Address, digest: Hex, req: Omit<FrostSignRequest, 'sessionId' | 'commitments' | 'passkeySignature'>, o: { passkeySignature?: Hex } = {}) {
  void account;
  const server = await w.service.frostCommit({ ...req, passkeySignature: sig(w, digest) }, w.caller);
  const { nonces, commitment } = commit(device);
  const serverCommitment: Commitment = {
    id: server.commitment.id,
    hiding: (await import('@mova/mpc')).Point.fromBytes(hexToBytes(server.commitment.hiding)),
    binding: (await import('@mova/mpc')).Point.fromBytes(hexToBytes(server.commitment.binding)),
  };
  const commitments = [commitment, serverCommitment].map(wire);
  const full: FrostSignRequest = { ...req, sessionId: server.sessionId, commitments, passkeySignature: o.passkeySignature ?? sig(w, digest) };
  return { full, nonces, commitments, sessionId: server.sessionId };
}

describe('FROST: the server participant, passkey first, nonces single-use', () => {
  it('enrols a FrostSigner Safe by its group key and its Delay\'s passkey, and refuses ECDSA co-signing for it', async () => {
    const { w, account, enrolment } = await frostSafe();
    expect(enrolment).toMatchObject({ kind: 'safe-frost', frostSigner: FROST_SIGNER, passkeySigner: fakeSignerAddress(w.pk) });
    const op = safeOp(w, account, [deposit(1n)]);
    await expectRefusal(w.service.cosign({ chainId: CHAIN_ID, account, kind: 'safe-operation', ...op, passkeySignature: sig(w, op.digest) }, w.caller), 'wrong_account_kind');
  });

  it('refuses to enrol a group it holds no share of', async () => {
    const [device] = dkg('someone else\'s group');
    const { w } = await frostSafe();
    const other = getAddress(`0x${'6f'.repeat(20)}`);
    const signer = getAddress(`0x${'f6'.repeat(20)}`);
    const g = device.groupPublicKey.toAffine();
    w.chain.code.add(k(other));
    w.chain.code.add(k(signer));
    w.chain.safes.set(k(other), { owners: [signer], threshold: 1n, modules: [] });
    w.chain.frostSigners.set(k(signer), { x: g.x, y: g.y });
    await expectRefusal(w.service.enrol({ chainId: CHAIN_ID, account: other, type: 'safe', ...enrolmentProof(w, other) }, w.caller), 'no_share');
  });

  it('signs its share only after the passkey signed the same digest; the aggregate verifies', async () => {
    const { w, device, account } = await frostSafe();
    const op = safeOp(w, account, [deposit(1n)]);
    const s = await session(w, device, account, op.digest, { chainId: CHAIN_ID, account, kind: 'safe-operation', ...op, route: 'cosign' });
    const r = await w.service.frostSign(s.full, w.caller);
    const msg = hexToBytes(op.digest);
    const own = sign(device, s.nonces, s.commitments, msg);
    const signature = aggregate(s.commitments, [own, { id: r.share.id, z: BigInt(r.share.z) }], msg, device.groupPublicKey, twoOfTwoCheck(device, r.share.id));
    expect(verify(signature, msg, device.groupPublicKey)).toBe(true);
    // The session is gone: its nonces never sign again.
    await expectRefusal(w.service.frostSign(s.full, w.caller), 'session_unknown');
  });

  it('burns the session on a refusal: no passkey, the passkey over another digest, or a policy refusal', async () => {
    const { w, device, account } = await frostSafe();
    const op = safeOp(w, account, [deposit(1n)]);
    const noPasskey = await session(w, device, account, op.digest, { chainId: CHAIN_ID, account, kind: 'safe-operation', ...op, route: 'cosign' }, { passkeySignature: '0x' });
    await expectRefusal(w.service.frostSign(noPasskey.full, w.caller), 'passkey_required');
    await expectRefusal(w.service.frostSign({ ...noPasskey.full, passkeySignature: sig(w, op.digest) }, w.caller), 'session_unknown');
    const other = safeOp(w, account, [deposit(2n)]);
    const wrong = await session(w, device, account, op.digest, { chainId: CHAIN_ID, account, kind: 'safe-operation', ...op, route: 'cosign' }, { passkeySignature: sig(w, other.digest) });
    await expectRefusal(w.service.frostSign(wrong.full, w.caller), 'bad_passkey_signature');
    const stranger = safeOp(w, account, [{ to: getAddress(`0x${'99'.repeat(20)}`), data: '0x' }]);
    const refused = await session(w, device, account, stranger.digest, { chainId: CHAIN_ID, account, kind: 'safe-operation', ...stranger, route: 'cosign' });
    await expectRefusal(w.service.frostSign(refused.full, w.caller), 'target_not_allowed');
    await expectRefusal(w.service.frostSign(refused.full, w.caller), 'session_unknown');
  });

  it('refuses a commitment list that swaps the server\'s own commitment, and an expired session', async () => {
    const { w, device, server, account } = await frostSafe();
    const op = safeOp(w, account, [deposit(1n)]);
    const s = await session(w, device, account, op.digest, { chainId: CHAIN_ID, account, kind: 'safe-operation', ...op, route: 'cosign' });
    const forged = commit(server).commitment;
    await expectRefusal(w.service.frostSign({ ...s.full, commitments: [s.commitments[0]!, forged] }, w.caller), 'frost_invalid');
    const late = await session(w, device, account, op.digest, { chainId: CHAIN_ID, account, kind: 'safe-operation', ...op, route: 'cosign' });
    w.clock.ms += 121_000;
    await expectRefusal(w.service.frostSign(late.full, w.caller), 'session_unknown');
  });

  it('a counterfactual Kernel FrostValidator account must install recovery for its passkey in its first operation', async () => {
    const [device, server] = dkg('cosigner frost kernel');
    const w = world({ frostShares: [server] });
    const initData = kernelInitData({ rootValidator: FROST_VALIDATOR, validatorData: frostInstallData(device.groupPublicKey) });
    const salt = pad(toHex(3n), { size: 32 });
    const account = predictKernelAddress({ initData, salt });
    await expectRefusal(w.service.enrol({ chainId: CHAIN_ID, account, type: 'kernel', kernel: { initData, salt }, ...enrolmentProof(w, account) }, w.caller), 'no_passkey_on_chain');
    const { enrolment } = await w.service.enrol({ chainId: CHAIN_ID, account, type: 'kernel', passkey: w.pk, kernel: { initData, salt }, ...enrolmentProof(w, account) }, w.caller);
    expect(enrolment.kind).toBe('kernel-frost');
    const bare = kernelOp(w, account, [deposit(1n)], { initCode: '0x1234', validator: FROST_VALIDATOR });
    const s1 = await session(w, device, account, bare.digest, { chainId: CHAIN_ID, account, kind: 'kernel-operation', ...bare, route: 'cosign' });
    await expectRefusal(w.service.frostSign(s1.full, w.caller), 'recovery_setup_required');
    const setup = kernelRecoverySetupCalls({ account, passkey: w.pk, passkeySigner: fakeSignerAddress(w.pk), adapter: ADAPTER, validator: FROST_VALIDATOR }).calls;
    const first = kernelOp(w, account, [...setup, deposit(1n)], { initCode: '0x1234', validator: FROST_VALIDATOR });
    const s2 = await session(w, device, account, first.digest, { chainId: CHAIN_ID, account, kind: 'kernel-operation', ...first, route: 'cosign' });
    const r = await w.service.frostSign(s2.full, w.caller);
    expect(r.share.id).toBe(server.id);
    void recoverySetupCalls;
  });

  it('a Kernel FrostValidator account the sponsorship module deployed before its first operation still installs recovery first, and can', async () => {
    const [device, server] = dkg('cosigner frost kernel deployed');
    const w = world({ frostShares: [server] });
    const initData = kernelInitData({ rootValidator: FROST_VALIDATOR, validatorData: frostInstallData(device.groupPublicKey) });
    const salt = pad(toHex(4n), { size: 32 });
    const account = predictKernelAddress({ initData, salt });
    await w.service.enrol({ chainId: CHAIN_ID, account, type: 'kernel', passkey: w.pk, kernel: { initData, salt }, ...enrolmentProof(w, account) }, w.caller);
    // What the sponsorship module's factory call leaves: the account, its FrostValidator over the group key - and no
    // recovery Delay yet, which only the account's own first operation installs.
    const g = device.groupPublicKey.toAffine();
    w.chain.code.add(k(account));
    w.chain.kernelRoots.set(k(account), FROST_VALIDATOR);
    w.chain.frostKeys.set(`${k(FROST_VALIDATOR)}:${k(account)}`, { x: g.x, y: g.y });

    const bare = kernelOp(w, account, [deposit(1n)], { validator: FROST_VALIDATOR });
    const s1 = await session(w, device, account, bare.digest, { chainId: CHAIN_ID, account, kind: 'kernel-operation', ...bare, route: 'cosign' });
    await expectRefusal(w.service.frostSign(s1.full, w.caller), 'recovery_setup_required');
    const passkeySigner = fakeSignerAddress(w.pk);
    const setup = kernelRecoverySetupCalls({ account, passkey: w.pk, passkeySigner, adapter: ADAPTER, validator: FROST_VALIDATOR }).calls;
    const first = kernelOp(w, account, [...setup, deposit(1n)], { validator: FROST_VALIDATOR });
    const s2 = await session(w, device, account, first.digest, { chainId: CHAIN_ID, account, kind: 'kernel-operation', ...first, route: 'cosign' });
    expect((await w.service.frostSign(s2.full, w.caller)).share.id).toBe(server.id);

    // Enrolling again before recovery is installed is the same binding, not a refusal.
    const again = await w.service.enrol({ chainId: CHAIN_ID, account, type: 'kernel', passkey: w.pk, ...enrolmentProof(w, account) }, w.caller);
    expect(again.enrolment).toMatchObject({ kind: 'kernel-frost', passkeySigner });

    // Installed, as those setup calls do it - the passkey signer created, the Delay with it as its module: the passkey is
    // read from the Delay now, and later operations need no setup.
    w.chain.deploySigner(w.pk);
    w.chain.installDelay(account, passkeySigner);
    const later = kernelOp(w, account, [deposit(1n)], { validator: FROST_VALIDATOR });
    const s3 = await session(w, device, account, later.digest, { chainId: CHAIN_ID, account, kind: 'kernel-operation', ...later, route: 'cosign' });
    expect((await w.service.frostSign(s3.full, w.caller)).share.id).toBe(server.id);
  });

  it('a deployed FROST account whose Delay address holds something that is not its recovery Delay stays refused', async () => {
    const [device, server] = dkg('cosigner frost kernel odd delay');
    const w = world({ frostShares: [server] });
    const initData = kernelInitData({ rootValidator: FROST_VALIDATOR, validatorData: frostInstallData(device.groupPublicKey) });
    const salt = pad(toHex(5n), { size: 32 });
    const account = predictKernelAddress({ initData, salt });
    await w.service.enrol({ chainId: CHAIN_ID, account, type: 'kernel', passkey: w.pk, kernel: { initData, salt }, ...enrolmentProof(w, account) }, w.caller);
    const g = device.groupPublicKey.toAffine();
    w.chain.code.add(k(account));
    w.chain.kernelRoots.set(k(account), FROST_VALIDATOR);
    w.chain.frostKeys.set(`${k(FROST_VALIDATOR)}:${k(account)}`, { x: g.x, y: g.y });
    // Code at the Delay's address that does not read as this account's Delay: the claimed key is no longer taken.
    const delay = w.chain.installDelay(account, fakeSignerAddress(w.pk));
    w.chain.delays.delete(k(delay));
    const setup = kernelRecoverySetupCalls({ account, passkey: w.pk, passkeySigner: fakeSignerAddress(w.pk), adapter: ADAPTER, validator: FROST_VALIDATOR }).calls;
    const op = kernelOp(w, account, [...setup, deposit(1n)], { validator: FROST_VALIDATOR });
    const s = await session(w, device, account, op.digest, { chainId: CHAIN_ID, account, kind: 'kernel-operation', ...op, route: 'cosign' });
    await expectRefusal(w.service.frostSign(s.full, w.caller), 'enrolment_stale');
    await expectRefusal(w.service.enrol({ chainId: CHAIN_ID, account, type: 'kernel', passkey: w.pk, ...enrolmentProof(w, account) }, w.caller), 'no_passkey_on_chain');
  });
});

/* ------------------------------------------------------------------ M-08: round one is authenticated and bounded */

type Op = ReturnType<typeof safeOp>;
type Wire = Omit<FrostCommitRequest, 'passkeySignature'>;
const cosignReq = (account: Address, op: Op): Wire => ({ chainId: CHAIN_ID, account, kind: 'safe-operation', userOp: op.userOp, window: op.window, route: 'cosign' });
const vetoReq = (account: Address, op: Op): Wire => ({ ...cosignReq(account, op), route: 'veto' });
const signed = (w: World, req: Wire, op: Op): FrostCommitRequest => ({ ...req, passkeySignature: sig(w, op.digest) });

/** A recovery queued by a stolen passkey, and the operation that vetoes it. */
function queuedRecovery(w: World, account: Address, delay: Address, o: { validUntil?: number } = {}): Op {
  if (w.chain.delays.get(delay.toLowerCase())!.queueNonce === 0n) w.chain.queue(delay, { to: TOKEN, value: 0n, data: '0x' });
  return safeOp(w, account, [{ to: delay, data: encodeVeto(1n) }], o);
}

const theirs = (c: { id: number; hiding: Hex; binding: Hex }): Commitment =>
  ({ id: c.id, hiding: Point.fromBytes(hexToBytes(c.hiding)), binding: Point.fromBytes(hexToBytes(c.binding)) });

/** Round two over an open session, aggregated; true when the aggregate verifies. */
async function finish(w: World, device: KeyShare, req: Wire, op: Op, server: { sessionId: Hex; commitment: { id: number; hiding: Hex; binding: Hex } }) {
  const { nonces, commitment } = commit(device);
  const commitments = [commitment, theirs(server.commitment)];
  const r = await w.service.frostSign({ ...signed(w, req, op), sessionId: server.sessionId, commitments }, w.caller);
  const msg = hexToBytes(op.digest);
  const signature = aggregate(commitments, [sign(device, nonces, commitments, msg), { id: r.share.id, z: BigInt(r.share.z) }], msg, device.groupPublicKey, twoOfTwoCheck(device, r.share.id));
  return verify(signature, msg, device.groupPublicKey);
}

describe('FROST round one: no session without the passkey, and the veto always has room (M-08)', () => {
  it('refuses a commit with no assertion, or one over another digest, and opens no session for it', async () => {
    const { w, account } = await frostSafe();
    const op = safeOp(w, account, [deposit(1n)]);
    const other = safeOp(w, account, [deposit(2n)]);
    await expectRefusal(w.service.frostCommit({ ...cosignReq(account, op), passkeySignature: '0x' }, w.caller), 'passkey_required');
    await expectRefusal(w.service.frostCommit(signed(w, cosignReq(account, op), other), w.caller), 'bad_passkey_signature');
    expect(w.service.status().frostSessionsOpen).toBe(0);
    // The old wire shape - an account and nothing else - no longer parses: there is nothing in it to authenticate.
    expect(() => parseFrostCommitRequest({ chainId: CHAIN_ID, account })).toThrow(/kind/);
  });

  it('a stranger holding the public API key cannot fill the slots: the veto still opens and signs', async () => {
    const { w, device, account, delay } = await frostSafe();
    const filler = safeOp(w, account, [deposit(1n)]);
    for (let i = 0; i < 50; i++) {
      await expectRefusal(w.service.frostCommit({ ...cosignReq(account, filler), passkeySignature: '0x' }, w.caller), 'passkey_required');
    }
    expect(w.service.status().frostSessionsOpen).toBe(0);
    const veto = queuedRecovery(w, account, delay);
    const server = await w.service.frostCommit(signed(w, vetoReq(account, veto), veto), w.caller);
    expect(await finish(w, device, vetoReq(account, veto), veto, server)).toBe(true);
  });

  it('binds the session to the digest and the route the passkey authorised at the commit', async () => {
    const { w, device, account, delay } = await frostSafe();
    const op = safeOp(w, account, [deposit(1n)]);
    const other = safeOp(w, account, [deposit(2n)]);
    const s = await w.service.frostCommit(signed(w, cosignReq(account, op), op), w.caller);
    const { commitment } = commit(device);
    // Round two for another operation, with a valid assertion for THAT operation: refused, and the session is burnt.
    await expectRefusal(w.service.frostSign({ ...signed(w, cosignReq(account, other), other), sessionId: s.sessionId, commitments: [commitment, theirs(s.commitment)] }, w.caller), 'session_unknown');
    await expectRefusal(w.service.frostSign({ ...signed(w, cosignReq(account, op), op), sessionId: s.sessionId, commitments: [commitment, theirs(s.commitment)] }, w.caller), 'session_unknown');
    // A session opened on the co-sign route is not a veto session, even for the veto's digest.
    const veto = queuedRecovery(w, account, delay);
    const c = await w.service.frostCommit(signed(w, cosignReq(account, veto), veto), w.caller);
    await expectRefusal(w.service.frostSign({ ...signed(w, vetoReq(account, veto), veto), sessionId: c.sessionId, commitments: [commitment, theirs(c.commitment)] }, w.caller), 'session_unknown');
  });

  it('a repeated commit for one digest gets the same session back at no cost; the account limit is one token per signature', async () => {
    // A burst of three: enrolment took one, which leaves two.
    const { w, device, account } = await frostSafe({ rateLimit: { burst: 3, perMinute: 1 } });
    const op = safeOp(w, account, [deposit(1n)]);
    const first = await w.service.frostCommit(signed(w, cosignReq(account, op), op), w.caller);
    for (let i = 0; i < 5; i++) expect((await w.service.frostCommit(signed(w, cosignReq(account, op), op), w.caller)).sessionId).toBe(first.sessionId);
    expect(w.service.status().frostSessionsOpen).toBe(1);
    // Commit and sign take one token between them: two whole signatures fit the two left.
    expect(await finish(w, device, cosignReq(account, op), op, first)).toBe(true);
    const op2 = safeOp(w, account, [deposit(2n)]);
    const second = await w.service.frostCommit(signed(w, cosignReq(account, op2), op2), w.caller);
    expect(await finish(w, device, cosignReq(account, op2), op2, second)).toBe(true);
    const op3 = safeOp(w, account, [deposit(3n)]);
    await expectRefusal(w.service.frostCommit(signed(w, cosignReq(account, op3), op3), w.caller), 'rate_limited');
  });

  it('limits the sessions one API client opens; another client has its own bucket, and the veto of a queued recovery is exempt', async () => {
    const { w, device, account, delay } = await frostSafe({ service: { frostCommitClientRateLimit: { burst: 2, perMinute: 1 } } });
    const ops = [1n, 2n, 3n].map((n) => safeOp(w, account, [deposit(n)]));
    for (const op of ops.slice(0, 2)) await w.service.frostCommit(signed(w, cosignReq(account, op), op), w.caller);
    await expectRefusal(w.service.frostCommit(signed(w, cosignReq(account, ops[2]!), ops[2]!), w.caller), 'rate_limited');
    await w.service.frostCommit(signed(w, cosignReq(account, ops[2]!), ops[2]!), { client: 'other-backend' });
    const veto = queuedRecovery(w, account, delay);
    const server = await w.service.frostCommit(signed(w, vetoReq(account, veto), veto), w.caller);
    expect(await finish(w, device, vetoReq(account, veto), veto, server)).toBe(true);
  });

  /// v3.1 N-07: the app ships one API key to every user, so the bucket is the key AND the client address: an attacker
  /// opening sessions from its own address exhausts its own bucket, not every user's.
  it('keys the commit limit by API client and client address: the shared app key does not make one bucket for all', async () => {
    const { w, account } = await frostSafe({ service: { frostCommitClientRateLimit: { burst: 2, perMinute: 1 } } });
    const ops = [1n, 2n, 3n, 4n].map((n) => safeOp(w, account, [deposit(n)]));
    const attacker = { client: 'app', address: '198.51.100.66' };
    for (const op of ops.slice(0, 2)) await w.service.frostCommit(signed(w, cosignReq(account, op), op), attacker);
    await expectRefusal(w.service.frostCommit(signed(w, cosignReq(account, ops[2]!), ops[2]!), attacker), 'rate_limited');
    // The same app key, another user's address: its own bucket.
    const user = await w.service.frostCommit(signed(w, cosignReq(account, ops[3]!), ops[3]!), { client: 'app', address: '203.0.113.20' });
    expect(user.sessionId).toBeDefined();
  });

  it('reserves a veto slot beside the co-signing slots, usable only by the veto of a recovery queued now', async () => {
    const { w, device, account, delay } = await frostSafe({ service: { maxFrostSessionsPerAccount: 2 } });
    for (const n of [1n, 2n]) {
      const op = safeOp(w, account, [deposit(n)]);
      await w.service.frostCommit(signed(w, cosignReq(account, op), op), w.caller);
    }
    const third = safeOp(w, account, [deposit(3n)]);
    await expectRefusal(w.service.frostCommit(signed(w, cosignReq(account, third), third), w.caller), 'rate_limited');
    // The reserve is no third co-signing slot: the veto route for anything else, or with nothing queued, is refused.
    await expectRefusal(w.service.frostCommit(signed(w, vetoReq(account, third), third), w.caller), 'not_a_veto');
    const early = safeOp(w, account, [{ to: delay, data: encodeVeto(1n) }]);
    await expectRefusal(w.service.frostCommit(signed(w, vetoReq(account, early), early), w.caller), 'nothing_to_veto');
    const veto = queuedRecovery(w, account, delay);
    const first = await w.service.frostCommit(signed(w, vetoReq(account, veto), veto), w.caller);
    // A newer veto (another window) takes the slot over.
    const newer = queuedRecovery(w, account, delay, { validUntil: Number(w.chain.time) + 600 });
    const second = await w.service.frostCommit(signed(w, vetoReq(account, newer), newer), w.caller);
    expect(second.sessionId).not.toBe(first.sessionId);
    expect(w.service.status().frostSessionsOpen).toBe(3);
    await expectRefusal(finish(w, device, vetoReq(account, veto), veto, first), 'session_unknown');
    expect(await finish(w, device, vetoReq(account, newer), newer, second)).toBe(true);
  });

  it('a full table evicts the oldest co-signing session first, and never a veto for a co-signing commit', async () => {
    const { w, device, account, delay } = await frostSafe({ service: { maxFrostSessions: 2, maxFrostSessionsPerAccount: 10 } });
    const veto = queuedRecovery(w, account, delay);
    const v = await w.service.frostCommit(signed(w, vetoReq(account, veto), veto), w.caller);
    const ops = [1n, 2n].map((n) => safeOp(w, account, [deposit(n)]));
    const a = await w.service.frostCommit(signed(w, cosignReq(account, ops[0]!), ops[0]!), w.caller);
    const b = await w.service.frostCommit(signed(w, cosignReq(account, ops[1]!), ops[1]!), w.caller);
    expect(w.service.status().frostSessionsOpen).toBe(2);
    // `a` was the oldest co-signing session and is gone; the older veto session survived.
    await expectRefusal(finish(w, device, cosignReq(account, ops[0]!), ops[0]!, a), 'session_unknown');
    expect(w.metrics.render()).toMatch(/mova_cosigner_frost_sessions_evicted_total\{route="cosign"\} 1/);
    expect(await finish(w, device, cosignReq(account, ops[1]!), ops[1]!, b)).toBe(true);
    expect(await finish(w, device, vetoReq(account, veto), veto, v)).toBe(true);

    // A table holding only a veto has no room a co-signing commit may take.
    const one = await frostSafe({ service: { maxFrostSessions: 1 } });
    const v1 = queuedRecovery(one.w, one.account, one.delay);
    await one.w.service.frostCommit(signed(one.w, vetoReq(one.account, v1), v1), one.w.caller);
    const c1 = safeOp(one.w, one.account, [deposit(1n)]);
    await expectRefusal(one.w.service.frostCommit(signed(one.w, cosignReq(one.account, c1), c1), one.w.caller), 'rate_limited');
    expect(one.w.service.status().frostSessionsOpen).toBe(1);
  });
});
