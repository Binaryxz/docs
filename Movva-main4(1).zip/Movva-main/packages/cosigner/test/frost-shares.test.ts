import { afterEach, describe, expect, it } from 'vitest';
import { inspect } from 'node:util';
import { randomBytes } from 'node:crypto';
import { toHex, type Hex } from 'viem';
import { publicShareOf, type KeyShare } from '@mova/mpc';
import {
  KeyCustodyError, RemoteCoSigner, cosignerConfigFromEnv, encryptedFrostShares, fileFrostShares, fileShareKeyWrapper, frostShareAad,
  frostShareJson, localShareKeyWrapper, serveCoSigner, type CoSignerConfig, type ShareKeyWrapper,
} from '../src/index.js';
import { loadFrostShares } from '../src/bin/cosigner.js';
import { CHAIN_ID, SERVER, VAULT, dkg, world } from './harness.js';

/**
 * M-09: the server's FROST shares are sealed on disk - AES-256-GCM under a per-share data key, the data key wrapped
 * by a KMS (here: a local wrapping key standing in for one) - and the plaintext file has a production flag of its
 * own.
 */

/** A share file in memory: what `writeFile` wrote is what the next load reads. */
function disk(initial?: unknown) {
  const d = { content: initial === undefined ? undefined : JSON.stringify(initial), writes: 0 };
  return {
    d,
    io: {
      path: '/data/frost-shares.json',
      fileMode: () => 0o600,
      readFile: () => {
        if (d.content === undefined) throw Object.assign(new Error('no file'), { code: 'ENOENT' });
        return d.content;
      },
      writeFile: (_p: string, c: string) => { d.content = c; d.writes++; },
    },
    entries: () => JSON.parse(d.content!) as Record<string, unknown>[],
  };
}

const wrapperKey = () => randomBytes(32);
const shareHex = (s: KeyShare) => toHex(s.share, { size: 32 }).slice(2);
const ref = `${CHAIN_ID}:${SERVER.toLowerCase()}`;
const transcript = 'ab'.repeat(32);

async function sealedStore(o: { wrapper?: ShareKeyWrapper; production?: boolean } = {}) {
  const wrapper = o.wrapper ?? localShareKeyWrapper(wrapperKey());
  const f = disk();
  const store = await encryptedFrostShares({ ...f.io, wrapper, production: o.production ?? false, createIfMissing: true });
  const [, server] = dkg('sealed store');
  await store.putPending({ share: server, accountRef: ref, transcript, createdAt: 1_800_000_000 });
  await store.complete(server.groupPublicKey);
  return { wrapper, f, store, server };
}

describe('FROST shares under envelope encryption (M-09)', () => {
  it('round trip: written sealed, never in the clear, and opened again by the same wrapping key', async () => {
    const { wrapper, f, store, server } = await sealedStore();
    expect(store.custody).toBe('envelope:local');
    expect(f.d.content).not.toContain(shareHex(server));
    const [entry] = f.entries();
    expect(entry).toMatchObject({
      id: server.id, groupPublicKey: toHex(server.groupPublicKey.toBytes(true)), verificationShare: toHex(publicShareOf(server).toBytes(true)),
      accountRef: ref, transcript, complete: true, sealed: { v: 2, alg: 'AES-256-GCM', keyId: wrapper.keyId },
    });
    expect(entry!.share).toBeUndefined();

    const again = await encryptedFrostShares({ ...f.io, wrapper, production: true });
    expect(again.shareFor(server.groupPublicKey)?.share).toBe(server.share);
    expect(again.forAccount(ref)).toMatchObject({ complete: true, transcript });
    // Nothing secret in JSON or inspect.
    expect(JSON.stringify(again)).not.toContain(shareHex(server));
    expect(inspect(again, { showHidden: true, depth: 6 })).not.toContain(shareHex(server));
    expect(inspect(wrapper, { showHidden: true, depth: 6 })).toBe(`ShareKeyWrapper(local, ${wrapper.keyId})`);
  });

  it('each share has its own data key: the same share sealed twice shares no ciphertext, IV or wrapped key', async () => {
    const { wrapper, server } = await sealedStore();
    const a = disk();
    const b = disk();
    for (const f of [a, b]) {
      const s = await encryptedFrostShares({ ...f.io, wrapper, production: false, createIfMissing: true });
      await s.putPending({ share: server, accountRef: ref });
    }
    const [x, y] = [a.entries()[0]!.sealed as Record<string, Hex>, b.entries()[0]!.sealed as Record<string, Hex>];
    for (const k of ['wrappedKey', 'iv', 'ciphertext', 'tag']) expect(x[k]).not.toBe(y[k]);
  });

  it('a tampered ciphertext, tag or IV, or a record whose AAD changed (group key, account, id, complete, transcript), does not open', async () => {
    const { wrapper, f, server } = await sealedStore();
    const good = f.entries()[0]!;
    const sealed = good.sealed as Record<string, Hex>;
    const flip = (h: Hex): Hex => `0x${(BigInt(h) ^ 1n).toString(16).padStart(h.length - 2, '0')}` as Hex;
    const [, other] = dkg('another group');
    const cases: Record<string, unknown>[] = [
      { ...good, sealed: { ...sealed, ciphertext: flip(sealed.ciphertext) } },
      { ...good, sealed: { ...sealed, tag: flip(sealed.tag) } },
      { ...good, sealed: { ...sealed, iv: flip(sealed.iv) } },
      { ...good, sealed: { ...sealed, wrappedKey: flip(sealed.wrappedKey) } },
      { ...good, accountRef: `${CHAIN_ID}:${VAULT.toLowerCase()}` },
      { ...good, accountRef: undefined },
      // N-17: `complete` and the transcript are in the v2 AAD - a share cannot be demoted, promoted or re-attributed.
      { ...good, complete: false },
      { ...good, transcript: `${'0'.repeat(63)}1` },
      // Moved to another group: the AAD names the group key, so the ciphertext refuses before anything is compared.
      { ...good, groupPublicKey: toHex(other.groupPublicKey.toBytes(true)), verificationShare: toHex(publicShareOf({ ...other, share: server.share }).toBytes(true)) },
    ];
    for (const entry of cases) {
      const t = disk([entry]);
      await expect(encryptedFrostShares({ ...t.io, wrapper, production: false })).rejects.toThrow(/does not decrypt/);
    }
    // Another participant id: AAD mismatch as well.
    const moved = disk([{ ...good, id: server.id + 1 }]);
    await expect(encryptedFrostShares({ ...moved.io, wrapper, production: false })).rejects.toThrow(/does not decrypt/);
    // A sealed blob copied onto another record of the same file.
    const [, third] = dkg('third group');
    const s3 = disk();
    const store3 = await encryptedFrostShares({ ...s3.io, wrapper, production: false, createIfMissing: true });
    await store3.putPending({ share: third, accountRef: ref });
    const swapped = disk([{ ...s3.entries()[0]!, sealed }]);
    await expect(encryptedFrostShares({ ...swapped.io, wrapper, production: false })).rejects.toThrow(/does not decrypt/);
    // The AAD itself: fixed-width at both ends.
    const aad = frostShareAad(server.groupPublicKey, ref, server.id);
    expect(Buffer.from(aad).toString('utf8')).toContain('mova/cosigner/frost-share/v1');
    expect(aad.length).toBe('mova/cosigner/frost-share/v1'.length + 1 + 33 + ref.length + 4);
  });

  it('another wrapping key does not open the file: not by its keyId, not by a wrapper claiming the same keyId', async () => {
    const { f, wrapper } = await sealedStore();
    await expect(encryptedFrostShares({ ...f.io, wrapper: localShareKeyWrapper(wrapperKey()), production: false })).rejects.toThrow(/wrapped under/);
    const impostor = localShareKeyWrapper(wrapperKey());
    const lying: ShareKeyWrapper = { custody: 'kms:test', keyId: wrapper.keyId, wrap: impostor.wrap, unwrap: (w, c) => impostor.unwrap(w, c, impostor.keyId) };
    await expect(encryptedFrostShares({ ...f.io, wrapper: lying, production: false })).rejects.toThrow(/does not decrypt/);
    // A plaintext reader refuses sealed entries instead of misreading them.
    expect(() => fileFrostShares({ ...f.io, production: false })).toThrow(/is sealed/);
  });

  it('a wrapper that does not round-trip, or is not a wrapper, is refused before any share is trusted to it', async () => {
    const f = disk();
    const broken: ShareKeyWrapper = { custody: 'kms:broken', keyId: 'k', wrap: async (k) => k, unwrap: async () => new Uint8Array(32) };
    await expect(encryptedFrostShares({ ...f.io, wrapper: broken, production: false, createIfMissing: true })).rejects.toThrow(/round trip/);
    await expect(encryptedFrostShares({ ...f.io, wrapper: {} as ShareKeyWrapper, production: false, createIfMissing: true })).rejects.toThrow(/must have custody/);
  });

  it('migration: a plaintext file still loads in development, with a warning, and is rewritten sealed at once', async () => {
    const [, server] = dkg('legacy file');
    const f = disk([frostShareJson({ share: server, accountRef: ref, complete: true })]);
    const warnings: string[] = [];
    const wrapper = localShareKeyWrapper(wrapperKey());
    const store = await encryptedFrostShares({ ...f.io, wrapper, production: false, warn: (m) => warnings.push(m) });
    expect(store.shareFor(server.groupPublicKey)?.share).toBe(server.share);
    expect(warnings.join('\n')).toMatch(/1 plaintext or v1-sealed FROST share\(s\).*rewritten sealed/);
    expect(f.d.content).not.toContain(shareHex(server));
    expect(f.entries()[0]!.sealed).toBeDefined();
    expect((await encryptedFrostShares({ ...f.io, wrapper, production: false })).shareFor(server.groupPublicKey)?.share).toBe(server.share);
  });

  it('production: plaintext refused - the plaintext store, a local wrapping key, a plaintext file to migrate - unless the FROST flag', async () => {
    const [, server] = dkg('production');
    const plain = () => disk([frostShareJson({ share: server, complete: true })]);
    expect(() => fileFrostShares({ ...plain().io, production: true })).toThrow(/COSIGNER_ALLOW_FROST_SHARE_FILE_IN_PRODUCTION/);
    expect(fileFrostShares({ ...plain().io, production: true, allowInProduction: true }).shareFor(server.groupPublicKey)?.id).toBe(server.id);
    const keyFile = { path: '/run/frost_wrapping_key', readFile: () => toHex(randomBytes(32)), fileMode: () => 0o600 };
    expect(() => fileShareKeyWrapper({ ...keyFile, production: true })).toThrow(KeyCustodyError);
    expect(fileShareKeyWrapper({ ...keyFile, production: true, allowInProduction: true }).custody).toBe('local-file');
    expect(() => fileShareKeyWrapper({ ...keyFile, production: false, fileMode: () => 0o640 })).toThrow(/group or others/);
    const kms = localShareKeyWrapper(wrapperKey(), 'kms:test');
    await expect(encryptedFrostShares({ ...plain().io, wrapper: kms, production: true })).rejects.toThrow(/plaintext and production mode refuses/);
    expect((await encryptedFrostShares({ ...plain().io, wrapper: kms, production: true, allowPlaintextInProduction: true })).custody).toBe('envelope:kms:test');
    // Sealed under a KMS: production needs no flag.
    const sealed = await sealedStore({ wrapper: kms, production: true });
    expect((await encryptedFrostShares({ ...sealed.f.io, wrapper: kms, production: true })).shareFor(sealed.server.groupPublicKey)?.share).toBe(sealed.server.share);
  });

  it('the DKG writes its half sealed: the service generates a key with a device into the envelope store', async () => {
    const f = disk();
    const store = await encryptedFrostShares({ ...f.io, wrapper: localShareKeyWrapper(wrapperKey()), production: false, createIfMissing: true });
    const w = world({ frostShares: [], extra: () => ({ frostShares: store }) });
    const s = serveCoSigner(w.service, { mode: 'api', apiKeys: [{ name: 'wallet', token: 'sealed-dkg-token-0123456789abcdefghij' }] });
    closers.push(s.close);
    const cosigner = new RemoteCoSigner({ url: `http://127.0.0.1:${await s.listen(0)}`, chainId: CHAIN_ID, apiKey: 'sealed-dkg-token-0123456789abcdefghij' });
    const out = await cosigner.runDkg({ passkey: { ...w.pk }, sign: (c) => w.passkey.sign(c), coSigner: SERVER, issuedAt: Number(w.clock.now) });
    const server = store.shareFor(out.keyShare.groupPublicKey)!;
    expect(server).toBeDefined();
    expect(f.d.content).not.toContain(shareHex(server));
    expect(f.entries()).toEqual([expect.objectContaining({ complete: true, groupPublicKey: out.groupKey, sealed: expect.objectContaining({ alg: 'AES-256-GCM' }) })]);
  });
});

const closers: (() => Promise<void>)[] = [];
afterEach(async () => { while (closers.length) await closers.pop()!(); });

describe('FROST share configuration: a flag of its own (M-09)', () => {
  const policy = JSON.stringify({ chainId: 31337, targets: [{ address: VAULT, label: 'TestVault' }], tokens: [], window: { maxSeconds: 900 } });
  const files: Record<string, string> = { '/policy.json': policy, '/keys': 'movva-web:abcdefghijklmnopqrstuvwxyz0123456789\n', '/kms.json': '{"keyId":"arn:aws:kms:x"}' };
  const readFile = (p: string) => { if (!(p in files)) throw new Error('ENOENT'); return files[p]!; };
  const base = { RPC_URL: 'http://127.0.0.1:8959', CHAIN_ID: '31337', COSIGNER_POLICY_FILE: '/policy.json', COSIGNER_AUDIT_LOG: '/data/audit.jsonl', COSIGNER_API_KEYS_FILE: '/keys' };
  const prodKey = { ...base, COSIGNER_MODE: 'production', COSIGNER_KEY_FILE: '/key', COSIGNER_ALLOW_FILE_KEY_IN_PRODUCTION: '1' };
  const read = (env: Record<string, string>) => cosignerConfigFromEnv(env, readFile);

  it('the signing key\'s flag no longer admits the share file, and the share file\'s flag does not admit a key file', () => {
    expect(() => read({ ...prodKey, COSIGNER_FROST_SHARES_FILE: '/data/frost.json' }))
      .toThrow(/plaintext and production mode refuses it.*COSIGNER_ALLOW_FROST_SHARE_FILE_IN_PRODUCTION=1.*covers the co-signer key only/s);
    const { COSIGNER_ALLOW_FILE_KEY_IN_PRODUCTION: _f, ...noKeyFlag } = prodKey;
    expect(() => read({ ...noKeyFlag, COSIGNER_FROST_SHARES_FILE: '/data/frost.json', COSIGNER_ALLOW_FROST_SHARE_FILE_IN_PRODUCTION: '1' }))
      .toThrow(/COSIGNER_KEY_FILE is a development key custody/);
    const both = read({ ...prodKey, COSIGNER_FROST_SHARES_FILE: '/data/frost.json', COSIGNER_ALLOW_FROST_SHARE_FILE_IN_PRODUCTION: '1' });
    expect(both.frostShares).toEqual({ file: '/data/frost.json', protection: { kind: 'plaintext' }, allowFileInProduction: true });
  });

  it('a KMS wrapper needs no flag in production; a local wrapping key does; one of the two, and only with a share file', () => {
    const kms = read({ ...prodKey, COSIGNER_FROST_SHARES_FILE: '/data/frost.json', COSIGNER_FROST_KMS_MODULE: '/plugins/kms.js', COSIGNER_FROST_KMS_SETTINGS_FILE: '/kms.json' });
    expect(kms.frostShares).toEqual({ file: '/data/frost.json', protection: { kind: 'kms', module: '/plugins/kms.js', settings: { keyId: 'arn:aws:kms:x' } }, allowFileInProduction: false });
    expect(() => read({ ...prodKey, COSIGNER_FROST_SHARES_FILE: '/data/frost.json', COSIGNER_FROST_WRAPPING_KEY_FILE: '/run/kek' })).toThrow(/same disk as the shares/);
    expect(read({ ...base, COSIGNER_KEY_FILE: '/key', COSIGNER_FROST_SHARES_FILE: '/data/frost.json', COSIGNER_FROST_WRAPPING_KEY_FILE: '/run/kek' }).frostShares?.protection)
      .toEqual({ kind: 'wrapping-key-file', path: '/run/kek' });
    expect(() => read({ ...base, COSIGNER_KEY_FILE: '/key', COSIGNER_FROST_SHARES_FILE: '/f', COSIGNER_FROST_KMS_MODULE: '/m.js', COSIGNER_FROST_WRAPPING_KEY_FILE: '/k' })).toThrow(/not both/);
    expect(() => read({ ...base, COSIGNER_KEY_FILE: '/key', COSIGNER_FROST_KMS_MODULE: '/m.js' })).toThrow(/need COSIGNER_FROST_SHARES_FILE/);
    expect(read({ ...base, COSIGNER_KEY_FILE: '/key' }).frostShares).toBeUndefined();
  });

  it('the entrypoint takes the production rule from the configuration, not a hard-coded allowance', async () => {
    const cfg = (production: boolean, allowFileInProduction: boolean) => ({
      production, frostShares: { file: '/nonexistent/frost-shares.json', protection: { kind: 'plaintext' }, allowFileInProduction },
    }) as unknown as CoSignerConfig;
    await expect(loadFrostShares(cfg(true, false))).rejects.toThrow(/COSIGNER_ALLOW_FROST_SHARE_FILE_IN_PRODUCTION/);
    const warnings: string[] = [];
    expect((await loadFrostShares(cfg(true, true), (m) => warnings.push(m)))?.custody).toBe('file');
    expect(warnings.join('\n')).toMatch(/PLAINTEXT/);
    expect((await loadFrostShares(cfg(false, false)))?.custody).toBe('file');
    expect(await loadFrostShares({ production: true } as CoSignerConfig)).toBeUndefined();
  });
});
