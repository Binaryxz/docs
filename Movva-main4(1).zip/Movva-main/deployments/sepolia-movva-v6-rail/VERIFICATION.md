# Verification report: Movva rail on Sepolia (MOVVA only)

Generated 2026-10-27T11:47:40.173Z by `scripts/deploy-movva-rail.ts`. Everything below was read from the chain after the deployment, and every number in it comes from the deployment JSON and `deployments/sepolia-movva-v6-rail/privileges.json`.

## Summary

| | |
|---|---|
| Chain | Sepolia, chain id 11155111 |
| Commit | `0c4b828f7dd5498ca93cdf62b48ced0e5c56a7ad` on `phase-1-shielded-rail`, clean tree |
| Build hash | `04ec2733e2be6ba0f5b563888aa4972aac11c8d4e2693362e5d686ac964cf428` |
| Deployer | `0xEAB314D8E5B0AFe05ade6C2097b09016942fBF26` |
| Contracts | 23 addresses, 23 distinct contracts, 23 running this build |
| Transactions | 64, 288,275,718 gas; blocks 12004265 to 12004872 |
| Checks | **361 pass, 8 expected, 0 fail** |
| Governance | finalized: every governor handed to `0x000000000000000000000000000000000000dEaD`, the Entrypoint's OWNER_ROLE renounced; ASP_POSTMAN held by the AspRootQuorum alone |
| **Test keys made permanent** | **18 role(s) that remain for ever are held by seed-derived test identities, or are the illustrative zkTLS templates** (`MOVVA_FINALIZE_ALLOW_TEST_KEYS=yes-this-is-a-rehearsal`). A demonstration only: see Substitutions |

> **Finalized with test keys (SRM1-1 opt-out, `MOVVA_FINALIZE_ALLOW_TEST_KEYS=yes-this-is-a-rehearsal`).** `--finalize` normally refuses while any role that outlives it is a test identity. This run was told to proceed anyway, so the following can never be replaced or revoked by anyone:

> - zkTLS witness 0x05EfF3D8e0ad59Aa8abFd94E0b08402ec0850Fbf: witness/0 (MOVVA_TEST_KEY_SEED)
> - zkTLS witness 0x8771D8B0038061D7872e4c2C69cD63F54380CBAb: witness/1 (MOVVA_TEST_KEY_SEED)
> - zkTLS witness 0x72C1a86B73Ca01Fec5e07160AE14a32849eE5214: witness/2 (MOVVA_TEST_KEY_SEED)
> - Movva FiatEscrow arbitrator 0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7: arbitrator (recorded test identity)
> - Movva OffRampEscrow arbitrator 0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7: arbitrator (recorded test identity)
> - registry LP 0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C: lp/0, the test LP and gateway (MOVVA_TEST_KEY_SEED)
> - reserve gateway 0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C: lp/0, the test LP and gateway (MOVVA_TEST_KEY_SEED)
> - reserve yield recipient 0x622F626F912AD25d36D9B8F48907Ac941F755ACb: treasury/0 (MOVVA_TEST_KEY_SEED)
> - FeeSplitter treasury 0x622F626F912AD25d36D9B8F48907Ac941F755ACb: treasury/0 (MOVVA_TEST_KEY_SEED)
> - AspRootQuorum ASP 0x6f239a1A5818808E63BB6F35A88B9876a79aa973: asp/0 (MOVVA_TEST_KEY_SEED)
> - AspRootQuorum ASP 0xc8510850c5bF41B52399473F234577B2d8Ef0B16: asp/1 (MOVVA_TEST_KEY_SEED)
> - AspRootQuorum ASP 0x323574Eb0c63b764F06832f15B21956bb8979FC9: asp/2 (MOVVA_TEST_KEY_SEED)
> - Entrypoint owner timelock proposer 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1: a 2-of-3 Safe whose owners custody/governor/signer/0 (MOVVA_TEST_KEY_SEED), custody/governor/signer/1 (MOVVA_TEST_KEY_SEED), custody/governor/signer/2 (MOVVA_TEST_KEY_SEED) are test keys
> - Entrypoint owner timelock executor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1: a 2-of-3 Safe whose owners custody/governor/signer/0 (MOVVA_TEST_KEY_SEED), custody/governor/signer/1 (MOVVA_TEST_KEY_SEED), custody/governor/signer/2 (MOVVA_TEST_KEY_SEED) are test keys
> - zkTLS endpoint 0xb54d2a19bba3a502dc449c083cd2579885618e4e0487435aae1673f06baf0c05: URL prefix https://api.banco-lp.example/ is on a reserved test domain (RFC 2606)
> - zkTLS endpoint 0xd8d90d629dc91348bf69c3c5148cd5bf1efdc99220a15a6f42d6ad42eeb2bb20: URL prefix https://api.banco-lp.example/ is on a reserved test domain (RFC 2606)
> - zkTLS endpoint 0x8259a0510dbf7425215eada80e9a8fcc1bac48d4e24e3cea67b5185b482abf77: URL prefix https://api.banco-lp.example/ is on a reserved test domain (RFC 2606)
> - zkTLS endpoint 0xf02c2badc915c0c690ccba5dd00202b6efcc3d49a1c1197db4026f075aaddc1a: URL prefix https://api.banco-lp.example/ is on a reserved test domain (RFC 2606)
>
> Whoever holds the test seed can forge payment proofs and rule disputes on this deployment for ever. It must never hold real value.

## Substitutions

What this deployment uses in place of the production component, as the deployment JSON records it:

- USDT: a stand-in TetherLike (contracts/test/ERC4626Adapter.t.sol) - 6 decimals and Tether's isBlackListed/pause/fee surface, but mint, pause and blacklist are open to anyone. Sepolia has no canonical USDT
- USDT/USD leg: Chainlink USDC/USD on Sepolia (0xA2F78ab2355fe2f984D808B5CeE7FD0A93D5270E, ~24h heartbeat), for the reserve
- custody (MOVVA_RAIL_CUSTODY=deployments/sepolia-movva-only-custody-rehearsal.json): the reserve's guardian and the escrows' only arbitrator are that record's 2-of-3 Safes from setup (its hedge-treasury Safe is recorded as the sleeve's treasury, not a reserve role), whose signers are test keys derived from the seed; witnesses, the institutional LP / Movva gateway and the treasury: test keys derived from the seed
- reserve yield recipient: the treasury 0x622F626F912AD25d36D9B8F48907Ac941F755ACb, a test key derived from the seed (MOVVA_RAIL_YIELD_RECIPIENT unset). The client rule of 21 October 2026 makes it Mova's Safe; harvestYield pays it, and only it, the yield above max(principal, liabilities at the target)
- ASPs: the AspRootQuorum's three ASPs are test keys derived from the seed (asp/0 stands for Movva; asp/1 and asp/2 for the two independent ASPs the client has yet to confirm)
- governor Safe: a 2-of-3 Safe 1.4.1 whose signers are test keys derived from the seed (movva-rail/<seed>/custody/governor/signer/0..2); it governs every DelayedGovernance contract from setup and drives the Entrypoint owner timelock
- Scope (client decisions, 14 October 2026): MOVVA only. No savings (D1: the code has no sMovva, no sMovva pool and no `distribute`; the reserve's surplus stays in it), no ETH/USDT ramp pair and no ETH or USDT band oracle. The ETH pool is upstream's, deployed by its protocol script; the product does not use it, and the owner step winds it down and removes it (M-18)
- zkTLS endpoints: the four illustrative receipt templates of packages/ramp receiptTemplates(prefix), not a real bank's
- Privacy Pools: a fresh upstream stack owned by the deployer until the owner step, not Mova's 8 September Entrypoint (its OWNER_ROLE key is not on this machine)
- Divergence breaker: none (MOVVA_BREAKER=off). Sepolia has no BRL/USD Chainlink feed or BRL stablecoin pool to read as a second price source, so this run deploys the reserve without one; the breaker is proven by its tests, not by this deployment
- FINALIZED WITH TEST KEYS (MOVVA_FINALIZE_ALLOW_TEST_KEYS=yes-this-is-a-rehearsal, SRM1-1 opt-out): the roles that remain for ever are held by seed-derived test identities, or are packages/ramp's illustrative zkTLS templates, and nobody can ever replace them - zkTLS witness 0x05EfF3D8e0ad59Aa8abFd94E0b08402ec0850Fbf: witness/0 (MOVVA_TEST_KEY_SEED); zkTLS witness 0x8771D8B0038061D7872e4c2C69cD63F54380CBAb: witness/1 (MOVVA_TEST_KEY_SEED); zkTLS witness 0x72C1a86B73Ca01Fec5e07160AE14a32849eE5214: witness/2 (MOVVA_TEST_KEY_SEED); Movva FiatEscrow arbitrator 0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7: arbitrator (recorded test identity); Movva OffRampEscrow arbitrator 0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7: arbitrator (recorded test identity); registry LP 0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C: lp/0, the test LP and gateway (MOVVA_TEST_KEY_SEED); reserve gateway 0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C: lp/0, the test LP and gateway (MOVVA_TEST_KEY_SEED); reserve yield recipient 0x622F626F912AD25d36D9B8F48907Ac941F755ACb: treasury/0 (MOVVA_TEST_KEY_SEED); FeeSplitter treasury 0x622F626F912AD25d36D9B8F48907Ac941F755ACb: treasury/0 (MOVVA_TEST_KEY_SEED); AspRootQuorum ASP 0x6f239a1A5818808E63BB6F35A88B9876a79aa973: asp/0 (MOVVA_TEST_KEY_SEED); AspRootQuorum ASP 0xc8510850c5bF41B52399473F234577B2d8Ef0B16: asp/1 (MOVVA_TEST_KEY_SEED); AspRootQuorum ASP 0x323574Eb0c63b764F06832f15B21956bb8979FC9: asp/2 (MOVVA_TEST_KEY_SEED); Entrypoint owner timelock proposer 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1: a 2-of-3 Safe whose owners custody/governor/signer/0 (MOVVA_TEST_KEY_SEED), custody/governor/signer/1 (MOVVA_TEST_KEY_SEED), custody/governor/signer/2 (MOVVA_TEST_KEY_SEED) are test keys; Entrypoint owner timelock executor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1: a 2-of-3 Safe whose owners custody/governor/signer/0 (MOVVA_TEST_KEY_SEED), custody/governor/signer/1 (MOVVA_TEST_KEY_SEED), custody/governor/signer/2 (MOVVA_TEST_KEY_SEED) are test keys; zkTLS endpoint 0xb54d2a19bba3a502dc449c083cd2579885618e4e0487435aae1673f06baf0c05: URL prefix https://api.banco-lp.example/ is on a reserved test domain (RFC 2606); zkTLS endpoint 0xd8d90d629dc91348bf69c3c5148cd5bf1efdc99220a15a6f42d6ad42eeb2bb20: URL prefix https://api.banco-lp.example/ is on a reserved test domain (RFC 2606); zkTLS endpoint 0x8259a0510dbf7425215eada80e9a8fcc1bac48d4e24e3cea67b5185b482abf77: URL prefix https://api.banco-lp.example/ is on a reserved test domain (RFC 2606); zkTLS endpoint 0xf02c2badc915c0c690ccba5dd00202b6efcc3d49a1c1197db4026f075aaddc1a: URL prefix https://api.banco-lp.example/ is on a reserved test domain (RFC 2606). A rehearsal or testnet demonstration only: whoever holds the test seed can forge payment proofs and rule disputes on it for ever

## What was deployed, and where

| Contract | Address | Source | Source sha256 | Runtime sha256 (build) | On chain |
|---|---|---|---|---|---|
| Privacy Pools Entrypoint (proxy) | `0xe5e3442940D997De3F8584aD0687C925C7178c3f` | `node_modules/@openzeppelin/contracts/proxy/ERC1967/ERC1967Proxy.sol` | `03cdbd59c384fe18`… | `f1f38be5dd06d358`… | identical |
| Entrypoint implementation | `0x3EA6De4f683f5B02D7C68339d36C2D3fB8c2F6c3` | `protocol/contracts/src/contracts/Entrypoint.sol` | `8245c32d50ae6582`… | `6408ed2ab26661a7`… | identical outside immutables |
| Withdrawal Groth16 verifier | `0xDCD3cA51E0C69Bf516eE485E4c1b543E0F1028C6` | `protocol/contracts/src/contracts/verifiers/WithdrawalVerifier.sol` | `7b6991befbc9a94a`… | `77bfc587acc64f36`… | identical |
| Ragequit (commitment) Groth16 verifier | `0x4F52A6Eac236725ee7d4bCDd247b89c1f496Fd68` | `protocol/contracts/src/contracts/verifiers/CommitmentVerifier.sol` | `de24f75d21d651c0`… | `ebae2d48b14ac64f`… | identical |
| ETH Privacy Pool (upstream's; unused by the product) | `0x43697fFB82471b2becA56135a9A1FBd228d34703` | `protocol/contracts/src/contracts/implementations/PrivacyPoolSimple.sol` | `f0d97040fd5bd00d`… | `92fdf5ae69da7a5d`… | identical outside immutables |
| PoseidonT3 library (pre-existing) | `0x8ffdA7Ed8B4aD98C2C34f54B76821711F4a6f2C5` | `node_modules/poseidon-solidity/PoseidonT3.sol` | `08a7493be3783816`… | `23a48ae4bae13d19`… | identical |
| PoseidonT4 library (pre-existing) | `0xe393dd7287Db9982e6f845824854Baf8b8e823AF` | `node_modules/poseidon-solidity/PoseidonT4.sol` | `289e22a19a20bcec`… | `e2f5e98664dbafbe`… | identical |
| Stand-in USDT (OwnedTetherLike) | `0x1931A0c8de3D7bFa68a1106dF269983304eb4960` | `contracts/test/utils/OwnedTetherLike.sol` | `584367afdfb7c75a`… | `38c228fa6ec202bf`… | identical |
| MovvaReserve | `0x0E6b613E8F52036A51CdAa9A309419782d35848c` | `contracts/movva/MovvaReserve.sol` | `5991c143ad7d7a60`… | `bba942d65970439d`… | identical outside immutables |
| Movva (token) | `0xa849B93B5ec04bb1b979faE8B82F8Fb66663AAD7` | `contracts/movva/Movva.sol` | `abe9ea0c2812eb1d`… | `6bd98a4cacef194f`… | identical outside immutables |
| Movva FX leg (PythFxOracle) | `0x9E87487Af7Af6ab3959CB790dE52A52fa5e32047` | `contracts/ramp/PythFxOracle.sol` | `d484bba9344f2787`… | `2cfa6bc756bc867e`… | identical outside immutables |
| Movva band adapter (ScaledFxBandOracle) | `0x78036B4deE6ebAe7aBFCaa355E84ab3C579035F8` | `contracts/movva/ScaledFxBandOracle.sol` | `ddd60c94d0d23dab`… | `88b961945deee216`… | identical outside immutables |
| FeeSplitter | `0x37c5232936F71533f1ee3Fc104A9Baf0DEdFB640` | `contracts/movva/FeeSplitter.sol` | `5076331e39e83c74`… | `0edf5bc97e4d9a9a`… | identical outside immutables |
| NodeRewards | `0x8BB79778Bf55ca02803E5bEcCC3e1d5bD1488EE2` | `contracts/ramp/NodeRewards.sol` | `81b44f19ecbbc43b`… | `80444681149a9e9f`… | identical outside immutables |
| Movva Privacy Pool | `0xfe04F27A763e6a0CFcC2877a08e738e5068cbBB2` | `protocol/contracts/src/contracts/implementations/PrivacyPoolComplex.sol` | `0f9c34f0bfd03a35`… | `d1e5735be46a6b62`… | identical outside immutables |
| Entrypoint owner (TimelockController, 7 days) | `0x2247f974Be28177E1ca7E1DE6D4eaeE410a96e38` | `contracts/governance/EntrypointTimelock.sol` | `14b611926a466386`… | `8aba44e5b6600663`… | identical |
| AspRootQuorum (ASP postman, 2 of 3) | `0x547a0BcDcB8104396bA1c3D2EA7C6A14684e8F96` | `contracts/AspRootQuorum.sol` | `3655224154c0f599`… | `c97f949a875b07ba`… | identical outside immutables |
| RulingLib library (linked by both escrows) | `0xC18B90Ada8896EA302647c1729F1EdA0c9c700Af` | `contracts/ramp/RulingLib.sol` | `b88480f0978b003c`… | `6b982c970015f8c1`… | identical |
| SafeTransferLib library (linked by both escrows) | `0x2741827E1Dc20B892370c4703dD060e344A9C22E` | `contracts/ramp/SafeTransferLib.sol` | `aede75b2b270ac7d`… | `6b6dde5bf5c49c31`… | identical |
| LPRegistry | `0xC2c28C7E0a123816BF5ECE680FC19fBb4a6b8F0a` | `contracts/ramp/LPRegistry.sol` | `fe6d90f5d4178ba3`… | `f438a3d4a074db13`… | identical outside immutables |
| ReclaimZkTlsVerifier (PIX, boleto, TED) | `0xdB87f0170Ef6bad9805Cd7203e793e9F4dacD74e` | `contracts/ramp/ReclaimZkTlsVerifier.sol` | `12bd1cb4f076b7e0`… | `982c7593107c1fc0`… | identical outside immutables |
| FiatEscrow (Movva on-ramp) | `0xDe2e82559127CBEFB4F19E219190AC15D9Ce1456` | `contracts/ramp/FiatEscrow.sol` | `ac7a7f303abab900`… | `87153e0a2c864bd7`… | identical outside immutables |
| OffRampEscrow (Movva off-ramp) | `0xCD95EC2aF9fA84Ab588F4279C86e8e8c4449606d` | `contracts/ramp/OffRampEscrow.sol` | `edf866cebf5ed38f`… | `23ef966b63ad06a4`… | identical outside immutables |

Full hashes, artifacts and constructor arguments are in the deployment JSON under `record.contracts`. ABIs: `deployments/sepolia-movva-v6-rail/abi/` (23 files; the Entrypoint proxy's callable ABI is `Entrypoint.json`).

## Build

**Build hash `04ec2733e2be6ba0f5b563888aa4972aac11c8d4e2693362e5d686ac964cf428`**: sha256 over the concatenated runtime bytecode (artifact deployedBytecode, library placeholders as 20 zero bytes, immutables as compiled) of every distinct deployed contract, sorted by its hex. Recompute it from a checkout of the commit with `npx tsx scripts/deployment-record.ts build-hash <deployment.json>` after `forge build` in the repo root and in `protocol/contracts`.

| Contract | Build | Runtime bytes | Runtime sha256 |
|---|---|---:|---|
| AspRootQuorum | root | 2,632 | `c97f949a875b07ba5e646f77f92640548a889fd02d1a0ebed406ff7162b531b9` |
| CommitmentVerifier | protocol | 1,582 | `ebae2d48b14ac64f45fd3df64ea84a60145ec212916915548cf93a7651b80f23` |
| Entrypoint | protocol | 13,490 | `6408ed2ab26661a75035495c8676b15f9f44321fcf9b611a811efb3c82be7395` |
| EntrypointTimelock | root | 6,496 | `8aba44e5b6600663ec549adc62286e9a90e3c3434ea3c98741aed166b6354599` |
| ERC1967Proxy | protocol | 122 | `f1f38be5dd06d358ef10a9010c1b52388094c454ae2b594351c124196c631df2` |
| FeeSplitter | root | 5,772 | `0edf5bc97e4d9a9ac964ead31f952f2a713038b43c719def76bf828ab600c17d` |
| FiatEscrow | root | 24,075 | `87153e0a2c864bd768eefcc67b4fb1e05884e95bce03e7626c2e558d7c8f2036` |
| LPRegistry | root | 11,807 | `f438a3d4a074db13923fb07837eb8427a6427240096ce7f4909aaf94534f6b83` |
| Movva | root | 4,129 | `6bd98a4cacef194f9e1d7ae31f00ae08049eee42b3d31b85aae16cd238551abd` |
| MovvaReserve | root | 24,267 | `bba942d65970439d9ef746ca71de956cddc5901c78600fc321550028afe42417` |
| NodeRewards | root | 11,239 | `80444681149a9e9f52bb2dd354524ae2c7499ceef14638074902ece9b0a15b5b` |
| OffRampEscrow | root | 18,311 | `23ef966b63ad06a4abd905712bccc0435b9547317b6a1e5cc1f0bc0a5b165692` |
| OwnedTetherLike | root | 2,733 | `38c228fa6ec202bf2756140664077f4965abfed27bd201fc578d00689ad76874` |
| PoseidonT3 | protocol | 23,522 | `23a48ae4bae13d19ecdb8321c33ae70c31bd5b1c37972bc673f2d073b6026fb6` |
| PoseidonT4 | protocol | 12,584 | `e2f5e98664dbafbeb3b29dfaf490adad71c401b9fa5076c9e0b1efd853d59071` |
| PrivacyPoolComplex | protocol | 7,720 | `d1e5735be46a6b62a4e7e72e1372455087813ac08eec4f1d9880b4d23e185216` |
| PrivacyPoolSimple | protocol | 7,378 | `92fdf5ae69da7a5d9a6beaa4074806c821cbabc887dfecee95576c93e4b1c57a` |
| PythFxOracle | root | 6,527 | `2cfa6bc756bc867e1d4ee09fdabd2bf6eabebdc2e9ca748b7a3626c69c8ed3af` |
| ReclaimZkTlsVerifier | root | 18,568 | `982c7593107c1fc01e6e5c4165fb9cfc385d1eb1fd09c6c728ff584572fabf22` |
| RulingLib | root | 3,000 | `6b982c970015f8c1a7628f08fda04e3635b67c6608d02b1de5e816eacdc00496` |
| SafeTransferLib | root | 1,713 | `6b6dde5bf5c49c3102cb9e1aa9ee7c6180042350bce33cb3168cfa4991dba1ee` |
| ScaledFxBandOracle | root | 652 | `88b961945deee216d56a201ed0b5bce445a0087563d863cf43d3571b60765772` |
| WithdrawalVerifier | protocol | 1,947 | `77bfc587acc64f361df684b77293f84073e4894b61bd870fc078510562fb7bb8` |

| Build | Config | Compiler | Optimizer | EVM | viaIR | Metadata hash |
|---|---|---|---|---|---|---|
| protocol | `protocol/contracts/foundry.toml` | 0.8.28+commit.7893614a (sha256 9a0fb7e0db2c0641…) | on, 10000 runs | cancun | false | none (no CBOR) |
| root | `foundry.toml` | 0.8.28+commit.7893614a (sha256 9a0fb7e0db2c0641…) | on, 200 runs | cancun | false | none (no CBOR) |

Forge: `forge 0.3.0 (5a8bd89 2024-12-19T17:17:10.245193696Z)`. Sources: 93 files compiled into the deployed contracts, every one identical on disk to the keccak256 its build recorded.

## Checks

Every check the verification pass ran, grouped: 361 pass, 8 expected, 0 fail. "Expected" is only ever a price refusal the check predicted exactly (see Prices).

### Code at every address (25 pass)

<details><summary>25 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | code at protocol.entrypoint | 0xe5e3442940D997De3F8584aD0687C925C7178c3f |
| pass | code at protocol.entrypointImplementation | 0x3EA6De4f683f5B02D7C68339d36C2D3fB8c2F6c3 |
| pass | code at protocol.withdrawalVerifier | 0xDCD3cA51E0C69Bf516eE485E4c1b543E0F1028C6 |
| pass | code at protocol.commitmentVerifier | 0x4F52A6Eac236725ee7d4bCDd247b89c1f496Fd68 |
| pass | code at protocol.ethPool | 0x43697fFB82471b2becA56135a9A1FBd228d34703 |
| pass | code at protocol.poseidonT3 | 0x8ffdA7Ed8B4aD98C2C34f54B76821711F4a6f2C5 |
| pass | code at protocol.poseidonT4 | 0xe393dd7287Db9982e6f845824854Baf8b8e823AF |
| pass | code at standInUsdt | 0x1931A0c8de3D7bFa68a1106dF269983304eb4960 |
| pass | code at movva.reserve | 0x0E6b613E8F52036A51CdAa9A309419782d35848c |
| pass | code at movva.token | 0xa849B93B5ec04bb1b979faE8B82F8Fb66663AAD7 |
| pass | code at movva.fxLeg | 0x9E87487Af7Af6ab3959CB790dE52A52fa5e32047 |
| pass | code at movva.bandAdapter | 0x78036B4deE6ebAe7aBFCaa355E84ab3C579035F8 |
| pass | code at movva.feeSplitter | 0x37c5232936F71533f1ee3Fc104A9Baf0DEdFB640 |
| pass | code at movva.nodeRewards | 0x8BB79778Bf55ca02803E5bEcCC3e1d5bD1488EE2 |
| pass | code at pools.movva | 0xfe04F27A763e6a0CFcC2877a08e738e5068cbBB2 |
| pass | code at asp.quorum | 0x547a0BcDcB8104396bA1c3D2EA7C6A14684e8F96 |
| pass | code at ramp.registry | 0xC2c28C7E0a123816BF5ECE680FC19fBb4a6b8F0a |
| pass | code at ramp.zktls | 0xdB87f0170Ef6bad9805Cd7203e793e9F4dacD74e |
| pass | code at ramp.movvaOnramp | 0xDe2e82559127CBEFB4F19E219190AC15D9Ce1456 |
| pass | code at ramp.movvaOfframp | 0xCD95EC2aF9fA84Ab588F4279C86e8e8c4449606d |
| pass | code at ramp.rulingLib | 0xC18B90Ada8896EA302647c1729F1EdA0c9c700Af |
| pass | code at ramp.safeTransferLib | 0x2741827E1Dc20B892370c4703dD060e344A9C22E |
| pass | code at ownership.timelock | 0x2247f974Be28177E1ca7E1DE6D4eaeE410a96e38 |
| pass | code at ownership.safe | 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | code at ownership.canceller | 0xd67DDA7D07CAa45d6f8e7C1dD0a170585e6B086c |

</details>

### Governance: governor, setup, delay (40 pass)

<details><summary>40 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | MovvaReserve governor (the Safe, ossified) | 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | MovvaReserve ossified (no risk-increasing change can ever run, N-04) | true |
| pass | MovvaReserve setupComplete | true |
| pass | MovvaReserve pendingChanges (nothing queued) | 0 |
| pass | MovvaReserve GOVERNANCE_DELAY | 172800 |
| pass | Movva FX leg (PythFxOracle) governor (the Safe, ossified) | 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | Movva FX leg (PythFxOracle) ossified (no risk-increasing change can ever run, N-04) | true |
| pass | Movva FX leg (PythFxOracle) setupComplete | true |
| pass | Movva FX leg (PythFxOracle) pendingChanges (nothing queued) | 0 |
| pass | Movva FX leg (PythFxOracle) GOVERNANCE_DELAY | 172800 |
| pass | FeeSplitter governor (the Safe, ossified) | 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | FeeSplitter ossified (no risk-increasing change can ever run, N-04) | true |
| pass | FeeSplitter setupComplete | true |
| pass | FeeSplitter pendingChanges (nothing queued) | 0 |
| pass | FeeSplitter GOVERNANCE_DELAY | 172800 |
| pass | NodeRewards governor (the Safe, ossified) | 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | NodeRewards ossified (no risk-increasing change can ever run, N-04) | true |
| pass | NodeRewards setupComplete | true |
| pass | NodeRewards pendingChanges (nothing queued) | 0 |
| pass | NodeRewards GOVERNANCE_DELAY | 172800 |
| pass | LPRegistry governor (the Safe, ossified) | 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | LPRegistry ossified (no risk-increasing change can ever run, N-04) | true |
| pass | LPRegistry setupComplete | true |
| pass | LPRegistry pendingChanges (nothing queued) | 0 |
| pass | LPRegistry GOVERNANCE_DELAY | 172800 |
| pass | ReclaimZkTlsVerifier governor (the Safe, ossified) | 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | ReclaimZkTlsVerifier ossified (no risk-increasing change can ever run, N-04) | true |
| pass | ReclaimZkTlsVerifier setupComplete | true |
| pass | ReclaimZkTlsVerifier pendingChanges (nothing queued) | 0 |
| pass | ReclaimZkTlsVerifier GOVERNANCE_DELAY | 172800 |
| pass | Movva FiatEscrow governor (the Safe, ossified) | 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | Movva FiatEscrow ossified (no risk-increasing change can ever run, N-04) | true |
| pass | Movva FiatEscrow setupComplete | true |
| pass | Movva FiatEscrow pendingChanges (nothing queued) | 0 |
| pass | Movva FiatEscrow GOVERNANCE_DELAY | 172800 |
| pass | Movva OffRampEscrow governor (the Safe, ossified) | 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | Movva OffRampEscrow ossified (no risk-increasing change can ever run, N-04) | true |
| pass | Movva OffRampEscrow setupComplete | true |
| pass | Movva OffRampEscrow pendingChanges (nothing queued) | 0 |
| pass | Movva OffRampEscrow GOVERNANCE_DELAY | 172800 |

</details>

### owner (6 pass)

<details><summary>6 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | Entrypoint OWNER_ROLE held by the TimelockController (H-02) | true |
| pass | Entrypoint OWNER_ROLE: the deployer renounced it | false |
| pass | Entrypoint DEFAULT_ADMIN_ROLE: not the deployer | false |
| pass | Entrypoint: the TimelockController is the only OWNER_ROLE holder and the deployer holds no role (every RoleGranted account re-checked) | OWNER_ROLE 0x2247f974Be28177E1ca7E1DE6D4eaeE410a96e38 |
| pass | TimelockController getMinDelay (7 days) | 604800 |
| pass | TimelockController: the Safe 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 alone proposes and executes, it and 0xd67DDA7D07CAa45d6f8e7C1dD0a170585e6B086c cancel (N-19); executor not open; it administers itself | PROPOSER, EXECUTOR: the Safe; CANCELLER: 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1, 0xd67DDA7D07CAa45d6f8e7C1dD0a170585e6B086c; DEFAULT_ADMIN: the timelock |

</details>

### Privacy Pools: Entrypoint roles and pools (7 pass)

<details><summary>7 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | Entrypoint: upstream's ETH pool removed (M-18) | 0x0000000000000000000000000000000000000000 |
| pass | upstream's ETH pool wound down (dead) | true |
| pass | Entrypoint holds no MOVVA fees | 0 units |
| pass | Entrypoint holds no ETH | 0 wei |
| pass | Entrypoint Movva pool (as the clean-up set it) | 0xfe04F27A763e6a0CFcC2877a08e738e5068cbBB2,1000000000000000000,10,100 |
| pass | Movva pool ENTRYPOINT | 0xe5e3442940D997De3F8584aD0687C925C7178c3f |
| pass | Movva pool ASSET | 0xa849B93B5ec04bb1b979faE8B82F8Fb66663AAD7 |

</details>

### ASP postman: the AspRootQuorum (12 pass)

<details><summary>12 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | AspRootQuorum ENTRYPOINT | 0xe5e3442940D997De3F8584aD0687C925C7178c3f |
| pass | AspRootQuorum THRESHOLD | 2 |
| pass | AspRootQuorum ASP_COUNT | 3 |
| pass | AspRootQuorum asps() are the recorded ASPs, in order | 0x6f239a1A5818808E63BB6F35A88B9876a79aa973,0xc8510850c5bF41B52399473F234577B2d8Ef0B16,0x323574Eb0c63b764F06832f15B21956bb8979FC9 |
| pass | the recorded ASPs are the seed's asp/0..2 (asp/0 = Movva; asp/1, asp/2 stand-ins) | 0x6f239a1A5818808E63BB6F35A88B9876a79aa973,0xc8510850c5bF41B52399473F234577B2d8Ef0B16,0x323574Eb0c63b764F06832f15B21956bb8979FC9 |
| pass | AspRootQuorum isAsp(asp/0) | true |
| pass | AspRootQuorum isAsp(asp/1) | true |
| pass | AspRootQuorum isAsp(asp/2) | true |
| pass | AspRootQuorum isAsp(deployer) is false | false |
| pass | Entrypoint ASP_POSTMAN held by the AspRootQuorum | true |
| pass | Entrypoint ASP_POSTMAN revoked from the deployer | false |
| pass | Entrypoint ASP_POSTMAN held by the quorum only (every RoleGranted account re-checked) | 0x547a0BcDcB8104396bA1c3D2EA7C6A14684e8F96 |

</details>

### Movva: reserve, FX leg, fees, rewards (48 pass)

<details><summary>48 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | reserve MOVVA | 0xa849B93B5ec04bb1b979faE8B82F8Fb66663AAD7 |
| pass | token RESERVE | 0x0E6b613E8F52036A51CdAa9A309419782d35848c |
| pass | reserve USDT (stand-in) | 0x1931A0c8de3D7bFa68a1106dF269983304eb4960 |
| pass | reserve USDT/USD feed (Chainlink USDC/USD) | 0xA2F78ab2355fe2f984D808B5CeE7FD0A93D5270E |
| pass | reserve FX oracle | 0x9E87487Af7Af6ab3959CB790dE52A52fa5e32047 |
| pass | reserve has no distribute() (D1: no savings path) | reverts with no data; selector not in the code |
| pass | reserve has no previewDistribute() (D1: no savings path) | reverts with no data; selector not in the code |
| pass | reserve has no savings() (D1: no savings path) | reverts with no data; selector not in the code |
| pass | reserve has no distributionFeeBps() (D1: no savings path) | reverts with no data; selector not in the code |
| pass | reserve has no withdrawToHedge(uint256) (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no queueHedgeWithdrawal(uint256) (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no executeHedgeWithdrawal(uint256) (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no hedgeWithdrawable() (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no hedgeLimitBps() (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no hedgeUsed() (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no hedgeUsedAt() (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no hedgeRequests(uint256) (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no hedgeRequestCount() (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no HEDGE_QUEUE_DELAY() (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no minWithdrawCollateralRatioBps() (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no treasurer() (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no hedgeTreasury() (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no setTreasurer(address) (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no setHedgeTreasury(address) (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no setLimits(uint256,uint16) (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no sweep(address) (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no rescue(address,address,uint256) (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve yield recipient (principal-locked: the only payee of harvestYield) | 0x622F626F912AD25d36D9B8F48907Ac941F755ACb |
| pass | reserve principalUsdt (the cost basis: mint + recapitalize - redeem) | 0 with a supply of 0 |
| pass | reserve setYieldRecipient from the governor must be scheduled (delayed both ways), or refused for good once ossified | Ossified: the recipient can never change |
| pass | reserve guardian | 0xd67DDA7D07CAa45d6f8e7C1dD0a170585e6B086c |
| pass | reserve MAX_VAULT_BPS, MIN_ROUND_TRIP_FEE_BPS (N-03, N-06) | 9000,20 |
| pass | reserve TRADE_FX_MAX_AGE (N-06; zero for a Chainlink leg) | 300 |
| pass | reserve keyless exit delays (ORACLE_EXIT_DELAY, GATEWAY_EXIT_DELAY; N-01, N-02) | 604800,2592000 |
| pass | reserve mintPaused | false |
| pass | reserve fee recipient is the FeeSplitter | 0x37c5232936F71533f1ee3Fc104A9Baf0DEdFB640 |
| pass | reserve fees (mint, redeem bps) | 10,10 |
| pass | reserve supply cap | 1000000000000000000000000 |
| pass | reserve gateway (the off-ramp's redeemer): test LP 0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C | true |
| pass | reserve gateway (the off-ramp's redeemer): institutional LP 0xf491FA29debC0D12d8F7c57B17995C2346F025AD | true |
| pass | Movva FX leg PYTH | 0xDd24F84d36BF92C65F92307595335bdFab5Bbd21 |
| pass | Movva FX leg usdBrlId | 0xd2db4dbf1aea74e0f666b0e8f73b9580d407f5e5cf931940b06dc633d7a95906 |
| pass | Movva FX leg maxAge / closedMaxAge / maxConfBps | 3600,345600,100 |
| pass | Movva band adapter SOURCE | 0x9E87487Af7Af6ab3959CB790dE52A52fa5e32047 |
| pass | FeeSplitter rewards | 0x8BB79778Bf55ca02803E5bEcCC3e1d5bD1488EE2 |
| pass | FeeSplitter treasury | 0x622F626F912AD25d36D9B8F48907Ac941F755ACb |
| pass | NodeRewards REWARD_TOKEN (the reserve's USDT) | 0x1931A0c8de3D7bFa68a1106dF269983304eb4960 |
| pass | NodeRewards bound to the registry | 0xC2c28C7E0a123816BF5ECE680FC19fBb4a6b8F0a |

</details>

### Ramp wiring: registry, escrows, oracles (26 pass)

<details><summary>26 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | registry phase (0 = A) | 0 |
| pass | registry rewards hook | 0x8BB79778Bf55ca02803E5bEcCC3e1d5bD1488EE2 |
| pass | registry accepts Movva FiatEscrow | true |
| pass | Movva FiatEscrow allows the zkTLS verifier | true |
| pass | Movva FiatEscrow arbitrator | true |
| pass | Movva FiatEscrow dispute timeout | 2592000 |
| pass | registry accepts Movva OffRampEscrow | true |
| pass | Movva OffRampEscrow allows the zkTLS verifier | true |
| pass | Movva OffRampEscrow arbitrator | true |
| pass | Movva OffRampEscrow dispute timeout | 2592000 |
| pass | registry: test LP is INSTITUTIONAL with its credit | tier 3, 5000000 centavos |
| pass | registry: extra LP 0xf491FA29debC0D12d8F7c57B17995C2346F025AD is INSTITUTIONAL with its credit | tier 3, 5000000 centavos |
| pass | Movva FiatEscrow TAKER_DISPUTE_TIMEOUT | 432000 |
| pass | Movva FiatEscrow MAX_VETTING_FEE_BPS | 10 |
| pass | Movva FiatEscrow MAX_VETTING_FEE_BPS covers the Movva pool's vetting fee | true |
| pass | Movva FiatEscrow Entrypoint / Movva pool | 0xe5e3442940D997De3F8584aD0687C925C7178c3f,0xfe04F27A763e6a0CFcC2877a08e738e5068cbBB2 |
| pass | Movva FiatEscrow BAND_BPS | 300 |
| pass | Movva FiatEscrow lists Movva (reserve, 18, enabled) | 0x0E6b613E8F52036A51CdAa9A309419782d35848c,18,true |
| pass | Movva FiatEscrow native ETH delisted | false |
| pass | Movva FiatEscrow stand-in USDT not listed | false |
| pass | Movva FiatEscrow ORACLE (constructor; seeds only the delisted native-ETH entry) | 0x0E6b613E8F52036A51CdAa9A309419782d35848c |
| pass | Movva OffRampEscrow BAND_BPS | 300 |
| pass | Movva OffRampEscrow lists Movva (reserve, 18, enabled) | 0x0E6b613E8F52036A51CdAa9A309419782d35848c,18,true |
| pass | Movva OffRampEscrow native ETH delisted | false |
| pass | Movva OffRampEscrow stand-in USDT not listed | false |
| pass | Movva OffRampEscrow ORACLE (constructor; seeds only the delisted native-ETH entry) | 0x0E6b613E8F52036A51CdAa9A309419782d35848c |

</details>

### Verifiers: who proves what (11 pass)

<details><summary>11 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | ReclaimZkTlsVerifier provesBankSession | true |
| pass | zktls witnesses + threshold | true |
| pass | zktls endpointCount | 4 |
| pass | zktls endpoint pix-received: a received page (N-08), txid-bound true (M-03, N-13) | 1,true |
| pass | zktls endpoint pix-received (rails, prefix) | 2,https://api.banco-lp.example/ |
| pass | zktls endpoint pix-sent: a sent page (N-08), txid-bound false (M-03, N-13) | 2,false |
| pass | zktls endpoint pix-sent (rails, prefix) | 2,https://api.banco-lp.example/ |
| pass | zktls endpoint boleto-received: a received page (N-08), txid-bound true (M-03, N-13) | 1,true |
| pass | zktls endpoint boleto-received (rails, prefix) | 4,https://api.banco-lp.example/ |
| pass | zktls endpoint boleto-paid: a sent page (N-08), txid-bound false (M-03, N-13) | 2,false |
| pass | zktls endpoint boleto-paid (rails, prefix) | 4,https://api.banco-lp.example/ |

</details>

### Prices: Chainlink freshness and the Pyth leg (1 pass, 8 expected)

<details><summary>9 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | Chainlink USDC/USD fresh for its max age | 99965505 (8 dp), 9132 s old, max 90000 |
| expected | Pyth FX.USD/BRL on Sepolia | publishTime 1792529999, 571141 s old at block 12004878; core session closed |
| expected | Movva FX leg brlCentsPerUnit (the rate) | StaleRate(1792529999) - Pyth's FX.USD/BRL is stale |
| expected | Movva FX leg brlCentsPerUnitForBand | StaleRate(1792529999) - Pyth's FX.USD/BRL is stale |
| expected | Movva band adapter brlCentsPerUnit | StaleRate(1792529999) - Pyth's FX.USD/BRL is stale |
| expected | reserve brlPerUsdtE18 (mint/redeem rate) | StaleRate(1792529999) - Pyth's FX.USD/BRL is stale |
| expected | reserve bandBrlPerUsdtE18 (Movva band) | StaleRate(1792529999) - Pyth's FX.USD/BRL is stale |
| expected | reserve brlCentsPerUnit (the Movva pair's band) | StaleRate(1792529999) - Pyth's FX.USD/BRL is stale |
| expected | reserve harvestableYield (the yield above max(principal, target)) | StaleRate(1792529999) - Pyth's FX.USD/BRL is stale |

</details>

### Bytecode: each address runs this commit's build (46 pass)

<details><summary>46 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | every source file the deployed contracts were compiled from is the file on disk (keccak256 in the build metadata) | 93 files |
| pass | the commit is clean for every build input | 0c4b828f7dd5498ca93cdf62b48ced0e5c56a7ad, tree clean |
| pass | no build input changed during the run | HEAD moved from 0c4b828f7dd5498ca93cdf62b48ced0e5c56a7ad to 9eef4ef8aa6b10b3a8ab3414fbb6fa10590d1cd8; the 1 file(s) that differ (scripts/deploy-permissionless-registry.ts) are none a build input |
| pass | Privacy Pools Entrypoint (proxy) runs the build's ERC1967Proxy | 0xe5e3442940D997De3F8584aD0687C925C7178c3f: 122 bytes, identical |
| pass | Privacy Pools Entrypoint (proxy): creation code is the build's, followed by its constructor arguments | tx 0xff036485c6b40537e025c35514c83ffd6da35bab43524f230a5d5e0cdfd91b63 (createx), 192 bytes of arguments |
| pass | Entrypoint implementation runs the build's Entrypoint | 0x3EA6De4f683f5B02D7C68339d36C2D3fB8c2F6c3: 13490 bytes, identical outside 3 immutable site(s) (96 bytes masked) |
| pass | Entrypoint implementation: creation code is the build's, followed by its constructor arguments | tx 0xae8f420aad3df163fca2e9d9652699a5e8a50c7b23cdf9265702bbc69d6741eb (createx), 0 bytes of arguments |
| pass | Withdrawal Groth16 verifier runs the build's WithdrawalVerifier | 0xDCD3cA51E0C69Bf516eE485E4c1b543E0F1028C6: 1947 bytes, identical |
| pass | Withdrawal Groth16 verifier: creation code is the build's, followed by its constructor arguments | tx 0x42fa14b5d0fa7bec0cd380a8a6297b35f34907fdbb4d8ac3320f938b160a2516 (createx), 0 bytes of arguments |
| pass | Ragequit (commitment) Groth16 verifier runs the build's CommitmentVerifier | 0x4F52A6Eac236725ee7d4bCDd247b89c1f496Fd68: 1582 bytes, identical |
| pass | Ragequit (commitment) Groth16 verifier: creation code is the build's, followed by its constructor arguments | tx 0x545bcfe586bdb46b542d59766be31c367a6a103ed0180cb71f1163befa90a1be (createx), 0 bytes of arguments |
| pass | ETH Privacy Pool (upstream's; unused by the product) runs the build's PrivacyPoolSimple | 0x43697fFB82471b2becA56135a9A1FBd228d34703: 7378 bytes, identical outside 12 immutable site(s) (384 bytes masked) |
| pass | ETH Privacy Pool (upstream's; unused by the product): creation code is the build's, followed by its constructor arguments | tx 0x5734a0cfd1fff763629a33a2180abeefb7934ff4a57d3b8ad844c398957d59fc (createx), 96 bytes of arguments |
| pass | PoseidonT3 library runs the build's PoseidonT3 | 0x8ffdA7Ed8B4aD98C2C34f54B76821711F4a6f2C5: 23522 bytes, identical |
| pass | PoseidonT4 library runs the build's PoseidonT4 | 0xe393dd7287Db9982e6f845824854Baf8b8e823AF: 12584 bytes, identical |
| pass | Stand-in USDT (OwnedTetherLike) runs the build's OwnedTetherLike | 0x1931A0c8de3D7bFa68a1106dF269983304eb4960: 2733 bytes, identical |
| pass | Stand-in USDT (OwnedTetherLike): creation code is the build's, followed by its constructor arguments | tx 0x5337c3c0028729a4b01fc239488ecfbd50f46d5d0c982ecd1d533a8d942b1c8e (create), 32 bytes of arguments |
| pass | MovvaReserve runs the build's MovvaReserve | 0x0E6b613E8F52036A51CdAa9A309419782d35848c: 24267 bytes, identical outside 47 immutable site(s) (1504 bytes masked) |
| pass | MovvaReserve: creation code is the build's, followed by its constructor arguments | tx 0x512dcac4dfe6433e8854191af394648aa662c06e9fcc8123b2ad6b767c155379 (create), 640 bytes of arguments |
| pass | Movva (token) runs the build's Movva | 0xa849B93B5ec04bb1b979faE8B82F8Fb66663AAD7: 4129 bytes, identical outside 10 immutable site(s) (320 bytes masked) |
| pass | Movva FX leg (PythFxOracle) runs the build's PythFxOracle | 0x9E87487Af7Af6ab3959CB790dE52A52fa5e32047: 6527 bytes, identical outside 5 immutable site(s) (160 bytes masked) |
| pass | Movva FX leg (PythFxOracle): creation code is the build's, followed by its constructor arguments | tx 0x4896a214a918b51df9188744a5b8c22ae4002bcaf00344257fc37c22106bc7ca (create), 224 bytes of arguments |
| pass | Movva band adapter (ScaledFxBandOracle) runs the build's ScaledFxBandOracle | 0x78036B4deE6ebAe7aBFCaa355E84ab3C579035F8: 652 bytes, identical outside 2 immutable site(s) (64 bytes masked) |
| pass | Movva band adapter (ScaledFxBandOracle): creation code is the build's, followed by its constructor arguments | tx 0xd3a7b36d62b0ea8174288745d9841c0d29ca49412dc228e207bb98d10bfd6f1e (create), 32 bytes of arguments |
| pass | FeeSplitter runs the build's FeeSplitter | 0x37c5232936F71533f1ee3Fc104A9Baf0DEdFB640: 5772 bytes, identical outside 8 immutable site(s) (256 bytes masked) |
| pass | FeeSplitter: creation code is the build's, followed by its constructor arguments | tx 0xe7a41828bd26f666d19b4583c2fe73eb5f071f6b6f59cc869d0d65bf568cadc4 (create), 160 bytes of arguments |
| pass | NodeRewards runs the build's NodeRewards | 0x8BB79778Bf55ca02803E5bEcCC3e1d5bD1488EE2: 11239 bytes, identical outside 27 immutable site(s) (864 bytes masked) |
| pass | NodeRewards: creation code is the build's, followed by its constructor arguments | tx 0xff279ca7d8763cb45b03ea1d3b9faed4fbd5073016b755c5b2e217506e2e1690 (create), 224 bytes of arguments |
| pass | Movva Privacy Pool runs the build's PrivacyPoolComplex | 0xfe04F27A763e6a0CFcC2877a08e738e5068cbBB2: 7720 bytes, identical outside 14 immutable site(s) (448 bytes masked) |
| pass | Movva Privacy Pool: creation code is the build's, followed by its constructor arguments | tx 0x0c9eaa0fd2e6dc8ea118ffa975ac50a6e2125262ff89bdb8bf3055d7a2e66213 (createx), 128 bytes of arguments |
| pass | Entrypoint owner (TimelockController, 7 days) runs the build's EntrypointTimelock | 0x2247f974Be28177E1ca7E1DE6D4eaeE410a96e38: 6496 bytes, identical |
| pass | Entrypoint owner (TimelockController, 7 days): creation code is the build's, followed by its constructor arguments | tx 0xb894d90598493fbd4714af2d5685d13e4023ca0e29be91b290fd7afd9e127b4a (create), 352 bytes of arguments |
| pass | AspRootQuorum (ASP postman, 2 of 3) runs the build's AspRootQuorum | 0x547a0BcDcB8104396bA1c3D2EA7C6A14684e8F96: 2632 bytes, identical outside 7 immutable site(s) (224 bytes masked) |
| pass | AspRootQuorum (ASP postman, 2 of 3): creation code is the build's, followed by its constructor arguments | tx 0xfe459d4cfac97c7a2372fb55c9584dbbebd0370e1072b257ac577768d296d38d (create), 256 bytes of arguments |
| pass | RulingLib library (linked by both escrows) runs the build's RulingLib | 0xC18B90Ada8896EA302647c1729F1EdA0c9c700Af: 3000 bytes, identical |
| pass | RulingLib library (linked by both escrows): creation code is the build's, followed by its constructor arguments | tx 0x1c73a2b1ea36fe5db8c19fc8c0b518abcf92d952142ef21e95c9cab25a4cae98 (create2), 0 bytes of arguments |
| pass | SafeTransferLib library (linked by both escrows) runs the build's SafeTransferLib | 0x2741827E1Dc20B892370c4703dD060e344A9C22E: 1713 bytes, identical |
| pass | SafeTransferLib library (linked by both escrows): creation code is the build's, followed by its constructor arguments | tx 0xa7a17e87ef2060adf28325d5b3723f870b0d2244567fca67e112d90287cf30cf (create2), 0 bytes of arguments |
| pass | LPRegistry runs the build's LPRegistry | 0xC2c28C7E0a123816BF5ECE680FC19fBb4a6b8F0a: 11807 bytes, identical outside 3 immutable site(s) (96 bytes masked) |
| pass | LPRegistry: creation code is the build's, followed by its constructor arguments | tx 0xfcad87b84107f8b4808c0254fbd97b5e8a17f7e51d28c8e85d4c0a3ced74678f (create), 64 bytes of arguments |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED) runs the build's ReclaimZkTlsVerifier | 0xdB87f0170Ef6bad9805Cd7203e793e9F4dacD74e: 18568 bytes, identical outside 3 immutable site(s) (96 bytes masked) |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): creation code is the build's, followed by its constructor arguments | tx 0x0224f0618b3a5e400a96555cdd97a9c3e3b4524fe11a502f7df87549bf356272 (create), 896 bytes of arguments |
| pass | FiatEscrow (Movva on-ramp) runs the build's FiatEscrow | 0xDe2e82559127CBEFB4F19E219190AC15D9Ce1456: 24075 bytes, identical outside 29 immutable site(s) (928 bytes masked) |
| pass | FiatEscrow (Movva on-ramp): creation code is the build's, followed by its constructor arguments | tx 0xa559f64118c788e32d65d1edaa3250d417d1eb5c7153c8e69002fbb3708eba32 (create), 320 bytes of arguments |
| pass | OffRampEscrow (Movva off-ramp) runs the build's OffRampEscrow | 0xCD95EC2aF9fA84Ab588F4279C86e8e8c4449606d: 18311 bytes, identical outside 23 immutable site(s) (736 bytes masked) |
| pass | OffRampEscrow (Movva off-ramp): creation code is the build's, followed by its constructor arguments | tx 0xe4218a0b61e8534e900af986d1f710fe0212fbee5a74c88c5777aa292bffdc45 (create), 192 bytes of arguments |

</details>

### Etherscan readiness (dry run, nothing submitted) (23 pass)

<details><summary>23 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | Privacy Pools Entrypoint (proxy): the verify-contract input recompiles to the code at the address | 8 sources, runs 10000, bytecodeHash none: runtime exact, creation code and arguments equal the creation transaction |
| pass | Entrypoint implementation: the verify-contract input recompiles to the code at the address | 27 sources, runs 10000, bytecodeHash none: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | Withdrawal Groth16 verifier: the verify-contract input recompiles to the code at the address | 1 sources, runs 10000, bytecodeHash none: runtime exact, creation code and arguments equal the creation transaction |
| pass | Ragequit (commitment) Groth16 verifier: the verify-contract input recompiles to the code at the address | 1 sources, runs 10000, bytecodeHash none: runtime exact, creation code and arguments equal the creation transaction |
| pass | ETH Privacy Pool (upstream's; unused by the product): the verify-contract input recompiles to the code at the address | 15 sources, runs 10000, bytecodeHash none: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | PoseidonT3 library: the verify-contract input recompiles to the code at the address | 1 sources, runs 10000, bytecodeHash none: runtime exact |
| pass | PoseidonT4 library: the verify-contract input recompiles to the code at the address | 1 sources, runs 10000, bytecodeHash none: runtime exact |
| pass | Stand-in USDT (OwnedTetherLike): the verify-contract input recompiles to the code at the address | 1 sources, runs 200, bytecodeHash none: runtime exact, creation code and arguments equal the creation transaction |
| pass | MovvaReserve: the verify-contract input recompiles to the code at the address | 37 sources, runs 200, bytecodeHash none: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | Movva (token): the verify-contract input recompiles to the code at the address | 20 sources, runs 200, bytecodeHash none: runtime exact-except-immutables |
| pass | Movva FX leg (PythFxOracle): the verify-contract input recompiles to the code at the address | 6 sources, runs 200, bytecodeHash none: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | Movva band adapter (ScaledFxBandOracle): the verify-contract input recompiles to the code at the address | 3 sources, runs 200, bytecodeHash none: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | FeeSplitter: the verify-contract input recompiles to the code at the address | 11 sources, runs 200, bytecodeHash none: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | NodeRewards: the verify-contract input recompiles to the code at the address | 17 sources, runs 200, bytecodeHash none: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | Movva Privacy Pool: the verify-contract input recompiles to the code at the address | 21 sources, runs 10000, bytecodeHash none: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | Entrypoint owner (TimelockController, 7 days): the verify-contract input recompiles to the code at the address | 13 sources, runs 200, bytecodeHash none: runtime exact, creation code and arguments equal the creation transaction |
| pass | AspRootQuorum (ASP postman, 2 of 3): the verify-contract input recompiles to the code at the address | 1 sources, runs 200, bytecodeHash none: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | RulingLib library (linked by both escrows): the verify-contract input recompiles to the code at the address | 1 sources, runs 200, bytecodeHash none: runtime exact, creation code and arguments equal the creation transaction |
| pass | SafeTransferLib library (linked by both escrows): the verify-contract input recompiles to the code at the address | 1 sources, runs 200, bytecodeHash none: runtime exact, creation code and arguments equal the creation transaction |
| pass | LPRegistry: the verify-contract input recompiles to the code at the address | 4 sources, runs 200, bytecodeHash none: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): the verify-contract input recompiles to the code at the address | 3 sources, runs 200, bytecodeHash none: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | FiatEscrow (Movva on-ramp): the verify-contract input recompiles to the code at the address | 9 sources, runs 200, bytecodeHash none: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | OffRampEscrow (Movva off-ramp): the verify-contract input recompiles to the code at the address | 8 sources, runs 200, bytecodeHash none: runtime exact-except-immutables, creation code and arguments equal the creation transaction |

</details>

### Privileges: roles, gates, proxies (116 pass)

<details><summary>116 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | Privacy Pools Entrypoint (proxy): every state-changing function classified | 15 functions in the ABI, all in the catalog |
| pass | Privacy Pools Entrypoint (proxy): a stranger is refused by every gated function | 11 gated functions, each refused with its own error |
| pass | Privacy Pools Entrypoint (proxy): EIP-1967 implementation is the recorded one; admin and beacon slots empty | implementation 0x3EA6De4f683f5B02D7C68339d36C2D3fB8c2F6c3, admin empty, beacon empty |
| pass | Entrypoint: OWNER_ROLE held by the recorded timelock alone (every owner action waits its delay) | 0x2247f974Be28177E1ca7E1DE6D4eaeE410a96e38 |
| pass | Entrypoint: the deployer passes none of its 8 owner functions | refused by every one |
| pass | Entrypoint: no DEFAULT_ADMIN_ROLE holder | none |
| pass | Entrypoint: ASP_POSTMAN held by the postman alone | 0x547a0BcDcB8104396bA1c3D2EA7C6A14684e8F96 |
| pass | Entrypoint: no role beyond OWNER_ROLE, ASP_POSTMAN and DEFAULT_ADMIN_ROLE was ever granted | none |
| pass | Entrypoint implementation: every state-changing function classified | 15 functions in the ABI, all in the catalog |
| pass | Entrypoint implementation: a stranger is refused by every gated function | 11 gated functions, each refused with its own error |
| pass | Entrypoint implementation: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | Entrypoint implementation: initializers disabled (nobody can initialize it and take its roles) | Initializable version 18446744073709551615 |
| pass | Withdrawal Groth16 verifier: every state-changing function classified | 0 functions in the ABI, all in the catalog |
| pass | Withdrawal Groth16 verifier: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | Ragequit (commitment) Groth16 verifier: every state-changing function classified | 0 functions in the ABI, all in the catalog |
| pass | Ragequit (commitment) Groth16 verifier: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | ETH Privacy Pool (upstream's; unused by the product): every state-changing function classified | 4 functions in the ABI, all in the catalog |
| pass | ETH Privacy Pool (upstream's; unused by the product): a stranger is refused by every gated function | 2 gated functions, each refused with its own error |
| pass | ETH Privacy Pool (upstream's; unused by the product): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | PoseidonT3 library: every state-changing function classified | 0 functions in the ABI, all in the catalog |
| pass | PoseidonT3 library: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | PoseidonT4 library: every state-changing function classified | 0 functions in the ABI, all in the catalog |
| pass | PoseidonT4 library: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | Stand-in USDT (OwnedTetherLike): every state-changing function classified | 9 functions in the ABI, all in the catalog |
| pass | Stand-in USDT (OwnedTetherLike): a stranger is refused by every gated function | 5 gated functions, each refused with its own error |
| pass | Stand-in USDT (OwnedTetherLike): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | MovvaReserve: every state-changing function classified | 33 functions in the ABI, all in the catalog |
| pass | MovvaReserve: a stranger is refused by every gated function | 27 gated functions, each refused with its own error |
| pass | MovvaReserve: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | MovvaReserve: no pending scheduled change | none |
| pass | MovvaReserve: ossified; the guardian is kept, and only it and the governor pass pauseMint | guardian 0xd67DDA7D07CAa45d6f8e7C1dD0a170585e6B086c; pauseMint refused for every other probed caller |
| pass | MovvaReserve: ossified (no risk-increasing change can ever run), its governor not the deployer, and the deployer passes none of its 21 governor functions | governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | Movva (token): every state-changing function classified | 6 functions in the ABI, all in the catalog |
| pass | Movva (token): a stranger is refused by every gated function | 2 gated functions, each refused with its own error |
| pass | Movva (token): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | Movva FX leg (PythFxOracle): every state-changing function classified | 10 functions in the ABI, all in the catalog |
| pass | Movva FX leg (PythFxOracle): a stranger is refused by every gated function | 9 gated functions, each refused with its own error |
| pass | Movva FX leg (PythFxOracle): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | Movva FX leg (PythFxOracle): no pending scheduled change | none |
| pass | Movva FX leg (PythFxOracle): ossified (no risk-increasing change can ever run), its governor not the deployer, and the deployer passes none of its 9 governor functions | governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | Movva band adapter (ScaledFxBandOracle): every state-changing function classified | 0 functions in the ABI, all in the catalog |
| pass | Movva band adapter (ScaledFxBandOracle): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | FeeSplitter: every state-changing function classified | 12 functions in the ABI, all in the catalog |
| pass | FeeSplitter: a stranger is refused by every gated function | 10 gated functions, each refused with its own error |
| pass | FeeSplitter: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | FeeSplitter: no pending scheduled change | none |
| pass | FeeSplitter: ossified (no risk-increasing change can ever run), its governor not the deployer, and the deployer passes none of its 10 governor functions | governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | NodeRewards: every state-changing function classified | 18 functions in the ABI, all in the catalog |
| pass | NodeRewards: a stranger is refused by every gated function | 12 gated functions, each refused with its own error |
| pass | NodeRewards: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | NodeRewards: no pending scheduled change | none |
| pass | NodeRewards: ossified (no risk-increasing change can ever run), its governor not the deployer, and the deployer passes none of its 11 governor functions | governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | Movva Privacy Pool: every state-changing function classified | 4 functions in the ABI, all in the catalog |
| pass | Movva Privacy Pool: a stranger is refused by every gated function | 2 gated functions, each refused with its own error |
| pass | Movva Privacy Pool: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | Entrypoint owner (TimelockController, 7 days): every state-changing function classified | 13 functions in the ABI, all in the catalog |
| pass | Entrypoint owner (TimelockController, 7 days): a stranger is refused by every gated function | 9 gated functions, each refused with its own error |
| pass | Entrypoint owner (TimelockController, 7 days): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | AspRootQuorum (ASP postman, 2 of 3): every state-changing function classified | 2 functions in the ABI, all in the catalog |
| pass | AspRootQuorum (ASP postman, 2 of 3): a stranger is refused by every gated function | 2 gated functions, each refused with its own error |
| pass | AspRootQuorum (ASP postman, 2 of 3): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | AspRootQuorum (ASP postman, 2 of 3): its ASPs are exactly the recorded 3 | 0x6f239a1A5818808E63BB6F35A88B9876a79aa973, 0xc8510850c5bF41B52399473F234577B2d8Ef0B16, 0x323574Eb0c63b764F06832f15B21956bb8979FC9 |
| pass | AspRootQuorum (ASP postman, 2 of 3): only its ASPs pass vote | admitted: 0xc8510850c5bF41B52399473F234577B2d8Ef0B16, 0x6f239a1A5818808E63BB6F35A88B9876a79aa973, 0x323574Eb0c63b764F06832f15B21956bb8979FC9 |
| pass | RulingLib library (linked by both escrows): every state-changing function classified | 0 functions in the ABI, all in the catalog |
| pass | RulingLib library (linked by both escrows): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | SafeTransferLib library (linked by both escrows): every state-changing function classified | 0 functions in the ABI, all in the catalog |
| pass | SafeTransferLib library (linked by both escrows): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | LPRegistry: every state-changing function classified | 21 functions in the ABI, all in the catalog |
| pass | LPRegistry: a stranger is refused by every gated function | 14 gated functions, each refused with its own error |
| pass | LPRegistry: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | LPRegistry: no pending scheduled change | none |
| pass | LPRegistry: ossified (no risk-increasing change can ever run), its governor not the deployer, and the deployer passes none of its 12 governor functions | governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): every state-changing function classified | 16 functions in the ABI, all in the catalog |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): a stranger is refused by every gated function | 15 gated functions, each refused with its own error |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): no pending scheduled change | none |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): ossified (no risk-increasing change can ever run), its governor not the deployer, and the deployer passes none of its 15 governor functions | governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | FiatEscrow (Movva on-ramp): every state-changing function classified | 30 functions in the ABI, all in the catalog |
| pass | FiatEscrow (Movva on-ramp): a stranger is refused by every gated function | 11 gated functions, each refused with its own error |
| pass | FiatEscrow (Movva on-ramp): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | FiatEscrow (Movva on-ramp): no pending scheduled change | none |
| pass | FiatEscrow (Movva on-ramp): ossified (no risk-increasing change can ever run), its governor not the deployer, and the deployer passes none of its 11 governor functions | governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | OffRampEscrow (Movva off-ramp): every state-changing function classified | 22 functions in the ABI, all in the catalog |
| pass | OffRampEscrow (Movva off-ramp): a stranger is refused by every gated function | 11 gated functions, each refused with its own error |
| pass | OffRampEscrow (Movva off-ramp): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | OffRampEscrow (Movva off-ramp): no pending scheduled change | none |
| pass | OffRampEscrow (Movva off-ramp): ossified (no risk-increasing change can ever run), its governor not the deployer, and the deployer passes none of its 11 governor functions | governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | ETH Privacy Pool (upstream's; unused by the product): ENTRYPOINT (immutable) is exactly the recorded set | 0xe5e3442940D997De3F8584aD0687C925C7178c3f |
| pass | Movva Privacy Pool: ENTRYPOINT (immutable) is exactly the recorded set | 0xe5e3442940D997De3F8584aD0687C925C7178c3f |
| pass | Entrypoint owner (TimelockController, 7 days): proposer is exactly the recorded set | 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | Entrypoint owner (TimelockController, 7 days): canceller is exactly the recorded set | 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1, 0xd67DDA7D07CAa45d6f8e7C1dD0a170585e6B086c |
| pass | Entrypoint owner (TimelockController, 7 days): executor is exactly the recorded set | 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | Entrypoint owner (TimelockController, 7 days): admin (DEFAULT_ADMIN_ROLE) is exactly the recorded set | 0x2247f974Be28177E1ca7E1DE6D4eaeE410a96e38 |
| pass | AspRootQuorum (ASP postman, 2 of 3): ASP is exactly the recorded set | 0x6f239a1A5818808E63BB6F35A88B9876a79aa973, 0xc8510850c5bF41B52399473F234577B2d8Ef0B16, 0x323574Eb0c63b764F06832f15B21956bb8979FC9 |
| pass | AspRootQuorum (ASP postman, 2 of 3): ENTRYPOINT (immutable) is exactly the recorded set | 0xe5e3442940D997De3F8584aD0687C925C7178c3f |
| pass | MovvaReserve: guardian is exactly the recorded set | 0xd67DDA7D07CAa45d6f8e7C1dD0a170585e6B086c |
| pass | MovvaReserve: gateway is exactly the recorded set | 0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C, 0xf491FA29debC0D12d8F7c57B17995C2346F025AD |
| pass | MovvaReserve: yield recipient (payee) is exactly the recorded set | 0x622F626F912AD25d36D9B8F48907Ac941F755ACb |
| pass | MovvaReserve: fee recipient (payee) is exactly the recorded set | 0x37c5232936F71533f1ee3Fc104A9Baf0DEdFB640 |
| pass | MovvaReserve: yield vault is exactly the recorded set | none |
| pass | Movva (token): minter (RESERVE, immutable) is exactly the recorded set | 0x0E6b613E8F52036A51CdAa9A309419782d35848c |
| pass | FeeSplitter: treasury (payee) is exactly the recorded set | 0x622F626F912AD25d36D9B8F48907Ac941F755ACb |
| pass | FeeSplitter: rewards (payee) is exactly the recorded set | 0x8BB79778Bf55ca02803E5bEcCC3e1d5bD1488EE2 |
| pass | NodeRewards: registry (reports settlements) is exactly the recorded set | 0xC2c28C7E0a123816BF5ECE680FC19fBb4a6b8F0a |
| pass | NodeRewards: excluded LP is exactly the recorded set | none |
| pass | LPRegistry: escrow is exactly the recorded set | 0xDe2e82559127CBEFB4F19E219190AC15D9Ce1456, 0xCD95EC2aF9fA84Ab588F4279C86e8e8c4449606d |
| pass | LPRegistry: rewards hook is exactly the recorded set | 0x8BB79778Bf55ca02803E5bEcCC3e1d5bD1488EE2 |
| pass | LPRegistry: LP (tier > NONE) is exactly the recorded set | 0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C, 0xf491FA29debC0D12d8F7c57B17995C2346F025AD |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): witness is exactly the recorded set | 0x05EfF3D8e0ad59Aa8abFd94E0b08402ec0850Fbf, 0x8771D8B0038061D7872e4c2C69cD63F54380CBAb, 0x72C1a86B73Ca01Fec5e07160AE14a32849eE5214 |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): bank endpoint (providerHash) is exactly the recorded set | 0xb54d2a19bba3a502dc449c083cd2579885618e4e0487435aae1673f06baf0c05, 0xd8d90d629dc91348bf69c3c5148cd5bf1efdc99220a15a6f42d6ad42eeb2bb20, 0x8259a0510dbf7425215eada80e9a8fcc1bac48d4e24e3cea67b5185b482abf77, 0xf02c2badc915c0c690ccba5dd00202b6efcc3d49a1c1197db4026f075aaddc1a |
| pass | FiatEscrow (Movva on-ramp): arbitrator is exactly the recorded set | 0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7 |
| pass | FiatEscrow (Movva on-ramp): allowed verifier is exactly the recorded set | 0xdB87f0170Ef6bad9805Cd7203e793e9F4dacD74e |
| pass | FiatEscrow (Movva on-ramp): listed asset (enabled) is exactly the recorded set | 0xa849B93B5ec04bb1b979faE8B82F8Fb66663AAD7 |
| pass | OffRampEscrow (Movva off-ramp): arbitrator is exactly the recorded set | 0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7 |
| pass | OffRampEscrow (Movva off-ramp): allowed verifier is exactly the recorded set | 0xdB87f0170Ef6bad9805Cd7203e793e9F4dacD74e |
| pass | OffRampEscrow (Movva off-ramp): listed asset (enabled) is exactly the recorded set | 0xa849B93B5ec04bb1b979faE8B82F8Fb66663AAD7 |

</details>

## Privileges

Read from the chain at block 12004878, after `--finalize`; the inventory before it was taken at block 12004820. For every contract: who holds each role, what the role can and cannot do (as the contract's code says, with the lines), and which state-changing functions the chain admits each caller to. The function list is the ABI of the build, so a function nobody classified would show as UNKNOWN and fail the checks: 0 do.

Probing: every state-changing function was `eth_call`ed with zero arguments from a stranger (`0x21f474a941692095F3122E1C82b9f24EC237f975`, holds nothing), the deployer and every current holder. "Refused" means the contract's own authorization error; "admitted" means the call got past the gate (it may then revert on the zero arguments). Nothing was sent.

### What --finalize renounced

- MovvaReserve (0x0E6b613E8F52036A51CdAa9A309419782d35848c): ossified; governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 keeps the brakes only.
- Movva FX leg (PythFxOracle) (0x9E87487Af7Af6ab3959CB790dE52A52fa5e32047): ossified; governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 keeps the brakes only.
- FeeSplitter (0x37c5232936F71533f1ee3Fc104A9Baf0DEdFB640): ossified; governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 keeps the brakes only.
- NodeRewards (0x8BB79778Bf55ca02803E5bEcCC3e1d5bD1488EE2): ossified; governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 keeps the brakes only.
- LPRegistry (0xC2c28C7E0a123816BF5ECE680FC19fBb4a6b8F0a): ossified; governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 keeps the brakes only.
- ReclaimZkTlsVerifier (PIX, boleto, TED) (0xdB87f0170Ef6bad9805Cd7203e793e9F4dacD74e): ossified; governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 keeps the brakes only.
- FiatEscrow (Movva on-ramp) (0xDe2e82559127CBEFB4F19E219190AC15D9Ce1456): ossified; governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 keeps the brakes only.
- OffRampEscrow (Movva off-ramp) (0xCD95EC2aF9fA84Ab588F4279C86e8e8c4449606d): ossified; governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 keeps the brakes only.
- deployments/sepolia-movva-v6-permissionless.json ramp.movvaOnramp (0x8B9374a252cce0a72403E74C94Dfdd079c709Fee): ossified; governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 keeps the brakes only.
- deployments/sepolia-movva-v6-permissionless.json ramp.movvaOfframp (0x33897ABf9506913A494e67899f72D39Ae65b24FE): ossified; governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 keeps the brakes only.
- deployments/sepolia-v6-hedge-sleeve.json subWallet (0x04E307c1700062Bb78f12f9ae0836060e7aa6e6a): ossified; governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 keeps the brakes only.
- Before renouncing anything: the inventory at block 12004820 passed 77/77 privilege checks and 29/29 exact-set checks against the record.
- Entrypoint ASP_POSTMAN: the recorded AspRootQuorum 0x547a0BcDcB8104396bA1c3D2EA7C6A14684e8F96 alone, running this build's code (2632 bytes, identical outside 7 immutable site(s) (224 bytes masked)), 2 of 3 ASPs, bound to this Entrypoint.
- MovvaReserve yield recipient 0x622F626F912AD25d36D9B8F48907Ac941F755ACb: after --finalize the only payee of harvestYield, for good (no governor will remain to move it).
- deployments/sepolia-v6-hedge-sleeve.json subWallet (0x04E307c1700062Bb78f12f9ae0836060e7aa6e6a): keeper 0x4D0dF9bB92883cf5584c812EB84AABA55d688853 stays: an EOA by design, equal to its record; it acts only inside the sleeve's immutable bounds and pays only TREASURY.
- deployments/sepolia-v6-hedge-sleeve.json venue (0x72366Bd20702690A68ca4673E8a87B00F3CdDa3B): venue operator 0xEAB314D8E5B0AFe05ade6C2097b09016942fBF26 stays: an EOA by design (a simulator's price and funding feed; not governed, no delay to renounce).
- Chain scan (GovernorTransferred / SetupCompleted since block 12004265): 11 governed contract(s) found, none outside the 11 renounced here.
- Owned contracts (OwnershipTransferred / OwnerChanged since block 12004265): 0x1931A0c8de3D7bFa68a1106dF269983304eb4960 owned by the governor Safe 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1. Finalizing does not change an owner; each stays the Safe's (M-19).
- Entrypoint fees: 0 MOVVA units held now; they stay collectable by the TimelockController 0x2247f974Be28177E1ca7E1DE6D4eaeE410a96e38 (withdrawFees(MOVVA, treasury), a 7-day operation the Safe proposes). The owner step withdrew what it held before the hand-over: nothing.
- MovvaReserve guardian 0xd67DDA7D07CAa45d6f8e7C1dD0a170585e6B086c: kept. It can pause minting, pull USDT from the yield vault back into the reserve and pause vault deposits, and nothing else (N-03, N-28).
- Entrypoint OWNER_ROLE: kept by the TimelockController 0x2247f974Be28177E1ca7E1DE6D4eaeE410a96e38 (7 days; proposer, canceller and executor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1). The deployer holds no Entrypoint role.
- Entrypoint ASP_POSTMAN: kept by 0x547a0BcDcB8104396bA1c3D2EA7C6A14684e8F96. It posts the roots every private withdrawal needs; only a 7-day timelock operation could replace it.
- 11 DelayedGovernance contracts (8 of the rail, 3 of its siblings): 11 ossified now; setup completed here on 0. Each keeps the governor Safe for its instant, risk-reducing changes alone (N-04). A paused sleeve stays paused: resume() is a delayed change (N-20).

**How.** Each `DelayedGovernance` governor was given up with `renounceGovernor` (`contracts/common/DelayedGovernance.sol:204`): one step, to `0x000000000000000000000000000000000000dEaD`, voiding every queued change. So it is a real renunciation, not a pending two-step one (a `transferGovernor` after setup is only a proposal, v2.0 I-36). No key is known for `0x000000000000000000000000000000000000dEaD`, and no contract can be deployed there. The Entrypoint's OWNER_ROLE was given up with `renounceRole`. Every role's admin is OWNER_ROLE (`protocol/contracts/src/contracts/Entrypoint.sol:81`), so nobody can grant any role again. No contract change was needed for any of it.

**What that makes impossible.** Each item below is a function only the renounced key could call:

- upgrading the Entrypoint, or adding, removing, reconfiguring or winding down a pool (`protocol/contracts/src/contracts/Entrypoint.sol:308`, `protocol/contracts/src/contracts/Entrypoint.sol:183`, `protocol/contracts/src/contracts/Entrypoint.sol:256`).
- recovering vetting fees. Every deposit's vetting fee (each pool's `vettingFeeBPS`, in the Entrypoint checks above) stays in the Entrypoint for good: only OWNER_ROLE can withdraw them (`protocol/contracts/src/contracts/Entrypoint.sol:264`, `protocol/contracts/src/contracts/Entrypoint.sol:332`).
- raising a pool's relay-fee cap. A relayer quote above it reverts `RelayFeeGreaterThanMax` for good. Users can still withdraw directly, or ragequit (`protocol/contracts/src/contracts/Entrypoint.sol:157`).
- replacing or removing the ASP postman. Its admin role is OWNER_ROLE. The postman is the AspRootQuorum 0x547a0BcDcB8104396bA1c3D2EA7C6A14684e8F96, 2 of 3 fixed ASPs with no owner and no setter, so neither the postman nor its ASP set can ever change (`protocol/contracts/src/contracts/Entrypoint.sol:82`).
- revoking a leaked zkTLS witness key. A quorum of leaked keys can prove payments that never happened, and each such proof releases an order's crypto (`contracts/ramp/ReclaimZkTlsVerifier.sol:782`).
- revoking a leaked arbitrator key. FiatEscrow's own NatSpec says a stolen arbitrator key can drain every offer, one disputed order at a time. The one defence it names is revoking the key within RULING_DELAY (`contracts/ramp/FiatEscrow.sol:1097`, `contracts/ramp/FiatEscrow.sol:1310`, `contracts/ramp/OffRampEscrow.sol:748`).
- revoking a verifier or a bank endpoint, delisting an asset, or lowering a cap on an escrow (`contracts/ramp/FiatEscrow.sol:1302`, `contracts/ramp/ReclaimZkTlsVerifier.sol:814`, `contracts/ramp/FiatEscrow.sol:566`).
- suspending a misbehaving LP, admitting a new one, or opening Phase B or C. The network stays in its current phase with its current LPs (`contracts/ramp/LPRegistry.sol:285`, `contracts/ramp/LPRegistry.sol:254`).
- resuming Movva minting after the guardian pauses it. A pause becomes permanent (`contracts/movva/MovvaReserve.sol:997`).
- adding or removing a Movva gateway. Only gateways redeem Movva for USDT, so if every gateway key is lost nobody can redeem again (`contracts/movva/MovvaReserve.sol:838`, `contracts/movva/MovvaReserve.sol:708`).
- repointing the reserve's oracle when Pyth retires the feed. Minting and redeeming would stop at a dead feed for good (`contracts/movva/MovvaReserve.sol:931`).
- changing the yield recipient or the yield vault. The yield recipient fixed at --finalize is the only address harvestYield ever pays, and the vault the principal is invested in stays the source for good (pulling it back into the reserve needs the governor too) (`contracts/movva/MovvaReserve.sol:856`, `contracts/movva/MovvaReserve.sol:944`, `contracts/movva/MovvaReserve.sol:960`).
- voiding farmed volume or excluding an LP from node-provider rewards (`contracts/ramp/NodeRewards.sol:493`, `contracts/ramp/NodeRewards.sol:481`).
- executing any change scheduled before the handover (`contracts/common/DelayedGovernance.sol:254`).

Every "instant" brake in `docs/runbook-mainnet-deploy.md` ("If something is wrong after deployment") is one of these. After `--finalize` that table has no one to act on it. The contracts themselves never relied on a governor for users to exit: escrow timeouts refund without permission, and ragequit needs no service.

### What remains, and why

| Contract | Role | Held by |
|---|---|---|
| Privacy Pools Entrypoint (proxy) | OWNER_ROLE | `0x2247f974Be28177E1ca7E1DE6D4eaeE410a96e38` |
| Privacy Pools Entrypoint (proxy) | ASP_POSTMAN | `0x547a0BcDcB8104396bA1c3D2EA7C6A14684e8F96` |
| Stand-in USDT (OwnedTetherLike) | owner | `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1` |
| MovvaReserve | governor | `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1` |
| MovvaReserve | guardian | `0xd67DDA7D07CAa45d6f8e7C1dD0a170585e6B086c` |
| MovvaReserve | gateway | `0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C`, `0xf491FA29debC0D12d8F7c57B17995C2346F025AD` |
| Movva FX leg (PythFxOracle) | governor | `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1` |
| FeeSplitter | governor | `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1` |
| NodeRewards | governor | `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1` |
| Entrypoint owner (TimelockController, 7 days) | proposer | `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1` |
| Entrypoint owner (TimelockController, 7 days) | canceller | `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`, `0xd67DDA7D07CAa45d6f8e7C1dD0a170585e6B086c` |
| Entrypoint owner (TimelockController, 7 days) | executor | `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1` |
| AspRootQuorum (ASP postman, 2 of 3) | ASP | `0x6f239a1A5818808E63BB6F35A88B9876a79aa973`, `0xc8510850c5bF41B52399473F234577B2d8Ef0B16`, `0x323574Eb0c63b764F06832f15B21956bb8979FC9` |
| LPRegistry | governor | `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1` |
| LPRegistry | LP (tier > NONE) | `0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C`, `0xf491FA29debC0D12d8F7c57B17995C2346F025AD` |
| ReclaimZkTlsVerifier (PIX, boleto, TED) | governor | `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1` |
| ReclaimZkTlsVerifier (PIX, boleto, TED) | witness | `0x05EfF3D8e0ad59Aa8abFd94E0b08402ec0850Fbf`, `0x8771D8B0038061D7872e4c2C69cD63F54380CBAb`, `0x72C1a86B73Ca01Fec5e07160AE14a32849eE5214` |
| FiatEscrow (Movva on-ramp) | governor | `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1` |
| FiatEscrow (Movva on-ramp) | arbitrator | `0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7` |
| OffRampEscrow (Movva off-ramp) | governor | `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1` |
| OffRampEscrow (Movva off-ramp) | arbitrator | `0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7` |

Why each remains:

- **ASP postman** (Entrypoint `ASP_POSTMAN`). A private withdrawal must prove membership in the latest association-set root (`protocol/contracts/src/contracts/PrivacyPool.sol:59`), and only the postman posts roots (`protocol/contracts/src/contracts/Entrypoint.sol:93`). Without it, new deposits could only leave by ragequit (`protocol/contracts/src/contracts/PrivacyPool.sol:132`). It can admit or leave out deposits; it cannot move funds. The postman is the AspRootQuorum `0x547a0BcDcB8104396bA1c3D2EA7C6A14684e8F96`: a root is posted only when 2 of its 3 fixed ASPs (`0x6f239a1A5818808E63BB6F35A88B9876a79aa973`, `0xc8510850c5bF41B52399473F234577B2d8Ef0B16`, `0x323574Eb0c63b764F06832f15B21956bb8979FC9`) vote for it (`contracts/AspRootQuorum.sol:144`). The ASPs are the keys that remain; the set cannot change.
- **Arbitrator**, on each escrow. Some disputes no proof can settle: bank downtime, a reversed payment. A ruling reaches only a DISPUTED order and pays one of its two counterparties. A RELEASE needs an arbitrator registered before the dispute (`contracts/ramp/FiatEscrow.sol:1189`). Rulings execute a day after posting (`contracts/ramp/FiatEscrow.sol:307`). With no arbitrator, a dispute can only time out back to the LP (`contracts/ramp/FiatEscrow.sol:1234`).
- **zkTLS witnesses.** They are the proof. Their signatures are what `verifyPayment` checks, and nothing on-chain can replace them.
- **Movva gateways and the yield recipient, and guardian.** Only gateways mint and redeem (`contracts/movva/MovvaReserve.sol:432`): the gateways are the institutional LPs that settle the off-ramp, and a redemption is the only way the reserve's principal leaves. The reserve is principal-locked (client rule, 21 October 2026): it has no hedge path, and only the yield above max(principal, liabilities at the target) leaves, by `harvestYield`, to the yield recipient alone (`contracts/movva/MovvaReserve.sol:784`). The guardian can only pause minting (`contracts/movva/MovvaReserve.sol:991`).
- **LPs** in the registry. Their tier and credit limit bound what each may have at risk.
- **Keepers: none with on-chain power.** The Pyth keeper posts prices to Pyth, which anyone may do. `split`, `sync` and `finalize` are open to anyone.
- **Bound to code, not keys:** Movva's minter (`RESERVE`, immutable), each pool's `ENTRYPOINT` (immutable), the quorum's `ENTRYPOINT`, ASP set and `THRESHOLD` (immutable), and the escrows the registry accepts.
- **Outside this deployment:** Pyth (its own governance can upgrade it), the Chainlink feeds (their proxies are owned by Chainlink), CreateX, and on mainnet Tether's USDT, which can freeze an escrow. These are trusted as they are and not inventoried here.

### Per contract

#### Privacy Pools Entrypoint (proxy)

`0xe5e3442940D997De3F8584aD0687C925C7178c3f` - `ERC1967Proxy` running `Entrypoint`, `protocol/contracts/src/contracts/Entrypoint.sol`. Privacy Pools' Entrypoint (upstream 0xbow, UUPS behind an ERC1967Proxy): deposits into and relays withdrawals from every pool, and holds the ASP root. **Holds funds.**

- DEFAULT_ADMIN_ROLE (admin OWNER_ROLE): **nobody**
- OWNER_ROLE (admin OWNER_ROLE): `0x2247f974Be28177E1ca7E1DE6D4eaeE410a96e38`
- ASP_POSTMAN (admin OWNER_ROLE): `0x547a0BcDcB8104396bA1c3D2EA7C6A14684e8F96`
- EIP-1967: implementation `0x3EA6De4f683f5B02D7C68339d36C2D3fB8c2F6c3`, admin `empty`, beacon `empty`

- **OWNER_ROLE** can upgrade the Entrypoint's code; register and remove pools; change a pool's minimum deposit, vetting fee and relay-fee cap; wind a pool down; withdraw every fee the Entrypoint holds, to any address; grant and revoke every role, OWNER_ROLE included. It cannot move pooled notes without an upgrade: a withdrawal needs the note's zero-knowledge proof. With an upgrade it can: the Entrypoint's code relays every withdrawal and holds depositors' ERC-20 approvals, so an upgrade is the one path from this role to users' money. (`node_modules/@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol:92`, `protocol/contracts/src/contracts/Entrypoint.sol:183`, `protocol/contracts/src/contracts/Entrypoint.sol:220`, `protocol/contracts/src/contracts/Entrypoint.sol:239`, `protocol/contracts/src/contracts/Entrypoint.sol:256`, `protocol/contracts/src/contracts/Entrypoint.sol:264`, …)
- **ASP_POSTMAN** can publish the association-set root. A private withdrawal must prove membership in the latest root, so the postman decides which deposits may withdraw privately. It cannot move funds, or stop a depositor leaving publicly: ragequit returns a deposit to its original depositor with no root at all. (`protocol/contracts/src/contracts/Entrypoint.sol:93`)
- **DEFAULT_ADMIN_ROLE** can call nothing: no Entrypoint function checks it, and it administers no role (every role's admin is OWNER_ROLE). Listed because AccessControl defines it. It cannot be held by anyone OWNER_ROLE did not grant it to. `initialize` grants it to nobody.

<details><summary>15 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `receive()` | only the Entrypoint (immutable) | - | Accept ETH only from the registered native pool (relayed withdrawals). | not probed (plain ETH transfer) | `protocol/contracts/src/contracts/Entrypoint.sol:298` |
| `deposit(address,uint256,uint256)` | anyone | - | Make an ERC20 deposit into the Privacy Pool <sub>(NatSpec)</sub> | open | `protocol/contracts/src/contracts/Entrypoint.sol:111` |
| `deposit(uint256)` | anyone | - | Make a native asset deposit into the Privacy Pool <sub>(NatSpec)</sub> | open | `protocol/contracts/src/contracts/Entrypoint.sol:111` |
| `grantRole(bytes32,address)` | the role's admin role (OWNER_ROLE, for every role here) (key) | instant | Grant a role. OWNER_ROLE is the admin of OWNER_ROLE, ASP_POSTMAN and DEFAULT_ADMIN_ROLE. | `0x2247…6e38` OWNER_ROLE | `node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol:143` |
| `initialize(address,address)` | nobody: the initializer has run (on the implementation: disabled) | - | Initializes the contract state <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:69` |
| `registerPool(address,address,uint256,uint256,uint256)` | an OWNER_ROLE holder (key) | instant | Register a Privacy Pool in the registry <sub>(NatSpec)</sub> | `0x2247…6e38` OWNER_ROLE | `protocol/contracts/src/contracts/Entrypoint.sol:183` |
| `relay(…)` | anyone carrying a proof the contract's verifier accepts | - | Process a withdrawal <sub>(NatSpec)</sub> | open | `protocol/contracts/src/contracts/Entrypoint.sol:133` |
| `removePool(address)` | an OWNER_ROLE holder (key) | instant | Remove a Privacy Pool from the registry <sub>(NatSpec)</sub> | `0x2247…6e38` OWNER_ROLE | `protocol/contracts/src/contracts/Entrypoint.sol:220` |
| `renounceRole(bytes32,address)` | only for the caller's own role | instant | Give up a role the caller holds (it must name itself). | **nobody** (every probed caller refused) | `node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol:178` |
| `revokeRole(bytes32,address)` | the role's admin role (OWNER_ROLE, for every role here) (key) | instant | Revoke a role from an account. | `0x2247…6e38` OWNER_ROLE | `node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol:158` |
| `updatePoolConfiguration(address,uint256,uint256,uint256)` | an OWNER_ROLE holder (key) | instant | Updates the configuration of a specific pool <sub>(NatSpec)</sub> | `0x2247…6e38` OWNER_ROLE | `protocol/contracts/src/contracts/Entrypoint.sol:239` |
| `updateRoot(uint256,string)` | an ASP_POSTMAN holder (key) | instant | Push a new root to the association root set <sub>(NatSpec)</sub> | `0x547a…8F96` ASP_POSTMAN | `protocol/contracts/src/contracts/Entrypoint.sol:93` |
| `upgradeToAndCall(address,bytes)` | an OWNER_ROLE holder (key) | instant | Replace the Entrypoint's code (UUPS; `_authorizeUpgrade` is onlyRole(OWNER_ROLE)). | `0x2247…6e38` OWNER_ROLE | `node_modules/@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol:92` |
| `windDownPool(address)` | an OWNER_ROLE holder (key) | instant | Irreversebly halt deposits from a Privacy Pool <sub>(NatSpec)</sub> | inconclusive (bare revert): `0x2247…6e38` OWNER_ROLE | `protocol/contracts/src/contracts/Entrypoint.sol:256` |
| `withdrawFees(address,address)` | an OWNER_ROLE holder (key) | instant | Withdraw fees from the Entrypoint <sub>(NatSpec)</sub> | inconclusive (bare revert): `0x2247…6e38` OWNER_ROLE | `protocol/contracts/src/contracts/Entrypoint.sol:264` |

</details>

#### Entrypoint implementation

`0x3EA6De4f683f5B02D7C68339d36C2D3fB8c2F6c3` - `Entrypoint`, `protocol/contracts/src/contracts/Entrypoint.sol`. The Entrypoint's implementation. Its own storage is never initialized (the constructor disables initializers), so no role exists in it, and `upgradeToAndCall` refuses a direct call (onlyProxy). It is code the proxy runs, not a second Entrypoint.

- EIP-1967 slots: empty (not a proxy)
- initializers disabled

<details><summary>15 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `receive()` | only the Entrypoint (immutable) | - | Accept ETH only from the registered native pool (relayed withdrawals). | not probed (plain ETH transfer) | `protocol/contracts/src/contracts/Entrypoint.sol:298` |
| `deposit(address,uint256,uint256)` | anyone | - | Make an ERC20 deposit into the Privacy Pool <sub>(NatSpec)</sub> | open | `protocol/contracts/src/contracts/Entrypoint.sol:111` |
| `deposit(uint256)` | anyone | - | Make a native asset deposit into the Privacy Pool <sub>(NatSpec)</sub> | open | `protocol/contracts/src/contracts/Entrypoint.sol:111` |
| `grantRole(bytes32,address)` | the role's admin role (OWNER_ROLE, for every role here) (key) | instant | Grant a role. OWNER_ROLE is the admin of OWNER_ROLE, ASP_POSTMAN and DEFAULT_ADMIN_ROLE. | **nobody** (every probed caller refused) | `node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol:143` |
| `initialize(address,address)` | nobody: the initializer has run (on the implementation: disabled) | - | Initializes the contract state <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:69` |
| `registerPool(address,address,uint256,uint256,uint256)` | an OWNER_ROLE holder (key) | instant | Register a Privacy Pool in the registry <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:183` |
| `relay(…)` | anyone carrying a proof the contract's verifier accepts | - | Process a withdrawal <sub>(NatSpec)</sub> | open | `protocol/contracts/src/contracts/Entrypoint.sol:133` |
| `removePool(address)` | an OWNER_ROLE holder (key) | instant | Remove a Privacy Pool from the registry <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:220` |
| `renounceRole(bytes32,address)` | only for the caller's own role | instant | Give up a role the caller holds (it must name itself). | **nobody** (every probed caller refused) | `node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol:178` |
| `revokeRole(bytes32,address)` | the role's admin role (OWNER_ROLE, for every role here) (key) | instant | Revoke a role from an account. | **nobody** (every probed caller refused) | `node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol:158` |
| `updatePoolConfiguration(address,uint256,uint256,uint256)` | an OWNER_ROLE holder (key) | instant | Updates the configuration of a specific pool <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:239` |
| `updateRoot(uint256,string)` | an ASP_POSTMAN holder (key) | instant | Push a new root to the association root set <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:93` |
| `upgradeToAndCall(address,bytes)` | an OWNER_ROLE holder (key) | instant | Replace the Entrypoint's code (UUPS; `_authorizeUpgrade` is onlyRole(OWNER_ROLE)). | **nobody** (every probed caller refused) | `node_modules/@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol:92` |
| `windDownPool(address)` | an OWNER_ROLE holder (key) | instant | Irreversebly halt deposits from a Privacy Pool <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:256` |
| `withdrawFees(address,address)` | an OWNER_ROLE holder (key) | instant | Withdraw fees from the Entrypoint <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:264` |

</details>

#### Withdrawal Groth16 verifier

`0xDCD3cA51E0C69Bf516eE485E4c1b543E0F1028C6` - `WithdrawalVerifier`, `protocol/contracts/src/contracts/verifiers/WithdrawalVerifier.sol`. Groth16 verifier for withdrawal proofs: pure code, no state.

- EIP-1967 slots: empty (not a proxy)

No state-changing functions.

#### Ragequit (commitment) Groth16 verifier

`0x4F52A6Eac236725ee7d4bCDd247b89c1f496Fd68` - `CommitmentVerifier`, `protocol/contracts/src/contracts/verifiers/CommitmentVerifier.sol`. Groth16 verifier for ragequit (commitment) proofs: pure code, no state.

- EIP-1967 slots: empty (not a proxy)

No state-changing functions.

#### ETH Privacy Pool (upstream's; unused by the product)

`0x43697fFB82471b2becA56135a9A1FBd228d34703` - `PrivacyPoolSimple`, `protocol/contracts/src/contracts/implementations/PrivacyPoolSimple.sol`. A Privacy Pool for native ETH (upstream 0xbow). No owner; bound to one Entrypoint and one asset at construction. **Holds funds.**

- ENTRYPOINT (immutable): `0xe5e3442940D997De3F8584aD0687C925C7178c3f`
- dead = `true` (wound down: no new deposits)
- EIP-1967 slots: empty (not a proxy)

- **ENTRYPOINT** can deposit on a depositor's behalf, and wind the pool down. It cannot withdraw: that needs a note's proof, or its original depositor for ragequit. (`protocol/contracts/src/contracts/PrivacyPool.sol:82`, `protocol/contracts/src/contracts/PrivacyPool.sol:157`)

<details><summary>4 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `deposit(address,uint256,uint256)` | only the Entrypoint (immutable) | - | Deposit funds into the Privacy Pool <sub>(NatSpec)</sub> | `0xe5e3…8c3f` ENTRYPOINT | `protocol/contracts/src/contracts/PrivacyPool.sol:82` |
| `ragequit((uint256[2],uint256[2][2],uint256[2],uint256[4]))` | a party to that offer, order, sale, note or reward | - | Publicly withdraw funds to original depositor without exposing secrets <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `protocol/contracts/src/contracts/PrivacyPool.sol:132` |
| `windDown()` | only the Entrypoint (immutable) | - | Irreversibly suspends deposits <sub>(NatSpec)</sub> | `0xe5e3…8c3f` ENTRYPOINT | `protocol/contracts/src/contracts/PrivacyPool.sol:157` |
| `withdraw(…)` | anyone carrying a proof the contract's verifier accepts | - | Privately withdraw funds by spending an existing commitment <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `protocol/contracts/src/contracts/PrivacyPool.sol:110` |

</details>

#### PoseidonT3 library

`0x8ffdA7Ed8B4aD98C2C34f54B76821711F4a6f2C5` - `PoseidonT3`, `node_modules/poseidon-solidity/PoseidonT3.sol`. Poseidon hash library (2 inputs): pure code, no state. Linked into the pools.

- EIP-1967 slots: empty (not a proxy)

No state-changing functions.

#### PoseidonT4 library

`0xe393dd7287Db9982e6f845824854Baf8b8e823AF` - `PoseidonT4`, `node_modules/poseidon-solidity/PoseidonT4.sol`. Poseidon hash library (3 inputs): pure code, no state. Linked into the pools.

- EIP-1967 slots: empty (not a proxy)

No state-changing functions.

#### Stand-in USDT (OwnedTetherLike)

`0x1931A0c8de3D7bFa68a1106dF269983304eb4960` - `OwnedTetherLike`, `contracts/test/utils/OwnedTetherLike.sol`. Sepolia stand-in for USDT from v5 on (contracts/test/utils/OwnedTetherLike.sol): Tether's surface, 6 decimals, with the blacklist, pause and fee its owner's - the governor Safe - as Tether's are on mainnet (v3.1 N-15). NOT a mainnet contract.

- owner: `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`
- paused = `false` (transfers refused)
- EIP-1967 slots: empty (not a proxy)

- **owner** can blacklist, pause and set the fee, as Tether can on mainnet. It cannot mint for itself alone (minting is open), or move anyone's balance. (`contracts/test/utils/OwnedTetherLike.sol:76`, `contracts/test/utils/OwnedTetherLike.sol:80`, `contracts/test/utils/OwnedTetherLike.sol:84`, `contracts/test/utils/OwnedTetherLike.sol:70`, `contracts/test/utils/OwnedTetherLike.sol:41`)

<details><summary>9 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `addBlackList(address)` | the contract's owner (key) | - | Blacklist an address. | `0x956E…dCa1` owner | `contracts/test/utils/OwnedTetherLike.sol:76` |
| `approve(address,uint256)` | anyone | - | Set an allowance over the caller's own balance. | open | `contracts/test/utils/OwnedTetherLike.sol:64` |
| `mint(address,uint256)` | anyone | - | Create tokens for anyone: the testers' faucet. | open | `contracts/test/utils/OwnedTetherLike.sol:46` |
| `removeBlackList(address)` | the contract's owner (key) | - | Unblacklist an address. | `0x956E…dCa1` owner | `contracts/test/utils/OwnedTetherLike.sol:80` |
| `setParams(uint256,uint256)` | the contract's owner (key) | - | Set the transfer fee (< 20 bps, < 50 tokens), paid to the owner. | `0x956E…dCa1` owner | `contracts/test/utils/OwnedTetherLike.sol:70` |
| `setPaused(bool)` | the contract's owner (key) | - | Pause or unpause transfers. | `0x956E…dCa1` owner | `contracts/test/utils/OwnedTetherLike.sol:84` |
| `transfer(address,uint256)` | anyone | - | Move the caller's own balance. | open | `contracts/test/utils/OwnedTetherLike.sol:52` |
| `transferFrom(address,address,uint256)` | anyone | - | Move a balance within an allowance its owner gave the caller. | open | `contracts/test/utils/OwnedTetherLike.sol:57` |
| `transferOwnership(address)` | the contract's owner (key) | - | Hand the token's switches to another owner. | `0x956E…dCa1` owner | `contracts/test/utils/OwnedTetherLike.sol:41` |

</details>

#### MovvaReserve

`0x0E6b613E8F52036A51CdAa9A309419782d35848c` - `MovvaReserve`, `contracts/movva/MovvaReserve.sol`. Holds the USDT backing Movva; mints and redeems Movva for gateways at the Pyth FX rate. Principal-locked (client rule, 21 October 2026): its USDT leaves only by redemption (gateways: the off-ramp's LPs) and, above max(principal, liabilities at the target ratio), by harvestYield to the fixed yield recipient. No hedge path, no sweep, no savings path (no sMovva, no `distribute`). **Holds funds.**

- governor `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`; setup complete; delay 48 h; 0 pending change(s)
- guardian: `0xd67DDA7D07CAa45d6f8e7C1dD0a170585e6B086c`
- gateway: `0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C`, `0xf491FA29debC0D12d8F7c57B17995C2346F025AD`
- gateway council: none
- yield recipient (payee): `0x622F626F912AD25d36D9B8F48907Ac941F755ACb`
- fee recipient (payee): `0x37c5232936F71533f1ee3Fc104A9Baf0DEdFB640`
- yield vault: none
- mintPaused = `false` (gateways cannot mint)
- vaultDepositsPaused = `false` (no USDT goes into the yield vault)
- supplyCap = `1000000000000000000000000` (most Movva that may exist (1e18 = R$ 1,00))
- principalUsdt = `0` (the cost basis (USDT in by mint and recapitalize, less out by redeem): no harvest goes below it)
- EIP-1967 slots: empty (not a proxy)

- **governor** can add and remove gateways; replace the guardian, the fee recipient and (always after the delay) the yield recipient; change fees (hard caps 1% mint, 1% redeem), collateral ratios (never under 100%), the supply cap, the oracle legs and their max ages, and the yield vault; pull USDT back from the vault into the reserve; pause and resume vault deposits and minting. After setup, every change that adds risk waits GOVERNANCE_DELAY; removing, lowering and pausing are instant. It cannot mint or burn Movva itself, send the reserve's USDT anywhere (principal-locked: pullFromVault only brings it back into the reserve; only redeem and harvestYield pay out), pause redemptions, or pass the hard fee caps. (`contracts/movva/MovvaReserve.sol:838`, `contracts/movva/MovvaReserve.sol:847`, `contracts/movva/MovvaReserve.sol:856`, `contracts/movva/MovvaReserve.sol:862`, `contracts/movva/MovvaReserve.sol:871`, `contracts/movva/MovvaReserve.sol:912`, …)
- **guardian** can pause minting; bring USDT back from the yield vault into the reserve; pause deposits into the vault. At once, and after finalization too (N-03, N-28). It cannot resume minting or vault deposits (governor only), send USDT anywhere but into the reserve, or do anything else. (`contracts/movva/MovvaReserve.sol:991`, `contracts/movva/MovvaReserve.sol:960`, `contracts/movva/MovvaReserve.sol:983`)
- **gateway council** can add a gateway after GOVERNANCE_DELAY, remove one at once, hand itself on or renounce (v3.1 N-02). None unless the deployment names one. It cannot mint, redeem, or touch any other setting. (`contracts/movva/MovvaReserve.sol:885`, `contracts/movva/MovvaReserve.sol:895`, `contracts/movva/MovvaReserve.sol:878`)
- **gateway** can mint Movva for USDT it pays in, and redeem Movva for USDT, at the oracle rate less fees, within the supply cap and the mint collateral floor. The gateways are the institutional LPs that settle the off-ramp: a redemption is the only way the principal leaves. It cannot mint without paying in. A wrong rate inside the oracle bounds is the residual risk the contract names: it is why only contracted gateways mint and redeem. (`contracts/movva/MovvaReserve.sol:655`, `contracts/movva/MovvaReserve.sol:708`, `contracts/movva/MovvaReserve.sol:763`, `contracts/movva/MovvaReserve.sol:770`)

<details><summary>33 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `acceptGovernor()` | a party to that offer, order, sale, note or reward | - | The proposed governor takes over. Every change the previous one queued is void. <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/common/DelayedGovernance.sol:198` |
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:239` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:172` |
| `councilSetGateway(address,bool)` | the reserve's gateway council (optional; outlives finalization) (key) | - | Council: add a proposed gateway once its delay has passed (and within EXECUTION_WINDOW of that), or remove one - or a proposal - at once. <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `contracts/movva/MovvaReserve.sol:895` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:254` |
| `exitRedeem(uint256,address,uint256)` | anyone | - | The keyless exit: any holder redeems their own Movva, once the gateways have gone quiet or the rate has been unreadable for long enough. See "The keyless exit" in the header. <sub>(NatSpec)</sub> | open | `contracts/movva/MovvaReserve.sol:726` |
| `gatewayHeartbeat()` | a gateway (key) | - | A gateway says it is operating, which keeps the keyless exit's gateway clock from running out. <sub>(NatSpec)</sub> | `0x3ce8…3f5C` gateway<br>`0xf491…25AD` gateway | `contracts/movva/MovvaReserve.sol:763` |
| `harvestYield()` | anyone | - | Anyone: pay `harvestableYield()` to `yieldRecipient`, pulling from the yield vault as needed. <sub>(NatSpec)</sub> | open | `contracts/movva/MovvaReserve.sol:784` |
| `mint(uint256,address,uint256)` | a gateway (key) | - | Gateway only: deposit USDT, receive Movva worth it at the oracle rate, less the mint fee. <sub>(NatSpec)</sub> | `0x3ce8…3f5C` gateway<br>`0xf491…25AD` gateway | `contracts/movva/MovvaReserve.sol:655` |
| `ossify()` | the governor (key) | instant | One-way: no risk-increasing change can ever run again; the instant, risk-reducing ones stay with the governor. See "Ossify" above. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:180` |
| `pauseMint()` | the guardian or the governor (key) | instant | Guardian or governor: stop minting. There is no pause for redemptions; see "Who can stop a redemption" in the header for what can stop one. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor<br>`0xd67D…086c` guardian | `contracts/movva/MovvaReserve.sol:991` |
| `pokeRate()` | anyone | - | Anyone: record whether the rate is readable now. Readable, it becomes `lastGoodRate`; unreadable, it starts the keyless exit's `ORACLE_EXIT_DELAY` clock if that is not running. <sub>(NatSpec)</sub> | open | `contracts/movva/MovvaReserve.sol:751` |
| `proposeGateway(address)` | the reserve's gateway council (optional; outlives finalization) (key) | - | Council: propose a gateway, addable after the governance delay. <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `contracts/movva/MovvaReserve.sol:885` |
| `pullFromVault(uint256)` | the guardian or the governor (key) | instant | Instant, guardian or governor: bring `usdt` back from the vault into the reserve, and stop depositing into it until the governor calls `setVaultDepositsPaused(false)`. `type(uint256).max` redeems e... <sub>(NatSpec)</sub> | `0x956E…dCa1` governor<br>`0xd67D…086c` guardian | `contracts/movva/MovvaReserve.sol:960` |
| `recapitalize(uint256)` | anyone | - | Anyone: add USDT without minting. It becomes principal. <sub>(NatSpec)</sub> | open | `contracts/movva/MovvaReserve.sol:822` |
| `redeem(uint256,address,uint256)` | a gateway (key) | - | Gateway only: burn Movva, receive USDT worth min(1, collateral ratio) of it, less the redeem fee. <sub>(NatSpec)</sub> | `0x3ce8…3f5C` gateway<br>`0xf491…25AD` gateway | `contracts/movva/MovvaReserve.sol:708` |
| `renounceGateway()` | a gateway (key) | - | A gateway removes itself, at once: what an operator does with a leaked key. <sub>(NatSpec)</sub> | `0x3ce8…3f5C` gateway<br>`0xf491…25AD` gateway | `contracts/movva/MovvaReserve.sol:770` |
| `renounceGovernor()` | the governor (key) | instant | Give governance up for good: to 0x...dEaD, at once, and every queued change void. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:204` |
| `resumeMint()` | the governor (key) | instant | Resume minting. | `0x956E…dCa1` governor | `contracts/movva/MovvaReserve.sol:997` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:227` |
| `setCollateralRatios(uint16,uint16)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | LOWERING a ratio is delayed (it lets value out at less backing); raising is instant. Neither may be below 100%, and the mint floor may not exceed the target. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/movva/MovvaReserve.sol:912` |
| `setFeeRecipient(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Delayed: this address is paid every fee. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/movva/MovvaReserve.sol:862` |
| `setFees(uint16,uint16)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Raising either fee is delayed; lowering is instant. Hard caps apply either way, and the two together never fall below `MIN_ROUND_TRIP_FEE_BPS`. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/movva/MovvaReserve.sol:871` |
| `setGateway(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Adding a gateway waits out the delay; removing one is instant. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/movva/MovvaReserve.sol:838` |
| `setGatewayCouncil(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | The council, or the governor through the delay, may name a new council; the council may hand itself on or renounce (zero) at once, and the governor may remove it at once. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/movva/MovvaReserve.sol:878` |
| `setGuardian(address)` | the governor (key) | instant | Instant. The guardian can only pause minting, pull USDT from the vault back into the reserve, and pause deposits into the vault. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/movva/MovvaReserve.sol:847` |
| `setOracle(address,address,uint64,uint64)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Repointing either leg or lengthening a max age is delayed; only tightening an age is instant, and never below `MIN_USDT_USD_MAX_AGE` / `MIN_FX_MAX_AGE` (SRM1-20). The rate prices every mint and red... <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/movva/MovvaReserve.sol:931` |
| `setSupplyCap(uint256)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Raising the supply cap is delayed; lowering it is instant. A cap of zero stops minting. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/movva/MovvaReserve.sol:921` |
| `setVaultDepositsPaused(bool)` | the guardian or the governor (key) | instant | Instant either way: the vault was chosen through the delay, and exits are unaffected. The guardian may pause; only the governor may resume. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/movva/MovvaReserve.sol:983` |
| `setYieldRecipient(address)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Always delayed, in either direction: this address is the only place yield is paid, and there is no "safer" value to move it to at once (client rule, 21 October 2026). <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/movva/MovvaReserve.sol:856` |
| `setYieldVault(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Choose the yield vault. A new vault is delayed; removing it (zero) is instant. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/movva/MovvaReserve.sol:944` |
| `sweepSunset()` | anyone | - | After SUNSET_DELAY with no Movva in circulation, pay everything the reserve can pay now to `yieldRecipient` (N-25). Anyone may call; a mint at any point stops the clock for good. <sub>(NatSpec)</sub> | open | `contracts/movva/MovvaReserve.sol:1111` |
| `transferGovernor(address)` | the governor (key) | instant | During setup, hand over at once. After it, propose `to` as the next governor; it takes over when it calls `acceptGovernor`, and a later proposal replaces this one (I-36). <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:190` |

</details>

#### Movva (token)

`0xa849B93B5ec04bb1b979faE8B82F8Fb66663AAD7` - `Movva`, `contracts/movva/Movva.sol`. The Movva ERC-20 (R$ 1,00). Its only minter is the MovvaReserve that deployed it.

- minter (RESERVE, immutable): `0x0E6b613E8F52036A51CdAa9A309419782d35848c`
- EIP-1967 slots: empty (not a proxy)

- **RESERVE** can mint to anyone, and burn its own balance. It cannot burn anyone else's Movva. No owner, no pause, no blacklist, no upgrade. (`contracts/movva/Movva.sol:49`, `contracts/movva/Movva.sol:55`)

<details><summary>6 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `approve(address,uint256)` | anyone | - | Set an allowance over the caller's own balance. | open | `node_modules/@openzeppelin/contracts/token/ERC20/ERC20.sol:127` |
| `burn(uint256)` | only the MovvaReserve (immutable) | - | Reserve only: destroy `amount` of the reserve's own Movva. <sub>(NatSpec)</sub> | `0x0E6b…848c` minter | `contracts/movva/Movva.sol:55` |
| `mint(address,uint256)` | only the MovvaReserve (immutable) | - | Reserve only: create `amount` Movva for `to`. <sub>(NatSpec)</sub> | `0x0E6b…848c` minter | `contracts/movva/Movva.sol:49` |
| `permit(…)` | anyone | - | EIP-2612: set an allowance with the owner's signature. | open | `node_modules/@openzeppelin/contracts/token/ERC20/extensions/ERC20Permit.sol:44` |
| `transfer(address,uint256)` | anyone | - | Move the caller's own balance. | open | `node_modules/@openzeppelin/contracts/token/ERC20/ERC20.sol:104` |
| `transferFrom(address,address,uint256)` | anyone | - | Move a balance within an allowance its owner gave the caller. | open | `node_modules/@openzeppelin/contracts/token/ERC20/ERC20.sol:149` |

</details>

#### Movva FX leg (PythFxOracle)

`0x9E87487Af7Af6ab3959CB790dE52A52fa5e32047` - `PythFxOracle`, `contracts/ramp/PythFxOracle.sol`. The BRL/USD FX leg over Pyth's FX.USD/BRL, with a band reading for the hours the FX market is closed.

- governor `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`; setup complete; delay 48 h; 0 pending change(s)
- EIP-1967 slots: empty (not a proxy)

- **governor** can repoint the Pyth price id, and loosen or tighten the max ages and the confidence bound (loosening waits GOVERNANCE_DELAY, tightening is instant). It cannot post a price (Pyth prices are posted permissionlessly on Pyth) or change which Pyth contract it reads: PYTH is immutable. (`contracts/ramp/PythFxOracle.sol:145`, `contracts/ramp/PythFxOracle.sol:153`, `contracts/common/DelayedGovernance.sol:190`)

<details><summary>10 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `acceptGovernor()` | a party to that offer, order, sale, note or reward | - | The proposed governor takes over. Every change the previous one queued is void. <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/common/DelayedGovernance.sol:198` |
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:239` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:172` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:254` |
| `ossify()` | the governor (key) | instant | One-way: no risk-increasing change can ever run again; the instant, risk-reducing ones stay with the governor. See "Ossify" above. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:180` |
| `renounceGovernor()` | the governor (key) | instant | Give governance up for good: to 0x...dEaD, at once, and every queued change void. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:204` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:227` |
| `setFeed(bytes32)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Repointing the feed waits out the governance delay. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/PythFxOracle.sol:145` |
| `setLimits(uint64,uint64,uint16)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Loosening any limit waits out the governance delay; tightening is instant. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/PythFxOracle.sol:153` |
| `transferGovernor(address)` | the governor (key) | instant | During setup, hand over at once. After it, propose `to` as the next governor; it takes over when it calls `acceptGovernor`, and a later proposal replaces this one (I-36). <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:190` |

</details>

#### Movva band adapter (ScaledFxBandOracle)

`0x78036B4deE6ebAe7aBFCaa355E84ab3C579035F8` - `ScaledFxBandOracle`, `contracts/movva/ScaledFxBandOracle.sol`. Reads an FX leg and re-expresses it in centavos; no governance of its own: SOURCE is immutable.

- EIP-1967 slots: empty (not a proxy)

No state-changing functions.

#### FeeSplitter

`0x37c5232936F71533f1ee3Fc104A9Baf0DEdFB640` - `FeeSplitter`, `contracts/movva/FeeSplitter.sol`. The reserve's fee recipient: splits Movva fee revenue between NodeRewards and Mova's treasury. **Holds funds.**

- governor `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`; setup complete; delay 48 h; 0 pending change(s)
- treasury (payee): `0x622F626F912AD25d36D9B8F48907Ac941F755ACb`
- rewards (payee): `0x8BB79778Bf55ca02803E5bEcCC3e1d5bD1488EE2`
- lpRewardShareBps = `0` (the LPs' share of fee revenue)
- EIP-1967 slots: empty (not a proxy)

- **governor** can change the LPs' share (never above 50%), the treasury and the rewards contract. It cannot take what the splitter holds: `split` pays only the treasury and the rewards contract, and anyone may call it. (`contracts/movva/FeeSplitter.sol:116`, `contracts/movva/FeeSplitter.sol:125`, `contracts/movva/FeeSplitter.sol:135`, `contracts/common/DelayedGovernance.sol:190`)

<details><summary>12 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `acceptGovernor()` | a party to that offer, order, sale, note or reward | - | The proposed governor takes over. Every change the previous one queued is void. <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/common/DelayedGovernance.sol:198` |
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:239` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:172` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:254` |
| `ossify()` | the governor (key) | instant | One-way: no risk-increasing change can ever run again; the instant, risk-reducing ones stay with the governor. See "Ossify" above. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:180` |
| `renounceGovernor()` | the governor (key) | instant | Give governance up for good: to 0x...dEaD, at once, and every queued change void. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:204` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:227` |
| `setLpRewardShare(uint16)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Raising the LPs' share waits out the delay; lowering it is instant. Never above 50%. What has already accrued is split first, at the share it accrued under (L-05): a lowering applies to fees from n... <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/movva/FeeSplitter.sol:116` |
| `setRewards(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | A new rewards contract waits out the delay; removing it (zero) is instant. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/movva/FeeSplitter.sol:135` |
| `setTreasury(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Delayed: this address is paid Mova's revenue. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/movva/FeeSplitter.sol:125` |
| `split()` | anyone | - | Send everything here: the LPs' share to the rewards contract, the rest to the treasury. Anyone may call. <sub>(NatSpec)</sub> | open | `contracts/movva/FeeSplitter.sol:82` |
| `transferGovernor(address)` | the governor (key) | instant | During setup, hand over at once. After it, propose `to` as the next governor; it takes over when it calls `acceptGovernor`, and a later proposal replaces this one (I-36). <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:190` |

</details>

#### NodeRewards

`0x8BB79778Bf55ca02803E5bEcCC3e1d5bD1488EE2` - `NodeRewards`, `contracts/ramp/NodeRewards.sol`. Node-provider rewards: fee revenue shared among INSTITUTIONAL and AFFILIATED LPs by settled BRL volume, epoch by epoch. **Holds funds.**

- governor `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`; setup complete; delay 48 h; 0 pending change(s)
- registry (reports settlements): `0xC2c28C7E0a123816BF5ECE680FC19fBb4a6b8F0a`
- excluded LP: none
- EIP-1967 slots: empty (not a proxy)

- **governor** can bind or unbind the registry, set the reward limits (within MAX_REWARD_BPS_OF_VOLUME), exclude or reinstate an LP, and void an LP's volume while its epoch is in review. It cannot pay anyone: rewards go only to LPs claiming their own shares, and voided shares roll forward instead of going to anyone else. (`contracts/ramp/NodeRewards.sol:460`, `contracts/ramp/NodeRewards.sol:471`, `contracts/ramp/NodeRewards.sol:481`, `contracts/ramp/NodeRewards.sol:493`, `contracts/common/DelayedGovernance.sol:190`)
- **registry** can report settlements, which count as volume. It cannot pay rewards. (`contracts/ramp/NodeRewards.sol:259`)

<details><summary>18 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `acceptGovernor()` | a party to that offer, order, sale, note or reward | - | The proposed governor takes over. Every change the previous one queued is void. <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/common/DelayedGovernance.sol:198` |
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:239` |
| `claim(uint256[],address)` | a party to that offer, order, sale, note or reward | - | Claim the caller's rewards for finalized epochs, paid to `to`. <sub>(NatSpec)</sub> | open | `contracts/ramp/NodeRewards.sol:349` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:172` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:254` |
| `expireEpoch(uint256)` | anyone | - | After CLAIM_EXPIRY, what nobody claimed from epoch `e` - rounding dust included - is forfeited (I-52). Anyone may call it, once per epoch. <sub>(NatSpec)</sub> | open | `contracts/ramp/NodeRewards.sol:381` |
| `finalize(uint256)` | anyone | - | Finalize up to `maxEpochs` epochs whose review has ended, oldest first. Anyone may call it. <sub>(NatSpec)</sub> | open | `contracts/ramp/NodeRewards.sol:302` |
| `onSettled(address,uint256,uint8)` | only the bound LPRegistry | - | Count a settlement's volume for the LP. | `0xC2c2…8F0a` registry | `contracts/ramp/NodeRewards.sol:259` |
| `ossify()` | the governor (key) | instant | One-way: no risk-increasing change can ever run again; the instant, risk-reducing ones stay with the governor. See "Ossify" above. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:180` |
| `renounceGovernor()` | the governor (key) | instant | Give governance up for good: to 0x...dEaD, at once, and every queued change void. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:204` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:227` |
| `setExcluded(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Excluding an LP is instant; reinstating one waits out the delay. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/NodeRewards.sol:481` |
| `setRegistry(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Bind the registry whose settlement reports count; zero unbinds. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/NodeRewards.sol:460` |
| `setRewardLimits(uint16,uint256,uint256)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Raising the rate or the per-LP cap, or lowering the minimum, is delayed; the opposite of each is instant. The rate can never pass MAX_REWARD_BPS_OF_VOLUME. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/NodeRewards.sol:471` |
| `sweepForfeited()` | anyone | - | Pay everything forfeited to SINK (I-52). Anyone may call it. <sub>(NatSpec)</sub> | open | `contracts/ramp/NodeRewards.sol:392` |
| `sync()` | anyone | - | Book reward tokens that arrived since the last sync into the current epoch. Anyone may call it; FeeSplitter calls it after every transfer here. <sub>(NatSpec)</sub> | open | `contracts/ramp/NodeRewards.sol:279` |
| `transferGovernor(address)` | the governor (key) | instant | During setup, hand over at once. After it, propose `to` as the next governor; it takes over when it calls `acceptGovernor`, and a later proposal replaces this one (I-36). <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:190` |
| `voidVolume(uint256,address)` | the governor (key) | instant | Instant, governor only: void `lp`'s volume for an epoch still in review, current or ended. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/NodeRewards.sol:493` |

</details>

#### Movva Privacy Pool

`0xfe04F27A763e6a0CFcC2877a08e738e5068cbBB2` - `PrivacyPoolComplex`, `protocol/contracts/src/contracts/implementations/PrivacyPoolComplex.sol`. A Privacy Pool for an ERC-20 (Movva) (upstream 0xbow). No owner; bound to one Entrypoint and one asset at construction. **Holds funds.**

- ENTRYPOINT (immutable): `0xe5e3442940D997De3F8584aD0687C925C7178c3f`
- dead = `false` (wound down: no new deposits)
- EIP-1967 slots: empty (not a proxy)

- **ENTRYPOINT** can deposit on a depositor's behalf, and wind the pool down. It cannot withdraw: that needs a note's proof, or its original depositor for ragequit. (`protocol/contracts/src/contracts/PrivacyPool.sol:82`, `protocol/contracts/src/contracts/PrivacyPool.sol:157`)

<details><summary>4 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `deposit(address,uint256,uint256)` | only the Entrypoint (immutable) | - | Deposit funds into the Privacy Pool <sub>(NatSpec)</sub> | `0xe5e3…8c3f` ENTRYPOINT | `protocol/contracts/src/contracts/PrivacyPool.sol:82` |
| `ragequit((uint256[2],uint256[2][2],uint256[2],uint256[4]))` | a party to that offer, order, sale, note or reward | - | Publicly withdraw funds to original depositor without exposing secrets <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `protocol/contracts/src/contracts/PrivacyPool.sol:132` |
| `windDown()` | only the Entrypoint (immutable) | - | Irreversibly suspends deposits <sub>(NatSpec)</sub> | `0xe5e3…8c3f` ENTRYPOINT | `protocol/contracts/src/contracts/PrivacyPool.sol:157` |
| `withdraw(…)` | anyone carrying a proof the contract's verifier accepts | - | Privately withdraw funds by spending an existing commitment <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `protocol/contracts/src/contracts/PrivacyPool.sol:110` |

</details>

#### Entrypoint owner (TimelockController, 7 days)

`0x2247f974Be28177E1ca7E1DE6D4eaeE410a96e38` - `EntrypointTimelock`, `contracts/governance/EntrypointTimelock.sol`. OpenZeppelin 5.1.0 TimelockController, unchanged (contracts/governance/EntrypointTimelock.sol adds nothing): the Entrypoint's OWNER_ROLE holder (H-02). Every call it makes waits getMinDelay() (7 days) after a proposer schedules it; the Safe is its only proposer and executor, it and an independent Safe cancel (v3.1 N-19; one constructor argument added to OpenZeppelin's), and it administers its own roles.

- proposer: `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`
- canceller: `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`, `0xd67DDA7D07CAa45d6f8e7C1dD0a170585e6B086c`
- executor: `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`
- admin (DEFAULT_ADMIN_ROLE): `0x2247f974Be28177E1ca7E1DE6D4eaeE410a96e38`
- getMinDelay = `604800` (seconds every operation waits between schedule and execute)
- EIP-1967 slots: empty (not a proxy)

- **proposer / canceller / executor (the Safe)** can schedule any call from the timelock - so any Entrypoint OWNER_ROLE action: upgrade, pools, fees, roles - and run it once getMinDelay() (7 days) has passed; cancel any queued operation at once. It cannot run anything sooner than the delay, shorten the delay without waiting it, or add a proposer without a delayed operation. Every scheduled operation is public (CallScheduled) for the whole delay. (`node_modules/@openzeppelin/contracts/governance/TimelockController.sol:266`, `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:291`, `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:358`, `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:385`, `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:334`)
- **DEFAULT_ADMIN_ROLE (the timelock itself)** can grant and revoke the timelock's roles and change its delay - only through its own delayed operations. It cannot act without a proposer scheduling it: nobody else holds the admin role. (`node_modules/@openzeppelin/contracts/access/AccessControl.sol:122`, `node_modules/@openzeppelin/contracts/access/AccessControl.sol:137`, `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:449`)

<details><summary>13 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `receive()` | anyone | - | Accept ETH (it holds none for the rail). | not probed (plain ETH transfer) | `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:155` |
| `cancel(bytes32)` | a holder of the timelock's CANCELLER_ROLE (the Safe) (key) | instant | Drop a queued operation before it runs. | `0x956E…dCa1` proposer, canceller, executor<br>`0xd67D…086c` canceller | `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:334` |
| `execute(address,uint256,bytes,bytes32,bytes32)` | a holder of the timelock's EXECUTOR_ROLE (the Safe; not open) (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a queued call once its delay has passed (calls the Entrypoint as OWNER_ROLE). | `0x956E…dCa1` proposer, canceller, executor | `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:358` |
| `executeBatch(address[],uint256[],bytes[],bytes32,bytes32)` | a holder of the timelock's EXECUTOR_ROLE (the Safe; not open) (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a queued batch once its delay has passed. | `0x956E…dCa1` proposer, canceller, executor | `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:385` |
| `grantRole(bytes32,address)` | only the timelock itself, through an operation that waited its minimum delay | only once a scheduled change has waited GOVERNANCE_DELAY | Grant a timelock role. DEFAULT_ADMIN_ROLE administers every role and only the timelock holds it, so only an operation that waited the delay can. | `0x2247…6e38` admin | `node_modules/@openzeppelin/contracts/access/AccessControl.sol:122` |
| `onERC1155BatchReceived(…)` | anyone | - | ERC-1155 batch receiver hook. | open | `node_modules/@openzeppelin/contracts/token/ERC1155/utils/ERC1155Holder.sol:33` |
| `onERC1155Received(address,address,uint256,uint256,bytes)` | anyone | - | ERC-1155 receiver hook. | open | `node_modules/@openzeppelin/contracts/token/ERC1155/utils/ERC1155Holder.sol:23` |
| `onERC721Received(address,address,uint256,bytes)` | anyone | - | ERC-721 receiver hook: accept a token sent to the timelock. | open | `node_modules/@openzeppelin/contracts/token/ERC721/utils/ERC721Holder.sol:21` |
| `renounceRole(bytes32,address)` | only for the caller's own role | instant | Give up a timelock role the caller holds (it must name itself). | **nobody** (every probed caller refused) | `node_modules/@openzeppelin/contracts/access/AccessControl.sol:157` |
| `revokeRole(bytes32,address)` | only the timelock itself, through an operation that waited its minimum delay | only once a scheduled change has waited GOVERNANCE_DELAY | Revoke a timelock role: an operation of the timelock itself. | `0x2247…6e38` admin | `node_modules/@openzeppelin/contracts/access/AccessControl.sol:137` |
| `schedule(address,uint256,bytes,bytes32,bytes32,uint256)` | a holder of the timelock's PROPOSER_ROLE (the Safe) (key) | instant | Queue one call (target, value, data) to run after at least getMinDelay(). | `0x956E…dCa1` proposer, canceller, executor | `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:266` |
| `scheduleBatch(…)` | a holder of the timelock's PROPOSER_ROLE (the Safe) (key) | instant | Queue a batch of calls to run together after at least getMinDelay(). | `0x956E…dCa1` proposer, canceller, executor | `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:291` |
| `updateDelay(uint256)` | only the timelock itself, through an operation that waited its minimum delay | only once a scheduled change has waited GOVERNANCE_DELAY | Change the minimum delay: only as an operation of the timelock itself, so a shorter delay waits the current one. | `0x2247…6e38` admin | `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:449` |

</details>

#### AspRootQuorum (ASP postman, 2 of 3)

`0x547a0BcDcB8104396bA1c3D2EA7C6A14684e8F96` - `AspRootQuorum`, `contracts/AspRootQuorum.sol`. The Entrypoint's ASP postman as an immutable THRESHOLD-of-ASP_COUNT quorum (contracts/AspRootQuorum.sol): a root reaches the Entrypoint only when THRESHOLD of the fixed ASPs voted for exactly that root and CID. No owner, no setter, no upgrade.

- ASP: `0x6f239a1A5818808E63BB6F35A88B9876a79aa973`, `0xc8510850c5bF41B52399473F234577B2d8Ef0B16`, `0x323574Eb0c63b764F06832f15B21956bb8979FC9`
- ENTRYPOINT (immutable): `0xe5e3442940D997De3F8584aD0687C925C7178c3f`
- THRESHOLD = `2` (distinct ASP votes that post a root)
- ASP_COUNT = `3` (ASPs, fixed at deployment)
- round = `0` (roots posted so far; votes count only in the current round)
- EIP-1967 slots: empty (not a proxy)

- **ASP** can vote for a root and CID in the current round. THRESHOLD distinct votes for the same proposal post it to the Entrypoint at once. It cannot post a root alone (THRESHOLD is a strict majority), vote twice for one proposal, move funds, or change the ASP set or THRESHOLD: nobody can, ever. (`contracts/AspRootQuorum.sol:157`, `contracts/AspRootQuorum.sol:187`)

<details><summary>2 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `unvote(uint256,string)` | one of the ASPs fixed at deployment (key) | instant | Withdraw this ASP's live vote for `root` with `ipfsCID` in the current round - for example after it found a label it no longer approves. It then counts for nothing. <sub>(NatSpec)</sub> | `0xc851…0B16` ASP<br>`0x6f23…a973` ASP<br>`0x3235…9FC9` ASP | `contracts/AspRootQuorum.sol:187` |
| `vote(uint256,string)` | one of the ASPs fixed at deployment (key) | instant | Vote, as one of the fixed ASPs, for posting `root` with `ipfsCID`. The vote that brings the live votes to THRESHOLD posts the root to the Entrypoint in the same transaction. A lapsed vote for the s... <sub>(NatSpec)</sub> | `0xc851…0B16` ASP<br>`0x6f23…a973` ASP<br>`0x3235…9FC9` ASP | `contracts/AspRootQuorum.sol:157` |

</details>

#### RulingLib library (linked by both escrows)

`0xC18B90Ada8896EA302647c1729F1EdA0c9c700Af` - `RulingLib`, `contracts/ramp/RulingLib.sol`. Linked into both escrows (from v6): checks an arbitrator's ruling signature and a taker gate's approval (verify, gateApproval: views over their arguments). No state, no owner; an escrow calls it by DELEGATECALL. Its ABI lists no function: a library's external functions are reached through the escrow.

- EIP-1967 slots: empty (not a proxy)

No state-changing functions.

#### SafeTransferLib library (linked by both escrows)

`0x2741827E1Dc20B892370c4703dD060e344A9C22E` - `SafeTransferLib`, `contracts/ramp/SafeTransferLib.sol`. Linked into both escrows (from v6): token transfers, approvals and exact-amount pulls (safeTransfer, safeApprove, receiveToken), run in the calling escrow's context by DELEGATECALL. No state, no owner; called directly it acts on its own empty balances. Its ABI lists no function.

- EIP-1967 slots: empty (not a proxy)

No state-changing functions.

#### LPRegistry

`0xC2c28C7E0a123816BF5ECE680FC19fBb4a6b8F0a` - `LPRegistry`, `contracts/ramp/LPRegistry.sol`. LP onboarding, network phases, tiers, credit and exposure across every escrow.

- governor `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`; setup complete; delay 48 h; 0 pending change(s)
- escrow: `0xDe2e82559127CBEFB4F19E219190AC15D9Ce1456`, `0xCD95EC2aF9fA84Ab588F4279C86e8e8c4449606d`
- rewards hook: `0x8BB79778Bf55ca02803E5bEcCC3e1d5bD1488EE2`
- LP (tier > NONE): `0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C`, `0xf491FA29debC0D12d8F7c57B17995C2346F025AD`
- phase = `0` (0 = A (governor-admitted institutions only), 1 = B (+ affiliates), 2 = C (+ retail))
- EIP-1967 slots: empty (not a proxy)

- **governor** can accept and drop escrows, open and close network phases, set the rewards hook, and admit, re-tier, suspend or remove LPs with their credit limits. It cannot move funds: the registry holds none. It decides how much an LP may have at risk, and which escrows may reserve it. (`contracts/ramp/LPRegistry.sol:230`, `contracts/ramp/LPRegistry.sol:254`, `contracts/ramp/LPRegistry.sol:267`, `contracts/ramp/LPRegistry.sol:285`, `contracts/ramp/LPRegistry.sol:243`, `contracts/common/DelayedGovernance.sol:190`)
- **escrow** can reserve and release LPs' exposure and record settlements and lost disputes. It cannot release exposure another escrow reserved. (`contracts/ramp/LPRegistry.sol:459`, `contracts/ramp/LPRegistry.sol:477`, `contracts/ramp/LPRegistry.sol:500`, `contracts/ramp/LPRegistry.sol:528`, `contracts/ramp/LPRegistry.sol:542`)

<details><summary>21 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `acceptGovernor()` | a party to that offer, order, sale, note or reward | - | The proposed governor takes over. Every change the previous one queued is void. <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/common/DelayedGovernance.sol:198` |
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:239` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:172` |
| `consumeBankTxId(bytes32)` | only an escrow the registry accepts | - | Spend a bank transaction id on a settlement: true the first time, false ever after, whichever escrow of this registry spent it. Only an escrow (current or retired) may call, or anyone could burn th... <sub>(NatSpec)</sub> | `0xDe2e…1456` escrow<br>`0xCD95…606d` escrow | `contracts/ramp/LPRegistry.sol:542` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:254` |
| `ossify()` | the governor (key) | instant | One-way: no risk-increasing change can ever run again; the instant, risk-reducing ones stay with the governor. See "Ossify" above. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:180` |
| `recordDispute(address)` | only an escrow the registry accepts | - | Called by the escrow when a dispute is ruled against the LP. MUST NOT revert. <sub>(NatSpec)</sub> | `0x21f4…f975` stranger<br>`0xEAB3…BF26` deployer<br>`0xDe2e…1456` escrow<br>`0x956E…dCa1` governor<br>`0xCD95…606d` escrow<br>`0x3ce8…3f5C` LP<br>`0xf491…25AD` LP | `contracts/ramp/LPRegistry.sol:528` |
| `recordSettled(address,uint256)` | only an escrow the registry accepts | - | Record a settlement (ignored when the caller is not an accepted escrow). | `0x21f4…f975` stranger<br>`0xEAB3…BF26` deployer<br>`0x956E…dCa1` governor<br>`0xDe2e…1456` escrow<br>`0xf491…25AD` LP<br>`0x3ce8…3f5C` LP<br>`0xCD95…606d` escrow | `contracts/ramp/LPRegistry.sol:500` |
| `register()` | anyone | - | Permissionless retail onboarding, Phase C only. The cap, not the gate, is the control - once the network has been opened to retail at all. <sub>(NatSpec)</sub> | open | `contracts/ramp/LPRegistry.sol:331` |
| `releaseExposure(address,uint256)` | only an escrow the registry accepts | - | Give back exposure this escrow reserved. MUST NOT revert: it runs on release and refund paths, after money has moved. <sub>(NatSpec)</sub> | `0x21f4…f975` stranger<br>`0xDe2e…1456` escrow<br>`0xf491…25AD` LP<br>`0x956E…dCa1` governor<br>`0xCD95…606d` escrow<br>`0x3ce8…3f5C` LP<br>`0xEAB3…BF26` deployer | `contracts/ramp/LPRegistry.sol:477` |
| `renounceGovernor()` | the governor (key) | instant | Give governance up for good: to 0x...dEaD, at once, and every queued change void. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:204` |
| `reserveExposure(address,uint256)` | only an escrow the registry accepts | - | Take on `brlCents` of exposure for `lp`, or return false if it would exceed the LP's remaining credit. Only a registered escrow may call. <sub>(NatSpec)</sub> | `0xDe2e…1456` escrow<br>`0xCD95…606d` escrow | `contracts/ramp/LPRegistry.sol:459` |
| `revokeAffiliate(address)` | a party to that offer, order, sale, note or reward | - | End an affiliation. The sponsor can always do this, whatever its own tier. <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/LPRegistry.sol:382` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:227` |
| `setEscrow(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Registering an escrow waits out the governance delay; removing one is instant. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/LPRegistry.sol:230` |
| `setPhase(uint8)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Open the next network phase (delayed), or close back to an earlier one (instant). <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/LPRegistry.sol:254` |
| `setRewardsHook(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Point settlement reports at a rewards contract (delayed), or stop them (zero, instant). <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/LPRegistry.sol:267` |
| `setSuccessor(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Name the registry that replaces this one, once (N-23). Delayed after setup: a successor that reverted would stop every settlement, so it is reviewed like any new dependency. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/LPRegistry.sol:243` |
| `setTier(address,uint8,uint256)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Admit, re-tier or remove an LP. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/LPRegistry.sol:285` |
| `sponsorAffiliate(address,uint256)` | an INSTITUTIONAL LP, from Phase B | - | Sponsor an affiliated LP, or change its credit. Phase B onwards; caller must be an active INSTITUTIONAL LP. <sub>(NatSpec)</sub> | open | `contracts/ramp/LPRegistry.sol:348` |
| `transferGovernor(address)` | the governor (key) | instant | During setup, hand over at once. After it, propose `to` as the next governor; it takes over when it calls `acceptGovernor`, and a later proposal replaces this one (I-36). <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:190` |

</details>

#### ReclaimZkTlsVerifier (PIX, boleto, TED)

`0xdB87f0170Ef6bad9805Cd7203e793e9F4dacD74e` - `ReclaimZkTlsVerifier`, `contracts/ramp/ReclaimZkTlsVerifier.sol`. PIX and boleto verifier: Reclaim zkTLS claims of the payer's own bank session, signed by a threshold of witnesses.

- governor `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`; setup complete; delay 48 h; 0 pending change(s)
- witness: `0x05EfF3D8e0ad59Aa8abFd94E0b08402ec0850Fbf`, `0x8771D8B0038061D7872e4c2C69cD63F54380CBAb`, `0x72C1a86B73Ca01Fec5e07160AE14a32849eE5214`
- bank endpoint (providerHash): `0xb54d2a19bba3a502dc449c083cd2579885618e4e0487435aae1673f06baf0c05`, `0xd8d90d629dc91348bf69c3c5148cd5bf1efdc99220a15a6f42d6ad42eeb2bb20`, `0x8259a0510dbf7425215eada80e9a8fcc1bac48d4e24e3cea67b5185b482abf77`, `0xf02c2badc915c0c690ccba5dd00202b6efcc3d49a1c1197db4026f075aaddc1a`
- threshold = `2` (witness signatures needed)
- witnessCount = `3` (witnesses)
- endpointCount = `4` (allowed bank endpoints)
- EIP-1967 slots: empty (not a proxy)

- **governor** can add and remove witnesses, change the threshold, allow and revoke bank endpoints, the rails each may attest and whether its PIX payments must carry the order's txid (adding, allowing, lowering and dropping the txid requirement wait; removing, revoking, raising and requiring are instant). It cannot prove a payment itself, unless it adds itself as witnesses through the delay. (`contracts/ramp/ReclaimZkTlsVerifier.sol:782`, `contracts/ramp/ReclaimZkTlsVerifier.sol:794`, `contracts/ramp/ReclaimZkTlsVerifier.sol:806`, `contracts/ramp/ReclaimZkTlsVerifier.sol:814`, `contracts/ramp/ReclaimZkTlsVerifier.sol:831`, `contracts/ramp/ReclaimZkTlsVerifier.sol:852`, …)
- **witness** can sign Reclaim claims: `threshold` of them prove that a bank session on an allowed endpoint showed the payment. It cannot vouch for an endpoint the governor has not allowed, or a rail the endpoint may not attest.

<details><summary>16 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `acceptGovernor()` | a party to that offer, order, sale, note or reward | - | The proposed governor takes over. Every change the previous one queued is void. <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/common/DelayedGovernance.sol:198` |
| `allowEndpoint(bytes32,string)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Allow a bank endpoint: the template's Reclaim `providerHash` and the URL prefix its `url` must start with. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/ReclaimZkTlsVerifier.sol:806` |
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:239` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:172` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:254` |
| `ossify()` | the governor (key) | instant | One-way: no risk-increasing change can ever run again; the instant, risk-reducing ones stay with the governor. See "Ossify" above. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:180` |
| `renounceGovernor()` | the governor (key) | instant | Give governance up for good: to 0x...dEaD, at once, and every queued change void. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:204` |
| `revokeEndpoint(bytes32)` | the governor (key) | instant | Revoking an endpoint is instant. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/ReclaimZkTlsVerifier.sol:814` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:227` |
| `setEndpointDirection(bytes32,uint8)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Say what an endpoint's page proves: RECEIVED (1), SENT (2), or nothing (0). See `endpointDirection`. Classifying an endpoint, or changing its class, is delayed - it decides which escrow its proofs ... <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/ReclaimZkTlsVerifier.sol:867` |
| `setEndpointOrderTxid(bytes32,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Require, or stop requiring, that an endpoint's non-boleto payments carry the order's txid: the M-03 binding in the header. Set it on every endpoint whose page is a PIX credit to the LP (`pix-receiv... <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/ReclaimZkTlsVerifier.sol:852` |
| `setEndpointRails(bytes32,uint16)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Set which rails an allowlisted endpoint may attest, as a bitmask over Rail. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/ReclaimZkTlsVerifier.sol:831` |
| `setThreshold(uint256)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Lowering the threshold waits out the governance delay; raising it is instant. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/ReclaimZkTlsVerifier.sol:794` |
| `setWitness(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Adding a witness waits out the governance delay; removing one is instant. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/ReclaimZkTlsVerifier.sol:782` |
| `setWitnessEpoch(uint32)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Move to the witnesses' new epoch (I-22). Raising is instant; lowering waits. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/ReclaimZkTlsVerifier.sol:877` |
| `transferGovernor(address)` | the governor (key) | instant | During setup, hand over at once. After it, propose `to` as the next governor; it takes over when it calls `acceptGovernor`, and a later proposal replaces this one (I-36). <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:190` |

</details>

#### FiatEscrow (Movva on-ramp)

`0xDe2e82559127CBEFB4F19E219190AC15D9Ce1456` - `FiatEscrow`, `contracts/ramp/FiatEscrow.sol`. On-ramp escrow: an LP escrows crypto in an offer; a taker locks an order, pays BRL, and the crypto is released on a proof of payment. **Holds funds.**

- governor `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`; setup complete; delay 48 h; 0 pending change(s)
- arbitrator: `0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7`
- allowed verifier: `0xdB87f0170Ef6bad9805Cd7203e793e9F4dacD74e`
- listed asset (enabled): `0xa849B93B5ec04bb1b979faE8B82F8Fb66663AAD7`
- EIP-1967 slots: empty (not a proxy)

- **governor** can list and delist assets and their band oracles, allow and revoke payment verifiers, add and remove arbitrators, set asset caps. After setup, listing, allowing, adding and raising wait GOVERNANCE_DELAY; delisting, revoking, removing and lowering are instant. It cannot move an offer's liquidity or an order's funds, change an asset's decimals once set, or decide a dispute: a ruling needs an arbitrator's signature. Its power over funds is indirect: which verifiers and arbitrators the escrow believes. (`contracts/ramp/FiatEscrow.sol:566`, `contracts/ramp/FiatEscrow.sol:1302`, `contracts/ramp/FiatEscrow.sol:1310`, `contracts/ramp/FiatEscrow.sol:1322`, `contracts/common/DelayedGovernance.sol:190`, `contracts/common/DelayedGovernance.sol:227`, …)
- **arbitrator** can sign a ruling on a DISPUTED order: RELEASE to the taker's named recipient, or REFUND to the LP (its offer; its own address after a taker's dispute). Anyone submits it; it executes only after RULING_DELAY (1 day), re-verified then, and before DISPUTE_TIMEOUT. A RELEASE needs an arbitrator registered no later than the dispute was raised. It cannot reach an order that is not in dispute, an LP's free liquidity, more than the disputed amount, or any payee but the order's two counterparties. (`contracts/ramp/FiatEscrow.sol:1148`)

<details><summary>30 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `receive()` | anyone | - | Accept ETH: meant for ragequit proceeds from a pool. ETH sent here any other way is credited to nobody, and no function can take it out. | not probed (plain ETH transfer) | `contracts/ramp/FiatEscrow.sol:1625` |
| `acceptGovernor()` | a party to that offer, order, sale, note or reward | - | The proposed governor takes over. Every change the previous one queued is void. <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/common/DelayedGovernance.sol:198` |
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:239` |
| `cancelOrder(bytes32)` | a party to that offer, order, sale, note or reward | - | Give up before paying. Returns the liquidity immediately rather than making the LP wait out the window for capital nobody is going to use. <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:935` |
| `closeOffer(bytes32)` | a party to that offer, order, sale, note or reward | - | Close an offer and return its free liquidity to the LP. The LP may always; ANYONE may once the registry gives the LP no credit at all (`capOf` zero: removed, suspended, or an affiliate whose sponso... <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:670` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:172` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:254` |
| `expireDispute(bytes32)` | anyone | - | After the dispute's timeout with no ruling (`disputeDeadline`: DISPUTE_TIMEOUT for an LP's dispute, TAKER_DISPUTE_TIMEOUT for a taker's), anyone returns the order's liquidity to the LP: to its offe... <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:1234` |
| `fundOffer(bytes32,uint256)` | a party to that offer, order, sale, note or reward | - | Add liquidity to the caller's own offer. | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:642` |
| `issueBoleto(bytes32,bytes32)` | a party to that offer, order, sale, note or reward | - | The LP commits to the boleto it registered for this order. <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:758` |
| `lockOrder(bytes32,uint256,uint8,address,uint256)` | anyone | - | Lock liquidity to pay for by PIX or TED, to the offer's key. <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:695` |
| `lockOrderByBoleto(bytes32,uint256,uint8,address,uint256)` | anyone | - | Lock liquidity to pay for by boleto. The LP must then issue one: see issueBoleto. <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:711` |
| `lockOrderGated(…)` | anyone | - | Lock an order on an offer that has a taker gate (H-04), with the gate's approval. <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:727` |
| `ossify()` | the governor (key) | instant | One-way: no risk-increasing change can ever run again; the instant, risk-reducing ones stay with the governor. See "Ossify" above. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:180` |
| `postOffer(…)` | an LP the registry lets quote | - | Post an offer and escrow its liquidity (the registry must let the LP quote it). | open | `contracts/ramp/FiatEscrow.sol:583` |
| `raiseDispute(bytes32,string)` | a party to that offer, order, sale, note or reward | - | Freeze an order pending arbitration. The cases this exists for are the ones no proof can settle: the taker paid but the attestor cannot produce a proof (bank downtime, an unsupported statement form... <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:1067` |
| `reclaimExpired(bytes32)` | anyone | - | After the window and the taker's grace (TAKER_GRACE), anyone may return unpaid liquidity to the LP. <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:996` |
| `releaseWithProof(bytes32,bytes)` | anyone carrying a proof the contract's verifier accepts | - | Present proof the BRL was paid, and take delivery. <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:866` |
| `renounceGovernor()` | the governor (key) | instant | Give governance up for good: to 0x...dEaD, at once, and every queued change void. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:204` |
| `rescueShielded(…)` | a party to that offer, order, sale, note or reward | - | The order's recipient ragequits a shielded delivery back out of the pool, to itself. | open | `contracts/ramp/FiatEscrow.sol:1271` |
| `resolveDispute(…)` | anyone carrying a registered arbitrator's signed ruling (key) | - | Submit an arbitrator's signed ruling. Anyone may submit it: the first submission posts it, and the same ruling submitted again after RULING_DELAY executes it. <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:1148` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:227` |
| `setArbitrator(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Adding an arbitrator waits out the governance delay; removing one is instant. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/FiatEscrow.sol:1310` |
| `setAsset(address,address,uint8,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | List or delist a settlement asset. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/FiatEscrow.sol:566` |
| `setAssetCap(address,uint256)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Lowering or setting a first cap is instant; raising or removing one is delayed. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/FiatEscrow.sol:1322` |
| `setRecipient(bytes32,address)` | a party to that offer, order, sale, note or reward | - | The order's recipient names another (L-30), while the order is LOCKED or DISPUTED: an issuer block on the first address must not strand a payment the taker made. The new one is screened as at lock. <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:984` |
| `setTakerGate(bytes32,address)` | a party to that offer, order, sale, note or reward | - | The LP names its offer's taker gate, or zero for none (H-04). From then on every lock of the offer needs the gate's one-use approval. Orders already locked are unaffected. <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:684` |
| `setVerifier(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Allowing a verifier waits out the governance delay; revoking one is instant. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/FiatEscrow.sol:1302` |
| `takeDeliveryDirect(bytes32)` | a party to that offer, order, sale, note or reward | - | Take a shielded order's delivery in the open instead, to the rescue address. A shielded delivery can become impossible after the taker has paid: the Entrypoint or the pool can be frozen by the toke... <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:963` |
| `transferGovernor(address)` | the governor (key) | instant | During setup, hand over at once. After it, propose `to` as the next governor; it takes over when it calls `acceptGovernor`, and a later proposal replaces this one (I-36). <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:190` |

</details>

#### OffRampEscrow (Movva off-ramp)

`0xCD95EC2aF9fA84Ab588F4279C86e8e8c4449606d` - `OffRampEscrow`, `contracts/ramp/OffRampEscrow.sol`. Off-ramp escrow: a seller escrows crypto in a sale; an LP claims it, pays the seller BRL, and is paid the crypto on a proof. **Holds funds.**

- governor `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`; setup complete; delay 48 h; 0 pending change(s)
- arbitrator: `0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7`
- allowed verifier: `0xdB87f0170Ef6bad9805Cd7203e793e9F4dacD74e`
- listed asset (enabled): `0xa849B93B5ec04bb1b979faE8B82F8Fb66663AAD7`
- EIP-1967 slots: empty (not a proxy)

- **governor** can list and delist assets and their band oracles, allow and revoke payment verifiers, add and remove arbitrators, set asset caps. After setup, listing, allowing, adding and raising wait GOVERNANCE_DELAY; delisting, revoking, removing and lowering are instant. It cannot move a sale's escrowed crypto, change an asset's decimals once set, or decide a dispute: a ruling needs an arbitrator's signature. Its power over funds is indirect: which verifiers and arbitrators the escrow believes. (`contracts/ramp/OffRampEscrow.sol:311`, `contracts/ramp/OffRampEscrow.sol:740`, `contracts/ramp/OffRampEscrow.sol:748`, `contracts/ramp/OffRampEscrow.sol:769`, `contracts/common/DelayedGovernance.sol:190`, `contracts/common/DelayedGovernance.sol:227`, …)
- **arbitrator** can sign a ruling on a DISPUTED sale: pay the claiming LP, or return the crypto to the seller. Anyone submits it; it executes only after RULING_DELAY (1 day), re-verified then. Paying the LP needs an arbitrator registered no later than the dispute was raised. It cannot reach a sale that is not in dispute, or pay anyone but the sale's two counterparties. (`contracts/ramp/OffRampEscrow.sol:645`)

<details><summary>22 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `abandonClaim(bytes32)` | a party to that offer, order, sale, note or reward | - | Give the claim back early, without penalty. The sale is cancellable at once and claimable again after CLAIM_COOLDOWN, by any LP, this one included. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:476` |
| `acceptGovernor()` | a party to that offer, order, sale, note or reward | - | The proposed governor takes over. Every change the previous one queued is void. <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/common/DelayedGovernance.sol:198` |
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:239` |
| `cancelSale(bytes32)` | a party to that offer, order, sale, note or reward | - | The seller cancels a sale that is unclaimed or whose claim is past payBy, and takes its crypto back. | every probe refused on its zero arguments | `contracts/ramp/OffRampEscrow.sol:409` |
| `claimSale(bytes32)` | an LP the registry lets quote | - | Take exclusivity on a sale in order to pay it. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:437` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:172` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:254` |
| `expireDispute(bytes32)` | anyone | - | After DISPUTE_TIMEOUT with no ruling, anyone returns the escrowed crypto to the seller's refund address and frees the LP's credit. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:723` |
| `openSale(…)` | anyone | - | Escrow ETH and ask for BRL. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:337` |
| `ossify()` | the governor (key) | instant | One-way: no risk-increasing change can ever run again; the instant, risk-reducing ones stay with the governor. See "Ossify" above. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:180` |
| `raiseDispute(bytes32,string)` | a party to that offer, order, sale, note or reward | - | Freeze a claimed sale pending arbitration. Either side may, only while the claim is live, `block.timestamp <= payBy`: the LP since H-04, the seller since v3.1 N-22. <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/OffRampEscrow.sol:596` |
| `releaseStaleClaim(bytes32)` | anyone | - | Clear a claim nobody honoured. Callable by anyone: leaving this to the seller would mean a seller without gas stays frozen. The sale is open again: cancellable at once, claimable after CLAIM_COOLDOWN. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:467` |
| `renounceGovernor()` | the governor (key) | instant | Give governance up for good: to 0x...dEaD, at once, and every queued change void. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:204` |
| `resolveDispute(…)` | anyone carrying a registered arbitrator's signed ruling (key) | - | Submit an arbitrator's signed ruling. Anyone may submit it: the first submission posts it, and the same ruling submitted again after RULING_DELAY executes it. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:645` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:227` |
| `setArbitrator(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Adding an arbitrator waits out the governance delay; removing one is instant. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/OffRampEscrow.sol:748` |
| `setAsset(address,address,uint8,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | List or delist a settlement asset. Decimals are fixed once first set. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/OffRampEscrow.sol:311` |
| `setAssetCap(address,uint256)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Lowering or setting a first cap is instant; raising or removing one is delayed. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/OffRampEscrow.sol:769` |
| `setRefundTo(bytes32,address)` | a party to that offer, order, sale, note or reward | - | The seller names another refund address while the sale is live (L-30): an issuer block on the first must not strand the seller's crypto. Screened as at open. <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/OffRampEscrow.sol:398` |
| `setVerifier(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Allowing a verifier waits out the governance delay; revoking one is instant. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/OffRampEscrow.sol:740` |
| `settleWithProof(bytes32,bytes)` | anyone carrying a proof the contract's verifier accepts | - | Prove the seller was paid, and collect the escrowed ETH. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:517` |
| `transferGovernor(address)` | the governor (key) | instant | During setup, hand over at once. After it, propose `to` as the next governor; it takes over when it calls `acceptGovernor`, and a later proposal replaces this one (I-36). <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:190` |

</details>

## Etherscan verification

`deployments/sepolia-movva-v6-rail/etherscan-verify.sh` holds the exact `forge verify-contract` command for each address, with its constructor arguments and linked libraries. **They were not run.** Each was dry-run instead: forge wrote the standard-JSON input it would submit (`--show-standard-json-input`), solc 0.8.28+commit.7893614a compiled it, and the result was compared with the code at the address and with the creation transaction's init code: 23 of 23 match.

Library paths are spelled through the remapping (`poseidon-solidity/PoseidonT3.sol`). Forge 0.3.0 writes any other spelling into the input as a path solc does not match. The pools then compile with unlinked placeholders, and Etherscan would not match them. The dry run fails any input whose libraries are left unlinked.

## What was NOT verified

- Etherscan itself. The verify commands were generated and dry-run offline, not submitted. The dry run repeats Etherscan's compile with the same solc, but not Etherscan's service.
- That the code is correct. This report proves which code is deployed and who can call it. Whether that code is safe is the audit's question (`docs/audit-scope.md`).
- Behaviour. No deposit, order, dispute, mint or withdrawal was executed here: the verification pass is read-only. Those flows are exercised by the Foundry and vitest suites.
- Immutable values byte by byte. They are masked in the bytecode comparison and checked through their getters by the wiring checks (Entrypoint, pools, oracles, tokens, delays, timeouts).
- The exact source text of the Privacy Pools contracts. The protocol build omits CBOR metadata (`bytecode_hash = "none"`), so for those contracts the match proves the bytecode. Their source files are hashed against the build's metadata separately.
- The Poseidon libraries' creation. They were already on the chain at deterministic addresses; their code is matched, their creation is not.
- Key custody. The inventory shows which addresses hold the remaining roles. It cannot show who holds those keys or how they are kept.
- Contracts outside the deployment: Pyth, the Chainlink feeds and their owners, CreateX and (on mainnet) USDT.
- Off-chain services: the relayer, the ASP that computes roots, the Pyth keeper and the monitor.
- Live prices. Pyth's FX.USD/BRL is stale on this chain, so the 8 checks that read it can only confirm each reader refuses it with exactly `StaleRate` (see Prices). A fresh-price read was not possible here.
