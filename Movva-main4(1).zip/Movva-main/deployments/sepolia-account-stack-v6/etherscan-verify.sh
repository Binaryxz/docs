#!/usr/bin/env bash
# Etherscan source verification for the account contracts redeployed for v2.0 (deployments/sepolia-account-stack-v6.json). Submit with scripts/etherscan-verify-v2.py.
# Each constructor argument string is the creation transaction's input after the build's creation code (an exact prefix).
set -euo pipefail
: "${ETHERSCAN_API_KEY:?set ETHERSCAN_API_KEY}"
FORGE="${FORGE:-$(bash scripts/foundry.sh path)}"

# passkeyCoSignerValidator: PasskeyCoSignerValidator
(cd packages/smart-account/contracts && "$FORGE" verify-contract 0xd8E6C075F042874d97c72d6324C9FfA4f687FcDD src/PasskeyCoSignerValidator.sol:PasskeyCoSignerValidator --chain sepolia --compiler-version v0.8.28+commit.7893614a --num-of-optimizations 1000 --evm-version cancun --constructor-args 0x0000000000000000000000001d31f259ee307358a26dfb23eb365939e8641195 --etherscan-api-key "$ETHERSCAN_API_KEY" --watch)
# kernelAvatarAdapter: KernelAvatarAdapter
(cd packages/smart-account/contracts && "$FORGE" verify-contract 0x28093B0879DA221B9db507533709b32a89000b5B src/KernelAvatarAdapter.sol:KernelAvatarAdapter --chain sepolia --compiler-version v0.8.28+commit.7893614a --num-of-optimizations 1000 --evm-version cancun --etherscan-api-key "$ETHERSCAN_API_KEY" --watch)
# auditGrantRegistry: AuditGrantRegistry
"$FORGE" verify-contract 0x9D8c8564d6A7fA58e4Fb0B912E0E685ab2e8Cb14 contracts/AuditGrantRegistry.sol:AuditGrantRegistry --chain sepolia --compiler-version v0.8.28+commit.7893614a --num-of-optimizations 200 --evm-version cancun --etherscan-api-key "$ETHERSCAN_API_KEY" --watch
