# Verification report: Movva rail on Sepolia (MOVVA only)

Generated 2026-10-27T02:13:53.413Z by `scripts/deploy-movva-rail.ts`. Everything below was read from the chain after the deployment, and every number in it comes from the deployment JSON and `deployments/sepolia-movva-v5-rail/privileges.json`.

## Summary

| | |
|---|---|
| Chain | Sepolia, chain id 11155111 |
| Commit | `6bcac7b992176f969c09c3991618be01bf4c7e8e` on `phase-1-shielded-rail`, clean tree |
| Build hash | `3cc301bcb69d5462681e685cba55bb59adb1412d6914e4a0e2a95e732a27e614` |
| Deployer | `0x9F65C8910d741427Df73B500724Eb4D36b46996f` |
| Contracts | 21 addresses, 21 distinct contracts, 21 running this build |
| Transactions | 62, 270,252,644 gas; blocks 12001585 to 12002042 |
| Checks | **349 pass, 8 expected, 0 fail** |
| Governance | finalized: every governor handed to `0x000000000000000000000000000000000000dEaD`, the Entrypoint's OWNER_ROLE renounced; ASP_POSTMAN held by the AspRootQuorum alone |
| **Test keys made permanent** | **18 role(s) that remain for ever are held by seed-derived test identities, or are the illustrative zkTLS templates** (`MOVVA_FINALIZE_ALLOW_TEST_KEYS=yes-this-is-a-rehearsal`). A demonstration only: see Substitutions |

> **Finalized with test keys (SRM1-1 opt-out, `MOVVA_FINALIZE_ALLOW_TEST_KEYS=yes-this-is-a-rehearsal`).** `--finalize` normally refuses while any role that outlives it is a test identity. This run was told to proceed anyway, so the following can never be replaced or revoked by anyone:

> - zkTLS witness 0x05EfF3D8e0ad59Aa8abFd94E0b08402ec0850Fbf: witness/0 (MOVVA_TEST_KEY_SEED)
> - zkTLS witness 0x8771D8B0038061D7872e4c2C69cD63F54380CBAb: witness/1 (MOVVA_TEST_KEY_SEED)
> - zkTLS witness 0x72C1a86B73Ca01Fec5e07160AE14a32849eE5214: witness/2 (MOVVA_TEST_KEY_SEED)
> - Movva FiatEscrow arbitrator 0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7: arbitrator (recorded test identity)
> - Movva OffRampEscrow arbitrator 0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7: arbitrator (recorded test identity)
> - registry LP 0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C: lp/0, the test LP and gateway (MOVVA_TEST_KEY_SEED)
> - reserve gateway 0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C: lp/0, the test LP and gateway (MOVVA_TEST_KEY_SEED)
> - reserve yield recipient 0x622F626F912AD25d36D9B8F48907Ac941F755ACb: treasury/0 (MOVVA_TEST_KEY_SEED)
> - FeeSplitter treasury 0x622F626F912AD25d36D9B8F48907Ac941F755ACb: treasury/0 (MOVVA_TEST_KEY_SEED)
> - AspRootQuorum ASP 0x6f239a1A5818808E63BB6F35A88B9876a79aa973: asp/0 (MOVVA_TEST_KEY_SEED)
> - AspRootQuorum ASP 0xc8510850c5bF41B52399473F234577B2d8Ef0B16: asp/1 (MOVVA_TEST_KEY_SEED)
> - AspRootQuorum ASP 0x323574Eb0c63b764F06832f15B21956bb8979FC9: asp/2 (MOVVA_TEST_KEY_SEED)
> - Entrypoint owner timelock proposer 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1: a 2-of-3 Safe whose owners custody/governor/signer/0 (MOVVA_TEST_KEY_SEED), custody/governor/signer/1 (MOVVA_TEST_KEY_SEED), custody/governor/signer/2 (MOVVA_TEST_KEY_SEED) are test keys
> - Entrypoint owner timelock executor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1: a 2-of-3 Safe whose owners custody/governor/signer/0 (MOVVA_TEST_KEY_SEED), custody/governor/signer/1 (MOVVA_TEST_KEY_SEED), custody/governor/signer/2 (MOVVA_TEST_KEY_SEED) are test keys
> - zkTLS endpoint 0xb54d2a19bba3a502dc449c083cd2579885618e4e0487435aae1673f06baf0c05: URL prefix https://api.banco-lp.example/ is on a reserved test domain (RFC 2606)
> - zkTLS endpoint 0xd8d90d629dc91348bf69c3c5148cd5bf1efdc99220a15a6f42d6ad42eeb2bb20: URL prefix https://api.banco-lp.example/ is on a reserved test domain (RFC 2606)
> - zkTLS endpoint 0x8259a0510dbf7425215eada80e9a8fcc1bac48d4e24e3cea67b5185b482abf77: URL prefix https://api.banco-lp.example/ is on a reserved test domain (RFC 2606)
> - zkTLS endpoint 0xf02c2badc915c0c690ccba5dd00202b6efcc3d49a1c1197db4026f075aaddc1a: URL prefix https://api.banco-lp.example/ is on a reserved test domain (RFC 2606)
>
> Whoever holds the test seed can forge payment proofs and rule disputes on this deployment for ever. It must never hold real value.

## Substitutions

What this deployment uses in place of the production component, as the deployment JSON records it:

- USDT: a stand-in TetherLike (contracts/test/ERC4626Adapter.t.sol) - 6 decimals and Tether's isBlackListed/pause/fee surface, but mint, pause and blacklist are open to anyone. Sepolia has no canonical USDT
- USDT/USD leg: Chainlink USDC/USD on Sepolia (0xA2F78ab2355fe2f984D808B5CeE7FD0A93D5270E, ~24h heartbeat), for the reserve
- custody (MOVVA_RAIL_CUSTODY=deployments/sepolia-movva-only-custody-rehearsal.json): the reserve's guardian and the escrows' only arbitrator are that record's 2-of-3 Safes from setup (its hedge-treasury Safe is recorded as the sleeve's treasury, not a reserve role), whose signers are test keys derived from the seed; witnesses, the institutional LP / Movva gateway and the treasury: test keys derived from the seed
- reserve yield recipient: the treasury 0x622F626F912AD25d36D9B8F48907Ac941F755ACb, a test key derived from the seed (MOVVA_RAIL_YIELD_RECIPIENT unset). The client rule of 21 October 2026 makes it Mova's Safe; harvestYield pays it, and only it, the yield above max(principal, liabilities at the target)
- ASPs: the AspRootQuorum's three ASPs are test keys derived from the seed (asp/0 stands for Movva; asp/1 and asp/2 for the two independent ASPs the client has yet to confirm)
- governor Safe: a 2-of-3 Safe 1.4.1 whose signers are test keys derived from the seed (movva-rail/<seed>/custody/governor/signer/0..2); it governs every DelayedGovernance contract from setup and drives the Entrypoint owner timelock
- Scope (client decisions, 14 October 2026): MOVVA only. No savings (D1: the code has no sMovva, no sMovva pool and no `distribute`; the reserve's surplus stays in it), no ETH/USDT ramp pair and no ETH or USDT band oracle. The ETH pool is upstream's, deployed by its protocol script; the product does not use it, and the owner step winds it down and removes it (M-18)
- zkTLS endpoints: the four illustrative receipt templates of packages/ramp receiptTemplates(prefix), not a real bank's
- Privacy Pools: a fresh upstream stack owned by the deployer until the owner step, not Mova's 8 September Entrypoint (its OWNER_ROLE key is not on this machine)
- Divergence breaker: none (MOVVA_BREAKER=off). Sepolia has no BRL/USD Chainlink feed or BRL stablecoin pool to read as a second price source, so this run deploys the reserve without one; the breaker is proven by its tests, not by this deployment
- FINALIZED WITH TEST KEYS (MOVVA_FINALIZE_ALLOW_TEST_KEYS=yes-this-is-a-rehearsal, SRM1-1 opt-out): the roles that remain for ever are held by seed-derived test identities, or are packages/ramp's illustrative zkTLS templates, and nobody can ever replace them - zkTLS witness 0x05EfF3D8e0ad59Aa8abFd94E0b08402ec0850Fbf: witness/0 (MOVVA_TEST_KEY_SEED); zkTLS witness 0x8771D8B0038061D7872e4c2C69cD63F54380CBAb: witness/1 (MOVVA_TEST_KEY_SEED); zkTLS witness 0x72C1a86B73Ca01Fec5e07160AE14a32849eE5214: witness/2 (MOVVA_TEST_KEY_SEED); Movva FiatEscrow arbitrator 0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7: arbitrator (recorded test identity); Movva OffRampEscrow arbitrator 0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7: arbitrator (recorded test identity); registry LP 0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C: lp/0, the test LP and gateway (MOVVA_TEST_KEY_SEED); reserve gateway 0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C: lp/0, the test LP and gateway (MOVVA_TEST_KEY_SEED); reserve yield recipient 0x622F626F912AD25d36D9B8F48907Ac941F755ACb: treasury/0 (MOVVA_TEST_KEY_SEED); FeeSplitter treasury 0x622F626F912AD25d36D9B8F48907Ac941F755ACb: treasury/0 (MOVVA_TEST_KEY_SEED); AspRootQuorum ASP 0x6f239a1A5818808E63BB6F35A88B9876a79aa973: asp/0 (MOVVA_TEST_KEY_SEED); AspRootQuorum ASP 0xc8510850c5bF41B52399473F234577B2d8Ef0B16: asp/1 (MOVVA_TEST_KEY_SEED); AspRootQuorum ASP 0x323574Eb0c63b764F06832f15B21956bb8979FC9: asp/2 (MOVVA_TEST_KEY_SEED); Entrypoint owner timelock proposer 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1: a 2-of-3 Safe whose owners custody/governor/signer/0 (MOVVA_TEST_KEY_SEED), custody/governor/signer/1 (MOVVA_TEST_KEY_SEED), custody/governor/signer/2 (MOVVA_TEST_KEY_SEED) are test keys; Entrypoint owner timelock executor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1: a 2-of-3 Safe whose owners custody/governor/signer/0 (MOVVA_TEST_KEY_SEED), custody/governor/signer/1 (MOVVA_TEST_KEY_SEED), custody/governor/signer/2 (MOVVA_TEST_KEY_SEED) are test keys; zkTLS endpoint 0xb54d2a19bba3a502dc449c083cd2579885618e4e0487435aae1673f06baf0c05: URL prefix https://api.banco-lp.example/ is on a reserved test domain (RFC 2606); zkTLS endpoint 0xd8d90d629dc91348bf69c3c5148cd5bf1efdc99220a15a6f42d6ad42eeb2bb20: URL prefix https://api.banco-lp.example/ is on a reserved test domain (RFC 2606); zkTLS endpoint 0x8259a0510dbf7425215eada80e9a8fcc1bac48d4e24e3cea67b5185b482abf77: URL prefix https://api.banco-lp.example/ is on a reserved test domain (RFC 2606); zkTLS endpoint 0xf02c2badc915c0c690ccba5dd00202b6efcc3d49a1c1197db4026f075aaddc1a: URL prefix https://api.banco-lp.example/ is on a reserved test domain (RFC 2606). A rehearsal or testnet demonstration only: whoever holds the test seed can forge payment proofs and rule disputes on it for ever

## What was deployed, and where

| Contract | Address | Source | Source sha256 | Runtime sha256 (build) | On chain |
|---|---|---|---|---|---|
| Privacy Pools Entrypoint (proxy) | `0xFa3A263bA866Dd12df5eb671C9E5004F7E4d87C8` | `node_modules/@openzeppelin/contracts/proxy/ERC1967/ERC1967Proxy.sol` | `03cdbd59c384fe18`… | `f1f38be5dd06d358`… | identical |
| Entrypoint implementation | `0xF8cF00E698c2D53ee900b06BA9285D6b9B148692` | `protocol/contracts/src/contracts/Entrypoint.sol` | `8245c32d50ae6582`… | `6408ed2ab26661a7`… | identical outside immutables |
| Withdrawal Groth16 verifier | `0x59f80dEBc22E4F9B0f37Ba0251303e11Fe9e9616` | `protocol/contracts/src/contracts/verifiers/WithdrawalVerifier.sol` | `7b6991befbc9a94a`… | `77bfc587acc64f36`… | identical |
| Ragequit (commitment) Groth16 verifier | `0xfEb764A2d109f0B3F4868Ff7609b1f30397fCA84` | `protocol/contracts/src/contracts/verifiers/CommitmentVerifier.sol` | `de24f75d21d651c0`… | `ebae2d48b14ac64f`… | identical |
| ETH Privacy Pool (upstream's; unused by the product) | `0x6C8e74582f738B8327d4432b4238f4b0c2347116` | `protocol/contracts/src/contracts/implementations/PrivacyPoolSimple.sol` | `f0d97040fd5bd00d`… | `92fdf5ae69da7a5d`… | identical outside immutables |
| PoseidonT3 library (pre-existing) | `0x8ffdA7Ed8B4aD98C2C34f54B76821711F4a6f2C5` | `node_modules/poseidon-solidity/PoseidonT3.sol` | `08a7493be3783816`… | `23a48ae4bae13d19`… | identical |
| PoseidonT4 library (pre-existing) | `0xe393dd7287Db9982e6f845824854Baf8b8e823AF` | `node_modules/poseidon-solidity/PoseidonT4.sol` | `289e22a19a20bcec`… | `e2f5e98664dbafbe`… | identical |
| Stand-in USDT (OwnedTetherLike) | `0xC427DcC3Fd4CB32fBD3Df12BEbc39486aB791A9c` | `contracts/test/utils/OwnedTetherLike.sol` | `584367afdfb7c75a`… | `2b39e3882d15bf47`… | identical |
| MovvaReserve | `0xE5ECD575F283331675E3734cBffCB70D37833926` | `contracts/movva/MovvaReserve.sol` | `7945c87e58d8a062`… | `8c55626eef549d9a`… | identical outside immutables |
| Movva (token) | `0xB7C02dFb1876Db52941fcaa38515a44F147c7986` | `contracts/movva/Movva.sol` | `abe9ea0c2812eb1d`… | `fb21f34746b333a8`… | identical outside immutables |
| Movva FX leg (PythFxOracle) | `0x0A9c2541c699F2F3308DFB70b9B846D7987bE108` | `contracts/ramp/PythFxOracle.sol` | `d484bba9344f2787`… | `43a4ebb1b3e42600`… | identical outside immutables |
| Movva band adapter (ScaledFxBandOracle) | `0x46AF143C878918ceD813C9B3C2Cbee4aEDf84dbC` | `contracts/movva/ScaledFxBandOracle.sol` | `ddd60c94d0d23dab`… | `e33a6eab3426e975`… | identical outside immutables |
| FeeSplitter | `0x48c00e0222a674a9d920482538d97928A870016D` | `contracts/movva/FeeSplitter.sol` | `5076331e39e83c74`… | `1fd2067ceb6c52e4`… | identical outside immutables |
| NodeRewards | `0x2b9a9F186414665468FBE68eE5cF2344e820Aa05` | `contracts/ramp/NodeRewards.sol` | `c526d4fe30d52c59`… | `a81889d023813aac`… | identical outside immutables |
| Movva Privacy Pool | `0xB3C042132A1650E01F61165ebf74c6c5aDa9f080` | `protocol/contracts/src/contracts/implementations/PrivacyPoolComplex.sol` | `0f9c34f0bfd03a35`… | `d1e5735be46a6b62`… | identical outside immutables |
| Entrypoint owner (TimelockController, 7 days) | `0x640ce45e8CBadCB7671Df7D98Cb8c085764C2C86` | `contracts/governance/EntrypointTimelock.sol` | `14b611926a466386`… | `fd5b9cd21637ac98`… | identical |
| AspRootQuorum (ASP postman, 2 of 3) | `0xC12e3DD76faDef119C8A8691959375948E4ea3a1` | `contracts/AspRootQuorum.sol` | `c3302c2b2d6f11e4`… | `5644ed194c5100a1`… | identical outside immutables |
| LPRegistry | `0xf182Eb04AbA75452CE5F4c400B0742C2f0abc7e2` | `contracts/ramp/LPRegistry.sol` | `e3b84eb7ba5327fd`… | `291e4e4187f125ec`… | identical outside immutables |
| ReclaimZkTlsVerifier (PIX, boleto, TED) | `0x1bE9d1Dbeb61B2815287de8eDA85B30EB1917F9d` | `contracts/ramp/ReclaimZkTlsVerifier.sol` | `62d7cd10165754be`… | `3f722e8efc942b01`… | identical outside immutables |
| FiatEscrow (Movva on-ramp) | `0x1fa7a70DA69f9Aa8A8074D939962E9187a102c39` | `contracts/ramp/FiatEscrow.sol` | `e014338ab8fb29a8`… | `5aa0fc2438db43e5`… | identical outside immutables |
| OffRampEscrow (Movva off-ramp) | `0x8cB7DDDaac7Fa98f747DF0553F3C7E375936499E` | `contracts/ramp/OffRampEscrow.sol` | `941caa9208a71d4c`… | `a755542bb72c134a`… | identical outside immutables |

Full hashes, artifacts and constructor arguments are in the deployment JSON under `record.contracts`. ABIs: `deployments/sepolia-movva-v5-rail/abi/` (21 files; the Entrypoint proxy's callable ABI is `Entrypoint.json`).

## Build

**Build hash `3cc301bcb69d5462681e685cba55bb59adb1412d6914e4a0e2a95e732a27e614`**: sha256 over the concatenated runtime bytecode (artifact deployedBytecode, library placeholders as 20 zero bytes, immutables as compiled) of every distinct deployed contract, sorted by its hex. Recompute it from a checkout of the commit with `npx tsx scripts/deployment-record.ts build-hash <deployment.json>` after `forge build` in the repo root and in `protocol/contracts`.

| Contract | Build | Runtime bytes | Runtime sha256 |
|---|---|---:|---|
| AspRootQuorum | root | 2,566 | `5644ed194c5100a101f164116738b6a6a53725896fb2d28a0842af61fdd2e625` |
| CommitmentVerifier | protocol | 1,582 | `ebae2d48b14ac64f45fd3df64ea84a60145ec212916915548cf93a7651b80f23` |
| Entrypoint | protocol | 13,490 | `6408ed2ab26661a75035495c8676b15f9f44321fcf9b611a811efb3c82be7395` |
| EntrypointTimelock | root | 6,550 | `fd5b9cd21637ac9859d6eb70e3fa0eb60f1fbfcb2b4933c49aea925a3a947b55` |
| ERC1967Proxy | protocol | 122 | `f1f38be5dd06d358ef10a9010c1b52388094c454ae2b594351c124196c631df2` |
| FeeSplitter | root | 5,284 | `1fd2067ceb6c52e454d99d93687f703a5819db259acea974986d393339f65fb6` |
| FiatEscrow | root | 23,853 | `5aa0fc2438db43e56aad8a103fdae945746feac3a6e0b7eda579b20291cb19ac` |
| LPRegistry | root | 10,151 | `291e4e4187f125ecd86982192be8c8e874f34c4dbdc495b45d9b8f50fccadbf4` |
| Movva | root | 4,183 | `fb21f34746b333a84c282cc36fdc9215a5421c094e9e355e02568a338fef85ba` |
| MovvaReserve | root | 22,962 | `8c55626eef549d9ab5d15e916b2e61f4678860c1d7670e0b7cf4382189169bd0` |
| NodeRewards | root | 9,878 | `a81889d023813aac5efad4d2bbc6f65f5c136770a48e5cb4880c922666dea3f8` |
| OffRampEscrow | root | 18,886 | `a755542bb72c134a7b8feaa3549efa29001f3dd8f166a29e0ea3fc4e011bcc21` |
| OwnedTetherLike | root | 2,786 | `2b39e3882d15bf47389c3c91bad17453ca130f5cf014d444a9985880c70c8756` |
| PoseidonT3 | protocol | 23,522 | `23a48ae4bae13d19ecdb8321c33ae70c31bd5b1c37972bc673f2d073b6026fb6` |
| PoseidonT4 | protocol | 12,584 | `e2f5e98664dbafbeb3b29dfaf490adad71c401b9fa5076c9e0b1efd853d59071` |
| PrivacyPoolComplex | protocol | 7,720 | `d1e5735be46a6b62a4e7e72e1372455087813ac08eec4f1d9880b4d23e185216` |
| PrivacyPoolSimple | protocol | 7,378 | `92fdf5ae69da7a5d9a6beaa4074806c821cbabc887dfecee95576c93e4b1c57a` |
| PythFxOracle | root | 6,098 | `43a4ebb1b3e4260062aaa030302328bac87d7da2de8a93f859ccc6ecc80e84a6` |
| ReclaimZkTlsVerifier | root | 17,293 | `3f722e8efc942b01c5084e827e513cac46d943f15dd5d9baea6b9a388e2baf52` |
| ScaledFxBandOracle | root | 706 | `e33a6eab3426e975b8f1c5bc07f3f50c12ac17577fba8f8516248155a5db6a36` |
| WithdrawalVerifier | protocol | 1,947 | `77bfc587acc64f361df684b77293f84073e4894b61bd870fc078510562fb7bb8` |

| Build | Config | Compiler | Optimizer | EVM | viaIR | Metadata hash |
|---|---|---|---|---|---|---|
| protocol | `protocol/contracts/foundry.toml` | 0.8.28+commit.7893614a (sha256 9a0fb7e0db2c0641…) | on, 10000 runs | cancun | false | none (no CBOR) |
| root | `foundry.toml` | 0.8.28+commit.7893614a (sha256 9a0fb7e0db2c0641…) | on, 200 runs | cancun | false | ipfs |

Forge: `forge 0.3.0 (5a8bd89 2024-12-19T17:17:10.245193696Z)`. Sources: 93 files compiled into the deployed contracts, every one identical on disk to the keccak256 its build recorded.

## Checks

Every check the verification pass ran, grouped: 349 pass, 8 expected, 0 fail. "Expected" is only ever a price refusal the check predicted exactly (see Prices).

### Code at every address (23 pass)

<details><summary>23 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | code at protocol.entrypoint | 0xFa3A263bA866Dd12df5eb671C9E5004F7E4d87C8 |
| pass | code at protocol.entrypointImplementation | 0xF8cF00E698c2D53ee900b06BA9285D6b9B148692 |
| pass | code at protocol.withdrawalVerifier | 0x59f80dEBc22E4F9B0f37Ba0251303e11Fe9e9616 |
| pass | code at protocol.commitmentVerifier | 0xfEb764A2d109f0B3F4868Ff7609b1f30397fCA84 |
| pass | code at protocol.ethPool | 0x6C8e74582f738B8327d4432b4238f4b0c2347116 |
| pass | code at protocol.poseidonT3 | 0x8ffdA7Ed8B4aD98C2C34f54B76821711F4a6f2C5 |
| pass | code at protocol.poseidonT4 | 0xe393dd7287Db9982e6f845824854Baf8b8e823AF |
| pass | code at standInUsdt | 0xC427DcC3Fd4CB32fBD3Df12BEbc39486aB791A9c |
| pass | code at movva.reserve | 0xE5ECD575F283331675E3734cBffCB70D37833926 |
| pass | code at movva.token | 0xB7C02dFb1876Db52941fcaa38515a44F147c7986 |
| pass | code at movva.fxLeg | 0x0A9c2541c699F2F3308DFB70b9B846D7987bE108 |
| pass | code at movva.bandAdapter | 0x46AF143C878918ceD813C9B3C2Cbee4aEDf84dbC |
| pass | code at movva.feeSplitter | 0x48c00e0222a674a9d920482538d97928A870016D |
| pass | code at movva.nodeRewards | 0x2b9a9F186414665468FBE68eE5cF2344e820Aa05 |
| pass | code at pools.movva | 0xB3C042132A1650E01F61165ebf74c6c5aDa9f080 |
| pass | code at asp.quorum | 0xC12e3DD76faDef119C8A8691959375948E4ea3a1 |
| pass | code at ramp.registry | 0xf182Eb04AbA75452CE5F4c400B0742C2f0abc7e2 |
| pass | code at ramp.zktls | 0x1bE9d1Dbeb61B2815287de8eDA85B30EB1917F9d |
| pass | code at ramp.movvaOnramp | 0x1fa7a70DA69f9Aa8A8074D939962E9187a102c39 |
| pass | code at ramp.movvaOfframp | 0x8cB7DDDaac7Fa98f747DF0553F3C7E375936499E |
| pass | code at ownership.timelock | 0x640ce45e8CBadCB7671Df7D98Cb8c085764C2C86 |
| pass | code at ownership.safe | 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | code at ownership.canceller | 0xd67DDA7D07CAa45d6f8e7C1dD0a170585e6B086c |

</details>

### Governance: governor, setup, delay (40 pass)

<details><summary>40 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | MovvaReserve governor (the Safe, ossified) | 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | MovvaReserve ossified (no risk-increasing change can ever run, N-04) | true |
| pass | MovvaReserve setupComplete | true |
| pass | MovvaReserve pendingChanges (nothing queued) | 0 |
| pass | MovvaReserve GOVERNANCE_DELAY | 172800 |
| pass | Movva FX leg (PythFxOracle) governor (the Safe, ossified) | 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | Movva FX leg (PythFxOracle) ossified (no risk-increasing change can ever run, N-04) | true |
| pass | Movva FX leg (PythFxOracle) setupComplete | true |
| pass | Movva FX leg (PythFxOracle) pendingChanges (nothing queued) | 0 |
| pass | Movva FX leg (PythFxOracle) GOVERNANCE_DELAY | 172800 |
| pass | FeeSplitter governor (the Safe, ossified) | 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | FeeSplitter ossified (no risk-increasing change can ever run, N-04) | true |
| pass | FeeSplitter setupComplete | true |
| pass | FeeSplitter pendingChanges (nothing queued) | 0 |
| pass | FeeSplitter GOVERNANCE_DELAY | 172800 |
| pass | NodeRewards governor (the Safe, ossified) | 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | NodeRewards ossified (no risk-increasing change can ever run, N-04) | true |
| pass | NodeRewards setupComplete | true |
| pass | NodeRewards pendingChanges (nothing queued) | 0 |
| pass | NodeRewards GOVERNANCE_DELAY | 172800 |
| pass | LPRegistry governor (the Safe, ossified) | 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | LPRegistry ossified (no risk-increasing change can ever run, N-04) | true |
| pass | LPRegistry setupComplete | true |
| pass | LPRegistry pendingChanges (nothing queued) | 0 |
| pass | LPRegistry GOVERNANCE_DELAY | 172800 |
| pass | ReclaimZkTlsVerifier governor (the Safe, ossified) | 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | ReclaimZkTlsVerifier ossified (no risk-increasing change can ever run, N-04) | true |
| pass | ReclaimZkTlsVerifier setupComplete | true |
| pass | ReclaimZkTlsVerifier pendingChanges (nothing queued) | 0 |
| pass | ReclaimZkTlsVerifier GOVERNANCE_DELAY | 172800 |
| pass | Movva FiatEscrow governor (the Safe, ossified) | 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | Movva FiatEscrow ossified (no risk-increasing change can ever run, N-04) | true |
| pass | Movva FiatEscrow setupComplete | true |
| pass | Movva FiatEscrow pendingChanges (nothing queued) | 0 |
| pass | Movva FiatEscrow GOVERNANCE_DELAY | 172800 |
| pass | Movva OffRampEscrow governor (the Safe, ossified) | 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | Movva OffRampEscrow ossified (no risk-increasing change can ever run, N-04) | true |
| pass | Movva OffRampEscrow setupComplete | true |
| pass | Movva OffRampEscrow pendingChanges (nothing queued) | 0 |
| pass | Movva OffRampEscrow GOVERNANCE_DELAY | 172800 |

</details>

### owner (6 pass)

<details><summary>6 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | Entrypoint OWNER_ROLE held by the TimelockController (H-02) | true |
| pass | Entrypoint OWNER_ROLE: the deployer renounced it | false |
| pass | Entrypoint DEFAULT_ADMIN_ROLE: not the deployer | false |
| pass | Entrypoint: the TimelockController is the only OWNER_ROLE holder and the deployer holds no role (every RoleGranted account re-checked) | OWNER_ROLE 0x640ce45e8CBadCB7671Df7D98Cb8c085764C2C86 |
| pass | TimelockController getMinDelay (7 days) | 604800 |
| pass | TimelockController: the Safe 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 alone proposes and executes, it and 0xd67DDA7D07CAa45d6f8e7C1dD0a170585e6B086c cancel (N-19); executor not open; it administers itself | PROPOSER, EXECUTOR: the Safe; CANCELLER: 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1, 0xd67DDA7D07CAa45d6f8e7C1dD0a170585e6B086c; DEFAULT_ADMIN: the timelock |

</details>

### Privacy Pools: Entrypoint roles and pools (7 pass)

<details><summary>7 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | Entrypoint: upstream's ETH pool removed (M-18) | 0x0000000000000000000000000000000000000000 |
| pass | upstream's ETH pool wound down (dead) | true |
| pass | Entrypoint holds no MOVVA fees | 0 units |
| pass | Entrypoint holds no ETH | 0 wei |
| pass | Entrypoint Movva pool (as the clean-up set it) | 0xB3C042132A1650E01F61165ebf74c6c5aDa9f080,1000000000000000000,10,100 |
| pass | Movva pool ENTRYPOINT | 0xFa3A263bA866Dd12df5eb671C9E5004F7E4d87C8 |
| pass | Movva pool ASSET | 0xB7C02dFb1876Db52941fcaa38515a44F147c7986 |

</details>

### ASP postman: the AspRootQuorum (12 pass)

<details><summary>12 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | AspRootQuorum ENTRYPOINT | 0xFa3A263bA866Dd12df5eb671C9E5004F7E4d87C8 |
| pass | AspRootQuorum THRESHOLD | 2 |
| pass | AspRootQuorum ASP_COUNT | 3 |
| pass | AspRootQuorum asps() are the recorded ASPs, in order | 0x6f239a1A5818808E63BB6F35A88B9876a79aa973,0xc8510850c5bF41B52399473F234577B2d8Ef0B16,0x323574Eb0c63b764F06832f15B21956bb8979FC9 |
| pass | the recorded ASPs are the seed's asp/0..2 (asp/0 = Movva; asp/1, asp/2 stand-ins) | 0x6f239a1A5818808E63BB6F35A88B9876a79aa973,0xc8510850c5bF41B52399473F234577B2d8Ef0B16,0x323574Eb0c63b764F06832f15B21956bb8979FC9 |
| pass | AspRootQuorum isAsp(asp/0) | true |
| pass | AspRootQuorum isAsp(asp/1) | true |
| pass | AspRootQuorum isAsp(asp/2) | true |
| pass | AspRootQuorum isAsp(deployer) is false | false |
| pass | Entrypoint ASP_POSTMAN held by the AspRootQuorum | true |
| pass | Entrypoint ASP_POSTMAN revoked from the deployer | false |
| pass | Entrypoint ASP_POSTMAN held by the quorum only (every RoleGranted account re-checked) | 0xC12e3DD76faDef119C8A8691959375948E4ea3a1 |

</details>

### Movva: reserve, FX leg, fees, rewards (48 pass)

<details><summary>48 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | reserve MOVVA | 0xB7C02dFb1876Db52941fcaa38515a44F147c7986 |
| pass | token RESERVE | 0xE5ECD575F283331675E3734cBffCB70D37833926 |
| pass | reserve USDT (stand-in) | 0xC427DcC3Fd4CB32fBD3Df12BEbc39486aB791A9c |
| pass | reserve USDT/USD feed (Chainlink USDC/USD) | 0xA2F78ab2355fe2f984D808B5CeE7FD0A93D5270E |
| pass | reserve FX oracle | 0x0A9c2541c699F2F3308DFB70b9B846D7987bE108 |
| pass | reserve has no distribute() (D1: no savings path) | reverts with no data; selector not in the code |
| pass | reserve has no previewDistribute() (D1: no savings path) | reverts with no data; selector not in the code |
| pass | reserve has no savings() (D1: no savings path) | reverts with no data; selector not in the code |
| pass | reserve has no distributionFeeBps() (D1: no savings path) | reverts with no data; selector not in the code |
| pass | reserve has no withdrawToHedge(uint256) (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no queueHedgeWithdrawal(uint256) (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no executeHedgeWithdrawal(uint256) (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no hedgeWithdrawable() (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no hedgeLimitBps() (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no hedgeUsed() (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no hedgeUsedAt() (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no hedgeRequests(uint256) (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no hedgeRequestCount() (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no HEDGE_QUEUE_DELAY() (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no minWithdrawCollateralRatioBps() (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no treasurer() (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no hedgeTreasury() (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no setTreasurer(address) (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no setHedgeTreasury(address) (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no setLimits(uint256,uint16) (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no sweep(address) (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no rescue(address,address,uint256) (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve yield recipient (principal-locked: the only payee of harvestYield) | 0x622F626F912AD25d36D9B8F48907Ac941F755ACb |
| pass | reserve principalUsdt (the cost basis: mint + recapitalize - redeem) | 0 with a supply of 0 |
| pass | reserve setYieldRecipient from the governor must be scheduled (delayed both ways), or refused for good once ossified | Ossified: the recipient can never change |
| pass | reserve guardian | 0xd67DDA7D07CAa45d6f8e7C1dD0a170585e6B086c |
| pass | reserve MAX_VAULT_BPS, MIN_ROUND_TRIP_FEE_BPS (N-03, N-06) | 9000,20 |
| pass | reserve TRADE_FX_MAX_AGE (N-06; zero for a Chainlink leg) | 300 |
| pass | reserve keyless exit delays (ORACLE_EXIT_DELAY, GATEWAY_EXIT_DELAY; N-01, N-02) | 604800,2592000 |
| pass | reserve mintPaused | false |
| pass | reserve fee recipient is the FeeSplitter | 0x48c00e0222a674a9d920482538d97928A870016D |
| pass | reserve fees (mint, redeem bps) | 10,10 |
| pass | reserve supply cap | 1000000000000000000000000 |
| pass | reserve gateway (the off-ramp's redeemer): test LP 0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C | true |
| pass | reserve gateway (the off-ramp's redeemer): institutional LP 0xf491FA29debC0D12d8F7c57B17995C2346F025AD | true |
| pass | Movva FX leg PYTH | 0xDd24F84d36BF92C65F92307595335bdFab5Bbd21 |
| pass | Movva FX leg usdBrlId | 0xd2db4dbf1aea74e0f666b0e8f73b9580d407f5e5cf931940b06dc633d7a95906 |
| pass | Movva FX leg maxAge / closedMaxAge / maxConfBps | 3600,345600,100 |
| pass | Movva band adapter SOURCE | 0x0A9c2541c699F2F3308DFB70b9B846D7987bE108 |
| pass | FeeSplitter rewards | 0x2b9a9F186414665468FBE68eE5cF2344e820Aa05 |
| pass | FeeSplitter treasury | 0x622F626F912AD25d36D9B8F48907Ac941F755ACb |
| pass | NodeRewards REWARD_TOKEN | 0xB7C02dFb1876Db52941fcaa38515a44F147c7986 |
| pass | NodeRewards bound to the registry | 0xf182Eb04AbA75452CE5F4c400B0742C2f0abc7e2 |

</details>

### Ramp wiring: registry, escrows, oracles (26 pass)

<details><summary>26 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | registry phase (0 = A) | 0 |
| pass | registry rewards hook | 0x2b9a9F186414665468FBE68eE5cF2344e820Aa05 |
| pass | registry accepts Movva FiatEscrow | true |
| pass | Movva FiatEscrow allows the zkTLS verifier | true |
| pass | Movva FiatEscrow arbitrator | true |
| pass | Movva FiatEscrow dispute timeout | 2592000 |
| pass | registry accepts Movva OffRampEscrow | true |
| pass | Movva OffRampEscrow allows the zkTLS verifier | true |
| pass | Movva OffRampEscrow arbitrator | true |
| pass | Movva OffRampEscrow dispute timeout | 2592000 |
| pass | registry: test LP is INSTITUTIONAL with its credit | tier 3, 5000000 centavos |
| pass | registry: extra LP 0xf491FA29debC0D12d8F7c57B17995C2346F025AD is INSTITUTIONAL with its credit | tier 3, 5000000 centavos |
| pass | Movva FiatEscrow TAKER_DISPUTE_TIMEOUT | 432000 |
| pass | Movva FiatEscrow MAX_VETTING_FEE_BPS | 10 |
| pass | Movva FiatEscrow MAX_VETTING_FEE_BPS covers the Movva pool's vetting fee | true |
| pass | Movva FiatEscrow Entrypoint / Movva pool | 0xFa3A263bA866Dd12df5eb671C9E5004F7E4d87C8,0xB3C042132A1650E01F61165ebf74c6c5aDa9f080 |
| pass | Movva FiatEscrow BAND_BPS | 300 |
| pass | Movva FiatEscrow lists Movva (reserve, 18, enabled) | 0xE5ECD575F283331675E3734cBffCB70D37833926,18,true |
| pass | Movva FiatEscrow native ETH delisted | false |
| pass | Movva FiatEscrow stand-in USDT not listed | false |
| pass | Movva FiatEscrow ORACLE (constructor; seeds only the delisted native-ETH entry) | 0xE5ECD575F283331675E3734cBffCB70D37833926 |
| pass | Movva OffRampEscrow BAND_BPS | 300 |
| pass | Movva OffRampEscrow lists Movva (reserve, 18, enabled) | 0xE5ECD575F283331675E3734cBffCB70D37833926,18,true |
| pass | Movva OffRampEscrow native ETH delisted | false |
| pass | Movva OffRampEscrow stand-in USDT not listed | false |
| pass | Movva OffRampEscrow ORACLE (constructor; seeds only the delisted native-ETH entry) | 0xE5ECD575F283331675E3734cBffCB70D37833926 |

</details>

### Verifiers: who proves what (11 pass)

<details><summary>11 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | ReclaimZkTlsVerifier provesBankSession | true |
| pass | zktls witnesses + threshold | true |
| pass | zktls endpointCount | 4 |
| pass | zktls endpoint pix-received: a received page (N-08), txid-bound true (M-03, N-13) | 1,true |
| pass | zktls endpoint pix-received (rails, prefix) | 2,https://api.banco-lp.example/ |
| pass | zktls endpoint pix-sent: a sent page (N-08), txid-bound false (M-03, N-13) | 2,false |
| pass | zktls endpoint pix-sent (rails, prefix) | 2,https://api.banco-lp.example/ |
| pass | zktls endpoint boleto-received: a received page (N-08), txid-bound true (M-03, N-13) | 1,true |
| pass | zktls endpoint boleto-received (rails, prefix) | 4,https://api.banco-lp.example/ |
| pass | zktls endpoint boleto-paid: a sent page (N-08), txid-bound false (M-03, N-13) | 2,false |
| pass | zktls endpoint boleto-paid (rails, prefix) | 4,https://api.banco-lp.example/ |

</details>

### Prices: Chainlink freshness and the Pyth leg (1 pass, 8 expected)

<details><summary>9 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | Chainlink USDC/USD fresh for its max age | 99978337 (8 dp), 61224 s old, max 90000 |
| expected | Pyth FX.USD/BRL on Sepolia | publishTime 1792529999, 536809 s old at block 12002045; core session closed |
| expected | Movva FX leg brlCentsPerUnit (the rate) | StaleRate(1792529999) - Pyth's FX.USD/BRL is stale |
| expected | Movva FX leg brlCentsPerUnitForBand | StaleRate(1792529999) - Pyth's FX.USD/BRL is stale |
| expected | Movva band adapter brlCentsPerUnit | StaleRate(1792529999) - Pyth's FX.USD/BRL is stale |
| expected | reserve brlPerUsdtE18 (mint/redeem rate) | StaleRate(1792529999) - Pyth's FX.USD/BRL is stale |
| expected | reserve bandBrlPerUsdtE18 (Movva band) | StaleRate(1792529999) - Pyth's FX.USD/BRL is stale |
| expected | reserve brlCentsPerUnit (the Movva pair's band) | StaleRate(1792529999) - Pyth's FX.USD/BRL is stale |
| expected | reserve harvestableYield (the yield above max(principal, target)) | StaleRate(1792529999) - Pyth's FX.USD/BRL is stale |

</details>

### Bytecode: each address runs this commit's build (42 pass)

<details><summary>42 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | every source file the deployed contracts were compiled from is the file on disk (keccak256 in the build metadata) | 93 files |
| pass | the commit is clean for every build input | 6bcac7b992176f969c09c3991618be01bf4c7e8e, tree clean |
| pass | no build input changed during the run | HEAD moved from 6bcac7b992176f969c09c3991618be01bf4c7e8e to 50ec43e25691b59883bac1d81d68b8f453f8fd5e; the 31 file(s) that differ (deployments/sepolia-movva-v5-permissionless.json, deployments/sepolia-movva-v5-permissionless.rehearsal.json, deployments/sepolia-movva-v5-permissionless/etherscan-verify.sh, deployments/sepolia-movva-v5-rail.json, deployments/sepolia-movva-v5-rail/VERIFICATION.md, depl |
| pass | Privacy Pools Entrypoint (proxy) runs the build's ERC1967Proxy | 0xFa3A263bA866Dd12df5eb671C9E5004F7E4d87C8: 122 bytes, identical |
| pass | Privacy Pools Entrypoint (proxy): creation code is the build's, followed by its constructor arguments | tx 0x29d2459a3bc5e4d020410e4a631d029e0ed3ffd67ca90c86a13a84f808e8d61a (createx), 192 bytes of arguments |
| pass | Entrypoint implementation runs the build's Entrypoint | 0xF8cF00E698c2D53ee900b06BA9285D6b9B148692: 13490 bytes, identical outside 3 immutable site(s) (96 bytes masked) |
| pass | Entrypoint implementation: creation code is the build's, followed by its constructor arguments | tx 0x6ceb2fcc8d82fa13d43325c1a9ae3266599c56c42c9576ca64e1934aafc366cb (createx), 0 bytes of arguments |
| pass | Withdrawal Groth16 verifier runs the build's WithdrawalVerifier | 0x59f80dEBc22E4F9B0f37Ba0251303e11Fe9e9616: 1947 bytes, identical |
| pass | Withdrawal Groth16 verifier: creation code is the build's, followed by its constructor arguments | tx 0xf5ae54cd0040c08c8e959b7fc9a33d3964f7514b1ec4aa5e5be3293cdfa6f40c (createx), 0 bytes of arguments |
| pass | Ragequit (commitment) Groth16 verifier runs the build's CommitmentVerifier | 0xfEb764A2d109f0B3F4868Ff7609b1f30397fCA84: 1582 bytes, identical |
| pass | Ragequit (commitment) Groth16 verifier: creation code is the build's, followed by its constructor arguments | tx 0x7c3675be8f6833f26f07e73b4d0148d221694639f33473bf387ce6e2792af0c8 (createx), 0 bytes of arguments |
| pass | ETH Privacy Pool (upstream's; unused by the product) runs the build's PrivacyPoolSimple | 0x6C8e74582f738B8327d4432b4238f4b0c2347116: 7378 bytes, identical outside 12 immutable site(s) (384 bytes masked) |
| pass | ETH Privacy Pool (upstream's; unused by the product): creation code is the build's, followed by its constructor arguments | tx 0xc2b2d917a9b2ca2680d05f018fe16e05b706a7a0ecc14ffcd999f3b7acf0a8cf (createx), 96 bytes of arguments |
| pass | PoseidonT3 library runs the build's PoseidonT3 | 0x8ffdA7Ed8B4aD98C2C34f54B76821711F4a6f2C5: 23522 bytes, identical |
| pass | PoseidonT4 library runs the build's PoseidonT4 | 0xe393dd7287Db9982e6f845824854Baf8b8e823AF: 12584 bytes, identical |
| pass | Stand-in USDT (OwnedTetherLike) runs the build's OwnedTetherLike | 0xC427DcC3Fd4CB32fBD3Df12BEbc39486aB791A9c: 2786 bytes, identical |
| pass | Stand-in USDT (OwnedTetherLike): creation code is the build's, followed by its constructor arguments | tx 0x9237c743e673cc58d9cb43c642ee1fed5cb5a8c9cfe692571fb9ce79284f8a5e (create), 32 bytes of arguments |
| pass | MovvaReserve runs the build's MovvaReserve | 0xE5ECD575F283331675E3734cBffCB70D37833926: 22962 bytes, identical outside 48 immutable site(s) (1536 bytes masked) |
| pass | MovvaReserve: creation code is the build's, followed by its constructor arguments | tx 0xb63d0b5a92e694c3bfe9d5bfd5da9eef26f8cc08150778743b8525f34c1a998b (create), 640 bytes of arguments |
| pass | Movva (token) runs the build's Movva | 0xB7C02dFb1876Db52941fcaa38515a44F147c7986: 4183 bytes, identical outside 10 immutable site(s) (320 bytes masked) |
| pass | Movva FX leg (PythFxOracle) runs the build's PythFxOracle | 0x0A9c2541c699F2F3308DFB70b9B846D7987bE108: 6098 bytes, identical outside 5 immutable site(s) (160 bytes masked) |
| pass | Movva FX leg (PythFxOracle): creation code is the build's, followed by its constructor arguments | tx 0xbfb8bdd74c0f519a71b307c8a2e7d1427a6853f34fcec282cadfde5fc0e9a8f9 (create), 224 bytes of arguments |
| pass | Movva band adapter (ScaledFxBandOracle) runs the build's ScaledFxBandOracle | 0x46AF143C878918ceD813C9B3C2Cbee4aEDf84dbC: 706 bytes, identical outside 2 immutable site(s) (64 bytes masked) |
| pass | Movva band adapter (ScaledFxBandOracle): creation code is the build's, followed by its constructor arguments | tx 0xb3800cdc53fea074b66703c2e9ed11edd2d7102cb2decbea2d84f43df5d02754 (create), 32 bytes of arguments |
| pass | FeeSplitter runs the build's FeeSplitter | 0x48c00e0222a674a9d920482538d97928A870016D: 5284 bytes, identical outside 8 immutable site(s) (256 bytes masked) |
| pass | FeeSplitter: creation code is the build's, followed by its constructor arguments | tx 0x300aeb161f3b5cb5c278dda524b6182fcff7c563a171cb5591ecd37519c44671 (create), 160 bytes of arguments |
| pass | NodeRewards runs the build's NodeRewards | 0x2b9a9F186414665468FBE68eE5cF2344e820Aa05: 9878 bytes, identical outside 23 immutable site(s) (736 bytes masked) |
| pass | NodeRewards: creation code is the build's, followed by its constructor arguments | tx 0x5e53b1859b34966c6c258b7d51df928ed8b1529becd63f58155c532ccdd1beed (create), 192 bytes of arguments |
| pass | Movva Privacy Pool runs the build's PrivacyPoolComplex | 0xB3C042132A1650E01F61165ebf74c6c5aDa9f080: 7720 bytes, identical outside 14 immutable site(s) (448 bytes masked) |
| pass | Movva Privacy Pool: creation code is the build's, followed by its constructor arguments | tx 0x08297f8d1589d560d2ce1d55c72a79409eaa7963f0805f6a00b5f1ebbaca929e (createx), 128 bytes of arguments |
| pass | Entrypoint owner (TimelockController, 7 days) runs the build's EntrypointTimelock | 0x640ce45e8CBadCB7671Df7D98Cb8c085764C2C86: 6550 bytes, identical |
| pass | Entrypoint owner (TimelockController, 7 days): creation code is the build's, followed by its constructor arguments | tx 0xab14481f3938c26f28831bbd721d4671a97a04e28f2131b2664a401dad467d36 (create), 352 bytes of arguments |
| pass | AspRootQuorum (ASP postman, 2 of 3) runs the build's AspRootQuorum | 0xC12e3DD76faDef119C8A8691959375948E4ea3a1: 2566 bytes, identical outside 7 immutable site(s) (224 bytes masked) |
| pass | AspRootQuorum (ASP postman, 2 of 3): creation code is the build's, followed by its constructor arguments | tx 0x17aa8b6204d049a2af3ef0a3567a8a48db8abeffa2b1f5b2c1c3d9a4db971ac8 (create), 256 bytes of arguments |
| pass | LPRegistry runs the build's LPRegistry | 0xf182Eb04AbA75452CE5F4c400B0742C2f0abc7e2: 10151 bytes, identical outside 3 immutable site(s) (96 bytes masked) |
| pass | LPRegistry: creation code is the build's, followed by its constructor arguments | tx 0x5c37982a6aa2429098e28d545a02ee323333f76cf235717ed76cb65792e3737e (create), 64 bytes of arguments |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED) runs the build's ReclaimZkTlsVerifier | 0x1bE9d1Dbeb61B2815287de8eDA85B30EB1917F9d: 17293 bytes, identical outside 3 immutable site(s) (96 bytes masked) |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): creation code is the build's, followed by its constructor arguments | tx 0x730693b289672cb7cd346b24b1b285b369038a44d099b19714abd3ee0a939a96 (create), 896 bytes of arguments |
| pass | FiatEscrow (Movva on-ramp) runs the build's FiatEscrow | 0x1fa7a70DA69f9Aa8A8074D939962E9187a102c39: 23853 bytes, identical outside 29 immutable site(s) (928 bytes masked) |
| pass | FiatEscrow (Movva on-ramp): creation code is the build's, followed by its constructor arguments | tx 0x49c19ad57c45428a5687c7f3e69dd8ed3393a8744b8e8cf27c4bcd0fec7ea74e (create), 320 bytes of arguments |
| pass | OffRampEscrow (Movva off-ramp) runs the build's OffRampEscrow | 0x8cB7DDDaac7Fa98f747DF0553F3C7E375936499E: 18886 bytes, identical outside 23 immutable site(s) (736 bytes masked) |
| pass | OffRampEscrow (Movva off-ramp): creation code is the build's, followed by its constructor arguments | tx 0xccd06a6d316754f4b4a2c278bd7b4f9e84112dbf4b98c1e73dd31fe795f155fb (create), 192 bytes of arguments |

</details>

### Etherscan readiness (dry run, nothing submitted) (21 pass)

<details><summary>21 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | Privacy Pools Entrypoint (proxy): the verify-contract input recompiles to the code at the address | 8 sources, runs 10000, bytecodeHash none: runtime exact, creation code and arguments equal the creation transaction |
| pass | Entrypoint implementation: the verify-contract input recompiles to the code at the address | 27 sources, runs 10000, bytecodeHash none: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | Withdrawal Groth16 verifier: the verify-contract input recompiles to the code at the address | 1 sources, runs 10000, bytecodeHash none: runtime exact, creation code and arguments equal the creation transaction |
| pass | Ragequit (commitment) Groth16 verifier: the verify-contract input recompiles to the code at the address | 1 sources, runs 10000, bytecodeHash none: runtime exact, creation code and arguments equal the creation transaction |
| pass | ETH Privacy Pool (upstream's; unused by the product): the verify-contract input recompiles to the code at the address | 15 sources, runs 10000, bytecodeHash none: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | PoseidonT3 library: the verify-contract input recompiles to the code at the address | 1 sources, runs 10000, bytecodeHash none: runtime exact |
| pass | PoseidonT4 library: the verify-contract input recompiles to the code at the address | 1 sources, runs 10000, bytecodeHash none: runtime exact |
| pass | Stand-in USDT (OwnedTetherLike): the verify-contract input recompiles to the code at the address | 1 sources, runs 200, bytecodeHash ipfs: runtime exact, creation code and arguments equal the creation transaction |
| pass | MovvaReserve: the verify-contract input recompiles to the code at the address | 37 sources, runs 200, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | Movva (token): the verify-contract input recompiles to the code at the address | 20 sources, runs 200, bytecodeHash ipfs: runtime exact-except-immutables |
| pass | Movva FX leg (PythFxOracle): the verify-contract input recompiles to the code at the address | 6 sources, runs 200, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | Movva band adapter (ScaledFxBandOracle): the verify-contract input recompiles to the code at the address | 3 sources, runs 200, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | FeeSplitter: the verify-contract input recompiles to the code at the address | 11 sources, runs 200, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | NodeRewards: the verify-contract input recompiles to the code at the address | 17 sources, runs 200, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | Movva Privacy Pool: the verify-contract input recompiles to the code at the address | 21 sources, runs 10000, bytecodeHash none: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | Entrypoint owner (TimelockController, 7 days): the verify-contract input recompiles to the code at the address | 13 sources, runs 200, bytecodeHash ipfs: runtime exact, creation code and arguments equal the creation transaction |
| pass | AspRootQuorum (ASP postman, 2 of 3): the verify-contract input recompiles to the code at the address | 1 sources, runs 200, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | LPRegistry: the verify-contract input recompiles to the code at the address | 4 sources, runs 200, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): the verify-contract input recompiles to the code at the address | 3 sources, runs 200, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | FiatEscrow (Movva on-ramp): the verify-contract input recompiles to the code at the address | 9 sources, runs 200, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | OffRampEscrow (Movva off-ramp): the verify-contract input recompiles to the code at the address | 8 sources, runs 200, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |

</details>

### Privileges: roles, gates, proxies (112 pass)

<details><summary>112 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | Privacy Pools Entrypoint (proxy): every state-changing function classified | 15 functions in the ABI, all in the catalog |
| pass | Privacy Pools Entrypoint (proxy): a stranger is refused by every gated function | 11 gated functions, each refused with its own error |
| pass | Privacy Pools Entrypoint (proxy): EIP-1967 implementation is the recorded one; admin and beacon slots empty | implementation 0xF8cF00E698c2D53ee900b06BA9285D6b9B148692, admin empty, beacon empty |
| pass | Entrypoint: OWNER_ROLE held by the recorded timelock alone (every owner action waits its delay) | 0x640ce45e8CBadCB7671Df7D98Cb8c085764C2C86 |
| pass | Entrypoint: the deployer passes none of its 8 owner functions | refused by every one |
| pass | Entrypoint: no DEFAULT_ADMIN_ROLE holder | none |
| pass | Entrypoint: ASP_POSTMAN held by the postman alone | 0xC12e3DD76faDef119C8A8691959375948E4ea3a1 |
| pass | Entrypoint: no role beyond OWNER_ROLE, ASP_POSTMAN and DEFAULT_ADMIN_ROLE was ever granted | none |
| pass | Entrypoint implementation: every state-changing function classified | 15 functions in the ABI, all in the catalog |
| pass | Entrypoint implementation: a stranger is refused by every gated function | 11 gated functions, each refused with its own error |
| pass | Entrypoint implementation: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | Entrypoint implementation: initializers disabled (nobody can initialize it and take its roles) | Initializable version 18446744073709551615 |
| pass | Withdrawal Groth16 verifier: every state-changing function classified | 0 functions in the ABI, all in the catalog |
| pass | Withdrawal Groth16 verifier: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | Ragequit (commitment) Groth16 verifier: every state-changing function classified | 0 functions in the ABI, all in the catalog |
| pass | Ragequit (commitment) Groth16 verifier: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | ETH Privacy Pool (upstream's; unused by the product): every state-changing function classified | 4 functions in the ABI, all in the catalog |
| pass | ETH Privacy Pool (upstream's; unused by the product): a stranger is refused by every gated function | 2 gated functions, each refused with its own error |
| pass | ETH Privacy Pool (upstream's; unused by the product): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | PoseidonT3 library: every state-changing function classified | 0 functions in the ABI, all in the catalog |
| pass | PoseidonT3 library: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | PoseidonT4 library: every state-changing function classified | 0 functions in the ABI, all in the catalog |
| pass | PoseidonT4 library: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | Stand-in USDT (OwnedTetherLike): every state-changing function classified | 9 functions in the ABI, all in the catalog |
| pass | Stand-in USDT (OwnedTetherLike): a stranger is refused by every gated function | 5 gated functions, each refused with its own error |
| pass | Stand-in USDT (OwnedTetherLike): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | MovvaReserve: every state-changing function classified | 30 functions in the ABI, all in the catalog |
| pass | MovvaReserve: a stranger is refused by every gated function | 26 gated functions, each refused with its own error |
| pass | MovvaReserve: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | MovvaReserve: no pending scheduled change | none |
| pass | MovvaReserve: ossified; the guardian is kept, and only it and the governor pass pauseMint | guardian 0xd67DDA7D07CAa45d6f8e7C1dD0a170585e6B086c; pauseMint refused for every other probed caller |
| pass | MovvaReserve: ossified (no risk-increasing change can ever run), its governor not the deployer, and the deployer passes none of its 20 governor functions | governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | Movva (token): every state-changing function classified | 6 functions in the ABI, all in the catalog |
| pass | Movva (token): a stranger is refused by every gated function | 2 gated functions, each refused with its own error |
| pass | Movva (token): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | Movva FX leg (PythFxOracle): every state-changing function classified | 8 functions in the ABI, all in the catalog |
| pass | Movva FX leg (PythFxOracle): a stranger is refused by every gated function | 8 gated functions, each refused with its own error |
| pass | Movva FX leg (PythFxOracle): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | Movva FX leg (PythFxOracle): no pending scheduled change | none |
| pass | Movva FX leg (PythFxOracle): ossified (no risk-increasing change can ever run), its governor not the deployer, and the deployer passes none of its 8 governor functions | governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | Movva band adapter (ScaledFxBandOracle): every state-changing function classified | 0 functions in the ABI, all in the catalog |
| pass | Movva band adapter (ScaledFxBandOracle): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | FeeSplitter: every state-changing function classified | 10 functions in the ABI, all in the catalog |
| pass | FeeSplitter: a stranger is refused by every gated function | 9 gated functions, each refused with its own error |
| pass | FeeSplitter: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | FeeSplitter: no pending scheduled change | none |
| pass | FeeSplitter: ossified (no risk-increasing change can ever run), its governor not the deployer, and the deployer passes none of its 9 governor functions | governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | NodeRewards: every state-changing function classified | 14 functions in the ABI, all in the catalog |
| pass | NodeRewards: a stranger is refused by every gated function | 11 gated functions, each refused with its own error |
| pass | NodeRewards: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | NodeRewards: no pending scheduled change | none |
| pass | NodeRewards: ossified (no risk-increasing change can ever run), its governor not the deployer, and the deployer passes none of its 10 governor functions | governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | Movva Privacy Pool: every state-changing function classified | 4 functions in the ABI, all in the catalog |
| pass | Movva Privacy Pool: a stranger is refused by every gated function | 2 gated functions, each refused with its own error |
| pass | Movva Privacy Pool: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | Entrypoint owner (TimelockController, 7 days): every state-changing function classified | 13 functions in the ABI, all in the catalog |
| pass | Entrypoint owner (TimelockController, 7 days): a stranger is refused by every gated function | 9 gated functions, each refused with its own error |
| pass | Entrypoint owner (TimelockController, 7 days): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | AspRootQuorum (ASP postman, 2 of 3): every state-changing function classified | 2 functions in the ABI, all in the catalog |
| pass | AspRootQuorum (ASP postman, 2 of 3): a stranger is refused by every gated function | 2 gated functions, each refused with its own error |
| pass | AspRootQuorum (ASP postman, 2 of 3): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | AspRootQuorum (ASP postman, 2 of 3): its ASPs are exactly the recorded 3 | 0x6f239a1A5818808E63BB6F35A88B9876a79aa973, 0xc8510850c5bF41B52399473F234577B2d8Ef0B16, 0x323574Eb0c63b764F06832f15B21956bb8979FC9 |
| pass | AspRootQuorum (ASP postman, 2 of 3): only its ASPs pass vote | admitted: 0x6f239a1A5818808E63BB6F35A88B9876a79aa973, 0x323574Eb0c63b764F06832f15B21956bb8979FC9, 0xc8510850c5bF41B52399473F234577B2d8Ef0B16 |
| pass | LPRegistry: every state-changing function classified | 18 functions in the ABI, all in the catalog |
| pass | LPRegistry: a stranger is refused by every gated function | 12 gated functions, each refused with its own error |
| pass | LPRegistry: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | LPRegistry: no pending scheduled change | none |
| pass | LPRegistry: ossified (no risk-increasing change can ever run), its governor not the deployer, and the deployer passes none of its 10 governor functions | governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): every state-changing function classified | 13 functions in the ABI, all in the catalog |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): a stranger is refused by every gated function | 13 gated functions, each refused with its own error |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): no pending scheduled change | none |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): ossified (no risk-increasing change can ever run), its governor not the deployer, and the deployer passes none of its 13 governor functions | governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | FiatEscrow (Movva on-ramp): every state-changing function classified | 25 functions in the ABI, all in the catalog |
| pass | FiatEscrow (Movva on-ramp): a stranger is refused by every gated function | 10 gated functions, each refused with its own error |
| pass | FiatEscrow (Movva on-ramp): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | FiatEscrow (Movva on-ramp): no pending scheduled change | none |
| pass | FiatEscrow (Movva on-ramp): ossified (no risk-increasing change can ever run), its governor not the deployer, and the deployer passes none of its 10 governor functions | governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | OffRampEscrow (Movva off-ramp): every state-changing function classified | 19 functions in the ABI, all in the catalog |
| pass | OffRampEscrow (Movva off-ramp): a stranger is refused by every gated function | 10 gated functions, each refused with its own error |
| pass | OffRampEscrow (Movva off-ramp): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | OffRampEscrow (Movva off-ramp): no pending scheduled change | none |
| pass | OffRampEscrow (Movva off-ramp): ossified (no risk-increasing change can ever run), its governor not the deployer, and the deployer passes none of its 10 governor functions | governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | ETH Privacy Pool (upstream's; unused by the product): ENTRYPOINT (immutable) is exactly the recorded set | 0xFa3A263bA866Dd12df5eb671C9E5004F7E4d87C8 |
| pass | Movva Privacy Pool: ENTRYPOINT (immutable) is exactly the recorded set | 0xFa3A263bA866Dd12df5eb671C9E5004F7E4d87C8 |
| pass | Entrypoint owner (TimelockController, 7 days): proposer is exactly the recorded set | 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | Entrypoint owner (TimelockController, 7 days): canceller is exactly the recorded set | 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1, 0xd67DDA7D07CAa45d6f8e7C1dD0a170585e6B086c |
| pass | Entrypoint owner (TimelockController, 7 days): executor is exactly the recorded set | 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | Entrypoint owner (TimelockController, 7 days): admin (DEFAULT_ADMIN_ROLE) is exactly the recorded set | 0x640ce45e8CBadCB7671Df7D98Cb8c085764C2C86 |
| pass | AspRootQuorum (ASP postman, 2 of 3): ASP is exactly the recorded set | 0x6f239a1A5818808E63BB6F35A88B9876a79aa973, 0xc8510850c5bF41B52399473F234577B2d8Ef0B16, 0x323574Eb0c63b764F06832f15B21956bb8979FC9 |
| pass | AspRootQuorum (ASP postman, 2 of 3): ENTRYPOINT (immutable) is exactly the recorded set | 0xFa3A263bA866Dd12df5eb671C9E5004F7E4d87C8 |
| pass | MovvaReserve: guardian is exactly the recorded set | 0xd67DDA7D07CAa45d6f8e7C1dD0a170585e6B086c |
| pass | MovvaReserve: gateway is exactly the recorded set | 0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C, 0xf491FA29debC0D12d8F7c57B17995C2346F025AD |
| pass | MovvaReserve: yield recipient (payee) is exactly the recorded set | 0x622F626F912AD25d36D9B8F48907Ac941F755ACb |
| pass | MovvaReserve: fee recipient (payee) is exactly the recorded set | 0x48c00e0222a674a9d920482538d97928A870016D |
| pass | MovvaReserve: yield vault is exactly the recorded set | none |
| pass | Movva (token): minter (RESERVE, immutable) is exactly the recorded set | 0xE5ECD575F283331675E3734cBffCB70D37833926 |
| pass | FeeSplitter: treasury (payee) is exactly the recorded set | 0x622F626F912AD25d36D9B8F48907Ac941F755ACb |
| pass | FeeSplitter: rewards (payee) is exactly the recorded set | 0x2b9a9F186414665468FBE68eE5cF2344e820Aa05 |
| pass | NodeRewards: registry (reports settlements) is exactly the recorded set | 0xf182Eb04AbA75452CE5F4c400B0742C2f0abc7e2 |
| pass | NodeRewards: excluded LP is exactly the recorded set | none |
| pass | LPRegistry: escrow is exactly the recorded set | 0x1fa7a70DA69f9Aa8A8074D939962E9187a102c39, 0x8cB7DDDaac7Fa98f747DF0553F3C7E375936499E |
| pass | LPRegistry: rewards hook is exactly the recorded set | 0x2b9a9F186414665468FBE68eE5cF2344e820Aa05 |
| pass | LPRegistry: LP (tier > NONE) is exactly the recorded set | 0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C, 0xf491FA29debC0D12d8F7c57B17995C2346F025AD |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): witness is exactly the recorded set | 0x05EfF3D8e0ad59Aa8abFd94E0b08402ec0850Fbf, 0x8771D8B0038061D7872e4c2C69cD63F54380CBAb, 0x72C1a86B73Ca01Fec5e07160AE14a32849eE5214 |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): bank endpoint (providerHash) is exactly the recorded set | 0xb54d2a19bba3a502dc449c083cd2579885618e4e0487435aae1673f06baf0c05, 0xd8d90d629dc91348bf69c3c5148cd5bf1efdc99220a15a6f42d6ad42eeb2bb20, 0x8259a0510dbf7425215eada80e9a8fcc1bac48d4e24e3cea67b5185b482abf77, 0xf02c2badc915c0c690ccba5dd00202b6efcc3d49a1c1197db4026f075aaddc1a |
| pass | FiatEscrow (Movva on-ramp): arbitrator is exactly the recorded set | 0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7 |
| pass | FiatEscrow (Movva on-ramp): allowed verifier is exactly the recorded set | 0x1bE9d1Dbeb61B2815287de8eDA85B30EB1917F9d |
| pass | FiatEscrow (Movva on-ramp): listed asset (enabled) is exactly the recorded set | 0xB7C02dFb1876Db52941fcaa38515a44F147c7986 |
| pass | OffRampEscrow (Movva off-ramp): arbitrator is exactly the recorded set | 0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7 |
| pass | OffRampEscrow (Movva off-ramp): allowed verifier is exactly the recorded set | 0x1bE9d1Dbeb61B2815287de8eDA85B30EB1917F9d |
| pass | OffRampEscrow (Movva off-ramp): listed asset (enabled) is exactly the recorded set | 0xB7C02dFb1876Db52941fcaa38515a44F147c7986 |

</details>

## Privileges

Read from the chain at block 12002046, after `--finalize`; the inventory before it was taken at block 12002002. For every contract: who holds each role, what the role can and cannot do (as the contract's code says, with the lines), and which state-changing functions the chain admits each caller to. The function list is the ABI of the build, so a function nobody classified would show as UNKNOWN and fail the checks: 0 do.

Probing: every state-changing function was `eth_call`ed with zero arguments from a stranger (`0x21f474a941692095F3122E1C82b9f24EC237f975`, holds nothing), the deployer and every current holder. "Refused" means the contract's own authorization error; "admitted" means the call got past the gate (it may then revert on the zero arguments). Nothing was sent.

### What --finalize renounced

- MovvaReserve (0xE5ECD575F283331675E3734cBffCB70D37833926): ossified; governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 keeps the brakes only.
- Movva FX leg (PythFxOracle) (0x0A9c2541c699F2F3308DFB70b9B846D7987bE108): ossified; governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 keeps the brakes only.
- FeeSplitter (0x48c00e0222a674a9d920482538d97928A870016D): ossified; governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 keeps the brakes only.
- NodeRewards (0x2b9a9F186414665468FBE68eE5cF2344e820Aa05): ossified; governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 keeps the brakes only.
- LPRegistry (0xf182Eb04AbA75452CE5F4c400B0742C2f0abc7e2): ossified; governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 keeps the brakes only.
- ReclaimZkTlsVerifier (PIX, boleto, TED) (0x1bE9d1Dbeb61B2815287de8eDA85B30EB1917F9d): ossified; governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 keeps the brakes only.
- FiatEscrow (Movva on-ramp) (0x1fa7a70DA69f9Aa8A8074D939962E9187a102c39): ossified; governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 keeps the brakes only.
- OffRampEscrow (Movva off-ramp) (0x8cB7DDDaac7Fa98f747DF0553F3C7E375936499E): ossified; governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 keeps the brakes only.
- deployments/sepolia-movva-v5-permissionless.json ramp.movvaOnramp (0xC4D0c445e518193730F478e15ce43837831bc099): ossified; governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 keeps the brakes only.
- deployments/sepolia-movva-v5-permissionless.json ramp.movvaOfframp (0x85adc96d0F724aD83f91a0454ab976Bb32a8Be2d): ossified; governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 keeps the brakes only.
- deployments/sepolia-v5-hedge-sleeve.json subWallet (0xb05a31Ea3A43aC6E1523128D04AB8c1e4Bc8823a): ossified; governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 keeps the brakes only.
- Before renouncing anything: the inventory at block 12002002 passed 73/73 privilege checks and 29/29 exact-set checks against the record.
- Entrypoint ASP_POSTMAN: the recorded AspRootQuorum 0xC12e3DD76faDef119C8A8691959375948E4ea3a1 alone, running this build's code (2566 bytes, identical outside 7 immutable site(s) (224 bytes masked)), 2 of 3 ASPs, bound to this Entrypoint.
- MovvaReserve yield recipient 0x622F626F912AD25d36D9B8F48907Ac941F755ACb: after --finalize the only payee of harvestYield, for good (no governor will remain to move it).
- deployments/sepolia-v5-hedge-sleeve.json subWallet (0xb05a31Ea3A43aC6E1523128D04AB8c1e4Bc8823a): keeper 0x4D0dF9bB92883cf5584c812EB84AABA55d688853 stays: an EOA by design, equal to its record; it acts only inside the sleeve's immutable bounds and pays only TREASURY.
- deployments/sepolia-v5-hedge-sleeve.json venue (0x40Fc13a5cE011b4aD50d71A8c520B47d2cF66A77): venue operator 0x9F65C8910d741427Df73B500724Eb4D36b46996f stays: an EOA by design (a simulator's price and funding feed; not governed, no delay to renounce).
- Chain scan (GovernorTransferred / SetupCompleted since block 12001585): 11 governed contract(s) found, none outside the 11 renounced here.
- Owned contracts (OwnershipTransferred / OwnerChanged since block 12001585): 0xC427DcC3Fd4CB32fBD3Df12BEbc39486aB791A9c owned by the governor Safe 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1. Finalizing does not change an owner; each stays the Safe's (M-19).
- Entrypoint fees: 0 MOVVA units held now; they stay collectable by the TimelockController 0x640ce45e8CBadCB7671Df7D98Cb8c085764C2C86 (withdrawFees(MOVVA, treasury), a 7-day operation the Safe proposes). The owner step withdrew what it held before the hand-over: nothing.
- MovvaReserve guardian 0xd67DDA7D07CAa45d6f8e7C1dD0a170585e6B086c: kept. It can pause minting, pull USDT from the yield vault back into the reserve and pause vault deposits, and nothing else (N-03, N-28).
- Entrypoint OWNER_ROLE: kept by the TimelockController 0x640ce45e8CBadCB7671Df7D98Cb8c085764C2C86 (7 days; proposer, canceller and executor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1). The deployer holds no Entrypoint role.
- Entrypoint ASP_POSTMAN: kept by 0xC12e3DD76faDef119C8A8691959375948E4ea3a1. It posts the roots every private withdrawal needs; only a 7-day timelock operation could replace it.
- 11 DelayedGovernance contracts (8 of the rail, 3 of its siblings): 11 ossified now; setup completed here on 0. Each keeps the governor Safe for its instant, risk-reducing changes alone (N-04). A paused sleeve stays paused: resume() is a delayed change (N-20).

**How.** Each `DelayedGovernance` governor was handed to `0x000000000000000000000000000000000000dEaD` with `transferGovernor` (`contracts/common/DelayedGovernance.sol:167`). That transfer is one step and instant, and refuses only `address(0)`. So it is a real renunciation, not a pending two-step one. No key is known for `0x000000000000000000000000000000000000dEaD`, and no contract can be deployed there. The Entrypoint's OWNER_ROLE was given up with `renounceRole`. Every role's admin is OWNER_ROLE (`protocol/contracts/src/contracts/Entrypoint.sol:81`), so nobody can grant any role again. No contract change was needed for any of it.

**What that makes impossible.** Each item below is a function only the renounced key could call:

- upgrading the Entrypoint, or adding, removing, reconfiguring or winding down a pool (`protocol/contracts/src/contracts/Entrypoint.sol:308`, `protocol/contracts/src/contracts/Entrypoint.sol:183`, `protocol/contracts/src/contracts/Entrypoint.sol:256`).
- recovering vetting fees. Every deposit's vetting fee (each pool's `vettingFeeBPS`, in the Entrypoint checks above) stays in the Entrypoint for good: only OWNER_ROLE can withdraw them (`protocol/contracts/src/contracts/Entrypoint.sol:264`, `protocol/contracts/src/contracts/Entrypoint.sol:332`).
- raising a pool's relay-fee cap. A relayer quote above it reverts `RelayFeeGreaterThanMax` for good. Users can still withdraw directly, or ragequit (`protocol/contracts/src/contracts/Entrypoint.sol:157`).
- replacing or removing the ASP postman. Its admin role is OWNER_ROLE. The postman is the AspRootQuorum 0xC12e3DD76faDef119C8A8691959375948E4ea3a1, 2 of 3 fixed ASPs with no owner and no setter, so neither the postman nor its ASP set can ever change (`protocol/contracts/src/contracts/Entrypoint.sol:82`).
- revoking a leaked zkTLS witness key. A quorum of leaked keys can prove payments that never happened, and each such proof releases an order's crypto (`contracts/ramp/ReclaimZkTlsVerifier.sol:752`).
- revoking a leaked arbitrator key. FiatEscrow's own NatSpec says a stolen arbitrator key can drain every offer, one disputed order at a time. The one defence it names is revoking the key within RULING_DELAY (`contracts/ramp/FiatEscrow.sol:1026`, `contracts/ramp/FiatEscrow.sol:1233`, `contracts/ramp/OffRampEscrow.sol:722`).
- revoking a verifier or a bank endpoint, delisting an asset, or lowering a cap on an escrow (`contracts/ramp/FiatEscrow.sol:1225`, `contracts/ramp/ReclaimZkTlsVerifier.sol:783`, `contracts/ramp/FiatEscrow.sol:548`).
- suspending a misbehaving LP, admitting a new one, or opening Phase B or C. The network stays in its current phase with its current LPs (`contracts/ramp/LPRegistry.sol:252`, `contracts/ramp/LPRegistry.sol:221`).
- resuming Movva minting after the guardian pauses it. A pause becomes permanent (`contracts/movva/MovvaReserve.sol:972`).
- adding or removing a Movva gateway. Only gateways redeem Movva for USDT, so if every gateway key is lost nobody can redeem again (`contracts/movva/MovvaReserve.sol:813`, `contracts/movva/MovvaReserve.sol:683`).
- repointing the reserve's oracle when Pyth retires the feed. Minting and redeeming would stop at a dead feed for good (`contracts/movva/MovvaReserve.sol:906`).
- changing the yield recipient or the yield vault. The yield recipient fixed at --finalize is the only address harvestYield ever pays, and the vault the principal is invested in stays the source for good (pulling it back into the reserve needs the governor too) (`contracts/movva/MovvaReserve.sol:831`, `contracts/movva/MovvaReserve.sol:919`, `contracts/movva/MovvaReserve.sol:935`).
- voiding farmed volume or excluding an LP from node-provider rewards (`contracts/ramp/NodeRewards.sol:449`, `contracts/ramp/NodeRewards.sol:437`).
- executing any change scheduled before the handover (`contracts/common/DelayedGovernance.sol:206`).

Every "instant" brake in `docs/runbook-mainnet-deploy.md` ("If something is wrong after deployment") is one of these. After `--finalize` that table has no one to act on it. The contracts themselves never relied on a governor for users to exit: escrow timeouts refund without permission, and ragequit needs no service.

### What remains, and why

| Contract | Role | Held by |
|---|---|---|
| Privacy Pools Entrypoint (proxy) | OWNER_ROLE | `0x640ce45e8CBadCB7671Df7D98Cb8c085764C2C86` |
| Privacy Pools Entrypoint (proxy) | ASP_POSTMAN | `0xC12e3DD76faDef119C8A8691959375948E4ea3a1` |
| Stand-in USDT (OwnedTetherLike) | owner | `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1` |
| MovvaReserve | governor | `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1` |
| MovvaReserve | guardian | `0xd67DDA7D07CAa45d6f8e7C1dD0a170585e6B086c` |
| MovvaReserve | gateway | `0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C`, `0xf491FA29debC0D12d8F7c57B17995C2346F025AD` |
| Movva FX leg (PythFxOracle) | governor | `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1` |
| FeeSplitter | governor | `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1` |
| NodeRewards | governor | `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1` |
| Entrypoint owner (TimelockController, 7 days) | proposer | `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1` |
| Entrypoint owner (TimelockController, 7 days) | canceller | `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`, `0xd67DDA7D07CAa45d6f8e7C1dD0a170585e6B086c` |
| Entrypoint owner (TimelockController, 7 days) | executor | `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1` |
| AspRootQuorum (ASP postman, 2 of 3) | ASP | `0x6f239a1A5818808E63BB6F35A88B9876a79aa973`, `0xc8510850c5bF41B52399473F234577B2d8Ef0B16`, `0x323574Eb0c63b764F06832f15B21956bb8979FC9` |
| LPRegistry | governor | `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1` |
| LPRegistry | LP (tier > NONE) | `0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C`, `0xf491FA29debC0D12d8F7c57B17995C2346F025AD` |
| ReclaimZkTlsVerifier (PIX, boleto, TED) | governor | `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1` |
| ReclaimZkTlsVerifier (PIX, boleto, TED) | witness | `0x05EfF3D8e0ad59Aa8abFd94E0b08402ec0850Fbf`, `0x8771D8B0038061D7872e4c2C69cD63F54380CBAb`, `0x72C1a86B73Ca01Fec5e07160AE14a32849eE5214` |
| FiatEscrow (Movva on-ramp) | governor | `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1` |
| FiatEscrow (Movva on-ramp) | arbitrator | `0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7` |
| OffRampEscrow (Movva off-ramp) | governor | `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1` |
| OffRampEscrow (Movva off-ramp) | arbitrator | `0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7` |

Why each remains:

- **ASP postman** (Entrypoint `ASP_POSTMAN`). A private withdrawal must prove membership in the latest association-set root (`protocol/contracts/src/contracts/PrivacyPool.sol:59`), and only the postman posts roots (`protocol/contracts/src/contracts/Entrypoint.sol:93`). Without it, new deposits could only leave by ragequit (`protocol/contracts/src/contracts/PrivacyPool.sol:132`). It can admit or leave out deposits; it cannot move funds. The postman is the AspRootQuorum `0xC12e3DD76faDef119C8A8691959375948E4ea3a1`: a root is posted only when 2 of its 3 fixed ASPs (`0x6f239a1A5818808E63BB6F35A88B9876a79aa973`, `0xc8510850c5bF41B52399473F234577B2d8Ef0B16`, `0x323574Eb0c63b764F06832f15B21956bb8979FC9`) vote for it (`contracts/AspRootQuorum.sol:139`). The ASPs are the keys that remain; the set cannot change.
- **Arbitrator**, on each escrow. Some disputes no proof can settle: bank downtime, a reversed payment. A ruling reaches only a DISPUTED order and pays one of its two counterparties. A RELEASE needs an arbitrator registered before the dispute (`contracts/ramp/FiatEscrow.sol:1117`). Rulings execute a day after posting (`contracts/ramp/FiatEscrow.sol:307`). With no arbitrator, a dispute can only time out back to the LP (`contracts/ramp/FiatEscrow.sol:1158`).
- **zkTLS witnesses.** They are the proof. Their signatures are what `verifyPayment` checks, and nothing on-chain can replace them.
- **Movva gateways and the yield recipient, and guardian.** Only gateways mint and redeem (`contracts/movva/MovvaReserve.sol:411`): the gateways are the institutional LPs that settle the off-ramp, and a redemption is the only way the reserve's principal leaves. The reserve is principal-locked (client rule, 21 October 2026): it has no hedge path, and only the yield above max(principal, liabilities at the target) leaves, by `harvestYield`, to the yield recipient alone (`contracts/movva/MovvaReserve.sol:759`). The guardian can only pause minting (`contracts/movva/MovvaReserve.sol:966`).
- **LPs** in the registry. Their tier and credit limit bound what each may have at risk.
- **Keepers: none with on-chain power.** The Pyth keeper posts prices to Pyth, which anyone may do. `split`, `sync` and `finalize` are open to anyone.
- **Bound to code, not keys:** Movva's minter (`RESERVE`, immutable), each pool's `ENTRYPOINT` (immutable), the quorum's `ENTRYPOINT`, ASP set and `THRESHOLD` (immutable), and the escrows the registry accepts.
- **Outside this deployment:** Pyth (its own governance can upgrade it), the Chainlink feeds (their proxies are owned by Chainlink), CreateX, and on mainnet Tether's USDT, which can freeze an escrow. These are trusted as they are and not inventoried here.

### Per contract

#### Privacy Pools Entrypoint (proxy)

`0xFa3A263bA866Dd12df5eb671C9E5004F7E4d87C8` - `ERC1967Proxy` running `Entrypoint`, `protocol/contracts/src/contracts/Entrypoint.sol`. Privacy Pools' Entrypoint (upstream 0xbow, UUPS behind an ERC1967Proxy): deposits into and relays withdrawals from every pool, and holds the ASP root. **Holds funds.**

- DEFAULT_ADMIN_ROLE (admin OWNER_ROLE): **nobody**
- OWNER_ROLE (admin OWNER_ROLE): `0x640ce45e8CBadCB7671Df7D98Cb8c085764C2C86`
- ASP_POSTMAN (admin OWNER_ROLE): `0xC12e3DD76faDef119C8A8691959375948E4ea3a1`
- EIP-1967: implementation `0xF8cF00E698c2D53ee900b06BA9285D6b9B148692`, admin `empty`, beacon `empty`

- **OWNER_ROLE** can upgrade the Entrypoint's code; register and remove pools; change a pool's minimum deposit, vetting fee and relay-fee cap; wind a pool down; withdraw every fee the Entrypoint holds, to any address; grant and revoke every role, OWNER_ROLE included. It cannot move pooled notes without an upgrade: a withdrawal needs the note's zero-knowledge proof. With an upgrade it can: the Entrypoint's code relays every withdrawal and holds depositors' ERC-20 approvals, so an upgrade is the one path from this role to users' money. (`node_modules/@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol:92`, `protocol/contracts/src/contracts/Entrypoint.sol:183`, `protocol/contracts/src/contracts/Entrypoint.sol:220`, `protocol/contracts/src/contracts/Entrypoint.sol:239`, `protocol/contracts/src/contracts/Entrypoint.sol:256`, `protocol/contracts/src/contracts/Entrypoint.sol:264`, …)
- **ASP_POSTMAN** can publish the association-set root. A private withdrawal must prove membership in the latest root, so the postman decides which deposits may withdraw privately. It cannot move funds, or stop a depositor leaving publicly: ragequit returns a deposit to its original depositor with no root at all. (`protocol/contracts/src/contracts/Entrypoint.sol:93`)
- **DEFAULT_ADMIN_ROLE** can call nothing: no Entrypoint function checks it, and it administers no role (every role's admin is OWNER_ROLE). Listed because AccessControl defines it. It cannot be held by anyone OWNER_ROLE did not grant it to. `initialize` grants it to nobody.

<details><summary>15 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `receive()` | only the Entrypoint (immutable) | - | Accept ETH only from the registered native pool (relayed withdrawals). | not probed (plain ETH transfer) | `protocol/contracts/src/contracts/Entrypoint.sol:298` |
| `deposit(address,uint256,uint256)` | anyone | - | Make an ERC20 deposit into the Privacy Pool <sub>(NatSpec)</sub> | open | `protocol/contracts/src/contracts/Entrypoint.sol:111` |
| `deposit(uint256)` | anyone | - | Make a native asset deposit into the Privacy Pool <sub>(NatSpec)</sub> | open | `protocol/contracts/src/contracts/Entrypoint.sol:111` |
| `grantRole(bytes32,address)` | the role's admin role (OWNER_ROLE, for every role here) (key) | instant | Grant a role. OWNER_ROLE is the admin of OWNER_ROLE, ASP_POSTMAN and DEFAULT_ADMIN_ROLE. | `0x640c…2C86` OWNER_ROLE | `node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol:143` |
| `initialize(address,address)` | nobody: the initializer has run (on the implementation: disabled) | - | Initializes the contract state <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:69` |
| `registerPool(address,address,uint256,uint256,uint256)` | an OWNER_ROLE holder (key) | instant | Register a Privacy Pool in the registry <sub>(NatSpec)</sub> | `0x640c…2C86` OWNER_ROLE | `protocol/contracts/src/contracts/Entrypoint.sol:183` |
| `relay(…)` | anyone carrying a proof the contract's verifier accepts | - | Process a withdrawal <sub>(NatSpec)</sub> | open | `protocol/contracts/src/contracts/Entrypoint.sol:133` |
| `removePool(address)` | an OWNER_ROLE holder (key) | instant | Remove a Privacy Pool from the registry <sub>(NatSpec)</sub> | `0x640c…2C86` OWNER_ROLE | `protocol/contracts/src/contracts/Entrypoint.sol:220` |
| `renounceRole(bytes32,address)` | only for the caller's own role | instant | Give up a role the caller holds (it must name itself). | **nobody** (every probed caller refused) | `node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol:178` |
| `revokeRole(bytes32,address)` | the role's admin role (OWNER_ROLE, for every role here) (key) | instant | Revoke a role from an account. | `0x640c…2C86` OWNER_ROLE | `node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol:158` |
| `updatePoolConfiguration(address,uint256,uint256,uint256)` | an OWNER_ROLE holder (key) | instant | Updates the configuration of a specific pool <sub>(NatSpec)</sub> | `0x640c…2C86` OWNER_ROLE | `protocol/contracts/src/contracts/Entrypoint.sol:239` |
| `updateRoot(uint256,string)` | an ASP_POSTMAN holder (key) | instant | Push a new root to the association root set <sub>(NatSpec)</sub> | `0xC12e…a3a1` ASP_POSTMAN | `protocol/contracts/src/contracts/Entrypoint.sol:93` |
| `upgradeToAndCall(address,bytes)` | an OWNER_ROLE holder (key) | instant | Replace the Entrypoint's code (UUPS; `_authorizeUpgrade` is onlyRole(OWNER_ROLE)). | `0x640c…2C86` OWNER_ROLE | `node_modules/@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol:92` |
| `windDownPool(address)` | an OWNER_ROLE holder (key) | instant | Irreversebly halt deposits from a Privacy Pool <sub>(NatSpec)</sub> | inconclusive (bare revert): `0x640c…2C86` OWNER_ROLE | `protocol/contracts/src/contracts/Entrypoint.sol:256` |
| `withdrawFees(address,address)` | an OWNER_ROLE holder (key) | instant | Withdraw fees from the Entrypoint <sub>(NatSpec)</sub> | inconclusive (bare revert): `0x640c…2C86` OWNER_ROLE | `protocol/contracts/src/contracts/Entrypoint.sol:264` |

</details>

#### Entrypoint implementation

`0xF8cF00E698c2D53ee900b06BA9285D6b9B148692` - `Entrypoint`, `protocol/contracts/src/contracts/Entrypoint.sol`. The Entrypoint's implementation. Its own storage is never initialized (the constructor disables initializers), so no role exists in it, and `upgradeToAndCall` refuses a direct call (onlyProxy). It is code the proxy runs, not a second Entrypoint.

- EIP-1967 slots: empty (not a proxy)
- initializers disabled

<details><summary>15 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `receive()` | only the Entrypoint (immutable) | - | Accept ETH only from the registered native pool (relayed withdrawals). | not probed (plain ETH transfer) | `protocol/contracts/src/contracts/Entrypoint.sol:298` |
| `deposit(address,uint256,uint256)` | anyone | - | Make an ERC20 deposit into the Privacy Pool <sub>(NatSpec)</sub> | open | `protocol/contracts/src/contracts/Entrypoint.sol:111` |
| `deposit(uint256)` | anyone | - | Make a native asset deposit into the Privacy Pool <sub>(NatSpec)</sub> | open | `protocol/contracts/src/contracts/Entrypoint.sol:111` |
| `grantRole(bytes32,address)` | the role's admin role (OWNER_ROLE, for every role here) (key) | instant | Grant a role. OWNER_ROLE is the admin of OWNER_ROLE, ASP_POSTMAN and DEFAULT_ADMIN_ROLE. | **nobody** (every probed caller refused) | `node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol:143` |
| `initialize(address,address)` | nobody: the initializer has run (on the implementation: disabled) | - | Initializes the contract state <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:69` |
| `registerPool(address,address,uint256,uint256,uint256)` | an OWNER_ROLE holder (key) | instant | Register a Privacy Pool in the registry <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:183` |
| `relay(…)` | anyone carrying a proof the contract's verifier accepts | - | Process a withdrawal <sub>(NatSpec)</sub> | open | `protocol/contracts/src/contracts/Entrypoint.sol:133` |
| `removePool(address)` | an OWNER_ROLE holder (key) | instant | Remove a Privacy Pool from the registry <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:220` |
| `renounceRole(bytes32,address)` | only for the caller's own role | instant | Give up a role the caller holds (it must name itself). | **nobody** (every probed caller refused) | `node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol:178` |
| `revokeRole(bytes32,address)` | the role's admin role (OWNER_ROLE, for every role here) (key) | instant | Revoke a role from an account. | **nobody** (every probed caller refused) | `node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol:158` |
| `updatePoolConfiguration(address,uint256,uint256,uint256)` | an OWNER_ROLE holder (key) | instant | Updates the configuration of a specific pool <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:239` |
| `updateRoot(uint256,string)` | an ASP_POSTMAN holder (key) | instant | Push a new root to the association root set <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:93` |
| `upgradeToAndCall(address,bytes)` | an OWNER_ROLE holder (key) | instant | Replace the Entrypoint's code (UUPS; `_authorizeUpgrade` is onlyRole(OWNER_ROLE)). | **nobody** (every probed caller refused) | `node_modules/@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol:92` |
| `windDownPool(address)` | an OWNER_ROLE holder (key) | instant | Irreversebly halt deposits from a Privacy Pool <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:256` |
| `withdrawFees(address,address)` | an OWNER_ROLE holder (key) | instant | Withdraw fees from the Entrypoint <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:264` |

</details>

#### Withdrawal Groth16 verifier

`0x59f80dEBc22E4F9B0f37Ba0251303e11Fe9e9616` - `WithdrawalVerifier`, `protocol/contracts/src/contracts/verifiers/WithdrawalVerifier.sol`. Groth16 verifier for withdrawal proofs: pure code, no state.

- EIP-1967 slots: empty (not a proxy)

No state-changing functions.

#### Ragequit (commitment) Groth16 verifier

`0xfEb764A2d109f0B3F4868Ff7609b1f30397fCA84` - `CommitmentVerifier`, `protocol/contracts/src/contracts/verifiers/CommitmentVerifier.sol`. Groth16 verifier for ragequit (commitment) proofs: pure code, no state.

- EIP-1967 slots: empty (not a proxy)

No state-changing functions.

#### ETH Privacy Pool (upstream's; unused by the product)

`0x6C8e74582f738B8327d4432b4238f4b0c2347116` - `PrivacyPoolSimple`, `protocol/contracts/src/contracts/implementations/PrivacyPoolSimple.sol`. A Privacy Pool for native ETH (upstream 0xbow). No owner; bound to one Entrypoint and one asset at construction. **Holds funds.**

- ENTRYPOINT (immutable): `0xFa3A263bA866Dd12df5eb671C9E5004F7E4d87C8`
- dead = `true` (wound down: no new deposits)
- EIP-1967 slots: empty (not a proxy)

- **ENTRYPOINT** can deposit on a depositor's behalf, and wind the pool down. It cannot withdraw: that needs a note's proof, or its original depositor for ragequit. (`protocol/contracts/src/contracts/PrivacyPool.sol:82`, `protocol/contracts/src/contracts/PrivacyPool.sol:157`)

<details><summary>4 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `deposit(address,uint256,uint256)` | only the Entrypoint (immutable) | - | Deposit funds into the Privacy Pool <sub>(NatSpec)</sub> | `0xFa3A…87C8` ENTRYPOINT | `protocol/contracts/src/contracts/PrivacyPool.sol:82` |
| `ragequit((uint256[2],uint256[2][2],uint256[2],uint256[4]))` | a party to that offer, order, sale, note or reward | - | Publicly withdraw funds to original depositor without exposing secrets <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `protocol/contracts/src/contracts/PrivacyPool.sol:132` |
| `windDown()` | only the Entrypoint (immutable) | - | Irreversibly suspends deposits <sub>(NatSpec)</sub> | `0xFa3A…87C8` ENTRYPOINT | `protocol/contracts/src/contracts/PrivacyPool.sol:157` |
| `withdraw(…)` | anyone carrying a proof the contract's verifier accepts | - | Privately withdraw funds by spending an existing commitment <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `protocol/contracts/src/contracts/PrivacyPool.sol:110` |

</details>

#### PoseidonT3 library

`0x8ffdA7Ed8B4aD98C2C34f54B76821711F4a6f2C5` - `PoseidonT3`, `node_modules/poseidon-solidity/PoseidonT3.sol`. Poseidon hash library (2 inputs): pure code, no state. Linked into the pools.

- EIP-1967 slots: empty (not a proxy)

No state-changing functions.

#### PoseidonT4 library

`0xe393dd7287Db9982e6f845824854Baf8b8e823AF` - `PoseidonT4`, `node_modules/poseidon-solidity/PoseidonT4.sol`. Poseidon hash library (3 inputs): pure code, no state. Linked into the pools.

- EIP-1967 slots: empty (not a proxy)

No state-changing functions.

#### Stand-in USDT (OwnedTetherLike)

`0xC427DcC3Fd4CB32fBD3Df12BEbc39486aB791A9c` - `OwnedTetherLike`, `contracts/test/utils/OwnedTetherLike.sol`. Sepolia stand-in for USDT from v5 on (contracts/test/utils/OwnedTetherLike.sol): Tether's surface, 6 decimals, with the blacklist, pause and fee its owner's - the governor Safe - as Tether's are on mainnet (v3.1 N-15). NOT a mainnet contract.

- owner: `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`
- paused = `false` (transfers refused)
- EIP-1967 slots: empty (not a proxy)

- **owner** can blacklist, pause and set the fee, as Tether can on mainnet. It cannot mint for itself alone (minting is open), or move anyone's balance. (`contracts/test/utils/OwnedTetherLike.sol:76`, `contracts/test/utils/OwnedTetherLike.sol:80`, `contracts/test/utils/OwnedTetherLike.sol:84`, `contracts/test/utils/OwnedTetherLike.sol:70`, `contracts/test/utils/OwnedTetherLike.sol:41`)

<details><summary>9 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `addBlackList(address)` | the contract's owner (key) | - | Blacklist an address. | `0x956E…dCa1` owner | `contracts/test/utils/OwnedTetherLike.sol:76` |
| `approve(address,uint256)` | anyone | - | Set an allowance over the caller's own balance. | open | `contracts/test/utils/OwnedTetherLike.sol:64` |
| `mint(address,uint256)` | anyone | - | Create tokens for anyone: the testers' faucet. | open | `contracts/test/utils/OwnedTetherLike.sol:46` |
| `removeBlackList(address)` | the contract's owner (key) | - | Unblacklist an address. | `0x956E…dCa1` owner | `contracts/test/utils/OwnedTetherLike.sol:80` |
| `setParams(uint256,uint256)` | the contract's owner (key) | - | Set the transfer fee (< 20 bps, < 50 tokens), paid to the owner. | `0x956E…dCa1` owner | `contracts/test/utils/OwnedTetherLike.sol:70` |
| `setPaused(bool)` | the contract's owner (key) | - | Pause or unpause transfers. | `0x956E…dCa1` owner | `contracts/test/utils/OwnedTetherLike.sol:84` |
| `transfer(address,uint256)` | anyone | - | Move the caller's own balance. | open | `contracts/test/utils/OwnedTetherLike.sol:52` |
| `transferFrom(address,address,uint256)` | anyone | - | Move a balance within an allowance its owner gave the caller. | open | `contracts/test/utils/OwnedTetherLike.sol:57` |
| `transferOwnership(address)` | the contract's owner (key) | - | Hand the token's switches to another owner. | `0x956E…dCa1` owner | `contracts/test/utils/OwnedTetherLike.sol:41` |

</details>

#### MovvaReserve

`0xE5ECD575F283331675E3734cBffCB70D37833926` - `MovvaReserve`, `contracts/movva/MovvaReserve.sol`. Holds the USDT backing Movva; mints and redeems Movva for gateways at the Pyth FX rate. Principal-locked (client rule, 21 October 2026): its USDT leaves only by redemption (gateways: the off-ramp's LPs) and, above max(principal, liabilities at the target ratio), by harvestYield to the fixed yield recipient. No hedge path, no sweep, no savings path (no sMovva, no `distribute`). **Holds funds.**

- governor `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`; setup complete; delay 48 h; 0 pending change(s)
- guardian: `0xd67DDA7D07CAa45d6f8e7C1dD0a170585e6B086c`
- gateway: `0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C`, `0xf491FA29debC0D12d8F7c57B17995C2346F025AD`
- gateway council: none
- yield recipient (payee): `0x622F626F912AD25d36D9B8F48907Ac941F755ACb`
- fee recipient (payee): `0x48c00e0222a674a9d920482538d97928A870016D`
- yield vault: none
- mintPaused = `false` (gateways cannot mint)
- vaultDepositsPaused = `false` (no USDT goes into the yield vault)
- supplyCap = `1000000000000000000000000` (most Movva that may exist (1e18 = R$ 1,00))
- principalUsdt = `0` (the cost basis (USDT in by mint and recapitalize, less out by redeem): no harvest goes below it)
- EIP-1967 slots: empty (not a proxy)

- **governor** can add and remove gateways; replace the guardian, the fee recipient and (always after the delay) the yield recipient; change fees (hard caps 1% mint, 1% redeem), collateral ratios (never under 100%), the supply cap, the oracle legs and their max ages, and the yield vault; pull USDT back from the vault into the reserve; pause and resume vault deposits and minting. After setup, every change that adds risk waits GOVERNANCE_DELAY; removing, lowering and pausing are instant. It cannot mint or burn Movva itself, send the reserve's USDT anywhere (principal-locked: pullFromVault only brings it back into the reserve; only redeem and harvestYield pay out), pause redemptions, or pass the hard fee caps. (`contracts/movva/MovvaReserve.sol:813`, `contracts/movva/MovvaReserve.sol:822`, `contracts/movva/MovvaReserve.sol:831`, `contracts/movva/MovvaReserve.sol:837`, `contracts/movva/MovvaReserve.sol:846`, `contracts/movva/MovvaReserve.sol:887`, …)
- **guardian** can pause minting; bring USDT back from the yield vault into the reserve; pause deposits into the vault. At once, and after finalization too (N-03, N-28). It cannot resume minting or vault deposits (governor only), send USDT anywhere but into the reserve, or do anything else. (`contracts/movva/MovvaReserve.sol:966`, `contracts/movva/MovvaReserve.sol:935`, `contracts/movva/MovvaReserve.sol:958`)
- **gateway council** can add a gateway after GOVERNANCE_DELAY, remove one at once, hand itself on or renounce (v3.1 N-02). None unless the deployment names one. It cannot mint, redeem, or touch any other setting. (`contracts/movva/MovvaReserve.sol:860`, `contracts/movva/MovvaReserve.sol:870`, `contracts/movva/MovvaReserve.sol:853`)
- **gateway** can mint Movva for USDT it pays in, and redeem Movva for USDT, at the oracle rate less fees, within the supply cap and the mint collateral floor. The gateways are the institutional LPs that settle the off-ramp: a redemption is the only way the principal leaves. It cannot mint without paying in. A wrong rate inside the oracle bounds is the residual risk the contract names: it is why only contracted gateways mint and redeem. (`contracts/movva/MovvaReserve.sol:633`, `contracts/movva/MovvaReserve.sol:683`, `contracts/movva/MovvaReserve.sol:738`, `contracts/movva/MovvaReserve.sol:745`)

<details><summary>30 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:191` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:151` |
| `councilSetGateway(address,bool)` | the reserve's gateway council (optional; outlives finalization) (key) | - | Council: add a proposed gateway once its delay has passed (and within EXECUTION_WINDOW of that), or remove one - or a proposal - at once. <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `contracts/movva/MovvaReserve.sol:870` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:206` |
| `exitRedeem(uint256,address,uint256)` | anyone | - | The keyless exit: any holder redeems their own Movva, once the gateways have gone quiet or the rate has been unreadable for long enough. See "The keyless exit" in the header. <sub>(NatSpec)</sub> | open | `contracts/movva/MovvaReserve.sol:701` |
| `gatewayHeartbeat()` | a gateway (key) | - | A gateway says it is operating, which keeps the keyless exit's gateway clock from running out. <sub>(NatSpec)</sub> | `0x3ce8…3f5C` gateway<br>`0xf491…25AD` gateway | `contracts/movva/MovvaReserve.sol:738` |
| `harvestYield()` | anyone | - | Anyone: pay `harvestableYield()` to `yieldRecipient`, pulling from the yield vault as needed. <sub>(NatSpec)</sub> | open | `contracts/movva/MovvaReserve.sol:759` |
| `mint(uint256,address,uint256)` | a gateway (key) | - | Gateway only: deposit USDT, receive Movva worth it at the oracle rate, less the mint fee. <sub>(NatSpec)</sub> | `0x3ce8…3f5C` gateway<br>`0xf491…25AD` gateway | `contracts/movva/MovvaReserve.sol:633` |
| `ossify()` | the governor (key) | instant | One-way: no risk-increasing change can ever run again; the instant, risk-reducing ones stay with the governor. See "Ossify" above. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:159` |
| `pauseMint()` | the guardian or the governor (key) | instant | Guardian or governor: stop minting. There is no pause for redemptions; see "Who can stop a redemption" in the header for what can stop one. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor<br>`0xd67D…086c` guardian | `contracts/movva/MovvaReserve.sol:966` |
| `pokeRate()` | anyone | - | Anyone: record whether the rate is readable now. Readable, it becomes `lastGoodRate`; unreadable, it starts the keyless exit's `ORACLE_EXIT_DELAY` clock if that is not running. <sub>(NatSpec)</sub> | open | `contracts/movva/MovvaReserve.sol:726` |
| `proposeGateway(address)` | the reserve's gateway council (optional; outlives finalization) (key) | - | Council: propose a gateway, addable after the governance delay. <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `contracts/movva/MovvaReserve.sol:860` |
| `pullFromVault(uint256)` | the guardian or the governor (key) | instant | Instant, guardian or governor: bring `usdt` back from the vault into the reserve, and stop depositing into it until the governor calls `setVaultDepositsPaused(false)`. `type(uint256).max` redeems e... <sub>(NatSpec)</sub> | `0x956E…dCa1` governor<br>`0xd67D…086c` guardian | `contracts/movva/MovvaReserve.sol:935` |
| `recapitalize(uint256)` | anyone | - | Anyone: add USDT without minting. It becomes principal. <sub>(NatSpec)</sub> | open | `contracts/movva/MovvaReserve.sol:797` |
| `redeem(uint256,address,uint256)` | a gateway (key) | - | Gateway only: burn Movva, receive USDT worth min(1, collateral ratio) of it, less the redeem fee. <sub>(NatSpec)</sub> | `0x3ce8…3f5C` gateway<br>`0xf491…25AD` gateway | `contracts/movva/MovvaReserve.sol:683` |
| `renounceGateway()` | a gateway (key) | - | A gateway removes itself, at once: what an operator does with a leaked key. <sub>(NatSpec)</sub> | `0x3ce8…3f5C` gateway<br>`0xf491…25AD` gateway | `contracts/movva/MovvaReserve.sol:745` |
| `resumeMint()` | the governor (key) | instant | Resume minting. | `0x956E…dCa1` governor | `contracts/movva/MovvaReserve.sol:972` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:179` |
| `setCollateralRatios(uint16,uint16)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | LOWERING a ratio is delayed (it lets value out at less backing); raising is instant. Neither may be below 100%, and the mint floor may not exceed the target. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/movva/MovvaReserve.sol:887` |
| `setFeeRecipient(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Delayed: this address is paid every fee. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/movva/MovvaReserve.sol:837` |
| `setFees(uint16,uint16)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Raising either fee is delayed; lowering is instant. Hard caps apply either way, and the two together never fall below `MIN_ROUND_TRIP_FEE_BPS`. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/movva/MovvaReserve.sol:846` |
| `setGateway(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Adding a gateway waits out the delay; removing one is instant. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/movva/MovvaReserve.sol:813` |
| `setGatewayCouncil(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | The council, or the governor through the delay, may name a new council; the council may hand itself on or renounce (zero) at once, and the governor may remove it at once. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/movva/MovvaReserve.sol:853` |
| `setGuardian(address)` | the governor (key) | instant | Instant. The guardian can only pause minting, pull USDT from the vault back into the reserve, and pause deposits into the vault. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/movva/MovvaReserve.sol:822` |
| `setOracle(address,address,uint64,uint64)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Repointing either leg or lengthening a max age is delayed; only tightening an age is instant, and never below `MIN_USDT_USD_MAX_AGE` / `MIN_FX_MAX_AGE` (SRM1-20). The rate prices every mint and red... <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/movva/MovvaReserve.sol:906` |
| `setSupplyCap(uint256)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Raising the supply cap is delayed; lowering it is instant. A cap of zero stops minting. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/movva/MovvaReserve.sol:896` |
| `setVaultDepositsPaused(bool)` | the guardian or the governor (key) | instant | Instant either way: the vault was chosen through the delay, and exits are unaffected. The guardian may pause; only the governor may resume. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/movva/MovvaReserve.sol:958` |
| `setYieldRecipient(address)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Always delayed, in either direction: this address is the only place yield is paid, and there is no "safer" value to move it to at once (client rule, 21 October 2026). <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/movva/MovvaReserve.sol:831` |
| `setYieldVault(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Choose the yield vault. A new vault is delayed; removing it (zero) is instant. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/movva/MovvaReserve.sol:919` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:167` |

</details>

#### Movva (token)

`0xB7C02dFb1876Db52941fcaa38515a44F147c7986` - `Movva`, `contracts/movva/Movva.sol`. The Movva ERC-20 (R$ 1,00). Its only minter is the MovvaReserve that deployed it.

- minter (RESERVE, immutable): `0xE5ECD575F283331675E3734cBffCB70D37833926`
- EIP-1967 slots: empty (not a proxy)

- **RESERVE** can mint to anyone, and burn its own balance. It cannot burn anyone else's Movva. No owner, no pause, no blacklist, no upgrade. (`contracts/movva/Movva.sol:49`, `contracts/movva/Movva.sol:55`)

<details><summary>6 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `approve(address,uint256)` | anyone | - | Set an allowance over the caller's own balance. | open | `node_modules/@openzeppelin/contracts/token/ERC20/ERC20.sol:127` |
| `burn(uint256)` | only the MovvaReserve (immutable) | - | Reserve only: destroy `amount` of the reserve's own Movva. <sub>(NatSpec)</sub> | `0xE5EC…3926` minter | `contracts/movva/Movva.sol:55` |
| `mint(address,uint256)` | only the MovvaReserve (immutable) | - | Reserve only: create `amount` Movva for `to`. <sub>(NatSpec)</sub> | `0xE5EC…3926` minter | `contracts/movva/Movva.sol:49` |
| `permit(…)` | anyone | - | EIP-2612: set an allowance with the owner's signature. | open | `node_modules/@openzeppelin/contracts/token/ERC20/extensions/ERC20Permit.sol:44` |
| `transfer(address,uint256)` | anyone | - | Move the caller's own balance. | open | `node_modules/@openzeppelin/contracts/token/ERC20/ERC20.sol:104` |
| `transferFrom(address,address,uint256)` | anyone | - | Move a balance within an allowance its owner gave the caller. | open | `node_modules/@openzeppelin/contracts/token/ERC20/ERC20.sol:149` |

</details>

#### Movva FX leg (PythFxOracle)

`0x0A9c2541c699F2F3308DFB70b9B846D7987bE108` - `PythFxOracle`, `contracts/ramp/PythFxOracle.sol`. The BRL/USD FX leg over Pyth's FX.USD/BRL, with a band reading for the hours the FX market is closed.

- governor `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`; setup complete; delay 48 h; 0 pending change(s)
- EIP-1967 slots: empty (not a proxy)

- **governor** can repoint the Pyth price id, and loosen or tighten the max ages and the confidence bound (loosening waits GOVERNANCE_DELAY, tightening is instant). It cannot post a price (Pyth prices are posted permissionlessly on Pyth) or change which Pyth contract it reads: PYTH is immutable. (`contracts/ramp/PythFxOracle.sol:145`, `contracts/ramp/PythFxOracle.sol:153`, `contracts/common/DelayedGovernance.sol:167`)

<details><summary>8 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:191` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:151` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:206` |
| `ossify()` | the governor (key) | instant | One-way: no risk-increasing change can ever run again; the instant, risk-reducing ones stay with the governor. See "Ossify" above. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:159` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:179` |
| `setFeed(bytes32)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Repointing the feed waits out the governance delay. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/PythFxOracle.sol:145` |
| `setLimits(uint64,uint64,uint16)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Loosening any limit waits out the governance delay; tightening is instant. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/PythFxOracle.sol:153` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:167` |

</details>

#### Movva band adapter (ScaledFxBandOracle)

`0x46AF143C878918ceD813C9B3C2Cbee4aEDf84dbC` - `ScaledFxBandOracle`, `contracts/movva/ScaledFxBandOracle.sol`. Reads an FX leg and re-expresses it in centavos; no governance of its own: SOURCE is immutable.

- EIP-1967 slots: empty (not a proxy)

No state-changing functions.

#### FeeSplitter

`0x48c00e0222a674a9d920482538d97928A870016D` - `FeeSplitter`, `contracts/movva/FeeSplitter.sol`. The reserve's fee recipient: splits Movva fee revenue between NodeRewards and Mova's treasury. **Holds funds.**

- governor `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`; setup complete; delay 48 h; 0 pending change(s)
- treasury (payee): `0x622F626F912AD25d36D9B8F48907Ac941F755ACb`
- rewards (payee): `0x2b9a9F186414665468FBE68eE5cF2344e820Aa05`
- lpRewardShareBps = `0` (the LPs' share of fee revenue)
- EIP-1967 slots: empty (not a proxy)

- **governor** can change the LPs' share (never above 50%), the treasury and the rewards contract. It cannot take what the splitter holds: `split` pays only the treasury and the rewards contract, and anyone may call it. (`contracts/movva/FeeSplitter.sol:116`, `contracts/movva/FeeSplitter.sol:125`, `contracts/movva/FeeSplitter.sol:135`, `contracts/common/DelayedGovernance.sol:167`)

<details><summary>10 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:191` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:151` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:206` |
| `ossify()` | the governor (key) | instant | One-way: no risk-increasing change can ever run again; the instant, risk-reducing ones stay with the governor. See "Ossify" above. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:159` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:179` |
| `setLpRewardShare(uint16)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Raising the LPs' share waits out the delay; lowering it is instant. Never above 50%. What has already accrued is split first, at the share it accrued under (L-05): a lowering applies to fees from n... <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/movva/FeeSplitter.sol:116` |
| `setRewards(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | A new rewards contract waits out the delay; removing it (zero) is instant. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/movva/FeeSplitter.sol:135` |
| `setTreasury(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Delayed: this address is paid Mova's revenue. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/movva/FeeSplitter.sol:125` |
| `split()` | anyone | - | Send everything here: the LPs' share to the rewards contract, the rest to the treasury. Anyone may call. <sub>(NatSpec)</sub> | open | `contracts/movva/FeeSplitter.sol:82` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:167` |

</details>

#### NodeRewards

`0x2b9a9F186414665468FBE68eE5cF2344e820Aa05` - `NodeRewards`, `contracts/ramp/NodeRewards.sol`. Node-provider rewards: fee revenue shared among INSTITUTIONAL and AFFILIATED LPs by settled BRL volume, epoch by epoch. **Holds funds.**

- governor `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`; setup complete; delay 48 h; 0 pending change(s)
- registry (reports settlements): `0xf182Eb04AbA75452CE5F4c400B0742C2f0abc7e2`
- excluded LP: none
- EIP-1967 slots: empty (not a proxy)

- **governor** can bind or unbind the registry, set the reward limits (within MAX_REWARD_BPS_OF_VOLUME), exclude or reinstate an LP, and void an LP's volume while its epoch is in review. It cannot pay anyone: rewards go only to LPs claiming their own shares, and voided shares roll forward instead of going to anyone else. (`contracts/ramp/NodeRewards.sol:416`, `contracts/ramp/NodeRewards.sol:427`, `contracts/ramp/NodeRewards.sol:437`, `contracts/ramp/NodeRewards.sol:449`, `contracts/common/DelayedGovernance.sol:167`)
- **registry** can report settlements, which count as volume. It cannot pay rewards. (`contracts/ramp/NodeRewards.sol:242`)

<details><summary>14 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:191` |
| `claim(uint256[],address)` | a party to that offer, order, sale, note or reward | - | Claim the caller's rewards for finalized epochs, paid to `to`. <sub>(NatSpec)</sub> | open | `contracts/ramp/NodeRewards.sol:331` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:151` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:206` |
| `finalize(uint256)` | anyone | - | Finalize up to `maxEpochs` epochs whose review has ended, oldest first. Anyone may call it. <sub>(NatSpec)</sub> | open | `contracts/ramp/NodeRewards.sol:285` |
| `onSettled(address,uint256,uint8)` | only the bound LPRegistry | - | Count a settlement's volume for the LP. | `0xf182…c7e2` registry | `contracts/ramp/NodeRewards.sol:242` |
| `ossify()` | the governor (key) | instant | One-way: no risk-increasing change can ever run again; the instant, risk-reducing ones stay with the governor. See "Ossify" above. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:159` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:179` |
| `setExcluded(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Excluding an LP is instant; reinstating one waits out the delay. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/NodeRewards.sol:437` |
| `setRegistry(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Bind the registry whose settlement reports count; zero unbinds. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/NodeRewards.sol:416` |
| `setRewardLimits(uint16,uint256,uint256)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Raising the rate or the per-LP cap, or lowering the minimum, is delayed; the opposite of each is instant. The rate can never pass MAX_REWARD_BPS_OF_VOLUME. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/NodeRewards.sol:427` |
| `sync()` | anyone | - | Book reward tokens that arrived since the last sync into the current epoch. Anyone may call it; FeeSplitter calls it after every transfer here. <sub>(NatSpec)</sub> | open | `contracts/ramp/NodeRewards.sol:262` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:167` |
| `voidVolume(uint256,address)` | the governor (key) | instant | Instant, governor only: void `lp`'s volume for an epoch still in review, current or ended. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/NodeRewards.sol:449` |

</details>

#### Movva Privacy Pool

`0xB3C042132A1650E01F61165ebf74c6c5aDa9f080` - `PrivacyPoolComplex`, `protocol/contracts/src/contracts/implementations/PrivacyPoolComplex.sol`. A Privacy Pool for an ERC-20 (Movva) (upstream 0xbow). No owner; bound to one Entrypoint and one asset at construction. **Holds funds.**

- ENTRYPOINT (immutable): `0xFa3A263bA866Dd12df5eb671C9E5004F7E4d87C8`
- dead = `false` (wound down: no new deposits)
- EIP-1967 slots: empty (not a proxy)

- **ENTRYPOINT** can deposit on a depositor's behalf, and wind the pool down. It cannot withdraw: that needs a note's proof, or its original depositor for ragequit. (`protocol/contracts/src/contracts/PrivacyPool.sol:82`, `protocol/contracts/src/contracts/PrivacyPool.sol:157`)

<details><summary>4 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `deposit(address,uint256,uint256)` | only the Entrypoint (immutable) | - | Deposit funds into the Privacy Pool <sub>(NatSpec)</sub> | `0xFa3A…87C8` ENTRYPOINT | `protocol/contracts/src/contracts/PrivacyPool.sol:82` |
| `ragequit((uint256[2],uint256[2][2],uint256[2],uint256[4]))` | a party to that offer, order, sale, note or reward | - | Publicly withdraw funds to original depositor without exposing secrets <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `protocol/contracts/src/contracts/PrivacyPool.sol:132` |
| `windDown()` | only the Entrypoint (immutable) | - | Irreversibly suspends deposits <sub>(NatSpec)</sub> | `0xFa3A…87C8` ENTRYPOINT | `protocol/contracts/src/contracts/PrivacyPool.sol:157` |
| `withdraw(…)` | anyone carrying a proof the contract's verifier accepts | - | Privately withdraw funds by spending an existing commitment <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `protocol/contracts/src/contracts/PrivacyPool.sol:110` |

</details>

#### Entrypoint owner (TimelockController, 7 days)

`0x640ce45e8CBadCB7671Df7D98Cb8c085764C2C86` - `EntrypointTimelock`, `contracts/governance/EntrypointTimelock.sol`. OpenZeppelin 5.1.0 TimelockController, unchanged (contracts/governance/EntrypointTimelock.sol adds nothing): the Entrypoint's OWNER_ROLE holder (H-02). Every call it makes waits getMinDelay() (7 days) after a proposer schedules it; the Safe is its only proposer and executor, it and an independent Safe cancel (v3.1 N-19; one constructor argument added to OpenZeppelin's), and it administers its own roles.

- proposer: `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`
- canceller: `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`, `0xd67DDA7D07CAa45d6f8e7C1dD0a170585e6B086c`
- executor: `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`
- admin (DEFAULT_ADMIN_ROLE): `0x640ce45e8CBadCB7671Df7D98Cb8c085764C2C86`
- getMinDelay = `604800` (seconds every operation waits between schedule and execute)
- EIP-1967 slots: empty (not a proxy)

- **proposer / canceller / executor (the Safe)** can schedule any call from the timelock - so any Entrypoint OWNER_ROLE action: upgrade, pools, fees, roles - and run it once getMinDelay() (7 days) has passed; cancel any queued operation at once. It cannot run anything sooner than the delay, shorten the delay without waiting it, or add a proposer without a delayed operation. Every scheduled operation is public (CallScheduled) for the whole delay. (`node_modules/@openzeppelin/contracts/governance/TimelockController.sol:266`, `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:291`, `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:358`, `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:385`, `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:334`)
- **DEFAULT_ADMIN_ROLE (the timelock itself)** can grant and revoke the timelock's roles and change its delay - only through its own delayed operations. It cannot act without a proposer scheduling it: nobody else holds the admin role. (`node_modules/@openzeppelin/contracts/access/AccessControl.sol:122`, `node_modules/@openzeppelin/contracts/access/AccessControl.sol:137`, `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:449`)

<details><summary>13 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `receive()` | anyone | - | Accept ETH (it holds none for the rail). | not probed (plain ETH transfer) | `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:155` |
| `cancel(bytes32)` | a holder of the timelock's CANCELLER_ROLE (the Safe) (key) | instant | Drop a queued operation before it runs. | `0xd67D…086c` canceller<br>`0x956E…dCa1` proposer, canceller, executor | `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:334` |
| `execute(address,uint256,bytes,bytes32,bytes32)` | a holder of the timelock's EXECUTOR_ROLE (the Safe; not open) (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a queued call once its delay has passed (calls the Entrypoint as OWNER_ROLE). | `0x956E…dCa1` proposer, canceller, executor | `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:358` |
| `executeBatch(address[],uint256[],bytes[],bytes32,bytes32)` | a holder of the timelock's EXECUTOR_ROLE (the Safe; not open) (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a queued batch once its delay has passed. | `0x956E…dCa1` proposer, canceller, executor | `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:385` |
| `grantRole(bytes32,address)` | only the timelock itself, through an operation that waited its minimum delay | only once a scheduled change has waited GOVERNANCE_DELAY | Grant a timelock role. DEFAULT_ADMIN_ROLE administers every role and only the timelock holds it, so only an operation that waited the delay can. | `0x640c…2C86` admin | `node_modules/@openzeppelin/contracts/access/AccessControl.sol:122` |
| `onERC1155BatchReceived(…)` | anyone | - | ERC-1155 batch receiver hook. | open | `node_modules/@openzeppelin/contracts/token/ERC1155/utils/ERC1155Holder.sol:33` |
| `onERC1155Received(address,address,uint256,uint256,bytes)` | anyone | - | ERC-1155 receiver hook. | open | `node_modules/@openzeppelin/contracts/token/ERC1155/utils/ERC1155Holder.sol:23` |
| `onERC721Received(address,address,uint256,bytes)` | anyone | - | ERC-721 receiver hook: accept a token sent to the timelock. | open | `node_modules/@openzeppelin/contracts/token/ERC721/utils/ERC721Holder.sol:21` |
| `renounceRole(bytes32,address)` | only for the caller's own role | instant | Give up a timelock role the caller holds (it must name itself). | **nobody** (every probed caller refused) | `node_modules/@openzeppelin/contracts/access/AccessControl.sol:157` |
| `revokeRole(bytes32,address)` | only the timelock itself, through an operation that waited its minimum delay | only once a scheduled change has waited GOVERNANCE_DELAY | Revoke a timelock role: an operation of the timelock itself. | `0x640c…2C86` admin | `node_modules/@openzeppelin/contracts/access/AccessControl.sol:137` |
| `schedule(address,uint256,bytes,bytes32,bytes32,uint256)` | a holder of the timelock's PROPOSER_ROLE (the Safe) (key) | instant | Queue one call (target, value, data) to run after at least getMinDelay(). | `0x956E…dCa1` proposer, canceller, executor | `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:266` |
| `scheduleBatch(…)` | a holder of the timelock's PROPOSER_ROLE (the Safe) (key) | instant | Queue a batch of calls to run together after at least getMinDelay(). | `0x956E…dCa1` proposer, canceller, executor | `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:291` |
| `updateDelay(uint256)` | only the timelock itself, through an operation that waited its minimum delay | only once a scheduled change has waited GOVERNANCE_DELAY | Change the minimum delay: only as an operation of the timelock itself, so a shorter delay waits the current one. | `0x640c…2C86` admin | `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:449` |

</details>

#### AspRootQuorum (ASP postman, 2 of 3)

`0xC12e3DD76faDef119C8A8691959375948E4ea3a1` - `AspRootQuorum`, `contracts/AspRootQuorum.sol`. The Entrypoint's ASP postman as an immutable THRESHOLD-of-ASP_COUNT quorum (contracts/AspRootQuorum.sol): a root reaches the Entrypoint only when THRESHOLD of the fixed ASPs voted for exactly that root and CID. No owner, no setter, no upgrade.

- ASP: `0x6f239a1A5818808E63BB6F35A88B9876a79aa973`, `0xc8510850c5bF41B52399473F234577B2d8Ef0B16`, `0x323574Eb0c63b764F06832f15B21956bb8979FC9`
- ENTRYPOINT (immutable): `0xFa3A263bA866Dd12df5eb671C9E5004F7E4d87C8`
- THRESHOLD = `2` (distinct ASP votes that post a root)
- ASP_COUNT = `3` (ASPs, fixed at deployment)
- round = `0` (roots posted so far; votes count only in the current round)
- EIP-1967 slots: empty (not a proxy)

- **ASP** can vote for a root and CID in the current round. THRESHOLD distinct votes for the same proposal post it to the Entrypoint at once. It cannot post a root alone (THRESHOLD is a strict majority), vote twice for one proposal, move funds, or change the ASP set or THRESHOLD: nobody can, ever. (`contracts/AspRootQuorum.sol:152`, `contracts/AspRootQuorum.sol:180`)

<details><summary>2 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `unvote(uint256,string)` | one of the ASPs fixed at deployment (key) | instant | Withdraw this ASP's live vote for `root` with `ipfsCID` in the current round - for example after it found a label it no longer approves. It then counts for nothing. <sub>(NatSpec)</sub> | `0x6f23…a973` ASP<br>`0xc851…0B16` ASP<br>`0x3235…9FC9` ASP | `contracts/AspRootQuorum.sol:180` |
| `vote(uint256,string)` | one of the ASPs fixed at deployment (key) | instant | Vote, as one of the fixed ASPs, for posting `root` with `ipfsCID`. The vote that brings the live votes to THRESHOLD posts the root to the Entrypoint in the same transaction. A lapsed vote for the s... <sub>(NatSpec)</sub> | `0x6f23…a973` ASP<br>`0x3235…9FC9` ASP<br>`0xc851…0B16` ASP | `contracts/AspRootQuorum.sol:152` |

</details>

#### LPRegistry

`0xf182Eb04AbA75452CE5F4c400B0742C2f0abc7e2` - `LPRegistry`, `contracts/ramp/LPRegistry.sol`. LP onboarding, network phases, tiers, credit and exposure across every escrow.

- governor `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`; setup complete; delay 48 h; 0 pending change(s)
- escrow: `0x1fa7a70DA69f9Aa8A8074D939962E9187a102c39`, `0x8cB7DDDaac7Fa98f747DF0553F3C7E375936499E`
- rewards hook: `0x2b9a9F186414665468FBE68eE5cF2344e820Aa05`
- LP (tier > NONE): `0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C`, `0xf491FA29debC0D12d8F7c57B17995C2346F025AD`
- phase = `0` (0 = A (governor-admitted institutions only), 1 = B (+ affiliates), 2 = C (+ retail))
- EIP-1967 slots: empty (not a proxy)

- **governor** can accept and drop escrows, open and close network phases, set the rewards hook, and admit, re-tier, suspend or remove LPs with their credit limits. It cannot move funds: the registry holds none. It decides how much an LP may have at risk, and which escrows may reserve it. (`contracts/ramp/LPRegistry.sol:212`, `contracts/ramp/LPRegistry.sol:221`, `contracts/ramp/LPRegistry.sol:234`, `contracts/ramp/LPRegistry.sol:252`, `contracts/common/DelayedGovernance.sol:167`)
- **escrow** can reserve and release LPs' exposure and record settlements and lost disputes. It cannot release exposure another escrow reserved. (`contracts/ramp/LPRegistry.sol:423`, `contracts/ramp/LPRegistry.sol:441`, `contracts/ramp/LPRegistry.sol:464`, `contracts/ramp/LPRegistry.sol:491`, `contracts/ramp/LPRegistry.sol:505`)

<details><summary>18 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:191` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:151` |
| `consumeBankTxId(bytes32)` | only an escrow the registry accepts | - | Spend a bank transaction id on a settlement: true the first time, false ever after, whichever escrow of this registry spent it. Only an escrow (current or retired) may call, or anyone could burn th... <sub>(NatSpec)</sub> | `0x1fa7…2c39` escrow<br>`0x8cB7…499E` escrow | `contracts/ramp/LPRegistry.sol:505` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:206` |
| `ossify()` | the governor (key) | instant | One-way: no risk-increasing change can ever run again; the instant, risk-reducing ones stay with the governor. See "Ossify" above. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:159` |
| `recordDispute(address)` | only an escrow the registry accepts | - | Called by the escrow when a dispute is ruled against the LP. MUST NOT revert. <sub>(NatSpec)</sub> | `0x21f4…f975` stranger<br>`0x956E…dCa1` governor<br>`0x1fa7…2c39` escrow<br>`0x8cB7…499E` escrow<br>`0x3ce8…3f5C` LP<br>`0xf491…25AD` LP<br>`0x9F65…996f` deployer | `contracts/ramp/LPRegistry.sol:491` |
| `recordSettled(address,uint256)` | only an escrow the registry accepts | - | Record a settlement (ignored when the caller is not an accepted escrow). | `0x9F65…996f` deployer<br>`0x956E…dCa1` governor<br>`0x8cB7…499E` escrow<br>`0x21f4…f975` stranger<br>`0x3ce8…3f5C` LP<br>`0xf491…25AD` LP<br>`0x1fa7…2c39` escrow | `contracts/ramp/LPRegistry.sol:464` |
| `register()` | anyone | - | Permissionless retail onboarding, Phase C only. The cap, not the gate, is the control - once the network has been opened to retail at all. <sub>(NatSpec)</sub> | open | `contracts/ramp/LPRegistry.sol:297` |
| `releaseExposure(address,uint256)` | only an escrow the registry accepts | - | Give back exposure this escrow reserved. MUST NOT revert: it runs on release and refund paths, after money has moved. <sub>(NatSpec)</sub> | `0x21f4…f975` stranger<br>`0x9F65…996f` deployer<br>`0x3ce8…3f5C` LP<br>`0xf491…25AD` LP<br>`0x8cB7…499E` escrow<br>`0x1fa7…2c39` escrow<br>`0x956E…dCa1` governor | `contracts/ramp/LPRegistry.sol:441` |
| `reserveExposure(address,uint256)` | only an escrow the registry accepts | - | Take on `brlCents` of exposure for `lp`, or return false if it would exceed the LP's remaining credit. Only a registered escrow may call. <sub>(NatSpec)</sub> | `0x1fa7…2c39` escrow<br>`0x8cB7…499E` escrow | `contracts/ramp/LPRegistry.sol:423` |
| `revokeAffiliate(address)` | a party to that offer, order, sale, note or reward | - | End an affiliation. The sponsor can always do this, whatever its own tier. <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/LPRegistry.sol:348` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:179` |
| `setEscrow(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Registering an escrow waits out the governance delay; removing one is instant. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/LPRegistry.sol:212` |
| `setPhase(uint8)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Open the next network phase (delayed), or close back to an earlier one (instant). <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/LPRegistry.sol:221` |
| `setRewardsHook(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Point settlement reports at a rewards contract (delayed), or stop them (zero, instant). <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/LPRegistry.sol:234` |
| `setTier(address,uint8,uint256)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Admit, re-tier or remove an LP. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/LPRegistry.sol:252` |
| `sponsorAffiliate(address,uint256)` | an INSTITUTIONAL LP, from Phase B | - | Sponsor an affiliated LP, or change its credit. Phase B onwards; caller must be an active INSTITUTIONAL LP. <sub>(NatSpec)</sub> | open | `contracts/ramp/LPRegistry.sol:314` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:167` |

</details>

#### ReclaimZkTlsVerifier (PIX, boleto, TED)

`0x1bE9d1Dbeb61B2815287de8eDA85B30EB1917F9d` - `ReclaimZkTlsVerifier`, `contracts/ramp/ReclaimZkTlsVerifier.sol`. PIX and boleto verifier: Reclaim zkTLS claims of the payer's own bank session, signed by a threshold of witnesses.

- governor `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`; setup complete; delay 48 h; 0 pending change(s)
- witness: `0x05EfF3D8e0ad59Aa8abFd94E0b08402ec0850Fbf`, `0x8771D8B0038061D7872e4c2C69cD63F54380CBAb`, `0x72C1a86B73Ca01Fec5e07160AE14a32849eE5214`
- bank endpoint (providerHash): `0xb54d2a19bba3a502dc449c083cd2579885618e4e0487435aae1673f06baf0c05`, `0xd8d90d629dc91348bf69c3c5148cd5bf1efdc99220a15a6f42d6ad42eeb2bb20`, `0x8259a0510dbf7425215eada80e9a8fcc1bac48d4e24e3cea67b5185b482abf77`, `0xf02c2badc915c0c690ccba5dd00202b6efcc3d49a1c1197db4026f075aaddc1a`
- threshold = `2` (witness signatures needed)
- witnessCount = `3` (witnesses)
- endpointCount = `4` (allowed bank endpoints)
- EIP-1967 slots: empty (not a proxy)

- **governor** can add and remove witnesses, change the threshold, allow and revoke bank endpoints, the rails each may attest and whether its PIX payments must carry the order's txid (adding, allowing, lowering and dropping the txid requirement wait; removing, revoking, raising and requiring are instant). It cannot prove a payment itself, unless it adds itself as witnesses through the delay. (`contracts/ramp/ReclaimZkTlsVerifier.sol:752`, `contracts/ramp/ReclaimZkTlsVerifier.sol:763`, `contracts/ramp/ReclaimZkTlsVerifier.sol:775`, `contracts/ramp/ReclaimZkTlsVerifier.sol:783`, `contracts/ramp/ReclaimZkTlsVerifier.sol:800`, `contracts/ramp/ReclaimZkTlsVerifier.sol:821`, …)
- **witness** can sign Reclaim claims: `threshold` of them prove that a bank session on an allowed endpoint showed the payment. It cannot vouch for an endpoint the governor has not allowed, or a rail the endpoint may not attest.

<details><summary>13 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `allowEndpoint(bytes32,string)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Allow a bank endpoint: the template's Reclaim `providerHash` and the URL prefix its `url` must start with. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/ReclaimZkTlsVerifier.sol:775` |
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:191` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:151` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:206` |
| `ossify()` | the governor (key) | instant | One-way: no risk-increasing change can ever run again; the instant, risk-reducing ones stay with the governor. See "Ossify" above. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:159` |
| `revokeEndpoint(bytes32)` | the governor (key) | instant | Revoking an endpoint is instant. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/ReclaimZkTlsVerifier.sol:783` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:179` |
| `setEndpointDirection(bytes32,uint8)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Say what an endpoint's page proves: RECEIVED (1), SENT (2), or nothing (0). See `endpointDirection`. Classifying an endpoint, or changing its class, is delayed - it decides which escrow its proofs ... <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/ReclaimZkTlsVerifier.sol:836` |
| `setEndpointOrderTxid(bytes32,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Require, or stop requiring, that an endpoint's non-boleto payments carry the order's txid: the M-03 binding in the header. Set it on every endpoint whose page is a PIX credit to the LP (`pix-receiv... <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/ReclaimZkTlsVerifier.sol:821` |
| `setEndpointRails(bytes32,uint16)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Set which rails an allowlisted endpoint may attest, as a bitmask over Rail. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/ReclaimZkTlsVerifier.sol:800` |
| `setThreshold(uint256)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Lowering the threshold waits out the governance delay; raising it is instant. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/ReclaimZkTlsVerifier.sol:763` |
| `setWitness(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Adding a witness waits out the governance delay; removing one is instant. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/ReclaimZkTlsVerifier.sol:752` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:167` |

</details>

#### FiatEscrow (Movva on-ramp)

`0x1fa7a70DA69f9Aa8A8074D939962E9187a102c39` - `FiatEscrow`, `contracts/ramp/FiatEscrow.sol`. On-ramp escrow: an LP escrows crypto in an offer; a taker locks an order, pays BRL, and the crypto is released on a proof of payment. **Holds funds.**

- governor `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`; setup complete; delay 48 h; 0 pending change(s)
- arbitrator: `0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7`
- allowed verifier: `0x1bE9d1Dbeb61B2815287de8eDA85B30EB1917F9d`
- listed asset (enabled): `0xB7C02dFb1876Db52941fcaa38515a44F147c7986`
- EIP-1967 slots: empty (not a proxy)

- **governor** can list and delist assets and their band oracles, allow and revoke payment verifiers, add and remove arbitrators, set asset caps. After setup, listing, allowing, adding and raising wait GOVERNANCE_DELAY; delisting, revoking, removing and lowering are instant. It cannot move an offer's liquidity or an order's funds, change an asset's decimals once set, or decide a dispute: a ruling needs an arbitrator's signature. Its power over funds is indirect: which verifiers and arbitrators the escrow believes. (`contracts/ramp/FiatEscrow.sol:548`, `contracts/ramp/FiatEscrow.sol:1225`, `contracts/ramp/FiatEscrow.sol:1233`, `contracts/ramp/FiatEscrow.sol:1245`, `contracts/common/DelayedGovernance.sol:167`, `contracts/common/DelayedGovernance.sol:179`, …)
- **arbitrator** can sign a ruling on a DISPUTED order: RELEASE to the taker's named recipient, or REFUND to the LP (its offer; its own address after a taker's dispute). Anyone submits it; it executes only after RULING_DELAY (1 day), re-verified then, and before DISPUTE_TIMEOUT. A RELEASE needs an arbitrator registered no later than the dispute was raised. It cannot reach an order that is not in dispute, an LP's free liquidity, more than the disputed amount, or any payee but the order's two counterparties. (`contracts/ramp/FiatEscrow.sol:1076`)

<details><summary>25 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `receive()` | anyone | - | Accept ETH: meant for ragequit proceeds from a pool. ETH sent here any other way is credited to nobody, and no function can take it out. | not probed (plain ETH transfer) | `contracts/ramp/FiatEscrow.sol:1540` |
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:191` |
| `cancelOrder(bytes32)` | a party to that offer, order, sale, note or reward | - | Give up before paying. Returns the liquidity immediately rather than making the LP wait out the window for capital nobody is going to use. <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:881` |
| `closeOffer(bytes32)` | a party to that offer, order, sale, note or reward | - | Close an offer and return its free liquidity to the LP. The LP may always; ANYONE may once the registry gives the LP no credit at all (`capOf` zero: removed, suspended, or an affiliate whose sponso... <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:652` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:151` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:206` |
| `expireDispute(bytes32)` | anyone | - | After the dispute's timeout with no ruling (`disputeDeadline`: DISPUTE_TIMEOUT for an LP's dispute, TAKER_DISPUTE_TIMEOUT for a taker's), anyone returns the order's liquidity to the LP: to its offe... <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:1158` |
| `fundOffer(bytes32,uint256)` | a party to that offer, order, sale, note or reward | - | Add liquidity to the caller's own offer. | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:624` |
| `issueBoleto(bytes32,bytes32)` | a party to that offer, order, sale, note or reward | - | The LP commits to the boleto it registered for this order. <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:708` |
| `lockOrder(bytes32,uint256,uint8,address,uint256)` | anyone | - | Lock liquidity to pay for by PIX or TED, to the offer's key. <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:669` |
| `lockOrderByBoleto(bytes32,uint256,uint8,address,uint256)` | anyone | - | Lock liquidity to pay for by boleto. The LP must then issue one: see issueBoleto. <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:685` |
| `ossify()` | the governor (key) | instant | One-way: no risk-increasing change can ever run again; the instant, risk-reducing ones stay with the governor. See "Ossify" above. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:159` |
| `postOffer(…)` | an LP the registry lets quote | - | Post an offer and escrow its liquidity (the registry must let the LP quote it). | open | `contracts/ramp/FiatEscrow.sol:565` |
| `raiseDispute(bytes32,string)` | a party to that offer, order, sale, note or reward | - | Freeze an order pending arbitration. The cases this exists for are the ones no proof can settle: the taker paid but the attestor cannot produce a proof (bank downtime, an unsupported statement form... <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:996` |
| `reclaimExpired(bytes32)` | anyone | - | After the window and the taker's grace (TAKER_GRACE), anyone may return unpaid liquidity to the LP. <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:929` |
| `releaseWithProof(bytes32,bytes)` | anyone carrying a proof the contract's verifier accepts | - | Present proof the BRL was paid, and take delivery. <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:814` |
| `rescueShielded(…)` | a party to that offer, order, sale, note or reward | - | The order's recipient ragequits a shielded delivery back out of the pool, to itself. | open | `contracts/ramp/FiatEscrow.sol:1195` |
| `resolveDispute(…)` | anyone carrying a registered arbitrator's signed ruling (key) | - | Submit an arbitrator's signed ruling. Anyone may submit it: the first submission posts it, and the same ruling submitted again after RULING_DELAY executes it. <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:1076` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:179` |
| `setArbitrator(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Adding an arbitrator waits out the governance delay; removing one is instant. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/FiatEscrow.sol:1233` |
| `setAsset(address,address,uint8,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | List or delist a settlement asset. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/FiatEscrow.sol:548` |
| `setAssetCap(address,uint256)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Lowering or setting a first cap is instant; raising or removing one is delayed. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/FiatEscrow.sol:1245` |
| `setVerifier(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Allowing a verifier waits out the governance delay; revoking one is instant. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/FiatEscrow.sol:1225` |
| `takeDeliveryDirect(bytes32)` | a party to that offer, order, sale, note or reward | - | Take a shielded order's delivery in the open instead, to the rescue address. A shielded delivery can become impossible after the taker has paid: the Entrypoint or the pool can be frozen by the toke... <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:909` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:167` |

</details>

#### OffRampEscrow (Movva off-ramp)

`0x8cB7DDDaac7Fa98f747DF0553F3C7E375936499E` - `OffRampEscrow`, `contracts/ramp/OffRampEscrow.sol`. Off-ramp escrow: a seller escrows crypto in a sale; an LP claims it, pays the seller BRL, and is paid the crypto on a proof. **Holds funds.**

- governor `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`; setup complete; delay 48 h; 0 pending change(s)
- arbitrator: `0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7`
- allowed verifier: `0x1bE9d1Dbeb61B2815287de8eDA85B30EB1917F9d`
- listed asset (enabled): `0xB7C02dFb1876Db52941fcaa38515a44F147c7986`
- EIP-1967 slots: empty (not a proxy)

- **governor** can list and delist assets and their band oracles, allow and revoke payment verifiers, add and remove arbitrators, set asset caps. After setup, listing, allowing, adding and raising wait GOVERNANCE_DELAY; delisting, revoking, removing and lowering are instant. It cannot move a sale's escrowed crypto, change an asset's decimals once set, or decide a dispute: a ruling needs an arbitrator's signature. Its power over funds is indirect: which verifiers and arbitrators the escrow believes. (`contracts/ramp/OffRampEscrow.sol:303`, `contracts/ramp/OffRampEscrow.sol:714`, `contracts/ramp/OffRampEscrow.sol:722`, `contracts/ramp/OffRampEscrow.sol:743`, `contracts/common/DelayedGovernance.sol:167`, `contracts/common/DelayedGovernance.sol:179`, …)
- **arbitrator** can sign a ruling on a DISPUTED sale: pay the claiming LP, or return the crypto to the seller. Anyone submits it; it executes only after RULING_DELAY (1 day), re-verified then. Paying the LP needs an arbitrator registered no later than the dispute was raised. It cannot reach a sale that is not in dispute, or pay anyone but the sale's two counterparties. (`contracts/ramp/OffRampEscrow.sol:622`)

<details><summary>19 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `abandonClaim(bytes32)` | a party to that offer, order, sale, note or reward | - | Give the claim back early, without penalty. The sale is cancellable at once and claimable again after CLAIM_COOLDOWN, by any LP, this one included. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:455` |
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:191` |
| `cancelSale(bytes32)` | a party to that offer, order, sale, note or reward | - | Withdraw a sale nobody holds a live claim on: an unclaimed one, or one whose claim is past its `payBy` (the stale claim is released first, freeing the LP's credit). Never available while a claim is... <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/OffRampEscrow.sol:388` |
| `claimSale(bytes32)` | an LP the registry lets quote | - | Take exclusivity on a sale in order to pay it. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:416` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:151` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:206` |
| `expireDispute(bytes32)` | anyone | - | After DISPUTE_TIMEOUT with no ruling, anyone returns the escrowed crypto to the seller's refund address and frees the LP's credit. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:697` |
| `openSale(…)` | anyone | - | Escrow ETH and ask for BRL. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:329` |
| `ossify()` | the governor (key) | instant | One-way: no risk-increasing change can ever run again; the instant, risk-reducing ones stay with the governor. See "Ossify" above. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:159` |
| `raiseDispute(bytes32,string)` | a party to that offer, order, sale, note or reward | - | Freeze a claimed sale pending arbitration. Either side may, only while the claim is live, `block.timestamp <= payBy`: the LP since H-04, the seller since v3.1 N-22. <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/OffRampEscrow.sol:573` |
| `releaseStaleClaim(bytes32)` | anyone | - | Clear a claim nobody honoured. Callable by anyone: leaving this to the seller would mean a seller without gas stays frozen. The sale is open again: cancellable at once, claimable after CLAIM_COOLDOWN. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:446` |
| `resolveDispute(…)` | anyone carrying a registered arbitrator's signed ruling (key) | - | Submit an arbitrator's signed ruling. Anyone may submit it: the first submission posts it, and the same ruling submitted again after RULING_DELAY executes it. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:622` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:179` |
| `setArbitrator(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Adding an arbitrator waits out the governance delay; removing one is instant. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/OffRampEscrow.sol:722` |
| `setAsset(address,address,uint8,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | List or delist a settlement asset. Decimals are fixed once first set. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/OffRampEscrow.sol:303` |
| `setAssetCap(address,uint256)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Lowering or setting a first cap is instant; raising or removing one is delayed. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/OffRampEscrow.sol:743` |
| `setVerifier(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Allowing a verifier waits out the governance delay; revoking one is instant. <sub>(NatSpec)</sub> | `0x956E…dCa1` governor | `contracts/ramp/OffRampEscrow.sol:714` |
| `settleWithProof(bytes32,bytes)` | anyone carrying a proof the contract's verifier accepts | - | Prove the seller was paid, and collect the escrowed ETH. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:496` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x956E…dCa1` governor | `contracts/common/DelayedGovernance.sol:167` |

</details>

## Etherscan verification

`deployments/sepolia-movva-v5-rail/etherscan-verify.sh` holds the exact `forge verify-contract` command for each address, with its constructor arguments and linked libraries. **They were not run.** Each was dry-run instead: forge wrote the standard-JSON input it would submit (`--show-standard-json-input`), solc 0.8.28+commit.7893614a compiled it, and the result was compared with the code at the address and with the creation transaction's init code: 21 of 21 match.

Library paths are spelled through the remapping (`poseidon-solidity/PoseidonT3.sol`). Forge 0.3.0 writes any other spelling into the input as a path solc does not match. The pools then compile with unlinked placeholders, and Etherscan would not match them. The dry run fails any input whose libraries are left unlinked.

## What was NOT verified

- Etherscan itself. The verify commands were generated and dry-run offline, not submitted. The dry run repeats Etherscan's compile with the same solc, but not Etherscan's service.
- That the code is correct. This report proves which code is deployed and who can call it. Whether that code is safe is the audit's question (`docs/audit-scope.md`).
- Behaviour. No deposit, order, dispute, mint or withdrawal was executed here: the verification pass is read-only. Those flows are exercised by the Foundry and vitest suites.
- Immutable values byte by byte. They are masked in the bytecode comparison and checked through their getters by the wiring checks (Entrypoint, pools, oracles, tokens, delays, timeouts).
- The exact source text of the Privacy Pools contracts. The protocol build omits CBOR metadata (`bytecode_hash = "none"`), so for those contracts the match proves the bytecode. Their source files are hashed against the build's metadata separately.
- The Poseidon libraries' creation. They were already on the chain at deterministic addresses; their code is matched, their creation is not.
- Key custody. The inventory shows which addresses hold the remaining roles. It cannot show who holds those keys or how they are kept.
- Contracts outside the deployment: Pyth, the Chainlink feeds and their owners, CreateX and (on mainnet) USDT.
- Off-chain services: the relayer, the ASP that computes roots, the Pyth keeper and the monitor.
- Live prices. Pyth's FX.USD/BRL is stale on this chain, so the 8 checks that read it can only confirm each reader refuses it with exactly `StaleRate` (see Prices). A fresh-price read was not possible here.
