// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Script, console} from "forge-std/Script.sol";
import {AuditGrantRegistry} from "../AuditGrantRegistry.sol";
import {ShieldedNoteLog} from "../ShieldedNoteLog.sol";
import {SponsorPaymaster, IEntryPoint} from "../SponsorPaymaster.sol";

/**
 * Deploys the two viewing-key contracts.
 *
 * Both are immutable, ownerless and hold no funds, so there is nothing to configure and no
 * admin key to protect: deployment is the whole ceremony. Record both addresses in the client
 * config - an auditor must read grant status from the same registry the user registered
 * against, and note records from the same log the user wrote to.
 *
 * ShieldedNoteLog is optional per deployment: a rollout that keeps note records in the
 * off-chain vault needs only the registry, whose anchorChain gives after-the-fact detection.
 * Deploy the log when write-time enforcement is wanted instead.
 *
 *   forge script contracts/script/Deploy.s.sol --rpc-url $RPC --broadcast --verify
 */
contract Deploy is Script {
    function run() external returns (AuditGrantRegistry registry, ShieldedNoteLog noteLog) {
        vm.startBroadcast();
        registry = new AuditGrantRegistry();
        noteLog = new ShieldedNoteLog();
        vm.stopBroadcast();
        console.log("AuditGrantRegistry:", address(registry));
        console.log("ShieldedNoteLog:   ", address(noteLog));
    }
}

/**
 * Deploys the gas sponsor, funds it and stakes it.
 *
 * Separate from `Deploy` because this one is NOT ownerless: it holds a gas deposit and has
 * an owner who administers the allowlist, so it needs a key you intend to keep. Staking is
 * not optional: SponsorPaymaster reads its own storage and returns a context during
 * validation, which ERC-7562 allows only a staked paymaster, so bundlers refuse every
 * operation of an unstaked one (docs/runbook-mainnet-deploy.md, 3c).
 *
 * STAKE_WEI defaults to 1 ETH, Rundler's default minimum stake (ERC-7562 recommends roughly
 * $1000); a bundler with a lower published floor allows less. UNSTAKE_DELAY below one day
 * (ERC-7562's MIN_UNSTAKE_DELAY) is refused, because bundlers would count the stake as absent.
 *
 *   PAYMASTER_OWNER=0x... DEPOSIT_WEI=... STAKE_WEI=... \
 *   forge script contracts/script/Deploy.s.sol:DeployPaymaster --rpc-url $RPC --broadcast
 *
 * EntryPoint v0.7 lives at the same address on every chain it is deployed to, so the
 * default below is correct for mainnet, Sepolia and most L2s.
 */
contract DeployPaymaster is Script {
    address constant ENTRYPOINT_V07 = 0x0000000071727De22E5E9d8BAf0edAc6f37da032;

    function run() external returns (SponsorPaymaster paymaster) {
        address owner = vm.envOr("PAYMASTER_OWNER", msg.sender);
        // I-38: on mainnet the owner is named, and is a contract (a Safe), never the deployer's key by default.
        if (block.chainid == 1) {
            require(vm.envOr("PAYMASTER_OWNER", address(0)) != address(0), "PAYMASTER_OWNER is required on mainnet");
            require(owner.code.length > 0 && owner != msg.sender, "PAYMASTER_OWNER must be a Safe on mainnet, not the deployer");
        }
        uint256 depositWei = vm.envOr("DEPOSIT_WEI", uint256(0.05 ether));
        uint256 stakeWei = vm.envOr("STAKE_WEI", uint256(1 ether));
        uint256 unstakeDelayEnv = vm.envOr("UNSTAKE_DELAY", uint256(86_400));
        require(
            unstakeDelayEnv >= 86_400 && unstakeDelayEnv <= type(uint32).max,
            "UNSTAKE_DELAY must be at least 86400 (ERC-7562 MIN_UNSTAKE_DELAY): bundlers count a shorter delay as unstaked"
        );
        uint32 unstakeDelay = uint32(unstakeDelayEnv);
        address entryPoint = vm.envOr("ENTRYPOINT", ENTRYPOINT_V07);

        require(entryPoint.code.length > 0, "no EntryPoint at that address on this chain");

        vm.startBroadcast();
        paymaster = new SponsorPaymaster(IEntryPoint(entryPoint), owner);
        if (depositWei > 0) paymaster.deposit{value: depositWei}();
        vm.stopBroadcast();

        console.log("SponsorPaymaster:  ", address(paymaster));
        console.log("owner:             ", owner);
        console.log("deposit (wei):     ", depositWei);
        console.log("stake (wei):       ", stakeWei);
        console.log("unstake delay (s): ", unstakeDelay);
        console.log("");
        console.log("Staking must be sent BY THE OWNER, so it is not broadcast here:");
        console.log("  cast send <paymaster> 'addStake(uint32)' <delay> --value <stake> ...");
        console.log("Then allowlist accounts with setSponsored / setSponsoredBatch, and set");
        console.log("a budget: setBudget(windowSeconds, weiPerAccountPerWindow).");
    }
}
