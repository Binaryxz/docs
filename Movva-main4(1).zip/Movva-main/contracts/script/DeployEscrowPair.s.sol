// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;
import {DelayedGovernance} from "../common/DelayedGovernance.sol";

import {Script} from "forge-std/Script.sol";
import {console2} from "forge-std/console2.sol";
import {FiatEscrow} from "../ramp/FiatEscrow.sol";
import {OffRampEscrow} from "../ramp/OffRampEscrow.sol";
import {LPRegistry} from "../ramp/LPRegistry.sol";

/**
 * @title DeployEscrowPair
 * @notice A NEW FiatEscrow / OffRampEscrow pair for a live ramp, configured exactly as the live
 *         pair it replaces, except for its code and its arbitrators.
 *
 * ## Why a redeploy
 *
 * The escrows are not upgradeable. SRM1-22 (a Safe can now be the arbitrator: RulingLib's
 * EIP-1271 path) and SRM1-3/4 (a proof settles a disputed order; a taker's dispute frees the
 * LP's credit) are code changes, so they reach a live rail only as new escrows.
 *
 * ## What is copied, and from where
 *
 * Everything is READ from the live pair (OLD_ONRAMP, OLD_OFFRAMP), not retyped:
 *  - the immutables: oracle, registry, Privacy Pool entrypoint and pool, band, governance delay
 *    and dispute timeout;
 *  - MOVVA_TOKEN's listing (oracle, decimals, enabled) and its asset cap;
 *  - native ETH, listed by every constructor and delisted, as on the live pair;
 *  - ZKTLS_VERIFIER, which must be allowed on both live escrows (an allowlist is a mapping, so
 *    it is named, then checked).
 * Setters are only these four kinds (setAsset, setAssetCap, setVerifier, setArbitrator), so
 * nothing else exists to copy. ARBITRATORS are new: for the custody plan, the 2-of-3 arbitrator
 * Safe alone. All of it is done during setup, where it is instant, then setup is closed and the
 * pair is handed to the live pair's governor.
 *
 * ## New on-ramp parameters
 *
 * TAKER_DISPUTE_TIMEOUT (H-04) and MAX_VETTING_FEE_BPS (H-02) are copied from the live on-ramp when
 * it has them, and default to 5 days and 10 bps when it predates them; either environment variable
 * overrides. Both are logged. On chain id 1 the live pair's governor must be a contract other than
 * the deploying key, or the script refuses.
 *
 * ## What it does NOT do
 *
 * Register the pair with the LPRegistry. That is `LPRegistry.setEscrow(pair, true)`, a
 * risk-increasing change the registry's governor schedules and executes GOVERNANCE_DELAY later
 * (scripts/redeploy-escrows.ts). Until then the new pair refuses every offer and sale
 * (`reserveExposure` reverts NotEscrow), so deploying it changes nothing for anyone. Retiring the
 * live pair afterwards is `setEscrow(old, false)`, instant, and safe while it still holds orders:
 * releasing credit is not gated on registration and the bank-tx-id check uses `wasEscrow`.
 *
 *   OLD_ONRAMP=0x.. OLD_OFFRAMP=0x.. MOVVA_TOKEN=0x.. ZKTLS_VERIFIER=0x.. ARBITRATORS=0x..[,0x..]
 *   [TAKER_DISPUTE_TIMEOUT=<seconds>] [MAX_VETTING_FEE_BPS=<bps>]
 *   forge script contracts/script/DeployEscrowPair.s.sol:DeployEscrowPair --rpc-url .. --broadcast
 */
contract DeployEscrowPair is Script {
    struct Pair {
        FiatEscrow onramp;
        OffRampEscrow offramp;
    }

    function run() external returns (Pair memory p) {
        FiatEscrow oldOn = FiatEscrow(payable(vm.envAddress("OLD_ONRAMP")));
        OffRampEscrow oldOff = OffRampEscrow(payable(vm.envAddress("OLD_OFFRAMP")));
        address movva = vm.envAddress("MOVVA_TOKEN");
        address zktls = vm.envAddress("ZKTLS_VERIFIER");
        address[] memory arbitrators = vm.envAddress("ARBITRATORS", ",");
        _refuseBadInputs(oldOn, oldOff, movva, zktls, arbitrators);

        address governor = oldOn.governor();
        _refuseKeyGovernor(governor, msg.sender);
        uint256 takerTimeout = _onrampParam(address(oldOn), "TAKER_DISPUTE_TIMEOUT", 5 days);
        uint256 feeCap = _onrampParam(address(oldOn), "MAX_VETTING_FEE_BPS", 10);
        vm.startBroadcast();
        p.onramp = new FiatEscrow(
            address(oldOn.ORACLE()),
            address(oldOn.REGISTRY()),
            oldOn.POOL_ENTRYPOINT(),
            oldOn.POOL(),
            oldOn.BAND_BPS(),
            msg.sender,
            oldOn.GOVERNANCE_DELAY(),
            oldOn.DISPUTE_TIMEOUT(),
            takerTimeout,
            feeCap
        );
        p.offramp = new OffRampEscrow(
            address(oldOff.ORACLE()),
            address(oldOff.REGISTRY()),
            oldOff.BAND_BPS(),
            msg.sender,
            oldOff.GOVERNANCE_DELAY(),
            oldOff.DISPUTE_TIMEOUT()
        );
        _copyAsset(address(oldOn), address(p.onramp), address(0));
        _copyAsset(address(oldOff), address(p.offramp), address(0));
        _copyAsset(address(oldOn), address(p.onramp), movva);
        _copyAsset(address(oldOff), address(p.offramp), movva);
        p.onramp.setVerifier(zktls, true);
        p.offramp.setVerifier(zktls, true);
        for (uint256 i; i < arbitrators.length; ++i) {
            p.onramp.setArbitrator(arbitrators[i], true);
            p.offramp.setArbitrator(arbitrators[i], true);
        }
        p.onramp.completeSetup();
        p.offramp.completeSetup();
        if (governor != msg.sender) {
            p.onramp.transferGovernor(governor);
            p.offramp.transferGovernor(governor);
        }
        vm.stopBroadcast();

        _assertCopied(address(oldOn), address(p.onramp), movva, zktls, arbitrators, governor, "on-ramp");
        _assertCopied(address(oldOff), address(p.offramp), movva, zktls, arbitrators, governor, "off-ramp");
        require(
            p.onramp.POOL_ENTRYPOINT() == oldOn.POOL_ENTRYPOINT() && p.onramp.POOL() == oldOn.POOL(),
            "on-ramp: not on the live pair's pool"
        );
        require(
            p.onramp.TAKER_DISPUTE_TIMEOUT() == takerTimeout && p.onramp.MAX_VETTING_FEE_BPS() == feeCap,
            "on-ramp: taker dispute timeout or vetting fee cap differs"
        );
        console2.log("movva FiatEscrow   ", address(p.onramp));
        console2.log("movva OffRampEscrow", address(p.offramp));
        console2.log("  TAKER_DISPUTE_TIMEOUT (s)", takerTimeout);
        console2.log("  MAX_VETTING_FEE_BPS      ", feeCap);
    }

    /// @dev The live pair's value if its on-ramp has the getter (code from the H-02/H-04 fixes on), the
    ///      default otherwise; either way the environment variable, when set, wins. Logged by the caller.
    function _onrampParam(address oldOn, string memory name, uint256 dflt) private view returns (uint256) {
        (bool ok, bytes memory ret) = oldOn.staticcall(abi.encodeWithSignature(string.concat(name, "()")));
        return vm.envOr(name, ok && ret.length == 32 ? abi.decode(ret, (uint256)) : dflt);
    }

    /// @dev On mainnet the governor must be a contract (a Safe, a timelock) and not the deploying key.
    function _refuseKeyGovernor(address governor, address deployer) private view {
        if (block.chainid != 1) return;
        require(governor.code.length > 0, "governor: no code; on mainnet it must be a Safe or timelock, not a key");
        require(governor != deployer, "governor: the deployer; on mainnet hand the pair to a separate Safe or timelock");
    }

    function _refuseBadInputs(
        FiatEscrow oldOn,
        OffRampEscrow oldOff,
        address movva,
        address zktls,
        address[] memory arbitrators
    ) private view {
        require(address(oldOn).code.length > 0 && address(oldOff).code.length > 0, "OLD_ONRAMP / OLD_OFFRAMP: no code");
        require(oldOn.REGISTRY() == oldOff.REGISTRY(), "the live pair is on two registries");
        LPRegistry registry = LPRegistry(address(oldOn.REGISTRY()));
        require(registry.isEscrow(address(oldOn)) && registry.isEscrow(address(oldOff)), "the live pair is not registered");
        require(oldOn.governor() == oldOff.governor(), "the live pair has two governors");
        require(oldOn.allowedVerifier(zktls) && oldOff.allowedVerifier(zktls), "ZKTLS_VERIFIER: not allowed on the live pair");
        (, , bool onEnabled) = _assetOf(address(oldOn), movva);
        (, , bool offEnabled) = _assetOf(address(oldOff), movva);
        require(onEnabled && offEnabled, "MOVVA_TOKEN: not listed on the live pair");
        require(arbitrators.length > 0, "ARBITRATORS: none; every dispute would wait out the timeout");
        for (uint256 i; i < arbitrators.length; ++i) {
            require(arbitrators[i] != address(0), "ARBITRATORS: zero address");
            for (uint256 j; j < i; ++j) require(arbitrators[i] != arbitrators[j], "ARBITRATORS: duplicate");
        }
    }

    function _copyAsset(address from, address to, address asset) private {
        (address oracle, uint8 dec, bool enabled) = _assetOf(from, asset);
        require(dec != 0, "the live pair never configured this asset");
        FiatEscrow(payable(to)).setAsset(asset, oracle, dec, enabled);
        uint256 cap = FiatEscrow(payable(from)).assetCap(asset);
        if (cap != 0) FiatEscrow(payable(to)).setAssetCap(asset, cap);
    }

    /// @dev Both escrows' getters share selectors (assets, assetCap, governor, ...), so FiatEscrow's serve both.
    function _assertCopied(
        address from,
        address to,
        address movva,
        address zktls,
        address[] memory arbitrators,
        address governor,
        string memory name
    ) private view {
        FiatEscrow o = FiatEscrow(payable(from));
        FiatEscrow n = FiatEscrow(payable(to));
        require(_handedTo(address(n), governor), string.concat(name, ": not handed to the live governor"));
        require(n.setupComplete(), string.concat(name, ": setup still open"));
        require(n.pendingChanges() == 0, string.concat(name, ": a change is already scheduled"));
        require(n.GOVERNANCE_DELAY() == o.GOVERNANCE_DELAY(), string.concat(name, ": governance delay differs"));
        require(n.DISPUTE_TIMEOUT() == o.DISPUTE_TIMEOUT(), string.concat(name, ": dispute timeout differs"));
        require(n.BAND_BPS() == o.BAND_BPS(), string.concat(name, ": band differs"));
        require(n.ORACLE() == o.ORACLE() && n.REGISTRY() == o.REGISTRY(), string.concat(name, ": oracle or registry differs"));
        require(n.allowedVerifier(zktls), string.concat(name, ": verifier not allowed"));
        require(_sameAsset(from, to, address(0)) && _sameAsset(from, to, movva), string.concat(name, ": an asset listing or cap differs"));
        for (uint256 i; i < arbitrators.length; ++i) {
            require(n.arbitratorSince(arbitrators[i]) != 0, string.concat(name, ": an arbitrator is missing"));
        }
        require(!LPRegistry(address(n.REGISTRY())).isEscrow(to), string.concat(name, ": registered already"));
    }

    function _sameAsset(address from, address to, address a) private view returns (bool) {
        (address oo, uint8 od, bool oe) = _assetOf(from, a);
        (address no, uint8 nd, bool ne) = _assetOf(to, a);
        return oo == no && od == nd && oe == ne
            && FiatEscrow(payable(from)).assetCap(a) == FiatEscrow(payable(to)).assetCap(a);
    }

    function _assetOf(address escrow, address token) private view returns (address oracle, uint8 dec, bool enabled) {
        (bool ok, bytes memory ret) = escrow.staticcall(abi.encodeWithSignature("assets(address)", token));
        require(ok && ret.length >= 96, "assets(): unreadable");
        (oracle, dec, enabled) = abi.decode(ret, (address, uint8, bool));
    }

    /// @dev Handed over: the governor now, or proposed and waiting to accept (I-36). The governor Safe accepts in the
    ///      same batch that closes setup, so a pending one is what a deploy script leaves behind.
    function _handedTo(address c, address g) internal view returns (bool) {
        return DelayedGovernance(c).governor() == g || DelayedGovernance(c).pendingGovernor() == g;
    }
}
