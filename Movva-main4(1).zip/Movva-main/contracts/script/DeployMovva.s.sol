// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Script} from "forge-std/Script.sol";
import {console2} from "forge-std/console2.sol";
import {IERC4626} from "@openzeppelin/contracts/interfaces/IERC4626.sol";
import {Movva} from "../movva/Movva.sol";
import {MovvaReserve} from "../movva/MovvaReserve.sol";
import {ScaledFxBandOracle} from "../movva/ScaledFxBandOracle.sol";
import {FeeSplitter} from "../movva/FeeSplitter.sol";
import {NodeRewards} from "../ramp/NodeRewards.sol";
import {SignedPriceOracle} from "../ramp/SignedPriceOracle.sol";
import {PythFxOracle} from "../ramp/PythFxOracle.sol";
import {ChainlinkFxOracle} from "../ramp/ChainlinkFxOracle.sol";
import {IPriceOracle} from "../ramp/IPriceOracle.sol";
import {IAggregatorV3} from "../ramp/ChainlinkBrlOracle.sol";
import {DivergenceBreaker} from "../movva/DivergenceBreaker.sol";
import {IPriceSource} from "../movva/IPriceSource.sol";
import {UniswapV3TwapSource} from "../movva/sources/UniswapV3TwapSource.sol";
import {ChainlinkCrossSource} from "../movva/sources/ChainlinkCrossSource.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";

/**
 * @notice Deploy Movva: the reserve (which deploys the token), the FX leg in millionths - a
 *         PythFxOracle over Pyth's FX.USD/BRL by default, a keyless ChainlinkFxOracle over Chainlink
 *         BRL/USD (MOVVA_FX_SOURCE=chainlink), a signed quorum's, or an existing one - and
 *         the centavo adapter the ramps' band reads, and node-provider rewards (a FeeSplitter as the
 *         reserve's fee recipient, feeding NodeRewards) - wired, setup closed, handed to the governor, and
 *         checked.
 *
 * As DeployRamp: the deployer owns everything while wiring, closes setup, then hands over, and the
 * script asserts the result and reverts on anything half-configured. After it, adding a gateway,
 * raising a cap or fee, lowering a ratio, or changing the vault, oracle, yield recipient or fee
 * recipient takes MOVVA_GOVERNANCE_DELAY - including for the real governor on day one. Phase A
 * gateways known at deploy time are admitted here instead (MOVVA_GATEWAYS).
 *
 * ## The principal-locked reserve (client rule, 21 October 2026)
 *
 * The reserve has no hedge withdrawal, no treasurer and no hedge treasury: its USDT leaves only by
 * redemption (gateways, the off-ramp's LPs) and, above max(principal, liabilities at the target),
 * by `harvestYield` to MOVVA_YIELD_RECIPIENT - Mova's Safe. It defaults to MOVVA_FEE_RECIPIENT (the
 * treasury) off mainnet; on chain id 1 it must be a contract. The env names of the removed hedge path
 * (MOVVA_TREASURER, MOVVA_HEDGE_TREASURY, MOVVA_HEDGE_LIMIT_BPS, MOVVA_MIN_WITHDRAW_RATIO_BPS,
 * MOVVA_HEDGE_QUEUE_DELAY) are refused if set, so a stale environment cannot read as configured.
 *
 * ## Hand-over before completeSetup (MOVVA_LEAVE_SETUP_OPEN=yes)
 *
 * The client's M-07 (21 October 2026): the governor Safe, not the deployer, closes setup. With
 * MOVVA_LEAVE_SETUP_OPEN=yes the script wires everything as the deployer, hands every governed contract
 * to MOVVA_GOVERNOR with setup still OPEN, and asserts exactly that; the governor then calls
 * `completeSetup()` on each (scripts/deploy-movva-rail.ts does it as one Safe batch). Until it does, every
 * contract refuses user business, and every change is instant for the governor alone - not for the deployer.
 * The default (no) closes setup here first, as before.
 *
 * ## What it refuses
 *
 *  - on Ethereum mainnet (chain id 1), a MOVVA_GOVERNOR that is the deployer or has no code: the governor
 *    must be a Safe or a timelock, independent of the key that deploys (M-07);
 *  - no supply cap, or zero: "no cap" must be a decision, and the contract has no such setting;
 *  - a zero max age on either oracle leg;
 *  - a Chainlink USDT/USD feed that answers zero or less, reverts, or is already older than its max
 *    age - at deploy, with the real feed;
 *  - an existing FX leg (MOVVA_FX_E6_ORACLE) whose setup is still open, or whose governance delay is
 *    shorter than the reserve's: its governor could change who signs the rate with less notice than
 *    the reserve gives for anything else;
 *  - an existing FX leg with no fresh price, or one outside R$ 1-100 per dollar at 1e-6: that is the
 *    ramps' centavo instance, or a publisher signing the wrong unit;
 *  - a Chainlink leg (MOVVA_FX_SOURCE=chainlink) whose feed is not described "BRL / USD", does not have
 *    the expected decimals (8), has no answer within its max age on this chain, or inverts outside its
 *    range; a max age that does not cover the feed's daily heartbeat (25 hours to 2 days, on the reserve
 *    and the leg alike); and a breaker whose Chainlink source reads the same BRL/USD feed, which would
 *    compare the leg with itself;
 *  - an unknown MOVVA_FX_SOURCE, or MOVVA_FX_SOURCE=chainlink alongside MOVVA_FX_E6_ORACLE or
 *    MOVVA_FX_PUBLISHERS: one FX leg, chosen once;
 *  - a yield vault whose asset is not USDT, or whose own setup is still open;
 *  - collateral ratios out of order (mint floor <= target, see setCollateralRatios);
 *  - on chain id 1, a MOVVA_YIELD_RECIPIENT with no code (it must be Mova's Safe); anywhere, the reserve itself;
 *  - any env name of the removed hedge path (above), set;
 *  - fees above the reserve's hard caps and ratios below 100% (the reserve refuses those itself);
 *  - an LP reward share above 5,000 bps, a reward rate above 20 bps of volume, an epoch outside 1-28 days
 *    or a review period outside 1-14 days (the splitter and NodeRewards refuse those too).
 *
 * ## Environment
 *
 * Every name is prefixed MOVVA_: forge runs tests in parallel in one process, environment variables
 * are process-wide, and DeployRamp.t.sol sets GOVERNOR and PRICE_PUBLISHERS.
 *
 *   MOVVA_GOVERNOR, MOVVA_GUARDIAN, MOVVA_FEE_RECIPIENT
 *   MOVVA_YIELD_RECIPIENT=0x..     Mova's Safe, the only payee of harvestYield (default MOVVA_FEE_RECIPIENT;
 *                                  on chain id 1 required to have code)
 *   MOVVA_LEAVE_SETUP_OPEN=no      yes: hand over with setup open, for the governor to close
 *   MOVVA_USDT=0xdAC17F958D2ee523a2206206994597C13D831ec7
 *   MOVVA_USDT_USD_FEED=0x3E7d1eAB13ad0104d2750B8863b489D65364e32D  MOVVA_USDT_USD_MAX_AGE=90000
 *   MOVVA_FX_MAX_AGE=3600          the rate's max age, on the reserve and on a new Pyth or Chainlink leg
 *                                  alike (default 3600 for Pyth; 93600, 26 hours, for Chainlink)
 *   The FX leg, one of four:
 *   MOVVA_PYTH=0x4305FB66699C3B2702D4d05CF36551390A4c69C6   deploy a PythFxOracle (the default path;
 *     MOVVA_PYTH_USD_BRL_ID defaults to FX.USD/BRL, MOVVA_PYTH_MAX_CONF_BPS=100,
 *     MOVVA_FX_CLOSED_MAX_AGE=345600: how old a last close a band takes off-hours, at most 4 days).
 *     It prices once the Pyth keeper (packages/yield, pyth-keeper) has posted the feed on this chain.
 *   MOVVA_FX_SOURCE=chainlink      a keyless ChainlinkFxOracle instead (Pyth stays the default, MOVVA_FX_SOURCE=pyth):
 *     MOVVA_CHAINLINK_BRL_USD=0x3126E7F38D5f60f4E2B6ec3511C7bdbD79317Df1   the mainnet proxy, required (Sepolia has
 *     no BRL/USD feed), MOVVA_CHAINLINK_BRL_USD_DECIMALS=8, MOVVA_FX_CLOSED_MAX_AGE=345600 as for Pyth, and its
 *     immutable sanity range MOVVA_CHAINLINK_FX_MIN_E6=1000000 MOVVA_CHAINLINK_FX_MAX_E6=100000000 (the reserve's).
 *     It prices at once - Chainlink pushes - and its rate refuses outside FxMarketHours' core session.
 *   MOVVA_FX_E6_ORACLE=0x..        an existing leg in millionths, or
 *   MOVVA_FX_PUBLISHERS=0x..,0x..  MOVVA_FX_THRESHOLD=2   a signed quorum's leg (no price until signed)
 *   MOVVA_SUPPLY_CAP=1000000       whole Movva (required)
 *   MOVVA_YIELD_VAULT=0x..         YieldVault(USDT), optional
 *   MOVVA_GATEWAYS=0x..,0x..       Phase A LPs, optional
 *   MOVVA_MINT_FEE_BPS=10  MOVVA_REDEEM_FEE_BPS=10  set at construction, never below
 *   MOVVA_MIN_ROUND_TRIP_FEE_BPS=20  together, immutable (N-06, L-20)
 *   MOVVA_MAX_VAULT_BPS=9000       most of the reserve the yield vault may hold; the rest stays idle (N-03)
 *   MOVVA_TRADE_FX_MAX_AGE=300     a Pyth or signed leg's oldest price a mint or redemption takes (N-06);
 *                                  zero, and not settable, for a Chainlink leg
 *   MOVVA_ORACLE_EXIT_DELAY=604800 MOVVA_GATEWAY_EXIT_DELAY=2592000   the keyless exit's clocks (N-01, N-02)
 *   MOVVA_GATEWAY_COUNCIL=0x..     may add a gateway after the delay and remove one at once; none by default
 *   MOVVA_TARGET_RATIO_BPS=10800  MOVVA_MIN_MINT_RATIO_BPS=10000  MOVVA_GOVERNANCE_DELAY=172800
 *   There is no savings product (client decision D1, 14 October 2026): the reserve has no sMovva, no
 *   `distribute` and no distribution fee; only the yield above the harvest floor reaches Mova.
 *   Node-provider rewards (docs/movva.md, "Fees"). The reserve pays its fees, in USDT (v3.1 N-27), to a
 *   FeeSplitter, which forwards the LPs' share to NodeRewards and the rest to MOVVA_FEE_RECIPIENT, Mova's
 *   treasury. NodeRewards pays in USDT too, and forfeits what it cannot pay to the same treasury (I-52):
 *   MOVVA_LP_REWARD_SHARE_BPS=0            the LPs' share of Mova's fees: none until Mova chooses. At most 5000;
 *                                          raising it after deployment waits out the delay, lowering it does not
 *   MOVVA_LP_REWARD_BPS_OF_VOLUME=10       an epoch pays at most this share of its settled volume (at most 20)
 *   MOVVA_LP_REWARD_CAP_PER_EPOCH=2000     whole USDT: the most one LP is paid for one epoch
 *   MOVVA_LP_REWARD_USDT_PER_CENT=2000     USDT base units counted per settled centavo (R$ 5,00 per US$ 1):
 *                                          the reference rate of the reward bound, not a price anything pays at
 *   MOVVA_LP_REWARD_MIN_CENTS=1000         settlements under R$ 10,00 are not counted
 *   MOVVA_LP_REWARD_EPOCH_SECONDS=604800   one epoch, a week (1 to 28 days)
 *   MOVVA_LP_REWARD_REVIEW_SECONDS=259200  after an epoch ends, how long its volume can still be voided (1 to 14 days)
 *   NodeRewards counts nothing until a registry is bound to it: DeployRamp with NODE_REWARDS sets the registry's
 *   hook, and the governor then binds that registry (`admin rewards:registry <rewards> <registry>`, immediate
 *   while NodeRewards has never been funded, a scheduled change afterwards).
 *   The divergence breaker (docs/movva.md, "The divergence breaker"): keyless and self-clearing, so every
 *   setting is an immutable chosen HERE. On by default; at least one source is required, or say
 *   MOVVA_BREAKER=off - "no breaker" must be a decision, as "no cap" is.
 *   MOVVA_BREAKER_BAND_BPS=300             halt while the compared rates differ by more than this (1 to 9999)
 *   MOVVA_BREAKER_HALTS_REDEEM=true        false keeps redemptions open while mint and harvests halt
 *   MOVVA_BREAKER_DEAD_AFTER=2592000       a tripping source dead this long (on a claim anyone may `poke`, withdrawn by
 *                                          any read that answers) stops counting for redemptions, so a retired feed or
 *                                          pool can never lock exits for good (SRM1-7). Mint and harvests still
 *                                          halt on it. 7 to 365 days; 30 days by default
 *   MOVVA_BREAKER_BRL_USD_FEED=0x..        a Chainlink BRL/USD feed: source 1, crossed with USDT/USD (independent of Pyth)
 *     MOVVA_BREAKER_BRL_USD_MAX_AGE=90000  MOVVA_BREAKER_CHAINLINK_TRIPS=true
 *   MOVVA_BREAKER_TWAP_POOL=0x..  MOVVA_BREAKER_TWAP_BRL_TOKEN=0x..   a Uniswap v3 USDT/BRL-stablecoin pool: source 2
 *     MOVVA_BREAKER_TWAP_WINDOW=1800  MOVVA_BREAKER_TWAP_MIN_LIQUIDITY=1000000000000  MOVVA_BREAKER_TWAP_TRIPS=true
 *     (TRIPS=false makes a source informational only: it cannot halt anything. A thin TWAP that trips is a
 *     denial-of-service lever; see the doc.)
 *   MOVVA_BREAKER_EXTRA_SOURCES=0x..,0x..  already-deployed IPriceSource contracts, all tripping
 *   forge script contracts/script/DeployMovva.s.sol:DeployMovva --rpc-url $RPC --broadcast
 *
 * Defaults are docs/movva.md's proposals. A new FX leg gets MOVVA_GOVERNANCE_DELAY too, and its setup
 * is closed here like the reserve's, so adding a publisher or lowering its threshold waits as long as
 * any reserve change. Pointing the ramps' USDT band at the same signed number is a separate, delayed
 * step on the ramps: `gov:schedule oracle:fx-legs <usdtOracle> <feed> <band adapter> ...`. Listing
 * Movva on the ramps, with the reserve as its band, is DeployRamp's MOVVA_RESERVE / MOVVA_TOKEN path,
 * using the two addresses this script reports.
 */
/// @dev Chainlink proxies' `description()`, which IAggregatorV3 leaves out; read in the Chainlink leg's preflight.
interface IChainlinkDescribed {
    function description() external view returns (string memory);
}

contract DeployMovva is Script {
    struct Deployed {
        MovvaReserve reserve;
        Movva movva;
        address fx;
        bool fxDeployedHere;
        ScaledFxBandOracle band;
        /// True when the leg deployed here is a PythFxOracle rather than a signed quorum's.
        bool fxIsPyth;
        /// The reserve's fee recipient, and the node-provider rewards it funds.
        FeeSplitter splitter;
        NodeRewards rewards;
        /// The self-clearing divergence breaker the reserve reads; zero when MOVVA_BREAKER=off.
        DivergenceBreaker breaker;
        /// True when the leg deployed here is a keyless ChainlinkFxOracle: nothing to close or hand over.
        bool fxIsChainlink;
    }

    /// @notice Pyth's FX.USD/BRL price id: reais per US dollar. The same on every chain Pyth serves.
    bytes32 internal constant PYTH_FX_USD_BRL = 0xd2db4dbf1aea74e0f666b0e8f73b9580d407f5e5cf931940b06dc633d7a95906;
    /// @notice Chainlink BRL/USD's decimals on Ethereum mainnet (feeds-mainnet.json, verified 19 October 2026).
    uint8 internal constant CHAINLINK_BRL_USD_DECIMALS = 8;
    /// @notice The Chainlink leg's default max age: the 24-hour heartbeat and two hours.
    uint64 internal constant CHAINLINK_FX_MAX_AGE = 26 hours;
    /// @notice USDT base units per BRL centavo for the reward bound: NodeRewards' TOKEN_PER_CENT (N-27).
    function _usdtPerCent() internal view returns (uint256) {
        return vm.envOr("MOVVA_LP_REWARD_USDT_PER_CENT", uint256(2_000));
    }

    function run() external returns (Deployed memory d) {
        address governor = vm.envAddress("MOVVA_GOVERNOR");
        _refuseUnsafeConfig();
        _refuseUnsafeRewards();
        _minRoundTripFee(); // I-05, refused with the broadcast closed

        bool leaveOpen = _leaveSetupOpen();

        vm.startBroadcast();
        (, address deployer,) = vm.readCallers();
        // Read inside the broadcast, where the deployer is known; stopped first, so a refusal leaves no broadcast open.
        string memory unsafeGovernor = _unsafeGovernor(governor, deployer);
        if (bytes(unsafeGovernor).length != 0) {
            vm.stopBroadcast();
            revert(unsafeGovernor);
        }
        d = _deploy(deployer);
        _wire(d);
        if (!leaveOpen) {
            d.reserve.completeSetup();
            // Before the hand-over, like the reserve's: the deployer must not leave a leg whose feed,
            // limits or publishers the real governor could change without the delay.
            if (d.fxDeployedHere && !d.fxIsChainlink) DelayedGovernance(d.fx).completeSetup();
            // And the fees' destination: a share or a treasury changed without notice moves Mova's revenue.
            d.splitter.completeSetup();
            d.rewards.completeSetup();
        }
        // MOVVA_LEAVE_SETUP_OPEN=yes: handed over with setup still open, so the governor itself closes it
        // (`completeSetup` on each, see "Hand-over before completeSetup" above).
        d.reserve.transferGovernor(governor);
        if (d.fxDeployedHere && !d.fxIsChainlink) DelayedGovernance(d.fx).transferGovernor(governor);
        d.splitter.transferGovernor(governor);
        d.rewards.transferGovernor(governor);
        vm.stopBroadcast();

        _assertWired(d, governor, !leaveOpen);
        _report(d);
    }

    /*//////////////////////////////////////////////////////////////
                                 CHECKS
    //////////////////////////////////////////////////////////////*/

    function _refuseUnsafeConfig() private view {
        require(_supplyCap() > 0, "MOVVA_SUPPLY_CAP: a supply cap of zero is not a cap; set one, in whole Movva");
        require(vm.envAddress("MOVVA_USDT").code.length > 0, "MOVVA_USDT: no contract at that address on this chain");

        IAggregatorV3 feed = IAggregatorV3(vm.envAddress("MOVVA_USDT_USD_FEED"));
        uint64 feedAge = _age("MOVVA_USDT_USD_MAX_AGE", 25 hours);
        (, int256 answer,, uint256 at,) = feed.latestRoundData();
        require(answer > 0, "MOVVA_USDT_USD_FEED: feed answers zero or less");
        require(at != 0 && block.timestamp <= at + feedAge, "MOVVA_USDT_USD_FEED: feed is older than its max age");
        require(feed.decimals() <= 18, "MOVVA_USDT_USD_FEED: feed decimals out of range");
        uint256 one = 10 ** feed.decimals();
        require(
            uint256(answer) * 2 >= one && uint256(answer) * 2 <= 3 * one,
            "MOVVA_USDT_USD_FEED: answer outside US$ 0.50 to 1.50 (not a dollar stablecoin feed, or the wrong one)"
        );
        require(feedAge >= 1 days, "MOVVA_USDT_USD_MAX_AGE: at least 1 day (the reserve refuses less: SRM1-20)");

        uint64 fxAge = _fxMaxAge();
        require(fxAge >= 15 minutes, "MOVVA_FX_MAX_AGE: at least 15 minutes (the reserve refuses less: SRM1-20)");
        address existing = vm.envOr("MOVVA_FX_E6_ORACLE", address(0));
        if (_fxIsChainlink()) {
            require(
                existing == address(0) && vm.envOr("MOVVA_FX_PUBLISHERS", ",", new address[](0)).length == 0,
                "MOVVA_FX_SOURCE=chainlink: unset MOVVA_FX_E6_ORACLE and MOVVA_FX_PUBLISHERS, one FX leg is chosen once"
            );
            _refuseUnsafeChainlinkLeg(fxAge);
        } else if (existing == address(0) && vm.envOr("MOVVA_FX_PUBLISHERS", ",", new address[](0)).length == 0) {
            // The Pyth leg. It may have no price yet - the keeper posts it - so only its inputs are checked.
            require(
                vm.envOr("MOVVA_PYTH", address(0)).code.length > 0,
                "MOVVA_PYTH: no Pyth contract at that address on this chain (or set MOVVA_FX_E6_ORACLE / MOVVA_FX_PUBLISHERS)"
            );
            require(
                _closedMaxAge() <= 4 days,
                "MOVVA_FX_CLOSED_MAX_AGE: above 4 days, which is no longer a market closure"
            );
        }
        if (existing != address(0)) {
            // First, and by name: an FX leg still in setup refuses to price (SetupIncomplete), and
            // one whose governance is not a DelayedGovernance at all has no `setupComplete` to ask.
            (bool ok, bytes memory ret) = existing.staticcall(abi.encodeWithSignature("setupComplete()"));
            require(
                ok && ret.length >= 32 && abi.decode(ret, (bool)),
                "MOVVA_FX_E6_ORACLE: setup still open, or its governance is not delayed: its governor could change who signs the rate at once"
            );
            require(
                DelayedGovernance(existing).GOVERNANCE_DELAY() >= _governanceDelay(),
                "MOVVA_FX_E6_ORACLE: governance delay shorter than MOVVA_GOVERNANCE_DELAY, so a publisher change would give holders less notice"
            );
            (uint256 e6, uint64 published) = IPriceOracle(existing).brlCentsPerUnit();
            require(
                e6 >= 1e6 && e6 <= 100e6,
                "MOVVA_FX_E6_ORACLE: not BRL per USD at 1e-6 (the ramps' centavo instance, or the wrong unit signed)"
            );
            require(block.timestamp <= uint256(published) + fxAge, "MOVVA_FX_E6_ORACLE: no price within MOVVA_FX_MAX_AGE");
        }

        require(
            !_breakerOn() || _breakerSourceCount() > 0,
            "MOVVA_BREAKER: no source configured (MOVVA_BREAKER_BRL_USD_FEED / _TWAP_POOL / _EXTRA_SOURCES); say MOVVA_BREAKER=off to deploy without a breaker"
        );
        string[5] memory removed = [
            "MOVVA_TREASURER", "MOVVA_HEDGE_TREASURY", "MOVVA_HEDGE_LIMIT_BPS", "MOVVA_MIN_WITHDRAW_RATIO_BPS", "MOVVA_HEDGE_QUEUE_DELAY"
        ];
        for (uint256 i; i < removed.length; ++i) {
            require(
                bytes(vm.envOr(removed[i], string(""))).length == 0,
                string.concat(removed[i], ": removed with the principal-locked reserve (21 October 2026); unset it")
            );
        }
        require(
            block.chainid != 1 || _yieldRecipient().code.length > 0,
            "MOVVA_YIELD_RECIPIENT: on chain id 1 it must be Mova's Safe (a contract), set explicitly or as MOVVA_FEE_RECIPIENT"
        );
        require(
            !_breakerOn() || (_breakerDeadAfter() >= 7 days && _breakerDeadAfter() <= 365 days),
            "MOVVA_BREAKER_DEAD_AFTER: 7 to 365 days"
        );
        // The reserve refuses these too, mid-broadcast; saying why before anything is sent is kinder.
        (uint16 target, uint16 minMint) = _ratios();
        require(minMint <= target, "MOVVA_*_RATIO_BPS: the mint floor may not exceed the target");

        address v = vm.envOr("MOVVA_YIELD_VAULT", address(0));
        if (v != address(0)) {
            require(IERC4626(v).asset() == vm.envAddress("MOVVA_USDT"), "MOVVA_YIELD_VAULT: its asset is not MOVVA_USDT");
            require(DelayedGovernance(v).setupComplete(), "MOVVA_YIELD_VAULT: the vault's own setup is still open");
        }
    }

    /// @dev The Chainlink leg's preflight, against the real feed on the target chain. ChainlinkFxOracle's
    ///      constructor refuses most of these too, mid-broadcast; saying why before anything is sent is kinder,
    ///      and a feed with no fresh answer is refused only here.
    function _refuseUnsafeChainlinkLeg(uint64 fxAge) private view {
        address feed = vm.envOr("MOVVA_CHAINLINK_BRL_USD", address(0));
        require(
            feed.code.length > 0,
            "MOVVA_CHAINLINK_BRL_USD: no contract at that address on this chain (mainnet: 0x3126E7F38D5f60f4E2B6ec3511C7bdbD79317Df1; Sepolia has no BRL/USD feed)"
        );
        // A retired proxy answers a contract `No access` (0x0eBDc65E7e9132Cb41ac5cbD0101B799D7aDb475 does): say so.
        (bool readable,) = feed.staticcall(abi.encodeCall(IAggregatorV3.latestRoundData, ()));
        require(
            readable,
            "MOVVA_CHAINLINK_BRL_USD: the feed refuses a contract reader - a retired proxy answers No access; use the live one"
        );
        require(
            keccak256(bytes(IChainlinkDescribed(feed).description())) == keccak256("BRL / USD"),
            "MOVVA_CHAINLINK_BRL_USD: its description is not BRL / USD (the wrong feed, or an inverted pair)"
        );
        require(
            IAggregatorV3(feed).decimals() == _chainlinkDecimals(),
            "MOVVA_CHAINLINK_BRL_USD: decimals differ from MOVVA_CHAINLINK_BRL_USD_DECIMALS (8 on mainnet)"
        );
        require(
            fxAge >= 25 hours && fxAge <= 2 days,
            "MOVVA_FX_MAX_AGE: 25 hours to 2 days for a Chainlink leg, to cover the feed's daily heartbeat on the reserve and the leg alike"
        );
        uint64 closed = _closedMaxAge();
        require(closed >= fxAge && closed <= 4 days, "MOVVA_FX_CLOSED_MAX_AGE: from MOVVA_FX_MAX_AGE to 4 days for a Chainlink leg");
        (uint256 lo, uint256 hi) = _chainlinkRange();
        require(
            lo >= 1e6 && hi <= 100e6 && lo < hi,
            "MOVVA_CHAINLINK_FX_MIN_E6 / _MAX_E6: a range inside R$ 1-100 per dollar at 1e-6, min below max"
        );
        (, int256 answer,, uint256 at,) = IAggregatorV3(feed).latestRoundData();
        require(answer > 0 && at != 0, "MOVVA_CHAINLINK_BRL_USD: the feed answers zero or less, or has no completed round");
        require(
            block.timestamp <= at + fxAge && at <= block.timestamp + 5 minutes,
            "MOVVA_CHAINLINK_BRL_USD: no answer within MOVVA_FX_MAX_AGE on this chain (the feed missed its heartbeat)"
        );
        uint256 e6 = 10 ** (6 + uint256(_chainlinkDecimals())) / uint256(answer);
        require(e6 >= lo && e6 <= hi, "MOVVA_CHAINLINK_BRL_USD: its answer inverts outside the sanity range");
        require(
            vm.envOr("MOVVA_BREAKER_BRL_USD_FEED", address(0)) != feed,
            "MOVVA_BREAKER_BRL_USD_FEED: the FX leg's own feed, so the breaker would compare the leg with itself; use an independent source"
        );
    }

    /// @dev M-07: on Ethereum mainnet the governor every contract here ends with must be a contract (a Safe or a
    ///      timelock) and not the deployer: a key that deploys is a key that is online. Elsewhere a rehearsal may
    ///      name any address, and the deploy record says which.
    function _unsafeGovernor(address governor, address deployer) private view returns (string memory) {
        if (block.chainid != 1) return "";
        if (governor == deployer) {
            return "MOVVA_GOVERNOR: on chain id 1 the governor is the deployer; name the governor Safe or timelock";
        }
        if (governor.code.length == 0) {
            return "MOVVA_GOVERNOR: on chain id 1 the governor must be a contract (a Safe or a timelock), not a key";
        }
        return "";
    }

    /// @dev "no" (the default; unset or empty) or "yes"; anything else is refused rather than read as either.
    function _leaveSetupOpen() private view returns (bool) {
        bytes32 v = keccak256(bytes(vm.envOr("MOVVA_LEAVE_SETUP_OPEN", string("no"))));
        require(v == keccak256("no") || v == keccak256("") || v == keccak256("yes"), "MOVVA_LEAVE_SETUP_OPEN: yes or no");
        return v == keccak256("yes");
    }

    function _refuseUnsafeRewards() private view {
        require(
            _bps("MOVVA_LP_REWARD_SHARE_BPS", 0) <= 5_000,
            "MOVVA_LP_REWARD_SHARE_BPS: above 5000, the splitter's cap on the LPs' share of Mova's fees"
        );
        (uint16 rate,,) = _rewardLimits();
        require(rate <= 20, "MOVVA_LP_REWARD_BPS_OF_VOLUME: above 20, more per real settled than the mint and redeem fees together");
        uint256 epoch = _epochSeconds();
        require(epoch >= 1 days && epoch <= 28 days, "MOVVA_LP_REWARD_EPOCH_SECONDS: an epoch is 1 to 28 days");
        uint256 review = _reviewSeconds();
        require(review >= 1 days && review <= 14 days, "MOVVA_LP_REWARD_REVIEW_SECONDS: a review period is 1 to 14 days");
    }

    /*//////////////////////////////////////////////////////////////
                                 DEPLOY
    //////////////////////////////////////////////////////////////*/

    function _deploy(address owner) private returns (Deployed memory d) {
        d.fx = vm.envOr("MOVVA_FX_E6_ORACLE", address(0));
        if (d.fx == address(0)) {
            address[] memory publishers = vm.envOr("MOVVA_FX_PUBLISHERS", ",", new address[](0));
            if (publishers.length > 0) {
                uint256 t = vm.envOr("MOVVA_FX_THRESHOLD", uint256(2));
                _requireMajority(t, publishers.length, "MOVVA_FX_THRESHOLD");
                d.fx = address(new SignedPriceOracle(owner, _governanceDelay(), publishers, t));
            } else if (_fxIsChainlink()) {
                (uint256 lo, uint256 hi) = _chainlinkRange();
                d.fx = address(
                    new ChainlinkFxOracle(vm.envAddress("MOVVA_CHAINLINK_BRL_USD"), _fxMaxAge(), _closedMaxAge(), lo, hi)
                );
                d.fxIsChainlink = true;
            } else {
                d.fx = address(
                    new PythFxOracle(
                        vm.envAddress("MOVVA_PYTH"),
                        vm.envOr("MOVVA_PYTH_USD_BRL_ID", PYTH_FX_USD_BRL),
                        _fxMaxAge(),
                        _closedMaxAge(),
                        _bps("MOVVA_PYTH_MAX_CONF_BPS", 100),
                        owner,
                        _governanceDelay()
                    )
                );
                d.fxIsPyth = true;
            }
            d.fxDeployedHere = true;
        }
        d.breaker = _deployBreaker();
        d.reserve = new MovvaReserve(
            MovvaReserve.Config({
                usdt: vm.envAddress("MOVVA_USDT"),
                usdtUsdFeed: vm.envAddress("MOVVA_USDT_USD_FEED"),
                fxOracle: d.fx,
                usdtUsdMaxAge: _age("MOVVA_USDT_USD_MAX_AGE", 25 hours),
                fxMaxAge: _fxMaxAge(),
                governor: owner,
                governanceDelay: _governanceDelay(),
                guardian: vm.envAddress("MOVVA_GUARDIAN"),
                feeRecipient: vm.envAddress("MOVVA_FEE_RECIPIENT"),
                yieldRecipient: _yieldRecipient(),
                supplyCap: _supplyCap(),
                breaker: address(d.breaker),
                maxVaultBps: _bps("MOVVA_MAX_VAULT_BPS", 9_000),
                mintFeeBps: _mintFee(),
                redeemFeeBps: _redeemFee(),
                minRoundTripFeeBps: _minRoundTripFee(),
                // N-06: only a pull leg (Pyth, a signed quorum) lets the caller choose the price.
                tradeFxMaxAge: _fxIsChainlink() ? 0 : _age("MOVVA_TRADE_FX_MAX_AGE", 5 minutes),
                oracleExitDelay: _age("MOVVA_ORACLE_EXIT_DELAY", 7 days),
                gatewayExitDelay: _age("MOVVA_GATEWAY_EXIT_DELAY", 30 days),
                gatewayCouncil: vm.envOr("MOVVA_GATEWAY_COUNCIL", address(0))
            })
        );
        d.movva = Movva(d.reserve.MOVVA());
        d.band = new ScaledFxBandOracle(IPriceOracle(d.fx));
        address usdt = vm.envAddress("MOVVA_USDT");
        address treasury = vm.envAddress("MOVVA_FEE_RECIPIENT");
        d.rewards = new NodeRewards(usdt, _usdtPerCent(), _epochSeconds(), _reviewSeconds(), owner, _governanceDelay(), treasury);
        d.splitter = new FeeSplitter(usdt, treasury, address(d.rewards), owner, _governanceDelay());
    }

    /// @notice With a push FX leg (Chainlink BRL/USD, deviation threshold 0.5%) a round trip must cost at least
    ///         that much, or the feed's lag is a free trade against the reserve (v2.0 I-05).
    uint16 internal constant PUSH_LEG_MIN_ROUND_TRIP_FEE_BPS = 50;

    function _minRoundTripFee() internal view returns (uint16 bps) {
        bps = _bps("MOVVA_MIN_ROUND_TRIP_FEE_BPS", _fxIsChainlink() ? PUSH_LEG_MIN_ROUND_TRIP_FEE_BPS : 20);
        require(
            !_fxIsChainlink() || bps >= PUSH_LEG_MIN_ROUND_TRIP_FEE_BPS,
            "MOVVA_MIN_ROUND_TRIP_FEE_BPS: a Chainlink FX leg lags up to 0.5%; the round trip must cost at least 50 bps (I-05)"
        );
        require(
            _mintFee() + _redeemFee() >= bps, "MOVVA_MINT_FEE_BPS + MOVVA_REDEEM_FEE_BPS: below MOVVA_MIN_ROUND_TRIP_FEE_BPS"
        );
    }

    function _breakerOn() internal view returns (bool) {
        return keccak256(bytes(vm.envOr("MOVVA_BREAKER", string("on")))) != keccak256("off");
    }

    /// @dev Mova's Safe. Off mainnet the treasury (MOVVA_FEE_RECIPIENT) by default; on chain id 1 checked to be a contract.
    function _yieldRecipient() internal view returns (address) {
        return vm.envOr("MOVVA_YIELD_RECIPIENT", vm.envAddress("MOVVA_FEE_RECIPIENT"));
    }

    function _breakerBand() internal view returns (uint16) {
        return _bps("MOVVA_BREAKER_BAND_BPS", 300);
    }

    /// @dev SRM1-7: how long a tripping source must be dead before redemptions stop counting it.
    function _breakerDeadAfter() internal view returns (uint64) {
        uint256 v = vm.envOr("MOVVA_BREAKER_DEAD_AFTER", uint256(30 days));
        require(v <= type(uint64).max, "MOVVA_BREAKER_DEAD_AFTER: seconds");
        return uint64(v);
    }

    function _breakerSourceCount() internal view returns (uint256 n) {
        if (vm.envOr("MOVVA_BREAKER_BRL_USD_FEED", address(0)) != address(0)) n++;
        if (vm.envOr("MOVVA_BREAKER_TWAP_POOL", address(0)) != address(0)) n++;
        n += vm.envOr("MOVVA_BREAKER_EXTRA_SOURCES", ",", new address[](0)).length;
    }

    /// @dev The breaker has no owner and no setter: nothing to hand over, nothing to close.
    function _deployBreaker() private returns (DivergenceBreaker b) {
        if (!_breakerOn()) return DivergenceBreaker(address(0));
        uint256 n = _breakerSourceCount();
        DivergenceBreaker.SourceConfig[] memory cfg = new DivergenceBreaker.SourceConfig[](n);
        uint256 i;
        address brlFeed = vm.envOr("MOVVA_BREAKER_BRL_USD_FEED", address(0));
        if (brlFeed != address(0)) {
            cfg[i++] = DivergenceBreaker.SourceConfig(
                IPriceSource(
                    address(
                        new ChainlinkCrossSource(
                            vm.envAddress("MOVVA_USDT_USD_FEED"),
                            brlFeed,
                            _age("MOVVA_USDT_USD_MAX_AGE", 25 hours),
                            _age("MOVVA_BREAKER_BRL_USD_MAX_AGE", 25 hours)
                        )
                    )
                ),
                vm.envOr("MOVVA_BREAKER_CHAINLINK_TRIPS", true)
            );
        }
        address pool = vm.envOr("MOVVA_BREAKER_TWAP_POOL", address(0));
        if (pool != address(0)) {
            cfg[i++] = DivergenceBreaker.SourceConfig(
                IPriceSource(
                    address(
                        new UniswapV3TwapSource(
                            pool,
                            vm.envAddress("MOVVA_USDT"),
                            vm.envAddress("MOVVA_BREAKER_TWAP_BRL_TOKEN"),
                            uint32(vm.envOr("MOVVA_BREAKER_TWAP_WINDOW", uint256(1800))),
                            uint128(vm.envOr("MOVVA_BREAKER_TWAP_MIN_LIQUIDITY", uint256(1e12)))
                        )
                    )
                ),
                vm.envOr("MOVVA_BREAKER_TWAP_TRIPS", true)
            );
        }
        address[] memory extra = vm.envOr("MOVVA_BREAKER_EXTRA_SOURCES", ",", new address[](0));
        for (uint256 j; j < extra.length; ++j) {
            cfg[i++] = DivergenceBreaker.SourceConfig(IPriceSource(extra[j]), true);
        }
        // L-16: a breaker "on" whose every source is informational can never trip; "no breaker" must be MOVVA_BREAKER=off.
        bool anyTrips;
        for (uint256 j; j < cfg.length; ++j) {
            if (cfg[j].trips) anyTrips = true;
        }
        require(anyTrips, "MOVVA_BREAKER: every source is informational (TRIPS=false), so it can never trip; set MOVVA_BREAKER=off instead");
        b = new DivergenceBreaker(
            _breakerBand(), vm.envOr("MOVVA_BREAKER_HALTS_REDEEM", true), _breakerDeadAfter(), cfg
        );
    }

    /// @dev During setup every change is instant, and nobody can hold Movva yet.
    function _wire(Deployed memory d) private {
        address[] memory gateways = vm.envOr("MOVVA_GATEWAYS", ",", new address[](0));
        for (uint256 i; i < gateways.length; ++i) {
            d.reserve.setGateway(gateways[i], true);
        }
        address v = vm.envOr("MOVVA_YIELD_VAULT", address(0));
        if (v != address(0)) d.reserve.setYieldVault(v);
        (uint16 target, uint16 minMint) = _ratios();
        d.reserve.setCollateralRatios(target, minMint);
        _wireRewards(d);
    }

    /// @dev The reserve was constructed paying MOVVA_FEE_RECIPIENT directly, and the splitter after it; here, still in
    ///      setup, the fees are pointed through the splitter. With a share of zero every fee still reaches
    ///      MOVVA_FEE_RECIPIENT, now one `split()` later.
    function _wireRewards(Deployed memory d) private {
        d.reserve.setFeeRecipient(address(d.splitter));
        d.splitter.setLpRewardShare(_bps("MOVVA_LP_REWARD_SHARE_BPS", 0));
        (uint16 rate, uint256 cap, uint256 minCents) = _rewardLimits();
        d.rewards.setRewardLimits(rate, cap, minCents);
    }

    /*//////////////////////////////////////////////////////////////
                                ASSERTIONS
    //////////////////////////////////////////////////////////////*/

    /// @param closed False with MOVVA_LEAVE_SETUP_OPEN=yes: every contract must then still be in setup, for its governor
    ///        to close (a contract closed by anyone else would not be what the deploy record says).
    function _assertWired(Deployed memory d, address governor, bool closed) private view {
        MovvaReserve r = d.reserve;
        require(_handedTo(address(r), governor), "reserve: governor not handed over");
        require(r.setupComplete() == closed, closed ? "reserve: setup still open, changes are instant" : "reserve: setup closed although MOVVA_LEAVE_SETUP_OPEN=yes");
        require(r.GOVERNANCE_DELAY() == _governanceDelay(), "reserve: governance delay differs from MOVVA_GOVERNANCE_DELAY");
        require(d.movva.RESERVE() == address(r), "token: minter is not the reserve");
        require(r.USDT() == vm.envAddress("MOVVA_USDT"), "reserve: wrong USDT");
        require(address(r.usdtUsdFeed()) == vm.envAddress("MOVVA_USDT_USD_FEED"), "reserve: wrong USDT/USD feed");
        require(address(r.fxOracle()) == d.fx && address(d.band.SOURCE()) == d.fx, "FX leg: reserve and band adapter disagree");
        require(
            r.usdtUsdMaxAge() == _age("MOVVA_USDT_USD_MAX_AGE", 25 hours) && r.fxMaxAge() == _fxMaxAge(),
            "reserve: max ages differ from the environment"
        );
        if (d.fxDeployedHere && !d.fxIsChainlink) {
            DelayedGovernance fx = DelayedGovernance(d.fx);
            require(_handedTo(address(fx), governor), "FX leg: governor not handed over, the deployer could change its source");
            require(fx.setupComplete() == closed, closed ? "FX leg: setup still open, its source changes instantly" : "FX leg: setup closed although MOVVA_LEAVE_SETUP_OPEN=yes");
            require(fx.GOVERNANCE_DELAY() == _governanceDelay(), "FX leg: governance delay differs from MOVVA_GOVERNANCE_DELAY");
        }
        if (d.fxIsPyth) {
            PythFxOracle p = PythFxOracle(d.fx);
            require(
                address(p.PYTH()) == vm.envAddress("MOVVA_PYTH") && p.usdBrlId() == vm.envOr("MOVVA_PYTH_USD_BRL_ID", PYTH_FX_USD_BRL),
                "FX leg: not Pyth's FX.USD/BRL on MOVVA_PYTH"
            );
            require(
                p.maxAge() == r.fxMaxAge() && p.closedMaxAge() == _closedMaxAge(),
                "FX leg: max ages differ from the environment"
            );
        }
        if (d.fxIsChainlink) _assertChainlinkLeg(d);
        require(address(r.BREAKER()) == address(d.breaker), "reserve: breaker not wired");
        if (_breakerOn()) {
            require(address(d.breaker) != address(0), "breaker: not deployed");
            require(
                d.breaker.BAND_BPS() == _breakerBand() && d.breaker.sourceCount() == _breakerSourceCount(),
                "breaker: band or sources differ from the environment"
            );
            require(
                d.breaker.HALTS_REDEEM() == vm.envOr("MOVVA_BREAKER_HALTS_REDEEM", true)
                    && d.breaker.DEAD_AFTER() == _breakerDeadAfter(),
                "breaker: HALTS_REDEEM or DEAD_AFTER differ from the environment"
            );
        }
        require(address(r.yieldVault()) == vm.envOr("MOVVA_YIELD_VAULT", address(0)), "reserve: yield vault not wired");
        require(r.guardian() == vm.envAddress("MOVVA_GUARDIAN"), "reserve: guardian differs from the environment");
        require(r.yieldRecipient() == _yieldRecipient(), "reserve: yield recipient differs from MOVVA_YIELD_RECIPIENT");
        require(r.principalUsdt() == 0, "reserve: a principal before any mint");
        require(r.feeRecipient() == address(d.splitter), "reserve: fees are not paid to this deployment's FeeSplitter");
        _assertRewards(d, governor, closed);
        address[] memory gateways = vm.envOr("MOVVA_GATEWAYS", ",", new address[](0));
        for (uint256 i; i < gateways.length; ++i) {
            require(r.isGateway(gateways[i]), "reserve: a gateway in MOVVA_GATEWAYS was not admitted");
        }
        require(r.mintFeeBps() == _mintFee() && r.redeemFeeBps() == _redeemFee(), "reserve: fees differ from the environment");
        require(
            r.MAX_VAULT_BPS() == _bps("MOVVA_MAX_VAULT_BPS", 9_000)
                && r.MIN_ROUND_TRIP_FEE_BPS() == _minRoundTripFee()
                && r.ORACLE_EXIT_DELAY() == _age("MOVVA_ORACLE_EXIT_DELAY", 7 days)
                && r.GATEWAY_EXIT_DELAY() == _age("MOVVA_GATEWAY_EXIT_DELAY", 30 days)
                && r.gatewayCouncil() == vm.envOr("MOVVA_GATEWAY_COUNCIL", address(0)),
            "reserve: vault cap, fee floor, exit delays or gateway council differ from the environment"
        );
        (uint16 target, uint16 minMint) = _ratios();
        require(
            r.targetCollateralRatioBps() == target && r.minMintCollateralRatioBps() == minMint,
            "reserve: collateral ratios differ from the environment"
        );
        require(r.supplyCap() == _supplyCap() && r.supplyCap() > 0, "reserve: supply cap differs from the environment");
        // An existing FX leg was checked fresh above; the reserve must now price with it.
        if (!d.fxDeployedHere) r.brlPerUsdtE18();
    }

    /// @dev Keyless, so nothing to hand over: what it reads and its limits are the environment's, and the reserve
    ///      prices through it now - through the band reading at any hour (the rate refuses outside the core
    ///      session, and a deployment may run at any hour), and through the rate inside the session.
    function _assertChainlinkLeg(Deployed memory d) private view {
        ChainlinkFxOracle c = ChainlinkFxOracle(d.fx);
        (uint256 lo, uint256 hi) = _chainlinkRange();
        require(address(c.FEED()) == vm.envAddress("MOVVA_CHAINLINK_BRL_USD"), "FX leg: not MOVVA_CHAINLINK_BRL_USD");
        require(
            c.MAX_AGE() == d.reserve.fxMaxAge() && c.CLOSED_MAX_AGE() == _closedMaxAge() && c.DECIMALS() == _chainlinkDecimals(),
            "FX leg: max ages or decimals differ from the environment"
        );
        require(c.MIN_BRL_PER_USD_E6() == lo && c.MAX_BRL_PER_USD_E6() == hi, "FX leg: sanity range differs from the environment");
        d.reserve.bandBrlPerUsdtE18();
        if (c.inCoreSession()) d.reserve.brlPerUsdtE18();
    }

    /// @dev The fees' destination, handed over and closed like the reserve, and NodeRewards bound to nothing yet.
    function _assertRewards(Deployed memory d, address governor, bool closed) private view {
        FeeSplitter s = d.splitter;
        NodeRewards n = d.rewards;
        require(_handedTo(address(s), governor) && _handedTo(address(n), governor), "rewards: governor not handed over");
        require(
            s.setupComplete() == closed && n.setupComplete() == closed,
            closed ? "rewards: setup still open, the share or the limits change instantly" : "rewards: setup closed although MOVVA_LEAVE_SETUP_OPEN=yes"
        );
        require(
            s.GOVERNANCE_DELAY() == _governanceDelay() && n.GOVERNANCE_DELAY() == _governanceDelay(),
            "rewards: governance delay differs from MOVVA_GOVERNANCE_DELAY"
        );
        require(
            address(s.TOKEN()) == vm.envAddress("MOVVA_USDT") && address(n.REWARD_TOKEN()) == vm.envAddress("MOVVA_USDT"),
            "rewards: not paid in this deployment's USDT"
        );
        require(n.SINK() == vm.envAddress("MOVVA_FEE_RECIPIENT"), "rewards: forfeits do not go to MOVVA_FEE_RECIPIENT");
        require(s.treasury() == vm.envAddress("MOVVA_FEE_RECIPIENT"), "splitter: treasury differs from MOVVA_FEE_RECIPIENT");
        require(s.rewards() == address(n), "splitter: does not fund this deployment's NodeRewards");
        require(
            s.lpRewardShareBps() == _bps("MOVVA_LP_REWARD_SHARE_BPS", 0), "splitter: LP share differs from MOVVA_LP_REWARD_SHARE_BPS"
        );
        (uint16 rate, uint256 cap, uint256 minCents) = _rewardLimits();
        require(
            n.rewardBpsOfVolume() == rate && n.maxRewardPerLpPerEpoch() == cap && n.minCountedCents() == minCents,
            "rewards: limits differ from the environment"
        );
        require(
            n.TOKEN_PER_CENT() == _usdtPerCent() && n.EPOCH_LENGTH() == _epochSeconds() && n.REVIEW_PERIOD() == _reviewSeconds(),
            "rewards: unit, epoch or review period differs from the environment"
        );
        require(n.registry() == address(0), "rewards: a registry is bound before any ramp was deployed");
    }

    function _report(Deployed memory d) private pure {
        console2.log("MovvaReserve        ", address(d.reserve));
        console2.log("Movva               ", address(d.movva));
        console2.log("FX leg (BRL/USD e6) ", d.fx);
        console2.log("band adapter (cents)", address(d.band));
        console2.log("FeeSplitter         ", address(d.splitter));
        console2.log("NodeRewards         ", address(d.rewards));
        console2.log("DivergenceBreaker   ", address(d.breaker));
        console2.log("  keyless and self-clearing: mint, redeem and harvests halt while sources disagree");
        console2.log("  the reserve pays its fees to the splitter; anyone may split() them to the treasury and NodeRewards");
        console2.log("  NodeRewards counts nothing until DeployRamp sets NODE_REWARDS=%s and the governor binds the registry", address(d.rewards));
        if (d.fxIsPyth) {
            console2.log("  a PythFxOracle: it prices once the Pyth keeper posts FX.USD/BRL on this chain");
            console2.log("  off-hours the ramps take the last close; minting and redeeming wait for the market");
        } else if (d.fxIsChainlink) {
            console2.log("  a keyless ChainlinkFxOracle (no governor) over MOVVA_CHAINLINK_BRL_USD: it prices now");
            console2.log("  off-hours the ramps take the last answer; minting and redeeming wait for the core session");
        } else if (d.fxDeployedHere) {
            console2.log("  the FX leg is new: nothing prices until its publishers sign a rate");
        }
        // What DeployRamp's Movva pair needs, verbatim: it checks the two are bound to each other.
        console2.log("list on the ramps: MOVVA_RESERVE=%s", address(d.reserve));
        console2.log("                   MOVVA_TOKEN=%s", address(d.movva));
    }

    /*//////////////////////////////////////////////////////////////
                                   ENV
    //////////////////////////////////////////////////////////////*/

    /// @dev Unset reads as zero, and zero is refused with a message rather than a cheatcode error.
    function _supplyCap() private view returns (uint256) {
        return vm.envOr("MOVVA_SUPPLY_CAP", uint256(0)) * 1e18;
    }

    function _governanceDelay() private view returns (uint256) {
        return vm.envOr("MOVVA_GOVERNANCE_DELAY", uint256(48 hours));
    }

    function _age(string memory name, uint256 dflt) private view returns (uint64) {
        uint256 v = vm.envOr(name, dflt);
        require(v > 0 && v <= type(uint64).max, string.concat(name, ": a max age is seconds, above zero"));
        return uint64(v);
    }

    /// @dev "pyth" (the default) or "chainlink"; anything else is refused rather than read as the default.
    function _fxIsChainlink() private view returns (bool) {
        bytes32 s = keccak256(bytes(vm.envOr("MOVVA_FX_SOURCE", string("pyth"))));
        require(s == keccak256("pyth") || s == keccak256("chainlink"), "MOVVA_FX_SOURCE: pyth (the default) or chainlink");
        return s == keccak256("chainlink");
    }

    /// @dev The rate's max age, on the reserve and on a leg deployed here alike: an hour for Pyth, whose keeper
    ///      posts within minutes; 26 hours for Chainlink, which a quiet market updates once a day.
    function _fxMaxAge() private view returns (uint64) {
        return _age("MOVVA_FX_MAX_AGE", _fxIsChainlink() ? CHAINLINK_FX_MAX_AGE : 1 hours);
    }

    function _chainlinkDecimals() private view returns (uint8) {
        uint256 v = vm.envOr("MOVVA_CHAINLINK_BRL_USD_DECIMALS", uint256(CHAINLINK_BRL_USD_DECIMALS));
        require(v <= 18, "MOVVA_CHAINLINK_BRL_USD_DECIMALS: at most 18");
        return uint8(v);
    }

    /// @dev The reserve's own bounds by default: an immutable bound tighter than the market might ever go would
    ///      stop a keyless leg for good, so it is there to catch a unit or an inversion, not to judge the real.
    function _chainlinkRange() private view returns (uint256 lo, uint256 hi) {
        lo = vm.envOr("MOVVA_CHAINLINK_FX_MIN_E6", uint256(1e6));
        hi = vm.envOr("MOVVA_CHAINLINK_FX_MAX_E6", uint256(100e6));
    }

    /// @dev Zero is a setting here (no closing prices at all), so unlike `_age` it is not refused.
    function _closedMaxAge() private view returns (uint64) {
        uint256 v = vm.envOr("MOVVA_FX_CLOSED_MAX_AGE", uint256(4 days));
        require(v <= type(uint64).max, "MOVVA_FX_CLOSED_MAX_AGE: seconds");
        return uint64(v);
    }

    /// @dev L-16: on chain id 1 a quorum is at least two and a strict majority of its signers.
    function _requireMajority(uint256 t, uint256 n, string memory name) private view {
        if (block.chainid != 1) return;
        require(t >= 2 && t * 2 > n, string.concat(name, ": on mainnet at least 2 and a strict majority of the signers"));
    }

    function _bps(string memory name, uint256 dflt) private view returns (uint16) {
        uint256 v = vm.envOr(name, dflt);
        require(v <= type(uint16).max, string.concat(name, ": basis points fit a uint16"));
        return uint16(v);
    }

    /// @dev Benchmarked to traditional finance (docs/movva.md, "Fees"): 0.10% to mint and 0.10% to redeem, as a
    ///      fiat-backed stablecoin issuer charges its institutions (Tether: 0.1% per acquisition and per redemption).
    ///      Both sit under the reserve's hard caps (100 bps each); raising either later waits out the governance delay.
    function _mintFee() private view returns (uint16) {
        return _bps("MOVVA_MINT_FEE_BPS", 10);
    }

    function _redeemFee() private view returns (uint16) {
        return _bps("MOVVA_REDEEM_FEE_BPS", 10);
    }

    function _ratios() private view returns (uint16, uint16) {
        return (_bps("MOVVA_TARGET_RATIO_BPS", 10_800), _bps("MOVVA_MIN_MINT_RATIO_BPS", 10_000));
    }

    function _epochSeconds() private view returns (uint256) {
        return vm.envOr("MOVVA_LP_REWARD_EPOCH_SECONDS", uint256(7 days));
    }

    function _reviewSeconds() private view returns (uint256) {
        return vm.envOr("MOVVA_LP_REWARD_REVIEW_SECONDS", uint256(3 days));
    }

    /// @dev 10 bps of volume, the mint fee: a settled real never earns more than minting it paid Mova. R$ 10.000,00 of Movva
    ///      per LP per epoch, and nothing under R$ 10,00 counted. Only the rate has a hard cap in the contract (20 bps).
    function _rewardLimits() private view returns (uint16 rate, uint256 cap, uint256 minCents) {
        rate = _bps("MOVVA_LP_REWARD_BPS_OF_VOLUME", 10);
        cap = vm.envOr("MOVVA_LP_REWARD_CAP_PER_EPOCH", uint256(2_000)) * 1e6;
        minCents = vm.envOr("MOVVA_LP_REWARD_MIN_CENTS", uint256(1_000));
    }

    /// @dev Handed over: the governor now, or proposed and waiting to accept (I-36). The governor Safe accepts in the
    ///      same batch that closes setup, so a pending one is what a deploy script leaves behind.
    function _handedTo(address c, address g) internal view returns (bool) {
        return DelayedGovernance(c).governor() == g || DelayedGovernance(c).pendingGovernor() == g;
    }
}
