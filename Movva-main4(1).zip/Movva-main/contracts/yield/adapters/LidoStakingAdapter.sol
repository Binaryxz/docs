// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {IERC4626} from "@openzeppelin/contracts/interfaces/IERC4626.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {IYieldAdapter} from "../IYieldAdapter.sol";

interface IWETH9 is IERC20 {
    function deposit() external payable;
    function withdraw(uint256) external;
}

interface IWstETH is IERC20 {
    function getStETHByWstETH(uint256) external view returns (uint256);
    function getWstETHByStETH(uint256) external view returns (uint256);
    function unwrap(uint256) external returns (uint256);
}

interface ICurveStEthPool {
    /// @dev Index 0 is ETH, 1 is stETH. Verified against mainnet: exchange(1, 0, 0.1 stETH, 0)
    ///      returned 0.09998 ETH.
    function exchange(int128 i, int128 j, uint256 dx, uint256 minDy) external payable returns (uint256);
}

interface IStEthEthFeed {
    function decimals() external view returns (uint8);
    function latestRoundData() external view returns (uint80, int256, uint256, uint256, uint80);
}

interface ILidoWithdrawalQueue {
    struct WithdrawalRequestStatus {
        uint256 amountOfStETH;
        uint256 amountOfShares;
        address owner;
        uint256 timestamp;
        bool isFinalized;
        bool isClaimed;
    }

    function requestWithdrawalsWstETH(uint256[] calldata amounts, address owner)
        external
        returns (uint256[] memory requestIds);
    function claimWithdrawal(uint256 requestId) external;
    function getWithdrawalStatus(uint256[] calldata requestIds)
        external
        view
        returns (WithdrawalRequestStatus[] memory);
    function MAX_STETH_WITHDRAWAL_AMOUNT() external view returns (uint256);
}

interface IVaultRoles {
    function keeper() external view returns (address);
    function guardian() external view returns (address);
}

/**
 * @title LidoStakingAdapter
 * @notice ETH staking through Lido as a yield source (task 3.1), with its risks priced in (3.5).
 *
 * The vault's asset is WETH. Deposits become wstETH, which compounds Lido's staking rate in
 * its exchange rate (2.23% APR measured over the week before this was written), so there is
 * nothing to harvest.
 *
 * ## How the risks are handled
 *
 * **Depeg.** stETH trades near 1 ETH but is not ETH. Everything is valued at the LOWER of
 * Lido's redemption rate and the Chainlink stETH/ETH market price, so a depeg shows up as a
 * loss in the share price straight away - which trips the vault's drawdown breaker - rather
 * than being papered over by the redemption rate until someone tries to sell. New stake is
 * refused while the market is more than `maxDepegBps` below par.
 *
 * **Oracle failure.** If the feed is stale, non-positive or reverts, the adapter does not
 * guess. It values staked ETH with a fixed pessimistic haircut, refuses new stake, and stops
 * offering instant exits - an instant exit needs a trustworthy minimum output, and without a
 * price the only honest minimum is none. Views never revert, so a dead feed cannot freeze
 * the vault; see IYieldAdapter.
 *
 * **Exit liquidity.** Two paths, because they fail differently:
 *  - *Instant*: sell stETH on the Curve stETH/ETH pool, with a minimum output set from the
 *    ORACLE price less `maxSlippageBps`. Anchoring the minimum to the oracle rather than to
 *    the pool's own quote is what stops a sandwich from setting the price it then fills at.
 *  - *Queued*: Lido's withdrawal queue at the redemption rate, which on mainnet had 17,287
 *    stETH waiting when this was written, so days rather than blocks. Requested stETH stays
 *    on the books as pending, valued conservatively, so moving funds into the queue does not
 *    look like a loss and trip the breaker.
 */
contract LidoStakingAdapter is IYieldAdapter, ReentrancyGuard {
    using SafeERC20 for IERC20;

    uint256 internal constant BPS = 10_000;
    uint256 internal constant ONE = 1e18;

    address public immutable override vault;
    /// @notice WETH.
    address public immutable override asset;
    IWstETH public immutable WSTETH;
    IERC20 public immutable STETH;
    ICurveStEthPool public immutable CURVE;
    IStEthEthFeed public immutable FEED;
    ILidoWithdrawalQueue public immutable QUEUE;
    uint256 internal immutable FEED_SCALE;

    uint256 public immutable maxOracleAge;
    uint16 public immutable maxDepegBps;
    uint16 public immutable maxSlippageBps;
    uint16 public immutable staleHaircutBps;

    uint256[] internal _pending;
    /// @notice stETH requested per withdrawal request, until it is claimed.
    mapping(uint256 => uint256) public pendingAmount;
    uint256 public pendingStEth;

    event Staked(uint256 eth, uint256 wstEth);
    event SoldOnCurve(uint256 stEth, uint256 ethOut, uint256 minOut);
    /// @notice Curve refused a sale at the oracle-derived minimum; nothing was sold (N-36).
    event CurveSaleFailed(uint256 stEth, uint256 minOut, bytes reason);
    event ExitRequested(uint256[] requestIds, uint256 stEth);
    event ExitClaimed(uint256 indexed requestId, uint256 requested, uint256 received);

    error NotVault();
    error NotKeeperOrGuardian();
    error ZeroAddress();
    error AssetMismatch();
    error BadParams();
    error Depegged();
    error OracleUnavailable();
    error StakeFailed();
    error UnexpectedEth();
    error NotPending();

    modifier onlyVault() {
        if (msg.sender != vault) revert NotVault();
        _;
    }

    constructor(
        address vault_,
        address weth_,
        address wstEth_,
        address stEth_,
        address curve_,
        address feed_,
        address queue_,
        uint256 maxOracleAge_,
        uint16 maxDepegBps_,
        uint16 maxSlippageBps_,
        uint16 staleHaircutBps_
    ) {
        if (
            vault_ == address(0) || weth_ == address(0) || wstEth_ == address(0)
                || stEth_ == address(0) || curve_ == address(0) || feed_ == address(0)
                || queue_ == address(0)
        ) revert ZeroAddress();
        if (IERC4626(vault_).asset() != weth_) revert AssetMismatch();
        if (maxDepegBps_ >= BPS || maxSlippageBps_ >= BPS || staleHaircutBps_ >= BPS) {
            revert BadParams();
        }
        vault = vault_;
        asset = weth_;
        WSTETH = IWstETH(wstEth_);
        STETH = IERC20(stEth_);
        CURVE = ICurveStEthPool(curve_);
        FEED = IStEthEthFeed(feed_);
        QUEUE = ILidoWithdrawalQueue(queue_);
        FEED_SCALE = 10 ** IStEthEthFeed(feed_).decimals();
        maxOracleAge = maxOracleAge_;
        maxDepegBps = maxDepegBps_;
        maxSlippageBps = maxSlippageBps_;
        staleHaircutBps = staleHaircutBps_;
    }

    function name() external pure returns (string memory) {
        return "Lido staking (wstETH)";
    }

    /*//////////////////////////////////////////////////////////////
                                PRICING
    //////////////////////////////////////////////////////////////*/

    /// @notice stETH per ETH from Chainlink, 1e18-scaled. `ok` is false if it cannot be trusted.
    function marketPrice() public view returns (bool ok, uint256 price) {
        // Round ids are not used: staleness is judged by `updatedAt`, positivity by `answer`.
        // slither-disable-next-line unused-return
        try FEED.latestRoundData() returns (uint80, int256 answer, uint256, uint256 updatedAt, uint80) {
            if (answer <= 0 || updatedAt == 0 || block.timestamp > updatedAt + maxOracleAge) {
                return (false, 0);
            }
            return (true, (uint256(answer) * ONE) / FEED_SCALE);
        } catch {
            return (false, 0);
        }
    }

    /// @notice True while new stake should be refused: the market is off peg, or unknown.
    function depegged() public view returns (bool) {
        (bool ok, uint256 p) = marketPrice();
        return !ok || p * BPS < ONE * (BPS - maxDepegBps);
    }

    function _valueOfStEth(uint256 stEth, bool ok, uint256 price) internal view returns (uint256) {
        if (!ok) return (stEth * (BPS - staleHaircutBps)) / BPS;
        return (stEth * (price < ONE ? price : ONE)) / ONE;
    }

    function _liquidStEth() internal view returns (uint256) {
        return WSTETH.getStETHByWstETH(WSTETH.balanceOf(address(this))) + STETH.balanceOf(address(this));
    }

    function _idle() internal view returns (uint256) {
        return IERC20(asset).balanceOf(address(this)) + address(this).balance;
    }

    function totalValue() external view returns (uint256) {
        (bool ok, uint256 p) = marketPrice();
        return _valueOfStEth(_liquidStEth() + pendingStEth, ok, p) + _idle();
    }

    /// @dev Queued stETH is excluded, and without a trustworthy price so is all staked ETH:
    ///      an instant sale needs a minimum output, and there is no honest one without a price.
    function maxInstantWithdraw() external view returns (uint256) {
        (bool ok, uint256 p) = marketPrice();
        if (!ok) return _idle();
        return _idle() + (_valueOfStEth(_liquidStEth(), true, p) * (BPS - maxSlippageBps)) / BPS;
    }

    /// @notice Outstanding withdrawal requests.
    function pendingRequests() external view returns (uint256[] memory) {
        return _pending;
    }

    /*//////////////////////////////////////////////////////////////
                              VAULT CALLS
    //////////////////////////////////////////////////////////////*/

    function deposit(uint256 assets) external onlyVault nonReentrant returns (uint256) {
        if (depegged()) revert Depegged();
        IWETH9(asset).withdraw(assets);
        uint256 before = WSTETH.balanceOf(address(this));
        // wstETH's receive() stakes the ETH with Lido and wraps it in one call.
        (bool ok,) = address(WSTETH).call{value: assets}("");
        if (!ok) revert StakeFailed();
        emit Staked(assets, WSTETH.balanceOf(address(this)) - before);
        return assets;
    }

    function withdraw(uint256 assets, address to) external onlyVault nonReentrant returns (uint256 sent) {
        if (address(this).balance > 0) IWETH9(asset).deposit{value: address(this).balance}();
        uint256 have = IERC20(asset).balanceOf(address(this));

        if (have < assets) {
            (bool ok, uint256 p) = marketPrice();
            if (!ok) revert OracleUnavailable();
            uint256 px = p < ONE ? p : ONE;
            uint256 need = assets - have;

            // Sell enough stETH that even at the worst accepted slippage the proceeds cover
            // `need`. Any excess stays here as WETH and is still counted in totalValue.
            uint256 stWanted = (need * ONE * BPS) / (px * (BPS - maxSlippageBps)) + 2;
            uint256 stBal = STETH.balanceOf(address(this));
            if (stBal < stWanted) {
                uint256 wstBal = WSTETH.balanceOf(address(this));
                uint256 wst = WSTETH.getWstETHByStETH(stWanted - stBal) + 1;
                if (wst > wstBal) wst = wstBal;
                // stETH received is re-read from the balance on the next line.
                // slither-disable-next-line unused-return
                if (wst > 0) WSTETH.unwrap(wst);
                stBal = STETH.balanceOf(address(this));
            }

            uint256 sell = stBal < stWanted ? stBal : stWanted;
            if (sell > 0) {
                // The minimum comes from the oracle, not from the pool being traded against.
                uint256 minOut = (sell * px * (BPS - maxSlippageBps)) / (ONE * BPS);
                STETH.forceApprove(address(CURVE), sell);
                // N-36: a pool trading further below the oracle than the slippage bound refuses the sale.
                // That must not revert the vault's whole withdrawal: send what is here, and let the vault
                // fall through to its next source or refuse with InsufficientLiquidity.
                try CURVE.exchange(1, 0, sell, minOut) returns (uint256 ethOut) {
                    emit SoldOnCurve(sell, ethOut, minOut);
                } catch (bytes memory reason) {
                    STETH.forceApprove(address(CURVE), 0);
                    emit CurveSaleFailed(sell, minOut, reason);
                }
                IWETH9(asset).deposit{value: address(this).balance}();
            }
            have = IERC20(asset).balanceOf(address(this));
        }

        sent = have < assets ? have : assets;
        if (sent > 0) IERC20(asset).safeTransfer(to, sent);
    }

    /// @dev wstETH compounds in its exchange rate. There is nothing separate to harvest.
    function harvest() external view onlyVault returns (uint256) {
        return 0;
    }

    /*//////////////////////////////////////////////////////////////
                         LIDO WITHDRAWAL QUEUE
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Move wstETH into Lido's withdrawal queue, at the redemption rate.
     * @dev Keeper or guardian: this is how size exits without paying Curve slippage, and how
     *      the guardian leaves a source whose market has broken. Split into requests no larger
     *      than Lido's per-request maximum.
     */
    function requestExit(uint256 wstAmount) external nonReentrant returns (uint256[] memory ids) {
        if (msg.sender != IVaultRoles(vault).keeper() && msg.sender != IVaultRoles(vault).guardian()) {
            revert NotKeeperOrGuardian();
        }
        uint256 wstBal = WSTETH.balanceOf(address(this));
        if (wstAmount > wstBal) wstAmount = wstBal;
        // slither-disable-next-line incorrect-equality
        if (wstAmount == 0) revert BadParams();

        uint256 maxWst = WSTETH.getWstETHByStETH(QUEUE.MAX_STETH_WITHDRAWAL_AMOUNT());
        uint256 n = (wstAmount + maxWst - 1) / maxWst;
        uint256[] memory amounts = new uint256[](n);
        uint256 left = wstAmount;
        for (uint256 i; i < n; ++i) {
            uint256 a = left < maxWst ? left : maxWst;
            amounts[i] = a;
            left -= a;
        }

        IERC20(address(WSTETH)).forceApprove(address(QUEUE), wstAmount);
        ids = QUEUE.requestWithdrawalsWstETH(amounts, address(this));

        ILidoWithdrawalQueue.WithdrawalRequestStatus[] memory st = QUEUE.getWithdrawalStatus(ids);
        uint256 total = 0;
        for (uint256 i; i < ids.length; ++i) {
            pendingAmount[ids[i]] = st[i].amountOfStETH;
            _pending.push(ids[i]);
            total += st[i].amountOfStETH;
        }
        pendingStEth += total;
        emit ExitRequested(ids, total);
    }

    /**
     * @notice Claim a finalized request. Anyone may call it: the queue pays the request's owner,
     *         which is this contract, so the caller cannot redirect anything.
     * @dev Reverts inside the queue if the request is not finalized yet.
     */
    function claimExit(uint256 requestId) external nonReentrant returns (uint256 received) {
        uint256 requested = pendingAmount[requestId];
        if (requested == 0) revert NotPending();
        delete pendingAmount[requestId];
        pendingStEth -= requested;
        for (uint256 i; i < _pending.length; ++i) {
            if (_pending[i] == requestId) {
                _pending[i] = _pending[_pending.length - 1];
                _pending.pop();
                break;
            }
        }

        uint256 before = address(this).balance;
        QUEUE.claimWithdrawal(requestId);
        received = address(this).balance - before;
        // The ETH goes to WETH, an immutable set at construction, and comes straight back to
        // this contract as WETH. Nothing reaches the caller.
        // slither-disable-next-line arbitrary-send-eth
        IWETH9(asset).deposit{value: received}();
        emit ExitClaimed(requestId, requested, received);
    }

    /// @dev Only the three contracts that legitimately pay this adapter in ETH.
    receive() external payable {
        if (msg.sender != asset && msg.sender != address(CURVE) && msg.sender != address(QUEUE)) {
            revert UnexpectedEth();
        }
    }
}
