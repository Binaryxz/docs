// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {ERC4626} from "@openzeppelin/contracts/token/ERC20/extensions/ERC4626.sol";
import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {IYieldAdapter} from "./IYieldAdapter.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";
import {IssuerFreeze} from "../common/IssuerFreeze.sol";

/**
 * @title YieldVault
 * @notice An ERC-4626 vault over governor-listed yield adapters (tasks 3.2, 3.5).
 *
 * ## Who holds it
 *
 * `MovvaReserve` (`setYieldVault`): the reserve's idle USDT, earning in a listed source. That
 * yield is Mova's. It raises the reserve's backing and reaches Mova only through the reserve's
 * hedge path; no user is paid it (client decision D1, 14 October 2026: there is no savings
 * product). The vault was first built to be held inside a Privacy Pool for users, through a
 * shielded router; that user-facing path was removed with savings.
 *
 * Yield accrues to the share price rather than being claimed, so a holder's share count never
 * changes and nothing is paid out per position.
 *
 * ## Risk management (task 3.5)
 *
 *  - **Conservative pricing.** Adapters value at the lower of redemption and market (see
 *    `IYieldAdapter`), so withdrawals are priced at what the position is actually worth.
 *  - **Drawdown circuit breaker.** If assets-per-share falls more than `maxDrawdownBps`
 *    below its high-water mark - a depeg, a slashing, an exploit in a source - deposits and
 *    new allocations stop automatically. Withdrawals stay open: trapping holders to protect
 *    them is the wrong trade, and conservative pricing means leaving does not cost the
 *    people who stay. Resuming is a governor decision that acknowledges the loss.
 *  - **Allocation caps** per adapter, a **deposit cap**, and a **guardian** that can pause
 *    and pull funds out of a source but cannot move them anywhere but back into the vault.
 *  - **Inflation-attack protection** from OpenZeppelin's decimals offset, so the first
 *    depositor cannot be robbed by a donation.
 *
 * ## What no role can do without warning
 *
 * No role can transfer the vault's assets to an arbitrary address directly. The governor
 * chooses which adapters exist and the keeper moves funds between the vault and those
 * adapters. Funds leave the vault only to redeeming shareholders - or into an adapter, and an
 * adapter is code. So a governor could list an adapter it wrote, make itself keeper and
 * `allocate` the vault into it, all in one block. This comment used to say adapters "should
 * be timelocked in production"; they now are, on-chain:
 *
 *  - adding an adapter, raising its allocation cap or reactivating it, changing the keeper,
 *    raising the deposit cap and widening the drawdown band all wait out GOVERNANCE_DELAY
 *    (see DelayedGovernance), long enough for every holder to redeem;
 *  - deactivating or removing an adapter, lowering caps, tightening the band, pausing and
 *    changing the guardian stay instant. The guardian can only pause and pull funds back
 *    INTO the vault, so rotating it is incident response rather than a new power.
 *
 * Resuming deposits stays instant too: it moves nothing, it only lets new money in again.
 */
contract YieldVault is ERC4626, ReentrancyGuard, DelayedGovernance {
    using SafeERC20 for IERC20;

    struct Strategy {
        uint16 maxAllocationBps;
        bool active;
        bool listed;
    }

    uint16 public constant BPS = 10_000;
    uint256 public constant MAX_ADAPTERS = 8;

    address public guardian;
    address public keeper;

    IYieldAdapter[] internal _adapters;
    mapping(IYieldAdapter => Strategy) public strategies;

    uint256 public depositCap;
    uint16 public maxDrawdownBps;
    bool public depositsPaused;
    /// @notice Highest assets-per-share seen, per `10 ** decimals()` shares.
    uint256 public highWaterAssetsPerShare;

    event AdapterAdded(address indexed adapter, uint16 maxAllocationBps);
    event AdapterUpdated(address indexed adapter, uint16 maxAllocationBps, bool active);
    event AdapterRemoved(address indexed adapter);
    /// @notice A source removed with dust in it, or unreadable: `value` is what its view still reported.
    event AdapterWrittenOff(address indexed adapter, uint256 value);
    event Allocated(address indexed adapter, uint256 assets);
    event Deallocated(address indexed adapter, uint256 requested, uint256 received);
    event Harvested(address indexed adapter, uint256 assets);
    event CircuitBreakerTripped(uint256 assetsPerShare, uint256 highWater);
    event DepositsPaused(address indexed by);
    event DepositsResumed(uint256 acknowledgedAssetsPerShare);
    event DepositCapSet(uint256 cap);
    event MaxDrawdownSet(uint16 bps);
    event RoleSet(string role, address indexed account);

    error NotKeeper();
    error ExitBelowValuation(address adapter, uint256 valueDrop, uint256 received);
    error NotGuardianOrKeeper();
    error NotGuardianOrGovernor();
    error BadAdapter();
    error AdapterExists();
    error TooManyAdapters();
    error UnknownAdapter();
    error AdapterInactive();
    error AdapterNotEmpty();
    error DepositsArePaused();
    error OverAllocationCap();
    error InsufficientIdle();
    error InsufficientLiquidity(uint256 wanted, uint256 available);
    error TransferFeeCharged(uint256 assets, uint256 received);
    error FrozenByAssetIssuer();
    error BadBps();

    modifier onlyKeeper() {
        if (msg.sender != keeper) revert NotKeeper();
        _;
    }

    constructor(
        IERC20 asset_,
        string memory name_,
        string memory symbol_,
        address governor_,
        address guardian_,
        address keeper_,
        uint256 depositCap_,
        uint16 maxDrawdownBps_,
        uint256 governanceDelay
    ) ERC20(name_, symbol_) ERC4626(asset_) DelayedGovernance(governor_, governanceDelay) {
        if (guardian_ == address(0) || keeper_ == address(0)) revert ZeroAddress();
        if (maxDrawdownBps_ == 0 || maxDrawdownBps_ >= BPS) revert BadBps();
        guardian = guardian_;
        keeper = keeper_;
        depositCap = depositCap_;
        maxDrawdownBps = maxDrawdownBps_;
    }

    /// @dev Six decimals of offset make a first-depositor donation attack uneconomic.
    function _decimalsOffset() internal pure override returns (uint8) {
        return 6;
    }

    /*//////////////////////////////////////////////////////////////
                               ACCOUNTING
    //////////////////////////////////////////////////////////////*/

    /// @dev An adapter whose view reverts counts as zero, whatever IYieldAdapter promises (N-35): one
    ///      broken source must not freeze every exit, the idle share's and the other adapters' included.
    function totalAssets() public view override returns (uint256 total) {
        total = IERC20(asset()).balanceOf(address(this));
        for (uint256 i; i < _adapters.length; ++i) {
            total += _valueOf(_adapters[i]);
        }
    }

    /// @notice What could be paid out right now without waiting on any queue.
    function liquidAssets() public view returns (uint256 liquid) {
        liquid = IERC20(asset()).balanceOf(address(this));
        for (uint256 i; i < _adapters.length; ++i) {
            liquid += _instantOf(_adapters[i]);
        }
    }

    /// @dev `totalValue`, or zero when it reverts (N-35): the pessimistic value of a source nobody can read.
    function _valueOf(IYieldAdapter a) internal view returns (uint256) {
        try a.totalValue() returns (uint256 v) {
            return v;
        } catch {
            return 0;
        }
    }

    /// @dev `maxInstantWithdraw`, or zero when it reverts (N-35).
    function _instantOf(IYieldAdapter a) internal view returns (uint256) {
        try a.maxInstantWithdraw() returns (uint256 v) {
            return v;
        } catch {
            return 0;
        }
    }

    function assetsPerShare() public view returns (uint256) {
        return convertToAssets(10 ** decimals());
    }

    function adapters() external view returns (IYieldAdapter[] memory) {
        return _adapters;
    }

    /*//////////////////////////////////////////////////////////////
                        ERC-4626 LIMITS AND HOOKS
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice True while the asset's issuer has frozen this vault (Tether or Circle blacklist).
     * @dev A frozen vault can still receive the asset, because the issuer checks only senders. So
     *      it would keep minting shares for deposits it can never pay back, and nobody could leave.
     *      This used to depend on the monitor's alert reaching someone who paused deposits (SR3-9);
     *      now the vault asks on every deposit, and resumes by itself once the issuer unfreezes it.
     */
    function frozenByAssetIssuer() public view returns (bool) {
        return IssuerFreeze.isFrozen(asset(), address(this));
    }

    /// @dev Zero until setup is complete: nobody's money goes in while changes are instant.
    function maxDeposit(address) public view override returns (uint256) {
        if (depositsPaused || !setupComplete || frozenByAssetIssuer()) return 0;
        uint256 total = totalAssets();
        return total >= depositCap ? 0 : depositCap - total;
    }

    function maxMint(address receiver) public view override returns (uint256) {
        return convertToShares(maxDeposit(receiver));
    }

    /// @dev Bounded by instant liquidity: a withdrawal the vault cannot fund must fail up front.
    ///      Zero while frozen: every payout would revert.
    function maxWithdraw(address owner) public view virtual override returns (uint256) {
        if (frozenByAssetIssuer()) return 0;
        uint256 byShares = super.maxWithdraw(owner);
        uint256 liquid = liquidAssets();
        return byShares < liquid ? byShares : liquid;
    }

    /**
     * @dev Cap only when a full redemption would need more than is liquid.
     *
     *      Converting the liquidity figure into shares and taking the minimum looks
     *      equivalent and is not: the conversion rounds down, so whenever assets-per-share is
     *      anything but the initial ratio - which is to say as soon as any yield accrues - it
     *      lands a few shares below the supply, and the last holder cannot leave. The first
     *      version did exactly that; a circuit-breaker test caught it after a loss.
     */
    function maxRedeem(address owner) public view virtual override returns (uint256) {
        if (frozenByAssetIssuer()) return 0;
        uint256 shares = balanceOf(owner);
        uint256 liquid = liquidAssets();
        if (previewRedeem(shares) <= liquid) return shares;
        return convertToShares(liquid);
    }

    /// @dev Checked before ERC-4626's own limit so the revert names the reason, not a zero limit.
    function deposit(uint256 assets, address receiver)
        public
        override
        nonReentrant
        returns (uint256)
    {
        if (frozenByAssetIssuer()) revert FrozenByAssetIssuer();
        return super.deposit(assets, receiver);
    }

    function mint(uint256 shares, address receiver) public override nonReentrant returns (uint256) {
        if (frozenByAssetIssuer()) revert FrozenByAssetIssuer();
        return super.mint(shares, receiver);
    }

    function withdraw(uint256 assets, address receiver, address owner)
        public
        virtual
        override
        nonReentrant
        returns (uint256)
    {
        return super.withdraw(assets, receiver, owner);
    }

    function redeem(uint256 shares, address receiver, address owner)
        public
        virtual
        override
        nonReentrant
        returns (uint256)
    {
        return super.redeem(shares, receiver, owner);
    }

    /**
     * @dev Refuse a deposit that did not arrive in full.
     *
     *      ERC-4626 prices the shares from `assets` before the transfer. A token that takes a
     *      fee in transit would mint the depositor shares for money the vault never received,
     *      and every other holder would pay the difference, one fee per deposit. USDT has that
     *      switch: `setParams` in its verified source allows up to 19 bps, capped at 49 USDT a
     *      transfer, and it read zero on 2026-09-14. So the vault checks what arrived.
     *
     *      Exits are not guarded the same way. The vault sends exactly `assets`, so its books stay
     *      right, and the fee comes out of what the leaver receives. What a fee does to exits that
     *      need an adapter is in `AaveUSDTFork.t.sol`.
     */
    function _deposit(address caller, address receiver, uint256 assets, uint256 shares)
        internal
        override
    {
        IERC20 token = IERC20(asset());
        uint256 before = token.balanceOf(address(this));
        // Every entry point that reaches here is nonReentrant, and `before` brackets only the
        // depositor's own transfer inside this call.
        // slither-disable-next-line reentrancy-balance
        super._deposit(caller, receiver, assets, shares);
        uint256 received = token.balanceOf(address(this)) - before;
        if (received < assets) revert TransferFeeCharged(assets, received);
        _checkpoint();
    }

    /**
     * @dev Pull from adapters until the vault holds enough idle asset, then pay out.
     *      Shares are priced before this runs, from conservative adapter values.
     */
    function _withdraw(
        address caller,
        address receiver,
        address owner,
        uint256 assets,
        uint256 shares
    ) internal override {
        IERC20 token = IERC20(asset());
        uint256 idle = token.balanceOf(address(this));
        for (uint256 i; i < _adapters.length && idle < assets; ++i) {
            uint256 avail = _instantOf(_adapters[i]);
            if (avail == 0) continue;
            uint256 want = assets - idle;
            // The adapter's reported amount is not trusted; the balance is re-read instead.
            // Adapters are governor-listed, every entry point here is nonReentrant, and
            // `idle` is refreshed from the balance after each call, so it is never stale.
            // An adapter that reverts is passed over, so the next source can still pay (N-35, N-36).
            uint256 valueBefore = _valueOf(_adapters[i]);
            // slither-disable-next-line reentrancy-balance,unused-return
            try _adapters[i].withdraw(want < avail ? want : avail, address(this)) returns (uint256) {} catch {}
            uint256 got = token.balanceOf(address(this)) - idle;
            // A holder's exit pays its own exit cost (v2.0 I-26): an adapter must deliver at least what its
            // valuation fell by, or the slippage would come out of every remaining holder's shares.
            uint256 valueAfter = _valueOf(_adapters[i]);
            // One unit of rounding is the adapter's share-to-asset conversion, not a cost.
            if (valueBefore > valueAfter && got + 1 < valueBefore - valueAfter) {
                revert ExitBelowValuation(address(_adapters[i]), valueBefore - valueAfter, got);
            }
            idle += got;
        }
        if (idle < assets) revert InsufficientLiquidity(assets, idle);
        super._withdraw(caller, receiver, owner, assets, shares);
        _checkpoint();
    }

    /*//////////////////////////////////////////////////////////////
                          ALLOCATION (KEEPER)
    //////////////////////////////////////////////////////////////*/

    function allocate(IYieldAdapter adapter, uint256 assets) external onlyKeeper nonReentrant {
        _requireSetupComplete();
        Strategy memory s = strategies[adapter];
        if (!s.listed) revert UnknownAdapter();
        if (!s.active) revert AdapterInactive();
        if (depositsPaused) revert DepositsArePaused();
        if (IERC20(asset()).balanceOf(address(this)) < assets) revert InsufficientIdle();

        uint256 total = totalAssets();
        if ((adapter.totalValue() + assets) * BPS > total * s.maxAllocationBps) {
            revert OverAllocationCap();
        }

        IERC20(asset()).safeTransfer(address(adapter), assets);
        // The checkpoint must follow the deposit: it is what notices an adapter that values
        // the new position below cost. The adapter is governor-listed and allocate is
        // nonReentrant, as is every function that reads or writes depositsPaused mid-call.
        // slither-disable-next-line reentrancy-no-eth,unused-return
        adapter.deposit(assets);
        emit Allocated(address(adapter), assets);
        _checkpoint();
    }

    /// @notice Pull funds back from a source. The guardian may do this too, to exit a
    ///         source under stress; funds can only come back into the vault.
    function deallocate(IYieldAdapter adapter, uint256 assets) external nonReentrant {
        if (msg.sender != keeper && msg.sender != guardian) revert NotGuardianOrKeeper();
        if (!strategies[adapter].listed) revert UnknownAdapter();
        uint256 received = adapter.withdraw(assets, address(this));
        emit Deallocated(address(adapter), assets, received);
        _checkpoint();
    }

    function harvest(IYieldAdapter adapter) external onlyKeeper nonReentrant {
        if (!strategies[adapter].listed) revert UnknownAdapter();
        uint256 out = adapter.harvest();
        emit Harvested(address(adapter), out);
        _checkpoint();
    }

    /// @notice Anyone may run the drawdown check, so it does not depend on one operator.
    function checkpoint() external {
        _checkpoint();
    }

    function _checkpoint() internal {
        if (totalSupply() == 0) return;
        uint256 price = assetsPerShare();
        if (price > highWaterAssetsPerShare) {
            highWaterAssetsPerShare = price;
        } else if (
            !depositsPaused
                && price * BPS < highWaterAssetsPerShare * (BPS - maxDrawdownBps)
        ) {
            depositsPaused = true;
            emit CircuitBreakerTripped(price, highWaterAssetsPerShare);
        }
    }

    /*//////////////////////////////////////////////////////////////
                               GOVERNANCE
    //////////////////////////////////////////////////////////////*/

    /// @notice Delayed: an adapter is code the keeper can move the vault's assets into.
    function addAdapter(IYieldAdapter adapter, uint16 maxAllocationBps) external {
        _authorizeChange(true);
        if (address(adapter) == address(0)) revert ZeroAddress();
        if (adapter.vault() != address(this) || adapter.asset() != asset()) revert BadAdapter();
        if (strategies[adapter].listed) revert AdapterExists();
        if (_adapters.length >= MAX_ADAPTERS) revert TooManyAdapters();
        if (maxAllocationBps > BPS) revert BadBps();
        _adapters.push(adapter);
        strategies[adapter] = Strategy({maxAllocationBps: maxAllocationBps, active: true, listed: true});
        emit AdapterAdded(address(adapter), maxAllocationBps);
    }

    /// @notice Raising the cap or reactivating is delayed; lowering or deactivating is instant.
    function updateAdapter(IYieldAdapter adapter, uint16 maxAllocationBps, bool active) external {
        Strategy memory cur = strategies[adapter];
        _authorizeChange(maxAllocationBps > cur.maxAllocationBps || (active && !cur.active));
        if (!cur.listed) revert UnknownAdapter();
        if (maxAllocationBps > BPS) revert BadBps();
        strategies[adapter].maxAllocationBps = maxAllocationBps;
        strategies[adapter].active = active;
        emit AdapterUpdated(address(adapter), maxAllocationBps, active);
    }

    /**
     * @notice Remove a source. Only one holding at most a whole unit of the asset (dust anyone could have
     *         sent it, I-27) - or one whose value cannot be read at all (N-35), which already counts as
     *         zero - so no value that can be read is ever dropped from the books. What is written off is
     *         reported.
     */
    function removeAdapter(IYieldAdapter adapter) external {
        _authorizeChange(false);
        if (!strategies[adapter].listed) revert UnknownAdapter();
        uint256 value = _valueOf(adapter);
        // Dust - up to one unit, or 1 bp of the vault - is written off, so a donation to the adapter
        // cannot keep it listed (v2.0 I-27). Anything larger must be deallocated first.
        uint256 dust = totalAssets() / BPS;
        uint256 unit = 10 ** (decimals() - _decimalsOffset());
        if (value > (dust > unit ? dust : unit)) revert AdapterNotEmpty();
        if (value != 0) emit AdapterWrittenOff(address(adapter), value);
        for (uint256 i; i < _adapters.length; ++i) {
            if (_adapters[i] == adapter) {
                _adapters[i] = _adapters[_adapters.length - 1];
                _adapters.pop();
                break;
            }
        }
        delete strategies[adapter];
        emit AdapterRemoved(address(adapter));
    }

    function pauseDeposits() external {
        if (msg.sender != guardian && msg.sender != governor) revert NotGuardianOrGovernor();
        depositsPaused = true;
        emit DepositsPaused(msg.sender);
    }

    /**
     * @notice Resume after the breaker or a pause, accepting the current share price as the
     *         new high-water mark. This is where a realised loss is acknowledged on-chain.
     */
    function resumeDeposits() external onlyGovernor {
        depositsPaused = false;
        highWaterAssetsPerShare = totalSupply() == 0 ? 0 : assetsPerShare();
        emit DepositsResumed(highWaterAssetsPerShare);
    }

    /// @notice Raising the cap is delayed; lowering it is instant.
    function setDepositCap(uint256 cap) external {
        _authorizeChange(cap > depositCap);
        depositCap = cap;
        emit DepositCapSet(cap);
    }

    /// @notice Widening the band (tripping later) is delayed; tightening it is instant.
    function setMaxDrawdown(uint16 bps) external {
        _authorizeChange(bps > maxDrawdownBps);
        if (bps == 0 || bps >= BPS) revert BadBps();
        maxDrawdownBps = bps;
        emit MaxDrawdownSet(bps);
    }

    /// @notice Instant: the guardian can only pause and pull funds back into the vault.
    function setGuardian(address g) external {
        _authorizeChange(false);
        if (g == address(0)) revert ZeroAddress();
        guardian = g;
        emit RoleSet("guardian", g);
    }

    /**
     * @notice Delayed. The keeper decides where the vault's assets sit.
     * @dev A compromised keeper is contained without waiting: `updateAdapter(..., false)`
     *      stops it allocating anywhere, and the guardian can pull funds back, both instantly.
     */
    function setKeeper(address k) external {
        _authorizeChange(k != keeper);
        if (k == address(0)) revert ZeroAddress();
        keeper = k;
        emit RoleSet("keeper", k);
    }

    function _isDelayable(bytes4 selector) internal pure override returns (bool) {
        return selector == YieldVault.addAdapter.selector
            || selector == YieldVault.updateAdapter.selector
            || selector == YieldVault.setDepositCap.selector
            || selector == YieldVault.setMaxDrawdown.selector
            || selector == YieldVault.setKeeper.selector;
    }
}
