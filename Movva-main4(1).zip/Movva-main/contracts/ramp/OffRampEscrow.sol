// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IAttestorVerifier} from "./IAttestorVerifier.sol";
import {IPriceOracle} from "./IPriceOracle.sol";
import {ILPRegistry} from "./ILPRegistry.sol";
import {RulingLib} from "./RulingLib.sol";
import {SafeTransferLib} from "./SafeTransferLib.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";
import {IssuerFreeze} from "../common/IssuerFreeze.sol";

/**
 * @title OffRampEscrow
 * @notice Shielded balance out, BRL in the seller's bank account (the second half of the
 *         Phase 2 deliverable). PIX, Boleto or TED.
 *
 * ## Why this is a separate contract, and why the roles invert
 *
 * On the on-ramp the LP escrows crypto and the taker pays fiat. Here the SELLER escrows
 * crypto and the LP pays fiat. That inversion changes who can grief whom, so the protections
 * are not mirror images of FiatEscrow's and the two do not belong in one contract:
 *
 *  - On-ramp, an idle taker wastes an LP's capital for a pay window. Bounded and cheap. A taker
 *    who disputes holds that capital up to DISPUTE_TIMEOUT, but never the LP's credit, which
 *    this escrow shares: FiatEscrow gives it back when the taker disputes (SRM1-4).
 *  - Off-ramp, an LP who claims a sale and never pays freezes the SELLER's money - money
 *    they have already taken out of the shielded pool and cannot put back privately. So a
 *    claim is exclusive but short, anyone may clear a stale claim, and the seller can always
 *    leave: see "The seller can always cancel".
 *
 * ## The seller can always cancel
 *
 * `cancelSale` works on any sale no LP holds a LIVE claim on: an unclaimed sale, and a claimed
 * one whose `payBy` has passed. A stale claim cannot be settled any more (`settleWithProof`
 * refuses after `payBy`), so it protects nobody, and the seller need not wait for someone to
 * call `releaseStaleClaim` first.
 *
 * That alone did not stop an LP renewing its claim for ever (SRM1-13). Releasing a stale claim
 * and claiming again in one transaction, or abandoning a live claim and claiming again, put the
 * sale straight back under a live claim, so the seller never saw a state it could cancel in -
 * or had to win a same-block race against the LP, which the LP wins by paying the builder. And
 * nothing was recorded against the LP, though this header said repeated claiming was "what
 * `recordDispute` is for": nothing called it. So every claim that ends unsettled with the sale
 * still open - released as stale, or abandoned - starts CLAIM_COOLDOWN, in which nobody may claim
 * the sale. The cooldown is per sale, not per LP: an LP that sponsors affiliates (or
 * registers retail addresses in Phase C) has as many identities as it likes. Between any two
 * claims on a sale there is therefore a stretch in which only the seller can change it, and a
 * cancel sent at any moment from the old claim's `payBy` (or its abandonment) to the end of the
 * cooldown lands whatever is ordered before it. The price is that an honest LP who gives a sale
 * back makes the next LP wait CLAIM_COOLDOWN. That is the seller's protection, not a penalty:
 * nothing is recorded against anyone's credit.
 *
 * ## Where the money comes from, and the privacy that matters
 *
 * A seller funds a sale from a withdrawal out of the shielded pool. If they withdraw to an
 * address already linked to them, the ramp is private and the exit is not - so the intended
 * path is a relayed withdrawal to a fresh address, which then opens the sale. This contract
 * cannot enforce that and does not pretend to; what it can do is avoid making it worse, so
 * a sale stores no more about the seller than a refund address and the hash of the PIX key
 * that will receive the money.
 *
 * The PIX key is stored as a SALTED COMMITMENT, never as a bare hash. The LP needs the
 * cleartext key to pay it, but that is a disclosure between seller and LP off-chain. An
 * earlier version of this comment said a hash kept the key private; for a CPF or phone key
 * it did not, because those spaces are small enough to hash exhaustively, and the result
 * would link a pool exit to a named person forever. See `pixKeyCommitment` in
 * packages/ramp/src/attestor.ts: keccak256(domain, normalised key, fresh secret salt).
 *
 * ## Selling to pay a bill: the boleto payee
 *
 * The payee need not be a PIX key. A seller who wants a bill paid - rent, a credit statement,
 * a utility - opens a sale whose payee is that BOLETO: `payeeKeyHash` commits to the bill's
 * normalised barcode (`boletoCommitment` in packages/ramp/src/boleto.ts, salted like a PIX
 * key, because a barcode names the biller's account and whoever issued the bill holds a copy),
 * and `railMask` is BOLETO alone. The LP pays the bill at its bank, and the attestation must
 * prove payment of that barcode, on the BOLETO rail, for exactly `brlCents`.
 *
 * A boleto's amount is part of its line, so the seller cannot choose `brlCents` freely - it
 * must equal the bill. The escrow cannot read the line through the commitment; the SDK checks
 * it for the seller before opening, and for the LP (who receives line and salt) before it
 * claims. What the escrow enforces is the part that settles money: exact amount, BOLETO rail,
 * and a sale's mask never mixing BOLETO with a key rail, because one commitment cannot be both
 * a PIX key and a barcode - a mixed mask would let a PIX transfer to nobody's key "settle" a
 * bill, or a bill payment settle a transfer.
 *
 * ## Disputes end
 *
 * As on FiatEscrow: anyone may submit an arbitrator's signed ruling - it is public for
 * RULING_DELAY before it executes, so a stolen arbitrator key is seen before it can pay itself -
 * and a dispute nobody rules on within DISPUTE_TIMEOUT expires to its default: the crypto back
 * to the seller's refund address, which is what a claim nobody proves comes to anyway.
 *
 * And as on FiatEscrow, a dispute does not silence a proof (SRM1-3): a valid proof of a payment
 * made inside the claim's window settles a DISPUTED sale. See settleWithProof.
 */
contract OffRampEscrow is DelayedGovernance {
    /*//////////////////////////////////////////////////////////////
                                  TYPES
    //////////////////////////////////////////////////////////////*/

    enum SaleState {
        NONE,
        OPEN, // escrowed, waiting for an LP
        CLAIMED, // an LP has exclusivity and must pay
        SETTLED,
        CANCELLED,
        DISPUTED
    }

    /// @notice See FiatEscrow.AssetConfig - each asset carries its own oracle and decimals.
    struct AssetConfig {
        IPriceOracle oracle;
        uint8 decimals;
        bool enabled;
    }

    struct Sale {
        address seller;
        address asset; // address(0) = native ETH
        uint256 weiAmount;
        uint256 brlCents; // what the seller must RECEIVE
        bytes32 payeeKeyHash; // seller's PIX/bank key, hashed
        address verifier;
        uint16 railMask; // bitmask of IAttestorVerifier.Rail values the seller accepts
        address lp; // zero until claimed
        uint64 claimedAt;
        uint64 payBy;
        address refundTo;
        SaleState state;
    }

    /*//////////////////////////////////////////////////////////////
                                 STORAGE
    //////////////////////////////////////////////////////////////*/

    IPriceOracle public immutable ORACLE;
    ILPRegistry public immutable REGISTRY;
    uint256 public immutable BAND_BPS;

    /// @notice The page a payment proof must be for (ReclaimZkTlsVerifier.endpointDirection, v3.1 N-08):
    ///         SENT, money sent out of the LP's account. The verifier reads it from the caller.
    uint8 public constant PAYMENT_DIRECTION = 2;

    /// @notice How long an LP has to pay once it claims a sale.
    /// @dev Short on purpose: a claim freezes the seller's money, and a boleto that takes a
    ///      banking day to settle should be paid against a fresh claim rather than by
    ///      holding a seller hostage overnight.
    uint64 public constant PAY_WINDOW = 45 minutes;
    uint64 public constant RECEIPT_MAX_AGE = 2 days; // boletos settle on a banking cycle

    /// @notice Refuse to trade against a price older than this, whatever the oracle claims.
    uint256 public constant MAX_PRICE_AGE = 1 hours;

    /// @notice After a claim ends unsettled, nobody may claim the sale again for this long, so the
    ///         seller always has a window to cancel in. See "The seller can always cancel".
    /// @dev Long enough for a seller's cancel to be included under congestion; shorter than
    ///      PAY_WINDOW, so the next honest LP waits less than one claim's worth.
    uint64 public constant CLAIM_COOLDOWN = 30 minutes;

    uint16 private constant BOLETO_BIT = uint16(1 << uint8(IAttestorVerifier.Rail.BOLETO));

    /// @notice Bounds on DISPUTE_TIMEOUT; see FiatEscrow's constructor.
    uint64 public constant MIN_DISPUTE_TIMEOUT = 7 days;
    uint64 public constant MAX_DISPUTE_TIMEOUT = 90 days;

    /// @notice How long a dispute may go unruled before anyone can expire it to its default.
    uint64 public immutable DISPUTE_TIMEOUT;

    /// @notice How long a signed ruling is public on-chain before it can execute.
    uint64 public constant RULING_DELAY = 1 days;

    mapping(address => AssetConfig) public assets;
    mapping(bytes32 => Sale) public sales;
    /// @notice When a sale whose last claim ended unsettled may be claimed again; zero for a sale
    ///         never claimed. See CLAIM_COOLDOWN.
    /// @dev A mapping, not a Sale field: the `sales` getter is decoded positionally off-chain.
    mapping(bytes32 => uint64) public claimableAt;
    mapping(address => bool) public allowedVerifier;

    /// @notice Whose signed rulings this escrow will execute, and since when (0 = none).
    ///         Not the same power as the governor's: an arbitrator decides, the governor
    ///         submits.
    /// @dev "Since when" matters. See resolveDispute: a ruling that pays the party who did
    ///      NOT escrow the funds must come from an arbitrator who predates the dispute.
    mapping(address => uint64) public arbitratorSince;
    /// @notice When each dispute was raised.
    mapping(bytes32 => uint64) public disputedAt;
    /// @notice Whether the claiming LP, rather than the seller, raised the dispute.
    mapping(bytes32 => bool) public disputeRaisedByLP;
    /// @dev A posted, unexecuted ruling: its digest's top 192 bits above its 64-bit executable
    ///      time. Laid out as in FiatEscrow.
    mapping(bytes32 => uint256) internal postedRuling;

    /// @notice Most of an asset this escrow may hold, in base units; zero means no cap. See
    ///         FiatEscrow.assetCap: the same bound on what an issuer freeze can take (SR2-25).
    mapping(address => uint256) public assetCap;
    /// @notice What this escrow holds of each asset for its sales (N-39), as FiatEscrow.heldOf:
    ///         `assetCap` is checked against it, so tokens sent here directly fill nothing.
    mapping(address => uint256) public heldOf;
    /// @dev Who posted each pending ruling (I-68), as FiatEscrow.
    mapping(bytes32 => address) internal postedBy;
    uint256 private _nonce;
    uint256 private _entered;

    /*//////////////////////////////////////////////////////////////
                             EVENTS / ERRORS
    //////////////////////////////////////////////////////////////*/

    event SaleOpened(bytes32 indexed saleId, uint256 weiAmount, uint256 brlCents, uint16 railMask);
    event SaleClaimed(bytes32 indexed saleId, address indexed lp, uint64 payBy);
    event SaleUnclaimed(bytes32 indexed saleId, address indexed lp, bool expired);
    event SaleSettled(bytes32 indexed saleId, address indexed lp, bytes32 bankTxId, uint8 rail);
    event SaleCancelled(bytes32 indexed saleId);
    event SaleDisputed(bytes32 indexed saleId, address by, string reason);
    /// @dev No rationale in the events: the signed ruling is in the posting transaction's
    ///      calldata. Kept identical to FiatEscrow's, which is at the size limit.
    event DisputeResolved(
        bytes32 indexed saleId,
        bool paidLP,
        address indexed arbitrator,
        bytes32 evidenceRoot
    );
    event RulingPosted(
        bytes32 indexed saleId, bool paidLP, address indexed arbitrator, bytes32 evidenceRoot, uint64 executableAt
    );
    event DisputeTimedOut(bytes32 indexed saleId);
    event VerifierSet(address indexed verifier, bool allowed);
    event AssetSet(address indexed asset, address oracle, uint8 decimals, bool enabled);
    event ArbitratorSet(address indexed arbitrator, bool allowed);
    event AssetCapSet(address indexed asset, uint256 cap);
    event RefundToSet(bytes32 indexed saleId, address refundTo);

    error BadBandBps(uint256 bps);
    error NotArbitrator(address signer);
    error ArbitratorNewerThanDispute(address signer);
    error RulingForAnotherOrder();
    error BadDisputeTimeout(uint256 timeout);
    error DisputeExpired(uint64 deadline);
    error DisputeStillOpen(uint64 deadline);
    error WrongAmount();
    error RulingNotReady(uint64 executableAt);
    error NotSeller();
    error NotClaimant();
    error Reentrancy();
    error BadSale();
    error WrongState();
    error VerifierNotAllowed();
    error LPNotEligible();
    error AlreadyClaimed();
    error ClaimStillLive();
    error ClaimCoolingDown(uint64 claimableAt);
    error WindowExpired();
    error WrongPayee();
    error Underpaid();
    error RailNotAccepted();
    error BankRailNeedsZkTls();
    error ReceiptReplayed();
    error ReceiptPredatesClaim();
    error ReceiptTooOld();
    error PriceOutsideBand();
    error AssetNotEnabled(address asset);
    error WrongMsgValue();
    error StalePrice();
    error TransferFailed();
    error DecimalsFixed(address asset, uint8 decimals);
    error FrozenByAssetIssuer(address who);
    error AssetCapExceeded(address asset, uint256 cap);
    error RulingAlreadyPosted();
    error WrongProver(address prover);

    modifier nonReentrant() {
        if (_entered == 1) revert Reentrancy();
        _entered = 1;
        _;
        _entered = 0;
    }

    constructor(
        address oracle,
        address registry,
        uint256 bandBps,
        address governor_,
        uint256 governanceDelay,
        uint256 disputeTimeout
    ) DelayedGovernance(governor_, governanceDelay) {
        if (oracle == address(0) || registry == address(0)) revert ZeroAddress();
        if (disputeTimeout < MIN_DISPUTE_TIMEOUT || disputeTimeout > MAX_DISPUTE_TIMEOUT) {
            revert BadDisputeTimeout(disputeTimeout);
        }
        DISPUTE_TIMEOUT = uint64(disputeTimeout);
        ORACLE = IPriceOracle(oracle);
        REGISTRY = ILPRegistry(registry);
        // A zero band refuses every price; above half the price it bounds nothing (I-69).
        if (bandBps == 0 || bandBps > 5_000) revert BadBandBps(bandBps);
        BAND_BPS = bandBps;
        assets[address(0)] =
            AssetConfig({oracle: IPriceOracle(oracle), decimals: 18, enabled: true});
        emit AssetSet(address(0), oracle, 18, true);
    }

    /**
     * @notice List or delist a settlement asset. Decimals are fixed once first set.
     * @dev The off-ramp is not exposed the way FiatEscrow was: a sale's `brlCents` is the
     *      seller's own number, fixed at `openSale`, and decimals only feed the band check
     *      made then. Changing them could not reprice a live sale. They are fixed here anyway
     *      - a re-listing with wrong decimals would let the band pass a sale priced 10^n off,
     *      against the seller the band exists to protect - and so both escrows share one rule.
     *
     *      Delisting is instant; listing, re-enabling or changing the oracle is delayed.
     */
    function setAsset(address asset, address oracle, uint8 decimals_, bool enabled) external {
        AssetConfig memory cur = assets[asset];
        _authorizeChange(
            cur.decimals == 0 || oracle != address(cur.oracle) || (enabled && !cur.enabled)
        );
        if (oracle == address(0)) revert ZeroAddress();
        if (decimals_ == 0 || decimals_ > 36) revert AssetNotEnabled(asset);
        uint8 fixed_ = cur.decimals;
        if (fixed_ != 0 && fixed_ != decimals_) revert DecimalsFixed(asset, fixed_);
        assets[asset] =
            AssetConfig({oracle: IPriceOracle(oracle), decimals: decimals_, enabled: enabled});
        emit AssetSet(asset, oracle, decimals_, enabled);
    }

    /*//////////////////////////////////////////////////////////////
                               SELLER SIDE
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Escrow ETH and ask for BRL.
     * @param payeeKeyHash Salted commitment to the payee: a PIX key (or bank key for TED), or
     *        - with a BOLETO-only mask - the barcode of the bill to be paid. See the header.
     * @param railMask Bitmask over IAttestorVerifier.Rail: 1<<uint8(Rail.PIX) etc. A seller
     *        paid to a key names the key rails it accepts (PIX for money today, TED for
     *        same-day); a seller whose payee is a boleto sets BOLETO and nothing else.
     */
    function openSale(
        address asset,
        uint256 amount,
        uint256 brlCents,
        bytes32 payeeKeyHash,
        address verifier,
        uint16 railMask,
        address refundTo
    ) external payable nonReentrant returns (bytes32 saleId) {
        _requireSetupComplete();
        AssetConfig memory cfg = assets[asset];
        if (!cfg.enabled) revert AssetNotEnabled(asset);
        if (amount == 0 || brlCents == 0 || payeeKeyHash == bytes32(0)) revert BadSale();
        if (railMask == 0 || refundTo == address(0)) revert BadSale();
        // A refund to a frozen address would land frozen.
        _requireNotFrozen(asset, refundTo);
        // One commitment is a key or a barcode, never both: see the header.
        if (railMask & BOLETO_BIT != 0 && railMask != BOLETO_BIT) revert BadSale();
        if (!allowedVerifier[verifier]) revert VerifierNotAllowed();
        // So every payout rail is a bank payment, and a sale settles only on a proof of the bank
        // session itself - never on attestors' word, which a colluding quorum could give for a
        // payment the LP never made, taking the seller's crypto.
        if (!IAttestorVerifier(verifier).provesBankSession()) revert BankRailNeedsZkTls();

        // The seller's asking price must be sane, for the seller's sake: this is the leg
        // where a mistake means giving the asset away for a handful of centavos.
        _requireWithinBand(asset, (brlCents * (10 ** cfg.decimals)) / amount);

        saleId = keccak256(abi.encode(msg.sender, ++_nonce, block.chainid, address(this)));
        sales[saleId] = Sale({
            seller: msg.sender,
            asset: asset,
            weiAmount: amount,
            brlCents: brlCents,
            payeeKeyHash: payeeKeyHash,
            verifier: verifier,
            railMask: railMask,
            lp: address(0),
            claimedAt: 0,
            payBy: 0,
            refundTo: refundTo,
            state: SaleState.OPEN
        });
        // Effects before interactions, so a callback token cannot observe a half-written
        // sale or re-enter against one that does not exist yet.
        _receive(asset, amount);
        emit SaleOpened(saleId, amount, brlCents, railMask);
    }

    /**
     * @notice Withdraw a sale nobody holds a live claim on: an unclaimed one, or one whose claim
     *         is past its `payBy` (the stale claim is released first, freeing the LP's credit).
     *         Never available while a claim is live, or the seller could take the crypto back
     *         after the BRL had already been sent. See "The seller can always cancel".
     * @dev A stale claim can no longer settle (`settleWithProof` refuses after `payBy`), and
     *      anyone could already release it and let the seller cancel; doing both here only takes
     *      away the LP's chance to re-claim in between. An LP can no longer dispute a stale claim
     *      (raiseDispute, H-04), so from `payBy` on nothing the LP does can stop this cancel.
     */
    /// @notice The seller names another refund address while the sale is live (L-30): an issuer
    ///         block on the first must not strand the seller's crypto. Screened as at open.
    function setRefundTo(bytes32 saleId, address to) external {
        Sale storage s = sales[saleId];
        if (s.seller != msg.sender) revert NotSeller();
        SaleState st = s.state;
        if (st != SaleState.OPEN && st != SaleState.CLAIMED && st != SaleState.DISPUTED) revert WrongState();
        if (to == address(0)) revert ZeroAddress();
        _requireNotFrozen(s.asset, to);
        s.refundTo = to;
        emit RefundToSet(saleId, to);
    }

    function cancelSale(bytes32 saleId) external nonReentrant {
        Sale storage s = sales[saleId];
        if (s.seller != msg.sender) revert NotSeller();
        SaleState st = s.state;
        bool stale = st == SaleState.CLAIMED && block.timestamp > s.payBy;
        if (st != SaleState.OPEN && !stale) revert WrongState();
        s.state = SaleState.CANCELLED;
        // `lp` stays on the cancelled sale as the record of whose claim lapsed.
        if (stale) emit SaleUnclaimed(saleId, s.lp, true);
        emit SaleCancelled(saleId);
        // Effects first, then the registry, then the transfer. A stale claim's credit comes back.
        if (stale) REGISTRY.releaseExposure(s.lp, s.brlCents);
        _pay(s.asset, s.refundTo, s.weiAmount);
    }

    /*//////////////////////////////////////////////////////////////
                                 LP SIDE
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Take exclusivity on a sale in order to pay it.
     * @dev Exclusivity exists so two LPs do not both send BRL for the same sale and leave
     *      one of them out of pocket with no on-chain claim. It is the reason this is not
     *      simply "first valid proof wins".
     *
     *      Refused within CLAIM_COOLDOWN of a claim that ended unsettled, so a claim cannot be
     *      renewed without leaving the seller a window to cancel (SRM1-13).
     */
    function claimSale(bytes32 saleId) external {
        Sale storage s = sales[saleId];
        if (s.state != SaleState.OPEN) {
            if (s.state == SaleState.CLAIMED) revert AlreadyClaimed();
            revert WrongState();
        }
        uint64 opensAt = claimableAt[saleId];
        if (block.timestamp < opensAt) revert ClaimCoolingDown(opensAt);
        // The seller's price is re-checked against the band now, not only at open (M-25): a sale
        // that has sat while the market moved would otherwise be a free option for whichever LP
        // claims it first. Outside the band the sale waits, and the seller can cancel or reprice.
        _requireWithinBand(s.asset, (s.brlCents * (10 ** assets[s.asset].decimals)) / s.weiAmount);
        // Before the LP sends BRL: an escrow the issuer froze cannot pay the LP, and a listed LP
        // is not a counterparty.
        _requireNotFrozen(s.asset, address(this));
        _requireNotFrozen(s.asset, msg.sender);
        s.lp = msg.sender;
        s.claimedAt = uint64(block.timestamp);
        s.payBy = uint64(block.timestamp) + PAY_WINDOW;
        s.state = SaleState.CLAIMED;
        // Reserved against the LP's credit across ALL its positions, on both escrows, until
        // the claim ends one way or another. After the effects: a refusal reverts them all,
        // and the sale is already CLAIMED if the registry were ever to call back in.
        if (!REGISTRY.reserveExposure(msg.sender, s.brlCents)) revert LPNotEligible();
        emit SaleClaimed(saleId, msg.sender, s.payBy);
    }

    /// @notice Clear a claim nobody honoured. Callable by anyone: leaving this to the seller
    ///         would mean a seller without gas stays frozen. The sale is open again: cancellable
    ///         at once, claimable after CLAIM_COOLDOWN.
    function releaseStaleClaim(bytes32 saleId) external {
        Sale storage s = sales[saleId];
        if (s.state != SaleState.CLAIMED) revert WrongState();
        if (block.timestamp <= s.payBy) revert ClaimStillLive();
        _unclaim(saleId, s, true);
    }

    /// @notice Give the claim back early, without penalty. The sale is cancellable at once and
    ///         claimable again after CLAIM_COOLDOWN, by any LP, this one included.
    function abandonClaim(bytes32 saleId) external {
        Sale storage s = sales[saleId];
        if (s.state != SaleState.CLAIMED) revert WrongState();
        if (s.lp != msg.sender) revert NotClaimant();
        _unclaim(saleId, s, false);
    }

    /// @dev Ends a claim unsettled: the sale OPEN again, the LP's credit back, and the cooldown
    ///      that keeps the claim from being renewed under the seller (SRM1-13).
    function _unclaim(bytes32 saleId, Sale storage s, bool expired) private {
        address lp = s.lp;
        s.lp = address(0);
        s.claimedAt = 0;
        s.payBy = 0;
        s.state = SaleState.OPEN;
        claimableAt[saleId] = uint64(block.timestamp) + CLAIM_COOLDOWN;
        emit SaleUnclaimed(saleId, lp, expired);
        REGISTRY.releaseExposure(lp, s.brlCents);
    }

    /**
     * @notice Prove the seller was paid, and collect the escrowed ETH.
     * @dev Callable by anyone with a valid proof; the ETH goes to the recorded claimant
     *      regardless of who submits, so a relayer can settle for an LP without being able
     *      to divert a wei.
     *
     *      A DISPUTED sale settles by proof as well (SRM1-3), as on FiatEscrow.releaseWithProof.
     *      The seller used to be able to dispute ahead of the LP's settlement - from the bank's
     *      notification, or by front-running this call - and, with no ruling within
     *      DISPUTE_TIMEOUT, get its crypto back and keep the BRL. Every check applies unchanged;
     *      only the clock differs. The payment must fall inside the claim's own window,
     *      [claimedAt, payBy], so an LP cannot dispute its own claim to pay later at a better
     *      rate; the receipt's age is taken when the dispute froze the sale; and the proof must
     *      land before the dispute's deadline, after which only expireDispute applies.
     *
     *      What a proof does to the dispute: the sale leaves DISPUTED for good, so a posted ruling
     *      can never execute; `DisputeResolved` is emitted in favour of the LP with no arbitrator
     *      (zero) and the bank transaction id as the evidence; the LP's credit is released and its
     *      settlement recorded, as a RELEASE ruling does. Nothing is recorded against anyone:
     *      an LP that disputed and then proves did pay, and a seller has no record to cut.
     */
    function settleWithProof(bytes32 saleId, bytes calldata proof) external nonReentrant {
        Sale storage s = sales[saleId];
        SaleState st = s.state;
        // When the sale's clock stopped: now, or the moment a dispute froze it.
        uint256 asOf = block.timestamp;
        if (st == SaleState.DISPUTED) {
            asOf = disputedAt[saleId];
            uint64 deadline = uint64(asOf) + DISPUTE_TIMEOUT;
            if (block.timestamp >= deadline) revert DisputeExpired(deadline);
        } else {
            if (st != SaleState.CLAIMED) revert WrongState();
            if (block.timestamp > s.payBy) revert WindowExpired();
        }

        // See FiatEscrow.releaseWithProof: revocation must reach live sales, or the
        // governor cannot stop a broken attestor without waiting for every seller to cancel.
        if (!allowedVerifier[s.verifier]) revert VerifierNotAllowed();
        IAttestorVerifier.Payment memory p =
            IAttestorVerifier(s.verifier).verifyPayment(saleId, proof);

        if (p.payeeKeyHash != s.payeeKeyHash) revert WrongPayee();
        // The session was the claiming LP's own bank: its payout (I-22).
        if (p.prover != s.lp) revert WrongProver(p.prover);
        if (p.amountBrlCents < s.brlCents) revert Underpaid();
        // A bill is paid for its face value, which is the sale's brlCents: a payment of any
        // other amount was not a payment of the boleto the seller committed to.
        if (p.rail == IAttestorVerifier.Rail.BOLETO && p.amountBrlCents != s.brlCents) {
            revert WrongAmount();
        }
        if (!_railAccepted(s.railMask, p.rail)) revert RailNotAccepted();
        // Must post-date the CLAIM, not the sale: otherwise an LP could pay a seller once,
        // then reuse a pre-existing transfer to claim a later sale by the same seller.
        if (p.paidAt < s.claimedAt) revert ReceiptPredatesClaim();
        // Nor after the claim's window: dated in the future on a CLAIMED sale, late on a DISPUTED one.
        if (p.paidAt > s.payBy) revert WindowExpired();
        if (p.paidAt + RECEIPT_MAX_AGE < asOf) revert ReceiptTooOld();

        s.state = SaleState.SETTLED;
        // Spent in the registry every escrow of the ramp shares, so a bank transaction that
        // settled an on-ramp order cannot settle this sale too (SRM1-12; LPRegistry, "One bank
        // transaction, one settlement"). After the effects: a replay reverts them all.
        if (!REGISTRY.consumeBankTxId(p.bankTxId)) revert ReceiptReplayed();
        address lp = s.lp;

        REGISTRY.releaseExposure(lp, s.brlCents);
        REGISTRY.recordSettled(lp, s.brlCents);
        if (st == SaleState.DISPUTED) emit DisputeResolved(saleId, true, address(0), p.bankTxId);
        emit SaleSettled(saleId, lp, p.bankTxId, uint8(p.rail));
        _pay(s.asset, lp, s.weiAmount);
    }

    /*//////////////////////////////////////////////////////////////
                                DISPUTES
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Freeze a claimed sale pending arbitration. Either side may, only while the claim is
     *         live, `block.timestamp <= payBy`: the LP since H-04, the seller since v3.1 N-22.
     * @dev Why the LP's window. A claim past its `payBy` can no longer be settled (`settleWithProof`
     *      refuses a payment after `payBy`), and the seller may cancel it at once. An LP's dispute
     *      at that point used to turn a stale claim into a freeze of the seller's money for
     *      DISPUTE_TIMEOUT, up to 90 days, just as the seller was about to leave. Now an LP whose
     *      proof is slow must dispute before its window closes, as a taker must on the on-ramp.
     *
     *      What that costs an LP that pays late: a payment after `payBy` has no on-chain route,
     *      proof or ruling, and the seller can cancel and keep the BRL. That was already true of
     *      the proof; the dispute was the one way to ask an arbitrator about a late payment, and
     *      it was the way to grief. The LP's protection is to pay inside the window it claimed:
     *      PAY_WINDOW is the contract's whole promise, and the node pays early in it.
     *
     *      The seller's window (N-22). After `payBy` the seller can cancel the stale claim at once and
     *      take the crypto back, so a dispute then could only hold the LP's credit - shared by both
     *      escrows - for DISPUTE_TIMEOUT. Inside the window it is the seller's recourse against an LP
     *      claiming a payment the seller does not see.
     *
     *      Residual: an LP can still claim and dispute inside the window, freezing the sale up to
     *      DISPUTE_TIMEOUT. That costs it its credit for the sale for the whole dispute, and a lost
     *      dispute on its record if nobody rules (expireDispute).
     */
    function raiseDispute(bytes32 saleId, string calldata reason) external {
        Sale storage s = sales[saleId];
        bool byLP = msg.sender == s.lp;
        if (msg.sender != s.seller && !byLP) revert NotSeller();
        if (s.state != SaleState.CLAIMED) revert WrongState();
        if (block.timestamp > s.payBy) revert WindowExpired();
        s.state = SaleState.DISPUTED;
        disputedAt[saleId] = uint64(block.timestamp);
        disputeRaisedByLP[saleId] = byLP;
        emit SaleDisputed(saleId, msg.sender, reason);
    }

    /**
     * @notice Submit an arbitrator's signed ruling. Anyone may submit it: the first submission
     *         posts it, and the same ruling submitted again after RULING_DELAY executes it.
     * @dev RELEASE means the arbitrator found the LP really did pay the seller.
     *      Bounded per call as FiatEscrow's is: reaches only DISPUTED sales, moves only that
     *      sale's escrowed amount, and can send it to precisely two places - the claiming LP
     *      or the seller's own refund address. It cannot name a third party.
     *
     *      Permissionless, and posted before it executes, for the reasons given on
     *      FiatEscrow.resolveDispute: the signature is the authority, so an absent governor must
     *      not freeze a disputed sale; and a stolen arbitrator key, no longer checked by a
     *      governor-only submitter, must not be able to pay itself - here, by claiming sales as
     *      an LP, disputing them and ruling RELEASE - before anyone can see its rulings and
     *      revoke it. The ruling binds this escrow, this sale and (through the EIP-712 domain)
     *      this chain, and a sale leaves DISPUTED once.
     *
     *      It cannot name a third party, but the governor could BE the claiming LP: allow its
     *      own arbitrator key, claim a sale, dispute it and rule RELEASE, collecting the
     *      seller's crypto without paying BRL. Adding an arbitrator therefore waits out
     *      GOVERNANCE_DELAY publicly, so sellers can cancel unclaimed sales first.
     *
     *      A timelock alone was not enough, and the reason is worth keeping. During the delay
     *      the governor can already claim sales as an LP and dispute them, and the seller
     *      cannot cancel a disputed sale; once the new arbitrator landed it would rule RELEASE
     *      on every one. So a ruling that pays the COUNTERPARTY (the LP, who escrowed nothing)
     *      is accepted only from an arbitrator registered no later than the dispute was
     *      raised. A ruling that returns the funds to the party who escrowed them is accepted
     *      from any current arbitrator, so rotating a compromised arbitrator key can never
     *      strand a dispute: the new key can always refund, and the timeout refunds even if
     *      nobody holds a key at all.
     *
     *      Reputation: the LP's obligation here is to pay, so RELEASE records the settlement
     *      and REFUND (it did not pay) records a lost dispute, whoever raised it.
     *
     *      A valid proof ends a dispute too, and pre-empts a ruling posted and not yet executed
     *      (settleWithProof, SRM1-3).
     */
    function resolveDispute(
        bytes32 saleId,
        RulingLib.Ruling calldata ruling,
        bytes calldata arbitratorSignature
    ) external nonReentrant {
        Sale storage s = sales[saleId];
        if (s.state != SaleState.DISPUTED) revert WrongState();
        (bool ready, bool paidLP) = _admitRuling(saleId, ruling, arbitratorSignature);
        if (!ready) return;

        // Final state first, then the registry, then the transfer.
        s.state = paidLP ? SaleState.SETTLED : SaleState.CANCELLED;
        REGISTRY.releaseExposure(s.lp, s.brlCents);
        if (paidLP) {
            REGISTRY.recordSettled(s.lp, s.brlCents);
            _pay(s.asset, s.lp, s.weiAmount);
        } else {
            REGISTRY.recordDispute(s.lp);
            _pay(s.asset, s.refundTo, s.weiAmount);
        }
    }

    /**
     * @dev Verify a ruling for a disputed sale, then either post it (first sight: executable
     *      after RULING_DELAY) or report it ready (the same ruling again, after its delay).
     *      Everything is re-checked on the second sight, so revoking the arbitrator in between
     *      voids its ruling. See FiatEscrow._admitRuling, which this mirrors.
     */
    function _admitRuling(bytes32 saleId, RulingLib.Ruling calldata ruling, bytes calldata sig)
        private
        returns (bool ready, bool release)
    {
        uint64 at = disputedAt[saleId];
        uint64 deadline = at + DISPUTE_TIMEOUT;
        if (block.timestamp >= deadline) revert DisputeExpired(deadline);
        if (ruling.orderId != saleId) revert RulingForAnotherOrder();

        address signer;
        bytes32 digest;
        (signer, release, digest) = RulingLib.verify(ruling, address(this), sig, at);
        uint64 since = arbitratorSince[signer];
        // Zero is the "never registered" sentinel, not a moment anyone can hit by timing.
        // slither-disable-next-line incorrect-equality
        if (since == 0) revert NotArbitrator(signer);
        // The LP escrowed nothing: paying it needs an arbitrator older than the dispute.
        if (release && since > at) revert ArbitratorNewerThanDispute(signer);

        uint256 posted = postedRuling[saleId];
        if (posted >> 64 != uint256(digest) >> 64) {
            // Replaced only once its arbitrator is revoked (I-68), as FiatEscrow.
            if (posted != 0 && arbitratorSince[postedBy[saleId]] != 0) revert RulingAlreadyPosted();
            uint64 executableAt = uint64(block.timestamp) + RULING_DELAY;
            if (executableAt + RULING_DELAY > deadline) revert DisputeExpired(deadline);
            postedRuling[saleId] = (uint256(digest) >> 64 << 64) | executableAt;
            postedBy[saleId] = signer;
            emit RulingPosted(saleId, release, signer, ruling.evidenceRoot, executableAt);
            return (false, release);
        }
        if (block.timestamp < uint64(posted)) revert RulingNotReady(uint64(posted));
        emit DisputeResolved(saleId, release, signer, ruling.evidenceRoot);
        return (true, release);
    }

    /**
     * @notice After DISPUTE_TIMEOUT with no ruling, anyone returns the escrowed crypto to the
     *         seller's refund address and frees the LP's credit.
     * @dev REFUND TO ORIGIN, as on FiatEscrow and for the same reasons: it is the desk's own
     *      default, the one outcome silence cannot game, and exactly what happens to a claim
     *      nobody proves - it goes stale and the seller cancels. An LP that really paid, inside
     *      its claim's window, has DISPUTE_TIMEOUT to prove it (settleWithProof) or to get a
     *      RELEASE signed and submit it itself.
     *
     *      A timeout is no finding, so it never records a settlement. It records a lost dispute
     *      only when the LP raised it: an LP that disputes its own claim holds the seller's
     *      money for up to DISPUTE_TIMEOUT instead of PAY_WINDOW, and one that then never gets
     *      a ruling carries that. A seller's unanswered dispute costs the LP nothing - otherwise
     *      a seller could cut an LP's limit by disputing while the desk is down.
     */
    function expireDispute(bytes32 saleId) external nonReentrant {
        Sale storage s = sales[saleId];
        if (s.state != SaleState.DISPUTED) revert WrongState();
        uint64 deadline = disputedAt[saleId] + DISPUTE_TIMEOUT;
        if (block.timestamp < deadline) revert DisputeStillOpen(deadline);
        s.state = SaleState.CANCELLED;
        REGISTRY.releaseExposure(s.lp, s.brlCents);
        if (disputeRaisedByLP[saleId]) REGISTRY.recordDispute(s.lp);
        emit DisputeTimedOut(saleId);
        _pay(s.asset, s.refundTo, s.weiAmount);
    }

    /*//////////////////////////////////////////////////////////////
                              GOVERNANCE
    //////////////////////////////////////////////////////////////*/

    /// @notice Allowing a verifier waits out the governance delay; revoking one is instant.
    function setVerifier(address verifier, bool allowed) external {
        _authorizeChange(allowed && !allowedVerifier[verifier]);
        if (verifier == address(0)) revert ZeroAddress();
        allowedVerifier[verifier] = allowed;
        emit VerifierSet(verifier, allowed);
    }

    /// @notice Adding an arbitrator waits out the governance delay; removing one is instant.
    function setArbitrator(address arbitrator, bool allowed) external {
        bool known = arbitratorSince[arbitrator] != 0;
        _authorizeChange(allowed && !known);
        if (arbitrator == address(0)) revert ZeroAddress();
        // Two booleans; slither sees `known` derive from a timestamp and flags the comparison.
        // slither-disable-next-line incorrect-equality
        if (allowed == known) return; // re-adding must not reset "since"
        arbitratorSince[arbitrator] = allowed ? uint64(block.timestamp) : 0;
        emit ArbitratorSet(arbitrator, allowed);
    }

    /// @notice Whether a bank transaction has settled anything on any escrow of this registry.
    function usedBankTxId(bytes32 bankTxId) external view returns (bool) {
        return REGISTRY.usedBankTxId(bankTxId);
    }

    function isArbitrator(address arbitrator) external view returns (bool) {
        return arbitratorSince[arbitrator] != 0;
    }

    /// @notice Lowering or setting a first cap is instant; raising or removing one is delayed.
    function setAssetCap(address asset, uint256 cap) external {
        uint256 cur = assetCap[asset];
        _authorizeChange(cur != 0 && (cap == 0 || cap > cur));
        assetCap[asset] = cap;
        emit AssetCapSet(asset, cap);
    }

    function _isDelayable(bytes4 selector) internal pure override returns (bool) {
        return selector == OffRampEscrow.setAsset.selector
            || selector == OffRampEscrow.setVerifier.selector
            || selector == OffRampEscrow.setArbitrator.selector
            || selector == OffRampEscrow.setAssetCap.selector;
    }

    /*//////////////////////////////////////////////////////////////
                                INTERNAL
    //////////////////////////////////////////////////////////////*/

    function _railAccepted(uint16 mask, IAttestorVerifier.Rail rail) private pure returns (bool) {
        if (rail == IAttestorVerifier.Rail.UNSPECIFIED) return false;
        return mask & uint16(1 << uint8(rail)) != 0;
    }

    /**
     * @dev Checks freshness here rather than relying on the oracle to do it. IPriceOracle
     *      says an implementation MUST revert when stale, but "MUST" in an interface is a
     *      request, not an enforcement - and this contract holds the money.
     */
    /// @dev As FiatEscrow._receive: refuse a token the issuer froze this escrow for, then hold the cap.
    function _receive(address asset, uint256 amount) private {
        if (asset == address(0)) {
            if (msg.value != amount) revert WrongMsgValue();
        } else {
            if (msg.value != 0) revert WrongMsgValue();
            _requireNotFrozen(asset, address(this));
            SafeTransferLib.receiveToken(asset, msg.sender, amount);
        }
        uint256 held = heldOf[asset] += amount;
        uint256 cap = assetCap[asset];
        if (cap != 0 && held > cap) revert AssetCapExceeded(asset, cap);
    }

    function _requireNotFrozen(address asset, address who) private view {
        if (asset != address(0) && IssuerFreeze.isFrozen(asset, who)) revert FrozenByAssetIssuer(who);
    }

    function _pay(address asset, address to, uint256 amount) private {
        heldOf[asset] -= amount;
        if (asset == address(0)) _send(to, amount);
        else SafeTransferLib.safeTransfer(asset, to, amount);
    }

    function _requireWithinBand(address asset, uint256 price) private view {
        AssetConfig memory cfg = assets[asset];
        if (!cfg.enabled) revert AssetNotEnabled(asset);
        (uint256 mid, uint64 updatedAt) = cfg.oracle.brlCentsPerUnit();
        if (mid == 0) revert PriceOutsideBand();
        if (block.timestamp > uint256(updatedAt) + MAX_PRICE_AGE) revert StalePrice();
        uint256 diff = price > mid ? price - mid : mid - price;
        if (diff * 10_000 > mid * BAND_BPS) revert PriceOutsideBand();
    }

    /**
     * @dev Slither flags this as `arbitrary-send-eth`, and the flag is worth answering
     *      rather than muting wholesale. Every destination reaching here is one of: an
     *      address the ORDER's own taker named at lock time, the LP recorded on the offer,
     *      or a seller's own refund address. None is attacker-chosen for someone else's
     *      money, and the amount is always that record's escrowed amount. The detector
     *      cannot see that constraint because the address is read from storage.
     */
    // slither-disable-next-line arbitrary-send-eth
    function _send(address to, uint256 amount) private {
        (bool ok,) = to.call{value: amount}("");
        if (!ok) revert TransferFailed();
    }
}
