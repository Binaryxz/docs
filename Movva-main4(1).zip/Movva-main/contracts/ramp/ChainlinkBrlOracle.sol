// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IPriceOracle} from "./IPriceOracle.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";

interface IAggregatorV3 {
    function decimals() external view returns (uint8);
    function latestRoundData()
        external
        view
        returns (uint80 roundId, int256 answer, uint256 startedAt, uint256 updatedAt, uint80 answeredInRound);
}

/**
 * @title ChainlinkBrlOracle
 * @notice BRL centavos per 1 ETH, composed from two Chainlink feeds (task 2.5).
 *
 * There is no ETH/BRL feed, so this crosses ETH/USD with BRL/USD:
 *
 *      BRL per ETH  =  (ETH/USD) / (BRL/USD)
 *
 * Both legs are validated independently, because a cross is only as fresh as its stalest
 * input and only as sane as its worst one. Silent failure modes this rejects explicitly:
 *
 *  - a non-positive answer (a feed that has never been written returns 0, and 0 would make
 *    the escrow's band accept everything);
 *  - `updatedAt == 0`, which means the round was never completed;
 *  - an answer older than its own leg's max age - `ethUsdMaxAge`, `brlUsdMaxAge` - so a healthy
 *    ETH/USD cannot mask a frozen BRL/USD, the likelier of the two to stall, and each is judged
 *    against its own heartbeat (ETH/USD beats hourly, BRL/USD daily: one shared age was either too
 *    long for one or too short for the other, M-22);
 *  - an answer stamped more than MAX_FUTURE_SKEW ahead of the chain (I-46).
 *
 * Each max age lies between MIN_MAX_AGE and MAX_MAX_AGE, at construction and on every change: a
 * 1-second "tightening", which is instant, would otherwise freeze the band (as L-02 found on the FX leg).
 *
 * It reverts rather than returning a flag. The escrow calls this to decide whether a trade
 * is sane; "I don't know" must stop the trade, and a revert is the only answer a caller
 * cannot accidentally ignore.
 *
 * BRL/USD availability differs by chain, so `brlUsd` is settable by the governor rather than
 * immutable. That is a real trust surface and it is the reason the oracle is a *band* and
 * not the price: the worst a compromised feed can do is widen or narrow which offers are
 * accepted, never move value on its own.
 *
 * Settable is not the same as instant. Repointing a feed or lengthening the max age waits out
 * GOVERNANCE_DELAY (DelayedGovernance); tightening the max age with the feeds unchanged does
 * not. Pointing an escrow at a different oracle is delayed (SR2-14), and an instant feed swap
 * inside the oracle was the same change without the notice. Until `completeSetup()` the cross
 * refuses to price, as every governed oracle here does.
 */
contract ChainlinkBrlOracle is IPriceOracle, DelayedGovernance {
    IAggregatorV3 public ethUsd;
    IAggregatorV3 public brlUsd;
    uint64 public ethUsdMaxAge;
    uint64 public brlUsdMaxAge;

    uint64 public constant MIN_MAX_AGE = 15 minutes;
    uint64 public constant MAX_MAX_AGE = 2 days;
    uint64 public constant MAX_FUTURE_SKEW = 5 minutes;

    event FeedsSet(address ethUsd, address brlUsd, uint64 ethUsdMaxAge, uint64 brlUsdMaxAge);
    // `governor`, `transferGovernor`, `GovernorTransferred`, `NotGovernor()` and `ZeroAddress()`
    // are DelayedGovernance's now, with the signatures this contract declared itself.

    error StalePrice(address feed, uint256 updatedAt);
    error BadPrice(address feed, int256 answer);
    error BadMaxAge();
    error PriceFromFuture(address feed, uint256 updatedAt);

    constructor(
        address ethUsd_,
        address brlUsd_,
        uint64 ethUsdMaxAge_,
        uint64 brlUsdMaxAge_,
        address governor_,
        uint256 governanceDelay
    ) DelayedGovernance(governor_, governanceDelay) {
        _setFeeds(ethUsd_, brlUsd_, ethUsdMaxAge_, brlUsdMaxAge_);
    }

    /// @notice Repointing either feed or lengthening either max age waits out the governance
    ///         delay; tightening an age, feeds unchanged, is instant (never below MIN_MAX_AGE).
    function setFeeds(address ethUsd_, address brlUsd_, uint64 ethUsdMaxAge_, uint64 brlUsdMaxAge_) external {
        _authorizeChange(
            ethUsd_ != address(ethUsd) || brlUsd_ != address(brlUsd) || ethUsdMaxAge_ > ethUsdMaxAge
                || brlUsdMaxAge_ > brlUsdMaxAge
        );
        _setFeeds(ethUsd_, brlUsd_, ethUsdMaxAge_, brlUsdMaxAge_);
    }

    function _setFeeds(address ethUsd_, address brlUsd_, uint64 ethAge, uint64 brlAge) private {
        if (ethUsd_ == address(0) || brlUsd_ == address(0)) revert ZeroAddress();
        if (ethAge < MIN_MAX_AGE || ethAge > MAX_MAX_AGE || brlAge < MIN_MAX_AGE || brlAge > MAX_MAX_AGE) {
            revert BadMaxAge();
        }
        ethUsd = IAggregatorV3(ethUsd_);
        brlUsd = IAggregatorV3(brlUsd_);
        (ethUsdMaxAge, brlUsdMaxAge) = (ethAge, brlAge);
        emit FeedsSet(ethUsd_, brlUsd_, ethAge, brlAge);
    }

    function brlCentsPerUnit() external view returns (uint256 price, uint64 updatedAt) {
        _requireSetupComplete();
        (uint256 eth, uint256 ethAt, uint8 ethDec) = _read(ethUsd, ethUsdMaxAge);
        (uint256 brl, uint256 brlAt, uint8 brlDec) = _read(brlUsd, brlUsdMaxAge);

        // centavos per ETH = (ethUsd / brlUsd) * 100, carrying both feeds' decimals.
        price = (eth * (10 ** brlDec) * 100) / (brl * (10 ** ethDec));
        updatedAt = uint64(ethAt < brlAt ? ethAt : brlAt); // freshness of the stalest leg
    }

    function _isDelayable(bytes4 selector) internal pure override returns (bool) {
        return selector == ChainlinkBrlOracle.setFeeds.selector;
    }

    function _read(IAggregatorV3 feed, uint64 maxAge)
        private
        view
        returns (uint256 value, uint256 at, uint8 dec)
    {
        // roundId / startedAt / answeredInRound are deliberately unused: the modern
        // aggregator contract no longer exposes a meaningful stale-round signal through
        // them, so freshness is judged by updatedAt alone.
        // slither-disable-next-line unused-return
        (, int256 answer,, uint256 updatedAt_,) = feed.latestRoundData();
        if (answer <= 0) revert BadPrice(address(feed), answer);
        if (updatedAt_ == 0 || block.timestamp > updatedAt_ + maxAge) {
            revert StalePrice(address(feed), updatedAt_);
        }
        if (updatedAt_ > block.timestamp + MAX_FUTURE_SKEW) revert PriceFromFuture(address(feed), updatedAt_);
        return (uint256(answer), updatedAt_, feed.decimals());
    }
}
