// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IBandPriceOracle} from "./IBandPriceOracle.sol";
import {IPyth} from "./IPyth.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";
import {FxMarketHours} from "../common/FxMarketHours.sol";

/**
 * @title PythFxOracle
 * @notice Reais per US dollar from Pyth's FX.USD/BRL feed, scaled 1e6 - the unit MovvaReserve prices
 *         in (R$ 5,4012 is 5_401_200). The ramps read it in centavos through ScaledFxBandOracle.
 *
 * ## Why Pyth, and what keeps it fresh
 *
 * Mova decided (14 September 2026) that the USD/BRL rate comes from Pyth rather than from named
 * publishers. Pyth publishes FX.USD/BRL; it was missing on Ethereum only because nobody posted it
 * there (PythFork.t.sol): Pyth is pull-based, and a price exists on a chain once someone submits a
 * signed update. Mova's keeper (packages/yield, `pyth-keeper`) posts updates fetched from Hermes. This
 * contract never posts one itself - that would make a read payable and put Hermes inside every trade -
 * so if nobody keeps the feed warm it goes stale and refuses, which is the right failure.
 *
 * Trust moves rather than disappears: from named publishers to Pyth's publisher set and the Wormhole
 * guardians whose signatures the Pyth contract checks on every update.
 *
 * ## Two readings: the rate, and a band's price
 *
 * The feed trades only on weekdays, 08:00-17:00 New York time (FxMarketHours). PIX does not close.
 *
 *  - `brlCentsPerUnit` is the RATE: the price as last traded, refused once older than `maxAge`, at any
 *    hour. MovvaReserve mints and redeems at it. A rate moves value, so while the market is closed this
 *    refuses and minting and redeeming wait for it to reopen (Mova's decision, 14 September 2026).
 *  - `brlCentsPerUnitForBand` is a BAND's price. Inside FxMarketHours' core session it is the rate,
 *    with the same age limit. Outside it, a price up to `closedMaxAge` old is taken as the last close,
 *    which stands until the market reopens, and is returned stamped with the current block's time - so
 *    the escrows' own one-hour check (MAX_PRICE_AGE) keeps trading against it. A band only admits or
 *    refuses offers; it never sets a trade's price (IPriceOracle). The worst a closing price does is
 *    admit an offer that a move since the close has pushed toward the band's edge, which the taker, who
 *    sees the price, must still accept.
 *
 * Outside the core session nothing tells a closing price from a price the keeper stopped posting early.
 * A keeper that dies at noon therefore leaves the bands on its last price from the close until the next
 * core session - at most `closedMaxAge` - and the monitor alerts on the stale rate meanwhile, because
 * the rate itself is refused at once.
 *
 * ## Checks on every read
 *
 * Setup complete; a price above zero; an exponent within +-18 before it reaches a power of ten; a
 * confidence interval no wider than `maxConfBps` of the price - a wide interval is Pyth's publishers
 * saying nobody currently knows the rate (see PythBrlOracle); and a publish time no more than
 * MAX_FUTURE_SKEW ahead of the chain.
 *
 * ## Governance (DelayedGovernance)
 *
 * Repointing the feed, or loosening a limit - a longer `maxAge` or `closedMaxAge`, a wider `maxConfBps`
 * - waits out GOVERNANCE_DELAY; tightening is instant, and never takes `maxAge` below MIN_MAX_AGE. A `closedMaxAge` of zero stops the bands outside
 * the core session as well. Until `completeSetup()` neither reading prices.
 */
contract PythFxOracle is IBandPriceOracle, DelayedGovernance {
    IPyth public immutable PYTH;
    /// @notice Pyth's FX.USD/BRL price id: reais per ONE US dollar (not dollars per real).
    bytes32 public usdBrlId;
    /// @notice The oldest price that is still the rate, at any hour.
    uint64 public maxAge;
    /// @notice The oldest price a band takes as the last close, outside the core session.
    uint64 public closedMaxAge;
    /// @notice Refuse a price whose confidence interval is wider than this share of it.
    uint16 public maxConfBps;

    /// @notice The longest closure on the schedule is a holiday beside a weekend - Friday's close to
    ///         Tuesday's open when 25 December is a Monday, 88 hours. Four days covers it and the time
    ///         between the last update and the close; nothing longer is a closure.
    uint64 public constant MAX_CLOSED_MAX_AGE = 4 days;
    /// @notice A confidence bound above 10% of the price bounds nothing a band needs.
    uint16 public constant MAX_CONF_BPS = 1_000;
    /// @notice `maxAge` bounds (L-02, I-45). Below 15 minutes a "tightening", which is instant, would make a
    ///         healthy feed read stale - every mint and redemption frozen by one transaction - and the
    ///         reserve already refuses less (MIN_FX_MAX_AGE). Above a day the rate is not a rate.
    uint64 public constant MIN_MAX_AGE = 15 minutes;
    uint64 public constant MAX_MAX_AGE = 1 days;
    /// @notice As SignedPriceOracle and the crosses allow: freshness from the future outlives the update.
    uint64 public constant MAX_FUTURE_SKEW = 5 minutes;

    event FeedSet(bytes32 usdBrlId);
    event LimitsSet(uint64 maxAge, uint64 closedMaxAge, uint16 maxConfBps);

    error BadFeedId();
    error BadLimits();
    error BadPrice(int64 price);
    error ExponentOutOfRange(int32 expo);
    error ConfidenceTooWide(uint64 conf, int64 price);
    error PriceFromFuture(uint256 publishTime);
    error StaleRate(uint256 publishTime);
    error PriceRoundsToZero();

    constructor(
        address pyth,
        bytes32 usdBrlId_,
        uint64 maxAge_,
        uint64 closedMaxAge_,
        uint16 maxConfBps_,
        address governor_,
        uint256 governanceDelay
    ) DelayedGovernance(governor_, governanceDelay) {
        if (pyth == address(0)) revert ZeroAddress();
        if (usdBrlId_ == bytes32(0)) revert BadFeedId();
        PYTH = IPyth(pyth);
        usdBrlId = usdBrlId_;
        emit FeedSet(usdBrlId_);
        _setLimits(maxAge_, closedMaxAge_, maxConfBps_);
    }

    /// @notice The rate: reais per US dollar at 1e-6, refused once older than `maxAge`.
    /// @dev `updatedAt` is Pyth's publish time.
    function brlCentsPerUnit() external view returns (uint256 price, uint64 updatedAt) {
        uint256 publishTime;
        (price, publishTime) = _read();
        if (block.timestamp > publishTime + maxAge) revert StaleRate(publishTime);
        updatedAt = uint64(publishTime);
    }

    /// @inheritdoc IBandPriceOracle
    function brlCentsPerUnitForBand() external view returns (uint256 price, uint64 updatedAt) {
        uint256 publishTime;
        (price, publishTime) = _read();
        if (block.timestamp <= publishTime + maxAge) return (price, uint64(publishTime));
        // Old. Inside the core session the market is trading, so an old price is a missing one; outside
        // it, a price no older than closedMaxAge is the last close and stands until the reopening.
        if (FxMarketHours.inCoreSession(block.timestamp) || block.timestamp > publishTime + closedMaxAge) {
            revert StaleRate(publishTime);
        }
        updatedAt = uint64(block.timestamp);
    }

    /// @notice True inside FxMarketHours' core session, when a band refuses an old price. For readers.
    function inCoreSession() external view returns (bool) {
        return FxMarketHours.inCoreSession(block.timestamp);
    }

    /*//////////////////////////////////////////////////////////////
                              GOVERNANCE
    //////////////////////////////////////////////////////////////*/

    /// @notice Repointing the feed waits out the governance delay.
    function setFeed(bytes32 usdBrlId_) external {
        _authorizeChange(usdBrlId_ != usdBrlId);
        if (usdBrlId_ == bytes32(0)) revert BadFeedId();
        usdBrlId = usdBrlId_;
        emit FeedSet(usdBrlId_);
    }

    /// @notice Loosening any limit waits out the governance delay; tightening is instant.
    function setLimits(uint64 maxAge_, uint64 closedMaxAge_, uint16 maxConfBps_) external {
        _authorizeChange(maxAge_ > maxAge || closedMaxAge_ > closedMaxAge || maxConfBps_ > maxConfBps);
        _setLimits(maxAge_, closedMaxAge_, maxConfBps_);
    }

    function _isDelayable(bytes4 selector) internal pure override returns (bool) {
        return selector == PythFxOracle.setFeed.selector || selector == PythFxOracle.setLimits.selector;
    }

    /*//////////////////////////////////////////////////////////////
                                INTERNAL
    //////////////////////////////////////////////////////////////*/

    /// @dev Reais per dollar at 1e-6, and Pyth's publish time, after every check but age.
    function _read() private view returns (uint256 price, uint256 publishTime) {
        _requireSetupComplete();
        // Age is judged by the two readings above, each against its own limit.
        IPyth.Price memory p = PYTH.getPriceUnsafe(usdBrlId);
        if (p.price <= 0) revert BadPrice(p.price);
        // Before it reaches a power of ten: a corrupt feed must not be able to burn the caller's gas.
        if (p.expo < -18 || p.expo > 18) revert ExponentOutOfRange(p.expo);
        uint256 abs = uint256(uint64(p.price));
        if (uint256(p.conf) * 10_000 > abs * maxConfBps) revert ConfidenceTooWide(p.conf, p.price);
        if (p.publishTime > block.timestamp + MAX_FUTURE_SKEW) revert PriceFromFuture(p.publishTime);
        // price x 10^expo reais per dollar, times 10^6. Floor: the tick is a millionth of a real.
        int256 shift = int256(p.expo) + 6;
        price = shift >= 0 ? abs * 10 ** uint256(shift) : abs / 10 ** uint256(-shift);
        if (price == 0) revert PriceRoundsToZero();
        publishTime = p.publishTime;
    }

    function _setLimits(uint64 maxAge_, uint64 closedMaxAge_, uint16 maxConfBps_) private {
        // Zero max age refuses every price and zero confidence refuses every real one: mistakes to
        // report, not settings to store. A zero closedMaxAge is a setting - no closing prices at all.
        if (
            maxAge_ < MIN_MAX_AGE || maxAge_ > MAX_MAX_AGE || closedMaxAge_ > MAX_CLOSED_MAX_AGE || maxConfBps_ == 0
                || maxConfBps_ > MAX_CONF_BPS
        ) {
            revert BadLimits();
        }
        maxAge = maxAge_;
        closedMaxAge = closedMaxAge_;
        maxConfBps = maxConfBps_;
        emit LimitsSet(maxAge_, closedMaxAge_, maxConfBps_);
    }
}
