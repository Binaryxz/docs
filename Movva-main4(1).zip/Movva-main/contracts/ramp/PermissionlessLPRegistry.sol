// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {IERC20Metadata} from "@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {ILPRegistry} from "./ILPRegistry.sol";

/// @dev What the registry reads from each escrow when it binds them. Both escrows have these getters.
interface IBoundEscrow {
    function REGISTRY() external view returns (address);
    function DISPUTE_TIMEOUT() external view returns (uint64);
}

/// @dev OffRampEscrow's RULING_DELAY is public; FiatEscrow's is the same value, internal for size.
interface IRulingDelay {
    function RULING_DELAY() external view returns (uint64);
}

/**
 * @title PermissionlessLPRegistry
 * @notice An LP registry with no curator and no admin: an LP joins by bonding MOVVA, its credit IS its bond, a lost
 *         dispute takes the bond, and an LP leaves by asking to and waiting out an unbonding period. Implements
 *         ILPRegistry exactly, so the audited FiatEscrow and OffRampEscrow, unchanged, run against it. Design and
 *         parameters: docs/permissionless-registry.md.
 *
 * ## What the client asked for (19 Oct 2026), and where each one is
 *
 *  - Any LP joins by posting the required bond and meeting on-chain rules: `join`. The rules are the bond (at least
 *    MIN_BOND), the escrows being bound, and the address not being bonded or exiting already. Nothing else.
 *  - Any LP exits after an unbonding period: `requestExit`, then `withdraw` once UNBONDING_PERIOD has passed and none
 *    of its exposure is live.
 *  - The escrows accept LPs dynamically, with no curator and no admin: `capOf` is a pure function of the bond.
 *  - A misbehaving LP loses its bond automatically: `recordDispute`, called by the escrow when a dispute is ruled
 *    against the LP, slashes it in the same transaction, with no human step after the ruling.
 *  - No admin key is needed to add or remove an LP: there is no admin key at all (see "No admin").
 *
 * ## Credit is the bond, centavo for centavo
 *
 * One MOVVA is R$ 1,00, so one centavo is 1e16 MOVVA base units (TOKEN_PER_CENT), and `capOf` is the bond, less
 * BOND_HAIRCUT_BPS, divided by that, rounded down: the limit never exceeds what the bond is worth, even with MOVVA
 * trading that far under its peg (v2.0 L-03). Every centavo of exposure an LP can hold live is more than a centavo
 * it has bonded.
 *
 * Why 1:1. The most a lost dispute can cost a counterparty is the disputed position's own BRL value: on the on-ramp,
 * an LP that disputes an order the taker really paid, and is never ruled against in time, keeps the taker's BRL and
 * its crypto (FiatEscrow.expireDispute); on the off-ramp the seller's crypto always comes back, so the worst there is
 * the time it was frozen. Every such position is exposure reserved here - an LP's own dispute keeps it reserved until
 * the dispute ends - and the escrows can reserve no more than the credit. So the sum of everything an LP could take
 * from counterparties at one time is at most its credit, which is its bond, and the whole bond is what a lost
 * dispute takes (below). Misbehaving is therefore never profitable: the gain is at most the exposure, the loss is at
 * least the bond. A ratio above 1:1 (credit greater than the bond) would break that; the haircut keeps the ratio below
 * it, so the guarantee holds while MOVVA trades up to BOND_HAIRCUT_BPS under R$ 1,00 (L-03; 10% at deploy).
 *
 * ## A lost dispute takes the whole bond
 *
 * `recordDispute(lp)` carries no amount and no counterparty (ILPRegistry is frozen with the escrows), so the slash
 * cannot be sized to the disputed position or paid to its victim. Of the rules that need neither, only "the whole
 * bond" keeps the guarantee above: a fixed share (half, say) of a bond would let an LP whose one disputed position is
 * larger than that share come out ahead. It is also what the client wrote: a misbehaving LP "loses its bond". The
 * credit then drops to zero, so the LP takes nothing new, and the escrows' suspension lever (`capOf == 0`) lets anyone
 * close its standing offers. Positions already live run off normally. Later lost disputes find no bond and take
 * nothing more, which is still sound: the first one took at least everything the LP could have gained across all of
 * them. An LP can bond again (`join`), and that bond answers for any dispute still to be ruled.
 *
 * What triggers it is exactly what the escrows report: an off-ramp REFUND ruling (the LP claimed a sale and did not
 * pay), an LP's own dispute that it then loses or lets time out, on either escrow. A counterparty's unanswered dispute
 * never reaches here - the escrows decided that, so nobody can cost an LP its bond by disputing during a desk outage.
 * The bond is therefore exactly as safe as the escrows' arbitration: see "Trust".
 *
 * ## Where slashed MOVVA goes: nowhere, for ever
 *
 * Movva can only be burned by its reserve, and only out of the reserve's own balance; a transfer to address(0)
 * reverts (OpenZeppelin ERC20). Paying it to Mova (the fee recipient) would give the party whose arbitrators decide
 * disputes a stake in the outcome. The victim is not named by `recordDispute`. So slashed MOVVA stays in this
 * contract, counted in `totalSlashed`, and no function can move it: a burn in all but the token's `totalSupply`. That
 * benefits every holder - the reserve's backing now stands behind fewer tokens that can ever be redeemed - and nobody
 * in particular, so nobody profits from a slash. (MovvaReserve.collateralRatioBps still counts the locked tokens as
 * supply, so it understates the ratio by them: the conservative direction.)
 *
 * ## Exit: credit at once, bond after the dispute window and the last position
 *
 * `requestExit` makes `capOf` zero in the same transaction: no reservation can succeed, `_lock` refuses new orders
 * against the LP's offers, and anyone may close them (FiatEscrow.closeOffer). `withdraw` then needs BOTH
 *
 *  - UNBONDING_PERIOD since the request, which `bindEscrows` checks is longer than each escrow's DISPUTE_TIMEOUT plus
 *    the RULING_DELAY plus UNBONDING_MARGIN (the longest pay window a position open at the request can still run, a
 *    boleto's 1 h issue + 3 days pay, plus a day for inclusion); and
 *  - none of its exposure live (`bonds[lp].exposureCents == 0`).
 *
 * The second is the one that closes it. Every escrow path that ends in `recordDispute` holds the position's exposure
 * until the very transaction that reports the dispute: the off-ramp releases it immediately before; the on-ramp keeps
 * an LP-disputed order inside its offer, so inside the offer's reservation. A position with no exposure here is one
 * that can no longer cost the LP its bond (a taker's on-ramp dispute releases the credit at once, and none of its
 * outcomes records a lost dispute). And nothing new can be reserved once the credit is zero. So when the exposure is
 * zero no dispute can still slash the bond, whenever it is withdrawn; the time bound is the client's rule and a public
 * notice period on top of that. A LOCKED order nobody reclaims can be disputed long after its pay window, which is why
 * time alone would not have been enough.
 *
 * There is no cancelling an exit, and no partial unbonding: an LP that wants back in withdraws and joins again. Fewer
 * paths, fewer states, one rule for when a bond may leave.
 *
 * ## No admin
 *
 * No owner, governor, curator, pause, upgrade or setter. MOVVA, PREDECESSOR, MIN_BOND and UNBONDING_PERIOD are
 * immutables; the credit ratio, the slash and the margin are constants.
 *
 * The escrows are the one thing that cannot be immutable: each takes the registry's address in its constructor, so
 * the registry exists first. `bindEscrows` is a one-shot setup: only DEPLOYER may call it, only once, and only with
 * two escrows that already point back at this registry and whose dispute windows fit inside UNBONDING_PERIOD. After
 * it, `escrowsBound()` is true for ever and DEPLOYER has no power left; before it, nobody can join, so no bond is ever
 * at risk from a choice its LP could not see first. The escrow set never changes: a new escrow pair needs a new
 * registry (with this one as PREDECESSOR, below).
 *
 * ## One bank transaction, one settlement, across registries
 *
 * As in LPRegistry, a bank transaction id is spent here, so it settles one position on either escrow. A new registry
 * starts with an empty set, so an id spent under the registry it replaces could settle a second position here.
 * PREDECESSOR (zero for none) is that registry: `consumeBankTxId` refuses, and `usedBankTxId` reports, any id it has
 * spent. A successor that names this registry as its own predecessor inherits both sets, transitively.
 *
 * The other direction is not closed here and cannot be: the predecessor does not consult its successor, so an id
 * spent here could still settle a position on the predecessor's own escrows. That needs a live position there; the
 * cutover (docs, "Cutover") suspends every LP on the old registry first, so none can be opened, and lets the ones
 * already open run off.
 *
 * ## Rewards: none
 *
 * NodeRewards pays only INSTITUTIONAL and AFFILIATED LPs, because its farming bounds rest on contracted identities
 * (SR2-36): an LP settling with itself from a second address is a breach with a named counterparty. A permissionless
 * LP has no such counterparty, so its settlements must not earn rewards, and a hook here could only ever report it as
 * RETAIL, which NodeRewards ignores. There is therefore no hook: `recordSettled` only counts and emits. A rewards
 * scheme for bonded LPs would be a new contract with its own bounds, reading the `Settled` events.
 *
 * ## Trust
 *
 * Nobody can add, remove, re-credit or slash an LP except by the rules above. What remains trusted is the escrows'
 * dispute process, unchanged: an arbitrator's ruling is what decides a lost dispute, and the escrows' governors set
 * the arbitrators (adding one waits out their GOVERNANCE_DELAY, in public). A malicious arbitrator could burn LPs'
 * bonds by ruling REFUND on disputed off-ramp sales; it could not take them.
 *
 * ## Never reverts where the escrows need it not to
 *
 * `releaseExposure`, `recordSettled` and `recordDispute` make no external call, write a fixed number of slots, and
 * return quietly for any caller that is not a bound escrow. MOVVA moves only in `join`, `topUp` and `withdraw`, by the
 * LP's own call: a plain OpenZeppelin ERC20 with no transfer hook, fee or rebase, so the amount sent is the amount
 * received and no transfer can call back in.
 */
contract PermissionlessLPRegistry is ILPRegistry {
    using SafeERC20 for IERC20;

    struct Bond {
        /// MOVVA base units bonded and neither slashed nor withdrawn.
        uint256 amount;
        /// Live BRL exposure across both escrows, in centavos.
        uint256 exposureCents;
        /// Lifetime settled volume, in centavos. A record only: it moves no limit.
        uint256 settledCents;
        /// When the LP asked to leave; zero while it is not leaving.
        uint64 exitRequestedAt;
        uint32 settlements;
        uint32 disputesLost;
    }

    /// @notice MOVVA base units per BRL centavo: 1 MOVVA (1e18) is R$ 1,00, 100 centavos.
    uint256 public constant TOKEN_PER_CENT = 1e16;
    /// @notice The escrows' RULING_DELAY: public on OffRampEscrow, the same value on FiatEscrow.
    uint64 public constant ESCROW_RULING_DELAY = 1 days;
    /// @notice Room in UNBONDING_PERIOD beyond the dispute window: FiatEscrow's longest pay window (a boleto's 1 h to
    ///         issue and 3 days to pay) for a position open when the exit is asked, plus most of a day for inclusion.
    uint64 public constant UNBONDING_MARGIN = 4 days;
    /// @notice No unbonding period may exceed a year: past that a typo locks every bond for good.
    uint64 public constant MAX_UNBONDING_PERIOD = 365 days;

    /// @notice The bond asset.
    IERC20 public immutable MOVVA;
    /// @notice The registry this one replaces, whose spent bank transaction ids stay spent here. Zero for none.
    ILPRegistry public immutable PREDECESSOR;
    /// @notice The least an LP may bond to join, in MOVVA base units. A whole number of centavos.
    uint256 public immutable MIN_BOND;
    /// @notice How much of a bond is NOT credit, in bps (L-03): the room for MOVVA under its peg. At most half.
    uint256 public immutable BOND_HAIRCUT_BPS;
    /// @notice How long after `requestExit` a bond may be withdrawn (if no exposure is live), in seconds.
    uint64 public immutable UNBONDING_PERIOD;
    /// @notice Who may bind the escrows, once. Powerless afterwards.
    address public immutable DEPLOYER;

    /// @notice The on-ramp escrow, bound once by `bindEscrows`; zero before.
    address public fiatEscrow;
    /// @notice The off-ramp escrow, bound once by `bindEscrows`; zero before.
    address public offRampEscrow;

    mapping(address => Bond) public bonds;
    /// @notice Escrow => LP => exposure that escrow reserved and has not released.
    mapping(address => mapping(address => uint256)) public reservedBy;
    /// @notice Bank transactions spent on THIS registry's escrows. `usedBankTxId` adds the predecessor's.
    mapping(bytes32 => bool) public spentHere;

    /// @notice MOVVA bonded and not slashed or withdrawn: the sum of every `bonds[lp].amount`.
    uint256 public totalBonded;
    /// @notice MOVVA taken by lost disputes, locked here for ever. See "Where slashed MOVVA goes".
    uint256 public totalSlashed;

    event EscrowsBound(address indexed fiatEscrow, address indexed offRampEscrow);
    event Joined(address indexed lp, uint256 amount);
    event ToppedUp(address indexed lp, uint256 amount, uint256 bond);
    event ExitRequested(address indexed lp, uint256 withdrawableFrom);
    event Withdrawn(address indexed lp, uint256 amount);
    event Slashed(address indexed lp, address indexed escrow, uint256 amount);
    event DisputeLost(address indexed lp, uint32 total);
    event Settled(address indexed lp, uint256 brlCents);
    event ExposureReserved(
        address indexed lp, address indexed escrow, uint256 brlCents, uint256 total
    );
    event ExposureReleased(
        address indexed lp, address indexed escrow, uint256 brlCents, uint256 total
    );
    event BankTxIdConsumed(bytes32 indexed bankTxId, address indexed escrow);

    error ZeroAddress();
    error NotAContract(address who);
    error BadMovva();
    error BadMinBond(uint256 minBond);
    error BadHaircut(uint256 bps);
    error BadUnbondingPeriod(uint256 period);
    error NotDeployer();
    error AlreadyBound();
    error NotBound();
    error BadEscrow(address escrow);
    error DisputeWindowTooLong(address escrow, uint256 window, uint256 unbondingPeriod);
    error NotEscrow();
    error AlreadyBonded();
    error NotBonded();
    error BelowMinBond(uint256 amount, uint256 minBond);
    error ZeroAmount();
    error Exiting();
    error NotExiting();
    error StillUnbonding(uint256 withdrawableFrom);
    error ExposureLive(uint256 exposureCents);

    /**
     * @param movva The MOVVA token: 18 decimals, R$ 1,00 each.
     * @param predecessor The registry whose spent bank transaction ids stay spent here; zero for a fresh rail.
     * @param minBond The least an LP may bond, in MOVVA base units: at least R$ 1,00, a whole number of centavos.
     * @param unbondingPeriod How long a leaving LP's bond stays answerable. `bindEscrows` refuses escrows whose
     *        dispute window (DISPUTE_TIMEOUT + ESCROW_RULING_DELAY + UNBONDING_MARGIN) is not shorter.
     * @param bondHaircutBps The share of a bond that is not credit (L-03), 1 to 5,000 bps.
     */
    constructor(address movva, address predecessor, uint256 minBond, uint256 unbondingPeriod, uint256 bondHaircutBps) {
        if (movva == address(0)) revert ZeroAddress();
        if (movva.code.length == 0) revert NotAContract(movva);
        if (IERC20Metadata(movva).decimals() != 18) revert BadMovva();
        if (predecessor != address(0)) {
            if (predecessor.code.length == 0) revert NotAContract(predecessor);
            // A registry answers this for any id; anything that does not is not a registry. The answer itself is not
            // needed - the call is a probe, and a revert here is the refusal.
            // slither-disable-next-line unused-return
            ILPRegistry(predecessor).usedBankTxId(bytes32(0));
        }
        if (minBond < 100 * TOKEN_PER_CENT || minBond % TOKEN_PER_CENT != 0) {
            revert BadMinBond(minBond);
        }
        if (unbondingPeriod == 0 || unbondingPeriod > MAX_UNBONDING_PERIOD) {
            revert BadUnbondingPeriod(unbondingPeriod);
        }
        if (bondHaircutBps == 0 || bondHaircutBps > 5_000) revert BadHaircut(bondHaircutBps);
        BOND_HAIRCUT_BPS = bondHaircutBps;
        MOVVA = IERC20(movva);
        PREDECESSOR = ILPRegistry(predecessor);
        MIN_BOND = minBond;
        UNBONDING_PERIOD = uint64(unbondingPeriod);
        DEPLOYER = msg.sender;
    }

    /*//////////////////////////////////////////////////////////////
                              ONE-SHOT SETUP
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Bind the escrow pair, once. DEPLOYER only; after this nobody can change anything.
     * @dev Each escrow must already exist and name this registry as its REGISTRY, so the pair cannot be swapped for
     *      contracts that do not run against it; and each one's dispute window must end inside UNBONDING_PERIOD, so an
     *      exit cannot outrun a dispute. Which code the pair runs is for the LPs to check before they bond (the docs
     *      and `lp bond:status` show how); nobody can bond before this call, so nobody bonds blind.
     */
    function bindEscrows(address fiat, address offRamp) external {
        if (msg.sender != DEPLOYER) revert NotDeployer();
        if (fiatEscrow != address(0)) revert AlreadyBound();
        if (fiat == address(0) || offRamp == address(0)) revert ZeroAddress();
        if (fiat == offRamp) revert BadEscrow(offRamp);
        uint64 rulingDelay = IRulingDelay(offRamp).RULING_DELAY();
        if (rulingDelay != ESCROW_RULING_DELAY) revert BadEscrow(offRamp);
        _checkEscrow(fiat);
        _checkEscrow(offRamp);
        fiatEscrow = fiat;
        offRampEscrow = offRamp;
        emit EscrowsBound(fiat, offRamp);
    }

    function _checkEscrow(address escrow) private view {
        if (escrow.code.length == 0) revert NotAContract(escrow);
        if (IBoundEscrow(escrow).REGISTRY() != address(this)) revert BadEscrow(escrow);
        uint256 window =
            uint256(IBoundEscrow(escrow).DISPUTE_TIMEOUT()) + ESCROW_RULING_DELAY + UNBONDING_MARGIN;
        if (window >= UNBONDING_PERIOD) {
            revert DisputeWindowTooLong(escrow, window, UNBONDING_PERIOD);
        }
    }

    /// @notice True once the escrows are bound: from then on the registry has no setup and no admin.
    function escrowsBound() public view returns (bool) {
        return fiatEscrow != address(0);
    }

    /// @notice Whether `who` is one of the two bound escrows.
    function isEscrow(address who) public view returns (bool) {
        return who != address(0) && (who == fiatEscrow || who == offRampEscrow);
    }

    /*//////////////////////////////////////////////////////////////
                               LP SIDE
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Join: bond `amount` MOVVA (at least MIN_BOND) and take that much credit. Approve this contract first.
     * @dev Also how an LP returns after a slash took its bond, or after it withdrew. Its record (settled volume,
     *      disputes lost) is kept: an address is free, so it would mean nothing to refuse one, but the history stays
     *      readable. Any exposure still live from before counts against the new credit at once.
     */
    function join(uint256 amount) external {
        if (!escrowsBound()) revert NotBound();
        Bond storage b = bonds[msg.sender];
        if (b.exitRequestedAt != 0) revert Exiting();
        if (b.amount != 0) revert AlreadyBonded();
        if (amount < MIN_BOND) revert BelowMinBond(amount, MIN_BOND);
        b.amount = amount;
        totalBonded += amount;
        emit Joined(msg.sender, amount);
        MOVVA.safeTransferFrom(msg.sender, address(this), amount);
    }

    /// @notice Add to a bond, and so to the credit. Not while leaving.
    function topUp(uint256 amount) external {
        Bond storage b = bonds[msg.sender];
        if (b.amount == 0) revert NotBonded();
        if (b.exitRequestedAt != 0) revert Exiting();
        if (amount == 0) revert ZeroAmount();
        b.amount += amount;
        totalBonded += amount;
        emit ToppedUp(msg.sender, amount, b.amount);
        MOVVA.safeTransferFrom(msg.sender, address(this), amount);
    }

    /// @notice Stop taking new business now; the bond can be withdrawn after UNBONDING_PERIOD, once nothing is live.
    function requestExit() external {
        Bond storage b = bonds[msg.sender];
        if (b.amount == 0) revert NotBonded();
        if (b.exitRequestedAt != 0) revert Exiting();
        b.exitRequestedAt = uint64(block.timestamp);
        emit ExitRequested(msg.sender, block.timestamp + UNBONDING_PERIOD);
    }

    /**
     * @notice Take the bond back: UNBONDING_PERIOD after `requestExit`, with no exposure live. Ends the exit, so the
     *         address may join again. A bond a slash emptied during the exit withdraws nothing and still ends it.
     */
    function withdraw() external {
        Bond storage b = bonds[msg.sender];
        uint256 asked = b.exitRequestedAt;
        if (asked == 0) revert NotExiting();
        uint256 from = asked + UNBONDING_PERIOD;
        // A period of weeks against the clock: the seconds a proposer can skew a timestamp cannot matter.
        // slither-disable-next-line timestamp
        if (block.timestamp < from) revert StillUnbonding(from);
        if (b.exposureCents != 0) revert ExposureLive(b.exposureCents);
        uint256 amount = b.amount;
        b.amount = 0;
        b.exitRequestedAt = 0;
        totalBonded -= amount;
        emit Withdrawn(msg.sender, amount);
        if (amount != 0) MOVVA.safeTransfer(msg.sender, amount);
    }

    /// @notice When a leaving LP's bond becomes withdrawable (exposure permitting); zero if it is not leaving.
    function withdrawableFrom(address lp) external view returns (uint256) {
        uint256 asked = bonds[lp].exitRequestedAt;
        // Zero is the "not leaving" sentinel, never a time anyone can hit: it is not a comparison with the clock.
        // slither-disable-next-line incorrect-equality,timestamp
        return asked == 0 ? 0 : asked + UNBONDING_PERIOD;
    }

    /*//////////////////////////////////////////////////////////////
                              CREDIT LIMITS
    //////////////////////////////////////////////////////////////*/

    /// @inheritdoc ILPRegistry
    /// @dev The bond in centavos, rounded down. Zero before the escrows are bound, while leaving, and below MIN_BOND.
    function capOf(address lp) public view returns (uint256) {
        if (!escrowsBound()) return 0;
        Bond storage b = bonds[lp];
        if (b.exitRequestedAt != 0 || b.amount < MIN_BOND) return 0;
        return b.amount * (10_000 - BOND_HAIRCUT_BPS) / 10_000 / TOKEN_PER_CENT;
    }

    /// @notice How much more exposure the LP may take on right now, in centavos.
    function availableCents(address lp) public view returns (uint256) {
        uint256 cap = capOf(lp);
        uint256 live = bonds[lp].exposureCents;
        return cap > live ? cap - live : 0;
    }

    /// @inheritdoc ILPRegistry
    function canQuote(address lp, uint256 brlCents) external view returns (bool) {
        return capOf(lp) != 0 && brlCents <= availableCents(lp);
    }

    /*//////////////////////////////////////////////////////////////
                         ESCROW-FACING ACCOUNTING
    //////////////////////////////////////////////////////////////*/

    /// @inheritdoc ILPRegistry
    /// @dev Refused (false) for an LP with no credit at all, whatever the amount.
    function reserveExposure(address lp, uint256 brlCents) external returns (bool) {
        if (!isEscrow(msg.sender)) revert NotEscrow();
        if (capOf(lp) == 0 || brlCents > availableCents(lp)) return false;
        Bond storage b = bonds[lp];
        b.exposureCents += brlCents;
        reservedBy[msg.sender][lp] += brlCents;
        emit ExposureReserved(lp, msg.sender, brlCents, b.exposureCents);
        return true;
    }

    /// @inheritdoc ILPRegistry
    /// @dev A caller can release only what it reserved; anyone else releases nothing. Never reverts.
    function releaseExposure(address lp, uint256 brlCents) external {
        uint256 held = reservedBy[msg.sender][lp];
        if (brlCents > held) brlCents = held;
        if (brlCents == 0) return;
        Bond storage b = bonds[lp];
        reservedBy[msg.sender][lp] = held - brlCents;
        // An LP's exposure is the sum of what each escrow holds for it, so this cannot underflow; saturating anyway,
        // because this path must not revert.
        uint256 live = b.exposureCents;
        b.exposureCents = live > brlCents ? live - brlCents : 0;
        emit ExposureReleased(lp, msg.sender, brlCents, b.exposureCents);
    }

    /// @inheritdoc ILPRegistry
    /// @dev A record, not a limit: settled volume moves no credit. No rewards hook (see "Rewards: none").
    function recordSettled(address lp, uint256 brlCents) external {
        if (!isEscrow(msg.sender)) return;
        Bond storage b = bonds[lp];
        unchecked {
            b.settledCents += brlCents;
            b.settlements += 1;
        }
        emit Settled(lp, brlCents);
    }

    /**
     * @inheritdoc ILPRegistry
     * @dev Slashes the whole bond into `totalSlashed`, where it stays for ever. No external call, a fixed number of
     *      writes, and quiet for a caller that is not a bound escrow: it runs on the escrows' ruling and timeout paths.
     */
    function recordDispute(address lp) external {
        if (!isEscrow(msg.sender)) return;
        Bond storage b = bonds[lp];
        uint256 slashed = b.amount;
        unchecked {
            b.disputesLost += 1;
            if (slashed != 0) {
                b.amount = 0;
                // totalBonded is the sum of every bond, this one among them, so it is at least `slashed`; and
                // totalSlashed + totalBonded is at most MOVVA's supply.
                totalBonded -= slashed;
                totalSlashed += slashed;
            }
        }
        if (slashed != 0) emit Slashed(lp, msg.sender, slashed);
        emit DisputeLost(lp, b.disputesLost);
    }

    /**
     * @inheritdoc ILPRegistry
     * @dev Reverts for anyone but a bound escrow. A replay - here or on PREDECESSOR - returns false, and the escrow
     *      reverts the settlement with ReceiptReplayed.
     */
    function consumeBankTxId(bytes32 bankTxId) external returns (bool fresh) {
        if (!isEscrow(msg.sender)) revert NotEscrow();
        if (usedBankTxId(bankTxId)) return false;
        spentHere[bankTxId] = true;
        emit BankTxIdConsumed(bankTxId, msg.sender);
        return true;
    }

    /// @inheritdoc ILPRegistry
    /// @dev Spent here, or on PREDECESSOR (and so, through it, on every registry before it).
    function usedBankTxId(bytes32 bankTxId) public view returns (bool) {
        if (spentHere[bankTxId]) return true;
        ILPRegistry p = PREDECESSOR;
        return address(p) != address(0) && p.usedBankTxId(bankTxId);
    }
}
