// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/**
 * @title RulingLib
 * @notice EIP-712 arbitrator rulings, verified on-chain (task 2.6, joining the two halves).
 *
 * ## Why the signature is checked on-chain rather than trusted off-chain
 *
 * Before this, a dispute was decided off-chain by a signed ruling and then executed on-chain
 * by the governor passing a free-text string. Nothing connected the two. The governor could
 * rule however they liked and attach any words; a party who later produced the arbitrator's
 * actual signed ruling had no way to show the chain had done something different, because
 * the chain never saw the ruling at all.
 *
 * Now the escrow requires the arbitrator's signature and records `evidenceRoot` in its
 * event. The governor becomes the party who SUBMITS a ruling rather than the party who
 * makes one, and the two most useful questions become answerable from chain data alone:
 * was this decided by a registered arbitrator, and does the evidence they cited match what
 * the parties were shown.
 *
 * It does not make arbitration trustless - a corrupt arbitrator signs a corrupt ruling. It
 * makes it *attributable*, which is the honest goal for a human process.
 *
 * ## Two kinds of arbitrator: a key, or a contract (SRM1-22)
 *
 * A 65-byte signature is an ECDSA key's, and the signer is recovered from it. Anything else is
 * a CONTRACT arbitrator's, encoded `abi.encodePacked(address arbitrator, bytes signature)`:
 * the first 20 bytes name the contract and the rest is handed to its EIP-1271
 * `isValidSignature(digest, signature)`, which must return the magic value. That is how the
 * client-approved 2-of-3 Safe rules: its owners sign the Safe's SafeMessage hash of the digest,
 * and the Safe's CompatibilityFallbackHandler checks the threshold. Without this a Safe could
 * never be registered usefully, because it has no key to recover (SRM1-22).
 *
 * The two encodings cannot be confused: a contract arbitrator's encoding is 20 + n bytes and
 * is refused unless it is longer than 20 bytes and not 65, and a Safe's signatures are 65 per
 * owner, so 20 + 65k is never 65. Naming the signer, rather than recovering it, gives nothing
 * away: the escrow still requires `arbitratorSince[signer]`, so naming an unregistered
 * contract fails as `NotArbitrator`, and naming a registered one succeeds only if that
 * contract says yes. The call is a STATICCALL, so the arbitrator cannot reenter or change
 * state, and the bytes it returns are checked for length before they are read.
 *
 * A contract arbitrator is exactly as strong as its own validation. A Safe's is its owners'
 * threshold; a contract that approves everything approves every ruling. Registering one waits
 * out GOVERNANCE_DELAY in public like any arbitrator, so an LP can read what it is first.
 *
 * ## The encoding is shared with packages/ramp/src/disputes.ts
 *
 * Both sides must produce byte-identical digests or every ruling fails to verify. The
 * struct below mirrors RULING_TYPES there exactly, and a differential test signs with the
 * TypeScript client and verifies with this compiled library rather than trusting that two
 * hand-written encoders agree.
 */
library RulingLib {
    struct Ruling {
        bytes32 orderId;
        string outcome; // "RELEASE" | "REFUND"
        bytes32 evidenceRoot;
        string rationale;
        uint64 ruledAt;
        bool byDefault;
    }

    /// @dev How far ahead of the block a ruling's `ruledAt` may be: the desk's clock, not the chain's.
    uint256 internal constant RULING_CLOCK_SKEW = 15 minutes;

    bytes32 internal constant RULING_TYPEHASH = keccak256(
        "Ruling(bytes32 orderId,address escrow,string outcome,bytes32 evidenceRoot,string rationale,uint64 ruledAt,bool byDefault)"
    );
    bytes32 internal constant DOMAIN_TYPEHASH = keccak256(
        "EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)"
    );

    bytes32 internal constant RELEASE = keccak256(bytes("RELEASE"));
    bytes32 internal constant REFUND = keccak256(bytes("REFUND"));

    error BadOutcome();
    /// @dev v2.0 I-43: a ruling dated before its dispute, or ahead of the chain's clock.
    error RulingOutOfTime(uint64 ruledAt);
    error MalformedSignature();
    /// @notice A contract arbitrator was named, and its EIP-1271 check did not approve the ruling.
    error ContractSignatureRejected(address arbitrator);

    /// @dev `bytes4(keccak256("isValidSignature(bytes32,bytes)"))`, EIP-1271's magic value.
    bytes4 internal constant EIP1271_MAGIC = 0x1626ba7e;

    function domainSeparator(address escrow) internal view returns (bytes32) {
        return keccak256(
            abi.encode(
                DOMAIN_TYPEHASH,
                keccak256("PrivacyPoolsBRL-Dispute"),
                keccak256("1"),
                block.chainid,
                escrow
            )
        );
    }

    function digest(Ruling calldata r, address escrow) internal view returns (bytes32) {
        return _digest(r, escrow, keccak256(bytes(r.outcome)));
    }

    /// @notice true for RELEASE, false for REFUND. Anything else reverts.
    /// @dev Never defaults. An unrecognised outcome silently meaning "refund" would turn a
    ///      typo into a transfer of someone's money.
    function isRelease(Ruling calldata r) internal pure returns (bool) {
        return _isRelease(keccak256(bytes(r.outcome)));
    }

    function recover(Ruling calldata r, address escrow, bytes calldata sig)
        internal
        view
        returns (address)
    {
        return _recover(digest(r, escrow), sig);
    }

    /**
     * @notice Who signed this ruling, and which way it goes: what an escrow needs, in one pass.
     * @dev Calldata throughout, and the outcome hashed once. The escrows receive the ruling as
     *      calldata; taking it as memory, and hashing the outcome separately for the signature
     *      and for the direction, copied the strings at every step in contracts that sit at
     *      the EIP-170 size limit.
     */
    /// @param disputedAt when the dispute was raised: a ruling must be dated from then to now, with
    ///        RULING_CLOCK_SKEW for the desk's clock (v2.0 I-43).
    /// @dev External, so the escrows link one deployed copy instead of each inlining it (both sit
    ///      near the EIP-170 size limit). A library call is a DELEGATECALL: `escrow` is passed, not read.
    function verify(Ruling calldata r, address escrow, bytes calldata sig, uint64 disputedAt)
        external
        view
        returns (address signer, bool release, bytes32 d)
    {
        if (r.ruledAt < disputedAt || r.ruledAt > block.timestamp + RULING_CLOCK_SKEW) revert RulingOutOfTime(r.ruledAt);
        bytes32 outcome = keccak256(bytes(r.outcome));
        release = _isRelease(outcome);
        d = _digest(r, escrow, outcome);
        signer = _recover(d, sig);
    }

    error GateApprovalInvalid();

    /**
     * @notice FiatEscrow's taker gate (H-04): the approval digest for this lock, after checking that
     *         `gate` signed it and that `deadline` has not passed. The escrow records the digest as spent.
     * @dev The EIP-191 hash of keccak256(abi.encode("PrivacyPoolsBRL/taker-gate/v1", chainid, escrow,
     *      offerId, taker, weiAmount, recipient, boleto, deadline)). `escrow` is passed: this runs as a
     *      DELEGATECALL, but the escrow names itself so the digest never depends on how it is called.
     */
    function gateApproval(
        address gate,
        address escrow,
        bytes32 offerId,
        address taker,
        uint256 weiAmount,
        address recipient,
        bool boleto,
        uint64 deadline,
        bytes calldata sig
    ) external view returns (bytes32 d) {
        d = keccak256(
            abi.encodePacked(
                "\x19Ethereum Signed Message:\n32",
                keccak256(
                    abi.encode(
                        "PrivacyPoolsBRL/taker-gate/v1", block.chainid, escrow, offerId, taker, weiAmount,
                        recipient, boleto, deadline
                    )
                )
            )
        );
        if (gate == address(0) || block.timestamp > deadline || _recover(d, sig) != gate) {
            revert GateApprovalInvalid();
        }
    }

    function _digest(Ruling calldata r, address escrow, bytes32 outcomeHash)
        private
        view
        returns (bytes32)
    {
        bytes32 structHash = keccak256(
            abi.encode(
                RULING_TYPEHASH,
                r.orderId,
                escrow,
                outcomeHash,
                r.evidenceRoot,
                keccak256(bytes(r.rationale)),
                r.ruledAt,
                r.byDefault
            )
        );
        return keccak256(abi.encodePacked("\x19\x01", domainSeparator(escrow), structHash));
    }

    function _isRelease(bytes32 outcomeHash) private pure returns (bool) {
        if (outcomeHash == RELEASE) return true;
        if (outcomeHash == REFUND) return false;
        revert BadOutcome();
    }

    function _recover(bytes32 d, bytes calldata sig) private view returns (address signer) {
        if (sig.length != 65) return _contractSigner(d, sig);
        bytes32 ss = bytes32(sig[32:64]);
        if (uint256(ss) > 0x7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5D576E7357A4501DDFE92F46681B20A0) {
            revert MalformedSignature();
        }
        signer = ecrecover(d, uint8(sig[64]), bytes32(sig[0:32]), ss);
        if (signer == address(0)) revert MalformedSignature();
    }

    /// @dev `sig` = 20-byte contract address ‖ its signature. Returns the contract only if its
    ///      EIP-1271 check returns the magic value for `d`. A name with no code is refused: an
    ///      EOA "approving" by not reverting would otherwise read as a ruling.
    function _contractSigner(bytes32 d, bytes calldata sig) private view returns (address signer) {
        if (sig.length <= 20) revert MalformedSignature();
        signer = address(bytes20(sig[0:20]));
        if (signer.code.length == 0) revert MalformedSignature();
        // slither-disable-next-line low-level-calls
        (bool ok, bytes memory ret) =
            signer.staticcall(abi.encodeWithSelector(EIP1271_MAGIC, d, sig[20:]));
        if (!ok || ret.length < 32 || bytes4(ret) != EIP1271_MAGIC) {
            revert ContractSignatureRejected(signer);
        }
    }
}
