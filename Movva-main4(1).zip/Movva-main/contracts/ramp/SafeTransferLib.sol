// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/**
 * @title SafeTransferLib
 * @notice ERC-20 transfers that survive the tokens people actually deploy.
 *
 * Two behaviours the naive `IERC20(token).transfer(...)` gets wrong, both of which appear in
 * tokens a BRL ramp would plausibly hold:
 *
 *  - **No return value.** USDT and others predate the finalised ERC-20 and return nothing.
 *    A typed call decodes the empty returndata as a failure and reverts a transfer that
 *    actually succeeded.
 *  - **Returning false instead of reverting.** Some tokens signal failure by returning
 *    false. Ignoring the return value turns a failed transfer into a silent credit, which
 *    on the escrow's release path means paying out money that never arrived.
 *
 * So: succeed on empty returndata, succeed on `true`, revert on anything else.
 *
 * Deliberately NOT handled: fee-on-transfer and rebasing tokens. The escrow records the
 * amount it was told to hold, and a token that delivers less than it was sent breaks that
 * accounting in a way no transfer wrapper can repair. Those tokens must not be listed; the
 * escrow enforces this by measuring the balance actually received (see `receiveToken`).
 */
library SafeTransferLib {
    error TransferFailed(address token, address to, uint256 amount);
    error TransferFromFailed(address token, address from, uint256 amount);
    error ApproveFailed(address token, address spender);
    error UnexpectedAmountReceived(uint256 expected, uint256 got);

    function safeTransfer(address token, address to, uint256 amount) external {
        (bool ok, bytes memory ret) =
            token.call(abi.encodeWithSelector(0xa9059cbb, to, amount)); // transfer
        if (!ok || !_accepted(token, ret)) revert TransferFailed(token, to, amount);
    }

    function safeTransferFrom(address token, address from, address to, uint256 amount) internal {
        (bool ok, bytes memory ret) =
            token.call(abi.encodeWithSelector(0x23b872dd, from, to, amount)); // transferFrom
        if (!ok || !_accepted(token, ret)) revert TransferFromFailed(token, from, amount);
    }

    /// @dev Sets the allowance to zero first: some tokens (USDT again) refuse a non-zero
    ///      to non-zero change, so a second approval to the same spender would revert.
    function safeApprove(address token, address spender, uint256 amount) external {
        (bool ok0, bytes memory r0) =
            token.call(abi.encodeWithSelector(0x095ea7b3, spender, 0));
        if (!ok0 || !_accepted(token, r0)) revert ApproveFailed(token, spender);
        if (amount == 0) return;
        (bool ok, bytes memory ret) =
            token.call(abi.encodeWithSelector(0x095ea7b3, spender, amount));
        if (!ok || !_accepted(token, ret)) revert ApproveFailed(token, spender);
    }

    function balanceOf(address token, address who) internal view returns (uint256) {
        (bool ok, bytes memory ret) =
            token.staticcall(abi.encodeWithSelector(0x70a08231, who)); // balanceOf
        if (!ok || ret.length < 32) return 0;
        return abi.decode(ret, (uint256));
    }

    /**
     * @notice Pull `amount` in, and require that exactly `amount` arrived.
     * @dev This is where fee-on-transfer and rebasing tokens are rejected rather than
     *      silently mis-accounted. The escrow promises a taker a specific amount; a token
     *      that quietly delivers 98% of what was sent turns that promise into a shortfall
     *      discovered at payout time, by someone who has already sent their BRL.
     */
    function receiveToken(address token, address from, uint256 amount) external {
        uint256 before = balanceOf(token, address(this));
        safeTransferFrom(token, from, address(this), amount);
        uint256 got = balanceOf(token, address(this)) - before;
        if (got != amount) revert UnexpectedAmountReceived(amount, got);
    }

    /// @dev Empty returndata is success only from a contract (I-42): a call to an address with no code also returns
    ///      nothing, and would otherwise read as a transfer that happened.
    function _accepted(address token, bytes memory ret) private view returns (bool) {
        if (ret.length == 0) return token.code.length != 0; // non-standard token, no return value
        return abi.decode(ret, (bool));
    }
}
