// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {IERC20Metadata} from "@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";
import {ICoreDepositWallet} from "./HyperCore.sol";
import {IDeltaNeutral} from "./IDeltaNeutral.sol";
import {DeltaNeutralStrategy as Strategy} from "./DeltaNeutralStrategy.sol";

/**
 * @title HyperCoreDeltaNeutralVault
 * @notice An Ethena-style delta-neutral position on Hyperliquid (task 3.3) whose funds are held by
 *         this contract on HyperEVM, not by a trading key.
 *
 * ## Custody
 *
 * The previous design stopped at a backtest because "running it needs collateral on Hyperliquid
 * and keys to trade it". Here the collateral's owner on HyperCore is this contract's address, and
 * the only thing that can move it is this contract calling CoreWriter. There is no API wallet and
 * no trading key: a keeper may call `rebalance()` and `harvest()`, and every order either call
 * places is computed and bounded inside the contract from HyperCore's own precompile reads.
 *
 * The position: long the spot asset, short the same size of its perp. Price moves cancel; what is
 * left is funding (received while it is positive) less fees.
 *
 * ## Two pieces of bytecode, one contract
 *
 * The HyperCore logic - reading the book, choosing the next step, placing orders, estimating
 * funding - lives in the linked library `DeltaNeutralStrategy`, reached by DELEGATECALL. This
 * contract keeps the share token, deposits, redemptions and claims, every role check, the
 * reentrancy guard, the settle and rate-limit gates, the drawdown breaker and governance, and
 * delegates only after all of those have passed. The library runs as this contract (one HyperCore
 * account, one balance sheet), receives only the strategy's own storage struct, and its address is
 * fixed in this bytecode at deployment. The split exists because the single contract was 29 KB,
 * over EIP-170; why it is a library rather than a second contract is in `DeltaNeutralStrategy`.
 *
 * ## What bounds a keeper
 *
 *  - orders are IOC limit orders priced within `slippageBps` of the HyperCore oracle (perp) or the
 *    spot price, and spot is only traded while it is within `maxSpotDeviationBps` of the oracle;
 *  - at most two orders per call (one per leg), each at most `maxOrderNotional`;
 *  - keeper-placed notional is capped at `maxDailyTurnover` per 24h window;
 *  - one call per `minActionInterval`, and never before the previous call's actions have had
 *    `settleSeconds` to land on HyperCore;
 *  - leverage never raised past `maxLeverageBps`, delta brought back within `deltaToleranceBps`;
 *  - no new exposure while the funding estimate is below `fundingPauseE8`, active unwinding below
 *    `fundingUnwindE8`, and no new exposure after a `maxDrawdownBps` fall in the share price.
 *
 * Worst case for a compromised keeper: per call, two orders of `maxOrderNotional` filled at the
 * edge of the band, each losing `slippageBps` plus the taker fee; per 24h, `maxDailyTurnover` times
 * the same. docs/delta-neutral.md works the numbers at the default parameters.
 *
 * ## Share pricing cannot be bought cheap
 *
 * The spot leg is valued at the lower of its spot price and the perp oracle. A spot price pushed
 * down on a thin book would otherwise price shares low for the deposit that follows (M-01). So every
 * share-priced operation - `deposit`, `requestRedeem`, `checkpoint` - reverts `SpotOffOracle` while
 * spot is outside `maxSpotDeviationBps` (at least 50 bps) of the oracle, and shares minted by a
 * deposit stay locked to their holder for `MIN_HOLD`: they cannot be redeemed, nor transferred to a
 * fresh address that would redeem them (`_update`). What a deposit can gain from a skew inside the
 * band is then held for a day and pays `exitFeeBps` on the way out.
 *
 * ## Exits do not need the keeper
 *
 * `requestRedeem` prices shares at the current NAV and pays at once from idle USDC on HyperEVM, or
 * records a claim. `processExits` - callable by anyone - walks the liquidity ladder one step per
 * call: bridge HyperCore spot USDC to HyperEVM; else move free perp margin to spot; else close both
 * legs by the shortfall. `claim` pays once the USDC has arrived. A keeper cannot spend USDC owed
 * to claims (no new exposure while any claim is unfunded), and `deleverage` - also open to anyone -
 * protects the margin if the keeper disappears in a rally.
 *
 * ## Asynchrony
 *
 * A CoreWriter action takes effect after the EVM block, if at all, and orders a few seconds later
 * still. So every NAV-priced operation (deposit, requestRedeem, checkpoint) and every call that acts
 * waits `settleSeconds` after the last action, and nothing assumes an action succeeded: each call
 * re-reads HyperCore and decides again.
 *
 * ## Not the shielded vault
 *
 * This is a separate HyperEVM product, deliberately not an adapter of the L1 `YieldVault`:
 * connecting them means moving funds across a bridge, which is the client's decision
 * (docs/delta-neutral.md).
 */
contract HyperCoreDeltaNeutralVault is IDeltaNeutral, ERC20, ReentrancyGuard, DelayedGovernance {
    using SafeERC20 for IERC20;

    struct Claim {
        address receiver;
        uint96 assets;
    }

    /// @dev Shares minted to an account within the last `MIN_HOLD`, and when the lock ends.
    struct Lock {
        uint192 shares;
        uint64 until;
    }

    uint256 internal constant BPS = 10_000;
    uint256 internal constant SHARE_OFFSET = 1e6;
    /// @notice How long shares minted by a deposit stay with their holder before they can be redeemed
    ///         or transferred (M-01).
    uint256 public constant MIN_HOLD = 1 days;
    /// @dev HYPE's HyperCore system address; native HYPE sent here credits the sender on HyperCore.
    address internal constant HYPE_SYSTEM = 0x2222222222222222222222222222222222222222;

    IERC20 public immutable USDC;
    ICoreDepositWallet public immutable DEPOSIT_WALLET;
    uint32 public immutable PERP;
    uint32 public immutable SPOT_MARKET;
    uint64 public immutable SPOT_TOKEN;
    uint8 public immutable PERP_SZ_DECIMALS;
    uint8 public immutable SPOT_SZ_DECIMALS;
    uint8 public immutable SPOT_WEI_DECIMALS;
    uint8 public immutable VENUE_MAX_LEVERAGE;

    address public keeper;
    address public guardian;
    bool public depositsPaused;
    uint64 public lastKeeperActionAt;
    uint256 public highWaterAssetsPerShare;
    uint256 public nextClaimId;
    /// @notice The earliest claim not yet paid: claims are paid in the order they were requested (N-37).
    uint256 public claimHead = 1;
    mapping(uint256 => Claim) public claims;
    mapping(address => Lock) internal _locks;

    /// @dev The only storage the strategy library is handed. Read through the getters below.
    State internal _state;

    modifier onlyKeeper() {
        if (msg.sender != keeper) revert NotKeeper();
        _;
    }

    constructor(
        string memory name_,
        string memory symbol_,
        IERC20 usdc,
        ICoreDepositWallet depositWallet,
        uint32 perp,
        uint32 spotMarket,
        address governor_,
        address guardian_,
        address keeper_,
        uint256 governanceDelay,
        Params memory p
    ) ERC20(name_, symbol_) DelayedGovernance(governor_, governanceDelay) {
        if (
            address(usdc) == address(0) || address(depositWallet) == address(0) || guardian_ == address(0)
                || keeper_ == address(0)
        ) revert ZeroAddress();
        if (IERC20Metadata(address(usdc)).decimals() != 6) revert BadMarket();
        USDC = usdc;
        DEPOSIT_WALLET = depositWallet;
        PERP = perp;
        SPOT_MARKET = spotMarket;
        // Market facts come from HyperCore itself, so a wrong index fails here instead of trading
        // the wrong asset.
        Market memory m = Strategy.readMarket(perp, spotMarket);
        SPOT_TOKEN = m.spotToken;
        PERP_SZ_DECIMALS = m.perpSzDecimals;
        SPOT_SZ_DECIMALS = m.spotSzDecimals;
        SPOT_WEI_DECIMALS = m.spotWeiDecimals;
        VENUE_MAX_LEVERAGE = m.maxLeverage;

        keeper = keeper_;
        guardian = guardian_;
        Strategy.validate(p, m.maxLeverage);
        _state.params = p;
        // Start the estimate at the formula's resting value. Starting at zero would read as funding
        // having collapsed.
        _state.fundingEmaE18 = Strategy.initialFundingEmaE18();
        _state.lastFundingSampleAt = uint64(block.timestamp);
    }

    /// @dev Shares carry six extra decimals, which makes a first-depositor donation uneconomic.
    function decimals() public pure override returns (uint8) {
        return 12;
    }

    function _market() internal view returns (Market memory) {
        return Market({
            usdc: USDC,
            depositWallet: DEPOSIT_WALLET,
            perp: PERP,
            spotMarket: SPOT_MARKET,
            spotToken: SPOT_TOKEN,
            perpSzDecimals: PERP_SZ_DECIMALS,
            spotSzDecimals: SPOT_SZ_DECIMALS,
            spotWeiDecimals: SPOT_WEI_DECIMALS,
            maxLeverage: VENUE_MAX_LEVERAGE
        });
    }

    /*//////////////////////////////////////////////////////////////
                                 VIEWS
    //////////////////////////////////////////////////////////////*/

    function getParams() external view returns (Params memory) {
        return _state.params;
    }

    /// @notice The funding estimate: hourly rate, 1e8 = 100%.
    function fundingEmaE8() external view returns (int256) {
        return _state.fundingEmaE18 / 1e10;
    }

    function lastFundingSampleAt() external view returns (uint64) {
        return _state.lastFundingSampleAt;
    }

    function lastCoreActionAt() external view returns (uint64) {
        return _state.lastCoreActionAt;
    }

    function turnoverWindowStart() external view returns (uint64) {
        return _state.turnoverWindowStart;
    }

    function turnoverUsed() external view returns (uint256) {
        return _state.turnoverUsed;
    }

    function totalOwed() external view returns (uint256) {
        return _state.totalOwed;
    }

    function exposurePaused() external view returns (bool) {
        return _state.exposurePaused;
    }

    function drawdownTripped() external view returns (bool) {
        return _state.drawdownTripped;
    }

    /**
     * @notice Everything the vault holds, in USDC (1e6): HyperEVM USDC, HyperCore spot USDC, the spot
     *         asset at the lower of its spot price and the perp oracle, and the perp account value.
     * @dev Reverts when HyperCore cannot be read: there is no honest NAV then, and everything priced
     *      from it must stop. Claims already recorded keep paying. Within `settleSeconds` of an action
     *      the figure can omit value in flight; nothing priced runs in that window.
     */
    function totalAssets() public view returns (uint256) {
        return Strategy.totalAssets(_market());
    }

    /// @notice Assets less what is owed to recorded claims: what shares are priced against.
    function equity() public view returns (uint256) {
        uint256 t = totalAssets();
        return t > _state.totalOwed ? t - _state.totalOwed : 0;
    }

    function assetsPerShare() public view returns (uint256) {
        return _sharePrice(equity());
    }

    function _sharePrice(uint256 eq) internal view returns (uint256) {
        return ((eq + 1) * 10 ** decimals()) / (totalSupply() + SHARE_OFFSET);
    }

    /// @notice Shares of `account` that cannot be redeemed or transferred yet (minted < `MIN_HOLD` ago).
    function lockedShares(address account) public view returns (uint256) {
        Lock memory l = _locks[account];
        return block.timestamp < l.until ? l.shares : 0;
    }

    function lockedUntil(address account) external view returns (uint256) {
        return _locks[account].until;
    }

    /// @dev `equity()` for pricing shares: reverts `SpotOffOracle` while spot is outside the band.
    function _pricedEquity() internal view returns (uint256) {
        (uint256 t, bool sane) = Strategy.pricedAssets(_market(), _state.params.maxSpotDeviationBps);
        if (!sane) revert SpotOffOracle();
        return t > _state.totalOwed ? t - _state.totalOwed : 0;
    }

    /**
     * @dev Locked shares cannot leave their holder, by `requestRedeem` (a burn) or by transfer. Without
     *      the transfer rule a deposit to one address and a transfer to a fresh one would skip the hold.
     *      Mints are unrestricted; a deposit made FOR someone else locks only what it minted to them
     *      (and restarts the clock on their shares still locked, never on their unlocked ones).
     */
    function _update(address from, address to, uint256 value) internal override {
        if (from != address(0)) {
            uint256 locked = lockedShares(from);
            if (locked > 0 && balanceOf(from) < locked + value) revert SharesLocked(_locks[from].until);
        }
        super._update(from, to, value);
    }

    function _requireSettled() internal view {
        uint256 ready = uint256(_state.lastCoreActionAt) + _state.params.settleSeconds;
        if (block.timestamp < ready) revert NotSettled(ready);
    }

    /*//////////////////////////////////////////////////////////////
                             DEPOSITS AND EXITS
    //////////////////////////////////////////////////////////////*/

    function deposit(uint256 assets, address receiver) external nonReentrant returns (uint256 shares) {
        _requireSetupComplete();
        _requireSettled();
        if (depositsPaused || _state.drawdownTripped) revert DepositsClosed();
        if (assets == 0) revert ZeroAmount();
        uint256 eq = _pricedEquity();
        if (eq + assets > _state.params.depositCap) revert OverDepositCap();
        shares = (assets * (totalSupply() + SHARE_OFFSET)) / (eq + 1);
        // slither-disable-next-line incorrect-equality
        if (shares == 0) revert ZeroAmount();
        // N-11: a deposit made for someone else may not restart the clock on their shares still locked,
        // or a dust deposit a day could hold them for ever. Refused while they are; afterwards it locks
        // only what it minted.
        uint256 locked = lockedShares(receiver);
        if (receiver != msg.sender && locked > 0) revert SharesLocked(_locks[receiver].until);
        _locks[receiver] = Lock({shares: uint192(locked + shares), until: uint64(block.timestamp + MIN_HOLD)});
        USDC.safeTransferFrom(msg.sender, address(this), assets);
        _mint(receiver, shares);
        emit Deposited(msg.sender, receiver, assets, shares);
    }

    /**
     * @notice Redeem shares at the current NAV, less `exitFeeBps`. Paid at once from HyperEVM USDC no
     *         earlier claim is owed; otherwise recorded as a claim that `claim` pays once `processExits`
     *         has brought the USDC over. Reverts `SpotOffOracle` while spot is outside the band, and
     *         `SharesLocked` for shares minted less than `MIN_HOLD` ago.
     * @return id Zero when paid at once.
     */
    function requestRedeem(uint256 shares, address receiver) external nonReentrant returns (uint256 id, uint256 assets) {
        _requireSettled();
        if (shares == 0) revert ZeroAmount();
        if (receiver == address(0)) revert ZeroAddress();
        // Spot is valued at min(spot, oracle) whatever the band (DeltaNeutralStrategy._readPositions), so a
        // redeemer cannot profit from moving it: redemptions stay open while spot is off the band (v3.1, the
        // M-01 fix's regression), and only deposits, which a low spot would favour, wait.
        (uint256 t,) = Strategy.pricedAssets(_market(), _state.params.maxSpotDeviationBps);
        uint256 eq = t > _state.totalOwed ? t - _state.totalOwed : 0;
        // One division, rounding down: the NAV share less the exit fee.
        assets = (shares * (eq + 1) * (BPS - _state.params.exitFeeBps)) / ((totalSupply() + SHARE_OFFSET) * BPS);
        _burn(msg.sender, shares);

        if (USDC.balanceOf(address(this)) >= _state.totalOwed + assets) {
            USDC.safeTransfer(receiver, assets);
            emit Redeemed(msg.sender, receiver, shares, assets);
            return (0, assets);
        }
        id = ++nextClaimId;
        claims[id] = Claim({receiver: receiver, assets: uint96(assets)});
        _state.totalOwed += assets;
        emit ClaimQueued(id, receiver, shares, assets);
    }

    /// @notice Pay a recorded claim once its USDC is on HyperEVM. Anyone may call; it pays the receiver.
    function claim(uint256 id) external nonReentrant {
        Claim memory c = claims[id];
        if (c.assets == 0) revert UnknownClaim();
        // N-37: in the order requested, so small later claims cannot starve a large earlier one.
        if (id != claimHead) revert NotYourTurn(claimHead);
        ++claimHead;
        uint256 evm = USDC.balanceOf(address(this));
        if (evm < c.assets) revert NotYetLiquid(c.assets, evm);
        delete claims[id];
        _state.totalOwed -= c.assets;
        USDC.safeTransfer(c.receiver, c.assets);
        emit ClaimPaid(id, c.receiver, c.assets);
    }

    /**
     * @notice Bring USDC to HyperEVM for recorded claims, one step per call. Anyone may call.
     * @dev The ladder: bridge spot USDC; else release perp margin down to `maxLeverageBps`; else close
     *      both legs by the shortfall. A step's result is visible only in a later block, which is why
     *      the next call waits `settleSeconds`.
     */
    function processExits() external nonReentrant {
        _requireSettled();
        Strategy.processExits(_state, _market());
    }

    /**
     * @notice Fund HyperCore gas. Bridging USDC back to HyperEVM is paid in HYPE from this contract's
     *         HyperCore spot balance; anyone may top it up. Native HYPE sent to its system address is
     *         credited to the sender on HyperCore.
     */
    function fundCoreGas() external payable {
        if (msg.value == 0) revert ZeroAmount();
        // slither-disable-next-line arbitrary-send-eth,low-level-calls
        (bool ok,) = HYPE_SYSTEM.call{value: msg.value}("");
        if (!ok) revert ZeroAmount();
    }

    /*//////////////////////////////////////////////////////////////
                                  KEEPER
    //////////////////////////////////////////////////////////////*/

    /// @notice Take the single most urgent step towards the target position. Reverts `NothingToDo`
    ///         when there is none, so a keeper's simulation says so without spending gas.
    function rebalance() external onlyKeeper nonReentrant {
        _requireSetupComplete();
        _keeperGate();
        Strategy.rebalance(_state, _market());
    }

    /// @notice Refresh the funding estimate and the drawdown breaker, and return perp margin above
    ///         target leverage to spot, where it can pay exits or be redeployed. Moves nothing out.
    function harvest() external onlyKeeper nonReentrant {
        _keeperGate();
        // The breaker first, as before the split: it writes state, and nothing is written after the
        // delegatecall. (Reads reflect HyperCore as of the start of the block either way.) Skipped,
        // not reverted, while spot is off the band, so a skewed book cannot stop the keeper.
        _checkpoint(false);
        Strategy.harvest(_state, _market());
    }

    function _keeperGate() internal {
        _requireSettled();
        uint256 ready = uint256(lastKeeperActionAt) + _state.params.minActionInterval;
        if (block.timestamp < ready) revert TooSoon(ready);
        lastKeeperActionAt = uint64(block.timestamp);
    }

    /// @notice Protect the margin when leverage is past `maxLeverageBps`. Anyone may call, so a rally
    ///         with the keeper offline does not end in a liquidation nobody tried to prevent.
    function deleverage() external nonReentrant {
        _requireSettled();
        Strategy.deleverage(_state, _market());
    }

    /// @notice Record a funding sample. Anyone may: a sample's weight is the time since the last one.
    function sampleFunding() external nonReentrant {
        Strategy.sampleFunding(_state, _market());
    }

    /// @notice Update the high-water mark and trip the drawdown breaker. Anyone may. Reverts
    ///         `SpotOffOracle` while spot is outside the band: a skewed spot price must neither raise
    ///         the high-water mark nor trip the breaker.
    function checkpoint() external {
        _requireSettled();
        _checkpoint(true);
    }

    function _checkpoint(bool strict) internal {
        // slither-disable-next-line incorrect-equality
        if (totalSupply() == 0) return;
        (uint256 t, bool sane) = Strategy.pricedAssets(_market(), _state.params.maxSpotDeviationBps);
        if (!sane) {
            if (strict) revert SpotOffOracle();
            return;
        }
        uint256 eq = t > _state.totalOwed ? t - _state.totalOwed : 0;
        uint256 price = _sharePrice(eq);
        if (price > highWaterAssetsPerShare) {
            highWaterAssetsPerShare = price;
        } else if (
            !_state.drawdownTripped && price * BPS < highWaterAssetsPerShare * (BPS - _state.params.maxDrawdownBps)
        ) {
            _state.drawdownTripped = true;
            emit CircuitBreaker("drawdown", true);
        }
    }

    /*//////////////////////////////////////////////////////////////
                               GOVERNANCE
    //////////////////////////////////////////////////////////////*/

    /// @notice Stop deposits and unwind exposure. Guardian or governor, instant.
    function pauseExposure() external {
        if (msg.sender != guardian && msg.sender != governor) revert NotGuardianOrGovernor();
        _state.exposurePaused = true;
        depositsPaused = true;
        emit CircuitBreaker("paused", true);
    }

    /// @notice Resume after a pause or the drawdown breaker, accepting the current share price.
    function resume() external onlyGovernor {
        _state.exposurePaused = false;
        depositsPaused = false;
        _state.drawdownTripped = false;
        // slither-disable-next-line incorrect-equality
        highWaterAssetsPerShare = totalSupply() == 0 ? 0 : _sharePrice(_pricedEquity());
        emit CircuitBreaker("paused", false);
    }

    /// @notice Delayed when any parameter adds risk or any exit-path parameter changes (`riskier`);
    ///         instant when every change removes risk and none touches the exit path.
    function setParams(Params calldata p) external {
        _authorizeChange(Strategy.riskier(p, _state.params));
        Strategy.validate(p, VENUE_MAX_LEVERAGE);
        _state.params = p;
        emit ParamsSet(p);
    }

    /// @notice Delayed: the keeper decides when bounded trades happen.
    function setKeeper(address k) external {
        _authorizeChange(k != keeper);
        if (k == address(0)) revert ZeroAddress();
        keeper = k;
        emit RoleSet("keeper", k);
    }

    /// @notice Instant: the guardian can only pause.
    function setGuardian(address g) external {
        _authorizeChange(false);
        if (g == address(0)) revert ZeroAddress();
        guardian = g;
        emit RoleSet("guardian", g);
    }

    function _isDelayable(bytes4 selector) internal pure override returns (bool) {
        return selector == HyperCoreDeltaNeutralVault.setParams.selector
            || selector == HyperCoreDeltaNeutralVault.setKeeper.selector;
    }
}
