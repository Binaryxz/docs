// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;
import {ProverOf} from "./utils/ProverOf.sol";

import {Governed} from "./utils/Governed.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";
import {FiatEscrow} from "../ramp/FiatEscrow.sol";
import {LPRegistry} from "../ramp/LPRegistry.sol";
import {IAttestorVerifier} from "../ramp/IAttestorVerifier.sol";
import {IPriceOracle} from "../ramp/IPriceOracle.sol";
import {RulingLib} from "../ramp/RulingLib.sol";
import {Multisig1271, YesMan1271, Bad1271, ContractArbitratorSigning} from "./utils/Multisig1271.sol";

/// @dev Attestor stub. Encodes exactly what a real verifier would return, so the escrow's
///      own checks - payee, amount, replay, timing, binding - are what is under test.
contract MockVerifier is IAttestorVerifier {
    struct Canned {
        bytes32 bankTxId;
        bytes32 payeeKeyHash;
        uint256 amountBrlCents;
        uint64 paidAt;
        Rail rail;
        bool bound;
    }

    mapping(bytes32 => Canned) public canned;
    /// @dev Zero: the position's LP ran the session, as it does. Otherwise someone else did (I-22).
    address public forcedProver;

    function forceProver(address p) external {
        forcedProver = p;
    }

    function setProof(bytes32 orderId, Canned memory c) external {
        canned[orderId] = c;
    }

    function verifyPayment(bytes32 orderId, bytes calldata)
        external
        view
        returns (Payment memory)
    {
        Canned memory c = canned[orderId];
        require(c.bound, "proof not bound to this order");
        address who = forcedProver != address(0) ? forcedProver : ProverOf.lpOf(msg.sender, orderId);
        return Payment({
            bankTxId: c.bankTxId,
            payeeKeyHash: c.payeeKeyHash,
            payerRef: bytes32(uint256(1)),
            amountBrlCents: c.amountBrlCents,
            paidAt: c.paidAt,
            rail: c.rail,
            prover: who
        });
    }

    function attestorKind() external pure returns (string memory) {
        return "mock/test";
    }

    function provesBankSession() external pure returns (bool) {
        return true;
    }
}

contract MockOracle is IPriceOracle {
    uint256 public price = 3_000_000; // R$30,000.00 per ETH, in centavos
    bool public stale;
    uint64 public updatedAt;

    function set(uint256 p) external {
        price = p;
    }

    function setStale(bool s) external {
        stale = s;
    }

    /// @dev A badly-behaved oracle: serves an OLD price without reverting. The interface
    ///      says it must revert; this is what happens when an implementation does not.
    function setUpdatedAt(uint64 t) external {
        updatedAt = t;
    }

    function brlCentsPerUnit() external view returns (uint256, uint64) {
        require(!stale, "stale");
        return (price, updatedAt == 0 ? uint64(block.timestamp) : updatedAt);
    }
}

/// Plays both the Entrypoint and its pool: the escrow reads the deposit's label from the pool
/// it finds through `assetConfig`, so the stand-in needs a SCOPE and a nonce that deposits bump.
contract MockEntrypoint {
    uint256 public constant SCOPE = 7;
    uint256 public nonce;
    uint256 public lastPrecommitment;
    uint256 public received;
    /// The pool's vetting fee, which the Entrypoint's owner may change at any time (H-02).
    uint256 public feeBps;

    function setFee(uint256 f) external {
        feeBps = f;
    }

    function deposit(uint256 precommitment) external payable returns (uint256) {
        lastPrecommitment = precommitment;
        received += msg.value;
        return ++nonce;
    }

    function assetConfig(address) external view returns (address, uint256, uint256, uint256) {
        return (address(this), 0, feeBps, 0);
    }
}

contract FiatEscrowTest is Governed, ContractArbitratorSigning {
    FiatEscrow escrow;
    LPRegistry registry;
    MockVerifier verifier;
    MockOracle oracle;
    MockEntrypoint entrypoint;

    address governor = address(0x60F);
    address lp = address(0xA11CE);
    address taker = address(0xB0B);
    address payout = address(0xDEAD);
    address retail = makeAddr("retail");

    bytes32 constant PIX = keccak256("lp@pix.example");
    uint16 constant PIX_MASK = uint16(1 << uint8(IAttestorVerifier.Rail.PIX));
    uint256 constant PRICE = 3_000_000; // centavos per ETH

    uint256 arbKey = 0xA2B;

    /// Build and sign a ruling the way the off-chain arbitrator client does.
    function _ruling(bytes32 orderId, string memory outcome)
        internal
        view
        returns (RulingLib.Ruling memory r, bytes memory sig)
    {
        r = RulingLib.Ruling({
            orderId: orderId,
            outcome: outcome,
            evidenceRoot: keccak256("evidence"),
            rationale: "checked the bank statement",
            ruledAt: uint64(block.timestamp),
            byDefault: false
        });
        bytes32 d = _digest(r);
        (uint8 v, bytes32 rr, bytes32 ss) = vm.sign(arbKey, d);
        sig = abi.encodePacked(rr, ss, v);
    }

    /// Post a signed ruling, wait out RULING_DELAY in public, and execute it - by anyone.
    function _rule(bytes32 orderId, RulingLib.Ruling memory r, bytes memory sig) internal {
        _ruleAt(escrow, orderId, r, sig);
    }

    function _ruleAt(FiatEscrow at, bytes32 orderId, RulingLib.Ruling memory r, bytes memory sig) internal {
        at.resolveDispute(orderId, r, sig);
        vm.warp(block.timestamp + 1 days);
        at.resolveDispute(orderId, r, sig);
    }

    function _digest(RulingLib.Ruling memory r) internal view returns (bytes32) {
        return _digestAt(r, address(escrow));
    }

    /// The digest an arbitrator signs for `at` - the escrow is in both the struct and the domain.
    function _digestAt(RulingLib.Ruling memory r, address at) internal view returns (bytes32) {
        bytes32 structHash = keccak256(
            abi.encode(
                keccak256(
                    "Ruling(bytes32 orderId,address escrow,string outcome,bytes32 evidenceRoot,string rationale,uint64 ruledAt,bool byDefault)"
                ),
                r.orderId,
                at,
                keccak256(bytes(r.outcome)),
                r.evidenceRoot,
                keccak256(bytes(r.rationale)),
                r.ruledAt,
                r.byDefault
            )
        );
        bytes32 domain = keccak256(
            abi.encode(
                keccak256(
                    "EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)"
                ),
                keccak256("PrivacyPoolsBRL-Dispute"),
                keccak256("1"),
                block.chainid,
                at
            )
        );
        return keccak256(abi.encodePacked("\x19\x01", domain, structHash));
    }

    function setUp() public {
        oracle = new MockOracle();
        verifier = new MockVerifier();
        entrypoint = new MockEntrypoint();
        registry = new LPRegistry(governor, DELAY);
        escrow = new FiatEscrow(address(oracle), address(registry), address(entrypoint), address(entrypoint), 500, governor, DELAY, DISPUTE_TIMEOUT, TAKER_DISPUTE_TIMEOUT, MAX_VETTING_FEE_BPS);

        vm.startPrank(governor);
        registry.setEscrow(address(escrow), true);
        escrow.setVerifier(address(verifier), true);
        escrow.setArbitrator(vm.addr(arbKey), true);
        registry.setTier(lp, LPRegistry.Tier.INSTITUTIONAL, 1_000_000_00);
        // Open retail (Phase C) during setup, so the retail-cap tests have a retail LP.
        registry.setPhase(LPRegistry.Phase.C);
        registry.completeSetup();
        escrow.completeSetup();
        vm.stopPrank();
        vm.prank(retail);
        registry.register();
        vm.deal(retail, 10 ether);

        vm.deal(lp, 100 ether);
        vm.deal(taker, 1 ether);
    }

    function _postOffer(uint256 amount) internal returns (bytes32) {
        vm.prank(lp);
        return escrow.postOffer{value: amount}(
            address(0), amount, PRICE, PIX, 0.01 ether, 5 ether, address(verifier), PIX_MASK
        );
    }

    function _lock(bytes32 offerId, uint256 amount) internal returns (bytes32) {
        vm.prank(taker);
        return escrow.lockOrder(offerId, amount, FiatEscrow.Delivery.DIRECT, payout, 0);
    }

    function _goodProof(bytes32 orderId, uint256 cents) internal {
        verifier.setProof(
            orderId,
            MockVerifier.Canned({
                bankTxId: keccak256(abi.encode(orderId, "e2e")),
                payeeKeyHash: PIX,
                amountBrlCents: cents,
                paidAt: uint64(block.timestamp),
                rail: IAttestorVerifier.Rail.PIX,
                bound: true
            })
        );
    }

    /*//////////////////////////////////////////////////////////////
                              HAPPY PATH
    //////////////////////////////////////////////////////////////*/

    function test_OnRamp_DirectDelivery() public {
        bytes32 offerId = _postOffer(10 ether);
        bytes32 orderId = _lock(offerId, 1 ether);

        (,,, uint256 brlCents,,,,,,,) = _order(orderId);
        assertEq(brlCents, PRICE, "1 ETH at R$30,000 = 3,000,000 centavos");

        _goodProof(orderId, brlCents);
        escrow.releaseWithProof(orderId, "");

        assertEq(payout.balance, 1 ether, "taker paid BRL, received ETH");
    }

    function test_OnRamp_ShieldedDelivery_DepositsIntoPool() public {
        bytes32 offerId = _postOffer(10 ether);
        vm.prank(taker);
        bytes32 orderId =
            escrow.lockOrder(offerId, 1 ether, FiatEscrow.Delivery.SHIELDED, payout, 4242);

        _goodProof(orderId, PRICE);
        escrow.releaseWithProof(orderId, "");

        assertEq(entrypoint.received(), 1 ether, "ETH went to the pool, not to an address");
        assertEq(entrypoint.lastPrecommitment(), 4242, "taker's precommitment was used");
    }

    /*//////////////////////////////////////////////////////////////
                        ATTACKS ON THE RECEIPT
    //////////////////////////////////////////////////////////////*/

    /// A genuine receipt must settle exactly one order, ever.
    function test_ReceiptCannotBeReplayedOnASecondOrder() public {
        bytes32 offerId = _postOffer(10 ether);
        bytes32 first = _lock(offerId, 1 ether);
        bytes32 second = _lock(offerId, 1 ether);

        bytes32 sharedTx = keccak256("one real payment");
        MockVerifier.Canned memory c = MockVerifier.Canned({
            bankTxId: sharedTx,
            payeeKeyHash: PIX,
            amountBrlCents: PRICE,
            paidAt: uint64(block.timestamp),
            rail: IAttestorVerifier.Rail.PIX,
            bound: true
        });
        verifier.setProof(first, c);
        verifier.setProof(second, c);

        escrow.releaseWithProof(first, "");
        vm.expectRevert(FiatEscrow.ReceiptReplayed.selector);
        escrow.releaseWithProof(second, "");
    }

    function test_PayingTheWrongPixKeyDoesNotRelease() public {
        bytes32 offerId = _postOffer(10 ether);
        bytes32 orderId = _lock(offerId, 1 ether);
        verifier.setProof(
            orderId,
            MockVerifier.Canned({
                bankTxId: keccak256("x"),
                payeeKeyHash: keccak256("attacker@pix"),
                amountBrlCents: PRICE,
                paidAt: uint64(block.timestamp),
                rail: IAttestorVerifier.Rail.PIX,
                bound: true
            })
        );
        vm.expectRevert(FiatEscrow.WrongPayee.selector);
        escrow.releaseWithProof(orderId, "");
    }

    function test_UnderpaymentByOneCentavoIsRejected() public {
        bytes32 offerId = _postOffer(10 ether);
        bytes32 orderId = _lock(offerId, 1 ether);
        _goodProof(orderId, PRICE - 1);
        vm.expectRevert(FiatEscrow.Underpaid.selector);
        escrow.releaseWithProof(orderId, "");
    }

    /// A receipt from before the order existed cannot be settling it.
    function test_ReceiptPredatingTheOrderIsRejected() public {
        vm.warp(1000);
        bytes32 offerId = _postOffer(10 ether);
        bytes32 orderId = _lock(offerId, 1 ether);
        verifier.setProof(
            orderId,
            MockVerifier.Canned({
                bankTxId: keccak256("old"),
                payeeKeyHash: PIX,
                amountBrlCents: PRICE,
                paidAt: uint64(999),
                rail: IAttestorVerifier.Rail.PIX,
                bound: true
            })
        );
        vm.expectRevert(FiatEscrow.ReceiptPredatesOrder.selector);
        escrow.releaseWithProof(orderId, "");
    }

    function test_ProofNotBoundToTheOrderCannotBeUsed() public {
        bytes32 offerId = _postOffer(10 ether);
        bytes32 victim = _lock(offerId, 1 ether);
        bytes32 attacker = _lock(offerId, 1 ether);
        _goodProof(victim, PRICE); // only the victim's order has a proof
        vm.expectRevert(bytes("proof not bound to this order"));
        escrow.releaseWithProof(attacker, "");
    }

    /*//////////////////////////////////////////////////////////////
                         LIQUIDITY ACCOUNTING
    //////////////////////////////////////////////////////////////*/

    /// The LP must not be able to pull liquidity out from under a live order.
    function test_CloseOfferCannotStealLockedLiquidity() public {
        bytes32 offerId = _postOffer(10 ether);
        bytes32 orderId = _lock(offerId, 4 ether);

        uint256 before = lp.balance;
        vm.prank(lp);
        escrow.closeOffer(offerId);
        assertEq(lp.balance - before, 6 ether, "only unlocked liquidity returns");

        _goodProof(orderId, 4 * PRICE);
        escrow.releaseWithProof(orderId, "");
        assertEq(payout.balance, 4 ether, "the locked order still settles");
    }

    function test_ExpiredOrderReturnsLiquidityAndCannotRelease() public {
        bytes32 offerId = _postOffer(10 ether);
        bytes32 orderId = _lock(offerId, 1 ether);

        vm.warp(block.timestamp + 31 minutes + escrow.TAKER_GRACE());
        escrow.reclaimExpired(orderId);

        _goodProof(orderId, PRICE);
        vm.expectRevert(FiatEscrow.WrongState.selector);
        escrow.releaseWithProof(orderId, "");

        vm.prank(lp);
        escrow.closeOffer(offerId);
        assertEq(lp.balance, 100 ether, "LP whole again");
    }

    function test_CannotLockMoreThanTheOfferAllows() public {
        bytes32 offerId = _postOffer(10 ether);
        vm.prank(taker);
        vm.expectRevert(FiatEscrow.AmountOutOfRange.selector);
        escrow.lockOrder(offerId, 6 ether, FiatEscrow.Delivery.DIRECT, payout, 0); // > maxOrderWei
    }

    /// Two orders may each be within maxOrderWei yet exceed the offer between them.
    function test_CannotLockMoreLiquidityThanRemains() public {
        vm.prank(lp);
        bytes32 offerId =
            escrow.postOffer{value: 5 ether}(address(0), 5 ether, PRICE, PIX, 0.01 ether, 5 ether, address(verifier), PIX_MASK);
        _lock(offerId, 4 ether);
        vm.prank(taker);
        vm.expectRevert(FiatEscrow.InsufficientLiquidity.selector);
        escrow.lockOrder(offerId, 2 ether, FiatEscrow.Delivery.DIRECT, payout, 0);
    }

    /// Rounding must never favour the taker.
    function testFuzz_TakerObligationRoundsUp(uint256 amount) public {
        amount = bound(amount, 0.01 ether, 5 ether);
        bytes32 offerId = _postOffer(10 ether);
        vm.prank(taker);
        bytes32 orderId =
            escrow.lockOrder(offerId, amount, FiatEscrow.Delivery.DIRECT, payout, 0);
        (,,, uint256 cents,,,,,,,) = _order(orderId);
        assertGe(cents * 1 ether, amount * PRICE, "taker never owes less than the exact price");
    }

    /*//////////////////////////////////////////////////////////////
                            ORACLE BAND
    //////////////////////////////////////////////////////////////*/

    function test_OfferOutsideTheBandIsRejected() public {
        vm.prank(lp);
        vm.expectRevert(FiatEscrow.PriceOutsideBand.selector);
        escrow.postOffer{value: 1 ether}(address(0), 1 ether, PRICE * 2, PIX, 0.01 ether, 1 ether, address(verifier), PIX_MASK);
    }

    /// An offer that was sane when posted must be re-checked when taken.
    function test_OfferDriftingOutsideTheBandCannotBeTaken() public {
        bytes32 offerId = _postOffer(10 ether);
        oracle.set(PRICE * 2); // market moved
        vm.prank(taker);
        vm.expectRevert(FiatEscrow.PriceOutsideBand.selector);
        escrow.lockOrder(offerId, 1 ether, FiatEscrow.Delivery.DIRECT, payout, 0);
    }

    /// No price must stop the trade, not fall back to a stale one.
    function test_StaleOracleStopsTrading() public {
        oracle.setStale(true);
        vm.prank(lp);
        vm.expectRevert(bytes("stale"));
        escrow.postOffer{value: 1 ether}(address(0), 1 ether, PRICE, PIX, 0.01 ether, 1 ether, address(verifier), PIX_MASK);
    }

    /// The escrow must not trust the oracle to police its own staleness.
    function test_EscrowRejectsAnOldPriceEvenIfTheOracleServesItHappily() public {
        vm.warp(block.timestamp + 10 days);
        oracle.setUpdatedAt(uint64(block.timestamp - 2 hours));
        vm.prank(lp);
        vm.expectRevert(FiatEscrow.StalePrice.selector);
        escrow.postOffer{value: 1 ether}(address(0), 1 ether, PRICE, PIX, 0.01 ether, 1 ether, address(verifier), PIX_MASK);
    }

    function test_ZeroPriceIsNeverInsideTheBand() public {
        oracle.set(0);
        vm.prank(lp);
        vm.expectRevert(FiatEscrow.PriceOutsideBand.selector);
        escrow.postOffer{value: 1 ether}(address(0), 1 ether, PRICE, PIX, 0.01 ether, 1 ether, address(verifier), PIX_MASK);
    }

    /*//////////////////////////////////////////////////////////////
                              GOVERNANCE
    //////////////////////////////////////////////////////////////*/

    function test_UnknownVerifierCannotBeSelected() public {
        MockVerifier rogue = new MockVerifier();
        vm.prank(lp);
        vm.expectRevert(FiatEscrow.VerifierNotAllowed.selector);
        escrow.postOffer{value: 1 ether}(address(0), 1 ether, PRICE, PIX, 0.01 ether, 1 ether, address(rogue), PIX_MASK);
    }

    /**
     * Revoking a verifier must stop live offers, not just new ones.
     *
     * Checking the allowlist only at post time made revocation useless against the case it
     * exists for: a compromised attestor would keep settling against every offer already
     * carrying it.
     */
    function test_RevokingAVerifierStopsSettlementOnLiveOffers() public {
        bytes32 offerId = _postOffer(10 ether);
        bytes32 orderId = _lock(offerId, 1 ether);
        _goodProof(orderId, PRICE);

        vm.prank(governor);
        escrow.setVerifier(address(verifier), false);

        vm.expectRevert(FiatEscrow.VerifierNotAllowed.selector);
        escrow.releaseWithProof(orderId, "");
    }

    /// And a taker stranded by that revocation still has the dispute path.
    function test_ARevokedVerifierLeavesTheDisputePathOpen() public {
        bytes32 offerId = _postOffer(10 ether);
        bytes32 orderId = _lock(offerId, 1 ether);
        vm.prank(governor);
        escrow.setVerifier(address(verifier), false);

        vm.prank(taker);
        escrow.raiseDispute(orderId, "I paid, then the verifier was revoked");
        (RulingLib.Ruling memory r, bytes memory sig) = _ruling(orderId, "RELEASE");
        _rule(orderId, r, sig);
        assertEq(payout.balance, 1 ether, "the taker is still made whole");
    }

    /// The governor's dispute power must not reach ordinary orders.
    function test_GovernorCannotTouchANonDisputedOrder() public {
        bytes32 offerId = _postOffer(10 ether);
        bytes32 orderId = _lock(offerId, 1 ether);
        (RulingLib.Ruling memory r, bytes memory sig) = _ruling(orderId, "RELEASE");
        vm.prank(governor);
        vm.expectRevert(FiatEscrow.WrongState.selector);
        escrow.resolveDispute(orderId, r, sig);
    }

    /*//////////////////////////////////////////////////////////////
                    A MALICIOUS GOVERNOR, AND THE DELAY
    //////////////////////////////////////////////////////////////*/

    /**
     * The theft: the governor allows its own arbitrator key, takes orders as the taker,
     * disputes them and rules RELEASE - an offer drained without a centavo of BRL. The
     * previous NatSpec on resolveDispute said this was impossible.
     *
     * With the delay, the arbitrator cannot be added in the same block, and the LP who sees
     * it scheduled closes their offer.
     */
    function test_AGovernorsOwnArbitratorWaitsAndTheLPLeavesFirst() public {
        bytes32 offerId = _postOffer(10 ether);
        uint256 govArbKey = 0x60F60F;
        bytes memory addArb = abi.encodeCall(FiatEscrow.setArbitrator, (vm.addr(govArbKey), true));

        vm.prank(governor);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, FiatEscrow.setArbitrator.selector)
        );
        escrow.setArbitrator(vm.addr(govArbKey), true);
        vm.prank(governor);
        escrow.schedule(addArb);

        // The LP reads ChangeScheduled and leaves with everything.
        uint256 before = lp.balance;
        vm.prank(lp);
        escrow.closeOffer(offerId);
        assertEq(lp.balance - before, 10 ether);

        vm.warp(block.timestamp + DELAY);
        vm.prank(governor);
        escrow.execute(addArb);
        vm.prank(governor);
        vm.expectRevert(FiatEscrow.OfferInactive.selector);
        escrow.lockOrder(offerId, 1 ether, FiatEscrow.Delivery.DIRECT, governor, 0);
    }

    /**
     * The bypass a plain timelock leaves open: take the liquidity hostage DURING the delay.
     * The governor locks orders as the taker and disputes them at once; a disputed order is
     * frozen, so the LP's closeOffer cannot recover it, and the new arbitrator would rule
     * RELEASE the moment it landed. A ruling for the taker must come from an arbitrator that
     * predates the dispute - so it cannot.
     */
    function test_DisputesRaisedBeforeANewArbitratorCannotBeReleasedByIt() public {
        bytes32 offerId = _postOffer(10 ether);
        uint256 govArbKey = 0x60F60F;
        bytes memory addArb = abi.encodeCall(FiatEscrow.setArbitrator, (vm.addr(govArbKey), true));
        vm.prank(governor);
        escrow.schedule(addArb);

        vm.deal(governor, 1 ether);
        vm.prank(governor);
        bytes32 hostage = escrow.lockOrder(offerId, 5 ether, FiatEscrow.Delivery.DIRECT, governor, 0);
        vm.prank(governor);
        escrow.raiseDispute(hostage, "I paid, honest");

        vm.warp(block.timestamp + DELAY);
        vm.prank(governor);
        escrow.execute(addArb);

        arbKey = govArbKey;
        (RulingLib.Ruling memory release, bytes memory sig) = _ruling(hostage, "RELEASE");
        vm.prank(governor);
        vm.expectRevert(
            abi.encodeWithSelector(FiatEscrow.ArbitratorNewerThanDispute.selector, vm.addr(govArbKey))
        );
        escrow.resolveDispute(hostage, release, sig);
        assertEq(governor.balance, 1 ether, "not a wei released to the hostage-taker");

        // A new arbitrator can always return funds to the LP, so rotation never strands one.
        (RulingLib.Ruling memory refund, bytes memory sig2) = _ruling(hostage, "REFUND");
        _rule(hostage, refund, sig2);
        vm.prank(lp);
        escrow.closeOffer(offerId);
        assertEq(address(escrow).balance, 0, "the LP recovered all ten");
    }

    function test_AllowingAVerifierWaitsButRevokingDoesNot() public {
        MockVerifier rogue = new MockVerifier();
        vm.prank(governor);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, FiatEscrow.setVerifier.selector)
        );
        escrow.setVerifier(address(rogue), true);
        _afterDelay(address(escrow), abi.encodeCall(FiatEscrow.setVerifier, (address(rogue), true)));
        assertTrue(escrow.allowedVerifier(address(rogue)));
        vm.prank(governor);
        escrow.setVerifier(address(rogue), false);
        assertFalse(escrow.allowedVerifier(address(rogue)));
    }

    /// Instant configuration is only safe because nobody can post liquidity until it ends.
    function test_NoOffersBeforeSetupIsComplete() public {
        FiatEscrow fresh = new FiatEscrow(
            address(oracle), address(registry), address(entrypoint), address(entrypoint), 500, governor, DELAY,
            DISPUTE_TIMEOUT,
            TAKER_DISPUTE_TIMEOUT,
            MAX_VETTING_FEE_BPS
        );
        vm.prank(lp);
        vm.expectRevert(DelayedGovernance.SetupIncomplete.selector);
        fresh.postOffer{value: 1 ether}(
            address(0), 1 ether, PRICE, PIX, 0.01 ether, 1 ether, address(verifier), PIX_MASK
        );
    }

    /// ...nor an LP's free liquidity.
    function test_GovernorCannotDrainFreeLiquidity() public {
        bytes32 offerId = _postOffer(10 ether);
        bytes32 orderId = _lock(offerId, 1 ether);
        vm.prank(taker);
        escrow.raiseDispute(orderId, "bank down");

        (RulingLib.Ruling memory r, bytes memory sig) = _ruling(orderId, "RELEASE");
        _rule(orderId, r, sig);

        assertEq(payout.balance, 1 ether, "only the disputed amount moved");
        assertEq(address(escrow).balance, 9 ether, "the rest of the offer is untouched");
    }

    /*//////////////////////////////////////////////////////////////
                    DISPUTES END, AND COST THE RIGHT PARTY
    //////////////////////////////////////////////////////////////*/

    /// A retail offer, an order against it, and a dispute raised by `by`.
    function _retailDispute(address by) internal returns (bytes32 offerId, bytes32 orderId) {
        // 0.1 ETH is R$3,000 at the test price - inside a new retail LP's R$5,000 cap.
        vm.prank(retail);
        offerId = escrow.postOffer{value: 0.1 ether}(
            address(0), 0.1 ether, PRICE, PIX, 0.01 ether, 0.1 ether, address(verifier), PIX_MASK
        );
        orderId = _lock(offerId, 0.05 ether);
        vm.prank(by);
        escrow.raiseDispute(orderId, "disputed");
    }

    function _reputation(address who) internal view returns (uint256 settledCents, uint32 lost) {
        (, settledCents,, lost,,,) = registry.lps(who);
    }

    /**
     * The griefing this replaced: an on-ramp REFUND recorded a lost dispute against the LP.
     * REFUND means the TAKER never paid - the LP was right - so any taker could halve a retail
     * LP's limit, eight times over, by locking orders it never meant to pay and disputing them.
     */
    function test_ATakerWhoNeverPaidCannotCutTheLPsLimitByDisputing() public {
        uint256 capBefore = registry.capOf(retail);
        for (uint256 i; i < 3; ++i) {
            (bytes32 offerId, bytes32 orderId) = _retailDispute(taker);
            (RulingLib.Ruling memory r, bytes memory sig) = _ruling(orderId, "REFUND");
            _rule(orderId, r, sig);
            vm.prank(retail);
            escrow.closeOffer(offerId);
        }
        assertEq(registry.capOf(retail), capBefore, "the LP that was right keeps its limit");
        (, uint32 lost) = _reputation(retail);
        assertEq(lost, 0);
    }

    /// An LP that disputes an order the taker really paid - to hold it - loses that dispute.
    function test_AnLPThatDisputesAPaidOrderAndLosesIsPenalised() public {
        uint256 capBefore = registry.capOf(retail);
        (, bytes32 orderId) = _retailDispute(retail);
        (RulingLib.Ruling memory r, bytes memory sig) = _ruling(orderId, "RELEASE");
        _rule(orderId, r, sig);
        assertEq(payout.balance, 0.05 ether, "the taker who paid is paid");
        (uint256 settled, uint32 lost) = _reputation(retail);
        assertEq(lost, 1, "the LP lost the dispute it raised");
        assertEq(settled, 150_000, "and the trade still completed");
        assertLt(registry.capOf(retail), capBefore);
    }

    /// A RELEASE on a dispute the TAKER raised is a completed trade, not a finding against the LP.
    function test_AReleaseOnATakersDisputeCountsAsSettledVolume() public {
        (, bytes32 orderId) = _retailDispute(taker);
        (RulingLib.Ruling memory r, bytes memory sig) = _ruling(orderId, "RELEASE");
        _rule(orderId, r, sig);
        (uint256 settled, uint32 lost) = _reputation(retail);
        assertEq(settled, 150_000);
        assertEq(lost, 0);
    }

    /**
     * The governor never submits. The ruling is signed; the taker it favours submits it. This
     * was governor-only, so an absent or hostile governor froze every disputed order whatever
     * the arbitrator decided.
     */
    function test_WithNoGovernorTheFavouredPartySubmitsTheSignedRuling() public {
        bytes32 offerId = _postOffer(10 ether);
        bytes32 orderId = _lock(offerId, 1 ether);
        vm.prank(taker);
        escrow.raiseDispute(orderId, "paid, attestor down");
        (RulingLib.Ruling memory r, bytes memory sig) = _ruling(orderId, "RELEASE");

        // Governance is gone entirely.
        vm.prank(governor);
        escrow.renounceGovernor();

        vm.startPrank(taker);
        escrow.resolveDispute(orderId, r, sig);
        vm.warp(block.timestamp + 1 days);
        escrow.resolveDispute(orderId, r, sig);
        vm.stopPrank();
        assertEq(payout.balance, 1 ether, "executed on the arbitrator's signature alone");
    }

    /// Permissionless submission does not mean permissionless deciding: the signature rules.
    function test_ASubmitterCannotChangeTheOutcomeOrForgeTheSigner() public {
        bytes32 offerId = _postOffer(10 ether);
        bytes32 orderId = _lock(offerId, 1 ether);
        vm.prank(taker);
        escrow.raiseDispute(orderId, "x");
        (RulingLib.Ruling memory r, bytes memory sig) = _ruling(orderId, "REFUND");
        r.outcome = "RELEASE"; // the taker edits the ruling it was handed
        vm.prank(taker);
        vm.expectRevert(); // recovers some other address: NotArbitrator
        escrow.resolveDispute(orderId, r, sig);
    }

    /**
     * The desk is dead: nobody ever rules. After TAKER_DISPUTE_TIMEOUT (a taker raised it: H-04) a stranger expires the
     * dispute. The taker raised it, so the order left its offer and its credit then (SRM1-4):
     * the four go to the LP itself, the offer keeps its six, and nothing is stranded.
     */
    function test_ADeadDeskCannotFreezeAnOrder_TheTimeoutRefundsTheLP() public {
        bytes32 offerId = _postOffer(10 ether);
        bytes32 orderId = _lock(offerId, 4 ether);
        vm.prank(taker);
        escrow.raiseDispute(orderId, "paid");

        vm.warp(block.timestamp + TAKER_DISPUTE_TIMEOUT);
        uint256 before = lp.balance;
        vm.prank(address(0xBEEF));
        escrow.expireDispute(orderId);
        assertEq(lp.balance - before, 4 ether, "the disputed four, to the LP directly");

        (,,,,,, FiatEscrow.OrderState state,,,,) = _order(orderId);
        assertEq(uint8(state), uint8(FiatEscrow.OrderState.CANCELLED));
        (,, uint256 available, uint256 locked,,,,,,,,) = escrow.offers(offerId);
        assertEq(available, 6 ether, "the offer keeps what was never disputed");
        assertEq(locked, 0);

        before = lp.balance;
        vm.prank(lp);
        escrow.closeOffer(offerId);
        assertEq(lp.balance - before, 6 ether);
        (,,,,,, uint256 exposure) = registry.lps(lp);
        assertEq(exposure, 0, "no credit stranded");
        assertEq(registry.reservedBy(address(escrow), lp), 0);
        (, uint32 lost) = _reputation(lp);
        assertEq(lost, 0, "a taker's unanswered dispute costs the LP nothing");
    }

    function test_ExpiringBeforeTheTimeoutIsRefused() public {
        bytes32 offerId = _postOffer(10 ether);
        bytes32 orderId = _lock(offerId, 1 ether);
        vm.prank(taker);
        escrow.raiseDispute(orderId, "x");
        uint64 deadline = uint64(block.timestamp + TAKER_DISPUTE_TIMEOUT);
        vm.warp(deadline - 1);
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.DisputeStillOpen.selector, deadline));
        escrow.expireDispute(orderId);
    }

    /// From the deadline on, only the default applies: a late ruling cannot race the expiry.
    function test_ARulingAfterTheDeadlineIsRefused() public {
        bytes32 offerId = _postOffer(10 ether);
        bytes32 orderId = _lock(offerId, 1 ether);
        vm.prank(taker);
        escrow.raiseDispute(orderId, "x");
        uint64 deadline = uint64(block.timestamp + TAKER_DISPUTE_TIMEOUT);
        vm.warp(deadline);
        (RulingLib.Ruling memory r, bytes memory sig) = _ruling(orderId, "RELEASE");
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.DisputeExpired.selector, deadline));
        escrow.resolveDispute(orderId, r, sig);
        escrow.expireDispute(orderId);
        assertEq(payout.balance, 0);
    }

    /// v2.0 I-43: a ruling is dated from its dispute to now (plus the desk's clock skew).
    function test_ARulingDatedBeforeTheDisputeOrInTheFutureIsRefused() public {
        bytes32 offerId = _postOffer(10 ether);
        bytes32 orderId = _lock(offerId, 1 ether);
        vm.warp(block.timestamp + 60);
        vm.prank(taker);
        escrow.raiseDispute(orderId, "x");
        (RulingLib.Ruling memory r, bytes memory sig) = _ruling(orderId, "RELEASE");
        r.ruledAt = uint64(block.timestamp - 1);
        vm.expectRevert(abi.encodeWithSelector(RulingLib.RulingOutOfTime.selector, r.ruledAt));
        escrow.resolveDispute(orderId, r, sig);
        r.ruledAt = uint64(block.timestamp + 15 minutes + 1);
        vm.expectRevert(abi.encodeWithSelector(RulingLib.RulingOutOfTime.selector, r.ruledAt));
        escrow.resolveDispute(orderId, r, sig);
        (r, sig) = _ruling(orderId, "RELEASE"); // dated now: admitted
        escrow.resolveDispute(orderId, r, sig);
    }

    function test_NothingButADisputedOrderCanBeExpired() public {
        bytes32 offerId = _postOffer(10 ether);
        bytes32 orderId = _lock(offerId, 1 ether);
        vm.warp(block.timestamp + DISPUTE_TIMEOUT + 1);
        vm.expectRevert(FiatEscrow.WrongState.selector);
        escrow.expireDispute(orderId);
        vm.expectRevert(FiatEscrow.WrongState.selector);
        escrow.expireDispute(keccak256("never existed"));
    }

    /// An LP that freezes an order with its own dispute and never gets a ruling carries it.
    function test_AnLPsOwnDisputeThatTimesOutCountsAgainstIt() public {
        (, bytes32 orderId) = _retailDispute(retail);
        uint256 capBefore = registry.capOf(retail);
        vm.warp(block.timestamp + DISPUTE_TIMEOUT);
        escrow.expireDispute(orderId);
        (uint256 settled, uint32 lost) = _reputation(retail);
        assertEq(lost, 1);
        assertEq(settled, 0, "a timeout never counts as volume");
        assertEq(registry.capOf(retail), capBefore / 2);
    }

    /// Once executed, the same ruling has nothing left to act on.
    function test_ARulingCannotBeReplayedOnceExecuted() public {
        bytes32 offerId = _postOffer(10 ether);
        bytes32 orderId = _lock(offerId, 1 ether);
        vm.prank(taker);
        escrow.raiseDispute(orderId, "x");
        (RulingLib.Ruling memory r, bytes memory sig) = _ruling(orderId, "REFUND");
        _rule(orderId, r, sig);
        vm.expectRevert(FiatEscrow.WrongState.selector);
        escrow.resolveDispute(orderId, r, sig);
    }

    /**
     * A genuine ruling presented at another escrow, where the same arbitrator key is registered
     * and an order with the named id is disputed. The EIP-712 domain and the struct both name
     * the escrow, so there it recovers to a stranger.
     */
    function test_ARulingCannotBeReplayedAtAnotherEscrow() public {
        FiatEscrow other = new FiatEscrow(
            address(oracle), address(registry), address(entrypoint), address(entrypoint), 500, governor, DELAY,
            DISPUTE_TIMEOUT,
            TAKER_DISPUTE_TIMEOUT,
            MAX_VETTING_FEE_BPS
        );
        vm.startPrank(governor);
        other.setArbitrator(vm.addr(arbKey), true);
        other.setVerifier(address(verifier), true);
        other.completeSetup();
        vm.stopPrank();
        _afterDelay(address(registry), abi.encodeCall(LPRegistry.setEscrow, (address(other), true)));

        vm.prank(lp);
        bytes32 offerId = other.postOffer{value: 10 ether}(
            address(0), 10 ether, PRICE, PIX, 0.01 ether, 5 ether, address(verifier), PIX_MASK
        );
        vm.prank(taker);
        bytes32 orderId = other.lockOrder(offerId, 1 ether, FiatEscrow.Delivery.DIRECT, payout, 0);
        vm.prank(taker);
        other.raiseDispute(orderId, "x");

        // Signed for THIS escrow, naming the other escrow's order.
        (RulingLib.Ruling memory r, bytes memory sig) = _ruling(orderId, "RELEASE");
        address strangerThere = ecrecover(_digestAt(r, address(other)), uint8(sig[64]), bytes32(_word(sig, 0)), bytes32(_word(sig, 32)));
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.NotArbitrator.selector, strangerThere));
        other.resolveDispute(orderId, r, sig);

        // The same arbitrator's ruling signed for the other escrow executes there.
        (uint8 v, bytes32 rr, bytes32 ss) = vm.sign(arbKey, _digestAt(r, address(other)));
        _ruleAt(other, orderId, r, abi.encodePacked(rr, ss, v));
        assertEq(payout.balance, 1 ether);
    }

    function _word(bytes memory b, uint256 at) internal pure returns (uint256 w) {
        assembly {
            w := mload(add(add(b, 32), at))
        }
    }

    /*//////////////////////////////////////////////////////////////
               A RULING IS PUBLIC BEFORE IT MOVES ANYTHING
    //////////////////////////////////////////////////////////////*/

    /*//////////////////////////////////////////////////////////////
                  v3.1 FOLLOW-UPS: v2.0 FINDINGS NOW FIXED IN CODE
    //////////////////////////////////////////////////////////////*/

    uint256 internal constant GATE_KEY = 0x6A7E;

    function _gateSig(bytes32 offerId, address who, uint256 amount, address recipient, bool boleto, uint64 deadline)
        internal
        view
        returns (bytes memory)
    {
        bytes32 d = keccak256(
            abi.encodePacked(
                "\x19Ethereum Signed Message:\n32",
                keccak256(
                    abi.encode(
                        "PrivacyPoolsBRL/taker-gate/v1", block.chainid, address(escrow), offerId, who, amount, recipient,
                        boleto, deadline
                    )
                )
            )
        );
        (uint8 v, bytes32 r, bytes32 ss) = vm.sign(GATE_KEY, d);
        return abi.encodePacked(r, ss, v);
    }

    /// H-04: an LP that gates its offer accepts only locks its gate approved, each once, before its deadline.
    function test_H04_AGatedOfferLocksOnlyWithTheGatesOneUseApproval() public {
        bytes32 offerId = _postOffer(5 ether);
        vm.prank(taker);
        vm.expectRevert(FiatEscrow.NotLP.selector);
        escrow.setTakerGate(offerId, vm.addr(GATE_KEY));
        vm.prank(lp);
        escrow.setTakerGate(offerId, vm.addr(GATE_KEY));
        assertEq(escrow.takerGate(offerId), vm.addr(GATE_KEY));

        vm.prank(taker);
        vm.expectRevert(FiatEscrow.GateRequired.selector);
        escrow.lockOrder(offerId, 1 ether, FiatEscrow.Delivery.DIRECT, payout, 0);

        uint64 deadline = uint64(block.timestamp + 10 minutes);
        bytes memory sig = _gateSig(offerId, taker, 1 ether, payout, false, deadline);
        // Bound to the taker, the amount and the recipient.
        vm.prank(retail);
        vm.expectRevert(FiatEscrow.GateApprovalInvalid.selector);
        escrow.lockOrderGated(offerId, 1 ether, FiatEscrow.Delivery.DIRECT, payout, 0, false, deadline, sig);
        vm.prank(taker);
        vm.expectRevert(FiatEscrow.GateApprovalInvalid.selector);
        escrow.lockOrderGated(offerId, 2 ether, FiatEscrow.Delivery.DIRECT, payout, 0, false, deadline, sig);
        vm.prank(taker);
        bytes32 orderId = escrow.lockOrderGated(offerId, 1 ether, FiatEscrow.Delivery.DIRECT, payout, 0, false, deadline, sig);
        (, address t,,,,,,,,,) = escrow.orders(orderId);
        assertEq(t, taker);
        // One use.
        vm.prank(taker);
        vm.expectRevert(FiatEscrow.GateApprovalInvalid.selector);
        escrow.lockOrderGated(offerId, 1 ether, FiatEscrow.Delivery.DIRECT, payout, 0, false, deadline, sig);
        // Expired.
        vm.warp(deadline + 1);
        bytes memory late = _gateSig(offerId, taker, 1 ether, payout, false, deadline);
        vm.prank(taker);
        vm.expectRevert(FiatEscrow.GateApprovalInvalid.selector);
        escrow.lockOrderGated(offerId, 1 ether, FiatEscrow.Delivery.DIRECT, payout, 0, false, deadline, late);
        // Ungating restores the open path.
        vm.prank(lp);
        escrow.setTakerGate(offerId, address(0));
        _lock(offerId, 1 ether);
    }

    /// N-39: the cap counts what offers and orders hold, so a donation fills nothing.
    function test_N39_ADonationNoLongerFillsTheAssetCap() public {
        vm.prank(governor);
        escrow.setAssetCap(address(0), 10 ether);
        _postOffer(5 ether);
        assertEq(escrow.heldOf(address(0)), 5 ether);
        vm.deal(address(this), 100 ether);
        (bool ok,) = address(escrow).call{value: 50 ether}("");
        assertTrue(ok);
        _postOffer(5 ether);
        assertEq(escrow.heldOf(address(0)), 10 ether, "the donation is not held for anyone");
        vm.deal(lp, 100 ether);
        vm.prank(lp);
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.AssetCapExceeded.selector, address(0), 10 ether));
        escrow.postOffer{value: 1}(address(0), 1, PRICE, PIX, 1, 1, address(verifier), PIX_MASK);
    }

    /// L-30: the taker's recipient can name another address while the order is live, and the payment goes there.
    function test_L30_TheRecipientCanRedirectALiveOrder() public {
        bytes32 offerId = _postOffer(5 ether);
        bytes32 orderId = _lock(offerId, 1 ether);
        address next = makeAddr("next");
        vm.prank(taker);
        vm.expectRevert(FiatEscrow.NotTaker.selector);
        escrow.setRecipient(orderId, next);
        vm.prank(payout);
        escrow.setRecipient(orderId, next);
        _goodProof(orderId, 3_000_000);
        escrow.releaseWithProof(orderId, "");
        assertEq(next.balance, 1 ether);
        vm.prank(next);
        vm.expectRevert(FiatEscrow.WrongState.selector);
        escrow.setRecipient(orderId, payout);
    }

    /// I-22: only the LP's own bank session settles its order.
    function test_I22_ASessionSomeoneElseRanDoesNotSettle() public {
        bytes32 offerId = _postOffer(5 ether);
        bytes32 orderId = _lock(offerId, 1 ether);
        _goodProof(orderId, 3_000_000);
        verifier.forceProver(taker);
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.WrongProver.selector, taker));
        escrow.releaseWithProof(orderId, "");
        verifier.forceProver(address(0));
        escrow.releaseWithProof(orderId, "");
    }

    function _disputed(uint256 amount) internal returns (bytes32 orderId) {
        orderId = _lock(_postOffer(10 ether), amount);
        vm.prank(taker);
        escrow.raiseDispute(orderId, "x");
    }

    function test_ARulingIsPostedFirstAndExecutesADayLater() public {
        bytes32 orderId = _disputed(1 ether);
        (RulingLib.Ruling memory r, bytes memory sig) = _ruling(orderId, "RELEASE");
        escrow.resolveDispute(orderId, r, sig);
        assertEq(payout.balance, 0, "posting moves nothing");

        uint64 executableAt = uint64(block.timestamp + 1 days);
        vm.warp(executableAt - 1);
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.RulingNotReady.selector, executableAt));
        escrow.resolveDispute(orderId, r, sig);

        vm.warp(executableAt);
        vm.prank(address(0xBEEF)); // a different courier is fine
        escrow.resolveDispute(orderId, r, sig);
        assertEq(payout.balance, 1 ether);
    }

    /**
     * The attack submission-by-anyone would otherwise open: the arbitrator key is stolen. The
     * thief locks orders as a taker, disputes them, signs RELEASE and submits - no governor in
     * the way any more. The ruling is public for a day; the governor revokes the key, which is
     * instant, and the posted ruling can never execute.
     */
    function test_AStolenArbitratorKeyIsRevokedBeforeItsRulingsCanPay() public {
        bytes32 offerId = _postOffer(10 ether);
        address thief = makeAddr("thief");
        vm.prank(thief);
        bytes32 orderId = escrow.lockOrder(offerId, 5 ether, FiatEscrow.Delivery.DIRECT, thief, 0);
        vm.prank(thief);
        escrow.raiseDispute(orderId, "paid, honest");
        (RulingLib.Ruling memory r, bytes memory sig) = _ruling(orderId, "RELEASE");
        vm.prank(thief);
        escrow.resolveDispute(orderId, r, sig); // RulingPosted: the desk has no such case

        vm.prank(governor);
        escrow.setArbitrator(vm.addr(arbKey), false);
        vm.warp(block.timestamp + 1 days);
        vm.prank(thief);
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.NotArbitrator.selector, vm.addr(arbKey)));
        escrow.resolveDispute(orderId, r, sig);
        assertEq(thief.balance, 0);

        // And the LP gets everything back on the timeout, with no arbitrator at all.
        vm.warp(block.timestamp + DISPUTE_TIMEOUT);
        escrow.expireDispute(orderId);
        vm.prank(lp);
        escrow.closeOffer(offerId);
        assertEq(address(escrow).balance, 0);
    }

    function test_ResubmittingAPendingRulingEarlyDoesNotRestartItsDelay() public {
        bytes32 orderId = _disputed(1 ether);
        (RulingLib.Ruling memory r, bytes memory sig) = _ruling(orderId, "RELEASE");
        escrow.resolveDispute(orderId, r, sig);
        uint64 executableAt = uint64(block.timestamp + 1 days);
        vm.warp(block.timestamp + 12 hours);
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.RulingNotReady.selector, executableAt));
        escrow.resolveDispute(orderId, r, sig);
        vm.warp(executableAt);
        escrow.resolveDispute(orderId, r, sig);
        assertEq(payout.balance, 1 ether);
    }

    /// I-68: a second valid ruling cannot restart the delay while the arbitrator who posted the first is still
    /// registered. Once it is revoked, a rotated-in arbitrator's ruling replaces it - and a REFUND may come from any
    /// current arbitrator, however new.
    function test_APendingRulingIsReplacedOnlyAfterItsArbitratorIsRevoked() public {
        uint256 rotatedKey = 0xA2B2;
        bytes memory addRotated = abi.encodeCall(FiatEscrow.setArbitrator, (vm.addr(rotatedKey), true));
        vm.prank(governor);
        escrow.schedule(addRotated);
        bytes32 orderId = _disputed(1 ether);
        (RulingLib.Ruling memory release, bytes memory sigRelease) = _ruling(orderId, "RELEASE");
        escrow.resolveDispute(orderId, release, sigRelease);
        (RulingLib.Ruling memory refund, bytes memory sigRefund) = _ruling(orderId, "REFUND");
        vm.expectRevert(FiatEscrow.RulingAlreadyPosted.selector);
        escrow.resolveDispute(orderId, refund, sigRefund);

        vm.warp(block.timestamp + DELAY);
        vm.startPrank(governor);
        escrow.execute(addRotated);
        escrow.setArbitrator(vm.addr(arbKey), false); // the original key is compromised
        vm.stopPrank();
        arbKey = rotatedKey;
        (refund, sigRefund) = _ruling(orderId, "REFUND");
        uint256 lpHad = lp.balance;
        _rule(orderId, refund, sigRefund);
        assertEq(payout.balance, 0, "the revoked key's RELEASE never ran");
        assertEq(lp.balance - lpHad, 1 ether, "the rotated arbitrator's REFUND did");
    }

    /// A ruling must leave a day to execute before the deadline, and dies with it if unexecuted.
    function test_APostedRulingMustExecuteBeforeTheDeadline() public {
        bytes32 orderId = _disputed(1 ether);
        uint64 deadline = uint64(block.timestamp + TAKER_DISPUTE_TIMEOUT);
        (RulingLib.Ruling memory r, bytes memory sig) = _ruling(orderId, "RELEASE");

        vm.warp(deadline - 2 days + 1);
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.DisputeExpired.selector, deadline));
        escrow.resolveDispute(orderId, r, sig);

        vm.warp(deadline - 2 days);
        escrow.resolveDispute(orderId, r, sig);
        vm.warp(deadline);
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.DisputeExpired.selector, deadline));
        escrow.resolveDispute(orderId, r, sig);
        escrow.expireDispute(orderId);
        assertEq(payout.balance, 0);
    }

    function test_TheDisputeTimeoutIsBoundedAtDeployment() public {
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.BadDisputeTimeout.selector, 7 days - 1));
        new FiatEscrow(address(oracle), address(registry), address(entrypoint), address(entrypoint), 500, governor, DELAY, 7 days - 1, TAKER_DISPUTE_TIMEOUT, MAX_VETTING_FEE_BPS);
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.BadDisputeTimeout.selector, 90 days + 1));
        new FiatEscrow(address(oracle), address(registry), address(entrypoint), address(entrypoint), 500, governor, DELAY, 90 days + 1, TAKER_DISPUTE_TIMEOUT, MAX_VETTING_FEE_BPS);
        FiatEscrow ok = new FiatEscrow(address(oracle), address(registry), address(entrypoint), address(entrypoint), 500, governor, DELAY, 7 days, TAKER_DISPUTE_TIMEOUT, MAX_VETTING_FEE_BPS);
        assertEq(ok.DISPUTE_TIMEOUT(), 7 days);
    }

    /// The change that matters: the governor can no longer decide, only submit.
    function test_GovernorCannotResolveWithoutAnArbitratorSignature() public {
        bytes32 offerId = _postOffer(10 ether);
        bytes32 orderId = _lock(offerId, 1 ether);
        vm.prank(taker);
        escrow.raiseDispute(orderId, "x");

        uint256 rogue = 0xDECAF;
        (RulingLib.Ruling memory r,) = _ruling(orderId, "RELEASE");
        (uint8 v, bytes32 rr, bytes32 ss) = vm.sign(rogue, _digest(r));
        vm.prank(governor);
        vm.expectRevert(
            abi.encodeWithSelector(FiatEscrow.NotArbitrator.selector, vm.addr(rogue))
        );
        escrow.resolveDispute(orderId, r, abi.encodePacked(rr, ss, v));
    }

    /// A genuine ruling for one order must not execute against another.
    function test_RulingCannotBeMovedToAnotherOrder() public {
        bytes32 offerId = _postOffer(10 ether);
        bytes32 victim = _lock(offerId, 1 ether);
        bytes32 other = _lock(offerId, 1 ether);
        vm.prank(taker);
        escrow.raiseDispute(other, "x");

        (RulingLib.Ruling memory r, bytes memory sig) = _ruling(victim, "RELEASE");
        vm.prank(governor);
        vm.expectRevert(FiatEscrow.RulingForAnotherOrder.selector);
        escrow.resolveDispute(other, r, sig);
    }

    /// An unrecognised outcome must never quietly mean one of the two real ones.
    function test_UnknownOutcomeReverts() public {
        bytes32 offerId = _postOffer(10 ether);
        bytes32 orderId = _lock(offerId, 1 ether);
        vm.prank(taker);
        escrow.raiseDispute(orderId, "x");

        (RulingLib.Ruling memory r, bytes memory sig) = _ruling(orderId, "MAYBE");
        vm.prank(governor);
        vm.expectRevert(RulingLib.BadOutcome.selector);
        escrow.resolveDispute(orderId, r, sig);
    }

    /*//////////////////////////////////////////////////////////////
                           PAYING BY BOLETO
    //////////////////////////////////////////////////////////////*/

    uint16 constant BOLETO_MASK = uint16(1 << uint8(IAttestorVerifier.Rail.BOLETO));
    /*//////////////////////////////////////////////////////////////
              A TAKER'S DISPUTE: IN THE WINDOW, AND SHORT (H-04)
    //////////////////////////////////////////////////////////////*/

    /// A taker disputes only while the order can still be paid for: up to and including `payBy`.
    function test_ATakerCanDisputeOnlyInsideThePayWindow() public {
        bytes32 offerId = _postOffer(10 ether);
        bytes32 late = _lock(offerId, 1 ether);
        bytes32 inTime = _lock(offerId, 1 ether);
        (,,,,, uint64 payBy,,,,,) = _order(late);

        // N-05: the taker's grace. Past payBy, nobody may reclaim yet, and the taker may still dispute.
        vm.warp(payBy + escrow.TAKER_GRACE());
        vm.expectRevert(FiatEscrow.WindowStillOpen.selector);
        escrow.reclaimExpired(inTime);
        vm.prank(taker);
        escrow.raiseDispute(inTime, "paid at minute 29, the LP never proved");

        vm.warp(payBy + escrow.TAKER_GRACE() + 1);
        vm.prank(taker);
        vm.expectRevert(FiatEscrow.WindowExpired.selector);
        escrow.raiseDispute(late, "too late to freeze anything");
        escrow.reclaimExpired(late); // the liquidity goes back, as for any unpaid order
    }

    /// N-05, the auditor's scenario: paid at minute 25, the LP does not prove and tries to reclaim at
    /// minute 30 plus a second. It cannot, and the taker's proof - made by anyone - still settles.
    function test_N05_AnLpThatDoesNotProveCannotReclaimBeforeTheGraceEnds() public {
        bytes32 offerId = _postOffer(10 ether);
        bytes32 orderId = _lock(offerId, 1 ether);
        (,,,,, uint64 payBy,,,,,) = _order(orderId);
        vm.warp(block.timestamp + 25 minutes);
        _goodProof(orderId, PRICE);
        vm.warp(payBy + 1);
        vm.prank(lp);
        vm.expectRevert(FiatEscrow.WindowStillOpen.selector);
        escrow.reclaimExpired(orderId);
        escrow.releaseWithProof(orderId, "");
    }

    /// The LP's own dispute is not windowed: it is the LP's liquidity, and its credit stays reserved.
    function test_AnLPMayStillDisputeAfterThePayWindow() public {
        bytes32 orderId = _lock(_postOffer(10 ether), 1 ether);
        (,,,,, uint64 payBy,,,,,) = _order(orderId);
        vm.warp(payBy + 1);
        vm.prank(lp);
        escrow.raiseDispute(orderId, "a reversal is being claimed");
        assertEq(escrow.disputeDeadline(orderId), uint64(block.timestamp + DISPUTE_TIMEOUT));
    }

    /// A boleto order's window is the issue deadline until the LP issues, then issue + three days.
    function test_ABoletoTakersDisputeWindowFollowsTheBoleto() public {
        bytes32 offerId = _boletoOffer();
        bytes32 unissued = _lockBoleto(offerId, 1 ether);
        (,,,,, uint64 issueBy,,,,,) = _order(unissued);
        vm.warp(issueBy + escrow.TAKER_GRACE() + 1);
        vm.prank(taker);
        vm.expectRevert(FiatEscrow.WindowExpired.selector);
        escrow.raiseDispute(unissued, "never issued");

        bytes32 issued = _lockBoleto(offerId, 1 ether);
        _issue(issued, BOLETO);
        (,,,,, uint64 payBy,,,,,) = _order(issued);
        assertEq(payBy, uint64(block.timestamp + 3 days));
        vm.warp(payBy);
        vm.prank(taker);
        escrow.raiseDispute(issued, "paid on Friday evening");
    }

    /// A taker's dispute expires after TAKER_DISPUTE_TIMEOUT, an LP's after DISPUTE_TIMEOUT, and
    /// `disputeDeadline` says which (zero before any dispute).
    function test_ATakersDisputeExpiresOnTheShortClockAnLPsOnTheLongOne() public {
        bytes32 offerId = _postOffer(10 ether);
        bytes32 byTaker = _lock(offerId, 1 ether);
        bytes32 byLP = _lock(offerId, 1 ether);
        assertEq(escrow.disputeDeadline(byTaker), 0, "never disputed");
        vm.prank(taker);
        escrow.raiseDispute(byTaker, "x");
        vm.prank(lp);
        escrow.raiseDispute(byLP, "y");
        uint64 short = uint64(block.timestamp + TAKER_DISPUTE_TIMEOUT);
        uint64 long = uint64(block.timestamp + DISPUTE_TIMEOUT);
        assertEq(escrow.disputeDeadline(byTaker), short);
        assertEq(escrow.disputeDeadline(byLP), long);

        vm.warp(short);
        uint256 before = lp.balance;
        escrow.expireDispute(byTaker);
        assertEq(lp.balance - before, 1 ether, "the taker's order, back to the LP after days, not a month");
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.DisputeStillOpen.selector, long));
        escrow.expireDispute(byLP);
        vm.warp(long);
        escrow.expireDispute(byLP);
    }

    /// The short clock still leaves a ruling room: at the shortest allowed taker timeout a RELEASE
    /// posted on the first day executes on the second, inside the deadline.
    function test_TheShortestTakerTimeoutStillTakesARuling() public {
        FiatEscrow fast = _escrowWith(3 days, MAX_VETTING_FEE_BPS);
        vm.prank(lp);
        bytes32 offerId = fast.postOffer{value: 1 ether}(
            address(0), 1 ether, PRICE, PIX, 0.01 ether, 1 ether, address(verifier), PIX_MASK
        );
        vm.prank(taker);
        bytes32 orderId = fast.lockOrder(offerId, 1 ether, FiatEscrow.Delivery.DIRECT, payout, 0);
        vm.prank(taker);
        fast.raiseDispute(orderId, "paid, the attestor is down");
        vm.warp(block.timestamp + 1 days); // the desk's day
        RulingLib.Ruling memory r = RulingLib.Ruling({
            orderId: orderId, outcome: "RELEASE", evidenceRoot: keccak256("e"), rationale: "paid",
            ruledAt: uint64(block.timestamp), byDefault: false
        });
        (uint8 v, bytes32 rr, bytes32 ss) = vm.sign(arbKey, _digestAt(r, address(fast)));
        _ruleAt(fast, orderId, r, abi.encodePacked(rr, ss, v));
        assertEq(payout.balance, 1 ether);
    }

    function test_TheTakerDisputeTimeoutIsBoundedAtDeployment() public {
        address ep = address(entrypoint);
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.BadDisputeTimeout.selector, 3 days - 1));
        new FiatEscrow(address(oracle), address(registry), ep, ep, 500, governor, DELAY, DISPUTE_TIMEOUT, 3 days - 1, MAX_VETTING_FEE_BPS);
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.BadDisputeTimeout.selector, 7 days + 1));
        new FiatEscrow(address(oracle), address(registry), ep, ep, 500, governor, DELAY, DISPUTE_TIMEOUT, 7 days + 1, MAX_VETTING_FEE_BPS);
        assertEq(_escrowWith(3 days, 0).TAKER_DISPUTE_TIMEOUT(), 3 days);
        assertEq(_escrowWith(7 days, 0).TAKER_DISPUTE_TIMEOUT(), 7 days);
    }

    /// A configured escrow beside the suite's, with its own taker timeout and fee cap.
    function _escrowWith(uint256 takerTimeout, uint256 feeCap) internal returns (FiatEscrow e) {
        e = new FiatEscrow(
            address(oracle), address(registry), address(entrypoint), address(entrypoint), 500, governor, DELAY,
            DISPUTE_TIMEOUT, takerTimeout, feeCap
        );
        vm.startPrank(governor);
        e.setVerifier(address(verifier), true);
        e.setArbitrator(vm.addr(arbKey), true);
        e.completeSetup();
        vm.stopPrank();
        _afterDelay(address(registry), abi.encodeCall(LPRegistry.setEscrow, (address(e), true)));
    }

    /*//////////////////////////////////////////////////////////////
                    THE VETTING FEE IS CAPPED (H-02), IN ETH
    //////////////////////////////////////////////////////////////*/

    /// Native ETH, shielded: a fee raised after the lock is never paid. A RELEASE ruling, like a
    /// proof, delivers the whole amount in the open instead of reverting or depositing.
    function test_AShieldedEthOrderIsDeliveredDirectWhenTheFeeRoseBeforeTheRuling() public {
        bytes32 offerId = _postOffer(10 ether);
        vm.prank(taker);
        bytes32 orderId = escrow.lockOrder(offerId, 1 ether, FiatEscrow.Delivery.SHIELDED, payout, 4242);
        vm.prank(taker);
        escrow.raiseDispute(orderId, "paid; attestor down");
        entrypoint.setFee(MAX_VETTING_FEE_BPS + 1);
        (RulingLib.Ruling memory r, bytes memory sig) = _ruling(orderId, "RELEASE");
        _rule(orderId, r, sig);
        assertEq(payout.balance, 1 ether, "all of it, to the rescue address");
        assertEq(entrypoint.received(), 0, "nothing deposited, no fee paid");
        assertEq(escrow.labelOfOrder(orderId), 0);
    }

    function test_AShieldedEthLockIsRefusedAboveTheCap() public {
        bytes32 offerId = _postOffer(10 ether);
        entrypoint.setFee(MAX_VETTING_FEE_BPS + 1);
        vm.prank(taker);
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.VettingFeeAboveCap.selector, MAX_VETTING_FEE_BPS + 1));
        escrow.lockOrder(offerId, 1 ether, FiatEscrow.Delivery.SHIELDED, payout, 4242);
    }

    /// Stands in for boletoCommitment(barcode, salt); the escrow only ever compares it.
    bytes32 constant BOLETO = keccak256("boleto 00190.00009 ... for this order, salted");

    function _boletoOffer() internal returns (bytes32) {
        vm.prank(lp);
        return escrow.postOffer{value: 10 ether}(
            address(0), 10 ether, PRICE, PIX, 0.01 ether, 5 ether, address(verifier), PIX_MASK | BOLETO_MASK
        );
    }

    function _lockBoleto(bytes32 offerId, uint256 amount) internal returns (bytes32) {
        vm.prank(taker);
        return escrow.lockOrderByBoleto(offerId, amount, FiatEscrow.Delivery.DIRECT, payout, 0);
    }

    function _issue(bytes32 orderId, bytes32 commitment) internal {
        vm.prank(lp);
        escrow.issueBoleto(orderId, commitment);
    }

    function _boletoProof(bytes32 orderId, bytes32 payee, uint256 cents, IAttestorVerifier.Rail rail, uint64 paidAt)
        internal
    {
        verifier.setProof(
            orderId,
            MockVerifier.Canned({
                bankTxId: keccak256(abi.encode(orderId, payee, cents, rail, paidAt)),
                payeeKeyHash: payee,
                amountBrlCents: cents,
                paidAt: paidAt,
                rail: rail,
                bound: true
            })
        );
    }

    function test_OnRampByBoleto_LockIssuePayRelease() public {
        bytes32 offerId = _boletoOffer();
        bytes32 orderId = _lockBoleto(offerId, 1 ether);
        (uint64 issueBy,,) = escrow.boletoOf(orderId);
        assertEq(issueBy, block.timestamp + 1 hours, "BOLETO_ISSUE_WINDOW");
        (,,,,, uint64 payBy,,,,,) = _order(orderId);
        assertEq(payBy, issueBy, "until issue, the only deadline is the LP's");

        vm.warp(block.timestamp + 10 minutes);
        _issue(orderId, BOLETO);
        (, uint64 issuedAt, bytes32 commitment) = escrow.boletoOf(orderId);
        assertEq(commitment, BOLETO);
        (,,,,, payBy,,,,,) = _order(orderId);
        assertEq(payBy, issuedAt + 3 days, "BOLETO_PAY_WINDOW");

        // Paid on a Friday night, attested on Monday: the rail is slow, the proof still counts.
        vm.warp(block.timestamp + 1 hours);
        uint64 paidAt = uint64(block.timestamp);
        vm.warp(block.timestamp + 2 days + 12 hours);
        _boletoProof(orderId, BOLETO, PRICE, IAttestorVerifier.Rail.BOLETO, paidAt);
        escrow.releaseWithProof(orderId, "");
        assertEq(payout.balance, 1 ether);
    }

    function test_ABoletoOrderCannotReleaseBeforeTheLPIssues() public {
        bytes32 orderId = _lockBoleto(_boletoOffer(), 1 ether);
        _boletoProof(orderId, BOLETO, PRICE, IAttestorVerifier.Rail.BOLETO, uint64(block.timestamp));
        vm.expectRevert(FiatEscrow.BoletoNotIssued.selector);
        escrow.releaseWithProof(orderId, "");
    }

    /// Paying a different boleto - another order's, or any bill - settles nothing here.
    function test_APaymentOfADifferentBoletoIsRefused() public {
        bytes32 offerId = _boletoOffer();
        bytes32 a = _lockBoleto(offerId, 1 ether);
        bytes32 b = _lockBoleto(offerId, 1 ether);
        _issue(a, BOLETO);
        _issue(b, keccak256("order b's boleto"));
        // The genuine payment of A's boleto, presented against B.
        _boletoProof(b, BOLETO, PRICE, IAttestorVerifier.Rail.BOLETO, uint64(block.timestamp));
        vm.expectRevert(FiatEscrow.WrongPayee.selector);
        escrow.releaseWithProof(b, "");
    }

    /// And a proof bound to one order is not a proof for another, whatever it contains.
    function test_ABoletoProofBoundToAnotherOrderIsRefused() public {
        bytes32 offerId = _boletoOffer();
        bytes32 a = _lockBoleto(offerId, 1 ether);
        bytes32 b = _lockBoleto(offerId, 1 ether);
        _issue(a, BOLETO);
        _issue(b, keccak256("order b's boleto"));
        _boletoProof(a, BOLETO, PRICE, IAttestorVerifier.Rail.BOLETO, uint64(block.timestamp));
        vm.expectRevert(bytes("proof not bound to this order"));
        escrow.releaseWithProof(b, "");
    }

    /// A boleto's amount is in its line: paying another amount is not paying that boleto.
    function test_ABoletoPaidForTheWrongAmountIsRefused() public {
        bytes32 orderId = _lockBoleto(_boletoOffer(), 1 ether);
        _issue(orderId, BOLETO);
        _boletoProof(orderId, BOLETO, PRICE + 1, IAttestorVerifier.Rail.BOLETO, uint64(block.timestamp));
        vm.expectRevert(FiatEscrow.WrongAmount.selector);
        escrow.releaseWithProof(orderId, "");
        _boletoProof(orderId, BOLETO, PRICE - 1, IAttestorVerifier.Rail.BOLETO, uint64(block.timestamp));
        vm.expectRevert(FiatEscrow.Underpaid.selector);
        escrow.releaseWithProof(orderId, "");
    }

    /// A PIX transfer is not payment of a boleto, even one attested with the boleto's commitment.
    function test_APixProofCannotSettleABoletoOrder() public {
        bytes32 orderId = _lockBoleto(_boletoOffer(), 1 ether);
        _issue(orderId, BOLETO);
        _boletoProof(orderId, BOLETO, PRICE, IAttestorVerifier.Rail.PIX, uint64(block.timestamp));
        vm.expectRevert(FiatEscrow.RailNotAccepted.selector);
        escrow.releaseWithProof(orderId, "");
    }

    /// ...and a "boleto" paid to the offer's PIX key cannot settle a PIX order.
    function test_ABoletoProofCannotSettleAPixOrder() public {
        bytes32 orderId = _lock(_boletoOffer(), 1 ether);
        _boletoProof(orderId, PIX, PRICE, IAttestorVerifier.Rail.BOLETO, uint64(block.timestamp));
        vm.expectRevert(FiatEscrow.RailNotAccepted.selector);
        escrow.releaseWithProof(orderId, "");
    }

    /// A receipt from before the boleto existed cannot be paying it.
    function test_APaymentBeforeTheBoletoWasIssuedIsRefused() public {
        bytes32 orderId = _lockBoleto(_boletoOffer(), 1 ether);
        uint64 early = uint64(block.timestamp);
        vm.warp(block.timestamp + 5 minutes);
        _issue(orderId, BOLETO);
        _boletoProof(orderId, BOLETO, PRICE, IAttestorVerifier.Rail.BOLETO, early);
        vm.expectRevert(FiatEscrow.ReceiptPredatesOrder.selector);
        escrow.releaseWithProof(orderId, "");
    }

    /// Only the offer's LP issues, once, in time; one boleto never serves two orders.
    function test_IssuingIsTheLPsAloneOnceInTimeAndUnique() public {
        bytes32 offerId = _boletoOffer();
        bytes32 a = _lockBoleto(offerId, 1 ether);
        bytes32 b = _lockBoleto(offerId, 1 ether);
        vm.prank(taker);
        vm.expectRevert(FiatEscrow.NotLP.selector);
        escrow.issueBoleto(a, BOLETO);
        vm.prank(lp);
        vm.expectRevert(FiatEscrow.BadBoleto.selector);
        escrow.issueBoleto(a, bytes32(0));

        _issue(a, BOLETO);
        vm.prank(lp);
        vm.expectRevert(FiatEscrow.WrongState.selector);
        escrow.issueBoleto(a, keccak256("a second boleto"));
        vm.prank(lp);
        vm.expectRevert(FiatEscrow.BadBoleto.selector);
        escrow.issueBoleto(b, BOLETO);

        // A PIX order has no boleto to issue.
        bytes32 pixOrder = _lock(offerId, 1 ether);
        vm.prank(lp);
        vm.expectRevert(FiatEscrow.WrongState.selector);
        escrow.issueBoleto(pixOrder, keccak256("x"));
    }

    /// An LP that never issues costs the taker nothing and strands nothing.
    function test_AnLPThatNeverIssuesLosesTheOrderAndTheTakerLosesNothing() public {
        bytes32 offerId = _boletoOffer();
        bytes32 orderId = _lockBoleto(offerId, 1 ether);
        vm.warp(block.timestamp + 1 hours + 1);
        vm.prank(lp);
        vm.expectRevert(FiatEscrow.WindowExpired.selector);
        escrow.issueBoleto(orderId, BOLETO);
        vm.warp(block.timestamp + escrow.TAKER_GRACE());
        vm.prank(address(0xBEEF));
        escrow.reclaimExpired(orderId);
        (,, uint256 available,,,,,,,,,) = escrow.offers(offerId);
        assertEq(available, 10 ether);

        // And a taker who gives up earlier simply cancels, before or after issue.
        bytes32 again = _lockBoleto(offerId, 1 ether);
        _issue(again, BOLETO);
        vm.prank(taker);
        escrow.cancelOrder(again);
    }

    function test_BoletoOrdersNeedAnLPThatTakesBoletos() public {
        bytes32 pixOnly = _postOffer(10 ether);
        vm.prank(taker);
        vm.expectRevert(FiatEscrow.RailNotAccepted.selector);
        escrow.lockOrderByBoleto(pixOnly, 1 ether, FiatEscrow.Delivery.DIRECT, payout, 0);

        // A boleto-only LP needs no PIX key, and takes no PIX orders.
        vm.prank(lp);
        bytes32 boletoOnly = escrow.postOffer{value: 1 ether}(
            address(0), 1 ether, PRICE, bytes32(0), 0.01 ether, 1 ether, address(verifier), BOLETO_MASK
        );
        vm.prank(taker);
        vm.expectRevert(FiatEscrow.RailNotAccepted.selector);
        escrow.lockOrder(boletoOnly, 0.5 ether, FiatEscrow.Delivery.DIRECT, payout, 0);
        _lockBoleto(boletoOnly, 0.5 ether);

        // Any other rail still needs a key.
        vm.prank(lp);
        vm.expectRevert(FiatEscrow.BadOffer.selector);
        escrow.postOffer{value: 1 ether}(
            address(0), 1 ether, PRICE, bytes32(0), 0.01 ether, 1 ether, address(verifier), BOLETO_MASK | PIX_MASK
        );
    }

    /*//////////////////////////////////////////////////////////////
                             LP REGISTRY
    //////////////////////////////////////////////////////////////*/

    function test_UnregisteredLPCannotQuote() public {
        address stranger = address(0xBEEF);
        vm.deal(stranger, 1 ether);
        vm.prank(stranger);
        vm.expectRevert(FiatEscrow.LPNotEligible.selector);
        escrow.postOffer{value: 1 ether}(address(0), 1 ether, PRICE, PIX, 0.01 ether, 1 ether, address(verifier), PIX_MASK);
    }

    function test_RetailCapGrowsWithSettledVolume() public {
        assertEq(registry.capOf(retail), 500_000, "new LP starts at the base cap: R$5,000");

        vm.prank(retail);
        bytes32 offerId = escrow.postOffer{value: 0.1 ether}(
            address(0), 0.1 ether, PRICE, PIX, 0.01 ether, 0.1 ether, address(verifier), PIX_MASK
        );
        bytes32 orderId = _lock(offerId, 0.1 ether);
        _goodProof(orderId, PRICE / 10);
        escrow.releaseWithProof(orderId, "");

        // Settled R$3,000 (0.1 ETH at the test price) raises the cap by 20% of that.
        assertEq(
            registry.capOf(retail), 500_000 + (300_000 * 2_000) / 10_000,
            "settling raises the cap by 20% of the BRL value settled"
        );
    }

    /*//////////////////////////////////////////////////////////////
                                HELPERS
    //////////////////////////////////////////////////////////////*/

    function _order(bytes32 id)
        internal
        view
        returns (
            bytes32 offerId,
            address taker_,
            uint256 weiAmount,
            uint256 brlCents,
            uint64 lockedAt,
            uint64 payBy,
            FiatEscrow.OrderState state,
            FiatEscrow.Delivery delivery,
            address recipient,
            uint256 precommitment,
            uint256 commitment
        )
    {
        return escrow.orders(id);
    }

    /*//////////////////////////////////////////////////////////////
          CONTRACT ARBITRATORS: THE 2-OF-3 SAFE RULES (SRM1-22)
    //////////////////////////////////////////////////////////////*/

    uint256[3] msKeys = [uint256(0x5AFE01), 0x5AFE02, 0x5AFE03];

    function _multisig() internal returns (Multisig1271 ms) {
        address[] memory owners = new address[](3);
        for (uint256 i; i < 3; i++) owners[i] = vm.addr(msKeys[i]);
        ms = new Multisig1271(owners, 2);
        _afterDelay(address(escrow), abi.encodeCall(FiatEscrow.setArbitrator, (address(ms), true)));
    }

    function _keys(uint256 a, uint256 b) internal pure returns (uint256[] memory k) {
        k = new uint256[](2);
        (k[0], k[1]) = (a, b);
    }

    function _disputedByTaker() internal returns (bytes32 orderId) {
        bytes32 offerId = _postOffer(10 ether);
        orderId = _lock(offerId, 1 ether);
        vm.prank(taker);
        escrow.raiseDispute(orderId, "paid, attestor down");
    }

    /// The custody plan's end state: the Safe is the arbitrator, the test key is gone, and two
    /// of three owners rule. One owner alone, or the old key, cannot.
    function test_AMultisigArbitratorRulesWithTwoOfThree() public {
        Multisig1271 ms = _multisig();
        vm.prank(governor);
        escrow.setArbitrator(vm.addr(arbKey), false); // revoking is instant
        bytes32 orderId = _disputedByTaker();
        (RulingLib.Ruling memory r, bytes memory eoaSig) = _ruling(orderId, "RELEASE");

        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.NotArbitrator.selector, vm.addr(arbKey)));
        escrow.resolveDispute(orderId, r, eoaSig);

        bytes memory sig = _multisigSig(address(ms), _digest(r), _keys(msKeys[0], msKeys[2]));
        vm.expectEmit(true, true, true, false, address(escrow));
        emit FiatEscrow.RulingPosted(orderId, true, address(ms), r.evidenceRoot, 0);
        escrow.resolveDispute(orderId, r, sig);
        vm.warp(block.timestamp + 1 days);
        vm.prank(taker); // anyone may submit, the favoured party included
        escrow.resolveDispute(orderId, r, sig);
        assertEq(payout.balance, 1 ether, "released on the multisig's ruling");
    }

    function test_OneMultisigOwnerAloneIsNoArbitrator() public {
        Multisig1271 ms = _multisig();
        bytes32 orderId = _disputedByTaker();
        (RulingLib.Ruling memory r,) = _ruling(orderId, "RELEASE");
        uint256[] memory one = new uint256[](1);
        one[0] = msKeys[1];
        bytes memory sig = _multisigSig(address(ms), _digest(r), one);
        vm.expectRevert(abi.encodeWithSelector(RulingLib.ContractSignatureRejected.selector, address(ms)));
        escrow.resolveDispute(orderId, r, sig);

        // Nor an owner's own key, as an ECDSA arbitrator: it was never registered.
        (uint8 v, bytes32 rr, bytes32 ss) = vm.sign(msKeys[1], _digest(r));
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.NotArbitrator.selector, vm.addr(msKeys[1])));
        escrow.resolveDispute(orderId, r, abi.encodePacked(rr, ss, v));

        // Two signatures from the same owner are one owner.
        sig = _multisigSig(address(ms), _digest(r), _keys(msKeys[1], msKeys[1]));
        vm.expectRevert(abi.encodeWithSelector(RulingLib.ContractSignatureRejected.selector, address(ms)));
        escrow.resolveDispute(orderId, r, sig);
    }

    /// Owners approve one exact ruling: the submitter cannot flip it, and an approval for one
    /// escrow is not one for another.
    function test_AMultisigApprovalCoversOneRulingOnOneEscrow() public {
        Multisig1271 ms = _multisig();
        bytes32 orderId = _disputedByTaker();
        (RulingLib.Ruling memory r,) = _ruling(orderId, "REFUND");
        bytes memory sig = _multisigSig(address(ms), _digest(r), _keys(msKeys[0], msKeys[1]));
        r.outcome = "RELEASE";
        vm.expectRevert(abi.encodeWithSelector(RulingLib.ContractSignatureRejected.selector, address(ms)));
        escrow.resolveDispute(orderId, r, sig);

        r.outcome = "REFUND";
        bytes memory elsewhere = _multisigSig(address(ms), _digestAt(r, address(0xE5C2)), _keys(msKeys[0], msKeys[1]));
        vm.expectRevert(abi.encodeWithSelector(RulingLib.ContractSignatureRejected.selector, address(ms)));
        escrow.resolveDispute(orderId, r, elsewhere);
    }

    /// Naming a contract proves nothing by itself: it must be registered, and must say yes.
    function test_ANamedContractMustBeRegisteredAndMustApprove() public {
        bytes32 orderId = _disputedByTaker();
        (RulingLib.Ruling memory r,) = _ruling(orderId, "RELEASE");

        YesMan1271 yes = new YesMan1271();
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.NotArbitrator.selector, address(yes)));
        escrow.resolveDispute(orderId, r, abi.encodePacked(address(yes), hex"00"));

        // A registered key's address with a contract-style signature: there is no code to ask.
        vm.expectRevert(RulingLib.MalformedSignature.selector);
        escrow.resolveDispute(orderId, r, abi.encodePacked(vm.addr(arbKey), new bytes(65)));

        // An address and nothing after it.
        vm.expectRevert(RulingLib.MalformedSignature.selector);
        escrow.resolveDispute(orderId, r, abi.encodePacked(address(yes)));

        Bad1271 bad = new Bad1271();
        _afterDelay(address(escrow), abi.encodeCall(FiatEscrow.setArbitrator, (address(bad), true)));
        for (uint8 m; m < 3; m++) {
            bad.setMode(m); // reverts; returns four bytes; returns the legacy magic
            vm.expectRevert(abi.encodeWithSelector(RulingLib.ContractSignatureRejected.selector, address(bad)));
            escrow.resolveDispute(orderId, r, abi.encodePacked(address(bad), hex"01"));
        }
    }

    /// A contract arbitrator gets no more power than a key: one registered after a dispute can
    /// still only refund it, so the hostage attack is closed for the Safe as well.
    function test_AMultisigNewerThanTheDisputeCanOnlyRefund() public {
        bytes32 orderId = _disputedByTaker();
        Multisig1271 ms = _multisig();
        (RulingLib.Ruling memory r,) = _ruling(orderId, "RELEASE");
        bytes memory sig = _multisigSig(address(ms), _digest(r), _keys(msKeys[0], msKeys[1]));
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.ArbitratorNewerThanDispute.selector, address(ms)));
        escrow.resolveDispute(orderId, r, sig);

        (RulingLib.Ruling memory refund,) = _ruling(orderId, "REFUND");
        _rule(orderId, refund, _multisigSig(address(ms), _digest(refund), _keys(msKeys[1], msKeys[2])));
        assertEq(payout.balance, 0, "nothing to the taker");
    }

    /// A posted multisig ruling dies with its registration, exactly as a key's does.
    function test_RevokingTheMultisigVoidsItsPostedRuling() public {
        Multisig1271 ms = _multisig();
        bytes32 orderId = _disputedByTaker();
        (RulingLib.Ruling memory r,) = _ruling(orderId, "RELEASE");
        bytes memory sig = _multisigSig(address(ms), _digest(r), _keys(msKeys[0], msKeys[1]));
        escrow.resolveDispute(orderId, r, sig);
        vm.prank(governor);
        escrow.setArbitrator(address(ms), false);
        vm.warp(block.timestamp + 1 days);
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.NotArbitrator.selector, address(ms)));
        escrow.resolveDispute(orderId, r, sig);
    }

    /*//////////////////////////////////////////////////////////////
       A SUSPENDED LP'S STANDING OFFERS STOP, AND ANYONE CAN CLOSE THEM
    //////////////////////////////////////////////////////////////*/

    function _suspend(address who) internal {
        vm.prank(governor);
        registry.setTier(who, LPRegistry.Tier.SUSPENDED, 0); // instant: it only lowers risk
    }

    /// The offer's credit was reserved when it was posted, so before this a suspension stopped only
    /// NEW offers: takers could still lock against the suspended LP's standing ones.
    function test_ASuspendedLPsStandingOfferTakesNoNewOrders() public {
        bytes32 offerId = _postOffer(10 ether);
        bytes32 before = _lock(offerId, 1 ether); // locked while the LP was in good standing
        _suspend(lp);

        vm.prank(taker);
        vm.expectRevert(FiatEscrow.LPNotEligible.selector);
        escrow.lockOrder(offerId, 1 ether, FiatEscrow.Delivery.DIRECT, payout, 0);

        // What was already locked still settles: the taker who paid is paid.
        _goodProof(before, PRICE);
        escrow.releaseWithProof(before, "");
        assertEq(payout.balance, 1 ether);
    }

    function test_AnyoneClosesASuspendedLPsOfferAndTheFundsGoToTheLP() public {
        bytes32 offerId = _postOffer(10 ether);
        _suspend(lp);
        address stranger = makeAddr("stranger");
        uint256 lpBefore = lp.balance;
        vm.prank(stranger);
        escrow.closeOffer(offerId);
        assertEq(lp.balance - lpBefore, 10 ether, "every wei back to the LP");
        assertEq(stranger.balance, 0, "nothing to the caller");
        (,,,,,, uint256 exposure) = registry.lps(lp);
        assertEq(exposure, 0, "the LP's credit is released");
    }

    function test_NobodyButTheLPClosesACreditedLPsOfferOrAnOfferThatDoesNotExist() public {
        bytes32 offerId = _postOffer(10 ether);
        address stranger = makeAddr("stranger");
        vm.prank(stranger);
        vm.expectRevert(FiatEscrow.NotLP.selector);
        escrow.closeOffer(offerId);
        vm.prank(stranger);
        vm.expectRevert(FiatEscrow.NotLP.selector);
        escrow.closeOffer(keccak256("no such offer"));
    }

    /// An affiliate draws on its sponsor's credit, so suspending the sponsor stops the affiliate's
    /// standing offers too (`capOf` is zero for it).
    function test_SuspendingASponsorStopsItsAffiliatesStandingOffers() public {
        address aff = makeAddr("affiliate");
        vm.prank(lp); // setUp opened Phase C, so sponsoring is open
        registry.sponsorAffiliate(aff, 100_000_00);
        vm.deal(aff, 10 ether);
        vm.prank(aff);
        bytes32 offerId = escrow.postOffer{value: 1 ether}(
            address(0), 1 ether, PRICE, PIX, 0.01 ether, 1 ether, address(verifier), PIX_MASK
        );
        _suspend(lp);
        vm.prank(taker);
        vm.expectRevert(FiatEscrow.LPNotEligible.selector);
        escrow.lockOrder(offerId, 0.5 ether, FiatEscrow.Delivery.DIRECT, payout, 0);
    }
}
