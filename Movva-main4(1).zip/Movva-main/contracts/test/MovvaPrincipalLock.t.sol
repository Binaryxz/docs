// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {MovvaBase} from "./MovvaReserve.t.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {YieldVault} from "../yield/YieldVault.sol";
import {MovvaReserve} from "../movva/MovvaReserve.sol";
import {IMovvaReserve} from "../movva/IMovvaReserve.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";

/**
 * The principal-locked reserve (client rule, 21 October 2026), rule by rule:
 *
 *  1. The USDT backing leaves only by redemption, and only a gateway (the off-ramp's LP) redeems. No
 *     role - governor, guardian, gateway, fee or yield recipient - can move it any other way, and the
 *     hedge path that could (withdrawToHedge, its queue and limit, the treasurer, the hedge treasury)
 *     is gone.
 *  2. The principal is invested in the delayed, client-chosen ERC-4626 vault; switching vaults only
 *     ever moves USDT between the vault and the reserve.
 *  3. Only the yield leaves, only to `yieldRecipient`: `harvestYield` pays
 *     totalUsdt - max(principalUsdt, ceil(liabilitiesUsdt x target)), and the recipient changes only
 *     through the delay, both ways.
 *  4. `recapitalize` is principal.
 *
 * The invariant suite is MovvaPrincipalLockInvariant.t.sol.
 */
contract MovvaPrincipalLockTest is MovvaBase {
    address user = makeAddr("user selling Movva on the off-ramp");

    /// Interest, as the vault's own income: a donation of USDT to it raises every share.
    function _earn(uint256 amount) internal {
        usdt.mint(address(vault), amount);
    }

    /// Every USDT the reserve controls, raw: idle (frozen or not) and its vault position.
    function _assets() internal view returns (uint256) {
        return usdt.balanceOf(address(reserve)) + vault.previewRedeem(vault.balanceOf(address(reserve)));
    }

    /// The harvest floor, from first principles: max(principal, supply x target / rate), rounded up.
    function _floor() internal view returns (uint256 f) {
        uint256 rate = _rate();
        f = (movva.totalSupply() * reserve.targetCollateralRatioBps() * 1e6 + rate * 10_000 - 1) / (rate * 10_000);
        if (reserve.principalUsdt() > f) f = reserve.principalUsdt();
    }

    /*//////////////////////////////////////////////////////////////
               RULE 1: NO EXIT BUT REDEMPTION (AND HARVEST)
    //////////////////////////////////////////////////////////////*/

    /// Each removed entry point falls through the dispatcher: it reverts with no data, where an existing
    /// function would answer or refuse with a named error.
    function test_TheHedgePathIsGone() public {
        bytes[18] memory gone = [
            abi.encodeWithSignature("withdrawToHedge(uint256)", 1),
            abi.encodeWithSignature("queueHedgeWithdrawal(uint256)", 1),
            abi.encodeWithSignature("executeHedgeWithdrawal(uint256)", 0),
            abi.encodeWithSignature("hedgeWithdrawable()"),
            abi.encodeWithSignature("hedgeLimitBps()"),
            abi.encodeWithSignature("hedgeUsed()"),
            abi.encodeWithSignature("hedgeUsedAt()"),
            abi.encodeWithSignature("hedgeRequests(uint256)", 0),
            abi.encodeWithSignature("hedgeRequestCount()"),
            abi.encodeWithSignature("HEDGE_QUEUE_DELAY()"),
            abi.encodeWithSignature("minWithdrawCollateralRatioBps()"),
            abi.encodeWithSignature("treasurer()"),
            abi.encodeWithSignature("hedgeTreasury()"),
            abi.encodeWithSignature("setTreasurer(address)", gov),
            abi.encodeWithSignature("setHedgeTreasury(address)", gov),
            abi.encodeWithSignature("setLimits(uint256,uint16)", 0, 0),
            abi.encodeWithSignature("sweep(address)", address(usdt)),
            abi.encodeWithSignature("rescue(address,address,uint256)", address(usdt), gov, 1)
        ];
        for (uint256 i; i < gone.length; ++i) {
            vm.prank(gov);
            (bool ok, bytes memory ret) = address(reserve).call(gone[i]);
            assertFalse(ok, "a removed function answered");
            assertEq(ret.length, 0, "a removed function answered");
        }
    }

    /**
     * Every role, and a stranger, tries every function that is not mint, redeem, recapitalize or
     * harvest, aimed at itself: the reserve's USDT stays put, and nobody ends with a USDT more. What
     * the governor CAN do - pull the vault back into the reserve, pause deposits, drop an empty vault -
     * only moves USDT between the vault and the reserve.
     */
    function test_NoRoleCanMoveTheUsdt() public {
        _mint(1_000_000 * U);
        _earn(10_000 * U);
        uint256 before = _assets();
        address[6] memory who = [gov, guardian, gateway, feeTo, yieldTo, stranger];
        for (uint256 i; i < who.length; ++i) {
            address a = who[i];
            uint256 had = usdt.balanceOf(a);
            bytes[12] memory calls = [
                abi.encodeCall(MovvaReserve.pullFromVault, (type(uint256).max)),
                abi.encodeCall(MovvaReserve.pullFromVault, (1_000 * U)),
                abi.encodeCall(MovvaReserve.setVaultDepositsPaused, (true)),
                abi.encodeCall(MovvaReserve.setYieldVault, (address(0))),
                abi.encodeCall(MovvaReserve.setYieldVault, (a)),
                abi.encodeCall(MovvaReserve.setYieldRecipient, (a)),
                abi.encodeCall(MovvaReserve.setFeeRecipient, (a)),
                abi.encodeCall(MovvaReserve.setGateway, (a, true)),
                abi.encodeCall(MovvaReserve.setGuardian, (a)),
                abi.encodeCall(MovvaReserve.pauseMint, ()),
                abi.encodeCall(DelayedGovernance.schedule, (abi.encodeCall(MovvaReserve.setYieldVault, (a)))),
                abi.encodeCall(DelayedGovernance.transferGovernor, (a))
            ];
            for (uint256 j; j < calls.length; ++j) {
                vm.prank(a);
                (bool ok,) = address(reserve).call(calls[j]);
                ok; // some are allowed (the governor's instant brakes); none may pay anyone
                assertApproxEqAbs(_assets(), before, 2, "the reserve's USDT moved");
                assertEq(usdt.balanceOf(a), had, "a role was paid");
            }
        }
        // The governor's pull left everything in the reserve itself, idle.
        assertApproxEqAbs(usdt.balanceOf(address(reserve)), before, 2, "pulled back into the reserve, not out of it");
    }

    /**
     * The user story. A user holds Movva and sells it for reais on the off-ramp; the escrow pays the
     * Movva to the LP that paid the PIX (here, a plain transfer stands in for OffRampEscrow's release),
     * and the LP - a gateway - redeems it. Nobody else can redeem, holder or governor.
     */
    function test_RedeemIsGatewayOnly_TheOffRampLpRedeems() public {
        vm.prank(gateway);
        uint256 movvaOut = reserve.mint(10_000 * U, user, 0);
        vm.roll(block.number + 1); // one block between a mint and a redemption (N-06)
        address[3] memory notGateways = [user, gov, stranger];
        for (uint256 i; i < notGateways.length; ++i) {
            vm.startPrank(notGateways[i]);
            movva.approve(address(reserve), type(uint256).max);
            vm.expectRevert(MovvaReserve.NotGateway.selector);
            reserve.redeem(1e18, notGateways[i], 0);
            vm.stopPrank();
        }
        vm.prank(user);
        movva.transfer(gateway, movvaOut); // the off-ramp settles: the Movva reaches the LP
        uint256 lpBefore = usdt.balanceOf(gateway);
        uint256 paid = _redeem(movvaOut);
        assertEq(usdt.balanceOf(gateway) - lpBefore, paid, "the LP is paid in USDT");
        assertApproxEqAbs(paid, 10_000 * U, 1);
        assertEq(reserve.principalUsdt(), 10_000 * U - paid, "the principal leaves with the redemption");
        assertEq(movva.totalSupply(), 0);
    }

    /*//////////////////////////////////////////////////////////////
                          PRINCIPAL ACCOUNTING
    //////////////////////////////////////////////////////////////*/

    function test_PrincipalIsMintPlusRecapitalizeLessRedeem() public {
        assertEq(reserve.principalUsdt(), 0);
        _mint(1_000_000 * U);
        assertEq(reserve.principalUsdt(), 1_000_000 * U, "a mint's USDT is principal");
        _fund(stranger, 50_000 * U);
        vm.prank(stranger);
        reserve.recapitalize(50_000 * U);
        assertEq(reserve.principalUsdt(), 1_050_000 * U, "a recapitalization raises it");
        uint256 paid = _redeem(540_000e18);
        assertEq(paid, 100_000 * U);
        assertEq(reserve.principalUsdt(), 950_000 * U, "a redemption lowers it by what it paid");
        assertEq(reserve.harvestableYield(), 0, "none of it is yield");
    }

    /// Redemptions can pay out more than came in - yield, then a real that strengthened - and the basis
    /// stops at zero instead of underflowing.
    function test_ThePrincipalFloorsAtZero() public {
        _mint(1_000 * U);
        _earn(100 * U);
        _publishFx(4_500_000); // par is now 1,200 USDT for the 5,400 Movva: pro rata pays all 1,100
        uint256 paid = _redeem(movva.balanceOf(gateway));
        assertApproxEqAbs(paid, 1_100 * U, 1);
        assertEq(reserve.principalUsdt(), 0);
    }

    function test_RecapitalizeRaisesPrincipalAndIsNeverHarvestable() public {
        _mint(1_000_000 * U);
        _fund(stranger, 500_000 * U);
        vm.prank(stranger);
        reserve.recapitalize(500_000 * U);
        assertEq(reserve.principalUsdt(), 1_500_000 * U);
        assertEq(reserve.harvestableYield(), 0, "Mova's top-up is backing, not yield");
        vm.expectRevert(MovvaReserve.NothingToHarvest.selector);
        reserve.harvestYield();
    }

    /*//////////////////////////////////////////////////////////////
                    RULE 3: ONLY THE YIELD, ONLY TO MOVA
    //////////////////////////////////////////////////////////////*/

    /// Over-collateralised by Mova's top-up: the principal is the binding floor, and exactly the
    /// vault's income leaves - to the yield recipient, whoever calls.
    function test_HarvestPaysOnlyTheYieldAboveThePrincipal() public {
        _mint(1_000_000 * U);
        _fund(stranger, 200_000 * U);
        vm.prank(stranger);
        reserve.recapitalize(200_000 * U); // 120%: the principal (1,200,000) is above the target's 1,080,000
        _earn(5_000 * U);
        uint256 h = reserve.harvestableYield();
        assertApproxEqAbs(h, 5_000 * U, 1, "the income, and only the income");
        assertEq(_floor(), 1_200_000 * U, "the principal binds");

        uint256 strangerHad = usdt.balanceOf(stranger);
        vm.expectEmit(address(reserve));
        emit IMovvaReserve.YieldHarvested(yieldTo, h, 1_200_000 * U, stranger);
        vm.prank(stranger);
        uint256 paid = reserve.harvestYield();
        assertEq(paid, h);
        assertEq(usdt.balanceOf(yieldTo), paid, "to the yield recipient");
        assertEq(usdt.balanceOf(stranger), strangerHad, "not to the caller");
        assertGe(reserve.totalUsdt(), reserve.principalUsdt(), "never into the principal");
        assertEq(reserve.principalUsdt(), 1_200_000 * U, "a harvest does not touch the basis");
        assertEq(reserve.harvestableYield(), 0);
    }

    /// At 100%, the target is the binding floor: income first restores the 8% buffer, and only what
    /// is above the target's liabilities leaves.
    function test_HarvestNeverTakesTheReserveBelowTheTarget() public {
        _mint(1_000_000 * U); // 100%: the target needs 1,080,000
        _earn(50_000 * U);
        assertEq(reserve.harvestableYield(), 0, "under target, the yield stays as backing");
        _earn(50_000 * U); // 1,100,000
        uint256 h = reserve.harvestableYield();
        assertApproxEqAbs(h, 20_000 * U, 1, "only above 108%");
        vm.prank(stranger);
        reserve.harvestYield();
        assertGe(reserve.collateralRatioBps(), 10_800, "left at the target");
        assertGe(reserve.totalUsdt(), _floor());
    }

    /// Yield is there; then the real strengthens 5% and the liabilities, in dollars, grow past it.
    /// The harvest sends nothing: holders' cover comes first.
    function test_AfterAnFxMoveThatLowersCoverageTheHarvestSendsNothing() public {
        _mint(1_000_000 * U);
        _fund(stranger, 80_000 * U);
        vm.prank(stranger);
        reserve.recapitalize(80_000 * U);
        _earn(50_000 * U);
        assertGt(reserve.harvestableYield(), 49_000 * U, "harvestable before the move");
        _publishFx(5_130_000); // liabilities 1,052,632 USDT, x 108% = 1,136,842 > 1,130,000 held
        assertEq(reserve.harvestableYield(), 0);
        vm.expectRevert(MovvaReserve.NothingToHarvest.selector);
        reserve.harvestYield();
        assertEq(usdt.balanceOf(yieldTo), 0);
    }

    /// Everything sits in the vault: the harvest pulls what it needs into the reserve, then pays from
    /// there, and the reserve is left exactly at or above the floor.
    function test_HarvestPullsFromTheVault() public {
        _mint(1_000_000 * U);
        _fund(stranger, 200_000 * U);
        vm.prank(stranger);
        reserve.recapitalize(200_000 * U);
        assertEq(usdt.balanceOf(address(reserve)), 0, "nothing idle");
        _earn(7_000 * U);
        vm.prank(stranger);
        uint256 paid = reserve.harvestYield();
        assertApproxEqAbs(paid, 7_000 * U, 2);
        assertEq(usdt.balanceOf(yieldTo), paid);
        assertGe(reserve.totalUsdt(), _floor(), "the vault's rounding is the harvest's, not the floor's");
        assertLe(usdt.balanceOf(address(reserve)), 2, "it pulled no more than it paid");
    }

    function test_HarvestRefusals() public {
        _mint(1_000_000 * U);
        vm.expectRevert(MovvaReserve.NothingToHarvest.selector);
        reserve.harvestYield();
        _earn(200_000 * U);

        // A stale rate: nothing that prices anything runs.
        vm.warp(block.timestamp + FX_MAX_AGE + 1);
        vm.expectRevert();
        reserve.harvestYield();
        _warp(0);

        // A frozen yield recipient is not paid.
        usdt.addBlackList(yieldTo);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.FrozenByAssetIssuer.selector, yieldTo));
        reserve.harvestYield();
        usdt.removeBlackList(yieldTo);

        // A frozen reserve waits: pulling the vault into it would freeze a payable position.
        usdt.addBlackList(address(reserve));
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.FrozenByAssetIssuer.selector, address(reserve)));
        reserve.harvestYield();
        usdt.removeBlackList(address(reserve));

        vm.prank(stranger);
        assertGt(reserve.harvestYield(), 0);
    }

    function test_TheYieldRecipientChangesOnlyThroughTheDelay_BothWays() public {
        address mova2 = makeAddr("Mova's new Safe");
        // Away from the original: delayed.
        vm.prank(gov);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, MovvaReserve.setYieldRecipient.selector));
        reserve.setYieldRecipient(mova2);

        // While it waits, a harvest still pays the recipient of record.
        _mint(1_000_000 * U);
        _earn(100_000 * U);
        bytes memory call = abi.encodeCall(MovvaReserve.setYieldRecipient, (mova2));
        vm.prank(gov);
        reserve.schedule(call);
        reserve.harvestYield();
        assertGt(usdt.balanceOf(yieldTo), 0, "the recipient of record");
        assertEq(usdt.balanceOf(mova2), 0);
        vm.warp(block.timestamp + DELAY);
        vm.prank(gov);
        reserve.execute(call);
        assertEq(reserve.yieldRecipient(), mova2);

        // And back again: delayed too, as is re-setting the same address.
        address[2] memory to = [yieldTo, mova2];
        for (uint256 i; i < 2; ++i) {
            vm.prank(gov);
            vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, MovvaReserve.setYieldRecipient.selector));
            reserve.setYieldRecipient(to[i]);
        }
        _afterDelay(address(reserve), abi.encodeCall(MovvaReserve.setYieldRecipient, (yieldTo)));
        assertEq(reserve.yieldRecipient(), yieldTo);

        // Zero and the reserve itself are refused, through the delay.
        bytes[2] memory bad =
            [abi.encodeCall(MovvaReserve.setYieldRecipient, (address(0))), abi.encodeCall(MovvaReserve.setYieldRecipient, (address(reserve)))];
        for (uint256 i; i < 2; ++i) {
            vm.prank(gov);
            reserve.schedule(bad[i]);
        }
        vm.warp(block.timestamp + DELAY);
        vm.prank(gov);
        vm.expectRevert(DelayedGovernance.ZeroAddress.selector);
        reserve.execute(bad[0]);
        vm.prank(gov);
        vm.expectRevert(MovvaReserve.BadYieldRecipient.selector);
        reserve.execute(bad[1]);
    }

    function test_TheConstructorNeedsAYieldRecipientThatIsNotTheReserve() public {
        MovvaReserve.Config memory c = _config();
        c.yieldRecipient = vm.computeCreateAddress(address(this), vm.getNonce(address(this)));
        vm.expectRevert(MovvaReserve.BadYieldRecipient.selector);
        new MovvaReserve(c);
    }

    /*//////////////////////////////////////////////////////////////
                RULE 2: SWITCHING THE SOURCE KEEPS THE USDT
    //////////////////////////////////////////////////////////////*/

    function test_AVaultSwitchKeepsEveryUsdtInTheReserve() public {
        _mint(1_000_000 * U);
        _earn(1_000 * U);
        YieldVault next = new YieldVault(IERC20(address(usdt)), "Next", "nUSDT", gov, guardian, keeper, 1e15, 100, DELAY);
        vm.prank(gov);
        next.completeSetup();
        uint256 before = _assets();
        uint256 principal = reserve.principalUsdt();

        // The new source waits the delay, and is refused while the old one still holds the reserve's shares.
        vm.prank(gov);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, MovvaReserve.setYieldVault.selector));
        reserve.setYieldVault(address(next));
        bytes memory call = abi.encodeCall(MovvaReserve.setYieldVault, (address(next)));
        vm.prank(gov);
        reserve.schedule(call);
        vm.warp(block.timestamp + DELAY);
        vm.prank(gov);
        vm.expectRevert(MovvaReserve.VaultNotEmpty.selector);
        reserve.execute(call);

        // The way out of the old vault is back into the reserve: instant, and to nowhere else.
        vm.prank(gov);
        reserve.pullFromVault(type(uint256).max);
        assertEq(vault.balanceOf(address(reserve)), 0);
        assertEq(usdt.balanceOf(address(reserve)), before, "all of it, idle in the reserve");
        vm.prank(gov);
        reserve.execute(call); // the change scheduled above, still ready: the failed execution undid nothing
        assertEq(address(reserve.yieldVault()), address(next));

        // Deposits resume into the new source; the books never moved.
        vm.prank(gov);
        reserve.setVaultDepositsPaused(false);
        _fund(stranger, 1 * U);
        vm.prank(stranger);
        reserve.recapitalize(1 * U);
        assertEq(usdt.balanceOf(address(reserve)), 0, "into the new vault");
        assertApproxEqAbs(next.previewRedeem(next.balanceOf(address(reserve))), before + 1 * U, 1);
        assertEq(reserve.principalUsdt(), principal + 1 * U);
        assertEq(usdt.balanceOf(gov), 0, "the governor holds nothing");
    }

    /*//////////////////////////////////////////////////////////////
                                  FUZZ
    //////////////////////////////////////////////////////////////*/

    /**
     * Any mix of minting, topping up, income, a move in the real either way and a redemption: the
     * harvest pays exactly what the formula says - the excess over max(principal, the target's
     * liabilities), never more than the income above the principal - only to the yield recipient, and
     * leaves the reserve at or above that floor.
     */
    function testFuzz_HarvestTakesOnlyTheExcessAboveTheFloor(
        uint256 minted,
        uint256 topUp,
        uint256 earned,
        uint256 fxBps,
        bool up,
        uint256 redeemBps
    ) public {
        minted = bound(minted, 1 * U, 10_000_000 * U);
        topUp = bound(topUp, 0, 2_000_000 * U);
        earned = bound(earned, 0, 2_000_000 * U);
        fxBps = bound(fxBps, 0, 3_000);
        redeemBps = bound(redeemBps, 0, 10_000);

        _mint(minted);
        if (topUp != 0) {
            _fund(stranger, topUp);
            vm.prank(stranger);
            reserve.recapitalize(topUp);
        }
        _earn(earned);
        _publishFx(up ? (FX * (10_000 + fxBps)) / 10_000 : (FX * (10_000 - fxBps)) / 10_000);
        uint256 toRedeem = (movva.balanceOf(gateway) * redeemBps) / 10_000;
        if (toRedeem != 0) {
            vm.roll(block.number + 1); // a mint and a redemption never share a block (N-06)
            vm.prank(gateway);
            try reserve.redeem(toRedeem, gateway, 0) {} catch {}
        }

        uint256 total = reserve.totalUsdt();
        uint256 floor = _floor();
        uint256 expected = total > floor ? total - floor : 0;
        assertEq(reserve.harvestableYield(), expected, "the formula");
        assertLe(expected, total > reserve.principalUsdt() ? total - reserve.principalUsdt() : 0, "never the principal");

        uint256 strangerHad = usdt.balanceOf(stranger);
        vm.prank(stranger);
        try reserve.harvestYield() returns (uint256 paid) {
            assertLe(paid, expected, "no more than harvestable");
            assertApproxEqAbs(paid, expected, 2, "all of it, less at most the vault's rounding");
            assertEq(usdt.balanceOf(yieldTo), paid, "only the yield recipient");
            assertGe(reserve.totalUsdt(), _floor(), "never below max(principal, target)");
        } catch (bytes memory reason) {
            assertEq(bytes4(reason), MovvaReserve.NothingToHarvest.selector);
            assertLe(expected, 2, "refused only when there is nothing (or dust) to take");
            assertEq(reserve.totalUsdt(), total, "and nothing moved");
        }
        assertEq(usdt.balanceOf(stranger), strangerHad);
    }
}
