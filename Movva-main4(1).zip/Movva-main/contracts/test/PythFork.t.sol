// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import {PythBrlOracle, IPyth} from "../ramp/PythBrlOracle.sol";

/**
 * PythBrlOracle against the REAL Pyth contract, not a mock.
 *
 * The unit tests prove the arithmetic. They cannot prove that our vendored IPyth interface
 * matches the deployed one - a struct field reordered upstream decodes into garbage that
 * still typechecks, and a mock written from the same wrong assumption agrees with it.
 *
 * Skips cleanly without FORK_RPC so CI stays green without an archive node.
 *
 *   FORK_RPC=http://127.0.0.1:8545 forge test --match-contract PythFork
 */
contract PythForkTest is Test {
    address constant PYTH = 0x4305FB66699C3B2702D4d05CF36551390A4c69C6;
    bytes32 constant ETH_USD =
        0xff61491a931112ddf1bd8147cd1b641375f79f5825126d665480874634fd0ace;
    /**
     * @dev Pyth's `FX.USD/BRL` feed - BRL per one USD. Confirmed live on Hermes, updating
     *      on a 200ms channel. It is simply not PRESENT on Ethereum mainnet's Pyth
     *      contract: Pyth is pull-based, so a feed exists on a chain only once somebody has
     *      posted an update for it there. Nobody has, hence PriceFeedNotFound below.
     *
     *      That is an operational gap, not a missing feed - see the test at the end.
     */
    bytes32 constant USD_BRL =
        0xd2db4dbf1aea74e0f666b0e8f73b9580d407f5e5cf931940b06dc633d7a95906;

    bool forked;

    function setUp() public {
        string memory rpc = vm.envOr("FORK_RPC", string(""));
        if (bytes(rpc).length == 0) return;
        // FORK_BLOCK pins the block: one from before Mova's keeper first posts FX.USD/BRL keeps
        // test_NoBrlUsdFeedOnEthereumMainnet about the unposted feed (see its comment).
        uint256 blk = vm.envOr("FORK_BLOCK", uint256(0));
        if (blk == 0) vm.createSelectFork(rpc);
        else vm.createSelectFork(rpc, blk);
        forked = true;
    }

    /// Our interface decodes the deployed contract's return value correctly.
    function test_RealPythDecodesThroughOurInterface() public view {
        if (!forked) return;
        IPyth.Price memory p = IPyth(PYTH).getPriceNoOlderThan(ETH_USD, 365 days);
        assertGt(p.price, 0, "a real ETH/USD price came back");
        assertEq(p.expo, -8, "Pyth publishes ETH/USD with exponent -8");
        assertGt(p.publishTime, 0, "publishTime is populated");
        // Sanity, not precision: if the struct were misaligned this would be absurd.
        uint256 usd = uint256(uint64(p.price)) / 1e8;
        assertGt(usd, 100, "ETH is worth more than $100");
        assertLt(usd, 100_000, "ETH is worth less than $100,000");
    }

    /**
     * The finding that actually matters for deployment.
     *
     * The USD/BRL feed is not readable on Ethereum mainnet: the call reverts with
     * PriceFeedNotFound. Note what that does and does not mean. Pyth PUBLISHES the feed -
     * it is live on Hermes - but Pyth is pull-based, so a price exists on a given chain
     * only after someone submits a signed update to that chain's Pyth contract and pays
     * the update fee. Nobody has done that for USD/BRL on mainnet.
     *
     * So unlike the Chainlink case, this is not blocked on anyone else: a keeper of ours
     * can post updates permissionlessly and the feed starts working. What it costs is an
     * operator who keeps it warm, which is the same shape of commitment as running the ASP
     * postman.
     *
     * Mova took that option (14 September 2026): PythFxOracle reads this feed and
     * packages/yield's pyth-keeper posts it. Once the keeper runs on mainnet, this assertion
     * fails at any later block - the signal it was written to give. Pin FORK_BLOCK before the
     * keeper's first update to keep testing the unposted case.
     *
     * This is asserted rather than written in a comment so that the day the feed is listed,
     * this test fails and tells us the option has opened up. A comment would just rot.
     */
    function test_NoBrlUsdFeedOnEthereumMainnet() public {
        if (!forked) return;
        vm.expectRevert(); // PriceFeedNotFound
        IPyth(PYTH).getPriceNoOlderThan(USD_BRL, 365 days);
    }

    /// Consequently, constructing the cross reverts on this chain. Loudly, not silently.
    function test_TheCrossCannotBeCompletedHere() public {
        if (!forked) return;
        PythBrlOracle oracle =
            new PythBrlOracle(PYTH, ETH_USD, USD_BRL, 4 days, 4 days, 500, address(this), 48 hours);
        oracle.completeSetup(); // so the refusal below is Pyth's, not the oracle's setup
        vm.expectRevert();
        oracle.brlCentsPerUnit();
    }
}
