// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Governed} from "./utils/Governed.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";
import {FiatEscrow} from "../ramp/FiatEscrow.sol";
import {OffRampEscrow} from "../ramp/OffRampEscrow.sol";
import {LPRegistry} from "../ramp/LPRegistry.sol";
import {IAttestorVerifier} from "../ramp/IAttestorVerifier.sol";
import {StableOracle, MockVerifier3} from "./RampErc20.t.sol";

/// Tether where it matters here: an owner blacklist that stops a listed address SENDING, and
/// nothing else. Receiving is never checked - which is exactly why a frozen escrow kept filling.
contract ListedToken {
    uint8 public constant decimals = 6;
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;
    mapping(address => bool) public isBlackListed;

    function mint(address to, uint256 v) external { balanceOf[to] += v; }
    function list(address who, bool on) external { isBlackListed[who] = on; }

    function approve(address s, uint256 v) external returns (bool) {
        allowance[msg.sender][s] = v;
        return true;
    }

    function transfer(address to, uint256 v) external returns (bool) {
        require(!isBlackListed[msg.sender], "listed");
        balanceOf[msg.sender] -= v;
        balanceOf[to] += v;
        return true;
    }

    function transferFrom(address f, address t, uint256 v) external returns (bool) {
        require(!isBlackListed[f], "listed");
        if (f != msg.sender) allowance[f][msg.sender] -= v;
        balanceOf[f] -= v;
        balanceOf[t] += v;
        return true;
    }
}

/// The Entrypoint's ERC-20 deposit as the escrow meets it: pull from the escrow, forward to the
/// pool less the vetting fee, refuse below the pool's minimum. Its owner can raise the minimum and
/// the fee at any time, as 0xbow's can; `dead` stands for any other refusal (a pool wound down).
contract ScriptedEntrypoint {
    address public immutable POOL = address(0x9001);
    uint256 public minimum;
    uint256 public feeBps;
    bool public hasPool = true;
    bool public dead;
    uint256 internal nonce;

    function setMinimum(uint256 m) external { minimum = m; }
    function setHasPool(bool h) external { hasPool = h; }
    function setFee(uint256 f) external { feeBps = f; }
    function setDead(bool d) external { dead = d; }

    function assetConfig(address) external view returns (address, uint256, uint256, uint256) {
        return (hasPool ? POOL : address(0), minimum, feeBps, 0);
    }

    function deposit(address asset, uint256 value, uint256) external returns (uint256) {
        require(!dead, "PoolIsDead");
        require(value >= minimum, "MinimumDepositAmount");
        ListedToken(asset).transferFrom(msg.sender, address(this), value);
        // reverts while the Entrypoint is listed; the fee stays here, as the real Entrypoint keeps it
        ListedToken(asset).transfer(POOL, value - value * feeBps / 10_000);
        return ++nonce;
    }
}

/// What the escrow reads from a pool after depositing into it, to index the deposit for rescue.
contract LabelSource {
    uint256 public constant SCOPE = 0x5C0BE;
    uint256 public nonce;
}

/**
 * The USDT safeguards, offline, so CI runs them on every push (the same behaviours against real
 * Tether are in UsdtRampFork.t.sol):
 *
 *  - an escrow the issuer froze takes no new tokens and locks no new orders (SR2-25);
 *  - an order never locks toward a party that cannot receive or send: a listed LP, a listed DIRECT
 *    recipient, a listed Entrypoint or pool for a SHIELDED order, a SHIELDED order below the
 *    pool's minimum (SR2-27);
 *  - a taker who has paid for a shielded order that can no longer be delivered takes it in the
 *    open instead of losing it (SR2-26) - automatically, when the Entrypoint's own configuration
 *    or a freeze says the deposit would fail, cost more than MAX_VETTING_FEE_BPS, or land frozen (H-02);
 *  - `assetCap` bounds what one escrow holds, raising it waits, lowering it does not.
 */
contract RampIssuerFreezeTest is Governed {
    FiatEscrow onramp;
    OffRampEscrow offramp;
    LPRegistry registry;
    StableOracle oracle;
    MockVerifier3 verifier;
    ScriptedEntrypoint entrypoint;
    ListedToken usdt;

    address governor = makeAddr("governor");
    address lp = makeAddr("lp");
    address taker = makeAddr("taker");
    address rescue = makeAddr("rescue owner");
    address payout = makeAddr("payout");
    address seller = makeAddr("seller");

    uint256 constant U = 1e6;
    bytes32 constant PIX = keccak256("lp@pix");
    uint16 constant PIX_MASK = uint16(1 << uint8(IAttestorVerifier.Rail.PIX));

    function setUp() public {
        vm.warp(1_700_000_000);
        oracle = new StableOracle();
        verifier = new MockVerifier3();
        registry = new LPRegistry(governor, DELAY);
        entrypoint = new ScriptedEntrypoint();
        vm.etch(entrypoint.POOL(), address(new LabelSource()).code);
        usdt = new ListedToken();
        onramp = new FiatEscrow(address(oracle), address(registry), address(entrypoint), entrypoint.POOL(), 500, governor, DELAY, DISPUTE_TIMEOUT, TAKER_DISPUTE_TIMEOUT, MAX_VETTING_FEE_BPS);
        offramp = new OffRampEscrow(address(oracle), address(registry), 500, governor, DELAY, DISPUTE_TIMEOUT);

        vm.startPrank(governor);
        registry.setEscrow(address(onramp), true);
        registry.setEscrow(address(offramp), true);
        registry.setTier(lp, LPRegistry.Tier.INSTITUTIONAL, 100_000_000);
        registry.completeSetup();
        onramp.setVerifier(address(verifier), true);
        onramp.setAsset(address(usdt), address(oracle), 6, true);
        onramp.completeSetup();
        offramp.setVerifier(address(verifier), true);
        offramp.setAsset(address(usdt), address(oracle), 6, true);
        offramp.completeSetup();
        vm.stopPrank();

        usdt.mint(lp, 100_000 * U);
        usdt.mint(seller, 100_000 * U);
        vm.prank(lp);
        usdt.approve(address(onramp), type(uint256).max);
        vm.prank(seller);
        usdt.approve(address(offramp), type(uint256).max);
    }

    function _offer(uint256 amount) internal returns (bytes32) {
        vm.prank(lp);
        return onramp.postOffer(address(usdt), amount, 550, PIX, U, amount, address(verifier), PIX_MASK);
    }

    function _lockShielded(bytes32 offerId, uint256 amount) internal returns (bytes32) {
        vm.prank(taker);
        return onramp.lockOrder(offerId, amount, FiatEscrow.Delivery.SHIELDED, rescue, 42);
    }

    function _pay(bytes32 orderId, uint256 cents) internal {
        verifier.setProof(orderId, IAttestorVerifier.Payment({
            bankTxId: keccak256(abi.encode(orderId)), payeeKeyHash: PIX, payerRef: bytes32(uint256(1)),
            amountBrlCents: cents, paidAt: uint64(block.timestamp), rail: IAttestorVerifier.Rail.PIX,
            prover: address(0)
        }));
    }

    function _delivery(bytes32 orderId) internal view returns (FiatEscrow.Delivery d) {
        (,,,,,,, d,,,) = onramp.orders(orderId);
    }

    /*//////////////////////////////////////////////////////////////
                          A FROZEN ESCROW (SR2-25)
    //////////////////////////////////////////////////////////////*/

    function test_AFrozenOnRampTakesNoNewTokensAndLocksNothing() public {
        bytes32 offerId = _offer(1_000 * U);
        usdt.list(address(onramp), true);

        vm.prank(lp);
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.FrozenByAssetIssuer.selector, address(onramp)));
        onramp.postOffer(address(usdt), 500 * U, 550, PIX, U, 500 * U, address(verifier), PIX_MASK);
        vm.prank(lp);
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.FrozenByAssetIssuer.selector, address(onramp)));
        onramp.fundOffer(offerId, 100 * U);

        // Without this a taker would pay BRL for tokens that can never leave the escrow.
        vm.prank(taker);
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.FrozenByAssetIssuer.selector, address(onramp)));
        onramp.lockOrder(offerId, 100 * U, FiatEscrow.Delivery.DIRECT, payout, 0);

        // ETH on the same escrow is none of the issuer's business.
        vm.deal(lp, 1 ether);
        vm.prank(lp);
        // (This test oracle prices every asset at 550, ETH included.)
        onramp.postOffer{value: 1 ether}(address(0), 1 ether, 550, PIX, 0.01 ether, 1 ether, address(verifier), PIX_MASK);
    }

    function test_AFrozenOffRampOpensAndClaimsNoSales() public {
        vm.prank(seller);
        bytes32 saleId = offramp.openSale(address(usdt), 100 * U, 55_000, PIX, address(verifier), PIX_MASK, seller);
        usdt.list(address(offramp), true);

        vm.prank(seller);
        vm.expectRevert(abi.encodeWithSelector(OffRampEscrow.FrozenByAssetIssuer.selector, address(offramp)));
        offramp.openSale(address(usdt), 100 * U, 55_000, PIX, address(verifier), PIX_MASK, seller);
        // An LP must not send BRL for a sale the escrow can never pay out.
        vm.prank(lp);
        vm.expectRevert(abi.encodeWithSelector(OffRampEscrow.FrozenByAssetIssuer.selector, address(offramp)));
        offramp.claimSale(saleId);
    }

    /*//////////////////////////////////////////////////////////////
                    NOBODY ON THE PATH IS FROZEN (SR2-24, 26, 27)
    //////////////////////////////////////////////////////////////*/

    function test_AListedLpOrDirectRecipientLocksNothing() public {
        bytes32 offerId = _offer(1_000 * U);
        usdt.list(lp, true);
        vm.prank(taker);
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.FrozenByAssetIssuer.selector, lp));
        onramp.lockOrder(offerId, 100 * U, FiatEscrow.Delivery.DIRECT, payout, 0);
        usdt.list(lp, false);

        usdt.list(payout, true);
        vm.prank(taker);
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.FrozenByAssetIssuer.selector, payout));
        onramp.lockOrder(offerId, 100 * U, FiatEscrow.Delivery.DIRECT, payout, 0);
    }

    function test_AListedLpCannotClaimAndAListedRefundAddressCannotSell() public {
        vm.prank(seller);
        bytes32 saleId = offramp.openSale(address(usdt), 100 * U, 55_000, PIX, address(verifier), PIX_MASK, seller);
        usdt.list(lp, true);
        vm.prank(lp);
        vm.expectRevert(abi.encodeWithSelector(OffRampEscrow.FrozenByAssetIssuer.selector, lp));
        offramp.claimSale(saleId);

        usdt.list(payout, true);
        vm.prank(seller);
        vm.expectRevert(abi.encodeWithSelector(OffRampEscrow.FrozenByAssetIssuer.selector, payout));
        offramp.openSale(address(usdt), 100 * U, 55_000, PIX, address(verifier), PIX_MASK, payout);
    }

    function test_AShieldedOrderIsScreenedAgainstThePoolItWouldLandIn() public {
        bytes32 offerId = _offer(1_000 * U);

        usdt.list(address(entrypoint), true);
        vm.prank(taker);
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.FrozenByAssetIssuer.selector, address(entrypoint)));
        onramp.lockOrder(offerId, 100 * U, FiatEscrow.Delivery.SHIELDED, rescue, 42);
        usdt.list(address(entrypoint), false);

        // A listed pool still accepts deposits, and then freezes every note in it.
        usdt.list(entrypoint.POOL(), true);
        vm.prank(taker);
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.FrozenByAssetIssuer.selector, entrypoint.POOL()));
        onramp.lockOrder(offerId, 100 * U, FiatEscrow.Delivery.SHIELDED, rescue, 42);
        usdt.list(entrypoint.POOL(), false);

        entrypoint.setMinimum(25 * U);
        vm.prank(taker);
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.BelowPoolMinimum.selector, 25 * U));
        onramp.lockOrder(offerId, 10 * U, FiatEscrow.Delivery.SHIELDED, rescue, 42);

        entrypoint.setHasPool(false);
        vm.prank(taker);
        vm.expectRevert(FiatEscrow.BadOrder.selector);
        onramp.lockOrder(offerId, 100 * U, FiatEscrow.Delivery.SHIELDED, rescue, 42);

        entrypoint.setHasPool(true);
        _lockShielded(offerId, 25 * U); // exactly the minimum is a deposit the pool takes
    }

    /*//////////////////////////////////////////////////////////////
                   A PAID TAKER IS NEVER STRANDED (SR2-26)
    //////////////////////////////////////////////////////////////*/

    /// Paid, then the Entrypoint is listed. Before SR2-26 the shielded release reverted and the order
    /// expired back to the LP with the taker's BRL gone; since H-02 the release itself sees the listing
    /// and delivers in the open, to the rescue address, with no step from the taker.
    function test_APaidTakerStrandedByAFrozenEntrypointIsDeliveredDirect() public {
        bytes32 offerId = _offer(1_000 * U);
        bytes32 orderId = _lockShielded(offerId, 100 * U);
        _pay(orderId, 55_000);
        usdt.list(address(entrypoint), true);

        vm.expectEmit(address(onramp));
        emit FiatEscrow.DeliveryMadeDirect(orderId);
        onramp.releaseWithProof(orderId, "");
        assertEq(usdt.balanceOf(rescue), 100 * U, "the paid taker has the tokens");
        assertEq(uint8(_delivery(orderId)), uint8(FiatEscrow.Delivery.DIRECT));
        assertEq(onramp.labelOfOrder(orderId), 0, "nothing was deposited, so there is nothing to rescue");
    }

    /// A pool the issuer listed would TAKE the deposit and freeze the note in it. The release refuses
    /// to deposit there and delivers in the open instead.
    function test_AFrozenPoolIsNotDepositedInto() public {
        bytes32 orderId = _lockShielded(_offer(1_000 * U), 100 * U);
        _pay(orderId, 55_000);
        usdt.list(entrypoint.POOL(), true);
        onramp.releaseWithProof(orderId, "");
        assertEq(usdt.balanceOf(entrypoint.POOL()), 0);
        assertEq(usdt.balanceOf(rescue), 100 * U);
    }

    /// The deposit can still fail for a reason the escrow cannot read beforehand (a pool wound down):
    /// the release reverts, and the taker takes the order in the open.
    function test_APaidTakerWhoseDepositRevertsTakesDeliveryDirect() public {
        bytes32 offerId = _offer(1_000 * U);
        bytes32 orderId = _lockShielded(offerId, 100 * U);
        _pay(orderId, 55_000);
        entrypoint.setDead(true);

        vm.expectRevert(FiatEscrow.TransferFailed.selector);
        onramp.releaseWithProof(orderId, "");

        // Nobody but the rescue address can give up the taker's privacy - not even the taker's relayer.
        vm.prank(taker);
        vm.expectRevert(FiatEscrow.NotTaker.selector);
        onramp.takeDeliveryDirect(orderId);
        vm.prank(lp);
        vm.expectRevert(FiatEscrow.NotTaker.selector);
        onramp.takeDeliveryDirect(orderId);

        vm.expectEmit(address(onramp));
        emit FiatEscrow.DeliveryMadeDirect(orderId);
        vm.prank(rescue);
        onramp.takeDeliveryDirect(orderId);
        assertEq(uint8(_delivery(orderId)), uint8(FiatEscrow.Delivery.DIRECT));

        onramp.releaseWithProof(orderId, ""); // anyone may carry the proof, as before
        assertEq(usdt.balanceOf(rescue), 100 * U, "the paid taker has the tokens");

        vm.prank(rescue);
        vm.expectRevert(FiatEscrow.WrongState.selector);
        onramp.takeDeliveryDirect(orderId);
    }

    /// The pool's owner raises the minimum between lock and release (SR2-27's moving target), or
    /// removes the pool: the Entrypoint would refuse the deposit, so the release delivers directly.
    function test_ARaisedPoolMinimumOrARemovedPoolDeliversDirect() public {
        bytes32 offerId = _offer(1_000 * U);
        bytes32 orderId = _lockShielded(offerId, 30 * U);
        _pay(orderId, 16_500);
        entrypoint.setMinimum(50 * U);
        onramp.releaseWithProof(orderId, "");
        assertEq(usdt.balanceOf(rescue), 30 * U);

        entrypoint.setMinimum(0);
        bytes32 second = _lockShielded(offerId, 40 * U);
        _pay(second, 22_000);
        entrypoint.setHasPool(false);
        onramp.releaseWithProof(second, "");
        assertEq(usdt.balanceOf(rescue), 70 * U);
        assertEq(uint8(_delivery(second)), uint8(FiatEscrow.Delivery.DIRECT));
    }

    /*//////////////////////////////////////////////////////////////
                   THE VETTING FEE IS CAPPED (H-02)
    //////////////////////////////////////////////////////////////*/

    /// A shielded order is not locked toward a pool that charges more than the cap; a DIRECT one
    /// does not care.
    function test_AShieldedLockIsRefusedAboveTheVettingFeeCap() public {
        bytes32 offerId = _offer(1_000 * U);
        entrypoint.setFee(MAX_VETTING_FEE_BPS + 1);
        vm.prank(taker);
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.VettingFeeAboveCap.selector, MAX_VETTING_FEE_BPS + 1));
        onramp.lockOrder(offerId, 100 * U, FiatEscrow.Delivery.SHIELDED, rescue, 42);
        vm.prank(taker);
        onramp.lockOrder(offerId, 100 * U, FiatEscrow.Delivery.DIRECT, payout, 0);

        entrypoint.setFee(MAX_VETTING_FEE_BPS); // at the cap is within it
        _lockShielded(offerId, 100 * U);
    }

    /// At the cap the deposit is made, fee and all: the taker accepted that much at lock.
    function test_AFeeWithinTheCapIsPaidAndTheOrderShielded() public {
        entrypoint.setFee(MAX_VETTING_FEE_BPS);
        bytes32 orderId = _lockShielded(_offer(1_000 * U), 100 * U);
        _pay(orderId, 55_000);
        onramp.releaseWithProof(orderId, "");
        assertEq(uint8(_delivery(orderId)), uint8(FiatEscrow.Delivery.SHIELDED));
        assertEq(usdt.balanceOf(entrypoint.POOL()), 100 * U - 100 * U * MAX_VETTING_FEE_BPS / 10_000);
        assertEq(usdt.balanceOf(rescue), 0);
        assertEq(usdt.allowance(address(onramp), address(entrypoint)), 0, "no standing allowance");
    }

    /// The Entrypoint's owner raises the fee after the taker locked and paid. The release does not
    /// pay it, and does not revert either - a relayer's proof still lands - but delivers the full
    /// amount to the rescue address. The shielded hatch is closed for that order: nothing is in the pool.
    function test_AFeeRaisedAfterLockIsNeverChargedTheOrderIsDeliveredDirect() public {
        bytes32 orderId = _lockShielded(_offer(1_000 * U), 100 * U);
        _pay(orderId, 55_000);
        entrypoint.setFee(5_000); // half of every deposit

        vm.expectEmit(address(onramp));
        emit FiatEscrow.DeliveryMadeDirect(orderId);
        vm.prank(makeAddr("relayer"));
        onramp.releaseWithProof(orderId, "");
        assertEq(usdt.balanceOf(rescue), 100 * U, "all of it, to the address the taker named");
        assertEq(usdt.balanceOf(address(entrypoint)) + usdt.balanceOf(entrypoint.POOL()), 0, "no fee taken");
        assertEq(uint8(_delivery(orderId)), uint8(FiatEscrow.Delivery.DIRECT));
    }

    /**
     * Whatever the fee does between lock and release, the release never reverts on its account and
     * never charges more than the cap: the order either lands in the pool at a fee within it, or
     * reaches the rescue address whole. Nothing stays in the escrow.
     */
    /// forge-config: default.fuzz.runs = 256
    /// forge-config: deep.fuzz.runs = 10000
    function testFuzz_ADeliveryIsNeverTrappedNorOvercharged(uint256 feeAtLock, uint256 feeAtRelease, uint256 amount)
        public
    {
        feeAtLock = bound(feeAtLock, 0, MAX_VETTING_FEE_BPS);
        feeAtRelease = bound(feeAtRelease, 0, 10_000);
        amount = bound(amount, U, 1_000 * U);
        bytes32 offerId = _offer(1_000 * U);
        entrypoint.setFee(feeAtLock);
        bytes32 orderId = _lockShielded(offerId, amount);
        _pay(orderId, (amount * 550 + U - 1) / U);
        entrypoint.setFee(feeAtRelease);

        onramp.releaseWithProof(orderId, "");
        uint256 pooled = usdt.balanceOf(entrypoint.POOL());
        if (feeAtRelease <= MAX_VETTING_FEE_BPS) {
            assertEq(pooled, amount - amount * feeAtRelease / 10_000);
            assertEq(usdt.balanceOf(rescue), 0);
        } else {
            assertEq(pooled, 0);
            assertEq(usdt.balanceOf(rescue), amount);
        }
        assertEq(usdt.balanceOf(address(onramp)), 1_000 * U - amount, "only the offer's free liquidity remains");
    }

    function test_TheVettingFeeCapIsBoundedAtDeployment() public {
        address pool = entrypoint.POOL();
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.VettingFeeAboveCap.selector, 101));
        new FiatEscrow(address(oracle), address(registry), address(entrypoint), pool, 500, governor, DELAY, DISPUTE_TIMEOUT, TAKER_DISPUTE_TIMEOUT, 101);
        FiatEscrow max = new FiatEscrow(address(oracle), address(registry), address(entrypoint), pool, 500, governor, DELAY, DISPUTE_TIMEOUT, TAKER_DISPUTE_TIMEOUT, 100);
        assertEq(max.MAX_VETTING_FEE_BPS(), 100);
        FiatEscrow none = new FiatEscrow(address(oracle), address(registry), address(entrypoint), pool, 500, governor, DELAY, DISPUTE_TIMEOUT, TAKER_DISPUTE_TIMEOUT, 0);
        assertEq(none.MAX_VETTING_FEE_BPS(), 0, "zero: only a pool that charges nothing is shielded into");
    }

    /// With the pay window closing, the taker disputes first; the switch still works while DISPUTED.
    function test_ADisputedOrderCanStillBeTakenDirect() public {
        bytes32 offerId = _offer(1_000 * U);
        bytes32 orderId = _lockShielded(offerId, 100 * U);
        vm.prank(taker);
        onramp.raiseDispute(orderId, "paid; shielded delivery reverts");
        vm.prank(rescue);
        onramp.takeDeliveryDirect(orderId);
        assertEq(uint8(_delivery(orderId)), uint8(FiatEscrow.Delivery.DIRECT));
    }

    function test_OnlyAShieldedOrderToAnUnfrozenAddressCanBeTakenDirect() public {
        bytes32 offerId = _offer(1_000 * U);
        vm.prank(taker);
        bytes32 direct = onramp.lockOrder(offerId, 100 * U, FiatEscrow.Delivery.DIRECT, payout, 0);
        vm.prank(payout);
        vm.expectRevert(FiatEscrow.WrongState.selector);
        onramp.takeDeliveryDirect(direct);

        bytes32 shielded = _lockShielded(offerId, 100 * U);
        usdt.list(rescue, true);
        vm.prank(rescue);
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.FrozenByAssetIssuer.selector, rescue));
        onramp.takeDeliveryDirect(shielded);
    }

    /*//////////////////////////////////////////////////////////////
                               THE CAP
    //////////////////////////////////////////////////////////////*/

    function test_TheCapBoundsWhatTheOnRampHolds_RaisingItWaits() public {
        vm.prank(governor);
        onramp.setAssetCap(address(usdt), 1_000 * U); // a first cap only lowers risk: instant
        bytes32 offerId = _offer(800 * U);
        vm.prank(lp);
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.AssetCapExceeded.selector, address(usdt), 1_000 * U));
        onramp.fundOffer(offerId, 201 * U);
        vm.prank(lp);
        onramp.fundOffer(offerId, 200 * U); // exactly the cap

        vm.prank(governor);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, FiatEscrow.setAssetCap.selector));
        onramp.setAssetCap(address(usdt), 2_000 * U);
        vm.prank(governor);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, FiatEscrow.setAssetCap.selector));
        onramp.setAssetCap(address(usdt), 0); // removing a cap is raising it

        _afterDelay(address(onramp), abi.encodeCall(FiatEscrow.setAssetCap, (address(usdt), 2_000 * U)));
        assertEq(onramp.assetCap(address(usdt)), 2_000 * U);
        vm.prank(governor);
        onramp.setAssetCap(address(usdt), 500 * U); // lowering: instant, even below what is held
        vm.prank(lp);
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.AssetCapExceeded.selector, address(usdt), 500 * U));
        onramp.fundOffer(offerId, 1);
        // Exits are never capped.
        vm.prank(lp);
        onramp.closeOffer(offerId);
        assertEq(usdt.balanceOf(lp), 100_000 * U);
    }

    function test_TheCapBoundsWhatTheOffRampHolds() public {
        vm.prank(governor);
        offramp.setAssetCap(address(usdt), 150 * U);
        vm.prank(seller);
        offramp.openSale(address(usdt), 100 * U, 55_000, PIX, address(verifier), PIX_MASK, seller);
        vm.prank(seller);
        vm.expectRevert(abi.encodeWithSelector(OffRampEscrow.AssetCapExceeded.selector, address(usdt), 150 * U));
        offramp.openSale(address(usdt), 100 * U, 55_000, PIX, address(verifier), PIX_MASK, seller);

        vm.prank(governor);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, OffRampEscrow.setAssetCap.selector));
        offramp.setAssetCap(address(usdt), 1_000 * U);
    }
}
