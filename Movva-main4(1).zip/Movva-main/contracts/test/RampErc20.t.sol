// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;
import {ProverOf} from "./utils/ProverOf.sol";

import {Governed} from "./utils/Governed.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";
import {FiatEscrow} from "../ramp/FiatEscrow.sol";
import {OffRampEscrow} from "../ramp/OffRampEscrow.sol";
import {LPRegistry} from "../ramp/LPRegistry.sol";
import {SafeTransferLib} from "../ramp/SafeTransferLib.sol";
import {IAttestorVerifier} from "../ramp/IAttestorVerifier.sol";
import {IPriceOracle} from "../ramp/IPriceOracle.sol";

/// A plain, well-behaved 6-decimal stablecoin.
contract MockUSD {
    string public name = "Mock BRL Stable";
    uint8 public decimals = 6;
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    function mint(address to, uint256 v) external {
        balanceOf[to] += v;
    }

    function approve(address s, uint256 v) external returns (bool) {
        allowance[msg.sender][s] = v;
        return true;
    }

    function transfer(address to, uint256 v) external returns (bool) {
        balanceOf[msg.sender] -= v;
        balanceOf[to] += v;
        return true;
    }

    function transferFrom(address f, address t, uint256 v) external returns (bool) {
        if (f != msg.sender) allowance[f][msg.sender] -= v;
        balanceOf[f] -= v;
        balanceOf[t] += v;
        return true;
    }
}

/// USDT-shaped: returns nothing at all. The classic breaker of naive integrations.
contract NoReturnToken {
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    function mint(address to, uint256 v) external {
        balanceOf[to] += v;
    }

    function approve(address s, uint256 v) external {
        allowance[msg.sender][s] = v;
    }

    function transfer(address to, uint256 v) external {
        balanceOf[msg.sender] -= v;
        balanceOf[to] += v;
    }

    function transferFrom(address f, address t, uint256 v) external {
        if (f != msg.sender) allowance[f][msg.sender] -= v;
        balanceOf[f] -= v;
        balanceOf[t] += v;
    }
}

/// Signals failure by returning false instead of reverting.
contract LyingToken {
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    function mint(address to, uint256 v) external {
        balanceOf[to] += v;
    }

    function approve(address, uint256) external pure returns (bool) {
        return true;
    }

    function transfer(address, uint256) external pure returns (bool) {
        return false;
    }

    function transferFrom(address, address, uint256) external pure returns (bool) {
        return false;
    }
}

/// Takes a 2% cut in transit. Must never be listable.
contract FeeToken {
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    function mint(address to, uint256 v) external {
        balanceOf[to] += v;
    }

    function approve(address s, uint256 v) external returns (bool) {
        allowance[msg.sender][s] = v;
        return true;
    }

    function transfer(address to, uint256 v) external returns (bool) {
        balanceOf[msg.sender] -= v;
        balanceOf[to] += (v * 98) / 100;
        return true;
    }

    function transferFrom(address f, address t, uint256 v) external returns (bool) {
        if (f != msg.sender) allowance[f][msg.sender] -= v;
        balanceOf[f] -= v;
        balanceOf[t] += (v * 98) / 100;
        return true;
    }
}

contract StableOracle is IPriceOracle {
    /// R$5.50 per token, in centavos, per WHOLE token (decimals handled by the escrow).
    uint256 public price = 550;

    function brlCentsPerUnit() external view returns (uint256, uint64) {
        return (price, uint64(block.timestamp));
    }
}

contract MockVerifier3 is IAttestorVerifier {
    mapping(bytes32 => Payment) internal p;
    mapping(bytes32 => bool) internal set_;

    function setProof(bytes32 id, Payment memory pay) external {
        p[id] = pay;
        set_[id] = true;
    }

    function verifyPayment(bytes32 id, bytes calldata) external view returns (Payment memory) {
        require(set_[id], "not bound");
        Payment memory q = p[id];
        if (q.prover == address(0)) q.prover = ProverOf.lpOf(msg.sender, id);
        return q;
    }

    function attestorKind() external pure returns (string memory) {
        return "mock/erc20";
    }

    function provesBankSession() external pure returns (bool) {
        return true;
    }
}

contract RampErc20Test is Governed {
    FiatEscrow onramp;
    OffRampEscrow offramp;
    LPRegistry registry;
    MockVerifier3 verifier;
    StableOracle stableOracle;
    MockUSD usd;

    address governor = address(0x60F);
    address lp = makeAddr("lp");
    address taker = makeAddr("taker");
    address payout = makeAddr("payout");
    address seller = makeAddr("seller");

    bytes32 constant PIX = keccak256("lp@pix");
    uint16 constant PIX_MASK = uint16(1 << uint8(IAttestorVerifier.Rail.PIX));
    uint256 constant ONE_USD = 1e6; // 6 decimals

    function setUp() public {
        vm.warp(1_700_000_000);
        stableOracle = new StableOracle();
        verifier = new MockVerifier3();
        registry = new LPRegistry(governor, DELAY);
        usd = new MockUSD();

        onramp = new FiatEscrow(address(stableOracle), address(registry), address(0xBEEF), address(0xBEEF), 500, governor, DELAY, DISPUTE_TIMEOUT, TAKER_DISPUTE_TIMEOUT, MAX_VETTING_FEE_BPS);
        offramp = new OffRampEscrow(address(stableOracle), address(registry), 500, governor, DELAY, DISPUTE_TIMEOUT);

        vm.startPrank(governor);
        registry.setEscrow(address(onramp), true);
        // Both escrows reserve credit in the one registry; an unregistered escrow cannot.
        registry.setEscrow(address(offramp), true);
        registry.setTier(lp, LPRegistry.Tier.INSTITUTIONAL, 100_000_000);
        registry.completeSetup();
        onramp.setVerifier(address(verifier), true);
        offramp.setVerifier(address(verifier), true);
        onramp.setAsset(address(usd), address(stableOracle), 6, true);
        offramp.setAsset(address(usd), address(stableOracle), 6, true);
        onramp.completeSetup();
        offramp.completeSetup();
        vm.stopPrank();

        usd.mint(lp, 10_000 * ONE_USD);
        usd.mint(seller, 10_000 * ONE_USD);
    }

    function _pay(bytes32 id, uint256 cents) internal {
        verifier.setProof(
            id,
            IAttestorVerifier.Payment({
                bankTxId: keccak256(abi.encode(id)),
                payeeKeyHash: PIX,
                payerRef: bytes32(uint256(1)),
                amountBrlCents: cents,
                paidAt: uint64(block.timestamp),
                rail: IAttestorVerifier.Rail.PIX,
            prover: address(0)
            })
        );
    }

    /*//////////////////////////////////////////////////////////////
                          A 6-DECIMAL ASSET
    //////////////////////////////////////////////////////////////*/

    /// The reason assets carry their own decimals: 1e18 math would be wrong by 1e12 here.
    function test_PriceMathUsesTheAssetsOwnDecimals() public {
        vm.startPrank(lp);
        usd.approve(address(onramp), 1000 * ONE_USD);
        bytes32 offerId = onramp.postOffer(
            address(usd), 1000 * ONE_USD, 550, PIX, ONE_USD, 500 * ONE_USD, address(verifier), PIX_MASK
        );
        vm.stopPrank();

        vm.prank(taker);
        bytes32 orderId =
            onramp.lockOrder(offerId, 100 * ONE_USD, FiatEscrow.Delivery.DIRECT, payout, 0);
        (,,, uint256 brlCents,,,,,,,) = onramp.orders(orderId);
        assertEq(brlCents, 100 * 550, "100 tokens at R$5.50 = R$550.00 = 55,000 centavos");
    }

    function test_OnRampSettlesInAStablecoin() public {
        vm.startPrank(lp);
        usd.approve(address(onramp), 1000 * ONE_USD);
        bytes32 offerId = onramp.postOffer(
            address(usd), 1000 * ONE_USD, 550, PIX, ONE_USD, 500 * ONE_USD, address(verifier), PIX_MASK
        );
        vm.stopPrank();
        assertEq(usd.balanceOf(address(onramp)), 1000 * ONE_USD, "the escrow really holds it");

        vm.prank(taker);
        bytes32 orderId =
            onramp.lockOrder(offerId, 100 * ONE_USD, FiatEscrow.Delivery.DIRECT, payout, 0);
        _pay(orderId, 55_000);
        onramp.releaseWithProof(orderId, "");

        assertEq(usd.balanceOf(payout), 100 * ONE_USD, "taker paid BRL, received tokens");
    }

    function test_OffRampSellsAStablecoinForBrl() public {
        vm.startPrank(seller);
        usd.approve(address(offramp), 100 * ONE_USD);
        bytes32 saleId = offramp.openSale(
            address(usd), 100 * ONE_USD, 55_000, PIX, address(verifier), PIX_MASK, seller
        );
        vm.stopPrank();

        vm.prank(lp);
        offramp.claimSale(saleId);
        _pay(saleId, 55_000);
        offramp.settleWithProof(saleId, "");
        assertEq(usd.balanceOf(lp), 10_100 * ONE_USD, "LP paid BRL, collected the tokens");
    }

    function test_NativeEthStillWorksAlongsideTokens() public {
        vm.deal(lp, 10 ether);
        vm.prank(governor);
        onramp.setAsset(address(0), address(stableOracle), 18, true);
        vm.prank(lp);
        // 1 ETH priced at R$5.50 keeps it inside the band of this test oracle.
        bytes32 offerId = onramp.postOffer{value: 5 ether}(
            address(0), 5 ether, 550, PIX, 0.1 ether, 2 ether, address(verifier), PIX_MASK
        );
        vm.prank(taker);
        bytes32 orderId =
            onramp.lockOrder(offerId, 1 ether, FiatEscrow.Delivery.DIRECT, payout, 0);
        _pay(orderId, 550);
        onramp.releaseWithProof(orderId, "");
        assertEq(payout.balance, 1 ether);
    }

    /*//////////////////////////////////////////////////////////////
                        AWKWARD REAL TOKENS
    //////////////////////////////////////////////////////////////*/

    /// USDT returns nothing. A naive integration reverts on a transfer that succeeded.
    function test_ATokenThatReturnsNothingIsHandled() public {
        NoReturnToken t = new NoReturnToken();
        t.mint(lp, 1000e6);
        // Listing a token is risk-increasing: it waits out the governance delay.
        _afterDelay(address(onramp), abi.encodeCall(FiatEscrow.setAsset, (address(t), address(stableOracle), 6, true)));

        vm.startPrank(lp);
        t.approve(address(onramp), 1000e6);
        bytes32 offerId = onramp.postOffer(
            address(t), 1000e6, 550, PIX, 1e6, 500e6, address(verifier), PIX_MASK
        );
        vm.stopPrank();

        vm.prank(taker);
        bytes32 orderId = onramp.lockOrder(offerId, 100e6, FiatEscrow.Delivery.DIRECT, payout, 0);
        _pay(orderId, 55_000);
        onramp.releaseWithProof(orderId, "");
        assertEq(t.balanceOf(payout), 100e6);
    }

    /// A token that returns false must not be treated as a successful transfer.
    function test_ATokenThatReturnsFalseIsRejected() public {
        LyingToken t = new LyingToken();
        t.mint(lp, 1000e6);
        // Listing a token is risk-increasing: it waits out the governance delay.
        _afterDelay(address(onramp), abi.encodeCall(FiatEscrow.setAsset, (address(t), address(stableOracle), 6, true)));

        vm.startPrank(lp);
        t.approve(address(onramp), 1000e6);
        vm.expectRevert(
            abi.encodeWithSelector(
                SafeTransferLib.TransferFromFailed.selector, address(t), lp, uint256(1000e6)
            )
        );
        onramp.postOffer(address(t), 1000e6, 550, PIX, 1e6, 500e6, address(verifier), PIX_MASK);
        vm.stopPrank();
    }

    /// Fee-on-transfer breaks the escrow's promise, so it is refused at the door.
    function test_AFeeOnTransferTokenCannotBeEscrowed() public {
        FeeToken t = new FeeToken();
        t.mint(lp, 1000e6);
        // Listing a token is risk-increasing: it waits out the governance delay.
        _afterDelay(address(onramp), abi.encodeCall(FiatEscrow.setAsset, (address(t), address(stableOracle), 6, true)));

        vm.startPrank(lp);
        t.approve(address(onramp), 1000e6);
        vm.expectRevert(
            abi.encodeWithSelector(
                SafeTransferLib.UnexpectedAmountReceived.selector, uint256(1000e6), uint256(980e6)
            )
        );
        onramp.postOffer(address(t), 1000e6, 550, PIX, 1e6, 500e6, address(verifier), PIX_MASK);
        vm.stopPrank();
    }

    /*//////////////////////////////////////////////////////////////
                          ASSET GOVERNANCE
    //////////////////////////////////////////////////////////////*/

    function test_AnUnlistedTokenCannotBeOffered() public {
        MockUSD other = new MockUSD();
        other.mint(lp, 100e6);
        vm.startPrank(lp);
        other.approve(address(onramp), 100e6);
        vm.expectRevert(
            abi.encodeWithSelector(FiatEscrow.AssetNotEnabled.selector, address(other))
        );
        onramp.postOffer(address(other), 100e6, 550, PIX, 1e6, 50e6, address(verifier), PIX_MASK);
        vm.stopPrank();
    }

    /// ETH must arrive as msg.value; a token must not be accompanied by any.
    function test_SendingEthWithATokenOfferIsRejected() public {
        vm.deal(lp, 1 ether);
        vm.startPrank(lp);
        usd.approve(address(onramp), 100 * ONE_USD);
        vm.expectRevert(FiatEscrow.WrongMsgValue.selector);
        onramp.postOffer{value: 1 ether}(
            address(usd), 100 * ONE_USD, 550, PIX, ONE_USD, 50 * ONE_USD, address(verifier), PIX_MASK
        );
        vm.stopPrank();
    }

    function test_MismatchedEthValueIsRejected() public {
        vm.deal(lp, 10 ether);
        vm.prank(governor);
        onramp.setAsset(address(0), address(stableOracle), 18, true);
        vm.prank(lp);
        vm.expectRevert(FiatEscrow.WrongMsgValue.selector);
        onramp.postOffer{value: 1 ether}(
            address(0), 2 ether, 550, PIX, 0.1 ether, 1 ether, address(verifier), PIX_MASK
        );
    }

    /// Delisting must not strand liquidity already posted.
    function test_DelistingDoesNotStrandALiveOffer() public {
        vm.startPrank(lp);
        usd.approve(address(onramp), 1000 * ONE_USD);
        bytes32 offerId = onramp.postOffer(
            address(usd), 1000 * ONE_USD, 550, PIX, ONE_USD, 500 * ONE_USD, address(verifier), PIX_MASK
        );
        vm.stopPrank();

        vm.prank(governor);
        onramp.setAsset(address(usd), address(stableOracle), 6, false);

        vm.prank(lp);
        onramp.closeOffer(offerId);
        assertEq(usd.balanceOf(lp), 10_000 * ONE_USD, "the LP got everything back");
    }

    /**
     * The attack: a governor re-lists a live 6-decimal token as 36 decimals, and
     * `ceilDiv(amount * price, 10 ** decimals)` rounds every order against the LP's offer up
     * to one centavo. Decimals are now fixed at first listing, including across a delist.
     */
    function test_AGovernorCannotRepriceLiveOffersByChangingDecimals() public {
        vm.startPrank(lp);
        usd.approve(address(onramp), 1000 * ONE_USD);
        bytes32 offerId = onramp.postOffer(
            address(usd), 1000 * ONE_USD, 550, PIX, ONE_USD, 500 * ONE_USD, address(verifier), PIX_MASK
        );
        vm.stopPrank();

        vm.startPrank(governor);
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.DecimalsFixed.selector, address(usd), 6));
        onramp.setAsset(address(usd), address(stableOracle), 36, true);
        onramp.setAsset(address(usd), address(stableOracle), 6, false); // delisting is instant
        vm.expectRevert(abi.encodeWithSelector(OffRampEscrow.DecimalsFixed.selector, address(usd), 6));
        offramp.setAsset(address(usd), address(stableOracle), 36, true);
        // Relisting waits out the delay - and still cannot change the decimals when it runs.
        bytes memory relist = abi.encodeCall(FiatEscrow.setAsset, (address(usd), address(stableOracle), 36, true));
        onramp.schedule(relist);
        vm.warp(block.timestamp + DELAY);
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.DecimalsFixed.selector, address(usd), 6));
        onramp.execute(relist);
        vm.stopPrank();

        (,,,,,,,,,,, uint8 pinned) = onramp.offers(offerId);
        assertEq(pinned, 6, "the offer carries the decimals it was posted with");
    }

    /// Defence in depth: even if the asset's config were rewritten by some future path, a
    /// live offer still charges at the decimals pinned when it was posted.
    function test_ALiveOfferPricesAtItsPinnedDecimalsWhateverTheConfigSays() public {
        vm.startPrank(lp);
        usd.approve(address(onramp), 1000 * ONE_USD);
        bytes32 offerId = onramp.postOffer(
            address(usd), 1000 * ONE_USD, 550, PIX, ONE_USD, 500 * ONE_USD, address(verifier), PIX_MASK
        );
        vm.stopPrank();

        // Rewrite assets[usd].decimals to 36 directly. The slot is found by value rather than
        // hard-coded, so an inheritance change that shifts the layout cannot make this pass
        // by writing somewhere irrelevant.
        bytes32 expected = bytes32(uint256(uint160(address(stableOracle))) | (6 << 160) | (1 << 168));
        bytes32 slot;
        for (uint256 i; i < 64; ++i) {
            bytes32 candidate = keccak256(abi.encode(address(usd), i));
            if (vm.load(address(onramp), candidate) == expected) {
                slot = candidate;
                break;
            }
        }
        require(slot != bytes32(0), "asset config slot not found");
        vm.store(address(onramp), slot, bytes32(uint256(expected) & ~(uint256(0xff) << 160) | (36 << 160)));
        (, uint8 nowDecimals,) = onramp.assets(address(usd));
        assertEq(nowDecimals, 36, "the config really was rewritten");

        vm.prank(taker);
        bytes32 orderId =
            onramp.lockOrder(offerId, 100 * ONE_USD, FiatEscrow.Delivery.DIRECT, payout, 0);
        (,,, uint256 brlCents,,,,,,,) = onramp.orders(orderId);
        assertEq(brlCents, 55_000, "still R$550.00, not R$0.01");
    }

    /// Pointing an asset at another oracle, or listing one, waits; LPs see it coming.
    function test_ListingOrChangingAnOracleWaitsButDelistingDoesNot() public {
        MockUSD other = new MockUSD();
        StableOracle otherOracle = new StableOracle();
        vm.startPrank(governor);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, FiatEscrow.setAsset.selector)
        );
        onramp.setAsset(address(other), address(stableOracle), 6, true);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, FiatEscrow.setAsset.selector)
        );
        onramp.setAsset(address(usd), address(otherOracle), 6, true);
        onramp.setAsset(address(usd), address(stableOracle), 6, false);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, FiatEscrow.setAsset.selector)
        );
        onramp.setAsset(address(usd), address(stableOracle), 6, true); // re-enabling waits too
        vm.stopPrank();
        (, , bool enabled) = onramp.assets(address(usd));
        assertFalse(enabled);
    }

    function test_OnlyGovernorListsAssets() public {
        vm.expectRevert(DelayedGovernance.NotGovernor.selector);
        onramp.setAsset(address(usd), address(stableOracle), 6, true);
    }
}
