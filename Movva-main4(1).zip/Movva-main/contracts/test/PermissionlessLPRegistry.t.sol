// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import {PermissionlessLPRegistry} from "../ramp/PermissionlessLPRegistry.sol";
import {LPRegistry} from "../ramp/LPRegistry.sol";
import {Movva} from "../movva/Movva.sol";
import {EscrowStub, TestMovva} from "./utils/PermissionlessRegistryKit.sol";

/**
 * Unit and fuzz tests for PermissionlessLPRegistry against escrow stubs: joining, credit, exposure, exit and
 * unbonding, the automatic slash, bank transaction ids across registries, the one-shot binding, and the bounds on
 * every path the escrows need never to revert. The real escrows run against it in PermissionlessRampIntegration.t.sol;
 * the invariants are in PermissionlessLPRegistryInvariant.t.sol.
 */
/// forge-config: default.fuzz.runs = 256
/// forge-config: deep.fuzz.runs = 10000
contract PermissionlessLPRegistryTest is Test {
    PermissionlessLPRegistry reg;
    Movva movva;
    LPRegistry old;
    EscrowStub oldEscrow;
    EscrowStub fiat;
    EscrowStub off;

    uint256 constant MIN = 5_000e18; // R$ 5.000,00
    uint64 constant TIMEOUT = 30 days;
    uint256 constant UNBONDING = 36 days; // 30 + 1 (ruling delay) + 4 (margin) + 1
    address lp = makeAddr("lp");
    address lp2 = makeAddr("lp2");
    address stranger = makeAddr("stranger");

    event Slashed(address indexed lp, address indexed escrow, uint256 amount);
    event EscrowsBound(address indexed fiatEscrow, address indexed offRampEscrow);

    function setUp() public {
        vm.warp(1_800_000_000);
        movva = new Movva(); // this test is its RESERVE, so it can mint
        old = new LPRegistry(address(this), 48 hours);
        oldEscrow = new EscrowStub(address(old), TIMEOUT);
        old.setEscrow(address(oldEscrow), true); // instant during setup
        old.completeSetup();
        reg = new PermissionlessLPRegistry(address(movva), address(old), MIN, UNBONDING, 1_000);
        fiat = new EscrowStub(address(reg), TIMEOUT);
        off = new EscrowStub(address(reg), TIMEOUT);
        reg.bindEscrows(address(fiat), address(off));
        _fund(lp, 1_000_000e18);
        _fund(lp2, 1_000_000e18);
    }

    function _fund(address who, uint256 amount) internal {
        movva.mint(who, amount);
        vm.prank(who);
        movva.approve(address(reg), type(uint256).max);
    }

    function _join(address who, uint256 amount) internal {
        vm.prank(who);
        reg.join(amount);
    }

    function _bond(address who) internal view returns (uint256 amount) {
        (amount,,,,,) = reg.bonds(who);
    }

    function _exposure(address who) internal view returns (uint256 e) {
        (, e,,,,) = reg.bonds(who);
    }

    /*//////////////////////////////////////////////////////////////
                              CONSTRUCTION
    //////////////////////////////////////////////////////////////*/

    function test_ConstructorRecordsItsImmutables() public view {
        assertEq(address(reg.MOVVA()), address(movva));
        assertEq(address(reg.PREDECESSOR()), address(old));
        assertEq(reg.MIN_BOND(), MIN);
        assertEq(reg.UNBONDING_PERIOD(), UNBONDING);
        assertEq(reg.DEPLOYER(), address(this));
        assertEq(reg.TOKEN_PER_CENT(), 1e16, "1 MOVVA = R$ 1,00 = 100 centavos");
    }

    function test_ConstructorRefusesBadParameters() public {
        vm.expectRevert(PermissionlessLPRegistry.ZeroAddress.selector);
        new PermissionlessLPRegistry(address(0), address(0), MIN, UNBONDING, 1_000);
        vm.expectRevert(
            abi.encodeWithSelector(PermissionlessLPRegistry.NotAContract.selector, stranger)
        );
        new PermissionlessLPRegistry(stranger, address(0), MIN, UNBONDING, 1_000);
        TestMovva six = new TestMovva(6);
        vm.expectRevert(PermissionlessLPRegistry.BadMovva.selector);
        new PermissionlessLPRegistry(address(six), address(0), MIN, UNBONDING, 1_000);
        vm.expectRevert(
            abi.encodeWithSelector(PermissionlessLPRegistry.NotAContract.selector, stranger)
        );
        new PermissionlessLPRegistry(address(movva), stranger, MIN, UNBONDING, 1_000);
        // A contract that is not a registry: usedBankTxId reverts.
        vm.expectRevert();
        new PermissionlessLPRegistry(address(movva), address(movva), MIN, UNBONDING, 1_000);
        vm.expectRevert(
            abi.encodeWithSelector(PermissionlessLPRegistry.BadMinBond.selector, 1e18 - 1)
        );
        new PermissionlessLPRegistry(address(movva), address(0), 1e18 - 1, UNBONDING, 1_000);
        vm.expectRevert(
            abi.encodeWithSelector(PermissionlessLPRegistry.BadMinBond.selector, 1e18 + 1)
        );
        new PermissionlessLPRegistry(address(movva), address(0), 1e18 + 1, UNBONDING, 1_000);
        vm.expectRevert(
            abi.encodeWithSelector(PermissionlessLPRegistry.BadUnbondingPeriod.selector, 0)
        );
        new PermissionlessLPRegistry(address(movva), address(0), MIN, 0, 1_000);
        vm.expectRevert(
            abi.encodeWithSelector(PermissionlessLPRegistry.BadUnbondingPeriod.selector, 366 days)
        );
        new PermissionlessLPRegistry(address(movva), address(0), MIN, 366 days, 1_000);
        // No predecessor is a fresh rail.
        PermissionlessLPRegistry fresh =
            new PermissionlessLPRegistry(address(movva), address(0), 1e18, 1, 1_000);
        assertEq(address(fresh.PREDECESSOR()), address(0));
    }

    /*//////////////////////////////////////////////////////////////
                             ONE-SHOT BINDING
    //////////////////////////////////////////////////////////////*/

    function _fresh() internal returns (PermissionlessLPRegistry r, EscrowStub a, EscrowStub b) {
        r = new PermissionlessLPRegistry(address(movva), address(0), MIN, UNBONDING, 1_000);
        a = new EscrowStub(address(r), TIMEOUT);
        b = new EscrowStub(address(r), TIMEOUT);
    }

    function test_BindingIsTheDeployersOnceAndClosesForGood() public {
        (PermissionlessLPRegistry r, EscrowStub a, EscrowStub b) = _fresh();
        assertFalse(r.escrowsBound());
        assertEq(r.capOf(lp), 0, "no credit before binding");
        vm.prank(lp);
        vm.expectRevert(PermissionlessLPRegistry.NotBound.selector);
        r.join(MIN);

        vm.prank(stranger);
        vm.expectRevert(PermissionlessLPRegistry.NotDeployer.selector);
        r.bindEscrows(address(a), address(b));

        vm.expectEmit(address(r));
        emit EscrowsBound(address(a), address(b));
        r.bindEscrows(address(a), address(b));
        assertTrue(r.escrowsBound());
        assertTrue(r.isEscrow(address(a)) && r.isEscrow(address(b)));
        assertFalse(r.isEscrow(address(0)) || r.isEscrow(stranger));

        EscrowStub c = new EscrowStub(address(r), TIMEOUT);
        vm.expectRevert(PermissionlessLPRegistry.AlreadyBound.selector);
        r.bindEscrows(address(c), address(b));
        assertEq(r.fiatEscrow(), address(a));
        assertEq(r.offRampEscrow(), address(b));
    }

    function test_BindingRefusesEscrowsThatDoNotFit() public {
        (PermissionlessLPRegistry r, EscrowStub a, EscrowStub b) = _fresh();
        vm.expectRevert(PermissionlessLPRegistry.ZeroAddress.selector);
        r.bindEscrows(address(0), address(b));
        vm.expectRevert(
            abi.encodeWithSelector(PermissionlessLPRegistry.BadEscrow.selector, address(a))
        );
        r.bindEscrows(address(a), address(a));

        // An escrow pointing at another registry.
        EscrowStub elsewhere = new EscrowStub(address(reg), TIMEOUT);
        vm.expectRevert(
            abi.encodeWithSelector(PermissionlessLPRegistry.BadEscrow.selector, address(elsewhere))
        );
        r.bindEscrows(address(elsewhere), address(b));

        // A dispute window that does not end inside the unbonding period: 31 + 1 + 4 = 36 days, not < 36.
        EscrowStub slow = new EscrowStub(address(r), 31 days);
        vm.expectRevert(
            abi.encodeWithSelector(
                PermissionlessLPRegistry.DisputeWindowTooLong.selector,
                address(slow),
                36 days,
                UNBONDING
            )
        );
        r.bindEscrows(address(a), address(slow));

        // A ruling delay other than the escrows' 1 day.
        b.setRulingDelay(2 days);
        vm.expectRevert(
            abi.encodeWithSelector(PermissionlessLPRegistry.BadEscrow.selector, address(b))
        );
        r.bindEscrows(address(a), address(b));
        b.setRulingDelay(1 days);

        vm.expectRevert(
            abi.encodeWithSelector(PermissionlessLPRegistry.NotAContract.selector, stranger)
        );
        r.bindEscrows(stranger, address(b));
        r.bindEscrows(address(a), address(b));
    }

    /// The whole public surface: there is nothing an admin could call.
    function test_ThereIsNoAdminSurface() public {
        string[8] memory admin = [
            "owner()",
            "governor()",
            "pause()",
            "setEscrow(address,bool)",
            "setTier(address,uint8,uint256)",
            "transferOwnership(address)",
            "upgradeTo(address)",
            "completeSetup()"
        ];
        for (uint256 i; i < admin.length; ++i) {
            (bool ok,) = address(reg).call(abi.encodeWithSignature(admin[i]));
            assertFalse(ok, admin[i]);
        }
        // And the deployer's one power is spent.
        vm.expectRevert(PermissionlessLPRegistry.AlreadyBound.selector);
        reg.bindEscrows(address(fiat), address(off));
    }

    /*//////////////////////////////////////////////////////////////
                           JOIN, TOP UP, CREDIT
    //////////////////////////////////////////////////////////////*/

    /// @dev The bond less the 10% haircut the tests deploy with (L-03), in centavos, rounded down.
    function _credit(uint256 bond) internal pure returns (uint256) {
        return bond * 9_000 / 10_000 / 1e16;
    }

    function test_JoinPostsTheBondAndCreditIsTheBondLessTheHaircut() public {
        _join(lp, MIN);
        assertEq(_bond(lp), MIN);
        assertEq(reg.capOf(lp), 450_000, "R$ 5.000,00 bonded is R$ 4.500,00 of credit (L-03)");
        assertEq(reg.availableCents(lp), 450_000);
        assertEq(reg.totalBonded(), MIN);
        assertEq(movva.balanceOf(address(reg)), MIN);
        assertTrue(reg.canQuote(lp, 450_000));
        assertFalse(reg.canQuote(lp, 450_001));
    }

    function test_JoinRefusesBelowTheMinimumOrTwice() public {
        vm.prank(lp);
        vm.expectRevert(
            abi.encodeWithSelector(PermissionlessLPRegistry.BelowMinBond.selector, MIN - 1, MIN)
        );
        reg.join(MIN - 1);
        _join(lp, MIN);
        vm.prank(lp);
        vm.expectRevert(PermissionlessLPRegistry.AlreadyBonded.selector);
        reg.join(MIN);
    }

    function test_JoinWithoutAllowanceReverts() public {
        address poor = makeAddr("poor");
        movva.mint(poor, MIN);
        vm.prank(poor);
        vm.expectRevert();
        reg.join(MIN);
        assertEq(reg.totalBonded(), 0);
    }

    function test_TopUpRaisesTheCredit() public {
        _join(lp, MIN);
        vm.prank(lp);
        reg.topUp(2_500e18);
        assertEq(reg.capOf(lp), 675_000);
        assertEq(reg.totalBonded(), MIN + 2_500e18);
        vm.prank(lp);
        vm.expectRevert(PermissionlessLPRegistry.ZeroAmount.selector);
        reg.topUp(0);
        vm.prank(lp2);
        vm.expectRevert(PermissionlessLPRegistry.NotBonded.selector);
        reg.topUp(1e18);
    }

    function test_CreditRoundsDownToTheCentavo() public {
        _join(lp, MIN + 11_111_111_111_111_109); // just under 1.0 centavo of credit after the haircut
        assertEq(reg.capOf(lp), 450_000, "a part-centavo of credit is no credit");
        vm.prank(lp);
        reg.topUp(10);
        assertEq(reg.capOf(lp), 450_001);
    }

    /*//////////////////////////////////////////////////////////////
                                EXPOSURE
    //////////////////////////////////////////////////////////////*/

    function test_OnlyABoundEscrowReserves() public {
        _join(lp, MIN);
        vm.prank(stranger);
        vm.expectRevert(PermissionlessLPRegistry.NotEscrow.selector);
        reg.reserveExposure(lp, 1);
        vm.expectRevert(PermissionlessLPRegistry.NotEscrow.selector);
        oldEscrow.consumeOn(address(reg), bytes32(uint256(1)));
    }

    function test_ReservationsAcrossBothEscrowsShareOneCredit() public {
        _join(lp, MIN);
        assertTrue(fiat.reserve(lp, 300_000));
        assertTrue(off.reserve(lp, 150_000));
        assertFalse(off.reserve(lp, 1), "the credit is one number across both escrows");
        assertEq(_exposure(lp), 450_000);
        assertEq(reg.reservedBy(address(fiat), lp), 300_000);
        assertEq(reg.reservedBy(address(off), lp), 150_000);
        assertEq(reg.availableCents(lp), 0);
        assertFalse(reg.canQuote(lp, 1));
    }

    function test_NoCreditNoReservationEvenOfZero() public {
        assertFalse(fiat.reserve(lp, 0));
        assertFalse(reg.canQuote(lp, 0));
    }

    function test_AnEscrowReleasesOnlyWhatItReserved() public {
        _join(lp, MIN);
        assertTrue(fiat.reserve(lp, 300_000));
        assertTrue(off.reserve(lp, 100_000));
        off.release(lp, 250_000); // clamps to its own 100_000
        assertEq(_exposure(lp), 300_000);
        assertEq(reg.reservedBy(address(off), lp), 0);
        vm.prank(stranger);
        reg.releaseExposure(lp, 300_000); // reserved nothing: releases nothing, does not revert
        assertEq(_exposure(lp), 300_000);
        fiat.release(lp, 300_000);
        assertEq(_exposure(lp), 0);
    }

    /*//////////////////////////////////////////////////////////////
                           EXIT AND UNBONDING
    //////////////////////////////////////////////////////////////*/

    function test_ExitStopsCreditAtOnce() public {
        _join(lp, MIN);
        assertTrue(fiat.reserve(lp, 100_000));
        vm.prank(lp);
        reg.requestExit();
        assertEq(reg.capOf(lp), 0, "no new business from the block of the request");
        assertFalse(fiat.reserve(lp, 1));
        assertEq(reg.withdrawableFrom(lp), block.timestamp + UNBONDING);
        vm.startPrank(lp);
        vm.expectRevert(PermissionlessLPRegistry.Exiting.selector);
        reg.requestExit();
        vm.expectRevert(PermissionlessLPRegistry.Exiting.selector);
        reg.topUp(1e18);
        vm.expectRevert(PermissionlessLPRegistry.Exiting.selector);
        reg.join(MIN);
        vm.stopPrank();
    }

    function test_WithdrawWaitsForTheUnbondingPeriodAndTheLastPosition() public {
        _join(lp, MIN);
        assertTrue(off.reserve(lp, 100_000));
        vm.prank(lp);
        reg.requestExit();
        uint256 from = block.timestamp + UNBONDING;

        vm.warp(from - 1);
        vm.prank(lp);
        vm.expectRevert(
            abi.encodeWithSelector(PermissionlessLPRegistry.StillUnbonding.selector, from)
        );
        reg.withdraw();

        vm.warp(from);
        vm.prank(lp);
        vm.expectRevert(
            abi.encodeWithSelector(PermissionlessLPRegistry.ExposureLive.selector, 100_000)
        );
        reg.withdraw();

        off.release(lp, 100_000);
        uint256 before = movva.balanceOf(lp);
        vm.prank(lp);
        reg.withdraw();
        assertEq(movva.balanceOf(lp) - before, MIN);
        assertEq(_bond(lp), 0);
        assertEq(reg.totalBonded(), 0);
        assertEq(reg.withdrawableFrom(lp), 0);

        // The exit is over: the address may join again.
        _join(lp, MIN);
        assertEq(reg.capOf(lp), 450_000);
    }

    function test_ExitAndWithdrawNeedABondAndAnExit() public {
        vm.prank(lp);
        vm.expectRevert(PermissionlessLPRegistry.NotBonded.selector);
        reg.requestExit();
        vm.prank(lp);
        vm.expectRevert(PermissionlessLPRegistry.NotExiting.selector);
        reg.withdraw();
    }

    function test_UnbondingIsLongerThanTheEscrowsWholeDisputeWindow() public view {
        uint256 window =
            uint256(fiat.DISPUTE_TIMEOUT()) + off.RULING_DELAY() + reg.UNBONDING_MARGIN();
        assertGt(reg.UNBONDING_PERIOD(), window);
    }

    /*//////////////////////////////////////////////////////////////
                           AUTOMATIC SLASHING
    //////////////////////////////////////////////////////////////*/

    function test_ALostDisputeTakesTheWholeBondWithNoHumanStep() public {
        _join(lp, MIN);
        assertTrue(off.reserve(lp, 150_000));
        off.release(lp, 150_000); // the off-ramp releases the sale's credit, then reports the loss
        vm.expectEmit(address(reg));
        emit Slashed(lp, address(off), MIN);
        off.dispute(lp);

        assertEq(_bond(lp), 0);
        assertEq(reg.capOf(lp), 0, "below the minimum: no credit");
        assertEq(reg.totalBonded(), 0);
        assertEq(reg.totalSlashed(), MIN);
        assertEq(movva.balanceOf(address(reg)), MIN, "slashed MOVVA stays here, locked");
        (,,,,, uint32 lost) = reg.bonds(lp);
        assertEq(lost, 1);
    }

    function test_SlashedMovvaCanNeverLeave() public {
        _join(lp, MIN);
        off.dispute(lp);
        _join(lp2, MIN);
        vm.prank(lp2);
        reg.requestExit();
        vm.warp(block.timestamp + UNBONDING);
        vm.prank(lp2);
        reg.withdraw();
        // Everything bonded is gone again; the slash stays.
        assertEq(movva.balanceOf(address(reg)), MIN);
        assertEq(reg.totalSlashed(), MIN);
        vm.prank(lp);
        vm.expectRevert(PermissionlessLPRegistry.NotExiting.selector);
        reg.withdraw();
    }

    function test_AStrangersDisputeReportIsIgnored() public {
        _join(lp, MIN);
        vm.prank(stranger);
        reg.recordDispute(lp);
        // An escrow of ANOTHER registry (the predecessor's) is a stranger here too.
        vm.prank(address(oldEscrow));
        reg.recordDispute(lp);
        assertEq(_bond(lp), MIN);
        assertEq(reg.totalSlashed(), 0);
    }

    function test_ASlashDuringTheExitStillLands() public {
        _join(lp, MIN);
        assertTrue(fiat.reserve(lp, 100_000));
        vm.prank(lp);
        reg.requestExit();
        vm.warp(block.timestamp + UNBONDING);
        // The LP-disputed order is ruled against it: the escrow releases, then reports.
        fiat.release(lp, 100_000);
        fiat.dispute(lp);
        uint256 before = movva.balanceOf(lp);
        vm.prank(lp);
        reg.withdraw(); // ends the exit, returns nothing
        assertEq(movva.balanceOf(lp), before);
        assertEq(reg.totalSlashed(), MIN);
        _join(lp, MIN); // and may come back with a fresh bond
    }

    function test_LaterLostDisputesTakeWhateverIsBondedThen() public {
        _join(lp, MIN);
        assertTrue(fiat.reserve(lp, 200_000));
        fiat.dispute(lp);
        assertEq(reg.totalSlashed(), MIN);
        fiat.dispute(lp); // nothing left: nothing taken, nothing reverts
        assertEq(reg.totalSlashed(), MIN);
        vm.prank(lp);
        vm.expectRevert(PermissionlessLPRegistry.NotBonded.selector);
        reg.topUp(MIN); // a slashed LP comes back through join, at the minimum
        _join(lp, 2 * MIN);
        assertEq(
            reg.availableCents(lp), 700_000, "the live R$ 2.000,00 counts against the new R$ 9.000,00 of credit"
        );
        fiat.dispute(lp); // a dispute still to be ruled answers to the new bond
        assertEq(reg.totalSlashed(), 3 * MIN);
    }

    function test_RecordSettledCountsAndMovesNoLimit() public {
        _join(lp, MIN);
        fiat.settled(lp, 123_456);
        off.settled(lp, 1);
        vm.prank(stranger);
        reg.recordSettled(lp, 999);
        (,, uint256 settled,, uint32 n,) = reg.bonds(lp);
        assertEq(settled, 123_457);
        assertEq(n, 2);
        assertEq(reg.capOf(lp), 450_000, "settled volume moves no credit");
    }

    /*//////////////////////////////////////////////////////////////
                          BANK TRANSACTION IDS
    //////////////////////////////////////////////////////////////*/

    function test_AnIdSpendsOnceAcrossBothEscrows() public {
        bytes32 id = keccak256("pix e2e 1");
        assertTrue(fiat.consume(id));
        assertFalse(off.consume(id));
        assertFalse(fiat.consume(id));
        assertTrue(reg.usedBankTxId(id));
        assertTrue(reg.spentHere(id));
    }

    function test_AnIdSpentUnderThePredecessorStaysSpent() public {
        bytes32 id = keccak256("pix e2e spent on the old ramp");
        assertTrue(oldEscrow.consume(id)); // on the old registry
        assertTrue(reg.usedBankTxId(id));
        assertFalse(reg.spentHere(id));
        assertFalse(fiat.consume(id));
        assertFalse(off.consume(id));
    }

    function test_AChainOfRegistriesInheritsEverySpentId() public {
        bytes32 a = keccak256("old");
        bytes32 b = keccak256("this");
        oldEscrow.consume(a);
        fiat.consume(b);
        PermissionlessLPRegistry next =
            new PermissionlessLPRegistry(address(movva), address(reg), MIN, UNBONDING, 1_000);
        assertTrue(next.usedBankTxId(a) && next.usedBankTxId(b));
        assertFalse(next.usedBankTxId(keccak256("fresh")));
    }

    function test_WithNoPredecessorOnlyItsOwnIdsAreSpent() public {
        (PermissionlessLPRegistry r, EscrowStub a, EscrowStub b) = _fresh();
        r.bindEscrows(address(a), address(b));
        bytes32 id = keccak256("x");
        oldEscrow.consume(id);
        assertFalse(r.usedBankTxId(id));
        assertTrue(a.consume(id));
    }

    /*//////////////////////////////////////////////////////////////
                      MUST-NOT-REVERT, AND GAS BOUNDS
    //////////////////////////////////////////////////////////////*/

    /// The three paths the escrows run after money has moved: a fixed, small gas cost, whatever the state.
    function test_TheMustNotRevertPathsAreCheapAndBounded() public {
        _join(lp, MIN);
        fiat.reserve(lp, 100_000);
        uint256 g = gasleft();
        fiat.release(lp, 100_000);
        assertLt(g - gasleft(), 40_000, "releaseExposure");
        g = gasleft();
        fiat.settled(lp, 100_000);
        assertLt(g - gasleft(), 70_000, "recordSettled");
        g = gasleft();
        fiat.dispute(lp);
        assertLt(g - gasleft(), 70_000, "recordDispute");
        // With nothing to work on, each still returns.
        fiat.release(lp2, type(uint256).max);
        fiat.dispute(lp2);
        fiat.settled(lp2, type(uint256).max);
    }

    /*//////////////////////////////////////////////////////////////
                                  FUZZ
    //////////////////////////////////////////////////////////////*/

    function testFuzz_CreditIsTheBondInCentavosRoundedDown(uint256 amount) public {
        amount = bound(amount, MIN, 1_000_000e18);
        _join(lp, amount);
        assertEq(reg.capOf(lp), _credit(amount));
        assertLe(reg.capOf(lp) * 1e16, amount * 9_000 / 10_000, "never more credit than the bond less its haircut");
    }

    function testFuzz_ReservationsNeverExceedTheCredit(uint256 bond, uint256[6] memory asks)
        public
    {
        bond = bound(bond, MIN, 100_000e18);
        _join(lp, bond);
        uint256 cap = reg.capOf(lp);
        uint256 live;
        for (uint256 i; i < asks.length; ++i) {
            uint256 ask = bound(asks[i], 0, cap + 1);
            EscrowStub e = i % 2 == 0 ? fiat : off;
            bool ok = e.reserve(lp, ask);
            assertEq(ok, live + ask <= cap, "accepted exactly when it fits");
            if (ok) live += ask;
            assertLe(_exposure(lp), cap);
        }
        assertEq(_exposure(lp), live);
        assertEq(reg.reservedBy(address(fiat), lp) + reg.reservedBy(address(off), lp), live);
    }

    function testFuzz_ReleaseClampsToTheCallersOwnReservation(uint256 reserved, uint256 asked)
        public
    {
        _join(lp, MIN);
        reserved = bound(reserved, 1, 450_000); // the credit of MIN, after the haircut
        assertTrue(off.reserve(lp, reserved));
        off.release(lp, asked);
        uint256 freed = asked > reserved ? reserved : asked;
        assertEq(_exposure(lp), reserved - freed);
        assertEq(reg.reservedBy(address(off), lp), reserved - freed);
    }

    function testFuzz_WithdrawOnlyAfterTheUnbondingPeriod(uint256 wait) public {
        _join(lp, MIN);
        vm.prank(lp);
        reg.requestExit();
        uint256 asked = block.timestamp;
        wait = bound(wait, 0, 2 * UNBONDING);
        vm.warp(asked + wait);
        vm.prank(lp);
        if (wait < UNBONDING) {
            vm.expectRevert(
                abi.encodeWithSelector(
                    PermissionlessLPRegistry.StillUnbonding.selector, asked + UNBONDING
                )
            );
            reg.withdraw();
        } else {
            reg.withdraw();
            assertEq(movva.balanceOf(lp), 1_000_000e18);
        }
    }

    function testFuzz_ASlashConservesMovva(uint256 a, uint256 b, bool exiting) public {
        a = bound(a, MIN, 400_000e18);
        b = bound(b, MIN, 400_000e18);
        _join(lp, a);
        _join(lp2, b);
        if (exiting) {
            vm.prank(lp);
            reg.requestExit();
        }
        off.dispute(lp);
        assertEq(reg.totalSlashed(), a);
        assertEq(reg.totalBonded(), b);
        assertEq(movva.balanceOf(address(reg)), a + b);
        assertEq(reg.capOf(lp2), _credit(b), "nobody else's bond moves");
    }
}
