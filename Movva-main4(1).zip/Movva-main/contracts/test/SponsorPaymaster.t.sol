// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

import {Test} from 'forge-std/Test.sol';
import {SponsorPaymaster, IEntryPoint, PackedUserOperation} from '../SponsorPaymaster.sol';

/// @dev Minimal EntryPoint stand-in: the paymaster only ever calls deposit/withdraw/stake.
contract MockEntryPoint {
  mapping(address => uint256) public balanceOf;
  uint256 public stake;

  function depositTo(address account) external payable {
    balanceOf[account] += msg.value;
  }

  function withdrawTo(address payable to, uint256 amount) external {
    balanceOf[msg.sender] -= amount;
    (bool ok,) = to.call{value: amount}('');
    require(ok, 'withdraw failed');
  }

  function addStake(uint32) external payable {
    stake += msg.value;
  }

  function unlockStake() external {}
  function withdrawStake(address payable) external {}
}

contract SponsorPaymasterTest is Test {
  SponsorPaymaster internal _pm;
  MockEntryPoint internal _ep;

  address internal _owner = makeAddr('OWNER');
  address internal _account = makeAddr('ACCOUNT');
  address internal _stranger = makeAddr('STRANGER');

  function setUp() public {
    _ep = new MockEntryPoint();
    _pm = new SponsorPaymaster(IEntryPoint(address(_ep)), _owner);
  }

  function _op(address sender) internal pure returns (PackedUserOperation memory op) {
    op.sender = sender;
  }

  /*//////////////////////////////////////////////////////////////
                              ACCESS
  //////////////////////////////////////////////////////////////*/

  function test_OnlyEntryPointCanValidate() public {
    vm.prank(_owner);
    _pm.setSponsored(_account, true);

    // Anyone else calling validation must be refused, or an attacker could probe policy
    // and, in a paymaster that kept state, corrupt it.
    vm.expectRevert(SponsorPaymaster.NotEntryPoint.selector);
    _pm.validatePaymasterUserOp(_op(_account), bytes32(0), 1 ether);

    vm.prank(address(_ep));
    (bytes memory ctx, uint256 validationData) =
      _pm.validatePaymasterUserOp(_op(_account), bytes32(0), 1 ether);
    // The context carries only the account, so postOp can bill the budget without
    // re-deriving anything. It deliberately does NOT carry the cost: postOp is told the
    // actual cost, and billing the pessimistic estimate would under-serve honest users.
    assertEq(abi.decode(ctx, (address)), _account, 'context is the account');
    assertEq(validationData, 0, 'valid with no time bounds');
  }

  function test_OnlyEntryPointCanCallPostOp() public {
    vm.expectRevert(SponsorPaymaster.NotEntryPoint.selector);
    _pm.postOp(0, '', 0, 0);

    vm.prank(address(_ep));
    _pm.postOp(0, '', 0, 0); // inert by design
  }

  function test_OnlyOwnerAdministers() public {
    vm.startPrank(_stranger);
    vm.expectRevert(SponsorPaymaster.NotOwner.selector);
    _pm.setSponsored(_stranger, true);
    vm.expectRevert(SponsorPaymaster.NotOwner.selector);
    _pm.setMaxCostAllowed(1);
    vm.expectRevert(SponsorPaymaster.NotOwner.selector);
    _pm.withdrawTo(payable(_stranger), 1);
    vm.expectRevert(SponsorPaymaster.NotOwner.selector);
    _pm.transferOwnership(_stranger);
    vm.stopPrank();
  }

  /*//////////////////////////////////////////////////////////////
                             POLICY
  //////////////////////////////////////////////////////////////*/

  function test_RefusesUnsponsoredAccount() public {
    vm.prank(address(_ep));
    vm.expectRevert(abi.encodeWithSelector(SponsorPaymaster.NotSponsored.selector, _stranger));
    _pm.validatePaymasterUserOp(_op(_stranger), bytes32(0), 1);
  }

  function test_SponsorshipIsRevocable() public {
    vm.startPrank(_owner);
    _pm.setSponsored(_account, true);
    _pm.setSponsored(_account, false);
    vm.stopPrank();

    vm.prank(address(_ep));
    vm.expectRevert(abi.encodeWithSelector(SponsorPaymaster.NotSponsored.selector, _account));
    _pm.validatePaymasterUserOp(_op(_account), bytes32(0), 1);
  }

  function test_EnforcesMaxCost() public {
    vm.startPrank(_owner);
    _pm.setSponsored(_account, true);
    _pm.setMaxCostAllowed(1 ether);
    vm.stopPrank();

    // At the limit is fine; above it is refused, so one absurd gas limit cannot drain
    // the whole deposit.
    vm.prank(address(_ep));
    _pm.validatePaymasterUserOp(_op(_account), bytes32(0), 1 ether);

    vm.prank(address(_ep));
    vm.expectRevert(
      abi.encodeWithSelector(SponsorPaymaster.CostAboveLimit.selector, 1 ether + 1, 1 ether)
    );
    _pm.validatePaymasterUserOp(_op(_account), bytes32(0), 1 ether + 1);
  }

  function testFuzz_MaxCostBoundary(uint128 limit, uint128 cost) public {
    vm.assume(limit > 0);
    vm.startPrank(_owner);
    _pm.setSponsored(_account, true);
    _pm.setMaxCostAllowed(limit);
    vm.stopPrank();

    vm.prank(address(_ep));
    if (cost > limit) {
      vm.expectRevert(
        abi.encodeWithSelector(SponsorPaymaster.CostAboveLimit.selector, cost, limit)
      );
      _pm.validatePaymasterUserOp(_op(_account), bytes32(0), cost);
    } else {
      _pm.validatePaymasterUserOp(_op(_account), bytes32(0), cost);
    }
  }

  function test_ZeroMaxCostMeansUnlimited() public {
    vm.prank(_owner);
    _pm.setSponsored(_account, true);
    vm.prank(address(_ep));
    _pm.validatePaymasterUserOp(_op(_account), bytes32(0), type(uint256).max);
  }

  function test_BatchSponsorship() public {
    address[] memory accounts = new address[](2);
    accounts[0] = _account;
    accounts[1] = _stranger;
    vm.prank(_owner);
    _pm.setSponsoredBatch(accounts, true);
    assertTrue(_pm.sponsored(_account));
    assertTrue(_pm.sponsored(_stranger));
  }

  function test_RejectsZeroAddresses() public {
    vm.prank(_owner);
    vm.expectRevert(SponsorPaymaster.ZeroAddress.selector);
    _pm.setSponsored(address(0), true);

    vm.expectRevert(SponsorPaymaster.ZeroAddress.selector);
    new SponsorPaymaster(IEntryPoint(address(0)), _owner);

    vm.expectRevert(SponsorPaymaster.ZeroAddress.selector);
    new SponsorPaymaster(IEntryPoint(address(_ep)), address(0));
  }

  /*//////////////////////////////////////////////////////////////
                             FUNDING
  //////////////////////////////////////////////////////////////*/

  function test_DepositAndWithdraw() public {
    _pm.deposit{value: 3 ether}();
    assertEq(_pm.getDeposit(), 3 ether);

    // A plain transfer funds the deposit too, so topping up needs no ABI.
    (bool ok,) = address(_pm).call{value: 1 ether}('');
    assertTrue(ok);
    assertEq(_pm.getDeposit(), 4 ether);

    vm.prank(_owner);
    _pm.withdrawTo(payable(_owner), 4 ether);
    assertEq(_pm.getDeposit(), 0);
    assertEq(_owner.balance, 4 ether);
  }

  function test_HoldsNoUserFunds() public {
    // Everything sent to the paymaster goes straight to the EntryPoint deposit; the
    // contract never accumulates a balance a bug could strand.
    _pm.deposit{value: 2 ether}();
    assertEq(address(_pm).balance, 0);
  }

  function test_OwnershipTransfer() public {
    vm.prank(_owner);
    _pm.transferOwnership(_stranger);
    assertEq(_pm.owner(), _stranger);

    vm.prank(_owner);
    vm.expectRevert(SponsorPaymaster.NotOwner.selector);
    _pm.setSponsored(_account, true);
  }
}

/**
 * Budgeting was the residual risk recorded in the first security review: `maxCostAllowed`
 * caps ONE operation but does nothing about an allowlisted account that simply keeps
 * transacting until the sponsor's deposit is gone.
 *
 * ERC-7562 bans TIMESTAMP in validation, so validation cannot ask whether a window has ended.
 * An operation that does not fit the current window comes back with `validAfter` = the window's
 * end; `_dueNow` applies the EntryPoint v0.7's own reading of that value, so these tests check
 * what the EntryPoint would accept, not only what the paymaster returns.
 */
contract SponsorPaymasterBudgetTest is Test {
  SponsorPaymaster internal _pm;
  MockEntryPoint internal _ep;
  address internal _owner = makeAddr('OWNER');
  address internal _account = makeAddr('ACCOUNT');

  uint256 internal constant T0 = 1_700_000_000;

  function setUp() public {
    _ep = new MockEntryPoint();
    _pm = new SponsorPaymaster(IEntryPoint(address(_ep)), _owner);
    vm.startPrank(_owner);
    _pm.setSponsored(_account, true);
    _pm.setBudget(1 days, 1 ether);
    vm.stopPrank();
    vm.warp(T0);
  }

  function _op() internal view returns (PackedUserOperation memory op) {
    op.sender = _account;
  }

  /// @dev One validation on its own, as a bundle of one sees it: its reservation is rolled back after (M-17).
  function _validate(uint256 maxCost) internal returns (bytes memory ctx, uint256 validationData) {
    uint256 snap = vm.snapshot();
    vm.prank(address(_ep));
    (ctx, validationData) = _pm.validatePaymasterUserOp(_op(), bytes32(0), maxCost);
    vm.revertTo(snap);
  }

  function _spend(uint256 amount) internal {
    vm.startPrank(address(_ep));
    (bytes memory ctx,) = _pm.validatePaymasterUserOp(_op(), bytes32(0), amount);
    _pm.postOp(0, ctx, amount, 0);
    vm.stopPrank();
  }

  /// @dev EntryPoint v0.7 `_parseValidationData` and its time-range check (AA32 when false).
  function _dueNow(uint256 validationData) internal view returns (bool) {
    if (address(uint160(validationData)) != address(0)) return false;
    uint48 validUntil = uint48(validationData >> 160);
    uint48 validAfter = uint48(validationData >> 208);
    if (validUntil == 0) validUntil = type(uint48).max;
    return block.timestamp >= validAfter && block.timestamp <= validUntil;
  }

  function _validAfter(uint256 validationData) internal pure returns (uint256) {
    return uint48(validationData >> 208);
  }

  function test_SpendAccumulatesAgainstTheBudget() public {
    _spend(0.4 ether);
    assertEq(_pm.spentSoFar(_account), 0.4 ether);
    _spend(0.4 ether);
    assertEq(_pm.spentSoFar(_account), 0.8 ether);
  }

  function test_AnOpPastTheBudgetWaitsForTheWindowToEnd() public {
    _spend(0.9 ether);
    (bytes memory ctx, uint256 vd) = _validate(0.2 ether);
    assertEq(abi.decode(ctx, (address)), _account);
    assertEq(_validAfter(vd), T0 + 1 days, 'valid from the moment the window ends');
    assertEq(uint48(vd >> 160), 0, 'no expiry');
    assertEq(address(uint160(vd)), address(0), 'not a signature failure');
    assertFalse(_dueNow(vd), 'the EntryPoint refuses it inside the window');

    vm.warp(T0 + 1 days - 1);
    assertFalse(_dueNow(vd), 'still refused one second before the end');
    vm.warp(T0 + 1 days);
    assertTrue(_dueNow(vd), 'accepted once the window has ended');
  }

  function test_AnOpLargerThanAWholeBudgetIsRefusedOutright() public {
    vm.prank(address(_ep));
    vm.expectRevert(
      abi.encodeWithSelector(SponsorPaymaster.BudgetExhausted.selector, _account, 0, 1 ether)
    );
    _pm.validatePaymasterUserOp(_op(), bytes32(0), 1 ether + 1);

    // No window could ever fit it, so waiting for one is not offered either.
    _spend(0.5 ether);
    vm.prank(address(_ep));
    vm.expectRevert(
      abi.encodeWithSelector(SponsorPaymaster.BudgetExhausted.selector, _account, 0.5 ether, 1 ether)
    );
    _pm.validatePaymasterUserOp(_op(), bytes32(0), 1 ether + 1);
  }

  function test_BudgetRollsOverAfterTheWindow() public {
    _spend(1 ether);
    (, uint256 inside) = _validate(1);
    assertFalse(_dueNow(inside), 'exhausted inside the window');

    // A fresh window: the old spend no longer counts.
    vm.warp(block.timestamp + 1 days);
    assertEq(_pm.spentSoFar(_account), 0);
    (bytes memory ctx, uint256 vd) = _validate(1 ether);
    assertTrue(_dueNow(vd), 'a whole budget is available once the window has ended');

    // Settling opens the new window, which counts only this operation.
    vm.prank(address(_ep));
    _pm.postOp(0, ctx, 1 ether, 0);
    assertEq(_pm.windowStartedAt(_account), block.timestamp, 'new window opens at settlement');
    assertEq(_pm.spentInWindow(_account), 1 ether, 'old spend dropped');
    (, uint256 next) = _validate(1);
    assertFalse(_dueNow(next), 'and the new window is exhausted in turn');
    assertEq(_validAfter(next), block.timestamp + 1 days);
  }

  function test_ValidationDoesNotDependOnTheClock() public {
    // The same state validates to the same bytes at any time: the answer is left to the
    // EntryPoint's time-range check, which is what lets validation go without TIMESTAMP.
    _spend(0.9 ether);
    (bytes memory ctxLate, uint256 vdLate) = _validate(0.2 ether);
    (, uint256 vdFits) = _validate(0.05 ether);
    vm.warp(block.timestamp + 365 days);
    (bytes memory ctxLate2, uint256 vdLate2) = _validate(0.2 ether);
    (, uint256 vdFits2) = _validate(0.05 ether);
    assertEq(vdLate, vdLate2);
    assertEq(keccak256(ctxLate), keccak256(ctxLate2));
    assertEq(vdFits, 0);
    assertEq(vdFits2, 0);
    assertTrue(_dueNow(vdLate2), 'a year later the waiting operation is long due');
  }

  function test_WindowIsPerAccount() public {
    address other = makeAddr('OTHER');
    vm.prank(_owner);
    _pm.setSponsored(other, true);
    _spend(1 ether);

    PackedUserOperation memory op;
    op.sender = other;
    vm.prank(address(_ep));
    (, uint256 vd) = _pm.validatePaymasterUserOp(op, bytes32(0), 1 ether);
    assertEq(vd, 0, 'unaffected by _account');
  }

  function test_PerAccountOverrideBeatsTheDefault() public {
    vm.prank(_owner);
    _pm.setAccountBudget(_account, 5 ether);
    assertEq(_pm.budgetFor(_account), 5 ether);
    _spend(3 ether);
    (, uint256 within) = _validate(1 ether);
    assertEq(within, 0);

    // Clearing the override restores the default, which is already exceeded.
    vm.prank(_owner);
    _pm.setAccountBudget(_account, 0);
    assertEq(_pm.budgetFor(_account), 1 ether);
    (, uint256 exceeded) = _validate(1);
    assertFalse(_dueNow(exceeded));
  }

  function test_ZeroWindowDisablesBudgeting() public {
    vm.prank(_owner);
    _pm.setBudget(0, 0);
    for (uint256 i; i < 5; ++i) _spend(100 ether);
    assertEq(_pm.spentSoFar(_account), 0, 'no accounting when disabled');
  }

  function test_WithoutAWindowABudgetCapsEachOperation() public {
    vm.prank(_owner);
    _pm.setBudget(0, 1 ether);
    for (uint256 i; i < 3; ++i) _spend(1 ether);
    assertEq(_pm.spentInWindow(_account), 0, 'nothing recorded');
    vm.prank(address(_ep));
    vm.expectRevert(
      abi.encodeWithSelector(SponsorPaymaster.BudgetExhausted.selector, _account, 0, 1 ether)
    );
    _pm.validatePaymasterUserOp(_op(), bytes32(0), 1 ether + 1);
  }

  function test_OwnerCanResetSpend() public {
    _spend(1 ether);
    vm.prank(_owner);
    _pm.resetSpend(_account);
    assertEq(_pm.spentSoFar(_account), 0);
    (, uint256 vd) = _validate(1 ether);
    assertEq(vd, 0, 'a whole budget again, immediately');
  }

  function test_PostOpNeverReverts() public {
    // postOp runs after the user's call has already executed; a revert there can brick the
    // operation, so every input must be survivable.
    vm.startPrank(address(_ep));
    _pm.postOp(0, '', 1 ether, 0);            // empty context
    _pm.postOp(0, abi.encode(_account, uint256(0)), 0, 0); // zero cost
    _pm.postOp(0, abi.encode(_account, uint256(1 ether)), type(uint256).max, 0); // releases more than is reserved
    _pm.postOp(0, abi.encode(_account, uint256(0)), type(uint256).max, 0); // would overflow; saturates
    vm.stopPrank();
    assertEq(_pm.spentInWindow(_account), type(uint256).max, 'saturated, not wrapped');
  }

  function test_AnAbsurdWindowNeitherRevertsPostOpNorOffersAWait() public {
    vm.prank(_owner);
    _pm.setBudget(type(uint256).max, 1 ether);
    _spend(0.6 ether);
    _spend(0.3 ether); // start + window saturates instead of overflowing
    assertEq(_pm.spentSoFar(_account), 0.9 ether);

    // The window never ends within validAfter's 48 bits: refused, not "valid after never".
    vm.prank(address(_ep));
    vm.expectRevert(
      abi.encodeWithSelector(SponsorPaymaster.BudgetExhausted.selector, _account, 0.9 ether, 1 ether)
    );
    _pm.validatePaymasterUserOp(_op(), bytes32(0), 0.2 ether);
  }

  function test_OnlyOwnerSetsBudgets() public {
    vm.startPrank(makeAddr('STRANGER'));
    vm.expectRevert(SponsorPaymaster.NotOwner.selector);
    _pm.setBudget(1, 1);
    vm.expectRevert(SponsorPaymaster.NotOwner.selector);
    _pm.setAccountBudget(_account, 1);
    vm.expectRevert(SponsorPaymaster.NotOwner.selector);
    _pm.resetSpend(_account);
    vm.stopPrank();
  }

  function testFuzz_NeverExceedsBudgetByMoreThanOneOperation(uint96 a, uint96 b) public {
    vm.assume(a > 0 && b > 0);
    vm.prank(_owner);
    _pm.setBudget(1 days, 1 ether);
    uint256 total;
    for (uint256 i; i < 2; ++i) {
      uint256 amount = i == 0 ? uint256(a) : uint256(b);
      if (_pm.spentSoFar(_account) + amount > 1 ether) break;
      _spend(amount);
      total += amount;
    }
    assertLe(total, 1 ether, 'settled spend never exceeds the budget');
  }

  /// @dev Operations validated and settled one at a time, at fuzzed times, each only if the
  ///      EntryPoint would accept it now: no window ever settles more than its budget.
  function testFuzz_WhatTheEntryPointAcceptsNeverOverrunsAWindow(
    uint64[8] calldata amounts,
    uint32[8] calldata gaps
  ) public {
    for (uint256 i; i < amounts.length; ++i) {
      vm.warp(block.timestamp + (gaps[i] % 2 days));
      uint256 amount = amounts[i] % 1.5 ether;
      vm.prank(address(_ep));
      try _pm.validatePaymasterUserOp(_op(), bytes32(0), amount) returns (
        bytes memory ctx, uint256 vd
      ) {
        assertLe(amount, 1 ether, 'only an operation that fits a whole budget is ever offered');
        if (!_dueNow(vd)) {
          assertGt(_validAfter(vd), block.timestamp, 'a refusal names a future time');
          continue;
        }
        vm.prank(address(_ep));
        _pm.postOp(0, ctx, amount, 0);
        assertLe(_pm.spentInWindow(_account), 1 ether, 'a window never settles past its budget');
      } catch {
        assertGt(amount, 1 ether, 'reverts only for more than a whole budget');
      }
    }
  }

  /// M-17: in one bundle every validation runs before any postOp. Each reserves its maxCost, so the later
  /// operations of the same account see the earlier ones and the bundle cannot overrun the budget.
  function test_M17_OneBundleCannotOverrunTheBudget() public {
    vm.startPrank(address(_ep));
    (bytes memory c1, uint256 v1) = _pm.validatePaymasterUserOp(_op(), bytes32(0), 0.6 ether);
    (bytes memory c2, uint256 v2) = _pm.validatePaymasterUserOp(_op(), bytes32(0), 0.3 ether);
    (, uint256 v3) = _pm.validatePaymasterUserOp(_op(), bytes32(0), 0.2 ether);
    assertEq(v1, 0);
    assertEq(v2, 0);
    assertTrue(v3 != 0, "the third would pass the 1 ether budget: it waits for the next window");
    assertEq(_pm.reservedInFlight(_account), 1.1 ether);
    _pm.postOp(0, c1, 0.5 ether, 0);
    _pm.postOp(0, c2, 0.2 ether, 0);
    vm.stopPrank();
    assertEq(_pm.reservedInFlight(_account), 0.2 ether, "only the unsettled third's reservation is left");
    assertEq(_pm.spentInWindow(_account), 0.7 ether, "billed at the actual cost");
  }
}
