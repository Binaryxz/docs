// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import {ChainlinkBrlOracle, IAggregatorV3} from "../ramp/ChainlinkBrlOracle.sol";

/**
 * The BRL/USD proxy Chainlink's Feed Registry returns, against real mainnet state.
 *
 * Correction, 19 October 2026. This suite was written in September to answer "does a live
 * BRL/USD feed exist on L1?", and it answered no from the proxy the Feed Registry returns,
 * 0x0eBDc65E7e9132Cb41ac5cbD0101B799D7aDb475. Everything it asserts about that proxy is still
 * true - and that proxy is RETIRED:
 *
 *   - it is gated by an access controller that permits only EOA readers, so a contract calling
 *     it gets "No access";
 *   - read as an EOA, its latestRoundData reports updatedAt = 1692977915, 25 August 2023.
 *
 * Chainlink's own feed list (reference-data-directory.vercel.app/feeds-mainnet.json) names the
 * live BRL/USD proxy: 0x3126E7F38D5f60f4E2B6ec3511C7bdbD79317Df1, 8 decimals, 24 h heartbeat,
 * 0.5% deviation, readable by contracts. ChainlinkFxFork.t.sol reads it, and ChainlinkFxOracle
 * is the reserve's FX leg from it. The Feed Registry is not where to look a feed up.
 *
 * Kept so that the retired proxy's state stays asserted - nobody should configure it - and so
 * that the day the registry is updated or the proxy changes, this fails and says so.
 *
 * Skips without FORK_RPC.
 */
contract OracleForkTest is Test {
    /// Chainlink Feed Registry, mainnet.
    address constant REGISTRY = 0x47Fb2585D2C56Fe188D0E6ec628a38b74fCeeeDf;
    /// ISO 4217 numeric codes, as the registry addresses fiat: 986 = BRL, 840 = USD.
    address constant BRL = address(uint160(986));
    address constant USD = address(uint160(840));
    address constant ETH_USD_FEED = 0x5f4eC3Df9cbd43714FE2740f5E3616155c5b8419;

    bool forked;

    function setUp() public {
        string memory rpc = vm.envOr("FORK_RPC", string(""));
        if (bytes(rpc).length == 0) return;
        vm.createSelectFork(rpc);
        forked = true;
    }

    function _brlFeed() internal view returns (address) {
        (bool ok, bytes memory ret) =
            REGISTRY.staticcall(abi.encodeWithSignature("getFeed(address,address)", BRL, USD));
        if (!ok || ret.length != 32) return address(0);
        return abi.decode(ret, (address));
    }

    function test_AChainlinkBrlUsdFeedIsListedOnMainnet() public view {
        if (!forked) return;
        address feed = _brlFeed();
        assertTrue(feed != address(0), "the registry lists a BRL/USD feed");
        assertEq(IAggregatorV3(feed).decimals(), 8);
    }

    /**
     * The finding, and the reason it is asserted rather than commented: if the feed is ever
     * opened to contracts, this fails and tells us the option has appeared.
     *
     * `No access` comes from Chainlink's access-controlled aggregator, which permits only
     * callers where msg.sender == tx.origin. That cannot be satisfied from a contract, so
     * no amount of oracle code fixes it.
     */
    function test_AContractCannotReadThatFeedAtAll() public {
        if (!forked) return;
        // Resolve the feed BEFORE arming the cheatcode: _brlFeed() calls the registry, and
        // a non-reverting call between expectRevert and the call under test consumes it.
        address feed = _brlFeed();
        // The feed reverts with Error(string) "No access" (visible in a -vvvv trace). Forge
        // matches an Error(string) revert against the bare reason bytes; passing the
        // ABI-encoded form instead fails with "No access != revert: No access".
        vm.expectRevert(bytes("No access"));
        IAggregatorV3(feed).latestRoundData();
    }

    /// And so the adapter cannot serve a BRL price on this chain. Reverts, never guesses.
    function test_TheAdapterCannotServeAPriceHere() public {
        if (!forked) return;
        // The longest maxAge allowed, so this fails on the BRL leg's access control rather than on
        // the ETH leg being frozen at the fork block - the ETH feed is healthy on the real
        // chain, and conflating the two would make this test prove the wrong thing.
        address feed = _brlFeed();
        ChainlinkBrlOracle oracle =
            new ChainlinkBrlOracle(ETH_USD_FEED, feed, 2 days, 2 days, address(this), 48 hours);
        oracle.completeSetup(); // so the refusal below is the feed's, not the oracle's setup
        vm.expectRevert(bytes("No access"));
        oracle.brlCentsPerUnit();
    }

    /// The ETH leg is healthy, so the failure is specifically the BRL side.
    /// The ETH leg is readable by contracts and answers, so the blocker is specifically BRL.
    function test_TheEthLegIsReadableAndAnswers() public view {
        if (!forked) return;
        (, int256 answer,,,) = IAggregatorV3(ETH_USD_FEED).latestRoundData();
        assertGt(answer, 0, "ETH/USD answers a contract caller");
        assertEq(IAggregatorV3(ETH_USD_FEED).decimals(), 8);
    }
}
