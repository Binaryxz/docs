// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {IERC4626} from "@openzeppelin/contracts/interfaces/IERC4626.sol";
import {DeployMovva} from "../script/DeployMovva.s.sol";
import {TetherLike, StataLike} from "./ERC4626Adapter.t.sol";
import {FxTestFeed} from "./ChainlinkSignedFxOracle.t.sol";
import {YieldVault} from "../yield/YieldVault.sol";
import {ERC4626Adapter} from "../yield/adapters/ERC4626Adapter.sol";
import {SignedPriceOracle} from "../ramp/SignedPriceOracle.sol";
import {PythFxOracle} from "../ramp/PythFxOracle.sol";
import {ChainlinkFxOracle} from "../ramp/ChainlinkFxOracle.sol";
import {MockBrlUsdAggregator} from "./ChainlinkFxOracle.t.sol";
import {MockPyth} from "./utils/MockPyth.sol";
import {MockPriceSource} from "./MovvaBreaker.t.sol";
import {DivergenceBreaker} from "../movva/DivergenceBreaker.sol";
import {IPriceSource} from "../movva/IPriceSource.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";
import {MovvaReserve} from "../movva/MovvaReserve.sol";
import {FeeSplitter} from "../movva/FeeSplitter.sol";
import {NodeRewards} from "../ramp/NodeRewards.sol";

/**
 * The Movva deployment script, run for real against the test EVM: what it refuses, what it wires,
 * that it hands everything over with setup closed, and that the result mints once publishers sign.
 *
 * One test function, because environment variables are process-wide and forge runs test functions
 * in parallel - which is also why the script reads only MOVVA_-prefixed names.
 */
contract DeployMovvaTest is Test {
    address governor = makeAddr("movva multisig");
    address guardian = makeAddr("movva guardian");
    address yieldTo = makeAddr("movva yield safe");
    address feeTo = makeAddr("movva fee recipient");
    address lp1 = makeAddr("phase-a gateway 1");
    address lp2 = makeAddr("phase-a gateway 2");
    uint256 p1 = uint256(keccak256("movva publisher 1"));
    uint256 p2 = uint256(keccak256("movva publisher 2"));

    TetherLike usdt;
    FxTestFeed feed;
    YieldVault vault;

    function test_TheScriptRefusesUnsafeConfigWiresAndHandsEverythingOver() public {
        vm.warp(1_800_000_000);
        usdt = new TetherLike();
        feed = new FxTestFeed(99_972_163, 8);
        vault = new YieldVault(IERC20(address(usdt)), "Shielded Yield USDT", "syUSDT", governor, guardian, guardian, 1e15, 100, 48 hours);
        ERC4626Adapter adapter = new ERC4626Adapter(address(vault), IERC4626(address(new StataLike(IERC20(address(usdt))))), "stata");
        vm.prank(governor);
        vault.addAdapter(adapter, 10_000);

        vm.setEnv("MOVVA_GOVERNOR", vm.toString(governor));
        vm.setEnv("MOVVA_GUARDIAN", vm.toString(guardian));
        vm.setEnv("MOVVA_FEE_RECIPIENT", vm.toString(feeTo));
        vm.setEnv("MOVVA_USDT", vm.toString(address(usdt)));
        vm.setEnv("MOVVA_USDT_USD_FEED", vm.toString(address(feed)));
        vm.setEnv("MOVVA_FX_PUBLISHERS", string.concat(vm.toString(vm.addr(p1)), ",", vm.toString(vm.addr(p2))));
        vm.setEnv("MOVVA_YIELD_VAULT", vm.toString(address(vault)));
        vm.setEnv("MOVVA_GATEWAYS", string.concat(vm.toString(lp1), ",", vm.toString(lp2)));
        vm.setEnv("MOVVA_MINT_FEE_BPS", "25");
        // The breaker is on by default and needs a source; one already-deployed source stands in here.
        MockPriceSource src = new MockPriceSource();
        src.set(5_399_696_467_956_000_000);
        vm.setEnv("MOVVA_BREAKER_EXTRA_SOURCES", vm.toString(address(src)));

        // 1. Unsafe configurations, each refused before anything is broadcast.
        _refuses("MOVVA_SUPPLY_CAP: a supply cap of zero is not a cap; set one, in whole Movva");
        vm.setEnv("MOVVA_SUPPLY_CAP", "0");
        _refuses("MOVVA_SUPPLY_CAP: a supply cap of zero is not a cap; set one, in whole Movva");
        vm.setEnv("MOVVA_SUPPLY_CAP", "1000000");

        vm.setEnv("MOVVA_FX_MAX_AGE", "0");
        _refuses("MOVVA_FX_MAX_AGE: a max age is seconds, above zero");
        vm.setEnv("MOVVA_FX_MAX_AGE", "3600");
        vm.setEnv("MOVVA_USDT_USD_MAX_AGE", "0");
        _refuses("MOVVA_USDT_USD_MAX_AGE: a max age is seconds, above zero");
        vm.setEnv("MOVVA_USDT_USD_MAX_AGE", "90000");

        feed.set(99_972_163, block.timestamp - 90_001);
        _refuses("MOVVA_USDT_USD_FEED: feed is older than its max age");
        feed.set(0, block.timestamp);
        _refuses("MOVVA_USDT_USD_FEED: feed answers zero or less");
        feed.set(3_000e8, block.timestamp); // ETH/USD where USDT/USD belongs (SRM1-21)
        _refuses("MOVVA_USDT_USD_FEED: answer outside US$ 0.50 to 1.50 (not a dollar stablecoin feed, or the wrong one)");
        feed.set(99_972_163, block.timestamp - 20 hours); // a day-heartbeat feed, still inside its max age

        _refuses("MOVVA_YIELD_VAULT: the vault's own setup is still open");
        vm.prank(governor);
        vault.completeSetup();

        // An existing FX leg whose governor could still change who signs at once: one in setup, one
        // that is not a DelayedGovernance at all (a Chainlink feed pasted by mistake), and one whose
        // delay is shorter than the reserve's. Each is refused before its price is even read.
        SignedPriceOracle open = _fxOracleWith(48 hours, false);
        _publish(open, 5_401_200);
        vm.setEnv("MOVVA_FX_E6_ORACLE", vm.toString(address(open)));
        _refuses(
            "MOVVA_FX_E6_ORACLE: setup still open, or its governance is not delayed: its governor could change who signs the rate at once"
        );
        vm.setEnv("MOVVA_FX_E6_ORACLE", vm.toString(address(feed)));
        _refuses(
            "MOVVA_FX_E6_ORACLE: setup still open, or its governance is not delayed: its governor could change who signs the rate at once"
        );
        SignedPriceOracle quick = _fxOracleWith(24 hours, true);
        _publish(quick, 5_401_200);
        vm.setEnv("MOVVA_FX_E6_ORACLE", vm.toString(address(quick)));
        _refuses(
            "MOVVA_FX_E6_ORACLE: governance delay shorter than MOVVA_GOVERNANCE_DELAY, so a publisher change would give holders less notice"
        );

        // The ramps' centavo FX instance, pointed at by mistake: 540 is not R$ 5,40 at 1e-6.
        SignedPriceOracle centavos = _fxOracle();
        _publish(centavos, 540);
        vm.setEnv("MOVVA_FX_E6_ORACLE", vm.toString(address(centavos)));
        _refuses("MOVVA_FX_E6_ORACLE: not BRL per USD at 1e-6 (the ramps' centavo instance, or the wrong unit signed)");
        SignedPriceOracle stale = _fxOracle();
        _publish(stale, 5_401_200);
        vm.warp(block.timestamp + 3_601);
        vm.setEnv("MOVVA_FX_E6_ORACLE", vm.toString(address(stale)));
        _refuses("MOVVA_FX_E6_ORACLE: no price within MOVVA_FX_MAX_AGE");
        vm.setEnv("MOVVA_FX_E6_ORACLE", "");
        feed.set(99_972_163, block.timestamp);

        // A mint floor above the target is out of order.
        vm.setEnv("MOVVA_TARGET_RATIO_BPS", "10200");
        vm.setEnv("MOVVA_MIN_MINT_RATIO_BPS", "10500");
        _refuses("MOVVA_*_RATIO_BPS: the mint floor may not exceed the target");
        vm.setEnv("MOVVA_TARGET_RATIO_BPS", "");
        vm.setEnv("MOVVA_MIN_MINT_RATIO_BPS", "");

        _principalLockRefusals();

        // Node-provider rewards past what the splitter and NodeRewards would accept.
        vm.setEnv("MOVVA_LP_REWARD_SHARE_BPS", "5001");
        _refuses("MOVVA_LP_REWARD_SHARE_BPS: above 5000, the splitter's cap on the LPs' share of Mova's fees");
        vm.setEnv("MOVVA_LP_REWARD_SHARE_BPS", "");
        vm.setEnv("MOVVA_LP_REWARD_BPS_OF_VOLUME", "21");
        _refuses("MOVVA_LP_REWARD_BPS_OF_VOLUME: above 20, more per real settled than the mint and redeem fees together");
        vm.setEnv("MOVVA_LP_REWARD_BPS_OF_VOLUME", "");
        vm.setEnv("MOVVA_LP_REWARD_EPOCH_SECONDS", "86399");
        _refuses("MOVVA_LP_REWARD_EPOCH_SECONDS: an epoch is 1 to 28 days");
        vm.setEnv("MOVVA_LP_REWARD_EPOCH_SECONDS", "");
        vm.setEnv("MOVVA_LP_REWARD_REVIEW_SECONDS", "1209601");
        _refuses("MOVVA_LP_REWARD_REVIEW_SECONDS: a review period is 1 to 14 days");
        vm.setEnv("MOVVA_LP_REWARD_REVIEW_SECONDS", "");

        // 2. A full deployment with a new FX leg.
        DeployMovva.Deployed memory d = new DeployMovva().run();
        MovvaReserve r = d.reserve;
        assertTrue(d.fxDeployedHere);
        assertTrue(_handedTo(address(r), governor), "handed over");
        assertTrue(r.setupComplete(), "setup closed");
        assertEq(r.GOVERNANCE_DELAY(), 48 hours, "default delay");
        assertTrue(_handedTo(address(SignedPriceOracle(d.fx)), governor), "the FX leg too");
        assertEq(SignedPriceOracle(d.fx).threshold(), 2);
        assertTrue(SignedPriceOracle(d.fx).setupComplete(), "the FX leg's setup closed too");
        assertEq(SignedPriceOracle(d.fx).GOVERNANCE_DELAY(), 48 hours, "with the reserve's delay");
        assertEq(d.movva.RESERVE(), address(r));
        assertEq(address(d.band.SOURCE()), d.fx, "the ramps' adapter reads the same signed leg");
        assertEq(address(r.yieldVault()), address(vault));
        assertTrue(r.isGateway(lp1) && r.isGateway(lp2), "Phase A gateways admitted during setup");
        assertEq(r.supplyCap(), 1_000_000e18);
        assertEq(r.mintFeeBps(), 25, "an override from the environment");
        assertEq(r.redeemFeeBps(), 10, "the traditional-finance default: 0.10% to redeem");
        assertEq(r.targetCollateralRatioBps(), 10_800, "the sized defaults (docs/movva.md, Sizing the buffer)");
        assertEq(r.minMintCollateralRatioBps(), 10_000);
        assertEq(r.usdtUsdMaxAge(), 90_000);
        assertEq(r.fxMaxAge(), 3_600);
        assertEq(r.yieldRecipient(), feeTo, "off mainnet the yield recipient defaults to the treasury");
        assertEq(r.principalUsdt(), 0);
        assertEq(r.guardian(), guardian);
        _assertRewardsWired(d, 0);

        // Nothing prices until the publishers sign; then a gateway mints into the vault.
        vm.expectRevert(SignedPriceOracle.NoPriceYet.selector);
        r.brlPerUsdtE18();
        _publish(SignedPriceOracle(d.fx), 5_401_200);
        (uint256 cents,) = d.band.brlCentsPerUnit();
        assertEq(cents, 540);
        usdt.mint(lp1, 1_000e6);
        vm.startPrank(lp1);
        usdt.approve(address(r), type(uint256).max);
        uint256 out = r.mint(1_000e6, lp1, 0);
        vm.stopPrank();
        // 25 bps of the 1,000 USDT to the fee recipient, in USDT (N-27); 997.5 x 0.99972163 x 5.4012 Movva for the rest.
        assertEq(out, 5_386_197_226_786_110_000_000);
        assertEq(usdt.balanceOf(address(d.splitter)), 2_500_000, "the fee reached the splitter, in USDT");
        assertEq(d.movva.balanceOf(address(d.splitter)), 0);
        d.splitter.split();
        assertEq(usdt.balanceOf(feeTo), 2_500_000, "a share of zero: all of it to the treasury");
        // The reserve booked 997.5 USDT, the mint less its USDT fee (N-27).
        assertEq(vault.totalAssets(), 897_750_000, "MOVVA_MAX_VAULT_BPS: at most 90% of the reserve in the vault (N-03)");
        assertEq(usdt.balanceOf(address(r)), 99_750_000, "the rest idle, payable whatever the vault does");

        // The real governor, once it has accepted (setup was closed, so the handover was a proposal, I-36), waits like
        // everyone else - on the reserve, and on who signs its rate.
        vm.startPrank(governor);
        if (r.governor() != governor) r.acceptGovernor();
        if (SignedPriceOracle(d.fx).governor() != governor) SignedPriceOracle(d.fx).acceptGovernor();
        vm.stopPrank();
        vm.prank(governor);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, MovvaReserve.setGateway.selector));
        r.setGateway(makeAddr("another"), true);
        vm.startPrank(governor);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, SignedPriceOracle.setPublisher.selector)
        );
        SignedPriceOracle(d.fx).setPublisher(makeAddr("another publisher"), true);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, SignedPriceOracle.setThreshold.selector)
        );
        SignedPriceOracle(d.fx).setThreshold(1);
        vm.stopPrank();

        // 3. With an existing millionths FX leg, signed and fresh.
        SignedPriceOracle live = _fxOracle();
        _publish(live, 5_401_200);
        vm.setEnv("MOVVA_FX_E6_ORACLE", vm.toString(address(live)));
        vm.setEnv("MOVVA_GATEWAYS", "");
        // And the rewards settings, every one from the environment.
        vm.setEnv("MOVVA_LP_REWARD_SHARE_BPS", "2500");
        vm.setEnv("MOVVA_LP_REWARD_BPS_OF_VOLUME", "5");
        vm.setEnv("MOVVA_LP_REWARD_CAP_PER_EPOCH", "2000");
        vm.setEnv("MOVVA_LP_REWARD_MIN_CENTS", "5000");
        vm.setEnv("MOVVA_LP_REWARD_EPOCH_SECONDS", "86400");
        vm.setEnv("MOVVA_LP_REWARD_REVIEW_SECONDS", "172800");
        d = new DeployMovva().run();
        assertFalse(d.fxDeployedHere);
        _assertRewardsWired(d, 2_500);
        assertEq(d.rewards.rewardBpsOfVolume(), 5);
        assertEq(d.rewards.maxRewardPerLpPerEpoch(), 2_000e6);
        assertEq(d.rewards.minCountedCents(), 5_000);
        assertEq(d.rewards.EPOCH_LENGTH(), 1 days);
        assertEq(d.rewards.REVIEW_PERIOD(), 2 days);
        for (uint256 i; i < 6; ++i) {
            vm.setEnv(
                ["MOVVA_LP_REWARD_SHARE_BPS", "MOVVA_LP_REWARD_BPS_OF_VOLUME", "MOVVA_LP_REWARD_CAP_PER_EPOCH", "MOVVA_LP_REWARD_MIN_CENTS", "MOVVA_LP_REWARD_EPOCH_SECONDS", "MOVVA_LP_REWARD_REVIEW_SECONDS"][i],
                ""
            );
        }
        assertEq(address(d.reserve.fxOracle()), address(live));
        assertEq(SignedPriceOracle(address(live)).governor(), address(this), "an existing leg's governor is not the script's to move");
        (uint256 rate,) = d.reserve.brlPerUsdtE18();
        assertEq(rate, 5_399_696_467_956_000_000);
        vm.setEnv("MOVVA_FX_E6_ORACLE", "");
        vm.setEnv("MOVVA_MINT_FEE_BPS", "");

        // 4. The default path, Mova's choice: neither publishers nor an existing leg - a PythFxOracle.
        vm.setEnv("MOVVA_FX_PUBLISHERS", "");
        _refuses("MOVVA_PYTH: no Pyth contract at that address on this chain (or set MOVVA_FX_E6_ORACLE / MOVVA_FX_PUBLISHERS)");
        MockPyth pyth = new MockPyth(1);
        vm.setEnv("MOVVA_PYTH", vm.toString(address(pyth)));
        vm.setEnv("MOVVA_FX_CLOSED_MAX_AGE", "345601");
        _refuses("MOVVA_FX_CLOSED_MAX_AGE: above 4 days, which is no longer a market closure");
        vm.setEnv("MOVVA_FX_CLOSED_MAX_AGE", "");

        d = new DeployMovva().run();
        assertTrue(d.fxDeployedHere && d.fxIsPyth);
        PythFxOracle leg = PythFxOracle(d.fx);
        assertEq(address(leg.PYTH()), address(pyth));
        assertEq(leg.usdBrlId(), 0xd2db4dbf1aea74e0f666b0e8f73b9580d407f5e5cf931940b06dc633d7a95906, "FX.USD/BRL by default");
        assertTrue(_handedTo(address(leg), governor), "the Pyth leg handed over");
        assertTrue(leg.setupComplete(), "with setup closed");
        assertEq(leg.GOVERNANCE_DELAY(), 48 hours);
        assertEq(leg.maxAge(), 3_600, "the rate's max age is the reserve's");
        assertEq(leg.closedMaxAge(), 4 days);
        assertEq(leg.maxConfBps(), 100);
        assertEq(address(d.band.SOURCE()), d.fx, "the ramps' adapter reads the same leg");

        // Nothing prices until the keeper posts the feed; then the reserve and the band both do.
        vm.expectRevert(MockPyth.PriceFeedNotFound.selector);
        d.reserve.brlPerUsdtE18();
        pyth.set(leg.usdBrlId(), 540_120, 50, -5, block.timestamp);
        (rate,) = d.reserve.brlPerUsdtE18();
        assertEq(rate, 5_399_696_467_956_000_000);
        (uint256 bandCents,) = d.band.brlCentsPerUnit();
        assertEq(bandCents, 540);
        vm.setEnv("MOVVA_PYTH", "");

        _breakerStep(live, src);
        _handoverStep(live);
        _chainlinkStep();
    }

    /// M-07: MOVVA_LEAVE_SETUP_OPEN=yes hands every contract over with setup open, for the governor to close; and on
    /// chain id 1 the governor must be a contract that is not the deployer.
    function _handoverStep(SignedPriceOracle live) internal {
        vm.setEnv("MOVVA_FX_E6_ORACLE", vm.toString(address(live)));
        vm.setEnv("MOVVA_BREAKER", "off");
        _publish(live, 5_401_200);
        vm.setEnv("MOVVA_LEAVE_SETUP_OPEN", "maybe");
        _refuses("MOVVA_LEAVE_SETUP_OPEN: yes or no");
        vm.setEnv("MOVVA_LEAVE_SETUP_OPEN", "yes");
        DeployMovva.Deployed memory d = new DeployMovva().run();
        DelayedGovernance[3] memory g = [DelayedGovernance(address(d.reserve)), DelayedGovernance(address(d.splitter)), DelayedGovernance(address(d.rewards))];
        for (uint256 i; i < 3; ++i) {
            assertTrue(_handedTo(address(g[i]), governor), "handed over before completeSetup");
            assertFalse(g[i].setupComplete(), "setup left for the governor to close");
        }
        // The deployer can no longer close it: only the governor can.
        vm.expectRevert(DelayedGovernance.NotGovernor.selector);
        d.reserve.completeSetup();
        for (uint256 i; i < 3; ++i) {
            vm.prank(governor);
            g[i].completeSetup();
            assertTrue(g[i].setupComplete());
        }

        // Ethereum mainnet: a key, or the deployer itself, is refused as the governor. (The yield recipient is
        // a Safe here, so the governor is what is refused.)
        uint256 chain = block.chainid;
        vm.chainId(1);
        vm.etch(yieldTo, hex"00");
        vm.setEnv("MOVVA_YIELD_RECIPIENT", vm.toString(yieldTo));
        _refuses("MOVVA_GOVERNOR: on chain id 1 the governor must be a contract (a Safe or a timelock), not a key");
        (, address deployer,) = vm.readCallers();
        vm.setEnv("MOVVA_GOVERNOR", vm.toString(deployer));
        _refuses("MOVVA_GOVERNOR: on chain id 1 the governor is the deployer; name the governor Safe or timelock");
        vm.setEnv("MOVVA_GOVERNOR", vm.toString(governor));
        vm.setEnv("MOVVA_YIELD_RECIPIENT", "");
        vm.chainId(chain);

        vm.setEnv("MOVVA_LEAVE_SETUP_OPEN", "");
        vm.setEnv("MOVVA_BREAKER", "");
        vm.setEnv("MOVVA_FX_E6_ORACLE", "");
    }

    /// MOVVA_FX_SOURCE=chainlink: the preflight against the feed, a keyless leg, the reserve's fxMaxAge set to
    /// cover the heartbeat, and the rate waiting for the core session. Last, because it moves the clock.
    function _chainlinkStep() internal {
        DeployMovva.Deployed memory d;
        // One script for every refusal: each new DeployMovva carries the whole stack's creation code, and this
        // test, a single function for the environment's sake, runs close to the block gas limit.
        DeployMovva script = new DeployMovva();
        MockBrlUsdAggregator brl = new MockBrlUsdAggregator(8);
        brl.set(19_752_930, block.timestamp - 20 hours); // R$ 5,062540 per dollar, yesterday's heartbeat
        vm.setEnv("MOVVA_BREAKER", "off");

        vm.setEnv("MOVVA_FX_SOURCE", "chainlnk");
        _refusesOn(script, "MOVVA_FX_SOURCE: pyth (the default) or chainlink");
        vm.setEnv("MOVVA_FX_SOURCE", "chainlink");
        _refusesOn(script, 
            "MOVVA_CHAINLINK_BRL_USD: no contract at that address on this chain (mainnet: 0x3126E7F38D5f60f4E2B6ec3511C7bdbD79317Df1; Sepolia has no BRL/USD feed)"
        );
        vm.setEnv("MOVVA_CHAINLINK_BRL_USD", vm.toString(address(brl)));
        brl.refuse("No access"); // what the retired proxy, 0x0eBD...b475, answers a contract
        _refusesOn(script, "MOVVA_CHAINLINK_BRL_USD: the feed refuses a contract reader - a retired proxy answers No access; use the live one");
        brl.refuse("");
        // MOVVA_FX_MAX_AGE is still 3600 from the steps above: the Pyth figure refuses a daily feed.
        _refusesOn(script, 
            "MOVVA_FX_MAX_AGE: 25 hours to 2 days for a Chainlink leg, to cover the feed's daily heartbeat on the reserve and the leg alike"
        );
        vm.setEnv("MOVVA_FX_MAX_AGE", "");
        vm.setEnv("MOVVA_FX_PUBLISHERS", string.concat(vm.toString(vm.addr(p1)), ",", vm.toString(vm.addr(p2))));
        _refusesOn(script, "MOVVA_FX_SOURCE=chainlink: unset MOVVA_FX_E6_ORACLE and MOVVA_FX_PUBLISHERS, one FX leg is chosen once");
        vm.setEnv("MOVVA_FX_PUBLISHERS", "");

        brl.setDescription("USD / BRL");
        _refusesOn(script, "MOVVA_CHAINLINK_BRL_USD: its description is not BRL / USD (the wrong feed, or an inverted pair)");
        brl.setDescription("BRL / USD");
        brl.setDecimals(18);
        _refusesOn(script, "MOVVA_CHAINLINK_BRL_USD: decimals differ from MOVVA_CHAINLINK_BRL_USD_DECIMALS (8 on mainnet)");
        brl.setDecimals(8);
        brl.set(19_752_930, block.timestamp - 26 hours - 1);
        _refusesOn(script, "MOVVA_CHAINLINK_BRL_USD: no answer within MOVVA_FX_MAX_AGE on this chain (the feed missed its heartbeat)");
        brl.set(506_254_000, block.timestamp); // an inverted pair: reais per dollar
        _refusesOn(script, "MOVVA_CHAINLINK_BRL_USD: its answer inverts outside the sanity range");
        brl.set(19_752_930, block.timestamp - 20 hours);
        vm.setEnv("MOVVA_FX_CLOSED_MAX_AGE", "3600");
        _refusesOn(script, "MOVVA_FX_CLOSED_MAX_AGE: from MOVVA_FX_MAX_AGE to 4 days for a Chainlink leg");
        vm.setEnv("MOVVA_FX_CLOSED_MAX_AGE", "");
        vm.setEnv("MOVVA_BREAKER", "");
        vm.setEnv("MOVVA_BREAKER_BRL_USD_FEED", vm.toString(address(brl)));
        _refusesOn(script, 
            "MOVVA_BREAKER_BRL_USD_FEED: the FX leg's own feed, so the breaker would compare the leg with itself; use an independent source"
        );
        vm.setEnv("MOVVA_BREAKER_BRL_USD_FEED", "");
        vm.setEnv("MOVVA_BREAKER", "off");

        // v2.0 I-05: the push leg lags up to 0.5%, so a round trip cheaper than that is refused, and the floor is 50 bps.
        vm.setEnv("MOVVA_MINT_FEE_BPS", "10");
        vm.setEnv("MOVVA_REDEEM_FEE_BPS", "10");
        _refusesOn(script, "MOVVA_MINT_FEE_BPS + MOVVA_REDEEM_FEE_BPS: below MOVVA_MIN_ROUND_TRIP_FEE_BPS");
        vm.setEnv("MOVVA_MIN_ROUND_TRIP_FEE_BPS", "20");
        _refusesOn(script, "MOVVA_MIN_ROUND_TRIP_FEE_BPS: a Chainlink FX leg lags up to 0.5%; the round trip must cost at least 50 bps (I-05)");
        vm.setEnv("MOVVA_MIN_ROUND_TRIP_FEE_BPS", "");
        vm.setEnv("MOVVA_MINT_FEE_BPS", "25");
        vm.setEnv("MOVVA_REDEEM_FEE_BPS", "25");

        d = new DeployMovva().run();
        assertTrue(d.fxDeployedHere && d.fxIsChainlink && !d.fxIsPyth);
        assertEq(d.reserve.MIN_ROUND_TRIP_FEE_BPS(), 50, "the push leg's floor");
        ChainlinkFxOracle leg = ChainlinkFxOracle(d.fx);
        assertEq(address(leg.FEED()), address(brl));
        assertEq(leg.MAX_AGE(), 26 hours, "the Chainlink default: the heartbeat and two hours");
        assertEq(d.reserve.fxMaxAge(), 26 hours, "the reserve's fxMaxAge covers the heartbeat too");
        assertEq(leg.CLOSED_MAX_AGE(), 4 days);
        assertEq(leg.MIN_BRL_PER_USD_E6(), 1e6);
        assertEq(leg.MAX_BRL_PER_USD_E6(), 100e6);
        (bool hasGovernor,) = d.fx.call(abi.encodeWithSignature("governor()"));
        assertFalse(hasGovernor, "keyless: nothing was handed over because there is nothing to hand");
        assertEq(address(d.band.SOURCE()), d.fx, "the ramps' adapter reads the same leg");

        // Friday 08:00 UTC, before the core session: the band prices, the rate waits.
        vm.expectRevert(abi.encodeWithSelector(ChainlinkFxOracle.MarketClosed.selector, block.timestamp));
        d.reserve.brlPerUsdtE18();
        (uint256 band, uint64 at) = d.reserve.bandBrlPerUsdtE18();
        assertEq(band, 5_061_130_740_740_200_000, "0.99972163 x 5.062540");
        assertEq(at, block.timestamp);
        (uint256 cents,) = d.band.brlCentsPerUnit();
        assertEq(cents, 506);
        // 14:00 UTC: inside the session the reserve prices on the 26-hour-old-at-most answer.
        vm.warp(block.timestamp + 6 hours);
        feed.set(99_972_163, block.timestamp);
        (uint256 rate, uint64 rateAt) = d.reserve.brlPerUsdtE18();
        assertEq(rate, band);
        assertEq(rateAt, block.timestamp - 26 hours, "the round's own time");

        vm.setEnv("MOVVA_FX_SOURCE", "");
        vm.setEnv("MOVVA_MINT_FEE_BPS", "");
        vm.setEnv("MOVVA_REDEEM_FEE_BPS", "");
        vm.setEnv("MOVVA_CHAINLINK_BRL_USD", "");
        vm.setEnv("MOVVA_BREAKER", "");
    }

    /// The breaker: immutable, wired from the environment, and "no breaker" is a decision. And the yield
    /// recipient, from MOVVA_YIELD_RECIPIENT when it is set.
    function _breakerStep(SignedPriceOracle live, MockPriceSource src) internal {
        DeployMovva.Deployed memory d;
        vm.setEnv("MOVVA_FX_E6_ORACLE", vm.toString(address(live)));
        _publish(live, 5_401_200);
        d = new DeployMovva().run();
        assertEq(address(d.reserve.BREAKER()), address(d.breaker));
        assertEq(d.breaker.BAND_BPS(), 300, "the default band");
        assertTrue(d.breaker.HALTS_REDEEM());
        assertEq(d.breaker.DEAD_AFTER(), 30 days, "SRM1-7: a source dead 30 days stops counting for redemptions");
        assertEq(d.breaker.sourceCount(), 1);
        (IPriceSource s0, bool trips) = d.breaker.sourceAt(0);
        assertEq(address(s0), address(src));
        assertTrue(trips);
        assertFalse(d.reserve.breakerTripped(), "in band");
        src.set(10e18);
        assertTrue(d.reserve.breakerTripped(), "a source far off halts");
        src.set(5_399_696_467_956_000_000);
        assertFalse(d.reserve.breakerTripped(), "and clears by itself");

        vm.setEnv("MOVVA_BREAKER_BAND_BPS", "150");
        vm.setEnv("MOVVA_BREAKER_HALTS_REDEEM", "false");
        vm.setEnv("MOVVA_YIELD_RECIPIENT", vm.toString(yieldTo));
        d = new DeployMovva().run();
        assertEq(d.breaker.BAND_BPS(), 150);
        assertFalse(d.breaker.HALTS_REDEEM());
        assertEq(d.reserve.yieldRecipient(), yieldTo, "MOVVA_YIELD_RECIPIENT");
        vm.setEnv("MOVVA_YIELD_RECIPIENT", "");
        vm.setEnv("MOVVA_BREAKER_BAND_BPS", "");
        vm.setEnv("MOVVA_BREAKER_HALTS_REDEEM", "");

        // SRM1-7: DEAD_AFTER from the environment, inside 7 to 365 days.
        vm.setEnv("MOVVA_BREAKER_DEAD_AFTER", "1209600");
        d = new DeployMovva().run();
        assertEq(d.breaker.DEAD_AFTER(), 14 days);
        vm.setEnv("MOVVA_BREAKER_DEAD_AFTER", "86400");
        _refuses("MOVVA_BREAKER_DEAD_AFTER: 7 to 365 days");
        vm.setEnv("MOVVA_BREAKER_DEAD_AFTER", "31622400");
        _refuses("MOVVA_BREAKER_DEAD_AFTER: 7 to 365 days");
        vm.setEnv("MOVVA_BREAKER_DEAD_AFTER", "");

        // SRM1-20: max ages under the reserve's floors are refused before anything is sent.
        vm.setEnv("MOVVA_USDT_USD_MAX_AGE", "3600");
        _refuses("MOVVA_USDT_USD_MAX_AGE: at least 1 day (the reserve refuses less: SRM1-20)");
        vm.setEnv("MOVVA_USDT_USD_MAX_AGE", "90000");
        vm.setEnv("MOVVA_FX_MAX_AGE", "60");
        _refuses("MOVVA_FX_MAX_AGE: at least 15 minutes (the reserve refuses less: SRM1-20)");
        vm.setEnv("MOVVA_FX_MAX_AGE", "3600");

        vm.setEnv("MOVVA_BREAKER_EXTRA_SOURCES", "");
        _refuses("MOVVA_BREAKER: no source configured (MOVVA_BREAKER_BRL_USD_FEED / _TWAP_POOL / _EXTRA_SOURCES); say MOVVA_BREAKER=off to deploy without a breaker");
        vm.setEnv("MOVVA_BREAKER", "off");
        d = new DeployMovva().run();
        assertEq(address(d.reserve.BREAKER()), address(0));
        assertFalse(d.reserve.breakerTripped());

        vm.setEnv("MOVVA_BREAKER", "");
        vm.setEnv("MOVVA_FX_E6_ORACLE", "");
    }

    /// The fees go through the splitter, the splitter funds NodeRewards, both closed and handed over, nothing bound yet.
    function _assertRewardsWired(DeployMovva.Deployed memory d, uint16 share) internal {
        FeeSplitter s = d.splitter;
        NodeRewards n = d.rewards;
        assertEq(d.reserve.feeRecipient(), address(s), "the reserve pays its fees to the splitter");
        assertEq(s.treasury(), feeTo, "MOVVA_FEE_RECIPIENT is the treasury behind it");
        assertEq(s.rewards(), address(n));
        assertEq(s.lpRewardShareBps(), share);
        // N-27: fees, and so rewards, are USDT; forfeits go to the treasury (I-52).
        assertEq(address(s.TOKEN()), address(d.reserve.USDT()));
        assertEq(address(n.REWARD_TOKEN()), address(d.reserve.USDT()));
        assertEq(n.TOKEN_PER_CENT(), 2_000, "a centavo counted at R$ 5,00 per US$ 1");
        assertEq(n.SINK(), feeTo);
        assertTrue(_handedTo(address(s), governor));
        assertTrue(_handedTo(address(n), governor));
        assertTrue(s.setupComplete() && n.setupComplete());
        assertEq(n.registry(), address(0), "bound later, to the registry DeployRamp deploys");
        if (share == 0) {
            assertEq(n.rewardBpsOfVolume(), 10, "10 bps of volume: the mint fee");
            assertEq(n.maxRewardPerLpPerEpoch(), 2_000e6);
            assertEq(n.minCountedCents(), 1_000);
            assertEq(n.EPOCH_LENGTH(), 7 days);
            assertEq(n.REVIEW_PERIOD(), 3 days);
        }
        // The real governor, once it has accepted, raises the share like any other risk-raising change: through the delay.
        if (s.governor() != governor) {
            vm.prank(governor);
            s.acceptGovernor();
        }
        vm.prank(governor);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, FeeSplitter.setLpRewardShare.selector));
        s.setLpRewardShare(share + 1);
    }

    /// The principal-locked reserve (21 October 2026): the removed hedge path's names are refused if set, so a
    /// stale environment cannot read as configured; on Ethereum mainnet the yield recipient must be a contract.
    function _principalLockRefusals() internal {
        // One script for all of them: each `new DeployMovva()` is most of a block, and this test is near the limit.
        DeployMovva script = new DeployMovva();
        string[5] memory removed = [
            "MOVVA_TREASURER", "MOVVA_HEDGE_TREASURY", "MOVVA_HEDGE_LIMIT_BPS", "MOVVA_MIN_WITHDRAW_RATIO_BPS", "MOVVA_HEDGE_QUEUE_DELAY"
        ];
        for (uint256 i; i < removed.length; ++i) {
            vm.setEnv(removed[i], "1");
            _refusesOn(script, string.concat(removed[i], ": removed with the principal-locked reserve (21 October 2026); unset it"));
            vm.setEnv(removed[i], "");
        }
        // On Ethereum mainnet the yield recipient must be Mova's Safe: a key is refused, before anything is sent.
        uint256 chain = block.chainid;
        vm.chainId(1);
        vm.setEnv("MOVVA_YIELD_RECIPIENT", vm.toString(yieldTo));
        _refusesOn(script, "MOVVA_YIELD_RECIPIENT: on chain id 1 it must be Mova's Safe (a contract), set explicitly or as MOVVA_FEE_RECIPIENT");
        vm.setEnv("MOVVA_YIELD_RECIPIENT", "");
        _refusesOn(script, "MOVVA_YIELD_RECIPIENT: on chain id 1 it must be Mova's Safe (a contract), set explicitly or as MOVVA_FEE_RECIPIENT");
        vm.chainId(chain);
    }

    function _refuses(string memory why) internal {
        _refusesOn(new DeployMovva(), why);
    }

    function _refusesOn(DeployMovva script, string memory why) internal {
        try script.run() {
            revert(string.concat("deployed despite: ", why));
        } catch (bytes memory reason) {
            assertEq(reason, abi.encodeWithSignature("Error(string)", why), why);
        }
    }

    /// A millionths FX leg as an existing deployment would have it: setup closed, the default delay.
    function _fxOracle() internal returns (SignedPriceOracle) {
        return _fxOracleWith(48 hours, true);
    }

    function _fxOracleWith(uint256 delay, bool closeSetup) internal returns (SignedPriceOracle o) {
        address[] memory pubs = new address[](2);
        (pubs[0], pubs[1]) = (vm.addr(p1), vm.addr(p2));
        o = new SignedPriceOracle(address(this), delay, pubs, 2);
        if (closeSetup) o.completeSetup();
    }

    function _publish(SignedPriceOracle o, uint256 value) internal {
        uint64 at = uint64(block.timestamp);
        uint64 seq = o.sequence() + 1;
        bytes32 dg = o.digest(value, at, seq);
        (uint256 lo, uint256 hi) = vm.addr(p1) < vm.addr(p2) ? (p1, p2) : (p2, p1);
        bytes[] memory sigs = new bytes[](2);
        (uint8 v, bytes32 rr, bytes32 s) = vm.sign(lo, dg);
        sigs[0] = abi.encodePacked(rr, s, v);
        (v, rr, s) = vm.sign(hi, dg);
        sigs[1] = abi.encodePacked(rr, s, v);
        o.submit(value, at, seq, sigs);
    }

    /// @dev Handed over: the governor now, or proposed and waiting to accept once setup was closed (I-36).
    function _handedTo(address c, address g) internal view returns (bool) {
        return DelayedGovernance(c).governor() == g || DelayedGovernance(c).pendingGovernor() == g;
    }
}
