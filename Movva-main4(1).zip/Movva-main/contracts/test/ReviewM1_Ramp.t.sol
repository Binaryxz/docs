// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";
import {FiatEscrow} from "../ramp/FiatEscrow.sol";
import {OffRampEscrow} from "../ramp/OffRampEscrow.sol";
import {LPRegistry} from "../ramp/LPRegistry.sol";
import {IAttestorVerifier} from "../ramp/IAttestorVerifier.sol";
import {IPriceOracle} from "../ramp/IPriceOracle.sol";
import {RulingLib} from "../ramp/RulingLib.sol";
import {MockVerifier, MockEntrypoint} from "./FiatEscrow.t.sol";

/// 18-decimal plain ERC-20 standing in for Movva (no hooks, no freeze, no fee).
contract M1Token {
    uint8 public constant decimals = 18;
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    function mint(address to, uint256 v) external {
        balanceOf[to] += v;
    }

    function approve(address s, uint256 v) external returns (bool) {
        allowance[msg.sender][s] = v;
        return true;
    }

    function transfer(address to, uint256 v) external returns (bool) {
        balanceOf[msg.sender] -= v;
        balanceOf[to] += v;
        return true;
    }

    function transferFrom(address f, address t, uint256 v) external returns (bool) {
        if (f != msg.sender) allowance[f][msg.sender] -= v;
        balanceOf[f] -= v;
        balanceOf[t] += v;
        return true;
    }
}

/// Stands in for MovvaReserve.brlCentsPerUnit at full backing: R$ 1,00 = 100 centavos, fresh.
contract M1Reserve is IPriceOracle {
    function brlCentsPerUnit() external view returns (uint256, uint64) {
        return (100, uint64(block.timestamp));
    }
}

/**
 * M1 security review (ramp component) - demonstrations against the MOVVA-only rail's shape:
 * a Movva FiatEscrow / OffRampEscrow pair built with the reserve as `oracle`, native ETH
 * delisted, Movva listed at 18 decimals, ONE arbitrator, ONE institutional LP, and every
 * governor renounced to 0x...dEaD (what `deploy-movva-rail.ts --finalize` leaves).
 *
 * Each `test_M1_*` test PASSES on the current code and in doing so demonstrates the behaviour
 * described in its comment. The `test_M1_Fixed_*` tests are the exception: they began as the
 * demonstrations of SRM1-3, SRM1-4, SRM1-12 and SRM1-13 and now pin the fixes, asserting the
 * opposite, with adversarial tests that the fixes open no opposite abuse.
 */
contract ReviewM1RampTest is Test {
    address constant BURN = 0x000000000000000000000000000000000000dEaD;
    uint256 constant DELAY = 48 hours;
    uint256 constant TIMEOUT = 30 days;
    uint256 constant TAKER_DISPUTE_TIMEOUT = 5 days;
    uint256 constant MAX_VETTING_FEE_BPS = 10;
    uint256 constant ARB_KEY = 0xA2B;
    uint16 constant PIX_MASK = uint16(1 << uint8(IAttestorVerifier.Rail.PIX));

    FiatEscrow onramp;
    OffRampEscrow offramp;
    LPRegistry registry;
    MockVerifier verifier;
    MockEntrypoint entrypoint;
    M1Token movva;
    M1Reserve reserve;

    address gov = makeAddr("gov");
    address lp = makeAddr("lp"); // the rail's only institutional LP
    address taker = makeAddr("taker");
    address seller = makeAddr("seller");
    bytes32 constant LP_PIX = keccak256("lp pix commitment");
    bytes32 constant SELLER_PIX = keccak256("seller pix commitment");

    function setUp() public {
        vm.warp(1_800_000_000);
        movva = new M1Token();
        reserve = new M1Reserve();
        verifier = new MockVerifier();
        entrypoint = new MockEntrypoint();
        registry = new LPRegistry(gov, DELAY);
        onramp = new FiatEscrow(
            address(reserve), address(registry), address(entrypoint), address(entrypoint), 300, gov, DELAY, TIMEOUT,
            TAKER_DISPUTE_TIMEOUT, MAX_VETTING_FEE_BPS
        );
        offramp = new OffRampEscrow(address(reserve), address(registry), 300, gov, DELAY, TIMEOUT);

        vm.startPrank(gov);
        // As DeployRamp._wireMovva, during setup.
        registry.setEscrow(address(onramp), true);
        registry.setEscrow(address(offramp), true);
        onramp.setAsset(address(0), address(reserve), 18, false);
        offramp.setAsset(address(0), address(reserve), 18, false);
        onramp.setAsset(address(movva), address(reserve), 18, true);
        offramp.setAsset(address(movva), address(reserve), 18, true);
        onramp.setVerifier(address(verifier), true);
        onramp.setArbitrator(vm.addr(ARB_KEY), true);
        offramp.setVerifier(address(verifier), true);
        offramp.setArbitrator(vm.addr(ARB_KEY), true);
        registry.setTier(lp, LPRegistry.Tier.INSTITUTIONAL, 5_000_000); // R$ 50.000,00
        registry.completeSetup();
        onramp.completeSetup();
        offramp.completeSetup();
        // --finalize
        registry.renounceGovernor();
        onramp.renounceGovernor();
        offramp.renounceGovernor();
        vm.stopPrank();

        movva.mint(lp, 100_000 ether);
        movva.mint(seller, 100_000 ether);
        vm.prank(lp);
        movva.approve(address(onramp), type(uint256).max);
        vm.prank(seller);
        movva.approve(address(offramp), type(uint256).max);
    }

    /*//////////////////////////////////////////////////////////////
                                 HELPERS
    //////////////////////////////////////////////////////////////*/

    function _sign(address escrow, bytes32 id, string memory outcome)
        internal
        view
        returns (RulingLib.Ruling memory r, bytes memory sig)
    {
        r = RulingLib.Ruling({
            orderId: id,
            outcome: outcome,
            evidenceRoot: keccak256("evidence"),
            rationale: "review",
            ruledAt: uint64(block.timestamp),
            byDefault: false
        });
        bytes32 structHash = keccak256(
            abi.encode(
                keccak256(
                    "Ruling(bytes32 orderId,address escrow,string outcome,bytes32 evidenceRoot,string rationale,uint64 ruledAt,bool byDefault)"
                ),
                r.orderId, escrow, keccak256(bytes(r.outcome)), r.evidenceRoot, keccak256(bytes(r.rationale)),
                r.ruledAt, r.byDefault
            )
        );
        bytes32 domain = keccak256(
            abi.encode(
                keccak256("EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)"),
                keccak256("PrivacyPoolsBRL-Dispute"), keccak256("1"), block.chainid, escrow
            )
        );
        (uint8 v, bytes32 rr, bytes32 ss) = vm.sign(ARB_KEY, keccak256(abi.encodePacked("\x19\x01", domain, structHash)));
        sig = abi.encodePacked(rr, ss, v);
    }

    function _proof(bytes32 id, bytes32 bankTxId, bytes32 payee, uint256 cents) internal {
        verifier.setProof(
            id,
            MockVerifier.Canned({
                bankTxId: bankTxId,
                payeeKeyHash: payee,
                amountBrlCents: cents,
                paidAt: uint64(block.timestamp),
                rail: IAttestorVerifier.Rail.PIX,
                bound: true
            })
        );
    }

    function _postOffer(uint256 amount, uint256 maxOrder) internal returns (bytes32) {
        vm.prank(lp);
        return onramp.postOffer(address(movva), amount, 100, LP_PIX, 1 ether, maxOrder, address(verifier), PIX_MASK);
    }

    /*//////////////////////////////////////////////////////////////
          Q2 - A STOLEN ARBITRATOR KEY AFTER RENUNCIATION (documented)
    //////////////////////////////////////////////////////////////*/

    /**
     * FiatEscrow.sol:819-827 says revoking the arbitrator voids its posted rulings and is the
     * defence against a stolen key; deployments.md "What finalizing costs" says nobody can revoke
     * after --finalize. This performs it: the key holder needs no registry status to be a taker
     * (FiatEscrow._lock makes no registry call), locks the whole offer, disputes, posts RELEASE.
     * The LP sees RulingPosted a day early and can do nothing: closeOffer returns only free
     * liquidity (zero), and setArbitrator(.., false) reverts NotGovernor for everyone.
     */
    function test_M1_StolenArbitratorKeyTakesTheWholeOfferAndNobodyCanRevoke() public {
        bytes32 offerId = _postOffer(10_000 ether, 2_500 ether);
        address thief = makeAddr("thief");
        bytes32[4] memory ids;
        RulingLib.Ruling[4] memory rs;
        bytes[4] memory sigs;
        for (uint256 i; i < 4; ++i) {
            vm.startPrank(thief);
            ids[i] = onramp.lockOrder(offerId, 2_500 ether, FiatEscrow.Delivery.DIRECT, thief, 0);
            onramp.raiseDispute(ids[i], "paid");
            vm.stopPrank();
            (rs[i], sigs[i]) = _sign(address(onramp), ids[i], "RELEASE");
            onramp.resolveDispute(ids[i], rs[i], sigs[i]); // posted, public for RULING_DELAY
        }

        // The LP reacts within the day.
        uint256 before = movva.balanceOf(lp);
        vm.prank(lp);
        onramp.closeOffer(offerId);
        assertEq(movva.balanceOf(lp) - before, 0, "nothing free to withdraw: all of it is disputed");
        // Nobody holds the revocation lever any more.
        vm.prank(gov);
        vm.expectRevert(DelayedGovernance.NotGovernor.selector);
        onramp.setArbitrator(vm.addr(ARB_KEY), false);

        vm.warp(block.timestamp + 1 days);
        for (uint256 i; i < 4; ++i) {
            onramp.resolveDispute(ids[i], rs[i], sigs[i]); // the same ruling again: executes
        }
        assertEq(movva.balanceOf(thief), 10_000 ether, "the whole offer, no BRL paid");
    }

    /*//////////////////////////////////////////////////////////////
     Q1/Q2 - THE ESCROWER CAN PRE-EMPT A VALID PROOF WITH A DISPUTE (new)
    //////////////////////////////////////////////////////////////*/

    /**
     * Was `test_M1_LPPreemptsATakersValidProofAndKeepsBothLegs`. The taker pays the PIX and holds a
     * valid proof; the LP sees the BRL land and disputes first. releaseWithProof used to require
     * LOCKED, so the proof was worthless, and with no ruling the timeout returned the Movva to the
     * LP, which kept the BRL too. Now a valid proof settles the DISPUTED order: the taker is paid,
     * the LP's credit is released, the settlement is recorded, and so is the dispute the LP raised
     * and lost. The dispute is closed (DisputeResolved, no arbitrator, the bank id as evidence) and
     * nothing is left to expire.
     */
    function test_M1_Fixed_LPCannotPreemptATakersValidProof() public {
        bytes32 offerId = _postOffer(1_000 ether, 1_000 ether);
        vm.prank(taker);
        bytes32 orderId = onramp.lockOrder(offerId, 500 ether, FiatEscrow.Delivery.DIRECT, taker, 0);
        // The taker paid R$ 500,00 to the LP's key; a good proof exists.
        bytes32 tx_ = keccak256("E2E-1");
        _proof(orderId, tx_, LP_PIX, 50_000);

        vm.prank(lp);
        onramp.raiseDispute(orderId, "not received");
        assertEq(registry.reservedBy(address(onramp), lp), 100_000, "an LP's dispute keeps its credit reserved");

        // The proof lands days later, with no ruling anywhere: the dispute does not stop it.
        vm.warp(block.timestamp + 10 days);
        vm.expectEmit(true, true, true, true, address(onramp));
        emit FiatEscrow.DisputeResolved(orderId, true, address(0), tx_);
        onramp.releaseWithProof(orderId, "");

        assertEq(movva.balanceOf(taker), 500 ether, "the taker who paid R$ 500,00 has its Movva");
        (,,,,,, FiatEscrow.OrderState st,,,,) = onramp.orders(orderId);
        assertEq(uint8(st), uint8(FiatEscrow.OrderState.RELEASED));
        (, uint256 settledCents, uint32 settlements, uint32 lost,,,) = registry.lps(lp);
        assertEq(settledCents, 50_000, "a completed trade");
        assertEq(settlements, 1);
        assertEq(lost, 1, "and the dispute the LP raised, lost");
        assertEq(registry.reservedBy(address(onramp), lp), 50_000, "credit only for the 500 still offered");
        assertTrue(registry.usedBankTxId(tx_), "the bank transaction is spent ramp-wide");

        vm.warp(block.timestamp + TIMEOUT);
        vm.expectRevert(FiatEscrow.WrongState.selector);
        onramp.expireDispute(orderId);
        vm.prank(lp);
        onramp.closeOffer(offerId);
        assertEq(movva.balanceOf(lp), 100_000 ether - 500 ether, "the LP got back only what it did not sell");
    }

    /**
     * Was `test_M1_SellerPreemptsTheLPsValidProofAndKeepsBothLegs`. The LP claims, pays the seller's
     * PIX, and the seller disputes ahead of settleWithProof. Now the LP's proof settles the DISPUTED
     * sale: the LP has the Movva, its credit is released and its settlement recorded, nothing is
     * recorded against it, and the seller - who has the BRL - cannot also expire its way back.
     */
    function test_M1_Fixed_SellerCannotPreemptTheLPsValidProof() public {
        vm.prank(seller);
        bytes32 saleId = offramp.openSale(address(movva), 500 ether, 50_000, SELLER_PIX, address(verifier), PIX_MASK, seller);
        vm.prank(lp);
        offramp.claimSale(saleId);
        bytes32 tx_ = keccak256("E2E-2");
        _proof(saleId, tx_, SELLER_PIX, 50_000); // the LP paid

        vm.prank(seller);
        offramp.raiseDispute(saleId, "not received");
        vm.expectEmit(true, true, true, true, address(offramp));
        emit OffRampEscrow.DisputeResolved(saleId, true, address(0), tx_);
        offramp.settleWithProof(saleId, "");

        assertEq(movva.balanceOf(lp), 100_000 ether + 500 ether, "LP: paid BRL, received the Movva");
        assertEq(movva.balanceOf(seller), 100_000 ether - 500 ether, "seller: the BRL, not both legs");
        assertEq(registry.reservedBy(address(offramp), lp), 0, "credit released");
        (, uint256 settledCents,, uint32 lost,,,) = registry.lps(lp);
        assertEq(settledCents, 50_000);
        assertEq(lost, 0, "a seller's dispute the LP disproves costs the LP nothing");

        vm.warp(block.timestamp + TIMEOUT);
        vm.expectRevert(OffRampEscrow.WrongState.selector);
        offramp.expireDispute(saleId);
    }

    /**
     * Was `test_M1_AFreeTakerFreezesTheBookAndStallsEveryExit`. A taker escrows nothing and needs
     * no standing; locking the whole book and disputing it kept the LP's credit - one number across
     * both escrows - reserved for DISPUTE_TIMEOUT, so the rail's only LP could claim no off-ramp sale
     * and exits stalled; at the timeout the griefer could expire and re-lock in one transaction. Now
     * a taker's dispute takes the order out of its offer and gives the credit back at once: the LP
     * claims the exit sale in the same block, without even closing its offer. At the timeout the
     * Movva goes to the LP itself, so the griefer's expire-and-re-lock finds nothing to lock.
     */
    function test_M1_Fixed_AFreeTakerCannotFreezeTheLPsCreditOrStallExits() public {
        bytes32 offerId = _postOffer(49_000 ether, 49_000 ether); // R$ 49.000 of the LP's R$ 50.000
        address griefer = makeAddr("griefer");
        vm.startPrank(griefer);
        bytes32 orderId = onramp.lockOrder(offerId, 49_000 ether, FiatEscrow.Delivery.DIRECT, griefer, 0);
        onramp.raiseDispute(orderId, "paid");
        vm.stopPrank();
        assertEq(registry.reservedBy(address(onramp), lp), 0, "the taker's dispute holds none of the LP's credit");
        assertEq(registry.availableCents(lp), 5_000_000, "all R$ 50.000 free");

        vm.prank(seller);
        bytes32 saleId = offramp.openSale(address(movva), 2_000 ether, 200_000, SELLER_PIX, address(verifier), PIX_MASK, seller);
        vm.prank(lp);
        offramp.claimSale(saleId); // the exit goes ahead
        _proof(saleId, keccak256("E2E-EXIT"), SELLER_PIX, 200_000);
        offramp.settleWithProof(saleId, "");
        assertEq(movva.balanceOf(seller), 100_000 ether - 2_000 ether, "the holder is out to PIX");

        // 30 days later the griefer expires its own dispute and tries to lock the same Movva again.
        vm.warp(block.timestamp + TIMEOUT);
        uint256 before = movva.balanceOf(lp);
        vm.startPrank(griefer);
        onramp.expireDispute(orderId);
        vm.expectRevert(FiatEscrow.InsufficientLiquidity.selector);
        onramp.lockOrder(offerId, 49_000 ether, FiatEscrow.Delivery.DIRECT, griefer, 0);
        vm.stopPrank();
        assertEq(movva.balanceOf(lp) - before, 49_000 ether, "the disputed Movva went to the LP, not the offer");
        (,, uint256 available, uint256 locked,,,,,,,,) = onramp.offers(offerId);
        assertEq(available + locked, 0, "nothing left in the offer to grief");
        (,,, uint32 lost,,,) = registry.lps(lp);
        assertEq(lost, 0, "the griefer's unanswered dispute costs the LP nothing");
    }

    /*//////////////////////////////////////////////////////////////
      SRM1-3 / SRM1-4 - ADVERSARIAL: THE FIXES OPEN NO OPPOSITE ABUSE
    //////////////////////////////////////////////////////////////*/

    function _canned(bytes32 id, bytes32 bankTxId, bytes32 payee, uint256 cents, uint64 paidAt) internal {
        verifier.setProof(
            id,
            MockVerifier.Canned({
                bankTxId: bankTxId, payeeKeyHash: payee, amountBrlCents: cents, paidAt: paidAt,
                rail: IAttestorVerifier.Rail.PIX, bound: true
            })
        );
    }

    function _lockedOrder(uint256 amount) internal returns (bytes32 offerId, bytes32 orderId) {
        offerId = _postOffer(1_000 ether, 1_000 ether);
        vm.prank(taker);
        orderId = onramp.lockOrder(offerId, amount, FiatEscrow.Delivery.DIRECT, taker, 0);
    }

    /// A dispute stops the clock for proving, never for paying: a taker who disputes to keep its order
    /// alive cannot then pay after payBy (at a better rate) and settle. Nor can the LP's dispute, nor
    /// any other: the receipt must fall in [lockedAt, payBy].
    function test_M1_Fixed_ADisputeBuysNoTimeToPayLate() public {
        (, bytes32 orderId) = _lockedOrder(500 ether);
        (,,,, uint64 lockedAt, uint64 payBy,,,,,) = onramp.orders(orderId);
        vm.prank(taker);
        onramp.raiseDispute(orderId, "attestor down");
        vm.warp(payBy + 1 hours);
        _canned(orderId, keccak256("LATE"), LP_PIX, 50_000, payBy + 1);
        vm.expectRevert(FiatEscrow.WindowExpired.selector);
        onramp.releaseWithProof(orderId, "");
        _canned(orderId, keccak256("EARLY"), LP_PIX, 50_000, lockedAt - 1);
        vm.expectRevert(FiatEscrow.ReceiptPredatesOrder.selector);
        onramp.releaseWithProof(orderId, "");
        // The last second of the window is still inside it.
        _canned(orderId, keccak256("ON-TIME"), LP_PIX, 50_000, payBy);
        onramp.releaseWithProof(orderId, "");
        assertEq(movva.balanceOf(taker), 500 ether);
    }

    /// A proof of a different payment cannot settle a disputed order: another payee, too little, a
    /// bank transaction already spent on the other escrow, or a proof bound to another order.
    function test_M1_Fixed_OnlyThisOrdersPaymentSettlesItsDispute() public {
        (, bytes32 orderId) = _lockedOrder(500 ether);
        vm.prank(lp);
        onramp.raiseDispute(orderId, "not received");

        _canned(orderId, keccak256("A"), keccak256("someone else's key"), 50_000, uint64(block.timestamp));
        vm.expectRevert(FiatEscrow.WrongPayee.selector);
        onramp.releaseWithProof(orderId, "");

        _canned(orderId, keccak256("B"), LP_PIX, 49_999, uint64(block.timestamp));
        vm.expectRevert(FiatEscrow.Underpaid.selector);
        onramp.releaseWithProof(orderId, "");

        // A PIX that already settled a sale on the off-ramp (same payee commitment) cannot settle this.
        vm.prank(seller);
        bytes32 saleId = offramp.openSale(address(movva), 500 ether, 50_000, LP_PIX, address(verifier), PIX_MASK, seller);
        vm.prank(lp);
        offramp.claimSale(saleId);
        _canned(saleId, keccak256("SPENT"), LP_PIX, 50_000, uint64(block.timestamp));
        offramp.settleWithProof(saleId, "");
        _canned(orderId, keccak256("SPENT"), LP_PIX, 50_000, uint64(block.timestamp));
        vm.expectRevert(FiatEscrow.ReceiptReplayed.selector);
        onramp.releaseWithProof(orderId, "");

        // A proof the verifier does not bind to this order.
        verifier.setProof(
            orderId,
            MockVerifier.Canned({
                bankTxId: keccak256("C"), payeeKeyHash: LP_PIX, amountBrlCents: 50_000,
                paidAt: uint64(block.timestamp), rail: IAttestorVerifier.Rail.PIX, bound: false
            })
        );
        vm.expectRevert("proof not bound to this order");
        onramp.releaseWithProof(orderId, "");

        (,,,,,, FiatEscrow.OrderState st,,,,) = onramp.orders(orderId);
        assertEq(uint8(st), uint8(FiatEscrow.OrderState.DISPUTED), "still in dispute");
        assertEq(movva.balanceOf(taker), 0);
    }

    /// From the dispute's deadline on, only the default applies: a proof cannot race expireDispute.
    function test_M1_Fixed_AProofAfterTheDisputeDeadlineIsRefused() public {
        (, bytes32 orderId) = _lockedOrder(500 ether);
        _proof(orderId, keccak256("E2E"), LP_PIX, 50_000);
        vm.prank(lp);
        onramp.raiseDispute(orderId, "not received");
        uint64 deadline = uint64(block.timestamp + TIMEOUT);
        vm.warp(deadline);
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.DisputeExpired.selector, deadline));
        onramp.releaseWithProof(orderId, "");

        // The same on the off-ramp.
        vm.prank(seller);
        bytes32 saleId = offramp.openSale(address(movva), 500 ether, 50_000, SELLER_PIX, address(verifier), PIX_MASK, seller);
        vm.prank(lp);
        offramp.claimSale(saleId);
        _proof(saleId, keccak256("E2E-S"), SELLER_PIX, 50_000);
        vm.prank(seller);
        offramp.raiseDispute(saleId, "x");
        deadline = uint64(block.timestamp + TIMEOUT);
        vm.warp(deadline);
        vm.expectRevert(abi.encodeWithSelector(OffRampEscrow.DisputeExpired.selector, deadline));
        offramp.settleWithProof(saleId, "");
    }

    /// The receipt's age is taken when the dispute froze the order, so a slow proof still settles;
    /// a dispute raised long after the payment, on a lapsed order nobody reclaimed, does not revive it -
    /// since H-04 the taker cannot raise it at all once the pay window has closed.
    function test_M1_Fixed_TheReceiptAgeIsTakenAtTheFreeze() public {
        (, bytes32 orderId) = _lockedOrder(500 ether);
        (,,,,, uint64 payBy,,,,,) = onramp.orders(orderId);
        _canned(orderId, keccak256("E2E"), LP_PIX, 50_000, payBy - 1);
        vm.warp(payBy + 1 days); // lapsed, never reclaimed
        vm.prank(taker);
        vm.expectRevert(FiatEscrow.WindowExpired.selector);
        onramp.raiseDispute(orderId, "paid, proof was slow");

        (, bytes32 second) = _lockedOrder(500 ether);
        (,,,,, payBy,,,,,) = onramp.orders(second);
        _canned(second, keccak256("E2E-2"), LP_PIX, 50_000, payBy - 1);
        vm.warp(payBy); // disputed in time
        vm.prank(taker);
        onramp.raiseDispute(second, "paid, proof is slow");
        vm.warp(block.timestamp + 4 days); // RECEIPT_MAX_AGE is one day, but the clock stopped
        onramp.releaseWithProof(second, "");
        assertEq(movva.balanceOf(taker), 500 ether);
    }

    /// A taker who disputes in bad faith and then proves costs the honest LP nothing: no lost
    /// dispute, the settlement recorded, and its credit was free all along.
    function test_M1_Fixed_ATakersDisputeThenProofDoesNotPenaliseTheLP() public {
        (, bytes32 orderId) = _lockedOrder(500 ether);
        vm.prank(taker);
        onramp.raiseDispute(orderId, "freezing it for fun");
        _proof(orderId, keccak256("E2E"), LP_PIX, 50_000);
        onramp.releaseWithProof(orderId, "");
        (, uint256 settledCents,, uint32 lost,,,) = registry.lps(lp);
        assertEq(settledCents, 50_000);
        assertEq(lost, 0);
        assertEq(registry.reservedBy(address(onramp), lp), 50_000, "credit only for the 500 still offered");
    }

    /// On the off-ramp the LP may dispute its own claim when the attestor is down and prove later; it is
    /// not penalised. It cannot dispute to pay late: that refunds the seller and counts against it.
    function test_M1_Fixed_AnLPsOwnDisputeKeepsItsProofButBuysNoTime() public {
        vm.startPrank(seller);
        bytes32 paid = offramp.openSale(address(movva), 500 ether, 50_000, SELLER_PIX, address(verifier), PIX_MASK, seller);
        bytes32 late = offramp.openSale(address(movva), 500 ether, 50_000, SELLER_PIX, address(verifier), PIX_MASK, seller);
        vm.stopPrank();
        vm.startPrank(lp);
        offramp.claimSale(paid);
        offramp.claimSale(late);
        offramp.raiseDispute(paid, "paid; attestor down");
        offramp.raiseDispute(late, "will pay later");
        vm.stopPrank();
        (,,,,,,,,, uint64 payBy,,) = offramp.sales(paid);
        _canned(paid, keccak256("ON-TIME"), SELLER_PIX, 50_000, payBy);
        vm.warp(payBy + 5 days);
        _canned(late, keccak256("LATE"), SELLER_PIX, 50_000, payBy + 1);
        offramp.settleWithProof(paid, "");
        vm.expectRevert(OffRampEscrow.WindowExpired.selector);
        offramp.settleWithProof(late, "");
        vm.warp(block.timestamp + TIMEOUT);
        offramp.expireDispute(late);
        (,,, uint32 lost,,,) = registry.lps(lp);
        assertEq(lost, 1, "only the dispute raised to pay late counts");
        assertEq(movva.balanceOf(seller), 100_000 ether - 500 ether, "the late sale was refunded to the seller");
        assertEq(registry.reservedBy(address(offramp), lp), 0);
    }

    /// A proof pre-empts a posted ruling: the REFUND the desk posted can never execute afterwards.
    function test_M1_Fixed_AProofPreemptsAPostedRuling() public {
        (bytes32 offerId, bytes32 orderId) = _lockedOrder(500 ether);
        vm.prank(lp);
        onramp.raiseDispute(orderId, "not received");
        (RulingLib.Ruling memory r, bytes memory sig) = _sign(address(onramp), orderId, "REFUND");
        onramp.resolveDispute(orderId, r, sig); // posted
        _proof(orderId, keccak256("E2E"), LP_PIX, 50_000);
        onramp.releaseWithProof(orderId, "");
        vm.warp(block.timestamp + 1 days);
        vm.expectRevert(FiatEscrow.WrongState.selector);
        onramp.resolveDispute(orderId, r, sig);
        (,, uint256 available, uint256 locked,,,,,,,,) = onramp.offers(offerId);
        assertEq(available, 500 ether);
        assertEq(locked, 0);
        assertEq(movva.balanceOf(taker), 500 ether);
    }

    /// An LP cannot free its credit by disputing its own orders: only a taker's dispute detaches.
    function test_M1_Fixed_AnLPsOwnDisputeKeepsItsCreditReserved() public {
        (bytes32 offerId, bytes32 orderId) = _lockedOrder(500 ether);
        vm.prank(lp);
        onramp.raiseDispute(orderId, "x");
        assertEq(registry.reservedBy(address(onramp), lp), 100_000);
        (,,, uint256 locked,,,,,,,,) = onramp.offers(offerId);
        assertEq(locked, 500 ether, "still in the offer");
        vm.warp(block.timestamp + TIMEOUT);
        onramp.expireDispute(orderId);
        (,, uint256 available,,,,,,,,,) = onramp.offers(offerId);
        assertEq(available, 1_000 ether, "an LP's own expired dispute returns to its offer");
        assertEq(registry.reservedBy(address(onramp), lp), 100_000);
    }

    /// A taker's dispute frees exactly that order's share of the credit, whatever the ruling: a RELEASE
    /// pays the taker without touching the offer, a REFUND pays the LP directly.
    function test_M1_Fixed_ATakerDisputedOrderSettlesApartFromItsOffer() public {
        bytes32 offerId = _postOffer(1_000 ether, 1_000 ether);
        vm.startPrank(taker);
        bytes32 a = onramp.lockOrder(offerId, 300 ether, FiatEscrow.Delivery.DIRECT, taker, 0);
        bytes32 b = onramp.lockOrder(offerId, 200 ether, FiatEscrow.Delivery.DIRECT, taker, 0);
        onramp.raiseDispute(a, "x");
        onramp.raiseDispute(b, "y");
        vm.stopPrank();
        assertEq(registry.reservedBy(address(onramp), lp), 50_000, "credit for the 500 never disputed");
        (RulingLib.Ruling memory ra, bytes memory sa) = _sign(address(onramp), a, "RELEASE");
        (RulingLib.Ruling memory rb, bytes memory sb) = _sign(address(onramp), b, "REFUND");
        onramp.resolveDispute(a, ra, sa);
        onramp.resolveDispute(b, rb, sb);
        vm.warp(block.timestamp + 1 days);
        uint256 lpBefore = movva.balanceOf(lp);
        onramp.resolveDispute(a, ra, sa);
        onramp.resolveDispute(b, rb, sb);
        assertEq(movva.balanceOf(taker), 300 ether, "RELEASE paid the taker");
        assertEq(movva.balanceOf(lp) - lpBefore, 200 ether, "REFUND paid the LP directly");
        (,, uint256 available, uint256 locked,,,,,,,,) = onramp.offers(offerId);
        assertEq(available, 500 ether);
        assertEq(locked, 0);
        assertEq(registry.reservedBy(address(onramp), lp), 50_000, "unchanged by either ruling");
        assertEq(movva.balanceOf(address(onramp)), 500 ether, "the escrow holds exactly the offer");
    }

    /// Many free takers (sybils, sponsored accounts) lock and dispute the whole book: the LP's credit
    /// is untouched by all of them, so every exit can still be claimed.
    function testFuzz_M1_Fixed_NoNumberOfTakerDisputesHoldsTheLPsCredit(uint8 n) public {
        n = uint8(bound(n, 1, 40));
        bytes32 offerId = _postOffer(40_000 ether, 1_000 ether);
        for (uint256 i; i < n; ++i) {
            address g = address(uint160(0xBAD000 + i));
            vm.startPrank(g);
            bytes32 id = onramp.lockOrder(offerId, 1_000 ether, FiatEscrow.Delivery.DIRECT, g, 0);
            onramp.raiseDispute(id, "grief");
            vm.stopPrank();
        }
        assertEq(registry.reservedBy(address(onramp), lp), (40_000 - uint256(n) * 1_000) * 100);
        vm.prank(lp);
        onramp.closeOffer(offerId);
        assertEq(registry.availableCents(lp), 5_000_000, "the whole limit is free for exits");
    }

    /*//////////////////////////////////////////////////////////////
     Q3 - RECEIPT REPLAY STATE IS SHARED BY BOTH ESCROWS (SRM1-12, fixed)
    //////////////////////////////////////////////////////////////*/

    /// An order and a sale that both name the LP's payee commitment, each ready to settle.
    function _orderAndSaleOnOnePayee() internal returns (bytes32 orderId, bytes32 saleId) {
        bytes32 offerId = _postOffer(1_000 ether, 1_000 ether);
        vm.prank(taker);
        orderId = onramp.lockOrder(offerId, 500 ether, FiatEscrow.Delivery.DIRECT, taker, 0);
        vm.prank(seller);
        saleId = offramp.openSale(address(movva), 500 ether, 50_000, LP_PIX, address(verifier), PIX_MASK, seller);
        vm.prank(lp);
        offramp.claimSale(saleId);
    }

    /**
     * Was `test_M1_OneBankTxIdSettlesAnOrderAndASale`. `usedBankTxId` was per escrow, so one PIX
     * settled an on-ramp order AND an off-ramp sale naming the same payee commitment (a commitment
     * is public: offers(id).pixKeyHash), given two zkTLS sessions of the same receipt bound to two
     * ids - which the payer or payee of that PIX can produce. The id is now spent in the registry
     * both escrows share: the second settlement is refused, and the sale stays CLAIMED.
     */
    function test_M1_Fixed_OneBankTxIdCannotSettleAnOrderAndASale() public {
        (bytes32 orderId, bytes32 saleId) = _orderAndSaleOnOnePayee();
        bytes32 tx_ = keccak256("E2E-ONE-PIX");
        _proof(orderId, tx_, LP_PIX, 50_000);
        _proof(saleId, tx_, LP_PIX, 50_000);

        onramp.releaseWithProof(orderId, "");
        vm.expectRevert(OffRampEscrow.ReceiptReplayed.selector);
        offramp.settleWithProof(saleId, "");

        assertTrue(registry.usedBankTxId(tx_), "spent in the registry");
        assertTrue(offramp.usedBankTxId(tx_), "and the off-ramp says so (the on-ramp no longer repeats the registry's view)");
        (,,,,,,,,,,, OffRampEscrow.SaleState st) = offramp.sales(saleId);
        assertEq(uint8(st), uint8(OffRampEscrow.SaleState.CLAIMED), "the sale did not settle");
        assertEq(movva.balanceOf(lp), 100_000 ether - 1_000 ether, "the LP was paid nothing off the sale");
    }

    /// The same, the other way round: a PIX that settled a sale cannot then settle an order.
    function test_M1_Fixed_ABankTxIdSpentOnASaleCannotSettleAnOrder() public {
        (bytes32 orderId, bytes32 saleId) = _orderAndSaleOnOnePayee();
        bytes32 tx_ = keccak256("E2E-ONE-PIX");
        _proof(orderId, tx_, LP_PIX, 50_000);
        _proof(saleId, tx_, LP_PIX, 50_000);

        offramp.settleWithProof(saleId, "");
        vm.expectRevert(FiatEscrow.ReceiptReplayed.selector);
        onramp.releaseWithProof(orderId, "");
        (,,,,,, FiatEscrow.OrderState st,,,,) = onramp.orders(orderId);
        assertEq(uint8(st), uint8(FiatEscrow.OrderState.LOCKED), "the order did not release");
        assertEq(movva.balanceOf(taker), 0);
    }

    /// Nobody but an escrow can spend an id: burning a victim's receipt ahead of its proof fails.
    function test_M1_Fixed_NobodyCanBurnABankTxIdAheadOfItsProof() public {
        (bytes32 orderId,) = _orderAndSaleOnOnePayee();
        bytes32 tx_ = keccak256("E2E-VICTIM");
        vm.prank(makeAddr("griefer"));
        vm.expectRevert(LPRegistry.NotEscrow.selector);
        registry.consumeBankTxId(tx_);
        _proof(orderId, tx_, LP_PIX, 50_000);
        onramp.releaseWithProof(orderId, "");
        assertEq(movva.balanceOf(taker), 500 ether, "the genuine proof still settles");
    }

    /**
     * Fuzzed: positions on both escrows, each presented with a bank transaction id drawn from a
     * pool of three. However the ids repeat and interleave, each id settles at most one position
     * across the two escrows, and every position that settled holds a distinct id.
     */
    function testFuzz_M1_Fixed_ABankTxIdSettlesOncePerRamp(uint256 seed) public {
        bytes32 offerId = _postOffer(10_000 ether, 1_000 ether);
        uint256[3] memory settledWith;
        for (uint256 i; i < 6; ++i) {
            uint256 r = uint256(keccak256(abi.encode(seed, i)));
            uint256 k = r % 3;
            bytes32 tx_ = keccak256(abi.encode("E2E", k));
            bool ok;
            if ((r >> 8) % 2 == 0) {
                vm.prank(taker);
                bytes32 orderId = onramp.lockOrder(offerId, 10 ether, FiatEscrow.Delivery.DIRECT, taker, 0);
                _proof(orderId, tx_, LP_PIX, 1_000);
                try onramp.releaseWithProof(orderId, "") {
                    ok = true;
                } catch (bytes memory err) {
                    assertEq(bytes4(err), FiatEscrow.ReceiptReplayed.selector);
                }
            } else {
                vm.prank(seller);
                bytes32 saleId =
                    offramp.openSale(address(movva), 10 ether, 1_000, LP_PIX, address(verifier), PIX_MASK, seller);
                vm.prank(lp);
                offramp.claimSale(saleId);
                _proof(saleId, tx_, LP_PIX, 1_000);
                try offramp.settleWithProof(saleId, "") {
                    ok = true;
                } catch (bytes memory err) {
                    assertEq(bytes4(err), OffRampEscrow.ReceiptReplayed.selector);
                }
            }
            if (ok) ++settledWith[k];
            assertLe(settledWith[k], 1, "one bank transaction, one settlement");
            assertEq(registry.usedBankTxId(tx_), true);
        }
    }

    /*//////////////////////////////////////////////////////////////
       Q1/Q6 - A STALE CLAIM CANNOT BE RENEWED TO BLOCK CANCEL (SRM1-13, fixed)
    //////////////////////////////////////////////////////////////*/

    /**
     * Was `test_M1_AnLPCanRenewAStaleClaimForeverAtNoCost`. releaseStaleClaim + claimSale (or
     * abandonClaim + claimSale) in one transaction renewed a claim before the seller could reach
     * cancelSale, which needed OPEN. Now a stale claim is cancellable by the seller directly, and
     * a claim that ends unsettled starts CLAIM_COOLDOWN, in which nobody may claim the sale.
     * Here the rail's only LP tries the loop the review described; every renewal in the block the
     * claim ends is refused, and the seller's cancel - ordered after the LP's release - lands.
     */
    function test_M1_Fixed_AnLPCannotRenewAStaleClaimToBlockCancel() public {
        vm.prank(seller);
        bytes32 saleId = offramp.openSale(address(movva), 500 ether, 50_000, SELLER_PIX, address(verifier), PIX_MASK, seller);
        for (uint256 i; i < 5; ++i) {
            vm.prank(lp);
            offramp.claimSale(saleId);
            vm.warp(block.timestamp + offramp.PAY_WINDOW() + 1);
            vm.startPrank(lp);
            offramp.releaseStaleClaim(saleId); // the same block as the attempted renewal
            vm.expectRevert(
                abi.encodeWithSelector(
                    OffRampEscrow.ClaimCoolingDown.selector, uint64(block.timestamp) + offramp.CLAIM_COOLDOWN()
                )
            );
            offramp.claimSale(saleId);
            vm.stopPrank();
            vm.warp(block.timestamp + offramp.CLAIM_COOLDOWN());
        }
        // The LP abandons a live claim a second before payBy and tries again: refused too.
        vm.prank(lp);
        offramp.claimSale(saleId);
        vm.warp(block.timestamp + offramp.PAY_WINDOW() - 1);
        vm.startPrank(lp);
        offramp.abandonClaim(saleId);
        vm.expectRevert(); // ClaimCoolingDown
        offramp.claimSale(saleId);
        vm.stopPrank();

        vm.prank(seller);
        offramp.cancelSale(saleId);
        assertEq(movva.balanceOf(seller), 100_000 ether, "the seller is out, with all its Movva");
        assertEq(registry.reservedBy(address(offramp), lp), 0, "and the LP's credit is free");
    }

    /// The seller need not wait for anyone to release a stale claim: it cancels the claim itself,
    /// so an LP that simply never releases cannot hold the sale either.
    function test_M1_Fixed_TheSellerCancelsAStaleClaimItself() public {
        vm.prank(seller);
        bytes32 saleId = offramp.openSale(address(movva), 500 ether, 50_000, SELLER_PIX, address(verifier), PIX_MASK, seller);
        vm.prank(lp);
        offramp.claimSale(saleId);
        vm.prank(seller);
        vm.expectRevert(OffRampEscrow.WrongState.selector);
        offramp.cancelSale(saleId); // a live claim still protects the LP
        vm.warp(block.timestamp + offramp.PAY_WINDOW() + 1);
        vm.prank(seller);
        offramp.cancelSale(saleId);
        assertEq(movva.balanceOf(seller), 100_000 ether);
        assertEq(registry.reservedBy(address(offramp), lp), 0);
    }

    /*//////////////////////////////////////////////////////////////
                 Q7 - NATIVE ETH ON THE MOVVA PAIR (held)
    //////////////////////////////////////////////////////////////*/

    /// Native ETH cannot become a position on either escrow, and nobody can re-list it. ETH sent to
    /// FiatEscrow.receive() is accepted and stranded (no function sends native ETH unless an ETH
    /// offer exists, and none can).
    function test_M1_NativeEthIsDelistedForGoodAndDonationsStrand() public {
        vm.deal(lp, 1 ether);
        vm.prank(lp);
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.AssetNotEnabled.selector, address(0)));
        onramp.postOffer{value: 1 ether}(address(0), 1 ether, 100, LP_PIX, 0.1 ether, 1 ether, address(verifier), PIX_MASK);
        vm.prank(lp);
        vm.expectRevert(abi.encodeWithSelector(OffRampEscrow.AssetNotEnabled.selector, address(0)));
        offramp.openSale{value: 1 ether}(address(0), 1 ether, 100, SELLER_PIX, address(verifier), PIX_MASK, lp);
        vm.prank(lp);
        (bool ok,) = address(onramp).call{value: 1 ether}("");
        assertTrue(ok, "receive() takes it");
        assertEq(address(onramp).balance, 1 ether, "and it stays there for good");
    }
}
