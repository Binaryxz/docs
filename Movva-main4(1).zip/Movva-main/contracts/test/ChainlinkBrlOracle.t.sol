// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Governed} from "./utils/Governed.sol";
import {MockFeed} from "./RampIntegration.t.sol";
import {ChainlinkBrlOracle} from "../ramp/ChainlinkBrlOracle.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";

/**
 * ChainlinkBrlOracle's governance. Its pricing is exercised through a real escrow in
 * RampIntegration.t.sol and against mainnet in OracleFork.t.sol; this is who may change what it
 * reads, and how fast.
 */
contract ChainlinkBrlOracleGovernanceTest is Governed {
    MockFeed ethUsd;
    MockFeed brlUsd;
    ChainlinkBrlOracle oracle;
    address governor = address(0x60F);

    function setUp() public {
        vm.warp(1_700_000_000);
        // ETH = $3,000.00 (8dp); BRL = $0.20 (8dp)  =>  1 ETH = R$15,000 = 1,500,000 centavos
        ethUsd = new MockFeed(3000e8, 8);
        brlUsd = new MockFeed(0.2e8, 8);
        oracle = new ChainlinkBrlOracle(address(ethUsd), address(brlUsd), 1 hours, 1 hours, governor, DELAY);
        _completeSetup(address(oracle));
    }

    function _setFeeds(address eth, address brl, uint64 maxAge) internal pure returns (bytes memory) {
        return abi.encodeCall(ChainlinkBrlOracle.setFeeds, (eth, brl, maxAge, maxAge));
    }

    function test_NothingPricesUntilSetupCloses() public {
        ChainlinkBrlOracle fresh = new ChainlinkBrlOracle(address(ethUsd), address(brlUsd), 1 hours, 1 hours, governor, DELAY);
        vm.expectRevert(DelayedGovernance.SetupIncomplete.selector);
        fresh.brlCentsPerUnit();
        _completeSetup(address(fresh));
        (uint256 price,) = fresh.brlCentsPerUnit();
        assertEq(price, 1_500_000);
    }

    /// Tightening the age with the feeds unchanged is a brake. Anything that admits a price waits.
    function test_TighteningIsInstantRepointingOrLengtheningWaits() public {
        vm.prank(governor);
        oracle.setFeeds(address(ethUsd), address(brlUsd), 30 minutes, 30 minutes);
        assertEq(oracle.ethUsdMaxAge(), 30 minutes);
        assertEq(oracle.brlUsdMaxAge(), 30 minutes);

        MockFeed other = new MockFeed(0.1e8, 8); // a BRL leg at half the rate: twice the band
        bytes[3] memory waits = [
            _setFeeds(address(other), address(brlUsd), 30 minutes),
            _setFeeds(address(ethUsd), address(other), 30 minutes),
            _setFeeds(address(ethUsd), address(brlUsd), 31 minutes)
        ];
        for (uint256 i; i < waits.length; ++i) {
            vm.prank(governor);
            (bool ok, bytes memory ret) = address(oracle).call(waits[i]);
            assertFalse(ok, "a risk-increasing change went through without the delay");
            assertEq(ret, abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, ChainlinkBrlOracle.setFeeds.selector));
        }
        (uint256 before,) = oracle.brlCentsPerUnit();
        assertEq(before, 1_500_000, "nothing moved the band");

        _afterDelay(address(oracle), _setFeeds(address(ethUsd), address(other), 1 hours));
        ethUsd.set(3000e8, block.timestamp);
        other.set(0.1e8, block.timestamp);
        (uint256 later,) = oracle.brlCentsPerUnit();
        assertEq(later, 3_000_000, "3000 USD/ETH over 0.10 USD/BRL, after the delay");
    }

    /// A zero feed is a repoint, so it waits - and is refused when it would land.
    function test_AZeroFeedIsRefusedThroughTheDelay() public {
        bytes memory zero = _setFeeds(address(0), address(brlUsd), 1 hours);
        vm.prank(governor);
        oracle.schedule(zero);
        vm.warp(block.timestamp + DELAY);
        vm.prank(governor);
        vm.expectRevert(DelayedGovernance.ZeroAddress.selector);
        oracle.execute(zero);
    }

    function test_OnlyTheGovernorAndOnlySetFeedsCanBeScheduled() public {
        vm.expectRevert(DelayedGovernance.NotGovernor.selector);
        oracle.setFeeds(address(ethUsd), address(brlUsd), 1 hours, 1 hours);
        bytes memory transfer = abi.encodeCall(DelayedGovernance.transferGovernor, (address(1)));
        vm.prank(governor);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.NotDelayable.selector, bytes4(transfer)));
        oracle.schedule(transfer);
    }

    function test_TheConstructorRefusesAnUnusableConfiguration() public {
        vm.expectRevert(DelayedGovernance.ZeroAddress.selector);
        new ChainlinkBrlOracle(address(0), address(brlUsd), 1 hours, 1 hours, governor, DELAY);
        vm.expectRevert(DelayedGovernance.ZeroAddress.selector);
        new ChainlinkBrlOracle(address(ethUsd), address(brlUsd), 1 hours, 1 hours, address(0), DELAY);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.BadGovernanceDelay.selector, 31 days));
        new ChainlinkBrlOracle(address(ethUsd), address(brlUsd), 1 hours, 1 hours, governor, 31 days);
    }

    /// M-22: each leg against its own age - a daily BRL/USD and an hourly ETH/USD.
    function test_EachLegIsJudgedAgainstItsOwnAge() public {
        vm.prank(governor);
        oracle.setFeeds(address(ethUsd), address(brlUsd), 1 hours, 1 hours);
        _afterDelay(address(oracle), _setFeedsAges(1 hours, 25 hours));
        ethUsd.set(3000e8, block.timestamp);
        brlUsd.set(0.2e8, block.timestamp - 20 hours);
        (uint256 p,) = oracle.brlCentsPerUnit();
        assertEq(p, 1_500_000, "a 20-hour-old BRL/USD is inside its daily heartbeat");
        ethUsd.set(3000e8, block.timestamp - 2 hours);
        vm.expectRevert(abi.encodeWithSelector(ChainlinkBrlOracle.StalePrice.selector, address(ethUsd), block.timestamp - 2 hours));
        oracle.brlCentsPerUnit();
    }

    /// L-02's lesson here too: no instant "tightening" to a second, and no age beyond two days.
    function test_MaxAgesAreBounded() public {
        vm.prank(governor);
        vm.expectRevert(ChainlinkBrlOracle.BadMaxAge.selector);
        oracle.setFeeds(address(ethUsd), address(brlUsd), 1, 1 hours);
        vm.expectRevert(ChainlinkBrlOracle.BadMaxAge.selector);
        new ChainlinkBrlOracle(address(ethUsd), address(brlUsd), 1 hours, 3 days, governor, DELAY);
    }

    /// I-46: an answer stamped from the future is refused.
    function test_AnAnswerFromTheFutureIsRefused() public {
        brlUsd.set(0.2e8, block.timestamp + 6 minutes);
        vm.expectRevert(abi.encodeWithSelector(ChainlinkBrlOracle.PriceFromFuture.selector, address(brlUsd), block.timestamp + 6 minutes));
        oracle.brlCentsPerUnit();
    }

    function _setFeedsAges(uint64 ethAge, uint64 brlAge) internal view returns (bytes memory) {
        return abi.encodeCall(ChainlinkBrlOracle.setFeeds, (address(ethUsd), address(brlUsd), ethAge, brlAge));
    }
}
