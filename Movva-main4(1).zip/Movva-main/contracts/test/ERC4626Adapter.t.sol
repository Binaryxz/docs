// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Governed} from "./utils/Governed.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {IERC4626} from "@openzeppelin/contracts/interfaces/IERC4626.sol";
import {ERC4626} from "@openzeppelin/contracts/token/ERC20/extensions/ERC4626.sol";
import {Pausable} from "@openzeppelin/contracts/utils/Pausable.sol";
import {YieldVault} from "../yield/YieldVault.sol";
import {ERC4626Adapter} from "../yield/adapters/ERC4626Adapter.sol";
import {IYieldAdapter} from "../yield/IYieldAdapter.sol";

/**
 * TetherToken's behaviour where it matters to a vault, copied from the verified source of
 * 0xdAC17F958D2ee523a2206206994597C13D831ec7: no return values; `approve` from a non-zero allowance
 * to a non-zero one reverts; `transfer` checks only the SENDER against the blacklist (and
 * `transferFrom` only `from`), so a blacklisted address can still receive; a fee of
 * `min(value * basisPointsRate / 10000, maximumFee)` goes to the owner; `pause` stops transfers.
 */
contract TetherLike {
    string public constant name = "Tether-like USD";
    string public constant symbol = "USDT";
    uint8 public constant decimals = 6;

    address public owner = msg.sender;
    uint256 public totalSupply;
    uint256 public basisPointsRate;
    uint256 public maximumFee;
    bool public paused;
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;
    mapping(address => bool) public isBlackListed;

    function mint(address to, uint256 v) external {
        balanceOf[to] += v;
        totalSupply += v;
    }

    function transfer(address to, uint256 v) external {
        require(!paused && !isBlackListed[msg.sender]);
        _move(msg.sender, to, v);
    }

    function transferFrom(address from, address to, uint256 v) external {
        require(!paused && !isBlackListed[from]);
        uint256 a = allowance[from][msg.sender];
        if (a < type(uint256).max) allowance[from][msg.sender] = a - v;
        _move(from, to, v);
    }

    function approve(address spender, uint256 v) external {
        require(!(v != 0 && allowance[msg.sender][spender] != 0));
        allowance[msg.sender][spender] = v;
    }

    function setParams(uint256 bps, uint256 maxFeeWhole) external {
        require(bps < 20 && maxFeeWhole < 50);
        basisPointsRate = bps;
        maximumFee = maxFeeWhole * 10 ** decimals;
    }

    function addBlackList(address who) external {
        isBlackListed[who] = true;
    }

    function removeBlackList(address who) external {
        isBlackListed[who] = false;
    }

    function setPaused(bool p) external {
        paused = p;
    }

    function _move(address from, address to, uint256 v) internal {
        uint256 fee = (v * basisPointsRate) / 10_000;
        if (fee > maximumFee) fee = maximumFee;
        balanceOf[from] -= v;
        balanceOf[to] += v - fee;
        balanceOf[owner] += fee;
    }
}

/**
 * Aave's StataTokenV2 where it matters to the adapter: an ERC-4626 with its own pause, which
 * blocks mint and burn but which `maxWithdraw`/`maxDeposit` do not check; withdrawals bounded by
 * available liquidity; deposits bounded by supply-cap room. `refuseWithdraw` makes it revert even
 * where its views allow, as liquidity borrowed out between a view and a call would.
 */
contract StataLike is ERC4626, Pausable {
    uint256 public liquidity = type(uint256).max;
    uint256 public room = type(uint256).max;
    bool public refuseWithdraw;
    /// An upgrade or a bug that makes the target's views revert (N-35).
    bool public viewsRevert;

    constructor(IERC20 a) ERC20("Wrapped", "stataUSDT") ERC4626(a) {}

    function setViewsRevert(bool r) external {
        viewsRevert = r;
    }

    function previewRedeem(uint256 shares) public view override returns (uint256) {
        require(!viewsRevert, "views broken");
        return super.previewRedeem(shares);
    }

    function setPaused(bool p) external {
        if (p) _pause();
        else _unpause();
    }

    function setLiquidity(uint256 l) external {
        liquidity = l;
    }

    function setRoom(uint256 r) external {
        room = r;
    }

    function setRefuseWithdraw(bool r) external {
        refuseWithdraw = r;
    }

    function maxDeposit(address) public view override returns (uint256) {
        return room;
    }

    function maxWithdraw(address owner) public view override returns (uint256) {
        require(!viewsRevert, "views broken");
        uint256 m = super.maxWithdraw(owner);
        return m < liquidity ? m : liquidity;
    }

    function _withdraw(address caller, address receiver, address owner, uint256 assets, uint256 shares)
        internal
        override
    {
        require(!refuseWithdraw, "liquidity gone");
        super._withdraw(caller, receiver, owner, assets, shares);
    }

    function _update(address from, address to, uint256 value) internal override whenNotPaused {
        super._update(from, to, value);
    }

    /// Interest, as a donation of the underlying.
    function earn(TetherLike t, uint256 v) external {
        t.mint(address(this), v);
    }
}

/// A target whose `paused()` answers something that is not a bool, and whose `maxDeposit` reverts.
contract OddTarget is ERC4626 {
    bool public broken = true;

    constructor(IERC20 a) ERC20("Odd", "odd") ERC4626(a) {}

    function paused() external pure returns (uint256, uint256) {
        return (7, 7);
    }

    function maxDeposit(address) public view override returns (uint256) {
        require(!broken, "no");
        return type(uint256).max;
    }
}

/// @dev An exit that costs: it gives up `assets` of its valuation but delivers only `delivered` of them (v2.0 I-26).
contract CostlyExitAdapter is IYieldAdapter {
    address public immutable override vault;
    address public immutable override asset;
    uint256 public value;
    uint256 public deliveredBps = 10_000;

    constructor(address vault_, address asset_) {
        vault = vault_;
        asset = asset_;
    }

    function setDeliveredBps(uint256 bps) external {
        deliveredBps = bps;
    }

    function name() external pure returns (string memory) {
        return "costly";
    }

    function totalValue() external view returns (uint256) {
        return value;
    }

    function maxInstantWithdraw() external view returns (uint256) {
        return value;
    }

    function deposit(uint256 assets) external returns (uint256) {
        value += assets;
        return assets;
    }

    function withdraw(uint256 assets, address to) external returns (uint256 out) {
        value -= assets;
        out = assets * deliveredBps / 10_000;
        // TetherLike returns nothing from transfer, as USDT does.
        (bool ok,) = asset.call(abi.encodeWithSelector(IERC20.transfer.selector, to, out));
        require(ok, "transfer");
    }

    function harvest() external pure returns (uint256) {
        return 0;
    }
}

contract ERC4626AdapterTest is Governed {
    TetherLike usdt;
    StataLike stata;
    YieldVault vault;
    ERC4626Adapter adapter;

    address gov = makeAddr("gov");
    address guardian = makeAddr("guardian");
    address keeper = makeAddr("keeper");
    address alice = makeAddr("alice");
    address bob = makeAddr("bob");

    uint256 constant DEPOSIT = 1_000_000e6;
    uint256 constant ALLOCATED = 900_000e6;

    function setUp() public {
        usdt = new TetherLike();
        stata = new StataLike(IERC20(address(usdt)));
        vault = new YieldVault(IERC20(address(usdt)), "Shielded Yield USDT", "syUSDT", gov, guardian, keeper, 1e15, 100, DELAY);
        adapter = new ERC4626Adapter(address(vault), IERC4626(address(stata)), "stata");
        vm.startPrank(gov);
        vault.addAdapter(adapter, 10_000);
        vault.completeSetup();
        vm.stopPrank();

        for (uint256 i; i < 2; ++i) {
            address who = i == 0 ? alice : bob;
            usdt.mint(who, DEPOSIT);
            vm.prank(who);
            usdt.approve(address(vault), type(uint256).max);
        }
        vm.prank(alice);
        vault.deposit(DEPOSIT, alice);
        vm.prank(keeper);
        vault.allocate(adapter, ALLOCATED);
    }

    /// N-35, the auditor's PoC inverted: the target's views start reverting with 900,000 allocated to it
    /// and 100,000 idle. The vault counts that source as zero rather than freezing: totalAssets answers, a
    /// 10,000 withdrawal is paid from idle, the guardian's deallocate runs, and the source can be removed.
    function test_N35_ATargetWhoseViewsRevertNoLongerFreezesTheVault() public {
        stata.setViewsRevert(true);
        assertEq(vault.totalAssets(), DEPOSIT - ALLOCATED, "the unreadable source counts as zero");
        assertEq(adapter.totalValue(), 0, "the adapter itself never reverts");
        assertEq(adapter.maxInstantWithdraw(), 0);
        vm.prank(alice);
        vault.withdraw(10_000e6, alice, alice);
        assertEq(usdt.balanceOf(alice), 10_000e6, "paid from the idle share");
        vm.prank(guardian);
        vault.deallocate(adapter, 1);
        vm.prank(gov);
        vault.updateAdapter(adapter, 0, false);
        vm.prank(gov);
        vault.removeAdapter(adapter);
        // Fixed again, the funds are still the adapter's: re-listed through the delay, they count again.
        stata.setViewsRevert(false);
        assertEq(adapter.totalValue(), ALLOCATED);
    }

    /// I-27: dust sent to an emptied source no longer blocks its removal; real value still does.
    function test_I27_DustCannotBlockRemovingASource() public {
        vm.prank(guardian);
        vault.deallocate(adapter, ALLOCATED);
        usdt.mint(address(adapter), 1e6); // a whole unit of dust
        vm.prank(gov);
        vault.removeAdapter(adapter);
    }

    function test_I27_ASourceWithValueCannotBeRemoved() public {
        vm.prank(gov);
        vm.expectRevert(YieldVault.AdapterNotEmpty.selector);
        vault.removeAdapter(adapter);
    }

    function _redeemAll(address who) internal returns (uint256 out) {
        uint256 shares = vault.balanceOf(who);
        vm.prank(who);
        out = vault.redeem(shares, who, who);
    }

    /*//////////////////////////////////////////////////////////////
                                  EXITS
    //////////////////////////////////////////////////////////////*/

    /// SR3-9: a frozen vault can still receive USDT, so it asks Tether before taking any, and every
    /// ERC-4626 limit reads zero while it is listed. Unlisted, it carries on with no governor action.
    function test_AVaultTheIssuerFroze_RefusesDepositsAndReportsNoRoom() public {
        usdt.addBlackList(address(vault));
        assertTrue(vault.frozenByAssetIssuer());
        assertEq(vault.maxDeposit(bob), 0);
        assertEq(vault.maxMint(bob), 0);
        assertEq(vault.maxWithdraw(alice), 0);
        assertEq(vault.maxRedeem(alice), 0);
        vm.prank(bob);
        vm.expectRevert(YieldVault.FrozenByAssetIssuer.selector);
        vault.deposit(1e6, bob);
        vm.prank(bob);
        vm.expectRevert(YieldVault.FrozenByAssetIssuer.selector);
        vault.mint(1e6, bob);

        usdt.removeBlackList(address(vault));
        assertFalse(vault.frozenByAssetIssuer());
        vm.prank(bob);
        vault.deposit(1e6, bob);
        assertGt(vault.maxRedeem(alice), 0);
    }

    /// The adapter never holds USDT on the way out, so blacklisting it cannot stop an exit.
    function test_ABlacklistedAdapterCannotStopAnExitButCannotAllocate() public {
        usdt.addBlackList(address(adapter));
        assertEq(usdt.balanceOf(address(adapter)), 0);
        vm.prank(keeper);
        vm.expectRevert();
        vault.allocate(adapter, 1e6);
        assertEq(_redeemAll(alice), DEPOSIT, "the whole position came out past a blacklisted adapter");
    }

    /// The wrapper's own pause: its views still promise, the adapter does not repeat the promise.
    function test_ATargetsOwnPauseIsNotPassedOnAsLiquidity() public {
        stata.setPaused(true);
        assertEq(stata.maxWithdraw(address(adapter)), ALLOCATED, "the target's view ignores its pause");

        assertTrue(adapter.targetPaused());
        assertEq(adapter.maxInstantWithdraw(), 0);
        assertEq(adapter.totalValue(), ALLOCATED, "still valued");
        assertEq(adapter.maxDeposit(), 0);
        assertEq(adapter.depositBlocker(), "target vault is paused");
        assertEq(vault.maxWithdraw(alice), DEPOSIT - ALLOCATED, "the vault promises only idle");

        vm.prank(alice);
        vault.withdraw(DEPOSIT - ALLOCATED, alice, alice);
        vm.prank(guardian);
        vault.deallocate(adapter, ALLOCATED);
        assertEq(adapter.totalValue(), ALLOCATED, "a pull while paused moves nothing and reverts nothing");

        stata.setPaused(false);
        _redeemAll(alice);
        assertEq(usdt.balanceOf(alice), DEPOSIT);
    }

    /// A refusal the views did not predict is caught inside the adapter and reported as an event.
    function test_ATargetThatRefusesDespiteItsViewsIsCaughtNotBubbled() public {
        stata.setRefuseWithdraw(true);
        vm.expectEmit(address(adapter));
        emit ERC4626Adapter.TargetWithdrawFailed(ALLOCATED, abi.encodeWithSignature("Error(string)", "liquidity gone"));
        vm.prank(guardian);
        vault.deallocate(adapter, ALLOCATED);

        // A holder asking for more than idle gets the vault's own error, naming what arrived.
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(YieldVault.InsufficientLiquidity.selector, 200_000e6, 100_000e6));
        vault.withdraw(200_000e6, alice, alice);
    }

    /// Liquidity binds: the adapter takes what the target allows, then any idle it holds.
    function test_TheTargetPaysFirstThenIdle() public {
        usdt.mint(address(adapter), 5_000e6); // a donation, or dust
        stata.setLiquidity(10_000e6);
        assertEq(adapter.maxInstantWithdraw(), 15_000e6);
        vm.prank(address(vault));
        assertEq(adapter.withdraw(12_000e6, bob), 12_000e6);
        assertEq(usdt.balanceOf(bob), DEPOSIT + 12_000e6);
        assertEq(usdt.balanceOf(address(adapter)), 3_000e6, "target first, then 2,000 of the idle");
    }

    function test_OnlyTheVaultMovesFunds() public {
        vm.expectRevert(ERC4626Adapter.NotVault.selector);
        adapter.withdraw(1, bob);
        vm.expectRevert(ERC4626Adapter.NotVault.selector);
        adapter.deposit(1);
    }

    /*//////////////////////////////////////////////////////////////
                       DEPOSITS AND KEEPER VIEWS
    //////////////////////////////////////////////////////////////*/

    function test_ForceApproveSurvivesAStaleAllowance() public {
        vm.prank(address(adapter));
        usdt.approve(address(stata), 1);
        vm.prank(address(adapter));
        vm.expectRevert();
        usdt.approve(address(stata), 2);

        vm.prank(keeper);
        vault.allocate(adapter, 50_000e6);
        assertEq(adapter.totalValue(), ALLOCATED + 50_000e6);
        assertEq(usdt.allowance(address(adapter), address(stata)), 0);
    }

    function test_MaxDepositIsTheTargetsRoomAndSaysWhyWhenZero() public {
        stata.setRoom(123e6);
        assertEq(adapter.maxDeposit(), 123e6);
        assertEq(adapter.depositBlocker(), "");
        vm.prank(keeper);
        vm.expectRevert(
            abi.encodeWithSelector(ERC4626.ERC4626ExceededMaxDeposit.selector, address(adapter), 124e6, 123e6)
        );
        vault.allocate(adapter, 124e6);

        stata.setRoom(0);
        assertEq(adapter.depositBlocker(), "target vault accepts no deposits (at its supply cap, frozen or paused)");
    }

    /// The optional probes degrade instead of reverting on targets that do not play along.
    function test_TargetsWithoutAPauseOrWithOddAnswersNeverBreakTheViews() public {
        YieldVault v = new YieldVault(IERC20(address(usdt)), "v", "v", gov, guardian, keeper, 1e15, 100, DELAY);
        OddTarget odd = new OddTarget(IERC20(address(usdt)));
        ERC4626Adapter a = new ERC4626Adapter(address(v), IERC4626(address(odd)), "odd");
        assertTrue(a.targetPaused(), "a non-zero first word reads as paused, conservatively");
        assertEq(a.maxInstantWithdraw(), 0);
        assertEq(a.maxDeposit(), 0);

        ERC4626 plain = new StataLikeWithoutPause(IERC20(address(usdt)));
        ERC4626Adapter b = new ERC4626Adapter(address(v), IERC4626(address(plain)), "plain");
        assertFalse(b.targetPaused(), "no paused() at all: not paused");
        assertEq(b.maxDeposit(), type(uint256).max);
    }

    /// Interest in the target is value in the vault, and a full exit takes all of it.
    function test_InterestIsRedeemedInFull() public {
        stata.earn(usdt, 9_000e6);
        // 1% of the target's assets counts in full once the growth cap (50% a year, I-29) allows it: 8 days on.
        vm.warp(block.timestamp + 8 days);
        assertApproxEqAbs(vault.totalAssets(), DEPOSIT + 9_000e6, 1);
        assertApproxEqAbs(_redeemAll(alice), DEPOSIT + 9_000e6, 2);
    }

    /// v2.0 I-29: a donation to the target raises its share price at once, but this position counts that growth at
    /// most 50% a year from its last checkpoint, so the vault's share price cannot be pumped in a block.
    function test_I29_ADonationToTheTargetIsCountedOnlyAtTheGrowthCap() public {
        uint256 before = adapter.totalValue();
        usdt.mint(address(stata), 450_000e6); // +50% to the target in one transfer
        assertApproxEqAbs(adapter.totalValue(), before, 1, "nothing counts in the same block");
        vm.warp(block.timestamp + 365 days / 10);
        assertApproxEqAbs(adapter.totalValue(), before + before * 5 / 100, 2, "a tenth of a year: 5%");
        vm.warp(block.timestamp + 365 days);
        assertApproxEqAbs(adapter.totalValue(), before * 3 / 2, 2, "never more than the target pays");
    }

    /// v2.0 I-26: a holder's exit through a source that delivers less than its valuation fell is refused, so no exit
    /// cost reaches the holders who stay.
    function test_I26_AnExitThatWouldPassItsCostToOthersIsRefused() public {
        CostlyExitAdapter costly = new CostlyExitAdapter(address(vault), address(usdt));
        _afterDelay(address(vault), abi.encodeCall(YieldVault.addAdapter, (IYieldAdapter(address(costly)), 10_000)));
        vm.prank(guardian);
        vault.deallocate(adapter, ALLOCATED);
        vm.prank(keeper);
        vault.allocate(costly, DEPOSIT);
        costly.setDeliveredBps(9_900);
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(YieldVault.ExitBelowValuation.selector, address(costly), 10_000e6, 9_900e6));
        vault.withdraw(10_000e6, alice, alice);
        costly.setDeliveredBps(10_000);
        vm.prank(alice);
        vault.withdraw(10_000e6, alice, alice);
        assertEq(usdt.balanceOf(alice), 10_000e6);
    }
}

contract StataLikeWithoutPause is ERC4626 {
    constructor(IERC20 a) ERC20("plain", "plain") ERC4626(a) {}
}

/**
 * The vault in front of a 6-decimal token with Tether's switches: a transfer fee, and the share
 * price resolution the drawdown breaker has to work with.
 */
contract YieldVaultTetherLikeTest is Governed {
    TetherLike usdt;
    StataLike stata;
    YieldVault vault;
    ERC4626Adapter adapter;

    address gov = makeAddr("gov");
    address guardian = makeAddr("guardian");
    address keeper = makeAddr("keeper");
    address alice = makeAddr("alice");
    address bob = makeAddr("bob");

    function setUp() public {
        usdt = new TetherLike();
        stata = new StataLike(IERC20(address(usdt)));
        vault = new YieldVault(IERC20(address(usdt)), "Shielded Yield USDT", "syUSDT", gov, guardian, keeper, 1e15, 100, DELAY);
        adapter = new ERC4626Adapter(address(vault), IERC4626(address(stata)), "stata");
        vm.startPrank(gov);
        vault.addAdapter(adapter, 10_000);
        vault.completeSetup();
        vm.stopPrank();
        usdt.mint(alice, 1_000_000e6);
        usdt.mint(bob, 1_000_000e6);
        vm.prank(alice);
        usdt.approve(address(vault), type(uint256).max);
        vm.prank(bob);
        usdt.approve(address(vault), type(uint256).max);
        vm.prank(alice);
        vault.deposit(1_000_000e6, alice);
    }

    function test_ADepositThatArrivesShortIsRefused() public {
        usdt.setParams(19, 49);
        vm.prank(bob);
        vm.expectRevert(abi.encodeWithSelector(YieldVault.TransferFeeCharged.selector, 100_000e6, 100_000e6 - 49e6));
        vault.deposit(100_000e6, bob);

        uint256 shares = vault.previewDeposit(1_000_000e6);
        vm.prank(bob);
        vm.expectRevert(abi.encodeWithSelector(YieldVault.TransferFeeCharged.selector, 1_000_000e6, 1_000_000e6 - 49e6));
        vault.mint(shares, bob);
    }

    /// Without the check, the depositor would be credited the fee and every other holder would pay it.
    function test_WithoutTheFeeSwitchDepositsArriveInFull() public {
        uint256 price = vault.assetsPerShare();
        vm.prank(bob);
        vault.deposit(100_000e6, bob);
        assertEq(vault.assetsPerShare(), price);
    }

    function test_WithAFeeTheLeaverPaysAndTheStayersDoNot() public {
        vm.prank(bob);
        vault.deposit(500_000e6, bob);
        usdt.setParams(19, 49);
        uint256 price = vault.assetsPerShare();
        vm.prank(bob);
        vault.withdraw(100_000e6, bob, bob);
        assertEq(usdt.balanceOf(bob), 500_000e6 + 100_000e6 - 49e6, "19 bps is 190 USDT, capped at 49");
        assertEq(vault.assetsPerShare(), price);
    }

    /**
     * Shares carry 12 decimals, so assets-per-share is quoted per 1e12 shares and moves in steps of
     * one micro-USDT: one part in a million. The breaker's 100 bps band is ten thousand steps wide.
     */
    function test_TheBreakerResolvesItsBandAtSixDecimals() public {
        assertEq(vault.decimals(), 12);
        vm.prank(keeper);
        vault.allocate(adapter, 1_000_000e6);
        uint256 hw = vault.assetsPerShare();
        assertApproxEqAbs(hw, 1e6, 1);
        vault.checkpoint();

        // A 0.99% loss does not trip a 1% band; 1.01% does.
        _lose(9_900e6);
        vault.checkpoint();
        assertFalse(vault.depositsPaused(), "inside the band");
        _lose(200e6);
        vault.checkpoint();
        assertTrue(vault.depositsPaused(), "through it");
    }

    function test_AMicroUnitOfYieldMovesTheHighWaterMark() public {
        vm.prank(keeper);
        vault.allocate(adapter, 1_000_000e6);
        vault.checkpoint();
        uint256 hw = vault.highWaterAssetsPerShare();
        stata.earn(usdt, 2e6); // 2 USDT on 1,000,000: two parts per million
        vm.warp(block.timestamp + 1 hours); // within the adapter's growth cap (I-29)
        vault.checkpoint();
        assertGt(vault.highWaterAssetsPerShare(), hw);
    }

    function _lose(uint256 v) internal {
        vm.prank(address(stata));
        usdt.transfer(makeAddr("hack"), v);
    }
}
