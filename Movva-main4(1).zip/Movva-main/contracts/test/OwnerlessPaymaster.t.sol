// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

import {Test, Vm} from "forge-std/Test.sol";
import {OwnerlessPaymaster, IEntryPointFunding, PackedUserOperation} from "../OwnerlessPaymaster.sol";

/*//////////////////////////////////////////////////////////////
               THE CANONICAL CONTRACTS, BY INTERFACE
//////////////////////////////////////////////////////////////*/

interface IEntryPointV07 {
    error FailedOp(uint256 opIndex, string reason);
    error FailedOpWithRevert(uint256 opIndex, string reason, bytes inner);

    struct DepositInfo {
        uint256 deposit;
        bool staked;
        uint112 stake;
        uint32 unstakeDelaySec;
        uint48 withdrawTime;
    }

    function handleOps(PackedUserOperation[] calldata ops, address payable beneficiary) external;
    function getUserOpHash(PackedUserOperation calldata userOp) external view returns (bytes32);
    function getNonce(address sender, uint192 key) external view returns (uint256);
    function balanceOf(address account) external view returns (uint256);
    function getDepositInfo(address account) external view returns (DepositInfo memory);
    function depositTo(address account) external payable;
    function addStake(uint32 unstakeDelaySec) external payable;
    function unlockStake() external;
    function withdrawStake(address payable withdrawAddress) external;
    function withdrawTo(address payable withdrawAddress, uint256 withdrawAmount) external;
}

interface ISafeProxyFactory {
    function createProxyWithNonce(address singleton, bytes memory initializer, uint256 saltNonce)
        external
        returns (address proxy);
    function proxyCreationCode() external pure returns (bytes memory);
}

interface ISafe {
    function setup(
        address[] calldata owners,
        uint256 threshold,
        address to,
        bytes calldata data,
        address fallbackHandler,
        address paymentToken,
        uint256 payment,
        address payable paymentReceiver
    ) external;
}

interface ISafeModuleSetup {
    function enableModules(address[] calldata modules) external;
}

interface ISafe4337Module {
    function getOperationHash(PackedUserOperation calldata userOp) external view returns (bytes32);
    function executeUserOp(address to, uint256 value, bytes memory data, uint8 operation) external;
}

interface IWebAuthnSignerFactory {
    function createSigner(uint256 x, uint256 y, uint176 verifiers) external returns (address);
}

interface IKernelFactory {
    function createAccount(bytes calldata data, bytes32 salt) external payable returns (address);
    function getAddress(bytes calldata data, bytes32 salt) external view returns (address);
}

interface IKernel {
    function initialize(
        bytes21 rootValidator,
        address hook,
        bytes calldata validatorData,
        bytes calldata hookData,
        bytes[] calldata initConfig
    ) external;
    function execute(bytes32 execMode, bytes calldata executionCalldata) external payable;
}

/**
 * Shared plumbing: the canonical ERC-4337 stack deployed from packages/smart-account/fixtures exactly as
 * mainnet deployed it (EntryPoint v0.7, Safe 1.4.1 with Safe4337Module, the Safe passkey signer factory,
 * Kernel v3.1 and its factory), our PasskeyCoSignerValidator from its vendored build, and the three kinds
 * of account the wallet creates:
 *
 *   SUB_WALLET   a Safe 1-of-1 owned by the sub-wallet's own key: no passkey, same factory
 *   SAFE         the primary account: a Safe 2-of-2, the passkey's WebAuthn signer and the co-signer
 *   KERNEL       the primary account on Kernel: PasskeyCoSignerValidator (passkey + co-signer),
 *                created by a plain transaction to KernelFactory as the co-signer does at enrolment
 *
 * Nothing here is a mock of a contract under test.
 */
abstract contract OwnerlessPaymasterHarness is Test {
    address internal constant ARACHNID = 0x4e59b44847b379578588920cA78FbF26c0B4956C;
    address internal constant SAFE_SINGLETON_FACTORY = 0x914d7Fec6aaC8cd542e72Bca78B30650d45643d7;
    address internal constant EIP2470 = 0xce0042B868300000d44A59004Da54A005ffdcf9f;
    string internal constant FIXTURES = "packages/smart-account/fixtures/";

    address internal constant BUNDLER = address(0xB0B);
    uint256 internal constant T0 = 1_800_000_000;

    uint8 internal constant SUB_WALLET = 0;
    uint8 internal constant SAFE = 1;
    uint8 internal constant KERNEL = 2;

    // Gas every operation here signs, unless a test sets its own.
    uint128 internal constant VERIFICATION_GAS = 2_000_000;
    uint128 internal constant CALL_GAS = 300_000;
    uint256 internal constant PRE_VERIFICATION_GAS = 100_000;
    uint128 internal constant PM_VERIFICATION_GAS = 150_000;
    uint128 internal constant PM_POST_OP_GAS = 50_000;
    uint128 internal constant MAX_PRIORITY_FEE = 1 gwei;
    uint128 internal constant MAX_FEE = 2 gwei;

    uint256 internal constant P256_N = 0xFFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551;
    string internal constant RP_ID = "wallet.brl.example";
    string internal constant CLIENT_DATA_FIELDS = '"origin":"https://wallet.brl.example","crossOrigin":false';
    /// @dev What PasskeyCoSignerValidator binds an account to (v2.0 I-31): sha256(RP_ID), and the exact origin field.
    bytes32 internal constant RP_ID_HASH = 0x85293154536c0d972d3e2003b3744b175996428f62ee7c2bffe07088b9e3da82;
    string internal constant ORIGIN_FIELD = '"origin":"https://wallet.brl.example"';
    bytes32 internal constant USER_OP_CHALLENGE_TYPEHASH =
        keccak256("UserOpChallenge(bytes32 userOpHash,uint48 validAfter,uint48 validUntil,address validator)");
    bytes32 internal constant USER_OPERATION_EVENT =
        keccak256("UserOperationEvent(bytes32,address,address,uint256,bool,uint256,uint256)");
    bytes32 internal constant SPONSORED_EVENT = keccak256("Sponsored(address,uint48,uint48,uint256)");

    IEntryPointV07 internal ep;
    ISafeProxyFactory internal safeFactory;
    address internal safeSingleton;
    address internal safeModuleSetup;
    ISafe4337Module internal safeModule;
    IWebAuthnSignerFactory internal signerFactory;
    uint176 internal verifiers;
    address internal kernelImpl;
    IKernelFactory internal kernelFactory;
    address internal passkeyValidator;

    bytes32 internal safeProxyHash;
    bytes32 internal kernelProxyHash;

    struct Acct {
        uint8 kind;
        address sender;
        uint8 index; // which of the paymaster's factories
        bytes32 salt; // the CREATE2 salt that factory used
        bytes initCode; // for a Safe not deployed yet
        uint256 ownerKey; // SUB_WALLET: the owner; SAFE/KERNEL: the co-signer
        uint256 passkeyKey; // SAFE/KERNEL
        address passkeySigner; // SAFE
    }

    uint256 private _nonce;

    function _setUpStack() internal {
        vm.warp(T0);
        _etchDeployers();
        ep = IEntryPointV07(_deployCanonical("EntryPoint"));
        safeSingleton = _deployCanonical("Safe");
        safeFactory = ISafeProxyFactory(_deployCanonical("SafeProxyFactory"));
        safeModuleSetup = _deployCanonical("SafeModuleSetup");
        safeModule = ISafe4337Module(_deployCanonical("Safe4337Module"));
        verifiers = uint176(uint160(_deployCanonical("FCLP256Verifier")));
        signerFactory = IWebAuthnSignerFactory(_deployCanonical("SafeWebAuthnSignerFactory"));
        kernelImpl = _deployCanonical("Kernel");
        kernelFactory = IKernelFactory(_deployCanonical("KernelFactory"));

        string memory j = vm.readFile(string.concat(FIXTURES, "mova/PasskeyCoSignerValidator.json"));
        bytes memory initCode = abi.encodePacked(vm.parseJsonBytes(j, ".bytecode"), abi.encode(address(signerFactory)));
        address v;
        assembly {
            v := create(0, add(initCode, 0x20), mload(initCode))
        }
        require(v != address(0), "PasskeyCoSignerValidator");
        passkeyValidator = v;

        // The two provenance roots, from the deployed factories themselves.
        safeProxyHash =
            keccak256(abi.encodePacked(safeFactory.proxyCreationCode(), uint256(uint160(safeSingleton))));
        kernelProxyHash = keccak256(_kernelProxyInitCode(kernelImpl));
    }

    /// @dev The policy the wallet would run with, scaled to the gas used here. Tests override fields.
    function _policy() internal view returns (OwnerlessPaymaster.Policy memory p) {
        p = OwnerlessPaymaster.Policy({
            factory0: address(safeFactory),
            proxyInitCodeHash0: safeProxyHash,
            factory1: address(kernelFactory),
            proxyInitCodeHash1: kernelProxyHash,
            window: 1 days,
            grace: 1 hours,
            maxCostPerOp: 0.01 ether,
            maxOpsPerAccount: 5,
            maxCostPerAccount: 0.05 ether,
            maxCostGlobal: 0.2 ether,
            unstakeDelaySec: 1 days
        });
    }

    /// @dev Deployed, funded with a 10 ETH deposit and a 1 ETH stake from a stranger: anyone may.
    function _deployPaymaster(OwnerlessPaymaster.Policy memory p) internal returns (OwnerlessPaymaster pm) {
        pm = new OwnerlessPaymaster(IEntryPointFunding(address(ep)), p);
        address funder = makeAddr("any funder");
        vm.deal(funder, 11 ether);
        vm.startPrank(funder);
        pm.deposit{value: 10 ether}();
        pm.addStake{value: 1 ether}();
        vm.stopPrank();
    }

    /*//////////////////////////////////////////////////////////////
                               ACCOUNTS
    //////////////////////////////////////////////////////////////*/

    function _safeInitializer(address[] memory owners, uint256 threshold) internal view returns (bytes memory) {
        address[] memory modules = new address[](1);
        modules[0] = address(safeModule);
        return abi.encodeCall(
            ISafe.setup,
            (
                owners,
                threshold,
                safeModuleSetup,
                abi.encodeCall(ISafeModuleSetup.enableModules, (modules)),
                address(safeModule),
                address(0),
                0,
                payable(address(0))
            )
        );
    }

    function _safeAccount(uint8 kind, address[] memory owners, uint256 threshold, uint256 saltNonce)
        internal
        view
        returns (Acct memory a)
    {
        bytes memory initializer = _safeInitializer(owners, threshold);
        a.kind = kind;
        a.index = 0;
        a.salt = keccak256(abi.encodePacked(keccak256(initializer), saltNonce));
        a.sender = vm.computeCreate2Address(a.salt, safeProxyHash, address(safeFactory));
        a.initCode = abi.encodePacked(
            address(safeFactory),
            abi.encodeCall(ISafeProxyFactory.createProxyWithNonce, (safeSingleton, initializer, saltNonce))
        );
    }

    /// @dev A sub-wallet's account: a Safe from the same factory, owned by the sub-wallet's own key alone.
    function _subWallet(string memory label) internal returns (Acct memory a) {
        uint256 key = uint256(keccak256(abi.encode("sub-wallet key", label)));
        address[] memory owners = new address[](1);
        owners[0] = vm.addr(key);
        a = _safeAccount(SUB_WALLET, owners, 1, uint256(keccak256(abi.encode(label, ++_nonce))));
        a.ownerKey = key;
    }

    /// @dev The primary account on Safe: passkey signer + co-signer, 2-of-2. The signer exists (enrolment).
    function _primarySafe(string memory label) internal returns (Acct memory a) {
        uint256 passkey = uint256(keccak256(abi.encode("passkey", label))) % P256_N;
        uint256 server = uint256(keccak256(abi.encode("co-signer", label)));
        (uint256 x, uint256 y) = vm.publicKeyP256(passkey);
        address signer = signerFactory.createSigner(x, y, verifiers);
        address[] memory owners = new address[](2);
        owners[0] = signer;
        owners[1] = vm.addr(server);
        a = _safeAccount(SAFE, owners, 2, uint256(keccak256(abi.encode(label, ++_nonce))));
        a.ownerKey = server;
        a.passkeyKey = passkey;
        a.passkeySigner = signer;
    }

    /// @dev The primary account on Kernel, created beforehand by a plain transaction to KernelFactory.
    function _primaryKernel(string memory label) internal returns (Acct memory a) {
        uint256 passkey = uint256(keccak256(abi.encode("passkey", label))) % P256_N;
        uint256 server = uint256(keccak256(abi.encode("co-signer", label)));
        (uint256 x, uint256 y) = vm.publicKeyP256(passkey);
        bytes memory initData = abi.encodeCall(
            IKernel.initialize,
            (
                bytes21(abi.encodePacked(bytes1(0x01), passkeyValidator)),
                address(0),
                abi.encode(x, y, verifiers, vm.addr(server), RP_ID_HASH, ORIGIN_FIELD),
                bytes(""),
                new bytes[](0)
            )
        );
        bytes32 userSalt = keccak256(abi.encode(label, ++_nonce));
        a.kind = KERNEL;
        a.index = 1;
        a.salt = keccak256(abi.encodePacked(initData, userSalt));
        a.sender = vm.computeCreate2Address(a.salt, kernelProxyHash, address(kernelFactory));
        require(kernelFactory.getAddress(initData, userSalt) == a.sender, "Kernel address prediction");
        vm.prank(makeAddr("anyone creates it"));
        require(kernelFactory.createAccount(initData, userSalt) == a.sender, "KernelFactory.createAccount");
        a.ownerKey = server;
        a.passkeyKey = passkey;
    }

    /*//////////////////////////////////////////////////////////////
                              OPERATIONS
    //////////////////////////////////////////////////////////////*/

    function _pmData(OwnerlessPaymaster pm, Acct memory a, uint48 window, uint128 postOpGas)
        internal
        pure
        returns (bytes memory)
    {
        return abi.encodePacked(address(pm), PM_VERIFICATION_GAS, postOpGas, a.index, a.salt, window);
    }

    function _window(OwnerlessPaymaster pm) internal view returns (uint48) {
        return uint48(block.timestamp / pm.WINDOW());
    }

    /// @dev A transfer of nothing to a fixed address: the cheapest call each account kind makes.
    function _callData(Acct memory a) internal pure returns (bytes memory) {
        address to = address(0xCAFE);
        if (a.kind == KERNEL) return abi.encodeCall(IKernel.execute, (bytes32(0), abi.encodePacked(to, uint256(0))));
        return abi.encodeCall(ISafe4337Module.executeUserOp, (to, 0, "", 0));
    }

    function _op(OwnerlessPaymaster pm, Acct memory a, uint48 window) internal view returns (PackedUserOperation memory) {
        return _opWith(a, _pmData(pm, a, window, PM_POST_OP_GAS), VERIFICATION_GAS, CALL_GAS, PRE_VERIFICATION_GAS, MAX_PRIORITY_FEE, MAX_FEE, 0);
    }

    function _opWith(
        Acct memory a,
        bytes memory paymasterAndData,
        uint128 verificationGas,
        uint128 callGas,
        uint256 preVerificationGas,
        uint128 priorityFee,
        uint128 maxFee,
        uint256 nonceOffset
    ) internal view returns (PackedUserOperation memory op) {
        op.sender = a.sender;
        op.nonce = ep.getNonce(a.sender, 0) + nonceOffset;
        if (a.sender.code.length == 0 && nonceOffset == 0) op.initCode = a.initCode;
        op.callData = _callData(a);
        op.accountGasLimits = bytes32((uint256(verificationGas) << 128) | callGas);
        op.preVerificationGas = preVerificationGas;
        op.gasFees = bytes32((uint256(priorityFee) << 128) | maxFee);
        op.paymasterAndData = paymasterAndData;
        _sign(a, op);
    }

    /// @dev The account's own signature, as the wallet produces it for that kind.
    function _sign(Acct memory a, PackedUserOperation memory op) internal view {
        if (a.kind == KERNEL) {
            bytes32 c = keccak256(
                abi.encode(USER_OP_CHALLENGE_TYPEHASH, ep.getUserOpHash(op), uint48(0), uint48(0), passkeyValidator)
            );
            op.signature = abi.encodePacked(uint48(0), uint48(0), abi.encode(_webauthn(a.passkeyKey, c), _ecdsa(a.ownerKey, c)));
            return;
        }
        op.signature = abi.encodePacked(uint48(0), uint48(0)); // the window header the SafeOp hash reads
        bytes32 h = safeModule.getOperationHash(op);
        if (a.kind == SUB_WALLET) {
            op.signature = abi.encodePacked(uint48(0), uint48(0), _ecdsa(a.ownerKey, h));
            return;
        }
        // Safe's signature layout: owners in address order; the passkey signer's is a contract signature.
        bytes memory passkeySig = _webauthn(a.passkeyKey, h);
        bytes memory contractSig = abi.encodePacked(bytes32(uint256(uint160(a.passkeySigner))), bytes32(uint256(2 * 65)), uint8(0));
        bytes memory serverSig = _ecdsa(a.ownerKey, h);
        bytes memory statics = uint160(a.passkeySigner) < uint160(vm.addr(a.ownerKey))
            ? abi.encodePacked(contractSig, serverSig)
            : abi.encodePacked(serverSig, contractSig);
        op.signature = abi.encodePacked(uint48(0), uint48(0), statics, passkeySig.length, passkeySig);
    }

    struct Settled {
        uint256 debit; // what the EntryPoint took from the paymaster's deposit (UserOperationEvent.actualGasCost)
        uint256 charged; // what the paymaster counted (Sponsored.charged)
        uint48 accountWindow;
        uint48 globalWindow;
        bool success;
    }

    function _bundle(PackedUserOperation[] memory ops) internal returns (Settled[] memory s) {
        vm.recordLogs();
        vm.prank(BUNDLER, BUNDLER);
        ep.handleOps(ops, payable(BUNDLER));
        s = _settled(ops.length);
    }

    function _submit(PackedUserOperation memory op) internal returns (Settled memory) {
        PackedUserOperation[] memory ops = new PackedUserOperation[](1);
        ops[0] = op;
        return _bundle(ops)[0];
    }

    /// @dev Sponsored and UserOperationEvent come in operation order, one each per sponsored operation.
    function _settled(uint256 n) internal returns (Settled[] memory s) {
        s = new Settled[](n);
        Vm.Log[] memory logs = vm.getRecordedLogs();
        uint256 i;
        uint256 k;
        for (uint256 l; l < logs.length; ++l) {
            if (logs[l].topics[0] == SPONSORED_EVENT) {
                (s[i].accountWindow, s[i].globalWindow, s[i].charged) = abi.decode(logs[l].data, (uint48, uint48, uint256));
                ++i;
            } else if (logs[l].topics[0] == USER_OPERATION_EVENT) {
                (, s[k].success, s[k].debit,) = abi.decode(logs[l].data, (uint256, bool, uint256, uint256));
                ++k;
            }
        }
        require(i == n && k == n, "one Sponsored and one UserOperationEvent per operation");
    }

    /// @dev handleOps' revert when the paymaster's validation reverted with `inner`.
    function _paymasterRevert(uint256 opIndex, bytes memory inner) internal pure returns (bytes memory) {
        return abi.encodeWithSelector(IEntryPointV07.FailedOpWithRevert.selector, opIndex, "AA33 reverted", inner);
    }

    /// @dev handleOps' revert when the paymaster's time range does not include now.
    function _notDue() internal pure returns (bytes memory) {
        return abi.encodeWithSelector(IEntryPointV07.FailedOp.selector, 0, "AA32 paymaster expired or not due");
    }

    /// @dev Submit `op` (built before the expectation, since building it calls the chain) and expect `reason`.
    function _sendRefused(PackedUserOperation memory op, bytes memory reason) internal {
        PackedUserOperation[] memory ops = new PackedUserOperation[](1);
        ops[0] = op;
        vm.expectRevert(reason);
        vm.prank(BUNDLER, BUNDLER);
        ep.handleOps(ops, payable(BUNDLER));
    }

    /*//////////////////////////////////////////////////////////////
                          CANONICAL DEPLOYMENT
    //////////////////////////////////////////////////////////////*/

    function _etchDeployers() internal {
        string memory j = vm.readFile(string.concat(FIXTURES, "canonical/deployers.json"));
        vm.etch(ARACHNID, vm.parseJsonBytes(j, ".arachnid.runtimeCode"));
        vm.etch(SAFE_SINGLETON_FACTORY, vm.parseJsonBytes(j, ".safeSingletonFactory.runtimeCode"));
        vm.etch(EIP2470, vm.parseJsonBytes(j, ".eip2470.runtimeCode"));
    }

    /// @dev Through the deployer and salt mainnet used: it must land at the canonical address with mainnet's code.
    function _deployCanonical(string memory name) internal returns (address expected) {
        string memory j = vm.readFile(string.concat(FIXTURES, "canonical/", name, ".json"));
        expected = vm.parseJsonAddress(j, ".address");
        if (expected.code.length != 0) return expected;
        address deployer = vm.parseJsonAddress(j, ".deployer");
        bytes32 salt = vm.parseJsonBytes32(j, ".salt");
        bytes memory initCode = vm.parseJsonBytes(j, ".initCode");
        bool ok;
        if (deployer == EIP2470) {
            (ok,) = deployer.call(abi.encodeWithSignature("deploy(bytes,bytes32)", initCode, salt));
        } else {
            (ok,) = deployer.call(abi.encodePacked(salt, initCode));
        }
        require(ok && expected.code.length != 0, string.concat("not at the canonical address: ", name));
        // Kernel caches block.chainid in immutables: its runtime hash is mainnet's only on chain 1.
        if (!vm.parseJsonBool(j, ".runtimeDependsOnChainId")) {
            require(keccak256(expected.code) == vm.parseJsonBytes32(j, ".runtimeCodeKeccak"), name);
        }
    }

    /// @dev Solady LibClone's ERC-1967 proxy init code (v0.0.168, Kernel v3.1's), as packages/smart-account/src/kernel.ts.
    function _kernelProxyInitCode(address implementation) internal pure returns (bytes memory) {
        return abi.encodePacked(
            hex"603d3d8160223d3973",
            implementation,
            hex"6009",
            hex"5155f3363d3d373d3d363d7f360894a13ba1a3210667c828492db98dca3e2076",
            hex"cc3735a920a3ca505d382bbc545af43d6000803e6038573d6000fd5b3d6000f3"
        );
    }

    /*//////////////////////////////////////////////////////////////
                               SIGNERS
    //////////////////////////////////////////////////////////////*/

    function _ecdsa(uint256 key, bytes32 digest) internal pure returns (bytes memory) {
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(key, digest);
        return abi.encodePacked(r, s, v);
    }

    /// @dev A WebAuthn assertion over `challenge`, as the Safe WebAuthn signer decodes it (user present + verified).
    function _webauthn(uint256 key, bytes32 challenge) internal pure returns (bytes memory) {
        bytes memory authenticatorData = abi.encodePacked(sha256(bytes(RP_ID)), bytes1(0x05), uint32(1));
        bytes memory clientData = abi.encodePacked(
            '{"type":"webauthn.get","challenge":"', _base64url(challenge), '",', CLIENT_DATA_FIELDS, "}"
        );
        bytes32 message = sha256(abi.encodePacked(authenticatorData, sha256(clientData)));
        (bytes32 r, bytes32 s) = vm.signP256(key, message);
        uint256 lowS = uint256(s) > P256_N / 2 ? P256_N - uint256(s) : uint256(s);
        return abi.encode(authenticatorData, CLIENT_DATA_FIELDS, uint256(r), lowS);
    }

    function _base64url(bytes32 data) internal pure returns (string memory) {
        bytes memory table = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
        bytes memory out = new bytes(43);
        uint256 j;
        for (uint256 i = 0; i < 30; i += 3) {
            uint256 n = (uint256(uint8(data[i])) << 16) | (uint256(uint8(data[i + 1])) << 8) | uint256(uint8(data[i + 2]));
            out[j++] = table[(n >> 18) & 63];
            out[j++] = table[(n >> 12) & 63];
            out[j++] = table[(n >> 6) & 63];
            out[j++] = table[n & 63];
        }
        uint256 last = (uint256(uint8(data[30])) << 16) | (uint256(uint8(data[31])) << 8);
        out[j++] = table[(last >> 18) & 63];
        out[j++] = table[(last >> 12) & 63];
        out[j++] = table[(last >> 6) & 63];
        return string(out);
    }
}

/*//////////////////////////////////////////////////////////////
                    SPONSORSHIP AND PROVENANCE
//////////////////////////////////////////////////////////////*/

contract OwnerlessPaymasterTest is OwnerlessPaymasterHarness {
    OwnerlessPaymaster internal pm;

    function setUp() public {
        _setUpStack();
        pm = _deployPaymaster(_policy());
    }

    function test_SponsorsThePrimarySafe_FirstOpWithInitCodeThenLaterOps() public {
        Acct memory a = _primarySafe("alice");
        assertEq(a.sender.code.length, 0, "counterfactual");
        uint256 depositBefore = pm.getDeposit();

        PackedUserOperation memory first = _op(pm, a, _window(pm));
        assertGt(first.initCode.length, 0, "the first op deploys the account");
        Settled memory s1 = _submit(first);
        assertTrue(s1.success, "first op");
        assertGt(a.sender.code.length, 0, "deployed by its first op, through SafeProxyFactory");
        assertEq(a.sender.balance, 0, "the account holds no ETH: the paymaster paid");

        Settled memory s2 = _submit(_op(pm, a, _window(pm)));
        assertTrue(s2.success, "later op");

        assertEq(depositBefore - pm.getDeposit(), s1.debit + s2.debit, "the deposit paid both");
        assertLe(s1.debit, s1.charged, "never counts less than it paid");
        assertLe(s2.debit, s2.charged);
        (uint48 w, uint32 ops, uint128 spent) = pm.usageOf(a.sender);
        assertEq(w, _window(pm));
        assertEq(ops, 2);
        assertEq(spent, s1.charged + s2.charged, "the account's counter is what was charged");
        (uint48 gw, uint128 gSpent) = pm.globalUsage();
        assertEq(gw, w);
        assertEq(gSpent, spent);
    }

    function test_SponsorsAPrimaryKernelAccountDeployedBeforehand() public {
        Acct memory a = _primaryKernel("bob");
        assertGt(a.sender.code.length, 0, "created by a plain transaction to KernelFactory");
        Settled memory s1 = _submit(_op(pm, a, _window(pm)));
        Settled memory s2 = _submit(_op(pm, a, _window(pm)));
        assertTrue(s1.success && s2.success);
        assertLe(s1.debit, s1.charged);
        assertLe(s2.debit, s2.charged);
    }

    function test_SponsorsAKernelAccountWhoseFirstOpCreatesIt() public {
        // The same rule holds when the op's initCode runs KernelFactory itself: the EntryPoint creates the
        // account before it asks the paymaster, and the address proves which factory did.
        uint256 server = 0x5E;
        uint256 passkey = 0xA11CE;
        (uint256 x, uint256 y) = vm.publicKeyP256(passkey);
        bytes memory initData = abi.encodeCall(
            IKernel.initialize,
            (bytes21(abi.encodePacked(bytes1(0x01), passkeyValidator)), address(0), abi.encode(x, y, verifiers, vm.addr(server), RP_ID_HASH, ORIGIN_FIELD), bytes(""), new bytes[](0))
        );
        Acct memory a;
        a.kind = KERNEL;
        a.index = 1;
        a.salt = keccak256(abi.encodePacked(initData, bytes32(0)));
        a.sender = vm.computeCreate2Address(a.salt, kernelProxyHash, address(kernelFactory));
        a.initCode = abi.encodePacked(address(kernelFactory), abi.encodeCall(IKernelFactory.createAccount, (initData, bytes32(0))));
        a.ownerKey = server;
        a.passkeyKey = passkey;
        assertTrue(_submit(_op(pm, a, _window(pm))).success);
        assertGt(a.sender.code.length, 0);
    }

    function test_SponsorsASubWalletAccountFromTheSameFactory() public {
        // A sub-wallet has no passkey: its account is a Safe owned by its own key alone, created by the same
        // SafeProxyFactory. The rule never looks at the owners, so it qualifies exactly as the primary does.
        Acct memory primary = _primarySafe("carol");
        Acct memory sub = _subWallet("carol's savings");
        assertTrue(_submit(_op(pm, primary, _window(pm))).success, "primary");
        Settled memory s1 = _submit(_op(pm, sub, _window(pm)));
        assertTrue(s1.success, "sub-wallet first op (initCode)");
        assertGt(sub.sender.code.length, 0);
        assertTrue(_submit(_op(pm, sub, _window(pm))).success, "sub-wallet later op");
        (, uint32 subOps,) = pm.usageOf(sub.sender);
        (, uint32 primaryOps,) = pm.usageOf(primary.sender);
        assertEq(subOps, 2, "limits are per account: the sub-wallet has its own");
        assertEq(primaryOps, 1);
    }

    function test_RefusesASafeFromAnotherFactoryInstance() public {
        // The same SafeProxyFactory bytecode at another address: same proxies, but not our factory.
        string memory j = vm.readFile(string.concat(FIXTURES, "canonical/SafeProxyFactory.json"));
        bytes memory initCode = vm.parseJsonBytes(j, ".initCode");
        address other;
        assembly {
            other := create(0, add(initCode, 0x20), mload(initCode))
        }
        address[] memory owners = new address[](1);
        owners[0] = vm.addr(0xBAD);
        bytes memory initializer = _safeInitializer(owners, 1);
        Acct memory a;
        a.kind = SUB_WALLET;
        a.ownerKey = 0xBAD;
        a.salt = keccak256(abi.encodePacked(keccak256(initializer), uint256(1)));
        a.sender = vm.computeCreate2Address(a.salt, safeProxyHash, other);
        a.initCode = abi.encodePacked(other, abi.encodeCall(ISafeProxyFactory.createProxyWithNonce, (safeSingleton, initializer, 1)));

        _sendRefused(_op(pm, a, _window(pm)), _paymasterRevert(0, abi.encodeWithSelector(OwnerlessPaymaster.NotFromFactory.selector, a.sender)));

        // Claiming the other factory's account under our factory's index and the same salt changes nothing.
        a.index = 1;
        _sendRefused(_op(pm, a, _window(pm)), _paymasterRevert(0, abi.encodeWithSelector(OwnerlessPaymaster.NotFromFactory.selector, a.sender)));
    }

    function test_RefusesASafeFromOurFactoryWithAnotherSingleton() public {
        // Our factory, but a proxy of other code (any contract will do as the "singleton"): the init code
        // hash differs, so no salt makes the address match.
        address otherSingleton = address(signerFactory);
        vm.prank(makeAddr("anyone"));
        address proxy = safeFactory.createProxyWithNonce(otherSingleton, "", 7);
        Acct memory a;
        a.salt = keccak256(abi.encodePacked(keccak256(""), uint256(7))); // the salt the factory used
        PackedUserOperation memory op;
        op.sender = proxy;
        op.paymasterAndData = _pmData(pm, a, _window(pm), PM_POST_OP_GAS);
        vm.prank(address(ep));
        vm.expectRevert(abi.encodeWithSelector(OwnerlessPaymaster.NotFromFactory.selector, proxy));
        pm.validatePaymasterUserOp(op, bytes32(0), 1);
        assertEq(
            proxy,
            vm.computeCreate2Address(
                a.salt, keccak256(abi.encodePacked(safeFactory.proxyCreationCode(), uint256(uint160(otherSingleton)))), address(safeFactory)
            ),
            "it is our factory's proxy, of other code"
        );
    }

    function test_RefusesAnAccountThatIsNotAFactoryProxy() public {
        // An EOA-shaped sender, or any contract, with whatever salt it claims.
        PackedUserOperation memory op;
        op.sender = makeAddr("some account");
        Acct memory a;
        a.salt = bytes32(uint256(1));
        for (uint8 i; i < 3; ++i) {
            a.index = i;
            op.paymasterAndData = _pmData(pm, a, _window(pm), PM_POST_OP_GAS);
            vm.prank(address(ep));
            vm.expectRevert(abi.encodeWithSelector(OwnerlessPaymaster.NotFromFactory.selector, op.sender));
            pm.validatePaymasterUserOp(op, bytes32(0), 1);
        }
    }

    function test_RefusesAQualifyingAccountWithTheWrongSalt() public {
        Acct memory a = _subWallet("dave");
        a.salt = bytes32(uint256(a.salt) ^ 1);
        _sendRefused(_op(pm, a, _window(pm)), _paymasterRevert(0, abi.encodeWithSelector(OwnerlessPaymaster.NotFromFactory.selector, a.sender)));
    }

    function test_AccountAddressMatchesBothFactories() public {
        Acct memory s = _subWallet("erin");
        assertEq(pm.accountAddress(0, s.salt), s.sender);
        Acct memory k = _primaryKernel("erin");
        assertEq(pm.accountAddress(1, k.salt), k.sender);
        assertEq(pm.accountAddress(2, k.salt), address(0), "no third factory");
    }
}

/*//////////////////////////////////////////////////////////////
                    PER-ACCOUNT LIMITS AND THE GLOBAL CAP
//////////////////////////////////////////////////////////////*/

contract OwnerlessPaymasterLimitsTest is OwnerlessPaymasterHarness {
    // (2.0M + 0.3M + 0.15M + 0.05M) gas + 0.1M preVerificationGas, at 2 gwei.
    uint256 internal constant MAX_COST = (2_000_000 + 300_000 + 150_000 + 50_000 + 100_000) * 2 gwei;

    function setUp() public {
        _setUpStack();
    }

    function test_PerAccountOperationLimit() public {
        OwnerlessPaymaster pm = _deployPaymaster(_policy());
        Acct memory a = _subWallet("frank");
        for (uint256 i; i < 5; ++i) assertTrue(_submit(_op(pm, a, _window(pm))).success);
        _sendRefused(_op(pm, a, _window(pm)), _paymasterRevert(
            0, abi.encodeWithSelector(OwnerlessPaymaster.AccountOpsExhausted.selector, a.sender, _window(pm))
        ));

        // Another account is not affected, and the next window gives this one its five again.
        assertTrue(_submit(_op(pm, _subWallet("grace"), _window(pm))).success);
        vm.warp((uint256(_window(pm)) + 1) * 1 days);
        assertTrue(_submit(_op(pm, a, _window(pm))).success, "a new window");
        (, uint32 ops,) = pm.usageOf(a.sender);
        assertEq(ops, 1);
    }

    function test_PerAccountCostLimit() public {
        OwnerlessPaymaster.Policy memory p = _policy();
        p.maxCostPerOp = MAX_COST;
        p.maxCostPerAccount = MAX_COST; // one op's reservation fills it
        OwnerlessPaymaster pm = _deployPaymaster(p);
        Acct memory a = _subWallet("heidi");
        Settled memory s = _submit(_op(pm, a, _window(pm)));
        assertTrue(s.success);
        (,, uint128 spent) = pm.usageOf(a.sender);
        assertEq(spent, s.charged, "settled down to the charge");
        _sendRefused(_op(pm, a, _window(pm)), _paymasterRevert(
            0,
            abi.encodeWithSelector(OwnerlessPaymaster.AccountBudgetExhausted.selector, a.sender, _window(pm), s.charged)
        ));
    }

    function test_PerOperationCostLimit() public {
        OwnerlessPaymaster.Policy memory p = _policy();
        p.maxCostPerOp = MAX_COST - 1;
        OwnerlessPaymaster pm = _deployPaymaster(p);
        _sendRefused(_op(pm, _subWallet("ivan"), _window(pm)), _paymasterRevert(0, abi.encodeWithSelector(OwnerlessPaymaster.OpCostAboveLimit.selector, MAX_COST, MAX_COST - 1)));
    }

    function test_GlobalCapHoldsInsideOneBundle() public {
        // The Sybil case: three fresh accounts from the public factory, one bundle. The EntryPoint validates
        // all three before executing any, and each validation sees the reservations before it.
        OwnerlessPaymaster.Policy memory p = _policy();
        p.maxCostPerOp = MAX_COST;
        p.maxCostPerAccount = MAX_COST;
        p.maxCostGlobal = 2 * MAX_COST + MAX_COST / 2;
        OwnerlessPaymaster pm = _deployPaymaster(p);
        PackedUserOperation[] memory ops = new PackedUserOperation[](3);
        for (uint256 i; i < 3; ++i) ops[i] = _op(pm, _subWallet(string(abi.encode("sybil", i))), _window(pm));
        vm.expectRevert(
            abi.encodeWithSelector(
                IEntryPointV07.FailedOpWithRevert.selector,
                2,
                "AA33 reverted",
                abi.encodeWithSelector(OwnerlessPaymaster.GlobalBudgetExhausted.selector, _window(pm), 2 * MAX_COST)
            )
        );
        vm.prank(BUNDLER, BUNDLER);
        ep.handleOps(ops, payable(BUNDLER));

        // Without the third, the bundle goes through, and the refunds then make room again.
        PackedUserOperation[] memory two = new PackedUserOperation[](2);
        two[0] = ops[0];
        two[1] = ops[1];
        Settled[] memory s = _bundle(two);
        (, uint128 gSpent) = pm.globalUsage();
        assertEq(gSpent, s[0].charged + s[1].charged);
        assertTrue(_submit(ops[2]).success, "room once the first two settled");
    }

    function test_GlobalCapRefusesEveryoneUntilTheWindowResets() public {
        OwnerlessPaymaster.Policy memory p = _policy();
        p.maxCostPerOp = MAX_COST;
        p.maxCostPerAccount = MAX_COST;
        p.maxCostGlobal = 3 * MAX_COST;
        OwnerlessPaymaster pm = _deployPaymaster(p);
        uint48 w = _window(pm);
        uint256 total;
        uint256 i;
        // Fresh accounts until the global budget will not take another op's reservation.
        for (;; ++i) {
            (, uint128 g) = pm.globalUsage();
            if (g + MAX_COST > 3 * MAX_COST) break;
            Settled memory s = _submit(_op(pm, _subWallet(string(abi.encode("drain", i))), w));
            total += s.debit;
        }
        assertGt(i, 3, "refunds let more ops in than three reservations would");
        assertLe(total, 3 * MAX_COST, "the window paid no more than the cap");

        Acct memory honest = _primarySafe("judy");
        (, uint128 spentNow) = pm.globalUsage();
        _sendRefused(_op(pm, honest, w), _paymasterRevert(0, abi.encodeWithSelector(OwnerlessPaymaster.GlobalBudgetExhausted.selector, w, spentNow)));

        // Asking for the next window early is refused by the EntryPoint (the paymaster's validAfter).
        _sendRefused(_op(pm, honest, w + 1), _notDue());

        // The next window: everyone again.
        vm.warp((uint256(w) + 1) * 1 days);
        assertTrue(_submit(_op(pm, honest, w + 1)).success);
        (uint48 gw, uint128 gs) = pm.globalUsage();
        assertEq(gw, w + 1);
        assertLe(gs, MAX_COST);
    }

    function test_WindowsAreBoundToTheClockByTheEntryPoint() public {
        OwnerlessPaymaster pm = _deployPaymaster(_policy());
        Acct memory a = _subWallet("ken");
        uint48 w = _window(pm);

        // A past window, beyond its grace: refused (AA32), nothing recorded.
        _sendRefused(_op(pm, a, w - 1), _notDue());
        (uint48 aw,,) = pm.usageOf(a.sender);
        assertEq(aw, 0, "a refused op leaves no trace");

        // Inside the grace period after window w: still valid, counted in w.
        vm.warp((uint256(w) + 1) * 1 days + 30 minutes);
        Settled memory late = _submit(_op(pm, a, w));
        assertEq(late.accountWindow, w);
        // Once window w + 1 is open, a late op naming w is counted in w + 1, the later (stricter) one.
        assertEq(_submit(_op(pm, a, w + 1)).accountWindow, w + 1);
        Settled memory bumped = _submit(_op(pm, a, w));
        assertEq(bumped.accountWindow, w + 1, "counted in the window already open");
        assertEq(bumped.globalWindow, w + 1);
        (, uint32 ops,) = pm.usageOf(a.sender);
        assertEq(ops, 2, "the new window counts the two ops in it");

        // The grace period's last second, and the first after it.
        vm.warp((uint256(w) + 1) * 1 days + 1 hours - 1);
        assertTrue(_submit(_op(pm, a, w)).success, "the last second of the grace period");
        vm.warp((uint256(w) + 1) * 1 days + 1 hours);
        _sendRefused(_op(pm, a, w), _notDue());
    }

    function test_PostOpAtItsMinimumGasSettles() public {
        OwnerlessPaymaster pm = _deployPaymaster(_policy());
        Acct memory a = _subWallet("leo");
        bytes memory pnd = _pmData(pm, a, _window(pm), uint128(pm.MIN_POST_OP_GAS()));
        Settled memory s = _submit(_opWith(a, pnd, VERIFICATION_GAS, CALL_GAS, PRE_VERIFICATION_GAS, MAX_PRIORITY_FEE, MAX_FEE, 0));
        assertTrue(s.success);
        assertLt(s.charged, MAX_COST, "postOp ran and refunded");

        pnd = _pmData(pm, a, _window(pm), uint128(pm.MIN_POST_OP_GAS() - 1));
        _sendRefused(_opWith(a, pnd, VERIFICATION_GAS, CALL_GAS, PRE_VERIFICATION_GAS, MAX_PRIORITY_FEE, MAX_FEE, 0), _paymasterRevert(
            0, abi.encodeWithSelector(OwnerlessPaymaster.PostOpGasTooLow.selector, pm.MIN_POST_OP_GAS() - 1, pm.MIN_POST_OP_GAS())
        ));
    }

    function test_AnOpWhoseCallRevertsIsStillChargedWhatItCost() public {
        OwnerlessPaymaster pm = _deployPaymaster(_policy());
        Acct memory a = _subWallet("mia");
        _submit(_op(pm, a, _window(pm))); // deploy
        PackedUserOperation memory op = _op(pm, a, _window(pm));
        op.callData = abi.encodeCall(ISafe4337Module.executeUserOp, (address(ep), 1 ether, "", 0)); // the account has no ETH
        _sign(a, op);
        Settled memory s = _submit(op);
        assertFalse(s.success, "the call reverted");
        assertLe(s.debit, s.charged, "still never under-counted");
    }
}

/*//////////////////////////////////////////////////////////////
                    FUNDING: ANYONE ADDS, NOBODY REMOVES
//////////////////////////////////////////////////////////////*/

contract OwnerlessPaymasterFundingTest is OwnerlessPaymasterHarness {
    OwnerlessPaymaster internal pm;
    address internal stranger = makeAddr("stranger");

    function setUp() public {
        _setUpStack();
        pm = _deployPaymaster(_policy());
        vm.deal(stranger, 100 ether);
    }

    function test_AnyoneCanTopUpTheDeposit() public {
        uint256 before = pm.getDeposit();
        vm.startPrank(stranger);
        pm.deposit{value: 1 ether}();
        (bool ok,) = address(pm).call{value: 2 ether}("");
        assertTrue(ok, "a plain transfer");
        ep.depositTo{value: 3 ether}(address(pm));
        vm.stopPrank();
        assertEq(pm.getDeposit(), before + 6 ether);
        assertEq(address(pm).balance, 0, "nothing stays in the contract");
    }

    function test_AnyoneCanAddStake_AlwaysWithTheImmutableDelay() public {
        IEntryPointV07.DepositInfo memory before = ep.getDepositInfo(address(pm));
        assertTrue(before.staked);
        assertEq(before.unstakeDelaySec, 1 days);
        vm.prank(stranger);
        pm.addStake{value: 4 ether}();
        IEntryPointV07.DepositInfo memory info = ep.getDepositInfo(address(pm));
        assertEq(info.stake, before.stake + 4 ether);
        assertEq(info.unstakeDelaySec, pm.UNSTAKE_DELAY_SEC());
        assertTrue(info.staked);
        assertEq(info.withdrawTime, 0, "never unlocking");
    }

    function test_TheContractHasNoWayToWithdrawUnstakeOrAdminister() public {
        bytes[] memory calls = new bytes[](12);
        calls[0] = abi.encodeWithSignature("withdrawTo(address,uint256)", stranger, 1);
        calls[1] = abi.encodeWithSignature("unlockStake()");
        calls[2] = abi.encodeWithSignature("withdrawStake(address)", stranger);
        calls[3] = abi.encodeWithSignature("owner()");
        calls[4] = abi.encodeWithSignature("transferOwnership(address)", stranger);
        calls[5] = abi.encodeWithSignature("renounceOwnership()");
        calls[6] = abi.encodeWithSignature("pause()");
        calls[7] = abi.encodeWithSignature("setSponsored(address,bool)", stranger, true);
        calls[8] = abi.encodeWithSignature("setBudget(uint256,uint256)", 0, 0);
        calls[9] = abi.encodeWithSignature("upgradeTo(address)", stranger);
        calls[10] = abi.encodeWithSignature("execute(address,uint256,bytes)", address(ep), 0, "");
        calls[11] = abi.encodeWithSignature("addStake(uint32)", uint32(1));
        uint256 deposit = pm.getDeposit();
        for (uint256 i; i < calls.length; ++i) {
            vm.prank(stranger);
            (bool ok,) = address(pm).call(calls[i]);
            assertFalse(ok, "no such function, and no fallback to land in");
        }
        assertEq(pm.getDeposit(), deposit);
    }

    function test_TheEntryPointRefusesEveryoneElseTheStakeAndDeposit() public {
        // Unstaking and withdrawing act on msg.sender's own entry: nobody but the paymaster can touch its
        // stake or deposit, and the paymaster has no code that would.
        IEntryPointV07.DepositInfo memory before = ep.getDepositInfo(address(pm));
        vm.startPrank(stranger);
        vm.expectRevert("not staked");
        ep.unlockStake();
        vm.expectRevert("No stake to withdraw");
        ep.withdrawStake(payable(stranger));
        vm.expectRevert("Withdraw amount too large");
        ep.withdrawTo(payable(stranger), 1);
        vm.stopPrank();
        IEntryPointV07.DepositInfo memory info = ep.getDepositInfo(address(pm));
        assertEq(info.deposit, before.deposit);
        assertEq(info.stake, before.stake);
        assertEq(info.withdrawTime, 0);

        // Even years later, the stake is still locked and staked.
        vm.warp(block.timestamp + 3650 days);
        assertTrue(ep.getDepositInfo(address(pm)).staked);
    }

    function test_RuntimeCodeHasNoDelegatecallSelfdestructOrCreate() public view {
        bytes memory code = address(pm).code;
        // The root build appends no CBOR metadata (foundry.toml, cbor_metadata = false): the whole code is instructions.
        uint256 end = code.length;
        uint256 calls;
        for (uint256 i; i < end; ++i) {
            uint8 op = uint8(code[i]);
            if (op >= 0x60 && op <= 0x7f) {
                i += op - 0x5f; // PUSH1..PUSH32 data
                continue;
            }
            assertTrue(op != 0xf4 && op != 0xff && op != 0xf2 && op != 0xf0 && op != 0xf5, "no DELEGATECALL, SELFDESTRUCT, CALLCODE, CREATE");
            if (op == 0xf1) ++calls;
        }
        assertLe(calls, 2, "CALL only for depositTo and addStake (the balanceOf view is a STATICCALL)");
    }

    function test_OnlyTheEntryPointValidatesAndSettles() public {
        PackedUserOperation memory op;
        vm.expectRevert(OwnerlessPaymaster.NotEntryPoint.selector);
        pm.validatePaymasterUserOp(op, bytes32(0), 0);
        vm.expectRevert(OwnerlessPaymaster.NotEntryPoint.selector);
        pm.postOp(0, abi.encode(address(1), uint48(0), uint48(0), uint256(0), uint256(0)), 0, 0);
    }
}

/*//////////////////////////////////////////////////////////////
                 VALIDATION AND SETTLEMENT, UNIT LEVEL
//////////////////////////////////////////////////////////////*/

contract OwnerlessPaymasterUnitTest is OwnerlessPaymasterHarness {
    OwnerlessPaymaster internal pm;
    Acct internal acct;

    function setUp() public {
        _setUpStack();
        pm = _deployPaymaster(_policy());
        Acct memory a = _subWallet("unit");
        acct = a;
    }

    function _validate(bytes memory pnd, uint256 maxCost) internal returns (bytes memory ctx, uint256 vd) {
        PackedUserOperation memory op;
        op.sender = acct.sender;
        op.accountGasLimits = bytes32((uint256(VERIFICATION_GAS) << 128) | CALL_GAS);
        op.paymasterAndData = pnd;
        vm.prank(address(ep));
        return pm.validatePaymasterUserOp(op, bytes32(0), maxCost);
    }

    function test_ValidationDataIsTheWindowPlusGrace() public {
        uint48 w = 20_833; // 1_800_000_000 / 86400
        assertEq(_window(pm), w);
        (, uint256 vd) = _validate(_pmData(pm, acct, w, PM_POST_OP_GAS), 1);
        assertEq(address(uint160(vd)), address(0), "no signature failure");
        assertEq(uint48(vd >> 160), uint256(w + 1) * 1 days - 1 + 1 hours, "validUntil");
        assertEq(uint48(vd >> 208), uint256(w) * 1 days, "validAfter");
    }

    function test_ValidationDoesNotDependOnTheClock() public {
        bytes memory pnd = _pmData(pm, acct, 7, PM_POST_OP_GAS);
        uint256 snap = vm.snapshotState();
        (bytes memory c1, uint256 v1) = _validate(pnd, 123);
        vm.revertToState(snap);
        vm.warp(block.timestamp + 400 days);
        vm.roll(block.number + 1_000_000);
        (bytes memory c2, uint256 v2) = _validate(pnd, 123);
        assertEq(keccak256(c1), keccak256(c2));
        assertEq(v1, v2);
    }

    function test_RefusesMalformedPaymasterData() public {
        bytes memory pnd = _pmData(pm, acct, 1, PM_POST_OP_GAS);
        bytes memory short = new bytes(pnd.length - 1);
        for (uint256 i; i < short.length; ++i) short[i] = pnd[i];
        PackedUserOperation memory op;
        op.sender = acct.sender;
        op.paymasterAndData = short;
        vm.prank(address(ep));
        vm.expectRevert(abi.encodeWithSelector(OwnerlessPaymaster.BadPaymasterData.selector, short.length));
        pm.validatePaymasterUserOp(op, bytes32(0), 1);
        op.paymasterAndData = abi.encodePacked(pnd, uint8(0));
        vm.prank(address(ep));
        vm.expectRevert(abi.encodeWithSelector(OwnerlessPaymaster.BadPaymasterData.selector, pnd.length + 1));
        pm.validatePaymasterUserOp(op, bytes32(0), 1);
    }

    function test_RefusesAWindowPastUint48Time() public {
        uint48 w = uint48(uint256(type(uint48).max) / 1 days);
        PackedUserOperation memory op;
        op.sender = acct.sender;
        op.paymasterAndData = _pmData(pm, acct, w, PM_POST_OP_GAS);
        vm.prank(address(ep));
        vm.expectRevert(abi.encodeWithSelector(OwnerlessPaymaster.WindowOutOfRange.selector, w));
        pm.validatePaymasterUserOp(op, bytes32(0), 1);
    }

    function test_PostOpRefundsOnlyIntoTheWindowItReservedIn() public {
        uint48 w = _window(pm);
        (bytes memory ctx,) = _validate(_pmData(pm, acct, w, PM_POST_OP_GAS), 0.01 ether);
        // Another op of the same account opens window w + 1 before this one settles (same bundle).
        (bytes memory ctx2,) = _validate(_pmData(pm, acct, w + 1, PM_POST_OP_GAS), 0.002 ether);
        vm.startPrank(address(ep));
        pm.postOp(0, ctx, 0, 1 gwei);
        (uint48 aw,, uint128 spent) = pm.usageOf(acct.sender);
        assertEq(aw, w + 1);
        assertEq(spent, 0.002 ether, "window w + 1 is not credited with w's refund");
        pm.postOp(0, ctx2, 0, 1 gwei);
        vm.stopPrank();
        (,, spent) = pm.usageOf(acct.sender);
        assertLt(spent, 0.002 ether, "its own refund applies");
    }

    function test_PostOpChargeIsActualPlusTheBoundedOverhead() public {
        uint48 w = _window(pm);
        (bytes memory ctx,) = _validate(_pmData(pm, acct, w, PM_POST_OP_GAS), 0.01 ether);
        (,,, uint256 reserved, uint256 overheadGas) = abi.decode(ctx, (address, uint48, uint48, uint256, uint256));
        assertEq(reserved, 0.01 ether);
        assertEq(overheadGas, PM_POST_OP_GAS + pm.POST_OP_OVERHEAD_GAS() + (CALL_GAS + PM_POST_OP_GAS) / 10);
        vm.recordLogs();
        vm.prank(address(ep));
        pm.postOp(0, ctx, 0.001 ether, 2 gwei);
        (,, uint128 spent) = pm.usageOf(acct.sender);
        assertEq(spent, 0.001 ether + overheadGas * 2 gwei);
    }

    function testFuzz_PostOpNeverRevertsAndNeverChargesMoreThanReserved(
        uint128 maxCost,
        uint256 actualGasCost,
        uint256 fee,
        uint128 callGas,
        uint128 postOpGas
    ) public {
        maxCost = uint128(bound(maxCost, 0, 0.01 ether));
        postOpGas = uint128(bound(postOpGas, pm.MIN_POST_OP_GAS(), type(uint128).max));
        PackedUserOperation memory op;
        op.sender = acct.sender;
        op.accountGasLimits = bytes32(uint256(callGas));
        op.paymasterAndData = _pmData(pm, acct, _window(pm), postOpGas);
        vm.startPrank(address(ep));
        (bytes memory ctx,) = pm.validatePaymasterUserOp(op, bytes32(0), maxCost);
        pm.postOp(0, ctx, actualGasCost, fee);
        vm.stopPrank();
        (,, uint128 spent) = pm.usageOf(acct.sender);
        assertLe(spent, maxCost);
        if (actualGasCost >= maxCost) assertEq(spent, maxCost, "never below the EntryPoint's own figure");
        else assertGe(spent, actualGasCost);
    }

    function test_ConstructorRefusesUnsafePolicies() public {
        IEntryPointFunding e = IEntryPointFunding(address(ep));
        OwnerlessPaymaster.Policy memory p;

        p = _policy();
        vm.expectRevert(OwnerlessPaymaster.BadConfig.selector);
        new OwnerlessPaymaster(IEntryPointFunding(address(0)), p);

        p = _policy();
        p.factory0 = address(0);
        vm.expectRevert(OwnerlessPaymaster.BadConfig.selector);
        new OwnerlessPaymaster(e, p);

        p = _policy();
        p.proxyInitCodeHash1 = bytes32(0); // a factory without a hash
        vm.expectRevert(OwnerlessPaymaster.BadConfig.selector);
        new OwnerlessPaymaster(e, p);

        p = _policy();
        p.factory1 = p.factory0;
        p.proxyInitCodeHash1 = p.proxyInitCodeHash0;
        vm.expectRevert(OwnerlessPaymaster.BadConfig.selector);
        new OwnerlessPaymaster(e, p);

        p = _policy();
        p.grace = p.window;
        vm.expectRevert(OwnerlessPaymaster.BadConfig.selector);
        new OwnerlessPaymaster(e, p);

        p = _policy();
        p.maxCostPerOp = p.maxCostPerAccount + 1;
        vm.expectRevert(OwnerlessPaymaster.BadConfig.selector);
        new OwnerlessPaymaster(e, p);

        p = _policy();
        p.maxCostPerAccount = p.maxCostGlobal + 1;
        vm.expectRevert(OwnerlessPaymaster.BadConfig.selector);
        new OwnerlessPaymaster(e, p);

        p = _policy();
        p.maxCostGlobal = uint256(type(uint128).max) + 1;
        p.maxCostPerAccount = p.maxCostGlobal;
        vm.expectRevert(OwnerlessPaymaster.BadConfig.selector);
        new OwnerlessPaymaster(e, p);

        p = _policy();
        p.maxOpsPerAccount = 0;
        vm.expectRevert(OwnerlessPaymaster.BadConfig.selector);
        new OwnerlessPaymaster(e, p);

        p = _policy();
        p.unstakeDelaySec = 1 days - 1;
        vm.expectRevert(OwnerlessPaymaster.BadConfig.selector);
        new OwnerlessPaymaster(e, p);

        // A single factory is fine.
        p = _policy();
        p.factory1 = address(0);
        p.proxyInitCodeHash1 = bytes32(0);
        OwnerlessPaymaster single = new OwnerlessPaymaster(e, p);
        assertEq(single.accountAddress(1, bytes32(0)), address(0));
    }
}

/*//////////////////////////////////////////////////////////////
                  PROPERTY: SPEND NEVER EXCEEDS THE CAPS
//////////////////////////////////////////////////////////////*/

/**
 * Random bundles from a handful of Sybil accounts (fresh sub-wallet Safes, all from the public factory)
 * through the real EntryPoint, with random gas limits, fees, windows (current, previous, next) and clock
 * moves. What is measured is what the EntryPoint actually took from the deposit (UserOperationEvent),
 * not what the paymaster thinks it spent.
 */
contract OwnerlessPaymasterPropertyTest is OwnerlessPaymasterHarness {
    OwnerlessPaymaster internal pm;
    Acct[6] internal accounts;
    bool[6] internal deployed;

    uint256 internal constant WINDOW = 6 hours;
    uint256 internal constant GRACE = 30 minutes;
    uint256 internal constant PER_OP = 0.004 ether;
    uint256 internal constant PER_ACCOUNT = 0.006 ether;
    uint256 internal constant GLOBAL = 0.012 ether;
    uint256 internal constant OPS = 3;

    mapping(uint48 window => uint256 debit) internal debitInGlobalWindow;
    mapping(bytes32 accountWindow => uint256 debit) internal debitOfAccountInWindow;
    mapping(bytes32 accountWindow => uint256 ops) internal opsOfAccountInWindow;

    function setUp() public {
        _setUpStack();
        OwnerlessPaymaster.Policy memory p = _policy();
        p.window = WINDOW;
        p.grace = GRACE;
        p.maxCostPerOp = PER_OP;
        p.maxCostPerAccount = PER_ACCOUNT;
        p.maxCostGlobal = GLOBAL;
        p.maxOpsPerAccount = OPS;
        pm = _deployPaymaster(p);
        for (uint256 i; i < 6; ++i) accounts[i] = _subWallet(string(abi.encode("sybil", i)));
    }

    function testFuzz_SponsoredSpendNeverExceedsTheCaps(uint256 seed) public {
        uint256 start = block.timestamp;
        uint256 total;
        for (uint256 step; step < 16; ++step) {
            seed = uint256(keccak256(abi.encode(seed, step)));
            vm.warp(block.timestamp + (seed % 1 hours));
            vm.fee(bound(seed >> 8, 0, 2 gwei));
            uint256 n = 1 + (seed >> 16) % 4;
            PackedUserOperation[] memory ops = new PackedUserOperation[](n);
            uint256[] memory who = new uint256[](n);
            for (uint256 j; j < n; ++j) {
                uint256 r = uint256(keccak256(abi.encode(seed, j)));
                who[j] = r % 6;
                uint256 offset;
                for (uint256 m; m < j; ++m) if (who[m] == who[j]) ++offset;
                ops[j] = _randomOp(accounts[who[j]], r, offset);
            }
            total += _bundleAsABundlerWould(ops, who);
            // The counters themselves never pass their caps.
            (, uint128 g) = pm.globalUsage();
            assertLe(g, GLOBAL);
            for (uint256 i; i < 6; ++i) {
                (, uint32 c, uint128 spent) = pm.usageOf(accounts[i].sender);
                assertLe(spent, PER_ACCOUNT);
                assertLe(c, OPS);
            }
        }
        // Over the whole run: at most (n + 2) windows' worth, n the windows the run spanned.
        uint256 spanned = (block.timestamp - start) / WINDOW + 1;
        assertLe(total, (spanned + 2) * GLOBAL);
    }

    /// @dev Submit; when the EntryPoint names a failing op, drop it and submit the rest, as a bundler does
    ///      after simulating the bundle.
    function _bundleAsABundlerWould(PackedUserOperation[] memory ops, uint256[] memory who)
        internal
        returns (uint256 debited)
    {
        while (ops.length > 0) {
            vm.recordLogs();
            vm.prank(BUNDLER, BUNDLER);
            try ep.handleOps(ops, payable(BUNDLER)) {
                Settled[] memory s = _settled(ops.length);
                for (uint256 j; j < ops.length; ++j) {
                    deployed[who[j]] = true;
                    debited += _account(ops[j].sender, s[j]);
                }
                return debited;
            } catch (bytes memory err) {
                bytes4 sel = bytes4(err);
                require(
                    sel == IEntryPointV07.FailedOp.selector || sel == IEntryPointV07.FailedOpWithRevert.selector,
                    "handleOps failed other than on one operation"
                );
                uint256 bad;
                assembly {
                    bad := mload(add(err, 36))
                }
                // Drop it and every later op of the same account: their nonce (and, for a new account, its
                // deployment) depended on it.
                uint256 kept;
                PackedUserOperation[] memory rest = new PackedUserOperation[](ops.length);
                uint256[] memory restWho = new uint256[](ops.length);
                for (uint256 j; j < ops.length; ++j) {
                    if (j == bad || (j > bad && who[j] == who[bad])) continue;
                    rest[kept] = ops[j];
                    restWho[kept++] = who[j];
                }
                assembly {
                    mstore(rest, kept)
                    mstore(restWho, kept)
                }
                ops = rest;
                who = restWho;
            }
        }
    }

    function _account(address sender, Settled memory s) internal returns (uint256) {
        assertLe(s.debit, s.charged, "the paymaster never counts less than the EntryPoint took");
        // The op ran inside its global window or that window's grace period.
        assertGe(block.timestamp, uint256(s.globalWindow) * WINDOW);
        assertLt(block.timestamp, (uint256(s.globalWindow) + 1) * WINDOW + GRACE);
        assertGe(s.globalWindow, s.accountWindow);

        debitInGlobalWindow[s.globalWindow] += s.debit;
        assertLe(debitInGlobalWindow[s.globalWindow], GLOBAL, "global cap per window");
        bytes32 key = keccak256(abi.encode(sender, s.accountWindow));
        debitOfAccountInWindow[key] += s.debit;
        assertLe(debitOfAccountInWindow[key], PER_ACCOUNT, "account cap per window");
        opsOfAccountInWindow[key] += 1;
        assertLe(opsOfAccountInWindow[key], OPS, "account ops per window");
        assertLe(s.debit, PER_OP, "per-op cap");
        return s.debit;
    }

    function _randomOp(Acct memory a, uint256 r, uint256 nonceOffset) internal view returns (PackedUserOperation memory) {
        uint48 w = uint48(block.timestamp / WINDOW);
        uint256 pick = (r >> 200) % 8;
        if (pick == 0 && w > 0) w -= 1; // late, maybe inside the grace period
        else if (pick == 1) w += 1; // early: the EntryPoint refuses it
        // The second op of an account in one bundle must not redeploy it.
        if (nonceOffset > 0 || deployed[_indexOf(a.sender)]) a.initCode = "";
        uint128 postOp = uint128(bound(r >> 8, pm.MIN_POST_OP_GAS(), 120_000));
        bytes memory pnd = abi.encodePacked(address(pm), uint128(120_000), postOp, a.index, a.salt, w);
        uint128 priority = uint128(bound(r >> 40, 0, 2 gwei));
        uint128 maxFee = uint128(bound(r >> 72, priority, 3 gwei));
        PackedUserOperation memory op;
        op.sender = a.sender;
        op.nonce = ep.getNonce(a.sender, 0) + nonceOffset;
        op.initCode = a.initCode;
        op.callData = _callData(a);
        op.accountGasLimits =
            bytes32((uint256(bound(r >> 104, 400_000, 800_000)) << 128) | bound(r >> 128, 40_000, 400_000));
        op.preVerificationGas = bound(r >> 152, 21_000, 150_000);
        op.gasFees = bytes32((uint256(priority) << 128) | maxFee);
        op.paymasterAndData = pnd;
        _sign(a, op);
        return op;
    }

    function _indexOf(address sender) internal view returns (uint256) {
        for (uint256 i; i < 6; ++i) if (accounts[i].sender == sender) return i;
        revert("unknown account");
    }
}
