// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {ReclaimProofBuilder} from "./utils/ReclaimProofBuilder.sol";
import {FiatEscrow} from "../ramp/FiatEscrow.sol";
import {OffRampEscrow} from "../ramp/OffRampEscrow.sol";
import {LPRegistry} from "../ramp/LPRegistry.sol";
import {ReclaimZkTlsVerifier} from "../ramp/ReclaimZkTlsVerifier.sol";
import {IAttestorVerifier} from "../ramp/IAttestorVerifier.sol";
import {IPriceOracle} from "../ramp/IPriceOracle.sol";

contract FixedOracle is IPriceOracle {
    function brlCentsPerUnit() external view returns (uint256, uint64) {
        return (1_500_000, uint64(block.timestamp));
    }
}

/// Entrypoint and pool in one: `assetConfig`, SCOPE and nonce are what the escrow reads to
/// index a shielded delivery for rescue.
contract PoolSink {
    uint256 public constant SCOPE = 7;
    uint256 public nonce;
    uint256 public received;

    function deposit(uint256) external payable returns (uint256) {
        received += msg.value;
        return ++nonce;
    }

    function assetConfig(address) external view returns (address, uint256, uint256, uint256) {
        return (address(this), 0, 0, 0);
    }
}

/// Both ramps settled by a zkTLS proof rather than a trusted quorum - the only way PIX and boleto
/// settle (IAttestorVerifier.provesBankSession): task 2.2 wired to 2.1 and to the off-ramp.
contract ZkTlsRampIntegrationTest is ReclaimProofBuilder {
    FiatEscrow escrow;
    OffRampEscrow offramp;
    LPRegistry registry;
    ReclaimZkTlsVerifier verifier;
    PoolSink pool;

    uint256 w1 = 0x11;
    uint256 w2 = 0x22;
    address governor = address(0x60F);
    address lp = makeAddr("lp");
    address taker = makeAddr("taker");
    address payout = makeAddr("payout");
    address seller = makeAddr("seller");

    bytes32 constant PIX = keccak256("lp@pix.example");
    uint16 constant PIX_MASK = uint16(1 << uint8(IAttestorVerifier.Rail.PIX));
    uint16 constant BOLETO_MASK = uint16(1 << uint8(IAttestorVerifier.Rail.BOLETO));
    /// A second allowlisted endpoint: the bank's boleto-payment receipts.
    bytes32 constant BOLETO_TEMPLATE = keccak256("template: api.bank.example boleto receipt");
    string constant BOLETO_PREFIX = "https://api.bank.example/boletos/";
    /// N-08: the pages of money SENT - the off-ramp LP's PIX payout and the bill it paid - are their own
    /// templates, classified SENT; BANK_TEMPLATE and BOLETO_TEMPLATE are the RECEIVED pages.
    bytes32 constant PIX_SENT_TEMPLATE = keccak256("template: api.bank.example pix sent");
    bytes32 constant BOLETO_PAID_TEMPLATE = keccak256("template: api.bank.example boleto paid");

    function setUp() public {
        vm.warp(1_700_000_000);
        // The LP runs the bank session, so it is the claim's owner (I-22).
        claimOwner = lp;
        address[] memory set = new address[](2);
        (set[0], set[1]) = vm.addr(w1) < vm.addr(w2)
            ? (vm.addr(w1), vm.addr(w2))
            : (vm.addr(w2), vm.addr(w1));
        bytes32[] memory templates = new bytes32[](4);
        (templates[0], templates[1], templates[2], templates[3]) = (BANK_TEMPLATE, BOLETO_TEMPLATE, PIX_SENT_TEMPLATE, BOLETO_PAID_TEMPLATE);
        string[] memory prefixes = new string[](4);
        (prefixes[0], prefixes[1], prefixes[2], prefixes[3]) = (BANK_PREFIX, BOLETO_PREFIX, BANK_PREFIX, BOLETO_PREFIX);
        verifier = new ReclaimZkTlsVerifier(governor, DELAY, set, 2, templates, prefixes);
        // The boleto receipt endpoints attest boletos and nothing else; the PIX ones stay PIX-only.
        vm.startPrank(governor);
        verifier.setEndpointRails(BOLETO_TEMPLATE, BOLETO_MASK);
        verifier.setEndpointRails(BOLETO_PAID_TEMPLATE, BOLETO_MASK);
        verifier.setEndpointDirection(BANK_TEMPLATE, 1);
        verifier.setEndpointDirection(BOLETO_TEMPLATE, 1);
        verifier.setEndpointDirection(PIX_SENT_TEMPLATE, 2);
        verifier.setEndpointDirection(BOLETO_PAID_TEMPLATE, 2);
        vm.stopPrank();
        _completeSetup(address(verifier));

        pool = new PoolSink();
        registry = new LPRegistry(governor, DELAY);
        escrow = new FiatEscrow(
            address(new FixedOracle()), address(registry), address(pool), address(pool), 500, governor, DELAY, DISPUTE_TIMEOUT,
            TAKER_DISPUTE_TIMEOUT,
            MAX_VETTING_FEE_BPS
        );

        offramp = new OffRampEscrow(address(new FixedOracle()), address(registry), 500, governor, DELAY, DISPUTE_TIMEOUT);

        vm.startPrank(governor);
        registry.setEscrow(address(escrow), true);
        registry.setEscrow(address(offramp), true);
        registry.setTier(lp, LPRegistry.Tier.INSTITUTIONAL, 1_000_000_00);
        registry.completeSetup();
        escrow.setVerifier(address(verifier), true);
        escrow.completeSetup();
        offramp.setVerifier(address(verifier), true);
        offramp.completeSetup();
        vm.stopPrank();
        vm.deal(lp, 50 ether);
        vm.deal(seller, 10 ether);
    }

    function test_OnRampSettledByAZkTlsProof() public {
        vm.prank(lp);
        bytes32 offerId = escrow.postOffer{value: 10 ether}(
            address(0), 10 ether, 1_500_000, PIX, 0.01 ether, 5 ether, address(verifier), PIX_MASK
        );
        vm.prank(taker);
        bytes32 orderId =
            escrow.lockOrder(offerId, 1 ether, FiatEscrow.Delivery.SHIELDED, payout, 777);

        bytes memory proof = _proof(orderId, 1_500_000);
        escrow.releaseWithProof(orderId, proof);

        assertEq(pool.received(), 1 ether, "a TLS session with the bank moved the money");
    }

    /// The end-to-end binding property, through the escrow rather than the verifier alone.
    function test_AZkTlsProofForAnotherOrderIsRefused() public {
        vm.prank(lp);
        bytes32 offerId = escrow.postOffer{value: 10 ether}(
            address(0), 10 ether, 1_500_000, PIX, 0.01 ether, 5 ether, address(verifier), PIX_MASK
        );
        vm.prank(taker);
        bytes32 victim = escrow.lockOrder(offerId, 1 ether, FiatEscrow.Delivery.DIRECT, payout, 0);
        vm.prank(address(0xBAD));
        bytes32 attacker =
            escrow.lockOrder(offerId, 1 ether, FiatEscrow.Delivery.DIRECT, address(0xBAD), 0);

        bytes memory proof = _proof(victim, 1_500_000); // genuine, for the victim's order
        vm.expectRevert(ReclaimZkTlsVerifier.OrderMismatch.selector);
        escrow.releaseWithProof(attacker, proof);

        escrow.releaseWithProof(victim, proof);
        assertEq(payout.balance, 1 ether);
    }

    /// Under-paying is caught by the escrow even though the proof itself is valid.
    function test_AValidProofOfAnUnderpaymentStillDoesNotRelease() public {
        vm.prank(lp);
        bytes32 offerId = escrow.postOffer{value: 10 ether}(
            address(0), 10 ether, 1_500_000, PIX, 0.01 ether, 5 ether, address(verifier), PIX_MASK
        );
        vm.prank(taker);
        bytes32 orderId = escrow.lockOrder(offerId, 1 ether, FiatEscrow.Delivery.DIRECT, payout, 0);
        vm.expectRevert(FiatEscrow.Underpaid.selector);
        escrow.releaseWithProof(orderId, _proof(orderId, 1_499_999));
    }

    /**
     * The critical finding, end to end: the taker pays nothing, runs a server that answers
     * with the payment fields they want, and has real witnesses observe that session. The
     * claim is honestly signed and names this order - and must not release a wei.
     */
    function test_AGenuinelySignedSessionWithTheTakersOwnServerDoesNotRelease() public {
        vm.prank(lp);
        bytes32 offerId = escrow.postOffer{value: 10 ether}(
            address(0), 10 ether, 1_500_000, PIX, 0.01 ether, 5 ether, address(verifier), PIX_MASK
        );
        vm.prank(taker);
        bytes32 orderId = escrow.lockOrder(offerId, 1 ether, FiatEscrow.Delivery.DIRECT, payout, 0);

        Fields memory f = Fields({
            orderId: orderId,
            bankTxId: keccak256("made up"),
            payeeKeyHash: PIX,
            payerRef: keccak256("cpf"),
            amountBrlCents: 1_500_000,
            paidAt: block.timestamp,
            rail: 1
        });
        bytes32 takersTemplate = keccak256("template: taker.example /receipt");
        uint256[] memory keys = new uint256[](2);
        keys[0] = w1;
        keys[1] = w2;
        bytes memory proof = abi.encode(
            _proof(_params("https://taker.example/receipt"), _context(f, takersTemplate), keys)
        );

        vm.expectRevert(
            abi.encodeWithSelector(ReclaimZkTlsVerifier.EndpointNotAllowed.selector, takersTemplate)
        );
        escrow.releaseWithProof(orderId, proof);
        assertEq(payout.balance, 0);
    }

    /*//////////////////////////////////////////////////////////////
                           A BOLETO, BY zkTLS
    //////////////////////////////////////////////////////////////*/

    bytes32 constant ISSUED = keccak256("boletoCommitment(barcode, salt) for this order");

    function _boletoOrder() internal returns (bytes32 orderId) {
        vm.prank(lp);
        bytes32 offerId = escrow.postOffer{value: 10 ether}(
            address(0), 10 ether, 1_500_000, PIX, 0.01 ether, 5 ether, address(verifier), PIX_MASK | BOLETO_MASK
        );
        vm.prank(taker);
        orderId = escrow.lockOrderByBoleto(offerId, 1 ether, FiatEscrow.Delivery.DIRECT, payout, 0);
        vm.prank(lp);
        escrow.issueBoleto(orderId, ISSUED);
    }

    function _boletoProof(bytes32 orderId, bytes32 payee, uint8 rail, bytes32 template, string memory url)
        internal
        view
        returns (bytes memory)
    {
        Fields memory f = Fields({
            orderId: orderId,
            bankTxId: keccak256(abi.encode("boleto auth", orderId)),
            payeeKeyHash: payee,
            payerRef: keccak256("cpf"),
            amountBrlCents: 1_500_000,
            paidAt: block.timestamp,
            rail: rail
        });
        uint256[] memory keys = new uint256[](2);
        keys[0] = w1;
        keys[1] = w2;
        // A received PIX page carries the order's txid (M-03, N-13).
        string memory ctx = template == BANK_TEMPLATE && rail == 1
            ? _contextWithTxid(f, template, _orderTxid(block.chainid, address(escrow), orderId, 35))
            : _context(f, template);
        return abi.encode(_proof(_params(url), ctx, keys));
    }

    function test_ABoletoOrderSettledByAZkTlsProofFromTheBoletoEndpoint() public {
        bytes32 orderId = _boletoOrder();
        escrow.releaseWithProof(
            orderId, _boletoProof(orderId, ISSUED, 2, BOLETO_TEMPLATE, "https://api.bank.example/boletos/{{e2eId}}")
        );
        assertEq(payout.balance, 1 ether);
    }

    /// The PIX receipt endpoint cannot vouch for a boleto payment, however it is filled in.
    function test_APixReceiptEndpointCannotSettleABoletoOrder() public {
        bytes32 orderId = _boletoOrder();
        bytes memory proof = _boletoProof(orderId, ISSUED, 2, BANK_TEMPLATE, BANK_URL);
        vm.expectRevert(
            abi.encodeWithSelector(ReclaimZkTlsVerifier.RailNotAllowedForEndpoint.selector, BANK_TEMPLATE, uint8(2))
        );
        escrow.releaseWithProof(orderId, proof);
        // ...and a PIX receipt from it, of the boleto's commitment, is the wrong rail.
        vm.expectRevert(FiatEscrow.RailNotAccepted.selector);
        escrow.releaseWithProof(orderId, _boletoProof(orderId, ISSUED, 1, BANK_TEMPLATE, BANK_URL));
    }

    /// A genuine boleto receipt for a different boleto settles nothing.
    function test_AZkTlsReceiptForAnotherBoletoIsRefused() public {
        bytes32 orderId = _boletoOrder();
        bytes memory proof = _boletoProof(
            orderId, keccak256("some other bill"), 2, BOLETO_TEMPLATE, "https://api.bank.example/boletos/{{e2eId}}"
        );
        vm.expectRevert(FiatEscrow.WrongPayee.selector);
        escrow.releaseWithProof(orderId, proof);
    }

    /*//////////////////////////////////////////////////////////////
                           THE OFF-RAMP, BY zkTLS
    //////////////////////////////////////////////////////////////*/

    bytes32 constant SELLER_PIX = keccak256("pixKeyCommitment(seller key, salt)");
    bytes32 constant BILL = keccak256("boletoCommitment(seller's bill, salt)");

    /// A seller's sale, claimed by the LP, which pays and proves its own bank session.
    function _claimedSale(bytes32 payee, uint16 mask) internal returns (bytes32 saleId) {
        vm.prank(seller);
        saleId = offramp.openSale{value: 1 ether}(address(0), 1 ether, 1_500_000, payee, address(verifier), mask, seller);
        vm.prank(lp);
        offramp.claimSale(saleId);
    }

    function test_ASaleSettledByAZkTlsProofOfTheLpsPixPayout() public {
        bytes32 saleId = _claimedSale(SELLER_PIX, PIX_MASK);
        uint256 before = lp.balance;
        offramp.settleWithProof(saleId, _boletoProof(saleId, SELLER_PIX, 1, PIX_SENT_TEMPLATE, BANK_URL));
        assertEq(lp.balance - before, 1 ether, "the LP proved it paid the seller, and took the ETH");
    }

    /// N-08: each page settles the escrow its money moves for, and no other. The LP's payout page cannot
    /// prove an on-ramp credit, and a received-credit page cannot prove an off-ramp payout.
    function test_N08_APageSettlesOnlyTheEscrowItsMoneyMovesFor() public {
        vm.prank(lp);
        bytes32 offerId = escrow.postOffer{value: 10 ether}(
            address(0), 10 ether, 1_500_000, PIX, 0.01 ether, 5 ether, address(verifier), PIX_MASK
        );
        vm.prank(taker);
        bytes32 orderId = escrow.lockOrder(offerId, 1 ether, FiatEscrow.Delivery.DIRECT, payout, 0);
        vm.expectRevert(abi.encodeWithSelector(ReclaimZkTlsVerifier.EndpointNotForConsumer.selector, PIX_SENT_TEMPLATE, uint8(2)));
        escrow.releaseWithProof(orderId, _boletoProof(orderId, PIX, 1, PIX_SENT_TEMPLATE, BANK_URL));

        bytes32 saleId = _claimedSale(SELLER_PIX, PIX_MASK);
        vm.expectRevert(abi.encodeWithSelector(ReclaimZkTlsVerifier.EndpointNotForConsumer.selector, BANK_TEMPLATE, uint8(1)));
        offramp.settleWithProof(saleId, _boletoProof(saleId, SELLER_PIX, 1, BANK_TEMPLATE, BANK_URL));
    }

    /// L-12, and N-08's path traversal: a substituted value carrying a path is refused.
    function test_L12_AReceiptIdCarryingAPathIsRefused() public {
        bytes32 saleId = _claimedSale(SELLER_PIX, PIX_MASK);
        Fields memory f = Fields({
            orderId: saleId,
            bankTxId: keccak256("e2e"),
            payeeKeyHash: SELLER_PIX,
            payerRef: keccak256("cpf"),
            amountBrlCents: 1_500_000,
            paidAt: block.timestamp,
            rail: 1
        });
        uint256[] memory keys = new uint256[](2);
        keys[0] = w1;
        keys[1] = w2;
        string memory params = string(
            abi.encodePacked(
                '{"body":"","method":"GET","paramValues":{"receiptId":"../received/E0000000020260913"},',
                '"responseMatches":[],"responseRedactions":[],"url":"', BANK_URL, '"}'
            )
        );
        bytes memory proof = abi.encode(_proof(params, _context(f, PIX_SENT_TEMPLATE), keys));
        vm.expectRevert(ReclaimZkTlsVerifier.BadParamValue.selector);
        offramp.settleWithProof(saleId, proof);
    }

    function test_ABillPaidForASellerSettlesByAZkTlsProofFromTheBoletoEndpoint() public {
        bytes32 saleId = _claimedSale(BILL, BOLETO_MASK);
        // A PIX receipt, even of the bill's commitment, is not the bill paid.
        vm.expectRevert(
            abi.encodeWithSelector(ReclaimZkTlsVerifier.RailNotAllowedForEndpoint.selector, PIX_SENT_TEMPLATE, uint8(2))
        );
        offramp.settleWithProof(saleId, _boletoProof(saleId, BILL, 2, PIX_SENT_TEMPLATE, BANK_URL));
        offramp.settleWithProof(
            saleId, _boletoProof(saleId, BILL, 2, BOLETO_PAID_TEMPLATE, "https://api.bank.example/boletos/{{e2eId}}")
        );
        assertEq(lp.balance, 50 ether + 1 ether);
    }

    /// A genuine proof of the LP paying one seller cannot settle another seller's sale.
    function test_AnOffRampProofIsBoundToItsSale() public {
        bytes32 first = _claimedSale(SELLER_PIX, PIX_MASK);
        bytes32 second = _claimedSale(SELLER_PIX, PIX_MASK);
        bytes memory proof = _boletoProof(first, SELLER_PIX, 1, PIX_SENT_TEMPLATE, BANK_URL);
        vm.expectRevert(ReclaimZkTlsVerifier.OrderMismatch.selector);
        offramp.settleWithProof(second, proof);
        offramp.settleWithProof(first, proof);
    }

    /*//////////////////////////////////////////////////////////////
          M-03: AN LP PROVING A TAKER'S CREDIT FOR ITS OWN ORDER
    //////////////////////////////////////////////////////////////*/

    address sybil = makeAddr("the LP's sybil taker");
    address sybilPayout = makeAddr("the LP's sybil payout");

    /// An honest taker's order and the LP's sybil order on the same offer, for the same amount.
    function _victimAndSybil() internal returns (bytes32 victim, bytes32 sybilOrder) {
        vm.prank(lp);
        bytes32 offerId = escrow.postOffer{value: 10 ether}(
            address(0), 10 ether, 1_500_000, PIX, 0.01 ether, 5 ether, address(verifier), PIX_MASK
        );
        vm.prank(taker);
        victim = escrow.lockOrder(offerId, 1 ether, FiatEscrow.Delivery.DIRECT, payout, 0);
        vm.prank(sybil);
        sybilOrder = escrow.lockOrder(offerId, 1 ether, FiatEscrow.Delivery.DIRECT, sybilPayout, 0);
    }

    /// The taker's one PIX, as the LP's `pix-received` page shows it: the bank's end-to-end id and,
    /// when `txid` is not empty, the txid the BR Code the taker paid carried. `bindTo` is the
    /// prover's `contextMessage` - the LP's to choose.
    function _takersCredit(bytes32 bindTo, string memory txid) internal view returns (bytes memory) {
        Fields memory f = Fields({
            orderId: bindTo,
            bankTxId: keccak256("E2E of the taker's one PIX"),
            payeeKeyHash: PIX,
            payerRef: keccak256("taker's cpf"),
            amountBrlCents: 1_500_000,
            paidAt: block.timestamp,
            rail: 1
        });
        uint256[] memory keys = new uint256[](2);
        keys[0] = w1;
        keys[1] = w2;
        string memory ctx = bytes(txid).length == 0 ? _context(f, BANK_TEMPLATE) : _contextWithTxid(f, BANK_TEMPLATE, txid);
        return abi.encode(_proof(_params(BANK_URL), ctx, keys));
    }

    /// The order's txid as the taker's wallet checks it and the LP node writes it into the BR Code.
    function _txidOf(bytes32 orderId) internal view returns (string memory) {
        return _orderTxid(block.chainid, address(escrow), orderId, 25);
    }

    /// The finding as reported needed an unflagged received-credit page. Since N-13 there is none: a
    /// RECEIVED page requires the txid with no flag at all, so the attack fails on it as on a flagged one,
    /// and an unclassified page settles nothing for the on-ramp.
    function test_M03_N13_AReceivedPageIsTxidBoundWithoutAFlag() public {
        assertFalse(verifier.endpointRequiresOrderTxid(PIX_SENT_TEMPLATE));
        assertTrue(verifier.endpointRequiresOrderTxid(BANK_TEMPLATE), "the page type, not a flag");
        (bytes32 victim, bytes32 sybilOrder) = _victimAndSybil();
        vm.expectRevert(ReclaimZkTlsVerifier.OrderTxidMismatch.selector);
        escrow.releaseWithProof(sybilOrder, _takersCredit(sybilOrder, _txidOf(victim)));
        escrow.releaseWithProof(victim, _takersCredit(victim, _txidOf(victim)));
        assertEq(payout.balance, 1 ether);
    }

    /// The fix, through FiatEscrow's own (unchanged) code: with the endpoint flagged, the bank-written
    /// txid names the victim's order, so the LP's proof for its sybil order reverts whatever it binds,
    /// and the bank transaction stays unspent for the taker's order.
    function test_M03_AFlaggedEndpointStopsTheSybilAttack() public {
        vm.prank(governor);
        verifier.setEndpointOrderTxid(BANK_TEMPLATE, true); // instant, after setup: it narrows
        (bytes32 victim, bytes32 sybilOrder) = _victimAndSybil();

        // Bound to the sybil order, carrying the txid the bank recorded: the victim's.
        vm.expectRevert(ReclaimZkTlsVerifier.OrderTxidMismatch.selector);
        escrow.releaseWithProof(sybilOrder, _takersCredit(sybilOrder, _txidOf(victim)));
        // A template that drops the txid cannot be used to dodge it.
        vm.expectRevert(abi.encodeWithSelector(ReclaimZkTlsVerifier.MissingField.selector, "txid"));
        escrow.releaseWithProof(sybilOrder, _takersCredit(sybilOrder, ""));
        // Nor can a proof re-pointed at the victim's order be spent on the sybil's: the binding stands.
        vm.expectRevert(ReclaimZkTlsVerifier.OrderMismatch.selector);
        escrow.releaseWithProof(sybilOrder, _takersCredit(victim, _txidOf(victim)));
        assertEq(sybilPayout.balance, 0, "the sybil order took nothing");

        // The credit settles the order it was paid for - and only once.
        escrow.releaseWithProof(victim, _takersCredit(victim, _txidOf(victim)));
        assertEq(payout.balance, 1 ether, "the taker's own order released");
        vm.expectRevert(FiatEscrow.WrongState.selector);
        escrow.releaseWithProof(victim, _takersCredit(victim, _txidOf(victim)));

        // The sybil order settles only by a payment made for it, under its own txid.
        Fields memory f = Fields({
            orderId: sybilOrder,
            bankTxId: keccak256("E2E of the LP's own PIX for its own order"),
            payeeKeyHash: PIX,
            payerRef: keccak256("lp's cpf"),
            amountBrlCents: 1_500_000,
            paidAt: block.timestamp,
            rail: 1
        });
        uint256[] memory keys = new uint256[](2);
        keys[0] = w1;
        keys[1] = w2;
        escrow.releaseWithProof(
            sybilOrder, abi.encode(_proof(_params(BANK_URL), _contextWithTxid(f, BANK_TEMPLATE, _txidOf(sybilOrder)), keys))
        );
        assertEq(sybilPayout.balance, 1 ether);
    }

    /// The txid the cob form of the LP node issues (35 characters) binds the same order.
    function test_M03_ACobTxidSettlesItsOrderThroughTheEscrow() public {
        vm.prank(governor);
        verifier.setEndpointOrderTxid(BANK_TEMPLATE, true);
        (bytes32 victim,) = _victimAndSybil();
        escrow.releaseWithProof(victim, _takersCredit(victim, _orderTxid(block.chainid, address(escrow), victim, 35)));
        assertEq(payout.balance, 1 ether);
    }

    /*//////////////////////////////////////////////////////////////
                             PROOF BUILDING
    //////////////////////////////////////////////////////////////*/

    /// A proof as the Reclaim network emits it: see utils/ReclaimProofBuilder.sol.
    function _proof(bytes32 orderId, uint256 cents) internal view returns (bytes memory) {
        Fields memory f = Fields({
            orderId: orderId,
            bankTxId: keccak256(abi.encode(orderId, cents)),
            payeeKeyHash: PIX,
            payerRef: keccak256("cpf"),
            amountBrlCents: cents,
            paidAt: block.timestamp,
            rail: 1
        });
        uint256[] memory keys = new uint256[](2);
        keys[0] = w1;
        keys[1] = w2;
        // A received PIX page: the charge's txid binds the credit to the order (M-03, N-13).
        return abi.encode(
            _proof(_params(BANK_URL), _contextWithTxid(f, BANK_TEMPLATE, _orderTxid(block.chainid, address(escrow), orderId, 35)), keys)
        );
    }
}
