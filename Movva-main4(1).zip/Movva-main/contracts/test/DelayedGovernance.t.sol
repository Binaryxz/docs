// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test, Vm} from "forge-std/Test.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";

/// The smallest contract with one risk-increasing and one risk-reducing knob.
contract Knob is DelayedGovernance {
    uint256 public limit = 100;
    uint256 public business;

    error TooHigh();

    constructor(address gov, uint256 delay) DelayedGovernance(gov, delay) {}

    /// Raising is risk-increasing; lowering is not.
    function setLimit(uint256 v) external {
        _authorizeChange(v > limit);
        if (v > 1_000_000) revert TooHigh();
        limit = v;
    }

    /// Not a governance function, and not delayable: the self-call must never reach it.
    function doBusiness() external {
        _requireSetupComplete();
        ++business;
    }

    function _isDelayable(bytes4 selector) internal pure override returns (bool) {
        return selector == Knob.setLimit.selector;
    }
}

/// Tries to reach a setter while pretending to be mid-execution.
contract Impostor {
    function poke(Knob k) external {
        k.setLimit(999);
    }
}

contract DelayedGovernanceTest is Test {
    Knob knob;
    address gov = makeAddr("gov");
    uint256 constant DELAY = 48 hours;

    function setUp() public {
        knob = new Knob(gov, DELAY);
    }

    /// @dev `scheduleId` as the contract computes it, without a call that would use up a `vm.prank`.
    function _id(bytes memory c) internal pure returns (bytes32) {
        return _idAt(0, c);
    }

    function _idAt(uint64 epoch, bytes memory c) internal pure returns (bytes32) {
        return keccak256(abi.encode(epoch, c));
    }

    function _live() internal {
        vm.prank(gov);
        knob.completeSetup();
    }

    function _raise() internal pure returns (bytes memory) {
        return abi.encodeCall(Knob.setLimit, (500));
    }

    /*//////////////////////////////////////////////////////////////
                                  SETUP
    //////////////////////////////////////////////////////////////*/

    /// A deploy script must be able to wire a contract without waiting between transactions.
    function test_DuringSetupEveryChangeIsInstant() public {
        vm.prank(gov);
        knob.setLimit(500);
        assertEq(knob.limit(), 500);
    }

    /// ...which is only safe because nobody can use the contract until setup is over.
    function test_NoBusinessIsAcceptedDuringSetup() public {
        vm.expectRevert(DelayedGovernance.SetupIncomplete.selector);
        knob.doBusiness();
        _live();
        knob.doBusiness();
        assertEq(knob.business(), 1);
    }

    function test_SetupCannotBeReopenedOrClosedByAnyoneElse() public {
        vm.expectRevert(DelayedGovernance.NotGovernor.selector);
        knob.completeSetup();
        _live();
        vm.prank(gov);
        vm.expectRevert(DelayedGovernance.SetupAlreadyComplete.selector);
        knob.completeSetup();
    }

    function test_TheDelayIsBoundedAtDeployment() public {
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.BadGovernanceDelay.selector, 1 hours));
        new Knob(gov, 1 hours);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.BadGovernanceDelay.selector, 31 days));
        new Knob(gov, 31 days);
        vm.expectRevert(DelayedGovernance.ZeroAddress.selector);
        new Knob(address(0), DELAY);
        assertEq(knob.GOVERNANCE_DELAY(), DELAY);
    }

    /// M-06: nothing is scheduled while setup is open. A change scheduled then would start its delay
    /// before anyone watched the contract, and could execute the moment setup closed.
    function test_NothingCanBeScheduledDuringSetup() public {
        vm.prank(gov);
        vm.expectRevert(DelayedGovernance.SetupIncomplete.selector);
        knob.schedule(_raise());
        _live();
        vm.prank(gov);
        knob.schedule(_raise());
        assertEq(knob.pendingChanges(), 1);
    }

    /// The schedule-in-setup attack, end to end, is gone: the delay always runs from after setup.
    function test_ADelayCannotBeWaitedOutBeforeSetupCloses() public {
        vm.warp(block.timestamp + 30 days); // a long setup
        _live();
        vm.prank(gov);
        knob.schedule(_raise());
        vm.prank(gov);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.NotReadyYet.selector, _id(_raise()), block.timestamp + DELAY));
        knob.execute(_raise());
    }

    /// `pendingChanges` counts what is queued: up on schedule, down on execute and on cancel - and an
    /// expired change still counts until the governor cancels it.
    function test_PendingChangesCountsWhatIsQueued() public {
        _live();
        bytes memory a = abi.encodeCall(Knob.setLimit, (500));
        bytes memory b = abi.encodeCall(Knob.setLimit, (600));
        bytes memory c = abi.encodeCall(Knob.setLimit, (700));
        assertEq(knob.pendingChanges(), 0, "a fresh deployment queues nothing");
        vm.startPrank(gov);
        knob.schedule(a);
        knob.schedule(b);
        knob.schedule(c);
        assertEq(knob.pendingChanges(), 3);
        knob.cancel(b);
        assertEq(knob.pendingChanges(), 2);
        vm.warp(block.timestamp + DELAY);
        knob.execute(a);
        assertEq(knob.pendingChanges(), 1);
        vm.warp(block.timestamp + 14 days + 1);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.ChangeExpired.selector, _id(c)));
        knob.execute(c);
        assertEq(knob.pendingChanges(), 1, "lapsed, but still queued until cancelled");
        knob.cancel(c);
        assertEq(knob.pendingChanges(), 0);
        // A failed execution changes nothing, the count included.
        bytes memory tooHigh = abi.encodeCall(Knob.setLimit, (2_000_000));
        knob.schedule(tooHigh);
        vm.warp(block.timestamp + DELAY);
        vm.expectRevert(Knob.TooHigh.selector);
        knob.execute(tooHigh);
        assertEq(knob.pendingChanges(), 1);
        vm.stopPrank();
    }

    /// The counter and the epoch share `_executing`'s slot; the pending governor has the next one (I-36, I-53).
    function test_PendingChangesAndTheEpochShareASlot() public {
        _live();
        vm.prank(gov);
        knob.schedule(_raise());
        // Knob's own first variable, `limit`, comes after DelayedGovernance's five slots.
        assertEq(uint256(vm.load(address(knob), bytes32(uint256(4)))), knob.limit());
        assertEq((uint256(vm.load(address(knob), bytes32(uint256(2)))) >> 8) & type(uint64).max, 1, "pendingChanges, beside _executing");
    }

    /*//////////////////////////////////////////////////////////////
                        AFTER SETUP: TWO SPEEDS
    //////////////////////////////////////////////////////////////*/

    function test_ARiskIncreasingChangeCannotBeMadeDirectly() public {
        _live();
        vm.prank(gov);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, Knob.setLimit.selector)
        );
        knob.setLimit(500);
    }

    /// Incident response is not slowed down.
    function test_ARiskReducingChangeIsStillInstant() public {
        _live();
        vm.prank(gov);
        knob.setLimit(10);
        assertEq(knob.limit(), 10);
    }

    function test_OnlyTheGovernorChangesAnything() public {
        _live();
        vm.expectRevert(DelayedGovernance.NotGovernor.selector);
        knob.setLimit(10);
        vm.expectRevert(DelayedGovernance.NotGovernor.selector);
        knob.schedule(_raise());
    }

    function test_AScheduledChangeRunsOnlyAfterTheDelayAndIsAnnounced() public {
        _live();
        bytes memory call = _raise();
        bytes32 id = _id(call);

        vm.recordLogs();
        vm.prank(gov);
        knob.schedule(call);
        Vm.Log[] memory logs = vm.getRecordedLogs();
        assertEq(logs[0].topics[0], DelayedGovernance.ChangeScheduled.selector);
        (bytes memory announced, uint256 readyAt, uint256 expiresAt) =
            abi.decode(logs[0].data, (bytes, uint256, uint256));
        assertEq(announced, call, "the exact calldata is public from the moment it is scheduled");
        assertEq(readyAt, block.timestamp + DELAY);
        assertEq(expiresAt, readyAt + knob.EXECUTION_WINDOW());

        vm.warp(block.timestamp + DELAY - 1);
        vm.prank(gov);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.NotReadyYet.selector, id, readyAt));
        knob.execute(call);

        vm.warp(block.timestamp + 1);
        vm.prank(gov);
        knob.execute(call);
        assertEq(knob.limit(), 500);
        assertEq(knob.readyAt(id), 0, "consumed: it cannot be executed twice");

        vm.prank(gov);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.NotScheduled.selector, id));
        knob.execute(call);
    }

    /// A stale approval is not a loaded gun for later.
    function test_AnUnexecutedChangeExpires() public {
        _live();
        bytes memory call = _raise();
        vm.prank(gov);
        knob.schedule(call);
        vm.warp(block.timestamp + DELAY + knob.EXECUTION_WINDOW() + 1);
        vm.prank(gov);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.ChangeExpired.selector, _id(call)));
        knob.execute(call);
    }

    function test_CancellingIsInstant() public {
        _live();
        bytes memory call = _raise();
        vm.startPrank(gov);
        knob.schedule(call);
        knob.cancel(call);
        vm.warp(block.timestamp + DELAY);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.NotScheduled.selector, _id(call)));
        knob.execute(call);
        vm.stopPrank();
    }

    function test_TheSameChangeCannotBeScheduledTwice() public {
        _live();
        vm.startPrank(gov);
        knob.schedule(_raise());
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.AlreadyScheduled.selector, _id(_raise())));
        knob.schedule(_raise());
        vm.stopPrank();
    }

    /// The self-call must not become a way to run arbitrary functions as the contract.
    function test_OnlyDeclaredGovernanceFunctionsCanBeScheduled() public {
        _live();
        vm.startPrank(gov);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.NotDelayable.selector, Knob.doBusiness.selector));
        knob.schedule(abi.encodeCall(Knob.doBusiness, ()));
        bytes memory transfer = abi.encodeCall(DelayedGovernance.transferGovernor, (address(1)));
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.NotDelayable.selector, DelayedGovernance.transferGovernor.selector)
        );
        knob.schedule(transfer);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.NotDelayable.selector, bytes4(0)));
        knob.schedule(hex"01");
        vm.stopPrank();
    }

    /// A setter's own validation still applies when it finally runs, and says why it failed.
    function test_AFailedExecutionBubblesTheSettersError() public {
        _live();
        bytes memory call = abi.encodeCall(Knob.setLimit, (2_000_000));
        vm.prank(gov);
        knob.schedule(call);
        vm.warp(block.timestamp + DELAY);
        vm.prank(gov);
        vm.expectRevert(Knob.TooHigh.selector);
        knob.execute(call);
    }

    /// Only execute's own self-call skips the delay; another contract calling in does not.
    function test_NoOtherCallerInheritsTheExecutionBypass() public {
        _live();
        Impostor imp = new Impostor();
        vm.expectRevert(DelayedGovernance.NotGovernor.selector);
        imp.poke(knob);
    }

    /// Rotating a compromised key needs no delay, but takes two steps: the proposed governor must accept, and it faces
    /// the same delays (I-36).
    function test_HandingOverTakesTheNewGovernorsAcceptanceButNoDelay() public {
        _live();
        address next = makeAddr("next");
        vm.prank(gov);
        knob.transferGovernor(next);
        assertEq(knob.governor(), gov, "only proposed");
        assertEq(knob.pendingGovernor(), next);
        vm.expectRevert(DelayedGovernance.NotPendingGovernor.selector);
        knob.acceptGovernor();
        vm.prank(next);
        knob.acceptGovernor();
        assertEq(knob.governor(), next);
        assertEq(knob.pendingGovernor(), address(0));
        vm.prank(next);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, Knob.setLimit.selector)
        );
        knob.setLimit(500);
        vm.prank(gov);
        vm.expectRevert(DelayedGovernance.NotGovernor.selector);
        knob.schedule(_raise());
    }

    /// What the previous governor queued dies with the handover (I-53): it can neither run nor needs cancelling.
    function test_AHandoverVoidsEveryQueuedChange() public {
        _live();
        bytes memory call = _raise();
        vm.prank(gov);
        knob.schedule(call);
        assertEq(knob.pendingChanges(), 1);
        address next = makeAddr("next");
        vm.prank(gov);
        knob.transferGovernor(next);
        vm.prank(next);
        knob.acceptGovernor();
        assertEq(knob.pendingChanges(), 0);
        assertEq(knob.governanceEpoch(), 1);
        vm.warp(block.timestamp + DELAY);
        vm.prank(next);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.NotScheduled.selector, _idAt(1, call)));
        knob.execute(call);
    }

    /// Renouncing is one step, to 0x...dEaD, and also voids the queue.
    function test_RenouncingBurnsGovernanceAndTheQueue() public {
        _live();
        vm.prank(gov);
        knob.schedule(_raise());
        vm.prank(gov);
        knob.renounceGovernor();
        assertEq(knob.governor(), address(0xdEaD));
        assertEq(knob.pendingChanges(), 0);
    }

    /// Classification happens when the change runs, against the state at that moment.
    function test_ClassificationIsEvaluatedAtExecution() public {
        _live();
        bytes memory call = _raise(); // 500
        vm.prank(gov);
        knob.schedule(call);
        vm.warp(block.timestamp + DELAY);
        vm.prank(gov);
        knob.execute(call);
        // A later instant lowering is still instant, from the new state.
        vm.prank(gov);
        knob.setLimit(400);
        assertEq(knob.limit(), 400);
    }
}
