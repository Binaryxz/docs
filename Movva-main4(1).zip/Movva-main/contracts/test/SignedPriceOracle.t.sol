// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Vm} from "forge-std/Test.sol";
import {Governed} from "./utils/Governed.sol";
import {MockVerifier} from "./FiatEscrow.t.sol";
import {SignedPriceOracle} from "../ramp/SignedPriceOracle.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";
import {FiatEscrow} from "../ramp/FiatEscrow.sol";
import {LPRegistry} from "../ramp/LPRegistry.sol";
import {IAttestorVerifier} from "../ramp/IAttestorVerifier.sol";

contract SignedPriceOracleTest is Governed {
    SignedPriceOracle oracle;

    uint256 p1 = 0xA1;
    uint256 p2 = 0xB2;
    uint256 p3 = 0xC3;
    uint256 rogue = 0xBAD;
    address governor = address(0x60F);
    address stranger = makeAddr("stranger");

    function setUp() public {
        vm.warp(1_700_000_000);
        oracle = _deploy();
        _completeSetup(address(oracle));
    }

    /// Three publishers, two to sign, setup still open.
    function _deploy() internal returns (SignedPriceOracle) {
        address[] memory set = new address[](3);
        set[0] = vm.addr(p1);
        set[1] = vm.addr(p2);
        set[2] = vm.addr(p3);
        return new SignedPriceOracle(governor, DELAY, set, 2);
    }

    function _sigs(uint256[] memory keys, uint256 price, uint64 at, uint64 seq)
        internal
        view
        returns (bytes[] memory)
    {
        return _sigsFor(oracle, keys, price, at, seq);
    }

    function _sigsFor(SignedPriceOracle o, uint256[] memory keys, uint256 price, uint64 at, uint64 seq)
        internal
        view
        returns (bytes[] memory out)
    {
        bytes32 d = o.digest(price, at, seq);
        uint256[] memory k = keys;
        for (uint256 i; i < k.length; ++i) {
            for (uint256 j = i + 1; j < k.length; ++j) {
                if (vm.addr(k[j]) < vm.addr(k[i])) (k[i], k[j]) = (k[j], k[i]);
            }
        }
        out = new bytes[](k.length);
        for (uint256 i; i < k.length; ++i) {
            (uint8 v, bytes32 r, bytes32 s) = vm.sign(k[i], d);
            out[i] = abi.encodePacked(r, s, v);
        }
    }

    function _two() internal view returns (uint256[] memory k) {
        k = new uint256[](2);
        k[0] = p1;
        k[1] = p2;
    }

    function _keys(uint256 a) internal pure returns (uint256[] memory k) {
        k = new uint256[](1);
        k[0] = a;
    }

    function _keys(uint256 a, uint256 b) internal pure returns (uint256[] memory k) {
        k = new uint256[](2);
        (k[0], k[1]) = (a, b);
    }

    function _submit(uint256 price, uint64 seq) internal {
        oracle.submit(price, uint64(block.timestamp), seq, _sigs(_two(), price, uint64(block.timestamp), seq));
    }

    /// Submit `price` signed by `keys`, expecting the exact revert `err` (empty: expect success).
    function _submitBy(uint256[] memory keys, uint256 price, uint64 seq, bytes memory err) internal {
        bytes[] memory sigs = _sigs(keys, price, uint64(block.timestamp), seq);
        if (err.length != 0) vm.expectRevert(err);
        oracle.submit(price, uint64(block.timestamp), seq, sigs);
    }

    /// A risk-increasing change: refused when sent directly, then applied through the delay.
    function _mustSchedule(bytes memory call) internal {
        vm.prank(governor);
        (bool ok, bytes memory ret) = address(oracle).call(call);
        assertFalse(ok, "a risk-increasing change went through without the delay");
        assertEq(ret, abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, bytes4(call)));
        _afterDelay(address(oracle), call);
    }

    /// A risk-reducing change: refused to a stranger, applied at once for the governor.
    function _instant(bytes memory call) internal {
        vm.prank(stranger);
        (bool ok, bytes memory ret) = address(oracle).call(call);
        assertFalse(ok, "a stranger changed governance");
        assertEq(ret, abi.encodeWithSelector(DelayedGovernance.NotGovernor.selector));
        vm.prank(governor);
        (ok, ret) = address(oracle).call(call);
        assertTrue(ok, "an instant change was refused");
    }

    /*//////////////////////////////////////////////////////////////
                                 BASICS
    //////////////////////////////////////////////////////////////*/

    /// Before anything is published there is no price - not zero, which would band-accept all.
    function test_RevertsBeforeAnyPriceExists() public {
        vm.expectRevert(SignedPriceOracle.NoPriceYet.selector);
        oracle.brlCentsPerUnit();
    }

    function test_AQuorumPublishesAPrice() public {
        _submit(1_244_910, 1);
        (uint256 p, uint64 at) = oracle.brlCentsPerUnit();
        assertEq(p, 1_244_910);
        assertEq(at, uint64(block.timestamp));
    }

    /// Anyone may push a signed price: the signatures authorise it, not the sender.
    function test_AnyoneMaySubmitAQuorumSignedPrice() public {
        bytes[] memory sigs = _sigs(_two(), 1_000_000, uint64(block.timestamp), 1);
        vm.prank(address(0xFEE)); // a relayer, not a publisher
        oracle.submit(1_000_000, uint64(block.timestamp), 1, sigs);
        (uint256 p,) = oracle.brlCentsPerUnit();
        assertEq(p, 1_000_000);
    }

    /*//////////////////////////////////////////////////////////////
                                ATTACKS
    //////////////////////////////////////////////////////////////*/

    function test_OneSignatureIsNotAQuorum() public {
        uint256[] memory one = new uint256[](1);
        one[0] = p1;
        bytes[] memory sigs = _sigs(one, 1_000_000, uint64(block.timestamp), 1);
        vm.expectRevert(
            abi.encodeWithSelector(SignedPriceOracle.NotEnoughSignatures.selector, 1, 2)
        );
        oracle.submit(1_000_000, uint64(block.timestamp), 1, sigs);
    }

    function test_TheSamePublisherTwiceIsNotAQuorum() public {
        uint256[] memory dup = new uint256[](2);
        dup[0] = p1;
        dup[1] = p1;
        bytes[] memory sigs = _sigs(dup, 1_000_000, uint64(block.timestamp), 1);
        vm.expectRevert(SignedPriceOracle.SignaturesUnsorted.selector);
        oracle.submit(1_000_000, uint64(block.timestamp), 1, sigs);
    }

    function test_AnOutsiderSignatureIsRejected() public {
        uint256[] memory k = new uint256[](2);
        k[0] = p1;
        k[1] = rogue;
        bytes[] memory sigs = _sigs(k, 1_000_000, uint64(block.timestamp), 1);
        vm.expectRevert(
            abi.encodeWithSelector(SignedPriceOracle.UnknownPublisher.selector, vm.addr(rogue))
        );
        oracle.submit(1_000_000, uint64(block.timestamp), 1, sigs);
    }

    /// A signed price is a bearer instrument until the sequence retires it.
    function test_AnOldSignedPriceCannotBeReplayedOverANewerOne() public {
        bytes[] memory old = _sigs(_two(), 500_000, uint64(block.timestamp), 1);
        _submit(1_244_910, 2);
        vm.expectRevert(abi.encodeWithSelector(SignedPriceOracle.StaleSequence.selector, 1, 2));
        oracle.submit(500_000, uint64(block.timestamp), 1, old);
    }

    function test_TheSameSequenceCannotBeReused() public {
        _submit(1_000_000, 5);
        bytes[] memory sigs = _sigs(_two(), 999_999, uint64(block.timestamp), 5);
        vm.expectRevert(abi.encodeWithSelector(SignedPriceOracle.StaleSequence.selector, 5, 5));
        oracle.submit(999_999, uint64(block.timestamp), 5, sigs);
    }

    /// One quorum signature over the largest sequence used to freeze the oracle for good: every
    /// later price was stale, and recovery meant a new oracle and a delayed repoint of every consumer.
    function test_ASequenceCannotRunAheadOfItsTimestamp() public {
        uint64 at = uint64(block.timestamp);
        bytes[] memory sigs = _sigs(_two(), 1_000_000, at, type(uint64).max);
        vm.expectRevert(
            abi.encodeWithSelector(SignedPriceOracle.SequenceAheadOfTimestamp.selector, type(uint64).max, at)
        );
        oracle.submit(1_000_000, at, type(uint64).max, sigs);
    }

    /// The furthest a quorum can push the sequence is the clock skew, and publishers deriving the
    /// sequence from the clock (sequenceFromTime) carry on as soon as the chain passes it.
    function test_TheFurthestASequenceCanJumpIsTheClockSkew() public {
        uint64 ahead = uint64(block.timestamp + oracle.MAX_FUTURE_SKEW());
        oracle.submit(1_000_000, ahead, ahead, _sigs(_two(), 1_000_000, ahead, ahead));

        uint64 now_ = uint64(block.timestamp);
        bytes[] memory early = _sigs(_two(), 1_010_000, now_, now_);
        vm.expectRevert(abi.encodeWithSelector(SignedPriceOracle.StaleSequence.selector, now_, ahead));
        oracle.submit(1_010_000, now_, now_, early);

        vm.warp(ahead + 1);
        uint64 later = uint64(block.timestamp);
        oracle.submit(1_010_000, later, later, _sigs(_two(), 1_010_000, later, later));
        (uint256 p,) = oracle.brlCentsPerUnit();
        assertEq(p, 1_010_000);
    }

    /// A future timestamp would mint freshness outlasting the signing itself.
    function test_AFutureTimestampIsRejected() public {
        uint64 future = uint64(block.timestamp + 1 hours);
        bytes[] memory sigs = _sigs(_two(), 1_000_000, future, 1);
        vm.expectRevert(
            abi.encodeWithSelector(
                SignedPriceOracle.TimestampInFuture.selector, future, block.timestamp
            )
        );
        oracle.submit(1_000_000, future, 1, sigs);
    }

    function test_ASmallClockSkewIsTolerated() public {
        uint64 slightly = uint64(block.timestamp + 30 seconds);
        oracle.submit(1_000_000, slightly, 1, _sigs(_two(), 1_000_000, slightly, 1));
        (, uint64 at) = oracle.brlCentsPerUnit();
        assertEq(at, block.timestamp, "accepted, and its freshness runs from the chain's clock (I-47)");
    }

    function test_ZeroPriceIsRefused() public {
        bytes[] memory sigs = _sigs(_two(), 0, uint64(block.timestamp), 1);
        vm.expectRevert(SignedPriceOracle.BadPrice.selector);
        oracle.submit(0, uint64(block.timestamp), 1, sigs);
    }

    function test_ChangingAnyFieldInvalidatesTheQuorum() public {
        bytes[] memory sigs = _sigs(_two(), 1_000_000, uint64(block.timestamp), 1);
        vm.expectRevert(); // recovers different addresses, none of them publishers
        oracle.submit(2_000_000, uint64(block.timestamp), 1, sigs);
    }

    /// Freshness must not regress: the escrows judge staleness by publishedAt.
    function test_ATimestampCannotGoBackwards() public {
        uint64 t0 = uint64(block.timestamp);
        _submit(1_000_000, 1);          // publishedAt = t0
        vm.warp(block.timestamp + 1 hours);
        uint64 t1 = uint64(block.timestamp);
        _submit(1_100_000, 2);          // publishedAt = t1

        // A higher sequence carrying an older clock: the escrows judge staleness by
        // publishedAt, so accepting this would make a current price look expired.
        bytes[] memory sigs = _sigs(_two(), 999_000, t0, 3);
        vm.expectRevert(
            abi.encodeWithSelector(SignedPriceOracle.StaleTimestamp.selector, t0, t1)
        );
        oracle.submit(999_000, t0, 3, sigs);
    }

    /// Republishing at the same instant is fine - only going backwards is refused.
    function test_TheSameTimestampWithAHigherSequenceIsAccepted() public {
        _submit(1_000_000, 1);
        uint64 t = uint64(block.timestamp);
        oracle.submit(1_010_000, t, 2, _sigs(_two(), 1_010_000, t, 2));
        (uint256 p,) = oracle.brlCentsPerUnit();
        assertEq(p, 1_010_000);
    }

    /*//////////////////////////////////////////////////////////////
                                  SETUP
    //////////////////////////////////////////////////////////////*/

    /**
     * Reading the price is this contract's user business. A price can be signed and submitted
     * while setup is open, so it is ready at launch - but nobody can read it until the governor's
     * instant power is gone.
     */
    function test_NoOneCanReadAPriceUntilSetupCloses() public {
        SignedPriceOracle fresh = _deploy();
        uint64 at = uint64(block.timestamp);
        fresh.submit(540, at, 1, _sigsFor(fresh, _two(), 540, at, 1));
        assertEq(fresh.price(), 540, "submitted during setup");

        vm.expectRevert(DelayedGovernance.SetupIncomplete.selector);
        fresh.brlCentsPerUnit();

        _completeSetup(address(fresh));
        (uint256 p, uint64 got) = fresh.brlCentsPerUnit();
        assertEq(p, 540);
        assertEq(got, at);
    }

    /// Setup gates before the price does: an unpublished oracle in setup says SetupIncomplete.
    function test_SetupIsCheckedBeforeThePrice() public {
        SignedPriceOracle fresh = _deploy();
        vm.expectRevert(DelayedGovernance.SetupIncomplete.selector);
        fresh.brlCentsPerUnit();
    }

    /// A deploy script wires without waiting: every change is instant until setup closes.
    function test_DuringSetupEveryChangeIsInstant() public {
        SignedPriceOracle fresh = _deploy();
        vm.startPrank(governor);
        fresh.setPublisher(vm.addr(rogue), true);
        fresh.setThreshold(1);
        fresh.completeSetup();
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, SignedPriceOracle.setThreshold.selector)
        );
        fresh.setThreshold(0);
        vm.stopPrank();
        assertEq(fresh.publisherCount(), 4);
        assertEq(fresh.threshold(), 1);
    }

    function test_TheConstructorRefusesAnUnusableConfiguration() public {
        address[] memory set = new address[](2);
        (set[0], set[1]) = (vm.addr(p1), vm.addr(p1)); // a duplicate counts once
        SignedPriceOracle dup = new SignedPriceOracle(governor, DELAY, set, 1);
        assertEq(dup.publisherCount(), 1);
        assertEq(dup.GOVERNANCE_DELAY(), DELAY);
        assertFalse(dup.setupComplete());

        vm.expectRevert(SignedPriceOracle.BadThreshold.selector);
        new SignedPriceOracle(governor, DELAY, set, 2);
        vm.expectRevert(SignedPriceOracle.BadThreshold.selector);
        new SignedPriceOracle(governor, DELAY, set, 0);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.BadGovernanceDelay.selector, 1 hours));
        new SignedPriceOracle(governor, 1 hours, set, 1);
        vm.expectRevert(DelayedGovernance.ZeroAddress.selector);
        new SignedPriceOracle(address(0), DELAY, set, 1);
        set[1] = address(0);
        vm.expectRevert(DelayedGovernance.ZeroAddress.selector);
        new SignedPriceOracle(governor, DELAY, set, 1);
    }

    /**
     * The getter, events and errors off-chain code decodes kept their exact signatures when they
     * moved into DelayedGovernance: same topics, same selectors, same values.
     */
    function test_OffChainReadersSeeTheSameInterface() public {
        assertEq(DelayedGovernance.GovernorTransferred.selector, keccak256("GovernorTransferred(address,address)"));
        assertEq(SignedPriceOracle.PublisherSet.selector, keccak256("PublisherSet(address,bool)"));
        assertEq(SignedPriceOracle.ThresholdSet.selector, keccak256("ThresholdSet(uint256)"));
        assertEq(DelayedGovernance.NotGovernor.selector, bytes4(keccak256("NotGovernor()")));
        assertEq(DelayedGovernance.ZeroAddress.selector, bytes4(keccak256("ZeroAddress()")));
        assertEq(oracle.governor(), governor);
        assertTrue(oracle.isPublisher(vm.addr(p1)));
        assertEq(oracle.publisherCount(), 3);
        assertEq(oracle.threshold(), 2);

        address next = makeAddr("next governor");
        vm.recordLogs();
        vm.prank(governor);
        oracle.transferGovernor(next);
        vm.prank(next);
        oracle.acceptGovernor();
        Vm.Log[] memory logs = vm.getRecordedLogs();
        assertEq(logs.length, 2);
        assertEq(logs[0].topics[0], keccak256("GovernorProposed(address,address)"));
        logs[0] = logs[1];
        assertEq(logs[0].topics[0], keccak256("GovernorTransferred(address,address)"));
        assertEq(logs[0].topics[1], bytes32(uint256(uint160(governor))), "from, indexed");
        assertEq(logs[0].topics[2], bytes32(uint256(uint160(next))), "to, indexed");
        assertEq(oracle.governor(), next);
    }

    /*//////////////////////////////////////////////////////////////
                    GOVERNANCE: WHICH CHANGES WAIT
    //////////////////////////////////////////////////////////////*/

    function test_AddingAPublisherWaits() public {
        _mustSchedule(abi.encodeCall(SignedPriceOracle.setPublisher, (vm.addr(rogue), true)));
        assertTrue(oracle.isPublisher(vm.addr(rogue)));
        assertEq(oracle.publisherCount(), 4);
    }

    /// Adding a key that already signs changes nothing, so it need not wait.
    function test_ReAddingACurrentPublisherIsInstantAndChangesNothing() public {
        vm.recordLogs();
        _instant(abi.encodeCall(SignedPriceOracle.setPublisher, (vm.addr(p1), true)));
        assertEq(vm.getRecordedLogs().length, 0, "no event for a no-op");
        assertEq(oracle.publisherCount(), 3);
    }

    /// A removed key that comes back is a new signer again: it waits.
    function test_ReAddingARemovedPublisherWaits() public {
        _instant(abi.encodeCall(SignedPriceOracle.setPublisher, (vm.addr(p1), false)));
        _mustSchedule(abi.encodeCall(SignedPriceOracle.setPublisher, (vm.addr(p1), true)));
        assertEq(oracle.publisherCount(), 3);
    }

    function test_LoweringTheThresholdWaitsRaisingDoesNot() public {
        _instant(abi.encodeCall(SignedPriceOracle.setThreshold, (3)));
        assertEq(oracle.threshold(), 3);
        _instant(abi.encodeCall(SignedPriceOracle.setThreshold, (3))); // equal: not lower
        _mustSchedule(abi.encodeCall(SignedPriceOracle.setThreshold, (2)));
        assertEq(oracle.threshold(), 2);
        _mustSchedule(abi.encodeCall(SignedPriceOracle.setThreshold, (1)));
        assertEq(oracle.threshold(), 1);
    }

    /// Reachability is a rule, not a delay: above the set is refused instantly, zero even when scheduled.
    function test_AnUnreachableOrZeroThresholdIsRefusedOnBothPaths() public {
        vm.prank(governor);
        vm.expectRevert(SignedPriceOracle.BadThreshold.selector);
        oracle.setThreshold(4);

        bytes memory zero = abi.encodeCall(SignedPriceOracle.setThreshold, (0));
        vm.prank(governor);
        oracle.schedule(zero);
        vm.warp(block.timestamp + DELAY);
        vm.prank(governor);
        vm.expectRevert(SignedPriceOracle.BadThreshold.selector);
        oracle.execute(zero);
        assertEq(oracle.threshold(), 2);
    }

    /// Incident response for a leaked publisher key is as fast as the governor can sign.
    function test_RemovingAPublisherIsInstant() public {
        _instant(abi.encodeCall(SignedPriceOracle.setPublisher, (vm.addr(p1), false)));
        assertFalse(oracle.isPublisher(vm.addr(p1)));
        assertEq(oracle.publisherCount(), 2);
        assertEq(oracle.threshold(), 2, "the threshold did not move");
        _submitBy(_keys(p2, p3), 1_000_000, 1, "");
        _submitBy(_keys(p1, p2), 1_000_001, 2, abi.encodeWithSelector(SignedPriceOracle.UnknownPublisher.selector, vm.addr(p1)));
    }

    /// A price signed but not yet submitted stops counting a removed key at once.
    function test_ARemovedPublishersPendingSignatureStopsCounting() public {
        uint64 at = uint64(block.timestamp);
        bytes[] memory signedBeforeRemoval = _sigs(_two(), 999, at, 1);
        vm.prank(governor);
        oracle.setPublisher(vm.addr(p1), false);
        vm.expectRevert(abi.encodeWithSelector(SignedPriceOracle.UnknownPublisher.selector, vm.addr(p1)));
        oracle.submit(999, at, 1, signedBeforeRemoval);
    }

    /**
     * The decision about removal, pinned. It used to lower the threshold to the remaining count
     * "so the price never freezes"; now it never touches the threshold, and a set left below it
     * freezes until a lower threshold is scheduled - the same path any other threshold cut takes.
     */
    function test_RemovalNeverLowersTheThresholdAndAFrozenSetRecoversThroughTheDelay() public {
        _submit(1_000_000, 1);
        vm.startPrank(governor);
        oracle.setPublisher(vm.addr(p1), false);
        oracle.setPublisher(vm.addr(p2), false);
        vm.stopPrank();
        assertEq(oracle.publisherCount(), 1);
        assertEq(oracle.threshold(), 2, "removal is not a threshold cut");

        // Frozen: the one remaining publisher cannot sign alone.
        _submitBy(_keys(p3), 1_100_000, 2, abi.encodeWithSelector(SignedPriceOracle.NotEnoughSignatures.selector, 1, 2));
        (uint256 last,) = oracle.brlCentsPerUnit();
        assertEq(last, 1_000_000, "the last price stands; its consumers' max age retires it");
        // Raising is still refused as unreachable, and lowering must wait.
        vm.prank(governor);
        vm.expectRevert(SignedPriceOracle.BadThreshold.selector);
        oracle.setThreshold(2);
        _mustSchedule(abi.encodeCall(SignedPriceOracle.setThreshold, (1)));
        _submitBy(_keys(p3), 1_100_000, 2, "");
        (last,) = oracle.brlCentsPerUnit();
        assertEq(last, 1_100_000);
    }

    /**
     * From the attacker's side. A governor colluding with one publisher removes every other
     * publisher - instantly, as incident response must be - and is still not a quorum of one.
     * Getting there needs a threshold cut, which is public for the whole delay.
     */
    function test_AGovernorCannotRemoveItsWayToAQuorumOfOne() public {
        vm.startPrank(governor);
        oracle.setPublisher(vm.addr(p1), false);
        oracle.setPublisher(vm.addr(p2), false);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, SignedPriceOracle.setThreshold.selector)
        );
        oracle.setThreshold(1);
        vm.stopPrank();
        _submitBy(_keys(p3), 10_000, 1, abi.encodeWithSelector(SignedPriceOracle.NotEnoughSignatures.selector, 1, 2));
    }

    /// Removing every publisher is allowed - it is the brake - and leaves nothing that can sign.
    function test_RemovingTheLastPublisherFreezesRatherThanReverts() public {
        vm.startPrank(governor);
        oracle.setPublisher(vm.addr(p1), false);
        oracle.setPublisher(vm.addr(p2), false);
        oracle.setPublisher(vm.addr(p3), false);
        vm.stopPrank();
        assertEq(oracle.publisherCount(), 0);
        assertEq(oracle.threshold(), 2);
        _submitBy(_two(), 1, 1, abi.encodeWithSelector(SignedPriceOracle.UnknownPublisher.selector, vm.addr(p1) < vm.addr(p2) ? vm.addr(p1) : vm.addr(p2)));
    }

    /// Only the two setters can be queued: the self-call cannot be aimed at anything else.
    function test_OnlyThePublisherAndThresholdSettersCanBeScheduled() public {
        bytes[4] memory calls = [
            abi.encodeCall(SignedPriceOracle.submit, (1, 1, 1, new bytes[](0))),
            abi.encodeCall(DelayedGovernance.transferGovernor, (stranger)),
            abi.encodeCall(DelayedGovernance.completeSetup, ()),
            abi.encodeCall(DelayedGovernance.cancel, (bytes("")))
        ];
        for (uint256 i; i < calls.length; ++i) {
            vm.prank(governor);
            vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.NotDelayable.selector, bytes4(calls[i])));
            oracle.schedule(calls[i]);
        }
    }

    function test_AStrangerCannotChangeAnything() public {
        bytes[7] memory calls = [
            abi.encodeCall(SignedPriceOracle.setPublisher, (stranger, true)),
            abi.encodeCall(SignedPriceOracle.setPublisher, (vm.addr(p1), false)),
            abi.encodeCall(SignedPriceOracle.setThreshold, (3)),
            abi.encodeCall(SignedPriceOracle.setThreshold, (1)),
            abi.encodeCall(DelayedGovernance.transferGovernor, (stranger)),
            abi.encodeCall(DelayedGovernance.schedule, (abi.encodeCall(SignedPriceOracle.setThreshold, (1)))),
            abi.encodeCall(DelayedGovernance.completeSetup, ())
        ];
        for (uint256 i; i < calls.length; ++i) {
            vm.prank(stranger);
            (bool ok, bytes memory ret) = address(oracle).call(calls[i]);
            assertFalse(ok);
            assertEq(ret, abi.encodeWithSelector(DelayedGovernance.NotGovernor.selector));
        }
    }

    /*//////////////////////////////////////////////////////////////
                      THE SCHEDULED PATH, END TO END
    //////////////////////////////////////////////////////////////*/

    function test_AScheduledPublisherWaitsItsDelayAndThenItsWindowExpires() public {
        bytes memory add = abi.encodeCall(SignedPriceOracle.setPublisher, (vm.addr(rogue), true));
        bytes32 id = oracle.scheduleId(add);
        uint256 ready = block.timestamp + DELAY;

        vm.expectEmit(address(oracle));
        emit DelayedGovernance.ChangeScheduled(
            id, SignedPriceOracle.setPublisher.selector, add, ready, ready + oracle.EXECUTION_WINDOW()
        );
        vm.prank(governor);
        oracle.schedule(add);
        assertEq(oracle.readyAt(id), ready);

        // Scheduled is not added: the key cannot sign during the delay.
        _submitBy(_keys(p1, rogue), 1_000, 1, abi.encodeWithSelector(SignedPriceOracle.UnknownPublisher.selector, vm.addr(rogue)));

        vm.warp(ready - 1);
        vm.prank(governor);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.NotReadyYet.selector, id, ready));
        oracle.execute(add);

        vm.warp(ready);
        vm.expectEmit(address(oracle));
        emit SignedPriceOracle.PublisherSet(vm.addr(rogue), true);
        vm.prank(governor);
        oracle.execute(add);
        assertTrue(oracle.isPublisher(vm.addr(rogue)));
        assertEq(oracle.readyAt(id), 0, "consumed");
        _submitBy(_keys(p1, rogue), 1_000, 1, "");

        // A second change, left past its window, can no longer run.
        bytes memory cut = abi.encodeCall(SignedPriceOracle.setThreshold, (1));
        bytes32 cutId = oracle.scheduleId(cut);
        vm.prank(governor);
        oracle.schedule(cut);
        vm.warp(block.timestamp + DELAY + oracle.EXECUTION_WINDOW() + 1);
        vm.prank(governor);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.ChangeExpired.selector, cutId));
        oracle.execute(cut);
        assertEq(oracle.threshold(), 2);
    }

    /**
     * The scenario the delay exists for. The governor key leaks. The thief tries to make itself a
     * quorum of one - add its own publisher key, cut the threshold to one - and is refused both.
     * It schedules them instead, which publishes the exact calldata. The owners, who still hold the
     * key, rotate to a fresh governor, and the fresh governor cancels both before either can run.
     */
    function test_ACompromisedGovernorMustScheduleInPublicAndARotatedGovernorCancels() public {
        address thief = governor; // the leaked key
        address rotated = makeAddr("fresh multisig");
        bytes memory add = abi.encodeCall(SignedPriceOracle.setPublisher, (vm.addr(rogue), true));
        bytes memory cut = abi.encodeCall(SignedPriceOracle.setThreshold, (1));

        // 1. Direct changes are refused.
        vm.startPrank(thief);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, SignedPriceOracle.setPublisher.selector)
        );
        oracle.setPublisher(vm.addr(rogue), true);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, SignedPriceOracle.setThreshold.selector)
        );
        oracle.setThreshold(1);

        // 2. Scheduling them publishes exactly what would run, and when.
        vm.recordLogs();
        oracle.schedule(add);
        oracle.schedule(cut);
        vm.stopPrank();
        Vm.Log[] memory logs = vm.getRecordedLogs();
        assertEq(logs.length, 2);
        bytes[2] memory calls = [add, cut];
        for (uint256 i; i < 2; ++i) {
            assertEq(logs[i].emitter, address(oracle));
            assertEq(logs[i].topics[0], DelayedGovernance.ChangeScheduled.selector);
            assertEq(logs[i].topics[1], oracle.scheduleId(calls[i]), "id");
            assertEq(bytes4(logs[i].topics[2]), bytes4(calls[i]), "selector");
            (bytes memory published, uint256 readyAt, uint256 expiresAt) = abi.decode(logs[i].data, (bytes, uint256, uint256));
            assertEq(published, calls[i], "the full calldata is on-chain");
            assertEq(readyAt, block.timestamp + DELAY);
            assertEq(expiresAt, readyAt + oracle.EXECUTION_WINDOW());
        }

        // Meanwhile the thief's key signs nothing, alone or with a real publisher.
        _submitBy(_keys(rogue), 1, 1, abi.encodeWithSelector(SignedPriceOracle.NotEnoughSignatures.selector, 1, 2));
        _submitBy(_keys(p1, rogue), 1, 1, abi.encodeWithSelector(SignedPriceOracle.UnknownPublisher.selector, vm.addr(rogue)));
        _submit(540, 1); // honest publishers carry on

        // 3. The owners rotate. The rotated governor accepts, and the handover voids the queue (I-53).
        vm.warp(block.timestamp + DELAY / 2);
        bytes32 addId = oracle.scheduleId(add);
        vm.prank(governor);
        oracle.transferGovernor(rotated);
        vm.prank(rotated);
        oracle.acceptGovernor();
        assertGt(oracle.readyAt(addId), 0, "recorded under the old epoch");
        assertEq(oracle.pendingChanges(), 0, "but no longer pending");
        vm.prank(thief);
        vm.expectRevert(DelayedGovernance.NotGovernor.selector);
        oracle.cancel(add);
        vm.prank(rotated);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.NotScheduled.selector, keccak256(abi.encode(uint64(1), add))));
        oracle.cancel(add);

        // 4. Past the delay, neither can run for anyone.
        vm.warp(block.timestamp + DELAY);
        vm.prank(thief);
        vm.expectRevert(DelayedGovernance.NotGovernor.selector);
        oracle.execute(add);
        vm.prank(rotated);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.NotScheduled.selector, keccak256(abi.encode(uint64(1), add))));
        oracle.execute(add);
        vm.prank(rotated);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.NotScheduled.selector, keccak256(abi.encode(uint64(1), cut))));
        oracle.execute(cut);
        assertFalse(oracle.isPublisher(vm.addr(rogue)));
        assertEq(oracle.threshold(), 2);
        _submitBy(_keys(rogue), 1, 2, abi.encodeWithSelector(SignedPriceOracle.NotEnoughSignatures.selector, 1, 2));
    }

    /*//////////////////////////////////////////////////////////////
                        USED BY A REAL ESCROW
    //////////////////////////////////////////////////////////////*/

    /// A verifier that proves the bank session: the escrow opens a PIX offer through nothing else.
    address internal bankVerifier;

    function _escrowOn(SignedPriceOracle o) internal returns (FiatEscrow escrow, address lp) {
        LPRegistry registry = new LPRegistry(governor, DELAY);
        escrow = new FiatEscrow(address(o), address(registry), address(0xBEEF), address(0xBEEF), 500, governor, DELAY, DISPUTE_TIMEOUT, TAKER_DISPUTE_TIMEOUT, MAX_VETTING_FEE_BPS);
        lp = makeAddr("lp");
        vm.deal(lp, 10 ether);
        vm.startPrank(governor);
        registry.setEscrow(address(escrow), true);
        registry.setTier(lp, LPRegistry.Tier.INSTITUTIONAL, 100_000_000);
        registry.completeSetup();
        bankVerifier = address(new MockVerifier());
        escrow.setVerifier(bankVerifier, true);
        escrow.completeSetup();
        vm.stopPrank();
    }

    function _post(FiatEscrow escrow, address lp) internal {
        vm.prank(lp);
        escrow.postOffer{value: 1 ether}(
            address(0), 1 ether, 1_244_910, keccak256("pix"), 0.01 ether, 1 ether, bankVerifier,
            uint16(1 << uint8(IAttestorVerifier.Rail.PIX))
        );
    }

    /// The point of the whole contract: it makes the ramp deployable where no feed exists.
    function test_AnEscrowCanTradeOnASignedPrice() public {
        (FiatEscrow escrow, address lp) = _escrowOn(oracle);

        // No price yet: the escrow must refuse to trade rather than band around nothing.
        vm.expectRevert(SignedPriceOracle.NoPriceYet.selector);
        _post(escrow, lp);

        _submit(1_244_910, 1);
        _post(escrow, lp);
        assertEq(address(escrow).balance, 1 ether, "the offer was accepted against a signed price");
    }

    /**
     * An escrow, itself live, fails closed on an oracle still in setup - even one holding a fresh,
     * correct price - and trades once the oracle's setup closes.
     */
    function test_AnEscrowRefusesToPriceAgainstAnOracleStillInSetup() public {
        SignedPriceOracle fresh = _deploy();
        uint64 at = uint64(block.timestamp);
        fresh.submit(1_244_910, at, 1, _sigsFor(fresh, _two(), 1_244_910, at, 1));
        (FiatEscrow escrow, address lp) = _escrowOn(fresh);
        assertTrue(escrow.setupComplete(), "the refusal below is the oracle's, not the escrow's");

        vm.expectRevert(DelayedGovernance.SetupIncomplete.selector);
        _post(escrow, lp);

        _completeSetup(address(fresh));
        _post(escrow, lp);
        assertEq(address(escrow).balance, 1 ether);
    }

    /// And staleness is still enforced by the escrow, not taken on trust from the oracle.
    function test_TheEscrowStillRejectsAnOldSignedPrice() public {
        (FiatEscrow escrow, address lp) = _escrowOn(oracle);
        _submit(1_244_910, 1);
        vm.warp(block.timestamp + 2 hours); // nobody refreshed it

        vm.expectRevert(FiatEscrow.StalePrice.selector);
        _post(escrow, lp);
    }
}
