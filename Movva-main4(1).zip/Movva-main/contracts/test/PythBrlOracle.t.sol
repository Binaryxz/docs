// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Governed} from "./utils/Governed.sol";
import {PythBrlOracle} from "../ramp/PythBrlOracle.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";
import {MockPyth} from "./utils/MockPyth.sol";

contract PythBrlOracleTest is Governed {
    MockPyth pyth;
    PythBrlOracle oracle;
    address governor = address(0x60F);

    bytes32 constant ETH_USD = keccak256("ETH/USD");
    /// Pyth quotes FX.USD/BRL - BRL per one USD (~5.4), NOT USD per BRL (~0.185).
    bytes32 constant USD_BRL = keccak256("USD/BRL");

    function setUp() public {
        vm.warp(1_700_000_000);
        pyth = new MockPyth(0);
        // ETH = $3,000 ; USD/BRL = 5.00  =>  1 ETH = R$15,000 = 1,500,000 centavos
        pyth.set(ETH_USD, 3000e8, 1e8, -8, block.timestamp);
        pyth.set(USD_BRL, 5e8, 0.0001e8, -8, block.timestamp);
        oracle = new PythBrlOracle(address(pyth), ETH_USD, USD_BRL, 1 hours, 1 hours, 200, governor, DELAY);
        _completeSetup(address(oracle));
    }

    function test_CrossesTwoFeedsIntoCentavos() public view {
        (uint256 price,) = oracle.brlCentsPerUnit();
        assertEq(price, 1_500_000);
    }

    function test_HandlesDifferentExponentsBetweenFeeds() public {
        pyth.set(USD_BRL, 5e6, 1, -6, block.timestamp); // same value, coarser exponent
        (uint256 price,) = oracle.brlCentsPerUnit();
        assertEq(price, 1_500_000, "the cross is exponent-correct, not exponent-lucky");
    }

    function test_FreshnessIsThatOfTheStalestLeg() public {
        pyth.set(USD_BRL, 5e8, 1, -8, block.timestamp - 30 minutes);
        (, uint64 updatedAt) = oracle.brlCentsPerUnit();
        assertEq(updatedAt, uint64(block.timestamp - 30 minutes));
    }

    /// A stale leg must stop the cross, not be averaged over.
    function test_StaleLegRevertsRatherThanServingAPrice() public {
        pyth.set(USD_BRL, 5e8, 1, -8, block.timestamp - 2 hours);
        vm.expectRevert(MockPyth.StalePrice.selector);
        oracle.brlCentsPerUnit();
    }

    /// The reason to use Pyth at all: it tells you when nobody knows the price.
    function test_WideConfidenceIntervalIsRefused() public {
        // 5% confidence on a 2% tolerance.
        pyth.set(ETH_USD, 3000e8, 150e8, -8, block.timestamp);
        vm.expectRevert(
            abi.encodeWithSelector(PythBrlOracle.ConfidenceTooWide.selector, ETH_USD, uint64(150e8), int64(3000e8))
        );
        oracle.brlCentsPerUnit();
    }

    function test_ConfidenceInsideToleranceIsAccepted() public {
        pyth.set(ETH_USD, 3000e8, 30e8, -8, block.timestamp); // 1%
        (uint256 price,) = oracle.brlCentsPerUnit();
        assertEq(price, 1_500_000);
    }

    function test_NonPositivePriceIsRefused() public {
        pyth.set(ETH_USD, 0, 0, -8, block.timestamp);
        vm.expectRevert(abi.encodeWithSelector(PythBrlOracle.BadPrice.selector, ETH_USD, int64(0)));
        oracle.brlCentsPerUnit();
    }

    /// A corrupt exponent must not be handed to 10 ** n.
    function test_AbsurdExponentIsRefusedRatherThanBurningGas() public {
        pyth.set(ETH_USD, 3000e8, 1, 60, block.timestamp);
        vm.expectRevert(
            abi.encodeWithSelector(PythBrlOracle.ExponentOutOfRange.selector, ETH_USD, int32(60))
        );
        oracle.brlCentsPerUnit();
    }

    /**
     * The bug this pins.
     *
     * Pyth's feed is USD/BRL - BRL per dollar. The oracle used to DIVIDE by it, which is
     * correct for Chainlink's BRL/USD and wrong here by about 29x. Neither the code nor the
     * test caught it, because the mock was seeded with 0.2 - the same wrong assumption that
     * produced the formula. So this asserts the DIRECTION, not just the arithmetic: a
     * stronger real can only make ETH worth MORE in BRL, never less.
     */
    function test_AStrongerDollarMakesEthWorthMoreBrlNotLess() public {
        (uint256 atFive,) = oracle.brlCentsPerUnit();
        pyth.set(USD_BRL, 6e8, 1, -8, block.timestamp); // 1 USD now buys 6 BRL
        (uint256 atSix,) = oracle.brlCentsPerUnit();
        assertGt(atSix, atFive, "more BRL per dollar must mean more BRL per ETH");
        assertEq(atSix, 1_800_000, "3000 USD/ETH at 6 BRL/USD = R$18,000.00");
    }

    /// A plausibility band that an inverted quote cannot satisfy.
    function test_ThePriceIsPlausibleForBrl() public view {
        (uint256 price,) = oracle.brlCentsPerUnit();
        // Inverting 3000 x 5 would give R$600.00; the real answer is R$15,000.00.
        assertGt(price, 100_000, "an ETH is worth more than R$1,000");
        assertLt(price, 100_000_000, "and less than R$1,000,000");
    }

    /// Interchangeable with the Chainlink adapter: both are just IPriceOracle.
    function test_IsDropInForAnEscrow() public view {
        (uint256 p, uint64 at) = oracle.brlCentsPerUnit();
        assertGt(p, 0);
        assertGt(at, 0);
    }

    /*//////////////////////////////////////////////////////////////
                               GOVERNANCE
    //////////////////////////////////////////////////////////////*/

    function test_OnlyGovernorSetsFeeds() public {
        vm.expectRevert(DelayedGovernance.NotGovernor.selector);
        oracle.setFeeds(ETH_USD, USD_BRL, 1 hours, 1 hours, 100);
    }

    /// Nothing prices through an oracle whose governor can still swap its feeds instantly.
    function test_NothingPricesUntilSetupCloses() public {
        PythBrlOracle fresh = new PythBrlOracle(address(pyth), ETH_USD, USD_BRL, 1 hours, 1 hours, 200, governor, DELAY);
        vm.expectRevert(DelayedGovernance.SetupIncomplete.selector);
        fresh.brlCentsPerUnit();
        _completeSetup(address(fresh));
        (uint256 price,) = fresh.brlCentsPerUnit();
        assertEq(price, 1_500_000);
    }

    /// Tightening the age or the confidence bound is a brake; anything that admits more waits.
    function test_TighteningIsInstantRepointingOrLooseningWaits() public {
        vm.startPrank(governor);
        oracle.setFeeds(ETH_USD, USD_BRL, 30 minutes, 30 minutes, 100);
        assertEq(oracle.ethMaxAge(), 30 minutes);
        assertEq(oracle.fxMaxAge(), 30 minutes);
        assertEq(oracle.maxConfBps(), 100);

        bytes32 other = keccak256("another USD/BRL");
        bytes[4] memory loosen = [
            abi.encodeCall(PythBrlOracle.setFeeds, (other, USD_BRL, 30 minutes, 30 minutes, 100)),
            abi.encodeCall(PythBrlOracle.setFeeds, (ETH_USD, other, 30 minutes, 30 minutes, 100)),
            abi.encodeCall(PythBrlOracle.setFeeds, (ETH_USD, USD_BRL, 31 minutes, 31 minutes, 100)),
            abi.encodeCall(PythBrlOracle.setFeeds, (ETH_USD, USD_BRL, 30 minutes, 30 minutes, 101))
        ];
        for (uint256 i; i < loosen.length; ++i) {
            (bool ok, bytes memory ret) = address(oracle).call(loosen[i]);
            assertFalse(ok, "a loosening change went through without the delay");
            assertEq(ret, abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, PythBrlOracle.setFeeds.selector));
        }
        vm.stopPrank();

        // The same repoint, through the delay.
        pyth.set(other, 6e8, 1, -8, block.timestamp + DELAY);
        _afterDelay(address(oracle), loosen[1]);
        assertEq(oracle.usdBrlId(), other);
        pyth.set(ETH_USD, 3000e8, 1, -8, block.timestamp);
        (uint256 price,) = oracle.brlCentsPerUnit();
        assertEq(price, 1_800_000);
    }

    function test_OnlySetFeedsCanBeScheduled() public {
        bytes memory transfer = abi.encodeCall(DelayedGovernance.transferGovernor, (address(1)));
        vm.prank(governor);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.NotDelayable.selector, bytes4(transfer)));
        oracle.schedule(transfer);
    }

    function test_TheConstructorRefusesAnUnusableConfiguration() public {
        vm.expectRevert(DelayedGovernance.ZeroAddress.selector);
        new PythBrlOracle(address(0), ETH_USD, USD_BRL, 1 hours, 1 hours, 200, governor, DELAY);
        vm.expectRevert(DelayedGovernance.ZeroAddress.selector);
        new PythBrlOracle(address(pyth), ETH_USD, USD_BRL, 1 hours, 1 hours, 200, address(0), DELAY);
        vm.expectRevert(PythBrlOracle.BadFeedId.selector);
        new PythBrlOracle(address(pyth), bytes32(0), USD_BRL, 1 hours, 1 hours, 200, governor, DELAY);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.BadGovernanceDelay.selector, 1 hours));
        new PythBrlOracle(address(pyth), ETH_USD, USD_BRL, 1 hours, 1 hours, 200, governor, 1 hours);
    }
}
