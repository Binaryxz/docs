// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {MovvaBase} from "./MovvaReserve.t.sol";
import {Governed} from "./utils/Governed.sol";
import {MockPyth} from "./utils/MockPyth.sol";
import {TetherLike} from "./ERC4626Adapter.t.sol";
import {FxTestFeed} from "./ChainlinkSignedFxOracle.t.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {ERC4626} from "@openzeppelin/contracts/token/ERC20/extensions/ERC4626.sol";
import {MovvaReserve} from "../movva/MovvaReserve.sol";
import {Movva} from "../movva/Movva.sol";
import {PythFxOracle} from "../ramp/PythFxOracle.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";

/// An 18-decimal stablecoin, which the reserve must refuse (N-38).
contract Dec18Usd is ERC20 {
    constructor() ERC20("Eighteen", "USD18") {}
}

/// A vault that, mid-withdrawal, reads the reserve's ratio and records what happened (N-30).
contract PeekingVault is ERC4626 {
    MovvaReserve public reserve;
    bytes public peekError;
    bool public peeked;

    constructor(IERC20 asset_) ERC4626(asset_) ERC20("Peek", "PEEK") {}

    function point(MovvaReserve r) external {
        reserve = r;
    }

    function _withdraw(address caller, address receiver, address owner, uint256 assets, uint256 shares)
        internal
        override
    {
        if (address(reserve) != address(0)) {
            try reserve.collateralRatioBps() returns (uint256) {
                peeked = true;
            } catch (bytes memory e) {
                peekError = e;
            }
        }
        super._withdraw(caller, receiver, owner, assets, shares);
    }
}

/**
 * The v3.1 audit's reserve findings, each against the fix: the keyless exit (N-01, N-02), the vault's
 * cap and the pull that survives finalization (N-03), the liquid valuation and vault-gain-only harvest
 * (N-09, N-26), and the smaller ones (N-29, N-30, N-31, N-38, L-20, L-22). The auditor's own scenarios
 * where they gave one; each test is named after its finding.
 */
contract MovvaAuditV31Test is MovvaBase {
    address alice = makeAddr("alice, a holder");
    address constant DEAD = address(0xdEaD);

    /// A holder with 5,400 Movva (R$ 5.400) out of 54,000, against 10,000 USDT, fully backed.
    function _holder() internal {
        _mint(10_000 * U);
        vm.prank(gateway);
        movva.transfer(alice, 5_400e18);
        vm.prank(alice);
        movva.approve(address(reserve), type(uint256).max);
    }

    function _finalize() internal {
        vm.prank(gov);
        reserve.renounceGovernor();
    }

    /*//////////////////////////////////////////////////////////////
                    N-01: A DEAD ORACLE LEG AFTER FINALIZATION
    //////////////////////////////////////////////////////////////*/

    /// The auditor's PoC, inverted: finalized, the FX leg stops publishing, and a year later the holder
    /// is still stuck - unless the keyless exit opens, which it now does after ORACLE_EXIT_DELAY.
    function test_N01_ADeadFxLegNoLongerFreezesRedemptionsForever() public {
        _holder();
        _finalize();
        vm.warp(block.timestamp + 2 hours); // nobody publishes FX any more
        vm.prank(gateway);
        vm.expectRevert(); // StaleRate
        reserve.redeem(1e18, gateway, 0);
        vm.prank(alice);
        vm.expectRevert(MovvaReserve.ExitClosed.selector);
        reserve.exitRedeem(5_400e18, alice, 0);

        // Anyone starts the clock; the exit opens ORACLE_EXIT_DELAY later, not a second earlier.
        vm.prank(stranger);
        assertFalse(reserve.pokeRate());
        assertEq(reserve.rateStaleSince(), block.timestamp);
        vm.warp(block.timestamp + reserve.ORACLE_EXIT_DELAY() - 1);
        vm.prank(alice);
        vm.expectRevert(MovvaReserve.ExitClosed.selector);
        reserve.exitRedeem(5_400e18, alice, 0);
        vm.warp(block.timestamp + 1);
        (, bool rateDead) = reserve.exitStatus();
        assertTrue(rateDead);

        vm.prank(alice);
        uint256 out = reserve.exitRedeem(5_400e18, alice, 0);
        assertEq(out, 1_000 * U, "min(par at the last rate read, pro rata): both R$ 5,40 here");
        assertEq(usdt.balanceOf(alice), 1_000 * U);
        assertEq(movva.balanceOf(alice), 0);
    }

    /// Once the rate reads again, the oracle exit closes: a dead leg is an emergency, not a mode.
    function test_N01_AReadableRateClosesTheOracleExit() public {
        _holder();
        vm.warp(block.timestamp + 2 hours);
        reserve.pokeRate();
        vm.warp(block.timestamp + reserve.ORACLE_EXIT_DELAY());
        _warp(0); // both legs publish again
        vm.prank(alice);
        vm.expectRevert(MovvaReserve.ExitClosed.selector); // readable, and the gateways are active
        reserve.exitRedeem(5_400e18, alice, 0);
        assertTrue(reserve.pokeRate());
        assertEq(reserve.rateStaleSince(), 0, "a good read withdraws the claim");
        assertEq(reserve.lastGoodRate(), _rate());
    }

    /// Starving the oracle read of gas cannot fake a dead rate: whatever the gas, a healthy rate is never
    /// recorded as unreadable.
    function test_N01_OutOfGasCannotFakeADeadRate() public {
        _holder();
        for (uint256 g = 20_000; g < 120_000; g += 3_000) {
            (bool ok,) = address(reserve).call{gas: g}(abi.encodeCall(MovvaReserve.pokeRate, ()));
            ok;
            assertEq(reserve.rateStaleSince(), 0, "a starved read is never a dead oracle");
        }
    }

    /*//////////////////////////////////////////////////////////////
                    N-02: THE GATEWAY SET AFTER FINALIZATION
    //////////////////////////////////////////////////////////////*/

    /// The auditor's PoC, inverted: finalized, Tether blacklists the only gateway. The holder exits on
    /// their own once the gateways have been quiet for GATEWAY_EXIT_DELAY, at the same price `redeem` pays.
    function test_N02_ABlacklistedGatewayNoLongerFreezesRedemptionsForever() public {
        _holder();
        _finalize();
        usdt.addBlackList(gateway);
        vm.prank(gateway);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.FrozenByAssetIssuer.selector, gateway));
        reserve.redeem(1e18, gateway, 0);
        vm.prank(alice);
        vm.expectRevert(MovvaReserve.NotGateway.selector);
        reserve.redeem(1e18, alice, 0);

        _warp(reserve.GATEWAY_EXIT_DELAY() - 1);
        vm.prank(alice);
        vm.expectRevert(MovvaReserve.ExitClosed.selector);
        reserve.exitRedeem(5_400e18, alice, 0);
        _warp(1);
        (bool quiet,) = reserve.exitStatus();
        assertTrue(quiet);
        vm.prank(alice);
        assertEq(reserve.exitRedeem(5_400e18, alice, 0), 1_000 * U);
    }

    /// A working gateway heartbeats, and the exit never opens.
    function test_N02_AHeartbeatKeepsTheGatewayExitClosed() public {
        _holder();
        _warp(29 days);
        vm.prank(gateway);
        reserve.gatewayHeartbeat();
        _warp(2 days);
        vm.prank(alice);
        vm.expectRevert(MovvaReserve.ExitClosed.selector);
        reserve.exitRedeem(5_400e18, alice, 0);
        vm.prank(stranger);
        vm.expectRevert(MovvaReserve.NotGateway.selector);
        reserve.gatewayHeartbeat();
        // A frozen gateway cannot keep the clock running.
        usdt.addBlackList(gateway);
        vm.prank(gateway);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.FrozenByAssetIssuer.selector, gateway));
        reserve.gatewayHeartbeat();
    }

    /// An operator with a leaked key removes the gateway itself, after finalization too.
    function test_N02_AGatewayCanRemoveItself() public {
        _finalize();
        vm.prank(gateway);
        reserve.renounceGateway();
        assertFalse(reserve.isGateway(gateway));
        vm.prank(gateway);
        vm.expectRevert(MovvaReserve.NotGateway.selector);
        reserve.renounceGateway();
    }

    /// The optional council survives finalization: it adds a gateway only after the delay, removes one at
    /// once, and can hand itself on or renounce.
    function test_N02_TheCouncilAddsAfterTheDelayAndRemovesAtOnce() public {
        address council = makeAddr("gateway council");
        address g2 = makeAddr("second gateway");
        vm.prank(gov);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, MovvaReserve.setGatewayCouncil.selector)
        );
        reserve.setGatewayCouncil(council);
        _afterDelay(address(reserve), abi.encodeCall(MovvaReserve.setGatewayCouncil, (council)));
        _finalize();

        vm.prank(stranger);
        vm.expectRevert(MovvaReserve.NotCouncil.selector);
        reserve.proposeGateway(g2);
        vm.prank(council);
        reserve.proposeGateway(g2);
        uint256 ready = reserve.gatewayReadyAt(g2);
        assertEq(ready, block.timestamp + DELAY);
        vm.prank(council);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.NotReadyYet.selector, bytes32(uint256(uint160(g2))), ready));
        reserve.councilSetGateway(g2, true);
        vm.warp(ready);
        vm.prank(council);
        reserve.councilSetGateway(g2, true);
        assertTrue(reserve.isGateway(g2));
        vm.prank(council);
        reserve.councilSetGateway(gateway, false); // removing is instant
        assertFalse(reserve.isGateway(gateway));
        vm.prank(council);
        reserve.setGatewayCouncil(address(0)); // and it can renounce
        assertEq(reserve.gatewayCouncil(), address(0));
    }

    /*//////////////////////////////////////////////////////////////
                         N-03: THE VAULT, AFTER FINALIZATION
    //////////////////////////////////////////////////////////////*/

    /// After finalization the guardian can still bring the principal home and stop deposits; it can never
    /// send USDT anywhere else, and only the governor resumes deposits.
    function test_N03_TheGuardianPullsThePrincipalBackAfterFinalization() public {
        _mint(10_000 * U);
        assertEq(usdt.balanceOf(address(reserve)), 0, "all in the vault");
        _finalize();
        vm.prank(stranger);
        vm.expectRevert(DelayedGovernance.NotGovernor.selector);
        reserve.pullFromVault(type(uint256).max);
        vm.prank(guardian);
        reserve.pullFromVault(type(uint256).max);
        assertEq(usdt.balanceOf(address(reserve)), 10_000 * U, "home, in the reserve");
        assertEq(vault.balanceOf(address(reserve)), 0);
        assertTrue(reserve.vaultDepositsPaused());
        assertEq(reserve.vaultCostUsdt(), 0);
        vm.prank(guardian);
        vm.expectRevert(DelayedGovernance.NotGovernor.selector);
        reserve.setVaultDepositsPaused(false);
    }

    /*//////////////////////////////////////////////////////////////
                N-09, N-26: WHAT COUNTS, AND WHAT IS YIELD
    //////////////////////////////////////////////////////////////*/

    /// Over-collateralised, with 5,000 of real vault income, then Tether freezes the vault: nothing is
    /// harvestable (the vault can pay nothing now), the idle principal is never paid as "yield", and the
    /// frozen position no longer lets anyone mint against it.
    function test_N09_AFrozenVaultPaysNoHarvestOutOfIdle() public {
        _mint(100_000 * U);
        vm.prank(gateway);
        reserve.recapitalize(10_000 * U);
        usdt.mint(address(vault), 5_000 * U); // income
        assertApproxEqAbs(reserve.harvestableYield(), 5_000 * U, 2, "the vault's gain");
        vm.prank(gov);
        reserve.setVaultDepositsPaused(true);
        _mint(20_000 * U); // stays idle
        usdt.addBlackList(address(vault));
        assertEq(reserve.harvestableYield(), 0, "a frozen vault can pay nothing now");
        vm.prank(stranger);
        vm.expectRevert(MovvaReserve.NothingToHarvest.selector);
        reserve.harvestYield();
        assertEq(reserve.liquidUsdt(), 20_000 * U, "the frozen position counts for nothing");
        vm.prank(gateway);
        vm.expectRevert(); // CollateralRatioTooLow: real backing is under 100%
        reserve.mint(1 * U, gateway, 0);
    }

    /// USDT sent by plain transfer is backing for holders, never Mova's yield.
    function test_N26_ADirectTransferIsBackingNotYield() public {
        _mint(10_000 * U);
        usdt.mint(address(reserve), 5_000 * U);
        assertGt(reserve.collateralRatioBps(), 14_000);
        assertEq(reserve.harvestableYield(), 0);
        vm.expectRevert(MovvaReserve.NothingToHarvest.selector);
        reserve.harvestYield();
    }

    /// A harvest pays only out of what it withdrew from the vault in the same call.
    function test_N09_AHarvestIsPaidOnlyFromTheVault() public {
        _mint(100_000 * U);
        vm.prank(gateway);
        reserve.recapitalize(10_000 * U);
        usdt.mint(address(reserve), 3_000 * U); // a donation, idle
        usdt.mint(address(vault), 1_000 * U); // income
        uint256 idle = usdt.balanceOf(address(reserve));
        uint256 paid = reserve.harvestYield();
        assertApproxEqAbs(paid, 1_000 * U, 2, "the income, not the donation");
        assertEq(usdt.balanceOf(address(reserve)), idle, "idle untouched");
    }

    /*//////////////////////////////////////////////////////////////
                          THE SMALLER ONES
    //////////////////////////////////////////////////////////////*/

    function test_N29_NoAllowanceIsLeftToTheVault() public {
        _mint(10_000 * U);
        assertEq(usdt.allowance(address(reserve), address(vault)), 0);
    }

    /// Mid-redemption, a vault reading the reserve's ratio is refused rather than shown a half-updated one.
    function test_N30_ViewsRefuseToAnswerMidCall() public {
        PeekingVault peek = new PeekingVault(IERC20(address(usdt)));
        _afterDelay(address(reserve), abi.encodeCall(MovvaReserve.setYieldVault, (address(peek))));
        _warp(0);
        peek.point(reserve);
        _mint(10_000 * U);
        assertEq(peek.balanceOf(address(reserve)) > 0, true);
        _redeem(5_400e18);
        assertFalse(peek.peeked());
        assertEq(bytes4(peek.peekError()), MovvaReserve.ReentrantRead.selector);
    }

    function test_N31_MovvaSentToTheReserveIsNoLiability() public {
        _mint(1_000 * U);
        vm.prank(gateway);
        movva.transfer(address(reserve), 540e18);
        assertEq(reserve.liabilitiesBrlE18(), 4_860e18);
        assertEq(reserve.collateralRatioBps(), 11_111, "R$ 5.400 against R$ 4.860");
    }

    function test_N38_AnAssetWithoutSixDecimalsIsRefused() public {
        MovvaReserve.Config memory c = _config();
        c.usdt = address(new Dec18Usd());
        vm.expectRevert(MovvaReserve.AssetMismatch.selector);
        new MovvaReserve(c);
    }

    /// The bound protects what the recipient received, not what the reserve computed.
    function test_L22_TheSlippageBoundIsWhatTheRecipientReceived() public {
        _mint(10_000 * U);
        usdt.setParams(10, 49); // a 0.10% transfer fee
        vm.prank(gateway);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.Slippage.selector, 999 * U, 1_000 * U));
        reserve.redeem(5_400e18, gateway, 1_000 * U);
    }

    /// The reserve itself is not a payee.
    function test_TheReserveCannotRedeemToItself() public {
        _mint(1_000 * U);
        vm.prank(gateway);
        vm.expectRevert(MovvaReserve.BadRecipient.selector);
        reserve.redeem(540e18, address(reserve), 0);
    }

    function test_BadExitConfigsAreRefused() public {
        MovvaReserve.Config memory c = _config();
        c.oracleExitDelay = 1 days;
        vm.expectRevert(MovvaReserve.BadConfig.selector);
        new MovvaReserve(c);
        c = _config();
        c.maxVaultBps = 10_001;
        vm.expectRevert(MovvaReserve.BadConfig.selector);
        new MovvaReserve(c);
        c = _config();
        c.tradeFxMaxAge = 1 hours;
        vm.expectRevert(MovvaReserve.BadConfig.selector);
        new MovvaReserve(c);
    }

    /*//////////////////////////////////////////////////////////////
                       N-04: OSSIFIED GOVERNANCE
    //////////////////////////////////////////////////////////////*/

    /// Ossified, the governor keeps every brake and loses every risk-increasing change, for good.
    function test_N04_OssifyKeepsTheBrakesAndBurnsTheRest() public {
        address g2 = makeAddr("second gateway");
        bytes memory add = abi.encodeCall(MovvaReserve.setGateway, (g2, true));
        vm.prank(gov);
        reserve.schedule(add);
        vm.prank(gov);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.ChangesPending.selector, uint64(1)));
        reserve.ossify();
        vm.prank(gov);
        reserve.cancel(add);
        vm.prank(gov);
        reserve.ossify();
        assertTrue(reserve.ossified());

        vm.startPrank(gov);
        vm.expectRevert(DelayedGovernance.Ossified.selector);
        reserve.schedule(add);
        vm.expectRevert(DelayedGovernance.Ossified.selector);
        reserve.setGateway(g2, true);
        vm.expectRevert(DelayedGovernance.Ossified.selector);
        reserve.ossify();
        // The brakes.
        reserve.pauseMint();
        reserve.setGateway(gateway, false);
        reserve.setSupplyCap(0);
        reserve.pullFromVault(type(uint256).max);
        vm.stopPrank();
        assertFalse(reserve.isGateway(gateway));
    }
}

/// The vault's allocation cap (N-03): at most MAX_VAULT_BPS of the reserve is ever in the vault.
contract MovvaVaultCapTest is MovvaBase {
    function _config() internal view override returns (MovvaReserve.Config memory c) {
        c = super._config();
        c.maxVaultBps = 9_000;
    }

    function test_N03_TheVaultNeverHoldsMoreThanItsCap() public {
        _mint(1_000 * U);
        assertEq(usdt.balanceOf(address(reserve)), 100 * U, "10% stays idle");
        assertEq(vault.previewRedeem(vault.balanceOf(address(reserve))), 900 * U);
        vm.prank(gateway);
        reserve.recapitalize(1_000 * U);
        assertEq(usdt.balanceOf(address(reserve)), 200 * U);
        assertEq(reserve.vaultCostUsdt(), 1_800 * U);
    }
}

/// The round-trip fee floor (N-06, L-20).
contract MovvaFeeFloorTest is MovvaBase {
    function _config() internal view override returns (MovvaReserve.Config memory c) {
        c = super._config();
        (c.mintFeeBps, c.redeemFeeBps, c.minRoundTripFeeBps) = (10, 10, 20);
    }

    function test_L20_FeesNeverFallBelowTheRoundTripFloor() public {
        assertEq(reserve.mintFeeBps(), 10);
        vm.prank(gov);
        vm.expectRevert(MovvaReserve.BadBps.selector);
        reserve.setFees(5, 10);
        MovvaReserve.Config memory c = _config();
        (c.mintFeeBps, c.redeemFeeBps) = (5, 5);
        vm.expectRevert(MovvaReserve.BadBps.selector);
        new MovvaReserve(c);
    }
}

/**
 * N-06 on a Pyth FX leg, the auditor's PoC setting: the reserve at its 108% target, a gateway that can
 * post any Pyth publication newer than the stored one. Before the fix it minted at the stored R$ 5,400
 * and redeemed at a newer R$ 5,373 in one transaction, 30.16 USDT ahead.
 */
contract MovvaPythRoundTripTest is Governed {
    bytes32 constant ID = bytes32(uint256(0xB41));
    uint256 constant U = 1e6;
    TetherLike usdt;
    FxTestFeed feed;
    MockPyth pyth;
    PythFxOracle leg;
    MovvaReserve reserve;
    Movva movva;
    address gov = makeAddr("gov");
    address gateway = makeAddr("gateway");

    function setUp() public {
        vm.warp(1_800_000_000);
        usdt = new TetherLike();
        feed = new FxTestFeed(1e8, 8);
        pyth = new MockPyth(1);
        leg = new PythFxOracle(address(pyth), ID, 1 hours, 4 days, 100, gov, DELAY);
        _completeSetup(address(leg));
        _post(540_000, block.timestamp); // R$ 5,400
        reserve = new MovvaReserve(
            MovvaReserve.Config({
                usdt: address(usdt),
                usdtUsdFeed: address(feed),
                fxOracle: address(leg),
                usdtUsdMaxAge: 25 hours,
                fxMaxAge: 1 hours,
                governor: gov,
                governanceDelay: DELAY,
                guardian: gov,
                feeRecipient: makeAddr("fees"),
                yieldRecipient: makeAddr("yield"),
                supplyCap: 1e30,
                breaker: address(0),
                maxVaultBps: 9_000,
                mintFeeBps: 10,
                redeemFeeBps: 10,
                minRoundTripFeeBps: 20,
                tradeFxMaxAge: 5 minutes,
                oracleExitDelay: 7 days,
                gatewayExitDelay: 30 days,
                gatewayCouncil: address(0)
            })
        );
        movva = Movva(reserve.MOVVA());
        vm.startPrank(gov);
        reserve.setGateway(gateway, true);
        reserve.completeSetup();
        vm.stopPrank();
        usdt.mint(gateway, 1_000_000 * U);
        vm.startPrank(gateway);
        usdt.approve(address(reserve), type(uint256).max);
        movva.approve(address(reserve), type(uint256).max);
        reserve.mint(100_000 * U, gateway, 0);
        reserve.recapitalize(8_000 * U); // the 108% target
        vm.stopPrank();
    }

    function _post(int64 price, uint256 at) internal {
        pyth.set(ID, price, 0, -5, at);
        feed.set(1e8, block.timestamp);
    }

    function test_N06_AStoredPublicationMinutesOldIsRefusedForATrade() public {
        vm.warp(block.timestamp + 20 minutes);
        feed.set(1e8, block.timestamp);
        (, uint64 at) = reserve.brlPerUsdtE18(); // still a readable rate, at fxMaxAge
        vm.prank(gateway);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.StaleLeg.selector, address(leg), at));
        reserve.mint(10_000 * U, gateway, 0);
    }

    function test_N06_TheTwoPublicationRoundTripIsRefused() public {
        vm.warp(block.timestamp + 20 minutes);
        uint256 t = block.timestamp;
        _post(540_000, t - 60); // the older publication, a minute old
        vm.prank(gateway);
        reserve.mint(10_000 * U, gateway, 0);
        _post(537_300, t); // the newer one, R$ 5,373
        vm.prank(gateway);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.RoundTripTooSoon.selector, t + 5 minutes));
        reserve.redeem(53_000e18, gateway, 0);
        // A block later, and a minute later, it still waits: only a publication made after the mint can
        // price the way back.
        vm.roll(block.number + 1);
        vm.warp(t + 5 minutes - 1);
        vm.prank(gateway);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.RoundTripTooSoon.selector, t + 5 minutes));
        reserve.redeem(53_000e18, gateway, 0);
        // Past t + 5 minutes the oldest usable publication is newer than the mint: one the gateway could not
        // see when it minted, so the way back is priced by the market, not by its choice.
        vm.warp(t + 5 minutes + 1);
        vm.prank(gateway);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.StaleLeg.selector, address(leg), uint64(t)));
        reserve.redeem(53_000e18, gateway, 0);
        _post(537_300, block.timestamp);
        vm.prank(gateway);
        reserve.redeem(53_000e18, gateway, 0);
    }

    /// Trades in the same direction are not delayed.
    function test_N06_RepeatedMintsAreNotDelayed() public {
        vm.startPrank(gateway);
        reserve.mint(1_000 * U, gateway, 0);
        reserve.mint(1_000 * U, gateway, 0);
        vm.stopPrank();
    }
}
