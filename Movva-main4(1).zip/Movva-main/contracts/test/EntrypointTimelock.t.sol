// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import {IAccessControl} from "@openzeppelin/contracts/access/IAccessControl.sol";
import {TimelockController} from "@openzeppelin/contracts/governance/TimelockController.sol";
import {EntrypointTimelock} from "../governance/EntrypointTimelock.sol";

/// @dev Stands in for the Entrypoint: one OWNER_ROLE-gated setter, so the test sees who the call comes from.
contract OwnedTarget {
    address public immutable OWNER;
    uint256 public vettingFeeBps;

    constructor(address owner) {
        OWNER = owner;
    }

    function setFee(uint256 v) external {
        require(msg.sender == OWNER, "not the owner");
        vettingFeeBps = v;
    }
}

/// H-02: the Entrypoint owner as scripts/deploy-movva-rail.ts deploys it - 7 days, the Safe alone proposing, cancelling
/// and executing, administering itself.
contract EntrypointTimelockTest is Test {
    address safe = makeAddr("governor safe");
    address deployer = makeAddr("deployer");
    EntrypointTimelock tl;
    OwnedTarget target;

    function setUp() public {
        address[] memory s = new address[](1);
        s[0] = safe;
        vm.prank(deployer);
        tl = new EntrypointTimelock(7 days, s, s, address(0), new address[](0));
        target = new OwnedTarget(address(tl));
    }

    function test_RolesAreTheSafesAloneAndTheTimelockAdministersItself() public view {
        assertEq(tl.getMinDelay(), 7 days);
        assertTrue(tl.hasRole(tl.PROPOSER_ROLE(), safe));
        assertTrue(tl.hasRole(tl.CANCELLER_ROLE(), safe));
        assertTrue(tl.hasRole(tl.EXECUTOR_ROLE(), safe));
        assertFalse(tl.hasRole(tl.EXECUTOR_ROLE(), address(0)), "executor not open");
        assertTrue(tl.hasRole(tl.DEFAULT_ADMIN_ROLE(), address(tl)));
        assertFalse(tl.hasRole(tl.DEFAULT_ADMIN_ROLE(), deployer), "the deployer administers nothing");
        assertFalse(tl.hasRole(tl.PROPOSER_ROLE(), deployer));
    }

    function test_AnOwnerActionWaitsSevenDaysAndOnlyTheSafeRunsIt() public {
        bytes memory call = abi.encodeCall(OwnedTarget.setFee, (9_999));
        (bytes32 proposer, bytes32 executor) = (tl.PROPOSER_ROLE(), tl.EXECUTOR_ROLE());
        vm.prank(deployer);
        vm.expectRevert(abi.encodeWithSelector(IAccessControl.AccessControlUnauthorizedAccount.selector, deployer, proposer));
        tl.schedule(address(target), 0, call, bytes32(0), bytes32(0), 7 days);

        vm.prank(safe);
        vm.expectRevert(abi.encodeWithSelector(TimelockController.TimelockInsufficientDelay.selector, 1 days, 7 days));
        tl.schedule(address(target), 0, call, bytes32(0), bytes32(0), 1 days);

        vm.prank(safe);
        tl.schedule(address(target), 0, call, bytes32(0), bytes32(0), 7 days);
        bytes32 id = tl.hashOperation(address(target), 0, call, bytes32(0), bytes32(0));

        vm.warp(block.timestamp + 7 days - 1);
        vm.prank(safe);
        vm.expectRevert();
        tl.execute(address(target), 0, call, bytes32(0), bytes32(0));

        vm.warp(block.timestamp + 1);
        vm.prank(deployer);
        vm.expectRevert(abi.encodeWithSelector(IAccessControl.AccessControlUnauthorizedAccount.selector, deployer, executor));
        tl.execute(address(target), 0, call, bytes32(0), bytes32(0));

        vm.prank(safe);
        tl.execute(address(target), 0, call, bytes32(0), bytes32(0));
        assertEq(target.vettingFeeBps(), 9_999);
        assertTrue(tl.isOperationDone(id));
    }

    function test_TheSafeCancelsAndOnlyAnOperationChangesTheDelay() public {
        bytes memory call = abi.encodeCall(OwnedTarget.setFee, (1));
        bytes32 proposer = tl.PROPOSER_ROLE();
        vm.startPrank(safe);
        tl.schedule(address(target), 0, call, bytes32(0), bytes32(0), 7 days);
        tl.cancel(tl.hashOperation(address(target), 0, call, bytes32(0), bytes32(0)));
        vm.expectRevert(abi.encodeWithSelector(TimelockController.TimelockUnauthorizedCaller.selector, safe));
        tl.updateDelay(0);
        vm.expectRevert(abi.encodeWithSelector(IAccessControl.AccessControlUnauthorizedAccount.selector, safe, bytes32(0)));
        tl.grantRole(proposer, deployer);
        vm.stopPrank();
    }
}
