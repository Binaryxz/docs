// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import {AuditGrantRegistry} from "../AuditGrantRegistry.sol";

// Registry test suite. Mirrors packages/viewing-key/test/registry.test.ts, which drives the
// same contract through an ethereumjs EVM harness. Both are kept: the TS suite runs in the
// same vitest pass as the client library, while this one is what an external reviewer reaches
// for.
contract AuditGrantRegistryTest is Test {
    AuditGrantRegistry internal registry;

    address internal alice = address(0xA11CE);
    address internal bob = address(0xB0B);

    bytes32 internal constant GRANT = bytes32(uint256(0x11));
    bytes32 internal constant SUBJECT = bytes32(uint256(0x22));
    bytes32 internal constant POINTER = bytes32(uint256(0x33));
    bytes32 internal constant EPOCH = bytes32(uint256(0x44));
    bytes32 internal constant EPOCH2 = bytes32(uint256(0x55));
    bytes32 internal constant CHAIN = bytes32(uint256(0x66));
    bytes32 internal constant HEAD1 = bytes32(uint256(0x01));
    bytes32 internal constant HEAD2 = bytes32(uint256(0x02));

    function setUp() public {
        registry = new AuditGrantRegistry();
        vm.warp(1_700_000_000);
    }

    function _register(address who) internal {
        vm.prank(who);
        registry.register(
            GRANT, SUBJECT, uint64(block.timestamp), uint64(block.timestamp + 3600), POINTER
        );
    }

    function test_RegistersAndReportsLive() public {
        _register(alice);

        (bool exists, bytes32 subject, uint64 revokedAt, uint64 expiry) =
            registry.statusOf(alice, GRANT);
        assertTrue(exists);
        assertEq(subject, SUBJECT, "subject must be bound on-chain");
        assertEq(revokedAt, 0);
        assertEq(expiry, uint64(block.timestamp + 3600));
        assertTrue(registry.isLive(alice, GRANT));
    }

    function test_RejectsEmptySubject() public {
        vm.prank(alice);
        vm.expectRevert(AuditGrantRegistry.EmptySubject.selector);
        registry.register(
            GRANT, bytes32(0), uint64(block.timestamp), uint64(block.timestamp + 1), POINTER
        );
    }

    function test_RejectsBadWindow() public {
        vm.startPrank(alice);
        vm.expectRevert(AuditGrantRegistry.BadWindow.selector);
        registry.register(
            GRANT, SUBJECT, uint64(block.timestamp + 10), uint64(block.timestamp), POINTER
        );

        vm.expectRevert(AuditGrantRegistry.BadWindow.selector);
        registry.register(GRANT, SUBJECT, 0, uint64(block.timestamp - 1), POINTER);
        vm.stopPrank();
    }

    /// A front-runner must not be able to block the real subject's registration.
    function test_GrantsAreKeyedPerOwner() public {
        vm.prank(bob);
        registry.register(
            GRANT,
            bytes32(uint256(0xEE)),
            uint64(block.timestamp),
            uint64(block.timestamp + 3600),
            POINTER
        );

        _register(alice);

        (, bytes32 aliceSubject,,) = registry.statusOf(alice, GRANT);
        (, bytes32 bobSubject,,) = registry.statusOf(bob, GRANT);
        assertEq(aliceSubject, SUBJECT);
        assertEq(bobSubject, bytes32(uint256(0xEE)));
    }

    function test_RefusesDuplicateFromSameOwner() public {
        _register(alice);
        vm.prank(alice);
        vm.expectRevert(AuditGrantRegistry.AlreadyRegistered.selector);
        registry.register(
            GRANT, SUBJECT, uint64(block.timestamp), uint64(block.timestamp + 3600), POINTER
        );
    }

    function test_OnlyOwnerRevokes_AndRevocationIsIdempotent() public {
        _register(alice);

        // Bob's call only ever reaches Bob's own slot, which does not exist.
        vm.prank(bob);
        vm.expectRevert(AuditGrantRegistry.UnknownGrant.selector);
        registry.revoke(GRANT);
        assertTrue(registry.isLive(alice, GRANT), "bob must not affect alice's grant");

        vm.warp(block.timestamp + 100);
        uint64 firstRevocation = uint64(block.timestamp);
        vm.prank(alice);
        registry.revoke(GRANT);
        (,, uint64 revokedAt,) = registry.statusOf(alice, GRANT);
        assertEq(revokedAt, firstRevocation);
        assertFalse(registry.isLive(alice, GRANT));

        // Revoking again must not move the binding timestamp.
        vm.warp(block.timestamp + 400);
        vm.prank(alice);
        registry.revoke(GRANT);
        (,, revokedAt,) = registry.statusOf(alice, GRANT);
        assertEq(revokedAt, firstRevocation, "first revocation timestamp is the binding one");
    }

    function test_LivenessWindow() public {
        uint64 from = uint64(block.timestamp + 100);
        uint64 until = uint64(block.timestamp + 3600);
        vm.prank(alice);
        registry.register(GRANT, SUBJECT, from, until, POINTER);

        assertFalse(registry.isLive(alice, GRANT), "not live before validFrom");
        vm.warp(from + 1);
        assertTrue(registry.isLive(alice, GRANT));
        vm.warp(until + 1);
        assertFalse(registry.isLive(alice, GRANT), "not live after expiry");
    }

    function test_RevokeAndRotate() public {
        _register(alice);
        bytes32[] memory epochs = new bytes32[](2);
        epochs[0] = EPOCH;
        epochs[1] = EPOCH2;

        vm.prank(alice);
        registry.revokeAndRotate(GRANT, epochs);

        assertEq(registry.rotation(alice, EPOCH), 1);
        assertEq(registry.rotation(alice, EPOCH2), 1);
        assertEq(registry.rotation(bob, EPOCH), 0, "rotation is per owner");
        assertFalse(registry.isLive(alice, GRANT));
    }

    function test_RevokeAndRotate_RevertsForUnknownGrant_WithoutRotating() public {
        bytes32[] memory epochs = new bytes32[](1);
        epochs[0] = EPOCH;

        vm.prank(alice);
        vm.expectRevert(AuditGrantRegistry.UnknownGrant.selector);
        registry.revokeAndRotate(GRANT, epochs);
        assertEq(registry.rotation(alice, EPOCH), 0);
    }

    function test_RegisterAndRotate_SealsChainsAtIssuance() public {
        bytes32[] memory epochs = new bytes32[](2);
        epochs[0] = EPOCH;
        epochs[1] = EPOCH2;

        vm.prank(alice);
        registry.registerAndRotate(GRANT, SUBJECT, uint64(block.timestamp), uint64(block.timestamp + 30 days), bytes32(0), epochs);

        assertTrue(registry.isLive(alice, GRANT));
        assertEq(registry.rotation(alice, EPOCH), 1);
        assertEq(registry.rotation(alice, EPOCH2), 1);
        assertEq(registry.rotation(bob, EPOCH), 0, "rotation is per owner");
        (bool exists, bytes32 subject,,) = registry.statusOf(alice, GRANT);
        assertTrue(exists);
        assertEq(subject, SUBJECT);
    }

    function test_RegisterAndRotate_RevertsWithoutRotating() public {
        bytes32[] memory epochs = new bytes32[](1);
        epochs[0] = EPOCH;

        vm.prank(alice);
        vm.expectRevert(AuditGrantRegistry.BadWindow.selector);
        registry.registerAndRotate(GRANT, SUBJECT, uint64(block.timestamp + 10), uint64(block.timestamp + 5), bytes32(0), epochs);
        assertEq(registry.rotation(alice, EPOCH), 0);
        assertFalse(registry.isLive(alice, GRANT));
    }

    function testFuzz_RotationIsMonotonic(uint8 times) public {
        vm.assume(times > 0 && times < 40);
        for (uint256 i = 1; i <= times; i++) {
            vm.prank(alice);
            registry.rotateEpoch(EPOCH);
            assertEq(registry.rotation(alice, EPOCH), uint32(i));
        }
    }

    function test_AnchorGrowsAndRecordsTime() public {
        vm.prank(alice);
        registry.anchorChain(CHAIN, HEAD1, 3);
        (bytes32 head, uint32 count, uint64 at) = registry.anchorOf(alice, CHAIN);
        assertEq(head, HEAD1);
        assertEq(count, 3);
        assertEq(at, uint64(block.timestamp));

        vm.warp(block.timestamp + 60);
        bytes32[] memory more = new bytes32[](2);
        more[0] = keccak256("record 3");
        more[1] = keccak256("record 4");
        vm.prank(alice);
        bytes32 next = registry.extendChain(CHAIN, more);
        // As ShieldedNoteLog chains records: keccak256(abi.encode(chainKey, seq, prevHash, keccak256(record))).
        bytes32 h3 = keccak256(abi.encode(CHAIN, uint32(3), HEAD1, more[0]));
        assertEq(next, keccak256(abi.encode(CHAIN, uint32(4), h3, more[1])));
        (head, count, at) = registry.anchorOf(alice, CHAIN);
        assertEq(head, next);
        assertEq(count, 5);
        assertEq(at, uint64(block.timestamp));
    }

    /// Shortening or rewriting published history is the attack anchors exist to stop (v2.0 I-30): after the first
    /// anchor, the only way forward is an on-chain extension of it.
    function test_AnchorCannotShrinkOrBeRewritten() public {
        vm.startPrank(alice);
        registry.anchorChain(CHAIN, HEAD2, 5);

        vm.expectRevert(AuditGrantRegistry.AnchorNotMonotonic.selector);
        registry.anchorChain(CHAIN, HEAD1, 4);
        vm.expectRevert(AuditGrantRegistry.AnchorNotMonotonic.selector);
        registry.anchorChain(CHAIN, HEAD1, 6);
        vm.expectRevert(AuditGrantRegistry.AnchorNotMonotonic.selector);
        registry.anchorChain(CHAIN, HEAD2, 5);

        vm.expectRevert(AuditGrantRegistry.EmptyAnchor.selector);
        registry.extendChain(CHAIN, new bytes32[](0));
        vm.stopPrank();
        vm.prank(bob);
        vm.expectRevert(AuditGrantRegistry.EmptyAnchor.selector);
        registry.extendChain(CHAIN, new bytes32[](1));
    }

    function test_AnchorRejectsEmptyAndIsPerOwner() public {
        vm.startPrank(alice);
        vm.expectRevert(AuditGrantRegistry.EmptyAnchor.selector);
        registry.anchorChain(CHAIN, bytes32(0), 1);

        vm.expectRevert(AuditGrantRegistry.EmptyAnchor.selector);
        registry.anchorChain(CHAIN, HEAD1, 0);

        registry.anchorChain(CHAIN, HEAD1, 2);
        vm.stopPrank();

        (, uint32 bobCount,) = registry.anchorOf(bob, CHAIN);
        assertEq(bobCount, 0);
    }

    /// The registry must never be able to hold or move value.
    function test_HoldsNoValue() public {
        assertEq(address(registry).balance, 0);
        vm.deal(alice, 1 ether);
        vm.prank(alice);
        (bool ok,) = address(registry).call{value: 1 ether}("");
        assertFalse(ok, "registry must reject ether: no receive or payable function");
        assertEq(address(registry).balance, 0);
    }
}
