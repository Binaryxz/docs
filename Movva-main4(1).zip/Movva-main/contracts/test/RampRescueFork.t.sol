// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;
import {ProverOf} from "./utils/ProverOf.sol";

import {Vm} from "forge-std/Test.sol";
import {Governed} from "./utils/Governed.sol";
import {FiatEscrow} from "../ramp/FiatEscrow.sol";
import {LPRegistry} from "../ramp/LPRegistry.sol";
import {IAttestorVerifier} from "../ramp/IAttestorVerifier.sol";
import {IPriceOracle} from "../ramp/IPriceOracle.sol";

contract FixedOracle3 is IPriceOracle {
    function brlCentsPerUnit() external view returns (uint256, uint64) {
        return (1_500_000, uint64(block.timestamp));
    }
}

/**
 * The escrow's recorded label, against the label the REAL Privacy Pool emits.
 *
 * The escrow recomputes a value the pool derives and does not return. That is the exact
 * shape of the `labelOf` bug in Phase 1, where a model agreed with itself for two tasks. So
 * this runs a shielded delivery through the real Entrypoint and pool and compares the
 * escrow's label with the one in the pool's own `Deposited` event.
 *
 * Needs FORK_RPC plus PP_ENTRYPOINT and PP_POOL (the ETH pool). Skips when any is unset.
 */
contract RampRescueForkTest is Governed {
    address ENTRYPOINT;
    address ETH_POOL;
    uint256 constant P = 21888242871839275222246405745257275088548364400416034343698204186575808495617;

    bool live;
    FiatEscrow escrow;
    LPRegistry registry;
    address gov = makeAddr("gov");
    address lp = makeAddr("lp");
    address taker = makeAddr("taker");
    bytes32 constant PIX = keccak256("lp@pix");

    function setUp() public {
        string memory rpc = vm.envOr("FORK_RPC", string(""));
        if (bytes(rpc).length == 0) return;
        // The same variables DeployRamp.s.sol reads.
        ENTRYPOINT = vm.envOr("PP_ENTRYPOINT", address(0));
        ETH_POOL = vm.envOr("PP_POOL", address(0));
        if (ENTRYPOINT == address(0) || ETH_POOL == address(0)) return;
        vm.createSelectFork(rpc);
        if (ENTRYPOINT.code.length == 0 || ETH_POOL.code.length == 0) return;
        live = true;

        registry = new LPRegistry(gov, DELAY);
        escrow = new FiatEscrow(address(new FixedOracle3()), address(registry), ENTRYPOINT, ETH_POOL, 500, gov, DELAY, DISPUTE_TIMEOUT, TAKER_DISPUTE_TIMEOUT, MAX_VETTING_FEE_BPS);
        vm.startPrank(gov);
        registry.setEscrow(address(escrow), true);
        registry.setTier(lp, LPRegistry.Tier.INSTITUTIONAL, 100_000_000);
        registry.completeSetup();
        escrow.setVerifier(address(this), true);
        escrow.completeSetup();
        vm.stopPrank();
        vm.deal(lp, 10 ether);
    }

    function verifyPayment(bytes32 orderId, bytes calldata)
        external
        view
        returns (IAttestorVerifier.Payment memory p)
    {
        p = IAttestorVerifier.Payment({
            bankTxId: keccak256(abi.encode(orderId)),
            payeeKeyHash: PIX,
            payerRef: bytes32(uint256(1)),
            amountBrlCents: type(uint256).max,
            paidAt: uint64(block.timestamp),
            rail: IAttestorVerifier.Rail.PIX,
            prover: ProverOf.lpOf(msg.sender, orderId)
        });
    }

    function attestorKind() external pure returns (string memory) {
        return "test";
    }

    function provesBankSession() external pure returns (bool) {
        return true;
    }

    function test_TheEscrowRecordsTheLabelTheRealPoolAssigned() public {
        if (!live) return;
        vm.prank(lp);
        bytes32 offerId = escrow.postOffer{value: 5 ether}(
            address(0), 5 ether, 1_500_000, PIX, 0.01 ether, 2 ether, address(this),
            uint16(1 << uint8(IAttestorVerifier.Rail.PIX))
        );
        uint256 precommitment = uint256(keccak256(abi.encode(block.timestamp, "rescue-fork"))) % P;
        vm.prank(taker);
        bytes32 orderId = escrow.lockOrder(offerId, 1 ether, FiatEscrow.Delivery.SHIELDED, taker, precommitment);

        vm.recordLogs();
        escrow.releaseWithProof(orderId, "");
        Vm.Log[] memory logs = vm.getRecordedLogs();

        bytes32 topic = keccak256("Deposited(address,uint256,uint256,uint256,uint256)");
        uint256 label;
        bool found;
        for (uint256 i; i < logs.length; ++i) {
            if (logs[i].emitter == ETH_POOL && logs[i].topics[0] == topic) {
                (, label,,) = abi.decode(logs[i].data, (uint256, uint256, uint256, uint256));
                found = true;
            }
        }
        assertTrue(found, "the real pool emitted Deposited");
        assertEq(escrow.labelOfOrder(orderId), label, "escrow label == pool label");
        // orderForLabel, the reverse index rescue routes by, is internal (FiatEscrow size); RampRescue.t.sol exercises it.
    }
}
