// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {console2} from "forge-std/console2.sol";
import {Governed} from "./utils/Governed.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {IERC4626} from "@openzeppelin/contracts/interfaces/IERC4626.sol";
import {IUSDT, IAavePool, IAaveAddressesProvider, IAaveConfigurator} from "./AaveUSDTFork.t.sol";
import {IChainlinkRounds} from "./UsdtRampFork.t.sol";
import {YieldVault} from "../yield/YieldVault.sol";
import {ERC4626Adapter} from "../yield/adapters/ERC4626Adapter.sol";
import {SignedPriceOracle} from "../ramp/SignedPriceOracle.sol";
import {Movva} from "../movva/Movva.sol";
import {MovvaReserve} from "../movva/MovvaReserve.sol";

/**
 * Movva against the real contracts on an Ethereum mainnet fork: Tether's USDT, Chainlink's USDT/USD
 * feed (0x3E7d1eAB13ad0104d2750B8863b489D65364e32D), and a `YieldVault(USDT)` + `ERC4626Adapter` over
 * Aave v3's USDT wrapper (0x7Bc3485026Ac48b6cf9BaF0A377477Fff5703Af8), all unmodified. Only our
 * contracts are deployed; the FX publishers are two test keys signing BRL per dollar at 1e-6.
 *
 * ## What is real and what is simulated
 *
 *  - **Real:** USDT transfers, Tether's blacklist (pranking `USDT.owner()`), Aave supply, interest,
 *    borrows and liquidity, and the feed's latest answer and timestamp at the fork block.
 *  - **The FX rate** is whatever the test keys sign: R$ 5,4012 per dollar, then 10% either way. The
 *    real moves are the point of the hedge; which number the market prints is not.
 *  - **The Chainlink leg, after the clock moves.** A fork does not advance the feed. Where a test warps
 *    past the feed's 25-hour max age (the Aave yield test), `latestRoundData` is mocked with
 *    `vm.mockCall` to return the feed's own last answer at the new time: the answer is real, the
 *    timestamp is the simulated heartbeat. The depeg test mocks a $0.90 answer, and says so.
 *  - **Balances** come from forge's `deal`, and the Aave borrower's WETH the same way.
 *
 *   FORK_RPC=https://ethereum-rpc.publicnode.com forge test --match-path contracts/test/MovvaFork.t.sol -vv
 *
 * Skips without FORK_RPC. `MOVVA_FORK_BLOCK` pins a block, which needs an archive RPC.
 */
contract MovvaForkTest is Governed {
    address constant USDT = 0xdAC17F958D2ee523a2206206994597C13D831ec7;
    address constant USDT_USD = 0x3E7d1eAB13ad0104d2750B8863b489D65364e32D;
    address constant STATA = 0x7Bc3485026Ac48b6cf9BaF0A377477Fff5703Af8;
    address constant AAVE_POOL = 0x87870Bca3F3fD6335C3F4ce8392D69350B4fA4E2;
    address constant WETH = 0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2;

    uint256 constant P1 = 0xF1;
    uint256 constant P2 = 0xF2;
    uint256 constant FX = 5_401_200; // R$ 5,4012 per US dollar, at 1e-6
    uint256 constant MINTED_USDT = 1_000_000e6;
    uint256 constant ALLOCATED = 900_000e6;

    bool live;
    SignedPriceOracle fx;
    YieldVault vault;
    ERC4626Adapter adapter;
    MovvaReserve reserve;
    Movva movva;
    uint64 fxSeq;
    uint256 fxNow;

    address gov = makeAddr("gov");
    address guardian = makeAddr("guardian");
    address keeper = makeAddr("keeper");
    address yieldTo = makeAddr("yield recipient");
    address feeTo = makeAddr("fee recipient");
    address gateway = makeAddr("gateway");
    address issuer = makeAddr("issuer");

    function setUp() public {
        string memory rpc = vm.envOr("FORK_RPC", string(""));
        if (bytes(rpc).length == 0) return;
        uint256 blk = vm.envOr("MOVVA_FORK_BLOCK", uint256(0));
        if (blk == 0) vm.createSelectFork(rpc);
        else vm.createSelectFork(rpc, blk);
        if (USDT.code.length == 0 || USDT_USD.code.length == 0 || STATA.code.length == 0) return;
        live = true;

        address[] memory pubs = new address[](2);
        (pubs[0], pubs[1]) = (vm.addr(P1), vm.addr(P2));
        fx = new SignedPriceOracle(gov, DELAY, pubs, 2);
        _publish(FX);

        vault = new YieldVault(IERC20(USDT), "Shielded Yield USDT", "syUSDT", gov, guardian, keeper, 1e15, 100, DELAY);
        adapter = new ERC4626Adapter(address(vault), IERC4626(STATA), "Aave v3 USDT (stataUSDT)");
        reserve = new MovvaReserve(
            MovvaReserve.Config({
                usdt: USDT,
                usdtUsdFeed: USDT_USD,
                fxOracle: address(fx),
                usdtUsdMaxAge: 25 hours,
                fxMaxAge: 1 hours,
                governor: gov,
                governanceDelay: DELAY,
                guardian: guardian,
                feeRecipient: feeTo,
                yieldRecipient: yieldTo,
                supplyCap: 100_000_000e18,
                breaker: address(0),
                maxVaultBps: 10_000,
                mintFeeBps: 0,
                redeemFeeBps: 0,
                minRoundTripFeeBps: 0,
                tradeFxMaxAge: 0,
                oracleExitDelay: 7 days,
                gatewayExitDelay: 30 days,
                gatewayCouncil: address(0)
            })
        );
        movva = Movva(reserve.MOVVA());
        vm.startPrank(gov);
        fx.completeSetup();
        vault.addAdapter(adapter, 10_000);
        vault.completeSetup();
        reserve.setGateway(gateway, true);
        reserve.setYieldVault(address(vault));
        reserve.completeSetup();
        vm.stopPrank();

        deal(USDT, gateway, 10_000_000e6);
        deal(USDT, issuer, 1_000_000e6);
        vm.prank(gateway);
        IUSDT(USDT).approve(address(reserve), type(uint256).max);
        vm.prank(gateway);
        movva.approve(address(reserve), type(uint256).max);
        vm.prank(issuer);
        IUSDT(USDT).approve(address(reserve), type(uint256).max);
    }

    /*//////////////////////////////////////////////////////////////
                                 HELPERS
    //////////////////////////////////////////////////////////////*/

    function _publish(uint256 e6) internal {
        uint64 at = uint64(block.timestamp);
        bytes32 d = fx.digest(e6, at, ++fxSeq);
        (uint256 lo, uint256 hi) = vm.addr(P1) < vm.addr(P2) ? (P1, P2) : (P2, P1);
        bytes[] memory sigs = new bytes[](2);
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(lo, d);
        sigs[0] = abi.encodePacked(r, s, v);
        (v, r, s) = vm.sign(hi, d);
        sigs[1] = abi.encodePacked(r, s, v);
        fx.submit(e6, at, fxSeq, sigs);
        fxNow = e6;
    }

    function _answer() internal view returns (int256 answer, uint80 id, uint256 at) {
        (id, answer,, at,) = IChainlinkRounds(USDT_USD).latestRoundData();
    }

    /// Serve the feed's answer at the current time (see the header: simulated heartbeat or depeg).
    function _mockFeed(int256 answer) internal {
        (, uint80 id,) = _answer();
        vm.mockCall(
            USDT_USD,
            abi.encodeWithSelector(IChainlinkRounds.latestRoundData.selector),
            abi.encode(id + 1, answer, block.timestamp, block.timestamp, id + 1)
        );
    }

    function _mintAndAllocate() internal returns (uint256 out) {
        vm.prank(gateway);
        out = reserve.mint(MINTED_USDT, gateway, 0);
        vm.roll(block.number + 1); // one block between a mint and a redemption (N-06)
        vm.prank(keeper);
        vault.allocate(adapter, ALLOCATED);
    }

    function _ratio(string memory label) internal view returns (uint256 r) {
        r = reserve.collateralRatioBps();
        console2.log(label, r);
    }

    /*//////////////////////////////////////////////////////////////
                                  TESTS
    //////////////////////////////////////////////////////////////*/

    /// The rate crosses the live feed with the signed leg, by hand, and a gateway mints real USDT
    /// into Aave through the vault.
    function test_AGatewayMintsRealUsdtIntoAaveAtTheRealFeedsRate() public {
        if (!live) return;
        (int256 answer,, uint256 at) = _answer();
        console2.log("fork block", block.number);
        console2.log("USDT/USD answer (8dp)", uint256(answer));
        console2.log("feed answer age (s)", block.timestamp - at);
        (uint256 rate, uint64 updatedAt) = reserve.brlPerUsdtE18();
        assertEq(rate, (uint256(answer) * FX * 1e12) / 1e8, "the cross, by hand");
        assertEq(updatedAt, uint64(block.timestamp), "freshness is the signed leg's");
        assertApproxEqRel(rate, 5.4012e18, 0.02e18, "within 2% of the peg");

        uint256 out = _mintAndAllocate();
        assertEq(out, (MINTED_USDT * rate) / 1e6, "1,000,000 USDT at the rate");
        console2.log("Movva minted for 1,000,000 USDT (whole)", out / 1e18);
        assertGt(IERC20(STATA).balanceOf(address(adapter)), 0, "real Aave wrapper shares");
        assertApproxEqAbs(reserve.totalUsdt(), MINTED_USDT, 2, "valued at what an exit pays");
        assertEq(reserve.liabilitiesUsdt(), MINTED_USDT, "what the issuer hedges");
        (uint256 cents,) = reserve.brlCentsPerUnit();
        assertEq(cents, 100, "the ramps' band for Movva: R$ 1,00");

        // A reserve at exactly par loses a base unit or two to the Aave wrapper's rounding when the
        // keeper allocates, and the ratio - rounded down - reads 9,999 bps. With a 100% mint floor that
        // stops minting until a buffer exists: here, one block of Aave's own interest.
        uint256 atPar = _ratio("ratio after mint and allocation (bps)");
        assertGe(atPar, 9_999);
        if (atPar < 10_000) {
            vm.prank(gateway);
            vm.expectRevert(abi.encodeWithSelector(MovvaReserve.CollateralRatioTooLow.selector, 9_999, 10_000));
            reserve.mint(1_000e6, gateway, 0);
            vm.warp(block.timestamp + 12);
            assertGe(_ratio("one block of Aave interest later (bps)"), 10_000);
        }
        vm.prank(gateway);
        reserve.mint(1_000e6, gateway, 0);
        vm.roll(block.number + 1); // one block between a mint and a redemption (N-06)
    }

    /**
     * The real moves 10% in a day, both ways, from rest: 1,000,000 USDT minted plus the issuer's 8%
     * launch buffer, so the reserve starts at its 108% target.
     *
     *  - The real weakens 10% (ratio 118.8%). The B3 short on the hedged dollars loses 10% in reais,
     *    and that margin is Mova's own capital (the principal-locked reserve, 21 October 2026): not one
     *    USDT leaves the reserve, and the move is no yield - nothing is harvestable.
     *  - From the same rest, the real strengthens 10% instead: 97.2%. Minting stops, a redemption pays
     *    pro rata, and the short's gain, converted to USDT, restores the 108% target.
     */
    function test_TheRealMovesTenPercentBothWays() public {
        if (!live) return;
        _mintAndAllocate();
        vm.prank(issuer);
        reserve.recapitalize(80_000e6);
        uint256 rest = _ratio("at rest, with the issuer's 8% buffer (bps)");
        assertApproxEqAbs(rest, 10_800, 1);
        uint256 hedgedUsd = reserve.liabilitiesUsdt();
        console2.log("liabilities in USDT, hedged at B3", hedgedUsd / 1e6);
        uint256 snap = vm.snapshotState();
        _realWeakensTenPercent(hedgedUsd);
        vm.revertToState(snap);
        _realStrengthensTenPercent(hedgedUsd);
    }

    function _realWeakensTenPercent(uint256 hedgedUsd) internal {
        uint256 fxUp = (FX * 110) / 100;
        _publish(fxUp);
        uint256 up = _ratio("real weakens 10%: ratio (bps)");
        assertApproxEqAbs(up, 11_880, 1);
        console2.log("surplus above 108% (BRL)", reserve.surplusBrlE18() / 1e18);
        (uint256 rateUp,) = reserve.brlPerUsdtE18();
        uint256 variationBrl = (hedgedUsd * (fxUp - FX) * 1e12) / 1e6;
        console2.log("B3 variation margin on the short (BRL)", variationBrl / 1e18);

        console2.log("  in USDT, paid from Mova's own capital", variationBrl * 1e6 / rateUp / 1e6);
        // A move in the real is not yield: the USDT is all principal, and none of it can leave.
        assertLe(reserve.harvestableYield(), 1, "an FX move is not yield");
        assertEq(reserve.principalUsdt(), MINTED_USDT + 80_000e6, "the principal is what came in");
    }

    /// From the same rest, the real strengthens 10% instead.
    function _realStrengthensTenPercent(uint256 hedgedUsd) internal {
        uint256 supply = movva.totalSupply();
        uint256 fxDown = (FX * 90) / 100;
        _publish(fxDown);
        uint256 down = _ratio("real strengthens 10%: ratio (bps)");
        assertApproxEqAbs(down, 9_720, 1, "1.08 x 0.9");
        vm.prank(gateway);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.CollateralRatioTooLow.selector, down, 10_000));
        reserve.mint(1_000e6, gateway, 0);
        assertEq(reserve.harvestableYield(), 0, "under-backed: no yield leaves");

        // An under-backed redemption: 10% of the supply takes 10% of the reserve.
        uint256 total = reserve.totalUsdt();
        vm.prank(gateway);
        uint256 paid = reserve.redeem(supply / 10, gateway, 0);
        vm.roll(block.number + 1); // one block between a redemption and a mint (N-06)
        (uint256 rate,) = reserve.brlPerUsdtE18();
        console2.log("redeemed 10% of supply for USDT", paid / 1e6);
        console2.log("par would have been USDT", (supply / 10) * 1e6 / rate / 1e6);
        assertApproxEqAbs(paid, total / 10, 2, "pro rata");
        assertLt(paid, ((supply / 10) * 1e6) / rate, "less than par");
        assertApproxEqAbs(_ratio("ratio after the pro-rata redemption (bps)"), down, 1, "stayers unchanged");

        // The short gained in reais; the issuer buys USDT with it and recapitalizes to the target.
        uint256 gainUsdt = ((hedgedUsd * (FX - fxDown) * 1e12) / 1e6) * 1e6 / rate;
        uint256 toTarget = (reserve.liabilitiesUsdt() * 10_800) / 10_000 - reserve.totalUsdt() + 1e6;
        console2.log("hedge gain, in USDT", gainUsdt / 1e6);
        console2.log("USDT to the 108% target", toTarget / 1e6);
        assertGe(gainUsdt, toTarget, "the hedge's gain restores the target");
        vm.prank(issuer);
        reserve.recapitalize(toTarget);
        assertGe(_ratio("after recapitalizing the hedge gain (bps)"), 10_800);
        vm.prank(gateway);
        reserve.mint(1_000e6, gateway, 0);
        vm.roll(block.number + 1); // one block between a mint and a redemption (N-06)
    }

    /**
     * Thirty days of real Aave interest on the vault's allocation becomes surplus once the reserve
     * sits at its 108% target, and stays there: nothing mints it (no savings product, client decision
     * D1). It is backing until Mova harvests it - only to the yield recipient, and only above the
     * principal and the target (the principal-locked reserve). The feed is re-served at the new time
     * (see the header).
     */
    function test_AaveYieldStaysInTheReserveAsSurplus() public {
        if (!live) return;
        _mintAndAllocate();

        // Bring the reserve to exactly its target: the issuer's 8% buffer, allocated to Aave too.
        vm.prank(issuer);
        reserve.recapitalize(80_000e6);
        vm.prank(keeper);
        vault.allocate(adapter, 80_000e6);
        uint256 before = reserve.totalUsdt();
        uint256 supply = movva.totalSupply();
        assertLe(reserve.surplusBrlE18(), 1e18, "at target, nothing to speak of");

        (int256 answer,,) = _answer();
        vm.warp(block.timestamp + 30 days);
        _mockFeed(answer);
        _publish(FX);
        uint256 earned = reserve.totalUsdt() - before;
        console2.log("Aave interest on 980,000 USDT over 30 days (USDT)", earned / 1e6);
        console2.log("  in base units", earned);
        assertGt(earned, 0, "real interest");
        console2.log("surplus above 108% (BRL, whole)", reserve.surplusBrlE18() / 1e18);
        assertGt(reserve.surplusBrlE18(), 0, "the interest is surplus");
        assertEq(movva.totalSupply(), supply, "and nothing minted it");
        assertGt(reserve.collateralRatioBps(), 10_800, "it raised the ratio above target");

        // Harvested, it goes to Mova's yield recipient only, out of Aave through the vault, and leaves
        // the reserve at max(principal, target) - never under it.
        uint256 h = reserve.harvestableYield();
        assertGt(h, 0, "the interest is harvestable");
        vm.prank(makeAddr("anyone"));
        uint256 paid = reserve.harvestYield();
        assertApproxEqAbs(paid, h, 2, "the harvest, less at most the vault's rounding");
        assertEq(IERC20(USDT).balanceOf(yieldTo), paid, "real USDT at the yield recipient");
        assertGe(reserve.totalUsdt(), reserve.principalUsdt(), "never below the principal");
        assertGe(reserve.collateralRatioBps(), 10_800, "never below the target");
    }

    /// A USDT depeg on the feed (mocked: $0.90 now) takes the ratio to 90% with no publisher involved.
    function test_AUsdtDepegReachesTheRatioThroughTheFeed() public {
        if (!live) return;
        _mintAndAllocate();
        (int256 answer,,) = _answer();
        uint256 supply = movva.totalSupply();
        _mockFeed(90_000_000);
        uint256 r = _ratio("USDT at $0.90 (mocked): ratio (bps)");
        assertApproxEqAbs(r, (90_000_000 * 10_000) / uint256(answer), 1);
        (uint256 cents,) = reserve.brlCentsPerUnit();
        console2.log("Movva band on the ramps (centavos)", cents);
        vm.prank(gateway);
        vm.expectRevert();
        reserve.mint(1_000e6, gateway, 0);
        uint256 total = reserve.totalUsdt();
        vm.prank(gateway);
        uint256 paid = reserve.redeem(supply / 4, gateway, 0);
        vm.roll(block.number + 1); // one block between a redemption and a mint (N-06)
        assertApproxEqAbs(paid, total / 4, 2, "a quarter of the supply, a quarter of the USDT");
    }

    /**
     * Tether freezes the reserve (the real owner calls addBlackList). Intake stops; idle USDT stops
     * counting; the vault position, shares not USDT, still pays redemptions straight to the gateway,
     * pro rata to what is payable. Unfrozen, everything counts again.
     */
    function test_TetherFreezingTheReserve() public {
        if (!live) return;
        _mintAndAllocate();
        vm.prank(gov);
        reserve.pullFromVault(50_000e6);
        uint256 supply = movva.totalSupply();

        vm.prank(IUSDT(USDT).owner());
        IUSDT(USDT).addBlackList(address(reserve));
        assertTrue(reserve.frozenByAssetIssuer());
        uint256 payable_ = reserve.totalUsdt();
        assertApproxEqAbs(payable_, 950_000e6, 2, "the 50,000 frozen idle USDT counts for nothing");
        _ratio("frozen: ratio (bps)");

        vm.prank(gateway);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.FrozenByAssetIssuer.selector, address(reserve)));
        reserve.mint(1_000e6, gateway, 0);
        vm.prank(issuer);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.FrozenByAssetIssuer.selector, address(reserve)));
        reserve.recapitalize(1_000e6);

        uint256 gw = IERC20(USDT).balanceOf(gateway);
        vm.prank(gateway);
        uint256 paid = reserve.redeem(supply / 10, gateway, 0);
        vm.roll(block.number + 1); // one block between a redemption and a mint (N-06)
        assertEq(IERC20(USDT).balanceOf(gateway) - gw, paid, "real USDT arrived from the vault");
        assertApproxEqAbs(paid, payable_ / 10, 2, "pro rata to what can be paid");
        assertEq(IERC20(USDT).balanceOf(address(reserve)), 50_000e6, "the frozen USDT did not move");
        console2.log("redeemed while frozen: USDT", paid / 1e6);

        vm.prank(IUSDT(USDT).owner());
        IUSDT(USDT).removeBlackList(address(reserve));
        assertFalse(reserve.frozenByAssetIssuer());
        assertGe(_ratio("unfrozen: ratio (bps)"), 10_000, "the stayers kept the frozen USDT's value");
    }

    /**
     * Borrowers take Aave's USDT down to 250,000 of liquidity. A redemption of the whole supply needs
     * more than the vault can pay now and is refused up front, naming what is available; exactly that
     * much still exits.
     */
    function test_RedemptionBeyondAavesInstantLiquidityRefusesCleanly() public {
        if (!live) return;
        _mintAndAllocate();
        IAavePool aave = IAavePool(AAVE_POOL);
        IAaveAddressesProvider ap = IAaveAddressesProvider(aave.ADDRESSES_PROVIDER());
        (address aclAdmin, IAaveConfigurator configurator) = (ap.getACLAdmin(), IAaveConfigurator(ap.getPoolConfigurator()));
        vm.prank(aclAdmin);
        configurator.setBorrowCap(USDT, 0);
        uint256 debt = aave.getVirtualUnderlyingBalance(USDT) - 250_000e6;
        address borrower = makeAddr("borrower");
        deal(WETH, borrower, 300_000e18);
        vm.startPrank(borrower);
        IERC20(WETH).approve(AAVE_POOL, type(uint256).max);
        aave.supply(WETH, 300_000e18, borrower, 0);
        aave.borrow(USDT, debt, 2, 0, borrower);
        vm.stopPrank();

        uint256 liquid = vault.maxWithdraw(address(reserve));
        console2.log("vault can pay the reserve now (USDT)", liquid / 1e6);
        assertLt(liquid, 400_000e6);
        uint256 supply = movva.totalSupply();
        (uint256 wanted,) = reserve.previewRedeem(supply);
        vm.prank(gateway);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.InsufficientLiquidity.selector, wanted, liquid));
        reserve.redeem(supply, gateway, 0);
        assertEq(movva.totalSupply(), supply, "nothing burned");

        (uint256 rate,) = reserve.brlPerUsdtE18();
        uint256 movvaForLiquid = (liquid * rate) / 1e6;
        vm.prank(gateway);
        uint256 paid = reserve.redeem(movvaForLiquid, gateway, 0);
        vm.roll(block.number + 1); // one block between a redemption and a mint (N-06)
        assertApproxEqAbs(paid, liquid, 1, "what was liquid still exits");
    }
}
