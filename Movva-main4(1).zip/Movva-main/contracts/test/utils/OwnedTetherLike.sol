// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/**
 * The Sepolia stand-in for USDT (v3.1 N-15). TetherToken's behaviour where it matters to the reserve and the escrows -
 * no return values, a sender-only blacklist, a fee switch, a pause, `approve` from non-zero to non-zero reverts - as
 * ERC4626Adapter.t.sol's TetherLike has it, except that the blacklist, the pause and the fee are the OWNER's, as they are
 * Tether's on mainnet. TetherLike left them open to anyone, so any third party could freeze the finalized Sepolia
 * reserve at will. `mint` stays open: it is the testers' faucet. TEST ONLY - never a mainnet asset.
 */
contract OwnedTetherLike {
    string public constant name = "Tether-like USD (Sepolia stand-in)";
    string public constant symbol = "USDT";
    uint8 public constant decimals = 6;

    address public owner;
    uint256 public totalSupply;
    uint256 public basisPointsRate;
    uint256 public maximumFee;
    bool public paused;
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;
    mapping(address => bool) public isBlackListed;

    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);
    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);

    error NotOwner();

    modifier onlyOwner() {
        if (msg.sender != owner) revert NotOwner();
        _;
    }

    constructor(address owner_) {
        owner = owner_;
        emit OwnershipTransferred(address(0), owner_);
    }

    function transferOwnership(address next) external onlyOwner {
        emit OwnershipTransferred(owner, next);
        owner = next;
    }

    function mint(address to, uint256 v) external {
        balanceOf[to] += v;
        totalSupply += v;
        emit Transfer(address(0), to, v);
    }

    function transfer(address to, uint256 v) external {
        require(!paused && !isBlackListed[msg.sender]);
        _move(msg.sender, to, v);
    }

    function transferFrom(address from, address to, uint256 v) external {
        require(!paused && !isBlackListed[from]);
        uint256 a = allowance[from][msg.sender];
        if (a < type(uint256).max) allowance[from][msg.sender] = a - v;
        _move(from, to, v);
    }

    function approve(address spender, uint256 v) external {
        require(!(v != 0 && allowance[msg.sender][spender] != 0));
        allowance[msg.sender][spender] = v;
        emit Approval(msg.sender, spender, v);
    }

    function setParams(uint256 bps, uint256 maxFeeWhole) external onlyOwner {
        require(bps < 20 && maxFeeWhole < 50);
        basisPointsRate = bps;
        maximumFee = maxFeeWhole * 10 ** decimals;
    }

    function addBlackList(address who) external onlyOwner {
        isBlackListed[who] = true;
    }

    function removeBlackList(address who) external onlyOwner {
        isBlackListed[who] = false;
    }

    function setPaused(bool p) external onlyOwner {
        paused = p;
    }

    function _move(address from, address to, uint256 v) internal {
        uint256 fee = (v * basisPointsRate) / 10_000;
        if (fee > maximumFee) fee = maximumFee;
        balanceOf[from] -= v;
        balanceOf[to] += v - fee;
        balanceOf[owner] += fee;
        emit Transfer(from, to, v - fee);
    }
}
