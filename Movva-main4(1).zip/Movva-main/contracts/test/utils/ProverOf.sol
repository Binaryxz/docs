// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @dev Test helper for mock verifiers (v2.0 I-22): the LP of the position the calling escrow is settling, which a
///      real zkTLS verifier returns as `prover` (the session's owner). OffRampEscrow's `sales(id)` has the LP as its
///      8th word; FiatEscrow's `orders(id)` names the offer, whose `offers(offerId)` has the LP first. Zero when the
///      caller is neither, as when a test calls the verifier directly.
library ProverOf {
    function lpOf(address escrow, bytes32 id) internal view returns (address lp) {
        if (escrow.code.length == 0) return address(0);
        (bool ok, bytes memory r) = escrow.staticcall(abi.encodeWithSignature("sales(bytes32)", id));
        if (ok && r.length >= 8 * 32) return address(uint160(_word(r, 7)));
        (ok, r) = escrow.staticcall(abi.encodeWithSignature("orders(bytes32)", id));
        if (!ok || r.length < 32) return address(0);
        bytes32 offerId = bytes32(_word(r, 0));
        (ok, r) = escrow.staticcall(abi.encodeWithSignature("offers(bytes32)", offerId));
        if (!ok || r.length < 32) return address(0);
        return address(uint160(_word(r, 0)));
    }

    function _word(bytes memory r, uint256 i) private pure returns (uint256 w) {
        assembly {
            w := mload(add(r, add(32, mul(i, 32))))
        }
    }
}
