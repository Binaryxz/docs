// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {TimelockController} from "@openzeppelin/contracts/governance/TimelockController.sol";

/**
 * @title EntrypointTimelock
 * @notice The Privacy Pools Entrypoint's OWNER_ROLE holder (client finding H-02, 21 October 2026): OpenZeppelin 5.1.0's
 *         TimelockController, unchanged. This contract adds, removes and overrides nothing; it only names the audited
 *         code inside contracts/, so the deploy record compiles it, compares its runtime code and dry-runs its Etherscan
 *         verification exactly like every other contract the rail deploys (forge cannot build a verification input for
 *         a file under node_modules).
 *
 * As scripts/deploy-movva-rail.ts deploys it:
 *  - minDelay 7 days: every Entrypoint owner action - an upgrade, registering, configuring, winding down or removing a
 *    pool, withdrawing fees, granting or revoking any role - is public for 7 days before it can run;
 *  - proposers = executors = [the 2-of-3 governor Safe]: the Safe alone schedules, cancels (proposers are cancellers)
 *    and executes. The executor is not open (address(0)): anyone executing would choose when a ready operation lands;
 *  - admin = address(0): the timelock administers its own roles, so adding a proposer or shortening the delay is itself
 *    a 7-day operation;
 *  - cancellers = [an independent Safe] (v3.1 N-19): CANCELLER_ROLE only, beside the proposer's own. A compromised
 *    governor Safe can then schedule an upgrade, but no longer be the only one who could cancel it during its 7 days.
 *    The canceller can schedule and execute nothing.
 *
 * The one addition to OpenZeppelin's code is that constructor argument: `_grantRole(CANCELLER_ROLE, ...)` for each,
 * at construction, as the parent does for proposers.
 */
contract EntrypointTimelock is TimelockController {
    error ZeroCanceller();

    constructor(
        uint256 minDelay,
        address[] memory proposers,
        address[] memory executors,
        address admin,
        address[] memory cancellers
    ) TimelockController(minDelay, proposers, executors, admin) {
        for (uint256 i; i < cancellers.length; ++i) {
            if (cancellers[i] == address(0)) revert ZeroCanceller();
            _grantRole(CANCELLER_ROLE, cancellers[i]);
        }
    }
}
