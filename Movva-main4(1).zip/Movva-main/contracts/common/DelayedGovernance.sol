// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/**
 * @title DelayedGovernance
 * @notice One governor, two speeds: changes that add risk wait out a public delay, changes
 *         that remove risk take effect at once.
 *
 * ## Why this exists
 *
 * Before this, a single governor key could steal from every contract that holds value in
 * this repo, in one block, with no warning to anyone:
 *
 *  - on an escrow: allow itself as an arbitrator, lock an order (or claim a sale) as a
 *    counterparty, dispute it, and sign its own RELEASE ruling;
 *  - on a verifier: add itself as an attestor, set the threshold to one, and sign payments
 *    that never happened;
 *  - on the yield vault: list an adapter it wrote, make itself keeper, and allocate.
 *
 * Several comments said these were impossible ("cannot drain an offer"). They were true of
 * each function and false of the combination. A timelock does not make a malicious governor
 * honest; it makes one visible. Every risk-increasing change is scheduled on-chain with its
 * exact calldata, and cannot run until `GOVERNANCE_DELAY` has passed - long enough for LPs
 * to close offers, sellers to cancel sales, and holders to redeem.
 *
 * ## Which changes wait, and which do not
 *
 * The rule each contract applies is: would this change let someone move value, or accept
 * a claim, that they could not before? If so it waits. Adding an arbitrator, verifier,
 * attestor, bank endpoint, adapter or escrow; lowering a threshold; listing an asset or
 * changing its oracle; changing the keeper; raising a cap, a credit limit or a tier; opening
 * a network phase.
 *
 * Revoking, suspending, pausing, delisting and lowering do NOT wait. Incident response
 * must be as fast as the governor can sign, and a delay on the brakes protects no one. Each
 * contract classifies from current state inside the setter itself, so the same function can
 * be instant when it reduces risk and delayed when it adds it, and the classification is
 * re-evaluated when a scheduled change finally executes.
 *
 * ## Setup
 *
 * A freshly deployed contract has to be wired before anyone can use it, and a deploy
 * script cannot wait 48 hours between transactions. So a contract starts in SETUP: every
 * change is instant, and - the part that makes this safe - the contract refuses all user
 * business until `completeSetup()` is called, which is irreversible. Instant power only ever
 * exists while the contract holds nothing and nobody depends on it.
 *
 * Nothing can be SCHEDULED during setup either (M-06). A change scheduled in setup would start
 * its delay before anyone had reason to watch the contract, and could execute the moment setup
 * closed: a deployer could schedule, say, a new arbitrator on day one, wait out the delay while
 * the contract is still being wired, call `completeSetup()`, and execute at once - so the delay
 * would have protected nobody. Every change that waits therefore waits from a moment after
 * `setupComplete()` became true.
 *
 * Before trusting a deployment, check BOTH `setupComplete()` and `pendingChanges() == 0`. The
 * first says instant power is gone; the second that no risk-increasing change is already queued.
 * A scheduled change that lapsed past its EXECUTION_WINDOW still counts until the governor
 * cancels it: it can no longer run, but the counter is kept conservative rather than clever.
 *
 * ## Mechanics
 *
 * `schedule(call)` records `scheduleId(call)` (the call under the current `governanceEpoch`) and emits the full calldata with the time it
 * becomes executable. `execute(call)` runs it on this contract, only between `readyAt` and
 * `readyAt + EXECUTION_WINDOW`; a stale approval expires rather than lingering as a loaded
 * gun. `cancel(call)` is instant. Only selectors a contract declares in `_isDelayable` can
 * be scheduled at all, so the self-call cannot be aimed at user-facing functions. Each
 * `schedule` adds one to `pendingChanges`, each `execute` or `cancel` takes one away.
 *
 * ## Handing over (v2.0 I-36, I-53)
 *
 * Once setup is complete, `transferGovernor(to)` only proposes: nothing changes until `to` calls
 * `acceptGovernor()`, so a mistyped address or a contract that cannot act never becomes the governor
 * and the brakes are never lost to a typo. Rotating a compromised key still needs no delay: the new
 * key accepts in the next block, and another proposal replaces this one until it does. During setup
 * - the deploy script handing a contract that holds nothing to its Safe, which then closes setup -
 * the transfer is instant, as before, so the deployer keeps no power once it has handed over. The new
 * governor inherits the same delays rather than escaping them.
 *
 * A handover also clears the queue. Every schedule id is taken under the current
 * `governanceEpoch`, and accepting bumps it, so a change the previous governor queued can never
 * be executed or need cancelling by the next one, and `pendingChanges` starts again at zero.
 * `renounceGovernor()` burns governance for good in one step (to 0x...dEaD), with the same clear.
 *
 * ## Ossify: brakes only, for good (N-04)
 *
 * `ossify()` is one-way. From then on no risk-increasing change can ever run again - nothing can
 * be scheduled, and every setter that would add risk reverts `Ossified` - while every
 * risk-reducing one stays with the governor: revoking a verifier, an arbitrator, a witness or an
 * endpoint, removing a gateway, pausing, tightening a limit. It is the finalization that keeps
 * incident response: renouncing the governor to 0x...dEaD burns the brakes with the risk. It
 * needs setup complete and nothing queued, so no change scheduled before it can run after it.
 */
abstract contract DelayedGovernance {
    /// @notice No deployment may use a shorter delay than this.
    /// @dev Internal, as is the maximum: nothing reads them, and every inheritor paid for two
    ///      getters - bytes FiatEscrow, at the EIP-170 limit, needed. GOVERNANCE_DELAY is public.
    uint256 internal constant MIN_GOVERNANCE_DELAY = 24 hours;
    /// @notice Nor a longer one: a delay nobody can wait out bricks incident recovery.
    uint256 internal constant MAX_GOVERNANCE_DELAY = 30 days;
    /// @notice A scheduled change must be executed within this long after it becomes ready.
    uint256 public constant EXECUTION_WINDOW = 14 days;

    /// @notice Minimum wait between scheduling a risk-increasing change and executing it.
    uint256 public immutable GOVERNANCE_DELAY;

    address public governor;
    /// @notice False while the contract is being wired; see "Setup" above.
    bool public setupComplete;
    /// @notice True once `ossify()` has run: risk-increasing changes are gone for good.
    bool public ossified;
    /// @notice When each scheduled change becomes executable, by `scheduleId` of its calldata.
    mapping(bytes32 => uint256) public readyAt;

    /// @dev Set only for the duration of `execute`'s self-call.
    bool private _executing;
    /// @notice Changes scheduled and neither executed nor cancelled yet. Zero means nothing risk-
    ///         increasing is queued; see "Setup" above. Packed beside `_executing`, so adding it
    ///         moved no inheritor's storage.
    uint64 public pendingChanges;
    /// @notice Bumped by every handover; every schedule id is taken under it (I-53).
    uint64 public governanceEpoch;
    /// @notice Proposed by `transferGovernor`, governor once it calls `acceptGovernor` (I-36).
    address public pendingGovernor;

    /// @notice Where `renounceGovernor` sends governance: nobody holds its key.
    address internal constant BURN = 0x000000000000000000000000000000000000dEaD;

    event GovernorTransferred(address indexed from, address indexed to);
    event GovernorProposed(address indexed from, address indexed to);
    event SetupCompleted(uint256 governanceDelay);
    event GovernanceOssified();
    event ChangeScheduled(
        bytes32 indexed id, bytes4 indexed selector, bytes call, uint256 readyAt, uint256 expiresAt
    );
    event ChangeCancelled(bytes32 indexed id);
    event ChangeExecuted(bytes32 indexed id, bytes4 indexed selector);

    error NotGovernor();
    error ZeroAddress();
    error BadGovernanceDelay(uint256 delay);
    error SetupIncomplete();
    error SetupAlreadyComplete();
    error ChangeMustBeScheduled(bytes4 selector);
    error NotDelayable(bytes4 selector);
    error AlreadyScheduled(bytes32 id);
    error NotScheduled(bytes32 id);
    error NotReadyYet(bytes32 id, uint256 readyAt);
    error ChangeExpired(bytes32 id);
    error Ossified();
    error ChangesPending(uint64 pending);
    error NotPendingGovernor();

    modifier onlyGovernor() {
        if (msg.sender != governor) revert NotGovernor();
        _;
    }

    constructor(address governor_, uint256 governanceDelay) {
        if (governor_ == address(0)) revert ZeroAddress();
        if (governanceDelay < MIN_GOVERNANCE_DELAY || governanceDelay > MAX_GOVERNANCE_DELAY) {
            revert BadGovernanceDelay(governanceDelay);
        }
        governor = governor_;
        GOVERNANCE_DELAY = governanceDelay;
    }

    /*//////////////////////////////////////////////////////////////
                                LIFECYCLE
    //////////////////////////////////////////////////////////////*/

    /// @notice End setup. From here on, every risk-increasing change waits out the delay.
    function completeSetup() external onlyGovernor {
        if (setupComplete) revert SetupAlreadyComplete();
        setupComplete = true;
        emit SetupCompleted(GOVERNANCE_DELAY);
    }

    /// @notice One-way: no risk-increasing change can ever run again; the instant, risk-reducing
    ///         ones stay with the governor. See "Ossify" above.
    function ossify() external onlyGovernor {
        _requireSetupComplete();
        if (ossified) revert Ossified();
        if (pendingChanges != 0) revert ChangesPending(pendingChanges);
        ossified = true;
        emit GovernanceOssified();
    }

    /// @notice During setup, hand over at once. After it, propose `to` as the next governor; it takes over when
    ///         it calls `acceptGovernor`, and a later proposal replaces this one (I-36).
    function transferGovernor(address to) external onlyGovernor {
        if (to == address(0)) revert ZeroAddress();
        if (!setupComplete) return _handOver(to);
        pendingGovernor = to;
        emit GovernorProposed(governor, to);
    }

    /// @notice The proposed governor takes over. Every change the previous one queued is void.
    function acceptGovernor() external {
        if (msg.sender != pendingGovernor) revert NotPendingGovernor();
        _handOver(msg.sender);
    }

    /// @notice Give governance up for good: to 0x...dEaD, at once, and every queued change void.
    function renounceGovernor() external onlyGovernor {
        _handOver(BURN);
    }

    function _handOver(address to) private {
        emit GovernorTransferred(governor, to);
        governor = to;
        delete pendingGovernor;
        pendingChanges = 0;
        unchecked { ++governanceEpoch; }
    }

    /// @notice The id `schedule`, `cancel` and `execute` use for `call` under the current epoch.
    function scheduleId(bytes calldata call) public view returns (bytes32) {
        return keccak256(abi.encode(governanceEpoch, call));
    }

    /*//////////////////////////////////////////////////////////////
                         SCHEDULE / EXECUTE / CANCEL
    //////////////////////////////////////////////////////////////*/

    /// @param call ABI-encoded call to one of this contract's delayable governance functions.
    /// @dev Refused while setup is open: see "Setup" above (M-06).
    function schedule(bytes calldata call) external onlyGovernor returns (bytes32 id) {
        _requireSetupComplete();
        if (ossified) revert Ossified();
        bytes4 selector = _selectorOf(call);
        id = scheduleId(call);
        if (readyAt[id] != 0) revert AlreadyScheduled(id);
        uint256 ready = block.timestamp + GOVERNANCE_DELAY;
        readyAt[id] = ready;
        unchecked { ++pendingChanges; } // one per schedule: 2^64 schedules is not a concern
        emit ChangeScheduled(id, selector, call, ready, ready + EXECUTION_WINDOW);
    }

    function cancel(bytes calldata call) external onlyGovernor {
        bytes32 id = scheduleId(call);
        if (readyAt[id] == 0) revert NotScheduled(id);
        delete readyAt[id];
        unchecked { --pendingChanges; } // readyAt[id] != 0, so its schedule counted it
        emit ChangeCancelled(id);
    }

    /**
     * @notice Run a scheduled change once its delay has passed.
     * @dev Governor-only, so a scheduled change is an option the governor may decline, not
     *      an obligation anyone can trigger. The call runs as this contract calling itself;
     *      the setter sees `msg.sender == address(this)` during `_executing`, which is what
     *      `_authorizeChange` accepts in place of the delay check.
     */
    function execute(bytes calldata call) external onlyGovernor returns (bytes memory result) {
        bytes4 selector = _selectorOf(call);
        bytes32 id = scheduleId(call);
        uint256 ready = readyAt[id];
        if (ready == 0) revert NotScheduled(id);
        if (block.timestamp < ready) revert NotReadyYet(id, ready);
        if (block.timestamp > ready + EXECUTION_WINDOW) revert ChangeExpired(id);
        delete readyAt[id];
        unchecked { --pendingChanges; } // readyAt[id] != 0, so its schedule counted it

        _executing = true;
        bool ok;
        (ok, result) = address(this).call(call);
        _executing = false;
        if (!ok) {
            // Bubble the setter's own error, so a failed execution says why.
            assembly {
                revert(add(result, 32), mload(result))
            }
        }
        emit ChangeExecuted(id, selector);
    }

    /*//////////////////////////////////////////////////////////////
                             FOR INHERITORS
    //////////////////////////////////////////////////////////////*/

    /**
     * @dev Call first in every governance setter, having classified the change from
     *      current state. Risk-reducing changes need only the governor. Risk-increasing
     *      ones need the governor during setup, or must arrive through `execute`.
     */
    function _authorizeChange(bool riskIncreasing) internal view {
        if (_executing && msg.sender == address(this)) return;
        if (msg.sender != governor) revert NotGovernor();
        if (riskIncreasing && setupComplete) {
            if (ossified) revert Ossified();
            revert ChangeMustBeScheduled(msg.sig);
        }
    }

    /// @dev Call at the top of every user-facing entry point that takes on value or trust.
    function _requireSetupComplete() internal view {
        if (!setupComplete) revert SetupIncomplete();
    }

    /// @dev The governance functions `schedule` may target. Nothing else can be self-called.
    function _isDelayable(bytes4 selector) internal pure virtual returns (bool);

    function _selectorOf(bytes calldata call) private pure returns (bytes4 selector) {
        if (call.length < 4) revert NotDelayable(bytes4(0));
        selector = bytes4(call[:4]);
        if (!_isDelayable(selector)) revert NotDelayable(selector);
    }
}
