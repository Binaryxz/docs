// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {IERC20Metadata} from "@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol";
import {IERC4626} from "@openzeppelin/contracts/interfaces/IERC4626.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {Math} from "@openzeppelin/contracts/utils/math/Math.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {IMovvaReserve} from "./IMovvaReserve.sol";
import {Movva} from "./Movva.sol";
import {IPriceOracle} from "../ramp/IPriceOracle.sol";
import {BandRead} from "../ramp/IBandPriceOracle.sol";
import {IAggregatorV3} from "../ramp/ChainlinkBrlOracle.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";
import {IssuerFreeze} from "../common/IssuerFreeze.sol";
import {IDivergenceBreaker} from "./IPriceSource.sol";

/**
 * @title MovvaReserve
 * @notice The USDT reserve behind Movva, the backstop rules around it, and Movva's band oracle on
 *         the ramps. Design: docs/movva.md. Threat model: docs/security-review-movva.md.
 *
 * ## What it holds, and how it counts
 *
 * USDT, idle and in one ERC-4626 `YieldVault(USDT)`. Liabilities are every Movva in circulation
 * (1e18 = R$ 1,00), wherever it sits: wallets, Privacy Pools, escrows. The rate is
 * Chainlink USDT/USD times a BRL/USD rate - Pyth's FX.USD/BRL through PythFxOracle, or a signed
 * quorum's (`brlPerUsdtE18`) - and
 *
 *     collateralRatioBps = totalUsdt x rate / totalSupply
 *
 * is computed on every call, from state and fresh oracle legs, never cached. Every division rounds
 * against the reserve: the vault position at `previewRedeem` (what an exit would actually pay),
 * reais rounded down, the ratio rounded down, liabilities never discounted. Idle USDT counts as
 * zero while Tether has frozen the reserve, because it cannot be paid to anyone - see "Freezes".
 *
 * ## The rules (docs/movva.md, "The backstop, on-chain")
 *
 *  - **Mint** (gateways only): USDT in, less `mintFeeBps` of it paid in USDT to the fee recipient,
 *    and Movva out at the rate for the rest, only while the ratio is at least
 *    `minMintCollateralRatioBps`, within `supplyCap`. Movva is minted for the USDT value the reserve
 *    actually booked after depositing it - so a vault's rounding is charged to the minter, not to
 *    holders. The USDT after the fee is principal.
 *  - **Redeem** (gateways only): Movva in and burned, USDT out worth `min(1, ratio)` of it, less
 *    `redeemFeeBps` of that USDT, paid to the fee recipient. Under-backed, that is exactly the
 *    redeemer's pro-rata share of the reserve, whatever the rate says: a run pays everybody the same
 *    fraction.
 *  - **recapitalize** (anyone): USDT in, nothing out. The USDT is principal.
 *  - **harvestYield** (anyone): only the USDT above the principal AND above what the liabilities need
 *    at the target ratio, only to the fixed `yieldRecipient`.
 *
 * ## The principal-locked reserve (client rule, 21 October 2026)
 *
 * The USDT backing can never be withdrawn or transferred by anyone - not the governor, the guardian,
 * a Safe or any other role. It leaves in exactly one way: a redemption, which burns Movva for USDT,
 * and which is the off-ramp's settlement path (a user sells Movva for reais on the off-ramp; the LP
 * that paid the reais is a gateway and redeems that Movva here).
 *
 *  - **Who redeems.** `redeem` is gateway-only, as `mint` is: a gateway is a contracted institutional
 *    LP, admitted by the governor through the delay and removable at once. The rule needs nothing of
 *    the escrows: OffRampEscrow pays the Movva to the LP, and the LP, not the escrow, redeems it.
 *  - **Principal** (`principalUsdt`) is a cost basis: every USDT the reserve took in through `mint`
 *    and `recapitalize`, less every USDT it paid out through `redeem` (never below zero).
 *  - **Invested.** The principal sits in one ERC-4626 vault the client chooses (`yieldVault`): a new
 *    vault waits the delay, and the reserve can only leave one once it has redeemed every share back
 *    to itself (`pullFromVault`), so moving funds between the reserve and a vault never pays anyone.
 *  - **Only the yield leaves, only to Mova.** `harvestYield` sends to `yieldRecipient` - Mova's Safe,
 *    set at deploy, changed only through the delay in either direction -
 *
 *        harvestableYield = totalUsdt - max(principalUsdt, ceil(liabilitiesUsdt x target / 100%))
 *
 *    so yield never leaves while holders are under-backed or the reserve is below its target ratio,
 *    and never out of the principal. It pulls from the vault as needed, into the reserve first.
 *
 * There is no other exit: no hedge withdrawal, no sweep, no rescue, no arbitrary transfer. The
 * delta-neutral sleeve (HedgeSubWallet) and any hedge margin are funded by Mova's own capital through
 * its hedge Safe, never from here; gains Mova chooses to add come in by `recapitalize`, as principal.
 * No holder is paid a yield (client decision D1, 14 October 2026: savings and sMovva are not part of
 * the product).
 *
 * The rule is about who can take USDT out, not about what the USDT is exposed to. While it sits in the
 * vault it is exposed to that vault: a vault that loses value or refuses withdrawals loses principal
 * (see "The vault" below). Fees are USDT, taken from the trade that pays them and never part of the
 * principal (v3.1 N-27): a mint's fee leaves before its USDT is booked, a redemption's leaves out of
 * the redeemer's own payout, so fees are no claim on anyone else's backing. A fee the fee recipient
 * cannot receive (frozen, or the USDT is in the vault) stays here as backing, and the trade goes on.
 *
 * ## The end of the system's life (v3.1 N-25)
 *
 * Principal can outlive every holder: when BRL weakens, redeeming all Movva at par pays less than the
 * principal, and the rest backs nobody. Once no Movva has been in circulation for SUNSET_DELAY (a
 * year, immutable) after a redemption took it to zero, anyone may `sweepSunset`: every USDT the
 * reserve can pay goes to `yieldRecipient`. A single mint stops the clock, so while anyone holds
 * Movva, or has in the last year, the principal stays locked.
 *
 * ## The vault (v3.1 N-03, N-09, N-26)
 *
 *  - **An allocation cap.** At most `MAX_VAULT_BPS` (immutable) of the reserve's USDT is ever put in the
 *    vault; the rest stays idle, payable to redeemers whatever the vault does.
 *  - **A pull that survives finalization.** The guardian, as well as the governor, may bring USDT back
 *    from the vault into this contract (`pullFromVault`) and stop new deposits. Neither can send USDT
 *    anywhere else, so neither is a power over funds. Finalization keeps the guardian (see the deploy
 *    script's ossify mode), so a failing vault can always be left.
 *  - **Valued at what it can pay now.** The floor `mint` checks and the harvest are judged on
 *    `idle + min(previewRedeem, maxWithdraw)`: a vault frozen by Tether or illiquid counts at what it
 *    can actually pay. Redemptions keep the vault's book value, so a temporary illiquidity makes one
 *    wait (InsufficientLiquidity) rather than pay it a haircut.
 *  - **Only the vault's gain is yield.** `harvestYield` pays at most the vault position's gain over its
 *    cost (`vaultCostUsdt`), and only out of what it withdrew from the vault in the same call. Idle USDT
 *    never pays a harvest: USDT sent here by plain transfer stays as backing for holders.
 *
 * ## The keyless exit (v3.1 N-01, N-02)
 *
 * Finalization removes the keys that could replace a dead oracle leg or a lost gateway. So a holder
 * can always get out, with no key at all, through `exitRedeem` - open to anyone, when either:
 *
 *  - **the gateways have gone quiet**: no gateway has minted, redeemed or called `gatewayHeartbeat` for
 *    `GATEWAY_EXIT_DELAY`. A working gateway heartbeats, so in normal operation this never opens. It is
 *    priced exactly as `redeem` is, at a fresh rate; or
 *  - **the rate has been unreadable for `ORACLE_EXIT_DELAY`**: someone called `pokeRate` while the rate
 *    was unreadable, and nothing has read it successfully since. It then pays `min(par at the last rate
 *    the reserve read, pro rata)` - pro rata alone if it never read one. Longer than any market
 *    closure, so a weekend never opens it.
 *
 * The fee is `redeemFeeBps`, as for `redeem`. Pro rata caps every exit, so an exit can never pay one
 * holder at the expense of the others. A gateway can remove itself (`renounceGateway`); the optional
 * `gatewayCouncil` can add one after the governance delay and remove one at once, and survives
 * finalization (it is zero, none, unless the deployment sets one).
 *
 * ## Trading at the freshest price (v3.1 N-06)
 *
 * A Pyth FX leg is a pull oracle: the caller chooses which signed publication to put on-chain. So
 * `mint` and `redeem` take an FX price no older than `TRADE_FX_MAX_AGE` (immutable, minutes) rather
 * than `fxMaxAge`, and a gateway's trade in the other direction from its last one waits
 * `TRADE_FX_MAX_AGE` as well (and never shares a block with it): its price is then from a publication
 * made after the first trade. With a push leg
 * (Chainlink, whose answer no caller picks) `TRADE_FX_MAX_AGE` is zero and `fxMaxAge` alone applies. A gateway can then choose only
 * between publications minutes apart, against a round trip that costs at least `MIN_ROUND_TRIP_FEE_BPS`
 * (immutable: `setFees` refuses anything below it). Views, the band and `harvestYield` keep `fxMaxAge`.
 *
 * ## The divergence breaker (client decision, 24 September 2026)
 *
 * `BREAKER` (immutable, optional) is a keyless, ownerless DivergenceBreaker. While the rate above disagrees with its
 * independent sources beyond a deploy-time band - or a source reverts, is stale or too thin - `mint`, `redeem` and
 * `harvestYield` revert. It is recomputed on every call and clears by
 * itself when the sources agree; no function lifts it and no role can trip it. `recapitalize`, the previews and the
 * ramps' band reading are not halted. The breaker is not a key (see "Who can stop a redemption" below); its
 * `HALTS_REDEEM` immutable can leave redemptions open, and a source dead for its `DEAD_AFTER` stops counting for
 * redemptions, so a retired source can never lock exits for good (SRM1-7). Mint and harvests still halt
 * on it. The cost, a manipulable TWAP as a halt switch, is in docs/movva.md ("The divergence breaker").
 *
 * Slippage bounds on mint and redeem protect a gateway from a rate that moves between signing and
 * inclusion; a redemption's bound is checked against what the recipient actually received. Fees are
 * set at deployment, never below `MIN_ROUND_TRIP_FEE_BPS` together, with hard caps no governance can pass.
 *
 * ## What no role can do
 *
 * USDT leaves this contract to exactly three places: a redeemer's chosen recipient (a gateway's, or
 * any holder's through the keyless exit), the yield vault (governor-chosen, delayed; at most
 * `MAX_VAULT_BPS`; its shares are only ever redeemed back to this contract or straight to one of the
 * other two payees), and - only above the floor above, only out of the vault's gain - the yield
 * recipient (delayed). There is no sweep, no rescue and no arbitrary transfer, of USDT or of vault shares.
 * Movva is minted only by `mint` (to the gateway's recipient, and its fee to the fee recipient), and
 * burned only by `redeem`, from the reserve's own balance.
 *
 * ## Governance (DelayedGovernance)
 *
 * Delayed, because each one adds risk: adding a gateway; raising the supply cap or any fee; LOWERING
 * any collateral ratio (a floor protects by being high); changing the fee recipient, an oracle leg, a
 * max age upward, or the yield vault; changing the yield recipient, in either direction.
 *
 * Instant, because each one removes risk: removing a gateway; lowering the cap or a fee (never below
 * the round-trip floor); raising a ratio; tightening a max age (never below its floor); pausing mint;
 * pulling USDT out of the yield vault into the reserve, and pausing deposits into it (the guardian may
 * do these three too - they are its only powers); rotating the guardian.
 *
 * After `ossify()` (DelayedGovernance) only the instant list remains, for good.
 *
 * Resuming mint is instant and governor-only, as resuming deposits is on `YieldVault`: it moves no
 * value, and the rules above still apply to every mint.
 *
 * ## Who can stop a redemption (SRM1-20)
 *
 * There is no pause for redemptions: a frozen exit is how a reserve turns a scare into a run. The
 * guardian can never stop one. Precisely:
 *
 *  - **Before finalize, the governor can, instantly**, by removing every gateway: removing one is
 *    instant because that is how a compromised gateway is cut off, and adding one back waits the
 *    delay. Max ages cannot be tightened below `MIN_USDT_USD_MAX_AGE` (a day, the Chainlink USDT/USD
 *    heartbeat) and `MIN_FX_MAX_AGE` (15 minutes; anyone may post a Pyth price), so tightening one no
 *    longer freezes redemptions; a 1-second max age is refused. Repointing a leg waits the delay.
 *    The FX leg's own contract (PythFxOracle) has a governor of its own, with instant tightening.
 *  - **After finalize** no key can stop a redemption for good. Ossified, the governor can still remove
 *    gateways - and then the keyless exit opens after `GATEWAY_EXIT_DELAY`. What still can, with no key:
 *    the breaker (above), a leg that is stale or out of its bounds - until the keyless exit opens after
 *    `ORACLE_EXIT_DELAY` - the asset issuer freezing the reserve's idle USDT, the gateway or the
 *    recipient, and the yield vault's liquidity.
 *
 * ## Oracle
 *
 * The two legs are read exactly as `ChainlinkSignedFxOracle` reads them - each against its own max
 * age (USDT/USD about a day, since the feed's heartbeat is a day; FX about an hour), zero and
 * negative answers refused, timestamps from the future refused - and a stale leg reverts every
 * action that prices anything. `updatedAt` is the FX leg's time, for the reason that contract
 * gives: the escrows allow a band an hour, and the Chainlink leg is judged here against its own clock.
 *
 * The USDT/USD leg must lie between US$ 0.50 and US$ 1.50 (`MIN_USDT_USD_BPS`, `MAX_USDT_USD_BPS`).
 * That catches a feed that is not a dollar stablecoin's - ETH/USD, BRL/USD, an inverted pair - and
 * nothing a stablecoin does short of collapse: the deepest depegs of USDT (about 0.85) and USDC
 * (about 0.87) stay inside and are priced as reported. Below half a dollar every action that prices
 * anything reverts `UsdtUsdOutOfRange`, redemptions included, until the feed is back inside.
 *
 * The FX leg must also lie between R$ 1 and R$ 100 per dollar. That is not a view about the real;
 * it catches the unit mistake this design invites. The ramps' FX instance is signed in centavos
 * (540), this one in millionths (5_400_000). Pointed at the wrong one, or signed in the wrong unit,
 * the rate would be off by 10^4 and every mint priced from it would be a gift: the bound makes it
 * revert instead.
 *
 * A wrong rate inside the bounds is the residual oracle risk, and the reason only contracted
 * gateways mint and redeem (docs/movva.md, "Why LPs mint"): a high rate over-mints, a low rate
 * over-pays redemptions - though never beyond the redeemer's pro-rata share of the whole reserve.
 *
 * ## Off-hours
 *
 * Pyth's FX.USD/BRL trades weekdays 08:00-17:00 New York time (FxMarketHours); PIX never closes. Mova
 * decided (14 September 2026) that trading continues and value creation waits:
 *
 *  - Everything that moves value - `mint`, `redeem`, `harvestYield`, and the ratios
 *    and previews that price them - reads the FX leg's RATE (`brlPerUsdtE18`) and refuses once it is
 *    older than `fxMaxAge`. While the market is closed, minting and redeeming wait for it to reopen.
 *  - The ramps' band, `brlCentsPerUnit`, reads the FX leg as a band does (BandRead): while the market
 *    is closed, at its last close, stamped current. So Movva's price check keeps working off-hours and
 *    LPs keep selling the Movva they hold. `bandBrlPerUsdtE18` exposes that reading to off-chain readers.
 *
 * A leg with no band reading (a SignedPriceOracle) is read the same way on both paths.
 *
 * ## Freezes
 *
 * Tether can freeze this contract. A frozen address can still receive USDT, so intake - mint and
 * recapitalize - is refused while frozen: it would only grow the frozen pile. Frozen idle USDT
 * counts for nothing, but the yield-vault position is shares, not USDT, and the vault can still pay
 * out of it: redemptions are paid straight from the vault to the recipient, pro rata to what is
 * actually payable. Nobody is paid into a frozen address. Harvests wait while the reserve is frozen:
 * they pull through the reserve, which would turn a payable vault position into frozen idle USDT.
 */
contract MovvaReserve is IMovvaReserve, IPriceOracle, DelayedGovernance, ReentrancyGuard {
    using SafeERC20 for IERC20;

    /// @dev Grouped to keep the constructor under the stack limit.
    struct Config {
        address usdt;
        address usdtUsdFeed;
        address fxOracle;
        uint64 usdtUsdMaxAge;
        uint64 fxMaxAge;
        address governor;
        uint256 governanceDelay;
        address guardian;
        address feeRecipient;
        /// @dev Mova's Safe: the only address `harvestYield` pays.
        address yieldRecipient;
        uint256 supplyCap;
        /// @dev The self-clearing DivergenceBreaker; zero for none (no breaker at all).
        address breaker;
        /// @dev Most of the reserve's USDT the vault may ever hold, in bps (N-03).
        uint16 maxVaultBps;
        /// @dev Initial fees, and the least they may ever add up to (N-06, L-20).
        uint16 mintFeeBps;
        uint16 redeemFeeBps;
        uint16 minRoundTripFeeBps;
        /// @dev The FX leg's oldest price a mint or redemption takes (N-06). Zero for a push leg
        ///      (Chainlink), where the caller cannot choose the price: `fxMaxAge` alone then applies.
        uint64 tradeFxMaxAge;
        /// @dev How long the rate must be unreadable, or the gateways quiet, before the keyless exit opens.
        uint64 oracleExitDelay;
        uint64 gatewayExitDelay;
        /// @dev May add a gateway after the governance delay and remove one at once; zero for none.
        address gatewayCouncil;
    }

    uint16 public constant BPS = 10_000;
    /// @notice Hard caps no governance can pass (docs/movva.md, "Still to decide").
    uint16 public constant MAX_MINT_FEE_BPS = 100;
    uint16 public constant MAX_REDEEM_FEE_BPS = 100;
    /// @notice The signed FX leg must read between R$ 1 and R$ 100 per US dollar, at 1e-6.
    uint256 public constant MIN_BRL_PER_USD_E6 = 1e6;
    uint256 public constant MAX_BRL_PER_USD_E6 = 100e6;
    /// @notice The USDT/USD leg must read between US$ 0.50 and US$ 1.50, in basis points of a dollar.
    uint256 public constant MIN_USDT_USD_BPS = 5_000;
    uint256 public constant MAX_USDT_USD_BPS = 15_000;
    /// @notice A leg's timestamp may be this far ahead of the chain, and no further.
    uint64 public constant MAX_FUTURE_SKEW = 5 minutes;
    /// @notice The tightest max ages governance may set (SRM1-20): tighter would make a healthy leg read
    ///         stale, which is a freeze of every redemption, and tightening is instant.
    uint64 public constant MIN_USDT_USD_MAX_AGE = 1 days;
    uint64 public constant MIN_FX_MAX_AGE = 15 minutes;
    /// @notice Bounds on the keyless exit's delays: longer than any market closure, short enough to matter.
    uint64 public constant MIN_EXIT_DELAY = 5 days;
    uint64 public constant MAX_EXIT_DELAY = 180 days;
    /// @notice Bounds on `TRADE_FX_MAX_AGE`: a Pyth update every block is not required, an hour is too long.
    uint64 public constant MIN_TRADE_FX_MAX_AGE = 30 seconds;
    uint64 public constant MAX_TRADE_FX_MAX_AGE = 15 minutes;
    /// @notice How long no Movva must have circulated before `sweepSunset` (N-25).
    uint64 public constant SUNSET_DELAY = 365 days;

    address public immutable MOVVA;
    address public immutable USDT;
    /// @notice Keyless, self-clearing halt while independent price sources disagree. Zero: none.
    IDivergenceBreaker public immutable BREAKER;
    /// @notice See "The vault" in the header.
    uint16 public immutable MAX_VAULT_BPS;
    /// @notice `setFees` refuses a mint fee and a redeem fee that add up to less (N-06, L-20).
    uint16 public immutable MIN_ROUND_TRIP_FEE_BPS;
    /// @notice See "Trading at the freshest price" in the header. Zero: a push leg, `fxMaxAge` alone.
    uint64 public immutable TRADE_FX_MAX_AGE;
    /// @notice See "The keyless exit" in the header.
    uint64 public immutable ORACLE_EXIT_DELAY;
    uint64 public immutable GATEWAY_EXIT_DELAY;

    address public guardian;
    /// @notice Receives mint and redeem fees, as Movva.
    address public feeRecipient;
    /// @notice Mova's Safe: the only address `harvestYield` pays. Changed only through the delay.
    address public yieldRecipient;
    /// @notice The reserve's cost basis in USDT: in through `mint` and `recapitalize`, less out through
    ///         `redeem`, never below zero. `harvestYield` never takes the reserve below it.
    uint256 public principalUsdt;

    /// @notice Chainlink USDT/USD.
    IAggregatorV3 public usdtUsdFeed;
    /// @notice BRL per ONE US dollar, scaled 1e6: a PythFxOracle, or a SignedPriceOracle signed in that unit.
    IPriceOracle public fxOracle;
    uint64 public usdtUsdMaxAge;
    uint64 public fxMaxAge;

    /// @notice YieldVault(USDT); zero for none.
    IERC4626 public yieldVault;
    /// @notice True stops the reserve putting USDT into the vault; exits from it are unaffected.
    bool public vaultDepositsPaused;
    bool public mintPaused;

    mapping(address => bool) public isGateway;

    /// @notice The last rate a value-moving call or `pokeRate` read, when, and since when `pokeRate` has
    ///         found it unreadable (zero: readable at the last look). One slot.
    uint128 public lastGoodRate;
    uint64 public lastGoodRateAt;
    uint64 public rateStaleSince;
    /// @notice The last mint, redemption or heartbeat by a gateway.
    uint64 public lastGatewayActivityAt;
    /// @notice Since when no Movva has circulated, set when a redemption leaves none and cleared by a
    ///         mint; zero otherwise. See "The end of the system's life" (N-25).
    uint64 public zeroSupplySince;
    /// @notice See "The keyless exit" in the header. Zero: none.
    address public gatewayCouncil;
    /// @notice When the council may add each proposed gateway (zero: not proposed).
    mapping(address => uint256) public gatewayReadyAt;
    /// @notice What the reserve put into the vault, less what came back for redemptions and pulls.
    ///         The vault's value above it is the only harvestable yield.
    uint256 public vaultCostUsdt;
    /// @dev Per gateway, its last trade: bit 0 is 1 for a redemption, bits 1-64 the block, 65-128 the time.
    mapping(address => uint256) private _lastTrade;

    /// @notice Most Movva that may exist, in base units (1e18 = R$ 1,00).
    uint256 public supplyCap;

    uint16 public mintFeeBps;
    uint16 public redeemFeeBps;
    // Sized with packages/movva's shock tool (docs/movva.md, "Sizing the buffer"): yield is harvested
    // only above the target, and minting stops at 100%.
    uint16 public targetCollateralRatioBps = 10_800;
    uint16 public minMintCollateralRatioBps = 10_000;

    event GatewaySet(address indexed gateway, bool allowed);
    event RoleSet(string role, address indexed account);
    event FeesSet(uint16 mintFeeBps, uint16 redeemFeeBps);
    event CollateralRatiosSet(uint16 target, uint16 minMint);
    event SupplyCapSet(uint256 supplyCap);
    event OracleSet(address usdtUsdFeed, address fxOracle, uint64 usdtUsdMaxAge, uint64 fxMaxAge);
    event YieldVaultSet(address indexed vault);
    event MintPaused(address indexed by);
    event MintResumed();
    event VaultDepositsPausedSet(bool paused);
    event PulledFromVault(uint256 requested, uint256 received);
    event ExitRedeemed(address indexed holder, address indexed to, uint256 movvaIn, uint256 usdtOut, uint256 brlPerUsdtE18);
    event RateStale(uint256 since);
    event RateRecovered(uint256 rate);
    event GatewayHeartbeat(address indexed gateway);
    event GatewayProposed(address indexed gateway, uint256 readyAt);
    /// @notice The vault refused a deposit its own `maxDeposit` allowed; the USDT stays idle.
    event VaultDepositFailed(uint256 usdt);
    /// @notice A USDT fee the fee recipient could not receive: it stays here as backing (N-27).
    event FeeKept(uint256 usdt);
    event SunsetSwept(address indexed to, uint256 usdt);

    error NotGateway();
    error NotGuardianOrGovernor();
    error ZeroAmount();
    error NotSunset();
    error MintIsPaused();
    error BadPrice(address leg, int256 answer);
    error FxOutOfRange(uint256 brlPerUsdE6);
    error UsdtUsdOutOfRange(int256 answer);
    error StaleLeg(address leg, uint256 updatedAt);
    error LegFromFuture(address leg, uint256 updatedAt);
    error FeedDecimalsOutOfRange(address feed, uint8 decimals);
    error PriceRoundsToZero();
    error BadMaxAge();
    error CollateralRatioTooLow(uint256 ratioBps, uint256 minimumBps);
    error RatiosOutOfOrder();
    error SupplyCapExceeded(uint256 supply, uint256 cap);
    error Slippage(uint256 out, uint256 minOut);
    error InsufficientLiquidity(uint256 wanted, uint256 available);
    error TransferFeeCharged(uint256 amount, uint256 received);
    error FrozenByAssetIssuer(address who);
    error FeeTooHigh();
    error BadBps();
    error AssetMismatch();
    error VaultNotEmpty();
    error NoVault();
    error NothingToHarvest();
    error BadYieldRecipient();
    error ExitClosed();
    error BadRecipient();
    error RoundTripTooSoon(uint256 allowedAt);
    error ReentrantRead();
    error ReadOutOfGas();
    error NotCouncil();
    error BadConfig();

    modifier onlyGateway() {
        if (!isGateway[msg.sender]) revert NotGateway();
        _;
    }

    /// @dev On every view that reads balances or supply: mid-call they are half-updated (N-30).
    modifier settled() {
        if (_reentrancyGuardEntered()) revert ReentrantRead();
        _;
    }

    /**
     * @dev Deploys Movva, so the token's minter is this contract from the token's first block (see
     *      Movva's header). Ratios, fees and limits start at the doc's proposed defaults; the deploy
     *      script overrides them, and adds gateways and the vault, during setup.
     */
    constructor(Config memory c) DelayedGovernance(c.governor, c.governanceDelay) {
        if (c.usdt == address(0) || c.guardian == address(0) || c.feeRecipient == address(0)) revert ZeroAddress();
        // Every amount here is USDT at 6 decimals; an 18-decimal stablecoin would mint 1e12 too much (N-38).
        if (IERC20Metadata(c.usdt).decimals() != 6) revert AssetMismatch();
        if (
            c.maxVaultBps > BPS || c.minRoundTripFeeBps > MAX_MINT_FEE_BPS + MAX_REDEEM_FEE_BPS
                || (c.tradeFxMaxAge != 0 && (c.tradeFxMaxAge < MIN_TRADE_FX_MAX_AGE || c.tradeFxMaxAge > MAX_TRADE_FX_MAX_AGE))
                || c.oracleExitDelay < MIN_EXIT_DELAY || c.oracleExitDelay > MAX_EXIT_DELAY
                || c.gatewayExitDelay < MIN_EXIT_DELAY || c.gatewayExitDelay > MAX_EXIT_DELAY
        ) revert BadConfig();
        USDT = c.usdt;
        MOVVA = address(new Movva());
        guardian = c.guardian;
        feeRecipient = c.feeRecipient;
        _setYieldRecipient(c.yieldRecipient);
        supplyCap = c.supplyCap;
        BREAKER = IDivergenceBreaker(c.breaker);
        MAX_VAULT_BPS = c.maxVaultBps;
        MIN_ROUND_TRIP_FEE_BPS = c.minRoundTripFeeBps;
        TRADE_FX_MAX_AGE = c.tradeFxMaxAge;
        ORACLE_EXIT_DELAY = c.oracleExitDelay;
        GATEWAY_EXIT_DELAY = c.gatewayExitDelay;
        gatewayCouncil = c.gatewayCouncil;
        lastGatewayActivityAt = uint64(block.timestamp);
        _setFees(c.mintFeeBps, c.redeemFeeBps);
        _setOracle(c.usdtUsdFeed, c.fxOracle, c.usdtUsdMaxAge, c.fxMaxAge);
    }

    /*//////////////////////////////////////////////////////////////
                         DIVERGENCE BREAKER (VIEW)
    //////////////////////////////////////////////////////////////*/

    /// @notice True while the breaker halts mint, redeem and harvests. Never
    ///         latches: it is recomputed from the sources' current answers on every call.
    function breakerTripped() external view returns (bool) {
        if (address(BREAKER) == address(0)) return false;
        (uint256 rate,) = _rate(false);
        return !BREAKER.inBand(rate);
    }

    /*//////////////////////////////////////////////////////////////
                                  RATE
    //////////////////////////////////////////////////////////////*/

    /// @inheritdoc IMovvaReserve
    /// @dev `updatedAt` is the FX leg's publish time; the Chainlink leg has been checked against
    ///      `usdtUsdMaxAge` before this returns. Everything that moves value prices at this.
    function brlPerUsdtE18() public view returns (uint256 rate, uint64 updatedAt) {
        return _rate(false);
    }

    /// @inheritdoc IMovvaReserve
    /// @dev For the band and for off-chain readers only: see "Off-hours" in the header.
    function bandBrlPerUsdtE18() external view returns (uint256 rate, uint64 updatedAt) {
        return _rate(true);
    }

    /// @dev The two legs, crossed. With `band`, the FX leg is read as a band reads it (BandRead): at its
    ///      last close while its market is closed, stamped current. Every other check is the same.
    function _rate(bool band) internal view returns (uint256 rate, uint64 updatedAt) {
        IAggregatorV3 feed = usdtUsdFeed;
        // Freshness is judged by updatedAt alone, as in ChainlinkSignedFxOracle.
        // slither-disable-next-line unused-return
        (, int256 answer,, uint256 at,) = feed.latestRoundData();
        if (answer <= 0) revert BadPrice(address(feed), answer);
        if (at == 0 || block.timestamp > at + usdtUsdMaxAge) revert StaleLeg(address(feed), at);
        if (at > block.timestamp + MAX_FUTURE_SKEW) revert LegFromFuture(address(feed), at);
        uint8 dec = feed.decimals();
        if (dec > 18) revert FeedDecimalsOutOfRange(address(feed), dec);
        // A dollar stablecoin's own sanity bound, as the FX leg has one: see "Oracle" in the header.
        // The first test keeps the products below from overflowing.
        uint256 one = 10 ** dec;
        uint256 usd = uint256(answer);
        if (usd > 2 * one || usd * BPS < one * MIN_USDT_USD_BPS || usd * BPS > one * MAX_USDT_USD_BPS) {
            revert UsdtUsdOutOfRange(answer);
        }

        IPriceOracle fx = fxOracle;
        uint256 brlPerUsdE6;
        // Either reading reverts before the leg has a price, and while its setup is open.
        (brlPerUsdE6, updatedAt) = band ? BandRead.read(fx) : fx.brlCentsPerUnit();
        if (brlPerUsdE6 < MIN_BRL_PER_USD_E6 || brlPerUsdE6 > MAX_BRL_PER_USD_E6) revert FxOutOfRange(brlPerUsdE6);
        if (updatedAt > block.timestamp + MAX_FUTURE_SKEW) revert LegFromFuture(address(fx), updatedAt);
        if (block.timestamp > uint256(updatedAt) + fxMaxAge) revert StaleLeg(address(fx), updatedAt);

        // usd (dec decimals) x brl/usd (1e6) -> brl (1e18): x 1e18 / (10^dec x 1e6). Floor.
        rate = Math.mulDiv(usd, brlPerUsdE6 * 1e12, one);
        if (rate == 0) revert PriceRoundsToZero();
    }

    /**
     * @inheritdoc IPriceOracle
     * @notice Movva's band on the ramps: R$ 1,00 x min(1, collateral ratio), in centavos per whole
     *         Movva, never above 100.
     * @dev Nearest centavo, as ChainlinkSignedFxOracle rounds a midpoint: the ramps quote whole
     *      centavos per token, so a centavo is already the band's resolution. The rate is read as a
     *      band (`bandBrlPerUsdtE18`, see "Off-hours"), and `updatedAt` is that reading's. Reverts when
     *      it is stale, as the interface requires.
     */
    function brlCentsPerUnit() external view settled returns (uint256 price, uint64 updatedAt) {
        uint256 rate;
        (rate, updatedAt) = _rate(true);
        uint256 ratio = _ratio(_totalUsdt(), rate, _supply());
        if (ratio > BPS) ratio = BPS;
        price = (ratio * 100 + BPS / 2) / BPS;
        // A reserve under half a percent backed: no price is the safe answer.
        // slither-disable-next-line incorrect-equality
        if (price == 0) revert PriceRoundsToZero();
    }

    /*//////////////////////////////////////////////////////////////
                               ACCOUNTING
    //////////////////////////////////////////////////////////////*/

    /**
     * @inheritdoc IMovvaReserve
     * @dev Idle USDT counts as zero while the reserve is frozen by Tether (it cannot be paid out);
     *      the vault position counts at `previewRedeem`, rounded down.
     */
    function totalUsdt() external view settled returns (uint256) {
        return _totalUsdt();
    }

    /// @notice `totalUsdt` with the vault at what it can pay now, `min(previewRedeem, maxWithdraw)`:
    ///         zero while it is frozen or illiquid. The mint floor and the harvest use this (N-09).
    function liquidUsdt() external view settled returns (uint256) {
        return _liquidUsdt();
    }

    /// @inheritdoc IMovvaReserve
    function reserveBrlE18() external view settled returns (uint256) {
        (uint256 rate,) = brlPerUsdtE18();
        return _brl(_totalUsdt(), rate);
    }

    /// @inheritdoc IMovvaReserve
    /// @dev Movva held by the reserve itself is excluded: nobody can redeem it (N-31).
    function liabilitiesBrlE18() external view settled returns (uint256) {
        return _supply();
    }

    /// @inheritdoc IMovvaReserve
    function collateralRatioBps() external view settled returns (uint256) {
        (uint256 rate,) = brlPerUsdtE18();
        return _ratio(_totalUsdt(), rate, _supply());
    }

    /// @inheritdoc IMovvaReserve
    function surplusBrlE18() external view settled returns (uint256) {
        (uint256 rate,) = brlPerUsdtE18();
        uint256 reserve = _brl(_totalUsdt(), rate);
        uint256 needed = Math.mulDiv(_supply(), targetCollateralRatioBps, BPS, Math.Rounding.Ceil);
        return reserve > needed ? reserve - needed : 0;
    }

    /// @inheritdoc IMovvaReserve
    /// @dev Rounded up: the figure the issuer hedges errs toward hedging a unit more.
    function liabilitiesUsdt() external view settled returns (uint256) {
        (uint256 rate,) = brlPerUsdtE18();
        return Math.mulDiv(_supply(), 1e6, rate, Math.Rounding.Ceil);
    }

    /// @notice True while Tether (or Circle, for a USDC reserve) has frozen this contract.
    function frozenByAssetIssuer() public view returns (bool) {
        return IssuerFreeze.isFrozen(USDT, address(this));
    }

    /**
     * @notice Movva a mint of `usdtIn` would deliver now, and the USDT fee taken from `usdtIn`.
     * @dev Ignores pauses, caps, freezes and the ratio floor. `mint` prices what the reserve books
     *      after depositing into the vault, which can be a vault rounding unit less.
     */
    function previewMint(uint256 usdtIn) external view settled returns (uint256 movvaOut, uint256 fee) {
        (uint256 rate,) = brlPerUsdtE18();
        fee = _fee(usdtIn, mintFeeBps);
        movvaOut = _brl(usdtIn - fee, rate);
    }

    /// @notice USDT a redemption of `movvaIn` would pay now, and the USDT fee taken from it. Ignores liquidity.
    function previewRedeem(uint256 movvaIn) external view settled returns (uint256 usdtOut, uint256 fee) {
        (uint256 rate,) = brlPerUsdtE18();
        return _redeemAmounts(movvaIn, rate);
    }

    /// @inheritdoc IMovvaReserve
    /// @dev Reverts while the rate is stale, as `harvestYield` would. Capped, as the harvest is, at the
    ///      vault's gain and at what the vault can pay now. Ignores the breaker and a freeze.
    function harvestableYield() external view settled returns (uint256) {
        (uint256 rate,) = brlPerUsdtE18();
        return _harvestCap(rate);
    }

    /**
     * @notice Whether the keyless exit is open, and why. See "The keyless exit" in the header.
     * @return gatewaysQuiet No gateway has minted, redeemed or heartbeated for `GATEWAY_EXIT_DELAY`.
     * @return rateDead `pokeRate` found the rate unreadable `ORACLE_EXIT_DELAY` ago, and nothing has read
     *         it since. `exitRedeem` also needs the rate to be unreadable at the time to use this.
     */
    function exitStatus() external view returns (bool gatewaysQuiet, bool rateDead) {
        return (_gatewaysQuiet(), _rateDead());
    }

    /*//////////////////////////////////////////////////////////////
                                ACTIONS
    //////////////////////////////////////////////////////////////*/

    /// @inheritdoc IMovvaReserve
    function mint(uint256 usdtIn, address to, uint256 minMovvaOut)
        external
        nonReentrant
        onlyGateway
        returns (uint256 movvaOut)
    {
        _requireSetupComplete();
        if (mintPaused) revert MintIsPaused();
        if (usdtIn == 0) revert ZeroAmount();
        if (to == address(0)) revert ZeroAddress();
        _requireNotFrozen(address(this));
        uint256 rate = _tradeRate(false);
        if (address(BREAKER) != address(0)) BREAKER.check(rate);
        uint256 supply = _supply();
        // The floor is judged on what the vault can pay now, not what it promises (N-09).
        uint256 ratio = _ratio(_liquidUsdt(), rate, supply);
        if (ratio < minMintCollateralRatioBps) revert CollateralRatioTooLow(ratio, minMintCollateralRatioBps);
        uint256 before = _totalUsdt();

        // Value in first, measured, then Movva out: what is minted is priced from what arrived and
        // what the vault booked for it, never from what was asked (ERC-4626's _deposit order).
        _pull(usdtIn);
        // The fee is paid in USDT before anything is booked: never principal (N-27).
        uint256 fee = _fee(usdtIn, mintFeeBps);
        uint256 net = usdtIn - fee;
        principalUsdt += net;
        zeroSupplySince = 0;
        _payFee(fee);
        // `before` is read to bracket exactly this intake: the vault is governor-chosen through the
        // delay, and mint is nonReentrant, so nothing else can move the reserve in between. Only this
        // mint's USDT goes to the vault, so the minter never pays for moving anyone else's (I-48).
        // slither-disable-next-line reentrancy-balance
        _depositIdle(net);
        uint256 booked = _totalUsdt();
        booked = booked > before ? booked - before : 0;
        // Never more than arrived, net of the fee (a fee kept here is backing, not the minter's).
        if (booked > net) booked = net;

        movvaOut = _brl(booked, rate);
        // Zero is dust, refused; not a balance anyone can steer to exactly zero for profit.
        // slither-disable-next-line incorrect-equality
        if (movvaOut == 0 || movvaOut < minMovvaOut) revert Slippage(movvaOut, minMovvaOut);
        if (supply + movvaOut > supplyCap) revert SupplyCapExceeded(supply + movvaOut, supplyCap);
        emit Minted(msg.sender, to, usdtIn, movvaOut, rate);
        Movva(MOVVA).mint(to, movvaOut);
    }

    /**
     * @inheritdoc IMovvaReserve
     * @dev The gateway approves (or permits) `movvaIn` to this contract. The Movva is taken and
     *      burned, less the fee, before any USDT moves. Gateway-only is the principal-locked rule's
     *      redeem rule (header, "The principal-locked reserve"): the off-ramp's LPs are the gateways.
     */
    function redeem(uint256 movvaIn, address to, uint256 minUsdtOut)
        external
        nonReentrant
        onlyGateway
        returns (uint256 usdtOut)
    {
        _requireSetupComplete();
        uint256 rate = _tradeRate(true);
        if (address(BREAKER) != address(0)) BREAKER.checkRedeem(rate);
        return _redeem(movvaIn, to, minUsdtOut, rate, false);
    }

    /**
     * @notice The keyless exit: any holder redeems their own Movva, once the gateways have gone quiet or
     *         the rate has been unreadable for long enough. See "The keyless exit" in the header.
     * @dev With a readable rate it is priced as `redeem` is (and the breaker applies); with a dead one,
     *      at `min(par at lastGoodRate, pro rata)`, or pro rata if no rate was ever read.
     */
    function exitRedeem(uint256 movvaIn, address to, uint256 minUsdtOut)
        external
        nonReentrant
        returns (uint256 usdtOut)
    {
        _requireSetupComplete();
        (bool readable, uint256 rate, uint64 at) = _tryRate();
        if (readable) {
            if (!_gatewaysQuiet()) revert ExitClosed();
            // As fresh as a gateway's: anyone may post a Pyth update first (N-06).
            _requireTradeFresh(at);
            _observe(rate);
            if (address(BREAKER) != address(0)) BREAKER.checkRedeem(rate);
        } else {
            if (!_rateDead()) revert ExitClosed();
            rate = lastGoodRate;
        }
        return _redeem(movvaIn, to, minUsdtOut, rate, true);
    }

    /**
     * @notice Anyone: record whether the rate is readable now. Readable, it becomes `lastGoodRate`;
     *         unreadable, it starts the keyless exit's `ORACLE_EXIT_DELAY` clock if that is not running.
     * @dev Mova's keeper calls this regularly, so `lastGoodRate` stays current.
     */
    function pokeRate() external nonReentrant returns (bool readable) {
        uint256 rate;
        (readable, rate,) = _tryRate();
        if (readable) {
            _observe(rate);
        } else if (rateStaleSince == 0) {
            rateStaleSince = uint64(block.timestamp);
            emit RateStale(block.timestamp);
        }
    }

    /// @notice A gateway says it is operating, which keeps the keyless exit's gateway clock from running out.
    function gatewayHeartbeat() external onlyGateway {
        _requireNotFrozen(msg.sender);
        lastGatewayActivityAt = uint64(block.timestamp);
        emit GatewayHeartbeat(msg.sender);
    }

    /// @notice A gateway removes itself, at once: what an operator does with a leaked key.
    function renounceGateway() external onlyGateway {
        isGateway[msg.sender] = false;
        emit GatewaySet(msg.sender, false);
    }

    /**
     * @inheritdoc IMovvaReserve
     * @dev Permissionless: it can only pay the fixed `yieldRecipient`, and only what sits above the
     *      floor, `max(principalUsdt, liabilities at the target ratio)`, so who calls it, and when,
     *      decides nothing. The vault's part is pulled INTO the reserve first and the harvest re-read
     *      from what actually arrived: a vault's rounding on the way out is charged to the harvest,
     *      never to the floor, and the payment itself is an exact transfer from idle USDT. Refused
     *      while Tether has frozen the reserve (that pull would freeze a payable vault position).
     */
    function harvestYield() external nonReentrant returns (uint256 usdt) {
        _requireSetupComplete();
        address to = yieldRecipient;
        _requireCanReceive(to);
        _requireNotFrozen(address(this));
        (uint256 rate,) = _rate(false);
        _observe(rate);
        // The breaker is immutable and ownerless, writes only its own claims and only staticcalls its
        // sources; this function is nonReentrant.
        // slither-disable-next-line reentrancy-benign
        if (address(BREAKER) != address(0)) BREAKER.check(rate);
        // Only the vault's gain, only what the vault can pay now, never below the floor (N-09, N-26).
        uint256 want = _harvestCap(rate);
        // slither-disable-next-line incorrect-equality
        if (want == 0) revert NothingToHarvest();
        IERC20 token = IERC20(USDT);
        uint256 before = token.balanceOf(address(this));
        // want <= the vault's gain, so a vault is set. What arrived is re-read; the shares burned do not matter.
        // slither-disable-next-line unused-return
        yieldVault.withdraw(want, address(this), address(this));
        // `before` brackets exactly this withdrawal; the function is nonReentrant.
        // slither-disable-next-line reentrancy-balance
        usdt = token.balanceOf(address(this)) - before;
        // Paid only out of what came from the vault, and re-checked against the floor after it.
        uint256 h = _harvestable(_liquidUsdt(), rate);
        if (usdt > h) usdt = h;
        // Zero is "nothing above the floor", not a clock or balance comparison.
        // slither-disable-next-line incorrect-equality,reentrancy-balance
        if (usdt == 0) revert NothingToHarvest();
        emit YieldHarvested(to, usdt, principalUsdt, msg.sender);
        token.safeTransfer(to, usdt);
    }

    /**
     * @inheritdoc IMovvaReserve
     * @dev Works with a stale rate: adding backing must never wait on an oracle. The event then
     *      carries a ratio of zero, meaning "not readable", not "zero". The USDT becomes principal.
     */
    function recapitalize(uint256 usdt) external nonReentrant {
        _requireSetupComplete();
        if (usdt == 0) revert ZeroAmount();
        _requireNotFrozen(address(this));
        _pull(usdt);
        principalUsdt += usdt;
        _depositIdle(type(uint256).max);
        (bool readable, uint256 rate,) = _tryRate();
        emit Recapitalized(msg.sender, usdt, readable ? _ratio(_totalUsdt(), rate, _supply()) : 0);
    }

    /*//////////////////////////////////////////////////////////////
                               GOVERNANCE
    //////////////////////////////////////////////////////////////*/

    /// @notice Adding a gateway waits out the delay; removing one is instant.
    function setGateway(address gateway, bool allowed) external {
        _authorizeChange(allowed && !isGateway[gateway]);
        if (gateway == address(0)) revert ZeroAddress();
        isGateway[gateway] = allowed;
        emit GatewaySet(gateway, allowed);
    }

    /// @notice Instant. The guardian can only pause minting, pull USDT from the vault back into the
    ///         reserve, and pause deposits into the vault.
    function setGuardian(address g) external {
        _authorizeChange(false);
        if (g == address(0)) revert ZeroAddress();
        guardian = g;
        emit RoleSet("guardian", g);
    }

    /// @notice Always delayed, in either direction: this address is the only place yield is paid, and
    ///         there is no "safer" value to move it to at once (client rule, 21 October 2026).
    function setYieldRecipient(address r) external {
        _authorizeChange(true);
        _setYieldRecipient(r);
    }

    /// @notice Delayed: this address is paid every fee.
    function setFeeRecipient(address r) external {
        _authorizeChange(r != feeRecipient);
        if (r == address(0)) revert ZeroAddress();
        feeRecipient = r;
        emit RoleSet("feeRecipient", r);
    }

    /// @notice Raising either fee is delayed; lowering is instant. Hard caps apply either way, and the
    ///         two together never fall below `MIN_ROUND_TRIP_FEE_BPS`.
    function setFees(uint16 mintBps, uint16 redeemBps) external {
        _authorizeChange(mintBps > mintFeeBps || redeemBps > redeemFeeBps);
        _setFees(mintBps, redeemBps);
    }

    /// @notice The council, or the governor through the delay, may name a new council; the council may
    ///         hand itself on or renounce (zero) at once, and the governor may remove it at once.
    function setGatewayCouncil(address c) external {
        if (msg.sender != gatewayCouncil) _authorizeChange(c != address(0));
        gatewayCouncil = c;
        emit RoleSet("gatewayCouncil", c);
    }

    /// @notice Council: propose a gateway, addable after the governance delay.
    function proposeGateway(address gateway) external {
        if (msg.sender != gatewayCouncil) revert NotCouncil();
        if (gateway == address(0)) revert ZeroAddress();
        uint256 ready = block.timestamp + GOVERNANCE_DELAY;
        gatewayReadyAt[gateway] = ready;
        emit GatewayProposed(gateway, ready);
    }

    /// @notice Council: add a proposed gateway once its delay has passed (and within EXECUTION_WINDOW
    ///         of that), or remove one - or a proposal - at once.
    function councilSetGateway(address gateway, bool allowed) external {
        if (msg.sender != gatewayCouncil) revert NotCouncil();
        if (allowed) {
            uint256 ready = gatewayReadyAt[gateway];
            if (ready == 0 || block.timestamp < ready) revert NotReadyYet(bytes32(uint256(uint160(gateway))), ready);
            if (block.timestamp > ready + EXECUTION_WINDOW) revert ChangeExpired(bytes32(uint256(uint160(gateway))));
        }
        delete gatewayReadyAt[gateway];
        isGateway[gateway] = allowed;
        emit GatewaySet(gateway, allowed);
    }

    /**
     * @notice LOWERING a ratio is delayed (it lets value out at less backing); raising is instant.
     *         Neither may be below 100%, and the mint floor may not exceed the target.
     * @dev The target is the harvest floor's liabilities leg: yield leaves only above it.
     */
    function setCollateralRatios(uint16 target, uint16 minMint) external {
        _authorizeChange(target < targetCollateralRatioBps || minMint < minMintCollateralRatioBps);
        if (target < BPS || minMint < BPS) revert BadBps();
        if (minMint > target) revert RatiosOutOfOrder();
        (targetCollateralRatioBps, minMintCollateralRatioBps) = (target, minMint);
        emit CollateralRatiosSet(target, minMint);
    }

    /// @notice Raising the supply cap is delayed; lowering it is instant. A cap of zero stops minting.
    function setSupplyCap(uint256 cap) external {
        _authorizeChange(cap > supplyCap);
        supplyCap = cap;
        emit SupplyCapSet(cap);
    }

    /// @notice Repointing either leg or lengthening a max age is delayed; only tightening an age is
    ///         instant, and never below `MIN_USDT_USD_MAX_AGE` / `MIN_FX_MAX_AGE` (SRM1-20). The rate
    ///         prices every mint and redemption, so unlike the ramps' band oracles its legs are not an
    ///         instant setting here.
    function setOracle(address feed, address fx, uint64 feedMaxAge, uint64 fxMaxAge_) external {
        _authorizeChange(
            feed != address(usdtUsdFeed) || fx != address(fxOracle) || feedMaxAge > usdtUsdMaxAge
                || fxMaxAge_ > fxMaxAge
        );
        _setOracle(feed, fx, feedMaxAge, fxMaxAge_);
    }

    /**
     * @notice Choose the yield vault. A new vault is delayed; removing it (zero) is instant.
     * @dev Only while the reserve holds no shares of the current one, so no value is ever dropped
     *      from the books: `pullFromVault(type(uint256).max)` first.
     */
    function setYieldVault(address v) external {
        _authorizeChange(v != address(0) && v != address(yieldVault));
        IERC4626 cur = yieldVault;
        if (address(cur) != address(0) && cur.balanceOf(address(this)) != 0) revert VaultNotEmpty();
        if (v != address(0) && IERC4626(v).asset() != USDT) revert AssetMismatch();
        yieldVault = IERC4626(v);
        emit YieldVaultSet(v);
    }

    /**
     * @notice Instant, guardian or governor: bring `usdt` back from the vault into the reserve, and stop
     *         depositing into it until the governor calls `setVaultDepositsPaused(false)`.
     *         `type(uint256).max` redeems every share. Survives finalization (N-03).
     * @dev USDT can only come back here. Refused while frozen: it would turn a payable vault position
     *      into frozen idle USDT.
     */
    function pullFromVault(uint256 usdt) external nonReentrant {
        if (msg.sender != guardian) _authorizeChange(false);
        IERC4626 v = yieldVault;
        if (address(v) == address(0)) revert NoVault();
        _requireNotFrozen(address(this));
        vaultDepositsPaused = true;
        emit VaultDepositsPausedSet(true);
        uint256 before = IERC20(USDT).balanceOf(address(this));
        // What arrived is re-read below; the shares burned, or assets returned, do not matter.
        if (usdt == type(uint256).max) {
            // slither-disable-next-line unused-return
            v.redeem(v.balanceOf(address(this)), address(this), address(this));
        } else {
            // slither-disable-next-line unused-return
            v.withdraw(usdt, address(this), address(this));
        }
        uint256 got = IERC20(USDT).balanceOf(address(this)) - before;
        _reduceVaultCost(got);
        emit PulledFromVault(usdt, got);
    }

    /// @notice Instant either way: the vault was chosen through the delay, and exits are unaffected.
    ///         The guardian may pause; only the governor may resume.
    function setVaultDepositsPaused(bool paused) external {
        if (!paused || msg.sender != guardian) _authorizeChange(false);
        vaultDepositsPaused = paused;
        emit VaultDepositsPausedSet(paused);
    }

    /// @notice Guardian or governor: stop minting. There is no pause for redemptions; see "Who can stop
    ///         a redemption" in the header for what can stop one.
    function pauseMint() external {
        if (msg.sender != guardian && msg.sender != governor) revert NotGuardianOrGovernor();
        mintPaused = true;
        emit MintPaused(msg.sender);
    }

    function resumeMint() external onlyGovernor {
        mintPaused = false;
        emit MintResumed();
    }

    function _isDelayable(bytes4 selector) internal pure override returns (bool) {
        return selector == MovvaReserve.setGateway.selector || selector == MovvaReserve.setYieldRecipient.selector
            || selector == MovvaReserve.setFeeRecipient.selector || selector == MovvaReserve.setFees.selector
            || selector == MovvaReserve.setCollateralRatios.selector || selector == MovvaReserve.setSupplyCap.selector
            || selector == MovvaReserve.setOracle.selector || selector == MovvaReserve.setYieldVault.selector
            || selector == MovvaReserve.setGatewayCouncil.selector;
    }

    /*//////////////////////////////////////////////////////////////
                                INTERNAL
    //////////////////////////////////////////////////////////////*/

    /// @dev Movva in circulation: the reserve's own balance is excluded, since only `redeem` burns, and
    ///      Movva sent here by plain transfer can never be redeemed (N-31).
    function _supply() internal view returns (uint256) {
        return IERC20(MOVVA).totalSupply() - IERC20(MOVVA).balanceOf(address(this));
    }

    function _totalUsdt() internal view returns (uint256) {
        return _payableIdle() + _vaultUsdt();
    }

    /// @dev See `liquidUsdt`.
    function _liquidUsdt() internal view returns (uint256) {
        uint256 v = _vaultUsdt();
        if (v != 0) {
            uint256 liquid = yieldVault.maxWithdraw(address(this));
            if (liquid < v) v = liquid;
        }
        return _payableIdle() + v;
    }

    function _payableIdle() internal view returns (uint256) {
        return frozenByAssetIssuer() ? 0 : IERC20(USDT).balanceOf(address(this));
    }

    function _vaultUsdt() internal view returns (uint256) {
        IERC4626 v = yieldVault;
        if (address(v) == address(0)) return 0;
        uint256 shares = v.balanceOf(address(this));
        // A shortcut, not a check: previewRedeem(0) is zero anyway.
        // slither-disable-next-line incorrect-equality
        return shares == 0 ? 0 : v.previewRedeem(shares);
    }

    /**
     * @dev What `harvestYield` may take now: the harvest floor's headroom over the liquid reserve,
     *      capped at the vault's gain over its cost and at what the vault can pay now (N-09, N-26).
     */
    function _harvestCap(uint256 rate) internal view returns (uint256 cap) {
        IERC4626 v = yieldVault;
        if (address(v) == address(0)) return 0;
        uint256 value = _vaultUsdt();
        uint256 cost = vaultCostUsdt;
        if (value <= cost) return 0;
        cap = value - cost;
        uint256 h = _harvestable(_liquidUsdt(), rate);
        if (h < cap) cap = h;
        uint256 liquid = v.maxWithdraw(address(this));
        if (liquid < cap) cap = liquid;
    }

    function _reduceVaultCost(uint256 usdt) internal {
        uint256 c = vaultCostUsdt;
        vaultCostUsdt = c > usdt ? c - usdt : 0;
    }

    /**
     * @dev Every redemption, gateway or keyless: Movva in and burned, the basis lowered by the USDT it
     *      was worth, that USDT out less the fee, which goes to the fee recipient (N-27). The bound is checked against what `to` actually
     *      received (L-22). A gateway, or a holder, the asset issuer froze may not route an exit to
     *      someone else (SRM1-21).
     */
    function _redeem(uint256 movvaIn, address to, uint256 minUsdtOut, uint256 rate, bool exit)
        internal
        returns (uint256 usdtOut)
    {
        if (movvaIn == 0) revert ZeroAmount();
        _requireCanReceive(to);
        if (to == address(this)) revert BadRecipient();
        _requireNotFrozen(msg.sender);
        uint256 fee;
        (usdtOut, fee) = _redeemAmounts(movvaIn, rate);
        // slither-disable-next-line incorrect-equality
        if (usdtOut == 0 || usdtOut < minUsdtOut) revert Slippage(usdtOut, minUsdtOut);

        IERC20(MOVVA).safeTransferFrom(msg.sender, address(this), movvaIn);
        Movva(MOVVA).burn(movvaIn);
        if (_supply() == 0) zeroSupplySince = uint64(block.timestamp);
        // A redemption can pay more than went in (the real strengthened since): the basis floors at zero.
        uint256 p = principalUsdt;
        uint256 worth = usdtOut + fee;
        principalUsdt = p > worth ? p - worth : 0;
        if (exit) emit ExitRedeemed(msg.sender, to, movvaIn, usdtOut, rate);
        else emit Redeemed(msg.sender, to, movvaIn, usdtOut, rate);
        IERC20 token = IERC20(USDT);
        uint256 had = token.balanceOf(to);
        _pay(to, usdtOut);
        // `had` brackets exactly this payment; the caller is nonReentrant.
        // slither-disable-next-line reentrancy-balance
        uint256 got = token.balanceOf(to) - had;
        if (got < minUsdtOut) revert Slippage(got, minUsdtOut);
        _payFee(fee);
    }

    /**
     * @notice After SUNSET_DELAY with no Movva in circulation, pay everything the reserve can pay now to
     *         `yieldRecipient` (N-25). Anyone may call; a mint at any point stops the clock for good.
     */
    function sweepSunset() external nonReentrant returns (uint256 usdt) {
        uint64 since = zeroSupplySince;
        // slither-disable-next-line incorrect-equality,timestamp
        if (since == 0 || _supply() != 0 || block.timestamp < since + SUNSET_DELAY) revert NotSunset();
        address to = yieldRecipient;
        _requireCanReceive(to);
        usdt = _liquidUsdt();
        if (usdt == 0) revert ZeroAmount();
        principalUsdt = 0;
        emit SunsetSwept(to, usdt);
        _pay(to, usdt);
    }

    /**
     * @dev The rate a gateway's mint or redemption takes: no older than TRADE_FX_MAX_AGE (N-06). And a
     *      gateway's trade in the other direction from its last one waits that long too (never in the
     *      same block): the second price is then from a publication made after the first trade, which the
     *      gateway could not know when it made it, so no pair of known publications can be played against
     *      each other. Records the reading and the gateway's activity for the keyless exit.
     */
    function _tradeRate(bool redeeming) internal returns (uint256 rate) {
        uint64 at;
        (rate, at) = _rate(false);
        _requireTradeFresh(at);
        uint256 last = _lastTrade[msg.sender];
        uint256 kind = redeeming ? 1 : 0;
        if (last != 0 && last & 1 != kind) {
            uint256 allowedAt = uint256(uint64(last >> 65)) + TRADE_FX_MAX_AGE;
            if (uint64(last >> 1) == block.number || block.timestamp < allowedAt) revert RoundTripTooSoon(allowedAt);
        }
        _lastTrade[msg.sender] = (block.timestamp << 65) | (block.number << 1) | kind;
        lastGatewayActivityAt = uint64(block.timestamp);
        _observe(rate);
    }

    function _requireTradeFresh(uint64 at) internal view {
        uint64 maxAge = TRADE_FX_MAX_AGE;
        if (maxAge != 0 && block.timestamp > uint256(at) + maxAge) revert StaleLeg(address(fxOracle), at);
    }

    function _observe(uint256 rate) internal {
        if (rateStaleSince != 0) emit RateRecovered(rate);
        // A rate that fits the legs' bounds fits 128 bits by a wide margin.
        (lastGoodRate, lastGoodRateAt, rateStaleSince) = (uint128(rate), uint64(block.timestamp), 0);
    }

    /// @dev The rate if it is readable now. An out-of-gas inside the read is not a dead oracle: the
    ///      caller could otherwise starve the read to fake one, so it reverts instead.
    function _tryRate() internal view returns (bool readable, uint256 rate, uint64 updatedAt) {
        uint256 g = gasleft();
        try this.brlPerUsdtE18() returns (uint256 r, uint64 at) {
            return (true, r, at);
        } catch {
            if (gasleft() <= g / 64) revert ReadOutOfGas();
            return (false, 0, 0);
        }
    }

    function _gatewaysQuiet() internal view returns (bool) {
        return block.timestamp >= uint256(lastGatewayActivityAt) + GATEWAY_EXIT_DELAY;
    }

    function _rateDead() internal view returns (bool) {
        uint256 since = rateStaleSince;
        return since != 0 && block.timestamp >= since + ORACLE_EXIT_DELAY;
    }

    function _setFees(uint16 mintBps, uint16 redeemBps) internal {
        if (mintBps > MAX_MINT_FEE_BPS || redeemBps > MAX_REDEEM_FEE_BPS) revert FeeTooHigh();
        if (uint256(mintBps) + redeemBps < MIN_ROUND_TRIP_FEE_BPS) revert BadBps();
        (mintFeeBps, redeemFeeBps) = (mintBps, redeemBps);
        emit FeesSet(mintBps, redeemBps);
    }

    /// @dev USDT (6 decimals) to reais (18 decimals) at `rate`, rounded down.
    function _brl(uint256 usdt, uint256 rate) internal pure returns (uint256) {
        return Math.mulDiv(usdt, rate, 1e6);
    }

    /// @dev Reserve rounded down, then the ratio rounded down.
    function _ratio(uint256 usdt, uint256 rate, uint256 supply) internal pure returns (uint256) {
        if (supply == 0) return type(uint256).max;
        return Math.mulDiv(_brl(usdt, rate), BPS, supply);
    }

    /// @dev A fee on `usdt`, rounded up.
    function _fee(uint256 usdt, uint16 bps) internal pure returns (uint256) {
        return Math.mulDiv(usdt, bps, BPS, Math.Rounding.Ceil);
    }

    /// @dev Pays a USDT fee as `_pay` pays a redemption, idle first and then from the vault straight to the fee
    ///      recipient; what cannot be paid (a freeze, an illiquid vault) stays here as backing rather than stopping
    ///      the trade (N-27).
    function _payFee(uint256 fee) internal {
        if (fee == 0) return;
        uint256 idle = _payableIdle();
        uint256 fromIdle = idle < fee ? idle : fee;
        address to = feeRecipient;
        if (fromIdle != 0) {
            // slither-disable-next-line low-level-calls
            (bool ok, bytes memory ret) = USDT.call(abi.encodeCall(IERC20.transfer, (to, fromIdle)));
            if (!ok || (ret.length != 0 && !abi.decode(ret, (bool)))) fromIdle = 0;
        }
        uint256 rest = fee - fromIdle;
        IERC4626 v = yieldVault;
        if (rest != 0 && address(v) != address(0)) {
            // slither-disable-next-line unused-return
            try v.withdraw(rest, to, address(this)) {
                _reduceVaultCost(rest);
                rest = 0;
            } catch {}
        }
        if (rest != 0) emit FeeKept(rest);
    }

    /**
     * @dev What `movvaIn` is worth is the lesser of par (`movvaIn / rate`) and its pro-rata share of
     *      everything payable (`movvaIn / supply x totalUsdt`), each rounded down: exactly min(1, ratio)
     *      of par. The fee is that USDT's `redeemFeeBps`, rounded up, and the rest is paid. A zero rate
     *      is the keyless exit with no rate ever read: pro rata alone.
     */
    function _redeemAmounts(uint256 movvaIn, uint256 rate) internal view returns (uint256 usdtOut, uint256 fee) {
        uint256 supply = _supply();
        if (supply == 0) return (0, 0);
        uint256 worth = Math.mulDiv(movvaIn, _totalUsdt(), supply);
        if (rate != 0) {
            uint256 atPar = Math.mulDiv(movvaIn, 1e6, rate);
            if (atPar < worth) worth = atPar;
        }
        fee = _fee(worth, redeemFeeBps);
        usdtOut = worth - fee;
    }

    /**
     * @dev `total` less the harvest floor, zero at or below it. The floor is the larger of the principal
     *      and the USDT the liabilities need at the target ratio, `supply x target / rate`, rounded UP
     *      (the floor errs high, so the harvest errs low).
     */
    function _harvestable(uint256 total, uint256 rate) internal view returns (uint256) {
        uint256 floor = Math.mulDiv(_supply(), uint256(targetCollateralRatioBps) * 1e6, rate * BPS, Math.Rounding.Ceil);
        uint256 p = principalUsdt;
        if (p > floor) floor = p;
        return total > floor ? total - floor : 0;
    }

    function _setYieldRecipient(address r) internal {
        if (r == address(0)) revert ZeroAddress();
        // Paying itself would book yield as backing it never left; refused so the address means a payee.
        if (r == address(this)) revert BadYieldRecipient();
        yieldRecipient = r;
        emit RoleSet("yieldRecipient", r);
    }

    /// @dev Pull USDT from the caller and refuse it if less arrived: YieldVault._deposit's guard.
    function _pull(uint256 amount) internal {
        IERC20 token = IERC20(USDT);
        uint256 before = token.balanceOf(address(this));
        token.safeTransferFrom(msg.sender, address(this), amount);
        // Every caller is nonReentrant, and `before` brackets only this transfer.
        // slither-disable-next-line reentrancy-balance
        uint256 received = token.balanceOf(address(this)) - before;
        if (received < amount) revert TransferFeeCharged(amount, received);
    }

    /**
     * @dev Put up to `max` idle USDT into the vault, as much as it accepts - `maxDeposit` is zero while
     *      the vault is paused, frozen, in setup or at its cap - and never so much that the vault would
     *      hold more than MAX_VAULT_BPS of the reserve (N-03). A vault that refuses anyway leaves the
     *      USDT idle rather than blocking the mint or recapitalization that brought it.
     */
    function _depositIdle(uint256 max) internal {
        IERC4626 v = yieldVault;
        if (address(v) == address(0) || vaultDepositsPaused) return;
        uint256 idle = IERC20(USDT).balanceOf(address(this));
        uint256 inVault = _vaultUsdt();
        uint256 allowed = Math.mulDiv(idle + inVault, MAX_VAULT_BPS, BPS);
        if (allowed <= inVault) return;
        uint256 amount = allowed - inVault;
        if (amount > idle) amount = idle;
        if (amount > max) amount = max;
        uint256 room = v.maxDeposit(address(this));
        if (room < amount) amount = room;
        // Nothing idle, or a vault that takes nothing now: skip the call, lose nothing.
        // slither-disable-next-line incorrect-equality
        if (amount == 0) return;
        IERC20(USDT).forceApprove(address(v), amount);
        // The shares are re-read by totalUsdt; the return value is not needed.
        // slither-disable-next-line unused-return
        try v.deposit(amount, address(this)) returns (uint256) {
            vaultCostUsdt += amount;
        } catch {
            emit VaultDepositFailed(amount);
        }
        // Never leave an allowance behind, whatever the vault pulled (N-29).
        IERC20(USDT).forceApprove(address(v), 0);
    }

    /**
     * @dev Pay `amount` from idle first, then from the vault straight to `to`. Paid directly, the
     *      vault's part still arrives while Tether has frozen this contract, and costs one USDT
     *      transfer rather than two. A shortfall reverts with what was available, before anything moves.
     */
    function _pay(address to, uint256 amount) internal {
        uint256 fromIdle = _payableIdle();
        if (fromIdle > amount) fromIdle = amount;
        uint256 fromVault = amount - fromIdle;
        if (fromVault != 0) {
            IERC4626 v = yieldVault;
            uint256 liquid = address(v) == address(0) ? 0 : v.maxWithdraw(address(this));
            if (liquid < fromVault) revert InsufficientLiquidity(amount, fromIdle + liquid);
            _reduceVaultCost(fromVault);
            // Shares burned are not needed; the vault rounds them up, against this reserve.
            // slither-disable-next-line unused-return
            v.withdraw(fromVault, to, address(this));
        }
        if (fromIdle != 0) IERC20(USDT).safeTransfer(to, fromIdle);
    }

    function _requireNotFrozen(address who) internal view {
        if (IssuerFreeze.isFrozen(USDT, who)) revert FrozenByAssetIssuer(who);
    }

    /// @dev A payee must exist and be able to use what it receives.
    function _requireCanReceive(address to) internal view {
        if (to == address(0)) revert ZeroAddress();
        _requireNotFrozen(to);
    }

    function _setOracle(address feed, address fx, uint64 feedMaxAge, uint64 fxMaxAge_) internal {
        if (feed == address(0) || fx == address(0)) revert ZeroAddress();
        // Below the floors a healthy leg would read stale: every redemption frozen by a "tightening"
        // that is instant (SRM1-20). Zero, which refuses every price, is below both.
        if (feedMaxAge < MIN_USDT_USD_MAX_AGE || fxMaxAge_ < MIN_FX_MAX_AGE) revert BadMaxAge();
        usdtUsdFeed = IAggregatorV3(feed);
        fxOracle = IPriceOracle(fx);
        usdtUsdMaxAge = feedMaxAge;
        fxMaxAge = fxMaxAge_;
        emit OracleSet(feed, fx, feedMaxAge, fxMaxAge_);
    }
}
