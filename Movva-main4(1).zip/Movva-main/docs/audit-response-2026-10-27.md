# Response to the v3.1 audit (26 October 2026), with the v6 follow-up

For the client's auditors. It gives each v3.1 finding (N-01 to N-39) and each v2.0 finding the v3.1 report still
lists as open or partial, what we changed and in which commit, or why we did not change it.

**v6 (27 October 2026).** The first response (v5, tag `audit-freeze-2026-10-27`) answered some findings without code:
acknowledged, documented, or left as a business rule. They now have code fixes too, deployed to Sepolia as **v6**:
a new rail, sleeve and permissionless pair, and the three account contracts that changed. Five findings are still not
changed, each for the reason given in its row (L-04, I-07, I-16, I-35/I-72, I-37).

**What is delivered.** A git bundle of branch `phase-1-shielded-rail` at tag `audit-freeze-2026-10-27-v6.1`, not a zip.
`git bundle verify` checks it; `git clone movva.bundle` gives the tree, its history and both tags. From a clean
clone, `npm ci` succeeds, and `npx tsc --noEmit`, `forge test` and `npx vitest run` pass (numbers below).

**Why the v3.1 tree did not match the response.** The zip reviewed in v3.0 and v3.1 was not an export of `d4eef51`. It
held files deleted from git before that commit: `savings.ts`, `zap-relayer.ts`, `Savings.tsx`, `SavingsMovva.t.sol`,
`CardRail.t.sol`, `ShieldedTransferRouter.sol`, `viewing-key/src/transfer.ts`, `yield/src/movva-keeper.ts` and the
`attestor` and `zap-relayer` workspaces that the lockfile no longer lists. A `git archive d4eef51` has none of them;
`npm ci` and `tsc` pass on it. That is why L-01, I-02, N-16 and the "not compiling" notes were right about the zip and
not about the commit. The bundle closes the gap: the reviewed tree is the commit itself. Of the dead code, only
`LimitedYieldVault.sol` was really in git, and it is now deleted (M-14 to M-16).

## Decisions for the client

These changes alter rules the client set, so they need your confirmation. Each is built and tested. Each can be
reverted before mainnet if you prefer the old rule.

1. **Keyless exit (N-01, N-02).** Any holder can call `exitRedeem` in two cases: after 30 days with no gateway
   activity, or after 7 days with an unreadable rate. Otherwise only gateways redeem, as before.
2. **Ossify instead of renounce (N-04, N-20, N-28).** Finalization ossifies by default. No risk-increasing change can
   ever run again; the governor Safe keeps only the brakes. `MOVVA_FINALIZE_GOVERNANCE=renounce` keeps the old end state.
3. **Gateway council (N-02).** Optional and off by default (`MOVVA_GATEWAY_COUNCIL`).
4. **Reserve sunset (N-25).** Once supply has been zero for a year, the surplus can be swept to the yield recipient.
   Before v6 it stayed in the reserve for ever as over-collateral.
5. **Fees in USDT (N-27).** Fees are taken in USDT, outside the principal, instead of being minted as Movva. Node
   rewards are paid in USDT too.
6. **Ramp rules (H-04, L-03, L-13, L-31, I-08).** An LP may gate its offers (a taker then needs the LP node's one-use
   approval, within per-taker limits). A bonded LP's credit counts its bond at a 10% haircut (`BOND_HAIRCUT_BPS`,
   configurable). A PIX credit without the order's txid is never matched by amount; it is refunded by a person. A retail
   LP's cap grows at most R$ 50,000 per 30 days. An institutional LP's credit halves per lost dispute, as a retail one's does.

## v3.1 findings

Commits for v5: `d0597d3` contracts and services; `68f9e48` open v2.0 medium and low findings, N-21, N-34; `e9a2d41`
L-14, N-15, N-19 and informational fixes; `ba7463d` docs; `0032800` the remaining v2.0 informational fixes. For v6:
`687e02c` contracts, `440f738` their TypeScript callers.

| ID | Status | What changed |
|---|---|---|
| N-01 | fixed `d0597d3` | Keyless `exitRedeem` once the rate has been unreadable for `ORACLE_EXIT_DELAY` (7 days, immutable). It pays `min(par at the last good rate, pro rata)`, or pro rata if no rate was ever read. `pokeRate` starts the clock, and an out-of-gas read cannot fake a dead rate |
| N-02 | fixed `d0597d3` | `exitRedeem` once no gateway has minted, redeemed or heartbeat for `GATEWAY_EXIT_DELAY` (30 days), priced as `redeem`. A gateway can `renounceGateway`. There is an optional gateway council (decision 3) |
| N-03 | fixed `d0597d3` | `MAX_VAULT_BPS` caps what the vault holds (default 90%). The guardian can `pullFromVault` and pause vault deposits, and keeps that power after finalization. A new vault still waits the delay |
| N-04 | fixed `d0597d3`, `0032800` | `DelayedGovernance.ossify()` (decision 2). Witnesses, endpoints, verifier and arbitrators can still be revoked after finalization, never added |
| N-05 | fixed `d0597d3` | `TAKER_GRACE`: the taker may dispute for 1 hour after `payBy`, while the LP has not reclaimed |
| N-06 | fixed `d0597d3` | A trade needs an FX publication at most `TRADE_FX_MAX_AGE` old (300 s on Pyth). An opposite trade by the same gateway waits a cooldown. `MIN_ROUND_TRIP_FEE_BPS` (20) is the fee floor. The PoC's two-publication round trip reverts (`test_N06_TheTwoPublicationRoundTripIsRefused`) |
| N-07 | fixed `d0597d3` | The FROST commit limiter is keyed per API key and client address, with configurable rate, burst and session caps |
| N-08 | fixed `d0597d3` | Each endpoint is classed RECEIVED or SENT, and each escrow declares `PAYMENT_DIRECTION`, so the on-ramp accepts only received credits. The PoC reverts |
| N-09 | fixed `d0597d3` | The vault is valued at `min(previewRedeem, maxWithdraw)` for the mint floor and the harvest. A frozen vault pays no harvest out of idle USDT |
| N-10 | fixed `d0597d3` | `_reduceBoth` sells the spot that matches the short actually filled, plus spot already uncovered (`SpotSaleShort`) |
| N-11 | fixed `d0597d3` | A third-party deposit is refused while the receiver's shares are locked |
| N-12 | fixed `d0597d3` | `TRUST_PROXY` is a hop count read from the right of X-Forwarded-For (test `proxy.test.ts`) |
| N-13 | fixed `d0597d3` | `endpointRequiresOrderTxid` is true for every RECEIVED endpoint. Finalize refuses an unclassified or wrongly flagged endpoint, and verification checks each one |
| N-14 | fixed `d0597d3` | The txid preflight rethrows transport errors (fail closed). Boleto is exempt |
| N-15 | fixed `e9a2d41` | The Sepolia stand-in USDT is `OwnedTetherLike`: blacklist, pause and fee belong to the governor Safe. Anyone can still mint (it is the testers' faucet) |
| N-16 | resolved by the bundle | The files exist only in the zip (above) |
| N-17 | fixed `d0597d3` | Envelope v2: the AAD binds `complete` and the transcript. v1 records are migrated on read |
| N-18 | documented | v6 is again finalized with test identities, because it is a test deployment. `audit-freeze.md` says so in its first lines. Mainnet refuses any test identity |
| N-19 | fixed `e9a2d41` | `EntrypointTimelock` takes independent cancellers (the guardian Safe), checked at deploy and in verification |
| N-20 | fixed `d0597d3`, `68f9e48` | Ossified, the governor keeps pause, keeper revocation and the other brakes. Mainnet revokes the sleeve keeper by default. A pause stays final, and the runbook says so |
| N-21 | fixed `68f9e48` | The permissionless pair and the sleeve are handed to the governor Safe with setup open, and the Safe closes setup |
| N-22 | fixed `d0597d3` | The seller's off-ramp dispute is windowed to `payBy` |
| N-23 | fixed `687e02c` | `LPRegistry.successor`: a registry checks its successor's spent bank transaction ids too (`consumeBankTxId`). The successor is set during setup, or scheduled with the governance delay before ossifying |
| N-24 | fixed `ba7463d` | The deploy header and the runbook are rewritten |
| N-25 | fixed `687e02c` (decision 4) | `sweepSunset`: once Movva supply has been zero for `SUNSET_DELAY` (365 days), anyone can sweep what is left to the yield recipient (`zeroSupplySince`, `NotSunset`) |
| N-26 | fixed `d0597d3` | `vaultCostUsdt`: a harvest pays only vault gain withdrawn in the same call. A direct USDT transfer becomes backing, not yield |
| N-27 | fixed `687e02c`, `440f738` (decision 5) | Fees are taken in USDT, outside the principal: `FeeSplitter` and `NodeRewards` pay USDT (`TOKEN_PER_CENT` 2,000 at R$ 5/USD). A fee is paid from idle USDT first, then from the vault; one that cannot be paid now is kept (`FeeKept`) |
| N-28 | fixed `d0597d3` | Ossify keeps `pauseMint` with the guardian, a key with no power over funds. The other parameters are listed in the runbook as permanent |
| N-29 | fixed `d0597d3` | The vault allowance is reset to 0 after each deposit |
| N-30 | fixed `d0597d3` | Views revert `ReentrantRead` while a call is in progress |
| N-31 | fixed `d0597d3` | Movva held by the reserve is not counted as a liability |
| N-32 | fixed `d0597d3` | `MovvaAuditV31.t.sol` covers (a) a frozen vault with idle USDT, (b) a dead feed after finalization, (c) two Pyth publications, (e) view reentrancy, and ossified governance. (d) vault loss and recovery is in `YieldVault.t.sol` (`test_TheLastHolderCanRedeemEverythingAfterALoss`, `test_ResumingAcknowledgesTheLoss`) |
| N-33 | fixed `d0597d3` | GCM `authTagLength: 16` |
| N-34 | fixed `68f9e48` | The value is `TEST_KEY_NOT_REAL_0123456` |
| N-35 | fixed `d0597d3` | Adapter values are read with try/catch. An unreadable source counts as zero, and the guardian can remove it (`AdapterWrittenOff`). `ERC4626Adapter` no longer trusts its target's views |
| N-36 | fixed `d0597d3` | A failed Curve sale falls through (`CurveSaleFailed`) instead of reverting the withdrawal |
| N-37 | fixed `d0597d3` | Claims are paid FIFO (`claimHead`, `NotYourTurn`) |
| N-38 | fixed `d0597d3` | The constructor requires a 6-decimal asset |
| N-39 | fixed `687e02c` | Both escrows track what they hold per asset (`heldOf`), and the cap checks that, not `balanceOf`: a donation moves nothing |

## v2.0 findings still open or partial in v3.1

v6 commits: `687e02c` contracts; `440f738` TypeScript callers, FROST (I-09, I-10) and circuits.json (I-03); `0ae7141`
deploy tooling and I-21; `9058d20` I-41, I-59, I-61, I-62, I-65; then one commit per finding, named in its row.

| ID | Status | What changed |
|---|---|---|
| H-04 | fixed `687e02c`, `413c06e` | An LP may set a taker gate per offer (`setTakerGate`); a gated offer locks only through `lockOrderGated`, with the gate's one-use EIP-191 approval for that taker, amount, recipient, rail and deadline. The LP node signs approvals with a key of its own (never the LP key), for the taker who signs the request, within per-taker limits (open orders, approvals per hour); the wallet asks for one and locks with it. Disputes stay windowed (N-05) |
| M-03 | fixed `d0597d3` | N-08, N-13, L-12. The bank-side test with each LP's real bank is still to do (below) |
| M-10, L-09, I-17, I-58 | resolved by the bundle | The files are not in git |
| M-12, M-13, M-17, M-19, M-23 | fixed `68f9e48` | As in v5 |
| M-22, M-25, L-02, L-12, L-19 | fixed `d0597d3` | As in v5 |
| L-01, I-02 | resolved by the bundle | `npm ci` and `forge test` pass on a clean clone |
| L-03 | fixed `687e02c` | `PermissionlessLPRegistry` counts a bond at a haircut (`BOND_HAIRCUT_BPS`, 1 to 5,000; default 1,000) |
| L-04 | not changed | Sparing live orders when a verifier is revoked would give a compromised verifier days to settle locked orders. Revocation stays immediate |
| L-05 | fixed `68f9e48` | Accrued fees are split before a change |
| L-06, I-62 | fixed `9058d20` | Test identities stay on Sepolia (N-18). A seed that signs on a public network must be 32 random bytes or more (`seedProblem`): the rail, sleeve, pair and custody scripts refuse a weak one |
| L-07 | fixed `4e3aff1`, `bdf1d22` | Rotation: a second DKG for the same passkey runs when it names the current group key (`rotates`, signed by the passkey). The co-signer then co-signs the switch to that new key and no other: `FrostValidator.rotateGroupKey` for a Kernel account, and for a Safe a `swapOwner` to a new FrostSigner whose code is exactly FrostSigner's for the new key (a contract that only answers `groupKey()` is refused). It retires the old share when the account re-enrols under the new key |
| L-08 | fixed `2299a68` | The co-signer signs DKG messages with a transport key of its own, which the co-signer key certifies once under its own type hash (`GET /v1/frost/dkg/key`). The co-signer key signs no DKG message |
| L-13 | fixed `e748bd2` | No amount matching: a credit without the order's txid matches no order and is listed for a person to refund |
| L-14 to L-29 | fixed | See the commit messages of `d0597d3`, `68f9e48` and `e9a2d41` |
| L-30 | fixed `687e02c` | A FiatEscrow recipient can redirect a DIRECT delivery (`setRecipient`); an OffRampEscrow seller can change `refundTo`. An issuer freeze is still not routed around |
| L-31 | fixed `687e02c` | `capVolume` grows a retail cap by at most `CAP_VOLUME_PER_WINDOW_CENTS` (R$ 50,000) per `CAP_WINDOW` (30 days) |
| I-01, I-11, I-12, I-14, I-25, I-38, I-40, I-42, I-43, I-45 to I-49, I-54, I-60, I-63, I-64, I-69 | fixed | As in v5 (`d0597d3`, `e9a2d41`, `0032800`) |
| I-03 | fixed `440f738` | `circuits.json` names the real templates and the withdraw circuit; `verify-artifacts.mjs` reads it |
| I-05 | fixed `687e02c` | The deploy refuses, before broadcasting, a push FX leg whose round trip is under 50 bps |
| I-07 | partly fixed | N-15. The breaker stays off on Sepolia, which has no second BRL source for it (a recorded decision) |
| I-08 | fixed `687e02c` | An institutional LP's credit halves per lost dispute too |
| I-09 | fixed `440f738` | H1, H3, H4 and H5 are RFC 9591's (`hash_to_field`, `expand_message_xmd`); H2 stays the on-chain challenge. The RFC vectors are tested |
| I-10 | fixed `440f738` | `aggregate` takes an `AggregateCheck`: it enforces the threshold and verifies every share (`twoOfTwoCheck` for the co-signer) |
| I-13 | documented in code `687e02c` | `FrostValidator` and `SchnorrVerifier` state the 160-bit comparison |
| I-15 | fixed `1ac5c64` | Every byte form of a FROST secret is wiped after use (nonce input, sealed DKG shares, X25519 keys and shared secrets, the passkey-sealed share). A test holds secret multiplications to noble's constant-time path. A JavaScript BigInt itself cannot be wiped |
| I-16 | not changed | A design property of passkey accounts (passkey plus veto window); I-32 narrows it |
| I-18 | fixed `a9ea483` | The wallet never reserves a deposit index past a restore's reach (`RECOVERY_GAP_LIMIT`); past it, it reuses an index a cancelled order released |
| I-19 | fixed `a9ea483` | The wallet refuses to prove at an ASP root it has seen replaced (`asp_root_rolled_back`), and books an exit whose earlier proof landed instead of proving it again |
| I-21 | fixed `0ae7141` | `normalizeBankTxId` before hashing: one bank id, one hash |
| I-22 | fixed `687e02c` | `Payment.prover` is the claim owner, and the escrows require it to be the LP (`WrongProver`). The verifier checks the claim's time (`MAX_CLAIM_AGE` 1 day, 15 minutes of skew, not before `paidAt`) and the witness epoch |
| I-23 | fixed `7d67348` | The zkTLS prover keeps proven payments and their proofs in a journal: a restart neither forgets one nor proves a second payment for an order |
| I-24 | fixed `7d67348` | In proxy-mTLS mode the webhook also needs the proxy's shared secret, not only the constant header |
| I-26 | fixed `687e02c` | `YieldVault` refuses an exit below the adapter's valuation (`ExitBelowValuation`) |
| I-27 | fixed `687e02c` | Dust up to 1 bp is written off, so `removeAdapter` cannot be blocked |
| I-29 | fixed `687e02c` | `ERC4626Adapter` caps the price growth it accepts (`MAX_GROWTH_BPS_PER_YEAR`, 50%) |
| I-30 | fixed `687e02c` | `AuditGrantRegistry`: the first anchor is set once; after that `extendChain` only extends the stored head |
| I-31 | fixed `687e02c` | `PasskeyCoSignerValidator` binds the RP ID hash and the origin on-chain (`NoSiteBinding`) |
| I-32 | fixed `687e02c` | A queued passkey-only call through `KernelAvatarAdapter` can only rotate the co-signer or the group key (`NotARotation`) |
| I-34 | fixed `11a134f` | The protocol deploy refuses Groth16 verifiers that do not embed the ceremony's keys, or that embed the development keys |
| I-35, I-72 | not changed | Upstream Privacy Pools circuit. A range check would need a new trusted setup; the contract caps the depth at 32 |
| I-36, I-53 | fixed `687e02c` | Two-step handover after setup (`transferGovernor`, `acceptGovernor`), `renounceGovernor`, and each handover voids the previous governor's queue (`governanceEpoch`) |
| I-37 | acknowledged | Sepolia's substitutions are recorded, as the auditors noted |
| I-41, I-61 | fixed `9058d20` | The bundler scripts take keys from the environment and run unsafe mode only against a local RPC. The anvil dev keys are refused off a local chain |
| I-51 | fixed `687e02c` | `AspRootQuorum` refuses a root already posted (`RootAlreadyPosted`) |
| I-52 | fixed `687e02c` | `NodeRewards` claims expire after a year (`CLAIM_EXPIRY`), and the forfeited balance goes to the sink |
| I-55 | fixed `47b3732` | The public deployment JSON carries no co-signer API key: the app refuses one, and a gateway adds its key server-side |
| I-56 | fixed `72c8e9e`, `228146b` | A sale account signs only after the user's passkey confirms the action; the assertion is checked (key, user verification, challenge). A sub-wallet, which has no passkey, confirms with the one that unlocked the app |
| I-57 | fixed `45fee7c`, `983bfa5` | Sealed local records carry a generation bound into the AEAD. A manifest refuses older copies and removed records put back. The generation is anchored at the note vault, per device, so a rollback of the whole browser storage is refused too |
| I-59 | fixed `9058d20` | Keepers and CLIs send with the chain set and a fee ceiling (`MAX_FEE_GWEI`) |
| I-65 | fixed `687e02c`, `9058d20` | The verifier signals `QuorumUnreachable`, and finalize refuses a verifier with no spare witness |
| I-66 | fixed `dec484e` | The LP node never issues one barcode for two orders, nor pays one bill for two sales |
| I-67 | fixed `dec484e` | A boleto falls due inside the order's pay window: the LP node asks for that date and the SDK and wallet refuse a later one |
| I-68 | fixed `687e02c` | A pending ruling is replaced only after the arbitrator who posted it is revoked |

## Tests and the v6 deployment

All figures are from a clean clone of the bundle at `audit-freeze-2026-10-27-v6.1`, after `npm ci` and the pinned Foundry.

| Check | Result |
|---|---|
| `npm ci` | succeeds on the clean clone |
| `forge build` (root, `protocol/contracts`, `packages/smart-account/contracts`) | all three compile |
| `npx tsc --noEmit` | no errors |
| `forge test` | 103 suites, 1,161 tests, all pass; `packages/smart-account/contracts`: 55 tests, all pass |
| `npx vitest run` | 189 files, 2,576 tests, all pass (the anvil suites need the pinned Foundry: `bash scripts/foundry.sh`) |
| Fork rehearsal of the full deploy and finalize | 361 checks pass, 0 fail; the sleeve and the pair on the same fork: 19 and 62 pass, 0 fail |

**The v6 deployment (Sepolia, 27 October 2026).** Deployed by `0xEAB314D8E5B0AFe05ade6C2097b09016942fBF26` in 63
transactions, then finalized by ossifying (N-04). Addresses, transaction hashes and the per-contract source check are
in [audit-freeze.md](audit-freeze.md).

- **Rail:** 23 contracts (now with the external `RulingLib` and `SafeTransferLib`), all running the frozen build (build
  hash `04ec2733…f428`). After finalization 361 checks pass, 0 fail, and 8 are expected (the FX market was closed). The
  privilege inventory classifies 230 functions, 0 unknown. Governor Safe `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`
  (2 of 3); the Entrypoint owner is the 7-day TimelockController `0x2247f974Be28177E1ca7E1DE6D4eaeE410a96e38`.
  Record: `deployments/sepolia-movva-v6-rail/VERIFICATION.md`.
- **Hedge sleeve:** `deployments/sepolia-v6-hedge-sleeve.json`. Every check passes.
- **Permissionless pair:** `deployments/sepolia-movva-v6-permissionless.json`. 125 checks pass, 0 fail.
- **Account contracts:** PasskeyCoSignerValidator (I-31), KernelAvatarAdapter (I-32) and AuditGrantRegistry (I-30)
  redeployed (`deployments/sepolia-account-stack-v6.json`). FrostValidator, OwnerlessPaymaster and ShieldedNoteLog are
  unchanged and kept.
- **Ossified:** 11 governed contracts (8 rail, 2 pair, 1 sleeve), checked on chain; a chain scan found no governed
  contract outside them. The reserve's guardian Safe is kept (N-03, N-28).
- **Source:** all 31 new contracts are verified on Etherscan, and `scripts/compare-deployed.py` finds each identical to
  the frozen build.
- **Test identities (N-18):** Sepolia keeps its test witnesses, arbitrator, LP, ASPs and treasury. Mainnet refuses them.

## Requests from the auditors

- **Live infrastructure test.** No Movva service is publicly hosted for Sepolia v6: the co-signer, LP node, relayer,
  bundler and ASP run locally for tests, and the app is built locally. When hosts are up, the operator will send the
  URLs and a signed authorisation with a time window.
- **Bank-side txid test.** It needs each LP's real bank account and Pix API access. It will be run with the first LP
  before mainnet, and the result sent.
