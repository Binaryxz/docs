# Audit freeze, 27 October 2026 (v6)

For the client's auditors and the next audit. It names the commit to audit and the final addresses on Sepolia, says
contract by contract whether the code at each address is the code in that commit, and lists the finalization
transactions. It supersedes the v5 freeze of the same day (`audit-freeze-2026-10-27`, `6bcac7b`): v6 carries the
code fixes for every v2.0 and v3.1 finding that v5 answered without code ([audit-response-2026-10-27.md](audit-response-2026-10-27.md)).

**Sepolia is a test deployment, finalized with test identities (N-18).** Its zkTLS witnesses, arbitrator, LP and
gateway, ASPs, treasury and the governor Safe's owners are keys derived from a test seed. Finalizing kept them: an
ossified contract takes no new witness, arbitrator, LP or recipient, so this rail can never become a production rail.
Mainnet refuses any test identity. The full list is in `deployments/sepolia-movva-v6-rail.json` (`finalize.testKeys`).

## The commit

The frozen commit is the git tag **`audit-freeze-2026-10-27-v6.1`** on branch `phase-1-shielded-rail`. It adds three
TypeScript fixes to `audit-freeze-2026-10-27-v6` (L-07 for Safe accounts, I-56 for sub-wallets, I-57's anchor at the
note vault) and no contract change. Every contract of
the v6 rail, its sleeve, its permissionless pair and the three redeployed account contracts was deployed from commit
`0c4b828` or later, and no contract source changed after it:
`git diff 0c4b828 audit-freeze-2026-10-27-v6.1 -- contracts protocol/contracts/src packages/smart-account/contracts/src packages/smart-account/fixtures`
is empty. The commits after `0c4b828` change deployment tooling, records, tool defaults and documentation only.

The delivery is a git bundle, not a zip: `git clone movva.bundle movva && cd movva && git checkout audit-freeze-2026-10-27-v6.1`
gives this commit exactly, and `npm ci` runs on it.

## Rebuilding and checking it

```bash
git checkout audit-freeze-2026-10-27-v6.1
npm ci                                            # creates the library links the Foundry projects need
eval "$(bash scripts/foundry.sh export)"          # the pinned Foundry
forge build && (cd protocol/contracts && forge build) && (cd packages/smart-account/contracts && forge build)
forge test                                        # 103 suites, 1,161 tests, all passing at the freeze
(cd packages/smart-account/contracts && forge test)   # 4 suites, 55 tests
npx vitest run                                    # TypeScript: 189 files, 2,576 tests, all passing at the freeze
RPC_URL=<a Sepolia node> python3 scripts/compare-deployed.py \
  deployments/sepolia-movva-v6-rail/etherscan-verify.sh \
  deployments/sepolia-v6-hedge-sleeve/etherscan-verify.sh \
  deployments/sepolia-movva-v6-permissionless/etherscan-verify.sh \
  deployments/sepolia-account-stack-v6/etherscan-verify.sh \
  deployments/sepolia-account-stack-frost-v2/etherscan-verify.sh \
  deployments/sepolia-account-stack/etherscan-verify.sh
```

The rail's own record does more: `deployments/sepolia-movva-v6-rail/VERIFICATION.md` has every source hash, the
creation code and constructor arguments of each creation transaction, a privilege inventory of every function (230
classified, 0 unknown), and 361 passing checks after finalization (0 failing; 8 expected, because the FX market was
closed). Every v6 contract is source-verified on Etherscan (`etherscan-verified.json` in each record directory: 23 of
23, 2 of 2, 3 of 3, 3 of 3).

## The v6 rail, finalized

Deployed on 27 October 2026 from `0xEAB314D8E5B0AFe05ade6C2097b09016942fBF26`, in 63 transactions, and finalized by
ossifying in one more (block 12004872).

- **Governance (I-36, I-53):** `DelayedGovernance` hands over in two steps after setup (`transferGovernor`, then
  `acceptGovernor`), and each handover clears the previous governor's queue (`governanceEpoch`). Every governed
  contract's governor was the 2-of-3 governor Safe `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1` before setup closed
  (M-07); the Safe closed setup, then **ossified** every governor at finalization (N-04). An ossified contract refuses
  every risk-increasing change for good; the Safe keeps only its instant, risk-reducing ones. Nothing was renounced.
- **The Entrypoint's `OWNER_ROLE`:** held only by the 7-day `TimelockController` `0x2247f974Be28177E1ca7E1DE6D4eaeE410a96e38`,
  whose proposer and executor is the governor Safe and whose cancellers are the Safe and the guardian Safe (H-02,
  N-19). The deployer holds no Entrypoint role.
- **The reserve:** principal-locked, with fees now taken in USDT outside the principal (N-27) and a sunset sweep of
  what is left once supply has been zero for 365 days (N-25). Its guardian Safe `0xd67DDA7D07CAa45d6f8e7C1dD0a170585e6B086c`
  is kept (N-03, N-28). The keyless exit (N-01, N-02) is live.
- **The ramp:** both escrows link the external `RulingLib` and `SafeTransferLib`. Offers can carry a taker gate (H-04);
  the zkTLS verifier binds the claim's owner, time and witness epoch (I-22), and finalize refused to run without a
  spare witness (I-65).
- **Before ossifying (M-18):** the unused ETH pool was wound down and removed; the Entrypoint held no fees.
- **Covered by finalization (M-19):** the rail's 8 governed contracts, the permissionless pair's 2 escrows and the hedge
  sleeve's sub-wallet: 11 contracts; a chain scan found none outside them. Before ossifying, the inventory passed
  77/77 privilege checks and 29/29 exact-set checks. The sleeve's keeper stays a trade-only key (`0x4D0d…8853`).

| Transaction | Hash |
|---|---|
| governor Safe setup batch (9 calls) | `0xb4698b24c66aad1adf5020e6a2e9e13bee221669b2135e6b4e931adac9bac416` |
| Entrypoint.windDownPool (upstream's ETH pool) | `0x6bcaa15eb95876ae1025f34b35c15c6173dad7dc38d4c18b0c16765adde1f0bc` |
| Entrypoint.removePool (upstream's ETH pool) | `0x4a600844c5fbc8b81bb2d43427606ddc05e0da1616e478dc73c7810f0bb9401b` |
| create EntrypointTimelock (7 days; proposer and executor: the Safe; cancellers: the Safe and the guardian Safe) | `0xb894d90598493fbd4714af2d5685d13e4023ca0e29be91b290fd7afd9e127b4a` |
| Entrypoint.grantRole OWNER_ROLE EntrypointTimelock | `0x1cbfc9f8b7ecd9977812e32f5de3d2e9f7619c2d3bb2a87850cb307051c45713` |
| Entrypoint.renounceRole OWNER_ROLE deployer | `0x0a7a258bfc900de5d130e7a0039f6c043786e42a3719d34b759561875c64ce73` |
| sleeve: HedgeSubWallet.completeSetup() by the governor Safe | `0xb283b99fd56d3cbc8bc8940142d6867359252bfb5a55f13a60e25dcc550f7dcd` |
| permissionless pair: completeSetup() on both escrows by the governor Safe | `0x39f6f78624aaae335f6269b9e819c350f6ac7aeabc47443494341aa593a39372` |
| governor Safe: 11 ossify calls (8 rail, 2 pair, 1 sleeve) | `0xed4cfe99e9820d26b8fa76a810c7a0ea4d8558ae0915277b3cf89eeedb3207e2` |

## Every contract on Sepolia, against the frozen source

**The v6 rail (27 October 2026)** (`deployments/sepolia-movva-v6-rail/`)

| Contract | Address | Matches the frozen source | Note |
|---|---|---|---|
| ERC1967Proxy | [`0xe5e3442940D997De3F8584aD0687C925C7178c3f`](https://sepolia.etherscan.io/address/0xe5e3442940D997De3F8584aD0687C925C7178c3f#code) | yes, byte for byte |  |
| Entrypoint | [`0x3EA6De4f683f5B02D7C68339d36C2D3fB8c2F6c3`](https://sepolia.etherscan.io/address/0x3EA6De4f683f5B02D7C68339d36C2D3fB8c2F6c3#code) | yes, byte for byte |  |
| WithdrawalVerifier | [`0xDCD3cA51E0C69Bf516eE485E4c1b543E0F1028C6`](https://sepolia.etherscan.io/address/0xDCD3cA51E0C69Bf516eE485E4c1b543E0F1028C6#code) | yes, byte for byte |  |
| CommitmentVerifier | [`0x4F52A6Eac236725ee7d4bCDd247b89c1f496Fd68`](https://sepolia.etherscan.io/address/0x4F52A6Eac236725ee7d4bCDd247b89c1f496Fd68#code) | yes, byte for byte |  |
| PrivacyPoolSimple | [`0x43697fFB82471b2becA56135a9A1FBd228d34703`](https://sepolia.etherscan.io/address/0x43697fFB82471b2becA56135a9A1FBd228d34703#code) | yes, byte for byte |  |
| PoseidonT3 | [`0x8ffdA7Ed8B4aD98C2C34f54B76821711F4a6f2C5`](https://sepolia.etherscan.io/address/0x8ffdA7Ed8B4aD98C2C34f54B76821711F4a6f2C5#code) | yes, byte for byte |  |
| PoseidonT4 | [`0xe393dd7287Db9982e6f845824854Baf8b8e823AF`](https://sepolia.etherscan.io/address/0xe393dd7287Db9982e6f845824854Baf8b8e823AF#code) | yes, byte for byte |  |
| OwnedTetherLike | [`0x1931A0c8de3D7bFa68a1106dF269983304eb4960`](https://sepolia.etherscan.io/address/0x1931A0c8de3D7bFa68a1106dF269983304eb4960#code) | yes, byte for byte | Sepolia stand-in USDT (N-15). |
| MovvaReserve | [`0x0E6b613E8F52036A51CdAa9A309419782d35848c`](https://sepolia.etherscan.io/address/0x0E6b613E8F52036A51CdAa9A309419782d35848c#code) | yes, byte for byte |  |
| Movva | [`0xa849B93B5ec04bb1b979faE8B82F8Fb66663AAD7`](https://sepolia.etherscan.io/address/0xa849B93B5ec04bb1b979faE8B82F8Fb66663AAD7#code) | yes, byte for byte |  |
| PythFxOracle | [`0x9E87487Af7Af6ab3959CB790dE52A52fa5e32047`](https://sepolia.etherscan.io/address/0x9E87487Af7Af6ab3959CB790dE52A52fa5e32047#code) | yes, byte for byte |  |
| ScaledFxBandOracle | [`0x78036B4deE6ebAe7aBFCaa355E84ab3C579035F8`](https://sepolia.etherscan.io/address/0x78036B4deE6ebAe7aBFCaa355E84ab3C579035F8#code) | yes, byte for byte |  |
| FeeSplitter | [`0x37c5232936F71533f1ee3Fc104A9Baf0DEdFB640`](https://sepolia.etherscan.io/address/0x37c5232936F71533f1ee3Fc104A9Baf0DEdFB640#code) | yes, byte for byte |  |
| NodeRewards | [`0x8BB79778Bf55ca02803E5bEcCC3e1d5bD1488EE2`](https://sepolia.etherscan.io/address/0x8BB79778Bf55ca02803E5bEcCC3e1d5bD1488EE2#code) | yes, byte for byte |  |
| PrivacyPoolComplex | [`0xfe04F27A763e6a0CFcC2877a08e738e5068cbBB2`](https://sepolia.etherscan.io/address/0xfe04F27A763e6a0CFcC2877a08e738e5068cbBB2#code) | yes, byte for byte |  |
| EntrypointTimelock | [`0x2247f974Be28177E1ca7E1DE6D4eaeE410a96e38`](https://sepolia.etherscan.io/address/0x2247f974Be28177E1ca7E1DE6D4eaeE410a96e38#code) | yes, byte for byte |  |
| AspRootQuorum | [`0x547a0BcDcB8104396bA1c3D2EA7C6A14684e8F96`](https://sepolia.etherscan.io/address/0x547a0BcDcB8104396bA1c3D2EA7C6A14684e8F96#code) | yes, byte for byte |  |
| RulingLib | [`0xC18B90Ada8896EA302647c1729F1EdA0c9c700Af`](https://sepolia.etherscan.io/address/0xC18B90Ada8896EA302647c1729F1EdA0c9c700Af#code) | yes, byte for byte | External library, linked by both escrows (EIP-170 room). |
| SafeTransferLib | [`0x2741827E1Dc20B892370c4703dD060e344A9C22E`](https://sepolia.etherscan.io/address/0x2741827E1Dc20B892370c4703dD060e344A9C22E#code) | yes, byte for byte | External library, linked by both escrows. |
| LPRegistry | [`0xC2c28C7E0a123816BF5ECE680FC19fBb4a6b8F0a`](https://sepolia.etherscan.io/address/0xC2c28C7E0a123816BF5ECE680FC19fBb4a6b8F0a#code) | yes, byte for byte |  |
| ReclaimZkTlsVerifier | [`0xdB87f0170Ef6bad9805Cd7203e793e9F4dacD74e`](https://sepolia.etherscan.io/address/0xdB87f0170Ef6bad9805Cd7203e793e9F4dacD74e#code) | yes, byte for byte |  |
| FiatEscrow | [`0xDe2e82559127CBEFB4F19E219190AC15D9Ce1456`](https://sepolia.etherscan.io/address/0xDe2e82559127CBEFB4F19E219190AC15D9Ce1456#code) | yes, byte for byte |  |
| OffRampEscrow | [`0xCD95EC2aF9fA84Ab588F4279C86e8e8c4449606d`](https://sepolia.etherscan.io/address/0xCD95EC2aF9fA84Ab588F4279C86e8e8c4449606d#code) | yes, byte for byte |  |

**Its hedge sleeve: Mova's own capital (27 October 2026)** (`deployments/sepolia-v6-hedge-sleeve/`)

| Contract | Address | Matches the frozen source | Note |
|---|---|---|---|
| SimHedgeVenue | [`0x72366bd20702690a68ca4673e8a87b00f3cdda3b`](https://sepolia.etherscan.io/address/0x72366bd20702690a68ca4673e8a87b00f3cdda3b#code) | yes, byte for byte | Test-only simulated venue. |
| HedgeSubWallet | [`0x04e307c1700062bb78f12f9ae0836060e7aa6e6a`](https://sepolia.etherscan.io/address/0x04e307c1700062bb78f12f9ae0836060e7aa6e6a#code) | yes, byte for byte |  |

**The permissionless LP registry and its escrow pair (27 October 2026)** (`deployments/sepolia-movva-v6-permissionless/`)

| Contract | Address | Matches the frozen source | Note |
|---|---|---|---|
| PermissionlessLPRegistry | [`0xA28eDb528bC06458F93bb5242091fF2c1109a46B`](https://sepolia.etherscan.io/address/0xA28eDb528bC06458F93bb5242091fF2c1109a46B#code) | yes, byte for byte |  |
| FiatEscrow | [`0x8B9374a252cce0a72403E74C94Dfdd079c709Fee`](https://sepolia.etherscan.io/address/0x8B9374a252cce0a72403E74C94Dfdd079c709Fee#code) | yes, byte for byte | Links the rail's RulingLib and SafeTransferLib. |
| OffRampEscrow | [`0x33897ABf9506913A494e67899f72D39Ae65b24FE`](https://sepolia.etherscan.io/address/0x33897ABf9506913A494e67899f72D39Ae65b24FE#code) | yes, byte for byte | Links the rail's RulingLib and SafeTransferLib. |

**The account contracts the v2.0 fixes changed (27 October 2026)** (`deployments/sepolia-account-stack-v6/`)

Redeployed by `scripts/redeploy-account-contracts.ts`, each through the Arachnid CREATE2 deployer with salt 0. New
accounts use them; the app's canonical pin names them.

| Contract | Address | Matches the frozen source | Note |
|---|---|---|---|
| PasskeyCoSignerValidator | [`0xd8E6C075F042874d97c72d6324C9FfA4f687FcDD`](https://sepolia.etherscan.io/address/0xd8E6C075F042874d97c72d6324C9FfA4f687FcDD#code) | yes, byte for byte | Binds the RP ID and origin on-chain (I-31). |
| KernelAvatarAdapter | [`0x28093B0879DA221B9db507533709b32a89000b5B`](https://sepolia.etherscan.io/address/0x28093B0879DA221B9db507533709b32a89000b5B#code) | yes, byte for byte | A queued passkey-only call can only rotate a key (I-32). |
| AuditGrantRegistry | [`0x9D8c8564d6A7fA58e4Fb0B912E0E685ab2e8Cb14`](https://sepolia.etherscan.io/address/0x9D8c8564d6A7fA58e4Fb0B912E0E685ab2e8Cb14#code) | yes, byte for byte | Anchors only extend the stored head (I-30). |

**The corrected FrostValidator (20 October 2026)** (`deployments/sepolia-account-stack-frost-v2/`)

| Contract | Address | Matches the frozen source | Note |
|---|---|---|---|
| FrostValidator | [`0xBb6Bb2779FAd749F87342d7E471513272c901158`](https://sepolia.etherscan.io/address/0xBb6Bb2779FAd749F87342d7E471513272c901158#code) | yes, byte for byte |  |

**The account stack (14 October 2026)** (`deployments/sepolia-account-stack/`)

| Contract | Address | Matches the frozen source | Note |
|---|---|---|---|
| PasskeyCoSignerValidator | [`0x7Ecc6B0edF79CACC4DaB559830111cC1c8702990`](https://sepolia.etherscan.io/address/0x7Ecc6B0edF79CACC4DaB559830111cC1c8702990#code) | **no** | Superseded by the v6 one above; accounts already created keep it. |
| FrostValidator | [`0x58997113b2572F9Bc6ca243a0Ffff0C1924AB223`](https://sepolia.etherscan.io/address/0x58997113b2572F9Bc6ca243a0Ffff0C1924AB223#code) | **no** | Superseded by the corrected FrostValidator above. |
| KernelAvatarAdapter | [`0x8214602c7991b48dEa1A5Cd58b06dCCF7840fAb0`](https://sepolia.etherscan.io/address/0x8214602c7991b48dEa1A5Cd58b06dCCF7840fAb0#code) | **no** | Superseded by the v6 one above. |
| OwnerlessPaymaster | [`0x98a488006bB816a03930Edfec76Fda95a8ee069d`](https://sepolia.etherscan.io/address/0x98a488006bB816a03930Edfec76Fda95a8ee069d#code) | **no** | Kept: unchanged source, built at 1,000 optimizer runs (below). Redeploying would lock another 1 ETH stake. |
| AuditGrantRegistry | [`0x8BcCa7574d7A87Ea225DFB4ab1Ced6947e33414A`](https://sepolia.etherscan.io/address/0x8BcCa7574d7A87Ea225DFB4ab1Ced6947e33414A#code) | **no** | Superseded by the v6 one above. |
| ShieldedNoteLog | [`0x9eE65d4b3B55A545721138B814d1227e7DFdB1a5`](https://sepolia.etherscan.io/address/0x9eE65d4b3B55A545721138B814d1227e7DFdB1a5#code) | **no** | Kept: unchanged source, built at 1,000 optimizer runs (below). |

`compare-deployed.py` masks immutables, linked-library slots and a library's own address (its runtime starts with
`PUSH20 <address>`), so the Poseidon libraries and the two ramp libraries compare byte for byte.

The account stack's OwnerlessPaymaster and ShieldedNoteLog were built on 14 October at 1,000 optimizer runs. The
frozen commit builds the root project at 200 (`foundry.toml`: FiatEscrow needed the room), so `compare-deployed.py`
reports them as different. Their sources are unchanged; rebuilt at 1,000 runs (`FOUNDRY_OPTIMIZER_RUNS=1000 forge build`)
ShieldedNoteLog matches byte for byte and the paymaster's code matches.

## The earlier rails

The rails of 6, 15 and 20 October 2026, the v3 and v4 rails of 21 October and the v5 rail of 27 October
(`deployments/sepolia-movva-v5-rail.json`, tag `audit-freeze-2026-10-27`) are superseded and kept as records. v5 is
ossified, so it cannot take the v2.0 code fixes: v6 is a new rail.
