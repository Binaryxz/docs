# Runbook - the Movva hedge desk

For the issuer's treasury and hedge desk. Movva is R$ 1,00 backed by USDT; the peg holds only while
the issuer keeps the reserve's dollar exposure sold on B3 and moves cash between the hedge account
and the reserve when USD/BRL moves (docs/movva.md). This runbook is the daily routine, statement
publication, what to do on each monitor alert, and a worked 2024-size shock.

**Market hours.** The reserve's rate is Chainlink USDT/USD crossed with Pyth's FX.USD/BRL, and it refuses
once the FX leg is older than `fxMaxAge` (an hour), at any hour. Pyth publishes FX.USD/BRL only on
weekdays, 08:00-17:00 New York time, and the oracle's core session - when it is certainly trading - is
13:30-21:00 UTC, 10:30-18:00 in Brasília. So everything this runbook sizes from reads the strict rate and
refuses outside market hours: `collateralRatioBps`, `liabilitiesUsdt`, `surplusBrlE18`, the previews, and
`withdrawToHedge` itself. Take snapshots, plans, shock checks and statements inside
the core session, after the keeper's latest post. Off-hours `bandBrlPerUsdtE18()` returns the last close,
stamped current: use it to watch the reserve and for nothing else. Never size a hedge, sign a statement or
plan a withdrawal from it - a weekend's move is not in it, and B3 reopens at the real rate.

Tooling: `packages/movva` (`movva-desk`), and the monitor's `movva_*` checks (`packages/ops`). All
commands below assume

```
export RPC_URL=https://<archive-capable RPC> MOVVA_RESERVE=0x<reserve> CHAIN_ID=1
export MOVVA_DESK_CONFIG=/etc/movva/desk.json MOVVA_STATEMENT_DIR=/srv/movva/statements
export MOVVA_STATEMENT_ISSUER=0x<statement key address>
alias movva-desk='node --import tsx packages/movva/src/bin/movva-desk.ts'
```

**Nothing in this runbook sends a transaction from a script.** Treasury moves are plans signed by
the treasurer multisig; the only key the desk tooling ever reads is the statement key, on the
signing machine, for `statement sign`.

## Facts to confirm before the first trade

The tooling defaults below stand for facts about B3, the broker and the deployed reserve. Each is
**to confirm**; set the confirmed value in `desk.json` and in the monitor's environment.

| Fact | Default | Status |
|---|---|---|
| DOL contract size | US$ 50,000 | B3 product page (read 14/09/2026); **to confirm with the broker** |
| WDO contract size | US$ 10,000 | B3 product page (read 14/09/2026); **to confirm with the broker** |
| Quote convention, tick | R$ per US$ 1,000; R$ 0,50 | B3 product pages; to confirm how the broker statement prints average price |
| Expiry, last trading day | 1st business day of the month; the session before | B3 product pages; **to confirm** the broker's roll cut-off |
| DOL standard lot | 5 contracts | B3 product page; **to confirm** whether odd lots are available to this account |
| Initial margin | 10% of notional (`initialMarginBps` 1000) | **Placeholder. To confirm**: B3's margin model plus the broker's add-on |
| When daily settlement (ajuste) is debited / credited | assumed next business day | **To confirm with the broker** |
| Fees, exchange charges, taxes on futures results | not modelled | **To confirm** (broker, accountant) |
| Position limits for the account | not modelled | **To confirm with the broker** |
| USDT/BRL conversion cost | 30 bps (`conversionCostBps`) | **To confirm** from the issuer's OTC quotes, and the time a conversion takes |
| Reserve 24h `withdrawToHedge` limit and window | 2% of `totalUsdt`, rolling 24h | **To confirm against the deployed reserve** - the interface has no view of it |
| Hedge policy band | ±2% (`hedgeBandBps` 200) | Issuer policy, still to decide (docs/movva.md) |

USD/BRL for the 2024 preset is verified: PTAX venda R$ 4,8413 on 29/12/2023 and R$ 6,1923 on
31/12/2024 (Banco Central do Brasil PTAX service), +27.90% over the year.

## Daily routine

Times are Brasília. The statement reconciles the broker's end-of-day position against one reserve
block, so it is produced after the broker's statement for day D is available. Any step that reads the
reserve's rate refuses outside the core session (after 18:00 Brasília, and at weekends): take the day's
snapshot before 18:00, and if the broker's statement arrives later, finish the rest at the next core session.

1. **Snapshot the reserve.** `movva-desk snapshot --text`, then save the JSON:
   `movva-desk snapshot > snapshots/D.json`. Check `INCONSISTENT` lines: there must be none. If
   `rate REFUSED` appears, see `movva_rate` below and stop - nothing is planned against an unpriced
   reserve. Outside the core session that is the market closed: snapshot again inside it.
2. **Transcribe the broker statement** into `positions/D.json` (instrument, ticker, expiry, side,
   contracts, average price as printed, in reais per US$ 1,000). **Two people**: one transcribes,
   the other checks against the PDF. The PDF's SHA-256 goes into the statement, so keep the file.
3. **Hedge plan.** `movva-desk hedge-plan --snapshot snapshots/D.json --positions positions/D.json --text`.
   Orders appear only when the hedge ratio is outside the band; send them to the broker for the next
   session. Roll notes appear five days before expiry.
4. **Shock check.** `movva-desk shock --positions positions/D.json --text` (against the chain, so
   today's `WithdrawnToHedge` count is used). Read the `+5%` block: if it says `NOT COVERED`, the
   issuer capital line is the free margin to have at the broker **before** the next session (see
   the walk-through for why this is the normal state at the target ratio).
5. **Sign the statement** on the signing machine:
   ```
   MOVVA_STATEMENT_KEY_FILE=/run/secrets/movva_statement movva-desk statement sign \
     --positions positions/D.json --broker-doc broker/D.pdf \
     --margin-balance 1249000.00 --margin-required 999000.00
   ```
   It reads the latest statement from `MOVVA_STATEMENT_DIR` as the previous one, verifies what it
   signed against the chain before writing it, and writes `statement-<sequence>.json` and
   `latest.json`. It refuses to overwrite or fork an issued sequence.
6. **Publish** `latest.json` and the new `statement-<sequence>.json` at the issuer's statement URL
   (the monitor's `MOVVA_STATEMENT_URL`), and the report:
   `movva-desk report --out reports/D.json --text`.
7. **Move cash if needed** (below): withdraw to meet margin, or recapitalize with hedge gains.

Statements are expected daily; the monitor fails `movva_hedge_statement` after 26 hours.

### Statement publication rules

- **Never replace a published statement.** A mistake is corrected by the next statement, with a
  note in the issuer's publication. The monitor fails when a sequence it has seen changes hash, or
  the published sequence goes backwards.
- **Never skip a sequence** and never sign with a key other than the published issuer address.
- **Keep every broker PDF** whose hash was signed: it is what an auditor checks the figures against.
- **Statement key compromise**: publish the new issuer address through the issuer's own channels,
  update `MOVVA_STATEMENT_ISSUER` in the monitor, and start a new chain (sequence 1) with the new
  key, with the old key's last statement hash noted in the announcement.

## Moving cash

### The dollar rose: margin call at the broker

`withdrawToHedge` prices at the rate, so it refuses outside the core session. A margin call due before
10:30 Brasília is met from free margin at the broker or issuer capital, and withdrawn once the rate is
fresh. Signing must finish inside the core session too: a plan simulated at 17:30 Brasília and executed
after 18:00 reverts.

1. `movva-desk withdraw-plan --amount <USDT needed> --from <treasurer multisig> --safe > plans/withdraw-D.json`
   (omit `--amount` for the most allowed). It refuses (exit 3) rather than trims an amount over the
   floor ratio (at a rate 0.5% worse, for the hours signing takes) or the 24h limit.
2. Check `simulation` is `{ "ok": true }`. A revert here means the deployed limit or state differs
   from the plan: do not collect signatures.
3. Signers compare `plan.hedgeTreasury` with the deployment record, import `safeBatch` into the Safe,
   and execute.
4. Convert the USDT at the hedge treasury to reais and deposit at the broker.
5. Whatever `withdrawToHedge` cannot cover is issuer capital - deposit it the same day.

### The dollar fell: bring hedge gains back

1. `movva-desk recap-plan --from <sender holding the USDT> --safe > plans/recap-D.json`. Default:
   what restores the target ratio at a rate 0.5% worse. The plan zeroes the USDT allowance first
   when needed (Tether's `approve` refuses non-zero to non-zero). The amount is priced at the rate, so
   plan inside the core session; `recapitalize` itself does not read the rate and lands at any hour.
2. Buy the USDT with the hedge's settled gains, execute approve + recapitalize from the sender.
3. Until this lands the reserve is under 100%: redeem pays the ratio and mint halts. Speed matters
   more here than on the other side.

## Monitor alerts

Enable with `MOVVA_RESERVE`; the statement check with `MOVVA_STATEMENT_URL` (or `_FILE`) and
`MOVVA_STATEMENT_ISSUER`. Set `MOVVA_HEDGE_BAND_BPS`, `MOVVA_WITHDRAW_DAILY_LIMIT_BPS`,
`MOVVA_INITIAL_MARGIN_BPS`, `MOVVA_CONVERSION_COST_BPS`, `MOVVA_SHOCK_BPS` and
`MOVVA_STATEMENT_MAX_AGE_SECONDS` to the same values as `desk.json`. `MOVVA_STATEMENT_URL` is
treated as a secret (it may carry a token) and redacted.

### `movva_collateral_ratio`

| Level | Meaning | Do |
|---|---|---|
| ok | At or above target | Nothing |
| warn | Below target (108%); below `minMintCollateralRatioBps`, mint is refused too | Usually the dollar fell. Check the hedge gains; `recap-plan` and execute today |
| fail | Below 100%: redeem pays the ratio, mint refused | Recapitalize now - from hedge gains if settled, otherwise issuer capital, reimbursed when gains settle. If the hedge did not gain (hedge ratio low, or no hedge), say so publicly: holders redeeming now take the haircut |
| fail (refuses) | The reserve cannot compute its ratio | The rate is stale: see `movva_rate`. Outside the core session, expected |
| unknown | The RPC failed | Check the RPC; not a reserve problem |

### `movva_rate`

| Level | Meaning | Do |
|---|---|---|
| warn | Rate 30+ minutes old | Inside the core session: check the Pyth keeper (gas, Pyth's update fee, Hermes access) and the Chainlink USDT/USD feed. Outside it: the market is closed; expected |
| fail (age) | 1h+ old | The reserve refuses mint, redeem and `withdrawToHedge` at its own max age. Inside the core session: get the keeper posting - anyone may post an update. Outside it: expected until the reopening |
| fail (refuses) | `brlPerUsdtE18()` reverts, e.g. `StaleLeg(leg, updatedAt)` | Mint, redeem and `withdrawToHedge` revert, so a margin call now must be met from issuer capital. Inside the core session the named leg is the one to fix; outside it, plan for the reopening |
| fail (mis-scaled) | Rate outside R$ 1-100 per USDT | The FX leg is in the wrong unit (a centavo instance where millionths belong) or an inverted quote; on a signed leg, a publisher signed centavos into the 1e-6 oracle (`signFxMicro`). Pause mint (instant), find the cause |

### `movva_hedge_statement`

| Level | Meaning | Do |
|---|---|---|
| ok | Latest statement verified: issuer signature, domain, hash, sum, freshness, snapshot matches the reserve; hedge ratio inside the band | Nothing |
| warn | Hedge ratio (statement short / today's `liabilitiesUsdt`) outside the band | Run `hedge-plan` and trade next session. After a large FX move this is expected until rebalanced |
| fail: none published / invalid | 404, missing file, not a v1 document | Publish today's statement. If the web server is serving an error page, fix it |
| fail: NOT signed by the issuer | Signature does not recover to `MOVVA_STATEMENT_ISSUER`, or for another chain/reserve | Treat as an incident: someone published a statement the issuer did not sign, or the key changed without notice |
| fail: stale | Older than 26h | Publish. A missed day is visible to everyone watching |
| fail: does not match the reserve | Snapshot block hash, rate or liabilities differ from the chain | The statement reconciled against a state that did not exist - wrong block, wrong chain, or edited figures. Publish a corrected next statement and explain |
| fail: REPLACED / BACKWARDS / does not link | A seen sequence changed, or the chain went back, or the new one links elsewhere | Someone rewrote history, or two desks signed. Stop signing, find out which statement is authentic |
| unknown | Could not fetch (network, HTTP 5xx), or the snapshot block needs an archive node | Check the URL, and the monitor RPC's archive access. On an archive failure the signature and freshness were still checked: the detail says so |

### `movva_withdraw_headroom`

How much a +5% dollar move would need in margin (variation + initial margin increase − free margin
from the latest verified statement) against what `withdrawToHedge` could release after that move
under the floor ratio and the 24h limit (net of conversion cost, minus what was withdrawn in 24h).

| Level | Meaning | Do |
|---|---|---|
| ok | Covered | Nothing |
| warn | Coverage below 100% | Pre-fund free margin at the broker by at least the "issuer would fund" amount, before the next session. At the target ratio with the proposed parameters this is the **normal** state - see below |
| warn (refuses) | The reserve cannot price, so nothing can be withdrawn | Inside the core session: a move now is met from issuer capital; fix the rate. Outside it: expected, and the free margin the check last asked for is what covers a move until the reopening, so pre-fund it before the close |
| unknown | RPC failure | Check the RPC |

Without a verified statement the check assumes the hedge equals `liabilitiesUsdt` with no free
margin, and says so.

(`movva_distribution`, the check on the Movva distribution keeper, was removed with savings by client decision D1,
14 October 2026: the reserve no longer distributes. Its surplus above the target stays in it as backing and is Mova's,
taken out only through `withdrawToHedge` within the daily limit, or `queueHedgeWithdrawal` /
`executeHedgeWithdrawal` above it.)

## Walk-through: a 2024-size move

Numbers from `movva-desk shock --text` on `packages/movva/examples/`:

- **Reserve**: R$ 10.000.000,00 of Movva, rate R$ 5,4000 per USDT, at the 102% target:
  1,888,888.888889 USDT. Target 102%, mint floor 100%, withdraw floor 105%.
- **Hedge**: 36 DOL + 5 WDO short = US$ 1,850,000 (99.90% of US$ 1,851,851.85).
- **Margin**: balance equal to requirement (no free margin).
- **Assumptions (to confirm)**: 24h limit 2% of the reserve, none used; initial margin 10% of
  notional; USDT/BRL conversion 0.30%; futures move one-for-one with the reserve's rate; USDT = US$ 1.

| Move (one day) | Rate after | Reserve ratio after | The hedge | `withdrawToHedge` after the move | Issuer capital | Covered |
|---|---|---|---|---|---|---|
| +5% | 5,6700 | 107.10% | margin call R$ 549.450,00 | 37,037.04 USDT = R$ 209.370,00 net (**floor** binds) | R$ 340.080,00 | no |
| −5% | 5,1300 | 96.90% | releases R$ 549.450,00 = 106,783.95 USDT | needs 60,428.85 USDT to 100%, 99,415.20 to 102% | 0 | yes |
| +10% | 5,9400 | 112.20% | margin call R$ 1.098.900,00 | 37,777.78 USDT = R$ 223.726,80 net (**24h limit** binds) | R$ 875.173,20 | no |
| −10% | 4,8600 | 91.80% | releases 225,432.78 USDT | needs 168,724.28 USDT to 100%, 209,876.54 to 102% | 0 | yes |
| 2024: +27.90% | 6,9066 | 130.45% | margin call R$ 3.065.931,00 | 37,777.78 USDT = R$ 260.133,25 net (24h limit) | R$ 2.805.797,75 | no |
| 2024 reversed: −21.81% | 4,2223 | 79.75% | releases 565,931.70 USDT | needs 479,510.97 USDT to 100%, 526,878.97 to 102% | 0 | yes |

The 2024 move took a year, not a day. Over 252 sessions (`--days 252`) the 24h limit stops binding
and the floor does: at 102%, `withdrawToHedge` releases 368,603.94 USDT = R$ 2.538.162,60 against
R$ 3.065.931,00, leaving **R$ 527.768,40** of issuer capital. From a 110% reserve the same year is
covered (R$ 3.558.293,00 released). This is an upper bound on the margin: a desk rebalancing
through the year buys back as the target falls (to US$ 1,447,890.42 at R$ 6,9066), so the short is
smaller for most of the move.

### What the numbers say

1. **At the target ratio, a dollar rally is met mostly from issuer capital.** The withdraw floor
   (105%) sits above the target (102%) the reserve rests at, so nothing can be
   withdrawn until the dollar has risen 2.94% (1.05 / 1.02). At +5% the floor releases R$ 209.370
   of a R$ 549.450 call. Either keep free margin at the broker of about **3.4% of liabilities**
   (R$ 340.080 per R$ 10M) at all times, or set the withdraw floor at or below the target, or
   take surplus out only down to the floor plus a shock buffer.
2. **The 24h limit cannot cover a one-day 5% move at any ratio.** 2% of the reserve a day is 2.04%
   of liabilities at 102% and 2.6% at 130% (a little more in reais after the move); a 5% move with
   10% initial margin costs 5.5%. `movva_withdraw_headroom` warns at 38% (102%), 41% (110%) and 49%
   (130%) coverage until free margin is pre-funded. A daily limit of roughly 5% of the reserve with
   the ratio clear of the floor, or pre-funded margin, is what a one-day 5% move needs.
3. **A dollar fall is covered by the hedge, but not instantly.** The reserve is under 100% from the
   moment the rate updates until the gains are settled, converted and recapitalized - a day or
   more, during which redeem pays the ratio (96.90% at −5%) and mint halts. A standing USDT recap
   buffer at the issuer (60,428.85 USDT per R$ 10M covers −5% to 100%) closes that window, and is
   refilled from the hedge gains when they settle.
4. **The buffer above 100% is not hedged**, by design: hedge gains restore full backing, and restore
   the target at −5% only because they include released initial margin. With no initial margin
   released, the gains buy 97,076.32 USDT against 99,415.20 needed for 102%: 2,338.89 USDT of issuer
   capital.

## Suggested parameters to review with the client

From the walk-through, for the "Parameters" and "Hedge operations" items still open in docs/movva.md:
the relationship between `minWithdrawCollateralRatioBps` and `targetCollateralRatioBps`, the 24h
withdraw limit against the largest one-day move the issuer wants covered without its own capital,
a standing free-margin amount at the broker, and a standing USDT recap buffer.
