# Open questions for the client

Every decision still blocking work, collected from Rev. 3, the comments on it, the deployment instruction and the
"like Bitcoin" proposals. Each has our recommendation, so a one-word answer is enough where you agree.
Written 24 September 2026.

## A. Before the immutable deployment — these can never be changed afterwards

**A1. Who creates MOVVA: the reserve, or the escrow?**
Today the token has no owner, no settable minter, no pause and no upgrade, and its only minter is the USDT-backed
reserve — the design agreed on 14 September, where Movva is pegged to R$ 1,00 and backed by a USDT reserve. Rev. 3 §5.1
instead says the escrow mints on settlement and supply equals escrow mints minus burns. Both cannot hold. After an
immutable deployment this is permanent.
*Our recommendation: keep the reserve, and update Rev. 3 §5.1 to match, because the reserve is the backing design that
Rev. 3 defers to a separate treasury document.*

**A2. After setup, do we renounce everything, or keep the ability to revoke a leaked key?**
Renouncing every role is one command and needs no code change. The cost: nobody could ever revoke a compromised
arbitrator, zkTLS witness or attestor key, lift a pause, replace a gateway (only gateways redeem), or repoint an oracle
if a feed is retired. The escrow's own code says a stolen arbitrator key can drain every liquidity provider's offer, and
revocation is the defence.
*Our recommendation: first remove the keys (A3, A4), then renounce everything. If any key must remain, we propose a
one-way switch that permanently disables every risk-raising change while keeping revocation — that is one new function,
so we will not add it without your approval.*

**A3. Do credit cards stay out of the MVP?**
Rev. 3 removes them; the card rail is built and works. Cards are the only reason the attestor keys still exist.
*Our recommendation: confirm they stay out; we then delete the attestor quorum and its keys entirely, which completes
your "pure zkTLS, no human keys" proposal with no new technology.*
**Decided 24 September 2026: cards stay out of the MVP.** The attestor quorum, its keys and the PSP attestor service were deleted (`docs/card-rail-removal.md`).

**A4. The association-set provider: a governed contract, or one the user picks?**
Your proposal asks to remove `ASP_POSTMAN` from the Entrypoint. That role lives inside the audited Privacy Pools code,
and the pool refuses any withdrawal whose root is not the Entrypoint's latest, so removing it means editing and
re-auditing the core — which your own rule excludes. The postman is only an address, so it can point at a multisig, a
DAO or an aggregator that publishes only when several providers agree: the ASP gets its own governance, with no change
to the audited code. Letting each user choose their own ASP needs a separate pool per ASP, and users on different ASPs
would no longer share an anonymity set.
*Our recommendation: a governed ASP contract now, one anonymity set; revisit user-selectable ASPs only if you accept a
core fork and the privacy loss.*
*Note: the fallback you ask for already exists — if an ASP stops publishing, the depositor can always exit by ragequit.*

**A5. Above the daily withdrawal limit: a timelock, or a multisig?**
A multisig is an admin key, which contradicts A2. A timelock is not: the withdrawal is announced on-chain and executes
after a delay, with nobody able to approve or block it.
*Our recommendation: timelock.*

**A6. The divergence breaker: does it clear itself?**
A breaker that trips and clears on its own needs no key. One that a human must lift needs a key that survives A2.
*Our recommendation: self-clearing.*

**A7. What goes in the first deployment?**
The escrow needs the pool, the token, the registry, the oracles and the verifiers. Yield, savings and node rewards could
follow in a second deployment. *(Savings has since been removed from M1 altogether: client decision D1, 14 October 2026.)*
*Our recommendation: deploy the escrow's core first. It is a smaller review for you, and less is frozen forever while
decisions are still open.*

## B. Scope of V1 — needed to finish and test the right thing

**B1. Tier limits: keep or remove?**
Rev. 3 §12.1 gives the numbers (R$ 2.000/1.000 a day at tier 0 up to R$ 30.000/15.000 at tier 4, with retention and
withdrawal speeds). Your comments on the document say "we will remove tiers, maybe next version" and "we remove this".
The limit mechanism is built and is off unless configured, so either answer is cheap — we need to know which.
*If tiers stay: we set those numbers. If they go: we leave the mechanism unconfigured and drop retention and tiered
withdrawal speed, which were never built.*

**B2. "First the user can hold and sell USDT and burn MOVVA" — what does the V1 user hold?**
Today the user holds MOVVA, shielded; the reserve holds USDT; only a gateway redeems and burns. If V1 users hold and
sell USDT themselves, that is a different product: a shielded USDT balance and an off-ramp that takes USDT from the
user.
*We need this spelled out before building V1.*

**B3. Sub-wallets: V1 or V2, and which assets?**
Rev. 3 requires sub-wallets with independent seed phrases; your comment says moving funds between them is V2 and that
they hold "movva and others". Nothing of this is built yet.
*Our recommendation: V2, with the transfer path already built and waiting.*

**B4. The MPC: which network?**
Today the account's second key is a co-signer that Mova runs, trust-minimised but operated by one party. Your comment
asks for a "permissionless and decentralised MPC". Moving to a threshold network nobody administers changes who signs
and who pays per-signature fees.
*We need the network named, or the properties that define "permissionless" for you: anyone can run a node, anyone can
enrol, or both.*

**B5. Exchanges as a route: liquidity provider, or Mova's own float?**
"Not only P2P but CEX and DEX also". An exchange can run a liquidity provider node, which keeps escrow and the payment
proof and leaves custody with the exchange. A route where user money lands in Mova's exchange account is a custodial
float, which Rev. 3 removed. For a DEX route we would also need to know which BRL stablecoin, and who converts it to
reais.
*Our recommendation: exchanges as liquidity providers.*

**B6. One proof provider, or provider-agnostic attestation?**
Payments are proven by zkTLS today in Reclaim's format only. ZKP2P's newer design normalises several providers
(TLSNotary, Primus, Reclaim) behind one attestation.
*Our recommendation: launch with one, add the others later — unless you need provider independence from day one.*

**B7. The third price source.**
You asked for a DEX TWAP beside Chainlink and Pyth. BRL liquidity on Ethereum is thin, and a TWAP over a shallow pool is
easier to manipulate than the feed it checks.
*Our recommendation: a second signed price publisher instead of a DEX TWAP.*

**B8. The delta-neutral venue.**
Marked "we will define until Monday" in your comments; still open. The vault and keeper are built for Hyperliquid, and a
different venue means a different adapter.

## C. What we need from you to proceed operationally

1. **Sepolia ETH** for the deployer `0x4C0A…d214`, which holds none. We will confirm the exact amount from a gas
   rehearsal before you send it.
2. **An RPC endpoint without a log-range cap** (a paid Alchemy/QuickNode key or an archive endpoint), to run the full
   privilege inventory against real Sepolia.
3. **A Pyth Hermes credential and a funded keeper key.** The stale Sepolia BRL price you saw in the report does not have
   to be waited out: our own keeper posts updates, which is what it does in production.
4. **A Reclaim application credential and a provider template per bank**, without which no PIX or boleto can settle.
5. **KMS keys** for the co-signer and its sponsor operator, and a VAPID key for recovery alerts. (The zap relayer, which
   also needed one, was removed with savings: client decision D1, 14 October 2026.)
6. **Confirmation that the old Sepolia owner key is still held**, so we can renounce the roles on the abandoned
   deployment.
7. **The audit engagement:** we recommend a manual review plus a public competition and a mitigation review, as you
   proposed. [audit-scope.md](audit-scope.md) is written for the reviewer.

## D. For the record

**D1.** Your deployment instruction settles the question your document comments raised: we proceed with the **Privacy
Pools fork**, not the Kohaku SDK and Umbra. Please confirm, since that reverses the comments on §1, §2.3, §4.1 and §4.2.

**D2.** Rev. 3's data model assumes a backend database (users, orders, viewing keys). This rail has none by design:
orders live on-chain, each liquidity provider keeps its own journal, and the device holds what belongs to the user. The
invoices, QR payment requests and conversion dashboard in §12.3 depend on that backend, so they do not exist. Tell us if
they are wanted.

**D3.** Offering yield to Brazilian users, and a governance token over a treasury, each carry their own regulatory
question. Both are named in Rev. 3 as needing legal review before launch.
