# Audit readiness — what an external reviewer receives

Rev. 2 §10.2 requires an external security review of the fork deltas, the escrow contracts
and the account modules before mainnet launch. This note is what goes to the auditor with the
request for a quote, so the scoping conversation starts from facts rather than a code dump.

**The audit itself is a third-party engagement.** Nothing in this repository substitutes for
it, and the internal reviews below were written by the same party that wrote the code — which
is exactly the weakness that produced two of the findings they record.

## What to send

| Item | Where |
|---|---|
| Scope, sharp edges, and what we already believe is wrong | `docs/audit-scope.md` |
| Internal review, Phase 1 | `docs/security-review-phase1.md` |
| Internal review, Phase 2 | `docs/security-review-phase2.md` |
| Internal review, Phase 3 | `docs/security-review-phase3.md` |
| Internal review, Phase 4 (shielded transfers: a record only, the feature was removed from scope on 12 October 2026 and deleted) | `docs/security-review-phase4.md` |
| Internal review, Movva (the BRL token and its reserve) | `docs/security-review-movva.md`, design in `docs/movva.md` |
| Wallet custody and the delta-neutral vault | `docs/wallet-custody.md`, `docs/delta-neutral.md` |
| What survives each service dying | `docs/availability.md` |
| What is deployed and verified on a public chain | `docs/deployments.md` |
| Security tooling: versions, commands, coverage and every finding triaged | `docs/security-tooling.md` |
| How to run every check | `TESTING.md` |
| Upstream provenance | `protocol/FORK.md`, and `npm run verify` |

## Freeze the commit first

Audit a tag, not a branch. A moving `HEAD` means the report describes code that no longer
exists, and re-auditing the delta costs more than getting this right once.

```bash
git tag -a audit-1 -m "Frozen for external audit" <commit>
git push origin audit-1
```

Deploy that same tag to mainnet. If a finding forces a change, the fix is re-reviewed and the
tag moves — deliberately, with the auditor's sign-off, not quietly.

## What the auditor can verify without us

- **The fork is upstream's, unmodified.** `npm run verify` diffs it against a fresh clone and
  hash-checks all 14 zk artifacts; all three circuits recompile to byte-identical R1CS.
- **The tests pass on a clean machine.** CI runs them on every push.
- **The deployed bytecode matches the source.** Every Sepolia contract is verified on
  Etherscan.

That covers provenance and reproducibility, so the engagement can spend its hours on
judgement rather than on setup.

## Where we would spend the budget

In this order, which is also the order of what would hurt most if wrong:

1. **`packages/mpc` and `contracts/SchnorrVerifier.sol`.** From-specification cryptography,
   written once, unaudited. Everything else is either upstream's audited code or application
   logic where a bug costs correctness; here a subtle mistake costs the key.
2. **`MovvaReserve` and the rate it mints at.** The first contract here that creates money: it
   mints and redeems Movva at Chainlink USDT/USD crossed with Pyth's FX.USD/BRL (`PythFxOracle`, posted
   by Mova's keeper), against a USDT reserve whose dollar exposure is hedged off-chain. Attack the rate
   (a wrong number is value, not a nuisance, here); the off-hours split, where everything that moves
   value refuses a stale rate while the band (`brlCentsPerUnit`, `bandBrlPerUsdtE18`, through `BandRead`)
   takes the last close outside `FxMarketHours`' core session (SR2-35, SRM-15); the ratio rules,
   rounding under Aave, and Tether freezing the reserve. The feed and its limits - or a signed leg's
   publishers - change only through the governance delay (SR2-30): challenge that too.
3. **The escrow release paths.** `FiatEscrow` and `OffRampEscrow` decide when money leaves.
   Both high-severity findings in Phase 2 were here, and both were in the *escape hatch*
   rather than the happy path. Since SR2-34 both
   escrows open a PIX, boleto or TED offer or sale only on a verifier that proves the bank session
   (`provesBankSession`, `BankRailNeedsZkTls`); the card rail and the attestor quorum were removed on 24 September 2026
   (`docs/card-rail-removal.md`). Attack that check: it is what stands between a colluding quorum and an LP's escrow.
4. **`YieldVault`**, which holds the Movva reserve's idle USDT and prices assets that can lose
   value. Phase 3's findings were both on exit paths. (`ShieldedYieldRouter`, which zapped users'
   shielded balances into the vault, was removed with savings by client decision D1, 14 October 2026.)
5. **Our use of the fork** — `reconcile.ts` and `pool/indexer.ts` — where two real bugs have
   already been found, both from our model disagreeing with the chain.

## Dependency advisories (`npm audit`)

Every finding comes from the vendored fork under `protocol/` or from build and test tooling;
none is in a package this repository wrote. The ones that mattered were in `protocol/relayer`,
because that workspace is the only dependency tree here that a stranger can reach over HTTP —
it is an Express service (`protocol/relayer/src/app.ts`) with a SQLite store.

The fix is **npm `overrides` in the root `package.json`**. Nothing under `protocol/` changes, so
`scripts/verify-protocol.sh` (check 2, and CI's provenance job) still reports the fork
byte-identical to upstream `c312dcd5`. Each override is the lowest version that clears its
advisory, on the major line the fork was written against.

| Override | Replaces | Clears | Reachable from a request? |
|---|---|---|---|
| `express ^4.22.3` | 4.21.2 | `express` high — stays on the 4.x line, no jump to 5 | Yes — every route |
| `path-to-regexp ^0.1.13` | 0.1.12 | ReDoS via multiple route parameters (high) | Route table only, and it has **no** parameterised routes: `/ping`, `/relayer/details`, `/relayer/request`, `/relayer/quote` are all literals. Not exploitable as configured; fixed anyway |
| `qs ^6.16.0` | 6.13.0 | four `qs` DoS advisories (moderate) | Yes — query strings, and `body-parser`'s copy |
| `ajv ^8.20.0` | 8.17.1 | `$data` ReDoS (moderate) | Yes — `ajv.compile` validates the details querystring and the quote body. The advisory needs the `$data` option, which the fork does not enable |
| `sqlite3 ^6.0.1` | 5.1.7 | `sqlite3`, and with it `node-gyp` 8 → `make-fetch-happen` → `cacache` → **`tar` (the one critical)**, plus `@tootallnate/once` and `http-proxy-agent` | **No.** See below |
| `tar ^7.5.21` | 6.2.1 | the critical directly, belt-and-braces | No |

**`tar` was never in a request path.** It reached the tree only through `sqlite3`'s install
script (`prebuild-install -r napi || node-gyp rebuild`) and through `node-gyp`'s own header
download. `sqlite3`'s runtime entrypoint (`lib/sqlite3.js`) does not require it. A critical
finding in an install-time extractor is a supply-chain risk at `npm ci`, not a remote one — but
it is the finding an auditor sees first, and it is now gone. `sqlite3 6.0.1` is the only release
whose `tar` is fixed, which is why it is the one major bump here; it needs Node ≥ 20.17 (CI and
the image are on 22) and is API-compatible with the `sqlite` 5.1.1 wrapper the fork opens it
through.

The rest of the tree was left alone deliberately: `snarkjs` 0.5.0 (inside `circom_tester`),
`jsonpath`, `underscore`, `bfj`, `tmp` (via `solc`), `circomkit` and `maci-circuits` are circuit
build and test tooling under `protocol/circuits`, which upstream declares as `dependencies`;
they never run in a service. The wallet's proving uses `snarkjs` 0.7.5, which is not the
vulnerable one.

### The numbers

| | before | after |
|---|---|---|
| `npm audit` | 88 — 1 critical, 24 high, 48 moderate, 15 low | **77 — 0 critical, 18 high, 45 moderate, 14 low** |
| `npm audit --omit=dev` | 48 — 1 critical, 17 high, 15 moderate, 15 low | **37 — 0 critical, 11 high, 12 moderate, 14 low** |

Eleven advisories cleared, none introduced: `tar` (critical), `express`, `sqlite3`, `node-gyp`,
`cacache`, `make-fetch-happen`, `path-to-regexp` (high), `ajv`, `qs` (moderate),
`@tootallnate/once`, `http-proxy-agent` (low). `body-parser` dropped from moderate to low,
because the `qs` it pins is now the fixed one.

### What remains, and why each is acceptable

- **`@openzeppelin/contracts` ≤ 4.9.5 (high) and the six `@uniswap/*` rollups (moderate).**
  These are **Solidity sources, not JavaScript**: the nested copies under
  `@uniswap/universal-router-sdk` (OZ 4.7.0) and under `@uniswap/v3-periphery`, `v3-staker` and
  `swap-router-contracts` (OZ 3.4.x-solc-0.7) contain no `.js` at all, and the SDKs' compiled
  `dist/` never references them. Nothing in `contracts/` or `protocol/contracts/src` imports
  `@uniswap`, and `foundry.toml` remaps `@openzeppelin/contracts/` to the root copy at 5.1.0, so
  they are never compiled or deployed. The relayer imports the SDK only for
  `UNIVERSAL_ROUTER_ADDRESS` and `UniversalRouterVersion` constants. No override was written:
  npm's own "fix" is a **downgrade** to `@uniswap/universal-router-sdk@3.0.3`, which would move
  the router addresses the relayer quotes against, and pinning OZ 4.9.6 into packages written
  for solc 0.7 would make the tree claim a build that cannot happen. An accurate unreachable
  finding beats a tidier dishonest one.
- **`ws` 8.18.0 (high) and the `viem` / `@0xbow/privacy-pools-core-sdk` / `@ethersproject/providers`
  rollups (moderate).** The relayer builds every client with `http()` transport
  (`providers/web3.provider.ts`), and viem loads `ws` only for a WebSocket transport, so it is
  not in the process. In the wallet it is browser code, where `isows` uses the native
  `WebSocket`. An override to `^8.21.3` would clear four findings for one line, but it would
  also replace `@ethersproject/providers`' exact `8.18.0` pin; recommended, not done.
- **`body-parser` 1.20.3 (low).** The relayer's own `bodyParser.json()`. The advisory needs an
  invalid `limit` option to silently disable size enforcement; `app.ts` passes no options, so the
  default 100 kB applies. Express's internal copy is already 1.20.8. An override could not be
  written for it — see the npm note below.
- **Circuit and contract build tooling** (`circomkit`, `circom_tester`, `snarkjs` 0.5.0, `bfj`,
  `jsonpath`, `underscore`, `tmp`, `solc`, `elliptic`, the `@ethersproject/*` lows). Build and
  test time only; they appear under `--omit=dev` only because upstream's `protocol/circuits`
  and `protocol/contracts` declare them as `dependencies`.
- **`@pimlico/alto` and its `fastify` / `find-my-way` / `@opentelemetry/*` / `@sentry/node` tree,
  `vitest`, `mocha`, `serialize-javascript`.** Root devDependencies — the local bundler and the
  test runners. They are absent from `npm audit --omit=dev` and from the
  `npm ci --omit=dev` image.

### Two npm behaviours worth knowing before you touch this

1. **`npm ls` exits 1 and prints `invalid:` for `express`, `ajv` and `sqlite3`.** It compares the
   installed version against the raw manifest spec in `protocol/relayer/package.json` without
   applying the override. It is cosmetic — `npm ci` and `npm install` both succeed, and nothing
   in CI or `scripts/` runs `npm ls`.
2. **`body-parser` cannot be overridden here.** npm (9 and 10) will not move a package that a
   workspace depends on *directly* when another overridden package (`express`) also depends on
   it; it writes a lockfile that `npm ci` then rejects with
   `lock file's body-parser@1.20.8 does not satisfy body-parser@1.20.3`. The override was removed
   rather than left in place not working. Related: npm will not apply a *new* override to an
   entry that already exists in the lockfile, so the lockfile was regenerated for that subtree
   alone — the diff is 4 versions changed, 31 entries added, 79 removed, all in the
   express/sqlite3/node-gyp neighbourhood.

### When to revisit

These overrides exist only because the fork pins old versions. Drop each one when upstream
catches up: `npm ls express ajv sqlite3` prints `invalid: "<pinned>" from protocol/relayer` for
exactly the three still being forced past the fork's pin, and that marker is what disappears
once upstream asks for a version the override already satisfies — at which point the entry can
go. Re-run `npm audit` and
`npm audit --omit=dev` against the numbers above after any `protocol/` fork bump; a count that
moves without an entry here is the signal to look. The `ws` override above is the one
outstanding decision.

## Known issues, stated before they are found

Listing these is cheaper than having them reported back as discoveries:

- No formal verification, no symbolic execution, and no fuzzing beyond Foundry's defaults.
- No invariant tests spanning vault and adapters together.
- The ASP postman and the MPC server share are single points of failure for *access*, not
  for funds. `docs/availability.md` sets out exactly what survives each service dying.
- Per-user daily caps and the dashboard are not built. Owner-side accounting exports
  (`packages/viewing-key/src/tax-export.ts`) are. Internal shielded transfers were built and then
  removed from scope by the client on 12 October 2026 (Rev. 3 §5.3); the router was deleted.
- Movva's peg rests on the issuer hedging off-chain and bringing gains back; the chain sees the
  reserve and a signed statement, not the B3 position. Movva has no freeze function, pending legal
  counsel. See `docs/security-review-movva.md`, "What stays trusted".
- There is no savings product and no distribution: client decision D1 (14 October 2026) removed sMovva, its pool,
  the savings relayer and `MovvaReserve.distribute`. The reserve's surplus above its target stays in it as backing,
  is Mova's, and leaves only through the hedge path. (The dust-`distribute` griefing listed here before went with it.)
- PIX, boleto and TED settle only on a zkTLS proof, and the zkTLS path has no Reclaim application
  credential or bank templates yet: until it does, nothing settles by PIX or boleto. Colluding witnesses
  can still sign a session that never happened, bounded by order size and LP credit (SR2-34).
- Pyth's FX.USD/BRL is closed about 73% of the week. Bands run on the last close for up to four days; a
  keeper outage outside the core session looks like a closure; whoever posts an update may pick among
  those signed since the last post; minting and redeeming wait for the reopening (SR2-35, SRM-15).
- FROST keys now come from a DKG (`packages/mpc/src/dkg.ts`, PedPoP); the trusted dealer is
  test-only. The DKG's transport - authenticated broadcast and encrypted point-to-point round 2 -
  is not built, and the whole package is from-specification cryptography that has not been
  reviewed. See `docs/wallet-custody.md`.

## What we would like challenged

The load-bearing claims, listed in `docs/audit-scope.md`. If any is false, it matters more
than a finding:

- the viewing key cannot authorise a spend, by construction rather than by policy;
- a relayer cannot alter what a user's proof authorised;
- no single compromised off-chain service can take funds held by a user's account (the broader
  "no user loses funds if any service dies" does not hold as stated, and `docs/availability.md` says
  where);
- the escrows use the oracle as a band and never as the price; the Movva reserve, which does use a
  price, cannot have its rate's feed, limits, signers or sources changed without the public delay, and
  never mints, redeems or withdraws to the hedge at a price older than its max age;
- no PIX, boleto or TED payment settles on an attestor quorum's word;
- Movva is never minted below full backing, and a redemption never pays more than `min(1, ratio)`;
- no keeper key, on Flux or anywhere, can pay itself.
