# Audit scope — Phase 1

For an external reviewer. This says what to look at, what not to bother with, what we
already believe is wrong, and where the sharp edges are. It is written to save an auditor
the week of orientation that usually comes first.

## What is in scope

Everything in this repo that we wrote:

| Component | Lines | What it is |
|---|---|---|
| `contracts/AuditGrantRegistry.sol` | ~200 | Public lifecycle for disclosure grants. No funds, no admin. |
| `contracts/ShieldedNoteLog.sol` | ~110 | Append-only encrypted note records. No funds, no admin. |
| `contracts/SponsorPaymaster.sol` | ~320 | ERC-4337 gas sponsor. Holds a gas deposit, has an owner. |
| `packages/viewing-key/src` | ~7,000 | The audit viewing key: key tree, note encryption, disclosure, reconciliation, indexer. |
| `packages/smart-account/src` | ~1,650 | Passkey/PRF seed derivation, Safe 2-of-2 over ERC-4337, WebAuthn signer encoding; **the passkey-sealed FROST device share** (`sealed-share.ts`), **the 2-of-3 recoverable seed split** (`seed-source.ts`), and **the delayed passkey-only recovery module** (`recovery.ts`, Zodiac Delay 1.1.1). Kernel v3.1 accounts beside Safe (`kernel.ts`, `kernel-validators.ts`, `kernel-recovery.ts`). See `docs/wallet-custody.md`. |
| `packages/smart-account/contracts/src` | ~500 | **Kernel validators, unaudited, and a separate Foundry project.** `PasskeyCoSignerValidator` enforces the passkey + server 2-of-2 inside one validator (Kernel lets every installed validator authorise alone, so on Kernel the 2-of-2 is this contract, not Safe's audited threshold); `FrostValidator` accepts a FROST group signature through `SchnorrVerifier`; `KernelAvatarAdapter` lets the Zodiac Delay recovery queue calls into a Kernel account through an open fallback selector that checks its caller. Both validators sign a validity window over the bare `userOpHash`. What Kernel cannot match of the Safe design: `docs/wallet-custody.md` §10.3. |
| `packages/mpc/src` | ~1,000 | **FROST threshold Schnorr (RFC 9591) and its distributed key generation (PedPoP, `dkg.ts`). Unaudited cryptography — review this first.** |
| `contracts/ramp/*.sol` | ~4,750 | **Phase 2 BRL ramp. Holds LP liquidity and seller escrow — the contracts with the most value at risk.** Two escrows (PIX, TED, boleto, and cards for institutional LPs only - SR2-32; a bank rail opens only on a verifier that proves the bank session - SR2-34), LP registry, two attestor verifiers (zkTLS for bank payments, a quorum for card captures), five price oracles behind the governance delay (SR2-30) - among them `PythFxOracle`, the USD/BRL rate with a band reading for the closed market (SR2-35) - `IBandPriceOracle`/`BandRead`, `RulingLib`, `SafeTransferLib`; **`NodeRewards`**, node-provider rewards paid from Mova's fees in proportion to settled volume, fed by `LPRegistry`'s rewards hook (SR2-36). |
| `packages/ramp/src` | ~4,600 | Off-chain matching (holds nothing, signs nothing), attestor client (PIX, boleto, card captures), zkTLS client, boleto validation, price publisher, arbitration desk and its service. |
| `contracts/SchnorrVerifier.sol` | ~230 | **On-chain FROST verification via an `ecrecover` construction, plus the ERC-1271 signer. Unaudited.** |
| `contracts/yield/YieldVault.sol` | ~420 | Phase 3 ERC-4626 over governor-listed adapters: allocation caps, deposit cap, drawdown breaker. Holds the Movva reserve's idle USDT (`MovvaReserve.setYieldVault`); its yield is Mova's, not users'. |
| `contracts/yield/adapters/*.sol` | ~1,000 | ERC-4626 (sUSDS; Aave v3's USDT wrapper), Lido (wstETH, Curve instant exit, withdrawal queue, Chainlink depeg guard), Superstate USTB (NAV-bounded). |
| `contracts/common/ShieldedDepositLabel.sol` | ~55 | Recomputes the label a pool just assigned. Used by the escrow's rescue index. |
| `contracts/common/DelayedGovernance.sol`, `IssuerFreeze.sol`, `FxMarketHours.sol` | ~310 | **The base every governed contract uses**: risk-raising changes are scheduled in public and wait `GOVERNANCE_DELAY`; risk-reducing ones are instant. `IssuerFreeze` asks Tether or Circle before anything new starts in a freezable token. `FxMarketHours` decides from a timestamp alone whether the FX market is certainly trading (SR2-35). |
| `contracts/movva/*.sol` | ~1,450 | **Movva: the first contract here that creates money.** `MovvaReserve` mints and redeems a BRL-pegged token at Chainlink USDT/USD x Pyth's FX.USD/BRL (or a signed rate) against a USDT reserve, refusing a stale rate while its band takes the last close (SRM-15); surplus above the target stays in the reserve as backing (there is no distribution: savings and `SavingsMovva` were removed by client decision D1, 14 October 2026); `ScaledFxBandOracle`; `FeeSplitter`, the reserve's fee recipient, which forwards the LPs' share of the fees to `NodeRewards`. See `docs/security-review-movva.md`. |
| `contracts/movva/DivergenceBreaker.sol`, `IPriceSource.sol`, `sources/*.sol` | ~330 | **Keyless, self-clearing circuit breaker for `MovvaReserve`** (SRM-16): no owner, no setter, no state after construction; mint, redeem and hedge withdrawals revert while independent rate sources (a Chainlink cross, a Uniswap v3 TWAP) disagree beyond a deploy-time band. A thin TWAP that trips it is a denial-of-service lever (docs/movva.md). |
| `contracts/yield/LimitedYieldVault.sol` | ~170 | `YieldVault` plus a per-owner daily limit and an announce-then-anyone-executes timelock above it, with no cancel (SRM-17). The reserve's `queueHedgeWithdrawal` / `executeHedgeWithdrawal` are the same pattern. |
| `contracts/yield/KeeperGate.sol` | ~170 | One revocable operator key per keeper replica, with a daily turnover budget. |
| `contracts/SponsorGate.sol` | ~320 | SponsorPaymaster's owner as a contract. Revocable operator keys may only sponsor, within a daily count budget and only while the paymaster bounds each account's gas. A two-step governor keeps every owner power by forwarding; a guardian may only revoke and lower. |
| `contracts/hyperliquid/*.sol` | ~1,500 | Delta-neutral vault on HyperEVM trading HyperCore through CoreWriter; the keeper triggers only bounded actions. Never traded on real HyperCore. |
| `packages/movva/src` | ~3,000 | The issuer's hedge desk: hedge and treasury arithmetic in bigints, signed and chained hedge statements. Holds no treasury key. |
| `packages/lp-node/src` | ~10,800 | **The LP's daemon. Holds the LP's key and moves the LP's BRL.** Offers inside the band, payment instructions, PIX/boleto matching, off-ramp payouts with an idempotency key persisted before every bank call. |
| `packages/wallet/src` | ~7,000 | The BRL-only boundary an app calls: balances in reais, PIX BR Codes, deposit quotes, audit grants, the tax year. |
| `packages/cosigner/src` | ~5,800 | **The server half of every user's 2-of-2. Holds the co-signer key (KMS in production).** It must never produce a signature a request can use without a user-verified passkey signature over the exact operation it computes itself, against the passkey read from the chain (Safe WebAuthn signer or `PasskeyCoSignerValidator`), never from the request. Refuses authority changes (owners, modules, validators, upgrades, the Delay's configuration, co-signer rotation) except the recovery setup and listed rotations; allowlists targets and approvals; windows ≤ 30 min; replay and rate limits; an fsynced audit record before each signature; the recovery veto. TypeScript WebAuthn and P-256 verification is checked against the deployed factory's verdicts in `examples/cosigner-live.ts`. Two optional modules: **sponsorship** at enrolment through `SponsorGate` from a separate operator transaction key (§11.1), and **recovery alerts** (a watcher of each account's Delay, Web Push with VAPID and aes128gcm implemented on node:crypto, §11.2). See `docs/wallet-custody.md` §11. |
| `packages/app/src` | ~5,800 | The PWA. Holds the seed in memory while unlocked (from the passkey's PRF), seals what it stores under a key derived from it, proves withdrawals in a Web Worker, and verifies every LP node answer on-chain before showing it. No server of Mova's sees a key. |
| `packages/attestor/src` | ~2,800 | **A licensed PSP's payment attestor. Holds a key in `AttestorQuorumVerifier`.** Reads terms from the chain and payments from the PSP's own records, and signs only what both show (SR2-33). Since SR2-34 only its card captures (acquirer reads) can settle anything: its API Pix and Open Finance sources remain, but no bank-rail offer or sale can name the quorum. |
| `packages/yield/src` | ~2,700 | Read-only Hyperliquid client and the delta-neutral backtest; **three keepers that sign**: the vault keeper (through `KeeperGate`), the HyperEVM keeper, and the Pyth keeper (posts Pyth's signed FX.USD/BRL updates, open to anyone; its key holds no role). None can pay itself. |

Shielded transfers (Rev. 3 §5.3, Option A) are not in scope: the client removed them from the product on
12 October 2026, so users deposit and withdraw only. `ShieldedTransferRouter` and the wallet's transfer path
(`packages/viewing-key/src/transfer.ts`) were deleted.

Savings is not in scope either: client decision D1 (14 October 2026) removed it from M1. `SavingsMovva` (sMovva),
its shielded pool, `ShieldedYieldRouter`, `packages/zap-relayer` and the Movva distribution keeper were deleted, and
`MovvaReserve` lost `distribute`, `previewDistribute`, `setSavings` and the distribution fee. The scope is deposit PIX,
mint Movva, hold it as shielded notes, withdraw to PIX. `YieldVault` and its adapters stay, as the reserve's own yield.

The highest-value targets, in order:

0. **`packages/mpc/src/frost.ts`.** The only from-specification cryptography in the repo.
   Everything else is either audited upstream code or application logic where a bug costs
   correctness; here a subtle mistake costs the key. Attack the nonce handling first: the
   binding factors are what stop the second party to commit from grinding the group nonce
   (Drijvers/ROS), and `commit()` must never be able to return a repeated nonce.

   Then **`packages/mpc/src/dkg.ts`**, which replaced the trusted dealer (the dealer is now a
   test fixture outside the package's exports). Attack the proof of possession's binding (id,
   session, context, threshold, participant set), the equivocation check (a transcript hash in
   every round-2 message), blame assignment, and whether any path computes or returns a group
   secret. Then **`packages/mpc/src/dkg-transport.ts`**, the channel it assumes: what the signed
   envelope and the transcript bind (session id, every party's long-term key, every party's whole
   round-1 payload), whether any refusal can be bypassed, and the round-2 sealing (X25519 to the
   recipient's round-1 key, HKDF-SHA256, XChaCha20-Poly1305 over the envelope as AAD) - including
   whether a key can ever be derived twice.

   Then `contracts/SchnorrVerifier.sol`, which is the same cryptography on-chain. Two
   specific things to attack: the `ecrecover` construction compares a 160-bit **address**
   rather than the full x-coordinate, and the challenge is recomputed in Solidity and must
   match the TypeScript exactly (a differential test pins it, but the test is ours too).

   Then **`packages/smart-account/src/sealed-share.ts`** (the device share sealed under the
   passkey PRF: salt and KDF separation from the pool seed, what the AEAD binds) and the GF(2^8)
   Shamir split and recovery code in **`seed-source.ts`**.

   And the recovery module's **reliance on Zodiac's signature-based module authentication**
   (`SignatureChecker`, ERC-1271): the passkey queues through it, and its only audit is the June
   2026 patch review, which covered the fix alone. The Delay's queue, cooldown and veto logic is
   audited; this path is not. `docs/wallet-custody.md` §7–8 has our reading and the audited
   alternative, and `contracts/test/PasskeyRecoveryFork.t.sol` attacks it.
1. **`contracts/movva/MovvaReserve.sol`, and the rate it mints at.** A wrong number here is
   value, not a nuisance. Try to mint below full backing, redeem above `min(1, ratio)`, move reserve USDT
   anywhere but a redeeming gateway, the yield vault or the fixed hedge treasury, or change the rate's
   feed, limits, signers or sources without the public delay (`PythFxOracle`, `SignedPriceOracle`,
   `ChainlinkSignedFxOracle`). Then the off-hours split (SRM-15, SR2-35): `mint`, `redeem`,
   `withdrawToHedge`, `executeHedgeWithdrawal`, the ratios and the previews must read the strict rate, and only
   `brlCentsPerUnit` and `bandBrlPerUsdtE18` the band. Find a value-moving path that reaches `BandRead`,
   or a band reading that returns a price the strict reading would refuse for another reason. Then
   `PythFxOracle` and `FxMarketHours` themselves: the core session's edges (13:30 and 21:00 UTC,
   weekends, 25 December, 1 January, leap years), a last close stamped current for up to
   `closedMaxAge`, exponent and confidence handling, updates that go backwards. Then Aave rounding at
   par (SRM-6) and Tether freezing the reserve (SRM-4). Residual risks already recorded, not findings: a
   gateway posting the most favourable Pyth update signed since the last post, a keeper outage outside
   the core session reading as a closure, about two hours a day misread as closed (bands only), and a
   band that jumps at the reopening.
2. **The bank-rail checks in `FiatEscrow.postOffer` and `OffRampEscrow.openSale`** (SR2-34). A PIX,
   boleto or TED offer or sale must open only on a verifier whose `provesBankSession()` is true, so the
   attestor quorum (a `pure` false) settles card captures only. Find any path around it: a rail mask
   that is not CARD alone reaching the quorum, an order or top-up on an offer that should never have
   opened, a card offer carrying a bank rail. The answer is read when an offer or sale opens, not at
   settlement; revoking a verifier is the lever against a broken one. Residual: colluding zkTLS
   witnesses can still sign a session that never happened, bounded by order size and LP credit.
3. **`contracts/ramp/NodeRewards.sol`, `contracts/movva/FeeSplitter.sol` and the hook in `LPRegistry.recordSettled`**
   (SR2-36). Try to claim more than an epoch's budget, than was funded, or past the per-LP cap; to make a void or an
   exclusion raise another LP's share; to change the share, the rate, the cap, the hook or a funded registry without the
   delay; to make the hook block or starve a settlement - revert, loop, return a mountain of data, re-enter the registry,
   or submit the release with a gas limit that leaves the hook short (it must revert, never skip); and to break the books
   (`accounted == carry + outstanding + unfinalized funding`) through donations, epochs never finalized, or rounding.
   Residual risks already recorded, not findings: an eligible LP settling with itself within the caps, affiliates each with
   their own cap, and the instant first binding of a registry while NodeRewards holds nothing.
4. **`packages/viewing-key/src/keys.ts` and `pool/scheme.ts`.** The whole read-only claim
   rests on the key tree's shape and on the withdrawal witness never leaving the spend
   branch. If this is wrong, nothing else matters.
5. **`disclosure.ts` + `audit.ts` + `reconcile.ts`.** Scope enforcement and the correctness
   of a fiscal report. A wrong balance here is handed to a tax authority.
6. **`SponsorPaymaster.sol`.** The only contract we wrote that holds value and has an owner.
7. **`vault.ts`.** Access control on ciphertext release.
8. **`YieldVault.sol` and `LidoStakingAdapter.sol`** (Phase 3).
   For the vault (the reserve's), try to strand a holder, since two of Phase 3's three bugs were on
   exit paths. For the Lido adapter, try to get an instant exit filled at a price the oracle
   would not allow, or to make a depeg invisible to the share price.
   `docs/security-review-phase3.md` lists what we checked.

## What is out of scope

`protocol/` is upstream's Privacy Pools, unmodified. `npm run verify` diffs it against a
fresh upstream clone and hash-checks all 14 zk artifacts; all three circuits recompile to
byte-identical R1CS. It carries its own Oxorio and Auditware reports in `protocol/audit/`.
Auditing it again would duplicate that work — but **do** check our *use* of it, especially
`reconcile.ts` and `pool/indexer.ts`, where two bugs have already been found.

## Start here

```bash
npm install && npm run verify      # 14 checks: provenance, 110 unit, 52 integration,
                                   # circuits reproduce + 18 circuit tests, relayer, ours
npm test                           # 372 tests incl. property-based
npm run slither                    # static analysis over contracts/
```

All of the above runs in CI on every push (`.github/workflows/verify.yml`), so what this
document claims is checked continuously rather than at the moment it was written.

Live deployment with verified sources: `docs/deployments.md`. Every contract is
Etherscan-verified, so the deployed bytecode can be read rather than taken on trust.

## Things we already believe are true and would like challenged

These are the load-bearing claims. If any is false, tell us first.

1. **A viewing key cannot spend.** Viewing material is an HKDF child of the spending
   secret; the withdrawal witness `(nullifier, secret)` derives from the spend branch and
   never enters a note or bundle; `assertNoWitness` walks payloads recursively at seal time.
2. **Scope is cryptographic, not filtered.** A record outside a grant's epochs is encrypted
   under a key the auditor was never given. The vault filter is defence in depth.
3. **Revocation stops future access only.** Rotation makes post-revocation notes
   permanently unreadable to the ex-auditor. Nothing retracts what was already decrypted,
   and we do not claim otherwise.
4. **A truncated disclosure is detectable only against an on-chain anchor.** A hash chain
   prefix is a valid hash chain; `anchorChain` commits head and count so the auditor can
   compare. This was sharpened by a property test that failed.
5. **`SponsorPaymaster` cannot touch user funds.** Everything sent to it forwards to the
   EntryPoint deposit; the worst outcome from a bug is draining its own gas.
6. **An attestor quorum cannot settle a bank payment.** No PIX, boleto or TED offer or sale opens
   on a verifier whose `provesBankSession()` is false (SR2-34).
7. **Nothing moves value at a closed market's price.** `MovvaReserve`'s mint, redeem,
   `withdrawToHedge` and `executeHedgeWithdrawal` refuse an FX leg older than `fxMaxAge` at any hour; only bands
   take the last close (SR2-35, SRM-15).

## Known issues, already recorded

Do not spend time rediscovering these — `docs/security-review-phase1.md` has the detail.

- **`terms.accounts` is an attestation, not a proof.** A deposit from an undeclared account
  is undetectable on-chain. Mitigation is a KYC'd ramp that does not exist yet.
- **Paymaster budget overshoot.** Several operations in one bundle each pass validation
  before any settles, so an account can exceed its budget by up to one bundle, bounded by
  `maxCostAllowed`. Accepted deliberately; the alternative adds failure modes to `postOp`,
  which must never revert.
- **The paymaster must be staked, and its budget is enforced through `validAfter`.** Public
  bundlers apply ERC-7562 to validation. An unstaked paymaster may not read its own storage
  there or return a context (STO-031, EREP-050), so an unstaked `SponsorPaymaster` is refused by
  every one of them; the stake is an operational requirement (`docs/runbook-mainnet-deploy.md`,
  3c). TIMESTAMP is banned in validation for every entity (OP-011), and the budget check used
  to read it. Validation now reads no block data: an operation that does not fit the account's
  current window returns `validAfter` = the window's end, the EntryPoint enforces it, and
  `postOp` opens the next window. Checked with Rundler v0.11.0 on geth
  (`packages/smart-account/examples/erc7562-live.ts`). Worth an auditor's look: the argument in
  `validatePaymasterUserOp`'s comment that a window which ended but was not settled can only
  delay an operation, never admit one the budget refuses.
- **ASP operator trust.** Withdrawals need an association-set root posted by the postman
  role. In production that is a separate operator whose liveness the withdrawal path
  depends on. See `docs/availability.md`.
- **The server co-signer (Safe owner or FROST share) is required for ordinary spending.**
  Its loss is handled by the delayed recovery module: the passkey alone queues any Safe
  transaction (ragequit, rescue, `swapOwner`), executable by anyone after 7 days, vetoable by
  both owners. What still loses funds is the combination *server dead and passkey compromised*
  (no veto), accepted deliberately because a server-alone veto would let a compromised server
  freeze recovery. 2-of-3 with an independent operator remains an option. `docs/availability.md`,
  `docs/wallet-custody.md` §6.
- **Two high-severity findings in Phase 2 are already fixed and worth reading first** —
  `docs/security-review-phase2.md`. Both were in `rescueShielded`, and both had the same
  shape: a comment asserting a property the code did not have. Attack the seams where a
  claim is made in prose rather than in a test.
- **BRL/USD is readable on Ethereum mainnet only once Mova's keeper posts it.** Pyth publishes
  FX.USD/BRL and it is live on Hermes, but Pyth is pull-based and nobody has posted that feed to
  mainnet, so the contract answers `PriceFeedNotFound`. Chainlink lists one, but it is gated to EOA
  readers (a contract gets `No access`) and its last update was August 2023. Mova decided
  (14 September 2026) to keep the Pyth pull warm: its Pyth keeper (`packages/yield`) posts updates,
  permissionlessly and with a key that holds no role, and `PythFxOracle` reads them. Reading Hermes's
  hosted gateway needs a credential, so the keeper needs one too (or its own Hermes).
  `packages/ramp/examples/brl-price.ts` reports the live state, and
  `contracts/test/{PythFork,OracleFork}.t.sol` pin the unposted state and fail once it changes.
  `SignedPriceOracle` remains a supported alternative (`FX_SOURCE=signed`).
- **The FX market is closed about 73% of the week** (SR2-35, SRM-15). Pyth publishes FX.USD/BRL on
  weekdays 08:00-17:00 New York time only. Bands (`IBandPriceOracle`/`BandRead`, `ScaledFxBandOracle`,
  the reserve's `brlCentsPerUnit`) take the last close outside `FxMarketHours`' core session;
  everything that moves value refuses. Recorded residual risks: a move while closed reaches no band
  until the reopening; a keeper outage outside the core session looks like a closure for up to
  `closedMaxAge` (four days); about two hours a day are misread as closed, for bands only; a holiday
  Pyth adds fails closed and needs a new `PythFxOracle`; whoever posts may choose among updates signed
  since the last post; `BandRead` falls back to the strict reading on any revert of the band reading.
- **LP limits are denominated in BRL centavos, not asset units.** Once the escrow holds more
  than one asset, a "wei" limit is meaningless - the same number is 5 ETH or 0.000005 USDC.
  Worth checking the conversion at every call site.
- **Fee-on-transfer and rebasing tokens are rejected, not supported.** `receiveToken`
  measures the balance actually received and reverts on a shortfall. Listing such a token
  would break the escrow's accounting in a way no transfer wrapper repairs.
- **Two attestor verifiers exist, with very different trust, and since SR2-34 they serve
  different rails.** `ReclaimZkTlsVerifier` verifies a zkTLS claim about a TLS session with a
  named bank host; its `provesBankSession()` is true, and it is the only verifier a PIX, boleto
  or TED offer or sale can name. Colluding witnesses can censor, and can still sign a claim about
  a session that never happened - a broader and more public set than named PSPs, not no trust.
  `AttestorQuorumVerifier` is a trusted M-of-N signature over reality, where colluding
  attestors can forge outright; its `provesBankSession()` is a `pure` false, so it settles card
  captures only. Nothing settles by PIX or boleto until a Reclaim application credential and
  per-bank templates exist. Attack the zkTLS context reader first: it parses a JSON document an attacker
  partly controls, and the identifier recomputation is what stops a genuine claim being
  re-pointed at another order.
- **MPC is implemented but is not the default, by decision.** Safe 2-of-2 (passkey owner +
  server owner) delivers "no single party can spend" with audited contracts and no unaudited
  code in the spending path, and remains the recommended production configuration. FROST
  (DKG keys, device share sealed under the passkey, one on-chain signature via `FrostSigner`) is
  the option for when single-signature indistinguishability is required, gated on this audit.
  The trade-off is worth challenging: two signatures are public where MPC would show one.
- **The passkey authenticator is simulated** in the test suite. The on-chain half is real
  and exercised on Sepolia; `packages/smart-account/browser/passkey-check.html` covers real
  hardware but is manual. It accepts cross-platform authenticators (a USB security key is
  enough), so no mobile device is required to exercise it.
- **The no-PRF fallback is written but is a policy decision.** `SeedSource` offers
  `PrfSeedSource` (seed never exists at rest) and `RecoverableSplitSeedSource` (seed
  reconstructable from any two of device share, server share and a user-held recovery code).
  The legacy `SplitSeedSource` (device ⊕ server) lost funds with the server share and is kept
  only for migration, which preserves the seed. The split is strictly weaker than PRF and marked
  as such; whether to enable it or require a PRF-capable authenticator has not been decided.
  Worth reviewing the split construction and, more importantly, the rule that PRF and split
  must never be migrated between silently — they yield different wallets.
- **Sponsor key custody is unspecified.** The paymaster owner controls the allowlist and can
  withdraw the deposit. Not user funds, but real operational risk with no documented
  procedure.
- **Upstream leaves the relayer's fee-commitment validation untested.** Three tests in
  `protocol/relayer/test/unit/privacyPoolRelayer.service.spec.ts` are `it.skip` with empty
  bodies: expired commitment, unverified commitment, and a fee lower than calculated. Those
  are exactly the paths deciding whether the relayer accepts an underpaying or replayed
  request. We have not written them either; they are upstream's file and we have kept it
  byte-identical. Worth an auditor's attention.

### Slither triage

`npm run slither` gates on **medium impact or worse** (`--fail-medium`) and currently exits
clean. It reports four low/informational findings, all reviewed:

| Finding | Assessment |
|---|---|
| `timestamp` in `AuditGrantRegistry.register` / `isLive` | Intended. Grants are time-boxed by design; validity windows are hours to days, while miner timestamp influence is seconds. |
| `timestamp` in `SponsorPaymaster.postOp`, `spentSoFar`, `_windowEnd` and `validatePaymasterUserOp` | Intended in the first three: `postOp` settles the budget window and `spentSoFar` is an off-chain view. A window is a day, and skewing it by seconds changes nothing an attacker benefits from. A false positive in `validatePaymasterUserOp`: it compares a stored window start plus the window with validAfter's 48-bit limit, and reads no block data, which ERC-7562 forbids there (OP-011; checked with Rundler). Run per file, clean at medium. |
| `contracts/SponsorGate.sol`, run per file | Clean at medium. Its one medium finding, `uninitialized-local` on `sponsorBatch`'s counter, was fixed by initializing it. Remaining low and informational findings: `timestamp` in `remainingSponsorships`, `windowEndsAt` and `_consume` (a one-day budget window; timestamp influence is seconds); `calls-loop` in `sponsorBatch` (static calls to the immutable paymaster, at most 100); `missing-zero-check` on the guardian (zero means no guardian, on purpose); `naming-convention` on the immutable `PAYMASTER`. |
| `naming-convention` on `ENTRYPOINT` | Cosmetic. Upper case for an immutable, matching upstream Privacy Pools' own convention. |
| `timestamp` in `LidoStakingAdapter.marketPrice` | Intended. Oracle staleness is judged in hours; timestamp influence is seconds. (`ShieldedYieldRouter.zap` was listed here until the router was removed, D1.) |
| `calls-loop` in `YieldVault.totalAssets` / `liquidAssets` | Intended. Adapters are governor-listed and capped at 8, and their views must not revert (`IYieldAdapter`). |
| `reentrancy-benign` in `YieldVault.allocate/deallocate/harvest`, `LidoStakingAdapter.requestExit` | The order is forced. The checkpoint must follow the deposit it measures. Every entry point is `nonReentrant`. (The removed router's `zap/_shield` were listed here too.) |
| `dead-code` on `YieldVault._deposit` / `_withdraw` | False positive. They override OpenZeppelin's ERC-4626 hooks, and OpenZeppelin calls them. |
| `costly-loop` in `YieldVault.removeAdapter`, `LidoStakingAdapter.claimExit` | Bounded: at most 8 adapters, and one swap-and-pop over outstanding requests. |
| `low-level-calls` in `LidoStakingAdapter.deposit` | Intended. Sending ETH to wstETH is how it stakes and wraps in one call, verified on mainnet. |
| `cyclomatic-complexity` in `LidoStakingAdapter.withdraw` | Accepted. One function, so the oracle check, sizing, unwrap and sale share one set of locals. Covered by fork tests. |
| Medium findings on Phase 3 contracts | Each suppression sits next to its reason. `reentrancy-balance` and `unused-return` are on balance-delta measurement and on returns re-read from balances. `arbitrary-send-eth` is on the Lido adapter wrapping its exit ETH into the immutable WETH (the removed router's payees bound by the user's proof were the other case). `divide-before-multiply` was fixed, not suppressed (SR3-3). |
| Medium findings on `packages/smart-account/contracts` | Suppressed with reasons, analysed by `scripts/slither-smart-account.sh` (the root script never sees this separate Foundry project). `locked-ether` on all three modules: `onInstall`, `onUninstall` and `validateUserOp` are payable because Kernel's `IModule`/`IValidator` declare them so, and Kernel sends no value. `unused-return` on `KernelAvatarAdapter`'s `executeFromExecutor` (single-call mode reverts on failure) and on `ECDSA.tryRecover` in `PasskeyCoSignerValidator` (the error and the recovered address are both checked). Informational `naming-convention` and `too-many-digits` (the P-256 constants) remain. |

`contracts/script/` is excluded from analysis, and that choice is worth knowing rather than
discovering: it produced one guaranteed **high**-impact false positive — `arbitrary-send-eth`
for a deploy script funding the paymaster it created in the same transaction. Keeping it in
meant either a permanently failing check or a per-finding suppression; excluding deployment
tooling and analysing what actually gets deployed is the more honest of the three. If you
disagree, the script is four lines and worth a look.

We would rather hear that this triage is wrong than have it silently agreed with.

## A third bug, of a different kind

The first two were logic. This one was worse in a way worth understanding, because it means
an earlier version of this document was making a claim it could not support.

An unanchored `lib/` in `.gitignore` matched at every depth, and silently excluded three
files of **audited protocol source** — `src/contracts/lib/{Constants,ProofLib,DeployLib}.sol`
— from every commit. Everything built and verified locally, because the files were on disk.
The published repository could not build at all, and "the fork is byte-identical to
upstream" was true of the working tree and false of what anyone else could clone.

Found by CI on the run after the lockfile was committed. Not findable by testing harder
locally — the machine that had the missing pieces was the machine doing the testing.

The rules are now anchored, and `.gitignore` carries the check to run before adding an
unanchored pattern. If you review one thing about the repo's hygiene, review that file.

## Where the bugs have actually been

Two real bugs were found in Phase 1, and both had the same shape: **the model and the test
agreed with each other because the same assumption produced and checked the value.**

- `labelOf` used Poseidon where the contract uses `keccak256`. Every test passed for two
  tasks, because `LocalPrivacyPool` generated labels with our function and checked them with
  our function.
- Ragequit exits were invisible to reconciliation, because the L1 event carries no nullifier
  hash and the RPC decoder fabricated one. The in-process model knows the hash, so only the
  real path was wrong. It would have **overstated a balance in a report to a tax authority**.

Both were found by comparing what the model believes against what the chain emits. If you
have limited time, that is the seam to attack: anywhere our TypeScript reproduces something
a contract computes. `test/scheme-onchain.test.ts` pins the known cases with vectors
captured from a deployed pool.

## What we have not done

- No formal verification, and no symbolic execution.
- No timing or side-channel analysis. We use `@noble`, which is constant-time by design, but
  have not audited our own usage.
- No dependency supply-chain review. `package-lock.json` is committed (1,093 resolved
  packages, lockfile v3) so the versions are at least pinned and `npm ci` is reproducible,
  but nothing has audited what is in them.
- No review of operational security for the relayer or sponsor signing keys.
- Property-based testing covers the key tree, note encryption, chain integrity
  (`test/properties.test.ts`), reconciliation (`test/reconcile-properties.test.ts`) and the
  matcher (`packages/ramp/test/orderbook-properties.test.ts` — conservation, rounding
  against the taker, rail and asset separation, ranking totality). It does not cover the
  vault's access control or the relayer.
- Nothing has run on mainnet, under adversarial conditions, or at load.

## Contact points in the code

| Question | Read |
|---|---|
| Why does the key tree look like this? | `src/keys.ts`, header comment |
| Why keccak and not Poseidon for labels? | `src/pool/scheme.ts`, `labelOf` |
| What does a grant actually commit to? | `src/disclosure.ts`, `GrantTerms` |
| How is a report reconciled against the pool? | `src/reconcile.ts` |
| Why is the registry reader synchronous? | `src/chain-registry.ts`, header |
| Why does the vault bound its registry age? | `src/vault.ts`, `maxRegistryAgeSeconds` |
| Why is `postOp` inert-by-construction? | `contracts/SponsorPaymaster.sol` |
| What did we change in the fork, and why? | `protocol/FORK.md` |
| Why is stETH valued at the lower of two prices? | `contracts/yield/adapters/LidoStakingAdapter.sol`, header |
| Why is a rescue keyed by label and not commitment? | `docs/security-review-phase3.md`, SR3-2 |
