# Ownerless paymaster

The client's decision B1 (14 October 2026): *"Ownerless paymaster. It sponsors only accounts that qualify by an
on-chain rule, with no signing key: accounts created by your account factory, under per-account rate limits.
Anyone can top up its deposit. Its stake is locked permanently and can never be withdrawn. No one can pause,
censor, or change the policy."* It pays gas for the primary account and for every sub-wallet's account.

`contracts/OwnerlessPaymaster.sol` implements it for EntryPoint v0.7. It is not in any deploy script yet;
`SponsorPaymaster` and `SponsorGate` are unchanged.

## What nobody can do

There is no owner, admin, signer, pause, setter or upgrade path, and no `delegatecall` or `selfdestruct` in
the runtime code. Every policy parameter is an immutable set in the constructor. The only state is the usage
counters, and only the EntryPoint can change them, through validation and `postOp`. The contract calls only the
immutable EntryPoint, and only `depositTo` and `addStake`.

- **Deposit.** Anyone tops it up: `deposit()`, a plain ETH transfer, or `EntryPoint.depositTo(paymaster)`.
- **Stake.** Anyone adds to it with `addStake()`, always with the immutable `UNSTAKE_DELAY_SEC` (at least one
  day). The EntryPoint lets only the staked address itself call `unlockStake`, `withdrawStake` and `withdrawTo`.
  This contract has no code that calls them, so the stake stays locked and the deposit leaves only as gas.

To retire it, stop funding it. To change the policy, deploy a new one. The old one keeps its stake, and keeps
sponsoring until its deposit runs out.

## Who qualifies

An account qualifies when its address is the CREATE2 address of one of two immutable factories, with that
factory's proxy init code hash, for a salt the operation supplies:

| Index | Factory | Proxy init code hash | CREATE2 salt the client supplies |
|---|---|---|---|
| 0 | Safe 1.4.1 `SafeProxyFactory` `0x4e1DCf7A…` | `keccak256(proxyCreationCode() ++ uint256(Safe 1.4.1 singleton))` | `keccak256(keccak256(initializer) ++ saltNonce)` |
| 1 | Kernel v3.1 `KernelFactory` `0xaac5D424…` | `keccak256(Solady ERC-1967 proxy over the Kernel v3.1 implementation)` | `keccak256(initData ++ salt)` |

The address is the proof, so no key and no registry are needed. One check covers both cases:

- **The op deploys the account (initCode).** The EntryPoint runs the factory and checks the result is `sender`
  before it calls the paymaster.
- **The account already exists.** The check is identical. A Kernel account is created by a plain transaction
  to `KernelFactory` before its first op (wallet-custody.md §10.3).

A sub-wallet's account (no passkey, its own key as the only owner) comes from the same factories. The rule never
looks at owners, so it qualifies the same way. The wallet already computes both salts when it predicts the
address (`predictSafeAddress`, `predictKernelAddress`).

**This is a filter, not a Sybil defence.** Both factories are public. Anyone can create any number of qualifying
accounts, free, with any owners. The rule fixes *what kind* of contract is sponsored: a proxy of a pinned
implementation. It cannot tell a user from an attacker. A proxy can later be pointed at other code by its owners,
which does not matter here: the rule bounds gas, not behaviour.

## Limits, and the trade-off the client should sign off

Time is cut into fixed windows of `WINDOW` seconds. The limits per window are:

- `MAX_COST_PER_OP` wei per operation (the EntryPoint's `maxCost`);
- `MAX_OPS_PER_ACCOUNT` operations and `MAX_COST_PER_ACCOUNT` wei per account;
- `MAX_COST_GLOBAL` wei for all accounts together.

**The global cap is the only bound on how fast the deposit can be drained.** One person running many accounts
through the public factory gets a full per-account budget for each of them. So the per-account limits only
spread the budget; they do not cap it. In any n consecutive windows the paymaster pays at most
(n + 2) x `MAX_COST_GLOBAL`: one extra window from fixed-window alignment, one from the grace period (below).

What the global cap costs is **availability**:

- An attacker can spend the whole global budget early in a window, free. Everyone is then unsponsored until the
  next window, and nobody can stop it, because nobody controls the contract.
- A bundler that is the attacker also keeps what the paymaster pays it: priority fees, `preVerificationGas`
  and EntryPoint v0.7's 10% penalty on unused gas. The budget can therefore be turned into the attacker's ETH at
  up to `MAX_COST_GLOBAL` per window.

Choose `MAX_COST_GLOBAL` as the loss per window you accept. Fund the deposit for the number of windows you are
willing to pay for. A per-account or per-user limit that resists Sybils would need an identity the chain can
check, such as a passkey attestation or a signer. That is the key the decision rules out.

## Where gas is charged, and why there

Validation **reserves** `maxCost` against the account's counter and the global counter. `postOp` then refunds
the reservation down to an upper bound of the real cost.

**Why validation.** The EntryPoint validates every op in a bundle before it executes any. A cap that validation
only checks, and `postOp` settles, lets a bundle of N Sybil ops each pass against the same pre-bundle total, and
the cap is overshot N times. Reserving in validation means each op sees the reservations made before it.
`test_GlobalCapHoldsInsideOneBundle` shows this through the real EntryPoint.

**Why a bounded refund.** EntryPoint v0.7 tells `postOp` a cost that leaves out two things it adds afterwards:
`postOp`'s own gas, and the 10% penalty on unused execution gas. So `postOp` charges `actualGasCost` plus, at the
op's gas price:

    paymasterPostOpGasLimit + 10,000 + (callGasLimit + paymasterPostOpGasLimit) / 10

The charge is capped at `maxCost`. The real debit can never exceed `maxCost`, because `maxCost` is the prefund.
The EntryPoint's own overhead measured about 1,300 gas.

**If `postOp` reverts or does not run**, the EntryPoint undoes `postOp`'s changes but keeps validation's, so the
full `maxCost` stays charged. That is the safe direction. Validation refuses a `paymasterPostOpGasLimit` below
25,000. `postOp` uses about 5,000.

## ERC-7562

| Rule | How the contract complies |
|---|---|
| OP-011: no TIMESTAMP, NUMBER or other block data in validation | The client names the window in `paymasterData`. Validation returns `validAfter` = the window's start and `validUntil` = its end + `GRACE`, and the EntryPoint enforces them (AA32). So an op counted in window k can only execute in window k or its grace period, and no client can spend now against a future window. If a later window is already open, the op is counted there instead, so counters only move forward. |
| STO-031 / EREP-050: own storage and a context are allowed only to a staked paymaster | Validation writes the sender-keyed counter and the global counter, and returns a context. The paymaster must hold at least a bundler's minimum stake (Rundler: 1 ETH) with an unstake delay of at least one day. |
| No other calls in validation | Validation calls no other contract. Provenance is a keccak over calldata and immutables. |

**Shared state and reputation.** The global counter is shared, so when the global budget runs out, ops already
in a mempool fail on-chain, and a bundler may throttle this paymaster. That is the cap working, and it ends with
the window.

**Grace period.** `GRACE` (less than `WINDOW`) keeps an op signed near the end of a window valid long enough for a
bundler to accept it.

`packages/smart-account/examples/erc7562-ownerless.ts` sends the wallet's ops through Rundler v0.11.0 in safe
mode on geth. Run on 14 October 2026, every row did what it expects (38 OK, 0 FAIL):

- the primary account on Safe: its first op (initCode, through the unstaked SafeProxyFactory) and a later op
  were accepted;
- the primary account on Kernel, created beforehand: its first op and a later op were accepted;
- a sub-wallet Safe: its first op (initCode) and a later op were accepted;
- a salt that does not produce the account was refused (`AA33`, `NotFromFactory`);
- the same code unstaked was refused for a later op and for a first op. Rundler's reason was "entity
  stake/unstake delay too low", naming slot 1 (the global counter), which is what STO-031 predicts.

The run used `RUNDLER_ARGS="--tracer_timeout 60s"`. On that machine, which was loaded, P-256 verification
under geth's JavaScript tracer overran Rundler's default 10 seconds on some passkey rows; the bundler reported
a tracer timeout, not a rule. The flag changes no validation rule.

## paymasterAndData

    paymaster (20) ++ paymasterVerificationGasLimit (16) ++ paymasterPostOpGasLimit (16)
      ++ factory index (1) ++ CREATE2 salt (32) ++ window (uint48, 6)

The window is `floor(now / WINDOW)` (`currentWindow()`) when the op is signed. `accountAddress(index, salt)` and
`remaining(account)` are views for clients. Validation costs about 50,000 gas the first time an account is seen
(two fresh storage slots) and less after that. A `paymasterVerificationGasLimit` of 100,000 to 200,000 is ample on
an EVM with standard storage pricing. Sepolia does not price it that way: it charges about 105,000 gas per slot written from zero.
There, the paymaster's first op failed at 150,000 (`AA33`, out of gas), and 300,000 is what the Task 2 rehearsal signs
(docs/deployments.md).

## To decide at deployment

`WINDOW`, `GRACE`, the four limits, the stake amount and the deposit. The constructor refuses incoherent
values: a zero or duplicate factory, a grace of at least one window, a per-op limit above the per-account limit,
a per-account limit above the global limit, a delay under a day. A wrong init code hash sponsors nobody. The
forge tests derive both hashes from the deployed factories, and the deploy step should check them the same way.

## Tests and tooling

- `contracts/test/OwnerlessPaymaster.t.sol` runs against the canonical bytecode in
  `packages/smart-account/fixtures`: EntryPoint v0.7, Safe 1.4.1, Safe4337Module, the passkey signer stack,
  Kernel v3.1 and its factory, and our vendored PasskeyCoSignerValidator. It covers:
  - sponsorship of each account kind;
  - refusals of accounts from another factory instance, from our factory with another singleton, and with a
    wrong salt;
  - each limit, and the global cap inside one bundle and across a window reset;
  - the clock binding at the window and grace boundaries;
  - funding by anyone, and that nothing can withdraw;
  - a fuzzed property: random Sybil bundles, gas limits, fees and clock moves, measured by what the EntryPoint
    actually debited. It checks per-op, per-account and global spend per window, and that the paymaster never
    counts less than it paid.
- `foundry.toml` lets tests read `packages/smart-account/fixtures`, read-only, for this.
- Slither and Mythril (`scripts/mythril.sh`) cover the contract.
