# Runbook — onboarding a liquidity provider

Rev. 2 §6.3 bootstraps the network institution-first: a small vetted set of licensed LPs with
contractual SLAs and the highest per-order limits, before affiliated networks (Phase B) and
long before open retail (Phase C, deferred).

The phases are enforced on-chain by `LPRegistry`, not by this document:

| Phase | Who can be an LP | How they get in |
|---|---|---|
| **A** (launch) | `INSTITUTIONAL` only: licensed PSPs, OTC desks, fintechs | The governor admits them |
| **B** | + `AFFILIATED`: an institution's partner network ("vinculados") | The sponsoring institution admits them, out of its own credit |
| **C** | + `RETAIL`: open P2P | Anyone calls `register()` |

Opening B or C is a governance change that waits out `GOVERNANCE_DELAY` (48 hours by
default). Closing back to an earlier phase is instant.

This is the procedure for adding one LP. It is deliberately slow at the start — the first
trade with a new LP is the one most likely to go wrong, and the cheapest one to get wrong.

## What the LP must have before anything on-chain happens

| Requirement | Why it matters |
|---|---|
| A licensed entity (PSP, OTC desk or fintech) | Rev. 2 restricts Phase A to licensed providers |
| A business bank account with a PIX key | Fiat moves bank-to-bank between LP and user; the protocol never touches BRL |
| Boleto capability, if they will quote boleto | Separate from PIX; do not assume one implies the other. For the on-ramp: a bank API that registers a boleto for an exact amount within minutes. For the off-ramp: the ability to pay a third party's bill the same day |
| A funded EVM address | To post offers. It holds their own liquidity, not ours |
| Posted collateral | Rev. 2 §6.4 puts PIX reversal (MED) and disputes on the LP's collateral, not the protocol |
| A signed SLA | Settlement window, and what happens when they miss it |
| A zkTLS prover for their bank | PIX, boleto and TED settle only on a zkTLS proof of the LP's own bank session (SR2-34). Their bank needs a Reclaim provider template and an allowlisted endpoint (Step 3). |
| Bank API access for the LP node, if they will not operate by hand | Receiving by API Pix, plus the bank's own API to send PIX (and pay/register boletos) with idempotency keys. See Step 3c |
| A bank that names the payer, **only if they will hold per-user caps** | A cap binds a person, and the only place a person is named here is the bank record. The standard API Pix carries no payer document, so their adapter must fill `payerId` or the node can attribute nothing. See Step 3f |

**The PIX key must be the LP's own, at the entity that signed the SLA.** A PIX key belonging
to a third party breaks the one link that makes a dispute resolvable. It should also be
**dedicated to the ramp**: the LP node treats every credit to that key as a possible order payment,
and unrelated business income on it shows up as unreconciled credits.

## Step 1 — testnet first, with real money movement

Before mainnet, the LP completes a full round trip on Sepolia: post an offer, take an
on-ramp order, settle by PIX in production BRL with a zkTLS proof of its bank session, and see the
escrow release. Then the reverse. This needs the Reclaim application credential and a template for the
LP's bank; without both no PIX or boleto order settles, on testnet or on mainnet.

A provider who cannot complete this on testnet will not do better on mainnet, and finding out
costs nothing here.

## Step 2 — admit them, at the lowest credit that works

The credit limit is the most BRL the LP may have **live at once, in total**: every offer's
unlocked and locked liquidity plus every sale it has claimed, on both escrows. Many small
offers do not get around it, and topping an offer up counts against it.

Admitting an institution is a delayed change. The multisig schedules it, and executes it once
`GOVERNANCE_DELAY` has passed:

```bash
CALL=$(cast calldata "setTier(address,uint8,uint256)" $LP_ADDRESS 3 500000)
cast send $REGISTRY "schedule(bytes)" $CALL       # via the multisig
# ... GOVERNANCE_DELAY later, within 14 days
cast send $REGISTRY "execute(bytes)" $CALL        # via the multisig
```

The tier argument is an index: `0 NONE`, `1 RETAIL`, `2 AFFILIATED`, `3 INSTITUTIONAL`,
`4 SUSPENDED`. The last argument is the credit limit **in centavos** (500000 = R$ 5.000,00).
The ops `admin` tool prints the same calldata; check that its tier names match this order
before using it.

The wait is the point: every LP and user can see a new counterparty being admitted before it
can take any exposure. LPs agreed before launch can be admitted at deployment instead
(`INSTITUTIONAL_LPS` in `runbook-mainnet-deploy.md`), with no wait.

Start below what they asked for. Rev. 2 §10.1's reasoning applies to LPs as much as to users:
low initial limits with real volume behind each increase keep the expected value of fraud
negative.

## Step 3 — how their payments are proven

**PIX, boleto and TED: zkTLS, and nothing else.** Since 14 September 2026 the escrows open a
bank-rail offer or sale only on a verifier that proves the bank session itself
(`provesBankSession()`): `FiatEscrow.postOffer` and `OffRampEscrow.openSale` refuse a verifier that does not,
reverting `BankRailNeedsZkTls` (SR2-34 in `docs/security-review-phase2.md`). A colluding quorum could otherwise settle a payment
that never happened. So every PIX or boleto offer names the zkTLS verifier (`ReclaimZkTlsVerifier`),
and the LP proves its own bank session: the credit it received on the on-ramp, the PIX it sent or the
boleto it paid on the off-ramp.

Two preconditions, neither of them on-chain: a Reclaim application credential, and a provider
template for the LP's bank that extracts the payment fields from what the bank writes. Until both
exist, this LP settles nothing by PIX or boleto.

A proof settles only against an allowlisted bank endpoint. If the LP's bank is already allowlisted,
for the rails it will quote, there is nothing to grant on-chain. If not, allowing the bank's
endpoint is a delayed governance change - see "zkTLS endpoints" in
`runbook-mainnet-deploy.md` for what must be reviewed first. Confirm they can generate a proof
from their bank, for both legs, before their first live order, and check the witness set is current:

```bash
npx tsx packages/ramp/examples/reclaim-witnesses.ts
```

Witness sets change with Reclaim epochs, and a stale set silently stops proofs settling.
Adding a witness waits out the delay, so schedule new witnesses as soon as an epoch is
announced. Colluding witnesses can still sign a claim about a session that never happened: the trust
moves from named PSPs to the witness set, bounded by order size and the LP's credit.

**Cards are out of the MVP.** The card rail and the licensed-PSP attestor quorum were removed on 24 September 2026
(`docs/card-rail-removal.md`); there is no card partner to onboard and no attestor key to hold.

## Step 3b — boletos, if they quote them

A boleto is not a standing address, so an LP that includes `BOLETO` in an offer's rail mask
takes on a job PIX does not have:

- **On-ramp.** When a taker locks with `lockOrderByBoleto` (event `BoletoRequested`), the LP must,
  within **one hour**: register a boleto at its bank for exactly the order's `brlCents`, due no
  sooner than three days out; commit to it with `issueBoleto(orderId, commitment)`, where
  `commitment = boletoCommitment(line, salt)` (`packages/ramp/src/boleto.ts`) with a fresh salt;
  and send the taker the line and salt. Missing the hour loses the order, not the LP's money — the
  taker cancels or anyone reclaims — but a pattern of it is an SLA breach.
- **When a boleto order does not release** (cancelled, expired, refunded), cancel ("baixar") the
  boleto at the bank immediately. A taker can still pay a registered boleto after the order is
  gone; nothing on-chain will notice, and the refund is the LP's to make.
- **Off-ramp bills.** A sale whose rail mask is `BOLETO` alone is a seller asking for a bill to be
  paid. Before claiming, get the line and salt from the seller and run
  `verifyBoletoCommitment`: it must open the sale's commitment, carry exactly the sale's amount,
  and not be overdue. (Wallets refuse to open a sale for a bill that is overdue or has no due date.) Pay it the same day, for its face value: a payment of any other amount —
  including a late one with charges — will not settle, and the escrow cannot tell the LP's good
  intentions from a different boleto.
- **Proof.** A boleto settles only on a zkTLS proof from a bank endpoint allowlisted for the BOLETO
  rail (`endpointRails`). Endpoints start PIX-only unless the deployment set `ZKTLS_ENDPOINT_RAILS`
  (6 = PIX + BOLETO); widening one later is a delayed change (`admin zktls:endpoint-rails`), made only
  after checking the template captures the paid barcode, hashed, and the amount from the bank-written
  receipt.

## Step 3c — the LP node, if they automate

`packages/lp-node` does the LP's side of both legs from one process. Read its README before
deploying it; what matters for onboarding is below.

### The duties it takes over, and their clocks

| Leg | Duty | Deadline (contract) | What missing it costs |
|---|---|---|---|
| On-ramp, PIX | Give the taker the PIX key, salt and exact amount (the offer only commits to the key) | Taker's `payBy` = lock + 30 min | The order expires unpaid; nothing on-chain |
| On-ramp, PIX | Prove the received credit with a zkTLS proof of the LP's bank session, and release | Before `payBy` | Taker may dispute while the order is LOCKED; BRL received for an order that then cancels must be refunded |
| On-ramp, boleto | Register a boleto for exactly `brlCents`, `issueBoleto`, give line + salt | Lock + 1 hour | Order expires; SLA breach |
| On-ramp | Cancel boletos and refund BRL for orders that did not release | After the cancellation is final | The taker's money held by the LP |
| Off-ramp | Pay the seller's committed payee (a PIX key or a bill), prove the payment with a zkTLS proof of the LP's bank session, `settleWithProof` | Claim + 45 min | Stale claim: sale reopens. **BRL paid under a stale claim can never settle the sale** |
| Off-ramp | If paid and unprovable: `raiseDispute` while still holding the claim | Before anyone calls `releaseStaleClaim` | Refund to the seller, and an LP-raised dispute that times out is a lost dispute |
| Both, with caps | Count what each payer moves in a Brasília day and month, and refuse what crosses their tier (Step 3f) | At the credit, the capture, or the payee disclosure | A cap that is not counted is not held; the monitor's `lp_node_caps` says so |

### Before it goes live

1. **One node per LP key and journal.** Not on Flux, not replicated: it holds the LP key and, via
   the bank plugin, moves BRL. Run it on the LP's own infrastructure.
2. **Secrets as files**: `LP_KEY_FILE`, `PAYER_REF_SECRET_FILE`, bank credentials through the
   plugin's own `*_FILE` variables. The strategy file (`LP_CONFIG`) holds no secrets and should be
   reviewed like code.
3. **The journal** (`STATE_FILE`) on a persistent, encrypted, backed-up volume. It holds seller PIX
   keys and the salts behind every offer commitment; losing it means sellers must re-disclose and
   takers of old offers cannot be served (payments are still never doubled - see the README).
4. **The bank plugin** is the LP's to write and to prove. The receiving side can use the
   standard API Pix adapter (`packages/lp-node/src/api-pix.ts`: OAuth2 client credentials, mTLS,
   `/pix` polling, devolução); sending is bank-specific. Whatever it is built from, two calls with one idempotency key must
   move money at most once, and `SETTLED` must mean the SPI settled. Run the LP's adapter against
   `packages/lp-node/test/safety.test.ts`'s crash scenarios (lost response, refused connection)
   on the bank's sandbox before production.

   **Banco Inter has a ready adapter** (`BANK_MODULE=packages/lp-node/src/banks/inter-module.ts`), built from its public
   API reference and OpenAPI documents (read 14 September 2026) and tested against a mock built from them - not yet
   against Inter itself. For an LP banking at Inter:
   - create the integration in Inter's Internet Banking with the scopes `pagamento-pix.write/read`,
     `pagamento-boleto.write/read`, `extrato.read`, `pix.read/write`, and `boleto-cobranca.read/write` if the LP issues
     boletos; download its certificate and key;
   - **turn manual approvals off** for the integration, or payments stay PENDING past the pay window;
   - put `INTER_STATE_PATH` on the same persistent, encrypted, backed-up volume as `STATE_FILE`, one process per file:
     Inter cannot look a Pix payment up by its idempotency id, so this journal is how a restart finds what was sent.
     Lose both and money still moves once, but the LP loses that sale;
   - the payer data for boletos it registers (`INTER_BOLETO_PAYER_FILE`) is the LP's compliance decision to sign off;
   - leave collection (utility) boletos off its off-ramp rails: Inter's payment endpoint needs a due date they lack;
   - Inter's API Pix lists only Pix paid against a charge (`cob`), so serve charges rather than a static BR Code
     (`onramp.pixCharge: "cob"`), or credits may never be seen; the integration then also needs the `cob.read` and
     `cob.write` scopes;
   - before real money, run `packages/lp-node/examples/bank-sandbox-check.ts` in Inter's sandbox: confirm a paid charge is
     listed, send R$ 0,01 (only with its explicit flag) and watch it go PENDING -> SETTLED with an end-to-end id, and
     record whether a repeated POST with the same `x-id-idempotente` returns the original payment.
5. **Provers.** The node needs a prover for every verifier its offers name: for PIX and boleto, a zkTLS
   prover over the LP's own bank session, which needs the Reclaim credential and the bank's template;
   reached as a `PROVER_MODULE`. A verifier with no prover makes
   the on-ramp passive and the off-ramp skip that verifier's sales. Never give the node the witnesses' keys
   in production: the built-in local-key witnesses load only with `LP_NODE_DEV=1`, for testing.
6. **Confirmations** (`confirmations` in the strategy): the node pays BRL only against a claim, and
   refunds only against a cancellation, that many blocks deep. On Ethereum L1 use at least 12, or
   wait for finality; keep `reorgWindow` above it.
7. **Price protection** is the LP's decision, recorded in the strategy file: `minSpreadBps` (never
   sell below the oracle plus this), `minMarginBps` (never buy above the oracle less this),
   `maxOracleDeviationBps` (stop when its own feed and the oracle disagree), `liquidity` and
   `maxOfferBrlCents` per asset, `dailyBudgetCents` for the off-ramp.
8. **Expose** only the counterparty API (`API_PORT`) publicly, behind TLS and rate limiting; keep
   `/status` and `/metrics` (`PORT`) private, and scrape `mova_lp_*` into the same alerting as the
   monitor. Page on `mova_lp_payments_unresolved`, `mova_lp_held`, `mova_lp_disputes_open` and
   `mova_lp_unreconciled_credits` above zero, and on a stale `mova_lp_last_tick_timestamp_seconds`.
9. **PIX charges** (`onramp.pixCharge`). `"static"` (the default) serves a BR Code for the LP's key; `"cob"` creates one
   Banco Central API Pix charge per order once its lock is `confirmations` deep - fixed amount, the order's txid, expiring
   `cobMarginSeconds` (default 300) before the pay window closes - serves the PSP's dynamic code, matches the credit by
   that txid only, and removes the charge of an order that did not release. Use `"cob"` wherever the PSP's API Pix lists
   only charge-paid Pix (Banco Inter) - and it is the better match everywhere. Instructions answer 409 until the charge
   exists. Tell wallet operators the PSP's QR host (for their `pixLocationHosts`), and in the sandbox confirm a paid charge
   appears in `GET /pix` with its txid.
10. **Transactions** (`tx` in the strategy): cap fees with `tx.maxFeePerGasWei` and
   `tx.maxPriorityFeePerGasWei`, and set `tx.replaceAfterBlocks` so a stuck transaction is re-sent at its
   nonce with higher fees. The gas limit is the estimate plus `tx.gasHeadroomPercent` (default 20%) plus
   25,000, so a transaction included a block after its estimate does not run out of gas; a revert that still
   happens is logged with its reason. Without a `tx` section nothing is replaced and fees are uncapped. Alert on
   `mova_lp_tx_fee_capped_total` rising: a transaction at the cap stalls the LP key until fees fall, and the
   cap is the LP's to raise.
11. **The journal** compacts itself past `compactJournalAtBytes` into one snapshot, crash-safely; watch
    `mova_lp_journal_bytes`. Back up after compaction as before - the snapshot holds the same secrets.
12. **The PIX webhook**, if the PSP sends one: `POST /v1/webhook/pix` on the API listener, authenticated by
    `webhook.auth` - `hmac` with `PIX_WEBHOOK_SECRET_FILE`, or `proxy-mtls` behind a reverse proxy that
    verifies the PSP's certificate (the node then accepts it only from loopback). It only speeds matching up:
    every payment is re-read from the API Pix, never taken from the webhook body.
13. **Cards** were removed on 24 September 2026: there is no acquirer module or `onramp.card` section to configure
    (`docs/card-rail-removal.md`); a configuration that still names them is refused.
14. **Disputes** (`arbitration.url`): the node files salted evidence commitments with the arbitration desk
    for every disputed order or sale; `mova_lp_evidence_errors_total{reason="desk_too_old"}` means the desk
    predates its case lookup by order and must be upgraded.

### Smoke test on testnet

With the node running against the Sepolia deployment, the Step 1 round trip becomes: watch
`/status` show the offers quoting; lock a small order as a taker and fetch instructions from
`POST /v1/onramp/instructions` (signed with `signInstructionsRequest`); pay the BR Code; see the
order release. Then open a small sale, disclose the payee to `POST /v1/offramp/payee`, and see the
node claim, pay, and settle. `examples/lp-node-live.ts` is the same script against anvil with a
mock bank - run it first to see what "working" looks like.

## Step 3d — Movva gateways: the LPs that mint and redeem

Users hold only Movva. A **gateway** is the LP that turns USDT into Movva for the on-ramp and Movva back
into USDT after the off-ramp (docs/movva.md, "Why LPs mint, and not every order"). Minting and redeeming
happen at the reserve's rate, which is the one place a wrong price moves value, so gateways are Phase A
institutions with a contract with the issuer - never retail or affiliated LPs.

1. **The contract with the issuer** covers the mint and redeem fees, what happens if either side acts on a
   rate that turns out wrong, and the gateway's KYC of its own customers.
2. **Admission** is two delayed changes: `INSTITUTIONAL` on the registry (Step 2) and
   `admin movva:gateway <reserve> <lp> true` through `gov:schedule` / `gov:execute`. Removing a gateway is
   instant. Movva trades on its **own** escrow pair (`runbook-mainnet-deploy.md`, section 3b), which shares
   the registry, so the LP's credit limit is one number across both pairs.
3. **The node's `gateway` section** (`packages/lp-node/README.md`, "The Movva gateway"). Every cap and
   cost must be stated; none has a default:
   - `maxMintUsdt`, `maxMintUsdtPerDay`, `keepUsdt` - the most a wrong rate can cost them per mint and per day;
   - `maxRedeemMovva`, `maxRedeemMovvaPerDay`, `keepMovva` - the working balance they keep in Movva;
   - `usdtCostBps` / `usdtSaleBps` - what buying and selling USDT actually costs them, so offers and sales
     are priced from cost rather than from par;
   - `maxFeeBps` (default 0) - a mint or redeem fee raised on-chain stops the node until they agree to it. The reserve
     launches at 10 bps each (docs/movva.md, "Fees"), so a gateway sets at least 10 or its node will not mint;
   - `minCollateralRatioBps` (default 10000) - below par the node **holds** Movva rather than redeem it at a
     haircut the ratio may recover from;
   - optionally `usdtPrice` and `maxRateDeviationBps`, so the node checks the reserve's rate against their own
     desk before minting or redeeming.
4. **Alerts to add** on their side: `mova_lp_gateway_held` (the reserve is below par, or a transaction needs
   a human), and `mova_lp_gateway_blocked{op="mint"}` persisting (paused, frozen, stale rate, ratio floor,
   supply cap - the label says which). A stale rate outside the FX core session (13:30-21:00 UTC on
   weekdays) is the market closed, not a fault: page on it only inside the core session.
5. **First mint on testnet**, watched: the node mints only the shortfall of its Movva offer, zeroing any
   leftover USDT allowance first; a buy-back redeems only what exceeds `keepMovva`.
6. **Market hours.** The reserve mints and redeems only at a fresh Pyth rate, so it refuses at night, at
   weekends and on 25 December and 1 January, while Movva's band takes the last close and the gateway's
   offers keep selling. Top up Movva offers before each close. A gateway that runs out stops quoting until
   the market reopens, and Movva it buys back waits to be redeemed (docs/movva.md, "The rate").

## Step 3e — node-provider rewards

Mova shares part of its fees with the LPs who settle volume (docs/movva.md, "Fees"). The LP does nothing extra to earn -
settling is enough - but four things decide whether it is paid:

1. **Eligibility, and the contract.** INSTITUTIONAL and AFFILIATED LPs earn; RETAIL and SUSPENDED do not, and settlements
   under R$ 10,00 do not count. Write into the contract that **settling with itself, or with any address it controls, is a
   breach**; that each epoch's volume can be voided during its three-day review; and that the LP can be excluded (SR2-36).
2. **NodeRewards must be counting.** After a deployment its governor binds the ramp's registry once:
   `admin rewards:registry <rewards> <registry>` - immediate while NodeRewards has never been funded, a scheduled change after.
   Until then every settlement emits `RewardsHookFailed` on the registry and counts for nothing, and the monitor's
   `node_rewards_wiring` warns once there is anything to share.
3. **The node's `rewards` section** (`packages/lp-node/README.md`, "Node-provider rewards"):

   ```json
   "rewards": { "contract": "0x…NodeRewards", "claim": true, "minClaim": "0", "lookbackEpochs": 12, "to": "0x…" }
   ```

   The node finalizes epochs whose review has ended and claims its share; `to` pays a wallet other than the LP key. It refuses
   to start against a NodeRewards bound to a different registry.
4. **Alerts on their side:** `mova_lp_rewards_counting` at 0 (`/status` `rewards.notCounting` says whether NodeRewards is unbound,
   bound elsewhere, or has excluded them), and `mova_lp_rewards_claimable` growing while `mova_lp_rewards_claims_total` does not.

On Mova's side the share starts at 0. Raising it is `admin gov:schedule splitter:share <splitter> <bps>`, then `gov:execute`
after the delay; lowering it is immediate. The monitor's `node_rewards_unclaimed` warns when an epoch sits finalizable for two
days or rewards go unclaimed for 30, and `node_rewards_balance` fails if the pool ever holds less than it has booked.

**Every epoch, before its review ends** (three days after the epoch): look for self-dealing - one taker settling again and again
with one LP, takers funded by the LP, the same Movva sold and bought back. Where you find it, send
`admin rewards:void <rewards> <epoch> <lp>` for each epoch still in review, then `admin rewards:exclude <rewards> <lp> true`. Both
are immediate; what the LP earned in epochs already past review stays claimable, and reinstating it waits out the delay.

## Step 3f — per-payer caps, if the LP is asked to hold them

Rev. 2 §10.1 asks for per-user daily limits in five tiers. They are **not on-chain**, and they cannot be:
on-chain a user is deliberately unlinkable, so a cap keyed on an address would cap nothing and a cap keyed
on an identity registry would undo the privacy the rail exists for. They live in the LP node, keyed on the
**payer the LP's bank names** — the one place a person is identified in this rail — and they are **off unless
the LP configures them** (`packages/lp-node/README.md`, "Per-payer caps").

What that means for onboarding:

1. **Decide whether this LP holds caps at all, and at what numbers.** Nothing ships with a limit set. The
   tiers, their daily and monthly limits, and who sits in which are the compliance decision — write them into
   the SLA, not into a config review. (An illustration only: tier 0 at R$ 2.000,00 a day and R$ 10.000,00 a
   month, tier 4 unlimited.)
2. **Check their bank names the payer before you agree to a cap.** The standard API Pix (2.10.0) carries no
   payer document, so an LP receiving only through it can attribute nothing, and with the default
   `unknownPayer: "refuse"` every PIX it cannot attribute is refused and returned. Ask for a `listIncoming`
   sample from their bank plugin showing `payerId`. A boleto payout names a bill, not a person, so caps do not
   really bind on an off-ramp that pays bills.
3. **The caps are per LP, and stay that way.** A person's totals at one LP are invisible to every other LP,
   and nothing about them reaches the chain, the wallet or the matcher. Two LPs each holding a R$ 2.000,00
   daily cap means a person can move R$ 4.000,00 across both. If the programme needs one number across the
   network, that is a shared identity registry and a different decision — do not pretend the node's caps are it.
4. **Where a refusal lands, so support knows.** On the on-ramp the payer is known only when their money
   arrives, so a refused purchase is one where **the LP does not release and returns the BRL** (PIX devolução); the crypto never moves. The user's wallet is told `cap_reached` and never the
   total. On the off-ramp the seller is refused at the disclosure, before anything is claimed, and may take
   the sale to another LP.
5. **Watch that the node is actually accounting them.** Point the monitor at the node's private operations
   URL (`LP_NODE_STATUS_URL`, optionally `LP_NODE_NAME`): `lp_node_caps` fails if that node reports no caps,
   if its clock puts it in the wrong Brasília day (limits would reset at the wrong hour), or if its cap ledger
   stops being written. A cap nobody checks is a promise, not a control.

`/status` on the node's **private** port shows each payer's hashed reference (`payerRef`) with their day and
month totals — that is how the LP reads someone's usage, and how it gets the reference to put in
`caps.payers` to raise a tier. It never shows a document. An LP with its own KYC provider points
`TIER_MODULE` at it instead, which is the only way to tier someone before their first payment.

## Step 4 — first live trade, watched

Smallest order the offer allows, both directions, with someone watching the monitor. Confirm:

- the order locks and the proof verifies (zkTLS, for PIX and boleto);
- the escrow releases to the right side;
- the BRL actually arrives in the destination account, at the amount quoted;
- `oracle_freshness` stayed quiet — a trade settled against a stale band is a near miss, not
  a success;
- if the LP runs the node: `mova_lp_payments_unresolved` and `mova_lp_held` stayed at zero, and
  the journal shows one payment intent and one result per sale.

## Step 5 — raise limits on evidence

Raise the credit limit when settled volume justifies it, not when asked. The registry tracks
settled volume and disputes lost, and the matcher already ranks on it — an LP's reputation is
earned in public. Raising a limit is scheduled exactly like Step 2; cutting one is instant.

This is the LP's limit. A **user's** limit is a different lever and a different owner: it is the
per-payer tier in the LP's own node (Step 3f), raised by naming that payer's `payerRef` in
`caps.payers` or by their tier moving in the LP's KYC system. Neither is visible on-chain.

## Phase B — affiliated LPs

Once Phase B is open, an active institution admits its own partners. It calls, from its LP
address:

```bash
cast send $REGISTRY "sponsorAffiliate(address,uint256)" $AFFILIATE $CREDIT_CENTS
```

The affiliate's credit is **carved out of** the sponsor's: the sponsor gives up that much of
its own headroom, the carve-out cannot exceed what the sponsor has free, and the sponsor plus
all its affiliates can never have more live than the sponsor's limit. The same call with a
different amount changes an affiliate's credit; `revokeAffiliate(address)` ends the
relationship. No governance delay applies, because no risk is added beyond the sponsor's own
limit, which was itself admitted with a delay.

The sponsor is responsible for its affiliates the way the SLA says. On-chain, suspending the
sponsor immediately stops every affiliate taking new exposure.

## Removing an LP

```bash
cast send $REGISTRY "setTier(address,uint8,uint256)" $LP_ADDRESS 4 0    # SUSPENDED, instant
```

Suspension stops them taking new exposure. It deliberately does **not** touch their live
offers or in-flight orders: stranding an LP's posted liquidity mid-trade would be a worse
outcome than one more settlement completing. Orders already locked run to settlement or to
their timeout refund, both of which are permissionless. Reinstating a suspended LP is a
delayed change.

## What to do when an LP does not settle

Nothing, at first — the timeout refund is automatic and permissionless, and the user's funds
return without anyone's intervention. Then:

1. Check whether it was one order or a pattern.
2. A pattern means suspend first, investigate second.
3. A disputed settlement goes to the arbitration desk, and the ruling moves the escrow to one
   side against the LP's collateral. The chain makes the ruling attributable, not correct —
   arbitration is a human process, and Phase A's small vetted set is what makes it tractable.

**Disputes, from the LP's side.** Anyone may submit the desk's signed ruling — post it, then
submit it again a day later to execute — so an LP a ruling favours does not wait for the
governor. A dispute nobody rules on within the escrow's `DISPUTE_TIMEOUT` (30 days by default)
returns the funds to where they came from: on-ramp, to the LP's offer; off-ramp, to the seller.
An LP that paid a seller and then disputes must get a ruling inside that window or lose the sale.

What counts against an LP's limit, so the rules are known before the first dispute:

| Ending | On-ramp | Off-ramp |
|---|---|---|
| Ruled `RELEASE` | counts as settled volume; also a lost dispute if the LP raised it | settled volume |
| Ruled `REFUND` | nothing | a lost dispute |
| Timed out | a lost dispute only if the LP raised it | a lost dispute only if the LP raised it |

A lost dispute halves a retail or affiliated LP's limit; institutional limits are set by the
governor. A counterparty's dispute that nobody answers never costs the LP.
