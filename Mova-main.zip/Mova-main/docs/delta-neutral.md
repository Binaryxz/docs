# Delta-neutral yield on Hyperliquid (task 3.3)

Status: contracts and keeper built and tested against a simulated HyperCore and against real
HyperEVM read data. **Not deployed anywhere, not audited, and not connected to the shielded
vault.** Connecting it is a decision for the client, set out at the end of this document.

```
contracts/hyperliquid/HyperCore.sol                   precompile reads + CoreWriter actions
contracts/hyperliquid/HyperCoreDeltaNeutralVault.sol  the product: shares, exits, roles, gates, governance
contracts/hyperliquid/DeltaNeutralStrategy.sol        linked library: book, next step, orders, funding
contracts/hyperliquid/IDeltaNeutral.sol               shared types, events, errors
contracts/test/HyperCoreDeltaNeutralVault.t.sol       bounds, breakers, keeper-offline exit
contracts/test/HyperCoreContractSize.t.sol            EIP-170/3860 sizes; the library runs only as the vault
contracts/test/utils/HyperCoreSim.sol                 HyperCore stand-in etched at the real addresses
contracts/test/HyperCoreReadFork.t.sol                the ABI decoded against live HyperEVM
packages/yield/src/hl-keeper.ts, src/bin/hl-keeper.ts the keeper
packages/yield/src/delta-neutral.ts                   backtest + the on-chain breaker, modelled
packages/ops/flux/hl-keeper.json                      Flux spec
```

## 1. What it is

An Ethena-style carry: long the spot asset on HyperCore, short the same size of its perpetual.
Price moves cancel; what is left is funding (paid to shorts while positive) less fees.

The earlier design stopped at a backtest because "running it needs collateral on Hyperliquid and
keys to trade it, which means custody outside the pool". This design removes the trading key:

- **The contract is the account.** `HyperCoreDeltaNeutralVault` holds USDC on HyperEVM and, as its
  own address, balances and positions on HyperCore. The only thing that moves them is the contract
  calling CoreWriter. There is no API wallet and no agent key.
- **The keeper chooses when, never what.** The keeper role can call `rebalance()` and `harvest()`,
  both argument-free. Every order is computed inside the contract from HyperCore precompile reads
  and bounded there.
- **Exits do not need the keeper.** `requestRedeem`, `processExits`, `claim` and `deleverage` are
  open to anyone.

It is still custody outside the Ethereum pool: the funds sit on Hyperliquid's chain, under its
validators (section 6).

## 2. Verified HyperEVM / HyperCore facts

Every value below was taken from Hyperliquid's documentation or code, then checked read-only
against mainnet. No transaction was sent.

Short names for the sources used in the table (all under `hyperliquid.gitbook.io/hyperliquid-docs/`):
- **[IHC]** `for-developers/hyperevm/interacting-with-hypercore`, including its `L1Read.sol` and
  `CoreWriter.sol` attachments
- **[TIMING]** `for-developers/hyperevm/interaction-timings`
- **[XFER]** `for-developers/hyperevm/hypercore-less-than-greater-than-hyperevm-transfers`
- **[CDW]** Circle's `developers.circle.com/cctp/references/coredepositwallet-contract-interface`

| Fact | Value | Source |
|---|---|---|
| CoreWriter | `0x3333…3333`, `sendRawAction(bytes)`; emits `RawAction(address indexed user, bytes data)`; deployed code is 544 bytes and does nothing but loop and emit | [IHC]; `eth_getCode` |
| Action encoding | `abi.encodePacked(uint8(1), uint24(actionId), abi.encode(...))` | [IHC]; matches live CoreDepositWallet logs (`01 00000d …`) |
| Limit order (id 1) | `(uint32 asset, bool isBuy, uint64 limitPx, uint64 sz, bool reduceOnly, uint8 tif, uint128 cloid)`; tif 3 = IOC; px and sz are ×10⁸ of the human value | [IHC] |
| USD class transfer (id 7) | `(uint64 ntl, bool toPerp)` | [IHC] |
| Send asset (id 13) | `(address dest, address subAccount, uint32 srcDex, uint32 dstDex, uint64 token, uint64 wei)`; `uint32.max` = spot | [IHC] |
| Asset ids | perp = index in `meta.universe` (BTC 0, ETH 1, HYPE 159); spot = 10000 + spot index | `api/asset-ids`; info API |
| Read precompiles | position `0x800`, spotBalance `0x801`, withdrawable `0x803`, markPx `0x806`, oraclePx `0x807`, spotPx `0x808`, perpAssetInfo `0x80a`, spotInfo `0x80b`, tokenInfo `0x80C`, bbo `0x80e`, accountMarginSummary `0x80F`, coreUserExists `0x810` | `L1Read.sol` |
| Price units | perp: human = raw / 10^(6 − szDecimals); spot: human = raw / 10^(8 − base szDecimals) | [IHC]; checked on mainnet: `oraclePx(1)` = 250990 → $2509.90 |
| USD units | accountMarginSummary, withdrawable, entryNtl: 1e6. USDC spot balance: 1e8 | mainnet reads vs info API |
| Tick and lot | ≤ 5 significant figures; ≤ 6 − szDecimals decimals (perps), 8 − szDecimals (spot); integer prices always allowed | `api/tick-and-lot-size` |
| USDC in | Circle's CoreDepositWallet `0x6B9E773128f453f5c2C60935Ee2DE2CBc5390A24`: `deposit(amount, dex)`, where 0 = perps and `uint32.max` = spot. `tokenInfo(0).evmContract` returns it. Tokens sent to it directly are lost. A new HyperCore account costs 1 USDC | [CDW]; `tokenInfo(0)` |
| USDC out | `sendAsset` to the system address `0x2000…0000`. Credited by a system transaction in the next EVM block. Gas is paid in HYPE from the sender's HyperCore spot balance | [XFER] |
| Timing | after an EVM block: EVM→Core transfers, then CoreWriter actions. Reads reflect HyperCore as of block construction. Orders are "delayed onchain for a few seconds" | [TIMING], [IHC] |
| Silent failure | HyperCore validates actions after the block. A rejected action leaves no EVM trace. An account that does not exist before the block cannot act | [TIMING], `api/activation-gas-fee` |
| Invalid read | consumes all gas passed to the call | [IHC]; observed `PrecompileError` |
| Funding | hourly, `F/8` where `F = premium + clamp(0.01% − premium, −0.05%, 0.05%)`; no precompile exposes it | `trading/funding` |
| Markets checked | ETH perp: szDecimals 4, max 25×. HYPE perp: 159, max 10×. UETH spot: @151, token 221, szDecimals 4, weiDecimals **9**. HYPE spot: @107, token 150, weiDecimals 8 | info API `meta` / `spotMeta` |

**Live check.** `contracts/test/HyperCoreReadForkTest` repeats this against `https://rpc.hyperliquid.xyz/evm`.
It sends each read as a raw `eth_call` and decodes the result with the library's own structs. It
passed on 2026-09-13 with ETH at $2,506.90. A local fork cannot run the precompiles, which are
native code in the node, so the test calls the live RPC instead.

## 3. How the contract trades

**Target.** Deployable capital is equity less claims and the HyperEVM buffer (`idleBufferBps`). At
target leverage L, a short of notional S needs S of spot and S/L of margin, so
`S = deployable × L / (L + 1)`.

**One step per keeper call, most urgent first.** Each step is re-derived from reads, never from
what the contract last sent.

0. No HyperCore account yet: bridge a little USDC. An action from a non-existent account is rejected.
1. A long perp position (never intended): close it, reduce-only.
2. Delta outside `deltaToleranceBps`. Too little short: sell perp, if exposure may grow and margin
   allows; otherwise sell spot. Too little spot: buy back short, reduce-only. It never buys spot to
   chase delta, because that could spend USDC owed to exits.
3. Leverage above `maxLeverageBps`: top up margin from spot USDC, else shrink both legs.
4. More exposure than target (unwinding, or equity fell): shrink both legs.
5. HyperEVM buffer low: bridge spot USDC back, or release margin above the hard cap.
6. Below target, and adding is allowed: fund margin, then spot USDC, then both IOC orders in one call.

**Every order** is IOC and priced `slippageBps` through the oracle (perp) or the spot price. Spot
trades only while spot is within `maxSpotDeviationBps` of the oracle. Buys round the tick down and
sells round it up, so rounding never widens the band. Sizes round down to the lot. Each order is at
most `maxOrderNotional` and is charged to `maxDailyTurnover`.

**Asynchrony.** Every call that acts, and every NAV-priced call (`deposit`, `requestRedeem`,
`checkpoint`), waits `settleSeconds` after the last action. `totalAssets()` can omit value that is
still in flight inside that window, but nothing priced runs there.
`test_NothingPricedRunsWhileActionsAreInFlight` checks this.

## 4. Bounds, and what a compromised keeper can do

Suggested launch parameters, with the Foundry test defaults in brackets where they differ:

| Parameter | Launch | Why |
|---|---|---|
| `targetLeverageBps` / `maxLeverageBps` | 2× / 3× | ETH liquidates a 2× short at +47% (backtest model); at most half the venue's max is enforced on-chain |
| `slippageBps` | 30 | band around the oracle |
| `maxOrderNotional` | $25,000 [$50,000] | per order, per leg |
| `maxDailyTurnover` | $200,000 [$2,000,000] | keeper-placed notional per 24h |
| `minActionInterval` / `settleSeconds` | 60 s / 5 s | pace, and time for actions to land |
| `deltaToleranceBps` / `maxSpotDeviationBps` | 200 / 100 | |
| `idleBufferBps` / `exitFeeBps` | 1000 / 20 | instant exits; the fee pays for the unwind an exit causes |
| `fundingPauseE8` / `fundingUnwindE8` / `fundingTau` | 0 / −1141 (−10% APR) / 84 h | section 5 |
| `maxDrawdownBps` | 300 | |
| `depositCap` | $1,000,000 | |

**Worst case per keeper call.** At most two orders, one per leg, each at most `maxOrderNotional`.
Each fills at worst at the edge of the band and pays the taker fee: perps 4.5 bps, spot 7 bps at the
base tier (`trading/fees`).

- Formula: `2 × maxOrderNotional × (slippageBps + 7 bps)`
- At launch parameters: 2 × $25,000 × 0.37% = **$185 per call**.

**Worst case per day.** The turnover cap binds long before the rate limit does: at $25,000 per
order, the $200,000 budget is spent in four calls.

- Formula: `maxDailyTurnover × (slippageBps + 7 bps)`
- At launch parameters: $200,000 × 0.37% = **$740 per day, 0.074% of a full $1M vault**.
- A fixed 24h window allows twice that across a window boundary: $1,480 in any 24 hours.
- The guardian ends it immediately with `pauseExposure()`. Rotating the key uses `setKeeper`, which
  waits out the governance delay.

**Measured.** `test_ACompromisedKeeperFillingAtTheBandEdgeIsBoundedByTurnover` makes every fill
land exactly at its limit, as a keeper colluding with the only maker would arrange. With a $250,000
budget the keeper was stopped by `TurnoverExhausted`, and the vault lost $525.93, under the
$926 bound.

**What the keeper cannot do.**
- choose a price, a size or a direction;
- trade outside the band, or trade spot while it is off the oracle;
- raise leverage past the cap;
- spend USDC owed to claims (no new exposure while any claim is unfunded; tested);
- block exits (anyone can process them);
- pause or change anything.

**Also bounded.** `deleverage()` and `processExits()` are open to anyone, but they only reduce risk
or fund recorded claims, and every order they place uses the same band and size cap.

**The library split changes none of these bounds** (section 10). The numbers above were re-measured
after the split and are identical: the same $525.93 loss under the same forced fills, and the same
17 `processExits` steps for the keeper-offline exit.

## 5. Breakers

**Funding.** No precompile exposes funding, so the contract estimates it:

1. It reads best bid, best ask and the oracle.
2. It computes the premium as `(max(bid − oracle, 0) − max(oracle − ask, 0)) / oracle`, clamped to ±5% per sample.
3. It applies Hyperliquid's formula to get an hourly rate.
4. It averages that rate with weight `dt / (tau + dt)`.

Because each sample's weight is the time since the previous one, sampling more often adds precision,
not influence. `test_SpammingSamplesDoesNotAmplifyAManipulatedBook` checks this: a manipulated book
sampled 60 times in one minute leaves the 84-hour average near its resting value.

The thresholds are the ones the backtest validated: a pause floor of 0 and a 7-day window, where an
84-hour EMA is the equivalent of a 168-hour mean. Checked on 180 days of real ETH data
(`npx tsx packages/yield/examples/backtest.ts`, run 2026-09-13):

- The formula reproduces all **4,320** published hourly rates from their published premiums, with a
  maximum error of 5·10⁻¹¹.
- The EMA breaker would have paused for **457 h**; the backtest's trailing 7-day mean flags **450 h**.
  The two disagree in 109 h, mostly around transitions.
- Unwinding (below −10% APR) would have triggered for **11 h**.

**What is approximate.** The venue computes the premium from impact prices sampled every few
seconds; the contract uses best bid/ask, sampled only when called. The formula check above is exact.
How closely on-chain bbo samples track the venue's impact-price premium has **not** been measured.
The keeper compares the venue's published funding with the contract's estimate and reports on
`/status` when they disagree about the pause floor. That comparison is an operator signal only; the
contract does not read it.

**Drawdown.** A fall of `maxDrawdownBps` in the share price closes deposits and new exposure. Only
the governor can `resume()`, which re-bases the high-water mark.

## 6. Exits with the keeper offline

1. `requestRedeem(shares)` prices the shares at NAV less `exitFeeBps`. It pays at once from HyperEVM
   USDC that no earlier claim is owed; otherwise it records a claim.
2. Anyone calls `processExits()`, one step per settle window:
   - bridge HyperCore spot USDC to HyperEVM;
   - otherwise, move perp margin above the hard-cap requirement to spot;
   - otherwise, close both legs by the shortfall.
3. Anyone calls `claim(id)`, which pays the receiver.

`test_AFullExitWorksWithTheKeeperOffline` runs this against the simulator. A holder with $300k in a
deployed position exits in **17** `processExits` steps (a $50k order cap). The holder who stays keeps
at least 99.9% of his share price. `deleverage()` protects the margin in a rally with nobody's key.

**Operational dependency.** Bridging USDC to HyperEVM costs HYPE on HyperCore. Anyone can top it up
with `fundCoreGas()`. If the vault's HyperCore HYPE runs out, step 2's first rung is rejected silently
and exits stall until someone funds it. Monitor it.

## 7. What could not be verified

- **End-to-end CoreWriter behaviour.** No transaction was sent, so every action's effect on HyperCore
  is untested: order fills, class transfers, sendAsset. Before any mainnet use this needs a run on
  HyperEVM testnet (chain 998, `https://rpc.hyperliquid-testnet.xyz/evm`).
- **Units of `usdClassTransfer.ntl`.** Assumed 1e6 USD, from hyper-evm-lib
  (`github.com/hyperliquid-dev/hyper-evm-lib`, by Obsidian, not Hyperliquid). The docs do not say.
- **Spot order `sz` scaling.** The docs say ×10⁸ for all orders; this has not been exercised on spot.
- **Timing.** The exact order delay, whether cancels are delayed, and the HYPE cost of HyperCore→EVM
  transfers at real base fees.
- **Account abstraction.** CoreWriter action 16 can switch an account to unified or portfolio margin.
  The contract never sends it and assumes separate spot and perp balances; the default for a new
  contract account is unverified.
- **Venue behaviour** outside the model: auto-deleveraging of profitable shorts, and liquidation
  mechanics at the venue's margin tiers.
- **The simulator** (`HyperCoreSim.sol`) encodes the documented rules but is not HyperCore.

## 8. Choosing the asset

| Pair | Spot leg custody | Notes |
|---|---|---|
| ETH perp (1) + UETH spot (@151) | UETH is Unit-bridged ETH: a 2-of-3 MPC guardian set (`docs.hyperunit.xyz/architecture/guardian-network`) | deepest perp; matches the backtest |
| HYPE perp (159) + HYPE spot (@107) | native to HyperCore | perp max 10×, so `maxLeverageBps` ≤ 5×; higher volatility and funding |

The contract takes the perp index and spot market as constructor arguments. It reads szDecimals,
weiDecimals and the quote token from HyperCore at deployment and refuses a spot market that is not
quoted in USDC.

## 9. The bridge, and the decision the client has to make

The client requirement reads: "all funds live in immutable Ethereum contracts; if any service dies
or is compromised, no user loses funds or access". **This product cannot meet that as long as its
funds are on Hyperliquid**, and no L1 adapter was built into the shielded `YieldVault`, deliberately.

**What a user would have to trust to move funds there.**

- **Circle CCTP V2** (Ethereum domain 0 → HyperEVM domain 19), then CoreDepositWallet into HyperCore:
  - Circle's attestation service;
  - Circle's upgradeable, pausable contracts: CoreDepositWallet has owner, pauser and rescuer roles,
    and USDC has a blacklist.
- **HyperBFT consensus.** HyperCore's state, including the vault's balances and positions, is what
  Hyperliquid's validators say it is:
  - more than two thirds of stake;
  - the active set is the top 27 validators by stake;
  - no automatic slashing (`hypercore/staking`).
- **The legacy Arbitrum bridge** (Bridge2, `0x2df1c51e…3df7`), if used:
  - withdrawals are signed by a **4-key** hot validator set (3 of 4 by power), not the full consensus set;
  - a 200-second dispute period, during which lockers can pause;
  - read on Arbitrum at block 504,832,412.
- **For ETH exposure via UETH:** Unit's guardian set.
- **The venue itself:** its oracle, matching, liquidation and auto-deleveraging.

**Why an adapter under the shielded vault is not a small step.**
- `YieldVault.totalAssets()` would have to count funds on another chain. Ethereum cannot read
  HyperEVM state trustlessly, so the valuation would come from an attestor or oracle quorum, a new
  service whose compromise could misprice every shielded share.
- Exits would take minutes to hours through CCTP rather than one transaction, and `maxWithdraw`
  would have to report that.
- Every movement between the vault and Hyperliquid is a public bridge transfer. It carries no user
  identity, but it publishes the aggregate flow.

**The options.**

1. **Keep it separate** (recommended until the client decides). The delta-neutral vault is its own
   HyperEVM product. A user who wants it moves funds out of the shielded pool, in the open, and
   accepts the trust list above. The shielded vault's guarantees are unchanged.
2. **Connect through a bridge adapter.** Accept CCTP + HyperBFT + an attested NAV for that slice of
   the shielded vault. Cap its allocation, and set `GOVERNANCE_DELAY` above the bridge's worst exit
   time. The availability invariant would then be false for that slice, and should be stated as
   false.
3. **Do not offer delta-neutral yield.** Ship T-bills (USTB) and staking only.

Whichever the client chooses, the contracts here do not change: they are the HyperEVM half of
options 1 and 2.

## 10. Contract size, the library split, and deploying it

**The problem.** As one contract, `HyperCoreDeltaNeutralVault` was 29,025 bytes of runtime code,
4,449 over EIP-170's 24,576. It could not be deployed on HyperEVM or any other EVM chain.
`forge test` does not enforce the limit, so the whole suite passed. Compiler settings were not
enough: it was still 24,684 bytes at `optimizer_runs = 1`, and 25,399 with via-IR.

**The split.** The HyperCore half moved into `DeltaNeutralStrategy`, an external library with
`public` functions, linked into the vault and reached by DELEGATECALL:

- **The library** reads the book, decides the next step, prices and sends orders, and estimates
  funding.
- **The vault** keeps everything else: the share token, deposits, `requestRedeem`, claims and
  `claim`, every role check, the reentrancy guard, the settle and rate-limit gates, the drawdown
  breaker and governance. It runs all of those first, then delegates.

**Why a linked library and not two contracts.** The size limit is a deployment constraint, not a
security boundary, so the split was chosen to add none.

| | Linked library (chosen) | Two contracts (shares / strategy) |
|---|---|---|
| HyperCore accounts | one: the library runs as the vault | two, or USDC shuttled between them |
| NAV | one book read | a sum across contracts |
| New interface to secure | none | a privileged vault↔strategy interface that moves USDC |
| Reentrancy guard | one | two, plus calls between them |
| Can the logic be swapped? | no: its address is in the vault's bytecode | depends on how the link is governed |
| What the logic can touch | one storage struct, `IDeltaNeutral.State` | its own storage and whatever the interface allows |

An internal library would not have helped: its code is inlined into the vault, so the size stays.

**Properties that still hold**, each checked by a test:

- **The keeper still only triggers bounded actions.** The keeper and anyone-may entry points are
  still the vault's, with the same modifiers and gates. The strategy code is unchanged in what it
  decides. All 18 vault tests pass without weakened assertions; only error and struct names now
  come from `IDeltaNeutral`, with the same selectors.
- **Nobody can drive the library directly.** Solc guards a library's state-changing functions so
  they revert unless DELEGATECALLed. A contract that does DELEGATECALL them acts on its own storage
  and its own HyperCore account. `test_TheStrategyLibraryCannotBeCalledDirectly` calls each entry
  point directly and gets the guard's empty revert. The same call to a view function succeeds, so
  the revert is the guard's and not a malformed call.
- **The strategy acts as the vault.** `test_TheStrategyActsAsTheVaultItself` checks that the
  strategy's events come from the vault's address, and that CoreWriter's `RawAction` records the
  vault as its user.
- **Governance and breakers are unchanged.** `setParams` still classifies a change as riskier
  through the same comparison, now `DeltaNeutralStrategy.riskier`, before `_authorizeChange`.
  There is no function to change the library.

**Sizes** at the repository's settings (solc 0.8.28, optimizer 10,000 runs), from
`forge build --sizes` and `HyperCoreContractSizeTest`:

| Contract | Runtime (bytes) | Headroom under 24,576 | Initcode (bytes) |
|---|---|---|---|
| `HyperCoreDeltaNeutralVault` | 19,976 | 4,600 | 23,972 (24,932 with constructor args) |
| `DeltaNeutralStrategy` | 17,144 | 7,432 | 17,196 |
| `KeeperGate` (L1) | 6,738 | 17,838 | 7,230 |
| `SuperstateUSTBAdapter` (L1) | 11,297 | 13,279 | 14,129 |

`HyperCoreContractSizeTest` runs inside `forge test` and fails if any of these goes over EIP-170 or
EIP-3860. For the vault it measures the runtime code as deployed, with immutables filled in, and
the creation code with real constructor arguments. CI's `forge build --sizes` step covers every
other contract.

**Deploying.** No transaction has been sent; these are the steps the tooling requires.

1. **Use big blocks.** HyperEVM's fast blocks carry 3M gas and its slow blocks 30M
   (`for-developers/hyperevm/dual-block-architecture`). Deploying ~17–20 KB of code needs more than
   3M, so the deployer must first send the HyperCore action
   `{"type": "evmUserModify", "usingBigBlocks": true}`. That needs an existing HyperCore account.
   Unset it afterwards so keeper transactions go back to fast blocks. A keeper call is a handful of
   precompile reads and at most two CoreWriter actions, well inside 3M.
2. **Deploy the library, then the vault linked against it.**
   - `forge script` deploys and links the library automatically.
   - With `forge create`:
     ```bash
     forge create contracts/hyperliquid/DeltaNeutralStrategy.sol:DeltaNeutralStrategy \
       --rpc-url $HYPEREVM_RPC --private-key $DEPLOYER_KEY
     forge create contracts/hyperliquid/HyperCoreDeltaNeutralVault.sol:HyperCoreDeltaNeutralVault \
       --libraries contracts/hyperliquid/DeltaNeutralStrategy.sol:DeltaNeutralStrategy:<library address> \
       --constructor-args ... --rpc-url $HYPEREVM_RPC --private-key $DEPLOYER_KEY
     ```
   - Verify the vault with the same `--libraries` value.
   - Anyone checking a deployment should confirm that the address linked into the vault's bytecode
     is the verified `DeltaNeutralStrategy`.
3. **Then the usual setup:** fund the vault's HyperCore gas with `fundCoreGas()`, check the
   parameters, and call `completeSetup()`.
