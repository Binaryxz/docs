# M1 (Rev. 3 §13.1), item by item

> **Update, 6 October 2026.** Task 1 below is done: the rail is on Sepolia from a fresh deployer `0xD249…73D1`, and its
> live verification shows 315 pass, 10 expected and 0 fail
> ([deployments.md](deployments.md#the-movva-rail-on-sepolia-6-october-2026)). The MOVVA token, the Movva and sMovva pools,
> the escrows, oracles and verifiers are therefore on Sepolia. It is not finalized (the deployer still holds the
> governors) and it runs without the divergence breaker. The rest of this document is as written on 25 September.
>
> **Update, 12 October 2026.** Task 5 below is settled: the client removed shielded transfers (Rev. 3 §5.3, Option A)
> from scope. Users deposit and withdraw only - no transfers between users, between sub-wallets, or shielded internal
> transfers. `ShieldedTransferRouter` and the wallet's transfer path (`packages/viewing-key/src/transfer.ts`) were
> deleted, and the two rows below say so.
>
> **Update, 15 October 2026.** Client decision D1 (14 October 2026) removed savings from M1: sMovva (`SavingsMovva`),
> its shielded pool, the savings relayer (`@mova/zap-relayer`), the shielded yield router and the Movva distribution
> keeper were deleted, and `MovvaReserve` no longer distributes (no `distribute`, no distribution fee). M1 is: deposit PIX
> -> mint MOVVA -> hold as shielded notes -> withdraw to PIX; the reserve's yield is Mova's, not a user product. Where
> this document says "Movva and sMovva pools" it describes what was built and deployed before D1; a rail deployed from the
> current code has the Movva pool only. The live 6 October rail still carries its sMovva contracts on Sepolia
> ([deployments.md](deployments.md)). The relayer row below is updated.

**Why this document.** The client reviewed the Sepolia deployment and reported that only the fork and a plain ERC-20
are delivered. The deployment they looked at is the **Phase 1 stack of 8 September**, which predates the Movva rail.
The rail — token, reserve, Movva and sMovva pools, escrows, oracles, verifiers — has never been broadcast to Sepolia,
because the deployer holds **0 ETH** and we have asked for funding in every report since 14 September. Our own record
says so in [deployments.md](deployments.md): *"Not on Sepolia yet."*

So the gap is mostly **deployment, not implementation**. Two M1 items are genuinely not built: sub-wallets, and Flux.
Written 25 September 2026 against commit `70933d0`.

## The comparison

| M1 item (Rev. 3 §13.1) | Built? | Proven by | On Sepolia? |
|---|---|---|---|
| Privacy Pools fork and deployment | Yes | `protocol/` byte-identical to upstream `c312dcd58f`; `npm run verify` | **Yes** (8 September) |
| MOVVA token | Yes | `contracts/movva/Movva.sol`: no owner, no settable minter, no pause, no upgrade | No — rehearsed only |
| Balances held as shielded MOVVA notes | Yes | The escrow deposits into the Movva pool under the user's precommitment; the wallet's balance is a set of notes (`packages/wallet/src/movva/ledger.ts`); proven in `movva-wallet-live.ts` (105 checks in EOA mode, 15 October 2026, real groth16 proofs) | No — the Movva pool is part of the rail, not of the 8 September stack |
| ERC-4337 smart accounts, passkey + MPC | Yes | Safe 2-of-2 and Kernel v3.1 with passkey plus server co-signer; FROST as the MPC option; `accounts-live.ts` 65 checks, `cosigner-live.ts` 113, ERC-7562 checked against Rundler | Partly: `SponsorPaymaster` is on Sepolia; the validators and SponsorGate are not |
| Sub-wallets with independent seed phrases | **No** | — | No |
| Relayer infrastructure | Yes | Privacy Pools relayer for exits; Alto bundler and paymaster for UserOperations. (`@mova/zap-relayer`, the savings relayer, was removed with savings, D1, 14 October 2026) | Not deployed |
| …on Flux | **No** — 6 specs exist, nothing deployed | `packages/ops/flux/*.json` | n/a |
| Audit viewing key | Yes | `packages/viewing-key` (33 source files): scoped, time-boxed, revocable, read-only by derivation; an auditor reconstructs the statement from chain data in `movva-wallet-live.ts` steps 14-16 and `audit-demo.ts` | `AuditGrantRegistry` **is** on Sepolia (8 September); the rest is client-side by design |
| Shielded transfer decision (§5.3) | **Removed from scope** by the client on 12 October 2026 | `ShieldedTransferRouter` and the wallet's transfer path were deleted; users deposit and withdraw only | n/a |

## Correcting one point precisely

"MOVVA token — but as a standard ERC-20, not as shielded notes." Rev. 3 §5.1 itself specifies MOVVA as *"an immutable
ERC-20 and the asset held in shielded notes"*. Both are true at once: the token is an ordinary ERC-20 contract, and user
balances live as notes inside the Movva pool. The app never shows a public MOVVA balance except through the emergency
exit that Rev. 3 §5.2 step 7 requires. What the client is looking at on Sepolia is a pool that has no Movva pool beside
it yet, because the rail was never deployed.

## What is genuinely left for M1

| # | Task | Depends on | Rough effort |
|---|---|---|---|
| 1 | **Deploy the rail to Sepolia** — token, reserve, Movva and sMovva pools, escrows, oracles, verifiers | Sepolia ETH; the minting decision (A1) | 1 day; the script is written and rehearsed (93 transactions, 344 checks, 0 failures) |
| 2 | **Deploy the account stack** — our validators, SponsorGate, a funded paymaster | Sepolia ETH; paymaster stake | 1 day |
| 3 | **Sub-wallets with independent BIP-39 seeds** — per sub-wallet shielded identity and account, recovery by rescanning, backup flow, app screens, isolation tests (T-10) | The V1/V2 decision; whether they are multi-asset | 10-15 working days |
| 4 | **Flux deployment** of the six replicable services | The client's Flux account and collateral | 3-5 days once the account exists |
| 5 | ~~Confirm §5.3~~ **Settled 12 October 2026** | The client removed shielded transfers from scope; the router and the wallet's transfer path were deleted | none |
| 6 | **The pending decisions** that gate a permanent deployment: who mints MOVVA, what is renounced, the ASP shape, fee governance | Client | none |

## Upgrade or replace?

**Replace.** The 8 September stack predates the rail, its `OWNER_ROLE` sits on a key the client has confirmed is lost,
and Rev. 3's immutability rule forbids upgrading anything anyway — a parameter change is a new deployment. The rail
deploys a fresh Privacy Pools stack of its own (the rehearsal does exactly this), and the old addresses should be
documented as abandoned and monitored, which is what the client's own proposal 6 asks for.

## What we need to proceed, unchanged since 14 September

1. **Sepolia ETH** for `0x4C0A…d214`, which holds none. Without it nothing can be deployed, rehearsals notwithstanding.
2. An RPC without the `eth_getLogs` cap, for the full inventory against real Sepolia.
3. A Pyth Hermes credential, so our keeper can refresh the BRL price rather than waiting it out.
4. The decisions listed in row 6.
