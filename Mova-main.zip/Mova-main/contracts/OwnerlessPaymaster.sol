// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

/// @dev The EntryPoint v0.7 functions this contract calls. It calls nothing else: in particular it
///      has no path to `withdrawTo`, `unlockStake` or `withdrawStake`, which the EntryPoint lets
///      only the paymaster itself call for its own deposit and stake.
interface IEntryPointFunding {
    function depositTo(address account) external payable;
    function addStake(uint32 unstakeDelaySec) external payable;
    function balanceOf(address account) external view returns (uint256);
}

/// @dev EntryPoint v0.7's packed UserOperation, field for field.
struct PackedUserOperation {
    address sender;
    uint256 nonce;
    bytes initCode;
    bytes callData;
    bytes32 accountGasLimits;
    uint256 preVerificationGas;
    bytes32 gasFees;
    bytes paymasterAndData;
    bytes signature;
}

/**
 * @title OwnerlessPaymaster
 * @notice Pays gas for smart accounts created by a fixed set of account factories, under fixed
 *         per-account and global spending limits, with no owner, no signer and no way to take the
 *         money back out.
 *
 * The client's decision (B1, 14 October 2026): "Ownerless paymaster. It sponsors only accounts that
 * qualify by an on-chain rule, with no signing key: accounts created by your account factory, under
 * per-account rate limits. Anyone can top up its deposit. Its stake is locked permanently and can
 * never be withdrawn. No one can pause, censor, or change the policy." docs/ownerless-paymaster.md
 * has the design at length; this header states what the code guarantees.
 *
 * ## No one controls it
 *
 * There is no owner, admin, signer, pause, setter, upgrade path, `delegatecall` or `selfdestruct`.
 * Every policy parameter is an immutable set in the constructor. The only state is the usage
 * counters below, and only the EntryPoint can change them. The only external calls are to the
 * immutable EntryPoint: `depositTo` and `addStake`, which add money, never remove it.
 *
 *  - **Deposit.** Anyone may top it up: `deposit()`, a plain transfer (`receive`), or
 *    `EntryPoint.depositTo(this)` directly. It leaves only as gas for sponsored operations.
 *  - **Stake.** Anyone may add to it with `addStake()`, always with the immutable
 *    `UNSTAKE_DELAY_SEC`. The EntryPoint lets only the staked address itself call `unlockStake`,
 *    `withdrawStake` and `withdrawTo` for its own funds, and this contract has no code that calls
 *    them, so the stake is locked for good and the deposit can never be withdrawn.
 *
 * ## Who qualifies: provenance by CREATE2
 *
 * An account qualifies when `userOp.sender` is the CREATE2 address of one of the (at most two)
 * immutable factories with that factory's immutable proxy init code hash, for a salt the operation
 * supplies:
 *
 *     sender == address(keccak256(0xff ++ FACTORY_i ++ salt ++ PROXY_INIT_CODE_HASH_i)[12:])
 *
 * As deployed for this wallet the two are Safe 1.4.1's SafeProxyFactory, with the hash of its
 * `proxyCreationCode() ++ uint256(Safe 1.4.1 singleton)`, and Kernel v3.1's KernelFactory, with the
 * hash of the Solady ERC-1967 proxy over the Kernel v3.1 implementation. The salt is the one the
 * factory itself computes (Safe: keccak256(keccak256(initializer) ++ saltNonce); Kernel:
 * keccak256(initData ++ salt)); a client already knows it, having predicted the address from it.
 * No key and no registry: the address IS the proof, because nothing but that factory can deploy
 * code at that address with that init code (short of a 160-bit address collision).
 *
 * One check serves both cases. In an operation that deploys the account (initCode), the EntryPoint
 * has already run the factory and checked that it produced `sender` before it asks the paymaster,
 * so the address check proves the factory made it, whatever the initCode named (a meta factory that
 * calls ours is fine; any other factory cannot produce the address). For an account deployed
 * earlier, by an operation or by a plain transaction to the factory (how a Kernel account is
 * created), the check is the same. Sub-wallet accounts, which have no passkey, are created by the
 * same factories and qualify by the same rule: the rule never looks at who owns the account.
 *
 * Provenance is a policy filter, NOT a Sybil defence. Both factories are public: anyone can create
 * any number of qualifying accounts for free, with any owners. It pins what kind of contract is
 * sponsored (a proxy of a pinned implementation); it does not tell a user from an attacker.
 *
 * ## Limits, and the one that bounds the drain
 *
 * Time is cut into fixed windows of `WINDOW` seconds; window k is [k * WINDOW, (k + 1) * WINDOW).
 *  - per operation: at most `MAX_COST_PER_OP` wei (the EntryPoint's `maxCost`);
 *  - per account per window: at most `MAX_OPS_PER_ACCOUNT` operations and `MAX_COST_PER_ACCOUNT` wei;
 *  - for everyone together per window: at most `MAX_COST_GLOBAL` wei.
 *
 * **The global cap is the only bound on how fast the deposit can be drained.** An ownerless rule
 * cannot tell a real user from one person running a thousand accounts through the public factory,
 * so per-account limits only spread the budget; they do not cap it. In any n consecutive windows the
 * paymaster pays at most (n + 2) x `MAX_COST_GLOBAL` (n + 1 without a grace period; see below). The
 * price is availability: an attacker who spends the whole global budget early in a window denies
 * sponsorship to everyone until the next one, at no cost to themselves, and nobody can stop it
 * because nobody controls the contract. A bundler that is the attacker also keeps what it is paid
 * (priority fees, preVerificationGas and the unused-gas penalty all go to the bundler), so the
 * budget can be turned into the attacker's ETH at up to that rate. Size `MAX_COST_GLOBAL` as the
 * loss per window you accept, and the deposit as how many windows of it you will fund.
 *
 * ## Where gas is charged
 *
 * Validation RESERVES `maxCost` (the most the EntryPoint can take for the operation) against the
 * account's and the global counters, writing them; `postOp` refunds the difference between that and
 * an upper bound of what the EntryPoint actually takes. Charging in validation is what makes the caps
 * exact: the EntryPoint validates every operation of a bundle before executing any, so a cap checked
 * in validation and settled only in postOp would let a bundle of N Sybil accounts each pass against
 * the same pre-bundle total and overshoot it N times. Here the second operation's validation sees the
 * first one's reservation. If postOp does not run or reverts (the EntryPoint then undoes postOp but
 * not validation), the full `maxCost` stays charged, which errs on the safe side.
 *
 * The refund is bounded so the recorded charge is never below the deposit's real debit. EntryPoint
 * v0.7 hands postOp a cost that excludes postOp's own gas and the 10% penalty on unused execution
 * gas it adds afterwards, so postOp charges `actualGasCost` plus, at the operation's gas price,
 * paymasterPostOpGasLimit + POST_OP_OVERHEAD_GAS + (callGasLimit + paymasterPostOpGasLimit) / 10,
 * capped at `maxCost` (the debit can never exceed `maxCost`: it is the prefund).
 *
 * ## ERC-7562 (bundler validation rules)
 *
 *  - Validation reads no block data [OP-011 bans TIMESTAMP for every entity]. The window is chosen by
 *    the client in paymasterData and bound to the clock by `validationData`: valid after the window's
 *    start and until its end plus `GRACE`. The EntryPoint enforces that range (AA32), so an operation
 *    counted in window k can only execute in window k, or within `GRACE` after it; a client cannot
 *    spend now against a future window. If a later window has already been opened, the operation is
 *    counted in that later one (the conservative choice), so counters only move forward.
 *  - It writes its own storage: the global counter [STO-031] and a mapping keyed by the sender, and
 *    it returns a context for postOp [EREP-050]. ERC-7562 allows both only to a STAKED paymaster, so
 *    this one must be staked (`addStake`) with at least a bundler's minimum stake; its delay is at
 *    least a day [MIN_UNSTAKE_DELAY]. It calls no other contract during validation.
 *  - Shared state has a cost a bundler sees: when the global budget runs out, operations already in
 *    a mempool fail validation on-chain, and a bundler may throttle this paymaster's reputation for
 *    it. That is the global cap working, and it ends with the window.
 *
 * ## paymasterAndData
 *
 *     paymaster (20) ++ paymasterVerificationGasLimit (16) ++ paymasterPostOpGasLimit (16)
 *       ++ factory index (1) ++ CREATE2 salt (32) ++ window (6, uint48)
 *
 * The window is floor(now / WINDOW) when the operation is signed (`currentWindow()`).
 */
contract OwnerlessPaymaster {
    /// @notice ERC-7562's MIN_UNSTAKE_DELAY: bundlers do not count a stake with a shorter delay.
    uint32 public constant MIN_UNSTAKE_DELAY = 1 days;
    /// @notice Least paymasterPostOpGasLimit accepted, so the refund in postOp can run.
    uint256 public constant MIN_POST_OP_GAS = 25_000;
    /// @notice Gas the EntryPoint spends around the postOp call, beyond postOp's own, that it bills
    ///         after postOp has seen the cost. About 1,300 measured against EntryPoint v0.7; 10,000
    ///         keeps a margin (contracts/test/OwnerlessPaymaster.t.sol checks debit <= charge).
    uint256 public constant POST_OP_OVERHEAD_GAS = 10_000;
    /// @dev Where paymasterData starts in paymasterAndData, and its length.
    uint256 internal constant PAYMASTER_DATA_OFFSET = 52;
    uint256 internal constant PAYMASTER_DATA_LENGTH = 39;

    /// @notice EntryPoint v0.7. Immutable: a swappable entry point would be a swappable caller.
    IEntryPointFunding public immutable ENTRYPOINT;

    /// @notice The factories whose accounts qualify (index 0 and 1), and the init code hash of the
    ///         proxy each one deploys. A zero factory disables that index.
    address public immutable FACTORY_0;
    bytes32 public immutable PROXY_INIT_CODE_HASH_0;
    address public immutable FACTORY_1;
    bytes32 public immutable PROXY_INIT_CODE_HASH_1;

    /// @notice Length of a budget window, in seconds.
    uint256 public immutable WINDOW;
    /// @notice How long after its window ends an operation stays valid (< WINDOW).
    uint256 public immutable GRACE;
    /// @notice Largest `maxCost` sponsored for one operation, in wei.
    uint256 public immutable MAX_COST_PER_OP;
    /// @notice Operations per account per window.
    uint256 public immutable MAX_OPS_PER_ACCOUNT;
    /// @notice Gas cost per account per window, in wei.
    uint256 public immutable MAX_COST_PER_ACCOUNT;
    /// @notice Gas cost for all accounts together per window, in wei. The bound on the drain rate.
    uint256 public immutable MAX_COST_GLOBAL;
    /// @notice The unstake delay every `addStake` uses. Never used to unstake: nothing can.
    uint32 public immutable UNSTAKE_DELAY_SEC;

    /// @dev One slot. `window` is the latest window the account was charged in.
    struct AccountUsage {
        uint48 window;
        uint32 ops;
        uint128 spent;
    }

    /// @dev One slot. `window` is the latest window anyone was charged in.
    struct GlobalUsage {
        uint48 window;
        uint128 spent;
    }

    /// @notice Each account's usage in the latest window it was charged in (which may have ended).
    mapping(address account => AccountUsage usage) public usageOf;
    /// @notice Everyone's usage in the latest window anyone was charged in (which may have ended).
    GlobalUsage public globalUsage;

    /// @notice A sponsored operation settled: `charged` wei counted against the account's window and
    ///         the global window (the latter is never earlier than the former).
    event Sponsored(address indexed account, uint48 accountWindow, uint48 globalWindow, uint256 charged);

    error NotEntryPoint();
    error BadConfig();
    error BadPaymasterData(uint256 length);
    error NotFromFactory(address sender);
    error PostOpGasTooLow(uint256 given, uint256 min);
    error WindowOutOfRange(uint256 window);
    error OpCostAboveLimit(uint256 maxCost, uint256 limit);
    error AccountOpsExhausted(address account, uint48 window);
    error AccountBudgetExhausted(address account, uint48 window, uint256 spent);
    error GlobalBudgetExhausted(uint48 window, uint256 spent);

    /// @notice Everything the constructor fixes for good.
    struct Policy {
        address factory0;
        bytes32 proxyInitCodeHash0;
        address factory1;
        bytes32 proxyInitCodeHash1;
        uint256 window;
        uint256 grace;
        uint256 maxCostPerOp;
        uint256 maxOpsPerAccount;
        uint256 maxCostPerAccount;
        uint256 maxCostGlobal;
        uint32 unstakeDelaySec;
    }

    constructor(IEntryPointFunding entryPoint, Policy memory p) {
        if (address(entryPoint) == address(0) || p.factory0 == address(0)) revert BadConfig();
        if (p.proxyInitCodeHash0 == bytes32(0)) revert BadConfig();
        if ((p.factory1 == address(0)) != (p.proxyInitCodeHash1 == bytes32(0))) revert BadConfig();
        if (p.factory1 == p.factory0 && p.proxyInitCodeHash1 == p.proxyInitCodeHash0) revert BadConfig();
        // A window of at least a minute, at most a year; the grace strictly shorter than a window,
        // so the "(n + 2) windows" bound in the header holds.
        if (p.window < 60 || p.window > 365 days || p.grace >= p.window) revert BadConfig();
        if (p.maxCostPerOp == 0 || p.maxCostPerOp > p.maxCostPerAccount) revert BadConfig();
        if (p.maxCostPerAccount > p.maxCostGlobal || p.maxCostGlobal > type(uint128).max) revert BadConfig();
        if (p.maxOpsPerAccount == 0 || p.maxOpsPerAccount > type(uint32).max) revert BadConfig();
        if (p.unstakeDelaySec < MIN_UNSTAKE_DELAY) revert BadConfig();

        ENTRYPOINT = entryPoint;
        FACTORY_0 = p.factory0;
        PROXY_INIT_CODE_HASH_0 = p.proxyInitCodeHash0;
        FACTORY_1 = p.factory1;
        PROXY_INIT_CODE_HASH_1 = p.proxyInitCodeHash1;
        WINDOW = p.window;
        GRACE = p.grace;
        MAX_COST_PER_OP = p.maxCostPerOp;
        MAX_OPS_PER_ACCOUNT = p.maxOpsPerAccount;
        MAX_COST_PER_ACCOUNT = p.maxCostPerAccount;
        MAX_COST_GLOBAL = p.maxCostGlobal;
        UNSTAKE_DELAY_SEC = p.unstakeDelaySec;
    }

    modifier onlyEntryPoint() {
        if (msg.sender != address(ENTRYPOINT)) revert NotEntryPoint();
        _;
    }

    /*//////////////////////////////////////////////////////////////
                               ERC-4337
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Called by the EntryPoint during validation: check provenance, reserve `maxCost`.
     * @dev Reads no block data and calls nothing (see the header). Every refusal reverts, which
     *      undoes the reservation; an accepted operation's reservation stays until its postOp.
     * @return context abi.encode(sender, account window, global window, maxCost, overhead gas)
     * @return validationData no signature failure; valid from the window's start until its end
     *         plus GRACE
     */
    function validatePaymasterUserOp(
        PackedUserOperation calldata userOp,
        bytes32,
        uint256 maxCost
    ) external onlyEntryPoint returns (bytes memory context, uint256 validationData) {
        (address sender, uint256 postOpGas, uint48 window) = _check(userOp, maxCost);
        validationData = _timeRange(window);
        (uint48 accountWindow, uint48 globalWindow) = _reserve(sender, window, maxCost);
        uint256 callGas = uint128(uint256(userOp.accountGasLimits));
        uint256 overheadGas = postOpGas + POST_OP_OVERHEAD_GAS + (callGas + postOpGas) / 10;
        context = abi.encode(sender, accountWindow, globalWindow, maxCost, overheadGas);
    }

    /// @dev Parse paymasterData and apply the checks that need no state: provenance, gas, cost.
    function _check(PackedUserOperation calldata userOp, uint256 maxCost)
        internal
        view
        returns (address sender, uint256 postOpGas, uint48 window)
    {
        bytes calldata pnd = userOp.paymasterAndData;
        if (pnd.length != PAYMASTER_DATA_OFFSET + PAYMASTER_DATA_LENGTH) revert BadPaymasterData(pnd.length);
        sender = userOp.sender;
        if (!_createdByFactory(sender, uint8(pnd[52]), bytes32(pnd[53:85]))) revert NotFromFactory(sender);
        postOpGas = uint128(bytes16(pnd[36:52]));
        if (postOpGas < MIN_POST_OP_GAS) revert PostOpGasTooLow(postOpGas, MIN_POST_OP_GAS);
        if (maxCost > MAX_COST_PER_OP) revert OpCostAboveLimit(maxCost, MAX_COST_PER_OP);
        window = uint48(bytes6(pnd[85:91]));
    }

    /// @dev validationData for `window`: valid from its start until its end plus GRACE, no signature failure.
    function _timeRange(uint48 window) internal view returns (uint256) {
        uint256 validAfter = uint256(window) * WINDOW;
        uint256 validUntil = validAfter + WINDOW - 1 + GRACE;
        if (validUntil > type(uint48).max) revert WindowOutOfRange(window);
        return (validUntil << 160) | (validAfter << 208);
    }

    /**
     * @dev Check the account's and the global limits for `maxCost` in `window` (or in the later window
     *      already opened, if there is one) and record the reservation. Returns the windows charged.
     */
    function _reserve(address sender, uint48 window, uint256 maxCost)
        internal
        returns (uint48 accountWindow, uint48 globalWindow)
    {
        AccountUsage memory a = usageOf[sender];
        if (window > a.window) a = AccountUsage({window: window, ops: 0, spent: 0});
        if (a.ops >= MAX_OPS_PER_ACCOUNT) revert AccountOpsExhausted(sender, a.window);
        // a.spent <= MAX_COST_PER_ACCOUNT always holds, so the subtraction cannot underflow.
        if (maxCost > MAX_COST_PER_ACCOUNT - a.spent) revert AccountBudgetExhausted(sender, a.window, a.spent);

        GlobalUsage memory g = globalUsage;
        if (window > g.window) g = GlobalUsage({window: window, spent: 0});
        if (maxCost > MAX_COST_GLOBAL - g.spent) revert GlobalBudgetExhausted(g.window, g.spent);

        // maxCost <= MAX_COST_PER_OP <= MAX_COST_PER_ACCOUNT <= MAX_COST_GLOBAL < 2^128, and each sum was
        // just checked against its cap, so these narrowings are exact.
        a.ops += 1;
        a.spent += uint128(maxCost);
        g.spent += uint128(maxCost);
        usageOf[sender] = a;
        globalUsage = g;
        return (a.window, g.window);
    }

    /**
     * @notice Called by the EntryPoint after execution: refund the reservation down to an upper bound
     *         of the real cost.
     * @dev Never reverts: no require, no external call, and no arithmetic that can overflow. The
     *      refund goes back only into the window the reservation was made in; if a later window has
     *      opened since (another operation in the same bundle), the old one no longer matters and the
     *      new one must not be credited with spend it never had.
     */
    function postOp(
        uint8,
        bytes calldata context,
        uint256 actualGasCost,
        uint256 actualUserOpFeePerGas
    ) external onlyEntryPoint {
        (address account, uint48 accountWindow, uint48 globalWindow, uint256 reserved, uint256 overheadGas) =
            abi.decode(context, (address, uint48, uint48, uint256, uint256));

        uint256 charge = reserved;
        if (actualGasCost < reserved) {
            uint256 room = reserved - actualGasCost;
            if (actualUserOpFeePerGas == 0) {
                charge = actualGasCost;
            } else if (overheadGas < room / actualUserOpFeePerGas) {
                // overheadGas * fee < room <= reserved, so this neither overflows nor exceeds reserved.
                charge = actualGasCost + overheadGas * actualUserOpFeePerGas;
            }
        }
        uint256 refund = reserved - charge;

        if (refund != 0) {
            AccountUsage storage a = usageOf[account];
            if (a.window == accountWindow) a.spent = uint128(_saturatingSub(a.spent, refund));
            GlobalUsage storage g = globalUsage;
            if (g.window == globalWindow) g.spent = uint128(_saturatingSub(g.spent, refund));
        }
        emit Sponsored(account, accountWindow, globalWindow, charge);
    }

    /*//////////////////////////////////////////////////////////////
                         FUNDING (ADD ONLY)
    //////////////////////////////////////////////////////////////*/

    /// @notice Add to the gas deposit. Anyone may; nobody can withdraw it.
    function deposit() public payable {
        ENTRYPOINT.depositTo{value: msg.value}(address(this));
    }

    /// @notice Add to the stake, always with UNSTAKE_DELAY_SEC. Anyone may; nobody can unstake.
    function addStake() external payable {
        ENTRYPOINT.addStake{value: msg.value}(UNSTAKE_DELAY_SEC);
    }

    /// @notice A plain transfer tops up the deposit too.
    receive() external payable {
        deposit();
    }

    /*//////////////////////////////////////////////////////////////
                         VIEWS (FOR CLIENTS)
    //////////////////////////////////////////////////////////////*/

    /// @notice The gas deposit at the EntryPoint.
    function getDeposit() external view returns (uint256) {
        return ENTRYPOINT.balanceOf(address(this));
    }

    /// @notice The address factory `index` deploys its proxy at for `salt`; zero for an unused index.
    function accountAddress(uint8 index, bytes32 salt) public view returns (address) {
        (address factory, bytes32 initCodeHash) = _root(index);
        if (factory == address(0)) return address(0);
        return address(uint160(uint256(keccak256(abi.encodePacked(bytes1(0xff), factory, salt, initCodeHash)))));
    }

    /// @notice The window an operation signed now should name. Off-chain use: it reads the clock.
    function currentWindow() public view returns (uint48) {
        return uint48(block.timestamp / WINDOW);
    }

    /**
     * @notice What `account` and everyone may still be sponsored for in the current window.
     *         Off-chain use: it reads the clock.
     */
    function remaining(address account)
        external
        view
        returns (uint256 opsLeft, uint256 accountCostLeft, uint256 globalCostLeft)
    {
        uint48 now_ = currentWindow();
        AccountUsage memory a = usageOf[account];
        if (a.window < now_) a = AccountUsage({window: now_, ops: 0, spent: 0});
        GlobalUsage memory g = globalUsage;
        if (g.window < now_) g = GlobalUsage({window: now_, spent: 0});
        opsLeft = MAX_OPS_PER_ACCOUNT - a.ops;
        accountCostLeft = MAX_COST_PER_ACCOUNT - a.spent;
        globalCostLeft = MAX_COST_GLOBAL - g.spent;
    }

    /*//////////////////////////////////////////////////////////////
                               INTERNAL
    //////////////////////////////////////////////////////////////*/

    function _root(uint8 index) internal view returns (address factory, bytes32 initCodeHash) {
        if (index == 0) return (FACTORY_0, PROXY_INIT_CODE_HASH_0);
        if (index == 1) return (FACTORY_1, PROXY_INIT_CODE_HASH_1);
        return (address(0), bytes32(0));
    }

    function _createdByFactory(address sender, uint8 index, bytes32 salt) internal view returns (bool) {
        address predicted = accountAddress(index, salt);
        return predicted != address(0) && predicted == sender;
    }

    function _saturatingSub(uint256 a, uint256 b) internal pure returns (uint256) {
        return a > b ? a - b : 0;
    }
}
