// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/**
 * @title DelayedGovernance
 * @notice One governor, two speeds: changes that add risk wait out a public delay, changes
 *         that remove risk take effect at once.
 *
 * ## Why this exists
 *
 * Before this, a single governor key could steal from every contract that holds value in
 * this repo, in one block, with no warning to anyone:
 *
 *  - on an escrow: allow itself as an arbitrator, lock an order (or claim a sale) as a
 *    counterparty, dispute it, and sign its own RELEASE ruling;
 *  - on a verifier: add itself as an attestor, set the threshold to one, and sign payments
 *    that never happened;
 *  - on the yield vault: list an adapter it wrote, make itself keeper, and allocate.
 *
 * Several comments said these were impossible ("cannot drain an offer"). They were true of
 * each function and false of the combination. A timelock does not make a malicious governor
 * honest; it makes one visible. Every risk-increasing change is scheduled on-chain with its
 * exact calldata, and cannot run until `GOVERNANCE_DELAY` has passed - long enough for LPs
 * to close offers, sellers to cancel sales, and holders to redeem.
 *
 * ## Which changes wait, and which do not
 *
 * The rule each contract applies is: would this change let someone move value, or accept
 * a claim, that they could not before? If so it waits. Adding an arbitrator, verifier,
 * attestor, bank endpoint, adapter or escrow; lowering a threshold; listing an asset or
 * changing its oracle; changing the keeper; raising a cap, a credit limit or a tier; opening
 * a network phase.
 *
 * Revoking, suspending, pausing, delisting and lowering do NOT wait. Incident response
 * must be as fast as the governor can sign, and a delay on the brakes protects no one. Each
 * contract classifies from current state inside the setter itself, so the same function can
 * be instant when it reduces risk and delayed when it adds it, and the classification is
 * re-evaluated when a scheduled change finally executes.
 *
 * ## Setup
 *
 * A freshly deployed contract has to be wired before anyone can use it, and a deploy
 * script cannot wait 48 hours between transactions. So a contract starts in SETUP: every
 * change is instant, and - the part that makes this safe - the contract refuses all user
 * business until `completeSetup()` is called, which is irreversible. Instant power only ever
 * exists while the contract holds nothing and nobody depends on it. Check
 * `setupComplete()` before trusting a deployment.
 *
 * ## Mechanics
 *
 * `schedule(call)` records `keccak256(call)` and emits the full calldata with the time it
 * becomes executable. `execute(call)` runs it on this contract, only between `readyAt` and
 * `readyAt + EXECUTION_WINDOW`; a stale approval expires rather than lingering as a loaded
 * gun. `cancel(call)` is instant. Only selectors a contract declares in `_isDelayable` can
 * be scheduled at all, so the self-call cannot be aimed at user-facing functions.
 *
 * `transferGovernor` is instant: rotating a compromised key must not wait, and the new
 * governor inherits the same delays rather than escaping them.
 */
abstract contract DelayedGovernance {
    /// @notice No deployment may use a shorter delay than this.
    uint256 public constant MIN_GOVERNANCE_DELAY = 24 hours;
    /// @notice Nor a longer one: a delay nobody can wait out bricks incident recovery.
    uint256 public constant MAX_GOVERNANCE_DELAY = 30 days;
    /// @notice A scheduled change must be executed within this long after it becomes ready.
    uint256 public constant EXECUTION_WINDOW = 14 days;

    /// @notice Minimum wait between scheduling a risk-increasing change and executing it.
    uint256 public immutable GOVERNANCE_DELAY;

    address public governor;
    /// @notice False while the contract is being wired; see "Setup" above.
    bool public setupComplete;
    /// @notice When each scheduled change becomes executable, by keccak256 of its calldata.
    mapping(bytes32 => uint256) public readyAt;

    /// @dev Set only for the duration of `execute`'s self-call.
    bool private _executing;

    event GovernorTransferred(address indexed from, address indexed to);
    event SetupCompleted(uint256 governanceDelay);
    event ChangeScheduled(
        bytes32 indexed id, bytes4 indexed selector, bytes call, uint256 readyAt, uint256 expiresAt
    );
    event ChangeCancelled(bytes32 indexed id);
    event ChangeExecuted(bytes32 indexed id, bytes4 indexed selector);

    error NotGovernor();
    error ZeroAddress();
    error BadGovernanceDelay(uint256 delay);
    error SetupIncomplete();
    error SetupAlreadyComplete();
    error ChangeMustBeScheduled(bytes4 selector);
    error NotDelayable(bytes4 selector);
    error AlreadyScheduled(bytes32 id);
    error NotScheduled(bytes32 id);
    error NotReadyYet(bytes32 id, uint256 readyAt);
    error ChangeExpired(bytes32 id);

    modifier onlyGovernor() {
        if (msg.sender != governor) revert NotGovernor();
        _;
    }

    constructor(address governor_, uint256 governanceDelay) {
        if (governor_ == address(0)) revert ZeroAddress();
        if (governanceDelay < MIN_GOVERNANCE_DELAY || governanceDelay > MAX_GOVERNANCE_DELAY) {
            revert BadGovernanceDelay(governanceDelay);
        }
        governor = governor_;
        GOVERNANCE_DELAY = governanceDelay;
    }

    /*//////////////////////////////////////////////////////////////
                                LIFECYCLE
    //////////////////////////////////////////////////////////////*/

    /// @notice End setup. From here on, every risk-increasing change waits out the delay.
    function completeSetup() external onlyGovernor {
        if (setupComplete) revert SetupAlreadyComplete();
        setupComplete = true;
        emit SetupCompleted(GOVERNANCE_DELAY);
    }

    function transferGovernor(address to) external onlyGovernor {
        if (to == address(0)) revert ZeroAddress();
        emit GovernorTransferred(governor, to);
        governor = to;
    }

    /*//////////////////////////////////////////////////////////////
                         SCHEDULE / EXECUTE / CANCEL
    //////////////////////////////////////////////////////////////*/

    /// @param call ABI-encoded call to one of this contract's delayable governance functions.
    function schedule(bytes calldata call) external onlyGovernor returns (bytes32 id) {
        bytes4 selector = _selectorOf(call);
        id = keccak256(call);
        if (readyAt[id] != 0) revert AlreadyScheduled(id);
        uint256 ready = block.timestamp + GOVERNANCE_DELAY;
        readyAt[id] = ready;
        emit ChangeScheduled(id, selector, call, ready, ready + EXECUTION_WINDOW);
    }

    function cancel(bytes calldata call) external onlyGovernor {
        bytes32 id = keccak256(call);
        if (readyAt[id] == 0) revert NotScheduled(id);
        delete readyAt[id];
        emit ChangeCancelled(id);
    }

    /**
     * @notice Run a scheduled change once its delay has passed.
     * @dev Governor-only, so a scheduled change is an option the governor may decline, not
     *      an obligation anyone can trigger. The call runs as this contract calling itself;
     *      the setter sees `msg.sender == address(this)` during `_executing`, which is what
     *      `_authorizeChange` accepts in place of the delay check.
     */
    function execute(bytes calldata call) external onlyGovernor returns (bytes memory result) {
        bytes4 selector = _selectorOf(call);
        bytes32 id = keccak256(call);
        uint256 ready = readyAt[id];
        if (ready == 0) revert NotScheduled(id);
        if (block.timestamp < ready) revert NotReadyYet(id, ready);
        if (block.timestamp > ready + EXECUTION_WINDOW) revert ChangeExpired(id);
        delete readyAt[id];

        _executing = true;
        bool ok;
        (ok, result) = address(this).call(call);
        _executing = false;
        if (!ok) {
            // Bubble the setter's own error, so a failed execution says why.
            assembly {
                revert(add(result, 32), mload(result))
            }
        }
        emit ChangeExecuted(id, selector);
    }

    /*//////////////////////////////////////////////////////////////
                             FOR INHERITORS
    //////////////////////////////////////////////////////////////*/

    /**
     * @dev Call first in every governance setter, having classified the change from
     *      current state. Risk-reducing changes need only the governor. Risk-increasing
     *      ones need the governor during setup, or must arrive through `execute`.
     */
    function _authorizeChange(bool riskIncreasing) internal view {
        if (_executing && msg.sender == address(this)) return;
        if (msg.sender != governor) revert NotGovernor();
        if (riskIncreasing && setupComplete) revert ChangeMustBeScheduled(msg.sig);
    }

    /// @dev Call at the top of every user-facing entry point that takes on value or trust.
    function _requireSetupComplete() internal view {
        if (!setupComplete) revert SetupIncomplete();
    }

    /// @dev The governance functions `schedule` may target. Nothing else can be self-called.
    function _isDelayable(bytes4 selector) internal pure virtual returns (bool);

    function _selectorOf(bytes calldata call) private pure returns (bytes4 selector) {
        if (call.length < 4) revert NotDelayable(bytes4(0));
        selector = bytes4(call[:4]);
        if (!_isDelayable(selector)) revert NotDelayable(selector);
    }
}
