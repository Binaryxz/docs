// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @dev The one Entrypoint function this contract calls. It is `onlyRole(ASP_POSTMAN)` there.
interface IEntrypointRoots {
    function updateRoot(uint256 root, string memory ipfsCID) external returns (uint256 index);
}

/**
 * @title AspRootQuorum
 * @notice The Entrypoint's ASP postman, as an immutable quorum of independent ASPs: an
 *         association-set root reaches the Entrypoint only when THRESHOLD of the fixed ASPs
 *         have voted for exactly that root and IPFS CID.
 *
 * ## Why this exists
 *
 * A private withdrawal must prove the Entrypoint's latest root, and only the holder of
 * ASP_POSTMAN can post one. OWNER_ROLE is that role's only admin, so once OWNER_ROLE is
 * renounced the postman can never be replaced. Held by one key, that is a single point of
 * failure: lose it and private withdrawals stop; leak it and whoever holds it decides which
 * deposits are approved. (Funds are never trapped either way: ragequit needs no root, and
 * `FiatEscrow.rescueShielded` gives escrow-delivered notes the same exit.)
 *
 * Granting ASP_POSTMAN to this contract instead, before OWNER_ROLE is renounced, spreads
 * that role over several independent ASPs. It lives outside the audited Privacy Pools code
 * and changes none of it: to the Entrypoint it is simply the postman.
 *
 * ## What it guarantees, and what it gives up
 *
 *  - No root is posted unless THRESHOLD distinct ASPs voted for it in the current round.
 *    THRESHOLD is a strict majority, so a minority of ASPs can never post a root the others
 *    did not approve, and two conflicting roots can never both reach a quorum.
 *  - It survives the loss or compromise of fewer than THRESHOLD ASPs for safety, and of up
 *    to ASP_COUNT - THRESHOLD ASPs for liveness.
 *  - It has no owner, no setter and no upgrade path. The ASP set and THRESHOLD are fixed at
 *    deployment. Nobody can ever add, remove or replace an ASP - that is the price of an
 *    immutable periphery. If so many ASPs are lost that a quorum can never form again,
 *    private withdrawals stop for good and users leave by ragequit.
 *
 * ## Rounds
 *
 * Votes are counted per (round, root, CID). The round advances each time a root is posted,
 * so votes cast for an earlier round can never complete later. An ASP may vote for more than
 * one proposal in a round - to correct a mistaken root, or to join the majority after a split -
 * because one vote per round would let a three-way split stall the quorum forever. It cannot
 * vote twice for the same proposal.
 */
contract AspRootQuorum {
    IEntrypointRoots public immutable ENTRYPOINT;
    /// @notice How many distinct ASPs must vote for the same proposal. Always > ASP_COUNT / 2.
    uint256 public immutable THRESHOLD;
    uint256 public immutable ASP_COUNT;

    mapping(address => bool) public isAsp;
    address[] private _asps;

    /// @notice How many roots this contract has posted; votes belong to the current round.
    uint256 public round;
    mapping(bytes32 proposal => uint256) public votes;
    mapping(bytes32 proposal => mapping(address asp => bool)) public hasVoted;

    event Voted(uint256 indexed round, address indexed asp, uint256 root, string ipfsCID, uint256 votes);
    event RootPosted(uint256 indexed round, uint256 root, string ipfsCID, uint256 entrypointIndex);

    error ZeroAddress();
    error DuplicateAsp(address asp);
    error ThresholdNotMajority(uint256 threshold, uint256 aspCount);
    error NotAnAsp();
    error AlreadyVoted();
    error EmptyRoot();
    error InvalidIPFSCIDLength();

    constructor(IEntrypointRoots entrypoint, address[] memory asps_, uint256 threshold) {
        if (address(entrypoint) == address(0)) revert ZeroAddress();
        uint256 n = asps_.length;
        if (threshold == 0 || threshold > n || threshold * 2 <= n) revert ThresholdNotMajority(threshold, n);
        for (uint256 i; i < n; ++i) {
            address a = asps_[i];
            if (a == address(0)) revert ZeroAddress();
            if (isAsp[a]) revert DuplicateAsp(a);
            isAsp[a] = true;
        }
        ENTRYPOINT = entrypoint;
        THRESHOLD = threshold;
        ASP_COUNT = n;
        _asps = asps_;
    }

    /// @notice The fixed ASP set, in deployment order.
    function asps() external view returns (address[] memory) {
        return _asps;
    }

    /// @notice The key a vote for `root` and `ipfsCID` is counted under in round `r`.
    function proposalId(uint256 r, uint256 root, string calldata ipfsCID) public pure returns (bytes32) {
        return keccak256(abi.encode(r, root, ipfsCID));
    }

    /**
     * @notice Vote, as one of the fixed ASPs, for posting `root` with `ipfsCID`. The vote that
     *         reaches THRESHOLD posts the root to the Entrypoint in the same transaction.
     * @return posted Whether this vote posted the root.
     */
    function vote(uint256 root, string calldata ipfsCID) external returns (bool posted) {
        if (!isAsp[msg.sender]) revert NotAnAsp();
        // The Entrypoint's own checks, applied up front so no vote is wasted on a proposal
        // that could never be posted.
        if (root == 0) revert EmptyRoot();
        uint256 cidLength = bytes(ipfsCID).length;
        if (cidLength < 32 || cidLength > 64) revert InvalidIPFSCIDLength();

        uint256 r = round;
        bytes32 p = proposalId(r, root, ipfsCID);
        if (hasVoted[p][msg.sender]) revert AlreadyVoted();
        hasVoted[p][msg.sender] = true;
        uint256 count = ++votes[p];
        emit Voted(r, msg.sender, root, ipfsCID, count);

        if (count == THRESHOLD) {
            round = r + 1;
            uint256 index = ENTRYPOINT.updateRoot(root, ipfsCID);
            emit RootPosted(r, root, ipfsCID, index);
            return true;
        }
    }
}
