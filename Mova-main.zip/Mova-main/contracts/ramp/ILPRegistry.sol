// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/**
 * @notice Sizes are in BRL CENTAVOS, never in asset units.
 *
 * Once the ramp holds more than one asset, a limit denominated in "wei" is meaningless: the
 * same number is 5 ETH or 0.000005 USDC depending on which token is in front of it. A cap
 * sized for one is either unreachable or unlimited for the other, and reputation earned
 * selling stablecoins would silently authorise an enormous ETH position.
 *
 * Centavos are the one unit every leg of this system already shares.
 *
 * ## Exposure is reserved, not checked
 *
 * An earlier version of this interface had only `canQuote(lp, amount)`, asked once per offer
 * or sale. That bounds each position, not the LP: fifty offers each just under the limit
 * were fifty times the limit, and `fundOffer` topped an offer up without asking at all. The
 * escrows now RESERVE an LP's exposure when they take it on and RELEASE it when it ends, and
 * the registry refuses a reservation that would take the LP's total - across every offer,
 * order and sale, on both escrows - over its credit limit.
 */
interface ILPRegistry {
    /// @notice Would reserving `brlCents` more exposure for this LP succeed right now?
    function canQuote(address lp, uint256 brlCents) external view returns (bool);

    /// @notice Take on `brlCents` of exposure for `lp`, or return false if it would exceed
    ///         the LP's remaining credit. Only a registered escrow may call.
    function reserveExposure(address lp, uint256 brlCents) external returns (bool);

    /// @notice Give back exposure this escrow reserved. MUST NOT revert: it runs on release
    ///         and refund paths, after money has moved.
    function releaseExposure(address lp, uint256 brlCents) external;

    /// @notice Called by the escrow on a successful settlement. MUST NOT revert.
    function recordSettled(address lp, uint256 brlCents) external;
    /// @notice Called by the escrow when a dispute is ruled against the LP. MUST NOT revert.
    function recordDispute(address lp) external;

    /// @notice Spend a bank transaction id on a settlement: true the first time, false ever after,
    ///         whichever escrow of this registry spent it. Only an escrow (current or retired) may
    ///         call, or anyone could burn the id of a payment before its proof lands.
    function consumeBankTxId(bytes32 bankTxId) external returns (bool fresh);

    /// @notice Whether a bank transaction id has settled a position on any escrow of this registry.
    function usedBankTxId(bytes32 bankTxId) external view returns (bool);
}
