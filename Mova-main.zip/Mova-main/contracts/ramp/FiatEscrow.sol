// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IAttestorVerifier} from "./IAttestorVerifier.sol";
import {IPriceOracle} from "./IPriceOracle.sol";
import {ILPRegistry} from "./ILPRegistry.sol";
import {RulingLib} from "./RulingLib.sol";
import {SafeTransferLib} from "./SafeTransferLib.sol";
import {ShieldedDepositLabel} from "../common/ShieldedDepositLabel.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";
import {IssuerFreeze} from "../common/IssuerFreeze.sol";

/// @dev The one Entrypoint view the escrow needs: which pool holds a given asset.
interface IEntrypointAssets {
    function assetConfig(address asset)
        external
        view
        returns (address pool, uint256 minimumDepositAmount, uint256 vettingFeeBPS, uint256 maxRelayFeeBPS);
}

/**
 * @title FiatEscrow
 * @notice ZKP2P-style escrow for a BRL <-> ETH ramp (task 2.1).
 *
 * An LP locks ETH here and advertises a price and a PIX key. A taker claims part of that
 * liquidity, pays BRL off-chain, and presents an attestation that the payment settled. The
 * ETH is then released. The contract never touches BRL; it only ever decides whether a
 * claimed fiat payment is good enough to release crypto it already holds.
 *
 * ## The one asymmetry that shapes everything
 *
 * The crypto leg is atomic and reversible-by-nobody; the fiat leg is neither. A PIX transfer
 * can be genuine and still be reversed by the payer's bank days later (MED - Mecanismo
 * Especial de Devolucao - and ordinary fraud reversal). So "proof of payment" is not proof
 * of settlement finality, and any escrow that treats it as such is writing an unsecured loan
 * with extra steps.
 *
 * This contract does not pretend to solve that. It makes the exposure explicit and bounded:
 *   - the LP chooses the attestor it trusts and the size it will write (`maxOrderWei`);
 *   - release is immediate for the taker, which is what makes the product usable;
 *   - the LP's recourse for a reversed payment is the dispute path (task 2.6), which is
 *     arbitrated off-chain because a reversal is a fact about the banking system that no
 *     on-chain mechanism can observe.
 * An LP unwilling to carry reversal risk should not be a retail LP. That is a business
 * decision, and the contract's job is to state it rather than obscure it.
 *
 * ## Binding, and why the proof carries the order id
 *
 * A payment receipt is a bearer instrument unless it is bound to the trade it settles.
 * Without binding, an attacker watches for any genuine PIX payment to an LP's key and
 * presents that receipt against their own order. The verifier checks `orderId`, and the
 * escrow additionally requires the payee to match the offer's key and the payment to
 * post-date the lock. Replay is stopped by the registry's `usedBankTxId`, which is global
 * rather than per-order for exactly this reason - and kept in the REGISTRY rather than here, so
 * that one bank transaction settles one position on the whole ramp: an order on this escrow or a
 * sale on the off-ramp, never both (SRM1-12; LPRegistry, "One bank transaction, one settlement").
 *
 * ## Delivery, and the escape hatch
 *
 * `Delivery.DIRECT` sends ETH to an address the taker names. They then deposit into the
 * shielded pool themselves, which makes them the pool's depositor of record and preserves
 * the Phase 1 guarantee that they can always `ragequit` out without any of our services.
 *
 * `Delivery.SHIELDED` has the escrow deposit for them, so the taker never appears on-chain
 * as a depositor at all. That is a real privacy gain and it comes at a real cost: the pool
 * records the ESCROW as depositor (`_pool.deposit(msg.sender, ...)`), so the taker cannot
 * ragequit, and their funds depend forever on the ASP continuing to approve withdrawals.
 * `rescueShielded` exists to give that guarantee back - the taker supplies the commitment
 * proof only they can produce, the escrow ragequits and forwards the proceeds. Without it,
 * choosing privacy would silently mean giving up the escape hatch, and users cannot be
 * expected to price that trade.
 *
 * A rescue is routed by COMMITMENT, not by the caller's own order, and that is load-bearing
 * rather than tidy. The escrow is the pool's depositor of record for EVERY shielded
 * delivery, and a ragequit proof is public the moment it is broadcast. An earlier version
 * took the caller's order id plus arbitrary calldata and paid out to that order's recipient,
 * which meant anyone holding any released shielded order could lift a victim's proof out of
 * the mempool, present it against their own order, and be paid the victim's funds. Routing
 * by commitment makes the payee a property of the money rather than of the transaction.
 *
 * It is routed by (pool, LABEL) rather than by commitment. The pool's ragequit checks the
 * depositor per label and accepts any unspent commitment of that lineage, and a private
 * partial withdrawal spends the deposited commitment and leaves the remainder in a successor
 * with the same label. Keyed by commitment, the hatch only worked for a user who had never
 * touched their deposit. The pool is looked up per asset from the Entrypoint, so token
 * deliveries are rescued from the token's pool, and the proceeds are forwarded in that asset.
 *
 * ## Paying by boleto
 *
 * A PIX key is the LP's for good; a boleto is not. A boleto is a payment slip the PAYEE
 * registers with its bank for one specific amount, so there is no standing "boleto address"
 * an offer could advertise the way it advertises a PIX key. An order paid by boleto therefore
 * has a step a PIX order does not: after the taker locks with `lockOrderByBoleto`, the LP
 * registers a boleto for exactly that order's amount and commits to it on-chain with
 * `issueBoleto`, within BOLETO_ISSUE_WINDOW. The taker checks the line off-chain against the
 * commitment (packages/ramp/src/boleto.ts), pays it at any bank, and the attestation must
 * prove payment of THAT boleto: payee commitment equal to the one issued, rail BOLETO, amount
 * equal to the order's, paid after issue. An LP that never issues has cost the taker nothing:
 * cancelling is free, and after the issue window anyone may return the liquidity.
 *
 * ## Disputes end
 *
 * A dispute is ruled by an arbitrator's signature, and anyone may submit a valid one: the
 * signature is the authority, so the submitter is only a courier. A submitted ruling is public
 * for RULING_DELAY before it executes, so that a stolen arbitrator key - which governor-only
 * submission used to hold back - is seen and revoked before it can move anything. A dispute
 * that nobody rules on within DISPUTE_TIMEOUT is expired by anyone, and the funds return to
 * where they came from - the outcome the escrow reaches anyway when nobody proves anything. So
 * neither a dead arbitration desk nor an absent governor can freeze an order for longer than
 * that, and a compromised desk cannot move funds faster than the governor can revoke it.
 */
/// @dev Mirrors ProofLib.RagequitProof so the compiler derives the same selector. The
///      layout must match the deployed pool exactly; RampRescue.t.sol pins the selector.
interface IPrivacyPoolRagequit {
    struct RagequitProof {
        uint256[2] pA;
        uint256[2][2] pB;
        uint256[2] pC;
        uint256[4] pubSignals;
    }

    function ragequit(RagequitProof memory proof) external;
}

contract FiatEscrow is DelayedGovernance {
    /*//////////////////////////////////////////////////////////////
                                  TYPES
    //////////////////////////////////////////////////////////////*/

    enum Delivery {
        DIRECT, // ETH to an address the taker names; taker keeps the ragequit hatch
        SHIELDED // escrow deposits into the pool; see rescueShielded
    }

    enum OrderState {
        NONE,
        LOCKED,
        RELEASED,
        CANCELLED,
        DISPUTED
    }

    /**
     * @notice A settlement asset the escrow will hold.
     *
     * Each asset carries its OWN oracle and decimals. Sharing one oracle across assets is
     * the obvious shortcut and it is wrong twice: a price quoted per 1e18 is meaningless for
     * a 6-decimal stablecoin, and "BRL per ETH" is not "BRL per USDC". An asset with no
     * configuration cannot be traded at all, which is the safe default.
     */
    struct AssetConfig {
        IPriceOracle oracle;
        uint8 decimals; // fixed the first time the asset is configured; see setAsset
        bool enabled;
    }

    struct Offer {
        address lp;
        address asset; // address(0) = native ETH
        uint256 availableWei; // unlocked liquidity
        uint256 lockedWei; // reserved by live orders
        uint256 priceBrlCentsPerEth; // LP's asking price
        bytes32 pixKeyHash; // salted commitment to the LP's PIX key, never a bare hash
        uint256 minOrderWei;
        uint256 maxOrderWei;
        address verifier; // which attestor this LP accepts
        uint16 railMask; // rails this LP can reconcile; see IAttestorVerifier.Rail
        bool active;
        // The asset's decimals when the offer was posted. Pinned, so the price a taker is
        // charged is a property of the offer and never of mutable asset config.
        uint8 decimals;
    }

    struct Order {
        bytes32 offerId;
        address taker;
        uint256 weiAmount;
        uint256 brlCents; // what the taker must pay
        uint64 lockedAt;
        uint64 payBy;
        OrderState state;
        Delivery delivery;
        address recipient; // DIRECT: payout address. SHIELDED: rescue owner.
        uint256 precommitment; // SHIELDED only
        uint256 commitment; // SHIELDED only, as returned by the pool at deposit time
    }

    /// @notice The boleto side of an order locked with `lockOrderByBoleto`.
    /// @dev A separate mapping rather than Order fields: the Order getter is positional and
    ///      read off-chain (arbitration-desk.ts), and every PIX order would pay for the slots.
    struct BoletoIssue {
        uint64 issueBy; // non-zero marks a boleto order: the LP must issue by this time
        uint64 issuedAt; // zero until the LP commits to a boleto
        bytes32 commitment; // salted commitment to the barcode registered for this order
    }

    /*//////////////////////////////////////////////////////////////
                                 STORAGE
    //////////////////////////////////////////////////////////////*/

    IPriceOracle public immutable ORACLE;
    ILPRegistry public immutable REGISTRY;
    address public immutable POOL_ENTRYPOINT;
    /// @notice The pool itself. `ragequit` lives here, NOT on the entrypoint.
    address public immutable POOL;

    /// @notice Max deviation of an offer price from the oracle mid, in bps. Sanity, not price.
    uint256 public immutable BAND_BPS;

    /// @notice How long a taker has to pay before their lock can be released back to the LP.
    uint64 public constant PAY_WINDOW = 30 minutes;

    /// @notice A receipt older than this cannot settle a new order, even if never used.
    uint64 public constant RECEIPT_MAX_AGE = 1 days;

    /// @notice Refuse to trade against a price older than this, whatever the oracle claims.
    uint256 public constant MAX_PRICE_AGE = 1 hours;

    /// @notice How long an LP has, after a boleto order is locked, to commit to a boleto.
    ///         Not public only for size: BoletoRequested carries the deadline.
    /// @dev Short: registering a boleto is an API call to the LP's bank, and until it happens
    ///      the taker cannot pay and the liquidity is reserved for nobody.
    uint64 internal constant BOLETO_ISSUE_WINDOW = 1 hours;

    /// @notice How long a taker has to pay an issued boleto and have it attested. BoletoIssued
    ///         carries the resulting deadline.
    /// @dev Longer than PAY_WINDOW because the rail is slower, not because the taker is: a
    ///      boleto paid on a Friday evening is confirmed to the payee on the next banking day,
    ///      and an attestor watching the payee's account sees it then. Three days covers a
    ///      weekend. The receipt must post-date the issue, so the window also bounds its age.
    uint64 internal constant BOLETO_PAY_WINDOW = 3 days;

    uint16 private constant BOLETO_BIT = uint16(1 << uint8(IAttestorVerifier.Rail.BOLETO));

    /// @notice Bounds on DISPUTE_TIMEOUT. See the constructor. The same values as
    ///         OffRampEscrow's; not public here only because this contract is at the size limit.
    uint64 internal constant MIN_DISPUTE_TIMEOUT = 7 days;
    uint64 internal constant MAX_DISPUTE_TIMEOUT = 90 days;

    /// @notice How long a signed ruling is public on-chain before it can execute. See
    ///         resolveDispute. OffRampEscrow.RULING_DELAY is the same value, and public.
    uint64 internal constant RULING_DELAY = 1 days;

    /// @notice How long a dispute may go unruled before anyone can expire it to its default.
    uint64 public immutable DISPUTE_TIMEOUT;

    /// @notice address(0) is native ETH, registered in the constructor.
    mapping(address => AssetConfig) public assets;

    mapping(bytes32 => Offer) public offers;
    mapping(bytes32 => Order) public orders;

    /// @notice BRL value of each offer's availableWei + lockedWei, as reserved against its
    ///         LP's credit in the registry. Kept in step by _reserveExposure/_releaseExposure.
    /// @dev A mapping rather than an Offer field: the struct's public getter is at the
    ///      stack limit, and off-chain readers decode that getter positionally. Not public, for
    ///      contract size: the LP's total is `LPRegistry.reservedBy(escrow, lp)`, and one offer's
    ///      is ceil((availableWei + lockedWei) * price / 10**decimals) from `offers(id)`.
    mapping(bytes32 => uint256) internal offerExposureCents;

    /// @notice Which order a shielded deposit belongs to, by pool and label.
    /// @dev The escrow is the pool's depositor of record for every SHIELDED delivery, so a
    ///      rescue must be routed by the MONEY rather than by whoever submitted it, and the
    ///      pool tracks money for ragequit by label. See rescueShielded.
    mapping(address => mapping(uint256 => bytes32)) public orderForLabel;
    /// @notice The pool label of a SHIELDED order's deposit; zero for DIRECT orders.
    mapping(bytes32 => uint256) public labelOfOrder;

    /// @notice Attestors the protocol will allow an LP to select. Not a price on trust:
    ///         an LP still has to choose one, but a known-broken attestor can be withdrawn.
    mapping(address => bool) public allowedVerifier;

    /// @notice Whose signed rulings this escrow will execute, and since when (0 = none).
    ///         Not the same power as the governor's: an arbitrator decides, the governor
    ///         submits.
    /// @dev "Since when" matters. See resolveDispute: a ruling that pays the party who did
    ///      NOT escrow the funds must come from an arbitrator who predates the dispute.
    mapping(address => uint64) public arbitratorSince;
    /// @notice When each dispute was raised.
    mapping(bytes32 => uint64) public disputedAt;
    /// @notice Whether the offer's LP, rather than the taker, raised the dispute. Only an LP
    ///         carries reputation, so only an LP's own disputes can count against it.
    mapping(bytes32 => bool) internal disputeRaisedByLP;
    /// @dev The ruling posted for each disputed order and not yet executed: the top 192 bits of
    ///      its EIP-712 digest, above the 64-bit time it becomes executable. One slot, because
    ///      this contract is at the size limit; 192 bits of a digest the arbitrator signed is
    ///      not a collision anyone can aim at.
    mapping(bytes32 => uint256) internal postedRuling;

    /// @notice Boleto orders, by order id. See BoletoIssue.
    mapping(bytes32 => BoletoIssue) public boletoOf;
    /// @notice A boleto commitment settles at most one order, ever.
    mapping(bytes32 => bool) internal usedBoletoCommitment;

    /**
     * @notice Most of an asset this escrow may hold, in base units; zero means no cap.
     * @dev Whatever this escrow holds of a freezable token is frozen at once if the issuer lists
     *      the escrow, with no path out (SR2-25). Credit limits bound each LP; this bounds the
     *      whole escrow, and so the worst case. Counted as the escrow's balance - offers, locked
     *      orders and anything sent to it - so a donation can fill it: an attacker who burns their
     *      own tokens into the escrow can pause new offers until the cap is raised.
     */
    mapping(address => uint256) public assetCap;

    uint256 private _nonce;
    uint256 private _entered;

    /*//////////////////////////////////////////////////////////////
                                 EVENTS
    //////////////////////////////////////////////////////////////*/

    event OfferPosted(bytes32 indexed offerId, address indexed lp, uint256 wei_, uint256 price);
    event OfferFunded(bytes32 indexed offerId, uint256 addedWei);
    event OfferClosed(bytes32 indexed offerId, uint256 returnedWei);
    event OrderLocked(
        bytes32 indexed orderId, bytes32 indexed offerId, address indexed taker, uint256 brlCents
    );
    event OrderReleased(bytes32 indexed orderId, bytes32 bankTxId, uint256 weiAmount);
    event OrderCancelled(bytes32 indexed orderId, bool byTaker);
    event OrderDisputed(bytes32 indexed orderId, address by, string reason);
    event DisputeResolved(
        bytes32 indexed orderId,
        bool releasedToTaker,
        address indexed arbitrator,
        bytes32 evidenceRoot
    );
    /// @dev The rationale is not in the events: the signed ruling, rationale and all, is in the
    ///      calldata of the transaction that posted it, and strings in events cost bytecode.
    event RulingPosted(
        bytes32 indexed orderId, bool releasedToTaker, address indexed arbitrator, bytes32 evidenceRoot,
        uint64 executableAt
    );
    event DisputeTimedOut(bytes32 indexed orderId);
    event BoletoRequested(bytes32 indexed orderId, uint64 issueBy);
    event BoletoIssued(bytes32 indexed orderId, bytes32 commitment, uint64 payBy);
    event VerifierSet(address indexed verifier, bool allowed);
    event AssetSet(address indexed asset, address oracle, uint8 decimals, bool enabled);
    event ArbitratorSet(address indexed arbitrator, bool allowed);
    event AssetCapSet(address indexed asset, uint256 cap);
    event DeliveryMadeDirect(bytes32 indexed orderId);

    /*//////////////////////////////////////////////////////////////
                                 ERRORS
    //////////////////////////////////////////////////////////////*/

    error NotArbitrator(address signer);
    error ArbitratorNewerThanDispute(address signer);
    error RulingForAnotherOrder();
    error BadDisputeTimeout(uint256 timeout);
    error DisputeExpired(uint64 deadline);
    error DisputeStillOpen(uint64 deadline);
    error BoletoNotIssued();
    error BadBoleto();
    error WrongAmount();
    error RulingNotReady(uint64 executableAt);
    error NotLP();
    error NotTaker();
    error Reentrancy();
    error BadOffer();
    error BadOrder();
    error OfferInactive();
    error VerifierNotAllowed();
    error AmountOutOfRange();
    error InsufficientLiquidity();
    error PriceOutsideBand();
    error AssetNotEnabled(address asset);
    error WrongMsgValue();
    error StalePrice();
    error WindowExpired();
    error WindowStillOpen();
    error WrongPayee();
    error Underpaid();
    error RailNotAccepted();
    error BankRailNeedsZkTls();
    error ReceiptReplayed();
    error ReceiptPredatesOrder();
    error ReceiptTooOld();
    error WrongState();
    error LPNotEligible();
    error TransferFailed();
    error DecimalsFixed(address asset, uint8 decimals);
    error FrozenByAssetIssuer(address who);
    error AssetCapExceeded(address asset, uint256 cap);
    error BelowPoolMinimum(uint256 minimum);

    /*//////////////////////////////////////////////////////////////
                               MODIFIERS
    //////////////////////////////////////////////////////////////*/

    /// @dev Release calls out to the pool and to arbitrary payout addresses. Effects are
    ///      written before every such call, but a guard is cheap and the alternative is
    ///      arguing about it during an audit.
    ///      The body lives in functions rather than in the modifier: a modifier is inlined into
    ///      every function it guards, and this contract sits against the EIP-170 size limit.
    modifier nonReentrant() {
        _enter();
        _;
        _entered = 0;
    }

    function _enter() private {
        if (_entered == 1) revert Reentrancy();
        _entered = 1;
    }

    constructor(
        address oracle,
        address registry,
        address poolEntrypoint,
        address pool,
        uint256 bandBps,
        address governor_,
        uint256 governanceDelay,
        uint256 disputeTimeout
    ) DelayedGovernance(governor_, governanceDelay) {
        if (
            oracle == address(0) || registry == address(0) || poolEntrypoint == address(0)
                || pool == address(0)
        ) revert ZeroAddress();
        // Immutable, so no governor can shorten a live dispute or stretch it into a freeze.
        // Below a week, a desk that is down over a long weekend and a holiday would lose every
        // case it had to the default; above ninety days, "not frozen forever" stops meaning much
        // to someone whose salary is in the escrow.
        if (disputeTimeout < MIN_DISPUTE_TIMEOUT || disputeTimeout > MAX_DISPUTE_TIMEOUT) {
            revert BadDisputeTimeout(disputeTimeout);
        }
        DISPUTE_TIMEOUT = uint64(disputeTimeout);
        ORACLE = IPriceOracle(oracle);
        REGISTRY = ILPRegistry(registry);
        POOL_ENTRYPOINT = poolEntrypoint;
        POOL = pool;
        BAND_BPS = bandBps;
        assets[address(0)] =
            AssetConfig({oracle: IPriceOracle(oracle), decimals: 18, enabled: true});
        emit AssetSet(address(0), oracle, 18, true);
    }

    /**
     * @notice List or delist a settlement asset.
     * @dev Delisting stops new offers; it deliberately does not touch live ones, because
     *      stranding an LP's posted liquidity is a worse outcome than one more settlement
     *      in an asset we no longer want.
     *
     *      Decimals are fixed the first time an asset is configured, and every offer also
     *      pins them when posted. They are a fact about the token, not a policy, and they
     *      were the one input to a taker's obligation that was read at lock time from
     *      governor-writable config: `ceilDiv(wei * price, 10 ** decimals)`. Re-listing a
     *      live 6-decimal token as 36 decimals made every order against its offers cost
     *      R$0.01, so a governor could buy out the book for centavos. Relisting or delisting
     *      may change the oracle and the enabled flag, never the decimals.
     *
     *      Delisting is instant. Anything else - a first listing, re-enabling, or pointing
     *      the band at a different oracle - waits out the governance delay.
     */
    function setAsset(address asset, address oracle, uint8 decimals_, bool enabled) external {
        AssetConfig storage cur = assets[asset];
        uint8 fixed_ = cur.decimals;
        _authorizeChange(fixed_ == 0 || oracle != address(cur.oracle) || (enabled && !cur.enabled));
        if (oracle == address(0)) revert ZeroAddress();
        if (decimals_ == 0 || decimals_ > 36) revert AssetNotEnabled(asset);
        if (fixed_ != 0 && fixed_ != decimals_) revert DecimalsFixed(asset, fixed_);
        cur.oracle = IPriceOracle(oracle);
        cur.decimals = decimals_;
        cur.enabled = enabled;
        emit AssetSet(asset, oracle, decimals_, enabled);
    }

    /*//////////////////////////////////////////////////////////////
                                  LP SIDE
    //////////////////////////////////////////////////////////////*/

    function postOffer(
        address asset,
        uint256 amount,
        uint256 priceBrlCentsPerEth,
        bytes32 pixKeyHash,
        uint256 minOrderWei,
        uint256 maxOrderWei,
        address verifier,
        uint16 railMask
    ) external payable nonReentrant returns (bytes32 offerId) {
        _requireSetupComplete();
        AssetConfig memory cfg = assets[asset];
        if (!cfg.enabled) revert AssetNotEnabled(asset);
        // A key is needed for every rail except BOLETO, whose payee is issued per order.
        if (
            amount == 0 || priceBrlCentsPerEth == 0
                || (pixKeyHash == bytes32(0) && railMask & ~BOLETO_BIT != 0)
        ) {
            revert BadOffer();
        }
        if (minOrderWei == 0 || maxOrderWei < minOrderWei || maxOrderWei > amount) {
            revert BadOffer();
        }
        if (!allowedVerifier[verifier]) revert VerifierNotAllowed();
        // An LP that cannot reconcile boletos declines them here rather than discovering it
        // when a taker presents one.
        if (railMask == 0) revert BadOffer();
        // Every rail is a bank payment - PIX, boleto or TED - and settles only on a proof of the
        // bank session itself, never on attestors' word: a colluding quorum could otherwise
        // release this offer against a payment that never happened.
        if (!IAttestorVerifier(verifier).provesBankSession()) revert BankRailNeedsZkTls();
        _requireWithinBand(asset, priceBrlCentsPerEth);

        offerId = keccak256(abi.encode(msg.sender, ++_nonce, block.chainid, address(this)));
        Offer storage o = offers[offerId];
        o.lp = msg.sender;
        o.asset = asset;
        o.availableWei = amount;
        o.priceBrlCentsPerEth = priceBrlCentsPerEth;
        o.pixKeyHash = pixKeyHash;
        o.minOrderWei = minOrderWei;
        o.maxOrderWei = maxOrderWei;
        o.verifier = verifier;
        o.railMask = railMask;
        o.active = true;
        o.decimals = cfg.decimals;
        // Exposure is the BRL value of the liquidity, not its raw token amount, and it is
        // RESERVED against the LP's credit across all its positions - not merely compared
        // with the limit, which let many offers each under the limit add up past it.
        _reserveExposure(offerId, o);
        // Effects before interactions: the pull hands control to the token, and a callback
        // token must find the offer already fully written rather than half-built.
        _receive(asset, amount);
        emit OfferPosted(offerId, msg.sender, amount, priceBrlCentsPerEth);
    }

    /// @dev nonReentrant because pulling a token hands control to it, and a callback token
    ///      (ERC-777 and friends) could otherwise re-enter before the offer's accounting is
    ///      updated. These entry points made no external calls until assets were added.
    function fundOffer(bytes32 offerId, uint256 amount) external payable nonReentrant {
        Offer storage o = offers[offerId];
        if (o.lp != msg.sender) revert NotLP();
        if (!o.active) revert OfferInactive();
        o.availableWei += amount;
        // Topping up is taking on more exposure. This used to skip the credit check entirely,
        // so a tiny offer could be funded to any size.
        _reserveExposure(offerId, o);
        _receive(o.asset, amount);
        emit OfferFunded(offerId, amount);
    }

    /**
     * @notice Withdraw unlocked liquidity and stop quoting.
     * @dev Only `availableWei` leaves. Liquidity reserved by live orders stays until those
     *      orders release or expire - otherwise an LP could see a payment land in their bank
     *      account and pull the crypto out from under the taker in the same block.
     */
    function closeOffer(bytes32 offerId) external nonReentrant {
        Offer storage o = offers[offerId];
        if (o.lp != msg.sender) revert NotLP();
        uint256 amount = o.availableWei;
        o.availableWei = 0;
        o.active = false;
        _releaseExposure(offerId, o);
        emit OfferClosed(offerId, amount);
        if (amount > 0) _pay(o.asset, msg.sender, amount);
    }

    /*//////////////////////////////////////////////////////////////
                                TAKER SIDE
    //////////////////////////////////////////////////////////////*/

    /// @notice Lock liquidity to pay for by PIX or TED, to the offer's key.
    function lockOrder(
        bytes32 offerId,
        uint256 weiAmount,
        Delivery delivery,
        address recipient,
        uint256 precommitment
    ) external returns (bytes32 orderId) {
        return _lock(offerId, weiAmount, delivery, recipient, precommitment, false);
    }

    /**
     * @notice Lock liquidity to pay for by boleto. The LP must then issue one: see issueBoleto.
     * @dev The pay clock does not start until the boleto exists. Until then `payBy` is the
     *      issue deadline, so an LP that never issues is handled by the same `reclaimExpired`
     *      as a taker that never pays - and the taker can `cancelOrder` at any moment, free.
     */
    function lockOrderByBoleto(
        bytes32 offerId,
        uint256 weiAmount,
        Delivery delivery,
        address recipient,
        uint256 precommitment
    ) external returns (bytes32 orderId) {
        return _lock(offerId, weiAmount, delivery, recipient, precommitment, true);
    }

    /**
     * @notice The LP commits to the boleto it registered for this order.
     * @param commitment keccak256(abi.encode("PrivacyPoolsBRL/boleto/v1", barcode44, salt)) -
     *        see `boletoCommitment` in packages/ramp/src/boleto.ts. Salted for the same reason
     *        a PIX key is: the barcode names the LP's bank account and whoever holds a copy of
     *        the slip could otherwise find the order on-chain.
     * @dev The escrow cannot see the barcode, so it cannot check the boleto is for the order's
     *      amount. The taker can, before paying a centavo: the LP hands over line and salt,
     *      the SDK recomputes this commitment and reads the amount out of the line, and a
     *      mismatch is a free cancel. What the escrow does enforce is that the attested
     *      payment is of THIS commitment, of exactly the order's amount, made after issue -
     *      and that one boleto never serves two orders.
     */
    function issueBoleto(bytes32 orderId, bytes32 commitment) external {
        Order storage ord = orders[orderId];
        BoletoIssue storage b = boletoOf[orderId];
        if (offers[ord.offerId].lp != msg.sender) revert NotLP();
        if (ord.state != OrderState.LOCKED || b.issueBy == 0 || b.issuedAt != 0) {
            revert WrongState();
        }
        if (block.timestamp > b.issueBy) revert WindowExpired();
        if (commitment == bytes32(0) || usedBoletoCommitment[commitment]) revert BadBoleto();
        usedBoletoCommitment[commitment] = true;
        b.commitment = commitment;
        b.issuedAt = uint64(block.timestamp);
        ord.payBy = uint64(block.timestamp) + BOLETO_PAY_WINDOW;
        emit BoletoIssued(orderId, commitment, ord.payBy);
    }

    function _lock(
        bytes32 offerId,
        uint256 weiAmount,
        Delivery delivery,
        address recipient,
        uint256 precommitment,
        bool boleto
    ) private returns (bytes32 orderId) {
        Offer storage o = offers[offerId];
        if (o.lp == address(0)) revert BadOffer();
        if (!o.active) revert OfferInactive();
        // An order the LP cannot reconcile would only waste its window. A boleto order needs
        // an LP that issues boletos; any other order needs a rail with a standing key.
        if (o.railMask & (boleto ? BOLETO_BIT : ~BOLETO_BIT) == 0) revert RailNotAccepted();
        if (weiAmount < o.minOrderWei || weiAmount > o.maxOrderWei) revert AmountOutOfRange();
        if (weiAmount > o.availableWei) revert InsufficientLiquidity();
        if (recipient == address(0)) revert ZeroAddress();
        if (delivery == Delivery.SHIELDED && precommitment == 0) revert BadOrder();

        // Re-check the band at lock time, not only at post time. An offer posted hours ago
        // at a then-sane price is not sane now, and the taker is the party who loses.
        _requireWithinBand(o.asset, o.priceBrlCentsPerEth);
        _screenLock(o, weiAmount, delivery, recipient);

        o.availableWei -= weiAmount;
        o.lockedWei += weiAmount;

        // Round the taker's obligation UP. Rounding down would let a taker shave a centavo
        // per order, and at ramp volumes "a rounding error in the user's favour" is a
        // withdrawal strategy rather than an accident.
        // The decimals pinned at post time, not the asset's current config: see setAsset.
        uint256 brlCents = _ceilDiv(weiAmount * o.priceBrlCentsPerEth, 10 ** o.decimals);

        orderId = keccak256(abi.encode(offerId, msg.sender, ++_nonce, block.chainid));
        // A boleto order's first deadline is the LP's, to issue; the taker's starts at issue.
        uint64 payBy = uint64(block.timestamp) + (boleto ? BOLETO_ISSUE_WINDOW : PAY_WINDOW);
        orders[orderId] = Order({
            offerId: offerId,
            taker: msg.sender,
            weiAmount: weiAmount,
            brlCents: brlCents,
            lockedAt: uint64(block.timestamp),
            payBy: payBy,
            state: OrderState.LOCKED,
            delivery: delivery,
            recipient: recipient,
            precommitment: precommitment,
            commitment: 0
        });
        emit OrderLocked(orderId, offerId, msg.sender, brlCents);
        if (boleto) {
            boletoOf[orderId].issueBy = payBy;
            emit BoletoRequested(orderId, payBy);
        }
    }

    /**
     * @notice Present proof the BRL was paid, and take delivery.
     * @dev Deliberately callable by anyone holding a valid proof. The proof is bound to the
     *      order and the payout destination is fixed at lock time, so a third party can pay
     *      the gas without being able to redirect a single wei. That is what lets a relayer
     *      settle for a taker who holds no ETH - the same property the Phase 1 paymaster
     *      provides, arrived at by a different route.
     */
    function releaseWithProof(bytes32 orderId, bytes calldata proof) external nonReentrant {
        Order storage ord = orders[orderId];
        if (ord.state != OrderState.LOCKED) revert WrongState();
        if (block.timestamp > ord.payBy) revert WindowExpired();

        Offer storage o = offers[ord.offerId];
        // Re-check the verifier at SETTLEMENT, not only when the offer was posted.
        //
        // Revoking a verifier is the governor's only lever against a compromised or broken
        // attestor, and checking it once at post time made that lever useless against
        // exactly the case it exists for: every offer already carrying the bad verifier
        // would keep settling forged payments until each LP closed their own offer.
        //
        // The cost is that revocation strands orders already locked, whose takers may have
        // paid BRL. That is what the dispute path is for - a stranded taker raises one and
        // an arbitrator can still release to them - and it is the right trade: a stuck order
        // is recoverable, a verifier minting settlements is not.
        if (!allowedVerifier[o.verifier]) revert VerifierNotAllowed();
        IAttestorVerifier.Payment memory p =
            IAttestorVerifier(o.verifier).verifyPayment(orderId, proof);

        // A boleto order settles only by payment of the boleto issued for it: that commitment,
        // on the BOLETO rail, for EXACTLY the order's amount - a boleto's amount is written into
        // its line, so a payment of any other amount is not a payment of the boleto the taker
        // checked - made after it was issued. Any other order settles only to the offer's key,
        // on a rail the offer accepts other than BOLETO, for at least the order's amount.
        BoletoIssue storage b = boletoOf[orderId];
        bool boleto = b.issueBy != 0;
        if (boleto && b.issuedAt == 0) revert BoletoNotIssued();
        if (p.payeeKeyHash != (boleto ? b.commitment : o.pixKeyHash)) revert WrongPayee();
        if (p.amountBrlCents < ord.brlCents) revert Underpaid();
        if (boleto && p.amountBrlCents != ord.brlCents) revert WrongAmount();
        if (!_railAccepted(boleto ? BOLETO_BIT : o.railMask & ~BOLETO_BIT, p.rail)) {
            revert RailNotAccepted();
        }
        // A receipt from before the order (or its boleto) existed cannot be settling it. A
        // boleto receipt needs no age check: paid after issue and proven before payBy, it is
        // never older than BOLETO_PAY_WINDOW.
        if (p.paidAt < (boleto ? b.issuedAt : ord.lockedAt)) revert ReceiptPredatesOrder();
        if (!boleto && p.paidAt + RECEIPT_MAX_AGE < block.timestamp) revert ReceiptTooOld();

        ord.state = OrderState.RELEASED;
        o.lockedWei -= ord.weiAmount;
        _releaseExposure(ord.offerId, o);
        // Spent in the registry, which every escrow of the ramp shares, so a bank transaction that
        // settled a sale on the off-ramp cannot settle this order too. After the effects: a
        // replay reverts them all.
        if (!REGISTRY.consumeBankTxId(p.bankTxId)) revert ReceiptReplayed();

        _reputation(o.lp, ord.brlCents, false);
        emit OrderReleased(orderId, p.bankTxId, ord.weiAmount);

        _deliver(orderId, ord);
    }

    /// @notice Give up before paying. Returns the liquidity immediately rather than making
    ///         the LP wait out the window for capital nobody is going to use.
    function cancelOrder(bytes32 orderId) external {
        Order storage ord = orders[orderId];
        if (ord.taker != msg.sender) revert NotTaker();
        if (ord.state != OrderState.LOCKED) revert WrongState();
        _unlock(ord);
        emit OrderCancelled(orderId, true);
    }

    /**
     * @notice Take a shielded order's delivery in the open instead, to the rescue address.
     *
     * A shielded delivery can become impossible after the taker has paid: the Entrypoint or the
     * pool can be frozen by the token's issuer (SR2-26), the pool's minimum can be raised above
     * the order, or the pool can be wound down. The delivery mode was fixed at lock, so a proven
     * release reverted, a RELEASE ruling reverted the same way, and the order expired back to the
     * LP - the taker's BRL paid for nothing. This lets the taker trade privacy for the money: from
     * here on every release and every RELEASE ruling pays `recipient`, the rescue address the
     * taker named at lock, directly.
     *
     * Only that address may ask, and only for itself, so nobody can strip a taker's privacy for
     * them. The LP is indifferent: it is paid in BRL either way, and the amount is the same. The
     * order must still be LOCKED (dispute it first if the pay window is closing) or DISPUTED.
     */
    function takeDeliveryDirect(bytes32 orderId) external {
        Order storage ord = orders[orderId];
        if (msg.sender != ord.recipient) revert NotTaker();
        if (
            ord.delivery != Delivery.SHIELDED
                || (ord.state != OrderState.LOCKED && ord.state != OrderState.DISPUTED)
        ) revert WrongState();
        _requireNotFrozen(offers[ord.offerId].asset, msg.sender);
        ord.delivery = Delivery.DIRECT;
        emit DeliveryMadeDirect(orderId);
    }

    /// @notice After the window, anyone may return unpaid liquidity to the LP.
    function reclaimExpired(bytes32 orderId) external {
        Order storage ord = orders[orderId];
        if (ord.state != OrderState.LOCKED) revert WrongState();
        if (block.timestamp <= ord.payBy) revert WindowStillOpen();
        _unlock(ord);
        emit OrderCancelled(orderId, false);
    }

    /*//////////////////////////////////////////////////////////////
                            DISPUTES (task 2.6)
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Freeze an order pending arbitration.
     *
     * The cases this exists for are the ones no proof can settle: the taker paid but the
     * attestor cannot produce a proof (bank downtime, an unsupported statement format), or
     * the LP believes a released payment was later reversed. Both are facts about the
     * banking system, not about the chain, so the ruling is necessarily off-chain. What is
     * on-chain is that the funds stop moving and the ruling is recorded publicly.
     */
    function raiseDispute(bytes32 orderId, string calldata reason) external {
        Order storage ord = orders[orderId];
        Offer storage o = offers[ord.offerId];
        if (msg.sender != ord.taker && msg.sender != o.lp) revert NotTaker();
        if (ord.state != OrderState.LOCKED) revert WrongState();
        ord.state = OrderState.DISPUTED;
        disputedAt[orderId] = uint64(block.timestamp);
        disputeRaisedByLP[orderId] = msg.sender == o.lp;
        emit OrderDisputed(orderId, msg.sender, reason);
    }

    /**
     * @notice Submit an arbitrator's signed ruling. Anyone may submit it: the first submission
     *         posts it, and the same ruling submitted again after RULING_DELAY executes it.
     * @dev The signature is the authority; the submitter is a courier. This was governor-only,
     *      which put two parties between a ruling and its execution - the desk that signs and
     *      the governor that submits - so an absent or hostile governor froze every dispute
     *      indefinitely, whatever the arbitrator had decided. The party a ruling favours now
     *      submits it themselves. Replay is still impossible: the signed struct names this
     *      escrow and this order, the EIP-712 domain names the chain, and an order leaves
     *      DISPUTED for good the first time a ruling executes.
     *
     *      Why a delay, when the governor was the only thing it replaces. Governor-only
     *      submission was also the one check between a STOLEN arbitrator key and the money:
     *      whoever holds the key can lock orders as a taker, dispute them, sign RELEASE on each,
     *      and - with submission open to anyone - drain every offer on the escrow, one order at
     *      a time, with no BRL paid. So a ruling is first posted, in public, and can execute
     *      only after RULING_DELAY, re-verified in full at that moment. A ruling the desk never
     *      signed shows up on-chain a day before it can move anything; revoking the arbitrator,
     *      which is instant, voids every ruling it has posted and not yet executed. Liveness is
     *      unaffected: the second submission is as permissionless as the first.
     *
     *      Timing against the dispute timeout: a ruling must be posted with at least one
     *      RULING_DELAY to spare after it becomes executable, and must execute before the
     *      deadline; from `disputedAt + DISPUTE_TIMEOUT` on only `expireDispute` applies, so a
     *      ruling and the default can never both be valid. Posting a DIFFERENT valid ruling
     *      replaces a pending one and restarts its delay - that is how a rotated-in arbitrator
     *      supersedes a revoked one - while resubmitting the same ruling early reverts rather
     *      than restarting anything. The desk signs at most one ruling per case.
     *
     *      Per call it is bounded: it reaches only orders in DISPUTED state, never an LP's free
     *      liquidity or a released order, never more than the disputed amount, and never the
     *      shielded pool.
     *
     *      That bound is NOT a bound on a malicious governor, and an earlier version of this
     *      comment said it could not drain an offer. It could: allow its own key as an
     *      arbitrator, lock orders against an offer as the taker, dispute them, sign RELEASE
     *      and submit - draining the offer order by order without paying BRL. What stops
     *      that now is that adding an arbitrator waits out GOVERNANCE_DELAY in public, so an
     *      LP sees the new arbitrator scheduled and can close their offer first. Revoking an
     *      arbitrator stays instant.
     *
     *      A timelock alone was not enough, and the reason is worth keeping. During the delay
     *      the governor can already lock orders as the taker and dispute them, and closing
     *      the offer does not recover a disputed order. Once the new arbitrator landed it
     *      would rule RELEASE on every one. So a ruling that pays the COUNTERPARTY (the side
     *      that escrowed nothing) is accepted only from an arbitrator registered no later
     *      than the dispute was raised. A ruling that returns the funds to the party who
     *      escrowed them is accepted from any current arbitrator, so rotating a compromised
     *      arbitrator key can never strand a dispute: the new key can always refund, and the
     *      timeout refunds even if nobody holds a key at all.
     *
     *      Reputation. On this leg the LP owes nothing an arbitrator could find it failed to
     *      pay, so a REFUND (the taker never paid) records nothing against it - it used to
     *      record a lost dispute, which let any taker halve a retail LP's limit by locking an
     *      order and disputing it. A RELEASE is a completed trade and counts as settled volume,
     *      exactly as a proven release does; if the LP itself raised the dispute, claiming it
     *      was not paid, it also lost the dispute it raised.
     */
    function resolveDispute(
        bytes32 orderId,
        RulingLib.Ruling calldata ruling,
        bytes calldata arbitratorSignature
    ) external nonReentrant {
        Order storage ord = orders[orderId];
        if (ord.state != OrderState.DISPUTED) revert WrongState();
        (bool ready, bool releaseToTaker) = _admitRuling(orderId, ruling, arbitratorSignature);
        if (!ready) return;

        if (releaseToTaker) {
            Offer storage o = offers[ord.offerId];
            ord.state = OrderState.RELEASED;
            o.lockedWei -= ord.weiAmount;
            _releaseExposure(ord.offerId, o);
            _reputation(o.lp, ord.brlCents, disputeRaisedByLP[orderId]);
            _deliver(orderId, ord);
        } else {
            _unlock(ord);
        }
    }

    /**
     * @dev Verify a ruling for a disputed order, then either post it (first sight: executable
     *      after RULING_DELAY) or report it ready (the same ruling again, after its delay).
     *      Everything is re-checked on the second sight, so revoking the arbitrator in between
     *      voids its ruling. Split out of resolveDispute for the stack, not for reuse.
     */
    function _admitRuling(bytes32 orderId, RulingLib.Ruling calldata ruling, bytes calldata sig)
        private
        returns (bool ready, bool release)
    {
        uint64 at = disputedAt[orderId];
        uint64 deadline = at + DISPUTE_TIMEOUT;
        if (block.timestamp >= deadline) revert DisputeExpired(deadline);
        if (ruling.orderId != orderId) revert RulingForAnotherOrder();

        address signer;
        bytes32 digest;
        (signer, release, digest) = RulingLib.verify(ruling, address(this), sig);
        uint64 since = arbitratorSince[signer];
        // Zero is the "never registered" sentinel, not a moment anyone can hit by timing.
        // slither-disable-next-line incorrect-equality
        if (since == 0) revert NotArbitrator(signer);
        // The counterparty escrowed nothing: paying it needs an arbitrator older than the dispute.
        if (release && since > at) revert ArbitratorNewerThanDispute(signer);

        uint256 posted = postedRuling[orderId];
        if (posted >> 64 != uint256(digest) >> 64) {
            uint64 executableAt = uint64(block.timestamp) + RULING_DELAY;
            if (executableAt + RULING_DELAY > deadline) revert DisputeExpired(deadline);
            postedRuling[orderId] = (uint256(digest) >> 64 << 64) | executableAt;
            emit RulingPosted(orderId, release, signer, ruling.evidenceRoot, executableAt);
            return (false, release);
        }
        if (block.timestamp < uint64(posted)) revert RulingNotReady(uint64(posted));
        emit DisputeResolved(orderId, release, signer, ruling.evidenceRoot);
        return (true, release);
    }

    /**
     * @notice After DISPUTE_TIMEOUT with no ruling, anyone returns the order's liquidity to
     *         the LP's offer.
     * @dev REFUND TO ORIGIN, the arbitration desk's own default, and for the reason the desk
     *      gives: it is the one outcome that cannot be gamed by staying silent. It is also
     *      exactly what this escrow does when nobody disputes anything - an unproven order
     *      expires back to the LP - so a dispute nobody decides is worth, in the end, nothing
     *      but the time it froze the order. A taker who really paid has DISPUTE_TIMEOUT to get
     *      a RELEASE signed and submit it themselves.
     *
     *      The liquidity goes back to the offer, as on every other path that ends an order
     *      unpaid; the LP's credit is freed when it withdraws (closeOffer), because until then
     *      that liquidity is quotable and at risk again.
     *
     *      A timeout is no finding on the merits, so it never records a settlement: a dispute
     *      cannot be used to farm volume. It records a lost dispute only when the LP raised it.
     *      Freezing the order was that LP's choice and getting it decided was its burden; the
     *      LP is also the only party on this leg a dispute could profit, by holding a paid
     *      order until the desk is unreachable. A taker's unanswered dispute costs the LP
     *      nothing, or anyone could halve an LP's limit by disputing during a desk outage.
     */
    function expireDispute(bytes32 orderId) external {
        Order storage ord = orders[orderId];
        if (ord.state != OrderState.DISPUTED) revert WrongState();
        uint64 deadline = disputedAt[orderId] + DISPUTE_TIMEOUT;
        if (block.timestamp < deadline) revert DisputeStillOpen(deadline);
        _unlock(ord);
        _reputation(offers[ord.offerId].lp, 0, disputeRaisedByLP[orderId]);
        emit DisputeTimedOut(orderId);
    }

    /// @notice Whether a bank transaction has settled anything on any escrow of this registry.
    function usedBankTxId(bytes32 bankTxId) external view returns (bool) {
        return REGISTRY.usedBankTxId(bankTxId);
    }

    /*//////////////////////////////////////////////////////////////
                              ESCAPE HATCH
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Ragequit a SHIELDED delivery back out of the pool, on the taker's behalf.
     *
     * Only meaningful because `Delivery.SHIELDED` makes this contract the pool's depositor
     * of record, which would otherwise strand the taker if the ASP stopped approving their
     * withdrawals. The proof requires secrets only the taker holds, so this cannot be used
     * against them; the proceeds go to the address they named at lock time, not to the
     * caller, so it cannot be front-run in the mempool either.
     */
    /// @param pool The Privacy Pool holding the deposit: the ETH pool, or the order asset's pool.
    /// @param proof A ragequit proof for any unspent commitment in the deposit's lineage.
    function rescueShielded(address pool, IPrivacyPoolRagequit.RagequitProof calldata proof)
        external
        nonReentrant
    {
        bytes32 orderId = orderForLabel[pool][proof.pubSignals[3]];
        if (orderId == bytes32(0)) revert BadOrder();
        Order storage ord = orders[orderId];
        if (ord.state != OrderState.RELEASED || ord.delivery != Delivery.SHIELDED) {
            revert WrongState();
        }
        if (msg.sender != ord.recipient) revert NotTaker();

        address asset = offers[ord.offerId].asset;
        uint256 before = _balanceOf(asset);
        IPrivacyPoolRagequit(pool).ragequit(proof);
        uint256 recovered = _balanceOf(asset) - before;
        if (recovered > 0) _pay(asset, ord.recipient, recovered);
    }

    function _balanceOf(address asset) private view returns (uint256) {
        return asset == address(0)
            ? address(this).balance
            : SafeTransferLib.balanceOf(asset, address(this));
    }

    /*//////////////////////////////////////////////////////////////
                              GOVERNANCE
    //////////////////////////////////////////////////////////////*/

    /// @notice Allowing a verifier waits out the governance delay; revoking one is instant.
    function setVerifier(address verifier, bool allowed) external {
        _authorizeChange(allowed && !allowedVerifier[verifier]);
        if (verifier == address(0)) revert ZeroAddress();
        allowedVerifier[verifier] = allowed;
        emit VerifierSet(verifier, allowed);
    }

    /// @notice Adding an arbitrator waits out the governance delay; removing one is instant.
    function setArbitrator(address arbitrator, bool allowed) external {
        bool known = arbitratorSince[arbitrator] != 0;
        _authorizeChange(allowed && !known);
        if (arbitrator == address(0)) revert ZeroAddress();
        // Two booleans; slither sees `known` derive from a timestamp and flags the comparison.
        // slither-disable-next-line incorrect-equality
        if (allowed == known) return; // re-adding must not reset "since"
        arbitratorSince[arbitrator] = allowed ? uint64(block.timestamp) : 0;
        emit ArbitratorSet(arbitrator, allowed);
    }

    /// @notice Lowering or setting a first cap is instant; raising or removing one is delayed.
    function setAssetCap(address asset, uint256 cap) external {
        uint256 cur = assetCap[asset];
        _authorizeChange(cur != 0 && (cap == 0 || cap > cur));
        assetCap[asset] = cap;
        emit AssetCapSet(asset, cap);
    }

    function _isDelayable(bytes4 selector) internal pure override returns (bool) {
        return selector == FiatEscrow.setAsset.selector
            || selector == FiatEscrow.setVerifier.selector
            || selector == FiatEscrow.setArbitrator.selector
            || selector == FiatEscrow.setAssetCap.selector;
    }

    /*//////////////////////////////////////////////////////////////
                                INTERNAL
    //////////////////////////////////////////////////////////////*/

    /**
     * @dev Slither flags the state written after the deposit call, and the ordering is
     *      forced: the commitment does not exist until the pool has inserted it and
     *      returned it. Both callers (releaseWithProof, resolveDispute) are nonReentrant,
     *      and the callee is the Privacy Pools entrypoint, itself nonReentrant and audited,
     *      so the window the detector describes cannot be entered.
     */
    // slither-disable-start reentrancy-eth
    // slither-disable-start reentrancy-no-eth
    function _deliver(bytes32 orderId, Order storage ord) private {
        address asset = offers[ord.offerId].asset;
        if (ord.delivery == Delivery.DIRECT) {
            _pay(asset, ord.recipient, ord.weiAmount);
        } else if (asset == address(0)) {
            (bool ok, bytes memory ret) = POOL_ENTRYPOINT.call{value: ord.weiAmount}(
                abi.encodeWithSignature("deposit(uint256)", ord.precommitment)
            );
            if (!ok) revert TransferFailed();
            _indexCommitment(orderId, ord, ret);
        } else {
            // The ERC-20 pool entrypoint pulls with transferFrom, so it needs an allowance.
            SafeTransferLib.safeApprove(asset, POOL_ENTRYPOINT, ord.weiAmount);
            (bool ok, bytes memory ret) = POOL_ENTRYPOINT.call(
                abi.encodeWithSignature(
                    "deposit(address,uint256,uint256)", asset, ord.weiAmount, ord.precommitment
                )
            );
            if (!ok) revert TransferFailed();
            _indexCommitment(orderId, ord, ret);
            // Leave no standing allowance if the pool pulled less than it was offered.
            SafeTransferLib.safeApprove(asset, POOL_ENTRYPOINT, 0);
        }
    }

    /**
     * @dev The pool returns the commitment it inserted. Recording it is what lets a rescue
     *      be routed to the order that owns those funds rather than to whoever asked.
     *
     *      Slither flags the write-after-call in `_deliver`, and the ordering is forced: the
     *      commitment does not exist until the pool has inserted it. Both callers
     *      (`releaseWithProof`, `resolveDispute`) are nonReentrant, and the callee is the
     *      Privacy Pools entrypoint, which is itself nonReentrant and audited - so the
     *      window the detector describes cannot be entered.
     */
    function _indexCommitment(bytes32 orderId, Order storage ord, bytes memory ret) private {
        if (ret.length < 32) return; // a pool that returns nothing simply has no rescue index
        ord.commitment = abi.decode(ret, (uint256));

        // The deposit just incremented the pool's nonce, so its last label is ours. Checked
        // against a real Deposited event in RampRescueFork.t.sol.
        address token = offers[ord.offerId].asset;
        // Only the pool is needed; fee and minimum settings are not the escrow's concern here.
        // slither-disable-next-line unused-return
        (address pool,,,) = IEntrypointAssets(POOL_ENTRYPOINT).assetConfig(
            token == address(0) ? ShieldedDepositLabel.NATIVE_ASSET : token
        );
        uint256 label = ShieldedDepositLabel.lastLabel(pool);
        labelOfOrder[orderId] = label;
        orderForLabel[pool][label] = orderId;
    }

    /// @dev Native ETH must arrive as msg.value; a token must not.
    // slither-disable-end reentrancy-eth
    // slither-disable-end reentrancy-no-eth

    /**
     * @dev Refuses a token the issuer has frozen this escrow for: the issuer checks only
     *      senders, so the transfer would succeed and the tokens would be frozen on arrival. Then
     *      holds the escrow to `assetCap`, checked on the balance after the transfer.
     */
    function _receive(address asset, uint256 amount) private {
        if (asset == address(0)) {
            if (msg.value != amount) revert WrongMsgValue();
        } else {
            if (msg.value != 0) revert WrongMsgValue();
            _requireNotFrozen(asset, address(this));
            SafeTransferLib.receiveToken(asset, msg.sender, amount);
        }
        uint256 cap = assetCap[asset];
        if (cap != 0 && _balanceOf(asset) > cap) revert AssetCapExceeded(asset, cap);
    }

    function _requireNotFrozen(address asset, address who) private view {
        if (asset != address(0) && IssuerFreeze.isFrozen(asset, who)) revert FrozenByAssetIssuer(who);
    }

    /**
     * @dev What must be true for a locked order to be deliverable at all, checked before the
     *      taker pays anything:
     *
     *      - Nobody the tokens must pass through or land at is frozen by the issuer: this escrow
     *        (it sends), the LP (a listed party is not a counterparty), and the destination - the
     *        recipient for DIRECT, the Entrypoint (it sends to the pool) and the pool for SHIELDED.
     *        A listed pool still accepts deposits and then freezes every note in it.
     *      - A SHIELDED order is at least the pool's minimum deposit. Below it the Entrypoint
     *        refuses the deposit at release (SR2-27). The minimum can still rise after lock;
     *        `takeDeliveryDirect` is the way out of that.
     */
    function _screenLock(Offer storage o, uint256 weiAmount, Delivery delivery, address recipient)
        private
        view
    {
        address asset = o.asset;
        _requireNotFrozen(asset, address(this));
        _requireNotFrozen(asset, o.lp);
        if (delivery == Delivery.DIRECT) {
            _requireNotFrozen(asset, recipient);
            return;
        }
        // Fees are not the escrow's concern; the pool and its minimum are.
        // slither-disable-next-line unused-return
        (address pool, uint256 minimum,,) = IEntrypointAssets(POOL_ENTRYPOINT).assetConfig(
            asset == address(0) ? ShieldedDepositLabel.NATIVE_ASSET : asset
        );
        if (pool == address(0)) revert BadOrder();
        if (weiAmount < minimum) revert BelowPoolMinimum(minimum);
        _requireNotFrozen(asset, POOL_ENTRYPOINT);
        _requireNotFrozen(asset, pool);
    }

    function _pay(address asset, address to, uint256 amount) private {
        if (asset == address(0)) _send(to, amount);
        else SafeTransferLib.safeTransfer(asset, to, amount);
    }

    /// @dev Every reputation report goes through here: settled volume, a lost dispute, or both.
    ///      The registry never reverts on these (see ILPRegistry), so neither does this.
    function _reputation(address lp, uint256 settledCents, bool lostDispute) private {
        if (settledCents != 0) REGISTRY.recordSettled(lp, settledCents);
        if (lostDispute) REGISTRY.recordDispute(lp);
    }

    /// @dev Reserve credit for any growth in the offer's BRL value, or refuse the change.
    ///      The target is recomputed from the offer itself, so rounding can never drift.
    function _reserveExposure(bytes32 offerId, Offer storage o) private {
        uint256 target = _offerExposure(o);
        uint256 held = offerExposureCents[offerId];
        if (target <= held) return;
        offerExposureCents[offerId] = target;
        if (!REGISTRY.reserveExposure(o.lp, target - held)) revert LPNotEligible();
    }

    /// @dev Give back credit for liquidity that has left the offer. Never reverts: it runs on
    ///      settlement and dispute paths, and the registry's release is fail-quiet.
    function _releaseExposure(bytes32 offerId, Offer storage o) private {
        uint256 target = _offerExposure(o);
        uint256 held = offerExposureCents[offerId];
        if (target >= held) return;
        offerExposureCents[offerId] = target;
        REGISTRY.releaseExposure(o.lp, held - target);
    }

    function _offerExposure(Offer storage o) private view returns (uint256) {
        return _ceilDiv((o.availableWei + o.lockedWei) * o.priceBrlCentsPerEth, 10 ** o.decimals);
    }

    /// @dev Ends an order unpaid: CANCELLED, and its liquidity back to the offer.
    function _unlock(Order storage ord) private {
        ord.state = OrderState.CANCELLED;
        Offer storage o = offers[ord.offerId];
        o.lockedWei -= ord.weiAmount;
        // Back to available even on a closed offer; closeOffer can be called again to sweep.
        o.availableWei += ord.weiAmount;
    }

    /**
     * @dev Checks freshness here rather than relying on the oracle to do it. IPriceOracle
     *      says an implementation MUST revert when stale, but "MUST" in an interface is a
     *      request, not an enforcement - and this contract holds the money. A future or
     *      swapped-in oracle that returns a last-known price would otherwise silently widen
     *      the band around a price nobody is maintaining.
     */
    function _requireWithinBand(address asset, uint256 price) private view {
        AssetConfig memory cfg = assets[asset];
        if (!cfg.enabled) revert AssetNotEnabled(asset);
        (uint256 mid, uint64 updatedAt) = cfg.oracle.brlCentsPerUnit();
        if (mid == 0) revert PriceOutsideBand();
        if (block.timestamp > uint256(updatedAt) + MAX_PRICE_AGE) revert StalePrice();
        uint256 diff = price > mid ? price - mid : mid - price;
        if (diff * 10_000 > mid * BAND_BPS) revert PriceOutsideBand();
    }

    function _railAccepted(uint16 mask, IAttestorVerifier.Rail rail) private pure returns (bool) {
        if (rail == IAttestorVerifier.Rail.UNSPECIFIED) return false;
        return mask & uint16(1 << uint8(rail)) != 0;
    }

    function _ceilDiv(uint256 a, uint256 b) private pure returns (uint256) {
        return a == 0 ? 0 : (a - 1) / b + 1;
    }

    /**
     * @dev Slither flags this as `arbitrary-send-eth`, and the flag is worth answering
     *      rather than muting wholesale. Every destination reaching here is one of: an
     *      address the ORDER's own taker named at lock time, the LP recorded on the offer,
     *      or a seller's own refund address. None is attacker-chosen for someone else's
     *      money, and the amount is always that record's escrowed amount. The detector
     *      cannot see that constraint because the address is read from storage.
     */
    // slither-disable-next-line arbitrary-send-eth
    function _send(address to, uint256 amount) private {
        (bool ok,) = to.call{value: amount}("");
        if (!ok) revert TransferFailed();
    }

    /// @dev Accepts ragequit proceeds from the pool. Bare transfers are otherwise unexpected.
    receive() external payable {}
}
