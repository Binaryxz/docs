// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IAttestorVerifier} from "./IAttestorVerifier.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";

/**
 * @title ReclaimZkTlsVerifier
 * @notice zkTLS proof of a bank transaction (task 2.2), in the Reclaim proof format.
 *
 * ## What a zkTLS proof buys over a signed quorum, precisely
 *
 * AttestorQuorumVerifier asks named parties to swear a payment happened. This verifies that
 * a TLS session with a NAMED BANK ENDPOINT returned a response matching a template, without
 * the witnesses ever seeing the plaintext. The difference that matters is not
 * "cryptography": it is that a witness here cannot invent a payment. It can only refuse to
 * attest, or attest to a session that really occurred with the bank. Collusion buys
 * censorship, not forgery - and that is a strictly smaller power.
 *
 * That sentence is only true if the verifier checks WHICH server the session was with. An
 * earlier version checked `claimInfo.provider` against a stored hash and read the payment
 * out of `context`. In real Reclaim proofs every HTTP claim has provider `"http"`, so the
 * check admitted a session with any server on the internet, and `context` fields other than
 * the witness-written ones are chosen by the prover. Anyone could have a witness observe a
 * session with their own server returning `{"amountBrlCents":"99999999"}` and settle orders
 * without paying. The provider string is not the bank; the endpoint is.
 *
 * What it does NOT buy, and must not be claimed:
 *
 *  - The witnesses still attest that the TLS transcript is authentic. A quorum of malicious
 *    witnesses can sign a claim about a session that never happened. This is why the
 *    witness set, threshold and endpoint allowlist are public, and why adding a witness,
 *    lowering the threshold or allowing an endpoint waits out GOVERNANCE_DELAY: otherwise
 *    a governor could add its own key, set the threshold to one and sign any payment in a
 *    single block, after every LP had opted in to this verifier.
 *  - It proves what the BANK'S RESPONSE SAID, not what the banking system will finally
 *    settle. A PIX reversal days later is invisible here, exactly as it is to a human
 *    reading the same screen.
 *
 * ## The Reclaim format this verifier assumes (checked against attestor-core, Sept 2026)
 *
 * Each assumption below is load-bearing. If Reclaim changes one, this contract must change.
 *
 *  1. `identifier = keccak256(provider + "\n" + parameters + "\n" + context)`, where the
 *     witness canonicalises `context` (RFC 8785: sorted keys, no whitespace) before hashing
 *     (`getIdentifierFromClaimInfo`, src/utils/claims.ts). So a context that verifies here
 *     is byte-for-byte the canonical one the witnesses signed.
 *  2. Witnesses sign `identifier\nowner\ntimestampS\nepoch` with an EIP-191 personal
 *     signature over that string itself - not over its hash (`createSignDataForClaim`;
 *     Reclaim's own Claims.sol `verifySignature`).
 *  3. For an HTTP claim the witness parses `parameters`, opens TLS to the host of
 *     `parameters.url` (after substituting `{{placeholders}}`), and then WRITES two fields
 *     into the context before signing (`assertValidProviderTranscript`,
 *     src/server/utils/assert-valid-claim-request.ts):
 *       - `providerHash = hashProviderParams(params)`: keccak256 of the canonical
 *         {url, method, body, responseMatches, responseRedactions} TEMPLATE, with
 *         placeholders unsubstituted. It overwrites any prover-supplied value.
 *       - `extractedParameters`: the named regex groups `responseMatches` captured from the
 *         bank's RESPONSE. It replaces the prover's object wholesale - but only when the
 *         template extracts at least one group. A template that extracts nothing leaves the
 *         prover's own `extractedParameters` standing, which is why an endpoint may only be
 *         allowlisted if its template captures every field read below.
 *  4. Everything else in `context` (`contextAddress`, `contextMessage`, any extra key) is
 *     chosen by the prover. `contextMessage` is where Reclaim's SDK puts the application's
 *     binding, and it is where the order id lives here.
 *
 * ## What is checked, and why each check exists
 *
 *  - `provider == "http"`: the only provider whose `providerHash` means what (3) says.
 *  - `context.providerHash` is allowlisted: the bank endpoint's whole template - URL,
 *    method, body, extraction regexes, redactions - is one the governor reviewed. A prover
 *    cannot pick a regex that lifts an "amount" out of a free-text memo field.
 *  - `parameters.url` starts with the URL prefix allowlisted for that template, and the
 *    prefix ends at a host boundary (`https://host/`). This restates the host on-chain in
 *    readable form, so an allowlisted hash whose template turned out to point somewhere
 *    else - or to put a placeholder in the host - still fails.
 *  - `context.contextMessage` is the order id: a genuine proof cannot be re-pointed at
 *    another order, because that edit changes the identifier the witnesses signed.
 *  - The payment fields are read only from `context.extractedParameters`, never from a
 *    prover-writable key.
 *  - The extracted `rail` is one the endpoint is allowlisted for. A PIX receipt page and a
 *    boleto receipt page are different templates, and neither should be able to vouch for
 *    the other's rail: a PIX-receipt template whose `rail` capture turned out to match more
 *    than it should would otherwise settle boleto orders. Each endpoint carries a rail mask,
 *    PIX only unless the governor widens it (`setEndpointRails`, delayed).
 *
 * The JSON reader is strict and fails closed: one object per document, every member of an
 * object being searched is scanned so a duplicate key reverts, any backslash in a key or in
 * a value we read reverts (we compare raw bytes, so we refuse bytes whose decoded meaning
 * could differ), and malformed JSON reverts. Real Reclaim documents contain none of those.
 *
 * ## Value formats
 *
 * The extracted fields are expected as `bankTxId`, `payeeKeyHash`, `payerRef` (0x-prefixed
 * 32-byte hex) and `amountBrlCents`, `paidAt`, `rail` (decimal digits). A bank's response
 * does not naturally contain a salted PIX-key commitment, so a production template for a
 * real bank needs Reclaim's hashed redactions or a verifier revision. That is the same
 * "provider template for the bank" gap docs/security-review-phase2.md records; it can fail
 * to settle, it cannot settle wrongly.
 *
 * A boleto payment uses the same six fields: `payeeKeyHash` is the salted commitment to the
 * barcode paid (`boletoCommitment` in packages/ramp/src/boleto.ts), `bankTxId` the payment's
 * authentication code, hashed, and `rail` is 2. The template for a boleto receipt must
 * capture the barcode from the part of the response the bank writes - the paid document -
 * never from a description the payer typed.
 */
contract ReclaimZkTlsVerifier is IAttestorVerifier, DelayedGovernance {
    struct ClaimInfo {
        string provider; // always "http" for a claim this verifier accepts
        string parameters; // canonical JSON: url, method, body, responseMatches, ...
        string context; // canonical JSON: contextMessage, extractedParameters, providerHash
    }

    struct CompleteClaimData {
        bytes32 identifier;
        address owner;
        uint32 timestampS;
        uint32 epoch;
    }

    struct SignedClaim {
        CompleteClaimData claim;
        bytes[] signatures;
    }

    struct Proof {
        ClaimInfo claimInfo;
        SignedClaim signedClaim;
    }

    bytes32 private constant HTTP_PROVIDER = keccak256("http");

    mapping(address => bool) public isWitness;
    uint256 public witnessCount;
    uint256 public threshold;

    /// @notice Allowlisted bank endpoints: Reclaim `providerHash` => required URL prefix.
    /// @dev An empty prefix means "not allowed". The prefix is validated on entry to end at
    ///      a host boundary, so `https://bank.com` can never be allowlisted and accidentally
    ///      match `https://bank.com.evil.io`, or the same host followed by an at-sign and
    ///      `evil.io` (userinfo, which makes evil.io the host).
    mapping(bytes32 => string) public endpointUrlPrefix;
    uint256 public endpointCount;

    /// @notice The rails each allowlisted endpoint may attest, as a bitmask over Rail.
    /// @dev Set to PIX alone when an endpoint is first allowed - every template allowlisted
    ///      before boletos existed was a PIX receipt - and deleted with the endpoint.
    mapping(bytes32 => uint16) public endpointRails;

    uint16 private constant PIX_ONLY = uint16(1 << uint8(Rail.PIX));

    event WitnessSet(address indexed witness, bool active);
    event ThresholdSet(uint256 threshold);
    event EndpointAllowed(bytes32 indexed providerHash, string urlPrefix);
    event EndpointRevoked(bytes32 indexed providerHash);
    event EndpointRailsSet(bytes32 indexed providerHash, uint16 railMask);

    error BadThreshold();
    error NotEnoughSignatures(uint256 got, uint256 need);
    error SignaturesUnsorted();
    error UnknownWitness(address signer);
    error MalformedProof();
    error IdentifierMismatch();
    error ProviderNotAllowed();
    error EndpointNotAllowed(bytes32 providerHash);
    error UrlNotAllowed();
    error BadUrlPrefix();
    error NoEndpoints();
    error OrderMismatch();
    error RailNotAllowedForEndpoint(bytes32 providerHash, uint8 rail);
    error BadRailMask();
    error MalformedJson();
    error MissingField(string key);
    error DuplicateKey(string key);
    error EscapedKey();
    error EscapedValue(string key);
    error BadNumber(string key);

    /// @param providerHashes Reclaim `providerHash` of each allowed bank endpoint template.
    /// @param urlPrefixes    The URL prefix each template's `url` must start with.
    /// @dev Refuses to deploy with no endpoints. A verifier with nothing allowlisted settles
    ///      nothing, which is safe - but the version this replaces shipped with a default
    ///      ("http") that allowlisted everything, and "configure it later" is how a default
    ///      goes live.
    constructor(
        address governor_,
        uint256 governanceDelay,
        address[] memory witnesses,
        uint256 threshold_,
        bytes32[] memory providerHashes,
        string[] memory urlPrefixes
    ) DelayedGovernance(governor_, governanceDelay) {
        for (uint256 i; i < witnesses.length; ++i) {
            if (witnesses[i] == address(0)) revert ZeroAddress();
            if (!isWitness[witnesses[i]]) {
                isWitness[witnesses[i]] = true;
                ++witnessCount;
                emit WitnessSet(witnesses[i], true);
            }
        }
        _setThreshold(threshold_);
        if (providerHashes.length == 0 || providerHashes.length != urlPrefixes.length) {
            revert NoEndpoints();
        }
        for (uint256 i; i < providerHashes.length; ++i) {
            _allowEndpoint(providerHashes[i], urlPrefixes[i]);
        }
    }

    function attestorKind() external pure returns (string memory) {
        return "zktls/reclaim/pix-boleto-v3";
    }

    /// @inheritdoc IAttestorVerifier
    /// @dev True: the payment is read from a TLS session with an allowlisted bank endpoint, so
    ///      witnesses can refuse to attest but cannot invent a payment (see the header).
    function provesBankSession() external pure returns (bool) {
        return true;
    }

    /*//////////////////////////////////////////////////////////////
                              VERIFICATION
    //////////////////////////////////////////////////////////////*/

    function verifyPayment(bytes32 orderId, bytes calldata proofBytes)
        external
        view
        returns (Payment memory p)
    {
        _requireSetupComplete();
        Proof memory proof = abi.decode(proofBytes, (Proof));

        if (keccak256(bytes(proof.claimInfo.provider)) != HTTP_PROVIDER) {
            revert ProviderNotAllowed();
        }

        // 1. The claim must be the one the witnesses signed, byte for byte.
        bytes32 recomputed = keccak256(
            abi.encodePacked(
                proof.claimInfo.provider, "\n", proof.claimInfo.parameters, "\n",
                proof.claimInfo.context
            )
        );
        if (recomputed != proof.signedClaim.claim.identifier) revert IdentifierMismatch();

        // 2. A quorum of known witnesses signed it.
        _checkWitnesses(proof.signedClaim);

        // One pass over the context's top level finds every key we read, and refuses a
        // duplicate of any of them.
        bytes memory ctx = bytes(proof.claimInfo.context);
        string[] memory keys = new string[](3);
        keys[0] = "contextMessage";
        keys[1] = "extractedParameters";
        keys[2] = "providerHash";
        uint256[] memory at = _document(ctx, keys);

        // 3. The session was with an allowlisted bank endpoint.
        bytes32 providerHash = _hex32(ctx, at[2], keys[2]);
        _checkEndpoint(providerHash, bytes(proof.claimInfo.parameters));

        // 4. The prover's binding: which order this payment settles.
        if (_hex32(ctx, at[0], keys[0]) != orderId) revert OrderMismatch();

        // 5. What the witness extracted from the bank's response, and nothing else.
        if (_u8(ctx, at[1]) != OPEN_OBJECT) revert MissingField(keys[1]);
        p = _readPayment(ctx, at[1]);

        // 6. On a rail this endpoint is allowed to attest.
        if ((uint256(endpointRails[providerHash]) >> uint8(p.rail)) & 1 == 0) {
            revert RailNotAllowedForEndpoint(providerHash, uint8(p.rail));
        }
    }

    function _checkEndpoint(bytes32 providerHash, bytes memory params) private view {
        bytes memory prefix = bytes(endpointUrlPrefix[providerHash]);
        if (prefix.length == 0) revert EndpointNotAllowed(providerHash);

        string[] memory keys = new string[](1);
        keys[0] = "url";
        (uint256 start, uint256 end) = _string(params, _document(params, keys)[0], keys[0]);
        if (end - start < prefix.length) revert UrlNotAllowed();
        if (_hashSlice(params, start, start + prefix.length) != keccak256(prefix)) {
            revert UrlNotAllowed();
        }
    }

    function _readPayment(bytes memory ctx, uint256 ext) private pure returns (Payment memory p) {
        string[] memory keys = new string[](6);
        keys[0] = "amountBrlCents";
        keys[1] = "bankTxId";
        keys[2] = "paidAt";
        keys[3] = "payeeKeyHash";
        keys[4] = "payerRef";
        keys[5] = "rail";
        (uint256[] memory at,) = _scan(ctx, ext, keys);
        for (uint256 i; i < keys.length; ++i) {
            if (at[i] == 0) revert MissingField(keys[i]);
        }
        p.amountBrlCents = _number(ctx, at[0], keys[0]);
        p.bankTxId = _hex32(ctx, at[1], keys[1]);
        p.paidAt = uint64(_number(ctx, at[2], keys[2]));
        p.payeeKeyHash = _hex32(ctx, at[3], keys[3]);
        p.payerRef = _hex32(ctx, at[4], keys[4]);
        uint256 rail = _number(ctx, at[5], keys[5]);
        if (rail > uint256(type(uint8).max)) revert BadNumber(keys[5]);
        p.rail = Rail(uint8(rail));
    }

    function _checkWitnesses(SignedClaim memory sc) private view {
        if (sc.signatures.length < threshold) {
            revert NotEnoughSignatures(sc.signatures.length, threshold);
        }
        bytes memory message = _serialise(sc.claim);
        bytes32 digest = keccak256(
            abi.encodePacked("\x19Ethereum Signed Message:\n", _dec(message.length), message)
        );
        // Zero start is intentional: signers must ascend strictly, and ecrecover returning
        // zero is already rejected as MalformedProof.
        address last = address(0);
        for (uint256 i; i < sc.signatures.length; ++i) {
            address signer = _recover(digest, sc.signatures[i]);
            if (!isWitness[signer]) revert UnknownWitness(signer);
            // Strictly ascending: duplicates are how an M-of-N check becomes 1-of-N.
            if (signer <= last) revert SignaturesUnsorted();
            last = signer;
        }
    }

    /// @notice Reclaim's canonical claim encoding: identifier\nowner\ntimestamp\nepoch.
    function _serialise(CompleteClaimData memory c) private pure returns (bytes memory) {
        return abi.encodePacked(
            _hex32str(c.identifier), "\n", _hexAddr(c.owner), "\n", _dec(uint256(c.timestampS)),
            "\n", _dec(uint256(c.epoch))
        );
    }

    /*//////////////////////////////////////////////////////////////
                           STRICT JSON READING
    //////////////////////////////////////////////////////////////*/

    uint8 private constant QUOTE = 0x22; // "
    uint8 private constant COMMA = 0x2c; // ,
    uint8 private constant COLON = 0x3a; // :
    uint8 private constant OPEN_ARRAY = 0x5b; // [
    uint8 private constant CLOSE_ARRAY = 0x5d; // ]
    uint8 private constant OPEN_OBJECT = 0x7b; // {
    uint8 private constant CLOSE_OBJECT = 0x7d; // }

    /**
     * @dev The value start of each of `keys` in a document that must be exactly one
     *      well-formed object with nothing but whitespace around it. Every key is required.
     *
     *      A deliberately unclever reader. Permissive parsing of a document an attacker
     *      partly controls is how field-confusion bugs happen: the witness parses with
     *      JSON.parse, and every place this reader could disagree with JSON.parse - a
     *      duplicate key (last wins there), an escaped key (an escaped `u` in "url" IS `url`
     *      there), a nested key of the same name, whitespace between tokens - must revert
     *      or be read the way JSON.parse reads it, never guessed at.
     */
    function _document(bytes memory j, string[] memory keys)
        private
        pure
        returns (uint256[] memory at)
    {
        uint256 end;
        (at, end) = _scan(j, _ws(j, 0), keys);
        if (_ws(j, end) != j.length) revert MalformedJson();
        for (uint256 i; i < keys.length; ++i) {
            if (at[i] == 0) revert MissingField(keys[i]);
        }
    }

    /**
     * @dev One pass over the object at `obj`: where each wanted key's value starts (0 when
     *      absent - no value can start at index 0), and the index just past the closing
     *      brace. Every member is scanned, so a second copy of a wanted key reverts rather
     *      than one copy silently winning, and any escaped key reverts because raw bytes
     *      cannot be compared with what it decodes to.
     */
    function _scan(bytes memory j, uint256 obj, string[] memory keys)
        private
        pure
        returns (uint256[] memory at, uint256 end)
    {
        bytes32[] memory wanted = new bytes32[](keys.length);
        for (uint256 x; x < keys.length; ++x) {
            wanted[x] = keccak256(bytes(keys[x]));
        }
        at = new uint256[](keys.length);

        if (_u8(j, obj) != OPEN_OBJECT) revert MalformedJson();
        uint256 i = _ws(j, obj + 1);
        if (_u8(j, i) == CLOSE_OBJECT) return (at, i + 1);
        while (true) {
            if (_u8(j, i) != QUOTE) revert MalformedJson();
            (uint256 keyEnd, bool escaped) = _stringEnd(j, i);
            if (escaped) revert EscapedKey();
            bytes32 key = _hashSlice(j, i + 1, keyEnd);
            i = _ws(j, keyEnd + 1);
            if (_u8(j, i) != COLON) revert MalformedJson();
            uint256 valueStart = _ws(j, i + 1);
            for (uint256 x; x < keys.length; ++x) {
                if (key != wanted[x]) continue;
                if (at[x] != 0) revert DuplicateKey(keys[x]);
                at[x] = valueStart;
            }
            i = _ws(j, _skipValue(j, valueStart));
            uint8 c = _u8(j, i);
            if (c == CLOSE_OBJECT) return (at, i + 1);
            if (c != COMMA) revert MalformedJson();
            i = _ws(j, i + 1);
        }
    }

    /// @dev The raw content of the string value at `v`, between its quotes. No escapes.
    function _string(bytes memory j, uint256 v, string memory key)
        private
        pure
        returns (uint256 start, uint256 end)
    {
        if (_u8(j, v) != QUOTE) revert MissingField(key);
        (uint256 close, bool escaped) = _stringEnd(j, v);
        if (escaped) revert EscapedValue(key);
        return (v + 1, close);
    }

    /// @dev `"0x<64 hex>"` as bytes32.
    function _hex32(bytes memory j, uint256 v, string memory key) private pure returns (bytes32) {
        (uint256 s, uint256 e) = _string(j, v, key);
        if (e - s != 66 || _u8(j, s) != 0x30 || _u8(j, s + 1) != 0x78) revert BadNumber(key);
        uint256 out = 0;
        for (uint256 i = s + 2; i < e; ++i) {
            out = (out << 4) | _nibble(_u8(j, i));
        }
        return bytes32(out);
    }

    /// @dev `"123"` as a number. Digits only; no signs, no decimals, no spaces.
    function _number(bytes memory j, uint256 v, string memory key)
        private
        pure
        returns (uint256 out)
    {
        (uint256 s, uint256 e) = _string(j, v, key);
        if (e == s || e - s > 30) revert BadNumber(key);
        for (uint256 i = s; i < e; ++i) {
            uint8 c = _u8(j, i);
            if (c < 0x30 || c > 0x39) revert BadNumber(key);
            out = out * 10 + (c - 0x30);
        }
    }

    function _skipValue(bytes memory j, uint256 i) private pure returns (uint256) {
        uint8 c = _u8(j, i);
        if (c == QUOTE) {
            (uint256 close,) = _stringEnd(j, i);
            return close + 1;
        }
        if (c == OPEN_OBJECT) {
            (, uint256 end) = _scan(j, i, new string[](0));
            return end;
        }
        if (c == OPEN_ARRAY) return _skipArray(j, i);
        return _skipLiteral(j, i);
    }

    function _skipArray(bytes memory j, uint256 i) private pure returns (uint256 end) {
        i = _ws(j, i + 1);
        if (_u8(j, i) == CLOSE_ARRAY) return i + 1;
        while (true) {
            i = _ws(j, _skipValue(j, i));
            uint8 c = _u8(j, i);
            if (c == CLOSE_ARRAY) return i + 1;
            if (c != COMMA) revert MalformedJson();
            i = _ws(j, i + 1);
        }
    }

    /*
     * The byte-level primitives below are assembly because they run once per byte of every
     * document, and bounds-checked Solidity indexing made a ~1.7KB proof cost ~1.8M gas to
     * verify. Each reads only below `mload(j)`, the byte length.
     */

    /// @dev Byte at `i`, or 0 past the end - which matches no JSON token, so a truncated
    ///      document reverts at whichever check reads past it.
    function _u8(bytes memory j, uint256 i) private pure returns (uint8 c) {
        assembly {
            if lt(i, mload(j)) { c := byte(0, mload(add(add(j, 32), i))) }
        }
    }

    function _ws(bytes memory j, uint256 i) private pure returns (uint256 k) {
        assembly {
            let len := mload(j)
            let data := add(j, 32)
            for { k := i } lt(k, len) { k := add(k, 1) } {
                let c := byte(0, mload(add(data, k)))
                if iszero(or(or(eq(c, 0x20), eq(c, 0x09)), or(eq(c, 0x0a), eq(c, 0x0d)))) {
                    break
                }
            }
        }
    }

    /// @dev Index of the closing quote of the string opening at `i`, and whether it held any
    ///      escape. Raw control characters are not JSON and revert.
    function _stringEnd(bytes memory j, uint256 i)
        private
        pure
        returns (uint256 close, bool escaped)
    {
        uint256 status; // 1 = closed, anything else = malformed
        assembly {
            let len := mload(j)
            let data := add(j, 32)
            let k := add(i, 1)
            for {} lt(k, len) { k := add(k, 1) } {
                let c := byte(0, mload(add(data, k)))
                if eq(c, 0x5c) {
                    escaped := 1
                    k := add(k, 1)
                    continue
                }
                if eq(c, 0x22) {
                    status := 1
                    break
                }
                if lt(c, 0x20) {
                    status := 2
                    break
                }
            }
            close := k
        }
        if (status != 1) revert MalformedJson();
    }

    /// @dev A number, true, false or null: a run of characters up to a delimiter. Its value
    ///      is never read, so its grammar is not checked beyond not containing structure.
    function _skipLiteral(bytes memory j, uint256 i) private pure returns (uint256 k) {
        uint256 bad;
        assembly {
            let len := mload(j)
            let data := add(j, 32)
            for { k := i } lt(k, len) { k := add(k, 1) } {
                let c := byte(0, mload(add(data, k)))
                if or(
                    or(eq(c, 0x2c), or(eq(c, 0x7d), eq(c, 0x5d))),
                    or(or(eq(c, 0x20), eq(c, 0x09)), or(eq(c, 0x0a), eq(c, 0x0d)))
                ) { break }
                if or(or(eq(c, 0x22), eq(c, 0x3a)), or(eq(c, 0x7b), eq(c, 0x5b))) {
                    bad := 1
                    break
                }
            }
        }
        if (bad == 1 || k == i) revert MalformedJson();
    }

    /// @dev keccak256 of j[s:e]. Callers guarantee s <= e <= j.length.
    function _hashSlice(bytes memory j, uint256 s, uint256 e) private pure returns (bytes32 h) {
        assembly {
            h := keccak256(add(add(j, 32), s), sub(e, s))
        }
    }

    /*//////////////////////////////////////////////////////////////
                              GOVERNANCE
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Adding a witness waits out the governance delay; removing one is instant.
     * @dev Reclaim rotates witnesses by epoch, so schedule the new set as soon as an epoch is
     *      announced. Removal does not lower the threshold: see AttestorQuorumVerifier.
     *      setAttestor for why an automatic lowering was a delay-free path to 1-of-1.
     */
    function setWitness(address witness, bool active) external {
        _authorizeChange(active && !isWitness[witness]);
        if (witness == address(0)) revert ZeroAddress();
        if (isWitness[witness] == active) return;
        isWitness[witness] = active;
        if (active) ++witnessCount;
        else --witnessCount;
        emit WitnessSet(witness, active);
    }

    /// @notice Lowering the threshold waits out the governance delay; raising it is instant.
    function setThreshold(uint256 t) external {
        _authorizeChange(t < threshold);
        _setThreshold(t);
    }

    /// @notice Allow a bank endpoint: the template's Reclaim `providerHash` and the URL
    ///         prefix its `url` must start with.
    /// @dev Before allowing a template, check that its `responseMatches` capture EVERY field
    ///      `_readPayment` reads, from parts of the response the payer cannot write. See
    ///      assumption (3) in the header: a template that extracts nothing leaves the
    ///      prover's own `extractedParameters` in place.
    ///      Allowing an endpoint, or changing an allowed endpoint's prefix, is delayed.
    function allowEndpoint(bytes32 providerHash, string calldata urlPrefix) external {
        _authorizeChange(
            keccak256(bytes(endpointUrlPrefix[providerHash])) != keccak256(bytes(urlPrefix))
        );
        _allowEndpoint(providerHash, urlPrefix);
    }

    /// @notice Revoking an endpoint is instant.
    function revokeEndpoint(bytes32 providerHash) external {
        _authorizeChange(false);
        if (bytes(endpointUrlPrefix[providerHash]).length == 0) return;
        delete endpointUrlPrefix[providerHash];
        delete endpointRails[providerHash];
        --endpointCount;
        emit EndpointRevoked(providerHash);
    }

    /**
     * @notice Set which rails an allowlisted endpoint may attest, as a bitmask over Rail.
     * @dev Adding a rail waits out the governance delay: it lets a template vouch for a kind of
     *      payment it could not before, which is the same power as allowing an endpoint.
     *      Removing rails is instant. Before adding BOLETO, check the template captures the
     *      paid barcode and the amount from the bank-written receipt, and that its `rail`
     *      capture cannot match a PIX receipt. To remove every rail, revoke the endpoint.
     */
    function setEndpointRails(bytes32 providerHash, uint16 railMask) external {
        uint16 current = endpointRails[providerHash];
        _authorizeChange(railMask & ~current != 0);
        if (bytes(endpointUrlPrefix[providerHash]).length == 0) {
            revert EndpointNotAllowed(providerHash);
        }
        // Bit 0 is UNSPECIFIED, which no escrow settles; an empty mask is a revocation.
        if (railMask == 0 || railMask & 1 != 0) revert BadRailMask();
        endpointRails[providerHash] = railMask;
        emit EndpointRailsSet(providerHash, railMask);
    }

    function _isDelayable(bytes4 selector) internal pure override returns (bool) {
        return selector == ReclaimZkTlsVerifier.setWitness.selector
            || selector == ReclaimZkTlsVerifier.setThreshold.selector
            || selector == ReclaimZkTlsVerifier.allowEndpoint.selector
            || selector == ReclaimZkTlsVerifier.setEndpointRails.selector;
    }

    function _setThreshold(uint256 t) private {
        if (t == 0 || t > witnessCount) revert BadThreshold();
        threshold = t;
        emit ThresholdSet(t);
    }

    function _allowEndpoint(bytes32 providerHash, string memory urlPrefix) private {
        if (providerHash == bytes32(0)) revert BadUrlPrefix();
        _validatePrefix(bytes(urlPrefix));
        if (bytes(endpointUrlPrefix[providerHash]).length == 0) {
            ++endpointCount;
            endpointRails[providerHash] = PIX_ONLY;
            emit EndpointRailsSet(providerHash, PIX_ONLY);
        }
        endpointUrlPrefix[providerHash] = urlPrefix;
        emit EndpointAllowed(providerHash, urlPrefix);
    }

    /**
     * @dev A prefix must be `https://` + a lowercase host (optionally `:port`) + `/` + an
     *      optional path of unreserved characters.
     *
     *      The trailing `/` after the host is the whole point. The witness finds the host
     *      with WHATWG URL parsing, which ends the authority at the first `/`. Without it,
     *      `https://bank.com` would match `https://bank.com.evil.io/`, or the same host
     *      followed by userinfo (an at-sign, then `evil.io/`). Characters that change how a
     *      URL parses - the at-sign, backslash, `?`, `#`, `%`, `{` - are refused anywhere in
     *      the prefix, so nothing the prover appends after it can move the host.
     */
    function _validatePrefix(bytes memory p) private pure {
        bytes memory scheme = "https://";
        if (p.length <= scheme.length + 1) revert BadUrlPrefix();
        for (uint256 k; k < scheme.length; ++k) {
            if (p[k] != scheme[k]) revert BadUrlPrefix();
        }
        uint256 i = scheme.length;
        uint256 hostStart = i;
        while (i < p.length && p[i] != "/") {
            bytes1 c = p[i];
            bool ok = (c >= "a" && c <= "z") || (c >= "0" && c <= "9") || c == "." || c == "-"
                || c == ":";
            if (!ok) revert BadUrlPrefix();
            ++i;
        }
        if (i == hostStart || i == p.length) revert BadUrlPrefix(); // no host, or no "/"
        for (; i < p.length; ++i) {
            bytes1 c = p[i];
            bool ok = (c >= "a" && c <= "z") || (c >= "A" && c <= "Z") || (c >= "0" && c <= "9")
                || c == "/" || c == "." || c == "-" || c == "_" || c == "~";
            if (!ok) revert BadUrlPrefix();
        }
    }

    /*//////////////////////////////////////////////////////////////
                                 UTIL
    //////////////////////////////////////////////////////////////*/

    function _recover(bytes32 digest, bytes memory sig) private pure returns (address) {
        if (sig.length != 65) revert MalformedProof();
        bytes32 r;
        bytes32 s;
        uint8 v;
        assembly {
            r := mload(add(sig, 32))
            s := mload(add(sig, 64))
            v := byte(0, mload(add(sig, 96)))
        }
        if (uint256(s) > 0x7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5D576E7357A4501DDFE92F46681B20A0) {
            revert MalformedProof();
        }
        address signer = ecrecover(digest, v, r, s);
        if (signer == address(0)) revert MalformedProof();
        return signer;
    }

    function _nibble(uint8 c) private pure returns (uint256) {
        if (c >= 0x30 && c <= 0x39) return c - 0x30;
        if (c >= 0x61 && c <= 0x66) return c - 0x57; // a-f
        if (c >= 0x41 && c <= 0x46) return c - 0x37; // A-F
        revert MalformedProof();
    }

    bytes16 private constant HEX = "0123456789abcdef";

    function _hex32str(bytes32 v) private pure returns (string memory) {
        bytes memory out = new bytes(66);
        out[0] = "0";
        out[1] = "x";
        for (uint256 i; i < 32; ++i) {
            out[2 + i * 2] = HEX[uint8(v[i]) >> 4];
            out[3 + i * 2] = HEX[uint8(v[i]) & 0x0f];
        }
        return string(out);
    }

    function _hexAddr(address a) private pure returns (string memory) {
        bytes20 b = bytes20(a);
        bytes memory out = new bytes(42);
        out[0] = "0";
        out[1] = "x";
        for (uint256 i; i < 20; ++i) {
            out[2 + i * 2] = HEX[uint8(b[i]) >> 4];
            out[3 + i * 2] = HEX[uint8(b[i]) & 0x0f];
        }
        return string(out);
    }

    function _dec(uint256 v) private pure returns (string memory) {
        if (v == 0) return "0";
        uint256 n = v;
        uint256 len;
        while (n != 0) {
            ++len;
            n /= 10;
        }
        bytes memory out = new bytes(len);
        while (v != 0) {
            out[--len] = bytes1(uint8(48 + (v % 10)));
            v /= 10;
        }
        return string(out);
    }
}
