// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IPriceSource, IDivergenceBreaker} from "./IPriceSource.sol";

/**
 * @title DivergenceBreaker
 * @notice A self-clearing, keyless circuit breaker for MovvaReserve (client decision, 24 Sep 2026,
 *         "Breaker": it pauses automatically when prices diverge and resumes when they return to
 *         band; no key needed; if BRL liquidity is thin it pauses, it does not substitute a source).
 *
 * ## What it is
 *
 * Immutable and ownerless: no owner, no setter, no state that changes after the constructor. Every
 * call is a pure function of the sources' CURRENT answers, so there is nothing to latch and nothing
 * to lift. The moment the sources agree again `check` stops reverting.
 *
 * It compares the reserve's own rate (Chainlink USDT/USD x Pyth FX.USD/BRL, passed in by the
 * reserve) with N further `IPriceSource`s. Among the reserve's rate and every source flagged
 * `trips`, the spread must satisfy `max - min <= min x BAND_BPS / 10_000`. A tripping source that
 * reverts, is stale, or is too thin counts as DISAGREEING: the breaker halts, it never drops the
 * source and carries on (that would let an attacker who can knock a source out choose the set that
 * is compared). A source with `trips` false is informational only (`sourceRates`, for the monitor).
 *
 * ## The cost: a denial-of-service lever
 *
 * A tripping source is a switch for the halt. A thin-liquidity Uniswap TWAP can be moved by anyone
 * with capital for the window it averages over, so whoever can move it can stop mint and redeem for
 * as long as they pay to hold it there. That is what the client asked for and what this implements;
 * the band and which sources trip are deploy-time constants so it can be tuned (wide band, deep pool,
 * long window) or the TWAP made non-tripping. docs/movva.md, "The divergence breaker", sets out the
 * median-of-three alternative (strong feeds trip the halt, the TWAP only moves a median).
 */
contract DivergenceBreaker is IDivergenceBreaker {
    struct SourceConfig {
        IPriceSource source;
        bool trips;
    }

    uint16 public constant BPS = 10_000;
    uint256 public constant MAX_SOURCES = 8;

    /// @notice Widest allowed disagreement among the compared rates, in basis points of the lowest.
    uint16 public immutable BAND_BPS;
    /// @notice Whether the breaker also stops `redeem`. True follows the client; false keeps exits open.
    bool public immutable HALTS_REDEEM;

    IPriceSource[] internal _sources;
    bool[] internal _trips;

    error BadBand();
    error BadSources();
    error SourceUnavailable(uint256 index);
    error SourcesDiverge(uint256 low, uint256 high, uint256 bandBps);

    constructor(uint16 bandBps, bool haltsRedeem, SourceConfig[] memory cfg) {
        if (bandBps == 0 || bandBps >= BPS) revert BadBand();
        if (cfg.length == 0 || cfg.length > MAX_SOURCES) revert BadSources();
        BAND_BPS = bandBps;
        HALTS_REDEEM = haltsRedeem;
        for (uint256 i; i < cfg.length; ++i) {
            if (address(cfg[i].source) == address(0)) revert BadSources();
            _sources.push(cfg[i].source);
            _trips.push(cfg[i].trips);
        }
    }

    function sourceCount() external view returns (uint256) {
        return _sources.length;
    }

    function sourceAt(uint256 i) external view returns (IPriceSource source, bool trips) {
        return (_sources[i], _trips[i]);
    }

    /// @inheritdoc IDivergenceBreaker
    function check(uint256 primaryRateE18) public view {
        (bool ok, uint256 low, uint256 high, uint256 bad) = _evaluate(primaryRateE18);
        if (bad != type(uint256).max) revert SourceUnavailable(bad);
        if (!ok) revert SourcesDiverge(low, high, BAND_BPS);
    }

    /// @inheritdoc IDivergenceBreaker
    function checkRedeem(uint256 primaryRateE18) external view {
        if (HALTS_REDEEM) check(primaryRateE18);
    }

    /// @inheritdoc IDivergenceBreaker
    function inBand(uint256 primaryRateE18) external view returns (bool) {
        (bool ok,,, uint256 bad) = _evaluate(primaryRateE18);
        return ok && bad == type(uint256).max;
    }

    /// @notice Every source's current answer, for the monitor: 0 where a source reverts.
    function sourceRates() external view returns (uint256[] memory rates) {
        rates = new uint256[](_sources.length);
        for (uint256 i; i < rates.length; ++i) {
            (bool ok, uint256 r) = _read(_sources[i]);
            rates[i] = ok ? r : 0;
        }
    }

    function _evaluate(uint256 primary)
        internal
        view
        returns (bool ok, uint256 low, uint256 high, uint256 bad)
    {
        bad = type(uint256).max;
        low = primary;
        high = primary;
        uint256 n = _sources.length;
        for (uint256 i; i < n; ++i) {
            if (!_trips[i]) continue;
            (bool good, uint256 r) = _read(_sources[i]);
            if (!good || r == 0) {
                if (bad == type(uint256).max) bad = i;
                continue;
            }
            if (r < low) low = r;
            if (r > high) high = r;
        }
        ok = low != 0 && (high - low) * BPS <= low * BAND_BPS;
    }

    function _read(IPriceSource s) internal view returns (bool ok, uint256 rate) {
        (bool success, bytes memory ret) = address(s).staticcall(abi.encodeCall(IPriceSource.brlPerUsdtE18, ()));
        if (!success || ret.length != 32) return (false, 0);
        return (true, abi.decode(ret, (uint256)));
    }
}
