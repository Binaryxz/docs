// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/**
 * @title IPriceSource
 * @notice One independent reading of reais per whole USDT, for the DivergenceBreaker to compare
 *         with the reserve's own rate. Never a substitute for it: a source that cannot answer is
 *         read as DISAGREEING (the breaker halts), not as absent.
 */
interface IPriceSource {
    /// @notice Reais per ONE whole USDT, scaled 1e18. MUST revert if there is no fresh, deep-enough
    ///         reading. Returning a stale or zero rate silently is the failure this interface prevents.
    function brlPerUsdtE18() external view returns (uint256 rate);
}

/// @notice What MovvaReserve asks of the breaker: revert if the sources disagree. Pure view logic.
interface IDivergenceBreaker {
    /// @notice Reverts while the sources disagree beyond the band (mint-side and hedge flows).
    function check(uint256 primaryRateE18) external view;
    /// @notice As `check`, but a no-op when this breaker was deployed not to halt redemptions.
    function checkRedeem(uint256 primaryRateE18) external view;
    /// @notice True while the sources are in band (or a source with `trips` false is not).
    function inBand(uint256 primaryRateE18) external view returns (bool);
}
