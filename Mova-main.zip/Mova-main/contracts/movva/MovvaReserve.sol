// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {IERC4626} from "@openzeppelin/contracts/interfaces/IERC4626.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {Math} from "@openzeppelin/contracts/utils/math/Math.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {IMovvaReserve} from "./IMovvaReserve.sol";
import {Movva} from "./Movva.sol";
import {IPriceOracle} from "../ramp/IPriceOracle.sol";
import {BandRead} from "../ramp/IBandPriceOracle.sol";
import {IAggregatorV3} from "../ramp/ChainlinkBrlOracle.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";
import {IssuerFreeze} from "../common/IssuerFreeze.sol";
import {IDivergenceBreaker} from "./IPriceSource.sol";

/**
 * @title MovvaReserve
 * @notice The USDT reserve behind Movva, the backstop rules around it, and Movva's band oracle on
 *         the ramps. Design: docs/movva.md. Threat model: docs/security-review-movva.md.
 *
 * ## What it holds, and how it counts
 *
 * USDT, idle and in one ERC-4626 `YieldVault(USDT)`. Liabilities are every Movva in circulation
 * (1e18 = R$ 1,00), wherever it sits: wallets, Privacy Pools, escrows. The rate is
 * Chainlink USDT/USD times a BRL/USD rate - Pyth's FX.USD/BRL through PythFxOracle, or a signed
 * quorum's (`brlPerUsdtE18`) - and
 *
 *     collateralRatioBps = totalUsdt x rate / totalSupply
 *
 * is computed on every call, from state and fresh oracle legs, never cached. Every division rounds
 * against the reserve: the vault position at `previewRedeem` (what an exit would actually pay),
 * reais rounded down, the ratio rounded down, liabilities never discounted. Idle USDT counts as
 * zero while Tether has frozen the reserve, because it cannot be paid to anyone - see "Freezes".
 *
 * ## The rules (docs/movva.md, "The backstop, on-chain")
 *
 *  - **Mint** (gateways only): USDT in, Movva out at the rate, less `mintFeeBps` (minted to the fee
 *    recipient), only while the ratio is at least `minMintCollateralRatioBps`, within `supplyCap`.
 *    Movva is minted for the USDT value the reserve actually booked after depositing it - so a
 *    vault's rounding is charged to the minter, not to holders.
 *  - **Redeem** (gateways only): Movva in, USDT out worth `min(1, ratio)` of it, less `redeemFeeBps`
 *    (kept as Movva by the fee recipient). Under-backed, that is exactly the redeemer's pro-rata
 *    share of the reserve, whatever the rate says: a run pays everybody the same fraction.
 *  - **withdrawToHedge** (treasurer only): USDT to the fixed `hedgeTreasury`, only if the ratio
 *    AFTER stays at least `minWithdrawCollateralRatioBps`, within a rate limit of `hedgeLimitBps` of
 *    the reserve that refills continuously over 24 hours.
 *  - **recapitalize** (anyone): USDT in, nothing out.
 *
 *  - **queueHedgeWithdrawal / executeHedgeWithdrawal** (treasurer announces, ANYONE executes): a hedge withdrawal
 *    ABOVE the daily limit waits `HEDGE_QUEUE_DELAY`, then pays exactly the queued USDT to exactly the hedge treasury
 *    of record, once. Nobody can cancel, approve or reorder it (client decision, 24 Sep 2026: a timelock, not a
 *    multisig). The ratio floor and the breaker are checked again at execution.
 *
 * There is no distribution of the surplus. What the reserve earns above its liabilities (the yield
 * vault's income, hedge gains brought back by `recapitalize`) stays in the reserve as backing; it is
 * Mova's, reached only through the hedge path above, and no holder is paid a yield (client decision
 * D1, 14 October 2026: savings and sMovva are not part of the product).
 *
 * ## The divergence breaker (client decision, 24 September 2026)
 *
 * `BREAKER` (immutable, optional) is a keyless, ownerless DivergenceBreaker. While the rate above disagrees with its
 * independent sources beyond a deploy-time band - or a source reverts, is stale or too thin - `mint`, `redeem`,
 * `withdrawToHedge` and `executeHedgeWithdrawal` revert. It is recomputed on every call and clears by
 * itself when the sources agree; no function lifts it and no role can trip it. `recapitalize`, the previews and the
 * ramps' band reading are not halted. This AMENDS "nobody can pause redemptions" above: that rule keeps a KEY from
 * freezing exits, and the breaker is not a key; the breaker's `HALTS_REDEEM` immutable can leave redemptions open.
 * The cost, a manipulable TWAP as a halt switch, is in docs/movva.md ("The divergence breaker").
 *
 * Slippage bounds on mint and redeem protect a gateway from a rate that moves between signing and
 * inclusion. Fees are zero at deployment, with hard caps no governance can pass.
 *
 * ## What no role can do
 *
 * USDT leaves this contract to exactly three places: a redeeming gateway's chosen recipient, the
 * yield vault (governor-chosen, delayed), and - within the rules above - the hedge treasury
 * (governor-chosen, delayed). There is no sweep, no rescue and no arbitrary transfer. Movva is minted
 * only by `mint` (to the gateway's recipient, and its fee to the fee recipient), and burned only by
 * `redeem`, from the reserve's own balance.
 *
 * ## Governance (DelayedGovernance)
 *
 * Delayed, because each one adds risk: adding a gateway; raising the supply cap, the hedge limit
 * or any fee; LOWERING any collateral ratio (a floor protects by being high); changing the
 * treasurer, the hedge treasury, the fee recipient, an oracle leg, a max age upward, or the yield
 * vault.
 *
 * Instant, because each one removes risk: removing a gateway; lowering a cap, limit or fee; raising a
 * ratio; tightening a max age; revoking the treasurer (setting it to zero); pausing mint (the
 * guardian may too - it is the guardian's only power); pulling USDT out of the yield vault into the
 * reserve, and pausing deposits into it; rotating the guardian.
 *
 * Resuming mint is instant and governor-only, as resuming deposits is on `YieldVault`: it moves no
 * value, and the rules above still apply to every mint. The guardian cannot pause redemptions; nobody
 * can. A frozen exit is how a reserve turns a scare into a run.
 *
 * ## Oracle
 *
 * The two legs are read exactly as `ChainlinkSignedFxOracle` reads them - each against its own max
 * age (USDT/USD about a day, since the feed's heartbeat is a day; FX about an hour), zero and
 * negative answers refused, timestamps from the future refused - and a stale leg reverts every
 * action that prices anything. `updatedAt` is the FX leg's time, for the reason that contract
 * gives: the escrows allow a band an hour, and the Chainlink leg is judged here against its own clock.
 *
 * The FX leg must also lie between R$ 1 and R$ 100 per dollar. That is not a view about the real;
 * it catches the unit mistake this design invites. The ramps' FX instance is signed in centavos
 * (540), this one in millionths (5_400_000). Pointed at the wrong one, or signed in the wrong unit,
 * the rate would be off by 10^4 and every mint priced from it would be a gift: the bound makes it
 * revert instead.
 *
 * A wrong rate inside the bounds is the residual oracle risk, and the reason only contracted
 * gateways mint and redeem (docs/movva.md, "Why LPs mint"): a high rate over-mints, a low rate
 * over-pays redemptions - though never beyond the redeemer's pro-rata share of the whole reserve.
 *
 * ## Off-hours
 *
 * Pyth's FX.USD/BRL trades weekdays 08:00-17:00 New York time (FxMarketHours); PIX never closes. Mova
 * decided (14 September 2026) that trading continues and value creation waits:
 *
 *  - Everything that moves value - `mint`, `redeem`, `withdrawToHedge`, and the ratios
 *    and previews that price them - reads the FX leg's RATE (`brlPerUsdtE18`) and refuses once it is
 *    older than `fxMaxAge`. While the market is closed, minting and redeeming wait for it to reopen.
 *  - The ramps' band, `brlCentsPerUnit`, reads the FX leg as a band does (BandRead): while the market
 *    is closed, at its last close, stamped current. So Movva's price check keeps working off-hours and
 *    LPs keep selling the Movva they hold. `bandBrlPerUsdtE18` exposes that reading to off-chain readers.
 *
 * A leg with no band reading (a SignedPriceOracle) is read the same way on both paths.
 *
 * ## Freezes
 *
 * Tether can freeze this contract. A frozen address can still receive USDT, so intake - mint and
 * recapitalize - is refused while frozen: it would only grow the frozen pile. Frozen idle USDT
 * counts for nothing, but the yield-vault position is shares, not USDT, and the vault can still pay
 * out of it: redemptions and hedge withdrawals are paid straight from the vault to the recipient,
 * pro rata to what is actually payable. Nobody is paid into a frozen address.
 */
contract MovvaReserve is IMovvaReserve, IPriceOracle, DelayedGovernance, ReentrancyGuard {
    using SafeERC20 for IERC20;

    /// @dev Grouped to keep the constructor under the stack limit.
    struct Config {
        address usdt;
        address usdtUsdFeed;
        address fxOracle;
        uint64 usdtUsdMaxAge;
        uint64 fxMaxAge;
        address governor;
        uint256 governanceDelay;
        address guardian;
        address treasurer;
        address hedgeTreasury;
        address feeRecipient;
        uint256 supplyCap;
        /// @dev The self-clearing DivergenceBreaker; zero for none (no breaker at all).
        address breaker;
        /// @dev How long a hedge withdrawal above the daily limit waits before anyone may execute it.
        uint64 hedgeQueueDelay;
    }

    uint16 public constant BPS = 10_000;
    /// @notice Hard caps no governance can pass (docs/movva.md, "Still to decide").
    uint16 public constant MAX_MINT_FEE_BPS = 100;
    uint16 public constant MAX_REDEEM_FEE_BPS = 100;
    /// @notice The signed FX leg must read between R$ 1 and R$ 100 per US dollar, at 1e-6.
    uint256 public constant MIN_BRL_PER_USD_E6 = 1e6;
    uint256 public constant MAX_BRL_PER_USD_E6 = 100e6;
    /// @notice A leg's timestamp may be this far ahead of the chain, and no further.
    uint64 public constant MAX_FUTURE_SKEW = 5 minutes;

    address public immutable MOVVA;
    address public immutable USDT;
    /// @notice Keyless, self-clearing halt while independent price sources disagree. Zero: none.
    IDivergenceBreaker public immutable BREAKER;
    /// @notice Delay before a hedge withdrawal above the daily limit may be executed, by anyone.
    uint64 public immutable HEDGE_QUEUE_DELAY;

    address public guardian;
    /// @notice May call `withdrawToHedge`. Zero means nobody may.
    address public treasurer;
    /// @notice The issuer's hedge account: the only place `withdrawToHedge` pays.
    address public hedgeTreasury;
    /// @notice Receives mint and redeem fees, as Movva.
    address public feeRecipient;

    /// @notice Chainlink USDT/USD.
    IAggregatorV3 public usdtUsdFeed;
    /// @notice BRL per ONE US dollar, scaled 1e6: a PythFxOracle, or a SignedPriceOracle signed in that unit.
    IPriceOracle public fxOracle;
    uint64 public usdtUsdMaxAge;
    uint64 public fxMaxAge;

    /// @notice YieldVault(USDT); zero for none.
    IERC4626 public yieldVault;
    /// @notice True stops the reserve putting USDT into the vault; exits from it are unaffected.
    bool public vaultDepositsPaused;
    bool public mintPaused;

    mapping(address => bool) public isGateway;

    /// @notice Most Movva that may exist, in base units (1e18 = R$ 1,00).
    uint256 public supplyCap;

    uint16 public mintFeeBps;
    uint16 public redeemFeeBps;
    // Sized with packages/movva's shock tool (docs/movva.md, "Sizing the buffer"): the hedge desk keeps
    // the reserve at the target, may draw it down to the withdraw floor, and minting stops at 100%.
    uint16 public targetCollateralRatioBps = 10_800;
    uint16 public minMintCollateralRatioBps = 10_000;
    uint16 public minWithdrawCollateralRatioBps = 10_300;
    /// @notice `withdrawToHedge` rate limit: this share of `totalUsdt` per 24 hours.
    uint16 public hedgeLimitBps = 800;

    uint64 public hedgeUsedAt;
    /// @notice The hedge rate limit's bucket at `hedgeUsedAt`, in USDT; it drains at the limit per day.
    uint256 public hedgeUsed;

    /// @dev A queued hedge withdrawal. Recipient and amount are fixed at queue time and nothing - no
    ///      role, no governance change - can alter, cancel or reorder it.
    struct HedgeRequest {
        address to;
        uint64 executeAfter;
        bool executed;
        uint256 usdt;
    }

    mapping(uint256 => HedgeRequest) public hedgeRequests;
    uint256 public hedgeRequestCount;

    /// @notice A hedge withdrawal above the daily limit was announced; anyone may execute it at `executeAfter`.
    event HedgeWithdrawalQueued(uint256 indexed id, address indexed to, uint256 usdt, uint64 executeAfter);
    event HedgeWithdrawalExecuted(uint256 indexed id, address indexed to, uint256 usdt, address executor);
    event GatewaySet(address indexed gateway, bool allowed);
    event RoleSet(string role, address indexed account);
    event FeesSet(uint16 mintFeeBps, uint16 redeemFeeBps);
    event CollateralRatiosSet(uint16 target, uint16 minMint, uint16 minWithdraw);
    event LimitsSet(uint256 supplyCap, uint16 hedgeLimitBps);
    event OracleSet(address usdtUsdFeed, address fxOracle, uint64 usdtUsdMaxAge, uint64 fxMaxAge);
    event YieldVaultSet(address indexed vault);
    event MintPaused(address indexed by);
    event MintResumed();
    event VaultDepositsPausedSet(bool paused);
    event PulledFromVault(uint256 requested, uint256 received);
    /// @notice The vault refused a deposit its own `maxDeposit` allowed; the USDT stays idle.
    event VaultDepositFailed(uint256 usdt);

    error NotGateway();
    error NotTreasurer();
    error NotGuardianOrGovernor();
    error ZeroAmount();
    error MintIsPaused();
    error BadPrice(address leg, int256 answer);
    error FxOutOfRange(uint256 brlPerUsdE6);
    error StaleLeg(address leg, uint256 updatedAt);
    error LegFromFuture(address leg, uint256 updatedAt);
    error FeedDecimalsOutOfRange(address feed, uint8 decimals);
    error PriceRoundsToZero();
    error BadMaxAge();
    error CollateralRatioTooLow(uint256 ratioBps, uint256 minimumBps);
    error RatiosOutOfOrder();
    error SupplyCapExceeded(uint256 supply, uint256 cap);
    error Slippage(uint256 out, uint256 minOut);
    error InsufficientLiquidity(uint256 wanted, uint256 available);
    error TransferFeeCharged(uint256 amount, uint256 received);
    error FrozenByAssetIssuer(address who);
    error HedgeLimitExceeded(uint256 wanted, uint256 available);
    error FeeTooHigh();
    error BadBps();
    error AssetMismatch();
    error VaultNotEmpty();
    error NoVault();
    error UnknownHedgeRequest(uint256 id);
    error HedgeRequestNotReady(uint256 id, uint64 executeAfter);
    error HedgeRequestDone(uint256 id);

    modifier onlyGateway() {
        if (!isGateway[msg.sender]) revert NotGateway();
        _;
    }

    /**
     * @dev Deploys Movva, so the token's minter is this contract from the token's first block (see
     *      Movva's header). Ratios, fees and limits start at the doc's proposed defaults; the deploy
     *      script overrides them, and adds gateways and the vault, during setup.
     */
    constructor(Config memory c) DelayedGovernance(c.governor, c.governanceDelay) {
        if (
            c.usdt == address(0) || c.guardian == address(0) || c.hedgeTreasury == address(0)
                || c.feeRecipient == address(0)
        ) revert ZeroAddress();
        USDT = c.usdt;
        MOVVA = address(new Movva());
        guardian = c.guardian;
        treasurer = c.treasurer;
        hedgeTreasury = c.hedgeTreasury;
        feeRecipient = c.feeRecipient;
        supplyCap = c.supplyCap;
        BREAKER = IDivergenceBreaker(c.breaker);
        HEDGE_QUEUE_DELAY = c.hedgeQueueDelay;
        _setOracle(c.usdtUsdFeed, c.fxOracle, c.usdtUsdMaxAge, c.fxMaxAge);
    }

    /*//////////////////////////////////////////////////////////////
                         DIVERGENCE BREAKER (VIEW)
    //////////////////////////////////////////////////////////////*/

    /// @notice True while the breaker halts mint, redeem and hedge withdrawals. Never
    ///         latches: it is recomputed from the sources' current answers on every call.
    function breakerTripped() external view returns (bool) {
        if (address(BREAKER) == address(0)) return false;
        (uint256 rate,) = _rate(false);
        return !BREAKER.inBand(rate);
    }

    /*//////////////////////////////////////////////////////////////
                                  RATE
    //////////////////////////////////////////////////////////////*/

    /// @inheritdoc IMovvaReserve
    /// @dev `updatedAt` is the FX leg's publish time; the Chainlink leg has been checked against
    ///      `usdtUsdMaxAge` before this returns. Everything that moves value prices at this.
    function brlPerUsdtE18() public view returns (uint256 rate, uint64 updatedAt) {
        return _rate(false);
    }

    /// @inheritdoc IMovvaReserve
    /// @dev For the band and for off-chain readers only: see "Off-hours" in the header.
    function bandBrlPerUsdtE18() external view returns (uint256 rate, uint64 updatedAt) {
        return _rate(true);
    }

    /// @dev The two legs, crossed. With `band`, the FX leg is read as a band reads it (BandRead): at its
    ///      last close while its market is closed, stamped current. Every other check is the same.
    function _rate(bool band) internal view returns (uint256 rate, uint64 updatedAt) {
        IAggregatorV3 feed = usdtUsdFeed;
        // Freshness is judged by updatedAt alone, as in ChainlinkSignedFxOracle.
        // slither-disable-next-line unused-return
        (, int256 answer,, uint256 at,) = feed.latestRoundData();
        if (answer <= 0) revert BadPrice(address(feed), answer);
        if (at == 0 || block.timestamp > at + usdtUsdMaxAge) revert StaleLeg(address(feed), at);
        if (at > block.timestamp + MAX_FUTURE_SKEW) revert LegFromFuture(address(feed), at);
        uint8 dec = feed.decimals();
        if (dec > 18) revert FeedDecimalsOutOfRange(address(feed), dec);

        IPriceOracle fx = fxOracle;
        uint256 brlPerUsdE6;
        // Either reading reverts before the leg has a price, and while its setup is open.
        (brlPerUsdE6, updatedAt) = band ? BandRead.read(fx) : fx.brlCentsPerUnit();
        if (brlPerUsdE6 < MIN_BRL_PER_USD_E6 || brlPerUsdE6 > MAX_BRL_PER_USD_E6) revert FxOutOfRange(brlPerUsdE6);
        if (updatedAt > block.timestamp + MAX_FUTURE_SKEW) revert LegFromFuture(address(fx), updatedAt);
        if (block.timestamp > uint256(updatedAt) + fxMaxAge) revert StaleLeg(address(fx), updatedAt);

        // usd (dec decimals) x brl/usd (1e6) -> brl (1e18): x 1e18 / (10^dec x 1e6). Floor.
        rate = Math.mulDiv(uint256(answer), brlPerUsdE6 * 1e12, 10 ** dec);
        if (rate == 0) revert PriceRoundsToZero();
    }

    /**
     * @inheritdoc IPriceOracle
     * @notice Movva's band on the ramps: R$ 1,00 x min(1, collateral ratio), in centavos per whole
     *         Movva, never above 100.
     * @dev Nearest centavo, as ChainlinkSignedFxOracle rounds a midpoint: the ramps quote whole
     *      centavos per token, so a centavo is already the band's resolution. The rate is read as a
     *      band (`bandBrlPerUsdtE18`, see "Off-hours"), and `updatedAt` is that reading's. Reverts when
     *      it is stale, as the interface requires.
     */
    function brlCentsPerUnit() external view returns (uint256 price, uint64 updatedAt) {
        uint256 rate;
        (rate, updatedAt) = _rate(true);
        uint256 ratio = _ratio(totalUsdt(), rate, _supply());
        if (ratio > BPS) ratio = BPS;
        price = (ratio * 100 + BPS / 2) / BPS;
        // A reserve under half a percent backed: no price is the safe answer.
        // slither-disable-next-line incorrect-equality
        if (price == 0) revert PriceRoundsToZero();
    }

    /*//////////////////////////////////////////////////////////////
                               ACCOUNTING
    //////////////////////////////////////////////////////////////*/

    /**
     * @inheritdoc IMovvaReserve
     * @dev Idle USDT counts as zero while the reserve is frozen by Tether (it cannot be paid out);
     *      the vault position counts at `previewRedeem`, rounded down.
     */
    function totalUsdt() public view returns (uint256) {
        return _payableIdle() + _vaultUsdt();
    }

    /// @inheritdoc IMovvaReserve
    function reserveBrlE18() external view returns (uint256) {
        (uint256 rate,) = brlPerUsdtE18();
        return _brl(totalUsdt(), rate);
    }

    /// @inheritdoc IMovvaReserve
    function liabilitiesBrlE18() external view returns (uint256) {
        return _supply();
    }

    /// @inheritdoc IMovvaReserve
    function collateralRatioBps() public view returns (uint256) {
        (uint256 rate,) = brlPerUsdtE18();
        return _ratio(totalUsdt(), rate, _supply());
    }

    /// @inheritdoc IMovvaReserve
    function surplusBrlE18() external view returns (uint256) {
        (uint256 rate,) = brlPerUsdtE18();
        uint256 reserve = _brl(totalUsdt(), rate);
        uint256 needed = Math.mulDiv(_supply(), targetCollateralRatioBps, BPS, Math.Rounding.Ceil);
        return reserve > needed ? reserve - needed : 0;
    }

    /// @inheritdoc IMovvaReserve
    /// @dev Rounded up: the figure the issuer hedges errs toward hedging a unit more.
    function liabilitiesUsdt() external view returns (uint256) {
        (uint256 rate,) = brlPerUsdtE18();
        return Math.mulDiv(_supply(), 1e6, rate, Math.Rounding.Ceil);
    }

    /// @notice True while Tether (or Circle, for a USDC reserve) has frozen this contract.
    function frozenByAssetIssuer() public view returns (bool) {
        return IssuerFreeze.isFrozen(USDT, address(this));
    }

    /**
     * @notice Movva a mint of `usdtIn` would deliver now, and the fee minted beside it.
     * @dev Ignores pauses, caps, freezes and the ratio floor. `mint` prices what the reserve books
     *      after depositing into the vault, which can be a vault rounding unit less.
     */
    function previewMint(uint256 usdtIn) external view returns (uint256 movvaOut, uint256 fee) {
        (uint256 rate,) = brlPerUsdtE18();
        return _mintAmounts(_brl(usdtIn, rate));
    }

    /// @notice USDT a redemption of `movvaIn` would pay now, and the Movva fee. Ignores liquidity.
    function previewRedeem(uint256 movvaIn) external view returns (uint256 usdtOut, uint256 fee) {
        (uint256 rate,) = brlPerUsdtE18();
        return _redeemAmounts(movvaIn, rate);
    }

    /// @notice USDT `withdrawToHedge` may send now under the rate limit (the ratio floor aside).
    function hedgeWithdrawable() external view returns (uint256) {
        (uint256 used, uint256 limit) = _hedgeBucket(totalUsdt());
        return limit > used ? limit - used : 0;
    }

    /*//////////////////////////////////////////////////////////////
                                ACTIONS
    //////////////////////////////////////////////////////////////*/

    /// @inheritdoc IMovvaReserve
    function mint(uint256 usdtIn, address to, uint256 minMovvaOut)
        external
        nonReentrant
        onlyGateway
        returns (uint256 movvaOut)
    {
        _requireSetupComplete();
        if (mintPaused) revert MintIsPaused();
        if (usdtIn == 0) revert ZeroAmount();
        if (to == address(0)) revert ZeroAddress();
        _requireNotFrozen(address(this));
        (uint256 rate,) = brlPerUsdtE18();
        if (address(BREAKER) != address(0)) BREAKER.check(rate);
        uint256 supply = _supply();
        uint256 before = totalUsdt();
        uint256 ratio = _ratio(before, rate, supply);
        if (ratio < minMintCollateralRatioBps) revert CollateralRatioTooLow(ratio, minMintCollateralRatioBps);

        // Value in first, measured, then Movva out: what is minted is priced from what arrived and
        // what the vault booked for it, never from what was asked (ERC-4626's _deposit order).
        _pull(usdtIn);
        // `before` is read to bracket exactly this intake: the vault is governor-chosen through the
        // delay, and mint is nonReentrant, so nothing else can move the reserve in between.
        // slither-disable-next-line reentrancy-balance
        _depositIdle();
        uint256 booked = totalUsdt();
        booked = booked > before ? booked - before : 0;
        // Never more than arrived: a vault's rounding can nudge existing shares up by a unit.
        if (booked > usdtIn) booked = usdtIn;

        uint256 fee;
        (movvaOut, fee) = _mintAmounts(_brl(booked, rate));
        // Zero is dust, refused; not a balance anyone can steer to exactly zero for profit.
        // slither-disable-next-line incorrect-equality
        if (movvaOut == 0 || movvaOut < minMovvaOut) revert Slippage(movvaOut, minMovvaOut);
        if (supply + movvaOut + fee > supplyCap) revert SupplyCapExceeded(supply + movvaOut + fee, supplyCap);
        emit Minted(msg.sender, to, usdtIn, movvaOut, rate);
        Movva(MOVVA).mint(to, movvaOut);
        if (fee != 0) Movva(MOVVA).mint(feeRecipient, fee);
    }

    /**
     * @inheritdoc IMovvaReserve
     * @dev The gateway approves (or permits) `movvaIn` to this contract. The Movva is taken and
     *      burned, less the fee, before any USDT moves.
     */
    function redeem(uint256 movvaIn, address to, uint256 minUsdtOut)
        external
        nonReentrant
        onlyGateway
        returns (uint256 usdtOut)
    {
        _requireSetupComplete();
        if (movvaIn == 0) revert ZeroAmount();
        _requireCanReceive(to);
        (uint256 rate,) = brlPerUsdtE18();
        if (address(BREAKER) != address(0)) BREAKER.checkRedeem(rate);
        uint256 fee;
        (usdtOut, fee) = _redeemAmounts(movvaIn, rate);
        // slither-disable-next-line incorrect-equality
        if (usdtOut == 0 || usdtOut < minUsdtOut) revert Slippage(usdtOut, minUsdtOut);

        IERC20(MOVVA).safeTransferFrom(msg.sender, address(this), movvaIn);
        Movva(MOVVA).burn(movvaIn - fee);
        if (fee != 0) IERC20(MOVVA).safeTransfer(feeRecipient, fee);
        emit Redeemed(msg.sender, to, movvaIn, usdtOut, rate);
        _pay(to, usdtOut);
    }

    /**
     * @inheritdoc IMovvaReserve
     * @dev The rate limit is a bucket of `hedgeLimitBps` of the reserve that drains continuously at
     *      that much per 24 hours. So at most one limit leaves at once, and at most two in any
     *      24-hour window (a full bucket, then a day of refill). The ratio floor is checked on the
     *      projected state before paying and on the actual state after, so a vault's rounding on the
     *      way out cannot slip the ratio under it.
     */
    function withdrawToHedge(uint256 usdt) external nonReentrant {
        if (msg.sender != treasurer) revert NotTreasurer();
        _requireSetupComplete();
        if (usdt == 0) revert ZeroAmount();
        address to = hedgeTreasury;
        _requireCanReceive(to);
        (uint256 rate,) = brlPerUsdtE18();
        if (address(BREAKER) != address(0)) BREAKER.check(rate);
        uint256 total = totalUsdt();
        (uint256 used, uint256 limit) = _hedgeBucket(total);
        uint256 room = limit > used ? limit - used : 0;
        if (usdt > room) revert HedgeLimitExceeded(usdt, room);
        uint256 supply = _supply();
        uint256 floor = minWithdrawCollateralRatioBps;
        uint256 projected = usdt > total ? 0 : _ratio(total - usdt, rate, supply);
        if (projected < floor) revert CollateralRatioTooLow(projected, floor);

        hedgeUsed = used + usdt;
        hedgeUsedAt = uint64(block.timestamp);
        // `total` priced the checks above; the ratio after is re-read from state, not from it.
        // slither-disable-next-line reentrancy-balance
        _pay(to, usdt);

        uint256 ratioAfter = _ratio(totalUsdt(), rate, supply);
        if (ratioAfter < floor) revert CollateralRatioTooLow(ratioAfter, floor);
        emit WithdrawnToHedge(to, usdt, ratioAfter);
    }

    /**
     * @notice Announce a hedge withdrawal that may exceed the daily limit. It waits `HEDGE_QUEUE_DELAY`,
     *         then ANYONE may execute it, exactly once, for exactly `usdt`, to exactly the hedge
     *         treasury as it is now. Nobody can cancel, approve, change or reorder it: a cancel right
     *         would be an admin key (client decision, 24 Sep 2026, "timelock, not multisig").
     * @dev Only the treasurer announces (anyone could otherwise queue noise). The ratio floor is
     *      checked now so a request that could never execute is refused, and again at execution
     *      against the then-current rate and floor, so a rate that fell in the meantime stops it
     *      until the reserve recovers. The daily bucket is not touched: this is the slow lane. Users
     *      have the whole delay to redeem.
     */
    function queueHedgeWithdrawal(uint256 usdt) external nonReentrant returns (uint256 id) {
        if (msg.sender != treasurer) revert NotTreasurer();
        _requireSetupComplete();
        if (usdt == 0) revert ZeroAmount();
        address to = hedgeTreasury;
        _requireCanReceive(to);
        (uint256 rate,) = brlPerUsdtE18();
        uint256 total = totalUsdt();
        uint256 floor = minWithdrawCollateralRatioBps;
        uint256 projected = usdt > total ? 0 : _ratio(total - usdt, rate, _supply());
        if (projected < floor) revert CollateralRatioTooLow(projected, floor);
        id = hedgeRequestCount++;
        uint64 at = uint64(block.timestamp) + HEDGE_QUEUE_DELAY;
        hedgeRequests[id] = HedgeRequest({to: to, executeAfter: at, executed: false, usdt: usdt});
        emit HedgeWithdrawalQueued(id, to, usdt, at);
    }

    /// @notice Pay a queued hedge withdrawal once its delay has passed. Callable by anyone, once.
    function executeHedgeWithdrawal(uint256 id) external nonReentrant {
        _requireSetupComplete();
        HedgeRequest storage r = hedgeRequests[id];
        if (r.to == address(0)) revert UnknownHedgeRequest(id);
        if (r.executed) revert HedgeRequestDone(id);
        if (block.timestamp < r.executeAfter) revert HedgeRequestNotReady(id, r.executeAfter);
        r.executed = true;
        (address to, uint256 usdt) = (r.to, r.usdt);
        _requireCanReceive(to);
        (uint256 rate,) = brlPerUsdtE18();
        if (address(BREAKER) != address(0)) BREAKER.check(rate);
        uint256 supply = _supply();
        uint256 floor = minWithdrawCollateralRatioBps;
        uint256 total = totalUsdt();
        uint256 projected = usdt > total ? 0 : _ratio(total - usdt, rate, supply);
        if (projected < floor) revert CollateralRatioTooLow(projected, floor);
        // slither-disable-next-line reentrancy-balance
        _pay(to, usdt);
        uint256 ratioAfter = _ratio(totalUsdt(), rate, supply);
        if (ratioAfter < floor) revert CollateralRatioTooLow(ratioAfter, floor);
        emit HedgeWithdrawalExecuted(id, to, usdt, msg.sender);
        emit WithdrawnToHedge(to, usdt, ratioAfter);
    }

    /**
     * @inheritdoc IMovvaReserve
     * @dev Works with a stale rate: adding backing must never wait on an oracle. The event then
     *      carries a ratio of zero, meaning "not readable", not "zero".
     */
    function recapitalize(uint256 usdt) external nonReentrant {
        _requireSetupComplete();
        if (usdt == 0) revert ZeroAmount();
        _requireNotFrozen(address(this));
        _pull(usdt);
        _depositIdle();
        uint256 ratio = 0;
        try this.collateralRatioBps() returns (uint256 r) {
            ratio = r;
        } catch {}
        emit Recapitalized(msg.sender, usdt, ratio);
    }

    /*//////////////////////////////////////////////////////////////
                               GOVERNANCE
    //////////////////////////////////////////////////////////////*/

    /// @notice Adding a gateway waits out the delay; removing one is instant.
    function setGateway(address gateway, bool allowed) external {
        _authorizeChange(allowed && !isGateway[gateway]);
        if (gateway == address(0)) revert ZeroAddress();
        isGateway[gateway] = allowed;
        emit GatewaySet(gateway, allowed);
    }

    /// @notice Instant: the guardian can only pause minting.
    function setGuardian(address g) external {
        _authorizeChange(false);
        if (g == address(0)) revert ZeroAddress();
        guardian = g;
        emit RoleSet("guardian", g);
    }

    /// @notice A new treasurer waits out the delay; revoking the role (zero) is instant.
    /// @dev No zero check on purpose: zero is how the role is revoked.
    // slither-disable-next-line missing-zero-check
    function setTreasurer(address t) external {
        _authorizeChange(t != address(0) && t != treasurer);
        treasurer = t;
        emit RoleSet("treasurer", t);
    }

    /// @notice Delayed: this address is where hedge withdrawals go.
    function setHedgeTreasury(address t) external {
        _authorizeChange(t != hedgeTreasury);
        if (t == address(0)) revert ZeroAddress();
        hedgeTreasury = t;
        emit RoleSet("hedgeTreasury", t);
    }

    /// @notice Delayed: this address is paid every fee.
    function setFeeRecipient(address r) external {
        _authorizeChange(r != feeRecipient);
        if (r == address(0)) revert ZeroAddress();
        feeRecipient = r;
        emit RoleSet("feeRecipient", r);
    }

    /// @notice Raising either fee is delayed; lowering is instant. Hard caps apply either way.
    function setFees(uint16 mintBps, uint16 redeemBps) external {
        _authorizeChange(mintBps > mintFeeBps || redeemBps > redeemFeeBps);
        if (mintBps > MAX_MINT_FEE_BPS || redeemBps > MAX_REDEEM_FEE_BPS) revert FeeTooHigh();
        (mintFeeBps, redeemFeeBps) = (mintBps, redeemBps);
        emit FeesSet(mintBps, redeemBps);
    }

    /**
     * @notice LOWERING a ratio is delayed (it lets value out at less backing); raising is instant.
     *         None may be below 100%, and they must stay ordered: mint floor <= withdraw floor <= target.
     * @dev The order is the hedge working at all. The hedge desk keeps the reserve at the target
     *      (`surplusBrlE18` is what sits above it). A withdraw floor ABOVE the target - as first
     *      proposed, 105% over 102% - leaves a dollar rally's first gains stuck in the reserve while
     *      the short position calls for margin: the shock tool found it before any money did.
     */
    function setCollateralRatios(uint16 target, uint16 minMint, uint16 minWithdraw) external {
        _authorizeChange(
            target < targetCollateralRatioBps || minMint < minMintCollateralRatioBps
                || minWithdraw < minWithdrawCollateralRatioBps
        );
        if (target < BPS || minMint < BPS || minWithdraw < BPS) revert BadBps();
        if (minMint > minWithdraw || minWithdraw > target) revert RatiosOutOfOrder();
        (targetCollateralRatioBps, minMintCollateralRatioBps, minWithdrawCollateralRatioBps) =
            (target, minMint, minWithdraw);
        emit CollateralRatiosSet(target, minMint, minWithdraw);
    }

    /// @notice Raising the supply cap or the hedge limit is delayed; lowering either is instant. A
    ///         supply cap of zero stops minting.
    function setLimits(uint256 cap, uint16 hedgeBps) external {
        _authorizeChange(cap > supplyCap || hedgeBps > hedgeLimitBps);
        if (hedgeBps > BPS) revert BadBps();
        (supplyCap, hedgeLimitBps) = (cap, hedgeBps);
        emit LimitsSet(cap, hedgeBps);
    }

    /// @notice Repointing either leg or lengthening a max age is delayed; only tightening an age is
    ///         instant. The rate prices every mint and redemption, so unlike the ramps' band oracles
    ///         its legs are not an instant setting here.
    function setOracle(address feed, address fx, uint64 feedMaxAge, uint64 fxMaxAge_) external {
        _authorizeChange(
            feed != address(usdtUsdFeed) || fx != address(fxOracle) || feedMaxAge > usdtUsdMaxAge
                || fxMaxAge_ > fxMaxAge
        );
        _setOracle(feed, fx, feedMaxAge, fxMaxAge_);
    }

    /**
     * @notice Choose the yield vault. A new vault is delayed; removing it (zero) is instant.
     * @dev Only while the reserve holds no shares of the current one, so no value is ever dropped
     *      from the books: `pullFromVault(type(uint256).max)` first.
     */
    function setYieldVault(address v) external {
        _authorizeChange(v != address(0) && v != address(yieldVault));
        IERC4626 cur = yieldVault;
        if (address(cur) != address(0) && cur.balanceOf(address(this)) != 0) revert VaultNotEmpty();
        if (v != address(0) && IERC4626(v).asset() != USDT) revert AssetMismatch();
        yieldVault = IERC4626(v);
        emit YieldVaultSet(v);
    }

    /**
     * @notice Instant, governor only: bring `usdt` back from the vault into the reserve, and stop
     *         depositing into it until `setVaultDepositsPaused(false)`. `type(uint256).max` redeems
     *         every share.
     * @dev USDT can only come back here. Refused while frozen: it would turn a payable vault position
     *      into frozen idle USDT.
     */
    function pullFromVault(uint256 usdt) external nonReentrant {
        _authorizeChange(false);
        IERC4626 v = yieldVault;
        if (address(v) == address(0)) revert NoVault();
        _requireNotFrozen(address(this));
        vaultDepositsPaused = true;
        emit VaultDepositsPausedSet(true);
        uint256 before = IERC20(USDT).balanceOf(address(this));
        // What arrived is re-read below; the shares burned, or assets returned, do not matter.
        if (usdt == type(uint256).max) {
            // slither-disable-next-line unused-return
            v.redeem(v.balanceOf(address(this)), address(this), address(this));
        } else {
            // slither-disable-next-line unused-return
            v.withdraw(usdt, address(this), address(this));
        }
        emit PulledFromVault(usdt, IERC20(USDT).balanceOf(address(this)) - before);
    }

    /// @notice Instant either way: the vault was chosen through the delay, and exits are unaffected.
    function setVaultDepositsPaused(bool paused) external {
        _authorizeChange(false);
        vaultDepositsPaused = paused;
        emit VaultDepositsPausedSet(paused);
    }

    /// @notice Guardian or governor: stop minting. Redemptions cannot be paused.
    function pauseMint() external {
        if (msg.sender != guardian && msg.sender != governor) revert NotGuardianOrGovernor();
        mintPaused = true;
        emit MintPaused(msg.sender);
    }

    function resumeMint() external onlyGovernor {
        mintPaused = false;
        emit MintResumed();
    }

    function _isDelayable(bytes4 selector) internal pure override returns (bool) {
        return selector == MovvaReserve.setGateway.selector || selector == MovvaReserve.setTreasurer.selector
            || selector == MovvaReserve.setHedgeTreasury.selector || selector == MovvaReserve.setFeeRecipient.selector
            || selector == MovvaReserve.setFees.selector || selector == MovvaReserve.setCollateralRatios.selector
            || selector == MovvaReserve.setLimits.selector || selector == MovvaReserve.setOracle.selector
            || selector == MovvaReserve.setYieldVault.selector;
    }

    /*//////////////////////////////////////////////////////////////
                                INTERNAL
    //////////////////////////////////////////////////////////////*/

    function _supply() internal view returns (uint256) {
        return IERC20(MOVVA).totalSupply();
    }

    function _payableIdle() internal view returns (uint256) {
        return frozenByAssetIssuer() ? 0 : IERC20(USDT).balanceOf(address(this));
    }

    function _vaultUsdt() internal view returns (uint256) {
        IERC4626 v = yieldVault;
        if (address(v) == address(0)) return 0;
        uint256 shares = v.balanceOf(address(this));
        // A shortcut, not a check: previewRedeem(0) is zero anyway.
        // slither-disable-next-line incorrect-equality
        return shares == 0 ? 0 : v.previewRedeem(shares);
    }

    /// @dev USDT (6 decimals) to reais (18 decimals) at `rate`, rounded down.
    function _brl(uint256 usdt, uint256 rate) internal pure returns (uint256) {
        return Math.mulDiv(usdt, rate, 1e6);
    }

    /// @dev Reserve rounded down, then the ratio rounded down.
    function _ratio(uint256 usdt, uint256 rate, uint256 supply) internal pure returns (uint256) {
        if (supply == 0) return type(uint256).max;
        return Math.mulDiv(_brl(usdt, rate), BPS, supply);
    }

    /// @dev Gross Movva, less a fee rounded up.
    function _mintAmounts(uint256 gross) internal view returns (uint256 out, uint256 fee) {
        fee = Math.mulDiv(gross, mintFeeBps, BPS, Math.Rounding.Ceil);
        out = gross - fee;
    }

    /**
     * @dev The fee is rounded up and kept as Movva; the rest is paid at the lesser of par
     *      (`net / rate`) and the pro-rata share of everything payable (`net / supply x totalUsdt`),
     *      each rounded down. The lesser of the two is exactly min(1, ratio) of par.
     */
    function _redeemAmounts(uint256 movvaIn, uint256 rate) internal view returns (uint256 usdtOut, uint256 fee) {
        fee = Math.mulDiv(movvaIn, redeemFeeBps, BPS, Math.Rounding.Ceil);
        uint256 net = movvaIn - fee;
        uint256 supply = _supply();
        if (supply == 0) return (0, fee);
        uint256 atPar = Math.mulDiv(net, 1e6, rate);
        uint256 proRata = Math.mulDiv(net, totalUsdt(), supply);
        usdtOut = atPar < proRata ? atPar : proRata;
    }

    /// @dev The bucket's level now, and its size: `hedgeLimitBps` of `total`, draining at that per day.
    function _hedgeBucket(uint256 total) internal view returns (uint256 used, uint256 limit) {
        limit = (total * hedgeLimitBps) / BPS;
        uint256 drained = Math.mulDiv(limit, block.timestamp - hedgeUsedAt, 1 days);
        used = hedgeUsed > drained ? hedgeUsed - drained : 0;
    }

    /// @dev Pull USDT from the caller and refuse it if less arrived: YieldVault._deposit's guard.
    function _pull(uint256 amount) internal {
        IERC20 token = IERC20(USDT);
        uint256 before = token.balanceOf(address(this));
        token.safeTransferFrom(msg.sender, address(this), amount);
        // Every caller is nonReentrant, and `before` brackets only this transfer.
        // slither-disable-next-line reentrancy-balance
        uint256 received = token.balanceOf(address(this)) - before;
        if (received < amount) revert TransferFeeCharged(amount, received);
    }

    /**
     * @dev Put idle USDT into the vault, as much as it accepts: `maxDeposit` is zero while the vault is
     *      paused, frozen, in setup or at its cap. A vault that refuses anyway leaves the USDT idle
     *      rather than blocking the mint or recapitalization that brought it.
     */
    function _depositIdle() internal {
        IERC4626 v = yieldVault;
        if (address(v) == address(0) || vaultDepositsPaused) return;
        uint256 amount = IERC20(USDT).balanceOf(address(this));
        uint256 room = v.maxDeposit(address(this));
        if (room < amount) amount = room;
        // Nothing idle, or a vault that takes nothing now: skip the call, lose nothing.
        // slither-disable-next-line incorrect-equality
        if (amount == 0) return;
        IERC20(USDT).forceApprove(address(v), amount);
        // The shares are re-read by totalUsdt; the return value is not needed.
        // slither-disable-next-line unused-return
        try v.deposit(amount, address(this)) returns (uint256) {}
        catch {
            IERC20(USDT).forceApprove(address(v), 0);
            emit VaultDepositFailed(amount);
        }
    }

    /**
     * @dev Pay `amount` from idle first, then from the vault straight to `to`. Paid directly, the
     *      vault's part still arrives while Tether has frozen this contract, and costs one USDT
     *      transfer rather than two. A shortfall reverts with what was available, before anything moves.
     */
    function _pay(address to, uint256 amount) internal {
        uint256 fromIdle = _payableIdle();
        if (fromIdle > amount) fromIdle = amount;
        uint256 fromVault = amount - fromIdle;
        if (fromVault != 0) {
            IERC4626 v = yieldVault;
            uint256 liquid = address(v) == address(0) ? 0 : v.maxWithdraw(address(this));
            if (liquid < fromVault) revert InsufficientLiquidity(amount, fromIdle + liquid);
            // Shares burned are not needed; the vault rounds them up, against this reserve.
            // slither-disable-next-line unused-return
            v.withdraw(fromVault, to, address(this));
        }
        if (fromIdle != 0) IERC20(USDT).safeTransfer(to, fromIdle);
    }

    function _requireNotFrozen(address who) internal view {
        if (IssuerFreeze.isFrozen(USDT, who)) revert FrozenByAssetIssuer(who);
    }

    /// @dev A payee must exist and be able to use what it receives.
    function _requireCanReceive(address to) internal view {
        if (to == address(0)) revert ZeroAddress();
        _requireNotFrozen(to);
    }

    function _setOracle(address feed, address fx, uint64 feedMaxAge, uint64 fxMaxAge_) internal {
        if (feed == address(0) || fx == address(0)) revert ZeroAddress();
        // Zero would refuse every price; that is a mistake to report, not a setting to store.
        if (feedMaxAge == 0 || fxMaxAge_ == 0) revert BadMaxAge();
        usdtUsdFeed = IAggregatorV3(feed);
        fxOracle = IPriceOracle(fx);
        usdtUsdMaxAge = feedMaxAge;
        fxMaxAge = fxMaxAge_;
        emit OracleSet(feed, fx, feedMaxAge, fxMaxAge_);
    }
}
