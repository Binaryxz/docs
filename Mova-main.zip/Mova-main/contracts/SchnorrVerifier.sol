// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

/**
 * @title SchnorrVerifier
 * @notice Verifies FROST threshold Schnorr signatures (RFC 9591, FROST(secp256k1, SHA-256))
 *         on-chain, so a threshold-signed operation can authorise a Safe.
 *
 * Ethereum has no secp256k1 point-multiplication precompile, and doing it in Solidity costs
 * hundreds of thousands of gas. The way round it is to coerce `ecrecover` into computing the
 * linear combination for us. `ecrecover(h, v, r, s)` internally evaluates
 *
 *     Q = r^-1 * (s*R' - h*G)          where R' is the curve point with x-coordinate r
 *
 * Choosing R' = P (the group public key), s = -c*Px and h = -z*Px gives
 *
 *     Q = Px^-1 * (-c*Px*P + z*Px*G) = z*G - c*P
 *
 * and the Schnorr check `z*G == R + c*P` is exactly `Q == R`. One precompile call, ~3k gas.
 *
 * ------------------------------------------------------------------------------------------
 * UNAUDITED. This and `packages/mpc` are the only from-specification cryptography in this
 * repository. `docs/audit-scope.md` ranks them first for external review. Do not put funds
 * behind either until that has happened.
 * ------------------------------------------------------------------------------------------
 *
 * Two properties of this construction a reviewer should weigh:
 *
 *  1. `ecrecover` returns an ADDRESS, not a point, so the comparison is over 160 bits rather
 *     than the full 256-bit x-coordinate. Forging needs a `z` whose combination lands on a
 *     specific address - 2^160 work, not a 2^80 birthday, because the target is fixed by R.
 *     The challenge also depends on R, so an attacker cannot choose R after fixing z. This
 *     is the same trade the widely-deployed Schnorr verifiers make, but it is a trade.
 *  2. The challenge is recomputed here from R, the public key and the message, using the
 *     ciphersuite's hash-to-scalar. If this diverged from the TypeScript by one byte,
 *     nothing would verify - so the divergence would be loud rather than silent. There is a
 *     differential test asserting they agree on random inputs.
 */
library SchnorrVerifier {
    /// @dev secp256k1 group order.
    uint256 internal constant N = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141;
    /// @dev secp256k1 field prime.
    uint256 internal constant P = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F;
    /// @dev RFC 9591 context string for this ciphersuite.
    string internal constant CONTEXT = "FROST-secp256k1-SHA256-v1";

    error NotOnCurve();
    error ZeroCoordinate();
    error ScalarOutOfRange();

    struct Signature {
        uint256 rx;
        uint256 ry;
        uint256 z;
    }

    struct PublicKey {
        uint256 x;
        uint256 y;
    }

    /// @dev y^2 == x^3 + 7 (mod p). Rejecting off-curve input matters: `ecrecover` would
    ///      otherwise be handed a point that does not exist and return something arbitrary.
    function onCurve(uint256 x, uint256 y) internal pure returns (bool) {
        if (x == 0 || y == 0 || x >= P || y >= P) return false;
        uint256 lhs = mulmod(y, y, P);
        uint256 rhs = addmod(mulmod(mulmod(x, x, P), x, P), 7, P);
        return lhs == rhs;
    }

    /// @dev Ethereum address of a curve point, as `ecrecover` would return it.
    function addressOf(uint256 x, uint256 y) internal pure returns (address) {
        return address(uint160(uint256(keccak256(abi.encodePacked(x, y)))));
    }

    /**
     * @dev Hash-to-scalar, matching `h2s` in packages/mpc/src/frost.ts.
     *
     * Reduces 64 bytes rather than 32. Reducing a 256-bit value into a ~256-bit order leaves
     * a measurable modulo bias; 512 bits makes it negligible. Both halves must be derived
     * exactly as the library does or nothing verifies.
     */
    function hashToScalar(string memory domain, bytes memory parts) internal pure returns (uint256) {
        bytes memory msg_ = abi.encodePacked(CONTEXT, domain, parts);
        bytes32 a = sha256(abi.encodePacked("h2s-1", msg_));
        bytes32 b = sha256(abi.encodePacked("h2s-2", msg_));
        // The wide value is a||b interpreted big-endian, reduced mod N. Computed as
        // a*2^256 + b (mod N) to avoid needing 512-bit arithmetic.
        uint256 hi = uint256(a) % N;
        uint256 shift = (type(uint256).max % N + 1) % N; // 2^256 mod N
        return addmod(mulmod(hi, shift, N), uint256(b) % N, N);
    }

    /// @dev Compressed SEC1 encoding: 0x02/0x03 by y parity, then x.
    function compress(uint256 x, uint256 y) internal pure returns (bytes memory) {
        return abi.encodePacked(uint8(y % 2 == 0 ? 0x02 : 0x03), x);
    }

    /// @dev The FROST challenge c = H2(R, PK, sha256(message)).
    function challenge(Signature memory sig, PublicKey memory pk, bytes memory message)
        internal
        pure
        returns (uint256)
    {
        return hashToScalar(
            "chal",
            abi.encodePacked(compress(sig.rx, sig.ry), compress(pk.x, pk.y), sha256(message))
        );
    }

    /**
     * @notice Verify `z*G == R + c*PK`.
     * @dev Reverts on malformed input rather than returning false, so a caller cannot
     *      confuse "this signature is invalid" with "these coordinates are nonsense".
     */
    function verify(Signature memory sig, PublicKey memory pk, bytes memory message)
        internal
        pure
        returns (bool)
    {
        if (!onCurve(sig.rx, sig.ry) || !onCurve(pk.x, pk.y)) revert NotOnCurve();
        if (pk.x % N == 0) revert ZeroCoordinate(); // Px is the inversion base; must be nonzero
        if (sig.z == 0 || sig.z >= N) revert ScalarOutOfRange();

        uint256 c = challenge(sig, pk, message);
        if (c == 0) return false;

        // h = -z*Px  and  s = -c*Px, both mod N, so ecrecover yields z*G - c*PK.
        uint256 px = pk.x % N;
        bytes32 h = bytes32(N - mulmod(sig.z, px, N));
        bytes32 s = bytes32(N - mulmod(c, px, N));
        uint8 v = pk.y % 2 == 0 ? 27 : 28;

        address recovered = ecrecover(h, v, bytes32(pk.x), s);
        if (recovered == address(0)) return false;
        return recovered == addressOf(sig.rx, sig.ry);
    }
}

/**
 * @title FrostSigner
 * @notice An ERC-1271 signer owned by a FROST group key, so a Safe can have threshold
 *         signing as one of its owners.
 *
 * This is the piece that turns `packages/mpc` from a library into a spending path. Safe
 * accepts contract owners, which is the same mechanism the WebAuthn P-256 signer uses, so a
 * FROST group becomes one owner alongside the passkey and the server co-signer rather than a
 * new account model. Address derivation, the 4337 flow and the paymaster are unchanged.
 *
 * Immutable and stateless: the group public key is fixed at deployment. Rotating the group
 * means deploying a new signer and swapping the Safe owner, which is a visible on-chain act
 * rather than a silent state change.
 */
contract FrostSigner {
    using SchnorrVerifier for SchnorrVerifier.Signature;

    /// @dev EIP-1271 as standardised: isValidSignature(bytes32,bytes).
    bytes4 internal constant MAGIC_1271 = 0x1626ba7e;
    /**
     * @dev Safe's LEGACY validator interface: isValidSignature(bytes,bytes), whose magic
     *      value is different. Safe 1.4.1's `checkNSignatures` calls this overload for a
     *      contract owner and compares against 0x20c13b0b, so returning the bytes32 magic
     *      here fails with an opaque AA24 - which is exactly how this was found, by running
     *      a UserOperation rather than trusting the unit test on the verifier alone.
     */
    bytes4 internal constant MAGIC_LEGACY = 0x20c13b0b;

    uint256 public immutable GROUP_X;
    uint256 public immutable GROUP_Y;

    error KeyNotOnCurve();

    constructor(uint256 groupX, uint256 groupY) {
        if (!SchnorrVerifier.onCurve(groupX, groupY)) revert KeyNotOnCurve();
        GROUP_X = groupX;
        GROUP_Y = groupY;
    }

    function groupKey() external view returns (SchnorrVerifier.PublicKey memory) {
        return SchnorrVerifier.PublicKey(GROUP_X, GROUP_Y);
    }

    /**
     * @notice EIP-1271 over a digest.
     * @param signature abi.encode(rx, ry, z)
     * @dev The FROST challenge covers `sha256(message)`, and the message here is the 32-byte
     *      digest itself. That must match what the signing side feeds the library, or nothing
     *      verifies - the differential test pins it.
     */
    function isValidSignature(bytes32 digest, bytes calldata signature)
        external
        view
        returns (bytes4)
    {
        (uint256 rx, uint256 ry, uint256 z) = abi.decode(signature, (uint256, uint256, uint256));
        bool okSig = SchnorrVerifier.verify(
            SchnorrVerifier.Signature(rx, ry, z),
            SchnorrVerifier.PublicKey(GROUP_X, GROUP_Y),
            abi.encodePacked(digest)
        );
        return okSig ? MAGIC_1271 : bytes4(0);
    }

    /**
     * @notice Legacy Safe path, which passes the preimage rather than the digest.
     * @dev This is the overload Safe actually calls. `keccak256(data)` reproduces the
     *      operation hash the group signed, because Safe4337Module hands over the full
     *      EIP-712 preimage whose keccak is that hash.
     */
    function isValidSignature(bytes calldata data, bytes calldata signature)
        external
        view
        returns (bytes4)
    {
        bool okSig = SchnorrVerifier.verify(
            _decode(signature),
            SchnorrVerifier.PublicKey(GROUP_X, GROUP_Y),
            abi.encodePacked(keccak256(data))
        );
        return okSig ? MAGIC_LEGACY : bytes4(0);
    }

    function _decode(bytes calldata signature) internal pure returns (SchnorrVerifier.Signature memory) {
        (uint256 rx, uint256 ry, uint256 z) = abi.decode(signature, (uint256, uint256, uint256));
        return SchnorrVerifier.Signature(rx, ry, z);
    }
}
