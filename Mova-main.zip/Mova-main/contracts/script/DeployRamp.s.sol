// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Script} from "forge-std/Script.sol";
import {console2} from "forge-std/console2.sol";
import {IERC20Metadata} from "@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol";
import {FiatEscrow, IEntrypointAssets} from "../ramp/FiatEscrow.sol";
import {OffRampEscrow} from "../ramp/OffRampEscrow.sol";
import {LPRegistry} from "../ramp/LPRegistry.sol";
import {ChainlinkBrlOracle} from "../ramp/ChainlinkBrlOracle.sol";
import {PythBrlOracle} from "../ramp/PythBrlOracle.sol";
import {SignedPriceOracle} from "../ramp/SignedPriceOracle.sol";
import {ChainlinkSignedFxOracle} from "../ramp/ChainlinkSignedFxOracle.sol";
import {PythFxOracle} from "../ramp/PythFxOracle.sol";
import {IPriceOracle} from "../ramp/IPriceOracle.sol";
import {ScaledFxBandOracle} from "../movva/ScaledFxBandOracle.sol";
import {IAggregatorV3} from "../ramp/ChainlinkBrlOracle.sol";
import {ReclaimZkTlsVerifier} from "../ramp/ReclaimZkTlsVerifier.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";
import {IssuerFreeze} from "../common/IssuerFreeze.sol";
import {Movva} from "../movva/Movva.sol";
import {MovvaReserve} from "../movva/MovvaReserve.sol";
import {NodeRewards} from "../ramp/NodeRewards.sol";

/**
 * @notice Deploy the Phase 2 ramp, wired.
 *
 * The wiring is the point. Six contracts deployed correctly and connected wrongly is a
 * broken ramp that looks deployed: a registry that does not recognise its escrow silently
 * stops recording reputation, an escrow with no allowlisted verifier accepts no offers at
 * all, and an escrow with no arbitrator has a dispute path that can be entered and never
 * left. Every one of those is a configuration mistake rather than a bug, which is exactly
 * why it belongs in a script rather than in a runbook someone follows by hand at 2am.
 *
 * The script asserts the wiring afterwards and reverts if any of it is wrong, so a
 * half-configured deployment fails loudly instead of going live.
 *
 * ## Governance delay
 *
 * Every contract here that holds value or decides what releases it delays risk-increasing
 * changes by GOVERNANCE_DELAY (default 48 hours; see DelayedGovernance). A new contract
 * starts in setup, where changes are instant and user business is refused; this script
 * wires everything in that window and then closes setup on each contract before handing it
 * over. So after this script, adding a verifier, arbitrator, attestor, bank endpoint, asset,
 * escrow or LP takes the delay - including for the real governor on day one. Phase A LPs
 * known at deploy time can be admitted here instead (INSTITUTIONAL_LPS).
 *
 * ## Dispute timeout
 *
 * Both escrows take an immutable DISPUTE_TIMEOUT (default 30 days, bounded 7-90 days by the
 * contracts): after it, an unruled dispute can be expired by anyone to its default refund. It
 * must comfortably exceed the arbitration desk's response window plus the time to rule and
 * submit - see docs/runbook-incidents.md - and it cannot be changed without redeploying.
 *
 * ## Prices on Ethereum L1: one FX rate, a Chainlink feed per asset
 *
 * `ORACLE_KIND=signed-fx` is the L1 configuration (the name predates Pyth). ONE number, BRL per US
 * dollar, is the "FX leg", and each asset's band is a ChainlinkSignedFxOracle crossing its Chainlink
 * ASSET/USD feed with that leg - ETH through CHAINLINK_ETH_USD, and every token in USD_FEED_ASSETS
 * through its own feed. Each feed's max age must be chosen for that feed's heartbeat, so there is no
 * default: the mainnet USDT/USD feed answers once a day while the peg holds (see
 * ChainlinkSignedFxOracle), ETH/USD hourly. USD_FEED_ASSETS also works with the other kinds; the FX
 * leg is deployed when first needed.
 *
 * The FX leg comes from Pyth by default (Mova's decision, 14 September 2026): a PythFxOracle over
 * FX.USD/BRL on PYTH, which the Pyth keeper keeps posted, read by the crosses through a centavo
 * ScaledFxBandOracle - so off-hours the bands take the last close (PythFxOracle). FX_SOURCE=signed
 * deploys a SignedPriceOracle signed by PRICE_PUBLISHERS instead.
 *
 *   ORACLE_KIND=signed-fx  CHAINLINK_ETH_USD=0x..  ETH_USD_MAX_AGE=4500  FX_MAX_AGE=3600
 *   PYTH=0x4305FB66699C3B2702D4d05CF36551390A4c69C6   PYTH_USD_BRL_ID (defaults to FX.USD/BRL)
 *   PYTH_MAX_CONF_BPS=100  FX_CLOSED_MAX_AGE=345600   (or FX_SOURCE=signed PRICE_PUBLISHERS=0x..,0x..)
 *   USD_FEED_ASSETS=0xdAC17F958D2ee523a2206206994597C13D831ec7            (USDT)
 *   USD_FEEDS=0x3E7d1eAB13ad0104d2750B8863b489D65364e32D                  (Chainlink USDT/USD)
 *   USD_FEED_MAX_AGES=90000                                                (24h heartbeat + 1h)
 *
 * A feed-priced token's decimals are read from the token, never typed in: they are fixed on the
 * escrows at first listing (SR2-13), so a wrong number could not be corrected afterwards.
 *
 * ## Every oracle deployed here waits too
 *
 * The FX leg, each ChainlinkSignedFxOracle and the ETH oracle of any kind are DelayedGovernance
 * contracts with the same GOVERNANCE_DELAY. Adding a publisher, lowering its threshold, repointing a
 * feed or leg, or loosening a max age waits, as pointing an escrow at a different oracle already did:
 * an instant swap inside the oracle was that change without the notice. Their setup closes here with
 * the rest, and until it does they refuse to price, so a deployment that skipped it cannot trade.
 *
 * ## Movva, optionally: its own escrow pair
 *
 *   MOVVA_RESERVE=0x..  MOVVA_TOKEN=0x..   both exactly as DeployMovva printed them
 *   MOVVA_PP_ENTRYPOINT=0x..               the Entrypoint the Movva Privacy Pool is registered on
 *   MOVVA_BAND_BPS=300                     optional: at least 100, and below BAND_BPS
 *
 * Movva is listed on a SECOND FiatEscrow / OffRampEscrow pair, with the reserve itself as its band
 * oracle (docs/movva.md, "Contracts") - not on the pair above. BAND_BPS is an immutable of each
 * escrow and applies to every asset listed on it. ETH and USDT need room for real desk spreads (500
 * by default); Movva's mid is R$ 1,00 x min(1, collateral ratio), and a 5% band lets an LP sell a
 * fully backed Movva at R$ 1,05 or buy it at R$ 0,95 - not a peg. A tight band therefore forces a
 * pair. It shares this deployment's registry (credit is one number across the product: a second
 * registry would let an LP take its full limit twice), verifiers and arbitrator; native ETH, which
 * every escrow lists at construction, is delisted on it.
 *
 * The pair is constructed with the RESERVE as its `oracle` argument. That argument's only use in
 * either escrow is the native-ETH listing the constructor makes (`ORACLE` is stored and read by no
 * function; every band check reads the asset's own `assets[asset].oracle`), and that listing is
 * delisted here during setup and asserted delisted. So the Movva pair depends on no ETH band oracle
 * and no Chainlink ETH/USD feed. Re-enabling native ETH would be a risk-increasing `setAsset`: it
 * waits out the delay, and once the governor is renounced nobody can.
 *
 * ## Movva only: MAIN_PAIR=off
 *
 *   MAIN_PAIR=off   deploy no ETH/USDT pair: no band oracle of any kind, no FX leg, no feed
 *                   oracles, no main FiatEscrow / OffRampEscrow. Only the registry, the zkTLS
 *                   verifier and the Movva pair (client decision, 14 October 2026: the Sepolia rail
 *                   is deposit PIX -> mint Movva -> shielded notes -> withdraw to PIX).
 *
 * It requires MOVVA_RESERVE (there would be nothing to deploy otherwise) and refuses ORACLE_KIND,
 * USD_FEED_ASSETS and ASSETS, which configure the main pair it does not deploy: a setting that
 * would silently do nothing is refused instead. PP_ENTRYPOINT, PP_POOL and BAND_BPS are not read.
 *
 * The band's floor is set by the unit. The mid is whole centavos, at most 100, and the escrow
 * refuses `diff * 10_000 > mid * BAND_BPS`, so a band admits one centavo either side only while
 * `mid >= 10_000 / BAND_BPS`. Below 100 bps no price but the mid passes even at par.
 *
 * The default is 300, because the band must leave an LP room to BUY below what redeeming pays, or
 * nobody buys Movva back exactly when holders want out. The mid is the reserve's ratio rounded to the
 * NEAREST centavo, so at 98.56% backing it is 99 while a redemption pays 98.56. At 100 bps only 99
 * passes - above the redemption value - and no LP claims a sale (found building the wallet's sale
 * path). At 300 bps the lowest admitted price is at least ~1.5% under the redemption value at every
 * ratio (worst at x.5%, e.g. 98.5% -> mid 99 -> 97 admitted), and at par offers pass at 97-103.
 * That is wider than a peg, and it does not need to be one: the price a user gets is set by LPs
 * competing in the matcher and checked by the wallet before anything is locked; the band only bounds
 * a fat finger.
 *
 * Listing happens here rather than in DeployMovva because it is only instant during setup, and only
 * this script deploys escrows. Against a live ramp, listing Movva is a scheduled change on each
 * escrow (`gov:schedule escrow:asset ...`), and a new pair also waits on the registry's `setEscrow`.
 * The escrows' Privacy Pool entrypoint is immutable too, so the script refuses one with no Movva
 * pool registered rather than deploy a pair whose shielded deliveries could never work.
 *
 * ## Node-provider rewards, optionally
 *
 *   NODE_REWARDS=0x..   the NodeRewards DeployMovva reported
 *
 * The registry's rewards hook is set to it during setup, so every settlement the registry records is reported
 * there (LPRegistry, "Rewards hook"). The script refuses a NodeRewards with no code, one whose setup is open or whose
 * governance delay is shorter than GOVERNANCE_DELAY, and - with MOVVA_TOKEN - one that does not pay Movva. The hook
 * alone counts nothing: NodeRewards accepts reports only from the registry its governor binds, with
 * `admin rewards:registry <rewards> <registry>` once this script has printed the registry - immediate while NodeRewards
 * has never been funded, a scheduled change after that.
 *
 *   ORACLE_KIND=chainlink|pyth|signed|signed-fx   GOVERNANCE_DELAY=172800 (seconds)
 *   DISPUTE_TIMEOUT=2592000 (seconds)
 *   ZKTLS_PROVIDER_HASHES=...  ZKTLS_URL_PREFIXES=...   (required, no default)
 *   ZKTLS_ENDPOINT_RAILS=2,6   (optional: rail mask per endpoint, default PIX only = 2;
 *                               6 = PIX + BOLETO. Masks are over IAttestorVerifier.Rail)
 *   INSTITUTIONAL_LPS=0xlp1,0xlp2  INSTITUTIONAL_CREDIT_CENTS=500000,500000   (optional)
 *   forge script contracts/script/DeployRamp.s.sol:DeployRamp --rpc-url $RPC --broadcast
 */
contract DeployRamp is Script {
    /// @notice Pyth's FX.USD/BRL price id: reais per US dollar.
    bytes32 internal constant PYTH_FX_USD_BRL = 0xd2db4dbf1aea74e0f666b0e8f73b9580d407f5e5cf931940b06dc633d7a95906;

    /// @dev Grouped so the deployment stays under the stack limit without via-ir, which
    ///      would change the bytecode of every contract in the repo for one script's sake.
    struct Config {
        address governor;
        address ppEntrypoint;
        uint256 bandBps;
        address arbitrator;
    }

    struct Deployed {
        address oracle;
        /// Movva's pair (see "Movva, optionally"): zero unless MOVVA_RESERVE is set.
        FiatEscrow movvaOnramp;
        OffRampEscrow movvaOfframp;
        /// BRL centavos per US dollar, what the crosses read; zero unless something crosses with it. The
        /// centavo adapter over a PythFxOracle, or a SignedPriceOracle itself.
        address fxLeg;
        /// The governed oracle behind fxLeg: the PythFxOracle, or fxLeg itself when signed.
        address fxSource;
        /// Tokens listed with a ChainlinkSignedFxOracle, and those oracles, index for index.
        address[] feedAssets;
        address[] feedOracles;
        LPRegistry registry;
        ReclaimZkTlsVerifier zktls;
        FiatEscrow onramp;
        OffRampEscrow offramp;
    }

    function run() external {
        Config memory cfg = Config({
            governor: vm.envAddress("GOVERNOR"),
            ppEntrypoint: _mainPair() ? vm.envAddress("PP_ENTRYPOINT") : address(0),
            bandBps: vm.envOr("BAND_BPS", uint256(500)),
            arbitrator: vm.envAddress("ARBITRATOR")
        });

        _refuseUnsafeMainPairOff();
        _refuseUnsafeMovva(cfg.bandBps);
        _refuseUnsafeRewards();

        // Deploy owning everything, wire it, THEN hand the governor role over.
        //
        // The obvious version - deploy straight to the final governor and configure
        // afterwards - cannot work: every setter is onlyGovernor, so the deployer is locked
        // out of its own deployment the moment the constructor runs. That failed on the
        // first real run of this script, which is the argument for having a script at all.
        vm.startBroadcast();
        // The address the transactions actually come from. Under `forge script` this is the
        // same as msg.sender; asking the broadcast rather than assuming it also holds when
        // the script is run from DeployRamp.t.sol.
        (, address deployer,) = vm.readCallers();
        Deployed memory d = _deployAll(deployer);
        _wire(d, cfg.arbitrator);
        _completeSetup(d);
        _handOver(d, cfg.governor);
        vm.stopBroadcast();

        _assertWired(d, cfg.arbitrator, cfg.governor);
        _report(d);
    }

    function _deployAll(address owner) private returns (Deployed memory d) {
        uint256 delay = _governanceDelay();
        if (_mainPair()) {
            d.oracle = _deployOracle(owner, d);
            _deployFeedOracles(owner, d);
        }
        d.registry = new LPRegistry(owner, delay);
        (bytes32[] memory providerHashes, string[] memory urlPrefixes) = _zkTlsEndpoints();
        d.zktls = new ReclaimZkTlsVerifier(
            owner,
            delay,
            vm.envAddress("ZKTLS_WITNESSES", ","),
            vm.envOr("ZKTLS_THRESHOLD", uint256(2)),
            providerHashes,
            urlPrefixes
        );
        if (_mainPair()) _deployMainPair(owner, d);
        _deployMovvaPair(owner, d);
    }

    /// @notice False with MAIN_PAIR=off: only the Movva pair is deployed (see "Movva only").
    function _mainPair() private view returns (bool) {
        return keccak256(bytes(vm.envOr("MAIN_PAIR", string("on")))) != keccak256("off");
    }

    /// @dev Before anything is broadcast: MAIN_PAIR=off with something only the main pair would use is refused.
    function _refuseUnsafeMainPairOff() private view {
        if (_mainPair()) return;
        require(
            vm.envOr("MOVVA_RESERVE", address(0)) != address(0),
            "MAIN_PAIR=off: set MOVVA_RESERVE, or there is no pair to deploy"
        );
        require(
            bytes(vm.envOr("ORACLE_KIND", string(""))).length == 0,
            "MAIN_PAIR=off: ORACLE_KIND configures the main pair's band oracle, which is not deployed; unset it"
        );
        require(
            vm.envOr("USD_FEED_ASSETS", ",", new address[](0)).length == 0
                && vm.envOr("ASSETS", ",", new address[](0)).length == 0,
            "MAIN_PAIR=off: USD_FEED_ASSETS / ASSETS list assets on the main pair, which is not deployed; unset them"
        );
    }

    function _deployMainPair(address owner, Deployed memory d) private {
        uint256 delay = _governanceDelay();
        d.onramp = new FiatEscrow(
            d.oracle,
            address(d.registry),
            vm.envAddress("PP_ENTRYPOINT"),
            // The pool, not the entrypoint: `ragequit` lives on PrivacyPool, and the
            // shielded escape hatch calls it directly.
            vm.envAddress("PP_POOL"),
            vm.envOr("BAND_BPS", uint256(500)),
            owner,
            delay,
            _disputeTimeout()
        );
        d.offramp = new OffRampEscrow(
            d.oracle,
            address(d.registry),
            vm.envOr("BAND_BPS", uint256(500)),
            owner,
            delay,
            _disputeTimeout()
        );
    }

    function _governanceDelay() private view returns (uint256) {
        return vm.envOr("GOVERNANCE_DELAY", uint256(48 hours));
    }

    function _disputeTimeout() private view returns (uint256) {
        return vm.envOr("DISPUTE_TIMEOUT", uint256(30 days));
    }

    /// @dev Last step, and irreversible from the deployer's side. Anything not configured
    ///      before this line needs the real governor to do it - through the delay.
    ///
    ///      The oracle is handed over too. It was not: the deployer kept `setFeeds` /
    ///      `setPublisher` on every deployment, and nothing checked.
    function _handOver(Deployed memory d, address governor) private {
        d.registry.transferGovernor(governor);
        d.zktls.transferGovernor(governor);
        if (address(d.onramp) != address(0)) {
            d.onramp.transferGovernor(governor);
            d.offramp.transferGovernor(governor);
        }
        if (d.oracle != address(0)) DelayedGovernance(d.oracle).transferGovernor(governor);
        if (d.fxSource != address(0)) DelayedGovernance(d.fxSource).transferGovernor(governor);
        for (uint256 i; i < d.feedOracles.length; ++i) {
            DelayedGovernance(d.feedOracles[i]).transferGovernor(governor);
        }
        if (address(d.movvaOnramp) != address(0)) {
            d.movvaOnramp.transferGovernor(governor);
            d.movvaOfframp.transferGovernor(governor);
        }
    }

    /// @dev Ends the instant-change window on every delayed contract. Until this runs they
    ///      refuse all user business - for the oracles, reading a price - so a deployment that
    ///      skips it fails closed.
    function _completeSetup(Deployed memory d) private {
        d.registry.completeSetup();
        d.zktls.completeSetup();
        if (address(d.onramp) != address(0)) {
            d.onramp.completeSetup();
            d.offramp.completeSetup();
        }
        if (d.oracle != address(0)) DelayedGovernance(d.oracle).completeSetup();
        if (d.fxSource != address(0)) DelayedGovernance(d.fxSource).completeSetup();
        for (uint256 i; i < d.feedOracles.length; ++i) {
            DelayedGovernance(d.feedOracles[i]).completeSetup();
        }
        if (address(d.movvaOnramp) != address(0)) {
            d.movvaOnramp.completeSetup();
            d.movvaOfframp.completeSetup();
        }
    }

    function _wire(Deployed memory d, address arbitrator) private {

        // Settlements on every escrow this registry accepts - the Movva pair's too - reach the rewards contract.
        address rewards = vm.envOr("NODE_REWARDS", address(0));
        if (rewards != address(0)) d.registry.setRewardsHook(rewards);

        if (address(d.onramp) != address(0)) {
            // Both escrows report to one registry, so reputation is the LP's across the whole
            // product rather than per-leg. The registry ignores reports from anyone else.
            d.registry.setEscrow(address(d.onramp), true);
            d.registry.setEscrow(address(d.offramp), true);

            _listAssets(d);

            d.onramp.setVerifier(address(d.zktls), true);
            d.onramp.setArbitrator(arbitrator, true);

            d.offramp.setVerifier(address(d.zktls), true);
            d.offramp.setArbitrator(arbitrator, true);
        }

        _setEndpointRails(d);
        _admitInstitutions(d);
        _wireMovva(d, arbitrator);
    }

    /**
     * @dev Which rails each bank endpoint may attest. The verifier allows a new endpoint for
     *      PIX alone; a boleto receipt template has to be widened explicitly, here during
     *      setup or later through the delay. Unset keeps every endpoint PIX-only, which is
     *      the narrow direction: a forgotten variable refuses boletos, it never admits them.
     */
    function _setEndpointRails(Deployed memory d) private {
        uint256[] memory rails = vm.envOr("ZKTLS_ENDPOINT_RAILS", ",", new uint256[](0));
        if (rails.length == 0) return;
        bytes32[] memory hashes = vm.envBytes32("ZKTLS_PROVIDER_HASHES", ",");
        require(rails.length == hashes.length, "ZKTLS_ENDPOINT_RAILS needs one mask per endpoint");
        for (uint256 i; i < rails.length; ++i) {
            require(rails[i] <= type(uint16).max, "ZKTLS_ENDPOINT_RAILS: mask is a uint16");
            if (rails[i] != 1 << 1) d.zktls.setEndpointRails(hashes[i], uint16(rails[i]));
        }
    }

    /**
     * @dev Phase A LPs known at deployment. Admitting them here, before setup closes, avoids
     *      a GOVERNANCE_DELAY wait before the first trade - and costs nothing in safety,
     *      because nobody can have funds in a contract that is still in setup, and the
     *      admissions are in the public deployment transactions.
     */
    function _admitInstitutions(Deployed memory d) private {
        address[] memory lps = vm.envOr("INSTITUTIONAL_LPS", ",", new address[](0));
        if (lps.length == 0) return;
        uint256[] memory credit = vm.envUint("INSTITUTIONAL_CREDIT_CENTS", ",");
        require(credit.length == lps.length, "INSTITUTIONAL_LPS and INSTITUTIONAL_CREDIT_CENTS must be the same length");
        for (uint256 i; i < lps.length; ++i) {
            d.registry.setTier(lps[i], LPRegistry.Tier.INSTITUTIONAL, credit[i]);
        }
    }

    function _report(Deployed memory d) private view {
        if (d.oracle != address(0)) console2.log("oracle          ", d.oracle);
        else console2.log("  MAIN_PAIR=off: no ETH/USDT pair, no band oracle, no FX leg");
        if (d.fxLeg != address(0)) console2.log("fx leg (BRL/USD)", d.fxLeg);
        if (d.fxSource != d.fxLeg) console2.log("  over PythFxOracle", d.fxSource);
        for (uint256 i; i < d.feedAssets.length; ++i) {
            console2.log("asset           ", d.feedAssets[i]);
            console2.log("  its oracle    ", d.feedOracles[i]);
        }
        console2.log("registry        ", address(d.registry));
        address rewards = d.registry.rewardsHook();
        if (rewards != address(0)) {
            console2.log("  rewards hook  ", rewards);
            console2.log("  NodeRewards counts nothing until its governor binds this registry:");
            console2.log("  admin rewards:registry %s %s", rewards, address(d.registry));
        }
        console2.log("zktls verifier  ", address(d.zktls));
        if (address(d.onramp) != address(0)) {
            console2.log("on-ramp escrow  ", address(d.onramp));
            console2.log("off-ramp escrow ", address(d.offramp));
        }
        if (address(d.movvaOnramp) != address(0)) {
            console2.log("movva FiatEscrow   ", address(d.movvaOnramp));
            console2.log("movva OffRampEscrow", address(d.movvaOfframp));
        }
    }

    /**
     * @dev Register ERC-20 settlement assets on both escrows.
     *
     * Without this a deployment is native-ETH-only however much ERC-20 support the
     * contracts carry, because an unlisted asset cannot be offered at all. Each asset needs
     * its OWN oracle: "BRL per ETH" is not "BRL per USDC", and a 6-decimal token priced
     * with 18-decimal math is wrong by a factor of a trillion.
     *
     *   ASSETS=0xtoken1,0xtoken2  ASSET_ORACLES=0xo1,0xo2  ASSET_DECIMALS=6,18
     *
     * ASSETS takes oracles deployed elsewhere, whose governors this script does not hold or
     * check. USD_FEED_ASSETS (see the header) deploys the oracles here and hands them over.
     */
    function _listAssets(Deployed memory d) private {
        for (uint256 i; i < d.feedAssets.length; ++i) {
            uint8 dec = _tokenDecimals(d.feedAssets[i]);
            d.onramp.setAsset(d.feedAssets[i], d.feedOracles[i], dec, true);
            d.offramp.setAsset(d.feedAssets[i], d.feedOracles[i], dec, true);
            _capAsset(d.onramp, d.offramp, d.feedAssets[i]);
        }
        address[] memory tokens = vm.envOr("ASSETS", ",", new address[](0));
        if (tokens.length == 0) return;
        address[] memory oracles = vm.envAddress("ASSET_ORACLES", ",");
        uint256[] memory decs = vm.envUint("ASSET_DECIMALS", ",");
        require(
            oracles.length == tokens.length && decs.length == tokens.length,
            "ASSETS, ASSET_ORACLES and ASSET_DECIMALS must be the same length"
        );
        for (uint256 i; i < tokens.length; ++i) {
            d.onramp.setAsset(tokens[i], oracles[i], uint8(decs[i]), true);
            d.offramp.setAsset(tokens[i], oracles[i], uint8(decs[i]), true);
            _capAsset(d.onramp, d.offramp, tokens[i]);
        }
    }

    /**
     * @dev The most each escrow may hold of a token, in base units (SR2-25):
     *
     *   ASSET_CAP_TOKENS=0xdAC17F958D2ee523a2206206994597C13D831ec7   ASSET_CAPS=250000000000
     *
     * Everything an escrow holds of a token whose issuer can freeze addresses is lost at once if
     * the escrow is listed, so such a token is refused here without a cap: "no cap" should be a
     * decision, not the result of a missing variable. Set during setup, the caps are instant;
     * afterwards lowering one stays instant and raising one waits out the governance delay.
     */
    function _capAsset(FiatEscrow onramp, OffRampEscrow offramp, address token) private {
        address[] memory tokens = vm.envOr("ASSET_CAP_TOKENS", ",", new address[](0));
        uint256[] memory caps = vm.envOr("ASSET_CAPS", ",", new uint256[](0));
        require(tokens.length == caps.length, "ASSET_CAP_TOKENS and ASSET_CAPS must be the same length");
        for (uint256 i; i < tokens.length; ++i) {
            if (tokens[i] != token) continue;
            require(caps[i] > 0, "ASSET_CAPS: a cap of 0 means no cap; leave the token out instead");
            onramp.setAssetCap(token, caps[i]);
            offramp.setAssetCap(token, caps[i]);
            return;
        }
        require(
            !_hasIssuerBlacklist(token),
            "a listed token's issuer can freeze the escrow: give it a cap in ASSET_CAP_TOKENS / ASSET_CAPS"
        );
    }

    /// @dev True when the token answers Tether's or Circle's blacklist query at all.
    function _hasIssuerBlacklist(address token) private view returns (bool) {
        bytes4[2] memory selectors = [IssuerFreeze.TETHER, IssuerFreeze.CIRCLE];
        for (uint256 i; i < 2; ++i) {
            (bool ok, bytes memory ret) = token.staticcall{gas: IssuerFreeze.PROBE_GAS}(
                abi.encodeWithSelector(selectors[i], address(0))
            );
            if (ok && ret.length >= 32) return true;
        }
        return false;
    }

    /**
     * @dev The bank endpoints the zkTLS verifier accepts. Deliberately has NO default.
     *
     * This read `ZKTLS_PROVIDER` with a default of "http", and every real Reclaim HTTP claim
     * has provider "http" - so an unconfigured deployment accepted a TLS session with any
     * server at all. An allowlist nobody chose is not an allowlist; `vm.envBytes32` reverts
     * when the variable is unset, which is the behaviour wanted.
     *
     *   ZKTLS_PROVIDER_HASHES=0xhash1,0xhash2   Reclaim providerHash of each bank template
     *   ZKTLS_URL_PREFIXES=https://api.bank1.example/pix/,https://api.bank2.example/v1/
     */
    function _zkTlsEndpoints() private view returns (bytes32[] memory hashes, string[] memory prefixes) {
        hashes = vm.envBytes32("ZKTLS_PROVIDER_HASHES", ",");
        prefixes = vm.envString("ZKTLS_URL_PREFIXES", ",");
        require(hashes.length > 0, "ZKTLS_PROVIDER_HASHES is empty: the zkTLS verifier needs bank endpoints");
        require(
            hashes.length == prefixes.length,
            "ZKTLS_PROVIDER_HASHES and ZKTLS_URL_PREFIXES must be the same length"
        );
    }

    /**
     * @dev The FX leg: BRL centavos per ONE US DOLLAR, and nothing else. One instance serves every
     *      ChainlinkSignedFxOracle in the deployment. By default a PythFxOracle in millionths behind a
     *      centavo ScaledFxBandOracle - the adapter reads it as a band, so the crosses keep pricing on
     *      the last close off-hours. With FX_SOURCE=signed, a SignedPriceOracle publishers sign in
     *      centavos.
     */
    function _fxLeg(address governor, Deployed memory d) private returns (address) {
        if (d.fxLeg != address(0)) return d.fxLeg;
        if (keccak256(bytes(vm.envOr("FX_SOURCE", string("pyth")))) == keccak256("signed")) {
            d.fxLeg = address(
                new SignedPriceOracle(
                    governor,
                    _governanceDelay(),
                    vm.envAddress("PRICE_PUBLISHERS", ","),
                    vm.envOr("PRICE_THRESHOLD", uint256(2))
                )
            );
            d.fxSource = d.fxLeg;
            return d.fxLeg;
        }
        address pyth = vm.envAddress("PYTH");
        require(pyth.code.length > 0, "PYTH: no Pyth contract at that address on this chain (or FX_SOURCE=signed)");
        uint256 conf = vm.envOr("PYTH_MAX_CONF_BPS", uint256(100));
        require(conf <= type(uint16).max, "PYTH_MAX_CONF_BPS: basis points");
        uint256 closed = vm.envOr("FX_CLOSED_MAX_AGE", uint256(4 days));
        require(closed <= 4 days, "FX_CLOSED_MAX_AGE: above 4 days, which is no longer a market closure");
        d.fxSource = address(
            new PythFxOracle(
                pyth,
                vm.envOr("PYTH_USD_BRL_ID", vm.envOr("PYTH_BRL_USD_ID", PYTH_FX_USD_BRL)),
                _fxMaxAge(),
                uint64(closed),
                uint16(conf),
                governor,
                _governanceDelay()
            )
        );
        d.fxLeg = address(new ScaledFxBandOracle(IPriceOracle(d.fxSource)));
        return d.fxLeg;
    }

    function _fxMaxAge() private view returns (uint64) {
        return _age(vm.envOr("FX_MAX_AGE", uint256(1 hours)), "FX_MAX_AGE");
    }

    function _age(uint256 v, string memory name) private pure returns (uint64) {
        require(v > 0 && v <= type(uint64).max, string.concat(name, ": a max age is seconds, above zero"));
        return uint64(v);
    }

    /**
     * @dev A ChainlinkSignedFxOracle per token in USD_FEED_ASSETS. Refuses, at deploy time, a
     *      token with no code (a typo, or the wrong chain) and a feed this deployment could not
     *      use: one that reverts when read from a contract - the BRL/USD aggregator's "No
     *      access" in OracleFork.t.sol - answers non-positive, or is already older than the max
     *      age chosen for it.
     */
    function _deployFeedOracles(address governor, Deployed memory d) private {
        address[] memory tokens = vm.envOr("USD_FEED_ASSETS", ",", new address[](0));
        if (tokens.length == 0) return;
        // No defaults: a max age nobody chose for this feed's heartbeat is not a max age.
        address[] memory feeds = vm.envAddress("USD_FEEDS", ",");
        uint256[] memory ages = vm.envUint("USD_FEED_MAX_AGES", ",");
        require(
            feeds.length == tokens.length && ages.length == tokens.length,
            "USD_FEED_ASSETS, USD_FEEDS and USD_FEED_MAX_AGES must be the same length"
        );
        address fx = _fxLeg(governor, d);
        d.feedAssets = tokens;
        d.feedOracles = new address[](tokens.length);
        for (uint256 i; i < tokens.length; ++i) {
            require(tokens[i].code.length > 0, "USD_FEED_ASSETS: no contract at that address on this chain");
            uint64 maxAge = _age(ages[i], "USD_FEED_MAX_AGES");
            _requireUsableFeed(feeds[i], maxAge, "USD_FEEDS");
            d.feedOracles[i] =
                address(new ChainlinkSignedFxOracle(feeds[i], fx, maxAge, _fxMaxAge(), governor, _governanceDelay()));
        }
    }

    function _requireUsableFeed(address feed, uint64 maxAge, string memory name) private view {
        (, int256 answer,, uint256 at,) = IAggregatorV3(feed).latestRoundData();
        require(answer > 0, string.concat(name, ": feed answers zero or less"));
        require(at != 0 && block.timestamp <= at + maxAge, string.concat(name, ": feed is older than its max age"));
        require(IAggregatorV3(feed).decimals() <= 18, string.concat(name, ": feed decimals out of range"));
    }

    /// @dev Tether's `decimals` is a uint256 public variable; decoded wide, then range-checked.
    function _tokenDecimals(address token) private view returns (uint8) {
        (bool ok, bytes memory ret) = token.staticcall(abi.encodeWithSignature("decimals()"));
        require(ok && ret.length >= 32, "USD_FEED_ASSETS: token has no decimals()");
        uint256 dec = abi.decode(ret, (uint256));
        require(dec > 0 && dec <= 36, "USD_FEED_ASSETS: token decimals out of range");
        return uint8(dec);
    }

    function _deployOracle(address governor, Deployed memory d) private returns (address) {
        string memory kind = vm.envOr("ORACLE_KIND", string("chainlink"));
        // The L1 configuration: ETH's band is Chainlink ETH/USD times the signed FX rate.
        if (keccak256(bytes(kind)) == keccak256("signed-fx")) {
            address ethUsd = vm.envAddress("CHAINLINK_ETH_USD");
            uint64 maxAge = _age(vm.envUint("ETH_USD_MAX_AGE"), "ETH_USD_MAX_AGE");
            _requireUsableFeed(ethUsd, maxAge, "CHAINLINK_ETH_USD");
            return address(
                new ChainlinkSignedFxOracle(ethUsd, _fxLeg(governor, d), maxAge, _fxMaxAge(), governor, _governanceDelay())
            );
        }
        // `signed` is for chains with no maintained BRL feed - which today includes Ethereum
        // mainnet. See SignedPriceOracle for what that trade actually costs.
        if (keccak256(bytes(kind)) == keccak256("signed")) {
            return address(
                new SignedPriceOracle(
                    governor,
                    _governanceDelay(),
                    vm.envAddress("PRICE_PUBLISHERS", ","),
                    vm.envOr("PRICE_THRESHOLD", uint256(2))
                )
            );
        }
        if (keccak256(bytes(kind)) == keccak256("pyth")) {
            return address(
                new PythBrlOracle(
                    vm.envAddress("PYTH"),
                    vm.envBytes32("PYTH_ETH_USD_ID"),
                    // Pyth quotes FX.USD/BRL (BRL per USD). The env name states that direction; the old
                    // name PYTH_BRL_USD_ID said the reverse, the same mistake that inverted the
                    // adapter. It is still accepted so an existing deployment config keeps working.
                    vm.envOr("PYTH_USD_BRL_ID", vm.envOr("PYTH_BRL_USD_ID", bytes32(0))),
                    vm.envOr("PRICE_MAX_AGE", uint256(3600)),
                    vm.envOr("PYTH_MAX_CONF_BPS", uint256(200)),
                    governor,
                    _governanceDelay()
                )
            );
        }
        return address(
            new ChainlinkBrlOracle(
                vm.envAddress("CHAINLINK_ETH_USD"),
                vm.envAddress("CHAINLINK_BRL_USD"),
                uint64(vm.envOr("PRICE_MAX_AGE", uint256(3600))),
                governor,
                _governanceDelay()
            )
        );
    }

    /// @dev Fail the deployment rather than hand over something half-configured.
    function _assertWired(Deployed memory d, address arbitrator, address governor)
        private
        view
    {
        require(d.registry.governor() == governor, "registry: governor not handed over");
        require(d.zktls.governor() == governor, "zktls: governor not handed over");
        _assertDelayed(address(d.registry), "registry");
        _assertDelayed(address(d.zktls), "zktls");
        require(d.zktls.endpointCount() > 0, "zktls: no bank endpoints allowlisted");
        require(d.registry.phase() == LPRegistry.Phase.A, "registry: must launch in Phase A");
        require(d.registry.rewardsHook() == vm.envOr("NODE_REWARDS", address(0)), "registry: rewards hook differs from NODE_REWARDS");
        if (_mainPair()) {
            _assertMainPair(d, arbitrator, governor);
        } else {
            require(
                d.oracle == address(0) && d.fxLeg == address(0) && d.feedOracles.length == 0 && address(d.onramp) == address(0)
                    && address(d.offramp) == address(0),
                "MAIN_PAIR=off: a main-pair contract was deployed"
            );
            require(address(d.movvaOnramp) != address(0), "MAIN_PAIR=off: no Movva pair deployed");
        }
        _assertMovva(d, arbitrator, governor);
    }

    function _assertMainPair(Deployed memory d, address arbitrator, address governor) private view {
        require(d.onramp.governor() == governor, "on-ramp: governor not handed over");
        require(d.offramp.governor() == governor, "off-ramp: governor not handed over");
        require(
            DelayedGovernance(d.oracle).governor() == governor,
            "oracle: governor not handed over, the deployer could still change the band"
        );
        _assertDelayed(d.oracle, "oracle");
        _assertDelayed(address(d.onramp), "on-ramp");
        _assertDelayed(address(d.offramp), "off-ramp");
        require(d.registry.isEscrow(address(d.onramp)), "registry does not accept the on-ramp");
        require(
            d.registry.isEscrow(address(d.offramp)),
            "registry does not accept the off-ramp: its settlements would build no reputation"
        );
        require(d.onramp.allowedVerifier(address(d.zktls)), "on-ramp: zktls not allowed");
        require(d.offramp.allowedVerifier(address(d.zktls)), "off-ramp: zktls not allowed");
        require(d.onramp.arbitratorSince(arbitrator) != 0, "on-ramp: no arbitrator, disputes stick");
        require(d.offramp.arbitratorSince(arbitrator) != 0, "off-ramp: no arbitrator, disputes stick");
        require(
            d.onramp.DISPUTE_TIMEOUT() == _disputeTimeout()
                && d.offramp.DISPUTE_TIMEOUT() == _disputeTimeout(),
            "escrows: dispute timeout differs from DISPUTE_TIMEOUT"
        );
        require(address(d.onramp.ORACLE()) != address(0), "on-ramp: no oracle");
        require(address(d.offramp.ORACLE()) != address(0), "off-ramp: no oracle");
        _assertFeedAssets(d, governor);
    }

    /// @dev The FX leg and every feed-priced asset: handed over, crossed with the one FX leg,
    ///      and listed on BOTH escrows with that oracle and the token's own decimals.
    function _assertFeedAssets(Deployed memory d, address governor) private view {
        if (d.fxLeg == address(0)) return;
        require(
            DelayedGovernance(d.fxSource).governor() == governor,
            "fx leg: governor not handed over, the deployer could still change its source"
        );
        _assertDelayed(d.fxSource, "fx leg");
        require(
            d.fxSource == d.fxLeg || address(ScaledFxBandOracle(d.fxLeg).SOURCE()) == d.fxSource,
            "fx leg: the centavo adapter does not read this deployment's Pyth leg"
        );
        if (keccak256(bytes(vm.envOr("ORACLE_KIND", string("chainlink")))) == keccak256("signed-fx")) {
            require(
                address(ChainlinkSignedFxOracle(d.oracle).usdBrl()) == d.fxLeg,
                "ETH oracle: not crossed with this deployment's FX leg"
            );
        }
        for (uint256 i; i < d.feedAssets.length; ++i) {
            ChainlinkSignedFxOracle o = ChainlinkSignedFxOracle(d.feedOracles[i]);
            require(o.governor() == governor, "asset oracle: governor not handed over");
            _assertDelayed(address(o), "asset oracle");
            require(address(o.usdBrl()) == d.fxLeg, "asset oracle: not crossed with this deployment's FX leg");
            uint8 dec = _tokenDecimals(d.feedAssets[i]);
            (address onOracle, uint8 onDec, bool onEnabled) = _assetOf(address(d.onramp), d.feedAssets[i]);
            (address offOracle, uint8 offDec, bool offEnabled) = _assetOf(address(d.offramp), d.feedAssets[i]);
            require(
                onOracle == address(o) && onDec == dec && onEnabled,
                "on-ramp: feed asset not listed with its oracle and decimals"
            );
            require(
                offOracle == address(o) && offDec == dec && offEnabled,
                "off-ramp: feed asset not listed with its oracle and decimals"
            );
        }
    }

    function _assetOf(address escrow, address token) private view returns (address oracle, uint8 dec, bool enabled) {
        (bool ok, bytes memory ret) = escrow.staticcall(abi.encodeWithSignature("assets(address)", token));
        require(ok, "escrow: assets() unreadable");
        (oracle, dec, enabled) = abi.decode(ret, (address, uint8, bool));
    }

    /// @dev Setup closed, and the delay the one users were promised.
    function _assertDelayed(address target, string memory name) private view {
        DelayedGovernance g = DelayedGovernance(target);
        require(g.setupComplete(), string.concat(name, ": setup still open, changes are instant"));
        require(
            g.GOVERNANCE_DELAY() == _governanceDelay(),
            string.concat(name, ": governance delay differs from GOVERNANCE_DELAY")
        );
    }

    /*//////////////////////////////////////////////////////////////
                                  MOVVA
    //////////////////////////////////////////////////////////////*/

    function _movvaBandBps() private view returns (uint256) {
        return vm.envOr("MOVVA_BAND_BPS", uint256(300));
    }

    /**
     * @dev Before anything is broadcast. The reserve must be the one DeployMovva deployed, and its band
     *      must not be changeable on less notice than these escrows give.
     *
     *      "The one DeployMovva deployed" is checked through the binding Movva makes: the token's only
     *      minter is the contract that deployed it, fixed in its constructor, and MovvaReserve deploys
     *      its token in its own. So MOVVA_TOKEN - the address DeployMovva printed - naming MOVVA_RESERVE
     *      as its minter, and the reserve naming that token, proves MOVVA_RESERVE is the reserve that
     *      run deployed. One pasted address is a typo away from any contract that answers MOVVA().
     */
    function _refuseUnsafeMovva(uint256 bandBps) private view {
        address reserve = vm.envOr("MOVVA_RESERVE", address(0));
        if (reserve == address(0)) return;
        require(reserve.code.length > 0, "MOVVA_RESERVE: no contract at that address on this chain");
        address movva = vm.envAddress("MOVVA_TOKEN");
        require(
            MovvaReserve(reserve).MOVVA() == movva,
            "MOVVA_RESERVE: its token is not MOVVA_TOKEN - not the reserve DeployMovva reported"
        );
        require(
            Movva(movva).RESERVE() == reserve,
            "MOVVA_TOKEN: its minter is not MOVVA_RESERVE - not the token DeployMovva reported"
        );
        // Fixed on the escrows at first listing (SR2-13): read, never assumed.
        require(
            IERC20Metadata(movva).decimals() == 18,
            "MOVVA_TOKEN: decimals are not 18, and a listing's decimals can never be corrected"
        );
        require(
            MovvaReserve(reserve).setupComplete(),
            "MOVVA_RESERVE: setup still open, its governor can change the band at once"
        );
        require(
            MovvaReserve(reserve).GOVERNANCE_DELAY() >= _governanceDelay(),
            "MOVVA_RESERVE: governance delay shorter than GOVERNANCE_DELAY, so the band could change on less notice than the escrows give"
        );
        // The rate behind the band. Its publishers are chosen by whoever governs that leg.
        address fx = address(MovvaReserve(reserve).fxOracle());
        (bool ok, bytes memory ret) = fx.staticcall(abi.encodeWithSignature("setupComplete()"));
        require(
            ok && ret.length >= 32 && abi.decode(ret, (bool)),
            "MOVVA_RESERVE: its FX leg's setup is open or its governance is not delayed, so who signs the band's rate could change at once"
        );
        require(
            DelayedGovernance(fx).GOVERNANCE_DELAY() >= _governanceDelay(),
            "MOVVA_RESERVE: its FX leg's governance delay is shorter than GOVERNANCE_DELAY"
        );
        uint256 band = _movvaBandBps();
        require(band >= 100, "MOVVA_BAND_BPS: below 100, a centavo band around R$ 1,00 admits only the mid itself");
        // With no main pair there is no BAND_BPS to be tighter than.
        require(
            !_mainPair() || band < bandBps,
            "MOVVA_BAND_BPS: not tighter than BAND_BPS, so there is no reason for a separate pair"
        );
        address entrypoint = vm.envAddress("MOVVA_PP_ENTRYPOINT");
        require(entrypoint.code.length > 0, "MOVVA_PP_ENTRYPOINT: no contract at that address on this chain");
        // slither-disable-next-line unused-return
        (address pool,,,) = IEntrypointAssets(entrypoint).assetConfig(movva);
        require(
            pool != address(0),
            "MOVVA_PP_ENTRYPOINT: no Movva pool registered there, and the escrow's entrypoint is immutable"
        );
    }

    /// @dev Before anything is broadcast: the rewards contract must be closed, as slow to change as the ramp, and paid in Movva.
    function _refuseUnsafeRewards() private view {
        address rewards = vm.envOr("NODE_REWARDS", address(0));
        if (rewards == address(0)) return;
        require(rewards.code.length > 0, "NODE_REWARDS: no contract at that address on this chain");
        (bool ok, bytes memory ret) = rewards.staticcall(abi.encodeWithSignature("setupComplete()"));
        require(
            ok && ret.length >= 32 && abi.decode(ret, (bool)),
            "NODE_REWARDS: setup still open, or its governance is not delayed: its limits could change at once"
        );
        require(
            DelayedGovernance(rewards).GOVERNANCE_DELAY() >= _governanceDelay(),
            "NODE_REWARDS: governance delay shorter than GOVERNANCE_DELAY"
        );
        address movva = vm.envOr("MOVVA_TOKEN", address(0));
        if (movva != address(0)) {
            require(address(NodeRewards(rewards).REWARD_TOKEN()) == movva, "NODE_REWARDS: does not pay MOVVA_TOKEN");
        }
    }

    function _deployMovvaPair(address owner, Deployed memory d) private {
        if (vm.envOr("MOVVA_RESERVE", address(0)) == address(0)) return;
        address entrypoint = vm.envAddress("MOVVA_PP_ENTRYPOINT");
        // `rescueShielded` is told the pool; POOL records the one Movva deliveries land in.
        (address pool,,,) = IEntrypointAssets(entrypoint).assetConfig(vm.envAddress("MOVVA_TOKEN"));
        // Every escrow lists native ETH at construction, with its `oracle` argument; _wireMovva delists it. That
        // listing is the argument's only use (see "Movva, optionally"), so the reserve is passed: the pair then
        // depends on no ETH band oracle, and none need be deployed for it.
        address reserve = vm.envAddress("MOVVA_RESERVE");
        d.movvaOnramp = new FiatEscrow(
            reserve, address(d.registry), entrypoint, pool, _movvaBandBps(), owner, _governanceDelay(), _disputeTimeout()
        );
        d.movvaOfframp =
            new OffRampEscrow(reserve, address(d.registry), _movvaBandBps(), owner, _governanceDelay(), _disputeTimeout());
    }

    /**
     * @dev Movva with the reserve as its band, 18 decimals, on both escrows of the pair; native ETH
     *      delisted; the pair registered and given this deployment's verifiers and arbitrator.
     *
     *      No asset cap is required, and none is set unless ASSET_CAP_TOKENS names Movva. A cap bounds
     *      what an escrow loses at once when what it holds becomes unusable in place - an issuer
     *      freezing the escrow's address (SR2-25). Movva has no freeze, blacklist or pause, and the
     *      reserve cannot touch a balance it does not hold: `burn` destroys only its own. The reserve's
     *      governor does have powers - admitting gateways, fees, ratios, the oracle, the vault - but
     *      each moves Movva's backing for every holder alike, through the reserve's own delay; a cap on
     *      this escrow would not bound that, only strand LP liquidity beneath it. `_capAsset` still
     *      probes for an issuer blacklist, so a Movva that ever gains one is refused here without a
     *      cap, as USDT is.
     */
    function _wireMovva(Deployed memory d, address arbitrator) private {
        if (address(d.movvaOnramp) == address(0)) return;
        address movva = vm.envAddress("MOVVA_TOKEN");
        address reserve = vm.envAddress("MOVVA_RESERVE");
        d.registry.setEscrow(address(d.movvaOnramp), true);
        d.registry.setEscrow(address(d.movvaOfframp), true);
        d.movvaOnramp.setAsset(address(0), reserve, 18, false);
        d.movvaOfframp.setAsset(address(0), reserve, 18, false);
        d.movvaOnramp.setAsset(movva, reserve, 18, true);
        d.movvaOfframp.setAsset(movva, reserve, 18, true);
        _capAsset(d.movvaOnramp, d.movvaOfframp, movva);
        d.movvaOnramp.setVerifier(address(d.zktls), true);
        d.movvaOnramp.setArbitrator(arbitrator, true);
        d.movvaOfframp.setVerifier(address(d.zktls), true);
        d.movvaOfframp.setArbitrator(arbitrator, true);
    }

    function _assertMovva(Deployed memory d, address arbitrator, address governor) private view {
        if (address(d.movvaOnramp) == address(0)) return;
        _assertMovvaEscrow(address(d.movvaOnramp), d, arbitrator, governor, "movva on-ramp");
        _assertMovvaEscrow(address(d.movvaOfframp), d, arbitrator, governor, "movva off-ramp");
        require(
            d.movvaOnramp.POOL_ENTRYPOINT() == vm.envAddress("MOVVA_PP_ENTRYPOINT"),
            "movva on-ramp: not on the Movva pool's entrypoint"
        );
    }

    /// @dev The getters read here have the same selectors on both escrows, so FiatEscrow's serve both.
    function _assertMovvaEscrow(
        address escrow,
        Deployed memory d,
        address arbitrator,
        address governor,
        string memory name
    ) private view {
        FiatEscrow e = FiatEscrow(payable(escrow));
        require(e.governor() == governor, string.concat(name, ": governor not handed over"));
        _assertDelayed(escrow, name);
        require(
            d.registry.isEscrow(escrow),
            string.concat(name, ": the registry does not accept it, so its positions would not count against credit")
        );
        require(
            e.allowedVerifier(address(d.zktls)),
            string.concat(name, ": verifiers not allowed")
        );
        require(e.arbitratorSince(arbitrator) != 0, string.concat(name, ": no arbitrator, disputes stick"));
        require(e.DISPUTE_TIMEOUT() == _disputeTimeout(), string.concat(name, ": dispute timeout differs from DISPUTE_TIMEOUT"));
        require(e.BAND_BPS() == _movvaBandBps(), string.concat(name, ": band differs from MOVVA_BAND_BPS"));
        (address oracle, uint8 dec, bool enabled) = _assetOf(escrow, vm.envAddress("MOVVA_TOKEN"));
        require(
            oracle == vm.envAddress("MOVVA_RESERVE") && dec == 18 && enabled,
            string.concat(name, ": Movva not listed with the reserve as its band and 18 decimals")
        );
        (,, enabled) = _assetOf(escrow, address(0));
        require(!enabled, string.concat(name, ": native ETH is still listed on the Movva pair"));
        require(
            address(e.ORACLE()) == vm.envAddress("MOVVA_RESERVE"),
            string.concat(name, ": constructed with an oracle other than the reserve")
        );
    }

}
