// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Script} from "forge-std/Script.sol";
import {console2} from "forge-std/console2.sol";
import {IERC4626} from "@openzeppelin/contracts/interfaces/IERC4626.sol";
import {Movva} from "../movva/Movva.sol";
import {MovvaReserve} from "../movva/MovvaReserve.sol";
import {ScaledFxBandOracle} from "../movva/ScaledFxBandOracle.sol";
import {FeeSplitter} from "../movva/FeeSplitter.sol";
import {NodeRewards} from "../ramp/NodeRewards.sol";
import {SignedPriceOracle} from "../ramp/SignedPriceOracle.sol";
import {PythFxOracle} from "../ramp/PythFxOracle.sol";
import {IPriceOracle} from "../ramp/IPriceOracle.sol";
import {IAggregatorV3} from "../ramp/ChainlinkBrlOracle.sol";
import {DivergenceBreaker} from "../movva/DivergenceBreaker.sol";
import {IPriceSource} from "../movva/IPriceSource.sol";
import {UniswapV3TwapSource} from "../movva/sources/UniswapV3TwapSource.sol";
import {ChainlinkCrossSource} from "../movva/sources/ChainlinkCrossSource.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";

/**
 * @notice Deploy Movva: the reserve (which deploys the token), the FX leg in millionths - a
 *         PythFxOracle over Pyth's FX.USD/BRL by default, a signed quorum's, or an existing one - and
 *         the centavo adapter the ramps' band reads, and node-provider rewards (a FeeSplitter as the
 *         reserve's fee recipient, feeding NodeRewards) - wired, setup closed, handed to the governor, and
 *         checked.
 *
 * As DeployRamp: the deployer owns everything while wiring, closes setup, then hands over, and the
 * script asserts the result and reverts on anything half-configured. After it, adding a gateway,
 * raising a cap or fee, lowering a ratio, or changing the vault, oracle, treasurer, hedge treasury or
 * fee recipient takes MOVVA_GOVERNANCE_DELAY - including for the real governor on day one. Phase A
 * gateways known at deploy time are admitted here instead (MOVVA_GATEWAYS).
 *
 * ## What it refuses
 *
 *  - no supply cap, or zero: "no cap" must be a decision, and the contract has no such setting;
 *  - a zero max age on either oracle leg;
 *  - a Chainlink USDT/USD feed that answers zero or less, reverts, or is already older than its max
 *    age - at deploy, with the real feed;
 *  - an existing FX leg (MOVVA_FX_E6_ORACLE) whose setup is still open, or whose governance delay is
 *    shorter than the reserve's: its governor could change who signs the rate with less notice than
 *    the reserve gives for anything else;
 *  - an existing FX leg with no fresh price, or one outside R$ 1-100 per dollar at 1e-6: that is the
 *    ramps' centavo instance, or a publisher signing the wrong unit;
 *  - a yield vault whose asset is not USDT, or whose own setup is still open;
 *  - collateral ratios out of order (mint floor <= withdraw floor <= target, see setCollateralRatios);
 *  - fees above the reserve's hard caps and ratios below 100% (the reserve refuses those itself);
 *  - an LP reward share above 5,000 bps, a reward rate above 20 bps of volume, an epoch outside 1-28 days
 *    or a review period outside 1-14 days (the splitter and NodeRewards refuse those too).
 *
 * ## Environment
 *
 * Every name is prefixed MOVVA_: forge runs tests in parallel in one process, environment variables
 * are process-wide, and DeployRamp.t.sol sets GOVERNOR and PRICE_PUBLISHERS.
 *
 *   MOVVA_GOVERNOR, MOVVA_GUARDIAN, MOVVA_TREASURER, MOVVA_HEDGE_TREASURY, MOVVA_FEE_RECIPIENT
 *   MOVVA_USDT=0xdAC17F958D2ee523a2206206994597C13D831ec7
 *   MOVVA_USDT_USD_FEED=0x3E7d1eAB13ad0104d2750B8863b489D65364e32D  MOVVA_USDT_USD_MAX_AGE=90000
 *   MOVVA_FX_MAX_AGE=3600          the rate's max age, on the reserve and on a new Pyth leg alike
 *   The FX leg, one of three:
 *   MOVVA_PYTH=0x4305FB66699C3B2702D4d05CF36551390A4c69C6   deploy a PythFxOracle (the default path;
 *     MOVVA_PYTH_USD_BRL_ID defaults to FX.USD/BRL, MOVVA_PYTH_MAX_CONF_BPS=100,
 *     MOVVA_FX_CLOSED_MAX_AGE=345600: how old a last close a band takes off-hours, at most 4 days).
 *     It prices once the Pyth keeper (packages/yield, pyth-keeper) has posted the feed on this chain.
 *   MOVVA_FX_E6_ORACLE=0x..        an existing leg in millionths, or
 *   MOVVA_FX_PUBLISHERS=0x..,0x..  MOVVA_FX_THRESHOLD=2   a signed quorum's leg (no price until signed)
 *   MOVVA_SUPPLY_CAP=1000000       whole Movva (required)
 *   MOVVA_YIELD_VAULT=0x..         YieldVault(USDT), optional
 *   MOVVA_GATEWAYS=0x..,0x..       Phase A LPs, optional
 *   MOVVA_MINT_FEE_BPS=10  MOVVA_REDEEM_FEE_BPS=10
 *   MOVVA_TARGET_RATIO_BPS=10800  MOVVA_MIN_MINT_RATIO_BPS=10000  MOVVA_MIN_WITHDRAW_RATIO_BPS=10300
 *   MOVVA_HEDGE_LIMIT_BPS=800  MOVVA_GOVERNANCE_DELAY=172800
 *   There is no savings product (client decision D1, 14 October 2026): the reserve has no sMovva, no
 *   `distribute` and no distribution fee, and its surplus stays in the reserve.
 *   Node-provider rewards (docs/movva.md, "Fees"). The reserve pays its fees to a FeeSplitter, which forwards
 *   the LPs' share to NodeRewards and the rest to MOVVA_FEE_RECIPIENT, Mova's treasury:
 *   MOVVA_LP_REWARD_SHARE_BPS=0            the LPs' share of Mova's fees: none until Mova chooses. At most 5000;
 *                                          raising it after deployment waits out the delay, lowering it does not
 *   MOVVA_LP_REWARD_BPS_OF_VOLUME=10       an epoch pays at most this share of its settled volume (at most 20)
 *   MOVVA_LP_REWARD_CAP_PER_EPOCH=10000    whole Movva: the most one LP is paid for one epoch
 *   MOVVA_LP_REWARD_MIN_CENTS=1000         settlements under R$ 10,00 are not counted
 *   MOVVA_LP_REWARD_EPOCH_SECONDS=604800   one epoch, a week (1 to 28 days)
 *   MOVVA_LP_REWARD_REVIEW_SECONDS=259200  after an epoch ends, how long its volume can still be voided (1 to 14 days)
 *   NodeRewards counts nothing until a registry is bound to it: DeployRamp with NODE_REWARDS sets the registry's
 *   hook, and the governor then binds that registry (`admin rewards:registry <rewards> <registry>`, immediate
 *   while NodeRewards has never been funded, a scheduled change afterwards).
 *   The divergence breaker (docs/movva.md, "The divergence breaker"): keyless and self-clearing, so every
 *   setting is an immutable chosen HERE. On by default; at least one source is required, or say
 *   MOVVA_BREAKER=off - "no breaker" must be a decision, as "no cap" is.
 *   MOVVA_BREAKER_BAND_BPS=300             halt while the compared rates differ by more than this (1 to 9999)
 *   MOVVA_BREAKER_HALTS_REDEEM=true        false keeps redemptions open while mint and hedge withdrawals halt
 *   MOVVA_BREAKER_BRL_USD_FEED=0x..        a Chainlink BRL/USD feed: source 1, crossed with USDT/USD (independent of Pyth)
 *     MOVVA_BREAKER_BRL_USD_MAX_AGE=90000  MOVVA_BREAKER_CHAINLINK_TRIPS=true
 *   MOVVA_BREAKER_TWAP_POOL=0x..  MOVVA_BREAKER_TWAP_BRL_TOKEN=0x..   a Uniswap v3 USDT/BRL-stablecoin pool: source 2
 *     MOVVA_BREAKER_TWAP_WINDOW=1800  MOVVA_BREAKER_TWAP_MIN_LIQUIDITY=1000000000000  MOVVA_BREAKER_TWAP_TRIPS=true
 *     (TRIPS=false makes a source informational only: it cannot halt anything. A thin TWAP that trips is a
 *     denial-of-service lever; see the doc.)
 *   MOVVA_BREAKER_EXTRA_SOURCES=0x..,0x..  already-deployed IPriceSource contracts, all tripping
 *   MOVVA_HEDGE_QUEUE_DELAY=86400          how long a hedge withdrawal above the daily limit waits (1 hour to 30 days)
 *   forge script contracts/script/DeployMovva.s.sol:DeployMovva --rpc-url $RPC --broadcast
 *
 * Defaults are docs/movva.md's proposals. A new FX leg gets MOVVA_GOVERNANCE_DELAY too, and its setup
 * is closed here like the reserve's, so adding a publisher or lowering its threshold waits as long as
 * any reserve change. Pointing the ramps' USDT band at the same signed number is a separate, delayed
 * step on the ramps: `gov:schedule oracle:fx-legs <usdtOracle> <feed> <band adapter> ...`. Listing
 * Movva on the ramps, with the reserve as its band, is DeployRamp's MOVVA_RESERVE / MOVVA_TOKEN path,
 * using the two addresses this script reports.
 */
contract DeployMovva is Script {
    struct Deployed {
        MovvaReserve reserve;
        Movva movva;
        address fx;
        bool fxDeployedHere;
        ScaledFxBandOracle band;
        /// True when the leg deployed here is a PythFxOracle rather than a signed quorum's.
        bool fxIsPyth;
        /// The reserve's fee recipient, and the node-provider rewards it funds.
        FeeSplitter splitter;
        NodeRewards rewards;
        /// The self-clearing divergence breaker the reserve reads; zero when MOVVA_BREAKER=off.
        DivergenceBreaker breaker;
    }

    /// @notice Pyth's FX.USD/BRL price id: reais per US dollar. The same on every chain Pyth serves.
    bytes32 internal constant PYTH_FX_USD_BRL = 0xd2db4dbf1aea74e0f666b0e8f73b9580d407f5e5cf931940b06dc633d7a95906;
    /// @notice Movva base units per BRL centavo: 1e18 is R$ 1,00. NodeRewards' TOKEN_PER_CENT.
    uint256 internal constant MOVVA_PER_CENT = 1e16;

    function run() external returns (Deployed memory d) {
        address governor = vm.envAddress("MOVVA_GOVERNOR");
        _refuseUnsafeConfig();
        _refuseUnsafeRewards();

        vm.startBroadcast();
        (, address deployer,) = vm.readCallers();
        d = _deploy(deployer);
        _wire(d);
        d.reserve.completeSetup();
        // Before the hand-over, like the reserve's: the deployer must not leave a leg whose feed,
        // limits or publishers the real governor could change without the delay.
        if (d.fxDeployedHere) DelayedGovernance(d.fx).completeSetup();
        // And the fees' destination: a share or a treasury changed without notice moves Mova's revenue.
        d.splitter.completeSetup();
        d.rewards.completeSetup();
        d.reserve.transferGovernor(governor);
        if (d.fxDeployedHere) DelayedGovernance(d.fx).transferGovernor(governor);
        d.splitter.transferGovernor(governor);
        d.rewards.transferGovernor(governor);
        vm.stopBroadcast();

        _assertWired(d, governor);
        _report(d);
    }

    /*//////////////////////////////////////////////////////////////
                                 CHECKS
    //////////////////////////////////////////////////////////////*/

    function _refuseUnsafeConfig() private view {
        require(_supplyCap() > 0, "MOVVA_SUPPLY_CAP: a supply cap of zero is not a cap; set one, in whole Movva");
        require(vm.envAddress("MOVVA_USDT").code.length > 0, "MOVVA_USDT: no contract at that address on this chain");

        IAggregatorV3 feed = IAggregatorV3(vm.envAddress("MOVVA_USDT_USD_FEED"));
        uint64 feedAge = _age("MOVVA_USDT_USD_MAX_AGE", 25 hours);
        (, int256 answer,, uint256 at,) = feed.latestRoundData();
        require(answer > 0, "MOVVA_USDT_USD_FEED: feed answers zero or less");
        require(at != 0 && block.timestamp <= at + feedAge, "MOVVA_USDT_USD_FEED: feed is older than its max age");
        require(feed.decimals() <= 18, "MOVVA_USDT_USD_FEED: feed decimals out of range");

        uint64 fxAge = _age("MOVVA_FX_MAX_AGE", 1 hours);
        address existing = vm.envOr("MOVVA_FX_E6_ORACLE", address(0));
        if (existing == address(0) && vm.envOr("MOVVA_FX_PUBLISHERS", ",", new address[](0)).length == 0) {
            // The Pyth leg. It may have no price yet - the keeper posts it - so only its inputs are checked.
            require(
                vm.envOr("MOVVA_PYTH", address(0)).code.length > 0,
                "MOVVA_PYTH: no Pyth contract at that address on this chain (or set MOVVA_FX_E6_ORACLE / MOVVA_FX_PUBLISHERS)"
            );
            require(
                _closedMaxAge() <= 4 days,
                "MOVVA_FX_CLOSED_MAX_AGE: above 4 days, which is no longer a market closure"
            );
        }
        if (existing != address(0)) {
            // First, and by name: an FX leg still in setup refuses to price (SetupIncomplete), and
            // one whose governance is not a DelayedGovernance at all has no `setupComplete` to ask.
            (bool ok, bytes memory ret) = existing.staticcall(abi.encodeWithSignature("setupComplete()"));
            require(
                ok && ret.length >= 32 && abi.decode(ret, (bool)),
                "MOVVA_FX_E6_ORACLE: setup still open, or its governance is not delayed: its governor could change who signs the rate at once"
            );
            require(
                DelayedGovernance(existing).GOVERNANCE_DELAY() >= _governanceDelay(),
                "MOVVA_FX_E6_ORACLE: governance delay shorter than MOVVA_GOVERNANCE_DELAY, so a publisher change would give holders less notice"
            );
            (uint256 e6, uint64 published) = IPriceOracle(existing).brlCentsPerUnit();
            require(
                e6 >= 1e6 && e6 <= 100e6,
                "MOVVA_FX_E6_ORACLE: not BRL per USD at 1e-6 (the ramps' centavo instance, or the wrong unit signed)"
            );
            require(block.timestamp <= uint256(published) + fxAge, "MOVVA_FX_E6_ORACLE: no price within MOVVA_FX_MAX_AGE");
        }

        require(
            !_breakerOn() || _breakerSourceCount() > 0,
            "MOVVA_BREAKER: no source configured (MOVVA_BREAKER_BRL_USD_FEED / _TWAP_POOL / _EXTRA_SOURCES); say MOVVA_BREAKER=off to deploy without a breaker"
        );
        require(
            _hedgeQueueDelay() >= 1 hours && _hedgeQueueDelay() <= 30 days,
            "MOVVA_HEDGE_QUEUE_DELAY: 1 hour to 30 days"
        );
        // The reserve refuses these too, mid-broadcast; saying why before anything is sent is kinder.
        (uint16 target, uint16 minMint, uint16 minWithdraw) = _ratios();
        require(
            minMint <= minWithdraw && minWithdraw <= target,
            "MOVVA_*_RATIO_BPS: must be ordered mint floor <= withdraw floor <= target"
        );

        address v = vm.envOr("MOVVA_YIELD_VAULT", address(0));
        if (v != address(0)) {
            require(IERC4626(v).asset() == vm.envAddress("MOVVA_USDT"), "MOVVA_YIELD_VAULT: its asset is not MOVVA_USDT");
            require(DelayedGovernance(v).setupComplete(), "MOVVA_YIELD_VAULT: the vault's own setup is still open");
        }
    }

    function _refuseUnsafeRewards() private view {
        require(
            _bps("MOVVA_LP_REWARD_SHARE_BPS", 0) <= 5_000,
            "MOVVA_LP_REWARD_SHARE_BPS: above 5000, the splitter's cap on the LPs' share of Mova's fees"
        );
        (uint16 rate,,) = _rewardLimits();
        require(rate <= 20, "MOVVA_LP_REWARD_BPS_OF_VOLUME: above 20, more per real settled than the mint and redeem fees together");
        uint256 epoch = _epochSeconds();
        require(epoch >= 1 days && epoch <= 28 days, "MOVVA_LP_REWARD_EPOCH_SECONDS: an epoch is 1 to 28 days");
        uint256 review = _reviewSeconds();
        require(review >= 1 days && review <= 14 days, "MOVVA_LP_REWARD_REVIEW_SECONDS: a review period is 1 to 14 days");
    }

    /*//////////////////////////////////////////////////////////////
                                 DEPLOY
    //////////////////////////////////////////////////////////////*/

    function _deploy(address owner) private returns (Deployed memory d) {
        d.fx = vm.envOr("MOVVA_FX_E6_ORACLE", address(0));
        if (d.fx == address(0)) {
            address[] memory publishers = vm.envOr("MOVVA_FX_PUBLISHERS", ",", new address[](0));
            if (publishers.length > 0) {
                d.fx = address(
                    new SignedPriceOracle(owner, _governanceDelay(), publishers, vm.envOr("MOVVA_FX_THRESHOLD", uint256(2)))
                );
            } else {
                d.fx = address(
                    new PythFxOracle(
                        vm.envAddress("MOVVA_PYTH"),
                        vm.envOr("MOVVA_PYTH_USD_BRL_ID", PYTH_FX_USD_BRL),
                        _age("MOVVA_FX_MAX_AGE", 1 hours),
                        _closedMaxAge(),
                        _bps("MOVVA_PYTH_MAX_CONF_BPS", 100),
                        owner,
                        _governanceDelay()
                    )
                );
                d.fxIsPyth = true;
            }
            d.fxDeployedHere = true;
        }
        d.breaker = _deployBreaker();
        d.reserve = new MovvaReserve(
            MovvaReserve.Config({
                usdt: vm.envAddress("MOVVA_USDT"),
                usdtUsdFeed: vm.envAddress("MOVVA_USDT_USD_FEED"),
                fxOracle: d.fx,
                usdtUsdMaxAge: _age("MOVVA_USDT_USD_MAX_AGE", 25 hours),
                fxMaxAge: _age("MOVVA_FX_MAX_AGE", 1 hours),
                governor: owner,
                governanceDelay: _governanceDelay(),
                guardian: vm.envAddress("MOVVA_GUARDIAN"),
                treasurer: vm.envAddress("MOVVA_TREASURER"),
                hedgeTreasury: vm.envAddress("MOVVA_HEDGE_TREASURY"),
                feeRecipient: vm.envAddress("MOVVA_FEE_RECIPIENT"),
                supplyCap: _supplyCap(),
                breaker: address(d.breaker),
                hedgeQueueDelay: _hedgeQueueDelay()
            })
        );
        d.movva = Movva(d.reserve.MOVVA());
        d.band = new ScaledFxBandOracle(IPriceOracle(d.fx));
        d.rewards = new NodeRewards(address(d.movva), MOVVA_PER_CENT, _epochSeconds(), _reviewSeconds(), owner, _governanceDelay());
        d.splitter =
            new FeeSplitter(address(d.movva), vm.envAddress("MOVVA_FEE_RECIPIENT"), address(d.rewards), owner, _governanceDelay());
    }

    function _breakerOn() internal view returns (bool) {
        return keccak256(bytes(vm.envOr("MOVVA_BREAKER", string("on")))) != keccak256("off");
    }

    function _hedgeQueueDelay() internal view returns (uint64) {
        return uint64(vm.envOr("MOVVA_HEDGE_QUEUE_DELAY", uint256(1 days)));
    }

    function _breakerBand() internal view returns (uint16) {
        return _bps("MOVVA_BREAKER_BAND_BPS", 300);
    }

    function _breakerSourceCount() internal view returns (uint256 n) {
        if (vm.envOr("MOVVA_BREAKER_BRL_USD_FEED", address(0)) != address(0)) n++;
        if (vm.envOr("MOVVA_BREAKER_TWAP_POOL", address(0)) != address(0)) n++;
        n += vm.envOr("MOVVA_BREAKER_EXTRA_SOURCES", ",", new address[](0)).length;
    }

    /// @dev The breaker has no owner and no setter: nothing to hand over, nothing to close.
    function _deployBreaker() private returns (DivergenceBreaker b) {
        if (!_breakerOn()) return DivergenceBreaker(address(0));
        uint256 n = _breakerSourceCount();
        DivergenceBreaker.SourceConfig[] memory cfg = new DivergenceBreaker.SourceConfig[](n);
        uint256 i;
        address brlFeed = vm.envOr("MOVVA_BREAKER_BRL_USD_FEED", address(0));
        if (brlFeed != address(0)) {
            cfg[i++] = DivergenceBreaker.SourceConfig(
                IPriceSource(
                    address(
                        new ChainlinkCrossSource(
                            vm.envAddress("MOVVA_USDT_USD_FEED"),
                            brlFeed,
                            _age("MOVVA_USDT_USD_MAX_AGE", 25 hours),
                            _age("MOVVA_BREAKER_BRL_USD_MAX_AGE", 25 hours)
                        )
                    )
                ),
                vm.envOr("MOVVA_BREAKER_CHAINLINK_TRIPS", true)
            );
        }
        address pool = vm.envOr("MOVVA_BREAKER_TWAP_POOL", address(0));
        if (pool != address(0)) {
            cfg[i++] = DivergenceBreaker.SourceConfig(
                IPriceSource(
                    address(
                        new UniswapV3TwapSource(
                            pool,
                            vm.envAddress("MOVVA_USDT"),
                            vm.envAddress("MOVVA_BREAKER_TWAP_BRL_TOKEN"),
                            uint32(vm.envOr("MOVVA_BREAKER_TWAP_WINDOW", uint256(1800))),
                            uint128(vm.envOr("MOVVA_BREAKER_TWAP_MIN_LIQUIDITY", uint256(1e12)))
                        )
                    )
                ),
                vm.envOr("MOVVA_BREAKER_TWAP_TRIPS", true)
            );
        }
        address[] memory extra = vm.envOr("MOVVA_BREAKER_EXTRA_SOURCES", ",", new address[](0));
        for (uint256 j; j < extra.length; ++j) {
            cfg[i++] = DivergenceBreaker.SourceConfig(IPriceSource(extra[j]), true);
        }
        b = new DivergenceBreaker(_breakerBand(), vm.envOr("MOVVA_BREAKER_HALTS_REDEEM", true), cfg);
    }

    /// @dev During setup every change is instant, and nobody can hold Movva yet.
    function _wire(Deployed memory d) private {
        address[] memory gateways = vm.envOr("MOVVA_GATEWAYS", ",", new address[](0));
        for (uint256 i; i < gateways.length; ++i) {
            d.reserve.setGateway(gateways[i], true);
        }
        address v = vm.envOr("MOVVA_YIELD_VAULT", address(0));
        if (v != address(0)) d.reserve.setYieldVault(v);
        (uint16 mintFee, uint16 redeemFee) = _fees();
        d.reserve.setFees(mintFee, redeemFee);
        (uint16 target, uint16 minMint, uint16 minWithdraw) = _ratios();
        d.reserve.setCollateralRatios(target, minMint, minWithdraw);
        d.reserve.setLimits(_supplyCap(), _hedgeLimit());
        _wireRewards(d);
    }

    /// @dev The reserve was constructed paying MOVVA_FEE_RECIPIENT directly, because the splitter needs the token the
    ///      reserve deploys; here, still in setup, the fees are pointed through the splitter. With a share of zero every
    ///      fee still reaches MOVVA_FEE_RECIPIENT, now one `split()` later.
    function _wireRewards(Deployed memory d) private {
        d.reserve.setFeeRecipient(address(d.splitter));
        d.splitter.setLpRewardShare(_bps("MOVVA_LP_REWARD_SHARE_BPS", 0));
        (uint16 rate, uint256 cap, uint256 minCents) = _rewardLimits();
        d.rewards.setRewardLimits(rate, cap, minCents);
    }

    /*//////////////////////////////////////////////////////////////
                                ASSERTIONS
    //////////////////////////////////////////////////////////////*/

    function _assertWired(Deployed memory d, address governor) private view {
        MovvaReserve r = d.reserve;
        require(r.governor() == governor, "reserve: governor not handed over");
        require(r.setupComplete(), "reserve: setup still open, changes are instant");
        require(r.GOVERNANCE_DELAY() == _governanceDelay(), "reserve: governance delay differs from MOVVA_GOVERNANCE_DELAY");
        require(d.movva.RESERVE() == address(r), "token: minter is not the reserve");
        require(r.USDT() == vm.envAddress("MOVVA_USDT"), "reserve: wrong USDT");
        require(address(r.usdtUsdFeed()) == vm.envAddress("MOVVA_USDT_USD_FEED"), "reserve: wrong USDT/USD feed");
        require(address(r.fxOracle()) == d.fx && address(d.band.SOURCE()) == d.fx, "FX leg: reserve and band adapter disagree");
        require(
            r.usdtUsdMaxAge() == _age("MOVVA_USDT_USD_MAX_AGE", 25 hours) && r.fxMaxAge() == _age("MOVVA_FX_MAX_AGE", 1 hours),
            "reserve: max ages differ from the environment"
        );
        if (d.fxDeployedHere) {
            DelayedGovernance fx = DelayedGovernance(d.fx);
            require(fx.governor() == governor, "FX leg: governor not handed over, the deployer could change its source");
            require(fx.setupComplete(), "FX leg: setup still open, its source changes instantly");
            require(fx.GOVERNANCE_DELAY() == _governanceDelay(), "FX leg: governance delay differs from MOVVA_GOVERNANCE_DELAY");
        }
        if (d.fxIsPyth) {
            PythFxOracle p = PythFxOracle(d.fx);
            require(
                address(p.PYTH()) == vm.envAddress("MOVVA_PYTH") && p.usdBrlId() == vm.envOr("MOVVA_PYTH_USD_BRL_ID", PYTH_FX_USD_BRL),
                "FX leg: not Pyth's FX.USD/BRL on MOVVA_PYTH"
            );
            require(
                p.maxAge() == r.fxMaxAge() && p.closedMaxAge() == _closedMaxAge(),
                "FX leg: max ages differ from the environment"
            );
        }
        require(address(r.BREAKER()) == address(d.breaker), "reserve: breaker not wired");
        require(r.HEDGE_QUEUE_DELAY() == _hedgeQueueDelay(), "reserve: hedge queue delay differs from the environment");
        if (_breakerOn()) {
            require(address(d.breaker) != address(0), "breaker: not deployed");
            require(
                d.breaker.BAND_BPS() == _breakerBand() && d.breaker.sourceCount() == _breakerSourceCount(),
                "breaker: band or sources differ from the environment"
            );
        }
        require(address(r.yieldVault()) == vm.envOr("MOVVA_YIELD_VAULT", address(0)), "reserve: yield vault not wired");
        require(
            r.guardian() == vm.envAddress("MOVVA_GUARDIAN") && r.treasurer() == vm.envAddress("MOVVA_TREASURER")
                && r.hedgeTreasury() == vm.envAddress("MOVVA_HEDGE_TREASURY"),
            "reserve: a role differs from the environment"
        );
        require(r.feeRecipient() == address(d.splitter), "reserve: fees are not paid to this deployment's FeeSplitter");
        _assertRewards(d, governor);
        address[] memory gateways = vm.envOr("MOVVA_GATEWAYS", ",", new address[](0));
        for (uint256 i; i < gateways.length; ++i) {
            require(r.isGateway(gateways[i]), "reserve: a gateway in MOVVA_GATEWAYS was not admitted");
        }
        (uint16 mintFee, uint16 redeemFee) = _fees();
        require(r.mintFeeBps() == mintFee && r.redeemFeeBps() == redeemFee, "reserve: fees differ from the environment");
        (uint16 target, uint16 minMint, uint16 minWithdraw) = _ratios();
        require(
            r.targetCollateralRatioBps() == target && r.minMintCollateralRatioBps() == minMint
                && r.minWithdrawCollateralRatioBps() == minWithdraw,
            "reserve: collateral ratios differ from the environment"
        );
        require(
            r.supplyCap() == _supplyCap() && r.supplyCap() > 0 && r.hedgeLimitBps() == _hedgeLimit(),
            "reserve: limits differ from the environment"
        );
        // An existing FX leg was checked fresh above; the reserve must now price with it.
        if (!d.fxDeployedHere) r.brlPerUsdtE18();
    }

    /// @dev The fees' destination, handed over and closed like the reserve, and NodeRewards bound to nothing yet.
    function _assertRewards(Deployed memory d, address governor) private view {
        FeeSplitter s = d.splitter;
        NodeRewards n = d.rewards;
        require(s.governor() == governor && n.governor() == governor, "rewards: governor not handed over");
        require(s.setupComplete() && n.setupComplete(), "rewards: setup still open, the share or the limits change instantly");
        require(
            s.GOVERNANCE_DELAY() == _governanceDelay() && n.GOVERNANCE_DELAY() == _governanceDelay(),
            "rewards: governance delay differs from MOVVA_GOVERNANCE_DELAY"
        );
        require(
            address(s.TOKEN()) == address(d.movva) && address(n.REWARD_TOKEN()) == address(d.movva),
            "rewards: not paid in this deployment's Movva"
        );
        require(s.treasury() == vm.envAddress("MOVVA_FEE_RECIPIENT"), "splitter: treasury differs from MOVVA_FEE_RECIPIENT");
        require(s.rewards() == address(n), "splitter: does not fund this deployment's NodeRewards");
        require(
            s.lpRewardShareBps() == _bps("MOVVA_LP_REWARD_SHARE_BPS", 0), "splitter: LP share differs from MOVVA_LP_REWARD_SHARE_BPS"
        );
        (uint16 rate, uint256 cap, uint256 minCents) = _rewardLimits();
        require(
            n.rewardBpsOfVolume() == rate && n.maxRewardPerLpPerEpoch() == cap && n.minCountedCents() == minCents,
            "rewards: limits differ from the environment"
        );
        require(
            n.TOKEN_PER_CENT() == MOVVA_PER_CENT && n.EPOCH_LENGTH() == _epochSeconds() && n.REVIEW_PERIOD() == _reviewSeconds(),
            "rewards: unit, epoch or review period differs from the environment"
        );
        require(n.registry() == address(0), "rewards: a registry is bound before any ramp was deployed");
    }

    function _report(Deployed memory d) private pure {
        console2.log("MovvaReserve        ", address(d.reserve));
        console2.log("Movva               ", address(d.movva));
        console2.log("FX leg (BRL/USD e6) ", d.fx);
        console2.log("band adapter (cents)", address(d.band));
        console2.log("FeeSplitter         ", address(d.splitter));
        console2.log("NodeRewards         ", address(d.rewards));
        console2.log("DivergenceBreaker   ", address(d.breaker));
        console2.log("  keyless and self-clearing: mint, redeem and hedge withdrawals halt while sources disagree");
        console2.log("  the reserve pays its fees to the splitter; anyone may split() them to the treasury and NodeRewards");
        console2.log("  NodeRewards counts nothing until DeployRamp sets NODE_REWARDS=%s and the governor binds the registry", address(d.rewards));
        if (d.fxIsPyth) {
            console2.log("  a PythFxOracle: it prices once the Pyth keeper posts FX.USD/BRL on this chain");
            console2.log("  off-hours the ramps take the last close; minting and redeeming wait for the market");
        } else if (d.fxDeployedHere) {
            console2.log("  the FX leg is new: nothing prices until its publishers sign a rate");
        }
        // What DeployRamp's Movva pair needs, verbatim: it checks the two are bound to each other.
        console2.log("list on the ramps: MOVVA_RESERVE=%s", address(d.reserve));
        console2.log("                   MOVVA_TOKEN=%s", address(d.movva));
    }

    /*//////////////////////////////////////////////////////////////
                                   ENV
    //////////////////////////////////////////////////////////////*/

    /// @dev Unset reads as zero, and zero is refused with a message rather than a cheatcode error.
    function _supplyCap() private view returns (uint256) {
        return vm.envOr("MOVVA_SUPPLY_CAP", uint256(0)) * 1e18;
    }

    function _governanceDelay() private view returns (uint256) {
        return vm.envOr("MOVVA_GOVERNANCE_DELAY", uint256(48 hours));
    }

    function _age(string memory name, uint256 dflt) private view returns (uint64) {
        uint256 v = vm.envOr(name, dflt);
        require(v > 0 && v <= type(uint64).max, string.concat(name, ": a max age is seconds, above zero"));
        return uint64(v);
    }

    /// @dev Zero is a setting here (no closing prices at all), so unlike `_age` it is not refused.
    function _closedMaxAge() private view returns (uint64) {
        uint256 v = vm.envOr("MOVVA_FX_CLOSED_MAX_AGE", uint256(4 days));
        require(v <= type(uint64).max, "MOVVA_FX_CLOSED_MAX_AGE: seconds");
        return uint64(v);
    }

    function _bps(string memory name, uint256 dflt) private view returns (uint16) {
        uint256 v = vm.envOr(name, dflt);
        require(v <= type(uint16).max, string.concat(name, ": basis points fit a uint16"));
        return uint16(v);
    }

    /// @dev Benchmarked to traditional finance (docs/movva.md, "Fees"): 0.10% to mint and 0.10% to redeem, as a
    ///      fiat-backed stablecoin issuer charges its institutions (Tether: 0.1% per acquisition and per redemption).
    ///      Both sit under the reserve's hard caps (100 bps each); raising either later waits out the governance delay.
    function _fees() private view returns (uint16, uint16) {
        return (_bps("MOVVA_MINT_FEE_BPS", 10), _bps("MOVVA_REDEEM_FEE_BPS", 10));
    }

    function _ratios() private view returns (uint16, uint16, uint16) {
        return (
            _bps("MOVVA_TARGET_RATIO_BPS", 10_800),
            _bps("MOVVA_MIN_MINT_RATIO_BPS", 10_000),
            _bps("MOVVA_MIN_WITHDRAW_RATIO_BPS", 10_300)
        );
    }

    function _hedgeLimit() private view returns (uint16) {
        return _bps("MOVVA_HEDGE_LIMIT_BPS", 800);
    }

    function _epochSeconds() private view returns (uint256) {
        return vm.envOr("MOVVA_LP_REWARD_EPOCH_SECONDS", uint256(7 days));
    }

    function _reviewSeconds() private view returns (uint256) {
        return vm.envOr("MOVVA_LP_REWARD_REVIEW_SECONDS", uint256(3 days));
    }

    /// @dev 10 bps of volume, the mint fee: a settled real never earns more than minting it paid Mova. R$ 10.000,00 of Movva
    ///      per LP per epoch, and nothing under R$ 10,00 counted. Only the rate has a hard cap in the contract (20 bps).
    function _rewardLimits() private view returns (uint16 rate, uint256 cap, uint256 minCents) {
        rate = _bps("MOVVA_LP_REWARD_BPS_OF_VOLUME", 10);
        cap = vm.envOr("MOVVA_LP_REWARD_CAP_PER_EPOCH", uint256(10_000)) * 1e18;
        minCents = vm.envOr("MOVVA_LP_REWARD_MIN_CENTS", uint256(1_000));
    }
}
