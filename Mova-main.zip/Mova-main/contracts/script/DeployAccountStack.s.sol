// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

import {Script, console} from "forge-std/Script.sol";
import {OwnerlessPaymaster, IEntryPointFunding} from "../OwnerlessPaymaster.sol";

interface IStakeInfo {
    struct DepositInfo {
        uint256 deposit;
        bool staked;
        uint112 stake;
        uint32 unstakeDelaySec;
        uint48 withdrawTime;
    }

    function getDepositInfo(address account) external view returns (DepositInfo memory);
    function balanceOf(address account) external view returns (uint256);
}

interface ISafeProxyFactoryLike {
    function proxyCreationCode() external pure returns (bytes memory);
    function createProxyWithNonce(address singleton, bytes memory initializer, uint256 saltNonce)
        external
        returns (address proxy);
}

interface ISafeSetupLike {
    function setup(
        address[] calldata owners,
        uint256 threshold,
        address to,
        bytes calldata data,
        address fallbackHandler,
        address paymentToken,
        uint256 payment,
        address payable paymentReceiver
    ) external;
    function getOwners() external view returns (address[] memory);
}

interface ISafeModuleSetupLike {
    function enableModules(address[] calldata modules) external;
}

interface IKernelFactoryLike {
    function implementation() external view returns (address);
    function getAddress(bytes calldata data, bytes32 salt) external view returns (address);
    function createAccount(bytes calldata data, bytes32 salt) external payable returns (address);
}

interface IKernelLike {
    function accountId() external view returns (string memory);
    function entrypoint() external view returns (address);
    function initialize(
        bytes21 rootValidator,
        address hook,
        bytes calldata validatorData,
        bytes calldata hookData,
        bytes[] calldata initConfig
    ) external;
}

interface IMetaFactoryLike {
    function approved(address factory) external view returns (bool);
}

interface IPasskeyCoSignerValidatorLike {
    function WEBAUTHN() external view returns (address);
}

/**
 * Task 2 on Sepolia: the smart-account contracts the wallet's accounts need that are OURS, and the ownerless gas
 * sponsor. Driven by scripts/deploy-account-stack.ts (rehearsal on a fork first; the viewing-key contracts are
 * contracts/script/Deploy.s.sol:Deploy, a second forge run).
 *
 * `check()` (no broadcast, cheatcodes only) proves every CANONICAL contract the accounts run on is already on this
 * chain, at its mainnet address, with the code of the vendored fixture (packages/smart-account/fixtures/canonical):
 * EntryPoint v0.7, Safe 1.4.1 + SafeProxyFactory, MultiSendCallOnly, SafeModuleSetup + Safe4337Module 0.3.0, the
 * Safe passkey signer factory + FCL P-256 verifier, Zodiac Delay 1.1.1 + ModuleProxyFactory, Kernel v3.1 +
 * KernelFactory + its meta factory, and the three deterministic deployers. Kernel's implementation caches the chain
 * id and its own address in immutables, so its runtime hash is mainnet's only on chain 1; here the fixture's init
 * code is run again through the same deployer and salt (in a state snapshot that is then thrown away) and the
 * result must equal this chain's code byte for byte.
 *
 * `run()` deploys, in order, each transaction from the broadcaster:
 *   1-3  PasskeyCoSignerValidator(SafeWebAuthnSignerFactory), FrostValidator, KernelAvatarAdapter: the vendored
 *        builds in packages/smart-account/fixtures/mova (byte-identical to the sub-project's build:
 *        packages/smart-account/contracts/test/Fixtures.t.sol), through the Arachnid deterministic deployer with
 *        salt 0, so they land at the addresses every chain shares and `deterministicDeploymentAddress` predicts.
 *        One already there (anyone may deploy them) is checked and kept.
 *   4    OwnerlessPaymaster(EntryPoint v0.7, policy). The policy's two (factory, proxy init code hash) roots are
 *        derived from the factories AS DEPLOYED HERE, exactly as contracts/test/OwnerlessPaymaster.t.sol derives them
 *        (SafeProxyFactory.proxyCreationCode() ++ uint256(Safe 1.4.1 singleton); the Solady ERC-1967 proxy over
 *        KernelFactory.implementation()), asserted against the published values, and then proved by a simulated
 *        (never broadcast) account creation through each factory: a wrong hash would sponsor nobody.
 *   5    addStake() with OWNERLESS_STAKE_WEI (default 1 ETH), at the immutable UNSTAKE_DELAY_SEC.
 *   6    deposit() with OWNERLESS_DEPOSIT_WEI (default 0.1 ETH).
 * Then every immutable, the EntryPoint deposit and stake are asserted. With OWNERLESS_PAYMASTER set to an earlier
 * deployment (a resumed run), step 4 is skipped after its immutables are checked against the policy, and 5-6 only
 * top the stake and deposit up to their targets.
 *
 * Policy (env, defaults for Sepolia): OWNERLESS_WINDOW 86400, OWNERLESS_GRACE 3600, OWNERLESS_MAX_COST_PER_OP 0.01
 * ETH, OWNERLESS_MAX_OPS_PER_ACCOUNT 10, OWNERLESS_MAX_COST_PER_ACCOUNT 0.02 ETH, OWNERLESS_MAX_COST_GLOBAL 0.2 ETH,
 * OWNERLESS_UNSTAKE_DELAY 86400. Amounts are in wei.
 *
 *   forge script contracts/script/DeployAccountStack.s.sol:DeployAccountStack --sig 'check()' --rpc-url $RPC
 *   forge script contracts/script/DeployAccountStack.s.sol:DeployAccountStack --rpc-url $RPC --broadcast --slow ...
 */
contract DeployAccountStack is Script {
    string internal constant FIXTURES = "packages/smart-account/fixtures/";

    address internal constant ARACHNID = 0x4e59b44847b379578588920cA78FbF26c0B4956C;
    address internal constant ENTRYPOINT = 0x0000000071727De22E5E9d8BAf0edAc6f37da032;
    address internal constant SAFE_SINGLETON = 0x41675C099F32341bf84BFc5382aF534df5C7461a;
    address internal constant SAFE_PROXY_FACTORY = 0x4e1DCf7AD4e460CfD30791CCC4F9c8a4f820ec67;
    address internal constant SAFE_MODULE_SETUP = 0x2dd68b007B46fBe91B9A7c3EDa5A7a1063cB5b47;
    address internal constant SAFE_4337_MODULE = 0x75cf11467937ce3F2f357CE24ffc3DBF8fD5c226;
    address internal constant WEBAUTHN_SIGNER_FACTORY = 0x1d31F259eE307358a26dFb23EB365939E8641195;
    address internal constant FCL_P256_VERIFIER = 0xA86e0054C51E4894D88762a017ECc5E5235f5DBA;
    address internal constant KERNEL_IMPLEMENTATION = 0xBAC849bB641841b44E965fB01A4Bf5F074f84b4D;
    address internal constant KERNEL_FACTORY = 0xaac5D4240AF87249B3f71BC8E4A2cae074A3E419;
    address internal constant KERNEL_META_FACTORY = 0xd703aaE79538628d27099B8c4f621bE4CCd142d5;

    /// @dev keccak256(SafeProxyFactory 1.4.1 proxyCreationCode() ++ uint256(Safe 1.4.1 singleton)): every Safe 1.4.1
    ///      proxy's CREATE2 init code hash, the same on every chain the canonical factory and singleton are on.
    bytes32 internal constant SAFE_PROXY_INIT_CODE_HASH =
        0x76733d705f71b79841c0ee960a0ca880f779cde7ef446c989e6d23efc0a4adfb;
    /// @dev keccak256 of Solady LibClone's ERC-1967 proxy (v0.0.168) over the Kernel v3.1 implementation.
    bytes32 internal constant KERNEL_PROXY_INIT_CODE_HASH =
        0x85d96aa1c9a65886d094915d76ccae85f14027a02c1647dde659f869460f03e6;

    string internal constant KERNEL_ACCOUNT_ID = "kernel.advanced.v0.3.1";

    /*//////////////////////////////////////////////////////////////
                                  CHECK
    //////////////////////////////////////////////////////////////*/

    /// @notice Read-only: every canonical contract is here with the vendored fixture's code. Reverts otherwise.
    function check() public {
        _checkDeployer("arachnid", ARACHNID);
        _checkDeployer("safeSingletonFactory", 0x914d7Fec6aaC8cd542e72Bca78B30650d45643d7);
        _checkDeployer("eip2470", 0xce0042B868300000d44A59004Da54A005ffdcf9f);
        string[13] memory names = [
            "EntryPoint",
            "Safe",
            "SafeProxyFactory",
            "MultiSendCallOnly",
            "SafeModuleSetup",
            "Safe4337Module",
            "FCLP256Verifier",
            "SafeWebAuthnSignerFactory",
            "Delay",
            "ModuleProxyFactory",
            "Kernel",
            "KernelFactory",
            "FactoryStaker"
        ];
        for (uint256 i; i < names.length; ++i) {
            _checkCanonical(names[i]);
        }
        _checkWiring();
        console.log(
            "canonical: all 13 contracts and 3 deployers present with the vendored fixtures' code"
        );
    }

    function _checkDeployer(string memory name, address at) internal view {
        string memory j = vm.readFile(string.concat(FIXTURES, "canonical/deployers.json"));
        bytes32 expected = vm.parseJsonBytes32(j, string.concat(".", name, ".runtimeCodeKeccak"));
        require(at.code.length != 0, string.concat("deployer missing: ", name));
        require(keccak256(at.code) == expected, string.concat("deployer code differs: ", name));
        console.log(string.concat("deployer ", name), at, "code = fixture");
    }

    function _checkCanonical(string memory name) internal {
        string memory j = vm.readFile(string.concat(FIXTURES, "canonical/", name, ".json"));
        address at = vm.parseJsonAddress(j, ".address");
        require(at.code.length != 0, string.concat("MISSING on this chain: ", name));
        if (!vm.parseJsonBool(j, ".runtimeDependsOnChainId")) {
            require(
                keccak256(at.code) == vm.parseJsonBytes32(j, ".runtimeCodeKeccak"),
                string.concat("runtime code differs from the fixture: ", name)
            );
            console.log(string.concat("canonical ", name), at, "runtime keccak = fixture");
            return;
        }
        // Chain-id immutables: rebuild it from the fixture's init code, here, through the same deployer and salt.
        bytes memory onChain = at.code;
        address deployer = vm.parseJsonAddress(j, ".deployer");
        require(deployer == ARACHNID, "only Arachnid-deployed chain-dependent fixtures are rebuilt");
        uint256 snap = vm.snapshotState();
        vm.etch(at, "");
        vm.resetNonce(at);
        (bool ok, bytes memory ret) = deployer.call(
            abi.encodePacked(vm.parseJsonBytes32(j, ".salt"), vm.parseJsonBytes(j, ".initCode"))
        );
        require(
            ok && address(bytes20(ret)) == at,
            string.concat("fixture init code does not land at ", name)
        );
        bool same = keccak256(at.code) == keccak256(onChain);
        vm.revertToState(snap);
        require(
            same,
            string.concat(
                "runtime code differs from the fixture's init code run on this chain: ", name
            )
        );
        console.log(
            string.concat("canonical ", name), at, "runtime = fixture init code run on this chain"
        );
    }

    function _checkWiring() internal view {
        require(
            IKernelFactoryLike(KERNEL_FACTORY).implementation() == KERNEL_IMPLEMENTATION,
            "KernelFactory clones another implementation"
        );
        require(
            keccak256(bytes(IKernelLike(KERNEL_IMPLEMENTATION).accountId()))
                == keccak256(bytes(KERNEL_ACCOUNT_ID)),
            "Kernel accountId"
        );
        require(
            IKernelLike(KERNEL_IMPLEMENTATION).entrypoint() == ENTRYPOINT,
            "Kernel is not bound to EntryPoint v0.7"
        );
        // Informational: the meta factory route (bundler first ops) needs it; this deployment's accounts do not.
        console.log(
            "Kernel meta factory approves KernelFactory:",
            IMetaFactoryLike(KERNEL_META_FACTORY).approved(KERNEL_FACTORY)
        );
    }

    /*//////////////////////////////////////////////////////////////
                                   RUN
    //////////////////////////////////////////////////////////////*/

    struct Deployed {
        address passkeyValidator;
        address frostValidator;
        address adapter;
        OwnerlessPaymaster paymaster;
    }

    function run() external returns (Deployed memory d) {
        require(
            ENTRYPOINT.code.length != 0 && KERNEL_FACTORY.code.length != 0,
            "no account stack on this chain: run check()"
        );
        _checkWiring();

        d.passkeyValidator =
            _deployMova("PasskeyCoSignerValidator", abi.encode(WEBAUTHN_SIGNER_FACTORY));
        require(
            IPasskeyCoSignerValidatorLike(d.passkeyValidator).WEBAUTHN() == WEBAUTHN_SIGNER_FACTORY,
            "PasskeyCoSignerValidator is bound to another WebAuthn verifier"
        );
        d.frostValidator = _deployMova("FrostValidator", "");
        d.adapter = _deployMova("KernelAvatarAdapter", "");

        OwnerlessPaymaster.Policy memory p = policy();
        uint256 stake = vm.envOr("OWNERLESS_STAKE_WEI", uint256(1 ether));
        uint256 depositWei = vm.envOr("OWNERLESS_DEPOSIT_WEI", uint256(0.1 ether));
        require(stake > 0 && stake <= type(uint112).max, "OWNERLESS_STAKE_WEI");

        address existing = vm.envOr("OWNERLESS_PAYMASTER", address(0));
        if (existing == address(0)) {
            vm.broadcast();
            d.paymaster = new OwnerlessPaymaster(IEntryPointFunding(ENTRYPOINT), p);
        } else {
            d.paymaster = OwnerlessPaymaster(payable(existing));
            console.log("OwnerlessPaymaster: adopting the earlier deployment", existing);
        }
        _assertImmutables(d.paymaster, p);

        IStakeInfo.DepositInfo memory info =
            IStakeInfo(ENTRYPOINT).getDepositInfo(address(d.paymaster));
        if (info.stake < stake) {
            vm.broadcast();
            d.paymaster.addStake{value: stake - info.stake}();
        }
        uint256 balance = IStakeInfo(ENTRYPOINT).balanceOf(address(d.paymaster));
        if (balance < depositWei) {
            vm.broadcast();
            d.paymaster.deposit{value: depositWei - balance}();
        }

        info = IStakeInfo(ENTRYPOINT).getDepositInfo(address(d.paymaster));
        require(info.staked, "paymaster not staked");
        require(info.stake == stake, "paymaster stake");
        require(info.unstakeDelaySec == p.unstakeDelaySec, "paymaster unstake delay");
        require(info.withdrawTime == 0, "paymaster stake unlocking");
        require(info.deposit == depositWei, "paymaster deposit");
        require(d.paymaster.getDeposit() == depositWei, "getDeposit");

        _proveProvenance(d.paymaster, d.passkeyValidator);

        console.log("PasskeyCoSignerValidator", d.passkeyValidator);
        console.log("FrostValidator", d.frostValidator);
        console.log("KernelAvatarAdapter", d.adapter);
        console.log("OwnerlessPaymaster", address(d.paymaster));
        console.log("SafeProxyInitCodeHash", vm.toString(p.proxyInitCodeHash0));
        console.log("KernelProxyInitCodeHash", vm.toString(p.proxyInitCodeHash1));
        console.log("stake (wei)", info.stake);
        console.log("deposit (wei)", info.deposit);
    }

    /// @notice The policy from the environment, with both provenance roots derived from the chain.
    function policy() public view returns (OwnerlessPaymaster.Policy memory p) {
        bytes32 safeHash = keccak256(
            abi.encodePacked(
                ISafeProxyFactoryLike(SAFE_PROXY_FACTORY).proxyCreationCode(),
                uint256(uint160(SAFE_SINGLETON))
            )
        );
        require(
            safeHash == SAFE_PROXY_INIT_CODE_HASH,
            "SafeProxyFactory proxy init code hash differs from Safe 1.4.1's"
        );
        bytes32 kernelHash =
            keccak256(_kernelProxyInitCode(IKernelFactoryLike(KERNEL_FACTORY).implementation()));
        require(
            kernelHash == KERNEL_PROXY_INIT_CODE_HASH,
            "KernelFactory proxy init code hash differs from Kernel v3.1's"
        );

        uint256 delay = vm.envOr("OWNERLESS_UNSTAKE_DELAY", uint256(1 days));
        require(delay <= type(uint32).max, "OWNERLESS_UNSTAKE_DELAY");
        p = OwnerlessPaymaster.Policy({
            factory0: SAFE_PROXY_FACTORY,
            proxyInitCodeHash0: safeHash,
            factory1: KERNEL_FACTORY,
            proxyInitCodeHash1: kernelHash,
            window: vm.envOr("OWNERLESS_WINDOW", uint256(1 days)),
            grace: vm.envOr("OWNERLESS_GRACE", uint256(1 hours)),
            maxCostPerOp: vm.envOr("OWNERLESS_MAX_COST_PER_OP", uint256(0.01 ether)),
            maxOpsPerAccount: vm.envOr("OWNERLESS_MAX_OPS_PER_ACCOUNT", uint256(10)),
            maxCostPerAccount: vm.envOr("OWNERLESS_MAX_COST_PER_ACCOUNT", uint256(0.02 ether)),
            maxCostGlobal: vm.envOr("OWNERLESS_MAX_COST_GLOBAL", uint256(0.2 ether)),
            unstakeDelaySec: uint32(delay)
        });
    }

    /// @dev A fixtures/mova build through Arachnid with salt 0; one already at its address is kept.
    function _deployMova(string memory name, bytes memory args) internal returns (address at) {
        bytes memory initCode = abi.encodePacked(
            vm.parseJsonBytes(
                vm.readFile(string.concat(FIXTURES, "mova/", name, ".json")), ".bytecode"
            ),
            args
        );
        at = vm.computeCreate2Address(bytes32(0), keccak256(initCode), ARACHNID);
        if (at.code.length == 0) {
            vm.broadcast();
            (bool ok, bytes memory ret) = ARACHNID.call(abi.encodePacked(bytes32(0), initCode));
            require(
                ok && ret.length == 20 && address(bytes20(ret)) == at,
                string.concat(name, ": deployment failed")
            );
        } else {
            console.log(
                string.concat(name, ": already deployed at its deterministic address; kept"), at
            );
        }
        require(at.code.length != 0, string.concat(name, ": no code"));
    }

    function _assertImmutables(OwnerlessPaymaster pm, OwnerlessPaymaster.Policy memory p)
        internal
        view
    {
        require(address(pm.ENTRYPOINT()) == ENTRYPOINT, "ENTRYPOINT");
        require(
            pm.FACTORY_0() == p.factory0 && pm.PROXY_INIT_CODE_HASH_0() == p.proxyInitCodeHash0,
            "root 0"
        );
        require(
            pm.FACTORY_1() == p.factory1 && pm.PROXY_INIT_CODE_HASH_1() == p.proxyInitCodeHash1,
            "root 1"
        );
        require(pm.WINDOW() == p.window && pm.GRACE() == p.grace, "WINDOW/GRACE");
        require(pm.MAX_COST_PER_OP() == p.maxCostPerOp, "MAX_COST_PER_OP");
        require(pm.MAX_OPS_PER_ACCOUNT() == p.maxOpsPerAccount, "MAX_OPS_PER_ACCOUNT");
        require(pm.MAX_COST_PER_ACCOUNT() == p.maxCostPerAccount, "MAX_COST_PER_ACCOUNT");
        require(pm.MAX_COST_GLOBAL() == p.maxCostGlobal, "MAX_COST_GLOBAL");
        require(pm.UNSTAKE_DELAY_SEC() == p.unstakeDelaySec, "UNSTAKE_DELAY_SEC");
    }

    /**
     * @dev The two roots, proved by creating an account through each factory in this script's local simulation
     *      only (nothing below is broadcast): the address the factory produced must be the one the paymaster
     *      derives from the salt the wallet supplies.
     */
    function _proveProvenance(OwnerlessPaymaster pm, address passkeyValidator) internal {
        // A sub-wallet-shaped Safe 1-of-1, with the wallet's initializer (packages/smart-account safeInitializer).
        address[] memory owners = new address[](1);
        owners[0] = address(0xA11CE);
        address[] memory modules = new address[](1);
        modules[0] = SAFE_4337_MODULE;
        bytes memory initializer = abi.encodeCall(
            ISafeSetupLike.setup,
            (
                owners,
                1,
                SAFE_MODULE_SETUP,
                abi.encodeCall(ISafeModuleSetupLike.enableModules, (modules)),
                SAFE_4337_MODULE,
                address(0),
                0,
                payable(address(0))
            )
        );
        uint256 saltNonce = uint256(keccak256("mova task 2 provenance probe"));
        bytes32 safeSalt = keccak256(abi.encodePacked(keccak256(initializer), saltNonce));
        address safe = ISafeProxyFactoryLike(SAFE_PROXY_FACTORY).createProxyWithNonce(
            SAFE_SINGLETON, initializer, saltNonce
        );
        require(
            safe == pm.accountAddress(0, safeSalt),
            "the paymaster does not derive the Safe SafeProxyFactory created"
        );
        require(ISafeSetupLike(safe).getOwners()[0] == owners[0], "probe Safe");

        // A primary Kernel account on PasskeyCoSignerValidator, created as the co-signer does at enrolment.
        (uint256 x, uint256 y) = vm.publicKeyP256(
            uint256(keccak256("mova task 2 passkey probe"))
                % 0xFFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551
        );
        bytes memory initData = abi.encodeCall(
            IKernelLike.initialize,
            (
                bytes21(abi.encodePacked(bytes1(0x01), passkeyValidator)),
                address(0),
                abi.encode(x, y, uint176(uint160(FCL_P256_VERIFIER)), address(0xC0516)),
                bytes(""),
                new bytes[](0)
            )
        );
        bytes32 userSalt = keccak256("mova task 2 kernel probe");
        address predicted = pm.accountAddress(1, keccak256(abi.encodePacked(initData, userSalt)));
        require(
            IKernelFactoryLike(KERNEL_FACTORY).getAddress(initData, userSalt) == predicted,
            "KernelFactory.getAddress"
        );
        require(
            IKernelFactoryLike(KERNEL_FACTORY).createAccount(initData, userSalt) == predicted,
            "KernelFactory.createAccount"
        );
        require(predicted.code.length != 0, "probe Kernel account");
        require(pm.accountAddress(2, safeSalt) == address(0), "a third factory index");
        console.log(
            "provenance: a Safe from SafeProxyFactory and a Kernel account from KernelFactory both derive (simulated, not broadcast)"
        );
    }

    /// @dev Solady LibClone's ERC-1967 proxy init code (v0.0.168, Kernel v3.1's), as OwnerlessPaymaster.t.sol.
    function _kernelProxyInitCode(address implementation) internal pure returns (bytes memory) {
        return abi.encodePacked(
            hex"603d3d8160223d3973",
            implementation,
            hex"6009",
            hex"5155f3363d3d373d3d363d7f360894a13ba1a3210667c828492db98dca3e2076",
            hex"cc3735a920a3ca505d382bbc545af43d6000803e6038573d6000fd5b3d6000f3"
        );
    }
}
