// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {ReclaimProofBuilder} from "./utils/ReclaimProofBuilder.sol";
import {FiatEscrow} from "../ramp/FiatEscrow.sol";
import {OffRampEscrow} from "../ramp/OffRampEscrow.sol";
import {LPRegistry} from "../ramp/LPRegistry.sol";
import {ReclaimZkTlsVerifier} from "../ramp/ReclaimZkTlsVerifier.sol";
import {IAttestorVerifier} from "../ramp/IAttestorVerifier.sol";
import {IPriceOracle} from "../ramp/IPriceOracle.sol";

contract FixedOracle is IPriceOracle {
    function brlCentsPerUnit() external view returns (uint256, uint64) {
        return (1_500_000, uint64(block.timestamp));
    }
}

/// Entrypoint and pool in one: `assetConfig`, SCOPE and nonce are what the escrow reads to
/// index a shielded delivery for rescue.
contract PoolSink {
    uint256 public constant SCOPE = 7;
    uint256 public nonce;
    uint256 public received;

    function deposit(uint256) external payable returns (uint256) {
        received += msg.value;
        return ++nonce;
    }

    function assetConfig(address) external view returns (address, uint256, uint256, uint256) {
        return (address(this), 0, 0, 0);
    }
}

/// Both ramps settled by a zkTLS proof rather than a trusted quorum - the only way PIX and boleto
/// settle (IAttestorVerifier.provesBankSession): task 2.2 wired to 2.1 and to the off-ramp.
contract ZkTlsRampIntegrationTest is ReclaimProofBuilder {
    FiatEscrow escrow;
    OffRampEscrow offramp;
    LPRegistry registry;
    ReclaimZkTlsVerifier verifier;
    PoolSink pool;

    uint256 w1 = 0x11;
    uint256 w2 = 0x22;
    address governor = address(0x60F);
    address lp = makeAddr("lp");
    address taker = makeAddr("taker");
    address payout = makeAddr("payout");
    address seller = makeAddr("seller");

    bytes32 constant PIX = keccak256("lp@pix.example");
    uint16 constant PIX_MASK = uint16(1 << uint8(IAttestorVerifier.Rail.PIX));
    uint16 constant BOLETO_MASK = uint16(1 << uint8(IAttestorVerifier.Rail.BOLETO));
    /// A second allowlisted endpoint: the bank's boleto-payment receipts.
    bytes32 constant BOLETO_TEMPLATE = keccak256("template: api.bank.example boleto receipt");
    string constant BOLETO_PREFIX = "https://api.bank.example/boletos/";

    function setUp() public {
        vm.warp(1_700_000_000);
        address[] memory set = new address[](2);
        (set[0], set[1]) = vm.addr(w1) < vm.addr(w2)
            ? (vm.addr(w1), vm.addr(w2))
            : (vm.addr(w2), vm.addr(w1));
        bytes32[] memory templates = new bytes32[](2);
        (templates[0], templates[1]) = (BANK_TEMPLATE, BOLETO_TEMPLATE);
        string[] memory prefixes = new string[](2);
        (prefixes[0], prefixes[1]) = (BANK_PREFIX, BOLETO_PREFIX);
        verifier = new ReclaimZkTlsVerifier(governor, DELAY, set, 2, templates, prefixes);
        // The boleto receipt endpoint attests boletos and nothing else; the PIX one stays PIX-only.
        vm.prank(governor);
        verifier.setEndpointRails(BOLETO_TEMPLATE, BOLETO_MASK);
        _completeSetup(address(verifier));

        pool = new PoolSink();
        registry = new LPRegistry(governor, DELAY);
        escrow = new FiatEscrow(
            address(new FixedOracle()), address(registry), address(pool), address(pool), 500, governor, DELAY, DISPUTE_TIMEOUT
        );

        offramp = new OffRampEscrow(address(new FixedOracle()), address(registry), 500, governor, DELAY, DISPUTE_TIMEOUT);

        vm.startPrank(governor);
        registry.setEscrow(address(escrow), true);
        registry.setEscrow(address(offramp), true);
        registry.setTier(lp, LPRegistry.Tier.INSTITUTIONAL, 1_000_000_00);
        registry.completeSetup();
        escrow.setVerifier(address(verifier), true);
        escrow.completeSetup();
        offramp.setVerifier(address(verifier), true);
        offramp.completeSetup();
        vm.stopPrank();
        vm.deal(lp, 50 ether);
        vm.deal(seller, 10 ether);
    }

    function test_OnRampSettledByAZkTlsProof() public {
        vm.prank(lp);
        bytes32 offerId = escrow.postOffer{value: 10 ether}(
            address(0), 10 ether, 1_500_000, PIX, 0.01 ether, 5 ether, address(verifier), PIX_MASK
        );
        vm.prank(taker);
        bytes32 orderId =
            escrow.lockOrder(offerId, 1 ether, FiatEscrow.Delivery.SHIELDED, payout, 777);

        bytes memory proof = _proof(orderId, 1_500_000);
        escrow.releaseWithProof(orderId, proof);

        assertEq(pool.received(), 1 ether, "a TLS session with the bank moved the money");
    }

    /// The end-to-end binding property, through the escrow rather than the verifier alone.
    function test_AZkTlsProofForAnotherOrderIsRefused() public {
        vm.prank(lp);
        bytes32 offerId = escrow.postOffer{value: 10 ether}(
            address(0), 10 ether, 1_500_000, PIX, 0.01 ether, 5 ether, address(verifier), PIX_MASK
        );
        vm.prank(taker);
        bytes32 victim = escrow.lockOrder(offerId, 1 ether, FiatEscrow.Delivery.DIRECT, payout, 0);
        vm.prank(address(0xBAD));
        bytes32 attacker =
            escrow.lockOrder(offerId, 1 ether, FiatEscrow.Delivery.DIRECT, address(0xBAD), 0);

        bytes memory proof = _proof(victim, 1_500_000); // genuine, for the victim's order
        vm.expectRevert(ReclaimZkTlsVerifier.OrderMismatch.selector);
        escrow.releaseWithProof(attacker, proof);

        escrow.releaseWithProof(victim, proof);
        assertEq(payout.balance, 1 ether);
    }

    /// Under-paying is caught by the escrow even though the proof itself is valid.
    function test_AValidProofOfAnUnderpaymentStillDoesNotRelease() public {
        vm.prank(lp);
        bytes32 offerId = escrow.postOffer{value: 10 ether}(
            address(0), 10 ether, 1_500_000, PIX, 0.01 ether, 5 ether, address(verifier), PIX_MASK
        );
        vm.prank(taker);
        bytes32 orderId = escrow.lockOrder(offerId, 1 ether, FiatEscrow.Delivery.DIRECT, payout, 0);
        vm.expectRevert(FiatEscrow.Underpaid.selector);
        escrow.releaseWithProof(orderId, _proof(orderId, 1_499_999));
    }

    /**
     * The critical finding, end to end: the taker pays nothing, runs a server that answers
     * with the payment fields they want, and has real witnesses observe that session. The
     * claim is honestly signed and names this order - and must not release a wei.
     */
    function test_AGenuinelySignedSessionWithTheTakersOwnServerDoesNotRelease() public {
        vm.prank(lp);
        bytes32 offerId = escrow.postOffer{value: 10 ether}(
            address(0), 10 ether, 1_500_000, PIX, 0.01 ether, 5 ether, address(verifier), PIX_MASK
        );
        vm.prank(taker);
        bytes32 orderId = escrow.lockOrder(offerId, 1 ether, FiatEscrow.Delivery.DIRECT, payout, 0);

        Fields memory f = Fields({
            orderId: orderId,
            bankTxId: keccak256("made up"),
            payeeKeyHash: PIX,
            payerRef: keccak256("cpf"),
            amountBrlCents: 1_500_000,
            paidAt: block.timestamp,
            rail: 1
        });
        bytes32 takersTemplate = keccak256("template: taker.example /receipt");
        uint256[] memory keys = new uint256[](2);
        keys[0] = w1;
        keys[1] = w2;
        bytes memory proof = abi.encode(
            _proof(_params("https://taker.example/receipt"), _context(f, takersTemplate), keys)
        );

        vm.expectRevert(
            abi.encodeWithSelector(ReclaimZkTlsVerifier.EndpointNotAllowed.selector, takersTemplate)
        );
        escrow.releaseWithProof(orderId, proof);
        assertEq(payout.balance, 0);
    }

    /*//////////////////////////////////////////////////////////////
                           A BOLETO, BY zkTLS
    //////////////////////////////////////////////////////////////*/

    bytes32 constant ISSUED = keccak256("boletoCommitment(barcode, salt) for this order");

    function _boletoOrder() internal returns (bytes32 orderId) {
        vm.prank(lp);
        bytes32 offerId = escrow.postOffer{value: 10 ether}(
            address(0), 10 ether, 1_500_000, PIX, 0.01 ether, 5 ether, address(verifier), PIX_MASK | BOLETO_MASK
        );
        vm.prank(taker);
        orderId = escrow.lockOrderByBoleto(offerId, 1 ether, FiatEscrow.Delivery.DIRECT, payout, 0);
        vm.prank(lp);
        escrow.issueBoleto(orderId, ISSUED);
    }

    function _boletoProof(bytes32 orderId, bytes32 payee, uint8 rail, bytes32 template, string memory url)
        internal
        view
        returns (bytes memory)
    {
        Fields memory f = Fields({
            orderId: orderId,
            bankTxId: keccak256(abi.encode("boleto auth", orderId)),
            payeeKeyHash: payee,
            payerRef: keccak256("cpf"),
            amountBrlCents: 1_500_000,
            paidAt: block.timestamp,
            rail: rail
        });
        uint256[] memory keys = new uint256[](2);
        keys[0] = w1;
        keys[1] = w2;
        return abi.encode(_proof(_params(url), _context(f, template), keys));
    }

    function test_ABoletoOrderSettledByAZkTlsProofFromTheBoletoEndpoint() public {
        bytes32 orderId = _boletoOrder();
        escrow.releaseWithProof(
            orderId, _boletoProof(orderId, ISSUED, 2, BOLETO_TEMPLATE, "https://api.bank.example/boletos/{{e2eId}}")
        );
        assertEq(payout.balance, 1 ether);
    }

    /// The PIX receipt endpoint cannot vouch for a boleto payment, however it is filled in.
    function test_APixReceiptEndpointCannotSettleABoletoOrder() public {
        bytes32 orderId = _boletoOrder();
        bytes memory proof = _boletoProof(orderId, ISSUED, 2, BANK_TEMPLATE, BANK_URL);
        vm.expectRevert(
            abi.encodeWithSelector(ReclaimZkTlsVerifier.RailNotAllowedForEndpoint.selector, BANK_TEMPLATE, uint8(2))
        );
        escrow.releaseWithProof(orderId, proof);
        // ...and a PIX receipt from it, of the boleto's commitment, is the wrong rail.
        vm.expectRevert(FiatEscrow.RailNotAccepted.selector);
        escrow.releaseWithProof(orderId, _boletoProof(orderId, ISSUED, 1, BANK_TEMPLATE, BANK_URL));
    }

    /// A genuine boleto receipt for a different boleto settles nothing.
    function test_AZkTlsReceiptForAnotherBoletoIsRefused() public {
        bytes32 orderId = _boletoOrder();
        bytes memory proof = _boletoProof(
            orderId, keccak256("some other bill"), 2, BOLETO_TEMPLATE, "https://api.bank.example/boletos/{{e2eId}}"
        );
        vm.expectRevert(FiatEscrow.WrongPayee.selector);
        escrow.releaseWithProof(orderId, proof);
    }

    /*//////////////////////////////////////////////////////////////
                           THE OFF-RAMP, BY zkTLS
    //////////////////////////////////////////////////////////////*/

    bytes32 constant SELLER_PIX = keccak256("pixKeyCommitment(seller key, salt)");
    bytes32 constant BILL = keccak256("boletoCommitment(seller's bill, salt)");

    /// A seller's sale, claimed by the LP, which pays and proves its own bank session.
    function _claimedSale(bytes32 payee, uint16 mask) internal returns (bytes32 saleId) {
        vm.prank(seller);
        saleId = offramp.openSale{value: 1 ether}(address(0), 1 ether, 1_500_000, payee, address(verifier), mask, seller);
        vm.prank(lp);
        offramp.claimSale(saleId);
    }

    function test_ASaleSettledByAZkTlsProofOfTheLpsPixPayout() public {
        bytes32 saleId = _claimedSale(SELLER_PIX, PIX_MASK);
        uint256 before = lp.balance;
        offramp.settleWithProof(saleId, _boletoProof(saleId, SELLER_PIX, 1, BANK_TEMPLATE, BANK_URL));
        assertEq(lp.balance - before, 1 ether, "the LP proved it paid the seller, and took the ETH");
    }

    function test_ABillPaidForASellerSettlesByAZkTlsProofFromTheBoletoEndpoint() public {
        bytes32 saleId = _claimedSale(BILL, BOLETO_MASK);
        // A PIX receipt, even of the bill's commitment, is not the bill paid.
        vm.expectRevert(
            abi.encodeWithSelector(ReclaimZkTlsVerifier.RailNotAllowedForEndpoint.selector, BANK_TEMPLATE, uint8(2))
        );
        offramp.settleWithProof(saleId, _boletoProof(saleId, BILL, 2, BANK_TEMPLATE, BANK_URL));
        offramp.settleWithProof(
            saleId, _boletoProof(saleId, BILL, 2, BOLETO_TEMPLATE, "https://api.bank.example/boletos/{{e2eId}}")
        );
        assertEq(lp.balance, 50 ether + 1 ether);
    }

    /// A genuine proof of the LP paying one seller cannot settle another seller's sale.
    function test_AnOffRampProofIsBoundToItsSale() public {
        bytes32 first = _claimedSale(SELLER_PIX, PIX_MASK);
        bytes32 second = _claimedSale(SELLER_PIX, PIX_MASK);
        bytes memory proof = _boletoProof(first, SELLER_PIX, 1, BANK_TEMPLATE, BANK_URL);
        vm.expectRevert(ReclaimZkTlsVerifier.OrderMismatch.selector);
        offramp.settleWithProof(second, proof);
        offramp.settleWithProof(first, proof);
    }

    /*//////////////////////////////////////////////////////////////
                             PROOF BUILDING
    //////////////////////////////////////////////////////////////*/

    /// A proof as the Reclaim network emits it: see utils/ReclaimProofBuilder.sol.
    function _proof(bytes32 orderId, uint256 cents) internal view returns (bytes memory) {
        Fields memory f = Fields({
            orderId: orderId,
            bankTxId: keccak256(abi.encode(orderId, cents)),
            payeeKeyHash: PIX,
            payerRef: keccak256("cpf"),
            amountBrlCents: cents,
            paidAt: block.timestamp,
            rail: 1
        });
        uint256[] memory keys = new uint256[](2);
        keys[0] = w1;
        keys[1] = w2;
        return abi.encode(_proof(_params(BANK_URL), _context(f, BANK_TEMPLATE), keys));
    }
}
