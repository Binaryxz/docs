// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Governed} from "./utils/Governed.sol";
import {FiatEscrow} from "../ramp/FiatEscrow.sol";
import {LPRegistry} from "../ramp/LPRegistry.sol";
import {ChainlinkBrlOracle, IAggregatorV3} from "../ramp/ChainlinkBrlOracle.sol";
import {IAttestorVerifier} from "../ramp/IAttestorVerifier.sol";

contract MockFeed is IAggregatorV3 {
    int256 public answer;
    uint8 public immutable dec;
    uint256 public at;

    constructor(int256 a, uint8 d) {
        answer = a;
        dec = d;
        at = block.timestamp;
    }

    function set(int256 a, uint256 t) external {
        answer = a;
        at = t;
    }

    function decimals() external view returns (uint8) {
        return dec;
    }

    function latestRoundData() external view returns (uint80, int256, uint256, uint256, uint80) {
        return (1, answer, at, at, 1);
    }
}

/// Entrypoint and pool in one: `assetConfig`, SCOPE and nonce are what the escrow reads to
/// index a shielded delivery for rescue.
contract PoolStub {
    uint256 public constant SCOPE = 7;
    uint256 public nonce;
    uint256 public received;

    function deposit(uint256) external payable returns (uint256) {
        received += msg.value;
        return ++nonce;
    }

    function assetConfig(address) external view returns (address, uint256, uint256, uint256) {
        return (address(this), 0, 0, 0);
    }
}

/// A verifier that takes named parties' word rather than proving the bank session - the kind the
/// escrows refuse for every bank rail. Only its constant answer matters here.
contract WordOnlyVerifier {
    function provesBankSession() external pure returns (bool) {
        return false;
    }
}

/// The ramp with no mocked oracle: the real oracle cross, and a verifier that does not prove the
/// bank session refused for every bank rail.
contract RampIntegrationTest is Governed {
    FiatEscrow escrow;
    LPRegistry registry;
    WordOnlyVerifier verifier;
    ChainlinkBrlOracle oracle;
    MockFeed ethUsd;
    MockFeed brlUsd;
    PoolStub pool;

    uint256 k1 = 0xA11CE;
    uint256 k2 = 0xB0B;
    address governor = address(0x60F);
    // Avoid low addresses: EIP-2537 precompiles occupy 0x0b..0x11 and paying one reverts.
    address lp = makeAddr("lp");
    address taker = makeAddr("taker");
    address payout = makeAddr("payout");
    bytes32 constant PIX = keccak256("lp@pix.example");
    uint16 constant PIX_MASK = uint16(1 << uint8(IAttestorVerifier.Rail.PIX));

    function setUp() public {
        vm.warp(1_700_000_000);
        // ETH = $3,000.00 (8dp); BRL = $0.20 (8dp)  =>  1 ETH = R$15,000 = 1,500,000 centavos
        ethUsd = new MockFeed(3000e8, 8);
        brlUsd = new MockFeed(0.2e8, 8);
        oracle = new ChainlinkBrlOracle(address(ethUsd), address(brlUsd), 1 hours, governor, DELAY);
        _completeSetup(address(oracle));

        verifier = new WordOnlyVerifier();

        pool = new PoolStub();
        registry = new LPRegistry(governor, DELAY);
        escrow =
            new FiatEscrow(address(oracle), address(registry), address(pool), address(pool), 500, governor, DELAY, DISPUTE_TIMEOUT);

        vm.startPrank(governor);
        registry.setEscrow(address(escrow), true);
        registry.setTier(lp, LPRegistry.Tier.INSTITUTIONAL, 1_000_000_00);
        registry.completeSetup();
        escrow.setVerifier(address(verifier), true);
        escrow.completeSetup();
        vm.stopPrank();

        vm.deal(lp, 50 ether);
    }

    function test_OracleCrossesTwoFeedsIntoCentavos() public view {
        (uint256 price,) = oracle.brlCentsPerUnit();
        assertEq(price, 1_500_000, "3000 USD/ETH over 0.20 USD/BRL = R$15,000.00");
    }

    function test_StaleLegStopsTheWholeCross() public {
        brlUsd.set(0.2e8, block.timestamp - 2 hours); // thin market stalls
        vm.expectRevert();
        oracle.brlCentsPerUnit();
    }

    /**
     * PIX, boleto and TED settle only on a proof of the bank session (IAttestorVerifier.
     * provesBankSession). An offer naming a verifier that does not prove it, for any of them, is
     * refused before it holds a wei: however honest the attestors, a colluding quorum could release it
     * against a payment that never happened. The end-to-end PIX and boleto releases - binding to the
     * order, the rail inside what is proven - are in ZkTlsRampIntegration.t.sol.
     */
    function test_AVerifierThatDoesNotProveTheBankSessionCannotBeNamedForABankRail() public {
        assertFalse(verifier.provesBankSession());
        uint16 boleto = uint16(1 << uint8(IAttestorVerifier.Rail.BOLETO));
        uint16 ted = uint16(1 << uint8(IAttestorVerifier.Rail.TED));
        uint16[4] memory masks = [PIX_MASK, boleto, ted, PIX_MASK | boleto | ted];
        for (uint256 i; i < masks.length; ++i) {
            vm.prank(lp);
            vm.expectRevert(FiatEscrow.BankRailNeedsZkTls.selector);
            escrow.postOffer{value: 1 ether}(
                address(0), 1 ether, 1_500_000, PIX, 0.01 ether, 1 ether, address(verifier), masks[i]
            );
        }
        assertEq(address(escrow).balance, 0, "nothing was escrowed");
    }
}
