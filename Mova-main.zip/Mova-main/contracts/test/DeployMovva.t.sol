// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {IERC4626} from "@openzeppelin/contracts/interfaces/IERC4626.sol";
import {DeployMovva} from "../script/DeployMovva.s.sol";
import {TetherLike, StataLike} from "./ERC4626Adapter.t.sol";
import {FxTestFeed} from "./ChainlinkSignedFxOracle.t.sol";
import {YieldVault} from "../yield/YieldVault.sol";
import {ERC4626Adapter} from "../yield/adapters/ERC4626Adapter.sol";
import {SignedPriceOracle} from "../ramp/SignedPriceOracle.sol";
import {PythFxOracle} from "../ramp/PythFxOracle.sol";
import {MockPyth} from "./utils/MockPyth.sol";
import {MockPriceSource} from "./MovvaBreaker.t.sol";
import {DivergenceBreaker} from "../movva/DivergenceBreaker.sol";
import {IPriceSource} from "../movva/IPriceSource.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";
import {MovvaReserve} from "../movva/MovvaReserve.sol";
import {FeeSplitter} from "../movva/FeeSplitter.sol";
import {NodeRewards} from "../ramp/NodeRewards.sol";

/**
 * The Movva deployment script, run for real against the test EVM: what it refuses, what it wires,
 * that it hands everything over with setup closed, and that the result mints once publishers sign.
 *
 * One test function, because environment variables are process-wide and forge runs test functions
 * in parallel - which is also why the script reads only MOVVA_-prefixed names.
 */
contract DeployMovvaTest is Test {
    address governor = makeAddr("movva multisig");
    address guardian = makeAddr("movva guardian");
    address treasurer = makeAddr("movva treasurer");
    address hedge = makeAddr("movva hedge treasury");
    address feeTo = makeAddr("movva fee recipient");
    address lp1 = makeAddr("phase-a gateway 1");
    address lp2 = makeAddr("phase-a gateway 2");
    uint256 p1 = uint256(keccak256("movva publisher 1"));
    uint256 p2 = uint256(keccak256("movva publisher 2"));

    TetherLike usdt;
    FxTestFeed feed;
    YieldVault vault;

    function test_TheScriptRefusesUnsafeConfigWiresAndHandsEverythingOver() public {
        vm.warp(1_800_000_000);
        usdt = new TetherLike();
        feed = new FxTestFeed(99_972_163, 8);
        vault = new YieldVault(IERC20(address(usdt)), "Shielded Yield USDT", "syUSDT", governor, guardian, guardian, 1e15, 100, 48 hours);
        ERC4626Adapter adapter = new ERC4626Adapter(address(vault), IERC4626(address(new StataLike(IERC20(address(usdt))))), "stata");
        vm.prank(governor);
        vault.addAdapter(adapter, 10_000);

        vm.setEnv("MOVVA_GOVERNOR", vm.toString(governor));
        vm.setEnv("MOVVA_GUARDIAN", vm.toString(guardian));
        vm.setEnv("MOVVA_TREASURER", vm.toString(treasurer));
        vm.setEnv("MOVVA_HEDGE_TREASURY", vm.toString(hedge));
        vm.setEnv("MOVVA_FEE_RECIPIENT", vm.toString(feeTo));
        vm.setEnv("MOVVA_USDT", vm.toString(address(usdt)));
        vm.setEnv("MOVVA_USDT_USD_FEED", vm.toString(address(feed)));
        vm.setEnv("MOVVA_FX_PUBLISHERS", string.concat(vm.toString(vm.addr(p1)), ",", vm.toString(vm.addr(p2))));
        vm.setEnv("MOVVA_YIELD_VAULT", vm.toString(address(vault)));
        vm.setEnv("MOVVA_GATEWAYS", string.concat(vm.toString(lp1), ",", vm.toString(lp2)));
        vm.setEnv("MOVVA_MINT_FEE_BPS", "25");
        // The breaker is on by default and needs a source; one already-deployed source stands in here.
        MockPriceSource src = new MockPriceSource();
        src.set(5_399_696_467_956_000_000);
        vm.setEnv("MOVVA_BREAKER_EXTRA_SOURCES", vm.toString(address(src)));

        // 1. Unsafe configurations, each refused before anything is broadcast.
        _refuses("MOVVA_SUPPLY_CAP: a supply cap of zero is not a cap; set one, in whole Movva");
        vm.setEnv("MOVVA_SUPPLY_CAP", "0");
        _refuses("MOVVA_SUPPLY_CAP: a supply cap of zero is not a cap; set one, in whole Movva");
        vm.setEnv("MOVVA_SUPPLY_CAP", "1000000");

        vm.setEnv("MOVVA_FX_MAX_AGE", "0");
        _refuses("MOVVA_FX_MAX_AGE: a max age is seconds, above zero");
        vm.setEnv("MOVVA_FX_MAX_AGE", "3600");
        vm.setEnv("MOVVA_USDT_USD_MAX_AGE", "0");
        _refuses("MOVVA_USDT_USD_MAX_AGE: a max age is seconds, above zero");
        vm.setEnv("MOVVA_USDT_USD_MAX_AGE", "90000");

        feed.set(99_972_163, block.timestamp - 90_001);
        _refuses("MOVVA_USDT_USD_FEED: feed is older than its max age");
        feed.set(0, block.timestamp);
        _refuses("MOVVA_USDT_USD_FEED: feed answers zero or less");
        feed.set(99_972_163, block.timestamp - 20 hours); // a day-heartbeat feed, still inside its max age

        _refuses("MOVVA_YIELD_VAULT: the vault's own setup is still open");
        vm.prank(governor);
        vault.completeSetup();

        // An existing FX leg whose governor could still change who signs at once: one in setup, one
        // that is not a DelayedGovernance at all (a Chainlink feed pasted by mistake), and one whose
        // delay is shorter than the reserve's. Each is refused before its price is even read.
        SignedPriceOracle open = _fxOracleWith(48 hours, false);
        _publish(open, 5_401_200);
        vm.setEnv("MOVVA_FX_E6_ORACLE", vm.toString(address(open)));
        _refuses(
            "MOVVA_FX_E6_ORACLE: setup still open, or its governance is not delayed: its governor could change who signs the rate at once"
        );
        vm.setEnv("MOVVA_FX_E6_ORACLE", vm.toString(address(feed)));
        _refuses(
            "MOVVA_FX_E6_ORACLE: setup still open, or its governance is not delayed: its governor could change who signs the rate at once"
        );
        SignedPriceOracle quick = _fxOracleWith(24 hours, true);
        _publish(quick, 5_401_200);
        vm.setEnv("MOVVA_FX_E6_ORACLE", vm.toString(address(quick)));
        _refuses(
            "MOVVA_FX_E6_ORACLE: governance delay shorter than MOVVA_GOVERNANCE_DELAY, so a publisher change would give holders less notice"
        );

        // The ramps' centavo FX instance, pointed at by mistake: 540 is not R$ 5,40 at 1e-6.
        SignedPriceOracle centavos = _fxOracle();
        _publish(centavos, 540);
        vm.setEnv("MOVVA_FX_E6_ORACLE", vm.toString(address(centavos)));
        _refuses("MOVVA_FX_E6_ORACLE: not BRL per USD at 1e-6 (the ramps' centavo instance, or the wrong unit signed)");
        SignedPriceOracle stale = _fxOracle();
        _publish(stale, 5_401_200);
        vm.warp(block.timestamp + 3_601);
        vm.setEnv("MOVVA_FX_E6_ORACLE", vm.toString(address(stale)));
        _refuses("MOVVA_FX_E6_ORACLE: no price within MOVVA_FX_MAX_AGE");
        vm.setEnv("MOVVA_FX_E6_ORACLE", "");
        feed.set(99_972_163, block.timestamp);

        // The first proposal's ratios, 102% target under a 105% withdraw floor, are out of order.
        vm.setEnv("MOVVA_TARGET_RATIO_BPS", "10200");
        vm.setEnv("MOVVA_MIN_WITHDRAW_RATIO_BPS", "10500");
        _refuses("MOVVA_*_RATIO_BPS: must be ordered mint floor <= withdraw floor <= target");
        vm.setEnv("MOVVA_TARGET_RATIO_BPS", "");
        vm.setEnv("MOVVA_MIN_WITHDRAW_RATIO_BPS", "");

        // Node-provider rewards past what the splitter and NodeRewards would accept.
        vm.setEnv("MOVVA_LP_REWARD_SHARE_BPS", "5001");
        _refuses("MOVVA_LP_REWARD_SHARE_BPS: above 5000, the splitter's cap on the LPs' share of Mova's fees");
        vm.setEnv("MOVVA_LP_REWARD_SHARE_BPS", "");
        vm.setEnv("MOVVA_LP_REWARD_BPS_OF_VOLUME", "21");
        _refuses("MOVVA_LP_REWARD_BPS_OF_VOLUME: above 20, more per real settled than the mint and redeem fees together");
        vm.setEnv("MOVVA_LP_REWARD_BPS_OF_VOLUME", "");
        vm.setEnv("MOVVA_LP_REWARD_EPOCH_SECONDS", "86399");
        _refuses("MOVVA_LP_REWARD_EPOCH_SECONDS: an epoch is 1 to 28 days");
        vm.setEnv("MOVVA_LP_REWARD_EPOCH_SECONDS", "");
        vm.setEnv("MOVVA_LP_REWARD_REVIEW_SECONDS", "1209601");
        _refuses("MOVVA_LP_REWARD_REVIEW_SECONDS: a review period is 1 to 14 days");
        vm.setEnv("MOVVA_LP_REWARD_REVIEW_SECONDS", "");

        // 2. A full deployment with a new FX leg.
        DeployMovva.Deployed memory d = new DeployMovva().run();
        MovvaReserve r = d.reserve;
        assertTrue(d.fxDeployedHere);
        assertEq(r.governor(), governor, "handed over");
        assertTrue(r.setupComplete(), "setup closed");
        assertEq(r.GOVERNANCE_DELAY(), 48 hours, "default delay");
        assertEq(SignedPriceOracle(d.fx).governor(), governor, "the FX leg too");
        assertEq(SignedPriceOracle(d.fx).threshold(), 2);
        assertTrue(SignedPriceOracle(d.fx).setupComplete(), "the FX leg's setup closed too");
        assertEq(SignedPriceOracle(d.fx).GOVERNANCE_DELAY(), 48 hours, "with the reserve's delay");
        assertEq(d.movva.RESERVE(), address(r));
        assertEq(address(d.band.SOURCE()), d.fx, "the ramps' adapter reads the same signed leg");
        assertEq(address(r.yieldVault()), address(vault));
        assertTrue(r.isGateway(lp1) && r.isGateway(lp2), "Phase A gateways admitted during setup");
        assertEq(r.supplyCap(), 1_000_000e18);
        assertEq(r.mintFeeBps(), 25, "an override from the environment");
        assertEq(r.redeemFeeBps(), 10, "the traditional-finance default: 0.10% to redeem");
        assertEq(r.targetCollateralRatioBps(), 10_800, "the sized defaults (docs/movva.md, Sizing the buffer)");
        assertEq(r.minMintCollateralRatioBps(), 10_000);
        assertEq(r.minWithdrawCollateralRatioBps(), 10_300);
        assertEq(r.hedgeLimitBps(), 800);
        assertEq(r.usdtUsdMaxAge(), 90_000);
        assertEq(r.fxMaxAge(), 3_600);
        assertEq(r.treasurer(), treasurer);
        assertEq(r.hedgeTreasury(), hedge);
        assertEq(r.guardian(), guardian);
        _assertRewardsWired(d, 0);

        // Nothing prices until the publishers sign; then a gateway mints into the vault.
        vm.expectRevert(SignedPriceOracle.NoPriceYet.selector);
        r.brlPerUsdtE18();
        _publish(SignedPriceOracle(d.fx), 5_401_200);
        (uint256 cents,) = d.band.brlCentsPerUnit();
        assertEq(cents, 540);
        usdt.mint(lp1, 1_000e6);
        vm.startPrank(lp1);
        usdt.approve(address(r), type(uint256).max);
        uint256 out = r.mint(1_000e6, lp1, 0);
        vm.stopPrank();
        // 1,000 x 0.99972163 x 5.4012 = 5,399.696467956 Movva, less 25 bps (13.49924116989) to the fee recipient.
        assertEq(out, 5_386_197_226_786_110_000_000);
        assertEq(d.movva.balanceOf(address(d.splitter)), 13_499_241_169_890_000_000, "the fee reached the splitter");
        d.splitter.split();
        assertEq(d.movva.balanceOf(feeTo), 13_499_241_169_890_000_000, "a share of zero: all of it to the treasury");
        assertEq(vault.totalAssets(), 1_000e6);

        // The real governor waits like everyone else - on the reserve, and on who signs its rate.
        vm.prank(governor);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, MovvaReserve.setGateway.selector));
        r.setGateway(makeAddr("another"), true);
        vm.startPrank(governor);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, SignedPriceOracle.setPublisher.selector)
        );
        SignedPriceOracle(d.fx).setPublisher(makeAddr("another publisher"), true);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, SignedPriceOracle.setThreshold.selector)
        );
        SignedPriceOracle(d.fx).setThreshold(1);
        vm.stopPrank();

        // 3. With an existing millionths FX leg, signed and fresh.
        SignedPriceOracle live = _fxOracle();
        _publish(live, 5_401_200);
        vm.setEnv("MOVVA_FX_E6_ORACLE", vm.toString(address(live)));
        vm.setEnv("MOVVA_GATEWAYS", "");
        // And the rewards settings, every one from the environment.
        vm.setEnv("MOVVA_LP_REWARD_SHARE_BPS", "2500");
        vm.setEnv("MOVVA_LP_REWARD_BPS_OF_VOLUME", "5");
        vm.setEnv("MOVVA_LP_REWARD_CAP_PER_EPOCH", "2000");
        vm.setEnv("MOVVA_LP_REWARD_MIN_CENTS", "5000");
        vm.setEnv("MOVVA_LP_REWARD_EPOCH_SECONDS", "86400");
        vm.setEnv("MOVVA_LP_REWARD_REVIEW_SECONDS", "172800");
        d = new DeployMovva().run();
        assertFalse(d.fxDeployedHere);
        _assertRewardsWired(d, 2_500);
        assertEq(d.rewards.rewardBpsOfVolume(), 5);
        assertEq(d.rewards.maxRewardPerLpPerEpoch(), 2_000e18);
        assertEq(d.rewards.minCountedCents(), 5_000);
        assertEq(d.rewards.EPOCH_LENGTH(), 1 days);
        assertEq(d.rewards.REVIEW_PERIOD(), 2 days);
        for (uint256 i; i < 6; ++i) {
            vm.setEnv(
                ["MOVVA_LP_REWARD_SHARE_BPS", "MOVVA_LP_REWARD_BPS_OF_VOLUME", "MOVVA_LP_REWARD_CAP_PER_EPOCH", "MOVVA_LP_REWARD_MIN_CENTS", "MOVVA_LP_REWARD_EPOCH_SECONDS", "MOVVA_LP_REWARD_REVIEW_SECONDS"][i],
                ""
            );
        }
        assertEq(address(d.reserve.fxOracle()), address(live));
        assertEq(SignedPriceOracle(address(live)).governor(), address(this), "an existing leg's governor is not the script's to move");
        (uint256 rate,) = d.reserve.brlPerUsdtE18();
        assertEq(rate, 5_399_696_467_956_000_000);
        vm.setEnv("MOVVA_FX_E6_ORACLE", "");
        vm.setEnv("MOVVA_MINT_FEE_BPS", "");

        // 4. The default path, Mova's choice: neither publishers nor an existing leg - a PythFxOracle.
        vm.setEnv("MOVVA_FX_PUBLISHERS", "");
        _refuses("MOVVA_PYTH: no Pyth contract at that address on this chain (or set MOVVA_FX_E6_ORACLE / MOVVA_FX_PUBLISHERS)");
        MockPyth pyth = new MockPyth(1);
        vm.setEnv("MOVVA_PYTH", vm.toString(address(pyth)));
        vm.setEnv("MOVVA_FX_CLOSED_MAX_AGE", "345601");
        _refuses("MOVVA_FX_CLOSED_MAX_AGE: above 4 days, which is no longer a market closure");
        vm.setEnv("MOVVA_FX_CLOSED_MAX_AGE", "");

        d = new DeployMovva().run();
        assertTrue(d.fxDeployedHere && d.fxIsPyth);
        PythFxOracle leg = PythFxOracle(d.fx);
        assertEq(address(leg.PYTH()), address(pyth));
        assertEq(leg.usdBrlId(), 0xd2db4dbf1aea74e0f666b0e8f73b9580d407f5e5cf931940b06dc633d7a95906, "FX.USD/BRL by default");
        assertEq(leg.governor(), governor, "the Pyth leg handed over");
        assertTrue(leg.setupComplete(), "with setup closed");
        assertEq(leg.GOVERNANCE_DELAY(), 48 hours);
        assertEq(leg.maxAge(), 3_600, "the rate's max age is the reserve's");
        assertEq(leg.closedMaxAge(), 4 days);
        assertEq(leg.maxConfBps(), 100);
        assertEq(address(d.band.SOURCE()), d.fx, "the ramps' adapter reads the same leg");

        // Nothing prices until the keeper posts the feed; then the reserve and the band both do.
        vm.expectRevert(MockPyth.PriceFeedNotFound.selector);
        d.reserve.brlPerUsdtE18();
        pyth.set(leg.usdBrlId(), 540_120, 50, -5, block.timestamp);
        (rate,) = d.reserve.brlPerUsdtE18();
        assertEq(rate, 5_399_696_467_956_000_000);
        (uint256 bandCents,) = d.band.brlCentsPerUnit();
        assertEq(bandCents, 540);
        vm.setEnv("MOVVA_PYTH", "");

        _breakerStep(live, src);
    }

    /// The breaker and the hedge queue: immutable, wired from the environment, and "no breaker" is a decision.
    function _breakerStep(SignedPriceOracle live, MockPriceSource src) internal {
        DeployMovva.Deployed memory d;
        vm.setEnv("MOVVA_FX_E6_ORACLE", vm.toString(address(live)));
        _publish(live, 5_401_200);
        d = new DeployMovva().run();
        assertEq(address(d.reserve.BREAKER()), address(d.breaker));
        assertEq(d.breaker.BAND_BPS(), 300, "the default band");
        assertTrue(d.breaker.HALTS_REDEEM());
        assertEq(d.breaker.sourceCount(), 1);
        (IPriceSource s0, bool trips) = d.breaker.sourceAt(0);
        assertEq(address(s0), address(src));
        assertTrue(trips);
        assertEq(d.reserve.HEDGE_QUEUE_DELAY(), 1 days);
        assertFalse(d.reserve.breakerTripped(), "in band");
        src.set(10e18);
        assertTrue(d.reserve.breakerTripped(), "a source far off halts");
        src.set(5_399_696_467_956_000_000);
        assertFalse(d.reserve.breakerTripped(), "and clears by itself");

        vm.setEnv("MOVVA_BREAKER_BAND_BPS", "150");
        vm.setEnv("MOVVA_BREAKER_HALTS_REDEEM", "false");
        vm.setEnv("MOVVA_HEDGE_QUEUE_DELAY", "172800");
        d = new DeployMovva().run();
        assertEq(d.breaker.BAND_BPS(), 150);
        assertFalse(d.breaker.HALTS_REDEEM());
        assertEq(d.reserve.HEDGE_QUEUE_DELAY(), 2 days);
        vm.setEnv("MOVVA_HEDGE_QUEUE_DELAY", "60");
        _refuses("MOVVA_HEDGE_QUEUE_DELAY: 1 hour to 30 days");
        vm.setEnv("MOVVA_HEDGE_QUEUE_DELAY", "");
        vm.setEnv("MOVVA_BREAKER_BAND_BPS", "");
        vm.setEnv("MOVVA_BREAKER_HALTS_REDEEM", "");

        vm.setEnv("MOVVA_BREAKER_EXTRA_SOURCES", "");
        _refuses("MOVVA_BREAKER: no source configured (MOVVA_BREAKER_BRL_USD_FEED / _TWAP_POOL / _EXTRA_SOURCES); say MOVVA_BREAKER=off to deploy without a breaker");
        vm.setEnv("MOVVA_BREAKER", "off");
        d = new DeployMovva().run();
        assertEq(address(d.reserve.BREAKER()), address(0));
        assertFalse(d.reserve.breakerTripped());

        vm.setEnv("MOVVA_BREAKER", "");
        vm.setEnv("MOVVA_FX_E6_ORACLE", "");
    }

    /// The fees go through the splitter, the splitter funds NodeRewards, both closed and handed over, nothing bound yet.
    function _assertRewardsWired(DeployMovva.Deployed memory d, uint16 share) internal {
        FeeSplitter s = d.splitter;
        NodeRewards n = d.rewards;
        assertEq(d.reserve.feeRecipient(), address(s), "the reserve pays its fees to the splitter");
        assertEq(s.treasury(), feeTo, "MOVVA_FEE_RECIPIENT is the treasury behind it");
        assertEq(s.rewards(), address(n));
        assertEq(s.lpRewardShareBps(), share);
        assertEq(address(s.TOKEN()), address(d.movva));
        assertEq(address(n.REWARD_TOKEN()), address(d.movva));
        assertEq(n.TOKEN_PER_CENT(), 1e16, "R$ 1,00 is 1e18 Movva");
        assertEq(s.governor(), governor);
        assertEq(n.governor(), governor);
        assertTrue(s.setupComplete() && n.setupComplete());
        assertEq(n.registry(), address(0), "bound later, to the registry DeployRamp deploys");
        if (share == 0) {
            assertEq(n.rewardBpsOfVolume(), 10, "10 bps of volume: the mint fee");
            assertEq(n.maxRewardPerLpPerEpoch(), 10_000e18);
            assertEq(n.minCountedCents(), 1_000);
            assertEq(n.EPOCH_LENGTH(), 7 days);
            assertEq(n.REVIEW_PERIOD(), 3 days);
        }
        // The real governor raises the share like any other risk-raising change: through the delay.
        vm.prank(governor);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, FeeSplitter.setLpRewardShare.selector));
        s.setLpRewardShare(share + 1);
    }

    function _refuses(string memory why) internal {
        DeployMovva script = new DeployMovva();
        try script.run() {
            revert(string.concat("deployed despite: ", why));
        } catch (bytes memory reason) {
            assertEq(reason, abi.encodeWithSignature("Error(string)", why), why);
        }
    }

    /// A millionths FX leg as an existing deployment would have it: setup closed, the default delay.
    function _fxOracle() internal returns (SignedPriceOracle) {
        return _fxOracleWith(48 hours, true);
    }

    function _fxOracleWith(uint256 delay, bool closeSetup) internal returns (SignedPriceOracle o) {
        address[] memory pubs = new address[](2);
        (pubs[0], pubs[1]) = (vm.addr(p1), vm.addr(p2));
        o = new SignedPriceOracle(address(this), delay, pubs, 2);
        if (closeSetup) o.completeSetup();
    }

    function _publish(SignedPriceOracle o, uint256 value) internal {
        uint64 at = uint64(block.timestamp);
        uint64 seq = o.sequence() + 1;
        bytes32 dg = o.digest(value, at, seq);
        (uint256 lo, uint256 hi) = vm.addr(p1) < vm.addr(p2) ? (p1, p2) : (p2, p1);
        bytes[] memory sigs = new bytes[](2);
        (uint8 v, bytes32 rr, bytes32 s) = vm.sign(lo, dg);
        sigs[0] = abi.encodePacked(rr, s, v);
        (v, rr, s) = vm.sign(hi, dg);
        sigs[1] = abi.encodePacked(rr, s, v);
        o.submit(value, at, seq, sigs);
    }
}
