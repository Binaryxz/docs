// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test, Vm} from "forge-std/Test.sol";
import {DeployRamp} from "../script/DeployRamp.s.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";
import {LPRegistry} from "../ramp/LPRegistry.sol";
import {ReclaimZkTlsVerifier} from "../ramp/ReclaimZkTlsVerifier.sol";
import {SignedPriceOracle} from "../ramp/SignedPriceOracle.sol";
import {FiatEscrow} from "../ramp/FiatEscrow.sol";
import {OffRampEscrow} from "../ramp/OffRampEscrow.sol";
import {ChainlinkSignedFxOracle} from "../ramp/ChainlinkSignedFxOracle.sol";
import {PythFxOracle} from "../ramp/PythFxOracle.sol";
import {ScaledFxBandOracle} from "../movva/ScaledFxBandOracle.sol";
import {MockPyth} from "./utils/MockPyth.sol";
import {FxTestFeed} from "./ChainlinkSignedFxOracle.t.sol";
import {TetherLike} from "./ERC4626Adapter.t.sol";
import {PoolStub} from "./RampIntegration.t.sol";
import {IAttestorVerifier} from "../ramp/IAttestorVerifier.sol";
import {Movva} from "../movva/Movva.sol";
import {MovvaReserve} from "../movva/MovvaReserve.sol";
import {NodeRewards} from "../ramp/NodeRewards.sol";

/// Tether-shaped where the script looks: `decimals` is a uint256, as on the mainnet token, and it
/// has Tether's blacklist, so the script must cap it.
contract DeployTestUsdt {
    uint256 public decimals = 6;
    mapping(address => bool) public isBlackListed;
}

/// A token that names its deployer as its only minter, like Movva - with 6 decimals.
contract SixDecimalMovva {
    address public immutable RESERVE;

    constructor() {
        RESERVE = msg.sender;
    }

    function decimals() external pure returns (uint8) {
        return 6;
    }
}

/// Bound to its token exactly as MovvaReserve is; the token is what is wrong.
contract ReserveOfASixDecimalToken {
    address public immutable MOVVA;

    constructor() {
        MOVVA = address(new SixDecimalMovva());
    }
}

/// Names the real Movva as its token without being the reserve that minted it.
contract ImpostorReserve {
    address public immutable MOVVA;

    constructor(address movva) {
        MOVVA = movva;
    }
}

/// An Entrypoint with no pool registered for anything.
contract EntrypointWithoutPools {
    function assetConfig(address) external pure returns (address, uint256, uint256, uint256) {}
}

/**
 * The deployment script, run for real against the test EVM.
 *
 * The script asserts its own wiring, but an assertion nobody runs is a comment. This runs it
 * and checks what the findings were about: that it refuses to deploy a zkTLS verifier with
 * no bank endpoints, that the oracle's governor is handed over, and that every delayed
 * contract leaves setup closed. And the L1 price configuration: one signed FX leg crossed
 * with a Chainlink feed per asset, USDT listed on both escrows with the decimals read from the
 * token, every oracle handed over - and a feed that cannot serve the band refused at deploy.
 *
 * The same configuration against the real mainnet USDT, feeds and Entrypoint is rehearsed on an
 * anvil fork in docs/runbook-mainnet-deploy.md; the escrows' USDT behaviour on that fork is
 * UsdtRampFork.t.sol.
 */
contract DeployRampTest is Test {
    address governor = makeAddr("multisig");
    address arbitrator = makeAddr("arbitrator");
    address lp = makeAddr("phase-a-lp");
    // Keys, not just addresses: the L1 scenario signs an FX rate with them.
    uint256 p1 = uint256(keccak256("price publisher 1"));
    uint256 p2 = uint256(keccak256("price publisher 2"));

    /// One test function, because environment variables are process-wide and forge runs
    /// test functions in parallel.
    function test_TheScriptRefusesAnEmptyAllowlistAndHandsEverythingOver() public {
        vm.setEnv("GOVERNOR", vm.toString(governor));
        vm.setEnv("PP_ENTRYPOINT", vm.toString(makeAddr("entrypoint")));
        vm.setEnv("PP_POOL", vm.toString(makeAddr("pool")));
        vm.setEnv("ARBITRATOR", vm.toString(arbitrator));
        vm.setEnv(
            "ZKTLS_WITNESSES", string.concat(vm.toString(makeAddr("a1")), ",", vm.toString(makeAddr("a2")))
        );
        vm.setEnv("ORACLE_KIND", "signed");
        vm.setEnv("PRICE_PUBLISHERS", string.concat(vm.toString(vm.addr(p1)), ",", vm.toString(vm.addr(p2))));
        vm.setEnv("INSTITUTIONAL_LPS", vm.toString(lp));
        vm.setEnv("INSTITUTIONAL_CREDIT_CENTS", "500000");

        // 1. Configured: it deploys, and hands over everything including the oracle.
        vm.setEnv("ZKTLS_PROVIDER_HASHES", vm.toString(keccak256("bank template")));
        vm.setEnv("ZKTLS_URL_PREFIXES", "https://api.bank.example/pix/");
        // PIX + BOLETO for the one endpoint; unset would leave it PIX-only.
        vm.setEnv("ZKTLS_ENDPOINT_RAILS", "6");
        vm.recordLogs();
        DeployRamp script = new DeployRamp();
        script.run();

        Vm.Log[] memory logs = vm.getRecordedLogs();
        address oracle;
        address registry;
        address zktls;
        uint256 delayed;
        uint256 escrows;
        for (uint256 i; i < logs.length; ++i) {
            if (logs[i].topics[0] == DelayedGovernance.SetupCompleted.selector) ++delayed;
            if (logs[i].topics[0] == SignedPriceOracle.PublisherSet.selector) oracle = logs[i].emitter;
            if (logs[i].topics[0] == LPRegistry.EscrowSet.selector) registry = logs[i].emitter;
            if (logs[i].topics[0] == ReclaimZkTlsVerifier.EndpointAllowed.selector) zktls = logs[i].emitter;
            if (logs[i].topics[0] == FiatEscrow.ArbitratorSet.selector) {
                // Both escrows emit it, and both must carry the default dispute timeout.
                assertEq(FiatEscrow(payable(logs[i].emitter)).DISPUTE_TIMEOUT(), 30 days, "default dispute timeout");
                ++escrows;
            }
        }
        assertEq(delayed, 5, "registry, the zkTLS verifier, both escrows and the oracle closed setup");
        assertEq(SignedPriceOracle(oracle).governor(), governor, "the oracle's governor was handed over");
        assertTrue(SignedPriceOracle(oracle).setupComplete(), "the oracle's setup closed");
        assertEq(SignedPriceOracle(oracle).GOVERNANCE_DELAY(), 48 hours);
        assertEq(LPRegistry(registry).governor(), governor);
        assertEq(LPRegistry(registry).GOVERNANCE_DELAY(), 48 hours, "default delay");
        assertEq(LPRegistry(registry).capOf(lp), 500_000, "Phase A LP admitted during setup");
        assertEq(ReclaimZkTlsVerifier(zktls).endpointUrlPrefix(keccak256("bank template")), "https://api.bank.example/pix/");
        assertEq(ReclaimZkTlsVerifier(zktls).endpointRails(keccak256("bank template")), 6, "endpoint widened to boletos");
        assertEq(escrows, 2);

        // And the new governor cannot skip the delay on day one.
        vm.prank(governor);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, LPRegistry.setTier.selector)
        );
        LPRegistry(registry).setTier(makeAddr("another"), LPRegistry.Tier.INSTITUTIONAL, 1);
        // Nor add a publisher to the band's signers.
        vm.prank(governor);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, SignedPriceOracle.setPublisher.selector)
        );
        SignedPriceOracle(oracle).setPublisher(makeAddr("another publisher"), true);

        _theL1PriceConfigurationListsUsdt();
        _theL1ConfigurationOnPyth();
        _aFeedThatCannotServeTheBandIsRefusedAtDeploy();
        _movvaGetsItsOwnTightPair();
        _movvaOnlyWithMainPairOff();

        // 4. No endpoint allowlist: the deployment must not happen. It used to default to
        //    "http", which every Reclaim claim matches. (Last, because a reverted script
        //    leaves its broadcast open in the test EVM.)
        vm.setEnv("ZKTLS_PROVIDER_HASHES", "");
        vm.setEnv("ZKTLS_URL_PREFIXES", "");
        vm.setEnv("ZKTLS_ENDPOINT_RAILS", "");
        script = new DeployRamp();
        try script.run() {
            revert("deployed a zkTLS verifier with no bank endpoint allowlist");
        } catch (bytes memory reason) {
            assertEq(
                reason,
                abi.encodeWithSignature(
                    "Error(string)", "ZKTLS_PROVIDER_HASHES is empty: the zkTLS verifier needs bank endpoints"
                ),
                "refused for the right reason"
            );
        }
    }

    /// What the L1 scenario deployed, recovered from its events.
    struct L1 {
        address fx;
        address ethOracle;
        address usdtOracle;
        address onramp;
        address offramp;
        address usdt;
        uint256 listings;
    }

    /**
     * 2. ORACLE_KIND=signed-fx with USDT in USD_FEED_ASSETS: the configuration for Ethereum L1.
     *    Publishers sign one FX number; ETH and USDT each cross it with their own feed.
     */
    function _theL1PriceConfigurationListsUsdt() private {
        FxTestFeed ethUsd = new FxTestFeed(248_368_328_680, 8); // $2,483.68328680
        FxTestFeed usdtUsd = new FxTestFeed(99_972_163, 8); // $0.99972163
        vm.warp(block.timestamp + 20 hours); // the USDT feed a day-heartbeat old; still in its max age
        ethUsd.set(248_368_328_680, block.timestamp - 30 minutes);

        vm.setEnv("ORACLE_KIND", "signed-fx");
        vm.setEnv("FX_SOURCE", "signed"); // this scenario's publishers sign the FX leg; Pyth is 2b
        vm.setEnv("CHAINLINK_ETH_USD", vm.toString(address(ethUsd)));
        vm.setEnv("ETH_USD_MAX_AGE", "4500");
        vm.setEnv("USD_FEEDS", vm.toString(address(usdtUsd)));
        vm.setEnv("USD_FEED_MAX_AGES", "90000");

        // A token its issuer can freeze is not listed without a cap (SR2-25).
        vm.setEnv("USD_FEED_ASSETS", vm.toString(address(new DeployTestUsdt())));
        DeployRamp uncapped = new DeployRamp();
        try uncapped.run() {
            revert("listed a freezable token with no cap");
        } catch (bytes memory reason) {
            assertEq(
                reason,
                abi.encodeWithSignature(
                    "Error(string)", "a listed token's issuer can freeze the escrow: give it a cap in ASSET_CAP_TOKENS / ASSET_CAPS"
                ),
                "refused for the right reason"
            );
        }
        vm.stopBroadcast();

        L1 memory x = _deployL1(address(ethUsd), address(usdtUsd));
        assertEq(FiatEscrow(payable(x.onramp)).assetCap(x.usdt), 250_000e6, "on-ramp capped");
        assertEq(OffRampEscrow(x.offramp).assetCap(x.usdt), 250_000e6, "off-ramp capped");

        assertTrue(x.fx != address(0) && x.ethOracle != address(0) && x.usdtOracle != address(0), "all three oracles");
        assertEq(x.listings, 2, "USDT listed on both escrows");
        assertEq(address(FiatEscrow(payable(x.onramp)).ORACLE()), x.ethOracle, "ETH's band is the cross");
        _assertListed(x.onramp, x);
        _assertListed(x.offramp, x);

        ChainlinkSignedFxOracle u = ChainlinkSignedFxOracle(x.usdtOracle);
        ChainlinkSignedFxOracle e = ChainlinkSignedFxOracle(x.ethOracle);
        assertEq(address(u.usdBrl()), x.fx, "USDT crosses the one FX leg");
        assertEq(address(e.usdBrl()), x.fx, "and so does ETH");
        assertEq(u.assetMaxAge(), 90_000);
        assertEq(e.assetMaxAge(), 4_500);
        assertEq(u.fxMaxAge(), 1 hours, "FX_MAX_AGE defaults to the escrows' own price window");
        assertEq(u.governor(), governor, "USDT oracle handed over");
        assertEq(e.governor(), governor, "ETH oracle handed over");
        assertEq(SignedPriceOracle(x.fx).governor(), governor, "FX leg handed over");
        assertTrue(u.setupComplete() && e.setupComplete() && SignedPriceOracle(x.fx).setupComplete(), "all three closed setup");
        assertEq(u.GOVERNANCE_DELAY(), 48 hours);
        assertEq(SignedPriceOracle(x.fx).GOVERNANCE_DELAY(), 48 hours);

        // The publishers sign R$5.40 per dollar, once, and both bands price.
        _publish(SignedPriceOracle(x.fx), 540);
        (uint256 usdtCents,) = u.brlCentsPerUnit();
        (uint256 ethCents,) = e.brlCentsPerUnit();
        assertEq(usdtCents, 540, "0.99972163 x 540 = 539.85 -> R$5.40 per USDT");
        assertEq(ethCents, 1_341_189, "2,483.68328680 x 540 = 1,341,188.97 -> R$13,411.89 per ETH");

        // Listing another asset after this is the delayed path, for the real governor too.
        vm.prank(governor);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, OffRampEscrow.setAsset.selector)
        );
        OffRampEscrow(x.offramp).setAsset(makeAddr("another token"), x.usdtOracle, 6, true);
        // And so is repointing an asset's band inside its oracle, which used to be instant.
        vm.prank(governor);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, ChainlinkSignedFxOracle.setLegs.selector)
        );
        u.setLegs(address(usdtUsd), makeAddr("the governor's own leg"), 90_000, 1 hours);
    }

    /**
     * 2b. The same L1 configuration with the FX leg from Pyth, the default: a PythFxOracle in millionths,
     *     read by every cross through the centavo adapter, handed over with its setup closed.
     */
    function _theL1ConfigurationOnPyth() private {
        MockPyth pyth = new MockPyth(1);
        FxTestFeed usdtUsd = new FxTestFeed(99_972_163, 8);
        vm.setEnv("FX_SOURCE", "");
        vm.setEnv("PYTH", vm.toString(address(pyth)));
        vm.setEnv("CHAINLINK_ETH_USD", vm.toString(address(new FxTestFeed(248_368_328_680, 8))));
        vm.setEnv("USD_FEEDS", vm.toString(address(usdtUsd)));
        address token = address(new DeployTestUsdt());
        vm.setEnv("USD_FEED_ASSETS", vm.toString(token));
        vm.setEnv("ASSET_CAP_TOKENS", vm.toString(token));

        vm.recordLogs();
        new DeployRamp().run();
        PythL1 memory x = _pythL1(vm.getRecordedLogs(), address(usdtUsd));
        PythFxOracle p = PythFxOracle(x.leg);
        assertEq(address(ScaledFxBandOracle(x.band).SOURCE()), x.leg, "every cross reads Pyth through the centavo adapter");
        assertEq(p.governor(), governor, "the Pyth leg handed over");
        assertTrue(p.setupComplete(), "with setup closed");
        assertEq(p.GOVERNANCE_DELAY(), 48 hours);
        assertEq(p.usdBrlId(), 0xd2db4dbf1aea74e0f666b0e8f73b9580d407f5e5cf931940b06dc633d7a95906, "FX.USD/BRL by default");
        assertEq(p.maxAge(), 1 hours);
        assertEq(p.closedMaxAge(), 4 days);

        // The keeper posts R$ 5,40 per dollar, and USDT's band prices from it.
        pyth.set(p.usdBrlId(), 540_000, 50, -5, block.timestamp);
        (uint256 cents,) = ChainlinkSignedFxOracle(x.usdtOracle).brlCentsPerUnit();
        assertEq(cents, 540);
        vm.setEnv("FX_SOURCE", "signed");
    }

    struct PythL1 {
        address leg;
        address band;
        address usdtOracle;
    }

    function _pythL1(Vm.Log[] memory logs, address usdtFeed) private pure returns (PythL1 memory x) {
        for (uint256 i; i < logs.length; ++i) {
            bytes32 t = logs[i].topics[0];
            if (t == PythFxOracle.LimitsSet.selector) x.leg = logs[i].emitter;
            if (t == ChainlinkSignedFxOracle.LegsSet.selector) {
                (address feed, address fx,,) = abi.decode(logs[i].data, (address, address, uint64, uint64));
                x.band = fx;
                if (feed == usdtFeed) x.usdtOracle = logs[i].emitter;
            }
        }
    }

    function _deployL1(address ethFeed, address usdtFeed) private returns (L1 memory x) {
        x.usdt = address(new DeployTestUsdt());
        vm.setEnv("USD_FEED_ASSETS", vm.toString(x.usdt));
        vm.setEnv("ASSET_CAP_TOKENS", vm.toString(x.usdt));
        vm.setEnv("ASSET_CAPS", "250000000000");
        vm.recordLogs();
        new DeployRamp().run();
        Vm.Log[] memory logs = vm.getRecordedLogs();
        for (uint256 i; i < logs.length; ++i) {
            bytes32 t = logs[i].topics[0];
            if (t == SignedPriceOracle.PublisherSet.selector) x.fx = logs[i].emitter;
            if (t == ChainlinkSignedFxOracle.LegsSet.selector) {
                (address feed,,,) = abi.decode(logs[i].data, (address, address, uint64, uint64));
                if (feed == ethFeed) x.ethOracle = logs[i].emitter;
                if (feed == usdtFeed) x.usdtOracle = logs[i].emitter;
            }
            if (t == FiatEscrow.ArbitratorSet.selector) {
                if (x.onramp == address(0)) x.onramp = logs[i].emitter;
                else x.offramp = logs[i].emitter;
            }
            if (t == FiatEscrow.AssetSet.selector && logs[i].topics[1] == bytes32(uint256(uint160(x.usdt)))) {
                ++x.listings;
            }
        }
    }

    function _assertListed(address escrow, L1 memory x) private view {
        (bool ok, bytes memory ret) = escrow.staticcall(abi.encodeWithSignature("assets(address)", x.usdt));
        assertTrue(ok);
        (address o, uint8 dec, bool enabled) = abi.decode(ret, (address, uint8, bool));
        assertEq(o, x.usdtOracle, "listed with its own oracle");
        assertEq(dec, 6, "decimals read from the token");
        assertTrue(enabled);
    }

    function _publish(SignedPriceOracle fx, uint256 cents) private {
        uint64 at = uint64(block.timestamp);
        uint64 seq = fx.sequence() + 1;
        bytes32 d = fx.digest(cents, at, seq);
        (uint256 lo, uint256 hi) = vm.addr(p1) < vm.addr(p2) ? (p1, p2) : (p2, p1);
        bytes[] memory sigs = new bytes[](2);
        (uint8 v, bytes32 r, bytes32 sg) = vm.sign(lo, d);
        sigs[0] = abi.encodePacked(r, sg, v);
        (v, r, sg) = vm.sign(hi, d);
        sigs[1] = abi.encodePacked(r, sg, v);
        fx.submit(cents, at, seq, sigs);
    }

    /**
     * 3. A feed the band could not use is refused before anything is listed: here, one already
     *    older than the max age chosen for it. (A contract-gated feed, like mainnet's BRL/USD in
     *    OracleFork.t.sol, fails the same read.)
     */
    function _aFeedThatCannotServeTheBandIsRefusedAtDeploy() private {
        vm.warp(block.timestamp + 2 days);
        // ETH's feed fresh, so that the refusal is the USDT feed's.
        vm.setEnv("CHAINLINK_ETH_USD", vm.toString(address(new FxTestFeed(248_368_328_680, 8))));
        FxTestFeed stale = new FxTestFeed(1e8, 8);
        stale.set(1e8, block.timestamp - 90_001);
        vm.setEnv("USD_FEEDS", vm.toString(address(stale)));
        DeployRamp script = new DeployRamp();
        try script.run() {
            revert("deployed an asset whose feed is older than its max age");
        } catch (bytes memory reason) {
            assertEq(
                reason,
                abi.encodeWithSignature("Error(string)", "USD_FEEDS: feed is older than its max age"),
                "refused for the right reason"
            );
        }
        // The reverted script left its broadcast open; close it so the next scenario can run.
        vm.stopBroadcast();
        vm.setEnv("ORACLE_KIND", "signed");
        vm.setEnv("USD_FEED_ASSETS", "");
    }

    /*//////////////////////////////////////////////////////////////
                                  MOVVA
    //////////////////////////////////////////////////////////////*/

    /// The Movva pair's zkTLS verifier, in storage: the scenario that reads it is at the stack limit.
    address internal movvaZkTls;

    struct MovvaSetup {
        MovvaReserve reserve;
        Movva movva;
        TetherLike usdt;
        FxTestFeed feed;
        SignedPriceOracle fx;
    }

    /// A reserve as DeployMovva leaves it, with the Phase A LP as a gateway; each part optionally wrong.
    function _movvaReserve(uint256 reserveDelay, bool closeReserve, bool closeFx) private returns (MovvaSetup memory m) {
        m.usdt = new TetherLike();
        m.feed = new FxTestFeed(1e8, 8);
        address[] memory pubs = new address[](2);
        (pubs[0], pubs[1]) = (vm.addr(p1), vm.addr(p2));
        m.fx = new SignedPriceOracle(address(this), 48 hours, pubs, 2);
        if (closeFx) m.fx.completeSetup();
        m.reserve = new MovvaReserve(
            MovvaReserve.Config({
                usdt: address(m.usdt),
                usdtUsdFeed: address(m.feed),
                fxOracle: address(m.fx),
                usdtUsdMaxAge: 25 hours,
                fxMaxAge: 1 hours,
                governor: address(this),
                governanceDelay: reserveDelay,
                guardian: makeAddr("movva guardian"),
                treasurer: makeAddr("movva treasurer"),
                hedgeTreasury: makeAddr("movva hedge treasury"),
                feeRecipient: makeAddr("movva fee recipient"),
                supplyCap: 1_000_000e18,
                breaker: address(0),
                hedgeQueueDelay: 1 days
            })
        );
        m.movva = Movva(m.reserve.MOVVA());
        m.reserve.setGateway(lp, true);
        if (closeReserve) m.reserve.completeSetup();
    }

    function _refuses(string memory why) private {
        DeployRamp script = new DeployRamp();
        try script.run() {
            revert(string.concat("deployed despite: ", why));
        } catch (bytes memory reason) {
            assertEq(reason, abi.encodeWithSignature("Error(string)", why), why);
        }
    }

    function _asset(address escrow, address token) private view returns (address oracle, uint8 dec, bool enabled) {
        (bool ok, bytes memory ret) = escrow.staticcall(abi.encodeWithSignature("assets(address)", token));
        assertTrue(ok);
        (oracle, dec, enabled) = abi.decode(ret, (address, uint8, bool));
    }

    /// The NodeRewards the Movva scenario deploys with, in storage for the same reason as `movvaZkTls`.
    NodeRewards internal movvaRewards;

    function _nodeRewardsRefusedUnlessSafe(MovvaSetup memory m) private {
        vm.setEnv("NODE_REWARDS", vm.toString(makeAddr("no rewards here")));
        _refuses("NODE_REWARDS: no contract at that address on this chain");
        movvaRewards = new NodeRewards(address(m.movva), 1e16, 7 days, 3 days, address(this), 48 hours);
        vm.setEnv("NODE_REWARDS", vm.toString(address(movvaRewards)));
        _refuses("NODE_REWARDS: setup still open, or its governance is not delayed: its limits could change at once");
        NodeRewards quick = new NodeRewards(address(m.movva), 1e16, 7 days, 3 days, address(this), 24 hours);
        quick.completeSetup();
        vm.setEnv("NODE_REWARDS", vm.toString(address(quick)));
        _refuses("NODE_REWARDS: governance delay shorter than GOVERNANCE_DELAY");
        NodeRewards inUsdt = new NodeRewards(address(m.usdt), 1e4, 7 days, 3 days, address(this), 48 hours);
        inUsdt.completeSetup();
        vm.setEnv("NODE_REWARDS", vm.toString(address(inUsdt)));
        _refuses("NODE_REWARDS: does not pay MOVVA_TOKEN");
        movvaRewards.completeSetup();
        vm.setEnv("NODE_REWARDS", vm.toString(address(movvaRewards)));
    }

    function _theRegistryReportsToNodeRewards(address registry, address someContract) private {
        assertEq(LPRegistry(registry).rewardsHook(), address(movvaRewards), "settlements on both pairs report to NodeRewards");
        // Its governor binds the new registry: immediate, because NodeRewards has never held anything.
        movvaRewards.setRegistry(registry);
        assertEq(movvaRewards.registry(), registry);
        // The registry's hook itself is now as slow to change as everything else on the ramp.
        vm.prank(governor);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, LPRegistry.setRewardsHook.selector));
        LPRegistry(registry).setRewardsHook(someContract);
        vm.setEnv("NODE_REWARDS", "");
    }

    function _useMovva(MovvaSetup memory m, address entrypoint) private {
        vm.setEnv("MOVVA_RESERVE", vm.toString(address(m.reserve)));
        vm.setEnv("MOVVA_TOKEN", vm.toString(address(m.movva)));
        vm.setEnv("MOVVA_PP_ENTRYPOINT", vm.toString(entrypoint));
    }

    /**
     * 4. Movva on its own pair (docs/movva.md, "Contracts"): the reserve as the band, a band tight
     *    enough to be a peg, what the script refuses first - and a real FiatEscrow from the script
     *    refusing a Movva offer outside the band once the reserve is under-backed.
     */
    function _movvaGetsItsOwnTightPair() private {
        PoolStub entrypoint = new PoolStub();
        MovvaSetup memory m = _movvaReserve(48 hours, true, true);

        // Not the reserve DeployMovva reported: the token disagrees, or the reserve is an impostor.
        _useMovva(m, address(entrypoint));
        vm.setEnv("MOVVA_TOKEN", vm.toString(makeAddr("a pasted address")));
        _refuses("MOVVA_RESERVE: its token is not MOVVA_TOKEN - not the reserve DeployMovva reported");
        ImpostorReserve impostor = new ImpostorReserve(address(m.movva));
        _useMovva(m, address(entrypoint));
        vm.setEnv("MOVVA_RESERVE", vm.toString(address(impostor)));
        _refuses("MOVVA_TOKEN: its minter is not MOVVA_RESERVE - not the token DeployMovva reported");

        // Bound correctly, to a token with the wrong decimals.
        ReserveOfASixDecimalToken six = new ReserveOfASixDecimalToken();
        vm.setEnv("MOVVA_RESERVE", vm.toString(address(six)));
        vm.setEnv("MOVVA_TOKEN", vm.toString(six.MOVVA()));
        _refuses("MOVVA_TOKEN: decimals are not 18, and a listing's decimals can never be corrected");

        // A band whose governance still acts instantly, or on shorter notice than the escrows'.
        _useMovva(_movvaReserve(48 hours, false, true), address(entrypoint));
        _refuses("MOVVA_RESERVE: setup still open, its governor can change the band at once");
        _useMovva(_movvaReserve(24 hours, true, true), address(entrypoint));
        _refuses(
            "MOVVA_RESERVE: governance delay shorter than GOVERNANCE_DELAY, so the band could change on less notice than the escrows give"
        );
        _useMovva(_movvaReserve(48 hours, true, false), address(entrypoint));
        _refuses(
            "MOVVA_RESERVE: its FX leg's setup is open or its governance is not delayed, so who signs the band's rate could change at once"
        );

        // A band too tight to hold a centavo, or not tighter than the main pair's; an entrypoint with no pool.
        _useMovva(m, address(entrypoint));
        vm.setEnv("MOVVA_BAND_BPS", "99");
        _refuses("MOVVA_BAND_BPS: below 100, a centavo band around R$ 1,00 admits only the mid itself");
        vm.setEnv("MOVVA_BAND_BPS", "500");
        _refuses("MOVVA_BAND_BPS: not tighter than BAND_BPS, so there is no reason for a separate pair");
        vm.setEnv("MOVVA_BAND_BPS", "");
        vm.setEnv("MOVVA_PP_ENTRYPOINT", vm.toString(address(new EntrypointWithoutPools())));
        _refuses("MOVVA_PP_ENTRYPOINT: no Movva pool registered there, and the escrow's entrypoint is immutable");

        // Node-provider rewards: a NodeRewards that is not closed, as slow to change as the ramp, and paid in Movva is refused.
        _useMovva(m, address(entrypoint));
        _nodeRewardsRefusedUnlessSafe(m);

        // Configured: the pair is deployed, wired, closed and handed over.
        _useMovva(m, address(entrypoint));
        vm.recordLogs();
        new DeployRamp().run();
        Vm.Log[] memory logs = vm.getRecordedLogs();
        address[2] memory pair;
        uint256 listed;
        address registry;
        for (uint256 i; i < logs.length; ++i) {
            bytes32 t = logs[i].topics[0];
            if (t == FiatEscrow.AssetSet.selector && logs[i].topics[1] == bytes32(uint256(uint160(address(m.movva))))) {
                pair[listed++] = logs[i].emitter;
            }
            // PIX offers and sales name the zkTLS verifier: the only verifier there is.
            if (t == ReclaimZkTlsVerifier.EndpointAllowed.selector) movvaZkTls = logs[i].emitter;
            if (t == LPRegistry.EscrowSet.selector) registry = logs[i].emitter;
        }
        assertEq(listed, 2, "Movva listed on exactly two escrows: its own pair, not the main one");
        for (uint256 i; i < 2; ++i) {
            FiatEscrow esc = FiatEscrow(payable(pair[i])); // the getters below share selectors on both escrows
            (address oracle, uint8 dec, bool enabled) = _asset(pair[i], address(m.movva));
            assertEq(oracle, address(m.reserve), "the reserve is Movva's band");
            assertEq(dec, 18);
            assertTrue(enabled);
            (,, enabled) = _asset(pair[i], address(0));
            assertFalse(enabled, "native ETH delisted on the Movva pair");
            assertEq(address(esc.ORACLE()), address(m.reserve), "constructed with the reserve: no ETH band oracle behind the pair");
            assertEq(esc.BAND_BPS(), 300, "Movva's own band, tighter than the main pair's");
            assertEq(esc.governor(), governor);
            assertTrue(esc.setupComplete());
            assertTrue(LPRegistry(registry).isEscrow(pair[i]), "one registry: one credit limit across both pairs");
            assertTrue(esc.allowedVerifier(movvaZkTls));
            assertGt(esc.arbitratorSince(arbitrator), 0);
            assertEq(esc.assetCap(address(m.movva)), 0, "no cap: Movva has no issuer freeze (see _wireMovva)");
        }
        _theRegistryReportsToNodeRewards(registry, address(m.reserve));
        FiatEscrow onramp = FiatEscrow(payable(pair[0]));
        assertEq(onramp.POOL_ENTRYPOINT(), address(entrypoint));
        assertEq(onramp.POOL(), address(entrypoint), "the pool the entrypoint registered for Movva");

        // A gateway mints 5.400 Movva for 1.000 USDT at R$ 5,40, and offers it on the Movva on-ramp.
        m.feed.set(1e8, block.timestamp);
        _publish(m.fx, 5_400_000);
        m.usdt.mint(lp, 1_000e6);
        uint16 pix = uint16(1 << uint8(IAttestorVerifier.Rail.PIX));
        vm.startPrank(lp);
        m.usdt.approve(address(m.reserve), type(uint256).max);
        assertEq(m.reserve.mint(1_000e6, lp, 0), 5_400e18);
        m.movva.approve(address(onramp), type(uint256).max);
        (uint256 mid,) = m.reserve.brlCentsPerUnit();
        assertEq(mid, 100, "fully backed: par");
        onramp.postOffer(address(m.movva), 1_000e18, 100, keccak256("lp@pix"), 1e18, 1_000e18, movvaZkTls, pix);
        onramp.postOffer(address(m.movva), 1_000e18, 103, keccak256("lp@pix"), 1e18, 1_000e18, movvaZkTls, pix);
        vm.expectRevert(FiatEscrow.PriceOutsideBand.selector);
        onramp.postOffer(address(m.movva), 1_000e18, 104, keccak256("lp@pix"), 1e18, 1_000e18, movvaZkTls, pix);
        vm.stopPrank();

        // Under-backed: R$ 4,86 per dollar values the 1.000 USDT at R$ 4.860 against 5.400 Movva, 90%.
        _publish(m.fx, 4_860_000);
        (mid,) = m.reserve.brlCentsPerUnit();
        assertEq(mid, 90);
        vm.startPrank(lp);
        vm.expectRevert(FiatEscrow.PriceOutsideBand.selector);
        onramp.postOffer(address(m.movva), 1_000e18, 100, keccak256("lp@pix"), 1e18, 1_000e18, movvaZkTls, pix);
        vm.expectRevert(FiatEscrow.PriceOutsideBand.selector);
        onramp.postOffer(address(m.movva), 1_000e18, 93, keccak256("lp@pix"), 1e18, 1_000e18, movvaZkTls, pix);
        onramp.postOffer(address(m.movva), 1_000e18, 88, keccak256("lp@pix"), 1e18, 1_000e18, movvaZkTls, pix);
        vm.stopPrank();

        // Why the band is 300 and not 100: at 98.56% backing the mid rounds UP to 99 while a redemption
        // pays 98.56 centavos. A 100 bps band would admit only 99, above what redeeming pays, and no LP
        // would ever buy a holder's Movva back. At 300 an LP can buy at 97, under the redemption value;
        // one centavo further is refused.
        _publish(m.fx, 5_322_240); // 1.000 USDT x R$ 5,32224 = R$ 5.322,24 against 5.400 Movva: 98.56%
        (mid,) = m.reserve.brlCentsPerUnit();
        assertEq(mid, 99, "98.56% rounds to the nearest centavo, up");
        OffRampEscrow offramp = OffRampEscrow(payable(pair[1]));
        vm.startPrank(lp);
        m.movva.approve(address(offramp), type(uint256).max);
        offramp.openSale(address(m.movva), 100e18, 9_700, keccak256("seller@pix"), movvaZkTls, pix, lp);
        vm.expectRevert(OffRampEscrow.PriceOutsideBand.selector);
        offramp.openSale(address(m.movva), 100e18, 9_600, keccak256("seller@pix"), movvaZkTls, pix, lp);
        vm.stopPrank();

        vm.setEnv("MOVVA_RESERVE", "");
        vm.setEnv("MOVVA_TOKEN", "");
        vm.setEnv("MOVVA_PP_ENTRYPOINT", "");
    }

    /**
     * 5. MAIN_PAIR=off (client decision, 14 October 2026): the Movva pair alone. No band oracle, no FX leg, no
     *    ETH/USDT escrows; the pair's constructor oracle is the reserve, and native ETH is delisted.
     */
    function _movvaOnlyWithMainPairOff() private {
        PoolStub entrypoint = new PoolStub();
        MovvaSetup memory m = _movvaReserve(48 hours, true, true);
        vm.setEnv("MAIN_PAIR", "off");
        _refuses("MAIN_PAIR=off: set MOVVA_RESERVE, or there is no pair to deploy");
        _useMovva(m, address(entrypoint));
        vm.setEnv("ORACLE_KIND", "signed");
        _refuses("MAIN_PAIR=off: ORACLE_KIND configures the main pair's band oracle, which is not deployed; unset it");
        vm.setEnv("ORACLE_KIND", "");
        vm.setEnv("USD_FEED_ASSETS", vm.toString(address(m.usdt)));
        _refuses("MAIN_PAIR=off: USD_FEED_ASSETS / ASSETS list assets on the main pair, which is not deployed; unset them");
        vm.setEnv("USD_FEED_ASSETS", "");
        // With no main pair there is no BAND_BPS for the Movva band to be tighter than.
        vm.setEnv("MOVVA_BAND_BPS", "500");

        vm.recordLogs();
        new DeployRamp().run();
        Vm.Log[] memory logs = vm.getRecordedLogs();
        uint256 closed;
        uint256 listed;
        address[2] memory pair;
        address registry;
        for (uint256 i; i < logs.length; ++i) {
            bytes32 t = logs[i].topics[0];
            if (t == DelayedGovernance.SetupCompleted.selector) ++closed;
            if (t == FiatEscrow.AssetSet.selector && logs[i].topics[1] == bytes32(uint256(uint160(address(m.movva))))) {
                pair[listed++] = logs[i].emitter;
            }
            if (t == LPRegistry.EscrowSet.selector) registry = logs[i].emitter;
            assertTrue(t != SignedPriceOracle.PublisherSet.selector, "no signed oracle deployed");
        }
        assertEq(closed, 4, "only the registry, the zkTLS verifier and the Movva pair were deployed");
        assertEq(listed, 2);
        for (uint256 i; i < 2; ++i) {
            FiatEscrow esc = FiatEscrow(payable(pair[i]));
            assertEq(address(esc.ORACLE()), address(m.reserve), "the reserve, not an ETH band oracle");
            (,, bool enabled) = _asset(pair[i], address(0));
            assertFalse(enabled, "native ETH delisted");
            (address oracle,, bool on) = _asset(pair[i], address(m.movva));
            assertEq(oracle, address(m.reserve));
            assertTrue(on);
            assertEq(esc.BAND_BPS(), 500);
            assertEq(esc.governor(), governor);
            assertTrue(esc.setupComplete());
            assertTrue(LPRegistry(registry).isEscrow(pair[i]));
        }
        assertEq(FiatEscrow(payable(pair[0])).POOL_ENTRYPOINT(), address(entrypoint));

        vm.setEnv("MAIN_PAIR", "");
        vm.setEnv("MOVVA_BAND_BPS", "");
        vm.setEnv("ORACLE_KIND", "signed");
        vm.setEnv("MOVVA_RESERVE", "");
        vm.setEnv("MOVVA_TOKEN", "");
        vm.setEnv("MOVVA_PP_ENTRYPOINT", "");
    }
}
