// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Governed} from "./Governed.sol";
import {ReclaimZkTlsVerifier} from "../../ramp/ReclaimZkTlsVerifier.sol";

/**
 * Builds proofs in the shape the Reclaim network actually emits, for the verifier tests.
 *
 * The shapes follow attestor-core rather than our own reader: `parameters` and `context` are
 * canonical JSON (sorted keys, no whitespace); the witness writes `providerHash` and
 * `extractedParameters` into the context; the order binding is the prover's
 * `contextMessage`; witnesses personal-sign the serialised claim string itself. A fixture
 * written to match the reader would only prove the reader agrees with itself.
 */
abstract contract ReclaimProofBuilder is Governed {
    /// The bank endpoint the tests allowlist.
    string internal constant BANK_PREFIX = "https://api.bank.example/pix/v2/";
    string internal constant BANK_URL = "https://api.bank.example/pix/v2/{{e2eId}}";

    /// Stands in for hashProviderParams(template). The verifier never recomputes it - the
    /// witness writes it - so any fixed value exercises the same code path.
    bytes32 internal constant BANK_TEMPLATE = keccak256("template: api.bank.example pix receipt");

    struct Fields {
        bytes32 orderId;
        bytes32 bankTxId;
        bytes32 payeeKeyHash;
        bytes32 payerRef;
        uint256 amountBrlCents;
        uint256 paidAt;
        uint8 rail;
    }

    /// Canonical HTTP provider parameters around a given url.
    function _params(string memory url) internal pure returns (string memory) {
        return string(
            abi.encodePacked(
                '{"body":"","method":"GET","paramValues":{"e2eId":"E0000000020260913"},',
                '"responseMatches":[{"type":"regex","value":"\\"endToEndId\\":\\"(?<bankTxId>0x[0-9a-f]{64})\\""}],',
                '"responseRedactions":[{"jsonPath":"$.pix","regex":"","xPath":""}],',
                '"url":"', url, '"}'
            )
        );
    }

    /// The extracted-parameters object, keys sorted as the witness's canonicaliser sorts them.
    function _extracted(Fields memory f) internal pure returns (string memory) {
        string memory head = string(
            abi.encodePacked(
                '{"amountBrlCents":"', vm.toString(f.amountBrlCents), '",',
                '"bankTxId":"', _hex32(f.bankTxId), '",',
                '"paidAt":"', vm.toString(f.paidAt), '",'
            )
        );
        return string(
            abi.encodePacked(
                head,
                '"payeeKeyHash":"', _hex32(f.payeeKeyHash), '",',
                '"payerRef":"', _hex32(f.payerRef), '",',
                '"rail":"', vm.toString(uint256(f.rail)), '"}'
            )
        );
    }

    /// A context as the witness leaves it: the prover's binding plus what the witness wrote.
    function _context(Fields memory f, bytes32 providerHash) internal pure returns (string memory) {
        return string(
            abi.encodePacked(
                '{"contextAddress":"0x0000000000000000000000000000000000000000",',
                '"contextMessage":"', _hex32(f.orderId), '",',
                '"extractedParameters":', _extracted(f), ',',
                '"providerHash":"', _hex32(providerHash), '"}'
            )
        );
    }

    function _proof(string memory params, string memory ctx, uint256[] memory keys)
        internal
        pure
        returns (ReclaimZkTlsVerifier.Proof memory p)
    {
        p.claimInfo = ReclaimZkTlsVerifier.ClaimInfo("http", params, ctx);
        p.signedClaim.claim = ReclaimZkTlsVerifier.CompleteClaimData({
            identifier: keccak256(abi.encodePacked("http", "\n", params, "\n", ctx)),
            owner: address(0xBEEF),
            timestampS: 1_700_000_000,
            epoch: 1
        });
        p.signedClaim.signatures = _sign(p.signedClaim.claim, keys);
    }

    /// Sign as a Reclaim witness: EIP-191 over the serialised claim string, sorted by signer.
    function _sign(ReclaimZkTlsVerifier.CompleteClaimData memory c, uint256[] memory keys)
        internal
        pure
        returns (bytes[] memory sigs)
    {
        bytes memory ser = abi.encodePacked(
            _hex32(c.identifier), "\n", _hexAddr(c.owner), "\n", vm.toString(uint256(c.timestampS)),
            "\n", vm.toString(uint256(c.epoch))
        );
        bytes32 digest = keccak256(
            abi.encodePacked("\x19Ethereum Signed Message:\n", vm.toString(ser.length), ser)
        );
        uint256[] memory k = new uint256[](keys.length);
        for (uint256 i; i < keys.length; ++i) {
            k[i] = keys[i];
        }
        for (uint256 i; i < k.length; ++i) {
            for (uint256 j = i + 1; j < k.length; ++j) {
                if (vm.addr(k[j]) < vm.addr(k[i])) (k[i], k[j]) = (k[j], k[i]);
            }
        }
        sigs = new bytes[](k.length);
        for (uint256 i; i < k.length; ++i) {
            (uint8 sv, bytes32 r, bytes32 s) = vm.sign(k[i], digest);
            sigs[i] = abi.encodePacked(r, s, sv);
        }
    }

    function _one(bytes32 providerHash) internal pure returns (bytes32[] memory h) {
        h = new bytes32[](1);
        h[0] = providerHash;
    }

    function _oneString(string memory s) internal pure returns (string[] memory out) {
        out = new string[](1);
        out[0] = s;
    }

    bytes16 private constant HEX = "0123456789abcdef";

    function _hex32(bytes32 val) internal pure returns (string memory) {
        bytes memory out = new bytes(66);
        out[0] = "0";
        out[1] = "x";
        for (uint256 i; i < 32; ++i) {
            out[2 + i * 2] = HEX[uint8(val[i]) >> 4];
            out[3 + i * 2] = HEX[uint8(val[i]) & 0x0f];
        }
        return string(out);
    }

    function _hexAddr(address a) internal pure returns (string memory) {
        bytes20 b = bytes20(a);
        bytes memory out = new bytes(42);
        out[0] = "0";
        out[1] = "x";
        for (uint256 i; i < 20; ++i) {
            out[2 + i * 2] = HEX[uint8(b[i]) >> 4];
            out[3 + i * 2] = HEX[uint8(b[i]) & 0x0f];
        }
        return string(out);
    }
}
