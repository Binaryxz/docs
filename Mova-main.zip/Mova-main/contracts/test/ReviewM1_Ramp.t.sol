// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";
import {FiatEscrow} from "../ramp/FiatEscrow.sol";
import {OffRampEscrow} from "../ramp/OffRampEscrow.sol";
import {LPRegistry} from "../ramp/LPRegistry.sol";
import {IAttestorVerifier} from "../ramp/IAttestorVerifier.sol";
import {IPriceOracle} from "../ramp/IPriceOracle.sol";
import {RulingLib} from "../ramp/RulingLib.sol";
import {MockVerifier, MockEntrypoint} from "./FiatEscrow.t.sol";

/// 18-decimal plain ERC-20 standing in for Movva (no hooks, no freeze, no fee).
contract M1Token {
    uint8 public constant decimals = 18;
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    function mint(address to, uint256 v) external {
        balanceOf[to] += v;
    }

    function approve(address s, uint256 v) external returns (bool) {
        allowance[msg.sender][s] = v;
        return true;
    }

    function transfer(address to, uint256 v) external returns (bool) {
        balanceOf[msg.sender] -= v;
        balanceOf[to] += v;
        return true;
    }

    function transferFrom(address f, address t, uint256 v) external returns (bool) {
        if (f != msg.sender) allowance[f][msg.sender] -= v;
        balanceOf[f] -= v;
        balanceOf[t] += v;
        return true;
    }
}

/// Stands in for MovvaReserve.brlCentsPerUnit at full backing: R$ 1,00 = 100 centavos, fresh.
contract M1Reserve is IPriceOracle {
    function brlCentsPerUnit() external view returns (uint256, uint64) {
        return (100, uint64(block.timestamp));
    }
}

/**
 * M1 security review (ramp component) - demonstrations against the MOVVA-only rail's shape:
 * a Movva FiatEscrow / OffRampEscrow pair built with the reserve as `oracle`, native ETH
 * delisted, Movva listed at 18 decimals, ONE arbitrator, ONE institutional LP, and every
 * governor renounced to 0x...dEaD (what `deploy-movva-rail.ts --finalize` leaves).
 *
 * Each `test_M1_*` test PASSES on the current code and in doing so demonstrates the behaviour
 * described in its comment. The `test_M1_Fixed_*` tests are the exception: they began as the
 * demonstrations of SRM1-12 and SRM1-13 and now pin the fixes, asserting the opposite.
 */
contract ReviewM1RampTest is Test {
    address constant BURN = 0x000000000000000000000000000000000000dEaD;
    uint256 constant DELAY = 48 hours;
    uint256 constant TIMEOUT = 30 days;
    uint256 constant ARB_KEY = 0xA2B;
    uint16 constant PIX_MASK = uint16(1 << uint8(IAttestorVerifier.Rail.PIX));

    FiatEscrow onramp;
    OffRampEscrow offramp;
    LPRegistry registry;
    MockVerifier verifier;
    MockEntrypoint entrypoint;
    M1Token movva;
    M1Reserve reserve;

    address gov = makeAddr("gov");
    address lp = makeAddr("lp"); // the rail's only institutional LP
    address taker = makeAddr("taker");
    address seller = makeAddr("seller");
    bytes32 constant LP_PIX = keccak256("lp pix commitment");
    bytes32 constant SELLER_PIX = keccak256("seller pix commitment");

    function setUp() public {
        vm.warp(1_800_000_000);
        movva = new M1Token();
        reserve = new M1Reserve();
        verifier = new MockVerifier();
        entrypoint = new MockEntrypoint();
        registry = new LPRegistry(gov, DELAY);
        onramp = new FiatEscrow(
            address(reserve), address(registry), address(entrypoint), address(entrypoint), 300, gov, DELAY, TIMEOUT
        );
        offramp = new OffRampEscrow(address(reserve), address(registry), 300, gov, DELAY, TIMEOUT);

        vm.startPrank(gov);
        // As DeployRamp._wireMovva, during setup.
        registry.setEscrow(address(onramp), true);
        registry.setEscrow(address(offramp), true);
        onramp.setAsset(address(0), address(reserve), 18, false);
        offramp.setAsset(address(0), address(reserve), 18, false);
        onramp.setAsset(address(movva), address(reserve), 18, true);
        offramp.setAsset(address(movva), address(reserve), 18, true);
        onramp.setVerifier(address(verifier), true);
        onramp.setArbitrator(vm.addr(ARB_KEY), true);
        offramp.setVerifier(address(verifier), true);
        offramp.setArbitrator(vm.addr(ARB_KEY), true);
        registry.setTier(lp, LPRegistry.Tier.INSTITUTIONAL, 5_000_000); // R$ 50.000,00
        registry.completeSetup();
        onramp.completeSetup();
        offramp.completeSetup();
        // --finalize
        registry.transferGovernor(BURN);
        onramp.transferGovernor(BURN);
        offramp.transferGovernor(BURN);
        vm.stopPrank();

        movva.mint(lp, 100_000 ether);
        movva.mint(seller, 100_000 ether);
        vm.prank(lp);
        movva.approve(address(onramp), type(uint256).max);
        vm.prank(seller);
        movva.approve(address(offramp), type(uint256).max);
    }

    /*//////////////////////////////////////////////////////////////
                                 HELPERS
    //////////////////////////////////////////////////////////////*/

    function _sign(address escrow, bytes32 id, string memory outcome)
        internal
        view
        returns (RulingLib.Ruling memory r, bytes memory sig)
    {
        r = RulingLib.Ruling({
            orderId: id,
            outcome: outcome,
            evidenceRoot: keccak256("evidence"),
            rationale: "review",
            ruledAt: uint64(block.timestamp),
            byDefault: false
        });
        bytes32 structHash = keccak256(
            abi.encode(
                keccak256(
                    "Ruling(bytes32 orderId,address escrow,string outcome,bytes32 evidenceRoot,string rationale,uint64 ruledAt,bool byDefault)"
                ),
                r.orderId, escrow, keccak256(bytes(r.outcome)), r.evidenceRoot, keccak256(bytes(r.rationale)),
                r.ruledAt, r.byDefault
            )
        );
        bytes32 domain = keccak256(
            abi.encode(
                keccak256("EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)"),
                keccak256("PrivacyPoolsBRL-Dispute"), keccak256("1"), block.chainid, escrow
            )
        );
        (uint8 v, bytes32 rr, bytes32 ss) = vm.sign(ARB_KEY, keccak256(abi.encodePacked("\x19\x01", domain, structHash)));
        sig = abi.encodePacked(rr, ss, v);
    }

    function _proof(bytes32 id, bytes32 bankTxId, bytes32 payee, uint256 cents) internal {
        verifier.setProof(
            id,
            MockVerifier.Canned({
                bankTxId: bankTxId,
                payeeKeyHash: payee,
                amountBrlCents: cents,
                paidAt: uint64(block.timestamp),
                rail: IAttestorVerifier.Rail.PIX,
                bound: true
            })
        );
    }

    function _postOffer(uint256 amount, uint256 maxOrder) internal returns (bytes32) {
        vm.prank(lp);
        return onramp.postOffer(address(movva), amount, 100, LP_PIX, 1 ether, maxOrder, address(verifier), PIX_MASK);
    }

    /*//////////////////////////////////////////////////////////////
          Q2 - A STOLEN ARBITRATOR KEY AFTER RENUNCIATION (documented)
    //////////////////////////////////////////////////////////////*/

    /**
     * FiatEscrow.sol:819-827 says revoking the arbitrator voids its posted rulings and is the
     * defence against a stolen key; deployments.md "What finalizing costs" says nobody can revoke
     * after --finalize. This performs it: the key holder needs no registry status to be a taker
     * (FiatEscrow._lock makes no registry call), locks the whole offer, disputes, posts RELEASE.
     * The LP sees RulingPosted a day early and can do nothing: closeOffer returns only free
     * liquidity (zero), and setArbitrator(.., false) reverts NotGovernor for everyone.
     */
    function test_M1_StolenArbitratorKeyTakesTheWholeOfferAndNobodyCanRevoke() public {
        bytes32 offerId = _postOffer(10_000 ether, 2_500 ether);
        address thief = makeAddr("thief");
        bytes32[4] memory ids;
        RulingLib.Ruling[4] memory rs;
        bytes[4] memory sigs;
        for (uint256 i; i < 4; ++i) {
            vm.startPrank(thief);
            ids[i] = onramp.lockOrder(offerId, 2_500 ether, FiatEscrow.Delivery.DIRECT, thief, 0);
            onramp.raiseDispute(ids[i], "paid");
            vm.stopPrank();
            (rs[i], sigs[i]) = _sign(address(onramp), ids[i], "RELEASE");
            onramp.resolveDispute(ids[i], rs[i], sigs[i]); // posted, public for RULING_DELAY
        }

        // The LP reacts within the day.
        uint256 before = movva.balanceOf(lp);
        vm.prank(lp);
        onramp.closeOffer(offerId);
        assertEq(movva.balanceOf(lp) - before, 0, "nothing free to withdraw: all of it is disputed");
        // Nobody holds the revocation lever any more.
        vm.prank(gov);
        vm.expectRevert(DelayedGovernance.NotGovernor.selector);
        onramp.setArbitrator(vm.addr(ARB_KEY), false);

        vm.warp(block.timestamp + 1 days);
        for (uint256 i; i < 4; ++i) {
            onramp.resolveDispute(ids[i], rs[i], sigs[i]); // the same ruling again: executes
        }
        assertEq(movva.balanceOf(thief), 10_000 ether, "the whole offer, no BRL paid");
    }

    /*//////////////////////////////////////////////////////////////
     Q1/Q2 - THE ESCROWER CAN PRE-EMPT A VALID PROOF WITH A DISPUTE (new)
    //////////////////////////////////////////////////////////////*/

    /**
     * On-ramp. The taker pays the PIX and holds a valid proof. The LP sees the BRL land in its
     * account and raises a dispute first (FiatEscrow.raiseDispute, :797-806: either party, any time
     * while LOCKED). From then on the proof is worthless: releaseWithProof requires LOCKED (:687).
     * Only a RELEASE ruling can pay the taker. With the rail's single arbitrator key lost or the
     * desk unresponsive - and after --finalize no new arbitrator can ever be added, and a newer one
     * could not RELEASE anyway (:911) - the timeout returns the Movva to the LP's offer. The LP keeps
     * the BRL AND the Movva. An INSTITUTIONAL LP's cap ignores lost disputes (LPRegistry.capOf,
     * :353-355), so it costs the LP nothing on-chain.
     */
    function test_M1_LPPreemptsATakersValidProofAndKeepsBothLegs() public {
        bytes32 offerId = _postOffer(1_000 ether, 1_000 ether);
        vm.prank(taker);
        bytes32 orderId = onramp.lockOrder(offerId, 500 ether, FiatEscrow.Delivery.DIRECT, taker, 0);
        // The taker paid R$ 500,00 to the LP's key; a good proof exists.
        _proof(orderId, keccak256("E2E-1"), LP_PIX, 50_000);

        vm.prank(lp);
        onramp.raiseDispute(orderId, "not received");

        vm.expectRevert(FiatEscrow.WrongState.selector);
        onramp.releaseWithProof(orderId, "");

        // No ruling arrives (the one arbitrator key is lost; nobody can add another).
        vm.warp(block.timestamp + TIMEOUT);
        onramp.expireDispute(orderId);
        uint256 capBefore = registry.capOf(lp);
        vm.prank(lp);
        onramp.closeOffer(offerId);

        assertEq(movva.balanceOf(taker), 0, "the taker paid R$ 500,00 and received nothing");
        assertEq(movva.balanceOf(lp), 100_000 ether, "the LP has all its Movva back, and the BRL");
        (,,, uint32 lost,,,) = registry.lps(lp);
        assertEq(lost, 1, "a lost dispute is recorded...");
        assertEq(registry.capOf(lp), capBefore, "...and changes nothing for an INSTITUTIONAL LP");
    }

    /**
     * Off-ramp, the mirror. The LP claims, pays the seller's PIX, and is about to settle. The
     * seller (a fresh address, no registry standing to lose) disputes first - from the bank
     * notification, or by front-running settleWithProof in the mempool. settleWithProof requires
     * CLAIMED (OffRampEscrow.sol:411); the timeout refunds the seller (:566-576) and, since the
     * seller raised it, records nothing against anyone. The seller keeps the BRL and gets its
     * Movva back.
     */
    function test_M1_SellerPreemptsTheLPsValidProofAndKeepsBothLegs() public {
        vm.prank(seller);
        bytes32 saleId = offramp.openSale(address(movva), 500 ether, 50_000, SELLER_PIX, address(verifier), PIX_MASK, seller);
        vm.prank(lp);
        offramp.claimSale(saleId);
        _proof(saleId, keccak256("E2E-2"), SELLER_PIX, 50_000); // the LP paid

        vm.prank(seller);
        offramp.raiseDispute(saleId, "not received");
        vm.expectRevert(OffRampEscrow.WrongState.selector);
        offramp.settleWithProof(saleId, "");

        vm.warp(block.timestamp + TIMEOUT);
        offramp.expireDispute(saleId);
        assertEq(movva.balanceOf(seller), 100_000 ether, "seller: Movva back, and the LP's R$ 500,00");
        assertEq(movva.balanceOf(lp), 100_000 ether, "LP: paid BRL, received nothing");
    }

    /**
     * A taker escrows nothing, needs no registry standing, and a taker's dispute costs it nothing
     * (SR2-18). Locking the whole book and disputing every order freezes it for DISPUTE_TIMEOUT
     * (30 days) instead of PAY_WINDOW (30 minutes) unless the desk signs a REFUND per order - and
     * after --finalize the one arbitrator key cannot be replaced. The offer's credit stays reserved
     * (closeOffer frees only available liquidity), and credit is one number across both escrows,
     * so the rail's only LP cannot claim ANY off-ramp sale meanwhile: holders' exits stall. At the
     * timeout the griefer can expire and re-lock in one transaction, ahead of an EOA LP's closeOffer.
     */
    function test_M1_AFreeTakerFreezesTheBookAndStallsEveryExit() public {
        bytes32 offerId = _postOffer(49_000 ether, 49_000 ether); // R$ 49.000 of the LP's R$ 50.000
        address griefer = makeAddr("griefer");
        vm.startPrank(griefer);
        bytes32 orderId = onramp.lockOrder(offerId, 49_000 ether, FiatEscrow.Delivery.DIRECT, griefer, 0);
        onramp.raiseDispute(orderId, "paid");
        vm.stopPrank();

        vm.prank(lp);
        onramp.closeOffer(offerId); // returns nothing; the exposure stays reserved

        vm.prank(seller);
        bytes32 saleId = offramp.openSale(address(movva), 2_000 ether, 200_000, SELLER_PIX, address(verifier), PIX_MASK, seller);
        vm.prank(lp);
        vm.expectRevert(OffRampEscrow.LPNotEligible.selector);
        offramp.claimSale(saleId); // R$ 2.000 > R$ 1.000 of headroom: the exit stalls

        // 30 days later the order expires back to the (closed) offer; the LP can now sweep it.
        vm.warp(block.timestamp + TIMEOUT);
        onramp.expireDispute(orderId);
        vm.prank(lp);
        onramp.closeOffer(offerId);
        vm.prank(lp);
        offramp.claimSale(saleId);
        // (Had the LP left the offer open, `lockOrder` would be refused only by `active`; an LP that
        // keeps quoting is re-frozen by the same griefer in the block the dispute expires.)
    }

    /*//////////////////////////////////////////////////////////////
     Q3 - RECEIPT REPLAY STATE IS SHARED BY BOTH ESCROWS (SRM1-12, fixed)
    //////////////////////////////////////////////////////////////*/

    /// An order and a sale that both name the LP's payee commitment, each ready to settle.
    function _orderAndSaleOnOnePayee() internal returns (bytes32 orderId, bytes32 saleId) {
        bytes32 offerId = _postOffer(1_000 ether, 1_000 ether);
        vm.prank(taker);
        orderId = onramp.lockOrder(offerId, 500 ether, FiatEscrow.Delivery.DIRECT, taker, 0);
        vm.prank(seller);
        saleId = offramp.openSale(address(movva), 500 ether, 50_000, LP_PIX, address(verifier), PIX_MASK, seller);
        vm.prank(lp);
        offramp.claimSale(saleId);
    }

    /**
     * Was `test_M1_OneBankTxIdSettlesAnOrderAndASale`. `usedBankTxId` was per escrow, so one PIX
     * settled an on-ramp order AND an off-ramp sale naming the same payee commitment (a commitment
     * is public: offers(id).pixKeyHash), given two zkTLS sessions of the same receipt bound to two
     * ids - which the payer or payee of that PIX can produce. The id is now spent in the registry
     * both escrows share: the second settlement is refused, and the sale stays CLAIMED.
     */
    function test_M1_Fixed_OneBankTxIdCannotSettleAnOrderAndASale() public {
        (bytes32 orderId, bytes32 saleId) = _orderAndSaleOnOnePayee();
        bytes32 tx_ = keccak256("E2E-ONE-PIX");
        _proof(orderId, tx_, LP_PIX, 50_000);
        _proof(saleId, tx_, LP_PIX, 50_000);

        onramp.releaseWithProof(orderId, "");
        vm.expectRevert(OffRampEscrow.ReceiptReplayed.selector);
        offramp.settleWithProof(saleId, "");

        assertTrue(registry.usedBankTxId(tx_), "spent in the registry");
        assertTrue(onramp.usedBankTxId(tx_) && offramp.usedBankTxId(tx_), "and both escrows say so");
        (,,,,,,,,,,, OffRampEscrow.SaleState st) = offramp.sales(saleId);
        assertEq(uint8(st), uint8(OffRampEscrow.SaleState.CLAIMED), "the sale did not settle");
        assertEq(movva.balanceOf(lp), 100_000 ether - 1_000 ether, "the LP was paid nothing off the sale");
    }

    /// The same, the other way round: a PIX that settled a sale cannot then settle an order.
    function test_M1_Fixed_ABankTxIdSpentOnASaleCannotSettleAnOrder() public {
        (bytes32 orderId, bytes32 saleId) = _orderAndSaleOnOnePayee();
        bytes32 tx_ = keccak256("E2E-ONE-PIX");
        _proof(orderId, tx_, LP_PIX, 50_000);
        _proof(saleId, tx_, LP_PIX, 50_000);

        offramp.settleWithProof(saleId, "");
        vm.expectRevert(FiatEscrow.ReceiptReplayed.selector);
        onramp.releaseWithProof(orderId, "");
        (,,,,,, FiatEscrow.OrderState st,,,,) = onramp.orders(orderId);
        assertEq(uint8(st), uint8(FiatEscrow.OrderState.LOCKED), "the order did not release");
        assertEq(movva.balanceOf(taker), 0);
    }

    /// Nobody but an escrow can spend an id: burning a victim's receipt ahead of its proof fails.
    function test_M1_Fixed_NobodyCanBurnABankTxIdAheadOfItsProof() public {
        (bytes32 orderId,) = _orderAndSaleOnOnePayee();
        bytes32 tx_ = keccak256("E2E-VICTIM");
        vm.prank(makeAddr("griefer"));
        vm.expectRevert(LPRegistry.NotEscrow.selector);
        registry.consumeBankTxId(tx_);
        _proof(orderId, tx_, LP_PIX, 50_000);
        onramp.releaseWithProof(orderId, "");
        assertEq(movva.balanceOf(taker), 500 ether, "the genuine proof still settles");
    }

    /**
     * Fuzzed: positions on both escrows, each presented with a bank transaction id drawn from a
     * pool of three. However the ids repeat and interleave, each id settles at most one position
     * across the two escrows, and every position that settled holds a distinct id.
     */
    function testFuzz_M1_Fixed_ABankTxIdSettlesOncePerRamp(uint256 seed) public {
        bytes32 offerId = _postOffer(10_000 ether, 1_000 ether);
        uint256[3] memory settledWith;
        for (uint256 i; i < 6; ++i) {
            uint256 r = uint256(keccak256(abi.encode(seed, i)));
            uint256 k = r % 3;
            bytes32 tx_ = keccak256(abi.encode("E2E", k));
            bool ok;
            if ((r >> 8) % 2 == 0) {
                vm.prank(taker);
                bytes32 orderId = onramp.lockOrder(offerId, 10 ether, FiatEscrow.Delivery.DIRECT, taker, 0);
                _proof(orderId, tx_, LP_PIX, 1_000);
                try onramp.releaseWithProof(orderId, "") {
                    ok = true;
                } catch (bytes memory err) {
                    assertEq(bytes4(err), FiatEscrow.ReceiptReplayed.selector);
                }
            } else {
                vm.prank(seller);
                bytes32 saleId =
                    offramp.openSale(address(movva), 10 ether, 1_000, LP_PIX, address(verifier), PIX_MASK, seller);
                vm.prank(lp);
                offramp.claimSale(saleId);
                _proof(saleId, tx_, LP_PIX, 1_000);
                try offramp.settleWithProof(saleId, "") {
                    ok = true;
                } catch (bytes memory err) {
                    assertEq(bytes4(err), OffRampEscrow.ReceiptReplayed.selector);
                }
            }
            if (ok) ++settledWith[k];
            assertLe(settledWith[k], 1, "one bank transaction, one settlement");
            assertEq(registry.usedBankTxId(tx_), true);
        }
    }

    /*//////////////////////////////////////////////////////////////
       Q1/Q6 - A STALE CLAIM CANNOT BE RENEWED TO BLOCK CANCEL (SRM1-13, fixed)
    //////////////////////////////////////////////////////////////*/

    /**
     * Was `test_M1_AnLPCanRenewAStaleClaimForeverAtNoCost`. releaseStaleClaim + claimSale (or
     * abandonClaim + claimSale) in one transaction renewed a claim before the seller could reach
     * cancelSale, which needed OPEN. Now a stale claim is cancellable by the seller directly, and
     * a claim that ends unsettled starts CLAIM_COOLDOWN, in which nobody may claim the sale.
     * Here the rail's only LP tries the loop the review described; every renewal in the block the
     * claim ends is refused, and the seller's cancel - ordered after the LP's release - lands.
     */
    function test_M1_Fixed_AnLPCannotRenewAStaleClaimToBlockCancel() public {
        vm.prank(seller);
        bytes32 saleId = offramp.openSale(address(movva), 500 ether, 50_000, SELLER_PIX, address(verifier), PIX_MASK, seller);
        for (uint256 i; i < 5; ++i) {
            vm.prank(lp);
            offramp.claimSale(saleId);
            vm.warp(block.timestamp + offramp.PAY_WINDOW() + 1);
            vm.startPrank(lp);
            offramp.releaseStaleClaim(saleId); // the same block as the attempted renewal
            vm.expectRevert(
                abi.encodeWithSelector(
                    OffRampEscrow.ClaimCoolingDown.selector, uint64(block.timestamp) + offramp.CLAIM_COOLDOWN()
                )
            );
            offramp.claimSale(saleId);
            vm.stopPrank();
            vm.warp(block.timestamp + offramp.CLAIM_COOLDOWN());
        }
        // The LP abandons a live claim a second before payBy and tries again: refused too.
        vm.prank(lp);
        offramp.claimSale(saleId);
        vm.warp(block.timestamp + offramp.PAY_WINDOW() - 1);
        vm.startPrank(lp);
        offramp.abandonClaim(saleId);
        vm.expectRevert(); // ClaimCoolingDown
        offramp.claimSale(saleId);
        vm.stopPrank();

        vm.prank(seller);
        offramp.cancelSale(saleId);
        assertEq(movva.balanceOf(seller), 100_000 ether, "the seller is out, with all its Movva");
        assertEq(registry.reservedBy(address(offramp), lp), 0, "and the LP's credit is free");
    }

    /// The seller need not wait for anyone to release a stale claim: it cancels the claim itself,
    /// so an LP that simply never releases cannot hold the sale either.
    function test_M1_Fixed_TheSellerCancelsAStaleClaimItself() public {
        vm.prank(seller);
        bytes32 saleId = offramp.openSale(address(movva), 500 ether, 50_000, SELLER_PIX, address(verifier), PIX_MASK, seller);
        vm.prank(lp);
        offramp.claimSale(saleId);
        vm.prank(seller);
        vm.expectRevert(OffRampEscrow.WrongState.selector);
        offramp.cancelSale(saleId); // a live claim still protects the LP
        vm.warp(block.timestamp + offramp.PAY_WINDOW() + 1);
        vm.prank(seller);
        offramp.cancelSale(saleId);
        assertEq(movva.balanceOf(seller), 100_000 ether);
        assertEq(registry.reservedBy(address(offramp), lp), 0);
    }

    /*//////////////////////////////////////////////////////////////
                 Q7 - NATIVE ETH ON THE MOVVA PAIR (held)
    //////////////////////////////////////////////////////////////*/

    /// Native ETH cannot become a position on either escrow, and nobody can re-list it. ETH sent to
    /// FiatEscrow.receive() is accepted and stranded (no function sends native ETH unless an ETH
    /// offer exists, and none can).
    function test_M1_NativeEthIsDelistedForGoodAndDonationsStrand() public {
        vm.deal(lp, 1 ether);
        vm.prank(lp);
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.AssetNotEnabled.selector, address(0)));
        onramp.postOffer{value: 1 ether}(address(0), 1 ether, 100, LP_PIX, 0.1 ether, 1 ether, address(verifier), PIX_MASK);
        vm.prank(lp);
        vm.expectRevert(abi.encodeWithSelector(OffRampEscrow.AssetNotEnabled.selector, address(0)));
        offramp.openSale{value: 1 ether}(address(0), 1 ether, 100, SELLER_PIX, address(verifier), PIX_MASK, lp);
        vm.prank(lp);
        (bool ok,) = address(onramp).call{value: 1 ether}("");
        assertTrue(ok, "receive() takes it");
        assertEq(address(onramp).balance, 1 ether, "and it stays there for good");
    }
}
