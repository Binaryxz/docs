// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import {console2} from "forge-std/console2.sol";
import {Governed} from "./utils/Governed.sol";
import {FiatEscrow} from "../ramp/FiatEscrow.sol";
import {OffRampEscrow} from "../ramp/OffRampEscrow.sol";
import {LPRegistry} from "../ramp/LPRegistry.sol";
import {IAttestorVerifier} from "../ramp/IAttestorVerifier.sol";
import {RulingLib} from "../ramp/RulingLib.sol";
import {MockVerifier, MockOracle} from "./FiatEscrow.t.sol";
import {MockVerifier2, MockOracle2} from "./OffRampEscrow.t.sol";
import {MockUSD, StableOracle} from "./RampErc20.t.sol";

/// The arbitration desk's key, signing rulings exactly as the unit tests (and the desk's client) do.
abstract contract RulingSigner is Test {
    uint256 internal constant ARB_KEY = 0xA2B;

    function _signRuling(address escrow_, bytes32 id, bool release, uint64 ruledAt)
        internal
        view
        returns (RulingLib.Ruling memory r, bytes memory sig)
    {
        r = RulingLib.Ruling({
            orderId: id,
            outcome: release ? "RELEASE" : "REFUND",
            evidenceRoot: keccak256("evidence"),
            rationale: "invariant run",
            ruledAt: ruledAt,
            byDefault: false
        });
        bytes32 structHash = keccak256(
            abi.encode(
                keccak256(
                    "Ruling(bytes32 orderId,address escrow,string outcome,bytes32 evidenceRoot,string rationale,uint64 ruledAt,bool byDefault)"
                ),
                r.orderId, escrow_, keccak256(bytes(r.outcome)), r.evidenceRoot,
                keccak256(bytes(r.rationale)), r.ruledAt, r.byDefault
            )
        );
        bytes32 domain = keccak256(
            abi.encode(
                keccak256("EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)"),
                keccak256("PrivacyPoolsBRL-Dispute"), keccak256("1"), block.chainid, escrow_
            )
        );
        (uint8 v, bytes32 rr, bytes32 ss) = vm.sign(ARB_KEY, keccak256(abi.encodePacked("\x19\x01", domain, structHash)));
        sig = abi.encodePacked(rr, ss, v);
    }

    /// Mostly minutes, so a claim or order can be paid inside its window; one warp in sixteen jumps
    /// hours to a day and a half, so windows and ruling delays lapse, and another one in sixteen a
    /// whole dispute timeout. (executeRuling and expireDispute also wait for their own moment.)
    function _warp(uint256 dt, uint256 disputeTimeout) internal {
        if (dt % 16 == 0) vm.warp(block.timestamp + disputeTimeout);
        else if (dt % 8 == 0) vm.warp(block.timestamp + bound(dt, 1 hours, 36 hours));
        else vm.warp(block.timestamp + bound(dt, 1 minutes, 10 minutes));
    }
}

/// The Entrypoint and its pool in one, for both deposit shapes the escrow uses (native ETH and
/// ERC-20). It keeps what it is sent and counts it, so a shielded delivery is paid to it and nowhere else.
contract ShieldedSink {
    uint256 public constant SCOPE = 7;
    uint256 public nonce;
    mapping(address => uint256) public received; // by asset; address(0) is ETH

    function deposit(uint256) external payable returns (uint256) {
        received[address(0)] += msg.value;
        return ++nonce;
    }

    function deposit(address asset, uint256 value, uint256) external returns (uint256) {
        MockUSD(asset).transferFrom(msg.sender, address(this), value);
        received[asset] += value;
        return ++nonce;
    }

    function assetConfig(address) external view returns (address, uint256, uint256, uint256) {
        return (address(this), 0, 0, 0);
    }
}

/*//////////////////////////////////////////////////////////////
                            ON-RAMP
//////////////////////////////////////////////////////////////*/

/**
 * Drives FiatEscrow the way a busy book would: two institutional LPs and one retail LP posting,
 * topping up and closing offers in ETH and a 6-decimal stablecoin; takers locking by PIX and by
 * boleto, for direct and shielded delivery, then paying (with good receipts and with replayed,
 * short, misaddressed and stale ones), cancelling, switching a shielded order to direct, letting
 * it expire, or disputing it; the desk posting and executing rulings either way; disputes timing
 * out; time passing. Every call may revert. Every call that succeeds is classified from the order's
 * state before and after it, and every payment the escrow should have made is booked to its payee.
 */
contract FiatEscrowHandler is RulingSigner {
    FiatEscrow public escrow;
    LPRegistry public registry;
    MockVerifier public verifier;
    MockUSD public usd;
    ShieldedSink public sink;

    uint256 internal constant ETH_PRICE = 3_000_000; // MockOracle's mid, centavos per ETH
    uint256 internal constant USD_PRICE = 550; // StableOracle's mid, centavos per whole token
    bytes32 internal constant PIX_KEY = keccak256("lp@pix.example");
    uint16 internal constant PIX_MASK = uint16(1 << uint8(IAttestorVerifier.Rail.PIX));
    uint16 internal constant BOLETO_MASK = uint16(1 << uint8(IAttestorVerifier.Rail.BOLETO));

    address[3] public lps; // lps[2] is RETAIL: its credit is small and moves with its record
    address[3] public takers;
    address[3] public recipients; // each taker's payout (DIRECT) and rescue owner (SHIELDED)
    address public stranger = makeAddr("stranger");

    bytes32[] internal offers;
    bytes32[] internal orders;
    mapping(bytes32 => uint256) public offerIndex; // order => index of its offer in `offers`
    mapping(bytes32 => uint256) public lpIndex; // offer => index of its LP in `lps`

    enum Outcome {
        OPEN,
        RELEASED,
        REFUNDED
    }

    mapping(bytes32 => Outcome) public outcome;
    mapping(bytes32 => uint256) public settlements;
    /// @notice A call that ended an already-ended order, or reopened one. Must stay zero.
    uint256 public secondSettlements;
    /// @notice A release on a replayed, short, misaddressed or pre-order receipt. Must stay zero.
    uint256 public badReceiptsAccepted;

    /// @notice What each address should have gained (+) or paid in (-) through the escrow, by asset.
    mapping(address => mapping(address => int256)) public expectedDelta;
    /// @notice What the escrow should hold, by asset: paid in, less paid out.
    mapping(address => uint256) public expectedHeld;

    struct Posted {
        bool set;
        bool release;
        uint64 ruledAt;
    }

    mapping(bytes32 => Posted) internal posted;
    uint256 internal bankTx;
    uint256 internal boletoNonce;
    bytes32 internal lastSettledTx;
    mapping(bytes32 => uint256) public calls;

    /// @dev Field for field the public getters' return values, so their return data decodes into
    ///      these directly (destructuring twelve values runs out of stack).
    struct OfferView {
        address lp;
        address asset;
        uint256 available;
        uint256 locked;
        uint256 price;
        bytes32 pixKey;
        uint256 minOrder;
        uint256 maxOrder;
        address verifier;
        uint16 railMask;
        bool active;
        uint8 decimals;
    }

    struct OrderView {
        bytes32 offerId;
        address taker;
        uint256 weiAmount;
        uint256 brlCents;
        uint64 lockedAt;
        uint64 payBy;
        FiatEscrow.OrderState state;
        FiatEscrow.Delivery delivery;
        address recipient;
        uint256 precommitment;
        uint256 commitment;
    }

    constructor(FiatEscrow escrow_, LPRegistry registry_, MockVerifier verifier_, MockUSD usd_, ShieldedSink sink_) {
        escrow = escrow_;
        registry = registry_;
        verifier = verifier_;
        usd = usd_;
        sink = sink_;
        for (uint256 i; i < 3; ++i) {
            lps[i] = makeAddr(string.concat("lp", vm.toString(i)));
            takers[i] = makeAddr(string.concat("taker", vm.toString(i)));
            recipients[i] = makeAddr(string.concat("recipient", vm.toString(i)));
        }
    }

    /*//////////////////////////////////////////////////////////////
                                LP SIDE
    //////////////////////////////////////////////////////////////*/

    function postOffer(uint256 lpSeed, bool token, uint256 amount, bool boletoToo) external {
        uint256 li = lpSeed % 3;
        address lp = lps[li];
        address asset = token ? address(usd) : address(0);
        bool retail = li == 2;
        uint256 minOrder;
        if (token) {
            amount = retail ? bound(amount, 10e6, 800e6) : bound(amount, 10e6, 1_000_000e6);
            minOrder = 1e6;
        } else {
            amount = retail ? bound(amount, 0.02 ether, 0.15 ether) : bound(amount, 0.05 ether, 50 ether);
            minOrder = 0.01 ether;
        }
        vm.prank(lp);
        try escrow.postOffer{value: token ? 0 : amount}(
            asset, amount, token ? USD_PRICE : ETH_PRICE, PIX_KEY, minOrder, amount, address(verifier),
            boletoToo ? PIX_MASK | BOLETO_MASK : PIX_MASK
        ) returns (bytes32 id) {
            offers.push(id);
            lpIndex[id] = li;
            _paidIn(lp, asset, amount);
            ++calls["postOffer"];
        } catch {}
    }

    function fundOffer(uint256 offerSeed, uint256 amount) external {
        if (offers.length == 0) return;
        bytes32 id = offers[offerSeed % offers.length];
        OfferView memory o = _offer(id);
        bool token = o.asset != address(0);
        bool retail = lpIndex[id] == 2;
        amount = token ? bound(amount, 1, retail ? 100e6 : 100_000e6) : bound(amount, 1, retail ? 0.02 ether : 5 ether);
        vm.prank(o.lp);
        try escrow.fundOffer{value: token ? 0 : amount}(id, amount) {
            _paidIn(o.lp, o.asset, amount);
            ++calls["fundOffer"];
        } catch {}
    }

    function closeOffer(uint256 offerSeed) external {
        if (offers.length == 0) return;
        bytes32 id = offers[offerSeed % offers.length];
        OfferView memory o = _offer(id);
        vm.prank(o.lp);
        try escrow.closeOffer(id) {
            _paidOut(o.lp, o.asset, o.available);
            ++calls["closeOffer"];
        } catch {}
    }

    function issueBoleto(uint256 orderSeed) external {
        if (orders.length == 0) return;
        bytes32 id = _pickOrder(orderSeed, Want.UNISSUED_BOLETO);
        OrderView memory ord = _order(id);
        address lp = _offer(ord.offerId).lp;
        vm.prank(lp);
        try escrow.issueBoleto(id, keccak256(abi.encode("boleto", ++boletoNonce))) {
            ++calls["issueBoleto"];
        } catch {}
    }

    /*//////////////////////////////////////////////////////////////
                              TAKER SIDE
    //////////////////////////////////////////////////////////////*/

    function lock(uint256 offerSeed, uint256 takerSeed, uint256 amount, bool shielded, bool boleto) external {
        if (offers.length == 0) return;
        uint256 oi = _pickOfferWithRoom(offerSeed);
        bytes32 offerId = offers[oi];
        OfferView memory o = _offer(offerId);
        uint256 hi = o.available < o.maxOrder ? o.available : o.maxOrder;
        if (hi < o.minOrder) return;
        amount = bound(amount, o.minOrder, hi);
        uint256 t = takerSeed % 3;
        FiatEscrow.Delivery d = shielded ? FiatEscrow.Delivery.SHIELDED : FiatEscrow.Delivery.DIRECT;
        uint256 pre = shielded ? uint256(keccak256(abi.encode("precommitment", orders.length))) : 0;
        vm.prank(takers[t]);
        bytes32 id;
        if (boleto) {
            try escrow.lockOrderByBoleto(offerId, amount, d, recipients[t], pre) returns (bytes32 r) {
                id = r;
            } catch {}
        } else {
            try escrow.lockOrder(offerId, amount, d, recipients[t], pre) returns (bytes32 r) {
                id = r;
            } catch {}
        }
        if (id == bytes32(0)) return;
        orders.push(id);
        offerIndex[id] = oi;
        ++calls[boleto ? bytes32("lockByBoleto") : bytes32("lock")];
    }

    /// Present a receipt. Variants 0-11 are good; 12 predates the order (or its boleto), 13 replays a
    /// receipt that already settled another order, 14 is a centavo short, 15 pays someone else.
    function release(uint256 orderSeed, uint256 variant) external {
        if (orders.length == 0) return;
        bytes32 id = _pickOrder(orderSeed, Want.PAYABLE);
        OrderView memory ord = _order(id);
        (uint64 issueBy, uint64 issuedAt, bytes32 commitment) = escrow.boletoOf(id);
        bool boleto = issueBy != 0;
        MockVerifier.Canned memory c = MockVerifier.Canned({
            bankTxId: keccak256(abi.encode("bank", ++bankTx)),
            payeeKeyHash: boleto ? commitment : _offer(ord.offerId).pixKey,
            amountBrlCents: ord.brlCents,
            paidAt: uint64(block.timestamp),
            rail: boleto ? IAttestorVerifier.Rail.BOLETO : IAttestorVerifier.Rail.PIX,
            bound: true
        });
        variant %= 16;
        bool bad = true;
        uint64 floor_ = boleto ? issuedAt : ord.lockedAt;
        if (variant == 12 && floor_ > 0) c.paidAt = floor_ - 1;
        else if (variant == 13 && lastSettledTx != bytes32(0)) c.bankTxId = lastSettledTx;
        else if (variant == 14) c.amountBrlCents = ord.brlCents - 1;
        else if (variant == 15) c.payeeKeyHash = keccak256("someone else's key");
        else bad = false;
        verifier.setProof(id, c);
        vm.prank(stranger); // anyone may submit; the payout is fixed by the order
        try escrow.releaseWithProof(id, "") {
            if (bad) ++badReceiptsAccepted;
            lastSettledTx = c.bankTxId;
            _observe(id, ord, true);
            ++calls["release"];
        } catch {}
    }

    function cancel(uint256 orderSeed) external {
        if (orders.length == 0) return;
        bytes32 id = _pickOrder(orderSeed, Want.LOCKED);
        OrderView memory ord = _order(id);
        vm.prank(ord.taker);
        try escrow.cancelOrder(id) {
            _observe(id, ord, true);
            ++calls["cancel"];
        } catch {}
    }

    function takeDeliveryDirect(uint256 orderSeed) external {
        if (orders.length == 0) return;
        bytes32 id = _pickOrder(orderSeed, Want.SHIELDED_OPEN);
        OrderView memory ord = _order(id);
        vm.prank(ord.recipient);
        try escrow.takeDeliveryDirect(id) {
            _observe(id, ord, false);
            ++calls["takeDeliveryDirect"];
        } catch {}
    }

    function reclaimExpired(uint256 orderSeed) external {
        if (orders.length == 0) return;
        bytes32 id = _pickOrder(orderSeed, Want.LAPSED);
        OrderView memory ord = _order(id);
        vm.prank(stranger);
        try escrow.reclaimExpired(id) {
            _observe(id, ord, true);
            ++calls["reclaimExpired"];
        } catch {}
    }

    /*//////////////////////////////////////////////////////////////
                               DISPUTES
    //////////////////////////////////////////////////////////////*/

    function raiseDispute(uint256 orderSeed, bool byLP) external {
        if (orders.length == 0) return;
        bytes32 id = _pickOrder(orderSeed, Want.LOCKED);
        OrderView memory ord = _order(id);
        vm.prank(byLP ? _offer(ord.offerId).lp : ord.taker);
        try escrow.raiseDispute(id, "invariant") {
            _observe(id, ord, false);
            ++calls["raiseDispute"];
        } catch {}
    }

    /// First sight of a signed ruling: it is posted, executable after RULING_DELAY.
    function postRuling(uint256 orderSeed, bool releaseToTaker) external {
        if (orders.length == 0) return;
        bytes32 id = _pickOrder(orderSeed, Want.DISPUTED);
        OrderView memory ord = _order(id);
        uint64 ruledAt = uint64(block.timestamp);
        (RulingLib.Ruling memory r, bytes memory sig) = _signRuling(address(escrow), id, releaseToTaker, ruledAt);
        vm.prank(stranger);
        try escrow.resolveDispute(id, r, sig) {
            if (_order(id).state == ord.state) posted[id] = Posted(true, releaseToTaker, ruledAt);
            _observe(id, ord, true);
            ++calls["postRuling"];
        } catch {}
    }

    /// The posted ruling again, by anyone. If its delay is not over, time passes to that moment first
    /// (never to or past the dispute's deadline), as it would for a party waiting to execute.
    function executeRuling(uint256 orderSeed) external {
        if (orders.length == 0) return;
        bytes32 id = _pickOrder(orderSeed, Want.POSTED);
        Posted memory p = posted[id];
        if (!p.set) return;
        uint256 ready = uint256(p.ruledAt) + 1 days;
        if (block.timestamp < ready && ready < escrow.disputedAt(id) + escrow.DISPUTE_TIMEOUT()) vm.warp(ready);
        OrderView memory ord = _order(id);
        (RulingLib.Ruling memory r, bytes memory sig) = _signRuling(address(escrow), id, p.release, p.ruledAt);
        vm.prank(stranger);
        try escrow.resolveDispute(id, r, sig) {
            _observe(id, ord, true);
            ++calls["executeRuling"];
        } catch {}
    }

    /// Half the time, time first passes to the picked dispute's deadline, as for a party waiting it out.
    function expireDispute(uint256 orderSeed, bool waitItOut) external {
        if (orders.length == 0) return;
        bytes32 id = _pickOrder(orderSeed, waitItOut ? Want.DISPUTED_ANY : Want.TIMED_OUT);
        uint256 deadline = escrow.disputedAt(id) + escrow.DISPUTE_TIMEOUT();
        if (waitItOut && block.timestamp < deadline) vm.warp(deadline);
        OrderView memory ord = _order(id);
        vm.prank(stranger);
        try escrow.expireDispute(id) {
            _observe(id, ord, true);
            ++calls["expireDispute"];
        } catch {}
    }

    /**
     * Take an order that has already ended and try every path that ends or reopens one: a fresh
     * good receipt, the taker's cancel, the expiry, a fresh ruling each way and the posted one, the
     * dispute timeout, a new dispute from either side. Every one must revert.
     */
    function hammerSettled(uint256 orderSeed) external {
        if (orders.length == 0) return;
        bytes32 id = _pickOrder(orderSeed, Want.ENDED);
        OrderView memory ord = _order(id);
        if (ord.state != FiatEscrow.OrderState.RELEASED && ord.state != FiatEscrow.OrderState.CANCELLED) return;
        ++calls["hammerSettled"];
        (uint64 issueBy,, bytes32 commitment) = escrow.boletoOf(id);
        verifier.setProof(
            id,
            MockVerifier.Canned({
                bankTxId: keccak256(abi.encode("bank", ++bankTx)),
                payeeKeyHash: issueBy != 0 ? commitment : _offer(ord.offerId).pixKey,
                amountBrlCents: ord.brlCents,
                paidAt: uint64(block.timestamp),
                rail: issueBy != 0 ? IAttestorVerifier.Rail.BOLETO : IAttestorVerifier.Rail.PIX,
                bound: true
            })
        );
        address lp = _offer(ord.offerId).lp;
        uint256 ok;
        try escrow.releaseWithProof(id, "") { ++ok; } catch {}
        vm.prank(ord.taker);
        try escrow.cancelOrder(id) { ++ok; } catch {}
        try escrow.reclaimExpired(id) { ++ok; } catch {}
        try escrow.expireDispute(id) { ++ok; } catch {}
        vm.prank(ord.taker);
        try escrow.raiseDispute(id, "again") { ++ok; } catch {}
        vm.prank(lp);
        try escrow.raiseDispute(id, "again") { ++ok; } catch {}
        vm.prank(ord.recipient);
        try escrow.takeDeliveryDirect(id) { ++ok; } catch {}
        for (uint256 i; i < 2; ++i) {
            (RulingLib.Ruling memory r, bytes memory sig) = _signRuling(address(escrow), id, i == 0, uint64(block.timestamp));
            try escrow.resolveDispute(id, r, sig) { ++ok; } catch {}
        }
        Posted memory p = posted[id];
        if (p.set) {
            (RulingLib.Ruling memory r, bytes memory sig) = _signRuling(address(escrow), id, p.release, p.ruledAt);
            try escrow.resolveDispute(id, r, sig) { ++ok; } catch {}
        }
        secondSettlements += ok;
    }

    /// See RulingSigner._warp.
    function warp(uint256 dt) external {
        _warp(dt, escrow.DISPUTE_TIMEOUT());
    }

    /*//////////////////////////////////////////////////////////////
                              BOOKKEEPING
    //////////////////////////////////////////////////////////////*/

    /// What an action needs of an order to be able to succeed.
    enum Want {
        LOCKED,
        PAYABLE, // locked, inside its window, and (a boleto order) issued
        LAPSED, // locked, past its window
        UNISSUED_BOLETO,
        SHIELDED_OPEN,
        DISPUTED, // with time left to post and execute a ruling
        DISPUTED_ANY,
        POSTED, // disputed, with a posted ruling, before the timeout
        TIMED_OUT,
        ENDED
    }

    /// The order the seed names or, three calls in four, the first from there that the action can
    /// apply to. The fourth stays on whatever the seed named, so the refusals are exercised too.
    function _pickOrder(uint256 seed, Want want) internal view returns (bytes32) {
        uint256 n = orders.length;
        uint256 start = seed % n;
        if (uint256(keccak256(abi.encode(seed))) % 4 == 0) return orders[start];
        for (uint256 k; k < n; ++k) {
            bytes32 id = orders[(start + k) % n];
            if (_fits(id, want)) return id;
        }
        return orders[start];
    }

    function _fits(bytes32 id, Want want) internal view returns (bool) {
        OrderView memory o = _order(id);
        bool locked = o.state == FiatEscrow.OrderState.LOCKED;
        bool disputed = o.state == FiatEscrow.OrderState.DISPUTED;
        if (want == Want.LOCKED) return locked;
        if (want == Want.ENDED) return !locked && !disputed;
        if (want == Want.SHIELDED_OPEN) return (locked || disputed) && o.delivery == FiatEscrow.Delivery.SHIELDED;
        if (want == Want.PAYABLE || want == Want.LAPSED || want == Want.UNISSUED_BOLETO) {
            if (!locked) return false;
            (uint64 issueBy, uint64 issuedAt,) = escrow.boletoOf(id);
            if (want == Want.LAPSED) return block.timestamp > o.payBy;
            if (want == Want.UNISSUED_BOLETO) return issueBy != 0 && issuedAt == 0 && block.timestamp <= issueBy;
            return block.timestamp <= o.payBy && (issueBy == 0 || issuedAt != 0);
        }
        if (!disputed) return false;
        if (want == Want.DISPUTED_ANY) return true;
        uint256 deadline = escrow.disputedAt(id) + escrow.DISPUTE_TIMEOUT();
        if (want == Want.TIMED_OUT) return block.timestamp >= deadline;
        if (want == Want.DISPUTED) return block.timestamp + 2 days <= deadline;
        return posted[id].set && block.timestamp < deadline; // POSTED
    }

    function _pickOfferWithRoom(uint256 seed) internal view returns (uint256) {
        uint256 n = offers.length;
        uint256 start = seed % n;
        for (uint256 k; k < n; ++k) {
            OfferView memory o = _offer(offers[(start + k) % n]);
            if (o.active && o.available >= o.minOrder) return (start + k) % n;
        }
        return start;
    }

    /**
     * Classify a successful call from the order's state before it and after it. An order that
     * leaves LOCKED/DISPUTED for RELEASED or CANCELLED has settled, and a release has paid exactly
     * one party: the recipient for a DIRECT order, the pool for a SHIELDED one. `settles` marks a
     * call whose success on an order that had already ended is itself a violation.
     */
    function _observe(bytes32 id, OrderView memory before, bool settles) internal {
        OrderView memory now_ = _order(id);
        bool wasOpen = before.state == FiatEscrow.OrderState.LOCKED || before.state == FiatEscrow.OrderState.DISPUTED;
        bool isOpen = now_.state == FiatEscrow.OrderState.LOCKED || now_.state == FiatEscrow.OrderState.DISPUTED;
        if (!wasOpen) {
            // Nothing may succeed against an ended order, least of all move it.
            if (settles || now_.state != before.state) ++secondSettlements;
            return;
        }
        if (isOpen) return;
        if (outcome[id] != Outcome.OPEN) ++secondSettlements;
        ++settlements[id];
        if (now_.state == FiatEscrow.OrderState.RELEASED) {
            outcome[id] = Outcome.RELEASED;
            address asset = _offer(now_.offerId).asset;
            address payee = now_.delivery == FiatEscrow.Delivery.DIRECT ? now_.recipient : address(sink);
            _paidOut(payee, asset, now_.weiAmount);
        } else {
            // Back to the offer: nothing leaves the escrow.
            outcome[id] = Outcome.REFUNDED;
        }
    }

    function _paidIn(address from, address asset, uint256 amount) internal {
        expectedDelta[from][asset] -= int256(amount);
        expectedHeld[asset] += amount;
    }

    function _paidOut(address to, address asset, uint256 amount) internal {
        expectedDelta[to][asset] += int256(amount);
        expectedHeld[asset] -= amount;
    }

    function _offer(bytes32 id) internal view returns (OfferView memory) {
        (bool ok, bytes memory ret) = address(escrow).staticcall(abi.encodeWithSelector(escrow.offers.selector, id));
        require(ok);
        return abi.decode(ret, (OfferView));
    }

    function _order(bytes32 id) internal view returns (OrderView memory) {
        (bool ok, bytes memory ret) = address(escrow).staticcall(abi.encodeWithSelector(escrow.orders.selector, id));
        require(ok);
        return abi.decode(ret, (OrderView));
    }

    /*//////////////////////////////////////////////////////////////
                           READ BY THE TEST
    //////////////////////////////////////////////////////////////*/

    function offerCount() external view returns (uint256) {
        return offers.length;
    }

    function offerAt(uint256 i) external view returns (bytes32) {
        return offers[i];
    }

    function orderCount() external view returns (uint256) {
        return orders.length;
    }

    function orderAt(uint256 i) external view returns (bytes32) {
        return orders[i];
    }

    function offerView(bytes32 id) external view returns (OfferView memory) {
        return _offer(id);
    }

    function orderView(bytes32 id) external view returns (OrderView memory) {
        return _order(id);
    }
}

/**
 * FiatEscrow's settlement invariants, over the real escrow and LP registry with the unit tests'
 * verifier and oracle mocks (T-01, T-02; ESC single settlement):
 *
 *  - every order settles at most once, by exactly one of release, cancel, expiry, a ruling or the
 *    dispute timeout: once RELEASED or CANCELLED nothing succeeds against it again, and its state
 *    never changes;
 *  - value is conserved: for each asset the escrow's balance equals the sum over its offers of
 *    available plus locked liquidity (the escrow charges no fee, so nothing else is owed), and equals
 *    what was paid in less what the handler saw paid out;
 *  - each offer's locked liquidity equals the sum of its open (LOCKED or DISPUTED) orders;
 *  - no path pays a third address: every LP, taker, recipient, the pool and every bystander holds
 *    exactly what it started with plus what the escrow owed it, and a release pays the order's
 *    recipient (DIRECT) or the pool (SHIELDED) exactly the order's amount;
 *  - no replayed, short, misaddressed or pre-order receipt ever releases;
 *  - the credit the registry holds for each LP equals the BRL value of its offers' liquidity;
 *  - and at the end of every run, with every window past, anyone can end every open order and every
 *    LP can close every offer, after which the escrow holds nothing and reserves no credit.
 */
/// forge-config: default.invariant.runs = 256
/// forge-config: default.invariant.depth = 200
contract FiatEscrowInvariantTest is Governed {
    FiatEscrow escrow;
    LPRegistry registry;
    MockVerifier verifier;
    MockOracle oracle;
    StableOracle usdOracle;
    MockUSD usd;
    ShieldedSink sink;
    FiatEscrowHandler handler;
    address governor = makeAddr("governor");

    address[] actors;
    mapping(address => mapping(address => uint256)) initial;
    mapping(address => uint256) supply;

    function setUp() public {
        vm.warp(1_700_000_000);
        oracle = new MockOracle();
        usdOracle = new StableOracle();
        verifier = new MockVerifier();
        usd = new MockUSD();
        sink = new ShieldedSink();
        registry = new LPRegistry(governor, DELAY);
        escrow = new FiatEscrow(
            address(oracle), address(registry), address(sink), address(sink), 500, governor, DELAY, DISPUTE_TIMEOUT
        );
        handler = new FiatEscrowHandler(escrow, registry, verifier, usd, sink);

        vm.startPrank(governor);
        registry.setEscrow(address(escrow), true);
        registry.setTier(handler.lps(0), LPRegistry.Tier.INSTITUTIONAL, 1e15);
        registry.setTier(handler.lps(1), LPRegistry.Tier.INSTITUTIONAL, 1e15);
        registry.setPhase(LPRegistry.Phase.C);
        registry.completeSetup();
        escrow.setVerifier(address(verifier), true);
        escrow.setArbitrator(vm.addr(0xA2B), true);
        escrow.setAsset(address(usd), address(usdOracle), 6, true);
        escrow.completeSetup();
        vm.stopPrank();
        vm.prank(handler.lps(2));
        registry.register();

        for (uint256 i; i < 3; ++i) {
            address lp = handler.lps(i);
            vm.deal(lp, 1_000_000 ether);
            usd.mint(lp, 1e15);
            vm.prank(lp);
            usd.approve(address(escrow), type(uint256).max);
            actors.push(lp);
            actors.push(handler.takers(i));
            actors.push(handler.recipients(i));
        }
        actors.push(handler.stranger());
        actors.push(address(sink));
        actors.push(address(handler));
        actors.push(address(verifier));
        actors.push(address(registry));
        actors.push(governor);
        for (uint256 i; i < actors.length; ++i) {
            initial[actors[i]][address(0)] = actors[i].balance;
            initial[actors[i]][address(usd)] = usd.balanceOf(actors[i]);
            supply[address(0)] += actors[i].balance;
            supply[address(usd)] += usd.balanceOf(actors[i]);
        }

        targetContract(address(handler));
    }

    function invariant_EveryOrderSettlesAtMostOnce() public view {
        assertEq(handler.secondSettlements(), 0, "an ended order was ended again, or reopened");
        for (uint256 i; i < handler.orderCount(); ++i) {
            bytes32 id = handler.orderAt(i);
            FiatEscrow.OrderState st = handler.orderView(id).state;
            FiatEscrowHandler.Outcome out = handler.outcome(id);
            assertLe(handler.settlements(id), 1, "an order settled twice");
            if (out == FiatEscrowHandler.Outcome.OPEN) {
                assertTrue(st == FiatEscrow.OrderState.LOCKED || st == FiatEscrow.OrderState.DISPUTED, "ended unseen");
            } else if (out == FiatEscrowHandler.Outcome.RELEASED) {
                assertEq(uint8(st), uint8(FiatEscrow.OrderState.RELEASED), "a released order changed state");
            } else {
                assertEq(uint8(st), uint8(FiatEscrow.OrderState.CANCELLED), "a refunded order changed state");
            }
        }
    }

    function invariant_EscrowHoldsExactlyItsOffers() public view {
        uint256 ethBook;
        uint256 usdBook;
        for (uint256 i; i < handler.offerCount(); ++i) {
            FiatEscrowHandler.OfferView memory o = handler.offerView(handler.offerAt(i));
            if (o.asset == address(0)) ethBook += o.available + o.locked;
            else usdBook += o.available + o.locked;
        }
        assertEq(address(escrow).balance, ethBook, "ETH held != offers' available + locked");
        assertEq(usd.balanceOf(address(escrow)), usdBook, "token held != offers' available + locked");
        assertEq(address(escrow).balance, handler.expectedHeld(address(0)), "ETH held != paid in - paid out");
        assertEq(usd.balanceOf(address(escrow)), handler.expectedHeld(address(usd)), "token held != paid in - paid out");
    }

    function invariant_OfferLockedIsItsOpenOrders() public view {
        uint256 n = handler.offerCount();
        uint256[] memory open = new uint256[](n);
        for (uint256 i; i < handler.orderCount(); ++i) {
            bytes32 id = handler.orderAt(i);
            FiatEscrowHandler.OrderView memory ord = handler.orderView(id);
            if (ord.state == FiatEscrow.OrderState.LOCKED || ord.state == FiatEscrow.OrderState.DISPUTED) {
                open[handler.offerIndex(id)] += ord.weiAmount;
            }
        }
        for (uint256 i; i < n; ++i) {
            assertEq(handler.offerView(handler.offerAt(i)).locked, open[i], "offer.lockedWei != its open orders");
        }
    }

    function invariant_NoThirdAddressIsPaid() public view {
        _checkPayees();
    }

    function invariant_NoBadReceiptReleases() public view {
        assertEq(handler.badReceiptsAccepted(), 0, "a replayed, short, misaddressed or stale receipt released");
    }

    function invariant_CreditMatchesOffers() public view {
        uint256[3] memory want;
        for (uint256 i; i < handler.offerCount(); ++i) {
            bytes32 id = handler.offerAt(i);
            FiatEscrowHandler.OfferView memory o = handler.offerView(id);
            uint256 v = (o.available + o.locked) * o.price;
            want[handler.lpIndex(id)] += v == 0 ? 0 : (v - 1) / 10 ** o.decimals + 1;
        }
        for (uint256 i; i < 3; ++i) {
            assertEq(registry.reservedBy(address(escrow), handler.lps(i)), want[i], "credit held != offers' BRL value");
        }
    }

    /**
     * Liveness, at the end of every run: past every window and timeout, a stranger ends every open
     * order and each LP closes each offer, receiving exactly its offer's available liquidity. Then the
     * escrow holds nothing and reserves no credit.
     */
    function afterInvariant() public {
        string[14] memory names = [
            "postOffer", "fundOffer", "closeOffer", "lock", "lockByBoleto", "issueBoleto", "release", "cancel",
            "takeDeliveryDirect", "reclaimExpired", "raiseDispute", "postRuling", "executeRuling", "expireDispute"
        ];
        for (uint256 i; i < names.length; ++i) {
            console2.log(names[i], handler.calls(bytes32(bytes(names[i]))));
        }
        console2.log("hammerSettled", handler.calls("hammerSettled"));

        vm.warp(block.timestamp + DISPUTE_TIMEOUT + 4 days);
        for (uint256 i; i < handler.orderCount(); ++i) {
            bytes32 id = handler.orderAt(i);
            FiatEscrow.OrderState st = handler.orderView(id).state;
            if (st == FiatEscrow.OrderState.LOCKED) escrow.reclaimExpired(id);
            else if (st == FiatEscrow.OrderState.DISPUTED) escrow.expireDispute(id);
        }
        for (uint256 i; i < handler.offerCount(); ++i) {
            bytes32 offerId = handler.offerAt(i);
            FiatEscrowHandler.OfferView memory o = handler.offerView(offerId);
            assertEq(o.locked, 0, "liquidity still locked after every order ended");
            uint256 before = o.asset == address(0) ? o.lp.balance : usd.balanceOf(o.lp);
            vm.prank(o.lp);
            escrow.closeOffer(offerId);
            uint256 after_ = o.asset == address(0) ? o.lp.balance : usd.balanceOf(o.lp);
            assertEq(after_ - before, o.available, "closing paid the LP other than its available liquidity");
        }
        assertEq(address(escrow).balance, 0, "ETH left in the escrow");
        assertEq(usd.balanceOf(address(escrow)), 0, "tokens left in the escrow");
        for (uint256 i; i < 3; ++i) {
            assertEq(registry.reservedBy(address(escrow), handler.lps(i)), 0, "credit still reserved");
        }
    }

    function _checkPayees() internal view {
        uint256 ethSum = address(escrow).balance;
        uint256 usdSum = usd.balanceOf(address(escrow));
        for (uint256 i; i < actors.length; ++i) {
            address a = actors[i];
            assertEq(
                int256(a.balance), int256(initial[a][address(0)]) + handler.expectedDelta(a, address(0)), "ETH payee"
            );
            assertEq(
                int256(usd.balanceOf(a)), int256(initial[a][address(usd)]) + handler.expectedDelta(a, address(usd)),
                "token payee"
            );
            ethSum += a.balance;
            usdSum += usd.balanceOf(a);
        }
        // Everything that exists is with a known party or in the escrow: nothing went anywhere else.
        assertEq(ethSum, supply[address(0)], "ETH reached an address outside the book");
        assertEq(usdSum, supply[address(usd)], "tokens reached an address outside the book");
        assertEq(sink.received(address(0)), uint256(handler.expectedDelta(address(sink), address(0))));
        assertEq(sink.received(address(usd)), uint256(handler.expectedDelta(address(sink), address(usd))));
    }
}

/*//////////////////////////////////////////////////////////////
                            OFF-RAMP
//////////////////////////////////////////////////////////////*/

/**
 * Drives OffRampEscrow: three sellers opening sales in ETH and the stablecoin, to a PIX key or to a
 * bill (BOLETO), and cancelling unclaimed ones; two institutional LPs and one retail LP claiming,
 * abandoning and letting claims go stale, and settling with good and bad receipts; either side
 * disputing; the desk ruling either way; disputes timing out; time passing.
 */
contract OffRampEscrowHandler is RulingSigner {
    OffRampEscrow public escrow;
    LPRegistry public registry;
    MockVerifier2 public verifier;
    MockUSD public usd;

    uint256 internal constant ETH_PRICE = 1_500_000; // MockOracle2's mid
    uint256 internal constant USD_PRICE = 550;
    uint16 internal constant PIX_MASK = uint16(1 << uint8(IAttestorVerifier.Rail.PIX));
    uint16 internal constant BOLETO_MASK = uint16(1 << uint8(IAttestorVerifier.Rail.BOLETO));

    address[3] public sellers;
    address[3] public refunds; // each seller's refund address
    address[3] public lps; // lps[2] is RETAIL
    address public stranger = makeAddr("stranger");

    bytes32[] internal sales;

    enum Outcome {
        OPEN,
        PAID_LP,
        REFUNDED
    }

    mapping(bytes32 => Outcome) public outcome;
    mapping(bytes32 => uint256) public settlements;
    uint256 public secondSettlements;
    uint256 public badReceiptsAccepted;
    mapping(address => mapping(address => int256)) public expectedDelta;
    mapping(address => uint256) public expectedHeld;

    struct Posted {
        bool set;
        bool paidLP;
        uint64 ruledAt;
    }

    mapping(bytes32 => Posted) internal posted;
    uint256 internal bankTx;
    uint256 internal payeeNonce;
    bytes32 internal lastSettledTx;
    mapping(bytes32 => uint256) public calls;

    /// @dev Field for field the `sales` getter's return values; see FiatEscrowHandler.OfferView.
    struct SaleView {
        address seller;
        address asset;
        uint256 weiAmount;
        uint256 brlCents;
        bytes32 payee;
        address verifier;
        uint16 railMask;
        address lp;
        uint64 claimedAt;
        uint64 payBy;
        address refundTo;
        OffRampEscrow.SaleState state;
    }

    constructor(OffRampEscrow escrow_, LPRegistry registry_, MockVerifier2 verifier_, MockUSD usd_) {
        escrow = escrow_;
        registry = registry_;
        verifier = verifier_;
        usd = usd_;
        for (uint256 i; i < 3; ++i) {
            sellers[i] = makeAddr(string.concat("seller", vm.toString(i)));
            refunds[i] = makeAddr(string.concat("refund", vm.toString(i)));
            lps[i] = makeAddr(string.concat("offramp-lp", vm.toString(i)));
        }
    }

    function openSale(uint256 sellerSeed, bool token, uint256 amount, bool bill) external {
        uint256 s = sellerSeed % 3;
        uint256 cents;
        if (token) {
            amount = bound(amount, 1e6, 500_000e6);
            cents = (amount * USD_PRICE + 1e6 - 1) / 1e6;
        } else {
            amount = bound(amount, 0.01 ether, 20 ether);
            cents = (amount * ETH_PRICE + 1 ether - 1) / 1 ether;
        }
        bytes32 payee = keccak256(abi.encode(bill ? "bill" : "pix", s, ++payeeNonce));
        address asset = token ? address(usd) : address(0);
        vm.prank(sellers[s]);
        try escrow.openSale{value: token ? 0 : amount}(
            asset, amount, cents, payee, address(verifier), bill ? BOLETO_MASK : PIX_MASK, refunds[s]
        ) returns (bytes32 id) {
            sales.push(id);
            _paidIn(sellers[s], asset, amount);
            ++calls["openSale"];
        } catch {}
    }

    /// An open sale, or (SRM1-13) one whose claim has lapsed: the seller cancels that directly.
    function cancelSale(uint256 saleSeed) external {
        if (sales.length == 0) return;
        bytes32 id = _pickSale(saleSeed, saleSeed % 2 == 0 ? Want.OPEN : Want.CLAIM_LAPSED);
        SaleView memory s = _sale(id);
        vm.prank(s.seller);
        try escrow.cancelSale(id) {
            _observe(id, s, true);
            ++calls["cancelSale"];
        } catch {}
    }

    function claimSale(uint256 saleSeed, uint256 lpSeed) external {
        if (sales.length == 0) return;
        bytes32 id = _pickSale(saleSeed, Want.OPEN);
        SaleView memory s = _sale(id);
        vm.prank(lps[lpSeed % 3]);
        try escrow.claimSale(id) {
            _observe(id, s, false);
            ++calls["claimSale"];
        } catch {}
    }

    function releaseStaleClaim(uint256 saleSeed) external {
        if (sales.length == 0) return;
        bytes32 id = _pickSale(saleSeed, Want.CLAIM_LAPSED);
        SaleView memory s = _sale(id);
        vm.prank(stranger);
        try escrow.releaseStaleClaim(id) {
            _observe(id, s, false);
            ++calls["releaseStaleClaim"];
        } catch {}
    }

    function abandonClaim(uint256 saleSeed) external {
        if (sales.length == 0) return;
        bytes32 id = _pickSale(saleSeed, Want.CLAIMED);
        SaleView memory s = _sale(id);
        vm.prank(s.lp);
        try escrow.abandonClaim(id) {
            _observe(id, s, false);
            ++calls["abandonClaim"];
        } catch {}
    }

    /// Variants 0-10 good; 11 on a bill pays more than its face value, 12 predates the claim, 13
    /// replays a settled receipt, 14 is a centavo short, 15 pays someone else.
    function settle(uint256 saleSeed, uint256 variant) external {
        if (sales.length == 0) return;
        bytes32 id = _pickSale(saleSeed, Want.CLAIM_LIVE);
        SaleView memory s = _sale(id);
        bool bill = s.railMask == BOLETO_MASK;
        MockVerifier2.Canned memory c = MockVerifier2.Canned({
            bankTxId: keccak256(abi.encode("offramp-bank", ++bankTx)),
            payeeKeyHash: s.payee,
            amountBrlCents: s.brlCents,
            paidAt: uint64(block.timestamp),
            rail: bill ? IAttestorVerifier.Rail.BOLETO : IAttestorVerifier.Rail.PIX,
            bound: true
        });
        variant %= 16;
        bool bad = true;
        if (variant == 11 && bill) c.amountBrlCents = s.brlCents + 1;
        else if (variant == 12 && s.claimedAt > 0) c.paidAt = s.claimedAt - 1;
        else if (variant == 13 && lastSettledTx != bytes32(0)) c.bankTxId = lastSettledTx;
        else if (variant == 14) c.amountBrlCents = s.brlCents - 1;
        else if (variant == 15) c.payeeKeyHash = keccak256("someone else's key");
        else bad = false;
        verifier.setProof(id, c);
        vm.prank(stranger);
        try escrow.settleWithProof(id, "") {
            if (bad) ++badReceiptsAccepted;
            lastSettledTx = c.bankTxId;
            _observe(id, s, true);
            ++calls["settle"];
        } catch {}
    }

    function raiseDispute(uint256 saleSeed, bool byLP) external {
        if (sales.length == 0) return;
        bytes32 id = _pickSale(saleSeed, Want.CLAIMED);
        SaleView memory s = _sale(id);
        vm.prank(byLP ? s.lp : s.seller);
        try escrow.raiseDispute(id, "invariant") {
            _observe(id, s, false);
            ++calls["raiseDispute"];
        } catch {}
    }

    function postRuling(uint256 saleSeed, bool paidLP) external {
        if (sales.length == 0) return;
        bytes32 id = _pickSale(saleSeed, Want.DISPUTED);
        SaleView memory s = _sale(id);
        uint64 ruledAt = uint64(block.timestamp);
        (RulingLib.Ruling memory r, bytes memory sig) = _signRuling(address(escrow), id, paidLP, ruledAt);
        vm.prank(stranger);
        try escrow.resolveDispute(id, r, sig) {
            if (_sale(id).state == s.state) posted[id] = Posted(true, paidLP, ruledAt);
            _observe(id, s, true);
            ++calls["postRuling"];
        } catch {}
    }

    /// See FiatEscrowHandler.executeRuling.
    function executeRuling(uint256 saleSeed) external {
        if (sales.length == 0) return;
        bytes32 id = _pickSale(saleSeed, Want.POSTED);
        Posted memory p = posted[id];
        if (!p.set) return;
        uint256 ready = uint256(p.ruledAt) + 1 days;
        if (block.timestamp < ready && ready < escrow.disputedAt(id) + escrow.DISPUTE_TIMEOUT()) vm.warp(ready);
        SaleView memory s = _sale(id);
        (RulingLib.Ruling memory r, bytes memory sig) = _signRuling(address(escrow), id, p.paidLP, p.ruledAt);
        vm.prank(stranger);
        try escrow.resolveDispute(id, r, sig) {
            _observe(id, s, true);
            ++calls["executeRuling"];
        } catch {}
    }

    /// See FiatEscrowHandler.expireDispute.
    function expireDispute(uint256 saleSeed, bool waitItOut) external {
        if (sales.length == 0) return;
        bytes32 id = _pickSale(saleSeed, waitItOut ? Want.DISPUTED_ANY : Want.TIMED_OUT);
        uint256 deadline = escrow.disputedAt(id) + escrow.DISPUTE_TIMEOUT();
        if (waitItOut && block.timestamp < deadline) vm.warp(deadline);
        SaleView memory s = _sale(id);
        vm.prank(stranger);
        try escrow.expireDispute(id) {
            _observe(id, s, true);
            ++calls["expireDispute"];
        } catch {}
    }

    /// Every path that ends, reopens or re-claims a sale, against one that has ended. All must revert.
    function hammerSettled(uint256 saleSeed, uint256 lpSeed) external {
        if (sales.length == 0) return;
        bytes32 id = _pickSale(saleSeed, Want.ENDED);
        SaleView memory s = _sale(id);
        if (s.state != OffRampEscrow.SaleState.SETTLED && s.state != OffRampEscrow.SaleState.CANCELLED) return;
        ++calls["hammerSettled"];
        verifier.setProof(
            id,
            MockVerifier2.Canned({
                bankTxId: keccak256(abi.encode("offramp-bank", ++bankTx)),
                payeeKeyHash: s.payee,
                amountBrlCents: s.brlCents,
                paidAt: uint64(block.timestamp),
                rail: s.railMask == BOLETO_MASK ? IAttestorVerifier.Rail.BOLETO : IAttestorVerifier.Rail.PIX,
                bound: true
            })
        );
        uint256 ok;
        try escrow.settleWithProof(id, "") { ++ok; } catch {}
        vm.prank(s.seller);
        try escrow.cancelSale(id) { ++ok; } catch {}
        vm.prank(lps[lpSeed % 3]);
        try escrow.claimSale(id) { ++ok; } catch {}
        try escrow.releaseStaleClaim(id) { ++ok; } catch {}
        vm.prank(s.lp);
        try escrow.abandonClaim(id) { ++ok; } catch {}
        try escrow.expireDispute(id) { ++ok; } catch {}
        vm.prank(s.seller);
        try escrow.raiseDispute(id, "again") { ++ok; } catch {}
        vm.prank(s.lp);
        try escrow.raiseDispute(id, "again") { ++ok; } catch {}
        for (uint256 i; i < 2; ++i) {
            (RulingLib.Ruling memory r, bytes memory sig) = _signRuling(address(escrow), id, i == 0, uint64(block.timestamp));
            try escrow.resolveDispute(id, r, sig) { ++ok; } catch {}
        }
        Posted memory p = posted[id];
        if (p.set) {
            (RulingLib.Ruling memory r, bytes memory sig) = _signRuling(address(escrow), id, p.paidLP, p.ruledAt);
            try escrow.resolveDispute(id, r, sig) { ++ok; } catch {}
        }
        secondSettlements += ok;
    }

    /// See RulingSigner._warp.
    function warp(uint256 dt) external {
        _warp(dt, escrow.DISPUTE_TIMEOUT());
    }

    enum Want {
        OPEN,
        CLAIMED,
        CLAIM_LIVE, // claimed, inside the pay window
        CLAIM_LAPSED, // claimed, past it
        DISPUTED, // with time left to post and execute a ruling
        DISPUTED_ANY,
        POSTED,
        TIMED_OUT,
        ENDED
    }

    /// See FiatEscrowHandler._pickOrder.
    function _pickSale(uint256 seed, Want want) internal view returns (bytes32) {
        uint256 n = sales.length;
        uint256 start = seed % n;
        if (uint256(keccak256(abi.encode(seed))) % 4 == 0) return sales[start];
        for (uint256 k; k < n; ++k) {
            bytes32 id = sales[(start + k) % n];
            if (_fits(id, want)) return id;
        }
        return sales[start];
    }

    function _fits(bytes32 id, Want want) internal view returns (bool) {
        SaleView memory s = _sale(id);
        OffRampEscrow.SaleState st = s.state;
        if (want == Want.OPEN) return st == OffRampEscrow.SaleState.OPEN;
        if (want == Want.ENDED) return st == OffRampEscrow.SaleState.SETTLED || st == OffRampEscrow.SaleState.CANCELLED;
        if (want == Want.CLAIMED) return st == OffRampEscrow.SaleState.CLAIMED;
        if (want == Want.CLAIM_LIVE) return st == OffRampEscrow.SaleState.CLAIMED && block.timestamp <= s.payBy;
        if (want == Want.CLAIM_LAPSED) return st == OffRampEscrow.SaleState.CLAIMED && block.timestamp > s.payBy;
        if (st != OffRampEscrow.SaleState.DISPUTED) return false;
        if (want == Want.DISPUTED_ANY) return true;
        uint256 deadline = escrow.disputedAt(id) + escrow.DISPUTE_TIMEOUT();
        if (want == Want.TIMED_OUT) return block.timestamp >= deadline;
        if (want == Want.DISPUTED) return block.timestamp + 2 days <= deadline;
        return posted[id].set && block.timestamp < deadline; // POSTED
    }

    /// A sale that leaves OPEN/CLAIMED/DISPUTED has settled: SETTLED pays the claiming LP, CANCELLED
    /// pays the seller's refund address, each exactly the sale's amount.
    function _observe(bytes32 id, SaleView memory before, bool settles) internal {
        SaleView memory now_ = _sale(id);
        bool wasOpen = before.state == OffRampEscrow.SaleState.OPEN || before.state == OffRampEscrow.SaleState.CLAIMED
            || before.state == OffRampEscrow.SaleState.DISPUTED;
        bool isOpen = now_.state == OffRampEscrow.SaleState.OPEN || now_.state == OffRampEscrow.SaleState.CLAIMED
            || now_.state == OffRampEscrow.SaleState.DISPUTED;
        if (!wasOpen) {
            if (settles || now_.state != before.state) ++secondSettlements;
            return;
        }
        if (isOpen) return;
        if (outcome[id] != Outcome.OPEN) ++secondSettlements;
        ++settlements[id];
        if (now_.state == OffRampEscrow.SaleState.SETTLED) {
            outcome[id] = Outcome.PAID_LP;
            // The LP that held the claim when the sale settled, as recorded before the call.
            _paidOut(before.lp, now_.asset, now_.weiAmount);
        } else {
            outcome[id] = Outcome.REFUNDED;
            _paidOut(now_.refundTo, now_.asset, now_.weiAmount);
        }
    }

    function _paidIn(address from, address asset, uint256 amount) internal {
        expectedDelta[from][asset] -= int256(amount);
        expectedHeld[asset] += amount;
    }

    function _paidOut(address to, address asset, uint256 amount) internal {
        expectedDelta[to][asset] += int256(amount);
        expectedHeld[asset] -= amount;
    }

    function _sale(bytes32 id) internal view returns (SaleView memory) {
        (bool ok, bytes memory ret) = address(escrow).staticcall(abi.encodeWithSelector(escrow.sales.selector, id));
        require(ok);
        return abi.decode(ret, (SaleView));
    }

    function saleCount() external view returns (uint256) {
        return sales.length;
    }

    function saleAt(uint256 i) external view returns (bytes32) {
        return sales[i];
    }

    function saleView(bytes32 id) external view returns (SaleView memory) {
        return _sale(id);
    }
}

/**
 * OffRampEscrow's settlement invariants, over the real escrow and registry with the unit tests' mocks:
 *
 *  - every sale settles at most once, to the LP (a proven payment or a RELEASE ruling) or back to the
 *    seller (cancel, a REFUND ruling or the dispute timeout), never both and never again;
 *  - value is conserved: for each asset the escrow's balance equals the sum of its open (OPEN, CLAIMED
 *    or DISPUTED) sales, and equals paid in less paid out (no fee is charged, so nothing else is owed);
 *  - no path pays a third address: a settled sale paid its claiming LP, a refunded one its seller's
 *    refund address, exactly the sale's amount, and every other address is untouched;
 *  - no replayed, short, misaddressed, pre-claim or wrong-face-value receipt ever settles;
 *  - the credit the registry holds for each LP is the sum of the sales it holds a live claim on;
 *  - and at the end of every run anyone can end every sale, after which the escrow is empty.
 */
/// forge-config: default.invariant.runs = 256
/// forge-config: default.invariant.depth = 200
contract OffRampEscrowInvariantTest is Governed {
    OffRampEscrow escrow;
    LPRegistry registry;
    MockVerifier2 verifier;
    MockOracle2 oracle;
    StableOracle usdOracle;
    MockUSD usd;
    OffRampEscrowHandler handler;
    address governor = makeAddr("governor");

    address[] actors;
    mapping(address => mapping(address => uint256)) initial;
    mapping(address => uint256) supply;

    function setUp() public {
        vm.warp(1_700_000_000);
        oracle = new MockOracle2();
        usdOracle = new StableOracle();
        verifier = new MockVerifier2();
        usd = new MockUSD();
        registry = new LPRegistry(governor, DELAY);
        escrow = new OffRampEscrow(address(oracle), address(registry), 500, governor, DELAY, DISPUTE_TIMEOUT);
        handler = new OffRampEscrowHandler(escrow, registry, verifier, usd);

        vm.startPrank(governor);
        registry.setEscrow(address(escrow), true);
        registry.setTier(handler.lps(0), LPRegistry.Tier.INSTITUTIONAL, 1e15);
        registry.setTier(handler.lps(1), LPRegistry.Tier.INSTITUTIONAL, 1e15);
        registry.setPhase(LPRegistry.Phase.C);
        registry.completeSetup();
        escrow.setVerifier(address(verifier), true);
        escrow.setArbitrator(vm.addr(0xA2B), true);
        escrow.setAsset(address(usd), address(usdOracle), 6, true);
        escrow.completeSetup();
        vm.stopPrank();
        vm.prank(handler.lps(2));
        registry.register();

        for (uint256 i; i < 3; ++i) {
            address seller = handler.sellers(i);
            vm.deal(seller, 1_000_000 ether);
            usd.mint(seller, 1e15);
            vm.prank(seller);
            usd.approve(address(escrow), type(uint256).max);
            actors.push(seller);
            actors.push(handler.refunds(i));
            actors.push(handler.lps(i));
        }
        actors.push(handler.stranger());
        actors.push(address(handler));
        actors.push(address(verifier));
        actors.push(address(registry));
        actors.push(governor);
        for (uint256 i; i < actors.length; ++i) {
            initial[actors[i]][address(0)] = actors[i].balance;
            initial[actors[i]][address(usd)] = usd.balanceOf(actors[i]);
            supply[address(0)] += actors[i].balance;
            supply[address(usd)] += usd.balanceOf(actors[i]);
        }

        targetContract(address(handler));
    }

    function _open(OffRampEscrow.SaleState st) internal pure returns (bool) {
        return st == OffRampEscrow.SaleState.OPEN || st == OffRampEscrow.SaleState.CLAIMED
            || st == OffRampEscrow.SaleState.DISPUTED;
    }

    function invariant_EverySaleSettlesAtMostOnce() public view {
        assertEq(handler.secondSettlements(), 0, "an ended sale was ended again, reopened or re-claimed");
        for (uint256 i; i < handler.saleCount(); ++i) {
            bytes32 id = handler.saleAt(i);
            OffRampEscrow.SaleState st = handler.saleView(id).state;
            OffRampEscrowHandler.Outcome out = handler.outcome(id);
            assertLe(handler.settlements(id), 1, "a sale settled twice");
            if (out == OffRampEscrowHandler.Outcome.OPEN) assertTrue(_open(st), "ended unseen");
            else if (out == OffRampEscrowHandler.Outcome.PAID_LP) assertEq(uint8(st), uint8(OffRampEscrow.SaleState.SETTLED));
            else assertEq(uint8(st), uint8(OffRampEscrow.SaleState.CANCELLED));
        }
    }

    function invariant_EscrowHoldsExactlyItsOpenSales() public view {
        uint256 ethOpen;
        uint256 usdOpen;
        for (uint256 i; i < handler.saleCount(); ++i) {
            OffRampEscrowHandler.SaleView memory s = handler.saleView(handler.saleAt(i));
            if (!_open(s.state)) continue;
            if (s.asset == address(0)) ethOpen += s.weiAmount;
            else usdOpen += s.weiAmount;
        }
        assertEq(address(escrow).balance, ethOpen, "ETH held != open sales");
        assertEq(usd.balanceOf(address(escrow)), usdOpen, "token held != open sales");
        assertEq(address(escrow).balance, handler.expectedHeld(address(0)), "ETH held != paid in - paid out");
        assertEq(usd.balanceOf(address(escrow)), handler.expectedHeld(address(usd)), "token held != paid in - paid out");
    }

    function invariant_NoThirdAddressIsPaid() public view {
        uint256 ethSum = address(escrow).balance;
        uint256 usdSum = usd.balanceOf(address(escrow));
        for (uint256 i; i < actors.length; ++i) {
            address a = actors[i];
            assertEq(int256(a.balance), int256(initial[a][address(0)]) + handler.expectedDelta(a, address(0)), "ETH payee");
            assertEq(
                int256(usd.balanceOf(a)), int256(initial[a][address(usd)]) + handler.expectedDelta(a, address(usd)),
                "token payee"
            );
            ethSum += a.balance;
            usdSum += usd.balanceOf(a);
        }
        assertEq(ethSum, supply[address(0)], "ETH reached an address outside the book");
        assertEq(usdSum, supply[address(usd)], "tokens reached an address outside the book");
    }

    function invariant_NoBadReceiptSettles() public view {
        assertEq(handler.badReceiptsAccepted(), 0, "a replayed, short, misaddressed or stale receipt settled");
    }

    function invariant_CreditMatchesLiveClaims() public view {
        uint256[3] memory want;
        for (uint256 i; i < handler.saleCount(); ++i) {
            OffRampEscrowHandler.SaleView memory s = handler.saleView(handler.saleAt(i));
            if (s.state != OffRampEscrow.SaleState.CLAIMED && s.state != OffRampEscrow.SaleState.DISPUTED) continue;
            for (uint256 j; j < 3; ++j) {
                if (s.lp == handler.lps(j)) want[j] += s.brlCents;
            }
        }
        for (uint256 j; j < 3; ++j) {
            assertEq(registry.reservedBy(address(escrow), handler.lps(j)), want[j], "credit held != live claims");
        }
    }

    function afterInvariant() public {
        string[11] memory names = [
            "openSale", "cancelSale", "claimSale", "releaseStaleClaim", "abandonClaim", "settle", "raiseDispute",
            "postRuling", "executeRuling", "expireDispute", "hammerSettled"
        ];
        for (uint256 i; i < names.length; ++i) {
            console2.log(names[i], handler.calls(bytes32(bytes(names[i]))));
        }

        vm.warp(block.timestamp + DISPUTE_TIMEOUT + 4 days);
        for (uint256 i; i < handler.saleCount(); ++i) {
            bytes32 id = handler.saleAt(i);
            OffRampEscrowHandler.SaleView memory s = handler.saleView(id);
            if (s.state == OffRampEscrow.SaleState.DISPUTED) {
                escrow.expireDispute(id);
                continue;
            }
            if (s.state == OffRampEscrow.SaleState.CLAIMED) escrow.releaseStaleClaim(id);
            if (s.state == OffRampEscrow.SaleState.CLAIMED || s.state == OffRampEscrow.SaleState.OPEN) {
                vm.prank(s.seller);
                escrow.cancelSale(id);
            }
        }
        assertEq(address(escrow).balance, 0, "ETH left in the escrow");
        assertEq(usd.balanceOf(address(escrow)), 0, "tokens left in the escrow");
        for (uint256 j; j < 3; ++j) {
            assertEq(registry.reservedBy(address(escrow), handler.lps(j)), 0, "credit still reserved");
        }
    }
}
