// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

import {Test} from "forge-std/Test.sol";
import {OwnerlessPaymaster, IEntryPointFunding, PackedUserOperation} from "../OwnerlessPaymaster.sol";
import {AspRootQuorum, IEntrypointRoots} from "../AspRootQuorum.sol";

/**
 * M1 security review, account layer: demonstrations of BEHAVIOUR, not failing tests.
 *
 * These pass on the current code. Each one pins a property the review reports, so a fix that changes
 * it (e.g. a priority-fee cap in a redeployed paymaster) makes the corresponding test fail and must
 * update this file deliberately.
 *
 * The paymaster's validation and postOp only compare msg.sender with the immutable ENTRYPOINT and
 * never call it, so a plain address stands in for EntryPoint v0.7 here; the factories are arbitrary
 * non-zero addresses because provenance is pure CREATE2 arithmetic (OwnerlessPaymaster.sol:400-404).
 * The policy is the one deployed on Sepolia at 0x98a4...069d (docs/deployments.md).
 */
contract ReviewM1_AccountsTest is Test {
    address internal constant EP = address(0x0000000071727De22E5E9d8BAf0edAc6f37da032);
    address internal constant SAFE_FACTORY = address(0x4e1DCf7AD4e460CfD30791CCC4F9c8a4f820ec67);
    bytes32 internal constant SAFE_HASH = keccak256("any proxy init code");

    OwnerlessPaymaster internal pm;

    function setUp() public {
        vm.warp(1_800_000_000);
        pm = new OwnerlessPaymaster(
            IEntryPointFunding(EP),
            OwnerlessPaymaster.Policy({
                factory0: SAFE_FACTORY,
                proxyInitCodeHash0: SAFE_HASH,
                factory1: address(0),
                proxyInitCodeHash1: bytes32(0),
                window: 86_400,
                grace: 3_600,
                maxCostPerOp: 0.01 ether,
                maxOpsPerAccount: 10,
                maxCostPerAccount: 0.02 ether,
                maxCostGlobal: 0.2 ether,
                unstakeDelaySec: 86_400
            })
        );
    }

    function _op(bytes32 salt, uint128 priorityFee, uint128 maxFee) internal view returns (PackedUserOperation memory op) {
        op.sender = pm.accountAddress(0, salt);
        op.accountGasLimits = bytes32((uint256(3_000_000) << 128) | 500_000);
        op.preVerificationGas = 200_000;
        // EntryPoint v0.7 packing: maxPriorityFeePerGas (high 128) ++ maxFeePerGas (low 128).
        op.gasFees = bytes32((uint256(priorityFee) << 128) | maxFee);
        op.paymasterAndData = abi.encodePacked(
            address(pm), uint128(300_000), uint128(60_000), uint8(0), salt, pm.currentWindow()
        );
    }

    /**
     * FINDING (gas price unbounded): validation never reads userOp.gasFees (OwnerlessPaymaster.sol:282-295).
     * An op whose priority fee is ~2.46 gwei-per-gas x 4.06M gas = 0.01 ETH maxCost is sponsored exactly
     * like one at 1 wei; with Sepolia's base fee at ~18 wei, essentially all of it is priority fee, which
     * EntryPoint v0.7 pays to the bundler's beneficiary. postOp then charges the full actualGasCost.
     */
    function test_Demo_PaymasterSponsorsAnyGasPriceUpToMaxCostPerOp() public {
        uint256 gasTotal = 3_000_000 + 500_000 + 200_000 + 300_000 + 60_000; // what EP multiplies maxFee by
        uint128 fee = uint128(0.01 ether / gasTotal); // ~2.46 gwei, i.e. ~1.4e8 x an 18 wei base fee
        PackedUserOperation memory greedy = _op(bytes32(uint256(1)), fee, fee);
        PackedUserOperation memory frugal = _op(bytes32(uint256(2)), 1, 19);

        vm.startPrank(EP);
        (bytes memory ctxGreedy, uint256 vdGreedy) = pm.validatePaymasterUserOp(greedy, bytes32(0), gasTotal * fee);
        (, uint256 vdFrugal) = pm.validatePaymasterUserOp(frugal, bytes32(0), gasTotal * 19);
        assertEq(vdGreedy, vdFrugal, "same validationData: the fee plays no part in the decision");

        // The op used all its gas at that price: the whole reservation stays charged.
        uint256 actual = (gasTotal - 70_000) * fee;
        pm.postOp(0, ctxGreedy, actual, fee);
        vm.stopPrank();
        (,, uint128 spent) = pm.usageOf(greedy.sender);
        assertGe(spent, actual, "charged at least what the EntryPoint debits");
        assertGt(spent, 0.0099 ether, "~0.01 ETH of deposit for one op that needed ~4M x 18 wei = 7e-11 ETH");
    }

    /**
     * FINDING (deployed config): MAX_COST_GLOBAL (0.2 ETH) is twice the deposit (0.1 ETH), so the global
     * cap - "the only bound on how fast the deposit can be drained" (OwnerlessPaymaster.sol:87) - cannot
     * bind before the deposit is gone. Five free Sybil accounts x two ops at MAX_COST_PER_OP reserve the
     * whole 0.1 ETH in ONE window and still leave 0.1 ETH of global room.
     */
    function test_Demo_TenOpsInOneWindowReserveTheWholeDeployedDeposit() public {
        uint256 reserved;
        vm.startPrank(EP);
        for (uint256 i; i < 5; ++i) {
            for (uint256 j; j < 2; ++j) {
                PackedUserOperation memory op = _op(bytes32(1000 + i), 0, 0);
                pm.validatePaymasterUserOp(op, bytes32(0), 0.01 ether);
                reserved += 0.01 ether;
            }
        }
        vm.stopPrank();
        assertEq(reserved, 0.1 ether, "= the whole Sepolia deposit");
        (,, uint256 globalLeft) = pm.remaining(address(0));
        assertEq(globalLeft, 0.1 ether, "and the global cap still has room for as much again");
    }

    /**
     * HELD: the only stale-window path is the conservative one. An op naming the previous window (valid in
     * its GRACE) after a later window was opened is counted in the later window; validationData still
     * limits it to the old window + GRACE.
     */
    function test_Held_OldWindowOpCountsInTheLaterOpenWindow() public {
        uint48 w = pm.currentWindow();
        PackedUserOperation memory now_ = _op(bytes32(uint256(7)), 0, 0);
        PackedUserOperation memory old = _op(bytes32(uint256(8)), 0, 0);
        old.paymasterAndData = abi.encodePacked(
            address(pm), uint128(300_000), uint128(60_000), uint8(0), bytes32(uint256(8)), w - 1
        );
        vm.startPrank(EP);
        pm.validatePaymasterUserOp(now_, bytes32(0), 0.001 ether);
        (bytes memory ctx, uint256 vd) = pm.validatePaymasterUserOp(old, bytes32(0), 0.001 ether);
        vm.stopPrank();
        (, uint48 accountWindow, uint48 globalWindow,,) = abi.decode(ctx, (address, uint48, uint48, uint256, uint256));
        assertEq(accountWindow, w - 1, "the account had no later window");
        assertEq(globalWindow, w, "globally it is charged to the open (later) window");
        assertEq(uint48(vd >> 160), uint256(w) * 86_400 - 1 + 3_600, "valid only until the old window's grace ends");
        (uint48 gw, uint128 gs) = pm.globalUsage();
        assertEq(gw, w);
        assertEq(gs, 0.002 ether);
    }
}

/// @dev Records what the quorum posts; Entrypoint.updateRoot's own checks are irrelevant here.
contract RootSink is IEntrypointRoots {
    uint256 public latestRoot;
    uint256 public posts;

    function updateRoot(uint256 root, string memory) external returns (uint256) {
        latestRoot = root;
        return posts++;
    }
}

/**
 * AspRootQuorum: a vote can never be withdrawn and never expires inside a round
 * (AspRootQuorum.sol:104-125 has no unvote, no deadline; rounds advance only on a post, line 120).
 */
contract ReviewM1_QuorumTest is Test {
    string internal constant CID = "bafybeigdyrzt5sfp7udm7hu76uh7y26nf3efuylqabf3oclgtqy55fbzdi";

    function test_Demo_AStaleVoteTheAspAbandonedStillCompletesAQuorum() public {
        RootSink sink = new RootSink();
        address[] memory asps = new address[](3);
        asps[0] = address(0xA);
        asps[1] = address(0xB);
        asps[2] = address(0xC);
        AspRootQuorum q = new AspRootQuorum(sink, asps, 2);

        // Round 0: ASP A approves root X (say it includes label L).
        vm.prank(address(0xA));
        q.vote(111, CID);
        // Months later A learns L is bad and votes for X' without it. Its vote for X still counts.
        vm.warp(block.timestamp + 180 days);
        vm.prank(address(0xA));
        q.vote(222, CID);
        // A single other ASP (B) now completes X with A's abandoned vote: X, not X', becomes the latest root.
        vm.prank(address(0xB));
        assertTrue(q.vote(111, CID));
        assertEq(sink.latestRoot(), 111);
    }
}
