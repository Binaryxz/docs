// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Governed} from "./utils/Governed.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {HyperCore, ICoreDepositWallet} from "../hyperliquid/HyperCore.sol";
import {HyperCoreDeltaNeutralVault as Vault} from "../hyperliquid/HyperCoreDeltaNeutralVault.sol";
import {IDeltaNeutral} from "../hyperliquid/IDeltaNeutral.sol";
import {HyperCoreSim, SimUSDC, SimDepositWallet} from "./utils/HyperCoreSim.sol";

/// Tick and lot rounding against the rules in hyperliquid-docs/for-developers/api/tick-and-lot-size.
contract HyperCoreRoundingTest is Governed {
    function test_PricesKeepFiveSignificantFiguresAndTheDecimalLimit() public pure {
        // 2507.53 at 2 perp price decimals (ETH, szDecimals 4): five sig figs means 2507.5.
        assertEq(HyperCore.roundPx(2507_53000000, 2, false), 2507_50000000);
        assertEq(HyperCore.roundPx(2507_53000000, 2, true), 2507_60000000);
        // Integer prices are always allowed, however many digits: 123456.7 -> 123456 / 123457.
        assertEq(HyperCore.roundPx(123456_70000000, 1, false), 123456_00000000);
        assertEq(HyperCore.roundPx(123456_70000000, 1, true), 123457_00000000);
        // Small prices: 0.0123456 with 6 decimals allowed -> 0.012345 (sig figs bind first).
        assertEq(HyperCore.roundPx(1234560, 6, false), 1234500);
        // The decimal limit binds when tighter: 1.23456 with 2 decimals -> 1.23.
        assertEq(HyperCore.roundPx(123456000, 2, false), 123000000);
        // Already valid prices are unchanged in both directions.
        assertEq(HyperCore.roundPx(2500_00000000, 2, true), 2500_00000000);
    }

    function testFuzz_RoundingNeverCrossesTheInputTheWrongWay(uint64 px, uint8 dec) public pure {
        vm.assume(px > 0);
        uint256 d = bound(dec, 0, 8);
        uint256 down = HyperCore.roundPx(px, d, false);
        uint256 up = HyperCore.roundPx(px, d, true);
        assertLe(down, px);
        assertGe(up, px);
        assertEq(HyperCore.roundPx(down, d, false), down, "idempotent");
    }

    function test_SizesRoundDownToTheLot() public pure {
        assertEq(HyperCore.roundSz(1_23456789, 4), 1_23450000);
        assertEq(HyperCore.roundSz(1_23456789, 8), 1_23456789);
        assertEq(HyperCore.roundSz(99, 0), 0);
    }

    function test_ActionEncodingMatchesTheDocs() public {
        // Version 1, action id 1 as three bytes, then abi.encode - checked against the bytes the
        // docs' own example and live CoreDepositWallet logs (01 00000d ...) use.
        HyperCoreSim sim = new HyperCoreSim(new SimUSDC());
        sim.install();
        vm.recordLogs();
        this.sendOrder();
        bytes memory data = abi.decode(vm.getRecordedLogs()[0].data, (bytes));
        assertEq(uint8(data[0]), 1);
        assertEq(uint8(data[1]), 0);
        assertEq(uint8(data[2]), 0);
        assertEq(uint8(data[3]), 1);
        assertEq(data.length, 4 + 7 * 32);
    }

    function sendOrder() external {
        HyperCore.limitOrder(1, true, 2500_00000000, 1_00000000, false, HyperCore.TIF_IOC, 0);
    }
}

/**
 * The delta-neutral vault against a simulated HyperCore living at the real precompile and
 * CoreWriter addresses. Each test ends an EVM block with `_tick`: HyperCore applies deposits and
 * actions after the block, and the vault may read and act again once `settleSeconds` have passed.
 */
contract HyperCoreDeltaNeutralVaultTest is Governed {
    SimUSDC usdc;
    HyperCoreSim sim;
    SimDepositWallet cdw;
    Vault vault;

    address gov = makeAddr("gov");
    address guardian = makeAddr("guardian");
    address keeper = makeAddr("keeper");
    address alice = makeAddr("alice");
    address bob = makeAddr("bob");
    address stranger = makeAddr("stranger");

    uint64 constant PX = 250_000; // $2,500 in ETH perp raw units
    uint64 constant SPOT_PX = 25_000_000; // $2,500 in spot raw units

    function _params() internal pure returns (IDeltaNeutral.Params memory p) {
        p = IDeltaNeutral.Params({
            targetLeverageBps: 20_000,
            maxLeverageBps: 30_000,
            slippageBps: 30,
            deltaToleranceBps: 200,
            maxSpotDeviationBps: 100,
            idleBufferBps: 1_000,
            maxDrawdownBps: 300,
            exitFeeBps: 20,
            fundingPauseE8: 0,
            fundingUnwindE8: -1_141, // -10% a year, hourly
            fundingTau: 84 hours,
            minActionInterval: 60,
            settleSeconds: 5,
            maxOrderNotional: 50_000e6,
            maxDailyTurnover: 2_000_000e6,
            depositCap: 10_000_000e6
        });
    }

    function setUp() public {
        vm.warp(1_789_000_000);
        usdc = new SimUSDC();
        sim = new HyperCoreSim(usdc);
        sim.install();
        cdw = new SimDepositWallet(sim, usdc);
        sim.setDepositWallet(cdw);

        vault = new Vault(
            "Delta-neutral ETH", "dnETH", IERC20(address(usdc)), ICoreDepositWallet(address(cdw)), 1, 151,
            gov, guardian, keeper, DELAY, _params()
        );
        vm.prank(gov);
        vault.completeSetup();
        // HyperCore charges bridge gas in HYPE from the vault's spot balance; anyone may fund it.
        vm.deal(stranger, 1 ether);
        vm.prank(stranger);
        vault.fundCoreGas{value: 1 ether}();

        for (uint256 i; i < 2; ++i) {
            address u = i == 0 ? alice : bob;
            usdc.mint(u, 1_000_000e6);
            vm.prank(u);
            usdc.approve(address(vault), type(uint256).max);
        }
    }

    /// End the EVM block: HyperCore processes it, and time passes past the settle window.
    function _tick() internal {
        sim.processBlock();
        vm.roll(block.number + 1);
        vm.warp(block.timestamp + 61);
    }

    function _rebalanceUntilDone(uint256 maxSteps) internal returns (uint256 steps) {
        for (; steps < maxSteps; ++steps) {
            vm.prank(keeper);
            try vault.rebalance() {}
            catch (bytes memory err) {
                assertEq(bytes4(err), IDeltaNeutral.NothingToDo.selector, "only 'nothing to do' ends the loop");
                return steps;
            }
            _tick();
        }
        revert("did not converge");
    }

    function _deposit(address who, uint256 amount) internal {
        vm.prank(who);
        vault.deposit(amount, who);
    }

    function _deploy(uint256 amount) internal {
        _deposit(alice, amount);
        _rebalanceUntilDone(60);
    }

    /*//////////////////////////////////////////////////////////////
                                POSITION
    //////////////////////////////////////////////////////////////*/

    function test_TheKeeperBuildsADeltaNeutralPositionWithinItsBounds() public {
        _deploy(300_000e6);
        uint256 shortSize = uint256(uint64(-sim.szi(address(vault))));
        uint256 spotSize = sim.spotOf(address(vault), sim.BASE_TOKEN());
        // szi has 4 decimals, UETH wei 9: compare in the same units.
        assertApproxEqRel(shortSize * 1e5, spotSize, 0.02e18, "legs within the delta tolerance");
        assertGt(shortSize, 0, "a short exists");

        // Equity ~300k less a 10% buffer, at 2x: spot S plus margin S/2 = 270k, so S ~ 180k.
        uint256 nav = vault.totalAssets();
        assertApproxEqRel(nav, 300_000e6, 0.003e18, "fees and slippage cost well under 0.3%");
        uint256 shortNotional = shortSize * PX;
        assertApproxEqRel(shortNotional, (nav * 9 * 2) / (10 * 3), 0.05e18, "at target leverage");
        assertGe(usdc.balanceOf(address(vault)), (nav * 9) / 100, "buffer kept on HyperEVM");

        // Every order the contract ever sent was IOC, within the band, and no bigger than the cap.
        for (uint256 i; i < sim.orderCount(); ++i) {
            HyperCoreSim.OrderLog memory o = sim.orderAt(i);
            assertEq(o.tif, HyperCore.TIF_IOC);
            uint256 ref = 2500e8;
            if (o.isBuy) assertLe(o.limitPx, (ref * 10_030) / 10_000, "buy within +30 bps");
            else assertGe(o.limitPx, (ref * 9_970) / 10_000, "sell within -30 bps");
            assertLe((uint256(o.sz) * 2500), 50_000e6 * 1e2 + 2500, "at most maxOrderNotional");
        }
    }

    function test_PriceMovesCancelOut() public {
        _deploy(300_000e6);
        uint256 before = vault.totalAssets();
        sim.setPrices((PX * 120) / 100, (SPOT_PX * 120) / 100);
        assertApproxEqRel(vault.totalAssets(), before, 0.005e18, "+20%: flat");
        sim.setPrices((PX * 75) / 100, (SPOT_PX * 75) / 100);
        assertApproxEqRel(vault.totalAssets(), before, 0.005e18, "-25%: flat");
    }

    function test_PositiveFundingReachesTheSharePrice() public {
        _deploy(300_000e6);
        uint256 price = vault.assetsPerShare();
        for (uint256 h; h < 24 * 30; ++h) sim.payFunding(address(vault), 1_250); // 0.00125%/h ~ 11% APR
        assertGt(vault.assetsPerShare(), price, "funding accrued to holders");
    }

    /*//////////////////////////////////////////////////////////////
                               KEEPER BOUNDS
    //////////////////////////////////////////////////////////////*/

    function test_OnlyTheKeeperRebalancesAndOnlyAtItsPace() public {
        _deposit(alice, 100_000e6);
        vm.prank(stranger);
        vm.expectRevert(IDeltaNeutral.NotKeeper.selector);
        vault.rebalance();

        vm.prank(keeper);
        vault.rebalance();
        vm.prank(keeper);
        vm.expectRevert(); // NotSettled, then TooSoon
        vault.rebalance();
        sim.processBlock();
        vm.warp(block.timestamp + 6);
        vm.prank(keeper);
        vm.expectRevert(abi.encodeWithSelector(IDeltaNeutral.TooSoon.selector, block.timestamp + 54));
        vault.rebalance();
    }

    /**
     * A compromised keeper colludes with a market maker: every fill it triggers lands at the worst
     * edge of the band. What it can burn is bounded by the daily turnover cap, whatever it does.
     */
    function test_ACompromisedKeeperFillingAtTheBandEdgeIsBoundedByTurnover() public {
        IDeltaNeutral.Params memory p = _params();
        p.maxDailyTurnover = 250_000e6;
        vm.prank(gov);
        vault.setParams(p); // lowering a cap is instant
        _deposit(alice, 1_000_000e6);

        // Every fill lands exactly at its limit - buys 30 bps over the reference, sells 30 bps under -
        // as a keeper colluding with the only maker on the book would arrange.
        sim.setFillAtLimit(true);
        uint256 before = vault.totalAssets();
        bool exhausted;
        for (uint256 i; i < 80 && !exhausted; ++i) {
            vm.prank(keeper);
            try vault.rebalance() {}
            catch (bytes memory err) {
                exhausted = bytes4(err) == IDeltaNeutral.TurnoverExhausted.selector;
                assertTrue(exhausted, "the keeper is stopped by the budget, not by running out of work");
            }
            _tick();
        }
        assertTrue(exhausted);
        assertLe(vault.turnoverUsed(), 250_000e6, "turnover never exceeded");
        uint256 lost = before - vault.totalAssets();
        // Band (30 bps) plus the simulated taker fee (7 bps spot, 5 perp) on at most 250k, plus
        // Circle's 1 USDC account fee.
        assertLe(lost, (250_000e6 * 37) / 10_000 + 1e6, "loss within turnover x (band + fee)");
        emit log_named_uint("worst-case loss, USDC (1e6)", lost);
        emit log_named_uint("keeper turnover used, USDC (1e6)", vault.turnoverUsed());

        // A new window restores the budget - and the guardian can end it instantly instead.
        vm.prank(guardian);
        vault.pauseExposure();
    }

    /// A sell limit below the band never fills; the vault does not assume it did.
    function test_RejectedActionsAreNotAssumedToHaveHappened() public {
        _deposit(alice, 200_000e6);
        sim.setRejectEverything(true);
        for (uint256 i; i < 6; ++i) {
            vm.prank(keeper);
            try vault.rebalance() {} catch {}
            _tick();
        }
        assertEq(sim.szi(address(vault)), 0, "nothing happened on HyperCore");
        // The bridge deposit itself is not an action and did land, less Circle's 1 USDC fee for
        // creating the HyperCore account. Nothing else moved.
        assertEq(vault.totalAssets(), 200_000e6 - 1e6, "and the books say exactly that");
        sim.setRejectEverything(false);
        _rebalanceUntilDone(60);
        assertLt(sim.szi(address(vault)), 0, "the next keeper round recovers from reads alone");
    }

    /*//////////////////////////////////////////////////////////////
                                BREAKERS
    //////////////////////////////////////////////////////////////*/

    function test_TheFundingEstimateFollowsHyperliquidsFormula() public {
        // Book inside the oracle: premium 0, so hourly = 0.01% / 8 = 1250e-8. Sample often: stays.
        for (uint256 h; h < 10; ++h) {
            vm.warp(block.timestamp + 1 hours);
            vault.sampleFunding();
        }
        assertEq(vault.fundingEmaE8(), 1_250);
        // Perp bid 0.1% under the oracle for a long time: premium -0.1%, clamp adds 0.05%,
        // hourly = -0.05% / 8 = -6250e-8.
        sim.setBook((PX * 9_980) / 10_000, (PX * 9_990) / 10_000);
        for (uint256 h; h < 24 * 60; ++h) {
            vm.warp(block.timestamp + 1 hours);
            vault.sampleFunding();
        }
        assertApproxEqAbs(vault.fundingEmaE8(), -6_250, 5);
    }

    /// Sampling a manipulated book many times in a minute moves the estimate no more than once.
    function test_SpammingSamplesDoesNotAmplifyAManipulatedBook() public {
        sim.setBook((PX * 9_900) / 10_000, (PX * 9_950) / 10_000); // -0.5% for one minute
        for (uint256 i; i < 60; ++i) {
            vm.warp(block.timestamp + 1);
            vault.sampleFunding();
        }
        int256 spammed = vault.fundingEmaE8();
        assertGt(spammed, 1_200, "a minute of a broken book barely moves an 84-hour average");
    }

    function test_PersistentlyNegativeFundingStopsNewExposureThenUnwinds() public {
        _deploy(300_000e6);
        int64 deployed = sim.szi(address(vault));

        // Mildly negative for a week: below the pause floor, above the unwind floor.
        // Ask 5.5 bps under the oracle: premium -0.055%, clamp adds back 0.05%, hourly -0.00065%.
        sim.setBook(249_850, 249_862);
        for (uint256 h; h < 24 * 7; ++h) {
            vm.warp(block.timestamp + 1 hours);
            vault.sampleFunding();
        }
        assertLt(vault.fundingEmaE8(), 0);
        assertGt(vault.fundingEmaE8(), -1_141);
        _deposit(bob, 300_000e6);
        _rebalanceUntilDone(60);
        assertEq(sim.szi(address(vault)), deployed, "new deposits were not put at risk");

        // Deeply negative: unwind.
        sim.setBook((PX * 9_950) / 10_000, (PX * 9_960) / 10_000);
        for (uint256 h; h < 24 * 14; ++h) {
            vm.warp(block.timestamp + 1 hours);
            vault.sampleFunding();
        }
        assertLt(vault.fundingEmaE8(), -1_141);
        _rebalanceUntilDone(80);
        assertEq(sim.szi(address(vault)), 0, "short closed");
        assertLt(sim.spotOf(address(vault), sim.BASE_TOKEN()), 1e7, "spot sold (under 0.01 ETH left)");
    }

    function test_ADrawdownClosesDepositsAndNewExposure() public {
        _deploy(300_000e6);
        vault.checkpoint();
        sim.slash(address(vault), 20_000e6); // a 6.7% loss
        vault.checkpoint();
        assertTrue(vault.drawdownTripped());
        vm.prank(bob);
        vm.expectRevert(IDeltaNeutral.DepositsClosed.selector);
        vault.deposit(1e6, bob);

        vm.prank(gov);
        vault.resume();
        assertFalse(vault.drawdownTripped());
        _deposit(bob, 1_000e6);
    }

    /*//////////////////////////////////////////////////////////////
                         EXITS WITHOUT THE KEEPER
    //////////////////////////////////////////////////////////////*/

    /**
     * The keeper is gone for good. Alice exits anyway: she records a claim, anyone (here Alice
     * herself) walks the liquidity ladder with `processExits`, and the claim pays. Bob, who stays,
     * is not diluted beyond the exit fee's rounding.
     */
    function test_AFullExitWorksWithTheKeeperOffline() public {
        _deposit(bob, 100_000e6);
        _deploy(300_000e6);
        uint256 bobPrice = vault.assetsPerShare();

        uint256 shares = vault.balanceOf(alice);
        vm.prank(alice);
        (uint256 id, uint256 owed) = vault.requestRedeem(shares, alice);
        assertGt(id, 0, "more than the buffer: a claim");
        assertApproxEqRel(owed, (300_000e6 * 9_980) / 10_000, 0.004e18, "priced at NAV less the exit fee");

        uint256 steps;
        while (true) {
            try vault.claim(id) {
                break;
            } catch {}
            vm.prank(alice);
            try vault.processExits() {} catch {}
            _tick();
            require(++steps < 80, "exit did not complete");
        }
        assertEq(usdc.balanceOf(alice), 1_000_000e6 - 300_000e6 + owed, "paid in full");
        assertEq(vault.totalOwed(), 0);
        assertGe(vault.assetsPerShare() * 10_000, bobPrice * 9_990, "the holder who stayed kept his value");
        emit log_named_uint("processExits steps with the keeper offline", steps);
    }

    /// The keeper cannot put USDC owed to a claim back to work.
    function test_TheKeeperCannotRedeployUSDCOwedToAClaim() public {
        _deploy(300_000e6);
        uint256 shares = vault.balanceOf(alice);
        vm.prank(alice);
        (uint256 id,) = vault.requestRedeem(shares / 2, alice);
        assertGt(id, 0);
        int64 sizeBefore = sim.szi(address(vault));

        for (uint256 i; i < 30; ++i) {
            vm.prank(keeper);
            try vault.rebalance() {} catch {}
            _tick();
            try vault.claim(id) {
                break;
            } catch {}
        }
        assertEq(vault.totalOwed(), 0, "the keeper's own steps ended up funding the claim");
        assertGe(sim.szi(address(vault)), sizeBefore, "and never grew the short while it was owed");
    }

    /// A rally with the keeper offline: anyone can deleverage before the venue liquidates.
    function test_AnyoneCanDeleverageInARally() public {
        _deploy(300_000e6);
        vm.prank(stranger);
        vm.expectRevert(IDeltaNeutral.NothingToDo.selector);
        vault.deleverage();

        sim.setPrices((PX * 130) / 100, (SPOT_PX * 130) / 100); // +30%: leverage well past 3x
        int64 before = sim.szi(address(vault));
        vm.prank(stranger);
        vault.deleverage();
        _tick();
        assertGt(sim.szi(address(vault)), before, "short reduced by a stranger");
    }

    function test_NothingPricedRunsWhileActionsAreInFlight() public {
        _deposit(alice, 100_000e6);
        vm.prank(keeper);
        vault.rebalance(); // bridges USDC: it leaves the EVM balance now, lands on HyperCore later
        vm.prank(bob);
        vm.expectRevert(abi.encodeWithSelector(IDeltaNeutral.NotSettled.selector, block.timestamp + 5));
        vault.deposit(1_000e6, bob);
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(IDeltaNeutral.NotSettled.selector, block.timestamp + 5));
        vault.requestRedeem(1, alice);
    }

    /*//////////////////////////////////////////////////////////////
                               GOVERNANCE
    //////////////////////////////////////////////////////////////*/

    function test_RiskierParamsAndANewKeeperWaitSaferParamsDoNot() public {
        IDeltaNeutral.Params memory p = _params();
        p.maxOrderNotional = 100_000e6;
        vm.prank(gov);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, Vault.setParams.selector));
        vault.setParams(p);
        _afterDelay(address(vault), abi.encodeCall(Vault.setParams, (p)));
        assertEq(vault.getParams().maxOrderNotional, 100_000e6);

        p.slippageBps = 10; // tighter: instant
        p.maxOrderNotional = 10_000e6;
        vm.prank(gov);
        vault.setParams(p);

        vm.prank(gov);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, Vault.setKeeper.selector));
        vault.setKeeper(stranger);
    }

    function test_TheGuardianUnwindsAtOnceAndOnlyTheGovernorResumes() public {
        _deploy(300_000e6);
        vm.prank(stranger);
        vm.expectRevert(IDeltaNeutral.NotGuardianOrGovernor.selector);
        vault.pauseExposure();
        vm.prank(guardian);
        vault.pauseExposure();
        _rebalanceUntilDone(80);
        assertEq(sim.szi(address(vault)), 0, "unwound");
        vm.prank(guardian);
        vm.expectRevert(DelayedGovernance.NotGovernor.selector);
        vault.resume();
    }

    /// Only risk-reducing edits reach validation directly, so these are all "safer" and still refused.
    function test_NonsenseParamsAreRefused() public {
        IDeltaNeutral.Params memory p = _params();
        p.maxLeverageBps = 15_000; // below the 2x target
        vm.prank(gov);
        vm.expectRevert(IDeltaNeutral.BadParams.selector);
        vault.setParams(p);
        p = _params();
        p.slippageBps = 0; // a zero band never fills
        vm.prank(gov);
        vm.expectRevert(IDeltaNeutral.BadParams.selector);
        vault.setParams(p);
        p = _params();
        p.fundingUnwindE8 = 10; // unwinding above the pause floor
        vm.prank(gov);
        vm.expectRevert(IDeltaNeutral.BadParams.selector);
        vault.setParams(p);
    }

    function test_AMarketNotQuotedInUSDCIsRefused() public {
        sim.setSpotQuoteToken(150);
        vm.expectRevert(IDeltaNeutral.BadMarket.selector);
        new Vault(
            "x", "x", IERC20(address(usdc)), ICoreDepositWallet(address(cdw)), 1, 151, gov, guardian, keeper, DELAY,
            _params()
        );
    }
}
