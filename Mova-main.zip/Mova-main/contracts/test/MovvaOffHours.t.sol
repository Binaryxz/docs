// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Governed} from "./utils/Governed.sol";
import {MockPyth} from "./utils/MockPyth.sol";
import {TetherLike} from "./ERC4626Adapter.t.sol";
import {FxTestFeed} from "./ChainlinkSignedFxOracle.t.sol";
import {MockVerifier3} from "./RampErc20.t.sol";
import {PoolStub} from "./RampIntegration.t.sol";
import {PythFxOracle} from "../ramp/PythFxOracle.sol";
import {FiatEscrow} from "../ramp/FiatEscrow.sol";
import {OffRampEscrow} from "../ramp/OffRampEscrow.sol";
import {LPRegistry} from "../ramp/LPRegistry.sol";
import {IAttestorVerifier} from "../ramp/IAttestorVerifier.sol";
import {Movva} from "../movva/Movva.sol";
import {MovvaReserve} from "../movva/MovvaReserve.sol";

/**
 * Mova's off-hours rule on the real reserve and escrows (MovvaReserve, "Off-hours"). Pyth's USD/BRL
 * closes on Friday at 17:00 New York time. Over the weekend an LP still sells and buys back Movva by PIX,
 * checked against the closing price, while minting and redeeming wait for Monday and a fresh price.
 */
contract MovvaOffHoursTest is Governed {
    bytes32 constant USD_BRL = keccak256("FX.USD/BRL");
    /// Friday 18 September 2026, 20:00 UTC; Saturday 15:00 UTC; Monday 13:30 UTC (the core session opens).
    uint256 constant FRI_2000 = 1_789_761_600;
    uint256 constant SAT_1500 = 1_789_830_000;
    uint256 constant MON_1330 = 1_789_997_400;
    uint256 constant U = 1e6;
    uint16 constant PIX_MASK = uint16(1 << uint8(IAttestorVerifier.Rail.PIX));

    address gov = makeAddr("gov");
    address gateway = makeAddr("gateway");
    address seller = makeAddr("seller");

    MockPyth pyth;
    PythFxOracle fx;
    FxTestFeed usdtUsd;
    TetherLike usdt;
    MovvaReserve reserve;
    Movva movva;
    FiatEscrow onramp;
    OffRampEscrow offramp;
    MockVerifier3 verifier;

    function setUp() public {
        vm.warp(FRI_2000);
        pyth = new MockPyth(1);
        pyth.set(USD_BRL, 540_000, 50, -5, FRI_2000); // R$ 5,40: the last price before Friday's close
        fx = new PythFxOracle(address(pyth), USD_BRL, 1 hours, 4 days, 100, gov, DELAY);
        usdtUsd = new FxTestFeed(1e8, 8);
        usdt = new TetherLike();
        reserve = new MovvaReserve(
            MovvaReserve.Config({
                usdt: address(usdt),
                usdtUsdFeed: address(usdtUsd),
                fxOracle: address(fx),
                usdtUsdMaxAge: 25 hours,
                fxMaxAge: 1 hours,
                governor: gov,
                governanceDelay: DELAY,
                guardian: makeAddr("guardian"),
                treasurer: makeAddr("treasurer"),
                hedgeTreasury: makeAddr("hedge"),
                feeRecipient: makeAddr("fees"),
                supplyCap: 1_000_000e18,
                breaker: address(0),
                hedgeQueueDelay: 1 days
            })
        );
        movva = Movva(reserve.MOVVA());

        LPRegistry registry = new LPRegistry(gov, DELAY);
        PoolStub pool = new PoolStub();
        verifier = new MockVerifier3();
        onramp = new FiatEscrow(address(reserve), address(registry), address(pool), address(pool), 300, gov, DELAY, DISPUTE_TIMEOUT);
        offramp = new OffRampEscrow(address(reserve), address(registry), 300, gov, DELAY, DISPUTE_TIMEOUT);

        vm.startPrank(gov);
        fx.completeSetup();
        reserve.setGateway(gateway, true);
        reserve.completeSetup();
        registry.setEscrow(address(onramp), true);
        registry.setEscrow(address(offramp), true);
        registry.setTier(gateway, LPRegistry.Tier.INSTITUTIONAL, 100_000_000);
        registry.completeSetup();
        onramp.setAsset(address(movva), address(reserve), 18, true);
        offramp.setAsset(address(movva), address(reserve), 18, true);
        onramp.setVerifier(address(verifier), true);
        offramp.setVerifier(address(verifier), true);
        onramp.completeSetup();
        offramp.completeSetup();
        vm.stopPrank();

        usdt.mint(gateway, 10_000 * U);
        vm.startPrank(gateway);
        usdt.approve(address(reserve), type(uint256).max);
        movva.approve(address(reserve), type(uint256).max);
        movva.approve(address(onramp), type(uint256).max);
        reserve.mint(1_000 * U, gateway, 0); // before the close: 5.400 Movva
        vm.stopPrank();
    }

    function test_OverTheWeekendLpsTradeMovvaButNobodyMintsOrRedeems() public {
        vm.warp(SAT_1500);
        usdtUsd.set(1e8, SAT_1500);
        bytes memory stale = abi.encodeWithSelector(PythFxOracle.StaleRate.selector, FRI_2000);

        // Value creation waits for the market.
        vm.startPrank(gateway);
        vm.expectRevert(stale);
        reserve.mint(100 * U, gateway, 0);
        vm.expectRevert(stale);
        reserve.redeem(100e18, gateway, 0);
        vm.stopPrank();
        vm.expectRevert(stale);
        reserve.collateralRatioBps();

        // The band does not: par from Friday's close, stamped now.
        (uint256 mid, uint64 at) = reserve.brlCentsPerUnit();
        assertEq(mid, 100);
        assertEq(at, SAT_1500);
        (uint256 rate,) = reserve.bandBrlPerUsdtE18();
        assertEq(rate, 5.4e18);

        // So a PIX offer of Movva the LP already holds posts, and a holder's sale inside the band opens.
        vm.startPrank(gateway);
        onramp.postOffer(address(movva), 1_000e18, 101, keccak256("lp@pix"), 1e18, 1_000e18, address(verifier), PIX_MASK);
        movva.transfer(seller, 100e18);
        vm.stopPrank();
        vm.startPrank(seller);
        movva.approve(address(offramp), type(uint256).max);
        offramp.openSale(address(movva), 100e18, 9_900, keccak256("seller@pix"), address(verifier), PIX_MASK, seller);
        vm.stopPrank();
    }

    function test_MondaysCoreSessionWantsAFreshPriceForTheBandToo() public {
        vm.warp(MON_1330);
        usdtUsd.set(1e8, MON_1330);
        vm.expectRevert(abi.encodeWithSelector(PythFxOracle.StaleRate.selector, FRI_2000));
        reserve.brlCentsPerUnit();

        // The keeper posts the opening price: everything prices again, and minting resumes.
        bytes[] memory u = new bytes[](1);
        u[0] = pyth.updateData(USD_BRL, 541_000, 50, -5, MON_1330);
        pyth.updatePriceFeeds{value: 1}(u);
        (uint256 mid,) = reserve.brlCentsPerUnit();
        assertEq(mid, 100);
        vm.prank(gateway);
        assertGt(reserve.mint(100 * U, gateway, 0), 0);
    }
}
