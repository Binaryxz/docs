// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import {RulingLib} from "../ramp/RulingLib.sol";

/// Exposes the library so a test can call it externally and observe reverts.
contract RulingHarness {
    function recover(RulingLib.Ruling calldata r, address escrow, bytes calldata sig)
        external
        view
        returns (address)
    {
        return RulingLib.recover(r, escrow, sig);
    }

    function isRelease(RulingLib.Ruling calldata r) external pure returns (bool) {
        return RulingLib.isRelease(r);
    }

    function digest(RulingLib.Ruling calldata r, address escrow) external view returns (bytes32) {
        return RulingLib.digest(r, escrow);
    }
}

/**
 * Cross-language check for the ruling encoding.
 *
 * The signature below was produced by the REAL TypeScript client
 * (packages/ramp/src/disputes.ts, `Arbitrator.rule`), not by this test. Two hand-written
 * EIP-712 encoders agreeing with each other is the thing that has to be proven, and it
 * cannot be proven by a test that writes both sides. If either encoder drifts - a field
 * reordered, a string hashed differently, the domain renamed - this recovers a different
 * address and fails, which is exactly when it should.
 */
contract RulingLibTest is Test {
    RulingHarness h;

    address constant ESCROW = 0x00000000000000000000000000000000000000E5;
    address constant TS_ARBITRATOR = 0x1a642f0E3c3aF545E7AcBD38b07251B3990914F1;
    bytes constant TS_SIGNATURE =
        hex"e0a35a80d0b3b1f7a8c74916243527689036352edb49e9c95ff43aa44cc42c1b5a7ee635687304f3bad5240bd0d07d723762eb27efdf89e496a8b303411c763e1c";

    function setUp() public {
        h = new RulingHarness();
        vm.chainId(31337); // the chain id the fixture was signed for
    }

    function _fixture() internal pure returns (RulingLib.Ruling memory) {
        return RulingLib.Ruling({
            orderId: bytes32(0xa1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1),
            outcome: "RELEASE",
            evidenceRoot: 0x7dca6297c37e0d18e02a1e531367a203324f9484bb088a6ad16b74d8f41544d4,
            rationale: "receipt matches",
            ruledAt: 1_700_000_000,
            byDefault: false
        });
    }

    function test_SolidityRecoversTheTypeScriptSigner() public view {
        assertEq(
            h.recover(_fixture(), ESCROW, TS_SIGNATURE),
            TS_ARBITRATOR,
            "the two EIP-712 encoders agree"
        );
    }

    function test_ChangingAnyFieldChangesTheSigner() public view {
        RulingLib.Ruling memory r = _fixture();
        r.outcome = "REFUND";
        assertTrue(h.recover(r, ESCROW, TS_SIGNATURE) != TS_ARBITRATOR);

        r = _fixture();
        r.evidenceRoot = keccak256("something else");
        assertTrue(h.recover(r, ESCROW, TS_SIGNATURE) != TS_ARBITRATOR);

        r = _fixture();
        r.rationale = "different words";
        assertTrue(h.recover(r, ESCROW, TS_SIGNATURE) != TS_ARBITRATOR);
    }

    /// The domain binds the ruling to one escrow, so it cannot be replayed at another.
    function test_TheSameRulingDoesNotVerifyAtAnotherEscrow() public view {
        assertTrue(h.recover(_fixture(), address(0xBEEF), TS_SIGNATURE) != TS_ARBITRATOR);
    }

    function test_OutcomeIsNeverGuessed() public {
        RulingLib.Ruling memory r = _fixture();
        assertTrue(h.isRelease(r));
        r.outcome = "REFUND";
        assertFalse(h.isRelease(r));
        r.outcome = "release"; // case matters; no fuzzy matching
        vm.expectRevert(RulingLib.BadOutcome.selector);
        h.isRelease(r);
    }

    function test_MalleatedSignatureIsRejected() public {
        uint256 N = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141;
        bytes memory sig = TS_SIGNATURE;
        bytes32 s;
        assembly {
            s := mload(add(sig, 64))
        }
        bytes32 r;
        assembly {
            r := mload(add(sig, 32))
        }
        uint8 v = uint8(sig[64]) == 27 ? 28 : 27;
        bytes memory flipped = abi.encodePacked(r, bytes32(N - uint256(s)), v);
        vm.expectRevert(RulingLib.MalformedSignature.selector);
        h.recover(_fixture(), ESCROW, flipped);
    }
}
