// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {MovvaBase} from "./MovvaReserve.t.sol";
import {TetherLike} from "./ERC4626Adapter.t.sol";
import {FxTestFeed} from "./ChainlinkSignedFxOracle.t.sol";
import {Governed} from "./utils/Governed.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {MovvaReserve} from "../movva/MovvaReserve.sol";
import {DivergenceBreaker} from "../movva/DivergenceBreaker.sol";
import {IPriceSource} from "../movva/IPriceSource.sol";
import {UniswapV3TwapSource} from "../movva/sources/UniswapV3TwapSource.sol";
import {ChainlinkCrossSource} from "../movva/sources/ChainlinkCrossSource.sol";
import {LimitedYieldVault} from "../yield/LimitedYieldVault.sol";

/// A source the test sets directly, including to revert.
contract MockPriceSource is IPriceSource {
    uint256 public rate;
    bool public down;

    function set(uint256 r) external {
        rate = r;
        down = false;
    }

    function fail() external {
        down = true;
    }

    function brlPerUsdtE18() external view returns (uint256) {
        require(!down, "source down");
        return rate;
    }
}

/// Just enough of a Uniswap v3 pool: a settable mean tick and liquidity.
contract MockPool {
    address public token0;
    address public token1;
    uint128 public liquidity = 1e18;
    int56 public meanTick;
    bool public shortHistory;

    constructor(address t0, address t1) {
        (token0, token1) = (t0, t1);
    }

    function setTick(int56 t) external {
        meanTick = t;
    }

    function setLiquidity(uint128 l) external {
        liquidity = l;
    }

    function setShort(bool s) external {
        shortHistory = s;
    }

    function observe(uint32[] calldata ago) external view returns (int56[] memory c, uint160[] memory s) {
        require(!shortHistory, "OLD");
        c = new int56[](2);
        s = new uint160[](2);
        c[0] = 0;
        c[1] = meanTick * int56(uint56(ago[0]));
    }
}

contract Dec {
    uint8 public decimals;

    constructor(uint8 d) {
        decimals = d;
    }
}

/// The reserve with a breaker over two mock sources, band 3%, halting redeem too.
contract BreakerTest is MovvaBase {
    MockPriceSource a;
    MockPriceSource b;
    DivergenceBreaker brk;

    function _config() internal view override returns (MovvaReserve.Config memory c) {
        c = super._config();
        c.breaker = address(brkAddr);
    }

    address brkAddr;

    function setUp() public virtual override {
        // The breaker must exist before the reserve is built in the base setUp.
        a = new MockPriceSource();
        b = new MockPriceSource();
        a.set(FX * 1e12);
        b.set(FX * 1e12);
        DivergenceBreaker.SourceConfig[] memory cfg = new DivergenceBreaker.SourceConfig[](2);
        cfg[0] = DivergenceBreaker.SourceConfig(a, true);
        cfg[1] = DivergenceBreaker.SourceConfig(b, true);
        brk = new DivergenceBreaker(300, true, cfg);
        brkAddr = address(brk);
        super.setUp();
        // The mocks must read like the live legs after the base warps.
        _sync();
    }

    function _sync() internal {
        a.set(_rate());
        b.set(_rate());
    }

    function test_InBandMintAndRedeemWork() public {
        uint256 got = _mint(1_000 * U);
        assertGt(got, 0);
        assertFalse(reserve.breakerTripped());
        _redeem(got / 2);
    }

    function test_DivergenceHaltsMintRedeemAndHedge() public {
        _mint(1_000_000 * U);
        vm.prank(gateway);
        reserve.recapitalize(80_000 * U);
        b.set(_rate() * 110 / 100); // 10% apart
        assertTrue(reserve.breakerTripped());
        vm.startPrank(gateway);
        vm.expectRevert(abi.encodeWithSelector(DivergenceBreaker.SourcesDiverge.selector, _rate(), _rate() * 110 / 100, 300));
        reserve.mint(1 * U, gateway, 0);
        vm.expectRevert();
        reserve.redeem(1e18, gateway, 0);
        vm.stopPrank();
        vm.prank(treasurer);
        vm.expectRevert();
        reserve.withdrawToHedge(1 * U);
        // What it does not stop: adding backing.
        vm.prank(gateway);
        reserve.recapitalize(1 * U);
    }

    function test_ClearsItselfWhenBackInBand_NoCallNeeded() public {
        _mint(10_000 * U);
        b.set(_rate() * 120 / 100);
        vm.prank(gateway);
        vm.expectRevert();
        reserve.mint(1 * U, gateway, 0);
        b.set(_rate() * 102 / 100); // inside 3%
        assertFalse(reserve.breakerTripped());
        _mint(1 * U);
        _redeem(1e18);
    }

    function test_ASourceThatRevertsHaltsRatherThanBeingDropped() public {
        a.fail();
        assertTrue(reserve.breakerTripped());
        vm.prank(gateway);
        vm.expectRevert(abi.encodeWithSelector(DivergenceBreaker.SourceUnavailable.selector, 0));
        reserve.mint(1 * U, gateway, 0);
        a.set(_rate());
        assertFalse(reserve.breakerTripped());
    }

    function test_AZeroSourceHalts() public {
        a.set(0);
        assertTrue(reserve.breakerTripped());
    }

    function test_ABandOfExactlyTheBandPasses() public {
        b.set(_rate() * 10_300 / 10_000);
        assertFalse(reserve.breakerTripped());
        b.set(_rate() * 10_300 / 10_000 + 1e12);
        assertTrue(reserve.breakerTripped());
    }

    /// The breaker has no state: for any pair of source answers the verdict equals the pure spread rule,
    /// and a trip followed by a return to band is never remembered.
    function testFuzz_NeverLatches(uint256 ra, uint256 rb, bool downA, bool downB) public {
        ra = bound(ra, 1e18, 20e18);
        rb = bound(rb, 1e18, 20e18);
        uint256 p = _rate();
        a.set(ra);
        b.set(rb);
        if (downA) a.fail();
        if (downB) b.fail();
        bool expectOk = !downA && !downB;
        if (expectOk) {
            uint256 lo = _min(_min(p, ra), rb);
            uint256 hi = _max(_max(p, ra), rb);
            expectOk = (hi - lo) * 10_000 <= lo * 300;
        }
        assertEq(brk.inBand(p), expectOk, "verdict is the sources' present state");
        assertEq(reserve.breakerTripped(), !expectOk);
        // Return to band: it clears with no call, whatever came before.
        _sync();
        assertFalse(reserve.breakerTripped());
        _mint(1 * U);
    }

    function _min(uint256 x, uint256 y) internal pure returns (uint256) {
        return x < y ? x : y;
    }

    function _max(uint256 x, uint256 y) internal pure returns (uint256) {
        return x > y ? x : y;
    }

    function test_NonTrippingSourceCannotHalt() public {
        DivergenceBreaker.SourceConfig[] memory cfg = new DivergenceBreaker.SourceConfig[](2);
        cfg[0] = DivergenceBreaker.SourceConfig(a, true);
        cfg[1] = DivergenceBreaker.SourceConfig(b, false);
        DivergenceBreaker soft = new DivergenceBreaker(300, true, cfg);
        b.set(_rate() * 3);
        assertTrue(soft.inBand(_rate()));
        b.fail();
        soft.check(_rate());
        assertEq(soft.sourceRates()[1], 0);
    }

    function test_HaltsRedeemFalseKeepsExitsOpen() public {
        DivergenceBreaker.SourceConfig[] memory cfg = new DivergenceBreaker.SourceConfig[](1);
        cfg[0] = DivergenceBreaker.SourceConfig(a, true);
        DivergenceBreaker open = new DivergenceBreaker(300, false, cfg);
        uint256 p = _rate();
        a.set(p * 2);
        vm.expectRevert();
        open.check(p);
        open.checkRedeem(p);
    }

    function test_ConstructorRefusals() public {
        DivergenceBreaker.SourceConfig[] memory none = new DivergenceBreaker.SourceConfig[](0);
        vm.expectRevert(DivergenceBreaker.BadSources.selector);
        new DivergenceBreaker(300, true, none);
        DivergenceBreaker.SourceConfig[] memory one = new DivergenceBreaker.SourceConfig[](1);
        one[0] = DivergenceBreaker.SourceConfig(a, true);
        vm.expectRevert(DivergenceBreaker.BadBand.selector);
        new DivergenceBreaker(0, true, one);
        vm.expectRevert(DivergenceBreaker.BadBand.selector);
        new DivergenceBreaker(10_000, true, one);
    }

    function test_BandOracleIsNotHalted() public view {
        // brlCentsPerUnit is a sanity band for the ramps and is left as it was.
        reserve.brlCentsPerUnit();
    }

    /*//////////////////////////////////////////////////////////////
                            HEDGE TIMELOCK
    //////////////////////////////////////////////////////////////*/

    function _seed() internal {
        _mint(1_000_000 * U);
        vm.prank(gateway);
        reserve.recapitalize(80_000 * U);
        _publishFx(5_940_000); // ratio 118.8%
        _sync();
    }

    function test_AboveTheLimitWaitsThenAnyoneExecutesExactlyOnce() public {
        _seed();
        uint256 limit = reserve.hedgeWithdrawable();
        uint256 want = limit + 10_000 * U;
        vm.prank(treasurer);
        vm.expectRevert();
        reserve.withdrawToHedge(want); // the instant lane refuses
        vm.prank(treasurer);
        uint256 id = reserve.queueHedgeWithdrawal(want);
        vm.expectRevert();
        reserve.executeHedgeWithdrawal(id); // too early
        _warp(1 days);
        _sync();
        uint256 before = usdt.balanceOf(hedge);
        vm.prank(stranger);
        reserve.executeHedgeWithdrawal(id);
        assertEq(usdt.balanceOf(hedge) - before, want, "exactly the queued amount, to the queued recipient");
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.HedgeRequestDone.selector, id));
        reserve.executeHedgeWithdrawal(id);
    }

    function test_OnlyTheTreasurerQueues_NobodyCancels() public {
        _seed();
        vm.prank(stranger);
        vm.expectRevert(MovvaReserve.NotTreasurer.selector);
        reserve.queueHedgeWithdrawal(1 * U);
        // There is no cancel: the ABI has no such selector.
        (bool ok,) = address(reserve).call(abi.encodeWithSignature("cancelHedgeWithdrawal(uint256)", 0));
        assertFalse(ok);
    }

    function test_ChangingTheHedgeTreasuryCannotRedirectAQueuedRequest() public {
        _seed();
        uint256 amt = reserve.hedgeWithdrawable() + 5_000 * U;
        vm.prank(treasurer);
        uint256 id = reserve.queueHedgeWithdrawal(amt);
        address thief = makeAddr("thief");
        _afterDelay(address(reserve), abi.encodeCall(MovvaReserve.setHedgeTreasury, (thief)));
        _warp(0);
        _sync();
        uint256 h = usdt.balanceOf(hedge);
        reserve.executeHedgeWithdrawal(id);
        assertGt(usdt.balanceOf(hedge), h, "paid the recipient fixed at queue time");
        assertEq(usdt.balanceOf(thief), 0);
    }

    function test_TheFloorStillBindsAtExecution() public {
        _seed();
        uint256 amt = reserve.hedgeWithdrawable() + 5_000 * U;
        vm.prank(treasurer);
        uint256 id = reserve.queueHedgeWithdrawal(amt);
        _warp(1 days);
        _publishFx(5_000_000); // the real strengthens: the ratio drops, the floor bites
        _sync();
        vm.expectRevert();
        reserve.executeHedgeWithdrawal(id);
        (,, bool done,) = reserve.hedgeRequests(id);
        assertFalse(done, "still queued, not lost");
    }

    function test_QueueRefusedBelowTheFloorUpFront() public {
        _seed();
        vm.prank(treasurer);
        vm.expectRevert();
        reserve.queueHedgeWithdrawal(10_000_000 * U);
    }

    function test_ExecutionRespectsTheBreaker() public {
        _seed();
        uint256 amt = reserve.hedgeWithdrawable() + 5_000 * U;
        vm.prank(treasurer);
        uint256 id = reserve.queueHedgeWithdrawal(amt);
        _warp(1 days);
        _sync();
        b.set(_rate() * 2);
        vm.expectRevert();
        reserve.executeHedgeWithdrawal(id);
        b.set(_rate());
        reserve.executeHedgeWithdrawal(id);
    }

    function test_UnknownRequest() public {
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.UnknownHedgeRequest.selector, 7));
        reserve.executeHedgeWithdrawal(7);
    }

    /// Fuzz: whatever is queued pays exactly that, once, to the recipient of record.
    function testFuzz_QueuedPaysExactlyOnce(uint256 extra, uint256 delaySlack) public {
        _seed();
        extra = bound(extra, 1 * U, 20_000 * U);
        delaySlack = bound(delaySlack, 0, 30 days);
        uint256 amt = reserve.hedgeWithdrawable() + extra;
        vm.prank(treasurer);
        uint256 id = reserve.queueHedgeWithdrawal(amt);
        _warp(1 days + delaySlack);
        _sync();
        uint256 h = usdt.balanceOf(hedge);
        reserve.executeHedgeWithdrawal(id);
        assertEq(usdt.balanceOf(hedge) - h, amt);
        vm.expectRevert();
        reserve.executeHedgeWithdrawal(id);
        assertEq(usdt.balanceOf(hedge) - h, amt, "no second payment");
    }
}

/// The TWAP and Chainlink-cross sources.
contract SourcesTest is Governed {
    Dec usdtT;
    Dec brz;

    function setUp() public {
        usdtT = new Dec(6);
        brz = new Dec(18);
    }

    /// token0 = USDT (6), token1 = BRZ (18): BRL raw per USDT raw = 5.4e12 -> tick ~ ln(5.4e12)/ln(1.0001).
    function test_TwapRateUsdtIsToken0() public {
        MockPool pool = new MockPool(address(usdtT), address(brz));
        // ln(5.4e12) / ln(1.0001) = 29.2236.../0.000099995 ~= 293_189
        pool.setTick(293_189);
        UniswapV3TwapSource s = new UniswapV3TwapSource(address(pool), address(usdtT), address(brz), 1800, 1);
        uint256 r = s.brlPerUsdtE18();
        assertApproxEqRel(r, 5.4e18, 0.001e18);
    }

    function test_TwapRateUsdtIsToken1() public {
        // token0 = BRZ, token1 = USDT: the tick is the negative of the other.
        Dec lowBrz = new Dec(18);
        (address t0, address t1) = address(lowBrz) < address(usdtT) ? (address(lowBrz), address(usdtT)) : (address(usdtT), address(lowBrz));
        MockPool pool = new MockPool(t0, t1);
        bool usdtIs0 = t0 == address(usdtT);
        pool.setTick(usdtIs0 ? int56(293_189) : int56(-293_189));
        UniswapV3TwapSource s = new UniswapV3TwapSource(address(pool), address(usdtT), address(lowBrz), 1800, 1);
        assertApproxEqRel(s.brlPerUsdtE18(), 5.4e18, 0.001e18);
    }

    function test_TwapRevertsWhenThinOrShort() public {
        MockPool pool = new MockPool(address(usdtT), address(brz));
        pool.setTick(293_189);
        UniswapV3TwapSource s = new UniswapV3TwapSource(address(pool), address(usdtT), address(brz), 1800, 1e12);
        pool.setLiquidity(1e11);
        vm.expectRevert();
        s.brlPerUsdtE18();
        pool.setLiquidity(1e13);
        s.brlPerUsdtE18();
        pool.setShort(true);
        vm.expectRevert();
        s.brlPerUsdtE18();
    }

    function test_TwapNegativeTickRoundsDown() public {
        MockPool pool = new MockPool(address(usdtT), address(brz));
        pool.setTick(-100);
        UniswapV3TwapSource s = new UniswapV3TwapSource(address(pool), address(usdtT), address(brz), 60, 1);
        // a tiny rate, but a valid nonzero reading at 1e-12 scale
        s.brlPerUsdtE18();
    }

    function test_ChainlinkCross() public {
        vm.warp(1_800_000_000);
        FxTestFeed u = new FxTestFeed(1e8, 8); // $1
        FxTestFeed br = new FxTestFeed(18_518_518, 8); // $0.18518518 per real
        ChainlinkCrossSource s = new ChainlinkCrossSource(address(u), address(br), 25 hours, 25 hours);
        assertApproxEqRel(s.brlPerUsdtE18(), 5.4e18, 1e12);
        vm.warp(block.timestamp + 26 hours);
        vm.expectRevert();
        s.brlPerUsdtE18();
    }
}

/// LimitedYieldVault: the per-owner daily limit and the timelock above it.
contract LimitedYieldVaultTest is Governed {
    TetherLike usdt;
    LimitedYieldVault vault;
    address gov = makeAddr("gov");
    address alice = makeAddr("alice");
    address bob = makeAddr("bob");
    address carol = makeAddr("carol");
    uint256 constant U = 1e6;

    function setUp() public {
        vm.warp(1_800_000_000);
        usdt = new TetherLike();
        vault = new LimitedYieldVault(
            IERC20(address(usdt)), "v", "v", gov, makeAddr("g"), makeAddr("k"), 1e15, 100, DELAY, 1_000, 1 days
        );
        vm.prank(gov);
        vault.completeSetup();
        usdt.mint(alice, 1_000_000 * U);
        usdt.mint(bob, 9_000_000 * U);
        vm.startPrank(alice);
        usdt.approve(address(vault), type(uint256).max);
        vault.deposit(1_000_000 * U, alice);
        vm.stopPrank();
        vm.startPrank(bob);
        usdt.approve(address(vault), type(uint256).max);
        vault.deposit(9_000_000 * U, bob);
        vm.stopPrank();
    }

    function test_InstantWithinTheLimit() public {
        // 10% of 10,000,000 = 1,000,000
        assertEq(vault.instantRoom(alice), 1_000_000 * U);
        vm.prank(alice);
        vault.withdraw(400_000 * U, alice, alice);
        assertEq(usdt.balanceOf(alice), 400_000 * U);
    }

    function test_AboveTheLimitRevertsInstantly() public {
        vm.prank(bob);
        vm.expectRevert();
        vault.withdraw(2_000_000 * U, bob, bob);
    }

    function test_SlowLaneExecutesOnceForExactlyTheSharesToTheReceiver() public {
        uint256 shares = vault.balanceOf(bob);
        vm.prank(bob);
        uint256 id = vault.requestRedeem(shares, carol, bob);
        assertEq(vault.balanceOf(bob), 0);
        vm.expectRevert();
        vault.executeRedeem(id);
        vm.warp(block.timestamp + 1 days);
        uint256 supplyBefore = vault.totalSupply();
        vm.prank(makeAddr("anyone"));
        uint256 paid = vault.executeRedeem(id);
        assertEq(usdt.balanceOf(carol), paid);
        assertApproxEqAbs(paid, 9_000_000 * U, 2);
        assertEq(supplyBefore - vault.totalSupply(), shares, "burned exactly the queued shares");
        vm.expectRevert(abi.encodeWithSelector(LimitedYieldVault.RequestDone.selector, id));
        vault.executeRedeem(id);
    }

    function test_NobodyCancels() public {
        vm.prank(bob);
        vault.requestRedeem(1e12, bob, bob);
        (bool ok,) = address(vault).call(abi.encodeWithSignature("cancelRedeem(uint256)", 0));
        assertFalse(ok);
    }

    function test_RequestNeedsAllowanceFromOthers() public {
        vm.prank(carol);
        vm.expectRevert();
        vault.requestRedeem(1e12, carol, bob);
        vm.prank(bob);
        vault.approve(carol, 1e12);
        vm.prank(carol);
        vault.requestRedeem(1e12, carol, bob);
    }

    function test_BucketRefillsOverADay() public {
        vm.prank(alice);
        vault.withdraw(500_000 * U, alice, alice);
        assertEq(vault.instantRoom(alice), vault.totalAssets() / 10 - 500_000 * U);
        vm.warp(block.timestamp + 12 hours);
        // the limit shrank with total assets; room is at most the limit
        assertLe(vault.instantRoom(alice), vault.totalAssets() / 10);
        vm.warp(block.timestamp + 12 hours);
        assertEq(vault.instantRoom(alice), vault.totalAssets() / 10);
    }

    function testFuzz_ASlowRequestPaysItsSharesOnceToItsReceiver(uint256 shares, uint256 wait) public {
        shares = bound(shares, 1e6, vault.balanceOf(bob));
        wait = bound(wait, 1 days, 400 days);
        vm.prank(bob);
        uint256 id = vault.requestRedeem(shares, carol, bob);
        uint256 expect = vault.previewRedeem(shares);
        vm.warp(block.timestamp + wait);
        uint256 supply = vault.totalSupply();
        uint256 got = vault.executeRedeem(id);
        assertEq(got, expect);
        assertEq(usdt.balanceOf(carol), got);
        assertEq(supply - vault.totalSupply(), shares);
        vm.expectRevert();
        vault.executeRedeem(id);
        assertEq(usdt.balanceOf(carol), got);
    }
}

import {Test} from "forge-std/Test.sol";

/// Random queueing, executing and waiting. Every execution is checked against the request of record.
contract HedgeQueueHandler is Test {
    MovvaReserve reserve;
    TetherLike usdt;
    address treasurer;
    address hedge;
    uint256 public paid;
    uint256 public violations;
    mapping(uint256 => uint256) public amountOf;
    mapping(uint256 => bool) public executedOnce;
    uint256 public n;

    constructor(MovvaReserve r, TetherLike u, address t, address h) {
        (reserve, usdt, treasurer, hedge) = (r, u, t, h);
    }

    function queue(uint256 amt) external {
        amt = bound(amt, 1 * 1e6, 40_000 * 1e6);
        vm.prank(treasurer);
        try reserve.queueHedgeWithdrawal(amt) returns (uint256 id) {
            amountOf[id] = amt;
            n = id + 1;
        } catch {}
    }

    function execute(uint256 id, address who) external {
        if (n == 0) return;
        id = bound(id, 0, n - 1);
        uint256 before = usdt.balanceOf(hedge);
        vm.prank(who);
        try reserve.executeHedgeWithdrawal(id) {
            uint256 got = usdt.balanceOf(hedge) - before;
            if (got != amountOf[id] || executedOnce[id]) violations++;
            executedOnce[id] = true;
            paid += got;
        } catch {
            if (usdt.balanceOf(hedge) != before) violations++;
        }
    }
}

contract HedgeQueueInvariantTest is BreakerTest {
    HedgeQueueHandler h;

    function setUp() public override {
        super.setUp();
        _mint(1_000_000 * U);
        vm.prank(gateway);
        reserve.recapitalize(80_000 * U);
        _publishFx(5_940_000);
        _sync();
        h = new HedgeQueueHandler(reserve, usdt, treasurer, hedge);
        targetContract(address(h));
        // The clock moves with the feeds re-published, as a live deployment keeps them.
        targetContract(address(this));
        bytes4[] memory sel = new bytes4[](1);
        sel[0] = this.handlerWait.selector;
        targetSelector(FuzzSelector({addr: address(this), selectors: sel}));
    }

    function handlerWait(uint256 dt) external {
        _warp(bound(dt, 0, 12 hours));
        _sync();
    }

    /// forge-config: default.invariant.runs = 32
    /// forge-config: default.invariant.depth = 100
    function invariant_QueuedWithdrawalsPayExactlyOnceExactlyToTheRecipientOfRecord() public view {
        assertEq(h.violations(), 0);
        assertEq(usdt.balanceOf(hedge), h.paid(), "the hedge account received only executed requests");
        for (uint256 i; i < h.n(); ++i) {
            (address to,, bool done, uint256 amt) = reserve.hedgeRequests(i);
            assertEq(to, hedge);
            assertEq(amt, h.amountOf(i), "a request's amount never changes");
            assertEq(done, h.executedOnce(i));
        }
    }
}
