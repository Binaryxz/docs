// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {ReclaimZkTlsVerifier} from "../ramp/ReclaimZkTlsVerifier.sol";
import {IAttestorVerifier} from "../ramp/IAttestorVerifier.sol";
import {ReclaimProofBuilder} from "./utils/ReclaimProofBuilder.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";

contract ReclaimZkTlsVerifierTest is ReclaimProofBuilder {
    ReclaimZkTlsVerifier v;

    uint256 w1 = 0x11;
    uint256 w2 = 0x2;
    uint256 w3 = 0x3;
    uint256 wEvil = 0xBAD;
    address governor = address(0x60F);

    bytes32 constant ORDER = bytes32(uint256(0xA11CE));
    bytes32 constant BANK_TX = bytes32(uint256(0xE2E1));
    bytes32 constant PAYEE = keccak256("seller@pix");

    function setUp() public {
        address[] memory set = new address[](3);
        set[0] = vm.addr(w1);
        set[1] = vm.addr(w2);
        set[2] = vm.addr(w3);
        v = new ReclaimZkTlsVerifier(governor, DELAY, set, 2, _one(BANK_TEMPLATE), _oneString(BANK_PREFIX));
        _completeSetup(address(v));
    }

    function _two() internal view returns (uint256[] memory k) {
        k = new uint256[](2);
        k[0] = w1;
        k[1] = w2;
    }

    function _fields(uint256 cents) internal pure returns (Fields memory) {
        return Fields({
            orderId: ORDER,
            bankTxId: BANK_TX,
            payeeKeyHash: PAYEE,
            payerRef: keccak256("payer"),
            amountBrlCents: cents,
            paidAt: 1_700_000_000,
            rail: 1
        });
    }

    function _genuine() internal view returns (ReclaimZkTlsVerifier.Proof memory) {
        return _proof(_params(BANK_URL), _context(_fields(1_500_000), BANK_TEMPLATE), _two());
    }

    /// A proof whose parameters are `params` and whose context is otherwise genuine.
    function _withParams(string memory params) internal view returns (bytes memory) {
        return abi.encode(_proof(params, _context(_fields(1_500_000), BANK_TEMPLATE), _two()));
    }

    function _withContext(string memory ctx) internal view returns (bytes memory) {
        return abi.encode(_proof(_params(BANK_URL), ctx, _two()));
    }

    /*//////////////////////////////////////////////////////////////
                           THE GENUINE PROOF
    //////////////////////////////////////////////////////////////*/

    function test_VerifiesAGenuineProofAndReadsTheFields() public view {
        IAttestorVerifier.Payment memory p = v.verifyPayment(ORDER, abi.encode(_genuine()));
        assertEq(p.bankTxId, BANK_TX);
        assertEq(p.payeeKeyHash, PAYEE);
        assertEq(p.payerRef, keccak256("payer"));
        assertEq(p.amountBrlCents, 1_500_000);
        assertEq(p.paidAt, 1_700_000_000);
        assertEq(uint8(p.rail), uint8(IAttestorVerifier.Rail.PIX));
    }

    /// Reclaim witnesses personal-sign the serialised claim STRING. The previous verifier
    /// expected a signature over its keccak, which no real witness produces.
    function test_ASignatureOverTheHashOfTheClaimIsNotAWitnessSignature() public {
        ReclaimZkTlsVerifier.Proof memory p = _genuine();
        bytes memory ser = abi.encodePacked(
            _hex32(p.signedClaim.claim.identifier), "\n", _hexAddr(p.signedClaim.claim.owner),
            "\n", vm.toString(uint256(p.signedClaim.claim.timestampS)), "\n",
            vm.toString(uint256(p.signedClaim.claim.epoch))
        );
        bytes32 oldDigest =
            keccak256(abi.encodePacked("\x19Ethereum Signed Message:\n32", keccak256(ser)));
        (uint8 v1, bytes32 r1, bytes32 s1) = vm.sign(w1, oldDigest);
        (uint8 v2, bytes32 r2, bytes32 s2) = vm.sign(w2, oldDigest);
        p.signedClaim.signatures = new bytes[](2);
        p.signedClaim.signatures[0] = abi.encodePacked(r1, s1, v1);
        p.signedClaim.signatures[1] = abi.encodePacked(r2, s2, v2);
        vm.expectRevert(); // recovers some other address: UnknownWitness
        v.verifyPayment(ORDER, abi.encode(p));
    }

    /*//////////////////////////////////////////////////////////////
                      WHICH SERVER WAS THE SESSION WITH
    //////////////////////////////////////////////////////////////*/

    /**
     * The attack this file exists for. Every real Reclaim HTTP claim has provider "http",
     * so checking the provider string admitted a session with ANY server. The attacker runs
     * their own server, has the witnesses observe a session returning the payment fields
     * they want, and presents it. The witness honestly records a different template hash.
     */
    function test_ASessionWithTheAttackersOwnServerIsRefused() public {
        bytes32 attackerTemplate = keccak256("template: evil.example /fake-receipt");
        ReclaimZkTlsVerifier.Proof memory p = _proof(
            _params("https://evil.example/fake-receipt"),
            _context(_fields(99_000_000), attackerTemplate),
            _two()
        );
        vm.expectRevert(
            abi.encodeWithSelector(ReclaimZkTlsVerifier.EndpointNotAllowed.selector, attackerTemplate)
        );
        v.verifyPayment(ORDER, abi.encode(p));
    }

    /// Defence in depth: even under an allowlisted template hash, the URL must be the bank's.
    function test_AnAllowlistedTemplateHashCannotVouchForAnotherHost() public {
        vm.expectRevert(ReclaimZkTlsVerifier.UrlNotAllowed.selector);
        v.verifyPayment(ORDER, _withParams(_params("https://evil.example/pix/v2/{{e2eId}}")));
    }

    function test_LookAlikeHostsAreRefused() public {
        string[6] memory lookalikes = [
            "https://api.bank.example.evil.io/pix/v2/x", // suffix domain
            "https://api.bank.example@evil.io/pix/v2/x", // userinfo: host is evil.io
            "https://api.bank.exampleevil.io/pix/v2/x", // no boundary
            "http://api.bank.example/pix/v2/x", // downgrade
            "https://evil.io/https://api.bank.example/pix/v2/", // bank URL as a path
            "https://api.bank.example:8443/pix/v2/x" // another port is another server
        ];
        for (uint256 i; i < lookalikes.length; ++i) {
            bytes memory proof = _withParams(_params(lookalikes[i]));
            vm.expectRevert(ReclaimZkTlsVerifier.UrlNotAllowed.selector);
            v.verifyPayment(ORDER, proof);
        }
    }

    /// `\/` is `/` to JSON.parse. Raw bytes are compared here, so escapes are refused outright.
    function test_EscapedSlashesInTheUrlAreRefused() public {
        bytes memory proof = _withParams(_params("https:\\/\\/api.bank.example\\/pix\\/v2\\/x"));
        vm.expectRevert(abi.encodeWithSelector(ReclaimZkTlsVerifier.EscapedValue.selector, "url"));
        v.verifyPayment(ORDER, proof);
    }

    /// JSON.parse keeps the LAST duplicate. A reader that took the first would see the bank.
    function test_ADuplicateUrlKeyIsRefused() public {
        string memory params = string(
            abi.encodePacked(
                '{"method":"GET","url":"', BANK_URL, '","url":"https://evil.example/x"}'
            )
        );
        bytes memory proof = _withParams(params);
        vm.expectRevert(abi.encodeWithSelector(ReclaimZkTlsVerifier.DuplicateKey.selector, "url"));
        v.verifyPayment(ORDER, proof);
    }

    /// `"\u0075rl"` is `"url"` to JSON.parse, and would be the last - winning - url key.
    function test_AnEscapedKeyIsRefused() public {
        string memory params = string(
            abi.encodePacked(
                '{"method":"GET","url":"', BANK_URL, '","\\u0075rl":"https://evil.example/x"}'
            )
        );
        bytes memory proof = _withParams(params);
        vm.expectRevert(ReclaimZkTlsVerifier.EscapedKey.selector);
        v.verifyPayment(ORDER, proof);
    }

    /// A bank URL tucked inside a nested object is not the URL the witness connects to.
    function test_ANestedUrlKeyIsNotMistakenForTheRealOne() public {
        string memory params = string(
            abi.encodePacked(
                '{"paramValues":{"url":"', BANK_URL, '"} , "url" : "https://evil.example/x"}'
            )
        );
        bytes memory proof = _withParams(params);
        vm.expectRevert(ReclaimZkTlsVerifier.UrlNotAllowed.selector);
        v.verifyPayment(ORDER, proof);
    }

    function test_MalformedParametersAreRefused() public {
        bytes memory trailing = _withParams(string(abi.encodePacked(_params(BANK_URL), "x")));
        vm.expectRevert(ReclaimZkTlsVerifier.MalformedJson.selector);
        v.verifyPayment(ORDER, trailing);

        bytes memory truncated = _withParams('{"url":"https://api.bank.example/pix/v2/x"');
        vm.expectRevert(ReclaimZkTlsVerifier.MalformedJson.selector);
        v.verifyPayment(ORDER, truncated);

        bytes memory mismatched = _withParams(
            '{"a":{"b":1],"url":"https://api.bank.example/pix/v2/x"}'
        );
        vm.expectRevert(ReclaimZkTlsVerifier.MalformedJson.selector);
        v.verifyPayment(ORDER, mismatched);
    }

    function test_OnlyTheHttpProviderIsAccepted() public {
        ReclaimZkTlsVerifier.Proof memory p = _genuine();
        p.claimInfo.provider = "not-http";
        vm.expectRevert(ReclaimZkTlsVerifier.ProviderNotAllowed.selector);
        v.verifyPayment(ORDER, abi.encode(p));
    }

    /// Revoking an endpoint stops its proofs at once.
    function test_ARevokedEndpointNoLongerSettles() public {
        bytes memory proof = abi.encode(_genuine());
        vm.prank(governor);
        v.revokeEndpoint(BANK_TEMPLATE);
        vm.expectRevert(
            abi.encodeWithSelector(ReclaimZkTlsVerifier.EndpointNotAllowed.selector, BANK_TEMPLATE)
        );
        v.verifyPayment(ORDER, proof);
    }

    /*//////////////////////////////////////////////////////////////
                  WHERE THE PAYMENT FIELDS COME FROM
    //////////////////////////////////////////////////////////////*/

    /// A prover-written key outside `extractedParameters` is never read.
    function test_AProverWrittenAmountOutsideTheExtractedParametersIsIgnored() public view {
        Fields memory f = _fields(1_500_000);
        string memory ctx = string(
            abi.encodePacked(
                '{"amountBrlCents":"999999999",',
                '"contextAddress":"0x0000000000000000000000000000000000000000",',
                '"contextMessage":"', _hex32(ORDER), '",',
                '"extractedParameters":', _extracted(f), ',',
                '"providerHash":"', _hex32(BANK_TEMPLATE), '"}'
            )
        );
        IAttestorVerifier.Payment memory p = v.verifyPayment(ORDER, _withContext(ctx));
        assertEq(p.amountBrlCents, 1_500_000, "read what the witness extracted");
    }

    function test_ADuplicateFieldInsideTheExtractedParametersIsRefused() public {
        Fields memory f = _fields(1_500_000);
        string memory ext = string(
            abi.encodePacked(
                '{"amountBrlCents":"1","amountBrlCents":"1500000",',
                '"bankTxId":"', _hex32(f.bankTxId), '","paidAt":"1700000000",',
                '"payeeKeyHash":"', _hex32(f.payeeKeyHash), '","payerRef":"', _hex32(f.payerRef),
                '","rail":"1"}'
            )
        );
        string memory ctx = string(
            abi.encodePacked(
                '{"contextMessage":"', _hex32(ORDER), '","extractedParameters":', ext,
                ',"providerHash":"', _hex32(BANK_TEMPLATE), '"}'
            )
        );
        bytes memory proof = _withContext(ctx);
        vm.expectRevert(
            abi.encodeWithSelector(ReclaimZkTlsVerifier.DuplicateKey.selector, "amountBrlCents")
        );
        v.verifyPayment(ORDER, proof);
    }

    function test_ADuplicateProviderHashIsRefused() public {
        string memory ctx = string(
            abi.encodePacked(
                '{"contextMessage":"', _hex32(ORDER), '","extractedParameters":',
                _extracted(_fields(1_500_000)), ',"providerHash":"', _hex32(keccak256("evil")),
                '","providerHash":"', _hex32(BANK_TEMPLATE), '"}'
            )
        );
        bytes memory proof = _withContext(ctx);
        vm.expectRevert(
            abi.encodeWithSelector(ReclaimZkTlsVerifier.DuplicateKey.selector, "providerHash")
        );
        v.verifyPayment(ORDER, proof);
    }

    function test_AMissingExtractedFieldRevertsRatherThanReadingZero() public {
        string memory ctx = string(
            abi.encodePacked(
                '{"contextMessage":"', _hex32(ORDER),
                '","extractedParameters":{"bankTxId":"', _hex32(BANK_TX),
                '"},"providerHash":"', _hex32(BANK_TEMPLATE), '"}'
            )
        );
        bytes memory proof = _withContext(ctx);
        vm.expectRevert(abi.encodeWithSelector(ReclaimZkTlsVerifier.MissingField.selector, "amountBrlCents"));
        v.verifyPayment(ORDER, proof);
    }

    function test_NonNumericAmountIsRejected() public {
        Fields memory f = _fields(1_500_000);
        string memory ext = string(
            abi.encodePacked(
                '{"amountBrlCents":"1.5e6","bankTxId":"', _hex32(f.bankTxId),
                '","paidAt":"1700000000","payeeKeyHash":"', _hex32(f.payeeKeyHash),
                '","payerRef":"', _hex32(f.payerRef), '","rail":"1"}'
            )
        );
        string memory ctx = string(
            abi.encodePacked(
                '{"contextMessage":"', _hex32(ORDER), '","extractedParameters":', ext,
                ',"providerHash":"', _hex32(BANK_TEMPLATE), '"}'
            )
        );
        bytes memory proof = _withContext(ctx);
        vm.expectRevert(abi.encodeWithSelector(ReclaimZkTlsVerifier.BadNumber.selector, "amountBrlCents"));
        v.verifyPayment(ORDER, proof);
    }

    /*//////////////////////////////////////////////////////////////
                           BINDING AND QUORUM
    //////////////////////////////////////////////////////////////*/

    /// The attack this proof shape invites: keep the signatures, swap the context.
    function test_SwappingTheContextBreaksTheIdentifier() public {
        ReclaimZkTlsVerifier.Proof memory p = _genuine();
        p.claimInfo.context = _context(_fields(99_000_000), BANK_TEMPLATE); // richer
        vm.expectRevert(ReclaimZkTlsVerifier.IdentifierMismatch.selector);
        v.verifyPayment(ORDER, abi.encode(p));
    }

    function test_TamperingWithParametersBreaksTheIdentifier() public {
        ReclaimZkTlsVerifier.Proof memory p = _genuine();
        p.claimInfo.parameters = _params("https://api.bank.example/pix/v2/other");
        vm.expectRevert(ReclaimZkTlsVerifier.IdentifierMismatch.selector);
        v.verifyPayment(ORDER, abi.encode(p));
    }

    /// Binding: a genuine proof for one order is worthless against another.
    function test_ProofIsBoundToItsOrder() public {
        bytes memory encoded = abi.encode(_genuine());
        vm.expectRevert(ReclaimZkTlsVerifier.OrderMismatch.selector);
        v.verifyPayment(bytes32(uint256(0xDEAD)), encoded);
    }

    function test_OneWitnessIsNotAQuorum() public {
        uint256[] memory one = new uint256[](1);
        one[0] = w1;
        ReclaimZkTlsVerifier.Proof memory p =
            _proof(_params(BANK_URL), _context(_fields(1_500_000), BANK_TEMPLATE), one);
        vm.expectRevert(
            abi.encodeWithSelector(ReclaimZkTlsVerifier.NotEnoughSignatures.selector, 1, 2)
        );
        v.verifyPayment(ORDER, abi.encode(p));
    }

    function test_TheSameWitnessTwiceIsNotAQuorum() public {
        ReclaimZkTlsVerifier.Proof memory p = _genuine();
        p.signedClaim.signatures[1] = p.signedClaim.signatures[0];
        vm.expectRevert(ReclaimZkTlsVerifier.SignaturesUnsorted.selector);
        v.verifyPayment(ORDER, abi.encode(p));
    }

    function test_UnknownWitnessIsRejected() public {
        uint256[] memory k = new uint256[](2);
        k[0] = w1;
        k[1] = wEvil;
        ReclaimZkTlsVerifier.Proof memory p =
            _proof(_params(BANK_URL), _context(_fields(1_500_000), BANK_TEMPLATE), k);
        vm.expectRevert(
            abi.encodeWithSelector(ReclaimZkTlsVerifier.UnknownWitness.selector, vm.addr(wEvil))
        );
        v.verifyPayment(ORDER, abi.encode(p));
    }

    /*//////////////////////////////////////////////////////////////
                              GOVERNANCE
    //////////////////////////////////////////////////////////////*/

    /// The deploy default that caused all this was "http", which allowlisted every server.
    function test_ItCannotBeDeployedWithoutAnEndpointAllowlist() public {
        address[] memory set = new address[](1);
        set[0] = vm.addr(w1);
        vm.expectRevert(ReclaimZkTlsVerifier.NoEndpoints.selector);
        new ReclaimZkTlsVerifier(governor, DELAY, set, 1, new bytes32[](0), new string[](0));
    }

    function test_APrefixWithoutAHostBoundaryCannotBeAllowlisted() public {
        string[8] memory bad = [
            "https://api.bank.example", // no "/" after the host: matches .evil.io suffixes
            "http://api.bank.example/", // not TLS
            "https://api.bank.example@evil.io/",
            "https://API.bank.example/", // the witness lowercases hosts; bytes would never match
            "https://api.bank.example/pix?x=", // query characters change parsing
            "https://api.bank.example/{{host}}/",
            "https:///pix/", // empty host
            "https://api.bank.example\\@evil.io/"
        ];
        // A verifier still in setup, where allowing is instant, isolates the validation.
        address[] memory set = new address[](1);
        set[0] = vm.addr(w1);
        ReclaimZkTlsVerifier fresh =
            new ReclaimZkTlsVerifier(governor, DELAY, set, 1, _one(BANK_TEMPLATE), _oneString(BANK_PREFIX));
        vm.startPrank(governor);
        for (uint256 i; i < bad.length; ++i) {
            vm.expectRevert(ReclaimZkTlsVerifier.BadUrlPrefix.selector);
            fresh.allowEndpoint(keccak256(bytes(bad[i])), bad[i]);
        }
        vm.stopPrank();
    }

    /// Changed behaviour: removal no longer lowers the threshold (see AttestorQuorumVerifier).
    function test_RemovingWitnessesNeverLowersTheThreshold() public {
        vm.startPrank(governor);
        v.setWitness(vm.addr(w1), false);
        v.setWitness(vm.addr(w2), false);
        vm.stopPrank();
        assertEq(v.witnessCount(), 1);
        assertEq(v.threshold(), 2, "fails closed rather than becoming 1-of-1");
    }

    /// Adding a witness, lowering the threshold, and allowing an endpoint all wait.
    function test_RiskIncreasingVerifierChangesMustBeScheduled() public {
        vm.startPrank(governor);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, ReclaimZkTlsVerifier.setWitness.selector)
        );
        v.setWitness(vm.addr(wEvil), true);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, ReclaimZkTlsVerifier.setThreshold.selector)
        );
        v.setThreshold(1);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, ReclaimZkTlsVerifier.allowEndpoint.selector)
        );
        v.allowEndpoint(keccak256("evil template"), "https://evil.example/");
        vm.stopPrank();

        _afterDelay(address(v), abi.encodeCall(ReclaimZkTlsVerifier.allowEndpoint, (keccak256("t2"), "https://api.bank2.example/")));
        assertEq(v.endpointUrlPrefix(keccak256("t2")), "https://api.bank2.example/");
    }

    function test_OnlyGovernorChangesWitnessesAndEndpoints() public {
        vm.expectRevert(DelayedGovernance.NotGovernor.selector);
        v.setWitness(address(0xFEE), true);
        vm.expectRevert(DelayedGovernance.NotGovernor.selector);
        v.allowEndpoint(keccak256("x"), "https://evil.example/");
        vm.expectRevert(DelayedGovernance.NotGovernor.selector);
        v.revokeEndpoint(BANK_TEMPLATE);
    }

    /*//////////////////////////////////////////////////////////////
                        WHICH RAILS AN ENDPOINT MAY ATTEST
    //////////////////////////////////////////////////////////////*/

    uint16 constant PIX_BIT = uint16(1 << 1);
    uint16 constant BOLETO_BIT = uint16(1 << 2);

    function _boletoFields() internal pure returns (Fields memory f) {
        f = _fields(1_500_000);
        f.payeeKeyHash = keccak256("boleto commitment");
        f.rail = 2;
    }

    /**
     * A PIX-receipt template whose rail capture turns out to match "2" must not become a way
     * to settle boleto orders: every endpoint is PIX-only until the governor says otherwise.
     */
    function test_APixReceiptEndpointCannotAttestABoleto() public {
        assertEq(v.endpointRails(BANK_TEMPLATE), PIX_BIT, "allowlisted endpoints start PIX-only");
        bytes memory proof = abi.encode(_proof(_params(BANK_URL), _context(_boletoFields(), BANK_TEMPLATE), _two()));
        vm.expectRevert(
            abi.encodeWithSelector(ReclaimZkTlsVerifier.RailNotAllowedForEndpoint.selector, BANK_TEMPLATE, uint8(2))
        );
        v.verifyPayment(ORDER, proof);
    }

    /// Widening an endpoint to boletos is the same power as allowing one, so it waits.
    function test_WideningAnEndpointToBoletoWaitsNarrowingDoesNot() public {
        vm.prank(governor);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, ReclaimZkTlsVerifier.setEndpointRails.selector)
        );
        v.setEndpointRails(BANK_TEMPLATE, PIX_BIT | BOLETO_BIT);

        _afterDelay(address(v), abi.encodeCall(ReclaimZkTlsVerifier.setEndpointRails, (BANK_TEMPLATE, PIX_BIT | BOLETO_BIT)));
        IAttestorVerifier.Payment memory p = v.verifyPayment(
            ORDER, abi.encode(_proof(_params(BANK_URL), _context(_boletoFields(), BANK_TEMPLATE), _two()))
        );
        assertEq(uint8(p.rail), uint8(IAttestorVerifier.Rail.BOLETO));
        assertEq(p.payeeKeyHash, keccak256("boleto commitment"));

        // Narrowing back to boleto-only is instant, and then a PIX receipt is refused.
        vm.prank(governor);
        v.setEndpointRails(BANK_TEMPLATE, BOLETO_BIT);
        vm.expectRevert(
            abi.encodeWithSelector(ReclaimZkTlsVerifier.RailNotAllowedForEndpoint.selector, BANK_TEMPLATE, uint8(1))
        );
        v.verifyPayment(ORDER, abi.encode(_genuine()));
    }

    function test_EndpointRailMasksAreValidatedAndDieWithTheEndpoint() public {
        // Validated during setup too, where the change itself would be instant.
        address[] memory set = new address[](1);
        set[0] = vm.addr(w1);
        ReclaimZkTlsVerifier fresh =
            new ReclaimZkTlsVerifier(governor, DELAY, set, 1, _one(BANK_TEMPLATE), _oneString(BANK_PREFIX));
        vm.startPrank(governor);
        vm.expectRevert(ReclaimZkTlsVerifier.BadRailMask.selector);
        fresh.setEndpointRails(BANK_TEMPLATE, PIX_BIT | 1); // UNSPECIFIED is never settleable

        vm.expectRevert(ReclaimZkTlsVerifier.BadRailMask.selector);
        v.setEndpointRails(BANK_TEMPLATE, 0);
        vm.expectRevert(
            abi.encodeWithSelector(ReclaimZkTlsVerifier.EndpointNotAllowed.selector, keccak256("unknown"))
        );
        fresh.setEndpointRails(keccak256("unknown"), PIX_BIT);
        v.revokeEndpoint(BANK_TEMPLATE);
        vm.stopPrank();
        assertEq(v.endpointRails(BANK_TEMPLATE), 0, "revoking clears the rails too");
    }

    function test_OnlyGovernorSetsEndpointRails() public {
        vm.prank(address(0xBAD));
        vm.expectRevert(DelayedGovernance.NotGovernor.selector);
        v.setEndpointRails(BANK_TEMPLATE, PIX_BIT);
    }
}
