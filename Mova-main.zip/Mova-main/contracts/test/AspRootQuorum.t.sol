// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import {ERC1967Proxy} from "@openzeppelin/contracts/proxy/ERC1967/ERC1967Proxy.sol";
import {AspRootQuorum, IEntrypointRoots} from "../AspRootQuorum.sol";

/// @dev The audited Entrypoint's role and root surface, as the tests read it.
interface IEntrypointUnderTest {
    function initialize(address owner, address postman) external;
    function latestRoot() external view returns (uint256);
    function associationSets(uint256 index) external view returns (uint256 root, string memory ipfsCID, uint256 timestamp);
    function grantRole(bytes32 role, address account) external;
    function revokeRole(bytes32 role, address account) external;
    function renounceRole(bytes32 role, address account) external;
    function hasRole(bytes32 role, address account) external view returns (bool);
    function updateRoot(uint256 root, string memory ipfsCID) external returns (uint256);
}

/**
 * AspRootQuorum against the real, audited Entrypoint - deployed from the Privacy Pools build
 * (`protocol/contracts/out`) behind an ERC1967 proxy, exactly as the rail deploys it - rather
 * than a mock that could agree with the quorum by construction.
 */
contract AspRootQuorumTest is Test {
    bytes32 constant OWNER_ROLE = keccak256("OWNER_ROLE"); // Entrypoint.sol:41
    bytes32 constant ASP_POSTMAN = keccak256("ASP_POSTMAN"); // Entrypoint.sol:43
    string constant CID = "bafybeigdyrzt5sfp7udm7hu76uh7y26nf3efuylqabf3oclgtqy55fbzdi"; // 59 chars
    string constant CID2 = "bafybeihkoviema7g3gxyt6la7vd5ho32ictqbilu3wnlo3rs7ewhnp7lly";

    IEntrypointUnderTest ep;
    AspRootQuorum quorum;
    address owner = makeAddr("owner");
    address a1 = makeAddr("asp1");
    address a2 = makeAddr("asp2");
    address a3 = makeAddr("asp3");
    address stranger = makeAddr("stranger");

    function setUp() public {
        address impl = deployCode("protocol/contracts/out/Entrypoint.sol/Entrypoint.json");
        ep = IEntrypointUnderTest(address(new ERC1967Proxy(impl, abi.encodeCall(IEntrypointUnderTest.initialize, (owner, owner)))));
        assertTrue(ep.hasRole(OWNER_ROLE, owner));
        assertTrue(ep.hasRole(ASP_POSTMAN, owner));

        quorum = new AspRootQuorum(IEntrypointRoots(address(ep)), _asps3(), 2);
        // The handover the rail makes before renouncing: the quorum becomes the only postman.
        vm.startPrank(owner);
        ep.grantRole(ASP_POSTMAN, address(quorum));
        ep.revokeRole(ASP_POSTMAN, owner);
        vm.stopPrank();
    }

    function _asps3() internal view returns (address[] memory s) {
        s = new address[](3);
        (s[0], s[1], s[2]) = (a1, a2, a3);
    }

    // ---- the quorum posts, and only the quorum ----

    function test_rootPostsOnlyAtThreshold() public {
        vm.prank(a1);
        assertFalse(quorum.vote(111, CID));
        vm.expectRevert(); // NoRootsAvailable: one vote posts nothing
        ep.latestRoot();

        vm.expectEmit(address(quorum));
        emit AspRootQuorum.RootPosted(0, 111, CID, 0);
        vm.prank(a2);
        assertTrue(quorum.vote(111, CID));

        assertEq(ep.latestRoot(), 111);
        (uint256 root, string memory cid,) = ep.associationSets(0);
        assertEq(root, 111);
        assertEq(cid, CID);
        assertEq(quorum.round(), 1);
    }

    function test_votesMustMatchRootAndCid() public {
        vm.prank(a1);
        quorum.vote(111, CID);
        vm.prank(a2);
        assertFalse(quorum.vote(111, CID2)); // same root, different CID: a different proposal
        vm.prank(a3);
        assertFalse(quorum.vote(222, CID)); // different root
        vm.expectRevert();
        ep.latestRoot();
    }

    function test_strangerCannotVote() public {
        vm.prank(stranger);
        vm.expectRevert(AspRootQuorum.NotAnAsp.selector);
        quorum.vote(111, CID);
    }

    function test_aspCannotVoteTwiceForTheSameProposal() public {
        vm.startPrank(a1);
        quorum.vote(111, CID);
        vm.expectRevert(AspRootQuorum.AlreadyVoted.selector);
        quorum.vote(111, CID);
        vm.stopPrank();
    }

    function test_nobodyElseCanPostOnceTheQuorumHoldsTheRole() public {
        for (uint256 i; i < 3; ++i) {
            address who = [owner, a1, stranger][i];
            vm.prank(who);
            vm.expectRevert(); // AccessControlUnauthorizedAccount
            ep.updateRoot(111, CID);
        }
    }

    // ---- rounds ----

    function test_oldRoundVotesNeverComplete() public {
        // Round 0: a1 and a2 post root 111; a3 had voted for 222.
        vm.prank(a3);
        quorum.vote(222, CID);
        vm.prank(a1);
        quorum.vote(111, CID);
        vm.prank(a2);
        quorum.vote(111, CID);
        assertEq(quorum.round(), 1);

        // In round 1, one more vote for 222 must not combine with a3's round-0 vote.
        vm.prank(a1);
        assertFalse(quorum.vote(222, CID));
        assertEq(ep.latestRoot(), 111);

        // It needs a fresh quorum in round 1.
        vm.prank(a3);
        assertTrue(quorum.vote(222, CID));
        assertEq(ep.latestRoot(), 222);
        assertEq(quorum.round(), 2);
    }

    function test_threeWaySplitRecoversByRevoting() public {
        vm.prank(a1);
        quorum.vote(111, CID);
        vm.prank(a2);
        quorum.vote(222, CID);
        vm.prank(a3);
        quorum.vote(333, CID);
        // Nobody has a quorum; one vote per round would stall here for ever. a2 joins a1.
        vm.prank(a2);
        assertTrue(quorum.vote(111, CID));
        assertEq(ep.latestRoot(), 111);
    }

    function test_sameRootCanBePostedAgainInALaterRound() public {
        vm.prank(a1);
        quorum.vote(111, CID);
        vm.prank(a2);
        quorum.vote(111, CID);
        vm.prank(a1);
        quorum.vote(111, CID); // round 1: not "AlreadyVoted", a new proposal
        vm.prank(a3);
        assertTrue(quorum.vote(111, CID));
        assertEq(quorum.round(), 2);
    }

    // ---- the Entrypoint's own rules, applied before any vote counts ----

    function test_refusesWhatTheEntrypointWouldRefuse() public {
        vm.startPrank(a1);
        vm.expectRevert(AspRootQuorum.EmptyRoot.selector);
        quorum.vote(0, CID);
        vm.expectRevert(AspRootQuorum.InvalidIPFSCIDLength.selector);
        quorum.vote(111, "short");
        vm.expectRevert(AspRootQuorum.InvalidIPFSCIDLength.selector);
        quorum.vote(111, string(new bytes(65)));
        vm.stopPrank();
    }

    // ---- immutable, and still working after the owner is gone ----

    function test_keepsPostingAfterOwnerRoleIsRenounced() public {
        vm.prank(owner);
        ep.renounceRole(OWNER_ROLE, owner);
        assertFalse(ep.hasRole(OWNER_ROLE, owner));

        vm.prank(a2);
        quorum.vote(444, CID);
        vm.prank(a3);
        assertTrue(quorum.vote(444, CID));
        assertEq(ep.latestRoot(), 444);

        // And with the owner gone, nobody can ever take the role from the quorum.
        vm.prank(owner);
        vm.expectRevert();
        ep.revokeRole(ASP_POSTMAN, address(quorum));
        assertTrue(ep.hasRole(ASP_POSTMAN, address(quorum)));
    }

    function test_survivesLossOfAMinority() public {
        // a1's key is lost: a2 and a3 still post.
        vm.prank(a2);
        quorum.vote(555, CID);
        vm.prank(a3);
        assertTrue(quorum.vote(555, CID));
    }

    function test_noOwnerOrSetter() public view {
        // The whole external surface: vote plus views. Anything else would be a new privileged path.
        assertEq(quorum.ASP_COUNT(), 3);
        assertEq(quorum.THRESHOLD(), 2);
        assertEq(address(quorum.ENTRYPOINT()), address(ep));
        address[] memory s = quorum.asps();
        assertEq(s.length, 3);
        assertTrue(quorum.isAsp(a1) && quorum.isAsp(a2) && quorum.isAsp(a3) && !quorum.isAsp(stranger));
    }

    // ---- construction ----

    function test_constructorRequiresAStrictMajority() public {
        address[] memory s = _asps3();
        IEntrypointRoots e = IEntrypointRoots(address(ep));
        vm.expectRevert(abi.encodeWithSelector(AspRootQuorum.ThresholdNotMajority.selector, 1, 3));
        new AspRootQuorum(e, s, 1);
        vm.expectRevert(abi.encodeWithSelector(AspRootQuorum.ThresholdNotMajority.selector, 0, 3));
        new AspRootQuorum(e, s, 0);
        vm.expectRevert(abi.encodeWithSelector(AspRootQuorum.ThresholdNotMajority.selector, 4, 3));
        new AspRootQuorum(e, s, 4);
        new AspRootQuorum(e, s, 3); // unanimity is allowed

        address[] memory two = new address[](2);
        (two[0], two[1]) = (a1, a2);
        vm.expectRevert(abi.encodeWithSelector(AspRootQuorum.ThresholdNotMajority.selector, 1, 2));
        new AspRootQuorum(e, two, 1); // 1 of 2 is not a majority
        new AspRootQuorum(e, two, 2);

        address[] memory none = new address[](0);
        vm.expectRevert(abi.encodeWithSelector(AspRootQuorum.ThresholdNotMajority.selector, 0, 0));
        new AspRootQuorum(e, none, 0);
    }

    function test_constructorRefusesZeroAndDuplicates() public {
        address[] memory s = _asps3();
        s[2] = a1;
        vm.expectRevert(abi.encodeWithSelector(AspRootQuorum.DuplicateAsp.selector, a1));
        new AspRootQuorum(IEntrypointRoots(address(ep)), s, 2);
        s[2] = address(0);
        vm.expectRevert(AspRootQuorum.ZeroAddress.selector);
        new AspRootQuorum(IEntrypointRoots(address(ep)), s, 2);
        vm.expectRevert(AspRootQuorum.ZeroAddress.selector);
        new AspRootQuorum(IEntrypointRoots(address(0)), _asps3(), 2);
    }

    // ---- property: no root without a quorum ----

    /// Any sequence of ASP and stranger votes over a few roots: the Entrypoint's latest root is
    /// always one that THRESHOLD distinct ASPs voted for in the round it was posted.
    function testFuzz_noRootWithoutQuorum(uint8[24] calldata who, uint8[24] calldata which) public {
        address[4] memory voters = [a1, a2, a3, stranger];
        uint256 posted;
        for (uint256 i; i < who.length; ++i) {
            address v = voters[who[i] % 4];
            uint256 root = 100 + (which[i] % 3);
            uint256 r = quorum.round();
            bytes32 p = quorum.proposalId(r, root, CID);
            uint256 before = quorum.votes(p);
            vm.prank(v);
            try quorum.vote(root, CID) returns (bool didPost) {
                assertTrue(quorum.isAsp(v));
                assertEq(quorum.votes(p), before + 1);
                if (didPost) {
                    ++posted;
                    assertEq(before + 1, 2);
                    assertEq(ep.latestRoot(), root);
                    assertEq(quorum.round(), r + 1);
                }
            } catch {
                assertTrue(!quorum.isAsp(v) || quorum.hasVoted(p, v));
            }
        }
        assertEq(quorum.round(), posted);
    }
}
