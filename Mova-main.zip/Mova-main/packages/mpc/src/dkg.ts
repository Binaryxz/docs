import { sha256 } from '@noble/hashes/sha2';
import { bytesToHex, concatBytes, hexToBytes, randomBytes, utf8ToBytes } from '@noble/hashes/utils';
import {
  Point, hashToScalar, nonceGenerate, pointToBytes, randomScalar, scalarToBytes,
  type KeyShare, type PointT, type Scalar,
} from './frost.js';

/**
 * Distributed key generation for FROST: Pedersen DKG with proofs of possession ("PedPoP"),
 * Komlo & Goldberg, "FROST: Flexible Round-Optimized Schnorr Threshold Signatures", Figure 1.
 *
 * WHY THIS EXISTS. Key generation used to be a trusted dealer: one machine drew the group
 * secret and split it. Whoever ran that machine - in practice, the server - knew every key it
 * ever made, so "no single party can sign" was a claim about the signing path only. Here every
 * participant samples its own polynomial, the group secret is the sum of their constant terms,
 * and no machine ever computes that sum. Each party ends with a share of it and nothing more.
 *
 * THE PROTOCOL, as implemented below
 *
 *   round 1   each P_i samples f_i(x) = a_i0 + a_i1 x + ... + a_i(t-1) x^(t-1)
 *             broadcasts  C_i = (a_i0 G, ..., a_i(t-1) G)         Feldman commitments
 *                         σ_i = (R_i, μ_i)                         proof of possession of a_i0
 *             where  R_i = k G,  c_i = H(session, i, a_i0 G, R_i),  μ_i = k + a_i0 c_i
 *   round 2   each P_i verifies every σ_l, then sends f_i(l) PRIVATELY to each other P_l
 *   finalize  each P_l checks  f_i(l) G == Σ_k C_ik l^k  for every sender,
 *             signing share        s_l = Σ_i f_i(l)
 *             group public key     Y   = Σ_i C_i0
 *             verification shares  Y_j = Σ_i Σ_k C_ik j^k   (computable by anyone)
 *
 * THE PROOF OF POSSESSION is what makes this PedPoP rather than plain Pedersen. Without it a
 * participant who sees the others' commitments first can publish C_i0 = X - Σ(others), steering
 * the group key to one it chose. It is bound to the participant id AND to the session - which
 * commits to a caller-supplied context string, the threshold and the participant set - so a
 * proof cannot be lifted onto another identifier or replayed into another run.
 *
 * WHAT THE CALLER MUST PROVIDE, because a library without networking cannot:
 *   - a fresh, agreed `context` per run (≥ 16 bytes; include random bytes, the account, the
 *     chain) - `dkgContext` builds one;
 *   - an AUTHENTICATED broadcast for round 1, and AUTHENTICATED, ENCRYPTED point-to-point
 *     channels for round 2 (`DkgShareMessage.share` is a secret scalar). Inconsistent
 *     broadcast - one party showing different commitments to different peers - is detected:
 *     every round-2 message carries the sender's hash of the whole round-1 transcript, and a
 *     mismatch aborts. What cannot be detected here is a man in the middle on an
 *     unauthenticated channel, who would simply be a participant;
 *   - `publicKeys.transcript` compared out of band (or signed by both ends) before funds go
 *     to the key, so every party knows they all finished the same run.
 *
 * MISUSE RESISTANCE. Round state is an opaque handle into a module-private table and is
 * consumed on first use - success or failure. A failed DKG is abandoned, never retried with the
 * same polynomial: re-running round 2 against a different set of peers would hand this party's
 * evaluations to whoever those peers are. Every proof and every share is verified, and a
 * failure throws `DkgError` naming each participant at fault and why.
 *
 * UNAUDITED, like the rest of this package. `docs/audit-scope.md` ranks it with `frost.ts`.
 */

const Fn = Point.Fn;

/** Shortest context accepted. A constant like "dkg" is the mistake this stops. */
export const MIN_DKG_CONTEXT_BYTES = 16;
/** Identifiers are encoded in 4 bytes, and a DKG with more parties than this is not our use. */
const MAX_PARTICIPANTS = 255;

const DST_SESSION = utf8ToBytes('FROST-secp256k1-SHA256-v1/dkg/session');
const DST_TRANSCRIPT = utf8ToBytes('FROST-secp256k1-SHA256-v1/dkg/transcript');
/** The hash domain of the proof of possession; `hashToScalar` refuses the signing domains. */
const POP_DOMAIN = 'dkg-pop';

/* ------------------------------------------------------------------ types */

export interface DkgParams {
  /** Session context Φ. Unique per run and identical for every participant. */
  readonly context: Uint8Array;
  /** Signers needed to sign. At least 2: with 1, every share would BE the group secret. */
  readonly threshold: number;
  /** Every participant's identifier, this party's included. Distinct, 1..2^32-1. */
  readonly participants: readonly number[];
}

/** Round 1 broadcast. Everything in it is public. */
export interface DkgRound1Package {
  readonly from: number;
  /** Hex session id; commits to context, threshold and participant set. */
  readonly session: string;
  /** Feldman commitments a_i0 G .. a_i(t-1) G. */
  readonly commitments: readonly PointT[];
  /** Proof of possession of a_i0, bound to `from` and `session`. */
  readonly proof: { readonly R: PointT; readonly mu: Scalar };
}

/**
 * Round 2 point-to-point message. `share` is SECRET: it is the sender's polynomial evaluated at
 * the recipient's identifier, and must travel over an encrypted, authenticated channel.
 */
export interface DkgShareMessage {
  readonly from: number;
  readonly to: number;
  readonly session: string;
  /** The sender's hash of the complete round-1 transcript, to catch equivocation. */
  readonly transcript: string;
  readonly share: Scalar;
}

/** Opaque, single-use handle to this party's round-1 secrets. Holds no secret itself. */
export interface DkgRound1State {
  readonly id: number;
  readonly session: string;
  readonly used: boolean;
}

/** Opaque, single-use handle to this party's round-2 secrets. Holds no secret itself. */
export interface DkgRound2State {
  readonly id: number;
  readonly session: string;
  readonly used: boolean;
}

/** What every participant learns, and may publish. */
export interface GroupPublicKeys {
  readonly groupPublicKey: PointT;
  /** Y_j = s_j G for every participant; what `verifyShare` checks a partial signature against. */
  readonly verificationShares: ReadonlyMap<number, PointT>;
  readonly threshold: number;
  readonly participants: readonly number[];
  readonly session: string;
  /** Hash of the round-1 transcript. Compare it across participants before using the key. */
  readonly transcript: string;
}

export interface DkgResult {
  /** This party's signing share, ready for `commit`/`sign`. */
  readonly keyShare: KeyShare;
  readonly publicKeys: GroupPublicKeys;
}

export type DkgFaultCode =
  | 'unexpected-sender'        // not a participant, or claims to be the recipient itself
  | 'duplicate-message'        // two messages from one participant
  | 'misrouted'                // addressed to someone else
  | 'wrong-session'            // from another run, or other parameters
  | 'malformed'                // wrong length, invalid or identity point, scalar out of range
  | 'bad-proof-of-possession'  // σ does not prove knowledge of a_i0 for this id and session
  | 'inconsistent-transcript'  // the sender saw different round-1 broadcasts than we did
  | 'bad-share'                // f_i(l) G does not match the sender's commitments
  | 'missing-message';

export interface DkgFault {
  readonly participant: number;
  readonly code: DkgFaultCode;
  readonly detail: string;
}

export type DkgErrorCode =
  | DkgFaultCode | 'invalid-parameters' | 'state-reused' | 'foreign-state' | 'degenerate-key';

/**
 * A DKG abort. `faults` names every participant found misbehaving and how; `culprits` is the
 * distinct identifiers. Errors that are this party's own (bad parameters, a reused handle) have
 * no culprits.
 */
export class DkgError extends Error {
  override readonly name = 'DkgError';

  constructor(readonly code: DkgErrorCode, readonly faults: readonly DkgFault[], message: string) {
    super(message);
  }

  get culprits(): number[] {
    return [...new Set(this.faults.map((f) => f.participant))].sort((a, b) => a - b);
  }
}

function abort(faults: DkgFault[], stage: string): never {
  const list = faults.map((f) => `participant ${f.participant}: ${f.code} (${f.detail})`).join('; ');
  throw new DkgError(faults[0]!.code, faults, `DKG aborted in ${stage}: ${list}`);
}

/* ------------------------------------------------------------------ parameters */

interface Validated {
  readonly context: Uint8Array;
  readonly threshold: number;
  readonly participants: readonly number[];
  readonly session: Uint8Array;
  readonly sessionHex: string;
}

function u32(n: number): Uint8Array {
  const out = new Uint8Array(4);
  new DataView(out.buffer).setUint32(0, n, false);
  return out;
}

function invalid(detail: string): never {
  throw new DkgError('invalid-parameters', [], `invalid DKG parameters: ${detail}`);
}

function validateParams(params: DkgParams): Validated {
  const { context, threshold, participants } = params ?? ({} as DkgParams);
  if (!(context instanceof Uint8Array) || context.length < MIN_DKG_CONTEXT_BYTES) {
    invalid(`a session context of at least ${MIN_DKG_CONTEXT_BYTES} bytes is required, `
      + 'unique to this run (see dkgContext)');
  }
  if (!Array.isArray(participants) || participants.length < 2
    || participants.length > MAX_PARTICIPANTS) {
    invalid(`between 2 and ${MAX_PARTICIPANTS} participants are required`);
  }
  for (const id of participants) {
    if (!Number.isSafeInteger(id) || id < 1 || id > 0xffffffff) {
      invalid(`participant identifier ${id} is not an integer in 1..2^32-1`);
    }
  }
  if (new Set(participants).size !== participants.length) {
    invalid('participant identifiers repeat');
  }
  if (!Number.isSafeInteger(threshold) || threshold < 2 || threshold > participants.length) {
    // threshold 1 is refused rather than supported: every f_i would be constant, so every
    // participant's share would equal the group secret.
    invalid(`threshold ${threshold} of ${participants.length}: need 2 <= t <= n`);
  }
  const sorted = [...participants].sort((a, b) => a - b);
  const session = sha256(concatBytes(
    DST_SESSION, u32(context.length), context, u32(threshold), u32(sorted.length),
    ...sorted.map(u32),
  ));
  return Object.freeze({
    context: Uint8Array.from(context), threshold, participants: Object.freeze(sorted),
    session, sessionHex: bytesToHex(session),
  });
}

/**
 * A context for one DKG run: a label naming what the key is for, plus 32 fresh random bytes.
 * One party generates it and the others adopt it; each should check the label is what it
 * expects before joining.
 */
export function dkgContext(label: string, random: Uint8Array = randomBytes(32)): Uint8Array {
  if (random.length < 16) throw new Error('dkgContext needs at least 16 random bytes');
  return concatBytes(utf8ToBytes(label), random);
}

/** The session id every message of a run carries. Validates the parameters. */
export function dkgSessionId(params: DkgParams): string {
  return validateParams(params).sessionHex;
}

/* ------------------------------------------------------------------ proof of possession */

/** c = H(session, id, a_i0 G, R). Exported so tests can build hostile packages. */
export function dkgProofChallenge(session: string, id: number, phi0: PointT, R: PointT): Scalar {
  return hashToScalar(
    POP_DOMAIN, hexToBytes(session), scalarToBytes(BigInt(id)), pointToBytes(phi0), pointToBytes(R),
  );
}

/** μ G == R + c φ0. Assumes both points were already checked to be valid and non-identity. */
function proofHolds(session: string, id: number, phi0: PointT, proof: { R: PointT; mu: Scalar }): boolean {
  if (proof.mu <= 0n || proof.mu >= Fn.ORDER) return false;
  try {
    const c = dkgProofChallenge(session, id, phi0, proof.R);
    return Point.BASE.multiply(proof.mu).equals(proof.R.add(phi0.multiply(c)));
  } catch {
    return false; // a zero challenge, which no honest run produces
  }
}

/* ------------------------------------------------------------------ helpers */

/** A usable, non-identity curve point, or a reason it is not. */
function pointFault(p: unknown): string | null {
  if (!(p instanceof Point)) return 'not a curve point';
  // Checked before validity, which also rejects the identity but would not say why.
  if (p.is0()) return 'the identity point (a zero secret or coefficient)';
  try {
    p.assertValidity();
  } catch {
    return 'not on the curve';
  }
  return null;
}

/** f(x) by Horner, over the scalar field. */
function evaluate(coefficients: readonly Scalar[], x: number): Scalar {
  let y = 0n;
  for (let k = coefficients.length - 1; k >= 0; k--) {
    y = Fn.create(y * BigInt(x) + coefficients[k]!);
  }
  return y;
}

/** Σ_k C_k x^k: the commitment to f(x), which is G times the share for x. */
function commitmentAt(commitments: readonly PointT[], x: number): PointT {
  let acc: PointT = Point.ZERO;
  let power = 1n;
  for (const c of commitments) {
    acc = acc.add(c.multiply(power));
    power = Fn.create(power * BigInt(x));
  }
  return acc;
}

function transcriptOf(v: Validated, packages: ReadonlyMap<number, DkgRound1Package>): string {
  const parts: Uint8Array[] = [DST_TRANSCRIPT, v.session];
  for (const id of v.participants) {
    const p = packages.get(id)!;
    parts.push(u32(id), ...p.commitments.map(pointToBytes), pointToBytes(p.proof.R),
      scalarToBytes(p.proof.mu));
  }
  return bytesToHex(sha256(concatBytes(...parts)));
}

/* ------------------------------------------------------------------ single-use state */

interface Round1Secret {
  readonly v: Validated;
  readonly id: number;
  readonly coefficients: readonly Scalar[];
  readonly own: DkgRound1Package;
}

interface Round2Secret {
  readonly v: Validated;
  readonly id: number;
  readonly transcript: string;
  readonly commitments: ReadonlyMap<number, readonly PointT[]>;
  readonly ownShare: Scalar;
}

/** `null` once consumed; absent if the handle was not made by this module in this process. */
const round1Secrets = new WeakMap<DkgRound1State, Round1Secret | null>();
const round2Secrets = new WeakMap<DkgRound2State, Round2Secret | null>();

function handle<T extends object>(table: WeakMap<T, unknown>, id: number, session: string): T {
  const h = Object.freeze({
    id, session,
    get used() { return table.get(h as unknown as T) === null; },
  }) as unknown as T;
  return h;
}

/**
 * Take a round's secrets out of the table, consuming the handle whatever happens next. A copy,
 * a deserialised object or a second call is refused: the polynomial behind round 1 must never
 * produce a second set of evaluations.
 */
function take<K extends object, S>(table: WeakMap<K, S | null>, state: K, round: string): S {
  const secret = table.get(state);
  if (secret === undefined) {
    throw new DkgError('foreign-state', [], `this ${round} state was not produced by this module in `
      + 'this process; DKG state cannot be copied, serialised or restored - start a new run');
  }
  if (secret === null) {
    throw new DkgError('state-reused', [], `this ${round} state was already used; a DKG round runs `
      + 'once, and a failed run is abandoned - start a new run with a new context');
  }
  table.set(state, null);
  return secret;
}

/* ------------------------------------------------------------------ round 1 */

/**
 * Round 1 for participant `id`: sample a polynomial, commit to it, prove possession of its
 * constant term. Broadcast `broadcast`; keep `state` for round 2.
 */
export function dkgRound1(id: number, params: DkgParams): {
  state: DkgRound1State; broadcast: DkgRound1Package;
} {
  const v = validateParams(params);
  if (!v.participants.includes(id)) invalid(`${id} is not among the participants`);

  // randomScalar is non-zero by construction, so a_i0 - this party's contribution to the
  // group secret - is never zero, and neither is the top coefficient (the degree is exact).
  const coefficients = Array.from({ length: v.threshold }, () => randomScalar());
  const commitments = Object.freeze(coefficients.map((a) => Point.BASE.multiply(a)));

  // The proof's nonce is hedged with the secret it proves, like a signing nonce.
  let k = 0n;
  while (k === 0n) k = nonceGenerate(coefficients[0]!);
  const R = Point.BASE.multiply(k);
  const c = dkgProofChallenge(v.sessionHex, id, commitments[0]!, R);
  const mu = Fn.create(k + coefficients[0]! * c);

  const broadcast: DkgRound1Package = Object.freeze({
    from: id, session: v.sessionHex, commitments, proof: Object.freeze({ R, mu }),
  });
  const state = handle<DkgRound1State>(round1Secrets, id, v.sessionHex);
  round1Secrets.set(state, Object.freeze({ v, id, coefficients: Object.freeze(coefficients), own: broadcast }));
  return { state, broadcast };
}

/* ------------------------------------------------------------------ round 2 */

/**
 * Round 2: verify every other participant's round-1 package, then produce the private share
 * messages. Consumes `state`. Throws `DkgError` naming every participant whose package is
 * missing, duplicated, from another session, malformed, or carries a bad proof - before any
 * share is computed, so nothing secret is released to a run that is going to abort.
 */
export function dkgRound2(state: DkgRound1State, received: readonly DkgRound1Package[]): {
  state: DkgRound2State; messages: readonly DkgShareMessage[];
} {
  const secret = take(round1Secrets, state, 'round-1');
  const { v, id: self } = secret;
  const faults: DkgFault[] = [];
  const byId = new Map<number, DkgRound1Package>();

  for (const pkg of received) {
    const from = (pkg as Partial<DkgRound1Package> | null)?.from as number;
    if (!v.participants.includes(from) || from === self) {
      faults.push({ participant: from, code: 'unexpected-sender',
        detail: from === self ? 'a package claiming to be our own' : 'not a participant of this run' });
      continue;
    }
    if (byId.has(from)) {
      faults.push({ participant: from, code: 'duplicate-message', detail: 'two round-1 packages' });
      continue;
    }
    byId.set(from, pkg);
  }

  for (const [from, pkg] of byId) {
    if (pkg.session !== v.sessionHex) {
      faults.push({ participant: from, code: 'wrong-session',
        detail: 'package is for another session or other parameters' });
      continue;
    }
    if (!Array.isArray(pkg.commitments) || pkg.commitments.length !== v.threshold) {
      faults.push({ participant: from, code: 'malformed',
        detail: `expected ${v.threshold} commitments, got ${pkg.commitments?.length}` });
      continue;
    }
    const bad = [...pkg.commitments, pkg.proof?.R].map(pointFault).find((f) => f !== null);
    if (bad !== undefined || typeof pkg.proof?.mu !== 'bigint') {
      faults.push({ participant: from, code: 'malformed', detail: bad ?? 'proof scalar missing' });
      continue;
    }
    if (!proofHolds(v.sessionHex, from, pkg.commitments[0]!, pkg.proof)) {
      faults.push({ participant: from, code: 'bad-proof-of-possession',
        detail: 'does not prove knowledge of its constant term for this identifier and session' });
    }
  }

  for (const id of v.participants) {
    if (id !== self && !byId.has(id)) {
      faults.push({ participant: id, code: 'missing-message', detail: 'no round-1 package' });
    }
  }
  if (faults.length) abort(faults, 'round 2');

  byId.set(self, secret.own);
  const transcript = transcriptOf(v, byId);
  const messages = v.participants.filter((id) => id !== self).map((to) => Object.freeze({
    from: self, to, session: v.sessionHex, transcript, share: evaluate(secret.coefficients, to),
  }));

  const next = handle<DkgRound2State>(round2Secrets, self, v.sessionHex);
  round2Secrets.set(next, Object.freeze({
    v, id: self, transcript,
    commitments: new Map([...byId].map(([id, p]) => [id, p.commitments])),
    ownShare: evaluate(secret.coefficients, self),
  }));
  return { state: next, messages: Object.freeze(messages) };
}

/* ------------------------------------------------------------------ finalize */

/**
 * Verify every received share against its sender's commitments and derive this party's key
 * material. Consumes `state`. The group secret is not computed here or anywhere else: this
 * party sums the evaluations it was sent at ITS OWN identifier, which is its share and nothing
 * more; the group key is a sum of public commitments.
 */
export function dkgFinalize(state: DkgRound2State, received: readonly DkgShareMessage[]): DkgResult {
  const secret = take(round2Secrets, state, 'round-2');
  const { v, id: self } = secret;
  const faults: DkgFault[] = [];
  const seen = new Set<number>();
  let share = secret.ownShare;

  for (const msg of received) {
    const from = (msg as Partial<DkgShareMessage> | null)?.from as number;
    if (!v.participants.includes(from) || from === self) {
      faults.push({ participant: from, code: 'unexpected-sender',
        detail: from === self ? 'a share claiming to be our own' : 'not a participant of this run' });
      continue;
    }
    if (seen.has(from)) {
      faults.push({ participant: from, code: 'duplicate-message', detail: 'two shares' });
      continue;
    }
    seen.add(from);
    if (msg.to !== self) {
      faults.push({ participant: from, code: 'misrouted', detail: `addressed to ${msg.to}` });
      continue;
    }
    if (msg.session !== v.sessionHex) {
      faults.push({ participant: from, code: 'wrong-session', detail: 'share is for another session' });
      continue;
    }
    if (msg.transcript !== secret.transcript) {
      // Either the sender or some third participant showed different round-1 broadcasts to
      // different peers. Continuing would give the two of us DIFFERENT group keys.
      faults.push({ participant: from, code: 'inconsistent-transcript',
        detail: 'saw a different round-1 transcript: the sender or another participant '
          + 'equivocated on the broadcast' });
      continue;
    }
    if (typeof msg.share !== 'bigint' || msg.share <= 0n || msg.share >= Fn.ORDER) {
      faults.push({ participant: from, code: 'malformed', detail: 'share is not a non-zero scalar' });
      continue;
    }
    const expected = commitmentAt(secret.commitments.get(from)!, self);
    if (!Point.BASE.multiply(msg.share).equals(expected)) {
      faults.push({ participant: from, code: 'bad-share',
        detail: "does not match the sender's round-1 commitments" });
      continue;
    }
    share = Fn.create(share + msg.share);
  }

  for (const id of v.participants) {
    if (id !== self && !seen.has(id)) {
      faults.push({ participant: id, code: 'missing-message', detail: 'no share' });
    }
  }
  if (faults.length) abort(faults, 'finalize');

  // Aggregate commitments A_k = Σ_i C_ik, so every verification share costs t multiplications.
  const aggregate: PointT[] = [];
  for (let k = 0; k < v.threshold; k++) {
    aggregate.push(v.participants.reduce<PointT>(
      (acc, id) => acc.add(secret.commitments.get(id)![k]!), Point.ZERO,
    ));
  }
  const groupPublicKey = aggregate[0]!;
  if (groupPublicKey.is0() || share === 0n) {
    throw new DkgError('degenerate-key', [], 'the run produced an identity group key or a zero share');
  }
  const verificationShares = new Map<number, PointT>();
  for (const id of v.participants) {
    const Y = commitmentAt(aggregate, id);
    if (Y.is0()) throw new DkgError('degenerate-key', [], `participant ${id}'s verification share is the identity`);
    verificationShares.set(id, Y);
  }
  if (!Point.BASE.multiply(share).equals(verificationShares.get(self)!)) {
    // Unreachable if every share verified; checked because a silent wrong share is a wallet
    // that can never sign.
    throw new DkgError('degenerate-key', [], 'our share does not match our verification share');
  }

  return Object.freeze({
    keyShare: Object.freeze({ id: self, share, groupPublicKey }),
    publicKeys: Object.freeze({
      groupPublicKey, verificationShares, threshold: v.threshold, participants: v.participants,
      session: v.sessionHex, transcript: secret.transcript,
    }),
  });
}
