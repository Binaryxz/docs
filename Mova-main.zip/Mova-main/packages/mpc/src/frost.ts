import { secp256k1 } from '@noble/curves/secp256k1';
import { sha256 } from '@noble/hashes/sha2';
import { randomBytes } from '@noble/hashes/utils';

/**
 * FROST threshold Schnorr signing over secp256k1 — RFC 9591, ciphersuite
 * FROST(secp256k1, SHA-256).
 *
 * WHY THIS AND NOT THRESHOLD ECDSA. The requirement is that no single party can move funds.
 * Threshold ECDSA (GG18, CGGMP, DKLs) needs Paillier or oblivious transfer plus a stack of
 * zero-knowledge proofs, and implementing it from a paper is the canonical way to write
 * code that looks correct and loses everyone's money. Schnorr is LINEAR - partial
 * signatures simply add - which is the entire reason threshold Schnorr is tractable where
 * threshold ECDSA is not. That is a property of the maths, not a shortcut.
 *
 * WHAT THIS IS AND IS NOT. It is genuine multi-party signing: the signing path never
 * assembles the group secret, on any machine. Each party holds a share, produces a partial
 * signature, and the partials are summed. A single compromised party cannot sign, and
 * learns nothing about the other's share. Key GENERATION is `dkg.ts`: a Pedersen DKG with
 * proofs of possession, so the group secret is never computed at generation time either.
 * There is no trusted dealer in `src/`; the one the tests use lives in `test/dealer.ts`.
 *
 * It is NOT audited. It is an implementation of a specification, by one author, and it has
 * not been reviewed by anyone who breaks these for a living. Do not put funds behind it
 * before it is audited - `docs/audit-scope.md` names it explicitly.
 *
 * WHAT THE SPEC BUYS. The dangerous, subtle part of multi-party Schnorr is the nonce. A
 * naive one-round protocol where the second party picks its nonce after seeing the first's
 * lets that party bias the group nonce, which breaks the scheme (the Drijvers attack, and
 * ROS more generally). RFC 9591 defends against this with two nonces per party and a
 * BINDING FACTOR derived from the whole commitment list and the message, so no party can
 * influence the aggregate after seeing anyone else's contribution. `bindingFactors` below
 * is that defence; it is not optional and it is not a detail.
 */

const { Point } = secp256k1;
const Fn = Point.Fn;
const ORDER = Fn.ORDER;
const CONTEXT = 'FROST-secp256k1-SHA256-v1';

export type Scalar = bigint;
export type PointT = InstanceType<typeof Point>;

/* ------------------------------------------------------------------ encoding helpers */

const enc = new TextEncoder();

function concat(...parts: Uint8Array[]): Uint8Array {
  const total = parts.reduce((n, p) => n + p.length, 0);
  const out = new Uint8Array(total);
  let at = 0;
  for (const p of parts) { out.set(p, at); at += p.length; }
  return out;
}

/** Scalars are encoded big-endian in 32 bytes, per the ciphersuite. */
export function scalarToBytes(s: Scalar): Uint8Array {
  const out = new Uint8Array(32);
  let v = Fn.create(s);
  for (let i = 31; i >= 0; i--) { out[i] = Number(v & 0xffn); v >>= 8n; }
  return out;
}

export function bytesToScalar(b: Uint8Array): Scalar {
  let v = 0n;
  for (const byte of b) v = (v << 8n) | BigInt(byte);
  return v;
}

/** Points are encoded compressed (33 bytes), per the ciphersuite. */
export function pointToBytes(p: PointT): Uint8Array {
  return p.toBytes(true);
}

/**
 * Map a hash to a scalar.
 *
 * Reduces 64 bytes rather than 32: reducing a 256-bit value into a ~256-bit order gives a
 * measurable modulo bias, while reducing 512 bits makes it negligible (< 2^-250). The
 * ciphersuite specifies hash-to-field for this reason.
 */
function h2s(domain: string, ...parts: Uint8Array[]): Scalar {
  const msg = concat(enc.encode(CONTEXT + domain), ...parts);
  const wide = concat(sha256(concat(enc.encode('h2s-1'), msg)),
                      sha256(concat(enc.encode('h2s-2'), msg)));
  return Fn.create(bytesToScalar(wide));
}

/**
 * Domain-separated hash-to-scalar, for the other protocols in this package (the DKG's proof
 * of possession). Each caller passes its own `domain`, which is what keeps a DKG challenge
 * from ever colliding with a signing challenge or a binding factor. Not for application use.
 */
export function hashToScalar(domain: string, ...parts: Uint8Array[]): Scalar {
  // The domain is concatenated with the input, not length-prefixed, so a domain that is a
  // prefix of a signing domain (or extends one) could collide with it given chosen parts.
  if (domain.length === 0 || ['rho', 'chal', 'nonce'].some((d) => d.startsWith(domain) || domain.startsWith(d))) {
    throw new Error(`hash domain "${domain}" overlaps a FROST signing domain`);
  }
  return h2s(domain, ...parts);
}

/**
 * A uniformly random NON-ZERO scalar, for key material.
 *
 * `randomSecretKey` rejection-samples into [1, n-1], so there is neither a zero nor the small
 * modulo bias of reducing 32 random bytes. Nonces keep using `nonceGenerate`, which hedges
 * with the share; a fresh polynomial coefficient has no share to hedge with.
 */
export function randomScalar(): Scalar {
  return bytesToScalar(secp256k1.utils.randomSecretKey());
}

/** H1 — binding factor. */
const H1 = (...p: Uint8Array[]) => h2s('rho', ...p);
/** H2 — challenge. */
const H2 = (...p: Uint8Array[]) => h2s('chal', ...p);
/** H3 — nonce generation. */
const H3 = (...p: Uint8Array[]) => h2s('nonce', ...p);

/* ------------------------------------------------------------------ key shares */

/**
 * One participant's signing key material, as `dkgFinalize` in `dkg.ts` produces it.
 *
 * THERE IS NO KEYGEN IN THIS FILE, deliberately. It used to hold `trustedDealerKeygen`, which
 * drew the group secret on one machine and split it - so "no machine ever held the key" was
 * false for every key it made. Key generation is now the distributed protocol in `dkg.ts`,
 * which never computes the group secret on any machine; the dealer survives only as a test
 * fixture in `test/dealer.ts`, outside the package's exports, and a test asserts that nothing
 * exported from `src/` can produce or return a group secret.
 */
export interface KeyShare {
  /** Participant identifier. Must be non-zero and distinct; used as the x-coordinate. */
  readonly id: number;
  /** This party's secret share. Never transmitted, never combined with another. */
  readonly share: Scalar;
  /** The group public key, known to everyone. */
  readonly groupPublicKey: PointT;
}

/** Lagrange coefficient for `id` over the signing set, evaluated at zero. */
export function lagrangeCoefficient(id: number, signers: readonly number[]): Scalar {
  if (!signers.includes(id)) throw new Error(`${id} is not in the signing set`);
  let num = 1n;
  let den = 1n;
  for (const j of signers) {
    if (j === id) continue;
    num = Fn.create(num * BigInt(j));
    den = Fn.create(den * BigInt(j - id));
  }
  return Fn.create(num * Fn.inv(den));
}

/* ------------------------------------------------------------------ round one */

/**
 * A party's per-signature nonces: an opaque, single-use handle.
 *
 * The scalars are not on this object. They live in a module-private table keyed by it, and
 * `sign` deletes them before computing the share it returns, so a second `sign` with the same
 * handle throws instead of signing. Reusing a nonce pair across two signatures reveals the
 * secret share by algebra, and "the caller will not do that" is not a control - this used
 * to be a plain `{ hiding, binding }` that `sign` accepted as often as it was passed.
 *
 * It follows that nonces cannot be copied, serialised or restored from storage: a spread
 * copy is not the handle, and a restored one would be the classic way to reuse a nonce
 * (sign, crash, restore, sign again). A party that restarts between rounds commits again.
 */
export interface Nonces {
  /** The participant these were generated for. */
  readonly id: number;
  /** True once `sign` has consumed them. */
  readonly used: boolean;
}

interface NonceSecret {
  readonly hiding: Scalar;
  readonly binding: Scalar;
  readonly commitment: Commitment;
  readonly groupPublicKey: PointT;
}

/** `null` once consumed. A handle absent from the table was not made by `commit`. */
const nonceSecrets = new WeakMap<Nonces, NonceSecret | null>();

/** The public half of round one, broadcast to the coordinator. */
export interface Commitment {
  readonly id: number;
  readonly hiding: PointT;
  readonly binding: PointT;
}

/**
 * RFC 9591 §4.1 `nonce_generate`: H3(random_bytes(32) || SerializeScalar(secret)).
 *
 * A hedge, and only against one failure. Mixing in the secret share means an RNG whose
 * output an attacker can PREDICT or OBSERVE still does not hand them the nonce, because they
 * lack the share. It does nothing against an RNG that REPEATS: the same bytes and the same
 * share give the same nonce, and the message is not an input (round one runs before the
 * message is fixed), so a repeating RNG reuses a nonce across different messages and leaks
 * the share. An earlier comment here claimed a broken RNG "degrades to
 * deterministic-per-message"; it did not, and even that would not be safe in FROST, where
 * the co-signer's commitments vary between sessions for the same message. The defences
 * against reuse are fresh randomness every call and `sign` consuming the nonces.
 *
 * Exported for tests; it returns a bare scalar, which `sign` does not accept.
 */
export function nonceGenerate(secret: Scalar, random: Uint8Array = randomBytes(32)): Scalar {
  if (random.length !== 32) throw new Error('nonce randomness must be 32 bytes');
  return H3(random, scalarToBytes(secret));
}

/**
 * Round one: generate nonces and commit to them.
 *
 * TWO nonces, not one. The binding nonce is what the binding factor multiplies, and that
 * combination is what makes the group nonce independent of ordering - a party that waits to
 * see everyone else's commitments still cannot steer the aggregate. A single-nonce variant
 * is simpler, looks equivalent, and is broken.
 *
 * Each nonce draws its own 32 fresh random bytes, as the RFC does. There is no way to pass
 * the randomness in: an injectable RNG parameter is how a test fixture's constant ends up
 * producing the same nonce for two messages in production.
 */
export function commit(share: KeyShare): { nonces: Nonces; commitment: Commitment } {
  const hiding = nonceGenerate(share.share);
  const binding = nonceGenerate(share.share);
  const commitment: Commitment = {
    id: share.id,
    hiding: Point.BASE.multiply(hiding),
    binding: Point.BASE.multiply(binding),
  };
  const nonces: Nonces = Object.freeze({
    id: share.id,
    get used() { return nonceSecrets.get(nonces) === null; },
  });
  nonceSecrets.set(nonces, { hiding, binding, commitment, groupPublicKey: share.groupPublicKey });
  return { nonces, commitment };
}

/* ------------------------------------------------------------------ round two */

function encodeCommitmentList(list: readonly Commitment[]): Uint8Array {
  const sorted = [...list].sort((a, b) => a.id - b.id);
  return concat(...sorted.flatMap((c) => [
    scalarToBytes(BigInt(c.id)), pointToBytes(c.hiding), pointToBytes(c.binding),
  ]));
}

/**
 * Binding factors, one per participant.
 *
 * Each is a hash over the participant id, the ENTIRE commitment list, and the message. That
 * is the point: because every party's factor depends on every commitment and on the
 * message, no party can choose its own contribution to influence the group nonce after
 * seeing the others. Remove this and the scheme is forgeable.
 */
export function bindingFactors(
  list: readonly Commitment[], msg: Uint8Array, groupPublicKey: PointT,
): Map<number, Scalar> {
  const encoded = encodeCommitmentList(list);
  const msgHash = sha256(msg);
  const out = new Map<number, Scalar>();
  for (const c of list) {
    out.set(c.id, H1(pointToBytes(groupPublicKey), msgHash, encoded, scalarToBytes(BigInt(c.id))));
  }
  return out;
}

/** The aggregate nonce commitment R = sum(D_i + rho_i * E_i). */
export function groupCommitment(
  list: readonly Commitment[], factors: Map<number, Scalar>,
): PointT {
  let R: PointT | null = null;
  for (const c of [...list].sort((a, b) => a.id - b.id)) {
    const rho = factors.get(c.id);
    if (rho === undefined) throw new Error(`no binding factor for participant ${c.id}`);
    const term = c.hiding.add(c.binding.multiply(rho));
    R = R === null ? term : R.add(term);
  }
  if (R === null) throw new Error('empty commitment list');
  return R;
}

/** The Schnorr challenge c = H2(R, PK, msg). */
export function challenge(R: PointT, groupPublicKey: PointT, msg: Uint8Array): Scalar {
  return H2(pointToBytes(R), pointToBytes(groupPublicKey), sha256(msg));
}

export interface SignatureShare {
  readonly id: number;
  readonly z: Scalar;
}

/**
 * Round two: produce this party's signature share.
 *
 * `z_i = d_i + (e_i * rho_i) + lambda_i * s_i * c`
 *
 * The share `s_i` is used here and never leaves this function. Nothing in the returned
 * value lets another party recover it: `z_i` is a single scalar masked by two secret
 * nonces - provided those nonces are used once, which is why this consumes them.
 *
 * The coordinator's commitment list is checked before anything is computed, as RFC 9591
 * §5.2 requires of a signer: identifiers are distinct positive integers, no point is the
 * identity, and this party's OWN commitment appears exactly once and is the one it made.
 * Without that last check a coordinator could substitute a different commitment for this
 * party, and this party would sign against a group nonce it never contributed to.
 *
 * A request that fails validation does not consume the nonces: nothing was computed from
 * them, so nothing leaked. Once validation passes they are consumed before `z` is computed,
 * so no path returns a second share from the same nonces.
 */
export function sign(
  share: KeyShare,
  nonces: Nonces,
  commitments: readonly Commitment[],
  msg: Uint8Array,
): SignatureShare {
  const secret = nonceSecrets.get(nonces);
  if (secret === undefined) {
    throw new Error('these nonces were not produced by commit() in this process; nonces '
      + 'cannot be copied, serialised or restored - commit again');
  }
  if (secret === null) {
    throw new Error(`the nonces for participant ${nonces.id} were already used: signing twice `
      + 'with one nonce pair reveals the secret share - commit again');
  }
  if (nonces.id !== share.id || !secret.groupPublicKey.equals(share.groupPublicKey)) {
    throw new Error(`these nonces were made for participant ${nonces.id}'s share, not this one`);
  }

  const signers = commitments.map((c) => c.id);
  if (new Set(signers).size !== signers.length) {
    throw new Error('the commitment list repeats a participant identifier');
  }
  for (const c of commitments) {
    if (!Number.isSafeInteger(c.id) || c.id < 1) {
      throw new Error(`invalid participant identifier ${c.id}`);
    }
    if (c.hiding.is0() || c.binding.is0()) {
      throw new Error(`participant ${c.id}'s commitment contains the identity point`);
    }
  }
  const own = commitments.filter((c) => c.id === share.id);
  if (own.length !== 1) {
    throw new Error(`participant ${share.id}'s own commitment is not among the commitments`);
  }
  if (!own[0]!.hiding.equals(secret.commitment.hiding)
    || !own[0]!.binding.equals(secret.commitment.binding)) {
    throw new Error(`the commitment list carries a commitment for participant ${share.id} `
      + 'that is not the one it made in round one');
  }

  // Consumed before use: whatever happens below, these nonces never produce another share.
  nonceSecrets.set(nonces, null);

  const factors = bindingFactors(commitments, msg, share.groupPublicKey);
  const R = groupCommitment(commitments, factors);
  const c = challenge(R, share.groupPublicKey, msg);
  const rho = factors.get(share.id)!;
  const lambda = lagrangeCoefficient(share.id, signers);

  const z = Fn.create(
    secret.hiding + Fn.create(secret.binding * rho) + Fn.create(lambda * share.share * c),
  );
  return { id: share.id, z };
}

/* ------------------------------------------------------------------ aggregation */

export interface Signature {
  /** Aggregate nonce commitment. */
  readonly R: PointT;
  /** Aggregate scalar. */
  readonly z: Scalar;
}

/**
 * Sum the shares into one signature.
 *
 * The coordinator doing this is untrusted: it learns nothing it did not already have, and a
 * dishonest coordinator can only produce an invalid signature, which `verify` rejects. It
 * cannot produce a valid signature over a different message.
 */
export function aggregate(
  commitments: readonly Commitment[],
  shares: readonly SignatureShare[],
  msg: Uint8Array,
  groupPublicKey: PointT,
): Signature {
  const ids = new Set(commitments.map((c) => c.id));
  for (const s of shares) {
    if (!ids.has(s.id)) throw new Error(`signature share from uncommitted participant ${s.id}`);
  }
  if (shares.length !== commitments.length) {
    throw new Error(`expected ${commitments.length} shares, got ${shares.length}`);
  }
  const factors = bindingFactors(commitments, msg, groupPublicKey);
  const R = groupCommitment(commitments, factors);
  const z = shares.reduce((acc, s) => Fn.create(acc + s.z), 0n);
  return { R, z };
}

/** Verify: `z*G == R + c*PK`. Ordinary single-signer Schnorr verification. */
export function verify(sig: Signature, msg: Uint8Array, groupPublicKey: PointT): boolean {
  try {
    const c = challenge(sig.R, groupPublicKey, msg);
    const lhs = Point.BASE.multiply(Fn.create(sig.z));
    const rhs = sig.R.add(groupPublicKey.multiply(c));
    return lhs.toHex(true) === rhs.toHex(true);
  } catch {
    return false;
  }
}

/**
 * Verify one party's share before aggregating.
 *
 * `z_i*G == D_i + rho_i*E_i + lambda_i*c*PK_i`
 *
 * Worth doing because it identifies WHICH party misbehaved. Without it a bad share only
 * shows up as an invalid aggregate, and the coordinator cannot tell whether the fault is
 * the device, the server, or itself.
 */
export function verifyShare(
  s: SignatureShare,
  commitments: readonly Commitment[],
  msg: Uint8Array,
  groupPublicKey: PointT,
  publicShare: PointT,
): boolean {
  try {
    const signers = commitments.map((c) => c.id);
    const factors = bindingFactors(commitments, msg, groupPublicKey);
    const R = groupCommitment(commitments, factors);
    const c = challenge(R, groupPublicKey, msg);
    const own = commitments.find((x) => x.id === s.id);
    if (!own) return false;
    const rho = factors.get(s.id)!;
    const lambda = lagrangeCoefficient(s.id, signers);

    const lhs = Point.BASE.multiply(Fn.create(s.z));
    const rhs = own.hiding
      .add(own.binding.multiply(rho))
      .add(publicShare.multiply(Fn.create(lambda * c)));
    return lhs.toHex(true) === rhs.toHex(true);
  } catch {
    return false;
  }
}

/** The public counterpart of a share, for `verifyShare`. */
export function publicShareOf(share: KeyShare): PointT {
  return Point.BASE.multiply(share.share);
}

export { Point, ORDER };
