import { describe, expect, it, beforeAll } from 'vitest';
import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
import { EVM } from '@ethereumjs/evm';
import { Common, Chain, Hardfork } from '@ethereumjs/common';
import { Address, hexToBytes, bytesToHex } from '@ethereumjs/util';
import { keccak_256 } from '@noble/hashes/sha3';
import { dkgRound1, dkgRound2, dkgFinalize, dkgContext, type DkgParams } from '../src/dkg.js';
import { DkgSession, generateDkgKey, secp256k1Auth, type DkgWireMessage } from '../src/dkg-transport.js';
import { commit, sign, aggregate, verify, type KeyShare } from '../src/frost.js';

/**
 * DKG keys, verified ON-CHAIN by the contract that will actually check them.
 *
 * `contracts/test/SchnorrVerifier.t.sol` checks pasted vectors under forge. This checks FRESH
 * keys every run: a real DKG, a real signing session, then `FrostSigner.isValidSignature` on an
 * EVM, compiled from the same source file. It follows the @ethereumjs/evm harness pattern of
 * `packages/viewing-key/test/evm.ts`, with constructor arguments, which that one does not need.
 *
 * The last case runs the DKG over the TRANSPORT (`dkg-transport.ts`) rather than in process, so
 * the key a device and the co-signer would generate over HTTP is the one the contract accepts.
 */

const require_ = createRequire(import.meta.url);
const SOURCE = new URL('../../../contracts/SchnorrVerifier.sol', import.meta.url);

function compileFrostSigner(): string {
  const solc = require_('solc') as { compile(input: string): string };
  const out = JSON.parse(solc.compile(JSON.stringify({
    language: 'Solidity',
    sources: { 'SchnorrVerifier.sol': { content: readFileSync(SOURCE, 'utf8') } },
    settings: {
      optimizer: { enabled: true, runs: 10_000 },
      outputSelection: { '*': { '*': ['evm.bytecode.object'] } },
    },
  }))) as {
    contracts?: Record<string, Record<string, { evm: { bytecode: { object: string } } }>>;
    errors?: { severity: string; formattedMessage: string }[];
  };
  const fatal = (out.errors ?? []).filter((e) => e.severity === 'error');
  if (fatal.length) throw new Error(fatal.map((e) => e.formattedMessage).join('\n'));
  return out.contracts!['SchnorrVerifier.sol']!.FrostSigner!.evm.bytecode.object;
}

const word = (v: bigint) => v.toString(16).padStart(64, '0');
const selector = (sig: string) => bytesToHex(keccak_256(new TextEncoder().encode(sig))).slice(2, 10);
const DEPLOYER = new Address(hexToBytes(`0x${'11'.repeat(20)}`));
const BLOCK = {
  header: {
    number: 1n, cliqueSigner: () => Address.zero(), coinbase: Address.zero(), timestamp: 1_700_000_000n,
    difficulty: 0n, prevRandao: new Uint8Array(32), gasLimit: 30_000_000n, baseFeePerGas: 0n,
    getBlobGasPrice: () => 0n,
  },
} as never;

let evm: EVM;
let bytecode: string;

async function deploySigner(key: KeyShare): Promise<Address> {
  const pk = key.groupPublicKey.toAffine();
  const res = await evm.runCall({
    caller: DEPLOYER, data: hexToBytes(`0x${bytecode}${word(pk.x)}${word(pk.y)}`),
    gasLimit: 5_000_000n, block: BLOCK,
  });
  if (res.execResult.exceptionError) throw new Error(`deploy: ${res.execResult.exceptionError.error}`);
  return res.createdAddress!;
}

/** isValidSignature(bytes32,bytes) with abi.encode(rx, ry, z); returns the 4-byte result. */
async function isValidSignature(signer: Address, digest: Uint8Array, sig: { R: { toAffine(): { x: bigint; y: bigint } }; z: bigint }) {
  const R = sig.R.toAffine();
  const data = selector('isValidSignature(bytes32,bytes)') + bytesToHex(digest).slice(2)
    + word(0x40n) + word(96n) + word(R.x) + word(R.y) + word(sig.z);
  const res = await evm.runCall({
    caller: DEPLOYER, to: signer, data: hexToBytes(`0x${data}`), gasLimit: 1_000_000n, block: BLOCK,
  });
  if (res.execResult.exceptionError) return `revert: ${res.execResult.exceptionError.error}`;
  return bytesToHex(res.execResult.returnValue).slice(0, 10);
}

function runDkg(p: DkgParams): Map<number, KeyShare> {
  const r1 = new Map(p.participants.map((id) => [id, dkgRound1(id, p)]));
  const all = [...r1.values()].map((r) => r.broadcast);
  const r2 = new Map(p.participants.map((id) => [id, dkgRound2(r1.get(id)!.state, all.filter((b) => b.from !== id))]));
  const msgs = [...r2.values()].flatMap((r) => r.messages);
  return new Map(p.participants.map((id) => [
    id, dkgFinalize(r2.get(id)!.state, msgs.filter((m) => m.to === id)).keyShare,
  ]));
}

function frostSign(signers: KeyShare[], digest: Uint8Array) {
  const rounds = signers.map((s) => ({ share: s, ...commit(s) }));
  const commitments = rounds.map((r) => r.commitment);
  const partials = rounds.map((r) => sign(r.share, r.nonces, commitments, digest));
  return aggregate(commitments, partials, digest, signers[0]!.groupPublicKey);
}

const MAGIC_1271 = '0x1626ba7e';

beforeAll(async () => {
  // Cancun, because solc 0.8.28 targets it by default (MCOPY), exactly as forge builds it.
  evm = await EVM.create({ common: new Common({ chain: Chain.Mainnet, hardfork: Hardfork.Cancun }) });
  bytecode = compileFrostSigner();
}, 120_000);

describe('DKG keys verify on-chain through FrostSigner', () => {
  it('2-of-2: a DKG group signs a digest the contract accepts', async () => {
    const keys = runDkg({ context: dkgContext('onchain-2of2'), threshold: 2, participants: [1, 2] });
    const [device, server] = [keys.get(1)!, keys.get(2)!];
    const signer = await deploySigner(device);
    const digest = keccak_256(new TextEncoder().encode('SafeOp digest stand-in'));
    const sig = frostSign([device, server], digest);
    expect(verify(sig, digest, device.groupPublicKey)).toBe(true);
    expect(await isValidSignature(signer, digest, sig)).toBe(MAGIC_1271);
    // ...and not for any other digest.
    expect(await isValidSignature(signer, keccak_256(digest), sig)).toBe('0x00000000');
  });

  it('a key generated over the transport is accepted by the contract, for the transcript both sides signed', async () => {
    const ids = [1, 2];
    const keys = new Map(ids.map((id) => [id, generateDkgKey()]));
    const identities = new Map([...keys].map(([id, k]) => [id, k.publicKey]));
    const params: DkgParams = { context: dkgContext('onchain-transport'), threshold: 2, participants: ids };
    const sessions = new Map(ids.map((id) => [id, DkgSession.open({
      party: id, params, identities,
      auth: secp256k1Auth({ secretKey: keys.get(id)!.secretKey, publicKeys: identities }),
    })]));
    const round1: DkgWireMessage[] = [];
    for (const s of sessions.values()) round1.push(await s.broadcast());
    const round2: DkgWireMessage[] = [];
    for (const [id, s] of sessions) round2.push(...await s.round2(round1.filter((m) => m.from !== id)));
    const shares: KeyShare[] = [];
    const confirmations: DkgWireMessage[] = [];
    for (const [id, s] of sessions) {
      const { result, confirmation } = await s.finish(round2.filter((m) => m.to === id));
      shares.push(result.keyShare);
      confirmations.push(confirmation);
    }
    for (const [id, s] of sessions) await s.confirm(confirmations.filter((m) => m.to === id));
    expect(sessions.get(1)!.transcript).toBe(sessions.get(2)!.transcript);

    const signer = await deploySigner(shares[0]!);
    const digest = keccak_256(new TextEncoder().encode('a key made over the wire'));
    const sig = frostSign(shares, digest);
    expect(verify(sig, digest, shares[0]!.groupPublicKey)).toBe(true);
    expect(await isValidSignature(signer, digest, sig)).toBe(MAGIC_1271);
    expect(await isValidSignature(signer, digest, frostSign([shares[0]!], digest))).toBe('0x00000000');
  });

  it('2-of-3: every pair produces a signature the contract accepts; one party alone does not', async () => {
    const keys = runDkg({ context: dkgContext('onchain-2of3'), threshold: 2, participants: [1, 2, 3] });
    const signer = await deploySigner(keys.get(1)!);
    for (const pair of [[1, 2], [1, 3], [2, 3]]) {
      const digest = keccak_256(new TextEncoder().encode(`pair ${pair}`));
      const sig = frostSign(pair.map((id) => keys.get(id)!), digest);
      expect(await isValidSignature(signer, digest, sig)).toBe(MAGIC_1271);
    }
    const digest = keccak_256(new TextEncoder().encode('alone'));
    const solo = frostSign([keys.get(2)!], digest);
    expect(await isValidSignature(signer, digest, solo)).toBe('0x00000000');
  });
});
