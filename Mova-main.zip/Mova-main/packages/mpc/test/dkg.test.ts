import { describe, expect, it } from 'vitest';
import { readFileSync, readdirSync } from 'node:fs';
import {
  dkgRound1, dkgRound2, dkgFinalize, dkgContext, dkgSessionId, dkgProofChallenge, DkgError,
  MIN_DKG_CONTEXT_BYTES,
  type DkgParams, type DkgRound1Package, type DkgShareMessage, type DkgResult,
} from '../src/dkg.js';
import {
  commit, sign, aggregate, verify, verifyShare, lagrangeCoefficient, Point, ORDER,
  randomScalar, hashToScalar, type KeyShare, type Scalar,
} from '../src/frost.js';

const Fn = Point.Fn;
const msg = (s: string) => new TextEncoder().encode(s);
const params = (threshold: number, participants: number[], label = 'test-dkg'): DkgParams => ({
  context: dkgContext(label), threshold, participants,
});

/**
 * Run every party honestly, in one process, and keep every message - so the tests can inspect
 * what each party saw. Production never does this: each party runs on its own machine.
 */
function runDkg(p: DkgParams) {
  const r1 = new Map(p.participants.map((id) => [id, dkgRound1(id, p)]));
  const broadcasts = [...r1.values()].map((r) => r.broadcast);
  const r2 = new Map(p.participants.map((id) => [
    id, dkgRound2(r1.get(id)!.state, broadcasts.filter((b) => b.from !== id)),
  ]));
  const allMessages = [...r2.values()].flatMap((r) => r.messages);
  const results = new Map<number, DkgResult>(p.participants.map((id) => [
    id, dkgFinalize(r2.get(id)!.state, allMessages.filter((m) => m.to === id)),
  ]));
  return { r1, broadcasts, r2, allMessages, results };
}

function signWith(shares: KeyShare[], m: Uint8Array) {
  const rounds = shares.map((s) => ({ share: s, ...commit(s) }));
  const commitments = rounds.map((r) => r.commitment);
  const partials = rounds.map((r) => sign(r.share, r.nonces, commitments, m));
  return { commitments, partials, sig: aggregate(commitments, partials, m, shares[0]!.groupPublicKey) };
}

/** TEST ONLY: interpolate the group secret from t shares, to check nothing else reveals it. */
function interpolateForTesting(shares: KeyShare[]): Scalar {
  const ids = shares.map((s) => s.id);
  return shares.reduce((acc, s) => Fn.create(acc + lagrangeCoefficient(s.id, ids) * s.share), 0n);
}

function expectDkgError(fn: () => unknown, code: string, culprits: number[]) {
  try {
    fn();
  } catch (e) {
    expect(e).toBeInstanceOf(DkgError);
    expect((e as DkgError).code).toBe(code);
    expect((e as DkgError).culprits).toEqual(culprits);
    return e as DkgError;
  }
  throw new Error(`expected DkgError ${code}`);
}

describe('DKG: keys that sign through the existing FROST path', () => {
  it('2-of-2: both parties agree on one group key and sign under it', () => {
    const { results } = runDkg(params(2, [1, 2]));
    const [a, b] = [results.get(1)!, results.get(2)!];
    expect(a.publicKeys.groupPublicKey.equals(b.publicKeys.groupPublicKey)).toBe(true);
    expect(a.publicKeys.transcript).toBe(b.publicKeys.transcript);
    const m = msg('pay R$ 250,00');
    const { sig, commitments, partials } = signWith([a.keyShare, b.keyShare], m);
    expect(verify(sig, m, a.publicKeys.groupPublicKey)).toBe(true);
    // The verification shares every party computed identify each partial.
    partials.forEach((z) => {
      expect(verifyShare(z, commitments, m, a.publicKeys.groupPublicKey,
        b.publicKeys.verificationShares.get(z.id)!)).toBe(true);
    });
  });

  it('2-of-3: every pair signs under the same key; one party alone does not', () => {
    const { results } = runDkg(params(2, [1, 2, 3]));
    const Y = results.get(1)!.publicKeys.groupPublicKey;
    for (const id of [2, 3]) expect(results.get(id)!.publicKeys.groupPublicKey.equals(Y)).toBe(true);
    for (const pair of [[1, 2], [1, 3], [2, 3]]) {
      const m = msg(`pair ${pair}`);
      const { sig } = signWith(pair.map((id) => results.get(id)!.keyShare), m);
      expect(verify(sig, m, Y)).toBe(true);
    }
    const m = msg('alone');
    expect(verify(signWith([results.get(1)!.keyShare], m).sig, m, Y)).toBe(false);
  });

  it('3-of-5 with non-contiguous identifiers', () => {
    const ids = [3, 7, 11, 19, 42];
    const { results } = runDkg(params(3, ids));
    const m = msg('three of five');
    const { sig } = signWith([7, 19, 42].map((id) => results.get(id)!.keyShare), m);
    expect(verify(sig, m, results.get(3)!.publicKeys.groupPublicKey)).toBe(true);
  });

  it('every party derives every verification share, and each matches that party\'s share', () => {
    const { results } = runDkg(params(2, [1, 2, 3]));
    for (const viewer of results.values()) {
      for (const owner of results.values()) {
        expect(viewer.publicKeys.verificationShares.get(owner.keyShare.id)!
          .equals(Point.BASE.multiply(owner.keyShare.share))).toBe(true);
      }
    }
  });
});

describe('DKG: the group secret is never materialised', () => {
  it('no participant\'s transcript contains the secret or any scalar behind the group key', () => {
    const { results, allMessages, broadcasts } = runDkg(params(2, [1, 2, 3]));
    const Y = results.get(1)!.publicKeys.groupPublicKey;
    // Computed HERE, in the test, from two parties' outputs: the only place it ever exists.
    const secret = interpolateForTesting([results.get(1)!.keyShare, results.get(2)!.keyShare]);
    expect(Point.BASE.multiply(secret).equals(Y)).toBe(true);

    for (const id of [1, 2, 3]) {
      // Everything party `id` holds or saw: its own share, every share sent to or by it, and
      // every public proof scalar.
      const seen: Scalar[] = [
        results.get(id)!.keyShare.share,
        ...allMessages.filter((m) => m.to === id || m.from === id).map((m) => m.share),
        ...broadcasts.map((b) => b.proof.mu),
      ];
      for (const s of seen) {
        expect(s).not.toBe(secret);
        expect(Point.BASE.multiply(s).equals(Y)).toBe(false);
      }
    }
  });

  it('no party\'s key share is the group key, and one share is not enough to interpolate it', () => {
    const { results } = runDkg(params(2, [1, 2]));
    const Y = results.get(1)!.publicKeys.groupPublicKey;
    for (const r of results.values()) {
      expect(Point.BASE.multiply(r.keyShare.share).equals(Y)).toBe(false);
      expect(Point.BASE.multiply(interpolateForTesting([r.keyShare])).equals(Y)).toBe(false);
    }
  });

  it('round state handles carry no secret material', () => {
    const p = params(2, [1, 2]);
    const { state, broadcast } = dkgRound1(1, p);
    expect(Object.keys(state).sort()).toEqual(['id', 'session', 'used']);
    // The broadcast is public by design: commitments, R and μ.
    expect(Object.keys(broadcast).sort()).toEqual(['commitments', 'from', 'proof', 'session']);
  });

  /**
   * The structural half of the claim. `trustedDealerKeygen` drew the group secret on one
   * machine; it now lives in test/dealer.ts, and nothing the package exports can produce or
   * return a group secret. If someone moves a dealer back into src/, this fails.
   */
  it('the package exports no dealer and no function that assembles a group secret', async () => {
    const exported = Object.keys(await import('../src/index.js'));
    expect(exported.filter((n) => /dealer|split|reconstruct|interpolate|groupSecret/i.test(n)))
      .toEqual([]);
    const srcDir = new URL('../src/', import.meta.url);
    for (const file of readdirSync(srcDir)) {
      const code = readFileSync(new URL(file, srcDir), 'utf8')
        .split('\n').filter((l) => !/^\s*(\*|\/\/|\/\*)/.test(l)).join('\n');
      expect(code, file).not.toMatch(/trustedDealer|function\s+split\s*\(/);
    }
  });
});

describe('DKG: every proof of possession is verified, and blame is assigned', () => {
  it('rejects a package whose proof was tampered with, naming the sender', () => {
    const p = params(2, [1, 2, 3]);
    const [a, b, c] = [1, 2, 3].map((id) => dkgRound1(id, p));
    const forged: DkgRound1Package = { ...c!.broadcast, proof: { ...c!.broadcast.proof, mu: Fn.create(c!.broadcast.proof.mu + 1n) } };
    const err = expectDkgError(() => dkgRound2(a!.state, [b!.broadcast, forged]),
      'bad-proof-of-possession', [3]);
    expect(err.message).toMatch(/participant 3/);
  });

  /**
   * The rogue-key attack PedPoP exists to stop: participant 2 waits for participant 1's
   * commitment and publishes X - C_10, so the group key is X, which it chose. It cannot prove
   * possession of that constant term - it does not know its discrete log.
   */
  it('rejects a rogue-key commitment, since its author cannot prove possession', () => {
    const p = params(2, [1, 2]);
    const honest = dkgRound1(1, p);
    const x = randomScalar();
    const rogue0 = Point.BASE.multiply(x).subtract(honest.broadcast.commitments[0]!);
    // The best it can do: a proof made for some other constant it does know.
    const k = randomScalar();
    const R = Point.BASE.multiply(k);
    const mu = Fn.create(k + randomScalar() * dkgProofChallenge(honest.broadcast.session, 2, rogue0, R));
    const rogue: DkgRound1Package = {
      from: 2, session: honest.broadcast.session,
      commitments: [rogue0, Point.BASE.multiply(randomScalar())], proof: { R, mu },
    };
    expectDkgError(() => dkgRound2(honest.state, [rogue]), 'bad-proof-of-possession', [2]);
  });

  it('rejects a genuine proof replayed under another session context', () => {
    const ids = [1, 2];
    const first = params(2, ids, 'session-A');
    const second = params(2, ids, 'session-B');
    const old = dkgRound1(2, first).broadcast;
    const victim = dkgRound1(1, second);
    // Re-labelled with the new session id so it gets past the session check: the proof's
    // challenge still commits to the OLD context, so it does not verify.
    const replay: DkgRound1Package = { ...old, session: victim.broadcast.session };
    expectDkgError(() => dkgRound2(victim.state, [replay]), 'bad-proof-of-possession', [2]);
    // Unmodified, it is refused one step earlier.
    const victim2 = dkgRound1(1, second);
    expectDkgError(() => dkgRound2(victim2.state, [old]), 'wrong-session', [2]);
  });

  it('rejects another participant\'s genuine proof copied under a different identifier', () => {
    const p = params(2, [1, 2, 3]);
    const [a, b] = [1, 2].map((id) => dkgRound1(id, p));
    const copy: DkgRound1Package = { ...b!.broadcast, from: 3 };
    expectDkgError(() => dkgRound2(a!.state, [b!.broadcast, copy]), 'bad-proof-of-possession', [3]);
  });

  /**
   * A zero constant term has a trivially valid proof (μ = k), which is why the identity point
   * is refused outright: such a party would contribute nothing and could bias the key.
   */
  it('rejects a zero secret (the identity commitment), even with an otherwise valid proof', () => {
    const p = params(2, [1, 2]);
    const honest = dkgRound1(1, p);
    const k = randomScalar();
    const zeroSecret: DkgRound1Package = {
      from: 2, session: honest.broadcast.session,
      commitments: [Point.ZERO, Point.BASE.multiply(randomScalar())],
      proof: { R: Point.BASE.multiply(k), mu: k },
    };
    const err = expectDkgError(() => dkgRound2(honest.state, [zeroSecret]), 'malformed', [2]);
    expect(err.faults[0]!.detail).toMatch(/identity/);
  });

  it('names every misbehaving participant at once', () => {
    const p = params(2, [1, 2, 3, 4]);
    const [a, b, c, d] = [1, 2, 3, 4].map((id) => dkgRound1(id, p));
    const bad = (pkg: DkgRound1Package) => ({ ...pkg, proof: { ...pkg.proof, mu: 1n } });
    const err = expectDkgError(
      () => dkgRound2(a!.state, [b!.broadcast, bad(c!.broadcast), bad(d!.broadcast)]),
      'bad-proof-of-possession', [3, 4],
    );
    expect(err.faults).toHaveLength(2);
  });

  it('rejects a package with the wrong number of commitments', () => {
    const p = params(3, [1, 2, 3]);
    const [a, b, c] = [1, 2, 3].map((id) => dkgRound1(id, p));
    const short = { ...c!.broadcast, commitments: c!.broadcast.commitments.slice(0, 2) };
    expectDkgError(() => dkgRound2(a!.state, [b!.broadcast, short]), 'malformed', [3]);
  });
});

describe('DKG: identifiers, sessions and missing parties', () => {
  it('refuses duplicate identifiers in the parameters', () => {
    expect(() => dkgRound1(1, params(2, [1, 2, 2]))).toThrow(/identifiers repeat/);
  });

  it('refuses two packages from one participant, naming it', () => {
    const p = params(2, [1, 2, 3]);
    const [a, b, c] = [1, 2, 3].map((id) => dkgRound1(id, p));
    const again = dkgRound1(2, p).broadcast; // a second polynomial under the same id
    expectDkgError(() => dkgRound2(a!.state, [b!.broadcast, again, c!.broadcast]), 'duplicate-message', [2]);
  });

  it('refuses a package claiming our own identifier (a reflection)', () => {
    const p = params(2, [1, 2]);
    const [a, b] = [1, 2].map((id) => dkgRound1(id, p));
    expectDkgError(() => dkgRound2(a!.state, [a!.broadcast, b!.broadcast]), 'unexpected-sender', [1]);
  });

  it('refuses a package from outside the participant set', () => {
    const p = params(2, [1, 2]);
    const [a, b] = [1, 2].map((id) => dkgRound1(id, p));
    const outsider = dkgRound1(9, params(2, [1, 9])).broadcast;
    expectDkgError(() => dkgRound2(a!.state, [b!.broadcast, outsider]), 'unexpected-sender', [9]);
  });

  it('names the participant whose package never arrived', () => {
    const p = params(2, [1, 2, 3]);
    const [a, b] = [1, 2].map((id) => dkgRound1(id, p));
    expectDkgError(() => dkgRound2(a!.state, [b!.broadcast]), 'missing-message', [3]);
  });

  it('requires a session context, and one long enough not to be a constant', () => {
    expect(() => dkgRound1(1, { context: new Uint8Array(0), threshold: 2, participants: [1, 2] }))
      .toThrow(/session context/);
    expect(() => dkgRound1(1, { context: msg('dkg'), threshold: 2, participants: [1, 2] }))
      .toThrow(new RegExp(`at least ${MIN_DKG_CONTEXT_BYTES} bytes`));
    expect(() => dkgRound1(1, { threshold: 2, participants: [1, 2] } as unknown as DkgParams))
      .toThrow(DkgError);
  });

  it('binds the session to the threshold and the participant set, not just the context', () => {
    const context = dkgContext('same context');
    const base = dkgSessionId({ context, threshold: 2, participants: [1, 2, 3] });
    expect(dkgSessionId({ context, threshold: 3, participants: [1, 2, 3] })).not.toBe(base);
    expect(dkgSessionId({ context, threshold: 2, participants: [1, 2, 4] })).not.toBe(base);
    // Order of the list is not part of it: the set is.
    expect(dkgSessionId({ context, threshold: 2, participants: [3, 1, 2] })).toBe(base);
  });

  it('refuses threshold 1, where every share would be the group secret', () => {
    expect(() => dkgRound1(1, params(1, [1, 2]))).toThrow(/need 2 <= t <= n/);
    expect(() => dkgRound1(1, params(3, [1, 2]))).toThrow(/need 2 <= t <= n/);
  });

  it('refuses to run for an identifier outside the participant set', () => {
    expect(() => dkgRound1(5, params(2, [1, 2]))).toThrow(/not among the participants/);
  });
});

describe('DKG: every share is verified against its sender\'s commitments', () => {
  function toFinalize(p: DkgParams) {
    const r1 = new Map(p.participants.map((id) => [id, dkgRound1(id, p)]));
    const all = [...r1.values()].map((r) => r.broadcast);
    const r2 = new Map(p.participants.map((id) => [
      id, dkgRound2(r1.get(id)!.state, all.filter((b) => b.from !== id)),
    ]));
    const inbox = (id: number) => [...r2.values()].flatMap((r) => r.messages).filter((m) => m.to === id);
    return { r2, inbox };
  }

  it('rejects a tampered share and names its sender', () => {
    const { r2, inbox } = toFinalize(params(2, [1, 2, 3]));
    const tampered = inbox(1).map((m) => (m.from === 3 ? { ...m, share: Fn.create(m.share + 1n) } : m));
    expectDkgError(() => dkgFinalize(r2.get(1)!.state, tampered), 'bad-share', [3]);
  });

  it('rejects a share lifted from a message addressed to someone else', () => {
    const { r2, inbox } = toFinalize(params(2, [1, 2, 3]));
    // Participant 3's share for participant 2, re-addressed to 1: it is a genuine evaluation of
    // 3's polynomial, at the wrong point.
    const lifted = { ...inbox(2).find((m) => m.from === 3)!, to: 1 };
    const msgs = inbox(1).map((m) => (m.from === 3 ? lifted : m));
    expectDkgError(() => dkgFinalize(r2.get(1)!.state, msgs), 'bad-share', [3]);
    const { r2: again, inbox: inbox2 } = toFinalize(params(2, [1, 2, 3]));
    const unaltered = inbox2(1).map((m) => (m.from === 3 ? inbox2(2).find((x) => x.from === 3)! : m));
    expectDkgError(() => dkgFinalize(again.get(1)!.state, unaltered), 'misrouted', [3]);
  });

  it('names every sender of a bad share, and a missing one', () => {
    const { r2, inbox } = toFinalize(params(2, [1, 2, 3, 4]));
    const msgs = inbox(1).filter((m) => m.from !== 4)
      .map((m) => (m.from === 2 ? { ...m, share: 5n } : m));
    const err = expectDkgError(() => dkgFinalize(r2.get(1)!.state, msgs), 'bad-share', [2, 4]);
    expect(err.faults.map((f) => f.code)).toEqual(['bad-share', 'missing-message']);
  });

  it('rejects a zero share outright', () => {
    const { r2, inbox } = toFinalize(params(2, [1, 2]));
    const msgs = inbox(1).map((m) => ({ ...m, share: 0n }));
    expectDkgError(() => dkgFinalize(r2.get(1)!.state, msgs), 'malformed', [2]);
  });

  /**
   * Equivocation: participant 3 shows DIFFERENT commitments to 1 and 2, each internally
   * consistent - valid proof, shares that verify against what that recipient saw. Without the
   * transcript check, 1 and 2 would each finish "successfully" with different group keys and
   * fund an address neither can sign for. Blame is necessarily ambiguous (1 cannot tell whether
   * 2 or 3 lied), so the run aborts and names the participant whose view disagreed.
   */
  it('detects a participant equivocating on the round-1 broadcast', () => {
    const p = params(2, [1, 2, 3]);
    const [one, two] = [1, 2].map((id) => dkgRound1(id, p));
    const threeForOne = dkgRound1(3, p);
    const threeForTwo = dkgRound1(3, p);
    const r2one = dkgRound2(one!.state, [two!.broadcast, threeForOne.broadcast]);
    const r2two = dkgRound2(two!.state, [one!.broadcast, threeForTwo.broadcast]);
    const r2threeA = dkgRound2(threeForOne.state, [one!.broadcast, two!.broadcast]);
    const r2threeB = dkgRound2(threeForTwo.state, [one!.broadcast, two!.broadcast]);
    const toOne: DkgShareMessage[] = [
      r2two.messages.find((m) => m.to === 1)!, r2threeA.messages.find((m) => m.to === 1)!,
    ];
    const err = expectDkgError(() => dkgFinalize(r2one.state, toOne), 'inconsistent-transcript', [2]);
    expect(err.message).toMatch(/equivocated/);
    // The share from 3 itself verified: only the transcript comparison caught this.
    expect(err.faults).toHaveLength(1);
    const toTwo = [r2one.messages.find((m) => m.to === 2)!, r2threeB.messages.find((m) => m.to === 2)!];
    expectDkgError(() => dkgFinalize(r2two.state, toTwo), 'inconsistent-transcript', [1]);
  });

  it('rejects a share from another session', () => {
    const { r2, inbox } = toFinalize(params(2, [1, 2]));
    const { inbox: other } = toFinalize(params(2, [1, 2]));
    expectDkgError(() => dkgFinalize(r2.get(1)!.state, other(1)), 'wrong-session', [2]);
    expect(inbox(1)).toHaveLength(1);
  });
});

describe('DKG: round state is single-use', () => {
  it('refuses to run round 2 twice from one round-1 state', () => {
    const p = params(2, [1, 2]);
    const [a, b] = [1, 2].map((id) => dkgRound1(id, p));
    expect(a!.state.used).toBe(false);
    dkgRound2(a!.state, [b!.broadcast]);
    expect(a!.state.used).toBe(true);
    expectDkgError(() => dkgRound2(a!.state, [b!.broadcast]), 'state-reused', []);
  });

  /**
   * A failed run is abandoned, not retried: re-running round 2 against a different peer set
   * would hand this party's polynomial evaluations to whoever those peers are.
   */
  it('consumes the state even when round 2 aborts', () => {
    const p = params(2, [1, 2]);
    const [a, b] = [1, 2].map((id) => dkgRound1(id, p));
    expectDkgError(() => dkgRound2(a!.state, []), 'missing-message', [2]);
    expectDkgError(() => dkgRound2(a!.state, [b!.broadcast]), 'state-reused', []);
  });

  it('refuses a copied or deserialised state', () => {
    const p = params(2, [1, 2]);
    const [a, b] = [1, 2].map((id) => dkgRound1(id, p));
    expectDkgError(() => dkgRound2({ ...a!.state }, [b!.broadcast]), 'foreign-state', []);
    expectDkgError(() => dkgRound2(JSON.parse(JSON.stringify(a!.state)), [b!.broadcast]), 'foreign-state', []);
    expect(a!.state.used).toBe(false);
  });

  it('refuses to finalize twice', () => {
    const p = params(2, [1, 2]);
    const [a, b] = [1, 2].map((id) => dkgRound1(id, p));
    const ra = dkgRound2(a!.state, [b!.broadcast]);
    const rb = dkgRound2(b!.state, [a!.broadcast]);
    dkgFinalize(ra.state, rb.messages);
    expectDkgError(() => dkgFinalize(ra.state, rb.messages), 'state-reused', []);
  });

  it('keeps the proof-of-possession hash out of the signing domains', () => {
    expect(() => hashToScalar('chal', msg('x'))).toThrow(/overlaps a FROST signing domain/);
    expect(() => hashToScalar('ch', msg('al'))).toThrow(/overlaps/);
    expect(() => hashToScalar('nonce2', msg('x'))).toThrow(/overlaps/);
    expect(ORDER).toBe(Fn.ORDER);
  });
});
