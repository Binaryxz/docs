/**
 * Where this browser's wallet seed comes from: a passkey's PRF (the default), or - on an authenticator without PRF -
 * a 2-of-3 split with a recovery code the user writes down. Both go through `openSeed` (packages/smart-account), which
 * refuses to open a wallet with a different source than it was created with: the two derive different seeds, so a
 * silent fallback would open an empty wallet that looks like theft.
 *
 * The seed is returned to the caller and held in memory while the wallet is unlocked. What this module persists is
 * only what identifies the wallet: which source, the credential id, and - on the recovery-code path only - the device
 * share, which that path cannot avoid keeping on the device.
 */
import {
  POOL_SEED_SALT, PrfSeedSource, RecoverableSplitSeedSource, assertionFromAuthenticatorResponse, decodeRecoveryCode, navigatorPasskey, openSeed,
  passkeyPublicKeyFromAssertions, passkeyPublicKeyFromAttestation,
  type AuthenticatorAssertionResponseLike, type AuthenticatorAttestationResponseLike, type PasskeyPublicKey, type WebAuthnAssertion,
} from '@mova/smart-account';
import type { AccountOwnerKey } from '../wallet/account.js';
import type { KeyValue } from '../wallet/stores.js';
import { plainFetch, type Fetch } from '../wallet/remote.js';

export type SeedKind = 'webauthn-prf' | 'split-share';

export interface StoredIdentity {
  v: 1;
  kind: SeedKind;
  /** base64url, for the PRF path: which passkey to ask. */
  credentialId?: string;
  /** hex, for the recovery-code path: the device's share. */
  deviceShare?: string;
  /**
   * The passkey's P-256 public key (hex): the smart account's owner. Read from the registration, or - on a device that
   * never saw it - recovered from two assertions of the credential.
   */
  passkey?: { x: string; y: string };
  /** The smart account kind this wallet's account is: its address depends on it. */
  account?: 'safe' | 'kernel';
  createdAt: number;
}

const IDENTITY_KEY = 'mova:identity:v1';

export function loadIdentity(kv: KeyValue): StoredIdentity | undefined {
  const raw = kv.get(IDENTITY_KEY);
  if (!raw) return undefined;
  try {
    const v = JSON.parse(raw) as StoredIdentity;
    return v.v === 1 && (v.kind === 'webauthn-prf' || v.kind === 'split-share') ? v : undefined;
  } catch {
    return undefined;
  }
}

export const saveIdentity = (kv: KeyValue, id: StoredIdentity): void => kv.set(IDENTITY_KEY, JSON.stringify(id));
export const forgetIdentity = (kv: KeyValue): void => kv.remove(IDENTITY_KEY);

export const b64url = (b: Uint8Array): string => btoa(String.fromCharCode(...b)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
export const fromB64url = (s: string): Uint8Array => Uint8Array.from(atob(s.replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((s.length + 3) % 4)), (c) => c.charCodeAt(0));
const hex = (b: Uint8Array): string => Array.from(b, (x) => x.toString(16).padStart(2, '0')).join('');
const word = (v: bigint): string => `0x${v.toString(16).padStart(64, '0')}`;
const storedKey = (k: PasskeyPublicKey): { x: string; y: string } => ({ x: word(k.x), y: word(k.y) });
const unhex = (s: string): Uint8Array => Uint8Array.from(s.match(/../g) ?? [], (x) => parseInt(x, 16));

export class PasskeyUnavailable extends Error {}
/** The passkey was created, but its authenticator does not support PRF: the wallet needs the recovery-code path. */
export class PrfUnsupported extends Error {}

/** Whether this browser can use passkeys at all: WebAuthn, in a secure context. */
export function passkeySupport(): { available: boolean; reason?: string } {
  const g = globalThis as { PublicKeyCredential?: unknown; isSecureContext?: boolean; navigator?: { credentials?: unknown } };
  if (!g.PublicKeyCredential || !g.navigator?.credentials) return { available: false, reason: 'Este navegador não oferece passkeys (WebAuthn).' };
  if (!g.isSecureContext) return { available: false, reason: 'Passkeys exigem uma conexão segura (https ou localhost).' };
  return { available: true };
}

interface PrfResults { enabled?: boolean; results?: { first?: ArrayBuffer | ArrayBufferView } }
const prfOf = (c: PublicKeyCredential): PrfResults | undefined => (c.getClientExtensionResults() as { prf?: PrfResults }).prf;
const bytesOf = (b: ArrayBuffer | ArrayBufferView): Uint8Array => (b instanceof ArrayBuffer ? new Uint8Array(b) : new Uint8Array(b.buffer, b.byteOffset, b.byteLength));
const randomChallenge = () => crypto.getRandomValues(new Uint8Array(32));

/**
 * One touch per unlock: `openSeed` asks a source whether it is available and then for the seed, and each would be a
 * separate assertion. The PRF output is the same both times, so the first is kept for the second.
 */
function onceEvaluator(get: (salt: Uint8Array) => Promise<Uint8Array | null>, primed?: Uint8Array) {
  let first: Promise<Uint8Array | null> | undefined = primed ? Promise.resolve(primed) : undefined;
  return (salt: Uint8Array) => {
    if (salt !== POOL_SEED_SALT) return get(salt);
    first ??= get(salt);
    return first;
  };
}

async function assertPrf(credentialId?: string): Promise<{ prf: Uint8Array | null; rawId: Uint8Array; assertion?: WebAuthnAssertion }> {
  const cred = await navigator.credentials.get({
    publicKey: {
      challenge: randomChallenge(),
      allowCredentials: credentialId ? [{ type: 'public-key', id: fromB64url(credentialId) as BufferSource }] : [],
      userVerification: 'required',
      extensions: { prf: { eval: { first: POOL_SEED_SALT } } } as AuthenticationExtensionsClientInputs,
    },
  }) as PublicKeyCredential | null;
  if (!cred) throw new PasskeyUnavailable('Nenhuma passkey foi usada.');
  const first = prfOf(cred)?.results?.first;
  let assertion: WebAuthnAssertion | undefined;
  try {
    assertion = assertionFromAuthenticatorResponse(cred.response as unknown as AuthenticatorAssertionResponseLike);
  } catch {
    // Not an ES256 credential: it opens the seed, and cannot own a smart account.
  }
  return { prf: first ? bytesOf(first) : null, rawId: new Uint8Array(cred.rawId), assertion };
}

/**
 * A new wallet on a new passkey: ES256 (P-256), the only key a Safe WebAuthn signer or Kernel's validator verifies, its
 * public key kept as the account's owner. Throws `PrfUnsupported` when the authenticator cannot derive a seed.
 */
export async function createWithPasskey(
  kv: KeyValue, o: { label?: string; accountKind?: 'safe' | 'kernel' } = {},
): Promise<{ identity: StoredIdentity; seed: Uint8Array }> {
  const label = o.label ?? 'Carteira Movva';
  const cred = await navigator.credentials.create({
    publicKey: {
      challenge: randomChallenge(),
      rp: { name: 'Movva' },
      user: { id: crypto.getRandomValues(new Uint8Array(16)), name: label, displayName: label },
      pubKeyCredParams: [{ type: 'public-key', alg: -7 }],
      // No authenticatorAttachment: a phone, a laptop or a USB security key all work.
      authenticatorSelection: { residentKey: 'required', userVerification: 'required' },
      extensions: { prf: { eval: { first: POOL_SEED_SALT } } } as AuthenticationExtensionsClientInputs,
    },
  }) as PublicKeyCredential | null;
  if (!cred) throw new PasskeyUnavailable('A passkey não foi criada.');
  const prf = prfOf(cred);
  const credentialId = b64url(new Uint8Array(cred.rawId));
  let passkey: PasskeyPublicKey;
  try {
    passkey = passkeyPublicKeyFromAttestation(cred.response as unknown as AuthenticatorAttestationResponseLike);
  } catch {
    throw new PasskeyUnavailable('A passkey foi criada, mas não é uma chave P-256 (ES256), a única que a conta inteligente verifica.');
  }
  if (!prf?.enabled && !prf?.results?.first) {
    throw new PrfUnsupported('Esta passkey foi criada, mas o autenticador não oferece a extensão PRF, que deriva a chave da carteira.');
  }
  const primed = prf.results?.first ? bytesOf(prf.results.first) : undefined;
  const evaluate = onceEvaluator(async () => (await assertPrf(credentialId)).prf, primed);
  const { seed } = await openSeed([new PrfSeedSource(evaluate)]);
  const identity: StoredIdentity = {
    v: 1, kind: 'webauthn-prf', credentialId, passkey: storedKey(passkey), ...(o.accountKind ? { account: o.accountKind } : {}),
    createdAt: Math.floor(Date.now() / 1000),
  };
  saveIdentity(kv, identity);
  return { identity, seed };
}

/**
 * Open with a passkey: this device's (`identity`), or - restoring on a new device - whichever synced passkey the user
 * picks, whose PRF derives the same seed.
 */
export async function unlockWithPasskey(kv: KeyValue, identity?: StoredIdentity): Promise<{ identity: StoredIdentity; seed: Uint8Array }> {
  let rawId: Uint8Array | undefined;
  let first: WebAuthnAssertion | undefined;
  const evaluate = onceEvaluator(async () => {
    const r = await assertPrf(identity?.credentialId);
    rawId = r.rawId;
    first = r.assertion;
    return r.prf;
  });
  const { seed } = await openSeed([new PrfSeedSource(evaluate)], identity?.kind ?? 'webauthn-prf');
  const credentialId = identity?.credentialId ?? (rawId ? b64url(rawId) : undefined);
  let passkey = identity?.passkey;
  if (!passkey && credentialId && first) {
    // An assertion carries no public key, but an ECDSA signature has at most two candidates, and a second assertion of
    // the same credential leaves one: the account's owner, found on a device that never saw the registration.
    const second = await navigatorPasskey({ credentialId: fromB64url(credentialId) })(randomChallenge());
    passkey = storedKey(passkeyPublicKeyFromAssertions(first, second));
  }
  const next: StoredIdentity = {
    ...(identity ?? { v: 1 as const, kind: 'webauthn-prf' as const, createdAt: Math.floor(Date.now() / 1000) }),
    ...(credentialId ? { credentialId } : {}), ...(passkey ? { passkey } : {}),
  };
  if (!identity || next.passkey !== identity.passkey || next.credentialId !== identity.credentialId) saveIdentity(kv, next);
  return { identity: next, seed };
}

/** The passkey as the smart account's owner: its stored public key, and `navigator.credentials.get` to sign. */
export function browserAccountOwner(identity: StoredIdentity): AccountOwnerKey | undefined {
  if (identity.kind !== 'webauthn-prf' || !identity.passkey || !identity.credentialId) return undefined;
  return {
    publicKey: { x: BigInt(identity.passkey.x), y: BigInt(identity.passkey.y) },
    sign: navigatorPasskey({ credentialId: fromB64url(identity.credentialId) }),
  };
}

/*////////////////////////////////////////////////////////////
          WITHOUT PRF: A RECOVERY CODE, 2 OF 3 SHARES
////////////////////////////////////////////////////////////*/

/** The id the share server files a wallet's share under: the 4-byte wallet tag every share of it carries. */
export const walletTagOf = (share: Uint8Array): string => hex(share.slice(2, 6));

async function fetchServerShare(sharesUrl: string, tag: string, fetchImpl: Fetch): Promise<Uint8Array> {
  const res = await fetchImpl(`${sharesUrl}/${tag}`);
  if (!res.ok) throw new Error(`share server: ${res.status}`);
  const b = await res.json() as { share?: unknown };
  if (typeof b.share !== 'string' || !/^[0-9a-f]{76}$/.test(b.share)) throw new Error('share server: not a share');
  return unhex(b.share);
}

/**
 * A new wallet without PRF: device share kept here, server share filed with the share server, recovery code returned
 * to be shown ONCE. Any two open the wallet; one alone opens nothing.
 */
export async function createWithRecoveryCode(kv: KeyValue, sharesUrl: string | undefined, fetchImpl: Fetch = plainFetch): Promise<{
  identity: StoredIdentity; seed: Uint8Array; recoveryCode: string;
}> {
  if (!sharesUrl) throw new PasskeyUnavailable('Este deployment não tem servidor de partes: o caminho com código de recuperação precisa dele.');
  const { deviceShare, serverShare, recoveryCode } = RecoverableSplitSeedSource.create();
  const tag = walletTagOf(deviceShare);
  const res = await fetchImpl(sharesUrl, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ id: tag, share: hex(serverShare) }) });
  if (!res.ok) throw new Error(`share server refused the share: ${res.status}`);
  const { seed } = await openSeed([new RecoverableSplitSeedSource({ deviceShare, recoveryCode })], 'split-share');
  const identity: StoredIdentity = { v: 1, kind: 'split-share', deviceShare: hex(deviceShare), createdAt: Math.floor(Date.now() / 1000) };
  saveIdentity(kv, identity);
  return { identity, seed, recoveryCode };
}

/** Open a recovery-code wallet: device share + server share, or the code with either. */
export async function unlockWithShares(kv: KeyValue, args: { identity?: StoredIdentity; recoveryCode?: string; sharesUrl?: string; fetchImpl?: Fetch }): Promise<{
  identity: StoredIdentity; seed: Uint8Array;
}> {
  const deviceShare = args.identity?.deviceShare ? unhex(args.identity.deviceShare) : undefined;
  const code = args.recoveryCode?.trim() || undefined;
  const tagFrom = deviceShare ?? (code ? decodeRecoveryCode(code) : undefined);
  if (!tagFrom) throw new PasskeyUnavailable('Informe o código de recuperação.');
  const sharesUrl = args.sharesUrl;
  const source = new RecoverableSplitSeedSource({
    deviceShare, recoveryCode: code,
    fetchServerShare: sharesUrl ? () => fetchServerShare(sharesUrl, walletTagOf(tagFrom), args.fetchImpl ?? plainFetch) : undefined,
  });
  const { seed } = await openSeed([source], 'split-share');
  const identity = args.identity ?? { v: 1 as const, kind: 'split-share' as const, createdAt: Math.floor(Date.now() / 1000) };
  if (!args.identity) saveIdentity(kv, identity);
  return { identity, seed };
}
