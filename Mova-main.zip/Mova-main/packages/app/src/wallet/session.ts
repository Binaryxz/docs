/**
 * One unlocked wallet: MovvaWallet wired to a deployment, from a root seed, with everything this device keeps sealed.
 *
 * Environment-agnostic on purpose - the prover and the storage are handed in - so the browser app and the headless
 * smoke run (scripts/smoke.ts) open the wallet through exactly this code.
 *
 * What runs where:
 *
 *  - on this device: every key (seed, spending keys, viewing keys, the account's key, sale accounts' keys), note
 *    encryption, withdrawal and commitment proofs, the checks on every LP node answer, the tax year;
 *  - remote, and told only what it must be: the RPC (reads and the account's transactions), the matcher (quotes), the
 *    LP nodes (instructions for this account's orders; a sale's payee), the relayer (a proven withdrawal, which it
 *    cannot alter), the ASP (approved labels, public), and the note vault (ciphertext it cannot read, signed by the
 *    wallet's identity so nobody else can file under it).
 */
import { createPublicClient, createWalletClient, defineChain, formatEther, getAddress, hexToBytes, http, toHex, type Address, type Hex, type PublicClient } from 'viem';
import { privateKeyToAccount } from 'viem/accounts';
import { ChainGrantRegistry, LocalGrantRegistry, VaultClient, ViewingKeyService, commitmentArtifactsFrom, type NoteRecord } from '@mova/viewing-key';
import { newSoftwarePasskeyKey, softwarePasskey, softwarePasskeyKeyFrom, type PasskeyPublicKey } from '@mova/smart-account';
import {
  AuditGrantRegistryRegistrar, BundlerSubmitter, EoaExecutor, LpNodeClient, MatcherClient, MovvaWallet, PP_POOL_ABI, ReshieldRefused, SaleRefused,
  ShieldedLedger, UNITS_PER_CENTAVO, ViemMovvaChain, ceilDiv, movvaLedgerWallets, type AccountExecutor, type AcrossNotes,
  type BuyOptions, type BuyStatus, type LockedOrder, type MovvaBalance, type MovvaTaxYear, type OpenedSale, type Rail, type RailQuote,
  type Reais, type Reshielded, type ResumedSale, type SaleJournalSnapshot, type SaleQuote, type SaleStatus, type VerifiedPayment,
  type WithdrawalProver,
} from '@mova/wallet';
import { DeploymentInvalid, isSmartAccount, type AppDeployment, type SmartAccountConfig, type SmartAccountKind } from '../lib/deployment.js';
import { AccountSetupError, connectCoSigner, openSmartAccount, type AccountOwnerKey, type SmartAccount, type SmartAccountEnv } from './account.js';
import { DevApi } from './dev.js';
import { deriveAccountKey, deriveAccountSalt, deriveDeviceOwnerKeyMaterial, newSaleAccountKey } from './keys.js';
import type {
  GrantState, OrderActivity, PendingSaleItem, RecoveryQueueView, ReshieldActivity, SaleActivity, SellRequest, ShareActivity,
  ShareRequest, WalletPort,
} from './port.js';
import { SaleInterrupted, SaleKeyMissing } from './sale-errors.js';
import type { PushRegistrationLike } from '@mova/cosigner/client';
import { AlertsUnavailableHere, disableRecoveryAlerts, enableRecoveryAlerts, recoveryAlertsView, type AlertsDeps, type AlertsRecord, type RecoveryAlertsView } from './alerts.js';
import { reshieldDeliveryBlocks, shieldedDeliveryCheck, type DeliveryBlock, type DeliveryCheck, type DeliveryReader } from './delivery-check.js';
import { stringify } from '../lib/json.js';
import { HttpAsp, HttpRelayer, MirroredVault, identitySubject, plainFetch, type Fetch } from './remote.js';
import { SealedStore, storeKeyFromSeed, type KeyValue } from './stores.js';

export interface OpenSessionArgs {
  deployment: AppDeployment;
  rootSeed: Uint8Array;
  kv: KeyValue;
  prover: WithdrawalProver;
  /**
   * Where the circuit artifacts are served, in the SDK's layout (`artifacts/commitment.*` under it): audit grants fetch
   * the commitment circuit from there the first time one is shared. The browser app passes its own; without it (Node,
   * scripts/smoke.ts) the SDK's files are used.
   */
  circuitsBaseUrl?: string;
  /**
   * The smart account's owner beside the co-signer: the passkey (`browserAccountOwner`), a software authenticator
   * (scripts/smoke.ts), or 'derive-from-seed' for a wallet opened with a recovery code, which has no passkey key.
   * Ignored for an EOA deployment.
   */
  owner?: AccountOwnerKey | 'derive-from-seed';
  /** The kind this wallet's account is, when known (the stored identity). Unknown: the one deployed, else the default. */
  accountKind?: SmartAccountKind;
  /** RP id and origin for keys this page signs with (sale accounts): the co-signer pins both. Default: the page's. */
  webauthn?: WebAuthnContext;
  fetchImpl?: Fetch;
  wallClock?: () => number;
  /** The PWA service worker's registration, for recovery alerts (src/wallet/push.ts). Without it, alerts are unavailable. */
  pushRegistration?: () => Promise<PushRegistrationLike | undefined>;  /**
   * Open the account as a plain EOA whose key `deriveAccountKey(rootSeed)` yields, even on a smart-account deployment: a sub-wallet
   * (src/wallet/subwallets.ts) is a wallet over its own root, and has no passkey. Gas for it is the dev stack's `ensureGas`.
   */
  eoaAccount?: boolean;
}

export interface WebAuthnContext { rpId: string; origin: string }

/** A sale account's key, as this device keeps it (sealed): a hex EOA key, or a smart account's owner key and salt. */
type SaleKey = Hex | { kind: SmartAccountKind; key: Hex; salt: string };

const pageWebAuthn = (): WebAuthnContext | undefined => {
  const loc = (globalThis as { location?: { hostname: string; origin: string } }).location;
  return loc ? { rpId: loc.hostname, origin: loc.origin } : undefined;
};

/** The user's smart account: the co-signer checked, the owner key, and the kind - the stored one, the deployed one, or the default. */
async function openUserAccount(a: OpenSessionArgs, cfg: SmartAccountConfig, publicClient: PublicClient, fetchImpl: Fetch, webauthn?: WebAuthnContext) {
  const cosigner = await connectCoSigner(cfg, a.deployment.chainId, fetchImpl);
  const env: SmartAccountEnv = {
    config: cfg, chainId: a.deployment.chainId, publicClient, cosigner,
    bundler: new BundlerSubmitter({ url: cfg.bundler, publicClient, fetch: fetchImpl, pollIntervalMs: 1_000, timeoutMs: 120_000 }),
  };
  let owner: AccountOwnerKey;
  if (a.owner === 'derive-from-seed') {
    if (!webauthn) throw new AccountSetupError('não há origem WebAuthn para a chave do aparelho');
    owner = softwarePasskey({ privateKey: softwarePasskeyKeyFrom(deriveDeviceOwnerKeyMaterial(a.rootSeed)), ...webauthn });
  } else if (a.owner) {
    owner = a.owner;
  } else {
    throw new AccountSetupError('a conta inteligente precisa da chave pública da passkey, que este aparelho não tem: desbloqueie de novo com a passkey');
  }
  const kinds = a.accountKind ? [a.accountKind] : [cfg.kind, ...cfg.kinds.filter((k) => k !== cfg.kind)];
  const opened = await Promise.all(kinds.map((kind) => openSmartAccount(env, { kind, owner, salt: deriveAccountSalt(a.rootSeed, kind) })));
  let smart = opened[0]!;
  if (!a.accountKind) {
    for (const candidate of opened) {
      if (await candidate.deployed()) { smart = candidate; break; }
    }
  }
  return { smart, env, owner };
}

export interface RestoreSummary {
  restored: boolean;
  positions: number;
  notes: number;
}

const DONE_BUY: readonly BuyStatus['state'][] = ['delivered', 'cancelled', 'expired', 'delivered_in_the_open'];
const DONE_SALE: readonly SaleStatus['state'][] = ['settled', 'cancelled'];

export const poolIdOf = (chainId: number, pool: Address): string => `pp:${chainId}:${pool.toLowerCase()}`;

export class WalletSession implements WalletPort {
  private readonly listeners = new Set<() => void>();
  private rev = 0;
  readonly dev?: DevApi;
  /** Sale accounts whose sale `sell` is making right now: that sale in progress is not offered to resume meanwhile. */
  private readonly selling = new Set<string>();
  /** Resumes running, by pending id: asked again for the same sale, the running call is returned rather than raced. */
  private readonly resuming = new Map<string, Promise<ResumedSale>>();
  /** Sales whose last resume answered `exit_pending`, with what the user asked for: asked again on every refresh. */
  private readonly waiting = new Map<string, 'continue' | 'cancel'>();
  private readonly resumeErrors = new Map<string, unknown>();
  private pendingSignature = '';

  private constructor(
    readonly deployment: AppDeployment,
    readonly wallet: MovvaWallet,
    readonly chain: ViemMovvaChain,
    readonly account: AccountExecutor,
    readonly publicClient: PublicClient,
    readonly services: { movva: ViewingKeyService },
    readonly ledgers: { movva: ShieldedLedger },
    private readonly store: SealedStore,
    private readonly vault: MirroredVault,
    private readonly grants: ChainGrantRegistry,
    private readonly identity: string,
    private readonly newDevice: boolean,
    private readonly fetchImpl: Fetch,
    private readonly wallClock: () => number,
    private readonly smart?: SmartAccount,
    private readonly env?: SmartAccountEnv,
    private readonly webauthn?: WebAuthnContext,
    private readonly owner?: AccountOwnerKey,
    private readonly pushRegistration?: () => Promise<PushRegistrationLike | undefined>,
  ) {
    if (deployment.dev) this.dev = new DevApi(deployment.dev.url, fetchImpl);
  }

  static async open(a: OpenSessionArgs): Promise<WalletSession> {
    const d = a.deployment;
    const fetchImpl = a.fetchImpl ?? plainFetch;
    const wallClock = a.wallClock ?? (() => Math.floor(Date.now() / 1000));
    const chain = defineChain({
      id: d.chainId, name: d.name, nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 }, rpcUrls: { default: { http: [d.rpcUrl] } },
    });
    const publicClient = createPublicClient({ chain, transport: http(d.rpcUrl), pollingInterval: 1_000 }) as PublicClient;
    const rpcChainId = await publicClient.getChainId();
    if (rpcChainId !== d.chainId) throw new DeploymentInvalid(`a RPC responde pela chain ${rpcChainId}, mas o deployment é da chain ${d.chainId}`);

    const keys = movvaLedgerWallets(a.rootSeed);
    const webauthn = a.webauthn ?? pageWebAuthn();
    let account: AccountExecutor;
    let smart: SmartAccount | undefined;
    let env: SmartAccountEnv | undefined;
    let owner: AccountOwnerKey | undefined;
    if (isSmartAccount(d.account) && !a.eoaAccount) {
      ({ smart, env, owner } = await openUserAccount(a, d.account, publicClient, fetchImpl, webauthn));
      account = smart.executor;
    } else {
      const signer = privateKeyToAccount(deriveAccountKey(a.rootSeed));
      account = new EoaExecutor({ wallet: createWalletClient({ account: signer, chain, transport: http(d.rpcUrl) }), publicClient });
    }
    const c = d.contracts;
    const store = new SealedStore(a.kv, storeKeyFromSeed(a.rootSeed), `mova:${d.chainId}:${c.movvaPool.toLowerCase()}:${account.address.toLowerCase()}:`);
    const newDevice = !store.has('svc:movva');
    // Before the account's first operation: allowlisted by the paymaster, and enrolled with the co-signer (one passkey
    // assertion). A device that already did it, or found it done, does not ask again.
    if (smart && !store.has('account')) {
      await smart.prepare();
      store.write('account', { kind: smart.kind, address: smart.address });
    }

    const grants = new ChainGrantRegistry({ url: d.rpcUrl, registry: c.auditGrantRegistry, fetchImpl });
    const vault = new MirroredVault(grants, { url: d.services.vault, identityPriv: keys.movva.identityPriv, fetchImpl, now: wallClock });
    const movvaScope = await publicClient.readContract({ address: c.movvaPool, abi: PP_POOL_ABI, functionName: 'SCOPE' });
    const mirror = new LocalGrantRegistry();
    const services = {
      movva: new ViewingKeyService(keys.movva, poolIdOf(d.chainId, c.movvaPool), mirror, vault, account.address, undefined, store.walletStore('svc:movva')),
    };
    const ledgers = {
      movva: new ShieldedLedger(services.movva, { pool: c.movvaPool, scope: movvaScope, parRate: 100n, store: store.ledgerStore('ledger:movva') }),
    };
    const lpClients = d.services.lpNodes.map((n) => ({ lp: getAddress(n.lp), client: new LpNodeClient(n.url, fetchImpl) }));
    const movvaChain = new ViemMovvaChain({ publicClient, rpcUrl: d.rpcUrl, deployment: c });
    const wallet = new MovvaWallet({
      chain: movvaChain,
      account, ledgers,
      matcher: new MatcherClient(d.services.matcher, fetchImpl),
      lpNodes: { forLp: (lp) => lpClients.find((n) => n.lp === getAddress(lp))?.client, all: lpClients.map((n) => n.client) },
      prover: a.prover,
      asp: new HttpAsp(d.services.asp, fetchImpl),
      relayer: await HttpRelayer.connect(d.services.relayer, fetchImpl),
      saleVerifier: c.saleVerifier,
      // A PIX charge's location is verified against its site's TLS certificate chain, which a browser does not expose.
      pixLocationHosts: [],
      saleStore: store.saleStore(),
      // Sales in progress (each one's payee, salt and sale account, never its key), sealed like every record here: an
      // interrupted sale survives a reload and can be resumed or re-shielded (MovvaWallet.pendingSales).
      saleJournal: { load: () => store.read('sale-journal'), save: (snapshot) => store.write('sale-journal', snapshot) },
      registrar: new AuditGrantRegistryRegistrar({ registry: c.auditGrantRegistry, account }),
      grantRotations: { source: grants },
      policy: { exitRelayFeeBps: d.policy.exitRelayFeeBps, saleDiscountBps: d.policy.saleDiscountBps },
      ...(a.circuitsBaseUrl ? { commitmentArtifacts: () => commitmentArtifactsFrom({ baseUrl: a.circuitsBaseUrl!, fetchImpl }) } : {}),
      wallClock,
    });
    return new WalletSession(
      d, wallet, movvaChain, account, publicClient, services, ledgers, store, vault, grants, identitySubject(keys.movva.identityPub), newDevice, fetchImpl,
      wallClock, smart, env, webauthn, owner, a.pushRegistration,
    );
  }

  get address(): Address { return this.account.address; }
  /** eoa, or the smart account's kind. */
  get accountKind(): 'eoa' | SmartAccountKind { return this.smart?.kind ?? 'eoa'; }
  /** The co-signer that is the account's second key, for a smart account. */
  get coSigner(): Address | undefined { return this.smart?.coSigner; }
  get exitRelayFeeBps(): bigint { return this.wallet.policy.exitRelayFeeBps; }
  now(): number { return this.wallClock(); }

  /*----------------------------- device ------------------------------*/

  /**
   * On a device with no records of this wallet: rebuild positions from the pools by precommitment (`MovvaWallet.recover`)
   * and, if there were any, the notes from the vault. On any other: file every note with the vault again (it keeps each
   * once), in case one did not reach it.
   *
   * Recovering a wallet with nothing on-chain is harmless: the library starts its next deposit within reach of the next
   * device's scan (recoverByPrecommitment's `nextIndex`), so a restore finds what this device deposits from here on.
   */
  async restoreOrFile(): Promise<RestoreSummary> {
    if (!this.newDevice) {
      await this.vault.fileAll([...this.services.movva.records()], this.identity);
      return { restored: false, positions: 0, notes: 0 };
    }
    const recovered = await this.wallet.recover();
    const found = recovered.movva.positions + recovered.movva.unexplained;
    if (found === 0) return { restored: false, positions: 0, notes: 0 };
    const notes = await this.resyncFromVault();
    return { restored: true, positions: recovered.movva.positions, notes };
  }

  private vaultRecords(client: VaultClient): Promise<NoteRecord[]> {
    const now = this.now();
    const { chainId, contracts } = this.deployment;
    return client.ownerRecords(poolIdOf(chainId, contracts.movvaPool), this.identity, this.services.movva.ownerProof(now));
  }

  /**
   * Fetch this wallet's encrypted notes from the vault and restore those this device lacks. Run on a new device, and
   * again when its balance is refused because notes are missing - another device may have filed them since.
   */
  async resyncFromVault(): Promise<number> {
    if (!this.deployment.services.vault) return 0;
    const movva = await this.vaultRecords(new VaultClient(this.deployment.services.vault, this.fetchImpl));
    const r = this.wallet.resyncNotes({ movva });
    this.changed();
    return r.movva;
  }

  /** Wait for every note written so far to have been offered to the vault. */
  async flushVault(): Promise<void> { await this.vault.flushed(); }

  /** How many of this device's notes the vault holds, and the last filing error. */
  async vaultStatus(): Promise<{ local: { movva: number }; filed: { movva: number }; failures: number; lastError?: string }> {
    const local = { movva: this.services.movva.records().length };
    if (!this.deployment.services.vault) return { local, filed: { movva: 0 }, failures: 0 };
    const movva = await this.vaultRecords(new VaultClient(this.deployment.services.vault, this.fetchImpl));
    return { local, filed: { movva: movva.length }, failures: this.vault.failures, lastError: this.vault.lastError };
  }

  /** On a demo stack: gas for the account, which locks orders and registers grants. A paymaster's job in production. */
  async ensureGas(address: Address = this.address): Promise<void> {
    // A smart account never holds ETH: the paymaster pays each operation.
    if (!this.dev || this.smart) return;
    const balance = await this.publicClient.getBalance({ address });
    if (Number(formatEther(balance)) < 0.05) await this.dev.fund(address);
  }

  /** Forget this wallet on this device: its sealed records. The funds are the chain's; the passkey reopens them. */
  forgetDevice(): void { this.store.clear(); }

  vaultFailures(): number { return this.vault.failures; }

  /*----------------------------- activity ------------------------------*/

  subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  version(): number { return this.rev; }

  private changed(): void {
    this.rev += 1;
    for (const l of this.listeners) l();
  }

  orders(): OrderActivity[] { return this.store.list<OrderActivity>('activity:orders'); }
  sales(): SaleActivity[] { return this.store.list<SaleActivity>('activity:sales'); }
  shares(): ShareActivity[] { return this.store.list<ShareActivity>('activity:shares'); }
  reshields(): ReshieldActivity[] { return this.store.list<ReshieldActivity>('activity:reshields'); }

  private putOrder(o: OrderActivity): void {
    this.store.upsert('activity:orders', o, (x) => x.orderId.toLowerCase() === o.orderId.toLowerCase());
    this.changed();
  }

  private putSale(s: SaleActivity): void {
    this.store.upsert('activity:sales', s, (x) => x.saleId.toLowerCase() === s.saleId.toLowerCase());
    this.changed();
  }

  async refreshActivity(): Promise<void> {
    for (const o of this.orders()) {
      if (o.status && DONE_BUY.includes(o.status.state)) continue;
      await this.buyStatus(o.orderId).catch(() => undefined);
    }
    for (const s of this.sales()) {
      if (s.status && DONE_SALE.includes(s.status.state)) continue;
      await this.saleStatus(s.saleId).catch(() => undefined);
    }
    // A shielded delivery the pool would refuse: read again for every order still waiting to be released, and kept with the
    // order, so a screen can say so wherever it is shown.
    for (const o of this.orders()) {
      const waiting = o.status?.state === 'awaiting_payment' || o.status?.state === 'disputed';
      if (!waiting && !o.delivery) continue;
      const delivery = waiting ? await this.deliveryCheck(o.orderId).catch(() => o.delivery) : undefined;
      if (stringify(delivery ?? null) !== stringify(o.delivery ?? null)) {
        const { delivery: _stale, ...rest } = o;
        this.putOrder(delivery ? { ...rest, delivery } : rest);
      }
    }
    // A sale waiting for the relayer: what the user asked for is asked again, in the background. The wallet sends nothing
    // while the exit may still land, and goes on once it has landed or no longer can.
    for (const [id, intent] of this.waiting) {
      if (!this.resuming.has(id)) void this.resumeSale(id, { cancel: intent === 'cancel' }).catch(() => undefined);
    }
    // The journal changes under a sale being made: screens listing sales in progress read it again when it has.
    const signature = JSON.stringify(this.wallet.pendingSales().map((p) => [p.id, p.stage]));
    if (signature !== this.pendingSignature) {
      this.pendingSignature = signature;
      this.changed();
    }
  }

  /*----------------------------- balance ------------------------------*/

  balance(): Promise<MovvaBalance> { return this.wallet.balance(); }

  /*----------------------------- buying ------------------------------*/

  quoteBuyByRail(amount: Reais, rails: Rail[]): Promise<BuyOptions> { return this.wallet.quoteBuyByRail(amount, rails); }

  async buy(option: RailQuote): Promise<LockedOrder[]> {
    const locked = await this.wallet.buy(option.quote, option.rail);
    const now = this.now();
    for (const o of locked) this.putOrder({ orderId: o.orderId, rail: o.rail, amount: o.amount, createdAt: now, payBy: o.payBy });
    return locked;
  }

  async paymentInstructions(orderId: Hex): Promise<VerifiedPayment> {
    const payment = await this.wallet.paymentInstructions(orderId);
    const o = this.orders().find((x) => x.orderId.toLowerCase() === orderId.toLowerCase());
    if (o) this.putOrder({ ...o, payment, payBy: payment.payBy });
    return payment;
  }

  async buyStatus(orderId: Hex): Promise<BuyStatus> {
    const status = await this.wallet.buyStatus(orderId);
    const o = this.orders().find((x) => x.orderId.toLowerCase() === orderId.toLowerCase());
    if (o && o.status?.state !== status.state) this.putOrder({ ...o, status });
    return status;
  }

  async cancelBuy(orderId: Hex): Promise<void> {
    await this.wallet.cancelBuy(orderId);
    await this.buyStatus(orderId).catch(() => undefined);
  }

  /*----------------------------- a shielded delivery the pool would refuse ------------------------------*/

  /** The chain reads the delivery escape hatch needs (delivery-check.ts): this deployment's chain, and raw calls. */
  private deliveryReader(): DeliveryReader {
    return { chain: this.chain, client: { call: (args) => this.publicClient.call(args) } };
  }

  /**
   * Whether an order locked for delivery into the shielded balance can still be delivered there, read from the chain now:
   * the pool's registration, minimum and `dead()`, and the token issuer's freeze on each party (delivery-check.ts).
   */
  deliveryCheck(orderId: Hex): Promise<DeliveryCheck> { return shieldedDeliveryCheck(this.deliveryReader(), orderId); }

  /** Trade privacy for the money (`MovvaWallet.takeDeliveryDirect`): the order is then released to this account, in the open. */
  async takeDeliveryDirect(orderId: Hex): Promise<void> {
    await this.wallet.takeDeliveryDirect(orderId);
    const delivery = await this.deliveryCheck(orderId).catch(() => undefined);
    const o = this.orders().find((x) => x.orderId.toLowerCase() === orderId.toLowerCase());
    if (o && delivery) this.putOrder({ ...o, delivery });
    else this.changed();
  }

  /** Why the pool would refuse the order's Movva back from this account now; empty when nothing the chain shows stops it. */
  reshieldDeliveryBlocks(orderId: Hex): Promise<DeliveryBlock[]> { return reshieldDeliveryBlocks(this.deliveryReader(), orderId, this.address); }

  /*----------------------------- selling ------------------------------*/

  quoteSale(what: Reais | { boletoLine: string }, opts: { acrossNotes?: AcrossNotes } = {}): Promise<SaleQuote> { return this.wallet.quoteSale(what, opts); }

  /** The account a sale was opened from, rebuilt from the key this device sealed for it. */
  private async saleAccount(address: Address): Promise<AccountExecutor> {
    const record = this.store.read<Record<string, SaleKey>>('sale-keys')?.[address.toLowerCase()];
    if (!record) throw new SaleKeyMissing(address);
    if (typeof record === 'string') {
      const signer = privateKeyToAccount(record);
      const chain = this.publicClient.chain!;
      return new EoaExecutor({ wallet: createWalletClient({ account: signer, chain, transport: http(this.deployment.rpcUrl) }), publicClient: this.publicClient });
    }
    if (!this.env || !this.webauthn) throw new AccountSetupError('esta sessão não abre contas inteligentes');
    const opened = await openSmartAccount(this.env, { kind: record.kind, owner: softwarePasskey({ privateKey: hexToBytes(record.key), ...this.webauthn }), salt: BigInt(record.salt) });
    if (getAddress(opened.address) !== getAddress(address)) throw new Error(`the key sealed for ${address} opens another account`);
    return opened.executor;
  }

  /**
   * A fresh account for one sale, its key sealed here before anything is sent to it.
   *
   * For a smart account: a new account of the user's kind whose owner is a P-256 key made for this sale and held by
   * this page - never the user's passkey, whose signer would name the same owner on-chain and link the sale to every
   * order the user's account locked. The co-signer is its second key, as for every account on this deployment; the
   * paymaster allowlists it and pays its one operation (approve + openSale, recovery installed first).
   */
  private async newSaleAccount(): Promise<AccountExecutor> {
    const keys = this.store.read<Record<string, SaleKey>>('sale-keys') ?? {};
    if (!this.smart) {
      const key = newSaleAccountKey();
      const address = privateKeyToAccount(key).address;
      keys[address.toLowerCase()] = key;
      this.store.write('sale-keys', keys);
      return this.saleAccount(address);
    }
    if (!this.env || !this.webauthn) throw new AccountSetupError('esta sessão não abre contas inteligentes');
    const key = newSoftwarePasskeyKey();
    const salt = BigInt(toHex(crypto.getRandomValues(new Uint8Array(32))));
    const opened = await openSmartAccount(this.env, { kind: this.smart.kind, owner: softwarePasskey({ privateKey: key, ...this.webauthn }), salt });
    keys[opened.address.toLowerCase()] = { kind: this.smart.kind, key: toHex(key), salt: salt.toString() };
    this.store.write('sale-keys', keys);
    await opened.prepare();
    return opened.executor;
  }

  async sell(request: SellRequest): Promise<OpenedSale> {
    const saleAccount = await this.newSaleAccount();
    const key = saleAccount.address.toLowerCase();
    this.selling.add(key);
    try {
      // The sale account approves and opens the sale, which costs gas: the paymaster's, for a smart account; the demo
      // stack's faucet's, for an EOA - never the user's account's, which would link the sale to it.
      if (this.dev && !this.smart) await this.dev.fund(saleAccount.address);
      const across = request.acrossNotes ? { acrossNotes: request.acrossNotes } : {};
      let sale: OpenedSale;
      try {
        sale = 'boletoLine' in request
          ? await this.wallet.sell({ boletoLine: request.boletoLine, saleAccount, ...across })
          : await this.wallet.sell({ receive: request.receive, pixKey: request.pixKey, saleAccount, ...across });
      } catch (e) {
        // Stopped after an exit's proof left this device: the sale is in progress, to continue or give up - never to be
        // sold again from the start, which would begin a second sale while this one's Movva waits.
        const pending = this.wallet.pendingSales().find((p) => p.account.toLowerCase() === key);
        throw pending ? new SaleInterrupted(pending.id, e) : e;
      }
      this.putSale({
        saleId: sale.saleId, rail: sale.rail, receive: sale.receive, cost: sale.cost, fee: sale.fee, account: saleAccount.address,
        payee: 'boletoLine' in request ? request.boletoLine : request.pixKey, dueDate: sale.dueDate, disclosedTo: sale.disclosedTo, createdAt: this.now(),
      });
      return sale;
    } finally {
      this.selling.delete(key);
      this.changed();
    }
  }

  async saleStatus(saleId: Hex): Promise<SaleStatus> {
    const status = await this.wallet.saleStatus(saleId);
    const s = this.sales().find((x) => x.saleId.toLowerCase() === saleId.toLowerCase());
    if (s && s.status?.state !== status.state) this.putSale({ ...s, status });
    return status;
  }

  async cancelSale(saleId: Hex): Promise<void> {
    const s = this.sales().find((x) => x.saleId.toLowerCase() === saleId.toLowerCase());
    if (!s) throw new Error('this device has no record of that sale');
    await this.wallet.cancelSale(saleId, await this.saleAccount(s.account));
    await this.saleStatus(saleId).catch(() => undefined);
  }

  /*----------------------------- sales in progress, and Movva in the open ------------------------------*/

  /** The wallet's sales in progress, with each one's payee from the sealed journal and what this session is doing with it. */
  pendingSales(): PendingSaleItem[] {
    const journal = this.store.read<SaleJournalSnapshot>('sale-journal');
    return this.wallet.pendingSales().map((p) => {
      const payee = journal?.sales[p.id]?.payee;
      const waiting = this.waiting.get(p.id);
      const error = this.resumeErrors.get(p.id);
      return {
        ...p,
        ...(payee ? { payee: payee.kind === 'pix' ? payee.pixKey : payee.line } : {}),
        ...(this.resuming.has(p.id) || this.selling.has(p.account.toLowerCase()) ? { busy: true } : {}),
        ...(waiting ? { waitingForRelayer: waiting } : {}),
        ...(error !== undefined ? { lastError: error } : {}),
      };
    });
  }

  /**
   * Take a sale in progress up where it stopped (`MovvaWallet.resumeSale`), from the account its sealed key opens. One
   * resume per sale at a time: asked again while one runs, the running call is returned.
   */
  resumeSale(id: string, o: { cancel?: boolean } = {}): Promise<ResumedSale> {
    const running = this.resuming.get(id);
    if (running) return running;
    const run = this.runResume(id, o).finally(() => {
      this.resuming.delete(id);
      this.changed();
    });
    this.resuming.set(id, run);
    this.changed();
    return run;
  }

  private async runResume(id: string, o: { cancel?: boolean }): Promise<ResumedSale> {
    const item = this.wallet.pendingSales().find((p) => p.id === id);
    if (!item) {
      this.waiting.delete(id);
      this.resumeErrors.delete(id);
      throw new SaleRefused('this device has no sale in progress with that id', 'no_pending_sale');
    }
    this.resumeErrors.delete(id);
    try {
      const journal = this.store.read<SaleJournalSnapshot>('sale-journal')?.sales[id];
      const payee = journal?.payee ? (journal.payee.kind === 'pix' ? journal.payee.pixKey : journal.payee.line) : '';
      // What every exit takes out of the balance, relay fees included: the sale's cost once they have all landed.
      const cost = ceilDiv((journal?.exits ?? []).reduce((s, x) => s + BigInt(x.amount), 0n), UNITS_PER_CENTAVO);
      const out = await this.wallet.resumeSale(id, { saleAccount: await this.saleAccount(item.account), cancel: o.cancel });
      if (out.state === 'exit_pending') this.waiting.set(id, o.cancel ? 'cancel' : 'continue');
      else this.waiting.delete(id);
      if (out.state === 'open' || out.state === 'claimed' || out.state === 'settled' || out.state === 'disputed') {
        const known = this.sales().find((s) => s.saleId.toLowerCase() === out.saleId.toLowerCase());
        this.putSale({
          saleId: out.saleId, rail: item.rail, receive: item.receive, cost: known?.cost ?? cost, fee: known?.fee ?? cost - BigInt(item.receive),
          account: item.account, payee: known?.payee ?? payee, dueDate: item.dueDate,
          disclosedTo: out.state === 'open' ? out.disclosedTo : Math.max(known?.disclosedTo ?? 0, 1), createdAt: known?.createdAt ?? item.createdAt,
          ...(known?.status ? { status: known.status } : {}),
        });
        await this.saleStatus(out.saleId).catch(() => undefined);
      } else if (out.state === 'reshielded') {
        this.putReshield(out.reshielded, { ref: item.saleId ?? id, ...(item.saleId ? { saleId: item.saleId } : {}) });
        if (item.saleId) await this.saleStatus(item.saleId).catch(() => undefined);
      }
      return out;
    } catch (e) {
      this.resumeErrors.set(id, e);
      // A re-ask that failed hands the sale back to the user, with the reason, rather than asking again forever.
      this.waiting.delete(id);
      throw e;
    }
  }

  /**
   * A sale's Movva back into the shielded balance, from its sale account: a sale in progress is given up through the
   * journal (`resumeSale` with `cancel`), so it stops being in progress; a recorded sale is cancelled first if still open.
   */
  async reshieldSale(ref: string): Promise<Reshielded> {
    const lower = ref.toLowerCase();
    const pending = this.wallet.pendingSales().find((p) => p.id === ref || p.saleId?.toLowerCase() === lower);
    if (pending) {
      const out = await this.resumeSale(pending.id, { cancel: true });
      if (out.state === 'reshielded') return out.reshielded;
      throw out.state === 'exit_pending'
        ? new ReshieldRefused('an exit funding this sale may still land: nothing can be deposited back until it lands or cannot', 'exit_pending')
        : new ReshieldRefused('no exit funding this sale ever landed: nothing left the shielded balance', 'nothing_to_reshield');
    }
    const s = this.sales().find((x) => x.saleId.toLowerCase() === lower);
    if (!s) throw new ReshieldRefused('this device has no sale in progress, nor a recorded sale, with that id', 'no_pending_sale');
    try {
      const r = await this.wallet.reshieldSale(s.saleId, await this.saleAccount(s.account));
      this.putReshield(r, { ref: s.saleId, saleId: s.saleId });
      return r;
    } finally {
      await this.saleStatus(s.saleId).catch(() => undefined);
    }
  }

  /** An order delivered in the open back into the shielded balance, from this account: the deposit is visibly the user's. */
  async reshieldDelivery(orderId: Hex): Promise<Reshielded> {
    const r = await this.wallet.reshieldDelivery(orderId);
    this.putReshield(r, { ref: orderId, orderId });
    return r;
  }

  private putReshield(r: Reshielded, at: { ref: string; saleId?: Hex; orderId?: Hex }): void {
    this.store.upsert<ReshieldActivity>('activity:reshields', {
      source: r.source, ...at, amount: r.amount, fee: r.fee, from: r.from, transactionHash: r.transactionHash, awaitingApproval: r.awaitingApproval,
      createdAt: this.now(),
    }, (x) => x.transactionHash.toLowerCase() === r.transactionHash.toLowerCase());
    this.changed();
  }

  /*----------------------------- audit and tax ------------------------------*/

  async shareWithAuditor(r: ShareRequest): Promise<ShareActivity> {
    const share = await this.wallet.shareWithAuditor(r);
    const activity: ShareActivity = { id: share.grants.map((g) => g.grantId).join('+'), auditor: r.auditor, purpose: r.purpose, createdAt: this.now(), share };
    this.store.upsert('activity:shares', activity, (x) => x.id === activity.id);
    this.changed();
    return activity;
  }

  async revokeAuditor(id: string): Promise<void> {
    const s = this.shares().find((x) => x.id === id);
    if (!s) throw new Error('this device has no record of that share');
    await this.wallet.revokeAuditor(s.share);
    this.store.upsert('activity:shares', { ...s, revokedAt: this.now() }, (x) => x.id === id);
    this.changed();
  }

  /** Each share's state as the AuditGrantRegistry records it now - revocation from any device included. */
  async grantStates(): Promise<Record<string, GrantState>> {
    const shares = this.shares();
    const grantIds = shares.flatMap((s) => s.share.grants.map((g) => g.grantId));
    if (grantIds.length === 0) return {};
    await this.grants.refresh({ owner: this.address, grantIds });
    const now = this.now();
    return Object.fromEntries(shares.map((s) => {
      const statuses = s.share.grants.map((g) => this.grants.statusOf(this.address, g.grantId));
      const state: GrantState = statuses.some((x) => !x?.exists) ? 'unknown'
        : statuses.some((x) => x!.revokedAt > 0) ? 'revoked'
          : now > s.share.expiresAt ? 'expired' : 'active';
      return [s.id, state];
    }));
  }

  taxYear(year: number): MovvaTaxYear { return this.wallet.taxYear(year); }

  /*----------------------------- recovery alerts ------------------------------*/

  private alertsDeps(): AlertsDeps | undefined {
    const { smart, env, owner, store } = this;
    if (!smart || !env || !owner) return undefined;
    return {
      cosigner: env.cosigner, account: smart.address, coSigner: smart.coSigner, sign: (challenge) => owner.sign(challenge),
      registration: this.pushRegistration ?? (async () => undefined),
      record: { read: () => store.read<AlertsRecord>('alerts'), write: (r) => store.write('alerts', r), remove: () => store.remove('alerts') },
      now: () => this.now(),
    };
  }

  /** Whether this device can receive recovery alerts, and whether it does (src/wallet/alerts.ts). */
  recoveryAlerts(): Promise<RecoveryAlertsView> { return recoveryAlertsView(this.alertsDeps()); }

  /** Subscribe this device, with the passkey. Answers the one-time offer too. */
  async enableRecoveryAlerts(): Promise<void> {
    const d = this.alertsDeps();
    if (!d) throw new AlertsUnavailableHere('eoa');
    await enableRecoveryAlerts(d);
    if (!this.store.has('alerts-offer')) this.store.write('alerts-offer', { at: this.now(), answer: 'on' });
    this.changed();
  }

  /** Unsubscribe this device, with the passkey. Refused by the co-signer while a recovery is queued. */
  async disableRecoveryAlerts(): Promise<void> {
    const d = this.alertsDeps();
    if (!d) throw new AlertsUnavailableHere('eoa');
    await disableRecoveryAlerts(d);
    this.changed();
  }

  /** Whether the offer to turn alerts on, shown once after onboarding, was answered on this device. */
  recoveryAlertsOffered(): boolean { return this.store.has('alerts-offer'); }

  dismissRecoveryAlertsOffer(): void {
    if (!this.store.has('alerts-offer')) this.store.write('alerts-offer', { at: this.now(), answer: 'later' });
    this.changed();
  }

  /*----------------------------- recovery ------------------------------*/

  /** What the account's recovery Delay holds, as the co-signer reads it. Nothing for an EOA. */
  async recoveryQueue(): Promise<RecoveryQueueView> {
    return this.smart ? this.smart.queue() : { installed: false, pending: [] };
  }

  /** Veto every queued recovery transaction: an operation of `setTxNonce` alone, the passkey's and the co-signer's. */
  async vetoRecovery(): Promise<void> {
    if (!this.smart) throw new AccountSetupError('uma conta EOA não tem fila de recuperação');
    await this.smart.veto();
    this.changed();
  }
}
