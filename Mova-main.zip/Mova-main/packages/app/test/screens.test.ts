// @vitest-environment happy-dom
/**
 * The screens, rendered against a fake wallet that answers the way MovvaWallet does: the balance and its backing (and
 * the closed-market note), the rail options, a refused payment with its free cancel, an overdue bill, and
 * onboarding's recovery explanation.
 */
import { act, createElement, type ReactElement } from 'react';
import { createRoot, type Root } from 'react-dom/client';
import { afterEach, describe, expect, it, vi } from 'vitest';
import {
  ExecutionFailed, PaymentRefused, ReshieldRefused, SaleRefused, reais, type BuyOptions, type DepositQuote, type MovvaBalance, type RailQuote,
  type Reshielded, type VerifiedPayment,
} from '@mova/wallet';
import { parseDeployment } from '../src/lib/deployment.js';
import { DELIVERY_RESHIELD_VISIBLE, SEVERAL_NOTES_COST } from '../src/lib/pending.js';
import { DIRECT_DELIVERY_COST, type DeliveryCheck } from '../src/lib/delivery.js';
import type { PendingSaleItem, WalletPort } from '../src/wallet/port.js';
import { SaleInterrupted } from '../src/wallet/sale-errors.js';
import { CoSignerRefused } from '@mova/cosigner/client';
import { RECOVERY_ALERTS_WHY, RecoveryAlertsCard } from '../src/ui/Alerts.js';
import { MemoryKeyValue } from '../src/wallet/stores.js';
import { Buy, OrderPayment, PaymentDetails, RailOptions } from '../src/ui/Buy.js';
import { BalanceCard, Home } from '../src/ui/Home.js';
import { WalletContext } from '../src/ui/hooks.js';
import { Onboarding, RECOVERY_EXPLAINED } from '../src/ui/Onboarding.js';
import { SaleTracker, Sell } from '../src/ui/Sell.js';

(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

const addr = (n: number) => `0x${n.toString(16).padStart(40, '0')}` as `0x${string}`;
const ORDER = `0x${'ab'.repeat(32)}` as const;
const NOW = Date.parse('2026-09-14T15:00:00Z') / 1000;

const deployment = parseDeployment({
  version: 1, chainId: 31337, rpcUrl: '/api/rpc', fromBlock: '1',
  contracts: Object.fromEntries(['movva', 'reserve', 'onramp', 'offramp', 'entrypoint', 'movvaPool', 'saleVerifier', 'auditGrantRegistry'].map((k, i) => [k, addr(i + 1)])),
  services: { matcher: '/m', lpNodes: [{ lp: addr(20), url: '/lp' }], relayer: '/r', asp: '/a', shares: '/api/shares' },
}, 'http://127.0.0.1:8981/api/deployment.json');

function balance(over: Partial<MovvaBalance> = {}): MovvaBalance {
  return {
    total: reais(49_504n), totalFormatted: 'R$ 495,04', available: reais(49_504n), availableFormatted: 'R$ 495,04',
    backing: { status: 'full', collateralRatioBps: 10_235n, rateUpdatedAt: NOW, marketClosed: false },
    atParHolds: true, valuedAt: NOW, ...over,
  };
}

function fakeWallet(over: Partial<WalletPort> = {}): WalletPort {
  const unexpected = (name: string) => () => { throw new Error(`${name} not expected in this test`); };
  return {
    deployment, address: addr(99), exitRelayFeeBps: 50n, now: () => NOW,
    subscribe: () => () => {}, version: () => 0, orders: () => [], sales: () => [], shares: () => [], reshields: () => [], pendingSales: () => [],
    balance: async () => balance(), refreshActivity: async () => {}, resyncFromVault: async () => 0,
    quoteBuyByRail: unexpected('quoteBuyByRail'), buy: unexpected('buy'), paymentInstructions: unexpected('paymentInstructions'),
    buyStatus: unexpected('buyStatus'), cancelBuy: unexpected('cancelBuy'), quoteSale: unexpected('quoteSale'), sell: unexpected('sell'),
    saleStatus: unexpected('saleStatus'), cancelSale: unexpected('cancelSale'),
    shareWithAuditor: unexpected('shareWithAuditor'), revokeAuditor: unexpected('revokeAuditor'), grantStates: async () => ({}), taxYear: unexpected('taxYear'),
    resumeSale: unexpected('resumeSale'), reshieldSale: unexpected('reshieldSale'), reshieldDelivery: unexpected('reshieldDelivery'),
    deliveryCheck: async () => ({ pending: false, delivery: 'shielded' as const, blocks: [], directRefused: false }),
    takeDeliveryDirect: unexpected('takeDeliveryDirect'), reshieldDeliveryBlocks: async () => [],
    ...over,
  } as WalletPort;
}

let mounted: Root | undefined;
afterEach(() => {
  act(() => mounted?.unmount());
  mounted = undefined;
  document.body.innerHTML = '';
});

async function render(element: ReactElement, wallet?: WalletPort): Promise<HTMLElement> {
  const host = document.createElement('div');
  document.body.appendChild(host);
  mounted = createRoot(host);
  await act(async () => { mounted!.render(wallet ? createElement(WalletContext.Provider, { value: wallet }, element) : element); });
  return host;
}

const settle = () => act(async () => { await new Promise((r) => setTimeout(r, 0)); });

async function click(el: Element | null | undefined) {
  if (!el) throw new Error('nothing to click');
  await act(async () => { (el as HTMLElement).click(); });
}

async function type(el: Element | null, value: string) {
  if (!el) throw new Error('nothing to type into');
  const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
  await act(async () => {
    Object.getOwnPropertyDescriptor(proto, 'value')!.set!.call(el, value);
    el.dispatchEvent(new Event('input', { bubbles: true }));
  });
}

const button = (host: HTMLElement, text: string) => [...host.querySelectorAll('button, a')].find((b) => b.textContent?.includes(text));

describe('home', () => {
  it('total and available in reais, and full backing', async () => {
    const host = await render(createElement(BalanceCard, { balance: balance() }));
    expect(host.querySelector('[data-testid=total]')!.textContent).toBe('R$ 495,04');
    expect(host.querySelector('[data-testid=available]')!.textContent).toBe('R$ 495,04');
    expect(host.textContent).toContain('Lastro integral');
    expect(host.textContent).toContain('As reservas cobrem 102,35% dos Movva em circulação.');
    expect(host.querySelector('[data-testid=conditional]')).toBeNull();
    expect(host.querySelector('[data-testid=market-closed]')).toBeNull();
  });

  it('with the FX market closed, a note that backing is at the last close and conversions wait', async () => {
    const host = await render(createElement(BalanceCard, {
      balance: balance({ backing: { status: 'full', collateralRatioBps: 10_100n, rateUpdatedAt: NOW, marketClosed: true, lastCloseAt: Date.parse('2026-09-11T21:00:00Z') / 1000 } }),
    }));
    expect(host.querySelector('[data-testid=market-closed]')!.textContent)
      .toBe('Mercado de câmbio fechado: o lastro usa o último fechamento (11/09/2026 às 18:00). Conversões na reserva aguardam a reabertura do mercado.');
  });

  it('partial backing marks the figures as conditional, with the ratio', async () => {
    const host = await render(createElement(BalanceCard, {
      balance: balance({ atParHolds: false, backing: { status: 'partial', ratio: '97,20%', collateralRatioBps: 9_720n, rateUpdatedAt: NOW, marketClosed: false } }),
    }));
    expect(host.textContent).toContain('Lastro parcial: 97,20%');
    expect(host.querySelector('[data-testid=conditional]')).not.toBeNull();
  });

  it('asks the chain about orders in progress before reading the balance', async () => {
    const refreshActivity = vi.fn(async () => {});
    const host = await render(createElement(Home), fakeWallet({ refreshActivity }));
    await settle();
    expect(refreshActivity).toHaveBeenCalledOnce();
    expect(host.querySelector('[data-testid=total]')!.textContent).toBe('R$ 495,04');
  });
});

describe('buy', () => {
  const railQuote = (rail: 'pix' | 'boleto', over: Partial<RailQuote> = {}): RailQuote => ({
    rail, quote: {} as DepositQuote, pay: reais(10_000n), payFormatted: 'R$ 100,00', total: reais(10_000n), totalFormatted: 'R$ 100,00',
    receive: reais(9_990n), receiveFormatted: 'R$ 99,90', premiumBps: 10n, premiumFormatted: '0,10%', payments: 1, summary: '', ...over,
  });

  it('a rail shows what is paid and what lands, and a rail that could not be quoted says why', async () => {
    const options: BuyOptions = {
      asked: reais(10_000n), askedFormatted: 'R$ 100,00',
      rails: [railQuote('pix')],
      byRail: {}, unavailable: [{ rail: 'boleto', reason: 'no liquidity on the requested rails right now' }],
    };
    const host = await render(createElement(RailOptions, { options, selected: 'pix', onSelect: () => {} }));
    const pix = host.querySelector('[data-testid=rail-pix]')!;
    expect(pix.textContent).toContain('Total a pagarR$ 100,00');
    expect(pix.textContent).toContain('Você recebe em MovvaR$ 99,90');
    expect(host.textContent).not.toContain('Tarifa do cartão');
    expect(host.querySelector('[data-testid=unavailable-boleto]')!.textContent).toBe('Boleto: Sem liquidez neste meio de pagamento agora.');
    expect(host.textContent).not.toContain('Só parte do valor');
  });

  it('an empty book while the reserve is not issuing: "Compras pausadas por segurança", and the rails say so alike', async () => {
    const options: BuyOptions = {
      asked: reais(10_000n), askedFormatted: 'R$ 100,00', rails: [], byRail: {}, issuance: 'breaker_tripped',
      unavailable: [{ rail: 'pix', reason: 'no liquidity on the requested rails right now' }, { rail: 'boleto', reason: 'matcher /offers: 502' }],
    };
    const host = await render(createElement(RailOptions, { options, selected: undefined, onSelect: () => {} }));
    expect(host.textContent).toContain('Compras pausadas por segurança');
    expect(host.textContent).toContain('a reserva suspendeu a emissão de novos Movva');
    for (const rail of ['pix', 'boleto']) {
      expect(host.querySelector(`[data-testid=unavailable-${rail}]`)!.textContent).toContain('Pausado junto com as compras');
    }
  });

  it('a quote smaller than the amount asked says so: the most on offer now, not what was asked', async () => {
    const options: BuyOptions = {
      asked: reais(2_423_423_400n), askedFormatted: 'R$ 24.234.234,00',
      rails: [railQuote('pix', { pay: reais(202_000n), payFormatted: 'R$ 2.020,00', total: reais(202_000n), totalFormatted: 'R$ 2.020,00' })],
      byRail: {}, unavailable: [],
    };
    const host = await render(createElement(RailOptions, { options, selected: 'pix', onSelect: () => {} }));
    expect(host.textContent).toContain('Só parte do valor está disponível');
    expect(host.textContent).toContain('Os provedores oferecem no máximo R$ 2.020,00 agora, não R$ 24.234.234,00');
  });

  it('an expired quote offers "Cotar de novo" instead of a lock that would be refused, and quoting again brings the lock back', async () => {
    const nowS = () => Math.floor(Date.now() / 1000);
    let expiresAt = nowS() - 1;
    const quoteBuyByRail = vi.fn(async () => {
      const q = railQuote('pix', { quote: { expiresAt } as unknown as DepositQuote });
      return { asked: reais(10_000n), askedFormatted: 'R$ 100,00', rails: [q], byRail: { pix: q }, unavailable: [] } as BuyOptions;
    });
    const host = await render(createElement(Buy, {}), fakeWallet({ quoteBuyByRail }));
    await type(host.querySelector('input[aria-label="Valor em reais"]'), '100');
    await click(button(host, 'Ver formas de pagamento'));
    await settle();
    expect(host.querySelector('[data-testid=quote-expired]')!.textContent).toContain('A cotação expirou');
    expect(button(host, 'Travar pedido')).toBeUndefined();
    expiresAt = nowS() + 120;
    await click(button(host, 'Cotar de novo'));
    await settle();
    expect(quoteBuyByRail).toHaveBeenCalledTimes(2);
    expect(host.querySelector('[data-testid=quote-deadline]')!.textContent).toMatch(/mais (1 min|2 min|\d+ s)/);
    expect(button(host, 'Travar pedido: R$ 100,00 por PIX')).toBeDefined();
  });

  it('PIX: a QR code and the copia e cola, built from what the chain verified', async () => {
    const payment: VerifiedPayment = {
      rail: 'pix', orderId: ORDER, amount: reais(5_000n), formatted: 'R$ 50,00', payBy: NOW + 900,
      pixCopiaECola: '00020126360014BR.GOV.BCB.PIX0114liquidez@lp.ex5204000053039865405' + '50.005802BR5916LP Liquidez Ltda6009Sao Paulo62070503***6304ABCD',
      receiver: { name: 'LP Liquidez Ltda', city: 'Sao Paulo' },
    };
    const host = await render(createElement(PaymentDetails, { payment }));
    expect(host.querySelector('svg[role=img] path')!.getAttribute('d')!.length).toBeGreaterThan(100);
    expect(host.querySelector('[data-testid="copy-PIX copia e cola"]')!.textContent).toBe(payment.pixCopiaECola);
    expect(host.textContent).toContain('LP Liquidez Ltda · Sao Paulo');
    expect(host.textContent).toContain('Pague até14/09/2026 às 12:15');
  });

  it('refused instructions: do not pay, why, and a free cancel that cancels', async () => {
    const cancelBuy = vi.fn(async () => {});
    const wallet = fakeWallet({
      buyStatus: async () => ({ orderId: ORDER, amount: reais(5_000n), formatted: 'R$ 50,00', state: 'awaiting_payment', payBy: NOW + 900 }),
      paymentInstructions: async () => { throw new PaymentRefused('pix_key_does_not_open_commitment', 'the key does not open the commitment', ORDER, { action: 'cancelOrder', free: true }); },
      cancelBuy,
    });
    const host = await render(createElement(OrderPayment, { orderId: ORDER }), wallet);
    await settle();
    await settle();
    expect(host.textContent).toContain('Não pague: as instruções não conferem');
    expect(host.textContent).toContain('A chave PIX enviada pelo provedor não é a que a oferta registrou na blockchain.');
    expect(host.querySelector('svg[role=img]')).toBeNull();
    await click(button(host, 'Cancelar pedido (gratuito)'));
    await settle();
    expect(cancelBuy).toHaveBeenCalledWith(ORDER);
  });
});

describe('sell', () => {
  it('pays a bill: an overdue one is refused and explained before anything moves', async () => {
    const quoteSale = vi.fn(async () => { throw new SaleRefused('the bill was due 2026-09-10', 'boleto_overdue'); });
    const sell = vi.fn();
    const host = await render(createElement(Sell), fakeWallet({ quoteSale, sell }));
    await click(button(host, 'Pagar boleto'));
    await type(host.querySelector('textarea'), '34191.09008 61207.727308 71140.063209 7 99990000004590');
    await click(button(host, 'Conferir boleto'));
    await settle();
    expect(quoteSale).toHaveBeenCalledWith({ boletoLine: '34191.09008 61207.727308 71140.063209 7 99990000004590' });
    expect(host.textContent).toContain('Boleto vencido');
    expect(host.textContent).toContain('nenhum provedor paga boleto vencido');
    expect(sell).not.toHaveBeenCalled();
  });

  it('pays a bill for the amount the bill states, with its due date', async () => {
    const quoteSale = vi.fn(async () => ({
      rail: 'boleto' as const, receive: reais(4_590n), receiveFormatted: 'R$ 45,90', cost: reais(4_652n), costFormatted: 'R$ 46,52',
      fee: reais(62n), feeFormatted: 'R$ 0,62', dueDate: '2026-09-24', summary: '',
    }));
    const host = await render(createElement(Sell), fakeWallet({ quoteSale }));
    await click(button(host, 'Pagar boleto'));
    await type(host.querySelector('textarea'), '34191');
    await click(button(host, 'Conferir boleto'));
    await settle();
    const q = host.querySelector('[data-testid=bill-quote]')!;
    expect(q.textContent).toContain('Valor do boletoR$ 45,90');
    expect(q.textContent).toContain('Vencimento24/09/2026');
    expect(button(host, 'Pagar boleto de R$ 45,90')).toBeDefined();
  });
});

describe('sales in progress, Movva in the open, several notes', () => {
  const SALE = `0x${'cd'.repeat(32)}` as const;
  const pendingSale = (over: Partial<PendingSaleItem> = {}): PendingSaleItem => ({
    id: 'pending:0a', account: addr(7), stage: 'opening', rail: 'pix', receive: reais(990n), receiveFormatted: 'R$ 9,90',
    exited: reais(1_000n), exitedFormatted: 'R$ 10,00', notes: 1, createdAt: NOW, payee: '+5511987654321', ...over,
  });
  const reshielded = (over: Partial<Reshielded> = {}): Reshielded => ({
    source: 'sale_account', from: addr(7), amount: reais(994n), formatted: 'R$ 9,94', fee: reais(1n), feeFormatted: 'R$ 0,01', transactionHash: SALE,
    awaitingApproval: true, ...over,
  });

  it('Início lists a sale stopped before its openSale - what happened, what is left, how much - and "Continuar venda" resumes it', async () => {
    let items = [pendingSale()];
    const resumeSale = vi.fn(async () => {
      items = [];
      return { id: 'pending:0a', state: 'open' as const, saleId: SALE, disclosedTo: 1 };
    });
    const host = await render(createElement(Home), fakeWallet({ pendingSales: () => items, resumeSale }));
    await settle();
    const card = host.querySelector('[data-testid=pending-sale]')!;
    expect(card.textContent).toContain('Venda por PIX · R$ 9,90');
    expect(card.textContent).toContain('Abertura não confirmada');
    expect(card.textContent).toContain('+5511987654321');
    expect(card.textContent).toContain('Já saiu do seu saldoR$ 10,00');
    expect(card.textContent).toContain('Falta abrir a venda');
    await click(button(host, 'Continuar venda'));
    await settle();
    expect(resumeSale).toHaveBeenCalledWith('pending:0a');
    expect(host.querySelector('[data-testid=pending-outcome]')!.textContent).toContain('Venda aberta');
    expect(host.querySelector('[data-testid=pending-sale]')).toBeNull();
  });

  it('an exit still with the relayer: "Aguardando o relayer", and no button that could send it again', async () => {
    const host = await render(createElement(Home), fakeWallet({ pendingSales: () => [pendingSale({ stage: 'exiting', waitingForRelayer: 'continue' })] }));
    await settle();
    const card = host.querySelector('[data-testid=pending-sale]')!;
    expect(card.textContent).toContain('Aguardando o relayer');
    expect(card.querySelectorAll('button')).toHaveLength(0);
  });

  it('"Cancelar e devolver ao saldo" resumes with cancel, and says what came back and that it awaits approval', async () => {
    const resumeSale = vi.fn(async () => ({ id: 'pending:0a', state: 'reshielded' as const, reason: 'cancelled' as const, reshielded: reshielded() }));
    const host = await render(createElement(Sell), fakeWallet({ pendingSales: () => [pendingSale({ stage: 'exited' })], resumeSale }));
    await click(button(host, 'Cancelar e devolver ao saldo'));
    await settle();
    expect(resumeSale).toHaveBeenCalledWith('pending:0a', { cancel: true });
    expect(host.querySelector('[data-testid=pending-outcome]')!.textContent)
      .toContain('R$ 9,94 voltaram ao saldo protegido (taxa do pool: R$ 0,01). Até a ASP aprovar o depósito');
  });

  it('a failed resume is explained on the sale, which keeps its buttons', async () => {
    const resumeSale = vi.fn(async () => { throw new SaleRefused('the sale account no longer holds what the sale escrows', 'chain_mismatch'); });
    const host = await render(createElement(Sell), fakeWallet({ pendingSales: () => [pendingSale({ stage: 'exited' })], resumeSale }));
    await click(button(host, 'Continuar venda'));
    await settle();
    const card = host.querySelector('[data-testid=pending-sale]')!;
    expect(card.textContent).toContain('A blockchain não confirma a venda');
    expect(button(card as HTMLElement, 'Continuar venda')).toBeDefined();
  });

  it('a balance awaiting approval: apart from what can be spent, and why under "Detalhes técnicos"', async () => {
    const host = await render(createElement(BalanceCard, {
      balance: balance({ pending: { awaitingApproval: reais(994n), awaitingApprovalFormatted: 'R$ 9,94', salesInProgress: 0, inSales: reais(0n), inSalesFormatted: 'R$ 0,00' } }),
    }));
    expect(host.querySelector('[data-testid=total]')!.textContent).toBe('R$ 495,04');
    expect(host.querySelector('[data-testid=available]')!.textContent).toBe('R$ 485,10');
    expect(host.querySelector('[data-testid=awaiting-approval]')!.textContent).toBe('R$ 9,94');
    expect(host.querySelector('[data-testid=pending-approval] details')!.textContent).toContain('a prova é feita contra a raiz que a ASP publica');
    expect(host.querySelector('[data-testid=in-sales]')).toBeNull();
  });

  it('a delivery taken in the open: one sentence that the deposit is the user\'s, and a deposit under the pool minimum refused in the wallet\'s words', async () => {
    const reshieldDelivery = vi.fn(async (): Promise<Reshielded> => {
      throw new ReshieldRefused('R$ 0,50 of Movva is under the pool\'s minimum deposit of R$ 1,00: the Entrypoint would refuse it', 'reshield_below_minimum');
    });
    const wallet = fakeWallet({
      buyStatus: async () => ({ orderId: ORDER, amount: reais(50n), formatted: 'R$ 0,50', state: 'delivered_in_the_open', to: addr(99) }),
      reshieldDelivery,
    });
    const host = await render(createElement(OrderPayment, { orderId: ORDER }), wallet);
    await settle();
    await settle();
    expect(host.querySelector('[data-testid=reshield-delivery]')!.textContent).toContain('R$ 0,50 em Movva deste pedido foram entregues na sua conta');
    expect(host.querySelector('[data-testid=reshield-visible]')!.textContent).toBe(DELIVERY_RESHIELD_VISIBLE);
    await click(button(host, 'Devolver ao saldo protegido'));
    await settle();
    expect(reshieldDelivery).toHaveBeenCalledWith(ORDER);
    expect(host.textContent).toContain('Valor abaixo do mínimo do pool');
    expect(host.textContent).toContain('São R$ 0,50 em Movva, abaixo do depósito mínimo do pool, de R$ 1,00');
  });

  it('a cancelled sale gets "Devolver ao saldo protegido", from its sale account', async () => {
    const reshieldSale = vi.fn(async () => reshielded({ awaitingApproval: false }));
    const wallet = fakeWallet({
      sales: () => [{ saleId: SALE, rail: 'pix', receive: 990n, cost: 1_000n, fee: 10n, account: addr(7), payee: '+5511987654321', disclosedTo: 1, createdAt: NOW }],
      saleStatus: async () => ({ saleId: SALE, receive: reais(990n), formatted: 'R$ 9,90', rail: 'pix', state: 'cancelled' }),
      reshieldSale,
    });
    const host = await render(createElement(SaleTracker, { saleId: SALE }), wallet);
    await settle();
    expect(host.querySelector('[data-testid=reshield-sale]')!.textContent).toContain('não liga a venda às suas compras');
    await click(button(host, 'Devolver ao saldo protegido'));
    await settle();
    expect(reshieldSale).toHaveBeenCalledWith(SALE);
  });

  it('a sale larger than the largest note offers "Usar várias notas", off by default, and quotes across notes once chosen', async () => {
    const quoteSale = vi.fn(async (_what: unknown, opts?: { acrossNotes?: { maxNotes: number } }) => {
      if (!opts?.acrossNotes) throw new SaleRefused('a sale is funded from one note, and your largest note is smaller than that', 'note_too_small');
      return {
        rail: 'pix' as const, receive: reais(3_960n), receiveFormatted: 'R$ 39,60', cost: reais(4_001n), costFormatted: 'R$ 40,01',
        fee: reais(41n), feeFormatted: 'R$ 0,41', notes: 2, summary: '',
      };
    });
    const sell = vi.fn();
    const host = await render(createElement(Sell), fakeWallet({ quoteSale, sell }));
    expect(host.querySelector('[data-testid=several-notes]')).toBeNull();
    await type(host.querySelector('input[aria-label="Valor a receber"]'), '40,00');
    await click(button(host, 'Cotar venda'));
    await settle();
    expect(host.textContent).toContain('Valor maior que uma nota');
    expect(quoteSale.mock.calls[0]).toHaveLength(1);
    const option = host.querySelector('[data-testid=several-notes]')!;
    const box = option.querySelector('input[type=checkbox]') as HTMLInputElement;
    expect(box.checked).toBe(false);
    expect(option.textContent).toContain(SEVERAL_NOTES_COST);
    await click(box);
    await settle();
    expect(quoteSale).toHaveBeenLastCalledWith(reais(4_000n), { acrossNotes: { maxNotes: 8 } });
    expect(host.querySelector('[data-testid=sale-notes]')!.textContent).toBe('2 notas');
    expect(sell).not.toHaveBeenCalled();
  });

  it('a sale stopped after its exit points to the sale in progress, and offers no "try again"', async () => {
    const quoteSale = vi.fn(async () => ({
      rail: 'pix' as const, receive: reais(990n), receiveFormatted: 'R$ 9,90', cost: reais(1_000n), costFormatted: 'R$ 10,00', fee: reais(10n), feeFormatted: 'R$ 0,10', summary: '',
    }));
    const sell = vi.fn(async () => { throw new SaleInterrupted('pending:0a', new ExecutionFailed('eth_sendUserOperation: the bundler refused it')); });
    const host = await render(createElement(Sell), fakeWallet({ quoteSale, sell }));
    await type(host.querySelector('input[aria-label="Valor a receber"]'), '10,00');
    await type(host.querySelector('input[aria-label="Chave PIX"]'), '+5511987654321');
    await click(button(host, 'Cotar venda'));
    await settle();
    await click(button(host, 'Vender e receber R$ 9,90'));
    await settle();
    expect(host.textContent).toContain('Venda interrompida');
    expect(host.textContent).toContain('(operação não enviada)');
    expect(button(host, 'Tentar de novo')).toBeUndefined();
    // Nor the sell button: selling again from the start would begin a second sale while this one's Movva waits.
    expect(button(host, 'Vender e receber R$ 9,90')).toBeUndefined();
    expect(sell).toHaveBeenCalledOnce();
  });
});

describe('a shielded delivery the pool would refuse: the escape hatch', () => {
  const M = 10n ** 18n;
  const blockedCheck = (over: Partial<DeliveryCheck> = {}): DeliveryCheck => ({
    pending: true, delivery: 'shielded', blocks: [{ kind: 'below_pool_minimum', minimum: 1_000_000n * M, amount: 30n * M }], directRefused: false, ...over,
  });
  const locked = async () => ({ orderId: ORDER, amount: reais(3_000n), formatted: 'R$ 30,00', state: 'awaiting_payment' as const, payBy: NOW + 900 });
  const pix: VerifiedPayment = {
    rail: 'pix', orderId: ORDER, amount: reais(3_000n), formatted: 'R$ 30,00', payBy: NOW + 900,
    pixCopiaECola: '00020126360014BR.GOV.BCB.PIX0114liquidez@lp.ex5204000053039865405' + '30.005802BR5916LP Liquidez Ltda6009Sao Paulo62070503***6304ABCD',
    receiver: { name: 'LP Liquidez Ltda', city: 'Sao Paulo' },
  };
  const settleAll = async () => { for (let i = 0; i < 4; i++) await settle(); };

  it('says why, stops showing where to pay, keeps the free cancel, and "Receber fora do saldo protegido" takes delivery in the open', async () => {
    const takeDeliveryDirect = vi.fn(async () => {});
    const host = await render(createElement(OrderPayment, { orderId: ORDER }), fakeWallet({
      buyStatus: locked, paymentInstructions: async () => pix, deliveryCheck: async () => blockedCheck(), takeDeliveryDirect,
    }));
    await settleAll();
    const card = host.querySelector('[data-testid=delivery-blocked]')!;
    expect(card.textContent).toContain('A entrega no saldo protegido não é possível agora');
    expect(card.textContent).toContain('O pool de Movva exige agora um depósito mínimo de R$ 1.000.000,00, acima dos R$ 30,00 em Movva a depositar');
    expect(card.textContent).toContain('Se você ainda não pagou, não pague');
    expect(card.querySelector('[data-testid=direct-delivery-cost]')!.textContent).toBe(DIRECT_DELIVERY_COST);
    expect(host.querySelector('svg[role=img]')).toBeNull();
    expect(button(host, 'Simular pagamento')).toBeUndefined();
    expect(button(host, 'Cancelar pedido (gratuito)')).toBeDefined();
    await click(button(host, 'Receber fora do saldo protegido'));
    await settle();
    expect(takeDeliveryDirect).toHaveBeenCalledWith(ORDER);
  });

  it('nothing blocks: the instructions as before; switched to the open, it says the LP releases to the account', async () => {
    const host = await render(createElement(OrderPayment, { orderId: ORDER }), fakeWallet({
      buyStatus: locked, paymentInstructions: async () => pix, deliveryCheck: async () => blockedCheck({ delivery: 'direct', blocks: [] }),
    }));
    await settleAll();
    expect(host.querySelector('[data-testid=delivery-blocked]')).toBeNull();
    expect(host.querySelector('svg[role=img]')).not.toBeNull();
    expect(host.querySelector('[data-testid=delivery-direct]')!.textContent).toContain('o provedor libera os Movva para a sua conta');
  });

  it('the issuer froze the escrow or the account: taking delivery in the open is not offered either', async () => {
    const host = await render(createElement(OrderPayment, { orderId: ORDER }), fakeWallet({
      buyStatus: locked, paymentInstructions: async () => pix,
      deliveryCheck: async () => blockedCheck({ blocks: [{ kind: 'frozen', party: 'escrow' }], directRefused: true }),
    }));
    await settleAll();
    expect(host.textContent).toContain('O emissor do token bloqueou o escrow de compra');
    expect(host.textContent).toContain('receber fora do saldo protegido também seria recusado');
    expect(button(host, 'Receber fora do saldo protegido')).toBeUndefined();
  });

  it('delivered in the open while the pool still refuses: "Devolver ao saldo protegido" waits, with the reason', async () => {
    const host = await render(createElement(OrderPayment, { orderId: ORDER }), fakeWallet({
      buyStatus: async () => ({ orderId: ORDER, amount: reais(3_000n), formatted: 'R$ 30,00', state: 'delivered_in_the_open' as const, to: addr(99) }),
      reshieldDeliveryBlocks: async () => [{ kind: 'below_pool_minimum' as const, minimum: 1_000_000n * M, amount: 30n * M }],
    }));
    await settleAll();
    const waits = host.querySelector('[data-testid=reshield-waits]')!;
    expect(waits.textContent).toContain('O pool ainda não aceita este depósito.');
    expect(waits.textContent).toContain('R$ 1.000.000,00');
    expect(button(host, 'Devolver ao saldo protegido')).toBeUndefined();
  });
});

describe('recovery alerts', () => {
  const available = (subscribed: boolean) => ({ available: true, subscribed });
  const toggle = (host: HTMLElement) => host.querySelector('input[role=switch]') as HTMLInputElement | null;

  it('Ajustes: why in one sentence, and the switch subscribes this device', async () => {
    let subscribed = false;
    const enableRecoveryAlerts = vi.fn(async () => { subscribed = true; });
    const host = await render(createElement(RecoveryAlertsCard), fakeWallet({ recoveryAlerts: async () => available(subscribed), enableRecoveryAlerts, disableRecoveryAlerts: async () => {} }));
    await settle();
    expect(host.textContent).toContain(RECOVERY_ALERTS_WHY);
    expect(toggle(host)!.checked).toBe(false);
    expect(host.querySelector('[data-testid=recovery-alerts-state]')!.textContent).toBe('Desativados neste aparelho');
    await click(toggle(host));
    await settle();
    await settle();
    expect(enableRecoveryAlerts).toHaveBeenCalledOnce();
    expect(toggle(host)!.checked).toBe(true);
    expect(host.querySelector('[data-testid=recovery-alerts-state]')!.textContent).toBe('Ativados neste aparelho');
  });

  it('turning alerts off while a recovery is queued: refused in Portuguese, and the switch stays on', async () => {
    const disableRecoveryAlerts = vi.fn(async () => { throw new CoSignerRefused(409, 'recovery_pending', 'the account has a queued recovery transaction'); });
    const host = await render(createElement(RecoveryAlertsCard), fakeWallet({ recoveryAlerts: async () => available(true), enableRecoveryAlerts: async () => {}, disableRecoveryAlerts }));
    await settle();
    expect(toggle(host)!.checked).toBe(true);
    await click(toggle(host));
    await settle();
    await settle();
    expect(disableRecoveryAlerts).toHaveBeenCalledOnce();
    expect(host.textContent).toContain('Recuperação pendente: alertas mantidos');
    expect(toggle(host)!.checked).toBe(true);
  });

  it('a co-signer without alerts, or a browser without Push: says why, and offers no switch', async () => {
    const host = await render(createElement(RecoveryAlertsCard), fakeWallet({ recoveryAlerts: async () => ({ available: false, unavailable: 'cosigner' as const, subscribed: false }) }));
    await settle();
    expect(host.querySelector('[data-testid=recovery-alerts-unavailable]')!.textContent).toBe('O cossignatário deste deployment não envia alertas de recuperação.');
    expect(toggle(host)).toBeNull();
  });

  it('Início offers them once after onboarding: "Agora não" answers it, "Ativar alertas" turns them on', async () => {
    const dismissRecoveryAlertsOffer = vi.fn();
    const enableRecoveryAlerts = vi.fn(async () => {});
    const host = await render(createElement(Home), fakeWallet({
      recoveryAlerts: async () => available(false), recoveryAlertsOffered: () => false, dismissRecoveryAlertsOffer, enableRecoveryAlerts,
    }));
    await settle();
    await settle();
    const offer = host.querySelector('[data-testid=recovery-alerts-offer]')!;
    expect(offer.textContent).toContain('Ativar alertas de recuperação?');
    expect(offer.textContent).toContain(RECOVERY_ALERTS_WHY);
    await click(button(host, 'Agora não'));
    expect(dismissRecoveryAlertsOffer).toHaveBeenCalledOnce();
    await click(button(host, 'Ativar alertas'));
    await settle();
    expect(enableRecoveryAlerts).toHaveBeenCalledOnce();
    expect(host.querySelector('[data-testid=recovery-alerts-offer]')!.textContent).toContain('Alertas de recuperação ativados');
  });

  it('answered already, subscribed already, or no alerts here: no offer', async () => {
    for (const over of [
      { recoveryAlerts: async () => available(false), recoveryAlertsOffered: () => true },
      { recoveryAlerts: async () => available(true), recoveryAlertsOffered: () => false },
      { recoveryAlerts: async () => ({ available: false, unavailable: 'browser' as const, subscribed: false }), recoveryAlertsOffered: () => false },
    ]) {
      const host = await render(createElement(Home), fakeWallet(over));
      await settle();
      await settle();
      expect(host.querySelector('[data-testid=recovery-alerts-offer]')).toBeNull();
      act(() => mounted?.unmount());
      mounted = undefined;
      document.body.innerHTML = '';
    }
  });
});

describe('onboarding', () => {
  it('explains recovery in one paragraph, and flags the recovery-code path as the weaker fallback', async () => {
    const host = await render(createElement(Onboarding, { deployment, kv: new MemoryKeyValue(), opening: false, onUnlocked: () => {} }));
    expect(host.querySelector('[data-testid=recovery-explained]')!.textContent).toBe(RECOVERY_EXPLAINED);
    expect(host.textContent).toContain('Caminho alternativo, mais fraco, para autenticadores sem a extensão PRF');
    // happy-dom has no WebAuthn: the app says so instead of failing mid-setup.
    expect(host.textContent).toContain('Passkeys indisponíveis');
  });
});
