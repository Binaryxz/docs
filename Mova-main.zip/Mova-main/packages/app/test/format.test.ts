import { describe, expect, it } from 'vitest';
import { reais, type Backing, type BuyStatus, type SaleStatus } from '@mova/wallet';
import {
  AmountInputError, backingView, brasiliaIsoDate, buyStatusView, formatBRL, formatBps, formatDateTime, formatIsoDate, formatTimeLeft,
  parseAmountInput, saleStatusView,
} from '../src/lib/format.js';

const ts = (iso: string) => Date.parse(iso) / 1000;

describe('amounts, always in reais', () => {
  it('formats centavos as a Brazilian writes them', () => {
    expect(formatBRL(123_456n)).toBe('R$ 1.234,56');
    expect(formatBRL(5n)).toBe('R$ 0,05');
    expect(formatBRL(100_000_000n)).toBe('R$ 1.000.000,00');
    expect(formatBRL(0n)).toBe('R$ 0,00');
  });

  it('reads what a Brazilian types: the dot groups thousands, the comma marks centavos', () => {
    expect(parseAmountInput('1.234,56')).toBe(123_456n);
    expect(parseAmountInput('R$ 50')).toBe(5_000n);
    expect(parseAmountInput(' 0,5 ')).toBe(50n);
    expect(parseAmountInput('1234,5')).toBe(123_450n);
    expect(parseAmountInput('1.234')).toBe(123_400n);
  });

  it('refuses in Portuguese rather than guessing', () => {
    expect(() => parseAmountInput('')).toThrow(new AmountInputError('Informe um valor em reais.'));
    expect(() => parseAmountInput('1,234.56')).toThrow('"1,234.56" não é um valor em reais. Use o formato 1.234,56.');
    expect(() => parseAmountInput('0,00')).toThrow('O valor precisa ser maior que zero.');
    expect(() => parseAmountInput('-5')).toThrow(AmountInputError);
  });

  it('percentages from basis points', () => {
    expect(formatBps(350)).toBe('3,50%');
    expect(formatBps(10_235n)).toBe('102,35%');
  });
});

describe('dates, in Brasília', () => {
  it('shows a moment in America/Sao_Paulo', () => {
    expect(formatDateTime(ts('2027-01-20T17:05:00Z'))).toBe('20/01/2027 às 14:05');
    expect(formatDateTime(ts('2026-09-14T03:00:00Z'))).toBe('14/09/2026 às 00:00');
  });

  it('turns the day over at midnight in Brasília, not in UTC', () => {
    expect(brasiliaIsoDate(ts('2026-09-15T02:30:00Z'))).toBe('2026-09-14');
    expect(brasiliaIsoDate(ts('2026-09-15T03:30:00Z'))).toBe('2026-09-15');
  });

  it('writes a due date day first', () => {
    expect(formatIsoDate('2027-01-20')).toBe('20/01/2027');
  });

  it('says how long is left', () => {
    expect(formatTimeLeft(100, 100)).toBe('prazo encerrado');
    expect(formatTimeLeft(130, 100)).toBe('menos de 1 minuto');
    expect(formatTimeLeft(100 + 25 * 60, 100)).toBe('25 min');
    expect(formatTimeLeft(100 + 90 * 60, 100)).toBe('1 h 30 min');
    expect(formatTimeLeft(100 + 3 * 86_400, 100)).toBe('3 dias');
  });
});

describe('backing, beside every balance', () => {
  const at = ts('2026-09-14T15:00:00Z');

  it('full: the reserve covers the Movva in circulation', () => {
    const v = backingView({ status: 'full', collateralRatioBps: 10_235n, rateUpdatedAt: at, marketClosed: false });
    expect(v).toMatchObject({ tone: 'ok', title: 'Lastro integral', detail: 'As reservas cobrem 102,35% dos Movva em circulação.', conditional: false });
    expect(v.closedMarket).toBeUndefined();
  });

  it('full with no Movva in circulation yet', () => {
    const v = backingView({ status: 'full', collateralRatioBps: 2n ** 256n - 1n, rateUpdatedAt: at, marketClosed: false });
    expect(v.detail).toBe('Ainda não há Movva em circulação: as reservas cobrem tudo.');
  });

  it('partial: the ratio, and that par is not guaranteed and buying waits', () => {
    const v = backingView({ status: 'partial', ratio: '97,20%', collateralRatioBps: 9_720n, rateUpdatedAt: at, marketClosed: false });
    expect(v.tone).toBe('warn');
    expect(v.title).toBe('Lastro parcial: 97,20%');
    expect(v.conditional).toBe(true);
    expect(v.detail).toContain('R$ 1,00 por Movva não está garantido e as compras ficam suspensas');
  });

  it('unknown: never full, and the wallet\'s reason kept for the details', () => {
    const v = backingView({ status: 'unknown', reason: 'the reserve could not be read: StaleRate(1757800000)' });
    expect(v).toMatchObject({ tone: 'danger', title: 'Lastro não confirmado', conditional: true, technical: 'the reserve could not be read: StaleRate(1757800000)' });
  });

  it('FX market closed: the backing is the last close, and conversions wait for the market', () => {
    const friday = ts('2026-09-11T21:00:00Z');
    const b: Backing = { status: 'full', collateralRatioBps: 10_100n, rateUpdatedAt: at, marketClosed: true, lastCloseAt: friday };
    expect(backingView(b).closedMarket).toBe(
      'Mercado de câmbio fechado: o lastro usa o último fechamento (11/09/2026 às 18:00). Conversões na reserva aguardam a reabertura do mercado.',
    );
    const { lastCloseAt: _, ...withoutClose } = b as Extract<Backing, { status: 'full' }>;
    expect(backingView(withoutClose).closedMarket).toBe('Mercado de câmbio fechado: o lastro usa o último fechamento. Conversões na reserva aguardam a reabertura do mercado.');
  });
});

describe('order and sale states', () => {
  const base = { orderId: '0x01' as const, amount: reais(5_000n), formatted: 'R$ 50,00' };
  const now = ts('2026-09-14T15:00:00Z');

  it('a purchase', () => {
    expect(buyStatusView({ ...base, state: 'awaiting_payment', payBy: now + 1_200 } as BuyStatus, now)).toMatchObject({
      label: 'Aguardando pagamento', done: false, detail: 'Pague R$ 50,00 até 14/09/2026 às 12:20 (20 min).',
    });
    expect(buyStatusView({ ...base, state: 'delivered', credited: reais(4_995n), creditedFormatted: 'R$ 49,95' } as BuyStatus, now)).toMatchObject({
      label: 'Entregue', tone: 'ok', done: true,
    });
    expect(buyStatusView({ ...base, state: 'expired' } as BuyStatus, now).done).toBe(true);
  });

  it('a bill sale past its due date says to cancel', () => {
    const s: SaleStatus = { saleId: '0x02', receive: reais(4_590n), formatted: 'R$ 45,90', rail: 'boleto', dueDate: '2026-09-10', state: 'open' };
    expect(saleStatusView(s, now, '2026-09-14')).toMatchObject({ label: 'Boleto vencido', tone: 'warn' });
    expect(saleStatusView({ ...s, state: 'settled' }, now, '2026-09-14')).toMatchObject({ label: 'Boleto pago', done: true });
    expect(saleStatusView({ ...s, rail: 'pix', dueDate: undefined, state: 'settled' }, now, '2026-09-14').label).toBe('PIX enviado');
  });
});
