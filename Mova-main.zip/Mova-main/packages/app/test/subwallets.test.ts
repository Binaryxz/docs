import { describe, expect, it } from 'vitest';
import { SubWalletRefused, backupChallenge, newSubWalletPhrase, subWalletKeysFromSeed } from '@mova/wallet';
import { parseDeployment } from '../src/lib/deployment.js';
import { addr, contracts, deployment, hex, primaryAddress, primarySeed, setup } from './subwallets-fixtures.js';
import { deriveAccountKey } from '../src/wallet/keys.js';
import { MemoryKeyValue, storeKeyFromSeed } from '../src/wallet/stores.js';
import { SubWalletManager } from '../src/wallet/subwallets.js';

const create = async (m: SubWalletManager, label: string) => {
  const d = m.draft();
  // The test plays the person: answers from the phrase it was shown.
  const words = d.phrase.split(' ');
  const view = await m.create(label, d.positions.map((p) => words[p - 1]));
  return { view, phrase: d.phrase };
};

describe('sub-wallets on this device', () => {
  it('creates one only after the backup check, and keeps no phrase afterwards', async () => {
    const { manager, kv } = setup();
    const d = manager.draft(24);
    const words = d.phrase.split(' ');
    expect(words).toHaveLength(24);
    expect(d.positions).toHaveLength(3);
    await expect(manager.create('Reserva', d.positions.map(() => 'errado'))).rejects.toThrow(/não conferem/);
    expect(manager.list()).toEqual([]);
    const view = await manager.create('Reserva', d.positions.map((p) => words[p - 1]));
    expect(manager.list()).toEqual([view]);
    expect(view).toMatchObject({ label: 'Reserva', backedUp: true, restored: false });
    // The draft is spent: the phrase is not kept, and cannot be created twice.
    await expect(manager.create('Outra', d.positions.map((p) => words[p - 1]))).rejects.toThrow(/frase em andamento/);
    // Everything on this device is sealed: neither a phrase word list, nor the label, nor the account, nor a root appears in clear.
    const raw = kv.keys().map((k) => `${k}=${kv.get(k)}`).join('\n');
    for (const secret of [d.phrase, words[0] + ' ' + words[1], 'Reserva', view.account, view.account.toLowerCase(), view.id]) expect(raw).not.toContain(secret);
    expect(raw).toContain('mova:subwallets:'); // ... and it is there.
  });

  it('shows one phrase at a time: a new draft replaces the last, which can no longer be confirmed', async () => {
    const { manager } = setup();
    const a = manager.draft();
    const b = manager.draft();
    expect(a.phrase).not.toBe(b.phrase);
    const wa = a.phrase.split(' ');
    await expect(manager.create('x', a.positions.map((p) => wa[p - 1]))).rejects.toThrow(/não conferem/);
  });

  it('opens a sub-wallet over its own root, with no phrase, even after the app reloads', async () => {
    const first = setup();
    const { view } = await create(first.manager, 'Viagem');
    const session = await first.manager.open(view.id);
    expect(first.opened).toHaveLength(1);
    const expected = subWalletKeysFromSeed(first.opened[0]);
    expect(expected.id).toBe(view.id);
    expect(session.address).toBe(view.account);
    // Its root is its own: not the primary's, and its account is the one the app derives from that root.
    expect(hex(first.opened[0])).not.toBe(hex(primarySeed));
    expect(deriveAccountKey(first.opened[0])).toBe(expected.accountKey);
    expect(deriveAccountKey(primarySeed)).not.toBe(expected.accountKey);
    // One session per sub-wallet.
    expect(await first.manager.open(view.id)).toBe(session);
    // A reload: a new manager over the same device storage lists it and opens it.
    const again = first.mk();
    expect(again.list().map((x) => x.label)).toEqual(['Viagem']);
    await again.open(view.id);
    expect(first.opened).toHaveLength(2);
    expect(hex(first.opened[1])).toBe(hex(first.opened[0]));
    // Unlocked with another wallet's key, the registry does not open at all.
    const other = new SubWalletManager({ kv: first.kv, deployment, primarySeed: new Uint8Array(32).fill(7), primaryAddress, now: () => 1, open: async () => { throw new Error('no'); } });
    expect(() => other.list()).toThrow(/não abre com esta chave/);
    expect(storeKeyFromSeed(primarySeed)).not.toEqual(storeKeyFromSeed(new Uint8Array(32).fill(7)));
  });

  it('restores from a phrase alone, rescanning, and refuses a phrase that is invalid, reused, or the primary\'s', async () => {
    const { manager, opened } = setup();
    const phrase = newSubWalletPhrase();
    const r = await manager.restore('Antiga', ` ${phrase.toUpperCase()} `);
    expect(r).toMatchObject({ positions: 2, notes: 1, view: { label: 'Antiga', restored: true } });
    expect(opened).toHaveLength(1);
    await expect(manager.restore('De novo', phrase)).rejects.toThrow(/já é a de uma sub-carteira/);
    await expect(manager.restore('Ruim', 'isto não é uma frase válida')).rejects.toThrow(SubWalletRefused);
    // A phrase whose entropy is the primary's root.
    const asPrimary = newSubWalletPhrase({ words: 24, entropy: primarySeed });
    await expect(manager.restore('Principal', asPrimary)).rejects.toThrow(/conta principal/);
    expect(manager.list().map((x) => x.label)).toEqual(['Antiga']);
    // A failed rescan leaves nothing half-registered.
    const failing = new SubWalletManager({
      kv: new MemoryKeyValue(), deployment, primarySeed, primaryAddress, now: () => 1,
      open: async () => { throw new Error('rpc down'); },
    });
    await expect(failing.restore('X', newSubWalletPhrase())).rejects.toThrow(/rpc down/);
    expect(failing.list()).toEqual([]);
  });

  it('forgets a sub-wallet on this device; its phrase brings it back', async () => {
    const { manager } = setup();
    const { view, phrase } = await create(manager, 'Efêmera');
    manager.forget(view.id);
    expect(manager.list()).toEqual([]);
    await expect(manager.open(view.id)).rejects.toThrow(/restaure-a pela frase/);
    expect((await manager.restore('Volta', phrase)).view.id).toBe(view.id);
  });

  it('shares the selected sub-wallets in ONE package, each from its own session, and says what it cannot prove', async () => {
    const { manager, shared } = setup();
    const a = (await create(manager, 'A')).view;
    const b = (await create(manager, 'B')).view;
    await create(manager, 'C');
    const req = { auditor: 'RFB', auditorKey: 'ab'.repeat(32), purpose: 'IRPF 2026', fromTs: 1, toTs: 2, validDays: 30 };
    const out = await manager.shareWithAuditor([a.id, b.id], req);
    expect(shared).toEqual([a.id, b.id]);
    expect(out.package.subWallets.map((s) => s.id)).toEqual([a.id, b.id]);
    expect(out.package.completeness).toBe('selected-subwallets-only');
    const json = JSON.parse(out.json);
    expect(json).toMatchObject({ kind: 'mova-subwallet-audit-package', completeness: 'selected-subwallets-only', purpose: 'IRPF 2026' });
    expect(json.subWallets.map((s: { id: string; account: string }) => [s.id, s.account])).toEqual([[a.id, a.account], [b.id, b.account]]);
    expect(json.note).toMatch(/apenas as sub-carteiras escolhidas/);
    // Nothing of a seed or a key in the package.
    expect(out.json).not.toMatch(/seed|accountKey|spendingSecret|viewingRoot/i);
    await expect(manager.shareWithAuditor([], req)).rejects.toThrow(/ao menos uma/);
  });

  it('is unavailable where gas is sponsored only for passkey accounts', () => {
    const smart = parseDeployment({
      version: 1, chainId: 31337, rpcUrl: '/api/rpc', fromBlock: '1', contracts,
      services: { matcher: '/m', lpNodes: [{ lp: addr(20), url: '/lp' }], relayer: '/r', asp: '/a' },
      account: {
        kind: 'safe', kinds: ['safe', 'kernel'], bundler: '/api/bundler', paymasterAndData: `0x${'ab'.repeat(20)}${'00'.repeat(32)}`,
        cosigner: { url: 'http://localhost:8986', apiKey: 'k'.repeat(48), address: addr(20) },
        kernel: { passkeyValidator: addr(21), adapter: addr(22) }, gas: { verificationGasLimit: '2500000' },
      },
    }, 'http://127.0.0.1:8981/api/deployment.json');
    const m = new SubWalletManager({ kv: new MemoryKeyValue(), deployment: smart, primarySeed, primaryAddress, now: () => 1, open: async () => { throw new Error('no'); } });
    expect(m.availability().ok).toBe(false);
    expect(() => m.draft()).toThrow(SubWalletRefused);
    void backupChallenge;
  });
});
