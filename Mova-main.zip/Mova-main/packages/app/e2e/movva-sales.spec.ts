/**
 * Sales that stop half-way, Movva put back into the shielded balance, and a sale funded from several notes - in headless
 * Chromium against scripts/dev-stack.ts, on the default Safe 2-of-2.
 *
 *   two purchases by PIX give the wallet two notes
 *   -> a sale larger than either note is refused; "Usar várias notas" is offered, unchecked, with its privacy cost; once
 *      checked the sale is quoted from 2 notes, and it settles
 *   -> a sale interrupted between its exit and its openSale (the stack answers that openSale's UserOperation with a
 *      bundler error, once): "Venda interrompida", no "try again", the sale listed in progress; after a reload and an
 *      unlock, Início lists it, "Continuar venda" opens it - one operation from its sale account - and it settles
 *   -> another sale interrupted the same way, cancelled: its Movva deposited back from its sale account, shown as
 *      "aguardando aprovação" apart from what can be spent while the dev ASP holds its approvals, and counted as
 *      available once the ASP approves it
 *   -> a sale whose exit the relayer holds (`holdNextExit`): "Continuar venda" says "Aguardando o relayer" and offers no
 *      button; once the relayer submits it, the sale goes on by itself and settles.
 *
 * The switches (`POST /api/dev/faults`) belong to the dev stack; the app runs the same code as in any other run.
 */
import { expect, test } from '@playwright/test';
import {
  accountReport, accountShown, balanceShown, buyByPix, centavos, expectReaisAbout, expectSponsoredThroughBundler, nav, openContext, quotePixSale,
  saleAccounts, saveFailureContext, setFaults, type Opened,
} from './helpers.js';

const SELLER_PIX = '+5511987654321';

test.describe.configure({ mode: 'serial' });

test.describe('Movva in a browser: sales that stop half-way, re-shielding, several notes', () => {
  let opened: Opened;
  let account: string;
  const userOps = 2;

  test.beforeAll(async ({ browser }, testInfo) => {
    opened = await openContext(browser, testInfo);
  });

  test.afterEach(async ({}, testInfo) => {
    await saveFailureContext(testInfo, [['sales', opened]]);
  });

  test.afterAll(async () => {
    // Whatever happened above, the specs after this one get a stack with no fault set.
    if (opened && !opened.page.isClosed()) await setFaults(opened.page, { failNextOpenSale: false, holdAsp: false, holdNextExit: false, releaseHeldExits: true }).catch(() => undefined);
    await opened?.context.close();
  });

  const newSaleAccounts = async (before: Set<string>) => (await saleAccounts(opened.page)).filter((a) => !before.has(a.address.toLowerCase()));
  const knownSaleAccounts = async () => new Set((await saleAccounts(opened.page)).map((a) => a.address.toLowerCase()));

  test('two purchases by PIX: two notes in the shielded balance', async () => {
    const { page } = opened;
    await page.goto('/');
    await page.getByRole('button', { name: 'Criar carteira com passkey' }).click();
    await expect(await balanceShown(page)).toHaveText('R$ 0,00');
    account = (await accountShown(page)).address;

    const first = await buyByPix(page, '30,00');
    const second = await buyByPix(page, '30,00');
    await balanceShown(page);
    await expectReaisAbout(page.getByTestId('available'), centavos(first) + centavos(second));
    expectSponsoredThroughBundler(await accountReport(page, account), userOps);
  });

  test('several notes: refused from one note, offered as an opt-in with its privacy cost, quoted from 2 notes, settled', async () => {
    const { page } = opened;
    const before = await knownSaleAccounts();
    await nav(page, 'Vender');
    await page.getByRole('tab', { name: 'Enviar por PIX' }).click();
    await page.getByLabel('Valor a receber').fill('40,00');
    await page.getByLabel('Chave PIX').fill(SELLER_PIX);
    await page.getByRole('button', { name: 'Cotar venda' }).click();

    const refusal = page.getByRole('alert').filter({ hasText: 'Valor maior que uma nota' });
    await expect(refusal).toBeVisible({ timeout: 60_000 });
    await expect(refusal).toContainText('permita usar várias notas');
    await expect(page.getByTestId('sale-quote')).toHaveCount(0);
    await expect(page.getByTestId('several-notes')).toContainText('essas saídas são de uma mesma pessoa');
    const several = page.getByLabel('Usar várias notas');
    await expect(several).not.toBeChecked();

    await several.check();
    const quote = page.getByTestId('sale-quote');
    await expect(quote).toBeVisible({ timeout: 60_000 });
    await expect(quote.getByTestId('sale-notes')).toHaveText('2 notas');
    const sellButton = quote.getByRole('button', { name: /^Vender e receber R\$ [\d.]+,\d{2}$/ });
    const receive = (await sellButton.innerText()).replace('Vender e receber ', '');
    await sellButton.click();

    const sale = page.getByTestId('sale').first();
    await expect(sale).toBeVisible({ timeout: 8 * 60_000 });
    await expect(sale).toContainText(SELLER_PIX);
    await expect(sale).toContainText('PIX enviado', { timeout: 8 * 60_000 });
    const state = await (await page.request.get('/api/dev/state')).json() as { outgoing: { destination: string; amountCents: string }[] };
    expect(state.outgoing).toEqual(expect.arrayContaining([expect.objectContaining({ destination: SELLER_PIX, amountCents: centavos(receive).toString() })]));

    // Both exits paid one new sale account, which opened the sale in one sponsored operation.
    const fresh = await newSaleAccounts(before);
    expect(fresh).toHaveLength(1);
    expectSponsoredThroughBundler(fresh[0]!, 1);
    expectSponsoredThroughBundler(await accountReport(page, account), userOps);
  });

  test('a sale interrupted between its exit and its openSale: after a reload Início lists it, "Continuar venda" opens it once, and it settles', async () => {
    const { page } = opened;
    const before = await knownSaleAccounts();
    expect((await setFaults(page, { failNextOpenSale: true })).failNextOpenSale).toBe(true);

    const quote = await quotePixSale(page, '10,00', SELLER_PIX);
    await quote.getByRole('button', { name: /^Vender e receber/ }).click();
    const interrupted = page.getByRole('status').filter({ hasText: 'Venda interrompida' });
    await expect(interrupted).toBeVisible({ timeout: 6 * 60_000 });
    await expect(interrupted).toContainText('continue ou cancele esta venda em Vendas em andamento');
    await expect(interrupted.getByRole('button', { name: 'Tentar de novo' })).toHaveCount(0);
    // The switch fired: the openSale was refused by the stack's bundler endpoint, and nothing opened a sale.
    expect((await setFaults(page, {})).failNextOpenSale).toBe(false);
    expect(await newSaleAccounts(before)).toHaveLength(0);
    const listed = page.getByTestId('pending-sale');
    await expect(listed).toHaveCount(1);
    await expect(listed).toContainText('Abertura não confirmada');
    await expect(listed).toContainText(SELLER_PIX);

    // Later: the page reloaded, the wallet unlocked again. The sale in progress comes back from the sealed journal.
    await page.reload();
    await page.getByRole('button', { name: 'Desbloquear com a passkey' }).click();
    // The page was on Vender, and opens there again: it lists the sale too. Início is where the balance says what it took.
    await expect(page.getByRole('navigation')).toBeVisible({ timeout: 4 * 60_000 });
    await expect(page.getByTestId('pending-sale')).toContainText('Abertura não confirmada', { timeout: 60_000 });
    await nav(page, 'Início');
    await balanceShown(page);
    await expect(page.getByTestId('in-sales')).toBeVisible({ timeout: 60_000 });
    const card = page.getByTestId('pending-sale');
    await expect(card).toHaveCount(1);
    await expect(card).toContainText('Os Movva saíram do seu saldo para a conta desta venda');
    await expect(card).toContainText('Já saiu do seu saldo');
    await card.getByRole('button', { name: 'Continuar venda' }).click();

    const outcome = page.getByTestId('pending-outcome');
    await expect(outcome).toContainText('Venda aberta', { timeout: 5 * 60_000 });
    await expect(page.getByTestId('pending-sale')).toHaveCount(0);

    await nav(page, 'Vender');
    const sale = page.getByTestId('sale').first();
    await expect(sale).toContainText(SELLER_PIX);
    await expect(sale).toContainText('PIX enviado', { timeout: 8 * 60_000 });
    // One operation from the sale account: the refused openSale never reached the chain, and the sale was not opened twice.
    const fresh = await newSaleAccounts(before);
    expect(fresh).toHaveLength(1);
    expectSponsoredThroughBundler(fresh[0]!, 1);
    expectSponsoredThroughBundler(await accountReport(page, account), userOps);
  });

  test('a sale cancelled before it opened: deposited back from its sale account, "aguardando aprovação" while the ASP holds it, available once approved', async () => {
    const { page } = opened;
    const before = await knownSaleAccounts();
    await setFaults(page, { failNextOpenSale: true });
    const quote = await quotePixSale(page, '5,00', SELLER_PIX);
    await quote.getByRole('button', { name: /^Vender e receber/ }).click();
    await expect(page.getByRole('status').filter({ hasText: 'Venda interrompida' })).toBeVisible({ timeout: 6 * 60_000 });

    await nav(page, 'Início');
    await balanceShown(page);
    const card = page.getByTestId('pending-sale');
    await expect(card).toHaveCount(1);
    // What can be spent while the exit's Movva is at the sale account.
    await expect(page.getByTestId('in-sales')).toBeVisible({ timeout: 60_000 });
    const spendable = centavos(await page.getByTestId('available').innerText());

    await setFaults(page, { holdAsp: true });
    await card.getByRole('button', { name: 'Cancelar e devolver ao saldo' }).click();
    const outcome = page.getByTestId('pending-outcome');
    await expect(outcome).toContainText('Devolvido ao saldo protegido', { timeout: 5 * 60_000 });
    await expect(outcome).toContainText('aguardando aprovação');
    const back = centavos(/(R\$ [\d.]+,\d{2}) voltaram/.exec(await outcome.innerText())![1]!);
    expect(back).toBeGreaterThan(400n);
    await expect(page.getByTestId('pending-sale')).toHaveCount(0);

    // Held by the ASP: in the total, apart from what can be spent, and why.
    const awaiting = page.getByTestId('awaiting-approval');
    await expect(awaiting).toBeVisible({ timeout: 60_000 });
    expect(centavos(await awaiting.innerText())).toBe(back);
    await expect(page.getByTestId('in-sales')).toHaveCount(0);
    await expectReaisAbout(page.getByTestId('available'), spendable);
    const details = page.getByTestId('pending-approval').locator('details');
    await details.locator('summary').click();
    await expect(details).toContainText('a prova é feita contra a raiz que a ASP publica');

    // The ASP approves it: no longer pending, and counted as available.
    await setFaults(page, { holdAsp: false });
    await expect(page.getByTestId('awaiting-approval')).toHaveCount(0, { timeout: 2 * 60_000 });
    await expectReaisAbout(page.getByTestId('available'), spendable + back);
    // No sale was ever opened, and nothing was sent from the user's account.
    expect(await newSaleAccounts(before)).toHaveLength(0);
    expectSponsoredThroughBundler(await accountReport(page, account), userOps);
  });

  test('an exit the relayer holds: "Aguardando o relayer" with no button, then the sale goes on by itself once the exit lands', async () => {
    const { page } = opened;
    // The ASP root stays put meanwhile: a proof is valid only at the latest root, and the held one must stay valid.
    await setFaults(page, { holdAsp: true, holdNextExit: true });
    const quote = await quotePixSale(page, '3,00', SELLER_PIX);
    await quote.getByRole('button', { name: /^Vender e receber/ }).click();
    await expect(page.getByRole('status').filter({ hasText: 'Venda interrompida' })).toBeVisible({ timeout: 6 * 60_000 });
    expect((await setFaults(page, {})).heldExits).toBe(1);

    const card = page.getByTestId('pending-sale');
    await expect(card).toHaveCount(1);
    await expect(card).toContainText('Saída não confirmada');
    await card.getByRole('button', { name: 'Continuar venda' }).click();
    await expect(card).toContainText('Aguardando o relayer', { timeout: 2 * 60_000 });
    await expect(card).toContainText('Nada é enviado de novo enquanto isso');
    await expect(card.getByRole('button')).toHaveCount(0);

    // The relayer sends it: on its next look the app books the exit, opens the sale and tells the LPs - nothing tapped.
    expect((await setFaults(page, { releaseHeldExits: true, holdAsp: false })).heldExits).toBe(0);
    await expect(page.getByTestId('pending-sale')).toHaveCount(0, { timeout: 3 * 60_000 });
    const sale = page.getByTestId('sale').first();
    await expect(sale).toContainText(SELLER_PIX);
    await expect(sale).toContainText('PIX enviado', { timeout: 8 * 60_000 });
    expectSponsoredThroughBundler(await accountReport(page, account), userOps);
  });
});
