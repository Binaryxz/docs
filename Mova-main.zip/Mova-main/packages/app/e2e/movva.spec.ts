/**
 * The Movva app in headless Chromium, end to end, against scripts/dev-stack.ts (see playwright.config.ts), on the
 * default account: a Safe 2-of-2 of the passkey and the co-signer, every call a sponsored UserOperation.
 *
 *   a passkey (a CDP virtual authenticator: CTAP2.1, internal, resident key, user verification, PRF) creates the wallet
 *   and its counterfactual Safe, enrolled with the co-signer -> buy R$ 50,00 by PIX (the first operation creates the
 *   Safe, installs recovery and locks the order) -> "Simular pagamento" -> delivered, the balance in reais
 *   -> an overdue bill refused in Portuguese
 *   -> sell to a PIX key (the withdrawal proof made in the app's Web Worker; the sale opened from a fresh Safe whose owner
 *   is a key made for that sale) -> settled
 *   -> reload, unlock with the same passkey -> the same balance
 *   -> a recovery transaction queued with the passkey on the Delay (a stolen passkey's move) is shown and vetoed
 *   -> a second browser context with the same passkey -> the same account, restored from the pools and the vault.
 *
 * After each step that sends something, the dev stack's account report is read from the chain: the account holds no ETH,
 * and every one of its operations was sent by the Alto bundler to the EntryPoint and paid by SponsorPaymaster.
 *
 * What PRF blocks, exactly: CDP can copy a passkey into another context's authenticator (`WebAuthn.getCredentials` /
 * `addCredential`: id, private key, user handle) but not its PRF secret - the copied credential signs, and its
 * assertion carries no PRF output, so the app cannot derive the wallet's seed there (the test shows that refusal).
 * A synced passkey carries its PRF secret between devices; here the test relays the PRF output the first context's
 * authenticator produced into the second context's PRF assertion, which the copied credential still makes for real.
 * Everything after that - the account's key recovered from two assertions, the session, recovery from the pools, notes
 * from the vault, the account's own operations - is the app's.
 */
import { expect, test } from '@playwright/test';
import {
  accountReport, accountShown, balanceShown, expectSponsoredByCoSigner, expectSponsoredThroughBundler, nav, openContext, saleAccounts, saveFailureContext,
  type Opened,
} from './helpers.js';

const SELLER_PIX = '+5511987654321';

test.describe.configure({ mode: 'serial' });

test.describe('Movva in a browser, with a passkey and a Safe 2-of-2', () => {
  let first: Opened;
  let second: Opened | undefined;
  let prf: string;
  let account: string;
  let userOps = 0;
  let balanceAfterBuy: string;
  let balanceAfterSale: string;

  test.beforeAll(async ({ browser }, testInfo) => {
    first = await openContext(browser, testInfo);
  });

  test.afterEach(async ({}, testInfo) => {
    await saveFailureContext(testInfo, [['first', first], ['second', second]]);
  });

  test.afterAll(async () => {
    await second?.context.close();
    await first?.context.close();
  });

  test('onboarding: a new wallet on a new passkey, with PRF; its Safe exists only as an address, and holds no ETH', async () => {
    const { page } = first;
    await page.goto('/');
    await expect(page.getByTestId('recovery-explained')).toBeVisible();
    await expect(page.getByLabel('Tipo de conta')).toHaveValue('safe');
    await page.getByRole('button', { name: 'Criar carteira com passkey' }).click();
    const total = await balanceShown(page);
    await expect(total).toHaveText('R$ 0,00');
    await expect(page.getByText('Carteira restaurada neste aparelho')).toHaveCount(0);
    prf = await page.evaluate(() => (window as unknown as { __movaPrf: string[] }).__movaPrf[0]);
    expect(prf).toMatch(/^[0-9a-f]{64}$/);

    const shown = await accountShown(page);
    expect(shown.kind).toContain('Safe 2-de-2');
    account = shown.address;
    const r = await accountReport(page, account);
    expect(r.deployed).toBe(false);
    expectSponsoredThroughBundler(r, 0);
    // Sponsored at enrolment by the co-signer's sponsorship module, through SponsorGate, from its own operator key: the
    // production path. The stack has no endpoint that allowlists an account any more.
    expectSponsoredByCoSigner(r);
    expect((await page.request.post('/api/dev/sponsor', { data: { account } })).status()).toBe(404);
  });

  test('buy R$ 50,00 by PIX: the first UserOperation creates the Safe and locks; "Simular pagamento", delivered, the balance in reais', async () => {
    const { page } = first;
    await nav(page, 'Comprar');
    await page.getByLabel('Valor em reais').fill('50,00');
    await page.getByRole('button', { name: 'Ver formas de pagamento' }).click();
    await page.getByTestId('rail-pix').click();
    await page.getByRole('button', { name: 'Travar pedido: R$ 50,00 por PIX' }).click();

    const order = page.getByTestId('order');
    await expect(order.getByRole('img', { name: 'QR Code PIX de R$ 50,00' })).toBeVisible({ timeout: 3 * 60_000 });
    await expect(order.getByText('Código montado por esta carteira')).toBeVisible();
    await order.getByRole('button', { name: 'Simular pagamento por PIX' }).click();

    const delivered = order.getByRole('status').filter({ hasText: 'Movva no seu saldo' });
    await expect(delivered).toBeVisible({ timeout: 6 * 60_000 });
    const credited = /(R\$ \d+,\d{2}) creditados/.exec(await delivered.innerText())![1];

    await nav(page, 'Início');
    const total = await balanceShown(page);
    await expect(total).toHaveText(credited, { timeout: 60_000 });
    await expect(page.getByTestId('available')).toHaveText(credited);
    balanceAfterBuy = credited;

    const r = await accountReport(page, account);
    expect(r.deployed).toBe(true);
    expect(r.owners).toHaveLength(2);
    userOps = r.operations.length;
    expect(userOps).toBe(1);
    expectSponsoredThroughBundler(r, userOps);
  });

  test('an overdue bill is refused in Portuguese, before anything moves', async () => {
    const { page } = first;
    const bills = await (await page.request.get('/api/dev/sample-bills')).json() as { bills: { label: string; line: string }[] };
    const overdue = bills.bills.find((b) => /vencido/i.test(b.label))!;
    await nav(page, 'Vender');
    await page.getByRole('tab', { name: 'Pagar boleto' }).click();
    await page.getByLabel('Linha digitável').fill(overdue.line);
    await page.getByRole('button', { name: 'Conferir boleto' }).click();

    // A refusal is a danger notice: role alert.
    const refusal = page.getByRole('alert').filter({ hasText: 'Boleto vencido' });
    await expect(refusal).toBeVisible({ timeout: 60_000 });
    await expect(refusal).toContainText('horário de Brasília');
    await expect(page.getByTestId('bill-quote')).toHaveCount(0);

    await nav(page, 'Início');
    await expect(await balanceShown(page)).toHaveText(balanceAfterBuy);
    expectSponsoredThroughBundler(await accountReport(page, account), userOps);
  });

  test('sell R$ 20,00 to a PIX key: proven in the browser, relayed, opened from a fresh Safe of its own key, paid by the LP, settled', async () => {
    const { page } = first;
    await nav(page, 'Vender');
    await page.getByRole('tab', { name: 'Enviar por PIX' }).click();
    await page.getByLabel('Valor a receber').fill('20,00');
    await page.getByLabel('Chave PIX').fill(SELLER_PIX);

    // The ASP approves a delivered deposit within seconds; until it has, the quote is refused and asked again.
    const quote = page.getByTestId('sale-quote');
    await expect(async () => {
      if (!(await quote.isVisible())) await page.getByRole('button', { name: 'Cotar venda' }).click();
      await expect(quote).toBeVisible({ timeout: 5_000 });
    }).toPass({ timeout: 2 * 60_000, intervals: [3_000] });
    await expect(quote).toContainText('Chega por PIX');
    await expect(quote).toContainText('R$ 19,80');

    // Other specs on the same stack open sales of their own: this sale's account is the one that was not there before.
    const before = new Set((await saleAccounts(page)).map((a) => a.address.toLowerCase()));
    await quote.getByRole('button', { name: /^Vender e receber R\$ 19,80$/ }).click();
    const sale = page.getByTestId('sale').first();
    await expect(sale).toBeVisible({ timeout: 5 * 60_000 });
    await expect(sale).toContainText(SELLER_PIX);
    await expect(sale).toContainText('PIX enviado', { timeout: 8 * 60_000 });

    const state = await (await page.request.get('/api/dev/state')).json() as { outgoing: { destination: string; amountCents: string }[] };
    expect(state.outgoing).toEqual(expect.arrayContaining([expect.objectContaining({ destination: SELLER_PIX, amountCents: '1980' })]));

    // The sale account: another Safe, owned by a key made for this sale and the co-signer - nothing of the user's.
    const mine = await accountReport(page, account);
    const accounts = (await saleAccounts(page)).filter((a) => !before.has(a.address.toLowerCase()));
    expect(accounts).toHaveLength(1);
    const seller = accounts[0]!;
    expect(seller.address.toLowerCase()).not.toBe(account.toLowerCase());
    expectSponsoredThroughBundler(seller, 1);
    // Sponsored the same way: enrolled from its own key, allowlisted by the co-signer's operator through the gate.
    expectSponsoredByCoSigner(seller);
    const coSigner = mine.owners!.filter((o) => seller.owners!.some((s) => s.toLowerCase() === o.toLowerCase()));
    expect(coSigner).toHaveLength(1);
    const deployment = await (await page.request.get('/api/deployment.json')).json() as { account: { cosigner: { address: string } } };
    expect(coSigner[0]!.toLowerCase()).toBe(deployment.account.cosigner.address.toLowerCase());
    // The sale sent nothing from the user's account.
    expectSponsoredThroughBundler(mine, userOps);

    await nav(page, 'Início');
    const total = await balanceShown(page);
    await expect(total).not.toHaveText(balanceAfterBuy, { timeout: 60_000 });
    balanceAfterSale = await total.innerText();
  });

  test('reload: unlock with the same passkey, the same balance', async () => {
    const { page } = first;
    await page.reload();
    await page.getByRole('button', { name: 'Desbloquear com a passkey' }).click();
    await expect(await balanceShown(page)).toHaveText(balanceAfterSale, { timeout: 60_000 });
  });

  test('a recovery transaction queued with the passkey is shown on open, and vetoed with the passkey and the co-signer', async () => {
    const { page } = first;
    const request = await (await page.request.post('/api/dev/recovery/request', { data: { account } })).json() as { hash: string };
    const identity = await page.evaluate(() => JSON.parse(localStorage.getItem('mova:identity:v1')!) as { credentialId: string; passkey: { x: string; y: string } });
    // The stolen passkey's move: an assertion over the Delay's queue request, relayed by anyone.
    const assertion = await page.evaluate(async ({ hash, credentialId }) => {
      const id = Uint8Array.from(atob(credentialId.replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((credentialId.length + 3) % 4)), (c) => c.charCodeAt(0));
      const challenge = Uint8Array.from(hash.slice(2).match(/../g)!, (x) => parseInt(x, 16));
      const hex = (b: ArrayBuffer) => `0x${Array.from(new Uint8Array(b), (x) => x.toString(16).padStart(2, '0')).join('')}`;
      const credential = await navigator.credentials.get({ publicKey: { challenge, allowCredentials: [{ type: 'public-key', id }], userVerification: 'required' } }) as PublicKeyCredential;
      const r = credential.response as AuthenticatorAssertionResponse;
      return { authenticatorData: hex(r.authenticatorData), clientDataJSON: hex(r.clientDataJSON), signature: hex(r.signature) };
    }, { hash: request.hash, credentialId: identity.credentialId });
    const queued = await (await page.request.post('/api/dev/recovery/queue', { data: { account, owner: identity.passkey, assertion } })).json() as { queued: boolean };
    expect(queued.queued).toBe(true);

    await nav(page, 'Vender');
    await nav(page, 'Início');
    const card = page.getByTestId('recovery-queue');
    await expect(card).toBeVisible({ timeout: 60_000 });
    await expect(card).toContainText('Recuperação pendente na sua conta');
    await expect(card).toContainText('Transação 0');
    await card.getByRole('button', { name: 'Vetar a recuperação' }).click();
    await expect(page.getByTestId('recovery-vetoed')).toBeVisible({ timeout: 3 * 60_000 });
    await expect(card).toHaveCount(0);

    userOps += 1;
    expectSponsoredThroughBundler(await accountReport(page, account), userOps);
    await expect(await balanceShown(page)).toHaveText(balanceAfterSale);
  });

  test('a second browser context, the same passkey: the same account, restored from the pools and the note vault, the same balance', async ({ browser }, testInfo) => {
    const { credentials } = await first.cdp.send('WebAuthn.getCredentials', { authenticatorId: first.authenticatorId });
    expect(credentials).toHaveLength(1);
    second = await openContext(browser, testInfo);
    for (const credential of credentials) {
      await second.cdp.send('WebAuthn.addCredential', { authenticatorId: second.authenticatorId, credential });
    }
    const { page } = second;
    await page.goto('/');
    const restore = page.getByRole('button', { name: 'Já tenho: restaurar com a passkey' });

    // The copied credential signs, but CDP could not copy its PRF secret: no seed, and the app says so.
    await restore.click();
    const noSeed = page.getByRole('alert').filter({ hasText: 'Não foi possível abrir a carteira' });
    await expect(noSeed).toBeVisible({ timeout: 60_000 });
    await expect(noSeed).toContainText('extensão PRF');
    expect(await page.evaluate(() => (window as unknown as { __movaPrf: string[] }).__movaPrf)).toEqual([]);

    // What a synced passkey carries: its PRF output for the wallet's salt, the same as on the first device.
    await page.evaluate((hex) => { (window as unknown as { __movaPrfRelay: string }).__movaPrfRelay = hex; }, prf);
    await restore.click();
    await expect(page.getByRole('status').filter({ hasText: 'Carteira restaurada neste aparelho' })).toBeVisible({ timeout: 4 * 60_000 });
    await expect(await balanceShown(page)).toHaveText(balanceAfterSale, { timeout: 2 * 60_000 });
    await expect(page.getByTestId('available')).toHaveText(balanceAfterSale);
    // The account's key came back from the passkey's assertions, its salt from the seed: the same Safe, nothing new sent.
    expect((await accountShown(page)).address).toBe(account);
    expectSponsoredThroughBundler(await accountReport(page, account), userOps);
  });
});
