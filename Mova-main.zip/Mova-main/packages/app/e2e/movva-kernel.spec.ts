/**
 * The Kernel option, in headless Chromium against the same dev stack: onboarding picks "Kernel" - a Kernel v3.1 account
 * whose root validator, PasskeyCoSignerValidator, requires the passkey and the co-signer. The co-signer creates the account
 * with a plain transaction at enrolment, so it already has code before anything is sent through the EntryPoint; then a
 * purchase by PIX runs on it: its first UserOperation carries no initCode, installs recovery through KernelAvatarAdapter
 * and locks the order, signed by the passkey in the browser and completed by the co-signer, sent by the bundler, paid by
 * the paymaster. Then a sale by PIX: opened from a fresh Kernel account whose owner key was made for that sale, with the
 * co-signer its second key.
 */
import { expect, test } from '@playwright/test';
import {
  accountReport, accountShown, balanceShown, expectSponsoredByCoSigner, expectSponsoredThroughBundler, nav, openContext, quotePixSale, saleAccounts,
  saveFailureContext, type Opened,
} from './helpers.js';

const SELLER_PIX = '+5511987654321';

test.describe.configure({ mode: 'serial' });

test.describe('Movva in a browser, with a passkey and a Kernel account', () => {
  let opened: Opened;
  let account: string;

  test.beforeAll(async ({ browser }, testInfo) => {
    opened = await openContext(browser, testInfo);
  });

  test.afterEach(async ({}, testInfo) => {
    await saveFailureContext(testInfo, [['kernel', opened]]);
  });

  test.afterAll(async () => {
    await opened?.context.close();
  });

  test('onboarding with Kernel chosen: the co-signer creates the Kernel account itself, before any operation, no ETH', async () => {
    const { page } = opened;
    await page.goto('/');
    await page.getByLabel('Tipo de conta').selectOption('kernel');
    await page.getByRole('button', { name: 'Criar carteira com passkey' }).click();
    await expect(await balanceShown(page)).toHaveText('R$ 0,00');
    const shown = await accountShown(page);
    expect(shown.kind).toContain('Kernel');
    account = shown.address;
    const r = await accountReport(page, account);
    // The account has code before its first operation: the co-signer's sponsorship deployed it through KernelFactory at
    // enrolment, so no operation of this account ever carries initCode - which is what a public bundler's rules need
    // (docs/wallet-custody.md §10.3). Nothing has gone through the EntryPoint yet.
    expect(r.deployed).toBe(true);
    expectSponsoredThroughBundler(r, 0);
    expectSponsoredByCoSigner(r);
  });

  test('buy R$ 50,00 by PIX on the Kernel account: its first operation carries no initCode, delivered, the balance in reais', async () => {
    const { page } = opened;
    await nav(page, 'Comprar');
    await page.getByLabel('Valor em reais').fill('50,00');
    await page.getByRole('button', { name: 'Ver formas de pagamento' }).click();
    await page.getByTestId('rail-pix').click();
    await page.getByRole('button', { name: 'Travar pedido: R$ 50,00 por PIX' }).click();

    const order = page.getByTestId('order');
    await expect(order.getByRole('img', { name: 'QR Code PIX de R$ 50,00' })).toBeVisible({ timeout: 3 * 60_000 });
    await order.getByRole('button', { name: 'Simular pagamento por PIX' }).click();
    const delivered = order.getByRole('status').filter({ hasText: 'Movva no seu saldo' });
    await expect(delivered).toBeVisible({ timeout: 6 * 60_000 });
    const credited = /(R\$ \d+,\d{2}) creditados/.exec(await delivered.innerText())![1];

    await nav(page, 'Início');
    await expect(await balanceShown(page)).toHaveText(credited, { timeout: 60_000 });

    const r = await accountReport(page, account);
    expect(r.deployed).toBe(true);
    const deployment = await (await page.request.get('/api/deployment.json')).json() as { account: { cosigner: { address: string } } };
    expect(r.kernelPasskey?.coSigner.toLowerCase()).toBe(deployment.account.cosigner.address.toLowerCase());
    expectSponsoredThroughBundler(r, 1);
  });

  test('sell R$ 20,00 to a PIX key from the Kernel account: opened from a fresh Kernel account of its own key and the co-signer, settled', async () => {
    const { page } = opened;
    const before = new Set((await saleAccounts(page)).map((a) => a.address.toLowerCase()));
    const quote = await quotePixSale(page, '20,00', SELLER_PIX);
    await expect(quote).toContainText('R$ 19,80');
    await quote.getByRole('button', { name: /^Vender e receber R\$ 19,80$/ }).click();

    const sale = page.getByTestId('sale').first();
    await expect(sale).toBeVisible({ timeout: 5 * 60_000 });
    await expect(sale).toContainText(SELLER_PIX);
    await expect(sale).toContainText('PIX enviado', { timeout: 8 * 60_000 });
    const state = await (await page.request.get('/api/dev/state')).json() as { outgoing: { destination: string; amountCents: string }[] };
    expect(state.outgoing).toEqual(expect.arrayContaining([expect.objectContaining({ destination: SELLER_PIX, amountCents: '1980' })]));

    // The sale account: a Kernel account like the user's, whose passkey is a key made for this sale - not the user's.
    const fresh = (await saleAccounts(page)).filter((a) => !before.has(a.address.toLowerCase()));
    expect(fresh).toHaveLength(1);
    const seller = fresh[0]!;
    const mine = await accountReport(page, account);
    const deployment = await (await page.request.get('/api/deployment.json')).json() as { account: { cosigner: { address: string } } };
    expect(seller.address.toLowerCase()).not.toBe(account.toLowerCase());
    expect(seller.owners).toBeUndefined();
    expect(seller.kernelPasskey?.coSigner.toLowerCase()).toBe(deployment.account.cosigner.address.toLowerCase());
    expect(seller.kernelPasskey?.x).toMatch(/^0x[0-9a-f]+$/);
    expect(seller.kernelPasskey?.x).not.toBe(mine.kernelPasskey?.x);
    expectSponsoredThroughBundler(seller, 1);
    expectSponsoredByCoSigner(seller);
    // The sale sent nothing from the user's account.
    expectSponsoredThroughBundler(mine, 1);
  });
});
