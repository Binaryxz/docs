/**
 * What the e2e specs share: a browser context with a CDP virtual passkey (CTAP2.1, internal, resident key, user
 * verification, PRF), the app's navigation, and the dev stack's view of an account as the chain shows it.
 */
import { expect, type Browser, type BrowserContext, type CDPSession, type Locator, type Page, type TestInfo } from '@playwright/test';

export interface Opened {
  context: BrowserContext;
  page: Page;
  cdp: CDPSession;
  authenticatorId: string;
  logs: string[];
}

/**
 * In every page: remember the PRF outputs the authenticator returns (to relay into another context), and - only once a
 * test sets `__movaPrfRelay` - fill in a PRF output an assertion lacks. The assertion itself is always the authenticator's.
 */
function prfObserver(): void {
  const w = window as unknown as { __movaPrf: string[]; __movaPrfRelay?: string };
  w.__movaPrf = [];
  const hex = (b: ArrayBuffer | ArrayBufferView): string => Array.from(
    b instanceof ArrayBuffer ? new Uint8Array(b) : new Uint8Array(b.buffer, b.byteOffset, b.byteLength), (x) => x.toString(16).padStart(2, '0'),
  ).join('');
  const creds = navigator.credentials;
  for (const name of ['create', 'get'] as const) {
    const original = creds[name].bind(creds) as (o?: CredentialCreationOptions & CredentialRequestOptions) => Promise<Credential | null>;
    creds[name] = (async (options?: CredentialCreationOptions & CredentialRequestOptions) => {
      const c = await original(options) as PublicKeyCredential | null;
      if (!c) return c;
      const results = c.getClientExtensionResults() as { prf?: { enabled?: boolean; results?: { first?: ArrayBuffer } } };
      if (results.prf?.results?.first) {
        w.__movaPrf.push(hex(results.prf.results.first));
        return c;
      }
      const relay = w.__movaPrfRelay;
      const askedPrf = !!(options as { publicKey?: { extensions?: { prf?: unknown } } } | undefined)?.publicKey?.extensions?.prf;
      if (name !== 'get' || !relay || !askedPrf) return c;
      const first = Uint8Array.from(relay.match(/../g)!, (x) => parseInt(x, 16)).buffer;
      return {
        id: c.id, rawId: c.rawId, type: c.type, response: c.response, authenticatorAttachment: c.authenticatorAttachment,
        getClientExtensionResults: () => ({ ...results, prf: { results: { first } } }),
      } as unknown as PublicKeyCredential;
    }) as typeof creds.get;
  }
}

export async function openContext(browser: Browser, testInfo: TestInfo): Promise<Opened> {
  const context = await browser.newContext({ baseURL: testInfo.project.use.baseURL });
  await context.addInitScript(prfObserver);
  const page = await context.newPage();
  const logs: string[] = [];
  page.on('console', (m) => { if (m.type() === 'error' || m.type() === 'warning') logs.push(`[${m.type()}] ${m.text()}`); });
  page.on('pageerror', (e) => logs.push(`[pageerror] ${e.message}`));
  const cdp = await context.newCDPSession(page);
  await cdp.send('WebAuthn.enable');
  const { authenticatorId } = await cdp.send('WebAuthn.addVirtualAuthenticator', {
    options: {
      protocol: 'ctap2', ctap2Version: 'ctap2_1', transport: 'internal', hasResidentKey: true, hasUserVerification: true,
      isUserVerified: true, hasPrf: true, automaticPresenceSimulation: true,
    } as never,
  });
  return { context, page, cdp, authenticatorId, logs };
}

export const nav = (page: Page, name: string) => page.getByRole('navigation').getByRole('link', { name, exact: true }).click();

export async function balanceShown(page: Page) {
  await expect(page.getByRole('heading', { name: 'Seu saldo' })).toBeVisible({ timeout: 4 * 60_000 });
  const total = page.getByTestId('total');
  await expect(total).toHaveText(/^R\$ \d{1,3}(\.\d{3})*,\d{2}$/, { timeout: 2 * 60_000 });
  return total;
}

/** The account the app opened, as its settings screen names it, with its kind. */
export async function accountShown(page: Page): Promise<{ address: string; kind: string }> {
  await nav(page, 'Ajustes');
  const address = (await page.getByTestId('copy-Conta').innerText()).trim();
  const kind = (await page.getByTestId('account-kind').innerText()).trim();
  await nav(page, 'Início');
  return { address, kind };
}

export interface AccountReport {
  address: string;
  balance: string;
  deployed: boolean;
  entryPointNonce: string;
  paymaster: string;
  bundlerExecutor: string;
  entryPoint: string;
  owners?: string[];
  kernelPasskey?: { x: string; coSigner: string };
  operations: { transactionHash: string; success: boolean; paymaster: string; actualGasCost: string; bundle: { from: string; to: string | null } }[];
  /** SponsorPaymaster's allowlist, and SponsorGate's Sponsored events for the account with the transactions that emitted them. */
  sponsorship: { sponsored: boolean; gate: string; operator: string; byGate: { operator: string; transactionHash: string; from: string; to: string | null }[] };
}

export const accountReport = async (page: Page, address: string): Promise<AccountReport> =>
  (await page.request.get(`/api/dev/account?address=${address}`)).json() as Promise<AccountReport>;

const same = (a?: string | null, b?: string | null) => !!a && !!b && a.toLowerCase() === b.toLowerCase();

/** No ETH in the account, and every one of its UserOperations successful, sent by the bundler to the EntryPoint and paid by the paymaster. */
export function expectSponsoredThroughBundler(r: AccountReport, operations: number): void {
  expect(r.balance).toBe('0');
  expect(r.operations).toHaveLength(operations);
  expect(BigInt(r.entryPointNonce)).toBe(BigInt(operations));
  for (const op of r.operations) {
    expect(op.success).toBe(true);
    expect(same(op.paymaster, r.paymaster)).toBe(true);
    expect(same(op.bundle.from, r.bundlerExecutor)).toBe(true);
    expect(same(op.bundle.to, r.entryPoint)).toBe(true);
    expect(BigInt(op.actualGasCost)).toBeGreaterThan(0n);
  }
}

export async function saveFailureContext(testInfo: TestInfo, contexts: [string, Opened | undefined][]): Promise<void> {
  if (testInfo.status === testInfo.expectedStatus) return;
  for (const [name, o] of contexts) {
    if (!o || o.page.isClosed()) continue;
    await o.page.screenshot({ path: testInfo.outputPath(`${name}-context.png`), fullPage: true }).catch(() => undefined);
    await testInfo.attach(`${name}-context console`, { body: o.logs.join('\n') || '(nothing logged)', contentType: 'text/plain' });
  }
}

export interface DevFaults { failNextOpenSale: boolean; holdAsp: boolean; holdNextExit: boolean; raisePoolMinimum: boolean; heldExits: number }

/** The dev stack's fault switches (scripts/dev-stack.ts, `POST /api/dev/faults`); `{}` just reads them. */
export async function setFaults(page: Page, faults: Partial<Omit<DevFaults, 'heldExits'>> & { releaseHeldExits?: boolean }): Promise<DevFaults> {
  const r = await page.request.post('/api/dev/faults', { data: faults, timeout: 120_000 });
  expect(r.ok(), await r.text()).toBe(true);
  return r.json() as Promise<DevFaults>;
}

/** Every account that opened a sale on the stack, as the chain shows it. */
export const saleAccounts = async (page: Page): Promise<AccountReport[]> =>
  ((await (await page.request.get('/api/dev/sale-accounts')).json()) as { accounts: AccountReport[] }).accounts;

/** Reais as the app writes them, in centavos: "R$ 1.234,56" -> 123456n. */
export const centavos = (text: string): bigint => BigInt(text.replace(/[^\d]/g, ''));

/** Within a centavo of `cents`: the balance rounds its units down once, and each figure it is compared with rounded its own. */
export async function expectReaisAbout(locator: Locator, cents: bigint, timeout = 60_000): Promise<void> {
  await expect(async () => {
    const shown = centavos(await locator.innerText());
    expect(shown >= cents - 1n && shown <= cents + 1n, `${shown} centavos shown, ${cents} expected`).toBe(true);
  }).toPass({ timeout, intervals: [1_000] });
}

/** Buy by PIX from a fresh Comprar screen, pay it through the dev API, wait for delivery: what was credited. */
export async function buyByPix(page: Page, amount: string): Promise<string> {
  await nav(page, 'Início');
  await nav(page, 'Comprar');
  await page.getByLabel('Valor em reais').fill(amount);
  await page.getByRole('button', { name: 'Ver formas de pagamento' }).click();
  await page.getByTestId('rail-pix').click();
  await page.getByRole('button', { name: `Travar pedido: R$ ${amount} por PIX` }).click();
  const order = page.getByTestId('order');
  await expect(order.getByRole('img', { name: `QR Code PIX de R$ ${amount}` })).toBeVisible({ timeout: 3 * 60_000 });
  await order.getByRole('button', { name: 'Simular pagamento por PIX' }).click();
  const delivered = order.getByRole('status').filter({ hasText: 'Movva no seu saldo' });
  await expect(delivered).toBeVisible({ timeout: 6 * 60_000 });
  const credited = /(R\$ [\d.]+,\d{2}) creditados/.exec(await delivered.innerText())![1]!;
  await nav(page, 'Início');
  return credited;
}

/** On Vender, a PIX sale quoted: the form filled, and asked again until the quote shows (the ASP approves a delivered deposit within seconds). */
export async function quotePixSale(page: Page, amount: string, pixKey: string): Promise<Locator> {
  await nav(page, 'Vender');
  await page.getByRole('tab', { name: 'Enviar por PIX' }).click();
  await page.getByLabel('Valor a receber').fill(amount);
  await page.getByLabel('Chave PIX').fill(pixKey);
  const quote = page.getByTestId('sale-quote');
  await expect(async () => {
    if (!(await quote.isVisible())) await page.getByRole('button', { name: 'Cotar venda' }).click();
    await expect(quote).toBeVisible({ timeout: 5_000 });
  }).toPass({ timeout: 2 * 60_000, intervals: [3_000] });
  return quote;
}

/** Allowlisted on SponsorPaymaster by one SponsorGate.sponsor, sent by the co-signer's operator key to the gate: nobody else's. */
export function expectSponsoredByCoSigner(r: AccountReport): void {
  expect(r.sponsorship.sponsored).toBe(true);
  expect(r.sponsorship.byGate).toHaveLength(1);
  const [s] = r.sponsorship.byGate;
  expect(same(s!.operator, r.sponsorship.operator)).toBe(true);
  expect(same(s!.from, r.sponsorship.operator)).toBe(true);
  expect(same(s!.to, r.sponsorship.gate)).toBe(true);
}
