# @mova/app — Movva, the web app

The user interface docs/HANDOVER.md lists as missing: a **web app, installable as a PWA**, in **Brazilian
Portuguese**, amounts always in reais (R$ 1.234,56). It calls `packages/wallet` (`MovvaWallet`) and nothing else
does the wallet's work: every check the wallet makes before something is payable is the wallet's own code, running
on the user's device. Vite + React + TypeScript; no UI framework.

```bash
# the local demo: anvil, the account stack (EntryPoint, Safe, Kernel, Delay, paymaster, Alto), the co-signer, the Movva
# contracts, an LP node, the matcher, relayer, ASP, note vault (ports 8981-8989; MOVVA_ACCOUNT=kernel for a Kernel default)
# SponsorGate may not be in forge-out yet: build it into a directory of your own (never forge-out) and point at it
FOUNDRY_OUT=/tmp/sg/out FOUNDRY_CACHE_PATH=/tmp/sg/cache $(bash scripts/foundry.sh path) build contracts/SponsorGate.sol
export SPONSOR_GATE_ARTIFACT=/tmp/sg/out/SponsorGate.sol/SponsorGate.json   # the stack falls back to forge-out/SponsorGate.sol
npx tsx packages/app/scripts/dev-stack.ts            # wait for "[dev-stack] ready"

npm run build -w @mova/app                           # then open http://localhost:8981
npm run dev -w @mova/app                             # or the dev server: http://localhost:8980 (proxies /api to 8981)

npx tsx packages/app/scripts/smoke.ts                # a buy and a sell against the stack, headless (see Tests)
```

Open it at **`http://localhost:8981`**, not `127.0.0.1`: passkeys need a secure context and a domain as their relying
party, and Chrome refuses an IP address ("This is an invalid domain") even on loopback. A LAN IP qualifies for neither.

## Screens

| Screen | What it does |
|---|---|
| **Onboarding** | Create a wallet on a new passkey (WebAuthn PRF, ES256), restore with a synced passkey, or unlock this device's. The account kind - *Safe 2-de-2 (recomendada)* or *Kernel* - is chosen here; the new passkey's public key becomes the account's owner, and the counterfactual account is enrolled with the co-signer, and sponsored by the co-signer's sponsorship module (the app waits for it), before the screen closes. One paragraph says how recovery works. A device without PRF - or a browser without passkeys - gets the **recovery-code path**, flagged as the weaker fallback: 2-of-3 shares (this browser, the share server, a code the user writes down, shown once), through `RecoverableSplitSeedSource`. `openSeed` refuses to open a wallet with a different source than it was made with. |
| **Início** | The account's **recovery queue**, on every open (and every 15 s): a transaction queued on the recovery Delay - what a stolen passkey would do - shown with when it becomes executable, and *Vetar a recuperação*. Total and available in reais, and backing: *integral* with the ratio, *parcial* with the ratio (figures marked conditional, buying suspended) or *não confirmado* (with the wallet's reason under "detalhes técnicos"). While the FX market is closed, a note that backing uses the last close (with its time when the reserve names it) and conversions wait for the market. Orders and sales in progress are asked about on every refresh, which is when deliveries are adopted. Beside *Disponível* (what can be spent), what the ASP has not approved yet (*Aguardando aprovação*, part of the total; why under "detalhes técnicos") and what sales in progress took out. **Vendas em andamento**: each sale this device started and did not finish (`pendingSales()`) - what happened, what is left, how much - with *Continuar venda* (`resumeSale`) and *Cancelar e devolver ao saldo* (`resumeSale` with `cancel`, which deposits it back); a sale given up only gets *Devolver ao saldo protegido*; a sale whose exit may still land says *Aguardando o relayer* and offers no button, and the session asks again on every refresh; a sale being made or resumed right now offers nothing. **Movva fora do saldo protegido**: orders delivered in the open and sales refunded to their sale account, each with *Devolver ao saldo protegido*. |
| **Comprar** | An amount in reais → `quoteBuyByRail` for PIX and boleto side by side: the order, the total, what arrives in Movva, the cost over what arrives; rails that could not be quoted say why. Lock → instructions verified on-chain: PIX **QR code + copia e cola** (built by the wallet from the verified key and amount), or the **boleto line** with its due date. Every `PaymentRefused` is shown in Portuguese - "Não pague", why, and the suggested action: *Cancelar pedido (gratuito)*, one tap. Status is polled until delivered, cancelled or expired. An order delivered in the open (`takeDeliveryDirect`) gets *Devolver ao saldo protegido* (`reshieldDelivery`), after one sentence saying the deposit back is visibly the user's own; under the pool's minimum it is refused with the wallet's figures, and while the pool still refuses the deposit the button waits, with the reason. **A shielded delivery the pool would refuse** (the escape hatch): for an order locked or disputed, read from the chain every few seconds - the Movva pool's minimum raised above the order, no pool registered for Movva or another one, the pool wound down, the token's issuer freezing the escrow, the Entrypoint or the pool - the order says why, stops showing where to pay, keeps the free cancel, and offers *Receber fora do saldo protegido* (`takeDeliveryDirect`) after one sentence on its privacy cost; Início lists such orders too. A release the LP node tried and that reverted is not visible to the app (the node simulates first, and its API does not report it); the reads are what such a revert comes from. |
| **Vender** | To a **PIX key** (quote: what arrives, what leaves the balance, the fees), or **pay a bill**: paste the line or scan the barcode (camera + `BarcodeDetector`, where the browser has it); the amount and due date come from the bill. Overdue, no-due-date, collection and no-amount bills are refused before anything moves, each explained. Status until settled. An open sale is cancelled and its Movva deposited back in one tap (*Cancelar e devolver ao saldo*); a cancelled or refunded one gets *Devolver ao saldo protegido* (`reshieldSale`). When the largest note cannot fund the sale, *Usar várias notas* is offered unchecked, with its privacy cost in one sentence (`acrossNotes`), and the quote says how many notes. A sale that stops after its exit (*Venda interrompida*) offers no "try again" - that would start a second sale - and is listed under *Vendas em andamento*. |
| **Auditoria** | Share a period with an auditor (Receita Federal do Brasil by default): the auditor's public key, purpose, dates in Brasília, validity. Grants are registered on `AuditGrantRegistry`; the list shows each one's state as the registry records it (active, expired, revoked - from any device), downloads the auditor's package, and revokes. The tax year: Bens e Direitos at cost, disposals by month, and the CSV. |
| **Ajustes** | **Alertas de recuperação**: an on/off switch for this device, with why in one sentence (a stolen passkey can request a recovery; you have 7 days to veto); turning it on or off takes a passkey assertion, and turning it off while a recovery is queued is refused and explained (`recovery_pending`), the switch staying on. Início offers to turn it on once, after onboarding. The account (address, kind, co-signer); the deployment (name, chain id, every contract address, start block, trusted checkout hosts) loaded from a deployment JSON by URL or file; RPC, matcher, relayer, ASP, note vault and LP node endpoints, editable; lock; forget this device. |
| **Teste** (demo only) | Present when the deployment names a dev API: gas for the demo account, the LP bank's outgoing payments, sample bills (valid, overdue, no due date, collection), a test auditor key. Beside every verified payment in Comprar, a *Simular pagamento* button pays it at MockBank. |

## What runs where, and why

### On the device

Every key and every secret computation:

- **The seed** comes from the passkey's PRF and lives in memory while the wallet is unlocked; locking or reloading drops
  it. Nothing derived from it is stored in the clear.
- **The ledgers' keys** (`movvaLedgerWallets`), **the passkey's signatures** over each operation of the account (see
  *The account* below), and **sale accounts' owner keys** (a fresh P-256 key per sale, held by the page, sealed).
- **What the device keeps** - the viewing-key service's notes and lineage, ledger reservations, each sale's payee and
  salt and account key, the sales in progress (the wallet's sale journal: payee, salt, sale account, never its key), the audit grants issued, the activity list - is sealed in `localStorage` with
  XChaCha20-Poly1305 under a key derived from the seed, the record's name bound as associated data
  (src/wallet/stores.ts). A stolen browser profile holds ciphertext.
- **Proofs.** Withdrawal proofs (funding a sale) and commitment proofs (audit grants).
- **Verification.** Every LP node answer is checked against the chain before it is shown, as the wallet does in Node.

### Remote, told only what it must be

| Service | Learns |
|---|---|
| RPC | The account's reads and transactions (public anyway), pool logs, reserve and escrow state. |
| Matcher | The amount being quoted. |
| LP node | The order it was asked about, signed by its taker; a sale's payee (it pays it). |
| Relayer | A proven withdrawal, which it can submit or not but cannot change. |
| Co-signer | Each operation and ERC-1271 message of the account, with the passkey's signature over it; the account's recovery queue. It cannot sign without the passkey, and learns what the account does (docs/wallet-custody.md §11). |
| Bundler | Each signed UserOperation, which it can submit or not but cannot change. |
| Co-signer's sponsorship module (through SponsorGate) | That a new account - the user's, and each sale account - was enrolled and should be sponsored; it creates a Safe's passkey signer contract. The enrolments' client and timing link a user's session to the sale accounts it opens (docs/wallet-custody.md §11.1). |
| Push service (recovery alerts, opt-in) | That this device received a message from the co-signer, when, and its size; the message is encrypted to the device. |
| ASP | Nothing: the app downloads the public list of approved labels. |
| Note vault | Ciphertext, signed by the wallet's identity so nobody else can file under it. It is what lets a new device restore its history. |
| Share server | Recovery-code path only: one share, useless alone. |

### The account: a smart account of the passkey and the co-signer

The user's account is a **Safe 1.4.1 2-of-2** - owners the passkey's `SafeWebAuthnSigner` and the deployment's co-signer -
by default, or a **Kernel v3.1** account whose root validator, `PasskeyCoSignerValidator`, requires the same two keys
(docs/wallet-custody.md §1-4, §10-11). src/wallet/account.ts builds it from the library's executors:

- **Its owner** is the passkey created at onboarding: `navigator.credentials.create` asks for ES256 only, and the P-256
  public key comes from the registration response (`passkeyPublicKeyFromAttestation`, packages/smart-account's
  browser-passkey.ts). **Its salt** comes from the seed (HKDF, per kind), so the address follows from the passkey, the
  seed and the co-signer's pinned address. A device that never saw the registration recovers the key from two
  assertions of the same credential (`passkeyPublicKeyFromAssertions`: an ECDSA signature has two candidate keys, two
  signatures one), finds the kind whose account exists on-chain (else the default), and needs nothing stored.
- **Every call MovvaWallet makes from `account`** - lock, cancel, register or revoke an audit grant - is one operation:
  `SafeExecutor` or `KernelExecutor` asks the passkey for an assertion over its digest (`navigatorPasskey`: the digest as
  the challenge, the DER signature split into r and low s, clientDataJSON kept as signed), `RemoteCoSigner` sends the
  operation and that half to the co-signer, checks its answer recovers to the pinned address, and hands the whole
  operation to the bundler (`BundlerSubmitter` over `/api/bundler`); SponsorPaymaster pays. The LP node's
  payment-instructions requests are ERC-1271 signatures made the same way (Kernel: ERC-6492 before it exists).
- **Before the first operation** the account is enrolled with the co-signer, with one passkey assertion over the
  enrolment challenge. The co-signer's sponsorship module then allowlists it on SponsorPaymaster through SponsorGate, from
  its own operator key, first creating a Safe's passkey signer contract (which its first operation is validated through),
  and the app waits for it (`waitForSponsorship`). An enrolled account whose sponsorship was never requested, or was
  refused for a reason that may pass, is enrolled again, which asks again (`enrolAndSponsor`). Nothing in the app
  allowlists an account, and the demo stack has no endpoint that does. **The first operation installs recovery** first: `recoverySetupCalls` (Safe) or
  `kernelRecoverySetupCalls` (Kernel), a Zodiac Delay with a 7-day cooldown and the passkey's signer as its only module,
  before the lock it carries - the one authority change the co-signer's policy allows.
- **The co-signer is pinned**: /v1/info must name the address in the deployment JSON, on the deployment's chain.
- **Sale accounts** are new accounts of the user's kind whose owner is a P-256 key made for that sale and kept by this
  page, sealed (`softwarePasskey`): never the user's passkey, whose signer contract would be the same owner on-chain as
  the user's account and link the sale to every order it locked. The co-signer is their second key, as for every
  account of the deployment; each is sponsored, enrolled, and does its one operation (recovery, approve, openSale).
- **A wallet opened with a recovery code** has no passkey key: its account's owner is a P-256 key derived from the seed,
  as weak as that path.
- **The recovery queue** is read from the co-signer on every open; *Vetar a recuperação* sends `setTxNonce` alone, which
  the co-signer co-signs only on its veto route, with the passkey's fresh assertion.

Each operation is a passkey prompt on a real authenticator: a lock is one, and so is each payment-instructions request
(the wallet signs a fresh timestamp each time, so the screen's retries while the LP node catches up are prompts too).

### The prover: in a Web Worker, over artifacts the app serves

The app runs the wallet's own withdrawal prover in a **Web Worker** (src/wallet/prover.worker.ts):
`new SdkWithdrawalProver({ baseUrl })`, pointed at the Privacy Pools SDK's own artifacts - `withdraw.{wasm,zkey,vkey}`
and `commitment.*`, the bytes the Node prover uses, byte-identical to the ceremony keys vendored in protocol/circuits -
copied into the build under `circuits/sdk/artifacts/` and cached by the service worker after first use (about 24 MB,
once). With a `baseUrl` the SDK fetches them from there; the worker has no prove logic of its own. The prover checks
every proof's public signals against what was asked (`assertProofStates`), and the main thread checks them again before
the wallet uses it.

Audit grants need commitment proofs, which `MovvaWallet.shareWithAuditor` makes through the viewing key's
`proveDisclosure`. The session hands the wallet `commitmentArtifacts: () => commitmentArtifactsFrom({ baseUrl })`: the
first share fetches `commitment.{wasm,zkey,vkey}` from the same directory (3.3 MB; the verification key parsed, not a
file path) and the wallet keeps them. The commitment circuit is small; those proofs run on the main thread.

**Privacy consequence.** The witness - a note's nullifier and secret, the spending authority over that note - never
leaves the browser: the worker is same-origin, and the artifacts are fetched from the app's own origin, so no third
party sees even when a proof is made. What a proof costs is time on the device: seconds, more on a slow phone, shown
as "Gerando a prova neste aparelho".

**Rejected: a local companion process.** It would prove faster on weak phones, but the user would have to install and
run it, the witness would cross a local socket to it, and a phone - the main platform - cannot run one. It stays an
option for a desktop power user; nothing in the app assumes the prover is local to the page (`WithdrawalProver` is
an interface).

### What does not run in the browser

- **Dynamic PIX charges (API Pix `cob`).** Verifying one requires the PSP site's TLS certificate chain
  (packages/wallet/src/pix-cob.ts), which no browser exposes to a page. The wallet's browser entry swaps that module for
  pix-cob.browser.ts, which refuses such a code: `pix_location_host_not_allowed` for a host not on the list (the app
  configures none), `pix_location_unverifiable` for one that is - both explained in Portuguese with the free cancel. LP nodes
  serving this app must serve static BR Codes (`pixCharge: "static"`, the LP node's default) - or the check moves to a
  service the user trusts, which is a product decision.
- **Nothing else of the account.** It is a smart account whose every call is a sponsored UserOperation (below); the
  app holds no account key and the account holds no ETH.

## Keys, recovery, and a new device

A new device with the same passkey derives the same seed, so the same account and ledgers. On a device with no local
records, the session looks for deposits under the wallet's precommitments; if there are any, it rebuilds positions
from the pools (`MovvaWallet.recover`) and fetches the encrypted notes back from the note vault (`resyncNotes`), so the
balance, its cost and the tax year come back. Every note the device writes is filed with the vault as it is written,
and every unlock files them all again (the vault keeps each once), so a note that did not reach it is retried. A
balance refused because notes are missing offers to fetch them from the vault again.

**Recovering, then depositing.** A device with no records runs `MovvaWallet.recover()` whatever the pools hold, and
says "restored" only when it found something. This once needed a probe first: recovery used to start the next deposit a
whole gap (100 indices) past the last index it scanned, so a new wallet's first deposit landed at index 100, outside the
window the next device scans, and the first smoke run here restored nothing. The library now starts half a gap past the
last deposit (recoverByPrecommitment's `nextIndex`; packages/wallet/test/movva-recover.test.ts reproduces the app's
case), so what a device deposits after a recovery stays within the next restore's reach.

## The demo stack

`scripts/dev-stack.ts` starts its own anvil and first puts the smart-account stack on it
(packages/smart-account/examples/_account-stack.ts: EntryPoint v0.7, Safe 1.4.1 with its 4337 module and passkey signer
factory, Kernel v3.1 with PasskeyCoSignerValidator and KernelAvatarAdapter, the Zodiac Delay, SponsorPaymaster from the
root forge build, and Alto); then it deploys what packages/wallet/examples/movva-wallet-live.ts deploys
(its steps 1-4, the same way), from forge artifacts **copied to a temp dir first**, so a forge build running meanwhile
cannot change them under the deploy. Then:

| Port | |
|---|---|
| 8981 | the gateway: the built app (`dist/`), and `/api` (CORS open) for the dev server on 8980 |
| 8982 | anvil, one-second blocks |
| 8983 | the LP node's API: an institutional LP as a Movva gateway, MockBank, zkTLS proofs from local witness keys |
| 8984 | the matcher |
| 8985 | the note vault, gated on the deployed AuditGrantRegistry |
| 8986 | the co-signer (packages/cosigner's production entrypoint with a development key file; ops on 8988): its policy allowlists this deployment's contracts and the Movva approvals to them, CORS and WebAuthn pinned to http://localhost:8981 and :8980, RP id localhost. The app reaches it through the gateway's `/api/cosigner`, as it reaches the matcher, LP node and vault, so a browser needs port 8981 alone. Sponsorship on: SponsorGate (from `SPONSOR_GATE_ARTIFACT`, else forge-out) owns SponsorPaymaster, bounded to 1 ETH an operation and 5 ETH an account a day; the co-signer's own operator key sponsors at most 500 accounts a day. Recovery alerts on: a VAPID key file, one confirmation, any http(s) endpoint (development) |
| 8989 | Alto, the ERC-4337 bundler, for EntryPoint v0.7; the app reaches it through the gateway's `/api/bundler` |

The gateway also plays the relayer (it submits `Entrypoint.relay`, nothing else), the
ASP (approves every deposit label and posts the root, as the example's postman does), the Pyth keeper (republishes the
FX rate and the USDT feed every minute, so backing stays current however long a demo runs), the share server, and the
dev API (`/api/dev`: gas, pay PIX / boleto, sample bills, a test auditor key, and `faults` for the e2e tests:
`failNextOpenSale` answers the next openSale UserOperation with a bundler error, once - a sale whose exit landed and whose
openSale never reached the chain -, `holdAsp` holds the ASP's approvals, `raisePoolMinimum` has the Entrypoint's owner raise the
Movva pool's minimum deposit above any order (and restore it), and `holdNextExit` has the relayer take the next exit without
submitting it until `releaseHeldExits`. The app never sets them, and no check is skipped). The gateway also plays a
browser's push service: what the co-signer POSTs to `/api/dev/push/<id>` is kept, encrypted, and listed at `/api/dev/push`.

### Image mode: the services from the container image

`MOVA_SERVICES_IMAGE=<image>` runs the same stack with the off-chain services taken from the services image
(packages/ops/Dockerfile) instead of in-process from source. It deploys exactly as above, then starts the services as
containers (scripts/dev-stack-containers.ts), each with `--network=host`, as the image's `node` user (uid 1000), with its
service's config directory mounted read-only at `/app/config` and a data directory of its own at `/app/data`, as
packages/ops/docker-compose.yml wires them. `CONTAINER_RUNTIME` is `podman` (the default, daemonless) or `docker`.

| Container | Port | What |
|---|---|---|
| `movva-dev-lp-node` | 8983 | packages/lp-node's entrypoint, `LP_NODE_DEV=1`: the same strategy as above as its `LP_CONFIG`, the LP key and payerRef secret as files, the local zkTLS witness key file; its bank is the stack's MockBank, over `DEV_MOCK_BANK_URL` |
| `movva-dev-matcher` | 8984 | packages/ramp's entrypoint over this deployment's FiatEscrow, LPRegistry and Entrypoint |
| `movva-dev-vault` | 8985 | packages/viewing-key's entrypoint, gated on the deployed AuditGrantRegistry, its journal on the data volume |
| `movva-dev-cosigner` | 8986, ops 8988 | packages/cosigner's entrypoint with the same policy, sponsorship and recovery alerts as above; key files 0600, owned by uid 1000 |
| `movva-dev-monitor` | a free port | packages/ops's monitor over this deployment (pools, oracle, escrows, Movva reserve, relayers, paymaster, SponsorGate, governance history); its first sweep is printed at startup and its latest at `/api/dev/monitor` |

What stays on the host: anvil, Alto (a root devDependency, not in the image), the gateway and its dev API, the ASP, the
Pyth keeper, the share server and the relayer (an EOA stand-in: protocol/relayer is not in the image). The
MockBank stays here too, so "Simular pagamento", sample bills and `/api/dev/state`'s outgoing payments work
unchanged: a small dev bank API on a loopback port (lp-node's `serveDevMockBank`) serves their adapter side - never
`receivePix`, `pay` or fault injection - to `MockBankClient` in the container. The LP node takes
`DEV_MOCK_BANK_URL` only with `LP_NODE_DEV=1`, never beside `BANK_MODULE`, and its local witnesses read
that client's records only when it came from that variable.

```bash
# 1. the image, from the working tree (repository root; the dependency layer is cached, so a source change rebuilds in seconds)
podman build --network=host --format docker -f packages/ops/Dockerfile -t localhost/mova-services:dev .

# 2. the stack in image mode: wait for "[dev-stack] ready" and the table of containers and ports it prints
MOVA_SERVICES_IMAGE=localhost/mova-services:dev npx tsx packages/app/scripts/dev-stack.ts

# 3. against it, from another terminal
npx tsx packages/app/scripts/smoke.ts
MOVA_E2E_REUSE_STACK=1 npx playwright test -c packages/app/e2e

# 4. the containers
podman ps --filter name=movva-dev-
curl -s http://127.0.0.1:8981/api/dev/services     # containers, ports, log files, the dev bank API
curl -s http://127.0.0.1:8981/api/dev/monitor      # the monitor's latest sweep

# 5. stop: Ctrl+C (or SIGTERM) in the stack's terminal stops and removes every container; then nothing is left
podman ps -a --filter name=movva-dev-
```

Or let Playwright start and stop its own image-mode stack (the config passes `MOVA_SERVICES_IMAGE` and `CONTAINER_RUNTIME`
through, and allows 15 minutes to start and 60 seconds to stop):

```bash
MOVA_SERVICES_IMAGE=localhost/mova-services:dev npx playwright test -c packages/app/e2e
```

Each container's output is followed into `<temp dir>/containers/<service>/container.log` (the ready message names the
directory). A SIGINT, SIGTERM or SIGHUP at any point - during the deploy included - or a failed start stops and removes
every container under the prefix (`MOVA_CONTAINER_PREFIX`, default `movva-dev`), and the next start removes any a killed
stack left behind. The API listeners are the same host ports as in source mode, so the app, the smoke run and the specs
see no difference. On host networking every service the stack starts binds 127.0.0.1: the matcher, vault and monitor
through their `HOST` setting (every interface when unset, as a container publishing its port needs). The exception, in both
modes, is Alto: version 0.0.21 hard-codes `0.0.0.0` for its RPC, so while a stack runs port 8989 answers from outside unless
a firewall blocks it. It fronts only this throwaway chain, but keep 8980-8989 firewalled on a machine with a public address. As a non-root
user, rootless podman hands the files to uid 1000 with `podman unshare chown`, and a docker client runs the containers as
your own uid instead.

### Extras: the rest of the rail, for a test console

`DEV_STACK_EXTRAS=1` (source mode only) also deploys and runs what the rail has beside the app's own flows, on the same
chain, with switches at `/api/dev/extras` (scripts/dev-stack-extras.ts says what each one is). Unset, none of it exists:
the smoke run and the e2e specs see the stack above, unchanged.

| Extra | What runs | Switch |
|---|---|---|
| Divergence breaker | `DivergenceBreaker` (300 bps, halts redemptions) over one tripping `MockPriceSource`, built before the reserve as DeployMovva builds it; the stack keeps the source on the reserve's rate every 5 s | `POST /extras/breaker {mode: follow \| diverge, bps \| fail}` |
| FX leg | the real **pyth-keeper** (packages/yield) posting through MockPyth, from a Hermes the stack plays on a loopback port; the stack's own loop keeps only the USDT/USD feed | `POST /extras/fx {mode: live \| stale \| closed, rateE6}`: stale and closed backdate the chain's price past maxAge, and Hermes offers nothing newer (closed: its market hours say so) |
| Reserve yield | `YieldVault` + `ERC4626Adapter` over `StataLike` behind a `KeeperGate` (100% turnover a day, not the tests' 10%), set on the reserve before its setup closes; the real **vault-keeper** as the gate's operator | `POST /extras/yield/earn {usdt}`: the stata wrapper earns interest |
| Fees to LPs | `FeeSplitter` as the reserve's fee recipient (30% to NodeRewards), `NodeRewards` (one-day epochs and reviews) as the registry's rewards hook and bound to it; the LP node's `rewards` option claims. Nothing in the repository calls `split()`, so the stack does once a minute | `POST /extras/split` |
| Per-payer caps | the LP node's `caps`: Rev. 3 §12.1's outbound daily figures by tier, as one combined total per payer (the node keeps no per-direction total); every payer tier 4 unless named. `/pay-pix` and `/pay-boleto` take an optional `payerId` | `POST /extras/payer-tier {payerId, tier \| null}` |
| FROST | the co-signer's `COSIGNER_FROST_SHARES_FILE`, so it serves `/v1/frost/*`; `deployment.json` `extras.frostValidator` names the validator | - |

`GET /api/dev/extras` reads every extra's contracts and each service's own `/status`. The keepers' status servers bind
every interface (packages/yield `serveKeeper` takes no host), so the stack preloads them with
`scripts/dev-stack-loopback.mjs`, which binds a host-less `listen` to 127.0.0.1. Their logs
are in `<temp dir>/extras/`. Not here: the Privacy Pools relayer (it prices an ERC-20 pool's fee through Uniswap, which a
bare chain lacks), Lido, Superstate and the Hyperliquid vault (no stand-ins that fit a USDT reserve, or none at all).

**The service worker** is built from `src/sw/worker.ts` into `dist/sw.js`, one classic script, by a plugin in
vite.config.ts; `public/sw.js` is gone. Beside the app shell and circuit caching, it shows a recovery alert pushed by the
co-signer (`handleRecoveryPush`, in Portuguese, with the veto deadline in Brasília) and focuses or opens the app when it is
clicked (`handleRecoveryNotificationClick`), through `src/sw/handlers.ts`. It is registered only in a production build. The deployment JSON is served at
`/api/deployment.json` and written to `packages/app/.dev-stack/deployment.json`.

## Tests

```bash
npx vitest run packages/app            # under the root vitest config (packages/**/test/**/*.test.ts)
npx tsc -p packages/app/tsconfig.json  # src, test, scripts and vite.config.ts
npm run build -w @mova/app
```

The root `npx tsc --noEmit` also checks `packages/app/src` and `test` (the root tsconfig now sets `"jsx": "react-jsx"`).

| File | |
|---|---|
| `format.test.ts` | reais formatting and pt-BR parsing (and its refusals), dates in Brasília, backing full / partial / unknown / market closed, order and sale states |
| `refusals.test.ts` | every `PaymentRefused` and `SaleRefused` code in Portuguese (the tables are `Record`s over the wallet's code unions, so a new code fails `tsc`), cancel suggested only while free, overdue and no-due-date bills, backing refusals, the ASP; re-shield refusals in the deposit's words (under the pool minimum with the wallet's figures), several notes, an interrupted sale offering no retry, a sale key this device lacks, an operation the bundler did not take |
| `sponsorship.test.ts` | `enrolAndSponsor`: a new account enrolled, then waited for until the co-signer sponsors it; an account that can transact asks nothing; an enrolled one never asked, or refused for a reason that may pass, enrolled again; one refused for good not asked again; the co-signer saying sponsored while the paymaster does not, refused |
| `alerts.test.ts` | src/wallet/alerts.ts against a fake co-signer and PushManager: unavailable for an EOA, a co-signer without alerts or a browser without Push; subscribed only while the browser holds the recorded subscription; subscribing for the co-signer's VAPID key with the passkey; unsubscribing, refused while a recovery is queued (the device stays subscribed), and a device the co-signer never had |
| `sw-handlers.test.ts` | the service worker's handlers: a recovery alert shown in Portuguese with the deadline in Brasília and Início as its link, the alerts-off notice, other messages ignored, a click focusing the app or opening Início |
| `delivery-check.test.ts` | src/wallet/delivery-check.ts (the escape hatch's reads, one module kept free of the app so it can move into @mova/wallet unchanged) against a fake chain and `eth_call`: the pool's minimum above the order, no pool or another one, `dead()`, IssuerFreeze's probe (Tether's and Circle's lists, 30 000 gas, a revert or a short answer read as not frozen) on the escrow, Entrypoint, pool and rescue address, a frozen escrow or rescue address refusing delivery in the open, an order already switched or released, and the account's own freeze for putting Movva back |
| `delivery.test.ts` | each reason a shielded delivery would be refused, in Portuguese with its figures; the one-sentence privacy cost of taking delivery in the open; which orders Início lists |
| `pending.test.ts` | sales in progress: each stage's words, figures and buttons (none while an exit may still land, or while a call on it runs), what resuming came to, a balance awaiting approval, Movva in the open until put back, the one-sentence privacy cost of several notes |
| `deployment.test.ts` | the deployment JSON: relative endpoints, refusals naming the field, a smart account refused with what it needs, overrides |
| `stores.test.ts` | the sealed store (another seed cannot read it, a record moved under another name does not open), bigint JSON, the account key |
| `screens.test.ts` (happy-dom) | Home with full, partial and market-closed backing; the rail options; a PIX QR code; a refused payment and its free cancel; an overdue bill refused; the relayer fee; onboarding's recovery paragraph and the flagged fallback; a sale in progress continued from Início and cancelled from Vender, an exit waiting for the relayer with no button, a failed resume explained, a balance awaiting approval, a delivery in the open refused under the pool minimum, a cancelled sale put back, the several-notes opt-in, an interrupted sale; the delivery escape hatch (why, no payment details, the free cancel kept, *Receber fora do saldo protegido*), not offered when the issuer froze the escrow, and a delivery in the open waiting for the pool |

`scripts/smoke.ts` runs the flows headless against the dev stack, through the app's own `WalletSession` (the code the
browser opens), with the Node SDK prover in place of the worker and a software authenticator (real P-256 over the
WebAuthn payload, RP id localhost, the app's origin) in place of the passkey. On the smart-account stack it also checks
the account's ETH and operations from the chain, the sale account's owners, and that a new device finds the same
account. A run on 2026-09-14:

```
1. a new wallet: nothing on-chain, nothing recovered; R$ 0,00, lastro integral
2. buy R$ 50,00 by PIX: quoted beside boleto (pedido R$ 50,00);
   instructions verified on-chain; paid through the dev API; delivered, R$ 49,45 credited
3. an overdue bill: "Boleto vencido", refused before anything moved
4. sell R$ 20,00 to a PIX key: chega R$ 19,80, sai do saldo R$ 20,11; proof, relayed exit and sale in 30 s;
   the LP's bank sent R$ 19,80 to +5511987654321; settled
5. a second device, same seed: all 3 notes were in the vault; 2 positions and 3 notes restored; the same R$ 49,13
```

`e2e/` drives the built app in headless Chromium (Playwright, its own config, outside the vitest include):

```bash
npx playwright install chromium                     # once; in CI: --with-deps
npx playwright test -c packages/app/e2e             # builds dist/, starts scripts/dev-stack.ts, runs the specs
```

A Chrome DevTools Protocol virtual authenticator (CTAP2.1, internal, resident key, user verification, `hasPrf`) is the
passkey. After every step that sends something, the dev API's account report (`/api/dev/account`) is read from the
chain: **the account holds 0 ETH, and every UserOperation it sent succeeded, went from Alto's executor to the
EntryPoint, and was paid by SponsorPaymaster** - and its EntryPoint nonce equals their count.

- `movva.spec.ts`, on the default Safe 2-of-2, one serial run: create the wallet (its Safe only an address) -> buy
  R$ 50,00 by PIX (the first operation creates the Safe, installs recovery and locks), "Simular pagamento", delivered ->
  an overdue bill refused ("Boleto vencido") -> sell R$ 20,00 to a PIX key, the proof made in the app's Web Worker,
  settled; the sale account is another Safe, one sponsored operation, sharing only the co-signer with the user's ->
  reload and unlock with the same passkey -> a recovery transaction queued on the Delay with the passkey (what a
  stolen one would do, through `/api/dev/recovery/*`) is shown on open and vetoed -> a second browser context finds the
  same Safe and restores the same balance from the pools and the vault.
- `movva-kernel.spec.ts`: onboarding with *Kernel* chosen, then a purchase by PIX and a sale to a PIX key on the Kernel account,
  opened from another Kernel account whose owner key was made for that sale, the co-signer its second key.
- `movva-sales.spec.ts`, on a Safe: two purchases give two notes -> a sale larger than either is refused, *Usar várias notas* is
  offered unchecked with its privacy cost, and once checked the sale is quoted from 2 notes and settles -> a sale interrupted
  between its exit and its openSale (`failNextOpenSale`) says *Venda interrompida* with no retry; after a reload and an unlock
  Início lists it, *Continuar venda* opens it - one operation from its sale account - and it settles -> another sale interrupted
  the same way is cancelled: its Movva is deposited back from its sale account, shown *aguardando aprovação* apart from what can
  be spent while `holdAsp` holds the ASP, and counted as available once the ASP approves it -> an exit the relayer holds
  (`holdNextExit`): continued, the sale says *Aguardando o relayer* with no button, and once the relayer submits it the sale
  goes on by itself and settles.
- `movva-escape.spec.ts`, on a Safe: an order locked by PIX, the Movva pool's minimum then raised above it (`raisePoolMinimum`),
  and the order paid: it says why its shielded delivery is impossible, stops showing where to pay and offers *Receber fora do
  saldo protegido*; taken, the LP's release pays the account in the open (*Entregue fora do saldo protegido*) -> while the pool
  still refuses, *Devolver ao saldo protegido* waits with the reason; once restored it re-shields the Movva from the account,
  shown *aguardando aprovação* while the ASP is held, and available once approved.
- `movva-alerts.spec.ts`, on full Chromium (`channel: 'chromium'`; the headless shell denies notifications): onboarding ->
  Início offers the alerts once -> *Ativar alertas* subscribes this device, the request's subscription and passkey signature
  checked -> a recovery queued with the passkey -> the co-signer's encrypted push decrypts with the subscription's keys ->
  handed to the app's service worker, a non-alert message shows nothing and the alert shows Chromium's notification, which a
  click closes -> turning alerts off is refused while the recovery is queued (409 `recovery_pending`, explained, the switch
  stays on) -> after the veto it turns off, and the device gets the last notice. **Mocked:** `PushManager` in the page
  (headless Chromium has no push service: `subscribe` is refused), replaced by a subscription to the stack's push sink with a
  real P-256 key pair made in the page; the push service's delivery to the worker (CDP `ServiceWorker.deliverPushMessage`);
  and the click (a `NotificationEvent` dispatched in the worker). **Not mocked:** the co-signer, its passkey proofs, watcher,
  refusal and aes128gcm/VAPID sends, the service worker and its handlers, the notification, the queue and the veto.
- Every account an e2e spec creates is checked from the chain as sponsored the production way: one `SponsorGate.sponsor`,
  sent by the co-signer's operator key (`expectSponsoredByCoSigner`), for the user's Safe and Kernel accounts and their sale
  accounts; `/api/dev/sponsor` answers 404.

What PRF blocks in the second context, exactly: CDP copies a credential into another context's authenticator (id,
private key, user handle) but not its PRF secret, so its assertion carries no PRF output and the app refuses to open
("Não foi possível abrir a carteira", asserted); the test then relays the first context's PRF output into that - real
- assertion, as a synced passkey would carry it. The account's key is recovered from that context's own assertions.
The app is opened at `localhost`: Chrome refuses `127.0.0.1` as a passkey's relying party. Failures leave screenshots,
the console and a trace in `e2e/artifacts/` (gitignored). `MOVA_E2E_REUSE_STACK=1` uses a stack already running (the
sale-account checks count the accounts a sale adds, so a stack other runs used works too); `MOVA_E2E_SKIP_BUILD=1` the current dist/. Chromium needs its
system libraries (`--with-deps` installs them; without root, `LD_LIBRARY_PATH`).

## Found in the libraries, fixed there

Building this app turned up six things in the libraries that stood between them and a browser. Each is fixed in its library,
with a test, and the workaround here is gone:

- **`fetch` as a method.** `MatcherClient`, `LpNodeClient`, `VaultClient` and `ReclaimClient` stored `fetch` and called
  `this.fetchImpl(...)`, which a browser refuses ("Illegal invocation"). They now store it bound, the global one
  included (packages/wallet/test/browser-runtime.test.ts and the viewing key's and ramp's tests fake a browser's fetch).
- **`Buffer`.** `pix-brcode.ts` measured BR Code fields with `Buffer.byteLength` and `MovvaWallet` compared keys with
  `Buffer.equals`; both use `TextEncoder` and byte comparisons now, and the app installs no `Buffer`.
- **Node built-ins in the barrels.** @mova/wallet, @mova/viewing-key and @mova/ramp have browser entries (the `browser`
  condition of their package.json "exports": `src/browser.ts`), without the matcher's, vault's and arbitration
  services, the file store and the PIX charge verifier; `#pix-cob` and `#sdk-artifacts` ("imports") pick the browser
  variant inside shared modules. packages/wallet/test/browser-entry.test.ts bundles each for a browser and fails if our
  code reaches a Node built-in. The build aliases none now; `src/shims/assert.ts` stays, for the Privacy Pools SDK's own
  `import 'assert'`.
- **Circuit files.** `SdkWithdrawalProver` takes `baseUrl` or `loadArtifact`, `verifyCommitmentProofs` a parsed
  verification key, `MovvaWallet` (`commitmentArtifacts`) and `shareWithAuditor` (`artifacts`) the circuit as bytes;
  `commitmentArtifactsFrom({ baseUrl })` fetches it. The worker's copied prove logic, the `node:module`/`node:fs`/
  `node:path` shims and the build-time verification key are gone.
- **Recovery** (above).
- **CORS.** The LP node's counterparty API (`serveLpNode(..., { cors: { allowedOrigins } })`) and the matcher
  (`allowedOrigins`, env `ALLOWED_ORIGINS`) answer browsers from an explicit origin list, none by default. The demo
  still serves them same-origin through the gateway.

The app's relayer is still the dev stack's call-submitting endpoint (`HttpRelayer`): the wallet now has a client for the
Privacy Pools relayer service (`ProtocolRelayer`, protocol/relayer's `/relayer/details`, `/quote` and `/request`), which
relays Entrypoint withdrawals - the only call the app has a relayer submit - and the app does not use it yet.
