/**
 * Which custom error a contract call reverted with.
 *
 * The examples check refusals by name - `BankRailNeedsZkTls`, `RailNotAllowedForEndpoint`, `Underpaid` - because "it
 * threw" also passes when a call fails for a reason nobody meant to test: out of gas, a typo'd argument, the wrong
 * contract. viem decodes a revert against the ABI the call was made with, so a verifier's error that surfaces through an
 * escrow needs the verifier's errors in that ABI: `withErrorsOf`.
 */
import { BaseError, ContractFunctionRevertedError, type Abi } from 'viem';

export function revertName(e: unknown): string | undefined {
  if (!(e instanceof BaseError)) return undefined;
  const r = e.walk((x) => x instanceof ContractFunctionRevertedError);
  return r instanceof ContractFunctionRevertedError ? r.data?.errorName : undefined;
}

/** `abi`, plus the custom errors of every contract it calls into. */
export function withErrorsOf(abi: Abi, ...callees: Abi[]): Abi {
  return [...abi, ...callees.flatMap((c) => c.filter((x) => x.type === 'error'))];
}
