/**
 * The decoded args of an escrow event, checked rather than cast.
 *
 * The examples load contract ABIs from forge artifacts at runtime, so viem cannot type the logs
 * `getContractEvents` returns, and the old `log as { args: { offerId: Hex } }` told the compiler
 * whatever it wanted to hear. A log that was not there, or did not decode, surfaced later as
 * an `undefined` id inside some unrelated call. This asserts each field that is read, by the
 * type viem decodes it to, and throws naming the event and field otherwise.
 */
import type { Address, Hex } from 'viem';

/** The Solidity types read here, and what viem decodes each to. */
interface Decoded { bytes32: Hex; address: Address; bool: boolean; uint: bigint }

const IS: { [K in keyof Decoded]: (v: unknown) => boolean } = {
  bytes32: (v) => typeof v === 'string' && /^0x[0-9a-fA-F]{64}$/.test(v),
  address: (v) => typeof v === 'string' && /^0x[0-9a-fA-F]{40}$/.test(v),
  bool: (v) => typeof v === 'boolean',
  uint: (v) => typeof v === 'bigint',
};

/**
 * @param log    a log from `getContractEvents` (or `undefined` when none matched)
 * @param event  the event's name, for the error
 * @param shape  each arg that will be read, with its Solidity type
 */
export function eventArgs<const S extends Record<string, keyof Decoded>>(
  log: unknown, event: string, shape: S,
): { [K in keyof S]: Decoded[S[K]] } {
  const args = typeof log === 'object' && log !== null && 'args' in log ? log.args : undefined;
  if (typeof args !== 'object' || args === null) throw new Error(`${event}: no such log, or it did not decode`);
  for (const [name, type] of Object.entries(shape)) {
    const v = (args as Record<string, unknown>)[name];
    if (!IS[type](v)) throw new Error(`${event}.${name}: expected ${type}, got ${String(v)}`);
  }
  return args as { [K in keyof S]: Decoded[S[K]] };
}
