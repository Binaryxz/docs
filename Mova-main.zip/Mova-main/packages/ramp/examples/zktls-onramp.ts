/**
 * The on-ramp settled by a zkTLS proof, against a live chain (task 2.2 end to end).
 *
 * PIX settles only on a zkTLS claim about a TLS session with the bank, where colluding
 * witnesses can censor but cannot invent a payment out of nothing: the escrows refuse a PIX or
 * boleto offer on a verifier that does not prove the session (BankRailNeedsZkTls). onramp.ts wires that verifier by
 * hand, next to the pool and a boleto; this proves the same rail with everything deployed by
 * contracts/script/DeployRamp.s.sol - the same script a real deployment uses - so the wiring
 * under test is the wiring that ships.
 *
 *   npx tsx packages/ramp/examples/zktls-onramp.ts <ppEntrypoint> <ppPool> [rpc]
 */
import {
  createWalletClient, createPublicClient, http, parseEther, formatEther, defineChain,
  keccak256, toBytes, type Hex, type Address,
} from 'viem';
import { privateKeyToAccount, generatePrivateKey } from 'viem/accounts';
import { readFileSync } from 'node:fs';
import { eventArgs } from './_event-args.js';
import { execFileSync } from 'node:child_process';
import { Rail, railMask, pixKeyCommitment, newPixSalt } from '../src/attestor.js';
import { buildProof, encodeProof, hashProviderParams, type HttpProviderParams } from '../src/reclaim.js';
import { IndexedPoolState } from '../../viewing-key/src/pool/indexer.js';
import { fetchPoolLogs } from '../../viewing-key/src/pool/rpc-source.js';
import { commitmentSecrets, precommitmentOf } from '../../viewing-key/src/pool/scheme.js';
import { walletFromSeed } from '../../viewing-key/src/keys.js';
import { resolveScanRange } from '../../viewing-key/examples/_scan-range.js';

/** A secret salt per PIX key for this run: the on-chain commitment must not be reversible. */
const pixSalts = new Map<string, Hex>();
const pix = (key: string): Hex => {
  if (!pixSalts.has(key)) pixSalts.set(key, newPixSalt());
  return pixKeyCommitment(key, pixSalts.get(key)!);
};

const [ppEntrypoint, ppPool, rpcArg] = process.argv.slice(2);
if (!ppEntrypoint || !ppPool) {
  console.error('usage: zktls-onramp.ts <ppEntrypoint> <ppPool> [rpc]');
  process.exit(2);
}
const RPC = rpcArg ?? process.env.RPC_URL ?? 'http://127.0.0.1:8545';
const CHAIN_ID = Number(process.env.CHAIN_ID ?? 1);
const chain = defineChain({
  id: CHAIN_ID, name: 'anvil-fork', nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
  rpcUrls: { default: { http: [RPC] } },
});
const pub = createPublicClient({ chain, transport: http(RPC) });

const step = (s: string) => console.log(`\n\x1b[1m${s}\x1b[0m`);
const ok = (s: string) => console.log(`  \x1b[32mOK\x1b[0m    ${s}`);
const bad = (s: string) => { console.log(`  \x1b[31mFAIL\x1b[0m  ${s}`); process.exitCode = 1; };
const info = (k: string, v: unknown) => console.log(`        ${k.padEnd(26)} ${v}`);

const art = (name: string, file?: string) =>
  JSON.parse(readFileSync(
    new URL(`../../../forge-out/${file ?? `${name}.sol`}/${name}.json`, import.meta.url), 'utf8'));

const FUNDER = privateKeyToAccount('0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80');
const funder = createWalletClient({ account: FUNDER, chain, transport: http(RPC) });
const ZERO_ASSET = '0x0000000000000000000000000000000000000000' as Address;
const CHAINLINK_ETH_USD = '0x5f4eC3Df9cbd43714FE2740f5E3616155c5b8419' as Address;

/**
 * The bank endpoint the verifier will accept: a Reclaim provider TEMPLATE, pinned on-chain by
 * its `providerHash`, plus the URL prefix its `url` must start with.
 *
 * A proof settles only for an allowlisted endpoint. Checking the provider string instead
 * (`"http"`, for every Reclaim claim) admitted a session with ANY server - see SR2-11 in
 * docs/security-review-phase2.md. The template here is illustrative: a real one comes from
 * Reclaim for a real bank, and must capture every field the verifier reads.
 */
const BANK_URL_PREFIX = 'https://api.bancoexemplo.com.br/pix/';
const BANK_PARAMS: HttpProviderParams = {
  url: `${BANK_URL_PREFIX}receipts/{{e2eId}}`,
  method: 'GET',
  body: '',
  paramValues: { e2eId: 'E00000000202609131200DEMO' },
  responseMatches: [
    { type: 'regex', value: '"amountBrlCents":"(?<amountBrlCents>[0-9]+)"' },
    { type: 'regex', value: '"endToEndId":"(?<bankTxId>0x[0-9a-f]{64})"' },
    { type: 'regex', value: '"settledAt":"(?<paidAt>[0-9]+)"' },
    { type: 'regex', value: '"payeeKeyHash":"(?<payeeKeyHash>0x[0-9a-f]{64})"' },
    { type: 'regex', value: '"payerRef":"(?<payerRef>0x[0-9a-f]{64})"' },
    { type: 'regex', value: '"rail":"(?<rail>[0-9])"' },
  ],
  responseRedactions: [{ jsonPath: '$.receipt', regex: '', xPath: '' }],
};
const BANK_TEMPLATE = hashProviderParams(BANK_PARAMS);
/** R$1,000,000 of credit, in centavos: live exposure across every offer and claim. */
const LP_CREDIT_CENTS = 100_000_000n;
const PIX_KEY = 'lp-liquidez@pix.example';

async function deploy(name: string, args: unknown[], value = 0n, file?: string): Promise<Address> {
  const a = art(name, file);
  const hash = await funder.deployContract({
    abi: a.abi, bytecode: a.bytecode.object as Hex, args: args as never, value,
  });
  const r = await pub.waitForTransactionReceipt({ hash });
  if (!r.contractAddress) throw new Error(`${name} failed to deploy`);
  return r.contractAddress;
}

async function fund(to: Address, amount: bigint) {
  await pub.waitForTransactionReceipt({ hash: await funder.sendTransaction({ to, value: amount }) });
}

async function main() {
  const gov = privateKeyToAccount(generatePrivateKey());
  const govWallet = createWalletClient({ account: gov, chain, transport: http(RPC) });
  const lp = privateKeyToAccount(generatePrivateKey());
  const lpWallet = createWalletClient({ account: lp, chain, transport: http(RPC) });
  const taker = privateKeyToAccount(generatePrivateKey());
  const takerWallet = createWalletClient({ account: taker, chain, transport: http(RPC) });
  const arbitrator = privateKeyToAccount(generatePrivateKey());
  await fund(gov.address, parseEther('2'));
  await fund(lp.address, parseEther('12'));
  await fund(taker.address, parseEther('1'));

  const w1 = generatePrivateKey();
  const w2 = generatePrivateKey();
  const witnesses = [privateKeyToAccount(w1).address, privateKeyToAccount(w2).address];

  step('1. Deploy the ramp with the real deploy script');
  // A fresh-timestamped republish of the genuine mainnet price: a fork freezes Chainlink
  // while block.timestamp advances, and the escrow rightly refuses a stale feed.
  const [, realEthUsd] = await pub.readContract({
    address: CHAINLINK_ETH_USD,
    abi: [{
      name: 'latestRoundData', type: 'function', stateMutability: 'view', inputs: [],
      outputs: [{ type: 'uint80' }, { type: 'int256' }, { type: 'uint256' },
                { type: 'uint256' }, { type: 'uint80' }],
    }],
    functionName: 'latestRoundData',
  }) as [bigint, bigint, bigint, bigint, bigint];
  const ethUsd = await deploy('MockFeed', [realEthUsd, 8], 0n, 'RampIntegration.t.sol');
  const brlUsd = await deploy('MockFeed', [20000000n, 8], 0n, 'RampIntegration.t.sol');

  // The pinned toolchain, not whatever forge is on PATH: FORGE if set (TESTING.md exports it),
  // otherwise the repo's resolver, which fetches the pinned version on first use.
  const root = new URL('../../../', import.meta.url).pathname;
  const forge = process.env.FORGE
    ?? execFileSync('bash', ['scripts/foundry.sh', 'path'], { cwd: root, encoding: 'utf8' }).trim();
  const out = execFileSync(
    forge,
    ['script', 'contracts/script/DeployRamp.s.sol:DeployRamp',
     '--rpc-url', RPC, '--broadcast', '--private-key', FUNDER_KEY, '--skip-simulation'],
    {
      cwd: root,
      env: {
        ...process.env,
        GOVERNOR: gov.address,
        PP_ENTRYPOINT: ppEntrypoint,
        PP_POOL: ppPool,
        ARBITRATOR: arbitrator.address,
        ZKTLS_WITNESSES: witnesses.join(','),
        ZKTLS_THRESHOLD: '2',
        // No default exists: the script refuses to deploy a verifier without endpoints.
        ZKTLS_PROVIDER_HASHES: BANK_TEMPLATE,
        ZKTLS_URL_PREFIXES: BANK_URL_PREFIX,
        // Phase A LPs are admitted during setup, before the script closes it. Admitting one
        // afterwards is a scheduled change that waits out GOVERNANCE_DELAY.
        INSTITUTIONAL_LPS: lp.address,
        INSTITUTIONAL_CREDIT_CENTS: String(LP_CREDIT_CENTS),
        CHAINLINK_ETH_USD: ethUsd,
        CHAINLINK_BRL_USD: brlUsd,
      },
      encoding: 'utf8',
    },
  );
  const pick = (label: string): Address => {
    const m = out.match(new RegExp(`${label}\\s+(0x[0-9a-fA-F]{40})`));
    if (!m) throw new Error(`deploy script did not report ${label}\n${out}`);
    return m[1] as Address;
  };
  const escrow = pick('on-ramp escrow');
  const zktls = pick('zktls verifier');
  const registry = pick('registry');
  ok('deployed and wired by DeployRamp.s.sol, which asserts its own wiring');
  info('on-ramp escrow', escrow);
  info('zktls verifier', zktls);

  const ESC = art('FiatEscrow').abi;
  const REG = art('LPRegistry').abi;
  const ZK = art('ReclaimZkTlsVerifier').abi;

  const send = async (w: typeof govWallet, address: Address, abi: unknown, fn: string, args: unknown[], value = 0n) => {
    const h = await w.writeContract({ address, abi: abi as never, functionName: fn, args: args as never, value });
    const r = await pub.waitForTransactionReceipt({ hash: h });
    if (r.status !== 'success') throw new Error(`${fn} reverted`);
    return r;
  };

  const onChainPrefix = await pub.readContract({
    address: zktls, abi: ZK, functionName: 'endpointUrlPrefix', args: [BANK_TEMPLATE],
  }) as string;
  if (onChainPrefix !== BANK_URL_PREFIX) return bad('the bank endpoint is not allowlisted');
  ok(`verifier accepts one bank endpoint: ${BANK_URL_PREFIX} (template ${BANK_TEMPLATE.slice(0, 10)}...)`);
  // A PIX receipt template attests PIX and nothing else unless the governor widens it.
  const rails = await pub.readContract({
    address: zktls, abi: ZK, functionName: 'endpointRails', args: [BANK_TEMPLATE],
  }) as number;
  if (rails !== railMask(Rail.PIX)) return bad(`the endpoint attests rails ${rails}, not PIX alone`);
  ok('and only for PIX: a boleto proof from this template would be refused (RailNotAllowedForEndpoint)');
  for (const [c, name] of [[zktls, 'zktls verifier'], [escrow, 'escrow'], [registry, 'registry']] as const) {
    const done = await pub.readContract({ address: c, abi: ZK, functionName: 'setupComplete' }) as boolean;
    if (!done) return bad(`${name}: setup still open`);
  }
  const credit = await pub.readContract({
    address: registry, abi: REG, functionName: 'capOf', args: [lp.address],
  }) as bigint;
  if (credit !== LP_CREDIT_CENTS) return bad('the LP was not admitted at deployment');
  ok('setup closed everywhere; the LP was admitted as INSTITUTIONAL during it');

  // A risk-increasing change now has to wait. Sending one directly is refused.
  try {
    await send(govWallet, registry, REG, 'setTier', [taker.address, 3, 1n]);
    bad('the governor admitted an LP without waiting out the governance delay');
  } catch {
    ok('the governor cannot admit another LP without scheduling it first');
  }

  step('2. LP posts liquidity, priced off the oracle');
  const price = 1_244_910n; // read below; posted at the market rate
  const [oraclePrice] = await pub.readContract({
    address: await pub.readContract({ address: escrow, abi: ESC, functionName: 'ORACLE' }) as Address,
    abi: art('ChainlinkBrlOracle').abi, functionName: 'brlCentsPerUnit',
  }) as [bigint, bigint];
  void price;
  await send(lpWallet, escrow, ESC, 'postOffer',
    [ZERO_ASSET, parseEther('10'), oraclePrice, pix(PIX_KEY), parseEther('0.05'),
     parseEther('5'), zktls, railMask(Rail.PIX)], parseEther('10'));
  const offerLogs = await pub.getContractEvents({
    address: escrow, abi: ESC, eventName: 'OfferPosted', fromBlock: 'latest',
  });
  const { offerId } = eventArgs(offerLogs[offerLogs.length - 1], 'OfferPosted', { offerId: 'bytes32' });
  ok(`10 ETH posted at R$ ${(Number(oraclePrice) / 100).toLocaleString('pt-BR')} / ETH`);

  step('3. Taker locks, choosing a shielded destination');
  const wallet = walletFromSeed(crypto.getRandomValues(new Uint8Array(32)));
  const { nullifier, secret } = commitmentSecrets(wallet.spendingSecret, 0, 0);
  const precommitment = precommitmentOf(nullifier, secret);

  const scan = resolveScanRange(CHAIN_ID, ppPool, await pub.getBlockNumber());
  const scope = await pub.readContract({
    address: ppPool as Address,
    abi: [{ name: 'SCOPE', type: 'function', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint256' }] }],
    functionName: 'SCOPE',
  }) as bigint;
  const before = new IndexedPoolState(scope);
  before.apply(await fetchPoolLogs({ url: RPC, pool: ppPool, fromBlock: scan.fromBlock }));
  const rootBefore = before.root();

  const lockRc = await send(takerWallet, escrow, ESC, 'lockOrder',
    [offerId, parseEther('0.5'), 1 /* SHIELDED */, taker.address, precommitment]);
  const lockLogs = await pub.getContractEvents({
    address: escrow, abi: ESC, eventName: 'OrderLocked', blockHash: lockRc.blockHash,
  });
  const { orderId } = eventArgs(lockLogs[0], 'OrderLocked', { orderId: 'bytes32' });
  const order = await pub.readContract({
    address: escrow, abi: ESC, functionName: 'orders', args: [orderId],
  }) as unknown[];
  const brlCents = order[3] as bigint;
  ok(`locked; taker owes R$ ${(Number(brlCents) / 100).toLocaleString('pt-BR')}`);

  step('4. The taker pays by PIX; witnesses observe the TLS session');
  const payment = {
    orderId,
    bankTxId: keccak256(toBytes(`E${Date.now()}ZKTLS`)),
    payeeKeyHash: pix(PIX_KEY),
    payerRef: keccak256(toBytes('cpf:***.***.***-**')),
    amountBrlCents: brlCents,
    paidAt: BigInt((await pub.getBlock()).timestamp),
    rail: Rail.PIX,
  };
  // The witness writes providerHash and the extracted fields into the context; buildProof
  // plays the witness here. In production the fields come out of the bank's TLS response.
  const proof = await buildProof({
    params: BANK_PARAMS, payment, witnessKeys: [w1, w2], owner: taker.address,
  });
  ok('zkTLS claim built and signed by 2 witnesses');
  info('claim identifier', proof.signedClaim.claim.identifier.slice(0, 26) + '...');

  step('5. Release');
  await send(takerWallet, escrow, ESC, 'releaseWithProof', [orderId, encodeProof(proof)]);
  ok('the escrow verified the zkTLS proof and released');

  step('6. Did a shielded balance appear?');
  const after = new IndexedPoolState(scope);
  after.apply(await fetchPoolLogs({ url: RPC, pool: ppPool, fromBlock: scan.fromBlock }));
  const onChainRoot = await pub.readContract({
    address: ppPool as Address,
    abi: [{ name: 'currentRoot', type: 'function', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint256' }] }],
    functionName: 'currentRoot',
  }) as bigint;
  if (after.root() === rootBefore) return bad('the pool tree did not grow');
  if (after.root() !== onChainRoot) return bad('our rebuilt root disagrees with the contract');
  ok('pool tree grew, and our rebuilt root matches the contract exactly');
  const mine = after.depositsBy([escrow]);
  info('shielded value', `${formatEther(BigInt(mine[mine.length - 1].value))} ETH`);

  step('7. The binding property, on a live chain');
  const other = await send(takerWallet, escrow, ESC, 'lockOrder',
    [offerId, parseEther('0.5'), 0 /* DIRECT */, taker.address, 0n]);
  const otherId = eventArgs((await pub.getContractEvents({
    address: escrow, abi: ESC, eventName: 'OrderLocked', blockHash: other.blockHash,
  }))[0], 'OrderLocked', { orderId: 'bytes32' }).orderId;
  try {
    await send(takerWallet, escrow, ESC, 'releaseWithProof', [otherId, encodeProof(proof)]);
    bad('a proof for one order settled another');
  } catch {
    ok('a genuine proof for another order is refused');
  }

  console.log('\n  \x1b[1mBRL in by PIX, proven by zkTLS, shielded balance out.\x1b[0m');
  console.log('  Witnesses can refuse to attest. They cannot invent a payment.\n');
}

const FUNDER_KEY = '0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80';

main().catch((e) => { console.error('\nfailed:', e.shortMessage ?? e.message ?? e); process.exit(1); });
