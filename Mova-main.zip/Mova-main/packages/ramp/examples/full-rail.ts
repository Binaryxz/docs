/**
 * Phase 1 and Phase 2 as ONE rail, against a live chain.
 *
 * Each existing script proves a segment. None proved the joins, and the joins are where a
 * product either works or quietly does not:
 *
 *   - the ramp's demos use a plain EOA taker, never the Phase 1 passkey-seeded wallet;
 *   - the off-ramp's seller was funded by a transfer "standing in for" a pool exit, so the
 *     sell leg had never actually started from shielded money;
 *   - and nothing had ever audited a RAMP deposit with a viewing key, which is the whole
 *     point of the product: BRL in, and provable to Receita Federal afterwards.
 *
 * So this runs the lot, in order, with no stand-ins:
 *
 *   passkey (PRF)  ->  BRL in by PIX, proven by zkTLS  ->  shielded balance in the real pool
 *                  ->  scoped disclosure an auditor verifies
 *                  ->  real groth16 withdrawal to a fresh address
 *                  ->  that address sells for BRL  ->  money in a bank account, proven by zkTLS
 *
 * Both PIX legs settle on a zkTLS proof of the bank session through ReclaimZkTlsVerifier - the only way PIX settles. Its witnesses are local keys standing
 * in for Reclaim's attestor network (_zktls.ts), as in every example that settles a bank payment; the stand-ins this run
 * removes are the ones BETWEEN the segments.
 *
 *   npx tsx packages/ramp/examples/full-rail.ts <ppEntrypoint> <ppPool> [rpc]
 */
import {
  createWalletClient, createPublicClient, http, parseEther, formatEther, defineChain,
  keccak256, toBytes, type Hex, type Address,
} from 'viem';
import { privateKeyToAccount, generatePrivateKey } from 'viem/accounts';
import { readFileSync } from 'node:fs';
import { eventArgs } from './_event-args.js';
import { LeanIMT } from '@zk-kit/lean-imt';
import { poseidon2 } from 'poseidon-lite';
import {
  Circuits, PrivacyPoolSDK, calculateContext, getCommitment, type Hash, type Secret,
} from '@0xbow/privacy-pools-core-sdk';
import { Rail, railMask, pixKeyCommitment, newPixSalt } from '../src/attestor.js';
import { PIX_RECEIPT, localWitnesses, pixReceiptProof, zkTlsVerifierArgs } from './_zktls.js';
import { matchOrder, type Offer } from '../src/orderbook.js';
import { IndexedPoolState } from '../../viewing-key/src/pool/indexer.js';
import { fetchPoolLogs } from '../../viewing-key/src/pool/rpc-source.js';
import {
  commitmentSecrets, precommitmentOf, nullifierHashOf,
} from '../../viewing-key/src/pool/scheme.js';
import { walletFromSeed, epochViewingKey } from '../../viewing-key/src/keys.js';
import { NoteLog } from '../../viewing-key/src/notes.js';
import { issueDisclosure, grantId, logKey } from '../../viewing-key/src/disclosure.js';
import { auditDisclosure } from '../../viewing-key/src/audit.js';
import { proveCommitment, releaseProofWorkers, verifyCommitmentProofs } from '../../viewing-key/src/proofs.js';
import { LocalGrantRegistry } from '../../viewing-key/src/vault.js';
import { PasskeyAuthenticator } from '../../smart-account/src/passkey.js';
import { openSeed, PrfSeedSource } from '../../smart-account/src/seed-source.js';
import { bytesToHex } from '@noble/hashes/utils';
import { resolveScanRange } from '../../viewing-key/examples/_scan-range.js';

/** A secret salt per PIX key for this run: the on-chain commitment must not be reversible. */
const pixSalts = new Map<string, Hex>();
const pix = (key: string): Hex => {
  if (!pixSalts.has(key)) pixSalts.set(key, newPixSalt());
  return pixKeyCommitment(key, pixSalts.get(key)!);
};

const POOL_ABI = [
  { type: 'function', name: 'SCOPE', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint256' }] },
  { type: 'function', name: 'currentRoot', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint256' }] },
  { type: 'function', name: 'nonce', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint256' }] },
  {
    type: 'function',
    name: 'withdraw',
    stateMutability: 'nonpayable',
    inputs: [
      { name: '_w', type: 'tuple', components: [
        { name: 'processooor', type: 'address' },
        { name: 'data', type: 'bytes' },
      ]},
      { name: '_p', type: 'tuple', components: [
        { name: 'pA', type: 'uint256[2]' },
        { name: 'pB', type: 'uint256[2][2]' },
        { name: 'pC', type: 'uint256[2]' },
        { name: 'pubSignals', type: 'uint256[8]' },
      ]},
    ],
    outputs: [],
  },
] as const;

const ENTRYPOINT_ABI = [
  {
    type: 'function',
    name: 'deposit',
    stateMutability: 'payable',
    inputs: [{ name: '_precommitment', type: 'uint256' }],
    outputs: [{ name: '_commitment', type: 'uint256' }],
  },
  {
    type: 'function',
    name: 'updateRoot',
    stateMutability: 'nonpayable',
    inputs: [{ name: '_root', type: 'uint256' }, { name: '_ipfsCID', type: 'string' }],
    outputs: [{ name: '_index', type: 'uint256' }],
  },
] as const;

const [ppEntrypoint, ppPool, rpcArg] = process.argv.slice(2);
if (!ppEntrypoint || !ppPool) {
  console.error('usage: full-rail.ts <ppEntrypoint> <ppPool> [rpc]');
  process.exit(2);
}
const RPC = rpcArg ?? process.env.RPC_URL ?? 'http://127.0.0.1:8545';
const CHAIN_ID = Number(process.env.CHAIN_ID ?? 1);
const chain = defineChain({
  id: CHAIN_ID, name: 'anvil-fork', nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
  rpcUrls: { default: { http: [RPC] } },
});
const pub = createPublicClient({ chain, transport: http(RPC) });

const step = (s: string) => console.log(`\n\x1b[1m${s}\x1b[0m`);
const ok = (s: string) => console.log(`  \x1b[32mOK\x1b[0m    ${s}`);
const bad = (s: string) => { console.log(`  \x1b[31mFAIL\x1b[0m  ${s}`); process.exitCode = 1; };
const info = (k: string, v: unknown) => console.log(`        ${k.padEnd(26)} ${v}`);
const brl = (c: bigint) => `R$ ${(Number(c) / 100).toLocaleString('pt-BR')}`;

const art = (n: string, f?: string) =>
  JSON.parse(readFileSync(new URL(`../../../forge-out/${f ?? `${n}.sol`}/${n}.json`, import.meta.url), 'utf8'));

const FUNDER = privateKeyToAccount('0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80');
const funder = createWalletClient({ account: FUNDER, chain, transport: http(RPC) });
const NATIVE = '0x0000000000000000000000000000000000000000' as Address;
const CHAINLINK_ETH_USD = '0x5f4eC3Df9cbd43714FE2740f5E3616155c5b8419' as Address;
const LP_PIX = 'lp-liquidez@pix.example';
const SELLER_PIX = 'vendedor@pix.example';

/**
 * Every governed contract starts in SETUP: changes are instant and all user business is
 * refused. The demo wires everything in that window, then closes it. After `completeSetup()`
 * a risk-increasing change (a verifier, an LP's tier, a threshold) must be scheduled and wait
 * out GOVERNANCE_DELAY, which is why nothing is configured after that point.
 */
const GOVERNANCE_DELAY = 48n * 60n * 60n;
/** The deploy script's default dispute timeout. */
const DISPUTE_TIMEOUT = 30n * 24n * 60n * 60n;
/** LPRegistry.Tier: NONE, RETAIL, AFFILIATED, INSTITUTIONAL, SUSPENDED. */
const TIER_INSTITUTIONAL = 3;

async function deploy(n: string, args: unknown[], v = 0n, f?: string): Promise<Address> {
  const a = art(n, f);
  const h = await funder.deployContract({ abi: a.abi, bytecode: a.bytecode.object as Hex, args: args as never, value: v });
  const r = await pub.waitForTransactionReceipt({ hash: h });
  if (!r.contractAddress) throw new Error(`${n} failed to deploy`);
  return r.contractAddress;
}
async function fund(to: Address, v: bigint) {
  await pub.waitForTransactionReceipt({ hash: await funder.sendTransaction({ to, value: v }) });
}
const send = async (w: ReturnType<typeof createWalletClient>, a: Address, abi: unknown, fn: string, args: unknown[], v = 0n) => {
  const h = await w.writeContract({ address: a, abi: abi as never, functionName: fn, args: args as never, value: v, account: w.account!, chain });
  const r = await pub.waitForTransactionReceipt({ hash: h });
  if (r.status !== 'success') throw new Error(`${fn} reverted`);
  return r;
};

async function main() {
  const scope = await pub.readContract({ address: ppPool as Address, abi: POOL_ABI, functionName: 'SCOPE' }) as bigint;
  const scan = resolveScanRange(CHAIN_ID, ppPool, await pub.getBlockNumber());
  const POOL_ID = `pp:${CHAIN_ID}:${ppPool.toLowerCase()}`;

  // ---------------------------------------------------------------- 1. the wallet
  step('1. A seedless wallet, from a passkey');
  const passkey = PasskeyAuthenticator.create('wallet.brl.example');
  const { seed, kind: seedKind } = await openSeed([PrfSeedSource.fromSimulator(passkey)]);
  const wallet0 = walletFromSeed(seed);
  info('credential', `${bytesToHex(passkey.credentialId).slice(0, 18)}...`);
  info('seed source', seedKind);
  ok('a spending key that exists only while the passkey is present');

  // ---------------------------------------------------------------- 2. the ramp
  step('2. Deploy the ramp, pointed at the SAME pool Phase 1 uses');
  const gov = privateKeyToAccount(generatePrivateKey());
  const govW = createWalletClient({ account: gov, chain, transport: http(RPC) });
  const lp = privateKeyToAccount(generatePrivateKey());
  const lpW = createWalletClient({ account: lp, chain, transport: http(RPC) });
  const taker = privateKeyToAccount(generatePrivateKey());
  const takerW = createWalletClient({ account: taker, chain, transport: http(RPC) });
  await fund(gov.address, parseEther('2'));
  await fund(lp.address, parseEther('12'));
  await fund(taker.address, parseEther('2'));

  const [, realEthUsd] = await pub.readContract({
    address: CHAINLINK_ETH_USD,
    abi: [{ name: 'latestRoundData', type: 'function', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint80' }, { type: 'int256' }, { type: 'uint256' }, { type: 'uint256' }, { type: 'uint80' }] }],
    functionName: 'latestRoundData',
  }) as [bigint, bigint, bigint, bigint, bigint];
  const ethUsd = await deploy('MockFeed', [realEthUsd, 8], 0n, 'RampIntegration.t.sol');
  const brlUsd = await deploy('MockFeed', [20000000n, 8], 0n, 'RampIntegration.t.sol');
  const oracle = await deploy('ChainlinkBrlOracle', [ethUsd, brlUsd, 3600n, gov.address, GOVERNANCE_DELAY]);
  const registry = await deploy('LPRegistry', [gov.address, GOVERNANCE_DELAY]);
  // Both PIX legs settle on witnesses to a session with the bank's Pix receipt endpoint; no boleto here, so no boleto endpoint.
  const witnesses = localWitnesses(2);
  const verifier = await deploy('ReclaimZkTlsVerifier', zkTlsVerifierArgs(gov.address, GOVERNANCE_DELAY, witnesses.addresses, [PIX_RECEIPT]));
  const onramp = await deploy('FiatEscrow', [oracle, registry, ppEntrypoint as Address, ppPool as Address, 500n, gov.address, GOVERNANCE_DELAY, DISPUTE_TIMEOUT]);
  const offramp = await deploy('OffRampEscrow', [oracle, registry, 500n, gov.address, GOVERNANCE_DELAY, DISPUTE_TIMEOUT]);

  const ESC = art('FiatEscrow').abi; const OFF = art('OffRampEscrow').abi;
  const REG = art('LPRegistry').abi; const ORA = art('ChainlinkBrlOracle').abi;
  await send(govW, registry, REG, 'setEscrow', [onramp, true]);
  await send(govW, registry, REG, 'setEscrow', [offramp, true]);
  await send(govW, onramp, ESC, 'setVerifier', [verifier, true]);
  await send(govW, offramp, OFF, 'setVerifier', [verifier, true]);
  // One credit limit across both escrows: every offer, order and claimed sale counts.
  await send(govW, registry, REG, 'setTier', [lp.address, TIER_INSTITUTIONAL, 100_000_000n]);
  // Wired during setup; closing it is what lets anyone trade, and makes changes wait.
  // The oracle too: it refuses to price until its governor can no longer swap feeds instantly.
  for (const c of [oracle, registry, verifier, onramp, offramp]) {
    await send(govW, c, art('DelayedGovernance').abi, 'completeSetup', []);
  }
  const [price] = await pub.readContract({ address: oracle, abi: ORA, functionName: 'brlCentsPerUnit' }) as [bigint, bigint];
  ok(`ramp deployed; BRL/ETH ${brl(price)}`);

  // ---------------------------------------------------------------- 3. BRL in
  step('3. BRL in by PIX, delivered SHIELDED to the passkey wallet');
  const before = new IndexedPoolState(scope);
  before.apply(await fetchPoolLogs({ url: RPC, pool: ppPool, fromBlock: scan.fromBlock }));
  const myIndex = before.depositsBy([onramp]).length;

  await send(lpW, onramp, ESC, 'postOffer',
    [NATIVE, parseEther('10'), price, pix(LP_PIX), parseEther('0.05'), parseEther('5'), verifier, railMask(Rail.PIX)], parseEther('10'));
  const { offerId } = eventArgs((await pub.getContractEvents({ address: onramp, abi: ESC, eventName: 'OfferPosted', fromBlock: 'latest' })).at(-1), 'OfferPosted', { offerId: 'bytes32' });

  const book: Offer[] = [{
    offerId, lp: lp.address, asset: NATIVE, decimals: 18, rails: [Rail.PIX],
    availableWei: parseEther('10'), priceBrlCentsPerEth: price,
    minOrderWei: parseEther('0.05'), maxOrderWei: parseEther('5'),
    verifier, tier: 'INSTITUTIONAL', settledCents: 0n, disputesLost: 0,
  }];
  const want = parseEther('1');
  const match = matchOrder(book, { asset: NATIVE, weiWanted: want, rails: [Rail.PIX] });
  if (match.unfilledWei !== 0n) return bad('the book could not fill the request');

  // The precommitment comes from the PASSKEY wallet, so the shielded balance is hers.
  const { nullifier, secret } = commitmentSecrets(wallet0.spendingSecret, myIndex, 0);
  const lockRc = await send(takerW, onramp, ESC, 'lockOrder',
    [offerId, want, 1 /* SHIELDED */, taker.address, precommitmentOf(nullifier, secret)]);
  const { orderId } = eventArgs((await pub.getContractEvents({ address: onramp, abi: ESC, eventName: 'OrderLocked', blockHash: lockRc.blockHash }))[0], 'OrderLocked', { orderId: 'bytes32' });
  const order = await pub.readContract({ address: onramp, abi: ESC, functionName: 'orders', args: [orderId] }) as unknown[];
  const owedCents = order[3] as bigint;
  info('taker pays', brl(owedCents));

  // The taker's bank shows the Pix sent; the witnesses observe that session and extract the receipt's fields.
  const proofBytes = await pixReceiptProof({
    orderId, bankTxId: keccak256(toBytes(`E${Date.now()}FULLRAIL`)), payeeKeyHash: pix(LP_PIX),
    payerRef: keccak256(toBytes('cpf:***')), amountBrlCents: owedCents,
    paidAt: BigInt((await pub.getBlock()).timestamp), witnessKeys: witnesses.keys, owner: taker.address,
  });
  await send(takerW, onramp, ESC, 'releaseWithProof', [orderId, proofBytes]);
  ok('PIX proven by zkTLS, escrow released into the pool');

  // ---------------------------------------------------------------- 4. it is HERS
  step('4. Is the shielded balance actually the passkey wallet\'s?');
  const state = new IndexedPoolState(scope);
  state.apply(await fetchPoolLogs({ url: RPC, pool: ppPool, fromBlock: scan.fromBlock }));
  const mine = state.depositsBy([onramp]);
  const d = mine[mine.length - 1];
  const onChainRoot = await pub.readContract({ address: ppPool as Address, abi: POOL_ABI, functionName: 'currentRoot' }) as bigint;
  if (state.root() !== onChainRoot) return bad('our rebuilt root disagrees with the contract');
  ok('our rebuilt root matches the deployed pool exactly');

  // The SDK's Secret/Hash are compile-time brands on bigint; our field elements are those bigints.
  const recomputed = getCommitment(BigInt(d.value), BigInt(d.label), nullifier as Secret, secret as Secret);
  if (recomputed.hash !== BigInt(d.commitment)) {
    return bad('the on-chain commitment is not the one her secrets produce');
  }
  ok('the commitment recomputes from HER spending key - the balance is hers, not the escrow\'s');
  info('shielded value', `${formatEther(BigInt(d.value))} ETH`);

  // ---------------------------------------------------------------- 5. the audit
  step('5. Prove it to an auditor, without handing over spending power');
  const ts = Number((await pub.getBlock({ blockNumber: lockRc.blockNumber })).timestamp);
  const epochId = new Date(ts * 1000).toISOString().slice(0, 7);
  const amountBRLCents = (BigInt(d.value) * price) / 10n ** 18n;
  const log = new NoteLog(POOL_ID, epochViewingKey(wallet0.viewingRoot, epochId, 0));
  log.append({
    kind: 'deposit', amountBRLCents, ts, ref: orderId,
    pool: {
      value: String(d.value), valueBRLCents: String(amountBRLCents), label: String(d.label),
      precommitment: String(precommitmentOf(nullifier, secret)), commitment: String(d.commitment),
      nullifierHash: String(nullifierHashOf(nullifier)), lineageIndex: 0,
      brlPerAssetUnit: String(price),
    },
  });
  const now = Math.floor(Date.now() / 1000);
  const bundle = issueDisclosure(wallet0, {
    poolId: POOL_ID, auditor: 'Receita Federal do Brasil', auditorKey: `0x${'aa'.repeat(32)}`,
    purpose: `fiscal ${epochId}`, scope: { kind: 'epochs', epochs: [{ epochId, rot: 0 }] },
    registrar: onramp, accounts: [onramp], poolScope: String(scope),
    period: { fromTs: ts - 86_400, toTs: ts + 86_400 },
    validFrom: now - 60, validUntil: now + 3600,
    logs: new Map([[logKey(epochId, 0), log]]),
  });
  const localReg = new LocalGrantRegistry();
  localReg.register(bundle);
  // Records come from the vault in production; here the log we just wrote IS the vault's
  // content, and passing the pool makes completeness checkable against chain state rather
  // than against what the wallet chose to log.
  const proven = await verifyCommitmentProofs({
    [String(d.commitment)]: await proveCommitment({ value: BigInt(d.value), label: BigInt(d.label), nullifier, secret }),
  });
  await releaseProofWorkers(); // or snarkjs's verifier threads keep this script alive
  const report = auditDisclosure(bundle, [...log.all], {
    now,
    status: localReg.statusOf(bundle.terms.registrar, grantId(bundle.terms))!,
    pool: state,
    proven,
  });
  if (!report.spendStateProven) return bad('the auditor could not prove the position unspent');
  if (report.closingBalanceBRLCents !== amountBRLCents) {
    return bad(`report says ${brl(report.closingBalanceBRLCents)}, deposit was ${brl(amountBRLCents)}`);
  }
  ok(`auditor reconstructed ${brl(report.closingBalanceBRLCents)} from the ramp deposit`);
  const asText = JSON.stringify(bundle);
  for (const leak of [String(nullifier), String(secret), Buffer.from(wallet0.spendingSecret).toString('hex')]) {
    if (asText.includes(leak)) return bad('the disclosure leaked spending material');
  }
  ok('and the bundle contains no nullifier, no secret, no spending key');

  // ---------------------------------------------------------------- 6. exit privately
  step('6. Leave the pool privately, with a real proof');
  const aspTree = new LeanIMT<bigint>((a, b) => poseidon2([a, b]));
  aspTree.insert(BigInt(d.label));
  const aspProof = aspTree.generateProof(0);
  // The ASP root must come from the pool's POSTMAN role, which is the account that
  // deployed the protocol - not the ramp's own governor. Two different governances meet
  // here, and conflating them is the kind of thing only a joined-up run catches.
  await send(funder, ppEntrypoint as Address, ENTRYPOINT_ABI, 'updateRoot',
    [aspTree.root, 'bafybeigdyrzt5sfp7udm7hu76uh7y26nf3efuylqabf3oclgtqy55fbzdi']);

  const seller = privateKeyToAccount(generatePrivateKey());
  const sellerW = createWalletClient({ account: seller, chain, transport: http(RPC) });
  const stateProof = state.merkleProof(BigInt(d.commitment));
  const next = commitmentSecrets(wallet0.spendingSecret, myIndex, 1);
  const exitValue = parseEther('0.5');
  const withdrawal = { processooor: seller.address, data: '0x' as Hex };
  const context = calculateContext(withdrawal, scope as Hash);
  const pad = (s: bigint[]) => [...s, ...Array(32 - s.length).fill(0n)];
  const t0 = Date.now();
  const { proof, publicSignals } = await new PrivacyPoolSDK(new Circuits({ browser: false })).proveWithdrawal(recomputed, {
    // calculateContext returns the field element as 0x-hex text, typed `string`; the circuit
    // input is that number (snarkjs BigInt()s every signal). Merkle indices are numbers the SDK
    // BigInt()s itself; the depths are circuit signals, declared bigint.
    context: BigInt(context), withdrawalAmount: exitValue,
    stateMerkleProof: { root: stateProof.root, leaf: recomputed.hash, index: stateProof.index, siblings: pad(stateProof.siblings) },
    aspMerkleProof: { root: aspTree.root, leaf: BigInt(d.label), index: aspProof.index, siblings: pad(aspProof.siblings) },
    stateRoot: stateProof.root as Hash, stateTreeDepth: BigInt(stateProof.depth),
    aspRoot: aspTree.root as Hash, aspTreeDepth: BigInt(aspTree.depth),
    newSecret: next.secret as Secret, newNullifier: next.nullifier as Secret,
  });
  ok(`groth16 proof in ${((Date.now() - t0) / 1000).toFixed(1)}s`);

  await fund(seller.address, parseEther('0.3')); // gas only; the value comes from the pool
  await send(sellerW, ppPool as Address, POOL_ABI, 'withdraw', [withdrawal, {
    pA: [BigInt(proof.pi_a[0]), BigInt(proof.pi_a[1])],
    pB: [[BigInt(proof.pi_b[0][1]), BigInt(proof.pi_b[0][0])], [BigInt(proof.pi_b[1][1]), BigInt(proof.pi_b[1][0])]],
    pC: [BigInt(proof.pi_c[0]), BigInt(proof.pi_c[1])],
    pubSignals: publicSignals.map((x: string) => BigInt(x)) as unknown as readonly bigint[],
  }]);
  ok(`${formatEther(exitValue)} ETH left the pool to a fresh address`);
  info('seller address', `${seller.address.slice(0, 14)}... (no deposit history)`);

  // ---------------------------------------------------------------- 7. BRL out
  step('7. Sell that shielded money for BRL - a REAL pool exit, not a stand-in');
  const wantCents = (exitValue * price) / 10n ** 18n;
  const openRc = await send(sellerW, offramp, OFF, 'openSale',
    [NATIVE, exitValue, wantCents, pix(SELLER_PIX), verifier, railMask(Rail.PIX), seller.address], exitValue);
  const { saleId } = eventArgs((await pub.getContractEvents({ address: offramp, abi: OFF, eventName: 'SaleOpened', blockHash: openRc.blockHash }))[0], 'SaleOpened', { saleId: 'bytes32' });
  await send(lpW, offramp, OFF, 'claimSale', [saleId]);

  // The LP pays the seller and proves its own session with its bank, bound to the sale id.
  const payoutProof = await pixReceiptProof({
    orderId: saleId, bankTxId: keccak256(toBytes(`E${Date.now()}OFF`)), payeeKeyHash: pix(SELLER_PIX),
    payerRef: keccak256(toBytes('lp-bank')), amountBrlCents: wantCents,
    paidAt: BigInt((await pub.getBlock()).timestamp), witnessKeys: witnesses.keys, owner: lp.address,
  });
  const lpBefore = await pub.getBalance({ address: lp.address });
  const settleRc = await send(lpW, offramp, OFF, 'settleWithProof', [saleId, payoutProof]);
  const lpAfter = await pub.getBalance({ address: lp.address });
  const gas = settleRc.gasUsed * settleRc.effectiveGasPrice;
  if (lpAfter + gas - lpBefore !== exitValue) return bad('the LP did not receive the escrowed ETH');
  ok(`settled on the LP's proven payout: seller received ${brl(wantCents)} by PIX`);

  step('8. End to end');
  info('BRL in', brl(owedCents));
  info('BRL out', brl(wantCents));
  info('still shielded', `${formatEther(BigInt(d.value) - exitValue)} ETH`);
  ok('passkey -> PIX (zkTLS) -> shielded -> audited -> private exit -> PIX (zkTLS), on one chain');

  console.log('\n  \x1b[1mPhase 1 and Phase 2 are one rail, with no stand-ins between them.\x1b[0m\n');
}

// Exit explicitly. The withdrawal prover (step 6) leaves worker threads behind that keep Node
// alive after every check has passed, so an unattended run hung until its timeout and reported
// a failure it did not have. `process.exitCode` still carries any FAIL.
main()
  .catch((e) => { console.error('\nfailed:', e.shortMessage ?? e.message ?? e); process.exitCode = 1; })
  .finally(() => process.exit(process.exitCode ?? 0));
