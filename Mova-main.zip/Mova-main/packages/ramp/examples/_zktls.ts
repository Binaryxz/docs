/**
 * Bank endpoints, a zkTLS verifier and proofs, for the examples that settle PIX and boletos.
 *
 * PIX, boleto and TED settle ONLY on a zkTLS proof of the bank session: the escrows revert `BankRailNeedsZkTls` for a
 * bank-rail offer or sale whose verifier's `provesBankSession()` is false. So an example
 * that moves BRL by PIX or boleto deploys a ReclaimZkTlsVerifier, allowlists the bank endpoints it proves sessions with,
 * and settles on Reclaim-format proofs built by ../src/reclaim.ts - with local witness keys standing in for Reclaim's
 * attestor network (`signAsWitness`), which is the one stand-in on that path: the claim structure, the encoding and every
 * on-chain check are the production ones.
 *
 * ## The two endpoints, and who proves with them
 *
 *  - **A Pix receipt** (`PIX_RECEIPT`): the comprovante a bank shows its account holder for a Pix they SENT. The taker
 *    proves an on-ramp payment with it, from their own bank; the LP proves an off-ramp payout to a seller with it, from
 *    the LP's. Allowlisted for PIX alone, the verifier's default for a new endpoint.
 *  - **A boleto payment receipt** (`BOLETO_RECEIPT`): the comprovante for a boleto paid - the taker's for the boleto an
 *    LP issued for an order, the LP's for a seller's bill. Widened to BOLETO, and narrowed from PIX, with
 *    `setEndpointRails` during setup (`ENDPOINT_RAILS`): a boleto receipt template must not vouch for a Pix.
 *
 * The templates are illustrative, as zktls-onramp.ts's is: a real one comes from Reclaim for a real bank, and must capture
 * every field the verifier reads from the bank-written response. What they fix here is what the chain pins - each
 * template's `providerHash` and URL prefix, and the rails it may attest.
 *
 * ## For packages/ramp/src/reclaim.ts
 *
 * reclaim.ts has the encoding, `buildProof` and `boletoPaymentContext`, but no endpoint templates and no one-call
 * "payment to encoded proof" for either rail; these are written here, local to the examples, rather than edited into the
 * library. Binding a proof to an off-ramp SALE needs nothing new: `bindingContext` takes any bytes32, and the sale id is
 * what `OffRampEscrow.settleWithProof` passes to the verifier as the order id.
 */
import type { Address, Hex } from 'viem';
import { generatePrivateKey, privateKeyToAccount } from 'viem/accounts';
import { Rail, railMask } from '../src/attestor.js';
import {
  boletoPaymentContext, buildProof, encodeProof, hashProviderParams, type HttpProviderParams, type PaymentContext,
} from '../src/reclaim.js';

export interface BankEndpoint {
  /** For output: what the endpoint serves. */
  what: string;
  /** Must be `https://` + lowercase host + `/` + path (ReclaimZkTlsVerifier `_validatePrefix`); the template's url starts with it. */
  urlPrefix: string;
  params: HttpProviderParams;
  providerHash: Hex;
  /** The rails the endpoint may attest, as a mask over Rail. */
  rails: number;
}

/** The verifier's default for an endpoint it allows: PIX alone. */
export const PIX_ONLY = railMask(Rail.PIX);

/** A receipt template capturing every field the verifier reads, with `rail` fixed to the one receipt kind it serves. */
function receiptTemplate(urlPrefix: string, path: string, rail: Rail): HttpProviderParams {
  return {
    url: `${urlPrefix}${path}`,
    method: 'GET',
    body: '',
    paramValues: { receiptId: 'COMPROVANTE-DEMO-0001' },
    responseMatches: [
      { type: 'regex', value: '"amountBrlCents":"(?<amountBrlCents>[0-9]+)"' },
      { type: 'regex', value: '"authenticationId":"(?<bankTxId>0x[0-9a-f]{64})"' },
      { type: 'regex', value: '"settledAt":"(?<paidAt>[0-9]+)"' },
      { type: 'regex', value: '"payeeKeyHash":"(?<payeeKeyHash>0x[0-9a-f]{64})"' },
      { type: 'regex', value: '"payerRef":"(?<payerRef>0x[0-9a-f]{64})"' },
      // A literal, not a class: a receipt of the other kind cannot match it.
      { type: 'regex', value: `"rail":"(?<rail>${rail})"` },
    ],
    responseRedactions: [{ jsonPath: '$.comprovante', regex: '', xPath: '' }],
  };
}

function endpoint(what: string, urlPrefix: string, path: string, rail: Rail): BankEndpoint {
  const params = receiptTemplate(urlPrefix, path, rail);
  return { what, urlPrefix, params, providerHash: hashProviderParams(params), rails: railMask(rail) };
}

export const PIX_RECEIPT = endpoint('a Pix receipt', 'https://api.bancoexemplo.com.br/pix/', 'comprovantes/{{receiptId}}', Rail.PIX);
export const BOLETO_RECEIPT = endpoint('a boleto payment receipt', 'https://api.bancoexemplo.com.br/boletos/', 'comprovantes/{{receiptId}}', Rail.BOLETO);

/** Local keys standing in for Reclaim's witnesses. */
export function localWitnesses(n = 2): { keys: Hex[]; addresses: Address[] } {
  const keys = Array.from({ length: n }, () => generatePrivateKey());
  return { keys, addresses: keys.map((k) => privateKeyToAccount(k).address) };
}

/** ReclaimZkTlsVerifier's constructor arguments: every witness required, and the endpoints allowlisted (both by default). */
export function zkTlsVerifierArgs(
  governor: Address, governanceDelay: bigint, witnesses: readonly Address[], endpoints: readonly BankEndpoint[] = [PIX_RECEIPT, BOLETO_RECEIPT],
): unknown[] {
  return [governor, governanceDelay, [...witnesses], BigInt(witnesses.length), endpoints.map((e) => e.providerHash), endpoints.map((e) => e.urlPrefix)];
}

/**
 * The `setEndpointRails(providerHash, mask)` calls an allowlist needs during setup: one for each endpoint whose rails are
 * not the verifier's PIX-only default. Widening a rail after setup waits out the governance delay.
 */
export function endpointRails(endpoints: readonly BankEndpoint[] = [PIX_RECEIPT, BOLETO_RECEIPT]): [Hex, number][] {
  return endpoints.filter((e) => e.rails !== PIX_ONLY).map((e) => [e.providerHash, e.rails]);
}

interface Proving {
  witnessKeys: readonly Hex[];
  /** Who requested the session: the taker on the on-ramp, the LP on the off-ramp. The verifier does not read it. */
  owner: Address;
}

/** Any payment, through any endpoint - for the refusals, where the payment or the endpoint is deliberately the wrong one. */
export async function receiptProof(payment: PaymentContext, via: BankEndpoint, p: Proving): Promise<Hex> {
  return encodeProof(await buildProof({ params: via.params, payment, witnessKeys: [...p.witnessKeys], owner: p.owner }));
}

/**
 * A Pix receipt for `orderId` (an order, or a sale): paid to `payeeKeyHash`, the salted key commitment the offer or sale
 * names, as a witness would extract it from the bank's response.
 */
export function pixReceiptProof(
  a: Omit<PaymentContext, 'rail'> & Proving,
): Promise<Hex> {
  const { witnessKeys, owner, ...payment } = a;
  return receiptProof({ ...payment, rail: Rail.PIX }, PIX_RECEIPT, { witnessKeys, owner });
}

/**
 * A boleto payment receipt for `orderId`, from the paid line and the salt: `boletoPaymentContext` derives the commitment
 * the escrow compares with the boleto issued for the order (or the bill a sale names), and refuses a line that is not a
 * boleto for exactly this amount.
 */
export function boletoReceiptProof(
  a: { orderId: Hex; bankTxId: Hex; line: string; salt: Hex; payerRef: Hex; amountBrlCents: bigint; paidAt: bigint } & Proving,
): Promise<Hex> {
  const { witnessKeys, owner, ...paid } = a;
  return receiptProof(boletoPaymentContext(paid), BOLETO_RECEIPT, { witnessKeys, owner });
}
