/**
 * Sync the on-chain witness set for ReclaimZkTlsVerifier (task 2.2, operations).
 *
 * Reclaim rotates its attestors by epoch. When it does, proofs from the new epoch are signed
 * by addresses the verifier has never heard of, and every settlement using that verifier
 * starts reverting with `UnknownWitness` - a failure that looks like a broken proof and is
 * actually an expired configuration. This is the routine that prevents it.
 *
 * It is deliberately a diff-and-apply rather than a replace: it adds what is missing, and
 * only removes what you explicitly ask it to. Blindly mirroring an upstream list would let a
 * bad fetch silently empty the witness set. Removing a witness never lowers the threshold -
 * that would be an undelayed way to a quorum of one - so pruning below it would stop every
 * settlement; this refuses to.
 *
 * ADDING A WITNESS IS DELAYED. Once the verifier's setup is complete, adding one raises risk,
 * so it goes through the governance queue: the first run schedules it, a run after
 * GOVERNANCE_DELAY executes it. Plan rotations at least that far ahead of Reclaim's epoch
 * change. Removing a witness is immediate.
 *
 *   WITNESSES=0xa,0xb,0xc [PRUNE=true] [THRESHOLD=2] \
 *     npx tsx packages/ramp/examples/reclaim-witnesses.ts <verifier> [rpc]
 */
import {
  createPublicClient, createWalletClient, http, defineChain, encodeFunctionData, keccak256,
  type Abi, type Address, type Hex,
} from 'viem';
import { privateKeyToAccount } from 'viem/accounts';
import { readFileSync } from 'node:fs';

const [verifierArg, rpcArg] = process.argv.slice(2);
if (!verifierArg) {
  console.error('usage: reclaim-witnesses.ts <verifier> [rpc]   (env: WITNESSES, PRUNE, THRESHOLD)');
  process.exit(2);
}
const RPC = rpcArg ?? process.env.RPC_URL ?? 'http://127.0.0.1:8545';
const CHAIN_ID = Number(process.env.CHAIN_ID ?? 1);
const verifier = verifierArg as Address;

const want = (process.env.WITNESSES ?? '')
  .split(',').map((s) => s.trim()).filter(Boolean) as Address[];
if (want.length === 0) {
  console.error('WITNESSES is required: the addresses Reclaim currently signs with');
  process.exit(2);
}

const chain = defineChain({
  id: CHAIN_ID, name: 'chain', nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
  rpcUrls: { default: { http: [RPC] } },
});
const pub = createPublicClient({ chain, transport: http(RPC) });

const art = JSON.parse(readFileSync(
  new URL('../../../forge-out/ReclaimZkTlsVerifier.sol/ReclaimZkTlsVerifier.json', import.meta.url),
  'utf8',
)) as { abi: unknown };

const ok = (s: string) => console.log(`  \x1b[32mOK\x1b[0m    ${s}`);
const info = (k: string, v: unknown) => console.log(`        ${k.padEnd(20)} ${v}`);
const warn = (s: string) => console.log(`  \x1b[33m!\x1b[0m     ${s}`);

/** Bounded, self-narrowing log scan. Public RPCs cap ranges at values they do not publish. */
async function scanWitnessEvents(fromBlock: bigint) {
  const head = await pub.getBlockNumber();
  const out: { args: { witness: Address; active: boolean } }[] = [];
  let from = fromBlock;
  let span = 5_000n;
  while (from <= head) {
    const to = from + span - 1n > head ? head : from + span - 1n;
    try {
      const batch = await pub.getContractEvents({
        address: verifier, abi: art.abi as never, eventName: 'WitnessSet',
        fromBlock: from, toBlock: to,
      }) as unknown as { args: { witness: Address; active: boolean } }[];
      out.push(...batch);
      from = to + 1n;
    } catch (e) {
      if (span <= 1n) throw e;
      span /= 2n;
    }
  }
  return out;
}

async function main() {
  const key = process.env.GOVERNOR_KEY as Hex | undefined;
  const governor = await pub.readContract({
    address: verifier, abi: art.abi as never, functionName: 'governor',
  }) as Address;
  const threshold = await pub.readContract({
    address: verifier, abi: art.abi as never, functionName: 'threshold',
  }) as bigint;
  const count = await pub.readContract({
    address: verifier, abi: art.abi as never, functionName: 'witnessCount',
  }) as bigint;

  console.log(`\n\x1b[1mReclaim witness set — ${verifier}\x1b[0m`);
  info('governor', governor);
  info('on-chain witnesses', `${count} (threshold ${threshold})`);

  const isKnown = async (a: Address) => await pub.readContract({
    address: verifier, abi: art.abi as never, functionName: 'isWitness', args: [a],
  }) as boolean;

  const missing: Address[] = [];
  for (const w of want) {
    if (!(await isKnown(w))) missing.push(w);
  }

  if (missing.length === 0) {
    ok('every requested witness is already registered; nothing to do');
  } else {
    info('to add', missing.join(', '));
  }

  if (!key) {
    warn('GOVERNOR_KEY not set — this was a dry run, nothing was written');
    console.log('\n  Set GOVERNOR_KEY to apply. Review the list above first: registering a');
    console.log('  witness is trusting it to attest bank sessions honestly.\n');
    return;
  }

  const account = privateKeyToAccount(key);
  if (account.address.toLowerCase() !== governor.toLowerCase()) {
    console.error(`\nGOVERNOR_KEY is ${account.address}, but the governor is ${governor}`);
    process.exit(1);
  }
  const wallet = createWalletClient({ account, chain, transport: http(RPC) });

  const write = async (functionName: string, args: unknown[]) => {
    const hash = await wallet.writeContract({
      address: verifier, abi: art.abi as never, functionName: functionName as never, args: args as never,
    });
    await pub.waitForTransactionReceipt({ hash });
  };
  const read = async <T>(functionName: string, args: unknown[] = []) => await pub.readContract({
    address: verifier, abi: art.abi as never, functionName: functionName as never, args: args as never,
  }) as T;

  const setupComplete = await read<boolean>('setupComplete');
  const delay = await read<bigint>('GOVERNANCE_DELAY');
  const window = await read<bigint>('EXECUTION_WINDOW');
  const now = (await pub.getBlock()).timestamp;

  for (const w of missing) {
    if (!setupComplete) {
      await write('setWitness', [w, true]);
      ok(`registered ${w} (verifier still in setup: changes are immediate)`);
      continue;
    }
    // The queue is keyed by the exact calldata, so schedule and execute must send the same bytes.
    const call = encodeFunctionData({ abi: art.abi as Abi, functionName: 'setWitness', args: [w, true] });
    const readyAt = await read<bigint>('readyAt', [keccak256(call)]);
    if (readyAt === 0n) {
      await write('schedule', [call]);
      ok(`scheduled ${w}; executable from ${new Date(Number(now + delay) * 1000).toISOString()}`);
    } else if (now < readyAt) {
      info('waiting', `${w} becomes executable at ${new Date(Number(readyAt) * 1000).toISOString()}`);
    } else if (now > readyAt + window) {
      await write('cancel', [call]);
      await write('schedule', [call]);
      warn(`${w}: the earlier schedule expired unexecuted; scheduled again`);
    } else {
      await write('execute', [call]);
      ok(`registered ${w}`);
    }
  }

  if (process.env.PRUNE === 'true') {
    // Only ever prunes what was NOT requested, and never below the threshold: the contract no
    // longer lowers it on removal, so a set smaller than the threshold settles nothing.
    warn('PRUNE=true: removing witnesses not in WITNESSES');
    // NOT `fromBlock: 'earliest'`. Against any real chain that asks the node for the whole
    // history and comes back as an opaque transport error - this project has now hit that
    // in four separate places. Scan a bounded window, halving on refusal, from the block
    // the verifier was deployed in.
    const from = process.env.VERIFIER_DEPLOY_BLOCK;
    if (!from) {
      console.error(
        '\nPRUNE needs VERIFIER_DEPLOY_BLOCK: pruning reads the WitnessSet history, and\n'
        + 'scanning from block 0 asks the node for the entire chain.',
      );
      process.exit(2);
    }
    const events = await scanWitnessEvents(BigInt(from));
    const everSeen = new Set(events.map((e) => e.args.witness.toLowerCase()));
    const wanted = new Set(want.map((w) => w.toLowerCase()));
    for (const addr of everSeen) {
      if (wanted.has(addr)) continue;
      if (!(await isKnown(addr as Address))) continue;
      const remaining = await read<bigint>('witnessCount');
      if (remaining - 1n < threshold) {
        warn(`not removing ${addr}: ${remaining - 1n} witnesses could not meet threshold ${threshold}`);
        continue;
      }
      await write('setWitness', [addr as Address, false]);
      ok(`removed ${addr}`);
    }
  }

  const after = await pub.readContract({
    address: verifier, abi: art.abi as never, functionName: 'witnessCount',
  }) as bigint;
  const thresholdAfter = await pub.readContract({
    address: verifier, abi: art.abi as never, functionName: 'threshold',
  }) as bigint;
  info('now', `${after} witnesses, threshold ${thresholdAfter}`);
  if (after < thresholdAfter) {
    warn('fewer witnesses than the threshold: no zkTLS proof can settle until more are registered');
  }
  console.log();
}

main().catch((e) => { console.error('\nfailed:', e.shortMessage ?? e.message ?? e); process.exit(1); });
