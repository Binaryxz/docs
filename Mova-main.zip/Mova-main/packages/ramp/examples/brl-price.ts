/**
 * Get the BRL price, properly, from every source we support - and say what each yields.
 *
 * This exists because "can we price BRL?" kept being answered from memory, and twice the
 * memory was wrong: first that Pyth had no feed (it has one), then that the adapter's
 * arithmetic was right (it was inverted). So this asks the sources directly and prints what
 * comes back, including the failures.
 *
 *   npx tsx packages/ramp/examples/brl-price.ts [rpc]
 */
import { createPublicClient, http, defineChain, type Address } from 'viem';

const RPC = process.argv[2] ?? process.env.RPC_URL ?? 'http://127.0.0.1:8545';
const chain = defineChain({
  id: Number(process.env.CHAIN_ID ?? 1), name: 'mainnet',
  nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
  rpcUrls: { default: { http: [RPC] } },
});
const pub = createPublicClient({ chain, transport: http(RPC) });

const step = (s: string) => console.log(`\n\x1b[1m${s}\x1b[0m`);
const ok = (s: string) => console.log(`  \x1b[32mOK\x1b[0m    ${s}`);
const no = (s: string) => console.log(`  \x1b[33m--\x1b[0m    ${s}`);
const info = (k: string, v: unknown) => console.log(`        ${k.padEnd(24)} ${v}`);

const AGG_ABI = [
  { name: 'latestRoundData', type: 'function', stateMutability: 'view', inputs: [],
    outputs: [{ type: 'uint80' }, { type: 'int256' }, { type: 'uint256' }, { type: 'uint256' }, { type: 'uint80' }] },
  { name: 'decimals', type: 'function', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint8' }] },
  { name: 'description', type: 'function', stateMutability: 'view', inputs: [], outputs: [{ type: 'string' }] },
] as const;

const CHAINLINK_ETH_USD = '0x5f4eC3Df9cbd43714FE2740f5E3616155c5b8419' as Address;
const CHAINLINK_BRL_USD = '0x0eBDc65E7e9132Cb41ac5cbD0101B799D7aDb475' as Address;
const PYTH = '0x4305FB66699C3B2702D4d05CF36551390A4c69C6' as Address;
const PYTH_ETH_USD = '0xff61491a931112ddf1bd8147cd1b641375f79f5825126d665480874634fd0ace';
const PYTH_USD_BRL = '0xd2db4dbf1aea74e0f666b0e8f73b9580d407f5e5cf931940b06dc633d7a95906';
const HERMES = process.env.HERMES_URL ?? 'https://hermes.pyth.network';

const age = (t: bigint | number) => {
  const s = Math.floor(Date.now() / 1000) - Number(t);
  const d = Math.floor(s / 86_400);
  return d > 1 ? `${d} days old` : `${Math.floor(s / 3600)}h old`;
};

async function main() {
  console.log('\n\x1b[1mWhat is 1 ETH worth in BRL, and who will tell us?\x1b[0m');

  // ---------------------------------------------------------------- Chainlink
  step('1. Chainlink, on Ethereum mainnet');
  let ethUsd = 0;
  try {
    const [, answer, , updatedAt] = await pub.readContract({
      address: CHAINLINK_ETH_USD, abi: AGG_ABI, functionName: 'latestRoundData',
    }) as [bigint, bigint, bigint, bigint, bigint];
    ethUsd = Number(answer) / 1e8;
    ok(`ETH/USD readable: $${ethUsd.toLocaleString('en-US')} (${age(updatedAt)})`);
  } catch (e) {
    no(`ETH/USD unreadable: ${(e as Error).message.split('\n')[0]}`);
  }

  // The BRL leg is access-controlled: contracts get "No access", so this read succeeds only
  // because viem issues a plain eth_call rather than calling from a contract.
  try {
    const [, answer, , updatedAt] = await pub.readContract({
      address: CHAINLINK_BRL_USD, abi: AGG_ABI, functionName: 'latestRoundData',
    }) as [bigint, bigint, bigint, bigint, bigint];
    const brlUsd = Number(answer) / 1e8;
    info('BRL/USD', `$${brlUsd.toFixed(6)} per BRL  =>  1 USD = ${(1 / brlUsd).toFixed(4)} BRL`);
    info('last updated', `${new Date(Number(updatedAt) * 1000).toISOString().slice(0, 10)} (${age(updatedAt)})`);
    if (ethUsd > 0) {
      info('implied', `1 ETH = R$ ${(ethUsd / brlUsd).toLocaleString('pt-BR', { maximumFractionDigits: 2 })}`);
    }
    no('but that price is years old, so it is not a price - it is a fossil');
    no('and a CONTRACT cannot read this feed at all: it answers "No access"');
  } catch (e) {
    no(`BRL/USD unreadable even off-chain: ${(e as Error).message.split('\n')[0]}`);
  }

  // ---------------------------------------------------------------- Pyth on-chain
  step('2. Pyth, on Ethereum mainnet');
  for (const [name, id] of [['ETH/USD', PYTH_ETH_USD], ['USD/BRL', PYTH_USD_BRL]] as const) {
    try {
      const p = await pub.readContract({
        address: PYTH,
        abi: [{ name: 'getPriceUnsafe', type: 'function', stateMutability: 'view',
          inputs: [{ type: 'bytes32' }],
          outputs: [{ components: [{ name: 'price', type: 'int64' }, { name: 'conf', type: 'uint64' },
            { name: 'expo', type: 'int32' }, { name: 'publishTime', type: 'uint256' }], type: 'tuple' }] }] as const,
        functionName: 'getPriceUnsafe', args: [id as `0x${string}`],
      }) as { price: bigint; conf: bigint; expo: number; publishTime: bigint };
      const v = Number(p.price) * 10 ** p.expo;
      ok(`${name}: ${v.toLocaleString('en-US')} (${age(p.publishTime)})`);
    } catch {
      no(`${name}: PriceFeedNotFound - nobody has ever posted this feed to mainnet`);
    }
  }
  info('why', 'Pyth is pull-based: a feed exists on a chain only after');
  info('', 'someone submits a signed update there and pays the fee');

  // ---------------------------------------------------------------- Pyth off-chain
  step('3. Pyth, off-chain (Hermes) - does the feed exist at all?');
  try {
    const r = await fetch(`${HERMES}/v2/price_feeds?query=BRL&asset_type=fx`);
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    const feeds = await r.json() as { id: string; attributes: Record<string, string> }[];
    for (const f of feeds) {
      ok(`${f.attributes.display_symbol} exists: ${f.attributes.description}`);
      info('feed id', `0x${f.id.slice(0, 24)}...`);
      info('quote currency', `${f.attributes.quote_currency}  (so the price is BRL per USD)`);
    }
  } catch (e) {
    no(`feed metadata unavailable: ${(e as Error).message}`);
  }

  try {
    const r = await fetch(`${HERMES}/v2/updates/price/latest?ids%5B%5D=${PYTH_USD_BRL.slice(2)}`);
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    const d = await r.json() as { parsed: { price: { price: string; expo: number } }[] };
    const p = d.parsed[0].price;
    ok(`live USD/BRL: ${(Number(p.price) * 10 ** p.expo).toFixed(4)} BRL per USD`);
  } catch (e) {
    no(`live price needs a credential: ${(e as Error).message}`);
    info('', 'Hermes\'s hosted gateway now authenticates price reads. Set HERMES_URL to');
    info('', 'your own instance, or use a Pyth API key, to post updates on-chain.');
  }

  // ---------------------------------------------------------------- verdict
  step('4. So what can price BRL on L1 today?');
  console.log(`
  Chainlink   the aggregator exists and is a fossil (Aug 2023), and refuses
              contract callers outright. Reviving it is Chainlink's decision,
              not a signup. Unusable.

  Pyth        the feed is real and live. Two things stand between it and the
              escrow, and both are operational rather than blocked:
                - a Hermes credential (or your own Hermes) to read updates
                - a keeper that posts them to mainnet and keeps them warm

  Signed      SignedPriceOracle: named publishers sign a price, anyone submits
              it, the escrow bands against it. Works today, and is honest about
              whose word you are taking.
`);
  console.log('  \x1b[1mThe blocker is an operator, not a missing price.\x1b[0m\n');
}

main().catch((e) => { console.error('\nfailed:', e.message ?? e); process.exit(1); });
