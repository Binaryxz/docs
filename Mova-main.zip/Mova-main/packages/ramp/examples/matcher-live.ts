/**
 * The matching service against a real deployed escrow (task 2.4, the service half).
 *
 * Deploys a ramp, posts real offers from real LPs, starts the service, and asks it for
 * quotes over HTTP. The point is not that the API responds - it is that the book the
 * service serves was rebuilt from chain events and reconciled against the escrow's own
 * storage, so a restart or a hostile operator changes nothing a taker relies on.
 *
 * The offers name a ReclaimZkTlsVerifier. They take PIX and boletos, and PIX and boleto settle only on a
 * zkTLS proof of the bank session (`BankRailNeedsZkTls` otherwise). Nothing here
 * settles, so the verifier's witnesses are local keys nobody signs with; its endpoints are _zktls.ts's.
 *
 *   npx tsx packages/ramp/examples/matcher-live.ts [rpc]
 */
import {
  createWalletClient, createPublicClient, http, parseEther, defineChain,
  type Hex, type Address,
} from 'viem';
import { privateKeyToAccount, generatePrivateKey } from 'viem/accounts';
import { readFileSync } from 'node:fs';
import { MatcherService, type Quote } from '../src/matcher-service.js';
import { Rail, railMask, pixKeyCommitment, newPixSalt } from '../src/attestor.js';
import { endpointRails, localWitnesses, zkTlsVerifierArgs } from './_zktls.js';

/** A secret salt per PIX key for this run: the on-chain commitment must not be reversible. */
const pixSalts = new Map<string, Hex>();
const pix = (key: string): Hex => {
  if (!pixSalts.has(key)) pixSalts.set(key, newPixSalt());
  return pixKeyCommitment(key, pixSalts.get(key)!);
};

const RPC = process.argv[2] ?? process.env.RPC_URL ?? 'http://127.0.0.1:8545';
const CHAIN_ID = Number(process.env.CHAIN_ID ?? 1);
const chain = defineChain({
  id: CHAIN_ID, name: 'anvil-fork', nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
  rpcUrls: { default: { http: [RPC] } },
});
const pub = createPublicClient({ chain, transport: http(RPC) });

const step = (s: string) => console.log(`\n\x1b[1m${s}\x1b[0m`);
const ok = (s: string) => console.log(`  \x1b[32mOK\x1b[0m    ${s}`);
const bad = (s: string) => { console.log(`  \x1b[31mFAIL\x1b[0m  ${s}`); process.exitCode = 1; };
const info = (k: string, v: unknown) => console.log(`        ${k.padEnd(24)} ${v}`);

const art = (n: string, f?: string) =>
  JSON.parse(readFileSync(new URL(`../../../forge-out/${f ?? `${n}.sol`}/${n}.json`, import.meta.url), 'utf8'));

const FUNDER = privateKeyToAccount('0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80');
const funder = createWalletClient({ account: FUNDER, chain, transport: http(RPC) });
const NATIVE = '0x0000000000000000000000000000000000000000' as Address;
const CHAINLINK_ETH_USD = '0x5f4eC3Df9cbd43714FE2740f5E3616155c5b8419' as Address;

/**
 * Every governed contract starts in SETUP: changes are instant and all user business is
 * refused. The demo wires everything in that window, then closes it. After `completeSetup()`
 * a risk-increasing change (a verifier, an LP's tier, a threshold) must be scheduled and wait
 * out GOVERNANCE_DELAY, which is why nothing is configured after that point.
 */
const GOVERNANCE_DELAY = 48n * 60n * 60n;
/** The deploy script's default dispute timeout. */
const DISPUTE_TIMEOUT = 30n * 24n * 60n * 60n;
/** LPRegistry.Tier: NONE, RETAIL, AFFILIATED, INSTITUTIONAL, SUSPENDED. */
const TIER_INSTITUTIONAL = 3;

async function deploy(n: string, args: unknown[], value = 0n, f?: string): Promise<Address> {
  const a = art(n, f);
  const h = await funder.deployContract({ abi: a.abi, bytecode: a.bytecode.object as Hex, args: args as never, value });
  const r = await pub.waitForTransactionReceipt({ hash: h });
  if (!r.contractAddress) throw new Error(`${n} failed to deploy`);
  return r.contractAddress;
}
async function fund(to: Address, v: bigint) {
  await pub.waitForTransactionReceipt({ hash: await funder.sendTransaction({ to, value: v }) });
}

/** `/health`'s body. MatcherService builds it inline and exports no type for it; `/quote` returns a `Quote`. */
interface Health { ok: boolean; offers: number; atBlock: string; syncError: string | null }

async function main() {
  const gov = privateKeyToAccount(generatePrivateKey());
  const govW = createWalletClient({ account: gov, chain, transport: http(RPC) });
  await fund(gov.address, parseEther('1'));

  step('1. Deploy a ramp with two competing LPs');
  const [, realEthUsd] = await pub.readContract({
    address: CHAINLINK_ETH_USD,
    abi: [{ name: 'latestRoundData', type: 'function', stateMutability: 'view', inputs: [],
      outputs: [{ type: 'uint80' }, { type: 'int256' }, { type: 'uint256' }, { type: 'uint256' }, { type: 'uint80' }] }],
    functionName: 'latestRoundData',
  }) as [bigint, bigint, bigint, bigint, bigint];
  const ethUsd = await deploy('MockFeed', [realEthUsd, 8], 0n, 'RampIntegration.t.sol');
  const brlUsd = await deploy('MockFeed', [20000000n, 8], 0n, 'RampIntegration.t.sol');
  const oracle = await deploy('ChainlinkBrlOracle', [ethUsd, brlUsd, 3600n, gov.address, GOVERNANCE_DELAY]);
  const registry = await deploy('LPRegistry', [gov.address, GOVERNANCE_DELAY]);
  // Where PIX and boleto offers must point: a zkTLS verifier (see the header).
  const verifier = await deploy('ReclaimZkTlsVerifier', zkTlsVerifierArgs(gov.address, GOVERNANCE_DELAY, localWitnesses(2).addresses));
  const escrow = await deploy('FiatEscrow',
    [oracle, registry, FUNDER.address, FUNDER.address, 500n, gov.address, GOVERNANCE_DELAY, DISPUTE_TIMEOUT]);
  const startBlock = await pub.getBlockNumber();

  const ESC = art('FiatEscrow').abi;
  const REG = art('LPRegistry').abi;
  const ORA = art('ChainlinkBrlOracle').abi;
  const send = async (w: typeof govW, a: Address, abi: unknown, fn: string, args: unknown[], v = 0n) => {
    const h = await w.writeContract({ address: a, abi: abi as never, functionName: fn, args: args as never, value: v });
    const r = await pub.waitForTransactionReceipt({ hash: h });
    if (r.status !== 'success') throw new Error(`${fn} reverted`);
    return r;
  };
  await send(govW, registry, REG, 'setEscrow', [escrow, true]);
  await send(govW, escrow, ESC, 'setVerifier', [verifier, true]);
  // The boleto receipt endpoint attests boletos, not the verifier's PIX-only default.
  for (const [providerHash, mask] of endpointRails()) {
    await send(govW, verifier, art('ReclaimZkTlsVerifier').abi, 'setEndpointRails', [providerHash, mask]);
  }

  // Two LPs: one cheaper but PIX-only, one dearer and accepting boletos.
  const cheap = privateKeyToAccount(generatePrivateKey());
  const dear = privateKeyToAccount(generatePrivateKey());
  await fund(cheap.address, parseEther('12'));
  await fund(dear.address, parseEther('12'));
  // INSTITUTIONAL (3), which the indexer reports as such; 2 would be AFFILIATED now.
  await send(govW, registry, REG, 'setTier', [cheap.address, TIER_INSTITUTIONAL, 100_000_000n]);
  await send(govW, registry, REG, 'setTier', [dear.address, TIER_INSTITUTIONAL, 100_000_000n]);
  // The oracle's setup closes with the rest; it refuses to price until then.
  for (const c of [oracle, registry, verifier, escrow]) {
    await send(govW, c, art('DelayedGovernance').abi, 'completeSetup', []);
  }
  const [price] = await pub.readContract({ address: oracle, abi: ORA, functionName: 'brlCentsPerUnit' }) as [bigint, bigint];

  const cheapPrice = price - price / 200n; // 0.5% under
  await send(createWalletClient({ account: cheap, chain, transport: http(RPC) }), escrow, ESC, 'postOffer',
    [NATIVE, parseEther('5'), cheapPrice, pix('cheap@pix.example'), parseEther('0.05'),
     parseEther('2'), verifier, railMask(Rail.PIX)], parseEther('5'));
  await send(createWalletClient({ account: dear, chain, transport: http(RPC) }), escrow, ESC, 'postOffer',
    [NATIVE, parseEther('5'), price, pix('dear@pix.example'), parseEther('0.05'),
     parseEther('2'), verifier, railMask(Rail.PIX, Rail.BOLETO)], parseEther('5'));
  ok('two offers posted on-chain');
  info('cheaper LP (PIX only)', `R$ ${(Number(cheapPrice) / 100).toLocaleString('pt-BR')}`);
  info('dearer LP (PIX+boleto)', `R$ ${(Number(price) / 100).toLocaleString('pt-BR')}`);

  step('2. Start the matcher; it rebuilds the book from chain events');
  const svc = new MatcherService({
    client: pub as never, escrow, registry, fromBlock: startBlock, pollMs: 1_000,
  });
  const port = await svc.listen(0);
  ok(`listening on :${port}, book rebuilt from logs alone`);

  const get = async <T>(path: string) => {
    const r = await fetch(`http://127.0.0.1:${port}${path}`);
    return { status: r.status, body: await r.json() as T };
  };

  const health = await get<Health>('/health');
  if (!health.body.ok || health.body.offers !== 2) return bad(`unhealthy: ${JSON.stringify(health.body)}`);
  ok(`/health reports 2 offers at block ${health.body.atBlock}`);

  step('3. A quote picks the cheaper LP');
  const q1 = await get<Quote>(`/quote?asset=${NATIVE}&amount=${parseEther('1')}&rails=${Rail.PIX}`);
  if (q1.body.fills.length !== 1) return bad('expected a single fill');
  if (q1.body.fills[0].lp.toLowerCase() !== cheap.address.toLowerCase()) {
    return bad('the matcher did not pick the cheaper offer');
  }
  ok(`quoted R$ ${(Number(q1.body.totalBrlCents) / 100).toLocaleString('pt-BR')} from the cheaper LP`);
  info('quote valid until', new Date(q1.body.expiresAt * 1000).toISOString());

  step('4. A boleto-only taker is routed to the LP that accepts boletos');
  const q2 = await get<Quote>(`/quote?asset=${NATIVE}&amount=${parseEther('1')}&rails=${Rail.BOLETO}`);
  if (q2.body.fills[0]?.lp.toLowerCase() !== dear.address.toLowerCase()) {
    return bad('a boleto taker was matched to a PIX-only LP');
  }
  ok('paid more, but to an LP that can actually settle it');

  step('5. A size no single LP can cover splits across both');
  const q3 = await get<Quote>(`/quote?asset=${NATIVE}&amount=${parseEther('3')}&rails=${Rail.PIX}`);
  if (q3.body.fills.length !== 2) return bad(`expected 2 fills, got ${q3.body.fills.length}`);
  ok(`split into ${q3.body.fills.length} legs, ${q3.body.unfilled} wei unfilled`);

  step('6. The book follows the chain, not the operator');
  await send(createWalletClient({ account: cheap, chain, transport: http(RPC) }), escrow, ESC,
    'closeOffer', [q1.body.fills[0].offerId]);
  await svc.refresh();
  const after = await get<Health>('/health');
  if (after.body.offers !== 1) return bad(`expected 1 offer after close, got ${after.body.offers}`);
  ok('the closed offer disappeared from the book without being told');

  const q4 = await get<Quote>(`/quote?asset=${NATIVE}&amount=${parseEther('1')}&rails=${Rail.PIX}`);
  if (q4.body.fills[0].lp.toLowerCase() !== dear.address.toLowerCase()) {
    return bad('still quoting the closed offer');
  }
  ok('quotes now come from the remaining LP');

  step('7. The service cannot move funds');
  const src = readFileSync(new URL('../src/matcher-service.ts', import.meta.url), 'utf8')
    + readFileSync(new URL('../src/indexer.ts', import.meta.url), 'utf8');
  for (const forbidden of ['privateKeyToAccount', 'writeContract', 'sendTransaction', 'signTypedData']) {
    if (src.includes(forbidden)) return bad(`the matcher references ${forbidden}`);
  }
  ok('no signer, no writeContract, no sendTransaction anywhere in the service');

  await svc.close();
  console.log('\n  \x1b[1mThe protocol can run a matcher without becoming a custodian.\x1b[0m\n');
}

// Exit explicitly: a check that fails returns early with the matcher still listening, and an
// open HTTP server keeps Node alive - a failing run hung until CI's timeout instead of failing.
main()
  .catch((e) => { console.error('\nfailed:', e.shortMessage ?? e.message ?? e); process.exitCode = 1; })
  .finally(() => process.exit(process.exitCode ?? 0));
