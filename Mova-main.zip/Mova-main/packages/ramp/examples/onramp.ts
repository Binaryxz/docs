/**
 * The Phase 2 deliverable, end to end against a live chain:
 *
 *   BRL paid by PIX  ->  proven by zkTLS  ->  escrow releases  ->  SHIELDED balance in the pool
 *   BRL paid by BOLETO: the LP issues one for the order, the taker checks it, pays it, and proves the payment
 *
 * PIX and boleto settle only on a zkTLS proof of the bank session. An offer on those rails must name a verifier that can
 * prove one (IAttestorVerifier.provesBankSession): FiatEscrow reverts BankRailNeedsZkTls for any other (contracts/test).
 *
 * Nothing here is modelled but the witnesses. The escrow, the LP registry, the zkTLS verifier with its bank endpoint
 * allowlist and the oracle are deployed; the pool is the same Privacy Pools deployment Phase 1 uses; and the shielded
 * balance at the end is read back out of the pool's own Merkle tree by our indexer. The witnesses are local keys standing
 * in for Reclaim's attestor network, signing claims in its exact format (_zktls.ts, ../src/reclaim.ts): what a local key
 * cannot stand in for is a real bank's TLS session.
 *
 *   npx tsx packages/ramp/examples/onramp.ts <ppEntrypoint> <ppPool> [rpc]
 */
import {
  createWalletClient, createPublicClient, http, parseEther, formatEther, defineChain,
  keccak256, toBytes, type Hex, type Address,
} from 'viem';
import { privateKeyToAccount, generatePrivateKey } from 'viem/accounts';
import { readFileSync } from 'node:fs';
import { eventArgs } from './_event-args.js';
import { revertName, withErrorsOf } from './_revert.js';
import {
  BOLETO_RECEIPT, PIX_RECEIPT, boletoReceiptProof, endpointRails, localWitnesses, pixReceiptProof, receiptProof, zkTlsVerifierArgs,
} from './_zktls.js';
import { matchOrder, type Offer } from '../src/orderbook.js';
import { pixKeyCommitment, newPixSalt, Rail, railMask } from '../src/attestor.js';
import {
  boletoCommitment, brasiliaToday, buildBankBoleto, newBoletoSalt, verifyBoletoCommitment,
} from '../src/boleto.js';
import { boletoPaymentContext } from '../src/reclaim.js';
import { IndexedPoolState } from '../../viewing-key/src/pool/indexer.js';
import { fetchPoolLogs } from '../../viewing-key/src/pool/rpc-source.js';
import { commitmentSecrets, precommitmentOf } from '../../viewing-key/src/pool/scheme.js';
import { walletFromSeed } from '../../viewing-key/src/keys.js';
import { resolveScanRange } from '../../viewing-key/examples/_scan-range.js';

/** A secret salt per PIX key for this run: the on-chain commitment must not be reversible. */
const pixSalts = new Map<string, Hex>();
const pix = (key: string): Hex => {
  if (!pixSalts.has(key)) pixSalts.set(key, newPixSalt());
  return pixKeyCommitment(key, pixSalts.get(key)!);
};

const [ppEntrypoint, ppPool, rpcArg] = process.argv.slice(2);
if (!ppEntrypoint || !ppPool) {
  console.error('usage: onramp.ts <ppEntrypoint> <ppPool> [rpc]');
  process.exit(2);
}
const RPC = rpcArg ?? process.env.RPC_URL ?? 'http://127.0.0.1:8545';
const CHAIN_ID = Number(process.env.CHAIN_ID ?? 1);
const chain = defineChain({
  id: CHAIN_ID, name: 'anvil-fork', nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
  rpcUrls: { default: { http: [RPC] } },
});
const pub = createPublicClient({ chain, transport: http(RPC) });

const step = (s: string) => console.log(`\n\x1b[1m${s}\x1b[0m`);
const ok = (s: string) => console.log(`  \x1b[32mOK\x1b[0m    ${s}`);
const bad = (s: string) => { console.log(`  \x1b[31mFAIL\x1b[0m  ${s}`); process.exitCode = 1; };
const info = (k: string, v: unknown) => console.log(`        ${k.padEnd(26)} ${v}`);

const art = (name: string, file?: string) =>
  JSON.parse(readFileSync(
    new URL(`../../../forge-out/${file ?? `${name}.sol`}/${name}.json`, import.meta.url), 'utf8'));

// anvil #0 funds everything; every ACTOR below is freshly generated.
const FUNDER = privateKeyToAccount('0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80');
const funder = createWalletClient({ account: FUNDER, chain, transport: http(RPC) });

/**
 * Every governed contract starts in SETUP: changes are instant and all user business is
 * refused. The demo wires everything in that window, then closes it. After `completeSetup()`
 * a risk-increasing change (a verifier, an LP's tier, a threshold, a bank endpoint's rails) must
 * be scheduled and wait out GOVERNANCE_DELAY, which is why nothing is configured after that point.
 */
const GOVERNANCE_DELAY = 48n * 60n * 60n;
/** How long a dispute may go unruled before anyone expires it to its refund; the deploy default. */
const DISPUTE_TIMEOUT = 30n * 24n * 60n * 60n;
/** LPRegistry.Tier: NONE, RETAIL, AFFILIATED, INSTITUTIONAL, SUSPENDED. */
const TIER_INSTITUTIONAL = 3;
const ZERO_ASSET = '0x0000000000000000000000000000000000000000' as Address;
const CHAINLINK_ETH_USD = '0x5f4eC3Df9cbd43714FE2740f5E3616155c5b8419' as Address;

async function deploy(name: string, args: unknown[], value = 0n, file?: string): Promise<Address> {
  const a = art(name, file);
  const hash = await funder.deployContract({
    abi: a.abi, bytecode: a.bytecode.object as Hex, args: args as never, value,
  });
  const r = await pub.waitForTransactionReceipt({ hash });
  if (!r.contractAddress) throw new Error(`${name} failed to deploy`);
  return r.contractAddress;
}

async function fund(to: Address, amount: bigint) {
  const h = await funder.sendTransaction({ to, value: amount });
  await pub.waitForTransactionReceipt({ hash: h });
}

async function main() {
  // --- actors -------------------------------------------------------------------------
  const lpKey = generatePrivateKey();
  const lp = privateKeyToAccount(lpKey);
  const lpWallet = createWalletClient({ account: lp, chain, transport: http(RPC) });
  const takerKey = generatePrivateKey();
  const taker = privateKeyToAccount(takerKey);
  const takerWallet = createWalletClient({ account: taker, chain, transport: http(RPC) });
  const govKey = generatePrivateKey();
  const gov = privateKeyToAccount(govKey);
  const govWallet = createWalletClient({ account: gov, chain, transport: http(RPC) });

  await fund(lp.address, parseEther('12'));
  await fund(taker.address, parseEther('1'));
  await fund(gov.address, parseEther('1'));

  step('1. Deploy the ramp');
  // Real Chainlink ETH/USD from mainnet. There is no ETH/BRL feed, so BRL/USD is a stub
  // here - on a fork the honest options are a stub or nothing, and the cross is what is
  // being demonstrated, not the second feed's provenance.
  // Chainlink on a fork is frozen at the fork block while block.timestamp keeps advancing,
  // so the real feed reads hours stale and the escrow (rightly) refuses to trade against it.
  // Read the REAL mainnet price, then republish that same number with a current timestamp:
  // the price is genuine, only the clock is repaired. The staleness guard itself is tested
  // in contracts/test - it is not being skipped here, it is being kept out of the way.
  const [, realEthUsd] = await pub.readContract({
    address: CHAINLINK_ETH_USD,
    abi: [{
      name: 'latestRoundData', type: 'function', stateMutability: 'view', inputs: [],
      outputs: [{ type: 'uint80' }, { type: 'int256' }, { type: 'uint256' },
                { type: 'uint256' }, { type: 'uint80' }],
    }],
    functionName: 'latestRoundData',
  }) as [bigint, bigint, bigint, bigint, bigint];
  const ethUsd = await deploy('MockFeed', [realEthUsd, 8], 0n, 'RampIntegration.t.sol');
  const brlUsd = await deploy('MockFeed', [20000000n, 8], 0n, 'RampIntegration.t.sol');
  // maxAge is deliberately large: a fork freezes Chainlink at the fork block while
  // block.timestamp keeps advancing as we mine, so the real feed reads ~32h stale. That is
  // an artefact of forking, not of the oracle - step 6 proves the staleness guard works.
  const oracle = await deploy('ChainlinkBrlOracle',
    [ethUsd, brlUsd, 60n * 60n, gov.address, GOVERNANCE_DELAY]);
  const registry = await deploy('LPRegistry', [gov.address, GOVERNANCE_DELAY]);

  // What PIX and boleto settle on: witnesses to a TLS session with an allowlisted bank endpoint - a Pix receipt and a
  // boleto payment receipt (_zktls.ts) - every one of them required.
  const witnesses = localWitnesses(2);
  const zktls = await deploy('ReclaimZkTlsVerifier', zkTlsVerifierArgs(gov.address, GOVERNANCE_DELAY, witnesses.addresses));

  // The entrypoint takes deposits; the POOL is where ragequit lives, and the shielded
  // escape hatch calls it directly.
  const escrow = await deploy('FiatEscrow',
    [oracle, registry, ppEntrypoint as Address, ppPool as Address, 500n, gov.address, GOVERNANCE_DELAY, DISPUTE_TIMEOUT]);

  const REG = art('LPRegistry').abi;
  const ESC = art('FiatEscrow').abi;
  const ORA = art('ChainlinkBrlOracle').abi;
  const ZK = art('ReclaimZkTlsVerifier').abi;
  // A release reverts in the escrow or in the verifier it calls: decode either by name.
  const ESCX = withErrorsOf(ESC, ZK);

  const send = async (w: typeof govWallet, address: Address, abi: unknown, fn: string, args: unknown[], value = 0n) => {
    const h = await w.writeContract({ address, abi: abi as never, functionName: fn, args: args as never, value });
    const r = await pub.waitForTransactionReceipt({ hash: h });
    if (r.status !== 'success') throw new Error(`${fn} reverted`);
    return r;
  };
  /** A call that must revert with `want`: OK when it does, FAIL when it succeeds or fails for another reason. */
  const refused = async (what: string, want: string, call: () => Promise<unknown>) => {
    try {
      await call();
      bad(`${what} was accepted`);
    } catch (e) {
      const name = revertName(e);
      if (name === want) ok(`${what} is refused on-chain: ${want}`);
      else bad(`${what} failed, but not with ${want}: ${name ?? (e as Error).message}`);
    }
  };

  // Wired during setup, while changes are instant and nobody can use the contracts.
  await send(govWallet, registry, REG, 'setEscrow', [escrow, true]);
  // Institutional credit in BRL centavos: R$1,000,000 live at once, across every position.
  await send(govWallet, registry, REG, 'setTier', [lp.address, TIER_INSTITUTIONAL, 100_000_000n]);
  await send(govWallet, escrow, ESC, 'setVerifier', [zktls, true]);
  // The boleto receipt endpoint attests boletos, not the verifier's PIX-only default.
  for (const [providerHash, mask] of endpointRails()) {
    await send(govWallet, zktls, ZK, 'setEndpointRails', [providerHash, mask]);
  }
  // The oracle too: it refuses to price until its governor can no longer swap feeds instantly.
  for (const c of [oracle, registry, zktls, escrow]) {
    await send(govWallet, c, art('DelayedGovernance').abi, 'completeSetup', []);
  }
  ok('escrow, registry, zkTLS verifier and oracle deployed; setup closed on all four');
  info('escrow', escrow);
  info('zkTLS verifier', `${zktls} (${witnesses.addresses.length} of ${witnesses.addresses.length} witnesses)`);
  info('bank endpoints', `${PIX_RECEIPT.urlPrefix} (PIX), ${BOLETO_RECEIPT.urlPrefix} (BOLETO)`);

  step('2. Price, crossed from two feeds');
  const [price] = await pub.readContract({
    address: oracle, abi: ORA, functionName: 'brlCentsPerUnit',
  }) as [bigint, bigint];
  info('BRL per ETH', `R$ ${(Number(price) / 100).toLocaleString('pt-BR')}`);
  ok('oracle crossed real ETH/USD with BRL/USD');

  step('3. LP posts an offer, through the zkTLS verifier');
  const PIX_KEY = 'lp-liquidez@pix.example';
  const offerWei = parseEther('10');
  const offerRc = await send(lpWallet, escrow, ESC, 'postOffer',
    [ZERO_ASSET, offerWei, price, pix(PIX_KEY), parseEther('0.05'), parseEther('5'),
     zktls, railMask(Rail.PIX, Rail.BOLETO)], offerWei);
  // Scope the log read to this transaction's own block. `fromBlock: 'earliest'` is the same
  // mistake as scanning a pool from block 0: it asks an upstream node for the whole chain,
  // and free RPC tiers cap the range - so it fails as a confusing transport error rather
  // than as the "I asked for too much" that it actually is.
  const logs = await pub.getContractEvents({
    address: escrow, abi: ESC, eventName: 'OfferPosted', blockHash: offerRc.blockHash,
  });
  const { offerId } = eventArgs(logs[logs.length - 1], 'OfferPosted', { offerId: 'bytes32' });
  ok(`10 ETH of liquidity posted at the market rate through the zkTLS verifier, offer ${offerId.slice(0, 12)}...`);

  step('4. Match, off-chain');
  const book: Offer[] = [{
    offerId, lp: lp.address, asset: ZERO_ASSET, decimals: 18,
    rails: [Rail.PIX, Rail.BOLETO], availableWei: offerWei, priceBrlCentsPerEth: price,
    minOrderWei: parseEther('0.05'), maxOrderWei: parseEther('5'),
    verifier: zktls, tier: 'INSTITUTIONAL', settledCents: 0n, disputesLost: 0,
  }];
  const wanted = parseEther('0.5');
  const match = matchOrder(book, {
    asset: ZERO_ASSET, weiWanted: wanted, rails: [Rail.PIX], requireInstitutional: true,
  });
  if (match.unfilledWei !== 0n) return bad('book could not fill the request');
  info('taker wants', `${formatEther(wanted)} ETH shielded`);
  info('taker must pay', `R$ ${(Number(match.totalBrlCents) / 100).toLocaleString('pt-BR')}`);
  ok('matched off-chain; the matcher signs nothing and holds nothing');

  step('5. Taker locks the order');
  // The shielded destination: a precommitment only the taker can open.
  // A fresh seed per run. A fixed seed yields a fixed precommitment, and the pool rejects
  // one it has already seen - so the demo would pass once and then fail forever with a
  // TransferFailed that says nothing about the real cause.
  const wallet = walletFromSeed(crypto.getRandomValues(new Uint8Array(32)));
  const { nullifier, secret } = commitmentSecrets(wallet.spendingSecret, 0, 0);
  const precommitment = precommitmentOf(nullifier, secret);

  const pre = new IndexedPoolState(await poolScope());
  const scan = resolveScanRange(CHAIN_ID, ppPool, await pub.getBlockNumber());
  pre.apply(await fetchPoolLogs({ url: RPC, pool: ppPool, fromBlock: scan.fromBlock }));
  const rootBefore = pre.root();

  const fill = match.fills[0];
  const lockRc = await send(takerWallet, escrow, ESC, 'lockOrder',
    [offerId, fill.weiAmount, 1 /* SHIELDED */, taker.address, precommitment]);
  const lockLogs = await pub.getContractEvents({
    address: escrow, abi: ESC, eventName: 'OrderLocked', blockHash: lockRc.blockHash,
  });
  const { orderId } = eventArgs(lockLogs[0], 'OrderLocked', { orderId: 'bytes32' });
  const order = await pub.readContract({
    address: escrow, abi: ESC, functionName: 'orders', args: [orderId],
  }) as unknown[];
  const brlCents = order[3] as bigint;
  ok(`order locked, taker owes R$ ${(Number(brlCents) / 100).toLocaleString('pt-BR')}`);
  info('liquidity reserved', `${formatEther(fill.weiAmount)} ETH, LP cannot withdraw it`);

  step('6. The taker pays BRL by PIX (off-chain); witnesses observe the taker\'s session with the bank');
  // What the bank's Pix receipt shows, as a witness extracts it: the e2e id hashed, the salted key the offer names, the
  // amount and time. `pixReceiptProof` plays the witnesses; in production these fields come out of the TLS response.
  const paid = {
    orderId,
    bankTxId: keccak256(toBytes(`E${Date.now()}PIXDEMO`)),
    payeeKeyHash: pix(PIX_KEY),
    payerRef: keccak256(toBytes('cpf:***.***.***-**')),
    amountBrlCents: brlCents,
    paidAt: BigInt((await pub.getBlock()).timestamp),
  };
  const takerProving = { witnessKeys: witnesses.keys, owner: taker.address };
  const proof = await pixReceiptProof({ ...paid, ...takerProving });
  ok(`a claim about the taker's Pix receipt, bound to this order, signed by ${witnesses.keys.length} witnesses`);

  // A genuine receipt of an underpayment proves exactly that - and nothing is released for it.
  const underpaid = await pixReceiptProof({
    ...paid, bankTxId: keccak256(toBytes(`E${Date.now()}PIXSHORT`)), amountBrlCents: brlCents - 1n, ...takerProving,
  });
  await refused('a proven receipt for one centavo less', 'Underpaid', () => send(takerWallet, escrow, ESCX, 'releaseWithProof', [orderId, underpaid]));

  step('7. Release');
  const relRc = await send(takerWallet, escrow, ESCX, 'releaseWithProof', [orderId, proof]);
  ok(`the escrow verified the zkTLS proof and released, block ${relRc.blockNumber}`);

  step('8. Did a shielded balance actually appear?');
  const post = new IndexedPoolState(await poolScope());
  post.apply(await fetchPoolLogs({ url: RPC, pool: ppPool, fromBlock: scan.fromBlock }));
  const onChainRoot = await pub.readContract({
    address: ppPool as Address,
    abi: [{ name: 'currentRoot', type: 'function', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint256' }] }],
    functionName: 'currentRoot',
  }) as bigint;

  if (post.root() === rootBefore) return bad('the pool tree did not grow');
  if (post.root() !== onChainRoot) return bad('our rebuilt root disagrees with the contract');
  ok('the pool tree grew, and our rebuilt root matches the contract exactly');

  const mine = post.depositsBy([escrow]);
  const last = mine[mine.length - 1];
  info('shielded commitment', String(last.commitment).slice(0, 30) + '...');
  info('shielded value', `${formatEther(BigInt(last.value))} ETH`);
  ok('BRL paid by PIX became a shielded balance');

  step('9. Replay');
  try {
    await send(takerWallet, escrow, ESCX, 'releaseWithProof', [orderId, proof]);
    bad('the same receipt settled twice');
  } catch {
    ok('the same bank receipt cannot be spent again');
  }

  step('10. The same offer, paid by BOLETO');
  // A boleto is not an address: the LP registers one for THIS order's amount after the taker
  // locks, and commits to it on-chain. A taker who can only pay at a bank counter uses this.
  const boletoBuyer = privateKeyToAccount(generatePrivateKey());
  await fund(boletoBuyer.address, parseEther('0.2'));
  const buyerWallet = createWalletClient({ account: boletoBuyer, chain, transport: http(RPC) });
  const bLock = await send(buyerWallet, escrow, ESC, 'lockOrderByBoleto',
    [offerId, parseEther('0.2'), 0 /* DIRECT */, boletoBuyer.address, 0n]);
  const bOrderId = eventArgs((await pub.getContractEvents({
    address: escrow, abi: ESC, eventName: 'BoletoRequested', blockHash: bLock.blockHash,
  }))[0], 'BoletoRequested', { orderId: 'bytes32' }).orderId;
  const bOrder = await pub.readContract({
    address: escrow, abi: ESC, functionName: 'orders', args: [bOrderId],
  }) as unknown[];
  const bCents = bOrder[3] as bigint;
  ok(`locked by boleto; the LP has an hour to issue one for R$ ${(Number(bCents) / 100).toLocaleString('pt-BR')}`);

  // The LP's bank registers the boleto (here: a real-format line for the LP's account) and
  // the LP commits to it, salted. Line and salt go to the taker, off-chain.
  const chainNow = new Date(Number((await pub.getBlock()).timestamp) * 1000);
  const due = brasiliaToday(new Date(chainNow.getTime() + 3 * 86_400_000));
  const issued = buildBankBoleto({
    bankCode: '341', amountCents: bCents, dueDate: due, freeField: '1090000123452345678901230',
  });
  const bSalt = newBoletoSalt();
  await send(lpWallet, escrow, ESC, 'issueBoleto', [bOrderId, boletoCommitment(issued, bSalt)]);
  info('boleto line', issued.line.replace(/^(\d{5})(\d{5})(\d{5})(\d{6})(\d{5})(\d{6})(\d)(\d{14})$/, '$1.$2 $3.$4 $5.$6 $7 $8'));
  info('due', due);

  // The taker checks, before paying a centavo, that this line and salt open the commitment
  // on-chain and are for exactly what the order says.
  const [, , onChainCommitment] = await pub.readContract({
    address: escrow, abi: ESC, functionName: 'boletoOf', args: [bOrderId],
  }) as [bigint, bigint, Hex];
  verifyBoletoCommitment({ line: issued.line, salt: bSalt, commitment: onChainCommitment, brlCents: bCents, now: chainNow });
  ok('the taker opened the on-chain commitment: right boleto, right amount, not overdue');
  const dearer = buildBankBoleto({
    bankCode: '341', amountCents: bCents + 100n, dueDate: due, freeField: '1090000123452345678901230',
  });
  try {
    verifyBoletoCommitment({ line: dearer.line, salt: bSalt, commitment: onChainCommitment, brlCents: bCents, now: chainNow });
    bad('the taker accepted a boleto for another amount');
  } catch {
    ok('a boleto for R$ 1,00 more would have been refused before paying - a free cancel');
  }

  // Paid at a bank; the witnesses observe the taker's session with the bank's boleto payment receipt, and the commitment
  // is derived from the paid DOCUMENT and the salt - it must be the one the LP issued.
  const paidBoleto = {
    orderId: bOrderId, bankTxId: keccak256(toBytes(`AUTH${Date.now()}BOLETO`)),
    line: issued.line, salt: bSalt, payerRef: keccak256(toBytes('cpf:boleto-payer')),
    amountBrlCents: bCents, paidAt: BigInt((await pub.getBlock()).timestamp),
  };
  const buyerProving = { witnessKeys: witnesses.keys, owner: boletoBuyer.address };

  // The same payment, vouched for by the Pix receipt endpoint - as a boleto, or as a Pix - settles nothing.
  const fromPixEndpoint = await receiptProof(boletoPaymentContext(paidBoleto), PIX_RECEIPT, buyerProving);
  await refused('a boleto receipt claimed from the Pix receipt endpoint', 'RailNotAllowedForEndpoint',
    () => send(buyerWallet, escrow, ESCX, 'releaseWithProof', [bOrderId, fromPixEndpoint]));
  const asPix = await receiptProof({ ...boletoPaymentContext(paidBoleto), rail: Rail.PIX }, PIX_RECEIPT, buyerProving);
  await refused('a Pix receipt of the same money, to the boleto\'s commitment', 'RailNotAccepted',
    () => send(buyerWallet, escrow, ESCX, 'releaseWithProof', [bOrderId, asPix]));

  const buyerBefore = await pub.getBalance({ address: boletoBuyer.address });
  const bRel = await send(lpWallet, escrow, ESCX, 'releaseWithProof', [bOrderId, await boletoReceiptProof({ ...paidBoleto, ...buyerProving })]);
  const buyerAfter = await pub.getBalance({ address: boletoBuyer.address });
  if (buyerAfter - buyerBefore !== parseEther('0.2')) return bad('the boleto payer did not receive the ETH');
  ok(`boleto payment proven from the boleto receipt endpoint and released, block ${bRel.blockNumber} (an LP relayed it; the ETH went to the taker)`);

  console.log('\n  \x1b[1mBRL in by PIX or boleto, proven by zkTLS; shielded balance out.\x1b[0m');
  console.log('  The matcher held nothing, the taker never revealed a shielded secret, and nothing but a proof of the bank session could have stood in for the bank.\n');

  async function poolScope() {
    return await pub.readContract({
      address: ppPool as Address,
      abi: [{ name: 'SCOPE', type: 'function', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint256' }] }],
      functionName: 'SCOPE',
    }) as bigint;
  }
}

main().catch((e) => { console.error('\nfailed:', e.message ?? e); process.exit(1); });
