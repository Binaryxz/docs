/**
 * The other half of the Phase 2 deliverable, against a live chain:
 *
 *   shielded balance  ->  private withdrawal  ->  sale  ->  BRL in the seller's bank, proven by zkTLS
 *
 * The privacy claim here is narrower than on the on-ramp and worth stating exactly. The
 * seller must move ETH out of the pool to escrow it, so the exit is visible; what stays
 * hidden is WHICH shielded deposit funded it, because the withdrawal lands on a freshly
 * generated address that has never transacted. The sale therefore links "some address sold
 * ETH for BRL" to a bank account, not "this depositor did".
 *
 * Every payout is a bank payment, and a bank payment settles only on a zkTLS proof of the bank session: the LP pays the
 * seller and proves its own session with its bank. OffRampEscrow.openSale reverts BankRailNeedsZkTls for a verifier that
 * does not prove it (contracts/test), since colluding attestors could swear to a payout the LP never made and take the
 * seller's crypto. The witnesses are local keys standing in for Reclaim's attestor network (_zktls.ts).
 *
 * Then the two other things the off-ramp must survive, on the same live contracts:
 *
 *   - a seller whose payee is a BILL: the sale commits to a boleto, and the LP pays it and proves the receipt;
 *   - disputes: one ruled by the desk and submitted by the LP it favours - the governor never
 *     touches it - and one the desk never answers, which the escrow refunds on its own timeout.
 *
 *   npx tsx packages/ramp/examples/offramp.ts <ppEntrypoint> <ppPool> [rpc]
 */
import {
  createWalletClient, createPublicClient, http, parseEther, formatEther, defineChain,
  keccak256, toBytes, type Hex, type Address,
} from 'viem';
import {
  assertPayableBoleto, boletoCommitment, brasiliaToday, buildCollectionBoleto, newBoletoSalt,
  verifyBoletoCommitment,
} from '../src/boleto.js';
import { Arbitrator, evidenceDigest, signEvidence } from '../src/disputes.js';
import { ArbitrationDesk, MemoryCaseStore, chainEscrowReader } from '../src/arbitration-desk.js';
import { privateKeyToAccount, generatePrivateKey } from 'viem/accounts';
import { readFileSync } from 'node:fs';
import { eventArgs } from './_event-args.js';
import { revertName, withErrorsOf } from './_revert.js';
import {
  BOLETO_RECEIPT, PIX_RECEIPT, boletoReceiptProof, endpointRails, localWitnesses, pixReceiptProof, receiptProof, zkTlsVerifierArgs,
} from './_zktls.js';
import { pixKeyCommitment, newPixSalt, Rail, railMask } from '../src/attestor.js';

/** A secret salt per PIX key for this run: the on-chain commitment must not be reversible. */
const pixSalts = new Map<string, Hex>();
const pix = (key: string): Hex => {
  if (!pixSalts.has(key)) pixSalts.set(key, newPixSalt());
  return pixKeyCommitment(key, pixSalts.get(key)!);
};

const [ppEntrypoint, ppPool, rpcArg] = process.argv.slice(2);
if (!ppEntrypoint || !ppPool) {
  console.error('usage: offramp.ts <ppEntrypoint> <ppPool> [rpc]');
  process.exit(2);
}
const RPC = rpcArg ?? process.env.RPC_URL ?? 'http://127.0.0.1:8545';
const CHAIN_ID = Number(process.env.CHAIN_ID ?? 1);
const chain = defineChain({
  id: CHAIN_ID, name: 'anvil-fork', nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
  rpcUrls: { default: { http: [RPC] } },
});
const pub = createPublicClient({ chain, transport: http(RPC) });

const step = (s: string) => console.log(`\n\x1b[1m${s}\x1b[0m`);
const ok = (s: string) => console.log(`  \x1b[32mOK\x1b[0m    ${s}`);
const bad = (s: string) => { console.log(`  \x1b[31mFAIL\x1b[0m  ${s}`); process.exitCode = 1; };
const info = (k: string, v: unknown) => console.log(`        ${k.padEnd(26)} ${v}`);

const art = (name: string, file?: string) =>
  JSON.parse(readFileSync(
    new URL(`../../../forge-out/${file ?? `${name}.sol`}/${name}.json`, import.meta.url), 'utf8'));

const FUNDER = privateKeyToAccount('0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80');
const funder = createWalletClient({ account: FUNDER, chain, transport: http(RPC) });

/**
 * Every governed contract starts in SETUP: changes are instant and all user business is
 * refused. The demo wires everything in that window, then closes it. After `completeSetup()`
 * a risk-increasing change (a verifier, an LP's tier, a threshold, a bank endpoint's rails) must
 * be scheduled and wait out GOVERNANCE_DELAY, which is why nothing is configured after that point.
 */
const GOVERNANCE_DELAY = 48n * 60n * 60n;
/** The deploy script's default: after this, an unruled dispute refunds to its origin. */
const DISPUTE_TIMEOUT = 30n * 24n * 60n * 60n;
/** LPRegistry.Tier: NONE, RETAIL, AFFILIATED, INSTITUTIONAL, SUSPENDED. */
const TIER_INSTITUTIONAL = 3;
const ZERO_ASSET = '0x0000000000000000000000000000000000000000' as Address;
const CHAINLINK_ETH_USD = '0x5f4eC3Df9cbd43714FE2740f5E3616155c5b8419' as Address;

async function deploy(name: string, args: unknown[], value = 0n, file?: string): Promise<Address> {
  const a = art(name, file);
  const hash = await funder.deployContract({
    abi: a.abi, bytecode: a.bytecode.object as Hex, args: args as never, value,
  });
  const r = await pub.waitForTransactionReceipt({ hash });
  if (!r.contractAddress) throw new Error(`${name} failed to deploy`);
  return r.contractAddress;
}

async function fund(to: Address, amount: bigint) {
  const h = await funder.sendTransaction({ to, value: amount });
  await pub.waitForTransactionReceipt({ hash: h });
}

async function main() {
  const gov = privateKeyToAccount(generatePrivateKey());
  const govWallet = createWalletClient({ account: gov, chain, transport: http(RPC) });
  const lpKey = generatePrivateKey();
  const lp = privateKeyToAccount(lpKey);
  const lpWallet = createWalletClient({ account: lp, chain, transport: http(RPC) });
  await fund(gov.address, parseEther('1'));
  await fund(lp.address, parseEther('1'));

  step('1. Deploy the off-ramp');
  // Chainlink on a fork is frozen at the fork block while block.timestamp keeps advancing,
  // so the real feed reads hours stale and the escrow (rightly) refuses to trade against it.
  // Read the REAL mainnet price, then republish that same number with a current timestamp:
  // the price is genuine, only the clock is repaired. The staleness guard itself is tested
  // in contracts/test - it is not being skipped here, it is being kept out of the way.
  const [, realEthUsd] = await pub.readContract({
    address: CHAINLINK_ETH_USD,
    abi: [{
      name: 'latestRoundData', type: 'function', stateMutability: 'view', inputs: [],
      outputs: [{ type: 'uint80' }, { type: 'int256' }, { type: 'uint256' },
                { type: 'uint256' }, { type: 'uint80' }],
    }],
    functionName: 'latestRoundData',
  }) as [bigint, bigint, bigint, bigint, bigint];
  const ethUsd = await deploy('MockFeed', [realEthUsd, 8], 0n, 'RampIntegration.t.sol');
  const brlUsd = await deploy('MockFeed', [20000000n, 8], 0n, 'RampIntegration.t.sol');
  const oracle = await deploy('ChainlinkBrlOracle',
    [ethUsd, brlUsd, 60n * 60n, gov.address, GOVERNANCE_DELAY]);
  const registry = await deploy('LPRegistry', [gov.address, GOVERNANCE_DELAY]);

  // What a payout settles on: witnesses to the LP's TLS session with an allowlisted bank endpoint (_zktls.ts).
  const witnesses = localWitnesses(2);
  const zktls = await deploy('ReclaimZkTlsVerifier', zkTlsVerifierArgs(gov.address, GOVERNANCE_DELAY, witnesses.addresses));
  const escrow = await deploy('OffRampEscrow', [oracle, registry, 500n, gov.address, GOVERNANCE_DELAY, DISPUTE_TIMEOUT]);

  const REG = art('LPRegistry').abi;
  const ESC = art('OffRampEscrow').abi;
  const ORA = art('ChainlinkBrlOracle').abi;
  const ZK = art('ReclaimZkTlsVerifier').abi;
  // A settlement reverts in the escrow or in the verifier it calls: decode either by name.
  const ESCX = withErrorsOf(ESC, ZK);

  const send = async (w: typeof govWallet, address: Address, abi: unknown, fn: string, args: unknown[], value = 0n) => {
    const h = await w.writeContract({ address, abi: abi as never, functionName: fn, args: args as never, value });
    const r = await pub.waitForTransactionReceipt({ hash: h });
    if (r.status !== 'success') throw new Error(`${fn} reverted`);
    return r;
  };
  /** A call that must revert with `want`: OK when it does, FAIL when it succeeds or fails for another reason. */
  const refused = async (what: string, want: string, call: () => Promise<unknown>) => {
    try {
      await call();
      bad(`${what} was accepted`);
    } catch (e) {
      const name = revertName(e);
      if (name === want) ok(`${what} is refused on-chain: ${want}`);
      else bad(`${what} failed, but not with ${want}: ${name ?? (e as Error).message}`);
    }
  };

  // Both LPs are admitted during setup: once it closes, admitting one waits out the delay.
  const lp2 = privateKeyToAccount(generatePrivateKey());
  await send(govWallet, registry, REG, 'setEscrow', [escrow, true]);
  await send(govWallet, registry, REG, 'setTier', [lp.address, TIER_INSTITUTIONAL, 100_000_000n]);
  await send(govWallet, registry, REG, 'setTier', [lp2.address, TIER_INSTITUTIONAL, 100_000_000n]);
  await send(govWallet, escrow, ESC, 'setVerifier', [zktls, true]);
  // The boleto receipt endpoint attests boletos - the bill in step 9 - not the verifier's PIX-only default.
  for (const [providerHash, mask] of endpointRails()) {
    await send(govWallet, zktls, ZK, 'setEndpointRails', [providerHash, mask]);
  }
  // The desk's arbitrator is registered during setup, like everything else.
  const arbKey = generatePrivateKey();
  await send(govWallet, escrow, ESC, 'setArbitrator', [privateKeyToAccount(arbKey).address, true]);
  // The oracle too: it refuses to price until its governor can no longer swap feeds instantly.
  for (const c of [oracle, registry, zktls, escrow]) {
    await send(govWallet, c, art('DelayedGovernance').abi, 'completeSetup', []);
  }
  ok('off-ramp escrow and zkTLS verifier deployed, two institutional LPs admitted, setup closed');
  info('bank endpoints', `${PIX_RECEIPT.urlPrefix} (PIX), ${BOLETO_RECEIPT.urlPrefix} (BOLETO)`);

  step('2. The seller exits the pool to a fresh address');
  // Standing in for a relayed private withdrawal: what matters to the off-ramp is that the
  // escrowing address is new, so nothing on-chain ties this sale to a particular deposit.
  const sellerKey = generatePrivateKey();
  const seller = privateKeyToAccount(sellerKey);
  const sellerWallet = createWalletClient({ account: seller, chain, transport: http(RPC) });
  await fund(seller.address, parseEther('1.1'));
  const txCount = await pub.getTransactionCount({ address: seller.address });
  if (txCount !== 0) return bad('the seller address has history');
  ok(`seller funded at a never-used address (tx count ${txCount})`);

  step('3. Seller opens a sale, proven by zkTLS');
  const [price] = await pub.readContract({
    address: oracle, abi: ORA, functionName: 'brlCentsPerUnit',
  }) as [bigint, bigint];
  const saleWei = parseEther('1');
  const wantCents = (saleWei * price) / 10n ** 18n;
  const SELLER_PIX = 'vendedor@pix.example';

  const openRc = await send(sellerWallet, escrow, ESC, 'openSale',
    [ZERO_ASSET, saleWei, wantCents, pix(SELLER_PIX), zktls, railMask(Rail.PIX),
     seller.address], saleWei);
  const openLogs = await pub.getContractEvents({
    address: escrow, abi: ESC, eventName: 'SaleOpened', blockHash: openRc.blockHash,
  });
  const { saleId } = eventArgs(openLogs[0], 'SaleOpened', { saleId: 'bytes32' });
  info('selling', `${formatEther(saleWei)} ETH`);
  info('wants', `R$ ${(Number(wantCents) / 100).toLocaleString('pt-BR')} by PIX only`);
  ok(`sale open through the zkTLS verifier, ${saleId.slice(0, 12)}... - the ETH is escrowed, not the LP's yet`);

  step('4. An LP claims it');
  const claimRc = await send(lpWallet, escrow, ESC, 'claimSale', [saleId]);
  const sale = await pub.readContract({
    address: escrow, abi: ESC, functionName: 'sales', args: [saleId],
  }) as unknown[];
  ok(`claimed exclusively, block ${claimRc.blockNumber}`);
  // Sale fields: seller, asset, weiAmount, brlCents, payeeKeyHash, verifier, railMask,
  // lp, claimedAt, payBy, refundTo, state. Adding `asset` shifted every index after it,
  // which is exactly the kind of change a positional tuple read does not survive.
  info('LP must pay by', new Date(Number(sale[9] as bigint) * 1000).toISOString());

  step('5. A second LP cannot claim the same sale');
  await fund(lp2.address, parseEther('0.2'));
  try {
    await send(createWalletClient({ account: lp2, chain, transport: http(RPC) }),
      escrow, ESC, 'claimSale', [saleId]);
    bad('two LPs claimed the same sale');
  } catch {
    ok('exclusivity holds, so two LPs cannot both send BRL for one sale');
  }

  step('6. The LP pays the seller by PIX, and proves its own session with its bank');
  // What the LP's bank shows for the Pix it sent, as a witness extracts it: bound to this SALE - the sale id is the order
  // id the escrow hands the verifier.
  const payout = {
    orderId: saleId,
    bankTxId: keccak256(toBytes(`E${Date.now()}OFFRAMP`)),
    payeeKeyHash: pix(SELLER_PIX),
    payerRef: keccak256(toBytes('lp-bank-account')),
    amountBrlCents: wantCents,
    paidAt: BigInt((await pub.getBlock()).timestamp),
  };
  const lpProving = { witnessKeys: witnesses.keys, owner: lp.address };
  const proof = await pixReceiptProof({ ...payout, ...lpProving });
  ok(`a claim about the LP's Pix receipt for the payout, bound to this sale, signed by ${witnesses.keys.length} witnesses`);

  // The Pix receipt endpoint cannot call the same payout a boleto: a boleto is proven from a boleto receipt, never a key.
  const asBoleto = await receiptProof({ ...payout, rail: Rail.BOLETO }, PIX_RECEIPT, lpProving);
  await refused('the same payout claimed as a boleto from the Pix receipt endpoint', 'RailNotAllowedForEndpoint',
    () => send(lpWallet, escrow, ESCX, 'settleWithProof', [saleId, asBoleto]));

  step('7. The LP collects the ETH');
  const lpBefore = await pub.getBalance({ address: lp.address });
  const rc = await send(lpWallet, escrow, ESCX, 'settleWithProof', [saleId, proof]);
  const lpAfter = await pub.getBalance({ address: lp.address });
  const gas = rc.gasUsed * rc.effectiveGasPrice;
  if (lpAfter + gas - lpBefore !== saleWei) return bad('the LP did not receive the escrowed ETH');
  ok(`settled on the zkTLS proof, block ${rc.blockNumber}`);
  info('LP received', `${formatEther(lpAfter + gas - lpBefore)} ETH`);
  info('seller received', `R$ ${(Number(wantCents) / 100).toLocaleString('pt-BR')} by PIX`);

  step('8. Replay');
  try {
    await send(lpWallet, escrow, ESCX, 'settleWithProof', [saleId, proof]);
    bad('the sale settled twice');
  } catch {
    ok('the sale is settled and the receipt is burned');
  }

  // ------------------------------------------------------------------ a bill, by boleto
  step('9. A seller sells to have a BILL paid: the payee is a boleto');
  const chainNow = async () => new Date(Number((await pub.getBlock()).timestamp) * 1000);
  const billCents = 38_990n; // R$ 389,90 of electricity
  const bill = buildCollectionBoleto({
    segment: 3, valueIdentifier: 8, value: billCents,
    // Company code, then the free field - which, when a collection document carries a due date,
    // starts with it as AAAAMMDD.
    rest: `0056${brasiliaToday(new Date((await chainNow()).getTime() + 10 * 86_400_000)).replace(/-/g, '')}00000000987654321`,
  });
  const billSalt = newBoletoSalt();
  // The amount is written in the bill; the SDK stops a sale priced otherwise before it opens.
  try {
    assertPayableBoleto(bill, billCents + 1000n, { now: await chainNow() });
    bad('the SDK let a seller price a bill at something other than its amount');
  } catch {
    ok('a sale of R$ 10,00 more than the bill says is refused before it is opened');
  }
  assertPayableBoleto(bill, billCents, { now: await chainNow() });
  const billCommitment = boletoCommitment(bill, billSalt);
  // Crypto worth the bill at the oracle price, rounded up to stay inside the band.
  const billWei = (billCents * 10n ** 18n + price - 1n) / price;
  const billSeller = privateKeyToAccount(generatePrivateKey());
  await fund(billSeller.address, billWei + parseEther('0.05'));
  const billSellerW = createWalletClient({ account: billSeller, chain, transport: http(RPC) });
  await refused('a sale mixing a boleto payee with a PIX rail', 'BadSale', () => send(billSellerW, escrow, ESC, 'openSale',
    [ZERO_ASSET, billWei, billCents, billCommitment, zktls, railMask(Rail.PIX, Rail.BOLETO), billSeller.address], billWei));
  const billOpen = await send(billSellerW, escrow, ESC, 'openSale',
    [ZERO_ASSET, billWei, billCents, billCommitment, zktls, railMask(Rail.BOLETO), billSeller.address], billWei);
  const billSale = eventArgs((await pub.getContractEvents({
    address: escrow, abi: ESC, eventName: 'SaleOpened', blockHash: billOpen.blockHash,
  }))[0], 'SaleOpened', { saleId: 'bytes32' }).saleId;
  ok(`sale open for R$ ${(Number(billCents) / 100).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}, payee committed as a boleto`);

  // The LP gets line and salt from the seller and checks them against the chain before claiming.
  verifyBoletoCommitment({ line: bill.line, salt: billSalt, commitment: billCommitment, brlCents: billCents, now: await chainNow() });
  await send(lpWallet, escrow, ESC, 'claimSale', [billSale]);
  ok('the LP opened the commitment - right bill, right amount - and claimed');

  const billPaidAt = BigInt((await pub.getBlock()).timestamp);
  // Genuine witnesses to a receipt for R$ 5,00 over the bill - a bank's error, or a payment the LP inflated - still cannot
  // settle it: a boleto pays exactly its amount.
  const overpaid = await receiptProof({
    orderId: billSale, bankTxId: keccak256(toBytes(`AUTH${Date.now()}OTHER`)), payeeKeyHash: billCommitment,
    payerRef: keccak256(toBytes('lp-bank-account')), amountBrlCents: billCents + 500n, paidAt: billPaidAt, rail: Rail.BOLETO,
  }, BOLETO_RECEIPT, lpProving);
  await refused('a proven boleto receipt for R$ 5,00 over the bill', 'WrongAmount',
    () => send(lpWallet, escrow, ESCX, 'settleWithProof', [billSale, overpaid]));

  const billProof = await boletoReceiptProof({
    orderId: billSale, bankTxId: keccak256(toBytes(`AUTH${Date.now()}BILL`)), line: bill.line, salt: billSalt,
    payerRef: keccak256(toBytes('lp-bank-account')), amountBrlCents: billCents, paidAt: billPaidAt, ...lpProving,
  });
  const lpBeforeBill = await pub.getBalance({ address: lp.address });
  const billRc = await send(lpWallet, escrow, ESCX, 'settleWithProof', [billSale, billProof]);
  const billGas = billRc.gasUsed * billRc.effectiveGasPrice;
  if ((await pub.getBalance({ address: lp.address })) + billGas - lpBeforeBill !== billWei) {
    return bad('the LP was not paid for the bill');
  }
  ok('the LP paid the bill at its bank, proved the receipt from the boleto endpoint - the commitment derived from the paid line - and it settled');

  // ------------------------------------------------------------------ disputes
  step('10. A dispute the desk rules - submitted by the LP it favours, never by the governor');
  const disputeSale = async (by: 'seller' | 'lp') => {
    const who = privateKeyToAccount(generatePrivateKey());
    await fund(who.address, parseEther('0.25'));
    const w = createWalletClient({ account: who, chain, transport: http(RPC) });
    const wei = parseEther('0.2');
    const cents = (wei * price) / 10n ** 18n;
    const rc = await send(w, escrow, ESC, 'openSale',
      [ZERO_ASSET, wei, cents, pix(`seller-${who.address.slice(2, 8)}@pix.example`), zktls, railMask(Rail.PIX), who.address], wei);
    const id = eventArgs((await pub.getContractEvents({
      address: escrow, abi: ESC, eventName: 'SaleOpened', blockHash: rc.blockHash,
    }))[0], 'SaleOpened', { saleId: 'bytes32' }).saleId;
    await send(lpWallet, escrow, ESC, 'claimSale', [id]);
    await send(by === 'lp' ? lpWallet : w, escrow, ESC, 'raiseDispute', [id, by === 'lp' ? 'paid by PIX, bank session unprovable' : 'nothing arrived']);
    return { id, seller: who, wei };
  };
  const ruled = await disputeSale('lp');
  const unanswered = await disputeSale('seller');

  let chainTime = Number((await pub.getBlock()).timestamp);
  const warp = async (seconds: number) => {
    await pub.request({ method: 'evm_increaseTime' as never, params: [seconds] as never });
    await pub.request({ method: 'evm_mine' as never, params: [] as never });
    chainTime = Number((await pub.getBlock()).timestamp);
  };
  const desk = new ArbitrationDesk(new MemoryCaseStore(), new Arbitrator(arbKey), {
    chainId: CHAIN_ID, escrows: [{ address: escrow, leg: 'offramp' }], reader: chainEscrowReader(pub),
  }, () => chainTime);
  const kase = await desk.open({ orderId: ruled.id, escrow, raisedBy: 'lp', reason: 'paid by PIX, bank session unprovable' });
  info('case deadline (from chain)', new Date(kase.case.expiresAt * 1000).toISOString());
  const statement = { digest: evidenceDigest(`LP bank statement ${ruled.id}`), kind: 'bank-statement' };
  await desk.submitEvidence(kase.caseId, statement, await signEvidence(
    lpKey,
    { caseId: kase.caseId, orderId: ruled.id, escrow, chainId: CHAIN_ID }, statement,
  ));
  await desk.rule(kase.caseId, 'RELEASE', 'statement shows the PIX to the seller\'s key', [statement.digest]);
  const sub = await desk.submission(kase.caseId);
  ok('the desk read the case from the chain and signed a RELEASE');

  await send(lpWallet, escrow, ESC, 'resolveDispute', sub.args);
  const postedLogs = await pub.getContractEvents({ address: escrow, abi: ESC, eventName: 'RulingPosted', fromBlock: 'latest' });
  const posted = postedLogs.map((l) => {
    const a = eventArgs(l, 'RulingPosted', { saleId: 'bytes32', paidLP: 'bool', arbitrator: 'address', evidenceRoot: 'bytes32' });
    return { escrow, orderId: a.saleId, arbitrator: a.arbitrator, evidenceRoot: a.evidenceRoot, releasedToTaker: a.paidLP };
  });
  if ((await desk.postedRulingsNotSigned(posted)).length !== 0 || posted.length !== 1) {
    return bad('the desk did not recognise the ruling posted on-chain');
  }
  ok('posted by the LP; the desk recognises it as its own (a stolen key\'s would show up here, a day early)');
  try {
    await send(lpWallet, escrow, ESC, 'resolveDispute', sub.args);
    bad('a posted ruling executed before its delay');
  } catch {
    ok('and it cannot execute yet: it stays public for RULING_DELAY first');
  }
  await warp(Number(sub.executableAfter));
  const lpBeforeRuling = await pub.getBalance({ address: lp.address });
  const exec = await send(lpWallet, escrow, ESC, 'resolveDispute', sub.args);
  const execGas = exec.gasUsed * exec.effectiveGasPrice;
  if ((await pub.getBalance({ address: lp.address })) + execGas - lpBeforeRuling !== ruled.wei) {
    return bad('the ruling did not pay the LP');
  }
  ok('a day later the LP submitted it again and was paid - no governor transaction anywhere');

  step('11. A dispute nobody ever rules on: the escrow\'s own timeout refunds the seller');
  try {
    await send(createWalletClient({ account: FUNDER, chain, transport: http(RPC) }), escrow, ESC, 'expireDispute', [unanswered.id]);
    bad('a dispute expired before its timeout');
  } catch {
    ok('expiring it early is refused: the dispute is still open');
  }
  await warp(Number(DISPUTE_TIMEOUT));
  const sellerBefore = await pub.getBalance({ address: unanswered.seller.address });
  await send(createWalletClient({ account: FUNDER, chain, transport: http(RPC) }), escrow, ESC, 'expireDispute', [unanswered.id]);
  const sellerAfter = await pub.getBalance({ address: unanswered.seller.address });
  if (sellerAfter - sellerBefore !== unanswered.wei) return bad('the seller was not refunded');
  const lpRecord = await pub.readContract({ address: registry, abi: REG, functionName: 'lps', args: [lp.address] }) as readonly unknown[];
  if (lpRecord[6] !== 0n) return bad(`the LP still has ${lpRecord[6]} centavos of exposure reserved`);
  ok('30 days on, a stranger expired it: the seller has the crypto back and the LP\'s credit is free');
  info('LP disputes lost', String(lpRecord[3]));

  console.log('\n  \x1b[1mShielded balance out; BRL in the seller\'s bank account, or their bill paid - each payout proven from the LP\'s own bank session.\x1b[0m');
  console.log('  The sale links an address to a bank account - never a shielded deposit - and no dispute outlives its timeout.\n');
}

main().catch((e) => { console.error('\nfailed:', e.shortMessage ?? e.message ?? e); process.exit(1); });
