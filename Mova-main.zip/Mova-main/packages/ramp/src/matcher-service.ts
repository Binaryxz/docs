/**
 * The matching service the protocol runs (task 2.4).
 *
 * ## What this service is forbidden to do
 *
 * It has no private key, holds no funds, and writes nothing to the chain. Grep it for a
 * signer and you will not find one, by construction rather than by policy. Its entire job
 * is: keep a view of the order book rebuilt from chain events, and answer "given what you
 * want, which offers should you take, and what will they cost you".
 *
 * The taker then locks the order themselves. That single boundary is what stops a matching
 * service from becoming an unlicensed exchange, and it is why the interesting failure modes
 * here are boring: a matcher that lies routes you to a worse price, and a matcher that dies
 * stops answering. Neither can move a wei.
 *
 * ## Quotes are advice with a shelf life
 *
 * Every quote carries the block it was computed at and a short validity. A price that was
 * sane one block ago may be outside the escrow's oracle band now, and the escrow re-checks
 * at lock time regardless - so a stale quote fails on-chain rather than settling wrongly.
 * Stamping the block makes that visible to the caller instead of surprising them.
 */
import { createServer, type Server, type IncomingMessage, type ServerResponse } from 'node:http';
import { parseAbi, type Address, type PublicClient } from 'viem';
import { matchOrder, type MatchRequest, type Offer } from './orderbook.js';
import { OrderBookIndexer, type IndexerConfig } from './indexer.js';
import { redact } from '@mova/ops/redact';
import { Rail } from './attestor.js';
import { CorsPolicy } from './cors.js';

export interface MatcherOptions extends IndexerConfig {
  /** Seconds a quote should be considered usable. Advisory; the escrow is the authority. */
  quoteTtlSeconds?: number;
  /**
   * Values that must never appear in a response, typically the RPC URL. URLs are cut to
   * scheme and host regardless; this also catches the configured value in any other form.
   */
  redactValues?: readonly string[];
  /** How often to fold in new events, ms. */
  pollMs?: number;
  /**
   * The Privacy Pools Entrypoint the escrow delivers SHIELDED orders into. With it, a quote asked
   * for `delivery=shielded` never contains a leg below the asset pool's minimum deposit (SR2-27),
   * and is refused for an asset with no pool. Without it, shielded quotes are refused outright:
   * a matcher that cannot see the minimum would quote legs that lock and never settle.
   */
  entrypoint?: Address;
  /**
   * Tokens whose issuer keeps a blacklist readable as `isBlackListed(address)` - USDT. An offer
   * from a listed LP stays open on-chain but its USDT is frozen, so taking it is at best a wasted
   * pay window (SR2-24). Such offers are left out of the book.
   */
  blacklistTokens?: Address[];
  /**
   * Browser origins allowed to read this service's answers (cors.ts): exact `scheme://host[:port]`
   * values, `*` and `null` refused. Default none - no CORS headers, and every preflight 403. Every
   * route is a public GET, so a preflight is answered for GET alone.
   */
  allowedOrigins?: readonly string[];
}

const ENTRYPOINT_ABI = parseAbi([
  'function assetConfig(address asset) view returns (address pool, uint256 minimumDepositAmount, uint256 vettingFeeBPS, uint256 maxRelayFeeBPS)',
]);
const BLACKLIST_ABI = parseAbi(['function isBlackListed(address who) view returns (bool)']);
/** How the Entrypoint names native ETH; the escrow names it address(0). */
const ENTRYPOINT_NATIVE = '0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE';
const ZERO = '0x0000000000000000000000000000000000000000';

export interface Quote {
  asset: string;
  requested: string;
  filled: string;
  unfilled: string;
  totalBrlCents: string;
  /** Present on a shielded quote: the smallest leg the pool accepts, which no fill is below. */
  minimumLeg?: string;
  fills: {
    offerId: string;
    lp: string;
    asset: string;
    amount: string;
    priceBrlCentsPerUnit: string;
    brlCents: string;
    rails: number[];
  }[];
  atBlock: string;
  expiresAt: number;
}

export class MatcherService {
  private readonly indexer: OrderBookIndexer;
  private readonly ttl: number;
  private readonly pollMs: number;
  private readonly client: PublicClient;
  private book: Offer[] = [];
  /** Per asset (lowercase), the pool minimum for shielded delivery; null when the asset has no pool. */
  private shieldedMinimum = new Map<string, bigint | null>();
  private timer?: ReturnType<typeof setInterval>;
  private server?: Server;
  private lastSyncError?: string;
  private readonly cors: CorsPolicy;

  constructor(private readonly opts: MatcherOptions) {
    // First, so a malformed origin fails here rather than when the first browser asks.
    this.cors = new CorsPolicy({ allowedOrigins: opts.allowedOrigins ?? [] });
    this.indexer = new OrderBookIndexer(opts);
    this.ttl = opts.quoteTtlSeconds ?? 30;
    this.pollMs = opts.pollMs ?? 5_000;
    this.client = opts.client;
  }

  /** Fold in new events and refresh the cached book. */
  async refresh(): Promise<void> {
    try {
      await this.indexer.sync();
      const book = await this.indexer.book();
      const [minimums, frozen] = await Promise.all([this.readMinimums(book), this.readBlacklisted(book)]);
      this.book = frozen.size ? book.filter((o) => !frozen.has(`${o.asset.toLowerCase()}:${o.lp.toLowerCase()}`)) : book;
      this.shieldedMinimum = minimums;
      this.lastSyncError = undefined;
    } catch (e) {
      // Keep serving the last good book rather than going dark: a stale book produces
      // quotes the escrow will reject, which is recoverable; no book at all is an outage.
      // `/health` reports the failure so this cannot hide - redacted, because `/health` is
      // public and a viem transport error carries the RPC URL, API key and all.
      this.lastSyncError = redact((e as Error).message, this.opts.redactValues);
    }
  }

  private async readMinimums(book: Offer[]): Promise<Map<string, bigint | null>> {
    const out = new Map<string, bigint | null>();
    const entrypoint = this.opts.entrypoint;
    if (!entrypoint) return out;
    const assets = [...new Set(book.map((o) => o.asset.toLowerCase()))];
    await Promise.all(assets.map(async (asset) => {
      const [pool, minimum] = await this.client.readContract({
        address: entrypoint, abi: ENTRYPOINT_ABI, functionName: 'assetConfig',
        args: [(asset === ZERO ? ENTRYPOINT_NATIVE : asset) as Address],
      });
      out.set(asset, pool.toLowerCase() === ZERO ? null : minimum);
    }));
    return out;
  }

  private async readBlacklisted(book: Offer[]): Promise<Set<string>> {
    const out = new Set<string>();
    const tokens = new Set((this.opts.blacklistTokens ?? []).map((t) => t.toLowerCase()));
    const pairs = [...new Set(book.filter((o) => tokens.has(o.asset.toLowerCase()))
      .map((o) => `${o.asset.toLowerCase()}:${o.lp.toLowerCase()}`))];
    await Promise.all(pairs.map(async (pair) => {
      const [token, lp] = pair.split(':') as [Address, Address];
      if (await this.client.readContract({ address: token, abi: BLACKLIST_ABI, functionName: 'isBlackListed', args: [lp] })) {
        out.add(pair);
      }
    }));
    return out;
  }

  /** The smallest leg a shielded order in `asset` can settle, or why none can be quoted. */
  shieldedMinimumFor(asset: string): { minimum: bigint } | { refused: string } {
    if (!this.opts.entrypoint) return { refused: 'this matcher has no Privacy Pools entrypoint configured, so it cannot quote shielded delivery' };
    const m = this.shieldedMinimum.get(asset.toLowerCase());
    if (m === null) return { refused: 'the Privacy Pools entrypoint has no pool for this asset: shielded delivery cannot settle' };
    // An asset with no offers is not in the map yet; there is nothing to match anyway.
    return { minimum: m ?? 0n };
  }

  quote(req: MatchRequest, maxFills = 3): Quote {
    const m = matchOrder(this.book, req, maxFills);
    return {
      asset: req.asset,
      requested: req.weiWanted.toString(),
      filled: m.filledWei.toString(),
      unfilled: m.unfilledWei.toString(),
      totalBrlCents: m.totalBrlCents.toString(),
      ...(req.minFillWei !== undefined ? { minimumLeg: req.minFillWei.toString() } : {}),
      fills: m.fills.map((f) => ({
        offerId: f.offerId,
        lp: f.lp,
        asset: f.asset,
        amount: f.weiAmount.toString(),
        priceBrlCentsPerUnit: f.priceBrlCentsPerEth.toString(),
        brlCents: f.brlCents.toString(),
        rails: f.rails,
      })),
      atBlock: this.indexer.lastIndexedBlock.toString(),
      expiresAt: Math.floor(Date.now() / 1000) + this.ttl,
    };
  }

  /** @param host the address to bind; all interfaces when omitted (a container publishing its port needs that) */
  async listen(port = 0, host?: string): Promise<number> {
    await this.refresh();
    this.timer = setInterval(() => void this.refresh(), this.pollMs);
    this.timer.unref?.();

    this.server = createServer((rq, rs) => void this.handle(rq, rs));
    await new Promise<void>((res) => (host ? this.server!.listen(port, host, res) : this.server!.listen(port, res)));
    const addr = this.server.address();
    return typeof addr === 'object' && addr ? addr.port : port;
  }

  async close(): Promise<void> {
    if (this.timer) clearInterval(this.timer);
    if (this.server) await new Promise<void>((res) => this.server!.close(() => res()));
  }

  private async handle(rq: IncomingMessage, rs: ServerResponse): Promise<void> {
    const url = new URL(rq.url ?? '/', 'http://localhost');
    const origin = rq.headers.origin;
    if (rq.method === 'OPTIONS') {
      const p = this.cors.preflight(origin, ['GET']);
      rs.writeHead(p.status, p.headers);
      rs.end();
      return;
    }
    const send = (code: number, body: unknown) => {
      rs.writeHead(code, { 'content-type': 'application/json', ...this.cors.responseHeaders(origin) });
      rs.end(JSON.stringify(body, null, 2));
    };

    try {
      if (url.pathname === '/health') {
        // Report the sync failure rather than a bare "ok": a matcher quoting from a book it
        // stopped being able to refresh looks healthy from the outside and is not.
        return send(this.lastSyncError ? 503 : 200, {
          ok: !this.lastSyncError,
          offers: this.book.length,
          atBlock: this.indexer.lastIndexedBlock.toString(),
          syncError: this.lastSyncError ?? null,
        });
      }

      if (url.pathname === '/offers') {
        return send(200, {
          atBlock: this.indexer.lastIndexedBlock.toString(),
          offers: this.book.map((o) => ({
            offerId: o.offerId, lp: o.lp, asset: o.asset, decimals: o.decimals,
            available: o.availableWei.toString(),
            priceBrlCentsPerUnit: o.priceBrlCentsPerEth.toString(),
            min: o.minOrderWei.toString(), max: o.maxOrderWei.toString(),
            verifier: o.verifier, rails: o.rails, tier: o.tier,
            settledCents: o.settledCents.toString(), disputesLost: o.disputesLost,
          })),
        });
      }

      if (url.pathname === '/quote') {
        const asset = url.searchParams.get('asset');
        const amount = url.searchParams.get('amount');
        if (!asset || !amount) return send(400, { error: 'asset and amount are required' });
        let weiWanted: bigint;
        try {
          weiWanted = BigInt(amount);
        } catch {
          return send(400, { error: 'amount must be an integer in the asset\'s smallest unit' });
        }
        if (weiWanted <= 0n) return send(400, { error: 'amount must be positive' });

        const rails = url.searchParams.get('rails');
        const req: MatchRequest = {
          asset,
          weiWanted,
          rails: rails ? rails.split(',').map((r) => Number(r) as Rail) : undefined,
          requireInstitutional: url.searchParams.get('institutional') === 'true',
          maxPriceBrlCentsPerEth: url.searchParams.get('maxPrice')
            ? BigInt(url.searchParams.get('maxPrice')!)
            : undefined,
        };
        const delivery = url.searchParams.get('delivery') ?? 'direct';
        if (delivery !== 'direct' && delivery !== 'shielded') return send(400, { error: 'delivery must be direct or shielded' });
        if (delivery === 'shielded') {
          const s = this.shieldedMinimumFor(asset);
          if ('refused' in s) return send(400, { error: s.refused });
          req.minFillWei = s.minimum;
        }
        return send(200, this.quote(req, Number(url.searchParams.get('maxFills') ?? 3)));
      }

      send(404, { error: 'not found', routes: ['/health', '/offers', '/quote'] });
    } catch (e) {
      send(500, { error: redact((e as Error).message, this.opts.redactValues) });
    }
  }
}
