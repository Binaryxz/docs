/**
 * Build Reclaim-format zkTLS proofs, and encode them for ReclaimZkTlsVerifier (task 2.2).
 *
 * ## What this is, and what a real deployment replaces
 *
 * In production the claim comes from Reclaim's attestor network: a client opens a TLS
 * session with the bank, witnesses observe the encrypted transcript, and they sign a claim
 * about what the response contained without ever seeing the plaintext. This module builds
 * and encodes that claim structure, and `signAsWitness` stands in for the witness network
 * so the whole path can be exercised without one.
 *
 * The distinction matters and should not be blurred: the ENCODING here is production code -
 * it must match the verifier and the Reclaim network byte for byte or nothing verifies. The
 * witness SIGNING and the witness-written context fields are a stand-in, in the same way
 * `PasskeyAuthenticator` stands in for a real authenticator in Phase 1.
 *
 * ## Who writes what, which is the security property
 *
 * The shapes follow Reclaim's attestor-core, not our reader:
 *
 *  - `identifier = keccak(provider \n parameters \n canonical(context))`.
 *  - The witness, not the prover, writes two context fields before signing:
 *    `providerHash = hashProviderParams(params)` (the bank endpoint's template) and
 *    `extractedParameters` (what the template's regexes captured from the bank's RESPONSE).
 *  - The prover writes only `contextAddress` / `contextMessage`; the order id is the
 *    `contextMessage`, which is how a proof is bound to one order.
 *
 * An earlier version of this file put the payment fields into the context itself, at
 * session-request time - i.e. the payer declared what they paid - and the verifier checked a
 * provider string that is `"http"` for every Reclaim claim. See docs/security-review-phase2.md,
 * SR2-11. The verifier now allowlists the endpoint and reads only witness-written fields.
 */
import {
  decodeAbiParameters, encodeAbiParameters, keccak256, toBytes, toHex, hashMessage, recoverAddress,
  type Hex, type Address,
} from 'viem';
import { privateKeyToAccount } from 'viem/accounts';
import { Rail, pixKeyCommitment } from './attestor.js';
import { boletoCommitment, parseBoleto } from './boleto.js';

export interface ClaimInfo {
  provider: string;
  parameters: string;
  context: string;
}

export interface CompleteClaimData {
  identifier: Hex;
  owner: Address;
  timestampS: number;
  epoch: number;
}

export interface ReclaimProof {
  claimInfo: ClaimInfo;
  signedClaim: { claim: CompleteClaimData; signatures: Hex[] };
}

export interface PaymentContext {
  /**
   * What the proof is bound to, as `contextMessage`: the order id on the on-ramp, the sale id on the
   * off-ramp - each escrow passes its own id to `verifyPayment` (FiatEscrow.releaseWithProof,
   * OffRampEscrow.settleWithProof), and the verifier compares it with this.
   */
  orderId: Hex;
  bankTxId: Hex;
  payeeKeyHash: Hex;
  payerRef: Hex;
  amountBrlCents: bigint;
  paidAt: bigint;
  rail: Rail;
}

/** The only Reclaim provider the verifier accepts. */
export const HTTP_PROVIDER = 'http';

/** The fields the verifier reads out of `extractedParameters`, all required. */
export const EXTRACTED_FIELDS = [
  'amountBrlCents', 'bankTxId', 'paidAt', 'payeeKeyHash', 'payerRef', 'rail',
] as const;

/** An HTTP provider's parameters, as far as the provider hash and the verifier care. */
export interface HttpProviderParams {
  url: string;
  method: string;
  body?: string;
  responseMatches: { type: string; value: string; invert?: boolean }[];
  responseRedactions?: { xPath?: string; jsonPath?: string; regex?: string; hash?: string }[];
  paramValues?: Record<string, string>;
  [extra: string]: unknown;
}

/**
 * JSON with sorted keys and no whitespace, as attestor-core's `canonicalStringify` (RFC 8785)
 * writes it. The witness canonicalises the context before hashing it into the identifier, so
 * a context that is not in this form cannot match a genuine signature.
 */
export function canonicalStringify(value: unknown): string {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) {
    return `[${value.map((v) => (v === undefined ? 'null' : canonicalStringify(v))).join(',')}]`;
  }
  const entries = Object.entries(value as Record<string, unknown>)
    .filter(([, v]) => v !== undefined)
    .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0));
  return `{${entries.map(([k, v]) => `${JSON.stringify(k)}:${canonicalStringify(v)}`).join(',')}}`;
}

/**
 * Reclaim's provider hash: keccak256 of the canonical endpoint TEMPLATE.
 *
 * Mirrors attestor-core `hashProviderParams`: url (placeholders unsubstituted), method, body,
 * and the match and redaction rules - not `paramValues`, which vary per session. This is the
 * value the governor allowlists in ReclaimZkTlsVerifier, next to the URL prefix.
 */
export function hashProviderParams(params: HttpProviderParams): Hex {
  const filtered = {
    url: params.url,
    method: params.method,
    body: params.body ?? '',
    responseMatches: params.responseMatches.map((m) => ({
      value: m.value, type: m.type, invert: m.invert || undefined,
    })),
    responseRedactions: (params.responseRedactions ?? []).map((r) => ({
      xPath: r.xPath ?? '', jsonPath: r.jsonPath ?? '', regex: r.regex ?? '', hash: r.hash || undefined,
    })),
  };
  return keccak256(toBytes(canonicalStringify(filtered)));
}

const b32 = (v: Hex): Hex => {
  const s = v.toLowerCase();
  if (!/^0x[0-9a-f]{64}$/.test(s)) throw new Error(`not a 32-byte hex value: ${v}`);
  return s as Hex;
};

/**
 * What a client asks Reclaim to bind into the proof when it requests a session: the order
 * id, and nothing about the payment. The payment is the bank's to say.
 *
 * On the off-ramp the id is the SALE's: an LP proving the PIX it sent a seller, or the bill it
 * paid, binds the proof to the sale it settles, and a proof bound to one sale settles no other
 * sale and no order.
 */
export function bindingContext(orderId: Hex): { contextAddress: Address; contextMessage: Hex } {
  return {
    contextAddress: '0x0000000000000000000000000000000000000000',
    contextMessage: b32(orderId),
  };
}

/**
 * The payment context of a BOLETO receipt, from what the bank's receipt shows.
 *
 * The verifier reads the same six fields for every rail, so a boleto receipt is not a new
 * format - it is a different endpoint template (allowlisted for BOLETO, see
 * `ReclaimZkTlsVerifier.setEndpointRails`) whose extraction yields:
 *
 *  - `payeeKeyHash`: the salted commitment to the barcode of the document paid, which is what
 *    the escrow compares with the boleto issued for the order or the bill a sale names;
 *  - `bankTxId`: the payment's authentication code, hashed;
 *  - `amountBrlCents`: what was paid, which must equal the order exactly;
 *  - `rail`: 2.
 *
 * Like PIX, a bank does not print a salted commitment, so a production template needs
 * Reclaim's hashed redactions over the barcode (or a verifier revision) - the same gap the
 * security review records for PIX keys. It can fail to settle; it cannot settle wrongly. This
 * builds the values a witness would extract, from the line as the receipt shows it, and
 * refuses a line that is not a valid boleto or an amount the line does not carry.
 */
export function boletoPaymentContext(args: {
  orderId: Hex;
  bankTxId: Hex;
  /** The paid document's line or barcode, as the receipt shows it. */
  line: string;
  salt: Hex;
  payerRef: Hex;
  amountBrlCents: bigint;
  paidAt: bigint;
}): PaymentContext {
  const boleto = parseBoleto(args.line);
  if (boleto.amountCents !== args.amountBrlCents) {
    throw new ReclaimProofError(
      `the receipt says ${args.amountBrlCents} was paid for a boleto of ${boleto.amountCents ?? 'no amount'}`,
    );
  }
  return {
    orderId: args.orderId,
    bankTxId: args.bankTxId,
    payeeKeyHash: boletoCommitment(boleto, args.salt),
    payerRef: args.payerRef,
    amountBrlCents: args.amountBrlCents,
    paidAt: args.paidAt,
    rail: Rail.BOLETO,
  };
}

/**
 * The payment context of a PIX receipt, from what the bank's receipt shows.
 *
 * `payeeKeyHash` is the salted commitment to the key the page shows credited (on the on-ramp, the
 * LP's own key; on the off-ramp, the seller's), recomputed here from the key and the salt that opens
 * the offer's or sale's commitment - never a commitment someone handed over. `bankTxId` is the
 * end-to-end id, hashed as the escrow burns it. As for boletos, a real bank page shows neither the
 * salted commitment nor `payerRef`, so a production template needs hashed redactions; this builds
 * the values a witness would extract, and refuses a key that is not a PIX key.
 */
export function pixPaymentContext(args: {
  orderId: Hex;
  bankTxId: Hex;
  /** The key the receipt shows credited, in any format the DICT accepts. */
  pixKey: string;
  salt: Hex;
  payerRef: Hex;
  amountBrlCents: bigint;
  paidAt: bigint;
}): PaymentContext {
  let payeeKeyHash: Hex;
  try {
    payeeKeyHash = pixKeyCommitment(args.pixKey, args.salt);
  } catch (e) {
    throw new ReclaimProofError(`the receipt's key does not make a commitment: ${(e as Error).message}`);
  }
  return {
    orderId: args.orderId,
    bankTxId: args.bankTxId,
    payeeKeyHash,
    payerRef: args.payerRef,
    amountBrlCents: args.amountBrlCents,
    paidAt: args.paidAt,
    rail: Rail.PIX,
  };
}

/** The extracted-parameter values in the formats the on-chain reader accepts. */
export function extractedParameters(c: PaymentContext): Record<(typeof EXTRACTED_FIELDS)[number], string> {
  return {
    amountBrlCents: c.amountBrlCents.toString(),
    bankTxId: b32(c.bankTxId),
    paidAt: c.paidAt.toString(),
    payeeKeyHash: b32(c.payeeKeyHash),
    payerRef: b32(c.payerRef),
    rail: String(c.rail),
  };
}

/**
 * The context as a witness leaves it after the session: the prover's binding, plus the
 * `extractedParameters` and `providerHash` the witness wrote. Canonical, as signed.
 *
 * Only a test stand-in may call this with payment values it chose; in production those
 * values come out of the bank's TLS response.
 */
export function buildContext(c: PaymentContext, providerHash: Hex): string {
  return canonicalStringify({
    ...bindingContext(c.orderId),
    extractedParameters: extractedParameters(c),
    providerHash: b32(providerHash),
  });
}

/** Reclaim's claim identifier. Must match the verifier's recomputation exactly. */
export function claimIdentifier(info: ClaimInfo): Hex {
  return keccak256(toBytes(`${info.provider}\n${info.parameters}\n${info.context}`));
}

/** Reclaim's canonical claim serialisation: identifier\nowner\ntimestamp\nepoch. */
export function serialiseClaim(c: CompleteClaimData): string {
  return [c.identifier.toLowerCase(), c.owner.toLowerCase(), c.timestampS, c.epoch].join('\n');
}

/** The digest a Reclaim witness signs: EIP-191 over the serialised claim string itself. */
export function claimDigest(c: CompleteClaimData): Hex {
  return hashMessage(serialiseClaim(c));
}

/**
 * Sign a claim as a witness would.
 *
 * EIP-191 personal-sign over the serialised claim STRING, as attestor-core's
 * `signatures.sign(strToUint8Array(createSignDataForClaim(...)))` and Reclaim's own
 * Claims.sol `verifySignature` do. An earlier version signed `keccak(serialised)` instead,
 * and its comment insisted that was the right double hash; no real witness signature would
 * ever have verified against it.
 */
export async function signAsWitness(privateKey: Hex, claim: CompleteClaimData): Promise<Hex> {
  return privateKeyToAccount(privateKey).signMessage({ message: serialiseClaim(claim) });
}

/** Assemble a proof as the network would return it. Signatures sorted by signer. */
export async function buildProof(args: {
  params: HttpProviderParams;
  payment: PaymentContext;
  witnessKeys: Hex[];
  owner: Address;
  timestampS?: number;
  epoch?: number;
}): Promise<ReclaimProof> {
  const claimInfo: ClaimInfo = {
    provider: HTTP_PROVIDER,
    parameters: canonicalStringify(args.params),
    context: buildContext(args.payment, hashProviderParams(args.params)),
  };
  const claim: CompleteClaimData = {
    identifier: claimIdentifier(claimInfo),
    owner: args.owner,
    timestampS: args.timestampS ?? Math.floor(Date.now() / 1000),
    epoch: args.epoch ?? 1,
  };

  const signed = await Promise.all(
    args.witnessKeys.map(async (k) => ({
      signer: BigInt(privateKeyToAccount(k).address),
      signature: await signAsWitness(k, claim),
    })),
  );
  signed.sort((a, b) => (a.signer < b.signer ? -1 : 1));

  return { claimInfo, signedClaim: { claim, signatures: signed.map((s) => s.signature) } };
}

const PROOF_ABI = [{
  type: 'tuple',
  components: [
    {
      name: 'claimInfo', type: 'tuple', components: [
        { name: 'provider', type: 'string' },
        { name: 'parameters', type: 'string' },
        { name: 'context', type: 'string' },
      ],
    },
    {
      name: 'signedClaim', type: 'tuple', components: [
        {
          name: 'claim', type: 'tuple', components: [
            { name: 'identifier', type: 'bytes32' },
            { name: 'owner', type: 'address' },
            { name: 'timestampS', type: 'uint32' },
            { name: 'epoch', type: 'uint32' },
          ],
        },
        { name: 'signatures', type: 'bytes[]' },
      ],
    },
  ],
}] as const;

/** ABI-encode for `verifyPayment(bytes32, bytes)`. */
export function encodeProof(p: ReclaimProof): Hex {
  return encodeAbiParameters(PROOF_ABI, [{
    claimInfo: p.claimInfo,
    signedClaim: {
      claim: {
        identifier: p.signedClaim.claim.identifier,
        owner: p.signedClaim.claim.owner,
        timestampS: p.signedClaim.claim.timestampS,
        epoch: p.signedClaim.claim.epoch,
      },
      signatures: p.signedClaim.signatures,
    },
  }] as never);
}

/** The proof back from `encodeProof` bytes, as `verifyPayment` decodes them. Throws on anything else. */
export function decodeProof(bytes: Hex): ReclaimProof {
  const [p] = decodeAbiParameters(PROOF_ABI, bytes) as unknown as [{
    claimInfo: ClaimInfo;
    signedClaim: { claim: CompleteClaimData; signatures: readonly Hex[] };
  }];
  return {
    claimInfo: { provider: p.claimInfo.provider, parameters: p.claimInfo.parameters, context: p.claimInfo.context },
    signedClaim: {
      claim: {
        identifier: p.signedClaim.claim.identifier,
        owner: p.signedClaim.claim.owner,
        timestampS: Number(p.signedClaim.claim.timestampS),
        epoch: Number(p.signedClaim.claim.epoch),
      },
      signatures: [...p.signedClaim.signatures],
    },
  };
}

/*//////////////////////////////////////////////////////////////
                         RECEIPT TEMPLATES
//////////////////////////////////////////////////////////////*/

/**
 * The four bank pages a ramp payment is proven from.
 *
 * Whoever holds the bank data proves: the LP, on both ramps (packages/lp-node, zktls.ts), and a taker
 * proving their own payment from their own bank. What the page shows differs by direction and rail:
 *
 *  - `pix-received`: a PIX credited to the account - the on-ramp LP's credit from a taker;
 *  - `pix-sent`: a PIX the account sent - the off-ramp LP's payout to a seller, or a taker's payment;
 *  - `boleto-received`: a boleto the account issued, paid - the on-ramp LP's registered boleto;
 *  - `boleto-paid`: a bill the account paid - the off-ramp LP paying a seller's boleto.
 *
 * Each is its own provider template, allowlisted on ReclaimZkTlsVerifier with its own rail mask:
 * the PIX pages for PIX alone (the default), the boleto pages widened to BOLETO with
 * `setEndpointRails`, so no page can vouch for the other rail's payments.
 */
export type ReceiptKind = 'pix-received' | 'pix-sent' | 'boleto-received' | 'boleto-paid';

export const RECEIPT_KINDS: readonly ReceiptKind[] = ['pix-received', 'pix-sent', 'boleto-received', 'boleto-paid'];

/** The rail a receipt page attests. */
export const receiptRail = (kind: ReceiptKind): Rail.PIX | Rail.BOLETO => (kind.startsWith('pix') ? Rail.PIX : Rail.BOLETO);

/** The page for a payment: `received` into the account proving it, or sent (paid) out of it. */
export function receiptKind(rail: Rail, direction: 'received' | 'sent'): ReceiptKind {
  if (rail === Rail.PIX) return direction === 'received' ? 'pix-received' : 'pix-sent';
  if (rail === Rail.BOLETO) return direction === 'received' ? 'boleto-received' : 'boleto-paid';
  throw new ReclaimProofError(`no bank receipt page proves a ${Rail[rail] ?? `rail ${rail}`} payment: zkTLS proves PIX and boleto`);
}

/** The rail mask to allowlist a receipt page's template for (`ReclaimZkTlsVerifier.setEndpointRails`). */
export const receiptRailMask = (kind: ReceiptKind): number => 1 << receiptRail(kind);

const RECEIPT_PATHS: Record<ReceiptKind, string> = {
  'pix-received': 'pix/received',
  'pix-sent': 'pix/sent',
  'boleto-received': 'boletos/received',
  'boleto-paid': 'boletos/paid',
};

/**
 * A receipt page's provider template, at `urlPrefix`: the shape the local witnesses, the tests and
 * the live examples allowlist and prove against.
 *
 * It is ILLUSTRATIVE in the way the zktls-onramp example's template is: a real one comes from Reclaim
 * for a real bank's page, and must capture every field the verifier reads from the part of the
 * response the bank writes. What this one does get right, and a real one must too: it captures all
 * six fields, and its `rail` capture matches only its own rail's digit, so a PIX page's template
 * cannot extract a boleto payment even from a response that says so. `urlPrefix` is what the
 * verifier allowlists beside the template's hash: `https://` + a lowercase host + `/`, ending in `/`.
 */
export function receiptTemplate(urlPrefix: string, kind: ReceiptKind): HttpProviderParams {
  if (!/^https:\/\/[a-z0-9.-]+(:[0-9]+)?\/([A-Za-z0-9._~-]+\/)*$/.test(urlPrefix)) {
    throw new ReclaimProofError(
      `receipt url prefix ${urlPrefix} is not https://<lowercase host>/[path/]: the verifier would refuse to allowlist it`,
    );
  }
  return {
    url: `${urlPrefix}${RECEIPT_PATHS[kind]}/{{receiptId}}`,
    method: 'GET',
    body: '',
    responseMatches: [
      { type: 'regex', value: '"amountBrlCents":"(?<amountBrlCents>[0-9]+)"' },
      { type: 'regex', value: '"bankTxId":"(?<bankTxId>0x[0-9a-f]{64})"' },
      { type: 'regex', value: '"settledAt":"(?<paidAt>[0-9]+)"' },
      { type: 'regex', value: '"payeeKeyHash":"(?<payeeKeyHash>0x[0-9a-f]{64})"' },
      { type: 'regex', value: '"payerRef":"(?<payerRef>0x[0-9a-f]{64})"' },
      { type: 'regex', value: `"rail":"(?<rail>${receiptRail(kind)})"` },
    ],
    responseRedactions: [{ jsonPath: '$.receipt', regex: '', xPath: '' }],
  };
}

/** Every receipt page's template at one prefix, by kind. */
export function receiptTemplates(urlPrefix: string): Record<ReceiptKind, HttpProviderParams> {
  return Object.fromEntries(RECEIPT_KINDS.map((k) => [k, receiptTemplate(urlPrefix, k)])) as Record<ReceiptKind, HttpProviderParams>;
}

/*//////////////////////////////////////////////////////////////
                   THE REAL RECLAIM NETWORK
//////////////////////////////////////////////////////////////*/

/**
 * A proof as the Reclaim SDK / app emits it.
 *
 * Deliberately typed here rather than imported from `@reclaimprotocol/js-sdk`. The only
 * thing we need from them is a JSON shape, and taking a dependency to obtain a type would
 * add a package - and its transitive tree - to the supply chain of a contract-facing
 * repository that currently pins every dependency it has. If their shape changes,
 * `fromReclaimProof` throws on a missing field rather than a version bump silently altering
 * what gets verified on-chain.
 */
export interface ReclaimSdkProof {
  identifier: string;
  claimData: {
    provider: string;
    parameters: string;
    owner: string;
    timestampS: number;
    context: string;
    identifier: string;
    epoch: number;
  };
  signatures: string[];
  witnesses?: { id: string; url?: string }[];
}

export class ReclaimProofError extends Error {}

const parseObject = (s: string, what: string): Record<string, unknown> => {
  let v: unknown;
  try {
    v = JSON.parse(s);
  } catch {
    throw new ReclaimProofError(`${what} is not JSON`);
  }
  if (!v || typeof v !== 'object' || Array.isArray(v)) {
    throw new ReclaimProofError(`${what} is not a JSON object`);
  }
  return v as Record<string, unknown>;
};

/**
 * Convert a genuine Reclaim proof into the form ReclaimZkTlsVerifier accepts.
 *
 * This is the seam between their network and our escrow, and it is written to fail loudly
 * rather than pass something through unchecked. Every check here is one the verifier makes
 * too; failing here says why in one line instead of costing a reverted settlement:
 *
 *  - the provider is `http`, and the context is in the canonical form the witness hashed;
 *  - the identifier is RECOMPUTED and compared against the one supplied;
 *  - `parameters` carries a string `url`, and the context carries a `providerHash`, a
 *    32-byte `contextMessage` (the order binding) and every extracted field the escrow reads.
 *
 * What this does NOT do is decide whether the witnesses or the endpoint are trustworthy.
 * Those are `ReclaimZkTlsVerifier`'s witness set and endpoint allowlist, governed on-chain -
 * see `assertEndpointAllowed` and `assertWitnessesRegistered` in reclaim-client.ts.
 */
export function fromReclaimProof(p: ReclaimSdkProof): ReclaimProof {
  for (const field of ['provider', 'parameters', 'context', 'owner'] as const) {
    if (!p.claimData?.[field]) throw new ReclaimProofError(`claimData.${field} is missing`);
  }
  if (!Array.isArray(p.signatures) || p.signatures.length === 0) {
    throw new ReclaimProofError('proof carries no witness signatures');
  }
  if (p.claimData.provider !== HTTP_PROVIDER) {
    throw new ReclaimProofError(`provider is "${p.claimData.provider}"; only "http" claims can settle`);
  }

  const claimInfo: ClaimInfo = {
    provider: p.claimData.provider,
    parameters: p.claimData.parameters,
    context: p.claimData.context,
  };
  const recomputed = claimIdentifier(claimInfo);
  const claimed = (p.claimData.identifier ?? p.identifier ?? '').toLowerCase();
  if (claimed && recomputed.toLowerCase() !== claimed) {
    throw new ReclaimProofError(
      `identifier does not match its claim data: recomputed ${recomputed}, proof says ${claimed}`,
    );
  }

  const ctx = parseObject(p.claimData.context, 'context');
  if (canonicalStringify(ctx) !== p.claimData.context) {
    throw new ReclaimProofError('context is not canonical JSON; the witness signed the canonical form');
  }
  const params = parseObject(p.claimData.parameters, 'parameters');
  if (typeof params.url !== 'string') {
    throw new ReclaimProofError('parameters has no url; the verifier checks the bank endpoint');
  }
  for (const key of ['providerHash', 'contextMessage'] as const) {
    if (typeof ctx[key] !== 'string' || !/^0x[0-9a-f]{64}$/i.test(ctx[key] as string)) {
      throw new ReclaimProofError(`context has no 32-byte "${key}"; the verifier reads it`);
    }
  }
  const extracted = ctx.extractedParameters as Record<string, unknown> | undefined;
  for (const key of EXTRACTED_FIELDS) {
    if (!extracted || typeof extracted[key] !== 'string') {
      throw new ReclaimProofError(
        `context.extractedParameters has no "${key}"; the escrow reads it and would revert on-chain`,
      );
    }
  }

  return {
    claimInfo,
    signedClaim: {
      claim: {
        identifier: recomputed,
        owner: p.claimData.owner as Address,
        timestampS: p.claimData.timestampS,
        epoch: p.claimData.epoch,
      },
      // Sorted by recovered signer is enforced on-chain; the SDK does not guarantee order,
      // so sorting is done by whoever assembles the proof - see sortSignatures.
      signatures: p.signatures as Hex[],
    },
  };
}

/**
 * The payment a proof attests, read the way the verifier reads it: from the witness-written
 * `extractedParameters`, never from anything else in the context.
 */
export function proofPayment(proof: ReclaimProof): Omit<PaymentContext, 'orderId'> & { orderId: Hex } {
  const ctx = parseObject(proof.claimInfo.context, 'context');
  const x = ctx.extractedParameters as Record<string, unknown> | undefined;
  const field = (k: (typeof EXTRACTED_FIELDS)[number]) => {
    if (!x || typeof x[k] !== 'string') throw new ReclaimProofError(`context.extractedParameters has no "${k}"`);
    return x[k] as string;
  };
  const rail = Number(field('rail'));
  if (!Number.isInteger(rail) || !(rail in Rail)) throw new ReclaimProofError(`rail "${field('rail')}" is not a Rail`);
  return {
    orderId: String(ctx.contextMessage) as Hex,
    bankTxId: field('bankTxId') as Hex,
    payeeKeyHash: field('payeeKeyHash') as Hex,
    payerRef: field('payerRef') as Hex,
    amountBrlCents: BigInt(field('amountBrlCents')),
    paidAt: BigInt(field('paidAt')),
    rail: rail as Rail,
  };
}

/** The endpoint a proof claims to attest: its template hash and its url, as the chain reads them. */
export function proofEndpoint(proof: ReclaimProof): { providerHash: Hex; url: string } {
  const ctx = parseObject(proof.claimInfo.context, 'context');
  const params = parseObject(proof.claimInfo.parameters, 'parameters');
  return { providerHash: String(ctx.providerHash).toLowerCase() as Hex, url: String(params.url) };
}

/**
 * Sort a real proof's signatures into the strictly-ascending order the verifier requires.
 *
 * The SDK returns them in witness order, which is not signer order. On-chain this surfaces
 * as `SignaturesUnsorted`, an error that describes the symptom and not the cause.
 */
export async function sortSignatures(proof: ReclaimProof): Promise<ReclaimProof> {
  const digest = claimDigest(proof.signedClaim.claim);
  const withSigner = await Promise.all(
    proof.signedClaim.signatures.map(async (signature) => ({
      signature,
      signer: await recoverAddress({ hash: digest, signature }),
    })),
  );
  withSigner.sort((a, b) => (BigInt(a.signer) < BigInt(b.signer) ? -1 : 1));
  return {
    ...proof,
    signedClaim: { ...proof.signedClaim, signatures: withSigner.map((w) => w.signature) },
  };
}

/** Who signed this proof? Lets an operator check a proof against the on-chain witness set. */
export async function proofSigners(proof: ReclaimProof): Promise<Address[]> {
  const digest = claimDigest(proof.signedClaim.claim);
  return Promise.all(
    proof.signedClaim.signatures.map((signature) => recoverAddress({ hash: digest, signature })),
  );
}

export { toHex };
