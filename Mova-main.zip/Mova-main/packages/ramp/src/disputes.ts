/**
 * The off-chain half of dispute resolution (task 2.6).
 *
 * The on-chain half is already in the escrows: a disputed order stops moving, and a signed
 * ruling can send it one of exactly two ways - or, if nobody rules within the escrow's
 * DISPUTE_TIMEOUT, it returns to where it came from. What the chain cannot do is decide WHICH way,
 * because every fact a ramp dispute turns on lives outside the chain - did the PIX arrive,
 * was it reversed, was the boleto ever registered. This module is the part that produces
 * an answer a human can defend and anyone can re-check.
 *
 * ## Three properties, and why each is here
 *
 * 1. **Evidence is committed, not uploaded.** Only a hash goes on-chain and into the case
 *    record. Bank statements carry names, CPFs and account numbers; publishing them to
 *    settle a R$300 argument would be a worse outcome than losing the argument. The
 *    material passes between the parties and the arbitrator, and the commitment proves
 *    afterwards that nobody edited it.
 *
 * 2. **Rulings are signed, and say what they relied on.** A ruling names the evidence
 *    hashes it rests on, so a party can check the arbitrator saw what they submitted and
 *    did not rule on something they never got to answer. An unsigned ruling is an opinion.
 *
 * 3. **Silence has a defined outcome.** Most disputes are not adversarial, they are one
 *    side having gone to bed. Every case has a response deadline and a default ruling that
 *    applies if a party never answers, so a dispute cannot become a way to freeze someone's
 *    money indefinitely by simply not participating. The escrow backs this with a hard
 *    deadline of its own: a desk that never rules still cannot freeze the order past it.
 *
 * This module decides nothing on its own. It builds the case, checks it is well-formed, and
 * produces the signed ruling that ANYONE then submits with `resolveDispute` - usually the party
 * it favours. The escrow posts it on the first submission and executes it on a second one after
 * RULING_DELAY, so the ruling is public before it moves anything (see FiatEscrow.resolveDispute).
 */
import { keccak256, toBytes, encodeAbiParameters, recoverTypedDataAddress, type Hex } from 'viem';
import { privateKeyToAccount } from 'viem/accounts';

export type Side = 'taker' | 'lp' | 'seller';

export interface EvidenceRef {
  /** keccak256 of the material itself. The material never appears here. */
  digest: Hex;
  /** What it is, e.g. "pix-receipt", "bank-statement", "chat-log". Not the content. */
  kind: string;
  /**
   * Which party submitted this.
   *
   * DERIVED from a signature, never declared. It used to be a plain field the caller set,
   * and that quietly defeated the module's main promise: a taker could submit one piece of
   * evidence as themselves and a second labelled as the LP, making `respondedSides` report
   * a contested case. `ruleByDefault` then refuses, the case can never be defaulted, and
   * the escrowed funds stay frozen for as long as the attacker likes - which is exactly the
   * "freeze money by not participating" failure the deadline was there to prevent.
   */
  submittedBy: Side;
  submittedAt: number;
  /** Address that signed the submission. */
  submitter: Hex;
  /** Where the parties can fetch it. Off-chain, access-controlled, not required. */
  uri?: string;
}

/** The on-chain addresses entitled to speak in a case. */
export type Parties = Partial<Record<Side, Hex>>;

export interface Case {
  /** The on-chain order or sale id. One case per disputed record. */
  orderId: Hex;
  escrow: Hex;
  chainId: number;
  leg: 'onramp' | 'offramp';
  raisedBy: Side;
  raisedAt: number;
  reason: string;
  /** After this, a missing response no longer blocks a ruling. Set by desk policy. */
  respondBy: number;
  /** Applied when a party never responds. Always REFUND when opened by the desk. */
  defaultRuling: Ruling['outcome'];
  /**
   * The escrow's own deadline, `disputedAt + DISPUTE_TIMEOUT`, read from the chain. From this
   * second on the escrow accepts no ruling and anyone can expire the dispute to REFUND, so a
   * ruling signed too close to it is a ruling that cannot execute.
   */
  expiresAt: number;
  /**
   * Who may submit evidence. `ArbitrationDesk.open` reads these from the escrow's own
   * storage through an `EscrowReader` (taker and offer LP, or seller and claiming LP), and
   * refuses a request that tries to supply them, so neither the filer nor the desk decides
   * who the parties are.
   */
  parties: Parties;
  evidence: EvidenceRef[];
}

export interface Ruling {
  orderId: Hex;
  escrow: Hex;
  chainId: number;
  /**
   * On the on-ramp: RELEASE pays the taker, REFUND returns liquidity to the LP.
   * On the off-ramp: RELEASE pays the LP, REFUND returns the ETH to the seller.
   * Named by direction rather than by party so one word cannot mean two things.
   */
  outcome: 'RELEASE' | 'REFUND';
  /** Evidence this ruling rests on. Must be a subset of the case's evidence. */
  reliedOn: Hex[];
  rationale: string;
  ruledAt: number;
  /** True when nobody responded and `defaultRuling` was applied. */
  byDefault: boolean;
}

export class DisputeError extends Error {}

export const EVIDENCE_TYPES = {
  Evidence: [
    { name: 'caseId', type: 'string' },
    { name: 'orderId', type: 'bytes32' },
    { name: 'digest', type: 'bytes32' },
    { name: 'kind', type: 'string' },
  ],
} as const;

export const evidenceDomain = (chainId: number, escrow: Hex) => ({
  name: 'PrivacyPoolsBRL-Evidence',
  version: '1',
  chainId,
  verifyingContract: escrow,
});

/** Sign an evidence submission as a party to a case. */
export async function signEvidence(
  privateKey: Hex,
  c: { caseId: string; orderId: Hex; escrow: Hex; chainId: number },
  ev: { digest: Hex; kind: string },
): Promise<Hex> {
  return privateKeyToAccount(privateKey).signTypedData({
    domain: evidenceDomain(c.chainId, c.escrow),
    types: EVIDENCE_TYPES,
    primaryType: 'Evidence',
    message: { caseId: c.caseId, orderId: c.orderId, digest: ev.digest, kind: ev.kind },
  });
}

/** Recover who signed an evidence submission. */
export async function evidenceSigner(
  c: { caseId: string; orderId: Hex; escrow: Hex; chainId: number },
  ev: { digest: Hex; kind: string },
  signature: Hex,
): Promise<Hex> {
  return recoverTypedDataAddress({
    domain: evidenceDomain(c.chainId, c.escrow),
    types: EVIDENCE_TYPES,
    primaryType: 'Evidence',
    message: { caseId: c.caseId, orderId: c.orderId, digest: ev.digest, kind: ev.kind },
    signature,
  });
}

export const RULING_TYPES = {
  Ruling: [
    { name: 'orderId', type: 'bytes32' },
    { name: 'escrow', type: 'address' },
    { name: 'outcome', type: 'string' },
    { name: 'evidenceRoot', type: 'bytes32' },
    { name: 'rationale', type: 'string' },
    { name: 'ruledAt', type: 'uint64' },
    { name: 'byDefault', type: 'bool' },
  ],
} as const;

export const rulingDomain = (chainId: number, escrow: Hex) => ({
  name: 'PrivacyPoolsBRL-Dispute',
  version: '1',
  chainId,
  verifyingContract: escrow,
});

/** Commit to the material without revealing it. */
export function evidenceDigest(material: Uint8Array | string): Hex {
  return keccak256(typeof material === 'string' ? toBytes(material) : material);
}

/**
 * Order-independent commitment over the evidence a ruling relied on.
 *
 * Sorted before hashing so two arbitrators listing the same evidence in a different order
 * produce the same root - otherwise "did you rely on the same material?" becomes a question
 * about array order, which is not a question anybody means to ask.
 */
export function evidenceRoot(digests: Hex[]): Hex {
  const sorted = [...digests].sort();
  return keccak256(
    encodeAbiParameters([{ type: 'bytes32[]' }], [sorted as readonly Hex[]]),
  );
}

/**
 * Check a case is fit to rule on, and reject it if not.
 *
 * Deliberately strict. An arbitrator ruling on a malformed case produces a decision that
 * cannot be re-checked later, which is the failure this whole module exists to avoid.
 */
export function assertRulable(c: Case, now: number): void {
  if (!c.orderId || !c.escrow) throw new DisputeError('case must name an order and an escrow');
  if (typeof c.expiresAt !== 'number') {
    throw new DisputeError('case has no on-chain deadline; it was not opened against the escrow');
  }
  if (now >= c.expiresAt) {
    throw new DisputeError(
      `the escrow's deadline passed at ${new Date(c.expiresAt * 1000).toISOString()}: `
      + 'it accepts no ruling now, and anyone can expire the dispute to its REFUND default',
    );
  }
  if (c.evidence.length === 0 && now < c.respondBy) {
    throw new DisputeError('no evidence yet, and the response window is still open');
  }
  const seen = new Set<Hex>();
  for (const e of c.evidence) {
    if (!/^0x[0-9a-f]{64}$/i.test(e.digest)) {
      throw new DisputeError(`evidence digest is not a keccak256 hash: ${e.digest}`);
    }
    if (seen.has(e.digest.toLowerCase() as Hex)) {
      throw new DisputeError(`evidence submitted twice: ${e.digest}`);
    }
    seen.add(e.digest.toLowerCase() as Hex);
  }
}

/** Did every side that needed to answer, answer? */
export function respondedSides(c: Case): Set<Side> {
  return new Set(c.evidence.map((e) => e.submittedBy));
}

/**
 * The ruling to apply when the window closed and a side never spoke.
 *
 * Returns null while a ruling on the merits is still possible, so a caller cannot
 * accidentally default a case that both parties actually contested.
 */
export function defaultRulingIfUnanswered(c: Case, now: number): Ruling['outcome'] | null {
  if (now < c.respondBy) return null;
  const answered = respondedSides(c);
  const bothSpoke = answered.size >= 2;
  return bothSpoke ? null : c.defaultRuling;
}

export class Arbitrator {
  private readonly account;

  constructor(privateKey: Hex) {
    this.account = privateKeyToAccount(privateKey);
  }

  get address(): Hex {
    return this.account.address;
  }

  /**
   * Sign a ruling.
   *
   * Refuses to rely on evidence the case does not contain. Without that check an
   * arbitrator could justify a decision with material the losing party never saw, and the
   * signature would still verify - the signature proves authorship, not fairness.
   */
  async rule(c: Case, r: Omit<Ruling, 'orderId' | 'escrow' | 'chainId'>): Promise<{
    ruling: Ruling;
    signature: Hex;
    evidenceRoot: Hex;
  }> {
    const known = new Set(c.evidence.map((e) => e.digest.toLowerCase()));
    for (const d of r.reliedOn) {
      if (!known.has(d.toLowerCase())) {
        throw new DisputeError(`ruling relies on evidence not in the case: ${d}`);
      }
    }
    if (!r.byDefault && r.reliedOn.length === 0) {
      throw new DisputeError('a ruling on the merits must cite the evidence it rests on');
    }

    const ruling: Ruling = { ...r, orderId: c.orderId, escrow: c.escrow, chainId: c.chainId };
    const root = evidenceRoot(r.reliedOn);
    const signature = await this.account.signTypedData({
      domain: rulingDomain(c.chainId, c.escrow),
      types: RULING_TYPES,
      primaryType: 'Ruling',
      message: {
        orderId: ruling.orderId,
        escrow: ruling.escrow,
        outcome: ruling.outcome,
        evidenceRoot: root,
        rationale: ruling.rationale,
        ruledAt: BigInt(ruling.ruledAt),
        byDefault: ruling.byDefault,
      },
    });
    return { ruling, signature, evidenceRoot: root };
  }
}

/** Recover who signed a ruling, so a party can check it came from the named arbitrator. */
export async function rulingSigner(
  ruling: Ruling,
  root: Hex,
  signature: Hex,
): Promise<Hex> {
  return recoverTypedDataAddress({
    domain: rulingDomain(ruling.chainId, ruling.escrow),
    types: RULING_TYPES,
    primaryType: 'Ruling',
    message: {
      orderId: ruling.orderId,
      escrow: ruling.escrow,
      outcome: ruling.outcome,
      evidenceRoot: root,
      rationale: ruling.rationale,
      ruledAt: BigInt(ruling.ruledAt),
      byDefault: ruling.byDefault,
    },
    signature,
  });
}

/**
 * The arguments anyone passes to `resolveDispute(bytes32, Ruling, bytes)` - twice: the first
 * call posts the ruling, the same call after the escrow's RULING_DELAY executes it.
 *
 * The escrow verifies the arbitrator's signature itself, so a submitter carries a decision
 * rather than making one, and who submits does not matter. Note there is no boolean here:
 * the outcome travels as the signed string and the contract maps it, because a boolean
 * alongside a signature is a second source of truth that can disagree with the first.
 */
export function toOnChainCall(
  ruling: Ruling,
  root: Hex,
  signature: Hex,
): {
  fn: 'resolveDispute';
  args: [Hex, {
    orderId: Hex; outcome: string; evidenceRoot: Hex;
    rationale: string; ruledAt: bigint; byDefault: boolean;
  }, Hex];
} {
  return {
    fn: 'resolveDispute',
    args: [
      ruling.orderId,
      {
        orderId: ruling.orderId,
        outcome: ruling.outcome,
        evidenceRoot: root,
        rationale: ruling.rationale,
        ruledAt: BigInt(ruling.ruledAt),
        byDefault: ruling.byDefault,
      },
      signature,
    ],
  };
}
