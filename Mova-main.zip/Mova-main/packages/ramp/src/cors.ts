/**
 * CORS for the public HTTP surfaces a browser wallet calls: the matcher, and an LP node's counterparty API.
 *
 * ## An explicit list, and nothing by default
 *
 * Without CORS headers a wallet served from another origin cannot read these responses at all. With a
 * wildcard, any page on the web could - including one that walks a victim's browser through quote and
 * payee calls from their IP. So the policy is a list of exact origins (`scheme://host[:port]`), and
 * the two values that mean "anyone" are refused rather than honoured:
 *
 *  - `*` is a wildcard.
 *  - `null` is what sandboxed iframes, `data:` and `file:` pages send: any page can make itself `null`,
 *    so allowing it allows everyone.
 *
 * An empty list (the default) allows nothing and adds no headers, so a server that configures no
 * origins answers exactly as it did before CORS existed here, apart from refusing preflights.
 *
 * There is no `Access-Control-Allow-Credentials`: these APIs take no cookies and no HTTP auth, and a
 * taker proves who they are with a signature in the body.
 *
 * Browser-safe: no `node:` imports.
 */

export interface CorsOptions {
  /** Exact origins, `https://wallet.example` or `http://localhost:5173`. `*` and `null` are refused. */
  allowedOrigins: readonly string[];
  /** How long a browser may cache a preflight answer. Default 600; browsers cap it (Chromium at 7200). */
  maxAgeSeconds?: number;
  /** Request headers a caller may send. Default `content-type`, which a JSON POST needs. */
  allowHeaders?: readonly string[];
}

const DEFAULT_MAX_AGE_SECONDS = 600;
const DEFAULT_ALLOW_HEADERS: readonly string[] = ['content-type'];
/** An RFC 9110 token: what a header name may be. */
const TOKEN = /^[!#$%&'*+.^_`|~0-9A-Za-z-]+$/;

/**
 * The canonical form of one configured origin: lowercase, default port dropped, a single trailing
 * slash stripped. Throws on anything that is not exactly an http(s) origin. The message says what is
 * wrong without repeating the value, so a caller can prefix it with where the value came from.
 */
export function normalizeOrigin(entry: string): string {
  const s = entry.trim().toLowerCase();
  if (!s) throw new Error('is empty');
  if (s === '*') throw new Error("is '*': refused - allowed origins are an explicit list, name each one");
  if (s === 'null') throw new Error("is 'null': refused - sandboxed frames and file pages all send it, so it would allow anyone");
  const scheme = /^([a-z][a-z0-9+.-]*):\/\//.exec(s)?.[1];
  if (!scheme) throw new Error('is not an origin: expected scheme://host[:port]');
  if (scheme !== 'http' && scheme !== 'https') throw new Error('must be an http:// or https:// origin');
  const rest = (s.endsWith('/') ? s.slice(0, -1) : s).slice(scheme.length + 3);
  if (!rest || /[/?#@\\\s]/.test(rest)) {
    throw new Error('must be an origin only - scheme://host[:port], with no path, query, fragment or credentials');
  }
  let url: URL;
  try {
    url = new URL(`${scheme}://${rest}`);
  } catch {
    throw new Error('is not an origin: expected scheme://host[:port]');
  }
  if (!url.hostname || url.pathname !== '/' || url.search || url.hash || url.username || url.password) {
    throw new Error('must be an origin only - scheme://host[:port], with no path, query, fragment or credentials');
  }
  return url.origin;
}

export class CorsPolicy {
  /** The allowed origins, canonical. */
  readonly origins: readonly string[];
  private readonly allowed: ReadonlySet<string>;
  private readonly maxAgeSeconds: number;
  private readonly allowHeaders: readonly string[];

  constructor(o?: CorsOptions) {
    this.origins = (o?.allowedOrigins ?? []).map((entry, i) => {
      if (typeof entry !== 'string') throw new Error(`CORS allowed origin ${i + 1} must be a string`);
      try {
        return normalizeOrigin(entry);
      } catch (e) {
        throw new Error(`CORS allowed origin ${i + 1} ${(e as Error).message}`);
      }
    });
    this.allowed = new Set(this.origins);
    this.maxAgeSeconds = o?.maxAgeSeconds ?? DEFAULT_MAX_AGE_SECONDS;
    if (!Number.isInteger(this.maxAgeSeconds) || this.maxAgeSeconds < 0) {
      throw new Error('CORS maxAgeSeconds must be a non-negative integer');
    }
    this.allowHeaders = o?.allowHeaders ?? DEFAULT_ALLOW_HEADERS;
    for (const h of this.allowHeaders) {
      if (h === '*' || !TOKEN.test(h)) throw new Error('CORS allowHeaders must be header names; a wildcard is refused');
    }
  }

  /** False when no origins are configured: then no response depends on the Origin header. */
  get enabled(): boolean {
    return this.allowed.size > 0;
  }

  allows(origin: string | undefined): boolean {
    return typeof origin === 'string' && this.allowed.has(origin.trim().toLowerCase());
  }

  /**
   * Headers to add to an actual response for a request carrying this Origin: ACAO echoing the origin
   * and `Vary: Origin` when allowed; only `Vary: Origin` otherwise (a cache must not hand one origin's
   * answer to another). With no origins configured, nothing.
   */
  responseHeaders(origin: string | undefined): Record<string, string> {
    if (!this.enabled) return {};
    // Echoed as the browser sent it: it compares the header byte for byte with its own serialisation.
    if (this.allows(origin)) return { 'access-control-allow-origin': origin!.trim(), vary: 'Origin' };
    return { vary: 'Origin' };
  }

  /**
   * A preflight answer: 204 with ACAO, the methods, the headers, the max age and `Vary: Origin` when
   * allowed; 403 when not - including every preflight when no origins are configured.
   */
  preflight(origin: string | undefined, methods: readonly string[]): { status: number; headers: Record<string, string> } {
    if (!this.allows(origin)) return { status: 403, headers: this.enabled ? { vary: 'Origin' } : {} };
    return {
      status: 204,
      headers: {
        'access-control-allow-origin': origin!.trim(),
        'access-control-allow-methods': methods.join(', '),
        ...(this.allowHeaders.length ? { 'access-control-allow-headers': this.allowHeaders.join(', ') } : {}),
        'access-control-max-age': String(this.maxAgeSeconds),
        vary: 'Origin',
      },
    };
  }
}
