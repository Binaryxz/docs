/**
 * The arbitration desk the protocol runs (task 2.6, the service half).
 *
 * `disputes.ts` decides what a well-formed case and a valid ruling look like. This runs the
 * process around them: intake, evidence, deadlines, and the signed ruling anyone may then
 * submit on-chain.
 *
 * ## What the desk deliberately cannot do
 *
 * It cannot move funds by itself. A ruling is a signature; the escrow acts only on a signature
 * from a registered arbitrator for a sale or order actually in dispute, only after posting it
 * publicly for RULING_DELAY, and only if the arbitrator is still registered when it executes.
 * Submission is open to anyone, so the governor is no longer a check on what the desk signs -
 * the delay is. A compromised desk's rulings are on-chain a day before they can pay anyone,
 * and revoking its arbitrator (instant) voids every one not yet executed. It can never touch a
 * healthy order, an LP's free liquidity, or the shielded pool. `postedRulingsNotSigned` is the
 * check an operator runs to notice rulings this desk never signed.
 *
 * ## The escrow's deadline bounds the desk's
 *
 * Each escrow expires an unruled dispute to REFUND at `disputedAt + DISPUTE_TIMEOUT`, and a
 * ruling must be posted at least two RULING_DELAYs before that to execute in time. So the desk
 * reads the deadline when it opens a case, fits the response window inside it, and refuses to
 * sign once too little time is left for the ruling to land - a signature that cannot execute
 * would only tell a party they had won when the chain is about to say otherwise.
 *
 * It also never stores evidence. Only commitments and a URI the parties can fetch from.
 * Bank statements carry names, CPFs and account numbers; a desk that accumulated those
 * would become the most sensitive database in the system while settling arguments about a
 * few hundred reais.
 *
 * ## Deadlines are the actual product
 *
 * Almost no dispute is a genuine adversarial contest. Most are one side having stopped
 * replying, and the failure mode that matters is a dispute becoming a way to freeze
 * somebody's money by simply not participating. So every case carries a response deadline
 * and a default outcome, `dueCases()` surfaces what is ripe, and the desk will rule by
 * default once the window closes with only one side heard.
 */
import { randomUUID } from 'node:crypto';
import { mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import { dirname } from 'node:path';
import {
  getAddress, isAddress, zeroAddress, type Address, type Hex, type PublicClient,
} from 'viem';

import {
  Arbitrator, DisputeError, assertRulable, defaultRulingIfUnanswered, evidenceRoot,
  evidenceSigner, rulingSigner, toOnChainCall, type Case, type Parties, type Ruling,
  type Side,
} from './disputes.js';
import { OFFERS_FN } from './indexer.js';

export interface DeskRecord {
  caseId: string;
  case: Case;
  status: 'OPEN' | 'RULED';
  ruling?: Ruling;
  signature?: Hex;
  evidenceRoot?: Hex;
}

/** Anything durable enough to survive a restart. A file or a table both satisfy this. */
export interface CaseStore {
  put(rec: DeskRecord): Promise<void>;
  get(caseId: string): Promise<DeskRecord | undefined>;
  all(): Promise<DeskRecord[]>;
}

export class MemoryCaseStore implements CaseStore {
  private readonly recs = new Map<string, DeskRecord>();

  async put(rec: DeskRecord): Promise<void> {
    this.recs.set(rec.caseId, rec);
  }

  async get(caseId: string): Promise<DeskRecord | undefined> {
    return this.recs.get(caseId);
  }

  async all(): Promise<DeskRecord[]> {
    return [...this.recs.values()];
  }
}

/**
 * Cases in one JSON file, rewritten atomically on every change.
 *
 * The memory store is right for tests and wrong for a running desk: a restart would forget
 * every open case, evidence commitment and deadline - and which orders already HAVE a case,
 * so the one-case-per-order rule would reset with the process. Dispute volume is small, so
 * a whole-file rewrite through a temp file and a rename is simpler to trust than a
 * database, and a crash mid-write leaves the previous file intact.
 */
export class FileCaseStore implements CaseStore {
  private cache?: Map<string, DeskRecord>;
  /** Chained, so two concurrent puts cannot interleave their renames. */
  private writing: Promise<void> = Promise.resolve();

  constructor(private readonly path: string) {}

  private async load(): Promise<Map<string, DeskRecord>> {
    if (this.cache) return this.cache;
    let recs: DeskRecord[] = [];
    try {
      recs = JSON.parse(await readFile(this.path, 'utf8')) as DeskRecord[];
    } catch (e) {
      // A missing file is a fresh desk. A corrupt or unreadable one must stop the desk
      // rather than start it empty, because an empty store forgets which orders have cases.
      if ((e as NodeJS.ErrnoException).code !== 'ENOENT') throw e;
    }
    this.cache = new Map(recs.map((r) => [r.caseId, r]));
    return this.cache;
  }

  async put(rec: DeskRecord): Promise<void> {
    const copy = structuredClone(rec);
    // Each write builds its snapshot only once the previous one has landed, so it includes
    // every earlier put; and the cache moves only after the file does, so a failed write
    // cannot leave the desk believing in a case the disk never saw. `catch` keeps one failed
    // write from failing every write after it.
    const run = this.writing.catch(() => undefined).then(async () => {
      const next = new Map(await this.load());
      next.set(copy.caseId, copy);
      await mkdir(dirname(this.path), { recursive: true });
      const tmp = `${this.path}.${process.pid}.tmp`;
      await writeFile(tmp, JSON.stringify([...next.values()], null, 2), { mode: 0o600 });
      await rename(tmp, this.path);
      this.cache = next;
    });
    this.writing = run;
    await run;
  }

  async get(caseId: string): Promise<DeskRecord | undefined> {
    const rec = (await this.load()).get(caseId);
    return rec && structuredClone(rec);
  }

  async all(): Promise<DeskRecord[]> {
    return [...(await this.load()).values()].map((r) => structuredClone(r));
  }
}

export type Leg = Case['leg'];

/** What the escrow itself records about an order or sale, as far as a case needs it. */
export interface EscrowRecord {
  /** True only when the escrow's own state for this id is DISPUTED. */
  disputed: boolean;
  /** The addresses the escrow recorded: taker and LP, or seller and LP. */
  parties: Parties;
  /** `disputedAt(id)`, unix seconds; 0 if never disputed. */
  disputedAt: number;
  /** `disputedAt + DISPUTE_TIMEOUT()`: when the escrow stops taking rulings. */
  expiresAt: number;
}

/**
 * Reads an order or sale from its escrow. An interface so tests can stub the chain; the
 * production implementation is `chainEscrowReader`.
 */
export interface EscrowReader {
  read(ref: { escrow: Address; leg: Leg; orderId: Hex }): Promise<EscrowRecord>;
}

/**
 * `FiatEscrow.OrderState.DISPUTED` and `OffRampEscrow.SaleState.DISPUTED`.
 *
 * Different numbers for the same word, because the off-ramp has an OPEN state before a
 * claim. The test reads both enums out of the Solidity, so a reordering there fails a test
 * rather than making every dispute look undisputed.
 */
export const ONRAMP_DISPUTED = 4;
export const OFFRAMP_DISPUTED = 5;

/**
 * The escrows' `RULING_DELAY`: a posted ruling executes no sooner than this. Both contracts
 * declare it; the test reads it out of the Solidity.
 */
export const RULING_DELAY_SECONDS = 86_400;

/**
 * Default time the desk leaves between its last signature and the escrow's deadline.
 *
 * The escrow needs two RULING_DELAYs - one before the posted ruling may execute, one of slack
 * after - and a party needs time to notice the ruling and submit it. Three days covers both;
 * a policy may raise it, never lower it below the two delays the chain requires.
 */
export const DEFAULT_RULING_MARGIN_SECONDS = 3 * RULING_DELAY_SECONDS;

const DISPUTED_AT_FN = {
  type: 'function', name: 'disputedAt', stateMutability: 'view',
  inputs: [{ type: 'bytes32' }], outputs: [{ type: 'uint64' }],
} as const;
const DISPUTE_TIMEOUT_FN = {
  type: 'function', name: 'DISPUTE_TIMEOUT', stateMutability: 'view',
  inputs: [], outputs: [{ type: 'uint64' }],
} as const;

/**
 * The public getter for `FiatEscrow.orders(bytes32)`. Solidity returns a struct's members
 * in declaration order; the test checks these names against `struct Order`.
 */
export const ORDERS_FN = {
  type: 'function',
  name: 'orders',
  stateMutability: 'view',
  inputs: [{ type: 'bytes32' }],
  outputs: [
    { name: 'offerId', type: 'bytes32' },
    { name: 'taker', type: 'address' },
    { name: 'weiAmount', type: 'uint256' },
    { name: 'brlCents', type: 'uint256' },
    { name: 'lockedAt', type: 'uint64' },
    { name: 'payBy', type: 'uint64' },
    { name: 'state', type: 'uint8' },
    { name: 'delivery', type: 'uint8' },
    { name: 'recipient', type: 'address' },
    { name: 'precommitment', type: 'uint256' },
    { name: 'commitment', type: 'uint256' },
  ],
} as const;

/** The public getter for `OffRampEscrow.sales(bytes32)`, checked against `struct Sale`. */
export const SALES_FN = {
  type: 'function',
  name: 'sales',
  stateMutability: 'view',
  inputs: [{ type: 'bytes32' }],
  outputs: [
    { name: 'seller', type: 'address' },
    { name: 'asset', type: 'address' },
    { name: 'weiAmount', type: 'uint256' },
    { name: 'brlCents', type: 'uint256' },
    { name: 'payeeKeyHash', type: 'bytes32' },
    { name: 'verifier', type: 'address' },
    { name: 'railMask', type: 'uint16' },
    { name: 'lp', type: 'address' },
    { name: 'claimedAt', type: 'uint64' },
    { name: 'payBy', type: 'uint64' },
    { name: 'refundTo', type: 'address' },
    { name: 'state', type: 'uint8' },
  ],
} as const;

/**
 * Parties and state, straight from the escrow's storage.
 *
 * On the on-ramp the order names the taker and points at an offer, which names the LP -
 * the same two addresses `FiatEscrow.raiseDispute` accepts. On the off-ramp the sale names
 * the seller and the claiming LP, the two `OffRampEscrow.raiseDispute` accepts.
 */
export function chainEscrowReader(client: Pick<PublicClient, 'readContract'>): EscrowReader {
  const deadline = async (escrow: Address, orderId: Hex) => {
    const at = Number(await client.readContract({
      address: escrow, abi: [DISPUTED_AT_FN], functionName: 'disputedAt', args: [orderId],
    }));
    const timeout = Number(await client.readContract({
      address: escrow, abi: [DISPUTE_TIMEOUT_FN], functionName: 'DISPUTE_TIMEOUT',
    }));
    return { disputedAt: at, expiresAt: at === 0 ? 0 : at + timeout };
  };
  return {
    async read({ escrow, leg, orderId }) {
      if (leg === 'onramp') {
        const o = await client.readContract({
          address: escrow, abi: [ORDERS_FN], functionName: 'orders', args: [orderId],
        }) as readonly unknown[];
        const offer = await client.readContract({
          address: escrow, abi: [OFFERS_FN], functionName: 'offers', args: [o[0] as Hex],
        }) as readonly unknown[];
        return {
          disputed: Number(o[6]) === ONRAMP_DISPUTED,
          parties: { taker: o[1] as Hex, lp: offer[0] as Hex },
          ...(await deadline(escrow, orderId)),
        };
      }
      const s = await client.readContract({
        address: escrow, abi: [SALES_FN], functionName: 'sales', args: [orderId],
      }) as readonly unknown[];
      return {
        disputed: Number(s[11]) === OFFRAMP_DISPUTED,
        parties: { seller: s[0] as Hex, lp: s[7] as Hex },
        ...(await deadline(escrow, orderId)),
      };
    },
  };
}

/** How this desk runs, set by its operator. None of it is the filer's to choose. */
export interface DeskPolicy {
  /** The chain the escrows live on; part of every signature domain. */
  chainId: number;
  /**
   * The escrows this desk's arbitrator is registered on, and which leg each is.
   *
   * The leg comes from here rather than from the request because it decides which getter
   * is read, and so who the parties are. An unlisted escrow is refused: a case against a
   * contract the filer deployed would read parties the filer invented.
   */
  escrows: readonly { address: Address; leg: Leg }[];
  reader: EscrowReader;
  /**
   * Seconds the silent side has to respond. Default 72 hours. Must be at most half the
   * escrow's dispute timeout, so the desk has at least as long to rule as the parties had to
   * answer; a case opened late gets a window cut short to fit before the ruling margin.
   */
  responseWindowSeconds?: number;
  /**
   * Seconds before the escrow's deadline after which the desk will not sign. Default
   * DEFAULT_RULING_MARGIN_SECONDS; never less than two RULING_DELAYs.
   */
  rulingMarginSeconds?: number;
}

export interface OpenCaseInput {
  orderId: Hex;
  escrow: Hex;
  /** The filer's own label, checked against the sides the escrow recorded. */
  raisedBy: Side;
  reason: string;
  /** Optional; refused if it disagrees with the desk's chain. */
  chainId?: number;
  /** Optional; refused if it disagrees with the leg configured for `escrow`. */
  leg?: Leg;
}

/**
 * Fields a filer used to set and no longer may. Refused loudly rather than dropped, so a
 * client that believes it chose the parties or the deadline learns that it did not.
 */
const NOT_THE_FILERS_TO_SET = ['parties', 'responseWindowSeconds', 'defaultRuling', 'respondBy'];

/**
 * The outcome applied when a side never answers: REFUND, on both legs.
 *
 * REFUND returns the escrowed asset to whoever put it up - the LP's liquidity on the
 * on-ramp, the seller's crypto on the off-ramp - which is the one outcome that cannot be
 * gamed by staying silent. Defaulting to RELEASE would make non-participation a way to get
 * paid. A constant rather than policy, because no deployment makes the other answer safe.
 */
export const DEFAULT_RULING: Ruling['outcome'] = 'REFUND';

export class ArbitrationDesk {
  /** Orders with an `open` in flight, so two concurrent requests cannot both pass the check. */
  private readonly opening = new Set<string>();

  constructor(
    private readonly store: CaseStore,
    private readonly arbitrator: Arbitrator,
    private readonly policy: DeskPolicy,
    private readonly now: () => number = () => Math.floor(Date.now() / 1000),
  ) {
    if (policy.escrows.length === 0) {
      throw new Error('no escrows configured: this desk could not open a single case');
    }
    if (this.margin < 2 * RULING_DELAY_SECONDS) {
      throw new Error(
        `rulingMarginSeconds ${this.margin} leaves no time for a ruling to post and execute: `
        + `the escrows need at least ${2 * RULING_DELAY_SECONDS}`,
      );
    }
  }

  private get margin(): number {
    return this.policy.rulingMarginSeconds ?? DEFAULT_RULING_MARGIN_SECONDS;
  }

  /** The last moment the desk will sign for a case: the escrow's deadline less the margin. */
  signingDeadline(c: Case): number {
    return c.expiresAt - this.margin;
  }

  get arbitratorAddress(): Hex {
    return this.arbitrator.address;
  }

  /**
   * Open a case for an order the escrow reports as DISPUTED.
   *
   * Everything that decides an outcome comes from the chain or from desk policy. It used to
   * come from the request: the filer supplied `parties`, `responseWindowSeconds` and
   * `defaultRuling`, so a taker could name a second key of their own as the LP, give the
   * real LP a one-second window, and set the default to RELEASE - turning the LP's silence
   * into a payout. The filer now controls only the reason text and which recorded side they
   * say they are.
   *
   * Opening stays permissionless; the escrow is the gate. Only an order's own parties can
   * move it to DISPUTED, and no case opens for anything else.
   *
   * One case per order, ever. An order leaves DISPUTED only through a ruling and cannot
   * re-enter it, so a second case - even after the first was ruled, while the ruling awaits
   * submission - could only produce a second, possibly contradicting, signed ruling.
   */
  async open(input: OpenCaseInput): Promise<DeskRecord> {
    if (typeof input !== 'object' || input === null) throw new DisputeError('a case request is an object');
    for (const k of NOT_THE_FILERS_TO_SET) {
      if (k in input) {
        throw new DisputeError(
          `${k} is not the filer's to set: parties come from the escrow, the response window `
          + 'and default ruling from desk policy',
        );
      }
    }
    if (typeof input.orderId !== 'string' || !/^0x[0-9a-fA-F]{64}$/.test(input.orderId)) {
      throw new DisputeError('orderId must be a bytes32 hex string');
    }
    if (typeof input.escrow !== 'string' || !isAddress(input.escrow, { strict: false })) {
      throw new DisputeError('escrow must be an address');
    }
    if (typeof input.reason !== 'string' || input.reason.trim() === '') {
      throw new DisputeError('a reason is required');
    }
    const escrow = getAddress(input.escrow);
    const orderId = input.orderId.toLowerCase() as Hex;
    const { chainId } = this.policy;

    const configured = this.policy.escrows.find((e) => getAddress(e.address) === escrow);
    if (!configured) throw new DisputeError(`this desk does not arbitrate escrow ${escrow}`);
    const { leg } = configured;
    if (input.leg !== undefined && input.leg !== leg) {
      throw new DisputeError(`${escrow} is the ${leg} escrow, not ${input.leg}`);
    }
    if (input.chainId !== undefined && input.chainId !== chainId) {
      throw new DisputeError(`this desk arbitrates chain ${chainId}, not ${input.chainId}`);
    }

    // Claimed before the first await, so a concurrent open for the same order is refused
    // here rather than racing past the store check below.
    const key = `${chainId}:${escrow}:${orderId}`;
    if (this.opening.has(key)) {
      throw new DisputeError(`order ${orderId} already has a case being opened`);
    }
    this.opening.add(key);
    try {
      const existing = (await this.store.all()).find((r) =>
        r.case.chainId === chainId
        && r.case.escrow.toLowerCase() === escrow.toLowerCase()
        && r.case.orderId.toLowerCase() === orderId);
      if (existing) {
        throw new DisputeError(
          `order ${orderId} already has a case: ${existing.caseId} (${existing.status})`,
        );
      }

      const onChain = await this.policy.reader.read({ escrow, leg, orderId });
      if (!onChain.disputed) {
        throw new DisputeError(
          `order ${orderId} is not DISPUTED on the escrow; raise the dispute on-chain first`,
        );
      }
      // An id the escrow never saw reads back as zeroes. A case whose "party" is address(0)
      // could never be answered by that side, so it is refused rather than recorded.
      const parties: Parties = {};
      for (const [side, addr] of Object.entries(onChain.parties) as [Side, Hex | undefined][]) {
        if (!addr || getAddress(addr) === zeroAddress) {
          throw new DisputeError(`the escrow records no ${side} for order ${orderId}`);
        }
        parties[side] = getAddress(addr);
      }
      // hasOwn, not a lookup: `parties["__proto__"]` is truthy on any object literal.
      if (!Object.hasOwn(parties, input.raisedBy)) {
        throw new DisputeError(
          `raisedBy must be one of ${Object.keys(parties).join(', ')} on the ${leg} escrow`,
        );
      }

      const at = this.now();
      const window = this.policy.responseWindowSeconds ?? 72 * 3600;
      const timeout = onChain.expiresAt - onChain.disputedAt;
      if (!(onChain.expiresAt > 0) || !(timeout > 0)) {
        throw new DisputeError(`the escrow reports no dispute deadline for order ${orderId}`);
      }
      if (window * 2 > timeout) {
        throw new DisputeError(
          `this desk's response window (${window}s) is not well inside the escrow's dispute `
          + `timeout (${timeout}s); a desk that slow would lose its cases to the default`,
        );
      }
      const signBy = onChain.expiresAt - this.margin;
      if (signBy <= at) {
        throw new DisputeError(
          `order ${orderId} is too close to the escrow's deadline `
          + `(${new Date(onChain.expiresAt * 1000).toISOString()}) for a ruling to execute in time; `
          + 'it will be refunded by default, and anyone can then call expireDispute',
        );
      }
      const rec: DeskRecord = {
        caseId: randomUUID(),
        status: 'OPEN',
        case: {
          orderId,
          escrow,
          chainId,
          leg,
          raisedBy: input.raisedBy,
          raisedAt: at,
          reason: input.reason,
          // A case opened late - the dispute was raised on-chain days ago - still leaves the
          // arbitrator room to rule before the escrow's deadline.
          respondBy: Math.min(at + window, signBy),
          defaultRuling: DEFAULT_RULING,
          expiresAt: onChain.expiresAt,
          parties,
          evidence: [],
        },
      };
      await this.store.put(rec);
      return rec;
    } finally {
      this.opening.delete(key);
    }
  }

  /**
   * Attach a commitment to material. The material itself stays with the parties.
   *
   * The submitting side is RECOVERED from the signature and never taken from the caller.
   * When it was a plain field, a taker could submit once as themselves and once as the LP;
   * `respondedSides` then reported a contested case, `ruleByDefault` refused, and the
   * escrowed funds could be frozen indefinitely by the very party who opened the dispute.
   */
  async submitEvidence(
    caseId: string,
    ev: { digest: Hex; kind: string; uri?: string },
    signature: Hex,
  ): Promise<DeskRecord> {
    const rec = await this.require(caseId);
    if (rec.status === 'RULED') {
      throw new DisputeError('the case is already ruled; evidence cannot change it');
    }
    if (rec.case.evidence.some((e) => e.digest.toLowerCase() === ev.digest.toLowerCase())) {
      throw new DisputeError(`evidence already submitted: ${ev.digest}`);
    }

    const signer = await evidenceSigner(
      { caseId, orderId: rec.case.orderId, escrow: rec.case.escrow, chainId: rec.case.chainId },
      ev,
      signature,
    );
    const side = (Object.keys(rec.case.parties) as Side[]).find(
      (k) => rec.case.parties[k]?.toLowerCase() === signer.toLowerCase(),
    );
    if (!side) {
      throw new DisputeError(
        `${signer} is not a party to this case; only its taker, LP or seller may submit`,
      );
    }

    rec.case.evidence.push({
      ...ev, submittedBy: side, submitter: signer, submittedAt: this.now(),
    });
    await this.store.put(rec);
    return rec;
  }

  /** Read a case. Public: a dispute process nobody can inspect is not a process. */
  async get(caseId: string): Promise<DeskRecord | undefined> {
    return this.store.get(caseId);
  }

  /**
   * The case for one disputed order or sale on one escrow of this desk's chain, if any.
   *
   * Exact match only - no listing, no partial ids - so it tells a caller nothing `get` would not once
   * they held the case id: which orders are disputed is already public on-chain (`OrderDisputed`,
   * `SaleDisputed`), and a case holds commitments, not documents. It exists because a party whose
   * counterparty filed first has no other way to learn the case id, and one case per order means
   * it cannot open its own.
   */
  async findByOrder(escrow: string, orderId: string): Promise<DeskRecord | undefined> {
    if (typeof escrow !== 'string' || !isAddress(escrow, { strict: false })) throw new DisputeError('escrow must be an address');
    if (typeof orderId !== 'string' || !/^0x[0-9a-fA-F]{64}$/.test(orderId)) {
      throw new DisputeError('orderId must be a bytes32 hex string');
    }
    const e = getAddress(escrow);
    const id = orderId.toLowerCase();
    return (await this.store.all()).find((r) => r.case.chainId === this.policy.chainId
      && getAddress(r.case.escrow) === e && r.case.orderId.toLowerCase() === id);
  }

  /**
   * Cases a human should look at now: past the response deadline, both sides heard, or within a
   * day of the last moment the desk can still sign for them.
   */
  async dueCases(): Promise<DeskRecord[]> {
    const now = this.now();
    return (await this.store.all()).filter((r) => {
      if (r.status !== 'OPEN') return false;
      const sides = new Set(r.case.evidence.map((e) => e.submittedBy));
      return now >= r.case.respondBy || sides.size >= 2
        || now >= this.signingDeadline(r.case) - RULING_DELAY_SECONDS;
    });
  }

  /**
   * Rule on the merits. The arbitrator must cite evidence actually in the case.
   */
  async rule(caseId: string, outcome: Ruling['outcome'], rationale: string, reliedOn: Hex[]) {
    const rec = await this.require(caseId);
    if (rec.status === 'RULED') throw new DisputeError('already ruled');
    assertRulable(rec.case, this.now());
    this.assertTimeToExecute(rec.case);

    const { ruling, signature, evidenceRoot: root } = await this.arbitrator.rule(rec.case, {
      outcome, reliedOn, rationale, ruledAt: this.now(), byDefault: false,
    });
    return this.finish(rec, ruling, signature, root);
  }

  /**
   * Rule by default, when the window closed with one side silent.
   *
   * Refuses if the case is actually contested. A desk that could quietly default a case
   * both parties engaged with would turn "we ran out of patience" into a ruling nobody
   * could distinguish from one on the merits.
   */
  async ruleByDefault(caseId: string) {
    const rec = await this.require(caseId);
    if (rec.status === 'RULED') throw new DisputeError('already ruled');
    assertRulable(rec.case, this.now());
    this.assertTimeToExecute(rec.case);

    const outcome = defaultRulingIfUnanswered(rec.case, this.now());
    if (outcome === null) {
      throw new DisputeError(
        'cannot default: either the window is still open, or both sides responded and this '
        + 'must be decided on the merits',
      );
    }
    const { ruling, signature, evidenceRoot: root } = await this.arbitrator.rule(rec.case, {
      outcome,
      reliedOn: [],
      rationale: `no response by ${new Date(rec.case.respondBy * 1000).toISOString()}`,
      ruledAt: this.now(),
      byDefault: true,
    });
    return this.finish(rec, ruling, signature, root);
  }

  /**
   * What anyone submits, plus everything needed to check it independently and to time it:
   * submit once to post, again at or after `executableAfter` seconds from posting, and before
   * `expiresAt`, when the escrow stops accepting rulings.
   */
  async submission(caseId: string) {
    const rec = await this.require(caseId);
    if (rec.status !== 'RULED' || !rec.ruling || !rec.signature || !rec.evidenceRoot) {
      throw new DisputeError('no ruling yet');
    }
    return {
      ...toOnChainCall(rec.ruling, rec.evidenceRoot, rec.signature),
      leg: rec.case.leg,
      arbitrator: this.arbitrator.address,
      executableAfter: RULING_DELAY_SECONDS,
      expiresAt: rec.case.expiresAt,
    };
  }

  /**
   * Of the rulings posted on-chain under THIS desk's arbitrator key (from `RulingPosted` events,
   * by whoever watches for them), the ones this desk never signed. Rulings by other arbitrator
   * keys are theirs to check, and are not reported.
   *
   * With submission open to anyone, a ruling nobody at the desk signed is the signature of a
   * stolen arbitrator key, and the posting delay exists so it can be caught here: anything this
   * returns means revoke the arbitrator now (`admin escrow:arbitrator <escrow> <key> false`),
   * before the ruling's delay runs out.
   */
  async postedRulingsNotSigned(
    posted: readonly { escrow: Address; orderId: Hex; arbitrator: Address; evidenceRoot: Hex; releasedToTaker: boolean }[],
  ): Promise<typeof posted[number][]> {
    const signed = (await this.store.all()).filter((r) => r.status === 'RULED' && r.ruling && r.evidenceRoot);
    const mine = this.arbitrator.address.toLowerCase();
    return posted.filter((p) => p.arbitrator.toLowerCase() === mine && !signed.some((r) =>
      r.case.escrow.toLowerCase() === p.escrow.toLowerCase()
      && r.case.orderId.toLowerCase() === p.orderId.toLowerCase()
      && r.evidenceRoot!.toLowerCase() === p.evidenceRoot.toLowerCase()
      && (r.ruling!.outcome === 'RELEASE') === p.releasedToTaker));
  }

  /** Anyone can re-derive who signed a ruling; the desk is not trusted for this. */
  async verify(caseId: string): Promise<{ signer: Hex; matchesDesk: boolean }> {
    const rec = await this.require(caseId);
    if (!rec.ruling || !rec.signature || !rec.evidenceRoot) {
      throw new DisputeError('no ruling yet');
    }
    const signer = await rulingSigner(rec.ruling, rec.evidenceRoot, rec.signature);
    return {
      signer,
      matchesDesk: signer.toLowerCase() === this.arbitrator.address.toLowerCase(),
    };
  }

  /** Refuse to sign what could no longer post and execute before the escrow's deadline. */
  private assertTimeToExecute(c: Case): void {
    const signBy = this.signingDeadline(c);
    if (this.now() >= signBy) {
      throw new DisputeError(
        `too late to rule: the escrow's deadline is ${new Date(c.expiresAt * 1000).toISOString()}, `
        + `and a ruling needs ${this.margin}s to post and execute. The dispute will be refunded `
        + 'by default; anyone can call expireDispute once the deadline passes',
      );
    }
  }

  private async finish(rec: DeskRecord, ruling: Ruling, signature: Hex, root: Hex) {
    rec.ruling = ruling;
    rec.signature = signature;
    rec.evidenceRoot = root;
    rec.status = 'RULED';
    await this.store.put(rec);
    return rec;
  }

  private async require(caseId: string): Promise<DeskRecord> {
    const rec = await this.store.get(caseId);
    if (!rec) throw new DisputeError(`no such case: ${caseId}`);
    return rec;
  }
}

export { evidenceRoot };
