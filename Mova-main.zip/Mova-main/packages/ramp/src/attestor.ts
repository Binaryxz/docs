/**
 * The rails, the terms an order is proven against, and the salted payee commitments (PIX key).
 *
 * The EIP-712 attestor client that signed for AttestorQuorumVerifier, and the card merchant
 * commitments, were removed on 24 September 2026 with the card rail: see docs/card-rail-removal.md.
 */
import { encodeAbiParameters, keccak256, toHex, type Hex } from 'viem';

/** Mirrors IAttestorVerifier.Rail. Order matters - these are the on-chain enum values. */
export enum Rail {
  UNSPECIFIED = 0,
  PIX = 1,
  BOLETO = 2,
  TED = 3,
}

/** Bitmask helper for the railMask an offer or a sale declares. */
export const railMask = (...rails: Rail[]): number =>
  rails.reduce((m, r) => m | (1 << r), 0);

export interface ObservedPayment {
  bankTxId: Hex; // the bank's end-to-end id, hashed
  payeeKeyHash: Hex;
  payerRef: Hex;
  amountBrlCents: bigint;
  paidAt: bigint;
  rail: Rail;
}

export interface OrderTerms {
  orderId: Hex;
  /** The payee commitment on-chain: the offer's or sale's PIX key, or the boleto issued. */
  payeeKeyHash: Hex;
  brlCents: bigint;
  /** The earliest a payment may have happened: the lock, the claim, or the boleto's issue. */
  lockedAt: bigint;
  /** Rails the counterparty declared it will accept. */
  acceptedRails?: Rail[];
}

/*//////////////////////////////////////////////////////////////
                         PIX KEY COMMITMENTS
//////////////////////////////////////////////////////////////*/

/**
 * What goes on-chain in place of a PIX key.
 *
 * This used to be `keccak256(pixKey)`, documented as keeping the key private. It did not,
 * for most real keys. A PIX key is usually a CPF, a phone number or an email, and those
 * spaces are small: there are about a billion valid CPFs, so hashing every one of them and
 * matching the on-chain value takes minutes on a laptop. The "hash" linked an off-ramp sale
 * - money that had just left a privacy pool - to a named person, permanently and publicly.
 *
 * The fix is a commitment with a secret salt:
 *
 *   commitment = keccak256(abi.encode("PrivacyPoolsBRL/pix-key/v1", normalizedKey, salt))
 *
 * with a fresh random 32-byte salt per offer or sale. Without the salt, enumerating every
 * CPF finds nothing. The contracts are unchanged: they only ever compare this value against
 * what an attestor reports, so it was always opaque to them.
 *
 * Who holds the salt: the key's owner generates it and shares key + salt, off-chain, with
 * exactly the parties who need them - the counterparty who must send the PIX, and the
 * attestors who must recompute the commitment from the payee key they observe at the bank.
 *
 * A FRESH salt matters as much as a secret one. Reusing a salt across two sales makes
 * their commitments identical, which links the sales to each other even if nobody learns
 * the key.
 */
export const PIX_COMMITMENT_DOMAIN = 'PrivacyPoolsBRL/pix-key/v1';

export type PixKeyKind = 'cpf' | 'cnpj' | 'phone' | 'email' | 'evp';

export class InvalidPixKey extends Error {}

/** A fresh 32-byte salt. Never reuse one across offers or sales. */
export function newPixSalt(): Hex {
  return toHex(crypto.getRandomValues(new Uint8Array(32)));
}

/**
 * Commit to a PIX key without revealing it.
 * @throws InvalidPixKey if the key is malformed, or the salt is missing or trivial.
 */
export function pixKeyCommitment(pixKey: string, salt: Hex): Hex {
  if (!/^0x[0-9a-fA-F]{64}$/.test(salt)) {
    throw new InvalidPixKey('salt must be 32 bytes of hex - use newPixSalt()');
  }
  if (/^0x0{64}$/.test(salt)) {
    throw new InvalidPixKey('an all-zero salt is no salt: the commitment would be reversible');
  }
  const { key } = normalizePixKey(pixKey);
  return keccak256(encodeAbiParameters(
    [{ type: 'string' }, { type: 'string' }, { type: 'bytes32' }],
    [PIX_COMMITMENT_DOMAIN, key, salt],
  ));
}

/**
 * The canonical form of a PIX key, as the Central Bank's DICT stores it.
 *
 * Normalising is a settlement requirement, not tidiness. The same CPF typed as
 * "529.982.247-25" and as "52998224725" must produce the same commitment, or an attestor
 * that sees the bank's formatting will report a payee that does not match the order, and a
 * payment that really happened will never settle.
 *
 * Validation catches typos at offer time: a CPF with a wrong check digit cannot receive a
 * PIX, and discovering that after a buyer has locked an order wastes their pay window.
 */
export function normalizePixKey(raw: string): { kind: PixKeyKind; key: string } {
  const v = raw.trim();
  if (!v) throw new InvalidPixKey('empty PIX key');

  // Random key (chave aleatória / EVP): a UUID.
  if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v)) {
    return { kind: 'evp', key: v.toLowerCase() };
  }

  if (v.includes('@')) {
    const key = v.toLowerCase();
    if (key.length > 77 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(key)) {
      throw new InvalidPixKey(`not a valid email PIX key: ${raw}`);
    }
    return { kind: 'email', key };
  }

  if (v.startsWith('+')) {
    const digits = v.slice(1).replace(/[\s().-]/g, '');
    if (!/^55\d{10,11}$/.test(digits)) {
      throw new InvalidPixKey(`a phone PIX key must be +55 followed by DDD and number: ${raw}`);
    }
    return { kind: 'phone', key: `+${digits}` };
  }

  const compact = v.replace(/[.\-/\s]/g, '').toUpperCase();
  if (/^\d{11}$/.test(compact)) {
    if (!validCpf(compact)) {
      throw new InvalidPixKey(
        `not a valid CPF: ${raw}. If this is a phone number, write it as +55 followed by the number.`,
      );
    }
    return { kind: 'cpf', key: compact };
  }
  // CNPJ: 14 characters. Since July 2026 the first twelve may be letters (the alphanumeric
  // CNPJ); the two check digits are always numeric.
  if (/^[0-9A-Z]{12}\d{2}$/.test(compact)) {
    if (!validCnpj(compact)) throw new InvalidPixKey(`not a valid CNPJ: ${raw}`);
    return { kind: 'cnpj', key: compact };
  }
  throw new InvalidPixKey(`not a recognisable PIX key (CPF, CNPJ, +55 phone, email or random key): ${raw}`);
}

function validCpf(d: string): boolean {
  if (/^(\d)\1{10}$/.test(d)) return false; // 000.000.000-00 and friends pass the arithmetic
  const n = [...d].map(Number);
  const dv = (len: number) => {
    let sum = 0;
    for (let i = 0; i < len; i++) sum += n[i] * (len + 1 - i);
    return ((sum * 10) % 11) % 10;
  };
  return dv(9) === n[9] && dv(10) === n[10];
}

function validCnpj(c: string): boolean {
  if (/^(.)\1{13}$/.test(c)) return false;
  // Character value is its code minus 48: digits keep their value, A=17, B=18, ...
  const v = [...c].map((ch) => ch.charCodeAt(0) - 48);
  const dv = (len: number) => {
    const w = len === 12 ? [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2] : [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
    let sum = 0;
    for (let i = 0; i < len; i++) sum += v[i] * w[i];
    const r = sum % 11;
    return r < 2 ? 0 : 11 - r;
  };
  return dv(12) === v[12] && dv(13) === v[13];
}
