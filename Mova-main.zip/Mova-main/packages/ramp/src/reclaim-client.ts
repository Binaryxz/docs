/**
 * Talking to the real Reclaim attestor network (task 2.2, the last mile).
 *
 * `reclaim.ts` builds and encodes proofs. This is the part that obtains one from the live
 * network and checks it is usable before it costs a transaction to find out.
 *
 * ## What still needs a human, and why it is not a code gap
 *
 * A Reclaim proof attests to a TLS session between a REAL PERSON and their REAL BANK. It
 * cannot be manufactured server-side, by us or by anyone: the taker opens the session, the
 * witnesses observe the ciphertext, and a proof exists only if a payment actually happened.
 * So going live needs two things this repo cannot contain — an application credential from
 * Reclaim's dashboard, and a provider template describing the bank's receipt page.
 *
 * Everything either of those touches is here: request construction, session polling, format
 * conversion, signature ordering, and verification against the witness set the CHAIN holds.
 * Supply `appId`/`providerId` and this talks to production.
 *
 * ## The checks that matter most
 *
 * `assertWitnessesRegistered` compares a proof's recovered signers against
 * `ReclaimZkTlsVerifier.isWitness` on-chain, and `assertEndpointAllowed` compares the bank
 * endpoint the proof attests against the verifier's endpoint allowlist. Neither is defensive
 * tidiness: the verifier rejects both anyway, but it does so inside a settlement
 * transaction, after the taker has already sent BRL. Catching a mismatch here turns a lost
 * settlement into an error message.
 */
import type { Address, Hex, PublicClient } from 'viem';
import {
  fromReclaimProof, proofSigners, sortSignatures, encodeProof, bindingContext, proofEndpoint,
  proofPayment, ReclaimProofError, type ReclaimProof, type ReclaimSdkProof,
} from './reclaim.js';
import { Rail } from './attestor.js';

export interface ReclaimClientConfig {
  /** From the Reclaim dashboard. Identifies your application to the network. */
  appId: string;
  /** The provider template describing the bank's receipt page. */
  providerId: string;
  /** Reclaim's backend. Overridable for staging or a self-hosted attestor set. */
  baseUrl?: string;
  /** How long to wait for the user to complete the session, ms. */
  timeoutMs?: number;
  /** How often to poll, ms. */
  pollMs?: number;
  fetchImpl?: typeof fetch;
}

export interface ProofSession {
  sessionId: string;
  /** Where to send the user. They open this, log in to their bank, and the proof is made. */
  url: string;
}

const WITNESS_FN = {
  type: 'function',
  name: 'isWitness',
  stateMutability: 'view',
  inputs: [{ type: 'address' }],
  outputs: [{ type: 'bool' }],
} as const;

const RAILS_FN = {
  type: 'function',
  name: 'endpointRails',
  stateMutability: 'view',
  inputs: [{ type: 'bytes32' }],
  outputs: [{ type: 'uint16' }],
} as const;

const ENDPOINT_FN = {
  type: 'function',
  name: 'endpointUrlPrefix',
  stateMutability: 'view',
  inputs: [{ type: 'bytes32' }],
  outputs: [{ type: 'string' }],
} as const;

export class ReclaimSessionError extends Error {}

export class ReclaimClient {
  private readonly baseUrl: string;
  private readonly timeoutMs: number;
  private readonly pollMs: number;
  private readonly http: typeof fetch;

  constructor(private readonly cfg: ReclaimClientConfig) {
    this.baseUrl = cfg.baseUrl ?? 'https://api.reclaimprotocol.org';
    this.timeoutMs = cfg.timeoutMs ?? 5 * 60_000;
    this.pollMs = cfg.pollMs ?? 2_000;
    // A plain function: a browser refuses the global fetch called as a method ("Illegal invocation").
    const f = cfg.fetchImpl;
    this.http = (input, init) => (f ?? globalThis.fetch)(input, init);
  }

  /**
   * Start a session for one order.
   *
   * The context carries the order id and NOTHING about the payment. Binding at request time
   * is what makes the resulting proof unusable against any other order - the identifier
   * commits to the context, so a proof cannot be re-pointed later. The payment fields are
   * written by the witness from the bank's response; an earlier version sent them here,
   * which made the payer the author of their own receipt.
   */
  async requestProof(orderId: Hex): Promise<ProofSession> {
    const body = {
      applicationId: this.cfg.appId,
      providerId: this.cfg.providerId,
      context: JSON.stringify(bindingContext(orderId)),
    };
    const res = await this.http(`${this.baseUrl}/api/sessions`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      throw new ReclaimSessionError(
        `Reclaim refused the session request (${res.status}). Check appId and providerId.`,
      );
    }
    const json = await res.json() as { sessionId?: string; id?: string; url?: string; link?: string };
    const sessionId = json.sessionId ?? json.id;
    const url = json.url ?? json.link;
    if (!sessionId || !url) {
      throw new ReclaimSessionError('Reclaim returned no session id or link');
    }
    return { sessionId, url };
  }

  /**
   * Wait for the user to finish, then return the proof in our on-chain form.
   *
   * Times out rather than polling forever: a session the user abandoned is the normal case,
   * not an error condition, and an escrow order has its own pay window that will expire
   * regardless of how patient this loop is.
   */
  async awaitProof(sessionId: string, now = () => Date.now()): Promise<ReclaimProof> {
    const deadline = now() + this.timeoutMs;
    for (;;) {
      const res = await this.http(`${this.baseUrl}/api/sessions/${sessionId}`);
      if (res.ok) {
        const json = await res.json() as { status?: string; proof?: ReclaimSdkProof; proofs?: ReclaimSdkProof[] };
        const proof = json.proof ?? json.proofs?.[0];
        if (proof) return sortSignatures(fromReclaimProof(proof));
        if (json.status && /fail|error|expired|cancel/i.test(json.status)) {
          throw new ReclaimSessionError(`the session ended without a proof: ${json.status}`);
        }
      }
      if (now() >= deadline) {
        throw new ReclaimSessionError(
          `no proof after ${Math.round(this.timeoutMs / 1000)}s; the user likely did not finish`,
        );
      }
      await new Promise((r) => setTimeout(r, this.pollMs));
    }
  }

  /** Convert a proof obtained by other means (the mobile SDK, a QR flow). */
  static adopt(sdkProof: ReclaimSdkProof): Promise<ReclaimProof> {
    return sortSignatures(fromReclaimProof(sdkProof));
  }
}

/**
 * Check a proof's witnesses against the set the verifier contract actually holds.
 *
 * Reclaim rotates its attestor set by epoch; a verifier configured months ago can fall
 * behind. Discovering that here costs an error message, discovering it on-chain costs a
 * settlement the taker has already paid for.
 */
export async function assertWitnessesRegistered(
  client: PublicClient,
  verifier: Address,
  proof: ReclaimProof,
): Promise<Address[]> {
  const signers = await proofSigners(proof);
  const unknown: Address[] = [];
  for (const s of signers) {
    const known = await client.readContract({
      address: verifier, abi: [WITNESS_FN], functionName: 'isWitness', args: [s],
    }) as boolean;
    if (!known) unknown.push(s);
  }
  if (unknown.length > 0) {
    throw new ReclaimProofError(
      `proof signed by witnesses the verifier does not know: ${unknown.join(', ')}. `
      + 'Reclaim rotates its attestor set by epoch - the governor must register the current '
      + 'witnesses with setWitness before proofs from this epoch can settle, and adding a '
      + 'witness waits out the governance delay, so schedule it when the epoch is announced.',
    );
  }
  return signers;
}

/**
 * Check the bank endpoint a proof attests against the verifier's allowlist.
 *
 * The verifier settles a proof only if its witness-written `providerHash` is allowlisted and
 * its `url` starts with the prefix allowlisted for that template. A proof of a session with
 * any other server - however genuinely signed - settles nothing.
 */
export async function assertEndpointAllowed(
  client: PublicClient,
  verifier: Address,
  proof: ReclaimProof,
): Promise<{ providerHash: Hex; urlPrefix: string }> {
  const { providerHash, url } = proofEndpoint(proof);
  const urlPrefix = await client.readContract({
    address: verifier, abi: [ENDPOINT_FN], functionName: 'endpointUrlPrefix', args: [providerHash],
  }) as string;
  if (!urlPrefix) {
    throw new ReclaimProofError(
      `proof attests provider template ${providerHash}, which the verifier does not allow. `
      + 'Only allowlisted bank endpoints settle; the governor adds one with allowEndpoint.',
    );
  }
  if (!url.startsWith(urlPrefix)) {
    throw new ReclaimProofError(`proof url ${url} is outside the allowed prefix ${urlPrefix}`);
  }
  return { providerHash, urlPrefix };
}

/**
 * Check the rail a proof attests is one its endpoint is allowlisted for.
 *
 * A PIX-receipt template cannot vouch for a boleto payment, and the verifier refuses one that
 * tries (`RailNotAllowedForEndpoint`). Most likely cause in practice: a boleto receipt proven
 * against a template that was allowlisted before anyone widened it to BOLETO.
 */
export async function assertEndpointRail(
  client: PublicClient,
  verifier: Address,
  proof: ReclaimProof,
): Promise<Rail> {
  const { providerHash } = proofEndpoint(proof);
  const { rail } = proofPayment(proof);
  const mask = Number(await client.readContract({
    address: verifier, abi: [RAILS_FN], functionName: 'endpointRails', args: [providerHash],
  }));
  if (((mask >> rail) & 1) === 0) {
    throw new ReclaimProofError(
      `the endpoint ${providerHash} is not allowlisted for ${Rail[rail]} payments. `
      + 'Widening an endpoint to a rail is setEndpointRails, which waits out the governance delay.',
    );
  }
  return rail;
}

/** Everything the escrow needs, checked before it costs a transaction. */
export async function prepareSettlement(
  client: PublicClient,
  verifier: Address,
  proof: ReclaimProof,
): Promise<{ encoded: Hex; witnesses: Address[]; providerHash: Hex; rail: Rail }> {
  const { providerHash } = await assertEndpointAllowed(client, verifier, proof);
  const rail = await assertEndpointRail(client, verifier, proof);
  const witnesses = await assertWitnessesRegistered(client, verifier, proof);
  return { encoded: encodeProof(proof), witnesses, providerHash, rail };
}
