/**
 * Publisher client for SignedPriceOracle (task 2.5).
 *
 * A publisher observes a BRL rate off-chain - a bank's FX desk, B3, a market-data vendor -
 * and signs it. A quorum of them keeps the oracle alive on a chain with no maintained BRL
 * feed. The signature is public and attributable: whoever signed a bad price can be named.
 *
 * Two rules here that the contract cannot enforce for you:
 *
 *  - **Sequence must increase, globally.** The contract rejects a sequence it has already
 *    passed, so publishers that disagree about the next number simply waste gas. Derive it
 *    from a shared clock (the timestamp is the obvious choice) rather than a local counter,
 *    or two publishers signing independently will produce unusable pairs.
 *  - **Sign what you observed, not what you were sent.** A quorum whose members all relay
 *    one feed is a 1-of-N dressed as M-of-N, and it will look healthy right up until that
 *    feed is wrong.
 *
 * ## The FX leg: one number for every asset
 *
 * On Ethereum L1 the deployment's publishers sign the BRL/USD rate and nothing else
 * (`ORACLE_KIND=signed-fx` in DeployRamp.s.sol). Their SignedPriceOracle's `brlCentsPerUnit`
 * then means **centavos per ONE US DOLLAR** - about 540 at R$5.40 - and each asset's band is a
 * `ChainlinkSignedFxOracle` crossing it with that asset's Chainlink USD feed. A publisher no
 * longer signs an ETH price and a USDT price; a USDT depeg reaches the band through Chainlink.
 *
 * The same signing format serves both kinds of oracle, which is exactly why the FX helpers
 * below exist. Nothing on-chain can tell 540 (R$5.40 per dollar) from 19 (the same quote
 * inverted: USD per BRL x 100) or from an ETH price signed into the wrong oracle. Each of those
 * fails closed - every offer falls outside the band - and each is an outage the publisher
 * caused. `fxCentsPerUsd` makes the quote's direction part of its type and refuses a result
 * outside a plausibility range before anything is signed; `signFx` is the only path that
 * should be used against an FX leg.
 *
 * ## The Movva reserve's leg: the same rate at 1e-6
 *
 * The Movva reserve (docs/movva.md) mints and redeems at `Chainlink USDT/USD x signed BRL/USD`, and
 * a centavo is too coarse for that: one tick at R$5.40 is 0.19%, value an LP could take on every
 * mint and redeem. So the reserve's SignedPriceOracle instance is signed in MICRO-reais per dollar
 * (R$5.4012 = 5_401_200) - the same contract and message, whose `brlCentsPerUnit` field then holds
 * reais x 1e6. `fxMicroPerUsd` and `signFxMicro` are the 1e-6 twins of the centavo helpers, with the
 * same direction-named input and the same sanity range (R$1 to R$100, from `FxBounds` scaled by
 * 10_000), so a quote cannot be inverted or mis-scaled into either oracle.
 *
 * The ramps' centavo band for Movva is derived from that signed number, not signed separately, so
 * both must come from ONE observation: `fxObservation` returns the micro value and
 * `centsFromMicroPerUsd` of it - the nearest centavo, halves up, as the band adapter exposes it.
 * Rounding the quote to centavos directly can land one centavo away (5.404999999 is 540 centavos
 * directly but 5.405000 micro, hence 541), and two oracles one tick apart are a band that disagrees
 * with the reserve it is meant to track.
 */
import { keccak256, encodeAbiParameters, encodePacked, type Hex, type Address } from 'viem';
import { privateKeyToAccount } from 'viem/accounts';

export const PRICE_TYPES = {
  Price: [
    { name: 'brlCentsPerUnit', type: 'uint256' },
    { name: 'publishedAt', type: 'uint64' },
    { name: 'sequence', type: 'uint64' },
  ],
} as const;

export const priceDomain = (chainId: number, oracle: Address) => ({
  name: 'PrivacyPoolsBRL-Price',
  version: '1',
  chainId,
  verifyingContract: oracle,
});

export interface SignedPrice {
  brlCentsPerUnit: bigint;
  publishedAt: bigint;
  sequence: bigint;
  signer: Address;
  signature: Hex;
}

/**
 * A BRL/USD quote, with its direction in the field name.
 *
 * The two directions are reciprocals and both are in common use: PTAX, FX desks and Pyth's
 * `FX.USD/BRL` quote reais per dollar (~5.40); Chainlink's BRL/USD aggregator quotes dollars per
 * real (~0.185). Mixing them up is SR2-9, which shipped once already. Decimal strings, not
 * numbers, so no binary float sits between the quote and the signature.
 */
export type FxQuote = { brlPerUsd: string } | { usdPerBrl: string };

/** The range a signed FX rate must fall in, in centavos per US dollar. */
export interface FxBounds {
  minCents: bigint;
  maxCents: bigint;
}

/**
 * R$1.00 to R$100.00 per dollar. Not a market view: a guard against the two mistakes that
 * produce a number the contract accepts and the band cannot use - an inverted quote lands near
 * 19, a rate scaled by 1e8 or an ETH price lands in the hundreds of millions. Pass explicit
 * bounds to narrow it.
 */
export const FX_SANITY: FxBounds = { minCents: 100n, maxCents: 10_000n };

const DECIMAL = /^\d+(\.\d+)?$/;

function parseDecimal(v: string, what: string): { n: bigint; scale: bigint } {
  if (!DECIMAL.test(v)) throw new Error(`${what} must be a plain decimal like "5.4049"; got "${v}"`);
  const [whole, frac = ''] = v.split('.');
  return { n: BigInt(whole + frac), scale: 10n ** BigInt(frac.length) };
}

/** a / b rounded to the nearest integer, halves up. Both positive. */
const roundDiv = (a: bigint, b: bigint): bigint => (2n * a + b) / (2n * b);

/**
 * Centavos per US dollar, to the nearest centavo, from a quote in either direction.
 *
 * @example fxCentsPerUsd({ brlPerUsd: '5.4049' })  // 540n
 * @example fxCentsPerUsd({ usdPerBrl: '0.18502' }) // 540n  (100 / 0.18502 = 540.48)
 */
export function fxCentsPerUsd(quote: FxQuote, bounds: FxBounds = FX_SANITY): bigint {
  let cents: bigint;
  if ('brlPerUsd' in quote) {
    const { n, scale } = parseDecimal(quote.brlPerUsd, 'brlPerUsd');
    cents = roundDiv(n * 100n, scale);
  } else {
    const { n, scale } = parseDecimal(quote.usdPerBrl, 'usdPerBrl');
    if (n === 0n) throw new Error('usdPerBrl must be positive');
    cents = roundDiv(100n * scale, n);
  }
  if (cents < bounds.minCents) {
    throw new Error(
      `FX rate of ${cents} centavos per dollar is below ${bounds.minCents}: is the quote inverted `
      + '(dollars per real passed as brlPerUsd)?',
    );
  }
  if (cents > bounds.maxCents) {
    throw new Error(
      `FX rate of ${cents} centavos per dollar is above ${bounds.maxCents}: is it mis-scaled, `
      + 'or an asset price rather than the BRL/USD rate?',
    );
  }
  return cents;
}

/** Micro-reais per centavo: the 1e-6 leg is the centavo leg times this. */
const MICRO_PER_CENT = 10_000n;

/**
 * Reais per US dollar scaled by 1e6, to the nearest micro-real, from a quote in either direction -
 * the value signed into the Movva reserve's SignedPriceOracle. Bounds are the centavo bounds
 * (`FX_SANITY` by default), applied at 1e-6: the same R$1 to R$100 either way.
 *
 * @example fxMicroPerUsd({ brlPerUsd: '5.4012' })    // 5_401_200n
 * @example fxMicroPerUsd({ usdPerBrl: '0.18502' })   // 5_404_821n (1 / 0.18502 = 5.40482110...)
 */
export function fxMicroPerUsd(quote: FxQuote, bounds: FxBounds = FX_SANITY): bigint {
  let micro: bigint;
  if ('brlPerUsd' in quote) {
    const { n, scale } = parseDecimal(quote.brlPerUsd, 'brlPerUsd');
    micro = roundDiv(n * 1_000_000n, scale);
  } else {
    const { n, scale } = parseDecimal(quote.usdPerBrl, 'usdPerBrl');
    if (n === 0n) throw new Error('usdPerBrl must be positive');
    micro = roundDiv(1_000_000n * scale, n);
  }
  const minMicro = bounds.minCents * MICRO_PER_CENT;
  const maxMicro = bounds.maxCents * MICRO_PER_CENT;
  if (micro < minMicro) {
    throw new Error(
      `FX rate of ${micro} micro-reais per dollar is below ${minMicro}: is the quote inverted `
      + '(dollars per real passed as brlPerUsd)?',
    );
  }
  if (micro > maxMicro) {
    throw new Error(
      `FX rate of ${micro} micro-reais per dollar is above ${maxMicro}: is it mis-scaled, `
      + 'or an asset price rather than the BRL/USD rate?',
    );
  }
  return micro;
}

/**
 * The centavo value a band adapter over the 1e-6 leg exposes: the nearest centavo, halves up
 * (`(micro + 5_000) / 10_000`). Refuses zero and below, as the oracles do.
 */
export function centsFromMicroPerUsd(microPerUsd: bigint): bigint {
  if (microPerUsd <= 0n) throw new Error('FX rate must be positive');
  const cents = (microPerUsd + MICRO_PER_CENT / 2n) / MICRO_PER_CENT;
  if (cents === 0n) throw new Error('FX rate rounds to zero centavos per dollar');
  return cents;
}

/**
 * One observation, both precisions: the micro value for the Movva reserve's oracle and the centavo
 * value derived from it, bounds-checked at both. Sign `microPerUsd` with `signFxMicro` and, where a
 * centavo oracle is still signed separately, `centsPerUsd` with `sign` - never a second conversion
 * of the quote.
 */
export function fxObservation(quote: FxQuote, bounds: FxBounds = FX_SANITY): { microPerUsd: bigint; centsPerUsd: bigint } {
  const microPerUsd = fxMicroPerUsd(quote, bounds);
  const centsPerUsd = centsFromMicroPerUsd(microPerUsd);
  if (centsPerUsd < bounds.minCents || centsPerUsd > bounds.maxCents) {
    throw new Error(`FX rate of ${centsPerUsd} centavos per dollar is outside ${bounds.minCents}-${bounds.maxCents}`);
  }
  return { microPerUsd, centsPerUsd };
}

/**
 * The band midpoint a ChainlinkSignedFxOracle will report, from the same inputs - so a publisher
 * or LP can see what an FX rate does to each asset's band before signing or quoting.
 *
 * Mirrors the contract exactly: `(answer * fxCents + 10^d / 2) / 10^d`, refusing a non-positive
 * answer, feed decimals above 18 and a result of zero. The vectors in the tests are the ones
 * contracts/test/ChainlinkSignedFxOracle.t.sol asserts on-chain.
 */
export function crossBrlCentsPerUnit(assetUsdAnswer: bigint, feedDecimals: number, fxCents: bigint): bigint {
  if (assetUsdAnswer <= 0n) throw new Error('feed answer must be positive');
  if (!Number.isInteger(feedDecimals) || feedDecimals < 0 || feedDecimals > 18) {
    throw new Error(`feed decimals out of range: ${feedDecimals}`);
  }
  if (fxCents <= 0n) throw new Error('FX rate must be positive');
  const scale = 10n ** BigInt(feedDecimals);
  const price = (assetUsdAnswer * fxCents + scale / 2n) / scale;
  if (price === 0n) throw new Error('price rounds to zero centavos per token');
  return price;
}

export class PricePublisher {
  private readonly account;

  constructor(privateKey: Hex, readonly chainId: number, readonly oracle: Address) {
    this.account = privateKeyToAccount(privateKey);
  }

  get address(): Address {
    return this.account.address;
  }

  async sign(brlCentsPerUnit: bigint, publishedAt: bigint, sequence: bigint): Promise<SignedPrice> {
    if (brlCentsPerUnit <= 0n) throw new Error('price must be positive');
    const signature = await this.account.signTypedData({
      domain: priceDomain(this.chainId, this.oracle),
      types: PRICE_TYPES,
      primaryType: 'Price',
      message: { brlCentsPerUnit, publishedAt, sequence },
    });
    return { brlCentsPerUnit, publishedAt, sequence, signer: this.account.address, signature };
  }

  /**
   * Sign a BRL/USD rate for an FX leg. Use this, never `sign`, against the SignedPriceOracle a
   * ChainlinkSignedFxOracle crosses with: it converts the quote from its named direction and
   * refuses a result outside `bounds` before a signature exists.
   */
  async signFx(
    quote: FxQuote, publishedAt: bigint, sequence: bigint, bounds: FxBounds = FX_SANITY,
  ): Promise<SignedPrice> {
    return this.sign(fxCentsPerUsd(quote, bounds), publishedAt, sequence);
  }

  /**
   * Sign a BRL/USD rate at 1e-6 (micro-reais per dollar) for the Movva reserve's SignedPriceOracle.
   * Use this, never `sign` or `signFx`, against that oracle: a centavo value there reads as a rate
   * 10,000 times too small, and the reserve would mint 10,000 times too little Movva - or, the other
   * way round, the escrows' centavo band would read R$54,012 per dollar.
   *
   * The returned `brlCentsPerUnit` field holds micro-reais: it is the contract's field name, not the unit.
   */
  async signFxMicro(
    quote: FxQuote, publishedAt: bigint, sequence: bigint, bounds: FxBounds = FX_SANITY,
  ): Promise<SignedPrice> {
    return this.sign(fxMicroPerUsd(quote, bounds), publishedAt, sequence);
  }
}

/**
 * Collect a quorum into the argument order `submit` expects.
 *
 * Rejects a set that disagrees about what it is signing, rather than letting the contract
 * discover it: signatures over different messages recover to strangers, and the on-chain
 * error would be `UnknownPublisher` - which points at the wrong problem entirely.
 */
export function collectQuorum(signed: SignedPrice[]): {
  brlCentsPerUnit: bigint;
  publishedAt: bigint;
  sequence: bigint;
  signatures: Hex[];
} {
  if (signed.length === 0) throw new Error('no signatures');
  const [head] = signed;
  for (const s of signed) {
    if (
      s.brlCentsPerUnit !== head.brlCentsPerUnit
      || s.publishedAt !== head.publishedAt
      || s.sequence !== head.sequence
    ) {
      throw new Error('publishers signed different prices; they must agree before submitting');
    }
  }
  const seen = new Set<string>();
  for (const s of signed) {
    const k = s.signer.toLowerCase();
    if (seen.has(k)) throw new Error(`duplicate publisher: ${s.signer}`);
    seen.add(k);
  }
  return {
    brlCentsPerUnit: head.brlCentsPerUnit,
    publishedAt: head.publishedAt,
    sequence: head.sequence,
    // Ascending by signer, as the contract requires.
    signatures: [...signed]
      .sort((a, b) => (BigInt(a.signer) < BigInt(b.signer) ? -1 : 1))
      .map((s) => s.signature),
  };
}

/** A sequence derived from a shared clock, so independent publishers agree. */
export function sequenceFromTime(publishedAt: bigint): bigint {
  return publishedAt;
}

export { keccak256, encodeAbiParameters, encodePacked };
