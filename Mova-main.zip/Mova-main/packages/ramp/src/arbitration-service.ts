/**
 * The arbitration desk as a service the protocol runs (task 2.6).
 *
 * `arbitration-desk.ts` is the process — intake, deadlines, signed rulings.  This puts it
 * behind HTTP so parties can file and follow a case, and so an operator can work a queue.
 *
 * ## The asymmetry that shapes the routes
 *
 * This service HOLDS THE ARBITRATOR KEY, which the matcher deliberately does not. So the
 * routes are split by what they can cost:
 *
 *  - **Open, and gated by the chain.** No operator credential is involved in opening a case
 *    or submitting evidence, because requiring one would make the desk a gatekeeper on
 *    whether a dispute may be raised at all. Opening is gated by the escrow instead: a case
 *    opens only for an order the escrow reports DISPUTED (which only its parties can cause),
 *    once, with parties read from the escrow and the window and default from desk policy.
 *    Evidence carries a party's own signature, checked against those recorded parties.
 *  - **Public reads.** Anyone may read a case and verify a ruling's signer. A dispute
 *    process nobody can inspect is indistinguishable from one that is not happening. A case is
 *    found by its id, or by the exact escrow and order id it is for (`GET /cases?escrow=&orderId=`):
 *    a party whose counterparty filed first needs the id, and which orders are disputed is public
 *    on-chain already. There is no listing of all cases beyond `/due`.
 *  - **Operator-only.** Ruling requires a bearer token. It is the only action that produces
 *    a signature, and a signature is what the escrow will act on.
 *
 * Even fully compromised, the desk can only mis-rule disputes that are already open, and
 * slowly: the escrow acts only on a registered arbitrator's signature for an order actually in
 * DISPUTED, only after posting it publicly for RULING_DELAY, and only if the arbitrator is
 * still registered when it executes - so a governor that revokes the key in that day voids
 * the rulings. It cannot reach a healthy order, an LP's free liquidity, or the pool.
 *
 * The token is compared with a constant-time check. A naive `===` on a secret leaks its
 * length and prefix to anyone who can time requests, which is a silly way to lose the only
 * credential that can sign.
 */
import { createServer, type Server, type IncomingMessage, type ServerResponse } from 'node:http';
import { timingSafeEqual } from 'node:crypto';
import type { Hex } from 'viem';
import { ArbitrationDesk, type DeskRecord, type OpenCaseInput } from './arbitration-desk.js';
import { redact } from '@mova/ops/redact';
import { DisputeError, type Ruling } from './disputes.js';

export interface ArbitrationServiceOptions {
  desk: ArbitrationDesk;
  /** Required for the ruling routes. Without one, they are disabled entirely. */
  operatorToken?: string;
  /**
   * Values that must never appear in a response: the RPC URL, the token, the key. Intake
   * reads the escrow over RPC, so an RPC failure surfaces here as a viem error carrying the
   * URL. URLs are cut to scheme and host regardless; the operator token is always included.
   */
  redactValues?: readonly string[];
}

export class ArbitrationService {
  private server?: Server;

  constructor(private readonly opts: ArbitrationServiceOptions) {}

  async listen(port = 0): Promise<number> {
    this.server = createServer((rq, rs) => void this.handle(rq, rs));
    await new Promise<void>((res) => this.server!.listen(port, res));
    const addr = this.server.address();
    return typeof addr === 'object' && addr ? addr.port : port;
  }

  async close(): Promise<void> {
    if (this.server) await new Promise<void>((r) => this.server!.close(() => r()));
  }

  /** Constant-time, and false when no token is configured at all. */
  private authorised(rq: IncomingMessage): boolean {
    const expected = this.opts.operatorToken;
    if (!expected) return false;
    const got = (rq.headers.authorization ?? '').replace(/^Bearer\s+/i, '');
    const a = Buffer.from(got);
    const b = Buffer.from(expected);
    if (a.length !== b.length) return false;
    return timingSafeEqual(a, b);
  }

  /** Never leaks the arbitrator's key material, only what a party may see. */
  private view(rec: DeskRecord) {
    return {
      caseId: rec.caseId,
      status: rec.status,
      orderId: rec.case.orderId,
      escrow: rec.case.escrow,
      leg: rec.case.leg,
      raisedBy: rec.case.raisedBy,
      reason: rec.case.reason,
      raisedAt: rec.case.raisedAt,
      respondBy: rec.case.respondBy,
      expiresAt: rec.case.expiresAt,
      defaultRuling: rec.case.defaultRuling,
      parties: rec.case.parties,
      evidence: rec.case.evidence,
      ruling: rec.ruling ?? null,
      evidenceRoot: rec.evidenceRoot ?? null,
      signature: rec.signature ?? null,
    };
  }

  private async handle(rq: IncomingMessage, rs: ServerResponse): Promise<void> {
    const url = new URL(rq.url ?? '/', 'http://localhost');
    /**
     * @dev The replacer is load-bearing, not cosmetic. `toOnChainCall` returns a bigint
     *      (`ruledAt`), and plain `JSON.stringify` throws on one. That throw happens INSIDE
     *      the response writer, so the catch below calls `send` again, which throws again -
     *      and the request hangs forever rather than failing. A 500 would have been fine; a
     *      socket that never answers is not, and it looks like a network problem.
     */
    const send = (code: number, body: unknown) => {
      const json = JSON.stringify(
        body, (_k, v) => (typeof v === 'bigint' ? v.toString() : v), 2,
      );
      rs.writeHead(code, { 'content-type': 'application/json' });
      rs.end(json);
    };
    const body = async <T>(): Promise<T> => {
      const chunks: Buffer[] = [];
      for await (const c of rq) chunks.push(c as Buffer);
      try {
        return JSON.parse(Buffer.concat(chunks).toString() || '{}') as T;
      } catch {
        throw new DisputeError('request body is not valid JSON');
      }
    };

    try {
      const parts = url.pathname.split('/').filter(Boolean);

      if (url.pathname === '/health') {
        return send(200, {
          ok: true,
          arbitrator: this.opts.desk.arbitratorAddress,
          rulingEnabled: Boolean(this.opts.operatorToken),
        });
      }

      // --- open, self-authenticating -------------------------------------------------
      if (rq.method === 'POST' && url.pathname === '/cases') {
        // The whole body goes to the desk, not a picked subset: the desk refuses `parties`,
        // `responseWindowSeconds` and `defaultRuling` outright, and silently dropping them
        // here would hide that refusal from a client that still sends them.
        const b = await body<OpenCaseInput>();
        if (typeof b !== 'object' || b === null || !b.orderId || !b.escrow || !b.raisedBy || !b.reason) {
          return send(400, { error: 'orderId, escrow, raisedBy and reason are required' });
        }
        return send(201, this.view(await this.opts.desk.open(b)));
      }

      if (rq.method === 'POST' && parts[0] === 'cases' && parts[2] === 'evidence') {
        const b = await body<{ digest: Hex; kind: string; uri?: string; signature: Hex }>();
        if (!b.signature) return send(400, { error: 'signature is required' });
        const rec = await this.opts.desk.submitEvidence(
          parts[1], { digest: b.digest, kind: b.kind, uri: b.uri }, b.signature,
        );
        return send(200, this.view(rec));
      }

      // --- public reads ---------------------------------------------------------------
      if (rq.method === 'GET' && url.pathname === '/cases') {
        const escrow = url.searchParams.get('escrow');
        const orderId = url.searchParams.get('orderId');
        if (!escrow || !orderId) return send(400, { error: 'escrow and orderId are required: cases are found one order at a time' });
        const rec = await this.opts.desk.findByOrder(escrow, orderId);
        return rec ? send(200, this.view(rec)) : send(404, { error: 'no such case' });
      }

      if (rq.method === 'GET' && parts[0] === 'cases' && parts.length === 2) {
        const rec = await this.opts.desk.get(parts[1]);
        return rec ? send(200, this.view(rec)) : send(404, { error: 'no such case' });
      }

      if (rq.method === 'GET' && parts[0] === 'cases' && parts[2] === 'verify') {
        return send(200, await this.opts.desk.verify(parts[1]));
      }

      if (rq.method === 'GET' && url.pathname === '/due') {
        const due = await this.opts.desk.dueCases();
        return send(200, { cases: due.map((r) => this.view(r)) });
      }

      // --- operator only --------------------------------------------------------------
      if (rq.method === 'POST' && parts[0] === 'cases' && parts[2] === 'rule') {
        if (!this.authorised(rq)) return send(401, { error: 'operator token required' });
        const b = await body<{
          outcome: Ruling['outcome']; rationale: string; reliedOn: Hex[]; byDefault?: boolean;
        }>();
        const rec = b.byDefault
          ? await this.opts.desk.ruleByDefault(parts[1])
          : await this.opts.desk.rule(parts[1], b.outcome, b.rationale, b.reliedOn ?? []);
        return send(200, this.view(rec));
      }

      if (rq.method === 'GET' && parts[0] === 'cases' && parts[2] === 'submission') {
        if (!this.authorised(rq)) return send(401, { error: 'operator token required' });
        return send(200, await this.opts.desk.submission(parts[1]));
      }

      send(404, {
        error: 'not found',
        routes: [
          'GET /health', 'POST /cases', 'POST /cases/:id/evidence', 'GET /cases?escrow=&orderId=', 'GET /cases/:id',
          'GET /cases/:id/verify', 'GET /due', 'POST /cases/:id/rule (operator)',
          'GET /cases/:id/submission (operator)',
        ],
      });
    } catch (e) {
      // A DisputeError is the caller's fault and says so; anything else is ours. Guarded so
      // a failure while writing the error cannot leave the socket open with no answer.
      const message = e instanceof Error ? e.message : String(e);
      try {
        send(e instanceof DisputeError ? 400 : 500, {
          error: redact(message, [...(this.opts.redactValues ?? []), this.opts.operatorToken]),
        });
      } catch {
        rs.writeHead(500, { 'content-type': 'application/json' });
        rs.end('{"error":"internal error while serialising the response"}');
      }
    }
  }
}
