/**
 * Rebuild the live order book from escrow events (task 2.4, the service half).
 *
 * ## The book is derived, never authoritative
 *
 * Everything here is reconstructed from `OfferPosted` / `OfferFunded` / `OrderLocked` /
 * `OrderReleased` / `OfferClosed` and then reconciled against the escrow's own storage. The
 * matcher therefore holds no state a restart could lose and no state an operator could
 * quietly edit: wipe the process and it rebuilds identically from the chain.
 *
 * That is what keeps a matching service from becoming an exchange. If the book lived in the
 * operator's database, "which offers exist and at what price" would be the operator's claim
 * rather than a fact, and a taker would have to trust it. Here the worst a malicious matcher
 * can do is omit or misreport offers - and a taker who suspects that can rebuild the book
 * themselves from the same events, with this module.
 *
 * ## Why storage is read back rather than trusted to the event replay
 *
 * Replaying events gives the shape of an offer; it does not reliably give `availableWei`,
 * because liquidity moves on paths that emit no event of their own (an order expiring,
 * a dispute resolving). Reading `offers(id)` after the replay costs one call per offer and
 * removes a whole class of drift where the matcher quotes liquidity that is already spoken
 * for. Events tell us WHICH offers to look at; the contract tells us their state.
 */
import type { Address, Hex, PublicClient } from 'viem';
import type { Offer } from './orderbook.js';
import { Rail } from './attestor.js';

export interface IndexerConfig {
  client: PublicClient;
  escrow: Address;
  registry: Address;
  /** Block to start from. Below this the escrow did not exist. */
  fromBlock: bigint;
  /** Max blocks per eth_getLogs request; public RPCs cap this. */
  span?: bigint;
}

const OFFER_POSTED = {
  type: 'event',
  name: 'OfferPosted',
  inputs: [
    { name: 'offerId', type: 'bytes32', indexed: true },
    { name: 'lp', type: 'address', indexed: true },
    { name: 'wei_', type: 'uint256', indexed: false },
    { name: 'price', type: 'uint256', indexed: false },
  ],
} as const;

/** `FiatEscrow.offers(bytes32)`. Exported because the arbitration desk reads the LP from it. */
export const OFFERS_FN = {
  type: 'function',
  name: 'offers',
  stateMutability: 'view',
  inputs: [{ type: 'bytes32' }],
  outputs: [
    { name: 'lp', type: 'address' },
    { name: 'asset', type: 'address' },
    { name: 'availableWei', type: 'uint256' },
    { name: 'lockedWei', type: 'uint256' },
    { name: 'priceBrlCentsPerEth', type: 'uint256' },
    { name: 'pixKeyHash', type: 'bytes32' },
    { name: 'minOrderWei', type: 'uint256' },
    { name: 'maxOrderWei', type: 'uint256' },
    { name: 'verifier', type: 'address' },
    { name: 'railMask', type: 'uint16' },
    { name: 'active', type: 'bool' },
    // Pinned when the offer was posted; the escrow prices orders with this, never with the
    // asset's current config.
    { name: 'decimals', type: 'uint8' },
  ],
} as const;

const ASSETS_FN = {
  type: 'function',
  name: 'assets',
  stateMutability: 'view',
  inputs: [{ type: 'address' }],
  outputs: [
    { name: 'oracle', type: 'address' },
    { name: 'decimals', type: 'uint8' },
    { name: 'enabled', type: 'bool' },
  ],
} as const;

const LPS_FN = {
  type: 'function',
  name: 'lps',
  stateMutability: 'view',
  inputs: [{ type: 'address' }],
  outputs: [
    { name: 'tier', type: 'uint8' },
    { name: 'settledCents', type: 'uint256' },
    { name: 'settlements', type: 'uint32' },
    { name: 'disputesLost', type: 'uint32' },
    { name: 'manualCapCents', type: 'uint256' },
    { name: 'sponsor', type: 'address' },
    { name: 'exposureCents', type: 'uint256' },
  ],
} as const;

/**
 * `LPRegistry.Tier.INSTITUTIONAL` in the enum NONE, RETAIL, AFFILIATED, INSTITUTIONAL,
 * SUSPENDED.
 *
 * It was a bare `2`, which is AFFILIATED once that tier exists - so a taker asking for
 * licensed counterparties only would have been routed to affiliated LPs. Only INSTITUTIONAL
 * satisfies `requireInstitutional`; every other tier is quoted as RETAIL.
 */
export const TIER_INSTITUTIONAL = 3;

/** Unpack the escrow's railMask bitfield into the rails an LP will accept. */
export function railsFromMask(mask: number): Rail[] {
  const out: Rail[] = [];
  for (const r of [Rail.PIX, Rail.BOLETO, Rail.TED]) {
    if (mask & (1 << r)) out.push(r);
  }
  return out;
}

export class OrderBookIndexer {
  private readonly cfg: Required<IndexerConfig>;
  private known = new Set<Hex>();
  private decimalsOf = new Map<string, number>();
  /** Last block whose events have been folded in. */
  private cursor: bigint;

  constructor(cfg: IndexerConfig) {
    this.cfg = { span: 5_000n, ...cfg } as Required<IndexerConfig>;
    this.cursor = cfg.fromBlock;
  }

  get lastIndexedBlock(): bigint {
    return this.cursor;
  }

  /**
   * Fold in new events. Safe to call repeatedly; only offer IDs are accumulated.
   *
   * The span halves on a refusal rather than failing the poll, because RPC providers cap
   * `eth_getLogs` ranges at values they do not publish and a matcher that dies on an
   * unfamiliar provider is a matcher nobody can self-host.
   */
  async sync(toBlock?: bigint): Promise<number> {
    // `cacheTime: 0`: viem caches the block number for its polling interval (4s by default), so
    // a sync right after new blocks read a head from before them and folded in nothing - the
    // first book after startup came back empty on any chain faster than the cache.
    const head = toBlock ?? (await this.cfg.client.getBlockNumber({ cacheTime: 0 }));
    let from = this.cursor;
    let span = this.cfg.span;
    let found = 0;

    while (from <= head) {
      const to = from + span - 1n > head ? head : from + span - 1n;
      try {
        const logs = await this.cfg.client.getLogs({
          address: this.cfg.escrow,
          event: OFFER_POSTED,
          fromBlock: from,
          toBlock: to,
        });
        for (const l of logs) {
          const id = (l as unknown as { args: { offerId: Hex } }).args.offerId;
          if (!this.known.has(id)) {
            this.known.add(id);
            found++;
          }
        }
        from = to + 1n;
      } catch (e) {
        if (span <= 1n) throw e;
        span = span / 2n;
      }
    }
    this.cursor = head;
    return found;
  }

  /** The book as the chain currently reports it. Closed and empty offers are dropped. */
  async book(): Promise<Offer[]> {
    const out: Offer[] = [];
    for (const offerId of this.known) {
      const o = await this.cfg.client.readContract({
        address: this.cfg.escrow, abi: [OFFERS_FN], functionName: 'offers', args: [offerId],
      }) as readonly [Address, Address, bigint, bigint, bigint, Hex, bigint, bigint, Address, number, boolean, number];

      const [lp, asset, availableWei, , price, , minOrderWei, maxOrderWei, verifier, railMask, active, pinned] = o;
      if (!active || availableWei === 0n) continue;

      // The offer's own decimals are what the escrow will charge by. An offer posted before
      // decimals were pinned reads 0 and falls back to the asset's config.
      const decimals = pinned || await this.decimals(asset);
      const rep = await this.cfg.client.readContract({
        address: this.cfg.registry, abi: [LPS_FN], functionName: 'lps', args: [lp],
      }) as readonly [number, bigint, number, number, bigint, Address, bigint];

      out.push({
        offerId, lp, asset, decimals,
        rails: railsFromMask(railMask),
        availableWei,
        priceBrlCentsPerEth: price,
        minOrderWei, maxOrderWei, verifier,
        tier: rep[0] === TIER_INSTITUTIONAL ? 'INSTITUTIONAL' : 'RETAIL',
        settledCents: rep[1],
        disputesLost: rep[3],
      });
    }
    return out;
  }

  private async decimals(asset: Address): Promise<number> {
    const key = asset.toLowerCase();
    const hit = this.decimalsOf.get(key);
    if (hit !== undefined) return hit;
    const cfg = await this.cfg.client.readContract({
      address: this.cfg.escrow, abi: [ASSETS_FN], functionName: 'assets', args: [asset],
    }) as readonly [Address, number, boolean];
    this.decimalsOf.set(key, cfg[1]);
    return cfg[1];
  }
}
