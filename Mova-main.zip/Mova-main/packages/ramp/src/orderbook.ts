/**
 * Order matching between takers and LPs (task 2.4).
 *
 * ## What this is allowed to be
 *
 * A matching engine in a P2P ramp is the obvious place to accidentally build a custodian.
 * It must not become one, so the rule this module is written to is:
 *
 *   the matcher produces a SUGGESTION; the taker signs the lock themselves.
 *
 * Nothing here holds funds, signs anything, or can move value. The worst a fully malicious
 * matcher can do is route a taker to a worse price or to a colluding LP - and even that is
 * bounded by the escrow, which re-checks the offer price against the oracle band at lock
 * time and refuses anything outside it. A matcher that lies is a matcher that gets
 * out-competed, not one that steals.
 *
 * That is why matching lives off-chain at all. On-chain matching would cost gas per quote,
 * leak every taker's intent into the mempool for front-running, and buy nothing: the
 * settlement guarantees come from the escrow, not from where the pairing was computed.
 */

import type { Rail } from './attestor.js';

export interface Offer {
  offerId: string;
  lp: string;
  /** Settlement asset. The zero address is native ETH. */
  asset: string;
  /** Decimals of `asset`, so cost is computed in that asset's own units. */
  decimals: number;
  /** Rails this LP can reconcile (IAttestorVerifier.Rail values). */
  rails: Rail[];
  /** Unlocked liquidity, in wei. */
  availableWei: bigint;
  /** LP's asking price: BRL centavos per one whole unit of `asset`. */
  priceBrlCentsPerEth: bigint;
  minOrderWei: bigint;
  maxOrderWei: bigint;
  verifier: string;
  /** From LPRegistry. A taker may refuse to face retail LPs. */
  tier: 'RETAIL' | 'INSTITUTIONAL';
  /** Lifetime settled volume, BRL centavos. Used only to break price ties. */
  settledCents: bigint;
  /** Lost disputes. Used only to break price ties. */
  disputesLost: number;
}

export interface MatchRequest {
  /** Which asset the taker wants. Offers in any other asset are not comparable. */
  asset: string;
  /** What the taker wants to end up holding, in that asset's smallest unit. */
  weiWanted: bigint;
  /**
   * How the taker can actually pay.
   *
   * Not a preference. Matching someone who can only send a boleto to an LP that cannot
   * reconcile one produces an order that is guaranteed to expire unpaid, wasting the pay
   * window and the LP's liquidity - a match that cannot settle is worse than no match.
   */
  rails?: Rail[];
  /** Reject any offer priced above this. The taker's own limit, not the matcher's. */
  maxPriceBrlCentsPerEth?: bigint;
  /** Restrict to licensed counterparties (Phase A). */
  requireInstitutional?: boolean;
  /** Only these verifiers are acceptable to the taker. */
  allowedVerifiers?: string[];
  /**
   * The smallest leg the delivery can settle, in the asset's smallest unit.
   *
   * Each leg becomes its own order, and a SHIELDED order becomes its own pool deposit, which the
   * Entrypoint refuses below the pool's `minimumDepositAmount` (25 USDT on 0xbow's USDT pool). A
   * leg under it locks, the taker pays, and the delivery can never land (SR2-27). The escrow has
   * no bytes left to check this itself, so the match must never produce such a leg.
   */
  minFillWei?: bigint;
}

export interface Fill {
  offerId: string;
  lp: string;
  asset: string;
  /**
   * Rails both sides can use for this leg, in the taker's order of preference. A taker paying
   * this leg by BOLETO locks it with `FiatEscrow.lockOrderByBoleto`, not `lockOrder`: the LP
   * then issues a boleto for the leg's exact `brlCents` (see boleto.ts). Matching is the same.
   */
  rails: Rail[];
  weiAmount: bigint;
  priceBrlCentsPerEth: bigint;
  /** What this leg costs the taker, rounded UP exactly as the escrow rounds it. */
  brlCents: bigint;
}

export interface MatchResult {
  fills: Fill[];
  filledWei: bigint;
  totalBrlCents: bigint;
  /** Non-zero when the book could not cover the request. */
  unfilledWei: bigint;
}

/**
 * Ceiling division, matching FiatEscrow's cost calculation exactly.
 *
 * `decimals` is the asset's, not a constant: 1e18 here would overcharge a holder of a
 * 6-decimal stablecoin by a factor of a trillion, and the escrow would then disagree with
 * the quote the taker accepted.
 */
export function costBrlCents(
  amount: bigint,
  priceBrlCentsPerUnit: bigint,
  decimals = 18,
): bigint {
  const n = amount * priceBrlCentsPerUnit;
  if (n === 0n) return 0n;
  return (n - 1n) / 10n ** BigInt(decimals) + 1n;
}

/**
 * Rank offers for a taker: cheapest first.
 *
 * Ties are broken by settled volume and then by disputes lost - deliberately only as a
 * tiebreak. Ranking primarily by reputation would let a large LP charge above the market
 * and still win the top of the book, which is how a "reputation-weighted" venue becomes an
 * expensive one. Price is what the taker pays; it leads.
 */
export function rankOffers(offers: Offer[]): Offer[] {
  return [...offers].sort((a, b) => {
    if (a.priceBrlCentsPerEth !== b.priceBrlCentsPerEth) {
      return a.priceBrlCentsPerEth < b.priceBrlCentsPerEth ? -1 : 1;
    }
    if (a.disputesLost !== b.disputesLost) return a.disputesLost - b.disputesLost;
    if (a.settledCents !== b.settledCents) return a.settledCents > b.settledCents ? -1 : 1;
    return a.offerId < b.offerId ? -1 : 1; // deterministic, so two matchers agree
  });
}

/**
 * Match a request against the book, walking it cheapest-first and splitting across offers.
 *
 * Splitting is not free for the taker: every leg is a separate PIX transfer they must
 * actually make, and a separate attestation. So a fill is only split when a single offer
 * cannot cover the size, and `maxFills` bounds how bad that can get - an unbounded splitter
 * can hand a user fourteen bank transfers to make in thirty minutes, which is a failure
 * dressed as a fill.
 */
export function matchOrder(
  offers: Offer[],
  req: MatchRequest,
  maxFills = 3,
): MatchResult {
  // The smallest leg an offer may contribute: its LP's minimum, or the delivery's, whichever is larger.
  const floor = (o: Offer) => (req.minFillWei !== undefined && req.minFillWei > o.minOrderWei ? req.minFillWei : o.minOrderWei);
  const eligible = rankOffers(offers).filter((o) => {
    if (o.asset.toLowerCase() !== req.asset.toLowerCase()) return false;
    // Only offers whose LP can reconcile a rail the taker can actually use.
    if (req.rails && !req.rails.some((r) => o.rails.includes(r))) return false;
    if (o.availableWei < floor(o)) return false;
    if (req.requireInstitutional && o.tier !== 'INSTITUTIONAL') return false;
    if (req.maxPriceBrlCentsPerEth !== undefined
      && o.priceBrlCentsPerEth > req.maxPriceBrlCentsPerEth) return false;
    if (req.allowedVerifiers && !req.allowedVerifiers.includes(o.verifier)) return false;
    return true;
  });

  const fills: Fill[] = [];
  let remaining = req.weiWanted;

  for (const o of eligible) {
    if (remaining === 0n || fills.length >= maxFills) break;

    const cap = min(o.availableWei, o.maxOrderWei);
    let take = min(remaining, cap);
    if (take < floor(o)) {
      // Taking below the LP's minimum is not allowed. Taking MORE than the taker asked for
      // to satisfy it would be worse: it silently spends money they did not agree to spend.
      continue;
    }

    // Never leave a remainder too small for any offer's minimum to clear on a later pass -
    // a taker stranded 0.001 ETH short has to start over.
    const rest = remaining - take;
    if (rest > 0n && rest < floor(o) && take + rest <= cap) {
      take = remaining;
    } else if (req.minFillWei !== undefined && rest > 0n && rest < req.minFillWei
      && take - (req.minFillWei - rest) >= floor(o)) {
      // This offer cannot take it all, and what it leaves is below the delivery's minimum, which
      // binds every offer. Leave exactly the minimum instead, so the next leg can exist.
      take -= req.minFillWei - rest;
    }

    fills.push({
      offerId: o.offerId,
      lp: o.lp,
      asset: o.asset,
      rails: req.rails ? req.rails.filter((r) => o.rails.includes(r)) : o.rails,
      weiAmount: take,
      priceBrlCentsPerEth: o.priceBrlCentsPerEth,
      brlCents: costBrlCents(take, o.priceBrlCentsPerEth, o.decimals),
    });
    remaining -= take;
  }

  return {
    fills,
    filledWei: fills.reduce((a, f) => a + f.weiAmount, 0n),
    totalBrlCents: fills.reduce((a, f) => a + f.brlCents, 0n),
    unfilledWei: remaining,
  };
}

function min(a: bigint, b: bigint): bigint {
  return a < b ? a : b;
}
