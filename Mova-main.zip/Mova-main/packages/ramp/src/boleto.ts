/**
 * Boletos: parse, validate and commit to them, for both directions of the ramp.
 *
 * A boleto is a payment slip. Unlike a PIX key it is not an address someone owns; it is ONE
 * document, registered by its payee for one amount, whose line the payer types or scans. The
 * ramp meets it twice:
 *
 *  - off-ramp, a seller sells crypto to have a BILL paid: the sale's payee is the bill's
 *    barcode, and its `brlCents` must be the bill's amount;
 *  - on-ramp, the LP issues a boleto for a locked order and commits to it on-chain
 *    (`FiatEscrow.issueBoleto`); the taker pays it at any bank.
 *
 * In both, the contract only ever sees a salted commitment, so everything a contract cannot
 * see is checked here, before money moves: that the line is a real FEBRABAN line (every check
 * digit), that its amount is the amount the order or sale says, that it is not already overdue,
 * and that it opens the commitment the counterparty put on-chain.
 *
 * ## The two formats (FEBRABAN)
 *
 * **Bank boleto ("boleto de cobrança")** - 44-digit barcode, 47-digit linha digitável:
 *
 *   barcode  [1-3] bank  [4] currency (9 = BRL)  [5] general check digit
 *            [6-9] due-date factor  [10-19] amount, centavos  [20-44] free field (the bank's)
 *   line     field 1 = bank + currency + free[1-5] + DV    (mod 10)
 *            field 2 = free[6-15] + DV                     (mod 10)
 *            field 3 = free[16-25] + DV                    (mod 10)
 *            field 4 = the barcode's general check digit
 *            field 5 = factor + amount
 *
 *   The general check digit is modulo 11 over the other 43 digits, weights 2..9 from the right;
 *   11 - remainder, and a result of 0, 10 or 11 is written as 1 - a bank barcode's check digit
 *   is never 0. (Bradesco, Layout de Cobrança 4008.524.0121 v17, whose worked line is a test
 *   vector in test/boleto.test.ts.)
 *
 * **Collection ("arrecadação" / "convênio")** - utility bills, taxes, fines - 44-digit barcode,
 * 48-digit line (FEBRABAN "Layout Padrão de Arrecadação/Recebimento com Utilização do Código de
 * Barras", versão 07, vigente desde 01.03.2023):
 *
 *   barcode  [1] product, always 8   [2] segment   [3] value identifier   [4] general DV
 *            [5-15] value (11 digits)   [16-19] company (or [16-23] CNPJ root)   rest free
 *   line     four blocks of 11 barcode digits, each followed by its own check digit
 *
 *   The value identifier chooses the modulus AND what the value means: 6 = the amount in reais,
 *   mod 10; 7 = a reference quantity, mod 10; 8 = the amount in reais, mod 11; 9 = a reference,
 *   mod 11. Only 6 and 8 carry an amount the ramp can bind. Collection mod 11 differs from the
 *   bank rule: remainder 0 or 1 gives 0, remainder 10 gives 1.
 *
 * ## The due-date factor rolled over, and what that means for decoding
 *
 * The factor is the number of days since 07/10/1997, in four digits. It reached 9999 on
 * 21/02/2025, and FEBRABAN (Comunicado FB-009/2023) restarted it at 1000 on 22/02/2025, "que
 * passa a ser a nova data de referência"; the new cycle reaches 9999 on 13/10/2049 and restarts
 * at 1000 again on 14/10/2049 (C6 Bank, Layout CNAB 400 v2.7, Julho 2025, "Cálculo do Fator de
 * Vencimento"). So factor 1000 now means 22/02/2025 - and also meant 03/07/2000. Every cycle is
 * exactly 9000 days, i.e. date = 07/10/1997 + factor + 9000·k.
 *
 * A factor is therefore ambiguous on its own, and a decoder that still adds the factor to the
 * 1997 base puts every boleto issued since February 2025 in the year 2000 - which a "refuse
 * overdue boletos" rule then rejects, silently, every one. `dueDateFromFactor` picks the cycle
 * whose date is closest to a reference date (today, by default): the candidates are 9000 days
 * apart, so any boleto due within ~12 years either side of the reference decodes correctly.
 * Factor 0000 means the line carries no due date.
 */
import { encodeAbiParameters, keccak256, toHex, type Hex } from 'viem';

export class InvalidBoleto extends Error {}

export type BoletoKind = 'bank' | 'collection';

export interface Boleto {
  kind: BoletoKind;
  /** The canonical form: the 44-digit barcode. Every commitment is over this. */
  barcode: string;
  /** The typed form: 47 digits (bank) or 48 (collection), digits only. */
  line: string;
  /**
   * Amount in centavos, as the line states it. For a collection boleto whose value field is a
   * reference rather than reais (identifier 7 or 9) this is `undefined`: there is no amount.
   */
  amountCents: bigint | undefined;
  /** Bank boleto: the three-digit bank code (COMPE). */
  bankCode?: string;
  /** Bank boleto: the four-digit due-date factor; 0 means no due date. */
  dueFactor?: number;
  /** Bank boleto with a factor: the due date, `YYYY-MM-DD`, decoded against `reference`. */
  dueDate?: string;
  /** Collection boleto: the segment (1 prefeituras ... 9 bank use). */
  segment?: number;
  /** Collection boleto: the value identifier, 6-9. */
  valueIdentifier?: number;
}

/*//////////////////////////////////////////////////////////////
                          CHECK DIGITS
//////////////////////////////////////////////////////////////*/

const digits = (s: string): number[] => [...s].map(Number);

/**
 * FEBRABAN modulo 10: weights 2,1,2,1... from the right, the DIGITS of each product summed,
 * 10 minus the remainder, and 0 when the remainder is 0. Used by the bank line's three fields
 * and by collection boletos with identifier 6 or 7.
 */
export function mod10(s: string): number {
  let sum = 0;
  digits(s).reverse().forEach((d, i) => {
    const p = d * (i % 2 === 0 ? 2 : 1);
    sum += Math.floor(p / 10) + (p % 10);
  });
  return (10 - (sum % 10)) % 10;
}

function mod11Sum(s: string): number {
  let sum = 0;
  digits(s).reverse().forEach((d, i) => { sum += d * (2 + (i % 8)); });
  return sum % 11;
}

/** A bank barcode's general check digit: 11 - remainder, with 0, 10 and 11 written as 1. */
export function bankMod11(s: string): number {
  const dv = 11 - mod11Sum(s);
  return dv === 0 || dv === 10 || dv === 11 ? 1 : dv;
}

/** A collection boleto's modulo 11: remainder 0 or 1 gives 0, remainder 10 gives 1. */
export function collectionMod11(s: string): number {
  const r = mod11Sum(s);
  if (r === 0 || r === 1) return 0;
  if (r === 10) return 1;
  return 11 - r;
}

/*//////////////////////////////////////////////////////////////
                         DUE-DATE FACTOR
//////////////////////////////////////////////////////////////*/

const DAY_MS = 86_400_000;
/** 07/10/1997: day zero of the factor. */
const FACTOR_BASE_MS = Date.UTC(1997, 9, 7);
/** Every cycle of the factor, 1000..9999, is this many days long. */
export const FACTOR_CYCLE_DAYS = 9000;

const isoDay = (ms: number): string => new Date(ms).toISOString().slice(0, 10);

/** Days since the factor's base for a calendar date, ignoring any time of day. */
function daysSinceBase(date: Date | string): number {
  const d = typeof date === 'string' ? new Date(`${date}T00:00:00Z`) : date;
  if (Number.isNaN(d.getTime())) throw new InvalidBoleto(`not a date: ${String(date)}`);
  const midnight = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate());
  return Math.round((midnight - FACTOR_BASE_MS) / DAY_MS);
}

/**
 * The due date a factor names, as `YYYY-MM-DD`, choosing the factor cycle closest to
 * `reference`. `undefined` for factor 0 (no due date). See the module header for why a factor
 * cannot be decoded without a reference since 22/02/2025.
 */
export function dueDateFromFactor(factor: number, reference: Date = new Date()): string | undefined {
  if (factor === 0) return undefined;
  if (!Number.isInteger(factor) || factor < 1000 || factor > 9999) {
    throw new InvalidBoleto(`due-date factor ${factor} is not 0000 or 1000-9999`);
  }
  const ref = daysSinceBase(reference);
  const cycle = Math.max(0, Math.round((ref - factor) / FACTOR_CYCLE_DAYS));
  return isoDay(FACTOR_BASE_MS + (factor + FACTOR_CYCLE_DAYS * cycle) * DAY_MS);
}

/** The factor a due date is written with: 22/02/2025 is 1000 again, 21/02/2025 was 9999. */
export function factorFromDueDate(date: Date | string): number {
  const days = daysSinceBase(date);
  if (days < 1000) throw new InvalidBoleto('due dates before 03/07/2000 have no factor');
  return ((days - 1000) % FACTOR_CYCLE_DAYS) + 1000;
}

/*//////////////////////////////////////////////////////////////
                       PARSING AND CONVERSION
//////////////////////////////////////////////////////////////*/

/**
 * Digits only. Lines are printed with dots and spaces and pasted with anything; the check
 * digits, not the punctuation, are what say whether a line is right. Anything that is not a
 * digit or a separator is refused rather than dropped, so "O" for "0" is an error, not a guess.
 */
export function normalizeBoletoInput(raw: string): string {
  if (typeof raw !== 'string') throw new InvalidBoleto('a boleto line is a string');
  const trimmed = raw.trim();
  if (!/^[\d\s.\-]+$/.test(trimmed)) {
    throw new InvalidBoleto('a boleto line has only digits, spaces, dots and hyphens');
  }
  return trimmed.replace(/\D/g, '');
}

const isCollection = (digitsOnly: string) => digitsOnly.startsWith('8');

/** 47-digit bank line to its 44-digit barcode. Checks nothing; `parseBoleto` does. */
function bankLineToBarcode(l: string): string {
  return l.slice(0, 4) + l[32] + l.slice(33, 47) + l.slice(4, 9) + l.slice(10, 20) + l.slice(21, 31);
}

function bankBarcodeToLine(b: string): string {
  const f1 = b.slice(0, 4) + b.slice(19, 24);
  const f2 = b.slice(24, 34);
  const f3 = b.slice(34, 44);
  return f1 + mod10(f1) + f2 + mod10(f2) + f3 + mod10(f3) + b[4] + b.slice(5, 19);
}

function collectionModulus(identifier: number): (s: string) => number {
  if (identifier === 6 || identifier === 7) return mod10;
  if (identifier === 8 || identifier === 9) return collectionMod11;
  throw new InvalidBoleto(`collection value identifier ${identifier} is not 6, 7, 8 or 9`);
}

function collectionLineToBarcode(l: string): string {
  return l.slice(0, 11) + l.slice(12, 23) + l.slice(24, 35) + l.slice(36, 47);
}

function collectionBarcodeToLine(b: string): string {
  const dv = collectionModulus(Number(b[2]));
  let out = '';
  for (let i = 0; i < 44; i += 11) {
    const block = b.slice(i, i + 11);
    out += block + dv(block);
  }
  return out;
}

/** Convert a line (47 or 48 digits, any punctuation) to its 44-digit barcode, validated. */
export function lineToBarcode(line: string): string {
  return parseBoleto(line).barcode;
}

/** Convert a 44-digit barcode to its typed line, validated. */
export function barcodeToLine(barcode: string): string {
  const b = normalizeBoletoInput(barcode);
  if (b.length !== 44) throw new InvalidBoleto(`a barcode has 44 digits, not ${b.length}`);
  return parseBoleto(b).line;
}

/**
 * Parse and fully validate a boleto from its line (47 or 48 digits) or barcode (44).
 *
 * Every check digit is verified - each field's, and the general one - because a single
 * mistyped digit usually still "looks like" a boleto, and paying the wrong one is not
 * reversible. `reference` is only used to pick the due-date factor's cycle.
 *
 * @throws InvalidBoleto naming the first thing wrong.
 */
export function parseBoleto(input: string, opts: { reference?: Date } = {}): Boleto {
  const s = normalizeBoletoInput(input);
  if (s.length !== 44 && s.length !== 47 && s.length !== 48) {
    throw new InvalidBoleto(
      `a boleto is a 44-digit barcode, a 47-digit bank line or a 48-digit collection line; got ${s.length} digits`,
    );
  }
  return isCollection(s) ? parseCollection(s) : parseBank(s, opts.reference ?? new Date());
}

function parseBank(s: string, reference: Date): Boleto {
  if (s.length === 48) throw new InvalidBoleto('a 48-digit line is a collection boleto and starts with 8');
  let barcode: string;
  if (s.length === 47) {
    const fields: [string, string, number][] = [
      [s.slice(0, 9), 'field 1', Number(s[9])],
      [s.slice(10, 20), 'field 2', Number(s[20])],
      [s.slice(21, 31), 'field 3', Number(s[31])],
    ];
    for (const [body, name, dv] of fields) {
      if (mod10(body) !== dv) {
        throw new InvalidBoleto(`${name} check digit is ${dv}, should be ${mod10(body)}: the line was mistyped`);
      }
    }
    barcode = bankLineToBarcode(s);
  } else {
    barcode = s;
  }

  const general = Number(barcode[4]);
  const expected = bankMod11(barcode.slice(0, 4) + barcode.slice(5));
  if (general !== expected) {
    throw new InvalidBoleto(`general check digit is ${general}, should be ${expected}`);
  }
  if (barcode[3] !== '9') {
    throw new InvalidBoleto(`currency code ${barcode[3]} is not 9 (reais); the ramp settles only BRL`);
  }
  const dueFactor = Number(barcode.slice(5, 9));
  const dueDate = dueDateFromFactor(dueFactor, reference);
  return {
    kind: 'bank',
    barcode,
    line: bankBarcodeToLine(barcode),
    amountCents: BigInt(barcode.slice(9, 19)),
    bankCode: barcode.slice(0, 3),
    dueFactor,
    ...(dueDate ? { dueDate } : {}),
  };
}

function parseCollection(s: string): Boleto {
  if (s.length === 47) throw new InvalidBoleto('a collection boleto line has 48 digits, not 47');
  const valueIdentifier = Number(s[2]);
  const dv = collectionModulus(valueIdentifier);
  const segment = Number(s[1]);
  if (segment === 0 || segment === 8) {
    throw new InvalidBoleto(`collection segment ${segment} does not exist (1-7, or 9)`);
  }

  let barcode: string;
  if (s.length === 48) {
    for (let i = 0; i < 4; i++) {
      const block = s.slice(i * 12, i * 12 + 11);
      const got = Number(s[i * 12 + 11]);
      if (dv(block) !== got) {
        throw new InvalidBoleto(
          `block ${i + 1} check digit is ${got}, should be ${dv(block)}: the line was mistyped`,
        );
      }
    }
    barcode = collectionLineToBarcode(s);
  } else {
    barcode = s;
  }

  const general = Number(barcode[3]);
  const expected = dv(barcode.slice(0, 3) + barcode.slice(4));
  if (general !== expected) {
    throw new InvalidBoleto(`general check digit is ${general}, should be ${expected}`);
  }
  const real = valueIdentifier === 6 || valueIdentifier === 8;
  return {
    kind: 'collection',
    barcode,
    line: collectionBarcodeToLine(barcode),
    amountCents: real ? BigInt(barcode.slice(4, 15)) : undefined,
    segment,
    valueIdentifier,
  };
}

/*//////////////////////////////////////////////////////////////
                     BUILDING (ISSUERS AND TESTS)
//////////////////////////////////////////////////////////////*/

/**
 * Assemble a valid bank boleto from its parts, computing every check digit.
 *
 * An LP's bank registers the boleto and hands back its line; this exists so an LP can check
 * that line against what it asked for, and so tests and examples can make real-format lines.
 */
export function buildBankBoleto(args: {
  bankCode: string;
  amountCents: bigint;
  /** `YYYY-MM-DD`, or omitted for a boleto with no due date. */
  dueDate?: string;
  /** The bank's 25-digit free field (agency, account, nosso número...). */
  freeField: string;
}): Boleto {
  if (!/^\d{3}$/.test(args.bankCode)) throw new InvalidBoleto('bank code is three digits');
  if (!/^\d{25}$/.test(args.freeField)) throw new InvalidBoleto('the free field is 25 digits');
  if (args.amountCents < 0n || args.amountCents > 9_999_999_999n) {
    throw new InvalidBoleto('a bank boleto amount is at most ten digits of centavos');
  }
  const factor = args.dueDate ? factorFromDueDate(args.dueDate) : 0;
  const body = `${args.bankCode}9${String(factor).padStart(4, '0')}${args.amountCents
    .toString().padStart(10, '0')}${args.freeField}`;
  const barcode = body.slice(0, 4) + bankMod11(body) + body.slice(4);
  const reference = args.dueDate ? new Date(`${args.dueDate}T00:00:00Z`) : undefined;
  return parseBoleto(barcode, { reference });
}

/** Assemble a valid collection boleto, computing every check digit. */
export function buildCollectionBoleto(args: {
  segment: number;
  /** 6 or 8 for an amount in reais (mod 10 or mod 11); 7 or 9 for a reference. */
  valueIdentifier: 6 | 7 | 8 | 9;
  /** Centavos, or the reference quantity for identifiers 7 and 9. */
  value: bigint;
  /** Company code (4 digits) followed by the free field: 29 digits in all. */
  rest: string;
}): Boleto {
  if (!/^\d{29}$/.test(args.rest)) throw new InvalidBoleto('company code and free field are 29 digits');
  if (args.value < 0n || args.value > 99_999_999_999n) {
    throw new InvalidBoleto('a collection value is at most eleven digits');
  }
  const head = `8${args.segment}${args.valueIdentifier}`;
  const tail = `${args.value.toString().padStart(11, '0')}${args.rest}`;
  const dv = collectionModulus(args.valueIdentifier)(head + tail);
  return parseBoleto(`${head}${dv}${tail}`);
}

/*//////////////////////////////////////////////////////////////
                           COMMITMENTS
//////////////////////////////////////////////////////////////*/

/**
 * What goes on-chain in place of a boleto: a salted commitment to its canonical barcode,
 *
 *   keccak256(abi.encode("PrivacyPoolsBRL/boleto/v1", barcode44, salt))
 *
 * in the same style as `pixKeyCommitment`, and salted for the same reason. A barcode is not
 * guessable the way a CPF is, but it is not secret either: the biller that issued a bill, the
 * bank that registered it and anyone who saw the slip can all hash it, and an unsalted value
 * would let each of them find the sale - money that just left a privacy pool - on-chain.
 *
 * Over the barcode, not the line: the 47/48-digit line and the 44-digit barcode are the same
 * boleto, and a bank receipt may show either, so the commitment must not depend on which.
 * Domain-separated from PIX key commitments, so a string that parses as both can never make one
 * commitment serve as the other.
 */
export const BOLETO_COMMITMENT_DOMAIN = 'PrivacyPoolsBRL/boleto/v1';

/** A fresh 32-byte salt. Never reuse one across orders or sales. */
export function newBoletoSalt(): Hex {
  return toHex(crypto.getRandomValues(new Uint8Array(32)));
}

export function boletoCommitment(boleto: string | Boleto, salt: Hex): Hex {
  if (!/^0x[0-9a-fA-F]{64}$/.test(salt)) {
    throw new InvalidBoleto('salt must be 32 bytes of hex - use newBoletoSalt()');
  }
  if (/^0x0{64}$/.test(salt)) {
    throw new InvalidBoleto('an all-zero salt is no salt: anyone holding the slip could find it');
  }
  const barcode = typeof boleto === 'string' ? parseBoleto(boleto).barcode : boleto.barcode;
  return keccak256(encodeAbiParameters(
    [{ type: 'string' }, { type: 'string' }, { type: 'bytes32' }],
    [BOLETO_COMMITMENT_DOMAIN, barcode, salt],
  ));
}

/*//////////////////////////////////////////////////////////////
                     THE CHECKS THE CHAIN CANNOT MAKE
//////////////////////////////////////////////////////////////*/

/** Today's calendar date in Brasília (UTC-3, no daylight saving since 2019), `YYYY-MM-DD`. */
export function brasiliaToday(now: Date = new Date()): string {
  return isoDay(now.getTime() - 3 * 3600_000);
}

/**
 * Is this boleto one the ramp can settle for exactly `brlCents`, today?
 *
 * The escrows bind a boleto payment's amount to the order's or sale's `brlCents` and can do
 * nothing else, because the barcode is behind a commitment. So this is where a seller is
 * stopped from opening a sale whose price is not the bill's, where an LP checks a seller's
 * bill before claiming, and where a taker checks the boleto an LP issued before paying it:
 *
 *  - the line is valid (every check digit);
 *  - it carries an amount in reais - not a zero "fill in the value" boleto, not a collection
 *    reference quantity - and that amount is exactly `brlCents`;
 *  - it is not past its due date in Brasília, since a late payment adds charges, and a payment
 *    of any other amount will not settle on-chain.
 *
 * @returns the parsed boleto.
 * @throws InvalidBoleto naming what is wrong.
 */
export function assertPayableBoleto(
  input: string | Boleto,
  brlCents: bigint,
  opts: { now?: Date } = {},
): Boleto {
  const now = opts.now ?? new Date();
  const b = typeof input === 'string' ? parseBoleto(input, { reference: now }) : input;
  if (b.amountCents === undefined) {
    throw new InvalidBoleto('this collection boleto carries a reference quantity, not an amount in reais');
  }
  if (b.amountCents === 0n) {
    throw new InvalidBoleto('this boleto has no amount written in it; the ramp can only pay a fixed amount');
  }
  if (b.amountCents !== brlCents) {
    throw new InvalidBoleto(
      `the boleto is for ${b.amountCents} centavos but the order is for ${brlCents}: the escrow would refuse the payment`,
    );
  }
  if (b.dueDate && b.dueDate < brasiliaToday(now)) {
    throw new InvalidBoleto(`the boleto was due ${b.dueDate}; paying it late adds charges the escrow will not accept`);
  }
  return b;
}

/**
 * Open a commitment someone put on-chain: does this line and salt give exactly that value,
 * for a boleto payable for `brlCents`? The taker's check before paying an LP-issued boleto,
 * and the LP's before claiming a seller's bill.
 */
export function verifyBoletoCommitment(args: {
  line: string;
  salt: Hex;
  commitment: Hex;
  brlCents: bigint;
  now?: Date;
}): Boleto {
  const b = assertPayableBoleto(args.line, args.brlCents, { now: args.now });
  if (boletoCommitment(b, args.salt).toLowerCase() !== args.commitment.toLowerCase()) {
    throw new InvalidBoleto('this line and salt do not open the commitment on-chain: it is a different boleto');
  }
  return b;
}
