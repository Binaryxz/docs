import { describe, it, expect } from 'vitest';
import { encodeAbiParameters, keccak256, toBytes, type Hex } from 'viem';
import {
  BOLETO_COMMITMENT_DOMAIN, InvalidBoleto, assertPayableBoleto, bankMod11, barcodeToLine,
  boletoCommitment, brasiliaToday, buildBankBoleto, buildCollectionBoleto, collectionMod11,
  dueDateFromFactor, factorFromDueDate, lineToBarcode, mod10, newBoletoSalt, parseBoleto,
  verifyBoletoCommitment,
} from '../src/boleto.js';
import { pixKeyCommitment } from '../src/attestor.js';

/**
 * Boleto parsing, validation and commitments.
 *
 * No vector below was produced by the code under test. They come from three places:
 *
 *  - PUBLISHED: the worked examples in the specifications themselves - Bradesco's "Layout de
 *    Cobrança" (4008.524.0121, v17) walks one linha digitável through every check digit, and
 *    FEBRABAN's "Layout Padrão de Arrecadação" (versão 07, vigente 01.03.2023) works its
 *    modulo-10 and modulo-11 examples by hand;
 *  - INDEPENDENT: lines built by a separate implementation of the same rules, written from
 *    the spec text in Python rather than from this module (kept out of the repo; every value
 *    it produced is pasted here as a literal, with the parts it encodes);
 *  - the FEBRABAN rollover dates, from the C6 Bank "Layout CNAB 400" v2.7 (Julho 2025),
 *    "Cálculo do Fator de Vencimento", which states them outright.
 *
 * A validator that generates its own fixtures agrees with itself whether or not it is right.
 */

const SALT = `0x${'5a'.repeat(32)}` as Hex;

/** Bradesco's worked example: 23790.03102 40031.772003 28009.527905 7 10010000000000. */
const BRADESCO_LINE = '23790.03102 40031.772003 28009.527905 7 10010000000000';
const BRADESCO_BARCODE = '23797100100000000000031040031772002800952790';

/** INDEPENDENT: Banco do Brasil (001), due 2026-09-20 (factor 1575), R$ 1.234,56. */
const BB_LINE = '00190.00009 02790.853002 00123.456170 3 15750000123456';
const BB_BARCODE = '00193157500001234560000002790853000012345617';

/** INDEPENDENT: Itaú (341), R$ 99,90, due the last day of the old factor cycle and the first of the new. */
const ITAU_LAST_OLD = '34191.09008 00123.452344 56789.012301 2 99990000009990'; // due 2025-02-21
const ITAU_FIRST_NEW = '34191.09008 00123.452344 56789.012301 8 10000000009990'; // due 2025-02-22

/** INDEPENDENT: water bill, segment 2, identifier 6 (reais, mod 10), R$ 87,35. */
const WATER_LINE = '82690000000-9 87350123202-9 60920123456-2 78901234567-2';
const WATER_BARCODE = '82690000000873501232026092012345678901234567';
/** INDEPENDENT: electricity bill, segment 3, identifier 8 (reais, mod 11), R$ 245,90. */
const POWER_LINE = '83820000002-9 45900056202-0 60930000000-8 00987654321-6';
const POWER_BARCODE = '83820000002459000562026093000000000987654321';
/** INDEPENDENT: a government document, identifier 7: a reference quantity, not an amount. */
const REFERENCE_LINE = '85760000000-7 00120001000-5 00000000000-0 00000000001-8';

describe('check digits, against the specifications\' own worked examples', () => {
  it('modulo 10 (FEBRABAN arrecadação v07, section 07: 01230067896 -> 3)', () => {
    expect(mod10('01230067896')).toBe(3);
  });

  it('collection modulo 11 (section 09: 01230067896, sum 176, remainder 0 -> 0)', () => {
    expect(collectionMod11('01230067896')).toBe(0);
  });

  it('the general digit over 43 positions (sections 08 and 10: sum 139 -> 1; sum 705, remainder 1 -> 0)', () => {
    const body = `822${'0000215048200974123220154098290108605940'}`;
    expect(mod10(body)).toBe(1);
    expect(collectionMod11(body)).toBe(0);
  });

  it('each field of Bradesco\'s line (237900310 -> 2, 4003177200 -> 3, 2800952790 -> 5)', () => {
    expect(mod10('237900310')).toBe(2);
    expect(mod10('4003177200')).toBe(3);
    expect(mod10('2800952790')).toBe(5);
  });

  /// "Se o resultado da subtração for igual a 0, 1 ou maior que 9, deverão assumir o dígito 1."
  it('a bank barcode\'s general digit is never 0, 10 or 11', () => {
    expect(bankMod11(BRADESCO_BARCODE.slice(0, 4) + BRADESCO_BARCODE.slice(5))).toBe(7);
    // '0' sums to 0 (11 - 0 = 11), '6' to 12 = remainder 1 (11 - 1 = 10): both are written 1.
    expect(bankMod11('0')).toBe(1);
    expect(bankMod11('6')).toBe(1);
  });

  /// "Quando o resto da divisão for igual a 0 ou 1, atribui-se ao DV o dígito 0, e quando for 10, 1."
  it('a collection modulo 11 writes remainders 0 and 1 as 0, and 10 as 1', () => {
    expect(collectionMod11('0')).toBe(0);
    expect(collectionMod11('6')).toBe(0); // remainder 1
    expect(collectionMod11('5')).toBe(1); // 10 = remainder 10
    expect(bankMod11('5')).toBe(1);
  });
});

describe('the due-date factor, across FEBRABAN\'s 22/02/2025 restart', () => {
  it('encodes the published boundary dates', () => {
    expect(factorFromDueDate('2000-07-03')).toBe(1000);
    expect(factorFromDueDate('2025-02-21')).toBe(9999);
    expect(factorFromDueDate('2025-02-22')).toBe(1000);
    expect(factorFromDueDate('2025-02-24')).toBe(1002);
    expect(factorFromDueDate('2049-10-13')).toBe(9999);
    expect(factorFromDueDate('2049-10-14')).toBe(1000);
  });

  it('decodes 1000 as 22/02/2025 today, and as 03/07/2000 for a reader in 2005', () => {
    expect(dueDateFromFactor(1000, new Date('2026-09-13T12:00:00Z'))).toBe('2025-02-22');
    expect(dueDateFromFactor(1000, new Date('2005-01-01T00:00:00Z'))).toBe('2000-07-03');
  });

  /**
   * The bug the restart creates: a decoder that still adds the factor to 07/10/1997 dates
   * every boleto issued since the restart in 2000-2025, and then "refuses overdue boletos"
   * by refusing all of them.
   */
  it('does not date a boleto issued after the restart in the old cycle', () => {
    const now = new Date('2026-09-13T12:00:00Z');
    expect(dueDateFromFactor(1575, now)).toBe('2026-09-20');
    const naive = new Date(Date.UTC(1997, 9, 7) + 1575 * 86_400_000).toISOString().slice(0, 10);
    expect(naive).toBe('2002-01-29');
  });

  it('keeps the old cycle for old boletos, and handles the days either side of the restart', () => {
    const eve = new Date('2025-02-20T12:00:00Z');
    expect(dueDateFromFactor(9999, eve)).toBe('2025-02-21');
    expect(dueDateFromFactor(1000, eve)).toBe('2025-02-22');
    expect(dueDateFromFactor(9999, new Date('2026-09-13T00:00:00Z'))).toBe('2025-02-21');
    expect(dueDateFromFactor(5000, new Date('2012-01-01T00:00:00Z'))).toBe('2011-06-16');
  });

  it('crosses the next restart in 2049 the same way', () => {
    const late2049 = new Date('2049-10-01T00:00:00Z');
    expect(dueDateFromFactor(9999, late2049)).toBe('2049-10-13');
    expect(dueDateFromFactor(1003, late2049)).toBe('2049-10-17');
  });

  it('0000 is no due date; 0001-0999 is not a factor', () => {
    expect(dueDateFromFactor(0)).toBeUndefined();
    expect(() => dueDateFromFactor(999)).toThrow(InvalidBoleto);
    expect(() => dueDateFromFactor(10_000)).toThrow(InvalidBoleto);
  });
});

describe('bank boletos (47-digit linha digitável)', () => {
  it('parses Bradesco\'s published line', () => {
    const b = parseBoleto(BRADESCO_LINE, { reference: new Date('2026-09-13T00:00:00Z') });
    expect(b).toMatchObject({
      kind: 'bank', bankCode: '237', barcode: BRADESCO_BARCODE, dueFactor: 1001, amountCents: 0n,
      dueDate: '2025-02-23',
    });
    expect(b.line).toBe(BRADESCO_LINE.replace(/\D/g, ''));
  });

  it('parses a constructed Banco do Brasil line: amount, due date after the restart, barcode', () => {
    const b = parseBoleto(BB_LINE, { reference: new Date('2026-09-13T00:00:00Z') });
    expect(b).toMatchObject({
      kind: 'bank', bankCode: '001', amountCents: 123_456n, dueFactor: 1575, dueDate: '2026-09-20',
      barcode: BB_BARCODE,
    });
  });

  it('dates the last boleto of the old cycle and the first of the new one correctly', () => {
    const ref = new Date('2025-02-20T12:00:00Z');
    expect(parseBoleto(ITAU_LAST_OLD, { reference: ref }).dueDate).toBe('2025-02-21');
    expect(parseBoleto(ITAU_FIRST_NEW, { reference: ref }).dueDate).toBe('2025-02-22');
  });

  it('converts line <-> barcode both ways, whatever the punctuation', () => {
    expect(lineToBarcode(BB_LINE)).toBe(BB_BARCODE);
    expect(lineToBarcode(BB_LINE.replace(/[ .]/g, ''))).toBe(BB_BARCODE);
    expect(barcodeToLine(BB_BARCODE)).toBe(BB_LINE.replace(/\D/g, ''));
    expect(parseBoleto(BB_BARCODE).line).toBe(BB_LINE.replace(/\D/g, ''));
  });

  it('builds the same line the independent implementation built', () => {
    const b = buildBankBoleto({
      bankCode: '001', amountCents: 123_456n, dueDate: '2026-09-20', freeField: '0000002790853000012345617',
    });
    expect(b.barcode).toBe(BB_BARCODE);
  });
});

describe('collection boletos (48-digit line)', () => {
  it('parses a mod-10 water bill', () => {
    const b = parseBoleto(WATER_LINE);
    expect(b).toMatchObject({
      kind: 'collection', segment: 2, valueIdentifier: 6, amountCents: 8_735n, barcode: WATER_BARCODE,
    });
    expect(barcodeToLine(WATER_BARCODE)).toBe(WATER_LINE.replace(/\D/g, ''));
  });

  it('parses a mod-11 electricity bill - the identifier chooses the modulus', () => {
    const b = parseBoleto(POWER_LINE);
    expect(b).toMatchObject({ segment: 3, valueIdentifier: 8, amountCents: 24_590n, barcode: POWER_BARCODE });
    expect(buildCollectionBoleto({
      segment: 3, valueIdentifier: 8, value: 24_590n, rest: `0056${'2026093000000000987654321'}`,
    }).barcode).toBe(POWER_BARCODE);
  });

  it('reads a reference quantity as no amount at all', () => {
    expect(parseBoleto(REFERENCE_LINE).amountCents).toBeUndefined();
  });

  /// The same digits checked with the wrong modulus must not pass: 6 means mod 10, 8 mod 11.
  it('refuses a line whose check digits were computed with the other modulus', () => {
    const asMod11 = `83${'6'}${POWER_BARCODE.slice(3)}`; // claims mod 10, digits are mod 11
    expect(() => parseBoleto(asMod11)).toThrow(/general check digit/);
  });
});

describe('rejections', () => {
  const flip = (line: string, index: number) => {
    const d = line.replace(/\D/g, '');
    return d.slice(0, index) + ((Number(d[index]) + 1) % 10) + d.slice(index + 1);
  };

  it('a mistyped digit in any field of a bank line', () => {
    expect(() => parseBoleto(flip(BB_LINE, 5))).toThrow(/field 1 check digit/);
    expect(() => parseBoleto(flip(BB_LINE, 12))).toThrow(/field 2 check digit/);
    expect(() => parseBoleto(flip(BB_LINE, 25))).toThrow(/field 3 check digit/);
    expect(() => parseBoleto(flip(BB_LINE, 32))).toThrow(/general check digit/);
    // The amount has no field digit of its own: the general digit is what catches it.
    expect(() => parseBoleto(flip(BB_LINE, 46))).toThrow(/general check digit/);
  });

  it('a mistyped digit in a collection block, or in its value', () => {
    expect(() => parseBoleto(flip(WATER_LINE, 13))).toThrow(/block 2 check digit/);
    expect(() => parseBoleto(flip(WATER_BARCODE, 10))).toThrow(/general check digit/);
  });

  it('wrong lengths, letters, other currencies, unknown identifiers and segments', () => {
    expect(() => parseBoleto(BB_LINE.replace(/\D/g, '').slice(0, 46))).toThrow(/44-digit barcode/);
    expect(() => parseBoleto(`${BB_BARCODE}1`)).toThrow(/got 45 digits/);
    expect(() => parseBoleto(BB_LINE.replace('3 1575', 'O 1575'))).toThrow(/only digits/);
    expect(() => parseBoleto(WATER_LINE.replace(/\D/g, '').slice(0, 47))).toThrow(/48 digits/);
    const otherCurrency = buildBankBoleto({
      bankCode: '001', amountCents: 1n, freeField: '0'.repeat(25),
    }).barcode.replace(/^0019/, '0010');
    expect(() => parseBoleto(otherCurrency)).toThrow(InvalidBoleto);
    expect(() => parseBoleto(`825${WATER_BARCODE.slice(3)}`)).toThrow(/identifier 5/);
    expect(() => parseBoleto(`806${WATER_BARCODE.slice(3)}`)).toThrow(/segment 0/);
  });
});

describe('commitments', () => {
  it('are the documented encoding over the barcode', () => {
    expect(boletoCommitment(BB_LINE, SALT)).toBe(keccak256(encodeAbiParameters(
      [{ type: 'string' }, { type: 'string' }, { type: 'bytes32' }],
      [BOLETO_COMMITMENT_DOMAIN, BB_BARCODE, SALT],
    )));
  });

  /// A bank receipt may show the line or the barcode; the commitment must not care which.
  it('do not depend on line, barcode or formatting', () => {
    const c = boletoCommitment(BB_LINE, SALT);
    expect(boletoCommitment(BB_BARCODE, SALT)).toBe(c);
    expect(boletoCommitment(BB_LINE.replace(/\D/g, ''), SALT)).toBe(c);
  });

  it('are unlinkable across salts, and not the bare hash anyone holding the slip could compute', () => {
    expect(boletoCommitment(BB_LINE, newBoletoSalt())).not.toBe(boletoCommitment(BB_LINE, newBoletoSalt()));
    expect(boletoCommitment(BB_LINE, SALT)).not.toBe(keccak256(toBytes(BB_BARCODE)));
  });

  it('are domain-separated from PIX key commitments', () => {
    // An 11-digit CPF and a barcode are different strings, but the domains keep even equal
    // preimages apart.
    expect(boletoCommitment(BB_LINE, SALT)).not.toBe(pixKeyCommitment('529.982.247-25', SALT));
  });

  it('refuse a malformed or all-zero salt', () => {
    expect(() => boletoCommitment(BB_LINE, '0x1234' as Hex)).toThrow(InvalidBoleto);
    expect(() => boletoCommitment(BB_LINE, `0x${'00'.repeat(32)}` as Hex)).toThrow(/no salt/);
  });
});

describe('what the chain cannot check, checked before money moves', () => {
  const now = new Date('2026-09-13T15:00:00Z');

  it('accepts a boleto for exactly the order\'s amount, not yet due', () => {
    expect(assertPayableBoleto(BB_LINE, 123_456n, { now }).amountCents).toBe(123_456n);
  });

  it('refuses a boleto whose amount is not the order\'s - the escrow would refuse the payment', () => {
    expect(() => assertPayableBoleto(BB_LINE, 123_455n, { now })).toThrow(/123456 centavos but the order is for 123455/);
  });

  it('refuses a boleto with no amount, and a reference-quantity collection document', () => {
    expect(() => assertPayableBoleto(BRADESCO_LINE, 0n, { now })).toThrow(/no amount/);
    expect(() => assertPayableBoleto(REFERENCE_LINE, 12n, { now })).toThrow(/reference quantity/);
  });

  it('refuses an overdue boleto, judged in Brasília time', () => {
    expect(() => assertPayableBoleto(ITAU_FIRST_NEW, 9_990n, { now })).toThrow(/was due 2025-02-22/);
    // 20/09/2026 at 01:00 UTC is still the 19th in Brasília: due tomorrow, payable.
    const lateEvening = new Date('2026-09-20T01:00:00Z');
    expect(brasiliaToday(lateEvening)).toBe('2026-09-19');
    expect(assertPayableBoleto(BB_LINE, 123_456n, { now: lateEvening }).dueDate).toBe('2026-09-20');
    expect(() => assertPayableBoleto(BB_LINE, 123_456n, { now: new Date('2026-09-21T04:00:00Z') }))
      .toThrow(/was due/);
  });

  it('opens a commitment only with the right line, salt and amount', () => {
    const commitment = boletoCommitment(BB_LINE, SALT);
    expect(verifyBoletoCommitment({ line: BB_LINE, salt: SALT, commitment, brlCents: 123_456n, now }).barcode)
      .toBe(BB_BARCODE);
    expect(() => verifyBoletoCommitment({
      line: BB_LINE, salt: newBoletoSalt(), commitment, brlCents: 123_456n, now,
    })).toThrow(/different boleto/);
    expect(() => verifyBoletoCommitment({
      line: WATER_LINE, salt: SALT, commitment, brlCents: 8_735n, now,
    })).toThrow(/different boleto/);
  });
});
