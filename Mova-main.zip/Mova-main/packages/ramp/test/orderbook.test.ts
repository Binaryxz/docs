import { describe, it, expect } from 'vitest';
import { matchOrder, rankOffers, costBrlCents, type Offer } from '../src/orderbook.js';
import { Rail } from '../src/attestor.js';

const ETH = 10n ** 18n;
const NATIVE = '0x0000000000000000000000000000000000000000';

function offer(p: Partial<Offer> & { offerId: string; priceBrlCentsPerEth: bigint }): Offer {
  return {
    lp: '0x' + p.offerId.padStart(40, '0'),
    asset: NATIVE,
    decimals: 18,
    rails: [Rail.PIX],
    availableWei: 10n * ETH,
    minOrderWei: ETH / 100n,
    maxOrderWei: 5n * ETH,
    verifier: '0xV',
    tier: 'RETAIL',
    settledCents: 0n,
    disputesLost: 0,
    ...p,
  } as Offer;
}

describe('cost', () => {
  it('rounds the taker obligation up, exactly as the escrow does', () => {
    // 1 wei at 3,000,000 centavos/ETH is a vanishing fraction of a centavo - and still
    // costs one. Rounding down here is a slow leak that the escrow would not accept.
    expect(costBrlCents(1n, 3_000_000n)).toBe(1n);
    expect(costBrlCents(ETH, 3_000_000n)).toBe(3_000_000n);
    expect(costBrlCents(0n, 3_000_000n)).toBe(0n);
  });

  it('never quotes less than the exact price', () => {
    for (let i = 1n; i < 500n; i++) {
      const wei = (ETH * i) / 137n;
      expect(costBrlCents(wei, 1_500_000n) * ETH).toBeGreaterThanOrEqual(wei * 1_500_000n);
    }
  });
});

describe('ranking', () => {
  it('leads with price, not reputation', () => {
    const cheapNewcomer = offer({ offerId: 'a', priceBrlCentsPerEth: 1_400_000n });
    const dearVeteran = offer({
      offerId: 'b', priceBrlCentsPerEth: 1_500_000n, settledCents: 90_000_00n,
    });
    expect(rankOffers([dearVeteran, cheapNewcomer])[0].offerId).toBe('a');
  });

  it('breaks ties by reputation, and penalises lost disputes', () => {
    const clean = offer({ offerId: 'a', priceBrlCentsPerEth: 1_500_000n, settledCents: 500_00n });
    const disputed = offer({
      offerId: 'b', priceBrlCentsPerEth: 1_500_000n, settledCents: 5_000_00n, disputesLost: 2,
    });
    expect(rankOffers([disputed, clean])[0].offerId).toBe('a');
  });

  it('is deterministic, so two matchers agree on the same book', () => {
    const book = [offer({ offerId: 'x', priceBrlCentsPerEth: 1n }), offer({ offerId: 'y', priceBrlCentsPerEth: 1n })];
    expect(rankOffers(book).map((o) => o.offerId))
      .toEqual(rankOffers([...book].reverse()).map((o) => o.offerId));
  });
});

describe('matching', () => {
  it('fills from the cheapest offer first', () => {
    const r = matchOrder(
      [offer({ offerId: 'a', priceBrlCentsPerEth: 1_600_000n }),
       offer({ offerId: 'b', priceBrlCentsPerEth: 1_500_000n })],
      { asset: NATIVE, weiWanted: ETH },
    );
    expect(r.fills).toHaveLength(1);
    expect(r.fills[0].offerId).toBe('b');
    expect(r.totalBrlCents).toBe(1_500_000n);
    expect(r.unfilledWei).toBe(0n);
  });

  it('splits across offers when one cannot cover the size', () => {
    const r = matchOrder(
      [offer({ offerId: 'a', priceBrlCentsPerEth: 1_500_000n, availableWei: 2n * ETH, maxOrderWei: 2n * ETH }),
       offer({ offerId: 'b', priceBrlCentsPerEth: 1_600_000n, availableWei: 5n * ETH })],
      { asset: NATIVE, weiWanted: 4n * ETH },
    );
    expect(r.fills.map((f) => f.offerId)).toEqual(['a', 'b']);
    expect(r.filledWei).toBe(4n * ETH);
    expect(r.unfilledWei).toBe(0n);
  });

  it('reports what it could not fill rather than silently filling less', () => {
    const r = matchOrder([offer({ offerId: 'a', priceBrlCentsPerEth: 1n, availableWei: ETH, maxOrderWei: ETH })],
      { asset: NATIVE, weiWanted: 5n * ETH });
    expect(r.filledWei).toBe(ETH);
    expect(r.unfilledWei).toBe(4n * ETH);
  });

  it('bounds the number of bank transfers a taker is handed', () => {
    const book = Array.from({ length: 20 }, (_, i) =>
      offer({ offerId: `o${i}`, priceBrlCentsPerEth: BigInt(1_500_000 + i),
              availableWei: ETH / 2n, maxOrderWei: ETH / 2n }));
    const r = matchOrder(book, { asset: NATIVE, weiWanted: 10n * ETH }, 3);
    expect(r.fills.length).toBeLessThanOrEqual(3);
    expect(r.unfilledWei).toBeGreaterThan(0n); // honest about the shortfall
  });

  it('never spends more than the taker asked for', () => {
    const r = matchOrder(
      [offer({ offerId: 'a', priceBrlCentsPerEth: 1_500_000n, minOrderWei: 2n * ETH })],
      { asset: NATIVE, weiWanted: ETH },
    );
    // The only way to use this offer is to buy 2 ETH when 1 was wanted. Refuse instead.
    expect(r.fills).toHaveLength(0);
    expect(r.unfilledWei).toBe(ETH);
  });

  it('honours the taker limit price', () => {
    const r = matchOrder([offer({ offerId: 'a', priceBrlCentsPerEth: 1_600_000n })],
      { asset: NATIVE, weiWanted: ETH, maxPriceBrlCentsPerEth: 1_550_000n });
    expect(r.fills).toHaveLength(0);
  });

  it('can restrict to licensed counterparties', () => {
    const r = matchOrder(
      [offer({ offerId: 'retail', priceBrlCentsPerEth: 1_400_000n }),
       offer({ offerId: 'inst', priceBrlCentsPerEth: 1_500_000n, tier: 'INSTITUTIONAL' })],
      { asset: NATIVE, weiWanted: ETH, requireInstitutional: true },
    );
    expect(r.fills[0].offerId).toBe('inst');
  });

  it('respects the verifiers a taker is willing to trust', () => {
    const r = matchOrder(
      [offer({ offerId: 'a', priceBrlCentsPerEth: 1_400_000n, verifier: '0xUNTRUSTED' }),
       offer({ offerId: 'b', priceBrlCentsPerEth: 1_500_000n, verifier: '0xOK' })],
      { asset: NATIVE, weiWanted: ETH, allowedVerifiers: ['0xOK'] },
    );
    expect(r.fills[0].offerId).toBe('b');
  });

  it('quotes each leg at its own price, not a blended one', () => {
    const r = matchOrder(
      [offer({ offerId: 'a', priceBrlCentsPerEth: 1_500_000n, availableWei: ETH, maxOrderWei: ETH }),
       offer({ offerId: 'b', priceBrlCentsPerEth: 1_600_000n })],
      { asset: NATIVE, weiWanted: 2n * ETH },
    );
    expect(r.totalBrlCents).toBe(1_500_000n + 1_600_000n);
  });
});

describe('assets and rails', () => {
  const USDC = '0x00000000000000000000000000000000000000dc';

  it('does not mix assets: an ETH request never fills from a USDC offer', () => {
    const r = matchOrder(
      [offer({ offerId: 'usdc', priceBrlCentsPerEth: 550n, asset: USDC, decimals: 6 })],
      { asset: NATIVE, weiWanted: ETH },
    );
    expect(r.fills).toHaveLength(0);
    expect(r.unfilledWei).toBe(ETH);
  });

  it('prices a 6-decimal asset in its own units', () => {
    // 100 USDC at R$5.50 is R$550.00. With 1e18 math this would be off by 1e12.
    expect(costBrlCents(100n * 10n ** 6n, 550n, 6)).toBe(55_000n);
  });

  it('fills a stablecoin request from a stablecoin offer', () => {
    const r = matchOrder(
      [offer({
        offerId: 'usdc', priceBrlCentsPerEth: 550n, asset: USDC, decimals: 6,
        availableWei: 1000n * 10n ** 6n, minOrderWei: 10n ** 6n, maxOrderWei: 500n * 10n ** 6n,
      })],
      { asset: USDC, weiWanted: 100n * 10n ** 6n },
    );
    expect(r.fills[0].brlCents).toBe(55_000n);
    expect(r.fills[0].asset).toBe(USDC);
  });

  /** SR2-27: a shielded leg below the pool minimum locks, gets paid, and can never land. */
  describe('a shielded delivery\'s minimum leg', () => {
    const USDT = '0xdac17f958d2ee523a2206206994597c13d831ec7';
    const U = 10n ** 6n;
    const usdt = (id: string, price: bigint, available: bigint) => offer({
      offerId: id, priceBrlCentsPerEth: price, asset: USDT, decimals: 6,
      availableWei: available * U, minOrderWei: U, maxOrderWei: 10_000n * U,
    });

    it('skips an offer too small to reach it, even the cheapest', () => {
      const book = [usdt('small', 540n, 10n), usdt('big', 545n, 1_000n)];
      expect(matchOrder(book, { asset: USDT, weiWanted: 30n * U }).fills.map((f) => f.offerId)).toEqual(['small', 'big']);
      const shielded = matchOrder(book, { asset: USDT, weiWanted: 30n * U, minFillWei: 25n * U });
      expect(shielded.fills.map((f) => [f.offerId, f.weiAmount])).toEqual([['big', 30n * U]]);
    });

    it('never quotes a request below it', () => {
      const r = matchOrder([usdt('big', 545n, 1_000n)], { asset: USDT, weiWanted: 20n * U, minFillWei: 25n * U });
      expect(r.fills).toHaveLength(0);
      expect(r.unfilledWei).toBe(20n * U);
    });

    it('shrinks a leg so the remainder can still be a leg', () => {
      // 40 from the cheap offer would leave 20, which no offer may take. 35 leaves 25.
      const r = matchOrder([usdt('cheap', 540n, 40n), usdt('next', 545n, 1_000n)], { asset: USDT, weiWanted: 60n * U, minFillWei: 25n * U });
      expect(r.fills.map((f) => [f.offerId, f.weiAmount])).toEqual([['cheap', 35n * U], ['next', 25n * U]]);
      expect(r.unfilledWei).toBe(0n);
      expect(r.fills.every((f) => f.weiAmount >= 25n * U)).toBe(true);
    });
  });

  /// A match that cannot settle is worse than no match: it burns the pay window.
  it('never matches a boleto-only taker to a PIX-only LP', () => {
    const r = matchOrder(
      [offer({ offerId: 'pixonly', priceBrlCentsPerEth: 1_400_000n, rails: [Rail.PIX] })],
      { asset: NATIVE, weiWanted: ETH, rails: [Rail.BOLETO] },
    );
    expect(r.fills).toHaveLength(0);
  });

  it('prefers a cheaper LP only among those that take a usable rail', () => {
    const r = matchOrder(
      [offer({ offerId: 'cheap-pix', priceBrlCentsPerEth: 1_400_000n, rails: [Rail.PIX] }),
       offer({ offerId: 'dear-boleto', priceBrlCentsPerEth: 1_500_000n, rails: [Rail.BOLETO] })],
      { asset: NATIVE, weiWanted: ETH, rails: [Rail.BOLETO] },
    );
    expect(r.fills[0].offerId).toBe('dear-boleto');
  });

  it('reports the rails a fill can actually be paid with', () => {
    const r = matchOrder(
      [offer({ offerId: 'both', priceBrlCentsPerEth: 1_400_000n, rails: [Rail.PIX, Rail.BOLETO] })],
      { asset: NATIVE, weiWanted: ETH, rails: [Rail.BOLETO, Rail.TED] },
    );
    expect(r.fills[0].rails).toEqual([Rail.BOLETO]);
  });
});
