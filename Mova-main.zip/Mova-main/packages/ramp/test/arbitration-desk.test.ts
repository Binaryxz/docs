import { describe, it, expect } from 'vitest';
import { mkdtempSync, readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { getAddress, zeroAddress } from 'viem';
import { generatePrivateKey, privateKeyToAccount } from 'viem/accounts';
import { Arbitrator, evidenceDigest, signEvidence } from '../src/disputes.js';
import {
  ArbitrationDesk, DEFAULT_RULING_MARGIN_SECONDS, FileCaseStore, MemoryCaseStore, ONRAMP_DISPUTED,
  OFFRAMP_DISPUTED, ORDERS_FN, RULING_DELAY_SECONDS, SALES_FN, chainEscrowReader,
  type EscrowReader, type EscrowRecord, type OpenCaseInput,
} from '../src/arbitration-desk.js';
import { OFFERS_FN } from '../src/indexer.js';

const TAKER_KEY = generatePrivateKey();
const LP_KEY = generatePrivateKey();
const STRANGER_KEY = generatePrivateKey();
const TAKER = privateKeyToAccount(TAKER_KEY).address;
const LP = privateKeyToAccount(LP_KEY).address;
const SELLER = privateKeyToAccount(generatePrivateKey()).address;

const ORDER = ('0x' + 'a1'.repeat(32)) as `0x${string}`;
const ORDER_B = ('0x' + 'b2'.repeat(32)) as `0x${string}`;
const SALE = ('0x' + 'c3'.repeat(32)) as `0x${string}`;
const ESCROW = '0x00000000000000000000000000000000000000e5' as `0x${string}`;
const OFFRAMP = '0x00000000000000000000000000000000000000e6' as `0x${string}`;

type Chain = Map<string, EscrowRecord>;

const T0 = 1_700_000_000;
const DAY = 86_400;
/** Disputed on-chain at T0, on an escrow with the default 30-day DISPUTE_TIMEOUT. */
const DEADLINE = { disputedAt: T0, expiresAt: T0 + 30 * DAY };

/** The escrow as the desk sees it: a table of what each order's storage says. */
function stubChain(): Chain {
  return new Map<string, EscrowRecord>([
    [`${ESCROW}:${ORDER}`, { disputed: true, parties: { taker: TAKER, lp: LP }, ...DEADLINE }],
    [`${ESCROW}:${ORDER_B}`, { disputed: true, parties: { taker: TAKER, lp: LP }, ...DEADLINE }],
    [`${OFFRAMP}:${SALE}`, { disputed: true, parties: { seller: SELLER, lp: LP }, ...DEADLINE }],
  ]);
}

function stubReader(chain: Chain): EscrowReader & { reads: number } {
  const r = {
    reads: 0,
    async read({ escrow, orderId }: { escrow: `0x${string}`; orderId: `0x${string}` }) {
      r.reads++;
      // An id the escrow never saw reads back as zeroes, exactly as a Solidity getter does.
      return chain.get(`${escrow.toLowerCase()}:${orderId.toLowerCase()}`)
        ?? { disputed: false, parties: { taker: zeroAddress, lp: zeroAddress }, disputedAt: 0, expiresAt: 0 };
    },
  };
  return r;
}

function desk(now = { t: 1_700_000_000 }, opts: { chain?: Chain; windowSeconds?: number } = {}) {
  const chain = opts.chain ?? stubChain();
  const reader = stubReader(chain);
  const d = new ArbitrationDesk(
    new MemoryCaseStore(),
    new Arbitrator(generatePrivateKey()),
    {
      chainId: 1,
      escrows: [{ address: ESCROW, leg: 'onramp' }, { address: OFFRAMP, leg: 'offramp' }],
      reader,
      responseWindowSeconds: opts.windowSeconds,
    },
    () => now.t,
  );
  return { d, now, chain, reader };
}

const input: OpenCaseInput = {
  orderId: ORDER, escrow: ESCROW, raisedBy: 'taker', reason: 'paid but the attestor is offline',
};

/** Sign as a party, the way the real submission flow does. */
async function submit(
  d: ArbitrationDesk, caseId: string, key: `0x${string}`,
  ev: { digest: `0x${string}`; kind: string; uri?: string },
) {
  const sig = await signEvidence(key, { caseId, orderId: ORDER, escrow: ESCROW, chainId: 1 }, ev);
  return d.submitEvidence(caseId, ev, sig);
}

describe('intake', () => {
  it('opens a case with a deadline and a default outcome', async () => {
    const { d, now } = desk();
    const rec = await d.open(input);
    expect(rec.status).toBe('OPEN');
    expect(rec.case.respondBy).toBe(now.t + 72 * 3600);
    // Silence must not be a way to get paid.
    expect(rec.case.defaultRuling).toBe('REFUND');
  });

  it('stores commitments, never the material', async () => {
    const { d } = desk();
    const rec = await d.open(input);
    const updated = await submit(d, rec.caseId, TAKER_KEY, {
      digest: evidenceDigest('statement naming a CPF'), kind: 'bank-statement', uri: 'https://parties-only.example/1',
    });
    expect(JSON.stringify(updated)).not.toContain('CPF');
    expect(updated.case.evidence[0].digest).toMatch(/^0x[0-9a-f]{64}$/);
  });

  it('rejects the same evidence twice', async () => {
    const { d } = desk();
    const rec = await d.open(input);
    const e = { digest: evidenceDigest('x'), kind: 'a' };
    await submit(d, rec.caseId, TAKER_KEY, e);
    await expect(submit(d, rec.caseId, TAKER_KEY, e)).rejects.toThrow(/already submitted/);
  });
});

describe('deadlines', () => {
  it('does not surface a case while the window is open and one side has spoken', async () => {
    const { d } = desk();
    const rec = await d.open(input);
    await submit(d, rec.caseId, TAKER_KEY, {
      digest: evidenceDigest('receipt'), kind: 'pix-receipt',
    });
    expect(await d.dueCases()).toHaveLength(0);
  });

  it('surfaces a case once both sides have been heard', async () => {
    const { d } = desk();
    const rec = await d.open(input);
    await submit(d, rec.caseId, TAKER_KEY, {
      digest: evidenceDigest('taker'), kind: 'a',
    });
    await submit(d, rec.caseId, LP_KEY, {
      digest: evidenceDigest('lp'), kind: 'b',
    });
    expect(await d.dueCases()).toHaveLength(1);
  });

  it('surfaces a case once the window closes', async () => {
    const { d, now } = desk();
    await d.open(input);
    now.t += 72 * 3600 + 1;
    expect(await d.dueCases()).toHaveLength(1);
  });
});

describe('ruling', () => {
  it('signs a ruling the escrow could verify, and anyone can attribute', async () => {
    const { d } = desk();
    const rec = await d.open(input);
    const ev = evidenceDigest('pix receipt');
    await submit(d, rec.caseId, TAKER_KEY, { digest: ev, kind: 'pix-receipt' });

    await d.rule(rec.caseId, 'RELEASE', 'receipt matches amount and payee', [ev]);
    const v = await d.verify(rec.caseId);
    expect(v.matchesDesk).toBe(true);
    expect(v.signer).toBe(d.arbitratorAddress);
  });

  it('refuses to cite evidence the case does not hold', async () => {
    const { d } = desk();
    const rec = await d.open(input);
    await submit(d, rec.caseId, TAKER_KEY, {
      digest: evidenceDigest('real'), kind: 'a',
    });
    await expect(
      d.rule(rec.caseId, 'RELEASE', 'trust me', [evidenceDigest('never submitted')]),
    ).rejects.toThrow(/not in the case/);
  });

  it('will not rule twice', async () => {
    const { d } = desk();
    const rec = await d.open(input);
    const ev = evidenceDigest('e');
    await submit(d, rec.caseId, TAKER_KEY, { digest: ev, kind: 'a' });
    await d.rule(rec.caseId, 'RELEASE', 'ok', [ev]);
    await expect(d.rule(rec.caseId, 'REFUND', 'changed my mind', [ev]))
      .rejects.toThrow(/already ruled/);
  });

  it('will not accept evidence after ruling', async () => {
    const { d } = desk();
    const rec = await d.open(input);
    const ev = evidenceDigest('e');
    await submit(d, rec.caseId, TAKER_KEY, { digest: ev, kind: 'a' });
    await d.rule(rec.caseId, 'RELEASE', 'ok', [ev]);
    await expect(submit(d, rec.caseId, LP_KEY, {
      digest: evidenceDigest('late'), kind: 'b',
    })).rejects.toThrow(/already ruled/);
  });
});

describe('default rulings', () => {
  it('defaults once the window closes with one side silent', async () => {
    const { d, now } = desk();
    const rec = await d.open(input);
    await submit(d, rec.caseId, TAKER_KEY, {
      digest: evidenceDigest('taker only'), kind: 'a',
    });
    now.t += 72 * 3600 + 1;
    const ruled = await d.ruleByDefault(rec.caseId);
    expect(ruled.ruling?.byDefault).toBe(true);
    expect(ruled.ruling?.outcome).toBe('REFUND');
  });

  it('will not default while the window is open', async () => {
    const { d } = desk();
    const rec = await d.open(input);
    await expect(d.ruleByDefault(rec.caseId)).rejects.toThrow(/window is still open/);
  });

  /// The property that keeps "we ran out of patience" from looking like a decision.
  it('will not default a case both sides engaged with', async () => {
    const { d, now } = desk();
    const rec = await d.open(input);
    await submit(d, rec.caseId, TAKER_KEY, {
      digest: evidenceDigest('taker'), kind: 'a',
    });
    await submit(d, rec.caseId, LP_KEY, {
      digest: evidenceDigest('lp'), kind: 'b',
    });
    now.t += 72 * 3600 + 1;
    await expect(d.ruleByDefault(rec.caseId)).rejects.toThrow(/on the merits/);
  });
});

describe('handing it to the chain', () => {
  it('produces the exact call anyone submits, and when it can execute', async () => {
    const { d } = desk();
    const rec = await d.open(input);
    const ev = evidenceDigest('e');
    await submit(d, rec.caseId, TAKER_KEY, { digest: ev, kind: 'a' });
    await d.rule(rec.caseId, 'RELEASE', 'paid', [ev]);

    const sub = await d.submission(rec.caseId);
    expect(sub.fn).toBe('resolveDispute');
    expect(sub.args[0]).toBe(ORDER);
    expect(sub.args[1].outcome).toBe('RELEASE');
    expect(sub.args[2]).toMatch(/^0x[0-9a-f]{130}$/);
    expect(sub.arbitrator).toBe(d.arbitratorAddress);
    expect(sub.executableAfter).toBe(RULING_DELAY_SECONDS);
    expect(sub.expiresAt).toBe(DEADLINE.expiresAt);
  });

  it('has nothing to submit before a ruling', async () => {
    const { d } = desk();
    const rec = await d.open(input);
    await expect(d.submission(rec.caseId)).rejects.toThrow(/no ruling yet/);
  });

  it('rejects an unknown case rather than inventing one', async () => {
    const { d } = desk();
    await expect(d.submission('nope')).rejects.toThrow(/no such case/);
  });
});

describe('who may speak', () => {
  /**
   * The bug this replaced.
   *
   * `submittedBy` was a plain field the caller set. A taker could submit once as themselves
   * and once as the LP, `respondedSides` would report two sides, `ruleByDefault` would
   * refuse as "contested", and the escrowed funds stayed frozen for as long as the attacker
   * liked - which is exactly the failure the response deadline exists to prevent, performed
   * by the party who opened the dispute.
   */
  it('a party cannot impersonate the other to block a default ruling', async () => {
    const { d, now } = desk();
    const rec = await d.open(input);
    await submit(d, rec.caseId, TAKER_KEY, { digest: evidenceDigest('mine'), kind: 'a' });

    // The taker tries to speak for the LP, who never showed up.
    const forged = { digest: evidenceDigest('forged'), kind: 'b' };
    const sig = await signEvidence(
      TAKER_KEY, { caseId: rec.caseId, orderId: ORDER, escrow: ESCROW, chainId: 1 }, forged,
    );
    const after = await d.submitEvidence(rec.caseId, forged, sig);
    expect(after.case.evidence.every((e) => e.submittedBy === 'taker'))
      .toBe(true); // attributed to whoever signed, not to whoever was claimed

    now.t += 72 * 3600 + 1;
    const ruled = await d.ruleByDefault(rec.caseId);
    expect(ruled.ruling?.byDefault).toBe(true);
    expect(ruled.ruling?.outcome).toBe('REFUND');
  });

  it('refuses evidence from someone who is not a party', async () => {
    const { d } = desk();
    const rec = await d.open(input);
    await expect(
      submit(d, rec.caseId, STRANGER_KEY, { digest: evidenceDigest('x'), kind: 'a' }),
    ).rejects.toThrow(/is not a party to this case/);
  });

  it('records which address actually signed', async () => {
    const { d } = desk();
    const rec = await d.open(input);
    const r = await submit(d, rec.caseId, LP_KEY, { digest: evidenceDigest('lp doc'), kind: 'a' });
    expect(r.case.evidence[0].submitter).toBe(LP);
    expect(r.case.evidence[0].submittedBy).toBe('lp');
  });

  /// A signature for one case must not be replayable into another.
  it('rejects a signature made for a different case', async () => {
    const { d } = desk();
    const a = await d.open(input);
    const b = await d.open({ ...input, orderId: ORDER_B });
    const ev = { digest: evidenceDigest('x'), kind: 'a' };
    // Everything but the caseId matches case B, so the caseId alone is what must bind it.
    const sigForA = await signEvidence(
      TAKER_KEY, { caseId: a.caseId, orderId: ORDER_B, escrow: ESCROW, chainId: 1 }, ev,
    );
    await expect(d.submitEvidence(b.caseId, ev, sigForA)).rejects.toThrow(/not a party/);
  });

  /// ...and a genuine contest still cannot be defaulted away.
  it('still refuses to default when both parties really did respond', async () => {
    const { d, now } = desk();
    const rec = await d.open(input);
    await submit(d, rec.caseId, TAKER_KEY, { digest: evidenceDigest('t'), kind: 'a' });
    await submit(d, rec.caseId, LP_KEY, { digest: evidenceDigest('l'), kind: 'b' });
    now.t += 72 * 3600 + 1;
    await expect(d.ruleByDefault(rec.caseId)).rejects.toThrow(/on the merits/);
  });
});

describe('intake trusts the chain, not the filer', () => {
  /**
   * The bug this replaced: `parties`, `responseWindowSeconds` and `defaultRuling` came from
   * the request. A taker could name a second key of their own as the LP, give the real LP a
   * one-second window and a RELEASE default, and be paid for the LP's silence.
   */
  it('takes the parties from the escrow, and the deadline and default from policy', async () => {
    const { d, now, reader } = desk({ t: 1_700_000_000 }, { windowSeconds: 48 * 3600 });
    const rec = await d.open(input);
    expect(reader.reads).toBe(1);
    expect(rec.case.parties).toEqual({ taker: getAddress(TAKER), lp: getAddress(LP) });
    expect(rec.case.respondBy).toBe(now.t + 48 * 3600);
    expect(rec.case.defaultRuling).toBe('REFUND');
    expect(rec.case.leg).toBe('onramp');
    expect(rec.case.chainId).toBe(1);
  });

  it('reads the seller and claiming LP for an off-ramp sale, and still defaults to REFUND', async () => {
    const { d } = desk();
    const rec = await d.open({
      orderId: SALE, escrow: OFFRAMP, raisedBy: 'seller', reason: 'no PIX arrived',
    });
    expect(rec.case.leg).toBe('offramp');
    expect(rec.case.parties).toEqual({ seller: getAddress(SELLER), lp: getAddress(LP) });
    // REFUND on the off-ramp returns the crypto to the seller who escrowed it.
    expect(rec.case.defaultRuling).toBe('REFUND');
  });

  it.each([
    ['parties', { parties: { taker: TAKER, lp: privateKeyToAccount(STRANGER_KEY).address } }],
    ['responseWindowSeconds', { responseWindowSeconds: 1 }],
    ['defaultRuling', { defaultRuling: 'RELEASE' }],
  ])('refuses a filer-supplied %s rather than using or silently dropping it', async (field, extra) => {
    const { d, reader } = desk();
    await expect(d.open({ ...input, ...extra } as OpenCaseInput))
      .rejects.toThrow(new RegExp(`${field} is not the filer's to set`));
    expect(reader.reads).toBe(0);
    expect(await d.dueCases()).toHaveLength(0);
  });

  it('refuses an order the escrow does not report as DISPUTED', async () => {
    const chain = stubChain();
    chain.set(`${ESCROW}:${ORDER}`, { disputed: false, parties: { taker: TAKER, lp: LP }, disputedAt: 0, expiresAt: 0 });
    const { d } = desk(undefined, { chain });
    await expect(d.open(input)).rejects.toThrow(/not DISPUTED on the escrow/);
  });

  /// An id the escrow never saw reads back as zeroes, and address(0) can never answer.
  it('refuses an order the escrow records no party for', async () => {
    const chain = stubChain();
    chain.set(`${ESCROW}:${ORDER}`, { disputed: true, parties: { taker: TAKER, lp: zeroAddress }, ...DEADLINE });
    const { d } = desk(undefined, { chain });
    await expect(d.open(input)).rejects.toThrow(/records no lp/);
  });

  it('refuses a second case for the same order while the first is open', async () => {
    const { d } = desk();
    await d.open(input);
    await expect(d.open({ ...input, raisedBy: 'lp', reason: 'my turn' }))
      .rejects.toThrow(/already has a case/);
    // ...however the escrow address is spelled.
    await expect(d.open({ ...input, escrow: getAddress(ESCROW) }))
      .rejects.toThrow(/already has a case/);
  });

  /// A ruled case whose ruling is not yet submitted leaves the order DISPUTED on-chain; a
  /// second case could only mint a second, contradicting signed ruling.
  it('refuses a second case after the first was ruled', async () => {
    const { d } = desk();
    const rec = await d.open(input);
    const ev = evidenceDigest('e');
    await submit(d, rec.caseId, TAKER_KEY, { digest: ev, kind: 'a' });
    await d.rule(rec.caseId, 'RELEASE', 'paid', [ev]);
    await expect(d.open(input)).rejects.toThrow(/already has a case/);
  });

  it('refuses the loser of two concurrent opens for the same order', async () => {
    const { d } = desk();
    const results = await Promise.allSettled([d.open(input), d.open(input)]);
    expect(results.filter((r) => r.status === 'fulfilled')).toHaveLength(1);
    expect(results.filter((r) => r.status === 'rejected')).toHaveLength(1);
  });

  /// A case against a contract the filer deployed would read parties the filer invented.
  it('refuses an escrow the desk is not configured for', async () => {
    const { d } = desk();
    await expect(d.open({ ...input, escrow: '0x00000000000000000000000000000000000000ff' }))
      .rejects.toThrow(/does not arbitrate escrow/);
  });

  it('refuses a leg or chain that disagrees with the desk', async () => {
    const { d } = desk();
    await expect(d.open({ ...input, leg: 'offramp' })).rejects.toThrow(/is the onramp escrow/);
    await expect(d.open({ ...input, chainId: 11155111 })).rejects.toThrow(/arbitrates chain 1/);
  });

  it('refuses a raisedBy side the escrow does not record', async () => {
    const { d } = desk();
    await expect(d.open({ ...input, raisedBy: 'seller' }))
      .rejects.toThrow(/raisedBy must be one of taker, lp/);
    // An inherited property is not a recorded side.
    await expect(d.open({ ...input, raisedBy: '__proto__' as never }))
      .rejects.toThrow(/raisedBy must be one of taker, lp/);
  });

  it('refuses a malformed order id or escrow before touching the chain', async () => {
    const { d, reader } = desk();
    await expect(d.open({ ...input, orderId: '0x1234' })).rejects.toThrow(/bytes32/);
    await expect(d.open({ ...input, escrow: '0xnope' as `0x${string}` }))
      .rejects.toThrow(/must be an address/);
    expect(reader.reads).toBe(0);
  });
});

describe('reading the escrow', () => {
  const OFFER_ID = ('0x' + '0f'.repeat(32)) as `0x${string}`;
  const EMPTY = `0x${'00'.repeat(32)}`;

  /** A client that answers the three getters with fixed tuples, recording what was asked. */
  function client(state: number) {
    const calls: string[] = [];
    return {
      calls,
      readContract: async ({ functionName, args }: { functionName: string; args: readonly unknown[] }) => {
        calls.push(functionName);
        if (functionName === 'orders') return [OFFER_ID, TAKER, 1n, 1n, 0n, 0n, state, 0, TAKER, 0n, 0n];
        if (functionName === 'offers') {
          // The LP must come from the order's own offer, not any offer.
          if (args[0] !== OFFER_ID) throw new Error('read the wrong offer');
          return [LP, zeroAddress, 0n, 1n, 1n, EMPTY, 0n, 0n, zeroAddress, 2, true];
        }
        if (functionName === 'sales') {
          return [SELLER, zeroAddress, 1n, 1n, EMPTY, zeroAddress, 2, LP, 0n, 0n, SELLER, state];
        }
        if (functionName === 'disputedAt') return BigInt(T0);
        if (functionName === 'DISPUTE_TIMEOUT') return BigInt(30 * DAY);
        throw new Error(`unexpected read ${functionName}`);
      },
    };
  }

  it('reads the taker from the order and the LP from its offer', async () => {
    const c = client(ONRAMP_DISPUTED);
    const r = await chainEscrowReader(c as never).read({ escrow: ESCROW, leg: 'onramp', orderId: ORDER });
    expect(r).toEqual({ disputed: true, parties: { taker: TAKER, lp: LP }, ...DEADLINE });
    expect(c.calls).toEqual(['orders', 'offers', 'disputedAt', 'DISPUTE_TIMEOUT']);
  });

  it('reads the seller and the claiming LP from the sale', async () => {
    const r = await chainEscrowReader(client(OFFRAMP_DISPUTED) as never)
      .read({ escrow: OFFRAMP, leg: 'offramp', orderId: SALE });
    expect(r).toEqual({ disputed: true, parties: { seller: SELLER, lp: LP }, ...DEADLINE });
  });

  it('does not mistake another state for DISPUTED', async () => {
    expect((await chainEscrowReader(client(1) as never)
      .read({ escrow: ESCROW, leg: 'onramp', orderId: ORDER })).disputed).toBe(false);
    // The on-ramp's DISPUTED number is the off-ramp's CANCELLED.
    expect((await chainEscrowReader(client(ONRAMP_DISPUTED) as never)
      .read({ escrow: OFFRAMP, leg: 'offramp', orderId: SALE })).disputed).toBe(false);
  });

  /**
   * The getters are positional. If a struct gains or reorders a member every index shifts,
   * and the desk would read the wrong address as a party. So the ABI is checked against the
   * Solidity source itself rather than against a copy of it.
   */
  const solidity = (file: string) =>
    readFileSync(new URL(`../../../contracts/ramp/${file}`, import.meta.url), 'utf8');
  const block = (src: string, kind: 'struct' | 'enum', name: string): string => {
    const m = src.match(new RegExp(`${kind} ${name} \\{([^}]*)\\}`));
    if (!m) throw new Error(`${kind} ${name} not found`);
    return m[1].replace(/\/\/.*$/gm, '');
  };
  const members = (src: string, name: string) =>
    block(src, 'struct', name).split(';').map((l) => l.trim()).filter(Boolean)
      .map((l) => l.split(/\s+/).pop());
  const enumIndex = (src: string, name: string, value: string) =>
    block(src, 'enum', name).split(',').map((v) => v.trim()).indexOf(value);

  it('matches struct Order, struct Offer and struct Sale member for member', () => {
    const fiat = solidity('FiatEscrow.sol');
    const off = solidity('OffRampEscrow.sol');
    expect(ORDERS_FN.outputs.map((o) => o.name)).toEqual(members(fiat, 'Order'));
    expect(OFFERS_FN.outputs.map((o) => o.name)).toEqual(members(fiat, 'Offer'));
    expect(SALES_FN.outputs.map((o) => o.name)).toEqual(members(off, 'Sale'));
  });

  /**
   * The desk's timing is only safe if it matches the contracts': a ruling signed with less
   * than two RULING_DELAYs to spare cannot post and execute, and a response window longer than
   * half the shortest DISPUTE_TIMEOUT would let a slow desk lose cases to the default.
   */
  it('keeps its deadlines consistent with the escrows\' own constants', () => {
    const constant = (src: string, name: string) => {
      const m = src.match(new RegExp(`${name} = (\\d+) (days|hours)`));
      if (!m) throw new Error(`${name} not found`);
      return Number(m[1]) * (m[2] === 'days' ? DAY : 3600);
    };
    for (const file of ['FiatEscrow.sol', 'OffRampEscrow.sol']) {
      const src = solidity(file);
      expect(constant(src, 'RULING_DELAY'), file).toBe(RULING_DELAY_SECONDS);
      expect(72 * 3600 * 2, `${file}: default response window vs MIN_DISPUTE_TIMEOUT`)
        .toBeLessThanOrEqual(constant(src, 'MIN_DISPUTE_TIMEOUT'));
    }
    expect(DEFAULT_RULING_MARGIN_SECONDS).toBeGreaterThanOrEqual(2 * RULING_DELAY_SECONDS);
  });

  it('uses the DISPUTED index each escrow actually declares', () => {
    expect(enumIndex(solidity('FiatEscrow.sol'), 'OrderState', 'DISPUTED')).toBe(ONRAMP_DISPUTED);
    expect(enumIndex(solidity('OffRampEscrow.sol'), 'SaleState', 'DISPUTED')).toBe(OFFRAMP_DISPUTED);
  });
});

describe('a desk that survives a restart', () => {
  it('keeps its cases, and with them the one-case-per-order rule', async () => {
    const dir = mkdtempSync(join(tmpdir(), 'desk-'));
    try {
      const path = join(dir, 'cases.json');
      const policy = {
        chainId: 1,
        escrows: [{ address: ESCROW, leg: 'onramp' as const }],
        reader: stubReader(stubChain()),
      };
      const arb = new Arbitrator(generatePrivateKey());
      const first = new ArbitrationDesk(new FileCaseStore(path), arb, policy, () => T0);
      const rec = await first.open(input);
      await submit(first, rec.caseId, TAKER_KEY, { digest: evidenceDigest('kept'), kind: 'a' });

      const second = new ArbitrationDesk(new FileCaseStore(path), arb, policy, () => T0);
      const back = await second.get(rec.caseId);
      expect(back?.case.parties.lp).toBe(getAddress(LP));
      expect(back?.case.evidence).toHaveLength(1);
      await expect(second.open(input)).rejects.toThrow(/already has a case/);
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });

  /// Concurrent writes must not overwrite each other's snapshot of the file.
  it('keeps every case when several are written at once', async () => {
    const dir = mkdtempSync(join(tmpdir(), 'desk-'));
    try {
      const path = join(dir, 'cases.json');
      const store = new FileCaseStore(path);
      const { d } = desk();
      const recs = await Promise.all([
        d.open(input), d.open({ ...input, orderId: ORDER_B }),
        d.open({ orderId: SALE, escrow: OFFRAMP, raisedBy: 'seller', reason: 'x' }),
      ]);
      await Promise.all(recs.map((r) => store.put(r)));
      expect(await new FileCaseStore(path).all()).toHaveLength(3);
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });
});

describe('the escrow\'s deadline bounds the desk\'s', () => {
  /// A case opened days after the dispute was raised on-chain still leaves time to rule.
  it('cuts a late case\'s response window short so a ruling can still execute', async () => {
    const chain = stubChain();
    chain.set(`${ESCROW}:${ORDER}`, {
      disputed: true, parties: { taker: TAKER, lp: LP }, disputedAt: T0 - 26 * DAY, expiresAt: T0 + 4 * DAY,
    });
    const { d, now } = desk({ t: T0 }, { chain });
    const rec = await d.open(input);
    expect(rec.case.expiresAt).toBe(T0 + 4 * DAY);
    expect(rec.case.respondBy).toBe(T0 + 4 * DAY - DEFAULT_RULING_MARGIN_SECONDS);
    expect(rec.case.respondBy).toBeLessThan(now.t + 72 * 3600);
  });

  it('refuses a case too close to the deadline for any ruling to land', async () => {
    const chain = stubChain();
    chain.set(`${ESCROW}:${ORDER}`, {
      disputed: true, parties: { taker: TAKER, lp: LP }, disputedAt: T0 - 28 * DAY, expiresAt: T0 + 2 * DAY,
    });
    const { d } = desk({ t: T0 }, { chain });
    await expect(d.open(input)).rejects.toThrow(/too close to the escrow's deadline/);
  });

  /// The desk would otherwise sign a ruling the chain can no longer execute.
  it('will not rule, on the merits or by default, once too little time is left', async () => {
    const { d, now } = desk({ t: T0 });
    const rec = await d.open(input);
    const ev = evidenceDigest('late');
    await submit(d, rec.caseId, TAKER_KEY, { digest: ev, kind: 'a' });
    now.t = DEADLINE.expiresAt - DEFAULT_RULING_MARGIN_SECONDS;
    await expect(d.rule(rec.caseId, 'RELEASE', 'too late', [ev])).rejects.toThrow(/too late to rule/);
    await expect(d.ruleByDefault(rec.caseId)).rejects.toThrow(/too late to rule/);
    now.t = DEADLINE.expiresAt;
    await expect(d.rule(rec.caseId, 'RELEASE', 'later still', [ev])).rejects.toThrow(/deadline passed/);
  });

  it('surfaces a case a day before its last signing moment, whatever else is true', async () => {
    const { d, now } = desk({ t: T0 });
    const rec = await d.open(input);
    await submit(d, rec.caseId, TAKER_KEY, { digest: evidenceDigest('one side'), kind: 'a' });
    now.t = T0 + 60; // window open, one side heard: not due...
    expect(await d.dueCases()).toHaveLength(0);
    now.t = DEADLINE.expiresAt - DEFAULT_RULING_MARGIN_SECONDS - RULING_DELAY_SECONDS; // ...until now
    expect(await d.dueCases()).toHaveLength(1);
  });

  it('refuses a response window that is not well inside the escrow\'s timeout', async () => {
    const chain = stubChain();
    chain.set(`${ESCROW}:${ORDER}`, {
      disputed: true, parties: { taker: TAKER, lp: LP }, disputedAt: T0, expiresAt: T0 + 7 * DAY,
    });
    const { d } = desk({ t: T0 }, { chain, windowSeconds: 4 * DAY });
    await expect(d.open(input)).rejects.toThrow(/not well inside the escrow's dispute timeout/);
  });

  it('refuses a ruling margin shorter than the escrows need to post and execute', () => {
    expect(() => new ArbitrationDesk(new MemoryCaseStore(), new Arbitrator(generatePrivateKey()), {
      chainId: 1, escrows: [{ address: ESCROW, leg: 'onramp' }], reader: stubReader(stubChain()),
      rulingMarginSeconds: RULING_DELAY_SECONDS,
    })).toThrow(/leaves no time for a ruling/);
  });
});

describe('noticing a stolen arbitrator key', () => {
  /**
   * Submission is open to anyone, so the governor no longer sees rulings before they execute.
   * The escrow posts every ruling a day early instead; a posted ruling this desk has no record
   * of signing is a stolen key's, and this is the check that says so while there is time.
   */
  it('reports posted rulings the desk never signed, and not the ones it did', async () => {
    const { d } = desk();
    const rec = await d.open(input);
    const ev = evidenceDigest('real receipt');
    await submit(d, rec.caseId, TAKER_KEY, { digest: ev, kind: 'a' });
    const ruled = await d.rule(rec.caseId, 'RELEASE', 'paid', [ev]);

    const genuine = {
      escrow: ESCROW, orderId: ORDER, arbitrator: d.arbitratorAddress,
      evidenceRoot: ruled.evidenceRoot!, releasedToTaker: true,
    };
    const forged = { ...genuine, orderId: ORDER_B };
    const flipped = { ...genuine, releasedToTaker: false };
    const anotherDesks = { ...forged, arbitrator: privateKeyToAccount(STRANGER_KEY).address };
    expect(await d.postedRulingsNotSigned([genuine, forged, flipped, anotherDesks])).toEqual([forged, flipped]);
  });
});

describe('finding a case by its order', () => {
  it('finds the one case for an escrow and order, on either leg, whatever the casing', async () => {
    const { d } = desk();
    const onramp = await d.open(input);
    const offramp = await d.open({ orderId: SALE, escrow: OFFRAMP, raisedBy: 'seller', reason: 'no PIX arrived' });
    expect((await d.findByOrder(ESCROW, ORDER))?.caseId).toBe(onramp.caseId);
    expect((await d.findByOrder(getAddress(ESCROW), ORDER.toUpperCase().replace('0X', '0x')))?.caseId).toBe(onramp.caseId);
    expect((await d.findByOrder(OFFRAMP, SALE))?.caseId).toBe(offramp.caseId);
  });

  it('matches exactly: another order, another escrow, or another chain\'s case is not found', async () => {
    const store = new MemoryCaseStore();
    const policy = (chainId: number) => ({
      chainId, escrows: [{ address: ESCROW, leg: 'onramp' as const }], reader: stubReader(stubChain()),
    });
    const one = new ArbitrationDesk(store, new Arbitrator(generatePrivateKey()), policy(1), () => T0);
    const two = new ArbitrationDesk(store, new Arbitrator(generatePrivateKey()), policy(2), () => T0);
    await one.open(input);
    expect(await one.findByOrder(ESCROW, ORDER_B)).toBeUndefined();
    expect(await one.findByOrder(OFFRAMP, ORDER)).toBeUndefined();
    expect(await two.findByOrder(ESCROW, ORDER)).toBeUndefined();
  });

  it('refuses a malformed escrow or order id rather than matching anything', async () => {
    const { d } = desk();
    await d.open(input);
    await expect(d.findByOrder('nope', ORDER)).rejects.toThrow(/escrow must be an address/);
    await expect(d.findByOrder(ESCROW, ORDER.slice(0, 40))).rejects.toThrow(/orderId must be a bytes32/);
  });
});
