import { describe, it, expect } from 'vitest';
import { generatePrivateKey, privateKeyToAccount } from 'viem/accounts';
import { recoverTypedDataAddress } from 'viem';
import {
  PricePublisher, collectQuorum, priceDomain, PRICE_TYPES, sequenceFromTime,
  fxCentsPerUsd, crossBrlCentsPerUnit, FX_SANITY, fxMicroPerUsd, centsFromMicroPerUsd, fxObservation,
} from '../src/price-publisher.js';

const ORACLE = '0x00000000000000000000000000000000000000c1' as `0x${string}`;
const AT = 1_700_000_000n;

describe('publishing', () => {
  it('signs a price anyone can attribute', async () => {
    const key = generatePrivateKey();
    const p = new PricePublisher(key, 1, ORACLE);
    const s = await p.sign(1_244_910n, AT, AT);
    const signer = await recoverTypedDataAddress({
      domain: priceDomain(1, ORACLE), types: PRICE_TYPES, primaryType: 'Price',
      message: { brlCentsPerUnit: s.brlCentsPerUnit, publishedAt: s.publishedAt, sequence: s.sequence },
      signature: s.signature,
    });
    expect(signer).toBe(privateKeyToAccount(key).address);
  });

  it('refuses a non-positive price before it reaches the chain', async () => {
    const p = new PricePublisher(generatePrivateKey(), 1, ORACLE);
    await expect(p.sign(0n, AT, AT)).rejects.toThrow(/positive/);
  });

  /// The domain binds a price to one oracle, so it cannot be replayed at another.
  it('does not verify against a different oracle', async () => {
    const key = generatePrivateKey();
    const s = await new PricePublisher(key, 1, ORACLE).sign(1n, AT, AT);
    const signer = await recoverTypedDataAddress({
      domain: priceDomain(1, '0x00000000000000000000000000000000000000ff'),
      types: PRICE_TYPES, primaryType: 'Price',
      message: { brlCentsPerUnit: 1n, publishedAt: AT, sequence: AT },
      signature: s.signature,
    });
    expect(signer).not.toBe(privateKeyToAccount(key).address);
  });
});

describe('quorum assembly', () => {
  const mk = () => new PricePublisher(generatePrivateKey(), 1, ORACLE);

  it('sorts signatures ascending by signer, as the contract requires', async () => {
    const a = mk(); const b = mk(); const c = mk();
    const signed = await Promise.all([a, b, c].map((p) => p.sign(1_000n, AT, AT)));
    const q = collectQuorum(signed);
    const order = signed
      .slice()
      .sort((x, y) => (BigInt(x.signer) < BigInt(y.signer) ? -1 : 1))
      .map((s) => s.signature);
    expect(q.signatures).toEqual(order);
  });

  /// Catching this locally matters: on-chain it surfaces as UnknownPublisher, which points
  /// at the wrong problem entirely.
  it('refuses a set that signed different prices', async () => {
    const a = await mk().sign(1_000n, AT, AT);
    const b = await mk().sign(1_001n, AT, AT);
    expect(() => collectQuorum([a, b])).toThrow(/different prices/);
  });

  it('refuses a set that disagrees about the timestamp', async () => {
    const a = await mk().sign(1_000n, AT, AT);
    const b = await mk().sign(1_000n, AT + 1n, AT);
    expect(() => collectQuorum([a, b])).toThrow(/different prices/);
  });

  it('rejects the same publisher twice', async () => {
    const p = mk();
    const s = await p.sign(1_000n, AT, AT);
    expect(() => collectQuorum([s, s])).toThrow(/duplicate publisher/);
  });

  it('refuses an empty quorum', () => {
    expect(() => collectQuorum([])).toThrow(/no signatures/);
  });

  /// Independent publishers must land on the same sequence or their signatures never pair.
  it('derives the sequence from a shared clock', () => {
    expect(sequenceFromTime(AT)).toBe(AT);
    expect(sequenceFromTime(AT)).toBe(sequenceFromTime(AT));
  });
});

/**
 * The FX leg. Expected values are worked by hand in the comments, not taken from the code: the
 * SR2-9 inversion shipped because a formula and its fixture shared one assumption.
 */
describe('FX leg: a BRL/USD quote to centavos per dollar', () => {
  it('converts reais per dollar to the nearest centavo', () => {
    expect(fxCentsPerUsd({ brlPerUsd: '5.4049' })).toBe(540n); // 540.49
    expect(fxCentsPerUsd({ brlPerUsd: '5.405' })).toBe(541n); // 540.5, half up
    expect(fxCentsPerUsd({ brlPerUsd: '5.40' })).toBe(540n);
    expect(fxCentsPerUsd({ brlPerUsd: '5' })).toBe(500n);
  });

  it('converts dollars per real by taking the reciprocal', () => {
    expect(fxCentsPerUsd({ usdPerBrl: '0.18502' })).toBe(540n); // 100 / 0.18502 = 540.48
    expect(fxCentsPerUsd({ usdPerBrl: '0.185' })).toBe(541n); // 540.54
    expect(fxCentsPerUsd({ usdPerBrl: '0.2' })).toBe(500n);
  });

  /** SR2-9 again, caught before a signature exists: 0.18502 as reais per dollar is 19 centavos. */
  it('refuses a quote passed in the wrong direction', () => {
    expect(() => fxCentsPerUsd({ brlPerUsd: '0.18502' })).toThrow(/inverted/);
  });

  it('refuses a mis-scaled rate or an asset price', () => {
    expect(() => fxCentsPerUsd({ brlPerUsd: '540490000' })).toThrow(/mis-scaled/); // 1e8-scaled
    expect(() => fxCentsPerUsd({ brlPerUsd: '13411.89' })).toThrow(/asset price/); // R$ per ETH
  });

  it('honours narrower bounds when given', () => {
    const bounds = { minCents: 400n, maxCents: 700n };
    expect(fxCentsPerUsd({ brlPerUsd: '5.40' }, bounds)).toBe(540n);
    expect(() => fxCentsPerUsd({ brlPerUsd: '3.00' }, bounds)).toThrow(/below 400/);
    expect(FX_SANITY).toEqual({ minCents: 100n, maxCents: 10_000n });
  });

  it('accepts only plain positive decimals', () => {
    for (const bad of ['5,40', '-5.4', '5.4e0', '', ' 5.40', '.5', '5.']) {
      expect(() => fxCentsPerUsd({ brlPerUsd: bad }), bad).toThrow(/plain decimal/);
    }
    expect(() => fxCentsPerUsd({ usdPerBrl: '0' })).toThrow(/positive/);
  });

  it('signs the converted rate, so the signature is over centavos per dollar', async () => {
    const key = generatePrivateKey();
    const s = await new PricePublisher(key, 1, ORACLE).signFx({ usdPerBrl: '0.18502' }, AT, AT);
    expect(s.brlCentsPerUnit).toBe(540n);
    const signer = await recoverTypedDataAddress({
      domain: priceDomain(1, ORACLE), types: PRICE_TYPES, primaryType: 'Price',
      message: { brlCentsPerUnit: 540n, publishedAt: AT, sequence: AT },
      signature: s.signature,
    });
    expect(signer).toBe(privateKeyToAccount(key).address);
  });

  it('never signs a rate it refused', async () => {
    const p = new PricePublisher(generatePrivateKey(), 1, ORACLE);
    await expect(p.signFx({ brlPerUsd: '0.18502' }, AT, AT)).rejects.toThrow(/inverted/);
  });
});

/** The same vectors ChainlinkSignedFxOracle.t.sol asserts on-chain. */
describe('FX leg: the band a cross will report', () => {
  it('matches the contract on the mainnet-shaped vectors', () => {
    expect(crossBrlCentsPerUnit(99_972_163n, 8, 540n)).toBe(540n); // 539.849 -> 540
    expect(crossBrlCentsPerUnit(248_368_328_680n, 8, 540n)).toBe(1_341_189n); // 1,341,188.97
    expect(crossBrlCentsPerUnit(95_000_000n, 8, 600n)).toBe(570n); // a $0.95 depeg
    expect(crossBrlCentsPerUnit(10n ** 18n, 18, 540n)).toBe(540n);
    expect(crossBrlCentsPerUnit(1_000_000n, 6, 540n)).toBe(540n);
  });

  it('rounds to the nearest centavo, halves up', () => {
    expect(crossBrlCentsPerUnit(1_000_000n, 8, 250n)).toBe(3n); // 2.5
    expect(crossBrlCentsPerUnit(999_960n, 8, 250n)).toBe(2n); // 2.4999
  });

  /** Direction: a stronger dollar is more reais per token; a depeg is fewer. */
  it('moves the right way with each leg', () => {
    const base = crossBrlCentsPerUnit(100_000_000n, 8, 540n);
    expect(crossBrlCentsPerUnit(100_000_000n, 8, 600n)).toBeGreaterThan(base);
    expect(crossBrlCentsPerUnit(94_000_000n, 8, 540n)).toBeLessThan(base);
  });

  it('refuses what the contract refuses', () => {
    expect(() => crossBrlCentsPerUnit(0n, 8, 540n)).toThrow(/positive/);
    expect(() => crossBrlCentsPerUnit(1n, 19, 540n)).toThrow(/decimals/);
    expect(() => crossBrlCentsPerUnit(10_000_000n, 8, 1n)).toThrow(/zero/); // 0.1 centavo
  });
});

/**
 * The Movva reserve's leg: the same BRL/USD rate at 1e-6, and the centavo band derived from it.
 * Expected values worked by hand in the comments, as above.
 */
describe('FX leg at 1e-6: the Movva reserve\'s oracle', () => {
  it('converts reais per dollar to the nearest micro-real', () => {
    expect(fxMicroPerUsd({ brlPerUsd: '5.4012' })).toBe(5_401_200n);
    expect(fxMicroPerUsd({ brlPerUsd: '5.40123449' })).toBe(5_401_234n); // 5,401,234.49
    expect(fxMicroPerUsd({ brlPerUsd: '5.4012345' })).toBe(5_401_235n); // 5,401,234.5, half up
    expect(fxMicroPerUsd({ brlPerUsd: '5' })).toBe(5_000_000n);
  });

  it('converts dollars per real by taking the reciprocal', () => {
    expect(fxMicroPerUsd({ usdPerBrl: '0.18502' })).toBe(5_404_821n); // 1e6 / 0.18502 = 5,404,821.10
    expect(fxMicroPerUsd({ usdPerBrl: '0.2' })).toBe(5_000_000n);
    expect(fxMicroPerUsd({ usdPerBrl: '0.185' })).toBe(5_405_405n); // 5,405,405.41
  });

  it('refuses an inverted quote, a mis-scaled rate or an asset price, with the centavo bounds x 10,000', () => {
    expect(() => fxMicroPerUsd({ brlPerUsd: '0.18502' })).toThrow(/below 1000000.*inverted/); // 185,020
    expect(() => fxMicroPerUsd({ brlPerUsd: '540490000' })).toThrow(/mis-scaled/);
    expect(() => fxMicroPerUsd({ brlPerUsd: '13411.89' })).toThrow(/asset price/);
    expect(() => fxMicroPerUsd({ brlPerUsd: '3.00' }, { minCents: 400n, maxCents: 700n })).toThrow(/below 4000000/);
    expect(fxMicroPerUsd({ brlPerUsd: '100' })).toBe(100_000_000n); // the edge itself is accepted
    expect(() => fxMicroPerUsd({ brlPerUsd: '100.000001' })).toThrow(/above 100000000/);
    for (const bad of ['5,40', '-5.4', '5.4e0', '']) expect(() => fxMicroPerUsd({ brlPerUsd: bad }), bad).toThrow(/plain decimal/);
    expect(() => fxMicroPerUsd({ usdPerBrl: '0' })).toThrow(/positive/);
  });

  it('derives the centavo the band adapter exposes: nearest, halves up', () => {
    expect(centsFromMicroPerUsd(5_401_200n)).toBe(540n); // 540.12
    expect(centsFromMicroPerUsd(5_404_999n)).toBe(540n); // 540.4999
    expect(centsFromMicroPerUsd(5_405_000n)).toBe(541n); // 540.5
    expect(centsFromMicroPerUsd(5_000n)).toBe(1n); // 0.5
    expect(() => centsFromMicroPerUsd(4_999n)).toThrow(/zero/);
    expect(() => centsFromMicroPerUsd(0n)).toThrow(/positive/);
  });

  /**
   * Why both values must come from one observation: rounding the quote straight to centavos and
   * deriving centavos from the micro value can differ by a tick.
   */
  it('takes both precisions from one observation, which can differ from rounding the quote twice', () => {
    const quote = { brlPerUsd: '5.404999999' };
    expect(fxObservation(quote)).toEqual({ microPerUsd: 5_405_000n, centsPerUsd: 541n }); // 5,404,999.999 -> 5,405,000 -> 540.5 -> 541
    expect(fxCentsPerUsd(quote)).toBe(540n); // 540.4999999 -> 540: the band would sit a tick away
    expect(fxObservation({ usdPerBrl: '0.18502' })).toEqual({ microPerUsd: 5_404_821n, centsPerUsd: 540n });
  });

  it('agrees with the centavo leg to within one tick for every quote', () => {
    for (let micro = 1_000_000n; micro <= 100_000_000n; micro += 987_653n) {
      const quote = { brlPerUsd: `${micro / 1_000_000n}.${(micro % 1_000_000n).toString().padStart(6, '0')}` };
      const { microPerUsd, centsPerUsd } = fxObservation(quote);
      expect(microPerUsd).toBe(micro);
      const direct = fxCentsPerUsd(quote);
      expect(centsPerUsd - direct).toBeGreaterThanOrEqual(0n);
      expect(centsPerUsd - direct).toBeLessThanOrEqual(1n);
    }
  });

  it('signs micro-reais per dollar for the reserve\'s oracle, recoverable like any price', async () => {
    const key = generatePrivateKey();
    const s = await new PricePublisher(key, 1, ORACLE).signFxMicro({ brlPerUsd: '5.4012' }, AT, AT);
    expect(s.brlCentsPerUnit).toBe(5_401_200n);
    const signer = await recoverTypedDataAddress({
      domain: priceDomain(1, ORACLE), types: PRICE_TYPES, primaryType: 'Price',
      message: { brlCentsPerUnit: 5_401_200n, publishedAt: AT, sequence: AT },
      signature: s.signature,
    });
    expect(signer).toBe(privateKeyToAccount(key).address);
  });

  it('never signs a rate it refused', async () => {
    const p = new PricePublisher(generatePrivateKey(), 1, ORACLE);
    await expect(p.signFxMicro({ brlPerUsd: '0.18502' }, AT, AT)).rejects.toThrow(/inverted/);
    await expect(p.signFxMicro({ brlPerUsd: '540' }, AT, AT)).rejects.toThrow(/mis-scaled/);
  });
});
