import { describe, it, expect } from 'vitest';
import { generatePrivateKey, privateKeyToAccount } from 'viem/accounts';
import {
  Arbitrator, DisputeError, assertRulable, defaultRulingIfUnanswered, evidenceDigest,
  evidenceRoot, rulingSigner, toOnChainCall, type Case,
} from '../src/disputes.js';

const NOW = 1_700_000_000;
const ORDER = ('0x' + 'a1'.repeat(32)) as `0x${string}`;
const ESCROW = '0x00000000000000000000000000000000000000e5' as `0x${string}`;
const SUBMITTER = '0x00000000000000000000000000000000000000aa' as `0x${string}`;

function makeCase(over: Partial<Case> = {}): Case {
  return {
    orderId: ORDER, escrow: ESCROW, chainId: 1, leg: 'onramp',
    raisedBy: 'taker', raisedAt: NOW, reason: 'paid but attestor offline',
    respondBy: NOW + 86_400, defaultRuling: 'REFUND', expiresAt: NOW + 30 * 86_400,
    parties: { taker: SUBMITTER },
    evidence: [
      {
        digest: evidenceDigest('pix receipt pdf'), kind: 'pix-receipt',
        submittedBy: 'taker', submitter: SUBMITTER, submittedAt: NOW,
      },
    ],
    ...over,
  };
}

describe('evidence', () => {
  it('commits to material without carrying it', () => {
    const d = evidenceDigest('bank statement with a CPF in it');
    expect(d).toMatch(/^0x[0-9a-f]{64}$/);
    expect(JSON.stringify(makeCase())).not.toContain('CPF');
  });

  it('roots the same evidence to the same value regardless of order', () => {
    const a = evidenceDigest('one');
    const b = evidenceDigest('two');
    expect(evidenceRoot([a, b])).toBe(evidenceRoot([b, a]));
  });

  it('roots different evidence differently', () => {
    expect(evidenceRoot([evidenceDigest('one')])).not.toBe(evidenceRoot([evidenceDigest('two')]));
  });
});

describe('case hygiene', () => {
  it('refuses to rule on an empty case while the window is open', () => {
    expect(() => assertRulable(makeCase({ evidence: [] }), NOW)).toThrow(DisputeError);
  });

  it('allows a ruling on an empty case once the window has closed', () => {
    expect(() => assertRulable(makeCase({ evidence: [] }), NOW + 90_000)).not.toThrow();
  });

  it('rejects a malformed digest', () => {
    const c = makeCase();
    c.evidence[0].digest = '0xdeadbeef' as `0x${string}`;
    expect(() => assertRulable(c, NOW)).toThrow(/not a keccak256/);
  });

  it('rejects the same evidence submitted twice', () => {
    const d = evidenceDigest('same');
    const c = makeCase({
      evidence: [
        { digest: d, kind: 'a', submittedBy: 'taker', submitter: SUBMITTER, submittedAt: NOW },
        { digest: d, kind: 'b', submittedBy: 'lp', submitter: SUBMITTER, submittedAt: NOW },
      ],
    });
    expect(() => assertRulable(c, NOW)).toThrow(/submitted twice/);
  });
});

describe('silence', () => {
  it('does not default while the window is open', () => {
    expect(defaultRulingIfUnanswered(makeCase(), NOW)).toBeNull();
  });

  it('defaults when only one side ever spoke', () => {
    expect(defaultRulingIfUnanswered(makeCase(), NOW + 90_000)).toBe('REFUND');
  });

  /// A contested case must be decided on the merits, never quietly defaulted.
  it('does not default when both sides responded', () => {
    const c = makeCase({
      evidence: [
        { digest: evidenceDigest('taker says'), kind: 'x', submittedBy: 'taker', submitter: SUBMITTER, submittedAt: NOW },
        { digest: evidenceDigest('lp says'), kind: 'y', submittedBy: 'lp', submitter: SUBMITTER, submittedAt: NOW },
      ],
    });
    expect(defaultRulingIfUnanswered(c, NOW + 90_000)).toBeNull();
  });
});

describe('rulings', () => {
  it('is signed by the arbitrator and recoverable by anyone', async () => {
    const key = generatePrivateKey();
    const arb = new Arbitrator(key);
    const c = makeCase();
    const { ruling, signature, evidenceRoot: root } = await arb.rule(c, {
      outcome: 'RELEASE', reliedOn: [c.evidence[0].digest],
      rationale: 'receipt matches the order amount and payee', ruledAt: NOW + 100, byDefault: false,
    });
    expect(await rulingSigner(ruling, root, signature))
      .toBe(privateKeyToAccount(key).address);
  });

  /// The property that keeps a signature from laundering an unfair decision.
  it('refuses to rely on evidence the case does not contain', async () => {
    const arb = new Arbitrator(generatePrivateKey());
    await expect(arb.rule(makeCase(), {
      outcome: 'RELEASE', reliedOn: [evidenceDigest('a secret the LP never saw')],
      rationale: 'trust me', ruledAt: NOW, byDefault: false,
    })).rejects.toThrow(/not in the case/);
  });

  it('requires a merits ruling to cite something', async () => {
    const arb = new Arbitrator(generatePrivateKey());
    await expect(arb.rule(makeCase(), {
      outcome: 'RELEASE', reliedOn: [], rationale: 'because', ruledAt: NOW, byDefault: false,
    })).rejects.toThrow(/must cite the evidence/);
  });

  it('allows a default ruling to cite nothing, since nobody spoke', async () => {
    const arb = new Arbitrator(generatePrivateKey());
    const { ruling } = await arb.rule(makeCase({ evidence: [] }), {
      outcome: 'REFUND', reliedOn: [], rationale: 'no response by the deadline',
      ruledAt: NOW + 90_000, byDefault: true,
    });
    expect(ruling.byDefault).toBe(true);
  });

  it('detects a tampered ruling: the recovered signer changes', async () => {
    const key = generatePrivateKey();
    const arb = new Arbitrator(key);
    const c = makeCase();
    const { ruling, signature, evidenceRoot: root } = await arb.rule(c, {
      outcome: 'RELEASE', reliedOn: [c.evidence[0].digest],
      rationale: 'ok', ruledAt: NOW, byDefault: false,
    });
    const flipped = { ...ruling, outcome: 'REFUND' as const };
    expect(await rulingSigner(flipped, root, signature))
      .not.toBe(privateKeyToAccount(key).address);
  });
});

describe('handing the ruling to the chain', () => {
  const root = ('0x' + 'bb'.repeat(32)) as `0x${string}`;
  const sig = ('0x' + 'cc'.repeat(65)) as `0x${string}`;

  it('passes the signed struct through unchanged', () => {
    const r = {
      orderId: ORDER, escrow: ESCROW, chainId: 1, outcome: 'RELEASE' as const,
      reliedOn: [], rationale: 'paid', ruledAt: NOW, byDefault: false,
    };
    const call = toOnChainCall(r, root, sig);
    expect(call.args[0]).toBe(ORDER);
    expect(call.args[1]).toMatchObject({ outcome: 'RELEASE', evidenceRoot: root });
    expect(call.args[2]).toBe(sig);
  });

  /// The outcome must have exactly one representation, or the two can disagree.
  it('carries no boolean beside the signed outcome', () => {
    const r = {
      orderId: ORDER, escrow: ESCROW, chainId: 1, outcome: 'REFUND' as const,
      reliedOn: [], rationale: 'no payment found', ruledAt: NOW, byDefault: true,
    };
    const call = toOnChainCall(r, root, sig);
    expect(Object.keys(call.args[1])).not.toContain('releaseToTaker');
    expect(Object.keys(call.args[1])).not.toContain('paidLP');
    expect(call.args[1].outcome).toBe('REFUND');
  });

  it('the ruling id and the order id are the same field', () => {
    const r = {
      orderId: ORDER, escrow: ESCROW, chainId: 1, outcome: 'RELEASE' as const,
      reliedOn: [], rationale: 'x', ruledAt: NOW, byDefault: false,
    };
    const call = toOnChainCall(r, root, sig);
    expect(call.args[1].orderId).toBe(call.args[0]);
  });
});

describe('the escrow\'s deadline', () => {
  /// After it the escrow takes no ruling; a desk that signed anyway would mislead the winner.
  it('makes a case unrulable once the on-chain deadline has passed', () => {
    const c = makeCase();
    expect(() => assertRulable(c, c.expiresAt - 1)).not.toThrow();
    expect(() => assertRulable(c, c.expiresAt)).toThrow(/expire the dispute/);
    expect(() => assertRulable({ ...c, expiresAt: undefined as never }, NOW)).toThrow(/no on-chain deadline/);
  });
});
