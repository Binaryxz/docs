import { describe, it, expect } from 'vitest';
import { generatePrivateKey, privateKeyToAccount } from 'viem/accounts';
import { keccak256, toBytes, hashMessage, recoverAddress } from 'viem';
import {
  bindingContext, boletoPaymentContext, buildContext, buildProof, canonicalStringify, claimIdentifier, decodeProof, encodeProof, proofPayment,
  fromReclaimProof, hashProviderParams, pixPaymentContext, proofEndpoint, proofSigners, ReclaimProofError, RECEIPT_KINDS, receiptKind,
  receiptRail, receiptRailMask, receiptTemplate, receiptTemplates,
  serialiseClaim, signAsWitness, sortSignatures, type HttpProviderParams, type ReclaimSdkProof,
} from '../src/reclaim.js';
import { Rail, pixKeyCommitment } from '../src/attestor.js';
import { boletoCommitment, buildBankBoleto, newBoletoSalt } from '../src/boleto.js';

const ORDER = ('0x' + 'a1'.repeat(32)) as `0x${string}`;
const b32 = (s: string) => keccak256(toBytes(s));

const payment = {
  orderId: ORDER,
  bankTxId: b32('E2E-0001'),
  payeeKeyHash: b32('lp@pix'),
  payerRef: b32('cpf'),
  amountBrlCents: 1_500_000n,
  paidAt: 1_700_000_000n,
  rail: Rail.PIX,
};

const params: HttpProviderParams = {
  url: 'https://api.bank.example/pix/v2/{{e2eId}}',
  method: 'GET',
  body: '',
  paramValues: { e2eId: 'E0000000020260913' },
  responseMatches: [{ type: 'regex', value: '"endToEndId":"(?<bankTxId>0x[0-9a-f]{64})"' }],
  responseRedactions: [{ jsonPath: '$.pix', regex: '', xPath: '' }],
};
const TEMPLATE = hashProviderParams(params);

describe('canonical JSON', () => {
  it('sorts keys at every depth and writes no whitespace', () => {
    expect(canonicalStringify({ b: 1, a: { d: 'x', c: [2, { f: 1, e: 0 }] } }))
      .toBe('{"a":{"c":[2,{"e":0,"f":1}],"d":"x"},"b":1}');
  });

  it('drops undefined members, as the witness canonicaliser does', () => {
    expect(canonicalStringify({ a: undefined, b: 'x' })).toBe('{"b":"x"}');
  });
});

describe('the provider hash', () => {
  it('covers the template, not the per-session values', () => {
    expect(hashProviderParams({ ...params, paramValues: { e2eId: 'E-other' } })).toBe(TEMPLATE);
  });

  /// These are exactly the things a prover would change to point a session elsewhere or to
  /// lift a field out of a different part of the response.
  it('changes with the url, the method, the body, a match or a redaction', () => {
    expect(hashProviderParams({ ...params, url: 'https://evil.example/pix/v2/{{e2eId}}' })).not.toBe(TEMPLATE);
    expect(hashProviderParams({ ...params, method: 'POST' })).not.toBe(TEMPLATE);
    expect(hashProviderParams({ ...params, body: 'x' })).not.toBe(TEMPLATE);
    expect(hashProviderParams({
      ...params, responseMatches: [{ type: 'regex', value: '"memo":"(?<amountBrlCents>\\d+)"' }],
    })).not.toBe(TEMPLATE);
    expect(hashProviderParams({ ...params, responseRedactions: [] })).not.toBe(TEMPLATE);
  });
});

describe('context building', () => {
  it('binds only the order when requesting a session', () => {
    const ctx = bindingContext(ORDER);
    expect(ctx.contextMessage).toBe(ORDER);
    expect(JSON.stringify(ctx)).not.toContain('amountBrlCents');
  });

  it('writes the witness fields the on-chain reader requires, canonically', () => {
    const ctx = buildContext(payment, TEMPLATE);
    const parsed = JSON.parse(ctx);
    expect(canonicalStringify(parsed)).toBe(ctx);
    expect(parsed.providerHash).toBe(TEMPLATE);
    expect(parsed.contextMessage).toBe(ORDER);
    for (const k of ['amountBrlCents', 'bankTxId', 'payeeKeyHash', 'payerRef', 'paidAt', 'rail']) {
      expect(typeof parsed.extractedParameters[k]).toBe('string');
    }
    expect(parsed.extractedParameters.orderId).toBeUndefined();
  });

  it('quotes numbers as digit strings, because the reader takes digits only', () => {
    expect(buildContext(payment, TEMPLATE)).toContain('"amountBrlCents":"1500000"');
    expect(buildContext(payment, TEMPLATE)).toContain('"rail":"1"');
  });

  /// Hand-rolled JSON is how a field ends up in a shape the reader rejects on-chain.
  it('refuses a value that is not a 32-byte hash', () => {
    expect(() => buildContext({ ...payment, bankTxId: '0xdeadbeef' as `0x${string}` }, TEMPLATE))
      .toThrow(/not a 32-byte hex value/);
  });
});

describe('the identifier and the witness signature', () => {
  it('changes if any part of the claim changes', () => {
    const base = { provider: 'http', parameters: 'p', context: buildContext(payment, TEMPLATE) };
    const id = claimIdentifier(base);
    expect(claimIdentifier({ ...base, provider: 'https' })).not.toBe(id);
    expect(claimIdentifier({ ...base, parameters: 'q' })).not.toBe(id);
    expect(claimIdentifier({
      ...base, context: buildContext({ ...payment, amountBrlCents: 1n }, TEMPLATE),
    })).not.toBe(id);
  });

  /// Reclaim's Claims.sol: keccak256("\x19Ethereum Signed Message:\n" + len + serialised).
  it('is a personal signature over the serialised claim string, not over its hash', async () => {
    const key = generatePrivateKey();
    const claim = {
      identifier: ('0x' + '11'.repeat(32)) as `0x${string}`,
      owner: privateKeyToAccount(key).address, timestampS: 42, epoch: 7,
    };
    const sig = await signAsWitness(key, claim);
    const ser = serialiseClaim(claim);
    const manual = keccak256(toBytes(`\x19Ethereum Signed Message:\n${toBytes(ser).length}${ser}`));
    expect(hashMessage(ser)).toBe(manual);
    expect(await recoverAddress({ hash: manual, signature: sig })).toBe(privateKeyToAccount(key).address);
  });
});

describe('a real Reclaim proof', () => {
  /** A proof in the exact shape the Reclaim SDK emits. */
  async function sdkProof(over: Partial<ReclaimSdkProof['claimData']> = {}): Promise<{
    proof: ReclaimSdkProof; keys: `0x${string}`[];
  }> {
    const keys = [generatePrivateKey(), generatePrivateKey()];
    const claimData = {
      provider: 'http',
      parameters: canonicalStringify(params),
      owner: privateKeyToAccount(keys[0]).address.toLowerCase(),
      timestampS: 1_700_000_000,
      context: buildContext(payment, TEMPLATE),
      identifier: '',
      epoch: 1,
      ...over,
    };
    claimData.identifier = claimIdentifier(claimData);
    const claim = {
      identifier: claimData.identifier as `0x${string}`,
      owner: claimData.owner as `0x${string}`,
      timestampS: claimData.timestampS,
      epoch: claimData.epoch,
    };
    const signatures = await Promise.all(keys.map((k) => signAsWitness(k, claim)));
    return { proof: { identifier: claimData.identifier, claimData, signatures }, keys };
  }

  it('converts into the on-chain form and encodes', async () => {
    const { proof } = await sdkProof();
    const ours = fromReclaimProof(proof);
    expect(ours.claimInfo.provider).toBe('http');
    expect(ours.signedClaim.claim.identifier).toBe(proof.identifier);
    expect(encodeProof(ours)).toMatch(/^0x[0-9a-f]+$/);
    expect(proofEndpoint(ours)).toEqual({ providerHash: TEMPLATE, url: params.url });
  });

  /// The check that earns its keep: a tampered proof is caught here, not by a reverted tx.
  it('rejects a proof whose identifier does not match its own claim data', async () => {
    const { proof } = await sdkProof();
    proof.claimData.context = buildContext({ ...payment, amountBrlCents: 99_000_000n }, TEMPLATE);
    expect(() => fromReclaimProof(proof)).toThrow(/does not match its claim data/);
  });

  it('rejects a claim from any provider but http', async () => {
    const { proof } = await sdkProof({ provider: 'not-http' });
    expect(() => fromReclaimProof(proof)).toThrow(/only "http"/);
  });

  it('rejects a context that is not in the canonical form the witness signed', async () => {
    const { proof } = await sdkProof({ context: ` ${buildContext(payment, TEMPLATE)}` });
    expect(() => fromReclaimProof(proof)).toThrow(/not canonical/);
  });

  it('rejects a context without a provider hash, since the endpoint could not be checked', async () => {
    const ctx = JSON.parse(buildContext(payment, TEMPLATE));
    delete ctx.providerHash;
    const { proof } = await sdkProof({ context: canonicalStringify(ctx) });
    expect(() => fromReclaimProof(proof)).toThrow(/"providerHash"/);
  });

  it('rejects a proof whose extracted parameters lack a field the escrow reads', async () => {
    const ctx = JSON.parse(buildContext(payment, TEMPLATE));
    delete ctx.extractedParameters.bankTxId;
    const { proof } = await sdkProof({ context: canonicalStringify(ctx) });
    expect(() => fromReclaimProof(proof)).toThrow(/no "bankTxId"/);
  });

  /// A field the prover wrote outside extractedParameters is not a field the bank said.
  it('does not accept payment fields written outside extractedParameters', async () => {
    const ctx = JSON.parse(buildContext(payment, TEMPLATE));
    const amount = ctx.extractedParameters.amountBrlCents;
    delete ctx.extractedParameters.amountBrlCents;
    ctx.amountBrlCents = amount;
    const { proof } = await sdkProof({ context: canonicalStringify(ctx) });
    expect(() => fromReclaimProof(proof)).toThrow(/no "amountBrlCents"/);
  });

  it('rejects a proof with no signatures rather than passing it on', async () => {
    const { proof } = await sdkProof();
    proof.signatures = [];
    expect(() => fromReclaimProof(proof)).toThrow(/no witness signatures/);
  });

  it('rejects malformed claim data', async () => {
    const { proof } = await sdkProof();
    (proof.claimData as { provider?: string }).provider = '';
    expect(() => fromReclaimProof(proof)).toThrow(/claimData.provider is missing/);
  });

  /// The SDK returns witness order, which is not signer order; on-chain that is
  /// SignaturesUnsorted, an error naming the symptom rather than the cause.
  it('sorts signatures into the order the verifier requires', async () => {
    const { proof } = await sdkProof();
    const sorted = await sortSignatures(fromReclaimProof(proof));
    const signers = await proofSigners(sorted);
    for (let i = 1; i < signers.length; i++) {
      expect(BigInt(signers[i])).toBeGreaterThan(BigInt(signers[i - 1]));
    }
  });

  it('recovers the witnesses, so an operator can check them against the on-chain set', async () => {
    const { proof, keys } = await sdkProof();
    const signers = await proofSigners(fromReclaimProof(proof));
    const expected = keys.map((k) => privateKeyToAccount(k).address).sort();
    expect([...signers].sort()).toEqual(expected);
  });

  it('round-trips a proof we built ourselves through the same converter', async () => {
    const built = await buildProof({
      params, payment,
      witnessKeys: [generatePrivateKey()], owner: privateKeyToAccount(generatePrivateKey()).address,
    });
    const asSdk: ReclaimSdkProof = {
      identifier: built.signedClaim.claim.identifier,
      claimData: {
        provider: built.claimInfo.provider,
        parameters: built.claimInfo.parameters,
        context: built.claimInfo.context,
        owner: built.signedClaim.claim.owner,
        timestampS: built.signedClaim.claim.timestampS,
        identifier: built.signedClaim.claim.identifier,
        epoch: built.signedClaim.claim.epoch,
      },
      signatures: built.signedClaim.signatures,
    };
    expect(fromReclaimProof(asSdk).claimInfo).toEqual(built.claimInfo);
    expect(() => fromReclaimProof(asSdk)).not.toThrow(ReclaimProofError);
  });
});

describe('claim serialisation', () => {
  it('matches Reclaim: identifier, owner, timestamp, epoch, newline separated', () => {
    const s = serialiseClaim({
      identifier: ('0x' + '11'.repeat(32)) as `0x${string}`,
      owner: '0x00000000000000000000000000000000000000AA',
      timestampS: 42, epoch: 7,
    });
    expect(s.split('\n')).toHaveLength(4);
    expect(s.endsWith('\n42\n7')).toBe(true);
    expect(s).toContain('0x00000000000000000000000000000000000000aa');
  });
});

describe('PIX receipts, receipt templates and decoding', () => {
  const salt = ('0x' + '5a'.repeat(32)) as `0x${string}`;
  const base = { orderId: ORDER, bankTxId: b32('E2E-0002'), salt, payerRef: b32('cpf'), amountBrlCents: 10_000n, paidAt: 1_700_000_000n };

  it('a PIX receipt carries the commitment to the key the bank shows, however the bank formats it, and rail 1', () => {
    const ctx = pixPaymentContext({ ...base, pixKey: '529.982.247-25' });
    expect(ctx).toMatchObject({ rail: Rail.PIX, payeeKeyHash: pixKeyCommitment('52998224725', salt), orderId: ORDER });
    expect(() => pixPaymentContext({ ...base, pixKey: 'not a key' })).toThrow(ReclaimProofError);
  });

  /// The off-ramp binds its proof to the SALE: the same builder, the sale id where the order id goes.
  it('binds a payout to the sale it settles, and a proof bound to one id reads as bound to that id alone', async () => {
    const saleId = ('0x' + '5a1e'.repeat(16)) as `0x${string}`;
    const proof = await buildProof({
      params: receiptTemplate('https://api.bank.example/', 'pix-sent'), payment: pixPaymentContext({ ...base, orderId: saleId, pixKey: 'vendedor@pix.example' }),
      witnessKeys: [generatePrivateKey()], owner: privateKeyToAccount(generatePrivateKey()).address,
    });
    expect(proofPayment(proof).orderId).toBe(saleId);
    expect(JSON.parse(proof.claimInfo.context).contextMessage).toBe(saleId);
  });

  it('decodes what it encodes, as verifyPayment reads it', async () => {
    const proof = await sortSignatures(await buildProof({
      params, payment, witnessKeys: [generatePrivateKey(), generatePrivateKey()], owner: privateKeyToAccount(generatePrivateKey()).address,
    }));
    expect(decodeProof(encodeProof(proof))).toEqual(proof);
    expect(() => decodeProof('0x1234')).toThrow();
  });

  it('gives each receipt page its own template, whose rail capture matches only its own rail', () => {
    const prefix = 'https://api.banco-lp.example/v1/';
    const hashes = new Set(RECEIPT_KINDS.map((k) => hashProviderParams(receiptTemplate(prefix, k))));
    expect(hashes.size).toBe(4);
    for (const k of RECEIPT_KINDS) {
      const t = receiptTemplate(prefix, k);
      expect(t.url.startsWith(prefix)).toBe(true);
      const rail = t.responseMatches.find((m) => m.value.includes('(?<rail>'))!.value;
      expect(new RegExp(rail).test(`"rail":"${receiptRail(k)}"`)).toBe(true);
      expect(new RegExp(rail).test(`"rail":"${receiptRail(k) === Rail.PIX ? Rail.BOLETO : Rail.PIX}"`)).toBe(false);
      expect(receiptRailMask(k)).toBe(1 << receiptRail(k));
    }
    expect(receiptTemplates(prefix)['boleto-paid']).toEqual(receiptTemplate(prefix, 'boleto-paid'));
    expect(receiptKind(Rail.PIX, 'received')).toBe('pix-received');
    expect(receiptKind(Rail.BOLETO, 'sent')).toBe('boleto-paid');
    expect(() => receiptKind(Rail.TED, 'received')).toThrow(/zkTLS proves PIX and boleto/);
  });

  /// The verifier's own prefix rule: a prefix without the host's trailing slash would match bank.com.evil.io.
  it('refuses a url prefix the verifier would refuse to allowlist', () => {
    for (const bad of ['http://api.bank.example/', 'https://api.bank.example', 'https://API.bank.example/', 'https://api.bank.example/a?b/']) {
      expect(() => receiptTemplate(bad, 'pix-received')).toThrow(/is not https:\/\/<lowercase host>/);
    }
  });
});

describe('boleto receipts', () => {
  const boleto = buildBankBoleto({
    bankCode: '001', amountCents: 1_500_000n, dueDate: '2030-01-10', freeField: '0000002790853000012345617',
  });
  const salt = newBoletoSalt();

  it('carry the paid barcode\'s commitment and rail 2 in the fields the verifier reads', async () => {
    const ctx = boletoPaymentContext({
      orderId: ORDER, bankTxId: b32('AUTH-1'), line: boleto.line, salt, payerRef: b32('cpf'),
      amountBrlCents: 1_500_000n, paidAt: 1_700_000_000n,
    });
    const proof = await buildProof({ params, payment: ctx, witnessKeys: [generatePrivateKey()], owner: ORDER.slice(0, 42) as `0x${string}` });
    expect(proofPayment(proof)).toMatchObject({
      orderId: ORDER, payeeKeyHash: boletoCommitment(boleto, salt), rail: Rail.BOLETO, amountBrlCents: 1_500_000n,
    });
    expect(JSON.parse(proof.claimInfo.context).extractedParameters.rail).toBe('2');
  });

  it('refuse a receipt whose amount is not the boleto\'s, or a line that is not a boleto', () => {
    const base = {
      orderId: ORDER, bankTxId: b32('AUTH-1'), salt, payerRef: b32('cpf'), paidAt: 1_700_000_000n,
    };
    expect(() => boletoPaymentContext({ ...base, line: boleto.line, amountBrlCents: 1_500_100n }))
      .toThrow(ReclaimProofError);
    expect(() => boletoPaymentContext({ ...base, line: '1234', amountBrlCents: 1_500_000n })).toThrow(/44-digit/);
  });
});
