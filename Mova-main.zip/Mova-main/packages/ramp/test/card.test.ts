import { describe, it, expect } from 'vitest';
import { encodeAbiParameters, keccak256, recoverTypedDataAddress, type Hex } from 'viem';
import { generatePrivateKey } from 'viem/accounts';
import {
  Attestor, CARD_MERCHANT_COMMITMENT_DOMAIN, EIP712_DOMAIN, InvalidCardMerchant, MAX_CARD_FEE_BPS, PAYMENT_TYPES, Rail, RefusedToAttest,
  cardCheckoutTotal, cardFee, cardMerchantCommitment, cardTransactionId, newPixSalt, railMask, railsFromMask,
  type ObservedCardCapture, type OrderTerms,
} from '../src/index.js';

/**
 * The card rail, attestor side. The escrow takes CARD only on an institutional LP's card-only
 * offer (contracts/test/CardRail.t.sol); what only the attestor can check is that the charge it
 * signs for was captured, for the merchant account and card fee the offer commits to, for the
 * order's amount plus exactly that fee - and that what it signs is the order's amount.
 */

const VERIFIER = '0x00000000000000000000000000000000000000aa' as Hex;
const ORDER = `0x${'11'.repeat(32)}` as Hex;
const merchant = { acquirerId: '01027058000191', merchantId: 'MOVA-PARTNER-0001', feeBps: 350 };
const salt = newPixSalt();

const terms: OrderTerms = {
  orderId: ORDER,
  payeeKeyHash: cardMerchantCommitment(merchant, salt),
  brlCents: 150_000n,
  lockedAt: 1_700_000_000n,
  acceptedRails: [Rail.CARD],
};

/** R$ 1.500,00 at 3,5%: R$ 52,50 of fee, R$ 1.552,50 charged. */
const FEE = 5_250n;

const capture: ObservedCardCapture = {
  ...merchant,
  transactionId: 'TID-000123456',
  salt,
  payerRef: `0x${'22'.repeat(32)}` as Hex,
  status: 'CAPTURED',
  capturedAmountBrlCents: 150_000n + FEE,
  capturedAt: 1_700_000_300n,
};

/** The commitment as v1 wrote it, before the fee was part of it. */
const v1Commitment = (m: { acquirerId: string; merchantId: string }, s: Hex): Hex => keccak256(encodeAbiParameters(
  [{ type: 'string' }, { type: 'string' }, { type: 'string' }, { type: 'bytes32' }],
  ['PrivacyPoolsBRL/card-merchant/v1', m.acquirerId, m.merchantId, s],
));

describe('card attestations', () => {
  const attestor = new Attestor(generatePrivateKey(), 1, VERIFIER);

  it('signs a captured charge of the order plus its committed fee, attesting the order\'s amount', async () => {
    const { payment, signature } = await attestor.attestCard(terms, capture);
    expect(payment.rail).toBe(Rail.CARD);
    expect(payment.payeeKeyHash).toBe(terms.payeeKeyHash);
    expect(payment.bankTxId).toBe(cardTransactionId(merchant.acquirerId, capture.transactionId));
    expect(payment.paidAt).toBe(capture.capturedAt);
    // Net of the fee the payer chose by paying with a card (IAttestorVerifier, guarantee 3): the escrow sees the order.
    expect(payment.amountBrlCents).toBe(terms.brlCents);
    const signer = await recoverTypedDataAddress({
      domain: EIP712_DOMAIN(1, VERIFIER), types: PAYMENT_TYPES, primaryType: 'Payment',
      message: { orderId: ORDER, ...payment }, signature,
    });
    expect(signer).toBe(attestor.address);
  });

  it('signs a fee-free card offer\'s charge of exactly the order', async () => {
    const free = { ...merchant, feeBps: 0 };
    const { payment } = await attestor.attestCard(
      { ...terms, payeeKeyHash: cardMerchantCommitment(free, salt) },
      { ...capture, feeBps: 0, capturedAmountBrlCents: terms.brlCents },
    );
    expect(payment.amountBrlCents).toBe(terms.brlCents);
  });

  it('refuses anything but a captured charge', async () => {
    for (const status of ['AUTHORIZED', 'VOIDED', 'REFUNDED', 'CHARGED_BACK'] as const) {
      await expect(attestor.attestCard(terms, { ...capture, status })).rejects.toThrow(/only a captured charge/);
    }
  });

  it('refuses a charge captured for another merchant account, at another acquirer, or opened with another salt', async () => {
    await expect(attestor.attestCard(terms, { ...capture, merchantId: 'SOMEONE-ELSE' })).rejects.toThrow(/different merchant account/);
    await expect(attestor.attestCard(terms, { ...capture, acquirerId: '99999999000191' })).rejects.toThrow(/different merchant account/);
    await expect(attestor.attestCard(terms, { ...capture, salt: newPixSalt() })).rejects.toThrow(/different merchant account/);
  });

  it('attack: a fee other than the committed one opens nothing, even with a total that matches it', async () => {
    // The LP (or its node, or anything in between) states 4,5% after posting at 3,5%, and charges to match.
    const higher = { ...capture, feeBps: 450, capturedAmountBrlCents: cardCheckoutTotal(terms.brlCents, 450) };
    await expect(attestor.attestCard(terms, higher)).rejects.toThrow(/at a different card fee/);
    // Stating a lower fee - to have the taker's smaller charge accepted - opens nothing either.
    const lower = { ...capture, feeBps: 250, capturedAmountBrlCents: cardCheckoutTotal(terms.brlCents, 250) };
    await expect(attestor.attestCard(terms, lower)).rejects.toThrow(/at a different card fee/);
    await expect(attestor.attestCard(terms, { ...capture, feeBps: MAX_CARD_FEE_BPS + 1 })).rejects.toThrow(/whole number of basis points/);
  });

  it('attack: the order alone is refused - the disclosed fee is part of the charge', async () => {
    await expect(attestor.attestCard(terms, { ...capture, capturedAmountBrlCents: terms.brlCents })).rejects.toThrow(/exactly 155250/);
  });

  it('attack: any other total is refused, a centavo over or under, or with installment interest', async () => {
    for (const total of [terms.brlCents + FEE + 1n, terms.brlCents + FEE - 1n, 149_999n, (terms.brlCents + FEE) * 104n / 100n]) {
      await expect(attestor.attestCard(terms, { ...capture, capturedAmountBrlCents: total }), String(total)).rejects.toThrow(/a card charge is for exactly/);
    }
  });

  it('attack: a v1 commitment - no fee in it - does not open, whatever fee is stated', async () => {
    const old = { ...terms, payeeKeyHash: v1Commitment(merchant, salt) };
    for (const feeBps of [0, 350]) {
      await expect(attestor.attestCard(old, { ...capture, feeBps, capturedAmountBrlCents: cardCheckoutTotal(old.brlCents, feeBps) }))
        .rejects.toThrow(/different merchant account/);
    }
  });

  it('refuses a counterparty that does not accept cards, and a capture from before the order', async () => {
    await expect(attestor.attestCard({ ...terms, acceptedRails: [Rail.PIX] }, capture)).rejects.toThrow(/does not accept CARD/);
    await expect(attestor.attestCard({ ...terms, acceptedRails: undefined }, capture)).rejects.toThrow(/does not accept CARD/);
    await expect(attestor.attestCard(terms, { ...capture, capturedAt: terms.lockedAt - 1n })).rejects.toThrow(/predates/);
  });

  it('will not sign a card payment someone describes instead of the charge itself', async () => {
    const described = {
      bankTxId: cardTransactionId(merchant.acquirerId, 'TID-1'), payeeKeyHash: terms.payeeKeyHash,
      payerRef: capture.payerRef, amountBrlCents: terms.brlCents, paidAt: capture.capturedAt, rail: Rail.CARD,
    };
    await expect(attestor.attest(terms, described)).rejects.toThrow(RefusedToAttest);
    await expect(attestor.attest(terms, described)).rejects.toThrow(/attestCard/);
  });
});

describe('card fees', () => {
  it('round up, to the centavo, in one place', () => {
    expect(cardFee(10_000n, 350)).toBe(350n);
    expect(cardFee(150_000n, 350)).toBe(5_250n);
    expect(cardFee(10_001n, 250)).toBe(251n); // 250,025 centavos
    expect(cardFee(1n, 1)).toBe(1n);
    expect(cardFee(0n, 350)).toBe(0n);
    expect(cardFee(99_999n, 0)).toBe(0n);
    expect(cardCheckoutTotal(10_000n, 350)).toBe(10_350n);
  });

  it('are whole basis points from 0 to 1000', () => {
    for (const feeBps of [-1, 1_001, 3.5, Number.NaN]) {
      expect(() => cardFee(10_000n, feeBps), String(feeBps)).toThrow(InvalidCardMerchant);
      expect(() => cardMerchantCommitment({ ...merchant, feeBps }, salt), String(feeBps)).toThrow(InvalidCardMerchant);
    }
    expect(cardFee(10_000n, MAX_CARD_FEE_BPS)).toBe(1_000n);
  });
});

describe('card commitments and ids', () => {
  it('commit to the merchant account at its acquirer and its card fee, salted', () => {
    const c = cardMerchantCommitment(merchant, salt);
    expect(cardMerchantCommitment(merchant, newPixSalt())).not.toBe(c);
    expect(cardMerchantCommitment({ ...merchant, acquirerId: '99999999000191' }, salt)).not.toBe(c);
    expect(cardMerchantCommitment({ ...merchant, feeBps: 351 }, salt)).not.toBe(c);
    // Surrounding whitespace is formatting, not a different account.
    expect(cardMerchantCommitment({ ...merchant, acquirerId: ` ${merchant.acquirerId}`, merchantId: `${merchant.merchantId} ` }, salt)).toBe(c);
  });

  it('are v2, and no v1 commitment equals a v2 one at any fee', () => {
    expect(CARD_MERCHANT_COMMITMENT_DOMAIN).toBe('PrivacyPoolsBRL/card-merchant/v2');
    const old = v1Commitment(merchant, salt);
    for (let feeBps = 0; feeBps <= MAX_CARD_FEE_BPS; feeBps++) {
      expect(cardMerchantCommitment({ ...merchant, feeBps }, salt)).not.toBe(old);
    }
  });

  it('refuse a trivial salt and malformed identifiers', () => {
    expect(() => cardMerchantCommitment(merchant, `0x${'00'.repeat(32)}`)).toThrow(InvalidCardMerchant);
    expect(() => cardMerchantCommitment(merchant, '0x1234')).toThrow(InvalidCardMerchant);
    for (const merchantId of ['', 'has space', 'x'.repeat(65), '"quoted"']) {
      expect(() => cardMerchantCommitment({ ...merchant, merchantId }, salt), merchantId).toThrow(InvalidCardMerchant);
    }
  });

  it('scope a transaction id by acquirer, so two acquirers reusing a TID are two payments', () => {
    expect(cardTransactionId('01027058000191', 'TID-1')).not.toBe(cardTransactionId('99999999000191', 'TID-1'));
  });

  it('put CARD in the rail mask the escrow reads, at the enum value it declares', () => {
    expect(Rail.CARD).toBe(4);
    expect(railMask(Rail.CARD)).toBe(16);
    expect(railsFromMask(railMask(Rail.PIX, Rail.CARD))).toEqual([Rail.PIX, Rail.CARD]);
  });
});
