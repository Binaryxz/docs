import { describe, expect, it, afterEach } from 'vitest';
import { HttpRequestError } from 'viem';
import { MatcherService } from '../src/matcher-service.js';
import { OrderBookIndexer, railsFromMask } from '../src/indexer.js';
import { Rail } from '../src/attestor.js';

/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * These ran only under `matcher-live.ts`, which needs a mainnet fork - so CI exercised
 * neither the indexer nor the service. A fake chain covers the logic that does not need a
 * real node: which offers reach the book, what the service does when a sync fails, and what
 * it refuses to answer.
 */

const ESCROW = '0x00000000000000000000000000000000000000e5' as const;
const REGISTRY = '0x00000000000000000000000000000000000000e6' as const;
const NATIVE = '0x0000000000000000000000000000000000000000';
const ETH = 10n ** 18n;

interface FakeOffer {
  id: `0x${string}`;
  lp: string;
  asset?: string;
  available: bigint;
  price: bigint;
  min?: bigint;
  max?: bigint;
  railMask?: number;
  active?: boolean;
}

/** A chain that answers the three reads the indexer makes. */
function chain(offers: FakeOffer[], opts: {
  failLogs?: boolean; decimals?: number; tier?: number;
  /** Entrypoint assetConfig per asset (lowercase, as the Entrypoint names it): [pool, minimum]. */
  pools?: Record<string, [string, bigint]>;
  blacklisted?: string[];
} = {}) {
  let logCalls = 0;
  return {
    logCalls: () => logCalls,
    client: {
      getBlockNumber: async () => 100n,
      getLogs: async () => {
        logCalls++;
        if (opts.failLogs) throw new Error('RPC exploded');
        return offers.map((o) => ({ args: { offerId: o.id } }));
      },
      readContract: async ({ functionName, args }: { functionName: string; args: readonly unknown[] }) => {
        if (functionName === 'offers') {
          const o = offers.find((x) => x.id === args[0])!;
          return [
            o.lp, o.asset ?? NATIVE, o.available, 0n, o.price, `0x${'00'.repeat(32)}`,
            o.min ?? ETH / 100n, o.max ?? 5n * ETH, '0xv', o.railMask ?? (1 << Rail.PIX),
            o.active ?? true,
          ];
        }
        if (functionName === 'assets') return ['0xoracle', opts.decimals ?? 18, true];
        if (functionName === 'lps') return [opts.tier ?? 3, 0n, 0, 0, 0n];
        if (functionName === 'assetConfig') {
          const [pool, min] = opts.pools?.[String(args[0]).toLowerCase()] ?? [NATIVE, 0n];
          return [pool, min, 0n, 1000n];
        }
        if (functionName === 'isBlackListed') return (opts.blacklisted ?? []).includes(String(args[0]).toLowerCase());
        throw new Error(`unexpected read: ${functionName}`);
      },
    } as never,
  };
}

const offer = (id: string, price: bigint, over: Partial<FakeOffer> = {}): FakeOffer => ({
  id: `0x${id.padStart(64, '0')}` as `0x${string}`,
  lp: `0x${id.padStart(40, '0')}`,
  available: 10n * ETH,
  price,
  ...over,
});

let svc: MatcherService | undefined;
afterEach(async () => {
  await svc?.close();
  svc = undefined;
});

describe('rail mask decoding', () => {
  it('unpacks the escrow bitfield', () => {
    expect(railsFromMask(1 << Rail.PIX)).toEqual([Rail.PIX]);
    expect(railsFromMask((1 << Rail.PIX) | (1 << Rail.BOLETO))).toEqual([Rail.PIX, Rail.BOLETO]);
  });

  /// Bit 0 is UNSPECIFIED and must never appear as an acceptable rail.
  it('never reports UNSPECIFIED', () => {
    expect(railsFromMask(0xffff)).not.toContain(Rail.UNSPECIFIED);
  });

  it('an empty mask accepts nothing', () => {
    expect(railsFromMask(0)).toEqual([]);
  });
});

describe('the book follows the chain', () => {
  it('reads offer state from storage rather than from the event', async () => {
    const c = chain([offer('a1', 1_500_000n, { available: 3n * ETH })]);
    const ix = new OrderBookIndexer({
      client: c.client, escrow: ESCROW, registry: REGISTRY, fromBlock: 0n,
    });
    await ix.sync();
    const book = await ix.book();
    expect(book).toHaveLength(1);
    expect(book[0].availableWei).toBe(3n * ETH);
    expect(book[0].rails).toEqual([Rail.PIX]);
  });

  /// Liquidity also moves on paths that emit no event - an order expiring, a dispute
  /// resolving - so a closed or emptied offer must drop out on the next read.
  it('drops closed and emptied offers', async () => {
    const c = chain([
      offer('a1', 1_500_000n, { active: false }),
      offer('a2', 1_500_000n, { available: 0n }),
      offer('a3', 1_500_000n),
    ]);
    const ix = new OrderBookIndexer({
      client: c.client, escrow: ESCROW, registry: REGISTRY, fromBlock: 0n,
    });
    await ix.sync();
    expect(await ix.book()).toHaveLength(1);
  });

  /**
   * `LPRegistry.Tier` is NONE, RETAIL, AFFILIATED, INSTITUTIONAL, SUSPENDED. The indexer
   * used to treat index 2 as institutional, which is AFFILIATED - so "licensed counterparties
   * only" would have quoted affiliated LPs.
   */
  it('reports only the INSTITUTIONAL tier as institutional', async () => {
    const tierOf = async (tier: number) => {
      const c = chain([offer('a1', 1n)], { tier });
      const ix = new OrderBookIndexer({
        client: c.client, escrow: ESCROW, registry: REGISTRY, fromBlock: 0n,
      });
      await ix.sync();
      return (await ix.book())[0].tier;
    };
    expect(await tierOf(3)).toBe('INSTITUTIONAL');
    for (const other of [0, 1, 2, 4]) expect(await tierOf(other), String(other)).toBe('RETAIL');
  });

  it('carries the asset decimals so cost is computed in the asset\'s own units', async () => {
    const c = chain([offer('a1', 550n)], { decimals: 6 });
    const ix = new OrderBookIndexer({
      client: c.client, escrow: ESCROW, registry: REGISTRY, fromBlock: 0n,
    });
    await ix.sync();
    expect((await ix.book())[0].decimals).toBe(6);
  });

  it('advances its cursor so a resync is cheap', async () => {
    const c = chain([offer('a1', 1n)]);
    const ix = new OrderBookIndexer({
      client: c.client, escrow: ESCROW, registry: REGISTRY, fromBlock: 0n,
    });
    await ix.sync();
    expect(ix.lastIndexedBlock).toBe(100n);
  });
});

describe('the service', () => {
  async function up(offers: FakeOffer[], opts: Parameters<typeof chain>[1] = {}, extra: Partial<ConstructorParameters<typeof MatcherService>[0]> = {}) {
    const c = chain(offers, opts);
    svc = new MatcherService({
      client: c.client, escrow: ESCROW, registry: REGISTRY, fromBlock: 0n, pollMs: 1_000_000, ...extra,
    });
    const port = await svc.listen(0);
    // Typed loosely on purpose: these are HTTP responses, and `as never` makes every
    // property access a type error - which vitest never sees, because it transpiles without
    // typechecking. The suite passed while `tsc --noEmit` (and therefore CI) failed.
    const get = async (p: string) => {
      const r = await fetch(`http://127.0.0.1:${port}${p}`);
      return { status: r.status, body: (await r.json()) as any };
    };
    return { get, c, port };
  }

  describe('USDT', () => {
    const USDT = '0xdac17f958d2ee523a2206206994597c13d831ec7';
    const ENTRYPOINT = '0x6818809eefce719e480a7526d76bd3e561526b46' as const;
    const U = 10n ** 6n;
    const book = () => [
      offer('a1', 540n, { asset: USDT, available: 10n * U, min: U, max: 10_000n * U }),
      offer('a2', 545n, { asset: USDT, available: 1_000n * U, min: U, max: 10_000n * U }),
    ];

    it('refuses a shielded quote it cannot check against the pool minimum', async () => {
      const { get } = await up(book(), { decimals: 6 });
      const q = await get(`/quote?asset=${USDT}&amount=${30n * U}&delivery=shielded`);
      expect(q.status).toBe(400);
      expect(q.body.error).toMatch(/no Privacy Pools entrypoint/);
      expect((await get(`/quote?asset=${USDT}&amount=${30n * U}&delivery=teleport`)).status).toBe(400);
    });

    it('keeps every shielded leg at or above the pool minimum (SR2-27)', async () => {
      const { get } = await up(book(), { decimals: 6, pools: { [USDT]: ['0xe859c0bd25f260baee534fb52e307d3b64d24572', 25n * U] } }, { entrypoint: ENTRYPOINT });
      const direct = await get(`/quote?asset=${USDT}&amount=${30n * U}`);
      expect(direct.body.fills.map((f: any) => f.offerId)).toEqual([`0x${'a1'.padStart(64, '0')}`, `0x${'a2'.padStart(64, '0')}`]);
      const shielded = await get(`/quote?asset=${USDT}&amount=${30n * U}&delivery=shielded`);
      expect(shielded.body.minimumLeg).toBe(String(25n * U));
      expect(shielded.body.fills.map((f: any) => f.amount)).toEqual([String(30n * U)]);
    });

    it('refuses shielded delivery of an asset the entrypoint has no pool for', async () => {
      const { get } = await up(book(), { decimals: 6, pools: {} }, { entrypoint: ENTRYPOINT });
      const q = await get(`/quote?asset=${USDT}&amount=${30n * U}&delivery=shielded`);
      expect(q.status).toBe(400);
      expect(q.body.error).toMatch(/no pool for this asset/);
    });

    it('leaves out offers from an LP the token issuer has blacklisted (SR2-24)', async () => {
      const lp = `0x${'a1'.padStart(40, '0')}`;
      const { get } = await up(book(), { decimals: 6, blacklisted: [lp] }, { blacklistTokens: [USDT as `0x${string}`] });
      const offers = await get('/offers');
      expect(offers.body.offers.map((o: any) => o.lp.toLowerCase())).not.toContain(lp);
      expect(offers.body.offers).toHaveLength(1);
    });
  });

  /// A browser wallet on another origin reads quotes only if the operator lists that origin (cors.ts).
  describe('CORS', () => {
    const WALLET = 'https://wallet.example';
    const call = async (port: number, path: string, origin?: string, method = 'GET') => {
      const r = await fetch(`http://127.0.0.1:${port}${path}`, {
        method,
        headers: { ...(origin ? { origin } : {}), ...(method === 'OPTIONS' ? { 'access-control-request-method': 'GET' } : {}) },
      });
      return { status: r.status, headers: r.headers, text: await r.text() };
    };

    it('sends no CORS headers and refuses every preflight by default', async () => {
      const { port } = await up([offer('a1', 1_500_000n)]);
      const r = await call(port, '/offers', WALLET);
      expect(r.status).toBe(200);
      expect(r.headers.get('access-control-allow-origin')).toBeNull();
      expect(r.headers.get('vary')).toBeNull();
      const p = await call(port, '/quote', WALLET, 'OPTIONS');
      expect(p.status).toBe(403);
      expect(p.headers.get('access-control-allow-origin')).toBeNull();
      expect(p.text).toBe('');
    });

    it('lets a listed origin read every answer, errors included, and answers its preflight for GET', async () => {
      const { port } = await up([offer('a1', 1_500_000n)], {}, { allowedOrigins: ['https://Wallet.example/'] });
      for (const [path, status] of [
        [`/quote?asset=${NATIVE}&amount=${ETH}`, 200], ['/offers', 200], ['/health', 200], [`/quote?asset=${NATIVE}`, 400], ['/nope', 404],
      ] as const) {
        const r = await call(port, path, WALLET);
        expect(r.status, path).toBe(status);
        expect(r.headers.get('access-control-allow-origin'), path).toBe(WALLET);
        expect(r.headers.get('vary'), path).toBe('Origin');
        expect(r.headers.get('access-control-allow-credentials'), path).toBeNull();
      }
      const p = await call(port, '/quote', WALLET, 'OPTIONS');
      expect(p.status).toBe(204);
      expect(p.headers.get('access-control-allow-origin')).toBe(WALLET);
      expect(p.headers.get('access-control-allow-methods')).toBe('GET');
      expect(p.headers.get('access-control-max-age')).toBe('600');
      expect(p.headers.get('vary')).toBe('Origin');
      expect(p.text).toBe('');
    });

    it('gives an unlisted origin, or none, nothing to read', async () => {
      const { port } = await up([offer('a1', 1_500_000n)], {}, { allowedOrigins: [WALLET] });
      for (const origin of ['https://evil.example', 'http://wallet.example', 'https://wallet.example.evil.example', undefined]) {
        // Still answered: CORS is the browser's rule about what a page may read, not access control.
        const r = await call(port, '/offers', origin);
        expect(r.status, origin).toBe(200);
        expect(r.headers.get('access-control-allow-origin'), origin).toBeNull();
        expect(r.headers.get('vary'), origin).toBe('Origin');
        const p = await call(port, '/offers', origin, 'OPTIONS');
        expect(p.status, origin).toBe(403);
        expect(p.headers.get('access-control-allow-origin'), origin).toBeNull();
      }
    });

    it('refuses a wildcard, or anything but an exact origin, when constructed', () => {
      for (const bad of ['*', 'null', 'https://wallet.example/app', 'ftp://wallet.example']) {
        expect(() => new MatcherService({
          client: chain([]).client, escrow: ESCROW, registry: REGISTRY, fromBlock: 0n, allowedOrigins: [bad],
        }), bad).toThrow(/CORS allowed origin 1/);
      }
    });
  });

  it('quotes the cheapest offer', async () => {
    const { get } = await up([offer('a1', 1_600_000n), offer('a2', 1_500_000n)]);
    const q = await get(`/quote?asset=${NATIVE}&amount=${ETH}`);
    expect(q.body.fills).toHaveLength(1);
    expect(q.body.totalBrlCents).toBe('1500000');
  });

  it('stamps the block and an expiry, because a quote is advice with a shelf life', async () => {
    const { get } = await up([offer('a1', 1_500_000n)]);
    const q = await get(`/quote?asset=${NATIVE}&amount=${ETH}`);
    expect(q.body.atBlock).toBe('100');
    expect(q.body.expiresAt).toBeGreaterThan(Math.floor(Date.now() / 1000));
  });

  it('rejects a missing or nonsensical amount rather than guessing', async () => {
    const { get } = await up([offer('a1', 1_500_000n)]);
    expect((await get(`/quote?asset=${NATIVE}`)).status).toBe(400);
    expect((await get(`/quote?asset=${NATIVE}&amount=0`)).status).toBe(400);
    expect((await get(`/quote?asset=${NATIVE}&amount=abc`)).status).toBe(400);
  });

  it('honours the rails a taker can actually pay with', async () => {
    const { get } = await up([
      offer('a1', 1_400_000n, { railMask: 1 << Rail.PIX }),
      offer('a2', 1_500_000n, { railMask: 1 << Rail.BOLETO }),
    ]);
    const q = await get(`/quote?asset=${NATIVE}&amount=${ETH}&rails=${Rail.BOLETO}`);
    expect(q.body.fills[0].priceBrlCentsPerUnit).toBe('1500000');
  });

  /**
   * A matcher quoting from a book it has stopped being able to refresh looks fine from
   * outside. It must not: /health reports the failure and answers 503.
   */
  it('reports a sync failure instead of looking healthy', async () => {
    const { get } = await up([offer('a1', 1n)], { failLogs: true });
    const h = await get('/health');
    expect(h.status).toBe(503);
    expect(h.body.ok).toBe(false);
    expect(h.body.syncError).toMatch(/RPC exploded/);
  });

  /**
   * `/health` is public and polled by Flux. A viem transport error names the RPC URL, and a
   * hosted RPC URL carries its API key in the path - so the reason is served redacted.
   */
  it('reports a sync failure without the RPC key in it', async () => {
    const rpc = 'https://eth-mainnet.g.alchemy.com/v2/AbCdEfGhIjKlMnOpQrStUvWx12';
    const c = chain([offer('a1', 1n)]);
    const failing = {
      ...(c.client as object),
      getLogs: async () => {
        throw new HttpRequestError({ url: rpc, status: 429, body: { method: 'eth_getLogs' } });
      },
    } as never;
    svc = new MatcherService({
      client: failing, escrow: ESCROW, registry: REGISTRY, fromBlock: 0n, pollMs: 1_000_000,
      span: 1n, redactValues: [rpc],
    });
    const port = await svc.listen(0);
    const r = await fetch(`http://127.0.0.1:${port}/health`);
    const text = await r.text();
    expect(r.status).toBe(503);
    expect(text).toContain('eth-mainnet.g.alchemy.com');
    expect(text).not.toContain('AbCdEfGhIjKlMnOpQrStUvWx12');
  });

  it('keeps serving the last good book when a refresh fails', async () => {
    const c = chain([offer('a1', 1_500_000n)]);
    let broken = false;
    const patched = {
      ...(c.client as object),
      getLogs: async () => {
        if (broken) throw new Error('later failure');
        return [{ args: { offerId: offer('a1', 1n).id } }];
      },
    } as never;
    svc = new MatcherService({
      client: patched, escrow: ESCROW, registry: REGISTRY, fromBlock: 0n, pollMs: 1_000_000,
    });
    const port = await svc.listen(0);
    broken = true;
    await svc.refresh();
    const r = await fetch(`http://127.0.0.1:${port}/offers`);
    // A stale book yields quotes the escrow rejects, which is recoverable. Going dark is an
    // outage. So the offers stay, and /health is where the failure surfaces.
    expect(((await r.json()) as { offers: unknown[] }).offers).toHaveLength(1);
  });

  it('lists the book', async () => {
    const { get } = await up([offer('a1', 1_500_000n), offer('a2', 1_600_000n)]);
    const o = await get('/offers');
    expect(o.body.offers).toHaveLength(2);
    expect(o.body.atBlock).toBe('100');
  });

  it('404s an unknown route with the ones that exist', async () => {
    const { get } = await up([offer('a1', 1n)]);
    const r = await get('/nope');
    expect(r.status).toBe(404);
    expect(r.body.routes).toContain('/quote');
  });
});
