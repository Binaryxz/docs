import { describe, it, expect } from 'vitest';
import { decodeAbiParameters, keccak256, recoverTypedDataAddress, toBytes, type Hex } from 'viem';
import { generatePrivateKey } from 'viem/accounts';
import {
  Attestor, EIP712_DOMAIN, PAYMENT_TYPES, Rail, RefusedToAttest, encodeQuorumProof,
  newPixSalt, pixKeyCommitment, type ObservedBoletoPayment, type ObservedPayment, type OrderTerms,
} from '../src/attestor.js';
import { boletoCommitment, buildBankBoleto, buildCollectionBoleto, newBoletoSalt } from '../src/boleto.js';

const VERIFIER = '0x00000000000000000000000000000000000000ae' as Hex;
const ORDER = `0x${'a1'.repeat(32)}` as Hex;
const b32 = (s: string) => keccak256(toBytes(s));

const attestor = new Attestor(generatePrivateKey(), 1, VERIFIER);

async function signer(order: Hex, p: ObservedPayment, signature: Hex) {
  return recoverTypedDataAddress({
    domain: EIP712_DOMAIN(1, VERIFIER), types: PAYMENT_TYPES, primaryType: 'Payment',
    message: { orderId: order, ...p, rail: p.rail }, signature,
  });
}

describe('PIX attestations', () => {
  const key = pixKeyCommitment('lp@liquidez.com.br', newPixSalt());
  const terms: OrderTerms = {
    orderId: ORDER, payeeKeyHash: key, brlCents: 150_000n, lockedAt: 1_700_000_000n, acceptedRails: [Rail.PIX],
  };
  const seen: ObservedPayment = {
    bankTxId: b32('E2E'), payeeKeyHash: key, payerRef: b32('cpf'), amountBrlCents: 150_000n,
    paidAt: 1_700_000_100n, rail: Rail.PIX,
  };

  it('signs what it saw, for the order it was asked about', async () => {
    expect(await signer(ORDER, seen, await attestor.attest(terms, seen))).toBe(attestor.address);
  });

  it('refuses another key, an underpayment, an earlier payment, or an unaccepted rail', async () => {
    await expect(attestor.attest(terms, { ...seen, payeeKeyHash: b32('other') })).rejects.toThrow(RefusedToAttest);
    await expect(attestor.attest(terms, { ...seen, amountBrlCents: 149_999n })).rejects.toThrow(/underpaid/);
    await expect(attestor.attest(terms, { ...seen, paidAt: 1n })).rejects.toThrow(/predates/);
    await expect(attestor.attest(terms, { ...seen, rail: Rail.TED })).rejects.toThrow(/does not accept/);
  });

  /**
   * A boleto signed through the PIX path would carry whatever payee commitment the requester
   * wrote in. The attestor's whole job for a boleto is to derive that commitment from the paid
   * document, so the shortcut is refused.
   */
  it('will not sign a boleto payment on a commitment it was handed', async () => {
    await expect(attestor.attest({ ...terms, acceptedRails: [Rail.BOLETO] }, { ...seen, rail: Rail.BOLETO }))
      .rejects.toThrow(/attestBoleto/);
  });
});

describe('boleto attestations', () => {
  const boleto = buildBankBoleto({
    bankCode: '341', amountCents: 150_000n, dueDate: '2030-01-10', freeField: '1090000123452345678901230',
  });
  const salt = newBoletoSalt();
  const commitment = boletoCommitment(boleto, salt);
  const terms: OrderTerms = {
    orderId: ORDER, payeeKeyHash: commitment, brlCents: 150_000n, lockedAt: 1_700_000_000n,
    acceptedRails: [Rail.BOLETO],
  };
  const seen: ObservedBoletoPayment = {
    bankTxId: b32('AUTH-0001'), line: boleto.line, salt, payerRef: b32('cpf'),
    amountBrlCents: 150_000n, paidAt: 1_700_000_100n,
  };

  it('derives the payee commitment from the paid line and signs a BOLETO payment', async () => {
    const { payment, signature } = await attestor.attestBoleto(terms, seen);
    expect(payment).toMatchObject({ payeeKeyHash: commitment, rail: Rail.BOLETO, amountBrlCents: 150_000n });
    expect(await signer(ORDER, payment, signature)).toBe(attestor.address);
  });

  it('accepts the bank showing the barcode instead of the line', async () => {
    const { payment } = await attestor.attestBoleto(terms, { ...seen, line: boleto.barcode });
    expect(payment.payeeKeyHash).toBe(commitment);
  });

  it('refuses a different boleto: another bill, or the right bill with another salt', async () => {
    const other = buildCollectionBoleto({
      segment: 3, valueIdentifier: 8, value: 150_000n, rest: `0056${'2030011000000000987654321'}`,
    });
    await expect(attestor.attestBoleto(terms, { ...seen, line: other.line })).rejects.toThrow(/not the one this order/);
    await expect(attestor.attestBoleto(terms, { ...seen, salt: newBoletoSalt() })).rejects.toThrow(/not the one this order/);
  });

  it('refuses a boleto whose own amount is not the order\'s', async () => {
    const dearer = buildBankBoleto({
      bankCode: '341', amountCents: 150_001n, dueDate: '2030-01-10', freeField: '1090000123452345678901230',
    });
    const t = { ...terms, payeeKeyHash: boletoCommitment(dearer, salt) };
    await expect(attestor.attestBoleto(t, { ...seen, line: dearer.line })).rejects.toThrow(/boleto is for 150001/);
  });

  it('refuses a settlement of any other amount - a late payment with charges included', async () => {
    await expect(attestor.attestBoleto(terms, { ...seen, amountBrlCents: 151_200n })).rejects.toThrow(/face value/);
  });

  it('refuses a mistyped statement line, an early payment, and a counterparty that takes no boletos', async () => {
    const mistyped = boleto.line.slice(0, 5) + ((Number(boleto.line[5]) + 1) % 10) + boleto.line.slice(6);
    await expect(attestor.attestBoleto(terms, { ...seen, line: mistyped })).rejects.toThrow(/not a valid boleto/);
    await expect(attestor.attestBoleto(terms, { ...seen, paidAt: 1n })).rejects.toThrow(/predates/);
    await expect(attestor.attestBoleto({ ...terms, acceptedRails: [Rail.PIX] }, seen)).rejects.toThrow(/does not accept/);
  });

  it('encodes into the quorum proof with rail 2', async () => {
    const { payment, signature } = await attestor.attestBoleto(terms, seen);
    const [, payee, , amount, , rail, sigs] = decodeAbiParameters(
      [{ type: 'bytes32' }, { type: 'bytes32' }, { type: 'bytes32' }, { type: 'uint256' }, { type: 'uint64' },
        { type: 'uint8' }, { type: 'bytes[]' }],
      encodeQuorumProof(payment, [{ signer: attestor.address, signature }]),
    );
    expect([payee, amount, rail, sigs.length]).toEqual([commitment, 150_000n, 2, 1]);
  });
});
