import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { CorsPolicy, normalizeOrigin } from '../src/cors.js';

/**
 * The CORS policy the matcher and the LP node's counterparty API share (cors.ts). The servers' own
 * tests cover what reaches the wire; these cover what the policy accepts as configuration and what
 * it answers.
 */

const WALLET = 'https://wallet.example';

describe('configured origins', () => {
  it('normalises each entry to the origin a browser sends', () => {
    expect(normalizeOrigin('https://Wallet.Example/')).toBe(WALLET);
    expect(normalizeOrigin(' http://localhost:5173 ')).toBe('http://localhost:5173');
    expect(normalizeOrigin('https://wallet.example:443')).toBe(WALLET);
    expect(normalizeOrigin('http://wallet.example:8443')).toBe('http://wallet.example:8443');
    expect(normalizeOrigin('http://[::1]:8080')).toBe('http://[::1]:8080');
    expect(new CorsPolicy({ allowedOrigins: ['HTTPS://WALLET.EXAMPLE/', 'http://localhost:5173'] }).origins)
      .toEqual([WALLET, 'http://localhost:5173']);
  });

  it('refuses the two values that mean anyone', () => {
    expect(() => new CorsPolicy({ allowedOrigins: ['*'] })).toThrow(/CORS allowed origin 1 is '\*': refused/);
    expect(() => new CorsPolicy({ allowedOrigins: [WALLET, 'null'] })).toThrow(/CORS allowed origin 2 is 'null': refused/);
    expect(() => new CorsPolicy({ allowedOrigins: ['NULL'] })).toThrow(/'null': refused/);
  });

  it('refuses anything but exactly an http(s) origin', () => {
    for (const bad of [
      'https://wallet.example/app', 'https://wallet.example//', 'https://wallet.example?x=1', 'https://wallet.example#top',
      'https://user:pw@wallet.example', 'https://wallet.example\\evil', 'https://', 'https://wal let.example',
    ]) {
      expect(() => new CorsPolicy({ allowedOrigins: [bad] }), bad).toThrow(/CORS allowed origin 1 must be an origin only/);
    }
    for (const bad of ['wallet.example', 'wallet.example:443', 'https://wallet.example:99999']) {
      expect(() => new CorsPolicy({ allowedOrigins: [bad] }), bad).toThrow(/CORS allowed origin 1 is not an origin/);
    }
    for (const bad of ['ftp://wallet.example', 'ws://wallet.example', 'file:///tmp/wallet.html', 'chrome-extension://abcdef']) {
      expect(() => new CorsPolicy({ allowedOrigins: [bad] }), bad).toThrow(/must be an http:\/\/ or https:\/\/ origin/);
    }
    expect(() => new CorsPolicy({ allowedOrigins: [' '] })).toThrow(/CORS allowed origin 1 is empty/);
  });

  it('says what is wrong without repeating the value', () => {
    let message = '';
    try {
      new CorsPolicy({ allowedOrigins: ['https://wallet.example/SecretPath?token=abc123'] });
    } catch (e) {
      message = (e as Error).message;
    }
    expect(message).toMatch(/must be an origin only/);
    expect(message.toLowerCase()).not.toContain('secretpath');
    expect(message).not.toContain('abc123');
  });

  it('refuses a malformed max age or header list', () => {
    expect(() => new CorsPolicy({ allowedOrigins: [WALLET], maxAgeSeconds: -1 })).toThrow(/maxAgeSeconds/);
    expect(() => new CorsPolicy({ allowedOrigins: [WALLET], maxAgeSeconds: 1.5 })).toThrow(/maxAgeSeconds/);
    expect(() => new CorsPolicy({ allowedOrigins: [WALLET], allowHeaders: ['*'] })).toThrow(/allowHeaders/);
    expect(() => new CorsPolicy({ allowedOrigins: [WALLET], allowHeaders: ['content-type\r\nx-evil: 1'] })).toThrow(/allowHeaders/);
  });
});

describe('the policy', () => {
  it('allows nothing and adds nothing by default', () => {
    for (const policy of [new CorsPolicy(), new CorsPolicy({ allowedOrigins: [] })]) {
      expect(policy.enabled).toBe(false);
      expect(policy.allows(WALLET)).toBe(false);
      expect(policy.responseHeaders(WALLET)).toEqual({});
      expect(policy.preflight(WALLET, ['GET'])).toEqual({ status: 403, headers: {} });
    }
  });

  it('allows exactly the listed origins', () => {
    const policy = new CorsPolicy({ allowedOrigins: [WALLET, 'http://localhost:5173'] });
    expect(policy.allows(WALLET)).toBe(true);
    expect(policy.allows('https://WALLET.example')).toBe(true);
    expect(policy.allows('http://localhost:5173')).toBe(true);
    for (const other of [
      'http://wallet.example', 'https://wallet.example:8443', 'https://evil.wallet.example', 'https://wallet.example.evil',
      'http://localhost:5174', 'null', '*', '', undefined,
    ]) {
      expect(policy.allows(other), String(other)).toBe(false);
    }
  });

  it('echoes an allowed origin on a response, and marks every response as varying by origin', () => {
    const policy = new CorsPolicy({ allowedOrigins: [WALLET] });
    expect(policy.responseHeaders(WALLET)).toEqual({ 'access-control-allow-origin': WALLET, vary: 'Origin' });
    expect(policy.responseHeaders('https://evil.example')).toEqual({ vary: 'Origin' });
    expect(policy.responseHeaders(undefined)).toEqual({ vary: 'Origin' });
  });

  it('answers an allowed preflight with the methods, headers and max age, and nothing about credentials', () => {
    const policy = new CorsPolicy({ allowedOrigins: [WALLET] });
    expect(policy.preflight(WALLET, ['POST'])).toEqual({
      status: 204,
      headers: {
        'access-control-allow-origin': WALLET,
        'access-control-allow-methods': 'POST',
        'access-control-allow-headers': 'content-type',
        'access-control-max-age': '600',
        vary: 'Origin',
      },
    });
    expect(policy.preflight('https://evil.example', ['POST'])).toEqual({ status: 403, headers: { vary: 'Origin' } });
    expect(policy.preflight(undefined, ['POST']).status).toBe(403);

    const custom = new CorsPolicy({ allowedOrigins: [WALLET], maxAgeSeconds: 60, allowHeaders: [] }).preflight(WALLET, ['GET', 'POST']);
    expect(custom.headers['access-control-allow-methods']).toBe('GET, POST');
    expect(custom.headers['access-control-max-age']).toBe('60');
    expect(custom.headers).not.toHaveProperty('access-control-allow-headers');
    expect(custom.headers).not.toHaveProperty('access-control-allow-credentials');
  });

  /// A browser wallet may build its own policy checks on it, so it must not pull in Node.
  it('is browser-safe', () => {
    const src = readFileSync(new URL('../src/cors.ts', import.meta.url), 'utf8');
    expect(src).not.toMatch(/from ['"]node:/);
    expect(src).not.toMatch(/require\(/);
  });
});
