import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { generatePrivateKey, privateKeyToAccount } from 'viem/accounts';
import { matcherConfigFromEnv } from '../src/bin/matcher.js';
import { arbitrationConfigFromEnv, MIN_OPERATOR_TOKEN_LENGTH } from '../src/bin/arbitration.js';
import { ConfigError } from '../src/bin/config.js';

/**
 * The service entrypoints' configuration. Importing them here also proves they do not start
 * on import - a bin that ran `main()` at module load would try to reach an RPC from the test.
 */

const RPC = 'https://eth-mainnet.g.alchemy.com/v2/AbCdEfGhIjKlMnOp0123456789';
const ESCROW = '0x00000000000000000000000000000000000000e5';
const REGISTRY = '0x00000000000000000000000000000000000000e6';
const TOKEN = 't'.repeat(MIN_OPERATOR_TOKEN_LENGTH);

const problems = (fn: () => unknown): string[] => {
  try {
    fn();
  } catch (e) {
    if (e instanceof ConfigError) return e.problems;
    throw e;
  }
  throw new Error('expected a ConfigError');
};

describe('the matcher entrypoint', () => {
  it('reads the real contracts from the environment', () => {
    const cfg = matcherConfigFromEnv({
      RPC_URL: RPC, ESCROW, REGISTRY, FROM_BLOCK: '19000000', PORT: '9000',
    });
    expect(cfg).toMatchObject({ rpcUrl: RPC, fromBlock: 19_000_000n, port: 9000, pollMs: 5000 });
    expect(cfg.escrow.toLowerCase()).toBe(ESCROW);
    expect(cfg.registry.toLowerCase()).toBe(REGISTRY);
  });

  it('reads the entrypoint and the blacklist tokens, refusing a malformed token unechoed', () => {
    const cfg = matcherConfigFromEnv({
      RPC_URL: RPC, ESCROW, REGISTRY, FROM_BLOCK: '1',
      PP_ENTRYPOINT: '0x6818809eefce719e480a7526d76bd3e561526b46',
      BLACKLIST_TOKENS: '0xdac17f958d2ee523a2206206994597c13d831ec7, ',
    });
    expect(cfg.entrypoint).toBe('0x6818809EefCe719E480a7526D76bD3e561526b46');
    expect(cfg.blacklistTokens).toEqual(['0xdAC17F958D2ee523a2206206994597C13D831ec7']);
    const p = problems(() => matcherConfigFromEnv({ RPC_URL: RPC, ESCROW, REGISTRY, FROM_BLOCK: '1', BLACKLIST_TOKENS: 'USDT_SECRET' }));
    expect(p).toEqual(['BLACKLIST_TOKENS entry 1 must be an address']);
  });

  it('reads the CORS origins, naming every bad entry at once without echoing it', () => {
    const base = { RPC_URL: RPC, ESCROW, REGISTRY, FROM_BLOCK: '1' };
    expect(matcherConfigFromEnv(base).allowedOrigins).toBeUndefined();
    expect(matcherConfigFromEnv({ ...base, ALLOWED_ORIGINS: 'https://Wallet.example/, http://localhost:5173,' }).allowedOrigins)
      .toEqual(['https://wallet.example', 'http://localhost:5173']);
    const p = problems(() => matcherConfigFromEnv({
      ...base, ALLOWED_ORIGINS: '*,https://wallet.example/app?k=SECRET1,https://ok.example,null,ftp://files.example',
    }));
    expect(p).toHaveLength(4);
    expect(p[0]).toMatch(/^ALLOWED_ORIGINS entry 1 is '\*': refused/);
    expect(p[1]).toMatch(/^ALLOWED_ORIGINS entry 2 must be an origin only/);
    expect(p[2]).toMatch(/^ALLOWED_ORIGINS entry 4 is 'null': refused/);
    expect(p[3]).toMatch(/^ALLOWED_ORIGINS entry 5 must be an http:\/\/ or https:\/\/ origin/);
    expect(p.join('\n')).not.toMatch(/secret1/i);
  });

  it('binds every interface unless HOST names one', () => {
    const base = { RPC_URL: RPC, ESCROW, REGISTRY, FROM_BLOCK: '1' };
    expect(matcherConfigFromEnv(base).host).toBeUndefined();
    expect(matcherConfigFromEnv({ ...base, HOST: ' 127.0.0.1 ' }).host).toBe('127.0.0.1');
    expect(matcherConfigFromEnv({ ...base, HOST: '' }).host).toBeUndefined();
  });

  it('refuses to start without its configuration, naming everything missing at once', () => {
    const p = problems(() => matcherConfigFromEnv({}));
    expect(p.join('\n')).toMatch(/RPC_URL/);
    expect(p.join('\n')).toMatch(/ESCROW/);
    expect(p.join('\n')).toMatch(/REGISTRY/);
    expect(p.join('\n')).toMatch(/FROM_BLOCK/);
  });

  it('refuses malformed values without echoing them', () => {
    const p = problems(() => matcherConfigFromEnv({
      RPC_URL: 'ftp://node.example/SECRETKEY123', ESCROW: '0xnothex', REGISTRY,
      FROM_BLOCK: 'REPLACE_WITH_ESCROW_DEPLOYMENT_BLOCK',
    }));
    expect(p).toHaveLength(3);
    expect(p.join('\n')).not.toContain('SECRETKEY123');
  });

  /**
   * The property that lets the matcher run on hardware nobody vetted. The demo it replaced
   * deployed contracts with a hard-coded key; this entrypoint must not even read one.
   */
  it('holds no key and can write nothing', () => {
    const src = ['../src/bin/matcher.ts', '../src/matcher-service.ts', '../src/indexer.ts']
      .map((p) => readFileSync(new URL(p, import.meta.url), 'utf8')).join('\n');
    for (const forbidden of [
      'privateKeyToAccount', 'mnemonicToAccount', 'createWalletClient', 'writeContract',
      'sendTransaction', 'signTypedData', '_KEY',
    ]) {
      expect(src, forbidden).not.toContain(forbidden);
    }
  });
});

describe('the arbitration entrypoint', () => {
  const KEY = generatePrivateKey();
  const base = {
    RPC_URL: RPC, ESCROW, ARBITRATOR_KEY: KEY, OPERATOR_TOKEN: TOKEN, CASE_STORE: '/data/cases.json',
  };

  it('reads escrows, key, token and store from the environment', () => {
    const cfg = arbitrationConfigFromEnv({ ...base, OFFRAMP_ESCROW: REGISTRY, CHAIN_ID: '1' });
    expect(cfg.escrows.map((e) => e.leg)).toEqual(['onramp', 'offramp']);
    expect(privateKeyToAccount(cfg.arbitratorKey).address).toBe(privateKeyToAccount(KEY).address);
    expect(cfg).toMatchObject({ port: 8082, chainId: 1, responseWindowSeconds: 72 * 3600 });
  });

  it('prefers a mounted key file, which does not show up in `docker inspect`', () => {
    const { ARBITRATOR_KEY: _omit, ...rest } = base;
    const cfg = arbitrationConfigFromEnv(
      { ...rest, ARBITRATOR_KEY_FILE: '/run/secrets/arbitrator_key' },
      (p) => (p === '/run/secrets/arbitrator_key' ? `${KEY}\n` : ''),
    );
    expect(cfg.arbitratorKey).toBe(KEY);
  });

  it.each([
    ['the key', 'ARBITRATOR_KEY', /ARBITRATOR_KEY_FILE or ARBITRATOR_KEY is required/],
    ['the operator token', 'OPERATOR_TOKEN', /OPERATOR_TOKEN is required/],
    ['a case store', 'CASE_STORE', /CASE_STORE is required/],
    ['an escrow', 'ESCROW', /ESCROW or OFFRAMP_ESCROW is required/],
    ['an RPC URL', 'RPC_URL', /RPC_URL is required/],
  ])('refuses to start without %s', (_what, name, message) => {
    const env: Record<string, string | undefined> = { ...base };
    delete env[name];
    expect(problems(() => arbitrationConfigFromEnv(env)).join('\n')).toMatch(message);
  });

  /// Ruling is the one route that produces a signature the escrow acts on.
  it('refuses a short operator token', () => {
    expect(problems(() => arbitrationConfigFromEnv({ ...base, OPERATOR_TOKEN: 'hunter2' })).join('\n'))
      .toMatch(new RegExp(`at least ${MIN_OPERATOR_TOKEN_LENGTH} characters`));
  });

  it('refuses both a key and a key file, rather than guessing which was meant', () => {
    expect(problems(() => arbitrationConfigFromEnv(
      { ...base, ARBITRATOR_KEY_FILE: '/run/secrets/k' }, () => KEY,
    )).join('\n')).toMatch(/not both/);
  });

  /**
   * A malformed key is still mostly a key. And an out-of-range one is worse: the curve
   * library's own error prints the key as a decimal number, which no hex redaction catches.
   */
  it('rejects an invalid key without repeating any of it', () => {
    const outOfRange = `0x${'ff'.repeat(32)}`;
    const truncated = KEY.slice(0, 40);
    for (const bad of [outOfRange, truncated]) {
      const text = problems(() => arbitrationConfigFromEnv({ ...base, ARBITRATOR_KEY: bad })).join('\n');
      expect(text).toMatch(/not a valid 0x-prefixed 32-byte secp256k1 private key/);
      expect(text).not.toContain(bad.slice(2, 20));
      expect(text).not.toContain(BigInt(outOfRange).toString().slice(0, 20));
    }
  });

  it('never puts the key or the token in a configuration error', () => {
    const text = problems(() => arbitrationConfigFromEnv({
      ...base, CASE_STORE: undefined, OPERATOR_TOKEN: 'short-but-secret', ESCROW: 'nope',
    })).join('\n');
    expect(text).not.toContain(KEY.slice(2));
    expect(text).not.toContain('short-but-secret');
  });
});
