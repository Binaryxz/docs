/* eslint-disable @typescript-eslint/no-explicit-any */
import { describe, expect, it, afterEach } from 'vitest';
import { HttpRequestError } from 'viem';
import { generatePrivateKey, privateKeyToAccount } from 'viem/accounts';
import { Arbitrator, evidenceDigest, signEvidence } from '../src/disputes.js';
import {
  ArbitrationDesk, MemoryCaseStore, type EscrowReader,
} from '../src/arbitration-desk.js';
import { ArbitrationService } from '../src/arbitration-service.js';

const ORDER = ('0x' + 'a1'.repeat(32)) as `0x${string}`;
const ORDER_B = ('0x' + 'b2'.repeat(32)) as `0x${string}`;
const NOT_DISPUTED = ('0x' + 'dd'.repeat(32)) as `0x${string}`;
const ESCROW = '0x00000000000000000000000000000000000000e5' as `0x${string}`;
const TAKER_KEY = generatePrivateKey();
const LP_KEY = generatePrivateKey();
const STRANGER_KEY = generatePrivateKey();
const TAKER = privateKeyToAccount(TAKER_KEY).address;
const LP = privateKeyToAccount(LP_KEY).address;
const TOKEN = 'operator-secret-token';

let svc: ArbitrationService | undefined;
afterEach(async () => { await svc?.close(); svc = undefined; });

/** The escrow: every order but NOT_DISPUTED is disputed between TAKER and LP. */
const reader: EscrowReader = {
  read: async ({ orderId }) => ({
    disputed: orderId !== NOT_DISPUTED,
    parties: { taker: TAKER, lp: LP },
    disputedAt: 1_700_000_000,
    expiresAt: 1_700_000_000 + 30 * 86_400,
  }),
};

async function up(opts: { token?: string; now?: { t: number } } = {}) {
  const now = opts.now ?? { t: 1_700_000_000 };
  const desk = new ArbitrationDesk(
    new MemoryCaseStore(), new Arbitrator(generatePrivateKey()),
    { chainId: 1, escrows: [{ address: ESCROW, leg: 'onramp' }], reader },
    () => now.t,
  );
  svc = new ArbitrationService({ desk, operatorToken: opts.token });
  const port = await svc.listen(0);
  const call = async (method: string, path: string, body?: unknown, token?: string) => {
    const r = await fetch(`http://127.0.0.1:${port}${path}`, {
      method,
      headers: {
        'content-type': 'application/json',
        ...(token ? { authorization: `Bearer ${token}` } : {}),
      },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    return { status: r.status, body: (await r.json()) as any };
  };
  return { call, desk, now, port };
}

const openBody = {
  orderId: ORDER, escrow: ESCROW, chainId: 1, leg: 'onramp',
  raisedBy: 'taker', reason: 'paid but the attestor is offline',
};

async function evidence(
  caseId: string, key: `0x${string}`, kind = 'pix-receipt', orderId: `0x${string}` = ORDER,
) {
  const ev = { digest: evidenceDigest(`${kind}-${key.slice(0, 8)}`), kind };
  const signature = await signEvidence(
    key, { caseId, orderId, escrow: ESCROW, chainId: 1 }, ev,
  );
  return { ...ev, signature };
}

describe('filing a case', () => {
  it('is open to a party without an operator credential', async () => {
    const { call } = await up();
    const r = await call('POST', '/cases', openBody);
    expect(r.status).toBe(201);
    expect(r.body.status).toBe('OPEN');
    expect(r.body.respondBy).toBeGreaterThan(r.body.raisedAt);
    expect(r.body.parties).toEqual({ taker: TAKER, lp: LP });
  });

  it('requires the order, escrow, side and reason', async () => {
    const { call } = await up();
    for (const k of ['orderId', 'escrow', 'raisedBy', 'reason']) {
      const r = await call('POST', '/cases', { ...openBody, [k]: undefined });
      expect(r.status, k).toBe(400);
    }
  });

  /// The request used to choose all three, which let a filer rig the outcome.
  it('refuses a request that tries to choose the parties, the window or the default', async () => {
    const { call } = await up();
    for (const extra of [
      { parties: { taker: TAKER, lp: privateKeyToAccount(STRANGER_KEY).address } },
      { responseWindowSeconds: 1 },
      { defaultRuling: 'RELEASE' },
    ]) {
      const r = await call('POST', '/cases', { ...openBody, ...extra });
      expect(r.status).toBe(400);
      expect(r.body.error).toMatch(/is not the filer's to set/);
    }
    expect((await call('GET', '/due')).body.cases).toHaveLength(0);
  });

  it('refuses an order the escrow does not report as DISPUTED', async () => {
    const { call } = await up();
    const r = await call('POST', '/cases', { ...openBody, orderId: NOT_DISPUTED });
    expect(r.status).toBe(400);
    expect(r.body.error).toMatch(/not DISPUTED/);
  });

  it('refuses a second case for the same order', async () => {
    const { call } = await up();
    expect((await call('POST', '/cases', openBody)).status).toBe(201);
    const again = await call('POST', '/cases', { ...openBody, raisedBy: 'lp' });
    expect(again.status).toBe(400);
    expect(again.body.error).toMatch(/already has a case/);
  });

  /// Intake reads the escrow over RPC; that failure must not publish the RPC key.
  it('does not return the RPC URL when the escrow read fails', async () => {
    const rpc = 'https://mainnet.infura.io/v3/0123456789abcdef0123456789abcdef';
    const desk = new ArbitrationDesk(
      new MemoryCaseStore(), new Arbitrator(generatePrivateKey()),
      {
        chainId: 1,
        escrows: [{ address: ESCROW, leg: 'onramp' }],
        reader: { read: async () => { throw new HttpRequestError({ url: rpc, details: 'fetch failed' }); } },
      },
    );
    svc = new ArbitrationService({ desk, operatorToken: TOKEN, redactValues: [rpc] });
    const port = await svc.listen(0);
    const r = await fetch(`http://127.0.0.1:${port}/cases`, {
      method: 'POST', body: JSON.stringify(openBody),
    });
    const text = await r.text();
    expect(r.status).toBe(500);
    expect(text).toContain('mainnet.infura.io');
    expect(text).not.toContain('0123456789abcdef0123456789abcdef');
  });

  it('answers malformed JSON with a 400, not a 500', async () => {
    const { port } = await up();
    const r = await fetch(`http://127.0.0.1:${port}/cases`, { method: 'POST', body: '{nope' });
    expect(r.status).toBe(400);
  });
});

describe('evidence', () => {
  it('accepts a party signature and attributes the side from it', async () => {
    const { call } = await up();
    const c = await call('POST', '/cases', openBody);
    const r = await call('POST', `/cases/${c.body.caseId}/evidence`,
      await evidence(c.body.caseId, LP_KEY));
    expect(r.status).toBe(200);
    expect(r.body.evidence[0].submittedBy).toBe('lp');
    expect(r.body.evidence[0].submitter).toBe(LP);
  });

  it('refuses someone who is not a party', async () => {
    const { call } = await up();
    const c = await call('POST', '/cases', openBody);
    const r = await call('POST', `/cases/${c.body.caseId}/evidence`,
      await evidence(c.body.caseId, STRANGER_KEY));
    expect(r.status).toBe(400);
    expect(r.body.error).toMatch(/not a party/);
  });

  it('requires a signature at all', async () => {
    const { call } = await up();
    const c = await call('POST', '/cases', openBody);
    const r = await call('POST', `/cases/${c.body.caseId}/evidence`,
      { digest: evidenceDigest('x'), kind: 'a' });
    expect(r.status).toBe(400);
  });
});

describe('reading is public', () => {
  it('serves a case to anyone', async () => {
    const { call } = await up();
    const c = await call('POST', '/cases', openBody);
    expect((await call('GET', `/cases/${c.body.caseId}`)).status).toBe(200);
  });

  it('finds a case by the escrow and order it is for, exactly, and serves what GET /cases/:id serves', async () => {
    const { call } = await up();
    const c = await call('POST', '/cases', openBody);
    const byOrder = await call('GET', `/cases?escrow=${ESCROW}&orderId=${ORDER}`);
    expect(byOrder.status).toBe(200);
    expect(byOrder.body).toEqual((await call('GET', `/cases/${c.body.caseId}`)).body);
    // Any address or hex casing names the same order.
    expect((await call('GET', `/cases?escrow=${ESCROW.toUpperCase().replace('0X', '0x')}&orderId=${ORDER.toUpperCase().replace('0X', '0x')}`)).body.caseId)
      .toBe(c.body.caseId);
  });

  it('by order, answers 404 for an order with no case, and never lists or matches partially', async () => {
    const { call } = await up();
    await call('POST', '/cases', openBody);
    expect(await call('GET', `/cases?escrow=${ESCROW}&orderId=${ORDER_B}`)).toMatchObject({ status: 404, body: { error: 'no such case' } });
    const other = '0x00000000000000000000000000000000000000e6';
    expect((await call('GET', `/cases?escrow=${other}&orderId=${ORDER}`)).status).toBe(404);
    for (const q of ['', `?escrow=${ESCROW}`, `?orderId=${ORDER}`]) {
      const r = await call('GET', `/cases${q}`);
      expect(r.status, q).toBe(400);
      expect(r.body.caseId).toBeUndefined();
      expect(r.body.cases).toBeUndefined();
    }
    for (const q of [`?escrow=${ESCROW}&orderId=${ORDER.slice(0, 20)}`, `?escrow=nope&orderId=${ORDER}`]) {
      expect((await call('GET', `/cases${q}`)).status, q).toBe(400);
    }
  });

  it('404s an unknown case rather than inventing one', async () => {
    const { call } = await up();
    expect((await call('GET', '/cases/nope')).status).toBe(404);
  });

  it('lists what is ripe for a human', async () => {
    const { call, now } = await up();
    const c = await call('POST', '/cases', openBody);
    expect((await call('GET', '/due')).body.cases).toHaveLength(0);
    now.t += 72 * 3600 + 1;
    expect((await call('GET', '/due')).body.cases[0].caseId).toBe(c.body.caseId);
  });
});

describe('ruling is operator-only', () => {
  /// The only route that produces a signature the escrow will act on.
  it('refuses without the token', async () => {
    const { call } = await up({ token: TOKEN });
    const c = await call('POST', '/cases', openBody);
    const ev = await evidence(c.body.caseId, TAKER_KEY);
    await call('POST', `/cases/${c.body.caseId}/evidence`, ev);

    const r = await call('POST', `/cases/${c.body.caseId}/rule`, {
      outcome: 'RELEASE', rationale: 'mine now', reliedOn: [ev.digest],
    });
    expect(r.status).toBe(401);
  });

  it('refuses a wrong token', async () => {
    const { call } = await up({ token: TOKEN });
    const c = await call('POST', '/cases', openBody);
    const r = await call('POST', `/cases/${c.body.caseId}/rule`,
      { outcome: 'RELEASE', rationale: 'x', reliedOn: [] }, 'wrong-token-same-len!');
    expect(r.status).toBe(401);
  });

  /// With no token configured the signing routes are off entirely, not open.
  it('is disabled when no token is configured', async () => {
    const { call } = await up();
    const c = await call('POST', '/cases', openBody);
    const r = await call('POST', `/cases/${c.body.caseId}/rule`,
      { outcome: 'RELEASE', rationale: 'x', reliedOn: [] }, TOKEN);
    expect(r.status).toBe(401);
    expect((await call('GET', '/health')).body.rulingEnabled).toBe(false);
  });

  it('rules with the token, and anyone can then verify the signer', async () => {
    const { call, desk } = await up({ token: TOKEN });
    const c = await call('POST', '/cases', openBody);
    const ev = await evidence(c.body.caseId, TAKER_KEY);
    await call('POST', `/cases/${c.body.caseId}/evidence`, ev);

    const ruled = await call('POST', `/cases/${c.body.caseId}/rule`, {
      outcome: 'RELEASE', rationale: 'receipt matches amount and payee', reliedOn: [ev.digest],
    }, TOKEN);
    expect(ruled.status).toBe(200);
    expect(ruled.body.status).toBe('RULED');

    const v = await call('GET', `/cases/${c.body.caseId}/verify`);
    expect(v.body.matchesDesk).toBe(true);
    expect(v.body.signer).toBe(desk.arbitratorAddress);
  });

  it('refuses to cite evidence the case does not hold', async () => {
    const { call } = await up({ token: TOKEN });
    const c = await call('POST', '/cases', openBody);
    await call('POST', `/cases/${c.body.caseId}/evidence`, await evidence(c.body.caseId, TAKER_KEY));
    const r = await call('POST', `/cases/${c.body.caseId}/rule`, {
      outcome: 'RELEASE', rationale: 'trust me', reliedOn: [evidenceDigest('never submitted')],
    }, TOKEN);
    expect(r.status).toBe(400);
    expect(r.body.error).toMatch(/not in the case/);
  });

  it('hands anyone exactly what resolveDispute takes, and when it can execute', async () => {
    const { call } = await up({ token: TOKEN });
    const c = await call('POST', '/cases', openBody);
    const ev = await evidence(c.body.caseId, TAKER_KEY);
    await call('POST', `/cases/${c.body.caseId}/evidence`, ev);
    await call('POST', `/cases/${c.body.caseId}/rule`,
      { outcome: 'RELEASE', rationale: 'ok', reliedOn: [ev.digest] }, TOKEN);

    const sub = await call('GET', `/cases/${c.body.caseId}/submission`, undefined, TOKEN);
    expect(sub.body.fn).toBe('resolveDispute');
    expect(sub.body.args[0]).toBe(ORDER);
    expect(sub.body.args[2]).toMatch(/^0x[0-9a-f]{130}$/);
    expect(sub.body.executableAfter).toBe(86_400);
    expect(sub.body.expiresAt).toBe(1_700_000_000 + 30 * 86_400);
  });

  it('defaults a case nobody answered, and refuses to default a contested one', async () => {
    const { call, now } = await up({ token: TOKEN });
    const quiet = await call('POST', '/cases', openBody);
    await call('POST', `/cases/${quiet.body.caseId}/evidence`, await evidence(quiet.body.caseId, TAKER_KEY));

    // A different order: one order can only ever have one case.
    const contested = await call('POST', '/cases', { ...openBody, orderId: ORDER_B });
    const cid = contested.body.caseId;
    await call('POST', `/cases/${cid}/evidence`, await evidence(cid, TAKER_KEY, 'pix-receipt', ORDER_B));
    await call('POST', `/cases/${cid}/evidence`, await evidence(cid, LP_KEY, 'pix-receipt', ORDER_B));

    now.t += 72 * 3600 + 1;

    const d1 = await call('POST', `/cases/${quiet.body.caseId}/rule`, { byDefault: true }, TOKEN);
    expect(d1.body.ruling.byDefault).toBe(true);
    expect(d1.body.ruling.outcome).toBe('REFUND');

    const d2 = await call('POST', `/cases/${contested.body.caseId}/rule`, { byDefault: true }, TOKEN);
    expect(d2.status).toBe(400);
    expect(d2.body.error).toMatch(/on the merits/);
  });
});
