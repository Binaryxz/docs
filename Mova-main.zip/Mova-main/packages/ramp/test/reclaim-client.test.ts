import { describe, it, expect, afterEach } from 'vitest';
import { createServer, type Server } from 'node:http';
import { generatePrivateKey, privateKeyToAccount } from 'viem/accounts';
import { keccak256, toBytes } from 'viem';
import {
  ReclaimClient, ReclaimSessionError, assertWitnessesRegistered, assertEndpointAllowed,
  assertEndpointRail, prepareSettlement,
} from '../src/reclaim-client.js';
import {
  buildContext, canonicalStringify, claimIdentifier, hashProviderParams, signAsWitness,
  proofSigners, ReclaimProofError, type HttpProviderParams, type ReclaimSdkProof,
} from '../src/reclaim.js';
import { Rail } from '../src/attestor.js';

const ORDER = ('0x' + 'a1'.repeat(32)) as `0x${string}`;
const b32 = (s: string) => keccak256(toBytes(s));

const payment = {
  orderId: ORDER, bankTxId: b32('E1'), payeeKeyHash: b32('lp@pix'), payerRef: b32('cpf'),
  amountBrlCents: 1_500_000n, paidAt: 1_700_000_000n, rail: Rail.PIX,
};

const params: HttpProviderParams = {
  url: 'https://api.bank.example/pix/v2/{{e2eId}}',
  method: 'GET',
  responseMatches: [{ type: 'regex', value: '"endToEndId":"(?<bankTxId>0x[0-9a-f]{64})"' }],
};
const TEMPLATE = hashProviderParams(params);

/** A proof in the exact shape Reclaim emits, signed by the given witnesses. */
async function sdkProof(keys: `0x${string}`[], url = params.url): Promise<ReclaimSdkProof> {
  const claimData = {
    provider: 'http',
    parameters: canonicalStringify({ ...params, url }),
    owner: privateKeyToAccount(keys[0]).address.toLowerCase(),
    timestampS: 1_700_000_000,
    context: buildContext(payment, TEMPLATE),
    identifier: '',
    epoch: 1,
  };
  claimData.identifier = claimIdentifier(claimData);
  const claim = {
    identifier: claimData.identifier as `0x${string}`,
    owner: claimData.owner as `0x${string}`,
    timestampS: claimData.timestampS,
    epoch: claimData.epoch,
  };
  const signatures = await Promise.all(keys.map((k) => signAsWitness(k, claim)));
  return { identifier: claimData.identifier, claimData, signatures };
}

let server: Server | undefined;
afterEach(async () => {
  if (server) await new Promise<void>((r) => server!.close(() => r()));
  server = undefined;
});

/** A stand-in for Reclaim's backend, spoken to over real HTTP. */
async function serve(routes: Record<string, (req: { url: string; method: string }) => [number, unknown]>) {
  server = createServer((rq, rs) => {
    const path = new URL(rq.url ?? '/', 'http://x').pathname;
    const key = Object.keys(routes).find((k) => path.startsWith(k));
    const [code, body] = key
      ? routes[key]({ url: path, method: rq.method ?? 'GET' })
      : [404, { error: 'no route' }];
    rs.writeHead(code, { 'content-type': 'application/json' });
    rs.end(JSON.stringify(body));
  });
  await new Promise<void>((r) => server!.listen(0, r));
  const addr = server.address();
  return `http://127.0.0.1:${typeof addr === 'object' && addr ? addr.port : 0}`;
}

describe('starting a session', () => {
  it('binds the order, and only the order, into the context it asks Reclaim to attest', async () => {
    let seen = '';
    const base = await serve({
      '/api/sessions': () => [200, { sessionId: 's1', url: 'https://reclaim.example/s1' }],
    });
    // Capture the body by wrapping fetch rather than trusting the server echo.
    const client = new ReclaimClient({
      appId: 'app', providerId: 'prov', baseUrl: base,
      fetchImpl: async (input, init) => {
        seen = String(init?.body ?? '');
        return fetch(input as string, init);
      },
    });
    const s = await client.requestProof(ORDER);
    expect(s.sessionId).toBe('s1');
    expect(seen).toContain(ORDER.slice(2));
    expect(JSON.parse(seen).applicationId).toBe('app');
    // The payment is the bank's to state, through the witness - never the payer's.
    expect(JSON.parse(JSON.parse(seen).context)).toEqual({
      contextAddress: '0x0000000000000000000000000000000000000000', contextMessage: ORDER,
    });
  });

  it('reports a rejected credential clearly instead of a bare status code', async () => {
    const base = await serve({ '/api/sessions': () => [401, { error: 'bad app' }] });
    const client = new ReclaimClient({ appId: 'x', providerId: 'y', baseUrl: base });
    await expect(client.requestProof(ORDER)).rejects.toThrow(/appId and providerId/);
  });

  it('rejects a response with no session link', async () => {
    const base = await serve({ '/api/sessions': () => [200, { sessionId: 's1' }] });
    const client = new ReclaimClient({ appId: 'x', providerId: 'y', baseUrl: base });
    await expect(client.requestProof(ORDER)).rejects.toThrow(/no session id or link/);
  });
});

describe('awaiting a proof', () => {
  it('returns the proof in on-chain form, with signatures sorted', async () => {
    const keys = [generatePrivateKey(), generatePrivateKey(), generatePrivateKey()];
    const proof = await sdkProof(keys);
    const base = await serve({ '/api/sessions/': () => [200, { status: 'done', proof }] });
    const client = new ReclaimClient({ appId: 'x', providerId: 'y', baseUrl: base });

    const got = await client.awaitProof('s1');
    const signers = await proofSigners(got);
    for (let i = 1; i < signers.length; i++) {
      expect(BigInt(signers[i])).toBeGreaterThan(BigInt(signers[i - 1]));
    }
  });

  it('polls until the user finishes', async () => {
    const keys = [generatePrivateKey()];
    const proof = await sdkProof(keys);
    let calls = 0;
    const base = await serve({
      '/api/sessions/': () => (++calls < 3 ? [200, { status: 'pending' }] : [200, { proof }]),
    });
    const client = new ReclaimClient({ appId: 'x', providerId: 'y', baseUrl: base, pollMs: 5 });
    await client.awaitProof('s1');
    expect(calls).toBeGreaterThanOrEqual(3);
  });

  /// An abandoned session is the normal case, not an error condition to hang on.
  it('gives up rather than polling forever', async () => {
    const base = await serve({ '/api/sessions/': () => [200, { status: 'pending' }] });
    const client = new ReclaimClient({
      appId: 'x', providerId: 'y', baseUrl: base, pollMs: 5, timeoutMs: 30,
    });
    await expect(client.awaitProof('s1')).rejects.toThrow(/did not finish/);
  });

  it('surfaces a failed session immediately', async () => {
    const base = await serve({ '/api/sessions/': () => [200, { status: 'expired' }] });
    const client = new ReclaimClient({ appId: 'x', providerId: 'y', baseUrl: base, pollMs: 5 });
    await expect(client.awaitProof('s1')).rejects.toThrow(/ended without a proof/);
  });

  /// A tampered proof must be caught here, not by a reverted settlement.
  it('rejects a proof whose identifier does not match its claim data', async () => {
    const proof = await sdkProof([generatePrivateKey()]);
    proof.claimData.context = buildContext({ ...payment, amountBrlCents: 99n }, TEMPLATE);
    const base = await serve({ '/api/sessions/': () => [200, { proof }] });
    const client = new ReclaimClient({ appId: 'x', providerId: 'y', baseUrl: base, pollMs: 5 });
    await expect(client.awaitProof('s1')).rejects.toThrow(/does not match its claim data/);
  });
});

describe('checking witnesses against the chain', () => {
  const fakeClient = (known: string[]) => ({
    readContract: async ({ args }: { args: readonly unknown[] }) =>
      known.map((k) => k.toLowerCase()).includes(String(args[0]).toLowerCase()),
  }) as never;

  it('passes when every signer is registered', async () => {
    const keys = [generatePrivateKey(), generatePrivateKey()];
    const proof = await ReclaimClient.adopt(await sdkProof(keys));
    const addrs = keys.map((k) => privateKeyToAccount(k).address);
    await expect(assertWitnessesRegistered(fakeClient(addrs), '0x00', proof)).resolves.toHaveLength(2);
  });

  /// Reclaim rotates attestors by epoch; a verifier configured months ago falls behind.
  it('names the unknown witnesses and says how to fix it', async () => {
    const keys = [generatePrivateKey(), generatePrivateKey()];
    const proof = await ReclaimClient.adopt(await sdkProof(keys));
    const onlyOne = [privateKeyToAccount(keys[0]).address];
    await expect(assertWitnessesRegistered(fakeClient(onlyOne), '0x00', proof))
      .rejects.toThrow(/setWitness/);
  });

  it('fails before a transaction rather than inside one', async () => {
    const proof = await ReclaimClient.adopt(await sdkProof([generatePrivateKey()]));
    await expect(assertWitnessesRegistered(fakeClient([]), '0x00', proof))
      .rejects.toBeInstanceOf(ReclaimProofError);
  });
});

describe('checking the bank endpoint against the chain', () => {
  const prefixes = (known: Record<string, string>) => ({
    readContract: async ({ args }: { args: readonly unknown[] }) =>
      known[String(args[0]).toLowerCase()] ?? '',
  }) as never;

  it('passes for an allowlisted template under its url prefix', async () => {
    const proof = await ReclaimClient.adopt(await sdkProof([generatePrivateKey()]));
    const got = await assertEndpointAllowed(
      prefixes({ [TEMPLATE]: 'https://api.bank.example/pix/' }), '0x00', proof,
    );
    expect(got.providerHash).toBe(TEMPLATE);
  });

  /// The critical finding: a genuinely signed session with the wrong server.
  it('refuses a template the verifier does not allow, before a transaction', async () => {
    const proof = await ReclaimClient.adopt(await sdkProof([generatePrivateKey()]));
    await expect(assertEndpointAllowed(prefixes({}), '0x00', proof)).rejects.toThrow(/allowEndpoint/);
  });

  it('refuses a url outside the allowed prefix', async () => {
    const proof = await ReclaimClient.adopt(
      await sdkProof([generatePrivateKey()], 'https://api.bank.example.evil.io/pix/x'),
    );
    await expect(assertEndpointAllowed(
      prefixes({ [TEMPLATE]: 'https://api.bank.example/pix/' }), '0x00', proof,
    )).rejects.toThrow(/outside the allowed prefix/);
  });
});

describe('checking the rail against the endpoint\'s allowlist', () => {
  /** A chain whose verifier allows TEMPLATE under its prefix, for `mask`, and knows the witness. */
  const chain = (mask: number, witness: string) => ({
    readContract: async ({ functionName, args }: { functionName: string; args: readonly unknown[] }) => {
      if (functionName === 'endpointRails') return String(args[0]).toLowerCase() === TEMPLATE ? mask : 0;
      if (functionName === 'endpointUrlPrefix') return 'https://api.bank.example/pix/';
      return String(args[0]).toLowerCase() === witness.toLowerCase();
    },
  }) as never;

  it('passes a PIX proof from a PIX endpoint, and prepares the settlement', async () => {
    const key = generatePrivateKey();
    const proof = await ReclaimClient.adopt(await sdkProof([key]));
    const w = privateKeyToAccount(key).address;
    expect(await assertEndpointRail(chain(1 << Rail.PIX, w), '0x00', proof)).toBe(Rail.PIX);
    const prepared = await prepareSettlement(chain(1 << Rail.PIX, w), '0x00', proof);
    expect(prepared.rail).toBe(Rail.PIX);
  });

  /// A proof the verifier would refuse with RailNotAllowedForEndpoint is refused here first.
  it('refuses a PIX proof from an endpoint allowlisted only for boletos, before a transaction', async () => {
    const key = generatePrivateKey();
    const proof = await ReclaimClient.adopt(await sdkProof([key]));
    await expect(assertEndpointRail(chain(1 << Rail.BOLETO, privateKeyToAccount(key).address), '0x00', proof))
      .rejects.toThrow(/not allowlisted for PIX payments/);
  });
});

describe('in a browser', () => {
  /** A fetch that, like a browser's, throws when called with any `this` but undefined or the global object. */
  const browserFetch = (inner: typeof fetch): typeof fetch => function f(this: unknown, input: RequestInfo | URL, init?: RequestInit) {
    if (this !== undefined && this !== globalThis) throw new TypeError("Failed to execute 'fetch' on 'Window': Illegal invocation");
    return inner(input, init);
  } as typeof fetch;

  it('calls an injected fetch, and the global one, as plain functions', async () => {
    const base = await serve({ '/api/sessions': () => [200, { sessionId: 's1', url: 'https://reclaim.example/s1' }] });
    const nodeFetch = globalThis.fetch;
    expect((await new ReclaimClient({ appId: 'a', providerId: 'p', baseUrl: base, fetchImpl: browserFetch(nodeFetch) }).requestProof(ORDER)).sessionId).toBe('s1');
    globalThis.fetch = browserFetch(nodeFetch);
    try {
      expect((await new ReclaimClient({ appId: 'a', providerId: 'p', baseUrl: base }).requestProof(ORDER)).sessionId).toBe('s1');
    } finally {
      globalThis.fetch = nodeFetch;
    }
  });
});
