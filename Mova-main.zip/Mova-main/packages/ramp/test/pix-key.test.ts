import { describe, it, expect } from 'vitest';
import { keccak256, toBytes, type Hex } from 'viem';
import {
  InvalidPixKey, newPixSalt, normalizePixKey, pixKeyCommitment,
} from '../src/attestor.js';

/**
 * PIX key commitments.
 *
 * The check-digit vectors below were computed by hand, not by the code under test: a
 * validator that generates its own fixtures agrees with itself whether or not it is right,
 * which is how the inverted Pyth quote and the labelOf bug both survived.
 */

// Hand-verified: 529.982.247-25 (a widely published valid CPF) and 11.222.333/0001-81.
const CPF = '529.982.247-25';
const CNPJ = '11.222.333/0001-81';
// The Receita Federal's worked example of an alphanumeric CNPJ; check digits hand-computed.
const CNPJ_ALNUM = '12.ABC.345/01DE-35';

describe('the flaw this replaces', () => {
  /**
   * A bare hash of a CPF is reversible by enumeration. Here the attacker only knows the
   * first six digits and tries the remaining thousand prefixes with their check digits;
   * a real attacker would try all ~10^9, which is minutes of work.
   */
  function cpfsWithPrefix(prefix6: string): string[] {
    const out: string[] = [];
    for (let i = 0; i < 1000; i++) {
      const nine = prefix6 + String(i).padStart(3, '0');
      const n = [...nine].map(Number);
      const dv1 = ((n.reduce((a, d, k) => a + d * (10 - k), 0) * 10) % 11) % 10;
      const n10 = [...n, dv1];
      const dv2 = ((n10.reduce((a, d, k) => a + d * (11 - k), 0) * 10) % 11) % 10;
      out.push(nine + dv1 + dv2);
    }
    return out;
  }

  it('an unsalted hash of a CPF is recovered by trying candidates', () => {
    const onChain = keccak256(toBytes('52998224725'));
    const found = cpfsWithPrefix('529982').find((c) => keccak256(toBytes(c)) === onChain);
    expect(found).toBe('52998224725');
  });

  it('a salted commitment to the same CPF is not', () => {
    const onChain = pixKeyCommitment(CPF, newPixSalt());
    const found = cpfsWithPrefix('529982').find((c) => keccak256(toBytes(c)) === onChain
      || pixKeyCommitment(c, `0x${'11'.repeat(32)}` as Hex) === onChain);
    expect(found).toBeUndefined();
  });
});

describe('commitments', () => {
  it('the same key with different salts gives unlinkable commitments', () => {
    expect(pixKeyCommitment(CPF, newPixSalt())).not.toBe(pixKeyCommitment(CPF, newPixSalt()));
  });

  /// Formatting must not break settlement: the bank shows one form, the user typed another.
  it('the same key in different formatting gives the same commitment', () => {
    const salt = newPixSalt();
    expect(pixKeyCommitment('529.982.247-25', salt)).toBe(pixKeyCommitment('52998224725', salt));
    expect(pixKeyCommitment('Vendedor@Example.com ', salt))
      .toBe(pixKeyCommitment('vendedor@example.com', salt));
    expect(pixKeyCommitment('+55 (61) 91234-5678', salt))
      .toBe(pixKeyCommitment('+5561912345678', salt));
  });

  it('is domain-separated from a bare or concatenated hash', () => {
    const salt = newPixSalt();
    const c = pixKeyCommitment(CPF, salt);
    expect(c).not.toBe(keccak256(toBytes('52998224725')));
    expect(c).not.toBe(keccak256(toBytes(`52998224725${salt.slice(2)}`)));
  });

  it('refuses a missing, malformed or all-zero salt', () => {
    expect(() => pixKeyCommitment(CPF, '0x1234' as Hex)).toThrow(InvalidPixKey);
    expect(() => pixKeyCommitment(CPF, `0x${'00'.repeat(32)}` as Hex)).toThrow(/no salt/);
  });

  it('generates a 32-byte salt that differs every time', () => {
    const a = newPixSalt();
    expect(a).toMatch(/^0x[0-9a-f]{64}$/);
    expect(newPixSalt()).not.toBe(a);
  });
});

describe('key validation', () => {
  it('accepts a valid CPF in either form', () => {
    expect(normalizePixKey(CPF)).toEqual({ kind: 'cpf', key: '52998224725' });
  });

  it('rejects a CPF with a wrong check digit, before any money is at stake', () => {
    expect(() => normalizePixKey('529.982.247-26')).toThrow(/not a valid CPF/);
  });

  /// 000.000.000-00 satisfies the check-digit arithmetic and is not a real CPF.
  it('rejects a CPF of one repeated digit', () => {
    expect(() => normalizePixKey('111.111.111-11')).toThrow(InvalidPixKey);
  });

  it('points an 11-digit phone number at the +55 form instead of calling it a bad CPF', () => {
    expect(() => normalizePixKey('61912345678')).toThrow(/\+55/);
  });

  it('accepts a numeric CNPJ and an alphanumeric one', () => {
    expect(normalizePixKey(CNPJ)).toEqual({ kind: 'cnpj', key: '11222333000181' });
    expect(normalizePixKey(CNPJ_ALNUM)).toEqual({ kind: 'cnpj', key: '12ABC34501DE35' });
  });

  it('rejects a CNPJ with a wrong check digit', () => {
    expect(() => normalizePixKey('11.222.333/0001-82')).toThrow(/not a valid CNPJ/);
  });

  it('accepts a +55 phone and rejects one without the country code', () => {
    expect(normalizePixKey('+55 61 91234-5678')).toEqual({ kind: 'phone', key: '+5561912345678' });
    expect(() => normalizePixKey('+1 202 555 0100')).toThrow(/\+55/);
  });

  it('lowercases an email and rejects a malformed one', () => {
    expect(normalizePixKey('LP@Liquidez.com.br')).toEqual({ kind: 'email', key: 'lp@liquidez.com.br' });
    expect(() => normalizePixKey('lp@pix')).toThrow(/email/);
  });

  it('accepts a random key (EVP)', () => {
    expect(normalizePixKey('123E4567-E89B-42D3-A456-426614174000'))
      .toEqual({ kind: 'evp', key: '123e4567-e89b-42d3-a456-426614174000' });
  });

  it('rejects anything else', () => {
    expect(() => normalizePixKey('not a key')).toThrow(InvalidPixKey);
    expect(() => normalizePixKey('')).toThrow(/empty/);
  });
});
