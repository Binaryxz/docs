import { describe, it, expect } from 'vitest';
import fc from 'fast-check';
import { matchOrder, rankOffers, costBrlCents, type Offer } from '../src/orderbook.js';
import { Rail } from '../src/attestor.js';

/**
 * Property tests for the matcher.
 *
 * Phase 1 has these for the key tree and reconciliation; Phase 2 had none, and the matcher
 * is the natural place for them: it is a pure function whose invariants are easy to state
 * and whose failures are quiet - a quote that is a centavo under what the escrow charges
 * does not throw, it reverts a settlement later, for someone who has already paid.
 */

const NATIVE = '0x0000000000000000000000000000000000000000';
const OTHER = '0x00000000000000000000000000000000000000dc';

const arbOffer = fc.record({
  offerId: fc.string({ minLength: 4, maxLength: 8, unit: fc.constantFrom(...'0123456789abcdef') }),
  price: fc.bigInt({ min: 1n, max: 10n ** 9n }),
  available: fc.bigInt({ min: 1n, max: 10n ** 21n }),
  min: fc.bigInt({ min: 1n, max: 10n ** 18n }),
  span: fc.bigInt({ min: 0n, max: 10n ** 20n }),
  decimals: fc.constantFrom(6, 8, 18),
  rails: fc.constantFrom<Rail[][]>([Rail.PIX], [Rail.BOLETO], [Rail.PIX, Rail.BOLETO]),
  tier: fc.constantFrom('RETAIL' as const, 'INSTITUTIONAL' as const),
  settledCents: fc.bigInt({ min: 0n, max: 10n ** 12n }),
  disputesLost: fc.integer({ min: 0, max: 8 }),
}).map((o): Offer => ({
  offerId: o.offerId,
  lp: `0x${o.offerId.padStart(40, '0')}`,
  asset: NATIVE,
  decimals: o.decimals,
  rails: o.rails,
  availableWei: o.available,
  priceBrlCentsPerEth: o.price,
  minOrderWei: o.min,
  maxOrderWei: o.min + o.span,
  verifier: '0xv',
  tier: o.tier,
  settledCents: o.settledCents,
  disputesLost: o.disputesLost,
}));

const arbBook = fc.array(arbOffer, { maxLength: 8 });
const arbWant = fc.bigInt({ min: 1n, max: 10n ** 21n });

describe('cost', () => {
  /// The escrow rounds up. A quote that rounds down is a settlement that reverts.
  it('never quotes less than the exact price, at any decimals', () => {
    fc.assert(fc.property(
      fc.bigInt({ min: 0n, max: 10n ** 24n }),
      fc.bigInt({ min: 1n, max: 10n ** 9n }),
      fc.constantFrom(6, 8, 18),
      (amount, price, decimals) => {
        const cents = costBrlCents(amount, price, decimals);
        expect(cents * 10n ** BigInt(decimals)).toBeGreaterThanOrEqual(amount * price);
      },
    ), { numRuns: 500 });
  });

  it('never overcharges by more than one centavo', () => {
    fc.assert(fc.property(
      fc.bigInt({ min: 1n, max: 10n ** 24n }),
      fc.bigInt({ min: 1n, max: 10n ** 9n }),
      fc.constantFrom(6, 8, 18),
      (amount, price, decimals) => {
        const unit = 10n ** BigInt(decimals);
        const exact = (amount * price) / unit;
        expect(costBrlCents(amount, price, decimals) - exact).toBeLessThanOrEqual(1n);
      },
    ), { numRuns: 500 });
  });

  it('is monotonic in amount', () => {
    fc.assert(fc.property(
      fc.bigInt({ min: 1n, max: 10n ** 20n }),
      fc.bigInt({ min: 1n, max: 10n ** 20n }),
      fc.bigInt({ min: 1n, max: 10n ** 9n }),
      (a, b, price) => {
        const [lo, hi] = a <= b ? [a, b] : [b, a];
        expect(costBrlCents(hi, price)).toBeGreaterThanOrEqual(costBrlCents(lo, price));
      },
    ), { numRuns: 300 });
  });
});

describe('matching invariants', () => {
  /// The one that would hurt: spending more of someone's money than they asked to spend.
  it('never fills more than was requested', () => {
    fc.assert(fc.property(arbBook, arbWant, (book, want) => {
      const r = matchOrder(book, { asset: NATIVE, weiWanted: want });
      expect(r.filledWei).toBeLessThanOrEqual(want);
    }), { numRuns: 300 });
  });

  it('accounts for every wei: filled + unfilled == requested', () => {
    fc.assert(fc.property(arbBook, arbWant, (book, want) => {
      const r = matchOrder(book, { asset: NATIVE, weiWanted: want });
      expect(r.filledWei + r.unfilledWei).toBe(want);
    }), { numRuns: 300 });
  });

  it('never takes more from an offer than that offer has, or than it allows', () => {
    fc.assert(fc.property(arbBook, arbWant, (book, want) => {
      const r = matchOrder(book, { asset: NATIVE, weiWanted: want });
      for (const f of r.fills) {
        const o = book.find((x) => x.offerId === f.offerId)!;
        expect(f.weiAmount).toBeLessThanOrEqual(o.availableWei);
        expect(f.weiAmount).toBeLessThanOrEqual(o.maxOrderWei);
        expect(f.weiAmount).toBeGreaterThanOrEqual(o.minOrderWei);
      }
    }), { numRuns: 300 });
  });

  it('never hands a taker more legs than the bound', () => {
    fc.assert(fc.property(arbBook, arbWant, fc.integer({ min: 1, max: 5 }), (book, want, max) => {
      expect(matchOrder(book, { asset: NATIVE, weiWanted: want }, max).fills.length)
        .toBeLessThanOrEqual(max);
    }), { numRuns: 200 });
  });

  it('quotes each leg at that leg\'s own price, never a blend', () => {
    fc.assert(fc.property(arbBook, arbWant, (book, want) => {
      const r = matchOrder(book, { asset: NATIVE, weiWanted: want });
      let sum = 0n;
      for (const f of r.fills) {
        const o = book.find((x) => x.offerId === f.offerId)!;
        expect(f.brlCents).toBe(costBrlCents(f.weiAmount, o.priceBrlCentsPerEth, o.decimals));
        sum += f.brlCents;
      }
      expect(r.totalBrlCents).toBe(sum);
    }), { numRuns: 300 });
  });

  it('uses each offer at most once', () => {
    fc.assert(fc.property(arbBook, arbWant, (book, want) => {
      const ids = matchOrder(book, { asset: NATIVE, weiWanted: want }).fills.map((f) => f.offerId);
      expect(new Set(ids).size).toBe(ids.length);
    }), { numRuns: 300 });
  });

  it('respects the taker\'s limit price', () => {
    fc.assert(fc.property(arbBook, arbWant, fc.bigInt({ min: 1n, max: 10n ** 9n }), (book, want, cap) => {
      const r = matchOrder(book, { asset: NATIVE, weiWanted: want, maxPriceBrlCentsPerEth: cap });
      for (const f of r.fills) expect(f.priceBrlCentsPerEth).toBeLessThanOrEqual(cap);
    }), { numRuns: 300 });
  });

  /// A match that cannot settle is worse than no match: it burns the pay window.
  it('never matches a taker to a rail the LP cannot reconcile', () => {
    fc.assert(fc.property(arbBook, arbWant, fc.constantFrom(Rail.PIX, Rail.BOLETO, Rail.TED),
      (book, want, rail) => {
        const r = matchOrder(book, { asset: NATIVE, weiWanted: want, rails: [rail] });
        for (const f of r.fills) {
          expect(book.find((x) => x.offerId === f.offerId)!.rails).toContain(rail);
        }
      }), { numRuns: 300 });
  });

  it('never mixes assets', () => {
    fc.assert(fc.property(arbBook, arbWant, (book, want) => {
      const mixed = book.map((o, i) => (i % 2 ? { ...o, asset: OTHER } : o));
      const r = matchOrder(mixed, { asset: NATIVE, weiWanted: want });
      for (const f of r.fills) expect(f.asset).toBe(NATIVE);
    }), { numRuns: 300 });
  });
});

describe('ranking', () => {
  it('is a total order: sorting twice changes nothing', () => {
    fc.assert(fc.property(arbBook, (book) => {
      const once = rankOffers(book).map((o) => o.offerId);
      expect(rankOffers(rankOffers(book)).map((o) => o.offerId)).toEqual(once);
    }), { numRuns: 200 });
  });

  it('is independent of input order, so two matchers agree on one book', () => {
    fc.assert(fc.property(arbBook, (book) => {
      expect(rankOffers([...book].reverse()).map((o) => o.offerId))
        .toEqual(rankOffers(book).map((o) => o.offerId));
    }), { numRuns: 200 });
  });

  /// Price leads. Reputation only breaks ties - otherwise a big LP charges above market
  /// and still wins the top of the book.
  it('never ranks a dearer offer above a cheaper one', () => {
    fc.assert(fc.property(arbBook, (book) => {
      const r = rankOffers(book);
      for (let i = 1; i < r.length; i++) {
        expect(r[i].priceBrlCentsPerEth).toBeGreaterThanOrEqual(r[i - 1].priceBrlCentsPerEth);
      }
    }), { numRuns: 200 });
  });
});
