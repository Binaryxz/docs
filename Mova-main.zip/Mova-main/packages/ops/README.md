# @mova/ops — monitoring and admin tooling

Two binaries and the packaging to run them. Both exist because production hardening is mostly
about the hours when nobody is watching: one tool that notices, and one that makes a
privileged change reviewable before it happens.

## The monitor

Sweeps the contracts on an interval and exposes what it found.

```bash
RPC_URL=https://... PP_ENTRYPOINT=0x… ORACLE=0x… VAULT=0x… \
RELAYER=0x… PAYMASTER=0x… ALERT_WEBHOOK=https://hooks.slack.com/… \
  npm run -w @mova/ops monitor
```

Every target is optional; it watches what it is given. It holds no key and sends no
transaction — `eth_call` and `eth_getBalance` only — which is what makes it safe to replicate
on hardware you do not control.

| Endpoint | Question it answers |
|---|---|
| `/healthz` | Is this process alive? Always 200 while it runs — see below |
| `/readyz` | Has it completed a sweep yet? 503 until the first one |
| `/status` | The verdict, what is firing, and every reading |
| `/metrics` | Prometheus exposition |

**`/healthz` deliberately ignores the chain's health.** A monitor that marks itself unhealthy
when the thing it watches breaks gets restarted by its supervisor at exactly the moment it had
something to say. The chain's verdict lives in `/status`, and the alerts go to the webhook.

### Checks

`oracle_freshness`, `asset_oracle:<asset>`, `asp_root_age`, `relayer_gas`, `paymaster_deposit`, `paymaster_stake`,
`pyth_keeper_gas:<address>` (`PYTH_KEEPERS`), `vault_drawdown`, `vault_liquidity`, `pool_reachable`,
the `movva_*` checks and the `node_rewards_*` checks. What each one means when it fires, and what to do, is in
[`docs/runbook-incidents.md`](../../docs/runbook-incidents.md).

**An LP node's per-payer caps** (`LP_NODE_STATUS_URL`, optionally `LP_NODE_NAME`; packages/lp-node `caps.ts`).
Set these only for a node whose operator HAS configured caps - a node without them is a policy choice, not a fault:

| Check | Fires when | What to do |
|---|---|---|
| `lp_node_caps` | fail: the node's `/status` reports no caps at all (the `caps` section is gone from its `LP_CONFIG`, or this is not the node you think); fail: it is counting into another Brasília day than today, so every daily limit resets at the wrong hour; fail: it attributed BRL to a payer more than `LP_NODE_CAPS_STALE_SECONDS` (300) after its cap ledger was last written. warn: it keeps a ledger no tier puts a limit on | No caps: put the section back and restart it - meanwhile that LP applies no limit to anyone. Wrong day: fix the node's clock or timezone. Stale ledger: check `STATE_FILE` is writable and is the journal it has been running on. No limits: set the numbers in `config.caps.tiers` |

**Node-provider rewards** (`NODE_REWARDS`, optionally `FEE_SPLITTER`; SR2-36):

| Check | Fires when | What to do |
|---|---|---|
| `node_rewards_balance` | fail: NodeRewards holds less of its token than it has booked, so claims revert | Only a claim moves tokens out: look at the reward token itself (a fee, a freeze, a rebase) |
| `node_rewards_unclaimed` | warn: an epoch has been finalizable for `REWARDS_FINALIZE_WARN_SECONDS` (2 days) and nobody finalized it; or more than `REWARDS_UNCLAIMED_FLOOR_CENTS` (R$ 100,00) is owed and no LP has claimed for `REWARDS_UNCLAIMED_WARN_SECONDS` (30 days) | Anyone may send `rewards:finalize`; ask LPs whether their nodes run with `rewards.claim`. Nothing expires |
| `node_rewards_wiring` | warn: no registry bound while there is something to share, or the splitter funds another contract or splits another token | `rewards:registry` to bind the ramp's registry; `splitter:rewards` through the delay |

Both contracts join the event watcher's governed set, and a scheduled `setLpRewardShare`, `setRewardLimits`, `setRegistry`,
`setExcluded`, `setTreasury`, `setRewards` or `setRewardsHook` is decoded in its alert.

**An FX rate sleeps at night.** PythFxOracle's rate is Pyth's FX.USD/BRL, which trades weekdays 08:00-17:00
New York time, so it ages and then refuses every weekday night and weekend by design. `oracle_freshness`
and the `movva_*` checks judge such a leg by FxMarketHours' core session (13:30-21:00 UTC): a stale or
refused rate inside it alerts and names the Pyth keeper; outside it, a band that still prices the last close
is `ok` and says the market is closed, and a band that refuses too alerts.

### Three states, not two

A check returns `ok`, `warn`, `fail` — or **`unknown`**, which is the one that matters. A
check whose call threw has not passed; it has failed to run. Collapsing that into `ok` is how
a dashboard stays green while the chain is on fire. `unknown` alerts on its own, after a
five-minute grace period so one flaky call is not a page.

### Alerts are edges

Entering a bad state fires once. Staying there is silent. Recovering sends a resolution. A
monitor that pages every sixty seconds gets muted, and a muted monitor buys silence rather
than safety.

## The admin tool

Every governor, guardian and keeper function in `contracts/ramp` and `contracts/yield` (the
escrows, registry, verifiers, oracles and vault) — and
none of them fires without `--execute`. `test/admin.test.ts` reads those contracts and fails
when a guarded function has no command, so the claim is checked. Not covered: the
`SponsorPaymaster` owner functions.

```bash
# Dry run: prints the call, the risk, the calldata and a pasteable cast send
npm run -w @mova/ops admin -- lp:tier $REGISTRY $LP AFFILIATED 500000

# Send it (or omit --execute and hand the calldata to the multisig)
npm run -w @mova/ops admin -- lp:tier $REGISTRY $LP AFFILIATED 500000 --execute

# Submit a ruling exactly as the arbitration desk handed it over
curl -H "authorization: Bearer $OPERATOR_TOKEN" $DESK/cases/$CASE/submission > ruling.json
npm run -w @mova/ops admin -- escrow:resolve $ESCROW ruling.json
```

Node-provider rewards have their own commands: `splitter:share`, `splitter:treasury`, `splitter:rewards` and
`splitter:split` on the FeeSplitter; `rewards:registry`, `rewards:limits`, `rewards:exclude`, `rewards:void` and
`rewards:finalize` on NodeRewards; `lp:rewards-hook` on the registry. Raising the LPs' share, the rate or the per-LP cap,
lowering the minimum, a new treasury, rewards contract, hook or (once funded) registry, and reinstating an excluded LP go through
`gov:schedule` / `gov:execute`; the dry run says which way a share or limits change goes. `splitter:split` and
`rewards:finalize` are open to anyone and read `SUBMITTER_KEY`.

`npm run -w @mova/ops admin` with no arguments lists every command. Tiers are the registry's
enum by name — `NONE`, `RETAIL`, `AFFILIATED`, `INSTITUTIONAL`, `SUSPENDED` — and anything
else, including a bare number, is refused. Keeper and guardian commands read `KEEPER_KEY` or
`GUARDIAN_KEY` instead of `GOVERNOR_KEY`.

**The governance timelock.** Risk-increasing calls (adding arbitrators, verifiers or
witnesses, lowering thresholds, listing assets or feeds, adding adapters, changing the keeper,
raising tiers or caps, advancing the network phase) are moving to schedule → execute after
48 hours. Those commands still call the direct function today; the list, and how to add the
schedule/execute pairs, is the TODO above `COMMANDS` in `src/bin/admin.ts`.

**Why the dry run is the default.** These commands decide whose attestation releases escrowed
money, what an LP may hold, and who governs the contracts. A tool that acts first and reports
afterwards gets used quickly and reviewed never. In production the governor should be a
multisig, in which case the dry run *is* the workflow: it prints the calldata to approve.

With `--execute` the call is simulated before it is sent, so a revert costs nothing and an
operator is never left guessing whether a change took effect.

## Running it in production

`Dockerfile` builds one image for the monitor, the matcher and the arbitration desk;
`docker-compose.yml` runs them locally in production shape (the desk, which holds a key, only
under `--profile arbitration`); `flux/` holds the Flux application specs for the two keyless
services and — more importantly —
[which services can be replicated on machines you do not control, and which cannot](flux/README.md).

Every launch site runs a production entrypoint with `node --import tsx`:
`src/bin/monitor.ts`, `packages/ramp/src/bin/matcher.ts` and
`packages/ramp/src/bin/arbitration.ts`. The matcher and the desk refuse to start on missing
or malformed configuration and name every variable at fault; the monitor refuses to start
with nothing to watch. `test/packaging.test.ts` checks, without Docker, that each launched
script exists and is not a demo, and that the launcher survives `npm ci --omit=dev`.

**No raw error leaves a service.** `src/redact.ts` cuts every URL in an error to scheme and
host and removes configured secrets (RPC_URL, ALERT_WEBHOOK, tokens). It is applied to check
details, `/status`, the alert webhook and console sink, the matcher's `/health`, the desk's
error responses, and every bin's logs — because a viem transport error contains the RPC URL,
and a hosted RPC URL contains its API key.

## Tests

```bash
npx vitest run packages/ops
```

77 tests. The ones worth reading are the alert-transition tests, which pin the edge behaviour,
and `checks.test.ts`'s "a read that throws" — the property the whole design rests on.
