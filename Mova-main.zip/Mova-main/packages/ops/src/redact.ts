/**
 * Strip secrets from text before it leaves the process.
 *
 * ## Why this exists
 *
 * Hosted RPC providers put the API key in the URL path (`/v2/<key>` at Alchemy, `/v3/<key>`
 * at Infura) or the query string, and viem puts the URL in every transport error:
 *
 *     HTTP request failed.
 *
 *     URL: https://eth-mainnet.g.alchemy.com/v2/<key>
 *     Request body: {"method":"eth_call", ...}
 *
 * Those messages were copied verbatim into the monitor's unauthenticated `/status`, into
 * the alert webhook, into the matcher's public `/health`, and into logs that on a replicated
 * Flux deployment are read by node operators nobody vetted. One flaky RPC call published the
 * key. Webhook URLs have the same shape - a Slack incoming webhook IS its path.
 *
 * ## What it does
 *
 * 1. Every URL is cut down to scheme and host, dropping credentials, path, query and
 *    fragment. Whether a path is secret cannot be known from the text, so none is kept.
 * 2. Then every configured secret (RPC_URL, ALERT_WEBHOOK, a token) is removed wherever it
 *    still appears - and for a URL, so are its credentials, its path and query, and each long
 *    path segment or query value on its own, which catches the key in a message that printed
 *    the URL without its scheme, or only its path.
 *
 * In that order, so the second step never sees the first step's output as a URL to cut again.
 *
 * It is one function applied at each boundary - HTTP responses, logs, webhooks - rather than
 * only where errors are made, because errors reach those boundaries from code this does not
 * own.
 */

const MARK = '[redacted]';

/** Anything with a scheme, up to whitespace or a character that cannot end a bare URL. */
const URL_RE = /\b[a-zA-Z][a-zA-Z0-9+.-]*:\/\/[^\s"'<>`)\]}]+/g;

/** Path segments or query values this long are treated as keys when they belong to a secret. */
const MIN_KEY_LENGTH = 8;

/** The pieces of a configured secret that must not appear anywhere. */
function fragmentsOf(secret: string): string[] {
  const out = new Set<string>([secret]);
  try {
    const u = new URL(secret);
    out.add(u.href);
    if (u.username) out.add(u.username);
    if (u.password) out.add(u.password);
    const rest = `${u.pathname}${u.search}`;
    if (rest.length > 1) out.add(rest);
    for (const seg of u.pathname.split('/')) {
      if (seg.length >= MIN_KEY_LENGTH) out.add(seg);
    }
    for (const v of u.searchParams.values()) {
      if (v.length >= MIN_KEY_LENGTH) out.add(v);
    }
  } catch {
    // Not a URL - a token or a key. The whole value is the secret.
  }
  return [...out].filter((f) => f.length > 0);
}

/** A URL as scheme and host only, marked when something was removed. */
function scrubUrl(raw: string): string {
  // A URL at the end of a sentence carries the sentence's punctuation; keep it outside.
  const trail = /[.,;:!?]+$/.exec(raw)?.[0] ?? '';
  const body = trail ? raw.slice(0, -trail.length) : raw;
  try {
    const u = new URL(body);
    const removed = u.username || u.password || u.pathname.length > 1 || u.search || u.hash;
    return `${u.protocol}//${u.host}${removed ? `/${MARK}` : ''}${trail}`;
  } catch {
    return `${MARK}${trail}`;
  }
}

/**
 * Redact `text`.
 *
 * @param secrets values that must never appear, typically RPC_URL and ALERT_WEBHOOK.
 *                Undefined and empty entries are ignored, so callers can pass optional
 *                configuration straight through.
 */
export function redact(text: string, secrets: readonly (string | undefined)[] = []): string {
  let out = text.replace(URL_RE, scrubUrl);
  // Longest first, so a whole value goes before a shorter piece of it could split it.
  const fragments = secrets
    .filter((s): s is string => typeof s === 'string' && s.length > 0)
    .flatMap(fragmentsOf)
    .sort((a, b) => b.length - a.length);
  for (const f of fragments) out = out.split(f).join(MARK);
  return out;
}

/**
 * Whether `text` carries any configured secret, or a piece of one `redact` would remove.
 *
 * For a response that must be served verbatim - payment instructions carry a PIX key, a salt and a
 * checkout URL whose path IS the checkout - `redact` would destroy the payload. Such a boundary refuses
 * to send instead of scrubbing: the configured secrets still never leave, and nothing the counterparty
 * needs is cut.
 */
export function containsSecret(text: string, secrets: readonly (string | undefined)[] = []): boolean {
  return secrets
    .filter((s): s is string => typeof s === 'string' && s.length > 0)
    .flatMap(fragmentsOf)
    .some((f) => text.includes(f));
}

/** `redact` for an unknown thrown value: its message, never its stack or its cause chain. */
export function redactError(e: unknown, secrets: readonly (string | undefined)[] = []): string {
  return redact(e instanceof Error ? e.message : String(e), secrets);
}
