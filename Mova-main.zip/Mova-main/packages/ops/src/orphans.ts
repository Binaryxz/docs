/**
 * The abandoned contracts, watched.
 *
 * The 8 September 2026 Sepolia stack (deployments/abandoned-sepolia-2026-09-08.json) is abandoned and its
 * owner key is lost (client decision, 24 September 2026: "document, monitor, make sure no frontend or script
 * points to those addresses"). Nothing legitimate happens there any more, so ANY of the following is an
 * incident, never noise:
 *
 *  - a log from any listed contract after the baseline: a new transaction touched it. Role events
 *    (RoleGranted, RoleRevoked, OwnershipTransferred) are named in the alert, because OWNER_ROLE or the
 *    paymaster's ownership changing hands means the lost key resurfaced or was taken;
 *  - the lost owner's nonce rising: the key signed something, anywhere on that chain;
 *  - the Entrypoint no longer granting OWNER_ROLE to the lost owner, or the paymaster no longer owned by it.
 *
 * The runbook step is "if the key resurfaces, renounce on the spot" (docs/runbook-incidents.md).
 *
 * A record can instead name a `renouncedOwner`: a superseded stack whose key we still hold and whose roles were
 * renounced (the 21 September 2026 partial deployment, deployments/abandoned-sepolia-2026-09-21.json). There the
 * invariant is inverted - the former owner must hold NO role, and every listed governor must be the burn address -
 * so anyone regaining a role, or the renunciation not having happened, is the incident.
 *
 * State is a block cursor and the owner's nonce, both taken from the chain at the first sweep (or from
 * `baselineBlock`), so a restart forgets nothing the baseline already covers. It reads only; no key.
 */
import { getAddress, keccak256, toHex, type Address, type Hex, type PublicClient } from 'viem';
import type { CheckResult } from './checks.js';
import { redactError } from './redact.js';

export interface AbandonedRecord {
  chainId: number;
  abandonedOn: string;
  baselineBlock: number | null;
  /** The owner key, when it is lost: the roles must stay with it. */
  lostOwner?: Address;
  /** The former owner, when its roles were renounced: it must hold none of them again. */
  renouncedOwner?: Address;
  /** The check id this record reports under; `orphan_watch` by default. */
  watchId?: string;
  contracts: { name: string; address: Address; ownerRole?: boolean; postmanRole?: boolean; paymasterOwner?: boolean; governor?: boolean }[];
  historicalRecords: { path: string; why: string }[];
  knownStaleReferences: { path: string; why: string }[];
}

export function parseAbandoned(json: string): AbandonedRecord {
  const r = JSON.parse(json) as AbandonedRecord;
  if (!Array.isArray(r.contracts) || r.contracts.length === 0) throw new Error('abandoned record: no contracts');
  if (!r.lostOwner === !r.renouncedOwner) throw new Error('abandoned record: name exactly one of lostOwner and renouncedOwner');
  return {
    ...r,
    lostOwner: r.lostOwner ? getAddress(r.lostOwner) : undefined,
    renouncedOwner: r.renouncedOwner ? getAddress(r.renouncedOwner) : undefined,
    contracts: r.contracts.map((c) => ({ ...c, address: getAddress(c.address) })),
    historicalRecords: r.historicalRecords ?? [],
    knownStaleReferences: r.knownStaleReferences ?? [],
  };
}

export const OWNER_ROLE: Hex = keccak256(toHex('OWNER_ROLE'));
export const ASP_POSTMAN: Hex = keccak256(toHex('ASP_POSTMAN'));
/** Where a renounced DelayedGovernance governor goes (`--finalize`, docs/deployments.md). */
export const BURN: Address = '0x000000000000000000000000000000000000dEaD';

/** The record's owner key, lost or renounced. */
export const ownerOf = (r: AbandonedRecord): Address => (r.lostOwner ?? r.renouncedOwner)!;
const ROLE_TOPICS: Record<string, string> = {
  [keccak256(toHex('RoleGranted(bytes32,address,address)'))]: 'RoleGranted',
  [keccak256(toHex('RoleRevoked(bytes32,address,address)'))]: 'RoleRevoked',
  [keccak256(toHex('OwnershipTransferred(address,address)'))]: 'OwnershipTransferred',
  // SponsorPaymaster's own event for transferOwnership.
  [keccak256(toHex('OwnerChanged(address,address)'))]: 'OwnerChanged',
};
const HAS_ROLE = [{ type: 'function', name: 'hasRole', stateMutability: 'view', inputs: [{ type: 'bytes32' }, { type: 'address' }], outputs: [{ type: 'bool' }] }] as const;
const OWNER = [{ type: 'function', name: 'owner', stateMutability: 'view', inputs: [], outputs: [{ type: 'address' }] }] as const;
const GOVERNOR = [{ type: 'function', name: 'governor', stateMutability: 'view', inputs: [], outputs: [{ type: 'address' }] }] as const;

export interface OrphanOptions {
  client: Pick<PublicClient, 'getBlockNumber' | 'getLogs' | 'getTransactionCount' | 'readContract'>;
  record: AbandonedRecord;
  /** Overrides `record.baselineBlock`; with neither, the first sweep's head is the baseline. */
  baselineBlock?: bigint;
  redactValues?: (string | undefined)[];
}

export class OrphanWatcher {
  private cursor?: bigint;
  private nonce?: number;
  /** Every incident found so far, kept: an incident does not resolve itself. */
  private readonly incidents = new Map<string, string>();
  private lastError?: string;

  constructor(private readonly o: OrphanOptions) {
    const b = o.baselineBlock ?? (o.record.baselineBlock === null ? undefined : BigInt(o.record.baselineBlock));
    this.cursor = b === undefined ? undefined : b + 1n;
  }

  async sweep(): Promise<CheckResult[]> {
    const { client, record } = this.o;
    try {
      const head = await client.getBlockNumber();
      if (this.cursor === undefined) this.cursor = head + 1n;
      const owner = ownerOf(record);
      const lost = record.lostOwner !== undefined;
      const nonce = await client.getTransactionCount({ address: owner, blockTag: 'latest' });
      if (this.nonce === undefined) this.nonce = nonce;
      if (nonce > this.nonce) {
        this.incidents.set('owner_nonce', lost
          ? `the lost owner ${owner} has sent ${nonce - this.nonce} transaction(s) since monitoring began (nonce ${this.nonce} -> ${nonce}): the key resurfaced or was taken`
          : `the former owner ${owner} of the renounced stack has sent ${nonce - this.nonce} transaction(s) since monitoring began (nonce ${this.nonce} -> ${nonce}): nothing should sign with it any more`);
        this.nonce = nonce;
      }
      if (head >= this.cursor) {
        const logs = await client.getLogs({ address: record.contracts.map((c) => c.address), fromBlock: this.cursor, toBlock: head });
        for (const l of logs) {
          const name = record.contracts.find((c) => c.address.toLowerCase() === l.address.toLowerCase())?.name ?? l.address;
          const role = ROLE_TOPICS[l.topics[0] ?? ''];
          this.incidents.set(`log:${l.transactionHash}:${l.logIndex}`,
            `${role ? `ROLE EVENT ${role}` : 'a transaction'} touched abandoned ${name} (${l.address}) in block ${l.blockNumber}, tx ${l.transactionHash}`
            + (role ? (lost ? ': ownership changed hands - the lost key resurfaced or was taken; renounce at once (runbook)' : ': a role changed on a renounced stack - nobody should be able to grant one') : ''));
        }
        this.cursor = head + 1n;
      }
      for (const c of record.contracts) {
        for (const [flag, role, label] of [[c.ownerRole, OWNER_ROLE, 'OWNER_ROLE'], [c.postmanRole, ASP_POSTMAN, 'ASP_POSTMAN']] as const) {
          if (!flag) continue;
          const has = await client.readContract({ address: c.address, abi: HAS_ROLE, functionName: 'hasRole', args: [role, owner] });
          if (lost && !has) this.incidents.set(`owner_role:${c.address}:${label}`, `${label} on ${c.name} is no longer held by the lost owner: it was renounced, revoked or moved`);
          if (!lost && has) this.incidents.set(`owner_role:${c.address}:${label}`, `${label} on ${c.name} is still held by the former owner ${owner}: the renunciation has not happened, or was undone`);
        }
        if (c.paymasterOwner) {
          const o = await client.readContract({ address: c.address, abi: OWNER, functionName: 'owner' });
          if (getAddress(o) !== owner) this.incidents.set(`paymaster_owner:${c.address}`, `${c.name} is now owned by ${o}, not the lost owner: ownership moved`);
        }
        if (c.governor) {
          const g = await client.readContract({ address: c.address, abi: GOVERNOR, functionName: 'governor' });
          if (getAddress(g) !== BURN) this.incidents.set(`governor:${c.address}`, `${c.name}'s governor is ${g}, not the burn address: the renunciation has not happened, or was undone`);
        }
      }
      this.lastError = undefined;
    } catch (e) {
      this.lastError = redactError(e, this.o.redactValues);
    }
    return this.checks();
  }

  private checks(): CheckResult[] {
    const out: CheckResult[] = [];
    const id = this.o.record.watchId ?? 'orphan_watch';
    if (this.lastError) out.push({ id, level: 'unknown', detail: `the abandoned stack could not be read: ${this.lastError}` });
    if (this.incidents.size === 0) {
      if (!this.lastError) out.push({ id, level: 'ok', detail: `${this.o.record.contracts.length} abandoned contracts and the ${this.o.record.lostOwner ? 'lost' : 'former'} owner are quiet (from block ${this.cursor})` });
      return out;
    }
    out.push({ id, level: 'fail', value: this.incidents.size, threshold: 0, detail: [...this.incidents.values()].join('; ') });
    return out;
  }
}
