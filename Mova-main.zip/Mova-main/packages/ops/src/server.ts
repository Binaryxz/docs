/**
 * The monitor's HTTP surface: what a load balancer, a scrape job and a human each need.
 *
 * Three endpoints, three different questions, deliberately not collapsed into one:
 *
 *  - `/healthz` - "is this process alive?" Answers 200 as long as the monitor itself is
 *    running. It does NOT report the chain's health, because a monitor that marks itself
 *    unhealthy when the thing it watches breaks gets restarted by its supervisor at exactly
 *    the moment it had something to say.
 *  - `/readyz` - "has it completed a sweep yet?" 503 until the first results exist, so a
 *    freshly started monitor is not scraped for a verdict it has not formed.
 *  - `/status` - the human view: every check, its level and its one-line detail.
 *  - `/metrics` - Prometheus exposition.
 *
 * This mirrors the convention already set by the matcher service, which returns 503 from
 * its health route when its own sync is broken rather than a bare "ok".
 */
import { createServer, type Server, type IncomingMessage, type ServerResponse } from 'node:http';
import type { CheckResult, Level } from './checks.js';
import { worst } from './checks.js';
import { redact } from './redact.js';

const LEVEL_CODE: Record<Level, number> = { ok: 0, warn: 1, fail: 2, unknown: 3 };

/**
 * Prometheus text exposition. Label sets stay identical across scrapes so series are stable.
 *
 * The only label is the check id, a constant in code. A check's detail - the one field that
 * can carry an error message - is never exported here, and must not become a label: labels
 * are scraped, stored and shown on dashboards with far less care than an alert channel.
 */
export function renderMetrics(results: readonly CheckResult[], sweepAt: number): string {
  const lines: string[] = [];
  const esc = (s: string) => s.replace(/\\/g, '\\\\').replace(/"/g, '\\"');

  lines.push('# HELP mova_check_level Check state: 0 ok, 1 warn, 2 fail, 3 unknown.');
  lines.push('# TYPE mova_check_level gauge');
  for (const r of results) {
    lines.push(`mova_check_level{check="${esc(r.id)}"} ${LEVEL_CODE[r.level]}`);
  }

  lines.push('# HELP mova_check_value The reading that the check compared against its threshold.');
  lines.push('# TYPE mova_check_value gauge');
  for (const r of results) {
    if (r.value !== undefined) lines.push(`mova_check_value{check="${esc(r.id)}"} ${r.value}`);
  }

  lines.push('# HELP mova_check_threshold The bound the reading was compared against.');
  lines.push('# TYPE mova_check_threshold gauge');
  for (const r of results) {
    if (r.threshold !== undefined) lines.push(`mova_check_threshold{check="${esc(r.id)}"} ${r.threshold}`);
  }

  lines.push('# HELP mova_last_sweep_timestamp_seconds Unix time of the last completed sweep.');
  lines.push('# TYPE mova_last_sweep_timestamp_seconds gauge');
  lines.push(`mova_last_sweep_timestamp_seconds ${Math.floor(sweepAt / 1000)}`);

  return `${lines.join('\n')}\n`;
}

export interface MonitorState {
  /** Latest sweep, or undefined before the first one completes. */
  results?: readonly CheckResult[];
  sweepAt?: number;
  firing?: readonly string[];
}

/**
 * Serve the endpoints over a state object the caller keeps updating. Passing state by
 * reference rather than by value means a slow sweep never blocks a scrape - the scrape
 * simply sees the previous sweep, which is what a monitoring system expects.
 */
export function serveMonitor(state: MonitorState, opts: {
  /** Values that must never be served: RPC_URL, ALERT_WEBHOOK. See `redact`. */
  redactValues?: readonly (string | undefined)[];
} = {}): {
  server: Server;
  /** `host`: the address to bind; every interface when omitted. */
  listen: (port?: number, host?: string) => Promise<number>;
  close: () => Promise<void>;
} {
  const handle = (rq: IncomingMessage, rs: ServerResponse): void => {
    const url = new URL(rq.url ?? '/', 'http://localhost');
    const json = (code: number, body: unknown) => {
      rs.writeHead(code, { 'content-type': 'application/json' });
      rs.end(JSON.stringify(body, null, 2));
    };

    if (url.pathname === '/healthz') return json(200, { ok: true });

    if (url.pathname === '/readyz') {
      const ready = state.results !== undefined;
      return json(ready ? 200 : 503, { ready, sweepAt: state.sweepAt ?? null });
    }

    if (url.pathname === '/metrics') {
      if (!state.results) {
        rs.writeHead(503, { 'content-type': 'text/plain; charset=utf-8' });
        rs.end('# no sweep has completed yet\n');
        return;
      }
      rs.writeHead(200, { 'content-type': 'text/plain; version=0.0.4; charset=utf-8' });
      rs.end(renderMetrics(state.results, state.sweepAt ?? Date.now()));
      return;
    }

    if (url.pathname === '/status') {
      if (!state.results) return json(503, { ready: false });
      return json(200, {
        verdict: worst(state.results),
        sweepAt: state.sweepAt ?? null,
        firing: state.firing ?? [],
        // Redacted again here, not only where checks build their detail: `/status` is
        // unauthenticated, and results can be written into `state` by code other than
        // `runChecks`.
        checks: state.results.map((r) => ({
          id: r.id, level: r.level, detail: redact(r.detail, opts.redactValues),
          value: r.value ?? null, threshold: r.threshold ?? null,
        })),
      });
    }

    return json(404, { error: 'not found', routes: ['/healthz', '/readyz', '/status', '/metrics'] });
  };

  const server = createServer(handle);
  return {
    server,
    listen: (port = 0, host?: string) => new Promise<number>((resolve) => {
      const done = () => {
        const a = server.address();
        resolve(typeof a === 'object' && a ? a.port : port);
      };
      if (host) server.listen(port, host, done);
      else server.listen(port, done);
    }),
    close: () => new Promise<void>((resolve) => server.close(() => resolve())),
  };
}
