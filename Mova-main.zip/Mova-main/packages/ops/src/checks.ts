/**
 * The invariants worth waking someone for.
 *
 * ## Three states, not two
 *
 * Every check returns `ok`, `warn`, `fail` - or `unknown`, which is the one that matters.
 * A check whose RPC call threw has not passed; it has failed to run. Collapsing that into
 * `ok` is how a dashboard stays green while the chain it watches is on fire, and it is the
 * exact mistake the Lido adapter avoids by refusing to price with a dead oracle. `unknown`
 * is therefore alertable in its own right, at a lower severity and a longer fuse: one
 * flaky RPC call is noise, five minutes of them is an outage.
 *
 * ## Thresholds are data
 *
 * Every bound lives in `Thresholds` rather than inside the logic, so the runbook can state
 * the number, the tests can drive it, and an operator can change it without a deploy. The
 * defaults below are derived from what the contracts themselves enforce - an alert that
 * fires later than the contract reverts is useless, so each one sits inside its on-chain
 * limit with room to act.
 */
import {
  BaseError, ContractFunctionRevertedError, ContractFunctionZeroDataError, hashTypedData, isAddressEqual,
  recoverTypedDataAddress, type Address, type Hex, type PublicClient,
} from 'viem';
import { redactError } from './redact.js';

export type Level = 'ok' | 'warn' | 'fail' | 'unknown';

export interface CheckResult {
  /** Stable id: used as the metric label and the alert key, so it must not drift. */
  id: string;
  level: Level;
  /** One line an operator can act on, naming the number that tripped it. */
  detail: string;
  /** Numeric reading, exported to Prometheus when present. */
  value?: number;
  /** What the reading was compared against, for the metric and the alert body. */
  threshold?: number;
}

export interface Thresholds {
  /**
   * Oracle freshness. The escrows reject a price older than the oracle's own `maxAge`, so
   * warn well before that: a stale feed halts new orders, which is a product outage even
   * though no funds are at risk. An oracle with FX market hours (PythFxOracle) is judged by
   * them - its rate grows old every night by design (see `oracleReading`).
   */
  oracleWarnSeconds: number;
  oracleFailSeconds: number;
  /**
   * ASP root age. A root that stops advancing does not stop withdrawals that are already
   * provable, but every NEW deposit becomes unwithdrawable-by-proof until it moves, and
   * users experience that as frozen funds. Ragequit remains, publicly.
   */
  aspRootWarnSeconds: number;
  aspRootFailSeconds: number;
  /** Gas floors. Below these the service stops being able to do its job. */
  relayerMinWei: bigint;
  paymasterMinWei: bigint;
  /**
   * SponsorPaymaster's stake at the EntryPoint. The paymaster reads its own storage and returns a context during
   * validation, which ERC-7562 allows only a staked paymaster (STO-031, EREP-050), so a bundler refuses every
   * sponsored operation unless it counts the paymaster as staked - and each bundler counts a stake only from its own
   * floor. Default 1 ETH (Rundler's default `min_stake_value`) and 86400 s (ERC-7562's MIN_UNSTAKE_DELAY).
   */
  paymasterMinStakeWei?: bigint;
  paymasterMinUnstakeDelaySeconds?: number;
  /**
   * Vault share price against its high-water mark, in basis points of drawdown. The vault
   * trips its own breaker at `maxDrawdownBps`; warn at half of it so someone is looking
   * before deposits stop.
   */
  vaultDrawdownWarnBps: number;
  /** Orders past their pay-by deadline still sitting in LOCKED, awaiting a keeper. */
  staleOrdersWarn: number;
  /** Warn when an escrow holds this share of a token's `assetCap`; at the cap it fails. */
  assetCapWarnPercent: number;
  /**
   * The Movva reserve's rate, by the `updatedAt` it returns. docs/movva.md gives the FX leg - PythFxOracle,
   * or a SignedPriceOracle - a 1h max age, past which the reserve reverts, and a revert is itself a fail.
   * Warn at half of it. While the FX market is closed the rate ages and refuses by design: see `movvaMarket`.
   */
  movvaRateWarnSeconds: number;
  movvaRateFailSeconds: number;
  /** A hedge statement older than this is stale: statements are daily, with two hours' grace. */
  movvaStatementMaxAgeSeconds: number;
  /** The desk's hedge policy band: a verified statement's hedge ratio outside it warns. */
  movvaHedgeBandBps: number;
  /** The adverse USD/BRL move `movva_withdraw_headroom` prices, in bps (the dollar UP). */
  movvaShockBps: number;
  /**
   * The reserve's 24h `withdrawToHedge` limit in bps of its USDT (the deployment default is 8%).
   * Fallback only: a reserve with `hedgeWithdrawable()` and `hedgeLimitBps()` is read instead, and a
   * configured value that disagrees with it is reported.
   */
  movvaWithdrawDailyLimitBps: number;
  /** Assumed B3 initial margin, bps of the short's notional: to confirm with the broker. */
  movvaInitialMarginBps: number;
  /** Assumed all-in USDT to BRL conversion cost, bps. */
  movvaConversionCostBps: number;
  /**
   * `pyth_keeper_gas:<address>`: a Pyth keeper replica's float for gas and Pyth's fee - the keeper's own
   * MIN_BALANCE_WEI. Warn below it, fail below half: a replica that cannot pay stops posting, and once none
   * can, PythFxOracle's rate is refused an hour after the last post.
   */
  pythKeeperMinWei: bigint;
  /**
   * `lp_node_caps`: how far the cap ledger's last write may lag behind the last BRL the node attributed to
   * a payer before the ledger counts as stuck. A healthy node writes the ledger in the same tick it
   * decides, so any real lag is a journal that could not be written or one replaced under the node.
   * Default 300 s, which is well inside one tick's poll interval.
   */
  lpNodeCapsStaleSeconds?: number;
  /** The SponsorGate operators' gas floor (`sponsor_operator_gas`). */
  sponsorOperatorMinWei?: bigint;
  /** Warn once operators have used this share of the gate's window (`sponsor_gate_budget`). */
  sponsorGateBudgetWarnPercent?: number;
  /**
   * `node_rewards_unclaimed`: how long an epoch may sit finalizable with nobody finalizing it. LP nodes with claiming on
   * finalize before they claim, so this is every node down, or claiming off. Default two days.
   */
  rewardsFinalizeWarnSeconds?: number;
  /** How long finalized LP rewards above the floor may sit with no LP claiming anything. Default 30 days. */
  rewardsUnclaimedWarnSeconds?: number;
  /** Rewards owed under this many centavos are not worth a notice. Default R$ 100,00. */
  rewardsUnclaimedFloorCents?: bigint;
}

export const DEFAULT_THRESHOLDS: Thresholds = {
  oracleWarnSeconds: 30 * 60,
  oracleFailSeconds: 2 * 60 * 60,
  aspRootWarnSeconds: 6 * 60 * 60,
  aspRootFailSeconds: 24 * 60 * 60,
  relayerMinWei: 20_000_000_000_000_000n, // 0.02 ETH
  paymasterMinWei: 50_000_000_000_000_000n, // 0.05 ETH
  paymasterMinStakeWei: 1_000_000_000_000_000_000n, // 1 ETH
  paymasterMinUnstakeDelaySeconds: 86_400,
  vaultDrawdownWarnBps: 250,
  staleOrdersWarn: 1,
  assetCapWarnPercent: 80,
  movvaRateWarnSeconds: 30 * 60,
  movvaRateFailSeconds: 60 * 60,
  movvaStatementMaxAgeSeconds: 26 * 60 * 60,
  movvaHedgeBandBps: 200,
  movvaShockBps: 500,
  movvaWithdrawDailyLimitBps: 800,
  movvaInitialMarginBps: 1_000,
  movvaConversionCostBps: 30,
  pythKeeperMinWei: 50_000_000_000_000_000n, // 0.05 ETH
  lpNodeCapsStaleSeconds: 300,
  sponsorOperatorMinWei: 20_000_000_000_000_000n, // 0.02 ETH
  sponsorGateBudgetWarnPercent: 80,
};

export interface MonitorTargets {
  client: PublicClient;
  /** Privacy Pools Entrypoint, for the ASP root. */
  entrypoint?: Address;
  /** The pool, for a root sanity read. */
  pool?: Address;
  /** BRL price oracle behind the escrows. */
  oracle?: Address;
  /** On-ramp escrow, for stuck orders. */
  escrow?: Address;
  /** Off-ramp escrow. Its asset oracles are checked alongside the on-ramp's. */
  offrampEscrow?: Address;
  /**
   * Settlement assets whose price band to check - native ETH is the zero address. Each asset's
   * oracle is read from the escrows' own `assets(asset)`, not configured here: the oracle that
   * matters is the one the escrow will call, and that can change through a scheduled
   * `setAsset`. One `asset_oracle:<asset>` check per asset.
   */
  assets?: Address[];
  /**
   * The USDT token, to watch the powers Tether holds over escrowed USDT - pause, a transfer
   * fee, the blacklist, deprecation. See SR2-22 to SR2-29 in docs/security-review-phase2.md.
   */
  usdt?: Address;
  /** 0xbow's USDT pool: blacklisting it freezes every shielded USDT note. */
  usdtPool?: Address;
  /**
   * The USDT yield vault and its adapters, for the same blacklist
   * watch (SR3-9). A blacklisted vault is the worst of these: every holder is frozen. It refuses
   * new deposits by itself, so the alert is for telling holders, not for stopping deposits.
   */
  usdtYield?: { vault?: Address; adapters?: Address[] };
  /** Yield vault, for drawdown and liquidity. */
  vault?: Address;
  /** Addresses that must keep a gas balance. */
  relayer?: Address;
  paymaster?: Address;
  /** ERC-4337 EntryPoint holding the paymaster's deposit. */
  aaEntrypoint?: Address;
  /**
   * The Pyth keeper's replica addresses (packages/yield `pyth-keeper`), one `pyth_keeper_gas:<address>` each.
   * Their keys hold no role; what runs out is the gas and fee float that keeps FX.USD/BRL posted.
   */
  pythKeepers?: Address[];
  /**
   * An LP node this deployment expects to be enforcing per-payer caps (packages/lp-node caps.ts).
   * `caps` reads its `/status` - `lpNodeCapsLoader(url)` - and enables `lp_node_caps`. Configure it only
   * for a node whose operator HAS configured caps: a node without them is a policy choice, not a fault,
   * and the check is here to catch a node that was meant to be capping and is not.
   */
  lpNode?: { name?: string; caps: () => Promise<LpNodeCapsReading> };
  /**
   * The SponsorGate that owns SponsorPaymaster (contracts/SponsorGate.sol), and the operator keys co-signers sponsor
   * from. `gate` enables `sponsor_gate_budget`; each operator, `sponsor_operator_gas:<address>`.
   */
  sponsorGate?: { gate: Address; operators?: Address[] };
  /**
   * Unix seconds of the last ASP root post, if the caller tracks it.
   *
   * The Entrypoint stores the root but no timestamp for it, so freshness cannot be read
   * from the contract - it has to come from watching the postman's transactions. Supplying
   * this turns `asp_root_age` from "a root exists" into a real staleness check; omitting it
   * leaves the weaker check rather than inventing a number.
   */
  lastRootPostedAt?: () => number | undefined;
  /**
   * The Movva reserve (contracts/movva/IMovvaReserve.sol). Enables `movva_collateral_ratio`,
   * `movva_rate` and `movva_withdraw_headroom`; with `statement`, also
   * `movva_hedge_statement`.
   */
  movva?: MovvaTargets;
  /**
   * Node-provider rewards (contracts/ramp/NodeRewards.sol) and, optionally, the FeeSplitter that funds it. Enables
   * `node_rewards_balance`, `node_rewards_unclaimed` and `node_rewards_wiring`.
   */
  rewards?: RewardsTargets;
  /**
   * Values that must never appear in a check's detail - RPC_URL and ALERT_WEBHOOK. A check
   * detail is served on the unauthenticated `/status` and posted to the webhook, and viem
   * puts the RPC URL, API key included, into every transport error.
   */
  redactValues?: readonly (string | undefined)[];
}

const ORACLE_ABI = [
  {
    type: 'function', name: 'brlCentsPerUnit', stateMutability: 'view', inputs: [],
    outputs: [{ name: 'price', type: 'uint256' }, { name: 'updatedAt', type: 'uint64' }],
  },
  // The refusals of the oracles in contracts/ramp, so a revert names its cause. BadPrice has the
  // same signature on ChainlinkBrlOracle and ChainlinkSignedFxOracle.
  { type: 'error', name: 'StaleLeg', inputs: [{ name: 'leg', type: 'address' }, { name: 'updatedAt', type: 'uint256' }] },
  { type: 'error', name: 'LegFromFuture', inputs: [{ name: 'leg', type: 'address' }, { name: 'updatedAt', type: 'uint256' }] },
  { type: 'error', name: 'BadPrice', inputs: [{ name: 'leg', type: 'address' }, { name: 'answer', type: 'int256' }] },
  { type: 'error', name: 'FeedDecimalsOutOfRange', inputs: [{ name: 'feed', type: 'address' }, { name: 'decimals', type: 'uint8' }] },
  { type: 'error', name: 'PriceRoundsToZero', inputs: [] },
  { type: 'error', name: 'NoPriceYet', inputs: [] },
  // An oracle whose governor can still change it instantly refuses to price (DelayedGovernance setup).
  { type: 'error', name: 'SetupIncomplete', inputs: [] },
  { type: 'error', name: 'StalePrice', inputs: [{ name: 'feed', type: 'address' }, { name: 'updatedAt', type: 'uint256' }] },
  // PythFxOracle's refusals - StaleRate is also every night's closed market - and Pyth's own for a feed
  // never posted on this chain. BadPrice(int64) is PythFxOracle's; the two BadPrice differ by selector.
  { type: 'error', name: 'StaleRate', inputs: [{ name: 'publishTime', type: 'uint256' }] },
  { type: 'error', name: 'BadPrice', inputs: [{ name: 'price', type: 'int64' }] },
  { type: 'error', name: 'ExponentOutOfRange', inputs: [{ name: 'expo', type: 'int32' }] },
  { type: 'error', name: 'ConfidenceTooWide', inputs: [{ name: 'conf', type: 'uint64' }, { name: 'price', type: 'int64' }] },
  { type: 'error', name: 'PriceFromFuture', inputs: [{ name: 'publishTime', type: 'uint256' }] },
  { type: 'error', name: 'PriceFeedNotFound', inputs: [] },
] as const;

/** PythFxOracle's band reading and market hours: asked only of an oracle whose rate is old or refused. */
const MARKET_HOURS_ABI = [
  {
    type: 'function', name: 'brlCentsPerUnitForBand', stateMutability: 'view', inputs: [],
    outputs: [{ name: 'price', type: 'uint256' }, { name: 'updatedAt', type: 'uint64' }],
  },
  { type: 'function', name: 'inCoreSession', stateMutability: 'view', inputs: [], outputs: [{ type: 'bool' }] },
  ...ORACLE_ABI.filter((x) => x.type === 'error'),
] as const;

const ESCROW_ASSETS_ABI = [{
  type: 'function', name: 'assets', stateMutability: 'view',
  inputs: [{ name: 'asset', type: 'address' }],
  outputs: [{ name: 'oracle', type: 'address' }, { name: 'decimals', type: 'uint8' }, { name: 'enabled', type: 'bool' }],
}] as const;

const ESCROW_CAP_ABI = [
  { type: 'function', name: 'assetCap', stateMutability: 'view', inputs: [{ name: 'asset', type: 'address' }], outputs: [{ type: 'uint256' }] },
  { type: 'function', name: 'balanceOf', stateMutability: 'view', inputs: [{ name: 'who', type: 'address' }], outputs: [{ type: 'uint256' }] },
] as const;

const TETHER_ABI = [
  { type: 'function', name: 'paused', stateMutability: 'view', inputs: [], outputs: [{ type: 'bool' }] },
  { type: 'function', name: 'basisPointsRate', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint256' }] },
  { type: 'function', name: 'maximumFee', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint256' }] },
  { type: 'function', name: 'deprecated', stateMutability: 'view', inputs: [], outputs: [{ type: 'bool' }] },
  { type: 'function', name: 'upgradedAddress', stateMutability: 'view', inputs: [], outputs: [{ type: 'address' }] },
  {
    type: 'function', name: 'isBlackListed', stateMutability: 'view',
    inputs: [{ type: 'address' }], outputs: [{ type: 'bool' }],
  },
] as const;

/**
 * The contract itself refused, as opposed to the read failing. For an oracle that is not
 * `unknown`: the escrows make the same call before every offer, order and sale, so a refusal
 * here means trading in that asset has stopped.
 */
function revertOf(e: unknown): { reason: string } | undefined {
  if (!(e instanceof BaseError)) return undefined;
  const r = e.walk((x) => x instanceof ContractFunctionRevertedError);
  if (!(r instanceof ContractFunctionRevertedError)) return undefined;
  const d = r.data;
  const reason = d ? `${d.errorName}(${(d.args ?? []).map(String).join(', ')})` : (r.reason ?? 'no reason');
  return { reason };
}

const ENTRYPOINT_ABI = [{
  type: 'function', name: 'latestRoot', stateMutability: 'view', inputs: [],
  outputs: [{ type: 'uint256' }],
}] as const;

const POOL_ABI = [{
  type: 'function', name: 'currentRoot', stateMutability: 'view', inputs: [],
  outputs: [{ type: 'uint256' }],
}] as const;

const VAULT_ABI = [
  { type: 'function', name: 'assetsPerShare', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint256' }] },
  { type: 'function', name: 'highWaterAssetsPerShare', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint256' }] },
  { type: 'function', name: 'depositsPaused', stateMutability: 'view', inputs: [], outputs: [{ type: 'bool' }] },
  { type: 'function', name: 'totalAssets', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint256' }] },
  { type: 'function', name: 'liquidAssets', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint256' }] },
] as const;

const AA_ABI = [{
  type: 'function', name: 'balanceOf', stateMutability: 'view',
  inputs: [{ name: 'account', type: 'address' }], outputs: [{ type: 'uint256' }],
}, {
  type: 'function', name: 'getDepositInfo', stateMutability: 'view',
  inputs: [{ name: 'account', type: 'address' }],
  outputs: [{
    name: 'info', type: 'tuple', components: [
      { name: 'deposit', type: 'uint256' }, { name: 'staked', type: 'bool' }, { name: 'stake', type: 'uint112' },
      { name: 'unstakeDelaySec', type: 'uint32' }, { name: 'withdrawTime', type: 'uint48' },
    ],
  }],
}] as const;

/**
 * Run a reader and turn any throw into `unknown` rather than letting it kill the sweep.
 *
 * The error text is redacted here, where it enters a result, as well as at every place a
 * result leaves the process: this is the one spot every failed read passes through.
 */
async function attemptRedacted(
  id: string,
  fn: () => Promise<CheckResult>,
  secrets: readonly (string | undefined)[] = [],
): Promise<CheckResult> {
  try {
    return await fn();
  } catch (e) {
    return { id, level: 'unknown', detail: `could not be read: ${redactError(e, secrets)}` };
  }
}

const ETH = (wei: bigint) => Number(wei) / 1e18;

const ZERO = '0x0000000000000000000000000000000000000000';

/** The contract answered - reverted, or has no such function - as opposed to the read failing. */
const refusedByContract = (e: unknown) => e instanceof BaseError
  && !!e.walk((x) => x instanceof ContractFunctionRevertedError || x instanceof ContractFunctionZeroDataError);

/**
 * `inCoreSession()` on a price source: whether the chain's clock is inside FxMarketHours' core session
 * (13:30-21:00 UTC, weekdays, not 25 December or 1 January), or undefined for a source without market
 * hours - a SignedPriceOracle, a cross, a reserve. A read that failed throws, for `unknown`.
 */
async function coreSessionOf(client: PublicClient, source: Address): Promise<boolean | undefined> {
  try {
    return await client.readContract({ address: source, abi: MARKET_HOURS_ABI, functionName: 'inCoreSession' }) as boolean;
  } catch (e) {
    if (refusedByContract(e)) return undefined;
    throw e;
  }
}

/**
 * Age of one oracle's price against the freshness thresholds; a refusal is `fail`.
 *
 * ## An oracle with market hours
 *
 * PythFxOracle's rate is Pyth's FX.USD/BRL, which trades weekdays 08:00-17:00 New York time. Every weekday
 * night and every weekend its `brlCentsPerUnit` grows old and then refuses (`StaleRate`) by design, while its
 * band reading serves the last close. A monitor that paged on that would page every night. So when a rate is
 * old or refused, an oracle answering `inCoreSession()` is judged by the session:
 *
 *  - inside the core session the market is certainly trading: an old rate warns and fails and a refusal fails,
 *    as for any oracle. The Pyth keeper is down or behind;
 *  - outside it, `brlCentsPerUnitForBand` decides. Pricing: the market is closed and the bands trade on the last
 *    close until the reopening - `ok`, `closed`, and the detail says so. Refusing: the last close is past
 *    `closedMaxAge`, or unusable, and the bands have stopped too - `fail`.
 *
 * Outside the core session a keeper that died while the market was still open (12:00-13:30 UTC in summer,
 * 21:00-22:00 UTC in winter) looks exactly like the close. The contract accepts the same ambiguity
 * (FxMarketHours), the bands keep only a close no older than `closedMaxAge`, and the first sweep inside the
 * core session reports it.
 */
async function oracleReading(
  client: PublicClient, oracle: Address, th: Thresholds, nowSeconds: number,
): Promise<{ level: Level; age?: number; note: string; closed?: boolean }> {
  let updatedAt: bigint | undefined;
  let refusal: string | undefined;
  try {
    [, updatedAt] = await client.readContract({
      address: oracle, abi: ORACLE_ABI, functionName: 'brlCentsPerUnit',
    }) as readonly [bigint, bigint];
  } catch (e) {
    const r = revertOf(e);
    if (!r) throw e; // the read failed, not the oracle: `unknown`, from the caller's wrapper
    refusal = r.reason;
  }
  const age = updatedAt === undefined ? undefined : nowSeconds - Number(updatedAt);
  const level: Level = age === undefined || age >= th.oracleFailSeconds ? 'fail' : age >= th.oracleWarnSeconds ? 'warn' : 'ok';
  const plain = refusal !== undefined ? `oracle ${oracle} refuses to price: ${refusal}` : `oracle ${oracle} price is ${age}s old`;
  if (level === 'ok') return { level, age, note: plain };

  const session = await coreSessionOf(client, oracle);
  if (session === undefined) {
    // A cross over a PythFxOracle bubbles its StaleRate up without market hours of its own.
    const hint = refusal?.startsWith('StaleRate(') ? '; StaleRate is PythFxOracle\'s refusal: inside the core session the Pyth keeper is down or behind, check its /status' : '';
    return { level, age, note: `${plain}${hint}` };
  }
  if (session) return { level, age, note: `${plain}, inside the FX market's core session: the Pyth keeper is down or behind, check its /status` };
  try {
    const [, bandAt] = await client.readContract({ address: oracle, abi: MARKET_HOURS_ABI, functionName: 'brlCentsPerUnitForBand' }) as readonly [bigint, bigint];
    return {
      level: 'ok', age, closed: true,
      note: `oracle ${oracle}: the FX market is closed - its rate ${refusal !== undefined ? `is refused (${refusal})` : `is ${age}s old`}, `
        + `and the bands trade on the last close until the reopening (band reading stamped ${Math.max(0, nowSeconds - Number(bandAt))}s ago)`,
    };
  } catch (e) {
    const r = revertOf(e);
    if (!r) throw e;
    return {
      level: 'fail', age,
      note: `oracle ${oracle} refuses to price even as a band outside the core session (${r.reason}): the last close is past `
        + 'closedMaxAge or unusable, so the bands have stopped too',
    };
  }
}

/** The Brasília calendar day of a unix time (UTC-3, no daylight saving since 2019) - the day LP caps count in. */
const brasiliaDayOf = (seconds: number): string => new Date((seconds - 3 * 3600) * 1000).toISOString().slice(0, 10);

const RANK: Level[] = ['ok', 'unknown', 'warn', 'fail'];
const worse = (a: Level, b: Level): Level => (RANK.indexOf(b) > RANK.indexOf(a) ? b : a);

/**
 * Read every configured target once. Targets left undefined are skipped rather than
 * reported, so one deployment's monitor does not invent failures about contracts another
 * deployment has.
 */
export async function runChecks(
  t: MonitorTargets,
  th: Thresholds = DEFAULT_THRESHOLDS,
  nowSeconds: number = Math.floor(Date.now() / 1000),
): Promise<CheckResult[]> {
  const out: Promise<CheckResult>[] = [];
  const attempt = (id: string, fn: () => Promise<CheckResult>) =>
    attemptRedacted(id, fn, t.redactValues);

  if (t.oracle) {
    const oracle = t.oracle;
    out.push(attempt('oracle_freshness', async () => {
      const r = await oracleReading(t.client, oracle, th, nowSeconds);
      if (r.closed) return { id: 'oracle_freshness', level: 'ok', value: r.age, threshold: th.oracleWarnSeconds, detail: r.note };
      if (r.age === undefined) {
        return { id: 'oracle_freshness', level: r.level, detail: `${r.note}; new orders are refused` };
      }
      const age = r.age;
      return {
        id: 'oracle_freshness', level: r.level, value: age, threshold: th.oracleWarnSeconds,
        detail: r.level === 'ok'
          ? `BRL price is ${age}s old`
          : `${r.note}; new orders halt once the escrow's own maxAge passes`,
      };
    }));
  }

  // Every listed asset's band, through the oracle each escrow has configured for it.
  const escrows = [t.escrow, t.offrampEscrow].filter((a): a is Address => a !== undefined);
  for (const asset of escrows.length ? t.assets ?? [] : []) {
    const id = `asset_oracle:${asset.toLowerCase()}`;
    const name = asset.toLowerCase() === ZERO ? 'ETH' : asset;
    out.push(attempt(id, async () => {
      let level: Level = 'ok';
      let oldest: number | undefined;
      const notes: string[] = [];
      const seen = new Map<string, Awaited<ReturnType<typeof oracleReading>>>();
      for (const escrow of escrows) {
        const [oracle,, enabled] = await t.client.readContract({
          address: escrow, abi: ESCROW_ASSETS_ABI, functionName: 'assets', args: [asset],
        }) as readonly [Address, number, boolean];
        if (oracle === ZERO || !enabled) {
          // Not an outage of this asset's price, but a monitored asset nobody can trade on this
          // escrow is a configuration an operator should know about.
          level = worse(level, 'warn');
          notes.push(`${name} is ${oracle === ZERO ? 'not listed' : 'delisted'} on escrow ${escrow}`);
          continue;
        }
        const key = oracle.toLowerCase();
        if (seen.has(key)) continue; // both escrows normally share one oracle: read and report it once
        const r = await oracleReading(t.client, oracle, th, nowSeconds);
        seen.set(key, r);
        level = worse(level, r.level);
        if (r.age !== undefined) oldest = Math.max(oldest ?? 0, r.age);
        if (r.level !== 'ok' || r.closed) notes.push(r.note);
      }
      if (seen.size > 1) {
        // Legitimate mid-migration (setAsset is scheduled per escrow), but never silently.
        level = worse(level, 'warn');
        notes.push(`the escrows use different oracles for ${name}: ${[...seen.keys()].join(', ')}`);
      }
      return {
        id, level, value: oldest, threshold: th.oracleWarnSeconds,
        detail: level === 'ok'
          ? `${name} price is ${oldest === undefined ? 'refused as a rate' : `${oldest}s old`}${notes.length ? `; ${notes.join('; ')}` : ''}`
          : `${name}: ${notes.join('; ')}. Offers, orders and sales in ${name} halt while its oracle refuses or passes the escrow's price age`,
      };
    }));
  }

  // How close each escrow is to the most it may hold of each token (`assetCap`, SR2-25). At the cap
  // the escrow refuses new offers and sales in that token, which looks to LPs like an outage.
  for (const asset of escrows.length ? (t.assets ?? []).filter((a) => a.toLowerCase() !== ZERO) : []) {
    const id = `asset_cap:${asset.toLowerCase()}`;
    out.push(attempt(id, async () => {
      let level: Level = 'ok';
      let fullest = 0;
      const notes: string[] = [];
      for (const escrow of escrows) {
        const [cap, held] = await Promise.all([
          t.client.readContract({ address: escrow, abi: ESCROW_CAP_ABI, functionName: 'assetCap', args: [asset] }) as Promise<bigint>,
          t.client.readContract({ address: asset, abi: ESCROW_CAP_ABI, functionName: 'balanceOf', args: [escrow] }) as Promise<bigint>,
        ]);
        if (cap === 0n) {
          notes.push(`escrow ${escrow} has no cap`);
          continue;
        }
        const pct = Number((held * 10_000n) / cap) / 100;
        fullest = Math.max(fullest, pct);
        if (held >= cap) {
          level = worse(level, 'fail');
          notes.push(`escrow ${escrow} is AT its cap (${held} of ${cap}): new offers and sales in ${asset} are refused`);
        } else if (pct >= th.assetCapWarnPercent) {
          level = worse(level, 'warn');
          notes.push(`escrow ${escrow} holds ${pct}% of its cap`);
        }
      }
      return {
        id, level, value: fullest, threshold: th.assetCapWarnPercent,
        detail: level === 'ok'
          ? `${asset}: fullest escrow at ${fullest}% of its cap${notes.length ? `; ${notes.join('; ')}` : ''}`
          : `${asset}: ${notes.join('; ')}. Raising a cap waits out the governance delay; lowering it does not`,
      };
    }));
  }

  if (t.usdt) {
    const usdt = t.usdt;
    out.push(attempt('usdt_state', async () => {
      const read = <T>(functionName: 'paused' | 'basisPointsRate' | 'maximumFee' | 'deprecated' | 'upgradedAddress') =>
        t.client.readContract({ address: usdt, abi: TETHER_ABI, functionName }) as Promise<T>;
      const listed = (who: Address) =>
        t.client.readContract({ address: usdt, abi: TETHER_ABI, functionName: 'isBlackListed', args: [who] }) as Promise<boolean>;
      const [paused, bps, maxFee, deprecated] = await Promise.all([
        read<boolean>('paused'), read<bigint>('basisPointsRate'), read<bigint>('maximumFee'), read<boolean>('deprecated'),
      ]);
      const issues: string[] = [];
      if (paused) issues.push('USDT is PAUSED: no USDT moves into or out of either escrow; paid orders need a dispute to survive it');
      if (bps > 0n) {
        issues.push(`USDT transfer fee is ON (${bps} bps, max ${maxFee}): new USDT offers and sales are refused, `
          + 'payouts arrive short by the fee, shielded USDT delivery cannot settle');
      }
      if (deprecated) {
        issues.push(`USDT is DEPRECATED to ${await read<Address>('upgradedAddress')}: escrowed USDT now behaves as that contract does`);
      }
      const consequence: Record<string, string> = {
        'on-ramp escrow': 'every USDT position on it is frozen and can be destroyed',
        'off-ramp escrow': 'every USDT position on it is frozen and can be destroyed',
        'Privacy Pools entrypoint': 'shielded USDT delivery cannot settle',
        'USDT pool': 'every shielded USDT note is frozen, ragequit included',
        'USDT yield vault': 'every holder is frozen; the vault refuses new deposits by itself. Tell holders',
        'USDT yield adapter': 'allocations to it revert; exits still pay out. Deactivate it (admin vault:adapter)',
      };
      const y = t.usdtYield ?? {};
      const watched: [string, Address | undefined][] = [
        ['on-ramp escrow', t.escrow], ['off-ramp escrow', t.offrampEscrow],
        ['Privacy Pools entrypoint', t.entrypoint], ['USDT pool', t.usdtPool],
        ['USDT yield vault', y.vault], ...(y.adapters ?? []).map((a): [string, Address] => ['USDT yield adapter', a]),
      ];
      for (const [label, who] of watched) {
        if (who && await listed(who)) issues.push(`Tether has BLACKLISTED the ${label} ${who}: ${consequence[label]}`);
      }
      return {
        id: 'usdt_state', level: issues.length ? 'fail' : 'ok', value: issues.length, threshold: 0,
        detail: issues.length ? issues.join('; ') : 'USDT unpaused, no transfer fee, not deprecated, nothing we depend on blacklisted',
      };
    }));
  }

  if (t.entrypoint) {
    const entrypoint = t.entrypoint;
    out.push(attempt('asp_root_age', async () => {
      const root = await t.client.readContract({
        address: entrypoint, abi: ENTRYPOINT_ABI, functionName: 'latestRoot',
      }) as bigint;
      if (root === 0n) {
        return {
          id: 'asp_root_age', level: 'fail',
          detail: 'no ASP root has ever been posted; private withdrawal cannot work',
        };
      }
      // The Entrypoint stores no timestamp per root, so freshness comes from the postman's
      // last transaction rather than from the contract. Reported by the caller via
      // `lastRootPostedAt`; without it we can only confirm a root exists.
      const at = t.lastRootPostedAt?.();
      if (at === undefined) {
        return { id: 'asp_root_age', level: 'ok', detail: `ASP root set (age not tracked)` };
      }
      const age = nowSeconds - at;
      const level: Level = age >= th.aspRootFailSeconds ? 'fail'
        : age >= th.aspRootWarnSeconds ? 'warn' : 'ok';
      return {
        id: 'asp_root_age', level, value: age, threshold: th.aspRootWarnSeconds,
        detail: level === 'ok'
          ? `ASP root posted ${age}s ago`
          : `ASP root posted ${age}s ago; deposits since then cannot be withdrawn by proof`,
      };
    }));
  }

  if (t.pool) {
    const pool = t.pool;
    out.push(attempt('pool_reachable', async () => {
      const root = await t.client.readContract({
        address: pool, abi: POOL_ABI, functionName: 'currentRoot',
      }) as bigint;
      return {
        id: 'pool_reachable',
        level: root === 0n ? 'warn' : 'ok',
        detail: root === 0n ? 'pool tree is empty' : 'pool responding',
      };
    }));
  }

  if (t.relayer) {
    const relayer = t.relayer;
    out.push(attempt('relayer_gas', async () => {
      const bal = await t.client.getBalance({ address: relayer });
      const level: Level = bal < th.relayerMinWei / 2n ? 'fail'
        : bal < th.relayerMinWei ? 'warn' : 'ok';
      return {
        id: 'relayer_gas', level, value: ETH(bal), threshold: ETH(th.relayerMinWei),
        detail: level === 'ok'
          ? `relayer holds ${ETH(bal).toFixed(4)} ETH`
          : `relayer holds ${ETH(bal).toFixed(4)} ETH; below this it stops relaying and users must self-submit`,
      };
    }));
  }

  if (t.paymaster && t.aaEntrypoint) {
    const paymaster = t.paymaster;
    const aa = t.aaEntrypoint;
    out.push(attempt('paymaster_deposit', async () => {
      const bal = await t.client.readContract({
        address: aa, abi: AA_ABI, functionName: 'balanceOf', args: [paymaster],
      }) as bigint;
      const level: Level = bal < th.paymasterMinWei / 2n ? 'fail'
        : bal < th.paymasterMinWei ? 'warn' : 'ok';
      return {
        id: 'paymaster_deposit', level, value: ETH(bal), threshold: ETH(th.paymasterMinWei),
        detail: level === 'ok'
          ? `paymaster deposit ${ETH(bal).toFixed(4)} ETH`
          : `paymaster deposit ${ETH(bal).toFixed(4)} ETH; gasless onboarding stops when it empties`,
      };
    }));

    // The deposit pays the gas; the stake is what lets a bundler accept the paymaster's operations at all. An
    // unlocked stake (`unlockStake`) counts as none from that block on, even before it can be withdrawn.
    out.push(attempt('paymaster_stake', async () => {
      const info = await t.client.readContract({
        address: aa, abi: AA_ABI, functionName: 'getDepositInfo', args: [paymaster],
      }) as { staked: boolean; stake: bigint; unstakeDelaySec: number | bigint; withdrawTime: number | bigint };
      const minStake = th.paymasterMinStakeWei ?? DEFAULT_THRESHOLDS.paymasterMinStakeWei!;
      const minDelay = th.paymasterMinUnstakeDelaySeconds ?? DEFAULT_THRESHOLDS.paymasterMinUnstakeDelaySeconds!;
      const stake = BigInt(info.stake);
      const delay = Number(info.unstakeDelaySec);
      const withdrawTime = Number(info.withdrawTime);
      const problems: string[] = [];
      if (!info.staked) {
        problems.push(withdrawTime > 0
          ? `stake is unlocked (withdrawable from ${new Date(withdrawTime * 1000).toISOString()})`
          : 'is not staked');
      } else {
        if (stake < minStake) problems.push(`stake ${ETH(stake).toFixed(4)} ETH is under ${ETH(minStake).toFixed(4)} ETH`);
        if (delay < minDelay) problems.push(`unstake delay ${delay} s is under ${minDelay} s`);
      }
      const level: Level = problems.length > 0 ? 'fail' : 'ok';
      return {
        id: 'paymaster_stake', level, value: ETH(stake), threshold: ETH(minStake),
        detail: level === 'ok'
          ? `paymaster staked ${ETH(stake).toFixed(4)} ETH, unstake delay ${delay} s`
          : `paymaster ${problems.join('; ')}: bundlers enforcing ERC-7562 refuse every sponsored operation. `
            + 'Stake it with admin paymaster:add-stake (docs/runbook-mainnet-deploy.md, 3c)',
      };
    }));
  }

  for (const keeper of t.pythKeepers ?? []) {
    const id = `pyth_keeper_gas:${keeper.toLowerCase()}`;
    out.push(attempt(id, async () => {
      const bal = await t.client.getBalance({ address: keeper });
      const level: Level = bal < th.pythKeeperMinWei / 2n ? 'fail' : bal < th.pythKeeperMinWei ? 'warn' : 'ok';
      return {
        id, level, value: ETH(bal), threshold: ETH(th.pythKeeperMinWei),
        detail: level === 'ok'
          ? `Pyth keeper ${keeper} holds ${ETH(bal).toFixed(4)} ETH`
          : `Pyth keeper ${keeper} holds ${ETH(bal).toFixed(4)} ETH: fund it. A replica that cannot pay gas and Pyth's fee stops posting `
            + 'FX.USD/BRL; the others post on their turns, and once none can, PythFxOracle\'s rate is refused an hour after the last post',
      };
    }));
  }

  if (t.lpNode?.caps) {
    const lp = t.lpNode;
    const who = lp.name ? `LP node ${lp.name}` : 'the LP node';
    const stale = th.lpNodeCapsStaleSeconds ?? DEFAULT_THRESHOLDS.lpNodeCapsStaleSeconds!;
    out.push(attempt('lp_node_caps', async () => {
      const c = await lp.caps();
      if (!c.enabled) {
        return {
          id: 'lp_node_caps', level: 'fail', value: 0, threshold: 1,
          detail: `${who} is running with no per-payer caps: its /status reports none. It was configured to enforce `
            + 'them (MVP Scope Rev. 2 §10.1), so either the caps section is gone from its LP_CONFIG or it is not the node '
            + 'the monitor thinks it is. Until it is back, this LP applies no daily or monthly limit to anyone',
        };
      }
      // The node counts into Brasília days; a node whose clock or zone disagrees resets its limits at the
      // wrong hour, which is a real cap failure and not a cosmetic one.
      const today = brasiliaDayOf(nowSeconds);
      if (c.day !== today) {
        return {
          id: 'lp_node_caps', level: 'fail', value: 0, threshold: 1,
          detail: `${who} is counting caps into the Brasília day ${c.day}, and it is ${today}: its clock or timezone is `
            + 'wrong, so every daily limit resets at the wrong moment. Fix the node\'s clock',
        };
      }
      // The ledger is written in the same tick the decision is taken, so any real lag is a journal that
      // could not be written, or one replaced under a running node.
      const behind = c.lastMoneyAt !== undefined ? c.lastMoneyAt - (c.lastCountAt ?? 0) : 0;
      if (c.lastMoneyAt !== undefined && behind > stale) {
        return {
          id: 'lp_node_caps', level: 'fail', value: behind, threshold: stale,
          detail: `${who} attributed BRL to a payer ${behind}s more recently than its cap ledger was last written `
            + `(${c.rows} rows): the ledger is stuck or was replaced, and a payer's limit is being counted against a total `
            + 'that is not growing. Check STATE_FILE is writable and is the journal the node has been running on',
        };
      }
      if (!c.limiting) {
        return {
          id: 'lp_node_caps', level: 'warn', value: c.rows, threshold: 0,
          detail: `${who} keeps a cap ledger (${c.rows} rows) but no tier states a limit, so nothing is ever refused. `
            + 'Set the numbers in config.caps.tiers',
        };
      }
      return {
        id: 'lp_node_caps', level: 'ok', value: c.rows, threshold: 0,
        detail: `${who} is accounting per-payer caps for ${today}: ${c.rows} ledger rows, unattributable payments `
          + `${c.unknownPayer === 'allow' ? 'allowed and uncounted' : 'refused'}`,
      };
    }));
  }

  if (t.vault) {
    const vault = t.vault;
    out.push(attempt('vault_drawdown', async () => {
      const [price, high, paused] = await Promise.all([
        t.client.readContract({ address: vault, abi: VAULT_ABI, functionName: 'assetsPerShare' }) as Promise<bigint>,
        t.client.readContract({ address: vault, abi: VAULT_ABI, functionName: 'highWaterAssetsPerShare' }) as Promise<bigint>,
        t.client.readContract({ address: vault, abi: VAULT_ABI, functionName: 'depositsPaused' }) as Promise<boolean>,
      ]);
      if (paused) {
        return {
          id: 'vault_drawdown', level: 'fail', value: 0,
          detail: 'vault deposits are PAUSED: the drawdown breaker has tripped. Withdrawals stay open; only the governor can resume',
        };
      }
      if (high === 0n) return { id: 'vault_drawdown', level: 'ok', detail: 'vault has no high-water mark yet' };
      const downBps = price >= high ? 0 : Number(((high - price) * 10_000n) / high);
      const level: Level = downBps >= th.vaultDrawdownWarnBps ? 'warn' : 'ok';
      return {
        id: 'vault_drawdown', level, value: downBps, threshold: th.vaultDrawdownWarnBps,
        detail: level === 'ok'
          ? `vault share price is ${downBps} bps below its high-water mark`
          : `vault share price is ${downBps} bps below high-water; the breaker pauses deposits at the configured max`,
      };
    }));

    out.push(attempt('vault_liquidity', async () => {
      const [total, liquid] = await Promise.all([
        t.client.readContract({ address: vault, abi: VAULT_ABI, functionName: 'totalAssets' }) as Promise<bigint>,
        t.client.readContract({ address: vault, abi: VAULT_ABI, functionName: 'liquidAssets' }) as Promise<bigint>,
      ]);
      if (total === 0n) return { id: 'vault_liquidity', level: 'ok', detail: 'vault is empty' };
      const pct = Number((liquid * 100n) / total);
      return {
        id: 'vault_liquidity', level: pct < 10 ? 'warn' : 'ok', value: pct, threshold: 10,
        detail: `${pct}% of vault assets can be withdrawn immediately`,
      };
    }));
  }

  if (t.sponsorGate) out.push(...sponsorGateChecks(t, t.sponsorGate, th, nowSeconds, attempt));
  if (t.movva) out.push(...movvaChecks(t, t.movva, th, nowSeconds, attempt));
  if (t.rewards) out.push(...rewardsChecks(t, t.rewards, th, nowSeconds, attempt));

  return Promise.all(out);
}

/*//////////////////////////////////////////////////////////////
                         NODE-PROVIDER REWARDS
//////////////////////////////////////////////////////////////*/

export interface RewardsTargets {
  /** NodeRewards. */
  contract: Address;
  /** The FeeSplitter that funds it: the reserve's fee recipient. */
  splitter?: Address;
}

export const DEFAULT_REWARDS_THRESHOLDS = {
  rewardsFinalizeWarnSeconds: 2 * 24 * 60 * 60,
  rewardsUnclaimedWarnSeconds: 30 * 24 * 60 * 60,
  rewardsUnclaimedFloorCents: 10_000n,
} as const;

const view = (name: string, type: string, inputs: { name: string; type: string }[] = []) =>
  ({ type: 'function', name, stateMutability: 'view', inputs, outputs: [{ type }] }) as const;

/** What the rewards checks read of NodeRewards, transcribed from contracts/ramp/NodeRewards.sol. */
export const NODE_REWARDS_MONITOR_ABI = [
  view('REWARD_TOKEN', 'address'), view('TOKEN_PER_CENT', 'uint256'), view('registry', 'address'), view('accounted', 'uint256'),
  view('outstanding', 'uint256'), view('carry', 'uint256'), view('totalFunded', 'uint256'), view('nextToFinalize', 'uint256'),
  view('finalizableEpochs', 'uint256'), view('lastClaimAt', 'uint64'), view('finalizableAt', 'uint256', [{ name: 'epoch', type: 'uint256' }]),
] as const;

/** What they read of FeeSplitter, transcribed from contracts/movva/FeeSplitter.sol. */
export const FEE_SPLITTER_MONITOR_ABI = [
  view('TOKEN', 'address'), view('rewards', 'address'), view('treasury', 'address'), view('lpRewardShareBps', 'uint16'),
] as const;

const BALANCE_OF_ABI = [view('balanceOf', 'uint256', [{ name: 'who', type: 'address' }])] as const;

/** Centavos as reais, the way the rest of the monitor writes them: R$ 1234,56. */
const reais = (cents: bigint) => `R$ ${cents / 100n},${String(cents % 100n).padStart(2, '0')}`;

/**
 * Three things can go wrong with node-provider rewards that nobody on-chain notices by themselves:
 *
 *  - **The pool is short of what it owes** (`node_rewards_balance`, fail). Nothing but a claim moves tokens out of
 *    NodeRewards, so this is the reward token itself - a fee switched on, a freeze, a rebase - and every claim will
 *    revert until it is understood.
 *  - **Rewards are not reaching LPs** (`node_rewards_unclaimed`, warn). An epoch nobody finalizes long after its review
 *    ended, or rewards owed while no LP has claimed for weeks: the LPs' nodes are down or have claiming off. Nothing
 *    expires, so this is a notice, not a loss.
 *  - **Settlements are not counted, or fees do not arrive** (`node_rewards_wiring`, warn). No registry bound while there
 *    is something to share, or a splitter that funds another contract or splits another token.
 *
 * What it does not watch: whether an LP's volume is genuine. Self-dealing within the caps is SR2-36's residual risk,
 * found off-chain - an LP taking its own offers shows as one taker settling with one LP - and answered with
 * rewards:void inside the review period and rewards:exclude.
 */
function rewardsChecks(
  t: MonitorTargets, rw: RewardsTargets, th: Thresholds, nowSeconds: number, attempt: Attempt,
): Promise<CheckResult>[] {
  const read = <T>(functionName: typeof NODE_REWARDS_MONITOR_ABI[number]['name'], args?: readonly unknown[]) =>
    t.client.readContract({ address: rw.contract, abi: NODE_REWARDS_MONITOR_ABI, functionName, ...(args ? { args } : {}) } as never) as Promise<T>;
  const finalizeWarn = th.rewardsFinalizeWarnSeconds ?? DEFAULT_REWARDS_THRESHOLDS.rewardsFinalizeWarnSeconds;
  const unclaimedWarn = th.rewardsUnclaimedWarnSeconds ?? DEFAULT_REWARDS_THRESHOLDS.rewardsUnclaimedWarnSeconds;
  const floorCents = th.rewardsUnclaimedFloorCents ?? DEFAULT_REWARDS_THRESHOLDS.rewardsUnclaimedFloorCents;
  const out: Promise<CheckResult>[] = [];

  out.push(attempt('node_rewards_balance', async () => {
    const id = 'node_rewards_balance';
    const [token, perCent, accounted, outstanding, carry] = await Promise.all([
      read<Address>('REWARD_TOKEN'), read<bigint>('TOKEN_PER_CENT'), read<bigint>('accounted'), read<bigint>('outstanding'), read<bigint>('carry'),
    ]);
    const held = await t.client.readContract({ address: token, abi: BALANCE_OF_ABI, functionName: 'balanceOf', args: [rw.contract] }) as bigint;
    const c = (units: bigint) => units / perCent;
    if (held < accounted) {
      return {
        id, level: 'fail', value: Number(c(held)), threshold: Number(c(accounted)),
        detail: `NodeRewards holds ${reais(c(held))} of its token but has booked ${reais(c(accounted))}: claims will revert. Only a claim `
          + 'moves tokens out of it, so look at the reward token itself - a transfer fee, a freeze or a rebase',
      };
    }
    const unbooked = held > accounted ? `, and ${reais(c(held - accounted))} arrived but not yet booked (anyone may sync)` : '';
    return {
      id, level: 'ok', value: Number(c(held)),
      detail: `NodeRewards holds ${reais(c(held))}: ${reais(c(outstanding))} owed to LPs for finalized epochs, ${reais(c(carry))} rolling forward${unbooked}`,
    };
  }));

  out.push(attempt('node_rewards_unclaimed', async () => {
    const id = 'node_rewards_unclaimed';
    const [next, finalizable, lastClaimAt, outstanding, perCent] = await Promise.all([
      read<bigint>('nextToFinalize'), read<bigint>('finalizableEpochs'), read<bigint>('lastClaimAt'), read<bigint>('outstanding'), read<bigint>('TOKEN_PER_CENT'),
    ]);
    if (finalizable > 0n) {
      const age = nowSeconds - Number(await read<bigint>('finalizableAt', [next]));
      if (age >= finalizeWarn) {
        return {
          id, level: 'warn', value: age, threshold: finalizeWarn,
          detail: `epoch ${next} could be finalized ${Math.floor(age / 3600)}h ago and nobody has (${finalizable} epoch(s) waiting), so LPs cannot `
            + 'claim them. LP nodes with rewards.claim on finalize before claiming: are they down? Anyone may send rewards:finalize',
        };
      }
    }
    const owed = outstanding / perCent;
    const since = lastClaimAt > 0n ? Number(lastClaimAt) : Number(await read<bigint>('finalizableAt', [0n]));
    const quiet = nowSeconds - since;
    if (owed >= floorCents && next > 0n && quiet >= unclaimedWarn) {
      return {
        id, level: 'warn', value: quiet, threshold: unclaimedWarn,
        detail: `${reais(owed)} of finalized LP rewards is unclaimed and no LP has claimed for ${Math.floor(quiet / 86_400)} days: their nodes `
          + 'may be down or have rewards.claim off. Nothing expires; this is a notice, not a loss',
      };
    }
    return {
      id, level: 'ok', value: Number(finalizable),
      detail: `${finalizable} epoch(s) waiting to be finalized, ${reais(owed)} owed to LPs, last claim ${lastClaimAt > 0n ? new Date(Number(lastClaimAt) * 1000).toISOString() : 'never'}`,
    };
  }));

  out.push(attempt('node_rewards_wiring', async () => {
    const id = 'node_rewards_wiring';
    const [registry, funded, token] = await Promise.all([read<Address>('registry'), read<bigint>('totalFunded'), read<Address>('REWARD_TOKEN')]);
    const problems: string[] = [];
    let share: number | undefined;
    if (rw.splitter) {
      const s = { address: rw.splitter, abi: FEE_SPLITTER_MONITOR_ABI } as const;
      const [splitToken, funds, bps] = await Promise.all([
        t.client.readContract({ ...s, functionName: 'TOKEN' }) as Promise<Address>,
        t.client.readContract({ ...s, functionName: 'rewards' }) as Promise<Address>,
        t.client.readContract({ ...s, functionName: 'lpRewardShareBps' }) as Promise<number>,
      ]);
      share = Number(bps);
      if (!isAddressEqual(funds, rw.contract)) problems.push(`the FeeSplitter funds ${funds}, not this NodeRewards: the LPs' share goes elsewhere`);
      if (!isAddressEqual(splitToken, token)) problems.push(`the FeeSplitter splits ${splitToken}, not the reward token ${token}`);
    }
    if (isAddressEqual(registry, ZERO) && (funded > 0n || (share ?? 0) > 0)) {
      problems.push(`no registry is bound, so no settlement counts while ${funded > 0n ? 'funds wait to be shared' : `the splitter forwards ${share} bps of Mova's fees`}: `
        + 'bind the ramp\'s registry with rewards:registry');
    }
    if (problems.length) return { id, level: 'warn', detail: problems.join('; ') };
    const bound = isAddressEqual(registry, ZERO) ? 'no registry bound yet (nothing to share)' : `counting settlements reported by registry ${registry}`;
    return { id, level: 'ok', detail: `${bound}${share !== undefined ? `; the splitter forwards ${share} bps of Mova's fees` : ''}` };
  }));

  return out;
}

/*//////////////////////////////////////////////////////////////
                             MOVVA
//////////////////////////////////////////////////////////////*/

/**
 * What the monitor needs to watch Movva: the reserve, and where the issuer publishes its hedge
 * statements.
 *
 * ## Why the statement check lives here, transcribed
 *
 * The desk tooling (`@mova/movva`) owns the statement format, and it depends on this package for
 * redaction - so this package cannot import it back. The EIP-712 types and the few verification
 * steps the monitor needs are therefore transcribed below, the way contract ABIs are, and
 * packages/movva/test/monitor-compat.test.ts pins them: identical types, and a statement signed by
 * the desk verifies here while a tampered one does not.
 */
export interface MovvaTargets {
  reserve: Address;
  /** The chain the monitor reads; a statement signed for another chain fails. */
  chainId?: number;
  statement?: {
    /** The latest statement's JSON, or undefined when there is none to fetch (404, missing file). */
    load: () => Promise<string | undefined>;
    /** The issuer's statement key. The only trust input. */
    issuer: Address;
    /** Carried across sweeps, so a replaced or rewound statement is noticed. Pass `{}` once. */
    memory: MovvaStatementMemory;
  };
  /**
   * Enables `movva_breaker` and `movva_hedge_queue`, for a reserve deployed with the divergence breaker and the
   * hedge timelock (docs/movva.md): off by default so an older reserve is not asked for views it lacks.
   */
  breaker?: boolean;
}

export interface MovvaStatementMemory {
  /** The last statement that verified. */
  last?: { hash: Hex; sequence: bigint };
  /** Statement hashes whose snapshot was already checked against the chain (archive reads are costly). */
  snapshotChecked?: Set<string>;
}

export const MOVVA_MONITOR_ABI = [
  {
    type: 'function', name: 'brlPerUsdtE18', stateMutability: 'view', inputs: [],
    outputs: [{ name: 'rate', type: 'uint256' }, { name: 'updatedAt', type: 'uint64' }],
  },
  {
    type: 'function', name: 'bandBrlPerUsdtE18', stateMutability: 'view', inputs: [],
    outputs: [{ name: 'rate', type: 'uint256' }, { name: 'updatedAt', type: 'uint64' }],
  },
  { type: 'function', name: 'totalUsdt', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint256' }] },
  { type: 'function', name: 'liabilitiesBrlE18', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint256' }] },
  { type: 'function', name: 'liabilitiesUsdt', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint256' }] },
  { type: 'function', name: 'collateralRatioBps', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint256' }] },
  { type: 'function', name: 'targetCollateralRatioBps', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint16' }] },
  { type: 'function', name: 'minMintCollateralRatioBps', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint16' }] },
  { type: 'function', name: 'minWithdrawCollateralRatioBps', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint16' }] },
  { type: 'function', name: 'hedgeWithdrawable', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint256' }] },
  { type: 'function', name: 'hedgeLimitBps', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint16' }] },
  {
    type: 'event', name: 'WithdrawnToHedge', anonymous: false, inputs: [
      { name: 'treasury', type: 'address', indexed: true },
      { name: 'usdt', type: 'uint256', indexed: false },
      { name: 'collateralRatioBpsAfter', type: 'uint256', indexed: false },
    ],
  },
  ...ORACLE_ABI.filter((x) => x.type === 'error'),
] as const;

/** `MovvaReserve`'s own `fxOracle()`, to ask its FX leg for market hours. Not in IMovvaReserve, so not in MOVVA_MONITOR_ABI. */
const MOVVA_FX_LEG_ABI = [{ type: 'function', name: 'fxOracle', stateMutability: 'view', inputs: [], outputs: [{ type: 'address' }] }] as const;

/** Transcribed from packages/movva/src/statement.ts; see MovvaTargets. */
export const MOVVA_STATEMENT_TYPES = {
  Position: [
    { name: 'instrument', type: 'string' },
    { name: 'ticker', type: 'string' },
    { name: 'expiry', type: 'string' },
    { name: 'side', type: 'string' },
    { name: 'contracts', type: 'uint256' },
    { name: 'contractSizeUsd', type: 'uint256' },
    { name: 'averagePriceBrlPerUsdE6', type: 'uint256' },
  ],
  HedgeStatement: [
    { name: 'issuer', type: 'address' },
    { name: 'sequence', type: 'uint64' },
    { name: 'asOf', type: 'uint64' },
    { name: 'reserveBlock', type: 'uint64' },
    { name: 'reserveBlockHash', type: 'bytes32' },
    { name: 'reserveBrlPerUsdtE18', type: 'uint256' },
    { name: 'reserveLiabilitiesUsdt', type: 'uint256' },
    { name: 'positions', type: 'Position[]' },
    { name: 'netShortUsdE6', type: 'int256' },
    { name: 'marginBalanceBrlCents', type: 'int256' },
    { name: 'marginRequiredBrlCents', type: 'uint256' },
    { name: 'brokerStatementSha256', type: 'bytes32' },
    { name: 'previousStatementHash', type: 'bytes32' },
  ],
} as const;

const MOVVA_STATEMENT_DOMAIN = (chainId: number, reserve: Address) =>
  ({ name: 'Movva Hedge Statement', version: '1', chainId, verifyingContract: reserve }) as const;

interface MovvaStatementDoc {
  chainId: number;
  verifyingContract: Address;
  hash: Hex;
  signature: Hex;
  message: {
    issuer: Address; sequence: bigint; asOf: bigint; reserveBlock: bigint; reserveBlockHash: Hex;
    reserveBrlPerUsdtE18: bigint; reserveLiabilitiesUsdt: bigint;
    positions: { instrument: string; ticker: string; expiry: string; side: string; contracts: bigint; contractSizeUsd: bigint; averagePriceBrlPerUsdE6: bigint }[];
    netShortUsdE6: bigint; marginBalanceBrlCents: bigint; marginRequiredBrlCents: bigint;
    brokerStatementSha256: Hex; previousStatementHash: Hex;
  };
}

/** Strict enough that a malformed document fails here rather than as a confusing signature error. */
function parseMovvaStatement(text: string): MovvaStatementDoc {
  const j = JSON.parse(text) as Record<string, any>; // eslint-disable-line @typescript-eslint/no-explicit-any
  const bad = (what: string): never => { throw new Error(`not a movva-hedge-statement/v1 document (${what})`); };
  if (j?.format !== 'movva-hedge-statement/v1') bad('format');
  const m = j.message ?? bad('message');
  const u = (v: unknown, what: string, signed = false) =>
    (typeof v === 'string' && (signed ? /^-?\d+$/ : /^\d+$/).test(v) ? BigInt(v) : bad(what));
  const hex = (v: unknown, what: string, len?: number) =>
    (typeof v === 'string' && new RegExp(`^0x[0-9a-fA-F]${len ? `{${len}}` : '*'}$`).test(v) ? v.toLowerCase() as Hex : bad(what));
  const str = (v: unknown, what: string) => (typeof v === 'string' ? v : bad(what));
  if (!Array.isArray(m.positions)) bad('positions');
  return {
    chainId: Number.isSafeInteger(j.domain?.chainId) ? j.domain.chainId : bad('domain.chainId'),
    verifyingContract: hex(j.domain?.verifyingContract, 'domain.verifyingContract', 40) as Address,
    hash: hex(j.hash, 'hash', 64), signature: hex(j.signature, 'signature'),
    message: {
      issuer: hex(m.issuer, 'issuer', 40) as Address, sequence: u(m.sequence, 'sequence'), asOf: u(m.asOf, 'asOf'),
      reserveBlock: u(m.reserveBlock, 'reserveBlock'), reserveBlockHash: hex(m.reserveBlockHash, 'reserveBlockHash', 64),
      reserveBrlPerUsdtE18: u(m.reserveBrlPerUsdtE18, 'reserveBrlPerUsdtE18'), reserveLiabilitiesUsdt: u(m.reserveLiabilitiesUsdt, 'reserveLiabilitiesUsdt'),
      positions: (m.positions as Record<string, unknown>[]).map((p, i) => ({
        instrument: str(p?.instrument, `positions[${i}].instrument`), ticker: str(p?.ticker, `positions[${i}].ticker`),
        expiry: str(p?.expiry, `positions[${i}].expiry`), side: str(p?.side, `positions[${i}].side`),
        contracts: u(p?.contracts, `positions[${i}].contracts`), contractSizeUsd: u(p?.contractSizeUsd, `positions[${i}].contractSizeUsd`),
        averagePriceBrlPerUsdE6: u(p?.averagePriceBrlPerUsdE6, `positions[${i}].averagePriceBrlPerUsdE6`),
      })),
      netShortUsdE6: u(m.netShortUsdE6, 'netShortUsdE6', true),
      marginBalanceBrlCents: u(m.marginBalanceBrlCents, 'marginBalanceBrlCents', true),
      marginRequiredBrlCents: u(m.marginRequiredBrlCents, 'marginRequiredBrlCents'),
      brokerStatementSha256: hex(m.brokerStatementSha256, 'brokerStatementSha256', 64),
      previousStatementHash: hex(m.previousStatementHash, 'previousStatementHash', 64),
    },
  };
}

/**
 * Where statements come from: an HTTPS URL (the issuer's publication) or a file. 404 and a missing
 * file are "no statement" - a `fail` - while any other failure to read is the monitor's problem
 * and reported `unknown`. The URL may carry an access token: pass it in `redactValues`.
 */
export function movvaStatementLoader(
  source: { url: string } | { file: string },
  deps: { fetch?: typeof fetch; readFile?: (path: string) => Promise<string> } = {},
): () => Promise<string | undefined> {
  if ('url' in source) {
    const f = deps.fetch ?? fetch;
    return async () => {
      const res = await f(source.url, { signal: AbortSignal.timeout(10_000), headers: { accept: 'application/json' } });
      if (res.status === 404 || res.status === 410) return undefined;
      if (!res.ok) throw new Error(`statement URL answered HTTP ${res.status}`);
      const text = await res.text();
      if (text.length > 1_000_000) throw new Error('statement document is larger than 1 MB');
      return text;
    };
  }
  const read = deps.readFile ?? (async (p: string) => (await import('node:fs/promises')).readFile(p, 'utf8'));
  return async () => {
    try {
      return await read(source.file);
    } catch (e) {
      if ((e as NodeJS.ErrnoException)?.code === 'ENOENT') return undefined;
      throw e;
    }
  };
}

/**
 * What `lp_node_caps` reads from an LP node's `/status`. Payer hashes and totals are deliberately NOT
 * read: the monitor watches that the ledger is working, not who is in it.
 */
export interface LpNodeCapsReading {
  /** False when the node runs with no `caps` section at all. */
  enabled: boolean;
  /** True once some tier states a limit; a ledger that only counts refuses nothing. */
  limiting: boolean;
  /** The Brasília day the node is counting into, `YYYY-MM-DD`. */
  day: string;
  /** Rows the ledger holds. */
  rows: number;
  /** Unix seconds of the last ledger write, from the journal; undefined if it has never been written. */
  lastCountAt?: number;
  /** Unix seconds the node last attributed BRL that should have been counted; undefined since its last restart. */
  lastMoneyAt?: number;
  unknownPayer: 'refuse' | 'allow';
}

/**
 * Reads an LP node's `/status` (`url` is its OPERATIONS base URL, which is private - see packages/lp-node).
 * Anything but a 200 carrying a `caps` object throws, which the check reports as `unknown`; a node that
 * answers 200 with `caps: null` is a node running without caps, which is `enabled: false` and a `fail`.
 */
export function lpNodeCapsLoader(url: string, deps: { fetch?: typeof fetch } = {}): () => Promise<LpNodeCapsReading> {
  const f = deps.fetch ?? fetch;
  const endpoint = `${url.replace(/\/+$/, '')}/status`;
  return async () => {
    const res = await f(endpoint, { signal: AbortSignal.timeout(10_000), headers: { accept: 'application/json' } });
    if (!res.ok) throw new Error(`LP node /status answered HTTP ${res.status}`);
    const body = await res.json() as { caps?: unknown };
    if (body.caps === null || body.caps === undefined) {
      return { enabled: false, limiting: false, day: '', rows: 0, unknownPayer: 'refuse' };
    }
    const c = body.caps as Record<string, unknown>;
    if (typeof c.day !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(c.day)) throw new Error('LP node /status: caps.day is not a calendar day');
    if (typeof c.rows !== 'number') throw new Error('LP node /status: caps.rows is not a number');
    const seconds = (v: unknown) => (typeof v === 'number' && Number.isFinite(v) ? v : undefined);
    return {
      enabled: c.enabled === true,
      limiting: c.limiting === true,
      day: c.day,
      rows: c.rows,
      lastCountAt: seconds(c.lastCountAt),
      lastMoneyAt: seconds(c.lastMoneyAt),
      unknownPayer: c.unknownPayer === 'allow' ? 'allow' : 'refuse',
    };
  };
}

const BPS = 10_000n;
const E6 = 1_000_000n;
const UINT256_MAX = (1n << 256n) - 1n;
const ceilDivPos = (a: bigint, b: bigint) => (a + b - 1n) / b;
/** USDT the reserve must hold for `ratioBps`, as the interface computes the ratio (see @mova/movva usdtForRatio). */
const usdtForRatio = (ratioBps: bigint, liabilitiesBrlE18: bigint, rate: bigint) =>
  ceilDivPos(ceilDivPos(ratioBps * liabilitiesBrlE18, BPS) * E6, rate);
/** Reais for a detail line, to the nearest centavo. Display only: no decision is taken on it. */
const brl = (e18: bigint) => `R$ ${(Number((e18 + 5n * 10n ** 15n) / 10n ** 16n) / 100).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const pct = (bps: bigint | number) => `${(Number(bps) / 100).toFixed(2)}%`;
/** Reais per USDT (1e18) to four places. Display only. */
const rate4 = (e18: bigint) => `R$ ${(Number(e18 / 10n ** 14n) / 10_000).toFixed(4).replace('.', ',')}`;

/**
 * ## Off-hours
 *
 * The reserve's FX leg is Pyth's FX.USD/BRL (PythFxOracle), which trades weekdays 08:00-17:00 New York time.
 * Everything on the reserve that prices value - `brlPerUsdtE18`, the ratio, the previews, `liabilitiesUsdt` -
 * reads the leg's RATE and refuses once it is older than its max age: every weekday night and every weekend.
 * That is Mova's decision (minting and redeeming wait for the market), not an outage, and a monitor that paged
 * on it would page every night. `bandBrlPerUsdtE18` reads the same rate as a band does: the last close while
 * the market is closed.
 *
 * So a Movva check whose rate is refused or old asks `movvaMarket` - once a sweep - and the market is `closed`
 * only when three readings agree: the reserve's `fxOracle()` keeps market hours, its `inCoreSession()` is
 * false, and the band still prices. Then the checks report `ok`, saying the market is closed, and compute what
 * they can at the last close, saying so; nothing is sized from it. Anything else - a stale USDT/USD feed (the
 * band refuses too), a leg without market hours, a last close past `closedMaxAge`, a refused rate inside the
 * core session (the Pyth keeper is down) - is judged as before, and the detail names the Pyth keeper for a
 * Pyth leg. A read that fails is `unknown`.
 */
interface MovvaMarket {
  /** The reserve's FX leg, when it names one. */
  leg?: Address;
  /** The leg's `inCoreSession()`; undefined for a leg without market hours (a SignedPriceOracle). */
  coreSession?: boolean;
  /** `bandBrlPerUsdtE18()` outside the core session: the last close. */
  band?: { rate: bigint; updatedAt: bigint };
  /** Why the band refused, when it did. */
  bandRefusal?: string;
  closed: boolean;
}

async function movvaMarket(
  t: MonitorTargets, mv: MovvaTargets, read: <T>(fn: typeof MOVVA_MONITOR_ABI[number]['name']) => Promise<T>,
): Promise<MovvaMarket> {
  let leg: Address | undefined;
  try {
    leg = await t.client.readContract({ address: mv.reserve, abi: MOVVA_FX_LEG_ABI, functionName: 'fxOracle' }) as Address;
  } catch (e) {
    if (!refusedByContract(e)) throw e;
  }
  const coreSession = leg ? await coreSessionOf(t.client, leg) : undefined;
  let band: MovvaMarket['band'];
  let bandRefusal: string | undefined;
  if (coreSession === false) {
    try {
      const [rate, updatedAt] = await read<readonly [bigint, bigint]>('bandBrlPerUsdtE18');
      band = { rate, updatedAt };
    } catch (e) {
      const r = revertOf(e);
      if (r) bandRefusal = r.reason;
      else if (!refusedByContract(e)) throw e;
    }
  }
  return { leg, coreSession, band, bandRefusal, closed: coreSession === false && band !== undefined };
}

/** What to check when the reserve's rate is refused or old, by the kind of FX leg it has. */
function legHint(m: MovvaMarket): string {
  if (m.coreSession === undefined) return 'the FX publishers and the USDT/USD feed';
  if (m.coreSession) {
    return `the Pyth keeper - inside the FX market's core session it keeps ${m.leg}'s feed posted; see its /status - and the USDT/USD feed`;
  }
  return `the USDT/USD feed, and whether ${m.leg}'s last close is past its closedMaxAge${m.bandRefusal ? ` (the band refuses too: ${m.bandRefusal})` : ''}`;
}

interface VerifiedStatement {
  netShortUsdE6: bigint;
  freeMarginBrlE18: bigint;
  sequence: bigint;
}

type Attempt = (id: string, fn: () => Promise<CheckResult>) => Promise<CheckResult>;

function movvaChecks(
  t: MonitorTargets, mv: MovvaTargets, th: Thresholds, nowSeconds: number, attempt: Attempt,
): Promise<CheckResult>[] {
  const out: Promise<CheckResult>[] = [];
  const read = <T>(functionName: typeof MOVVA_MONITOR_ABI[number]['name'], blockNumber?: bigint) =>
    t.client.readContract({ address: mv.reserve, abi: MOVVA_MONITOR_ABI, functionName, ...(blockNumber === undefined ? {} : { blockNumber }) } as never) as Promise<T>;
  // Asked once a sweep, and only by a check whose rate was refused or old (see "Off-hours").
  let market: Promise<MovvaMarket> | undefined;
  const marketOf = () => (market ??= movvaMarket(t, mv, read));

  out.push(attempt('movva_collateral_ratio', async () => {
    let ratio: bigint;
    let atClose = '';
    try {
      ratio = await read<bigint>('collateralRatioBps');
    } catch (e) {
      const r = revertOf(e);
      if (!r) throw e;
      const m = await marketOf();
      if (!m.closed) {
        return {
          id: 'movva_collateral_ratio', level: 'fail',
          detail: `the reserve refuses to compute its collateral ratio (${r.reason}): mint and redeem are halted; see movva_rate`,
        };
      }
      // The reserve's own arithmetic at the band's last close, rounded down as it rounds. Nothing is sized from it.
      const [T, L] = await Promise.all([read<bigint>('totalUsdt'), read<bigint>('liabilitiesBrlE18')]);
      ratio = L === 0n ? UINT256_MAX : (T * m.band!.rate / E6) * BPS / L;
      atClose = ` at the last close, ${rate4(m.band!.rate)} per USDT (the FX market is closed: the reserve prices nothing until it reopens)`;
    }
    const [target, minMint, minWithdraw] = await Promise.all([
      read<number>('targetCollateralRatioBps'), read<number>('minMintCollateralRatioBps'), read<number>('minWithdrawCollateralRatioBps'),
    ]);
    // The reserve now enforces minMint <= minWithdraw <= target; a deployment that predates that can
    // still carry them out of order, and a withdraw floor above the target starves the hedge of margin.
    if (!(minMint <= minWithdraw && minWithdraw <= target)) {
      const fromRatio = ratio === UINT256_MAX ? '' : `collateral ratio ${pct(ratio)}${atClose}; `;
      return {
        id: 'movva_collateral_ratio', level: ratio < BPS ? 'fail' : 'warn', value: ratio === UINT256_MAX ? undefined : Number(ratio), threshold: target,
        detail: `${fromRatio}RATIOS OUT OF ORDER: mint floor ${pct(minMint)}, withdraw floor ${pct(minWithdraw)}, target ${pct(target)}. `
          + 'With the withdraw floor above the target a reserve at its target cannot release margin to the hedge; set minMint <= minWithdraw <= target',
      };
    }
    if (ratio === UINT256_MAX) return { id: 'movva_collateral_ratio', level: 'ok', detail: `no Movva in circulation${atClose ? '; the FX market is closed' : ''}`, threshold: target };
    const value = Number(ratio);
    if (ratio < BPS) {
      return {
        id: 'movva_collateral_ratio', level: 'fail', value, threshold: target,
        detail: `Movva is UNDER-BACKED at ${pct(ratio)}${atClose}: redeem pays ${pct(ratio)} of R$ 1,00 and mint is refused. `
          + 'If the dollar fell, the hedge gains must come back through recapitalize now',
      };
    }
    if (ratio < BigInt(target)) {
      return {
        id: 'movva_collateral_ratio', level: 'warn', value, threshold: target,
        detail: `collateral ratio ${pct(ratio)}${atClose} is below the ${pct(target)} target${ratio < BigInt(minMint) ? ': mint is refused' : ''}; `
          + 'recapitalize to restore the buffer (movva-desk recap-plan)',
      };
    }
    return { id: 'movva_collateral_ratio', level: 'ok', value, threshold: target, detail: `collateral ratio ${pct(ratio)} (target ${pct(target)})${atClose}` };
  }));

  out.push(attempt('movva_rate', async () => {
    let rate: bigint; let updatedAt: bigint;
    try {
      [rate, updatedAt] = await read<readonly [bigint, bigint]>('brlPerUsdtE18');
    } catch (e) {
      const r = revertOf(e);
      if (!r) throw e;
      const m = await marketOf();
      if (m.closed) {
        return {
          id: 'movva_rate', level: 'ok',
          detail: `the FX market is closed: the reserve refuses to price value (${r.reason}), so mint, redeem and withdrawToHedge `
            + `wait for the reopening, while Movva's band on the ramps reads the last close, ${rate4(m.band!.rate)} per USDT`,
        };
      }
      return {
        id: 'movva_rate', level: 'fail',
        detail: `the reserve refuses to price (${r.reason}): mint, redeem and withdrawToHedge revert until both oracle legs are fresh. Check ${legHint(m)}`,
      };
    }
    // R$ 1 to R$ 100 per USDT: outside it the rate is mis-scaled or inverted, not a market.
    if (rate < 10n ** 18n || rate > 100n * 10n ** 18n) {
      return { id: 'movva_rate', level: 'fail', detail: `the reserve's rate is ${rate} (reais per USDT x 1e18), outside R$ 1-100: mis-scaled or inverted. Pause mint` };
    }
    const age = nowSeconds - Number(updatedAt);
    const level: Level = age >= th.movvaRateFailSeconds ? 'fail' : age >= th.movvaRateWarnSeconds ? 'warn' : 'ok';
    const shown = rate4(rate);
    if (level === 'ok') return { id: 'movva_rate', level, value: age, threshold: th.movvaRateWarnSeconds, detail: `Movva rate ${shown} per USDT, ${age}s old` };
    const m = await marketOf();
    if (m.coreSession === false) {
      return {
        id: 'movva_rate', level: 'ok', value: age, threshold: th.movvaRateWarnSeconds,
        detail: `Movva rate ${shown} per USDT, ${age}s old: the FX market is closed, so no newer price comes until it reopens, and the reserve stops pricing value once the leg passes its max age`,
      };
    }
    return {
      id: 'movva_rate', level, value: age, threshold: th.movvaRateWarnSeconds,
      detail: `Movva rate ${shown} per USDT is ${age}s old: the reserve refuses to mint and redeem once a leg passes its max age. Check ${legHint(m)}`,
    };
  }));

  // One read and verification of the statement per sweep, shared by the two checks that use it.
  let statement: Promise<{ result: CheckResult; verified?: VerifiedStatement }> | undefined;
  const loadStatement = () => {
    statement ??= movvaStatement(t, mv, th, nowSeconds, read, marketOf).catch((e: unknown) => ({
      result: { id: 'movva_hedge_statement', level: 'unknown' as Level, detail: `could not be read: ${redactError(e, t.redactValues)}` },
    }));
    return statement;
  };
  if (mv.statement) out.push(attempt('movva_hedge_statement', async () => (await loadStatement()).result));

  out.push(attempt('movva_withdraw_headroom', async () => {
    const id = 'movva_withdraw_headroom';
    let rate: bigint;
    let atClose = '';
    try {
      [rate] = await read<readonly [bigint, bigint]>('brlPerUsdtE18');
    } catch (e) {
      const r = revertOf(e);
      if (!r) throw e;
      const m = await marketOf();
      if (!m.closed) {
        return { id, level: 'warn', detail: `withdrawToHedge is unavailable while the reserve refuses to price (${r.reason}): a margin call now must be met from the issuer's own capital` };
      }
      rate = m.band!.rate;
      atClose = `. Priced at the last close, ${rate4(rate)} per USDT: the FX market is closed and withdrawToHedge waits for it to reopen, `
        + 'so a margin call before then is met from the issuer\'s own capital';
    }
    const [T, L, floor, head] = await Promise.all([
      read<bigint>('totalUsdt'), read<bigint>('liabilitiesBrlE18'), read<number>('minWithdrawCollateralRatioBps'),
      t.client.getBlock({ blockTag: 'latest' }),
    ]);
    if (L === 0n) return { id, level: 'ok', detail: `no Movva in circulation: nothing is hedged${atClose ? '; the FX market is closed' : ''}` };
    // liabilitiesUsdt prices through the rate, so while closed it is the reserve's arithmetic at the close (rounded up, as it rounds).
    const liabUsdt = atClose ? ceilDivPos(L * E6, rate) : await read<bigint>('liabilitiesUsdt');
    const v = mv.statement ? (await loadStatement()).verified : undefined;
    const H = v?.netShortUsdE6 ?? liabUsdt;
    const free = v?.freeMarginBrlE18 ?? 0n;
    // The reserve's own bucket and limit when it has them; configuration and events only without.
    const own = await hedgeViews(read);
    const withdrawn = own ? 0n : await withdrawnToHedge(t.client, mv.reserve, head.number!, head.timestamp);
    const bucket = own ? own.withdrawable
      : (T * BigInt(th.movvaWithdrawDailyLimitBps) / BPS > withdrawn ? T * BigInt(th.movvaWithdrawDailyLimitBps) / BPS - withdrawn : 0n);
    const limitNote = own
      ? `the reserve's hedgeWithdrawable() holds ${Number(own.withdrawable) / 1e6} USDT of its ${pct(own.limitBps)}/24h limit`
        + (own.limitBps !== th.movvaWithdrawDailyLimitBps ? ` (MOVVA_WITHDRAW_DAILY_LIMIT_BPS says ${pct(th.movvaWithdrawDailyLimitBps)}: update it)` : '')
      : `the reserve exposes no hedgeWithdrawable(): assumed ${pct(th.movvaWithdrawDailyLimitBps)}/24h less ${Number(withdrawn) / 1e6} USDT withdrawn in 24h`;

    const dS = rate * BigInt(th.movvaShockBps) / BPS;
    const S1 = rate + dS;
    const absH = H < 0n ? -H : H;
    const variation = H * dS / E6;
    const imChange = absH * dS * BigInt(th.movvaInitialMarginBps) / (E6 * BPS);
    const need0 = variation + imChange - free;
    const need = need0 > 0n ? need0 : 0n;
    const allowedAt = (S: bigint) => {
      const floorMin = usdtForRatio(BigInt(floor), L, S);
      const floorMax = T > floorMin ? T - floorMin : 0n;
      const dailyMax = bucket;
      const usdt = floorMax < dailyMax ? floorMax : dailyMax;
      return { usdt, binding: floorMax <= dailyMax ? `the ${pct(floor)} floor` : 'the 24h limit', brl: usdt * S / E6 * (BPS - BigInt(th.movvaConversionCostBps)) / BPS };
    };
    const today = allowedAt(rate);
    const shocked = allowedAt(S1);
    const hedgeFrom = v ? `statement #${v.sequence}` : mv.statement ? 'ASSUMED at liabilitiesUsdt (no verified statement)' : 'assumed at liabilitiesUsdt';
    const context = `short ${(Number(H / E6)).toLocaleString('en-US')} USD (${hedgeFrom}); withdrawToHedge allows ${brl(today.brl)} today and `
      + `${brl(shocked.brl)} after the move (${shocked.binding} binds; ${limitNote})`;
    if (need === 0n) {
      return { id, level: 'ok', value: 100, threshold: 100, detail: `a +${pct(th.movvaShockBps)} dollar move needs no new margin: ${context}${atClose}` };
    }
    const coverage = shocked.brl >= need ? 100 : Number(shocked.brl * 100n / need);
    return {
      id, level: coverage >= 100 ? 'ok' : 'warn', value: coverage, threshold: 100,
      detail: coverage >= 100
        ? `a +${pct(th.movvaShockBps)} dollar move needs ${brl(need)} of margin, covered: ${context}${atClose}`
        : `a +${pct(th.movvaShockBps)} dollar move would need ${brl(need)} of margin; withdrawToHedge covers ${coverage}%, `
          + `the issuer would fund ${brl(need - shocked.brl)}: ${context}. Pre-fund margin at the broker or hold the ratio above the floor${atClose}`,
    };
  }));

  if (mv.breaker) out.push(...movvaBreakerChecks(t, mv, nowSeconds, attempt));
  return out;
}

/** What `movva_breaker` and `movva_hedge_queue` read; kept out of MOVVA_MONITOR_ABI, which tracks the interface. */
export const MOVVA_BREAKER_ABI = [
  { type: 'function', name: 'breakerTripped', stateMutability: 'view', inputs: [], outputs: [{ type: 'bool' }] },
  { type: 'function', name: 'BREAKER', stateMutability: 'view', inputs: [], outputs: [{ type: 'address' }] },
  { type: 'function', name: 'hedgeRequestCount', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint256' }] },
  {
    type: 'function', name: 'hedgeRequests', stateMutability: 'view', inputs: [{ type: 'uint256' }],
    outputs: [{ name: 'to', type: 'address' }, { name: 'executeAfter', type: 'uint64' }, { name: 'executed', type: 'bool' }, { name: 'usdt', type: 'uint256' }],
  },
  { type: 'function', name: 'sourceRates', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint256[]' }] },
] as const;

/** Newest queued hedge withdrawals the check looks at; older ones were announced long ago and settled or are stuck by design. */
const HEDGE_QUEUE_LOOKBACK = 20n;

/**
 * `movva_breaker`: the self-clearing divergence breaker is tripped, so mint, redeem and hedge
 * withdrawals revert until the sources agree again. `warn`, not `fail`: it is working as designed and clears
 * itself, but a halt is a product outage and, if a thin TWAP trips it, possibly an attack. The detail lists
 * each source's rate (0 means the source reverted).
 *
 * `movva_hedge_queue`: a hedge withdrawal above the daily limit has been announced. `warn` while one waits
 * (users have until `executeAfter` to redeem, which is the point of the delay), once, with its amount.
 */
function movvaBreakerChecks(t: MonitorTargets, mv: MovvaTargets, nowSeconds: number, attempt: Attempt): Promise<CheckResult>[] {
  const call = <T>(functionName: string, address: Address = mv.reserve, abi: readonly unknown[] = MOVVA_BREAKER_ABI, args: unknown[] = []) =>
    t.client.readContract({ address, abi, functionName, args } as never) as Promise<T>;
  return [
    attempt('movva_breaker', async () => {
      const id = 'movva_breaker';
      const breaker = await call<Address>('BREAKER');
      if (breaker === ZERO) return { id, level: 'ok', detail: 'no divergence breaker on this reserve' };
      const tripped = await call<boolean>('breakerTripped');
      if (!tripped) return { id, level: 'ok', value: 0, threshold: 0, detail: 'the independent price sources agree' };
      let rates = '';
      try {
        const r = await call<readonly bigint[]>('sourceRates', breaker);
        rates = `; source rates (reais per USDT x 1e18, 0 = reverted): ${r.join(', ')}`;
      } catch { /* the rates are context, not the verdict */ }
      return {
        id, level: 'warn', value: 1, threshold: 0,
        detail: `the divergence breaker is tripped: mint, redeem and hedge withdrawals revert until the sources are back in band (it clears itself; nobody can lift it)${rates}. If a thin TWAP source is the one off, consider an attack on it`,
      };
    }),
    attempt('movva_hedge_queue', async () => {
      const id = 'movva_hedge_queue';
      const n = await call<bigint>('hedgeRequestCount');
      const pending: string[] = [];
      for (let i = n > HEDGE_QUEUE_LOOKBACK ? n - HEDGE_QUEUE_LOOKBACK : 0n; i < n; i++) {
        const [to, executeAfter, executed, usdt] = await call<readonly [Address, bigint, boolean, bigint]>('hedgeRequests', mv.reserve, MOVVA_BREAKER_ABI, [i]);
        if (!executed) pending.push(`#${i}: ${usdt / 1_000_000n} USDT to ${to}, ${executeAfter > BigInt(nowSeconds) ? `executable by anyone in ${executeAfter - BigInt(nowSeconds)}s` : 'executable now'}`);
      }
      if (pending.length === 0) return { id, level: 'ok', value: 0, detail: 'no hedge withdrawal above the daily limit is waiting' };
      return {
        id, level: 'warn', value: pending.length,
        detail: `${pending.length} hedge withdrawal(s) above the daily limit announced and not yet executed (nobody can cancel them): ${pending.join('; ')}`,
      };
    }),
  ];
}

/**
 * The reserve's `hedgeWithdrawable()` and `hedgeLimitBps()`, or undefined for a reserve without
 * them (the call reverts or returns no data). Any other failure is a failed read and propagates.
 */
async function hedgeViews(
  read: <T>(fn: typeof MOVVA_MONITOR_ABI[number]['name']) => Promise<T>,
): Promise<{ withdrawable: bigint; limitBps: number } | undefined> {
  try {
    const [withdrawable, limitBps] = await Promise.all([read<bigint>('hedgeWithdrawable'), read<number>('hedgeLimitBps')]);
    return { withdrawable, limitBps };
  } catch (e) {
    if (revertOf(e) || (e instanceof BaseError && e.walk((x) => x instanceof ContractFunctionZeroDataError))) return undefined;
    throw e;
  }
}

/** `WithdrawnToHedge` in the 24h before the head block, by block timestamp. Fallback only (see hedgeViews). */
async function withdrawnToHedge(client: PublicClient, reserve: Address, head: bigint, headTimestamp: bigint): Promise<bigint> {
  const span = 7_920n; // 24h of 12s slots plus 10%: missed slots only make blocks further apart
  const logs = await client.getLogs({
    address: reserve, event: MOVVA_MONITOR_ABI.find((x) => x.type === 'event')!, fromBlock: head > span ? head - span : 0n, toBlock: head,
  });
  let total = 0n;
  const stamps = new Map<bigint, bigint>();
  for (const l of logs) {
    const n = l.blockNumber!;
    if (!stamps.has(n)) stamps.set(n, (await client.getBlock({ blockNumber: n })).timestamp);
    if (stamps.get(n)! + 86_400n > headTimestamp) total += (l.args as { usdt?: bigint }).usdt ?? 0n;
  }
  return total;
}

async function movvaStatement(
  t: MonitorTargets, mv: MovvaTargets, th: Thresholds, nowSeconds: number,
  read: <T>(fn: typeof MOVVA_MONITOR_ABI[number]['name'], blockNumber?: bigint) => Promise<T>,
  marketOf: () => Promise<MovvaMarket>,
): Promise<{ result: CheckResult; verified?: VerifiedStatement }> {
  const id = 'movva_hedge_statement';
  const cfg = mv.statement!;
  const failed = (detail: string) => ({ result: { id, level: 'fail' as Level, detail } });
  const text = await cfg.load();
  if (text === undefined) return failed('no hedge statement is published: the off-chain half of the peg is unverifiable. Publish today\'s statement');
  let doc: MovvaStatementDoc;
  try {
    doc = parseMovvaStatement(text);
  } catch (e) {
    return failed(`the published statement is invalid: ${e instanceof Error ? e.message : 'unparseable'}`);
  }
  const m = doc.message;
  const chainId = mv.chainId ?? doc.chainId;
  if (doc.chainId !== chainId || !isAddressEqual(doc.verifyingContract, mv.reserve)) {
    return failed(`statement #${m.sequence} is for chain ${doc.chainId} reserve ${doc.verifyingContract}, not this reserve`);
  }
  const domain = MOVVA_STATEMENT_DOMAIN(chainId, mv.reserve);
  const typed = { domain, types: MOVVA_STATEMENT_TYPES, primaryType: 'HedgeStatement', message: m } as const;
  let signer: Address | undefined;
  try {
    signer = await recoverTypedDataAddress({ ...typed, signature: doc.signature });
  } catch {
    signer = undefined;
  }
  if (!signer || !isAddressEqual(signer, cfg.issuer) || !isAddressEqual(m.issuer, cfg.issuer)) {
    return failed(`statement #${m.sequence} is NOT signed by the issuer's statement key ${cfg.issuer}${signer ? ` (signed by ${signer})` : ' (malformed signature)'}`);
  }
  const hash = hashTypedData(typed);
  if (hash !== doc.hash) return failed(`statement #${m.sequence} states a hash that is not its own`);
  const net = m.positions.reduce((a, p) => a + (p.side === 'short' ? 1n : -1n) * p.contracts * p.contractSizeUsd * E6, 0n);
  if (net !== m.netShortUsdE6) return failed(`statement #${m.sequence}: netShortUsdE6 does not equal its positions (${net})`);

  // Continuity against what this monitor saw before.
  const last = cfg.memory.last;
  const notes: string[] = [];
  if (last) {
    if (m.sequence < last.sequence) return failed(`the published statement went BACKWARDS from #${last.sequence} to #${m.sequence}`);
    if (m.sequence === last.sequence && hash !== last.hash) return failed(`statement #${m.sequence} was REPLACED after publication (hash ${last.hash} became ${hash})`);
    if (m.sequence === last.sequence + 1n && m.previousStatementHash !== last.hash) {
      return failed(`statement #${m.sequence} does not link to #${last.sequence} (${last.hash}): the chain is broken or history was rewritten`);
    }
    if (m.sequence > last.sequence + 1n) notes.push(`chain link not checked: #${last.sequence + 1n} to #${m.sequence - 1n} were never seen by this monitor`);
  }

  const age = nowSeconds - Number(m.asOf);
  if (age > th.movvaStatementMaxAgeSeconds) {
    return failed(`the latest hedge statement (#${m.sequence}) is ${Math.floor(age / 3600)}h old, past ${Math.floor(th.movvaStatementMaxAgeSeconds / 3600)}h: the hedge is unreported`);
  }
  if (age < -300) return failed(`statement #${m.sequence} is dated ${-age}s in the future`);
  cfg.memory.last = { hash, sequence: m.sequence };
  const free = (m.marginBalanceBrlCents - m.marginRequiredBrlCents) * 10n ** 16n;
  const verified: VerifiedStatement = { netShortUsdE6: m.netShortUsdE6, freeMarginBrlE18: free, sequence: m.sequence };

  // The snapshot it reconciles against, once per statement (an archive read for any block not recent).
  let level: Level = 'ok';
  cfg.memory.snapshotChecked ??= new Set();
  if (!cfg.memory.snapshotChecked.has(hash)) {
    try {
      const [block, [rate], liab] = await Promise.all([
        t.client.getBlock({ blockNumber: m.reserveBlock }),
        read<readonly [bigint, bigint]>('brlPerUsdtE18', m.reserveBlock),
        read<bigint>('liabilitiesUsdt', m.reserveBlock),
      ]);
      if (block.hash?.toLowerCase() !== m.reserveBlockHash || rate !== m.reserveBrlPerUsdtE18 || liab !== m.reserveLiabilitiesUsdt) {
        cfg.memory.last = last;
        return failed(`statement #${m.sequence} does not match the reserve at block ${m.reserveBlock}: it reconciles against liabilities or a rate the reserve never had`);
      }
      cfg.memory.snapshotChecked.add(hash);
    } catch (e) {
      level = 'unknown';
      notes.push(`its snapshot at block ${m.reserveBlock} could not be checked (archive node?): ${redactError(e, t.redactValues)}`);
    }
  }

  // Today's hedge ratio against today's liabilities - at the last close while the FX market is closed, saying so.
  let value: number | undefined;
  const judge = (target: bigint, atClose: string) => {
    if (target > 0n) {
      const ratio = m.netShortUsdE6 * BPS / target;
      value = Number(ratio);
      const band = BigInt(th.movvaHedgeBandBps);
      if (m.netShortUsdE6 * BPS < target * (BPS - band) || m.netShortUsdE6 * BPS > target * (BPS + band)) {
        level = 'warn';
        notes.unshift(`hedge ratio ${pct(ratio)}${atClose} is outside the ±${pct(band)} policy band: rebalance (movva-desk hedge-plan)`);
      } else {
        notes.unshift(`hedge ratio ${pct(ratio)}${atClose}`);
      }
    } else if (m.netShortUsdE6 !== 0n) {
      level = 'warn';
      notes.unshift('there is no Movva in circulation, yet the statement reports an open position');
    }
  };
  try {
    judge(await read<bigint>('liabilitiesUsdt'), '');
  } catch (e) {
    const r = revertOf(e);
    if (!r) throw e;
    const mk = await marketOf();
    if (mk.closed) judge(ceilDivPos((await read<bigint>('liabilitiesBrlE18')) * E6, mk.band!.rate), ' at the last close (the FX market is closed)');
    else notes.unshift(`hedge ratio unavailable while the reserve refuses to price (${r.reason})`);
  }
  return {
    verified,
    result: {
      id, level, value, threshold: th.movvaHedgeBandBps,
      detail: `statement #${m.sequence} signed by the issuer, ${Math.floor(age / 60)} min old; ${notes.join('; ')}`,
    },
  };
}

/** The worst level present, for a single health verdict. */
export function worst(results: readonly CheckResult[]): Level {
  const order: Level[] = ['ok', 'unknown', 'warn', 'fail'];
  return results.reduce<Level>(
    (acc, r) => (order.indexOf(r.level) > order.indexOf(acc) ? r.level : acc),
    'ok',
  );
}

/*//////////////////////////////////////////////////////////////
                     GASLESS ONBOARDING: SPONSORGATE
//////////////////////////////////////////////////////////////*/

export const SPONSOR_GATE_MONITOR_ABI = [
  view('maxSponsorsPerWindow', 'uint32'),
  view('remainingSponsorships', 'uint256'),
  view('windowEndsAt', 'uint256'),
  view('PAYMASTER', 'address'),
  view('isOperator', 'bool', [{ name: 'operator', type: 'address' }]),
  view('owner', 'address'),
] as const;

/**
 * `sponsor_gate_budget`: how much of the gate's window operators have used. At zero left, new accounts wait for the
 * window to close - real demand, or a leaked operator key adding accounts - and the paymaster not owned by the gate
 * means operators can do nothing at all. `sponsor_operator_gas:<address>`: each operator's float, and whether it is
 * still an operator (a revoked key still watched is a stale monitor, or a revocation nobody meant).
 */
function sponsorGateChecks(
  t: MonitorTargets, sg: NonNullable<MonitorTargets['sponsorGate']>, th: Thresholds, nowSeconds: number,
  attempt: (id: string, fn: () => Promise<CheckResult>) => Promise<CheckResult>,
): Promise<CheckResult>[] {
  const out: Promise<CheckResult>[] = [];
  const read = <T>(functionName: typeof SPONSOR_GATE_MONITOR_ABI[number]['name'], address: Address = sg.gate, args?: readonly unknown[]) =>
    t.client.readContract({ address, abi: SPONSOR_GATE_MONITOR_ABI, functionName, args } as never) as Promise<T>;
  const warnPercent = th.sponsorGateBudgetWarnPercent ?? DEFAULT_THRESHOLDS.sponsorGateBudgetWarnPercent!;
  const minWei = th.sponsorOperatorMinWei ?? DEFAULT_THRESHOLDS.sponsorOperatorMinWei!;

  out.push(attempt('sponsor_gate_budget', async () => {
    const [max, remaining, endsAt, paymaster] = await Promise.all([
      read<number | bigint>('maxSponsorsPerWindow'), read<bigint>('remainingSponsorships'), read<bigint>('windowEndsAt'), read<Address>('PAYMASTER'),
    ]);
    const owner = await read<Address>('owner', paymaster);
    const budget = BigInt(max);
    const used = budget > remaining ? budget - remaining : 0n;
    const pct = budget === 0n ? 100 : Number((used * 10_000n) / budget) / 100;
    const until = endsAt === 0n ? 'the next addition opens a new window' : `the window closes in ${Math.max(0, Number(endsAt) - nowSeconds)}s`;
    const notes: string[] = [];
    let level: Level = 'ok';
    if (!isAddressEqual(owner, sg.gate)) {
      level = 'warn';
      notes.push(`the paymaster ${paymaster} is owned by ${owner}, not the gate: operators cannot sponsor, and that owner holds every paymaster power`);
    }
    if (budget === 0n) {
      level = worse(level, 'warn');
      notes.push('the budget is 0: operator sponsorship is stopped (a guardian or governor brake); new accounts are not sponsored until it is raised');
    } else if (remaining === 0n) {
      level = worse(level, 'fail');
      notes.push(`operators have added all ${budget} accounts this window: new accounts are not sponsored until ${until.replace('the window closes', 'it closes')}. `
        + 'Real demand: raise it with sponsor-gate:budget. Unexplained: a leaked operator key - read the gate\'s Sponsored events and revoke with sponsor-gate:operator <gate> <key> false');
    } else if (pct >= warnPercent) {
      level = worse(level, 'warn');
      notes.push(`operators have used ${pct}% of the window's ${budget} accounts; ${until}`);
    }
    return {
      id: 'sponsor_gate_budget', level, value: pct, threshold: warnPercent,
      detail: level === 'ok' ? `sponsor gate: ${remaining} of ${budget} accounts left this window; ${until}` : notes.join('; '),
    };
  }));

  for (const operator of sg.operators ?? []) {
    const id = `sponsor_operator_gas:${operator.toLowerCase()}`;
    out.push(attempt(id, async () => {
      const [bal, allowed] = await Promise.all([t.client.getBalance({ address: operator }), read<boolean>('isOperator', sg.gate, [operator])]);
      let level: Level = bal < minWei / 2n ? 'fail' : bal < minWei ? 'warn' : 'ok';
      const notes: string[] = [];
      if (level !== 'ok') {
        notes.push(`sponsorship operator ${operator} holds ${ETH(bal).toFixed(4)} ETH: fund it. Below the co-signer's COSIGNER_SPONSOR_MIN_BALANCE_WEI `
          + 'new accounts are refused sponsorship (operator_unfunded) and users cannot make their first operation');
      }
      if (!allowed) {
        level = worse(level, 'warn');
        notes.push(`${operator} is no longer an operator of the gate: its co-signer refuses sponsorship (operator_revoked). If that was not an incident response, add it back with sponsor-gate:operator`);
      }
      return {
        id, level, value: ETH(bal), threshold: ETH(minWei),
        detail: notes.length ? notes.join('; ') : `sponsorship operator ${operator} holds ${ETH(bal).toFixed(4)} ETH and is an operator`,
      };
    }));
  }
  return out;
}
