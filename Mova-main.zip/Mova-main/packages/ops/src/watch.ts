/**
 * The events a human has to see in time.
 *
 * Two protections in the contracts are notice periods, and a notice nobody reads protects
 * nobody:
 *
 * - **Scheduled governance changes.** `DelayedGovernance` makes every risk-raising change wait
 *   `GOVERNANCE_DELAY` after `ChangeScheduled`. That delay is for users and LPs to exit and for
 *   the client to cancel a change it did not intend - which only happens if someone is told.
 * - **Posted rulings.** Anyone may submit an arbitrator's signed ruling, so a stolen arbitrator
 *   key is stopped only by the day a ruling waits between `RulingPosted` and execution: revoke
 *   the arbitrator within it and the ruling is void.
 *
 * `runChecks` reads state; these need history. So this keeps a block cursor across sweeps,
 * folds in new logs each time, and reports every pending item as its own check - one alert per
 * change or ruling, not one alert for "some number of them" that goes quiet when a second one
 * arrives. When an item executes, is cancelled or expires, it is reported `ok` once, which
 * resolves its alert, and then forgotten.
 *
 * ## The oracles behind the watched contracts
 *
 * The price oracles are governed too - a PythFxOracle's feed and limits, a SignedPriceOracle's
 * publishers and threshold, a cross's legs, a feed oracle's feeds all wait out their own delay - and
 * a change scheduled on one moves an escrow's band, or the rate the Movva reserve mints at, without
 * any event on the escrow or the reserve. Nobody configures those addresses, so the watcher finds
 * them from what it already watches: an escrow's `AssetSet` names each asset's oracle, a
 * ChainlinkSignedFxOracle's `usdBrl()` and `LegsSet` its BRL-per-USD leg, a ScaledFxBandOracle's
 * `SOURCE()` the rate it rescales, and a reserve's `fxOracle()` and `OracleSet` its FX leg. Each one
 * found is watched from `fromBlock`, so a change scheduled before it was found is still reported, and
 * its alert says what it is the oracle of. A pointer read that the contract refuses (it is not that
 * kind of contract) is not asked again; one the RPC failed is.
 *
 * ## A PythFxOracle's settings
 *
 * Its limits change at once when they only tighten - no `ChangeScheduled`, so no notice - and a
 * tightening still moves who can trade: a `closedMaxAge` of 0 stops the ramps' bands outside the core
 * session, a `maxAge` under the Pyth keeper's refresh refuses the rate between posts. So `FeedSet` and
 * `LimitsSet` are folded into `oracle_settings:<oracle>`: `ok` with the current feed and limits, `warn`
 * once when they change after the watcher first reported them (and `ok` again on the next sweep, which
 * resolves it), and `warn` for as long as `closedMaxAge` is 0.
 */
import {
  BaseError, ContractFunctionRevertedError, ContractFunctionZeroDataError, decodeFunctionData, parseAbi,
  parseAbiItem, type Address, type Hex, type PublicClient,
} from 'viem';
import type { CheckResult } from './checks.js';
import { redactError } from './redact.js';

const EV = {
  scheduled: parseAbiItem('event ChangeScheduled(bytes32 indexed id, bytes4 indexed selector, bytes call, uint256 readyAt, uint256 expiresAt)'),
  cancelled: parseAbiItem('event ChangeCancelled(bytes32 indexed id)'),
  executed: parseAbiItem('event ChangeExecuted(bytes32 indexed id, bytes4 indexed selector)'),
  // FiatEscrow names the flag releasedToTaker and OffRampEscrow paidLP; the ABI types, and so the
  // topics, are identical, which is all a log filter looks at.
  posted: parseAbiItem('event RulingPosted(bytes32 indexed orderId, bool favoursCounterparty, address indexed arbitrator, bytes32 evidenceRoot, uint64 executableAt)'),
  resolved: parseAbiItem('event DisputeResolved(bytes32 indexed orderId, bool favoursCounterparty, address indexed arbitrator, bytes32 evidenceRoot)'),
  timedOut: parseAbiItem('event DisputeTimedOut(bytes32 indexed orderId)'),
  // Where a price comes from: each names another contract whose own governance moves that price.
  assetSet: parseAbiItem('event AssetSet(address indexed asset, address oracle, uint8 decimals, bool enabled)'),
  legsSet: parseAbiItem('event LegsSet(address assetUsd, address usdBrl, uint64 assetMaxAge, uint64 fxMaxAge)'),
  oracleSet: parseAbiItem('event OracleSet(address usdtUsdFeed, address fxOracle, uint64 usdtUsdMaxAge, uint64 fxMaxAge)'),
  // PythFxOracle's settings (see the header). MovvaReserve's LimitsSet has other types, so another topic.
  feedSet: parseAbiItem('event FeedSet(bytes32 usdBrlId)'),
  limitsSet: parseAbiItem('event LimitsSet(uint64 maxAge, uint64 closedMaxAge, uint16 maxConfBps)'),
} as const;

/** The same pointers as state, for a contract deployed before `fromBlock` or behind an adapter. */
const POINTERS = parseAbi([
  'function usdBrl() view returns (address)', // ChainlinkSignedFxOracle
  'function SOURCE() view returns (address)', // ScaledFxBandOracle
  'function fxOracle() view returns (address)', // MovvaReserve
]);
const POINTER_ROLE = {
  usdBrl: 'the BRL-per-USD leg of',
  SOURCE: 'the BRL-per-USD rate rescaled by',
  fxOracle: 'the FX leg the Movva reserve mints at, of',
} as const;

/** Setters that move a price, decoded in an alert so the reader sees what, not a selector. */
const PRICE_SETTERS = parseAbi([
  'function setPublisher(address publisher, bool active)',
  'function setThreshold(uint256 threshold)',
  'function setLegs(address assetUsd, address usdBrl, uint64 assetMaxAge, uint64 fxMaxAge)',
  'function setFeeds(address ethUsd, address brlUsd, uint64 maxAge)',
  'function setFeeds(bytes32 ethUsdId, bytes32 usdBrlId, uint256 maxAge, uint256 maxConfBps)',
  'function setOracle(address feed, address fx, uint64 feedMaxAge, uint64 fxMaxAge)',
  'function setAsset(address asset, address oracle, uint8 decimals, bool enabled)',
  'function setFeed(bytes32 usdBrlId)', // PythFxOracle
  'function setLimits(uint64 maxAge, uint64 closedMaxAge, uint16 maxConfBps)', // PythFxOracle
]);

/**
 * Setters that move who is paid Mova's fees (FeeSplitter, NodeRewards, the registry's rewards hook), decoded in an alert
 * the same way: a scheduled `setLpRewardShare(5000)` should read as that, not as a selector.
 */
const REWARD_SETTERS = parseAbi([
  'function setLpRewardShare(uint16 bps)',
  'function setTreasury(address t)',
  'function setRewards(address r)',
  'function setRegistry(address r)',
  'function setRewardLimits(uint16 bpsOfVolume, uint256 lpCap, uint256 minCents)',
  'function setExcluded(address lp, bool isExcluded)',
  'function setRewardsHook(address hook)',
]);

export interface PostedRuling {
  escrow: Address;
  orderId: Hex;
  arbitrator: Address;
  evidenceRoot: Hex;
  favoursCounterparty: boolean;
  executableAt: number;
}

export interface WatchOptions {
  /** `readContract` is optional: without it, oracles are still followed through events. */
  client: Pick<PublicClient, 'getBlockNumber' | 'getLogs'> & Partial<Pick<PublicClient, 'readContract'>>;
  /** Contracts inheriting DelayedGovernance: escrows, registry, verifiers, vault. */
  governed?: Address[];
  /** FiatEscrow and OffRampEscrow. */
  escrows?: Address[];
  /** First block to read: the deployment block. Reading from 0 asks a node for all history. */
  fromBlock: bigint;
  /** Largest getLogs span to ask for; halved on refusal, since providers cap it silently. */
  span?: bigint;
  /** Also watch the price oracles the watched contracts point at (see the header). Default true. */
  followOracles?: boolean;
  /**
   * The arbitration desk's own answer to "which of these did I never sign"
   * (`ArbitrationDesk.postedRulingsNotSigned`). A posted ruling in that list is a stolen key
   * in use, and escalates from warn to fail.
   */
  unsignedByDesk?: (posted: PostedRuling[]) => Promise<PostedRuling[]>;
  redactValues?: readonly (string | undefined)[];
}

interface PendingChange { contract: Address; id: Hex; selector: Hex; call?: Hex; readyAt: number; expiresAt: number }
interface PythSettings { feed?: Hex; limits?: { maxAge: bigint; closedMaxAge: bigint; maxConfBps: number }; block: bigint }
interface Found { address: Address; via: string }
type Log = { address: Address; eventName: string; args: Record<string, unknown> };

const short = (a: string) => `${a.slice(0, 10)}…`;
const iso = (ts: number) => new Date(ts * 1000).toISOString();
const key = (a: string) => a.toLowerCase();
const ZERO = '0x0000000000000000000000000000000000000000';

/** `setPublisher(0x…, true)` for a known price or reward setter; undefined for anything else. */
export function describeCall(call: Hex | undefined): string | undefined {
  if (!call || call.length < 10) return undefined;
  for (const abi of [PRICE_SETTERS, REWARD_SETTERS]) {
    try {
      const { functionName, args } = decodeFunctionData({ abi, data: call });
      return `${functionName}(${(args ?? []).map(String).join(', ')})`;
    } catch {
      // not one of this list's setters
    }
  }
  return undefined;
}

/** The contract answered - reverted, or has no such function - as opposed to the read failing. */
const refusedByContract = (e: unknown) => e instanceof BaseError
  && !!e.walk((x) => x instanceof ContractFunctionRevertedError || x instanceof ContractFunctionZeroDataError);

export class EventWatcher {
  private cursor: bigint;
  private readonly changes = new Map<string, PendingChange>();
  private readonly rulings = new Map<string, PostedRuling>();
  /** Items that stopped being pending since the last report, to be reported `ok` once. */
  private readonly settled = new Map<string, string>();
  /** Oracles found through the watched contracts, by lowercased address, with how. */
  private readonly followed = new Map<string, Found>();
  /** Found but not yet watched: their history is read before they join `followed`. */
  private readonly found = new Map<string, Found>();
  /** The batch whose history is being read now, so oracles pointing at each other are noted once. */
  private readonly adopting = new Set<string>();
  /** `address:getter` pairs the contract has answered, or refused for good. */
  private readonly probed = new Set<string>();
  /** PythFxOracle settings by lowercased address, from FeedSet and LimitsSet; and what was last reported of each. */
  private readonly pythSettings = new Map<string, PythSettings & { address: Address }>();
  private readonly pythReported = new Map<string, string>();
  private lastError?: string;

  constructor(private readonly o: WatchOptions) {
    this.cursor = o.fromBlock;
  }

  private get follow(): boolean {
    return this.o.followOracles ?? true;
  }

  /** Governed contracts: the configured ones and every oracle followed so far. */
  private governed(): Address[] {
    return [...(this.o.governed ?? []), ...[...this.followed.values()].map((f) => f.address)];
  }

  private watching(a: string): boolean {
    return this.followed.has(key(a)) || [...(this.o.governed ?? [])].some((g) => key(g) === key(a));
  }

  /** Fold in every relevant log up to the current head. Errors are kept for `checks`. */
  async sync(): Promise<void> {
    try {
      const head = await this.o.client.getBlockNumber({ cacheTime: 0 });
      const known = new Map([...this.governed(), ...(this.o.escrows ?? [])].map((a) => [key(a), a]));
      for (const a of known.values()) await this.probe(a);
      await this.adopt(this.cursor - 1n);
      let span = this.o.span ?? 5_000n;
      while (this.cursor <= head) {
        const to = this.cursor + span - 1n > head ? head : this.cursor + span - 1n;
        try {
          await this.fold(this.governed(), this.o.escrows ?? [], this.cursor, to);
          this.cursor = to + 1n;
        } catch (e) {
          if (span <= 1n) throw e;
          span /= 2n;
          continue;
        }
        await this.adopt(to);
      }
      this.lastError = undefined;
    } catch (e) {
      this.lastError = redactError(e, this.o.redactValues ?? []);
    }
  }

  private async fold(governed: Address[], escrows: Address[], fromBlock: bigint, toBlock: bigint): Promise<void> {
    const pointers = this.follow ? [EV.assetSet, EV.legsSet, EV.oracleSet] : [];
    const get = (address: Address[], events: readonly unknown[]) => address.length
      ? this.o.client.getLogs({ address, events: events as never, fromBlock, toBlock })
      : Promise.resolve([]);
    const [gov, esc] = await Promise.all([
      get(governed, [EV.scheduled, EV.cancelled, EV.executed, EV.feedSet, EV.limitsSet, ...pointers]),
      get(escrows, [EV.posted, EV.resolved, EV.timedOut, ...pointers]),
    ]);
    // Logs within one span may interleave events from both sets; within each set the node returns
    // them in chain order, which is the order that matters for pending/settled.
    for (const l of gov as unknown as Log[]) {
      if (this.pointer(l) || this.settings(l as Log & { blockNumber?: bigint })) continue;
      const k = `governance_change:${key(l.address)}:${String(l.args.id).slice(0, 18)}`;
      if (l.eventName === 'ChangeScheduled') {
        this.settled.delete(k);
        this.changes.set(k, {
          contract: l.address, id: l.args.id as Hex, selector: l.args.selector as Hex, call: l.args.call as Hex,
          readyAt: Number(l.args.readyAt), expiresAt: Number(l.args.expiresAt),
        });
      } else {
        const was = this.changes.get(k);
        if (this.changes.delete(k)) {
          const what = describeCall(was?.call);
          this.settled.set(k, `${l.eventName === 'ChangeExecuted' ? 'executed' : 'cancelled'} on ${short(l.address)}${what ? `: ${what}` : ''}`);
        }
      }
    }
    for (const l of esc as unknown as Log[]) {
      if (this.pointer(l)) continue;
      const k = `posted_ruling:${key(l.address)}:${String(l.args.orderId).slice(0, 18)}`;
      if (l.eventName === 'RulingPosted') {
        this.settled.delete(k);
        this.rulings.set(k, {
          escrow: l.address, orderId: l.args.orderId as Hex, arbitrator: l.args.arbitrator as Address,
          evidenceRoot: l.args.evidenceRoot as Hex, favoursCounterparty: l.args.favoursCounterparty as boolean,
          executableAt: Number(l.args.executableAt),
        });
      } else if (this.rulings.delete(k)) {
        this.settled.set(k, `${l.eventName === 'DisputeResolved' ? 'ruling executed' : 'dispute timed out'} on ${short(l.address)}`);
      }
    }
  }

  /** A pointer event: note the contract it names. True if `l` was one. */
  private pointer(l: Log): boolean {
    if (l.eventName === 'AssetSet') {
      const asset = String(l.args.asset);
      this.note(l.args.oracle as Address, `the band of ${key(asset) === ZERO ? 'native ETH' : `asset ${short(asset)}`} on ${short(l.address)}`);
    } else if (l.eventName === 'LegsSet') {
      this.note(l.args.usdBrl as Address, `the BRL-per-USD leg of ${short(l.address)}`);
    } else if (l.eventName === 'OracleSet') {
      this.note(l.args.fxOracle as Address, `the FX leg the Movva reserve mints at, of ${short(l.address)}`);
    } else {
      return false;
    }
    return true;
  }

  /** A PythFxOracle settings event: fold it into that oracle's settings. True if `l` was one. */
  private settings(l: Log & { blockNumber?: bigint }): boolean {
    if (l.eventName !== 'FeedSet' && l.eventName !== 'LimitsSet') return false;
    const k = key(l.address);
    const s = this.pythSettings.get(k) ?? { address: l.address, block: 0n };
    if (l.eventName === 'FeedSet') s.feed = l.args.usdBrlId as Hex;
    else s.limits = { maxAge: l.args.maxAge as bigint, closedMaxAge: l.args.closedMaxAge as bigint, maxConfBps: Number(l.args.maxConfBps) };
    s.block = l.blockNumber ?? s.block;
    this.pythSettings.set(k, s);
    return true;
  }

  private note(address: Address | undefined, via: string): void {
    if (!address || key(address) === ZERO || this.watching(address) || this.found.has(key(address))
      || this.adopting.has(key(address))) return;
    this.found.set(key(address), { address, via });
  }

  /** Ask a contract what oracle it points at, once each getter answers or refuses for good. */
  private async probe(address: Address): Promise<void> {
    if (!this.follow || !this.o.client.readContract) return;
    for (const fn of ['usdBrl', 'SOURCE', 'fxOracle'] as const) {
      const k = `${key(address)}:${fn}`;
      if (this.probed.has(k)) continue;
      try {
        const target = await this.o.client.readContract({ address, abi: POINTERS, functionName: fn }) as Address;
        this.probed.add(k);
        this.note(target, `${POINTER_ROLE[fn]} ${short(address)}`);
      } catch (e) {
        // Not that kind of contract: never ask again. The read failed: ask on the next sync.
        if (refusedByContract(e)) this.probed.add(k);
      }
    }
  }

  /**
   * Start watching everything found, from `fromBlock` up to `upTo`, so a change scheduled before an
   * oracle was found is not missed. What they point at is found in turn. An address joins the
   * watched set only once its history is read; if that read fails, it is tried again next sync.
   */
  private async adopt(upTo: bigint): Promise<void> {
    while (this.found.size) {
      const batch = [...this.found.values()];
      this.found.clear();
      for (const f of batch) this.adopting.add(key(f.address));
      const addresses = batch.map((f) => f.address);
      let from = this.o.fromBlock;
      let span = this.o.span ?? 5_000n;
      try {
        for (const f of batch) await this.probe(f.address);
        while (from <= upTo) {
          const to = from + span - 1n > upTo ? upTo : from + span - 1n;
          try {
            await this.fold(addresses, [], from, to);
            from = to + 1n;
          } catch (e) {
            if (span <= 1n) throw e;
            span /= 2n;
          }
        }
      } catch (e) {
        for (const f of batch) this.found.set(key(f.address), f);
        throw e;
      } finally {
        this.adopting.clear();
      }
      for (const f of batch) this.followed.set(key(f.address), f);
    }
  }

  /** One result per pending item, plus `ok` once for each that settled since the last call. */
  async checks(nowSeconds: number = Math.floor(Date.now() / 1000)): Promise<CheckResult[]> {
    const out: CheckResult[] = [];
    const oracles = this.followed.size ? `; ${this.followed.size} price oracle(s) followed from the watched contracts` : '';
    if (this.lastError) out.push({ id: 'event_watch', level: 'unknown', detail: `event history could not be read: ${this.lastError}` });
    else out.push({ id: 'event_watch', level: 'ok', detail: `read to block ${this.cursor - 1n}${oracles}` });

    for (const [k, c] of this.changes) {
      const what = describeCall(c.call) ?? c.selector;
      if (nowSeconds > c.expiresAt) {
        // Never executed within its window: it can no longer run. Treat as settled.
        this.changes.delete(k);
        out.push({ id: k, level: 'ok', detail: `scheduled change ${what} on ${short(c.contract)} expired unexecuted` });
        continue;
      }
      const when = nowSeconds >= c.readyAt ? `executable now, until ${iso(c.expiresAt)}` : `executable from ${iso(c.readyAt)}`;
      const via = this.followed.get(key(c.contract))?.via;
      out.push({
        id: k, level: 'warn', value: c.readyAt,
        detail: `governance change ${what} scheduled on ${c.contract}${via ? `, ${via},` : ''} (${when}). Confirm it was intended; `
          + `if not, cancel it with gov:cancel and warn users and LPs.`,
      });
    }

    let unsigned = new Set<string>();
    if (this.o.unsignedByDesk && this.rulings.size) {
      try {
        const bad = await this.o.unsignedByDesk([...this.rulings.values()]);
        unsigned = new Set(bad.map((r) => `posted_ruling:${key(r.escrow)}:${r.orderId.slice(0, 18)}`));
      } catch (e) {
        out.push({ id: 'desk_crosscheck', level: 'unknown', detail: `desk could not be asked: ${redactError(e, this.o.redactValues ?? [])}` });
      }
    }
    for (const [k, r] of this.rulings) {
      const stolen = unsigned.has(k);
      out.push({
        id: k, level: stolen ? 'fail' : 'warn', value: r.executableAt,
        detail: stolen
          ? `ruling on ${r.orderId} at ${r.escrow} was posted under arbitrator ${r.arbitrator} but the desk never `
            + `signed it: revoke the arbitrator NOW (escrow:arbitrator ... false), before ${iso(r.executableAt)}`
          : `ruling on ${r.orderId} at ${short(r.escrow)} by ${short(r.arbitrator)} executes from ${iso(r.executableAt)}`,
      });
    }

    for (const [k, s] of this.pythSettings) {
      const via = this.followed.get(k)?.via;
      const limits = s.limits
        ? `maxAge ${s.limits.maxAge}s, closedMaxAge ${s.limits.closedMaxAge}s, maxConfBps ${s.limits.maxConfBps}` : 'limits not seen';
      const now = `feed ${s.feed ?? 'not seen'}, ${limits}`;
      const before = this.pythReported.get(k);
      this.pythReported.set(k, now);
      const where = `PythFxOracle ${s.address}${via ? `, ${via},` : ''}`;
      const off = s.limits?.closedMaxAge === 0n
        ? '. closedMaxAge is 0: the ramps\' bands refuse outside the core session, so LPs cannot trade while the FX market is closed' : '';
      if (before !== undefined && before !== now) {
        out.push({
          id: `oracle_settings:${k}`, level: 'warn', value: Number(s.block),
          detail: `${where} changed at block ${s.block}: ${before} -> ${now}${off}. A tightening applies at once without a schedule; confirm it was intended`,
        });
      } else {
        out.push({ id: `oracle_settings:${k}`, level: off ? 'warn' : 'ok', value: Number(s.block), detail: `${where}: ${now}${off}` });
      }
    }

    for (const [k, detail] of this.settled) out.push({ id: k, level: 'ok', detail });
    this.settled.clear();
    return out;
  }
}
