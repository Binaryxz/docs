import { describe, expect, it, vi } from 'vitest';
import { Alerter, webhookSink, type Alert } from '../src/alerts.js';
import type { CheckResult, Level } from '../src/checks.js';

const r = (level: Level, id = 'oracle_freshness', detail = 'x'): CheckResult => ({ id, level, detail });

function collect() {
  const seen: Alert[] = [];
  return { seen, sink: (a: Alert) => { seen.push(a); } };
}

describe('alerts are edges, not levels', () => {
  /**
   * The property that keeps a monitor trusted: a page every poll trains people to mute it,
   * and a muted monitor buys silence rather than safety.
   */
  it('fires once when a check goes bad and stays quiet while it stays bad', async () => {
    const { seen, sink } = collect();
    const a = new Alerter(sink);

    await a.observe([r('fail')], 1_000);
    await a.observe([r('fail')], 2_000);
    await a.observe([r('fail')], 3_000);

    expect(seen).toHaveLength(1);
    expect(seen[0]).toMatchObject({ kind: 'firing', level: 'fail', id: 'oracle_freshness' });
  });

  it('sends a resolution when the check recovers', async () => {
    const { seen, sink } = collect();
    const a = new Alerter(sink);

    await a.observe([r('fail')], 1_000);
    await a.observe([r('ok')], 2_000);

    expect(seen.map((x) => x.kind)).toEqual(['firing', 'resolved']);
  });

  /** Nobody was told there was a problem, so nobody needs telling it is over. */
  it('does not announce a recovery it never reported', async () => {
    const { seen, sink } = collect();
    const a = new Alerter(sink);

    await a.observe([r('ok')], 1_000);
    await a.observe([r('ok')], 2_000);

    expect(seen).toHaveLength(0);
  });

  it('fires again when severity escalates from warn to fail', async () => {
    const { seen, sink } = collect();
    const a = new Alerter(sink);

    await a.observe([r('warn')], 1_000);
    await a.observe([r('fail')], 2_000);

    expect(seen.map((x) => x.level)).toEqual(['warn', 'fail']);
  });

  it('fires a fresh alert for a second episode after a recovery', async () => {
    const { seen, sink } = collect();
    const a = new Alerter(sink);

    await a.observe([r('fail')], 1_000);
    await a.observe([r('ok')], 2_000);
    await a.observe([r('fail')], 3_000);

    expect(seen.map((x) => x.kind)).toEqual(['firing', 'resolved', 'firing']);
  });
});

describe('unknown has a longer fuse', () => {
  /** One failed RPC call is not an outage; five minutes of them is. */
  it('stays silent inside the grace period', async () => {
    const { seen, sink } = collect();
    const a = new Alerter(sink, { unknownGraceMs: 300_000 });

    await a.observe([r('unknown')], 1_000);
    await a.observe([r('unknown')], 100_000);

    expect(seen).toHaveLength(0);
  });

  it('fires once the endpoint has been unreadable for long enough', async () => {
    const { seen, sink } = collect();
    const a = new Alerter(sink, { unknownGraceMs: 300_000 });

    await a.observe([r('unknown')], 1_000);
    await a.observe([r('unknown')], 400_000);

    expect(seen).toHaveLength(1);
    expect(seen[0].level).toBe('unknown');
  });

  it('measures the episode, not the gap between polls', async () => {
    const { seen, sink } = collect();
    const a = new Alerter(sink, { unknownGraceMs: 300_000 });

    for (const t of [1_000, 60_000, 120_000, 180_000, 240_000]) await a.observe([r('unknown')], t);
    expect(seen).toHaveLength(0);

    await a.observe([r('unknown')], 302_000);
    expect(seen).toHaveLength(1);
  });

  it('resets the fuse when the endpoint recovers in between', async () => {
    const { seen, sink } = collect();
    const a = new Alerter(sink, { unknownGraceMs: 300_000 });

    await a.observe([r('unknown')], 1_000);
    await a.observe([r('ok')], 200_000);
    await a.observe([r('unknown')], 250_000);
    await a.observe([r('unknown')], 400_000);

    expect(seen).toHaveLength(0);
  });
});

describe('firing list', () => {
  it('names what is currently alerting, for the status endpoint', async () => {
    const { sink } = collect();
    const a = new Alerter(sink);

    await a.observe([r('fail', 'oracle_freshness'), r('warn', 'relayer_gas'), r('ok', 'vault_drawdown')], 1_000);
    expect(a.firing.sort()).toEqual(['oracle_freshness', 'relayer_gas']);

    await a.observe([r('ok', 'oracle_freshness'), r('warn', 'relayer_gas'), r('ok', 'vault_drawdown')], 2_000);
    expect(a.firing).toEqual(['relayer_gas']);
  });
});

describe('webhook delivery', () => {
  it('posts the alert as JSON with a readable text line', async () => {
    const calls: { url: string; body: unknown }[] = [];
    const fetchImpl = vi.fn(async (url: string, init?: { body?: string }) => {
      calls.push({ url, body: JSON.parse(String(init?.body)) });
      return { ok: true, status: 200 } as Response;
    }) as unknown as typeof fetch;

    await webhookSink('https://hooks.example/x', { fetchImpl })(
      { id: 'relayer_gas', kind: 'firing', level: 'warn', detail: 'relayer holds 0.01 ETH', at: 1 },
    );

    expect(calls).toHaveLength(1);
    expect((calls[0].body as { text: string }).text).toBe('[WARN] relayer_gas: relayer holds 0.01 ETH');
  });

  /** An alerting system that crashes the service it watches has inverted its purpose. */
  it('reports a delivery failure instead of throwing', async () => {
    const onError = vi.fn();
    const fetchImpl = (async () => { throw new Error('network down'); }) as unknown as typeof fetch;

    await expect(
      webhookSink('https://hooks.example/x', { fetchImpl, onError })(
        { id: 'x', kind: 'firing', level: 'fail', detail: 'y', at: 1 },
      ),
    ).resolves.toBeUndefined();
    expect(onError).toHaveBeenCalledOnce();
  });

  it('reports a non-2xx response as a delivery failure', async () => {
    const onError = vi.fn();
    const fetchImpl = (async () => ({ ok: false, status: 429 })) as unknown as typeof fetch;

    await webhookSink('https://hooks.example/x', { fetchImpl, onError })(
      { id: 'x', kind: 'firing', level: 'fail', detail: 'y', at: 1 },
    );
    expect(onError.mock.calls[0][0]).toBeInstanceOf(Error);
    expect(String(onError.mock.calls[0][0])).toContain('429');
  });
});
