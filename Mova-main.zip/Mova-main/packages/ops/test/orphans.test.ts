import { describe, expect, it } from 'vitest';
import { execFileSync } from 'node:child_process';
import { existsSync, readdirSync, readFileSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { getAddress, keccak256, toHex, type Address } from 'viem';
import { ASP_POSTMAN, BURN, OWNER_ROLE, OrphanWatcher, ownerOf, parseAbandoned, type AbandonedRecord } from '../src/orphans.js';

const ROOT = fileURLToPath(new URL('../../../', import.meta.url));
const RECORD_PATH = 'deployments/abandoned-sepolia-2026-09-08.json';
const RENOUNCED_PATH = 'deployments/abandoned-sepolia-2026-09-21.json';
const load = (p: string) => parseAbandoned(readFileSync(join(ROOT, p), 'utf8'));
const record = load(RECORD_PATH);
const renounced = load(RENOUNCED_PATH);
/** Every abandonment record in the repo: each is scanned for on its own. */
const RECORDS = readdirSync(join(ROOT, 'deployments')).filter((f) => /^abandoned-.*\.json$/.test(f)).map((f) => `deployments/${f}`);

/**
 * The repo check. The abandoned Sepolia stack (the record above) must be named by nothing current: no script,
 * config, deployment JSON, source or test outside the record itself, the historical files it lists, and the
 * prose under docs/. A reference here is a place that would send a user, a script or a frontend to a contract
 * whose owner key is lost.
 */
describe.each(RECORDS)('nothing current points at the abandoned stack in %s', (path) => {
  const record = load(path);
  const needles = [ownerOf(record), ...record.contracts.map((c) => c.address)].map((a) => a.slice(2).toLowerCase());
  const files = execFileSync('git', ['ls-files', '--cached', '--others', '--exclude-standard', '-z'], { cwd: ROOT, maxBuffer: 64 * 1024 * 1024 })
    .toString().split('\0').filter(Boolean);
  const allowed = new Set([...RECORDS, ...record.historicalRecords.map((h) => h.path)]);
  const stale = new Set(record.knownStaleReferences.map((s) => s.path));
  const inDocs = (p: string) => p.startsWith('docs/');
  const BINARY = /\.(png|jpg|jpeg|gif|webp|ico|woff2?|ttf|zip|gz|wasm|zkey|pdf|bin)$/i;

  const hits = (p: string): string[] => {
    const abs = join(ROOT, p);
    if (BINARY.test(p) || !existsSync(abs)) return [];
    let text: string;
    // Generated and vendored blobs (lockfiles, circuit artifacts) are not places an address is configured.
    if (statSync(abs).size > 1_000_000) return [];
    try { text = readFileSync(abs, 'utf8').toLowerCase(); } catch { return []; }
    return needles.filter((n) => text.includes(n));
  };

  it('finds the files to scan', () => {
    expect(files.length).toBeGreaterThan(100);
    expect(files).toContain(path);
  });

  it('no script, config, deployment JSON or source names an abandoned address', { timeout: 60_000 }, () => {
    const offenders = files.filter((p) => !allowed.has(p) && !inDocs(p) && !stale.has(p)).filter((p) => hits(p).length > 0);
    expect(offenders, `files naming the abandoned stack (move the reference to the record, or delete it): ${offenders.join(', ')}`).toEqual([]);
  });

  it('every known stale reference still exists - and is removed from the record once fixed', () => {
    for (const s of record.knownStaleReferences) expect(hits(s.path).length, `${s.path} no longer names the stack: remove it from knownStaleReferences`).toBeGreaterThan(0);
  });

  it('every historical record still names the stack, or is dropped from the record', () => {
    for (const h of record.historicalRecords) expect(hits(h.path).length, h.path).toBeGreaterThan(0);
  });

  it('names its owner as a checksummed address', () => {
    expect(ownerOf(record)).toBe(getAddress(ownerOf(record)));
  });
});

describe('the records', () => {
  it('lists both abandoned stacks', () => {
    expect(RECORDS).toEqual(expect.arrayContaining([RECORD_PATH, RENOUNCED_PATH]));
  });

  it('8 September: eight contracts, owner key lost', () => {
    expect(record.contracts.length).toBe(8);
    expect(record.lostOwner).toBeDefined();
    expect(record.renouncedOwner).toBeUndefined();
  });

  it('21 September: seven contracts, roles renounced, its own check id, and not the shared Poseidon libraries', () => {
    expect(renounced.contracts.length).toBe(7);
    expect(renounced.renouncedOwner).toBeDefined();
    expect(renounced.lostOwner).toBeUndefined();
    expect(renounced.watchId).toBe('orphan_watch:2026-09-21');
    const listed = renounced.contracts.map((c) => c.address.toLowerCase());
    for (const poseidon of ['0x8ffda7ed8b4ad98c2c34f54b76821711f4a6f2c5', '0xe393dd7287db9982e6f845824854baf8b8e823af']) expect(listed).not.toContain(poseidon);
    const live = readFileSync(join(ROOT, 'deployments/sepolia-movva-rail.json'), 'utf8').toLowerCase();
    for (const a of listed) expect(live, `${a} is part of the live rail`).not.toContain(a.slice(2));
  });

  it('refuses a record naming both, or neither, kind of owner', () => {
    const base = JSON.parse(readFileSync(join(ROOT, RENOUNCED_PATH), 'utf8')) as AbandonedRecord;
    expect(() => parseAbandoned(JSON.stringify({ ...base, lostOwner: base.renouncedOwner }))).toThrow(/exactly one/);
    expect(() => parseAbandoned(JSON.stringify({ ...base, renouncedOwner: undefined }))).toThrow(/exactly one/);
  });
});

/** The monitor: a fake chain whose logs, nonce and role state the test sets. */
const [ENTRY, PAYMASTER] = [record.contracts[0].address, record.contracts[7].address];
const OWNER = record.lostOwner;
const OTHER = '0x00000000000000000000000000000000000000ee' as Address;
type FakeLog = { address: Address; topics: string[]; transactionHash: string; logIndex: number; blockNumber: bigint };

function chain() {
  const s = { head: 100n, nonce: 7, logs: [] as FakeLog[], ownerHasRole: true, paymasterOwner: OWNER as Address, fail: false };
  const client = {
    getBlockNumber: async () => { if (s.fail) throw new Error('rpc down https://secret'); return s.head; },
    getTransactionCount: async () => s.nonce,
    getLogs: async (a: { fromBlock: bigint; toBlock: bigint }) => s.logs.filter((l) => l.blockNumber >= a.fromBlock && l.blockNumber <= a.toBlock),
    readContract: async (a: { functionName: string }) => (a.functionName === 'hasRole' ? s.ownerHasRole : s.paymasterOwner),
  };
  return { s, client: client as never };
}
const one = async (w: OrphanWatcher) => (await w.sweep()).find((r) => r.id === 'orphan_watch')!;

describe('orphan_watch', () => {
  it('is quiet while nothing happens, and baselines at the first sweep', async () => {
    const { s, client } = chain();
    s.logs.push({ address: ENTRY, topics: [keccak256(toHex('Anything()'))], transactionHash: '0xold', logIndex: 0, blockNumber: 50n });
    const w = new OrphanWatcher({ client, record });
    expect((await one(w)).level).toBe('ok');
    s.head = 200n;
    expect((await one(w)).level).toBe('ok');
  });

  it('fails on any new transaction touching a listed contract, and stays failed', async () => {
    const { s, client } = chain();
    const w = new OrphanWatcher({ client, record });
    await one(w);
    s.head = 120n;
    s.logs.push({ address: record.contracts[1].address, topics: [keccak256(toHex('Deposited(address)'))], transactionHash: '0xabc', logIndex: 3, blockNumber: 110n });
    const r = await one(w);
    expect(r.level).toBe('fail');
    expect(r.detail).toContain('0xabc');
    s.head = 130n;
    expect((await one(w)).level).toBe('fail');
  });

  it('names a role event, whoever sent it', async () => {
    const { s, client } = chain();
    const w = new OrphanWatcher({ client, record });
    await one(w);
    s.head = 120n;
    s.logs.push({ address: ENTRY, topics: [keccak256(toHex('RoleGranted(bytes32,address,address)'))], transactionHash: '0xdef', logIndex: 0, blockNumber: 105n });
    const r = await one(w);
    expect(r.level).toBe('fail');
    expect(r.detail).toContain('ROLE EVENT RoleGranted');
    expect(r.detail).toContain('renounce');
  });

  it('fails when the lost key signs anything, anywhere on the chain', async () => {
    const { s, client } = chain();
    const w = new OrphanWatcher({ client, record });
    await one(w);
    s.nonce = 8;
    expect((await one(w)).detail).toContain('lost owner');
  });

  it('fails when OWNER_ROLE or the paymaster owner is no longer the lost key', async () => {
    const a = chain();
    const wa = new OrphanWatcher({ client: a.client, record });
    await one(wa);
    a.s.ownerHasRole = false;
    expect((await one(wa)).detail).toContain('OWNER_ROLE');
    const b = chain();
    const wb = new OrphanWatcher({ client: b.client, record });
    await one(wb);
    b.s.paymasterOwner = OTHER;
    expect((await one(wb)).detail).toContain('now owned by');
  });

  it('is unknown, not ok, when the chain cannot be read, and redacts the error', async () => {
    const { s, client } = chain();
    s.fail = true;
    const r = await one(new OrphanWatcher({ client, record, redactValues: ['https://secret'] }));
    expect(r.level).toBe('unknown');
    expect(r.detail).not.toContain('https://secret');
  });

  it('honours a recorded baseline block: history after it is not forgiven', async () => {
    const { s, client } = chain();
    s.logs.push({ address: ENTRY, topics: ['0x1'], transactionHash: '0xlate', logIndex: 0, blockNumber: 90n });
    const r = await one(new OrphanWatcher({ client, record, baselineBlock: 80n }));
    expect(r.level).toBe('fail');
    expect(r.detail).toContain('0xlate');
  });

  it('uses the same role hash the Entrypoint does', () => {
    expect(OWNER_ROLE).toBe(keccak256(toHex('OWNER_ROLE')));
  });
});

/** The renounced stack: the former owner must hold nothing, and every governor must be the burn address. */
describe('orphan_watch for a renounced stack', () => {
  const EP = renounced.contracts[0].address;
  function renouncedChain() {
    const s = { head: 100n, nonce: 4, logs: [] as FakeLog[], roles: new Set<string>(), governor: BURN as Address };
    const client = {
      getBlockNumber: async () => s.head,
      getTransactionCount: async () => s.nonce,
      getLogs: async (a: { fromBlock: bigint; toBlock: bigint }) => s.logs.filter((l) => l.blockNumber >= a.fromBlock && l.blockNumber <= a.toBlock),
      readContract: async (a: { functionName: string; args?: readonly unknown[] }) =>
        a.functionName === 'hasRole' ? s.roles.has(String(a.args![0])) : s.governor,
    };
    return { s, client: client as never };
  }

  it('is quiet once everything is renounced, under its own check id', async () => {
    const { client } = renouncedChain();
    const r = (await new OrphanWatcher({ client, record: renounced }).sweep())[0];
    expect(r.id).toBe('orphan_watch:2026-09-21');
    expect(r.level).toBe('ok');
    expect(r.detail).toContain('former owner');
  });

  it('fails while the former owner still holds OWNER_ROLE or ASP_POSTMAN', async () => {
    for (const role of [OWNER_ROLE, ASP_POSTMAN]) {
      const { s, client } = renouncedChain();
      s.roles.add(role);
      const r = (await new OrphanWatcher({ client, record: renounced }).sweep())[0];
      expect(r.level).toBe('fail');
      expect(r.detail).toContain('still held by the former owner');
    }
  });

  it('fails while a governor is anything but the burn address', async () => {
    const { s, client } = renouncedChain();
    s.governor = renounced.renouncedOwner!;
    const r = (await new OrphanWatcher({ client, record: renounced }).sweep())[0];
    expect(r.level).toBe('fail');
    expect(r.detail).toContain('not the burn address');
  });

  it('fails on a role event, and on the former key signing anything', async () => {
    const { s, client } = renouncedChain();
    // The fake chain starts at block 100, below the record's real baseline (the renunciation block).
    const w = new OrphanWatcher({ client, record: renounced, baselineBlock: 99n });
    await w.sweep();
    s.head = 120n;
    s.nonce = 5;
    s.logs.push({ address: EP, topics: [keccak256(toHex('RoleGranted(bytes32,address,address)'))], transactionHash: '0x9', logIndex: 0, blockNumber: 110n });
    const r = (await w.sweep())[0];
    expect(r.level).toBe('fail');
    expect(r.detail).toContain('nobody should be able to grant one');
    expect(r.detail).toContain('nothing should sign with it');
  });
});
