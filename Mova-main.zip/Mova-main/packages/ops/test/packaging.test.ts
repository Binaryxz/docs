import { describe, expect, it } from 'vitest';
import { existsSync, readFileSync, readdirSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';

/**
 * The deployment files, checked without Docker.
 *
 * Every defect here was invisible to the unit tests and fatal in production: the image ran
 * `npx tsx` with tsx left out by `npm ci --omit=dev`, the matcher spec launched a demo that
 * deploys mock contracts with anvil's key #0, and the compose file referenced an entrypoint
 * that did not exist. None needs a container to catch - only someone reading the files the
 * way the container will.
 */

const ROOT = fileURLToPath(new URL('../../../', import.meta.url));
const read = (p: string) => readFileSync(join(ROOT, p), 'utf8');

interface Launch { source: string; argv: string[] }

function launches(): Launch[] {
  const out: Launch[] = [];

  const docker = read('packages/ops/Dockerfile');
  const cmd = /^CMD\s+(\[.*\])\s*$/m.exec(docker);
  if (!cmd) throw new Error('Dockerfile has no exec-form CMD');
  out.push({ source: 'Dockerfile CMD', argv: JSON.parse(cmd[1]) });

  // Every `command:` in the compose file is written as a JSON array, including commented
  // ones - a commented entry is still documentation someone will uncomment.
  const compose = read('packages/ops/docker-compose.yml');
  for (const m of compose.matchAll(/command:\s*(\[.*\])/g)) {
    out.push({ source: `docker-compose ${m[1]}`, argv: JSON.parse(m[1]) });
  }

  for (const spec of ['monitor.json', 'matcher.json', 'vault.json', 'vault-keeper.json', 'hl-keeper.json', 'pyth-keeper.json']) {
    const j = JSON.parse(read(`packages/ops/flux/${spec}`)) as { compose: { commands: string[] }[] };
    for (const c of j.compose) out.push({ source: `flux/${spec}`, argv: c.commands });
  }
  return out;
}

describe('what the image launches', () => {
  const all = launches();

  it('finds every launch site', () => {
    // Dockerfile, eight compose services, six Flux specs.
    expect(all.length).toBe(15);
  });

  it.each(all.map((l) => [l.source, l]))('%s runs an existing production entrypoint', (_s, l) => {
    const { argv } = l as Launch;
    // `node --import tsx <file>`: one process, and nothing fetched at start.
    expect(argv.slice(0, 3)).toEqual(['node', '--import', 'tsx']);
    const script = argv[3];
    expect(existsSync(join(ROOT, script)), script).toBe(true);
    expect(script, 'examples deploy mock contracts with test keys').not.toMatch(/(^|\/)examples\//);
    expect(script).toMatch(/\/src\/bin\/[a-z-]+\.ts$/);
  });

  /**
   * The keepers hold keys and do run on Flux, which is only acceptable because neither key can
   * pay itself. Each spec must say so, and must be registered once per replica: Flux gives every
   * instance of an app the same environment, so `instances > 1` would share one key.
   */
  it('ships the keepers as one-instance specs whose notes bound what a leaked key can do', () => {
    for (const spec of ['vault-keeper.json', 'hl-keeper.json', 'pyth-keeper.json']) {
      const j = JSON.parse(read(`packages/ops/flux/${spec}`)) as {
        instances: number; compose: { environmentParameters: string[] }[]; _notes: Record<string, string>;
      };
      expect(j.instances, spec).toBe(1);
      const env = j.compose.flatMap((c) => c.environmentParameters).join('\n');
      expect(env, `${spec} must not carry a key in its file`).not.toMatch(/KEY=/);
      expect(env).toMatch(/REPLICA_INDEX=/);
      expect(Object.keys(j._notes).join(' '), spec).toMatch(/one (registration per replica|key)/);
    }
  });

  /// The desk holds the arbitrator key; Flux node operators can read an app's environment.
  it('never ships the key-holding arbitration desk as a Flux app', () => {
    for (const l of all.filter((x) => x.source.startsWith('flux/'))) {
      expect(l.argv.join(' ')).not.toMatch(/arbitration/);
    }
  });

  /**
   * The co-signer's key is an owner of every user's account: alone it can only refuse, but with one stolen passkey
   * it spends at once, and a Flux node operator can read an app's environment and disk. So it runs from its own
   * profile, its key in a KMS module (a key file is a development custody the entrypoint refuses in production
   * mode), never inline, production mode by default, every port on loopback - and no Flux spec launches it, or
   * even names it.
   */
  it('ships the co-signer behind its own profile, on loopback, its key never inline, and never as a Flux app', () => {
    const compose = read('packages/ops/docker-compose.yml');
    const block = /\n {2}cosigner:\n([\s\S]*?)(?=\n {2}[a-z][a-z-]*:\n|\nvolumes:)/.exec(compose)?.[1] ?? '';
    expect(block, 'a cosigner service in docker-compose.yml').toContain('command: ["node", "--import", "tsx", "packages/cosigner/src/bin/cosigner.ts"]');
    expect(block).toMatch(/^ {4}profiles: \["cosigner"\]$/m);
    expect(block, 'production mode unless the operator says otherwise').toMatch(/^ {6}COSIGNER_MODE: \$\{COSIGNER_MODE:-production\}$/m);
    expect(block, 'key custody through a KMS module').toMatch(/^ {6}COSIGNER_KMS_MODULE:/m);
    expect(block, 'never an inline key').not.toMatch(/COSIGNER_KEY:|PRIVATE_KEY/);
    expect(block, 'an audit log on a volume').toMatch(/COSIGNER_AUDIT_LOG: \/app\/data\//);
    const ports = [...block.matchAll(/^ {6}- "([^"]+)"$/gm)].map((m) => m[1]);
    expect(ports.length).toBeGreaterThan(0);
    for (const p of ports) expect(p, 'bound to loopback').toMatch(/^127\.0\.0\.1:/);
    for (const l of all.filter((x) => x.source.startsWith('flux/'))) {
      expect(l.argv.join(' ')).not.toMatch(/cosigner/);
    }
    for (const spec of readdirSync(join(ROOT, 'packages/ops/flux')).filter((f) => f.endsWith('.json'))) {
      expect(read(`packages/ops/flux/${spec}`), `flux/${spec}`).not.toMatch(/cosigner|COSIGNER_/i);
    }
    const flux = read('packages/ops/flux/README.md');
    expect(flux, 'the Flux README lists the co-signer among the key holders that are never on Flux').toMatch(/^\| Co-signer \| \*\*Yes\*\*.*\| \*\*Never\.\*\*/m);
  });
});

describe('what `npm ci --omit=dev` installs', () => {
  const lock = JSON.parse(read('package-lock.json')) as {
    packages: Record<string, { dev?: boolean; devOptional?: boolean; optional?: boolean;
      dependencies?: Record<string, string>; optionalDependencies?: Record<string, string> }>;
  };

  /**
   * A package and everything it needs, resolved the way npm hoists them here. Optional
   * dependencies count: esbuild's native binary for the image's platform is one.
   */
  function closure(name: string, seen = new Set<string>()): Set<string> {
    if (seen.has(name)) return seen;
    seen.add(name);
    const entry = lock.packages[`node_modules/${name}`];
    for (const dep of Object.keys({ ...entry?.dependencies, ...entry?.optionalDependencies })) {
      if (lock.packages[`node_modules/${dep}`]) closure(dep, seen);
    }
    return seen;
  }

  it('includes the launcher and all of its dependencies', () => {
    const launcher = launches()[0].argv[2];
    // A runtime dependency of some workspace, not only a root devDependency.
    const declaring = Object.entries(lock.packages)
      .filter(([k]) => k.startsWith('packages/') && !k.includes('node_modules'))
      .filter(([, v]) => v.dependencies?.[launcher]);
    expect(declaring.map(([k]) => k), `${launcher} must be in some workspace's dependencies`)
      .not.toEqual([]);

    const needed = closure(launcher);
    expect(needed.has('@esbuild/linux-x64')).toBe(true);
    for (const name of needed) {
      const entry = lock.packages[`node_modules/${name}`];
      expect(entry, name).toBeDefined();
      // `dev: true` is exactly what --omit=dev leaves out. Platform binaries may be
      // optional, just not dev-only.
      expect(entry.dev, `${name} is dev-only in package-lock.json`).not.toBe(true);
      expect(entry.devOptional, `${name} is dev-only in package-lock.json`).not.toBe(true);
    }
  });

  it('copies every workspace manifest before `npm ci`, or the install fails', () => {
    const docker = read('packages/ops/Dockerfile');
    const root = JSON.parse(read('package.json')) as { workspaces: string[] };
    const workspaces = Object.keys(lock.packages)
      .filter((k) => k && !k.includes('node_modules'))
      .filter((k) => root.workspaces.some((w) => new RegExp(`^${w.replace('*', '[^/]+')}$`).test(k)));
    expect(workspaces.length).toBeGreaterThan(5);
    for (const w of workspaces) {
      expect(docker, w).toMatch(new RegExp(`COPY ${w}/package\\.json\\s`));
    }
  });
});
