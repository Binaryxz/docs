import { describe, expect, it } from 'vitest';
import type { Address } from 'viem';
import { runChecks, DEFAULT_THRESHOLDS } from '../src/checks.js';

const RESERVE = '0x00000000000000000000000000000000000000c1' as Address;
const BREAKER = '0x00000000000000000000000000000000000000b2' as Address;
const NOW = 1_800_000_000;

function client(o: { breaker?: Address; tripped?: boolean; requests?: [Address, bigint, boolean, bigint][] }) {
  return {
    readContract: async (a: { functionName: string; args?: unknown[] }) => {
      switch (a.functionName) {
        case 'BREAKER': return o.breaker ?? BREAKER;
        case 'breakerTripped': return o.tripped ?? false;
        case 'sourceRates': return [5_400_000_000_000_000_000n, 0n];
        case 'hedgeRequestCount': return BigInt(o.requests?.length ?? 0);
        case 'hedgeRequests': return o.requests![Number(a.args![0])];
        default: throw new Error(`unexpected ${a.functionName}`);
      }
    },
  } as never;
}
const run = (o: Parameters<typeof client>[0], on = true) =>
  runChecks({ client: client(o), movva: { reserve: RESERVE, chainId: 1, breaker: on } }, DEFAULT_THRESHOLDS, NOW);
const by = (rs: { id: string }[], id: string) => rs.find((r) => r.id === id) as unknown as { level: string; detail: string };

describe('movva_breaker and movva_hedge_queue', () => {
  it('are off unless asked for', async () => {
    const rs = await run({}, false);
    expect(rs.find((r) => r.id === 'movva_breaker')).toBeUndefined();
  });
  it('movva_breaker is ok in band, warns while tripped and says nobody can lift it', async () => {
    expect(by(await run({ tripped: false }), 'movva_breaker').level).toBe('ok');
    const t = by(await run({ tripped: true }), 'movva_breaker');
    expect(t.level).toBe('warn');
    expect(t.detail).toContain('nobody can lift it');
    expect(t.detail).toContain('0');
  });
  it('movva_breaker is ok for a reserve with no breaker', async () => {
    expect(by(await run({ breaker: '0x0000000000000000000000000000000000000000' }), 'movva_breaker').level).toBe('ok');
  });
  it('movva_hedge_queue warns on a waiting request and not on an executed one', async () => {
    const to = '0x00000000000000000000000000000000000000d4' as Address;
    expect(by(await run({ requests: [[to, BigInt(NOW - 5), true, 90_000_000_000n]] }), 'movva_hedge_queue').level).toBe('ok');
    const w = by(await run({ requests: [[to, BigInt(NOW + 3600), false, 90_000_000_000n]] }), 'movva_hedge_queue');
    expect(w.level).toBe('warn');
    expect(w.detail).toContain('90000 USDT');
    expect(w.detail).toContain('3600s');
  });
});
