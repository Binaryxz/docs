import { describe, expect, it } from 'vitest';
import {
  ContractFunctionZeroDataError, encodeFunctionData, getAddress, parseAbi, toFunctionSelector, type Address, type Hex,
} from 'viem';
import { Alerter, type Alert } from '../src/alerts.js';
import { EventWatcher, describeCall, type PostedRuling } from '../src/watch.js';

/**
 * A notice period protects only if someone is told. These drive the watcher with the logs a
 * node would return and check what an operator actually receives.
 */

const ESCROW = '0x00000000000000000000000000000000000000e5' as Address;
const VAULT = '0x00000000000000000000000000000000000000a7' as Address;
const ARB = '0x00000000000000000000000000000000000000ab' as Address;
const id = (n: number) => `0x${n.toString(16).padStart(64, '0')}` as Hex;
const NOW = 1_800_000_000;

type Log = { address: Address; eventName: string; args: Record<string, unknown>; blockNumber: bigint };

/** Reads, by `address:functionName`: a value, or an Error to throw. Anything unlisted has no such function. */
type Reads = Record<string, unknown>;

function fakeClient(logs: Log[], opts: { failSpanAbove?: bigint; reads?: Reads } = {}) {
  let head = 0n;
  const calls: [bigint, bigint][] = [];
  const asked: string[] = [];
  return {
    setHead: (h: bigint) => { head = h; },
    calls,
    asked,
    client: {
      readContract: async (a: { address: Address; functionName: string }) => {
        const k = `${a.address.toLowerCase()}:${a.functionName}`;
        asked.push(k);
        const v = opts.reads?.[k];
        if (v === undefined) throw new ContractFunctionZeroDataError({ functionName: a.functionName });
        if (v instanceof Error) throw v;
        return v;
      },
      getBlockNumber: async () => head,
      getLogs: async (a: { address: Address[]; fromBlock: bigint; toBlock: bigint; events: { name: string }[] }) => {
        if (opts.failSpanAbove && a.toBlock - a.fromBlock + 1n > opts.failSpanAbove) throw new Error('range too large');
        calls.push([a.fromBlock, a.toBlock]);
        const names = new Set(a.events.map((e) => e.name));
        return logs.filter((l) => a.address.includes(l.address) && names.has(l.eventName)
          && l.blockNumber >= a.fromBlock && l.blockNumber <= a.toBlock);
      },
    } as never,
  };
}

const alerts = async (w: EventWatcher, alerter: Alerter, now = NOW) => {
  const sent: Alert[] = [];
  await w.sync();
  sent.push(...await alerter.observe(await w.checks(now)));
  return sent;
};

describe('scheduled governance changes', () => {
  it('alerts on each change, and resolves each when it executes or is cancelled', async () => {
    const logs: Log[] = [];
    const f = fakeClient(logs);
    const w = new EventWatcher({ client: f.client, governed: [ESCROW, VAULT], fromBlock: 100n });
    const alerter = new Alerter(() => undefined);

    logs.push({ address: VAULT, eventName: 'ChangeScheduled', blockNumber: 110n,
      args: { id: id(1), selector: '0x6f9b2f7a', call: '0x', readyAt: BigInt(NOW + 172_800), expiresAt: BigInt(NOW + 1_382_400) } });
    f.setHead(120n);
    let sent = await alerts(w, alerter);
    expect(sent.map((a) => [a.kind, a.level])).toEqual([['firing', 'warn']]);
    expect(sent[0].detail).toContain('gov:cancel');

    // A second change while the first is still pending gets its own alert.
    logs.push({ address: ESCROW, eventName: 'ChangeScheduled', blockNumber: 130n,
      args: { id: id(2), selector: '0x12345678', call: '0x', readyAt: BigInt(NOW + 172_800), expiresAt: BigInt(NOW + 1_382_400) } });
    f.setHead(140n);
    sent = await alerts(w, alerter);
    expect(sent).toHaveLength(1);
    expect(sent[0].id).toContain(ESCROW.toLowerCase());

    logs.push({ address: VAULT, eventName: 'ChangeExecuted', blockNumber: 150n, args: { id: id(1), selector: '0x6f9b2f7a' } });
    logs.push({ address: ESCROW, eventName: 'ChangeCancelled', blockNumber: 151n, args: { id: id(2) } });
    f.setHead(160n);
    sent = await alerts(w, alerter);
    expect(sent.map((a) => a.kind)).toEqual(['resolved', 'resolved']);
    expect(alerter.firing).toEqual([]);
  });

  it('lets an unexecuted change expire', async () => {
    const logs: Log[] = [{ address: VAULT, eventName: 'ChangeScheduled', blockNumber: 101n,
      args: { id: id(3), selector: '0xaaaaaaaa', call: '0x', readyAt: BigInt(NOW), expiresAt: BigInt(NOW + 10) } }];
    const f = fakeClient(logs);
    f.setHead(101n);
    const w = new EventWatcher({ client: f.client, governed: [VAULT], fromBlock: 100n });
    const alerter = new Alerter(() => undefined);
    expect((await alerts(w, alerter, NOW)).map((a) => a.kind)).toEqual(['firing']);
    expect((await alerts(w, alerter, NOW + 11)).map((a) => a.kind)).toEqual(['resolved']);
  });
});

describe('posted rulings', () => {
  const posted: Log = { address: ESCROW, eventName: 'RulingPosted', blockNumber: 105n,
    args: { orderId: id(9), favoursCounterparty: true, arbitrator: ARB, evidenceRoot: id(7), executableAt: BigInt(NOW + 86_400) } };

  it('warns while a ruling waits, and fails when the desk never signed it', async () => {
    const f = fakeClient([posted]);
    f.setHead(106n);
    let desk: PostedRuling[] = [];
    const w = new EventWatcher({ client: f.client, escrows: [ESCROW], fromBlock: 100n, unsignedByDesk: async () => desk });
    const alerter = new Alerter(() => undefined);
    expect((await alerts(w, alerter)).map((a) => a.level)).toEqual(['warn']);

    desk = [{ escrow: ESCROW, orderId: id(9), arbitrator: ARB, evidenceRoot: id(7), favoursCounterparty: true, executableAt: NOW + 86_400 }];
    const sent = await alerts(w, alerter);
    expect(sent.map((a) => a.level)).toEqual(['fail']);
    expect(sent[0].detail).toMatch(/revoke the arbitrator NOW/);
  });

  it('resolves when the dispute ends either way', async () => {
    const logs: Log[] = [posted];
    const f = fakeClient(logs);
    f.setHead(106n);
    const w = new EventWatcher({ client: f.client, escrows: [ESCROW], fromBlock: 100n });
    const alerter = new Alerter(() => undefined);
    await alerts(w, alerter);
    logs.push({ address: ESCROW, eventName: 'DisputeTimedOut', blockNumber: 200n, args: { orderId: id(9) } });
    f.setHead(200n);
    expect((await alerts(w, alerter)).map((a) => a.kind)).toEqual(['resolved']);
  });
});

describe('reading history', () => {
  it('halves the span a provider refuses, and never re-reads a block', async () => {
    const f = fakeClient([], { failSpanAbove: 1_000n });
    f.setHead(3_999n);
    const w = new EventWatcher({ client: f.client, governed: [VAULT], fromBlock: 0n, span: 4_000n });
    await w.sync();
    const covered = f.calls.reduce((n, [a, b]) => n + (b - a + 1n), 0n);
    expect(covered).toBe(4_000n);
    await w.sync();
    expect(f.calls.reduce((n, [a, b]) => n + (b - a + 1n), 0n)).toBe(4_000n);
  });

  it('reports an unreadable history as unknown, with the RPC URL redacted', async () => {
    const w = new EventWatcher({
      client: { getBlockNumber: async () => { throw new Error('HTTP request failed. URL: https://eth.example/v2/SECRETKEY'); }, getLogs: async () => [] } as never,
      governed: [VAULT], fromBlock: 0n, redactValues: ['https://eth.example/v2/SECRETKEY'],
    });
    await w.sync();
    const [status] = await w.checks(NOW);
    expect(status.level).toBe('unknown');
    expect(status.detail).not.toContain('SECRETKEY');
  });
});

describe('the price oracles behind the watched contracts', () => {
  const USDT = '0x00000000000000000000000000000000000000d7' as Address;
  const CROSS = '0x00000000000000000000000000000000000000c5' as Address; // ChainlinkSignedFxOracle
  const BAND = '0x00000000000000000000000000000000000000ba' as Address; // ScaledFxBandOracle
  const FX = '0x00000000000000000000000000000000000000f1' as Address; // SignedPriceOracle, millionths
  const FX2 = '0x00000000000000000000000000000000000000f2' as Address;
  const RESERVE = '0x00000000000000000000000000000000000000e0' as Address;
  const THIEF = '0x000000000000000000000000000000000000dead' as Address;
  const SETTERS = parseAbi(['function setPublisher(address publisher, bool active)', 'function setThreshold(uint256 threshold)']);
  const scheduled = (address: Address, blockNumber: bigint, n: number, call: Hex): Log => ({
    address, eventName: 'ChangeScheduled', blockNumber,
    args: { id: id(n), selector: call.slice(0, 10), call, readyAt: BigInt(NOW + 172_800), expiresAt: BigInt(NOW + 1_382_400) },
  });
  const addPublisher = encodeFunctionData({ abi: SETTERS, functionName: 'setPublisher', args: [THIEF, true] });
  const cutThreshold = encodeFunctionData({ abi: SETTERS, functionName: 'setThreshold', args: [1n] });

  /**
   * Nobody lists the FX leg in the monitor's configuration. The escrow names its USDT oracle, the
   * oracle's `usdBrl()` names the band adapter, whose `SOURCE()` names the signed leg - and a
   * publisher scheduled on that leg BEFORE any of it was found is still reported, decoded.
   */
  it('finds an escrow\'s oracle, the leg behind its adapter, and a publisher already scheduled there', async () => {
    const logs: Log[] = [
      scheduled(FX, 105n, 1, addPublisher),
      { address: ESCROW, eventName: 'AssetSet', blockNumber: 110n, args: { asset: USDT, oracle: CROSS, decimals: 6, enabled: true } },
    ];
    const f = fakeClient(logs, { reads: { [`${CROSS}:usdBrl`]: BAND, [`${BAND}:SOURCE`]: FX } });
    f.setHead(120n);
    const w = new EventWatcher({ client: f.client, governed: [ESCROW], escrows: [ESCROW], fromBlock: 100n });
    const alerter = new Alerter(() => undefined);

    const sent = await alerts(w, alerter);
    expect(sent.map((a) => [a.kind, a.level])).toEqual([['firing', 'warn']]);
    expect(sent[0].id).toContain(FX.toLowerCase());
    expect(sent[0].detail).toContain(`setPublisher(${getAddress(THIEF)}, true)`);
    expect(sent[0].detail).toMatch(/the BRL-per-USD rate rescaled by 0x00000000…/);
    expect(sent[0].detail).toContain('gov:cancel');

    // Cancelled on the leg: the watcher reads the leg from here on like any governed contract.
    logs.push({ address: FX, eventName: 'ChangeCancelled', blockNumber: 130n, args: { id: id(1) } });
    f.setHead(140n);
    expect((await alerts(w, alerter)).map((a) => a.kind)).toEqual(['resolved']);
    expect((await w.checks(NOW))[0].detail).toMatch(/3 price oracle\(s\) followed/);
  });

  /** A repointed leg is followed from the event that repoints it, and a reserve's leg from its own. */
  it('follows LegsSet and OracleSet to the new leg', async () => {
    const logs: Log[] = [
      scheduled(FX2, 101n, 2, cutThreshold),
      { address: CROSS, eventName: 'LegsSet', blockNumber: 150n, args: { assetUsd: USDT, usdBrl: FX2, assetMaxAge: 90_000n, fxMaxAge: 3_600n } },
      { address: RESERVE, eventName: 'OracleSet', blockNumber: 151n, args: { usdtUsdFeed: USDT, fxOracle: FX, usdtUsdMaxAge: 90_000n, fxMaxAge: 3_600n } },
      scheduled(FX, 152n, 3, addPublisher),
    ];
    const f = fakeClient(logs);
    f.setHead(160n);
    const w = new EventWatcher({ client: f.client, governed: [CROSS, RESERVE], fromBlock: 100n });
    const sent = await alerts(w, new Alerter(() => undefined));
    expect(sent.map((a) => a.id).sort()).toEqual([
      `governance_change:${FX.toLowerCase()}:${id(3).slice(0, 18)}`,
      `governance_change:${FX2.toLowerCase()}:${id(2).slice(0, 18)}`,
    ]);
    const byLeg = (leg: Address) => sent.find((a) => a.id.includes(leg.toLowerCase()))!.detail;
    expect(byLeg(FX2)).toContain('setThreshold(1)');
    expect(byLeg(FX2)).toMatch(/the BRL-per-USD leg of/);
    expect(byLeg(FX)).toMatch(/the FX leg the Movva reserve mints at/);
  });

  /** A contract that has no such getter is not asked again; a read the RPC dropped is. */
  it('asks again after a failed read, never after a refusal', async () => {
    const reads: Reads = { [`${RESERVE}:fxOracle`]: new Error('HTTP request failed') };
    const f = fakeClient([scheduled(FX, 101n, 4, addPublisher)], { reads });
    f.setHead(110n);
    const w = new EventWatcher({ client: f.client, governed: [RESERVE], fromBlock: 100n });
    const alerter = new Alerter(() => undefined);
    expect(await alerts(w, alerter)).toEqual([]);

    reads[`${RESERVE}:fxOracle`] = FX;
    const sent = await alerts(w, alerter);
    expect(sent.map((a) => a.id)).toEqual([`governance_change:${FX.toLowerCase()}:${id(4).slice(0, 18)}`]);
    const count = (k: string) => f.asked.filter((x) => x === k).length;
    expect(count(`${RESERVE.toLowerCase()}:fxOracle`)).toBe(2);
    expect(count(`${RESERVE.toLowerCase()}:usdBrl`)).toBe(1);
  });

  it('follows nothing when told not to', async () => {
    const f = fakeClient([
      scheduled(FX, 101n, 5, addPublisher),
      { address: ESCROW, eventName: 'AssetSet', blockNumber: 102n, args: { asset: USDT, oracle: FX, decimals: 6, enabled: true } },
    ]);
    f.setHead(110n);
    const w = new EventWatcher({ client: f.client, governed: [ESCROW], fromBlock: 100n, followOracles: false });
    expect(await alerts(w, new Alerter(() => undefined))).toEqual([]);
    expect(f.asked).toEqual([]);
  });

  /**
   * A PythFxOracle found behind the reserve: a scheduled repointing is decoded, a limits tightening that
   * needs no schedule is noticed once, and a closedMaxAge of 0 stays a warning.
   */
  it('reports a PythFxOracle\'s settings, decodes its scheduled setFeed and setLimits, and notices an instant tightening', async () => {
    const PYTH_FX = '0x00000000000000000000000000000000000000f3' as Address;
    const PYTH_SETTERS = parseAbi(['function setFeed(bytes32 usdBrlId)', 'function setLimits(uint64 maxAge, uint64 closedMaxAge, uint16 maxConfBps)']);
    const repoint = encodeFunctionData({ abi: PYTH_SETTERS, functionName: 'setFeed', args: [id(0xbad)] });
    const loosen = encodeFunctionData({ abi: PYTH_SETTERS, functionName: 'setLimits', args: [7_200n, 345_600n, 100] });
    expect(describeCall(repoint)).toBe(`setFeed(${id(0xbad)})`);
    expect(describeCall(loosen)).toBe('setLimits(7200, 345600, 100)');

    const logs: Log[] = [
      { address: PYTH_FX, eventName: 'FeedSet', blockNumber: 101n, args: { usdBrlId: id(0xd2) } },
      { address: PYTH_FX, eventName: 'LimitsSet', blockNumber: 101n, args: { maxAge: 3_600n, closedMaxAge: 345_600n, maxConfBps: 100 } },
      scheduled(PYTH_FX, 105n, 6, repoint),
    ];
    const f = fakeClient(logs, { reads: { [`${RESERVE}:fxOracle`]: PYTH_FX } });
    f.setHead(110n);
    const w = new EventWatcher({ client: f.client, governed: [RESERVE], fromBlock: 100n });
    const alerter = new Alerter(() => undefined);
    const first = await alerts(w, alerter);
    expect(first.map((a) => a.id)).toEqual([`governance_change:${PYTH_FX.toLowerCase()}:${id(6).slice(0, 18)}`]);
    expect(first[0].detail).toContain(`setFeed(${id(0xbad)})`);
    expect(first[0].detail).toMatch(/the FX leg the Movva reserve mints at/);
    const settings = (await w.checks(NOW)).find((c) => c.id === `oracle_settings:${PYTH_FX.toLowerCase()}`)!;
    expect(settings).toMatchObject({ level: 'ok' });
    expect(settings.detail).toContain(`feed ${id(0xd2)}, maxAge 3600s, closedMaxAge 345600s, maxConfBps 100`);

    // The governor tightens closedMaxAge to 0 directly: no schedule, applied at once.
    logs.push({ address: PYTH_FX, eventName: 'LimitsSet', blockNumber: 120n, args: { maxAge: 3_600n, closedMaxAge: 0n, maxConfBps: 100 } });
    f.setHead(125n);
    const tightened = await alerts(w, alerter);
    const notice = tightened.find((a) => a.id === `oracle_settings:${PYTH_FX.toLowerCase()}`)!;
    expect(notice).toMatchObject({ kind: 'firing', level: 'warn' });
    expect(notice.detail).toMatch(/changed at block 120: .*closedMaxAge 345600s.* -> .*closedMaxAge 0s.*bands refuse outside the core session/);
    // And it stays a warning while the bands are off outside the core session; the notice itself does not repeat.
    expect(await alerts(w, alerter)).toEqual([]);
    expect((await w.checks(NOW)).find((c) => c.id === `oracle_settings:${PYTH_FX.toLowerCase()}`)!.level).toBe('warn');

    // The scheduled repointing executes: resolved, naming what executed.
    logs.push({ address: PYTH_FX, eventName: 'ChangeExecuted', blockNumber: 130n, args: { id: id(6), selector: repoint.slice(0, 10) } });
    logs.push({ address: PYTH_FX, eventName: 'FeedSet', blockNumber: 130n, args: { usdBrlId: id(0xbad) } });
    logs.push({ address: PYTH_FX, eventName: 'LimitsSet', blockNumber: 131n, args: { maxAge: 3_600n, closedMaxAge: 345_600n, maxConfBps: 100 } });
    f.setHead(140n);
    const done = await alerts(w, alerter);
    expect(done.find((a) => a.id.startsWith('governance_change:'))).toMatchObject({ kind: 'resolved' });
    expect(done.find((a) => a.id.startsWith('governance_change:'))!.detail).toContain(`executed on 0x00000000…: setFeed(${id(0xbad)})`);
  });

  it('decodes the price setters and leaves anything else as its selector', () => {
    expect(describeCall(addPublisher)).toBe(`setPublisher(${getAddress(THIEF)}, true)`);
    expect(describeCall(cutThreshold)).toBe('setThreshold(1)');
    expect(describeCall(toFunctionSelector('setTier(address,uint8,uint256)'))).toBeUndefined();
    expect(describeCall('0x')).toBeUndefined();
  });
});

describe('reward governance, decoded', () => {
  it('names a scheduled share raise, a limits change and a new rewards hook, so the alert says what moves', () => {
    const abi = parseAbi([
      'function setLpRewardShare(uint16 bps)',
      'function setRewardLimits(uint16 bpsOfVolume, uint256 lpCap, uint256 minCents)',
      'function setRewardsHook(address hook)',
    ]);
    expect(describeCall(encodeFunctionData({ abi, functionName: 'setLpRewardShare', args: [5000] }))).toBe('setLpRewardShare(5000)');
    expect(describeCall(encodeFunctionData({ abi, functionName: 'setRewardLimits', args: [20, 10n ** 22n, 1000n] })))
      .toBe('setRewardLimits(20, 10000000000000000000000, 1000)');
    expect(describeCall(encodeFunctionData({ abi, functionName: 'setRewardsHook', args: [ESCROW] }))).toBe(`setRewardsHook(${getAddress(ESCROW)})`);
    expect(describeCall(`0x${'12345678'}` as Hex)).toBeUndefined();
  });
});
