import { describe, expect, it } from 'vitest';
import { existsSync, mkdtempSync, readFileSync, readdirSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { decodeAbiParameters, decodeFunctionData, getAddress, parseAbi, toFunctionSelector, type AbiParameter } from 'viem';
import {
  COMMANDS, DEPLOYS, REWARD_CAPS, TIERS, abiOf, classifyPythFxFeed, classifyPythFxLimits, classifyRewardLimits, classifySplitterShare, encode,
  encodeDeploy, hlParams, signatureOf,
} from '../src/bin/admin.js';

const REG = '0x1111111111111111111111111111111111111111';
const X = '0x2222222222222222222222222222222222222222';
const H = `0x${'ab'.repeat(32)}`;

const cmd = (name: string) => {
  const c = COMMANDS[name];
  if (!c) throw new Error(`no command ${name}`);
  return c;
};
const build = (name: string, argv: string[]) => cmd(name).build(argv);

/** A desk submission as `GET /cases/:id/submission` serialises it (bigints as strings). */
function submissionFile(): { path: string; cleanup: () => void } {
  const dir = mkdtempSync(join(tmpdir(), 'admin-'));
  const path = join(dir, 'submission.json');
  writeFileSync(path, JSON.stringify({
    fn: 'resolveDispute',
    args: [H, {
      orderId: H, outcome: 'REFUND', evidenceRoot: `0x${'cd'.repeat(32)}`,
      rationale: 'no response by 2026-01-01, (defaulted)', ruledAt: '1700000000', byDefault: true,
    }, `0x${'11'.repeat(65)}`],
    leg: 'onramp',
    arbitrator: X,
  }));
  writeFileSync(join(dir, 'params.json'), JSON.stringify(HL_SAMPLE_PARAMS));
  return { path, cleanup: () => rmSync(dir, { recursive: true, force: true }) };
}

/** The HyperEVM vault's parameters as an operator would write them (the Foundry tests' defaults). */
const HL_SAMPLE_PARAMS = {
  targetLeverageBps: 20000, maxLeverageBps: 30000, slippageBps: 30, deltaToleranceBps: 200,
  maxSpotDeviationBps: 100, idleBufferBps: 1000, maxDrawdownBps: 300, exitFeeBps: 20,
  fundingPauseE8: 0, fundingUnwindE8: -1141, fundingTau: 302400, minActionInterval: 60,
  settleSeconds: 5, maxOrderNotional: '50000000000', maxDailyTurnover: '2000000000000',
  depositCap: '10000000000000',
};

/** Enough positional arguments to build any command in the table. */
function sampleArgs(spec: string, file: string): string[] {
  return spec.split(' ').map((token) => {
    if (token.includes('|')) return token.replace(/[<>]/g, '').split('|')[0];
    if (/params\.json/.test(token)) return join(dirname(file), 'params.json');
    if (/\.json/.test(token)) return file;
    if (/https:/.test(token)) return 'https://bank.example/pix/';
    if (/hash|Id>/i.test(token)) return H;
    if (/railMask/.test(token)) return '6';
    if (/RatioBps/.test(token)) return '10800';
    if (/cents|wei|bps|threshold|assets|cap|Seconds|decimals/i.test(token)) return '1';
    return X;
  });
}

describe('the command table', () => {
  it('describes every command with args, a stated risk and a parseable function', () => {
    for (const [name, c] of Object.entries(COMMANDS)) {
      expect(c.what, name).toBeTruthy();
      expect(c.risk, name).toBeTruthy();
      expect(c.args, name).toBeTruthy();
      expect(() => abiOf(c), name).not.toThrow();
    }
  });

  /**
   * The printed `cast send` line is meant to be pasted. A placeholder signature would hand
   * an operator a command that fails at exactly the moment they are trying to act.
   */
  it('encodes every command to calldata that decodes back under its printed signature', () => {
    const { path, cleanup } = submissionFile();
    try {
      for (const [name, c] of Object.entries(COMMANDS)) {
        // The queue wrappers take another command and its arguments.
        const args = /^gov:(schedule|execute|cancel)$/.test(name)
          ? ['escrow:arbitrator', X, X, 'true']
          : sampleArgs(c.args, path);
        const e = encode(c, args);
        expect(e.signature, name).toMatch(/^[a-zA-Z]+\([a-z0-9,()[\]]*\)$/);
        expect(e.data.slice(0, 10), name).toBe(toFunctionSelector(signatureOf(c)));
        expect(decodeFunctionData({ abi: [abiOf(c)], data: e.data }).functionName, name).toBe(e.fn);
      }
    } finally {
      cleanup();
    }
  });

  /// The USDT band's oracle: two addresses, two uint64 ages, and no zero age.
  it('encodes the FX-crossed oracle\'s legs and refuses a zero max age', () => {
    const feed = '0x3E7d1eAB13ad0104d2750B8863b489D65364e32D';
    const e = encode(cmd('oracle:fx-legs'), [REG, feed, X, '90000', '3600']);
    expect(e.signature).toBe('setLegs(address,address,uint64,uint64)');
    expect(e.args).toEqual([feed, X, 90000n, 3600n]);
    expect(() => build('oracle:fx-legs', [REG, feed, X, '0', '3600'])).toThrow(/above zero/);
    expect(() => build('oracle:fx-legs', [REG, feed, X, '90000', `${2n ** 64n}`])).toThrow(/uint64/);
  });

  /// Same name, different contract, different selector. A lookup by name used to pick one.
  it('keeps the Chainlink and Pyth setFeeds overloads apart', () => {
    expect(signatureOf(cmd('oracle:feeds'))).toBe('setFeeds(address,address,uint64)');
    expect(signatureOf(cmd('oracle:pyth-feeds'))).toBe('setFeeds(bytes32,bytes32,uint256,uint256)');
    expect(toFunctionSelector(signatureOf(cmd('oracle:feeds'))))
      .not.toBe(toFunctionSelector(signatureOf(cmd('oracle:pyth-feeds'))));
  });

  /**
   * The tool claims to reach every privileged function. This makes that claim checkable:
   * every function in these directories guarded by a governor, guardian, keeper or owner
   * check must have a command, matched by name and arity. When the governance timelock adds
   * schedule/execute functions, this is the test that says which commands to add.
   */
  it('has a command for every privileged function in contracts/ramp, yield, common, hyperliquid and movva', () => {
    const root = new URL('../../../contracts/', import.meta.url);
    const files = ['ramp', 'yield', 'common', 'hyperliquid', 'movva'].flatMap((d) => walk(join(root.pathname, d)));
    expect(files.some((f) => f.endsWith('HyperCoreDeltaNeutralVault.sol')), 'the HyperEVM vault is scanned').toBe(true);
    expect(files.some((f) => f.endsWith('MovvaReserve.sol')), 'the Movva reserve is scanned').toBe(true);
    expect(files.some((f) => f.endsWith('NodeRewards.sol')), 'node-provider rewards are scanned').toBe(true);
    expect(files.some((f) => f.endsWith('FeeSplitter.sol')), 'the fee splitter is scanned').toBe(true);
    expect(files.length).toBeGreaterThan(10);

    const covered = new Set(Object.values(COMMANDS).map((c) => {
      const a = abiOf(c);
      return `${a.name}/${a.inputs.length}`;
    }));
    const privileged: string[] = [];
    for (const f of files) {
      const src = readFileSync(f, 'utf8');
      for (const m of src.matchAll(/function\s+(\w+)\s*\(([^)]*)\)([^{;]*)\{/g)) {
        const bodyStart = m.index! + m[0].length;
        const body = src.slice(bodyStart, src.indexOf('\n    }', bodyStart));
        // `_authorizeChange` is DelayedGovernance's guard: it lives in the body, because whether
        // a call must wait out the delay depends on the arguments and current state. The Movva
        // reserve's treasurer is an operator role too. Its gateways are not: `mint` and `redeem` are
        // an LP's business, run from the LP's own tooling, like an escrow's `postOffer`.
        const guarded = /\bonly(Governor|Guardian|Keeper|Owner|Treasurer)\b/.test(m[3])
          || /msg\.sender\s*!=\s*(governor|guardian|keeper|owner|treasurer)\b/.test(body)
          || /\b_authorizeChange\(/.test(body);
        // Only what an operator can call: the guard helpers themselves are internal.
        if (!guarded || !/\b(external|public)\b/.test(m[3])) continue;
        const arity = m[2].split(',').map((p) => p.trim()).filter(Boolean).length;
        privileged.push(`${m[1]}/${arity} (${f.split('/contracts/')[1]})`);
      }
    }
    expect(privileged.length).toBeGreaterThan(20);
    const missing = privileged.filter((p) => !covered.has(p.split(' ')[0]));
    expect(missing.join(', '), 'add a command in packages/ops/src/bin/admin.ts for each').toBe('');
  });

  /// A delayed change must execute with exactly the calldata that was scheduled.
  it('wraps a command for the governance queue without changing its calldata', () => {
    const esc = '0x00000000000000000000000000000000000000e5';
    const arb = '0x00000000000000000000000000000000000000a4';
    const direct = encode(cmd('escrow:arbitrator'), [esc, arb, 'true']);
    const scheduled = encode(cmd('gov:schedule'), ['escrow:arbitrator', esc, arb, 'true']);
    const executed = encode(cmd('gov:execute'), ['escrow:arbitrator', esc, arb, 'true']);
    expect(scheduled.to).toBe(direct.to);
    expect(scheduled.fn).toBe('schedule');
    expect(executed.fn).toBe('execute');
    expect(scheduled.args[0]).toBe(direct.data);
    expect(executed.args[0]).toBe(direct.data);
    expect(() => encode(cmd('gov:schedule'), ['gov:execute', esc])).toThrow(/needs a command/);
  });

  /// `--execute` reads the key of the role that may call it; the governor cannot deallocate.
  it('names the role that can actually call keeper and guardian functions', () => {
    expect(cmd('vault:deallocate').role).toBe('guardian');
    expect(cmd('vault:allocate').role).toBe('keeper');
    expect(cmd('vault:harvest').role).toBe('keeper');
    expect(cmd('lp:tier').role ?? 'governor').toBe('governor');
    // Rulings and expiries are open to anyone; the tool must not reach for the governor's key.
    expect(cmd('escrow:resolve').role).toBe('submitter');
    expect(cmd('escrow:expire-dispute').role).toBe('submitter');
    expect(cmd('hl:rebalance').role).toBe('keeper');
    expect(cmd('hl:harvest').role).toBe('keeper');
    expect(cmd('hl:pause').role).toBe('guardian');
    expect(cmd('gate:operator').role ?? 'governor').toBe('governor');
    // The Movva reserve: only the treasurer can withdraw to the hedge, and only the guardian (or the
    // governor) pauses mint.
    expect(cmd('movva:withdraw-to-hedge').role).toBe('treasurer');
    expect(cmd('movva:pause-mint').role).toBe('guardian');
    expect(cmd('movva:resume-mint').role ?? 'governor').toBe('governor');
    expect(cmd('movva:gateway').role ?? 'governor').toBe('governor');
  });

  /// Widening an endpoint to boletos is a governance change; the mask is checked before encoding.
  it('encodes an endpoint rail mask and refuses one that cannot be set', () => {
    const verifier = '0x3333333333333333333333333333333333333333';
    const e = encode(cmd('zktls:endpoint-rails'), [verifier, H, '6']);
    expect(e.data.slice(0, 10)).toBe(toFunctionSelector('setEndpointRails(bytes32,uint16)'));
    expect(e.args).toEqual([H, 6]);
    for (const bad of ['0', '1', '3', '65536']) {
      expect(() => build('zktls:endpoint-rails', [verifier, H, bad]), bad).toThrow(/railMask/);
    }
  });
});

describe('the Movva reserve', () => {
  const RESERVE = '0x4444444444444444444444444444444444444444';

  /// The hard caps are the contract's; refusing here keeps a dead proposal off the multisig.
  it('encodes fees within the hard caps and refuses more', () => {
    const e = encode(cmd('movva:fees'), [RESERVE, '100', '100']);
    expect(e.signature).toBe('setFees(uint16,uint16)');
    expect(e.args).toEqual([100, 100]);
    expect(() => build('movva:fees', [RESERVE, '101', '0'])).toThrow(/mintFeeBps/);
    expect(() => build('movva:fees', [RESERVE, '0', '101'])).toThrow(/redeemFeeBps/);
  });

  it('refuses a collateral ratio below 100%, and ratios out of order', () => {
    expect(encode(cmd('movva:ratios'), [RESERVE, '10800', '10000', '10300']).args).toEqual([10800, 10000, 10300]);
    expect(encode(cmd('movva:ratios'), [RESERVE, '10800', '10800', '10800']).args).toEqual([10800, 10800, 10800]);
    expect(() => build('movva:ratios', [RESERVE, '9999', '10000', '10000'])).toThrow(/targetRatioBps/);
    expect(() => build('movva:ratios', [RESERVE, '10800', '10000', '70000'])).toThrow(/minWithdrawRatioBps/);
    // The first proposal: a 105% withdraw floor above a 102% target.
    expect(() => build('movva:ratios', [RESERVE, '10200', '10000', '10500'])).toThrow(/ordered/);
    expect(() => build('movva:ratios', [RESERVE, '10800', '10400', '10300'])).toThrow(/ordered/);
  });

  /// Whole Movva in, base units out: an operator typing 1000000 means a million reais, not 1e-12.
  it('takes the supply cap in whole Movva and encodes it in base units', () => {
    const e = encode(cmd('movva:limits'), [RESERVE, '1000000', '200']);
    expect(e.signature).toBe('setLimits(uint256,uint16)');
    expect(e.args).toEqual([1_000_000n * 10n ** 18n, 200]);
    expect(() => build('movva:limits', [RESERVE, '1', '10001'])).toThrow(/hedgeLimitBps/);
  });

  it('pulls everything with "max" and refuses zero', () => {
    expect(build('movva:pull-from-vault', [RESERVE, 'max']).args).toEqual([2n ** 256n - 1n]);
    expect(build('movva:pull-from-vault', [RESERVE, '50000000000']).args).toEqual([50_000_000_000n]);
    expect(() => build('movva:pull-from-vault', [RESERVE, '0'])).toThrow(/above zero/);
  });

  it('refuses a zero oracle max age, and revokes the treasurer with the zero address', () => {
    const feed = '0x3E7d1eAB13ad0104d2750B8863b489D65364e32D';
    expect(encode(cmd('movva:oracle'), [RESERVE, feed, X, '90000', '3600']).signature)
      .toBe('setOracle(address,address,uint64,uint64)');
    expect(() => build('movva:oracle', [RESERVE, feed, X, '90000', '0'])).toThrow(/above zero/);
    const zero = '0x0000000000000000000000000000000000000000';
    expect(build('movva:treasurer', [RESERVE, zero]).args).toEqual([zero]);
  });

  /// Admitting a gateway waits out the reserve's own delay: the queue wrapper carries it unchanged.
  it('schedules a new gateway through the reserve\'s queue', () => {
    const inner = encode(cmd('movva:gateway'), [RESERVE, X, 'true']);
    const scheduled = encode(cmd('gov:schedule'), ['movva:gateway', RESERVE, X, 'true']);
    expect(scheduled.to).toBe(getAddress(RESERVE));
    expect(scheduled.args[0]).toBe(inner.data);
    expect(inner.signature).toBe('setGateway(address,bool)');
  });
});

const ORACLE = '0x5555555555555555555555555555555555555555';

describe('the price oracles', () => {

  /// Adding a publisher and lowering the threshold wait: the queue wrapper carries each unchanged.
  it('schedules a new publisher and a lower threshold through the oracle\'s own queue', () => {
    for (const [name, args] of [['oracle:publisher', [ORACLE, X, 'true']], ['threshold:set', [ORACLE, '1']]] as const) {
      const inner = encode(cmd(name), [...args]);
      const scheduled = encode(cmd('gov:schedule'), [name, ...args]);
      const executed = encode(cmd('gov:execute'), [name, ...args]);
      const cancelled = encode(cmd('gov:cancel'), [name, ...args]);
      expect(scheduled.to, name).toBe(getAddress(ORACLE));
      expect([scheduled.fn, executed.fn, cancelled.fn]).toEqual(['schedule', 'execute', 'cancel']);
      for (const e of [scheduled, executed, cancelled]) expect(e.args[0], name).toBe(inner.data);
    }
    expect(signatureOf(cmd('oracle:publisher'))).toBe('setPublisher(address,bool)');
    expect(signatureOf(cmd('threshold:set'))).toBe('setThreshold(uint256)');
  });

  /// Removing a leaked publisher is sent as-is: the direct command, not a queued one.
  it('removes a publisher directly', () => {
    const e = encode(cmd('oracle:publisher'), [ORACLE, X, 'false']);
    expect(e.to).toBe(getAddress(ORACLE));
    expect(decodeFunctionData({ abi: [abiOf(cmd('oracle:publisher'))], data: e.data }).args).toEqual([getAddress(X), false]);
  });

  /// The risk line is what an approver reads before signing: it must say which direction waits.
  it('says which direction of each oracle change waits', () => {
    const risk = (n: string) => cmd(n).risk;
    expect(risk('oracle:publisher')).toMatch(/Adding one is DELAYED/);
    expect(risk('oracle:publisher')).toMatch(/removing one is immediate/);
    expect(risk('oracle:publisher')).toMatch(/never lowers the threshold/);
    expect(risk('threshold:set')).toMatch(/lowering it is DELAYED/);
    expect(risk('threshold:set')).toMatch(/raising it is immediate/);
    for (const n of ['oracle:feeds', 'oracle:pyth-feeds', 'oracle:fx-legs', 'oracle:pyth-fx-limits']) {
      expect(risk(n), n).toMatch(/is DELAYED/);
      expect(risk(n), n).toMatch(/only tightening .* is immediate/);
    }
  });

  /**
   * Checked against the contracts rather than hoped: every function an oracle declares delayable in
   * `_isDelayable` has a command, matched by name and arity, whose risk line says DELAYED. An oracle
   * setter made delayable without its command being relabelled fails here.
   */
  it('labels every delayable oracle setter DELAYED, read from the contracts', () => {
    const ramp = new URL('../../../contracts/ramp/', import.meta.url).pathname;
    const files = ['SignedPriceOracle.sol', 'ChainlinkSignedFxOracle.sol', 'ChainlinkBrlOracle.sol', 'PythBrlOracle.sol', 'PythFxOracle.sol'];
    const checked: string[] = [];
    for (const f of files) {
      const src = readFileSync(join(ramp, f), 'utf8');
      const body = src.slice(src.indexOf('function _isDelayable'), src.indexOf('\n    }', src.indexOf('function _isDelayable')));
      const names = [...body.matchAll(/\.(\w+)\.selector/g)].map((m) => m[1]);
      expect(names.length, f).toBeGreaterThan(0);
      for (const name of names) {
        const params = src.match(new RegExp(`function\\s+${name}\\s*\\(([^)]*)\\)`))![1];
        const arity = params.split(',').map((p) => p.trim()).filter(Boolean).length;
        const commands = Object.entries(COMMANDS).filter(([k, c]) => !k.startsWith('gov:')
          && abiOf(c).name === name && abiOf(c).inputs.length === arity);
        expect(commands.length, `${f}: ${name}/${arity} has a command`).toBeGreaterThan(0);
        for (const [k, c] of commands) expect(c.risk, `${k} (${f} ${name}/${arity})`).toMatch(/DELAYED/);
        checked.push(`${name}/${arity}`);
      }
    }
    expect(checked.sort()).toEqual(['setFeed/1', 'setFeeds/3', 'setFeeds/4', 'setLegs/4', 'setLimits/3', 'setPublisher/2', 'setThreshold/1']);
  });

  /**
   * PythFxOracle: Pyth's FX.USD/BRL, which the reserve mints at and the ramps' bands read rescaled. Repointing
   * the id waits; its limits wait when any loosens and apply at once when all tighten.
   */
  describe('PythFxOracle', () => {
    const id = `0x${'d2'.repeat(32)}`;
    const current = { maxAge: 3_600n, closedMaxAge: 345_600n, maxConfBps: 100n };

    it('encodes setFeed and setLimits at the contract\'s widths, refusing what the contract would', () => {
      expect(encode(cmd('oracle:pyth-fx-feed'), [ORACLE, id])).toMatchObject({ signature: 'setFeed(bytes32)', args: [id] });
      expect(() => build('oracle:pyth-fx-feed', [ORACLE, `0x${'00'.repeat(32)}`])).toThrow(/BadFeedId/);
      expect(() => build('oracle:pyth-fx-feed', [ORACLE, '0x1234'])).toThrow(/32-byte/);
      const e = encode(cmd('oracle:pyth-fx-limits'), [ORACLE, '3600', '0', '100']);
      expect(e.signature).toBe('setLimits(uint64,uint64,uint16)');
      expect(e.args).toEqual([3_600n, 0n, 100]);
      expect(toFunctionSelector(e.signature)).not.toBe(toFunctionSelector(signatureOf(cmd('movva:limits'))));
      expect(() => build('oracle:pyth-fx-limits', [ORACLE, '0', '0', '100'])).toThrow(/maxAgeSeconds must be above zero/);
      expect(() => build('oracle:pyth-fx-limits', [ORACLE, '3600', '345601', '100'])).toThrow(/4 days/);
      expect(() => build('oracle:pyth-fx-limits', [ORACLE, '3600', '0', '0'])).toThrow(/maxConfBps/);
      expect(() => build('oracle:pyth-fx-limits', [ORACLE, '3600', '0', '1001'])).toThrow(/maxConfBps/);
    });

    it('schedules and executes both through the oracle\'s own queue with identical calldata', () => {
      for (const [name, args] of [['oracle:pyth-fx-feed', [ORACLE, id]], ['oracle:pyth-fx-limits', [ORACLE, '7200', '345600', '100']]] as const) {
        const inner = encode(cmd(name), [...args]);
        for (const verb of ['gov:schedule', 'gov:execute', 'gov:cancel']) {
          const wrapped = encode(cmd(verb), [name, ...args]);
          expect(wrapped.to, `${verb} ${name}`).toBe(getAddress(ORACLE));
          expect(wrapped.args[0], `${verb} ${name}`).toBe(inner.data);
        }
      }
    });

    it('classifies a limits change the way the contract does: any loosening waits, tightening is immediate', () => {
      expect(classifyPythFxLimits(current, { ...current, maxAge: 7_200n }, true)).toMatchObject({ delayed: true });
      expect(classifyPythFxLimits(current, { ...current, maxConfBps: 101n }, true).text).toMatch(/maxConfBps 100 bps -> 101 bps \(LOOSENS\): DELAYED/);
      // One tighter, one looser: still delayed, as `maxAge_ > maxAge || ...` in the contract.
      expect(classifyPythFxLimits(current, { ...current, maxAge: 1_800n, closedMaxAge: 345_600n, maxConfBps: 150n }, true).delayed).toBe(true);
      const tighten = classifyPythFxLimits(current, { maxAge: 1_800n, closedMaxAge: 0n, maxConfBps: 50n }, true);
      expect(tighten.delayed).toBe(false);
      expect(tighten.text).toMatch(/tightening only, immediate/);
      expect(tighten.text).toMatch(/stops the bands outside the core session/);
      expect(classifyPythFxLimits(current, current, true).text).toMatch(/no limit changes/);
      expect(classifyPythFxLimits(current, { ...current, maxAge: 7_200n }, false)).toMatchObject({ delayed: false });
    });

    it('classifies a feed change: a new id waits, the same id changes nothing', () => {
      expect(classifyPythFxFeed(id as `0x${string}`, `0x${'ee'.repeat(32)}`, true)).toMatchObject({ delayed: true });
      expect(classifyPythFxFeed(id as `0x${string}`, id.toUpperCase().replace('0X', '0x') as `0x${string}`, true).delayed).toBe(false);
      expect(classifyPythFxFeed(id as `0x${string}`, `0x${'ee'.repeat(32)}`, false).delayed).toBe(false);
    });

    it('reads the oracle\'s current settings to classify, for the command and for its queue wrapper', async () => {
      const reads: string[] = [];
      const read = async (sig: string) => {
        reads.push(sig);
        if (sig.includes('setupComplete')) return true;
        if (sig.includes('closedMaxAge')) return 345_600n;
        if (sig.includes('maxConfBps')) return 100;
        return 3_600n;
      };
      const limits = cmd('oracle:pyth-fx-limits');
      expect(await limits.classify!(limits.build([ORACLE, '3600', '0', '100']).args, read)).toMatch(/closedMaxAge 345600s -> 0s \(tightens\).*immediate/);
      expect(await limits.classify!(limits.build([ORACLE, '5400', '345600', '100']).args, read)).toMatch(/maxAge 3600s -> 5400s \(LOOSENS\).*DELAYED/);
      expect(reads.some((r) => r.startsWith('function maxAge()'))).toBe(true);
    });
  });
});

describe('the keeper gate and the HyperEVM vault', () => {
  it('schedules a new replica key the way the delay requires', () => {
    const e = encode(cmd('gov:schedule'), ['gate:operator', REG, X, 'true']);
    const inner = encode(cmd('gate:operator'), [REG, X, 'true']);
    expect(e.args[0]).toBe(inner.data);
    expect(inner.signature).toBe('setOperator(address,bool)');
    expect(signatureOf(cmd('gate:turnover'))).toBe('setMaxTurnover(uint16)');
  });

  it('encodes every params field in the contract\'s order and width', () => {
    const { path, cleanup } = submissionFile();
    try {
      const e = encode(cmd('hl:params'), [REG, join(dirname(path), 'params.json')]);
      const decoded = decodeFunctionData({ abi: [abiOf(cmd('hl:params'))], data: e.data });
      expect(decoded.args[0]).toMatchObject({
        targetLeverageBps: 20000, fundingUnwindE8: -1141, maxOrderNotional: 50_000_000_000n, depositCap: 10_000_000_000_000n,
      });
    } finally {
      cleanup();
    }
  });

  /// A missing field would encode as zero - a zero band or cap is a real setting, not a default.
  it('refuses a params file with a missing, malformed or unknown field', () => {
    const { maxOrderNotional: _omit, ...missing } = HL_SAMPLE_PARAMS;
    expect(() => hlParams(missing)).toThrow(/maxOrderNotional/);
    expect(() => hlParams({ ...HL_SAMPLE_PARAMS, slippageBps: '30bps' })).toThrow(/slippageBps/);
    expect(() => hlParams({ ...HL_SAMPLE_PARAMS, leverage: 3 })).toThrow(/unknown/);
  });
});

function walk(dir: string): string[] {
  return readdirSync(dir).flatMap((n) => {
    const p = join(dir, n);
    return statSync(p).isDirectory() ? walk(p) : p.endsWith('.sol') ? [p] : [];
  });
}

describe('lp:tier', () => {
  /**
   * `enum Tier` in contracts/ramp/LPRegistry.sol, in declaration order. Hardcoded rather
   * than parsed on purpose: a reorder in the contract must be made here deliberately as
   * well, because the index is what the registry receives. The tool once mapped five names
   * onto a four-member enum, and every tier after RETAIL landed one too high.
   */
  const LP_REGISTRY_TIERS = ['NONE', 'RETAIL', 'AFFILIATED', 'INSTITUTIONAL', 'SUSPENDED'];

  it('maps each tier name to its index in LPRegistry.Tier', () => {
    expect([...TIERS]).toEqual(LP_REGISTRY_TIERS);
    LP_REGISTRY_TIERS.forEach((name, index) => {
      expect(build('lp:tier', [REG, X, name, '0']).args, name).toEqual([X, index, 0n]);
    });
    expect(build('lp:tier', [REG, X, 'retail', '0']).args).toEqual([X, 1, 0n]);
  });

  it('refuses a tier name that is not in the enum, including the old VERIFIED and bare numbers', () => {
    for (const bad of ['PLATINUM', 'VERIFIED', '3', '']) {
      expect(() => build('lp:tier', [REG, X, bad, '0']), bad).toThrow(/tier must be one of/);
    }
  });

  it('encodes to the setTier selector the registry exposes', () => {
    const e = encode(cmd('lp:tier'), [REG, X, 'AFFILIATED', '250000']);
    expect(e.data.slice(0, 10)).toBe(toFunctionSelector('setTier(address,uint8,uint256)'));
    expect(e.args).toEqual([X, 2, 250000n]);
  });
});

describe('escrow:resolve', () => {
  it('submits exactly what the desk handed over', () => {
    const { path, cleanup } = submissionFile();
    try {
      const e = encode(cmd('escrow:resolve'), [REG, path]);
      const decoded = decodeFunctionData({ abi: [abiOf(cmd('escrow:resolve'))], data: e.data });
      const [orderId, ruling] = decoded.args as [string, Record<string, unknown>];
      expect(orderId).toBe(H);
      expect(ruling).toMatchObject({ outcome: 'REFUND', ruledAt: 1700000000n, byDefault: true });
      expect(ruling.rationale).toBe('no response by 2026-01-01, (defaulted)');
    } finally {
      cleanup();
    }
  });

  it('refuses a file that is not a resolveDispute submission', () => {
    const dir = mkdtempSync(join(tmpdir(), 'admin-'));
    try {
      const p = join(dir, 'x.json');
      writeFileSync(p, JSON.stringify({ fn: 'somethingElse', args: [] }));
      expect(() => build('escrow:resolve', [REG, p])).toThrow(/not a desk submission/);
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });
});

describe('argument handling', () => {
  it('reads booleans the way an operator writes them', () => {
    expect(build('escrow:verifier', [REG, X, 'true']).args[1]).toBe(true);
    expect(build('escrow:verifier', [REG, X, '1']).args[1]).toBe(true);
    expect(build('escrow:verifier', [REG, X, 'on']).args[1]).toBe(true);
    expect(build('escrow:verifier', [REG, X, 'false']).args[1]).toBe(false);
    // Anything unrecognised is false rather than a silent true: revoking by accident is
    // recoverable, granting by accident is not.
    expect(build('escrow:verifier', [REG, X, 'yes-please']).args[1]).toBe(false);
  });

  it('names the missing argument instead of failing obscurely', () => {
    expect(() => build('lp:tier', [REG])).toThrow(/missing lp/);
    expect(() => build('lp:tier', [REG, X])).toThrow(/missing tier/);
    expect(() => build('vault:cap', [REG])).toThrow(/missing capWei/);
    expect(() => build('governor:transfer', [])).toThrow(/missing contract/);
  });

  it('rejects a malformed address or hash rather than encoding it', () => {
    expect(() => build('governor:transfer', ['0xnothex', X])).toThrow();
    expect(() => build('zktls:endpoint', [REG, '0x1234', 'https://bank.example/pix/'])).toThrow(/32-byte/);
    expect(() => build('zktls:endpoint', [REG, `0x${'11'.repeat(32)}`, 'https://bank.example.evil.io'])).toThrow(/host must end/);
  });

  /**
   * The expected value comes from `getAddress` itself, not from EIP-55 casing typed out by
   * hand. An earlier version of this test asserted a hand-written mixed case and failed -
   * the same shape as the Phase 1 label bug, except here the library disagreed loudly
   * instead of agreeing with a wrong assumption.
   */
  it('checksums addresses so a lowercase paste still encodes correctly', () => {
    const lower = '0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa';
    const { to } = build('vault:pause', [lower]);
    expect(to).toBe(getAddress(lower));
    expect(to).not.toBe(lower);
  });
});

describe('commands that take no arguments', () => {
  it('builds pause and resume with an empty argument list', () => {
    expect(encode(cmd('vault:pause'), [REG])).toMatchObject({ to: REG, fn: 'pauseDeposits', args: [] });
    expect(encode(cmd('vault:resume'), [REG])).toMatchObject({ to: REG, fn: 'resumeDeposits', args: [] });
  });
});

describe('numeric widths', () => {
  it('passes basis points and decimals as numbers, matching uint16 and uint8', () => {
    expect(build('vault:drawdown', [REG, '500']).args).toEqual([500]);
    expect(build('escrow:asset', [REG, X, X, '6', 'true']).args).toEqual([X, X, 6, true]);
  });

  it('passes wei-scale values as bigint so large caps survive', () => {
    const big = '1000000000000000000000000';
    expect(build('vault:cap', [REG, big]).args).toEqual([BigInt(big)]);
  });
});

describe('node-provider rewards', () => {
  const RW = '0x4444444444444444444444444444444444444444';

  /**
   * Read from the contracts, as the oracle test is: every setter NodeRewards and FeeSplitter declare delayable, and the
   * registry's rewards hook, has a command whose risk line says DELAYED. A setter made delayable without its command being
   * relabelled fails here.
   */
  it('labels every delayable NodeRewards, FeeSplitter and rewards-hook setter DELAYED, read from the contracts', () => {
    const root = new URL('../../../contracts/', import.meta.url).pathname;
    const checked: string[] = [];
    for (const [f, only] of [['ramp/NodeRewards.sol', undefined], ['movva/FeeSplitter.sol', undefined], ['ramp/LPRegistry.sol', 'setRewardsHook']] as const) {
      const src = readFileSync(join(root, f), 'utf8');
      const body = src.slice(src.indexOf('function _isDelayable'), src.indexOf('\n    }', src.indexOf('function _isDelayable')));
      const names = [...body.matchAll(/\.(\w+)\.selector/g)].map((m) => m[1]).filter((n) => !only || n === only);
      expect(names.length, f).toBeGreaterThan(0);
      for (const name of names) {
        const params = src.match(new RegExp(`function\\s+${name}\\s*\\(([^)]*)\\)`))![1];
        const arity = params.split(',').map((p) => p.trim()).filter(Boolean).length;
        const commands = Object.entries(COMMANDS).filter(([k, c]) => !k.startsWith('gov:') && abiOf(c).name === name && abiOf(c).inputs.length === arity);
        expect(commands.length, `${f}: ${name}/${arity} has a command`).toBeGreaterThan(0);
        for (const [k, c] of commands) expect(c.risk, `${k} (${f} ${name}/${arity})`).toMatch(/DELAYED/);
        checked.push(`${name}/${arity}`);
      }
    }
    expect(checked.sort()).toEqual(['setExcluded/2', 'setLpRewardShare/1', 'setRegistry/1', 'setRewardLimits/3', 'setRewards/1', 'setRewardsHook/1', 'setTreasury/1']);
  });

  it('encodes each command at the contract\'s widths and refuses what the contracts would', () => {
    expect(encode(cmd('splitter:share'), [RW, '2000'])).toMatchObject({ signature: 'setLpRewardShare(uint16)', args: [2000] });
    expect(() => build('splitter:share', [RW, String(REWARD_CAPS.lpRewardShareBps + 1)])).toThrow(/between 0 and 5000/);
    const limits = encode(cmd('rewards:limits'), [RW, '10', '10000', '1000']);
    expect(limits.signature).toBe('setRewardLimits(uint16,uint256,uint256)');
    expect(limits.args).toEqual([10, 10_000n * 10n ** 18n, 1_000n]);
    expect(() => build('rewards:limits', [RW, '21', '1', '1'])).toThrow(/between 0 and 20/);
    expect(encode(cmd('rewards:void'), [RW, '12', X])).toMatchObject({ signature: 'voidVolume(uint256,address)', args: [12n, X] });
    expect(encode(cmd('rewards:exclude'), [RW, X, 'true'])).toMatchObject({ signature: 'setExcluded(address,bool)', args: [X, true] });
    expect(encode(cmd('lp:rewards-hook'), [REG, RW])).toMatchObject({ signature: 'setRewardsHook(address)', args: [RW] });
    expect(signatureOf(cmd('rewards:registry'))).toBe('setRegistry(address)');
    expect(signatureOf(cmd('splitter:split'))).toBe('split()');
    expect(toFunctionSelector(signatureOf(cmd('rewards:limits')))).not.toBe(toFunctionSelector(signatureOf(cmd('movva:limits'))));
  });

  it('sends the permissionless calls from any funded key, never the governor\'s', () => {
    expect(cmd('splitter:split').role).toBe('submitter');
    expect(cmd('rewards:finalize').role).toBe('submitter');
    for (const n of ['splitter:share', 'splitter:treasury', 'splitter:rewards', 'rewards:registry', 'rewards:limits', 'rewards:exclude', 'rewards:void', 'lp:rewards-hook']) {
      expect(cmd(n).role ?? 'governor', n).toBe('governor');
    }
  });

  it('classifies a share change and a limits change by direction, as the contracts do', () => {
    expect(classifySplitterShare(0, 2_000, true)).toMatchObject({ delayed: true });
    expect(classifySplitterShare(2_000, 500, true)).toMatchObject({ delayed: false });
    expect(classifySplitterShare(0, 2_000, false).text).toMatch(/still in setup/);
    const cur = { rewardBpsOfVolume: 10n, maxRewardPerLpPerEpoch: 10_000n * 10n ** 18n, minCountedCents: 1_000n };
    expect(classifyRewardLimits(cur, { ...cur, rewardBpsOfVolume: 11n }, true)).toMatchObject({ delayed: true });
    expect(classifyRewardLimits(cur, { ...cur, minCountedCents: 999n }, true)).toMatchObject({ delayed: true });
    expect(classifyRewardLimits(cur, { ...cur, maxRewardPerLpPerEpoch: 1n, minCountedCents: 5_000n }, true)).toMatchObject({ delayed: false });
    expect(classifyRewardLimits(cur, cur, true).text).toMatch(/no limit changes/);
  });
});

describe('gas sponsorship: SponsorPaymaster behind SponsorGate', () => {
  const GATE = '0x0000000000000000000000000000000000005a7e';
  const PM = '0x000000000000000000000000000000000000fa11';
  const source = (file: string) => readFileSync(new URL(`../../../contracts/${file}`, import.meta.url), 'utf8');
  /** The contract's own body, without the interfaces declared above it. */
  const body = (file: string, contract: string) => source(file).split(`contract ${contract} {`)[1]!;
  const signatures = (src: string) => new Set([...src.matchAll(/function\s+(\w+)\s*\(([^)]*)\)/g)]
    .map((m) => `${m[1]}(${m[2]!.split(',').map((p) => p.trim().split(/\s+/)[0]).filter(Boolean).join(',')})`));

  it('has a command for every SponsorPaymaster owner function and every SponsorGate governance function', () => {
    const covered = new Set(Object.values(COMMANDS).map((c) => `${abiOf(c).name}/${abiOf(c).inputs.length}`));
    const privileged: string[] = [];
    for (const [file, contract] of [['SponsorPaymaster.sol', 'SponsorPaymaster'], ['SponsorGate.sol', 'SponsorGate']] as const) {
      const src = body(file, contract);
      for (const m of src.matchAll(/function\s+(\w+)\s*\(([^)]*)\)([^{;]*)\{/g)) {
        const start = m.index! + m[0].length;
        const fnBody = src.slice(start, src.indexOf('\n    }', start));
        const guarded = /\bonly(Governor|Owner)\b/.test(m[3]!) || /msg\.sender\s*[!=]=\s*(governor|pendingGovernor|guardian)\b/.test(fnBody);
        if (!guarded || !/\b(external|public)\b/.test(m[3]!)) continue;
        privileged.push(`${m[1]}/${m[2]!.split(',').map((p) => p.trim()).filter(Boolean).length} (${file})`);
      }
    }
    expect(privileged.length).toBeGreaterThan(20);
    expect(privileged.filter((p) => !covered.has(p.split(' ')[0]!)).join(', '), 'add a command in packages/ops/src/bin/admin.ts').toBe('');
    // Operators' own calls are not admin commands: they belong to the co-signer's sponsorship module.
    expect(Object.values(COMMANDS).some((c) => ['sponsor', 'sponsorBatch', 'unsponsor'].includes(abiOf(c).name))).toBe(false);
  });

  it('names each paymaster: command after a function both contracts have with the same signature, so it reaches either', () => {
    const pm = signatures(body('SponsorPaymaster.sol', 'SponsorPaymaster'));
    const gate = signatures(body('SponsorGate.sol', 'SponsorGate'));
    const forwarded = Object.entries(COMMANDS).filter(([n]) => n.startsWith('paymaster:') && n !== 'paymaster:transfer-ownership');
    expect(forwarded.length).toBe(10);
    for (const [name, c] of forwarded) {
      expect(pm.has(signatureOf(c)), `${name} on SponsorPaymaster`).toBe(true);
      expect(gate.has(signatureOf(c)), `${name} on SponsorGate`).toBe(true);
    }
    expect(pm.has(signatureOf(cmd('paymaster:transfer-ownership')))).toBe(true);
    for (const n of ['sponsor-gate:operator', 'sponsor-gate:budget', 'sponsor-gate:guardian', 'sponsor-gate:transfer-paymaster', 'sponsor-gate:accept-governor']) {
      expect(gate.has(signatureOf(cmd(n))), n).toBe(true);
    }
  });

  it('encodes adding and revoking operators, the budget, the ownership handover, a batch and a stake with its value', () => {
    const revoke = encode(cmd('sponsor-gate:operator'), [GATE, X, 'false']);
    expect(revoke).toMatchObject({ to: getAddress(GATE), signature: 'setOperator(address,bool)', args: [getAddress(X), false] });
    expect(decodeFunctionData({ abi: [abiOf(cmd('sponsor-gate:operator'))], data: revoke.data }).args).toEqual([getAddress(X), false]);
    const add = encode(cmd('sponsor-gate:operator'), [GATE, X, 'true']);
    expect(add.data).toBe(`${toFunctionSelector('setOperator(address,bool)')}${'0'.repeat(24)}${X.slice(2)}${'0'.repeat(63)}1`);
    expect(encode(cmd('sponsor-gate:budget'), [GATE, '500'])).toMatchObject({ signature: 'setMaxSponsorsPerWindow(uint32)', args: [500] });
    expect(() => encode(cmd('sponsor-gate:budget'), [GATE, '100001'])).toThrow(/100000/);
    const handover = encode(cmd('paymaster:transfer-ownership'), [PM, GATE]);
    expect(handover).toMatchObject({ to: getAddress(PM), signature: 'transferOwnership(address)', args: [getAddress(GATE)] });
    expect(handover.data).toBe(`0xf2fde38b${'0'.repeat(24)}${GATE.slice(2)}`);
    expect(encode(cmd('paymaster:withdraw'), [GATE, X, '5'])).toMatchObject({ to: getAddress(GATE), signature: 'withdrawTo(address,uint256)', args: [getAddress(X), 5n] });
    expect(encode(cmd('paymaster:sponsor-batch'), [GATE, `${X},${REG}`, 'false']).args).toEqual([[getAddress(X), getAddress(REG)], false]);
    const stake = encode(cmd('paymaster:add-stake'), [GATE, '86400', '2000000000000000000']);
    expect(stake).toMatchObject({ signature: 'addStake(uint32)', args: [86400], value: 2n * 10n ** 18n });
    expect(encode(cmd('paymaster:max-cost'), [PM, '1']).value).toBeUndefined();
  });

  it('deploys SponsorGate with constructor arguments matching the contract\'s constructor, then says what to run', () => {
    const d = DEPLOYS['sponsor-gate:deploy']!;
    const ctor = parseAbi([d.constructorAbi])[0] as unknown as { inputs: readonly AbiParameter[] };
    const solidity = /constructor\(([^)]*)\)/.exec(body('SponsorGate.sol', 'SponsorGate'))![1]!.split(',').map((p) => p.trim().split(/\s+/)[0]);
    expect(solidity.map((t) => (t === 'ISponsorPaymaster' ? 'address' : t))).toEqual(ctor.inputs.map((i) => i.type));
    const zero = '0x0000000000000000000000000000000000000000';
    const { args, constructorArgs } = encodeDeploy(d, [PM, REG, zero, '200']);
    expect(args).toEqual([getAddress(PM), getAddress(REG), zero, 200]);
    expect(decodeAbiParameters(ctor.inputs, constructorArgs)).toEqual([getAddress(PM), getAddress(REG), zero, 200]);
    expect(() => encodeDeploy(d, [PM, REG, zero, '100001'])).toThrow(/100000/);
    expect(() => encodeDeploy(d, [PM, REG])).toThrow(/missing/);
    expect(d.next(args).join('\n')).toMatch(/paymaster:budget[\s\S]*paymaster:transfer-ownership[\s\S]*sponsor-gate:operator/);
    expect(existsSync(new URL('../../../contracts/SponsorGate.sol', import.meta.url))).toBe(true);
    expect(d.contract).toBe('contracts/SponsorGate.sol:SponsorGate');
  });
});
