import { afterEach, describe, expect, it, vi } from 'vitest';
import { HttpRequestError } from 'viem';
import { redact, redactError } from '../src/redact.js';
import { runChecks, type MonitorTargets } from '../src/checks.js';
import { renderMetrics, serveMonitor } from '../src/server.js';
import { consoleSinkRedacting, webhookSink } from '../src/alerts.js';

const ALCHEMY = 'https://eth-mainnet.g.alchemy.com/v2/AbCdEfGhIjKlMnOpQrStUvWx12';
const INFURA = 'https://mainnet.infura.io/v3/0123456789abcdef0123456789abcdef';
const WEBHOOK = 'https://hooks.slack.com/services/T0AAAAAAA/B0BBBBBBB/cCcCcCcCcCcCcCcCcCcCcCcC';
const KEYS = ['AbCdEfGhIjKlMnOpQrStUvWx12', '0123456789abcdef0123456789abcdef', 'cCcCcCcCcCcCcCcCcCcCcCcC'];

/** viem's own error, with viem's own formatting: exactly what a failed RPC read throws. */
const viemError = (url: string) => new HttpRequestError({
  url, status: 401, body: { method: 'eth_call', params: [{ to: '0x01', data: '0xd7b0fef1' }, 'latest'] },
  details: '{"code":-32000,"message":"Must be authenticated!"}',
});

/** A readContract failure as viem@2 prints it, captured from a real call. */
const READ_CONTRACT_MESSAGE = `HTTP request failed.

URL: ${INFURA}
Request body: {"method":"eth_call","params":[{"data":"0xd7b0fef1","to":"0x0000000000000000000000000000000000000001"},"latest"]}

Raw Call Arguments:
  to:    0x0000000000000000000000000000000000000001
  data:  0xd7b0fef1

Contract Call:
  address:   0x0000000000000000000000000000000000000001
  function:  latestRoot()

Docs: https://viem.sh/docs/contract/readContract
Details: fetch failed
Version: viem@2.56.3`;

const leaks = (text: string) => KEYS.filter((k) => text.includes(k));

describe('redact', () => {
  it('keeps scheme and host of a viem transport error, and drops the key in the path', () => {
    const msg = viemError(ALCHEMY).message;
    expect(msg).toContain(ALCHEMY); // the premise: viem really does print it
    const out = redact(msg);
    expect(leaks(out)).toEqual([]);
    expect(out).toContain('URL: https://eth-mainnet.g.alchemy.com/[redacted]');
    // Everything an operator needs to diagnose it is still there.
    expect(out).toContain('Status: 401');
    expect(out).toContain('Must be authenticated!');
  });

  it('handles the multi-line readContract message', () => {
    const out = redact(READ_CONTRACT_MESSAGE);
    expect(leaks(out)).toEqual([]);
    expect(out).toContain('URL: https://mainnet.infura.io/[redacted]');
    expect(out).toContain('function:  latestRoot()');
  });

  it('drops credentials, query-string keys and fragments', () => {
    const out = redact('failed: https://user:hunter2hunter2@rpc.example:8545/?apikey=QUERYSECRET123#frag.');
    expect(out).toBe('failed: https://rpc.example:8545/[redacted].');
    expect(redact('see http://node.example/')).toBe('see http://node.example');
  });

  /// A Slack incoming webhook is its path. An undici failure names the URL it failed on.
  it('removes a webhook URL, which is its own credential', () => {
    const out = redact(`request to ${WEBHOOK} failed, reason: getaddrinfo ENOTFOUND hooks.slack.com`);
    expect(leaks(out)).toEqual([]);
    expect(out).toContain('https://hooks.slack.com/[redacted]');
  });

  it('removes a configured secret even where it does not appear as a URL', () => {
    const secrets = [ALCHEMY, 'operator-token-0123456789abcdef'];
    const out = redact(
      'proxy said: eth-mainnet.g.alchemy.com/v2/AbCdEfGhIjKlMnOpQrStUvWx12 rejected; '
      + 'path /v2/AbCdEfGhIjKlMnOpQrStUvWx12; token operator-token-0123456789abcdef',
      secrets,
    );
    expect(leaks(out)).toEqual([]);
    expect(out).not.toContain('operator-token');
  });

  it('ignores unset configuration, so optional values pass straight through', () => {
    expect(redact('nothing to hide', [undefined, ''])).toBe('nothing to hide');
  });

  it('never returns a thrown value\'s cause or stack', () => {
    const e = new Error('outer', { cause: viemError(INFURA) });
    expect(redactError(e)).toBe('outer');
    expect(redactError('plain string with https://x.example/secretpath')).toBe(
      'plain string with https://x.example/[redacted]',
    );
  });
});

describe('where errors leave the monitor', () => {
  const ORACLE = '0x0000000000000000000000000000000000000001' as const;
  const failing = (e: Error) => ({
    readContract: async () => { throw e; },
  }) as unknown as MonitorTargets['client'];

  it('a failed check does not carry the RPC key into its detail', async () => {
    const [r] = await runChecks({ client: failing(viemError(ALCHEMY)), oracle: ORACLE, redactValues: [ALCHEMY] });
    expect(r.level).toBe('unknown');
    expect(leaks(r.detail)).toEqual([]);
    expect(r.detail).toContain('eth-mainnet.g.alchemy.com');
  });

  let close: (() => Promise<void>) | undefined;
  afterEach(async () => { await close?.(); close = undefined; });

  /// `/status` is unauthenticated; results may come from anywhere, so it redacts again.
  it('/status serves a redacted detail even when handed a raw one', async () => {
    const s = serveMonitor({
      results: [{ id: 'oracle_freshness', level: 'unknown', detail: `could not be read: ${READ_CONTRACT_MESSAGE}` }],
      sweepAt: 1,
    }, { redactValues: [INFURA] });
    close = s.close;
    const port = await s.listen(0);
    const body = await (await fetch(`http://127.0.0.1:${port}/status`)).text();
    expect(leaks(body)).toEqual([]);
    expect(body).toContain('mainnet.infura.io');
  });

  it('/metrics never exports a detail at all', () => {
    const text = renderMetrics([{ id: 'oracle_freshness', level: 'unknown', detail: READ_CONTRACT_MESSAGE }], 1);
    expect(leaks(text)).toEqual([]);
    expect(text).not.toContain('HTTP request failed');
  });

  it('the webhook posts a redacted alert, and reports its own failure redacted', async () => {
    const bodies: string[] = [];
    const ok = (async (_u: string, init?: { body?: string }) => {
      bodies.push(String(init?.body));
      return { ok: true, status: 200 } as Response;
    }) as unknown as typeof fetch;
    await webhookSink(WEBHOOK, { fetchImpl: ok, redactValues: [ALCHEMY] })({
      id: 'oracle_freshness', kind: 'firing', level: 'unknown', at: 1,
      detail: `could not be read: ${viemError(ALCHEMY).message}`,
    });
    expect(bodies).toHaveLength(1);
    expect(leaks(bodies[0])).toEqual([]);

    const onError = vi.fn();
    const down = (async () => { throw new TypeError(`fetch failed for ${WEBHOOK}`); }) as unknown as typeof fetch;
    await webhookSink(WEBHOOK, { fetchImpl: down, onError })({
      id: 'x', kind: 'firing', level: 'fail', detail: 'y', at: 1,
    });
    expect(onError).toHaveBeenCalledOnce();
    expect(leaks(String(onError.mock.calls[0][0]))).toEqual([]);
  });

  it('the console sink logs a redacted detail', () => {
    const log = vi.spyOn(console, 'log').mockImplementation(() => {});
    try {
      consoleSinkRedacting([INFURA])({
        id: 'x', kind: 'firing', level: 'unknown', detail: READ_CONTRACT_MESSAGE, at: 1,
      });
      expect(leaks(String(log.mock.calls[0][0]))).toEqual([]);
    } finally {
      log.mockRestore();
    }
  });
});
