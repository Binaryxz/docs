import { describe, expect, it } from 'vitest';
import { containsSecret, redact } from '../src/redact.js';

/**
 * `containsSecret` is the check for a boundary that must serve its payload verbatim (payment instructions
 * carry URLs whose paths are the payload). It must flag exactly what `redact` would remove from a
 * configured secret - the whole value, and for a URL its credentials, path and long segments - and
 * nothing a legitimate payload carries.
 */
describe('containsSecret', () => {
  const rpc = 'https://user:pa55word@eth-mainnet.g.alchemy.com/v2/sEcReTkEy0123456789?token=qwertyuiop123';

  it('finds a configured secret whole, or any piece redact would remove', () => {
    for (const leak of [rpc, 'sEcReTkEy0123456789', 'qwertyuiop123', 'pa55word', '/v2/sEcReTkEy0123456789?token=qwertyuiop123']) {
      expect(containsSecret(`error: ${leak} failed`, [rpc]), leak).toBe(true);
      expect(redact(`error: ${leak} failed`, [rpc]), leak).not.toContain(leak);
    }
    expect(containsSecret('key 0xabc0123456789def', [undefined, '', '0xabc0123456789def'])).toBe(true);
  });

  it('passes a payload that carries URLs and keys of its own but no configured secret', () => {
    const payload = JSON.stringify({
      checkoutUrl: 'https://checkout.acquirer.example/pay/ck_7f3a9c2e1b?session=abc123def456',
      pixKey: '12.345.678/0001-95', salt: `0x${'ab'.repeat(32)}`,
    });
    expect(containsSecret(payload, [rpc, undefined, ''])).toBe(false);
    expect(containsSecret(payload, [])).toBe(false);
  });
});
