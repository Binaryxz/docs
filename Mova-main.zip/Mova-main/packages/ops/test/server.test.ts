import { afterEach, describe, expect, it } from 'vitest';
import { renderMetrics, serveMonitor, type MonitorState } from '../src/server.js';
import type { CheckResult } from '../src/checks.js';

const results: CheckResult[] = [
  { id: 'oracle_freshness', level: 'warn', detail: 'BRL price is 3600s old', value: 3600, threshold: 1800 },
  { id: 'relayer_gas', level: 'ok', detail: 'relayer holds 1.0000 ETH', value: 1, threshold: 0.02 },
  { id: 'asp_root_age', level: 'unknown', detail: 'could not be read: RPC 503' },
];

let close: (() => Promise<void>) | undefined;
afterEach(async () => { await close?.(); close = undefined; });

async function up(state: MonitorState): Promise<string> {
  const s = serveMonitor(state);
  close = s.close;
  const port = await s.listen(0);
  return `http://127.0.0.1:${port}`;
}

describe('before the first sweep', () => {
  /**
   * A monitor that has not looked yet must not be scraped for a verdict it has not formed -
   * and must not report itself unhealthy either, or its supervisor restarts it forever.
   */
  it('is alive but not ready', async () => {
    const base = await up({});
    expect((await fetch(`${base}/healthz`)).status).toBe(200);
    expect((await fetch(`${base}/readyz`)).status).toBe(503);
    expect((await fetch(`${base}/metrics`)).status).toBe(503);
    expect((await fetch(`${base}/status`)).status).toBe(503);
  });
});

describe('after a sweep', () => {
  it('is ready and serves the verdict with each check', async () => {
    const base = await up({ results, sweepAt: 1_800_000_000_000, firing: ['oracle_freshness'] });

    expect((await fetch(`${base}/readyz`)).status).toBe(200);

    const body = await (await fetch(`${base}/status`)).json() as {
      verdict: string; firing: string[]; checks: { id: string; level: string }[];
    };
    expect(body.verdict).toBe('warn');
    expect(body.firing).toEqual(['oracle_freshness']);
    expect(body.checks.map((c) => c.id)).toEqual(['oracle_freshness', 'relayer_gas', 'asp_root_age']);
  });

  /**
   * The monitor stays up while the chain it watches is broken. Marking itself unhealthy
   * would get it restarted exactly when it has something to report.
   */
  it('still answers healthz when every check is failing', async () => {
    const base = await up({
      results: [{ id: 'oracle_freshness', level: 'fail', detail: 'stale' }],
      sweepAt: 1,
    });
    expect((await fetch(`${base}/healthz`)).status).toBe(200);
    expect(((await (await fetch(`${base}/status`)).json()) as { verdict: string }).verdict).toBe('fail');
  });

  it('lists its routes on an unknown path', async () => {
    const base = await up({});
    const res = await fetch(`${base}/nope`);
    expect(res.status).toBe(404);
    expect(((await res.json()) as { routes: string[] }).routes).toContain('/metrics');
  });
});

describe('prometheus exposition', () => {
  const text = renderMetrics(results, 1_800_000_000_000);

  it('exports one stable series per check, with the level encoded', () => {
    expect(text).toContain('mova_check_level{check="oracle_freshness"} 1');
    expect(text).toContain('mova_check_level{check="relayer_gas"} 0');
    expect(text).toContain('mova_check_level{check="asp_root_age"} 3');
  });

  it('exports readings and thresholds only where they exist', () => {
    expect(text).toContain('mova_check_value{check="oracle_freshness"} 3600');
    expect(text).toContain('mova_check_threshold{check="oracle_freshness"} 1800');
    // The unknown check has neither, and must not export a zero that would look like a reading.
    expect(text).not.toContain('mova_check_value{check="asp_root_age"}');
  });

  it('stamps the sweep time in seconds, so staleness is visible to the scraper', () => {
    expect(text).toContain('mova_last_sweep_timestamp_seconds 1800000000');
  });

  it('declares HELP and TYPE for every metric it emits', () => {
    for (const m of ['mova_check_level', 'mova_check_value', 'mova_check_threshold', 'mova_last_sweep_timestamp_seconds']) {
      expect(text).toContain(`# HELP ${m} `);
      expect(text).toContain(`# TYPE ${m} gauge`);
    }
  });

  it('serves the exposition with the content type prometheus expects', async () => {
    const base = await up({ results, sweepAt: 1_800_000_000_000 });
    const res = await fetch(`${base}/metrics`);
    expect(res.headers.get('content-type')).toContain('text/plain');
    expect(await res.text()).toContain('mova_check_level');
  });
});
