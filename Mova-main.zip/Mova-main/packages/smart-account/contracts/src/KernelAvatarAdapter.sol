// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

import {IModule, IKernelExecutor} from "./interfaces/IKernel.sol";

/**
 * @title KernelAvatarAdapter
 * @notice Lets the wallet's existing recovery module - a Zodiac Delay Modifier 1.1.1 proxy - drive
 *         a Kernel account exactly as it drives a Safe, so both accounts share one audited queue,
 *         cooldown, veto and expiry implementation instead of Kernel getting a second, new one.
 *
 * THE MISMATCH. A Zodiac module executes by calling
 * `target.execTransactionFromModule(to, value, data, operation)`, the Safe's module interface.
 * Kernel has no such function; its equivalent is `executeFromExecutor(mode, calldata)`, and only
 * an installed ERC-7579 executor may call it. This contract is both halves of the translation,
 * installed on the account twice:
 *
 *   as a FALLBACK for selector 0x468721a7 (execTransactionFromModule), CALL type, hook address(1)
 *       Kernel forwards the call here with the original caller appended as the last 20 bytes
 *       (ExecLib.doFallback2771Call). Hook address(1) means "no hook, any caller": the Delay is not
 *       the EntryPoint, and Kernel's default for a fallback (hook 0) admits only the EntryPoint.
 *   as an EXECUTOR, with abi.encode(delay)
 *       so it may call back `account.executeFromExecutor(single CALL, to ++ value ++ data)`.
 *
 * THE CHECK. `msg.sender` is taken as the account and the appended 20 bytes as the caller. The call
 * proceeds only if that caller is the Delay recorded for that account. Why that is sufficient:
 *   - Through Kernel's fallback, the appended bytes are written by Kernel from its own `caller()`
 *     and always come last. Anyone can call the account's `execTransactionFromModule`, but only the
 *     Delay makes the last 20 bytes equal the Delay.
 *   - Called directly, `msg.sender` is the direct caller, so an attacker can only name ITSELF as
 *     the account. The callback then goes to the attacker's own contract.
 *   - The account can make `msg.sender == account` with arbitrary trailing bytes only through a
 *     call it was already authorised to make (a root-validated UserOperation or another executor),
 *     which could have done anything anyway.
 *
 * Only CALL. The Safe's Delay may queue a DELEGATECALL; this refuses one. A queued call from a stolen
 * passkey can still do anything the account can do (it runs AS the account, including reconfiguring
 * validators), but it cannot run foreign code in the account's storage context. `operation` 1 reverts.
 *
 * Storage is keyed by the account, so no one can pre-register a Delay for someone else's address.
 * Uninstalling either half calls `onUninstall` and clears the Delay: recovery is then off, which
 * only the account (both signers) can do, and which a monitor sees as `DelaySet(account, 0)` next
 * to Kernel's `ModuleUninstalled`.
 *
 * UNAUDITED, and ours. The Delay it serves is audited; this translation is not.
 *
 * Slither's locked-ether: `onInstall`/`onUninstall` are payable because Kernel's IModule declares them
 * so; Kernel calls them with no value, and only a caller sending its own ETH could strand it here.
 */
// slither-disable-next-line locked-ether
contract KernelAvatarAdapter is IModule {
    uint256 internal constant MODULE_TYPE_EXECUTOR = 2;
    uint256 internal constant MODULE_TYPE_FALLBACK = 3;

    /// @dev ERC-7579 ExecMode for one CALL that reverts on failure: callType 0x00, execType 0x00.
    bytes32 internal constant EXEC_MODE_SINGLE = bytes32(0);

    mapping(address account => address delay) public delayOf;

    event DelaySet(address indexed account, address indexed delay);

    error NotTheDelay(address caller);
    error OnlyCall(uint8 operation);
    error ZeroDelay();

    /**
     * @param data abi.encode(address delay) when installed as the executor; empty when installed as
     *        the fallback, whose `onInstall` Kernel calls with the selector data after its call type.
     * @dev Installing the same Delay twice is a no-op; a different one while set is refused, so a
     *      second Delay cannot silently replace the first.
     */
    function onInstall(bytes calldata data) external payable override {
        if (data.length == 0) return;
        address delay = abi.decode(data, (address));
        if (delay == address(0)) revert ZeroDelay();
        address current = delayOf[msg.sender];
        if (current == delay) return;
        if (current != address(0)) revert AlreadyInitialized(msg.sender);
        delayOf[msg.sender] = delay;
        emit DelaySet(msg.sender, delay);
    }

    function onUninstall(bytes calldata) external payable override {
        if (delayOf[msg.sender] == address(0)) return;
        delete delayOf[msg.sender];
        emit DelaySet(msg.sender, address(0));
    }

    function isModuleType(uint256 moduleTypeId) external pure override returns (bool) {
        return moduleTypeId == MODULE_TYPE_EXECUTOR || moduleTypeId == MODULE_TYPE_FALLBACK;
    }

    function isInitialized(address account) external view override returns (bool) {
        return delayOf[account] != address(0);
    }

    /**
     * @notice Reached through the account's fallback when its Delay executes a queued transaction.
     * @return success always true; a failing call reverts, and the Delay's `executeNextTx` with it
     */
    function execTransactionFromModule(address to, uint256 value, bytes calldata data, uint8 operation)
        external
        returns (bool success)
    {
        address account = msg.sender;
        address caller = address(bytes20(msg.data[msg.data.length - 20:]));
        address delay = delayOf[account];
        if (delay == address(0) || caller != delay) revert NotTheDelay(caller);
        if (operation != 0) revert OnlyCall(operation);
        // The returned data is not needed: EXEC_MODE_SINGLE's execType 0x00 reverts on a failed call.
        // slither-disable-next-line unused-return
        IKernelExecutor(account).executeFromExecutor(
            EXEC_MODE_SINGLE, abi.encodePacked(to, value, data)
        );
        return true;
    }
}
