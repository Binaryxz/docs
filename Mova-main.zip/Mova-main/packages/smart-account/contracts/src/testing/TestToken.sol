// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";

/// @notice A token anyone can mint, for local chains only: examples/accounts-live.ts pays with it.
contract TestToken is ERC20 {
    constructor() ERC20("Test BRL", "tBRL") {}

    function mint(address to, uint256 amount) external {
        _mint(to, amount);
    }
}
