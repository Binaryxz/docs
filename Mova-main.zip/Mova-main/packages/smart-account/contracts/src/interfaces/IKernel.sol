// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

/**
 * The part of Kernel v3.1's module interface (ERC-7579 as Kernel implements it) that the modules
 * in this directory need, written out by hand so the project has no dependency on the Kernel
 * repository. Every declaration matches zerodevapp/kernel at commit
 * 03f7f5cf5871cda0070e4223f196f5b577f6cde2 (tag v3.1): src/interfaces/PackedUserOperation.sol,
 * src/interfaces/IERC7579Modules.sol and Kernel.executeFromExecutor. A mismatch would change a
 * function selector and fail loudly in test/KernelIntegration.t.sol, which runs these modules
 * inside the real, vendored Kernel bytecode.
 */

/// @dev EntryPoint v0.7's packed UserOperation, field for field.
struct PackedUserOperation {
    address sender;
    uint256 nonce;
    bytes initCode;
    bytes callData;
    bytes32 accountGasLimits;
    uint256 preVerificationGas;
    bytes32 gasFees;
    bytes paymasterAndData;
    bytes signature;
}

interface IModule {
    error AlreadyInitialized(address smartAccount);
    error NotInitialized(address smartAccount);

    function onInstall(bytes calldata data) external payable;
    function onUninstall(bytes calldata data) external payable;
    function isModuleType(uint256 moduleTypeId) external view returns (bool);
    function isInitialized(address smartAccount) external view returns (bool);
}

interface IValidator is IModule {
    /// @return validationData ERC-4337 packing: sigFailed (1) | validUntil << 160 | validAfter << 208
    function validateUserOp(PackedUserOperation calldata userOp, bytes32 userOpHash)
        external
        payable
        returns (uint256);

    /// @param hash for Kernel, the account's EIP-712 wrapper of the hash the caller asked about
    function isValidSignatureWithSender(address sender, bytes32 hash, bytes calldata data)
        external
        view
        returns (bytes4);
}

/// @dev Kernel's executor entry point. `execMode` is ERC-7579 ExecMode (callType, execType, ...).
interface IKernelExecutor {
    function executeFromExecutor(bytes32 execMode, bytes calldata executionCalldata)
        external
        payable
        returns (bytes[] memory returnData);
}
