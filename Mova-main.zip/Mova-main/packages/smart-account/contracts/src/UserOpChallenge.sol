// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

/**
 * @title UserOpChallenge
 * @notice What a Kernel validator in this project asks its signers to sign for a UserOperation,
 *         and how the answer is packed for the EntryPoint.
 *
 * The EntryPoint hands a validator `userOpHash`, which already binds the operation, the account,
 * the EntryPoint and the chain. It does not bind a validity window: an account that signed the
 * bare hash would have signed an operation valid forever, and whoever held it could submit it
 * next week. Safe4337Module solves this with `validAfter`/`validUntil` inside its SafeOp struct,
 * and the Safe side of this wallet signs a 15-minute window. The validators here do the same, so
 * a Kernel account is no weaker:
 *
 *   userOp.signature = validAfter (6 bytes) || validUntil (6 bytes) || body
 *   challenge        = keccak256(abi.encode(TYPEHASH, userOpHash, validAfter, validUntil, validator))
 *
 * The 12-byte header is Safe4337Module's layout, byte for byte. The window is returned to the
 * EntryPoint in `validationData`, so it is enforced by the EntryPoint, not by this code; a
 * `validUntil` of 0 means no expiry, exactly as in ERC-4337.
 *
 * The validator's own address is in the challenge so one signature can never satisfy two
 * validators installed on the same account. No 0x1901 prefix: the preimage starts with a
 * 32-byte type hash, so it cannot collide with an EIP-712 digest (Safe's SafeOp, Zodiac's
 * ModuleTx, Kernel's ERC-1271 wrapper) that the same passkey may sign.
 *
 * `packages/smart-account/src/kernel-validators.ts` computes the same value (`kernelUserOpChallenge`).
 */
library UserOpChallenge {
    bytes32 internal constant TYPEHASH = keccak256(
        "UserOpChallenge(bytes32 userOpHash,uint48 validAfter,uint48 validUntil,address validator)"
    );

    uint256 internal constant HEADER_LENGTH = 12;

    /// @dev ERC-4337's SIG_VALIDATION_FAILED, as the low 160 bits ("authorizer") of validationData.
    uint256 internal constant SIG_VALIDATION_FAILED = 1;

    error SignatureTooShort(uint256 length);

    function split(bytes calldata signature)
        internal
        pure
        returns (uint48 validAfter, uint48 validUntil, bytes calldata body)
    {
        if (signature.length < HEADER_LENGTH) revert SignatureTooShort(signature.length);
        validAfter = uint48(bytes6(signature[0:6]));
        validUntil = uint48(bytes6(signature[6:12]));
        body = signature[HEADER_LENGTH:];
    }

    function hash(bytes32 userOpHash, uint48 validAfter, uint48 validUntil, address validator)
        internal
        pure
        returns (bytes32)
    {
        return keccak256(abi.encode(TYPEHASH, userOpHash, validAfter, validUntil, validator));
    }

    /// @dev The window is returned even when the signature failed: the EntryPoint reads `failed` first.
    function validationData(bool failed, uint48 validAfter, uint48 validUntil)
        internal
        pure
        returns (uint256)
    {
        return (failed ? SIG_VALIDATION_FAILED : 0) | (uint256(validUntil) << 160)
            | (uint256(validAfter) << 208);
    }
}
