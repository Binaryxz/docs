// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

import {SchnorrVerifier} from "mova-contracts/SchnorrVerifier.sol";
import {IValidator, PackedUserOperation} from "./interfaces/IKernel.sol";
import {UserOpChallenge} from "./UserOpChallenge.sol";

/**
 * @title FrostValidator
 * @notice The Kernel equivalent of the wallet's FROST option: the account's authority is a FROST
 *         threshold group (device + server from a DKG, packages/mpc), and the chain sees one
 *         Schnorr signature.
 *
 * On the Safe side the group is a `FrostSigner` contract that the Safe calls as its only owner.
 * Kernel has no owners, so the group key lives here, per account, and verification is the same
 * library call FrostSigner makes: `SchnorrVerifier.verify(sig, groupKey, abi.encodePacked(digest))`
 * from contracts/SchnorrVerifier.sol, imported, not copied. The message is the 32-byte digest, as
 * for FrostSigner, so the signing side runs the same session over the same bytes.
 *
 * WHAT IS SIGNED. For a UserOperation, `UserOpChallenge.hash(userOpHash, validAfter, validUntil,
 * this)` with the 12-byte validity header in front of the signature. For ERC-1271, the hash Kernel
 * passes in (already wrapped in Kernel's EIP-712 domain for the account).
 *
 * Signature body: abi.encode(uint256 rx, uint256 ry, uint256 z), FrostSigner's encoding.
 *
 * `SchnorrVerifier.verify` reverts on a point off the curve or z outside (0, N). Those cases are
 * checked first and reported as an invalid signature instead, so a garbage signature is AA24
 * (signature error) at the EntryPoint and not AA23 (reverted), and ERC-1271 answers "invalid"
 * rather than reverting in a verifier's `eth_call`.
 *
 * `rotateGroupKey`, called by the account itself, replaces the key after a new DKG, for instance
 * with a replacement server. It is the counterpart of `PasskeyCoSignerValidator.rotateCoSigner`.
 *
 * NOT a hook (`isModuleType(4)` is false); see PasskeyCoSignerValidator for why that matters.
 *
 * UNAUDITED, and it inherits the audit status of SchnorrVerifier.sol and packages/mpc, which are
 * unaudited from-specification cryptography (docs/audit-scope.md ranks them first).
 *
 * Slither's locked-ether: `onInstall`, `onUninstall` and `validateUserOp` are payable because Kernel's
 * IModule/IValidator declare them so; Kernel calls them with no value, and only a caller sending its own
 * ETH could strand it here.
 */
// slither-disable-next-line locked-ether
contract FrostValidator is IValidator {
    using UserOpChallenge for bytes;

    struct GroupKey {
        uint256 x;
        uint256 y;
    }

    bytes4 internal constant ERC1271_MAGIC = 0x1626ba7e;
    bytes4 internal constant ERC1271_INVALID = 0xffffffff;
    uint256 internal constant MODULE_TYPE_VALIDATOR = 1;

    mapping(address account => GroupKey) internal _keys;

    event FrostGroupInstalled(address indexed account, uint256 x, uint256 y);
    event FrostGroupUninstalled(address indexed account);
    event FrostGroupRotated(address indexed account, uint256 x, uint256 y);

    error InvalidGroupKey();

    /// @param data abi.encode(uint256 x, uint256 y), the group public key from the DKG
    function onInstall(bytes calldata data) external payable override {
        if (_keys[msg.sender].x != 0) revert AlreadyInitialized(msg.sender);
        (uint256 x, uint256 y) = abi.decode(data, (uint256, uint256));
        _checkKey(x, y);
        _keys[msg.sender] = GroupKey(x, y);
        emit FrostGroupInstalled(msg.sender, x, y);
    }

    function onUninstall(bytes calldata) external payable override {
        if (_keys[msg.sender].x == 0) revert NotInitialized(msg.sender);
        delete _keys[msg.sender];
        emit FrostGroupUninstalled(msg.sender);
    }

    function isModuleType(uint256 moduleTypeId) external pure override returns (bool) {
        return moduleTypeId == MODULE_TYPE_VALIDATOR;
    }

    function isInitialized(address account) external view override returns (bool) {
        return _keys[account].x != 0;
    }

    function groupKeyOf(address account) external view returns (GroupKey memory) {
        return _keys[account];
    }

    /// @notice Replace the group key after a new DKG. Only the account can call it, for itself.
    function rotateGroupKey(uint256 x, uint256 y) external {
        if (_keys[msg.sender].x == 0) revert NotInitialized(msg.sender);
        _checkKey(x, y);
        _keys[msg.sender] = GroupKey(x, y);
        emit FrostGroupRotated(msg.sender, x, y);
    }

    function validateUserOp(PackedUserOperation calldata userOp, bytes32 userOpHash)
        external
        payable
        override
        returns (uint256)
    {
        (uint48 validAfter, uint48 validUntil, bytes calldata body) = userOp.signature.split();
        GroupKey memory key = _keys[msg.sender];
        if (key.x == 0) return UserOpChallenge.validationData(true, validAfter, validUntil);
        bytes32 challenge = UserOpChallenge.hash(userOpHash, validAfter, validUntil, address(this));
        return UserOpChallenge.validationData(!_verify(key, challenge, body), validAfter, validUntil);
    }

    function isValidSignatureWithSender(address, bytes32 hash, bytes calldata data)
        external
        view
        override
        returns (bytes4)
    {
        GroupKey memory key = _keys[msg.sender];
        if (key.x == 0) return ERC1271_INVALID;
        return _verify(key, hash, data) ? ERC1271_MAGIC : ERC1271_INVALID;
    }

    function _verify(GroupKey memory key, bytes32 digest, bytes calldata body)
        internal
        pure
        returns (bool)
    {
        if (body.length != 96) return false;
        (uint256 rx, uint256 ry, uint256 z) = abi.decode(body, (uint256, uint256, uint256));
        if (!SchnorrVerifier.onCurve(rx, ry) || z == 0 || z >= SchnorrVerifier.N) return false;
        return SchnorrVerifier.verify(
            SchnorrVerifier.Signature(rx, ry, z),
            SchnorrVerifier.PublicKey(key.x, key.y),
            abi.encodePacked(digest)
        );
    }

    /// @dev On secp256k1, and x not a multiple of N: SchnorrVerifier inverts it.
    function _checkKey(uint256 x, uint256 y) internal pure {
        if (!SchnorrVerifier.onCurve(x, y) || x % SchnorrVerifier.N == 0) revert InvalidGroupKey();
    }
}
