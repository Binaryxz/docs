// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

import {ECDSA} from "@openzeppelin/contracts/utils/cryptography/ECDSA.sol";
import {IValidator, PackedUserOperation} from "./interfaces/IKernel.sol";
import {UserOpChallenge} from "./UserOpChallenge.sol";

/// @dev SafeWebAuthnSignerFactory 0.2.1 (safe-global/safe-modules, tag passkey/v0.2.1).
interface IWebAuthnVerifier {
    /// @param verifiers P256.Verifiers: high 16 bits a precompile to try, low 160 a fallback verifier
    function isValidSignatureForSigner(
        bytes32 message,
        bytes calldata signature,
        uint256 x,
        uint256 y,
        uint176 verifiers
    ) external view returns (bytes4 magicValue);
}

/**
 * @title PasskeyCoSignerValidator
 * @notice The Kernel equivalent of the wallet's default Safe: 2-of-2, a passkey AND a server
 *         co-signer, both required for every UserOperation and every ERC-1271 signature.
 *
 * WHY ONE VALIDATOR FOR TWO SIGNERS. Kernel has no owner set and no threshold. Every validator
 * installed on an account is a complete authority on its own: the root validator for anything,
 * any other validator for the selectors it was enabled for. Installing a "passkey validator" and a
 * "co-signer validator" side by side would make each of them able to spend alone, which is the
 * one property the custody design exists to prevent. The AND has to live inside one validator.
 *
 * HOW THE PASSKEY IS CHECKED. Exactly as the Safe path checks it. The P-256 assertion is handed to
 * the canonical SafeWebAuthnSignerFactory's `isValidSignatureForSigner`, which runs the audited
 * SafeWebAuthnSigner singleton (WebAuthn payload reconstruction, user-verification flag, P-256 via
 * the FCL verifier or a RIP-7212 precompile) against the key stored here. The signature bytes are
 * the Safe path's `encodeWebAuthnSignature` output, unchanged. No per-credential signer contract
 * is needed for spending; recovery still deploys one, because the Zodiac Delay authenticates its
 * module by an ERC-1271 call to an address.
 *
 * ZeroDev's own WebAuthnValidator (kernel-7579-plugins) was not used: it calls the RIP-7212
 * precompile at 0x100 and falls back to Daimo's verifier at a fixed address. Ethereum L1 has no
 * such precompile, a plain anvil has neither, and it would be a second, different P-256 stack next
 * to the one the Safe path already depends on and that has been audited (Certora, Nethermind).
 *
 * HOW THE CO-SIGNER IS CHECKED. A 65-byte ECDSA signature over the same 32-byte challenge,
 * recovered by OpenZeppelin 5.1's `ECDSA.tryRecover` (rejects high-s and malformed signatures),
 * compared with the stored address. No eth_sign prefix, as with the Safe's `signSafeOp`.
 *
 * WHAT IS SIGNED. For a UserOperation, `UserOpChallenge.hash(userOpHash, validAfter, validUntil,
 * this)`. For ERC-1271, the hash Kernel passes in, which Kernel has already wrapped in its own
 * EIP-712 domain (name "Kernel", version "0.3.1", the account address, the chain).
 *
 * Both checks always run, even when the first fails. A wallet estimating gas with a placeholder
 * signature therefore pays for both verifications and does not underestimate by the ~800k gas of
 * a P-256 verification.
 *
 * WHAT THE ACCOUNT CAN CHANGE. `rotateCoSigner`, called by the account itself: the Kernel
 * counterpart of the Safe's `swapOwner(deadServer, newServer)`. In normal operation that call needs
 * both signatures like any other; with the server gone it arrives through the Zodiac Delay after
 * the cooldown (see KernelAvatarAdapter). The passkey is not rotatable here: a new credential means
 * a new validator installed by the account.
 *
 * NOT a hook. `isModuleType(4)` is false. Kernel lets ANY caller reach `execute`, `installModule`
 * and `upgradeTo` when the root validator claims to be a hook (`onlyEntryPointOrSelfOrRoot`), and
 * a validator that answered true would open the account to everyone.
 *
 * UNAUDITED. This contract is ours. The P-256 and ECDSA primitives it calls are audited; the
 * composition, the storage and the challenge format are not.
 *
 * Slither's locked-ether: `onInstall`, `onUninstall` and `validateUserOp` are payable because Kernel's
 * IModule/IValidator declare them so; Kernel calls them with no value, and only a caller sending its own
 * ETH could strand it here.
 */
// slither-disable-next-line locked-ether
contract PasskeyCoSignerValidator is IValidator {
    using UserOpChallenge for bytes;

    struct Config {
        uint256 x;
        uint256 y;
        uint176 verifiers;
        address coSigner;
    }

    bytes4 internal constant ERC1271_MAGIC = 0x1626ba7e;
    bytes4 internal constant ERC1271_INVALID = 0xffffffff;
    uint256 internal constant MODULE_TYPE_VALIDATOR = 1;

    /// @dev P-256 field prime and curve coefficient b (a = p - 3).
    uint256 internal constant P256_P =
        0xFFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFF;
    uint256 internal constant P256_B =
        0x5AC635D8AA3A93E7B3EBBD55769886BC651D06B0CC53B0F63BCE3C3E27D2604B;

    IWebAuthnVerifier public immutable WEBAUTHN;

    mapping(address account => Config) internal _configs;

    event PasskeyCoSignerInstalled(
        address indexed account, uint256 x, uint256 y, uint176 verifiers, address indexed coSigner
    );
    event PasskeyCoSignerUninstalled(address indexed account);
    event CoSignerRotated(address indexed account, address indexed from, address indexed to);

    error ZeroAddress();
    error ZeroCoSigner();
    error PasskeyNotOnCurve();
    error NoVerifier();

    constructor(IWebAuthnVerifier webauthn) {
        if (address(webauthn) == address(0)) revert ZeroAddress();
        WEBAUTHN = webauthn;
    }

    /*//////////////////////////////////////////////////////////////
                               INSTALLATION
    //////////////////////////////////////////////////////////////*/

    /**
     * @param data abi.encode(uint256 x, uint256 y, uint176 verifiers, address coSigner)
     * @dev Refuses what would brick the account rather than install it: a point that is not on
     *      P-256 (a typo in x or y), no verifier at all, or no co-signer. A zero co-signer would
     *      not make this a passkey-only validator; it would make it a validator nothing satisfies.
     */
    function onInstall(bytes calldata data) external payable override {
        if (_configs[msg.sender].coSigner != address(0)) revert AlreadyInitialized(msg.sender);
        (uint256 x, uint256 y, uint176 verifiers, address coSigner) =
            abi.decode(data, (uint256, uint256, uint176, address));
        if (coSigner == address(0)) revert ZeroCoSigner();
        if (!onP256(x, y)) revert PasskeyNotOnCurve();
        if (verifiers == 0) revert NoVerifier();
        _configs[msg.sender] = Config(x, y, verifiers, coSigner);
        emit PasskeyCoSignerInstalled(msg.sender, x, y, verifiers, coSigner);
    }

    function onUninstall(bytes calldata) external payable override {
        if (_configs[msg.sender].coSigner == address(0)) revert NotInitialized(msg.sender);
        delete _configs[msg.sender];
        emit PasskeyCoSignerUninstalled(msg.sender);
    }

    function isModuleType(uint256 moduleTypeId) external pure override returns (bool) {
        return moduleTypeId == MODULE_TYPE_VALIDATOR;
    }

    function isInitialized(address account) external view override returns (bool) {
        return _configs[account].coSigner != address(0);
    }

    function configOf(address account) external view returns (Config memory) {
        return _configs[account];
    }

    /// @notice Replace the server co-signer. Only the account can call it, for itself.
    function rotateCoSigner(address newCoSigner) external {
        Config storage c = _configs[msg.sender];
        if (c.coSigner == address(0)) revert NotInitialized(msg.sender);
        if (newCoSigner == address(0)) revert ZeroCoSigner();
        emit CoSignerRotated(msg.sender, c.coSigner, newCoSigner);
        c.coSigner = newCoSigner;
    }

    /*//////////////////////////////////////////////////////////////
                                VALIDATION
    //////////////////////////////////////////////////////////////*/

    /**
     * @param userOp its `signature` is validAfter(6) || validUntil(6) || abi.encode(bytes passkey,
     *        bytes coSigner), where `passkey` is the Safe WebAuthn encoding and `coSigner` 65 bytes
     * @dev A malformed body reverts (the EntryPoint reports AA23); a well-formed but wrong one
     *      returns SIG_VALIDATION_FAILED (AA24). An account without a config fails, never passes.
     */
    function validateUserOp(PackedUserOperation calldata userOp, bytes32 userOpHash)
        external
        payable
        override
        returns (uint256)
    {
        (uint48 validAfter, uint48 validUntil, bytes calldata body) = userOp.signature.split();
        Config memory c = _configs[msg.sender];
        if (c.coSigner == address(0)) {
            return UserOpChallenge.validationData(true, validAfter, validUntil);
        }
        bytes32 challenge = UserOpChallenge.hash(userOpHash, validAfter, validUntil, address(this));
        return UserOpChallenge.validationData(!_verify(c, challenge, body), validAfter, validUntil);
    }

    /// @param data abi.encode(bytes passkey, bytes coSigner), both over `hash` as Kernel passes it
    function isValidSignatureWithSender(address, bytes32 hash, bytes calldata data)
        external
        view
        override
        returns (bytes4)
    {
        Config memory c = _configs[msg.sender];
        if (c.coSigner == address(0)) return ERC1271_INVALID;
        return _verify(c, hash, data) ? ERC1271_MAGIC : ERC1271_INVALID;
    }

    function _verify(Config memory c, bytes32 digest, bytes calldata body)
        internal
        view
        returns (bool)
    {
        (bytes memory passkeySignature, bytes memory coSignerSignature) =
            abi.decode(body, (bytes, bytes));
        bool passkeyOk = WEBAUTHN.isValidSignatureForSigner(
            digest, passkeySignature, c.x, c.y, c.verifiers
        ) == ERC1271_MAGIC;
        // Only the error argument is dropped; the error code and the recovered address are both checked.
        // slither-disable-next-line unused-return
        (address recovered, ECDSA.RecoverError err,) = ECDSA.tryRecover(digest, coSignerSignature);
        bool coSignerOk = err == ECDSA.RecoverError.NoError && recovered == c.coSigner;
        return passkeyOk && coSignerOk;
    }

    /// @dev y^2 == x^3 - 3x + b (mod p), with both coordinates in the field and not both zero.
    function onP256(uint256 x, uint256 y) public pure returns (bool) {
        if (x >= P256_P || y >= P256_P || (x == 0 && y == 0)) return false;
        uint256 lhs = mulmod(y, y, P256_P);
        uint256 rhs = addmod(
            addmod(mulmod(mulmod(x, x, P256_P), x, P256_P), mulmod(P256_P - 3, x, P256_P), P256_P),
            P256_B,
            P256_P
        );
        return lhs == rhs;
    }
}
