# @mova/smart-account — task 1.2

Seedless self-custody: a **passkey** seeds the shielded wallet, and a **Safe 2-of-2** smart
account (passkey + server co-signer) spends through **ERC-4337**. A **delayed passkey-only
recovery path** (Zodiac Delay Modifier) means the server dying costs a cooldown, not funds.

The whole custody picture - key tree, what each party can do alone, what each failure costs -
is [docs/wallet-custody.md](../../docs/wallet-custody.md).

```bash
npm test -w @mova/smart-account          # 131 tests, no chain needed

# Safe AND Kernel, both custody configurations, on an empty anvil (8970) + Alto (8971): 64 checks
npx tsx packages/smart-account/examples/accounts-live.ts

# the Kernel validators and adapter (their own Foundry project, NOT the root one): 53 tests
cd packages/smart-account/contracts && $(bash ../../../scripts/foundry.sh path) test

# against a bare mainnet-forked anvil
npx tsx packages/smart-account/examples/passkey-recovery.ts                  # server dead, funds out
npx tsx packages/smart-account/examples/mpc-owner.ts                         # DKG + passkey-sealed share
FORK_RPC=$ETHEREUM_MAINNET_RPC forge test --match-contract PasskeyRecoveryForkTest

# against a mainnet-forked anvil with the pool deployed (see ../../protocol/FORK.md)
npx tsx packages/smart-account/examples/smart-account-deposit.ts <ppEntrypoint> <ppPool>
npx tsx packages/smart-account/examples/passkey-owner.ts       <ppEntrypoint> <ppPool>
npx tsx packages/smart-account/examples/gasless-deposit.ts  <paymaster> <ppEntrypoint> <ppPool>
```

## What runs today

```
1. Passkey seeds the shielded wallet    restored passkey → same spending key ✓
2. Safe 2-of-2                          counterfactual address known up front ✓
4. One owner alone must NOT spend       rejected by the EntryPoint (AA24)     ✓
5. Both owners sign                     UserOperation executed                ✓
6. Result                               threshold 2 of 2, module enabled,
                                        the SAFE is the pool's depositor      ✓
```

Nothing is deployed by us except the user's own Safe. EntryPoint v0.7, the Safe 1.4.1
factory and singleton, `SafeModuleSetup` and `Safe4337Module` 0.3.0 are all canonical
mainnet deployments, so a mainnet fork already has them.

## Passkey → pool seed

A passkey's private key is non-extractable, but the shielded pool needs a spending key that
is **deterministic and recoverable**, because every viewing key and withdrawal witness hangs
off it. A signature cannot supply that: WebAuthn signatures are randomised, so the same
challenge signed twice gives different bytes (`passkey.test.ts` asserts this, because it is
the reason the rest of the design exists).

The **PRF extension** (`hmac-secret`) is the primitive that fits. The authenticator holds a
per-credential secret it never reveals and returns `HMAC(secret, salt)`:

```
passkey ──PRF(POOL_SEED_SALT)──▶ 32 bytes ──HMAC("PP/v1/seed")──▶ pool seed
                                                                     │
                                                          PP/v1/spend ├── PP/v1/view
                                                                      └── PP/v1/ident
```

So no seed is stored, written down, or backed up, and device loss is survived through
ordinary passkey sync. `derivePoolSeed` takes the PRF **output**, not an authenticator, so
production passes `getClientExtensionResults().prf.results.first` and the simulator is a
drop-in for tests.

One extra HMAC separates the pool seed from the raw PRF value: without it, any other feature
evaluating the same salt would hold spending authority.

**Simulated here:** `PasskeyAuthenticator` is software. The cryptography is real — real
P-256 keys, real ECDSA over the real WebAuthn payload (`sha256(authenticatorData ||
sha256(clientDataJSON))`), real HMAC for PRF, low-s normalised — but it holds material a
hardware authenticator would never release. A headless process has no security key; this is
the boundary, and it is the only thing faked.

## Why 2-of-2 multisig, not MPC

The requirement is that no single compromised party can move funds. Two Safe owners with
threshold 2 — the user's device and a server co-signer — deliver that with audited
contracts and no new cryptography. `smart-account-deposit.ts` proves it against the real
EntryPoint rather than asserting it: a single-owner UserOperation is submitted and must be
rejected (AA24).

This is **threshold-by-multisig, not threshold-by-MPC**, and the difference is real:

| | 2-of-2 Safe (here) | True MPC |
|---|---|---|
| On-chain | two signatures, policy public | one signature, indistinguishable |
| Gas | higher | lower |
| Dependency | audited Safe contracts | threshold-signing library or vendor |
| Privacy | co-signing is visible | co-signing is invisible |

For a regulated BRL rail an auditable on-chain policy is arguably a feature, not a cost.
Swapping in an MPC signer changes the **owner set**, not the account, its address
derivation, or anything in this package's interface - and that option now exists:
`examples/mpc-owner.ts` runs a Safe owned by a FROST group from a DKG, with the device share
sealed under the passkey. It is unaudited, so **Safe 2-of-2 (passkey owner + server owner) is
the recommended production default**; the recovery module below works with either.

Hand-rolling 2-party ECDSA was rejected outright: it is precisely the kind of code that
looks correct and loses everyone's funds.

## The passkey in the spending path

`examples/passkey-owner.ts` goes further than seed derivation: it deploys a
`SafeWebAuthnSigner` and makes it an **actual Safe owner**, so a P-256 assertion is verified
on-chain via ERC-1271 and spending requires the authenticator.

```
2. Deploy the WebAuthn signer        at the predicted address, before the Safe exists  OK
5. Neither owner alone may spend     passkey only AA24 · server only AA24              OK
6. Wrong-digest assertion            rejected on-chain (AA24)                          OK
7. Passkey + server co-signer        executed, P-256 verified on-chain                 OK
```

Costs ~956k gas: P-256 runs in Solidity, since mainnet has no RIP-7212 precompile. On a
chain that has one, the same code picks it up through the `verifiers` field.

## Gasless

`examples/gasless-deposit.ts` uses `contracts/SponsorPaymaster.sol` so the user needs no ETH.
The Safe is given exactly the amount it will deposit and no EntryPoint stake, then:

```
4. Control, unsponsored (snapshot)   burns 0.0016 ETH on gas, deposit never lands      OK
5. Account not on the allowlist      refused by the paymaster                          OK
7. Sponsored                         user spent exactly 0.5 ETH, not one wei of gas    OK
                                     sponsor paid 0.00079 ETH                          OK
```

The control runs for real on an `evm_snapshot` and rolls back, because `handleOps` does not
revert when the inner call fails — only on validation failure. "handleOps succeeded" would
have proved nothing.

## Through a real bundler

`examples/bundler-deposit.ts` stops calling `EntryPoint.handleOps` directly — which skips
the bundler's own validation, mempool and pricing — and speaks the actual ERC-4337 RPC:

```
eth_estimateUserOperationGas   verification 449685 · call 353236 · preVerification 56525
eth_sendUserOperation          accepted into the mempool
eth_getUserOperationReceipt    bundled and mined
→ user spent 0.5 ETH (the deposit) and no gas; sponsor paid 0.00079 ETH
→ budget billed in postOp: 0.00074 ETH against this account
```

Run one locally:

```bash
export BUNDLER_EXECUTOR_KEY=0x... BUNDLER_UTILITY_KEY=0x...
npm run bundler          # Alto, EntryPoint v0.7, port 4337
```

The paymaster must be **staked** first — bundlers refuse operations from an unstaked
paymaster, which `handleOps` never enforced. `DeployPaymaster` prints the exact `addStake`
command.

Note the signature covers the gas fields, so the flow is: sign generous limits, ask the
bundler to estimate, then **re-sign** the answer. An estimate cannot be swapped in
afterwards.

## Testing PRF on real hardware

`browser/passkey-check.html` is the part that cannot be automated headlessly. Serve it over
`localhost` (WebAuthn needs a secure context) and it will, on your actual device:

1. create a credential and report whether the authenticator supports PRF at all
2. derive the pool seed **twice** and require both to be identical
3. sign the same challenge twice and require the signatures to *differ*

Step 3 is the one that justifies the whole design: a randomised signature cannot seed a
recoverable wallet, which is why PRF is used instead.

```bash
npx http-server packages/smart-account/browser -p 8080   # or any static server
# then open http://localhost:8080/passkey-check.html
```

This is also how to answer the open question of **PRF availability** across the platforms
your users actually have.

**No phone is required, anywhere.** `authenticatorSelection` deliberately sets no
`authenticatorAttachment`, so cross-platform authenticators are accepted alongside platform
ones: a YubiKey 5 over USB, Windows Hello, a Linux laptop, Android. A USB security key is the
easiest way to exercise PRF from a desktop. Nothing in the key tree, the Safe, or the
co-signer path assumes a mobile device — the second Safe owner is a server key.

## Where the seed comes from — and what happens without PRF

`src/seed-source.ts` separates two questions that used to be tangled: *can this device
produce a seed* (`available()`) and *where does it come from* (the implementation). Before
this, PRF was the only path and a device without it failed with a thrown error deep inside
key derivation rather than a decision onboarding could see coming.

| Source | Seed at rest | Use |
|---|---|---|
| `PrfSeedSource` | **never exists** — recomputed from a secret the authenticator will not release | always, when available |
| `RecoverableSplitSeedSource` | exists, Shamir 2-of-3: device, server, **recovery code the user writes down** | only when PRF is absent |
| `SplitSeedSource` | exists, XOR-split device ⊕ server | **legacy**; migrate with `RecoverableSplitSeedSource.fromLegacySplit` |

The difference is not cosmetic. With PRF there is nothing to steal at rest. With a split,
the seed is a reconstructable value: two shares together give full spending authority. So it
is a fallback, not an alternative.

**The legacy XOR split lost funds when the server share was lost** - nothing else could rebuild
the seed. The 2-of-3 split removes that: device + code opens the wallet with the server gone,
server + code on a new device, and any single share is uniformly random. It splits the same raw
secret the XOR split did and derives the same seed with the same `kind`, so migrating does not
change the wallet. Shares carry a 4-byte wallet tag, so combining shares of two different
wallets fails loudly instead of opening an empty one; the code has a checksum and forgives
case, spacing and O/0, I/L/1. The price is the code itself: it is as sensitive as the device
share and belongs offline.

```ts
// creating: returns the kind to persist beside the account
const { seed, kind } = await openSeed([
  new PrfSeedSource(evaluatePrfInBrowser),      // preferred, always first
  new RecoverableSplitSeedSource({ deviceShare, fetchServerShare, recoveryCode }),
]);

// re-opening: pass the persisted kind, and a fallback is REFUSED
const { seed } = await openSeed(candidates, storedKind);  // throws SeedSourceMismatchError
```

**The two sources produce different seeds, so a silent fallback is not a degraded
experience — it opens a different, empty wallet, which looks exactly like theft.**
`openSeed` therefore refuses rather than falling back, and names both sources in the error
so the fix is obvious. Enforced by code, in both directions, not by this paragraph.

Persist `kind`; do not infer it. A device can gain or lose PRF support between sessions — a
new browser, a different authenticator, an OS update — and inference would pick wrong
precisely when it matters.

Every example in this package goes through `openSeed`. They used to derive seeds directly,
which meant the abstraction had tests but no callers, and the migration rule existed only
as prose.

## Recovery without the server: `src/recovery.ts`

The Safe is the pool's depositor of record, `ragequit` must come from the depositor, and a Safe
transaction needs both owners - so without this, a dead server froze every deposit the ASP had
not approved. The fix reuses audited contracts only:

```
Safe ──module──▶ Zodiac Delay Modifier 1.1.1 proxy (owner = avatar = target = the Safe)
                      ▲ module
                      └── the passkey's SafeWebAuthnSigner (already a Safe owner)

queue    passkey ALONE signs ModuleTx(data, salt); ANY address relays it
wait     7 days (DEFAULT_RECOVERY); TransactionAdded is public the whole time
veto     passkey AND server (the Safe) call setTxNonce to skip it
execute  after the cooldown ANYONE calls executeNextTx; the Delay executes it as the Safe
```

`encodeRecoverySetup` installs it in one UserOperation (bundled with the Safe's deployment in
the example, 923k gas). `buildQueueRequest` + `encodeSignedQueue` queue a call with a passkey
assertion (~330-360k gas, paid by whoever relays), `encodeExecuteNextTx` executes it (~72k for a
depositor-only exit), `encodeVeto` skips the queue, `readRecoveryQueue` and
`parseTransactionAdded` are what a wallet UI and the monitor read.

`contracts/test/PasskeyRecoveryFork.t.sol` performs it on mainnet state (13 tests): passkey-only
queue, refused one second before the cooldown and executed at it, a depositor-only exit and an
owner swap with no server signature, the owners' veto, every way a server alone might queue,
veto, reconfigure or execute early, replay, a signature moved to another call, a failing queued
call that expires instead of jamming recovery, and the attack on the faulty Delay 1.1.0 that is
why the pinned mastercopy is 1.1.1. `examples/passkey-recovery.ts` runs the same flow through
these TypeScript helpers against the deployed bytecode.

Conservative defaults, marked as product decisions in the code: a 7-day cooldown (minimum 3
days, enforced) and a 7-day execution window (never 0: the Delay executes in order, and with no
expiry one reverting queued call would block recovery for good).

## FROST with a passkey-sealed device share: `src/sealed-share.ts`

In the FROST configuration the Safe's owner is the threshold group. The device's DKG share is
stored only as XChaCha20-Poly1305 ciphertext under `HKDF(PRF(SHARE_SEAL_SALT))`: a different PRF
salt from the pool seed and a different KDF label, so neither value yields the other. The AEAD
binds participant id, group key, verification share and credential id; opening checks the share
against its verification point. `sealShareWithPrf` / `openShareWithPrf` evaluate the right salt
themselves. **Safe 2-of-2 remains the recommended default**; FROST is the unaudited
single-signature option.

## Both accounts on an empty chain: `examples/accounts-live.ts`

The examples above need a mainnet fork, since that is where Safe, the EntryPoint and Zodiac live.
`accounts-live.ts` needs nothing but the repository. It starts its own anvil and deploys every
third-party contract from `fixtures/canonical`, using mainnet's own init code with the deployer and
salt mainnet used, and requires each one to land at its mainnet address (provenance in
[fixtures/README.md](fixtures/README.md)). It then deploys the root build's `SponsorPaymaster`, starts
the repository's Alto bundler, and runs both accounts through the **wallet's own executors**
(`SafeExecutor`, `KernelExecutor`, `BundlerSubmitter`):

```
1. Safe    passkey signer + server   created + recovery installed by one sponsored op    OK
                                     server alone AA24 · passkey alone AA24               OK
                                     ERC-1271 accepted by viem verifyTypedData            OK
                                     server gone: passkey queues, 7 days, anyone exits    OK
2. Safe    FROST 2-of-2 owner        sponsored transfer · ERC-1271 · one share AA24       OK
3. Kernel  passkey + server          same as 1, plus ERC-6492 before deployment,
                                     veto of a stolen passkey's drain, NotTheDelay for
                                     the server, co-signer rotated through the Delay      OK
4. Kernel  FROST 2-of-2              same as 2                                            OK
  64 OK, 0 FAIL
```

## Kernel v3.1, next to the Safe

`src/kernel.ts` is the account: canonical addresses, creation through the meta factory,
`predictKernelAddress` (offline, checked against `KernelFactory.getAddress`), `encodeKernelExecute`,
nonce keys, the EntryPoint v0.7 hash, and Kernel's ERC-1271 wrapper. `src/kernel-validators.ts` and
`contracts/src` are the signers:

| Contract (ours, unaudited) | Role |
|---|---|
| `PasskeyCoSignerValidator` | Root validator for the default configuration: passkey AND server co-signer. The passkey is verified by the canonical `SafeWebAuthnSignerFactory`, the same P-256 code and encoding as the Safe path. ZeroDev's WebAuthnValidator was not used: it needs the RIP-7212 precompile or Daimo's verifier, neither of which exists on L1 or on a plain anvil. |
| `FrostValidator` | Root validator for the FROST option: `SchnorrVerifier.verify` from the root contracts, over the same message as `FrostSigner`. |
| `KernelAvatarAdapter` | Lets the Safe's Zodiac Delay 1.1.1 drive the account, so recovery (queue, cooldown, veto, expiry) is the same audited module (`src/kernel-recovery.ts`). |
| `UserOpChallenge` | The signed validity window both validators use: Safe4337Module's 12-byte header, signed together with the operation hash. |

Kernel has no owner threshold, so on Kernel the 2-of-2 rule is our Solidity rather than Safe's.
[docs/wallet-custody.md §10](../../docs/wallet-custody.md) goes through every custody requirement and
lists what Kernel cannot match. The Safe stays the recommended account.

`fixtures/` holds the vendored bytecode, with the mainnet creation transaction, CREATE2 proof and hashes
of each contract. `scripts/vendor-fixtures.ts` regenerates it, and `scripts/frost-vectors.ts` generates
the FROST vectors for `contracts/test/FrostValidator.t.sol`.

## Not done

- **An audit of the Kernel validators and adapter** (`contracts/src`), the one place where this package
  puts its own Solidity in a spending path. Until then the Kernel account is an option, not the default.
- ~~**Bundler admission under ERC-7562.**~~ Done, 15-17 September 2026: `examples/erc7562-live.ts` submits every
  scenario through Rundler in safe mode on geth, which enforces the tracing rules. Safe is admitted throughout; a Kernel
  account is admitted once it exists, which the co-signer's sponsorship sees to at enrolment. Creation *inside* the first
  operation, through ZeroDev's meta factory, stays refused (`banned opcode: CREATE2`) whatever its stake, and is
  documented rather than worked around. No hosted bundler has been tried.
- **An external audit of `packages/mpc` and `SchnorrVerifier.sol`.** Until then the FROST
  owner is an option, not the default. The on-chain verifier exists and the DKG replaced the
  dealer; what is missing is review.
- **Which fallback to enable in production.** `RecoverableSplitSeedSource` is written and
  tested; whether to turn the fallback on at all, or to require a PRF-capable authenticator,
  is still a product decision. The harness above is how to decide.
- **More than one passkey.** Losing the only passkey without platform sync still loses the
  PRF seed and the Safe's quorum; a second authenticator as an additional owner and Delay
  module is the natural extension, not built.
- **Hardware in CI.** `PasskeyAuthenticator` remains software for the test suite. The
  on-chain half is real and the browser harness covers real devices, but nothing exercises
  hardware automatically.
- **Hosted bundler.** Alto runs locally here. Production wants a hosted endpoint, and the
  paymaster staked on that chain.
