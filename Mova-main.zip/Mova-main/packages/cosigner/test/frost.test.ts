import { describe, expect, it } from 'vitest';
import { getAddress, hexToBytes, pad, toHex, type Address, type Hex } from 'viem';
import { aggregate, commit, sign, verify, type Commitment, type KeyShare } from '@mova/mpc';
import { frostInstallData, kernelInitData, kernelRecoverySetupCalls, predictKernelAddress, recoverySetupCalls } from '@mova/smart-account';
import { type FrostSignRequest } from '../src/index.js';
import {
  CHAIN_ID, FROST_VALIDATOR, ADAPTER, deposit, dkg, enrolmentProof, expectRefusal, fakeSignerAddress, kernelOp, safeOp, sig, world,
  type World,
} from './harness.js';

const k = (a: string) => a.toLowerCase();
const FROST_SIGNER = getAddress(`0x${'f5'.repeat(20)}`);

async function frostSafe() {
  const [device, server] = dkg('cosigner frost safe');
  const w = world({ frostShares: [server] });
  const account = getAddress(`0x${'5f'.repeat(20)}`);
  const g = device.groupPublicKey.toAffine();
  w.chain.code.add(k(account));
  w.chain.code.add(k(FROST_SIGNER));
  w.chain.safes.set(k(account), { owners: [FROST_SIGNER], threshold: 1n, modules: [] });
  w.chain.frostSigners.set(k(FROST_SIGNER), { x: g.x, y: g.y });
  const passkeySigner = w.chain.deploySigner(w.pk);
  const delay = w.chain.installDelay(account, passkeySigner);
  const { enrolment } = await w.service.enrol({ chainId: CHAIN_ID, account, type: 'safe', ...enrolmentProof(w, account) }, w.caller);
  return { w, device, server, account, delay, enrolment };
}

const wire = (c: Commitment) => c;

async function session(w: World, device: KeyShare, account: Address, digest: Hex, req: Omit<FrostSignRequest, 'sessionId' | 'commitments' | 'passkeySignature'>, o: { passkeySignature?: Hex } = {}) {
  const server = await w.service.frostCommit({ chainId: CHAIN_ID, account }, w.caller);
  const { nonces, commitment } = commit(device);
  const serverCommitment: Commitment = {
    id: server.commitment.id,
    hiding: (await import('@mova/mpc')).Point.fromBytes(hexToBytes(server.commitment.hiding)),
    binding: (await import('@mova/mpc')).Point.fromBytes(hexToBytes(server.commitment.binding)),
  };
  const commitments = [commitment, serverCommitment].map(wire);
  const full: FrostSignRequest = { ...req, sessionId: server.sessionId, commitments, passkeySignature: o.passkeySignature ?? sig(w, digest) };
  return { full, nonces, commitments, sessionId: server.sessionId };
}

describe('FROST: the server participant, passkey first, nonces single-use', () => {
  it('enrols a FrostSigner Safe by its group key and its Delay\'s passkey, and refuses ECDSA co-signing for it', async () => {
    const { w, account, enrolment } = await frostSafe();
    expect(enrolment).toMatchObject({ kind: 'safe-frost', frostSigner: FROST_SIGNER, passkeySigner: fakeSignerAddress(w.pk) });
    const op = safeOp(w, account, [deposit(1n)]);
    await expectRefusal(w.service.cosign({ chainId: CHAIN_ID, account, kind: 'safe-operation', ...op, passkeySignature: sig(w, op.digest) }, w.caller), 'wrong_account_kind');
  });

  it('refuses to enrol a group it holds no share of', async () => {
    const [device] = dkg('someone else\'s group');
    const { w } = await frostSafe();
    const other = getAddress(`0x${'6f'.repeat(20)}`);
    const signer = getAddress(`0x${'f6'.repeat(20)}`);
    const g = device.groupPublicKey.toAffine();
    w.chain.code.add(k(other));
    w.chain.code.add(k(signer));
    w.chain.safes.set(k(other), { owners: [signer], threshold: 1n, modules: [] });
    w.chain.frostSigners.set(k(signer), { x: g.x, y: g.y });
    await expectRefusal(w.service.enrol({ chainId: CHAIN_ID, account: other, type: 'safe', ...enrolmentProof(w, other) }, w.caller), 'no_share');
  });

  it('signs its share only after the passkey signed the same digest; the aggregate verifies', async () => {
    const { w, device, account } = await frostSafe();
    const op = safeOp(w, account, [deposit(1n)]);
    const s = await session(w, device, account, op.digest, { chainId: CHAIN_ID, account, kind: 'safe-operation', ...op, route: 'cosign' });
    const r = await w.service.frostSign(s.full, w.caller);
    const msg = hexToBytes(op.digest);
    const own = sign(device, s.nonces, s.commitments, msg);
    const signature = aggregate(s.commitments, [own, { id: r.share.id, z: BigInt(r.share.z) }], msg, device.groupPublicKey);
    expect(verify(signature, msg, device.groupPublicKey)).toBe(true);
    // The session is gone: its nonces never sign again.
    await expectRefusal(w.service.frostSign(s.full, w.caller), 'session_unknown');
  });

  it('burns the session on a refusal: no passkey, the passkey over another digest, or a policy refusal', async () => {
    const { w, device, account } = await frostSafe();
    const op = safeOp(w, account, [deposit(1n)]);
    const noPasskey = await session(w, device, account, op.digest, { chainId: CHAIN_ID, account, kind: 'safe-operation', ...op, route: 'cosign' }, { passkeySignature: '0x' });
    await expectRefusal(w.service.frostSign(noPasskey.full, w.caller), 'passkey_required');
    await expectRefusal(w.service.frostSign({ ...noPasskey.full, passkeySignature: sig(w, op.digest) }, w.caller), 'session_unknown');
    const other = safeOp(w, account, [deposit(2n)]);
    const wrong = await session(w, device, account, op.digest, { chainId: CHAIN_ID, account, kind: 'safe-operation', ...op, route: 'cosign' }, { passkeySignature: sig(w, other.digest) });
    await expectRefusal(w.service.frostSign(wrong.full, w.caller), 'bad_passkey_signature');
    const stranger = safeOp(w, account, [{ to: getAddress(`0x${'99'.repeat(20)}`), data: '0x' }]);
    const refused = await session(w, device, account, stranger.digest, { chainId: CHAIN_ID, account, kind: 'safe-operation', ...stranger, route: 'cosign' });
    await expectRefusal(w.service.frostSign(refused.full, w.caller), 'target_not_allowed');
    await expectRefusal(w.service.frostSign(refused.full, w.caller), 'session_unknown');
  });

  it('refuses a commitment list that swaps the server\'s own commitment, and an expired session', async () => {
    const { w, device, server, account } = await frostSafe();
    const op = safeOp(w, account, [deposit(1n)]);
    const s = await session(w, device, account, op.digest, { chainId: CHAIN_ID, account, kind: 'safe-operation', ...op, route: 'cosign' });
    const forged = commit(server).commitment;
    await expectRefusal(w.service.frostSign({ ...s.full, commitments: [s.commitments[0]!, forged] }, w.caller), 'frost_invalid');
    const late = await session(w, device, account, op.digest, { chainId: CHAIN_ID, account, kind: 'safe-operation', ...op, route: 'cosign' });
    w.clock.ms += 121_000;
    await expectRefusal(w.service.frostSign(late.full, w.caller), 'session_unknown');
  });

  it('a counterfactual Kernel FrostValidator account must install recovery for its passkey in its first operation', async () => {
    const [device, server] = dkg('cosigner frost kernel');
    const w = world({ frostShares: [server] });
    const initData = kernelInitData({ rootValidator: FROST_VALIDATOR, validatorData: frostInstallData(device.groupPublicKey) });
    const salt = pad(toHex(3n), { size: 32 });
    const account = predictKernelAddress({ initData, salt });
    await expectRefusal(w.service.enrol({ chainId: CHAIN_ID, account, type: 'kernel', kernel: { initData, salt }, ...enrolmentProof(w, account) }, w.caller), 'no_passkey_on_chain');
    const { enrolment } = await w.service.enrol({ chainId: CHAIN_ID, account, type: 'kernel', passkey: w.pk, kernel: { initData, salt }, ...enrolmentProof(w, account) }, w.caller);
    expect(enrolment.kind).toBe('kernel-frost');
    const bare = kernelOp(w, account, [deposit(1n)], { initCode: '0x1234', validator: FROST_VALIDATOR });
    const s1 = await session(w, device, account, bare.digest, { chainId: CHAIN_ID, account, kind: 'kernel-operation', ...bare, route: 'cosign' });
    await expectRefusal(w.service.frostSign(s1.full, w.caller), 'recovery_setup_required');
    const setup = kernelRecoverySetupCalls({ account, passkey: w.pk, passkeySigner: fakeSignerAddress(w.pk), adapter: ADAPTER }).calls;
    const first = kernelOp(w, account, [...setup, deposit(1n)], { initCode: '0x1234', validator: FROST_VALIDATOR });
    const s2 = await session(w, device, account, first.digest, { chainId: CHAIN_ID, account, kind: 'kernel-operation', ...first, route: 'cosign' });
    const r = await w.service.frostSign(s2.full, w.caller);
    expect(r.share.id).toBe(server.id);
    void recoverySetupCalls;
  });

  it('a Kernel FrostValidator account the sponsorship module deployed before its first operation still installs recovery first, and can', async () => {
    const [device, server] = dkg('cosigner frost kernel deployed');
    const w = world({ frostShares: [server] });
    const initData = kernelInitData({ rootValidator: FROST_VALIDATOR, validatorData: frostInstallData(device.groupPublicKey) });
    const salt = pad(toHex(4n), { size: 32 });
    const account = predictKernelAddress({ initData, salt });
    await w.service.enrol({ chainId: CHAIN_ID, account, type: 'kernel', passkey: w.pk, kernel: { initData, salt }, ...enrolmentProof(w, account) }, w.caller);
    // What the sponsorship module's factory call leaves: the account, its FrostValidator over the group key - and no
    // recovery Delay yet, which only the account's own first operation installs.
    const g = device.groupPublicKey.toAffine();
    w.chain.code.add(k(account));
    w.chain.kernelRoots.set(k(account), FROST_VALIDATOR);
    w.chain.frostKeys.set(`${k(FROST_VALIDATOR)}:${k(account)}`, { x: g.x, y: g.y });

    const bare = kernelOp(w, account, [deposit(1n)], { validator: FROST_VALIDATOR });
    const s1 = await session(w, device, account, bare.digest, { chainId: CHAIN_ID, account, kind: 'kernel-operation', ...bare, route: 'cosign' });
    await expectRefusal(w.service.frostSign(s1.full, w.caller), 'recovery_setup_required');
    const passkeySigner = fakeSignerAddress(w.pk);
    const setup = kernelRecoverySetupCalls({ account, passkey: w.pk, passkeySigner, adapter: ADAPTER }).calls;
    const first = kernelOp(w, account, [...setup, deposit(1n)], { validator: FROST_VALIDATOR });
    const s2 = await session(w, device, account, first.digest, { chainId: CHAIN_ID, account, kind: 'kernel-operation', ...first, route: 'cosign' });
    expect((await w.service.frostSign(s2.full, w.caller)).share.id).toBe(server.id);

    // Enrolling again before recovery is installed is the same binding, not a refusal.
    const again = await w.service.enrol({ chainId: CHAIN_ID, account, type: 'kernel', passkey: w.pk, ...enrolmentProof(w, account) }, w.caller);
    expect(again.enrolment).toMatchObject({ kind: 'kernel-frost', passkeySigner });

    // Installed, as those setup calls do it - the passkey signer created, the Delay with it as its module: the passkey is
    // read from the Delay now, and later operations need no setup.
    w.chain.deploySigner(w.pk);
    w.chain.installDelay(account, passkeySigner);
    const later = kernelOp(w, account, [deposit(1n)], { validator: FROST_VALIDATOR });
    const s3 = await session(w, device, account, later.digest, { chainId: CHAIN_ID, account, kind: 'kernel-operation', ...later, route: 'cosign' });
    expect((await w.service.frostSign(s3.full, w.caller)).share.id).toBe(server.id);
  });

  it('a deployed FROST account whose Delay address holds something that is not its recovery Delay stays refused', async () => {
    const [device, server] = dkg('cosigner frost kernel odd delay');
    const w = world({ frostShares: [server] });
    const initData = kernelInitData({ rootValidator: FROST_VALIDATOR, validatorData: frostInstallData(device.groupPublicKey) });
    const salt = pad(toHex(5n), { size: 32 });
    const account = predictKernelAddress({ initData, salt });
    await w.service.enrol({ chainId: CHAIN_ID, account, type: 'kernel', passkey: w.pk, kernel: { initData, salt }, ...enrolmentProof(w, account) }, w.caller);
    const g = device.groupPublicKey.toAffine();
    w.chain.code.add(k(account));
    w.chain.kernelRoots.set(k(account), FROST_VALIDATOR);
    w.chain.frostKeys.set(`${k(FROST_VALIDATOR)}:${k(account)}`, { x: g.x, y: g.y });
    // Code at the Delay's address that does not read as this account's Delay: the claimed key is no longer taken.
    const delay = w.chain.installDelay(account, fakeSignerAddress(w.pk));
    w.chain.delays.delete(k(delay));
    const setup = kernelRecoverySetupCalls({ account, passkey: w.pk, passkeySigner: fakeSignerAddress(w.pk), adapter: ADAPTER }).calls;
    const op = kernelOp(w, account, [...setup, deposit(1n)], { validator: FROST_VALIDATOR });
    const s = await session(w, device, account, op.digest, { chainId: CHAIN_ID, account, kind: 'kernel-operation', ...op, route: 'cosign' });
    await expectRefusal(w.service.frostSign(s.full, w.caller), 'enrolment_stale');
    await expectRefusal(w.service.enrol({ chainId: CHAIN_ID, account, type: 'kernel', passkey: w.pk, ...enrolmentProof(w, account) }, w.caller), 'no_passkey_on_chain');
  });
});
