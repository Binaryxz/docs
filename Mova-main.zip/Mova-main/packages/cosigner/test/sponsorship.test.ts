import { afterEach, describe, expect, it } from 'vitest';
import { getAddress, keccak256, pad, parseGwei, recoverTransactionAddress, toHex, type Address, type Hex } from 'viem';
import { MemoryJournal } from '@mova/lp-node/src/journal.js';
import { kernelInitData, passkeyCoSignerInstallData, predictKernelAddress } from '@mova/smart-account';
import {
  KeyCustodyError, SponsorTransactionFailed, SponsorshipModule, cosignerConfigFromEnv, enrolmentChallenge, fileOperatorKey, localKey, operatorAccount,
  serveCoSigner, type AuditRecord, type EnrolledKernelDeployment, type GateReading, type PasskeyConfig, type SponsorChain, type SponsorRecord,
} from '../src/index.js';
import {
  CHAIN_ID, OTHER, OTHER_KEY, PASSKEY_VALIDATOR, SERVER, fakeSafeAddress, fakeSignerAddress, kernelAccount, safeAccount, sig, world, type World,
} from './harness.js';

/** The initData `kernelAccount` enrols with, or the same shape naming another co-signer (a deployment of another account). */
const kernelInitDataFor = (w: World, coSigner: Address = SERVER) =>
  kernelInitData({ rootValidator: PASSKEY_VALIDATOR, validatorData: passkeyCoSignerInstallData({ passkey: w.pk, coSigner }) });

const GATE = getAddress(`0x${'9a'.repeat(20)}`);
const PAYMASTER = getAddress(`0x${'77'.repeat(20)}`);
const OPERATOR = localKey(OTHER_KEY).address;
const k = (a: string) => a.toLowerCase();
const hash = (label: string): Hex => keccak256(toHex(label));
const DAY = 86_400n;

/** The gate, the paymaster and the signer factory, as the module sees them. */
class FakeSponsorChain implements SponsorChain {
  readonly gate = GATE;
  readonly operator = OPERATOR;
  readonly sponsoredSet = new Set<string>();
  readonly code = new Set<string>();
  readonly sent: string[] = [];
  remaining = 10n;
  maxPerWindow = 10n;
  isOperator = true;
  paymasterOwner: Address = GATE;
  bounded = true;
  balance = 10n ** 18n;
  failNext?: string;
  private held?: Promise<void>;

  /** Transactions wait until the returned release is called: a sponsorship the test can observe pending. */
  hold(): () => void {
    let release!: () => void;
    this.held = new Promise((r) => { release = r; });
    return () => { this.held = undefined; release(); };
  }

  async readGate(): Promise<GateReading> {
    return { isOperator: this.isOperator, remaining: this.remaining, maxPerWindow: this.maxPerWindow, paymaster: PAYMASTER, paymasterOwner: this.paymasterOwner, bounded: this.bounded };
  }
  async isSponsored(account: Address) { return this.sponsoredSet.has(k(account)); }
  async hasCode(address: Address) { return this.code.has(k(address)); }
  async operatorBalance() { return this.balance; }
  async createSigner(pk: PasskeyConfig) {
    await this.held;
    const signer = fakeSignerAddress(pk);
    this.sent.push(`createSigner:${signer}`);
    this.code.add(k(signer));
    return hash(`signer ${signer}`);
  }
  async createKernelAccount(d: EnrolledKernelDeployment) {
    await this.held;
    const account = predictKernelAddress({ initData: d.initData, salt: d.salt });
    this.sent.push(`deploy:${account}`);
    this.code.add(k(account));
    return hash(`deploy ${account}`);
  }
  async sponsor(account: Address) {
    await this.held;
    if (this.failNext) {
      const reason = this.failNext;
      this.failNext = undefined;
      throw new SponsorTransactionFailed(hash('reverted'), reason);
    }
    this.sent.push(`sponsor:${account}`);
    this.sponsoredSet.add(k(account));
    this.remaining -= 1n;
    return hash(`sponsor ${account}`);
  }
}

interface Sponsored { w: World; sc: FakeSponsorChain; module: SponsorshipModule }

function sponsoredWorld(o: {
  sc?: FakeSponsorChain; base?: World; dailyCap?: number; clientRateLimit?: { burst: number; perMinute: number };
} = {}): Sponsored {
  const sc = o.sc ?? new FakeSponsorChain();
  let module!: SponsorshipModule;
  const w = world({
    ...(o.base ? { journal: o.base.journal, chain: o.base.chain, clock: o.base.clock, passkey: o.base.passkey } : {}),
    extra: ({ audit, clock, metrics }) => {
      module = new SponsorshipModule({
        chainId: CHAIN_ID, chain: sc, audit, dailyCap: o.dailyCap ?? 5, now: () => clock.now, nowMs: () => clock.ms, metrics,
        rateLimit: { burst: 50, perMinute: 60 }, clientRateLimit: o.clientRateLimit ?? { burst: 50, perMinute: 60 },
      });
      return { sponsorship: module };
    },
  });
  return { w, sc, module };
}

const sponsorRecords = (w: World) => w.journal.load().filter((r): r is SponsorRecord => r.t === 'sponsor');

/** A counterfactual 2-of-2 Safe enrolled by a given client, returning the enrolment's answer. */
async function enrolSafe(w: World, saltNonce: bigint, client = 'test') {
  const passkeySigner = fakeSignerAddress(w.pk);
  const owners = [passkeySigner, SERVER];
  const account = fakeSafeAddress(owners, 2, saltNonce);
  const issuedAt = Number(w.clock.now);
  const r = await w.service.enrol({
    chainId: CHAIN_ID, account, type: 'safe', passkey: w.pk, safe: { owners, threshold: 2, saltNonce }, issuedAt,
    passkeySignature: sig(w, enrolmentChallenge(CHAIN_ID, account, SERVER, issuedAt)),
  }, { client });
  return { account, passkeySigner, ...r };
}

describe('sponsorship at enrolment', () => {
  it('creates a counterfactual Safe\'s passkey signer, then sponsors it through the gate, from the operator key, on record', async () => {
    const { w, sc, module } = sponsoredWorld();
    const a = await enrolSafe(w, 1n);
    expect(a.sponsorship).toMatchObject({ status: 'pending', account: a.account });
    await module.idle();
    expect(sc.sent).toEqual([`createSigner:${a.passkeySigner}`, `sponsor:${a.account}`]);
    const view = module.view(CHAIN_ID, a.account);
    expect(view).toMatchObject({ status: 'sponsored', signerTx: hash(`signer ${a.passkeySigner}`), sponsorTx: hash(`sponsor ${a.account}`) });
    expect(sponsorRecords(w)).toEqual([expect.objectContaining({
      outcome: 'sponsored', account: a.account, kind: 'safe-passkey', client: 'test', operator: OPERATOR, signerTx: view.signerTx, sponsorTx: view.sponsorTx,
    })]);
    expect(w.metrics.get('mova_cosigner_sponsorships_total', { result: 'sponsored' })).toBe(1);
  });

  it('creates a counterfactual Kernel account before sponsoring it, and never a signer; a second Safe on the same passkey reuses its signer', async () => {
    const { w, sc, module } = sponsoredWorld();
    const kernel = await kernelAccount(w, { salt: 7n });
    const safe = await enrolSafe(w, 2n);
    const again = await enrolSafe(w, 3n);
    await module.idle();
    expect(sc.sent).toEqual([
      `deploy:${kernel.account}`, `sponsor:${kernel.account}`,
      `createSigner:${safe.passkeySigner}`, `sponsor:${safe.account}`, `sponsor:${again.account}`,
    ]);
    const view = module.view(CHAIN_ID, kernel.account);
    expect(view).toMatchObject({ status: 'sponsored', accountTx: hash(`deploy ${kernel.account}`), sponsorTx: hash(`sponsor ${kernel.account}`) });
    expect(view.signerTx).toBeUndefined();
    expect(sponsorRecords(w)[0]).toMatchObject({
      outcome: 'sponsored', account: kernel.account, kind: 'kernel-passkey', operator: OPERATOR, accountTx: view.accountTx, sponsorTx: view.sponsorTx,
    });
  });

  it('deploys the Kernel account from the enrolment\'s own initData and salt, so no operation carries initCode', async () => {
    const { w, sc, module } = sponsoredWorld();
    const kernel = await kernelAccount(w, { salt: 11n });
    await module.idle();
    // What the module sent creates exactly the enrolled account, from what the enrolment checked - not from any request.
    expect(w.journal.load().flatMap((r) => (r.t === 'enrol' ? [r.enrolment.kernelDeployment] : []))).toEqual([{ initData: kernel.initData, salt: kernel.salt }]);
    expect(predictKernelAddress({ initData: kernel.initData, salt: kernel.salt })).toBe(kernel.account);
    expect(sc.code.has(k(kernel.account))).toBe(true);
    expect(sc.sent).toEqual([`deploy:${kernel.account}`, `sponsor:${kernel.account}`]);
  });

  it('a second enrolment of the same Kernel account deploys nothing and sponsors nothing', async () => {
    const { w, sc, module } = sponsoredWorld();
    const kernel = await kernelAccount(w, { salt: 13n });
    await module.idle();
    sc.sent.length = 0;
    // The chain the service reads now shows the account deployed, as the module left it.
    const again = await kernelAccount(w, { salt: 13n, deployed: true });
    await module.idle();
    expect(again.account).toBe(kernel.account);
    expect(again.enrolment.kernelDeployment).toEqual({ initData: kernel.initData, salt: kernel.salt });
    expect(sc.sent).toEqual([]);
    expect(module.view(CHAIN_ID, kernel.account).status).toBe('sponsored');
    expect(sponsorRecords(w).map((r) => r.outcome)).toEqual(['sponsored']);
  });

  it('deploys a Kernel account that was sponsored but never created, without sponsoring it again', async () => {
    const { w, sc, module } = sponsoredWorld();
    const initData = kernelInitDataFor(w);
    const salt = pad(toHex(17n), { size: 32 });
    const account = predictKernelAddress({ initData, salt });
    sc.sponsoredSet.add(k(account)); // the governor allowlisted it; nobody deployed it
    await kernelAccount(w, { salt: 17n });
    await module.idle();
    expect(sc.sent).toEqual([`deploy:${account}`]);
    expect(sponsorRecords(w).at(-1)).toMatchObject({ outcome: 'already', accountTx: hash(`deploy ${account}`) });
  });

  it('refuses to send a recorded deployment that does not create the enrolled account', async () => {
    const { w, sc, module } = sponsoredWorld();
    const kernel = await kernelAccount(w, { salt: 19n });
    await module.idle();
    sc.sent.length = 0;
    // A tampered audit line: the same account, another account's initData. Nothing may be sent for it.
    const tampered = { ...kernel.enrolment, kernelDeployment: { initData: kernelInitDataFor(w, OTHER), salt: kernel.salt } };
    const view = await module.request(tampered, { client: 'test' });
    await module.idle();
    expect(view).toMatchObject({ status: 'refused', code: 'deployment_mismatch', retryable: false });
    expect(sc.sent).toEqual([]);
    expect(sponsorRecords(w).at(-1)).toMatchObject({ outcome: 'refused', code: 'deployment_mismatch' });
  });

  it('is idempotent: an enrolment repeated while pending or after sends nothing new, and records nothing new', async () => {
    const { w, sc, module } = sponsoredWorld();
    const release = sc.hold();
    const first = await enrolSafe(w, 1n);
    const whilePending = await enrolSafe(w, 1n);
    expect(whilePending).toMatchObject({ created: false, sponsorship: { status: 'pending' } });
    release();
    await module.idle();
    const after = await enrolSafe(w, 1n);
    const afterAgain = await enrolSafe(w, 1n);
    await module.idle();
    expect(after.sponsorship?.status).toBe('sponsored');
    expect(afterAgain.sponsorship?.status).toBe('sponsored');
    expect(sc.sent.filter((s) => s.startsWith('sponsor:'))).toEqual([`sponsor:${first.account}`]);
    expect(sponsorRecords(w).map((r) => r.outcome)).toEqual(['sponsored']);
  });

  it('sends nothing for an account already sponsored, but still creates a Safe\'s missing signer', async () => {
    const { w, sc, module } = sponsoredWorld();
    const kernel = await kernelAccount(w, { salt: 9n });
    await module.idle();
    sc.sent.length = 0;
    const byGovernor = fakeSafeAddress([fakeSignerAddress(w.pk), SERVER], 2, 4n);
    sc.sponsoredSet.add(k(byGovernor));
    const safe = await enrolSafe(w, 4n);
    await module.idle();
    expect(sc.sent).toEqual([`createSigner:${safe.passkeySigner}`]);
    expect(module.view(CHAIN_ID, safe.account).status).toBe('sponsored');
    expect(sponsorRecords(w).at(-1)).toMatchObject({ outcome: 'already', signerTx: hash(`signer ${safe.passkeySigner}`) });
    void kernel;
  });

  it('never re-sponsors an account whose sponsorship was removed on-chain, even after a restart', async () => {
    const { w, sc, module } = sponsoredWorld();
    const a = await enrolSafe(w, 1n);
    await module.idle();
    sc.sponsoredSet.delete(k(a.account)); // the governor, or an operator, removed it
    const again = await enrolSafe(w, 1n);
    expect(again.sponsorship).toMatchObject({ status: 'refused', code: 'sponsorship_revoked', retryable: false });
    const restarted = sponsoredWorld({ sc, base: w });
    const afterRestart = await enrolSafe(restarted.w, 1n);
    expect(afterRestart.sponsorship).toMatchObject({ status: 'refused', code: 'sponsorship_revoked' });
    await restarted.module.idle();
    expect(sc.sent.filter((s) => s.startsWith('sponsor:'))).toHaveLength(1);
  });

  it('keeps its own daily cap below the gate\'s budget, counting in-flight sponsorships; a restart remembers; a day later it refills', async () => {
    const { w, sc, module } = sponsoredWorld({ dailyCap: 2 });
    await enrolSafe(w, 1n);
    await enrolSafe(w, 2n);
    const third = await enrolSafe(w, 3n);
    expect(third.sponsorship).toMatchObject({ status: 'refused', code: 'daily_cap', retryable: true });
    await module.idle();
    const restarted = sponsoredWorld({ sc, base: w, dailyCap: 2 });
    expect((await enrolSafe(restarted.w, 3n)).sponsorship).toMatchObject({ code: 'daily_cap' });
    w.clock.now += DAY + 1n;
    w.clock.ms += Number(DAY + 1n) * 1000;
    expect((await enrolSafe(restarted.w, 3n)).sponsorship?.status).toBe('pending');
    await restarted.module.idle();
    expect(sc.sent.filter((s) => s.startsWith('sponsor:'))).toHaveLength(3);
  });

  it('rate-limits per API client without auditing the flood, and other clients are unaffected', async () => {
    const { w, module } = sponsoredWorld({ clientRateLimit: { burst: 1, perMinute: 1 } });
    await enrolSafe(w, 1n, 'app');
    const flooded = await enrolSafe(w, 2n, 'app');
    expect(flooded.sponsorship).toMatchObject({ status: 'refused', code: 'rate_limited', retryable: true });
    expect((await enrolSafe(w, 3n, 'other-app')).sponsorship?.status).toBe('pending');
    await module.idle();
    expect(sponsorRecords(w).map((r) => r.code ?? r.outcome)).toEqual(['sponsored', 'sponsored']);
  });

  it('refuses with a code, sending nothing, when the gate cannot sponsor: revoked operator, ungated or unbounded paymaster, spent window, no gas', async () => {
    const cases: [string, (sc: FakeSponsorChain) => void][] = [
      ['operator_revoked', (sc) => { sc.isOperator = false; }],
      ['paymaster_not_gated', (sc) => { sc.paymasterOwner = PAYMASTER; }],
      ['paymaster_unbounded', (sc) => { sc.bounded = false; }],
      ['gate_budget_exhausted', (sc) => { sc.remaining = 0n; }],
      ['operator_unfunded', (sc) => { sc.balance = 10n ** 15n; }],
    ];
    for (const [code, set] of cases) {
      const { w, sc, module } = sponsoredWorld();
      set(sc);
      const a = await enrolSafe(w, 5n);
      await module.idle();
      expect(a.sponsorship, code).toMatchObject({ status: 'refused', code, retryable: true });
      expect(sc.sent, code).toEqual([]);
      expect(sponsorRecords(w), code).toEqual([expect.objectContaining({ outcome: 'refused', code })]);
    }
  });

  it('records a failed transaction with its reason; enrolling again retries it', async () => {
    const { w, sc, module } = sponsoredWorld();
    sc.failNext = 'SponsorBudgetExhausted(1, 0)';
    const a = await enrolSafe(w, 1n);
    await module.idle();
    expect(module.view(CHAIN_ID, a.account)).toMatchObject({ status: 'failed', code: 'transaction_failed', retryable: true });
    expect(sponsorRecords(w).at(-1)).toMatchObject({ outcome: 'failed', code: 'transaction_failed', reason: 'SponsorBudgetExhausted(1, 0)', signerTx: hash(`signer ${a.passkeySigner}`) });
    expect((await enrolSafe(w, 1n)).sponsorship?.status).toBe('pending');
    await module.idle();
    expect(module.view(CHAIN_ID, a.account).status).toBe('sponsored');
    expect(sc.sent).toEqual([`createSigner:${a.passkeySigner}`, `sponsor:${a.account}`]);
  });

  it('asks for no user identifier: a record holds the account, its kind, the API client and the transactions, nothing else', async () => {
    const { w, module } = sponsoredWorld();
    await enrolSafe(w, 1n);
    await module.idle();
    const allowed = new Set(['t', 'at', 'client', 'chainId', 'account', 'kind', 'outcome', 'code', 'operator', 'signerTx', 'sponsorTx', 'reason']);
    for (const r of sponsorRecords(w)) expect(Object.keys(r).filter((key) => !allowed.has(key))).toEqual([]);
    const lines = w.journal.lines.filter((l) => l.includes('"sponsor"')).join('\n');
    expect(lines).not.toContain(w.pk.x.toString());
  });

  it('serves the sponsorship over HTTP with the enrolment, and GET /v1/sponsorship; without the module the route says so', async () => {
    const { w, module } = sponsoredWorld();
    const s = serveCoSigner(w.service, { mode: 'api', apiKeys: [{ name: 'app', token: 'app-client-token-0123456789abcdefghij' }] });
    const port = await s.listen(0);
    closers.push(s.close);
    const call = (path: string, body?: unknown) => fetch(`http://127.0.0.1:${port}${path}`, {
      method: body ? 'POST' : 'GET', body: body ? JSON.stringify(body, (_k, v) => (typeof v === 'bigint' ? v.toString() : v)) : undefined,
      headers: { authorization: 'Bearer app-client-token-0123456789abcdefghij', ...(body ? { 'content-type': 'application/json' } : {}) },
    }).then(async (r) => ({ status: r.status, json: await r.json() as Record<string, unknown> }));
    const owners = [fakeSignerAddress(w.pk), SERVER];
    const account = fakeSafeAddress(owners, 2, 11n);
    const issuedAt = Number(w.clock.now);
    const enrolled = await call('/v1/enrol', {
      chainId: CHAIN_ID, account, type: 'safe', issuedAt, passkey: { x: w.pk.x, y: w.pk.y }, safe: { owners, threshold: 2, saltNonce: '11' },
      passkeySignature: sig(w, enrolmentChallenge(CHAIN_ID, account, SERVER, issuedAt)),
    });
    expect(enrolled.status).toBe(200);
    expect(enrolled.json.sponsorship).toMatchObject({ status: 'pending' });
    await module.idle();
    expect((await call(`/v1/sponsorship?chainId=${CHAIN_ID}&account=${account}`)).json).toMatchObject({ status: 'sponsored', account });
    expect((await call(`/v1/sponsorship?chainId=${CHAIN_ID}&account=${OPERATOR}`)).json).toMatchObject({ error: 'not_enrolled' });
    expect((await call('/v1/info')).json.sponsorship).toEqual({ gate: GATE, operator: OPERATOR, dailyCap: 5 });

    const plain = world();
    const p = serveCoSigner(plain.service, { mode: 'api', apiKeys: [{ name: 'app', token: 'app-client-token-0123456789abcdefghij' }] });
    const plainPort = await p.listen(0);
    closers.push(p.close);
    const r = await fetch(`http://127.0.0.1:${plainPort}/v1/sponsorship?chainId=${CHAIN_ID}&account=${account}`, { headers: { authorization: 'Bearer app-client-token-0123456789abcdefghij' } });
    expect(r.status).toBe(404);
    expect(await r.json()).toMatchObject({ error: 'sponsorship_disabled' });
  });
});

const closers: (() => Promise<void>)[] = [];
afterEach(async () => { while (closers.length) await closers.pop()!(); });

describe('the operator key', () => {
  it('a file key refuses production mode unless explicitly allowed, and a file others can read', () => {
    const readFile = () => OTHER_KEY;
    expect(() => fileOperatorKey({ path: '/k', production: true, readFile, fileMode: () => 0o600 })).toThrow(/COSIGNER_ALLOW_SPONSOR_FILE_KEY_IN_PRODUCTION/);
    expect(() => fileOperatorKey({ path: '/k', production: false, readFile, fileMode: () => 0o640 })).toThrow(/group or others/);
    expect(() => fileOperatorKey({ path: '/k', production: false, readFile: () => 'nope', fileMode: () => 0o600 })).toThrow(KeyCustodyError);
    expect(fileOperatorKey({ path: '/k', production: true, allowInProduction: true, readFile, fileMode: () => 0o600 }).address).toBe(OPERATOR);
  });

  it('signs transactions by digest, recoverable to the key\'s address', async () => {
    const account = operatorAccount(localKey(OTHER_KEY));
    const signed = await account.signTransaction!({
      chainId: CHAIN_ID, type: 'eip1559', to: GATE, data: '0x12345678', nonce: 3, gas: 100_000n,
      maxFeePerGas: parseGwei('30'), maxPriorityFeePerGas: parseGwei('1'), value: 0n,
    });
    expect(await recoverTransactionAddress({ serializedTransaction: signed as never })).toBe(OPERATOR);
  });
});

describe('sponsorship and alerts configuration', () => {
  const files: Record<string, string> = {
    '/policy.json': JSON.stringify({ chainId: CHAIN_ID, targets: [{ address: GATE, label: 'Vault' }] }),
    '/keys': 'app:app-client-token-0123456789abcdefghij\n',
  };
  const base = {
    RPC_URL: 'http://127.0.0.1:8545', CHAIN_ID: String(CHAIN_ID), COSIGNER_MODE: 'development', COSIGNER_KEY_FILE: '/cosigner_key',
    COSIGNER_POLICY_FILE: '/policy.json', COSIGNER_AUDIT_LOG: '/audit.jsonl', COSIGNER_API_KEYS_FILE: '/keys',
  };
  const read = (env: Record<string, string>) => cosignerConfigFromEnv(env, (p) => { if (!(p in files)) throw new Error('no file'); return files[p]!; });

  it('turns sponsorship on with the gate, with defaults, and refuses a sponsor key file in production unless explicit', () => {
    const cfg = read({ ...base, COSIGNER_SPONSOR_GATE: GATE, COSIGNER_SPONSOR_KEY_FILE: '/sponsor_key' });
    expect(cfg.sponsorship).toMatchObject({ gate: GATE, key: { kind: 'file', path: '/sponsor_key' }, dailyCap: 100, maxFeePerGasWei: parseGwei('300'), maxPriorityFeePerGasWei: parseGwei('5') });
    const prod = { ...base, COSIGNER_MODE: 'production', COSIGNER_ALLOW_FILE_KEY_IN_PRODUCTION: '1', COSIGNER_SPONSOR_GATE: GATE, COSIGNER_SPONSOR_KEY_FILE: '/sponsor_key' };
    expect(() => read(prod)).toThrow(/COSIGNER_SPONSOR_KEY_FILE is a development key custody/);
    expect(read({ ...prod, COSIGNER_ALLOW_SPONSOR_FILE_KEY_IN_PRODUCTION: '1' }).sponsorship?.key).toMatchObject({ kind: 'file', allowInProduction: true });
    expect(read({ ...base, COSIGNER_SPONSOR_GATE: GATE, COSIGNER_SPONSOR_KMS_MODULE: '/kms.js', COSIGNER_SPONSOR_MAX_FEE_GWEI: '1.5' }).sponsorship)
      .toMatchObject({ key: { kind: 'kms', module: '/kms.js' }, maxFeePerGasWei: parseGwei('1.5') });
  });

  it('refuses the operator key in the environment, settings without the gate, and a gate without a key', () => {
    expect(() => read({ ...base, COSIGNER_SPONSOR_GATE: GATE, COSIGNER_SPONSOR_KEY_FILE: '/k', COSIGNER_SPONSOR_KEY: '0xabc' })).toThrow(/COSIGNER_SPONSOR_KEY is refused/);
    expect(() => read({ ...base, COSIGNER_SPONSOR_DAILY_CAP: '5' })).toThrow(/need COSIGNER_SPONSOR_GATE/);
    expect(() => read({ ...base, COSIGNER_SPONSOR_GATE: GATE })).toThrow(/needs the operator's transaction key/);
    expect(() => read({ ...base, COSIGNER_SPONSOR_GATE: GATE, COSIGNER_SPONSOR_KEY_FILE: '/k', COSIGNER_SPONSOR_DAILY_CAP: '0' })).toThrow(/at least 1/);
  });

  it('turns alerts on with the VAPID key file; any-endpoint mode is refused in production', () => {
    const on = { ...base, COSIGNER_ALERTS_VAPID_KEY_FILE: '/vapid.json', COSIGNER_ALERTS_SUBJECT: 'mailto:ops@movva.app', COSIGNER_ALERTS_STATE: '/alerts.jsonl' };
    expect(read(on).alerts).toMatchObject({ confirmations: 3, pollMs: 15_000, realertSeconds: 86_400, finalNoticeSeconds: 86_400, allowInsecureEndpoints: false, allowedHosts: expect.arrayContaining(['fcm.googleapis.com']) });
    expect(() => read({ ...on, COSIGNER_ALERTS_SUBJECT: 'ops' })).toThrow(/mailto/);
    expect(() => read({ ...base, COSIGNER_ALERTS_STATE: '/a.jsonl' })).toThrow(/need COSIGNER_ALERTS_VAPID_KEY_FILE/);
    expect(() => read({ ...on, COSIGNER_MODE: 'production', COSIGNER_ALLOW_FILE_KEY_IN_PRODUCTION: '1', COSIGNER_PUSH_ALLOW_INSECURE: '1' })).toThrow(/refused in production/);
    expect(read({ ...on, COSIGNER_PUSH_ALLOWED_HOSTS: 'push.example.com,.push.example.net' }).alerts?.allowedHosts).toEqual(['push.example.com', '.push.example.net']);
  });
});
