import { afterEach, describe, expect, it } from 'vitest';
import { getAddress, hexToBytes, pad, toHex, type Hex } from 'viem';
import { concatBytes, randomBytes, utf8ToBytes } from '@noble/hashes/utils';
import { secp256k1 } from '@noble/curves/secp256k1';
import {
  PasskeyAuthenticator, encodeWebAuthnSignature, frostInstallData, kernelInitData, kernelRecoverySetupCalls,
  predictKernelAddress,
} from '@mova/smart-account';
import {
  DkgSession, Point, aggregate, commit, generateDkgKey, secp256k1Auth, sign, verify,
  type Commitment, type DkgAuth, type DkgWireMessage,
} from '@mova/mpc';
import {
  CoSignerRefused, DKG_DEVICE, DKG_SERVER, DKG_THRESHOLD, RemoteCoSigner, dkgConfirmChallenge, dkgStartChallenge,
  enrolmentChallenge, serveCoSigner,
  type DkgStartResult, type FrostShareWriter,
} from '../src/index.js';
import {
  ADAPTER, CHAIN_ID, FCL_VERIFIERS, FROST_VALIDATOR, SERVER, deposit, enrolmentProof, expectRefusal, fakeSignerAddress,
  kernelOp, sig, world, type World,
} from './harness.js';

/**
 * Key generation between a device and the service, over the routes a browser calls.
 *
 * The happy path runs through the real HTTP server and `RemoteCoSigner.runDkg`, so what is tested is what a
 * wallet would actually execute. The refusals drive the service directly, because each one needs a message
 * built wrong on purpose.
 */

const TOKEN = 'dkg-client-token-0123456789abcdefghij';
const closers: (() => Promise<void>)[] = [];
afterEach(async () => { while (closers.length) await closers.pop()!(); });

/** A world whose share store is empty and writable: the DKG is what fills it. */
const dkgWorld = (o: Parameters<typeof world>[0] = {}) => world({ frostShares: [], ...o });

async function serve(w: World) {
  const s = serveCoSigner(w.service, { mode: 'api', apiKeys: [{ name: 'wallet', token: TOKEN }] });
  const port = await s.listen(0);
  closers.push(s.close);
  return new RemoteCoSigner({ url: `http://127.0.0.1:${port}`, chainId: CHAIN_ID, apiKey: TOKEN });
}

const shares = (w: World) => w.service as unknown as { o: { frostShares: FrostShareWriter } };
const storeOf = (w: World): FrostShareWriter => shares(w).o.frostShares;

const contextFor = (label: string): Hex => toHex(concatBytes(utf8ToBytes(`${label}/`), randomBytes(32)));

/** `runDkg`, on the harness's clock: the service checks the proof's age against it. */
const runDkg = (w: World, cosigner: RemoteCoSigner, o: Parameters<RemoteCoSigner['runDkg']>[0]) =>
  cosigner.runDkg({ issuedAt: Number(w.clock.now), ...o });

/** The audit log, as records. */
const dkgRecords = (w: World) => w.journal.load().filter((r) => r.t === 'dkg');

/** The device half, driven against the service object: everything `runDkg` does, one step at a time. */
async function begin(w: World, o: { label: string; passkey?: PasskeyAuthenticator; pk?: { x: bigint; y: bigint; verifiers: bigint } } ) {
  const authenticator = o.passkey ?? w.passkey;
  const pk = o.pk ?? w.pk;
  const key = generateDkgKey();
  const deviceKey = toHex(key.publicKey);
  const context = contextFor(o.label);
  const auth: DkgAuth = {
    sign: (digest) => secp256k1.sign(digest, key.secretKey, { prehash: false }).toBytes('compact'),
    verify: () => true,
  };
  const session = DkgSession.open({
    party: DKG_DEVICE,
    params: { context: hexToBytes(context), threshold: DKG_THRESHOLD, participants: [DKG_DEVICE, DKG_SERVER] },
    identities: new Map([[DKG_DEVICE, key.publicKey], [DKG_SERVER, hexToBytes(SERVER)]]),
    auth,
  });
  const round1 = await session.broadcast();
  const issuedAt = Number(w.clock.now);
  const challenge = dkgStartChallenge({ chainId: CHAIN_ID, coSigner: SERVER, passkey: pk, deviceKey, context, issuedAt });
  const request = {
    chainId: CHAIN_ID, passkey: pk, deviceKey, context, issuedAt, round1,
    passkeySignature: encodeWebAuthnSignature(authenticator.sign(hexToBytes(challenge))) as Hex,
  };
  return { session, key, deviceKey, context, issuedAt, request, authenticator, pk };
}

async function through(w: World, o: { label: string }) {
  const run = await begin(w, o);
  const start: DkgStartResult = await w.service.dkgStart(run.request, w.caller);
  const [message] = await run.session.round2([start.round1 as DkgWireMessage]);
  const r2 = await w.service.dkgRound2({ chainId: CHAIN_ID, sessionId: start.sessionId, message: message! }, w.caller);
  const { result, confirmation } = await run.session.finish([r2.message as DkgWireMessage]);
  await run.session.confirm([r2.confirmation as DkgWireMessage]);
  return { ...run, start, result, confirmation };
}

describe('DKG with a device, over the routes', () => {
  it('a browser runs the whole protocol over HTTP, and the two shares sign together', async () => {
    const w = dkgWorld();
    const cosigner = await serve(w);
    const out = await runDkg(w, cosigner, { passkey: { ...w.pk }, sign: (c) => w.passkey.sign(c), coSigner: SERVER, label: 'live-dkg' });
    expect(out.accountRef).toBe(fakeSignerAddress(w.pk));
    expect(out.keyShare.id).toBe(DKG_DEVICE);

    const server = storeOf(w).shareFor(out.keyShare.groupPublicKey);
    expect(server?.id).toBe(DKG_SERVER);
    expect(server!.share).not.toBe(out.keyShare.share);
    expect(server!.groupPublicKey.equals(out.keyShare.groupPublicKey)).toBe(true);
    expect(toHex(out.keyShare.groupPublicKey.toBytes(true))).toBe(out.groupKey);

    const digest = randomBytes(32);
    const rounds = [out.keyShare, server!].map((s) => ({ share: s, ...commit(s) }));
    const list = rounds.map((r) => r.commitment);
    const signature = aggregate(list, rounds.map((r) => sign(r.share, r.nonces, list, digest)), digest, out.keyShare.groupPublicKey);
    expect(verify(signature, digest, out.keyShare.groupPublicKey)).toBe(true);
  });

  it('the key it produced becomes a Kernel FrostValidator account that signs through /v1/frost', async () => {
    const w = dkgWorld();
    const cosigner = await serve(w);
    const out = await runDkg(w, cosigner, { passkey: { ...w.pk }, sign: (c) => w.passkey.sign(c), coSigner: SERVER });

    const initData = kernelInitData({ rootValidator: FROST_VALIDATOR, validatorData: frostInstallData(out.keyShare.groupPublicKey) });
    const salt = pad(toHex(9n), { size: 32 });
    const account = predictKernelAddress({ initData, salt });
    const { enrolment } = await w.service.enrol(
      { chainId: CHAIN_ID, account, type: 'kernel', passkey: w.pk, kernel: { initData, salt }, ...enrolmentProof(w, account) }, w.caller,
    );
    expect(enrolment.kind).toBe('kernel-frost');
    expect(enrolment.groupKey).toBe(out.groupKey);
    expect(enrolment.passkeySigner).toBe(out.accountRef);

    const setup = kernelRecoverySetupCalls({ account, passkey: w.pk, passkeySigner: fakeSignerAddress(w.pk), adapter: ADAPTER }).calls;
    const op = kernelOp(w, account, [...setup, deposit(1n)], { initCode: '0x1234', validator: FROST_VALIDATOR });
    const server = await w.service.frostCommit({ chainId: CHAIN_ID, account }, w.caller);
    const { nonces, commitment } = commit(out.keyShare);
    const serverCommitment: Commitment = {
      id: server.commitment.id,
      hiding: Point.fromBytes(hexToBytes(server.commitment.hiding)),
      binding: Point.fromBytes(hexToBytes(server.commitment.binding)),
    };
    const list = [commitment, serverCommitment];
    const r = await w.service.frostSign({
      chainId: CHAIN_ID, account, kind: 'kernel-operation', ...op, route: 'cosign',
      sessionId: server.sessionId, commitments: list, passkeySignature: sig(w, op.digest),
    }, w.caller);
    const msg = hexToBytes(op.digest);
    const signature = aggregate(list, [sign(out.keyShare, nonces, list, msg), { id: r.share.id, z: BigInt(r.share.z) }], msg, out.keyShare.groupPublicKey);
    expect(verify(signature, msg, out.keyShare.groupPublicKey)).toBe(true);
  });

  it('writes every round to the audit log, and no share', async () => {
    const w = dkgWorld();
    const out = await through(w, { label: 'audited' });
    const confirmed = await w.service.dkgConfirm({
      chainId: CHAIN_ID, sessionId: out.start.sessionId, confirmation: out.confirmation,
      passkeySignature: encodeWebAuthnSignature(w.passkey.sign(hexToBytes(dkgConfirmChallenge({
        chainId: CHAIN_ID, coSigner: SERVER, session: out.start.sessionId,
        groupKey: toHex(out.result.publicKeys.groupPublicKey.toBytes(true)), transcript: `0x${out.result.publicKeys.transcript}`,
      })))),
    }, w.caller);
    const records = dkgRecords(w);
    expect(records.map((r) => r.event)).toEqual(['started', 'round2', 'completed']);
    expect(records[2]).toMatchObject({ accountRef: `${CHAIN_ID}:${fakeSignerAddress(w.pk).toLowerCase()}`, groupKey: confirmed.groupKey });
    const text = w.journal.lines.join('\n');
    const server = storeOf(w).shareFor(out.result.publicKeys.groupPublicKey)!;
    expect(text).not.toContain(server.share.toString(16));
    expect(text).not.toContain(out.result.keyShare.share.toString(16));
  });
});

describe('DKG: what the service refuses', () => {
  it('a second key generation for an account that already has a share', async () => {
    const w = dkgWorld();
    const cosigner = await serve(w);
    await runDkg(w, cosigner, { passkey: { ...w.pk }, sign: (c) => w.passkey.sign(c), coSigner: SERVER });
    await expect(runDkg(w, cosigner, { passkey: { ...w.pk }, sign: (c) => w.passkey.sign(c), coSigner: SERVER }))
      .rejects.toMatchObject({ code: 'dkg_exists' });
    // Another passkey is another account, and is allowed.
    const other = PasskeyAuthenticator.create('wallet.brl.example');
    const pub = other.publicKey();
    const out = await runDkg(w, cosigner, { passkey: { x: pub.x, y: pub.y, verifiers: FCL_VERIFIERS }, sign: (c) => other.sign(c), coSigner: SERVER });
    expect(out.accountRef).not.toBe(fakeSignerAddress(w.pk));
  });

  it('a second run while one is open for the same account', async () => {
    const w = dkgWorld();
    await w.service.dkgStart((await begin(w, { label: 'first' })).request, w.caller);
    await expectRefusal(w.service.dkgStart((await begin(w, { label: 'second' })).request, w.caller), 'dkg_exists');
  });

  it('a run without the passkey, and one whose assertion is over something else', async () => {
    const w = dkgWorld();
    const none = await begin(w, { label: 'no-passkey' });
    await expectRefusal(w.service.dkgStart({ ...none.request, passkeySignature: '0x' }, w.caller), 'passkey_required');
    const wrong = await begin(w, { label: 'wrong-passkey' });
    await expectRefusal(w.service.dkgStart({ ...wrong.request, passkeySignature: sig(w, enrolmentChallenge(CHAIN_ID, SERVER, SERVER, 1)) }, w.caller), 'bad_passkey_signature');
    // A stale proof is refused like a stale enrolment.
    const stale = await begin(w, { label: 'stale' });
    await expectRefusal(w.service.dkgStart({ ...stale.request, issuedAt: stale.issuedAt - 3600 }, w.caller), 'enrolment_expired');
  });

  it('a confirmation the device signed for a different key, and one without its passkey', async () => {
    const w = dkgWorld();
    const out = await through(w, { label: 'bad-confirm' });
    const groupKey = toHex(out.result.publicKeys.groupPublicKey.toBytes(true));
    const transcript = `0x${out.result.publicKeys.transcript}` as Hex;
    await expectRefusal(w.service.dkgConfirm({ chainId: CHAIN_ID, sessionId: out.start.sessionId, confirmation: out.confirmation, passkeySignature: '0x' }, w.caller), 'passkey_required');
    await expectRefusal(w.service.dkgConfirm({
      chainId: CHAIN_ID, sessionId: out.start.sessionId, confirmation: out.confirmation,
      passkeySignature: sig(w, dkgConfirmChallenge({ chainId: CHAIN_ID, coSigner: SERVER, session: out.start.sessionId, groupKey, transcript: pad('0x01', { size: 32 }) })),
    }, w.caller), 'bad_passkey_signature');
    // The share is still pending, and a share that never confirmed never signs.
    expect(storeOf(w).shareFor(out.result.publicKeys.groupPublicKey)).toBeUndefined();
    expect(storeOf(w).record(out.result.publicKeys.groupPublicKey)?.complete).toBe(false);
  });

  it('a share whose run never confirmed: the account cannot be enrolled and nothing can sign with it', async () => {
    const w = dkgWorld();
    const out = await through(w, { label: 'never-confirmed' });
    const groupKey = out.result.publicKeys.groupPublicKey;
    const initData = kernelInitData({ rootValidator: FROST_VALIDATOR, validatorData: frostInstallData(groupKey) });
    const salt = pad(toHex(4n), { size: 32 });
    const account = predictKernelAddress({ initData, salt });
    await expectRefusal(w.service.enrol(
      { chainId: CHAIN_ID, account, type: 'kernel', passkey: w.pk, kernel: { initData, salt }, ...enrolmentProof(w, account) }, w.caller,
    ), 'no_share');
  });

  it('a pending share left by a run that expired does not strand the account: the next run replaces it', async () => {
    const w = dkgWorld();
    const abandoned = await through(w, { label: 'abandoned' });
    expect(storeOf(w).record(abandoned.result.publicKeys.groupPublicKey)?.complete).toBe(false);
    // While the run is open, a second one is refused.
    await expectRefusal(w.service.dkgStart((await begin(w, { label: 'too-soon' })).request, w.caller), 'dkg_exists');
    w.clock.ms += 301_000;
    const second = await through(w, { label: 'second-try' });
    expect(second.result.publicKeys.groupPublicKey.equals(abandoned.result.publicKeys.groupPublicKey)).toBe(false);
    expect(storeOf(w).record(abandoned.result.publicKeys.groupPublicKey)).toBeUndefined();
    const confirmed = await w.service.dkgConfirm({
      chainId: CHAIN_ID, sessionId: second.start.sessionId, confirmation: second.confirmation,
      passkeySignature: sig(w, dkgConfirmChallenge({
        chainId: CHAIN_ID, coSigner: SERVER, session: second.start.sessionId,
        groupKey: toHex(second.result.publicKeys.groupPublicKey.toBytes(true)), transcript: `0x${second.result.publicKeys.transcript}`,
      })),
    }, w.caller);
    expect(confirmed.complete).toBe(true);
    expect(storeOf(w).shareFor(second.result.publicKeys.groupPublicKey)?.id).toBe(DKG_SERVER);
    // ...and now that it is complete, a third run is refused for good.
    await expectRefusal(w.service.dkgStart((await begin(w, { label: 'third' })).request, w.caller), 'dkg_exists');
  });

  it('round 2 replayed, an unknown session, and a session that expired', async () => {
    const w = dkgWorld();
    const out = await through(w, { label: 'replay' });
    // The run is past round 2 now: the same request again finds nothing at that round.
    const again = { chainId: CHAIN_ID, sessionId: out.start.sessionId, message: out.start.round1 };
    await expectRefusal(w.service.dkgRound2(again, w.caller), 'session_unknown');
    await expectRefusal(w.service.dkgRound2({ ...again, sessionId: pad('0xdead', { size: 32 }) }, w.caller), 'session_unknown');

    const fresh = dkgWorld();
    const run = await begin(fresh, { label: 'expiry' });
    const start = await fresh.service.dkgStart(run.request, fresh.caller);
    const [message] = await run.session.round2([start.round1 as DkgWireMessage]);
    fresh.clock.ms += 301_000;
    await expectRefusal(fresh.service.dkgRound2({ chainId: CHAIN_ID, sessionId: start.sessionId, message: message! }, fresh.caller), 'session_unknown');
  });

  it('a round-2 message signed by a key the run did not authorise, naming the participant', async () => {
    const w = dkgWorld();
    const run = await begin(w, { label: 'forged' });
    const start = await w.service.dkgStart(run.request, w.caller);
    const [message] = await run.session.round2([start.round1 as DkgWireMessage]);
    const stranger = generateDkgKey();
    const digest = randomBytes(32);
    const forged = { ...message!, signature: toHex(secp256k1.sign(digest, stranger.secretKey, { prehash: false }).toBytes('compact')).slice(2) };
    try {
      await w.service.dkgRound2({ chainId: CHAIN_ID, sessionId: start.sessionId, message: forged }, w.caller);
      throw new Error('accepted');
    } catch (e) {
      expect((e as { code?: string }).code).toBe('dkg_invalid');
      expect((e as Error).message).toContain('unauthenticated');
    }
    const refusal = dkgRecords(w).at(-1) as { event: string; code?: string; party?: number };
    expect(refusal).toMatchObject({ event: 'refused', code: 'dkg_invalid', party: DKG_DEVICE });
  });

  it('a request for another chain, a malformed device key and a context that is too short', async () => {
    const w = dkgWorld();
    const run = await begin(w, { label: 'shapes' });
    await expectRefusal(w.service.dkgStart({ ...run.request, chainId: CHAIN_ID + 1 }, w.caller), 'wrong_chain');
    const { parseDkgStartRequest } = await import('../src/dkg.js');
    const wire = JSON.parse(JSON.stringify(run.request, (_k, v) => (typeof v === 'bigint' ? v.toString() : v))) as Record<string, unknown>;
    expect(() => parseDkgStartRequest({ ...wire, deviceKey: '0x1234' })).toThrow(/deviceKey/);
    expect(() => parseDkgStartRequest({ ...wire, context: '0x0102' })).toThrow(/context/);
    expect(() => parseDkgStartRequest({ ...wire, round1: { ...(wire.round1 as object), payload: '0xNOTHEX' } })).toThrow(/payload/);
    expect(parseDkgStartRequest(wire).deviceKey).toBe(run.deviceKey);
  });

  it('a service whose share store cannot be written to does not generate keys at all', async () => {
    const w = world();
    const run = await begin(w, { label: 'disabled' });
    await expectRefusal(w.service.dkgStart(run.request, w.caller), 'dkg_disabled');
    expect(w.service.info().frost).toBeNull();
    const enabled = dkgWorld();
    expect(enabled.service.info().frost).toMatchObject({ dkg: true });
  });

  it('enrolling a group key this service generated for a different passkey', async () => {
    const w = dkgWorld();
    const cosigner = await serve(w);
    const out = await runDkg(w, cosigner, { passkey: { ...w.pk }, sign: (c) => w.passkey.sign(c), coSigner: SERVER });
    const other = PasskeyAuthenticator.create('wallet.brl.example');
    const pub = other.publicKey();
    const otherPk = { x: pub.x, y: pub.y, verifiers: FCL_VERIFIERS };
    const initData = kernelInitData({ rootValidator: FROST_VALIDATOR, validatorData: frostInstallData(out.keyShare.groupPublicKey) });
    const salt = pad(toHex(11n), { size: 32 });
    const account = predictKernelAddress({ initData, salt });
    const issuedAt = Number(w.clock.now);
    await expectRefusal(w.service.enrol({
      chainId: CHAIN_ID, account, type: 'kernel', passkey: otherPk, kernel: { initData, salt }, issuedAt,
      passkeySignature: encodeWebAuthnSignature(other.sign(hexToBytes(enrolmentChallenge(CHAIN_ID, account, SERVER, issuedAt)))),
    }, w.caller), 'dkg_invalid');
  });

  it('a client that expects another co-signer stops before sending its share', async () => {
    const w = dkgWorld();
    const cosigner = await serve(w);
    await expect(runDkg(w, cosigner, {
      passkey: { ...w.pk }, sign: (c) => w.passkey.sign(c), coSigner: getAddress(`0x${'cc'.repeat(20)}`),
    })).rejects.toThrow();
  });
});

void CoSignerRefused;
