/**
 * Prometheus exposition, prefix `mova_cosigner_`.
 *
 * Label values come only from fixed vocabularies in code - a route, a result, a refusal code, an account
 * kind - never from a request: an account address is not a label (which accounts use this service is
 * customer data), and neither is any error text.
 */
import { REFUSAL_CODES } from './refusal.js';

type Kind = 'counter' | 'gauge';

const DEFS = {
  mova_cosigner_up: ['gauge', '1 while the co-signer process is running.'],
  mova_cosigner_ready: ['gauge', '1 once the chain, the key and the audit log have been checked.'],
  mova_cosigner_requests_total: ['counter', 'Requests by route and result (signed, reused, refused, served).'],
  mova_cosigner_refusals_total: ['counter', 'Requests refused, by code.'],
  mova_cosigner_signatures_total: ['counter', 'Co-signatures and FROST signature shares produced, by account kind.'],
  mova_cosigner_enrolments: ['gauge', 'Accounts enrolled.'],
  mova_cosigner_audit_records: ['gauge', 'Records in the audit log.'],
  mova_cosigner_frost_sessions_open: ['gauge', 'FROST sessions committed and not yet used or expired.'],
  mova_cosigner_dkg_sessions_open: ['gauge', 'Distributed key generations started and not yet finished or expired.'],
  mova_cosigner_dkg_total: ['counter', 'Distributed key generations by result (completed, refused).'],
  mova_cosigner_sponsorships_total: ['counter', 'Sponsorship decisions by result (sponsored, already, refused, failed).'],
  mova_cosigner_sponsor_gate_remaining: ['gauge', 'Accounts SponsorGate lets operators add in its current window, at the last read.'],
  mova_cosigner_sponsor_operator_balance_eth: ['gauge', 'The sponsorship operator key\'s ETH, at the last read.'],
  mova_cosigner_push_subscriptions: ['gauge', 'Devices subscribed to recovery alerts.'],
  mova_cosigner_push_total: ['counter', 'Recovery alert deliveries by result (delivered, gone, failed).'],
  mova_cosigner_recovery_pending: ['gauge', 'Queued recovery transactions still being alerted on.'],
  mova_cosigner_recovery_watch_block: ['gauge', 'The last block the recovery watcher has read, after confirmations.'],
} as const satisfies Record<string, readonly [Kind, string]>;

export type CoSignerMetricName = keyof typeof DEFS;
type Labels = Record<string, string>;

const esc = (s: string) => s.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n');
const key = (labels: Labels) => Object.keys(labels).sort().map((k) => `${k}="${esc(labels[k]!)}"`).join(',');

export class CoSignerMetrics {
  private readonly series = new Map<CoSignerMetricName, Map<string, number>>();

  constructor() {
    for (const n of Object.keys(DEFS) as CoSignerMetricName[]) this.series.set(n, new Map());
    this.set('mova_cosigner_up', 1);
    this.set('mova_cosigner_ready', 0);
    for (const code of REFUSAL_CODES) this.series.get('mova_cosigner_refusals_total')!.set(key({ code }), 0);
  }

  inc(name: CoSignerMetricName, labels: Labels = {}, by = 1): void {
    const m = this.series.get(name)!;
    const k = key(labels);
    m.set(k, (m.get(k) ?? 0) + by);
  }

  set(name: CoSignerMetricName, value: number, labels: Labels = {}): void {
    this.series.get(name)!.set(key(labels), value);
  }

  get(name: CoSignerMetricName, labels: Labels = {}): number {
    return this.series.get(name)!.get(key(labels)) ?? 0;
  }

  render(): string {
    const lines: string[] = [];
    for (const [name, [type, help]] of Object.entries(DEFS) as [CoSignerMetricName, readonly [Kind, string]][]) {
      lines.push(`# HELP ${name} ${help}`);
      lines.push(`# TYPE ${name} ${type}`);
      const m = this.series.get(name)!;
      if (m.size === 0) lines.push(`${name} 0`);
      for (const [k, v] of m) lines.push(`${name}${k ? `{${k}}` : ''} ${Number.isFinite(v) ? v : 0}`);
    }
    return `${lines.join('\n')}\n`;
  }
}
