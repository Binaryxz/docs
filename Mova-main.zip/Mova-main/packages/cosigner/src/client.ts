/**
 * `RemoteCoSigner`: the wallet's side of the co-signer service, so a wallet swaps the local server key for
 * the service without changing an executor.
 *
 * The executors ask their signers for a signature over a DIGEST (`SafeOwner.signHash`, the
 * `passkeyCoSignerSigner` co-signer callback, `KernelValidatorSigner.sign`), and a digest is exactly what the
 * service refuses to sign: it co-signs an operation it can read and a passkey signature it can check. So the
 * stand-ins below return a placeholder of the right length, and the operation is co-signed where the whole of
 * it exists - in the submitter, just before the bundler:
 *
 *   const cosigner = new RemoteCoSigner({ url, chainId, apiKey });
 *   const coSigner = (await cosigner.info()).coSigner;
 *
 *   // Safe 2-of-2
 *   const remote = cosigner.safe({ safe, passkeySigner, coSigner });
 *   const executor = remote.wrap(new SafeExecutor({ ..., owners: [passkeySafeOwner(passkeySigner, passkey), remote.owner],
 *                                                   submitter: remote.submitter(bundler) }));
 *   // Kernel + PasskeyCoSignerValidator
 *   const remote = cosigner.kernel({ account, validator, coSigner });
 *   const executor = remote.wrap(new KernelExecutor({ ..., submitter: remote.submitter(bundler),
 *     signer: passkeyCoSignerSigner({ validator, passkey, coSigner: remote.coSign }) }));
 *
 * The submitter reads the passkey's half out of the signature the executor assembled, sends the operation and
 * that half to the service (`/v1/veto` when the operation is exactly one `setTxNonce`, `/v1/cosign`
 * otherwise), checks that the answer recovers to the co-signer over the digest it computes itself, puts it in
 * the placeholder's place and hands the operation to the real submitter. `wrap` does the same for
 * `signTypedData` (ERC-1271, including a Kernel ERC-6492 wrapper). An operation with no placeholder passes
 * through untouched.
 *
 * FROST accounts: `frostSafe` / `frostKernel` run the device's half of a two-party FROST session with the
 * service at submit time, with a fresh passkey assertion over the same digest.
 *
 * Recovery alerts, in a browser: `subscribeRecoveryAlerts(registration, ...)` subscribes the service worker's push
 * manager with the co-signer's VAPID key and registers the subscription with a fresh passkey assertion;
 * `handleRecoveryPush(event)` shows the notification in the service worker. Sponsorship: `enrol` answers with the
 * account's sponsorship, and `waitForSponsorship` follows it until the account can transact.
 *
 * Key generation: `runDkg` runs the device's half of a distributed key generation with the service, so a page
 * can make a FROST account's key without any machine ever holding the group secret (docs/wallet-custody.md §5).
 *
 * Browser-safe: fetch, viem, @noble and packages/mpc; nothing from node.
 */
import {
  decodeFunctionData, getAddress, hashTypedData, hexToBytes, isErc6492Signature, parseAbi, parseErc6492Signature, recoverAddress,
  size, slice, toFunctionSelector, toHex,
  type Address, type Hex, type TypedDataDefinition,
} from 'viem';
import {
  decodeKernelUserOpSignature, decodePasskeyCoSignerSignature, encodeFrostSignature, encodeKernelUserOpSignature,
  encodePasskeyCoSignerSignature, encodeWebAuthnSignature, kernelWrappedHash,
  type KernelValidatorSigner, type PackedUserOperation, type PasskeyPublicKey, type WebAuthnAssertion,
} from '@mova/smart-account';
import type { AccountExecutor, Executed, SafeOwner, UserOpSubmitter } from '@mova/wallet/src/executor.js';
import { safeMessageHash } from '@mova/wallet/src/executor.js';
import { secp256k1 } from '@noble/curves/secp256k1';
import { concatBytes, randomBytes, utf8ToBytes } from '@noble/hashes/utils';
import {
  DkgSession, Point, aggregate, commit, generateDkgKey, sign, verify,
  type Commitment, type DkgAuth, type DkgWireMessage, type KeyShare, type PointT, type Signature,
} from '@mova/mpc';
import {
  RECOVERY_ALERT_TEXT, alertsSubscribeChallenge, alertsUnsubscribeChallenge, canonicalB64url,
  type AlertSubscriptionJson, type RecoveryAlertPayload,
} from './alerts-proof.js';
import {
  DKG_DEVICE, DKG_SERVER, DKG_THRESHOLD, dkgConfirmChallenge, dkgStartChallenge,
  type DkgConfirmResult, type DkgRound2Result, type DkgStartResult,
} from './dkg-proof.js';
import { enrolmentChallenge } from './enrolment.js';
import {
  containsPlaceholder, decodeKernelCallData, decodeSafeCallData, kernelOperationDigest, placeholderSignature, safeOperationDigest,
  spliceSignature, splitSafeSignature, userOpToWire,
  type UnsignedUserOp, type ValidityWindow, type WireUserOp,
} from './operation.js';

export class CoSignerRefused extends Error {
  override readonly name = 'CoSignerRefused';
  constructor(readonly status: number, readonly code: string, message: string) {
    super(`co-signer refused (${code}): ${message}`);
  }
}

export interface RemoteCoSignerOptions {
  /** The API base, e.g. `https://cosigner.mova.example`. */
  url: string;
  chainId: number;
  apiKey?: string;
  timeoutMs?: number;
  fetch?: typeof fetch;
}

export interface CoSignerInfo {
  service: string;
  chainId: number;
  coSigner: Address;
  custody: string;
  entryPoint: Address;
  deployment: { entryPoint: Address; passkeyValidator?: Address; frostValidator?: Address; kernelAdapter?: Address };
  policy: Record<string, unknown>;
  /** Present when the service sponsors enrolled accounts through SponsorGate. */
  sponsorship?: { gate: Address; operator: Address; dailyCap: number } | null;
  /** Present when the service sends recovery alerts. */
  alerts?: { vapidPublicKey: string; subscribeTypehash: Hex; unsubscribeTypehash: Hex; maxProofAgeSeconds: number } | null;
}

/** An account's sponsorship, as the service reports it. */
export interface RemoteSponsorship {
  chainId: number;
  account: Address;
  status: 'pending' | 'sponsored' | 'refused' | 'failed' | 'none';
  code?: string;
  message?: string;
  retryable?: boolean;
  signerTx?: Hex;
  /** A Kernel account created by the service before its first operation, so that operation carries no initCode. */
  accountTx?: Hex;
  sponsorTx?: Hex;
}

export class SponsorshipNotGranted extends Error {
  override readonly name = 'SponsorshipNotGranted';
  constructor(readonly sponsorship: RemoteSponsorship) {
    super(`the co-signer did not sponsor ${sponsorship.account}: ${sponsorship.code ?? sponsorship.status}${sponsorship.message ? ` (${sponsorship.message})` : ''}`);
  }
}

export interface RemoteCosignResult {
  digest: Hex;
  coSigner: Address;
  coSignature: Hex;
  signature: Hex;
  reused: boolean;
}

export interface RemoteQueue {
  account: Address;
  delay: Address;
  txNonce: bigint;
  queueNonce: bigint;
  cooldown: bigint;
  expiration: bigint;
  vetoNonce?: bigint;
  pending: { nonce: bigint; txHash: Hex; createdAt: bigint; executableAt: bigint; expiresAt: bigint; call?: { to: Address; value: bigint; data: Hex; operation: number } }[];
}

export type PasskeySign = (challenge: Uint8Array) => WebAuthnAssertion | Promise<WebAuthnAssertion>;

type WireSigning = {
  kind: 'safe-operation' | 'kernel-operation' | 'safe-message' | 'kernel-message';
  account: Address;
  userOp?: WireUserOp;
  validAfter?: number;
  validUntil?: number;
  typedData?: unknown;
  passkeySignature: Hex;
  requestId?: string;
};

const SET_TX_NONCE = toFunctionSelector('setTxNonce(uint256)').toLowerCase();
const same = (a: Address | undefined, b: Address | undefined) => !!a && !!b && a.toLowerCase() === b.toLowerCase();
const jsonSafe = (v: unknown): unknown => JSON.parse(JSON.stringify(v, (_k, x) => (typeof x === 'bigint' ? x.toString() : x)));
const unsignedOf = ({ signature: _s, ...op }: PackedUserOperation): UnsignedUserOp => op;

/** Exactly one `setTxNonce` call: the operation goes to the veto route. */
export function isVetoOperation(callData: Hex, family: 'safe' | 'kernel'): boolean {
  try {
    const calls = family === 'safe' ? decodeSafeCallData(callData) : decodeKernelCallData(callData);
    return calls.length === 1 && calls[0]!.data.slice(0, 10).toLowerCase() === SET_TX_NONCE;
  } catch {
    return false;
  }
}

async function expectCoSignature(digest: Hex, coSignature: Hex, coSigner: Address): Promise<void> {
  let recovered: Address;
  try {
    recovered = await recoverAddress({ hash: digest, signature: coSignature });
  } catch {
    throw new Error('the co-signer answered with a signature that does not decode');
  }
  if (!same(recovered, coSigner)) throw new Error(`the co-signature is not from ${coSigner} over this operation`);
}

export class RemoteCoSigner {
  constructor(private readonly o: RemoteCoSignerOptions) {}

  get chainId(): number {
    return this.o.chainId;
  }

  private async call<T>(method: 'GET' | 'POST', path: string, body?: unknown): Promise<T> {
    const headers: Record<string, string> = {};
    if (this.o.apiKey) headers.authorization = `Bearer ${this.o.apiKey}`;
    if (body !== undefined) headers['content-type'] = 'application/json';
    const res = await (this.o.fetch ?? fetch)(`${this.o.url.replace(/\/$/, '')}${path}`, {
      method, headers, body: body === undefined ? undefined : JSON.stringify(jsonSafe(body)),
      signal: AbortSignal.timeout(this.o.timeoutMs ?? 30_000),
    });
    const text = await res.text();
    let parsed: { error?: string; message?: string } & Record<string, unknown>;
    try {
      parsed = JSON.parse(text) as typeof parsed;
    } catch {
      throw new CoSignerRefused(res.status, 'unknown', `HTTP ${res.status} without a JSON body`);
    }
    if (!res.ok) throw new CoSignerRefused(res.status, parsed.error ?? 'unknown', parsed.message ?? `HTTP ${res.status}`);
    return parsed as T;
  }

  info(): Promise<CoSignerInfo> {
    return this.call('GET', '/v1/info');
  }

  /** Enrol an account, proving the passkey with an assertion over the enrolment challenge. */
  async enrol(e: {
    account: Address;
    type: 'safe' | 'kernel';
    coSigner: Address;
    passkey: PasskeyPublicKey & { verifiers?: bigint };
    sign: PasskeySign;
    safe?: { owners: Address[]; threshold: number; saltNonce: bigint };
    kernel?: { initData: Hex; salt: Hex };
    issuedAt?: number;
  }): Promise<{ created: boolean; enrolment: Record<string, unknown>; sponsorship?: RemoteSponsorship }> {
    const issuedAt = e.issuedAt ?? Math.floor(Date.now() / 1000);
    const challenge = enrolmentChallenge(this.o.chainId, e.account, e.coSigner, issuedAt);
    const assertion = await e.sign(hexToBytes(challenge));
    return this.call('POST', '/v1/enrol', {
      chainId: this.o.chainId, account: getAddress(e.account), type: e.type, issuedAt,
      passkey: { x: e.passkey.x, y: e.passkey.y, ...(e.passkey.verifiers !== undefined ? { verifiers: e.passkey.verifiers } : {}) },
      safe: e.safe, kernel: e.kernel, passkeySignature: encodeWebAuthnSignature(assertion),
    });
  }

  /** The enrolled account's sponsorship. */
  sponsorship(account: Address): Promise<RemoteSponsorship> {
    return this.call('GET', `/v1/sponsorship?chainId=${this.o.chainId}&account=${getAddress(account)}`);
  }

  /**
   * Follow an account's sponsorship until it is granted. Throws `SponsorshipNotGranted` when the service refused or
   * failed it (enrolling again retries what is `retryable`), or when nothing was requested.
   */
  async waitForSponsorship(account: Address, o: { timeoutMs?: number; intervalMs?: number } = {}): Promise<RemoteSponsorship> {
    const deadline = Date.now() + (o.timeoutMs ?? 120_000);
    for (;;) {
      const s = await this.sponsorship(account);
      if (s.status === 'sponsored') return s;
      if (s.status !== 'pending') throw new SponsorshipNotGranted(s);
      if (Date.now() >= deadline) throw new SponsorshipNotGranted({ ...s, message: 'still pending when the wait ran out' });
      await new Promise((r) => setTimeout(r, o.intervalMs ?? 1_000));
    }
  }

  /** Register a push subscription for the account's recovery alerts, proven by a fresh passkey assertion. */
  async subscribeAlerts(o: { account: Address; coSigner: Address; subscription: AlertSubscriptionJson; sign: PasskeySign; issuedAt?: number }): Promise<{ subscribed: true; created: boolean; pending: number }> {
    const issuedAt = o.issuedAt ?? Math.floor(Date.now() / 1000);
    const subscription = { endpoint: o.subscription.endpoint, keys: { p256dh: canonicalB64url(o.subscription.keys.p256dh), auth: canonicalB64url(o.subscription.keys.auth) } };
    const challenge = alertsSubscribeChallenge(this.o.chainId, o.account, o.coSigner, issuedAt, subscription);
    const assertion = await o.sign(hexToBytes(challenge));
    return this.call('POST', '/v1/alerts/subscribe', {
      chainId: this.o.chainId, account: getAddress(o.account), subscription, issuedAt, passkeySignature: encodeWebAuthnSignature(assertion),
    });
  }

  /** Remove a device's subscription, with the same proof. Refused (`recovery_pending`) while a recovery is queued. */
  async unsubscribeAlerts(o: { account: Address; coSigner: Address; endpoint: string; sign: PasskeySign; issuedAt?: number }): Promise<{ unsubscribed: true }> {
    const issuedAt = o.issuedAt ?? Math.floor(Date.now() / 1000);
    const challenge = alertsUnsubscribeChallenge(this.o.chainId, o.account, o.coSigner, issuedAt, o.endpoint);
    const assertion = await o.sign(hexToBytes(challenge));
    return this.call('POST', '/v1/alerts/unsubscribe', {
      chainId: this.o.chainId, account: getAddress(o.account), endpoint: o.endpoint, issuedAt, passkeySignature: encodeWebAuthnSignature(assertion),
    });
  }

  cosign(payload: WireSigning): Promise<RemoteCosignResult> {
    return this.call('POST', '/v1/cosign', { chainId: this.o.chainId, ...payload });
  }

  veto(payload: WireSigning): Promise<RemoteCosignResult> {
    return this.call('POST', '/v1/veto', { chainId: this.o.chainId, ...payload });
  }

  async queue(account: Address): Promise<RemoteQueue> {
    const q = await this.call<Record<string, unknown>>('GET', `/v1/queue?chainId=${this.o.chainId}&account=${getAddress(account)}`);
    const big = (v: unknown) => BigInt(v as string);
    return {
      account: getAddress(q.account as string), delay: getAddress(q.delay as string), txNonce: big(q.txNonce), queueNonce: big(q.queueNonce),
      cooldown: big(q.cooldown), expiration: big(q.expiration), vetoNonce: q.vetoNonce === undefined ? undefined : big(q.vetoNonce),
      pending: (q.pending as Record<string, unknown>[]).map((p) => {
        const call = p.call as Record<string, unknown> | undefined;
        return {
          nonce: big(p.nonce), txHash: p.txHash as Hex, createdAt: big(p.createdAt), executableAt: big(p.executableAt), expiresAt: big(p.expiresAt),
          call: call ? { to: getAddress(call.to as string), value: big(call.value), data: call.data as Hex, operation: Number(call.operation) } : undefined,
        };
      }),
    };
  }

  frostCommit(account: Address): Promise<{ sessionId: Hex; commitment: { id: number; hiding: Hex; binding: Hex }; expiresAt: number }> {
    return this.call('POST', '/v1/frost/commit', { chainId: this.o.chainId, account: getAddress(account) });
  }

  frostSign(req: WireSigning & { sessionId: Hex; route: 'cosign' | 'veto'; commitments: { id: number; hiding: Hex; binding: Hex }[] }): Promise<{ digest: Hex; share: { id: number; z: Hex }; reused: boolean }> {
    return this.call('POST', '/v1/frost/sign', { chainId: this.o.chainId, ...req });
  }

  /* ------------------------------------------------------------------ distributed key generation */

  /**
   * Generate a FROST key WITH the service: the device's half of `dkg.ts`, in a browser.
   *
   * Nothing here needs node: @noble for the curves and the AEAD, viem for hashing and address recovery, and
   * `fetch`. A page calls this once, before the account exists, and seals what it returns with
   * `sealShare(...)` from @mova/smart-account (docs/wallet-custody.md §5) - this function never writes the
   * share anywhere.
   *
   * What the user is asked for: TWO user-verified assertions. The first authorises the run and the per-run
   * signing key this function generates; the second accepts the group key that came out of it. Between them
   * every message in both directions is signed - the device's under the per-run key, the service's under the
   * co-signer key `coSigner` names, checked here by recovery - and the round-2 shares are sealed to X25519
   * keys exchanged in round 1, so the share the service sends can be opened by this device alone.
   *
   * It throws if the service's group key is not the one this device derived: `DkgSession` compares the whole
   * transcript, and a mismatch means the run did not agree and the key must not be used.
   */
  async runDkg(o: {
    passkey: PasskeyPublicKey & { verifiers: bigint };
    sign: PasskeySign;
    /** The service's address, from `info()`: every message it sends must recover to it. */
    coSigner: Address;
    /** Goes into the DKG context, before 32 random bytes. Name what the key is for. */
    label?: string;
    issuedAt?: number;
  }): Promise<{
    keyShare: KeyShare;
    groupKey: Hex;
    /** `verificationShares` and the transcript, as the service reported them and this device checked them. */
    verificationShares: Map<number, PointT>;
    transcript: Hex;
    sessionId: Hex;
    accountRef: Address;
  }> {
    const coSigner = getAddress(o.coSigner);
    const device = generateDkgKey();
    const deviceKey = toHex(device.publicKey);
    const context = toHex(concatBytes(utf8ToBytes(`${o.label ?? 'mova-frost'}/`), randomBytes(32)));
    const auth: DkgAuth = {
      sign: (digest) => secp256k1.sign(digest, device.secretKey, { prehash: false }).toBytes('compact'),
      verify: async (party, digest, signature) => {
        if (party !== DKG_SERVER || signature.length !== 65) return false;
        try {
          return same(await recoverAddress({ hash: toHex(digest), signature: toHex(signature) }), coSigner);
        } catch {
          return false;
        }
      },
    };
    const session = DkgSession.open({
      party: DKG_DEVICE,
      params: { context: hexToBytes(context), threshold: DKG_THRESHOLD, participants: [DKG_DEVICE, DKG_SERVER] },
      // The service is known by the address its accounts name on-chain; this device by the per-run key the
      // assertion below authorises. Both are bound into the transcript.
      identities: new Map([[DKG_DEVICE, device.publicKey], [DKG_SERVER, hexToBytes(coSigner)]]),
      auth,
    });
    const round1 = await session.broadcast();

    const issuedAt = o.issuedAt ?? Math.floor(Date.now() / 1000);
    const passkey = { x: o.passkey.x, y: o.passkey.y, verifiers: o.passkey.verifiers };
    const start = await this.call<DkgStartResult>('POST', '/v1/frost/dkg/start', {
      chainId: this.o.chainId, passkey: { x: passkey.x.toString(), y: passkey.y.toString(), verifiers: passkey.verifiers.toString() },
      deviceKey, context, issuedAt, round1,
      passkeySignature: encodeWebAuthnSignature(await o.sign(hexToBytes(dkgStartChallenge({
        chainId: this.o.chainId, coSigner, passkey, deviceKey, context, issuedAt,
      })))),
    });
    if (getAddress(start.coSigner) !== coSigner) throw new Error('the co-signer answered for another address');

    const ours = await session.round2([start.round1 as DkgWireMessage]);
    const round2 = await this.call<DkgRound2Result>('POST', '/v1/frost/dkg/round2', {
      chainId: this.o.chainId, sessionId: start.sessionId, message: ours[0]!,
    });
    const { result, confirmation } = await session.finish([round2.message as DkgWireMessage]);
    // The service's own view of the key, signed: a mismatch aborts here, before anything is sealed or enrolled.
    await session.confirm([round2.confirmation as DkgWireMessage]);

    const groupKey = toHex(result.publicKeys.groupPublicKey.toBytes(true));
    const transcript = `0x${result.publicKeys.transcript}` as Hex;
    const done = await this.call<DkgConfirmResult>('POST', '/v1/frost/dkg/confirm', {
      chainId: this.o.chainId, sessionId: start.sessionId, confirmation,
      passkeySignature: encodeWebAuthnSignature(await o.sign(hexToBytes(dkgConfirmChallenge({
        chainId: this.o.chainId, coSigner, session: start.sessionId, groupKey, transcript,
      })))),
    });
    if (done.groupKey.toLowerCase() !== groupKey.toLowerCase() || done.transcript.toLowerCase() !== transcript.toLowerCase()) {
      throw new Error('the co-signer confirmed a different group key: do not use this key');
    }
    for (const { id, point } of done.verificationShares) {
      const own = result.publicKeys.verificationShares.get(id);
      if (!own || toHex(own.toBytes(true)).toLowerCase() !== point.toLowerCase()) {
        throw new Error(`the co-signer reported a different verification share for participant ${id}`);
      }
    }
    return {
      keyShare: result.keyShare, groupKey, transcript, sessionId: start.sessionId,
      accountRef: getAddress(done.accountRef), verificationShares: new Map(result.publicKeys.verificationShares),
    };
  }

  /* ------------------------------------------------------------------ executor wiring */

  /** A Safe 2-of-2 (passkey signer + this co-signer). */
  safe(a: { safe: Address; passkeySigner: Address; coSigner: Address }): RemoteSafeCoSigner {
    return new RemoteSafeCoSigner(this, { safe: getAddress(a.safe), passkeySigner: getAddress(a.passkeySigner), coSigner: getAddress(a.coSigner) });
  }

  /** A Kernel account whose root validator is PasskeyCoSignerValidator. */
  kernel(a: { account: Address; validator: Address; coSigner: Address }): RemoteKernelCoSigner {
    return new RemoteKernelCoSigner(this, { account: getAddress(a.account), validator: getAddress(a.validator), coSigner: getAddress(a.coSigner) });
  }

  /** A Safe whose only owner is a FrostSigner over a device + server group. */
  frostSafe(a: { safe: Address; frostSigner: Address; device: KeyShare; passkey: PasskeySign }): RemoteFrostCoSigner {
    return new RemoteFrostCoSigner(this, 'safe', getAddress(a.safe), getAddress(a.frostSigner), a.device, a.passkey);
  }

  /** A Kernel account whose root validator is FrostValidator. */
  frostKernel(a: { account: Address; validator: Address; device: KeyShare; passkey: PasskeySign }): RemoteFrostCoSigner {
    return new RemoteFrostCoSigner(this, 'kernel', getAddress(a.account), getAddress(a.validator), a.device, a.passkey);
  }
}

function wrapExecutor(inner: AccountExecutor, signTypedData: (typedData: TypedDataDefinition) => Promise<Hex>): AccountExecutor {
  return {
    address: inner.address, kind: inner.kind,
    execute: (calls) => inner.execute(calls),
    signTypedData,
  };
}

export class RemoteSafeCoSigner {
  /** The co-signer as a Safe owner. Its "signature" is a placeholder the submitter replaces. */
  readonly owner: SafeOwner;

  constructor(private readonly remote: RemoteCoSigner, private readonly a: { safe: Address; passkeySigner: Address; coSigner: Address }) {
    this.owner = { address: a.coSigner, kind: 'eoa', signHash: async (digest) => placeholderSignature(digest) };
  }

  private passkeyHalf(signature: Hex, header: 0 | 12): Hex {
    const entry = splitSafeSignature(signature, header).entries.find((e) => e.kind === 'contract' && same(e.owner, this.a.passkeySigner));
    if (!entry) throw new Error('the Safe signature carries no signature from the passkey owner');
    return entry.signature;
  }

  submitter(inner: UserOpSubmitter): UserOpSubmitter {
    return {
      // The bundler's minimum priority fee reaches the executor through the wrapper (wallet fees.ts, SRM1-5).
      minPriorityFeePerGas: async () => inner.minPriorityFeePerGas?.(),
      submit: async (op: PackedUserOperation): Promise<Executed> => {
        if (size(op.signature) < 12 + 65) return inner.submit(op);
        const unsigned = unsignedOf(op);
        const window: ValidityWindow = { validAfter: Number(BigInt(slice(op.signature, 0, 6))), validUntil: Number(BigInt(slice(op.signature, 6, 12))) };
        const digest = safeOperationDigest(unsigned, window, this.remote.chainId);
        const placeholder = placeholderSignature(digest);
        if (!containsPlaceholder(op.signature, placeholder)) return inner.submit(op);
        const payload: WireSigning = {
          kind: 'safe-operation', account: this.a.safe, userOp: userOpToWire(unsigned), ...window, passkeySignature: this.passkeyHalf(op.signature, 12),
        };
        const r = isVetoOperation(op.callData, 'safe') ? await this.remote.veto(payload) : await this.remote.cosign(payload);
        await expectCoSignature(digest, r.coSignature, this.a.coSigner);
        return inner.submit({ ...op, signature: spliceSignature(op.signature, placeholder, r.coSignature) });
      },
    };
  }

  /** ERC-1271 through the Safe's owners: the executor's signature, completed by the service. */
  async signTypedData(executor: Pick<AccountExecutor, 'signTypedData'>, typedData: TypedDataDefinition): Promise<Hex> {
    const signature = await executor.signTypedData(typedData);
    const digest = safeMessageHash(this.a.safe, this.remote.chainId, hashTypedData(typedData));
    const placeholder = placeholderSignature(digest);
    if (!containsPlaceholder(signature, placeholder)) return signature;
    const r = await this.remote.cosign({ kind: 'safe-message', account: this.a.safe, typedData: jsonSafe(typedData), passkeySignature: this.passkeyHalf(signature, 0) });
    await expectCoSignature(digest, r.coSignature, this.a.coSigner);
    return spliceSignature(signature, placeholder, r.coSignature);
  }

  wrap(executor: AccountExecutor): AccountExecutor {
    return wrapExecutor(executor, (td) => this.signTypedData(executor, td));
  }
}

export class RemoteKernelCoSigner {
  /** The `coSigner` callback of `passkeyCoSignerSigner`: a placeholder the submitter replaces. */
  readonly coSign: (digest: Hex) => Promise<Hex>;

  constructor(private readonly remote: RemoteCoSigner, private readonly a: { account: Address; validator: Address; coSigner: Address }) {
    this.coSign = async (digest) => placeholderSignature(digest);
  }

  submitter(inner: UserOpSubmitter): UserOpSubmitter {
    return {
      // The bundler's minimum priority fee reaches the executor through the wrapper (wallet fees.ts, SRM1-5).
      minPriorityFeePerGas: async () => inner.minPriorityFeePerGas?.(),
      submit: async (op: PackedUserOperation): Promise<Executed> => {
        let parts: { validAfter: number; validUntil: number; passkeySignature: Hex; coSignerSignature: Hex };
        try {
          const { validAfter, validUntil, body } = decodeKernelUserOpSignature(op.signature);
          parts = { validAfter, validUntil, ...decodePasskeyCoSignerSignature(body) };
        } catch {
          return inner.submit(op);
        }
        const unsigned = unsignedOf(op);
        const window = { validAfter: parts.validAfter, validUntil: parts.validUntil };
        const digest = kernelOperationDigest(unsigned, window, this.remote.chainId, this.a.validator);
        if (parts.coSignerSignature.toLowerCase() !== placeholderSignature(digest).toLowerCase()) return inner.submit(op);
        const payload: WireSigning = { kind: 'kernel-operation', account: this.a.account, userOp: userOpToWire(unsigned), ...window, passkeySignature: parts.passkeySignature };
        const r = isVetoOperation(op.callData, 'kernel') ? await this.remote.veto(payload) : await this.remote.cosign(payload);
        await expectCoSignature(digest, r.coSignature, this.a.coSigner);
        return inner.submit({ ...op, signature: encodeKernelUserOpSignature(window.validAfter, window.validUntil, encodePasskeyCoSignerSignature(parts.passkeySignature, r.coSignature)) });
      },
    };
  }

  async signTypedData(executor: Pick<AccountExecutor, 'signTypedData'>, typedData: TypedDataDefinition): Promise<Hex> {
    const signature = await executor.signTypedData(typedData);
    const digest = kernelWrappedHash(this.a.account, this.remote.chainId, hashTypedData(typedData));
    const placeholder = placeholderSignature(digest);
    if (!containsPlaceholder(signature, placeholder)) return signature;
    const erc1271 = isErc6492Signature(signature) ? parseErc6492Signature(signature).signature : signature;
    if (!erc1271.toLowerCase().startsWith('0x00')) throw new Error('only the root validator route (0x00) is co-signed');
    const { passkeySignature } = decodePasskeyCoSignerSignature(slice(erc1271, 1));
    const r = await this.remote.cosign({ kind: 'kernel-message', account: this.a.account, typedData: jsonSafe(typedData), passkeySignature });
    await expectCoSignature(digest, r.coSignature, this.a.coSigner);
    return spliceSignature(signature, placeholder, r.coSignature);
  }

  wrap(executor: AccountExecutor): AccountExecutor {
    return wrapExecutor(executor, (td) => this.signTypedData(executor, td));
  }
}

const FROST_SIG_BYTES = 96;
const pointHex = (p: { toBytes(compressed?: boolean): Uint8Array }) => toHex(p.toBytes(true));

export class RemoteFrostCoSigner {
  /** Safe: the FrostSigner owner. */
  readonly owner: SafeOwner;
  /** Kernel: the FrostValidator signer. */
  readonly signer: KernelValidatorSigner;

  constructor(
    private readonly remote: RemoteCoSigner,
    private readonly family: 'safe' | 'kernel',
    private readonly account: Address,
    /** FrostSigner (Safe) or FrostValidator (Kernel). */
    private readonly signerAddress: Address,
    private readonly device: KeyShare,
    private readonly passkey: PasskeySign,
  ) {
    this.owner = { address: signerAddress, kind: 'contract', signHash: async (digest) => placeholderSignature(digest, FROST_SIG_BYTES) };
    this.signer = { validator: signerAddress, sign: async (challenge) => placeholderSignature(challenge, FROST_SIG_BYTES) };
  }

  /** One two-party session over `digest`: device commits, server commits, passkey signs, both sign, aggregate, verify. */
  async session(digest: Hex, payload: WireSigning, route: 'cosign' | 'veto'): Promise<Signature> {
    const msg = hexToBytes(digest);
    const { nonces, commitment } = commit(this.device);
    const server = await this.remote.frostCommit(this.account);
    const serverCommitment: Commitment = {
      id: server.commitment.id, hiding: Point.fromBytes(hexToBytes(server.commitment.hiding)), binding: Point.fromBytes(hexToBytes(server.commitment.binding)),
    };
    const commitments = [commitment, serverCommitment];
    const assertion = await this.passkey(msg);
    const r = await this.remote.frostSign({
      ...payload, passkeySignature: encodeWebAuthnSignature(assertion), sessionId: server.sessionId, route,
      commitments: commitments.map((c) => ({ id: c.id, hiding: pointHex(c.hiding), binding: pointHex(c.binding) })),
    });
    if (r.digest.toLowerCase() !== digest.toLowerCase()) throw new Error('the co-signer signed a different digest');
    const own = sign(this.device, nonces, commitments, msg);
    const signature = aggregate(commitments, [own, { id: r.share.id, z: BigInt(r.share.z) }], msg, this.device.groupPublicKey);
    if (!verify(signature, msg, this.device.groupPublicKey)) throw new Error('the aggregate FROST signature does not verify: the co-signer\'s share is invalid');
    return signature;
  }

  submitter(inner: UserOpSubmitter): UserOpSubmitter {
    return {
      // The bundler's minimum priority fee reaches the executor through the wrapper (wallet fees.ts, SRM1-5).
      minPriorityFeePerGas: async () => inner.minPriorityFeePerGas?.(),
      submit: async (op: PackedUserOperation): Promise<Executed> => {
        if (size(op.signature) < 12 + FROST_SIG_BYTES) return inner.submit(op);
        const unsigned = unsignedOf(op);
        const window = { validAfter: Number(BigInt(slice(op.signature, 0, 6))), validUntil: Number(BigInt(slice(op.signature, 6, 12))) };
        const digest = this.family === 'safe'
          ? safeOperationDigest(unsigned, window, this.remote.chainId)
          : kernelOperationDigest(unsigned, window, this.remote.chainId, this.signerAddress);
        const placeholder = placeholderSignature(digest, FROST_SIG_BYTES);
        if (!containsPlaceholder(op.signature, placeholder)) return inner.submit(op);
        const payload: WireSigning = { kind: this.family === 'safe' ? 'safe-operation' : 'kernel-operation', account: this.account, userOp: userOpToWire(unsigned), ...window, passkeySignature: '0x' };
        const route = isVetoOperation(op.callData, this.family) ? 'veto' : 'cosign';
        const signature = encodeFrostSignature(await this.session(digest, payload, route));
        return inner.submit({ ...op, signature: spliceSignature(op.signature, placeholder, signature) });
      },
    };
  }

  async signTypedData(executor: Pick<AccountExecutor, 'signTypedData'>, typedData: TypedDataDefinition): Promise<Hex> {
    const signature = await executor.signTypedData(typedData);
    const hash = hashTypedData(typedData);
    const digest = this.family === 'safe' ? safeMessageHash(this.account, this.remote.chainId, hash) : kernelWrappedHash(this.account, this.remote.chainId, hash);
    const placeholder = placeholderSignature(digest, FROST_SIG_BYTES);
    if (!containsPlaceholder(signature, placeholder)) return signature;
    const payload: WireSigning = { kind: this.family === 'safe' ? 'safe-message' : 'kernel-message', account: this.account, typedData: jsonSafe(typedData), passkeySignature: '0x' };
    return spliceSignature(signature, placeholder, encodeFrostSignature(await this.session(digest, payload, 'cosign')));
  }

  wrap(executor: AccountExecutor): AccountExecutor {
    return wrapExecutor(executor, (td) => this.signTypedData(executor, td));
  }
}

/** The ABI for a veto call, re-exported so a wallet builds `setTxNonce` without the recovery helpers. */
export const VETO_ABI = parseAbi(['function setTxNonce(uint256 nonce)']);
export const decodeVeto = (data: Hex): bigint => decodeFunctionData({ abi: VETO_ABI, data }).args[0];

/* ------------------------------------------------------------------ recovery alerts in the browser */

/** The part of a `ServiceWorkerRegistration` the helpers use. */
export interface PushRegistrationLike {
  pushManager: {
    getSubscription(): Promise<PushSubscriptionLike | null>;
    subscribe(options: { userVisibleOnly: boolean; applicationServerKey: Uint8Array }): Promise<PushSubscriptionLike>;
  };
}

/** The part of a `PushSubscription` the helpers use. */
export interface PushSubscriptionLike {
  readonly endpoint: string;
  readonly options?: { applicationServerKey?: ArrayBuffer | null };
  toJSON(): { endpoint?: string; keys?: Record<string, string> };
  unsubscribe(): Promise<boolean>;
}

/** base64url (or base64) to bytes, without Buffer. */
export function base64UrlToBytes(value: string): Uint8Array {
  const s = canonicalB64url(value).replace(/-/g, '+').replace(/_/g, '/');
  const binary = atob(s + '='.repeat((4 - (s.length % 4)) % 4));
  return Uint8Array.from(binary, (c) => c.charCodeAt(0));
}

const sameBytes = (a: Uint8Array, b: Uint8Array) => a.length === b.length && a.every((x, i) => x === b[i]);

/**
 * Subscribe this browser to an account's recovery alerts: the service worker's push subscription for the co-signer's
 * VAPID key (an existing subscription for another key is replaced), registered with the co-signer under a fresh
 * passkey assertion. Call it from a user gesture: the browser asks for notification permission.
 */
export async function subscribeRecoveryAlerts(registration: PushRegistrationLike, o: {
  cosigner: RemoteCoSigner;
  account: Address;
  /** The co-signer's address, as pinned from `info()`. */
  coSigner: Address;
  sign: PasskeySign;
  /** Default: from the co-signer's `info()`. */
  vapidPublicKey?: string;
}): Promise<{ endpoint: string; created: boolean; pending: number }> {
  const vapid = o.vapidPublicKey ?? (await o.cosigner.info()).alerts?.vapidPublicKey;
  if (!vapid) throw new Error('this co-signer does not send recovery alerts');
  const applicationServerKey = base64UrlToBytes(vapid);
  let subscription = await registration.pushManager.getSubscription();
  const current = subscription?.options?.applicationServerKey;
  if (subscription && current && !sameBytes(new Uint8Array(current), applicationServerKey)) {
    await subscription.unsubscribe();
    subscription = null;
  }
  subscription ??= await registration.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey });
  const keys = subscription.toJSON().keys ?? {};
  if (!keys.p256dh || !keys.auth) throw new Error('the push subscription carries no encryption keys');
  const r = await o.cosigner.subscribeAlerts({ account: o.account, coSigner: o.coSigner, subscription: { endpoint: subscription.endpoint, keys: { p256dh: keys.p256dh, auth: keys.auth } }, sign: o.sign });
  return { endpoint: subscription.endpoint, created: r.created, pending: r.pending };
}

/**
 * Stop an account's recovery alerts on this browser. The co-signer refuses while a recovery is queued
 * (`CoSignerRefused` with code `recovery_pending`). The browser's push subscription is kept unless
 * `dropBrowserSubscription`: it may serve other accounts.
 */
export async function unsubscribeRecoveryAlerts(registration: PushRegistrationLike, o: {
  cosigner: RemoteCoSigner;
  account: Address;
  coSigner: Address;
  sign: PasskeySign;
  dropBrowserSubscription?: boolean;
}): Promise<boolean> {
  const subscription = await registration.pushManager.getSubscription();
  if (!subscription) return false;
  await o.cosigner.unsubscribeAlerts({ account: o.account, coSigner: o.coSigner, endpoint: subscription.endpoint, sign: o.sign });
  if (o.dropBrowserSubscription) await subscription.unsubscribe();
  return true;
}

/** The part of a `PushEvent` the handler uses. */
export interface PushEventLike {
  readonly data?: { json(): unknown } | null;
  waitUntil(promise: Promise<unknown>): void;
}

export interface NotificationRegistrationLike {
  showNotification(title: string, options?: Record<string, unknown>): Promise<void>;
}

export function isRecoveryAlertPayload(v: unknown): v is RecoveryAlertPayload {
  const p = v as Partial<RecoveryAlertPayload> | null;
  return !!p && typeof p === 'object' && p.v === 1 && (p.type === 'mova.recovery-requested' || p.type === 'mova.alerts-off')
    && typeof p.title === 'string' && typeof p.body === 'string' && typeof p.tag === 'string'
    && (p.executableAt === undefined || Number.isSafeInteger(p.executableAt));
}

/**
 * In the service worker's `push` listener: shows a recovery alert and returns true, or returns false for any other
 * message so the app's own handler can take it.
 *
 *   self.addEventListener('push', (event) => { if (!handleRecoveryPush(event)) { ... } });
 */
export function handleRecoveryPush(event: PushEventLike, o: { registration?: NotificationRegistrationLike; url?: string; locale?: string; timeZone?: string } = {}): boolean {
  let payload: unknown;
  try {
    payload = event.data?.json();
  } catch {
    return false;
  }
  if (!isRecoveryAlertPayload(payload)) return false;
  const registration = o.registration ?? (globalThis as { registration?: NotificationRegistrationLike }).registration;
  if (!registration) return false;
  let body = payload.body;
  if (payload.type === 'mova.recovery-requested') {
    body = payload.executableAt
      ? `${payload.body}. Se não foi você, abra o app e vete antes de ${new Intl.DateTimeFormat(o.locale ?? 'pt-BR', { dateStyle: 'short', timeStyle: 'short', timeZone: o.timeZone }).format(new Date(payload.executableAt * 1000))}.`
      : `${payload.body}. Se não foi você, abra o app e vete.`;
  }
  event.waitUntil(registration.showNotification(payload.title || RECOVERY_ALERT_TEXT.title, {
    body, tag: payload.tag, renotify: true, requireInteraction: payload.type === 'mova.recovery-requested',
    data: { url: o.url ?? '/', type: payload.type, kind: payload.kind, executableAt: payload.executableAt },
  }));
  return true;
}

/** The part of `Clients` the click handler uses. */
export interface ClientsLike {
  matchAll(options: { type: 'window'; includeUncontrolled: boolean }): Promise<readonly { url: string; focus?(): Promise<unknown> }[]>;
  openWindow(url: string): Promise<unknown>;
}

/** In the `notificationclick` listener: focuses an open app window or opens one. False for other notifications. */
export function handleRecoveryNotificationClick(
  event: { notification: { data?: unknown; close(): void }; waitUntil(promise: Promise<unknown>): void },
  o: { clients?: ClientsLike } = {},
): boolean {
  const data = event.notification.data as { type?: string; url?: string } | undefined;
  if (data?.type !== 'mova.recovery-requested' && data?.type !== 'mova.alerts-off') return false;
  event.notification.close();
  const clients = o.clients ?? (globalThis as { clients?: ClientsLike }).clients;
  if (!clients) return true;
  const url = data.url ?? '/';
  event.waitUntil((async () => {
    const open = await clients.matchAll({ type: 'window', includeUncontrolled: true });
    const focusable = open.find((c) => typeof c.focus === 'function');
    if (focusable) await focusable.focus!();
    else await clients.openWindow(url);
  })());
  return true;
}
