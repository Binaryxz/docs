/**
 * The co-signer's HTTP surface (node:http).
 *
 * Two listeners, as for the attestor and the LP node:
 *
 *  - **ops** - `GET /healthz` (the process is alive), `/readyz` (503 until the startup checks passed),
 *    `/status`, `/metrics` (Prometheus). Keep it private.
 *  - **api** - behind TLS:
 *      GET  /v1/info             the co-signer's address, chain, deployment, policy and limits
 *      POST /v1/enrol            bind an account to the passkey it trusts (proof: a passkey assertion)
 *      POST /v1/cosign           co-sign a UserOperation or an ERC-1271 message (the passkey's half included)
 *      POST /v1/veto             co-sign `setTxNonce` over a queued recovery (the passkey's half included)
 *      GET  /v1/queue            ?chainId=&account= : the account's recovery queue, for the wallet to show
 *      POST /v1/frost/commit     round one of a two-party FROST session
 *      POST /v1/frost/sign       round two, with the passkey's signature over the same digest
 *      POST /v1/frost/dkg/start    round one of a distributed key generation (proof: a passkey assertion)
 *      POST /v1/frost/dkg/round2   round two: the device's sealed share in, the service's out
 *      POST /v1/frost/dkg/confirm  round three: the device confirms the key, and the share becomes usable
 *      GET  /v1/sponsorship      ?chainId=&account= : the enrolled account's sponsorship (when the module runs)
 *      POST /v1/alerts/subscribe    a push subscription for an account's recovery alerts (proof: a fresh passkey assertion)
 *      POST /v1/alerts/unsubscribe  remove one (the same proof; refused while a recovery is queued)
 *
 * Request authentication is two layers. Every signing and enrolment request authenticates the USER by a
 * passkey signature (service.ts); nothing else can make this service sign. On top, `Authorization: Bearer`
 * API keys name the CLIENT (the app, a backend) and gate every /v1 route; they are compared as SHA-256
 * digests in constant time and never logged. A per-client-address token bucket runs before a body is read,
 * so a flood costs neither P-256 verifications nor audit-log writes. Bodies are capped (64 KiB), must be JSON,
 * and every response is redacted against the configured secrets. No response carries key material: the
 * co-signature is the only signature the service returns, and it is useless without the passkey's.
 */
import { createHash, timingSafeEqual } from 'node:crypto';
import { createServer, type IncomingMessage, type Server, type ServerResponse } from 'node:http';
import { redact } from '@mova/ops/redact';
import { parseDkgConfirmRequest, parseDkgRound2Request, parseDkgStartRequest } from './dkg.js';
import { parseEnrolRequest } from './enrolment.js';
import { parseAlertSubscribeRequest, parseAlertUnsubscribeRequest } from './recovery-alerts.js';
import { RateLimiter } from './rate-limit.js';
import { Refusal } from './refusal.js';
import {
  parseAccountRequest, parseFrostSignRequest, parseSigningPayload,
  type Caller, type CoSignerService, type Logger,
} from './service.js';

export interface ApiKey {
  /** Shown in the audit log as the client. */
  name: string;
  token: string;
}

export interface ServeCoSignerOptions {
  mode: 'api' | 'ops' | 'both';
  apiKeys?: readonly ApiKey[];
  /** No API key required (the passkey signature still is). Refused by the entrypoint in production unless explicit. */
  publicApi?: boolean;
  maxBodyBytes?: number;
  redactValues?: readonly (string | undefined)[];
  /** Origins a browser wallet calls from. None: no CORS headers. */
  corsOrigins?: readonly string[];
  clientRateLimit?: { burst: number; perMinute: number };
  /** Take the client address from X-Forwarded-For (behind your own proxy only). */
  trustProxy?: boolean;
  log?: Logger;
}

export const DEFAULT_MAX_BODY_BYTES = 64 * 1024;
export const MIN_API_KEY_LENGTH = 32;

export const toJson = (value: unknown): string => JSON.stringify(value, (_k, v) => (typeof v === 'bigint' ? v.toString() : v));

const sha256 = (s: string) => createHash('sha256').update(s, 'utf8').digest();

export function serveCoSigner(service: CoSignerService, o: ServeCoSignerOptions): {
  server: Server;
  listen: (port?: number, host?: string) => Promise<number>;
  close: () => Promise<void>;
} {
  const ops = o.mode !== 'api';
  const api = o.mode !== 'ops';
  const keys = (o.apiKeys ?? []).map((k) => ({ name: k.name, hash: sha256(k.token) }));
  const clientLimiter = new RateLimiter({ ...(o.clientRateLimit ?? { burst: 60, perMinute: 600 }), maxKeys: 20_000 });
  const maxBody = o.maxBodyBytes ?? DEFAULT_MAX_BODY_BYTES;

  const authenticate = (rq: IncomingMessage): Caller => {
    const header = rq.headers.authorization;
    if (header === undefined && o.publicApi) return { client: 'anonymous' };
    const m = /^Bearer ([\x21-\x7e]{16,512})$/.exec(header ?? '');
    if (m) {
      const h = sha256(m[1]!);
      for (const k of keys) if (timingSafeEqual(h, k.hash)) return { client: k.name };
    }
    throw new Refusal('unauthorized', 'a valid API key is required (Authorization: Bearer ...)');
  };

  const clientAddress = (rq: IncomingMessage): string => {
    const forwarded = rq.headers['x-forwarded-for'];
    if (o.trustProxy && typeof forwarded === 'string' && forwarded.trim()) return forwarded.split(',')[0]!.trim();
    return rq.socket.remoteAddress ?? 'unknown';
  };

  const readJson = async (rq: IncomingMessage): Promise<unknown> => {
    const type = rq.headers['content-type'] ?? '';
    if (!/^application\/json\b/i.test(type)) throw new Refusal('unsupported_media_type', 'the body must be application/json');
    const declared = Number(rq.headers['content-length'] ?? NaN);
    if (Number.isFinite(declared) && declared > maxBody) throw new Refusal('body_too_large', `the body is limited to ${maxBody} bytes`);
    const chunks: Buffer[] = [];
    let total = 0;
    for await (const c of rq) {
      total += (c as Buffer).length;
      if (total > maxBody) throw new Refusal('body_too_large', `the body is limited to ${maxBody} bytes`);
      chunks.push(c as Buffer);
    }
    try {
      return JSON.parse(Buffer.concat(chunks).toString('utf8'));
    } catch {
      throw new Refusal('malformed', 'the body is not JSON');
    }
  };

  const handle = async (rq: IncomingMessage, rs: ServerResponse): Promise<void> => {
    const url = new URL(rq.url ?? '/', 'http://localhost');
    const origin = typeof rq.headers.origin === 'string' ? rq.headers.origin : undefined;
    const cors: Record<string, string> = origin && o.corsOrigins?.includes(origin)
      ? { 'access-control-allow-origin': origin, vary: 'Origin', 'access-control-allow-headers': 'authorization, content-type', 'access-control-allow-methods': 'GET, POST', 'access-control-max-age': '600' }
      : {};
    let inService = false;
    let bodyUnread = false;
    const send = (code: number, value: unknown) => {
      const headers: Record<string, string> = { 'content-type': 'application/json', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff', ...cors };
      if (bodyUnread) headers.connection = 'close';
      rs.writeHead(code, headers);
      rs.end(redact(toJson(value), o.redactValues));
    };
    try {
      if (rq.method === 'GET' && url.pathname === '/healthz') return send(200, { ok: true });
      if (rq.method === 'GET' && url.pathname === '/readyz') return send(service.ready ? 200 : 503, { ready: service.ready });
      if (ops && rq.method === 'GET' && url.pathname === '/metrics') {
        rs.writeHead(200, { 'content-type': 'text/plain; version=0.0.4; charset=utf-8' });
        rs.end(redact(service.metrics.render(), o.redactValues));
        return;
      }
      if (ops && rq.method === 'GET' && url.pathname === '/status') return send(service.ready ? 200 : 503, service.status());

      if (api && url.pathname.startsWith('/v1/')) {
        if (rq.method === 'OPTIONS') {
          rs.writeHead(cors['access-control-allow-origin'] ? 204 : 403, cors);
          rs.end();
          return;
        }
        bodyUnread = rq.method === 'POST';
        if (!clientLimiter.take(clientAddress(rq))) throw new Refusal('rate_limited', 'too many requests from this client');
        const caller = authenticate(rq);
        if (rq.method === 'GET' && url.pathname === '/v1/info') return send(200, service.info());
        if (rq.method === 'GET' && url.pathname === '/v1/queue') {
          const q = parseAccountRequest(Object.fromEntries(url.searchParams));
          inService = true;
          return send(200, await service.queue(q, caller));
        }
        if (rq.method === 'GET' && url.pathname === '/v1/sponsorship') {
          const q = parseAccountRequest(Object.fromEntries(url.searchParams));
          inService = true;
          return send(200, await service.sponsorship(q, caller));
        }
        if (rq.method === 'POST') {
          const route = url.pathname;
          if (!['/v1/enrol', '/v1/cosign', '/v1/veto', '/v1/frost/commit', '/v1/frost/sign',
            '/v1/frost/dkg/start', '/v1/frost/dkg/round2', '/v1/frost/dkg/confirm',
            '/v1/alerts/subscribe', '/v1/alerts/unsubscribe'].includes(route)) return send(404, { error: 'not_found' });
          const body = await readJson(rq);
          bodyUnread = false;
          switch (route) {
            case '/v1/enrol': { const r = parseEnrolRequest(body); inService = true; return send(200, await service.enrol(r, caller)); }
            case '/v1/cosign': { const r = parseSigningPayload(body); inService = true; return send(200, await service.cosign(r, caller)); }
            case '/v1/veto': { const r = parseSigningPayload(body); inService = true; return send(200, await service.veto(r, caller)); }
            case '/v1/frost/commit': { const r = parseAccountRequest(body); inService = true; return send(200, await service.frostCommit(r, caller)); }
            case '/v1/frost/sign': { const r = parseFrostSignRequest(body); inService = true; return send(200, await service.frostSign(r, caller)); }
            case '/v1/frost/dkg/start': { const r = parseDkgStartRequest(body); inService = true; return send(200, await service.dkgStart(r, caller)); }
            case '/v1/frost/dkg/round2': { const r = parseDkgRound2Request(body); inService = true; return send(200, await service.dkgRound2(r, caller)); }
            case '/v1/frost/dkg/confirm': { const r = parseDkgConfirmRequest(body); inService = true; return send(200, await service.dkgConfirm(r, caller)); }
            case '/v1/alerts/subscribe': { const r = parseAlertSubscribeRequest(body); inService = true; return send(200, await service.subscribeAlerts(r, caller)); }
            case '/v1/alerts/unsubscribe': { const r = parseAlertUnsubscribeRequest(body); inService = true; return send(200, await service.unsubscribeAlerts(r, caller)); }
          }
        }
      }
      const routes = ['GET /healthz', 'GET /readyz', ...(ops ? ['GET /status', 'GET /metrics'] : []),
        ...(api ? ['GET /v1/info', 'POST /v1/enrol', 'POST /v1/cosign', 'POST /v1/veto', 'GET /v1/queue', 'POST /v1/frost/commit', 'POST /v1/frost/sign',
          'POST /v1/frost/dkg/start', 'POST /v1/frost/dkg/round2', 'POST /v1/frost/dkg/confirm',
          'GET /v1/sponsorship', 'POST /v1/alerts/subscribe', 'POST /v1/alerts/unsubscribe'] : [])];
      return send(404, { error: 'not_found', routes });
    } catch (e) {
      if (e instanceof Refusal) {
        // The service counts what it refuses; what was refused before reaching it is counted here.
        if (!inService) {
          service.metrics.inc('mova_cosigner_refusals_total', { code: e.code });
          service.metrics.inc('mova_cosigner_requests_total', { route: url.pathname.replace(/^\/v1\//, '').replace(/[^a-z/-]/g, '').replace(/\//g, '-') || 'unknown', result: 'refused' });
        }
        send(e.status, { error: e.code, message: e.message });
      } else {
        o.log?.error(`http: ${redact(e instanceof Error ? e.message : String(e), o.redactValues)}`);
        try {
          send(500, { error: 'internal', message: 'internal error' });
        } catch {
          rs.destroy();
        }
      }
      if (bodyUnread) rs.once('finish', () => rq.destroy());
    }
  };

  const server = createServer((rq, rs) => void handle(rq, rs));
  server.headersTimeout = 10_000;
  server.requestTimeout = 30_000;
  return {
    server,
    listen: (port = 0, host = '127.0.0.1') => new Promise<number>((resolve, reject) => {
      server.once('error', reject);
      server.listen(port, host, () => {
        const a = server.address();
        resolve(typeof a === 'object' && a ? a.port : port);
      });
    }),
    close: () => new Promise<void>((resolve) => {
      server.close(() => resolve());
      server.closeAllConnections();
    }),
  };
}
