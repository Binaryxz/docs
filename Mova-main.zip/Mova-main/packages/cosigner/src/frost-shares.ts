/**
 * The server's FROST shares, for accounts whose owner is a FrostSigner (Safe) or whose root validator is a
 * FrostValidator (Kernel): one share of a 2-of-2 group per account, from the DKG in packages/mpc.
 *
 * A share alone signs nothing and reveals nothing about the group secret (docs/wallet-custody.md §5), but a
 * share plus the device's opened share is the account. So the same custody rule as the ECDSA key applies:
 * the file store is for development and refuses production mode unless allowed explicitly. In production,
 * implement `FrostShareStore` over envelope encryption (a KMS data key per share) - a KMS cannot run FROST
 * itself.
 *
 * WRITING. Shares used to arrive only by being put in the file by hand, from a DKG run elsewhere. Now
 * `dkg.ts` runs the DKG with the device over HTTP and stores its half here, so the store has a write half
 * (`FrostShareWriter`) and every record carries what the DKG bound it to:
 *
 *   accountRef    the account the DKG was run for. A FROST account has no address until the group key
 *                 exists - the address commits to the key - so the DKG is keyed by the one identifier that
 *                 exists beforehand: `chainId:passkeySigner`, the account's future recovery signer
 *   transcript    the DKG transcript both parties derived and the device's passkey signed, so the record says
 *                 WHICH run made it, and an auditor can line it up against the device's own record
 *   complete      false until the device confirmed the same group key and transcript. `shareFor` returns
 *                 only complete shares, so a DKG that stopped halfway leaves a share that cannot sign
 *
 * File format: JSON array of { "id": 2, "share": "0x<32 bytes>", "groupPublicKey": "0x<33 bytes compressed>",
 * "verificationShare": "0x<33 bytes compressed>", "accountRef": "31337:0x..", "transcript": "<64 hex>",
 * "createdAt": 1750000000, "complete": true }. The last four are optional: an entry without them is a share
 * placed by hand, complete and bound to no account. The verification share is checked against the share on
 * load, so a truncated or mismatched entry refuses to start instead of producing invalid signature shares.
 */
import { chmodSync, readFileSync, renameSync, statSync, writeFileSync } from 'node:fs';
import { Point, publicShareOf, type KeyShare, type PointT } from '@mova/mpc';
import { hexToBytes, isHex, toHex, type Hex } from 'viem';
import { KeyCustodyError } from './key.js';

/** One stored share, with what the DKG bound it to. */
export interface FrostShareRecord {
  readonly share: KeyShare;
  /** `chainId:passkeySigner`, lower-case; undefined for a share placed in the file by hand. */
  readonly accountRef?: string;
  /** The DKG transcript of the run that produced it, hex without `0x`. */
  readonly transcript?: string;
  /** Unix seconds. */
  readonly createdAt?: number;
  /** False while the device has not confirmed the group key: such a share never signs. */
  readonly complete: boolean;
}

export interface FrostShareStore {
  readonly custody: string;
  /** The share of `groupPublicKey`, if this service holds one AND its DKG completed. */
  shareFor(groupPublicKey: PointT): KeyShare | undefined;
}

/**
 * A store the DKG can write to. `fileFrostShares` and `memoryFrostShares` are both writers; a KMS-backed
 * store need not be, and then the service simply does not offer the DKG routes.
 */
export interface FrostShareWriter extends FrostShareStore {
  /** Record a share the DKG just produced, not yet confirmed by the device. Replaces a pending one. */
  putPending(record: Omit<FrostShareRecord, 'complete'>): void;
  /** Mark a pending share complete. Throws if there is none. */
  complete(groupPublicKey: PointT): FrostShareRecord;
  /** Drop a pending share; a complete one is never dropped. */
  discardPending(groupPublicKey: PointT): void;
  record(groupPublicKey: PointT): FrostShareRecord | undefined;
  /** The record this service holds for an account reference, complete or not. */
  forAccount(accountRef: string): FrostShareRecord | undefined;
}

export const isFrostShareWriter = (s: FrostShareStore | undefined): s is FrostShareWriter =>
  !!s && typeof (s as FrostShareWriter).putPending === 'function';

const keyOf = (p: PointT) => toHex(p.toBytes(true));

function store(records: FrostShareRecord[], custody: string, persist?: (all: readonly FrostShareRecord[]) => void): FrostShareWriter {
  const byGroup = new Map(records.map((r) => [keyOf(r.share.groupPublicKey), r]));
  const save = () => persist?.([...byGroup.values()]);
  const w: FrostShareWriter = {
    custody,
    shareFor: (g) => {
      const r = byGroup.get(keyOf(g));
      return r?.complete ? r.share : undefined;
    },
    record: (g) => byGroup.get(keyOf(g)),
    forAccount: (accountRef) => [...byGroup.values()].find((r) => r.accountRef === accountRef),
    putPending: (r) => {
      const key = keyOf(r.share.groupPublicKey);
      if (byGroup.get(key)?.complete) throw new KeyCustodyError('this service already holds a complete share of that group key');
      byGroup.set(key, { ...r, complete: false });
      save();
    },
    complete: (g) => {
      const r = byGroup.get(keyOf(g));
      if (!r) throw new KeyCustodyError('no share of that group key to complete');
      const done: FrostShareRecord = { ...r, complete: true };
      byGroup.set(keyOf(g), done);
      save();
      return done;
    },
    discardPending: (g) => {
      const r = byGroup.get(keyOf(g));
      if (r && !r.complete) {
        byGroup.delete(keyOf(g));
        save();
      }
    },
  };
  Object.defineProperty(w, 'toJSON', { value: () => ({ custody, groups: byGroup.size }), enumerable: false });
  Object.defineProperty(w, Symbol.for('nodejs.util.inspect.custom'), { value: () => `FrostShareStore(${custody}, ${byGroup.size} groups)`, enumerable: false });
  return Object.freeze(w);
}

/** Shares held in memory. Tests, examples, and the in-memory half of the file store. */
export function memoryFrostShares(shares: readonly KeyShare[] = [], custody = 'memory'): FrostShareWriter {
  return store(shares.map((share) => ({ share, complete: true })), custody);
}

/** The JSON one entry of the share file is. */
export function frostShareJson(r: FrostShareRecord): Record<string, unknown> {
  return {
    id: r.share.id,
    share: toHex(r.share.share, { size: 32 }),
    groupPublicKey: keyOf(r.share.groupPublicKey),
    verificationShare: keyOf(publicShareOf(r.share)),
    ...(r.accountRef ? { accountRef: r.accountRef } : {}),
    ...(r.transcript ? { transcript: r.transcript } : {}),
    ...(r.createdAt ? { createdAt: r.createdAt } : {}),
    complete: r.complete,
  };
}

export function fileFrostShares(o: {
  path: string; production: boolean; allowInProduction?: boolean;
  readFile?: (p: string) => string; fileMode?: (p: string) => number;
  /** Replaced in tests; by default the file is rewritten through a 0600 temporary file and renamed. */
  writeFile?: (p: string, content: string) => void;
  /** No file yet: an empty store the DKG fills. Default false, so a typo in the path is loud. */
  createIfMissing?: boolean;
}): FrostShareWriter {
  if (o.production && !o.allowInProduction) {
    throw new KeyCustodyError('a FROST share file refuses to start in production mode: use an envelope-encrypted store, '
      + 'or set COSIGNER_ALLOW_FILE_KEY_IN_PRODUCTION=1 to accept shares on disk explicitly');
  }
  let raw: unknown;
  try {
    if (((o.fileMode ?? ((p) => statSync(p).mode))(o.path) & 0o077) !== 0) {
      throw new KeyCustodyError('the FROST share file is readable by group or others: chmod 600 it');
    }
    raw = JSON.parse((o.readFile ?? ((p) => readFileSync(p, 'utf8')))(o.path));
  } catch (e) {
    if (e instanceof KeyCustodyError) throw e;
    if (o.createIfMissing && (e as NodeJS.ErrnoException)?.code === 'ENOENT') raw = [];
    else throw new KeyCustodyError('the FROST share file could not be read as JSON');
  }
  if (!Array.isArray(raw)) throw new KeyCustodyError('the FROST share file must be a JSON array');
  const records = raw.map((entry: unknown, i): FrostShareRecord => {
    const e = (entry ?? {}) as Record<string, unknown>;
    const hex = (k: string, bytes: number): Hex => {
      const v = e[k];
      if (typeof v !== 'string' || !isHex(v) || hexToBytes(v).length !== bytes) throw new KeyCustodyError(`FROST share [${i}].${k} must be ${bytes} bytes of hex`);
      return v;
    };
    if (!Number.isSafeInteger(e.id) || (e.id as number) < 1) throw new KeyCustodyError(`FROST share [${i}].id must be a positive integer`);
    let share: KeyShare;
    try {
      share = { id: e.id as number, share: BigInt(hex('share', 32)), groupPublicKey: Point.fromBytes(hexToBytes(hex('groupPublicKey', 33))) };
      const verification = Point.fromBytes(hexToBytes(hex('verificationShare', 33)));
      if (!publicShareOf(share).equals(verification)) throw new KeyCustodyError(`FROST share [${i}] does not match its verification share`);
    } catch (err) {
      if (err instanceof KeyCustodyError) throw err;
      throw new KeyCustodyError(`FROST share [${i}] is not a valid share`);
    }
    if (e.accountRef !== undefined && typeof e.accountRef !== 'string') throw new KeyCustodyError(`FROST share [${i}].accountRef must be a string`);
    if (e.transcript !== undefined && (typeof e.transcript !== 'string' || !/^[0-9a-f]{64}$/.test(e.transcript))) throw new KeyCustodyError(`FROST share [${i}].transcript must be 32 bytes of hex`);
    return {
      share, accountRef: e.accountRef as string | undefined, transcript: e.transcript as string | undefined,
      createdAt: Number.isSafeInteger(e.createdAt) ? (e.createdAt as number) : undefined,
      // An entry written by hand, before this file had a DKG behind it, is a complete share.
      complete: e.complete === undefined ? true : e.complete === true,
    };
  });
  const write = o.writeFile ?? ((p: string, content: string) => {
    const tmp = `${p}.tmp`;
    writeFileSync(tmp, content, { mode: 0o600 });
    chmodSync(tmp, 0o600);
    renameSync(tmp, p);
  });
  return store(records, 'file', (all) => write(o.path, `${JSON.stringify(all.map(frostShareJson), null, 2)}\n`));
}
