/**
 * The co-signer's append-only audit log, and the memory rebuilt from it.
 *
 * Every enrolment and every decision - signed, reused or refused, with its code - is one JSON line, written
 * and fsynced BEFORE the answer leaves the process: a crash after signing and before logging loses a
 * signature nobody received, never one somebody holds. The format, the fsync discipline and torn-line
 * recovery are lp-node's `JsonlJournal`, reused rather than rewritten. It is never compacted: it is the
 * record an operator or an auditor reads to answer "what did the server sign, for whom, and why".
 *
 * Who: the account, the API client's name and a fingerprint of the passkey key - never an IP address, a
 * passkey signature or anything the co-signer signed. What: the digest, the EntryPoint nonce and window,
 * the target/selector/value of each call and the amounts counted against limits. Decision: signed, reused
 * (an identical request answered again) or refused with its code.
 *
 * What is rebuilt on load: the latest enrolment per account, the digests already co-signed (idempotency),
 * the last 24 hours of counted value per account (daily limits survive a restart), and which accounts the
 * sponsorship module allowlisted and when (its daily cap survives a restart, and it never re-sponsors an account
 * whose sponsorship was removed on-chain).
 *
 * Three more record kinds: `sponsor` (gasless onboarding decisions and their transactions), `alert`
 * (recovery-alert subscriptions and deliveries, never an endpoint or a key) and `dkg` (every round of every
 * distributed key generation, and the group key each one produced - never a share).
 */
import { keccak256, encodeAbiParameters, type Address, type Hex } from 'viem';
import type { Journal } from '@mova/lp-node/src/journal.js';
import type { AccountKind, CallSummary, Spend } from './policy.js';
import type { RefusalCode } from './refusal.js';

export interface Enrolment {
  chainId: number;
  account: Address;
  kind: AccountKind;
  passkey: { x: bigint; y: bigint; verifiers: bigint };
  /** The SafeWebAuthnSigner address for the passkey (the Safe owner, and the Delay's module). */
  passkeySigner: Address;
  /** This service's address as the account knows it. */
  coSigner: Address;
  /** Kernel: the root validator. */
  validator?: Address;
  /** Safe FROST: the FrostSigner owner. */
  frostSigner?: Address;
  /** FROST: the group key, compressed. */
  groupKey?: Hex;
  /** The recovery Delay at its predicted address (installed or not). */
  delay: Address;
  /** True when bound through a CREATE2 commitment before the account existed. */
  counterfactual: boolean;
  /**
   * Kernel, bound before it existed: the deployment its CREATE2 address commits to, as `resolveBinding` checked it.
   * Kept so the sponsorship module can create the account with a plain transaction - rebuilding the factory call from
   * these two fields, never from a request - before any operation would have to carry initCode.
   */
  kernelDeployment?: { initData: Hex; salt: Hex };
  /** The block at enrolment: where the queue's logs are read from. */
  fromBlock: bigint;
  /** Unix seconds. */
  enrolledAt: bigint;
}

export type Route = 'enrol' | 'cosign' | 'veto' | 'frost-commit' | 'frost-sign'
  | 'frost-dkg-start' | 'frost-dkg-round2' | 'frost-dkg-confirm';

export interface EnrolRecord {
  t: 'enrol';
  at: bigint;
  client: string;
  enrolment: Enrolment;
}

export interface DecisionRecord {
  t: 'decision';
  at: bigint;
  client: string;
  route: Route;
  chainId: number;
  account: Address;
  kind?: string;
  passkeyId?: Hex;
  digest?: Hex;
  decision: 'signed' | 'reused' | 'refused';
  code?: RefusalCode;
  nonce?: bigint;
  validUntil?: number;
  flow?: string;
  calls?: CallSummary[];
  spend?: Spend[];
  requestId?: string;
}

/**
 * The sponsorship module (sponsorship.ts): one record per decision about gasless onboarding of an enrolled account.
 * No user identifier: the account, its kind, the API client, and the operator's transactions - a Safe's passkey signer
 * (`signerTx`), a Kernel account's creation (`accountTx`) and the allowlisting (`sponsorTx`).
 */
export interface SponsorRecord {
  t: 'sponsor';
  at: bigint;
  client: string;
  chainId: number;
  account: Address;
  kind: AccountKind;
  /** sponsored: this service's operator allowlisted it; already: it was allowlisted before; refused or failed, with a code. */
  outcome: 'sponsored' | 'already' | 'refused' | 'failed';
  code?: string;
  operator?: Address;
  /** The SafeWebAuthnSigner creation, when this service sent it. */
  signerTx?: Hex;
  /** The Kernel account's creation through KernelFactory, when this service sent it. */
  accountTx?: Hex;
  sponsorTx?: Hex;
  /** A failed transaction's revert reason, redacted. */
  reason?: string;
}

/**
 * Recovery alerts (recovery-alerts.ts): subscriptions changing and alerts sent. The push endpoint and its keys are
 * never here - only the push service's host - so the audit log cannot address a device.
 */
export interface AlertRecord {
  t: 'alert';
  at: bigint;
  client?: string;
  chainId: number;
  account: Address;
  event: 'subscribed' | 'unsubscribed' | 'refused' | 'sent' | 'subscription-removed' | 'closed';
  code?: string;
  service?: string;
  queueNonce?: bigint;
  alert?: 'queued' | 'daily' | 'final';
  delivered?: number;
  failed?: number;
  /** For `closed`: why alerting stopped. */
  outcome?: 'vetoed-or-executed' | 'expired';
}

/**
 * Distributed key generation (dkg.ts): one record per round of every run, refusals included. There is no
 * account yet - a FROST account's address commits to the group key the run is about to produce - so the
 * subject is the account reference the run is keyed by, `chainId:passkeySigner`, plus the passkey's
 * fingerprint. No share, no polynomial and no transport message is ever here: the group key and the
 * transcript are public, and they are what an auditor needs to tie a run to the account that came out of it.
 */
export interface DkgRecord {
  t: 'dkg';
  at: bigint;
  client: string;
  chainId: number;
  /** `chainId:passkeySigner`: the account the run is for, before its address exists. */
  accountRef: string;
  passkeyId?: Hex;
  session?: Hex;
  event: 'started' | 'round2' | 'completed' | 'refused';
  code?: string;
  /** The participant the transport blamed, when it named one. */
  party?: number;
  groupKey?: Hex;
  transcript?: Hex;
}

export type AuditRecord = EnrolRecord | DecisionRecord | SponsorRecord | AlertRecord | DkgRecord;

export const passkeyId = (pk: { x: bigint; y: bigint }): Hex =>
  keccak256(encodeAbiParameters([{ type: 'uint256' }, { type: 'uint256' }], [pk.x, pk.y]));

const DAY = 24n * 3600n;
const accountKey = (chainId: number, account: Address) => `${chainId}:${account.toLowerCase()}`;

export class AuditLog {
  private readonly enrolments = new Map<string, Enrolment>();
  private readonly signed = new Map<string, DecisionRecord>();
  private readonly spends = new Map<string, { at: bigint; asset: string; amount: bigint }[]>();
  /** When this service sponsored each account, by account key. */
  private readonly sponsoredAt = new Map<string, bigint>();
  /** Completed key generations, by group key: which account reference a group key came out of. */
  private readonly dkgGroups = new Map<string, DkgRecord>();
  /** Every sponsorship this service sent, oldest first (pruned past a day when counted). */
  private readonly sponsorTimes: bigint[] = [];
  private count = 0;
  private loaded = false;

  constructor(private readonly journal: Journal<AuditRecord>, private readonly o: { now: () => bigint }) {}

  load(): void {
    for (const r of this.journal.load()) this.apply(r);
    this.loaded = true;
  }

  get records(): number {
    return this.count;
  }

  get enrolled(): number {
    return this.enrolments.size;
  }

  enrolment(chainId: number, account: Address): Enrolment | undefined {
    return this.enrolments.get(accountKey(chainId, account));
  }

  /** The signing decision recorded for `digest`, if the service co-signed it before. */
  signedFor(digest: Hex): DecisionRecord | undefined {
    return this.signed.get(digest.toLowerCase());
  }

  /** Value counted for `asset` on `account` in the last 24 hours. */
  spentToday(chainId: number, account: Address, asset: Address | 'native'): bigint {
    const list = this.spends.get(accountKey(chainId, account));
    if (!list) return 0n;
    const since = this.o.now() - DAY;
    const key = asset === 'native' ? 'native' : asset.toLowerCase();
    let total = 0n;
    for (let i = list.length - 1; i >= 0; i--) {
      const s = list[i]!;
      if (s.at < since) { list.splice(0, i + 1); break; }
      if (s.asset === key) total += s.amount;
    }
    return total;
  }

  /** The completed DKG that produced `groupKey`, if this service ran it. */
  dkgFor(groupKey: Hex): DkgRecord | undefined {
    return this.dkgGroups.get(groupKey.toLowerCase());
  }

  /** Every enrolment, latest per account: the accounts whose recovery queues are watched. */
  allEnrolments(): Enrolment[] {
    return [...this.enrolments.values()];
  }

  /** When this service's operator sponsored the account, if it ever did. */
  sponsoredByService(chainId: number, account: Address): bigint | undefined {
    return this.sponsoredAt.get(accountKey(chainId, account));
  }

  /** Sponsorships this service sent at or after `since` (unix seconds). */
  sponsorshipsSince(since: bigint): number {
    while (this.sponsorTimes.length && this.sponsorTimes[0]! < since - DAY) this.sponsorTimes.shift();
    let n = 0;
    for (let i = this.sponsorTimes.length - 1; i >= 0 && this.sponsorTimes[i]! >= since; i--) n++;
    return n;
  }

  /** Durably append, then remember. Returns only once the record is on disk. */
  append(r: AuditRecord): void {
    if (!this.loaded) throw new Error('audit log not loaded');
    this.journal.append(r);
    this.apply(r);
  }

  close(): void {
    this.journal.close();
  }

  private apply(r: AuditRecord): void {
    this.count++;
    if (r.t === 'enrol') {
      this.enrolments.set(accountKey(r.enrolment.chainId, r.enrolment.account), r.enrolment);
      return;
    }
    if (r.t === 'sponsor') {
      if (r.outcome === 'sponsored') {
        this.sponsoredAt.set(accountKey(r.chainId, r.account), r.at);
        this.sponsorTimes.push(r.at);
      }
      return;
    }
    if (r.t === 'dkg') {
      if (r.event === 'completed' && r.groupKey) this.dkgGroups.set(r.groupKey.toLowerCase(), r);
      return;
    }
    if (r.t !== 'decision' || r.decision !== 'signed' || !r.digest) return;
    const key = r.digest.toLowerCase();
    if (!this.signed.has(key)) this.signed.set(key, r);
    if (r.spend?.length) {
      const k = accountKey(r.chainId, r.account);
      const list = this.spends.get(k) ?? [];
      for (const s of r.spend) list.push({ at: r.at, asset: s.asset === 'native' ? 'native' : s.asset.toLowerCase(), amount: s.amount });
      this.spends.set(k, list);
    }
  }
}
