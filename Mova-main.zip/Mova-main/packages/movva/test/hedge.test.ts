import { describe, expect, it } from 'vitest';
import {
  B3_DOL, B3_WDO, DEFAULT_INSTRUMENTS, DEFAULT_SHOCK_ASSUMPTIONS, PTAX_2024, STANDARD_SHOCKS, b3QuoteToBrlPerUsdE6, carry,
  daysToExpiry, hedgeRatioBps, moveBpsBetween, netShortUsdE6, planHedge, positionsFromJson, recommendFreeMargin, shock,
  usdtForRatio, withinBand, type Position,
} from '../src/hedge.js';
import { modelSnapshot, thresholdWarnings } from '../src/reserve.js';

const ZERO_ADDRESS = '0x0000000000000000000000000000000000000000' as const;
import {
  ceilDiv, floorDiv, formatBps, formatBrl, formatUsd, formatUsdt, parseDecimal, roundDiv, toDecimal, truncDiv,
} from '../src/units.js';

/**
 * Worked examples. Every expected number is derived by hand in the comment beside it, not taken
 * from running the code: a formula and a fixture that share one mistake agree perfectly.
 */

const E18 = 10n ** 18n;
const usd = (dollars: bigint) => dollars * 1_000_000n;
const brl = (reais: bigint) => reais * E18;

/** R$ 10,000,000 of Movva at R$ 5.40 per USDT. */
const L = brl(10_000_000n);
const S = 5_400_000_000_000_000_000n;

const short = (instrument: 'DOL' | 'WDO', contracts: bigint, expiry = '2026-10-01'): Position => ({
  instrument, ticker: `${instrument}V26`, expiry, side: 'short', contracts, averagePriceBrlPerUsdE6: 5_421_000n,
});
/** 36 DOL + 5 WDO = US$ 1,800,000 + US$ 50,000. */
const BOOK = [short('DOL', 36n), short('WDO', 5n)];
const policy = { instruments: DEFAULT_INSTRUMENTS, bandBps: 200, tickers: { DOL: 'DOLX26', WDO: 'WDOX26' } };

describe('units', () => {
  it('rounds each way it says', () => {
    expect([truncDiv(-7n, 2n), floorDiv(-7n, 2n), ceilDiv(-7n, 2n), roundDiv(-7n, 2n)]).toEqual([-3n, -4n, -3n, -4n]);
    expect([truncDiv(7n, 2n), floorDiv(7n, 2n), ceilDiv(7n, 2n), roundDiv(7n, 2n)]).toEqual([3n, 3n, 4n, 4n]);
    expect(roundDiv(5n, 3n)).toBe(2n);
    expect(() => truncDiv(1n, 0n)).toThrow(/division by zero/);
  });

  it('parses decimals strictly and prints them losslessly', () => {
    expect(parseDecimal('1000.5', 6)).toBe(1_000_500_000n);
    expect(parseDecimal('1000.500000000', 6)).toBe(1_000_500_000n); // trailing zeros lose nothing
    expect(() => parseDecimal('1000.5000001', 6)).toThrow(/more than 6 decimal places/);
    expect(() => parseDecimal('1,000.5', 6)).toThrow(/plain decimal/);
    expect(toDecimal(-1_500_000n, 6)).toBe('-1.500000');
    expect(toDecimal(5n, 6)).toBe('0.000005');
  });

  it('formats for people in each currency\'s convention', () => {
    expect(formatBrl(brl(10_200_000n))).toBe('R$ 10.200.000,00');
    expect(formatUsd(usd(1_851_851n) + 850_000n)).toBe('US$ 1,851,851.85');
    expect(formatUsdt(1_888_888_888_889n)).toBe('1,888,888.888889 USDT');
    expect(formatBps(10_200n)).toBe('102.00%');
  });
});

describe('positions and the hedge ratio', () => {
  it('adds up shorts, subtracts longs, by configured contract size', () => {
    expect(netShortUsdE6(BOOK, DEFAULT_INSTRUMENTS)).toBe(usd(1_850_000n));
    expect(netShortUsdE6([...BOOK, { ...short('WDO', 2n), side: 'long' }], DEFAULT_INSTRUMENTS)).toBe(usd(1_830_000n));
    expect(() => netShortUsdE6([short('DOL', 1n), { ...short('WDO', 1n), instrument: 'XYZ' }], DEFAULT_INSTRUMENTS)).toThrow(/unknown instrument XYZ/);
  });

  it('marks the B3 contract sizes as facts to confirm with the broker', () => {
    expect(B3_DOL.contractSizeUsd).toBe(50_000n);
    expect(B3_WDO.contractSizeUsd).toBe(10_000n);
    for (const i of DEFAULT_INSTRUMENTS) expect(i.source).toMatch(/confirm with the broker/);
  });

  it('computes the ratio against liabilitiesUsdt', () => {
    // liabilitiesUsdt = 10,000,000 / 5.40 = 1,851,851.851851 USD; 1,850,000 / that = 0.999 -> 9990 bps
    const target = L * 1_000_000n / S;
    expect(target).toBe(1_851_851_851_851n);
    expect(hedgeRatioBps(usd(1_850_000n), target)).toBe(9_990n);
    expect(hedgeRatioBps(0n, 0n)).toBeUndefined();
    expect(withinBand(usd(1_850_000n), target, 200)).toBe(true);
    expect(withinBand(0n, 0n, 200)).toBe(true);
    expect(withinBand(1n, 0n, 200)).toBe(false);
  });

  it('reads B3 quotes (reais per US$ 1,000) as reais per dollar at 1e-6', () => {
    expect(b3QuoteToBrlPerUsdE6('5402.5')).toBe(5_402_500n);
    expect(b3QuoteToBrlPerUsdE6('5402.500')).toBe(5_402_500n);
    expect(() => b3QuoteToBrlPerUsdE6('5402.5001')).toThrow(/decimal places/);
  });

  it('parses a positions file, refusing what it cannot price', () => {
    const ok = positionsFromJson({ positions: [{ instrument: 'WDO', ticker: 'WDOV26', expiry: '2026-10-01', side: 'short', contracts: '5', averagePrice: '5418.500' }] });
    expect(ok[0]).toMatchObject({ contracts: 5n, averagePriceBrlPerUsdE6: 5_418_500n });
    let message = '';
    try {
      positionsFromJson({ positions: [{ instrument: 'WDO', ticker: 'WDOV26', expiry: '1/10/26', side: 'sell', contracts: '0', averagePrice: '5,4' }] });
    } catch (e) {
      message = (e as Error).message;
    }
    for (const field of ['expiry', 'side', 'averagePrice', 'contracts']) expect(message, field).toContain(`positions[0].${field}`);
  });
});

describe('rebalancing', () => {
  it('does nothing inside the band', () => {
    const p = planHedge({ targetUsdE6: 1_851_851_851_851n, positions: BOOK, policy });
    expect(p.withinBand).toBe(true);
    expect(p.orders).toEqual([]);
    expect(p.afterUsdE6).toBe(usd(1_850_000n));
  });

  /**
   * After a +5% dollar move the target falls to 10,000,000 / 5.67 = US$ 1,763,668.430335 and the
   * book is 104.9% hedged. Buy back 86,331.57: one DOL (50,000), then 36,331.57 in WDO - 3 leaves
   * 1,770,000 (+6,331.57 from target), 4 leaves 1,760,000 (-3,668.43). Both clear the 98% floor
   * (1,728,395); 4 is nearer.
   */
  it('buys back to the nearest position after a dollar rally, larger contracts first', () => {
    const p = planHedge({ targetUsdE6: 1_763_668_430_335n, positions: BOOK, policy });
    expect(p.withinBand).toBe(false);
    expect(p.orders).toEqual([
      { instrument: 'DOL', ticker: 'DOLX26', side: 'buy', contracts: 1n, notionalUsdE6: usd(50_000n) },
      { instrument: 'WDO', ticker: 'WDOX26', side: 'buy', contracts: 4n, notionalUsdE6: usd(40_000n) },
    ]);
    expect(p.afterUsdE6).toBe(usd(1_760_000n));
    expect(p.afterRatioBps).toBe(9_979n); // 1,760,000 / 1,763,668.43 = 0.99792
    expect(p.afterWithinBand).toBe(true);
  });

  /**
   * Target US$ 1,853,000 with a ±5 bps band from flat: 37 DOL = 1,850,000, then WDO. Zero WDO is
   * nearer (-3,000 vs +7,000) but under the floor (1,853,000 x 0.9995 = 1,852,073.5), so it sells one.
   */
  it('rounds up rather than leave the hedge under the band', () => {
    const p = planHedge({ targetUsdE6: usd(1_853_000n), positions: [], policy: { ...policy, bandBps: 5 } });
    expect(p.orders.map((o) => `${o.side} ${o.contracts} ${o.instrument}`)).toEqual(['sell 37 DOL', 'sell 1 WDO']);
    expect(p.afterUsdE6).toBe(usd(1_860_000n));
    // Width 2 x 5 bps x 1,853,000 = 1,853 USD, narrower than one WDO: no position is inside.
    expect(p.bandAchievable).toBe(false);
    expect(p.afterWithinBand).toBe(false);
    expect(p.notes.join(' ')).toMatch(/narrower than one WDO contract/);
  });

  it('closes the book when nothing is left to hedge', () => {
    const p = planHedge({ targetUsdE6: 0n, positions: BOOK, policy });
    // 36 DOL + 5 WDO are bought back as held - not 37 DOL, which nets to zero with a DOL long open.
    expect(p.orders.map((o) => `${o.side} ${o.contracts} ${o.instrument}`)).toEqual(['buy 36 DOL', 'buy 5 WDO']);
    expect(p.afterUsdE6).toBe(0n);
  });

  it('reduces a book of minis in minis', () => {
    // 185 WDO (US$ 1,850,000) against a US$ 1,763,668.43 target: buying back 9 leaves 1,760,000, nearer
    // than 8 (1,770,000) - but under a 20 bps floor of 1,763,668.43 x 0.998 = 1,760,141.09. So 8, in WDO.
    const p = planHedge({ targetUsdE6: 1_763_668_430_335n, positions: [short('WDO', 185n)], policy: { ...policy, bandBps: 20 } });
    expect(p.orders.map((o) => `${o.side} ${o.contracts} ${o.instrument}`)).toEqual(['buy 8 WDO']);
    expect(p.afterUsdE6).toBe(usd(1_770_000n));
  });

  it('flags positions to roll before expiry, and expired ones', () => {
    const asOf = Date.UTC(2026, 8, 28) / 1000; // 28 Sep 2026
    expect(daysToExpiry('2026-10-01', asOf)).toBe(3);
    const p = planHedge({ targetUsdE6: 1_851_851_851_851n, positions: [...BOOK, { ...short('WDO', 1n, '2026-09-01'), ticker: 'WDOU26' }], policy, asOf });
    expect(p.rolls.map((r) => r.ticker)).toEqual(['DOLV26', 'WDOV26', 'WDOU26']);
    expect(p.notes.join('\n')).toMatch(/WDOU26 expired 27 day/);
  });

  it('refuses a policy it cannot apply', () => {
    expect(() => planHedge({ targetUsdE6: 1n, positions: [], policy: { ...policy, bandBps: 10_000 } })).toThrow(/bandBps/);
    expect(() => planHedge({ targetUsdE6: 1n, positions: [], policy: { ...policy, instruments: [B3_WDO, B3_WDO] } })).toThrow(/twice/);
  });
});

describe('shocks', () => {
  /**
   * The reserve's defaults since the 14 September 2026 review: target 108%, withdraw floor 103%,
   * 24h hedge limit 8%. At the target: 10,800,000 / 5.40 = 2,000,000 USDT exactly.
   */
  const atTarget = modelSnapshot({ brlPerUsdtE18: S, totalUsdt: usdtForRatio(10_800n, L, S), liabilitiesBrlE18: L });
  const base = { snapshot: atTarget, hedgeShortUsdE6: usd(1_850_000n) };

  it('uses the reserve the example says', () => {
    expect(atTarget.totalUsdt).toBe(2_000_000_000_000n);
    expect(atTarget.collateralRatioBps).toBe(10_800n);
    expect(atTarget.thresholds).toEqual({ targetCollateralRatioBps: 10_800, minMintCollateralRatioBps: 10_000, minWithdrawCollateralRatioBps: 10_300 });
    expect(DEFAULT_SHOCK_ASSUMPTIONS.withdrawDailyLimitBps).toBe(800);
  });

  /**
   * +5%: the rate goes 5.40 -> 5.67. The short loses 1,850,000 x 0.27 = R$ 499,500 and initial
   * margin (10%) rises by R$ 49,950: R$ 549,450 to post. The 103% floor keeps 10,300,000 / 5.67 =
   * 1,816,578.483246 USDT, so 183,421.516754 may leave; the 24h limit, 8% x 2,000,000 = 160,000,
   * binds. Sold at 5.67 less 0.30%: 160,000 x 5.67 x 0.997 = R$ 904,478.40. Covered.
   */
  it('+5% at the target ratio: the reserve alone meets the margin call', () => {
    const r = shock({ ...base, moveBps: 500 });
    expect(r.rate.afterE18).toBe(5_670_000_000_000_000_000n);
    expect(r.hedge.variationBrlE18).toBe(-brl(499_500n));
    expect(r.hedge.initialMarginChangeBrlE18).toBe(brl(49_950n));
    expect(r.marginCall.needBrlE18).toBe(brl(549_450n));
    expect(r.marginCall.floorMaxUsdt).toBe(183_421_516_754n);
    expect(r.marginCall.dailyMaxUsdt).toBe(160_000_000_000n);
    expect(r.marginCall).toMatchObject({ binding: 'daily-limit', limitSource: 'assumption', shortfallBrlE18: 0n });
    expect(r.marginCall.withdrawableBrlNetE18).toBe(904_478_400_000_000_000_000_000n);
    expect(r.reserve.ratioAfterBps).toBe(11_340n); // 108% x 1.05
    expect(r.covered).toBe(true);
    expect(r.flags).toEqual([]);
  });

  /**
   * -5%: 5.40 -> 5.13. 2,000,000 x 5.13 / 10M = 102.60%: still fully backed. Back to 108% needs
   * 10,800,000 / 5.13 - 2,000,000 = 105,263.157895 USDT; the short gains R$ 499,500 and releases
   * R$ 49,950 of margin, buying 549,450 x 0.997 / 5.13 = 106,783.947368 USDT - the target, restored.
   */
  it('-5% at the target ratio: still above 100%, and the hedge gains restore the target', () => {
    const r = shock({ ...base, moveBps: -500 });
    expect(r.reserve.ratioAfterBps).toBe(10_260n);
    expect(r.hedge.cashFlowBrlE18).toBe(brl(549_450n));
    expect(r.recapitalization.toFullUsdt).toBe(0n);
    expect(r.recapitalization.toTargetUsdt).toBe(105_263_157_895n);
    expect(r.recapitalization.fromHedgeUsdt).toBe(106_783_947_368n);
    expect(r.recapitalization.issuerCapitalToTargetUsdt).toBe(0n);
    expect(r.covered).toBe(true);
    expect(r.flags).toEqual([]);
  });

  /**
   * +10%: 5.94. Call 1,850,000 x 0.54 x 1.1 = R$ 1,098,900. The floor allows 2,000,000 -
   * 10,300,000 / 5.94 = 265,993.265993; the 24h limit's 160,000 binds, = 160,000 x 5.94 x 0.997 =
   * R$ 947,548.80: R$ 151,351.20 short.
   */
  it('+10%: the 24h limit binds and leaves a gap', () => {
    const r = shock({ ...base, moveBps: 1_000 });
    expect(r.marginCall.floorMaxUsdt).toBe(265_993_265_993n);
    expect(r.marginCall.binding).toBe('daily-limit');
    expect(r.marginCall.shortfallBrlE18).toBe(brl(151_351n) + 200_000_000_000_000_000n);
    expect(r.covered).toBe(false);
  });

  /** -10%: 4.86. 2,000,000 x 4.86 / 10M = 97.20%; back to 100%: 10M / 4.86 - 2M = 57,613.168725. */
  it('-10%: under-backed until recapitalized', () => {
    const r = shock({ ...base, moveBps: -1_000 });
    expect(r.reserve.ratioAfterBps).toBe(9_720n);
    expect(r.recapitalization.toFullUsdt).toBe(57_613_168_725n);
    expect(r.covered).toBe(true);
    expect(r.flags.join(' ')).toMatch(/UNDER-BACKED after the move/);
  });

  /**
   * The parameters the review replaced: target 102%, withdraw floor 105%, limit 2%. The same +5%
   * then released 1,888,888.888889 - 10,500,000 / 5.67 = 37,037.037037 USDT (R$ 209,370 net) of a
   * R$ 549,450 call: R$ 340,080 from the issuer. The desk now names the cause.
   */
  it('flags ratios out of order - a withdraw floor above the target - and shows what they cost', () => {
    const legacy = modelSnapshot({
      brlPerUsdtE18: S, totalUsdt: usdtForRatio(10_200n, L, S), liabilitiesBrlE18: L,
      thresholds: { targetCollateralRatioBps: 10_200, minWithdrawCollateralRatioBps: 10_500 },
    });
    expect(thresholdWarnings(legacy.thresholds)[0]).toMatch(/RATIOS OUT OF ORDER: the withdraw floor 105.00% is above the target 102.00%.*rises 2.94%/);
    const r = shock({ snapshot: legacy, hedgeShortUsdE6: usd(1_850_000n), moveBps: 500, assumptions: { withdrawDailyLimitBps: 200 } });
    expect(r.flags[0]).toMatch(/RATIOS OUT OF ORDER/);
    expect(r.marginCall.floorMaxUsdt).toBe(37_037_037_037n);
    expect(r.marginCall.binding).toBe('floor');
    expect(formatBrl(r.marginCall.shortfallBrlE18)).toBe('R$ 340.080,00');
    expect(r.flags.join(' ')).toMatch(/MARGIN CALL NOT COVERED.*105.00% withdraw floor/);
    expect(thresholdWarnings(atTarget.thresholds)).toEqual([]);
    expect(thresholdWarnings({ targetCollateralRatioBps: 10_800, minWithdrawCollateralRatioBps: 10_300, minMintCollateralRatioBps: 10_400 })[0])
      .toMatch(/mint floor 104.00% is above the withdraw floor 103.00%/);
  });

  it('prices 2024 from the PTAX year ends: +27.90%, and -21.81% back', () => {
    // (6.1923 - 4.8413) / 4.8413 = 0.279057...; (4.8413 - 6.1923) / 6.1923 = -0.218174...
    expect(moveBpsBetween(PTAX_2024.start.brlPerUsdE6, PTAX_2024.end.brlPerUsdE6)).toBe(2_790n);
    expect(moveBpsBetween(PTAX_2024.end.brlPerUsdE6, PTAX_2024.start.brlPerUsdE6)).toBe(-2_181n);
    expect(STANDARD_SHOCKS.map((s) => s.moveBps)).toEqual([500n, -500n, 1_000n, -1_000n, 2_790n, -2_181n]);
  });

  it('lets free margin absorb a call first, and refills the 24h limit over days but not the floor', () => {
    const margin = { balanceBrlE18: brl(1_249_000n), requiredBrlE18: brl(999_000n) }; // R$ 250,000 free
    const r = shock({ ...base, moveBps: 500, margin });
    expect(r.marginCall.needBrlE18).toBe(brl(299_450n));
    const slow = shock({ ...base, moveBps: 1_000, assumptions: { days: 5 } });
    expect(slow.marginCall.dailyMaxUsdt).toBe(800_000_000_000n); // 160,000 a day for 5 days
    expect(slow.marginCall.binding).toBe('floor');
    expect(slow.covered).toBe(true); // 265,993.27 x 5.94 x 0.997 = R$ 1,575,217 against R$ 1,098,900
  });

  it('counts withdrawals already made in the window, when the reserve cannot say itself', () => {
    const r = shock({ ...base, moveBps: 1_000, assumptions: { withdrawnInWindowUsdt: 30_000_000_000n } });
    expect(r.marginCall.dailyMaxUsdt).toBe(130_000_000_000n);
    expect(r.marginCall.limitSource).toBe('assumption');
  });

  /**
   * With the reserve's views: its bucket holds 50,000 USDT now. Day one is exactly that, whatever the
   * configuration or the event count says; each later day refills 8% x 2,000,000 = 160,000.
   * +5%: 50,000 x 5.67 = 283,500, x 0.997 = R$ 282,649.50 against R$ 549,450: R$ 266,800.50 short.
   */
  it('takes the 24h allowance from the reserve\'s hedgeWithdrawable and hedgeLimitBps when the snapshot has them', () => {
    const snapshot = { ...atTarget, hedge: { withdrawableUsdt: 50_000_000_000n, limitBps: 800, treasury: ZERO_ADDRESS, treasurer: ZERO_ADDRESS } };
    const r = shock({ snapshot, hedgeShortUsdE6: usd(1_850_000n), moveBps: 500, assumptions: { withdrawnInWindowUsdt: 40_000_000_000n } });
    expect(r.marginCall).toMatchObject({ dailyMaxUsdt: 50_000_000_000n, binding: 'daily-limit', limitSource: 'reserve' });
    expect(formatBrl(r.marginCall.shortfallBrlE18)).toBe('R$ 266.800,50');
    expect(shock({ snapshot, hedgeShortUsdE6: usd(1_850_000n), moveBps: 500, assumptions: { days: 3 } }).marginCall.dailyMaxUsdt).toBe(370_000_000_000n);
    const mismatch = shock({ snapshot, hedgeShortUsdE6: usd(1_850_000n), moveBps: 500, assumptions: { withdrawDailyLimitBps: 200 } });
    expect(mismatch.assumptions.withdrawDailyLimitBps).toBe(800);
    expect(mismatch.flags.join()).toMatch(/configured 24h limit \(2.00%\) differs from the reserve's hedgeLimitBps \(8.00%\)/);
  });

  it('refuses nonsense', () => {
    expect(() => shock({ ...base, moveBps: -10_000 })).toThrow(/-100%/);
    expect(() => shock({ ...base, moveBps: 1, assumptions: { days: 0 } })).toThrow(/days/);
  });
});

describe('standing free margin', () => {
  const atTarget = modelSnapshot({ brlPerUsdtE18: S, totalUsdt: usdtForRatio(10_800n, L, S), liabilitiesBrlE18: L });

  /**
   * A +10% day calls 1,850,000 x 0.54 x 1.1 = R$ 1,098,900. Before the move, withdrawToHedge allows
   * 2,000,000 - 10,300,000 / 5.40 = 92,592.592592 USDT (the floor, under the 160,000 bucket), sold at
   * 5.40 less 0.30% = R$ 498,500. Free margin to hold: R$ 600,400 = 6.004% of the R$ 10M supply.
   * If the oracle has repriced first, the shock view's R$ 151,351.20.
   */
  it('sizes the free margin a +10% day needs beside what the reserve releases now', () => {
    const r = recommendFreeMargin({ snapshot: atTarget, hedgeShortUsdE6: usd(1_850_000n) });
    expect(r.stressMoveBps).toBe(1_000n);
    expect(r.needBrlE18).toBe(brl(1_098_900n));
    expect(r.releasableNowUsdt).toBe(92_592_592_592n);
    expect(formatBrl(r.releasableNowBrlE18)).toBe('R$ 498.500,00');
    expect(formatBrl(r.freeMarginBrlE18)).toBe('R$ 600.400,00');
    expect(r.freeMarginOfSupplyBps).toBe(601n); // rounded up
    expect(r.freeMarginIfRepricedBrlE18).toBe(shock({ snapshot: atTarget, hedgeShortUsdE6: usd(1_850_000n), moveBps: 1_000 }).marginCall.shortfallBrlE18);
    expect(r.basis).toMatch(/configured 24h limit/);
    // Fully hedged at liabilitiesUsdt: 1,851,851.85 x 0.594 = R$ 1,100,000, less R$ 498,500.
    expect(formatBrl(recommendFreeMargin({ snapshot: atTarget, hedgeShortUsdE6: atTarget.liabilitiesUsdt }).freeMarginBrlE18)).toBe('R$ 601.500,00');
  });

  it('is exactly enough: with it the stress is covered on the shock view, a wei less is not', () => {
    const r = recommendFreeMargin({ snapshot: atTarget, hedgeShortUsdE6: usd(1_850_000n) });
    const withMargin = (free: bigint) => shock({
      snapshot: atTarget, hedgeShortUsdE6: usd(1_850_000n), moveBps: 1_000, margin: { balanceBrlE18: free, requiredBrlE18: 0n },
    });
    expect(withMargin(r.freeMarginIfRepricedBrlE18).covered).toBe(true);
    expect(withMargin(r.freeMarginIfRepricedBrlE18 - 1n).covered).toBe(false);
    // And on the conservative basis: what is left of the call after free margin is what the reserve releases now.
    expect(r.needBrlE18 - r.freeMarginBrlE18).toBe(r.releasableNowBrlE18);
  });

  it('reports the top-up against the statement\'s free margin, and zero when the reserve alone covers the stress', () => {
    const r = recommendFreeMargin({ snapshot: atTarget, hedgeShortUsdE6: usd(1_850_000n), margin: { balanceBrlE18: brl(1_249_000n), requiredBrlE18: brl(999_000n) } });
    expect(formatBrl(r.topUpBrlE18!)).toBe('R$ 350.400,00');
    // At 120%, a +5% day (R$ 549,450) is under the R$ 957,100 the bucket releases now (177,777.78 USDT).
    const rich = modelSnapshot({ brlPerUsdtE18: S, totalUsdt: usdtForRatio(12_000n, L, S), liabilitiesBrlE18: L });
    expect(recommendFreeMargin({ snapshot: rich, hedgeShortUsdE6: usd(1_850_000n), stressMoveBps: 500 }).freeMarginBrlE18).toBe(0n);
    expect(() => recommendFreeMargin({ snapshot: rich, hedgeShortUsdE6: 1n, stressMoveBps: -500 })).toThrow(/positive/);
  });

  it('counts the reserve\'s own bucket when it has one', () => {
    const snapshot = { ...atTarget, hedge: { withdrawableUsdt: 50_000_000_000n, limitBps: 800, treasury: ZERO_ADDRESS, treasurer: ZERO_ADDRESS } };
    const r = recommendFreeMargin({ snapshot, hedgeShortUsdE6: usd(1_850_000n) });
    expect(r.releasableNowUsdt).toBe(50_000_000_000n); // the bucket, under the 92,592.59 floor
    expect(r.basis).toMatch(/hedgeWithdrawable/);
  });
});

describe('carry', () => {
  /**
   * Spot 5.40, the future at 5,430.000 per US$ 1,000 with 30 days to go: basis R$ 0.03, 55.6 bps
   * for the period, 0.03 / 5.40 x 365 / 30 = 6.759% a year; on US$ 1,850,000, R$ 55,500.
   */
  it('annualises the basis a short earns', () => {
    const c = carry({ futuresBrlPerUsdE6: b3QuoteToBrlPerUsdE6('5430.000'), spotBrlPerUsdE6: 5_400_000n, days: 30, notionalUsdE6: usd(1_850_000n) });
    expect(c.basisBrlPerUsdE6).toBe(30_000n);
    expect(c.periodBps).toBe(56n);
    expect(c.annualizedBps).toBe(676n);
    expect(c.carryBrlE18).toBe(brl(55_500n));
    // 21 business days over 252: 0.03 / 5.40 x 252 / 21 = 6.667%
    expect(carry({ futuresBrlPerUsdE6: 5_430_000n, spotBrlPerUsdE6: 5_400_000n, days: 21, dayBasis: 252 }).annualizedBps).toBe(667n);
  });

  it('is negative in backwardation and refuses a zero horizon', () => {
    expect(carry({ futuresBrlPerUsdE6: 5_390_000n, spotBrlPerUsdE6: 5_400_000n, days: 10 }).annualizedBps).toBe(-676n); // -0.01/5.4 x 36.5
    expect(() => carry({ futuresBrlPerUsdE6: 1n, spotBrlPerUsdE6: 1n, days: 0 })).toThrow(/days/);
  });
});
