import { describe, expect, it } from 'vitest';
import { privateKeyToAccount } from 'viem/accounts';
import { DEFAULT_THRESHOLDS, MOVVA_STATEMENT_TYPES, runChecks, type MonitorTargets } from '@mova/ops';
import { DEFAULT_INSTRUMENTS, shock, usdtForRatio, type Position } from '../src/hedge.js';
import { toJson } from '../src/json.js';
import { readReserveSnapshot, requirePriced } from '../src/reserve.js';
import { STATEMENT_TYPES, buildStatement, documentSha256, signStatement, statementToJson } from '../src/statement.js';
import { FakeReserve, L10M, R540, RESERVE } from './fake-reserve.js';

/**
 * The monitor (@mova/ops) cannot import this package - this package imports it - so it carries a
 * transcription of the statement format and of the headroom arithmetic. These tests keep the two
 * in step: a change on either side that the other does not share fails here.
 */

const issuer = privateKeyToAccount(`0x${'42'.repeat(32)}`);
const POSITIONS: Position[] = [
  { instrument: 'DOL', ticker: 'DOLV26', expiry: '2026-10-01', side: 'short', contracts: 36n, averagePriceBrlPerUsdE6: 5_421_000n },
  { instrument: 'WDO', ticker: 'WDOV26', expiry: '2026-10-01', side: 'short', contracts: 5n, averagePriceBrlPerUsdE6: 5_418_500n },
];

async function setup(ratio = 10_200n, marginFreeCents = 0n) {
  const f = new FakeReserve().at(100n, { rate: R540, updatedAt: 1_789_001_000n, totalUsdt: usdtForRatio(ratio, L10M, R540), liabilitiesBrlE18: L10M });
  f.head = 150n;
  const snapshot = requirePriced(await readReserveSnapshot(f.client(), RESERVE, { blockNumber: 100n }));
  const signed = await signStatement(issuer, 1, RESERVE, buildStatement({
    issuer: issuer.address, asOf: snapshot.blockTimestamp + 60n, snapshot, positions: POSITIONS, instruments: DEFAULT_INSTRUMENTS,
    marginBalanceBrlCents: 99_900_000n + marginFreeCents, marginRequiredBrlCents: 99_900_000n,
    brokerStatementSha256: documentSha256(new TextEncoder().encode('broker')),
  }));
  let text = toJson(statementToJson(signed));
  const targets: MonitorTargets = {
    client: f.client(),
    movva: { reserve: RESERVE, chainId: 1, statement: { load: async () => text, issuer: issuer.address, memory: {} } },
  };
  const now = Number(f.timestamp(150n));
  const run = async () => runChecks(targets, DEFAULT_THRESHOLDS, now);
  return { f, snapshot, signed, targets, run, setText: (t: string) => { text = t; } };
}

const by = (rs: Awaited<ReturnType<typeof runChecks>>, id: string) => rs.find((r) => r.id === id)!;

describe('the monitor\'s transcription of the statement format', () => {
  it('has exactly the EIP-712 types this package signs', () => {
    expect(MOVVA_STATEMENT_TYPES).toEqual(STATEMENT_TYPES);
  });

  it('accepts a statement this package signed', async () => {
    const { run } = await setup();
    const r = by(await run(), 'movva_hedge_statement');
    expect(r.detail).toMatch(/statement #1 signed by the issuer/);
    expect(r.level).toBe('ok');
    expect(r.value).toBe(9_990); // 1,850,000 / 1,851,851.85
  });

  it('rejects the same statement edited after signing', async () => {
    const { run, signed, setText } = await setup();
    const doc = statementToJson(signed) as { message: { positions: { contracts: string }[]; netShortUsdE6: string } };
    doc.message.positions[0].contracts = '37';
    doc.message.netShortUsdE6 = '1900000000000';
    setText(JSON.stringify(doc));
    const r = by(await run(), 'movva_hedge_statement');
    expect(r.level).toBe('fail');
    expect(r.detail).toMatch(/NOT signed by the issuer/);
  });
});

describe('the monitor\'s withdraw headroom', () => {
  /** The same +5% the desk's shock tool prices, with the same default assumptions. */
  it.each([[10_200n, 0n], [11_000n, 0n], [11_000n, 25_000_000n], [11_000n, 40_000_000n], [13_000n, 0n]])('agrees with shock() at %s bps and %s cents of free margin', async (ratio, free) => {
    const { run, snapshot } = await setup(ratio, free);
    const r = by(await run(), 'movva_withdraw_headroom');
    const s = shock({
      snapshot, hedgeShortUsdE6: 1_850_000_000_000n, moveBps: DEFAULT_THRESHOLDS.movvaShockBps,
      margin: { balanceBrlE18: (99_900_000n + free) * 10n ** 16n, requiredBrlE18: 99_900_000n * 10n ** 16n },
      assumptions: {
        withdrawDailyLimitBps: DEFAULT_THRESHOLDS.movvaWithdrawDailyLimitBps, initialMarginBps: DEFAULT_THRESHOLDS.movvaInitialMarginBps,
        conversionCostBps: DEFAULT_THRESHOLDS.movvaConversionCostBps,
      },
    });
    const coverage = s.marginCall.needBrlE18 === 0n || s.marginCall.shortfallBrlE18 === 0n
      ? 100 : Number(s.marginCall.withdrawableBrlNetE18 * 100n / s.marginCall.needBrlE18);
    expect(r.value).toBe(coverage);
    expect(r.level).toBe(coverage >= 100 ? 'ok' : 'warn');
    expect(r.detail).toContain('statement #1');
  });
});
