import { describe, expect, it } from 'vitest';
import { existsSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { toEventSelector, toFunctionSelector, type Abi, type AbiEvent, type AbiFunction } from 'viem';
import { MOVVA_MONITOR_ABI } from '@mova/ops';
import { MOVVA_RESERVE_ABI, MOVVA_RESERVE_QUEUE_ABI } from '../src/abi.js';

/**
 * The hand-transcribed ABI against the compiled interface. Skipped when no build is present, so a
 * checkout without Foundry still runs the suite (see the README for the build command).
 *
 * `MOVVA_FORGE_OUT` points at a build directory; otherwise the repository's `forge-out`.
 */
const ROOT = fileURLToPath(new URL('../../../', import.meta.url));
const OUT = process.env.MOVVA_FORGE_OUT ?? join(ROOT, 'forge-out');

const artifact = (file: string, name: string): Abi | undefined => {
  const p = join(OUT, file, `${name}.json`);
  return existsSync(p) ? (JSON.parse(readFileSync(p, 'utf8')) as { abi: Abi }).abi : undefined;
};

const sig = (x: AbiFunction | AbiEvent) => `${x.name}(${x.inputs.map((i) => i.type).join(',')})`;
const fns = (abi: Abi) => abi.filter((x): x is AbiFunction => x.type === 'function');
const evs = (abi: Abi) => abi.filter((x): x is AbiEvent => x.type === 'event');

/** Every function and event in `mine` exists in `compiled` with the same outputs, mutability and indexing. */
function contained(mine: Abi, compiled: Abi): void {
  for (const item of fns(mine)) {
    const theirs = fns(compiled).find((c) => toFunctionSelector(c) === toFunctionSelector(item));
    expect(theirs, `function ${sig(item)} is not in the compiled contract`).toBeDefined();
    expect(theirs!.outputs.map((o) => o.type), `${item.name} outputs`).toEqual(item.outputs.map((o) => o.type));
    expect(theirs!.stateMutability, `${item.name} mutability`).toBe(item.stateMutability);
  }
  for (const item of evs(mine)) {
    const theirs = evs(compiled).find((c) => toEventSelector(c) === toEventSelector(item));
    expect(theirs, `event ${sig(item)} is not in the compiled contract`).toBeDefined();
    expect(theirs!.inputs.map((i) => i.indexed ?? false), `${item.name} indexing`).toEqual(item.inputs.map((i) => i.indexed ?? false));
  }
}

describe.skipIf(!existsSync(join(OUT, 'IMovvaReserve.sol', 'IMovvaReserve.json')))('the ABI matches the compiled interface', () => {
  it('transcribes every function and event of IMovvaReserve, and nothing it lacks', () => {
    const compiled = artifact('IMovvaReserve.sol', 'IMovvaReserve')!;
    contained(MOVVA_RESERVE_ABI, compiled);
    // And the other way: a function added to the interface must be taught to this package.
    contained(compiled.filter((x) => x.type === 'function' || x.type === 'event') as Abi, MOVVA_RESERVE_ABI);
  });

  it('the monitor\'s subset matches too', () => {
    contained(MOVVA_MONITOR_ABI as unknown as Abi, artifact('IMovvaReserve.sol', 'IMovvaReserve')!);
  });

  it.skipIf(!existsSync(join(OUT, 'MovvaReserve.sol', 'MovvaReserve.json')))('the implementation, once built, exposes all of it', () => {
    contained(MOVVA_RESERVE_ABI, artifact('MovvaReserve.sol', 'MovvaReserve')!);
  });
});

type AbiError = Extract<Abi[number], { type: 'error' }>;
const errSig = (x: AbiError) => `${x.name}(${x.inputs.map((i) => i.type).join(',')})`;

describe.skipIf(!existsSync(join(OUT, 'MovvaReserve.sol', 'MovvaReserve.json')))('the queue ABI matches the compiled reserve', () => {
  it('transcribes the queue\'s functions and events as MovvaReserve compiles them', () => {
    contained(MOVVA_RESERVE_QUEUE_ABI as unknown as Abi, artifact('MovvaReserve.sol', 'MovvaReserve')!);
  });

  it('every refusal it decodes is one the reserve or its breaker declares, with the same arguments', () => {
    const declared = new Set([
      ...artifact('MovvaReserve.sol', 'MovvaReserve')!,
      ...(artifact('DivergenceBreaker.sol', 'DivergenceBreaker') ?? []),
    ].filter((x): x is AbiError => x.type === 'error').map(errSig));
    const mine = (MOVVA_RESERVE_QUEUE_ABI as unknown as Abi).filter((x): x is AbiError => x.type === 'error').map(errSig);
    expect(mine.length).toBeGreaterThan(0);
    for (const e of mine) expect(declared, `error ${e} is not declared by the compiled reserve or breaker`).toContain(e);
  });
});

describe('without a build', () => {
  it('the monitor\'s transcription is a subset of this one', () => {
    contained(MOVVA_MONITOR_ABI as unknown as Abi, MOVVA_RESERVE_ABI);
  });
});
