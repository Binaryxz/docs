import { describe, expect, it } from 'vitest';
import { mkdtempSync, readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { privateKeyToAccount } from 'viem/accounts';
import { runDesk, type DeskIo } from '../src/bin/movva-desk.js';
import { ConfigError, deskConfigFromEnv, statementKeyFromEnv } from '../src/config.js';
import { usdtForRatio } from '../src/hedge.js';
import { toJson } from '../src/json.js';
import { modelSnapshot } from '../src/reserve.js';
import { FakeReserve, L10M, R540, RESERVE } from './fake-reserve.js';

/**
 * The CLI end to end, with the chain and the filesystem injected. Importing the bin also proves it
 * does not run on import.
 */
const EXAMPLES = fileURLToPath(new URL('../examples/', import.meta.url));
const RPC = 'https://eth-mainnet.g.alchemy.com/v2/AbCdEfGhIjKlMnOp0123456789';
const KEY = `0x${'42'.repeat(32)}`;
const ISSUER = privateKeyToAccount(KEY as `0x${string}`).address;

function io(env: Record<string, string>, files: Record<string, string> = {}, fake?: FakeReserve, now = 1_789_010_000) {
  const out: string[] = [];
  const err: string[] = [];
  const written: Record<string, string> = {};
  const read = (p: string) => {
    if (p in files) return files[p];
    if (p in written) return written[p];
    return readFileSync(p, 'utf8');
  };
  const d: DeskIo = {
    env, readFile: read, readBytes: (p) => new TextEncoder().encode(read(p)),
    writeFile: (p, t) => { written[p] = t; },
    stdout: (t) => { out.push(t); }, stderr: (t) => { err.push(t); },
    nowSeconds: () => now,
    client: fake ? () => fake.client() : () => { throw new Error(`could not reach ${RPC}`); },
  };
  return { d, out, err, written, json: () => JSON.parse(out.join('')) };
}

const chainAt108 = () => {
  const f = new FakeReserve().at(700n, { rate: R540, updatedAt: 1_789_008_000n, totalUsdt: usdtForRatio(10_800n, L10M, R540), liabilitiesBrlE18: L10M });
  f.genesisTime = 1_789_000_000n;
  return f;
};

describe('movva-desk offline', () => {
  const env = { MOVVA_DESK_CONFIG: join(EXAMPLES, 'desk.json') };

  it('runs the standard shocks against a saved snapshot with the reserve\'s own limit, and says which are not covered', async () => {
    const t = io(env);
    const code = await runDesk(['shock', '--snapshot', join(EXAMPLES, 'reserve-at-target.json'), '--positions', join(EXAMPLES, 'positions.json')], t.d);
    expect(code).toBe(0);
    const r = t.json() as {
      limitSource: string; recommendation: { stressMoveBps: string; freeMarginBrlE18: string; freeMarginOfSupplyBps: string };
      results: { label: string; covered: boolean; marginCall: { limitSource: string } }[];
    };
    // At 108% / 103% / 8%: a +5% day is met by the reserve; +10% and a 2024-size day are not.
    expect(r.results.map((x) => [x.label, x.covered])).toEqual([
      ['+5%', true], ['-5%', true], ['+10%', false], ['-10%', true], ['2024 (R$ 4,8413 -> 6,1923)', false], ['2024 reversed (R$ 6,1923 -> 4,8413)', true],
    ]);
    expect(r.limitSource).toBe('reserve');
    expect(r.results.every((x) => x.marginCall.limitSource === 'reserve')).toBe(true);
    // Worked in hedge.test.ts: R$ 1,098,900 less the R$ 498,500 released now = R$ 600,400.
    expect(r.recommendation).toMatchObject({ stressMoveBps: '1000', freeMarginOfSupplyBps: '601' });
    expect(BigInt(r.recommendation.freeMarginBrlE18) / 10n ** 18n).toBe(600_400n);
    // The snapshot carries the reserve's bucket, so no event count is assumed.
    expect(t.err.join()).not.toMatch(/assuming nothing was withdrawn/);
  });

  it('prints a text summary with the standing free margin, and takes custom moves and a custom stress', async () => {
    const t = io(env);
    expect(await runDesk(['shock', '--snapshot', join(EXAMPLES, 'reserve-at-floor.json'), '--move', '500', '--stress', '500', '--text'], t.d)).toBe(0);
    const text = t.out.join('');
    expect(text).toMatch(/ASSUMED fully hedged/);
    expect(text).toMatch(/24h withdraw limit 8.00% from the reserve/);
    expect(text).toMatch(/\+5.00%: rate R\$ 5,4000 -> R\$ 5,6700; reserve ratio 103.00% -> 108.15%/);
    // At the floor nothing is releasable now, so the whole +5% call (1,851,851.85 x 0.297) is free margin.
    expect(text).toMatch(/standing free margin for a one-day \+5.00% rally: R\$ 550.000,00 \(5.50% of supply\)/);
    expect(await runDesk(['shock', '--snapshot', join(EXAMPLES, 'reserve-at-floor.json'), '--stress', '-5'], io(env).d)).toBe(2);
  });

  it('flags a snapshot whose withdraw floor is above its target, once, and a configured limit that disagrees with the reserve', async () => {
    const legacy = modelSnapshot({
      brlPerUsdtE18: R540, totalUsdt: usdtForRatio(10_200n, L10M, R540), liabilitiesBrlE18: L10M,
      thresholds: { targetCollateralRatioBps: 10_200, minWithdrawCollateralRatioBps: 10_500 },
    });
    // No desk config: it names the example reserve, and this model is of another.
    const t = io({}, { '/legacy.json': toJson(legacy) });
    expect(await runDesk(['shock', '--snapshot', '/legacy.json', '--text'], t.d)).toBe(0);
    const text = t.out.join('');
    expect(text.match(/RATIOS OUT OF ORDER/g)).toHaveLength(1);
    expect(text).toMatch(/CONFIGURED \(reserve exposes no view\)/);
    expect(t.err.join()).toMatch(/offline: assuming nothing was withdrawn/);
    const snap = io({}, { '/legacy.json': toJson(legacy) });
    expect(await runDesk(['snapshot', '--snapshot', '/legacy.json', '--text'], snap.d)).toBe(0);
    expect(snap.out.join('')).toMatch(/WARNING +RATIOS OUT OF ORDER/);

    const stale = io({ MOVVA_DESK_CONFIG: '/desk.json' }, { '/desk.json': JSON.stringify({ withdrawDailyLimitBps: 200 }) });
    expect(await runDesk(['shock', '--snapshot', join(EXAMPLES, 'reserve-at-target.json'), '--text'], stale.d)).toBe(0);
    expect(stale.out.join('').match(/configured 24h limit \(2.00%\) differs from the reserve's hedgeLimitBps \(8.00%\)/g)).toHaveLength(1);
  });

  it('plans a hedge from a positions file', async () => {
    const t = io(env);
    expect(await runDesk(['hedge-plan', '--snapshot', join(EXAMPLES, 'reserve-at-target.json'), '--positions', join(EXAMPLES, 'positions.json'), '--text'], t.d)).toBe(0);
    expect(t.out.join('')).toMatch(/short US\$ 1,850,000.00 = 99.90% \(band ±2.00%: inside\)\nno orders/);
  });

  it('exits 3 with the reason when a withdrawal is refused, and plans one that fits as calldata', async () => {
    const refused = io(env);
    expect(await runDesk(['withdraw-plan', '--snapshot', join(EXAMPLES, 'reserve-at-floor.json')], refused.d)).toBe(3);
    expect(refused.err.join()).toMatch(/refused: nothing can be withdrawn/);
    const ok = io({ ...env, CHAIN_ID: '1' });
    expect(await runDesk(['withdraw-plan', '--snapshot', join(EXAMPLES, 'reserve-at-target.json'), '--safe'], ok.d)).toBe(0);
    const j = ok.json() as {
      plan: { amountUsdt: string; binding: string; hedgeTreasury: string; warnings: string[]; transactions: { data: string }[] };
      safeBatch: { chainId: string; transactions: unknown[] }; simulation: string;
    };
    // At 108% the floor after the 0.5% buffer binds under the 160,000 bucket: 2,000,000 - 10,300,000 / 5.373.
    expect(j.plan.amountUsdt).toBe('83007630746');
    expect(j.plan.binding).toBe('floor');
    expect(j.plan.hedgeTreasury.toLowerCase()).toBe('0x00000000000000000000000000000000000000b1');
    expect(j.plan.warnings.join()).not.toMatch(/exposes no view/);
    expect(j.plan.transactions[0].data).toMatch(/^0x/);
    expect(j.safeBatch.chainId).toBe('1');
    expect(j.simulation).toMatch(/offline/);
  });

  it('refuses usage it does not understand, with exit 2', async () => {
    expect(await runDesk(['frobnicate'], io(env).d)).toBe(2);
    expect(await runDesk(['shock', '--nope'], io(env).d)).toBe(2);
    expect(await runDesk([], io(env).d)).toBe(2);
    const noRpc = io({});
    expect(await runDesk(['snapshot'], noRpc.d)).toBe(2);
    expect(noRpc.err.join()).toMatch(/RPC_URL is required/);
  });
});

describe('movva-desk against a chain', () => {
  it('signs a statement into the store, verifies it, and reports on it', async () => {
    const dir = mkdtempSync(join(tmpdir(), 'movva-desk-'));
    try {
      const f = chainAt108();
      const env = {
        RPC_URL: RPC, MOVVA_RESERVE: RESERVE, MOVVA_STATEMENT_DIR: dir, MOVVA_STATEMENT_ISSUER: ISSUER,
        MOVVA_DESK_CONFIG: join(EXAMPLES, 'desk.json'), MOVVA_STATEMENT_KEY_FILE: '/run/secrets/statement',
      };
      const files = { '/run/secrets/statement': `${KEY}\n`, '/docs/broker.pdf': '%PDF broker' };
      const sign = io(env, files, f);
      const code = await runDesk(['statement', 'sign', '--positions', join(EXAMPLES, 'positions.json'), '--broker-doc', '/docs/broker.pdf',
        '--margin-balance', '999000.00', '--margin-required', '999000'], sign.d);
      expect(sign.err.join()).not.toMatch(/Error/);
      expect(code).toBe(0);
      const doc = sign.json() as { message: { sequence: string; netShortUsdE6: string; issuer: string }; hash: string };
      expect(doc.message).toMatchObject({ sequence: '1', netShortUsdE6: '1850000000000', issuer: ISSUER });
      expect(sign.err.join()).toMatch(/wrote .*statement-000000000001.json/);
      expect(sign.out.join()).not.toContain(KEY.slice(2));

      const verify = io(env, {}, f);
      expect(await runDesk(['statement', 'verify'], verify.d)).toBe(0);
      expect(verify.json()).toMatchObject({ valid: true, checks: { signature: 'ok', snapshot: 'ok' } });

      // The day after, a second statement links to the first.
      f.at(800n, { rate: R540, updatedAt: 1_789_009_000n, totalUsdt: usdtForRatio(10_800n, L10M, R540), liabilitiesBrlE18: L10M });
      const sign2 = io(env, files, f, 1_789_020_000);
      expect(await runDesk(['statement', 'sign', '--positions', join(EXAMPLES, 'positions.json'), '--broker-doc', '/docs/broker.pdf',
        '--margin-balance', '999000', '--margin-required', '999000'], sign2.d)).toBe(0);
      expect((sign2.json() as { message: { previousStatementHash: string } }).message.previousStatementHash).toBe(doc.hash);

      const report = io(env, {}, f, 1_789_020_100);
      expect(await runDesk(['report', '--text'], report.d)).toBe(0);
      expect(report.out.join('')).toMatch(/Statement         #2, .* verified/);
      expect(report.out.join('')).toMatch(/If the hedge holds 108.00%/);
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });

  /** Friday night on a PythFxOracle leg: the snapshot shows the close, the report prices at it and says so, plans refuse. */
  it('while the FX market is closed, shows the band\'s last close, reports at it labelled, and refuses to plan', async () => {
    const f = new FakeReserve().at(700n, {
      rate: R540, updatedAt: 1_789_008_000n, totalUsdt: usdtForRatio(10_800n, L10M, R540), liabilitiesBrlE18: L10M, closed: true,
    });
    const env = { RPC_URL: RPC, MOVVA_RESERVE: RESERVE };
    const snap = io(env, {}, f);
    expect(await runDesk(['snapshot', '--text'], snap.d)).toBe(0);
    expect(snap.out.join('')).toMatch(/rate {11}REFUSED: StaleRate\(1789008000\)\nband {11}R\$ 5,4000 per USDT - the last close: the FX market is closed/);

    const text = io(env, {}, f);
    expect(await runDesk(['report', '--text'], text.d)).toBe(0);
    expect(text.out.join('')).toMatch(/Rate {14}R\$ 5,4000 per USDT - the LAST CLOSE, as the band reads it: the FX market is closed/);
    expect(text.out.join('')).toMatch(/Reserve ratio {5}108.00%/);
    expect(text.err.join('')).toMatch(/the FX market is closed \(StaleRate\(1789008000\)\): reporting at the band's last close, R\$ 5,4000 per USDT/);
    const json = io(env, {}, f);
    expect(await runDesk(['report'], json.d)).toBe(0);
    expect(json.json()).toMatchObject({ snapshot: { rateSource: 'band', brlPerUsdtE18: R540.toString() } });

    // Sizing a hedge waits for the live rate, and says why.
    const plan = io(env, {}, f);
    expect(await runDesk(['hedge-plan', '--positions', join(EXAMPLES, 'positions.json')], plan.d)).toBe(1);
    expect(plan.err.join('')).toMatch(/the FX market is closed. Its band reads the last close, R\$ 5,4000 per USDT, but hedges, withdrawals/);
    // A report on a live rate says so as well.
    const live = io(env, {}, chainAt108());
    expect(await runDesk(['report'], live.d)).toBe(0);
    expect(live.json()).toMatchObject({ snapshot: { rateSource: 'rate' } });
  });

  /** readHedgeWithdrawals is the fallback: a reserve that answers hedgeWithdrawable() is not asked for logs. */
  it('counts WithdrawnToHedge events only for a reserve without the hedge views', async () => {
    const env = { RPC_URL: RPC, MOVVA_RESERVE: RESERVE };
    const run = async (f: FakeReserve) => {
      let logs = 0;
      const client = f.client();
      const t = io(env, {}, undefined);
      t.d.client = () => ({ ...client, getLogs: async (a: never) => { logs += 1; return client.getLogs(a); } });
      expect(await runDesk(['shock', '--move', '1000'], t.d)).toBe(0);
      return { logs, json: t.json() as { limitSource: string; results: { marginCall: { dailyMaxUsdt: string } }[] } };
    };
    const without = await run(chainAt108());
    expect(without.logs).toBe(1);
    expect(without.json.limitSource).toBe('configuration');
    const f = chainAt108();
    for (const [k, v] of f.states) f.states.set(k, { ...v, hedge: { withdrawableUsdt: 12_000_000_000n, limitBps: 800 } });
    const withViews = await run(f);
    expect(withViews.logs).toBe(0);
    expect(withViews.json.limitSource).toBe('reserve');
    expect(withViews.json.results[0].marginCall.dailyMaxUsdt).toBe('12000000000');
  });

  it('exits 1 on a statement that does not verify', async () => {
    const dir = mkdtempSync(join(tmpdir(), 'movva-desk-'));
    try {
      const f = chainAt108();
      const env = { RPC_URL: RPC, MOVVA_RESERVE: RESERVE, MOVVA_STATEMENT_DIR: dir, MOVVA_STATEMENT_KEY: KEY };
      const sign = io(env, { '/b': 'x' }, f);
      expect(await runDesk(['statement', 'sign', '--positions', join(EXAMPLES, 'positions.json'), '--broker-doc', '/b', '--margin-balance', '0', '--margin-required', '0'], sign.d)).toBe(0);
      const stranger = privateKeyToAccount(`0x${'43'.repeat(32)}`).address;
      const verify = io({ ...env, MOVVA_STATEMENT_ISSUER: stranger }, {}, f);
      expect(await runDesk(['statement', 'verify'], verify.d)).toBe(1);
      expect(verify.json()).toMatchObject({ valid: false });
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });

  /** viem puts the RPC URL, API key included, into every transport error. */
  it('redacts the RPC key and the statement key from everything it prints', async () => {
    const t = io({ RPC_URL: RPC, MOVVA_RESERVE: RESERVE, MOVVA_STATEMENT_KEY: KEY });
    expect(await runDesk(['snapshot'], t.d)).toBe(1);
    const all = t.out.join('') + t.err.join('');
    expect(all).toMatch(/could not reach https:\/\/eth-mainnet.g.alchemy.com\/\[redacted\]/);
    expect(all).not.toContain('AbCdEfGhIjKlMnOp0123456789');
  });
});

describe('desk configuration', () => {
  it('defaults every policy number, and reads overrides', () => {
    const cfg = deskConfigFromEnv({}, () => '');
    expect(cfg).toMatchObject({ hedgeBandBps: 200, withdrawDailyLimitBps: 800, executionBufferBps: 50, initialMarginBps: 1_000, conversionCostBps: 30, stressMoveBps: 1_000 });
    expect(cfg.instruments.map((i) => [i.symbol, i.contractSizeUsd])).toEqual([['DOL', 50_000n], ['WDO', 10_000n]]);
    const custom = deskConfigFromEnv({ MOVVA_DESK_CONFIG: '/c' }, () => JSON.stringify({ hedgeBandBps: 300, instruments: [{ symbol: 'WDO', contractSizeUsd: '10000' }] }));
    expect(custom.hedgeBandBps).toBe(300);
    expect(custom.instruments[0].source).toMatch(/confirm with the broker/);
  });

  it('collects every problem without echoing values', () => {
    try {
      deskConfigFromEnv({ RPC_URL: 'ws://secret-host/key', MOVVA_RESERVE: 'nope', MOVVA_DESK_CONFIG: '/c' }, () => JSON.stringify({ hedgeBandBps: 10_000, instruments: [{ symbol: 'wdo', contractSizeUsd: 0 }] }));
      throw new Error('expected a ConfigError');
    } catch (e) {
      expect(e).toBeInstanceOf(ConfigError);
      const p = (e as ConfigError).problems.join('\n');
      expect(p).toMatch(/RPC_URL must be an http/);
      expect(p).toMatch(/MOVVA_RESERVE must be an address/);
      expect(p).toMatch(/hedgeBandBps/);
      expect(p).toMatch(/instruments\[0\]\.symbol/);
      expect(p).not.toContain('secret-host');
    }
  });

  it('reads the statement key only when asked, and redacts it from then on', () => {
    const cfg = deskConfigFromEnv({ MOVVA_STATEMENT_KEY_FILE: '/k' }, () => '');
    expect(cfg.secrets).toEqual([]);
    expect(statementKeyFromEnv({ MOVVA_STATEMENT_KEY_FILE: '/k' }, () => `${KEY}\n`, cfg)).toBe(KEY);
    expect(cfg.secrets).toContain(KEY);
    expect(() => statementKeyFromEnv({ MOVVA_STATEMENT_KEY: KEY, MOVVA_STATEMENT_KEY_FILE: '/k' }, () => KEY, cfg)).toThrow(/not both/);
    expect(() => statementKeyFromEnv({ MOVVA_STATEMENT_KEY: '0x12' }, () => '', cfg)).toThrow(/32-byte/);
  });
});
