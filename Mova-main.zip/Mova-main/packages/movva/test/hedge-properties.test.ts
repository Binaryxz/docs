import { describe, expect, it } from 'vitest';
import fc from 'fast-check';
import {
  DEFAULT_INSTRUMENTS, hedgeRatioBps, netShortUsdE6, planHedge, recommendFreeMargin, shock, usdtForRatio, withinBand, type Position,
} from '../src/hedge.js';
import { modelSnapshot } from '../src/reserve.js';
import { BPS, E6 } from '../src/units.js';

/**
 * Invariants of the hedge math, over arbitrary books, targets and moves.
 *
 * The failures these guard against are quiet ones: a hedge one WDO short after rounding does not
 * throw, it leaves US$ 10,000 of the reserve exposed until someone reads the statement; a shock that
 * is not symmetric overstates one side's coverage and understates the other's.
 */

const arbPosition = fc.record({
  instrument: fc.constantFrom('DOL', 'WDO'),
  side: fc.constantFrom('short' as const, 'long' as const),
  contracts: fc.bigInt({ min: 1n, max: 2_000n }),
}).map((p): Position => ({ ...p, ticker: `${p.instrument}V26`, expiry: '2026-10-01', averagePriceBrlPerUsdE6: 5_400_000n }));

const arbBook = fc.array(arbPosition, { maxLength: 6 });
/** Up to US$ 500 million to hedge, in micro-dollars. */
const arbTarget = fc.oneof(fc.constant(0n), fc.bigInt({ min: 1n, max: 500_000_000n * E6 }));
const arbBand = fc.integer({ min: 0, max: 2_000 });

const applyOrders = (h: bigint, plan: ReturnType<typeof planHedge>) =>
  plan.orders.reduce((a, o) => a + (o.side === 'sell' ? 1n : -1n) * o.notionalUsdE6, h);

describe('hedge ratio', () => {
  it('is the short over the target, toward zero, and 100% exactly at the target', () => {
    fc.assert(fc.property(fc.bigInt({ min: 0n, max: 10n ** 16n }), fc.bigInt({ min: 1n, max: 10n ** 16n }), (h, t) => {
      const r = hedgeRatioBps(h, t)!;
      expect(r * t <= h * BPS).toBe(true);
      expect(h * BPS < (r + 1n) * t).toBe(true);
      expect(hedgeRatioBps(t, t)).toBe(BPS);
    }));
  });

  it('agrees with the band test at the band edges', () => {
    fc.assert(fc.property(fc.bigInt({ min: 1n, max: 10n ** 16n }), arbBand, (t, band) => {
      // Exactly at the floor and the ceiling (when representable), inside; one below the floor, outside.
      const floor = (t * (BPS - BigInt(band)) + BPS - 1n) / BPS;
      expect(withinBand(floor, t, band)).toBe(true);
      if (floor > 0n && (floor - 1n) * BPS < t * (BPS - BigInt(band))) expect(withinBand(floor - 1n, t, band)).toBe(false);
    }));
  });
});

describe('rebalancing', () => {
  it('never leaves the hedge under the band floor, and lands inside the band whenever a contract fits', () => {
    fc.assert(fc.property(arbTarget, arbBook, arbBand, (target, book, band) => {
      const policy = { instruments: DEFAULT_INSTRUMENTS, bandBps: band };
      const h = netShortUsdE6(book, DEFAULT_INSTRUMENTS);
      const plan = planHedge({ targetUsdE6: target, positions: book, policy });
      expect(plan.currentUsdE6).toBe(h);
      expect(plan.afterUsdE6).toBe(applyOrders(h, plan));
      // The floor: T x (1 - band), for any target including zero.
      expect(plan.afterUsdE6 * BPS >= target * (BPS - BigInt(band))).toBe(true);
      if (plan.bandAchievable) expect(withinBand(plan.afterUsdE6, target, band)).toBe(true);
      if (plan.withinBand) expect(plan.orders).toEqual([]);
      for (const o of plan.orders) expect(o.contracts > 0n).toBe(true);
    }), { numRuns: 500 });
  });

  it('is stable: re-planning the book it produced asks for nothing more', () => {
    fc.assert(fc.property(arbTarget, arbBook, arbBand, (target, book, band) => {
      const policy = { instruments: DEFAULT_INSTRUMENTS, bandBps: band };
      const plan = planHedge({ targetUsdE6: target, positions: book, policy });
      fc.pre(plan.afterWithinBand);
      const next: Position[] = [...book, ...plan.orders.map((o): Position => ({
        instrument: o.instrument, ticker: `${o.instrument}V26`, expiry: '2026-10-01',
        side: o.side === 'sell' ? 'short' : 'long', contracts: o.contracts, averagePriceBrlPerUsdE6: 5_400_000n,
      }))];
      expect(planHedge({ targetUsdE6: target, positions: next, policy }).orders).toEqual([]);
    }), { numRuns: 300 });
  });

  it('trades no more than one smallest contract beyond the distance to the target', () => {
    fc.assert(fc.property(arbTarget, arbBook, arbBand, (target, book, band) => {
      const plan = planHedge({ targetUsdE6: target, positions: book, policy: { instruments: DEFAULT_INSTRUMENTS, bandBps: band } });
      const traded = plan.orders.reduce((a, o) => a + o.notionalUsdE6, 0n);
      const distance = target > plan.currentUsdE6 ? target - plan.currentUsdE6 : plan.currentUsdE6 - target;
      expect(traded <= distance + 10_000n * E6).toBe(true);
    }), { numRuns: 300 });
  });
});

describe('shocks', () => {
  const arbReserve = fc.record({
    rate: fc.bigInt({ min: 10n ** 18n, max: 100n * 10n ** 18n }),
    liabilities: fc.bigInt({ min: 10n ** 18n, max: 10n ** 28n }),
    ratioBps: fc.bigInt({ min: 5_000n, max: 20_000n }),
    hedgeBps: fc.bigInt({ min: 0n, max: 15_000n }),
  });

  it('is symmetric: +m and -m move the reserve and the short by exact opposites', () => {
    fc.assert(fc.property(arbReserve, fc.integer({ min: 1, max: 9_999 }), fc.integer({ min: 0, max: 5_000 }), (r, m, im) => {
      const snapshot = modelSnapshot({ brlPerUsdtE18: r.rate, totalUsdt: usdtForRatio(r.ratioBps, r.liabilities, r.rate), liabilitiesBrlE18: r.liabilities });
      const hedge = snapshot.liabilitiesUsdt * r.hedgeBps / BPS;
      const up = shock({ snapshot, hedgeShortUsdE6: hedge, moveBps: m, assumptions: { initialMarginBps: im } });
      const down = shock({ snapshot, hedgeShortUsdE6: hedge, moveBps: -m, assumptions: { initialMarginBps: im } });
      expect(up.rate.afterE18 - up.rate.beforeE18).toBe(-(down.rate.afterE18 - down.rate.beforeE18));
      expect(up.reserve.changeBrlE18).toBe(-down.reserve.changeBrlE18);
      expect(up.hedge.variationBrlE18).toBe(-down.hedge.variationBrlE18);
      expect(up.hedge.initialMarginChangeBrlE18).toBe(-down.hedge.initialMarginChangeBrlE18);
      expect(up.hedge.cashFlowBrlE18).toBe(-down.hedge.cashFlowBrlE18);
    }), { numRuns: 500 });
  });

  it('without costs or free margin, the call a rally makes is the cash the same fall releases', () => {
    fc.assert(fc.property(arbReserve, fc.integer({ min: 1, max: 9_999 }), (r, m) => {
      const snapshot = modelSnapshot({ brlPerUsdtE18: r.rate, totalUsdt: usdtForRatio(r.ratioBps, r.liabilities, r.rate), liabilitiesBrlE18: r.liabilities });
      const hedge = snapshot.liabilitiesUsdt * r.hedgeBps / BPS;
      const assumptions = { initialMarginBps: 1_000, conversionCostBps: 0 };
      const up = shock({ snapshot, hedgeShortUsdE6: hedge, moveBps: m, assumptions });
      const down = shock({ snapshot, hedgeShortUsdE6: hedge, moveBps: -m, assumptions });
      expect(up.marginCall.needBrlE18).toBe(down.hedge.cashFlowBrlE18);
      expect(down.marginCall.needBrlE18).toBe(0n);
    }), { numRuns: 300 });
  });

  it('a fully hedged reserve at 100% gains exactly what the short loses, up to rounding', () => {
    fc.assert(fc.property(arbReserve, fc.integer({ min: -5_000, max: 9_999 }), (r, m) => {
      const snapshot = modelSnapshot({ brlPerUsdtE18: r.rate, totalUsdt: usdtForRatio(BPS, r.liabilities, r.rate), liabilitiesBrlE18: r.liabilities });
      const s = shock({ snapshot, hedgeShortUsdE6: snapshot.liabilitiesUsdt, moveBps: m, assumptions: { initialMarginBps: 0 } });
      const net = s.reserve.changeBrlE18 + s.hedge.variationBrlE18;
      // One micro-USDT of rounding on each side, at the shocked rate.
      const tolerance = 2n * (s.rate.afterE18 > s.rate.beforeE18 ? s.rate.afterE18 : s.rate.beforeE18) / E6 + 2n;
      expect(net < 0n ? -net : net).toBeLessThanOrEqual(tolerance);
    }), { numRuns: 300 });
  });

  it('a larger rally never needs less margin, nor lets less be withdrawn under the floor', () => {
    fc.assert(fc.property(arbReserve, fc.integer({ min: 1, max: 5_000 }), fc.integer({ min: 1, max: 5_000 }), (r, a, b) => {
      const [lo, hi] = a < b ? [a, b] : [b, a];
      const snapshot = modelSnapshot({ brlPerUsdtE18: r.rate, totalUsdt: usdtForRatio(r.ratioBps, r.liabilities, r.rate), liabilitiesBrlE18: r.liabilities });
      const hedge = snapshot.liabilitiesUsdt * r.hedgeBps / BPS;
      const x = shock({ snapshot, hedgeShortUsdE6: hedge, moveBps: lo });
      const y = shock({ snapshot, hedgeShortUsdE6: hedge, moveBps: hi });
      expect(y.marginCall.needBrlE18 >= x.marginCall.needBrlE18).toBe(true);
      expect(y.marginCall.floorMaxUsdt >= x.marginCall.floorMaxUsdt).toBe(true);
    }), { numRuns: 300 });
  });
});

describe('standing free margin', () => {
  const arb = fc.record({
    rate: fc.bigInt({ min: 10n ** 18n, max: 100n * 10n ** 18n }),
    liabilities: fc.bigInt({ min: 10n ** 18n, max: 10n ** 28n }),
    ratioBps: fc.bigInt({ min: 9_000n, max: 20_000n }),
    hedgeBps: fc.bigInt({ min: 0n, max: 15_000n }),
    stress: fc.integer({ min: 1, max: 5_000 }),
    /** The reserve's bucket as a share of its full day, or undefined for a reserve without the views. */
    bucketBps: fc.option(fc.bigInt({ min: 0n, max: 10_000n }), { nil: undefined }),
  });

  it('is never below the repriced figure, and each exactly closes its own gap', () => {
    fc.assert(fc.property(arb, (r) => {
      const totalUsdt = usdtForRatio(r.ratioBps, r.liabilities, r.rate);
      const base = modelSnapshot({ brlPerUsdtE18: r.rate, totalUsdt, liabilitiesBrlE18: r.liabilities });
      const snapshot = r.bucketBps === undefined ? base : {
        ...base, hedge: { withdrawableUsdt: totalUsdt * 800n / BPS * r.bucketBps / BPS, limitBps: 800, treasury: base.movva, treasurer: base.movva },
      };
      const hedge = snapshot.liabilitiesUsdt * r.hedgeBps / BPS;
      const rec = recommendFreeMargin({ snapshot, hedgeShortUsdE6: hedge, stressMoveBps: r.stress });
      expect(rec.freeMarginBrlE18 >= rec.freeMarginIfRepricedBrlE18).toBe(true);
      // Conservative basis: free margin plus what the reserve releases now meets the call, with nothing to spare.
      expect(rec.freeMarginBrlE18 + rec.releasableNowBrlE18 >= rec.needBrlE18).toBe(true);
      if (rec.freeMarginBrlE18 > 0n) expect(rec.freeMarginBrlE18 + rec.releasableNowBrlE18).toBe(rec.needBrlE18);
      // Repriced basis: exactly enough for shock() to leave no margin-call shortfall. (Not `covered`,
      // which also asks for full backing: a reserve already under 100% is not covered by any margin.)
      const covered = (free: bigint) => shock({
        snapshot, hedgeShortUsdE6: hedge, moveBps: r.stress, margin: { balanceBrlE18: free, requiredBrlE18: 0n },
      }).marginCall.shortfallBrlE18 === 0n;
      expect(covered(rec.freeMarginIfRepricedBrlE18)).toBe(true);
      if (rec.freeMarginIfRepricedBrlE18 > 0n) expect(covered(rec.freeMarginIfRepricedBrlE18 - 1n)).toBe(false);
    }), { numRuns: 300 });
  });
});
