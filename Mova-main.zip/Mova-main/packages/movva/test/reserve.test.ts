import { describe, expect, it } from 'vitest';
import { decodeFunctionData } from 'viem';
import { MOVVA_RESERVE_ABI, ERC20_ABI } from '../src/abi.js';
import { usdtForRatio, ratioBps } from '../src/hedge.js';
import { toJson } from '../src/json.js';
import {
  ReserveUnpriced, atLastClose, readHedgeWithdrawals, readReserveSnapshot, requirePriced, snapshotFromJson, type PricedSnapshot,
} from '../src/reserve.js';
import { planRecapitalize, planWithdrawToHedge, safeTransactionBatch, simulateWithdrawToHedge } from '../src/treasury.js';
import { FakeReserve, L10M, R540, RESERVE, USDT, blockHash } from './fake-reserve.js';

const at = (ratio: bigint, extra: Partial<Parameters<FakeReserve['at']>[1]> = {}) =>
  new FakeReserve().at(100n, { rate: R540, updatedAt: 1_789_001_000n, totalUsdt: usdtForRatio(ratio, L10M, R540), liabilitiesBrlE18: L10M, ...extra });

describe('reading the reserve', () => {
  it('reads every figure at one pinned block, and finds them consistent', async () => {
    const f = at(11_000n);
    f.at(101n, { rate: 5_500_000_000_000_000_000n, updatedAt: 1n, totalUsdt: 1n, liabilitiesBrlE18: 1n }); // a later block that must not leak in
    const s = requirePriced(await readReserveSnapshot(f.client(), RESERVE, { blockNumber: 100n }));
    expect(s).toMatchObject({
      blockNumber: 100n, blockHash: blockHash(100n), usdt: USDT, totalUsdt: 2_037_037_037_038n, liabilitiesUsdt: 1_851_851_851_851n,
      collateralRatioBps: 11_000n, thresholds: { targetCollateralRatioBps: 10_800, minWithdrawCollateralRatioBps: 10_300 },
    });
    expect(s.inconsistencies).toEqual([]);
    expect(f.calls.every((c) => c.endsWith('@100'))).toBe(true);
  });

  it('pins "latest" to a block number before reading', async () => {
    const f = at(10_200n);
    const s = await readReserveSnapshot(f.client(), RESERVE);
    expect(s.blockNumber).toBe(100n);
    expect(f.calls.every((c) => c.endsWith('@100'))).toBe(true);
  });

  /** A stale rate is the reserve refusing, not the read failing: a state, with what can still be read. */
  it('returns an unpriced snapshot naming the refusal when the rate is stale', async () => {
    const s = await readReserveSnapshot(at(10_200n, { stale: true }).client(), RESERVE);
    expect(s.priced).toBe(false);
    if (s.priced) return;
    expect(s.refusal).toMatch(/^StaleLeg\(0x/);
    expect(s.totalUsdt).toBe(1_888_888_888_889n);
    expect(() => requirePriced(s)).toThrow(ReserveUnpriced);
  });

  /** Friday night on a PythFxOracle leg: the rate refuses, the band serves the close. Shown and reported, never planned from. */
  it('carries the band\'s last close beside a closed-market refusal, which plans refuse and a report can price at', async () => {
    const f = at(10_800n, { closed: true });
    const s = await readReserveSnapshot(f.client(), RESERVE);
    expect(s).toMatchObject({ priced: false, refusal: 'StaleRate(1789001000)', band: { brlPerUsdtE18: R540, updatedAt: f.timestamp(100n) } });
    if (s.priced) return;
    expect(() => requirePriced(s)).toThrow(ReserveUnpriced);
    expect(() => requirePriced(s)).toThrow(/the FX market is closed. Its band reads the last close, R\$ 5,4000 per USDT, but hedges, withdrawals, recapitalizations and statements are sized at the live rate only/);
    const close = atLastClose(s);
    expect(close).toMatchObject({ priced: true, brlPerUsdtE18: R540, rateUpdatedAt: f.timestamp(100n), collateralRatioBps: 10_800n, liabilitiesUsdt: 1_851_851_851_852n });
    expect(close.inconsistencies).toEqual([]);
    expect(snapshotFromJson(JSON.parse(toJson(s)))).toEqual(s);
    // A stale leg refuses the band too, and a reserve from before the band has none: nothing to show, nothing to price at.
    expect(await readReserveSnapshot(at(10_800n, { stale: true }).client(), RESERVE)).not.toHaveProperty('band');
    const old = await readReserveSnapshot(at(10_800n, { closed: true, noBand: true }).client(), RESERVE);
    expect(old).not.toHaveProperty('band');
    expect(() => atLastClose(old as never)).toThrow(/Nothing that depends on the rate can be planned/);
  });

  it('throws on a read that fails, rather than calling it a refusal', async () => {
    const client = { ...at(10_200n).client(), readContract: async () => { throw new Error('HTTP request failed'); } };
    await expect(readReserveSnapshot(client, RESERVE)).rejects.toThrow(/HTTP request failed/);
  });

  it('notices when the reserve\'s derived figures disagree with its inputs', async () => {
    const s = requirePriced(await readReserveSnapshot(at(10_200n, { reserveBrlSkew: 10n ** 21n }).client(), RESERVE));
    expect(s.inconsistencies.join('\n')).toMatch(/reserveBrlE18 is .* but totalUsdt x rate is/);
  });

  it('round-trips through JSON, recomputing consistency instead of trusting the file', async () => {
    const s = requirePriced(await readReserveSnapshot(at(10_200n).client(), RESERVE));
    const back = snapshotFromJson(JSON.parse(toJson(s)));
    expect(back).toEqual(s);
    const edited = JSON.parse(toJson({ ...s, liabilitiesUsdt: 1n, inconsistencies: [] }));
    expect(requirePriced(snapshotFromJson(edited)).inconsistencies.join()).toMatch(/liabilitiesUsdt is 1/);
    expect(() => snapshotFromJson({ ...edited, totalUsdt: 5 })).not.toThrow(); // small numbers are fine
    expect(() => snapshotFromJson({ ...edited, totalUsdt: '1.5' })).toThrow(/totalUsdt must be/);
  });

  /** An offline plan must use the reserve's own limit exactly as a live one would. */
  it('keeps the reserve\'s hedge views through JSON', async () => {
    const f = at(10_800n);
    for (const [k, v] of f.states) f.states.set(k, { ...v, hedge: { withdrawableUsdt: 99_000_000n, limitBps: 800 } });
    const s = requirePriced(await readReserveSnapshot(f.client(), RESERVE));
    const back = snapshotFromJson(JSON.parse(toJson(s)));
    expect(back.hedge).toEqual(s.hedge);
    expect(back.hedge?.withdrawableUsdt).toBe(99_000_000n);
    expect(() => snapshotFromJson({ ...JSON.parse(toJson(s)), hedge: { limitBps: 800 } })).toThrow(/snapshot.hedge.withdrawableUsdt/);
  });

  it('counts withdrawals to the hedge in the last 24h by block time', async () => {
    const f = at(11_000n);
    f.head = 10_000n;
    f.withdrawals.push({ blockNumber: 2_700n, usdt: 5n }, { blockNumber: 2_900n, usdt: 7n }, { blockNumber: 9_999n, usdt: 11n });
    // head at 10,000 x 12s; 24h is 7,200 blocks: block 2,800 is the edge. 2,700 is outside, 2,900 inside.
    const w = await readHedgeWithdrawals(f.client(), RESERVE, { toBlock: 10_000n, toTimestamp: f.timestamp(10_000n) });
    expect(w.totalUsdt).toBe(18n);
    expect(w.withdrawals.map((x) => x.blockNumber)).toEqual([2_900n, 9_999n]);
  });
});

describe('planning withdrawToHedge', () => {
  const snap = async (ratio: bigint) => requirePriced(await readReserveSnapshot(at(ratio).client(), RESERVE));

  /**
   * At 120%, against a reserve without the hedge views (the configured fallback, 8%):
   * 12,000,000 / 5.40 = 2,222,222.222223 USDT. The 24h limit is 8% = 177,777.777777 USDT; the 103%
   * floor allows 2,222,222.222223 - 10,300,000 / 5.40 = 314,814.814815 (305,229.85 at 5.40 x 0.995).
   * The limit binds. After: 2,044,444.444446 x 5.40 / 10M = 110.40%.
   */
  it('takes the most the 24h limit allows when the floor is looser', async () => {
    const p = planWithdrawToHedge(await snap(12_000n));
    expect(p.limits.dailyMaxUsdt).toBe(177_777_777_777n);
    expect(p.limits.floorMaxUsdt).toBe(314_814_814_815n);
    expect(p.limits.dailyLimitBps).toBe(800);
    expect(p.binding).toBe('daily-limit');
    expect(p.amountUsdt).toBe(177_777_777_777n);
    expect(p.ratio.afterBps).toBe(11_040n);
    const call = decodeFunctionData({ abi: MOVVA_RESERVE_ABI, data: p.transactions[0].data });
    expect(call).toEqual({ functionName: 'withdrawToHedge', args: [177_777_777_777n] });
    expect(p.transactions[0].to).toBe(RESERVE);
  });

  it('stops exactly at the floor, after the execution buffer, when the floor binds', async () => {
    const s = await snap(11_000n);
    // At 110% the 8% bucket (162,962.96) is looser than the floor after the buffer (120,044.67).
    const p = planWithdrawToHedge(s);
    expect(p.binding).toBe('floor');
    expect(p.amountUsdt).toBe(120_044_667_784n);
    expect(p.ratio.afterAtBufferedRateBps).toBeGreaterThanOrEqual(10_300n);
    // One more micro-USDT would breach the floor at the buffered rate: the amount is tight.
    expect(ratioBps(s.totalUsdt - p.amountUsdt - 1n, s.liabilitiesBrlE18, p.bufferedRateBrlPerUsdtE18)).toBeLessThan(10_300n);
  });

  it('refuses rather than trims an amount above the limit, and refuses at the withdraw floor', async () => {
    const over = planWithdrawToHedge(await snap(12_000n), { amountUsdt: 200_000_000_000n });
    expect(over.refused).toMatch(/exceeds what may be withdrawn: at most 177,777.777777 USDT, bound by the 24h limit/);
    expect(over.transactions).toEqual([]);
    const none = planWithdrawToHedge(await snap(10_300n));
    expect(none.refused).toMatch(/nothing can be withdrawn: the reserve is at 103.00%, and the floor is 103.00%/);
    // At the 108% target there is margin to release: the review's point.
    expect(planWithdrawToHedge(await snap(10_800n)).amountUsdt).toBeGreaterThan(0n);
  });

  it('subtracts what was already withdrawn in the window, and warns the limit is not readable', async () => {
    // 177,777.777777 - 30,000 = 147,777.777777, still under the buffered floor at 120%.
    const p = planWithdrawToHedge(await snap(12_000n), { policy: { withdrawnInWindowUsdt: 30_000_000_000n } });
    expect(p.amountUsdt).toBe(147_777_777_777n);
    expect(p.warnings.join()).toMatch(/exposes no view/);
  });

  it('warns when the reserve\'s ratios are out of order', async () => {
    const legacy = requirePriced(await readReserveSnapshot(at(11_000n, { target: 10_200, minWithdraw: 10_500 }).client(), RESERVE));
    expect(planWithdrawToHedge(legacy).warnings.join()).toMatch(/RATIOS OUT OF ORDER: the withdraw floor 105.00% is above the target 102.00%/);
    expect(planRecapitalize(legacy).warnings.join()).toMatch(/RATIOS OUT OF ORDER/);
    expect(planWithdrawToHedge(await snap(11_000n)).warnings.join()).not.toMatch(/OUT OF ORDER/);
  });

  /** The reserve answers the limit itself (a refilling bucket); the plan uses that, not configuration. */
  it('uses the reserve\'s own withdrawable amount and treasury when it exposes them', async () => {
    const f = at(11_000n);
    const TREASURY = '0x00000000000000000000000000000000000000Dd';
    for (const [k, v] of f.states) f.states.set(k, { ...v, hedge: { withdrawableUsdt: 12_345_000_000n, limitBps: 800, treasury: TREASURY } });
    const s = requirePriced(await readReserveSnapshot(f.client(), RESERVE));
    expect(s.hedge?.withdrawableUsdt).toBe(12_345_000_000n);
    const p = planWithdrawToHedge(s, { policy: { dailyLimitBps: 9_000 } }); // configuration ignored
    expect(p.limits).toMatchObject({ dailyMaxUsdt: 12_345_000_000n, dailyLimitBps: 800 });
    expect(p.amountUsdt).toBe(12_345_000_000n);
    expect(p.warnings.join()).not.toMatch(/exposes no view/);
    expect(p.hedgeTreasury?.toLowerCase()).toBe(TREASURY.toLowerCase());
    const wrong = planWithdrawToHedge(s, { hedgeTreasury: '0x0000000000000000000000000000000000000001' });
    expect(wrong.warnings.join()).toMatch(/do not sign until that is explained/);
  });

  it('refuses to move USDT when the reserve\'s own figures disagree', async () => {
    const s: PricedSnapshot = { ...(await snap(11_000n)), inconsistencies: ['x'] };
    expect(planWithdrawToHedge(s).refused).toMatch(/do not agree/);
  });

  it('simulates from the treasurer and reports a revert by name', async () => {
    const f = at(11_000n);
    const p = planWithdrawToHedge(requirePriced(await readReserveSnapshot(f.client(), RESERVE)));
    expect(await simulateWithdrawToHedge(f.client(), p, USDT)).toEqual({ ok: true });
    f.simulateRevert = 'WithdrawLimitExceeded';
    expect(await simulateWithdrawToHedge(f.client(), p, USDT)).toEqual({ ok: false, reason: 'WithdrawLimitExceeded()' });
  });
});

describe('planning recapitalize', () => {
  const snap = async (ratio: bigint) => requirePriced(await readReserveSnapshot(at(ratio).client(), RESERVE));

  it('restores the target even after the buffer, zeroing a USDT allowance first', async () => {
    const s = await snap(9_690n);
    const p = planRecapitalize(s, { from: USDT, allowance: 5n, balance: 1_000_000n }); // 1 USDT held
    expect(p.binding).toBe('target');
    expect(p.ratio.afterAtBufferedRateBps).toBeGreaterThanOrEqual(10_800n);
    expect(ratioBps(s.totalUsdt + p.amountUsdt - 1n, s.liabilitiesBrlE18, p.bufferedRateBrlPerUsdtE18)).toBeLessThan(10_800n);
    expect(p.transactions.map((t) => t.call)).toEqual([
      `approve(${RESERVE}, 0)`, `approve(${RESERVE}, ${p.amountUsdt})`, `recapitalize(${p.amountUsdt})`,
    ]);
    expect(decodeFunctionData({ abi: ERC20_ABI, data: p.transactions[1].data }).args).toEqual([RESERVE, p.amountUsdt]);
    expect(p.transactions.slice(0, 2).every((t) => t.to === USDT)).toBe(true);
    expect(p.warnings.join()).toMatch(/holds .* less than/);
  });

  it('skips the zeroing when the allowance is known to be zero, and refuses when nothing is needed', async () => {
    expect(planRecapitalize(await snap(9_690n), { allowance: 0n }).transactions).toHaveLength(2);
    expect(planRecapitalize(await snap(11_000n)).refused).toMatch(/nothing to do/);
  });

  it('exports a Safe Transaction Builder batch', async () => {
    const p = planRecapitalize(await snap(9_690n), { allowance: 0n });
    const b = safeTransactionBatch(p.transactions, { chainId: 1, name: 'recap', description: 'd', createdAt: 1 });
    expect(b).toMatchObject({ version: '1.0', chainId: '1', meta: { name: 'recap' } });
    expect(b.transactions[1]).toEqual({ to: RESERVE, value: '0', data: p.transactions[1].data, contractMethod: null, contractInputsValues: null });
  });
});
