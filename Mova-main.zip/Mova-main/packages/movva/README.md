# @mova/movva

The issuer's hedge desk and reserve reporting for Movva, the BRL-pegged token backed by a USDT
reserve (docs/movva.md). The chain can see the reserve; it cannot see the short USD/BRL position
the issuer holds on B3 to turn that dollar reserve into a real one. This package makes the off-chain
half of the peg **correct** (the hedge and treasury arithmetic, in bigints) and **verifiable**
(signed, chained statements anyone can check against the reserve with an address and an RPC).

It holds no treasury key and sends no transaction. The only key it can read is the statement key,
and only `statement sign` reads it.

```
   IMovvaReserve (chain)                        broker statement (B3 positions, margin)
          │ reserve.ts: snapshot at one block             │ transcribed to positions.json, hashed
          ▼                                                ▼
   ┌──────────────┐   hedge.ts: target, ratio, orders,   ┌───────────────┐
   │  snapshot    │──▶ shocks, carry ◀────────────────────│  positions    │
   └──────┬───────┘                                       └──────┬────────┘
          │ treasury.ts: withdrawToHedge / recapitalize          │ statement.ts: EIP-712, signed,
          │ plans → calldata / Safe batch (multisig signs)       │ chained, snapshot-bound
          ▼                                                      ▼
   report.ts: reserve ratio · hedge ratio · backing if the hedge holds  → JSON + text, published
          │
          ▼  @mova/ops monitor: movva_collateral_ratio, movva_rate, movva_hedge_statement, movva_withdraw_headroom
```

## Modules

| File | What it does |
|---|---|
| `abi.ts` | `IMovvaReserve` transcribed (every function and event), plus the oracle-leg errors a stale rate bubbles up. `test/abi.test.ts` checks it against the compiled interface. |
| `units.ts` | Bigint fixed point: rounding that states its direction (a limit rounds toward safety, a shock toward zero so ±m are exact opposites), strict decimal parsing, display formatting. No floats touch money. |
| `reserve.ts` | `readReserveSnapshot`: every figure at one pinned block, with its hash; a stale rate is an `UnpricedSnapshot` naming the revert, not an exception; the reserve's derived figures are recomputed and any disagreement listed. `readHedgeWithdrawals`: `WithdrawnToHedge` in the last 24h, by block time. |
| `hedge.ts` | Instruments (B3 DOL US$ 50,000, WDO US$ 10,000 - **confirm with the broker**), hedge ratio, `planHedge` (integer contracts, a ±band, never under the band floor), `shock` (margin call vs `withdrawToHedge` under the floor and 24h limit; recapitalization vs hedge cash), `carry`, PTAX 2024 preset. |
| `treasury.ts` | `planWithdrawToHedge`, `planRecapitalize`: amount, ratio after (also after an execution buffer), which rule binds, unsigned calldata, a Safe Transaction Builder batch, `simulateWithdrawToHedge` from the treasurer's address. Refuses rather than trims. |
| `statement.ts` | The signed hedge statement: build, sign, publish as JSON, parse, verify (signature and domain, hash, arithmetic, chain link, freshness, snapshot against the chain). |
| `statement-store.ts` | One file per sequence, created exclusively and fsynced, plus an atomically replaced `latest.json` to publish. Refuses a fork, a gap and an overwrite. |
| `report.ts` | The backing report (JSON and text): reserve ratio, hedge ratio, backing if the hedge holds, and what none of them covers. |
| `config.ts` | Environment and JSON policy, secrets redacted. |
| `bin/movva-desk.ts` | The CLI. |
| `server.ts`, `bin/movva-desk-serve.ts` | The HTTP server for the web UI: `runDesk` per request, read-only and planning. |

## The statement

EIP-712, domain `{ name: "Movva Hedge Statement", version: "1", chainId, verifyingContract: <reserve> }`:

```
HedgeStatement(address issuer, uint64 sequence, uint64 asOf,
               uint64 reserveBlock, bytes32 reserveBlockHash, uint256 reserveBrlPerUsdtE18, uint256 reserveLiabilitiesUsdt,
               Position[] positions, int256 netShortUsdE6,
               int256 marginBalanceBrlCents, uint256 marginRequiredBrlCents,
               bytes32 brokerStatementSha256, bytes32 previousStatementHash)
Position(string instrument, string ticker, string expiry, string side,
         uint256 contracts, uint256 contractSizeUsd, uint256 averagePriceBrlPerUsdE6)
```

- The snapshot **figures** are signed, not only the block: a verifier with an archive node checks
  the reserve really had that rate and those liabilities at that block (and that block's hash).
- `netShortUsdE6` must equal the positions' sum; `marginBalanceBrlCents` is signed because a debit
  balance must be reportable.
- `previousStatementHash` is the EIP-712 hash of the previous statement (zero for sequence 1). A
  rewritten statement changes its hash and every later statement stops linking to it.
- Published as `{ "format": "movva-hedge-statement/v1", "domain", "message", "hash", "signature" }`
  with every integer a decimal string.

What a signature proves is **who** said it, not that it is **true**: positions and margin are the
issuer's claim, bound to the broker's document by SHA-256 for an auditor holding that document.

### Verifying a statement as a third party

```
RPC_URL=https://<archive node> MOVVA_RESERVE=0x… MOVVA_STATEMENT_ISSUER=0x<statement key address> \
  node --import tsx packages/movva/src/bin/movva-desk.ts statement verify latest.json --previous statement-000000000041.json
```

Exit 0 and `"valid": true` only when every check ran and passed; a snapshot that could not be read
is `unverifiable`, never assumed fine.

## CLI

```
RPC_URL=… MOVVA_RESERVE=0x… MOVVA_DESK_CONFIG=desk.json MOVVA_STATEMENT_DIR=/srv/movva/statements \
MOVVA_STATEMENT_ISSUER=0x… node --import tsx packages/movva/src/bin/movva-desk.ts <command>

snapshot        [--block N]                                    the reserve at one block
hedge-plan      [--positions F | --statement F] [--text]       orders to bring the hedge inside the band
shock           [--move 500,-500] [--days N] [...] [--text]    default: ±5%, ±10%, 2024 both ways
withdraw-plan   [--amount USDT] [--from TREASURER] [--safe]    exits 3 when refused
recap-plan      [--amount USDT] [--target-bps N] [--from SENDER] [--safe]
hedge-queue     [--block N]                                    the queued hedge withdrawals (needs the chain)
queue-plan      [--amount USDT] [--from TREASURER] [--safe]    queueHedgeWithdrawal; exits 3 when refused
execute-plan    --id N [--from SENDER] [--safe]                executeHedgeWithdrawal; exits 3 when refused
statement sign  --positions F --broker-doc F --margin-balance BRL --margin-required BRL [--as-of UNIX]
statement verify [F] [--previous F]                            exits 1 when not valid
report          [--statement F] [--text] [--out F]
```

`--snapshot F` (a saved `snapshot`) replaces the chain for planning, so plans can be made and
re-checked offline; `examples/` has two example reserves, a positions file and a desk policy:

```
MOVVA_DESK_CONFIG=packages/movva/examples/desk.json node --import tsx packages/movva/src/bin/movva-desk.ts \
  shock --snapshot packages/movva/examples/reserve-at-target.json --positions packages/movva/examples/positions.json --text
```

Environment: `RPC_URL` (secret: carries the provider key), `CHAIN_ID` (checked against the RPC;
required offline for signing), `MOVVA_RESERVE`, `MOVVA_STATEMENT_ISSUER`, `MOVVA_STATEMENT_DIR`,
`MOVVA_DESK_CONFIG`, `MOVVA_STATEMENT_KEY_FILE` (preferred) or `MOVVA_STATEMENT_KEY`. Everything
printed is passed through `@mova/ops` `redact` with RPC_URL, the key and every secret-shaped variable.

Policy (`MOVVA_DESK_CONFIG`, all optional): `reserve`, `issuer`, `hedgeTreasury`, `treasurer`,
`instruments` (`[{symbol, contractSizeUsd}]`), `tickers`, `hedgeBandBps` (200), `rollWithinDays`
(5), `withdrawDailyLimitBps` (200 - must match the deployed reserve), `executionBufferBps` (50),
`initialMarginBps` (1000 - an assumption, to confirm), `conversionCostBps` (30), `statementMaxAgeSeconds`
(93600), `statementDir`.

## Web UI

`src/server.ts` is the desk's HTTP surface for the desk UI, `mova-frontend`, which lives beside this
monorepo (`../mova-frontend`, outside the repository): read-only and planning, every route a
`runDesk` call in-process, no signing route and no statement key in its environment. Same variables as the CLI, plus
`MOVVA_DESK_HOST` (127.0.0.1), `MOVVA_DESK_PORT` (8990), `MOVVA_DESK_SNAPSHOT` (plan offline from a saved snapshot),
`MOVVA_DESK_POSITIONS` (positions to use while the store is empty) and `MOVVA_DESK_UI_DIR` (default `../mova-frontend/dist`):

```
(cd ../mova-frontend && npm install && npm run build)
RPC_URL=… MOVVA_RESERVE=0x… MOVVA_DESK_CONFIG=desk.json MOVVA_STATEMENT_DIR=… MOVVA_STATEMENT_ISSUER=0x… \
  npm run serve -w @mova/movva                       # http://127.0.0.1:8990
```

See `../mova-frontend/README.md`.

## The hedge-withdrawal queue

`withdrawToHedge` is the fast lane, inside the reserve's 24h bucket. Above it, `MovvaReserve` has a slow lane that
the interface does not declare: the treasurer calls `queueHedgeWithdrawal(usdt)`, and after `HEDGE_QUEUE_DELAY`
(immutable per deployment; 24 h on Sepolia) **anyone** may call `executeHedgeWithdrawal(id)`, once, paying exactly that
amount to the hedge treasury fixed at queue time. Nothing can cancel, change or reorder a request.

- `hedge-queue` lists the newest 50 requests with their status (`executed`, `ready`, `waiting`) and what is still
  pending.
- `queue-plan` refuses what the reserve would refuse now (the withdraw floor at the current rate), and warns when the
  request may not execute: after every pending request and a rate `executionBufferBps` lower, it would breach the
  floor, and the reserve checks the floor again at execution. Its default amount is the most that still clears.
  It also says when the amount fits today's 24h allowance, where `withdraw-plan` pays at once.
- `execute-plan` refuses a request already executed, not yet due, or that would leave the reserve under the floor.
- `withdraw-plan` points at `queue-plan` when the 24h limit refuses a requested amount.

These, and the reserve's and the divergence breaker's refusals (`HedgeLimitExceeded`, `CollateralRatioTooLow`,
`SourcesDiverge`, ...), are in `MOVVA_RESERVE_QUEUE_ABI` (abi.ts), so a simulation that reverts names its reason;
`test/abi.test.ts` checks each against the compiled `MovvaReserve` and `DivergenceBreaker`.

## Off-hours

The reserve's FX leg is Pyth's FX.USD/BRL (`PythFxOracle`), which trades weekdays 08:00-17:00 New York
time. Every weekday night and weekend the reserve's rate (`brlPerUsdtE18`) refuses (`StaleRate`), by
design: minting and redeeming wait for the market. The desk follows the same line. `snapshot` shows the
refusal and, beside it, `bandBrlPerUsdtE18` - the last close, as the ramps' band reads it. `report` prices at
that close and labels it (`rateSource: "band"`, and in words in `--text`). Everything that sizes a hedge,
moves USDT or signs a statement - `hedge-plan`, `shock`, `withdraw-plan`, `recap-plan`, `statement sign` -
prices at the live rate only and refuses until the market reopens, saying so.

## Facts this package could not verify

Marked in code and docs as "to confirm":

- **With the broker**: that DOL and WDO are US$ 50,000 and US$ 10,000 per contract for this account
  (B3's product pages say so, read 14 September 2026), DOL's standard lot of 5, margin (B3's model
  plus the broker's add-on - the 10% default is a placeholder), fees and exchange charges, when
  daily settlement is debited, position limits, last trading day handling, and tax treatment.
- **Against the deployed reserve**: the 24h `withdrawToHedge` limit and its window (rolling or
  fixed), what `totalUsdt` counts, whether a withdrawal above idle USDT pulls from the vault.
- **Operationally**: the USDT/BRL conversion cost (30 bps default) and how long a conversion and a
  B3 margin deposit take.

Verified: B3 contract sizes, quote convention (reais per US$ 1,000), tick (R$ 0,50), expiry (first
business day of the month) and cash settlement from B3's DOL and WDO product pages; PTAX venda
R$ 4,8413 (29/12/2023) and R$ 6,1923 (31/12/2024) from the BCB PTAX service.

## What IMovvaReserve does not expose, and the workarounds

| Would add | Why | Workaround here |
|---|---|---|
| `withdrawLimitUsdt()` / `withdrawableToHedgeUsdt()` and the window reset time | The 24h limit is the binding rule for any one-day move; the desk and monitor must know it, not assume it | Configured bps + counting `WithdrawnToHedge` events; `simulateWithdrawToHedge` before signing |
| `hedgeTreasury()`, `treasurer()` | Signers should compare the destination with the deployment record | Configured, shown in the plan as "expected" |
| Custom errors declared in the interface (`StaleRate`, `BelowWithdrawFloor`, `WithdrawLimitExceeded`, `NotTreasurer`, …) | So tools decode refusals without the implementation's ABI | Oracle-leg errors listed; others show as raw selectors |
| `idleUsdt()` (and the vault position) | Whether a withdrawal needs a vault exit | `USDT.balanceOf(reserve)` |
| `rateMaxAge()` per leg, or the leg timestamps separately | The monitor's warn threshold should sit inside the real one | Thresholds from docs/movva.md (FX 1h) |
| `Recapitalized`/`WithdrawnToHedge` carrying the rate | Reconstruct the ratio history without archive reads | Archive reads |

## Tests

```
npx vitest run packages/movva
```

`test/abi.test.ts` compares the ABI with the compiled interface when a build exists. To run it
without touching the repository's `forge-out`:

```
FOUNDRY_OUT=/tmp/forge-movva/out FOUNDRY_CACHE_PATH=/tmp/forge-movva/cache forge build contracts/movva/IMovvaReserve.sol
MOVVA_FORGE_OUT=/tmp/forge-movva/out npx vitest run packages/movva/test/abi.test.ts
```

`test/hedge-properties.test.ts` (fast-check): hedge ratio bounds, rebalancing never under the band
floor and inside it whenever a contract fits, re-planning is stable, shocks are exactly symmetric,
a fully hedged reserve at 100% nets to zero. `test/monitor-compat.test.ts` keeps the monitor's
transcription of the statement format and headroom arithmetic identical to this package's.
