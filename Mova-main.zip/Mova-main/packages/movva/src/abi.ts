/**
 * The reserve's contract surface, transcribed from contracts/movva/IMovvaReserve.sol.
 *
 * Transcribed, not loaded from forge artifacts, for the reason packages/lp-node gives: the desk
 * runs where there is no `forge-out`, and a tool that plans treasury transactions should not
 * resolve its ABI from whatever build happens to be on disk. The price is drift, so
 * `test/abi.test.ts` compares every selector, event topic, output layout and mutability here with
 * the compiled interface whenever a build is present - and, once it exists, with the compiled
 * `MovvaReserve` too.
 *
 * The whole interface is listed, not only what the desk calls: the artifact test then also catches
 * a function ADDED to the interface that this package has not been taught about.
 *
 * The interface declares no errors. Listed below are the refusals the reserve's oracle legs raise
 * today (contracts/ramp), which a reserve that does not catch them bubbles up, so a stale rate
 * decodes to `StaleLeg(leg, updatedAt)` - or, on a PythFxOracle leg, `StaleRate(publishTime)`, which is
 * also what the rate says every weekday night and weekend while the FX market is closed - instead of
 * raw bytes. The reserve's own errors are not in the interface; the ones a hedge withdrawal can meet are transcribed
 * from the implementation in `MOVVA_RESERVE_QUEUE_ABI` below (see the README's interface wish-list).
 *
 * ## Two readings of the rate
 *
 * `brlPerUsdtE18` is the rate everything that moves value prices at, refused once the FX leg's last
 * trade is too old - so, with a Pyth leg, refused off-hours. `bandBrlPerUsdtE18` is the same rate read as
 * a band reads it: while the market is closed, the last close, stamped current. This package sizes hedges,
 * withdrawals, recapitalizations and statements from the first only, and shows the second where a person
 * wants a number while the market is closed, saying which it is (reserve.ts, "Off-hours").
 */
import { parseAbi } from 'viem';

export const MOVVA_RESERVE_ABI = parseAbi([
  'event Minted(address indexed gateway, address indexed to, uint256 usdtIn, uint256 movvaOut, uint256 brlPerUsdtE18)',
  'event Redeemed(address indexed gateway, address indexed to, uint256 movvaIn, uint256 usdtOut, uint256 brlPerUsdtE18)',
  'event WithdrawnToHedge(address indexed treasury, uint256 usdt, uint256 collateralRatioBpsAfter)',
  'event Recapitalized(address indexed from, uint256 usdt, uint256 collateralRatioBpsAfter)',

  'function MOVVA() view returns (address)',
  'function USDT() view returns (address)',
  'function brlPerUsdtE18() view returns (uint256 rate, uint64 updatedAt)',
  'function bandBrlPerUsdtE18() view returns (uint256 rate, uint64 updatedAt)',
  'function totalUsdt() view returns (uint256)',
  'function reserveBrlE18() view returns (uint256)',
  'function liabilitiesBrlE18() view returns (uint256)',
  'function collateralRatioBps() view returns (uint256)',
  'function surplusBrlE18() view returns (uint256)',
  'function liabilitiesUsdt() view returns (uint256)',
  'function isGateway(address account) view returns (bool)',
  'function mintFeeBps() view returns (uint16)',
  'function redeemFeeBps() view returns (uint16)',
  'function targetCollateralRatioBps() view returns (uint16)',
  'function minMintCollateralRatioBps() view returns (uint16)',
  'function minWithdrawCollateralRatioBps() view returns (uint16)',
  'function supplyCap() view returns (uint256)',
  'function hedgeLimitBps() view returns (uint16)',
  'function mintPaused() view returns (bool)',
  'function frozenByAssetIssuer() view returns (bool)',
  'function previewMint(uint256 usdtIn) view returns (uint256 movvaOut, uint256 fee)',
  'function previewRedeem(uint256 movvaIn) view returns (uint256 usdtOut, uint256 fee)',
  'function hedgeWithdrawable() view returns (uint256)',
  'function hedgeTreasury() view returns (address)',
  'function treasurer() view returns (address)',

  'function mint(uint256 usdtIn, address to, uint256 minMovvaOut) returns (uint256 movvaOut)',
  'function redeem(uint256 movvaIn, address to, uint256 minUsdtOut) returns (uint256 usdtOut)',
  'function withdrawToHedge(uint256 usdt)',
  'function recapitalize(uint256 usdt)',

  // Oracle-leg refusals (ChainlinkSignedFxOracle, SignedPriceOracle), in case they bubble up.
  'error StaleLeg(address leg, uint256 updatedAt)',
  'error LegFromFuture(address leg, uint256 updatedAt)',
  'error BadPrice(address leg, int256 answer)',
  'error FeedDecimalsOutOfRange(address feed, uint8 decimals)',
  'error PriceRoundsToZero()',
  'error NoPriceYet()',
  'error SetupIncomplete()',
  // PythFxOracle's refusals, and Pyth's own before the feed's first post on this chain.
  'error StaleRate(uint256 publishTime)',
  'error BadPrice(int64 price)',
  'error ExponentOutOfRange(int32 expo)',
  'error ConfidenceTooWide(uint64 conf, int64 price)',
  'error PriceFromFuture(uint256 publishTime)',
  'error PriceFeedNotFound()',
]);

/**
 * What `MovvaReserve` has beyond the interface and the desk uses: the hedge-withdrawal queue (the slow lane above the
 * 24h limit) and the refusals a hedge withdrawal can meet, so a simulation that reverts names its reason instead of
 * printing a selector. Transcribed from contracts/movva/MovvaReserve.sol and DivergenceBreaker.sol, as the interface
 * is above; `test/abi.test.ts` checks every item against those two compiled contracts.
 *
 * Kept out of `MOVVA_RESERVE_ABI` so that one stays exactly the interface (its test checks both directions).
 *
 * The queue: the treasurer calls `queueHedgeWithdrawal(usdt)`; after `HEDGE_QUEUE_DELAY` ANYONE may call
 * `executeHedgeWithdrawal(id)`, once, which pays exactly `usdt` to the `to` fixed at queue time. Nothing can cancel,
 * change or reorder a request. The ratio floor is checked when it is queued and again when it executes; the 24h
 * bucket is not used.
 */
export const MOVVA_RESERVE_QUEUE_ABI = parseAbi([
  'event HedgeWithdrawalQueued(uint256 indexed id, address indexed to, uint256 usdt, uint64 executeAfter)',
  'event HedgeWithdrawalExecuted(uint256 indexed id, address indexed to, uint256 usdt, address executor)',

  'function HEDGE_QUEUE_DELAY() view returns (uint64)',
  'function hedgeRequestCount() view returns (uint256)',
  'function hedgeRequests(uint256 id) view returns (address to, uint64 executeAfter, bool executed, uint256 usdt)',
  'function queueHedgeWithdrawal(uint256 usdt) returns (uint256 id)',
  'function executeHedgeWithdrawal(uint256 id)',
  'function BREAKER() view returns (address)',

  // MovvaReserve: the refusals of withdrawToHedge, queueHedgeWithdrawal and executeHedgeWithdrawal.
  'error NotTreasurer()',
  'error ZeroAmount()',
  'error ZeroAddress()',
  'error CollateralRatioTooLow(uint256 ratioBps, uint256 minimumBps)',
  'error HedgeLimitExceeded(uint256 wanted, uint256 available)',
  'error InsufficientLiquidity(uint256 wanted, uint256 available)',
  'error FrozenByAssetIssuer(address who)',
  'error UnknownHedgeRequest(uint256 id)',
  'error HedgeRequestNotReady(uint256 id, uint64 executeAfter)',
  'error HedgeRequestDone(uint256 id)',
  // DivergenceBreaker, bubbled through the reserve: a self-clearing halt while the price sources disagree.
  'error SourcesDiverge(uint256 low, uint256 high, uint256 bandBps)',
  'error SourceUnavailable(uint256 index)',
]);

/** Everything the desk decodes against a reserve: the interface, the queue, and every refusal known to it. */
export const MOVVA_RESERVE_DESK_ABI = [...MOVVA_RESERVE_ABI, ...MOVVA_RESERVE_QUEUE_ABI] as const;

/**
 * The USDT calls a recapitalization needs. Tether's mainnet `approve` returns nothing and refuses
 * to change a non-zero allowance to another non-zero one, so the planner zeroes it first; the
 * `bool` outputs here are only used for reads and simulation, never to decode Tether's approve.
 */
export const ERC20_ABI = parseAbi([
  'function balanceOf(address who) view returns (uint256)',
  'function allowance(address owner, address spender) view returns (uint256)',
  'function approve(address spender, uint256 amount) returns (bool)',
]);
