/**
 * What the reserve says about itself, read at one block.
 *
 * ## One block, or the numbers do not add up
 *
 * Every figure the desk works from - the rate, the USDT held, the Movva outstanding, the ratio - is
 * read with the same `blockNumber`. Reading them at "latest" one call after another straddles
 * blocks: a mint lands between `totalUsdt()` and `liabilitiesBrlE18()`, and the ratio computed from
 * the pair is one the reserve never had. A signed statement then reconciles against a state that
 * did not exist, and nobody can reproduce it. So the snapshot is pinned to a block, carries that
 * block's hash and timestamp, and anyone with an archive node can read the same numbers again.
 *
 * ## A stale rate is a state, not an exception
 *
 * `brlPerUsdtE18()` reverts when an oracle leg is stale, and so does everything priced from it.
 * That is the reserve working as designed - mint and redeem stop rather than use a wrong price - so
 * the reader returns an `UnpricedSnapshot` naming the refusal, with every figure that does not need
 * a price (USDT held, Movva outstanding, fees, thresholds). A read that FAILS (the RPC is down) is
 * different and throws: it says nothing about the reserve.
 *
 * ## Off-hours
 *
 * With a PythFxOracle leg the rate is Pyth's FX.USD/BRL, which trades weekdays 08:00-17:00 New York time,
 * and `brlPerUsdtE18()` refuses (`StaleRate`) every weekday night and weekend - by design: value creation
 * waits for the market. Beside such a refusal the reader also reads `bandBrlPerUsdtE18()`, which serves the
 * last close while the market is closed, into `band`. It is shown - `snapshot` prints it, and `report` prices
 * at it and says so (`atLastClose`) - and never planned from: hedge plans, shocks, withdrawals,
 * recapitalizations and statements price at the live rate only, and wait for the reopening with a message
 * that says why (`ReserveUnpriced`). A stale leg refuses the band too, so it never shows as a closed market.
 *
 * ## Checking the reserve's arithmetic
 *
 * The reserve reports derived figures (`reserveBrlE18`, `liabilitiesUsdt`, the ratio, the surplus)
 * alongside the inputs they derive from. The snapshot recomputes each from the inputs and records
 * any disagreement beyond rounding in `inconsistencies`. An empty list is what a correct reserve
 * produces; anything else is a units or rounding bug in the contract - or in this package - that
 * must be understood before a statement is signed against it.
 */
import {
  BaseError, ContractFunctionRevertedError, ContractFunctionZeroDataError, getAddress, type Address, type Hex, type PublicClient,
} from 'viem';
import { MOVVA_RESERVE_ABI, MOVVA_RESERVE_QUEUE_ABI } from './abi.js';
import { Fields } from './json.js';
import { BPS, E6, UINT256_MAX, abs, ceilDiv, formatRate, max } from './units.js';

export type ReserveClient = Pick<PublicClient, 'readContract' | 'getBlock'>;

export interface ReserveThresholds {
  targetCollateralRatioBps: number;
  minMintCollateralRatioBps: number;
  minWithdrawCollateralRatioBps: number;
}

export interface ReserveFees {
  mintFeeBps: number;
  redeemFeeBps: number;
}

interface SnapshotBase {
  reserve: Address;
  blockNumber: bigint;
  blockHash: Hex;
  blockTimestamp: bigint;
  movva: Address;
  usdt: Address;
  /** USDT held, idle plus the yield position's conservative redemption value. 6 decimals. */
  totalUsdt: bigint;
  /** Movva in circulation, in reais. 18 decimals. */
  liabilitiesBrlE18: bigint;
  fees: ReserveFees;
  thresholds: ReserveThresholds;
  /**
   * The reserve's own answer to "how much may `withdrawToHedge` send now" (its refilling 24h bucket,
   * before the ratio floor), and where it sends. Undefined against a reserve without these views.
   */
  hedge?: { withdrawableUsdt: bigint; limitBps: number; treasury: Address; treasurer: Address };
}

export interface PricedSnapshot extends SnapshotBase {
  priced: true;
  brlPerUsdtE18: bigint;
  rateUpdatedAt: bigint;
  reserveBrlE18: bigint;
  /** The dollar amount to hedge. 6 decimals. */
  liabilitiesUsdt: bigint;
  /** `UINT256_MAX` with no supply. */
  collateralRatioBps: bigint;
  surplusBrlE18: bigint;
  /** Derived figures that disagree with their inputs beyond rounding. Empty on a correct reserve. */
  inconsistencies: string[];
}

export interface UnpricedSnapshot extends SnapshotBase {
  priced: false;
  /** The decoded revert of `brlPerUsdtE18()`, e.g. `StaleLeg(0x..., 1789...)`, or `StaleRate(1789...)` at night. */
  refusal: string;
  /**
   * `bandBrlPerUsdtE18()` beside the refusal, when it prices: the rate as the ramps' band reads it - while the
   * FX market is closed, the last close, stamped with the block's time. Display only (see "Off-hours").
   */
  band?: { brlPerUsdtE18: bigint; updatedAt: bigint };
}

export type ReserveSnapshot = PricedSnapshot | UnpricedSnapshot;

export class ReserveUnpriced extends Error {
  constructor(readonly snapshot: UnpricedSnapshot) {
    super(snapshot.band
      ? `the reserve refuses to price at block ${snapshot.blockNumber} (${snapshot.refusal}): the FX market is closed. Its band reads the last close, `
        + `${formatRate(snapshot.band.brlPerUsdtE18, 18)} per USDT, but hedges, withdrawals, recapitalizations and statements are sized at the live `
        + 'rate only: plan once the market reopens (08:00 New York time on a weekday). `report` works meanwhile, at the last close'
      : `the reserve refuses to price at block ${snapshot.blockNumber}: ${snapshot.refusal}. `
        + 'Nothing that depends on the rate can be planned until both oracle legs are fresh');
  }
}

/**
 * The reserve's deployment defaults (docs/movva.md, after the 14 September 2026 shock review):
 * target 108%, withdraw floor 103%, mint floor 100%, and `withdrawToHedge` limited to 8% of the
 * reserve a day. The desk plans from what a snapshot reads, never from these; they seed examples,
 * models and the fallback when a reserve predates the hedge views.
 */
export const DEFAULT_RESERVE_THRESHOLDS: ReserveThresholds = {
  targetCollateralRatioBps: 10_800, minMintCollateralRatioBps: 10_000, minWithdrawCollateralRatioBps: 10_300,
};
export const DEFAULT_HEDGE_LIMIT_BPS = 800;

/**
 * Ratios in the wrong order. The reserve now refuses them (`setCollateralRatios` requires
 * minMint <= minWithdraw <= target, `RatiosOutOfOrder()`), but a snapshot of an older deployment, a
 * hand-edited file or a model can still carry them - and the consequence is not cosmetic: with the
 * withdraw floor above the target the reserve rests at, a reserve at its target cannot
 * release a single USDT for margin until the dollar has risen by floor / target - 1.
 */
export function thresholdWarnings(t: ReserveThresholds): string[] {
  const out: string[] = [];
  const pct = (bps: number) => `${(bps / 100).toFixed(2)}%`;
  if (t.minWithdrawCollateralRatioBps > t.targetCollateralRatioBps) {
    const rise = ((t.minWithdrawCollateralRatioBps * 10_000) / t.targetCollateralRatioBps - 10_000) / 100;
    out.push(`RATIOS OUT OF ORDER: the withdraw floor ${pct(t.minWithdrawCollateralRatioBps)} is above the target ${pct(t.targetCollateralRatioBps)}. `
      + `A reserve at its target releases nothing to the hedge until the dollar rises ${rise.toFixed(2)}%; `
      + 'the reserve should enforce minMint <= minWithdraw <= target (RatiosOutOfOrder)');
  }
  if (t.minMintCollateralRatioBps > t.minWithdrawCollateralRatioBps) {
    out.push(`RATIOS OUT OF ORDER: the mint floor ${pct(t.minMintCollateralRatioBps)} is above the withdraw floor `
      + `${pct(t.minWithdrawCollateralRatioBps)}: a hedge withdrawal can halt minting`);
  }
  return out;
}

export function requirePriced(s: ReserveSnapshot): PricedSnapshot {
  if (!s.priced) throw new ReserveUnpriced(s);
  return s;
}

/**
 * The contract itself refused, as opposed to the read failing. Undefined for anything else, which
 * the caller should treat as "could not read".
 */
export function revertReason(e: unknown): string | undefined {
  if (!(e instanceof BaseError)) return undefined;
  const r = e.walk((x) => x instanceof ContractFunctionRevertedError);
  if (!(r instanceof ContractFunctionRevertedError)) return undefined;
  const d = r.data;
  return d ? `${d.errorName}(${(d.args ?? []).map(String).join(', ')})` : (r.reason ?? r.signature ?? 'no reason');
}

/** Read the reserve at `blockNumber` (default: the latest block, pinned once). */
export async function readReserveSnapshot(
  client: ReserveClient, reserveAddress: Address, opts: { blockNumber?: bigint } = {},
): Promise<ReserveSnapshot> {
  const reserve = getAddress(reserveAddress);
  const block = opts.blockNumber === undefined
    ? await client.getBlock({ blockTag: 'latest' })
    : await client.getBlock({ blockNumber: opts.blockNumber });
  if (block.number === null || block.hash === null) throw new Error('the RPC returned a pending block');
  const blockNumber = block.number;

  type Fn = typeof MOVVA_RESERVE_ABI[number] & { type: 'function' };
  const read = <T>(functionName: Fn['name']): Promise<T> =>
    client.readContract({ address: reserve, abi: MOVVA_RESERVE_ABI, functionName, blockNumber } as never) as Promise<T>;

  const [movva, usdt, totalUsdt, liabilitiesBrlE18, mintFeeBps, redeemFeeBps,
    targetCollateralRatioBps, minMintCollateralRatioBps, minWithdrawCollateralRatioBps] = await Promise.all([
    read<Address>('MOVVA'), read<Address>('USDT'), read<bigint>('totalUsdt'), read<bigint>('liabilitiesBrlE18'),
    read<number>('mintFeeBps'), read<number>('redeemFeeBps'),
    read<number>('targetCollateralRatioBps'), read<number>('minMintCollateralRatioBps'), read<number>('minWithdrawCollateralRatioBps'),
  ]);
  const base: SnapshotBase = {
    reserve, blockNumber, blockHash: block.hash, blockTimestamp: block.timestamp, movva, usdt, totalUsdt, liabilitiesBrlE18,
    fees: { mintFeeBps, redeemFeeBps },
    thresholds: { targetCollateralRatioBps, minMintCollateralRatioBps, minWithdrawCollateralRatioBps },
  };
  try {
    const [withdrawableUsdt, limitBps, treasury, treasurer] = await Promise.all([
      read<bigint>('hedgeWithdrawable'), read<number>('hedgeLimitBps'), read<Address>('hedgeTreasury'), read<Address>('treasurer'),
    ]);
    base.hedge = { withdrawableUsdt, limitBps, treasury, treasurer };
  } catch (e) {
    // A reserve that predates these views: planning falls back to configuration and events.
    if (revertReason(e) === undefined && !(e instanceof BaseError)) throw e;
  }

  let rate: readonly [bigint, bigint];
  try {
    rate = await read<readonly [bigint, bigint]>('brlPerUsdtE18');
  } catch (e) {
    const refusal = revertReason(e);
    if (refusal === undefined) throw e;
    const band = await bandBeside(() => read<readonly [bigint, bigint]>('bandBrlPerUsdtE18'));
    return band ? { ...base, priced: false, refusal, band } : { ...base, priced: false, refusal };
  }
  const [reserveBrlE18, liabilitiesUsdt, collateralRatioBps, surplusBrlE18] = await Promise.all([
    read<bigint>('reserveBrlE18'), read<bigint>('liabilitiesUsdt'), read<bigint>('collateralRatioBps'), read<bigint>('surplusBrlE18'),
  ]);
  const priced: PricedSnapshot = {
    ...base, priced: true, brlPerUsdtE18: rate[0], rateUpdatedAt: rate[1],
    reserveBrlE18, liabilitiesUsdt, collateralRatioBps, surplusBrlE18, inconsistencies: [],
  };
  priced.inconsistencies = inconsistencies(priced);
  return priced;
}

/**
 * The band's reading beside a refused rate, or undefined when the band refuses too (a stale leg) or the reserve
 * predates it (no such view). A read that failed throws, as any other.
 */
async function bandBeside(read: () => Promise<readonly [bigint, bigint]>): Promise<UnpricedSnapshot['band']> {
  try {
    const [brlPerUsdtE18, updatedAt] = await read();
    return { brlPerUsdtE18, updatedAt };
  } catch (e) {
    if (e instanceof BaseError && e.walk((x) => x instanceof ContractFunctionRevertedError || x instanceof ContractFunctionZeroDataError)) return undefined;
    throw e;
  }
}

/**
 * An unpriced snapshot priced at its band's last close, each figure computed as the reserve computes it (reais
 * and the ratio rounded down, `liabilitiesUsdt` up). For `report` while the FX market is closed, which labels
 * it - never for a plan or a statement. Throws `ReserveUnpriced` when there is no band reading to price at.
 */
export function atLastClose(s: UnpricedSnapshot): PricedSnapshot {
  if (!s.band) throw new ReserveUnpriced(s);
  const S = s.band.brlPerUsdtE18;
  const L = s.liabilitiesBrlE18;
  const reserveBrlE18 = s.totalUsdt * S / E6;
  const priced: Omit<PricedSnapshot, 'inconsistencies'> = {
    reserve: s.reserve, blockNumber: s.blockNumber, blockHash: s.blockHash, blockTimestamp: s.blockTimestamp, movva: s.movva, usdt: s.usdt,
    totalUsdt: s.totalUsdt, liabilitiesBrlE18: L, fees: s.fees, thresholds: s.thresholds, ...(s.hedge ? { hedge: s.hedge } : {}),
    priced: true, brlPerUsdtE18: S, rateUpdatedAt: s.band.updatedAt, reserveBrlE18,
    liabilitiesUsdt: ceilDiv(L * E6, S),
    collateralRatioBps: L === 0n ? UINT256_MAX : reserveBrlE18 * BPS / L,
    surplusBrlE18: max(0n, reserveBrlE18 - ceilDiv(L * BigInt(s.thresholds.targetCollateralRatioBps), BPS)),
  };
  return { ...priced, inconsistencies: inconsistencies(priced) };
}

/** What each derived figure should be, from the inputs, and how far rounding may move it. */
export function inconsistencies(s: Omit<PricedSnapshot, 'inconsistencies'>): string[] {
  const out: string[] = [];
  const S = s.brlPerUsdtE18;
  if (S === 0n) return ['the rate is zero'];
  const L = s.liabilitiesBrlE18;

  const reserve = s.totalUsdt * S / E6;
  // One micro-USDT's worth of reais, plus a wei, either way.
  if (abs(s.reserveBrlE18 - reserve) > S / E6 + 1n) {
    out.push(`reserveBrlE18 is ${s.reserveBrlE18}, but totalUsdt x rate is ${reserve}`);
  }
  const liabUsdt = L * E6 / S;
  if (abs(s.liabilitiesUsdt - liabUsdt) > 1n) {
    out.push(`liabilitiesUsdt is ${s.liabilitiesUsdt}, but liabilitiesBrlE18 / rate is ${liabUsdt}`);
  }
  const ratio = L === 0n ? UINT256_MAX : s.reserveBrlE18 * BPS / L;
  if (L === 0n ? s.collateralRatioBps !== UINT256_MAX : abs(s.collateralRatioBps - ratio) > 1n) {
    out.push(`collateralRatioBps is ${s.collateralRatioBps}, but reserve / liabilities is ${ratio}`);
  }
  const surplus = max(0n, s.reserveBrlE18 - ceilDiv(L * BigInt(s.thresholds.targetCollateralRatioBps), BPS));
  if (abs(s.surplusBrlE18 - surplus) > s.reserveBrlE18 / 1_000_000_000n + 10n ** 12n) {
    out.push(`surplusBrlE18 is ${s.surplusBrlE18}, but reserve above target is ${surplus}`);
  }
  return out;
}

export interface HedgeWithdrawal {
  blockNumber: bigint;
  timestamp: bigint;
  transactionHash: Hex;
  treasury: Address;
  usdt: bigint;
  collateralRatioBpsAfter: bigint;
}

/**
 * `WithdrawnToHedge` in the `windowSeconds` before `toBlock`, by block timestamp.
 *
 * The interface has no view of how much of the 24h limit is left, so this is the workaround: count
 * what was withdrawn. It matches a rolling-window limit exactly and over-counts against a limit
 * that resets at a fixed hour - so headroom derived from it can be understated, never overstated.
 */
export async function readHedgeWithdrawals(
  client: Pick<PublicClient, 'getLogs' | 'getBlock'>, reserve: Address,
  opts: { toBlock: bigint; toTimestamp: bigint; windowSeconds?: number; secondsPerBlock?: number },
): Promise<{ totalUsdt: bigint; withdrawals: HedgeWithdrawal[] }> {
  const window = BigInt(opts.windowSeconds ?? 86_400);
  // Missed slots make blocks further apart, never closer: ~10% more blocks than the window needs.
  const span = window * 11n / (10n * BigInt(opts.secondsPerBlock ?? 12)) + 1n;
  const fromBlock = opts.toBlock > span ? opts.toBlock - span : 0n;
  const logs = await client.getLogs({
    address: reserve, event: MOVVA_RESERVE_ABI.find((x) => x.type === 'event' && x.name === 'WithdrawnToHedge') as never,
    fromBlock, toBlock: opts.toBlock,
  }) as unknown as { blockNumber: bigint; transactionHash: Hex; args: { treasury: Address; usdt: bigint; collateralRatioBpsAfter: bigint } }[];
  const stamps = new Map<bigint, bigint>();
  const withdrawals: HedgeWithdrawal[] = [];
  for (const l of logs) {
    if (!stamps.has(l.blockNumber)) stamps.set(l.blockNumber, (await client.getBlock({ blockNumber: l.blockNumber })).timestamp);
    const timestamp = stamps.get(l.blockNumber)!;
    if (timestamp + window <= opts.toTimestamp) continue;
    withdrawals.push({ blockNumber: l.blockNumber, timestamp, transactionHash: l.transactionHash, ...l.args });
  }
  return { totalUsdt: withdrawals.reduce((a, w) => a + w.usdt, 0n), withdrawals };
}

/** One queued hedge withdrawal, as `hedgeRequests(id)` reads it. */
export interface HedgeRequest {
  id: bigint;
  /** Fixed at queue time: a later change of the hedge treasury does not move it. */
  to: Address;
  usdt: bigint;
  executeAfter: bigint;
  executed: boolean;
}

export interface HedgeQueue {
  reserve: Address;
  blockNumber: bigint;
  blockTimestamp: bigint;
  /** `HEDGE_QUEUE_DELAY`, seconds from queueing to the earliest execution. Immutable per deployment. */
  delaySeconds: bigint;
  /** Requests ever queued; ids are 0 to count - 1. */
  count: bigint;
  /** The newest `limit` requests, newest first. */
  requests: HedgeRequest[];
  /** Queued, not yet executed: what will still leave the reserve. */
  pendingUsdt: bigint;
}

/**
 * The reserve's hedge-withdrawal queue at one block, or `undefined` for a reserve that predates it (the views do not
 * exist). `pendingUsdt` counts only the requests read, so with more than `limit` requests it can understate.
 */
export async function readHedgeQueue(
  client: ReserveClient, reserveAddress: Address, opts: { blockNumber?: bigint; limit?: number } = {},
): Promise<HedgeQueue | undefined> {
  const reserve = getAddress(reserveAddress);
  const block = opts.blockNumber === undefined
    ? await client.getBlock({ blockTag: 'latest' })
    : await client.getBlock({ blockNumber: opts.blockNumber });
  if (block.number === null) throw new Error('the RPC returned a pending block');
  const blockNumber = block.number;
  const read = <T>(functionName: string, args: readonly unknown[] = []): Promise<T> =>
    client.readContract({ address: reserve, abi: MOVVA_RESERVE_QUEUE_ABI, functionName, args, blockNumber } as never) as Promise<T>;

  let delaySeconds: bigint;
  let count: bigint;
  try {
    [delaySeconds, count] = await Promise.all([read<bigint>('HEDGE_QUEUE_DELAY'), read<bigint>('hedgeRequestCount')]);
  } catch (e) {
    if (e instanceof BaseError && e.walk((x) => x instanceof ContractFunctionRevertedError || x instanceof ContractFunctionZeroDataError)) return undefined;
    throw e;
  }
  const limit = BigInt(opts.limit ?? 50);
  const first = count > limit ? count - limit : 0n;
  const ids: bigint[] = [];
  for (let id = count - 1n; id >= first; id--) ids.push(id);
  const requests = await Promise.all(ids.map(async (id): Promise<HedgeRequest> => {
    const [to, executeAfter, executed, usdt] = await read<readonly [Address, bigint, boolean, bigint]>('hedgeRequests', [id]);
    return { id, to, usdt, executeAfter: BigInt(executeAfter), executed };
  }));
  return {
    reserve, blockNumber, blockTimestamp: block.timestamp, delaySeconds: BigInt(delaySeconds), count, requests,
    pendingUsdt: requests.filter((r) => !r.executed).reduce((a, r) => a + r.usdt, 0n),
  };
}

/** Parse a snapshot saved by `movva-desk snapshot`, for planning offline. Strict: every field. */
export function snapshotFromJson(raw: unknown): ReserveSnapshot {
  const f = new Fields();
  const o = f.obj(raw, 'snapshot');
  const fees = f.obj(o.fees, 'snapshot.fees');
  const th = f.obj(o.thresholds, 'snapshot.thresholds');
  const base: SnapshotBase = {
    reserve: f.address(o, 'reserve', 'snapshot'),
    blockNumber: f.big(o, 'blockNumber', 'snapshot'),
    blockHash: f.hex32(o, 'blockHash', 'snapshot'),
    blockTimestamp: f.big(o, 'blockTimestamp', 'snapshot'),
    movva: f.address(o, 'movva', 'snapshot'),
    usdt: f.address(o, 'usdt', 'snapshot'),
    totalUsdt: f.big(o, 'totalUsdt', 'snapshot'),
    liabilitiesBrlE18: f.big(o, 'liabilitiesBrlE18', 'snapshot'),
    fees: {
      mintFeeBps: f.int(fees, 'mintFeeBps', 'snapshot.fees', undefined, [0, 65_535]),
      redeemFeeBps: f.int(fees, 'redeemFeeBps', 'snapshot.fees', undefined, [0, 65_535]),
    },
    thresholds: {
      targetCollateralRatioBps: f.int(th, 'targetCollateralRatioBps', 'snapshot.thresholds', undefined, [0, 65_535]),
      minMintCollateralRatioBps: f.int(th, 'minMintCollateralRatioBps', 'snapshot.thresholds', undefined, [0, 65_535]),
      minWithdrawCollateralRatioBps: f.int(th, 'minWithdrawCollateralRatioBps', 'snapshot.thresholds', undefined, [0, 65_535]),
    },
  };
  if (o.hedge !== undefined) {
    // Optional: a snapshot of a reserve without the views has none. Dropping it when present would
    // silently swap the reserve's own 24h limit for configuration.
    const h = f.obj(o.hedge, 'snapshot.hedge');
    base.hedge = {
      withdrawableUsdt: f.big(h, 'withdrawableUsdt', 'snapshot.hedge'),
      limitBps: f.int(h, 'limitBps', 'snapshot.hedge', undefined, [0, 65_535]),
      treasury: f.address(h, 'treasury', 'snapshot.hedge'),
      treasurer: f.address(h, 'treasurer', 'snapshot.hedge'),
    };
  }
  if (o.priced === false) {
    const refusal = f.str(o, 'refusal', 'snapshot');
    let band: UnpricedSnapshot['band'];
    if (o.band !== undefined) {
      const b = f.obj(o.band, 'snapshot.band');
      band = { brlPerUsdtE18: f.big(b, 'brlPerUsdtE18', 'snapshot.band'), updatedAt: f.big(b, 'updatedAt', 'snapshot.band') };
    }
    f.done('snapshot');
    return band ? { ...base, priced: false, refusal, band } : { ...base, priced: false, refusal };
  }
  if (o.priced !== true) f.problems.push('snapshot.priced must be true or false');
  const priced: Omit<PricedSnapshot, 'inconsistencies'> = {
    ...base, priced: true,
    brlPerUsdtE18: f.big(o, 'brlPerUsdtE18', 'snapshot'),
    rateUpdatedAt: f.big(o, 'rateUpdatedAt', 'snapshot'),
    reserveBrlE18: f.big(o, 'reserveBrlE18', 'snapshot'),
    liabilitiesUsdt: f.big(o, 'liabilitiesUsdt', 'snapshot'),
    collateralRatioBps: f.big(o, 'collateralRatioBps', 'snapshot'),
    surplusBrlE18: f.big(o, 'surplusBrlE18', 'snapshot'),
  };
  f.done('snapshot');
  // Recomputed, never trusted from the file: a hand-edited snapshot is exactly what this catches.
  return { ...priced, inconsistencies: inconsistencies(priced) };
}

/**
 * A priced snapshot of a hypothetical reserve, computing the derived figures the way the
 * interface documents them. For the shock walk-through, examples and tests - never for a
 * statement, which must reconcile against the chain.
 */
export function modelSnapshot(p: {
  brlPerUsdtE18: bigint; totalUsdt: bigint; liabilitiesBrlE18: bigint;
  thresholds?: Partial<ReserveThresholds>; fees?: Partial<ReserveFees>;
  reserve?: Address; blockNumber?: bigint; blockTimestamp?: bigint;
  /** The reserve's hedge views; omit for a reserve without them. */
  hedge?: SnapshotBase['hedge'];
}): PricedSnapshot {
  const thresholds: ReserveThresholds = { ...DEFAULT_RESERVE_THRESHOLDS, ...p.thresholds };
  const reserveBrlE18 = p.totalUsdt * p.brlPerUsdtE18 / E6;
  const L = p.liabilitiesBrlE18;
  const s: Omit<PricedSnapshot, 'inconsistencies'> = {
    reserve: p.reserve ?? '0x000000000000000000000000000000000000dEaD',
    blockNumber: p.blockNumber ?? 0n, blockHash: `0x${'00'.repeat(32)}`, blockTimestamp: p.blockTimestamp ?? 0n,
    movva: '0x0000000000000000000000000000000000000000', usdt: '0x0000000000000000000000000000000000000000',
    totalUsdt: p.totalUsdt, liabilitiesBrlE18: L,
    fees: { mintFeeBps: 0, redeemFeeBps: 0, ...p.fees },
    ...(p.hedge ? { hedge: p.hedge } : {}),
    thresholds, priced: true, brlPerUsdtE18: p.brlPerUsdtE18, rateUpdatedAt: p.blockTimestamp ?? 0n,
    reserveBrlE18,
    liabilitiesUsdt: L * E6 / p.brlPerUsdtE18,
    collateralRatioBps: L === 0n ? UINT256_MAX : reserveBrlE18 * BPS / L,
    surplusBrlE18: max(0n, reserveBrlE18 - ceilDiv(L * BigInt(thresholds.targetCollateralRatioBps), BPS)),
  };
  return { ...s, inconsistencies: inconsistencies(s) };
}
