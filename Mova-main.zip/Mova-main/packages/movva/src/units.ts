/**
 * Fixed-point arithmetic for money, and nothing else.
 *
 * ## Why no floats, anywhere
 *
 * Every number this package produces ends up in front of a treasurer deciding how much USDT to move
 * or how many futures to sell, or inside a signed statement. A binary float turns R$ 0,10 into
 * 0.1000000000000000055511151231257827 and a product of two of them into a centavo off; worse, it
 * does so silently and differently depending on the order of operations. So amounts are bigints in
 * the units the contract uses, and every division states which way it rounds:
 *
 *  - `floorDiv` / `ceilDiv` for the side of a limit. A withdrawal cap rounds down, a
 *    recapitalization rounds up: whichever way leaves the reserve on the safe side of its rule.
 *  - `truncDiv` (toward zero) for signed shocks, so a +5% and a -5% move produce amounts that are
 *    exact negatives of each other. That symmetry is property-tested in test/hedge-properties.
 *  - `roundDiv` (nearest, halves away from zero) only for display and for choosing a contract count.
 *
 * Units, as in contracts/movva/IMovvaReserve.sol: Movva and reais 18 decimals (`...BrlE18`), USDT 6
 * (`...Usdt`), US dollars of hedge notional 6 (`...UsdE6`, the same scale as `liabilitiesUsdt` so
 * the two compare directly), prices in reais per dollar 6 (`...BrlPerUsdE6`), the reserve's rate 18
 * (`brlPerUsdtE18`), ratios and costs in basis points. Numbers (not bigints) appear only for
 * seconds, days and basis-point settings, none of which is money.
 */

export const BPS = 10_000n;
export const E6 = 1_000_000n;
export const E18 = 1_000_000_000_000_000_000n;
/** `collateralRatioBps()` with no supply. */
export const UINT256_MAX = (1n << 256n) - 1n;

export const abs = (x: bigint): bigint => (x < 0n ? -x : x);
export const min = (a: bigint, b: bigint): bigint => (a < b ? a : b);
export const max = (a: bigint, b: bigint): bigint => (a > b ? a : b);

function nonZero(d: bigint): void {
  if (d === 0n) throw new RangeError('division by zero');
}

/** Toward zero: bigint's own division. Symmetric under negation, which is why shocks use it. */
export const truncDiv = (a: bigint, b: bigint): bigint => {
  nonZero(b);
  return a / b;
};

/** Toward negative infinity. */
export function floorDiv(a: bigint, b: bigint): bigint {
  nonZero(b);
  const q = a / b;
  return (a % b !== 0n) && ((a < 0n) !== (b < 0n)) ? q - 1n : q;
}

/** Toward positive infinity. */
export function ceilDiv(a: bigint, b: bigint): bigint {
  nonZero(b);
  const q = a / b;
  return (a % b !== 0n) && ((a < 0n) === (b < 0n)) ? q + 1n : q;
}

/** Nearest, halves away from zero. */
export function roundDiv(a: bigint, b: bigint): bigint {
  nonZero(b);
  const neg = (a < 0n) !== (b < 0n);
  const q = (2n * abs(a) + abs(b)) / (2n * abs(b));
  return neg ? -q : q;
}

const DECIMAL = /^-?\d+(\.\d+)?$/;

/**
 * A plain decimal string to a bigint at `decimals`, refusing anything that would need rounding.
 * "1000.5" USDT is 1_000_500_000; "1000.5000001" USDT is an error, not 1_000_500_000: an amount
 * typed with more precision than the token has is a mistake worth stopping at.
 */
export function parseDecimal(v: string, decimals: number, what = 'amount'): bigint {
  const s = v.trim();
  if (!DECIMAL.test(s)) throw new Error(`${what} must be a plain decimal like "1234.56"; got "${v}"`);
  const neg = s.startsWith('-');
  const [whole, frac = ''] = (neg ? s.slice(1) : s).split('.');
  if (frac.length > decimals) {
    if (/[^0]/.test(frac.slice(decimals))) throw new Error(`${what} has more than ${decimals} decimal places: "${v}"`);
  }
  const n = BigInt(whole + frac.slice(0, decimals).padEnd(decimals, '0'));
  return neg ? -n : n;
}

/** A bigint at `decimals` as a plain decimal string with every digit ("-1.500000"). Lossless. */
export function toDecimal(x: bigint, decimals: number): string {
  const neg = x < 0n;
  const digits = abs(x).toString().padStart(decimals + 1, '0');
  const whole = digits.slice(0, digits.length - decimals);
  const frac = decimals ? `.${digits.slice(-decimals)}` : '';
  return `${neg ? '-' : ''}${whole}${frac}`;
}

function grouped(x: bigint, decimals: number, shown: number, thousands: string, point: string): string {
  const scale = 10n ** BigInt(decimals - shown);
  const r = roundDiv(x, scale);
  const neg = r < 0n;
  const digits = abs(r).toString().padStart(shown + 1, '0');
  const whole = digits.slice(0, digits.length - shown).replace(/\B(?=(\d{3})+(?!\d))/g, thousands);
  return `${neg ? '-' : ''}${whole}${shown ? `${point}${digits.slice(-shown)}` : ''}`;
}

/** R$ 10.200.000,00 - reais in the Brazilian convention, rounded to the centavo, for humans only. */
export const formatBrl = (brlE18: bigint): string => `R$ ${grouped(brlE18, 18, 2, '.', ',')}`;
/** US$ 1,851,851.85 */
export const formatUsd = (usdE6: bigint): string => `US$ ${grouped(usdE6, 6, 2, ',', '.')}`;
/** 1,888,888.888889 USDT */
export const formatUsdt = (usdt: bigint): string => `${grouped(usdt, 6, 6, ',', '.')} USDT`;
/** R$ 5,4000 per dollar, from reais per unit scaled 1e18 or 1e6. */
export const formatRate = (rate: bigint, decimals: 6 | 18): string => `R$ ${grouped(rate, decimals, 4, '.', ',')}`;
/** 102.00% */
export const formatBps = (bps: bigint | number): string => {
  const b = BigInt(bps);
  if (b === UINT256_MAX) return 'infinite (no supply)';
  return `${grouped(b, 2, 2, ',', '.')}%`;
};

/** Reais (1e18) to centavos, toward zero: what a statement or a bank records. */
export const brlE18ToCents = (brlE18: bigint): bigint => brlE18 / 10n ** 16n;
export const centsToBrlE18 = (cents: bigint): bigint => cents * 10n ** 16n;

/** The reserve's rate (reais per USDT, 1e18) at the 1e-6 precision prices are quoted in here. */
export const rateE18ToE6 = (rateE18: bigint): bigint => rateE18 / 10n ** 12n;
export const rateE6ToE18 = (rateE6: bigint): bigint => rateE6 * 10n ** 12n;

/** `usdE6 × brlPerUsdE18` in reais at 18 decimals, toward zero. */
export const usdToBrlE18 = (usdE6: bigint, brlPerUsdE18: bigint): bigint => truncDiv(usdE6 * brlPerUsdE18, E6);

/** basis points of `x`, toward zero. */
export const bpsOf = (x: bigint, bps: bigint | number): bigint => truncDiv(x * BigInt(bps), BPS);
