/**
 * Plans for the two treasury actions that move reserve USDT: `withdrawToHedge` and `recapitalize`.
 *
 * ## Plan, never send
 *
 * This module holds no key and sends nothing. It produces the amount, the ratio it leaves, which
 * rule binds, and unsigned calldata for the issuer's treasurer - in practice a multisig, whose
 * signers should each be able to reproduce the plan from the same block. The separation is the
 * point: the software that reads the reserve and does the arithmetic is the software most likely
 * to be wrong, and a wrong number that needs three signatures is caught more often than one that
 * needs none.
 *
 * ## Time passes between the plan and the transaction
 *
 * A multisig executes hours after the plan, at a different rate. A withdrawal sized to land exactly
 * on the 103% floor at plan time reverts if the real strengthens 0.1% before execution - which, the
 * reserve being long dollars, is exactly when the floor tightens. So both planners work at a rate
 * moved against the reserve by `executionBufferBps` and report the ratio at both rates: a
 * withdrawal stays above the floor, and a recapitalization still reaches its target, after that
 * move. Re-plan before signing if the rate has moved further.
 *
 * ## What the interface does not tell us
 *
 *  - **The 24h withdraw limit.** The reserve answers it itself (`hedgeWithdrawable`, a bucket that
 *    refills continuously) and the snapshot carries that answer, which the plan uses. Against a
 *    reserve without the view, the limit falls back to configuration and `WithdrawnToHedge` events
 *    (reserve.ts); simulate from the treasurer's address before collecting signatures either way
 *    (`simulateWithdrawToHedge`).
 *  - **The hedge treasury.** Read from the reserve. When the desk also names the treasury it
 *    expects, a mismatch is a warning signers must resolve before signing.
 *  - **Idle versus deployed USDT.** `totalUsdt` includes the yield position; whether a withdrawal
 *    larger than the idle balance pulls from the vault is up to the implementation.
 */
import { encodeFunctionData, type Address, type Hex, type PublicClient } from 'viem';
import { ERC20_ABI, MOVVA_RESERVE_ABI, MOVVA_RESERVE_DESK_ABI, MOVVA_RESERVE_QUEUE_ABI } from './abi.js';
import { ratioBps, usdtForRatio } from './hedge.js';
import { DEFAULT_HEDGE_LIMIT_BPS, revertReason, thresholdWarnings, type HedgeRequest, type PricedSnapshot } from './reserve.js';
import { BPS, formatBps, formatUsdt, max, min } from './units.js';

export interface PlannedTransaction {
  to: Address;
  value: '0';
  data: Hex;
  /** `recapitalize(1888888888889)`, for the signer to read before the calldata. */
  call: string;
  description: string;
}

export interface WithdrawPolicy {
  /**
   * 24h limit in bps of `totalUsdt`. Fallback only: a snapshot carrying the reserve's
   * `hedgeWithdrawable()` is planned against that instead.
   */
  dailyLimitBps: number;
  /** Already withdrawn inside the window, from `readHedgeWithdrawals`. Fallback only, as above. */
  withdrawnInWindowUsdt: bigint;
  /** Plan as if the rate had moved this much against the reserve before execution. */
  executionBufferBps: number;
}

export const DEFAULT_WITHDRAW_POLICY: WithdrawPolicy = { dailyLimitBps: DEFAULT_HEDGE_LIMIT_BPS, withdrawnInWindowUsdt: 0n, executionBufferBps: 50 };

export interface WithdrawPlan {
  kind: 'withdrawToHedge';
  reserve: Address;
  blockNumber: bigint;
  rateBrlPerUsdtE18: bigint;
  bufferedRateBrlPerUsdtE18: bigint;
  requestedUsdt?: bigint;
  amountUsdt: bigint;
  /** The rule that sets the amount: the floor ratio, the 24h limit, or the amount asked for. */
  binding: 'floor' | 'daily-limit' | 'requested';
  limits: {
    floorBps: number;
    floorMaxUsdt: bigint;
    floorMaxAtBufferedRateUsdt: bigint;
    dailyLimitBps: number;
    withdrawnInWindowUsdt: bigint;
    dailyMaxUsdt: bigint;
    /** Queued hedge withdrawals not yet executed, when the reserve has a queue and it was read. */
    pendingQueueUsdt?: bigint;
  };
  ratio: { beforeBps: bigint; afterBps: bigint; afterAtBufferedRateBps: bigint };
  hedgeTreasury?: Address;
  transactions: PlannedTransaction[];
  /** Set when no transaction is produced, saying why. */
  refused?: string;
  warnings: string[];
}

const buffered = (rate: bigint, bps: number) => rate * (BPS - BigInt(bps)) / BPS;

function checkPolicyBps(name: string, v: number): void {
  if (!Number.isInteger(v) || v < 0 || v >= 10_000) throw new Error(`${name} must be an integer from 0 to 9999`);
}

function snapshotWarnings(s: PricedSnapshot, nowSeconds?: number): string[] {
  const w: string[] = [...thresholdWarnings(s.thresholds)];
  if (nowSeconds !== undefined && nowSeconds - Number(s.blockTimestamp) > 15 * 60) {
    w.push(`the snapshot is ${Math.floor((nowSeconds - Number(s.blockTimestamp)) / 60)} minutes old: re-plan against a fresh block before signing`);
  }
  return w;
}

/**
 * The most `withdrawToHedge` can take now without breaching the floor (after the buffer) or the
 * 24h limit - or a check of `amountUsdt` against both, refusing rather than trimming it: a
 * treasurer who asked for R$ 500k of margin and silently got R$ 300k has a margin call to miss.
 */
export function planWithdrawToHedge(snapshot: PricedSnapshot, opts: {
  amountUsdt?: bigint; policy?: Partial<WithdrawPolicy>; hedgeTreasury?: Address; idleUsdt?: bigint; nowSeconds?: number;
  /**
   * Queued hedge withdrawals still to execute (readHedgeQueue). The fast lane does not count them - the reserve does
   * not either - but a withdrawal that leaves no room for them strands them under the floor, so the plan warns.
   */
  pendingQueueUsdt?: bigint;
} = {}): WithdrawPlan {
  const p: WithdrawPolicy = { ...DEFAULT_WITHDRAW_POLICY, ...opts.policy };
  checkPolicyBps('dailyLimitBps', p.dailyLimitBps);
  checkPolicyBps('executionBufferBps', p.executionBufferBps);
  const { totalUsdt: T, liabilitiesBrlE18: L, brlPerUsdtE18: S } = snapshot;
  const Sb = buffered(S, p.executionBufferBps);
  const floorBps = snapshot.thresholds.minWithdrawCollateralRatioBps;
  const floorMax = max(0n, T - usdtForRatio(BigInt(floorBps), L, S));
  const floorMaxBuffered = max(0n, T - usdtForRatio(BigInt(floorBps), L, Sb));
  const onChain = snapshot.hedge;
  const dailyMax = onChain
    ? onChain.withdrawableUsdt
    : max(0n, T * BigInt(p.dailyLimitBps) / BPS - p.withdrawnInWindowUsdt);
  const allowed = min(floorMaxBuffered, dailyMax);
  const limitName = floorMaxBuffered <= dailyMax ? 'floor' as const : 'daily-limit' as const;
  const warnings = [...snapshotWarnings(snapshot, opts.nowSeconds)];
  if (!onChain) {
    warnings.push(`the 24h limit (${formatBps(p.dailyLimitBps)} of the reserve, ${formatUsdt(p.withdrawnInWindowUsdt)} already used) is configuration: `
      + 'this reserve exposes no view of it. Simulate from the treasurer before collecting signatures');
  } else if (opts.hedgeTreasury && opts.hedgeTreasury.toLowerCase() !== onChain.treasury.toLowerCase()) {
    warnings.push(`the reserve pays ${onChain.treasury}, not the expected hedge treasury ${opts.hedgeTreasury}: do not sign until that is explained`);
  }
  if (L === 0n) warnings.push('there is no Movva in circulation: nothing is hedged, so there is no margin to meet');

  let amount = opts.amountUsdt ?? allowed;
  let binding: WithdrawPlan['binding'] = opts.amountUsdt === undefined ? limitName : 'requested';
  let refused: string | undefined;
  if (snapshot.inconsistencies.length) {
    refused = `the reserve's figures do not agree with each other (${snapshot.inconsistencies.join('; ')}): find out why before moving USDT`;
  } else if (opts.amountUsdt !== undefined && opts.amountUsdt > allowed) {
    binding = limitName;
    refused = `${formatUsdt(opts.amountUsdt)} exceeds what may be withdrawn: at most ${formatUsdt(allowed)}, bound by the `
      + (limitName === 'floor'
        ? `${formatBps(floorBps)} floor at a rate ${formatBps(p.executionBufferBps)} lower`
        : `24h limit`);
  } else if (amount === 0n) {
    refused = limitName === 'floor'
      ? `nothing can be withdrawn: the reserve is at ${formatBps(snapshot.collateralRatioBps)}, and the floor is ${formatBps(floorBps)} after the withdrawal`
      : 'nothing can be withdrawn: the 24h limit is used up';
  }
  if (refused) amount = 0n;
  const pending = opts.pendingQueueUsdt ?? 0n;
  if (!refused && pending > 0n && ratioBps(max(0n, T - amount - pending), L, Sb) < BigInt(floorBps)) {
    const room = max(0n, floorMaxBuffered - pending);
    warnings.push(`${formatUsdt(pending)} is queued and not yet executed: after this withdrawal, executing it would breach the `
      + `${formatBps(floorBps)} floor at a rate ${formatBps(p.executionBufferBps)} lower, and it would wait until the reserve recovers. `
      + `At most ${formatUsdt(room)} leaves room for the queue`);
  }
  if (opts.idleUsdt !== undefined && amount > opts.idleUsdt) {
    warnings.push(`the reserve holds ${formatUsdt(opts.idleUsdt)} idle; the rest of this withdrawal must come out of the yield vault, `
      + 'which the interface does not describe - simulate it');
  }
  return {
    kind: 'withdrawToHedge', reserve: snapshot.reserve, blockNumber: snapshot.blockNumber,
    rateBrlPerUsdtE18: S, bufferedRateBrlPerUsdtE18: Sb,
    requestedUsdt: opts.amountUsdt, amountUsdt: amount, binding,
    limits: {
      floorBps, floorMaxUsdt: floorMax, floorMaxAtBufferedRateUsdt: floorMaxBuffered,
      dailyLimitBps: onChain ? onChain.limitBps : p.dailyLimitBps,
      withdrawnInWindowUsdt: onChain ? 0n : p.withdrawnInWindowUsdt, dailyMaxUsdt: dailyMax,
      ...(opts.pendingQueueUsdt === undefined ? {} : { pendingQueueUsdt: opts.pendingQueueUsdt }),
    },
    ratio: {
      beforeBps: snapshot.collateralRatioBps, afterBps: ratioBps(T - amount, L, S), afterAtBufferedRateBps: ratioBps(T - amount, L, Sb),
    },
    hedgeTreasury: onChain?.treasury ?? opts.hedgeTreasury,
    transactions: refused ? [] : [{
      to: snapshot.reserve, value: '0',
      data: encodeFunctionData({ abi: MOVVA_RESERVE_ABI, functionName: 'withdrawToHedge', args: [amount] }),
      call: `withdrawToHedge(${amount})`,
      description: `Send ${formatUsdt(amount)} from the Movva reserve to its hedge treasury`
        + `${opts.hedgeTreasury ? ` (expected: ${opts.hedgeTreasury})` : ''}; ratio after ${formatBps(ratioBps(T - amount, L, S))}`,
    }],
    refused, warnings,
  };
}

export interface RecapPlan {
  kind: 'recapitalize';
  reserve: Address;
  usdt: Address;
  blockNumber: bigint;
  rateBrlPerUsdtE18: bigint;
  bufferedRateBrlPerUsdtE18: bigint;
  targetRatioBps: number;
  /** What reaches the target at the snapshot's rate, and at the buffered rate. */
  toTargetUsdt: bigint;
  toTargetAtBufferedRateUsdt: bigint;
  /** What restores 100% at the buffered rate. */
  toFullAtBufferedRateUsdt: bigint;
  amountUsdt: bigint;
  binding: 'target' | 'requested';
  ratio: { beforeBps: bigint; afterBps: bigint; afterAtBufferedRateBps: bigint };
  from?: Address;
  transactions: PlannedTransaction[];
  refused?: string;
  warnings: string[];
}

/**
 * USDT that brings the ratio back to `targetRatioBps` (default: the reserve's target) even after the
 * execution buffer, as approve + recapitalize from `from`. Anyone may recapitalize; the sender is
 * whoever holds the USDT the hedge gains bought.
 */
export function planRecapitalize(snapshot: PricedSnapshot, opts: {
  amountUsdt?: bigint; targetRatioBps?: number; executionBufferBps?: number;
  from?: Address; allowance?: bigint; balance?: bigint; nowSeconds?: number;
} = {}): RecapPlan {
  const bufferBps = opts.executionBufferBps ?? DEFAULT_WITHDRAW_POLICY.executionBufferBps;
  checkPolicyBps('executionBufferBps', bufferBps);
  const target = opts.targetRatioBps ?? snapshot.thresholds.targetCollateralRatioBps;
  if (!Number.isInteger(target) || target <= 0) throw new Error('targetRatioBps must be a positive integer');
  const { totalUsdt: T, liabilitiesBrlE18: L, brlPerUsdtE18: S } = snapshot;
  const Sb = buffered(S, bufferBps);
  const toTarget = max(0n, usdtForRatio(BigInt(target), L, S) - T);
  const toTargetBuffered = max(0n, usdtForRatio(BigInt(target), L, Sb) - T);
  const toFullBuffered = max(0n, usdtForRatio(BPS, L, Sb) - T);
  const amount = opts.amountUsdt ?? toTargetBuffered;
  const warnings = snapshotWarnings(snapshot, opts.nowSeconds);
  let refused: string | undefined;
  if (snapshot.inconsistencies.length) {
    refused = `the reserve's figures do not agree with each other (${snapshot.inconsistencies.join('; ')}): find out why before moving USDT`;
  } else if (amount === 0n) {
    refused = `nothing to do: the reserve is at ${formatBps(snapshot.collateralRatioBps)}, at or above ${formatBps(target)} even at a rate ${formatBps(bufferBps)} lower`;
  }
  if (opts.amountUsdt !== undefined && opts.amountUsdt < toTargetBuffered && !refused) {
    warnings.push(`${formatUsdt(opts.amountUsdt)} does not reach ${formatBps(target)}: ${formatUsdt(toTargetBuffered)} would, at the buffered rate`);
  }
  if (opts.balance !== undefined && opts.from && opts.balance < amount) {
    warnings.push(`${opts.from} holds ${formatUsdt(opts.balance)}, less than ${formatUsdt(amount)}: the transaction would revert`);
  }
  const txs: PlannedTransaction[] = [];
  if (!refused) {
    const approve = (v: bigint, why: string): PlannedTransaction => ({
      to: snapshot.usdt, value: '0', data: encodeFunctionData({ abi: ERC20_ABI, functionName: 'approve', args: [snapshot.reserve, v] }),
      call: `approve(${snapshot.reserve}, ${v})`, description: why,
    });
    // Tether's approve refuses a non-zero to non-zero change; zero it unless it is known to be zero.
    if (opts.allowance === undefined || opts.allowance > 0n) {
      txs.push(approve(0n, 'Reset the USDT allowance to zero first (USDT refuses to change a non-zero allowance)'));
      if (opts.allowance === undefined) warnings.push('the sender\'s current allowance was not read: the plan resets it to zero first, which is harmless');
    }
    txs.push(approve(amount, `Allow the reserve to pull exactly ${formatUsdt(amount)}`));
    txs.push({
      to: snapshot.reserve, value: '0',
      data: encodeFunctionData({ abi: MOVVA_RESERVE_ABI, functionName: 'recapitalize', args: [amount] }),
      call: `recapitalize(${amount})`,
      description: `Add ${formatUsdt(amount)} to the Movva reserve without minting; ratio after ${formatBps(ratioBps(T + amount, L, S))}`,
    });
  }
  return {
    kind: 'recapitalize', reserve: snapshot.reserve, usdt: snapshot.usdt, blockNumber: snapshot.blockNumber,
    rateBrlPerUsdtE18: S, bufferedRateBrlPerUsdtE18: Sb, targetRatioBps: target,
    toTargetUsdt: toTarget, toTargetAtBufferedRateUsdt: toTargetBuffered, toFullAtBufferedRateUsdt: toFullBuffered,
    amountUsdt: refused ? 0n : amount, binding: opts.amountUsdt === undefined ? 'target' : 'requested',
    ratio: {
      beforeBps: snapshot.collateralRatioBps,
      afterBps: ratioBps(T + (refused ? 0n : amount), L, S),
      afterAtBufferedRateBps: ratioBps(T + (refused ? 0n : amount), L, Sb),
    },
    from: opts.from, transactions: txs, refused, warnings,
  };
}

/**
 * A plan's transactions in the Safe Transaction Builder's batch JSON shape (version 1.0), for a
 * multisig to import and review. No checksum is included; the Safe app computes and shows its own.
 * The shape is as the builder documents it - to confirm against the Safe version the issuer uses.
 */
export function safeTransactionBatch(txs: readonly PlannedTransaction[], opts: {
  chainId: number; safe?: Address; name: string; description: string; createdAt: number;
}) {
  return {
    version: '1.0',
    chainId: String(opts.chainId),
    createdAt: opts.createdAt,
    meta: { name: opts.name, description: opts.description, createdFromSafeAddress: opts.safe ?? '' },
    transactions: txs.map((t) => ({ to: t.to, value: t.value, data: t.data, contractMethod: null, contractInputsValues: null })),
  };
}

/**
 * `eth_call` the planned withdrawal from the treasurer's address at the snapshot's block. The
 * cheapest way to learn the deployed limit disagrees with the configured one - before three
 * people sign a transaction that reverts.
 */
export async function simulateWithdrawToHedge(
  client: Pick<PublicClient, 'simulateContract'>, plan: WithdrawPlan, treasurer: Address,
): Promise<{ ok: true } | { ok: false; reason: string }> {
  try {
    await client.simulateContract({
      address: plan.reserve, abi: MOVVA_RESERVE_DESK_ABI, functionName: 'withdrawToHedge', args: [plan.amountUsdt],
      account: treasurer, blockNumber: plan.blockNumber,
    });
    return { ok: true };
  } catch (e) {
    const reason = revertReason(e);
    if (reason === undefined) throw e;
    return { ok: false, reason };
  }
}

/*//////////////////////////////////////////////////////////////
                  THE QUEUE: ABOVE THE 24H LIMIT
//////////////////////////////////////////////////////////////*/

const isoTime = (seconds: bigint) => new Date(Number(seconds) * 1000).toISOString().replace('.000Z', 'Z');
const waitText = (seconds: bigint) => (seconds < 3_600n ? `${(seconds + 59n) / 60n} min` : `${(Number(seconds) / 3_600).toFixed(1)} h`);

export interface QueuePlan {
  kind: 'queueHedgeWithdrawal';
  reserve: Address;
  blockNumber: bigint;
  rateBrlPerUsdtE18: bigint;
  bufferedRateBrlPerUsdtE18: bigint;
  requestedUsdt?: bigint;
  amountUsdt: bigint;
  /** `floor`: the most the floor allows after what is already queued, at the buffered rate. */
  binding: 'floor' | 'requested';
  delaySeconds?: bigint;
  /** The earliest execution if the queue transaction landed at the plan's time. */
  executeAfterEstimate?: bigint;
  limits: {
    floorBps: number;
    /** What the reserve accepts now: its own check, at the current rate, ignoring other queued requests. */
    floorMaxNowUsdt: bigint;
    /** What still clears the floor after every pending request and a rate `executionBufferBps` lower. */
    floorMaxAfterPendingUsdt: bigint;
    pendingUsdt: bigint;
    /** The fast lane's room today, for comparison. */
    dailyRoomUsdt?: bigint;
  };
  ratio: { beforeBps: bigint; afterBps: bigint; afterPendingAtBufferedRateBps: bigint };
  hedgeTreasury?: Address;
  transactions: PlannedTransaction[];
  refused?: string;
  warnings: string[];
}

/**
 * `queueHedgeWithdrawal`: the slow lane, for a withdrawal the 24h bucket cannot take. The treasurer announces it, and
 * after `HEDGE_QUEUE_DELAY` anyone may execute it. Nothing can cancel it, so the plan refuses what the reserve would
 * refuse now (the floor at the current rate) and warns about what may not execute later: the floor is checked again
 * at execution, after every other pending request and whatever the rate has done during the delay.
 */
export function planQueueHedgeWithdrawal(snapshot: PricedSnapshot, opts: {
  amountUsdt?: bigint; pendingUsdt?: bigint; delaySeconds?: bigint; executionBufferBps?: number;
  hedgeTreasury?: Address; nowSeconds?: number;
} = {}): QueuePlan {
  const bufferBps = opts.executionBufferBps ?? DEFAULT_WITHDRAW_POLICY.executionBufferBps;
  checkPolicyBps('executionBufferBps', bufferBps);
  const { totalUsdt: T, liabilitiesBrlE18: L, brlPerUsdtE18: S } = snapshot;
  const Sb = buffered(S, bufferBps);
  const floorBps = snapshot.thresholds.minWithdrawCollateralRatioBps;
  const pending = opts.pendingUsdt ?? 0n;
  const floorMaxNow = max(0n, T - usdtForRatio(BigInt(floorBps), L, S));
  const floorMaxAfterPending = max(0n, T - pending - usdtForRatio(BigInt(floorBps), L, Sb));
  const dailyRoom = snapshot.hedge?.withdrawableUsdt;
  const warnings = [...snapshotWarnings(snapshot, opts.nowSeconds)];
  if (L === 0n) warnings.push('there is no Movva in circulation: nothing is hedged, so there is no margin to meet');
  if (snapshot.hedge && opts.hedgeTreasury && opts.hedgeTreasury.toLowerCase() !== snapshot.hedge.treasury.toLowerCase()) {
    warnings.push(`the reserve pays ${snapshot.hedge.treasury}, not the expected hedge treasury ${opts.hedgeTreasury}: do not sign until that is explained`);
  }

  let amount = opts.amountUsdt ?? floorMaxAfterPending;
  let refused: string | undefined;
  if (snapshot.inconsistencies.length) {
    refused = `the reserve's figures do not agree with each other (${snapshot.inconsistencies.join('; ')}): find out why before moving USDT`;
  } else if (amount === 0n) {
    refused = opts.amountUsdt === 0n
      ? 'the amount is zero'
      : `nothing can be queued: after ${formatUsdt(pending)} already pending, the reserve is at or under the ${formatBps(floorBps)} floor at a rate ${formatBps(bufferBps)} lower`;
  } else if (amount > floorMaxNow) {
    refused = `${formatUsdt(amount)} would leave the reserve under its ${formatBps(floorBps)} withdraw floor now: the reserve refuses to queue more than ${formatUsdt(floorMaxNow)}`;
  }
  if (!refused) {
    if (amount > floorMaxAfterPending) {
      warnings.push(`after the ${formatUsdt(pending)} already pending and a rate ${formatBps(bufferBps)} lower, executing this would breach the `
        + `${formatBps(floorBps)} floor (at most ${formatUsdt(floorMaxAfterPending)} clears it): it would wait until the reserve recovers or is recapitalized`);
    }
    if (dailyRoom !== undefined && amount <= dailyRoom) {
      warnings.push(`${formatUsdt(amount)} fits today's 24h allowance (${formatUsdt(dailyRoom)}): withdraw-plan pays it now instead of after the delay`);
    }
    warnings.push('nothing can cancel or change a queued withdrawal: once it is queued, anyone can execute it after the delay');
  }
  if (refused) amount = 0n;
  const executeAfter = opts.delaySeconds === undefined ? undefined : BigInt(opts.nowSeconds ?? Number(snapshot.blockTimestamp)) + opts.delaySeconds;
  return {
    kind: 'queueHedgeWithdrawal', reserve: snapshot.reserve, blockNumber: snapshot.blockNumber,
    rateBrlPerUsdtE18: S, bufferedRateBrlPerUsdtE18: Sb,
    requestedUsdt: opts.amountUsdt, amountUsdt: amount, binding: opts.amountUsdt === undefined ? 'floor' : 'requested',
    delaySeconds: opts.delaySeconds, executeAfterEstimate: executeAfter,
    limits: { floorBps, floorMaxNowUsdt: floorMaxNow, floorMaxAfterPendingUsdt: floorMaxAfterPending, pendingUsdt: pending, dailyRoomUsdt: dailyRoom },
    ratio: {
      beforeBps: snapshot.collateralRatioBps,
      afterBps: ratioBps(T - amount, L, S),
      afterPendingAtBufferedRateBps: ratioBps(max(0n, T - pending - amount), L, Sb),
    },
    hedgeTreasury: snapshot.hedge?.treasury ?? opts.hedgeTreasury,
    transactions: refused ? [] : [{
      to: snapshot.reserve, value: '0',
      data: encodeFunctionData({ abi: MOVVA_RESERVE_QUEUE_ABI, functionName: 'queueHedgeWithdrawal', args: [amount] }),
      call: `queueHedgeWithdrawal(${amount})`,
      description: `Queue ${formatUsdt(amount)} from the Movva reserve to its hedge treasury`
        + (opts.delaySeconds === undefined ? '' : `, executable by anyone ${waitText(opts.delaySeconds)} after it lands`)
        + `; it cannot be cancelled`,
    }],
    refused, warnings,
  };
}

export interface ExecutePlan {
  kind: 'executeHedgeWithdrawal';
  reserve: Address;
  blockNumber: bigint;
  request: HedgeRequest;
  /** At the snapshot's block: not executed and past `executeAfter`. */
  ready: boolean;
  floorBps: number;
  ratio: { beforeBps: bigint; afterBps: bigint; afterAtBufferedRateBps: bigint };
  transactions: PlannedTransaction[];
  refused?: string;
  warnings: string[];
}

/**
 * `executeHedgeWithdrawal(id)`: pays a queued request. Anyone may send it - no multisig is needed - once its delay has
 * passed; the reserve checks the floor again at the then-current rate, so a request that would breach it waits.
 *
 * Whether it is due is judged by the snapshot's block time, as the reserve judges it (`block.timestamp`), not by the
 * desk's clock; `nowSeconds` only dates the snapshot for the staleness warning.
 */
export function planExecuteHedgeWithdrawal(snapshot: PricedSnapshot, request: HedgeRequest, opts: {
  executionBufferBps?: number; nowSeconds?: number;
} = {}): ExecutePlan {
  const bufferBps = opts.executionBufferBps ?? DEFAULT_WITHDRAW_POLICY.executionBufferBps;
  checkPolicyBps('executionBufferBps', bufferBps);
  const { totalUsdt: T, liabilitiesBrlE18: L, brlPerUsdtE18: S } = snapshot;
  const Sb = buffered(S, bufferBps);
  const floorBps = snapshot.thresholds.minWithdrawCollateralRatioBps;
  const now = BigInt(snapshot.blockTimestamp);
  const after = ratioBps(max(0n, T - request.usdt), L, S);
  const afterBuffered = ratioBps(max(0n, T - request.usdt), L, Sb);
  const warnings = [...snapshotWarnings(snapshot, opts.nowSeconds)];
  let refused: string | undefined;
  if (request.executed) {
    refused = `request #${request.id} has already been executed`;
  } else if (now < request.executeAfter) {
    refused = `request #${request.id} is not executable yet: after ${isoTime(request.executeAfter)} (in ${waitText(request.executeAfter - now)} of chain time)`;
  } else if (snapshot.inconsistencies.length) {
    refused = `the reserve's figures do not agree with each other (${snapshot.inconsistencies.join('; ')}): find out why before moving USDT`;
  } else if (request.usdt > T || after < BigInt(floorBps)) {
    refused = `executing request #${request.id} now would leave the reserve at ${formatBps(after)}, under its ${formatBps(floorBps)} withdraw floor: `
      + 'it waits until the reserve recovers or is recapitalized';
  }
  if (!refused && afterBuffered < BigInt(floorBps)) {
    warnings.push(`at a rate ${formatBps(bufferBps)} lower the reserve would be at ${formatBps(afterBuffered)}, under the floor: execute promptly or it may revert`);
  }
  if (!refused) warnings.push(`pays exactly ${formatUsdt(request.usdt)} to ${request.to}, fixed when it was queued; anyone may send this transaction`);
  return {
    kind: 'executeHedgeWithdrawal', reserve: snapshot.reserve, blockNumber: snapshot.blockNumber, request,
    ready: !request.executed && now >= request.executeAfter, floorBps,
    ratio: { beforeBps: snapshot.collateralRatioBps, afterBps: after, afterAtBufferedRateBps: afterBuffered },
    transactions: refused ? [] : [{
      to: snapshot.reserve, value: '0',
      data: encodeFunctionData({ abi: MOVVA_RESERVE_QUEUE_ABI, functionName: 'executeHedgeWithdrawal', args: [request.id] }),
      call: `executeHedgeWithdrawal(${request.id})`,
      description: `Pay queued request #${request.id}: ${formatUsdt(request.usdt)} to ${request.to}; ratio after ${formatBps(after)}`,
    }],
    refused, warnings,
  };
}

/** `eth_call` a planned queue or execute transaction at the plan's block, from `from` (the treasurer, for a queue). */
export async function simulateQueuePlan(
  client: Pick<PublicClient, 'simulateContract'>, plan: QueuePlan | ExecutePlan, from?: Address,
): Promise<{ ok: true } | { ok: false; reason: string }> {
  try {
    await client.simulateContract({
      address: plan.reserve, abi: MOVVA_RESERVE_DESK_ABI, blockNumber: plan.blockNumber, ...(from ? { account: from } : {}),
      ...(plan.kind === 'queueHedgeWithdrawal'
        ? { functionName: 'queueHedgeWithdrawal', args: [plan.amountUsdt] }
        : { functionName: 'executeHedgeWithdrawal', args: [plan.request.id] }),
    } as never);
    return { ok: true };
  } catch (e) {
    const reason = revertReason(e);
    if (reason === undefined) throw e;
    return { ok: false, reason };
  }
}
