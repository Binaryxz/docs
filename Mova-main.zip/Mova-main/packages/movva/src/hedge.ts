/**
 * Hedge math: how much dollar to short, in which contracts, and what a move in USD/BRL costs.
 *
 * ## The position being hedged
 *
 * The reserve holds USDT against real-denominated Movva, so it is long `liabilitiesUsdt()` dollars
 * (USDT above that is surplus and deliberately unhedged). The issuer sells that many dollars on B3
 * dollar futures. Reserve plus short is then a synthetic real position: a move in USD/BRL shows up
 * as a reserve surplus and a margin call of the same size, or a deficit and a gain of the same size
 * - see docs/movva.md. Everything below is arithmetic on that identity, in bigints (units.ts).
 *
 * ## What can go wrong, and what this module does about it
 *
 *  - **Integer contracts.** A US$ 1,851,851.85 target cannot be sold exactly in US$ 10,000 lots.
 *    `planHedge` rounds to the nearest achievable position but never leaves the hedge below the
 *    policy band: when nearest would under-hedge beyond it, it rounds up. If the band, edge to
 *    edge, is narrower than the smallest contract, a position inside it may not exist; the plan says so
 *    (`bandAchievable: false`) and errs over-hedged, rather than oscillating.
 *  - **The chain cannot see the hedge.** Positions come from the broker statement, not from here.
 *    A plan against a stale position list re-sells what was already sold, so a plan always states
 *    the position it started from and statement.ts binds positions to a signed, dated document.
 *  - **Margin is paid in reais, tomorrow; the reserve holds dollars, on-chain, behind limits.**
 *    `shock` puts the two side by side: the BRL a move demands of the short against the USDT
 *    `withdrawToHedge` can release under the reserve's floor ratio and its 24h limit, and on the
 *    other side the USDT a recapitalization needs against what the hedge gains buy. A shock the
 *    limits cannot cover is flagged with the limit that binds and the issuer capital it would take.
 *  - **Assumed, not known.** B3 margin, the USDT/BRL conversion cost and the reserve's 24h limit
 *    (the interface has no view for it) are inputs with defaults marked "to confirm". A shock result
 *    lists the assumptions it used, so a number is never quoted without them.
 *
 * Futures are assumed to move one-for-one with the reserve's rate (no basis change during the
 * shock) and USDT is assumed to be worth a dollar: B3 futures hedge USD/BRL, not a USDT depeg,
 * which reaches the reserve through its Chainlink leg and is not covered by any of this.
 */
import {
  BPS, E6, UINT256_MAX, abs, ceilDiv, formatBps, formatBrl, formatUsdt, max, min, parseDecimal, roundDiv, truncDiv,
} from './units.js';
import { Fields } from './json.js';
import { DEFAULT_HEDGE_LIMIT_BPS, thresholdWarnings, type PricedSnapshot } from './reserve.js';

/*//////////////////////////////////////////////////////////////
                          INSTRUMENTS
//////////////////////////////////////////////////////////////*/

export interface Instrument {
  /** B3 ticker root: DOL, WDO. */
  symbol: string;
  /** Whole US dollars per contract. */
  contractSizeUsd: bigint;
  /** Where the size comes from, and what remains to confirm. Shown in plans. */
  source: string;
}

/**
 * B3's full-size dollar future. US$ 50,000 per contract, quoted in reais per US$ 1,000, cash
 * settled, expiring on the first business day of the month - as B3's product page states (read on
 * 14 September 2026). CONFIRM WITH THE BROKER: contract size, the standard lot (B3 lists five
 * contracts), margin, fees, and whether the broker offers DOL to this account at all.
 */
export const B3_DOL: Instrument = {
  symbol: 'DOL', contractSizeUsd: 50_000n,
  source: 'B3 product page (read 14 Sep 2026): US$ 50,000; confirm with the broker (size, lot of 5, margin, fees)',
};

/**
 * B3's mini dollar future. US$ 10,000 per contract, otherwise as DOL. CONFIRM WITH THE BROKER.
 */
export const B3_WDO: Instrument = {
  symbol: 'WDO', contractSizeUsd: 10_000n,
  source: 'B3 product page (read 14 Sep 2026): US$ 10,000; confirm with the broker (size, margin, fees)',
};

export const DEFAULT_INSTRUMENTS: readonly Instrument[] = [B3_DOL, B3_WDO];

/**
 * A B3 dollar-future price - reais per US$ 1,000, e.g. "5402.500" - as reais per dollar at 1e-6.
 * The two scales coincide: 5402.500 per thousand is 5.402500 per dollar. More than three decimals
 * is refused (B3's tick is R$ 0,50 per US$ 1,000).
 */
export const b3QuoteToBrlPerUsdE6 = (quote: string): bigint => parseDecimal(quote, 3, 'B3 quote (reais per US$ 1,000)');

/*//////////////////////////////////////////////////////////////
                           POSITIONS
//////////////////////////////////////////////////////////////*/

export type Side = 'short' | 'long';

export interface Position {
  instrument: string;
  /** Contract with its maturity code, e.g. WDOV26. */
  ticker: string;
  /** Expiry date, YYYY-MM-DD. */
  expiry: string;
  side: Side;
  contracts: bigint;
  averagePriceBrlPerUsdE6: bigint;
}

export function instrumentOf(instruments: readonly Instrument[], symbol: string): Instrument {
  const i = instruments.find((x) => x.symbol === symbol);
  if (!i) throw new Error(`unknown instrument ${symbol}: configure its contract size (known: ${instruments.map((x) => x.symbol).join(', ')})`);
  if (i.contractSizeUsd <= 0n) throw new Error(`instrument ${symbol} has a non-positive contract size`);
  return i;
}

/** Dollars one position is short, 6 decimals; negative for a long. */
export function positionShortUsdE6(p: Position, instruments: readonly Instrument[]): bigint {
  if (p.contracts < 0n) throw new Error(`${p.ticker}: contracts must be non-negative; the side carries the sign`);
  const n = p.contracts * instrumentOf(instruments, p.instrument).contractSizeUsd * E6;
  return p.side === 'short' ? n : -n;
}

export const netShortUsdE6 = (positions: readonly Position[], instruments: readonly Instrument[]): bigint =>
  positions.reduce((a, p) => a + positionShortUsdE6(p, instruments), 0n);

/**
 * Hedge ratio in basis points, toward zero: 10_000 is fully hedged. Undefined with nothing to hedge
 * (a zero target), where no ratio means anything - `withinBand` handles that case on its own.
 */
export function hedgeRatioBps(shortUsdE6: bigint, targetUsdE6: bigint): bigint | undefined {
  if (targetUsdE6 < 0n) throw new Error('hedge target cannot be negative');
  return targetUsdE6 === 0n ? undefined : truncDiv(shortUsdE6 * BPS, targetUsdE6);
}

const atOrAboveFloor = (p: bigint, t: bigint, band: bigint) => p * BPS >= t * (BPS - band);
const atOrBelowCeiling = (p: bigint, t: bigint, band: bigint) => p * BPS <= t * (BPS + band);

/** Within ±`bandBps` of the target, edges included. With a zero target, only a flat book is. */
export function withinBand(shortUsdE6: bigint, targetUsdE6: bigint, bandBps: number): boolean {
  const band = BigInt(bandBps);
  if (targetUsdE6 === 0n) return shortUsdE6 === 0n;
  return atOrAboveFloor(shortUsdE6, targetUsdE6, band) && atOrBelowCeiling(shortUsdE6, targetUsdE6, band);
}

/*//////////////////////////////////////////////////////////////
                           REBALANCING
//////////////////////////////////////////////////////////////*/

export interface HedgePolicy {
  instruments: readonly Instrument[];
  /** Keep the hedge ratio within ±this. Rebalance only outside it, and then to the nearest position. */
  bandBps: number;
  /** Ticker to trade per instrument (the month being rolled into), e.g. { WDO: 'WDOV26' }. */
  tickers?: Record<string, string>;
  /** Flag positions expiring within this many days. */
  rollWithinDays?: number;
}

export interface HedgeOrder {
  instrument: string;
  ticker?: string;
  /** `sell` adds to the short. */
  side: 'sell' | 'buy';
  contracts: bigint;
  notionalUsdE6: bigint;
}

export interface HedgePlan {
  targetUsdE6: bigint;
  currentUsdE6: bigint;
  currentRatioBps?: bigint;
  bandBps: number;
  withinBand: boolean;
  orders: HedgeOrder[];
  afterUsdE6: bigint;
  afterRatioBps?: bigint;
  afterWithinBand: boolean;
  /** Whether the smallest contract fits inside the band at this target (width >= one contract). */
  bandAchievable: boolean;
  rolls: { ticker: string; expiry: string; daysToExpiry: number }[];
  notes: string[];
}

/** Whole days from `asOf` (unix seconds) to 00:00 UTC of `expiry` (YYYY-MM-DD). */
export function daysToExpiry(expiry: string, asOf: number): number {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(expiry);
  if (!m) throw new Error(`expiry must be YYYY-MM-DD; got "${expiry}"`);
  return Math.floor((Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3])) / 1000 - asOf) / 86_400);
}

/**
 * The orders that bring the net short to `targetUsdE6`, or none while it is inside the band.
 *
 * Larger contracts first, each truncated toward the target so none overshoots (and, when
 * reducing, no further than that contract is held short); the smallest
 * contract then takes the remainder, rounded to the nearest position that is not below the band's
 * floor (ties go to the more hedged). So after the orders:
 *  - the hedge is never under the band's floor (for a positive target), and
 *  - it is inside the band whenever the band is at least one smallest contract wide.
 * Both are property-tested.
 */
export function planHedge(input: {
  targetUsdE6: bigint; positions: readonly Position[]; policy: HedgePolicy; asOf?: number;
}): HedgePlan {
  const { targetUsdE6: T, positions, policy } = input;
  if (T < 0n) throw new Error('hedge target cannot be negative');
  if (!Number.isInteger(policy.bandBps) || policy.bandBps < 0 || policy.bandBps >= 10_000) {
    throw new Error('bandBps must be an integer from 0 to 9999');
  }
  if (policy.instruments.length === 0) throw new Error('no instruments configured');
  const symbols = new Set<string>();
  for (const i of policy.instruments) {
    if (symbols.has(i.symbol)) throw new Error(`instrument ${i.symbol} is configured twice`);
    symbols.add(i.symbol);
    if (i.contractSizeUsd <= 0n) throw new Error(`instrument ${i.symbol} has a non-positive contract size`);
  }
  const band = BigInt(policy.bandBps);
  const H = netShortUsdE6(positions, policy.instruments);
  const bySize = [...policy.instruments].sort((a, b) => (a.contractSizeUsd > b.contractSizeUsd ? -1 : a.contractSizeUsd < b.contractSizeUsd ? 1 : 0));
  const smallest = bySize[bySize.length - 1].contractSizeUsd * E6;
  const bandAchievable = T === 0n || smallest * BPS <= 2n * T * band;
  const notes: string[] = [];

  const rolls = input.asOf === undefined ? [] : positions
    .map((p) => ({ ticker: p.ticker, expiry: p.expiry, daysToExpiry: daysToExpiry(p.expiry, input.asOf!) }))
    .filter((r) => r.daysToExpiry <= (policy.rollWithinDays ?? 5));
  for (const r of rolls) {
    notes.push(r.daysToExpiry < 0
      ? `${r.ticker} expired ${-r.daysToExpiry} day(s) ago: the statement lists a position that should no longer exist`
      : `${r.ticker} expires in ${r.daysToExpiry} day(s) (${r.expiry}): roll it (B3 last trading day is the session before expiry - to confirm with the broker)`);
  }

  const inside = withinBand(H, T, policy.bandBps);
  const orders: HedgeOrder[] = [];
  let after = H;
  if (!inside) {
    const D = T - H;
    const sign = D > 0n ? 1n : -1n;
    let rem = abs(D);
    // Reducing, a larger contract is only bought back as far as it is held short: a book of WDO
    // is closed in WDO, not by opening a DOL long against it (same net dollars, two open lines).
    const heldShort = (symbol: string) => positions
      .filter((x) => x.instrument === symbol)
      .reduce((a, x) => a + (x.side === 'short' ? x.contracts : -x.contracts), 0n);
    for (const inst of bySize.slice(0, -1)) {
      const size = inst.contractSizeUsd * E6;
      const n = sign < 0n ? min(rem / size, max(0n, heldShort(inst.symbol))) : rem / size;
      if (n > 0n) {
        orders.push(order(inst, n, sign, policy));
        rem -= n * size;
        after += sign * n * size;
      }
    }
    const last = bySize[bySize.length - 1];
    const lo = rem / smallest;
    const candidates = rem % smallest === 0n ? [lo] : [lo, lo + 1n];
    const scored = candidates
      .map((n) => ({ n, p: after + sign * n * smallest }))
      .filter((c) => atOrAboveFloor(c.p, T, band));
    scored.sort((a, b) => {
      const da = abs(a.p - T); const db = abs(b.p - T);
      return da < db ? -1 : da > db ? 1 : a.p > b.p ? -1 : 1;
    });
    // Never empty: selling, the larger count lands at or above T; buying back, the smaller does.
    const pick = scored[0];
    if (!pick) throw new Error('internal: no rounding candidate reaches the band floor');
    if (pick.n > 0n) orders.push(order(last, pick.n, sign, policy));
    after = pick.p;
    if (!bandAchievable) {
      notes.push(`the band (±${policy.bandBps} bps of ${T / E6} USD) is narrower than one ${last.symbol} contract: `
        + 'no position is inside it, so the plan rounds to the nearest position that is not under-hedged');
    }
  }
  for (const i of policy.instruments) notes.push(`${i.symbol}: ${i.source}`);
  return {
    targetUsdE6: T, currentUsdE6: H, currentRatioBps: hedgeRatioBps(H, T), bandBps: policy.bandBps, withinBand: inside,
    orders, afterUsdE6: after, afterRatioBps: hedgeRatioBps(after, T), afterWithinBand: withinBand(after, T, policy.bandBps),
    bandAchievable, rolls, notes,
  };
}

function order(inst: Instrument, n: bigint, sign: bigint, policy: HedgePolicy): HedgeOrder {
  return {
    instrument: inst.symbol, ticker: policy.tickers?.[inst.symbol], side: sign > 0n ? 'sell' : 'buy',
    contracts: n, notionalUsdE6: n * inst.contractSizeUsd * E6,
  };
}

/*//////////////////////////////////////////////////////////////
                             SHOCKS
//////////////////////////////////////////////////////////////*/

export interface ShockAssumptions {
  /**
   * The reserve's 24h `withdrawToHedge` limit, in bps of `totalUsdt` (default 8%). A snapshot that
   * carries the reserve's `hedgeLimitBps()` overrides this: the configured number is only the
   * fallback for a reserve without the view.
   */
  withdrawDailyLimitBps: number;
  /**
   * Already withdrawn inside the current window (reserve.ts `readHedgeWithdrawals`). Fallback only:
   * ignored when the reserve's own `hedgeWithdrawable()` is known.
   */
  withdrawnInWindowUsdt: bigint;
  /**
   * What the reserve's refilling 24h bucket holds now (`hedgeWithdrawable()`): the first day's
   * allowance, exactly. Taken from the snapshot when it has it.
   */
  withdrawableNowUsdt?: bigint;
  /**
   * B3 initial margin as bps of the short's notional in reais. An ASSUMPTION - B3 computes margin
   * with its own risk model and brokers add to it; TO CONFIRM with the broker. It moves with the
   * notional, so a dollar rally raises it on top of the variation.
   */
  initialMarginBps: number;
  /** All-in cost of converting USDT to reais or back (spread + fees), bps. An assumption. */
  conversionCostBps: number;
  /** Days over which the move happens: the 24h bucket refills each day; the floor does not. */
  days: number;
}

export const DEFAULT_SHOCK_ASSUMPTIONS: ShockAssumptions = {
  withdrawDailyLimitBps: DEFAULT_HEDGE_LIMIT_BPS,
  withdrawnInWindowUsdt: 0n,
  initialMarginBps: 1_000,
  conversionCostBps: 30,
  days: 1,
};

/**
 * USD/BRL at the last PTAX (venda) of 2023 and of 2024, from the Banco Central do Brasil's PTAX
 * service (read 14 September 2026): R$ 4,8413 on 29/12/2023 and R$ 6,1923 on 31/12/2024, a
 * +27.9% year. docs/movva.md rounds the start to "about R$ 4,90", which is the first PTAX of 2024
 * (R$ 4,8916 on 02/01/2024).
 */
export const PTAX_2024 = {
  start: { date: '2023-12-29', brlPerUsdE6: 4_841_300n },
  end: { date: '2024-12-31', brlPerUsdE6: 6_192_300n },
  source: 'BCB PTAX venda via olinda.bcb.gov.br, read 14 Sep 2026',
} as const;

/** The move from one rate to another in bps, toward zero. */
export const moveBpsBetween = (fromE6: bigint, toE6: bigint): bigint => truncDiv((toE6 - fromE6) * BPS, fromE6);

/** ±5%, ±10%, and 2024's move in both directions (+27.9%, and its reversal, -21.8%). */
export const STANDARD_SHOCKS: readonly { label: string; moveBps: bigint }[] = [
  { label: '+5%', moveBps: 500n },
  { label: '-5%', moveBps: -500n },
  { label: '+10%', moveBps: 1_000n },
  { label: '-10%', moveBps: -1_000n },
  { label: '2024 (R$ 4,8413 -> 6,1923)', moveBps: moveBpsBetween(PTAX_2024.start.brlPerUsdE6, PTAX_2024.end.brlPerUsdE6) },
  { label: '2024 reversed (R$ 6,1923 -> 4,8413)', moveBps: moveBpsBetween(PTAX_2024.end.brlPerUsdE6, PTAX_2024.start.brlPerUsdE6) },
];

export interface ShockInput {
  snapshot: Pick<PricedSnapshot, 'brlPerUsdtE18' | 'totalUsdt' | 'liabilitiesBrlE18' | 'thresholds' | 'hedge'>;
  /** Net dollars short, 6 decimals: from the latest verified statement, or the target if assumed. */
  hedgeShortUsdE6: bigint;
  /** The hedge account from the statement. Free margin (balance above requirement) absorbs calls first. */
  margin?: { balanceBrlE18: bigint; requiredBrlE18: bigint };
  /** Signed: +500 is the dollar up 5% against the real. */
  moveBps: bigint | number;
  label?: string;
  assumptions?: Partial<ShockAssumptions>;
}

export interface ShockResult {
  label: string;
  moveBps: bigint;
  assumptions: ShockAssumptions;
  rate: { beforeE18: bigint; afterE18: bigint };
  reserve: { beforeBrlE18: bigint; afterBrlE18: bigint; changeBrlE18: bigint; ratioBeforeBps: bigint; ratioAfterBps: bigint };
  hedge: {
    shortUsdE6: bigint;
    /** Mark-to-market of the short: positive is a gain. */
    variationBrlE18: bigint;
    /** Change in initial margin required: positive must be posted. */
    initialMarginChangeBrlE18: bigint;
    freeMarginBrlE18: bigint;
    /** variation - margin change: positive is cash released to the issuer, negative must be posted. */
    cashFlowBrlE18: bigint;
  };
  marginCall: {
    needBrlE18: bigint;
    floorMaxUsdt: bigint;
    dailyMaxUsdt: bigint;
    withdrawableUsdt: bigint;
    binding: 'floor' | 'daily-limit';
    /** Where the 24h allowance came from: the reserve's own views, or configuration and events. */
    limitSource: 'reserve' | 'assumption';
    withdrawableBrlNetE18: bigint;
    /** What to withdraw: the need in USDT, capped by the limits. */
    withdrawUsdt: bigint;
    ratioAfterWithdrawBps: bigint;
    /** Reais the issuer must post from its own capital. */
    shortfallBrlE18: bigint;
  };
  recapitalization: {
    toTargetUsdt: bigint;
    toFullUsdt: bigint;
    /** Hedge cash (released + free margin) converted to USDT, net of conversion cost. */
    fromHedgeUsdt: bigint;
    issuerCapitalToTargetUsdt: bigint;
    issuerCapitalToFullUsdt: bigint;
    ratioAfterBps: bigint;
  };
  rehedge: { targetAfterUsdE6: bigint; hedgeRatioAfterBps?: bigint };
  covered: boolean;
  flags: string[];
}

/** USDT the reserve must hold for `ratioBps` at `rate`: the least U with floor(floor(U·S/1e6)·1e4/L) >= ratio. */
export function usdtForRatio(ratioBps: bigint, liabilitiesBrlE18: bigint, brlPerUsdtE18: bigint): bigint {
  return ceilDiv(ceilDiv(ratioBps * liabilitiesBrlE18, BPS) * E6, brlPerUsdtE18);
}

/** The reserve's ratio as the interface computes it. */
export function ratioBps(totalUsdt: bigint, liabilitiesBrlE18: bigint, brlPerUsdtE18: bigint): bigint {
  return liabilitiesBrlE18 === 0n ? UINT256_MAX : (totalUsdt * brlPerUsdtE18 / E6) * BPS / liabilitiesBrlE18;
}

export function shock(input: ShockInput): ShockResult {
  const onChain = input.snapshot.hedge;
  // The reserve's own limit and bucket win over configuration; configuration is the fallback.
  const a: ShockAssumptions = {
    ...DEFAULT_SHOCK_ASSUMPTIONS, ...input.assumptions,
    ...(onChain ? { withdrawDailyLimitBps: onChain.limitBps, withdrawableNowUsdt: onChain.withdrawableUsdt, withdrawnInWindowUsdt: 0n } : {}),
  };
  for (const k of ['withdrawDailyLimitBps', 'initialMarginBps', 'conversionCostBps'] as const) {
    if (!Number.isInteger(a[k]) || a[k] < 0 || a[k] > 10_000) throw new Error(`${k} must be an integer from 0 to 10000`);
  }
  if (!Number.isInteger(a.days) || a.days < 1) throw new Error('days must be a positive integer');
  const m = BigInt(input.moveBps);
  if (m <= -BPS) throw new Error('a move of -100% or more leaves no rate');
  const { snapshot: s } = input;
  const S0 = s.brlPerUsdtE18;
  if (S0 <= 0n) throw new Error('the rate must be positive');
  const T = s.totalUsdt;
  const L = s.liabilitiesBrlE18;
  const H = input.hedgeShortUsdE6;

  // Toward zero, so +m and -m are exact negatives: the symmetry the property tests pin.
  const dS = truncDiv(S0 * m, BPS);
  const S1 = S0 + dS;
  const cost = BigInt(a.conversionCostBps);

  const reserveBefore = T * S0 / E6;
  const reserveAfter = T * S1 / E6;
  const ratioBefore = ratioBps(T, L, S0);
  const ratioAfter = ratioBps(T, L, S1);

  const variation = -truncDiv(H * dS, E6);
  const imChange = truncDiv(abs(H) * dS * BigInt(a.initialMarginBps), E6 * BPS);
  const free = input.margin ? max(0n, input.margin.balanceBrlE18 - input.margin.requiredBrlE18) : 0n;
  const cashFlow = variation - imChange;

  // The margin call, against withdrawToHedge at the shocked rate.
  const need = max(0n, -cashFlow - free);
  const floorMax = max(0n, T - usdtForRatio(BigInt(s.thresholds.minWithdrawCollateralRatioBps), L, S1));
  // Day one: what the bucket holds now (the reserve's answer, or the configured limit less what
  // was withdrawn in the window). Each further day refills a full day's limit.
  const firstDay = a.withdrawableNowUsdt ?? max(0n, T * BigInt(a.withdrawDailyLimitBps) / BPS - a.withdrawnInWindowUsdt);
  const dailyMax = firstDay + T * BigInt(a.withdrawDailyLimitBps) * BigInt(a.days - 1) / BPS;
  const withdrawable = min(floorMax, dailyMax);
  const netBrl = (usdt: bigint) => usdt * S1 / E6 * (BPS - cost) / BPS;
  const usdtFor = (brl: bigint) => (brl === 0n ? 0n : ceilDiv(brl * E6 * BPS, S1 * (BPS - cost)));
  const withdrawUsdt = cost === BPS ? 0n : min(withdrawable, usdtFor(need));
  const shortfall = max(0n, need - netBrl(withdrawable));

  // The other side: USDT to restore the ratio, against what the hedge's cash buys.
  const toTarget = max(0n, usdtForRatio(BigInt(s.thresholds.targetCollateralRatioBps), L, S1) - T);
  const toFull = max(0n, usdtForRatio(BPS, L, S1) - T);
  // A loss eats free margin first; a gain adds to it. Either way what is left can be brought back.
  const hedgeCash = max(0n, cashFlow + free);
  const fromHedge = hedgeCash * (BPS - cost) / BPS * E6 / S1;
  const recapUsdt = min(fromHedge, toTarget);

  const targetAfter = L * E6 / S1;
  const flags: string[] = [...thresholdWarnings(s.thresholds)];
  const configured = input.assumptions?.withdrawDailyLimitBps;
  if (onChain && configured !== undefined && configured !== onChain.limitBps) {
    flags.push(`the configured 24h limit (${formatBps(configured)}) differs from the reserve's hedgeLimitBps (${formatBps(onChain.limitBps)}): `
      + 'using the reserve\'s. Update the desk and monitor configuration');
  }
  if (need > 0n && shortfall > 0n) {
    flags.push(`MARGIN CALL NOT COVERED: the short needs ${formatBrl(need)}; withdrawToHedge releases at most `
      + `${formatUsdt(withdrawable)} (${formatBrl(netBrl(withdrawable))} after conversion) in ${a.days} day(s), bound by the `
      + `${binding(floorMax, dailyMax) === 'floor' ? `${formatBps(s.thresholds.minWithdrawCollateralRatioBps)} withdraw floor` : '24h limit'}; `
      + `the issuer must post ${formatBrl(shortfall)} of its own capital`);
  }
  if (ratioAfter < BPS) {
    flags.push(`UNDER-BACKED after the move, before any recapitalization: ratio ${formatBps(ratioAfter)}; redeem pays that share of R$ 1,00 and mint halts`);
  }
  const issuerToFull = max(0n, toFull - fromHedge);
  const issuerToTarget = max(0n, toTarget - fromHedge);
  if (issuerToFull > 0n) {
    flags.push(`HEDGE CASH DOES NOT RESTORE FULL BACKING: ${formatUsdt(issuerToFull)} of issuer capital needed to reach 100%`);
  } else if (issuerToTarget > 0n) {
    flags.push(`hedge cash restores full backing but not the target ratio: ${formatUsdt(issuerToTarget)} of issuer capital to reach `
      + `${formatBps(s.thresholds.targetCollateralRatioBps)} (the surplus above 100% is unhedged by design)`);
  }
  const rehedgeRatio = hedgeRatioBps(H, targetAfter);
  return {
    label: input.label ?? `${m >= 0n ? '+' : ''}${m} bps`,
    moveBps: m, assumptions: a,
    rate: { beforeE18: S0, afterE18: S1 },
    reserve: { beforeBrlE18: reserveBefore, afterBrlE18: reserveAfter, changeBrlE18: truncDiv(T * dS, E6), ratioBeforeBps: ratioBefore, ratioAfterBps: ratioAfter },
    hedge: { shortUsdE6: H, variationBrlE18: variation, initialMarginChangeBrlE18: imChange, freeMarginBrlE18: free, cashFlowBrlE18: cashFlow },
    marginCall: {
      needBrlE18: need, floorMaxUsdt: floorMax, dailyMaxUsdt: dailyMax, withdrawableUsdt: withdrawable,
      binding: binding(floorMax, dailyMax), limitSource: a.withdrawableNowUsdt === undefined ? 'assumption' : 'reserve',
      withdrawableBrlNetE18: netBrl(withdrawable), withdrawUsdt,
      ratioAfterWithdrawBps: ratioBps(T - withdrawUsdt, L, S1), shortfallBrlE18: shortfall,
    },
    recapitalization: {
      toTargetUsdt: toTarget, toFullUsdt: toFull, fromHedgeUsdt: fromHedge,
      issuerCapitalToTargetUsdt: issuerToTarget, issuerCapitalToFullUsdt: issuerToFull,
      ratioAfterBps: ratioBps(T + recapUsdt, L, S1),
    },
    rehedge: { targetAfterUsdE6: targetAfter, hedgeRatioAfterBps: rehedgeRatio },
    covered: shortfall === 0n && issuerToFull === 0n,
    flags,
  };
}

const binding = (floorMax: bigint, dailyMax: bigint): 'floor' | 'daily-limit' => (floorMax <= dailyMax ? 'floor' : 'daily-limit');

/*//////////////////////////////////////////////////////////////
                      STANDING FREE MARGIN
//////////////////////////////////////////////////////////////*/

export interface FreeMarginRecommendation {
  /** The one-day dollar rally the margin is sized for, bps (default +10%). */
  stressMoveBps: bigint;
  /** Margin that rally calls for with no free margin: variation plus the initial-margin increase. */
  needBrlE18: bigint;
  /** What `withdrawToHedge` releases now, before the move: today's floor, today's bucket. */
  releasableNowUsdt: bigint;
  /** ... converted at today's rate, net of conversion cost. */
  releasableNowBrlE18: bigint;
  /**
   * The recommendation: free margin to hold at the broker so the rally is met without issuer capital
   * even if the reserve can release only what it allows now. Conservative on purpose - see below.
   */
  freeMarginBrlE18: bigint;
  /** Share of the Movva supply, bps. */
  freeMarginOfSupplyBps: bigint;
  /**
   * The same, if the oracle has repriced before the margin is due, so the floor is measured at the
   * stressed rate and the USDT sells at it: the `shock()` view, and a lower number.
   */
  freeMarginIfRepricedBrlE18: bigint;
  /** Free margin the statement reports, and the top-up to reach the recommendation. */
  currentFreeMarginBrlE18?: bigint;
  topUpBrlE18?: bigint;
  basis: string;
}

export const DEFAULT_STRESS_MOVE_BPS = 1_000;

/**
 * The smallest free margin at the broker that meets a one-day dollar rally of `stressMoveBps`
 * together with what the reserve can release to the hedge.
 *
 * ## Why "now", not "after the move"
 *
 * A margin call is sized by the day's futures move; the reserve's floor moves with its oracle rate.
 * On the stress day those can part: the FX leg may be stale (and the reserve refusing) exactly when
 * the market is moving, the treasurer multisig takes hours, and the bucket may already be partly
 * spent. So the recommendation counts only what `withdrawToHedge` allows at the snapshot - today's
 * floor at today's rate, the bucket as it stands - converted at today's rate. `shock()`'s
 * after-the-move figure is reported beside it as the optimistic bound. Zero means the reserve
 * alone covers the stress even on this basis.
 */
export function recommendFreeMargin(input: Omit<ShockInput, 'moveBps' | 'label' | 'margin'> & {
  stressMoveBps?: bigint | number;
  /** The statement's margin account, to report the top-up. */
  margin?: { balanceBrlE18: bigint; requiredBrlE18: bigint };
}): FreeMarginRecommendation {
  const m = BigInt(input.stressMoveBps ?? DEFAULT_STRESS_MOVE_BPS);
  if (m <= 0n) throw new Error('the stress move is a dollar rally: a positive number of bps');
  // One day, no free margin: the gap is what free margin must fill.
  const stressed = shock({ snapshot: input.snapshot, hedgeShortUsdE6: input.hedgeShortUsdE6, moveBps: m, assumptions: { ...input.assumptions, days: 1 } });
  const s = input.snapshot;
  const a = stressed.assumptions;
  const T = s.totalUsdt;
  const S0 = s.brlPerUsdtE18;
  const floorNow = max(0n, T - usdtForRatio(BigInt(s.thresholds.minWithdrawCollateralRatioBps), s.liabilitiesBrlE18, S0));
  const bucketNow = a.withdrawableNowUsdt ?? max(0n, T * BigInt(a.withdrawDailyLimitBps) / BPS - a.withdrawnInWindowUsdt);
  const releasableNowUsdt = min(floorNow, bucketNow);
  const releasableNowBrlE18 = releasableNowUsdt * S0 / E6 * (BPS - BigInt(a.conversionCostBps)) / BPS;
  const need = stressed.marginCall.needBrlE18;
  const freeMargin = max(0n, need - releasableNowBrlE18);
  const current = input.margin ? max(0n, input.margin.balanceBrlE18 - input.margin.requiredBrlE18) : undefined;
  return {
    stressMoveBps: m, needBrlE18: need, releasableNowUsdt, releasableNowBrlE18,
    freeMarginBrlE18: freeMargin,
    freeMarginOfSupplyBps: s.liabilitiesBrlE18 === 0n ? 0n : ceilDiv(freeMargin * BPS, s.liabilitiesBrlE18),
    freeMarginIfRepricedBrlE18: stressed.marginCall.shortfallBrlE18,
    currentFreeMarginBrlE18: current,
    topUpBrlE18: current === undefined ? undefined : max(0n, freeMargin - current),
    basis: `a one-day +${formatBps(m)} dollar move; withdrawToHedge counted at what it allows now `
      + `(floor at today's rate, ${stressed.marginCall.limitSource === 'reserve' ? 'the reserve\'s hedgeWithdrawable()' : 'the configured 24h limit'}), `
      + `initial margin ${formatBps(a.initialMarginBps)} of notional, conversion ${formatBps(a.conversionCostBps)}`,
  };
}

/*//////////////////////////////////////////////////////////////
                              CARRY
//////////////////////////////////////////////////////////////*/

export interface Carry {
  /** Futures minus spot, reais per dollar at 1e-6. Positive: the short earns it as the future converges. */
  basisBrlPerUsdE6: bigint;
  periodBps: bigint;
  /** Simple (not compounded) annualisation over `dayBasis`. */
  annualizedBps: bigint;
  /** Reais the notional earns over the period if the basis converges, 18 decimals. */
  carryBrlE18?: bigint;
}

/**
 * The carry a short earns from selling a future above spot: roughly the Brazil-US rate
 * differential.
 *
 * `days` and `dayBasis` go together: calendar days over 365, or business days over 252 (the B3
 * convention for rates - to confirm for how the desk reports carry).
 */
export function carry(p: {
  futuresBrlPerUsdE6: bigint; spotBrlPerUsdE6: bigint; days: number; dayBasis?: number; notionalUsdE6?: bigint;
}): Carry {
  if (p.spotBrlPerUsdE6 <= 0n || p.futuresBrlPerUsdE6 <= 0n) throw new Error('prices must be positive');
  if (!Number.isInteger(p.days) || p.days < 1) throw new Error('days to expiry must be a positive integer');
  const basisDays = BigInt(p.dayBasis ?? 365);
  const basis = p.futuresBrlPerUsdE6 - p.spotBrlPerUsdE6;
  return {
    basisBrlPerUsdE6: basis,
    periodBps: roundDiv(basis * BPS, p.spotBrlPerUsdE6),
    annualizedBps: roundDiv(basis * BPS * basisDays, p.spotBrlPerUsdE6 * BigInt(p.days)),
    // usdE6 x (reais per dollar)E6 = reais E12; x1e6 for E18.
    carryBrlE18: p.notionalUsdE6 === undefined ? undefined : p.notionalUsdE6 * basis * E6,
  };
}

/**
 * A positions file as the desk keeps it, transcribed from the broker statement:
 *
 *   { "positions": [{ "instrument": "WDO", "ticker": "WDOV26", "expiry": "2026-10-01", "side": "short",
 *                     "contracts": "185", "averagePrice": "5412.500" }] }
 *
 * `averagePrice` is in B3's quote convention, reais per US$ 1,000, as the statement prints it.
 */
export function positionsFromJson(raw: unknown): Position[] {
  const f = new Fields();
  const o = f.obj(raw, 'positions file');
  const out = f.arr(o.positions, 'positions').map((x, i) => {
    const p = `positions[${i}]`;
    const po = f.obj(x, p);
    const price = f.str(po, 'averagePrice', p);
    let averagePriceBrlPerUsdE6 = 0n;
    try {
      averagePriceBrlPerUsdE6 = b3QuoteToBrlPerUsdE6(price);
    } catch {
      f.problems.push(`${p}.averagePrice must be a B3 quote in reais per US$ 1,000, like "5412.500"`);
    }
    const contracts = f.big(po, 'contracts', p);
    if (contracts === 0n) f.problems.push(`${p}.contracts must be positive (leave closed positions out)`);
    return {
      instrument: f.str(po, 'instrument', p, /^[A-Z0-9]{1,16}$/),
      ticker: f.str(po, 'ticker', p, /^[A-Z0-9]{1,16}$/),
      expiry: f.str(po, 'expiry', p, /^\d{4}-\d{2}-\d{2}$/),
      side: f.str(po, 'side', p, /^(short|long)$/) as Side,
      contracts,
      averagePriceBrlPerUsdE6,
    };
  });
  f.done('positions file');
  return out;
}
