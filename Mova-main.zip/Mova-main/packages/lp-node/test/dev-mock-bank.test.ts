import { afterEach, describe, expect, it } from 'vitest';
import type { Hex } from 'viem';
import { Rail, proofPayment } from '@mova/ramp';
import { MockBank, type BankAdapter } from '../src/bank.js';
import { localWitnessReceipts } from '../src/bin/lp-node.js';
import { ConfigError, lpNodeConfigFromEnv, type Env } from '../src/config.js';
import {
  MockBankClient, devMockBankBase, devWireParse, devWireStringify, serveDevMockBank,
} from '../src/dev-mock-bank.js';
import { LocalWitnessSession, type ReceiptSource, type ZkTlsSessionRequest } from '../src/zktls.js';
import { LP_PIX_KEY, RECEIPT_TEMPLATES, WITNESS_KEYS } from './harness.js';

/**
 * dev-mock-bank.ts: the dev stack's MockBank served to an LP node in another process (the services
 * image), the clients that node uses, and the gates that keep all of it in development: DEV_MOCK_BANK_URL only with
 * LP_NODE_DEV=1, never beside a real bank module, and local witnesses reading a client only when it came
 * from that URL.
 */

let closers: (() => Promise<void>)[] = [];
afterEach(async () => {
  for (const c of closers.splice(0)) await c();
});

async function served() {
  const bank = new MockBank({ now: () => 1_030n });
  const s = serveDevMockBank({ bank });
  closers.push(s.close);
  const url = `http://127.0.0.1:${await s.listen(0)}`;
  return { bank, url, client: await MockBankClient.connect(url) };
}

const SELLER = '+5511987654321';
const ORDER: Hex = `0x${'0a'.repeat(32)}`;
const SALT: Hex = `0x${'5a'.repeat(32)}`;
const PAYER_REF: Hex = `0x${'77'.repeat(32)}`;

describe('MockBankClient: the MockBank the dev API pays into, from the LP node\'s process', () => {
  it('reads the credits the owner records, with bigints and absent answers intact', async () => {
    const { bank, client } = await served();
    const credit = bank.receivePix({ amountCents: 12_345n, creditedKey: LP_PIX_KEY, txid: 'MOVVA0000000000000000000001' });
    expect(await client.listIncoming({ since: 0n })).toEqual([credit]);
    expect(await client.listIncoming({ since: 2_000n })).toEqual([]);
    expect(await client.getIncoming(credit.bankTxId)).toEqual(credit);
    expect(await client.getIncoming('E00000000202609141200NOSUCHPIX1')).toBeUndefined();
    expect(await client.balanceCents()).toBe(await bank.balanceCents());
    expect(client.boletoNeedsDueDate).toBe(false);
  });

  it('moves money once per idempotency key, and a lost response is still a thrown send whose money moved', async () => {
    const { bank, client } = await served();
    const sent = await client.sendPix({ idempotencyKey: 'sale-1', pixKey: SELLER, amountCents: 1_980n });
    expect(sent).toMatchObject({ idempotencyKey: 'sale-1', status: 'SETTLED', amountCents: 1_980n, paidAt: 1_030n });
    expect(await client.sendPix({ idempotencyKey: 'sale-1', pixKey: SELLER, amountCents: 1_980n })).toEqual(sent);
    expect(bank.moneyMovedFor('sale-1')).toBe(1);

    bank.loseNextResponse();
    await expect(client.sendPix({ idempotencyKey: 'sale-2', pixKey: SELLER, amountCents: 500n })).rejects.toThrow(/^socket hang up$/);
    expect(await client.getOutgoing('sale-2')).toMatchObject({ status: 'SETTLED', amountCents: 500n });
    expect(await client.getOutgoing('never-sent')).toBeUndefined();
    expect(bank.moneyMovedFor('sale-2')).toBe(1);
    // What the dev API's /state reads: the owner's own record of what the LP's bank sent.
    expect(bank.outgoing.map((o) => [o.kind, o.destination, o.amountCents])).toEqual([['PIX', SELLER, 1_980n], ['PIX', SELLER, 500n]]);
  });

  it('registers boletos and API Pix charges on the owner\'s bank, and relays its refusals as they are', async () => {
    const { bank, client } = await served();
    const { line, bankRef } = await client.registerBoleto({ idempotencyKey: 'order-b', amountCents: 10_000n, dueDate: '2030-01-10', reference: 'order-b' });
    const paid = bank.payRegisteredBoleto(line);
    expect(await client.receipt('onramp', 'BOLETO', paid.bankTxId)).toEqual(await bank.receipt('onramp', 'BOLETO', paid.bankTxId));
    await client.cancelBoleto(bankRef);
    expect(bank.boletos.get(bankRef)?.status).toBe('PAID');

    const txid = 'MOVVA00000000000000000000002';
    const charge = await client.createCharge({ txid, amountCents: 700n, pixKey: LP_PIX_KEY, expiresInSeconds: 600 });
    expect(charge).toMatchObject({ status: 'ATIVA', amountCents: 700n, expiresAt: 1_630n });
    expect(await client.getCharge(txid)).toEqual(charge);
    expect(await client.cancelCharge(txid)).toBe('REMOVIDA_PELO_USUARIO_RECEBEDOR');
    await expect(client.createCharge({ txid, amountCents: 701n, pixKey: LP_PIX_KEY, expiresInSeconds: 600 })).rejects.toThrow(/^txid already used by another charge$/);

    const credit = bank.receivePix({ amountCents: 900n, creditedKey: LP_PIX_KEY });
    expect(await client.refundIncoming({ idempotencyKey: 'refund-1', bankTxId: credit.bankTxId, amountCents: 900n, reason: 'no order' })).toMatchObject({ status: 'SETTLED' });
    expect(await client.refundIncoming({ idempotencyKey: 'refund-2', bankTxId: credit.bankTxId, amountCents: 1n, reason: 'again' }))
      .toMatchObject({ status: 'FAILED', failureReason: 'refund exceeds the credit' });
  });

  it('gives local witnesses the same records as the MockBank itself: the same signed claim, and the same refusal', async () => {
    const { bank, client } = await served();
    const credit = bank.receivePix({ amountCents: 10_000n, creditedKey: LP_PIX_KEY });
    const session = (receipts: ReceiptSource) => new LocalWitnessSession({ witnessKeys: WITNESS_KEYS, receipts, templates: RECEIPT_TEMPLATES, now: () => 1_031n });
    const req: ZkTlsSessionRequest = {
      leg: 'onramp', rail: Rail.PIX, receipt: 'pix-received', binding: ORDER, bankTxId: credit.bankTxId, salt: SALT, payerRef: PAYER_REF,
    };
    const remote = await session(client).prove(req);
    expect(remote).toEqual(await session(bank).prove(req));
    expect(proofPayment(remote)).toMatchObject({ orderId: ORDER, amountBrlCents: 10_000n, paidAt: 1_030n, rail: Rail.PIX });

    const sent = await client.sendPix({ idempotencyKey: 'sale-1', pixKey: SELLER, amountCents: 1_980n });
    expect(await client.receipt('offramp', 'PIX', sent.bankTxId!)).toEqual({ bankTxId: sent.bankTxId, amountCents: 1_980n, paidAt: 1_030n, pixKey: SELLER });
    await expect(session(client).prove({ ...req, bankTxId: 'E00000000202609141200NOSUCHPIX1' })).rejects.toThrow(/^the bank shows no settled PIX credit under that id$/);
  });
});

describe('MockBankClient.connect: unreachable or malformed URLs', () => {
  it('refuses to connect where nothing answers, or to a URL that is not http(s)', async () => {
    await expect(MockBankClient.connect('http://127.0.0.1:1', { timeoutMs: 2_000 })).rejects.toThrow(/did not answer \/bank/);
    expect(() => devMockBankBase('ftp://127.0.0.1:1')).toThrow(/http\(s\) base URL/);
    expect(devMockBankBase('http://127.0.0.1:8123/')).toBe('http://127.0.0.1:8123');
  });
});

describe('serveDevMockBank: the adapter side only', () => {
  it('never serves the outside world\'s methods or fault injection, and takes only POST { args }', async () => {
    const { bank, url } = await served();
    const post = (path: string, body: unknown = { args: [] }) =>
      fetch(`${url}${path}`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: devWireStringify(body) });
    for (const m of ['receivePix', 'payRegisteredBoleto', 'payCharge', 'failNextSend', 'holdNextSend', 'loseNextResponse', 'settlePending', 'send', 'constructor', 'moneyMovedFor']) {
      expect((await post(`/bank/${m}`, { args: [{ amountCents: 1_000n, creditedKey: LP_PIX_KEY }] })).status, m).toBe(404);
    }
    expect((await post('/acquirer/createCheckout')).status, 'the card acquirer is gone').toBe(404);
    expect(bank.incoming).toHaveLength(0);
    expect((await fetch(`${url}/bank/sendPix`)).status).toBe(405);
    expect((await post('/bank')).status).toBe(405);
    expect((await post('/bank/sendPix', { nope: 1 })).status).toBe(400);
    expect((await fetch(`${url}/bank/listIncoming`, { method: 'POST', body: 'not json' })).status).toBe(400);
    expect((await fetch(`${url}/elsewhere`)).status).toBe(404);
    expect((await fetch(`${url}/bank/sendPix/extra`, { method: 'POST' })).status).toBe(404);
  });

  it('keeps bigints across the wire, and nothing else turns into one', () => {
    const value = { a: 1n, b: [2n, { c: -3n }], d: 'x', e: { $bigint: '12a' }, f: { $bigint: '4', g: 1 } };
    expect(devWireParse(devWireStringify(value))).toEqual(value);
  });
});

describe('DEV_MOCK_BANK_URL: development only', () => {
  const strategy = {
    registry: '0x00000000000000000000000000000000000000e6', fromBlock: '1', lpPayerId: '12345678000195',
    onramp: {
      escrow: '0x00000000000000000000000000000000000000e5', pixKey: '12.345.678/0001-95', receiver: { name: 'LP Liquidez Ltda', city: 'Sao Paulo' },
      assets: [{
        asset: '0x0000000000000000000000000000000000000000', symbol: 'ETH', liquidity: '1000', minOrder: '1', maxOrder: '10',
        verifier: '0x00000000000000000000000000000000000000a7', rails: ['PIX'], spreadBps: 80, price: { source: 'oracle' },
      }],
    },
  };
  const env: Env = {
    RPC_URL: 'http://127.0.0.1:8982', LP_KEY: `0x${'33'.repeat(32)}`, PAYER_REF_SECRET: `0x${'44'.repeat(32)}`,
    STATE_FILE: '/app/data/lp-node.jsonl', LP_CONFIG: '/app/config/lp.json',
  };
  const URL_ = 'http://127.0.0.1:43210';
  const read = (p: string) => {
    if (p === '/app/config/lp.json') return JSON.stringify(strategy);
    throw new Error('ENOENT');
  };
  const problems = (e: Env): string[] => {
    try {
      lpNodeConfigFromEnv(e, read);
      return [];
    } catch (x) {
      if (x instanceof ConfigError) return x.problems;
      throw x;
    }
  };

  it('with LP_NODE_DEV=1 it stands in for BANK_MODULE', () => {
    const cfg = lpNodeConfigFromEnv({ ...env, LP_NODE_DEV: '1', DEV_MOCK_BANK_URL: URL_ }, read);
    expect(cfg).toMatchObject({ dev: true, devMockBankUrl: URL_, bankModule: undefined });
  });

  it('is refused, not ignored, without LP_NODE_DEV=1 - even beside a real bank', () => {
    for (const dev of [{}, { LP_NODE_DEV: '0' }, { LP_NODE_DEV: 'true' }]) {
      const p = problems({ ...env, ...dev, DEV_MOCK_BANK_URL: URL_ }).join('\n');
      expect(p).toMatch(/DEV_MOCK_BANK_URL is for LP_NODE_DEV=1 only/);
      expect(p).toMatch(/BANK_MODULE is required/);
    }
    const production = { ...env, BANK_MODULE: '/plugins/bank.js' };
    expect(problems(production)).toEqual([]);
    expect(lpNodeConfigFromEnv(production, read).devMockBankUrl).toBeUndefined();
    expect(problems({ ...production, DEV_MOCK_BANK_URL: URL_ })).toEqual([expect.stringMatching(/^DEV_MOCK_BANK_URL is for LP_NODE_DEV=1 only/)]);
  });

  it('is refused beside BANK_MODULE, and when it is not an http(s) URL', () => {
    const dev = { ...env, LP_NODE_DEV: '1', DEV_MOCK_BANK_URL: URL_ };
    expect(problems({ ...dev, BANK_MODULE: '/plugins/bank.js' }).join('\n')).toMatch(/set BANK_MODULE or DEV_MOCK_BANK_URL, not both/);
    expect(problems({ ...dev, DEV_MOCK_BANK_URL: 'file:///tmp/bank' }).join('\n')).toMatch(/DEV_MOCK_BANK_URL must be an http\(s\) base URL/);
  });

  it('lets local witnesses read MockBank\'s records in memory or from the dev URL, never from a BANK_MODULE', async () => {
    const { client, url } = await served();
    const memory = new MockBank();
    const real: BankAdapter = {
      listIncoming: async () => [], sendPix: async (r) => ({ idempotencyKey: r.idempotencyKey, status: 'FAILED' }),
      payBoleto: async (r) => ({ idempotencyKey: r.idempotencyKey, status: 'FAILED' }), getOutgoing: async () => undefined,
    };
    expect(localWitnessReceipts({}, memory)).toBe(memory);
    expect(localWitnessReceipts({ devMockBankUrl: url }, client)).toBe(client);
    // A BANK_MODULE handing back a client is still a BANK_MODULE: config.ts refuses the pair, and this refuses it again.
    expect(localWitnessReceipts({ bankModule: '/plugins/bank.js' }, client)).toBeUndefined();
    expect(localWitnessReceipts({ bankModule: '/plugins/bank.js', devMockBankUrl: url }, client)).toBeUndefined();
    expect(localWitnessReceipts({}, client)).toBeUndefined();
    expect(localWitnessReceipts({ devMockBankUrl: url }, real)).toBeUndefined();
  });
});
