import { describe, expect, it } from 'vitest';
import type { Hex } from 'viem';
import { pixKeyCommitment } from '@mova/ramp';
import { parseDynamicPixBrCode } from '@mova/wallet';
import { OrderState } from '../src/abi.js';
import { NATIVE } from '../src/chain.js';
import { pixCobTxidForOrder, pixTxidForOrder } from '../src/onramp.js';
import { harness, LP_PIX_KEY, type Harness } from './harness.js';
import { ONRAMP } from './fake-chain.js';

/**
 * `onramp.pixCharge: "cob"`: an API Pix immediate charge per PIX order (PUT /cob/{txid}), for PSPs whose API Pix lists
 * only charge-paid Pix. MockBank plays the PSP.
 */

function cobHarness(o: Parameters<typeof harness>[0] = {}): Harness {
  return harness({ offramp: false, ...o, tweak: (opts) => { opts.onramp!.pixCharge = 'cob'; o.tweak?.(opts); } });
}

async function offerFor(h: Harness, asset: string): Promise<Hex> {
  await h.tick();
  const s = h.node.offers!.status.get(asset.toLowerCase());
  if (!s?.activeOfferId) throw new Error(`no offer for ${asset}: ${s?.reason}`);
  return s.activeOfferId;
}

async function settle(h: Harness, blocks = 3): Promise<void> {
  h.chain.mine(blocks);
  await h.tick();
}

const txidOf = (h: Harness, orderId: Hex) => pixCobTxidForOrder(h.chain.chainId, ONRAMP, orderId);

describe('on-ramp, PIX by charge (cob)', () => {
  it('creates one charge for a confirmed lock, serves it, and releases on the credit that pays it', async () => {
    const h = cobHarness();
    const offerId = await offerFor(h, NATIVE);
    const orderId = h.chain.lockOrder(offerId, 10n ** 17n);
    await h.tick();
    expect(h.bank.charges.size).toBe(0); // one block deep: nothing a bank app could pay yet
    await expect(h.node.onramp!.instructions(orderId)).rejects.toMatchObject({ status: 409 });

    await settle(h, 3);
    const ord = await h.chain.order(orderId);
    const txid = txidOf(h, orderId);
    expect(txid).toMatch(/^[a-zA-Z0-9]{26,35}$/);
    const c = h.bank.charges.get(txid)!;
    expect(c).toMatchObject({ status: 'ATIVA', amountCents: ord.brlCents, amountFixed: true, pixKey: LP_PIX_KEY });
    expect(c.expiresAt).toBeLessThanOrEqual(ord.payBy - 300n);
    expect(h.bank.chargeCalls.create).toBe(1);

    const { body } = await h.node.onramp!.instructions(orderId);
    if (body.rail !== 'PIX') throw new Error('expected PIX');
    expect(body).toMatchObject({
      charge: 'cob', txid, location: c.location, pixCopiaECola: c.pixCopiaECola, expiresAt: Number(c.expiresAt), amountCents: ord.brlCents.toString(),
    });
    expect(parseDynamicPixBrCode(body.pixCopiaECola).location).toBe(c.location);
    // Still the key and salt that open the offer's commitment: what the wallet checks the signed charge against.
    expect(pixKeyCommitment(body.pixKey, body.salt)).toBe((await h.chain.offer(offerId)).pixKeyHash);

    await settle(h, 2);
    expect(h.bank.chargeCalls.create).toBe(1);

    h.bank.payCharge(txid);
    await h.tick();
    expect((await h.chain.order(orderId)).state).toBe(OrderState.RELEASED);
    await settle(h, 3);
    expect(h.node.store.getOrder(orderId)?.done).toBe(OrderState.RELEASED);
    expect(h.bank.charges.get(txid)!.status).toBe('CONCLUIDA');
  });

  it('matches a credit to a charge order by the charge\'s txid only: never by amount, never by the static code\'s txid', async () => {
    const h = cobHarness();
    const offerId = await offerFor(h, NATIVE);
    const orderId = h.chain.lockOrder(offerId, 10n ** 17n);
    await settle(h, 3);
    const ord = await h.chain.order(orderId);
    h.bank.receivePix({ amountCents: ord.brlCents, creditedKey: LP_PIX_KEY }); // the exact amount, no txid
    h.bank.receivePix({ amountCents: ord.brlCents, creditedKey: LP_PIX_KEY, txid: pixTxidForOrder(orderId) }); // the static code's txid
    h.chain.warp(400n);
    h.chain.mine();
    await h.tick();
    expect(h.node.store.getOrder(orderId)?.payment).toBeUndefined();
    expect(h.chain.writes).not.toContain('releaseWithProof');
    expect(h.node.metrics.get('mova_lp_unreconciled_credits')).toBe(2);

    h.bank.payCharge(txidOf(h, orderId));
    await h.tick();
    expect(h.node.store.getOrder(orderId)?.payment?.txid).toBe(txidOf(h, orderId));
    expect((await h.chain.order(orderId)).state).toBe(OrderState.RELEASED);
  });

  it('a restart between the PSP creating the charge and the journal recording it finds that charge: never a second', async () => {
    const h = cobHarness();
    const offerId = await offerFor(h, NATIVE);
    const orderId = h.chain.lockOrder(offerId, 10n ** 17n);
    await h.tick();
    h.bank.loseNextChargeResponse();
    await settle(h, 3);
    expect(h.bank.charges.size).toBe(1); // the PSP made it
    expect(h.node.store.getOrder(orderId)?.cob).toEqual({ txid: txidOf(h, orderId) }); // the journal holds the intent only
    await expect(h.node.onramp!.instructions(orderId)).rejects.toMatchObject({ status: 409 });

    h.restart();
    await settle(h, 1);
    expect(h.bank.chargeCalls.create).toBe(1);
    expect(h.bank.chargeCalls.get).toBeGreaterThanOrEqual(1);
    expect(h.bank.charges.size).toBe(1);
    const { body } = await h.node.onramp!.instructions(orderId);
    expect(body).toMatchObject({ charge: 'cob', txid: txidOf(h, orderId), location: h.bank.charges.get(txidOf(h, orderId))!.location });
  });

  it('a PUT that never reached the PSP is asked about, then retried under the same txid', async () => {
    const h = cobHarness();
    const real = h.bank.createCharge.bind(h.bank);
    let attempts = 0;
    h.bank.createCharge = async (r) => {
      if (attempts++ === 0) throw new Error('ECONNRESET');
      return real(r);
    };
    const offerId = await offerFor(h, NATIVE);
    const orderId = h.chain.lockOrder(offerId, 10n ** 17n);
    await settle(h, 3);
    expect(h.bank.charges.size).toBe(0);
    await settle(h, 1);
    expect(h.bank.chargeCalls.get).toBe(1);
    expect([...h.bank.charges.keys()]).toEqual([txidOf(h, orderId)]);
  });

  it('removes the unpaid charge of a cancelled order once that is confirmed, and refunds a credit that lands anyway', async () => {
    const h = cobHarness();
    const offerId = await offerFor(h, NATIVE);
    const orderId = h.chain.lockOrder(offerId, 10n ** 17n);
    await settle(h, 3);
    const txid = txidOf(h, orderId);
    const ord = await h.chain.order(orderId);

    h.chain.cancelOrder(orderId);
    await h.tick();
    expect(h.bank.charges.get(txid)!.status).toBe('ATIVA'); // not N blocks deep yet
    await settle(h, 3);
    expect(h.bank.charges.get(txid)!.status).toBe('REMOVIDA_PELO_USUARIO_RECEBEDOR');
    expect(h.node.store.getOrder(orderId)?.cob?.closed).toBe('REMOVIDA_PELO_USUARIO_RECEBEDOR');

    // A payer whose app read the code just before the removal: the credit still lands, under the charge's txid.
    const late = h.bank.receivePix({ amountCents: ord.brlCents, creditedKey: LP_PIX_KEY, txid });
    await settle(h, 3);
    const refunds = h.bank.outgoing.filter((x) => x.kind === 'REFUND');
    expect(refunds).toHaveLength(1);
    expect(refunds[0]).toMatchObject({ destination: late.bankTxId, amountCents: ord.brlCents });
    await settle(h, 2);
    expect(h.bank.outgoing.filter((x) => x.kind === 'REFUND')).toHaveLength(1);
    expect(h.node.store.getOrder(orderId)?.done).toBe(OrderState.CANCELLED);
    expect(h.bank.chargeCalls.cancel).toBe(1);
  });

  it('removes the charge of an order that expired unpaid', async () => {
    const h = cobHarness();
    const offerId = await offerFor(h, NATIVE);
    const orderId = h.chain.lockOrder(offerId, 10n ** 17n);
    await settle(h, 3);
    h.chain.warp(31n * 60n);
    h.chain.mine();
    await h.tick(); // reclaims
    expect((await h.chain.order(orderId)).state).toBe(OrderState.CANCELLED);
    await settle(h, 3);
    expect(h.bank.charges.get(txidOf(h, orderId))!.status).toBe('REMOVIDA_PELO_USUARIO_RECEBEDOR');
  });

  it('removes a charge the PSP made for another amount, and holds the order', async () => {
    const h = cobHarness();
    const real = h.bank.createCharge.bind(h.bank);
    h.bank.createCharge = (r) => real({ ...r, amountCents: r.amountCents + 1n });
    const offerId = await offerFor(h, NATIVE);
    const orderId = h.chain.lockOrder(offerId, 10n ** 17n);
    await settle(h, 3);
    expect(h.bank.charges.get(txidOf(h, orderId))!.status).toBe('REMOVIDA_PELO_USUARIO_RECEBEDOR');
    expect(h.node.store.getOrder(orderId)?.hold).toMatch(/another amount/);
    await expect(h.node.onramp!.instructions(orderId)).rejects.toMatchObject({ status: 409 });
  });

  it('holds a PIX order when the bank adapter cannot create charges', async () => {
    const h = cobHarness();
    (h.bank as { createCharge?: unknown }).createCharge = undefined;
    const offerId = await offerFor(h, NATIVE);
    const orderId = h.chain.lockOrder(offerId, 10n ** 17n);
    await settle(h, 3);
    expect(h.node.store.getOrder(orderId)?.hold).toMatch(/cannot create PIX charges/);
  });

  it('boleto orders are untouched by cob mode, and static mode (the default) creates no charge', async () => {
    const h = cobHarness();
    const offerId = await offerFor(h, NATIVE);
    const boleto = h.chain.lockOrderByBoleto(offerId, 10n ** 17n);
    await settle(h, 3);
    expect(h.bank.charges.size).toBe(0);
    expect(h.bank.boletos.size).toBe(1);
    expect(h.node.store.getOrder(boleto)?.cob).toBeUndefined();

    const s = harness({ offramp: false });
    const staticOffer = await offerFor(s, NATIVE);
    const orderId = s.chain.lockOrder(staticOffer, 10n ** 17n);
    await settle(s, 3);
    expect(s.bank.charges.size).toBe(0);
    const { body } = await s.node.onramp!.instructions(orderId);
    expect(body).not.toHaveProperty('charge');
    expect(body).not.toHaveProperty('location');
  });
});
