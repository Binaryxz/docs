import { describe, expect, it } from 'vitest';
import { mkdtempSync, readFileSync, statSync, writeFileSync, appendFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import type { Address, Hex } from 'viem';
import fc from 'fast-check';
import { Rail, newPixSalt, pixKeyCommitment, railMask } from '@mova/ramp';
import { SaleState, OrderState } from '../src/abi.js';
import type { BankAdapter } from '../src/bank.js';
import { NATIVE } from '../src/chain.js';
import { lpNodeConfigFromEnv, ConfigError } from '../src/config.js';
import { redactingLogger } from '../src/context.js';
import { JsonlJournal, MemoryJournal } from '../src/journal.js';
import { evaluateSale, quoteOffer, type OfferPricing } from '../src/pricing.js';
import { serveLpNode } from '../src/server.js';
import { idempotencyKey, type LpRecord } from '../src/store.js';
import { OFFRAMP } from './fake-chain.js';
import { harness, LP_PIX_KEY, type Harness } from './harness.js';

const SELLER_KEY = '+5511987654321';

async function claimedSale(h: Harness): Promise<{ saleId: Hex; key: string }> {
  const salt = newPixSalt();
  const saleId = h.chain.openSale({
    amount: 10n ** 17n, brlCents: 198_000n, payeeKeyHash: pixKeyCommitment(SELLER_KEY, salt), railMask: railMask(Rail.PIX),
  });
  await h.node.offramp!.submitPayee(saleId, { pixKey: SELLER_KEY, salt });
  await h.tick();
  expect((await h.chain.sale(saleId)).state).toBe(SaleState.CLAIMED);
  return { saleId, key: idempotencyKey('sale-pay', h.chain.chainId, OFFRAMP, saleId) };
}

describe('safety: BRL is never paid before the claim is on-chain with the configured confirmations', () => {
  it('waits for exactly N confirmations', async () => {
    const h = harness({ onramp: false, confirmations: 6 });
    const { saleId } = await claimedSale(h);
    for (let depth = 1; depth < 6; depth++) {
      await h.tick();
      expect(h.bank.sendCalls, `paid at ${depth} confirmation(s)`).toBe(0);
      h.chain.mine();
    }
    await h.tick(); // the claim is now 6 blocks deep
    expect(h.bank.sendCalls).toBe(1);
    expect((await h.chain.sale(saleId)).state).toBe(SaleState.SETTLED);
  });

  it('pays nothing for a claim that a reorg removes before it confirms', async () => {
    const h = harness({ onramp: false, confirmations: 3 });
    const { saleId } = await claimedSale(h);
    h.chain.mine(1);
    await h.tick();
    expect(h.bank.sendCalls).toBe(0);
    h.chain.reorg(2); // the claim block and the one after it are gone
    expect((await h.chain.sale(saleId)).state).toBe(SaleState.OPEN);
    await h.tick(); // sees the sale open again and re-claims it
    expect(h.bank.sendCalls).toBe(0);
    h.chain.mine(2);
    await h.tick();
    expect(h.bank.sendCalls).toBe(1);
    expect(h.bank.outgoing).toHaveLength(1);
    expect((await h.chain.sale(saleId)).state).toBe(SaleState.SETTLED);
  });
});

describe('safety: an idempotency key is persisted before the bank is called, so a crash cannot double-pay', () => {
  it('writes the intent to the journal before the transfer, with the key the bank then sees', async () => {
    const h = harness({ onramp: false, confirmations: 1 });
    const { saleId, key } = await claimedSale(h);
    let journalAtSend: LpRecord[] = [];
    const bank = h.bank;
    const spy = new Proxy(bank, {
      get(target, prop, recv) {
        if (prop === 'sendPix') {
          return async (req: Parameters<BankAdapter['sendPix']>[0]) => {
            journalAtSend = h.journal.load();
            expect(req.idempotencyKey).toBe(key);
            return target.sendPix(req);
          };
        }
        return Reflect.get(target, prop, recv);
      },
    });
    (h.node.ctx as { bank: BankAdapter }).bank = spy;
    await h.tick();
    const intent = journalAtSend.find((r) => r.t === 'sale.pay.intent');
    expect(intent).toMatchObject({ saleId, idempotencyKey: key });
    expect(h.bank.moneyMovedFor(key)).toBe(1);
  });

  it('a crash after the bank moved money but before the result was recorded: restart settles, pays once', async () => {
    const h = harness({ onramp: false, confirmations: 1 });
    const { saleId, key } = await claimedSale(h);
    h.bank.loseNextResponse();
    await h.tick(); // the transfer happens, the response is lost: the handler throws
    expect(h.bank.moneyMovedFor(key)).toBe(1);
    expect(h.node.store.getSale(saleId)?.pay?.result).toBeUndefined();

    h.restart(); // a new process over the same journal
    await h.tick();
    expect(h.bank.moneyMovedFor(key)).toBe(1);
    expect(h.bank.outgoing).toHaveLength(1);
    expect((await h.chain.sale(saleId)).state).toBe(SaleState.SETTLED);
  });

  it('a crash before the request reached the bank: restart repeats it under the same key, once', async () => {
    const h = harness({ onramp: false, confirmations: 1 });
    const { saleId, key } = await claimedSale(h);
    const real = h.node.ctx.bank;
    (h.node.ctx as { bank: BankAdapter }).bank = { ...real, listIncoming: real.listIncoming.bind(real), getOutgoing: real.getOutgoing.bind(real),
      payBoleto: real.payBoleto.bind(real), sendPix: async () => { throw new Error('ECONNREFUSED'); } };
    await h.tick();
    expect(h.node.store.getSale(saleId)?.pay?.idempotencyKey).toBe(key);
    expect(h.bank.sendCalls).toBe(0);

    h.restart();
    await h.tick();
    await h.tick();
    expect(h.bank.moneyMovedFor(key)).toBe(1);
    expect((await h.chain.sale(saleId)).state).toBe(SaleState.SETTLED);
  });

  it('even with the journal lost entirely, the derived key makes the bank refuse a second transfer', async () => {
    const h = harness({ onramp: false, confirmations: 1 });
    const { saleId, key } = await claimedSale(h);
    h.bank.loseNextResponse();
    await h.tick();
    const payee = h.node.store.getSale(saleId)!.payee!;
    h.journal.lines.splice(0, h.journal.lines.length); // disk gone
    h.restart();
    await h.tick();
    await h.tick();
    expect(h.bank.moneyMovedFor(key)).toBe(1);
    expect(h.bank.outgoing).toHaveLength(1);
    // It adopted the payment the bank reported, so it neither paid again nor gave the claim back...
    expect((await h.chain.sale(saleId)).state).toBe(SaleState.CLAIMED);
    expect(h.chain.writes).not.toContain('abandonClaim');
    // ...and once the seller discloses the payee again, it proves and collects.
    if (payee.kind !== 'pix') throw new Error('expected a PIX payee');
    await h.node.offramp!.submitPayee(saleId, { pixKey: payee.pixKey, salt: payee.salt });
    await h.tick();
    expect((await h.chain.sale(saleId)).state).toBe(SaleState.SETTLED);
    expect(h.bank.outgoing).toHaveLength(1);
  });

  it('a refund is idempotent across a crash too', async () => {
    const h = harness({ offramp: false, confirmations: 1 });
    await h.tick();
    const offerId = h.node.offers!.status.get(NATIVE)!.activeOfferId!;
    const orderId = h.chain.lockOrder(offerId, 10n ** 17n);
    const ord = await h.chain.order(orderId);
    const saved = h.witnesses.splice(0, 2);
    h.bank.receivePix({ amountCents: ord.brlCents, creditedKey: LP_PIX_KEY, txid: orderId.slice(2, 27) });
    await h.tick();
    h.chain.cancelOrder(orderId);
    h.bank.loseNextResponse();
    await h.tick();
    expect(h.bank.outgoing.filter((o) => o.kind === 'REFUND')).toHaveLength(1); // moved, response lost
    h.witnesses.push(...saved);
    h.restart();
    await h.tick();
    await h.tick();
    expect(h.bank.outgoing.filter((o) => o.kind === 'REFUND')).toHaveLength(1);
    expect(h.node.store.getOrder(orderId)?.done).toBe(OrderState.CANCELLED);
  });
});

describe('safety: local state survives a crash (append-only JSONL, torn tail recovered)', () => {
  it('drops a torn final line, cuts the file back, and keeps appending cleanly', () => {
    const dir = mkdtempSync(join(tmpdir(), 'lp-journal-'));
    const path = join(dir, 'state.jsonl');
    const j = new JsonlJournal<{ n: bigint; s: string }>(path);
    j.load();
    j.append({ n: 1n, s: 'one' });
    j.append({ n: 2n ** 200n, s: '{"$n":"not a bigint"}' });
    j.close();
    appendFileSync(path, '{"n":{"$n":"3"},"s":"thr'); // power cut mid-append

    const k = new JsonlJournal<{ n: bigint; s: string }>(path);
    expect(k.load()).toEqual([{ n: 1n, s: 'one' }, { n: 2n ** 200n, s: '{"$n":"not a bigint"}' }]);
    k.append({ n: 4n, s: 'four' });
    k.close();
    expect(new JsonlJournal(path).load()).toEqual([
      { n: 1n, s: 'one' }, { n: 2n ** 200n, s: '{"$n":"not a bigint"}' }, { n: 4n, s: 'four' },
    ]);
    expect(statSync(path).mode & 0o777).toBe(0o600);
  });

  it('refuses to start over a corrupt line that is not the last', () => {
    const dir = mkdtempSync(join(tmpdir(), 'lp-journal-'));
    const path = join(dir, 'state.jsonl');
    writeFileSync(path, '{"a":1}\nnot json\n{"a":2}\n');
    expect(() => new JsonlJournal(path).load()).toThrow(/corrupt at byte 8/);
  });

  it('a node restarted on the file journal carries on where it stopped', async () => {
    const dir = mkdtempSync(join(tmpdir(), 'lp-journal-'));
    const path = join(dir, 'state.jsonl');
    const h = harness({ onramp: false, confirmations: 1, tweak: (o) => { o.journal = new JsonlJournal<LpRecord>(path); } });
    const { saleId, key } = await claimedSale(h);
    h.bank.loseNextResponse();
    await h.tick();
    await h.node.stop();
    expect(readFileSync(path, 'utf8')).toContain(key);
    h.restart();
    await h.tick();
    expect(h.bank.moneyMovedFor(key)).toBe(1);
    expect((await h.chain.sale(saleId)).state).toBe(SaleState.SETTLED);
  });
});

describe('safety: reorgs', () => {
  it('rewinds the event cursor when its block is replaced, and drops an order the reorg erased', async () => {
    const h = harness({ offramp: false, confirmations: 2 });
    await h.tick();
    const offerId = h.node.offers!.status.get(NATIVE)!.activeOfferId!;
    const orderId = h.chain.lockOrder(offerId, 10n ** 17n);
    await h.tick();
    expect(h.node.store.getOrder(orderId)).toBeDefined();

    h.chain.reorg(1);
    h.chain.mine(2);
    await h.tick();
    expect(h.node.metrics.get('mova_lp_reorgs_total')).toBe(1);
    h.chain.mine(13);
    await h.tick();
    expect(h.node.store.getOrder(orderId)?.done).toBe(OrderState.NONE);
  });

  it('an order locked after a reorg in a replacement block is found by the rescan', async () => {
    const h = harness({ offramp: false, confirmations: 2 });
    await h.tick();
    const offerId = h.node.offers!.status.get(NATIVE)!.activeOfferId!;
    h.chain.mine(3);
    await h.tick();
    h.chain.reorg(2);
    const orderId = h.chain.lockOrder(offerId, 10n ** 17n); // lands at a height the cursor already passed
    h.chain.mine(1);
    await h.tick();
    expect(h.node.store.getOrder(orderId)).toBeDefined();
  });
});

describe('safety: exposure stays bounded when the reference price is wrong', () => {
  const cfg: OfferPricing = {
    spreadBps: 100, minSpreadBps: 30, maxOracleDeviationBps: 200, bandMarginBps: 100, refreshDriftBps: 50,
    maxReferenceAgeSeconds: 120, oracleStaleMarginSeconds: 300,
  };

  it('never asks below the oracle plus the minimum spread, and never outside the band, whatever the reference says', () => {
    fc.assert(fc.property(
      fc.bigInt({ min: 1n, max: 10n ** 12n }), fc.integer({ min: 1, max: 100_000 }), fc.integer({ min: 1, max: 2_000 }),
      (oracle, refRatioBps, bandBps) => {
        const reference = (oracle * BigInt(refRatioBps)) / 10_000n + 1n;
        const q = quoteOffer({
          reference: { price: reference, updatedAt: 1000n }, oracle: { price: oracle, updatedAt: 1000n },
          bandBps: BigInt(bandBps), chainNow: 1000n, wallNow: 1000n, cfg,
        });
        if (!q.ok) return;
        expect(q.price * 10_000n).toBeGreaterThanOrEqual(oracle * (10_000n + 30n));
        const diff = q.price > oracle ? q.price - oracle : oracle - q.price;
        expect(diff * 10_000n).toBeLessThanOrEqual(oracle * BigInt(bandBps));
      },
    ), { numRuns: 2_000 });
  });

  it('never values a sale above the oracle less the margin, whatever the reference says', () => {
    fc.assert(fc.property(
      fc.bigInt({ min: 100n, max: 10n ** 9n }), fc.integer({ min: 5_000, max: 20_000 }), fc.bigInt({ min: 1n, max: 10n ** 12n }),
      (oracle, refRatioBps, brlCents) => {
        const v = evaluateSale({
          brlCents, amount: 10n ** 6n, decimals: 6, reference: { price: (oracle * BigInt(refRatioBps)) / 10_000n, updatedAt: 1000n },
          oracle: { price: oracle, updatedAt: 1000n }, chainNow: 1000n, wallNow: 1000n,
          cfg: { minMarginBps: 50, maxOracleDeviationBps: 10_000, maxReferenceAgeSeconds: 120, oracleStaleMarginSeconds: 300 },
        });
        if (v.ok) expect(v.impliedPrice * 10_000n).toBeLessThanOrEqual(oracle * 9_950n);
      },
    ), { numRuns: 2_000 });
  });

  it('pulls a live offer when the reference feed breaks away from the oracle, and posts nothing', async () => {
    const h = harness({ offramp: false });
    await h.tick();
    expect(h.node.offers!.status.get(NATIVE)?.quoting).toBe(true);
    h.feeds.eth.override = { price: 1_000_000n, updatedAt: h.chain.time() }; // the feed halves
    await h.tick();
    const s = h.node.offers!.status.get(NATIVE)!;
    expect(s).toMatchObject({ quoting: false, reason: 'reference_deviates' });
    expect(h.chain.writes.filter((w) => w === 'postOffer')).toHaveLength(2); // ETH and USDT, once each
    expect(h.node.metrics.get('mova_lp_quote_pulled_total', { asset: NATIVE, symbol: 'ETH', reason: 'reference_deviates' })).toBe(1);
  });

  it('sizes offers to the registry credit, and stops quoting when the LP has none', async () => {
    const h = harness({ offramp: false });
    h.chain.setCap(1_000_000n); // R$ 10.000,00 across everything
    await h.tick();
    expect(h.chain.exposure()).toBeLessThanOrEqual(1_000_000n);
    h.chain.setCap(0n);
    await h.tick();
    expect(h.node.offers!.status.get(NATIVE)).toMatchObject({ quoting: false, reason: 'not_eligible' });
    expect(h.chain.exposure()).toBe(0n);
  });
});

describe('safety: secrets never reach logs, /status or /metrics', () => {
  const RPC = 'https://eth-mainnet.g.alchemy.com/v2/AbCdEfGhIjKlMnOp0123456789';

  it('the logger strips RPC keys and configured secrets from every line', () => {
    const lines: string[] = [];
    const log = redactingLogger([RPC, '0xdeadbeefdeadbeefdeadbeef'], { log: (s) => lines.push(s), error: (s) => lines.push(s) });
    log.error(`HTTP request failed. URL: ${RPC} key 0xdeadbeefdeadbeefdeadbeef`);
    expect(lines.join('\n')).not.toContain('AbCdEfGhIjKlMnOp0123456789');
    expect(lines.join('\n')).not.toContain('deadbeefdeadbeef');
  });

  it('/status and /metrics carry no PIX key, salt, payee or bank id', async () => {
    const h = harness({ confirmations: 1 });
    await h.tick();
    const { saleId } = await claimedSale(h);
    await h.tick();
    const offerId = h.node.offers!.status.get(NATIVE)!.activeOfferId!;
    const orderId = h.chain.lockOrder(offerId, 10n ** 17n);
    const credit = h.bank.receivePix({ amountCents: (await h.chain.order(orderId)).brlCents, creditedKey: LP_PIX_KEY, txid: orderId.slice(2, 27) });
    await h.tick();
    const srv = serveLpNode(h.node, { mode: 'ops' });
    const port = await srv.listen(0);
    try {
      const text = await (await fetch(`http://127.0.0.1:${port}/status`)).text()
        + await (await fetch(`http://127.0.0.1:${port}/metrics`)).text();
      const salts = [...h.node.store.offerSalts.values()].map((x) => x.salt.slice(2));
      for (const secret of [LP_PIX_KEY, SELLER_KEY, credit.bankTxId, h.bank.outgoing[0].result.bankTxId!, ...salts]) {
        expect(text).not.toContain(secret);
      }
      expect(text).toContain(orderId);
      expect(saleId).toMatch(/^0x/);
    } finally {
      await srv.close();
    }
  });
});

describe('safety: key material comes only from the environment or a file', () => {
  const base = {
    RPC_URL: 'http://127.0.0.1:8745', STATE_FILE: '/data/lp.jsonl', LP_CONFIG: '/cfg/lp.json', LP_NODE_DEV: '1',
    PAYER_REF_SECRET: `0x${'11'.repeat(32)}`,
  };
  const json = JSON.stringify({
    registry: '0x00000000000000000000000000000000000000e6', fromBlock: '1', lpPayerId: '12345678000195',
    // A key in the strategy file is not a key source: it is ignored, never read.
    key: `0x${'22'.repeat(32)}`, LP_KEY: `0x${'22'.repeat(32)}`,
    offramp: { escrow: '0x00000000000000000000000000000000000000e7', assets: [{ asset: '0x0000000000000000000000000000000000000000', symbol: 'ETH', minMarginBps: 50, maxSaleBrlCents: '100000', price: { source: 'oracle' } }] },
  });
  const files = (extra: Record<string, string> = {}) => (p: string) => {
    const all: Record<string, string> = { '/cfg/lp.json': json, ...extra };
    if (!(p in all)) throw new Error('ENOENT');
    return all[p];
  };

  it('reads the LP key from LP_KEY_FILE, and a key in the JSON strategy file is never used', () => {
    const key = `0x${'33'.repeat(32)}`;
    const cfg = lpNodeConfigFromEnv({ ...base, LP_KEY_FILE: '/run/secrets/lp' }, files({ '/run/secrets/lp': `${key}\n` }));
    expect(cfg.key).toBe(key);
    expect(cfg.secrets).toContain(key);
    expect(() => lpNodeConfigFromEnv({ ...base }, files())).toThrow(/LP_KEY_FILE \(or LP_KEY\) is required/);
  });

  it('refuses both sources at once, and never echoes a malformed key', () => {
    const bad = 'not-a-key-SECRETSECRETSECRET';
    const problems = (() => {
      try {
        lpNodeConfigFromEnv({ ...base, LP_KEY: bad }, files());
      } catch (e) {
        return (e as ConfigError).problems;
      }
      return [];
    })();
    expect(problems.join('\n')).toMatch(/LP_KEY must be/);
    expect(problems.join('\n')).not.toContain('SECRETSECRET');
    expect(() => lpNodeConfigFromEnv({ ...base, LP_KEY: `0x${'33'.repeat(32)}`, LP_KEY_FILE: '/x' }, files())).toThrow(/not both/);
  });

  it('refuses the in-memory bank outside development', () => {
    expect(() => lpNodeConfigFromEnv({ ...base, LP_NODE_DEV: '0', LP_KEY: `0x${'33'.repeat(32)}` }, files())).toThrow(/BANK_MODULE is required/);
  });
});

/** Keep the unused-import checker honest about the types used only in casts above. */
export type _Unused = Address | MemoryJournal<LpRecord>;
