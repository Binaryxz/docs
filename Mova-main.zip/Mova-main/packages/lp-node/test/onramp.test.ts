import { describe, expect, it } from 'vitest';
import type { Hex } from 'viem';
import { parseBoleto, pixKeyCommitment, verifyBoletoCommitment } from '@mova/ramp';
import { BrlWallet, parsePixBrCode, reais } from '@mova/wallet';
import { OrderState } from '../src/abi.js';
import { NATIVE } from '../src/chain.js';
import { InstructionsError, pixTxidForOrder } from '../src/onramp.js';
import { harness, LP_PIX_KEY, type Harness } from './harness.js';
import { USDT } from './fake-chain.js';

/** Tick until the node has an active offer for `asset`, and return its id. */
async function offerFor(h: Harness, asset: string): Promise<Hex> {
  await h.tick();
  const s = h.node.offers!.status.get(asset.toLowerCase());
  if (!s?.activeOfferId) throw new Error(`no offer for ${asset}: ${s?.reason}`);
  return s.activeOfferId;
}

/** Enough empty blocks for anything to be confirmed, then a tick. */
async function settle(h: Harness, blocks = 3): Promise<void> {
  h.chain.mine(blocks);
  await h.tick();
}

describe('on-ramp, PIX', () => {
  it('serves the taker a BR Code for exactly the order, and releases once the credit lands', async () => {
    const h = harness({ offramp: false });
    const offerId = await offerFor(h, NATIVE);
    const orderId = h.chain.lockOrder(offerId, 10n ** 17n);
    await h.tick();

    const ord = await h.chain.order(orderId);
    const { body } = await h.node.onramp!.instructions(orderId);
    if (body.rail !== 'PIX') throw new Error('expected PIX');
    expect(body.amountCents).toBe(ord.brlCents.toString());
    // The key and salt open the offer's commitment, which is the taker's check before paying.
    const offer = await h.chain.offer(offerId);
    expect(pixKeyCommitment(body.pixKey, body.salt)).toBe(offer.pixKeyHash);
    const code = parsePixBrCode(body.pixCopiaECola);
    expect(code.amountCents).toBe(ord.brlCents);
    expect(code.txid).toBe(pixTxidForOrder(orderId));
    // The same txid the wallet puts in its own BR Code for this order.
    const wallet = new BrlWallet({} as never).paymentInstructions({
      pixKey: body.pixKey, amount: reais(ord.brlCents), orderId, receiverName: 'x', receiverCity: 'y',
    });
    expect(parsePixBrCode(wallet.pixCopiaECola).txid).toBe(code.txid);

    h.bank.receivePix({ amountCents: ord.brlCents, creditedKey: LP_PIX_KEY, txid: code.txid });
    await h.tick();
    expect((await h.chain.order(orderId)).state).toBe(OrderState.RELEASED);
    expect(h.node.metrics.get('mova_lp_onramp_released_total')).toBe(1);
  });

  it('prices a 6-decimal token by its own decimals', async () => {
    const h = harness({ offramp: false });
    const offerId = await offerFor(h, USDT);
    const offer = await h.chain.offer(offerId);
    expect(offer.decimals).toBe(6);
    // Oracle R$5.50, spread 0.8%: 554.4 -> 555 centavos per whole token, ceilinged by the band.
    expect(offer.priceBrlCentsPerEth).toBe(555n);
    const orderId = h.chain.lockOrder(offerId, 100n * 10n ** 6n);
    const ord = await h.chain.order(orderId);
    expect(ord.brlCents).toBe(55_500n);
    h.bank.receivePix({ amountCents: 55_500n, creditedKey: LP_PIX_KEY, txid: pixTxidForOrder(orderId) });
    await h.tick();
    await h.tick();
    expect((await h.chain.order(orderId)).state).toBe(OrderState.RELEASED);
  });

  it('matches a credit without a txid by exact amount only when exactly one order fits', async () => {
    const h = harness({ offramp: false });
    const offerId = await offerFor(h, NATIVE);
    const a = h.chain.lockOrder(offerId, 10n ** 17n);
    const b = h.chain.lockOrder(offerId, 10n ** 17n); // same amount: ambiguous
    const c = h.chain.lockOrder(offerId, 2n * 10n ** 17n);
    await h.tick();
    const cents = (id: Hex) => h.chain.order(id).then((o) => o.brlCents);

    h.bank.receivePix({ amountCents: await cents(a), creditedKey: LP_PIX_KEY });
    h.bank.receivePix({ amountCents: await cents(c), creditedKey: LP_PIX_KEY });
    h.chain.warp(400n);
    h.chain.mine();
    await h.tick();
    expect((await h.chain.order(c)).state).toBe(OrderState.RELEASED);
    expect((await h.chain.order(a)).state).toBe(OrderState.LOCKED);
    expect((await h.chain.order(b)).state).toBe(OrderState.LOCKED);
    expect(h.node.metrics.get('mova_lp_unreconciled_credits')).toBe(1);
  });

  it('ignores credits to a key that is not the ramp\'s', async () => {
    const h = harness({ offramp: false });
    const offerId = await offerFor(h, NATIVE);
    const orderId = h.chain.lockOrder(offerId, 10n ** 17n);
    const ord = await h.chain.order(orderId);
    h.bank.receivePix({ amountCents: ord.brlCents, creditedKey: 'outra-chave@lp.example', txid: pixTxidForOrder(orderId) });
    await h.tick();
    expect((await h.chain.order(orderId)).state).toBe(OrderState.LOCKED);
  });

  it('does not serve instructions for an order that is not awaiting payment', async () => {
    const h = harness({ offramp: false });
    const offerId = await offerFor(h, NATIVE);
    const orderId = h.chain.lockOrder(offerId, 10n ** 17n);
    h.chain.cancelOrder(orderId);
    await expect(h.node.onramp!.instructions(orderId)).rejects.toBeInstanceOf(InstructionsError);
    await expect(h.node.onramp!.instructions(`0x${'12'.repeat(32)}`)).rejects.toMatchObject({ status: 404 });
  });
});

describe('on-ramp, boleto', () => {
  it('registers a boleto only for a confirmed lock, commits to it, and releases when it is paid', async () => {
    const h = harness({ offramp: false, confirmations: 3 });
    const offerId = await offerFor(h, NATIVE);
    const orderId = h.chain.lockOrderByBoleto(offerId, 10n ** 17n);
    await h.tick();
    expect(h.bank.boletos.size).toBe(0); // one block deep: not yet
    await expect(h.node.onramp!.instructions(orderId)).rejects.toMatchObject({ status: 409 });

    await settle(h, 3);
    expect(h.bank.boletos.size).toBe(1);
    const bol = await h.chain.boleto(orderId);
    expect(bol.issuedAt).not.toBe(0n);

    const { body } = await h.node.onramp!.instructions(orderId);
    if (body.rail !== 'BOLETO') throw new Error('expected BOLETO');
    const ord = await h.chain.order(orderId);
    // The taker's check before paying: the line and salt open the on-chain commitment, for the amount.
    verifyBoletoCommitment({
      line: body.line, salt: body.salt, commitment: bol.commitment, brlCents: ord.brlCents,
      now: new Date(Number(h.chain.time()) * 1000),
    });
    expect(parseBoleto(body.line).amountCents).toBe(ord.brlCents);

    h.bank.payRegisteredBoleto(body.line);
    await h.tick();
    expect((await h.chain.order(orderId)).state).toBe(OrderState.RELEASED);
    expect(h.node.metrics.get('mova_lp_boletos_issued_total')).toBe(1);
  });

  it('cancels the boleto at the bank when its order ends unpaid', async () => {
    const h = harness({ offramp: false });
    const offerId = await offerFor(h, NATIVE);
    const orderId = h.chain.lockOrderByBoleto(offerId, 10n ** 17n);
    await settle(h, 3);
    expect([...h.bank.boletos.values()][0].status).toBe('OPEN');
    h.chain.cancelOrder(orderId);
    await settle(h, 3);
    expect([...h.bank.boletos.values()][0].status).toBe('CANCELLED');
  });
});

describe('on-ramp, expiry and refunds', () => {
  it('returns an unpaid expired order to the offer', async () => {
    const h = harness({ offramp: false });
    const offerId = await offerFor(h, NATIVE);
    const orderId = h.chain.lockOrder(offerId, 10n ** 17n);
    await h.tick();
    h.chain.warp(31n * 60n);
    h.chain.mine();
    await h.tick();
    expect((await h.chain.order(orderId)).state).toBe(OrderState.CANCELLED);
    expect(h.node.metrics.get('mova_lp_onramp_reclaimed_total')).toBe(1);
  });

  it('refunds BRL received for an order that did not release - only once the cancellation is confirmed', async () => {
    const h = harness({ offramp: false, confirmations: 4 });
    const offerId = await offerFor(h, NATIVE);
    const orderId = h.chain.lockOrder(offerId, 10n ** 17n);
    const ord = await h.chain.order(orderId);
    // Witnesses down: the payment lands, but no proof can be made.
    h.witnesses.splice(0, 2);
    const credit = h.bank.receivePix({ amountCents: ord.brlCents, creditedKey: LP_PIX_KEY, txid: pixTxidForOrder(orderId) });
    await h.tick();
    expect((await h.chain.order(orderId)).state).toBe(OrderState.LOCKED);

    h.chain.warp(31n * 60n);
    h.chain.mine();
    await h.tick(); // reclaims
    expect((await h.chain.order(orderId)).state).toBe(OrderState.CANCELLED);
    await h.tick();
    expect(h.bank.outgoing.filter((x) => x.kind === 'REFUND')).toHaveLength(0); // not confirmed yet

    await settle(h, 4);
    const refunds = h.bank.outgoing.filter((x) => x.kind === 'REFUND');
    expect(refunds).toHaveLength(1);
    expect(refunds[0].destination).toBe(credit.bankTxId);
    expect(refunds[0].amountCents).toBe(ord.brlCents);
    await settle(h, 2);
    expect(h.bank.outgoing.filter((x) => x.kind === 'REFUND')).toHaveLength(1);
    expect(h.node.store.getOrder(orderId)?.done).toBe(OrderState.CANCELLED);
  });

  it('leaves a disputed order to the arbitration desk', async () => {
    const h = harness({ offramp: false });
    const offerId = await offerFor(h, NATIVE);
    const orderId = h.chain.lockOrder(offerId, 10n ** 17n);
    h.chain.raiseDisputeAs('onramp', orderId);
    h.chain.warp(40n * 60n);
    await settle(h, 3);
    expect((await h.chain.order(orderId)).state).toBe(OrderState.DISPUTED);
    expect(h.chain.writes).not.toContain('reclaimExpired');
  });
});

describe('on-ramp, matching edge cases', () => {
  it('never matches a PIX credit to a boleto order by amount, even before its boleto exists', async () => {
    const h = harness({ offramp: false, confirmations: 5 });
    await h.tick();
    const offerId = h.node.offers!.status.get(NATIVE)!.activeOfferId!;
    const boletoOrder = h.chain.lockOrderByBoleto(offerId, 10n ** 17n);
    const ord = await h.chain.order(boletoOrder);
    h.bank.receivePix({ amountCents: ord.brlCents, creditedKey: LP_PIX_KEY }); // no txid, same amount
    await h.tick();
    expect(h.node.store.getOrder(boletoOrder)?.payment).toBeUndefined();
    expect(h.chain.writes).not.toContain('releaseWithProof');
  });
});
