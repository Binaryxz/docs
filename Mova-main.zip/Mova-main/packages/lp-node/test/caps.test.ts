import { describe, expect, it } from 'vitest';
import type { Hex } from 'viem';
import { Rail, newPixSalt, pixKeyCommitment, railMask, railsFromMask } from '@mova/ramp';
import { OrderState, SaleState } from '../src/abi.js';
import { payerRef } from '../src/attestation.js';
import { capDay, dayMinus, payerIdForPayee, type CapsOptions, type TierSource } from '../src/caps.js';
import { NATIVE } from '../src/chain.js';
import type { LpNodeOptions } from '../src/node.js';
import { InstructionsError, pixTxidForOrder } from '../src/onramp.js';
import { PayeeError } from '../src/offramp.js';
import { LP_PIX_KEY, ZKTLS_VERIFIER, harness, type Harness } from './harness.js';

/**
 * Per-payer daily and monthly caps (caps.ts, MVP Scope Rev. 2 §10.1).
 *
 * The cap binds the PAYER the bank names, not an address, so these tests drive the bank
 * rather than the chain: the same payer buying twice, one of them over the limit, a day rolling over in
 * Brasília rather than UTC, and a restart that must not forget what was counted.
 */

/** A CPF the MockBank reports as the payer, and a second person. */
const ANA = '52998224725';
const BRUNO = '11144477735';
/** The harness's payerRef secret. */
const SECRET: Hex = `0x${'ab'.repeat(32)}`;
const refOf = (id: string) => payerRef(id, SECRET);

/** 0.1 ETH at the harness's R$ 20.200,00 per ETH: R$ 2.020,00 an order. */
const ORDER_CENTS = 202_000n;
const TENTH = 10n ** 17n;

function caps(o: Partial<CapsOptions> = {}): CapsOptions {
  return { tiers: {}, defaultTier: 0, ...o };
}

/** A node with `caps`, the on-ramp only unless `offramp` is asked for. */
function capped(o: { caps: CapsOptions; offramp?: boolean; t0?: bigint; tweak?: (x: LpNodeOptions) => void }): Harness {
  return harness({
    offramp: o.offramp ?? false,
    onramp: true,
    t0: o.t0,
    confirmations: 1,
    tweak: (x) => {
      x.caps = o.caps;
      o.tweak?.(x);
    },
  });
}

/** Unix seconds of an instant, for the chain's (and so the node's and the bank's) clock. */
const at = (iso: string) => BigInt(Math.floor(Date.parse(iso) / 1000));

async function offerFor(h: Harness, key: string): Promise<Hex> {
  await h.tick();
  const s = h.node.offers!.status.get(key);
  if (!s?.activeOfferId) throw new Error(`no offer for ${key}: ${s?.reason}`);
  return s.activeOfferId;
}

/** Lock an order, pay it by PIX as `payerId`, tick. Returns the order id and what the bank credited. */
async function buyByPix(h: Harness, payerId: string | null, o: { amount?: bigint; cents?: bigint } = {}): Promise<{ orderId: Hex; cents: bigint }> {
  const offerId = await offerFor(h, NATIVE);
  const orderId = h.chain.lockOrder(offerId, o.amount ?? TENTH);
  await h.tick();
  const cents = o.cents ?? (await h.chain.order(orderId)).brlCents;
  const credit = h.bank.receivePix({ amountCents: cents, creditedKey: LP_PIX_KEY, txid: pixTxidForOrder(orderId), payerId: payerId ?? undefined });
  // `null`: a PSP that reports no payer at all, which is what the standard API Pix does.
  if (payerId === null) delete credit.payerId;
  await h.tick();
  return { orderId, cents };
}

/** Let an order expire, be reclaimed, and its cancellation become confirmed, so the refund runs. */
async function expireAndRefund(h: Harness): Promise<void> {
  h.chain.warp(31n * 60n);
  h.chain.mine();
  await h.tick();
  h.chain.mine(3);
  await h.tick();
  await h.tick();
}

describe('per-payer caps: off unless configured', () => {
  it('a node with no caps section keeps no ledger, refuses nothing, and never asks who paid', async () => {
    const h = harness({ offramp: false });
    expect(h.node.ctx.caps).toBeUndefined();
    const { orderId } = await buyByPix(h, ANA);
    expect((await h.chain.order(orderId)).state).toBe(OrderState.RELEASED);

    // Twice more, well past any limit anyone would set: nothing counts, nothing refuses.
    await buyByPix(h, ANA);
    await buyByPix(h, ANA);
    expect(h.node.store.capRows()).toHaveLength(0);
    expect(h.node.status().caps).toBeNull();
    expect(h.node.metrics.get('mova_lp_caps_enabled')).toBe(0);
    expect(h.journal.lines.some((l) => l.includes('"cap.'))).toBe(false);
  });

  it('a caps section that states no limit counts and refuses nothing', async () => {
    const h = capped({ caps: caps({ tiers: { 0: {} } }) });
    const { orderId } = await buyByPix(h, ANA);
    const second = await buyByPix(h, ANA);
    expect((await h.chain.order(orderId)).state).toBe(OrderState.RELEASED);
    expect((await h.chain.order(second.orderId)).state).toBe(OrderState.RELEASED);
    expect(h.node.ctx.caps!.limiting).toBe(false);
    expect(h.node.ctx.caps!.usage(refOf(ANA), capDay(h.chain.time())).dayCents).toBe(2n * ORDER_CENTS);
  });
});

describe('per-payer caps: the limit', () => {
  it('releases the first purchase and refuses the second, which crosses the day\'s limit; nothing moves and the BRL goes back', async () => {
    const h = capped({ caps: caps({ tiers: { 0: { dailyBrlCents: 300_000n } } }) });
    const first = await buyByPix(h, ANA);
    expect((await h.chain.order(first.orderId)).state).toBe(OrderState.RELEASED);

    const escrowBefore = h.chain.exposure();
    const second = await buyByPix(h, ANA);
    expect((await h.chain.order(second.orderId)).state).toBe(OrderState.LOCKED);
    expect(h.node.store.getOrder(second.orderId)?.cap?.refused).toMatchObject({ period: 'day' });
    // The asset is still the LP's: no proof was fetched, nothing was released.
    expect(h.chain.writes.filter((w) => w === 'releaseWithProof')).toHaveLength(1);
    expect(h.chain.exposure()).toBe(escrowBefore);
    expect(h.node.metrics.get('mova_lp_caps_refusals_total', { leg: 'onramp', reason: 'day' })).toBe(1);

    // Only the first purchase is against her allowance: a refused payment is never counted.
    expect(h.node.ctx.caps!.usage(refOf(ANA), capDay(h.chain.time())).dayCents).toBe(ORDER_CENTS);

    // And the money she sent comes back, which gives her allowance back with it.
    await expireAndRefund(h);
    expect(h.bank.outgoing.filter((o) => o.kind === 'REFUND')).toHaveLength(1);
    expect(h.node.ctx.caps!.usage(refOf(ANA), capDay(h.chain.time())).dayCents).toBe(ORDER_CENTS);
  });

  it('a refunded purchase gives the payer their allowance back', async () => {
    const h = capped({ caps: caps({ tiers: { 0: { dailyBrlCents: 300_000n } } }) });
    const { orderId } = await buyByPix(h, ANA);
    const day = capDay(h.chain.time());
    expect(h.node.ctx.caps!.usage(refOf(ANA), day).dayCents).toBe(ORDER_CENTS);

    // The taker disputes nothing; the order simply is not released in time... so force the cancel path by
    // releasing then cancelling is not possible - instead take an order that was paid and never released.
    const second = await buyByPix(h, ANA, { cents: 50_000n }); // less than the order: unprovable, will expire
    expect((await h.chain.order(second.orderId)).state).toBe(OrderState.LOCKED);
    expect(h.node.ctx.caps!.usage(refOf(ANA), day).dayCents).toBe(ORDER_CENTS + 50_000n);
    await expireAndRefund(h);
    expect(h.node.ctx.caps!.usage(refOf(ANA), day).dayCents).toBe(ORDER_CENTS);
    expect(h.node.store.getOrder(second.orderId)?.cap?.uncounted).toBe(true);
    expect(orderId).toBeTruthy();
  });

  it('counts what the bank credited, not what the order asked for, and leaves the rest of the allowance usable', async () => {
    // R$ 2.500,00 a day. A part payment of R$ 500,00 counts 500, not the order's 2.020.
    const h = capped({ caps: caps({ tiers: { 0: { dailyBrlCents: 250_000n } } }) });
    const partial = await buyByPix(h, ANA, { cents: 50_000n });
    const day = capDay(h.chain.time());
    expect(h.node.ctx.caps!.usage(refOf(ANA), day).dayCents).toBe(50_000n);
    expect((await h.chain.order(partial.orderId)).state).toBe(OrderState.LOCKED); // unprovable, not capped

    // 50.000 + 202.000 = 252.000 > 250.000: refused whole, never part-filled.
    const over = await buyByPix(h, ANA);
    expect(h.node.store.getOrder(over.orderId)?.cap?.refused).toMatchObject({ period: 'day' });
    expect(h.node.ctx.caps!.usage(refOf(ANA), day).dayCents).toBe(50_000n);

    // What still fits does go through: a cap refuses an amount, it does not close the payer's day.
    const fits = await buyByPix(h, ANA, { amount: TENTH / 10n });
    expect((await h.chain.order(fits.orderId)).state).toBe(OrderState.RELEASED);
    expect(h.node.ctx.caps!.usage(refOf(ANA), day).dayCents).toBe(50_000n + 20_200n);
  });

  it('a monthly limit refuses what the daily one allows', async () => {
    const h = capped({ caps: caps({ tiers: { 0: { dailyBrlCents: 500_000n, monthlyBrlCents: 300_000n } } }) });
    await buyByPix(h, ANA);
    const second = await buyByPix(h, ANA);
    expect(h.node.store.getOrder(second.orderId)?.cap?.refused).toMatchObject({ period: 'month' });
    expect(h.node.metrics.get('mova_lp_caps_refusals_total', { leg: 'onramp', reason: 'month' })).toBe(1);
  });

  it('binds the person, not the address: two orders from one payer share one counter, and another payer has their own', async () => {
    const h = capped({ caps: caps({ tiers: { 0: { dailyBrlCents: 300_000n } } }) });
    const day = capDay(h.chain.time());
    // Every order is locked by the same fake taker here; what separates the counters is the BANK's payer.
    await buyByPix(h, ANA);
    const anaAgain = await buyByPix(h, ANA);
    const bruno = await buyByPix(h, BRUNO);

    expect(h.node.store.getOrder(anaAgain.orderId)?.cap?.refused).toBeTruthy();
    expect((await h.chain.order(bruno.orderId)).state).toBe(OrderState.RELEASED);
    expect(h.node.ctx.caps!.usage(refOf(ANA), day)).toEqual({ dayCents: ORDER_CENTS, monthCents: ORDER_CENTS });
    expect(h.node.ctx.caps!.usage(refOf(BRUNO), day)).toEqual({ dayCents: ORDER_CENTS, monthCents: ORDER_CENTS });

    // One row per payer per day: the ledger holds hashes, days and amounts and nothing that names an order.
    const rows = h.node.store.capRows();
    expect(rows).toHaveLength(2);
    expect(new Set(rows.map((r) => r.payer.toLowerCase()))).toEqual(new Set([refOf(ANA).toLowerCase(), refOf(BRUNO).toLowerCase()]));
    for (const line of h.journal.lines.filter((l) => l.includes('"cap.count"'))) {
      expect(line).not.toContain(ANA);
      expect(line).not.toContain(BRUNO);
      expect(line).not.toContain('orderId');
    }
  });
});

describe('per-payer caps: a refusal is not a promise', () => {
  it('counts a refused payment the taker proved and released themselves: the LP kept the BRL', async () => {
    // releaseWithProof is permissionless. A taker who paid can prove it from their own bank session, and
    // no LP policy can stop that - so the cap must at least count what happened.
    const h = capped({ caps: caps({ tiers: { 0: { dailyBrlCents: 300_000n } } }) });
    await buyByPix(h, ANA);
    const day = capDay(h.chain.time());
    const over = await buyByPix(h, ANA);
    expect(h.node.store.getOrder(over.orderId)?.cap?.refused).toMatchObject({ period: 'day' });
    expect(h.node.ctx.caps!.usage(refOf(ANA), day).dayCents).toBe(ORDER_CENTS);

    // The taker proves the credit and releases it without the LP.
    const ord = await h.chain.order(over.orderId);
    const offer = await h.chain.offer(ord.offerId);
    const credit = h.bank.incoming[h.bank.incoming.length - 1];
    const proof = await h.node.ctx.provers.get(ZKTLS_VERIFIER.toLowerCase())!.provePix({
      orderId: over.orderId, payeeKeyHash: offer.pixKeyHash, brlCents: ord.brlCents, lockedAt: ord.lockedAt,
      acceptedRails: railsFromMask(offer.railMask).filter((r) => r !== Rail.BOLETO),
    }, {
      bankTxId: credit.bankTxId, pixKey: LP_PIX_KEY, salt: h.node.store.saltFor(offer.pixKeyHash)!,
      payerRef: payerRef(ANA, SECRET), amountBrlCents: credit.amountCents, paidAt: credit.paidAt, leg: 'onramp',
    });
    await h.chain.releaseWithProof(over.orderId, proof);
    expect((await h.chain.order(over.orderId)).state).toBe(OrderState.RELEASED);

    await h.tick();
    expect(h.node.ctx.caps!.usage(refOf(ANA), day).dayCents).toBe(2n * ORDER_CENTS);
    expect(h.node.store.getOrder(over.orderId)?.cap).toMatchObject({ refused: { period: 'day' }, counted: { cents: ORDER_CENTS } });
    expect(h.logs.some((l) => l.includes('released anyway'))).toBe(true);
    // And it is counted once, however many ticks follow.
    await h.tick();
    await h.tick();
    expect(h.node.ctx.caps!.usage(refOf(ANA), day).dayCents).toBe(2n * ORDER_CENTS);
  });
});

describe('per-payer caps: the day is a Brasília day', () => {
  it('rolls at midnight in Brasília, not at midnight UTC', async () => {
    // 2027-01-16T02:40:00Z is 2027-01-15 23:40 in Brasília: the day is nearly over there and is not over here.
    const h = capped({ caps: caps({ tiers: { 0: { dailyBrlCents: 300_000n } } }), t0: at('2027-01-16T02:40:00Z') });

    await buyByPix(h, ANA);
    expect(h.node.store.capRows()[0].day).toBe('2027-01-15');
    const blocked = await buyByPix(h, ANA);
    expect(h.node.store.getOrder(blocked.orderId)?.cap?.refused).toMatchObject({ period: 'day' });

    // Half an hour on, past 00:00 in Brasília: a new allowance, though the UTC day never changed.
    h.chain.warp(31n * 60n);
    h.chain.mine();
    const next = await buyByPix(h, ANA);
    expect(capDay(h.chain.time())).toBe('2027-01-16');
    expect((await h.chain.order(next.orderId)).state).toBe(OrderState.RELEASED);
    expect(h.node.store.capRows().map((r) => r.day).sort()).toEqual(['2027-01-15', '2027-01-16']);

    // The month keeps both days together, so a monthly limit is not reset by a day rolling.
    expect(h.node.ctx.caps!.usage(refOf(ANA), '2027-01-16')).toEqual({ dayCents: ORDER_CENTS, monthCents: 2n * ORDER_CENTS });
  });

  it('a UTC day rolls at 21:00 in Brasília, and the cap does not roll with it', async () => {
    // 2027-01-15T23:50:00Z: ten minutes before a new UTC day, 20:50 on the 15th in Brasília.
    const h = capped({ caps: caps({ tiers: { 0: { dailyBrlCents: 300_000n } } }), t0: at('2027-01-15T23:50:00Z') });
    await buyByPix(h, ANA);
    expect(h.node.store.capRows()[0].day).toBe('2027-01-15');

    // Past midnight UTC - and still the same Brasília day, so still the same allowance.
    h.chain.warp(31n * 60n);
    h.chain.mine();
    expect(new Date(Number(h.chain.time()) * 1000).toISOString().slice(0, 10)).toBe('2027-01-16');
    expect(capDay(h.chain.time())).toBe('2027-01-15');
    const blocked = await buyByPix(h, ANA);
    expect(h.node.store.getOrder(blocked.orderId)?.cap?.refused).toMatchObject({ period: 'day' });
  });

  it('dayMinus walks the calendar back, which is what retention is measured in', () => {
    expect(dayMinus('2027-01-01', 1)).toBe('2026-12-31');
    expect(dayMinus('2027-03-01', 62)).toBe('2026-12-29');
  });
});

describe('per-payer caps: a restart, and compaction', () => {
  it('a new process over the same journal still knows what the payer moved', async () => {
    const h = capped({ caps: caps({ tiers: { 0: { dailyBrlCents: 300_000n } } }) });
    await buyByPix(h, ANA);
    const day = capDay(h.chain.time());
    expect(h.node.ctx.caps!.usage(refOf(ANA), day).dayCents).toBe(ORDER_CENTS);

    h.restart();
    expect(h.node.ctx.caps!.usage(refOf(ANA), day).dayCents).toBe(ORDER_CENTS);
    const after = await buyByPix(h, ANA);
    expect(h.node.store.getOrder(after.orderId)?.cap?.refused).toMatchObject({ period: 'day' });
    expect((await h.chain.order(after.orderId)).state).toBe(OrderState.LOCKED);
  });

  it('a compacted journal keeps the ledger, and a restart from the snapshot still refuses', async () => {
    const h = capped({ caps: caps({ tiers: { 0: { dailyBrlCents: 300_000n } } }) });
    await buyByPix(h, ANA);
    const day = capDay(h.chain.time());
    expect(h.node.store.compact({ now: h.chain.time() })).toBe(true);
    expect(h.journal.lines).toHaveLength(1);
    expect(h.node.store.capRows()).toHaveLength(1);

    h.restart();
    expect(h.node.ctx.caps!.usage(refOf(ANA), day).dayCents).toBe(ORDER_CENTS);
    const after = await buyByPix(h, ANA);
    expect(h.node.store.getOrder(after.orderId)?.cap?.refused).toBeTruthy();
  });

  it('compaction drops rows older than the retention window and keeps the rest', async () => {
    const h = capped({ caps: caps({ tiers: { 0: { dailyBrlCents: 300_000n } } }) });
    const now = h.chain.time();
    const today = capDay(now);
    const payer = refOf(ANA);
    h.node.store.record({ t: 'cap.count', payer, day: dayMinus(today, 100), cents: 1_000n });
    h.node.store.record({ t: 'cap.count', payer, day: dayMinus(today, 10), cents: 2_000n });
    h.node.store.compact({ now });
    expect(h.node.store.capRows().map((r) => r.day)).toEqual([dayMinus(today, 10)]);
  });

  it('a decision is taken once: a day that rolls over does not release an order already refused', async () => {
    const h = capped({ caps: caps({ tiers: { 0: { dailyBrlCents: 300_000n } } }), t0: at('2027-01-16T02:40:00Z') });
    await buyByPix(h, ANA);
    const blocked = await buyByPix(h, ANA);
    expect(h.node.store.getOrder(blocked.orderId)?.cap?.refused).toBeTruthy();

    // A new Brasília day, and a new allowance - but the refused order stays refused (and by then expired).
    h.chain.warp(20n * 60n);
    h.chain.mine();
    await h.tick();
    expect(capDay(h.chain.time())).toBe('2027-01-16');
    expect((await h.chain.order(blocked.orderId)).state).not.toBe(OrderState.RELEASED);
    expect(h.node.store.getOrder(blocked.orderId)?.cap?.counted).toBeUndefined();
  });
});

describe('per-payer caps: who the payer is', () => {
  it('an unknown payer is refused by default: a limit nobody can be held to is not a limit', async () => {
    const h = capped({ caps: caps({ tiers: { 0: { dailyBrlCents: 1_000_000n } } }) });
    const { orderId } = await buyByPix(h, null);
    expect(h.node.store.getOrder(orderId)?.cap?.refused).toMatchObject({ period: 'unknown_payer' });
    expect((await h.chain.order(orderId)).state).toBe(OrderState.LOCKED);
    expect(h.node.store.capRows()).toHaveLength(0);
    expect(h.node.metrics.get('mova_lp_caps_refusals_total', { leg: 'onramp', reason: 'unknown_payer' })).toBe(1);
  });

  it('unknownPayer "allow" lets it through, uncounted, and says so', async () => {
    const logs: string[] = [];
    const h = harness({
      offramp: false, logSink: logs, confirmations: 1,
      tweak: (x) => { x.caps = caps({ tiers: { 0: { dailyBrlCents: 1_000_000n } }, unknownPayer: 'allow' }); },
    });
    const { orderId } = await buyByPix(h, null);
    expect((await h.chain.order(orderId)).state).toBe(OrderState.RELEASED);
    expect(h.node.store.capRows()).toHaveLength(0);
    expect(logs.some((l) => l.includes('names no payer'))).toBe(true);
  });

  it('is refused wherever any tier limits something, even when the default tier states no limit of its own', async () => {
    // The default tier is 0 and states nothing; tier 4 does. An unnamed payer could be either, so the node
    // cannot know which limit is theirs - and a limit nobody can be held to is not a limit.
    const h = capped({ caps: caps({ tiers: { 4: { dailyBrlCents: 100n } } }) });
    const { orderId } = await buyByPix(h, null);
    expect(h.node.store.getOrder(orderId)?.cap?.refused).toMatchObject({ period: 'unknown_payer' });
  });

  it('is allowed where nothing is limited at all: a ledger that only counts refuses nobody', async () => {
    const h = capped({ caps: caps({ tiers: { 0: {} } }) });
    const { orderId } = await buyByPix(h, null);
    expect((await h.chain.order(orderId)).state).toBe(OrderState.RELEASED);
    expect(h.node.store.capRows()).toHaveLength(0);
  });
});

describe('per-payer caps: tiers', () => {
  it('an unknown payer falls to the default tier, and the configured list raises one person', async () => {
    const h = capped({
      caps: caps({
        tiers: { 0: { dailyBrlCents: 300_000n }, 3: { dailyBrlCents: 1_000_000n } },
        payerTiers: new Map([[refOf(BRUNO).toLowerCase(), 3]]),
      }),
    });
    await buyByPix(h, ANA);
    const anaOver = await buyByPix(h, ANA);
    expect(h.node.store.getOrder(anaOver.orderId)?.cap?.refused).toBeTruthy();

    // Bruno is tier 3: three purchases, all released.
    for (let i = 0; i < 3; i++) {
      const b = await buyByPix(h, BRUNO);
      expect((await h.chain.order(b.orderId)).state).toBe(OrderState.RELEASED);
    }
    expect(h.node.ctx.caps!.usage(refOf(BRUNO), capDay(h.chain.time())).dayCents).toBe(3n * ORDER_CENTS);
  });

  it('a TIER_MODULE decides first, is given the payer and never the order, and a failing one falls back to the configuration', async () => {
    const asked: { payerId?: string; payerRef: Hex; leg: string; rail: string }[] = [];
    let fail = false;
    const tierSource: TierSource = {
      tierOf(p) {
        asked.push({ payerId: p.payerId, payerRef: p.payerRef, leg: p.leg, rail: p.rail });
        if (fail) throw new Error('KYC provider is down');
        return p.payerId === BRUNO ? 4 : undefined;
      },
    };
    const h = capped({
      caps: caps({
        tiers: { 0: { dailyBrlCents: 300_000n }, 4: {} },
        payerTiers: new Map([[refOf(ANA).toLowerCase(), 0]]),
        tierSource,
      }),
    });
    // Tier 4 states no limit: Bruno buys past what tier 0 would allow.
    for (let i = 0; i < 3; i++) {
      const b = await buyByPix(h, BRUNO);
      expect((await h.chain.order(b.orderId)).state).toBe(OrderState.RELEASED);
    }
    expect(asked[0]).toMatchObject({ payerId: BRUNO, payerRef: refOf(BRUNO), leg: 'onramp', rail: 'PIX' });

    // It returns undefined for Ana: the configured list decides, and tier 0 refuses her second purchase.
    await buyByPix(h, ANA);
    const anaOver = await buyByPix(h, ANA);
    expect(h.node.store.getOrder(anaOver.orderId)?.cap?.refused).toBeTruthy();

    // A provider that throws must not promote everyone to no limit.
    fail = true;
    const brunoAfter = await buyByPix(h, BRUNO);
    expect(h.node.store.getOrder(brunoAfter.orderId)?.cap?.refused).toMatchObject({ period: 'day' });
    expect(h.node.metrics.get('mova_lp_caps_tier_errors_total')).toBe(1);
  });
});

describe('per-payer caps: the off-ramp', () => {
  const SELLER = 'vendedor@pix.example';
  const sale = (h: Harness, brlCents = 198_000n) => {
    const salt = newPixSalt();
    const saleId = h.chain.openSale({
      asset: NATIVE, amount: 10n ** 17n, brlCents, payeeKeyHash: pixKeyCommitment(SELLER, salt), railMask: railMask(Rail.PIX),
    });
    return { saleId, salt };
  };

  it('counts the seller as the payer, and refuses the disclosure that would cross their day', async () => {
    const h = capped({ caps: caps({ tiers: { 0: { dailyBrlCents: 300_000n } } }), offramp: true });
    const first = sale(h);
    await h.node.offramp!.submitPayee(first.saleId, { pixKey: SELLER, salt: first.salt });
    await h.tick();
    h.chain.mine(2);
    await h.tick();
    expect((await h.chain.sale(first.saleId)).state).toBe(SaleState.SETTLED);
    const day = capDay(h.chain.time());
    expect(h.node.ctx.caps!.usage(refOf(SELLER), day).dayCents).toBe(198_000n);

    // The next sale crosses the day: the intake says so, and nothing is claimed.
    const second = sale(h);
    const refusal = await h.node.offramp!.submitPayee(second.saleId, { pixKey: SELLER, salt: second.salt })
      .then(() => undefined, (e: unknown) => e);
    expect(refusal).toBeInstanceOf(PayeeError);
    expect((refusal as PayeeError).status).toBe(409);
    expect((refusal as PayeeError).code).toBe('cap_reached');
    // It says a limit was reached and nothing about what she has moved.
    expect((refusal as PayeeError).message).not.toContain('198000');
    await h.tick();
    expect((await h.chain.sale(second.saleId)).state).toBe(SaleState.OPEN);
    expect(h.bank.outgoing.filter((o) => o.kind === 'PIX')).toHaveLength(1);
  });

  it('skips a claim with payer_cap when the disclosure predates the limit being reached', async () => {
    const h = capped({ caps: caps({ tiers: { 0: { dailyBrlCents: 300_000n } } }), offramp: true });
    const a = sale(h);
    const b = sale(h);
    // Both disclosed while there is room for either.
    await h.node.offramp!.submitPayee(a.saleId, { pixKey: SELLER, salt: a.salt });
    await h.node.offramp!.submitPayee(b.saleId, { pixKey: SELLER, salt: b.salt });
    await h.tick();
    h.chain.mine(2);
    await h.tick();
    await h.tick();
    const states = [(await h.chain.sale(a.saleId)).state, (await h.chain.sale(b.saleId)).state];
    expect(states.filter((s) => s === SaleState.SETTLED)).toHaveLength(1);
    expect(h.bank.outgoing.filter((o) => o.kind === 'PIX')).toHaveLength(1);
    const skipped = [h.node.offramp!.skipped.get(a.saleId.toLowerCase()), h.node.offramp!.skipped.get(b.saleId.toLowerCase())];
    expect(skipped).toContain('payer_cap');
  });

  it('a payment the bank refused gives the payee their allowance back', async () => {
    const h = capped({ caps: caps({ tiers: { 0: { dailyBrlCents: 300_000n } } }), offramp: true });
    const { saleId, salt } = sale(h);
    await h.node.offramp!.submitPayee(saleId, { pixKey: SELLER, salt });
    await h.tick();
    h.chain.mine(2);
    h.bank.failNextSend();
    await h.tick();
    expect(h.node.store.getSale(saleId)?.pay?.result?.status).toBe('FAILED');
    expect(h.node.ctx.caps!.usage(refOf(SELLER), capDay(h.chain.time())).dayCents).toBe(0n);
    expect(h.node.store.getSale(saleId)?.cap?.uncounted).toBe(true);
  });

  it('a PIX key that is a CPF is the same person as a bank payer with that CPF; other key kinds are the account', () => {
    expect(payerIdForPayee({ kind: 'pix', pixKey: '529.982.247-25', salt: `0x${'11'.repeat(32)}` })).toBe(ANA);
    expect(payerIdForPayee({ kind: 'pix', pixKey: 'Vendedor@Pix.Example', salt: `0x${'11'.repeat(32)}` })).toBe('vendedor@pix.example');
  });
});

describe('per-payer caps: what a counterparty is told, and what the LP sees', () => {
  it('the taker is told a limit was reached, with a code and no total', async () => {
    const h = capped({ caps: caps({ tiers: { 0: { dailyBrlCents: 300_000n } } }) });
    await buyByPix(h, ANA);
    const { orderId } = await buyByPix(h, ANA);
    const e = await h.node.onramp!.instructions(orderId).then(() => undefined, (x: unknown) => x);
    expect(e).toBeInstanceOf(InstructionsError);
    expect((e as InstructionsError).status).toBe(409);
    expect((e as InstructionsError).code).toBe('cap_reached');
    expect((e as InstructionsError).message).toContain('daily limit');
    expect((e as InstructionsError).message).not.toContain('202000');
    expect((e as InstructionsError).message).not.toContain('300000');
  });

  it('/status shows the LP its own ledger: payer hashes and totals, never a document or an order', async () => {
    const h = capped({ caps: caps({ tiers: { 0: { dailyBrlCents: 300_000n } } }) });
    await buyByPix(h, ANA);
    await buyByPix(h, BRUNO);
    await h.tick();
    const st = h.node.status().caps as Record<string, unknown>;
    expect(st).toMatchObject({ enabled: true, limiting: true, day: capDay(h.chain.time()), defaultTier: 0, unknownPayer: 'refuse', rows: 2 });
    const payers = st.payers as { payerRef: string; dayCents: string; monthCents: string }[];
    expect(payers).toHaveLength(2);
    expect(payers.map((p) => p.payerRef.toLowerCase()).sort())
      .toEqual([refOf(ANA).toLowerCase(), refOf(BRUNO).toLowerCase()].sort());
    expect(payers.every((p) => p.dayCents === ORDER_CENTS.toString())).toBe(true);
    const text = JSON.stringify(st);
    expect(text).not.toContain(ANA);
    expect(text).not.toContain(BRUNO);
    expect(h.node.metrics.get('mova_lp_caps_payers_today')).toBe(2);
    expect(h.node.metrics.get('mova_lp_caps_counted_today_cents')).toBe(Number(2n * ORDER_CENTS));
  });
});
