import { afterEach, describe, expect, it } from 'vitest';
import type { Hex } from 'viem';
import { OrderState } from '../src/abi.js';
import type { BankAdapter, IncomingPayment } from '../src/bank.js';
import { NATIVE } from '../src/chain.js';
import { pixTxidForOrder } from '../src/onramp.js';
import { serveLpNode, webhookSignature, type WebhookAuth } from '../src/server.js';
import { LP_PIX_KEY, harness, type Harness } from './harness.js';

/**
 * The PIX webhook (server.ts, onramp.ts `hint`): a latency optimisation that must not become a way in.
 * It is authenticated, it passes on only end-to-end ids, the node looks each one up at the bank, and only
 * what the bank says is matched.
 */

const SECRET = 'webhook-secret-0123456789abcdef-0123456789';
let closers: (() => Promise<void>)[] = [];
afterEach(async () => {
  for (const c of closers) await c();
  closers = [];
});

async function up(h: Harness, webhook?: WebhookAuth): Promise<string> {
  const s = serveLpNode(h.node, { mode: 'api', webhook });
  closers.push(s.close);
  return `http://127.0.0.1:${await s.listen(0)}`;
}

const hook = (url: string, body: string, headers: Record<string, string> = {}) =>
  fetch(`${url}/v1/webhook/pix`, { method: 'POST', headers: { 'content-type': 'application/json', ...headers }, body });

/** The API Pix `Pix` record a PSP would post, with whatever amount, key and txid the sender claims. */
const pixRecord = (e2e: string, o: { valor: string; chave: string; txid?: string; at: bigint }) => ({
  endToEndId: e2e, txid: o.txid, valor: o.valor, chave: o.chave, horario: new Date(Number(o.at) * 1000).toISOString(),
});

/** The bank's polling lags: `listIncoming` shows nothing, so only a webhook hint can find the credit. */
function laggingListing(h: Harness): void {
  const real = h.bank;
  const bank: BankAdapter = {
    listIncoming: async () => [], getIncoming: (id) => real.getIncoming(id), sendPix: (r) => real.sendPix(r),
    payBoleto: (r) => real.payBoleto(r), getOutgoing: (k) => real.getOutgoing(k), refundIncoming: (r) => real.refundIncoming(r),
  };
  (h.node.ctx as { bank: BankAdapter }).bank = bank;
}

async function lockedOrder(h: Harness): Promise<{ orderId: Hex; brlCents: bigint; credit: IncomingPayment }> {
  await h.tick();
  const orderId = h.chain.lockOrder(h.node.offers!.status.get(NATIVE)!.activeOfferId!, 10n ** 17n);
  await h.tick();
  const brlCents = (await h.chain.order(orderId)).brlCents;
  const credit = h.bank.receivePix({ amountCents: brlCents, creditedKey: LP_PIX_KEY, txid: pixTxidForOrder(orderId) });
  return { orderId, brlCents, credit };
}

describe('the PIX webhook', () => {
  it('a signed webhook makes the next match look the Pix up at the bank; the body\'s amount, key and txid are never used', async () => {
    const h = harness({ offramp: false, confirmations: 1 });
    const { orderId, brlCents, credit } = await lockedOrder(h);
    laggingListing(h);
    await h.tick();
    expect((await h.chain.order(orderId)).state).toBe(OrderState.LOCKED); // polling alone does not see it

    const url = await up(h, { auth: 'hmac', secret: SECRET });
    // The body lies about everything but the id.
    const body = JSON.stringify({ pix: [pixRecord(credit.bankTxId, { valor: '99999.99', chave: 'someone-else@example', txid: 'NOTTHISORDER', at: h.chain.time() })] });
    const res = await hook(url, body, { 'x-webhook-signature': webhookSignature(SECRET, body) });
    expect(res.status).toBe(202);
    expect(await res.text()).not.toContain('99999.99');

    await h.tick();
    expect(h.bank.getIncomingCalls).toBe(1);
    expect(h.node.store.getOrder(orderId)?.payment).toMatchObject({ bankTxId: credit.bankTxId, amountCents: brlCents, creditedKey: LP_PIX_KEY });
    expect((await h.chain.order(orderId)).state).toBe(OrderState.RELEASED);
    expect(h.node.metrics.get('mova_lp_webhook_requests_total', { result: 'accepted' })).toBe(1);
  });

  it('a webhook naming a Pix the bank does not have matches nothing, whatever the body says it paid', async () => {
    const h = harness({ offramp: false, confirmations: 1 });
    const { orderId, brlCents } = await lockedOrder(h);
    laggingListing(h);
    const url = await up(h, { auth: 'hmac', secret: SECRET });
    const forged = 'E99999999202609141200FORGED00001';
    const body = JSON.stringify({ pix: [pixRecord(forged, { valor: `${brlCents / 100n}.${String(brlCents % 100n).padStart(2, '0')}`, chave: LP_PIX_KEY, txid: pixTxidForOrder(orderId), at: h.chain.time() })] });
    expect((await hook(url, body, { 'x-webhook-signature': webhookSignature(SECRET, body) })).status).toBe(202);
    await h.tick();
    expect(h.bank.getIncomingCalls).toBe(1);
    expect(h.node.store.getOrder(orderId)?.payment).toBeUndefined();
    expect((await h.chain.order(orderId)).state).toBe(OrderState.LOCKED);
  });

  it('an unsigned or wrongly signed call is refused, queues nothing, and costs no bank lookup', async () => {
    const h = harness({ offramp: false, confirmations: 1 });
    const { credit } = await lockedOrder(h);
    const url = await up(h, { auth: 'hmac', secret: SECRET });
    const body = JSON.stringify({ pix: [pixRecord(credit.bankTxId, { valor: '1.00', chave: LP_PIX_KEY, at: h.chain.time() })] });
    expect((await hook(url, body)).status).toBe(401);
    expect((await hook(url, body, { 'x-webhook-signature': webhookSignature('another-secret-another-secret-00000', body) })).status).toBe(401);
    const tampered = body.replace('1.00', '2.00');
    expect((await hook(url, tampered, { 'x-webhook-signature': webhookSignature(SECRET, body) })).status).toBe(401);
    await h.tick();
    expect(h.bank.getIncomingCalls).toBe(0);
    expect(h.node.metrics.get('mova_lp_webhook_requests_total', { result: 'unauthorised' })).toBe(3);
  });

  it('behind an mTLS proxy: accepted only with the header the proxy sets after verifying the PSP\'s certificate', async () => {
    const h = harness({ offramp: false, confirmations: 1 });
    const { credit } = await lockedOrder(h);
    const url = await up(h, { auth: 'proxy-mtls', header: 'X-SSL-Client-Verify', value: 'SUCCESS' });
    const body = JSON.stringify({ pix: [pixRecord(credit.bankTxId, { valor: '1.00', chave: LP_PIX_KEY, at: h.chain.time() })] });
    expect((await hook(url, body)).status).toBe(401);
    expect((await hook(url, body, { 'x-ssl-client-verify': 'FAILED:unable to verify' })).status).toBe(401);
    expect((await hook(url, body, { 'x-ssl-client-verify': 'SUCCESS' })).status).toBe(202);
  });

  it('is off unless configured, refuses a body that is not API Pix without echoing it, and bounds the ids taken', async () => {
    const h = harness({ offramp: false, confirmations: 1 });
    expect((await hook(await up(h), '{"pix":[]}')).status).toBe(404);
    const url = await up(h, { auth: 'hmac', secret: SECRET });
    const junk = '{"not":"pix","secretish":"4111111111111111"}';
    const res = await hook(url, junk, { 'x-webhook-signature': webhookSignature(SECRET, junk) });
    expect(res.status).toBe(400);
    expect(await res.text()).not.toContain('4111111111111111');
    const many = JSON.stringify({ pix: Array.from({ length: 250 }, (_, i) => pixRecord(`E99999999202609141200${String(i).padStart(11, '0')}`, { valor: '1.00', chave: LP_PIX_KEY, at: h.chain.time() })) });
    const r2 = await hook(url, many, { 'x-webhook-signature': webhookSignature(SECRET, many) });
    expect(await r2.json()).toEqual({ accepted: 100 });
  });

  it('under run(), a webhook ticks the node at once instead of after the poll interval', async () => {
    const h = harness({ offramp: false, confirmations: 1, tweak: (o) => { o.pollMs = 60_000; } });
    const { orderId, credit } = await lockedOrder(h);
    laggingListing(h);
    const url = await up(h, { auth: 'hmac', secret: SECRET });
    h.node.run();
    try {
      await new Promise((r) => setTimeout(r, 50)); // the first tick of run(); the next is a minute away
      expect((await h.chain.order(orderId)).state).toBe(OrderState.LOCKED);
      const body = JSON.stringify({ pix: [pixRecord(credit.bankTxId, { valor: '1.00', chave: LP_PIX_KEY, at: h.chain.time() })] });
      expect((await hook(url, body, { 'x-webhook-signature': webhookSignature(SECRET, body) })).status).toBe(202);
      for (let i = 0; i < 50 && (await h.chain.order(orderId)).state !== OrderState.RELEASED; i++) await new Promise((r) => setTimeout(r, 20));
      expect((await h.chain.order(orderId)).state).toBe(OrderState.RELEASED);
    } finally {
      await h.node.stop();
    }
  });
});
