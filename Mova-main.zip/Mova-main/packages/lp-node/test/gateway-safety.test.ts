import { describe, expect, it } from 'vitest';
import fc from 'fast-check';
import { ChainRevert } from '../src/chain.js';
import { MOVVA, RESERVE, USDT, inFxCoreSession, type FakeReserve } from './fake-chain.js';
import { E18, MOVVA_LIQUIDITY, U, harness, type Harness } from './harness.js';

/**
 * The Movva gateway's claims, each attacked (gateway.ts, README "Movva gateway"): it never asks the
 * reserve for what the reserve would refuse; `minMovvaOut` binds; it never redeems below par unless
 * configured; USDT's approve quirk is respected; a crash or a reorg anywhere between approval, mint and
 * top-up never mints twice for one need; the caps hold; and, as a property, whatever happens between
 * ticks the node mints only to a need and never beside another unfinished transaction.
 */

const offerOf = (h: Harness) => h.node.offers?.status.get(MOVVA);
const blocked = (h: Harness, op: 'mint' | 'redeem', reason: string) => h.node.metrics.get('mova_lp_gateway_blocked', { op, reason });
const gw = (h: Harness) => h.node.gateway!.status() as { mint: { blocked: string[] }; redeem: { blocked: string[]; held: { reason: string } | null } };
const sends = (h: Harness) => h.chain.attempts.filter((a) => a.phase === 'send');

describe('safety: the gateway never asks for a mint the reserve would refuse, and says why', () => {
  it.each([
    ['mint_paused', { mintPaused: true }],
    ['reserve_frozen', { frozen: true }],
    ['lp_frozen', { lpFrozen: true }],
    ['not_gateway', { isGateway: false }],
    ['setup_incomplete', { setupComplete: false }],
    ['below_mint_ratio', { minMintRatioBps: 11_000n }], // 108% against a 110% floor; the band still reads par
    ['supply_cap', { supplyCap: 1_000_000n * E18 }],
    ['fee_too_high', { mintFeeBps: 60n }],
  ] as [string, Partial<FakeReserve>][])('%s', async (reason, patch) => {
    const h = harness({ gateway: true, offramp: false, confirmations: 1 });
    h.chain.setReserve(patch);
    await h.tick();
    expect(h.chain.attempts).toEqual([]); // not sent, not even simulated
    expect(h.chain.executed('mint')).toEqual([]);
    expect(h.chain.writes).not.toContain('approve');
    expect(blocked(h, 'mint', reason)).toBe(1);
    expect(gw(h).mint.blocked).toContain(reason);
    expect(offerOf(h)).toMatchObject({ quoting: false, reason: 'insufficient_liquidity' });
  });

  it.each([
    ['rate_stale', { rateUpdatedAt: 1_000n }],
    ['rate_unavailable', { rateError: 'FxOutOfRange' }],
  ] as [string, Partial<FakeReserve>][])('%s: the band reverts, the offer is pulled, neither side acts', async (reason, patch) => {
    const h = harness({ gateway: true, confirmations: 1 });
    h.chain.giveMovva(5_000n * E18);
    h.chain.setReserve(patch);
    await h.tick();
    expect(h.chain.attempts).toEqual([]);
    expect(blocked(h, 'mint', reason)).toBe(1);
    expect(blocked(h, 'redeem', reason)).toBe(1);
    expect(h.node.metrics.get('mova_lp_gateway_rate_readable')).toBe(0);
    expect(offerOf(h)).toMatchObject({ quoting: false, reason: 'oracle_unavailable' });
  });

  it('a reserve it cannot read is not a pass: nothing is minted or redeemed, and Movva is not quoted', async () => {
    const h = harness({ gateway: true, confirmations: 1 });
    h.chain.giveMovva(5_000n * E18);
    h.chain.reserveUnreadable = true;
    await h.tick();
    expect(h.chain.attempts).toEqual([]);
    expect(blocked(h, 'mint', 'reserve_unreadable')).toBe(1);
    expect(blocked(h, 'redeem', 'reserve_unreadable')).toBe(1);
    expect(offerOf(h)).toMatchObject({ quoting: false, reason: 'cost_unavailable' });
  });

  it('mints no further than the supply cap allows, then stops at it', async () => {
    const h = harness({ gateway: true, offramp: false, confirmations: 1 });
    h.chain.setReserve({ supplyCap: 1_003_000n * E18 });
    await h.tick();
    // floor(3.000 Movva x 1e6 / 5,40) USDT units: gross Movva can only round down from there.
    expect(h.chain.executed('mint')).toMatchObject([{ amountIn: 555_555_555n }]);
    expect(h.chain.reserveState().supply <= h.chain.reserveState().supplyCap).toBe(true);
    await h.tick();
    expect(h.chain.executed('mint')).toHaveLength(1);
    expect(blocked(h, 'mint', 'supply_cap')).toBe(1);
  });
});

describe('safety: minMovvaOut is previewMint less the configured slippage, and it binds', () => {
  it('a rate that falls past the bound between the plan and inclusion reverts the mint: nothing is minted', async () => {
    const h = harness({ gateway: true, offramp: false, confirmations: 1 });
    const usdt = await h.chain.balance(USDT);
    h.chain.onBroadcast = () => h.chain.setReserve({ rateE18: 5_389_000_000_000_000_000n }, { beforeMempool: true }); // -20 bps
    await h.tick();
    const [op] = h.node.store.gatewayOps.values();
    // The preview: 1.851.851.852 units x 5,40 = 10.000,0000008 Movva, less 10 bps.
    expect(op.minOut).toBe((10_000_000_000_800_000_000_000n * 9_990n) / 10_000n);
    expect(h.chain.executed('mint')).toEqual([]);
    expect(await h.chain.balance(MOVVA)).toBe(0n);
    expect(await h.chain.balance(USDT)).toBe(usdt);
    await h.tick();
    expect(h.node.store.gatewayOps.get(op.opId.toLowerCase())!.result?.outcome).toBe('REVERTED');
    expect(h.node.metrics.get('mova_lp_gateway_mints_total', { outcome: 'reverted' })).toBe(1);
    expect(h.chain.executed('mint')).toHaveLength(1); // re-planned at the new rate, inside its bound
  });

  it('a move inside the bound mints, and delivers at least minMovvaOut', async () => {
    const h = harness({ gateway: true, offramp: false, confirmations: 1 });
    h.chain.onBroadcast = () => h.chain.setReserve({ rateE18: 5_397_300_000_000_000_000n }, { beforeMempool: true }); // -5 bps
    await h.tick();
    const [op] = h.node.store.gatewayOps.values();
    const [m] = h.chain.executed('mint');
    expect(m.amountOut! >= op.minOut).toBe(true);
    expect(m.amountOut! < 10_000n * E18).toBe(true);
  });
});

describe('safety: Movva is never redeemed below par unless the LP configured it', () => {
  // 99% backed: 184.250 USDT at R$ 5,40 behind 1.005.000 Movva.
  const underBacked = { totalUsdt: 184_250n * U, liquidUsdt: 184_250n * U };

  it('holds, raises the alert, and redeems once the reserve is back at par', async () => {
    const h = harness({ gateway: true, onramp: false, confirmations: 1 });
    h.chain.giveMovva(5_000n * E18);
    h.chain.setReserve(underBacked);
    await h.tick();
    expect(h.chain.attempts).toEqual([]);
    expect(gw(h).redeem.held).toMatchObject({ reason: 'below_par' });
    expect(h.node.metrics.get('mova_lp_gateway_held', { reason: 'below_par' })).toBe(1);
    expect(blocked(h, 'redeem', 'below_par')).toBe(1);
    h.chain.setReserve({ totalUsdt: 200_000n * U, liquidUsdt: 200_000n * U });
    await h.tick();
    expect(h.chain.executed('redeem')).toMatchObject([{ amountIn: 4_000n * E18, amountOut: 740_740_740n }]);
    expect(h.node.metrics.get('mova_lp_gateway_held', { reason: 'below_par' })).toBe(0);
  });

  it('with minCollateralRatioBps at 95%, it redeems at 99% and takes the pro-rata share', async () => {
    const h = harness({
      gateway: true, onramp: false, confirmations: 1, tweak: (o) => { o.gateway!.redeem.minCollateralRatioBps = 9_500; },
    });
    h.chain.giveMovva(5_000n * E18);
    h.chain.setReserve(underBacked);
    await h.tick();
    // 4.000 of 1.005.000 Movva, pro rata to 184.250 USDT - not the 740,74 par would pay.
    expect(h.chain.executed('redeem')).toMatchObject([{ amountIn: 4_000n * E18, amountOut: 733_333_333n }]);
  });

  it('refuses to redeem while the reserve charges more than the LP accepted, or to a frozen LP', async () => {
    for (const patch of [{ redeemFeeBps: 60n }, { lpFrozen: true }] as Partial<FakeReserve>[]) {
      const h = harness({ gateway: true, onramp: false, confirmations: 1 });
      h.chain.giveMovva(5_000n * E18);
      h.chain.setReserve(patch);
      await h.tick();
      expect(h.chain.attempts).toEqual([]);
      expect(blocked(h, 'redeem', patch.lpFrozen ? 'lp_frozen' : 'fee_too_high')).toBe(1);
    }
  });
});

describe("safety: USDT's approve quirk - a non-zero allowance is zeroed before it changes", () => {
  it('the fake USDT refuses what TetherToken refuses', async () => {
    const h = harness({ gateway: true, offramp: false });
    h.chain.setAllowance(USDT, RESERVE, 1n);
    await expect(h.chain.approve(USDT, RESERVE, 5n)).rejects.toBeInstanceOf(ChainRevert);
    expect(h.chain.approveQuirkHits).toBe(1);
  });

  it('a leftover allowance from a crashed approval is zeroed, then set, and the mint goes through once', async () => {
    const h = harness({ gateway: true, offramp: false, confirmations: 1 });
    h.chain.setAllowance(USDT, RESERVE, 1_000n);
    await h.tick();
    expect(h.chain.writes.filter((w) => w === 'approve')).toHaveLength(2);
    expect(h.chain.approveQuirkHits).toBe(0);
    expect(h.chain.executed('mint')).toHaveLength(1);
  });

  it('an allowance already large enough is used as it is', async () => {
    const h = harness({ gateway: true, offramp: false, confirmations: 1 });
    h.chain.setAllowance(USDT, RESERVE, 10_000n * U);
    await h.tick();
    expect(h.chain.writes).not.toContain('approve');
    expect(h.chain.executed('mint')).toHaveLength(1);
  });
});

describe('safety: a crash between approval, mint and top-up never mints twice for one need', () => {
  it('after the approval, before the intent: the restart re-plans from fresh balances and mints once', async () => {
    const h = harness({ gateway: true, offramp: false, confirmations: 1 });
    h.chain.failNext = { fn: 'simulateMint', error: new Error('killed') };
    await h.tick();
    expect(await h.chain.allowance(USDT, RESERVE)).toBe(1_851_851_852n);
    expect(h.node.store.gatewayOps.size).toBe(0);
    h.restart();
    await h.tick();
    expect(h.chain.executed('mint')).toHaveLength(1);
    expect(h.chain.writes.filter((w) => w === 'approve')).toHaveLength(1);
    expect(offerOf(h)).toMatchObject({ quoting: true, available: MOVVA_LIQUIDITY });
  });

  it('after the mint was broadcast, before its hash was recorded: the restart waits for it and mints nothing more', async () => {
    const h = harness({ gateway: true, offramp: false, confirmations: 3 });
    h.chain.holdSends = true;
    h.chain.loseNextSendResponse = true;
    await h.tick();
    const [op] = h.node.store.gatewayOps.values();
    expect(op.tx).toBeUndefined();
    expect(h.chain.pending()).toHaveLength(1);

    h.restart();
    await h.tick();
    expect(sends(h)).toHaveLength(1);
    expect(blocked(h, 'mint', 'tx_pending')).toBe(1);

    h.chain.holdSends = false;
    h.chain.mine(); // it lands
    await h.tick(); // not three deep yet: still open - but the offer can post from the wallet
    expect(offerOf(h)).toMatchObject({ quoting: true, available: MOVVA_LIQUIDITY });
    h.chain.mine(3);
    await h.tick();
    expect(h.node.store.gatewayOps.get(op.opId.toLowerCase())!.result?.outcome).toBe('CONSUMED');
    for (let i = 0; i < 3; i++) await h.tick();
    expect(h.chain.executed('mint')).toHaveLength(1);
    expect(sends(h)).toHaveLength(1);
  });

  it('...and when that broadcast reached nobody: the nonce is taken again, and a copy that surfaces cannot mine', async () => {
    const h = harness({ gateway: true, offramp: false, confirmations: 1 });
    h.chain.holdSends = true;
    h.chain.loseNextSendResponse = true;
    await h.tick();
    const [ghost] = h.chain.pending();
    h.chain.dropPending();
    h.chain.holdSends = false;
    h.restart();
    await h.tick();
    expect([...h.node.store.gatewayOps.values()][0].result?.outcome).toBe('DROPPED');
    expect(h.chain.executed('mint')).toHaveLength(1);
    h.chain.reinject(ghost);
    h.chain.mine(2);
    await h.tick();
    expect(h.chain.executed('mint')).toHaveLength(1);
    const held = (await h.chain.balance(MOVVA)) + (await h.chain.offer(offerOf(h)!.activeOfferId!)).availableWei;
    expect(held <= MOVVA_LIQUIDITY + 5_400_000_000_000n).toBe(true);
  });

  it('after the mint mined but before anything was recorded: the restart counts it and mints nothing more', async () => {
    const h = harness({ gateway: true, offramp: false, confirmations: 3 });
    h.chain.loseNextSendResponse = true;
    await h.tick();
    expect(h.chain.executed('mint')).toHaveLength(1);
    h.restart();
    for (let i = 0; i < 4; i++) {
      await h.tick();
      h.chain.mine();
    }
    expect(h.chain.executed('mint')).toHaveLength(1);
    expect([...h.node.store.gatewayOps.values()].map((o) => o.result?.outcome)).toEqual(['CONSUMED']);
    expect(offerOf(h)).toMatchObject({ quoting: true, available: MOVVA_LIQUIDITY });
  });

  it('a redemption broadcast before its hash was recorded is waited for, not repeated', async () => {
    const h = harness({ gateway: true, onramp: false, confirmations: 2 });
    h.chain.giveMovva(5_000n * E18);
    h.chain.holdSends = true;
    h.chain.loseNextSendResponse = true;
    await h.tick();
    h.restart();
    await h.tick();
    expect(blocked(h, 'redeem', 'tx_pending')).toBe(1);
    h.chain.holdSends = false;
    h.chain.mine(3);
    await h.tick();
    await h.tick();
    expect(h.chain.executed('redeem')).toHaveLength(1);
    expect(sends(h)).toHaveLength(1);
    expect(await h.chain.balance(MOVVA)).toBe(1_000n * E18);
  });

  it('a reorg that returns the mint to the mempool: the node waits for it rather than minting again', async () => {
    const h = harness({ gateway: true, offramp: false, confirmations: 3 });
    await h.tick(); // approve, mint, post
    h.chain.reorg(2, { reinject: true }); // the mint's block and the post's
    expect(h.chain.executed('mint')).toHaveLength(0);
    await h.tick();
    expect(sends(h)).toHaveLength(1);
    h.chain.mine(4);
    await h.tick();
    await h.tick();
    expect(h.chain.executed('mint')).toHaveLength(1);
    expect(sends(h)).toHaveLength(1);
    expect(offerOf(h)).toMatchObject({ quoting: true, available: MOVVA_LIQUIDITY });
  });

  it('a mint the node has SEEN mined, but fewer than N blocks deep, is not final: a reorg that re-queues it is waited for', async () => {
    const h = harness({ gateway: true, offramp: false, confirmations: 3 });
    await h.tick(); // approve, mint, post
    await h.tick(); // the node sees the mint mined, two blocks deep: not yet final
    expect([...h.node.store.gatewayOps.values()][0].result).toBeUndefined();
    h.chain.reorg(2, { reinject: true }); // the mint's block and the post's, back to the mempool
    await h.tick();
    h.chain.mine(4);
    await h.tick();
    await h.tick();
    expect(h.chain.executed('mint')).toHaveLength(1);
    expect(sends(h)).toHaveLength(1);
    expect([...h.node.store.gatewayOps.values()].map((o) => o.result?.outcome)).toEqual(['MINED']);
  });

  it('...and one that drops it: the nonce is free again, so the node mints once more and one mint exists', async () => {
    const h = harness({ gateway: true, offramp: false, confirmations: 3 });
    await h.tick();
    h.chain.reorg(2);
    await h.tick();
    h.chain.mine(3);
    await h.tick();
    expect(h.chain.executed('mint')).toHaveLength(1);
    expect(sends(h)).toHaveLength(2);
  });

  it('holds on a nonce gap it cannot reason about, and mints nothing while it lasts', async () => {
    const h = harness({ gateway: true, offramp: false, confirmations: 1 });
    h.node.store.record({
      t: 'gateway.intent', opId: `0x${'77'.repeat(32)}`, op: 'mint', amountIn: 1n * U, minOut: 1n, need: 1n, nonce: 99, wallAt: h.chain.time(),
    });
    await h.tick();
    expect(h.chain.attempts).toEqual([]);
    expect(h.node.metrics.get('mova_lp_gateway_held', { reason: 'nonce_gap' })).toBe(1);
    expect(blocked(h, 'mint', 'nonce_gap')).toBe(1);
  });
});

describe('safety: a stuck gateway transaction is replaced, and a replacement is never a second mint', () => {
  const stuck = (h: Harness) => {
    h.chain.txPolicy.replaceAfterBlocks = 2;
    h.chain.baseFee = 2n * 1_000_000_000n; // the mint offers 1 gwei: it sits in the mempool
  };

  it('re-sends the mint at its nonce with a bumped fee after replaceAfterBlocks, journals both hashes, and resolves MINED once', async () => {
    const h = harness({ gateway: true, offramp: false, confirmations: 2 });
    stuck(h);
    await h.tick();
    expect(h.chain.pending()).toHaveLength(1);
    const [op] = h.node.store.gatewayOps.values();
    h.chain.mine(2);
    h.chain.feeEstimate = 3n * 1_000_000_000n; // the market moved: the replacement follows it
    await h.tick();
    expect(h.node.store.gatewayOps.get(op.opId.toLowerCase())!.txs).toHaveLength(2);
    expect(h.node.metrics.get('mova_lp_tx_replacements_total', { kind: 'gateway' })).toBe(1);
    h.chain.mine(3);
    await h.tick();
    await h.tick();
    const done = h.node.store.gatewayOps.get(op.opId.toLowerCase())!;
    expect(done.result?.outcome).toBe('MINED');
    expect(h.chain.executed('mint')).toHaveLength(1);
    expect(sends(h)).toHaveLength(1);
    expect(offerOf(h)).toMatchObject({ quoting: true });
  });

  it('stops at the fee cap: no bump past it, the alert, and nothing new planned while the mint is stuck', async () => {
    const h = harness({ gateway: true, offramp: false, confirmations: 1 });
    stuck(h);
    h.chain.txPolicy.maxFeePerGasWei = 1_050_000_000n; // under the 10% a replacement needs
    await h.tick();
    for (let i = 0; i < 4; i++) {
      h.chain.mine(2);
      await h.tick();
    }
    const [op] = h.node.store.gatewayOps.values();
    expect(op.txs).toHaveLength(1);
    expect(h.chain.pending()[0].maxFee).toBe(1_000_000_000n);
    expect(h.node.metrics.get('mova_lp_tx_fee_capped_total', { kind: 'gateway' })).toBeGreaterThan(0);
    expect(sends(h)).toHaveLength(1);
    expect(blocked(h, 'mint', 'tx_pending')).toBe(1);
  });

  it('a crash after the replacement was broadcast, before its hash was recorded: resolved from the nonce as CONSUMED, one mint', async () => {
    const h = harness({ gateway: true, offramp: false, confirmations: 2 });
    stuck(h);
    await h.tick();
    h.chain.mine(2);
    h.chain.feeEstimate = 3n * 1_000_000_000n;
    h.chain.loseNextReplaceResponse = true;
    await h.tick(); // the replacement is in the mempool; the node never heard its hash
    const [op] = h.node.store.gatewayOps.values();
    expect(h.node.store.gatewayOps.get(op.opId.toLowerCase())).toMatchObject({ replacing: true });
    expect(h.node.store.gatewayOps.get(op.opId.toLowerCase())!.txs).toHaveLength(1);

    h.restart();
    h.chain.mine(3);
    for (let i = 0; i < 3; i++) await h.tick();
    expect(h.node.store.gatewayOps.get(op.opId.toLowerCase())!.result?.outcome).toBe('CONSUMED');
    expect(h.chain.executed('mint')).toHaveLength(1);
    expect(sends(h)).toHaveLength(1);
  });
});

describe('safety: mints stay inside the per-mint and daily caps', () => {
  it('splits a need across mints of at most maxMintUsdt, and stops at maxMintUsdtPerDay until a day has passed', async () => {
    const h = harness({
      gateway: true, offramp: false, confirmations: 1,
      tweak: (o) => { o.gateway!.mint.maxMintUsdt = 500n * U; o.gateway!.mint.maxMintUsdtPerDay = 1_200n * U; },
    });
    const drain = async () => {
      const id = offerOf(h)?.activeOfferId;
      if (!id) return;
      const off = await h.chain.offer(id);
      const amount = off.availableWei < 5_000n * E18 ? off.availableWei : 5_000n * E18;
      if (amount >= 10n * E18) h.chain.releaseAsOther(h.chain.lockOrder(id, amount));
    };
    for (let i = 0; i < 6; i++) {
      await h.tick();
      await drain();
    }
    const mints = h.chain.executed('mint');
    for (const m of mints) expect(m.amountIn <= 500n * U).toBe(true);
    expect(mints.reduce((s, m) => s + m.amountIn, 0n)).toBe(1_200n * U);
    expect(blocked(h, 'mint', 'daily_cap')).toBe(1);
    h.chain.warp(86_400n);
    h.chain.publishRate();
    await h.tick();
    expect(h.chain.executed('mint').length).toBeGreaterThan(mints.length);
  });
});

describe('safety: off-hours - with the FX market closed the node keeps selling Movva it holds, and neither mints nor redeems', () => {
  // FakeChain's t0 is Friday 15 January 2027, 08:00 UTC.
  const FRIDAY_2050_UTC = 12n * 3600n + 50n * 60n; // after t0
  const TO_SATURDAY_NOON = 15n * 3600n + 10n * 60n;
  const TO_MONDAY_1400 = 50n * 3600n;

  it('holds both as market_closed while the Movva offer stays posted from the close, and resumes once the reopened market has a price', async () => {
    const h = harness({ gateway: true, confirmations: 1 });
    // A Pyth FX leg: outside the core session the band takes a close up to four days old; the rate refuses it at once.
    h.chain.setReserve({ fxLeg: 'pyth', closedMaxAge: 4n * 86_400n });
    h.chain.warp(FRIDAY_2050_UTC);
    h.chain.publishRate(); // the keeper's last Friday price, inside the core session
    expect(inFxCoreSession(h.chain.time())).toBe(true);
    for (let i = 0; i < 3; i++) { await h.tick(); h.chain.mine(); }
    expect(offerOf(h)).toMatchObject({ quoting: true });
    expect(h.node.metrics.get('mova_lp_gateway_market_closed')).toBe(0);
    const mints = h.chain.executed('mint').length;
    const redeems = h.chain.executed('redeem').length;
    expect(mints).toBe(1);

    h.chain.warp(TO_SATURDAY_NOON);
    h.chain.mine();
    expect(inFxCoreSession(h.chain.time())).toBe(false);
    h.chain.giveMovva(20_000n * E18); // Movva the LP holds: far above its working balance
    const attempts = h.chain.attempts.length;
    // Takers drain the offer below its refill threshold: it wants a top-up, which can only come from the wallet.
    const offerId = offerOf(h)!.activeOfferId!;
    for (let i = 0; i < 2; i++) h.chain.releaseAsOther(h.chain.lockOrder(offerId, 3_000n * E18));
    for (let i = 0; i < 3; i++) { await h.tick(); h.chain.mine(); }

    expect(h.chain.attempts.slice(attempts)).toEqual([]); // nothing even simulated
    expect(h.chain.executed('mint')).toHaveLength(mints);
    expect(h.chain.executed('redeem')).toHaveLength(redeems);
    expect([blocked(h, 'mint', 'market_closed'), blocked(h, 'redeem', 'market_closed')]).toEqual([1, 1]);
    expect(gw(h).redeem.held?.reason).toBe('market_closed');
    expect(h.node.gateway!.status()).toMatchObject({ market: 'closed' });
    expect(h.node.metrics.get('mova_lp_gateway_held', { reason: 'market_closed' })).toBe(1);
    expect(h.node.metrics.get('mova_lp_gateway_market_closed')).toBe(1);
    // Still quoting, from the close: the escrow band reads it stamped current, and the top-up came from the wallet.
    expect(offerOf(h)).toMatchObject({ quoting: true, oraclePrice: 100n });
    expect((await h.chain.offer(offerOf(h)!.activeOfferId!)).availableWei).toBeGreaterThan(8_000n * E18);
    // The calendar, not an incident: said once, at info.
    expect(h.logs.filter((l) => l.includes('waiting: the FX market is closed'))).toHaveLength(1);
    expect(h.logs.filter((l) => l.startsWith('error'))).toEqual([]);

    // Monday 14:00 UTC, the core session, before the keeper's first price: a missing price, not a closed market.
    h.chain.warp(TO_MONDAY_1400);
    h.chain.mine();
    await h.tick();
    expect(blocked(h, 'redeem', 'rate_stale')).toBe(1);
    expect(blocked(h, 'redeem', 'market_closed')).toBe(0);
    expect(offerOf(h)).toMatchObject({ quoting: false, reason: 'oracle_unavailable' });

    h.chain.publishRate();
    for (let i = 0; i < 4 && h.chain.executed('redeem').length === redeems; i++) { await h.tick(); h.chain.mine(); }
    expect(h.chain.executed('redeem').length).toBeGreaterThan(redeems);
    for (let i = 0; i < 2; i++) { await h.tick(); h.chain.mine(); }
    expect(offerOf(h)?.quoting).toBe(true);
    expect(gw(h).redeem.held).toBeNull();
    expect(h.node.metrics.get('mova_lp_gateway_market_closed')).toBe(0);
    expect(h.logs.some((l) => l.includes('no longer holding (market_closed)'))).toBe(true);
    for (const s of h.chain.attempts.slice(attempts)) expect(s.refusals).toEqual([]);
  });
});

type Action =
  | { t: 'tick' } | { t: 'drain'; bps: number } | { t: 'lockCancel'; bps: number } | { t: 'mine'; n: number } | { t: 'restart' }
  | { t: 'hold'; on: boolean } | { t: 'lose' } | { t: 'drop' } | { t: 'pause'; on: boolean } | { t: 'freeze'; on: boolean }
  | { t: 'stale' } | { t: 'rate'; bps: number } | { t: 'cap'; movva: number } | { t: 'day' }
  | { t: 'reorg'; depth: number; reinject: boolean };

const action: fc.Arbitrary<Action> = fc.oneof(
  { weight: 6, arbitrary: fc.constant({ t: 'tick' } as const) },
  { weight: 3, arbitrary: fc.record({ t: fc.constant('drain' as const), bps: fc.integer({ min: 100, max: 10_000 }) }) },
  { weight: 1, arbitrary: fc.record({ t: fc.constant('lockCancel' as const), bps: fc.integer({ min: 100, max: 10_000 }) }) },
  { weight: 2, arbitrary: fc.record({ t: fc.constant('mine' as const), n: fc.integer({ min: 1, max: 3 }) }) },
  { weight: 1, arbitrary: fc.constant({ t: 'restart' } as const) },
  { weight: 1, arbitrary: fc.record({ t: fc.constant('hold' as const), on: fc.boolean() }) },
  { weight: 1, arbitrary: fc.constant({ t: 'lose' } as const) },
  { weight: 1, arbitrary: fc.constant({ t: 'drop' } as const) },
  { weight: 1, arbitrary: fc.record({ t: fc.constant('pause' as const), on: fc.boolean() }) },
  { weight: 1, arbitrary: fc.record({ t: fc.constant('freeze' as const), on: fc.boolean() }) },
  { weight: 1, arbitrary: fc.constant({ t: 'stale' } as const) },
  { weight: 1, arbitrary: fc.record({ t: fc.constant('rate' as const), bps: fc.integer({ min: 9_500, max: 10_500 }) }) },
  { weight: 1, arbitrary: fc.record({ t: fc.constant('cap' as const), movva: fc.integer({ min: 0, max: 20_000 }) }) },
  { weight: 1, arbitrary: fc.constant({ t: 'day' } as const) },
  { weight: 2, arbitrary: fc.record({ t: fc.constant('reorg' as const), depth: fc.integer({ min: 1, max: 3 }), reinject: fc.boolean() }) },
);

/**
 * `seen`: the highest head any tick has read. A reorg may only remove blocks above `seen - N + 1`: the
 * node's safety assumption is that no reorg is deeper than `confirmations` (README, "Failure modes").
 */
async function apply(h: Harness, a: Action, n: number, seen: { head: bigint }): Promise<void> {
  const c = h.chain;
  switch (a.t) {
    case 'tick': {
      const head = c.blocks[c.blocks.length - 1].number;
      if (head > seen.head) seen.head = head;
      return h.tick();
    }
    case 'reorg': {
      const head = c.blocks[c.blocks.length - 1].number;
      let depth = a.depth;
      while (depth > 0 && head - BigInt(depth) + 1n <= seen.head - BigInt(n) + 1n) depth--;
      if (depth > 0 && depth < c.blocks.length - 1) c.reorg(depth, { reinject: a.reinject });
      return;
    }
    case 'drain': case 'lockCancel': {
      const id = offerOf(h)?.activeOfferId;
      if (!id) return;
      const off = await c.offer(id);
      let amount = (off.availableWei * BigInt(a.bps)) / 10_000n;
      if (amount > off.maxOrderWei) amount = off.maxOrderWei;
      if (!off.active || amount < off.minOrderWei) return;
      try {
        const orderId = c.lockOrder(id, amount);
        if (a.t === 'drain') c.releaseAsOther(orderId);
        else c.cancelOrder(orderId);
      } catch (e) {
        if (!(e instanceof ChainRevert)) throw e; // the band moved under the taker: no order
      }
      return;
    }
    case 'mine': return c.mine(a.n);
    case 'restart': h.restart(); return;
    case 'hold': c.holdSends = a.on; return;
    case 'lose': c.loseNextSendResponse = true; return;
    case 'drop': return c.dropPending();
    case 'pause': return c.setReserve({ mintPaused: a.on });
    case 'freeze': return c.setReserve({ frozen: a.on });
    case 'stale': c.warp(3_700n); return c.mine();
    case 'rate': return c.publishRate((5_400_000_000_000_000_000n * BigInt(a.bps)) / 10_000n);
    case 'cap': return c.setReserve({ supplyCap: c.reserveState().supply + BigInt(a.movva) * E18 });
    case 'day': c.warp(86_400n); return c.publishRate();
  }
}

describe('safety: property - whatever happens between ticks, it mints only to a need, inside its caps, never beside another', () => {
  const N = 2;
  const MAX_MINT = 700n * U;
  const PER_DAY = 2_000n * U;

  it('holds for random interleavings of drains, crashes, lost and dropped sends, reorgs, pauses, freezes, stale rates and caps', async () => {
    // Not vacuous: count what the runs actually exercised, and require it below.
    const seen = { runsWithMints: 0, runsWithTwoMints: 0, runsWithRedeems: 0, restartsWithAnOpenIntent: 0, lostSends: 0 };
    await fc.assert(fc.asyncProperty(fc.array(action, { minLength: 1, maxLength: 25 }), async (actions) => {
      const h = harness({
        gateway: true, offramp: false, confirmations: N,
        tweak: (o) => { o.gateway!.mint.maxMintUsdt = MAX_MINT; o.gateway!.mint.maxMintUsdtPerDay = PER_DAY; },
      });
      const tickSeen = { head: 0n };
      for (const a of actions) {
        if (a.t === 'restart' && h.node.store.openGatewayOps().length > 0) seen.restartsWithAnOpenIntent++;
        const lose = h.chain.loseNextSendResponse;
        await apply(h, a, N, tickSeen);
        if (lose && !h.chain.loseNextSendResponse) seen.lostSends++;
      }
      const minted = h.chain.attempts.filter((s) => s.phase === 'send' && s.kind === 'mint').length;
      if (minted > 0) seen.runsWithMints++;
      if (minted > 1) seen.runsWithTwoMints++;
      if (h.chain.attempts.some((s) => s.phase === 'send' && s.kind === 'redeem')) seen.runsWithRedeems++;

      for (const s of h.chain.attempts) {
        // Nothing the reserve would refuse was even simulated.
        expect(s.refusals).toEqual([]);
        if (s.phase !== 'send') continue;
        // Never beside another gateway transaction that could still mine, or mined and not yet final.
        expect(s.mempoolGateway).toBe(0);
        if (s.lastGatewayReceiptBlock !== undefined) expect(s.lastGatewayReceiptBlock <= s.head - BigInt(N) + 1n).toBe(true);
        if (s.kind === 'mint') {
          expect(s.amount <= MAX_MINT).toBe(true);
          // To a need: what the wallet holds, what the active offer has, and this mint, is the target plus rounding.
          expect(s.walletMovva + s.activeAvailable + s.expectedOut <= MOVVA_LIQUIDITY + s.rateE18 / U + 1n).toBe(true);
        }
      }
      // The daily cap, over what actually minted, by the time each was planned.
      const ops = [...h.node.store.gatewayOps.values()].filter((o) => o.op === 'mint');
      const planned = h.chain.executed('mint').map((m) => {
        const op = ops.filter((o) => o.nonce === m.nonce && o.result?.outcome !== 'DROPPED').at(-1);
        expect(op, `an executed mint at nonce ${m.nonce} with no intent`).toBeDefined();
        return { at: op!.wallAt, amount: m.amountIn };
      });
      for (const m of planned) {
        const window = planned.filter((x) => x.at <= m.at && x.at + 86_400n > m.at).reduce((s, x) => s + x.amount, 0n);
        expect(window <= PER_DAY).toBe(true);
      }
      expect(h.chain.approveQuirkHits).toBe(0);
    }), { numRuns: 200 });
    expect(seen.runsWithMints).toBeGreaterThan(50);
    expect(seen.runsWithTwoMints).toBeGreaterThan(10);
    expect(seen.restartsWithAnOpenIntent + seen.lostSends).toBeGreaterThan(5);
  }, 240_000);
});
