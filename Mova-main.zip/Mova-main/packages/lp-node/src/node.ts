/**
 * The LP node: one loop, one head per tick, three handlers.
 *
 * ## Shape
 *
 * Each tick polls the chain once (events.ts), hands the new events to the handlers so they start
 * tracking what concerns this LP, pins a `TickView`, and runs, in this order:
 *
 *   1. off-ramp sales - claims already held have a 45-minute clock and BRL may be in flight;
 *   2. on-ramp orders - boleto issue deadlines, payments to match, releases, refunds;
 *   3. offers - repricing and top-ups, which are never urgent in the same way.
 *
 * A Movva gateway (gateway.ts) brackets them: before anything is written it settles mints and
 * redemptions an earlier tick or a crashed process left open; the offer manager asks it to mint while
 * funding the Movva offer; and after everything else it redeems Movva above the working balance, when
 * the tick's sales have settled and its offers have taken what they need.
 *
 * With `rewards` configured, a last step claims the LP's node-provider rewards (rewards.ts): it finalizes
 * epochs whose review has ended and claims its share of each, after the tick's own settlements have been
 * counted.
 *
 * Ticks never overlap: the next is scheduled when the previous finishes. So there is exactly one
 * writer to the journal and one sender of transactions from this key, and no nonce races within
 * the process. Two processes on one key and one journal are not supported - see the README.
 *
 * ## Failure
 *
 * A handler that throws on one order, sale or asset logs, counts `mova_lp_tick_errors_total`,
 * and moves on to the next; the tick itself fails only if the chain cannot be read at all.
 * Whatever was half-done is resumed next tick from the journal and fresh chain reads, which is
 * the same path a restart takes - a crash is not a special case.
 *
 * `stop()` waits for the tick in flight. A payment the tick had started is then finished and
 * recorded rather than left for the restart to resolve; the restart would resolve it correctly,
 * but a clean shutdown should not create work.
 */
import type { Hex } from 'viem';
import { redact } from '@mova/ops/redact';
import type { PaymentProver } from './attestation.js';
import type { BankAdapter } from './bank.js';
import { CapLedger, type CapsOptions } from './caps.js';
import { isGatewayChain, isRewardsChain, sameAddress, type RampChain } from './chain.js';
import { errorText, silentLogger, type Logger, type NodeContext, type TickView } from './context.js';
import { EventSync } from './events.js';
import { EvidenceSubmitter, type ArbitrationClient, type EvidenceSigner } from './evidence.js';
import { GatewayManager, type GatewayOptions } from './gateway.js';
import { RewardsManager, type RewardsOptions } from './rewards.js';
import type { Journal } from './journal.js';
import { Metrics } from './metrics.js';
import { OfferManager, type OfferAssetConfig } from './offers.js';
import { OfframpHandler, type OfframpOptions } from './offramp.js';
import { OnrampHandler, type OnrampOptions } from './onramp.js';
import { Store, type LpRecord } from './store.js';

export interface LpNodeOptions {
  chain: RampChain;
  bank: BankAdapter;
  journal: Journal<LpRecord>;
  provers?: readonly PaymentProver[];
  onramp?: OnrampOptions & { assets: readonly OfferAssetConfig[] };
  offramp?: OfframpOptions;
  /** File evidence commitments with the arbitration desk for disputed orders and sales, signed by the LP key. */
  arbitration?: { client: ArbitrationClient; signer: EvidenceSigner };
  /** Operate as a Movva gateway. The chain must also implement `GatewayChain`. */
  gateway?: GatewayOptions;
  /** Claim node-provider rewards from NodeRewards. The chain must also implement `RewardsChain`. */
  rewards?: RewardsOptions;
  /**
   * Per-payer daily and monthly limits (caps.ts). Absent - the default - the node has no cap ledger and
   * behaves exactly as it did before caps existed.
   */
  caps?: CapsOptions;
  /** Blocks deep a claim or cancellation must be before BRL moves because of it. At least 1. */
  confirmations: number;
  fromBlock: bigint;
  reorgWindow: bigint;
  logSpan?: bigint;
  payerRefSecret: Hex;
  lpPayerId: string;
  log?: Logger;
  /** Wall clock, unix seconds. */
  wallClock?: () => bigint;
  pollMs?: number;
  /** Values never to appear in /status or logs: RPC URL, credentials. */
  redactValues?: readonly (string | undefined)[];
  /** Compact the journal (store.ts `snapshot`) at the end of a tick once it holds more than this many bytes. */
  compactJournalAtBytes?: number;
}

export class LpNode {
  readonly metrics = new Metrics();
  readonly store: Store;
  readonly ctx: NodeContext;
  readonly events: EventSync;
  readonly offers?: OfferManager;
  readonly onramp?: OnrampHandler;
  readonly offramp?: OfframpHandler;
  readonly gateway?: GatewayManager;
  readonly rewards?: RewardsManager;
  ready = false;
  lastTick?: { at: string; head: bigint; indexed: bigint; durationMs: number; error?: string };
  private credit?: { capCents: bigint; availableCents: bigint };
  private stopping = false;
  private timer?: ReturnType<typeof setTimeout>;
  private inflight?: Promise<void>;
  private reorgsSeen = 0;
  private loop?: () => Promise<void>;
  private wakeAgain = false;

  constructor(private readonly o: LpNodeOptions) {
    if (o.confirmations < 1) throw new Error('confirmations must be at least 1');
    if (o.reorgWindow < BigInt(o.confirmations)) throw new Error('reorgWindow must be at least confirmations');
    this.store = new Store(o.journal);
    this.store.load();
    this.ctx = {
      chain: o.chain, bank: o.bank, store: this.store, metrics: this.metrics, log: o.log ?? silentLogger,
      provers: new Map((o.provers ?? []).map((p) => [p.verifier.toLowerCase(), p])),
      payerRefSecret: o.payerRefSecret, lpPayerId: o.lpPayerId, wallClock: () => this.wallNow(),
    };
    if (o.arbitration) this.ctx.evidence = new EvidenceSubmitter(this.ctx, o.arbitration);
    // Before the handlers: they read `ctx.caps` on the path that decides whether money moves.
    if (o.caps) this.ctx.caps = new CapLedger(this.ctx, o.caps);
    this.events = new EventSync(o.chain, this.store, {
      fromBlock: o.fromBlock, reorgWindow: o.reorgWindow, span: o.logSpan,
    });
    if (o.gateway) {
      if (!isGatewayChain(o.chain)) throw new Error('gateway: the chain does not implement the reserve calls (GatewayChain)');
      this.gateway = new GatewayManager(this.ctx, o.chain, o.gateway);
    }
    if (o.rewards) {
      if (!isRewardsChain(o.chain)) throw new Error('rewards: the chain does not implement the NodeRewards calls (RewardsChain)');
      this.rewards = new RewardsManager(this.ctx, o.chain, o.rewards);
    }
    const g = this.gateway;
    // The gateway's Movva, on either leg, is priced against what minting costs and redeeming pays.
    const movva = (asset: string) => !!g && sameAddress(asset, g.o.movva);
    if (o.onramp) {
      this.onramp = new OnrampHandler(this.ctx, o.onramp);
      const assets = o.onramp.assets.map((a) => (movva(a.asset) ? { ...a, gateway: g } : a));
      this.offers = new OfferManager(this.ctx, { pixKey: o.onramp.pixKey, assets });
    }
    if (o.offramp) {
      const assets = o.offramp.assets.map((a) => (movva(a.asset) ? { ...a, value: g } : a));
      this.offramp = new OfframpHandler(this.ctx, { ...o.offramp, assets });
    }
  }

  private wallNow(): bigint {
    return this.o.wallClock ? this.o.wallClock() : BigInt(Math.floor(Date.now() / 1000));
  }

  async tick(): Promise<void> {
    const started = Date.now();
    const { metrics } = this;
    try {
      const { head, events } = await this.events.poll();
      if (this.events.reorgs > this.reorgsSeen) {
        metrics.inc('mova_lp_reorgs_total', {}, this.events.reorgs - this.reorgsSeen);
        this.ctx.log.warn(`reorg detected under block ${head.number}; rescanned`);
        this.reorgsSeen = this.events.reorgs;
      }
      this.onramp?.onEvents(events);
      this.offramp?.onEvents(events);

      const confirmedBlock = head.number - BigInt(this.o.confirmations) + 1n;
      const view: TickView = {
        head, confirmedBlock: confirmedBlock < 0n ? 0n : confirmedBlock, chainNow: head.timestamp, wallNow: this.wallNow(),
      };
      try {
        const c = await this.o.chain.credit();
        this.credit = { capCents: c.capCents, availableCents: c.availableCents };
        metrics.set('mova_lp_credit_cap_cents', Number(c.capCents));
        metrics.set('mova_lp_credit_available_cents', Number(c.availableCents));
      } catch (e) {
        metrics.inc('mova_lp_tick_errors_total', { stage: 'credit' });
        this.ctx.log.error(`reading credit: ${errorText(e)}`);
      }

      const gateway = async (stage: 'begin' | 'tick') => {
        if (!this.gateway) return;
        try {
          await (stage === 'begin' ? this.gateway.begin(view) : this.gateway.tick(view));
        } catch (e) {
          metrics.inc('mova_lp_tick_errors_total', { stage: 'gateway' });
          this.ctx.log.error(`gateway: ${redact(errorText(e), this.o.redactValues)}`);
        }
      };
      await gateway('begin');
      if (this.offramp) await this.offramp.tick(view);
      if (this.onramp) await this.onramp.tick(view);
      if (this.offers) await this.offers.tick(view);
      await gateway('tick');
      if (this.rewards) {
        try {
          await this.rewards.tick(view);
        } catch (e) {
          metrics.inc('mova_lp_tick_errors_total', { stage: 'rewards' });
          this.ctx.log.error(`rewards: ${redact(errorText(e), this.o.redactValues)}`);
        }
      }

      this.gauges();
      this.maybeCompact(view);
      metrics.set('mova_lp_chain_head_block', Number(head.number));
      metrics.set('mova_lp_indexed_block', Number(this.events.indexedBlock));
      metrics.set('mova_lp_last_tick_timestamp_seconds', Math.floor(Date.now() / 1000));
      this.ready = true;
      metrics.set('mova_lp_ready', 1);
      this.lastTick = {
        at: new Date().toISOString(), head: head.number, indexed: this.events.indexedBlock, durationMs: Date.now() - started,
      };
    } catch (e) {
      metrics.inc('mova_lp_tick_errors_total', { stage: 'tick' });
      const msg = redact(errorText(e), this.o.redactValues);
      this.ctx.log.error(`tick failed: ${msg}`);
      this.lastTick = {
        at: new Date().toISOString(), head: this.lastTick?.head ?? 0n, indexed: this.events.indexedBlock,
        durationMs: Date.now() - started, error: msg,
      };
    } finally {
      metrics.set('mova_lp_tick_duration_seconds', (Date.now() - started) / 1000);
    }
  }

  /**
   * Between handlers, never inside one: nothing is mid-way through an intent when the snapshot is taken.
   * A failure leaves the old journal in place (journal.ts) and is only counted.
   */
  private maybeCompact(view: TickView): void {
    const limit = this.o.compactJournalAtBytes;
    const bytes = this.store.journalBytes();
    if (limit === undefined || bytes === undefined || bytes <= limit) return;
    try {
      if (this.store.compact({ now: view.wallNow, drainedOffers: this.offers?.drainedOffers() })) {
        this.metrics.inc('mova_lp_journal_compactions_total');
        this.ctx.log.info(`journal compacted from ${bytes} to ${this.store.journalBytes()} bytes`);
      }
    } catch (e) {
      this.metrics.inc('mova_lp_tick_errors_total', { stage: 'compact' });
      this.ctx.log.error(`journal compaction failed, the journal is unchanged: ${errorText(e)}`);
    }
  }

  private gauges(): void {
    let held = 0;
    let disputes = 0;
    for (const o of this.store.orders.values()) if (o.hold && o.done === undefined) held++;
    for (const s of this.store.sales.values()) {
      if (s.hold && s.done === undefined) held++;
      if (s.disputedTx && s.done === undefined) disputes++;
    }
    disputes += this.metrics.get('mova_lp_onramp_orders', { state: 'DISPUTED' });
    this.metrics.set('mova_lp_held', held);
    this.metrics.set('mova_lp_disputes_open', disputes);
    this.metrics.set('mova_lp_payments_unresolved', this.store.unresolvedPayments());
    this.metrics.set('mova_lp_journal_records', this.store.records);
    this.metrics.set('mova_lp_journal_bytes', this.store.journalBytes() ?? 0);
    this.ctx.caps?.gauges(this.wallNow());
  }

  /** Run ticks until `stop()`. */
  run(): void {
    const pollMs = this.o.pollMs ?? 5_000;
    const loop = async () => {
      if (this.stopping) return;
      this.wakeAgain = false;
      this.inflight = this.tick();
      await this.inflight;
      this.inflight = undefined;
      if (!this.stopping) this.timer = setTimeout(() => void loop(), this.wakeAgain ? 0 : pollMs);
    };
    this.loop = loop;
    void loop();
  }

  /**
   * Tick as soon as possible - now if idle, right after the tick in flight if not - without ever running
   * two at once. For a webhook: it shortens the wait, and changes nothing a tick decides. No-op unless `run()`.
   */
  wake(): void {
    if (this.stopping || !this.loop) return;
    if (this.inflight) {
      this.wakeAgain = true;
      return;
    }
    if (this.timer) clearTimeout(this.timer);
    const loop = this.loop;
    this.timer = setTimeout(() => void loop(), 0);
  }

  /** Finish the tick in flight, then stop and close the journal. */
  async stop(): Promise<void> {
    this.stopping = true;
    if (this.timer) clearTimeout(this.timer);
    if (this.inflight) await this.inflight;
    this.metrics.set('mova_lp_up', 0);
    this.store.close();
  }

  /**
   * What an operator needs to see, and nothing a stranger scraping it should: no PIX keys, salts,
   * boleto lines, payer documents or bank ids - only on-chain ids, states and reasons. With caps
   * configured it also carries the cap ledger's payer HASHES and their totals (caps.ts): the LP's own
   * view of its limits, which is why `/status` belongs on the private port.
   */
  status(): Record<string, unknown> {
    const orders = [...this.store.orders.values()].filter((o) => o.done === undefined).map((o) => ({
      orderId: o.orderId, offerId: o.offerId, paid: !!o.payment, released: o.releasedTx ?? null,
      boleto: o.boleto ? { issued: !!o.boleto.issuedTx, cancelled: !!o.boleto.cancelled } : null,
      refund: o.refund?.result?.status ?? (o.refund ? 'UNRESOLVED' : null), hold: o.hold ?? null,
      // Which cap rule refused it, so support can answer "why did nothing happen"; never whose cap it was.
      capped: o.cap?.refused?.period ?? null,
    }));
    const sales = [...this.store.sales.values()].filter((s) => s.done === undefined && s.seenBlock > 0n).map((s) => ({
      saleId: s.saleId, payeeKnown: !!s.payee, claims: s.claims.length,
      payment: s.pay ? (s.pay.result?.status ?? 'UNRESOLVED') : null, settled: s.settledTx ?? null,
      disputed: s.disputedTx ?? null, hold: s.hold ?? null,
      skipped: this.offramp?.skipped.get(s.saleId.toLowerCase()) ?? null,
    }));
    return {
      ready: this.ready,
      account: this.o.chain.account,
      chainId: this.o.chain.chainId,
      lastTick: this.lastTick ?? null,
      credit: this.credit ?? null,
      unresolvedPayments: this.store.unresolvedPayments(),
      onramp: this.onramp ? {
        escrow: this.o.onramp!.escrow,
        assets: [...(this.offers?.status.values() ?? [])],
        orders,
        unreconciledCredits: this.onramp.unreconciled.length,
      } : null,
      offramp: this.offramp ? { escrow: this.o.offramp!.escrow, sales } : null,
      gateway: this.gateway ? this.gateway.status() : null,
      rewards: this.rewards ? this.rewards.status() : null,
      // Only on the private operations port: it carries payer hashes and their totals, which is how an
      // operator reads and sets a tier. Nothing here names a document, a key, an order or an address.
      caps: this.ctx.caps ? this.ctx.caps.status(this.wallNow()) : null,
    };
  }
}
