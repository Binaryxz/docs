/**
 * zkTLS proofs of the LP's own bank payments: how PIX and boleto settle, on both ramps.
 *
 * ## Why bank rails are proven this way, and only this way
 *
 * The escrows settle a PIX or boleto payment only through a verifier that proves the bank session
 * itself (`IAttestorVerifier.provesBankSession`): `FiatEscrow.postOffer` reverts `BankRailNeedsZkTls`
 * on a verifier that does not, and `OffRampEscrow.openSale` for every sale
 * (Mova's decision, 14 September 2026). A quorum of attestors can swear to a payment that never
 * happened; witnesses to a TLS session with an allowlisted bank endpoint can refuse to attest, but
 * cannot write the bank's response. So every PIX and
 * boleto proof this node submits comes from `ZkTlsProver`, for `ReclaimZkTlsVerifier`.
 *
 * ## Which payment, from which page
 *
 * On both ramps it is the LP's bank that shows the payment, so the LP proves it:
 *
 *  - on-ramp, the credit it RECEIVED: a PIX to its key (`pix-received`), or the boleto it registered,
 *    paid (`boleto-received`);
 *  - off-ramp, the payment it MADE: a PIX to the seller's key (`pix-sent`), or the seller's bill
 *    (`boleto-paid`).
 *
 * Each is a different page at the bank, so a different provider template, allowlisted on the
 * verifier with its own rail mask (reclaim.ts in @mova/ramp, `ReceiptKind`). The request names the
 * leg and the rail and the session opens that page. The proof is bound to the order id on the
 * on-ramp and to the sale id on the off-ramp - the id each escrow hands `verifyPayment` - as the
 * claim's `contextMessage`, which the witnesses sign: re-pointed at anything else it verifies nowhere.
 *
 * ## The session is the LP's plugin; the one here is a stand-in, and says so
 *
 * A zkTLS session is a TLS connection to the LP's bank, logged in as the LP, observed by Reclaim's
 * witnesses. Three things make one and none of them can live in this repository: a Reclaim
 * application credential; a provider template per bank page that captures all six fields the
 * verifier reads from what the bank writes (a bank page shows neither a salted payee commitment nor
 * `payerRef`, so a real template needs Reclaim's hashed redactions - the gap reclaim.ts and
 * docs/security-review-phase2.md record); and the LP's own authenticated client for the page. So the
 * node defines `ZkTlsSession`, and an LP supplies one from `PROVER_MODULE` (config.ts, README "The
 * prover plugin") - typically over `ReclaimClient` in @mova/ramp, with `fromReclaimProof` turning the
 * network's proof into this form.
 *
 * `LocalWitnessSession` signs claims with local witness keys, in the exact Reclaim format, over what
 * a bank's own records show (`ReceiptSource`; `MockBank` implements it) - the amount, the time and
 * the payee come from the bank's record found by id, never from the node's claim. It lets the whole
 * path run down to ReclaimZkTlsVerifier's byte-level checks without the network, in the tests and the
 * live examples, and the entrypoint allows it only with LP_NODE_DEV=1, like MockBank: an LP holding
 * its witnesses' keys would be attesting its own payments.
 *
 * ## What the prover checks before a proof costs a transaction
 *
 * Everything `ReclaimZkTlsVerifier` and the escrow will check that can be checked off-chain: the claim
 * is `http`, its identifier is its own, it is bound to THIS order or sale, it proves the payment the
 * node's bank reported (by id) and that payment proves the order (rail, payee, amount, time), its
 * signers are the verifier's witnesses and enough of them, and its endpoint and rail are allowlisted
 * - the last two when the prover is told the verifier's configuration (`witnesses`, `endpoints`), and
 * all of it again against the chain with `preflight` (the entrypoint uses `prepareSettlement`). A
 * refusal here is a line in the log; the same refusal on-chain is a reverted settlement. And, as
 * the earlier quorum prover did, once it has proven one payment for an order it proves no other for it.
 */
import type { Address, Hex } from 'viem';
import {
  Rail, boletoPaymentContext, buildProof, canonicalStringify, claimIdentifier, encodeProof, pixPaymentContext, proofEndpoint,
  proofPayment, proofSigners, receiptKind, sortSignatures,
  type HttpProviderParams, type ReceiptKind, type ReclaimProof, type OrderTerms,
} from '@mova/ramp';
import { ProofUnavailable, whyPaymentDoesNotProve, type BoletoClaim, type PaymentProver, type PixClaim } from './attestation.js';
import { bankTxIdHash, type BankRail } from './bank.js';
import type { Leg } from './chain.js';

/** What the node asks a session to prove: one payment its bank reported, bound to one order or sale. */
export interface ZkTlsSessionRequest {
  /** `onramp`: a credit into the LP's account. `offramp`: a payment out of it. */
  leg: Leg;
  rail: Rail.PIX | Rail.BOLETO;
  /** The page to open: `receiptKind(rail, leg === 'onramp' ? 'received' : 'sent')`. */
  receipt: ReceiptKind;
  /** The order id (on-ramp) or sale id (off-ramp): the claim's `contextMessage`. */
  binding: Hex;
  /** The bank's own id for the payment, as the node's bank reported it: which receipt to open. Never logged. */
  bankTxId: string;
  /** The salt that opens the payee commitment, which no bank page shows. */
  salt: Hex;
  payerRef: Hex;
}

/**
 * A zkTLS session at the LP's bank. Returns the witnesses' signed claim about the receipt page, in
 * the on-chain form (`fromReclaimProof` converts the network's). It need not sort signatures, and it
 * may throw whatever stopped it: the prover reports it and the node retries next tick.
 */
export interface ZkTlsSession {
  prove(req: ZkTlsSessionRequest): Promise<ReclaimProof>;
}

/** A payment as the bank's own record shows it: what a receipt page's template captures. */
export interface BankReceipt {
  bankTxId: string;
  amountCents: bigint;
  /** Settlement time, unix seconds, the bank's clock. */
  paidAt: bigint;
  /** PIX: the key credited - the LP's own on a received payment, the payee's on a sent one. */
  pixKey?: string;
  /** Boleto: the line or barcode of the document paid. */
  boletoLine?: string;
}

/** Where `LocalWitnessSession` reads the facts a witness would see on the page. `MockBank` is one. */
export interface ReceiptSource {
  receipt(leg: Leg, rail: BankRail, bankTxId: string): Promise<BankReceipt | undefined>;
}

/**
 * A stand-in for Reclaim's witness network, for development and tests only (see the header).
 *
 * It looks the payment up in `receipts` by the bank's id, as a template would read the page for that
 * id, and signs what the record says - an id the bank does not know is refused, and a node that
 * recorded another amount or time gets the bank's. The template is the page's (`templates`), so the
 * verifier must allowlist those templates' hashes for the claims to settle.
 */
export class LocalWitnessSession implements ZkTlsSession {
  constructor(private readonly o: {
    /** Read on every proof, as a network whose witnesses come and go: keys removed from the array stop signing. */
    witnessKeys: readonly Hex[];
    receipts: ReceiptSource;
    templates: Record<ReceiptKind, HttpProviderParams>;
    /** The claim's `owner`: the address that asked for the session. Default: the zero address. */
    owner?: Address;
    /** The claim's timestamp, unix seconds. Default: wall time. */
    now?: () => bigint;
  }) {}

  async prove(req: ZkTlsSessionRequest): Promise<ReclaimProof> {
    const rail: BankRail = req.rail === Rail.PIX ? 'PIX' : 'BOLETO';
    const r = await this.o.receipts.receipt(req.leg, rail, req.bankTxId);
    if (!r) throw new ProofUnavailable(`the bank shows no settled ${rail} ${req.leg === 'onramp' ? 'credit' : 'payment'} under that id`);
    const common = {
      orderId: req.binding, bankTxId: bankTxIdHash(r.bankTxId), salt: req.salt, payerRef: req.payerRef,
      amountBrlCents: r.amountCents, paidAt: r.paidAt,
    };
    let payment;
    if (req.rail === Rail.PIX) {
      if (!r.pixKey) throw new ProofUnavailable('the bank\'s receipt shows no PIX key: nothing to open the payee commitment with');
      payment = pixPaymentContext({ ...common, pixKey: r.pixKey });
    } else {
      if (!r.boletoLine) throw new ProofUnavailable('the bank\'s receipt shows no barcode: nothing to open the payee commitment with');
      payment = boletoPaymentContext({ ...common, line: r.boletoLine });
    }
    const keys = [...this.o.witnessKeys];
    if (keys.length === 0) throw new ProofUnavailable('no witness answered');
    return buildProof({
      params: this.o.templates[req.receipt], payment, witnessKeys: keys,
      owner: this.o.owner ?? '0x0000000000000000000000000000000000000000',
      timestampS: Number(this.o.now ? this.o.now() : BigInt(Math.floor(Date.now() / 1000))),
    });
  }
}

/** An endpoint as the verifier allowlists it: `endpointUrlPrefix(providerHash)` and `endpointRails(providerHash)`. */
export interface ZkTlsEndpoint {
  providerHash: Hex;
  urlPrefix: string;
  rails: readonly Rail[];
}

export interface ZkTlsProverOptions {
  /** The verifier's witness set and threshold. With it, a claim signed by others, or by too few, is refused here. */
  witnesses?: { addresses: readonly Address[]; threshold: number };
  /** The verifier's endpoint allowlist. With it, a claim about another page, or a rail its page may not attest, is refused here. */
  endpoints?: readonly ZkTlsEndpoint[];
  /** Last, before the proof is handed back: e.g. `prepareSettlement` against the verifier on-chain. Throw to refuse. */
  preflight?: (proof: ReclaimProof) => Promise<void>;
}

/** How many orders' proven payments a prover remembers; the oldest is forgotten first. */
const REMEMBERED_ORDERS = 10_000;

/**
 * `PaymentProver` for a `ReclaimZkTlsVerifier`: PIX and boleto, on both ramps, from a `ZkTlsSession`.
 * See the header for what it checks.
 */
export class ZkTlsProver implements PaymentProver {
  readonly rails: readonly Rail[] = [Rail.PIX, Rail.BOLETO];
  /** Per order or sale, the bank id (hashed) this prover has proven. */
  private readonly proven = new Map<string, Hex>();

  constructor(
    readonly verifier: Address,
    private readonly session: ZkTlsSession,
    private readonly o: ZkTlsProverOptions = {},
  ) {
    const w = o.witnesses;
    if (w && (w.threshold < 1 || w.threshold > new Set(w.addresses.map((a) => a.toLowerCase())).size)) {
      throw new Error(`threshold ${w.threshold} cannot be met by ${w.addresses.length} witnesses`);
    }
  }

  provePix(terms: OrderTerms, claim: PixClaim): Promise<Hex> {
    return this.prove(terms, Rail.PIX, claim);
  }

  proveBoleto(terms: OrderTerms, claim: BoletoClaim): Promise<Hex> {
    return this.prove(terms, Rail.BOLETO, claim);
  }

  private async prove(terms: OrderTerms, rail: Rail.PIX | Rail.BOLETO, claim: PixClaim | BoletoClaim): Promise<Hex> {
    if (!claim.leg) {
      throw new ProofUnavailable('a zkTLS proof is of a receipt page: the claim must say whether the LP received the payment (onramp) or made it (offramp)');
    }
    const order = terms.orderId.toLowerCase();
    const paid = bankTxIdHash(claim.bankTxId);
    const prior = this.proven.get(order);
    if (prior !== undefined && prior !== paid) {
      throw new ProofUnavailable(`asked to prove a different ${Rail[rail]} payment than the one this node already proved for this order; it does not submit a second`);
    }
    const request: ZkTlsSessionRequest = {
      leg: claim.leg, rail, receipt: receiptKind(rail, claim.leg === 'onramp' ? 'received' : 'sent'), binding: terms.orderId,
      bankTxId: claim.bankTxId, salt: claim.salt, payerRef: claim.payerRef,
    };
    const proof = await sortSignatures(await this.session.prove(request));
    const why = await this.refusal(terms, rail, paid, proof);
    if (why) throw new ProofUnavailable(`the zkTLS claim does not settle this: ${why}`);
    await this.o.preflight?.(proof);
    this.proven.delete(order);
    this.proven.set(order, paid);
    if (this.proven.size > REMEMBERED_ORDERS) this.proven.delete(this.proven.keys().next().value as string);
    return encodeProof(proof);
  }

  /** Why the verifier or the escrow would refuse this claim for this order, or undefined. */
  private async refusal(terms: OrderTerms, rail: Rail, paid: Hex, proof: ReclaimProof): Promise<string | undefined> {
    const { claimInfo, signedClaim } = proof;
    if (claimInfo.provider !== 'http') return `provider "${claimInfo.provider}"; only http claims settle`;
    if (claimIdentifier(claimInfo).toLowerCase() !== signedClaim.claim.identifier.toLowerCase()) {
      return 'its identifier is not its own claim\'s (IdentifierMismatch)';
    }
    let payment;
    let endpoint;
    try {
      if (canonicalStringify(JSON.parse(claimInfo.context)) !== claimInfo.context) return 'its context is not the canonical form witnesses sign';
      payment = proofPayment(proof);
      endpoint = proofEndpoint(proof);
    } catch (e) {
      return `its context cannot be read: ${(e as Error).message}`;
    }
    if (payment.orderId.toLowerCase() !== terms.orderId.toLowerCase()) return 'it is bound to another order or sale (OrderMismatch)';
    if (payment.bankTxId.toLowerCase() !== paid.toLowerCase()) return 'it attests another payment than the one the node\'s bank reported';
    const notProving = whyPaymentDoesNotProve(terms, rail, payment);
    if (notProving) return `it attests ${notProving}`;

    const w = this.o.witnesses;
    if (w) {
      const known = new Set(w.addresses.map((a) => a.toLowerCase()));
      const signers = new Set((await proofSigners(proof)).map((a) => a.toLowerCase()));
      const unknown = [...signers].filter((s) => !known.has(s));
      if (unknown.length) return `signed by ${unknown.length} key(s) outside the verifier's witness set (UnknownWitness)`;
      if (signers.size < w.threshold || signedClaim.signatures.length !== signers.size) {
        return `${signers.size} distinct witness signature(s), ${w.threshold} needed (NotEnoughSignatures)`;
      }
    }
    if (this.o.endpoints) {
      const ep = this.o.endpoints.find((x) => x.providerHash.toLowerCase() === endpoint.providerHash.toLowerCase());
      if (!ep) return 'its page template is not allowlisted on the verifier (EndpointNotAllowed)';
      if (!endpoint.url.startsWith(ep.urlPrefix)) return 'its url is outside the allowlisted prefix (UrlNotAllowed)';
      if (!ep.rails.includes(payment.rail)) return `its page is not allowlisted for ${Rail[payment.rail]} (RailNotAllowedForEndpoint)`;
    }
    return undefined;
  }
}
