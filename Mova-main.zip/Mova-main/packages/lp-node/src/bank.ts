/**
 * The LP's bank, as the node sees it.
 *
 * ## Why this is an interface and a mock, not an integration
 *
 * Brazil standardised RECEIVING by PIX: the Banco Central's "API Pix" (`/v2/cob`, `/v2/pix`,
 * webhooks, devolução) is the same at every PSP, and `api-pix.ts` implements that side. It did
 * not standardise SENDING. Initiating a PIX to a key, paying a boleto, or registering one is a
 * bank-specific API with bank-specific credentials, approval flows and limits (Open Finance
 * "iniciação de pagamento" exists, but it moves money on a customer's consent through a
 * third party - not an LP paying from its own treasury). So the node defines what it needs and
 * each LP supplies an adapter for its bank. `MockBank` implements the contract in memory for
 * tests and for the live example.
 *
 * ## The contract an adapter MUST honour
 *
 * 1. **Idempotency.** Two `sendPix`/`payBoleto`/`refundIncoming` calls with the same
 *    `idempotencyKey` move money at most once, and the second returns the first's result. A bank
 *    API with an idempotency header satisfies this directly; one without must look the key up
 *    before sending (for instance in the transfer's free-text field) and document the window in
 *    which two concurrent calls could both miss. The node persists the key BEFORE calling, and on
 *    restart resolves an unacknowledged intent by `getOutgoing(key)` and, failing that, by
 *    calling again with the SAME key. An adapter that breaks this rule breaks the node's
 *    no-double-pay guarantee; nothing above it can compensate.
 * 2. **Settlement, not acceptance.** `status: 'SETTLED'` means the money reached the payee's
 *    institution (for PIX, the SPI settled and the bank returned an end-to-end id). "Accepted
 *    for processing" is `PENDING`. The node attests and proves only SETTLED payments, because an
 *    attestor would otherwise be asked to sign a transfer that may yet fail.
 * 3. **Bank identifiers are the bank's.** `bankTxId` is the PIX end-to-end id (`E...`) or a
 *    boleto payment's authentication code, never something the node generated: the escrows'
 *    replay protection is keyed on it (IAttestorVerifier, guarantee 1).
 *    With Open Finance attestors it is the institution's `transactionId` instead, because that is the only id Open
 *    Finance account data shows (packages/attestor, SR2-33): whatever the scheme, it must be the one the LP's attestors
 *    sign, and one scheme per rail across all of the LP's verifiers.
 * 4. **Times are settlement times**, unix seconds, from the bank's clock.
 */
import { randomBytes } from 'node:crypto';
import { keccak256, toBytes } from 'viem';
import { buildBankBoleto, normalizePixKey, parseBoleto } from '@mova/ramp';
import { buildDynamicPixBrCode } from '@mova/wallet';
import type { Leg } from './chain.js';
import type { CobLocationAnswer, MockPixQrSite } from './pix-qr-mock.js';
import type { BankReceipt } from './zktls.js';

export type BankRail = 'PIX' | 'BOLETO';

export interface IncomingPayment {
  rail: BankRail;
  /** The institution's id for the payment, in the scheme the LP's attestors sign (PIX end-to-end id, or an Open Finance `transactionId`), or the boleto payment's authentication code. */
  bankTxId: string;
  amountCents: bigint;
  /** Settlement time, unix seconds. */
  paidAt: bigint;
  /** PIX: the key credited, as the bank reports it. */
  creditedKey?: string;
  /** PIX: the txid the payer's QR code carried (BR Code field 62-05, or the cob's txid). */
  txid?: string;
  /** BOLETO: the line or barcode of the document paid. */
  boletoLine?: string;
  /** The payer's document (CPF/CNPJ) or account reference, for payerRef and refunds. */
  payerId?: string;
}

export type OutgoingStatus = 'SETTLED' | 'PENDING' | 'FAILED';

export interface OutgoingPaymentResult {
  idempotencyKey: string;
  status: OutgoingStatus;
  /** PIX end-to-end id or boleto authentication code; present once SETTLED. */
  bankTxId?: string;
  amountCents?: bigint;
  paidAt?: bigint;
  /** The key credited (PIX), as the bank reports it. */
  creditedKey?: string;
  failureReason?: string;
}

export interface RegisteredBoleto {
  /** The bank's own reference for the registered document ("nosso número"). */
  bankRef: string;
  /** The typed line (linha digitável) the bank issued. */
  line: string;
}

/** API Pix `CobStatus` (OpenAPI 2.10.0 enum). */
export type PixChargeStatus = 'ATIVA' | 'CONCLUIDA' | 'REMOVIDA_PELO_USUARIO_RECEBEDOR' | 'REMOVIDA_PELO_PSP';

/** An API Pix immediate charge (`cob`) at the LP's PSP, as the node reads it. */
export interface PixCharge {
  /** 26-35 letters and digits. */
  txid: string;
  status: PixChargeStatus;
  revisao: number;
  amountCents: bigint;
  /** False when the payer may change the amount (`valor.modalidadeAlteracao` 1): never acceptable for an order. */
  amountFixed: boolean;
  /** The key the charge pays, as the PSP reports it. */
  pixKey: string;
  /** `calendario.criacao`, unix seconds, the PSP's clock. */
  createdAt: bigint;
  /** `calendario.expiracao`: seconds from creation. */
  expiresInSeconds: number;
  /** `createdAt + expiresInSeconds`. */
  expiresAt: bigint;
  /** Without protocol prefix. A capability URL: served to the order's taker only, never logged. */
  location?: string;
  /** The dynamic BR Code whose location it is. */
  pixCopiaECola?: string;
}

export interface BankAdapter {
  /** Credits received with settlement time in [since, until]. */
  listIncoming(q: { since: bigint; until?: bigint }): Promise<IncomingPayment[]>;
  /**
   * One credit by the bank's own id (API Pix `GET /pix/{e2eid}`), or undefined if the bank has none. How a
   * webhook hint is turned into payment facts: from the bank, never from the webhook's body.
   */
  getIncoming?(bankTxId: string): Promise<IncomingPayment | undefined>;
  sendPix(req: { idempotencyKey: string; pixKey: string; amountCents: bigint; description?: string }): Promise<OutgoingPaymentResult>;
  payBoleto(req: { idempotencyKey: string; line: string; amountCents: bigint }): Promise<OutgoingPaymentResult>;
  /** The outcome of an earlier send by its idempotency key; undefined if the bank never saw it. */
  getOutgoing(idempotencyKey: string): Promise<OutgoingPaymentResult | undefined>;

  /** On-ramp boleto orders. Omit if the LP does not quote BOLETO. Idempotent by key. */
  registerBoleto?(req: { idempotencyKey: string; amountCents: bigint; dueDate: string; reference: string }): Promise<RegisteredBoleto>;
  /** "Baixa": a boleto whose order did not release must stop being payable. */
  cancelBoleto?(bankRef: string): Promise<void>;
  /**
   * API Pix immediate charges, for `onramp.pixCharge: "cob"`: `PUT /cob/{txid}`, `GET /cob/{txid}`, and `PATCH
   * /cob/{txid}` to status `REMOVIDA_PELO_USUARIO_RECEBEDOR`. `createCharge` under a txid the PSP already holds
   * returns that charge (the spec's PUT is idempotent); `getCharge` is undefined when the PSP has none;
   * `cancelCharge` removes an `ATIVA` charge and returns the status the charge ends in (a `CONCLUIDA` one was paid
   * and stays so), undefined when there is no such charge. `ApiPixReceiver` implements all three.
   */
  createCharge?(req: { txid: string; amountCents: bigint; pixKey: string; expiresInSeconds: number }): Promise<PixCharge>;
  getCharge?(txid: string): Promise<PixCharge | undefined>;
  cancelCharge?(txid: string): Promise<PixChargeStatus | undefined>;
  /** PIX devolução of a credit, to its original payer only. Idempotent by key. */
  refundIncoming?(req: { idempotencyKey: string; bankTxId: string; amountCents: bigint; reason: string }): Promise<OutgoingPaymentResult>;
  /** Available balance in centavos, if the bank exposes it. */
  balanceCents?(): Promise<bigint>;
  /**
   * The bank pays a boleto only with its due date (Banco Inter's `POST /pagamento` requires `dataVencimento`). A
   * collection ("arrecadação") line carries none, so such a bank cannot pay one, and the off-ramp does not claim a
   * sale whose bill has no due date (`boleto_no_due_date`) rather than claim, fail to pay, and give the claim back.
   */
  readonly boletoNeedsDueDate?: boolean;
}

/** The on-chain `bankTxId`: the bank identifier, hashed (IAttestorVerifier.Payment). */
export const bankTxIdHash = (bankTxId: string) => keccak256(toBytes(bankTxId));

/*//////////////////////////////////////////////////////////////
                               MOCK BANK
//////////////////////////////////////////////////////////////*/

interface OutgoingRecord {
  idempotencyKey: string;
  kind: 'PIX' | 'BOLETO' | 'REFUND';
  destination: string;
  amountCents: bigint;
  result: OutgoingPaymentResult;
}

/**
 * A bank in memory, honouring the adapter contract, with the failure modes the node must survive
 * available on demand: a send that fails, one left pending, and one that goes through and then
 * loses the response - the case idempotency keys exist for.
 */
export class MockBank implements BankAdapter {
  readonly incoming: IncomingPayment[] = [];
  readonly outgoing: OutgoingRecord[] = [];
  readonly boletos = new Map<string, { line: string; barcode: string; amountCents: bigint; status: 'OPEN' | 'PAID' | 'CANCELLED' }>();
  /** API Pix immediate charges, by txid. Mutable, so a test can make the PSP say something else. */
  readonly charges = new Map<string, PixCharge>();
  /** Charge calls that reached the bank, including repeats it absorbed. */
  readonly chargeCalls = { create: 0, get: 0, cancel: 0 };
  /** Calls that reached the bank, including duplicates it absorbed. */
  sendCalls = 0;
  private seq = 0;
  private balance: bigint;
  private faults: ('fail' | 'pending' | 'lose-response')[] = [];
  private chargeFaults: 'lose-response'[] = [];

  readonly boletoNeedsDueDate: boolean;

  /**
   * `qrSite`: the PSP's dynamic QR site; each charge's location is served there, signed. Without it a charge still has
   * a location and a code, and nothing answers at it. `receiver`: the merchant name and city in the dynamic codes.
   * `boletoNeedsDueDate`: pay a boleto only if its line carries a due date, as Banco Inter does.
   */
  constructor(private readonly o: {
    now?: () => bigint; ispb?: string; balanceCents?: bigint; bankCode?: string;
    qrSite?: MockPixQrSite; receiver?: { name: string; city: string }; boletoNeedsDueDate?: boolean;
  } = {}) {
    this.balance = o.balanceCents ?? 1_000_000_000n;
    this.boletoNeedsDueDate = o.boletoNeedsDueDate ?? false;
  }

  private now(): bigint {
    return this.o.now ? this.o.now() : BigInt(Math.floor(Date.now() / 1000));
  }

  private e2e(): string {
    // E + ISPB (8) + yyyyMMddHHmm (12) + 11 alphanumerics: 32 characters, as the SPI assigns them.
    const d = new Date(Number(this.now()) * 1000).toISOString().replace(/\D/g, '').slice(0, 12);
    return `E${this.o.ispb ?? '99999999'}${d}${(++this.seq).toString(36).toUpperCase().padStart(11, '0')}`;
  }

  /*------------------------- the outside world -------------------------*/

  /** Someone pays the LP by PIX. */
  receivePix(p: { amountCents: bigint; creditedKey: string; txid?: string; payerId?: string; paidAt?: bigint }): IncomingPayment {
    const credit: IncomingPayment = {
      rail: 'PIX', bankTxId: this.e2e(), amountCents: p.amountCents, paidAt: p.paidAt ?? this.now(),
      creditedKey: p.creditedKey, txid: p.txid, payerId: p.payerId ?? '52998224725',
    };
    this.incoming.push(credit);
    this.balance += p.amountCents;
    return credit;
  }

  /** Someone pays a boleto this bank registered for the LP. */
  payRegisteredBoleto(line: string, p: { payerId?: string; paidAt?: bigint; amountCents?: bigint } = {}): IncomingPayment {
    const barcode = parseBoleto(line).barcode;
    const b = [...this.boletos.values()].find((x) => x.barcode === barcode);
    if (!b) throw new Error('no such boleto registered here');
    if (b.status !== 'OPEN') throw new Error(`boleto is ${b.status}`);
    b.status = 'PAID';
    const credit: IncomingPayment = {
      rail: 'BOLETO', bankTxId: `AUTH${(++this.seq).toString().padStart(12, '0')}`,
      amountCents: p.amountCents ?? b.amountCents, paidAt: p.paidAt ?? this.now(), boletoLine: b.line,
      payerId: p.payerId ?? '52998224725',
    };
    this.incoming.push(credit);
    this.balance += credit.amountCents;
    return credit;
  }

  /** Someone pays a charge's dynamic BR Code: a credit with the charge's txid, key and amount, and the charge CONCLUIDA. */
  payCharge(txid: string, p: { payerId?: string; paidAt?: bigint } = {}): IncomingPayment {
    const c = this.charges.get(txid);
    if (!c) throw new Error('no such charge');
    if (c.status !== 'ATIVA') throw new Error(`charge is ${c.status}`);
    const paidAt = p.paidAt ?? this.now();
    if (paidAt > c.expiresAt) throw new Error('charge expired');
    c.status = 'CONCLUIDA';
    return this.receivePix({ amountCents: c.amountCents, creditedKey: c.pixKey, txid: c.txid, payerId: p.payerId, paidAt });
  }

  /*--------------------------- fault injection --------------------------*/

  /** The next charge is created, and then the connection drops before the response. */
  loseNextChargeResponse(): void { this.chargeFaults.push('lose-response'); }

  /** The next send is refused outright. */
  failNextSend(): void { this.faults.push('fail'); }
  /** The next send is accepted but stays PENDING until `settlePending`. */
  holdNextSend(): void { this.faults.push('pending'); }
  /** The next send goes through, and then the connection drops before the response. */
  loseNextResponse(): void { this.faults.push('lose-response'); }

  settlePending(): void {
    for (const o of this.outgoing) {
      if (o.result.status === 'PENDING') {
        o.result = { ...o.result, status: 'SETTLED', bankTxId: this.e2e(), paidAt: this.now() };
      }
    }
  }

  /*-------------------------------- adapter ------------------------------*/

  async listIncoming(q: { since: bigint; until?: bigint }): Promise<IncomingPayment[]> {
    return this.incoming.filter((p) => p.paidAt >= q.since && (q.until === undefined || p.paidAt <= q.until))
      .map((p) => ({ ...p }));
  }

  getIncomingCalls = 0;

  async getIncoming(bankTxId: string): Promise<IncomingPayment | undefined> {
    this.getIncomingCalls++;
    const p = this.incoming.find((x) => x.bankTxId === bankTxId);
    return p && { ...p };
  }

  async getOutgoing(idempotencyKey: string): Promise<OutgoingPaymentResult | undefined> {
    const o = this.outgoing.find((x) => x.idempotencyKey === idempotencyKey);
    return o && { ...o.result };
  }

  async sendPix(req: { idempotencyKey: string; pixKey: string; amountCents: bigint }): Promise<OutgoingPaymentResult> {
    const key = normalizePixKey(req.pixKey).key;
    return this.send(req.idempotencyKey, 'PIX', key, req.amountCents, key);
  }

  async payBoleto(req: { idempotencyKey: string; line: string; amountCents: bigint }): Promise<OutgoingPaymentResult> {
    const b = parseBoleto(req.line);
    if (b.amountCents !== undefined && b.amountCents !== 0n && b.amountCents !== req.amountCents) {
      // A bank refuses to pay a fixed-amount boleto for any other amount.
      return this.send(req.idempotencyKey, 'BOLETO', b.barcode, req.amountCents, undefined, 'amount differs from the boleto');
    }
    if (this.boletoNeedsDueDate && !b.dueDate) {
      return this.send(req.idempotencyKey, 'BOLETO', b.barcode, req.amountCents, undefined, 'the bank requires a due date and this line carries none');
    }
    return this.send(req.idempotencyKey, 'BOLETO', b.barcode, req.amountCents);
  }

  /**
   * The bank's own record of a settled payment, found by its id, as a receipt page shows it (`ReceiptSource`, zktls.ts):
   * what `LocalWitnessSession` signs. `onramp`, a credit into the account; `offramp`, a payment out of it.
   */
  async receipt(leg: Leg, rail: BankRail, bankTxId: string): Promise<BankReceipt | undefined> {
    if (leg === 'onramp') {
      const c = this.incoming.find((x) => x.bankTxId === bankTxId && x.rail === rail);
      return c && { bankTxId: c.bankTxId, amountCents: c.amountCents, paidAt: c.paidAt, pixKey: c.creditedKey, boletoLine: c.boletoLine };
    }
    const o = this.outgoing.find((x) => x.kind === rail && x.result.status === 'SETTLED' && x.result.bankTxId === bankTxId);
    if (!o || o.result.paidAt === undefined) return undefined;
    return {
      bankTxId, amountCents: o.result.amountCents ?? o.amountCents, paidAt: o.result.paidAt,
      ...(rail === 'PIX' ? { pixKey: o.destination } : { boletoLine: o.destination }),
    };
  }

  async refundIncoming(req: { idempotencyKey: string; bankTxId: string; amountCents: bigint }): Promise<OutgoingPaymentResult> {
    const credit = this.incoming.find((p) => p.bankTxId === req.bankTxId);
    if (!credit) return this.send(req.idempotencyKey, 'REFUND', req.bankTxId, req.amountCents, undefined, 'no such credit');
    const refunded = this.outgoing.filter((o) => o.kind === 'REFUND' && o.destination === req.bankTxId && o.result.status !== 'FAILED')
      .reduce((a, o) => (o.idempotencyKey === req.idempotencyKey ? a : a + o.amountCents), 0n);
    if (refunded + req.amountCents > credit.amountCents) {
      return this.send(req.idempotencyKey, 'REFUND', req.bankTxId, req.amountCents, undefined, 'refund exceeds the credit');
    }
    return this.send(req.idempotencyKey, 'REFUND', req.bankTxId, req.amountCents);
  }

  async registerBoleto(req: { idempotencyKey: string; amountCents: bigint; dueDate: string }): Promise<RegisteredBoleto> {
    const existing = this.boletos.get(req.idempotencyKey);
    if (existing) return { bankRef: req.idempotencyKey, line: existing.line };
    const free = BigInt(`0x${keccak256(toBytes(req.idempotencyKey)).slice(2, 20)}`).toString().padStart(25, '0').slice(-25);
    const b = buildBankBoleto({ bankCode: this.o.bankCode ?? '341', amountCents: req.amountCents, dueDate: req.dueDate, freeField: free });
    this.boletos.set(req.idempotencyKey, { line: b.line, barcode: b.barcode, amountCents: req.amountCents, status: 'OPEN' });
    return { bankRef: req.idempotencyKey, line: b.line };
  }

  async cancelBoleto(bankRef: string): Promise<void> {
    const b = this.boletos.get(bankRef);
    if (b && b.status === 'OPEN') b.status = 'CANCELLED';
  }

  async createCharge(req: { txid: string; amountCents: bigint; pixKey: string; expiresInSeconds: number }): Promise<PixCharge> {
    this.chargeCalls.create++;
    if (!/^[a-zA-Z0-9]{26,35}$/.test(req.txid)) throw new Error('a cob txid is 26-35 letters and digits');
    const pixKey = normalizePixKey(req.pixKey).key;
    const prior = this.charges.get(req.txid);
    if (prior) {
      // A repeated PUT is the same charge; another charge under a txid already used is refused (Annex I §5.3.1).
      if (prior.amountCents !== req.amountCents || prior.pixKey !== pixKey) throw new Error('txid already used by another charge');
      return { ...prior };
    }
    if (req.amountCents <= 0n || !Number.isSafeInteger(req.expiresInSeconds) || req.expiresInSeconds <= 0) throw new Error('invalid charge');
    const createdAt = this.now();
    const location = this.o.qrSite
      ? this.o.qrSite.newLocation(() => this.cobAnswer(req.txid))
      : `pix.mockbank.example/qr/v2/${randomBytes(16).toString('hex')}`;
    const charge: PixCharge = {
      txid: req.txid, status: 'ATIVA', revisao: 0, amountCents: req.amountCents, amountFixed: true, pixKey, createdAt,
      expiresInSeconds: req.expiresInSeconds, expiresAt: createdAt + BigInt(req.expiresInSeconds), location,
      pixCopiaECola: buildDynamicPixBrCode({ location, merchantName: this.o.receiver?.name ?? 'Recebedor Mock', merchantCity: this.o.receiver?.city ?? 'Sao Paulo' }),
    };
    this.charges.set(req.txid, charge);
    if (this.chargeFaults.shift() === 'lose-response') throw new Error('socket hang up');
    return { ...charge };
  }

  async getCharge(txid: string): Promise<PixCharge | undefined> {
    this.chargeCalls.get++;
    const c = this.charges.get(txid);
    return c && { ...c };
  }

  async cancelCharge(txid: string): Promise<PixChargeStatus | undefined> {
    this.chargeCalls.cancel++;
    const c = this.charges.get(txid);
    if (!c) return undefined;
    if (c.status === 'ATIVA') {
      c.status = 'REMOVIDA_PELO_USUARIO_RECEBEDOR';
      c.revisao++;
    }
    return c.status;
  }

  /** What a charge's location serves: the API Pix `CobPayload` (Manual de Padrões 2.10.0 §2.7.1.1), or 410 once removed. */
  private cobAnswer(txid: string): CobLocationAnswer {
    const c = this.charges.get(txid);
    if (!c || c.status === 'REMOVIDA_PELO_USUARIO_RECEBEDOR' || c.status === 'REMOVIDA_PELO_PSP') return { status: 410 };
    const iso = (s: bigint) => new Date(Number(s) * 1000).toISOString();
    return {
      status: 200,
      payload: {
        calendario: { criacao: iso(c.createdAt), apresentacao: iso(this.now()), expiracao: c.expiresInSeconds },
        txid: c.txid, revisao: c.revisao, status: c.status,
        valor: { original: `${c.amountCents / 100n}.${(c.amountCents % 100n).toString().padStart(2, '0')}`, modalidadeAlteracao: c.amountFixed ? 0 : 1 },
        chave: c.pixKey,
      },
    };
  }

  async balanceCents(): Promise<bigint> {
    return this.balance;
  }

  /** How many transfers actually moved money for this key. The no-double-pay assertion. */
  moneyMovedFor(idempotencyKey: string): number {
    return this.outgoing.filter((o) => o.idempotencyKey === idempotencyKey && o.result.status !== 'FAILED').length;
  }

  private send(
    idempotencyKey: string, kind: OutgoingRecord['kind'], destination: string, amountCents: bigint,
    creditedKey?: string, refuse?: string,
  ): OutgoingPaymentResult {
    this.sendCalls++;
    const prior = this.outgoing.find((x) => x.idempotencyKey === idempotencyKey);
    if (prior) return { ...prior.result };

    const fault = this.faults.shift();
    let result: OutgoingPaymentResult;
    if (refuse || fault === 'fail') {
      result = { idempotencyKey, status: 'FAILED', failureReason: refuse ?? 'refused by the bank' };
    } else if (amountCents > this.balance) {
      result = { idempotencyKey, status: 'FAILED', failureReason: 'insufficient funds' };
    } else if (fault === 'pending') {
      result = { idempotencyKey, status: 'PENDING', amountCents, creditedKey };
      this.balance -= amountCents;
    } else {
      result = {
        idempotencyKey, status: 'SETTLED', bankTxId: this.e2e(), amountCents, paidAt: this.now(), creditedKey,
      };
      this.balance -= amountCents;
    }
    this.outgoing.push({ idempotencyKey, kind, destination, amountCents, result });
    if (fault === 'lose-response') throw new Error('socket hang up');
    return { ...result };
  }
}
