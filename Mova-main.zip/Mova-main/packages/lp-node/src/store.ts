/**
 * The node's state: journal records, folded.
 *
 * Every mutation is `record()`: append durably, THEN apply in memory. There is no other way to
 * change what the node believes it has done, so what it believes after a restart is exactly what
 * it believed before the crash, less at most a record it never acknowledged.
 *
 * What is deliberately NOT here: anything the chain already knows. Offer liquidity, order and
 * sale states, deadlines and credit are read from the contracts every tick. The journal records
 * only what the chain cannot tell a restarted node - intents and results of off-chain money
 * movement, secrets, disclosures, and which ids it was following - so the two can never
 * disagree about on-chain facts.
 *
 * ## Idempotency keys are derived, not random
 *
 * `idempotencyKey('sale-pay', ...)` is a pure function of the chain, the escrow and the sale.
 * The journal persists it before the bank call, and the derivation is a second line of defence:
 * even a node that lost its journal entirely would present the bank the same key for the same
 * sale, and a conforming bank adapter would refuse to pay twice. One key per sale, ever, is also
 * the policy - see offramp.ts for why a sale is never paid under a second key.
 */
import { encodeAbiParameters, keccak256, type Address, type Hex } from 'viem';
import type { BankRail, IncomingPayment, OutgoingPaymentResult } from './bank.js';
import { CAP_RETENTION_DAYS, capDay, capMonth, dayMinus, type CapCount, type CapPeriod } from './caps.js';
import type { EvidenceKind } from './evidence.js';
import type { Journal } from './journal.js';

export type Payee =
  | { kind: 'pix'; pixKey: string; salt: Hex }
  | { kind: 'boleto'; line: string; salt: Hex };

type At = { at: number };

export type LpRecord = At & (
  | { t: 'cursor'; block: bigint; hash: Hex }
  | { t: 'offer.salt'; asset: Address; salt: Hex; commitment: Hex }
  | { t: 'offer.mine'; offerId: Hex; asset?: Address; tx?: Hex }
  | { t: 'order.seen'; orderId: Hex; offerId: Hex; block: bigint }
  | { t: 'order.boleto.intent'; orderId: Hex; idempotencyKey: string; salt: Hex }
  | { t: 'order.boleto.registered'; orderId: Hex; bankRef: string; line: string; commitment: Hex }
  | { t: 'order.boleto.issued'; orderId: Hex; tx: Hex }
  | { t: 'order.boleto.cancelled'; orderId: Hex }
  /** An API Pix charge for the order (`pixCharge: "cob"`): its txid, fsynced before the PSP is asked for it. */
  | { t: 'order.cob.intent'; orderId: Hex; txid: string }
  | { t: 'order.cob.created'; orderId: Hex; location: string; pixCopiaECola: string; expiresAt: bigint; amountCents: bigint; revisao: number }
  /** The charge takes no more payments: the status it ended in (removed by the node, found paid or removed, or `NONE`). */
  | { t: 'order.cob.closed'; orderId: Hex; status: string }
  | { t: 'order.payment'; orderId: Hex; payment: IncomingPayment }
  | { t: 'order.released'; orderId: Hex; tx: Hex }
  | { t: 'order.refund.intent'; orderId: Hex; idempotencyKey: string }
  | { t: 'order.refund.result'; orderId: Hex; result: OutgoingPaymentResult }
  | { t: 'order.hold'; orderId: Hex; reason: string }
  | { t: 'order.done'; orderId: Hex; state: number }
  | { t: 'sale.seen'; saleId: Hex; block: bigint }
  | { t: 'sale.payee'; saleId: Hex; payee: Payee }
  | { t: 'sale.claimed'; saleId: Hex; tx: Hex }
  | { t: 'sale.pay.intent'; saleId: Hex; idempotencyKey: string; rail: BankRail; amountCents: bigint; claimedAt: bigint }
  | { t: 'sale.pay.result'; saleId: Hex; result: OutgoingPaymentResult }
  | { t: 'sale.settled'; saleId: Hex; tx: Hex }
  | { t: 'sale.abandoned'; saleId: Hex; tx: Hex; reason: string }
  | { t: 'sale.disputed'; saleId: Hex; tx: Hex; reason: string }
  | { t: 'sale.hold'; saleId: Hex; reason: string }
  | { t: 'sale.done'; saleId: Hex; state: number }
  | { t: 'gateway.intent'; opId: Hex; op: GatewayOpKind; amountIn: bigint; minOut: bigint; need: bigint; nonce: number; wallAt: bigint }
  | { t: 'gateway.sent'; opId: Hex; tx: Hex; block?: bigint }
  /** Before a replacement is broadcast: until its `gateway.sent` (or `gateway.replace.skipped`), its hash is unknown. */
  | { t: 'gateway.replacing'; opId: Hex; from: Hex }
  | { t: 'gateway.replace.skipped'; opId: Hex; block: bigint; why: 'capped' | 'gone' }
  | { t: 'gateway.result'; opId: Hex; outcome: GatewayOutcome; amountOut?: bigint; block?: bigint }
  /** Dispute evidence (evidence.ts): a salted commitment fixed, a case found, a commitment filed. */
  | { t: 'evidence.prepared'; leg: 'onramp' | 'offramp'; id: Hex; kind: EvidenceKind; digest: Hex; salt: Hex }
  | { t: 'evidence.case'; leg: 'onramp' | 'offramp'; id: Hex; caseId: string }
  | { t: 'evidence.submitted'; leg: 'onramp' | 'offramp'; id: Hex; digest: Hex }
  /**
   * Per-payer caps (caps.ts). The ledger is `(payerRef, Brasília day, centavos)` and nothing else - no
   * order, no sale, no address, no key - so it correlates one person's payments through their hashed
   * bank identity and through nothing else. `cap.uncount` gives an allowance back when the money did.
   */
  | { t: 'cap.count'; payer: Hex; day: string; cents: bigint }
  | { t: 'cap.uncount'; payer: Hex; day: string; cents: bigint }
  /** The cap decision for one order, so a restart does not decide it again with a day that has since rolled. */
  | { t: 'order.cap'; orderId: Hex; decision: 'counted' | 'refused'; day: string; cents?: bigint; period?: CapPeriod }
  | { t: 'order.cap.uncounted'; orderId: Hex }
  | { t: 'sale.cap'; saleId: Hex; day: string; cents: bigint }
  | { t: 'sale.cap.uncounted'; saleId: Hex }
  /** Everything a restart needs, in one record: what `compact` writes in place of the journal. */
  | { t: 'snapshot'; v: 1; state: SnapshotState }
);

/**
 * The store's live state, as a compacted journal holds it. Finished orders, sales and gateway operations
 * are left out once nothing reads them any more; see `Store.snapshot`.
 */
export interface SnapshotState {
  cursor?: { block: bigint; hash: Hex };
  offerSalts: OfferSalt[];
  offers: OfferTrack[];
  orders: OrderTrack[];
  sales: SaleTrack[];
  /** Bank credits already used, with when they were paid: one payment settles one order. */
  consumedCredits: { id: string; paidAt?: bigint }[];
  gatewayOps: GatewayOpTrack[];
  /** For open orders and sales only. Optional: snapshots before evidence filing have none. */
  evidence?: EvidenceTrack[];
  /** The per-payer cap ledger, days inside `CAP_RETENTION_DAYS`. Optional: snapshots from a node without caps have none. */
  capCounts?: CapCount[];
}

/** What one order or sale's cap decision was, so it is made once and survives a restart. */
export interface CapTrack {
  /** Committed against the payer's day; what `uncount` gives back. */
  counted?: { day: string; cents: bigint };
  /** The count was already given back (a refund or reversal settled). */
  uncounted?: boolean;
  /** Refused: this node will not prove, release or pay it. */
  refused?: { period: CapPeriod; day: string };
}

export interface EvidenceTrack {
  leg: 'onramp' | 'offramp';
  id: Hex;
  caseId?: string;
  /** The salt is what regenerates the material (`evidenceMaterial`); it never leaves the node. */
  items: { kind: EvidenceKind; digest: Hex; salt: Hex; submitted?: boolean }[];
}

/** How long a used bank credit is remembered after it was paid. */
export const CONSUMED_RETENTION_SECONDS = 30n * 86_400n;
/** How long finished sales and gateway operations are kept: the 24-hour budgets and caps count them. */
export const FINISHED_RETENTION_SECONDS = 2n * 86_400n;

export type GatewayOpKind = 'mint' | 'redeem';

/**
 * How a gateway transaction ended, once nothing can change it (gateway.ts):
 *  - MINED / REVERTED: its receipt, `confirmations` deep.
 *  - DROPPED: it never mined, and cannot - its nonce went to another transaction, or to nothing.
 *  - CONSUMED: its nonce was spent but its hash was never recorded, so whether THIS transaction
 *    moved money is not known. Counted against the daily caps as if it had.
 */
export type GatewayOutcome = 'MINED' | 'REVERTED' | 'DROPPED' | 'CONSUMED';

/** A record as a caller writes it; `at` is stamped by the store. */
export type NewRecord = LpRecord extends infer R ? R extends LpRecord ? Omit<R, 'at'> : never : never;

export interface OfferTrack {
  offerId: Hex;
  asset?: Address;
}

export interface OrderTrack {
  orderId: Hex;
  offerId: Hex;
  seenBlock: bigint;
  boleto?: { idempotencyKey: string; salt: Hex; bankRef?: string; line?: string; commitment?: Hex; issuedTx?: Hex; cancelled?: boolean };
  cob?: CobOrderTrack;
  payment?: IncomingPayment;
  releasedTx?: Hex;
  refund?: { idempotencyKey: string; result?: OutgoingPaymentResult };
  /** The per-payer cap decision for this order (caps.ts). Absent on a node without caps. */
  cap?: CapTrack;
  hold?: string;
  done?: number;
}

/** An order's API Pix charge (onramp.ts, `pixCharge: "cob"`). */
export interface CobOrderTrack {
  /** Derived (`idempotencyKey('order-cob', …)`), recorded before the PSP is asked. */
  txid: string;
  /** Payable by whoever holds it: served to the taker only, never logged or put in /status. */
  location?: string;
  pixCopiaECola?: string;
  /** Unix seconds, the PSP's clock. */
  expiresAt?: bigint;
  amountCents?: bigint;
  revisao?: number;
  /** The status it ended in, once it takes no more payments. */
  closed?: string;
}

export interface SaleTrack {
  saleId: Hex;
  seenBlock: bigint;
  payee?: Payee;
  claims: Hex[];
  pay?: { idempotencyKey: string; rail: BankRail; amountCents: bigint; claimedAt: bigint; result?: OutgoingPaymentResult };
  settledTx?: Hex;
  abandoned: { tx: Hex; reason: string }[];
  disputedTx?: Hex;
  /** The per-payer cap decision for this sale (caps.ts). Absent on a node without caps. */
  cap?: CapTrack;
  hold?: string;
  done?: number;
}

export interface GatewayOpTrack {
  opId: Hex;
  op: GatewayOpKind;
  /** USDT into a mint, or Movva into a redemption, base units. */
  amountIn: bigint;
  minOut: bigint;
  /** What the plan was sized to: the offer's shortfall, or the Movva above the working balance. */
  need: bigint;
  nonce: number;
  /** Wall clock at planning, unix seconds: the daily caps count from it. */
  wallAt: bigint;
  at: number;
  /** The first hash; `txs` holds it and every replacement, in order. */
  tx?: Hex;
  txs: Hex[];
  /** The head when a transaction for it was last broadcast, or a replacement last considered. */
  sentBlock?: bigint;
  /** A replacement was being broadcast and its hash never recorded. */
  replacing?: boolean;
  result?: { outcome: GatewayOutcome; amountOut?: bigint; block?: bigint; at: number };
}

export type KeyPurpose = 'sale-pay' | 'order-refund' | 'order-boleto' | 'order-cob';

/**
 * A bank-safe idempotency key: one letter and 32 hex digits, deterministic in its inputs. 33
 * alphanumerics fits the API Pix devolução id (1-35 of [a-zA-Z0-9]), a cob txid (26-35 of the same)
 * and every idempotency header we know of.
 */
export function idempotencyKey(purpose: KeyPurpose, chainId: number, escrow: Address, id: Hex): string {
  const h = keccak256(encodeAbiParameters(
    [{ type: 'string' }, { type: 'uint256' }, { type: 'address' }, { type: 'bytes32' }],
    [`mova-lp/${purpose}/v1`, BigInt(chainId), escrow, id],
  ));
  const letter = { 'sale-pay': 'S', 'order-refund': 'R', 'order-boleto': 'B', 'order-cob': 'Q' }[purpose];
  return `${letter}${h.slice(2, 34)}`;
}

export interface OfferSalt { asset: Address; salt: Hex; commitment: Hex; at: number }

export class Store {
  cursor?: { block: bigint; hash: Hex };
  /** Offer PIX-key salts by commitment, so a discovered offer can still be served. */
  readonly offerSalts = new Map<string, OfferSalt>();
  readonly offers = new Map<string, OfferTrack>();
  readonly orders = new Map<string, OrderTrack>();
  readonly sales = new Map<string, SaleTrack>();
  /** Bank credits already matched to an order: one payment settles one order. */
  readonly consumedCredits = new Set<string>();
  /** When each consumed credit was paid, for compaction's retention. */
  private readonly consumedAt = new Map<string, bigint | undefined>();
  /** The gateway's mints and redemptions, in the order they were planned. */
  readonly gatewayOps = new Map<string, GatewayOpTrack>();
  /** Evidence filed, or to file, for disputed orders and sales, by `leg:id`. */
  readonly evidence = new Map<string, EvidenceTrack>();
  /**
   * The per-payer cap ledger (caps.ts): payer hash -> Brasília day -> centavos. Nothing in it names an
   * order, a sale, an address or a key, so it cannot link a person to anything but their own total.
   */
  private readonly capCounts = new Map<string, { payer: Hex; days: Map<string, bigint> }>();
  private capLast?: number;
  records = 0;

  constructor(private readonly journal: Journal<LpRecord>, private readonly clock: () => number = Date.now) {}

  /** Replay the journal. Call once, before anything else. */
  load(): void {
    for (const r of this.journal.load()) this.apply(r);
  }

  record(rec: NewRecord): void {
    const full = { ...rec, at: this.clock() } as LpRecord;
    this.journal.append(full);
    this.apply(full);
  }

  close(): void {
    this.journal.close();
  }

  private order(id: Hex): OrderTrack | undefined {
    return this.orders.get(id.toLowerCase());
  }

  private sale(id: Hex): SaleTrack {
    const k = id.toLowerCase();
    let s = this.sales.get(k);
    if (!s) {
      s = { saleId: id, seenBlock: 0n, claims: [], abandoned: [] };
      this.sales.set(k, s);
    }
    return s;
  }

  private apply(r: LpRecord): void {
    this.records++;
    switch (r.t) {
      case 'cursor':
        this.cursor = { block: r.block, hash: r.hash };
        return;
      case 'offer.salt':
        this.offerSalts.set(r.commitment.toLowerCase(), {
          asset: r.asset, salt: r.salt, commitment: r.commitment, at: r.at,
        });
        return;
      case 'offer.mine': {
        const k = r.offerId.toLowerCase();
        const prev = this.offers.get(k);
        this.offers.set(k, { offerId: r.offerId, asset: r.asset ?? prev?.asset });
        return;
      }
      case 'order.seen':
        if (!this.order(r.orderId)) {
          this.orders.set(r.orderId.toLowerCase(), { orderId: r.orderId, offerId: r.offerId, seenBlock: r.block });
        }
        return;
      case 'sale.seen': {
        const s = this.sale(r.saleId);
        if (s.seenBlock === 0n) s.seenBlock = r.block;
        return;
      }
      case 'snapshot':
        this.restore(r.state);
        return;
      default:
        break;
    }
    if (r.t === 'cap.count' || r.t === 'cap.uncount') return this.applyCap(r);
    if (r.t.startsWith('order.')) return this.applyOrder(r);
    if (r.t.startsWith('gateway.')) return this.applyGateway(r);
    if (r.t.startsWith('evidence.')) return this.applyEvidence(r);
    return this.applySale(r);
  }

  private applyOrder(r: LpRecord): void {
    const o = 'orderId' in r ? this.order(r.orderId) : undefined;
    if (!o) return; // a record for an order this journal never saw: nothing to attach it to
    switch (r.t) {
      case 'order.boleto.intent':
        o.boleto = { idempotencyKey: r.idempotencyKey, salt: r.salt };
        break;
      case 'order.boleto.registered':
        if (o.boleto) Object.assign(o.boleto, { bankRef: r.bankRef, line: r.line, commitment: r.commitment });
        break;
      case 'order.boleto.issued':
        if (o.boleto) o.boleto.issuedTx = r.tx;
        break;
      case 'order.boleto.cancelled':
        if (o.boleto) o.boleto.cancelled = true;
        break;
      case 'order.cob.intent':
        // Never replaced: one txid per order, for the life of the journal.
        o.cob ??= { txid: r.txid };
        break;
      case 'order.cob.created':
        if (o.cob) Object.assign(o.cob, { location: r.location, pixCopiaECola: r.pixCopiaECola, expiresAt: r.expiresAt, amountCents: r.amountCents, revisao: r.revisao });
        break;
      case 'order.cob.closed':
        if (o.cob) o.cob.closed = r.status;
        break;
      case 'order.payment':
        o.payment = r.payment;
        this.consumedCredits.add(r.payment.bankTxId);
        this.consumedAt.set(`credit:${r.payment.bankTxId}`, r.payment.paidAt);
        break;
      case 'order.released':
        o.releasedTx = r.tx;
        break;
      case 'order.refund.intent':
        o.refund = { idempotencyKey: r.idempotencyKey };
        break;
      case 'order.refund.result':
        if (o.refund) o.refund.result = r.result;
        break;
      case 'order.cap':
        // Each side once: a refusal is never revisited (a day that has since rolled would undo it), and a
        // count is never doubled. An order can hold both - one this LP refused that a taker released anyway
        // is counted, because the LP kept the BRL (onramp.ts).
        o.cap ??= {};
        if (r.decision === 'counted') o.cap.counted ??= { day: r.day, cents: r.cents ?? 0n };
        else o.cap.refused ??= { period: r.period ?? 'day', day: r.day };
        break;
      case 'order.cap.uncounted':
        if (o.cap) o.cap.uncounted = true;
        break;
      case 'order.hold':
        o.hold = r.reason;
        break;
      case 'order.done':
        o.done = r.state;
        break;
      default:
        break;
    }
  }

  private applyEvidence(r: LpRecord): void {
    if (r.t !== 'evidence.prepared' && r.t !== 'evidence.case' && r.t !== 'evidence.submitted') return;
    const k = `${r.leg}:${r.id.toLowerCase()}`;
    let ev = this.evidence.get(k);
    if (!ev) {
      ev = { leg: r.leg, id: r.id, items: [] };
      this.evidence.set(k, ev);
    }
    if (r.t === 'evidence.prepared') {
      if (!ev.items.some((x) => x.kind === r.kind)) ev.items.push({ kind: r.kind, digest: r.digest, salt: r.salt });
    } else if (r.t === 'evidence.case') {
      ev.caseId ??= r.caseId;
    } else {
      const item = ev.items.find((x) => x.digest.toLowerCase() === r.digest.toLowerCase());
      if (item) item.submitted = true;
    }
  }

  evidenceFor(leg: 'onramp' | 'offramp', id: Hex): EvidenceTrack | undefined {
    return this.evidence.get(`${leg}:${id.toLowerCase()}`);
  }

  private applyGateway(r: LpRecord): void {
    switch (r.t) {
      case 'gateway.intent':
        if (!this.gatewayOps.has(r.opId.toLowerCase())) {
          this.gatewayOps.set(r.opId.toLowerCase(), {
            opId: r.opId, op: r.op, amountIn: r.amountIn, minOut: r.minOut, need: r.need, nonce: r.nonce, wallAt: r.wallAt, at: r.at, txs: [],
          });
        }
        return;
      case 'gateway.sent': {
        const op = this.gatewayOps.get(r.opId.toLowerCase());
        if (!op) return;
        if (!op.tx) op.tx = r.tx;
        if (!op.txs.includes(r.tx)) op.txs.push(r.tx);
        if (r.block !== undefined) op.sentBlock = r.block;
        op.replacing = false;
        return;
      }
      case 'gateway.replacing': {
        const op = this.gatewayOps.get(r.opId.toLowerCase());
        if (op) op.replacing = true;
        return;
      }
      case 'gateway.replace.skipped': {
        const op = this.gatewayOps.get(r.opId.toLowerCase());
        if (op) Object.assign(op, { replacing: false, sentBlock: r.block });
        return;
      }
      case 'gateway.result': {
        const op = this.gatewayOps.get(r.opId.toLowerCase());
        // Never replaced: an outcome is recorded only once it is final.
        if (op && !op.result) op.result = { outcome: r.outcome, amountOut: r.amountOut, block: r.block, at: r.at };
        return;
      }
      default:
        return;
    }
  }

  private applySale(r: LpRecord): void {
    if (!('saleId' in r)) return;
    const s = this.sale(r.saleId);
    switch (r.t) {
      case 'sale.payee':
        s.payee = r.payee;
        break;
      case 'sale.claimed':
        s.claims.push(r.tx);
        break;
      case 'sale.pay.intent':
        // Never replaced: one payment intent per sale, for the life of the journal.
        if (!s.pay) s.pay = { idempotencyKey: r.idempotencyKey, rail: r.rail, amountCents: r.amountCents, claimedAt: r.claimedAt };
        break;
      case 'sale.pay.result':
        if (s.pay) s.pay.result = r.result;
        break;
      case 'sale.settled':
        s.settledTx = r.tx;
        break;
      case 'sale.abandoned':
        s.abandoned.push({ tx: r.tx, reason: r.reason });
        break;
      case 'sale.disputed':
        s.disputedTx = r.tx;
        break;
      case 'sale.cap':
        s.cap ??= { counted: { day: r.day, cents: r.cents } };
        break;
      case 'sale.cap.uncounted':
        if (s.cap) s.cap.uncounted = true;
        break;
      case 'sale.hold':
        s.hold = r.reason;
        break;
      case 'sale.done':
        s.done = r.state;
        break;
      default:
        break;
    }
  }

  private applyCap(r: LpRecord & { t: 'cap.count' | 'cap.uncount' }): void {
    const k = r.payer.toLowerCase();
    let e = this.capCounts.get(k);
    if (!e) {
      e = { payer: r.payer, days: new Map() };
      this.capCounts.set(k, e);
    }
    const now = (e.days.get(r.day) ?? 0n) + (r.t === 'cap.count' ? r.cents : -r.cents);
    // A day can only ever go back to zero: an un-count gives back what a count took, never more.
    e.days.set(r.day, now > 0n ? now : 0n);
    if (r.t === 'cap.count') this.capLast = r.at;
  }

  /** Every ledger row the store holds. Payer hashes, days and amounts - nothing else. */
  capRows(): CapCount[] {
    const out: CapCount[] = [];
    for (const e of this.capCounts.values()) {
      for (const [day, cents] of e.days) if (cents > 0n) out.push({ payer: e.payer, day, cents });
    }
    return out;
  }

  /** What one payer has counted in a day and in that day's month. */
  capUsage(payer: Hex, day: string): { dayCents: bigint; monthCents: bigint } {
    const e = this.capCounts.get(payer.toLowerCase());
    if (!e) return { dayCents: 0n, monthCents: 0n };
    const month = capMonth(day);
    let monthCents = 0n;
    for (const [d, c] of e.days) if (capMonth(d) === month) monthCents += c;
    return { dayCents: e.days.get(day) ?? 0n, monthCents };
  }

  /** When the ledger was last written, unix milliseconds of the record's `at`; undefined if never. */
  capLedgerLastAt(): number | undefined {
    return this.capLast === undefined ? undefined : Math.floor(this.capLast / 1000);
  }

  /*------------------------------ compaction ------------------------------*/

  /**
   * The state a restart needs, as one record. Kept: the cursor; every offer salt (an offer can stay live,
   * and its orders need the salt, for as long as the price holds); every offer followed, less those
   * `drained` (closed and empty, so nothing can come back to them); every open order and sale, with their
   * intents, keys, disclosures and boletos; finished sales with a payment inside
   * `FINISHED_RETENTION_SECONDS` (the daily budget counts them); every open gateway operation, those
   * finished inside the retention (the daily caps count them) and the last final mint and redemption;
   * and every used credit paid inside `CONSUMED_RETENTION_SECONDS` (older ones are before any
   * order that could match them). Dropped: finished orders and sales, whose on-chain state is final and
   * whose bank calls are keyed by ids derived from the chain.
   */
  snapshot(o: { now: bigint; drainedOffers?: ReadonlySet<string> }): LpRecord {
    const keepConsumed = (ids: Set<string>) => [...ids]
      .map((id) => ({ id, paidAt: this.consumedAt.get(`credit:${id}`) }))
      .filter((c) => c.paidAt === undefined || c.paidAt + CONSUMED_RETENTION_SECONDS > o.now);
    const recent = (t: bigint | undefined) => t === undefined || t + FINISHED_RETENTION_SECONDS > o.now;
    const ops = [...this.gatewayOps.values()];
    const lastMined = new Set((['mint', 'redeem'] as const)
      .map((k) => ops.filter((x) => x.op === k && x.result?.outcome === 'MINED').at(-1)?.opId).filter((x): x is Hex => !!x));
    const state: SnapshotState = {
      cursor: this.cursor,
      offerSalts: [...this.offerSalts.values()],
      offers: [...this.offers.values()].filter((t) => !o.drainedOffers?.has(t.offerId.toLowerCase())),
      orders: [...this.orders.values()].filter((t) => t.done === undefined),
      sales: [...this.sales.values()].filter((t) => t.done === undefined || (t.pay && recent(t.pay.result?.paidAt))),
      consumedCredits: keepConsumed(this.consumedCredits),
      gatewayOps: ops.filter((x) => !x.result || recent(x.wallAt) || lastMined.has(x.opId)),
      evidence: [...this.evidence.values()].filter((e) => (e.leg === 'onramp'
        ? this.orders.get(e.id.toLowerCase())?.done === undefined && this.orders.has(e.id.toLowerCase())
        : this.sales.get(e.id.toLowerCase())?.done === undefined && this.sales.has(e.id.toLowerCase()))),
      // Two months of cap history: a monthly limit must never look at a window the snapshot cut short.
      capCounts: this.capRows().filter((c) => c.day > dayMinus(capDay(o.now), CAP_RETENTION_DAYS)),
    };
    return { t: 'snapshot', v: 1, state, at: this.clock() };
  }

  /** Replace the journal with `snapshot()`, when the journal can be compacted. */
  compact(o: { now: bigint; drainedOffers?: ReadonlySet<string> }): boolean {
    if (!this.journal.compact) return false;
    const snap = this.snapshot(o);
    this.journal.compact([snap]);
    // The store now holds exactly what a restart from the new journal would: rebuild from it.
    this.records = 0;
    this.apply(snap);
    return true;
  }

  private restore(st: SnapshotState): void {
    this.cursor = st.cursor;
    for (const m of [this.offerSalts, this.offers, this.orders, this.sales, this.gatewayOps, this.evidence] as Map<string, unknown>[]) m.clear();
    for (const e of st.evidence ?? []) this.evidence.set(`${e.leg}:${e.id.toLowerCase()}`, e);
    this.consumedCredits.clear();
    this.consumedAt.clear();
    for (const x of st.offerSalts) this.offerSalts.set(x.commitment.toLowerCase(), x);
    for (const x of st.offers) this.offers.set(x.offerId.toLowerCase(), x);
    for (const x of st.orders) this.orders.set(x.orderId.toLowerCase(), x);
    for (const x of st.sales) this.sales.set(x.saleId.toLowerCase(), x);
    for (const x of st.gatewayOps) this.gatewayOps.set(x.opId.toLowerCase(), x);
    for (const c of st.consumedCredits) { this.consumedCredits.add(c.id); this.consumedAt.set(`credit:${c.id}`, c.paidAt); }
    this.capCounts.clear();
    for (const c of st.capCounts ?? []) this.applyCap({ ...c, t: 'cap.count', at: 0 });
  }

  /** Bytes in the journal, when it can say. */
  journalBytes(): number | undefined {
    return this.journal.size?.();
  }

  /*------------------------------ queries ------------------------------*/

  getOrder(id: Hex): OrderTrack | undefined {
    return this.order(id);
  }

  getSale(id: Hex): SaleTrack | undefined {
    return this.sales.get(id.toLowerCase());
  }

  isMyOffer(offerId: Hex): boolean {
    return this.offers.has(offerId.toLowerCase());
  }

  saltFor(commitment: Hex): Hex | undefined {
    return this.offerSalts.get(commitment.toLowerCase())?.salt;
  }

  openOrders(): OrderTrack[] {
    return [...this.orders.values()].filter((o) => o.done === undefined);
  }

  openSales(): SaleTrack[] {
    return [...this.sales.values()].filter((s) => s.done === undefined && s.seenBlock > 0n);
  }

  /** Gateway transactions planned and not yet final, oldest first. */
  openGatewayOps(): GatewayOpTrack[] {
    return [...this.gatewayOps.values()].filter((o) => !o.result);
  }

  /** Off-ramp payments whose outcome the node has not yet recorded as final. */
  unresolvedPayments(): number {
    let n = 0;
    for (const s of this.sales.values()) if (s.pay && (!s.pay.result || s.pay.result.status === 'PENDING')) n++;
    for (const o of this.orders.values()) {
      if (o.refund && (!o.refund.result || o.refund.result.status === 'PENDING')) n++;
    }
    return n;
  }
}
