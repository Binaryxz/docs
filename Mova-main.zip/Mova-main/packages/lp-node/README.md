# @mova/lp-node

The software a liquidity provider runs so it stops operating the ramp by hand. One daemon, one
LP key, one journal: it keeps on-ramp offers priced and funded, serves takers their payment
instructions, watches the LP's bank for their payments and proves them, and on the off-ramp
decides which sales to buy, claims them, pays the sellers and collects the crypto - within the
contracts' deadlines, and without ever paying twice. Configured as a **Movva gateway**, it also mints
Movva from its USDT to fund Movva offers and redeems the Movva it buys back into USDT
([below](#the-movva-gateway)).

```
      chain (FiatEscrow, OffRampEscrow, LPRegistry, oracles, MovvaReserve)
                 ▲ reads at head and at head-N+1, writes from the LP key
                 │
   ┌─────────────┴──────────────────────────────────────────────┐
   │ LpNode.tick()   events.ts: cursor + reorg rewind             │
   │   gateway.ts    settle open mint/redeem intents (begin)      │
   │   offramp.ts    decide → claim → [N confirmations] → pay     │
   │                 → prove → settle   (or dispute in time)       │
   │   onramp.ts     track orders → boleto issue → match credits  │
   │                 → prove → release / reclaim → refund          │
   │   offers.ts     quote (pricing.ts) → post/close/fund/sweep    │
   │                 └ Movva: gateway.fund → mint to the need       │
   │   gateway.ts    redeem Movva above the working balance (end) │
   │ store.ts ⇄ journal.ts (JSONL, fsync, torn-tail recovery)     │
   └─────┬───────────────────────┬──────────────────────┬────────┘
         │ BankAdapter (bank.ts) │ PaymentProver         │ HTTP (server.ts)
         ▼                       ▼                       ▼
   LP's bank: plugin       PIX, boleto: zkTLS       ops: /healthz /readyz /status /metrics
   (api-pix.ts receives;    session (zktls.ts)      api: /v1/onramp/instructions, /v1/offramp/payee
    MockBank in tests)      (plugins; local keys dev)
```

## What the contracts ask of an LP

Read from `contracts/ramp/*.sol`; the node is built around exactly this.

**On-ramp (`FiatEscrow`).** The LP escrows crypto in an offer at a fixed price (there is no
"update price": repricing is `closeOffer` + `postOffer`). A taker locks part of it:

| Order | LP must | Deadline | If missed |
|---|---|---|---|
| PIX/TED (`lockOrder`) | Tell the taker where to pay: the offer holds only a **salted commitment** to the LP's PIX key, so key + salt + amount go to the taker off-chain. Nothing on-chain is required. | Taker has `PAY_WINDOW` = 30 min to have payment proven | Order expires; anyone may `reclaimExpired` it back to the offer |
| Boleto (`lockOrderByBoleto`) | Register a boleto for exactly `brlCents`, commit with `issueBoleto(orderId, commitment)`, hand the taker line + salt | `BOLETO_ISSUE_WINDOW` = 1 h; then the taker has 3 days | Order expires at no on-chain cost; an SLA breach |
| Proof | `releaseWithProof` is callable by anyone. A PIX or boleto offer names a zkTLS verifier (`postOffer` refuses any other: `BankRailNeedsZkTls`); the LP, whose bank shows the credit, proves it from a TLS session with its bank - or the taker proves from theirs | Before `payBy` | Taker may `raiseDispute` while the order is still LOCKED |

On this leg the LP owes nothing an arbitrator could find unpaid: a REFUND ruling records nothing
against it, a taker's unanswered dispute costs it nothing, a RELEASE counts as settled volume. What
costs the LP is holding BRL for an order that did not release - that money is the taker's.

**Off-ramp (`OffRampEscrow`).** The seller escrows crypto and names a salted payee commitment
(PIX key, or a boleto barcode for a BOLETO-only sale). The LP:

| Step | Rule |
|---|---|
| `claimSale` | Exclusive; reserves `brlCents` of registry credit; `payBy = now + 45 min` |
| Pay BRL | To the committed payee, on a rail the sale accepts, ≥ `brlCents` (exactly, for a boleto), **after** the claim |
| `settleWithProof` | Before `payBy`; receipt ≤ 2 days old, not replayed |
| Miss `payBy` | Anyone `releaseStaleClaim`s it; the sale reopens. `abandonClaim` before that is free |
| The trap | BRL paid under a claim that goes stale **cannot** settle any later claim (`ReceiptPredatesClaim`). Only a dispute raised while still holding the claim can recover it, and an LP-raised dispute that times out refunds the seller **and** records a lost dispute |

`LPRegistry` bounds everything: an LP's live exposure across every offer, order and claim on both
escrows cannot exceed its credit; a lost dispute halves a retail or affiliated LP's limit.

**Bank payments settle on zkTLS only** (Mova's decision, 14 September 2026). Both escrows ask the verifier
`provesBankSession()`: `FiatEscrow.postOffer` and `OffRampEscrow.openSale` refuse a
verifier that answers false (`BankRailNeedsZkTls`). `ReclaimZkTlsVerifier` answers true - its witnesses can refuse to
attest a TLS session with an allowlisted bank endpoint but cannot invent its response. See [Proving payments](#proving-payments-zktls-for-bank-rails). The card rail and the attestor quorum were removed on 24 September 2026 (`docs/card-rail-removal.md`).

**Movva (`MovvaReserve`).** Movva is a listed asset like any other on the escrows, with the reserve as
its band oracle: `brlCentsPerUnit` reads 100 centavos while the reserve is fully backed and
min(1, ratio) of that below. An LP the reserve admits as a *gateway* may also:

| Call | Refuses when | Pays |
|---|---|---|
| `mint(usdtIn, to, minMovvaOut)` | not a gateway; setup open; `mintPaused`; Tether froze the reserve (or the LP, whose USDT cannot move); a rate leg stale or out of range; `collateralRatioBps < minMintCollateralRatioBps`; past `supplyCap`; under `minMovvaOut` | Movva at the rate for the USDT the reserve booked, less `mintFeeBps` |
| `redeem(movvaIn, to, minUsdtOut)` | not a gateway; setup open; the payee frozen; a rate leg stale; under `minUsdtOut`; `InsufficientLiquidity` (idle USDT plus the vault's `maxWithdraw`) | USDT worth min(1, ratio) of par, less `redeemFeeBps`. **Cannot be paused** |

Movva pulls USDT with `transferFrom`, so each mint needs an allowance - and real USDT refuses to change
a non-zero allowance to another non-zero value.

**The FX leg, and the FX market's hours.** The rate comes from Pyth's FX.USD/BRL through `PythFxOracle`, which the
reserve reads directly and the ramps read as centavos through `ScaledFxBandOracle` inside each asset's
`ChainlinkSignedFxOracle` cross. FX.USD/BRL trades weekdays 08:00-17:00 New York time; PIX does not close. So there
are two readings: the RATE (`brlPerUsdtE18`, and everything that mints, redeems or previews) refuses a price older than
its limit at any hour (`StaleRate`), while a BAND (`bandBrlPerUsdtE18`, Movva's `brlCentsPerUnit`, and the USDT and ETH
crosses) takes the last close outside the core session (13:30-21:00 UTC, weekdays), stamped with the block's time.
Buying and selling by PIX and boleto run 24/7 against the close; minting and redeeming wait for the market.

## What the node does

- **Offers** (`offers.ts`, `pricing.ts`). Per asset: ask = `max(reference, oracle) × (1 + spreadBps)`,
  never below `max(...) × (1 + minSpreadBps)`, clamped inside the escrow band less
  `bandMarginBps`. Reprices (close + post, fresh salt) when the posted price falls below the floor,
  reaches the band edge, or drifts past `refreshDriftBps`. Sizes to `liquidity`, wallet balance
  (less a gas reserve for ETH), `LPRegistry.availableCents` and `maxOfferBrlCents`. Tops up with
  `fundOffer`; sweeps liquidity that expired orders return to closed offers. Asset decimals come
  from the escrow's pinned config. **Pulls** (closes) on: stale or missing oracle or reference,
  reference/oracle disagreement beyond `maxOracleDeviationBps`, floor above the band ceiling, asset
  delisted, verifier revoked, no credit (suspended LPs' offers are still lockable until closed).
- **On-ramp** (`onramp.ts`). Tracks orders against its offers; registers and issues boletos (only
  for locks with N confirmations); serves instructions (PIX key, salt, BR Code whose txid is the
  wallet's derivation from the order id; or boleto line + salt) to the order's taker only; matches
  bank credits by txid, else by exact amount when exactly one order fits, else leaves them for a
  human; proves the credit by zkTLS (its received-payment page) and releases; reclaims expired orders; cancels boletos of orders
  that did not release; refunds (PIX devolução) BRL received for an order once its cancellation
  has N confirmations. With `onramp.pixCharge: "cob"` a PIX order gets an API Pix immediate charge instead of the
  static code: see [PIX charges](#pix-charges-cob).
- **Movva gateway** (`gateway.ts`). See [below](#the-movva-gateway): mints to fund the Movva offer,
  redeems Movva above `keepMovva`, prices both from what they cost, and journals each as an intent
  with its nonce before sending.
- **Node-provider rewards** (`rewards.ts`). See [below](#node-provider-rewards): finalizes epochs whose review has
  ended and claims the LP's share of Mova's fees for the volume it settled.
- **Per-payer caps** (`caps.ts`), when configured. See [below](#per-payer-caps): counts what each *payer* -
  the person the bank names, never an address - moves in a Brasília day and month, and refuses what crosses
  their tier's limit before the LP's asset or its BRL does.
- **Off-ramp** (`offramp.ts`). Takes payee disclosures (key or line + salt, checked against the
  commitment, and only on a rail in `offramp.rails`); claims only sales it can finish (payee known, a bill its bank
  can pay - `boleto_no_due_date` at a bank that pays only with one - a prover for the sale's verifier that proves
  its rail, a buy by both reference and oracle less `minMarginBps`, credit, bank balance, open-claim cap, daily
  budget); pays only after the claim has N confirmations, with time left and the price still good (else
  abandons, free); proves the PIX it sent or the bill it paid by zkTLS, bound to the sale, and settles; raises a
  dispute while still holding the claim if it paid and cannot prove in time.

## What the node never does

- Pay BRL against a claim, or refund against a cancellation, that is not N blocks deep.
- Call the bank for a payment whose intent and idempotency key are not already fsynced; issue a
  second key for a sale; retry a FAILED payment under a new key.
- Quote at a price it cannot justify from two agreeing, fresh prices; sell below the oracle plus its
  minimum spread; buy above the oracle less its margin.
- Serve a PIX key + salt to anyone but the order's taker; log, serve or label a metric with a key,
  salt, payee, payer document or bank id; read a key from the strategy file.
- Hold an arbitrator role, submit rulings, or decide disputes: disputed orders and
  sales are flagged for a human with the evidence.
- Offer PIX or boleto on a verifier that does not prove the bank session, or submit anything but a zkTLS proof of a bank
  payment; submit a zkTLS claim bound to another order or sale, about a page the verifier does not allowlist for
  that rail, or about any payment but the one its bank reported - or a second payment for an order it already proved.
- Ask the Movva reserve for a mint or redemption it would refuse (it checks first, and reports why);
  mint more than the Movva offer needs, or past its per-mint and daily caps; redeem while the reserve
  would pay under `minCollateralRatioBps` of par (default: never below par); send a second mint or
  redemption while an earlier one could still mine, or is mined and not yet N blocks deep; change a
  non-zero USDT allowance to another non-zero value; mint or redeem while the FX market is closed.

## Proving payments: zkTLS for bank rails

A node registers one `PaymentProver` per verifier, and each says which rails it proves (`rails`):

| Prover | Verifier | Rails | Proves |
|---|---|---|---|
| `ZkTlsProver(verifier, session, options)` (zktls.ts) | `ReclaimZkTlsVerifier` | PIX, BOLETO | on-ramp: the credit the LP received; off-ramp: the PIX it sent, or the bill it paid |

**Which page.** A zkTLS proof is a Reclaim claim about one page of the LP's bank, and a ramp payment is on one of
four (`ReceiptKind` in `@mova/ramp`): `pix-received` and `boleto-received` on the on-ramp, `pix-sent` and
`boleto-paid` on the off-ramp. Each is its own provider template, allowlisted on the verifier by its `providerHash`
beside a URL prefix and a rail mask: the PIX pages for PIX (what `allowEndpoint` sets), the boleto pages widened to
BOLETO with `setEndpointRails`, so no page vouches for the other rail. The claim's `contextMessage` is the order id
on the on-ramp and the sale id on the off-ramp - the id each escrow passes to `verifyPayment` - so a proof settles
the one order or sale it was made for.

**What the prover checks** before a proof costs a transaction: provider `http`; the identifier recomputed; bound to
this order or sale; the payment the node's bank reported, by id; a payment that proves the order (rail, payee,
amount - exactly, for a boleto - and time); signers in the verifier's witness set, at least its threshold; an
endpoint allowlisted for that rail. The last two against `options.witnesses` and `options.endpoints`, and all of it
against the chain with `options.preflight` (`prepareSettlement` in `@mova/ramp`). Once it has proven one payment for
an order it proves no other.

**The session is the LP's plugin.** `ZkTlsSession.prove({ leg, rail, receipt, binding, bankTxId, salt, payerRef })`
returns the witnesses' signed claim. A real session needs what no repository can hold: a Reclaim application
credential; the provider templates for the LP's bank pages, capturing all six fields the verifier reads from what
the bank writes (with hashed redactions for the payee commitment and `payerRef`, which no bank page shows - the gap
docs/security-review-phase2.md records); and the LP's own authenticated client for those pages. `LocalWitnessSession`
is the stand-in, and says so: local witness keys sign claims in the exact Reclaim format over the bank's own record
of the payment (`ReceiptSource`; `MockBank.receipt` finds it by id, so the amount, time and payee are the bank's, not
the node's), on `receiptTemplates(urlPrefix)`. It runs the whole path down to the verifier's byte-level JSON checks in
the tests and the live examples; the entrypoint allows it only with `LP_NODE_DEV=1`.

**Without a bank prover** the on-ramp is passive (the taker may still prove from their own bank) and no sale is
claimed. A PIX or boleto asset on a verifier that does not prove the bank session never starts - `lp-node.ts` asks the chain `provesBankSession()` of every bank asset's
verifier - and one that reaches the offer manager anyway is pulled as `bank_rail_needs_zktls`.

## The Movva gateway

Enabled by the `gateway` section. The Movva asset on either leg is the configured `gateway.movva`.

**Minting to a need.** When the Movva offer would post or top up and the wallet's Movva cannot cover
it, the offer manager asks the gateway for exactly the shortfall: the offer's liquidity target less what
is posted, within credit and `maxOfferBrlCents`, less the wallet's Movva. The gateway checks every
refusal above, then sizes the USDT: the least that mints the shortfall after the fee, capped by
`maxMintUsdt`, by `maxMintUsdtPerDay` (trailing 24 h, counting every mint that may have moved money), by
the wallet's USDT less `keepUsdt`, and by the reserve's supply headroom. `minMovvaOut` is `previewMint`
less `maxSlippageBps`. It approves USDT (zeroing a leftover allowance first), simulates, and sends. A
mint exceeds the shortfall by at most one USDT base unit's worth of Movva.

**Redeeming above the working balance.** Last in each tick - after sales settled and offers took what
they needed - Movva above `keepMovva` (and above anything the Movva offer wanted and could not post) is
redeemed, capped by `maxRedeemMovva`, `maxRedeemMovvaPerDay` and what the reserve can pay now, with
`minUsdtOut` = `previewRedeem` less slippage. While the reserve's ratio is under `minCollateralRatioBps`
(default 10000), or `previewRedeem` pays less than that share of par, it **holds** instead and raises
`mova_lp_gateway_held{reason="below_par"}`: redeeming then would make a shortfall the ratio may recover
from permanent. `redeem.enabled: false` stops redemptions, which the reserve itself never does.

**Pricing.** `{"source":"par"}` is Movva's reference (100 centavos); the oracle is the reserve. Neither
is a cost, so a Movva offer also gets a floor: what a Movva costs to mint - the reserve's rate (or the
LP's `usdtPrice`, whichever is dearer) plus `usdtCostBps`, over the Movva one USDT buys after the mint
fee - and the spreads apply over that too. A Movva sale must also be a buy against what redeeming it
pays: min(1, ratio) of par, less the redeem fee, in USDT sold back at the rate (or `usdtPrice`,
whichever is lower) less `usdtSaleBps`. Both are carried to 1e-18 centavo: a centavo is 100 bps of
R$ 1,00. When either cannot be stated (a stale rate, an unreadable reserve, a policy that would hold what
it bought), Movva is not quoted and Movva sales are not claimed (`cost_unavailable`); a cost above what
the band allows is `cost_above_band`. With `usdtPrice`, a reserve rate further than
`maxRateDeviationBps` from it also stops mint and redeem (`rate_deviates`).

**Off-hours.** While the FX market is closed the reserve refuses its rate (`StaleRate`) and its band reads the last
close; a band that reads while the rate does not is exactly that (`marketClosed`, chain.ts). Then the gateway
plans no mint and no redemption - both `blocked` as `market_closed`, `mova_lp_gateway_held{reason="market_closed"}`
and `mova_lp_gateway_market_closed` 1, `/status` `gateway.market` `closed`, logged once at info - while the Movva
offer keeps being priced (its cost at the band's rate, its oracle the escrow band stamped current) and posted from
the Movva the wallet holds, and Movva sales are valued at the close; Movva bought meanwhile waits. When the market
reopens and the keeper posts the day's first price, the next tick mints and redeems. A rate and band both refused -
inside the core session, a keeper that has not posted - is not a closed market: `rate_stale`, and Movva is pulled.

**At most one transaction per intent.** Mint and redeem are the LP's own transactions, and a restarted
node cannot see one still in the mempool. So each is journaled before it is signed - amounts, the need,
and the nonce it will use, read before the balances it is sized from - and its hash is journaled as soon
as the RPC returns it. An intent is final only `confirmations` deep, and nothing new is planned while one
is open. On restart an open intent is resolved from its receipt, or from its nonce: spent at the
confirmed block, it can never mine (`DROPPED` if its hash had no receipt, `CONSUMED` if its hash was
never recorded - counted against the daily cap as if it minted); still pending, wait; free, nothing was
broadcast and the next transaction takes that nonce, so no copy can mine beside it; a gap below it, hold
for a human (`nonce_gap`). Approvals are re-read, not journaled.


## Node-provider rewards

Mova shares part of its fee revenue with the LPs who settle BRL volume (docs/movva.md, "Fees"; the contract,
`contracts/ramp/NodeRewards.sol`; what bounds farming and what remains, SR2-36 in docs/security-review-phase2.md). The node
earns by settling, as it already does: `LPRegistry` reports each settlement to NodeRewards through its rewards hook, and
NodeRewards counts it for INSTITUTIONAL and AFFILIATED LPs, per weekly epoch. An epoch is claimable once it has ended, its
review period has passed and someone has finalized it. What the node adds is claiming (`rewards.ts`):

- every tick it reads whether its settlements count (NodeRewards bound to the configured registry, the LP not excluded), its
  counted volume this epoch, and what it can claim from finalized epochs in its look-back window;
- with `claim` on, it finalizes any epoch whose review has ended - anyone may, and the LP is the one waiting - then claims every
  finalized epoch with a share in one transaction, once the total reaches `minClaim`;
- it keeps no journal for it: the contract marks each epoch claimed and every write is simulated first, so nothing is paid twice,
  and a claim a reorg removes is simply claimable again.

```json
"rewards": { "contract": "0x…NodeRewards", "claim": true, "minClaim": "0", "lookbackEpochs": 12, "to": "0x…" }
```

Only `contract` is required. `lookbackEpochs` (1 to 104) is how many finalized epochs back the node looks; `to` pays a wallet
other than the LP key; `claim: false` keeps the metrics and `/status` without sending anything. The entrypoint refuses a
NodeRewards bound to a different registry than `registry` (none of this LP's settlements would count) and warns while none is bound.

| Metric | What it says |
|---|---|
| `mova_lp_rewards_claimable` | Centavos of the reward token claimable now |
| `mova_lp_rewards_counting` | 1 while settlements count; 0 when NodeRewards is unbound, bound elsewhere, or has excluded the LP |
| `mova_lp_rewards_epoch_volume_cents` | This LP's counted volume in the current epoch |
| `mova_lp_rewards_unclaimed_epochs`, `mova_lp_rewards_finalizable_epochs` | Finalized epochs with a share not yet claimed; epochs waiting to be finalized |
| `mova_lp_rewards_finalized_total`, `mova_lp_rewards_claims_total{outcome}`, `mova_lp_rewards_claimed_cents_total` | What the node finalized and claimed |

`/status` `rewards` carries the same figures, `notCounting` (`unbound`, `bound_elsewhere`, `excluded`) and the last claim.
`examples/lp-node-movva-live.ts` funds rewards through the FeeSplitter (step 7) and has the node finalize and claim them (step 11)
on the real contracts.
## Per-payer caps

MVP Scope Rev. 2 §10.1 asks for per-user daily caps in five tiers. They live here, in the node
(`caps.ts`), and are **off unless you configure them** - a node with no `caps` section keeps no ledger
and behaves exactly as it did before they existed.

**Why not on-chain.** A cap binds a *person*. On-chain a user is deliberately unlinkable - a fresh
taker address per order, a shielded recipient - so an on-chain cap would have to be keyed on an
address, which anyone can make (capping nothing), or on an identity registry, which would undo the
privacy the rail is for. The one place a person is identified is the **fiat side**: a PIX credit, a
paid boleto names a payer, and the node already derives `payerRef` from it for
attestation. So the cap is keyed on `payerRef` - `keccak256("mova-lp/payer-ref/v1", payerId,
PAYER_REF_SECRET)` - and never leaves this node.

**Where the refusal happens.** Only once the payer is known, which differs per rail:

| Rail | The payer is known | What a refusal does |
|---|---|---|
| On-ramp PIX / boleto | when the credit lands - nothing earlier names a person without linking addresses | no proof is fetched and nothing is released; the order expires and the BRL goes back by PIX devolução on the existing cancellation path, which gives the allowance back with it |
| Off-ramp | at the payee disclosure, before anything is claimed | `POST /v1/offramp/payee` answers 409 `cap_reached`, and `decide` skips the sale (`payer_cap`). Nothing was claimed, so another LP may take it |

`releaseWithProof` is permissionless, and a taker who has paid can prove it from their own bank
session. So a refusal is **this LP declining to prove it, to release, and to keep the BRL** - not a
promise that no order can ever settle. If a taker releases one anyway, the LP keeps the money and the
node counts the payment then, so that payer's next one is refused too.

**What this LP learns, and what it cannot.** The ledger is rows of `(payerRef, Brasília day,
centavos)`: no order id, no sale id, no address, no key, no document. Two payments by one person are
correlated through `payerRef` and through nothing else, and `payerRef` is not enumerable without
`PAYER_REF_SECRET`. Nothing about a cap reaches the chain, the wallet, the matcher or another LP: a
person's tier and totals here are invisible everywhere else, and a counterparty is told only *that* a
limit was reached, never the number. What caps do **not** change: an LP already sees "this order's
credit came from this document", and the order's taker is on-chain, so it could already join the two
for an order it served. Unlinkability across orders is a property of the chain, not of a bank
statement.

**Days are Brasília days** (`America/Sao_Paulo`, UTC-3, no DST since 2019), because that is the day a
regulator, a bank statement and a user all mean; a UTC day would reset every cap at 21:00 local. A
month is that day's calendar month. The ledger is in the journal (`STATE_FILE`), so a restart does not
forget, and compaction keeps two months of it.

**Counting.** A payment is counted when the node commits to it - the credit it is about to release
against, the payment it is about to send - and **un-counted** when that money demonstrably goes back
(a settled refund, a payment the bank reported FAILED): a purchase that was
returned did not consume anyone's limit. The count is fsynced before the order is marked counted, so
the only thing a crash between them can do is count twice - which refuses more, never less.

**Your bank must name the payer.** This is the one thing configuration cannot check. The standard
**API Pix 2.10.0 carries no payer document**, so `ApiPixReceiver` (and Banco Inter's charge listing)
report none; only a `BANK_MODULE` that fills `IncomingPayment.payerId` can be capped. With the default `unknownPayer: "refuse"` such a payment is not settled
and is returned - which is the point, but check it before you turn caps on. The entrypoint warns at
start. A boleto **payout** identifies a bill,
not a person, so caps do not really bind on `offramp.rails: ["BOLETO"]`.

```jsonc
"caps": {
  "defaultTier": 0,              // the tier of a payer nothing else names
  "unknownPayer": "refuse",      // or "allow": let an unattributable payment through, uncounted
  "tiers": {                     // 0-4; a tier with no limit is unlimited, and there are NO defaults
    "0": { "dailyBrlCents": "200000", "monthlyBrlCents": "1000000" },
    "4": {}
  },
  "payers": [
    { "payerRef": "0x…", "tier": 3 },       // the hash /status shows: no personal data in this file
    { "payer": "529.982.247-25", "tier": 2 } // hashed on read and never kept - but the FILE holds a document
  ]
}
```

> **The numbers above are an example, not a policy.** Nothing ships with a limit set. Tier 0 at
> R$ 2.000,00 a day and R$ 10.000,00 a month, and tier 4 unlimited, is what the block illustrates;
> the tiers, their limits and who is in them are the operator's to decide and to defend.

| `caps` key | Default | |
|---|---|---|
| (the section itself) | absent | No ledger, no counting, no refusals. A section with no limit in it counts and refuses nothing |
| `tiers.<0-4>.dailyBrlCents` | none | BRL centavos one payer may move in a Brasília day. Absent: unlimited |
| `tiers.<0-4>.monthlyBrlCents` | none | The same for that day's calendar month. Must be at least the daily limit |
| `defaultTier` | `0` | The tier of a payer neither `TIER_MODULE` nor `payers` names |
| `unknownPayer` | `"refuse"` | A payment the bank attributes to nobody. `"refuse"`: not settled, and returned. `"allow"`: let through, uncounted. Neither applies while no tier states a limit |
| `payers[]` | `[]` | `{"payerRef": "0x…", "tier": n}` (preferred) or `{"payer": "<CPF/CNPJ/PIX key>", "tier": n}`, hashed on read |

A payer's tier is decided by, in order: **`TIER_MODULE`** (`export function createTierSource(env):
TierSource`, the shape of the other plugins - the LP's own KYC provider, and the only source that can
tier someone before their first payment; it is given the raw payer identity and sees no order, sale or
address, and one that throws falls back rather than promoting everyone), then `payers`, then
`defaultTier`.

`/status` (the **private** operations port) carries `caps`: the day being counted, the tiers, the
ledger's size, and each payer's `payerRef` with their day and month totals - which is how you read
someone's usage and how you get the `payerRef` to put in `payers`. It never carries a document.

| Metric | What it says |
|---|---|
| `mova_lp_caps_enabled`, `mova_lp_caps_ledger_rows` | 1 while caps are configured; rows the ledger holds |
| `mova_lp_caps_refusals_total{leg,reason}` | Payments refused, by `day`, `month` or `unknown_payer` |
| `mova_lp_caps_counted_cents_total{leg}`, `mova_lp_caps_uncounted_cents_total{leg}` | Centavos counted, and given back when the money went back |
| `mova_lp_caps_payers_today`, `mova_lp_caps_counted_today_cents` | Distinct payers and total centavos in the current Brasília day |
| `mova_lp_caps_last_count_timestamp_seconds` | When the ledger was last written; the monitor's `lp_node_caps` compares it with the last BRL attributed |
| `mova_lp_caps_tier_errors_total` | `TIER_MODULE` lookups that threw (the configured tier was used) |

The monitor watches a capping node with `lp_node_caps` (`LP_NODE_STATUS_URL`, packages/ops): it fails
while the node reports no caps, while it is counting into another Brasília day than today (a wrong
clock resets limits at the wrong hour), and while its ledger lags the last BRL it attributed - a
journal that could not be written, or one replaced under a running node.


## Transactions, the journal, the webhook and disputes

**Stuck transactions** (`tx-sender.ts`). Every write goes out at an explicit nonce with fees capped by
`tx.maxFeePerGasWei` / `tx.maxPriorityFeePerGasWei`, and its receipt is fetched by the hashes the node
broadcast - never through viem's waiter, which follows a replacement to the REPLACEMENT's receipt. A
transaction unmined `tx.replaceAfterBlocks` after it was last sent is re-sent at its nonce with both fees
raised by `tx.bumpBps` (at least 10%) and at least to the current estimate, up to the cap and never past it.
A nonce another transaction took is reported as `replaced`, and the handler re-reads the chain. A pending
transaction of this account left by an earlier process is found in the node's pending block and followed;
one that cannot be found and still blocks is cancelled by a zero-value transfer to self at its nonce. Gateway
intents replace their own transactions, journaling `gateway.replacing` before the broadcast and each new hash
after it, so an intent whose replacement mined is never mistaken for one that did not (`CONSUMED`, not
`DROPPED`). Without a `tx` section, fees are the node's estimate, uncapped, and nothing is replaced.

**Gas limits** (`tx-sender.ts`). Never the node's bare estimate: `eth_estimateGas` finds the least gas that
succeeds on the state it estimates at, and a transaction included a block later on a path a few gas costlier
runs out of gas at exactly that. Every write's limit is the estimate plus `tx.gasHeadroomPercent` (default 20)
percent plus 25,000 gas, never above the block gas limit; unused gas is not charged. A replacement keeps the
limit of the transaction it replaces. A write that reverts says why - `out of gas (used X of Y)`, the
contract's error replayed on the parent block, or `unknown` with what is known - in the handler's error and
in the gateway's `REVERTED` log line.

**Journal compaction** (`journal.ts`, `store.ts`). Past `compactJournalAtBytes`, at the end of a tick, the
journal is replaced by one `snapshot` record of the live state: written to `<journal>.compact`, fsynced,
renamed over the journal, the directory fsynced, appends reopened on the new file. A crash before the rename
leaves the old journal (the `.compact` file is deleted at load); after it, the new one, whole. Kept: the
cursor, every offer salt, followed offers not yet drained, every open order and sale with all their intents,
keys, disclosures, boletos, finished sales and gateway operations the 24-hour budget
and caps still count, the last final mint and redemption, open evidence, and used credits from
the last 30 days. Dropped: finished orders and sales.

**PIX webhook** (`POST /v1/webhook/pix` on the API listener; register `webhookUrl` = `https://<api>/v1/webhook`).
A latency optimisation only: the node takes the end-to-end ids out of the body (at most 100 per call), looks
each Pix up with `GET /pix/{e2eid}` (`BankAdapter.getIncoming`), and ticks at once instead of after
`pollMs`. Nothing else in the body - amount, key, txid - is used; polling stays the source of truth.
Authentication, `config.webhook.auth`:
- `hmac`: header `x-webhook-signature: sha256=<hex HMAC-SHA256 of the raw body>`, secret from
  `PIX_WEBHOOK_SECRET_FILE` (≥ 32 characters). For a PSP or intermediary that signs callbacks.
- `proxy-mtls` (API Pix's own scheme): terminate the PSP's mutual TLS at the reverse proxy, verify its
  certificate against the PSP's CA, and forward `X-SSL-Client-Verify: SUCCESS` (nginx:
  `proxy_set_header X-SSL-Client-Verify $ssl_client_verify;`). The node accepts the call only from a loopback
  peer with that header, so the API listener must be reachable only through the proxy.

**Dispute evidence** (`evidence.ts`, `config.arbitration.url`). When an order or sale of this LP is
DISPUTED, the node finds its case at the arbitration desk (`GET /cases?escrow=&orderId=`) or, if there is none,
opens one as `lp`, and
files one commitment per fact it holds - `pix-credit` / `boleto-credit` on the on-ramp,
`lp-payment` on the off-ramp - each an EIP-712 `Evidence` signature by the LP key over a keccak256 digest.
The digest commits to canonical JSON of the journaled record plus a fresh 32-byte salt kept in the journal:
`evidenceMaterial(kind, facts, salt)` regenerates the exact material to hand the arbitrator. Only digests,
kinds and signatures leave the node: no key, salt, bank id, payer document, amount or URI. Each
commitment is filed once, across ticks and restarts; a desk that is down is retried.

## Configuration

Secrets and addresses from the environment; strategy from `LP_CONFIG` (JSON).

| Variable | |
|---|---|
| `RPC_URL` | JSON-RPC endpoint (redacted everywhere) |
| `LP_KEY_FILE` / `LP_KEY` | The LP's wallet key, the address admitted in `LPRegistry`. Prefer the file; the variable is deleted after reading. |
| `PAYER_REF_SECRET_FILE` / `PAYER_REF_SECRET` | 32 bytes keying `payerRef` (a bare hash of a CPF is enumerable) |
| `STATE_FILE` | The journal. Persistent, encrypted, backed up, **one process per file** |
| `LP_CONFIG` | Strategy JSON, below |
| `BANK_MODULE` | Path to a module exporting `createBankAdapter(env): BankAdapter` |
| `PROVER_MODULE` | Path to a module exporting `createProvers(env): PaymentProver[]` |
| `TIER_MODULE` | Path to a module exporting `createTierSource(env): TierSource`: the LP's own per-payer tiers ([per-payer caps](#per-payer-caps)). Only with a `caps` section |
| `PIX_WEBHOOK_SECRET_FILE` / `PIX_WEBHOOK_SECRET` | With `webhook.auth: "hmac"`: the shared secret (≥ 32 characters) |
| `PORT` / `HOST` | Operations listener (default `9480`, `0.0.0.0`) - keep private |
| `API_PORT` / `API_HOST` | Counterparty API; if unset, both route sets share `PORT` |
| `API_ALLOWED_ORIGINS` | Comma-separated browser origins (`scheme://host[:port]`) allowed to call the counterparty API (CORS); default none, `*` and `null` refused |
| `CHAIN_ID` | Refuse to start if the RPC serves another chain |
| `LP_NODE_DEV=1` | Allows the in-memory `MockBank` and the local provers below. Never in production |
| `ZKTLS_WITNESS_KEYS_FILE` | Development only: `{"verifier", "threshold", "keys", "urlPrefix"}` - a `ZkTlsProver` whose `LocalWitnessSession` signs MockBank's records on `receiptTemplates(urlPrefix)`, for PIX and boleto. The verifier must allowlist those four templates under `urlPrefix` (the boleto pages for BOLETO) and these keys as witnesses |

Any variable whose name contains KEY, SECRET, TOKEN, PASSWORD or CREDENTIAL is added to the
redaction list, so a bank plugin's credentials are covered.

```jsonc
{
  "registry": "0x…", "fromBlock": "21000000",   // escrow deployment block
  "confirmations": 3, "reorgWindow": 64, "pollMs": 5000,
  "lpPayerId": "12345678000195",                  // how the LP's own account is identified in proofs
  "compactJournalAtBytes": 67108864,              // default 64 MiB
  "tx": { "maxFeePerGasWei": "200000000000", "maxPriorityFeePerGasWei": "3000000000",
          "replaceAfterBlocks": 3, "bumpBps": 1250, "waitBlocks": 30,
          "gasHeadroomPercent": 20 },                     // optional; the cap is required in it
  "webhook": { "auth": "proxy-mtls" },            // or {"auth":"hmac"}; optional
  "arbitration": { "url": "https://desk.example" },   // optional
  "onramp": {
    "escrow": "0x…", "pixKey": "12.345.678/0001-95",
    "receiver": { "name": "LP Liquidez Ltda", "city": "Sao Paulo" },
    "reclaimExpired": true, "autoRefund": true, "boletoDueDays": 3, "lateCreditGraceSeconds": 21600,
    // "static" (default), or "cob": an API Pix charge per PIX order, required where the PSP's API Pix lists only
    // charge-paid Pix (Banco Inter). cobMarginSeconds: a charge expires this long before payBy (default 300).
    "pixCharge": "static", "cobMarginSeconds": 300,
    "assets": [{
      "asset": "0x0000000000000000000000000000000000000000", "symbol": "ETH",
      "liquidity": "5000000000000000000", "minOrder": "10000000000000000", "maxOrder": "2000000000000000000",
      "verifier": "0x…", "rails": ["PIX", "BOLETO"],
      "spreadBps": 80, "minSpreadBps": 30, "maxOracleDeviationBps": 200, "bandMarginBps": 50,
      "refreshDriftBps": 50, "maxReferenceAgeSeconds": 300, "oracleStaleMarginSeconds": 300,
      "refillBelowBps": 5000, "maxOfferBrlCents": "10000000", "gasReserveWei": "50000000000000000",
      "price": { "source": "http", "url": "https://desk.example/eth-brl" }   // or {"source":"oracle"}
    }]
  },
  "offramp": {
    "escrow": "0x…", "rails": ["PIX", "BOLETO"], "maxOpenClaims": 2,
    "minTimeToPaySeconds": 1200, "disputeMarginSeconds": 420, "bankClockSkewSeconds": 5,
    "raiseDisputeWhenUnproven": true, "dailyBudgetCents": "5000000",
    "assets": [{ "asset": "0xdAC1…", "symbol": "USDT", "minMarginBps": 50, "minSaleBrlCents": "1000",
                 "maxSaleBrlCents": "500000", "price": { "source": "oracle" } }]
  },
  // Optional: per-payer daily and monthly limits (Rev. 2 §10.1). Absent: no ledger, no limits.
  // The numbers here are an EXAMPLE; nothing ships with a limit set. See "Per-payer caps".
  "caps": {
    "defaultTier": 0, "unknownPayer": "refuse",
    "tiers": { "0": { "dailyBrlCents": "200000", "monthlyBrlCents": "1000000" }, "4": {} },
    "payers": [{ "payerRef": "0x…", "tier": 3 }]
  },
  // Optional: operate as a Movva gateway. List gateway.movva as an asset on either leg,
  // with "price": {"source":"par"}.
  "gateway": {
    "reserve": "0x…", "usdt": "0xdAC1…", "movva": "0x…",
    "mint":   { "maxMintUsdt": "50000000000", "maxMintUsdtPerDay": "200000000000", "usdtCostBps": 30,
                "maxFeeBps": 10, "minMintUsdt": "1000000", "keepUsdt": "0", "maxSlippageBps": 10 },
    "redeem": { "keepMovva": "10000000000000000000000", "maxRedeemMovva": "100000000000000000000000",
                "maxRedeemMovvaPerDay": "500000000000000000000000", "usdtSaleBps": 30, "maxFeeBps": 10,
                "minRedeemMovva": "10000000000000000000", "minCollateralRatioBps": 10000, "maxSlippageBps": 10 },
    "maxRateDeviationBps": 100, "maxReferenceAgeSeconds": 300,
    "usdtPrice": { "source": "http", "url": "https://desk.example/usdt-brl" }   // optional
  }
}
```

An HTTP price source must return `{"brlCentsPerUnit": "<integer>", "updatedAt": <unix seconds>}`
(centavos per whole unit). `{"source":"oracle"}` uses the escrow's oracle as the reference, which
makes the deviation check vacuous: it is the choice to trust the escrow's own price - Chainlink's USD price
crossed with Pyth's FX.USD/BRL, which off-hours is the last close.
`{"source":"par"}` is 100 centavos, always, and is accepted only for `gateway.movva`.

| `gateway` key | Default | |
|---|---|---|
| `reserve`, `usdt`, `movva` | required | Checked at start: the reserve has code, its `USDT()` and `MOVVA()` are these, and each escrow listing Movva uses the reserve as its oracle |
| `mint.enabled` / `redeem.enabled` | `true` | The node's own switch. On an enabled side every limit and cost below marked required must be set |
| `mint.maxMintUsdt`, `mint.maxMintUsdtPerDay` | required | USDT base units; per mint, and over the trailing 24 h |
| `mint.minMintUsdt` | `1000000` (1 USDT) | A shortfall needing less is not minted |
| `mint.keepUsdt` | `0` | USDT never minted |
| `mint.usdtCostBps` | required | What the LP pays for USDT above the reserve's rate: priced into Movva offers |
| `mint.maxFeeBps`, `redeem.maxFeeBps` | `0` | The reserve's fee the node accepts. A fee raised on-chain stops the node until the LP raises this |
| `mint.maxSlippageBps`, `redeem.maxSlippageBps` | `10` | 1 to 500. `minMovvaOut` / `minUsdtOut` = preview less this |
| `redeem.keepMovva` | `0` | The Movva working balance |
| `redeem.minRedeemMovva` | `10e18` | Less above the working balance is left for later |
| `redeem.maxRedeemMovva`, `redeem.maxRedeemMovvaPerDay` | required | Movva base units |
| `redeem.minCollateralRatioBps` | `10000` | 5000 to 20000. Below it, hold rather than redeem at a haircut |
| `redeem.usdtSaleBps` | required | What the LP loses selling USDT for reais below the rate: priced into Movva sales |
| `usdtPrice` | none | The LP's USDT/BRL price (HTTP, centavos per USDT). Without it, the reserve's rate is taken as the market |
| `maxRateDeviationBps` | `100` | With `usdtPrice`: a reserve rate further from it stops mint and redeem |
| `maxReferenceAgeSeconds` | `300` | With `usdtPrice`: older is unusable |

### The bank plugin

`bank.ts` is the contract. Receiving is standardised in Brazil (API Pix: `/v2/pix`, webhooks,
devolução); **sending is not** - PIX initiation, boleto payment and boleto registration are
bank-specific APIs, so each LP writes `createBankAdapter`. The adapter MUST make two calls with one
idempotency key move money at most once, report `SETTLED` only when the SPI settled (with the
end-to-end id and settlement time), and return the bank's own identifiers. `MockBank` is the
reference implementation of those rules.

**Banco Inter** (`src/banks/inter.ts`, `BANK_MODULE=packages/lp-node/src/banks/inter-module.ts`) is a
production adapter written against Inter's published OpenAPI documents (read 2026-09-14; sources in
`src/banks/inter-client.ts`) and tested against a mock built from them (`test/banks/`). Pix goes out by
`POST /banking/v2/pix` under `x-id-idempotente` (a UUID v5 of the node's key), boletos are paid by
`POST /banking/v2/pagamento` after a look-up by barcode, registered and cancelled through Cobrança v3, and
API Pix (`ApiPixReceiver`) receives. OAuth2 client credentials in the form body, mTLS on every call, the
documented per-minute limits kept locally, 429 retried only where a repeat cannot pay twice.

| Variable | |
|---|---|
| `INTER_API_URL` | `https://cdpj.partners.bancointer.com.br`, or the sandbox `https://cdpj-sandbox.partners.uatinter.co` |
| `INTER_CLIENT_ID`, `INTER_CLIENT_SECRET_FILE` | The integration's credentials; the secret only from a file |
| `INTER_CERT_FILE`, `INTER_CERT_KEY_FILE`, `INTER_CA_FILE` | The certificate downloaded with the integration (the CA is optional) |
| `INTER_STATE_PATH` | The adapter's own journal of what it sent. **As durable as `STATE_FILE`**: Inter cannot be asked for a Pix by idempotency id, so with both lost the node gives back a claim it paid (it still never pays twice) |
| `INTER_ACCOUNT` | `x-conta-corrente`, for an integration with more than one account |
| `INTER_BOLETO_PAYER_FILE` | The `pagador` Cobrança requires; without it boletos are not registered |
| `INTER_SCOPES` | Override the scopes requested. The default includes `cob.read` and `cob.write`, which `onramp.pixCharge: "cob"` needs - and an LP at Inter needs cob, because Inter's API Pix lists only charge-paid Pix |

Before trusting it with money: turn manual approvals off for the integration (approved payments stay
`PENDING`), and run `examples/bank-sandbox-check.ts` against the sandbox. Inter's API Pix lists only Pix
paid to cob/cobv charges, so check that on-ramp credits to the static BR Code appear, or run the on-ramp with
[`pixCharge: "cob"`](#pix-charges-cob) - which needs `InterApiPixClient` to route `PUT|GET|PATCH /cob/{txid}`
(today it routes only `/pix` and devolução, and a charge call fails).

### API Pix (Banco Central), for the receiving side

`api-pix.ts` implements the standard part from the published OpenAPI document (API Pix 2.10.0):
OAuth2 client credentials with HTTP Basic, mTLS with the PSP-issued certificate on every call
(token included), `GET /pix` with RFC 3339 `inicio`/`fim` and `paginacao.*` paging,
`PUT|GET /pix/{e2eid}/devolucao/{id}` for refunds (looked up by the idempotency key before a PUT,
because the spec does not define a repeated PUT), `PUT|GET|PATCH /cob/{txid}` for immediate charges,
`PUT /webhook/{chave}`, and `parseWebhookPix` for the `{ "pix": [...] }` the PSP POSTs to
`webhookUrl/pix`. A plugin joins it with the bank's own sending API:

```ts
export function createBankAdapter(env) {
  const client = new ApiPixClient({
    baseUrl: env.PIX_API_URL, tokenUrl: env.PIX_TOKEN_URL, clientId: env.PIX_CLIENT_ID,
    clientSecret: readFileSync(env.PIX_CLIENT_SECRET_FILE, 'utf8').trim(),
    tls: { cert: readFileSync(env.PIX_CERT_FILE), key: readFileSync(env.PIX_KEY_FILE), ca: readFileSync(env.PIX_CA_FILE) },
  });
  return composeBank(new ApiPixReceiver(client), new MyBankSendingAdapter(env)); // sendPix, payBoleto, getOutgoing, ...
}
```

Two consequences of the standard worth knowing: the `Pix` record carries **no payer document**
(only `infoPagador` free text), so `payerRef` is keyed on an empty payer id with this adapter; and
the webhook fires only for Pix that carry a txid, which the BR Codes the node serves always do.
Polling `/pix` stays the source of truth; the webhook is a latency optimisation.

### PIX charges (cob)

`onramp.pixCharge` is `"static"` by default: each PIX order is served a BR Code for `pixKey` that the node builds,
and credits match by its txid (or by an amount exactly one order fits). Set `"cob"` where the PSP's API Pix lists
only Pix paid to a charge - Banco Inter documents `GET /pix`, `GET /pix/{e2eId}` and its webhook that way - so a
static-code credit might never be seen. Sources: API Pix OpenAPI 2.10.0 (`github.com/bacen/pix-api`), Manual de
Padrões para Iniciação do Pix 2.10.0, read 2026-09-14.

- **Creation.** Once the lock has N confirmations: `PUT /cob/{txid}` with `valor.original` = `brlCents`,
  `modalidadeAlteracao: 0`, `chave` = the LP's key, `calendario.expiracao` ending `cobMarginSeconds` (default 300,
  at most 1500) before `payBy`. The txid is `idempotencyKey('order-cob', chainId, escrow, orderId)` (33 of the
  26-35 alphanumerics allowed, never reused), journaled before the call; any retry or restart `GET`s it before a
  second `PUT`, so a lost response never makes two charges. What comes back must be that charge (txid, amount,
  fixed, key, expiry by `payBy`, a location); anything else is removed and the order held.
- **Instructions** add `charge: "cob"`, the PSP's `pixCopiaECola`, its `location`, the `txid` and `expiresAt`,
  beside the key and salt; 409 until the charge exists. The location is a capability URL: never logged, not in `/status`.
- **Matching** is by that txid only, never by amount.
- **Cancellation.** An order that ends unreleased has its charge removed (`PATCH /cob/{txid}` to
  `REMOVIDA_PELO_USUARIO_RECEBEDOR`) once that is N blocks deep; a credit that lands anyway is refunded as before.

The bank adapter needs `createCharge` and `getCharge` (and `cancelCharge`): `composeBank(new ApiPixReceiver(...), ...)`
provides them over API Pix, `MockBank` in memory (`MockPixQrSite` serves its locations, signed, for tests). A PIX
order in `cob` mode with an adapter lacking them is held. Wallets verify the served charge against the PSP's signed
payload (@mova/wallet `pix-cob.ts`) and must list the PSP's QR code host in `pixLocationHosts`.

### The prover plugin

`createProvers(env)` returns one `PaymentProver` per verifier address: a `ZkTlsProver` for the
`ReclaimZkTlsVerifier` your bank offers and every sale name. The zkTLS session is where your Reclaim credential and your bank's
page templates go:

```ts
// PROVER_MODULE=/app/plugins/provers.js
import { createPublicClient, http } from 'viem';
import { ZkTlsProver, type ZkTlsSession } from '@mova/lp-node';
import { ReclaimClient, prepareSettlement } from '@mova/ramp';

export async function createProvers(env) {
  const client = createPublicClient({ transport: http(env.RPC_URL) });
  // One Reclaim provider per receipt page of YOUR bank (req.receipt: pix-received, pix-sent, boleto-received,
  // boleto-paid), each allowlisted on the verifier; the templates must capture all six fields the verifier reads.
  const session: ZkTlsSession = {
    async prove(req) {
      const reclaim = new ReclaimClient({ appId: env.RECLAIM_APP_ID, providerId: env[`RECLAIM_PROVIDER_${req.receipt}`] });
      const { sessionId, url } = await reclaim.requestProof(req.binding); // bound to the order or sale id
      await yourBankSession(url, req); // your client, logged in to your bank, opens the page for req.bankTxId
      return reclaim.awaitProof(sessionId); // converted with fromReclaimProof, signatures sorted
    },
  };
  return [
    new ZkTlsProver(env.ZKTLS_VERIFIER, session, { preflight: async (p) => { await prepareSettlement(client, env.ZKTLS_VERIFIER, p); } }),
  ];
}
```

A verifier with no
prover for a rail makes the on-ramp passive on it (the taker proves) and excludes its sales from the off-ramp.

## Counterparty API

- `POST /v1/onramp/instructions` `{orderId, issuedAt, signature}` - EIP-712
  `PaymentInstructionsRequest(bytes32 orderId, uint64 issuedAt)` under domain
  `{name: "Mova-LP-Node", version: "1", chainId, verifyingContract: FiatEscrow}`, signed by the
  order's taker (ERC-1271 accepted), within 5 minutes. `signInstructionsRequest` builds it. Returns
  the PIX key, salt, commitment, BR Code and `payBy` (with `pixCharge: "cob"`, the PSP's dynamic BR Code, `charge`,
  `location`, `txid` and `expiresAt`; 409 until the charge exists), the boleto line and salt (409 until issued).
- `POST /v1/offramp/payee` `{saleId, pixKey | boletoLine, salt}` - 201 when it opens the sale's
  commitment (and, for a bill, the amount matches and it is not overdue); 422 otherwise, never
  echoing what was sent.

A refusal a wallet should be able to act on carries a stable `code` beside its sentence:
`{"error": "…", "code": "cap_reached"}` on `/v1/onramp/instructions` and `/v1/offramp/payee` when
[per-payer caps](#per-payer-caps) are in force (`payer_unidentified` when the bank named no payer).
The node states *that* a limit was reached and never the payer's total or the limit itself;
`LpNodeError.code` in `@mova/wallet` carries it through, and only codes that package knows.

Put the API behind TLS and rate limiting; it is the only internet-facing surface.

**CORS.** A browser wallet served from another origin can call these three routes only if its origin is listed:
`serveLpNode(node, { mode: 'api', cors: { allowedOrigins: ['https://wallet.example'] } })` (`CorsPolicy` in
`@mova/ramp`). Each entry is an exact origin - `scheme://host[:port]`, http or https, no path - and `*` and `null` are
refused at startup, since either would let any page read the answers. The default is no origins: no CORS headers, and
every preflight (`OPTIONS`) on these routes answered 403. For a listed origin, every response on the three routes carries
`Access-Control-Allow-Origin` and `Vary: Origin` - refusals (400, 401, 404, 409, 413, 422, 500) included, so the wallet
can show why - and a preflight gets 204 with the route's method, `content-type` and a 10-minute max age. Credentials are
never allowed: the taker proves itself with a signature, not a cookie. CORS is not access control - a non-browser client
is answered whatever its `Origin` - and the operations routes and the PSP webhook never send CORS headers.

## Operations

`/healthz` is liveness only; `/readyz` is 200 after a completed tick; `/status` lists quoting state
per asset, tracked orders and sales (ids, states, holds - no keys or payees), and for a gateway
`gateway.market` (`open`, `closed`, `unreadable`), `gateway.mint` / `gateway.redeem` (`canMint`, `canRedeem`, every
`blocked` reason, `held`, the last final mint and redemption), wallet balances, the reserve's ratio, rate, band
reading, pause, freeze, supply and fees, and open intents; `/metrics` exports `mova_lp_*`. Alert on:

| Metric | Why |
|---|---|
| `mova_lp_payments_unresolved > 0` for > 10 min | A transfer whose outcome is unknown |
| `mova_lp_held > 0` | The node stopped acting on something and needs a human |
| `mova_lp_disputes_open > 0` | File evidence with the arbitration desk |
| `mova_lp_unreconciled_credits > 0` | BRL arrived that matches no order |
| `mova_lp_quoting == 0` | Offers pulled; `mova_lp_quote_pulled_total{reason}` says why |
| `time() - mova_lp_last_tick_timestamp_seconds > 120` | The loop is stuck or the RPC is down |
| `increase(mova_lp_tx_fee_capped_total[15m]) > 0` | A stuck transaction the fee cap allows no further bump for: raise `tx.maxFeePerGasWei` or wait for fees to fall; everything after it waits |
| `increase(mova_lp_tx_cancelled_total[1h]) > 0` | A pending transaction nobody could identify was cancelled at its nonce: check the account's history |
| `increase(mova_lp_evidence_errors_total[1h]) > 3` | Evidence for a dispute is not reaching the arbitration desk |
| `increase(mova_lp_webhook_requests_total{result="unauthorised"}[1h]) > 10` | Someone is posting to the webhook without the proxy's verification or the secret |
| `mova_lp_credit_cap_cents == 0` | Suspended or not admitted |
| `rate(mova_lp_reorgs_total[1h]) > 0` | Check `confirmations` is enough for the chain |
| `mova_lp_gateway_held{reason!="market_closed"} > 0` | `below_par`: the reserve is under-backed and the node is holding Movva rather than redeem at a haircut - follow the issuer's recapitalisation. `nonce_gap`: a gateway intent cannot be accounted for; inspect the account's pending transactions |
| `mova_lp_gateway_market_closed == 1` outside weekend and holiday hours, for > 30 min | Expected while FX.USD/BRL is closed (`held{reason="market_closed"}`: the node sells Movva it holds, and mints and redeems on Monday). Inside New York trading hours it means the Pyth keeper posted nothing today |
| `mova_lp_gateway_blocked{op="mint"} == 1` for > 15 min | The node cannot mint; `reason` says why (`mint_paused`, `rate_stale`, `below_mint_ratio`, `supply_cap`, `fee_too_high`, `daily_cap`, `insufficient_usdt`, `reserve_unreadable`, ...). Movva offers drain meanwhile |
| `mova_lp_gateway_blocked{reason="rate_stale"}` | The Pyth keeper or Chainlink stopped, and the band refuses too: Movva is neither quoted nor bought. (`mova_lp_gateway_rate_readable == 0` alone is also every closed-market hour: read it beside `market_closed`) |
| `mova_lp_gateway_pending > 0` for > 10 min | A mint or redemption is not yet final: stuck in the mempool, or waiting on confirmations |
| `increase(mova_lp_gateway_mints_total{outcome=~"reverted\|consumed"}[1h]) > 0` | A mint reverted at inclusion (the rate moved past the slippage bound) or its outcome had to be inferred after a crash |

Gateway counters and gauges: `mova_lp_gateway_mints_total{outcome}` and `mova_lp_gateway_redeems_total{outcome}`
(`mined`, `reverted`, `dropped`, `consumed`), `mova_lp_gateway_usdt_minted_units_total`,
`mova_lp_gateway_movva_minted_cents_total`, `mova_lp_gateway_movva_redeemed_cents_total`,
`mova_lp_gateway_usdt_redeemed_units_total`, `mova_lp_gateway_usdt_balance_units`,
`mova_lp_gateway_movva_balance_cents`, `mova_lp_gateway_collateral_ratio_bps`,
`mova_lp_gateway_last_mint_timestamp_seconds`, `mova_lp_gateway_last_redeem_timestamp_seconds`.

## Failure modes

| Failure | What happens |
|---|---|
| Crash or kill -9 at any point | Restart replays the journal; an intent without a result is resolved by `getOutgoing(key)`, then by repeating under the same key while a confirmed claim stands. Tested with a lost bank response and with a refused connection |
| Journal lost | The node rescans from `fromBlock`. Payment keys are derived from the sale id, so the bank refuses a second transfer and the node adopts the payment it reports. Payee disclosures and offer salts are gone: sellers must disclose again, and orders against old offers cannot be served instructions. Restore from backup |
| Two processes, one key | Unsupported: nonce races and, with two journals, no shared view of intents |
| RPC down | Ticks fail and are counted; nothing is paid, because nothing can be confirmed |
| Reorg deeper than `confirmations` | Outside the safety assumption. Choose N for the chain (Ethereum L1: finality, or ≥ 12) |
| Bank down | Matching and payments stop; claimed sales near `payBy` are abandoned before paying (`minTimeToPaySeconds`); a paid-but-unproven sale is disputed at `payBy - disputeMarginSeconds` |
| zkTLS session or witnesses down | On-ramp: the taker may still prove; otherwise orders expire and BRL received is refunded after confirmed cancellation. Off-ramp: a paid sale is disputed in time. Tested |
| FX market closed (weekends, 25 Dec, 1 Jan, outside the core session) | Offers and sales keep trading against the last close; no mint or redemption is planned (`market_closed`); Movva offers post only from the wallet. Resumes by itself on the first price of the reopened market. Tested |
| A PIX or boleto asset on a verifier that does not prove the bank session | Refused at startup (`provesBankSession()` on-chain); a bank book whose verifier's prover proves none of its rails, or that the escrow refuses, is pulled (`bank_rail_needs_zktls`). Tested |
| Reference feed wrong | Beyond `maxOracleDeviationBps` from the oracle: offers pulled, sales skipped. Within it: can only make offers dearer and purchases pickier |
| Oracle stale / delisted / verifier revoked / credit 0 | Offers pulled |
| Bank clock behind the chain | A receipt that predates the lock/claim cannot prove; `bankClockSkewSeconds` delays off-ramp payments; on-ramp credits that predate are refunded after expiry |
| A PIX credit is later reversed (MED) | Not handled: the escrow already released. The LP's recourse is the dispute path, off-chain |
| Crash between USDT approval and mint | No intent was written; the restart re-reads the allowance and re-plans from fresh balances. Tested |
| Crash after a mint or redemption is broadcast, before its hash is journaled | The intent's nonce is pending: the node waits, then counts it once its nonce is spent at the confirmed block (`CONSUMED`). If the broadcast reached nobody, the nonce is free and is reused, so a copy that surfaces later cannot mine. Tested, including a copy re-injected afterwards |
| A reorg removes a mint | Re-queued by the node: it waits for it. Dropped: its nonce is free, and one mint is sent again. Either way one mint exists. Tested |
| Reserve mint paused, Tether freezes the reserve or the LP, rate stale, ratio under the mint floor, supply cap reached, fee above `maxFeeBps` | No mint is simulated or sent; `mova_lp_gateway_blocked{op="mint",reason}`. The Movva offer drains and is not refilled; a stale rate also pulls it |
| Reserve under par | Movva offers pulled (par and the reserve disagree); Movva sales not claimed; redemptions held (`below_par`) unless `minCollateralRatioBps` allows. Redemptions resume by themselves when the ratio recovers |
| Rate moves past the slippage bound before inclusion | The mint or redemption reverts (`outcome="reverted"`); nothing moved but gas. Re-planned next tick at the new rate |
| Reserve short of liquidity (vault funds lent out) | Redeems what can be paid now; the rest waits (`insufficient_liquidity`) |
| Mint fee raised on-chain | The cost floor rises with it; above `maxFeeBps`, minting stops until the LP agrees |
| Nonce gap under an open gateway intent | Held (`nonce_gap`): nothing new is minted or redeemed until a human resolves it |
| A transaction stuck under rising fees | Replaced at its nonce after `replaceAfterBlocks`, bumped, up to the cap; at the cap, `mova_lp_tx_fee_capped_total` and it waits. Tested against a scripted node with geth's replacement rules |
| Another transaction takes a write's nonce (same key elsewhere) | The write fails as `replaced`; its receipt is never taken for ours. Tested |
| Restart with this account's transactions still pending | Found in the pending block and followed; one that cannot be found is cancelled once it has blocked `replaceAfterBlocks`. Tested |
| Crash during journal compaction | Old journal whole before the rename, new journal whole after; a leftover `.compact` is deleted at load. Tested at each step, with torn files |
| Webhook forged or replayed | Costs one `GET /pix/{e2eid}` per id; nothing from the body is matched. Unauthenticated calls are refused. Tested |
| Arbitration desk down | Evidence is retried every tick; the commitment, fixed in the journal, is the one filed |

## Tests

```bash
npx vitest run packages/lp-node                   # unit: in-memory chain (test/fake-chain.ts), MockBank,
                                                  # a mock API Pix PSP over HTTP and over mTLS (needs openssl)
LP_NODE_FORGE_OUT=<forge out> npx vitest run packages/lp-node/test/abi.test.ts   # ABI vs artifacts

# end to end on anvil :8745 against the real contracts: the FX leg from Pyth (MockPyth), PIX and boleto on
# ReclaimZkTlsVerifier with local witnesses (both ramps, a boleto payout included), # and a per-payer daily cap refusing a third purchase without moving anything
# (MockBank, local keys); pass an rpc to use your own anvil
FOUNDRY_OUT=<forge out> npx tsx packages/lp-node/examples/lp-node-live.ts [rpc]

# the Movva gateway end to end on anvil :8749: the real MovvaReserve, Movva, YieldVault +
# ERC4626Adapter, a Tether-like USDT, PythFxOracle as the FX leg, both escrows with Movva listed on zkTLS -
# and a weekend: anvil moved to a Saturday (mint and redeem held as market_closed, Movva still sold), then Monday
FOUNDRY_OUT=<forge out> npx tsx packages/lp-node/examples/lp-node-movva-live.ts [rpc]
```

`test/zktls.test.ts` attacks the bank-rail proofs: a claim bound to another order (refused by the prover, and by the
fake verifier as `OrderMismatch`), too few or unknown witnesses, a page not allowlisted or allowlisted for the other
rail, a payment the bank does not show or that does not prove the order, a second payment for a proven order; a
verifier that does not prove the bank session refused for PIX and boleto offers and sales; PIX and boleto payouts settled from the sent-payment and paid-bill
pages; a bill with no due date at a bank that needs one (`boleto_no_due_date`); a disclosure on a rail the node does
not pay. The fake chain verifies zkTLS proofs as ReclaimZkTlsVerifier does (witness signatures, identifier,
`contextMessage`, endpoint and rail) and refuses bank rails on any other verifier, as the escrows do.
`test/safety.test.ts` has one `describe` per safety property: confirmations before paying (incl. a
reorged claim), intent-before-bank and crash recovery (lost response, refused connection, lost
journal, refund), journal torn-tail recovery and 0600, reorg rewind, bounded exposure under a wrong
reference (property-based), redaction of logs/`/status`/`/metrics`, and key material only from
env/file.

`test/tx-sender.test.ts` drives the sender against a scripted node
with geth's replacement rules; `test/compaction.test.ts` crashes compaction at each step; `test/webhook.test.ts`
forges and replays webhooks; `test/evidence.test.ts` files evidence with the real arbitration desk service and
searches every byte sent for the payment's data.

`test/caps.test.ts` drives the per-payer caps from the bank rather than the chain: a payer at
their limit refused while the order stays LOCKED and nothing leaves the escrow; a partial credit counted at what
arrived, not at the order, with the rest of the allowance still usable; a monthly limit refusing what the daily one
allows; two orders from one payer on one counter and a second payer on their own; a refused payment the taker proved and released themselves, counted after
the fact because the LP kept the BRL; the day rolling at midnight in Brasília and NOT at midnight UTC; a restart and a compacted journal still refusing; an unattributable payment
refused (and allowed where nothing is limited); the configured payer list and a `TIER_MODULE` that decides first,
sees no order or address, and falls back rather than promoting everyone when it throws; the off-ramp refusing a disclosure and skipping a claim (`payer_cap`) and giving the
allowance back when the bank refuses the payment; and `/status` carrying payer hashes and totals but no document.

`test/gateway-safety.test.ts` does the same for the gateway, against a reserve model in the fake chain
that refuses as the contract does (and a USDT whose approve refuses as Tether's does, and a mempool with
nonces): no mint is even simulated while paused, frozen (reserve or LP), stale, under the ratio floor, at
the supply cap, over the fee, or unreadable; `minMovvaOut` binds when the rate moves before inclusion;
no redemption below par by default; the approve quirk; a crash after the approval, after the broadcast
(reached the mempool, or reached nobody and later surfaced), and after the mint mined; a reorg that
re-queues or drops a mint, including one the node had already seen mined but not N deep; a nonce gap;
the per-mint and daily caps; and a property test over random interleavings of drains, cancellations,
restarts, held, lost and dropped sends, reorgs shallower than `confirmations`, pauses, freezes, stale
rates, rate moves and supply caps (and it asserts it exercised mints, repeat mints and crashes): nothing refused is attempted, every mint is to a need (wallet + offer +
mint within the target plus one USDT unit), within the caps, and never sent beside another gateway
transaction that could still mine or is not yet final. Off-hours, with a Pyth-shaped FX leg on the fake reserve:
from Friday's core session to a Saturday (both sides held as `market_closed`, the offer topped up from the wallet,
nothing simulated) to Monday before the keeper's price (`rate_stale`) and after it (redeemed). `test/gateway.test.ts`
covers the happy paths, pricing and `/status`/`/metrics`.

## Not yet

- A sending adapter for any real bank (by design: it is bank-specific), and a webhook receiver
  wired into the node's HTTP surface (`parseWebhookPix` exists; polling covers it meanwhile).
- A production `ZkTlsSession`: it needs a Reclaim application credential, provider templates for the LP's bank's
  four receipt pages (with hashed redactions for the payee commitment and `payerRef`), and the LP's authenticated
  client for them - the interface, the checks around it and `PROVER_MODULE` are here; `LocalWitnessSession` is the
  development stand-in.
- TED payouts (need account details, not a key), MED reversal handling.
- Handing the arbitrator the evidence material itself (the LP does, with `evidenceMaterial`). A desk without
  `GET /cases?escrow=&orderId=` is refused (`the arbitration desk has no case lookup by order`), not worked around.
- Per-payer caps: the tier numbers themselves (the operator's, and unset here); a shared view of a person
  across LPs (deliberately absent - it would need an identity registry every LP could read); and a cap on a
  payer the bank does not name, which API Pix 2.10.0 cannot supply.
- Gateway: redeeming by `permit` instead of an approval; hedging the USDT the LP holds between minting
  and selling; selling redeemed USDT for BRL (that is the LP's desk, outside the node).
