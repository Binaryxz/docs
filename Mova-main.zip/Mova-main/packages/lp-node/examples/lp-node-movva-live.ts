/**
 * The LP node as a Movva gateway, end to end, against the real contracts on a local anvil.
 *
 * Deploys Movva as contracts/test/MovvaReserve.t.sol wires it offline - a Tether-like USDT (no return
 * values, approve refuses non-zero to non-zero, sender-only blacklist), a settable Chainlink USDT/USD
 * feed, the FX leg from Pyth (MockPyth's FX.USD/BRL read by PythFxOracle in millionths of a real),
 * MovvaReserve (which deploys Movva), and a real YieldVault(USDT) with an ERC4626Adapter over an
 * Aave-wrapper-like target - and the ramp with Movva listed on both escrows and the reserve as its band
 * oracle, settling PIX on a ReclaimZkTlsVerifier whose witnesses are local keys. The LP is admitted as a
 * gateway and as an institutional LP, setup is closed everywhere, and then the NODE does the gateway's job. The reserve pays
 * its fees to a FeeSplitter that forwards 20% to NodeRewards (node-provider rewards, docs/movva.md "Fees"), whose registry
 * hook counts the LP's settled volume:
 *
 *   1. mint: the Movva offer needs 2.000 Movva and the wallet has none, so the node mints exactly that
 *      from its USDT - zeroing a leftover allowance first, which real Tether bytecode insists on - and posts;
 *   2. on-ramp by PIX: a taker locks 600 Movva, fetches signed-for instructions, pays; the node proves the credit by
 *      zkTLS and releases;
 *   3. top-up: the node mints only the 600 the taker drained;
 *   4. off-ramp by PIX: the same user sells 500 Movva back; the node claims, waits for confirmations,
 *      pays, proves the PIX it sent by zkTLS, settles - and redeems the Movva above its working balance for USDT:
 *      supply falls;
 *   5. node rewards are funded: the mint and redeem fees sit in the FeeSplitter; anyone splits them, 20% to NodeRewards
 *      and the rest to Mova's treasury, and NodeRewards has counted both settlements for the LP;
 *   6. the reserve pauses minting: the node reports why it cannot mint;
 *   7. the reserve falls under par: the node pulls the Movva offer and HOLDS the Movva it would otherwise
 *      redeem; back at par, it re-posts from the wallet without minting and redeems the rest;
 *   8. the FX market closes: anvil is moved to a Saturday and Pyth's last price is Friday's close. The reserve refuses
 *      its rate (`StaleRate`) and its band reads the close, so the node holds mint and redeem as `market_closed` while
 *      the Movva offer stays posted - a user buys Movva by PIX on the Saturday, and nothing is minted - and Movva above
 *      the working balance waits. On Monday, in the core session, Friday's price is refused by the band too; the
 *      keeper posts a fresh price and the node redeems what it held;
 *   9. the rewards epoch has ended and its review has passed: the node finalizes it and claims the LP's share, paid to
 *      the LP's rewards wallet;
 *  10. a new process over the same journal: nothing is minted, redeemed or claimed twice.
 *
 * The bank is MockBank, Pyth is MockPyth and the zkTLS witnesses are local keys. Everything else on-chain is the real
 * bytecode.
 *
 *   FOUNDRY_OUT=<build dir> npx tsx packages/lp-node/examples/lp-node-movva-live.ts [rpc]
 *
 * Without an rpc argument it starts its own anvil on port 8749 with one-second blocks, and stops it at
 * the end. (examples/lp-node-live.ts uses 8745: the two can run side by side.)
 */
import { spawn, type ChildProcess } from 'node:child_process';
import { mkdtempSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  createPublicClient, createWalletClient, defineChain, encodeAbiParameters, formatUnits, http, parseEther,
  type Abi, type Account, type Address, type Chain, type Hex, type PublicClient, type Transport, type WalletClient,
} from 'viem';
import { generatePrivateKey, privateKeyToAccount } from 'viem/accounts';
import {
  RECEIPT_KINDS, Rail, hashProviderParams, newPixSalt, pixKeyCommitment, prepareSettlement, railMask, receiptRail, receiptRailMask,
  receiptTemplates,
} from '@mova/ramp';
import { parsePixBrCode } from '@mova/wallet';
import {
  ChainRevert, JsonlJournal, LocalWitnessSession, LpNode, MockBank, OrderState, ParPriceFeed, RESERVE_ABI, SaleState, ViemRampChain,
  ZkTlsProver, serveLpNode, signInstructionsRequest, toChainRevert, type GatewayOptions, type LpNodeOptions, type LpRecord,
} from '../src/index.js';

const ROOT = fileURLToPath(new URL('../../../', import.meta.url));
const OUT = process.env.LP_NODE_FORGE_OUT ?? process.env.FOUNDRY_OUT ?? join(ROOT, 'forge-out');
const PORT = 8749;
const RPC = process.argv[2] ?? `http://127.0.0.1:${PORT}`;
const ANVIL = join(ROOT, '.foundry-pinned/v0.3.0/anvil');

const started = Date.now();
const step = (s: string) => console.log(`\n\x1b[1m${s}\x1b[0m  (+${Math.round((Date.now() - started) / 1000)}s)`);
const ok = (s: string) => console.log(`  \x1b[32mOK\x1b[0m    ${s}`);
const info = (k: string, v: unknown) => console.log(`        ${k.padEnd(30)} ${v}`);
class Failed extends Error {}
const check = (cond: unknown, what: string): void => {
  if (!cond) {
    console.log(`  \x1b[31mFAIL\x1b[0m  ${what}`);
    throw new Failed(what);
  }
  ok(what);
};
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const movvaFmt = (v: bigint) => `${formatUnits(v, 18)} Movva`;
const usdtFmt = (v: bigint) => `${formatUnits(v, 6)} USDT`;

const art = (name: string, file = `${name}.sol`): { abi: Abi; bytecode: Hex } => {
  const j = JSON.parse(readFileSync(join(OUT, file, `${name}.json`), 'utf8')) as { abi: Abi; bytecode: { object: Hex } };
  return { abi: j.abi, bytecode: j.bytecode.object };
};

const GOVERNANCE_DELAY = 24n * 3600n;
const DISPUTE_TIMEOUT = 30n * 24n * 3600n;
const TIER_INSTITUTIONAL = 3;
const U = 10n ** 6n;
const E18 = 10n ** 18n;
/** R$ 5,40 per US dollar, at 1e-6: the unit the reserve prices in, posted to Pyth at exponent -6. */
const FX_E6 = 5_400_000n;
/** Pyth's FX.USD/BRL id (DeployRamp's PYTH_FX_USD_BRL). */
const FX_USD_BRL_ID: Hex = '0xd2db4dbf1aea74e0f666b0e8f73b9580d407f5e5cf931940b06dc633d7a95906';
/** Where the LP's bank serves its receipt pages; the zkTLS verifier allowlists the templates under it. */
const BANK_URL_PREFIX = 'https://api.banco-lp.example/';
const DAY = 86_400n;
const MINT_FEE_BPS = 5;
const REDEEM_FEE_BPS = 5;
const LIQUIDITY = 2_000n * E18;
const KEEP = 50n * E18;
const LP_PIX = 'liquidez@lp.example';
/** The LPs' share of Mova's fees the splitter forwards to NodeRewards, and NodeRewards' base units per centavo. */
const REWARDS_SHARE_BPS = 2_000n;
const MOVVA_PER_CENT = 10n ** 16n;
const SELLER_PIX = '+5511987654321';
const FUNDER_KEY: Hex = '0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80';

type Wallet = WalletClient<Transport, Chain, Account>;

async function startAnvil(): Promise<ChildProcess | undefined> {
  if (process.argv[2]) return undefined;
  const child = spawn(ANVIL, ['--port', String(PORT), '--block-time', '1', '--silent'], { stdio: 'ignore' });
  for (let i = 0; i < 50; i++) {
    try {
      const r = await fetch(RPC, { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{"jsonrpc":"2.0","id":1,"method":"eth_chainId","params":[]}' });
      if (r.ok) return child;
    } catch {
      // not up yet
    }
    await sleep(200);
  }
  child.kill();
  throw new Error(`anvil did not start on ${RPC}`);
}

async function main(): Promise<void> {
  const probe = createPublicClient({ transport: http(RPC) });
  const chainId = await probe.getChainId();
  const chain = defineChain({ id: chainId, name: 'anvil', nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 }, rpcUrls: { default: { http: [RPC] } } });
  const pub = createPublicClient({ chain, transport: http(RPC), pollingInterval: 250 }) as PublicClient;
  const wallet = (key: Hex): Wallet => createWalletClient({ account: privateKeyToAccount(key), chain, transport: http(RPC), pollingInterval: 250 });
  const funder = wallet(FUNDER_KEY);

  const send = async (w: Wallet, address: Address, abi: Abi, functionName: string, args: unknown[], value = 0n) => {
    const hash = await w.writeContract({ address, abi, functionName, args, value } as never);
    const r = await pub.waitForTransactionReceipt({ hash });
    if (r.status !== 'success') throw new Error(`${functionName} reverted`);
    return r;
  };
  const read = <T>(address: Address, abi: Abi, functionName: string, args: unknown[] = []) =>
    pub.readContract({ address, abi, functionName, args } as never) as Promise<T>;
  const deploy = async (name: string, args: unknown[], file?: string): Promise<Address> => {
    const a = art(name, file);
    const hash = await funder.deployContract({ abi: a.abi, bytecode: a.bytecode, args } as never);
    const r = await pub.waitForTransactionReceipt({ hash });
    if (!r.contractAddress) throw new Error(`${name} did not deploy`);
    return r.contractAddress;
  };
  const fund = async (to: Address, value: bigint) => {
    await pub.waitForTransactionReceipt({ hash: await funder.sendTransaction({ to, value }) });
  };
  const rpc = async (method: string, params: unknown[]): Promise<unknown> => {
    const r = await fetch(RPC, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ jsonrpc: '2.0', id: 1, method, params }) });
    const j = await r.json() as { result?: unknown; error?: { message: string } };
    if (j.error) throw new Error(`${method}: ${j.error.message}`);
    return j.result;
  };

  step('1. Deploy Movva and the ramp from forge artifacts');
  info('artifacts', OUT);
  const gov = wallet(generatePrivateKey());
  const guardian = wallet(generatePrivateKey());
  const issuer = wallet(generatePrivateKey());
  const lp = wallet(generatePrivateKey());
  const userKey = generatePrivateKey();
  const user = wallet(userKey); // buys Movva on the on-ramp, sells some back on the off-ramp
  for (const w of [gov, guardian, issuer, lp, user]) await fund(w.account.address, parseEther('20'));

  const usdt = await deploy('TetherLike', [], 'ERC4626Adapter.t.sol');
  const usdFeed = await deploy('FxTestFeed', [100_000_000n, 8], 'ChainlinkSignedFxOracle.t.sol'); // $1.00000000
  const FEED = art('FxTestFeed', 'ChainlinkSignedFxOracle.t.sol').abi;
  // The FX leg: Pyth's FX.USD/BRL, posted by a keeper, read by PythFxOracle as the reserve's rate (and, off-hours, as
  // the band's last close).
  const pyth = await deploy('MockPyth', [1n]);
  const PYTH = art('MockPyth').abi;
  let lastPublish = 0n;
  /** Post a Pyth update as the keeper does, at `at` or the head's time; Pyth ignores one no newer than what it holds. */
  const publishFx = async (e6: bigint, at?: bigint) => {
    let t = at ?? (await pub.getBlock()).timestamp;
    while (at === undefined && t <= lastPublish) {
      await sleep(300);
      t = (await pub.getBlock()).timestamp;
    }
    lastPublish = t;
    const update = encodeAbiParameters(
      [{ type: 'bytes32' }, { type: 'int64' }, { type: 'uint64' }, { type: 'int32' }, { type: 'uint256' }], [FX_USD_BRL_ID, e6, 0n, -6, t],
    );
    await send(funder, pyth, PYTH, 'updatePriceFeeds', [[update]], 1n);
  };
  await publishFx(FX_E6);
  const fx = await deploy('PythFxOracle', [pyth, FX_USD_BRL_ID, 3_600n, 4n * DAY, 100, gov.account.address, GOVERNANCE_DELAY]);
  const PFX = art('PythFxOracle').abi;
  await send(gov, fx, PFX, 'completeSetup', []);

  const RES = art('MovvaReserve').abi;
  const reserve = await deploy('MovvaReserve', [{
    usdt, usdtUsdFeed: usdFeed, fxOracle: fx, usdtUsdMaxAge: 25n * 3600n, fxMaxAge: 3600n, governor: gov.account.address,
    governanceDelay: GOVERNANCE_DELAY, guardian: guardian.account.address, treasurer: '0x0000000000000000000000000000000000000000',
    hedgeTreasury: privateKeyToAccount(generatePrivateKey()).address, feeRecipient: privateKeyToAccount(generatePrivateKey()).address,
    supplyCap: 10_000_000n * E18, breaker: '0x0000000000000000000000000000000000000000', hedgeQueueDelay: 86_400n,
  }]);
  const movva = await read<Address>(reserve, RES, 'MOVVA');
  const stata = await deploy('StataLike', [usdt], 'ERC4626Adapter.t.sol');
  const vault = await deploy('YieldVault', [usdt, 'Shielded Yield USDT', 'syUSDT', gov.account.address, guardian.account.address,
    privateKeyToAccount(generatePrivateKey()).address, 10n ** 15n, 100, GOVERNANCE_DELAY]);
  const adapter = await deploy('ERC4626Adapter', [vault, stata, 'stata']);
  const VAULT = art('YieldVault').abi;
  await send(gov, vault, VAULT, 'addAdapter', [adapter, 10_000]);
  await send(gov, vault, VAULT, 'completeSetup', []);
  await send(gov, reserve, RES, 'setGateway', [lp.account.address, true]);
  await send(gov, reserve, RES, 'setYieldVault', [vault]);
  await send(gov, reserve, RES, 'setFees', [MINT_FEE_BPS, REDEEM_FEE_BPS]);
  // Node-provider rewards, as DeployMovva wires them: the reserve's fees go through a FeeSplitter, which forwards the LPs'
  // share to NodeRewards. One-day epochs and reviews, the shortest the contract allows, so step 11 can warp through one.
  const movaTreasury = privateKeyToAccount(generatePrivateKey()).address;
  const nodeRewards = await deploy('NodeRewards', [movva, MOVVA_PER_CENT, DAY, DAY, gov.account.address, GOVERNANCE_DELAY]);
  const NR = art('NodeRewards').abi;
  const splitter = await deploy('FeeSplitter', [movva, movaTreasury, nodeRewards, gov.account.address, GOVERNANCE_DELAY]);
  const SPLIT = art('FeeSplitter').abi;
  await send(gov, reserve, RES, 'setFeeRecipient', [splitter]);
  await send(gov, splitter, SPLIT, 'setLpRewardShare', [REWARDS_SHARE_BPS]);
  await send(gov, splitter, SPLIT, 'completeSetup', []);
  await send(gov, nodeRewards, NR, 'completeSetup', []);
  await send(gov, reserve, RES, 'completeSetup', []);

  const USDT = art('TetherLike', 'ERC4626Adapter.t.sol').abi;
  const MOVVA = art('Movva').abi;
  // The issuer seeds a buffer before any gateway mints, as docs/movva.md asks, so a unit of the vault's
  // rounding cannot leave the reserve a hair under par.
  await send(funder, usdt, USDT, 'mint', [issuer.account.address, 100n * U]);
  await send(issuer, usdt, USDT, 'approve', [reserve, 100n * U]);
  await send(issuer, reserve, RES, 'recapitalize', [100n * U]);

  // PIX settles on zkTLS: witnesses (local keys) to sessions with the LP's bank's receipt pages.
  const witnessKeys = [generatePrivateKey(), generatePrivateKey()];
  const templates = receiptTemplates(BANK_URL_PREFIX);
  const ethBand = await deploy('StableOracle', [], 'RampErc20.t.sol'); // the escrows' native-ETH listing; unused here
  const registry = await deploy('LPRegistry', [gov.account.address, GOVERNANCE_DELAY]);
  const verifier = await deploy('ReclaimZkTlsVerifier', [
    gov.account.address, GOVERNANCE_DELAY, witnessKeys.map((k) => privateKeyToAccount(k).address), 2n,
    RECEIPT_KINDS.map((k) => hashProviderParams(templates[k])), RECEIPT_KINDS.map(() => BANK_URL_PREFIX),
  ]);
  for (const k of RECEIPT_KINDS) {
    if (receiptRail(k) === Rail.BOLETO) await send(gov, verifier, art('ReclaimZkTlsVerifier').abi, 'setEndpointRails', [hashProviderParams(templates[k]), receiptRailMask(k)]);
  }
  const poolStub = await deploy('PoolStub', [], 'RampIntegration.t.sol');
  // 300 bps, DeployRamp's MOVVA_BAND_BPS: at whole-centavo prices a tighter band leaves a partly backed
  // reserve's rounded mid as the only price that passes, above what a redemption pays.
  const fiat = await deploy('FiatEscrow', [ethBand, registry, poolStub, poolStub, 300n, gov.account.address, GOVERNANCE_DELAY, DISPUTE_TIMEOUT]);
  const offramp = await deploy('OffRampEscrow', [ethBand, registry, 300n, gov.account.address, GOVERNANCE_DELAY, DISPUTE_TIMEOUT]);
  const deployBlock = await pub.getBlockNumber();
  const REG = art('LPRegistry').abi;
  const FIAT = art('FiatEscrow').abi;
  const OFF = art('OffRampEscrow').abi;
  await send(gov, registry, REG, 'setEscrow', [fiat, true]);
  await send(gov, registry, REG, 'setEscrow', [offramp, true]);
  await send(gov, registry, REG, 'setTier', [lp.account.address, TIER_INSTITUTIONAL, 100_000_000n]);
  // DeployRamp's NODE_REWARDS: every settlement this registry records is reported to NodeRewards.
  await send(gov, registry, REG, 'setRewardsHook', [nodeRewards]);
  for (const e of [fiat, offramp]) {
    await send(gov, e, FIAT, 'setVerifier', [verifier, true]);
    // Movva's band is the reserve: R$ 1,00 while fully backed, min(1, ratio) of it below.
    await send(gov, e, FIAT, 'setAsset', [movva, reserve, 18, true]);
  }
  for (const c of [registry, verifier, fiat, offramp]) await send(gov, c, art('DelayedGovernance').abi, 'completeSetup', []);
  // NodeRewards' setup closed before the registry existed, as on a real deployment: its governor binds the registry now,
  // immediately, because NodeRewards has never held anything.
  await send(gov, nodeRewards, NR, 'setRegistry', [registry]);
  check((await read<Address>(nodeRewards, NR, 'registry')).toLowerCase() === registry.toLowerCase() && (await read<boolean>(nodeRewards, NR, 'setupComplete')),
    'NodeRewards (setup closed) bound to the registry by its governor at once: it holds nothing yet');

  await send(funder, usdt, USDT, 'mint', [lp.account.address, 100_000n * U]);
  // A leftover allowance, as a process that approved and died before minting would leave it. Tether's
  // approve refuses to move it to another non-zero value: the node must zero it first.
  await send(lp, usdt, USDT, 'approve', [reserve, 1n]);
  ok('TetherLike USDT, FxTestFeed, the FX leg from Pyth (MockPyth -> PythFxOracle, 1e-6), MovvaReserve + Movva, YieldVault + ERC4626Adapter');
  ok('ReclaimZkTlsVerifier: 2-of-2 local witnesses, the LP bank\'s receipt pages allowlisted');
  ok('FiatEscrow and OffRampEscrow (3% band) with Movva listed against the reserve; LP admitted as gateway and institutional LP');
  ok('FeeSplitter as the reserve\'s fee recipient (20% to NodeRewards), NodeRewards as the registry\'s rewards hook');
  info('MovvaReserve', reserve);
  info('Movva', movva);
  info('FiatEscrow / OffRampEscrow', `${fiat} / ${offramp}`);
  const supply = () => read<bigint>(movva, MOVVA, 'totalSupply');
  const movvaOf = (a: Address) => read<bigint>(movva, MOVVA, 'balanceOf', [a]);
  const usdtOf = (a: Address) => read<bigint>(usdt, USDT, 'balanceOf', [a]);
  type Minted = { usdtIn: bigint; movvaOut: bigint; gateway: Address };
  type Redeemed = { movvaIn: bigint; usdtOut: bigint; gateway: Address };
  const events = async <T>(eventName: 'Minted' | 'Redeemed') => (await pub.getContractEvents({ address: reserve, abi: RES, eventName, fromBlock: deployBlock }))
    .map((l) => (l as unknown as { args: T }).args);

  step('2. Start the LP node as a Movva gateway: MockBank, local zkTLS witnesses, a journal file');
  /** How far step 10 has moved the chain's calendar ahead: the bank and the node keep the chain's date. */
  let clockOffset = 0n;
  const wall = () => BigInt(Math.floor(Date.now() / 1000)) + clockOffset;
  const bank = new MockBank({ now: wall });
  const dir = mkdtempSync(join(tmpdir(), 'lp-node-movva-'));
  const journalPath = join(dir, 'lp-node.jsonl');
  const rampChain = new ViemRampChain({ publicClient: pub, walletClient: lp, registry, onramp: fiat, offramp, receiptWaitMs: 30_000 });
  const session = new LocalWitnessSession({ witnessKeys, receipts: bank, templates, now: wall });
  const zkProver = new ZkTlsProver(verifier, session, {
    witnesses: { addresses: witnessKeys.map((k) => privateKeyToAccount(k).address), threshold: 2 },
    endpoints: RECEIPT_KINDS.map((k) => ({ providerHash: hashProviderParams(templates[k]), urlPrefix: BANK_URL_PREFIX, rails: [receiptRail(k)] })),
    preflight: async (proof) => { await prepareSettlement(pub, verifier, proof); },
  });
  const par = new ParPriceFeed(wall);
  /** Where the LP's node-provider rewards are paid: not the gateway wallet, whose Movva balance the steps below count exactly. */
  const rewardsTo = privateKeyToAccount(generatePrivateKey()).address;
  const gateway: GatewayOptions = {
    reserve, usdt, movva,
    mint: { enabled: true, maxSlippageBps: 10, minMintUsdt: 1n * U, maxMintUsdt: 1_000n * U, maxMintUsdtPerDay: 5_000n * U, keepUsdt: 0n, maxFeeBps: 10, usdtCostBps: 0 },
    redeem: {
      enabled: true, keepMovva: KEEP, minRedeemMovva: 10n * E18, maxRedeemMovva: 10_000n * E18, maxRedeemMovvaPerDay: 50_000n * E18,
      maxSlippageBps: 10, minCollateralRatioBps: 10_000, maxFeeBps: 10, usdtSaleBps: 30,
    },
    maxRateDeviationBps: 100, maxReferenceAgeSeconds: 300,
  };
  const options = (): LpNodeOptions => ({
    chain: rampChain, bank, journal: new JsonlJournal<LpRecord>(journalPath),
    provers: [zkProver],
    confirmations: 2, fromBlock: deployBlock, reorgWindow: 16n, payerRefSecret: `0x${'5a'.repeat(32)}`, lpPayerId: '12345678000195',
    wallClock: wall, pollMs: 500,
    log: { info: () => {}, warn: () => {}, error: (m) => console.log(`        node error: ${m}`) },
    onramp: {
      escrow: fiat, pixKey: LP_PIX, receiver: { name: 'LP Liquidez Ltda', city: 'Sao Paulo' }, reclaimExpired: true, autoRefund: true,
      boletoDueDays: 3, reorgWindow: 16n, lateCreditGraceSeconds: 600,
      assets: [{
        asset: movva, symbol: 'MOVVA', liquidity: LIQUIDITY, minOrder: 10n * E18, maxOrder: 1_000n * E18, verifier, rails: [Rail.PIX],
        refillBelowBps: 8_000, feed: par,
        pricing: { spreadBps: 50, minSpreadBps: 20, maxOracleDeviationBps: 100, bandMarginBps: 50, refreshDriftBps: 60, maxReferenceAgeSeconds: 120, oracleStaleMarginSeconds: 300 },
      }],
    },
    offramp: {
      escrow: offramp, rails: ['PIX'], maxOpenClaims: 2, minTimeToPaySeconds: 20 * 60, disputeMarginSeconds: 7 * 60,
      bankClockSkewSeconds: 1, raiseDisputeWhenUnproven: true, reorgWindow: 16n,
      assets: [{
        asset: movva, symbol: 'MOVVA', minSaleBrlCents: 100n, maxSaleBrlCents: 10_000_000n, feed: par,
        pricing: { minMarginBps: 50, maxOracleDeviationBps: 100, maxReferenceAgeSeconds: 120, oracleStaleMarginSeconds: 300 },
      }],
    },
    gateway,
    rewards: { contract: nodeRewards, registry, claim: true, minClaim: 0n, lookbackEpochs: 12, to: rewardsTo },
  });
  let node = new LpNode(options());
  let api = serveLpNode(node, { mode: 'both' });
  let apiUrl = `http://127.0.0.1:${await api.listen(0)}`;
  const until = async (what: string, cond: () => Promise<boolean>, maxTicks = 40) => {
    for (let i = 0; i < maxTicks; i++) {
      await node.tick();
      if (await cond()) return;
      await sleep(400);
    }
    throw new Failed(`timed out waiting for: ${what}`);
  };
  const ticks = async (n: number) => {
    for (let i = 0; i < n; i++) {
      await node.tick();
      await sleep(600);
    }
  };
  type GatewayStatus = {
    market: string | null;
    mint: { canMint: boolean; blocked: string[] }; redeem: { canRedeem: boolean; blocked: string[]; held: { reason: string } | null };
    pending: unknown[];
  };
  const status = async () => ((await (await fetch(`${apiUrl}/status`)).json()) as { gateway: GatewayStatus }).gateway;
  const offerStatus = () => node.offers!.status.get(movva.toLowerCase());

  step('3. The node mints what the Movva offer needs, and posts it');
  const supply0 = await supply();
  const usdt0 = await usdtOf(lp.account.address);
  await until('a Movva offer', async () => !!offerStatus()?.quoting);
  const [mint1] = await events<Minted>('Minted');
  const offer1 = await rampChain.offer(offerStatus()!.activeOfferId!);
  info('minted', `${usdtFmt(mint1.usdtIn)} -> ${movvaFmt(mint1.movvaOut)}`);
  info('offer', `${movvaFmt(offer1.availableWei)} at ${offer1.priceBrlCentsPerEth} centavos per Movva`);
  check(mint1.gateway === lp.account.address && usdt0 - (await usdtOf(lp.account.address)) === mint1.usdtIn,
    'Minted names the LP as gateway, and exactly that USDT left its wallet');
  const fee1 = (mint1.movvaOut * BigInt(MINT_FEE_BPS) + 9_999n) / 9_995n; // the fee the reserve minted beside it, roughly
  check(mint1.movvaOut >= LIQUIDITY && mint1.movvaOut - LIQUIDITY < 10n ** 13n,
    'sized to the need: 2.000 Movva after the 5 bps mint fee, plus under one USDT unit of rounding');
  check((await supply()) - supply0 >= mint1.movvaOut && (await supply()) - supply0 <= mint1.movvaOut + fee1, 'Movva supply grew by the mint and its fee');
  check((await read<bigint>(usdt, USDT, 'allowance', [lp.account.address, reserve])) === 0n,
    'the leftover 1-unit allowance was zeroed before the new one (Tether bytecode refuses otherwise), and the mint used all of it');
  check(offer1.availableWei === LIQUIDITY && offer1.priceBrlCentsPerEth === 101n,
    'posted 2.000 Movva at R$ 1,01: par plus the spread, which also covers the mint fee (R$ 1,0005 a Movva)');
  check((await read<bigint>(vault, VAULT, 'balanceOf', [reserve])) > 0n, 'the reserve put the USDT to work in YieldVault(USDT)');

  /** The user buys `amount` Movva from the offer by PIX, as a wallet does; returns the BR Code's amount. */
  const buyByPix = async (amount: bigint): Promise<bigint> => {
    const offerId = offerStatus()!.activeOfferId!;
    const rc = await send(user, fiat, FIAT, 'lockOrder', [offerId, amount, 0, user.account.address, 0n]);
    const orderId = ((await pub.getContractEvents({ address: fiat, abi: FIAT, eventName: 'OrderLocked', blockHash: rc.blockHash }))[0] as unknown as { args: { orderId: Hex } }).args.orderId;
    await until('order tracked', async () => !!node.store.getOrder(orderId));
    // The wallet signs with its own clock, which the node's API checks against its own: real time, not the chain's calendar.
    const req = await signInstructionsRequest(privateKeyToAccount(userKey), { chainId, escrow: fiat, orderId, issuedAt: Math.floor(Date.now() / 1000) });
    const res = await fetch(`${apiUrl}/v1/onramp/instructions`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(req) });
    const body = await res.json() as { pixKey: string; salt: Hex; pixCopiaECola: string };
    check(res.status === 200 && pixKeyCommitment(body.pixKey, body.salt) === (await rampChain.offer(offerId)).pixKeyHash, 'the user fetched instructions; the key and salt open the offer\'s commitment');
    const code = parsePixBrCode(body.pixCopiaECola);
    bank.receivePix({ amountCents: code.amountCents!, creditedKey: code.key, txid: code.txid });
    await until('release', async () => (await rampChain.order(orderId)).state === OrderState.RELEASED);
    return code.amountCents!;
  };

  step('4. On-ramp by PIX: a user buys 600 Movva');
  {
    const charged = await buyByPix(600n * E18);
    check(charged === 60_600n, 'the BR Code charged R$ 606,00 for 600 Movva at R$ 1,01');
    check((await movvaOf(user.account.address)) === 600n * E18, 'the node matched the PIX, proved its received-payment page by zkTLS, the escrow released 600 Movva to the user');
  }

  step('5. The node tops the offer up, minting only what was drained');
  await until('the offer back at 2.000 Movva', async () => (await rampChain.offer(offerStatus()!.activeOfferId!)).availableWei === LIQUIDITY);
  const mints = await events<Minted>('Minted');
  check(mints.length === 2, 'one more mint, no more');
  info('minted', `${usdtFmt(mints[1].usdtIn)} -> ${movvaFmt(mints[1].movvaOut)}`);
  check(mints[1].movvaOut > 599n * E18 && mints[1].movvaOut < 600n * E18 + 10n ** 13n,
    'sized to the 600 Movva sold, less the rounding already in the wallet');

  step('6. Off-ramp by PIX: the user sells 500 Movva back; the node buys, then redeems at the reserve');
  {
    const redeemedBefore = (await events<Redeemed>('Redeemed')).length;
    const supplyBefore = await supply();
    const usdtBefore = await usdtOf(lp.account.address);
    const salt = newPixSalt();
    await send(user, movva, MOVVA, 'approve', [offramp, 500n * E18]);
    const rc = await send(user, offramp, OFF, 'openSale', [movva, 500n * E18, 49_500n, pixKeyCommitment(SELLER_PIX, salt), verifier, railMask(Rail.PIX), user.account.address]);
    const saleId = ((await pub.getContractEvents({ address: offramp, abi: OFF, eventName: 'SaleOpened', blockHash: rc.blockHash }))[0] as unknown as { args: { saleId: Hex } }).args.saleId;
    const disclosed = await fetch(`${apiUrl}/v1/offramp/payee`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ saleId, pixKey: SELLER_PIX, salt }) });
    check(disclosed.status === 201, 'the user disclosed the payee: R$ 495,00 for 500 Movva, a buy against par and against what redeeming pays');
    await until('claim', async () => (await rampChain.sale(saleId)).state === SaleState.CLAIMED);
    check(bank.outgoing.length === 0, 'claimed - and nothing paid while the claim is unconfirmed');
    await until('settlement', async () => (await rampChain.sale(saleId)).state === SaleState.SETTLED);
    check(bank.outgoing.at(-1)?.amountCents === 49_500n && bank.outgoing.at(-1)?.destination === SELLER_PIX, 'R$ 495,00 sent by PIX to the user\'s key; the sale settled');
    await until('a redemption', async () => (await events<Redeemed>('Redeemed')).length > redeemedBefore);
    const r = (await events<Redeemed>('Redeemed')).at(-1)!;
    const fee = (r.movvaIn * BigInt(REDEEM_FEE_BPS) + 9_999n) / 10_000n;
    info('redeemed', `${movvaFmt(r.movvaIn)} -> ${usdtFmt(r.usdtOut)}`);
    check(r.gateway === lp.account.address && (await movvaOf(lp.account.address)) === KEEP, 'the node redeemed everything above its 50 Movva working balance');
    check((await usdtOf(lp.account.address)) - usdtBefore === r.usdtOut, 'the USDT came back to the LP\'s wallet');
    const atPar = ((r.movvaIn - fee) * U) / (FX_E6 * 10n ** 12n);
    check(r.usdtOut === atPar, 'at par, less the 5 bps redeem fee: the reserve is fully backed');
    check(supplyBefore - (await supply()) === r.movvaIn - fee, `Movva supply fell by ${movvaFmt(r.movvaIn - fee)}`);
  }

  step('7. Mova\'s fees fund node rewards: anyone splits them, and the LP\'s settled volume is already counted');
  const rewardsEpoch = await read<bigint>(nodeRewards, NR, 'currentEpoch');
  let rewardsFunded = 0n;
  {
    const feesHeld = await movvaOf(splitter);
    const treasuryBefore = await movvaOf(movaTreasury);
    const volume = await read<bigint>(nodeRewards, NR, 'volumeOf', [rewardsEpoch, lp.account.address]);
    info('fees in the splitter', movvaFmt(feesHeld));
    check(feesHeld > 0n, 'the gateway\'s mint and redeem fees sit in the FeeSplitter, the reserve\'s fee recipient');
    check(volume === 60_600n + 49_500n,
      `NodeRewards counted the R$ 606,00 on-ramp and R$ 495,00 off-ramp settlements for the LP in epoch ${rewardsEpoch}, through the registry's hook`);
    await send(funder, splitter, SPLIT, 'split', []); // anyone may
    rewardsFunded = (feesHeld * REWARDS_SHARE_BPS) / 10_000n;
    check((await movvaOf(nodeRewards)) === rewardsFunded && (await movvaOf(movaTreasury)) - treasuryBefore === feesHeld - rewardsFunded,
      `split: ${movvaFmt(rewardsFunded)} (20%) to NodeRewards, the rest to Mova's treasury`);
    const [,, funded] = await read<readonly bigint[]>(nodeRewards, NR, 'epochs', [rewardsEpoch]);
    check(funded === rewardsFunded, 'booked into the epoch it arrived in');
    await ticks(1);
    const metrics = await (await fetch(`${apiUrl}/metrics`)).text();
    check(/^mova_lp_rewards_counting 1$/m.test(metrics) && new RegExp(`^mova_lp_rewards_epoch_volume_cents ${60_600 + 49_500}$`, 'm').test(metrics),
      '/metrics: mova_lp_rewards_counting 1, mova_lp_rewards_epoch_volume_cents 110100');
  }

  step('8. The guardian pauses minting: the node says why it cannot mint');
  await send(guardian, reserve, RES, 'pauseMint', []);
  await ticks(1);
  {
    const s = await status();
    info('gateway.mint.blocked', JSON.stringify(s.mint.blocked));
    check(!s.mint.canMint && s.mint.blocked.includes('mint_paused') && s.redeem.canRedeem, '/status: cannot mint (mint_paused); redemptions, which cannot be paused, still can');
    const metrics = await (await fetch(`${apiUrl}/metrics`)).text();
    check(/^mova_lp_gateway_blocked\{op="mint",reason="mint_paused"\} 1$/m.test(metrics), '/metrics: mova_lp_gateway_blocked{op="mint",reason="mint_paused"} 1');
  }
  await send(gov, reserve, RES, 'resumeMint', []);

  step('9. The reserve falls under par: the node holds instead of taking the haircut');
  {
    await send(user, movva, MOVVA, 'transfer', [lp.account.address, 100n * E18]); // Movva the LP holds above its working balance
    const [totalUsdt, supplyNow] = await Promise.all([read<bigint>(reserve, RES, 'totalUsdt'), supply()]);
    // ratio = totalUsdt x e6 x 1e10 / supply; aim for 95%.
    const underE6 = (9_500n * supplyNow) / (totalUsdt * 10n ** 10n);
    await sleep(1_100);
    await publishFx(underE6);
    const ratio = await read<bigint>(reserve, RES, 'collateralRatioBps');
    info('collateral ratio', `${ratio} bps at R$ ${formatUnits(underE6, 6)} per dollar`);
    const redeemed = (await events<Redeemed>('Redeemed')).length;
    const supplyHeld = await supply();
    await until('the offer pulled', async () => offerStatus()?.quoting === false);
    await ticks(2);
    const s = await status();
    check(offerStatus()?.reason === 'reference_deviates', 'the Movva offer was pulled: the reserve reads under R$ 1,00 and par no longer agrees');
    check(s.redeem.held?.reason === 'below_par' && (await events<Redeemed>('Redeemed')).length === redeemed && (await supply()) === supplyHeld,
      `/status redeem.held = below_par: ${movvaFmt(await movvaOf(lp.account.address))} held, nothing redeemed, supply unchanged`);
    const metrics = await (await fetch(`${apiUrl}/metrics`)).text();
    check(/^mova_lp_gateway_held\{reason="below_par"\} 1$/m.test(metrics), '/metrics: mova_lp_gateway_held{reason="below_par"} 1');

    await sleep(1_100);
    await publishFx(FX_E6);
    const mintsBefore = (await events<Minted>('Minted')).length;
    await until('re-posted and redeemed', async () => !!offerStatus()?.quoting && (await events<Redeemed>('Redeemed')).length > redeemed);
    check((await events<Minted>('Minted')).length === mintsBefore, 'back at par: the offer re-posted 2.000 Movva from the wallet, minting nothing');
    check((await movvaOf(lp.account.address)) === KEEP, 'and the Movva above the working balance was redeemed');
  }

  step('10. The FX market closes for the weekend: the node sells from the last close; minting and redeeming wait for Monday');
  {
    const PYTH_FX = art('PythFxOracle').abi;
    /** Move anvil's clock to `target`, keep the bank and the node on the chain's calendar, and keep Chainlink's USDT/USD heartbeat. */
    const warpTo = async (target: bigint): Promise<bigint> => {
      const now = (await pub.getBlock()).timestamp;
      await rpc('evm_increaseTime', [Number(target - now)]);
      await rpc('evm_mine', []);
      const head = (await pub.getBlock()).timestamp;
      clockOffset = head - BigInt(Math.floor(Date.now() / 1000));
      await send(funder, usdFeed, FEED, 'set', [100_000_000n, head]);
      return head;
    };
    const utc = (t: bigint) => new Date(Number(t) * 1000).toISOString().replace('.000Z', ' UTC');
    // The next Saturday noon at least 36 hours out, so Friday's 20:55 UTC close is later than any price posted so far,
    // and whose Monday is not 25 December or 1 January (FxMarketHours keeps those closed).
    const t0 = (await pub.getBlock()).timestamp;
    let saturday = (t0 / DAY + ((6n - ((t0 / DAY + 4n) % 7n) + 7n) % 7n)) * DAY + 12n * 3_600n;
    const holiday = (t: bigint) => /-(12-25|01-01)T/.test(new Date(Number(t) * 1000).toISOString());
    while (saturday - t0 < 36n * 3_600n || holiday(saturday + 2n * DAY)) saturday += 7n * DAY;
    const fridayClose = saturday - 15n * 3_600n - 5n * 60n;
    const mondayOpen = saturday + 2n * DAY + 2n * 3_600n + 30n * 60n; // Monday 14:30 UTC, inside the core session

    const [mintsBefore, redeemsBefore] = [(await events<Minted>('Minted')).length, (await events<Redeemed>('Redeemed')).length];
    const at = await warpTo(saturday);
    await publishFx(FX_E6, fridayClose); // the last price the keeper posted on Friday
    info('chain time', `${utc(at)} (Saturday); Pyth's last FX.USD/BRL price ${utc(fridayClose)}`);
    const strict = await pub.readContract({ address: reserve, abi: RESERVE_ABI, functionName: 'brlPerUsdtE18' }).then(() => undefined, (e: unknown) => toChainRevert(e));
    const [bandRate] = await pub.readContract({ address: reserve, abi: RESERVE_ABI, functionName: 'bandBrlPerUsdtE18' });
    check(strict instanceof ChainRevert && strict.errorName === 'StaleRate' && bandRate === FX_E6 * 10n ** 12n && !(await read<boolean>(fx, PYTH_FX, 'inCoreSession')),
      `MovvaReserve.brlPerUsdtE18 reverts ${strict instanceof ChainRevert ? strict.errorName : 'nothing'}; bandBrlPerUsdtE18 reads Friday's close, R$ ${formatUnits(bandRate, 18)}`);

    await sleep(1_100);
    await ticks(2);
    let s = await status();
    info('gateway', JSON.stringify({ market: s.market, mint: s.mint.blocked, redeem: s.redeem.blocked, held: s.redeem.held?.reason }));
    check(s.market === 'closed' && s.mint.blocked.includes('market_closed') && s.redeem.blocked.includes('market_closed') && s.redeem.held?.reason === 'market_closed',
      '/status: market closed; mint and redeem held as market_closed');
    check(offerStatus()?.quoting === true, 'the Movva offer stays posted, priced from the close: the escrow band reads R$ 1,00, stamped current');
    const metrics = await (await fetch(`${apiUrl}/metrics`)).text();
    check(/^mova_lp_gateway_held\{reason="market_closed"\} 1$/m.test(metrics) && /^mova_lp_gateway_market_closed 1$/m.test(metrics),
      '/metrics: mova_lp_gateway_held{reason="market_closed"} 1, mova_lp_gateway_market_closed 1');

    const charged = await buyByPix(100n * E18);
    check(charged === 10_100n && (await events<Minted>('Minted')).length === mintsBefore,
      'on the Saturday a user bought 100 Movva by PIX for R$ 101,00: proven by zkTLS and released from what the LP held - nothing minted');
    await send(user, movva, MOVVA, 'transfer', [lp.account.address, 100n * E18]); // Movva the LP comes to hold above its working balance
    await ticks(3);
    check((await events<Redeemed>('Redeemed')).length === redeemsBefore && (await movvaOf(lp.account.address)) === KEEP + 100n * E18,
      'the 100 Movva above the working balance wait in the wallet: nothing is redeemed at Friday\'s close');

    await warpTo(mondayOpen);
    const inSession = await pub.readContract({ address: reserve, abi: RESERVE_ABI, functionName: 'bandBrlPerUsdtE18' }).then(() => undefined, (e: unknown) => toChainRevert(e));
    info('chain time', `${utc(mondayOpen)} (Monday)`);
    check(inSession instanceof ChainRevert && inSession.errorName === 'StaleRate' && (await read<boolean>(fx, PYTH_FX, 'inCoreSession')),
      'in Monday\'s core session Friday\'s price is a missing price, not a close: the band refuses it too, until the keeper posts');
    await publishFx(FX_E6); // the keeper's first price of the week
    await until('Monday: the held Movva redeemed', async () => (await events<Redeemed>('Redeemed')).length > redeemsBefore);
    // The redemption is final only two blocks deep; until then it is the open intent that blocks both sides.
    await until('the redemption final', async () => { const st = await status(); return st.pending.length === 0 && st.mint.canMint && st.redeem.canRedeem; });
    s = await status();
    info('gateway', JSON.stringify({ market: s.market, mint: s.mint.blocked, redeem: s.redeem.blocked, held: s.redeem.held?.reason ?? null, quoting: offerStatus()?.quoting }));
    check(s.market === 'open' && s.mint.canMint && s.redeem.canRedeem && s.redeem.held === null && !!offerStatus()?.quoting,
      '/status: market open, can mint, can redeem, nothing held; the offer still posted');
    check((await movvaOf(lp.account.address)) === KEEP, 'the Movva held over the weekend was redeemed at Monday\'s rate, down to the working balance');
  }

  step('11. The rewards epoch has ended and passed review: the node finalizes it and claims the LP\'s share');
  type RewardsStatus = { counting: boolean; claimable: string; lastClaim: { paid: string } | null };
  type ClaimedLog = { epoch: bigint; lp: Address; to: Address; paid: bigint; rolledForward: bigint };
  const claims = async () => (await pub.getContractEvents({ address: nodeRewards, abi: NR, eventName: 'Claimed', fromBlock: deployBlock }))
    .map((l) => (l as unknown as { args: ClaimedLog }).args);
  {
    // Monday, in step 10, is more than a day and a review after this epoch ended; the node may already have claimed.
    await until('the epoch claimed', async () => read<boolean>(nodeRewards, NR, 'claimed', [rewardsEpoch, lp.account.address]));
    const [volume,, funded, budget] = await read<readonly bigint[]>(nodeRewards, NR, 'epochs', [rewardsEpoch]);
    const byVolume = (volume * MOVVA_PER_CENT * 10n) / 10_000n;
    info(`epoch ${rewardsEpoch}`, `${volume} centavos settled, ${movvaFmt(funded)} funded, budget ${movvaFmt(budget)} (10 bps of volume: ${movvaFmt(byVolume)})`);
    check(budget === (funded < byVolume ? funded : byVolume), 'the budget is the smaller of the fees funded and 10 bps of the volume settled');
    const mine = (await claims()).filter((c) => c.epoch === rewardsEpoch && c.lp === lp.account.address);
    check(mine.length === 1 && mine[0].paid === budget && mine[0].to === rewardsTo,
      `one claim, by the node, for the whole budget - the only LP that settled - paid to the LP's rewards wallet: ${movvaFmt(mine[0]?.paid ?? 0n)}`);
    check((await movvaOf(rewardsTo)) === budget, 'the rewards wallet holds it');
    const s = ((await (await fetch(`${apiUrl}/status`)).json()) as { rewards: RewardsStatus }).rewards;
    check(s.counting && s.claimable === '0' && s.lastClaim?.paid === String(budget), '/status rewards: counting, nothing left to claim, the claim recorded');
    const metrics = await (await fetch(`${apiUrl}/metrics`)).text();
    check(/^mova_lp_rewards_claimable 0$/m.test(metrics) && new RegExp(`^mova_lp_rewards_claimed_cents_total ${budget / MOVVA_PER_CENT}$`, 'm').test(metrics),
      `/metrics: mova_lp_rewards_claimable 0, mova_lp_rewards_claimed_cents_total ${budget / MOVVA_PER_CENT}`);
  }

  step('12. A new process over the same journal');
  await ticks(3); // let the last intents reach two confirmations
  const claimsAll = (await claims()).length;
  const [mintsAll, redeemsAll] = [(await events<Minted>('Minted')).length, (await events<Redeemed>('Redeemed')).length];
  const metrics = await (await fetch(`${apiUrl}/metrics`)).text();
  const val = (re: RegExp) => Number(re.exec(metrics)?.[1] ?? 'NaN');
  info('mints (final, this process)', val(/^mova_lp_gateway_mints_total\{outcome="mined"\} (\d+)$/m));
  info('redemptions (final)', val(/^mova_lp_gateway_redeems_total\{outcome="mined"\} (\d+)$/m));
  check(val(/^mova_lp_gateway_pending (\d+)$/m) === 0, '/metrics: no gateway transaction left open');
  await node.stop();
  await api.close();
  node = new LpNode(options());
  api = serveLpNode(node, { mode: 'both' });
  apiUrl = `http://127.0.0.1:${await api.listen(0)}`;
  await ticks(4);
  check((await events<Minted>('Minted')).length === mintsAll && (await events<Redeemed>('Redeemed')).length === redeemsAll,
    'the restarted node read its intents back as final, re-planned from fresh balances, and minted or redeemed nothing twice');
  check((await claims()).length === claimsAll, 'and claimed no reward twice: the contract marks each epoch claimed');
  const s = await status();
  check(s.mint.canMint && s.redeem.canRedeem && s.pending.length === 0, '/status after restart: can mint, can redeem, nothing pending');
  info('journal records', readFileSync(journalPath, 'utf8').trim().split('\n').length);
  await node.stop();
  await api.close();

  console.log('\n  \x1b[1mThe node minted Movva to a need, sold it, bought it back, redeemed it, held below par, and claimed its node rewards - on the real contracts.\x1b[0m\n');
}

let anvil: ChildProcess | undefined;
startAnvil()
  .then((a) => { anvil = a; return main(); })
  .catch((e: unknown) => {
    if (!(e instanceof Failed)) console.error('\nfailed:', e instanceof Error ? e.message : e);
    process.exitCode = 1;
  })
  .finally(() => {
    anvil?.kill();
    process.exit(process.exitCode ?? 0);
  });
