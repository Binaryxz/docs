# Mova — privacy-preserving BRL payments rail

Monorepo root. Built against MVP Scope **Rev. 2**: Phase 1 (shielded balances, seedless smart
accounts, the audit viewing key), Phase 2 (the P2P BRL ramp), and the yield infrastructure behind
Movva's reserve, which Rev. 2 defers to post-MVP and which is built here early. There is no
user-facing yield: savings (sMovva, its shielded pool, the savings relayer and the shielded yield
router) was removed by client decision D1, 14 October 2026.

[docs/HANDOVER.md](docs/HANDOVER.md) is the summary for a reader who wants to know what is
delivered, what is verified and what is deliberately not built yet.

```
packages/wallet/        the BRL-only boundary an app calls: balances in reais (Movva at par,
                        backing status), buying by PIX or boleto
                        with the LP's instructions verified on-chain, selling for a PIX
                        payout or a bill the LP pays, audit grants with one statement
                        across balances, the IRPF tax year
packages/viewing-key/   scoped selective-disclosure library + tests (see its README)
  src/pool/             Privacy Pools commitment scheme, in-process model, L1 indexer
  src/proofs.ts         commitment proofs (upstream's ragequit circuit) binding spend state
  src/price-reference.ts  PTAX x Chainlink reference price for BRL figures
  src/tax-export.ts     owner-side IRPF figures: acquisition cost, disposals, CSV
  src/vault-service.ts  the note vault as a replicable, keyless HTTP service
packages/smart-account/ passkey-seeded wallet + Safe 2-of-2 over ERC-4337 (task 1.2),
                        passkey-sealed MPC share, passkey-only recovery after a cooldown
packages/mpc/           FROST threshold Schnorr with a PedPoP DKG — UNAUDITED, see its README
                        contracts/SchnorrVerifier.sol verifies it on-chain (ERC-1271)
packages/ops/           monitor (state checks + event watch), admin tool, Flux specs
packages/movva/         the Movva issuer's hedge desk: hedge and treasury plans, signed and
                        chained hedge statements anyone can verify against the reserve; its HTTP server
                        serves the desk UI, which lives beside this repository (../mova-frontend)
packages/lp-node/       the liquidity provider's daemon: offers inside the band, payment
                        instructions for takers, PIX/boleto matching,
                        off-ramp payouts with crash-safe idempotency, the
                        Movva gateway (mint to a need, redeem above a working balance),
                        node-provider rewards claims, stuck-transaction replacement,
                        dispute evidence; runs on the LP's
                        own infrastructure
packages/yield/         vault and HyperEVM keepers; the Pyth keeper that
                        posts FX.USD/BRL to Ethereum; Hyperliquid data, delta-neutral backtest
contracts/              AuditGrantRegistry.sol (grant lifecycle), ShieldedNoteLog.sol
                        (append-only encrypted note records), SponsorPaymaster.sol
                        (pays gas so users need no ETH); none hold user funds
contracts/common/       DelayedGovernance: risk-raising changes wait; risk-reducing ones don't
                        IssuerFreeze: nothing new starts in USDT Tether has frozen
                        FxMarketHours: whether the FX market is certainly trading
contracts/movva/        Movva, the BRL-pegged token users hold: MovvaReserve (mints and
                        redeems for gateways at Pyth's USD/BRL rate, never at a stale one;
                        its band takes the last close off-hours; USDT reserve in YieldVault),
                        ScaledFxBandOracle
                        (the rate in centavos, for the ramps' bands), FeeSplitter (the
                        reserve's fee recipient: the LPs' share to NodeRewards, the rest
                        to Mova's treasury)
contracts/ramp/         Phase 2 BRL ramp (tasks 2.1–2.7)
                        FiatEscrow          on-ramp: BRL in (PIX or boleto),
                                            crypto out
                        OffRampEscrow       off-ramp: crypto in, BRL out (PIX or a boleto paid)
                        LPRegistry          network phases A/B/C, tiers, one credit limit
                                            across all of an LP's positions; reports
                                            settlements to a rewards hook
                        NodeRewards         node-provider rewards: a share of Mova's fees
                                            per LP per epoch, pro rata to settled volume,
                                            farming bounded (SR2-36)
                        ReclaimZkTlsVerifier zkTLS proof of a bank TLS session: the only
                                            verifier PIX, boleto and TED settle on
                        PythFxOracle        Pyth's FX.USD/BRL: the rate, refused once stale,
                                            and a band reading that takes the last close
                                            while the FX market is closed
                        IBandPriceOracle    that band reading, and BandRead, how bands use it
                        ChainlinkBrlOracle / PythBrlOracle   sanity bands, not prices
                        SignedPriceOracle   a named quorum's signed rate, the supported
                                            alternative to Pyth; like every oracle here, its
                                            signers and sources change only through the
                                            governance delay
                        ChainlinkSignedFxOracle  Chainlink ASSET/USD x the BRL/USD rate
                                            (Pyth's, or a signed one): the L1 band for USDT
                                            (and ETH)
                        RulingLib           EIP-712 arbitrator rulings, verified on-chain
                        SafeTransferLib     ERC-20 transfers that survive real tokens
packages/ramp/          off-chain half, run BY the protocol
                        matcher-service.ts  HTTP quotes over a book rebuilt from L1 events
                        indexer.ts          that rebuild; state is derived, never stored
                        arbitration-desk.ts case intake, deadlines, signed rulings
                        arbitration-service.ts  the desk over HTTP; ruling is
                                            operator-only, reading is public
                        orderbook.ts        the matching itself (a pure function)
                        attestor.ts / reclaim.ts   rails, PIX key commitments and zkTLS proof building
                        reclaim-client.ts   talks to the live Reclaim attestor network
                        price-publisher.ts  signs prices for SignedPriceOracle
                        disputes.ts         what a valid case and ruling look like
                        boleto.ts           FEBRABAN linha digitável / barcode validation
contracts/yield/        YieldVault, adapters (sUSDS, Aave v3 USDT, Lido, Superstate USTB), KeeperGate
contracts/hyperliquid/  delta-neutral vault held by a contract on HyperEVM, not a trading key
protocol/               FORKED Privacy Pools (task 1.1) — see protocol/FORK.md
  contracts/            Entrypoint, PrivacyPool, verifiers; audited, unmodified
  circuits/             withdraw/commitment/merkleTree circom + final ceremony keys
  audit/                upstream audit reports (Oxorio, Auditware)
docs/                   design, threat model, security review, deployments
```

**[TESTING.md](TESTING.md)** walks through testing this yourself — offline in five minutes,
or end to end against Sepolia and a local fork. Phase 1 is on the
`phase-1-shielded-rail` branch until PR #1 merges, so `git checkout phase-1-shielded-rail`
after cloning; `master` is still the pre-Phase-1 state.

## Run it

```bash
npm install
npm test                                                # 2129 tests (incl. property-based and anvil runs)
npm run demo                                            # end-to-end walkthrough

# our contracts (needs foundry: curl -L https://foundry.paradigm.xyz | bash && foundryup)
forge test                                              # 882 tests, incl. fuzz and invariant runs (fork suites skip without an RPC)
forge script contracts/script/Deploy.s.sol --rpc-url $RPC --broadcast

# forked Privacy Pools protocol
npm run verify                                          # fork provenance + audited suite
```

CI runs all of this on every push (`.github/workflows/verify.yml`): our tests and
contracts, fork provenance, the audited unit suite, circuit reproduction and the circuit
tests. The integration job needs RPC secrets and skips cleanly without them, so a fork of
this repo still gets a green build for everything it can actually run.

The forked protocol suite is **green**: 110 unit + 52 integration, zero failures, on the
foundry version pinned in `foundry-version` (fetched automatically by `scripts/foundry.sh`).
Newer foundry reports spurious failures — see [protocol/FORK.md](protocol/FORK.md) for why
the pin exists and why not to move it casually.

## What is implemented

- Viewing root derived **from the spending key** (one-way), with identity keys alongside it.
  Viewing material cannot yield spending authority, nor the pool withdrawal witness
  (asserted in `test/readonly.test.ts` and `test/pool-audit.test.ts`).
- Encrypted note records (XChaCha20-Poly1305) in per-epoch hash chains, so a note that was
  logged and then withheld is detectable.
- **A fiscal statement a tax authority can use**: opening balance, movements and closing
  balance for the audited period, each checked against pool state *as of* the period - so a
  user who held money before it, or kept transacting after it, is stated correctly and never
  has to disclose out-of-scope activity. Opening positions are pool anchors only, never the
  pre-period movements behind them.
- **Pool reconciliation** against the real Privacy Pools commitment scheme (Poseidon +
  LeanIMT), relying on chain facts rather than the user's claims: commitments must be leaves
  of the root; every in-period deposit and every pre-period lineage of a declared account
  must be disclosed; lineages are followed through the chain's own withdrawal links; a
  movement's date, kind and BRL amount must agree with the event that created it.
- **Spend state proven, not claimed**: each disclosed position carries a proof from
  upstream's audited `commitment.circom` (the ragequit circuit - no new circuit) binding its
  nullifier hash, so a withdrawn position cannot be passed off as held
  (`src/proofs.ts`, `test/dishonest-disclosure.test.ts`).
- Two disclosure scopes: **fiscal period** (epoch secrets) and **specific transactions**
  (per-note keys). Signed bundle, validity window, on-chain `grantId`.
- **Expiry is cryptographic**: issuing a grant seals the note chains it reads
  (`AuditGrantRegistry.registerAndRotate`), so no key ever reads a note written after it was
  issued; revocation stops the vault releasing anything further.
- **Subject binding**: the on-chain grant records the bundle's ed25519 signer, and grants are
  keyed per owner so a registration cannot be front-run.
- **Note vault as a service** (`src/vault-service.ts`, Flux spec `packages/ops/flux/vault.json`):
  never receives a viewing key or an opening balance, every route authenticates itself,
  owner-only access log, per-grant rate limiting and scope filtering on every release.
- Fiscal epochs in **America/Sao_Paulo**, so quarter boundaries match Receita Federal's.
- `IndexedPoolState` rebuilds pool state from L1 logs; tests assert it yields the same root
  and the same report as the in-process model.
- Sender attestations separate a legitimate inbound transfer from an undeclared account.
- **Recovery from the spending key alone**: lineages, indices and balances rebuilt from L1
  events; note contents restored from vault ciphertexts.
- Durable state via `WalletStore`, encrypted at rest, chain re-verified on restore.
- **On-chain chain anchors**: heads committed as the user transacts, so a disclosure cannot
  omit history the user already published.
- **`ShieldedNoteLog`**: optional on-chain note emission that enforces `seq`/`prevHash` at
  write time, making a rollback impossible rather than merely detectable — and letting a wiped
  device recover its full itemised history with no vault at all.
- One chain hash shared by the attestation, the anchor and the note log, cross-checked against
  the deployed contract on an EVM.
- Ragequit exits modelled, so an honest exit is not reported as a truncated disclosure.
- Auditor-side verifier producing a BRL statement; refuses out-of-scope records.

See [docs/audit-viewing-key.md](docs/audit-viewing-key.md) for the design, the threat
model, and — importantly — the honest limits of revocation.
[docs/security-review-phase1.md](docs/security-review-phase1.md) is the internal security
review (task 1.6): the fixed findings (including two adversarial passes over the fiscal
statement), what was reviewed and cleared, and the open risks that are decisions rather
than defects.
[docs/availability.md](docs/availability.md) answers the handoff's invariant — *if any
service dies, no user loses funds or access* — service by service. **It does not hold as
stated.** No single compromised service can take shielded funds, and a private withdrawal
needs no service of ours; but ragequit from a Safe needs the server co-signer, some
combinations of outages freeze funds, and colluding zkTLS witnesses (for bank payments) can release LP escrow.
[docs/audit-scope.md](docs/audit-scope.md) is the package for an external reviewer — what
to attack first, the claims we want challenged, known issues not worth rediscovering, and
where the two real bugs actually were.

## Live pool (task 1.5)

Deposit → shielded balance → withdrawal, against a **deployed** pool rather than a model:

```bash
anvil --fork-url $ETHEREUM_MAINNET_RPC        # fork mainnet so CreateX exists
cd protocol/contracts && forge script script/Deploy.s.sol:EthereumMainnet \
  --broadcast --rpc-url http://127.0.0.1:8545 --private-key <anvil key>

npx tsx packages/viewing-key/examples/live-pool.ts <entrypoint> <pool>
```

It makes a real deposit, rebuilds the tree from L1 logs with `IndexedPoolState`, and
**compares our root against the contract's**; then posts an ASP root, generates a real
groth16 withdrawal proof via the SDK, and spends on-chain. Roots match before and after.

`src/pool/rpc-source.ts` is the log fetcher behind it — plain JSON-RPC over `fetch`, no
signer, so a read-only auditor tool cannot move funds even by accident.

## Private withdrawal via the relayer (task 1.3)

```bash
cd protocol/relayer && CONFIG_PATH=./config.local.json node dist/index.js
npx tsx packages/viewing-key/examples/relayed-withdraw.ts <entrypoint> <pool>
```

The user builds the proof offline and **signs nothing on-chain**; the relayer pays gas and
takes a fee in BPS. The recipient is a freshly generated address, so the run asserts the
real property: it ends up funded while its transaction count is still zero.

Note the fee ceiling. A pool's `maxRelayFeeBPS` must exceed the relayer's base fee *plus*
gas expressed in BPS, or every relay reverts — see FORK.md, it bounds the smallest
relayable withdrawal.

## Smart accounts (task 1.2)

A passkey seeds the shielded wallet through the WebAuthn **PRF extension**, so no seed is
ever stored and device loss is survived by passkey sync. Spending goes through a **Safe
2-of-2** (device + server co-signer) over **ERC-4337**, and the demo proves the threshold
by submitting a single-owner UserOperation to the real EntryPoint and watching it fail.

```bash
npx tsx packages/smart-account/examples/smart-account-deposit.ts <ppEntrypoint> <ppPool>
```

The passkey is also a **real on-chain Safe owner** (`examples/passkey-owner.ts`): a P-256
assertion is verified on-chain via ERC-1271, so spending needs the authenticator, and an
assertion over the wrong digest is rejected. `examples/gasless-deposit.ts` adds
`SponsorPaymaster` so the user holds **no ETH at all** — verified against a snapshot control
where the unsponsored account burns its balance on gas and the deposit never lands.

Operations also go through a **real bundler** (Alto, `npm run bundler`) over the actual
ERC-4337 RPC rather than calling `handleOps` directly, with the paymaster staked as bundlers
require. `browser/passkey-check.html` tests PRF support on real hardware — the one part that
cannot run headlessly.

See [packages/smart-account/README.md](packages/smart-account/README.md) — including why
this is threshold-by-multisig rather than MPC, and what is still open.

**Beside Safe, Kernel v3.1.** `PasskeyCoSignerValidator` keeps the passkey AND co-signer rule inside one validator;
`FrostValidator` and `KernelAvatarAdapter` add FROST and the same delayed recovery. **The server half**,
[packages/cosigner](packages/cosigner/README.md), signs only over a digest it computes itself, after a user-verified
passkey signature over that digest checks out against the key on-chain. It refuses authority changes, serves the
recovery veto, sponsors new accounts through `SponsorGate` (whose operators can only sponsor, within a daily budget),
and pushes recovery alerts while the app is closed.

ERC-4337's validation rules are checked with a rule-enforcing bundler (Rundler in safe mode on geth, `erc7562-live.ts`).
The whole Movva flow runs from either account kind (`MOVVA_ACCOUNT=safe|kernel`).

**The app**, [packages/app](packages/app/README.md), is a PWA in Portuguese on that stack. It is tested in headless
Chromium with a virtual passkey authenticator.

## The BRL ramp (Phase 2)

```bash
anvil --fork-url $ETHEREUM_MAINNET_RPC
npx tsx packages/ramp/examples/onramp.ts       <ppEntrypoint> <ppPool>   # BRL -> shielded
npx tsx packages/ramp/examples/offramp.ts      <ppEntrypoint> <ppPool>   # shielded -> BRL
npx tsx packages/ramp/examples/zktls-onramp.ts <ppEntrypoint> <ppPool>   # settled by zkTLS
npx tsx packages/ramp/examples/matcher-live.ts                           # the matcher service
npx tsx packages/ramp/examples/full-rail.ts    <ppEntrypoint> <ppPool>   # BOTH phases, joined
npx tsx packages/ramp/examples/brl-price.ts                              # who can price BRL?
```

`full-rail.ts` is the one that proves the phases are a single product rather than two that
happen to share a repo: a passkey-seeded wallet buys BRL-side, the shielded balance
recomputes from **her** spending key, an auditor verifies a disclosure over that ramp
deposit, and the off-ramp sale is funded by a real groth16 exit from the pool.

Each deploys the ramp, runs a real trade and checks the pool's own Merkle root against the
one our indexer rebuilds. `zktls-onramp.ts` deploys through
`contracts/script/DeployRamp.s.sol`, the same script a real deployment uses, so the wiring
under test is the wiring that ships.

**The matcher and the arbitration desk are services the protocol runs**, and both are built
so that running them confers no power over user funds. The matcher has no key: it rebuilds
the order book from L1 events, reconciles it against the escrow's storage, and answers
"which offers should you take" — the taker locks the order themselves. `matcher-live.ts`
asserts that, including that the service source contains no signer, no `writeContract` and
no `sendTransaction`. The arbitration desk signs rulings but cannot execute them; the escrow
acts only on a registered arbitrator's signature for an order already in dispute, and the
desk stores evidence commitments rather than the documents, which carry names and CPFs.

**Settlement assets** are ETH or any listed ERC-20; each carries its own oracle and decimals,
because "BRL per ETH" is not "BRL per USDC" and 1e18 price math is wrong by 1e12 for a
6-decimal token. Fee-on-transfer and rebasing tokens are refused rather than mis-accounted.
**USDT** is proven on both escrows against the real token, Chainlink feed and 0xbow's USDT pool
(`UsdtRampFork.t.sol`), including Tether's pause, fee, blacklist and deprecation powers over
escrowed funds ([docs/security-review-phase2.md](docs/security-review-phase2.md), SR2-20 to SR2-29).
Nothing new starts in frozen USDT: the escrows and the yield vault ask the issuer before taking any,
no order locks toward a listed party or below the pool's minimum, a paid user whose shielded delivery
became impossible takes it directly instead (`takeDeliveryDirect`), and `assetCap` bounds what one
listing of an escrow can freeze.

**Pricing BRL on Ethereum L1 needs a keeper, not code.** Run
`packages/ramp/examples/brl-price.ts` to see the current state from every source rather than
taking this paragraph's word for it. The Chainlink BRL/USD aggregator is gated to EOA readers and
last updated in August 2023. Pyth publishes FX.USD/BRL, but Pyth is pull-based and nobody had posted
it to Ethereum. Both facts are asserted against the live contracts in
`contracts/test/{PythFork,OracleFork}.t.sol`, which fail the day either changes. Mova's decision
(14 September 2026): the rate is Pyth's FX.USD/BRL, posted by Mova's own Pyth keeper
(`packages/yield`) and read through `PythFxOracle`. Posting is permissionless and the keeper's key
holds no role; what it needs is Hermes access, gas and Pyth's update fee. Each asset's band is its
Chainlink USD feed crossed with that rate (`ChainlinkSignedFxOracle` over `ScaledFxBandOracle`,
`ORACLE_KIND=signed-fx`, a name that predates Pyth), so a USDT depeg reaches the band without anyone
signing a stablecoin price. What bounds a wrong rate on the ramps is that the escrows use the oracle
as a *band* and never as the price: it changes which offers are postable and cannot move value.
`SignedPriceOracle`, where a named quorum publishes the rate and their signatures are public, remains
a supported alternative (`FX_SOURCE=signed`).

**The FX market closes; PIX does not.** Pyth publishes FX.USD/BRL on weekdays, 08:00-17:00 New York
time, and not at weekends, on 25 December or on 1 January: about 73% of the week is closed.
`PythFxOracle` reads it two ways. The rate refuses a price older than its max age, at any hour. A
band's reading takes the last close outside the core session (`FxMarketHours`: 13:30-21:00 UTC on
weekdays), stamped current, for up to four days. So the ramps keep trading at night and at weekends,
and nothing that moves value is priced at a closed market's last close (SR2-35 in
`docs/security-review-phase2.md`).

The Movva reserve is the one contract that uses a price as a price: it mints and redeems at Chainlink's
USDT/USD crossed with that rate, and refuses while the rate is stale. So the oracles' own governance is
delayed too. Adding a publisher, lowering a threshold, repointing a feed, lengthening a max age or
widening a confidence bound is scheduled in public and waits out `GOVERNANCE_DELAY`, and no oracle
prices until its setup is closed (SR2-30).

**LPs run a node, not a script.** `packages/lp-node` keeps an LP's offers priced inside the band,
answers a taker's signed request for payment instructions, matches the BRL credit in the LP's bank
and releases it on a zkTLS proof of that bank session, and on the off-ramp claims, pays only after
confirmations and settles on a proof of the PIX it sent or the bill it paid. Every
outgoing payment carries an idempotency key written before the bank is called, so a crash never
pays twice. It holds the LP's key and moves the LP's money, so each LP runs its own, never on Flux.
Receiving uses the Banco Central API Pix; sending needs an adapter per bank, and one is ready for Banco Inter
(`src/banks/`), built from the provider's
published API and awaiting a sandbox run. A gateway LP's node
also mints the Movva its offers need and redeems the Movva it buys back. Stuck transactions are replaced under a fee cap, the
journal compacts itself, and disputes get salted evidence commitments filed with the arbitration desk.
`FOUNDRY_OUT=forge-out npx tsx packages/lp-node/examples/lp-node-live.ts` runs it end to end (PIX,
boleto, off-ramp, a crash mid-payment), and `lp-node-movva-live.ts` runs the gateway.

**Cards are out of the MVP.** The client's decision of 24 September 2026 (Rev. 3 §2.2 removes the credit card
rail): the card rail, the attestor quorum (`AttestorQuorumVerifier`), its PSP attestor keys and the
`packages/attestor` service were deleted, so every bank rail settles on a zkTLS proof and nothing settles on a
named party's word. `docs/card-rail-removal.md` records what went and how to restore it from git history.

**PIX, boleto and TED settle only on zkTLS, and going live with it needs credentials, not code.**
Since 14 September 2026 both escrows refuse to open a bank-rail offer or sale on a verifier that does
not prove the bank session (`provesBankSession()`, `BankRailNeedsZkTls`; SR2-34), so no attestor quorum
can settle a PIX payment that never happened. The cost is that nothing settles by PIX or
boleto until a Reclaim application credential and per-bank provider templates exist, and each LP proves
its own bank session. `reclaim-client.ts` requests proof
sessions, polls them, converts the result and checks the witnesses against the on-chain set
before a settlement is attempted. What it cannot contain is a Reclaim application credential
and a provider template for the bank — a proof attests to a session between a real person
and their real bank, so it cannot be manufactured server-side by anyone, which is the point.
`examples/reclaim-witnesses.ts` handles attestor rotation, without which proofs from a new
Reclaim epoch stop settling.

## Movva: the token users hold

Users see reais and hold **Movva**, a BRL-pegged token (1 Movva = R$ 1,00), as shielded notes.
There is no savings product and no user yield (client decision D1, 14 October 2026).
[docs/movva.md](docs/movva.md) is the design; the flow is:

1. **Mint.** A gateway - a Phase A LP with a contract with the issuer - buys USDT and mints Movva at
   `MovvaReserve` at the oracle rate. The USDT sits in the reserve and earns in `YieldVault` (Aave v3).
2. **Buy.** The LP sells Movva to users over Movva's own escrow pair, by PIX or boleto, delivered into the user's shielded Movva balance.
3. **Hold.** Users hold Movva as shielded notes in the Movva Privacy Pool.
4. **Reserve yield.** The reserve's surplus above its 108% target - Aave yield and the issuer's hedge carry -
   stays in the reserve as backing. It is Mova's, not users', and reaches Mova only through the hedge path
   (`withdrawToHedge` within the daily limit, the queued hedge withdrawal above it).
5. **Sell and burn.** A user sells Movva to an LP over the off-ramp, for a PIX payout or a bill the LP pays
   for exactly the sale's amount; the LP redeems it at the reserve for USDT, and the Movva is burned.
6. **Revenue.** Mova earns the reserve's mint and redeem fees ("the fee in transactions with node providers")
   and the reserve's yield: 0.10% to mint and 0.10% to redeem by default, benchmarked to traditional finance
   ([docs/movva.md](docs/movva.md), "Fees"), under hard caps.

Minting and redeeming wait for the FX market. The reserve mints, redeems and withdraws to the hedge
only at a fresh Pyth rate, while Movva's band on its escrow pair takes the last close, so
users keep buying and selling Movva at night and at weekends from what gateways already hold; a gateway
that runs out stops quoting until the market reopens ([docs/movva.md](docs/movva.md), "The rate").

The reserve's dollars are hedged off-chain by the issuer, short USD/BRL on B3; the on-chain buffer,
ratio floors and daily limits are the backstop, and `packages/movva` publishes signed hedge statements
anyone can check against the chain. The LP node runs the gateway (`packages/lp-node`, "The Movva
gateway"); the Pyth keeper posts the rate; the monitor alerts on the ratio, the
rate, the hedge statement and the withdraw headroom.
[docs/security-review-movva.md](docs/security-review-movva.md) is the internal review.

`packages/wallet/examples/movva-wallet-live.ts` runs all of it at once on a local anvil with real proofs: the LP
mints from USDT, the user buys by PIX and boleto, sells back, the LP burns, an auditor verifies
the period, and Mova's fees are checked against the reserve's own events.

## Reserve yield (Phase 3)

```bash
npx tsx packages/yield/examples/backtest.ts                        # delta-neutral over real Hyperliquid data
```

The yield infrastructure is the reserve's, not users'. `MovvaReserve` holds its idle USDT in a
`YieldVault` (its `setYieldVault` target, governor-chosen and delayed); what the vault earns raises
the reserve's backing and is Mova's. There is no user-facing yield: the shielded yield router, the
share pool and the savings relayer that let users zap a shielded balance into a vault and back were
removed with savings (client decision D1, 14 October 2026).

**Sources** sit behind `IYieldAdapter`, under `YieldVault` (ERC-4626):

| Adapter | Source | Notes |
|---|---|---|
| `ERC4626Adapter` | sUSDS (Sky savings rate, ~3.6%); Aave v3 USDT wrapper (3.19% at the fork block) | permissionless; fork-tested for accrual, and on Aave for the supply cap, borrowed-out liquidity, a frozen or paused reserve, and USDT's fee, blacklist and pause |
| `LidoStakingAdapter` | wstETH (~2.2% measured) | valued at min(redemption, Chainlink); instant exit via Curve with an oracle-anchored minimum, queued exit via Lido |

**Risk controls.**
- **Conservative valuation.** Adapters report what their positions could actually fetch.
- **Allocation limits.** Each adapter has an allocation cap, and the vault has a deposit cap.
- **Drawdown breaker.** A fall in the share price pauses deposits and leaves withdrawals open.
  Anyone can trigger the check, but only the governor can resume.
- **Depeg and oracle guards on Lido.** A depeg or a stale oracle stops new stake. It also
  haircuts the valuation, so the loss shows in the share price immediately.

The tests perform each attack rather than describing it: a manipulated Curve pool, a stale
feed, a frozen or paused Aave reserve.

**Tokenized T-bills.** `SuperstateUSTBAdapter` subscribes and redeems Superstate USTB atomically
in USDC, valued at the NAV its redemption facility pays with a bounded rate of increase, and is
fork-tested against the real fund. Using it needs Superstate to onboard the vault - and its
eligibility rules do not list Brazil today - so that is a business question, not a code one.

**Delta-neutral (3.3).** `contracts/hyperliquid` holds the collateral in a contract on HyperEVM
that trades HyperCore through CoreWriter: the keeper can only trigger bounded rebalances, exits
work with the keeper offline, and breakers cover funding and drawdown. It is tested against a
HyperCore simulator and its reads against live HyperCore, but it has never traded on HyperCore,
and it is deliberately not connected to the reserve's vault: that needs a bridge, which is the
client's decision. [docs/delta-neutral.md](docs/delta-neutral.md).

**Keepers** run as replicable services (`packages/yield/src/bin/`) behind `KeeperGate`, which
gives each replica its own revocable key and a daily turnover budget. Open decisions are in
[docs/security-review-phase3.md](docs/security-review-phase3.md) (a dated review that also covers
the since-removed router).

## Deployed on Sepolia

The full stack runs on a public network, not only a fork —
[docs/deployments.md](docs/deployments.md) has the addresses and the on-chain evidence:
deposit → shielded balance → withdrawal with a real groth16 proof accepted by the deployed
verifier, and a passkey Safe owner with P-256 verified on-chain.

## Not implemented yet (deliberately)

Not built: per-bank payout adapters for the LP node
(each bank's own API), per-user daily caps (Rev. 2 §10.1 - the tier numbers are not in
this repository, nor a decision on how a cap binds a person without linking their addresses), and a
bridge from the shielded vault to the HyperEVM strategy. Not verified: the delta-neutral vault trading on real HyperCore,
and the passkey recovery module's signature path, which postdates Zodiac's last full audit.

**MPC** is implemented in [packages/mpc](packages/mpc/README.md): FROST threshold Schnorr
(RFC 9591) with a PedPoP distributed key generation, so no party ever holds the group secret,
and one signature on-chain instead of two. [docs/wallet-custody.md](docs/wallet-custody.md)
covers the passkey-sealed device share and passkey-only recovery when the server is gone.
`npx tsx packages/mpc/examples/two-party-sign.ts` walks the protocol step by step.

`contracts/SchnorrVerifier.sol` verifies those signatures **on-chain** — via a construction
that coerces `ecrecover` into computing `z·G − c·P`, one precompile call instead of point
multiplication in Solidity. `examples/mpc-owner.ts` runs a Safe whose **single owner** is
the FROST group: one signature on-chain, two parties required, indistinguishable from a
plain key.

It is **unaudited from-spec cryptography** — both the library and the verifier — and is the
first thing an external reviewer should read. Safe 2-of-2 remains available as the
conservative alternative.

One thing gates anything further, and it is not code: **there has been no external audit**.

`LocalPrivacyPool` remains the model used by the unit tests; the live path above is what
checks it against reality. Note that doing so immediately found a real discrepancy — see
`test/scheme-onchain.test.ts`.

Contracts are tested twice over: a Foundry suite in
[contracts/test/](contracts/test/AuditGrantRegistry.t.sol) (what a reviewer will reach for),
and the same cases through an `@ethereumjs/evm` harness in `test/evm.ts` so they run in the
same `vitest` pass as the client library.
