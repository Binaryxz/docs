# Open questions for the client

Every decision still blocking work, collected from Rev. 3, the comments on it, the deployment instruction and the
"like Bitcoin" proposals. Each has our recommendation, so a one-word answer is enough where you agree.
Written 24 September 2026.

> **Status lines added 18 October 2026** (against commit `5cfa0cc`). Each question keeps its original text and now
> ends with a **Status** line: *decided* (with the date and the record), *built per the recommendation* (with the
> commit), or *open*. "Open (no recorded decision)" means we found no record in this repository that the client
> decided it; it does not mean nobody has discussed it.
>
> **A naming clash to know about.** The client's written decisions of 14 October 2026 carry their own labels - **D1**
> (MOVVA only), **A1** (the ASP registry), **B1** (the ownerless paymaster), **C2** (the guardian goes at
> finalization) - which are not this document's question numbers. Below, those are always written "client decision
> D1" and so on.

## A. Before the immutable deployment — these can never be changed afterwards

**A1. Who creates MOVVA: the reserve, or the escrow?**
Today the token has no owner, no settable minter, no pause and no upgrade, and its only minter is the USDT-backed
reserve — the design agreed on 14 September, where Movva is pegged to R$ 1,00 and backed by a USDT reserve. Rev. 3 §5.1
instead says the escrow mints on settlement and supply equals escrow mints minus burns. Both cannot hold. After an
immutable deployment this is permanent.
*Our recommendation: keep the reserve, and update Rev. 3 §5.1 to match, because the reserve is the backing design that
Rev. 3 defers to a separate treasury document.*
**Status: built per the recommendation; the choice itself is open (no recorded decision).** The MOVVA-only rail
deployed on 15 October 2026 (commit `84e97d0`) mints only through `MovvaReserve`, which is the token's only minter
(`docs/deployments.md`; `docs/security-review-m1.md` §5.1). We found no record that the client chose the reserve over
Rev. 3 §5.1's escrow mint: `docs/HANDOVER.md` (ninth pass, 5 October) lists "who mints MOVVA" as undecided,
`docs/rev3-conformance.md` decision 1 is still open, and client decision D1's "deposit PIX -> mint MOVVA" does not name
the minter. No record that Rev. 3 §5.1 was updated.

**A2. After setup, do we renounce everything, or keep the ability to revoke a leaked key?**
Renouncing every role is one command and needs no code change. The cost: nobody could ever revoke a compromised
arbitrator, zkTLS witness or attestor key, lift a pause, replace a gateway (only gateways redeem), or repoint an oracle
if a feed is retired. The escrow's own code says a stolen arbitrator key can drain every liquidity provider's offer, and
revocation is the defence.
*Our recommendation: first remove the keys (A3, A4), then renounce everything. If any key must remain, we propose a
one-way switch that permanently disables every risk-raising change while keeping revocation — that is one new function,
so we will not add it without your approval.*
**Status: decided - renounce everything (Option A), not yet executed.** The M1 review records the client's acceptance
of Option A and its price: SRM1-2 is "accepted (Option A)" and §8 lists the "residual risks the client has explicitly
accepted" (`docs/security-review-m1.md`, dated 14 October 2026). Client decision C2 (14 October 2026, commit `ccdc79d`)
adds that `--finalize` sends the reserve's guardian to `0x…dEaD`. The one-way switch was not requested and is not
built. `--finalize` has not been run on the live rail: the deployer still holds the governors and `OWNER_ROLE`
(`docs/deployments.md`), and it refuses while any permanent role is a test identity (SRM1-1).

**A3. Do credit cards stay out of the MVP?**
Rev. 3 removes them; the card rail is built and works. Cards are the only reason the attestor keys still exist.
*Our recommendation: confirm they stay out; we then delete the attestor quorum and its keys entirely, which completes
your "pure zkTLS, no human keys" proposal with no new technology.*
**Decided 24 September 2026: cards stay out of the MVP.** The attestor quorum, its keys and the PSP attestor service were deleted (`docs/card-rail-removal.md`).
**Status: decided 24 September 2026, built** (deleted in commit `c6e5444`, 5 October 2026).

**A4. The association-set provider: a governed contract, or one the user picks?**
Your proposal asks to remove `ASP_POSTMAN` from the Entrypoint. That role lives inside the audited Privacy Pools code,
and the pool refuses any withdrawal whose root is not the Entrypoint's latest, so removing it means editing and
re-auditing the core — which your own rule excludes. The postman is only an address, so it can point at a multisig, a
DAO or an aggregator that publishes only when several providers agree: the ASP gets its own governance, with no change
to the audited code. Letting each user choose their own ASP needs a separate pool per ASP, and users on different ASPs
would no longer share an anonymity set.
*Our recommendation: a governed ASP contract now, one anonymity set; revisit user-selectable ASPs only if you accept a
core fork and the privacy loss.*
*Note: the fallback you ask for already exists — if an ASP stops publishing, the depositor can always exit by ragequit.*
**Status: decided 12 October 2026, built and deployed.** The client moved `ASP_POSTMAN` to a registry of independent
ASPs outside the audited core (commit `7f4d433`), and client decision A1 of 14 October 2026 set 3 ASPs with a
threshold of 2 (commit `ccdc79d`). `contracts/AspRootQuorum.sol` has no owner and no setter; on the MOVVA-only rail it
is the only `ASP_POSTMAN` holder (`0x7f8Bb7B988F866f280e4999Ea4259cFBd24846bD`), and Task 1's root was the first posted
by 2 of the 3 ASPs (`docs/deployments.md`). Still open: the three ASPs are test identities until the client confirms
two independent entities, which means a new quorum before `--finalize`; SRM1-14 (votes cannot be withdrawn; CIDs must
match byte for byte) is open (`docs/security-review-m1.md`). User-selectable ASPs: not pursued.

**A5. Above the daily withdrawal limit: a timelock, or a multisig?**
A multisig is an admin key, which contradicts A2. A timelock is not: the withdrawal is announced on-chain and executes
after a delay, with nobody able to approve or block it.
*Our recommendation: timelock.*
**Status: decided 24 September 2026 (timelock), built and deployed.** The decision is quoted in `docs/movva.md`,
"Timelocks above a daily limit". Built in commit `c6e5444`: the reserve's `queueHedgeWithdrawal` /
`executeHedgeWithdrawal` (announced, executable by anyone after `HEDGE_QUEUE_DELAY`, no cancel) and
`LimitedYieldVault`. The hedge queue is in the live reserve (`deployments/sepolia-movva-only-rail/VERIFICATION.md`).
Open from that pass (`docs/HANDOVER.md`, ninth pass): a gateway redeem above a daily amount, per-address against global
limits, and whether an owner may cancel a mistaken request. Queued requests never expire (SRM1-10); `--finalize`
refuses while one is unexecuted.

**A6. The divergence breaker: does it clear itself?**
A breaker that trips and clears on its own needs no key. One that a human must lift needs a key that survives A2.
*Our recommendation: self-clearing.*
**Status: decided 24 September 2026 (self-clearing), built, not deployed on Sepolia.** The decision is quoted in
`docs/movva.md`, "The divergence breaker"; `DivergenceBreaker` (no owner, no setter, no state) was built in commit
`c6e5444`. The Sepolia rail runs without one (`MOVVA_RAIL_BREAKER=off`: Sepolia has no second BRL price source;
`deployments/sepolia-movva-only-rail/VERIFICATION.md`). Open before a mainnet deployment: SRM1-7 (a dead tripping source
halts the reserve for good while `HALTS_REDEEM=true`, the default; `docs/security-review-m1.md`).

**A7. What goes in the first deployment?**
The escrow needs the pool, the token, the registry, the oracles and the verifiers. Yield, savings and node rewards could
follow in a second deployment. *(Savings has since been removed from M1 altogether: client decision D1, 14 October 2026.)*
*Our recommendation: deploy the escrow's core first. It is a smaller review for you, and less is frozen forever while
decisions are still open.*
**Status: decided by client decision D1 (14 October 2026), deployed 15 October 2026.** D1 is MOVVA only: no sMovva or
savings pool and no ETH/USDT ramps (commit `ccdc79d`). The MOVVA-only rail (`84e97d0`) has 20 contracts: the protocol,
the stand-in USDT, the reserve and token, the FX leg, the band adapter, `FeeSplitter`, `NodeRewards`, the Movva pool,
the `AspRootQuorum`, the registry, the zkTLS verifier and the Movva escrow pair. No yield vault, no breaker, no ETH/USDT
pair (`docs/deployments.md`). Unlike our recommendation, node rewards went in the first deployment.

## B. Scope of V1 — needed to finish and test the right thing

**B1. Tier limits: keep or remove?**
Rev. 3 §12.1 gives the numbers (R$ 2.000/1.000 a day at tier 0 up to R$ 30.000/15.000 at tier 4, with retention and
withdrawal speeds). Your comments on the document say "we will remove tiers, maybe next version" and "we remove this".
The limit mechanism is built and is off unless configured, so either answer is cheap — we need to know which.
*If tiers stay: we set those numbers. If they go: we leave the mechanism unconfigured and drop retention and tiered
withdrawal speed, which were never built.*
**Status: open (no recorded decision beyond the comments).** The only record is the 16 September comments quoted
above (`docs/rev3-client-comments.md` §4). In the meantime the build is in the "if they go" state: the LP node's
per-payer caps are off unless an LP configures them, and retention and tiered withdrawal speed are not built
(`docs/HANDOVER.md`, "Honest limitations").

**B2. "First the user can hold and sell USDT and burn MOVVA" — what does the V1 user hold?**
Today the user holds MOVVA, shielded; the reserve holds USDT; only a gateway redeems and burns. If V1 users hold and
sell USDT themselves, that is a different product: a shielded USDT balance and an off-ramp that takes USDT from the
user.
*We need this spelled out before building V1.*
**Status: answered for M1 by client decision D1 (14 October 2026).** M1 is "deposit PIX -> mint MOVVA -> hold as
shielded notes -> withdraw to PIX" (`docs/HANDOVER.md`, update of 15 October): the user holds MOVVA, shielded, and no
user-held USDT path was built. Redeeming and burning stay with the gateway, as run live in Task 3, where the LP
redeemed the MOVVA it received (`docs/deployments.md`). Whether a later version lets users hold or sell USDT
themselves: open (no recorded decision).

**B3. Sub-wallets: V1 or V2, and which assets?**
Rev. 3 requires sub-wallets with independent seed phrases; your comment says moving funds between them is V2 and that
they hold "movva and others". Nothing of this is built yet.
*Our recommendation: V2, with the transfer path already built and waiting.*
**Status: built (commit `c6e5444`, 5 October 2026); moves between sub-wallets stay V2.** `docs/HANDOVER.md` (ninth
pass) records that this pass built what the client's 24 September answers settled, sub-wallets among them; the
wording of that answer is not recorded here. Each sub-wallet has its own BIP-39 seed from fresh entropy, its own
shielded keys and account (`docs/wallet-custody.md` §12). The transfer path this recommendation mentioned was
deleted when the client removed shielded transfers from scope on 12 October 2026. On the M1 rail sub-wallets hold
MOVVA, the only pool (client decision D1); "MOVVA and others" as a multi-asset requirement is open (no recorded
decision). Not done: recovery is the phrase alone, and the app cannot yet build the ownerless paymaster's data for a
sub-wallet's account (SRM1-17), although the paymaster sponsors such accounts on-chain (Task 2, `docs/deployments.md`).

**B4. The MPC: which network?**
Today the account's second key is a co-signer that Mova runs, trust-minimised but operated by one party. Your comment
asks for a "permissionless and decentralised MPC". Moving to a threshold network nobody administers changes who signs
and who pays per-signature fees.
*We need the network named, or the properties that define "permissionless" for you: anyone can run a node, anyone can
enrol, or both.*
**Status: open (no recorded decision).** The second key is still the Movva-run co-signer, with FROST (DKG and its
transport, `packages/mpc`) as the built option (`docs/wallet-custody.md` §5).

**B5. Exchanges as a route: liquidity provider, or Mova's own float?**
"Not only P2P but CEX and DEX also". An exchange can run a liquidity provider node, which keeps escrow and the payment
proof and leaves custody with the exchange. A route where user money lands in Mova's exchange account is a custodial
float, which Rev. 3 removed. For a DEX route we would also need to know which BRL stablecoin, and who converts it to
reais.
*Our recommendation: exchanges as liquidity providers.*
**Status: open (no recorded decision).** No CEX or DEX route is built; an exchange could run the existing LP node
(`docs/runbook-lp-onboarding.md`).

**B6. One proof provider, or provider-agnostic attestation?**
Payments are proven by zkTLS today in Reclaim's format only. ZKP2P's newer design normalises several providers
(TLSNotary, Primus, Reclaim) behind one attestation.
*Our recommendation: launch with one, add the others later — unless you need provider independence from day one.*
**Status: open (no recorded decision).** The deployed rail has one verifier, `ReclaimZkTlsVerifier`, in Reclaim's
format (`docs/deployments.md`).

**B7. The third price source.**
You asked for a DEX TWAP beside Chainlink and Pyth. BRL liquidity on Ethereum is thin, and a TWAP over a shallow pool is
easier to manipulate than the feed it checks.
*Our recommendation: a second signed price publisher instead of a DEX TWAP.*
**Status: answered in the client's 24 September breaker decision, against our recommendation; built, not deployed.**
The decision quoted in `docs/movva.md`, "The divergence breaker", asks for "several independent sources, including a
TWAP". Built in commit `c6e5444`: `ChainlinkCrossSource` and `UniswapV3TwapSource` as breaker sources. The
median-of-three alternative, which would stop the TWAP halting anything on its own, is not built and waits for the
client to ask for it (`docs/movva.md`). No breaker, and so no source, is deployed on Sepolia.

**B8. The delta-neutral venue.**
Marked "we will define until Monday" in your comments; still open. The vault and keeper are built for Hyperliquid, and a
different venue means a different adapter.
**Status: open (no recorded decision).** No venue is chosen (`docs/delta-neutral.md` §12.8: "The venue. Still open.").
Since this was written the sleeve became venue-neutral: `contracts/hedge/` (`IHedgeVenue`, `HedgeSubWallet`; commit
`2edad0d`) and the risk engine `packages/yield/src/hedge-risk` (commit `4ba16e5`). On Sepolia it runs against
`SimHedgeVenue`, a TEST-ONLY simulator, deployed 17 October 2026 at `a90c78f` and not funded (`docs/deployments.md`).
`contracts/hyperliquid` is one optional adapter among others, not the venue.

## C. What we need from you to proceed operationally

1. **Sepolia ETH** for the deployer `0x4C0A…d214`, which holds none. We will confirm the exact amount from a gas
   rehearsal before you send it.
   **Status: provided.** `0x4C0A…d214` was funded on 21 September 2026 and its partial run superseded; every later
   deployment was funded from a fresh deployer: `0xD249…73D1` (the 6 October rail and the 14 October account stack),
   `0x3c43…2779` (the MOVVA-only rail, 15 October) and `0x4D0d…8853` (the hedge sleeve, 17 October)
   (`docs/deployments.md`).
2. **An RPC endpoint without a log-range cap** (a paid Alchemy/QuickNode key or an archive endpoint), to run the full
   privilege inventory against real Sepolia.
   **Status: still open, no longer blocking.** The inventory now reads event logs in windows the provider accepts
   (Alchemy's free plan allows 10 blocks), and it ran against real Sepolia for the MOVVA-only rail: 176 functions
   classified, 0 unknown (`docs/deployments.md`).
3. **A Pyth Hermes credential and a funded keeper key.** The stale Sepolia BRL price you saw in the report does not have
   to be waited out: our own keeper posts updates, which is what it does in production.
   **Status: Hermes credential provided and in use.** Task 1 read Hermes with `HERMES_API_KEY` and posted FX.USD/BRL to
   Sepolia on 14 and 15 October 2026 (`scripts/task1-mint-and-shield.ts`, `docs/deployments.md`). The posts came from
   the Task 1 script, not from a keeper service; we found no record of the Pyth keeper running continuously on Sepolia,
   so the price there goes stale between posts.
4. **A Reclaim application credential and a provider template per bank**, without which no PIX or boleto can settle.
   **Status: open.** Sepolia still runs on seed-derived test witnesses and an illustrative bank endpoint; the rotation
   to Reclaim's witness set is planned and needs these (`docs/deployments.md`, custody rehearsal, "Planned, not rotated
   here").
5. **KMS keys** for the co-signer and its sponsor operator, and a VAPID key for recovery alerts. (The zap relayer, which
   also needed one, was removed with savings: client decision D1, 14 October 2026.)
   **Status: open (no record of them being provided).** The custody plan adds a KMS/HSM key for the gateway, also not
   provided (`docs/deployments.md`, "Planned, not rotated here").
6. **Confirmation that the old Sepolia owner key is still held**, so we can renounce the roles on the abandoned
   deployment.
   **Status: answered 24 September 2026: the key is lost.** The 8 September stack is documented and monitored instead
   (`deployments/abandoned-sepolia-2026-09-08.json`, `orphan_watch`). The superseded 21 September stack's roles were
   renounced on 14 October 2026 (`docs/deployments.md`).
7. **The audit engagement:** we recommend a manual review plus a public competition and a mitigation review, as you
   proposed. [audit-scope.md](audit-scope.md) is written for the reviewer.
   **Status: open (no record of an engagement).** The scope and readiness documents are current as of 18 October 2026.

## D. For the record

**D1.** Your deployment instruction settles the question your document comments raised: we proceed with the **Privacy
Pools fork**, not the Kohaku SDK and Umbra. Please confirm, since that reverses the comments on §1, §2.3, §4.1 and §4.2.
**Status: not confirmed in writing (no recorded decision).** The build proceeded on the fork, and the client's later
decisions are framed on it: the ASP registry "outside the audited core" (12 October 2026, commit `7f4d433`) and client
decision D1's Movva Privacy Pool.

**D2.** Rev. 3's data model assumes a backend database (users, orders, viewing keys). This rail has none by design:
orders live on-chain, each liquidity provider keeps its own journal, and the device holds what belongs to the user. The
invoices, QR payment requests and conversion dashboard in §12.3 depend on that backend, so they do not exist. Tell us if
they are wanted.
**Status: open (no recorded decision).** Invoices and a dashboard still do not exist (`docs/HANDOVER.md`, "Honest
limitations").

**D3.** Offering yield to Brazilian users, and a governance token over a treasury, each carry their own regulatory
question. Both are named in Rev. 3 as needing legal review before launch.
**Status: open (no recorded legal review).** Client decision D1 removed user-facing yield from M1 (the reserve's yield
is Mova's), so the first question does not arise for M1. No governance token is built.
