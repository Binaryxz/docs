# The permissionless LP registry

`contracts/ramp/PermissionlessLPRegistry.sol` is an LP registry with no curator and no admin. It implements
`ILPRegistry` exactly as the audited escrows use it, so the **unchanged** `FiatEscrow` and `OffRampEscrow` bytecode can
be redeployed against it. The curated `LPRegistry` stays as it is: this is a second registry, not a change to the first.

The client approved it on 19 Oct 2026 with these requirements:

| Requirement (verbatim) | Where it is met |
|---|---|
| any LP can join by posting the required bond and meeting on-chain rules | `join(amount)`: at least `MIN_BOND` MOVVA, escrows bound, the address not already bonded or leaving |
| any LP can exit after an unbonding period | `requestExit()`, then `withdraw()` once `UNBONDING_PERIOD` has passed and nothing is live |
| the escrow accepts LPs dynamically, with no curator and no admin | `capOf(lp)` is a pure function of the LP's bond; there is no list to be put on |
| a misbehaving LP loses its bond automatically | `recordDispute(lp)`, which the escrows call when a dispute is ruled against the LP, takes the whole bond in the same transaction |
| no admin key is needed to add or remove an LP | there is no admin key at all |

The audit freeze held: `git diff 3f63b7e -- contracts/ramp/FiatEscrow.sol contracts/ramp/OffRampEscrow.sol
contracts/ramp/RulingLib.sol contracts/ramp/ILPRegistry.sol` is empty. No requirement needed an escrow or interface change.

## The rules

| Action | Who | What happens |
|---|---|---|
| `join(amount)` | any address | at least `MIN_BOND` MOVVA is pulled into the registry; credit = the bond in centavos |
| `topUp(amount)` | a bonded LP that is not leaving | more MOVVA in, more credit |
| `requestExit()` | a bonded LP | credit is 0 **in the same block**; the unbonding clock starts |
| `withdraw()` | a leaving LP | after `UNBONDING_PERIOD` **and** with no exposure live: the whole bond back; the address may join again |
| `reserveExposure` / `releaseExposure` | the two bound escrows | as in `LPRegistry`: one credit across both escrows, each escrow releases only what it reserved |
| `recordSettled` | the two bound escrows | counts settled volume. A record only: it moves no limit and pays no reward |
| `recordDispute` | the two bound escrows | the whole bond is slashed and locked in the registry for ever |
| `consumeBankTxId` | the two bound escrows | spends a bank transaction id, refused if this registry **or its predecessor** spent it |

There is no cancelling an exit and no partial unbonding: an LP that wants back in withdraws and joins again. An LP
whose bond a slash took joins again with at least `MIN_BOND`; its record (settled volume, disputes lost) stays public.

## Parameters, and why

| Parameter | Value | Kind | Why |
|---|---|---|---|
| Bond asset | MOVVA | immutable | R$ 1,00 each, already the rail's unit; 18 decimals (checked in the constructor) |
| Credit per bond | 1 centavo per 1e16 MOVVA base units (credit = bond value), rounded down | constant | see "Credit is the bond" |
| Slash | the whole bond, per lost dispute | constant | see "A lost dispute takes the whole bond" |
| `MIN_BOND` | 5.000 MOVVA (R$ 5.000,00) by default in the deploy script | immutable | the curated registry's starting retail limit (`LPRegistry.BASE_CAP_CENTS`). Constructor floor R$ 1,00, whole centavos |
| `UNBONDING_PERIOD` | 36 days on the live rail (`DISPUTE_TIMEOUT` 30 days + 1 + 4 + 1) | immutable | strictly longer than the escrows' whole dispute window; `bindEscrows` re-checks it on-chain |
| `ESCROW_RULING_DELAY` | 1 day | constant | the escrows' `RULING_DELAY`; `bindEscrows` checks OffRampEscrow's public value against it (FiatEscrow's is the same value, internal for size) |
| `UNBONDING_MARGIN` | 4 days | constant | FiatEscrow's longest pay window (a boleto's 1 h to issue + 3 days to pay) for a position open when the exit is asked, plus most of a day for inclusion |
| `MAX_UNBONDING_PERIOD` | 365 days | constant | so a typo cannot lock every bond for good |
| `PREDECESSOR` | the live `LPRegistry` | immutable | see "Bank transaction ids across registries" |

### Credit is the bond

The worst a lost dispute can cost a counterparty is the disputed position's own BRL value. On the on-ramp, an LP that
disputes an order the taker really paid, and is never ruled against in time, keeps both the taker's BRL and its crypto
(`FiatEscrow.expireDispute`). On the off-ramp the seller's crypto always comes back, so the worst there is the time it
was frozen. Every such position is exposure reserved in the registry (an LP's own dispute keeps it reserved until the
dispute ends), and the escrows cannot reserve more than the credit. So everything an LP could take from counterparties
at once is at most its credit, which is its bond. Because a lost dispute takes the whole bond, misbehaving never pays:
the LP gains at most its exposure and loses at least its bond.

A ratio above 1:1 (more credit than bond) would break that. A ratio below 1:1, a haircut, would cover MOVVA trading
under its peg. That choice belongs to the client (see below).

### A lost dispute takes the whole bond

`recordDispute(lp)` carries no amount and no counterparty, and `ILPRegistry` is frozen with the escrows. So the slash
cannot be sized to the disputed position, and it cannot be paid to the victim. Of the rules that need neither, only
"the whole bond" keeps the guarantee above. A fixed share (say half) would let an LP whose one disputed position is
bigger than that share come out ahead. "The whole bond" is also what the client wrote.

What triggers a slash is exactly what the escrows report:
- an off-ramp REFUND ruling, meaning the LP claimed a sale and did not pay it;
- a dispute the LP raised itself, on either escrow, that it then loses or lets time out.

A counterparty's unanswered dispute never reaches the registry, so nobody can cost an LP its bond by disputing while
the desk is down. Once the bond is gone, later lost disputes take nothing more. That is still sound: the first slash
took at least everything the LP could have gained across all of them. If the LP joins again, the new bond answers for
any dispute still waiting for a ruling.

### Where slashed MOVVA goes

Nowhere. It stays in the registry, counted in `totalSlashed`, and no function can move it. Every option that would move
it is worse:
- Movva can only be burned by its reserve, out of the reserve's own balance.
- A transfer to `address(0)` reverts.
- Paying it to Mova would give the party whose arbitrators decide disputes a stake in the outcome.
- `recordDispute` does not name the victim, so it cannot go to them.

The effect is a burn in all but `totalSupply`. It benefits every holder, because the reserve's backing now stands
behind fewer tokens that can ever be redeemed, and it benefits nobody in particular. `MovvaReserve.collateralRatioBps`
still counts the locked tokens as supply, so it understates the ratio, which is the conservative direction. MOVVA sent
to the registry directly is locked the same way.

### Exit: why "nothing live" is the rule that closes it

`withdraw` needs both the unbonding period and zero exposure. The second condition is the one that matters. Every
escrow path that ends in `recordDispute` holds the position's exposure until the transaction that reports the dispute:
the off-ramp releases it immediately before, and the on-ramp keeps an LP-disputed order inside its offer's reservation.
A taker's on-ramp dispute gives the credit back at once, and none of its outcomes records a lost dispute. Once the credit
is zero, nothing new can be reserved.

So when an LP's exposure is zero, no dispute can still slash its bond. The unbonding period is the client's rule and a
public notice period on top of that. Time alone would not be enough: a LOCKED order nobody reclaims can be disputed long
after its pay window. `PermissionlessRampIntegration.t.sol` (`test_AnExitCannotOutrunALiveDispute`) runs this exact case.

Exposure always reaches zero without the LP's help, because every position can be ended by anyone:
- once the LP's credit is 0, `closeOffer` returns its standing offers' free liquidity to it;
- `reclaimExpired` and `releaseStaleClaim` end positions whose pay window has passed;
- `expireDispute` ends a dispute after its timeout.

### No admin, and the one-shot binding

The registry has no owner, governor, curator, pause, upgrade or setter. The escrows cannot be immutables, because each
escrow takes the registry's address in its constructor, so the registry has to exist first. `bindEscrows(onramp,
offramp)` solves that once:
- only `DEPLOYER` may call it, and only once;
- each escrow must already exist and name this registry as its `REGISTRY`;
- each escrow's `DISPUTE_TIMEOUT` + `ESCROW_RULING_DELAY` + `UNBONDING_MARGIN` must be shorter than `UNBONDING_PERIOD`;
- after it, `escrowsBound()` is true for ever and `DEPLOYER` has no power left;
- before it, `join` reverts and `capOf` is 0, so no bond is ever at risk from a binding its LP could not see first.

To check on-chain that setup is closed, read `escrowsBound()`, `fiatEscrow()` and `offRampEscrow()`, and read
`REGISTRY()` on each escrow. `lp bond:status` prints all of it. The escrow set never changes: a new escrow pair needs a
new registry, which names this one as its `PREDECESSOR`.

### Bank transaction ids across registries

`consumeBankTxId` refuses, and `usedBankTxId` reports, any id that this registry has spent or that `PREDECESSOR` reports
as spent. The check is transitive, so a successor of this registry inherits both sets.
`test_ABankTxIdSpentUnderTheOldRegistrySettlesNothingHere` replays an id spent under the old `LPRegistry` against both
new escrows, and both refuse it (`ReceiptReplayed`).

The other direction cannot be closed from here. The old registry does not consult its successor, so an id spent here
could still settle a position on the **old** escrows. That needs a live position on the old pair, which the cutover
prevents.

**While the two run side by side** (the Sepolia deployment below sits beside the final rail, with no cutover), that
direction is open. It matters only for an LP that quotes on BOTH pairs to the same PIX key: a taker who locks one order
with it on each pair and pays once could prove the same payment to both, and the curated pair would not see that the
new one spent it. Until a cutover, an LP on both pairs must quote a different payee on each (another PIX key or
account). Boleto orders are not affected: each boleto is issued for one order, and its commitment is the payee.

### Rewards: none

`NodeRewards` pays only INSTITUTIONAL and AFFILIATED LPs. Its farming bounds rest on contracted identities (SR2-36): an
LP that settles with itself from a second address breaches a contract with a named counterparty. A permissionless LP has
no such counterparty. The best a hook could report is RETAIL, which `NodeRewards` ignores. So there is no hook, and
`recordSettled` only counts and emits `Settled`. Rewards for bonded LPs would need a new contract with its own bounds.

### MUST-NOT-revert paths, reentrancy, transfers, rounding

- `releaseExposure`, `recordSettled` and `recordDispute` make no external call and write a fixed number of slots. Each
  returns quietly for any caller that is not a bound escrow, and `releaseExposure` subtracts with saturation. The
  measured cost is under 40k / 70k / 70k gas (`test_TheMustNotRevertPathsAreCheapAndBounded`). The invariant suite
  counts any revert on these paths, and the count stays zero.
- MOVVA moves only in `join`, `topUp` and `withdraw`, on the LP's own call, with effects before the transfer. Movva is a
  plain OpenZeppelin ERC20: no hook, no fee, no rebase. The amount sent is the amount received, and no transfer can call
  back in. The only other external calls are views: the predecessor's `usedBankTxId`, and the escrows' getters during
  `bindEscrows`.
- Rounding: credit rounds down (never more credit than bond). The escrows round exposure up. Both directions go against
  the LP.

## Trust model

Nobody can add, remove, re-credit or slash an LP except through the rules above, and nobody can move a bond except its
own LP, through `withdraw`. What is still trusted is what was trusted before: **the escrows' dispute process**. An
arbitrator's ruling decides a lost dispute, and the escrows' governors choose the arbitrators. Adding an arbitrator
waits out the escrows' `GOVERNANCE_DELAY` in public. A malicious arbitrator could burn bonds by ruling REFUND on
disputed off-ramp sales, but it could not take them. An LP that paid a seller and can prove it settles by proof, even
on a disputed sale, before any ruling.

## Deploying on Sepolia, beside the final rail (deployed 20 October 2026)

`scripts/deploy-permissionless-registry.ts` deploys the registry and a new escrow pair BESIDE the final rail of 20
October 2026 (`deployments/sepolia-movva-final-rail.json`, tag `audit-freeze-2026-10-20`). Nothing on the final rail
changes: no transaction goes to any of its contracts, and its curated pair keeps running. What it takes from the final
rail, every value read from the live contracts:

| | Value on Sepolia |
|---|---|
| `PREDECESSOR` | the final rail's `LPRegistry` `0x3C7f5f7dDF970af011f549C67C50BB7d14670248` |
| Bond token | the final MOVVA `0x22E1e640752eB91461566B70e6D8099583588f04` |
| `MIN_BOND` | 5.000 MOVVA (`PERMISSIONLESS_MIN_BOND`, whole MOVVA, to change it) |
| `UNBONDING_PERIOD` | 36 days: `DISPUTE_TIMEOUT` 30 days + `RULING_DELAY` 1 + `UNBONDING_MARGIN` 4 + 1, strictly past every dispute window |
| Escrow constructors | the final pair's `ORACLE` (the reserve `0xb7a8…11B6`), `POOL_ENTRYPOINT` and `POOL` (the Movva pool), `BAND_BPS` 300, `GOVERNANCE_DELAY` 48 h, `DISPUTE_TIMEOUT` 30 days |
| Asset listings | as on the final pair: MOVVA enabled with the reserve as its band oracle, ETH delisted, no caps |
| Verifier | the final rail's zkTLS verifier `0x9970…5712`, the only one |
| Arbitrator | the 2-of-3 arbitrator Safe `0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7`, the only one |
| Governor | the final pair's, `0x4D0dF9bB92883cf5584c812EB84AABA55d688853` (also the deployer, so no handover) |

The transactions are those of `contracts/script/DeployPermissionlessRegistry.s.sol`, in its order (14 from one key):
the registry; the FiatEscrow; the OffRampEscrow; `bindEscrows`; each escrow's ETH and MOVVA listings; the verifier;
the arbitrator; `completeSetup` on each. They are sent one at a time rather than by `forge script --broadcast` so that
each live gas limit is Sepolia's own estimate at send time: Sepolia charges about 7x what the pinned Foundry predicts
for contract creation (the final rail's FiatEscrow took 38.4M gas). The rehearsal runs the frozen forge script itself,
simulated on the fork, and checks that its own refusals and assertions pass and that it creates the same three
addresses from the same nonce.

```bash
# The dry run: preflight on Sepolia (read-only), the whole deployment on an anvil fork of SEPOLIA_RPC (port 8955),
# verified there read-only, the forge script cross-check, and the same transactions replayed read-only on Sepolia
# (eth_simulateV1) for gas. Writes deployments/sepolia-movva-final-permissionless.rehearsal.json and
# deployments/sepolia-movva-final-permissionless.rehearsal/etherscan-verify.sh.
npx tsx scripts/deploy-permissionless-registry.ts

# The real run, from a clean checkout with forge-out built (forge build), with the final rail's deployer key in .env
# (SEPOLIA_HEDGE_DEPLOYER_KEY, or PERMISSIONLESS_DEPLOYER_KEY):
PERMISSIONLESS_CONFIRM=deploy-permissionless-registry-to-sepolia-from-0x4d0df9bb92883cf5584c812eb84aaba55d688853 \
  npx tsx scripts/deploy-permissionless-registry.ts --broadcast-sepolia
# interrupted? the same command with --resume: a sent transaction is adopted, never sent twice

# Afterwards, and any time: read-only verification, and Etherscan (the V2 API; the pinned forge speaks only V1)
npx tsx scripts/deploy-permissionless-registry.ts --verify deployments/sepolia-movva-final-permissionless.json
ETHERSCAN_API_KEY=... FORGE=$(bash scripts/foundry.sh path) python3 scripts/etherscan-verify-v2.py \
  deployments/sepolia-movva-final-permissionless/etherscan-verify.sh deployments/sepolia-movva-final-permissionless/etherscan-verified.json
```

`--broadcast-sepolia` refuses unless `PERMISSIONLESS_CONFIRM` is exactly that string; `SEPOLIA_RPC` is Sepolia and not a
local node; the tree has no uncommitted change outside `deployments/`; the escrow, registry and deploy-script sources
are byte-identical to `audit-freeze-2026-10-20` and `forge-out` is their build; a fresh rehearsal passes; and the
deployer holds the projected ETH. The record `deployments/sepolia-movva-final-permissionless.json` has the shape of a
rail record (`contracts.ramp.registry` and `permissionlessRegistry` are the new registry, `movvaOnramp` /
`movvaOfframp` the new pair, `predecessorRegistry` the curated one), so the `lp` tool takes it as `--rail`.

**What the verification checks** (61 checks in the rehearsal): the registry's immutables, its binding (and that
`bindEscrows` cannot run again), each dispute window against the unbonding period, and that no admin function answers
(`owner`, `governor`, `setupComplete`, `pause`, `upgradeTo`); each escrow's registry, governor, closed setup, delay,
timeout, band, oracle, pool, asset listings and caps, and its verifier and arbitrator sets read from its own events (the
zkTLS verifier and the Safe, alone); each runtime against this build with only immutables masked, **and against the
final pair's own runtime on Sepolia**: the same audited code, byte for byte outside the immutables; EIP-170; and each
`forge verify-contract` command dry-run offline (forge's standard-JSON input, compiled by solc 0.8.28, reproduces the
code at the address and the creation transaction).

**The rehearsal** (`deployments/sepolia-movva-final-permissionless.rehearsal.json`): see that record for the run's
block, gas and checks. The addresses it predicted were not the final ones (the deployer sent other transactions
first). **The deployed contracts** (`deployments/sepolia-movva-final-permissionless.json`, all checks pass,
Etherscan-verified 3/3): registry `0x21e135789297A0E7F2924Eb25FD074c223AB727D`, on-ramp
`0xF5fb3C7545839A56c6Ccc0CBFf770773323372dC`, off-ramp `0x53354C364f04Bc2059d27bCB53cBE84cdd7232DC`. Sepolia's own gas for
the sequence is about 80.8M (the fork's 11.7M x ~7 for the creations), a fraction of a milli-ETH at Sepolia's current
sub-gwei price and about 0.24 ETH at 2 gwei; the deployer held 0.2 ETH.

**The LP smoke on the fork** (`scripts/permissionless-lp-smoke.ts`, record
`deployments/sepolia-movva-final-permissionless.lp-smoke.json`) deploys the same thing on a fork and walks one LP
through its life with the LP's own tooling, run as a separate process exactly as an LP runs it: MOVVA minted at the
final reserve by the rail's gateway (impersonated on the fork) at a current Pyth FX price posted from Hermes;
`bond:status`; `bond:join 5000` dry run, then `--execute`; R$ 5.000,00 of credit; a 1.000 MOVVA offer on the new
on-ramp, admitted against the bond with no curator (R$ 4.000,00 left; `canQuote` exact to the centavo); `lp:status`;
`bond:exit` (credit 0 in the same block, the exposure still live); `bond:withdraw` refused (unbonding, exposure live);
a stranger closing the leaving LP's offer (the MOVVA goes back to the LP); 36 days on, `bond:withdraw` returning the
whole bond; then a second bond lost to the LP's own dispute timing out (`expireDispute`, anyone's call): `Slashed` in
the same transaction, the 5.000 MOVVA locked in the registry for ever.

### The forge script on its own

`contracts/script/DeployPermissionlessRegistry.s.sol` deploys the registry and then a new escrow pair from the unchanged
escrow code pointing at it. In order:

1. Deploys the registry with the live pair's registry as `PREDECESSOR`, the live MOVVA, `MIN_BOND` (default 5.000
   MOVVA) and `UNBONDING_PERIOD` (default: the pair's longest `DISPUTE_TIMEOUT` + 6 days).
2. Deploys a FiatEscrow and an OffRampEscrow pointing at it.
3. Calls `bindEscrows`.
4. Copies the live pair's setup, as `DeployEscrowPair` does: MOVVA's listing and cap, ETH's listing, the zkTLS verifier
   and the arbitrators.
5. Closes the escrows' setup and hands them to the live governor.
6. Asserts everything, EIP-170 sizes included.

`DeployPermissionlessRegistry.t.sol` runs it against a local copy of the live rail.

```bash
OLD_ONRAMP=0x.. OLD_OFFRAMP=0x.. MOVVA_TOKEN=0x.. ZKTLS_VERIFIER=0x.. ARBITRATORS=0x.. \
  forge script contracts/script/DeployPermissionlessRegistry.s.sol:DeployPermissionlessRegistry --rpc-url $RPC_URL
```

Sizes (runtime, EIP-170 limit 24,576 B):

| Contract | Runtime size |
|---|---|
| PermissionlessLPRegistry | 6,446 B |
| OffRampEscrow | 19,753 B |
| FiatEscrow | **24,576 B, exactly at the limit**. It is frozen and unchanged; the limit is inclusive, and it is deployed on Sepolia at that size |

### Cutover (a governed step, not in the script)

The Sepolia deployment above runs BESIDE the final rail and does none of this: both pairs take business, and the
curated one keeps its institutional LPs (see "While the two run side by side" for the one rule that follows). If the
client later retires the curated pair:

1. Deploy as above; its record names `contracts.ramp.permissionlessRegistry` and the new pair.
2. On the **old** `LPRegistry`, suspend every LP (`lp:suspend`, instant), or close the phases. The old pair then opens
   no new position. This is what keeps a bank transaction id spent on the new ramp from settling on the old one.
3. Let the old pair's live positions run off: sweep expired orders (`reclaimExpired`) and stale claims, and expire
   disputes after their timeout. Then retire the old pair (`setEscrow(old, false)`).
4. Point the app, the LP nodes (`capOf`, `availableCents` and `canQuote` read the same) and the indexer at the new
   pair. The indexer, the examples, `lp:status` and the monitor detect the registry's kind and read `bonds(lp)` there
   (see "LP tooling").

## LP tooling

`npm run -w @mova/ops lp -- bond:<command>` (`packages/ops/src/bond.ts`, dispatched from `bin/lp.ts`). Every command is
a dry run unless `--execute --confirm <lp>` is passed with `LP_KEY` set to that LP's own key. Each call is simulated
before it is sent. Amounts are in MOVVA.

| Command | What it checks before it builds anything |
|---|---|
| `bond:status [lp]` | read-only: no-admin facts, whether setup is closed, each escrow points back, each dispute window against the unbonding period, total bonded and slashed, one LP's bond |
| `bond:join <MOVVA>` | escrows bound and pointing back; not bonded; not leaving; at least `MIN_BOND`; wallet balance. Sends `approve` (if short) then `join` |
| `bond:topup <MOVVA>` | bonded; not leaving; not zero; balance. `approve` (if short) then `topUp` |
| `bond:exit` | bonded; not leaving. Warns: credit 0 at once, anyone may close the LP's offers, no cancel, withdrawable date |
| `bond:withdraw` | leaving; unbonding over; nothing live |

The registry is `--registry <addr>`, or `contracts.ramp.permissionlessRegistry` in the rail record
(`--rail deployments/sepolia-movva-final-permissionless.json` once it is deployed). It was smoke-tested end to end on a
local anvil (join, top up, exit, a refused early withdrawal, then withdraw after the period), and on a fork of Sepolia
against the real deployment path (`scripts/permissionless-lp-smoke.ts`, above).

**Everything else that reads the registry detects which one it is.** A `PermissionlessLPRegistry` answers `MIN_BOND()`
and `escrowsBound()`; the curated `LPRegistry` answers `governor()` / `setupComplete()` / `lps()` instead. A registry
that answers neither (an RPC failure, or not a registry) is an error, never assumed to be curated.

| Reader | On a permissionless registry |
|---|---|
| `lp lp:status` (`packages/ops/src/bin/lp.ts`, `lp-network.ts`, `registry-kind.ts`) | bond, credit, exposure by escrow (`reservedBy`), available credit, exit (`withdrawableFrom`) and slashes; LPs found from `Joined`. `lp:pending` says nothing is ever scheduled; the governor's commands (`lp:admit`, `lp:suspend`, ...) are refused with a pointer to `bond:*` |
| The monitor (`LP_REGISTRY`) | `lp_network` (warns while the escrows are unbound or one does not name the registry back), `lp_credit`, `lp_disputes`, and two new checks below; no `lp_change` |
| The LP node (`packages/lp-node`, `ViemRampChain.credit`) | `capOf`, `availableCents` and `canQuote` as before; `escrowsBound` in place of `setupComplete` (which this registry does not have: the node used to revert there and never quote), and the bond in `/status` |
| The ramp indexer and examples (`packages/ramp/src/lp-registry.ts`) | `bonds(lp)` in place of `lps(lp)`; a bonded LP is quoted as RETAIL |

| Monitor check | Level | When |
|---|---|---|
| `lp_slash:<lp>` | **fail** for `LP_SLASH_ALERT_SECONDS` (default a day) | the LP lost a dispute: a `Slashed` / `DisputeLost` log (stamped with its block's time, so a slash while the monitor was down still alerts), or a `disputesLost` that rose between sweeps. `lp_slash:unattributed` if `totalSlashed` rose and no known LP explains it |
| `lp_exit:<lp>` | **warn**, then **fail** | warn while a leaving LP still has exposure live (with `withdrawableFrom` and the exposure by escrow: a dispute on it can still slash the bond); fail once `withdrawableFrom` has passed with exposure still live |

The fork smoke sweeps the monitor's own watcher at both moments: `lp_exit` warns with the exit pending and the offer
live, and `lp_slash` fails right after the slash.

## What the client must still decide

1. **`MIN_BOND`.** The script defaults to R$ 5.000,00. It is immutable once deployed.
2. **The credit ratio.** 1:1 is the most credit that keeps misbehaving unprofitable. A haircut (for example 80%: R$ 1,00
   of MOVVA for R$ 0,80 of credit) protects against MOVVA trading under its peg. It is one constant, set before
   deployment.
3. **Whole-bond slashing.** This follows the requirement's wording and is the only amount-blind rule that keeps the
   guarantee. The client should accept it knowingly: one wrong ruling, or one LP-raised dispute that the desk lets time
   out, costs an honest LP everything it bonded. LPs should bond only what they mean to have at risk. Proportional
   slashing would need `recordDispute` to carry an amount, which means an `ILPRegistry` and escrow change and so a new
   audit.
4. **Slashed MOVVA is locked for ever.** It could instead go to a fixed, immutable sink, for example a compensation fund
   with its own rules. That would be a new contract and a new decision.
5. **Rewards.** Permissionless LPs earn no node rewards. Sharing fees with them needs a rewards design that holds up
   against self-trading without contracted identities.
6. **Arbitrators.** The bond is exactly as safe as the escrows' arbitration. Whoever governs the escrows' arbitrator set
   now decides who can burn LP bonds.
7. **Cutover timing,** and whether the curated registry keeps running beside the new one for institutional LPs. They
   are separate escrow pairs; an LP's credit on one is not credit on the other.
