# Internal security review — Phase 3 (shielded yield)

Reviewer: internal. Date: 2026-09-11, extended 2026-09-13 and 2026-09-14. Scope: everything under
`contracts/yield/` (including the USTB adapter and `KeeperGate` added on 09-13, and USDT through Aave's
USDT wrapper on 09-14), `contracts/hyperliquid/`,
`contracts/common/ShieldedDepositLabel.sol`, `packages/yield/` (including both keepers), and the
Phase 2 escrow's rescue path, which Phase 3 rewrote.

> **Update, 15 October 2026: savings removed.** Client decision D1 (14 October 2026) removed savings from M1.
> `contracts/yield/ShieldedYieldRouter.sol` (the user-facing shielded yield path reviewed here), `@mova/zap-relayer`,
> the Movva distribution keeper (`movva-keeper`, SR3-12's discovery case) and `MovvaReserve.distribute` were deleted.
> `YieldVault`, `LimitedYieldVault`, `KeeperGate`, the adapters, `contracts/hyperliquid/` and the vault, HyperEVM and
> Pyth keepers remain, as the Movva reserve's own yield infrastructure. Findings about the router and the share pool
> are a record; the review below is otherwise as written.

**This is not an external audit and does not substitute for one.** It is written by the party
that wrote the code. Phase 2's review showed what that costs: a confident comment reads as a
finished argument. This review applies the method that worked there. Each claim a header
makes is turned into a test that tries to break it.

Phase 3 is the first phase whose contracts **hold other people's yield positions** and **price
assets that can lose value**. Phase 2 held escrow at a price two parties had agreed. So the
new questions are about valuation, exits and liquidity, not about who may call what.

## Findings

### SR3-1 — The last holder of the vault could not leave
**Severity: high (availability).** `contracts/yield/YieldVault.sol`, `maxRedeem`. **Fixed.**

`maxRedeem` capped a holder's shares at `convertToShares(liquidAssets())`. Once the share price
moved away from 1, rounding in that conversion came out a few wei below the holder's actual
share balance. For the last holder, or anyone whose whole position was liquid, `redeem(balance)`
then failed ERC-4626's own `maxRedeem` check. The yield that made the position worth leaving
was what made leaving impossible.

**Fix.** When the holder's full balance is covered by liquid assets, return the balance itself.
Convert only when liquidity actually binds.

Regression: `YieldVault.t.sol` has the last holder exit after a gain and after a loss, plus a
fuzz test that a full exit always succeeds.

### SR3-2 — The shielded escape hatch stopped working after one partial withdrawal
**Severity: high (availability).** `contracts/ramp/FiatEscrow.sol`, `rescueShielded`. **Fixed.**

SR2-1 fixed a front-running theft by routing rescues by **commitment**. That was the wrong key.
`ragequit` checks the depositor per **label** and accepts any unspent commitment in that label's
lineage, and a private partial withdrawal spends the deposited commitment and inserts a
successor with the same label. So the escrow did not recognise a user's remaining balance
after their first partial withdrawal. The hatch worked only for users who never touched their
deposit, which is not when anyone needs it.

Two further defects came with the same function:

- it forwarded only the **ETH** balance change, so a rescued token delivery would have stayed in
  the escrow;
- it always called the ETH pool, so a token delivery was "rescued" from the wrong pool and reverted.

**Fix.** A shielded delivery is indexed by `(pool, label)`. The pool comes from the Entrypoint's
`assetConfig` for the order's asset. The label is recomputed exactly as the pool derives it
(`ShieldedDepositLabel`). The proceeds are forwarded in the order's own asset. SR2-1's
property survives unchanged: the payee is the order's recipient, never the caller.

**Why it survived review, and the fix to that.** The rescue test's pool double was keyed by
commitment, the same wrong key the escrow used, so code and test agreed. The double now
follows the real pool's label rules. A fork test (`RampRescueFork.t.sol`) compares the label
the escrow records with the one in the real pool's `Deposited` event, because a recomputed
value checked only against its own model is exactly the Phase 1 bug shape again.

Regression: `RampRescue.t.sol` rescues the remainder after a partial withdrawal, and refuses a
rescue that names the wrong pool.

### SR3-3 — Instant exits sized with truncated intermediate division
**Severity: low.** `contracts/yield/adapters/LidoStakingAdapter.sol`, `withdraw`. **Fixed.**

Both the amount of stETH to sell and the Curve minimum output divided before multiplying.
Neither could be exploited: the minimum only got slightly looser, and the sale was topped up
by two wei. But a minimum output is a safety bound, and it should not lose precision for no
reason. Both are now computed with a single final division. Found by slither.

### SR3-4 — The vault governor could move every holder's assets in one block
**Severity: high.** `contracts/yield/YieldVault.sol`. **Fixed 2026-09-13.**

The vault's header said no role could transfer its assets to an arbitrary address, and that
adapters "should be timelocked in production". Both were true only of intent. Funds leave the
vault into adapters, and an adapter is code: `addAdapter(evil)` + `setKeeper(self)` +
`allocate(evil, everything)` needs one key and one block, and holders learn about it
afterwards. The same shape as SR2-14 on the ramp.

**Fix.** `YieldVault` inherits `contracts/common/DelayedGovernance.sol`. Adding an adapter,
raising an adapter's allocation cap or reactivating it, changing the keeper, raising the
deposit cap and widening the drawdown band are scheduled on-chain and wait out
`GOVERNANCE_DELAY` (48 hours by default); every holder can redeem during that window.
Deactivating or removing an adapter, lowering caps, tightening the band, pausing, resuming and
changing the guardian stay instant, so a compromised keeper is contained at once by
deactivating adapters, and the guardian can still pull funds back. A new vault accepts no
deposits and no allocations until `completeSetup()`, so the instant-change window never
coexists with anyone's money.

Regression: `YieldVault.t.sol` schedules the adapter-and-keeper theft, shows the holder leaving
in full before either change can land, and checks that the brakes remain instant.

### SR3-5 — A replicated keeper put the keeper key on every node, and nothing bounded its churn
**Severity: medium.** `contracts/yield/YieldVault.sol` keeper role, as operated. **Fixed 2026-09-13** by
`contracts/yield/KeeperGate.sol`.

`YieldVault` has exactly one `keeper` address. The requirement is that every keeper runs replicated
on Flux, and Flux node operators can read an app's environment. Replicating an EOA keeper therefore
hands its key to strangers.

The keeper cannot pay itself: `allocate` pays only listed adapters, and `deallocate` and `harvest`
pay only the vault. But it can make holders pay. Every deallocation from the Lido adapter sells on
Curve within `maxSlippageBps`, and nothing limited how often. A leaked key could loop
allocate/deallocate and burn up to 50 bps per round trip, all day.

**Fix.** The vault's keeper is now a `KeeperGate` contract, which:

- takes **one operator key per replica**. The guardian can revoke a key instantly, without touching
  the other replicas. Adding a key waits out the governance delay, like `setKeeper`.
- enforces a **turnover budget**: `allocate` + `deallocate` ≤ `maxTurnoverBps` of assets per 24h window.
  The worst case is stated in the contract: at a 10% budget and 50 bps exit cost, 0.1% of the vault
  per day, twice that across a window boundary.
- forwards nothing before its own `completeSetup()`.

The vault keeper service (`packages/yield/src/bin/vault-keeper.ts`) refuses `REPLICA_COUNT > 1`
without a gate.

Regression: `KeeperGate.t.sol` runs the churn attack against an adapter with an exit cost. It stops at
the budget, and the loss is bounded by budget × exit cost.

### SR3-6 — The T-bill adapter promised a withdrawal the facility could not pay
**Severity: medium (availability). Caught by a unit test before the adapter was used anywhere.**
`contracts/yield/adapters/SuperstateUSTBAdapter.sol`, `maxInstantWithdraw`.

The first version reported the redemption facility's raw USDC balance as the redeemable amount.
The vault then asked for exactly that. Redemption is priced in whole USTB units: `calculateUstbIn`
rounds up, so the request overshot the facility and reverted. The adapter caught that and returned
nothing, and the vault reverted the holder's withdrawal. Whenever the facility was the binding limit,
`maxWithdraw` promised an amount that could not be withdrawn.

**Fix.** The adapter reports what redeeming `maxUstbRedemptionAmount() − 1` would actually pay,
computed the way RedemptionIdle computes it, and caps its redemption the same way.
`test_MaxWithdrawIsBoundedByTheFacilityNotTheFund` withdraws exactly `maxWithdraw` and asserts it
arrives.

This is SR3-1 again: a limit that reads correctly and fails at the edge where it binds.

### SR3-7 — The on-chain funding estimate could not move the last 84 units
**Severity: medium (the breaker would not trip). Caught by a test before use.**
`contracts/hyperliquid/HyperCoreDeltaNeutralVault.sol`, `_sampleFunding`.

The exponential average was stored at 1e8. With an 84-hour time constant and hourly samples, any
step smaller than 85 units truncated to zero. So the average stopped short of a steady input, by as
much as the whole distance between a mildly negative rate and the pause floor.
`test_TheFundingEstimateFollowsHyperliquidsFormula` saw −6166 where the formula gives −6250.

**Fix.** The average is kept at 1e18 and read back at 1e8.

### SR3-8 — The generic adapter passed on liquidity that Aave's wrapper would not pay
**Severity: medium (availability). Caught by a fork test before the adapter held USDT.**
`contracts/yield/adapters/ERC4626Adapter.sol`, `maxInstantWithdraw` and `withdraw`.

Aave's USDT wrapper (StataTokenV2 behind `0x7Bc3…3Af8`) has a pause of its own, separate from the
reserve's, which any Aave emergency admin can set. While it is on, the wrapper's `_update` refuses to
mint or burn shares. Its `maxWithdraw` and `maxDeposit` check only the reserve's flags, so they keep
reporting the position as liquid. The adapter passed `maxWithdraw` straight through. The vault's
`maxWithdraw` therefore counted the whole Aave leg, and a holder who withdrew that much reverted inside
the adapter with `EnforcedPause`, even for the part idle USDT could have paid.

**Fix.** The adapter probes an optional `paused()` on the target, with a staticcall that cannot revert.
While it returns true, the adapter reports no instant liquidity and no deposit capacity. `withdraw`
wraps the target call in try/catch and returns what it sent, as the USTB adapter already did.

Regression: `test_TheWrappersOwnPauseIsInvisibleToItsViewsButNotToTheAdapter` pauses the real wrapper as
an emergency admin. It shows the wrapper's `maxWithdraw` still reporting the position while its
`withdraw` reverts, then withdraws exactly the vault's `maxWithdraw`. Unit tests:
`test_ATargetsOwnPauseIsNotPassedOnAsLiquidity` and `test_ATargetThatRefusesDespiteItsViewsIsCaughtNotBubbled`.

### SR3-9 — A blacklisted adapter would have frozen the whole Aave leg
**Severity: medium (availability, issuer-triggered). Found while adding USDT, fixed before use.**
`ERC4626Adapter.withdraw`.

The adapter withdrew from the target into itself, then transferred to the vault. In USDT's verified
source, `transfer` checks the sender against the blacklist and `transferFrom` checks `from`; nothing
checks the receiver. Once blacklisted, the adapter would still have received every withdrawal and been
unable to forward any of it.

**Fix.** The adapter asks the target to pay the vault directly (`TARGET.withdraw(assets, to, adapter)`)
and never holds USDT on the way out. A blacklisted adapter still blocks new allocations, because the
wrapper pulls from it with `transferFrom`. It cannot block exits.

Regression: `test_ABlacklistedAdapterCannotFreezeExits` (fork, using Tether's own `addBlackList`) and
`test_ABlacklistedAdapterCannotStopAnExitButCannotAllocate` (unit).

### SR3-10 — A USDT transfer fee would have been paid by the vault's other holders
**Severity: low (the fee is off). Fixed.** `contracts/yield/YieldVault.sol`, `_deposit`.

ERC-4626 prices a deposit's shares from `assets`, before the transfer. USDT's verified source has a fee
switch: `setParams` allows up to 19 bps, capped at 49 USDT per transfer. It read zero on 2026-09-14.
Switched on, every deposit would have credited the depositor with up to 49 USDT the vault never
received, paid by everyone else. Nobody profits, but anyone can impose that cost on holders at an
equal cost to themselves.

**Fix.** `_deposit` checks what arrived and reverts `TransferFeeCharged(assets, received)`. Exits are
unchanged: the vault sends exactly `assets`, its books stay right, and the fee comes out of what the
leaver receives.

Regression: `test_ADepositThatArrivesShortIsRefused` and `test_WithAFeeTheLeaverPaysAndTheStayersDoNot`
(unit), and `test_ATransferFeeIsRefusedAtTheDoorAndCostsLeaversNotStayers`, which switches the real fee
on as Tether's owner. What the fee still does to exits is under Open risks.

### SR3-11 — The keeper would have allocated exactly the supply-cap room Aave states, and reverted
**Severity: low (failed keeper rounds; no funds at risk). Caught by a fork test.**
`packages/yield/src/vault-keeper.ts`, allocation sizing.

The wrapper's `maxDeposit` is the reserve's remaining supply-cap room. Aave checks the cap after
`updateState`, and `updateState` first adds the treasury's share of interest accrued since the reserve
was last touched to `accruedToTreasury`. The wrapper's view reads that figure before it is booked. So a
supply of exactly `maxDeposit` reverts `SupplyCapExceeded()` whenever the reserve has gone a block
untouched. The keeper took a source's stated capacity at face value. Whenever the cap was the binding
limit, it would have planned exactly that allocation, simulated a revert it did not recognise, and
reported a failure every round.

**Fix.** The keeper now stays `capHeadroomBps` (default 50 bps) below a source's stated capacity, as it
already did below the vault's allocation cap. It treats `SupplyCapExceeded`, `ERC4626ExceededMaxDeposit`,
`ReserveFrozen`, `ReservePaused` and `EnforcedPause` as "not now". The adapter exposes the optional
`maxDeposit()` and `depositBlocker()` views the keeper reads.

Regression: `test_TheSupplyCapBoundsAllocationsAndTheAdapterSaysSo` lowers the real cap to leave about
500,000 USDT of room, then checks three amounts:
- exactly the stated room reverts;
- the stated room less the computed unbooked accrual, less one unit, goes in;
- the stated room less the keeper's 50 bps goes in.

The unbooked accrual measured 4.3 to 25.7 USDT across runs, depending on how long the reserve had gone
untouched at the fork block. Keeper tests: "stays capHeadroomBps below the supply-cap room Aave's
wrapper states" and "skips, rather than reports, a source that filled up or paused".

### SR3-12 — Every sender used the node's exact gas estimate, and a transaction landing a second later ran out of gas
**Severity: medium (availability; gas wasted, a release or distribution missed).** `packages/yield/src/movva-keeper.ts`,
`vault-keeper.ts`, `hl-keeper.ts`, `packages/lp-node/src/tx-sender.ts`, `packages/wallet/src/executor.ts`. **Fixed 2026-09-14.**

None of the senders set a gas limit, so each used `eth_estimateGas`, which finds the least gas that succeeds against
the state and timestamp it estimates at. A transaction is included later. Found when the Movva distribution keeper's
anvil test failed once under a loaded full suite, and then proven deterministically: at exactly
`lastDistributionAt + 24h`, `distribute()` estimates at 120,006 gas, but included one second later it takes the
branch that clamps `elapsed` to a day and needs 120,011; sent with the estimate it reverted, having used 120,006 of
120,006. Reproducing it by load alone failed three times - the timestamp experiment is what showed it. The same holds
for any transaction whose path depends on the block's time or on state another transaction can change first: an LP
node's release, mint or redeem, a vault keeper's allocation.

**Fix.** Every sender now sets the limit to the estimate plus `GAS_HEADROOM_PERCENT` (default 20%) plus 25,000 - about
one storage slot written from zero that the estimate did not see - never above the block gas limit, never below the
estimate. Unused gas is not charged. A request that states its own limit is sent as is, and the LP node's fee-bump
replacements keep the original limit. When a sent transaction still reverts, the keepers' `/status` and the LP node's
error say why: `out of gas (used X of Y)`, or the error decoded by replaying the call on the parent block, or
`unknown` with what the replay showed - never a bare "reverted".

Tests: `packages/yield/test/gas.test.ts` (the rule's bounds, a property, each diagnosis); a limit above the estimate
and bounded, and a diagnosed revert, for each of the five senders; and on anvil, `movva-keeper-anvil.test.ts` pins the
estimate to the boundary block and inclusion three seconds later, shows the bare estimate running out of gas, and the
keeper's send with headroom mined.

## Reviewed and cleared

- **A relayer cannot change what a zap does.** Everything the router acts on is carried in
  `Withdrawal.data`: the vault, minimum output, deadline, relayer fee and rescue recipient.
  The pool checks the proof's context against `keccak256(abi.encode(withdrawal, SCOPE))`, so
  changing any field is a different context and the pool rejects it.
  `test_ARelayerCannotChangeWhatTheProofAuthorised` swaps the fee and minimum and asserts
  `ContextMismatch`. The fork demo checks that the SDK's context equals `router.context()`
  on-chain.
- **The router spends only what arrived in the same call.** Every amount is a balance delta
  across the pool call. Stray tokens or ETH sent to the router stay put and cannot fund someone
  else's zap.
- **Fake pools.** The source pool must be the Entrypoint's registered pool for its asset, so a
  contract impersonating a pool cannot drive the router.
- **Vaults are allowlisted.** A zap names a vault, but only governor-listed vaults are accepted.
  Listing on the router is not delayed: the router holds nothing between calls, and every zap
  names its vault inside the user's own proof, so a newly listed vault receives only the zaps
  that choose it. The vault's own adapters and keeper are delayed (SR3-4).
  Delisting a vault stops new zaps without blocking rescues (tested).
- **A manipulated Curve pool cannot fill an instant exit.** The minimum output comes from
  Chainlink, not from the pool being traded against. `LidoAdapterFork.t.sol` dumps 60,000
  stETH into the real Curve pool and asserts the exit reverts.
- **A dead or stale oracle cannot freeze the vault or invent a price.** The adapter's views
  never revert. Without a trustworthy price the adapter:
  - values staked ETH with a fixed pessimistic haircut;
  - refuses new stake;
  - offers no instant exit, since an exit without a price has no honest minimum.

  Each behaviour is tested against the real feed, mocked stale and mocked reverting.
- **A depeg reaches the share price immediately.** stETH is valued at the lower of Lido's
  redemption rate and the market price, so a depeg shows up as a loss and trips the drawdown
  breaker, instead of being hidden until someone sells. The breaker stops deposits and leaves
  withdrawals open.
- **Queued exits do not look like losses.** stETH sitting in Lido's withdrawal queue stays on
  the books as pending, so a large orderly exit does not trip the breaker.
- **The drawdown breaker does not depend on one operator.** Anyone may call `checkpoint`. Only
  the governor can resume deposits, and resuming re-bases the high-water mark, which records
  the loss rather than hiding it.
- **The first-depositor donation attack is uneconomic.** Six decimals of share offset. Tested.
- **A bad USTB NAV cannot be redeemed against other holders.** Superstate's oracle accepts a
  checkpoint up to $1.00 (~9%) above the last, so a bad checkpoint could lift the vault's share
  price, and whoever redeemed first would take the difference from everyone else. The adapter values
  USTB at `min(oracle, ref)`, where `ref` rises at most 10% a year and never falls. A drop passes
  through immediately; a jump does not.
  - `test_ABadNavSpikeCannotBeRedeemedAgainstOtherHolders` deposits before a +9% checkpoint and
    redeems after it; the gain is capped at one day of the bounded rate.
  - `SuperstateUSTBFork.t.sol` publishes the largest jump the real oracle accepts, and the vault's
    share price does not follow.
- **A swapped USTB subscription oracle is refused.** Subscriptions are priced by the token's
  `superstateOracle()`, which the token owner can change; redemptions use RedemptionIdle's immutable
  feed. The adapter refuses to subscribe when the two differ. It also reverts any subscription worth
  less than `maxEntryCostBps` below cost at the redemption NAV. Both are tested.
- **The issuer cannot freeze the vault through the adapter.** Tested against mocks and the real
  contracts:
  - revoked allowlist entry, paused token, accounting pause or paused facility: the USTB leg reports
    no instant liquidity and `withdraw` returns what it has;
  - facility drained between the check and the call: the redeem is caught;
  - oracle reverting past expiry: the position is valued at the last good NAV less a haircut.
  Holders can still take everything else.
- **The KeeperGate cannot pay anyone.** It has no transfer path. Its forwarded calls pay only listed
  adapters or the vault, and an operator's balance stays zero through allocate, harvest and
  deallocate (`test_NothingEverReachesAnOperator`).
- **A HyperEVM keeper cannot choose a trade.** `rebalance()` takes no arguments. Every order is an
  IOC inside the band around the HyperCore oracle, at most `maxOrderNotional` per leg, and charged to
  `maxDailyTurnover`.
  - `test_ACompromisedKeeperFillingAtTheBandEdgeIsBoundedByTurnover` fills every order at its limit
    and asserts the loss stays within turnover × (band + fee).
  - Orders HyperCore rejects are never assumed to have happened: every step is re-derived from
    precompile reads (`test_RejectedActionsAreNotAssumedToHaveHappened`).
- **HyperEVM exits do not need the keeper, and the keeper cannot spend what exits are owed.**
  `test_AFullExitWorksWithTheKeeperOffline` exits a $300k position with only anyone-may calls.
  `test_TheKeeperCannotRedeployUSDCOwedToAClaim` runs the keeper against an open claim; the short
  never grows while the claim is owed.
- **USDT through Aave, against the real contracts** (`AaveUSDTFork.t.sol`, 15 tests). Aave governance
  and Tether actions are pranks of their own admin addresses, read on-chain; nothing else is simulated.
  - *Interest:* 900,000 USDT allocated for 30 days gained 2,361.7 USDT, within 1% of Aave's supply rate
    at the fork (319 bps). Writing the index to storage with a real supply leaves the vault's valuation
    unchanged, so the views are not extrapolating something Aave does not book.
  - *Borrowed dry:* a borrower took about 410M USDT, leaving 250,000 liquid. The vault's `maxWithdraw`
    reported idle plus Aave's liquidity. A full redemption was refused up front
    (`ERC4626ExceededMaxRedeem`); a withdrawal of exactly `maxWithdraw` arrived in full; the rest came out
    after repayment. At that utilisation Aave's supply rate read 12.94%, which is the market's own pull
    on liquidity back.
  - *Frozen reserve:* allocations refused, full exit. *Paused reserve:* the Aave leg reports no liquidity
    but keeps its value, so no false loss and no breaker; idle pays out; the guardian's pull returns zero
    without reverting; everything exits after the unpause.
  - *Approvals:* USDT returns no value and refuses a non-zero to non-zero approval; `forceApprove`
    allocates through a stale allowance. *USDT paused by Tether:* views keep working, pulls return zero,
    exits resume after the unpause.
  - *Valuation:* `totalValue` never exceeds the wrapper's own `convertToAssets`, and equals what a
    deallocation actually delivers.
- **Six decimals.** Shares carry 12 decimals, and assets-per-share moves in steps of one part per
  million, so a 100 bps breaker band is 10,000 steps wide (`test_TheBreakerResolvesItsBandAtSixDecimals`).
  KeeperGate budgets in bps of base units (`test_TheKeeperGateBudgetsAUSDTVaultInBaseUnits`, against
  real Aave). The keeper plans in base units and warns at startup when `MIN_MOVE` looks written for a
  token with different decimals.
- **The shielded USDT round trip runs against 0xbow's live deployment**
  (`packages/yield/examples/shielded-yield-usdt.ts`). A 10,000 USDT note in 0xbow's mainnet USDT pool was
  zapped into the Aave-backed vault, held 180 days as a share note, zapped back, and relayed to a fresh
  wallet through `Entrypoint.relay`. Three groth16 proofs were verified by 0xbow's deployed verifiers,
  which the script first checks are byte-identical to the vendored ones. Result at fork block 25,971,705: 10,147.46 USDT back in
  the pool against 9,990 for the same trip with no yield (3.22% annualised); 10,096.72 USDT in the
  wallet after a 50 bps relay fee; no transaction from the user after shielding. Simulated: registering
  the share pool (impersonating 0xbow's owner Safe), posting ASP roots (impersonating its postman), the
  user's USDT balance, and the clock.

## How client assets are segregated

"Segregated" here means two things the code does and one thing it deliberately does not do. Every
claim below points at the code or test that backs it.

**Client assets are held apart from anyone who operates the product.** A vault is its own contract.
Its asset sits at the vault's address or, through an adapter, in a yield source. The Aave adapter holds
wrapper shares and no loose USDT (`test_TheGenericAdapterPutsUSDTIntoRealAave`). No operator balance is
mixed in, and the vault charges no fee.

- **Where the money can go.** The vault moves its asset in two ways only. ERC-4626 exits pay a
  receiver against shares burned from their owner (or spent under the owner's allowance). `allocate`
  pays a listed, active adapter. An adapter's `deposit` and `withdraw` accept only the vault
  (`onlyVault`), and every `withdraw` the vault calls names the vault itself as recipient (`_withdraw`,
  `deallocate`). Shares are minted only against a deposit that arrived in full (SR3-10).
- **Who can move what.**

  | Role | Can | Cannot |
  |---|---|---|
  | Holder | redeem or withdraw their own shares, within what is liquid | touch anyone else's shares |
  | Keeper (a `KeeperGate` when replicated) | move idle asset into a listed, active adapter within its cap; pull it back into the vault; harvest into the vault | pay any address, itself included; allocate while deposits are paused or before setup; move more than the gate's daily turnover budget |
  | Guardian | pause deposits; pull funds from an adapter back into the vault; revoke a gate operator | resume deposits, list adapters, raise caps, allocate |
  | Governor | after the delay: list an adapter, raise or reactivate its cap, change the keeper, raise the deposit cap, widen the drawdown band. At once: deactivate or remove an empty adapter, lower caps, tighten the band, pause, resume, rotate the guardian | transfer the vault's assets to any address |
  | Router | carry a user's proven withdrawal into an allowlisted vault and a pool, and back | choose the vault, the minimum, the relayer fee or the rescue recipient: all are bound into the user's proof |

- **Governance delay.** A risk-increasing change is scheduled on-chain with its full calldata. It waits
  out `GOVERNANCE_DELAY` (immutable per deployment, 24 hours to 30 days; the tests and fork examples use
  48 hours) and must then execute within 14 days. A holder sees an adapter listing or keeper change
  coming and can redeem first (`test_AGovernorCannotListAnAdapterTakeTheKeeperAndAllocateInOneBlock`). A
  new vault takes no deposits and makes no allocations until `completeSetup()`.
- **Guardian limits.** The guardian can stop money coming in and bring money home, nothing else
  (`test_GuardianCanPullFundsBackButOnlyIntoTheVault`, `test_GuardianPausesButOnlyGovernorResumes`).
- **Per-source limits.** Each adapter is capped at `maxAllocationBps` of total assets (`OverAllocationCap`),
  and a vault has at most eight adapters and a deposit cap. The drawdown breaker stops deposits and
  allocations when assets-per-share falls `maxDrawdownBps` below its high-water mark. A source's own
  limits, such as Aave's supply cap, reach the keeper through `maxDeposit()` (SR3-11).

**Each vault holds one asset.** A USDT vault holds USDT and positions bought with USDT, and its shares
sit in their own share pool. The USDS, USDC and USDT vaults are separate contracts, so a loss in one
vault's sources does not reach the others' holders.

**Within a vault, positions are pooled, not held in an account per client.** Every holder owns shares
of the same positions, and a holder's claim is their share count. That is deliberate, and the reason is
privacy:

- **A per-client account publishes the position.** Whether it is an address, a sub-vault or a per-user
  adapter position, it is on-chain. Its balance, every top-up and every withdrawal would be public, and
  its growth would be that client's position times the rate. One movement linked to the client's
  shielding or unshielding would expose the whole history.
- **A pooled position is a note.** The note holds vault shares inside a Privacy Pool, its share count
  never changes, and yield reaches it through the share price, with no transaction that names it. In
  both fork demos the user sends nothing after the first deposit, and the router, not the user, is the
  depositor of record. A per-client account cannot work that way: paying it yield is a transaction to it.
- **The keeper allocates the vault's total.** There is no per-client allocation, which would name the
  account it served.

What pooling costs, so it is not mistaken for per-client insulation:

- **Losses are shared pro rata.** In `test_ABlacklistedVaultFreezesEveryoneAndABurnTripsTheBreaker`,
  Tether burns the vault's idle USDT. A holder who deposited just before the burn bears the same
  percentage loss as the first holder.
- **An issuer action against the vault reaches every holder at once.** Blacklisting the vault freezes
  all exits (same test).
- **Exits share liquidity.** When Aave is borrowed dry, what is liquid goes to whoever withdraws first
  (`test_HighUtilisationLimitsExitsToAavesAvailableLiquidity`).

The mitigations are the ones above: conservative valuation, the breaker, caps and the delay.

## Open risks that are decisions, not defects

- **The ASP needs a policy for router deposits.** Every zapped note is deposited by the
  router, so the ASP sees the router as depositor, never a person. A withdrawal from the
  share pool needs the ASP to approve that label. The natural policy is to approve a
  router deposit when the withdrawal that funded it came from an approved label. That lives
  in the ASP service, not in these contracts, and it has to be written before this is used
  with a real ASP. On the fork, the demo posts roots as the postman.
- **Amounts can link the two sides of a zap.** One transaction withdraws a value from one pool
  and deposits the converted value into another, so the two notes are publicly linked to
  each other. They are not linked to the user unless the source note already was.
  Zapping exactly the amount of a public deposit would re-link it. Wallets should zap
  amounts that differ from the user's public deposits, which partial withdrawals make easy.
- **The rescue recipient is public.** It is stored against the note's label. A wallet should
  use a fresh address, as the demo does. Using the user's own deposit address would publish
  the link the pool exists to hide.
- **Vetting fees apply on both sides of a round trip.** A zap in and a zap out each pay the
  destination pool's fee. On the fork configuration (50 bps each) that is about a percent,
  roughly three months of the sUSDS rate. Setting fees for yield pools is a commercial decision.
- **Tokenized T-bills: the code is done; the issuer is not.**

  **Implemented** (`contracts/yield/adapters/SuperstateUSTBAdapter.sol`):
  - subscribes and redeems Superstate USTB on-chain;
  - values it from the NAV oracle RedemptionIdle pays at, with three checks of its own:
    checkpoint freshness, the issuer's $7 floor, and a rate-of-change bound, because the issuer's
    contract accepts a checkpoint up to $1.00 (~9%) off the last;
  - reports zero deposit capacity with a reason until it is allowlisted;
  - bounds `maxWithdraw` by what the facility would actually pay;
  - never reverts a holder's exit because of the issuer.

  **Why USTB.** Compared against mainnet at block 25,970,523:
  - BUIDL has no on-chain subscription, and its Circle facility reported zero liquidity.
  - USYC's NAV reporter has no on-chain bounds.
  - OUSG and USDY need an Ondo ID, KYC, compliance and rate-limiter setup for each holder.

  **Fork-tested against the real contracts** (`SuperstateUSTBFork.t.sol`):
  - allowlisting, NAV publication and facility drain were simulated by pranking the issuer's own
    owner addresses and calling the issuer's own functions;
  - 1,000,000 USDC in, two days, 1,000,243.96 out;
  - the largest NAV jump the issuer accepts leaves the vault's share price inside the bound;
  - a revoked allowlist entry freezes only the USTB leg;
  - an expired oracle does not freeze the vault.

  **Still needs the issuer:**
  - Superstate must allowlist the adapter (`setProtocolAddressPermission`).
  - Its getting-started page limits funds to "Qualified Purchasers in supported countries", and
    **Brazil was not on that list**. Whether Superstate will onboard a vault whose depositors are
    Brazilian users is a question only Superstate can answer.
  - The issuer can pause the token or the facility, revoke the allowlist entry, drain the facility or
    upgrade the proxies. The adapter survives each without freezing the vault, but it cannot make
    USTB redeemable while the issuer says no.
  - The adapter's vault is a USDC vault, which means a USDC shielded pool alongside the USDS one.

  **Fallback if Superstate declines.** USDY lists Brazil as "restricted" (qualified investors),
  not prohibited.

  **Unchanged:** whether a permissioned, freezable fund is acceptable inside a privacy product is the
  client's call. sUSDS remains the permissionless source.
- **USDT is an issuer-controlled token.** In its verified source, Tether's owner can:
  - blacklist any address, which can then neither `transfer` nor be `transferFrom`'d, and burn a
    blacklisted address's balance (`destroyBlackFunds`);
  - pause all transfers;
  - switch on a fee of up to 19 bps, capped at 49 USDT per transfer;
  - `deprecate` the contract in favour of another, to which every call is then forwarded.

  Tested against the real token:
  - **A blacklisted vault** reverts every exit and allocation. It used to keep accepting deposits,
    because Tether does not check recipients, and stopping that depended on someone pausing it. It now
    asks Tether (and Circle, for a USDC vault) on every deposit: `deposit` and `mint` revert
    `FrozenByAssetIssuer`, and `maxDeposit`, `maxMint`, `maxWithdraw` and `maxRedeem` read zero while it
    is listed. It resumes by itself if unlisted. A burn of its idle USDT is a real loss and trips the
    breaker. Once the vault is off the list, holders share what is left: the Aave leg, which the vault
    never held as USDT (`test_ABlacklistedVaultFreezesEveryoneAndABurnTripsTheBreaker`,
    `test_AVaultFrozenAndUnfrozenResumesByItself`).
  - **With the fee on,** deposits are refused (SR3-10) and exits from idle pay the fee. An exit that
    needs the Aave leg reverts `InsufficientLiquidity`, because the vault receives the fee less than it
    asked for. `maxWithdraw` still counts that leg: the SR3-6 shape, left on purpose. Closing it would
    mean re-asking every adapter until the fee-sized shortfall closes. At Tether's maximum parameters
    that is three more calls per exit (short by 49 USDT, then 0.0931, then 0.000176, then nothing, by
    the fee formula), and on the Lido adapter each would be another Curve sale. The response is
    operational: the guardian's `deallocate` moves the leg into idle for one capped fee, and then
    everyone can leave. Allocations revert. 0xbow's live Entrypoint also refuses USDT deposits with the
    fee on: it forwards the full amount to the pool and held no USDT to cover the fee. So zaps stop at
    the pool in both directions.
  - **0xbow's USDT pool** holds USDT, so a blacklist of the pool freezes every USDT note. The share pool
    holds vault shares, which Tether cannot blacklist, but it can freeze the vault behind them.
- **Aave losses may not reach the share price.** The wrapper prices from Aave's normalized income,
  which depends only on the liquidity index, the supply rate and time. Aave records uncovered bad debt
  in a separate reserve deficit; the USDT reserve's deficit read 0.85 USDT at the fork block. A large deficit
  would show up as illiquidity, not as a lower price, so the breaker would not see it.
- **Wrapper dust.** The wrapper rounds share burns up, so a full exit can leave one wrapper share (at
  most a unit of USDT) in the adapter. `removeAdapter` requires a value of zero, so pull the dust first.
- **Lido exits take days at size.** The instant path is bounded by Curve depth and slippage.
  Larger exits go through Lido's queue, which is days rather than blocks. The vault's
  `maxWithdraw` reports only what can leave now, so users see the limit before they hit it.
- **Delta-neutral (3.3) is built without a trading key, and is still outside the pool.**
  `HyperCoreDeltaNeutralVault` is a HyperEVM contract that holds the collateral itself and trades
  through CoreWriter. The keeper can only call `rebalance()` and `harvest()`. Every order is bounded
  on-chain: an IOC order in a 30 bps band, at most one per leg per call, capped per order and per
  day. Worst case at launch parameters is $185 per call and $740 per day on a $1M vault
  (docs/delta-neutral.md).

  Exits and deleveraging are open to anyone and are tested with the keeper offline. The funding
  breaker applies Hyperliquid's own formula, which reproduced all 4,320 published hourly rates over
  180 days, and its thresholds are the ones the backtest validated.

  **What remains:**
  - Nothing was sent to HyperCore. Actions were exercised against a simulator and the read ABI
    against live data, so a HyperEVM testnet run is the next step.
  - The funds sit on Hyperliquid, under HyperBFT and, to get there, Circle CCTP. That breaks "all
    funds in immutable Ethereum contracts".

  No bridge adapter was added to the shielded vault. Keeping the products separate, connecting them
  through an attested NAV, or not offering delta-neutral yield is the client's decision
  (docs/delta-neutral.md §9).
- **The delay must outlast the slowest exit.** SR3-4's protection is that holders can leave
  before a scheduled change lands. `maxWithdraw` is bounded by instant liquidity, and Lido's
  queue takes days at size, so a vault with a large queued position needs a
  `GOVERNANCE_DELAY` longer than the queue - it is immutable per deployment and can be set up
  to 30 days.
- **Roles.** Governor, guardian and keeper must be the client's multisig and operators, not
  a developer's key.

## What has not been done

- No external audit.
- Lido's withdrawal queue was exercised up to request and refusal of an unfinalized claim.
  Finalization needs a Lido oracle report, which a fork cannot produce, so the claim itself is
  untested against the real queue.
- The ETH-through-Lido path has been tested in pieces: the router's native path with unit
  tests, and the adapter against real Lido, Curve and Chainlink. It has not been run as one
  proven zap on the fork the way the USDS path has. Lido's rate rises only with oracle reports,
  so a time warp shows no yield there.
- None of the Phase 3 contracts are deployed on Sepolia.
- The USTB adapter has never been allowlisted for real. Every issuer action in its fork test is a
  prank of the issuer's owner addresses. The public RPC it ran against serves only recent state, so
  the test runs at the latest block rather than a pinned one.
- `HyperCoreDeltaNeutralVault` has never sent an action to HyperCore. Several things are unverified
  (listed in docs/delta-neutral.md §7):
  - the unit of `usdClassTransfer`;
  - spot order size scaling;
  - order delays;
  - the default account-abstraction mode.
- The keepers (`vault-keeper`, `hl-keeper`) are tested against models of the contracts, not against
  a running chain.
- The USDT vault, its Aave adapter and its share pool are not deployed anywhere. Registering a share pool
  on 0xbow's Entrypoint is 0xbow's decision, and the fork demo impersonated its owner and ASP postman to
  do it.
- The USDT round trip proves each note in 0xbow's live pool while that note is the newest leaf, building
  its path from the tree's on-chain side nodes. A note deeper in the live tree needs its whole leaf
  history, which needs an archive RPC, and none was available.
- The monitor's `usdt_state` check (`packages/ops/src/checks.ts`) also watches the USDT yield vault,
  its adapters and the router (`USDT_VAULT`, `USDT_YIELD_ADAPTERS`, `YIELD_ROUTER`). The vault no longer
  depends on it: it refuses deposits by itself while listed. The alert is so holders can be told.
- No fuzzing of the router beyond the unit suite, and no invariant test across vault, adapters
  and router together.

## Where the bugs have been

Two of the three Phase 3 findings were on **exit paths**. One was the last holder leaving after
yield; the other was the escape hatch after a partial withdrawal. Both happy paths were well
tested, and the leaving path is only exercised when the state has already moved: a new share
price, or a spent commitment. That is also exactly when a user needs it.

SR3-2 is the Phase 1 lesson again: a test double built on the same assumption as the code
cannot find the bug in that assumption. What caught it was writing down what the real pool
does per label, then checking the escrow against the real pool's event on a fork.

The 09-13 additions repeat the shape.
- **SR3-6** was a liquidity limit that read correctly and failed exactly where it binds. The test
  that caught it withdraws the precise amount `maxWithdraw` promised, not a round number below it.
- **SR3-7** was a breaker that never quite reached its threshold. The test that caught it compares
  against the value the documented formula gives, not against "negative".
- **SR3-5** was not a bug in any function but in how the role would be operated. It surfaced only
  when the Flux spec had to say where the key lives.

The 09-14 additions were found only against the real contracts.
- **SR3-8 and SR3-11** were views that state a limit the protocol does not keep at the edge: the
  wrapper's pause, and Aave's cap after booking treasury interest. A mock written from the ERC-4626
  standard would have kept both promises and passed.
- **SR3-9** turned on which side of a USDT transfer the blacklist checks. That is in the token's source,
  not in any interface.
