# Movva — design

Movva is a BRL-pegged token for faster, cheaper and private on-chain payments. One Movva is R$ 1,00.
This document is the design the contracts and services implement. Decisions taken on 14 September 2026, as amended
since (savings removed by client decision D1, 14 October 2026: "Remove savings (sMovva, its shielded pool, the savings
relayer) ... from M1. The scope is: deposit PIX -> mint MOVVA -> hold as shielded notes -> withdraw to PIX. ... yield is
entirely Movva's, not a user-facing product."):

| Decision | Choice |
|---|---|
| What Movva is | A BRL-pegged token |
| What holds the peg | **USDT reserve, dollar exposure hedged off-chain** (option A), with an on-chain collateral buffer and breakers as the backstop |
| Issuer | A traditional legal entity, which operates the reserve and the hedge |
| What users hold | Only Movva, as shielded notes. USDT never reaches a user. There is no savings product (sMovva was removed, D1) |
| Fees | **Benchmarked to traditional finance**: 0.10% to mint, 0.10% to redeem (see "Fees"). The 20% distribution fee went with savings (D1) |
| The USD/BRL rate | **Pyth's FX.USD/BRL**, posted on Ethereum by Mova's own keeper, instead of named publishers (see "The rate") |
| When the FX market is closed | **Trading continues on the last close; minting and redeeming wait for the market** (see "The rate") |
| PIX and boleto settlement | **Only on a zkTLS proof of the bank session**; the card rail and the attestor quorum were removed on 24 September 2026 |

## The flow

```
            ┌────────────── Movva ecosystem ──────────────┐
 user ─PIX─▶│ FiatEscrow (Movva offers) ──Movva──▶ user's shielded Movva note   │
            │        ▲                                                         │
            │        │ sells Movva                                             │
            │   LP (gateway) ──USDT──▶ MovvaReserve ──USDT──▶ YieldVault (Aave) │
            │        │ ◀──Movva (minted at oracle rate)                         │
            │        ▼ buys Movva                                              │
 user ◀─PIX─│ OffRampEscrow (Movva sales) ◀──Movva── user                      │
            │   LP redeems Movva ──▶ MovvaReserve ──USDT──▶ LP                  │
            └───────────────────────────────────────────────────────────────┘
                     ▲ margin USDT / hedge gains USDT ▼
             issuer's hedge desk: short USD/BRL on B3 dollar futures
```

1. **Supply.** An approved LP (a *gateway*) deposits USDT in `MovvaReserve` and receives Movva at the
   oracle rate, less the mint fee. This is "BRL to USDT, mint Movva": the LP bought the USDT; the
   user buys the Movva.
2. **On-ramp.** The LP sells Movva to users over the existing escrows (PIX, boleto), delivered into
   the user's shielded Movva balance. The escrows are unchanged: Movva is a listed asset whose band
   oracle is the reserve itself (R$ 1,00 while fully backed).
3. **No payments between users.** Shielded transfers (Rev. 3 §5.3) were removed from scope by the
   client on 12 October 2026: a user deposits and withdraws, and nothing moves Movva from one user's
   shielded balance to another's. The shielded transfer router was deleted.
4. **No savings.** Movva stays exactly R$ 1,00 and earns nothing for its holder. The reserve's yield
   (Aave, the hedge carry) stays in the reserve as surplus backing; it is Mova's, reached only through
   the hedge path. sMovva, its shielded pool, the savings relayer and the shielded yield router that
   zapped balances into it were removed by client decision D1 (14 October 2026).
5. **Off-ramp.** A user sells Movva to an LP over the off-ramp escrow; the LP redeems it at the
   reserve for USDT, less the redeem fee.
6. **Mova's revenue** ("fee in transactions with node providers and yield"): the mint and redeem fees
   LPs pay at the reserve, and the reserve's yield, which is entirely Mova's.

### Why LPs mint, and not every order

Minting and redeeming at an oracle price is the one place in this system where a wrong price moves
value: mint when the rate reads high, redeem when it reads low. Restricting both to known,
contracted institutions - the Phase A LPs - bounds that to parties with a legal relationship with the
issuer, and keeps the escrows (148 bytes from their size limit before, and audited as they are) out
of it. It is also how fiat-backed stablecoins work: institutions mint and redeem, everyone else trades.

### Where this differs from the architecture diagram, deliberately

The client's architecture diagram draws Movva as "minted 1:1 with USDT on-chain" and "burned back to USDT (1:1)", with
"no derivatives". When the code was checked against that diagram (14 September 2026), Mova confirmed Movva stays
**R$ 1,00**. The diagram asks that users see and hold reais only and leaves the backing open ("treasury/backing design
TBD"); a Movva worth one USDT would make every user's balance in reais move with the dollar. What that choice costs is
the diagram's "no derivatives": the dollar exposure is hedged on B3 (below).

Two more differences follow from the design rather than from a choice about it:

- **No holder earns yield.** The reserve's yield is Mova's (client decision D1, 14 October 2026); a shielded note's amount
  never grows. (The earlier design paid it to savers through sMovva; that was removed.)
- **Mova's fee is charged at the reserve, not on each user trade.** Gateways pay the mint and redeem fees and price them
  into their offers ("Fees"); the escrows charge nothing, and node providers earn their spread.

## Holding the peg: a dollar reserve for a real token

**The principal-locked reserve (client rule, 21 October 2026).** The reserve's USDT never leaves except by
redemption: no role, Safe or governor can withdraw it. It is invested in one ERC-4626 yield source the client chooses
(`yieldVault`, changed only after the delay). Only the yield leaves: the permissionless `harvestYield()` pays to the
fixed `yieldRecipient` (Mova's Safe, changed only after the delay, in either direction) only what sits above
`max(principalUsdt, liabilities at the 108% target)`, so no yield leaves while holders are under-backed or below
target. `principalUsdt` is a cost basis: USDT in by `mint` and `recapitalize`, less USDT out by `redeem`. Redemption is
gateway-only: the off-ramp's LPs, who paid a seller BRL, redeem that MOVVA for USDT. The former hedge path out of the
reserve (`withdrawToHedge`, `queueHedgeWithdrawal`, `executeHedgeWithdrawal`, `hedgeLimitBps`,
`minWithdrawCollateralRatioBps`) is removed. Every hedge, the issuer's FX hedge and the delta-neutral sleeve, runs on
Mova's own capital; its gains come back through `recapitalize` and become principal.

The reserve is in dollars; Movva is in reais. Unhedged, the reserve is long USD/BRL: during 2024 alone
the dollar went from about R$ 4,90 to R$ 6,19 (PTAX, 31/12/2024), and the same move in the other
direction would leave the reserve about 20% short.

**The hedge.** The issuer shorts USD against BRL for the dollar value of the liabilities
(`liabilitiesUsdt()`), on B3 dollar futures (full-size DOL, mini WDO - contract sizes and margin to be
confirmed with the broker). Reserve plus hedge is then a synthetic real position:

| The real... | On-chain reserve | Hedge account | What moves |
|---|---|---|---|
| weakens (USD/BRL up) | worth more reais: surplus | loses: margin calls in BRL | Mova meets the margin from its own capital (the reserve's surplus stays in it as backing) |
| strengthens (USD/BRL down) | worth fewer reais: deficit | gains BRL | the issuer buys USDT with the gains and calls `recapitalize` |

**Carry.** Dollar futures price above spot by roughly the rate differential, so a short converges down
and earns about the difference between Brazilian and US rates over time. Brought back as USDT through
`recapitalize`, it becomes surplus, alongside the reserve's own dollar yield from Aave. Surplus stays in the
reserve as backing. Only yield above the principal and the target leaves, through `harvestYield()`, to Mova's
`yieldRecipient`. Nothing pays it to holders.

**What stays trusted.** The hedge is off-chain. If the issuer does not hedge, or does not bring gains
back, the on-chain ratio shows it within one rate update and the backstops below engage - but the
peg itself depends on the issuer's operations. That is the cost of option A, and why the reserve
publishes everything it can and the issuer publishes signed hedge statements (`packages/movva`).

## The backstop, on-chain

`collateralRatioBps = reserveBrl / liabilitiesBrl`, computed from the oracle rate on every call.

| Rule | Proposed default | Why |
|---|---|---|
| Mint only while ratio ≥ `minMintCollateralRatioBps` | 100% | New holders never join an under-backed reserve |
| Redeem pays `min(1, ratio)` per Movva | - | A run cannot pay early redeemers in full and leave the rest short |
| No withdrawal at all: USDT leaves only by `redeem` (gateway-only) and, above `max(principalUsdt, liabilities at target)`, by `harvestYield` to `yieldRecipient` | - | The principal never leaves (client rule, 21 October 2026) |
| `targetCollateralRatioBps`: the level the issuer keeps the reserve at; `surplusBrlE18` is what sits above it | 108% | The buffer. Nothing is minted against surplus: Movva is minted only by `mint` (there is no `distribute`, D1) |
| The ratios stay ordered: mint floor ≤ target | enforced (`RatiosOutOfOrder`) | The target is also the harvest floor's liabilities leg |
| Supply cap | set at deploy | Bounds everything above while the system is young |
| Both oracle legs fresh | FX 1h, USDT/USD 25h; governance cannot go under 15 min and 1 day (SRM1-20) | No price is a safe answer; a wrong one is not |
| USDT/USD within US$ 0.50 to 1.50, FX within R$ 1 to R$ 100 | enforced (`UsdtUsdOutOfRange`, `FxOutOfRange`) | Catches a wrong feed or unit; real depegs (USDT ~0.85, USDC ~0.87) stay inside |

### Sizing the buffer

The issuer keeps the reserve at the target: surplus above it is Mova's and is taken out through the hedge path. So
the target is the buffer the hedge desk draws on when the dollar rallies, the withdraw floor is how far it may draw, and the
daily limit is how fast. The first proposal (target 102%, floor 105%, 2% a day) put the floor above the rest
point: at rest nothing could be withdrawn, and a rally's first gains were stuck in the reserve while the B3
short called for margin. The hedge desk's `shock()` (`packages/movva/src/hedge.ts`) found it; the contract now
refuses that ordering.

Run from rest on 14 September 2026: R$ 5.400.000 of Movva at R$ 5,40, the short equal to the liabilities
($1,000,000), no free margin at the broker, B3 initial margin **10% of notional (a placeholder, to confirm with
the broker)**, 30 bps to convert USDT to reais (an assumption). "Issuer margin" is what the issuer would post
from its own capital, as a share of supply.

| Move | First proposal: 102% / 105% / 2% | Adopted: 108% / 103% / 8% |
|---|---|---|
| Dollar +5% in one day | ratio 107.1%; issuer margin 3.4%* | ratio 113.4%; **covered by the reserve** |
| Dollar −5% in one day | 96.9%: under-backed until hedge gains return | 102.6%: still fully backed |
| Dollar +10% in one day | issuer margin 8.8%* | issuer margin 1.5%* (the day's limit binds) |
| Dollar −10% in one day | 91.8% | 97.2% until hedge gains are recapitalized |
| 2024 rally (R$ 4,8413 → 6,1923, +27.9%) over 252 sessions | issuer margin 5.3%* (the floor binds) | **covered by the reserve** |
| 2024 reversed (−21.8%) | 79.75% | 84.4% until hedge gains are recapitalized |

\* Depends on the broker's initial margin, here the 10% placeholder.

In every case the short's own gains, brought back through `recapitalize`, restore full backing without issuer
capital. The +10% day is the one the adopted settings do not cover alone: estimates of the free margin it needs
at the broker range from 1.5% of supply (this table's placeholders) to about 6% (the desk's own run). Both are
margin assumptions, not properties of the contract: re-run `shock()` with the broker's numbers before launch.

**At launch the issuer seeds the 8% buffer** - `recapitalize` to 108% - before any gateway is opened, so the
reserve starts at rest rather than at par (where a unit of Aave rounding also stops minting).

### Live coverage, and the top-up commitment

Movva publishes three figures. The first is the live coverage ratio, which is `collateralRatioBps`: the figure the
contracts count. The second is the delta-neutral position, reported separately: whatever sits on the hedge path is
outside the reserve and does not count toward the ratio. The third is the commitment that Movva tops up before
coverage falls below 100%. In practice it tops up once coverage is under the withdraw floor (103%), the monitor's
top-up point.

`hedge-sleeve coverage --json` prints the report from one block-pinned read. The monitor serves the same report live
on `/coverage` and alerts as `reserve_coverage`: `warn` below the top-up point, `fail` below 100%. While the FX market
is closed, both report the last posted rate as stale. Fields, levels and a Sepolia sample: docs/delta-neutral.md §12.9.
In the wallet, the backing notice on Início and the "Reserva e riscos" screen show the same ratio, read at the band's
rate, and the strategy position appears on a separate line.

### Governance

Raising a limit, adding a gateway, changing the treasurer, the hedge treasury address, an oracle or a
fee waits out `GOVERNANCE_DELAY` (`DelayedGovernance`). Lowering a limit, removing a gateway and
pausing mint are instant. A collateral ratio is a floor, so it works the other way round: lowering one
waits, raising one is instant, none can be set below 100%, and they must stay ordered. Pulling USDT back from the yield vault
into the reserve is instant. No role can move reserve USDT anywhere but to a redeeming gateway, to the
yield vault, or - within the rules above - to the fixed hedge treasury.

**Who can stop a redemption (SRM1-20).** There is no pause for redemptions, and the guardian can never stop one.
Precisely:

- **Before `--finalize`, the governor can, instantly**, by removing every gateway (removing one is instant because
  that is how a compromised gateway is cut off; adding one back waits the delay). It can no longer do it through a
  max age: tightening one is still instant, but never below 1 day for USDT/USD (the Chainlink feed's heartbeat) or
  15 minutes for FX (anyone may post a Pyth price), so a healthy leg never reads stale; the review's 1-second max age
  is refused. The FX leg's own contract, `PythFxOracle`, has a governor of its own whose tightening is instant too
  (`setLimits`); it is renounced by the same finalize.
- **After `--finalize`** every governor is `0x…dEaD` and no key can stop a redemption. What still can, with no key:
  the divergence breaker (below), an oracle leg that is stale or outside its bounds, the asset issuer freezing the reserve's idle
  USDT, the gateway or the recipient, and the yield vault's liquidity.

## The rate

`brlPerUsdtE18 = Chainlink USDT/USD × BRL/USD`. The BRL/USD leg is **Pyth's FX.USD/BRL** through
`PythFxOracle`, at 1e-6 precision: a centavo tick (0.19%) is fine for a band but not for minting and
redeeming. Pyth is pull-based, so Mova's keeper (`packages/yield`) posts updates from Hermes; posting is
permissionless and the keeper's key holds no role. The ramps' centavo band oracle reads the same leg
(`ScaledFxBandOracle`), so the reserve and every band see one number. The reserve refuses a leg outside
R$ 1 to R$ 100 per dollar, which catches a centavo value read where millionths belong, and a USDT/USD
leg outside US$ 0.50 to 1.50, which catches a feed that is not a dollar stablecoin's (ETH/USD, BRL/USD, an
inverted pair). A USDT depeg inside that band reaches the ratio through Chainlink's feed; below half a dollar
every mint and redemption refuses until the feed is back inside. A signed quorum's leg (`SignedPriceOracle`) remains a
supported alternative, and so, since 19 October 2026, does Chainlink's BRL/USD (below).

**Chainlink BRL/USD, the alternative leg (verified 19 October 2026).** Chainlink's mainnet BRL/USD is live and a
contract can read it: proxy `0x3126E7F38D5f60f4E2B6ec3511C7bdbD79317Df1` (Chainlink's feed list), "BRL / USD", 8
decimals, heartbeat 86,400 s, deviation threshold 0.5%, aggregator `0x3A9763662BFCa861340d1D40bA5e5A2a29Bc5f3e`; last
round 18 October 2026 19:14 UTC, 0.1975293 US$ per real (R$ 5,0625 per dollar). This document said in September that
no Chainlink BRL/USD was usable on L1; that was the **retired** proxy `0x0eBDc65E7e9132Cb41ac5cbD0101B799D7aDb475`
(last updated 25 August 2023, `No access` to contracts), which the Feed Registry still returns. Sepolia has no
Chainlink BRL/USD feed.

`ChainlinkFxOracle` is the reserve's FX leg from it, the same `IBandPriceOracle` shape as `PythFxOracle`, deployed by
`DeployMovva` with `MOVVA_FX_SOURCE=chainlink` (Pyth stays the default):

- **Units.** `floor(10^14 / answer)`: reais per dollar at 1e-6, the reciprocal floored as `PythFxOracle` truncates.
  The error is under 0.2 ppm (0.002 bps).
- **Keyless.** The feed, decimals, max ages and an R$ 1-100 sanity range are immutables bounded at construction; no
  governor. The Chainlink proxy is already the indirection (aggregator upgrades happen behind it), and replacing a
  retired proxy is a new leg behind the reserve's own delayed `setOracle` - a governor in the leg would be a second
  lever on the same number. After finalize neither lever exists, exactly as for `PythFxOracle`.
- **Market hours.** Chainlink keeps posting at weekends (heartbeat rounds on Saturday 17 and Sunday 18 October 2026,
  the Saturday one carrying a +0.23% move from after Friday's last round), so the answer's age never says the market is closed. The leg's
  **rate refuses outside `FxMarketHours`' core session** (`MarketClosed`): without that, a 26 h max age would let the
  reserve mint and redeem all weekend at Friday's close and be gap-arbitraged at the reopening - the risk Mova's
  14 September rule exists to avoid. The **band** takes the last answer stamped current: up to `MAX_AGE` inside the
  session, `CLOSED_MAX_AGE` (four days) outside it - and it is stamped current inside the session too, because the
  escrows allow a band an hour and the feed may legitimately not post for a day.
- **Max age.** `MAX_AGE` 26 h (bounded 25 h to 2 days), and the reserve's `fxMaxAge` set to the same: an hour would
  refuse a healthy, quiet feed most of every day. The real heartbeat intervals are 86,424-86,436 s
  (`ChainlinkFxFork.t.sol` reads them back).

**The deviation threshold against the fees.** Pyth's price moves every few hundred milliseconds and Mova's keeper
posts it within the hour; Chainlink's answer moves only when the market has moved 0.5% from the last round, or on the
daily heartbeat. Inside the session, then, a Chainlink leg's rate can sit up to ~50 bps from the market (plus the time
a deviation round takes to land) - and the first `fx_parity` run, a Monday afternoon, found it on Sunday's heartbeat,
22 hours old, 1.46 bps from Pyth. A gateway that sees the market mints when the on-chain rate is rich and redeems when
it is poor:

| | per trade, at the threshold |
|---|---|
| on-chain lag before a deviation round | up to ~50 bps |
| reserve's fee, mint or redeem (deployment default) | 10 bps |
| gateway's gain, at the reserve's expense | up to ~40 bps |

A round trip through the reserve at one rate gains nothing (it pays both fees); the gain needs the market on the other
side, which only a contracted gateway has, and it is bounded per trade by the threshold and in size by the supply cap
and the hedge desk's attention. The mitigations, which are the client's to choose - the fees are not changed here:

- **fees at least the threshold**: 50 bps to mint and 50 to redeem (the hard caps are 100) close the one-way gain;
- **a second, independent source in the divergence breaker** with a band near the threshold (50-75 bps), so minting
  halts while Chainlink and Pyth disagree by more. The default band (300 bps) does not catch a 50 bps lag. The shipped
  `ChainlinkCrossSource` reads the same Chainlink feed and is no check on this leg (`DeployMovva` refuses that pair);
  what is independent of it is Pyth or a BRL-stablecoin TWAP, and no Pyth `IPriceSource` is built yet;
- **watching**: `scripts/fx-parity.ts` and the monitor's `fx_parity` warn past 50 bps.

With Pyth as the leg the comparable lag is the keeper's posting interval, and a gateway can post a fresher signed
update itself; the recorded residual there is choosing among recent signed updates (docs/audit-scope.md).

**Off-hours.** Pyth publishes FX.USD/BRL only on weekdays, 08:00-17:00 New York time, closed on 25
December and 1 January - about 73% of the week closed - while PIX never closes. Mova's rule (14 September
2026): everything that **moves value** - `mint`, `redeem`, `harvestYield` - prices at
the leg's rate and refuses once it is older than `fxMaxAge`, so it waits for the market to reopen.
Everything that is a **band** - Movva's price check on its escrow pair (`MovvaReserve.brlCentsPerUnit`,
`bandBrlPerUsdtE18`) and the USDT and ETH bands - takes the last close while the market is closed. So
users keep buying and selling Movva by PIX and boleto at night and at weekends, from Movva LPs already
hold; an LP that runs out stops quoting until the market reopens, and should inventory before the close.
The hours, the reasoning and the residual risks: `PythFxOracle`, `FxMarketHours`, and SR2-35 in
[security-review-phase2.md](security-review-phase2.md).

### The divergence breaker

Client decision (24 September 2026, "Breaker"): **self-clearing - it pauses automatically when prices diverge and
resumes when they return to band. No key needed. Several independent sources, including a TWAP, and the breaker
pauses if they diverge. If BRL liquidity is thin, the breaker pauses - it does not substitute the source.**

`DivergenceBreaker` is a small contract the reserve reads (`BREAKER`, an immutable; zero means none). It has no
owner, no setter and no role: every call recomputes the verdict from the sources' present answers, so there is
nothing to latch and nothing to lift. Its only state is one word of dead-source claims (below), which can only
relax the redemption verdict for a source that is dead, never cause a halt. The reserve passes it its own rate (Chainlink USDT/USD x
Pyth FX.USD/BRL) and the breaker compares that with N further `IPriceSource` readings; among the reserve's rate and
every source flagged `trips`, `max - min <= min x BAND_BPS / 10,000` must hold. A tripping source that reverts, is
stale, returns zero or is too thin counts as DISAGREEING - the breaker halts, it never drops the source and carries
on, because choosing the compared set would be the attacker's to influence.

Sources shipped: `ChainlinkCrossSource` (Chainlink USDT/USD over BRL/USD: shares no publisher with the Pyth leg),
`UniswapV3TwapSource` (the time-weighted tick of a USDT / BRL-stablecoin pool, e.g. BRZ, with a floor on in-range
liquidity; it reverts, so the breaker halts, while the pool's history is shorter than the window or liquidity is
under the floor), and a mock for tests. Anything implementing `IPriceSource` can be added at deploy.

**What it stops while tripped:** `mint`, `redeem` and `harvestYield`.
**What it does not stop:** `recapitalize` (adding backing never waits), the Movva token itself, the
ramps' band reading (`brlCentsPerUnit` is a sanity band, not a price), and the views.

**Redeem is halted too.** There is no pause for redemptions: no key can stop one after finalize ("Who can stop a
redemption", under "Governance"). The breaker is not a key: it has none and clears itself, and redeem pays `min(1, ratio)` of the
rate, so a wrong primary rate over-pays; the client asked for both to pause. Deploy option
`MOVVA_BREAKER_HALTS_REDEEM=false` keeps exits open while mint and hedge withdrawals still halt.

**Dead sources (SRM1-7).** A tripping source that dies for good - Chainlink deprecates BRL/USD, a pool migrates or
stays under its liquidity floor - would otherwise halt the breaker for ever, and with `HALTS_REDEEM` lock every USDT in
the reserve: `BREAKER` is immutable and nothing can repoint it. So a source DEAD for `DEAD_AFTER` (an immutable, 7 to
365 days, `MOVVA_BREAKER_DEAD_AFTER`, 30 days by default) stops counting for redemptions. Mint and hedge withdrawals
keep halting on it for good: they grow or move the backing on a degraded set of prices and are no holder's exit, so
such a reserve winds down to redemptions and a successor needs a new deployment.

- **Dead** means: `brlPerUsdtE18()`, given its full `SOURCE_GAS` (500,000), reverts - which every source does when
  its reading is stale beyond its own max age, too thin or out of range - or returns anything but 32 bytes of a
  non-zero rate.
- **For `DEAD_AFTER`** is established on-chain. Anyone may call `poke()`: a tripping source found dead with no open
  claim gets one dated now. Every poke, and every mint, redemption or hedge withdrawal that passes, withdraws the
  claim of each source it read answering. A redemption leaves a source out only if it is dead in that call AND its
  claim is at least `DEAD_AFTER` old; a source that answers is always compared, and a diverging source answers.
- **A live source cannot be made to look dead.** The attacker needs a claim nobody withdrew for `DEAD_AFTER`: they
  would have to keep the source dead in every block anyone reads it for 30 days, and a source kept dead that long is
  dead. A starved read never counts (`poke` refuses, and a redemption refuses to leave a source out, unless the read
  had all its gas). A reserve in use withdraws claims by itself; the monitor's `movva_breaker_claims` fails on any
  claim against a source that answers, and the runbook says to `poke()` it through a private relay.
- **The cost.** After `DEAD_AFTER` a redemption is priced by the reserve's own rate and the remaining sources, as if the
  dead one had never been configured; with every tripping source dead, by the reserve's rate alone, which is what
  `HALTS_REDEEM=false` gives from day one.

Deploy-time knobs (all immutable, `DeployMovva`): band (`MOVVA_BREAKER_BAND_BPS`, default 300), which sources, each
source's `trips` flag, the TWAP window and liquidity floor, whether redeem halts, and `DEAD_AFTER`. No source and no `MOVVA_BREAKER=off`
is refused: "no breaker" must be a decision.

**The cost: a denial-of-service lever.** Every tripping source is a switch for the halt. A thin-liquidity Uniswap
TWAP can be moved by anyone with capital for the window it averages over, and then mint and redeem stop for as long as
they pay to hold it there; the halt is also the moment holders most want to exit. This is what the client asked for and
what is built, but it should be a decision with open eyes:

- Cost to the attacker is roughly the liquidity moved times the window; it falls with a shorter window and a thinner
  pool, and the BRL stablecoin pools on Ethereum are thin. A longer window and a high floor raise it but slow the
  breaker's response to a real divergence by the same amount.
- Fewer false trips: a wide band (500+ bps), `trips=false` on the TWAP (it is then informational, visible to the
  monitor, and cannot halt anything), or a pool deep enough that the cost of moving it exceeds the benefit.
- **The alternative, median-of-three.** Strong feeds trip the halt; the TWAP only influences a median. The reserve would
  price at `median(Chainlink x Pyth, Chainlink x Chainlink BRL/USD, TWAP)` and the breaker would compare only the two
  strong feeds with each other: manipulating the TWAP alone can neither halt anything nor move the median past the
  middle value. It is NOT built, because it changes what rate the audited core prices at (the reserve would read the
  median instead of its own cross). What IS available with no code change and no privilege is the pieces: deploy the
  Chainlink cross as a tripping source and the TWAP as `trips=false`. That halts on a strong-feed divergence only; the
  TWAP then does nothing but inform the monitor (`sourceRates`). Say if the median should be built.

Monitor: `movva_breaker` (`warn` while tripped, with each source's rate), see the runbook.

### Timelocks above a daily limit

Client decision (24 September 2026, "Withdrawal limits"): **timelock above the daily limit, not multisig. A multisig is
an admin key. A timelock lets the user withdraw, just with a delay - no one approves on their behalf.**

The shape, everywhere it is used: within the daily limit a withdrawal is instant; above it, a request is ANNOUNCED
on-chain with its recipient and amount fixed, and after the delay ANYONE may execute it, once, for exactly that amount to
exactly that recipient. Nobody can cancel, approve, change or reorder a request - a cancel right is an admin key - and
there is no new privileged function. The delay and the limit are immutables, so there is no parameter a change could
front-run.

Where it applies:

1. **The reserve's hedge withdrawal: removed** (principal-locked reserve, client rule of 21 October 2026). The reserve
   no longer has `withdrawToHedge`, `queueHedgeWithdrawal` or `executeHedgeWithdrawal`: its USDT leaves only by redemption
   and, above the harvest floor, by `harvestYield` to the fixed `yieldRecipient`. Hedges run on Mova's own capital.
2. **`LimitedYieldVault`** (a `YieldVault` with a per-owner daily limit, `DAILY_LIMIT_BPS` of `totalAssets`, draining
   over 24 hours): `withdraw`/`redeem` are instant up to the owner's room, revert above it, and `requestRedeem` /
   `executeRedeem` is the slow lane after `WITHDRAW_DELAY`. The request escrows the owner's shares; execution burns
   exactly those shares and pays their value at execution (`previewRedeem`) to the recorded receiver. The owner cannot cancel
   their own request either. Deploy it instead of `YieldVault` where wanted; `DeployMovva` does not change the reserve's
   vault.

Open questions (not guessed, nothing built for them):

- **A gateway redeem above a daily amount.** `MovvaReserve.redeem` has no daily limit and is exactly what an exit looks
  like in a run. A limit with a timelock there is a different product (a per-gateway or global redemption gate) and needs
  a decision about whose limit it is. Not built.
- **Whether the reserve's own yield vault should be a `LimitedYieldVault`.** The reserve is one owner; its payouts out of
  the vault would hit the owner's daily limit, so a run would queue behind the delay. Left as `YieldVault` until decided.
- **The per-owner limit is per address.** Splitting shares across addresses gives many buckets. A global limit is a run
  brake rather than a user right. Which is wanted?
- **No cancel means a mistaken request is final.** For
  `LimitedYieldVault` a mistaken `requestRedeem` locks the owner's shares for the delay and then pays them to the receiver
  named. Say if an owner-only cancel is acceptable (it is a key, but the owner's own).

## Fees

Mova earns what the flow says it earns - the fee on transactions with node providers, and yield - through the
reserve's two fees and the reserve's own yield, which is entirely Mova's. The fees are set the way traditional finance
charges for the same services, and deploy as `DeployMovva`'s defaults:

| Fee | Default | Paid by | Traditional benchmark |
|---|---|---|---|
| Mint | 0.10% (10 bps) | the gateway, on USDT it turns into Movva | A fiat-backed stablecoin issuer's acquisition fee: Tether charges 0.1% per acquisition ([tether.to/en/fees](https://tether.to/en/fees), read 14 September 2026) |
| Redeem | 0.10% (10 bps) | the gateway, on Movva it burns for USDT | The same issuer's redemption fee: Tether charges the greater of US$ 1,000 or 0.1% per redemption. Movva has no fixed minimum: its gateways are contracted institutions, and the fee is a percentage only |

The third fee, 20% of each distribution of yield to sMovva savers, was removed with savings (client decision D1,
14 October 2026): there is no distribution, so the reserve's yield is Mova's in full.

Two things this choice does not do:

- **It is not charged to users directly.** A user buying or selling Movva pays the LP's price; the gateway's mint and
  redeem fees are part of the LP's cost, and LPs compete on it.
- **It is a starting point, not a contract term.** Each fee can be lowered at once and raised only through the
  governance delay, never past its hard cap (100 bps, 100 bps). A gateway's LP node refuses to mint or redeem at a
  fee above its own `maxFeeBps`, so a fee rise stops gateways until each agrees.

At 10 bps the mint and redeem fees also make small rate-lag arbitrage unprofitable: a gateway gains from redeeming at a
stale rate only when the rate lags the market by more than the fee (docs/security-review-movva.md, "The rate").

### Node-provider rewards

The flow's third incentive, "node provider rewards", is a share of the fees above, paid to the LPs who carry the flow in
proportion to the BRL volume they settle (`FeeSplitter`, `NodeRewards`; decided 14 September 2026, numbers to come).

- **Funding.** The reserve's fee recipient is a `FeeSplitter`. Anyone may call `split()`: `lpRewardShareBps` of the Movva it
  holds goes to `NodeRewards`, the rest to Mova's treasury (`MOVVA_FEE_RECIPIENT`). **The share is 0 at deployment**
  (`MOVVA_LP_REWARD_SHARE_BPS`), so every fee reaches the treasury as before until Mova chooses a number.
- **Counting.** `LPRegistry` reports every settlement it records, on every escrow it accepts - both Movva escrows included -
  through a rewards hook that cannot block a settlement. Only INSTITUTIONAL and AFFILIATED LPs earn.
- **Paying.** Weekly epochs. Once an epoch has ended and a three-day review has passed, anyone finalizes it: its budget is the
  smaller of what was funded during it (plus whatever earlier epochs could not pay) and **10 bps of its settled volume** - the
  mint fee, so a settled real never earns more than minting that real paid Mova. Each LP claims its pro-rata share, up to a
  per-LP cap; its LP node claims on its own. Nothing expires, and what an epoch cannot pay rolls forward.

| Setting | Default | Hard cap | Raising | Lowering |
|---|---|---|---|---|
| LPs' share of fees (`FeeSplitter.lpRewardShareBps`) | 0 | 5,000 bps | delayed | instant |
| Reward per real settled (`NodeRewards.rewardBpsOfVolume`) | 10 bps | 20 bps (mint + redeem fee) | delayed | instant |
| Most one LP is paid per epoch (`maxRewardPerLpPerEpoch`) | R$ 10.000,00 of Movva | - | delayed | instant |
| Smallest settlement counted (`minCountedCents`) | R$ 10,00 | - | instant | delayed |
| Epoch, review period | 7 days, 3 days | 1-28 days, 1-14 days | fixed at deployment | |

What it does not do: tell a self-trade from a trade. An eligible LP can take its own offer from another address and pay its own
PIX; the bounds above cap what that earns, the review period lets the governor void it and exclude the LP, and the contract with
the LP makes it a breach. SR2-36 in [security-review-phase2.md](security-review-phase2.md) states what remains.

## Contracts

| Contract | Role |
|---|---|
| `Movva` | ERC-20 + permit, 18 decimals. Mint and burn only by the reserve, fixed at deployment (the reserve deploys the token) |
| `MovvaReserve` | Implements `IMovvaReserve` and `IPriceOracle` (the band for Movva on the ramps). Holds USDT idle and in `YieldVault(USDT)` |
| `PythFxOracle` | The BRL/USD leg from Pyth's FX.USD/BRL, at 1e-6: the rate the reserve mints and redeems at, and a band reading that serves the last close while the FX market is closed. Behind `ScaledFxBandOracle` for the ramps' centavo bands |
| `DivergenceBreaker`, `ChainlinkCrossSource`, `UniswapV3TwapSource` | The keyless, self-clearing breaker the reserve reads and its two shipped price sources ("The divergence breaker") |
| `LimitedYieldVault` | `YieldVault` with a per-owner daily limit and an announce-then-anyone-executes timelock above it ("Timelocks above a daily limit") |
| `FeeSplitter` | The reserve's fee recipient. `split()`, open to anyone, sends `lpRewardShareBps` of the Movva it holds to `NodeRewards` and the rest to Mova's treasury. Share 0 at deployment and never above 50%; raising it or changing where either part goes waits out the delay |
| `NodeRewards` | Node-provider rewards (`contracts/ramp`): counts each INSTITUTIONAL or AFFILIATED LP's settled volume per weekly epoch through `LPRegistry`'s rewards hook, and after a review period pays each its pro-rata share of what the epoch was funded, at most 10 bps of the volume and a per-LP cap. Claim-based, no loop over LPs, nothing expires (see "Fees") |
| Movva Privacy Pool | On Mova's own Entrypoint (decided 14 September 2026). The sMovva pool and `SavingsMovva` were removed (D1) |
| Movva escrow pair | Its **own** `FiatEscrow` / `OffRampEscrow` pair (`DeployRamp` with `MOVVA_RESERVE`), sharing the LP registry, verifiers and arbitrator: `BAND_BPS` is immutable per escrow and 5% around R$ 1,00 is no peg. Movva listed with the reserve as its oracle, native ETH delisted, band 300 bps by default - offers at 97-103 centavos at par. Not 100: the mid is the ratio rounded to the nearest centavo, so at 98.56% backing a 100 bps band admits only 99, above what a redemption pays, and nobody would buy a holder's Movva back. At 300 an LP always has ~1.5% under the redemption value |

## Still to decide

| Item | Notes |
|---|---|
| Fee numbers | **Decided**: 0.10% / 0.10%, benchmarked to traditional finance ("Fees"); the 20% distribution fee went with savings (D1). Revisit with real volumes |
| Token symbol | `MOVVA` in the contracts until chosen |
| Freeze capability | A regulated issuer may be ordered to freeze funds. Movva has no freeze function; compliance today is gateway KYC, Mova's own ASP (which decides private withdrawals) and viewing keys. Needs legal counsel before mainnet |
| Parameters | Sized with the shock tool ("Sizing the buffer"); its margin and conversion inputs are placeholders until the broker confirms them |
| Hedge operations | Broker with B3 access, hedge policy (ratio band, rebalancing frequency), who signs statements |
| Authorization | Whether the issuer needs Banco Central authorization for a BRL-pegged token: a legal opinion before mainnet |
