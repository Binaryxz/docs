# M1 (Rev. 3 §13.1), item by item

> **Status, 18 October 2026** (against commit `5cfa0cc`; source: [deployments.md](deployments.md) unless named).
> The M1 rail is on Sepolia: the **MOVVA-only rail** was deployed on 15 October 2026 from commit `84e97d0` and verified
> live (247 pass, 3 expected, 0 fail; 176 functions classified, 0 unknown; source verified on Etherscan 20/20). The
> account stack has been live since 14 October. The client's whole flow - Tasks 1, 2 and 3 - ran live on the MOVVA-only
> rail on 15 October, and custody phases 1 and 2 moved the reserve's guardian, treasurer and hedge treasury to 2-of-3
> Safes (phase 2 executed 17 October). The rail is **not finalized**. "The comparison", "What is genuinely left for
> M1" and "What we need to proceed" below are current; "Why this document" and "Correcting one point precisely" are
> as written on 25 September and say what was true then.
>
> **Update, 6 October 2026.** The rail went on Sepolia from a fresh deployer `0xD249…73D1`, and its
> live verification showed 315 pass, 10 expected and 0 fail
> ([deployments.md](deployments.md#the-movva-rail-on-sepolia-6-october-2026)). It carried sMovva and the ETH/USDT pair,
> and is superseded by the MOVVA-only rail of 15 October.
>
> **Update, 12 October 2026.** Task 5 below is settled: the client removed shielded transfers (Rev. 3 §5.3, Option A)
> from scope. Users deposit and withdraw only - no transfers between users, between sub-wallets, or shielded internal
> transfers. `ShieldedTransferRouter` and the wallet's transfer path (`packages/viewing-key/src/transfer.ts`) were
> deleted, and the two rows below say so.
>
> **Update, 15 October 2026.** Client decision D1 (14 October 2026) removed savings from M1: sMovva (`SavingsMovva`),
> its shielded pool, the savings relayer (`@mova/zap-relayer`), the shielded yield router and the Movva distribution
> keeper were deleted, and `MovvaReserve` no longer distributes (no `distribute`, no distribution fee). M1 is: deposit PIX
> -> mint MOVVA -> hold as shielded notes -> withdraw to PIX; the reserve's yield is Mova's, not a user product. Where
> this document says "Movva and sMovva pools" it describes what was built and deployed before D1; the MOVVA-only rail has
> the Movva pool only. The 6 October rail still carries its sMovva contracts on Sepolia.

**Why this document** *(25 September 2026)*. The client reviewed the Sepolia deployment and reported that only the fork
and a plain ERC-20 are delivered. The deployment they looked at is the **Phase 1 stack of 8 September**, which predates
the Movva rail. The rail — token, reserve, Movva and sMovva pools, escrows, oracles, verifiers — had never been broadcast
to Sepolia, because the deployer held **0 ETH** and we had asked for funding in every report since 14 September. Our own
record said so in [deployments.md](deployments.md): *"Not on Sepolia yet."*

So the gap was mostly **deployment, not implementation**. Two M1 items were then genuinely not built: sub-wallets, and
Flux. Written 25 September 2026 against commit `70933d0`.

## The comparison

Updated 18 October 2026.

| M1 item (Rev. 3 §13.1) | Built? | Proven by | On Sepolia? |
|---|---|---|---|
| Privacy Pools fork and deployment | Yes | `protocol/` byte-identical to upstream `c312dcd58f`; `npm run verify` | **Yes**: the MOVVA-only rail deploys its own Entrypoint and Movva pool (15 October); the 8 September stack is abandoned and monitored |
| MOVVA token | Yes | `contracts/movva/Movva.sol`: no owner, no settable minter, no pause, no upgrade | **Yes** (15 October), Etherscan-verified; minted only by `MovvaReserve` |
| Balances held as shielded MOVVA notes | Yes | The escrow deposits into the Movva pool under the user's precommitment; the wallet's balance is a set of notes (`packages/wallet/src/movva/ledger.ts`); proven in `movva-wallet-live.ts` (105 checks in EOA mode, 15 October 2026, real groth16 proofs) | **Yes**: Task 1 minted 504.62 MOVVA and held it as a 504.12 MOVVA note; Task 3 withdrew 200 of it privately (15 October) |
| ERC-4337 smart accounts, passkey + MPC | Yes | Safe 2-of-2 and Kernel v3.1 with passkey plus server co-signer; FROST as the MPC option; `accounts-live.ts` 65 checks, `cosigner-live.ts` 113, ERC-7562 checked against Rundler | **Yes**: the account stack (14 October, commit `5290121`; 48 checks, 0 fail): the three Kernel modules and the `OwnerlessPaymaster`; Task 2 ran six sponsored ops from accounts holding 0 ETH. The passkey was a software P-256 key. `SponsorPaymaster` and `SponsorGate` are superseded and not deployed in it |
| Sub-wallets with independent seed phrases | **Yes** (commit `c6e5444`, 5 October 2026) | Own BIP-39 seed per sub-wallet; a leaked phrase opens no other sub-wallet ([wallet-custody.md](wallet-custody.md) §12; `packages/wallet/test/movva-subwallet.test.ts`) | Partly: Task 2 sponsored a sub-wallet Safe, on a script-held key rather than a phrase-derived one |
| Relayer infrastructure | Yes | Privacy Pools relayer for exits; Alto bundler and paymaster for UserOperations. (`@mova/zap-relayer`, the savings relayer, was removed with savings, D1, 14 October 2026) | Exercised, not deployed as a service: Task 3's withdrawal was relayed through `Entrypoint.relay` and Task 2's ops bundled by the deployer acting as relayer and bundler |
| …on Flux | **No** — 6 specs exist, nothing deployed | `packages/ops/flux/*.json` | n/a |
| Audit viewing key | Yes | `packages/viewing-key` (34 source files): scoped, time-boxed, revocable, read-only by derivation; an auditor reconstructs the statement from chain data in `movva-wallet-live.ts` steps 14-16 and `audit-demo.ts` | **Yes**: `AuditGrantRegistry` and `ShieldedNoteLog` in the account stack; in Task 2 the auditor rebuilt R$ 504,11 from a grant over the Task 1 note and chain data alone (15 October) |
| Shielded transfer decision (§5.3) | **Removed from scope** by the client on 12 October 2026 | `ShieldedTransferRouter` and the wallet's transfer path were deleted; users deposit and withdraw only | n/a |

## Correcting one point precisely

*(25 September 2026.)* "MOVVA token — but as a standard ERC-20, not as shielded notes." Rev. 3 §5.1 itself specifies
MOVVA as *"an immutable ERC-20 and the asset held in shielded notes"*. Both are true at once: the token is an ordinary
ERC-20 contract, and user balances live as notes inside the Movva pool. The app never shows a public MOVVA balance except
through the emergency exit that Rev. 3 §5.2 step 7 requires. What the client was looking at on Sepolia then was a pool
with no Movva pool beside it, because the rail had not been deployed. Since 15 October the Movva pool is on Sepolia and
holds the Task 1 note.

## What is genuinely left for M1

Updated 18 October 2026. Rows 1 to 6 are the 25 September list with their status; rows 7 to 10 are what has appeared
since.

| # | Task | Status | Depends on |
|---|---|---|---|
| 1 | ~~Deploy the rail to Sepolia~~ **Done 15 October 2026** | The MOVVA-only rail from commit `84e97d0`: 59 transactions, 247 pass / 3 expected / 0 fail, 176 functions classified, Etherscan 20/20. Not finalized (row 7) | none |
| 2 | ~~Deploy the account stack~~ **Done 14 October 2026** | Commit `5290121`: the three Kernel modules, the `OwnerlessPaymaster` (1 ETH stake locked for good, 0.1 ETH deposit), `AuditGrantRegistry`, `ShieldedNoteLog`; 48 pass, 0 fail. Its `forge verify-contract` commands are recorded but were not run, so these six are not Etherscan-verified | Running the recorded Etherscan commands (ours) |
| 3 | ~~Sub-wallets with independent BIP-39 seeds~~ **Built 5 October 2026** | Commit `c6e5444`; moves between sub-wallets stay V2. Left: recovery is the phrase alone, and the app cannot yet build the ownerless paymaster's data for any account (SRM1-17, open) | SRM1-17 is ours |
| 4 | **Flux deployment** of the six replicable services | **Not done.** Six specs in `packages/ops/flux/`, nothing deployed ([HANDOVER.md](HANDOVER.md): "Specs delivered, not deployed") | The client's Flux account and collateral |
| 5 | ~~Confirm §5.3~~ **Settled 12 October 2026** | The client removed shielded transfers from scope; the router and the wallet's transfer path were deleted | none |
| 6 | **The pending decisions** that gated a permanent deployment | **Decided:** what is renounced (Option A, [security-review-m1.md](security-review-m1.md) SRM1-2 and §8), the ASP shape (12 and 14 October 2026, built: `AspRootQuorum`, 2 of 3). **Open (no recorded decision):** who mints MOVVA (built as the reserve), fee governance. See [client-questions.md](client-questions.md) A1, A2, A4 | Client |
| 7 | **Finalize the rail** (`--finalize`) | Not run. It refuses while any permanent role is a test identity (SRM1-1): on Sepolia the zkTLS witnesses and bank endpoints, the arbitrator, the gateway and LP, the FeeSplitter treasury and the three ASPs are seed-derived or illustrative, and so are the signers of the custody Safes now holding the treasurer and hedge-treasury roles (a Safe whose threshold of owners are test keys counts as one) | Rows 8 and 9, real keys for each of those roles, and the client's sign-off |
| 8 | **Replace the escrow pair** with the EIP-1271 pair (`5cfa0cc`: SRM1-3, SRM1-4, SRM1-22, the suspended-LP lever) | Built and rehearsed on a fork (17 October); three steps with a 48 h wait (`scripts/redeploy-escrows.ts`). On the deployed pair the arbitrator Safe cannot rule, so the arbitrator stays one test key | The client's approval |
| 9 | **Custody** | Phases 1 and 2 done (phase 2 executed 17 October 2026): the reserve's guardian, treasurer and hedge treasury are 2-of-3 Safes, and the old test keys are refused. Planned, not rotated: the arbitrator (with row 8), the gateway to a KMS/HSM key, the zkTLS witnesses to Reclaim's set, the LPs to their own keys. The deployer stays governor until finalization | Row 8; a KMS key; a Reclaim credential and templates; independent ASP entities |
| 10 | *Beyond M1:* the hedge sleeve | Deployed 17 October 2026 at `a90c78f` against `SimHedgeVenue` (TEST ONLY), 19/19 checks, Etherscan 2/2; not funded. No venue is chosen ([delta-neutral.md](delta-neutral.md) §12.8) | The venue decision ([client-questions.md](client-questions.md) B8) |

## Upgrade or replace?

**Replace**, and it was done. The 8 September stack predates the rail, its `OWNER_ROLE` sits on a key the client has
confirmed is lost, and Rev. 3's immutability rule forbids upgrading anything anyway — a parameter change is a new
deployment. The rail deploys a fresh Privacy Pools stack of its own, and the old addresses are documented as abandoned
and monitored (`deployments/abandoned-sepolia-2026-09-08.json`, `orphan_watch`), which is what the client's own
proposal 6 asked for.

## What we need to proceed

Updated 18 October 2026. The three items of 25 September first, then what the remaining rows need.

1. ~~Sepolia ETH~~ **Provided.** Every deployment since 6 October was funded ([client-questions.md](client-questions.md)
   C1 lists the deployers).
2. An RPC without the `eth_getLogs` cap. **Not provided, no longer blocking:** the privilege inventory reads logs in
   windows a free plan accepts, and it ran against real Sepolia for the MOVVA-only rail.
3. ~~A Pyth Hermes credential~~ **Provided and in use:** Task 1 posted Hermes' FX.USD/BRL to Sepolia on 14 and
   15 October. The price goes stale between posts, because no keeper service runs on Sepolia.
4. **Approval to replace the escrow pair** (row 8), so the 2-of-3 arbitrator Safe can rule.
5. **A Reclaim application credential and a provider template per bank**, without which no real PIX or boleto can
   settle and the ramp cannot be finalized (SRM1-1).
6. **KMS keys**: the gateway's (custody plan), the co-signer's and its sponsor operator's; and a VAPID key for recovery
   alerts.
7. **Two independent ASP entities** besides Movva, for a new `AspRootQuorum` before `--finalize`.
8. **The Flux account and collateral**, for row 4.
9. **The open decisions**: who mints MOVVA (A1), fee governance, the breaker's redemption rule for mainnet (SRM1-7), and
   the hedge venue (B8). See [client-questions.md](client-questions.md).
