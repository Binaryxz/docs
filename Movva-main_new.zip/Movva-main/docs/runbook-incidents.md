# Runbook — what each alert means and what to do

Keyed to the monitor's check ids, so the alert text and this document use the same names.
Every entry says what the user experiences, because that decides how fast you move.

**First, always:** an alert means the monitor could read the chain and did not like what it
saw. An `unknown` alert means the opposite — it could not read at all. Do not treat the two
the same.

## `oracle_freshness`

**What broke.** The BRL/USD rate behind the escrow bands is stale. On Mova's deployment that rate is
Pyth's FX.USD/BRL, posted to Ethereum by Mova's Pyth keeper (`packages/yield`) and read through
`PythFxOracle`. Point the monitor's `ORACLE` at the centavo adapter the bands read (`fx leg (BRL/USD)`
in the deploy log), not at the `PythFxOracle` under it, whose rate refuses every night by design.

**First, which session.** Pyth publishes FX.USD/BRL only on weekdays, 08:00-17:00 New York time, and not
on 25 December or 1 January. The oracle's core session is 13:30-21:00 UTC on those weekdays
(`FxMarketHours`; `cast call <PythFxOracle> "inCoreSession()(bool)"` answers for the current block).

- **Inside the core session**, a stale price means the keeper is not posting, or Pyth is not
  publishing. The bands refuse it too: new offers, orders and sales stop, and the Movva reserve refuses
  mint and redeem (`movva_rate`). This is an incident.
- **Outside it**, a stale rate is the market closed, and is expected. Bands read the last close, stamped
  current, for up to `closedMaxAge` (four days by default), so the ramps keep trading; only the reserve's
  rate refuses, by design (see "Off-hours" below). But a keeper that died before the close looks exactly
  like a closure until the next core session opens, and at 13:30 UTC the bands start refusing the old
  price. On a closed day, check the keeper's own health rather than finding out then.

**What users see.** Inside the core session, nothing at first; once the age passes the oracle's own
`maxAge` (an hour), new offers and new orders stop being accepted. Outside it, nothing, until the last
close is older than `closedMaxAge`. In-flight orders settle or refund normally either way.

| Level | Meaning | Do |
|---|---|---|
| warn | 30+ minutes old, inside the core session | Check the keeper is running, funded for gas and Pyth's update fee, and reaching Hermes. There is still time. |
| fail | 2+ hours old, or the oracle refuses (`StaleRate`), inside the core session | The bands have stopped. Restart the keeper, or post an update by hand from any funded key: posting is permissionless and needs no governance (`runbook-mainnet-deploy.md`, "Rehearse on a fork"). |
| fail, outside the core session | The last close is older than `closedMaxAge`, so the bands refuse too | The keeper never posted the close. Post the latest update now: Hermes serves the last close while the market is shut. |
| unknown | The oracle could not be read | Check the RPC endpoint first — the monitor and the escrow read the same chain. |

**The keeper's own checks.** Two more checks watch the keeper rather than the price, so a closed day is not
a blind one:

| Check | Level | Meaning | Do |
|---|---|---|---|
| `pyth_keeper_gas:<addr>` (addresses from `PYTH_KEEPERS`) | warn | A replica's ETH is below `PYTH_KEEPER_MIN_WEI`: it will soon be unable to pay gas and Pyth's update fee | Top it up. Another replica posts meanwhile - out of turn once the price is two thirds of `maxAge` old - so this is not yet an incident. |
| `oracle_settings:<oracle>` | warn | `PythFxOracle`'s feed or limits changed, or `closedMaxAge` is 0 (bands stop off-hours) | Confirm the change was the one scheduled (`ChangeScheduled` / `ChangeExecuted`). A `closedMaxAge` of 0 stays a warning for as long as it is set, deliberately. |

The keeper's `/status` says why it is not posting: `fresh`, `closed` (Hermes' market hours, or the chain's core
session without them), `hermes-behind` (the market is open and Hermes has nothing newer - a Pyth or Hermes problem,
not the keeper's) or `from-future`. One gap the monitor shares with the contract: about an hour a day the market is
open but outside the core session, and a keeper that dies then is reported only when the next core session starts.

**A signed leg.** A deployment on `SignedPriceOracle` (`FX_SOURCE=signed`) has no market hours: a
stale price means the publishers stopped. *Adding* a publisher, or lowering the threshold, waits out
`GOVERNANCE_DELAY` (48 hours) — keep spares registered (N ≥ M + 2) rather than planning to add one
mid-incident. Removing a publisher is instant but never lowers the threshold, so removing below it
freezes the price until a scheduled lower threshold executes.

Escrowed funds are never at risk from this: the escrow uses the oracle as a *band*, never as the
price. A trade's price is what the LP posted and the taker accepted. The Movva reserve is different -
it mints and redeems *at* the rate - which is why the feed, its limits and a signed leg's publishers
can only change through the delay (SR2-30).

**A dead feed.** Repointing a feed or a leg (`setFeeds`, `setLegs`, `PythFxOracle.setFeed`) is delayed:
the band stays closed until the scheduled repoint executes. Schedule it the day a feed deprecation is
announced, not the day the feed stops.

## Off-hours: `movva_rate`, gateways holding

Mova's rule (14 September 2026) is that trading continues on the last close and value creation waits for
the market (SR2-35, SRM-15). Outside the core session these are the rule working, not incidents:

- **`movva_rate` and `movva_collateral_ratio` refusing on a stale FX leg.** The reserve prices mint,
  redeem, `harvestYield`, its ratio and its previews at the rate, which refuses once
  older than `fxMaxAge`. `runbook-movva-hedge.md` has what the desk does meanwhile.
- **Gateways holding.** No gateway can mint or redeem: `mova_lp_gateway_blocked{op="mint"}` names a
  stale rate, Movva offers run down over a weekend, and Movva bought back waits to be redeemed. A gateway
  sells what it holds and stops quoting when it runs out. Tell gateways to hold inventory before the
  close; do nothing else.

(There is no distribution to wait for: savings and `distribute` were removed by client decision D1, 14 October 2026.)

The same readings **inside** the core session are incidents: start at `oracle_freshness`.

## `asp_root_age`

**What broke.** The ASP postman has stopped publishing association-set roots.

**What users see.** Deposits made since the last root cannot be withdrawn *privately*. The
exit is ragequit, which is public — the thing users came here to avoid — and, because the
depositor is the user's 2-of-2 Safe, **ragequit needs the server co-signer**. The money is not
stuck while the co-signer is up. If the co-signer is down at the same time, affected users have
no exit at all until one of the two returns (see `docs/availability.md`).

**Do.** Restart the postman. Check the co-signer is healthy before anything else, because it
is now the only exit. If the postman cannot be restarted, say so publicly and quickly: a user
choosing between waiting and exiting publicly deserves to know which they are choosing.

`fail` with "no ASP root has ever been posted" on a fresh deployment means the postman was
never started. Start it before the first deposit.

## `relayer_gas` / `paymaster_deposit`

**What broke.** A service that pays gas on users' behalf is running out.

**What users see.** For the relayer: withdrawals must be self-submitted, which means the
recipient pays gas and appears on-chain as the sender — a privacy regression, not a fund
risk. For the paymaster: new users who hold no ETH cannot transact at all.

**Do.** Top it up. These are the two alerts worth automating a response to, because the fix
is always the same and the consequence of waiting is a worse product, not a broken one.

## `paymaster_global_cap`

**What broke.** An `OwnerlessPaymaster`'s EntryPoint deposit is under `PAYMASTER_GLOBAL_CAP_WINDOWS` (default 3) ×
its `MAX_COST_GLOBAL` (warn), or under one `MAX_COST_GLOBAL` (fail). Its global cap is the only bound on how fast the
deposit drains, and in any one window's length of time it can pay up to 3 × the cap (fixed-window alignment and the
grace period each add one). Below that, Sybil accounts from the public factories can reserve the whole deposit before
the cap stops them (SRM1-16). A paymaster without `MAX_COST_GLOBAL` (SponsorPaymaster) always reports ok here.

**What users see.** Nothing yet. Once the deposit is reserved or spent, every sponsored operation fails `AA31` until
someone tops it up, and new users who hold no ETH cannot transact.

**Do.** Top it up by the amount in the alert, from any funded key: `EntryPoint.depositTo(paymaster)` with that value
(`cast send 0x0000000071727De22E5E9d8BAf0edAc6f37da032 'depositTo(address)' <paymaster> --value <wei> ...`), or the
paymaster's own `deposit()`. Anyone may; nothing can take it back out. `npx tsx scripts/deploy-account-stack.ts
--verify <record>` prints the same amount. The cap itself is immutable: a lower one means a new paymaster.

## `paymaster_stake`

**What broke.** `SponsorPaymaster` is not staked at the EntryPoint as bundlers require: never staked, staked
under `PAYMASTER_MIN_STAKE_WEI` (default 1 ETH) or on an unstake delay under 86400 s, or unlocked with
`unlockStake`. The paymaster reads its own storage and returns a context during validation, which ERC-7562
allows only a staked paymaster, so every bundler enforcing it refuses every sponsored operation. Rundler's
refusal reads `entity stake/unstake delay too low` (docs/runbook-mainnet-deploy.md, 3c).

**What users see.** The same as an empty deposit: users who hold no ETH cannot transact at all. The deposit
can look healthy while this fails.

**Do.** Stake it from the paymaster's owner, the governor when SponsorGate owns it:
`admin -- paymaster:add-stake <paymaster-or-gate> 86400 <wei>`, at least the highest floor among the bundlers the
wallet uses. If the stake was unlocked and nobody on your side unlocked it, treat the owner key as compromised:
re-staking restores service, but the key can unlock again. If the floor itself is wrong for your bundlers, set
`PAYMASTER_MIN_STAKE_WEI` to theirs rather than silencing the check.

## Gasless onboarding: `sponsor_gate_budget` / `sponsor_operator_gas:<address>`

The co-signer's sponsorship module sponsors new accounts through `SponsorGate`, which owns `SponsorPaymaster`
(docs/wallet-custody.md §11.1). The gate lets operator keys add a budgeted number of accounts per day, and nothing
else; the governor (a multisig) keeps every paymaster power.

**Setting it up.** Do this once per paymaster. Every command below is a dry run until `--execute`, and a multisig
takes the printed calldata.

1. `admin -- sponsor-gate:deploy <paymaster> <governor> <guardian> <accounts-per-day-cap>`. Keep the cap above every
   co-signer's `COSIGNER_SPONSOR_DAILY_CAP`: a co-signer whose cap is not below the gate's refuses to start.
2. `admin -- paymaster:budget <paymaster> 86400 <perAccountWei>` and `admin -- paymaster:max-cost <paymaster> <wei>`,
   if they are not set. The gate refuses operators while either is zero.
3. `admin -- paymaster:transfer-ownership <paymaster> <gate>`, sent by the current owner. From now on, the
   `paymaster:` commands take the gate's address.
4. `admin -- sponsor-gate:operator <gate> <operator> true`, sent by the governor. Each co-signer prints its operator's
   address at startup (`sponsorship: operator 0x...`).
5. Configure each co-signer:
   - `COSIGNER_SPONSOR_GATE`;
   - `COSIGNER_SPONSOR_KMS_MODULE`, for a key that is not the co-signer's;
   - `COSIGNER_SPONSOR_DAILY_CAP`.

   Fund the operator. Give the monitor `SPONSOR_GATE` and `SPONSOR_OPERATORS`.

**`sponsor_gate_budget` fail: operators have spent the window.** New users' enrolments are refused sponsorship
(`gate_budget_exhausted`), so their first operation cannot be paid for until the window closes. The detail says when.

1. Compare the gate's `Sponsored` events with each co-signer's audit log (`"t":"sponsor"` records).
2. **Every account explained:** this is real demand. Raise the budget with `sponsor-gate:budget`, and each co-signer's
   cap with it.
3. **Accounts no audit log explains:** an operator key has leaked.
   - Revoke it at once: `sponsor-gate:operator <gate> <key> false`, from the guardian or the governor.
   - Take back the unexplained accounts: `paymaster:sponsor-batch <gate> <accounts> false`.
   - Add a new key (`sponsor-gate:operator <gate> <new> true`), point that co-signer's `COSIGNER_SPONSOR_KMS_MODULE`
     at it, and restart the co-signer.

The leaked key could not withdraw, change a budget or move the paymaster, and each account it added could spend at
most the per-account gas budget.

**`sponsor_gate_budget` warn.**

- **Past the warn share:** watch it.
- **Budget 0:** someone pulled the brake. Raise it once the incident is closed.
- **The paymaster is not owned by the gate:** operators can do nothing, and the owner holds every paymaster power.
  If nobody meant to move it, treat it as a governance compromise.

**`sponsor_operator_gas:<address>`.**

- **Below the floor:** fund the key. Below the co-signer's `COSIGNER_SPONSOR_MIN_BALANCE_WEI`, enrolments are refused
  sponsorship (`operator_unfunded`).
- **No longer an operator:** if nobody on call revoked it, find out who did. If the revocation was deliberate, remove
  the address from `SPONSOR_OPERATORS`.

**Recovery alerts** (docs/wallet-custody.md §11.2) have no monitor check of their own. Watch the co-signer's `/metrics`:

- `mova_cosigner_push_total{result="failed"}` rising means push services refuse its messages. Check the VAPID key and
  `COSIGNER_ALERTS_SUBJECT`.
- `mova_cosigner_recovery_watch_block` must follow the chain head.
- `mova_cosigner_recovery_pending` counts accounts with a queued recovery: each is a user who should be vetoing.

## `vault_drawdown`

**What broke.** The yield vault's share price has fallen relative to its high-water mark.

| Level | Meaning | Do |
|---|---|---|
| warn | Down 250+ bps | Look at which adapter moved. A depeg shows here first, because the Lido adapter marks to the lower of redemption and market price. |
| fail | Deposits are PAUSED | The breaker tripped on its own. Deposits have stopped; withdrawals have not. |

**After a trip.** Understand the loss before resuming. `admin vault:resume` re-bases the
high-water mark, which means the breaker will not trip again on the same dip — that is the
point, and also why resuming without understanding the cause disables your own alarm.

To exit a source under stress without waiting: `admin vault:deallocate <vault> <adapter>
<assets>` pulls funds back into the vault. Funds can only move *to* the vault, never out to
an arbitrary address, so this is safe to do quickly. It is a guardian (or keeper) call, so
`--execute` reads `GUARDIAN_KEY`; the governor key cannot send it.

## `vault_liquidity`

**What broke.** Less than 10% of vault assets can be withdrawn immediately.

**What users see.** Large withdrawals fail up front with `InsufficientLiquidity` rather than
partially filling.

**Do.** Deallocate from a strategy. For the Lido adapter, remember the two exit paths differ:
Curve is instant but costs slippage, and the withdrawal queue takes days. The vault's
`maxWithdraw` already reports only what can leave now, so users see the limit before they hit
it.

## `pool_reachable`

**What broke.** The pool answered, but its tree is empty.

On a live deployment this means you are pointed at the wrong address. On a fresh one it is
expected until the first deposit.

## `governance_change:<contract>:<id>`

Needs `WATCH_FROM_BLOCK` (see `packages/ops/src/watch.ts`). One alert per scheduled change.

**What happened.** Someone with the governor role scheduled a risk-raising change - a new
arbitrator, verifier, attestor, witness or bank endpoint, a lower threshold, a new asset or
yield adapter, a higher tier, credit or cap, a new keeper, opening a network phase, or on a price
oracle a new publisher, a lower threshold, a repointed feed, a longer max age or closed max age, or a
wider confidence bound. The watcher finds the
oracles itself from the escrows, the cross and the Movva reserve, and says which band or reserve the
oracle feeds. It cannot execute before the time in the alert.

**What users see.** Nothing yet. That is the point: the delay is their time to leave if they do
not accept the change.

| Level | Meaning | Do |
|---|---|---|
| warn | A change is pending | Confirm it with whoever holds the governor role. The alert names the function selector; `cast 4byte <selector>` names the function. If nobody intended it, the governor key is compromised: `gov:cancel` the change, rotate the role, and tell LPs and vault holders. |
| ok (resolved) | Executed, cancelled, or expired unexecuted | Nothing. |

## `posted_ruling:<escrow>:<order>`

Needs `WATCH_FROM_BLOCK`. One alert per ruling posted and not yet executed.

**What happened.** A signed arbitration ruling was posted. Anyone can post one; it executes
one day later, and revoking its arbitrator before then voids it.

**What users see.** The disputed order or sale moves when the ruling executes.

| Level | Meaning | Do |
|---|---|---|
| warn | A ruling is waiting out its day | Confirm the desk issued it. |
| fail | The desk says it never signed this ruling | The arbitrator key is stolen and in use. Revoke it now, before the time in the alert: `admin escrow:arbitrator <escrow> <arbitrator> false` on BOTH escrows (revocation is immediate). Then register a new desk key, which waits out the governance delay. |
| ok (resolved) | The ruling executed or the dispute timed out | Nothing. |

A dispute nobody rules on refunds to origin after its timeout - `DISPUTE_TIMEOUT`, or on the on-ramp for a dispute
its TAKER raised the shorter `TAKER_DISPUTE_TIMEOUT` (5 days by default; `disputeDeadline(id)` on the escrow gives
either) - and it does not alert, because
nothing is at risk - but a desk that lets disputes time out is a desk not working its queue.

## Node-provider rewards: `node_rewards_balance`, `node_rewards_unclaimed`, `node_rewards_wiring`

Needs `NODE_REWARDS` (and `FEE_SPLITTER` for the wiring check). `FeeSplitter` receives the reserve's fees and sends
`lpRewardShareBps` of them to `NodeRewards`; LPs earn per weekly epoch in proportion to the BRL volume they settle, after
a three-day review, within the caps in SR2-36 (`docs/security-review-phase2.md`).

**What users see.** Nothing: rewards are between Mova and its LPs. A holder's Movva is never touched.

| Check | Level | Meaning | Do |
|---|---|---|---|
| `node_rewards_balance` | fail | `NodeRewards` holds less of its token than it has booked, so claims will revert | Only a claim moves tokens out of it. Look at the reward token itself - a transfer fee switched on, a freeze, a rebase. Lower `lpRewardShareBps` to 0 (`admin splitter:share`, instant) so nothing more flows in until it is understood. |
| `node_rewards_unclaimed` | warn | An epoch was not finalized long after its review ended, or rewards are owed and no LP has claimed for weeks | Finalizing is open to anyone: `admin rewards:finalize <epoch>`. If LPs are not claiming, their nodes are down or have `rewards.claim` off - tell them. Nothing expires, so this is a notice, not a loss. |
| `node_rewards_wiring` | warn | No registry is bound while there is something to share, or the splitter funds another contract or splits another token | Bind the registry (`admin rewards:registry`, delayed once the pool has been funded) and confirm the splitter's `rewards` and `TOKEN` against `docs/deployments.md`. A splitter pointing elsewhere that nobody scheduled is a governor incident: start at `governance_change`. |

**Volume that looks farmed.** The monitor does not judge whether volume is genuine. An LP settling many orders with one
taker, or with takers funded from its own addresses, is SR2-36's residual risk: inside the epoch's review period, void
that LP's volume with `admin rewards:void` (instant; the voided share rolls forward rather than going to other LPs), and
use `admin rewards:exclude` to stop it earning.

## `orphan_watch` (the abandoned Sepolia stacks)

Two records are watched, each under its own check id (`ORPHANS_FILE` takes both, comma-separated):

- `orphan_watch`: the 8 September 2026 stack, whose owner key is **lost** (below).
- `orphan_watch:2026-09-21`: the superseded 21 September 2026 partial deployment
  (`deployments/abandoned-sepolia-2026-09-21.json`). Its key is held, and its roles were **renounced** with
  `scripts/renounce-sepolia-2026-09-21.sh`. Here the invariant is inverted: it fails while the former owner
  `0x4C0A...d214` still holds `OWNER_ROLE` or `ASP_POSTMAN`, while the PythFxOracle's governor is anything but
  `0x...dEaD`, on any role event or log from its contracts, and on that key signing anything. Before the
  renunciation has run it is failing by design; after it, any failure means someone regained a role that should
  not exist, so treat it as a compromise of that key: move what the key holds and investigate.

The 8 September stack:

The 8 September 2026 Sepolia stack is abandoned and its owner key `0x941fb8cf...d23d659` is lost
(`deployments/abandoned-sepolia-2026-09-08.json` is the record and the monitor's config). Nothing
legitimate happens there, so this check has no warning level: it is `ok` or it is an incident. It fails
on any new log from any of the eight contracts, on a role event (`RoleGranted`, `RoleRevoked`,
`OwnershipTransferred`, `OwnerChanged`), on the lost owner's nonce rising on Sepolia, and on `OWNER_ROLE`
or the paymaster's ownership no longer being the lost key's. It stays failed until the record is updated:
an incident does not clear itself. The monitor needs `ORPHANS_FILE` and `ORPHANS_RPC_URL` (an RPC on
Sepolia, not the chain the rest of it reads), and `ORPHANS_BASELINE_BLOCK` once an operator has pinned
what counts as history.

The user experiences nothing: these contracts carry no live money or users. The risk is a third party
using an old address (a stale doc, a copied env file) and the lost key's powers: `OWNER_ROLE` on the
Entrypoint also authorises proxy upgrades, `withdrawFees`, `removePool` and `windDownPool`; the paymaster
owner can withdraw its deposit. The repo test `packages/ops/test/orphans.test.ts` fails CI when anything
current names those addresses.

**If the key resurfaces (the holder tells you, or the check shows the key moving): renounce on the spot.**
Do it from the key itself, before anything else, in this order, with `$RPC` a Sepolia RPC, `$KEY` the
resurfaced key, `$OWNER` its address:

```
ENTRYPOINT=<Entrypoint proxy from the record>   PAYMASTER=<SponsorPaymaster from the record>
OWNER_ROLE=$(cast keccak "OWNER_ROLE")

# 1. OWNER_ROLE on the Entrypoint. It administers itself, so after this nobody can grant it again:
#    the proxy can never be upgraded, fees never withdrawn, ASP_POSTMAN never rotated. That is the point.
cast send $ENTRYPOINT "renounceRole(bytes32,address)" $OWNER_ROLE $OWNER --rpc-url $RPC --private-key $KEY

# 2. The paymaster's gas deposit back to the key, then the paymaster to a burn address (it refuses
#    the zero address, so there is no renounce; 0xdEaD has no key).
cast send $PAYMASTER "withdrawTo(address,uint256)" $OWNER <deposit wei> --rpc-url $RPC --private-key $KEY
cast send $PAYMASTER "transferOwnership(address)" 0x000000000000000000000000000000000000dEaD --rpc-url $RPC --private-key $KEY

# 3. Check, then update the record and the runbook's baseline.
cast call $ENTRYPOINT "hasRole(bytes32,address)(bool)" $OWNER_ROLE $OWNER --rpc-url $RPC   # false
cast call $PAYMASTER  "owner()(address)" --rpc-url $RPC                                    # 0x...dEaD
```

The check will fail on each of those transactions, which is correct: they are the incident being closed.
The Entrypoint goes first because it is the larger power (it authorises upgrades of the proxy); the paymaster only holds a gas deposit. If the key was TAKEN rather than found, there is nothing to renounce from: the
thief holds the powers. On Sepolia that is a nuisance, not a loss; say so in the incident record, and make
sure no environment or document still points users at the stack. Run `admin` privilege inventory afterwards
(`scripts/privilege-inventory.ts`) and note the result in `docs/deployments.md`.

## `movva_breaker` / `movva_hedge_queue`

`movva_breaker` is `warn` while the reserve's self-clearing divergence breaker is tripped: the Chainlink x
Pyth rate and at least one independent source (Chainlink BRL/USD cross, Uniswap v3 TWAP) are further apart
than the band the reserve was deployed with, or a tripping source reverted, is stale or is too thin. **Mint,
redeem and hedge withdrawals revert** until they agree again; recapitalisation and the ramps' band
are not affected. Nobody can lift it, and nothing needs to: it clears on the first read after the sources
agree. The detail lists each source's rate (0 = reverted).

**Do:** read the rates. If the TWAP is the outlier and its pool is thin, treat it as a possible attack
(a denial-of-service on mint and redeem; docs/movva.md, "The divergence breaker"): there is no key to override
it, so the answer is the deploy-time one (a wider band, a deeper pool or a non-tripping TWAP in the next
deployment). If a strong feed is stale, fix the keeper (`oracle_freshness`, `movva_rate`). A halt that lasts
hours while the real market is calm is a source problem, never a reserve problem.

`movva_breaker_claims` reads the breaker's dead-source claims (SRM1-7; breakers built from this code on). A
claim is opened by anyone's `poke()` that finds a tripping source dead, and withdrawn by the first poke, mint,
redemption or hedge withdrawal that reads the source answering. Once a claim is `DEAD_AFTER` old (30 days by
default), redemptions leave that source out whenever it fails; mint and hedge withdrawals never do.

- **`fail`: a claim against a source that answers.** Someone knocked the source out at least once and opened
  a claim. Withdraw it now: call `poke()` on the breaker from any account (it needs no role), sent through a
  private relay so a thin TWAP cannot be pushed out of range around it. One successful poke is enough.
- **`warn`: a claim against a source that is dead.** The fix working as designed. Find out why the source died
  (a deprecated Chainlink feed, a migrated or drained pool). After `DEAD_AFTER` redemptions price without it;
  minting and hedge withdrawals stay halted on that reserve for good, so plan a new reserve (its breaker is
  immutable) and say so to gateways.

`movva_hedge_queue` is `warn` while a hedge withdrawal above the daily limit is waiting. It is the timelock
doing its job: the treasurer announced it, **nobody can cancel it**, and anyone may execute it after
`HEDGE_QUEUE_DELAY` (`admin movva:execute-hedge-withdrawal <reserve> <id>`). It still has to clear the
withdraw floor and the breaker at execution. Use the delay to look at the reserve's ratio and the hedge
statement; holders who do not like it have that long to redeem.

## `fx_parity` (Chainlink BRL/USD against Pyth FX.USD/BRL)

On while the reserve's FX leg is being considered for, or has moved to, Chainlink (`FX_PARITY=true`; one-shot:
`npx tsx scripts/fx-parity.ts`). It reads Chainlink BRL/USD on mainnet and Pyth's FX.USD/BRL on Hermes, both as reais
per dollar, and reports the divergence in bps and each age. Nothing halts on it.

- **`warn`, divergence over 50 bps inside the session**: more than Chainlink's 0.5% deviation threshold explains. Look
  for a deviation round that has not landed (Chainlink's age), or a Pyth publisher problem (Hermes' confidence). With a
  ChainlinkFxOracle leg this is the window a gateway could mint or redeem at the reserve's expense
  (`docs/movva.md`, "The rate"): consider pausing mint (the guardian may) until they agree.
- **`fail`, over 300 bps**: one of them is wrong by more than the breaker's default band. Pause mint; find which.
- **`warn`, Chainlink older than 26 h**: the feed missed its heartbeat; a ChainlinkFxOracle leg already refuses
  (`StaleAnswer`). **Hermes stale while it says the market is open**: Pyth's side, and the Pyth keeper's too.
- **Market closed** (in the detail): both are last closes, Chainlink's re-posted by its weekend heartbeat; a divergence
  then is two closes and nothing mints on either.

## `reserve_coverage` (MOVVA's live coverage, and the top-up commitment)

On with `RESERVE_COVERAGE=true` beside `MOVVA_RESERVE`. It reads the reserve and, when a sleeve is named
(`RESERVE_COVERAGE_RECORD` or `RESERVE_COVERAGE_SUBWALLET`), the hedge path, all at one block. Every figure it
reports is also on `/coverage` (the publishable JSON) and on `/metrics`. One-shot:
`hedge-sleeve coverage --record <sleeve record> [--json]` (docs/delta-neutral.md §12.9).

- **`warn`, below the top-up point** (`RESERVE_COVERAGE_TOPUP_BPS`, by default 103%): this is Movva's commitment coming due. The detail names the USDT that brings
  the reserve back to the top-up point. Top up now with `recapitalize` (`movva-desk recap-plan`, or bring Mova's own hedge
  capital home: `hedge-sleeve sleeve:withdraw` then `reserve:recapitalize`; it then becomes principal). Do not wait for 100%: below it, redemptions pay
  pro-rata.
- **`fail`, below 100% on-chain**: under-backed. A redemption pays its pro-rata share, and minting is refused. Treat it
  like `movva_collateral_ratio` at `fail`: recapitalize the amount the detail names ("Movva owes ...") from the hedge
  path and Movva's own capital, and tell gateways. The combined figure says whether bringing the hedge path home is
  enough, but only USDT in the reserve counts.
- **`STALE` in the detail**: the reserve refuses to price itself, so the figures are at the last posted rate. Outside FX
  hours this is expected. Inside the core session it means the Pyth keeper is down; see `movva_rate`. When the last
  posting is more than four days old (`RESERVE_COVERAGE_STALE_WARN_SECONDS`), the check warns on its own.
- **`ok` with "under the target"**: between the top-up point and the 108% target. `movva_collateral_ratio` warns here.
  Restore the buffer at the next recapitalization; no top-up is due.

## Any check reporting `unknown`

The monitor could not read. It waits five minutes before alerting, so a single `unknown`
alert means the endpoint has been unreadable for at least that long.

**Do, in order:** check the RPC endpoint; check the address is right; check the monitor
itself is running. Note that `unknown` is *not* `ok` — nothing has been verified while this
is firing, so treat a long `unknown` on a critical check as though it were a `fail` until you
can read the chain.

The detail shows the RPC error with every URL cut to scheme and host
(`https://eth-mainnet.g.alchemy.com/[redacted]`). That is deliberate: `/status` is public and
the alert goes to a chat channel, and the path of a hosted RPC URL is its API key. Compare the
host with the configured `RPC_URL`; the full value is only in the deployment's secrets. If a
key ever does appear in an alert, `/status` or a log, treat it as disclosed and rotate it.

## Incidents that produce no alert at all

Worth knowing, because the monitor cannot see them:

- **A compromised key.** Nothing on-chain looks wrong until it is used. This is what the
  role rotation in `scripts/rotate-sepolia.sh` is for; the equivalent exists for mainnet only
  if the roles are on a multisig.
- **An LP not paying.** This is the escrow's dispute path, not a monitoring concern. Timeout
  refunds are permissionless, for undisputed orders and — after `DISPUTE_TIMEOUT` — for
  disputed ones too.
- **The arbitration desk down.** Nothing is frozen for longer than the escrow's
  `DISPUTE_TIMEOUT` (30 days by default; `DISPUTE_TIMEOUT()` on each escrow) - and an on-ramp
  dispute raised by its taker no longer than `TAKER_DISPUTE_TIMEOUT` (5 days by default; read
  `disputeDeadline(id)`). A taker can dispute only inside the order's pay window, and an LP an
  off-ramp claim only before its `payBy` (H-04). Until then a
  dispute moves only on a ruling signed by a registered arbitrator; after it, anyone calls
  `admin escrow:expire-dispute <escrow> <id>` and the escrowed amount returns to its origin — the
  LP's offer on the on-ramp, the seller's refund address on the off-ramp. A desk that is down for
  most of that time is costing whichever side actually paid, so still restore it fast: its
  `/health` is on the desk itself (self-hosted, never on Flux); cases live in `CASE_STORE`, so
  restore that file with the service or every open case, deadline and evidence commitment is
  lost. The desk will not sign within three days of a dispute's deadline, because a ruling then
  cannot post and execute in time.
- **Submitting a ruling.** Nobody needs the governor. `GET /cases/:id/submission` (operator
  token), then any funded key — normally the party the ruling favours — runs
  `admin escrow:resolve <escrow> <submission.json> --execute` **twice**: the first posts it
  (`RulingPosted`), the second, at least `executableAfter` seconds (one day) later and before
  `expiresAt`, executes it. Resubmitting early reverts with `RulingNotReady`; it does not restart
  the clock. The command reads `SUBMITTER_KEY`, never the governor's.
- **A stolen arbitrator key.** The one incident on this list with a one-day clock. With
  submission open to anyone, the thief does not need the governor: it locks orders as a taker
  (or claims sales as an LP), disputes them, signs `RELEASE` and posts. Posted rulings wait a day
  before they can execute, so the signal is a `RulingPosted` the desk never signed —
  `ArbitrationDesk.postedRulingsNotSigned` compares them with the case store. The monitor watches
  this when ARBITRATION_DESK_URL is set, with WATCH_FROM_BLOCK and the escrows:
  - **A forged ruling:** `posted_ruling:<escrow>:<order>` turns from warn to **fail** for a ruling
    posted under the desk's arbitrator that the desk never completed. That covers a missing case, a
    draft its Safe owners had not approved, and another evidence root or direction.
  - **An unreachable desk:** `desk_crosscheck` goes unknown, and the rulings stay at warn.

  It reads only the desk's public routes. **Do,
  immediately:** revoke the key on both escrows, which is instant and voids every posted,
  unexecuted ruling it signed —
  `admin escrow:arbitrator <escrow> <arbitrator> false --execute`. Then schedule a replacement
  (adding an arbitrator waits out the governance delay). The replacement can only REFUND
  disputes raised before it existed, and anything it does not reach refunds on the timeout, so
  keep a second arbitrator key registered in advance if takers who really paid should still be
  able to win.
- **With the arbitrator Safe instead of a key (SRM1-22).** The desk holds no key
  (`ARBITRATOR_SAFE`). A ruling drafted on `/rule` executes only once two of the three owners
  approve it, each in their own wallet, over the Safe message hash `GET /cases/:id` shows.
  - **A compromised desk** can only draft rulings the owners decline to approve.
  - **One stolen owner key** rules nothing on its own. Rotate it on the Safe (`swapOwner`,
    signed by the other two), then restart the desk so it re-reads the owners.
  - **Two stolen owner keys** are the stolen-arbitrator case above. Revoke the Safe on both
    escrows at once.

  `postedRulingsNotSigned` compares `RulingPosted` events naming the Safe with the case store, as
  it does for a key.
- **The matcher out of sync.** Its `/health` answers 503 with the sync error (URLs redacted),
  and Flux pulls the instance out of rotation. No funds are involved; takers can still lock
  orders directly against the escrow.
- **A bank reversing a PIX payment.** Rev. 2 §6.4 puts this on the LP's posted collateral.
  No on-chain mechanism observes it.
- **A card chargeback.** The card partner's loss, by contract: the order released when the charge was
  captured, and nothing on-chain can take the crypto back. A pattern of chargebacks from one partner is
  a fraud-screening failure to raise with them; suspend the partner (`SUSPENDED`, instant) and its card
  offers take no new orders at once, while locked ones still settle.
- **A boleto paid after its order ended.** An LP issues a boleto for an on-ramp order; the taker
  cancels, or the order expires, and pays it anyway. The LP has the BRL and the crypto is back in
  its offer. Nothing on-chain can see this; the LP's procedure is to cancel ("baixar") every
  issued boleto whose order did not release, as soon as it ends (see
  `runbook-lp-onboarding.md`), and to refund at the bank any that was paid regardless.
- **A zkTLS proof refused with `RailNotAllowedForEndpoint`.** A bank receipt template was used
  for a rail it is not allowlisted for — most often a boleto receipt proven against a template
  that has only ever been allowed for PIX. Widening is `admin zktls:endpoint-rails` through
  `gov:schedule`/`gov:execute`, after checking the template captures the paid barcode and
  amount from the bank-written receipt. Orders stranded meanwhile have the dispute path.
- **An offer or sale refused with `BankRailNeedsZkTls`.** Someone tried to open a PIX, boleto or
  TED offer, or a sale, naming the attestor quorum (or any verifier whose `provesBankSession()` is
  false). The escrow refuses before anything is escrowed, so nothing is at risk; it means an LP node,
  a wallet or a script is still configured for the quorum on a bank rail. Point it at the zkTLS
  verifier (SR2-34). There is nothing to change on-chain, and nothing should be: the quorum's answer
  is a constant, and card offers keep it.
- **An LP whose bank has no zkTLS path.** Without a Reclaim credential and an allowlisted template
  for the LP's bank, its PIX and boleto orders cannot settle. Nothing is lost: unpaid on-ramp orders
  return to the LP's offer after `payBy` through the permissionless `reclaimExpired`, and a stale
  off-ramp claim is cleared by `releaseStaleClaim`. BRL that moved meanwhile goes through disputes.
