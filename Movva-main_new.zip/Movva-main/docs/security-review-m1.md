# Internal security review — M1 (deposit PIX, mint MOVVA, hold shielded, withdraw to PIX)

Reviewer: internal. Date: 14 October 2026. Commit reviewed: `9a554ed` (branch `phase-1-shielded-rail`), with no change to
any contract or production code. Scope: M1 as the client defined it on 14 October 2026 (below).

> **Update, 15 October 2026: savings removed.** After this review, the savings path was deleted from the code, per
> client decision D1 (14 October 2026): `SavingsMovva` (sMovva) and its pool, `ShieldedYieldRouter`, `@mova/zap-relayer`
> and the Movva distribution keeper are gone, and `MovvaReserve` no longer has `distribute`, `previewDistribute`,
> `savings`/`setSavings`, the distribution fee (`distributionFeeBps`, `MAX_DISTRIBUTION_FEE_BPS`),
> `maxDistributionBpsPerDay` or `lastDistributionAt`; `setFees` and `setLimits` take two arguments. Movva is minted
> only by `mint`; the surplus above `targetCollateralRatioBps` stays in the reserve as backing. `MovvaReserve`'s runtime
> went from 22,907 to 20,969 bytes. **SRM1-19 is fixed (removed).** These statements below are now historical and
> describe the commit reviewed, not the current code: the "Dormant code in the reserve" and "What still runs" bullets
> in section 2 (the reserve's savings path), "Only `mint` and `distribute` mint" in section 5, SRM1-11's "with
> `distribute` dead" (SRM1-11 stays **open**: the treasurer can still lower backing to 103%; `distribute` simply no
> longer exists, so nothing but the issuer's own `recapitalize` rebuilds the buffer), the line numbers cited in
> `MovvaReserve.sol`, and the tool results of section 7 (the invariant suite lost
> `invariant_DistributeNeverMintsAtOrBelowTarget`, and `...MintRedeemAndDistribute` became
> `invariant_SupplyMovesOnlyThroughMintAndRedeem`). The findings text is otherwise as written.

**This is not an external audit and does not substitute for one.** It was written by the party that built the code. It
follows the method of the earlier reviews (`docs/security-review-phase1.md` to `-phase4.md` and
`docs/security-review-movva.md`). Each claim a docblock or document makes was read at the site and, where it was in
doubt, turned into a test that tries to break it. The independent audit follows before mainnet. Section 11 says where
we would point it.

## Contents

1. Summary
2. Scope and method
3. Upstream Privacy Pools: what we verified
4. System overview and trust model
5. Threat model per component
6. Findings
7. Tooling results
8. Residual risks the client has accepted
9. Sepolia stand-ins and what mainnet needs instead
10. What this review did not cover
11. Focus areas for the independent auditor
12. Reproducing this review

---

## 1. Summary

**No critical finding.** No path was found that mints MOVVA below full backing, redeems above `min(1, ratio)`, moves
reserve USDT anywhere but a redeeming gateway's recipient or the fixed hedge treasury, pays an escrowed order or sale
twice, or withdraws the ownerless paymaster's deposit or stake. The prior fixes SRM-1 to SRM-17 and SR2-1 to SR2-36 that
touch M1 still hold.

The findings are about what full renunciation makes permanent, and about who wins a dispute nobody decides:

- **The test identities would become permanent (SRM1-1, high if it happened; fixed in tooling).** `--finalize` refused
  a single-key postman but checked none of the other keys that remain by necessity: witnesses, arbitrator, LP and
  endpoints. On the rail as configured, all of them derive from one seed. It now refuses while any of them is a test
  identity, unless a rehearsal opts out loudly (never on chain id 1).
- **A stolen arbitrator key can drain the on-ramp book, and nobody can revoke it after renunciation (SRM1-2, high,
  accepted).** This is the largest residual risk of Option A. It is documented, but the documents understate it.
- **A dispute pre-empts a valid payment proof (SRM1-3, medium).** With the desk absent, the side that escrowed
  keeps both legs.
- **A taker who escrows nothing can freeze an LP's liquidity and credit, and so stall exits (SRM1-4, medium).**
- **The paymaster puts no bound on the gas price, and the wallet signs a fixed 1 gwei tip (SRM1-5, medium, known).**
  On Sepolia this drains the deposit about 1,000 times faster than gas needs. *Fixed in the wallet after the review:*
  it signs the market's tip, capped; the paymaster itself is unchanged.
- **The change note's encrypted record is not appended (SRM1-6, medium for audit completeness, known).** Until the
  wallet does it, a disclosure is incomplete. *Fixed in the wallet after the review:* a deferred, randomised append,
  and an auditor status that says "pending append" rather than "missing".
- **A dead breaker source would lock the reserve for good (SRM1-7, medium).** This applies only where a breaker is
  deployed: not on Sepolia, but on by default for mainnet. *Fixed in the contracts after the review:* a source dead
  for `DEAD_AFTER` (30 days by default) stops counting for redemptions; mint and hedge withdrawals stay halted.
- **The client-approved Safe multisig cannot be the arbitrator (SRM1-22, medium).** The escrows
  verify rulings with `ecrecover` only (`RulingLib.sol:130-137`), and they are not upgradeable. The custody rehearsal
  (`26d345d`) proved it: the Safe's EIP-1271 approval is rejected as `MalformedSignature`. *Fixed in the contracts
  after the review:* rulings from a contract arbitrator are verified through EIP-1271, and a new pair with the Safe as
  its only arbitrator replaces the deployed one (`scripts/redeploy-escrows.ts`).

There are also nine lows and six informational items. One of them, SRM1-23, records that `--finalize` sends the guardian
to `0x…dEaD` while the custody plan first rotates it to a Safe.

**What exists on Sepolia, and what does not.**
- **Live:** the Task 1–3 demonstrations, which ran on the 6 October rail. That rail is not finalized: the deployer
  holds every governor, OWNER_ROLE and ASP_POSTMAN, and sMovva and the ETH/USDT pair are deployed. The account stack
  of 14 October is also live, including the ownerless paymaster.
- **Rehearsed on a fork only:** the M1 end state, meaning the MOVVA-only rail with its `AspRootQuorum` and `--finalize`
  (`docs/deployments.md`, "The MOVVA-only rail").

Everything said here about the finalized state is therefore said of code and fork rehearsals, not of a live finalized
deployment.

| Severity | Count | IDs |
|---|---:|---|
| Critical | 0 | |
| High | 2 | SRM1-1 (fixed in tooling), SRM1-2 (accepted) |
| Medium | 6 | SRM1-3, -4, -5, -6, -7, SRM1-22 |
| Low | 9 | SRM1-8 to SRM1-16 (SRM1-8, -9, -10 fixed in tooling; SRM1-16 fixed in tooling, Sepolia deposit top-up pending) |
| Informational | 6 | SRM1-17 to SRM1-21, SRM1-23 (SRM1-19 fixed by removal, 15 October 2026; SRM1-17 fixed in the wallet, the app and the co-signer) |

**Tools, run fresh for this review (section 7):**

| Tool | Scope | Result |
|---|---|---|
| Foundry v0.3.0 (pinned), invariants | 6 suites, 27 invariant functions | 46/46 tests pass |
| Foundry, full suite (`--no-match-contract Invariant`) | 83 suites incl. the 17 ReviewM1 demonstrations | 861/861 pass; 91 fork tests pass vacuously (no RPC) |
| Slither 0.11.6, per file | 15 in-scope files + 4 smart-account modules | 0 high / 0 medium; with suppressions shown, 5 high + 25 medium, all false positives |
| Mythril 0.24.8 (`scripts/mythril.sh`, both modes, 1 job) | the 14 in-scope contracts | 43 findings, 0 not allowlisted, 0 analyses failed |
| Circomspect 0.9.0 | upstream circuits | 3 warnings, all allowlisted |
| Upstream provenance and circuits | `protocol/` vs `c312dcd58f` | byte-identical; 11/11 artifacts; 3/3 R1CS reproduce; audited unit suite 110/110 |

---

## 2. Scope and method

### In scope (ours)

| Component | Files | Lines |
|---|---|---:|
| Issuer | `contracts/movva/{Movva,MovvaReserve,ScaledFxBandOracle,FeeSplitter,IMovvaReserve}.sol` | 1,399 |
| Breaker (not deployed on the M1 Sepolia rail; on by default for mainnet, see SRM1-7) | `contracts/movva/DivergenceBreaker.sol`, `IPriceSource.sol`, `sources/*` | ~330 |
| FX leg | `contracts/ramp/PythFxOracle.sol`, `IBandPriceOracle.sol` (BandRead), `contracts/common/FxMarketHours.sol` | 293 |
| PIX ramp, Movva pair | `contracts/ramp/{FiatEscrow,OffRampEscrow,LPRegistry,ReclaimZkTlsVerifier,NodeRewards,RulingLib,SafeTransferLib}.sol` | 3,874 |
| Shared base | `contracts/common/{DelayedGovernance,IssuerFreeze,ShieldedDepositLabel}.sol` | 308 |
| ASP registry | `contracts/AspRootQuorum.sol` | 126 |
| Gas sponsor | `contracts/OwnerlessPaymaster.sol` | 448 |
| Viewing key, on-chain half | `contracts/AuditGrantRegistry.sol`, `contracts/ShieldedNoteLog.sol` | 352 |
| Kernel modules | `packages/smart-account/contracts/src/{PasskeyCoSignerValidator,FrostValidator,KernelAvatarAdapter,UserOpChallenge}.sol` (+ `contracts/SchnorrVerifier.sol`, used by FrostValidator) | 556 + 230 |
| Deploy and finalize safety logic | `scripts/deploy-movva-rail.ts` (`stepFinalize`, the `asp` step, the verification and broadcast guards), `scripts/privilege-inventory.ts`, `contracts/script/{DeployMovva,DeployRamp}.s.sol` | ~2,700 + scripts |

**Read only to understand how our code integrates:** the upstream Privacy Pools Entrypoint, PrivacyPool and State in
`protocol/contracts/src/contracts/`. Section 3 covers them.

**Off-chain code was read only where an on-chain finding depends on it:**
- the wallet executors' fee setting (`packages/wallet/src/executor.ts`, `kernel-executor.ts`);
- the withdrawal path (`packages/wallet/src/movva/withdrawal.ts`, read only, because another session has it
  uncommitted);
- the auditor's anchor check (`packages/viewing-key/src/audit.ts`);
- the Task 1–3 scripts.

### Out of scope, and how their presence still touches M1

Removed from M1 by the client, but still in the repo until a later removal (as reviewed; the savings part has since been
removed from the code - see the update at the top):

- **sMovva (`SavingsMovva.sol`) and the reserve's savings path.** On the MOVVA-only rail `DeployMovva` runs with
  `MOVVA_SAVINGS=off`, so `savings` is never set.
  - **Dormant code in the reserve:** `distribute` reverts `NoSavings` before reading any oracle
    (`MovvaReserve.sol:664`). `setSavings` (`:823-828`) is a delayable governor change, unreachable once the governor
    is `0x…dEaD`. `savings` is read nowhere else.
  - **What still runs:** `previewDistribute` (`:463-466`) still computes a positive amount that `distribute` would
    refuse (SRM1-19). `distributionFeeBps` and `targetCollateralRatioBps` survive only in views and in the
    ratio-ordering rule (`:747`).
  - **The effect that matters:** with `distribute` dead, nothing brings the reserve back to the 108% target. All
    backing above the 103% withdraw floor stays within the treasurer's reach through the hedge path (SRM1-11).
- **The ETH/USDT ramp pair.** `DeployRamp` runs with `MAIN_PAIR=off`: no ETH/USDT escrows, no ETH or USDT band oracle.
  - **What remains on the Movva pair:**
    - its native-ETH code paths, delisted during setup (`DeployRamp.s.sol:907-908`);
    - the unused immutable `ORACLE`, which is set to the reserve;
    - `FiatEscrow.receive()` (`FiatEscrow.sol:1246`), which accepts ETH from anyone. On the Movva pair that ETH is
      stranded for good, because the Movva pool is ERC-20 and no ragequit pays ETH there.
  - Re-listing ETH would be a delayed `setAsset`, impossible after finalization.
  - **Upstream's ETH pool** is still deployed and registered by the unedited upstream script. Two consequences:
    - after OWNER_ROLE is renounced it can never be wound down;
    - the Entrypoint's `latestRoot` is global, so the ASP quorum's roots govern that pool too.
- **Not reviewed at all:** yield (`contracts/yield/*`), Hyperliquid, `SponsorPaymaster`/`SponsorGate` (superseded by
  the ownerless paymaster on this stack), `ChainlinkBrlOracle`, `ChainlinkSignedFxOracle`, `SignedPriceOracle`, and the
  card-attestor quorum (no card rail on M1).
- **Off-chain services:** reviewed only where noted above. That covers the LP node, co-signer, relayer, arbitration
  desk, apps, `packages/mpc` and `packages/viewing-key` beyond `audit.ts`.

### Method

- **Line-by-line reading in four parallel passes:**
  1. issuer and oracle;
  2. ramp;
  3. account layer, quorum and viewing-key contracts;
  4. deploy and finalize tooling plus the upstream integration.
- **Every finding below was re-read at its site** by the author of this document before inclusion.
- **Reproductions:** where a property was in doubt, a test was written against the real contracts in the M1
  configuration. That means the Movva pair as `_wireMovva` builds it (the reserve as the escrows' oracle, native ETH
  delisted, one arbitrator, one institutional LP), with every governor sent to `0x…dEaD`.
  - The tests are new files only: `contracts/test/ReviewM1_{Movva,Ramp,Accounts}.t.sol`.
  - Each asserts the behaviour it documents, so they PASS on the current code. They are demonstrations, not
    regression tests for a fix.
- **Tools, run fresh:** Slither, Mythril, the invariant suites, the full Foundry suite, Circomspect, and the upstream
  provenance and circuit checks (section 7).

---

## 3. Upstream Privacy Pools: what we verified

`protocol/` is upstream's audited Privacy Pools at `c312dcd58f6ad085204be61923c49f8065e4e9ae` (`protocol/FORK.md`),
with its Oxorio and Auditware reports in `protocol/audit/`. It is not re-audited here.

**Provenance, checked fresh on 14 October.** `npm run verify` is `scripts/verify-protocol.sh`. Its full run writes to
the shared build directories (`forge-out`, `protocol/contracts/out`) and runs `npm test` on shared anvil ports, and
another session was using both. So its checks were run individually instead, with the same commands and private
output directories:

| Check (verify-protocol.sh section) | Result |
|---|---|
| 1. FORK.md records the pinned commit | yes |
| 2. `diff -rq -x test` of upstream `packages/contracts/src` vs `protocol/contracts/src` (fresh clone at the pin) | **byte-identical** (18 files) |
| 2. same for `packages/circuits/circuits` vs `protocol/circuits/circuits` | **byte-identical** (3 files) |
| 2. zk artifacts (`*.zkey`, `*vkey*.json`, `*.wasm`, `*.r1cs` under build and trusted-setup) | **11 checked, 0 mismatched**; the 3 absent are the dev-setup `groth16_pkey.zkey` whose removal FORK.md records |
| 2. LICENSE | identical |
| `git status protocol/` | clean: the working tree is what is committed |
| 4. Audited unit suite, pinned Foundry v0.3.0, `--fuzz-seed 1` | **110 passed, 0 failed** (28 suites) |
| 5. Integration suite (forks mainnet, Sepolia, Gnosis) | **not run**: no `ETHEREUM_MAINNET_RPC` here |
| 6. Circuits recompiled with the pinned circom 2.2.2 (`protocol/circuits/scripts/verify-artifacts.mjs`, builds into a temp dir) | **all three MATCH**: commitment `3c93dfa4…`, withdraw `c6eb70eb…`, merkleTree `13d02166…` |
| 7. Upstream circuit mocha suite, relayer vitest suite | not run (shared ports and time) |

**Two places the script's diff does not reach:**
- `protocol/contracts/script/`, which the rail's `protocol` step runs. Diffed by hand, it differs from upstream only by
  the removal of the Gnosis/GnosisChiado contracts that FORK.md records. Adding `script/` to the automated diff is
  recommended.
- `protocol/relayer`. It differs from upstream only in `package.json` (name, description, the lint scripts removed) and
  in one `tsconfig.json` path.

The dependency pins (OpenZeppelin 5.1.0 / upgradeable 5.0.2, poseidon-solidity 0.0.5, lean-imt.sol 2.0.0) match
upstream's.

### How our contracts depend on upstream, read at the site

- **A private withdrawal needs exactly the latest ASP root.** `withdraw` and `relay` require it
  (`PrivacyPool.sol:59`), with no window. The state root may be any of the last 64 (`State.sol:35, :164-172`). The
  proof's context binds the withdrawal data, including the relay fee's recipient and bps (`PrivacyPool.sol:48-50`).
  `relayFeeBPS ≤ maxRelayFeeBPS` (`Entrypoint.sol:157`), and the cap is fixed once OWNER_ROLE is gone.
- **Ragequit needs no ASP root**, but only the original depositor may call it: `depositors[label] == msg.sender`
  (`PrivacyPool.sol:132-150`). On M1 the user deposits from their own account (Task 1), so the user can ragequit. A
  note the escrow delivered shielded has the escrow as its depositor of record, and its exit is
  `FiatEscrow.rescueShielded` (`FiatEscrow.sol:972-989`, keyed by (pool, label), SR2-1/2 and SR3-2). A change note keeps
  its label, so ragequit covers it too.
- **ASP_POSTMAN can never be changed once OWNER_ROLE is gone.** OWNER_ROLE is the admin of every role
  (`Entrypoint.sol:80-82`) and the only role that can upgrade the Entrypoint (`:308`). After renunciation nobody can
  grant or revoke a role, upgrade, register or wind down a pool (`:220, :256`), or withdraw vetting fees (`:264`; they
  stay in the Entrypoint).
  - `updateRoot` accepts any root, an old one included (`Entrypoint.sol:93-104`). A quorum can therefore roll the
    root back, but a single ASP cannot.

---

## 4. System overview and trust model

### The M1 flow, as demonstrated on Sepolia (6 October rail, 14 October runs)

1. **Deposit PIX, receive MOVVA.** An institutional LP posts a MOVVA offer on the Movva `FiatEscrow`. The taker locks
   an order and pays by PIX. A zkTLS proof of the bank session (`ReclaimZkTlsVerifier`, 2-of-3 witnesses) releases the
   MOVVA, directly or shielded into the Movva pool.
   - The LP got that MOVVA by minting at the `MovvaReserve` as a gateway: USDT in, MOVVA out at Chainlink USDT/USD ×
     Pyth FX.USD/BRL, refused below 100% backing.
   - In Task 1 the gateway minted straight to the test user, and the user shielded the MOVVA into the pool themselves.
2. **Hold it shielded.** The note sits in the Movva Privacy Pool. The wallet appends an encrypted note record to
   `ShieldedNoteLog`, and grants a viewing key through `AuditGrantRegistry`.
3. **Withdraw to PIX.** A Groth16 withdrawal against the latest ASP root, relayed through `Entrypoint.relay`, pays a
   fresh Safe. The Safe is sponsored by `OwnerlessPaymaster` and opens a sale on the Movva `OffRampEscrow`. The LP
   claims it, pays PIX, settles with a pix-sent zkTLS receipt and receives the MOVVA. The LP then redeems the MOVVA at
   the reserve for USDT.

### Who holds what

Notation: "deployer" is `0xD249…73D1` on Sepolia. `<seed>/role/i` is a test key derived from `MOVVA_TEST_KEY_SEED`
(`scripts/deploy-movva-rail.ts:262-275`, `docs/deployments.md`, "Substitutions (rehearsal only)").

| Power | Before `--finalize` | After `--finalize` (Option A) |
|---|---|---|
| Entrypoint OWNER_ROLE (upgrade, pools, roles, fees) | deployer | **nobody** (renounced, `deploy-movva-rail.ts:951`) |
| Entrypoint ASP_POSTMAN (post the root every private withdrawal needs) | on the 6 Oct rail: deployer. On the MOVVA-only rail: `AspRootQuorum` alone, from the `asp` step | `AspRootQuorum`, 2-of-3 fixed ASPs (`<seed>/asp/0..2`); no owner, no setter, can never be replaced |
| Governor of the 8 DelayedGovernance contracts (reserve, FX leg, FeeSplitter, NodeRewards, LPRegistry, verifier, both escrows) | deployer | **`0x…dEaD`** |
| Reserve guardian (`pauseMint`) | `<seed>/guardian/0` | **`0x…dEaD`**; nobody can pause minting (`MovvaReserve.sol:831-835`) |
| Gateway (mint, redeem) | `<seed>/lp/0` | the same, fixed for ever; no gateway can be added or removed |
| Treasurer (`withdrawToHedge`, `queueHedgeWithdrawal`) | `<seed>/treasurer/0` | the same, can never be revoked (SRM1-11) |
| Hedge treasury (where hedge withdrawals go) | `<seed>/hedge-treasury/0` | the same, fixed |
| Fee recipient | the `FeeSplitter` → `<seed>/treasury/0` (LP share 0) | the same, fixed |
| Arbitrator, per escrow | `<seed>/arbitrator/0`, one key, on the 15 October pair (rulings ECDSA-only there). On the EIP-1271 pair: the 2-of-3 arbitrator Safe alone (SRM1-22) | the same, can never be revoked or joined by a second (SRM1-2) |
| zkTLS witnesses, threshold, bank endpoints | `<seed>/witness/0..2`, 2-of-3, the illustrative templates | the same, fixed: no witness, endpoint or verifier can be added or revoked |
| LPs and credit | `<seed>/lp/0`, institutional, R$ 50,000 | the same, fixed: no admission, suspension, raise or Phase B |
| `OwnerlessPaymaster` | no owner from construction; 1 ETH stake locked for good, 0.1 ETH deposit | the same |
| `AuditGrantRegistry`, `ShieldedNoteLog` | no admin | no admin |
| Kernel modules | no admin; each account configures its own | the same |

**What remains by necessity, and the worst each can do after renunciation:**

- **ASP quorum.**
  - Two colluding ASPs decide which deposits may withdraw privately: censoring, admitting tainted deposits, or rolling
    the root back.
  - Lose two of the three keys and the last posted root stays the latest for ever. Deposits already in it keep
    withdrawing privately; later ones have only ragequit.
- **Arbitrator.** A stolen key can drain the on-ramp book (SRM1-2). A lost key leaves every dispute to the 30-day
  timeout, which returns the funds to the side that escrowed them (SRM1-3).
- **Witnesses.** Two colluding witnesses can sign a session that never happened. That is bounded per order by the
  offer, and per LP by its credit, but there is no limit across time.
- **Gateway.**
  - It mints only at the oracle rate while backing is ≥ 100%, and redeems at `min(par, pro rata)`.
  - Its worst outcome is rate-lag arbitrage, plus choosing which signed Pyth update to post (SRM-15).
  - If every gateway key is lost, nobody can redeem MOVVA for USDT again.
- **Treasurer.**
  - It moves reserve USDT to the fixed hedge treasury, never below 103% backing at the current rate: 8% a day
    instantly, and more through the queue after `HEDGE_QUEUE_DELAY` (1 day).
  - A compromised treasurer and hedge treasury can take the buffer from ~108% down to 103%.
- **LPs.** An LP holds its own offers' MOVVA. It cannot take the user's MOVVA except through a sale it settles with a
  receipt.
- **Off-chain, permissionless:** the relayer and the bundler (the deployer on Sepolia), and the Pyth poster. None holds
  an on-chain role.

**External trust that renunciation does not remove:**
- Pyth and Wormhole (the FX rate);
- the owner of the Chainlink USDT/USD proxy;
- Tether (it can freeze the reserve, a gateway or the hedge treasury);
- the canonical EntryPoint v0.7, Safe 1.4.1, Kernel v3.1 and the WebAuthn verifier;
- Reclaim, once real witnesses are used.

---

## 5. Threat model per component

Each entry: what it holds, who can hurt it, what we checked, and what held.

### 5.1 MovvaReserve and Movva

- **Holds:** all USDT backing; it is the only minter of MOVVA.
- **Attackers:** a gateway; the treasurer; an oracle that is wrong inside its bounds; Tether; anyone, via
  permissionless entry points (`recapitalize`, `executeHedgeWithdrawal`).

**Held:**
- **Minting.**
  - Only `mint` and `distribute` mint (`Movva.sol:44-58`); `distribute` is dead on M1. *(Since the savings removal only
    `mint` exists.)*
  - Mint is refused below the 100% floor (`MovvaReserve.sol:494-495`).
  - Mint prices from the USDT the reserve booked, capped at `usdtIn` (`:504-507`). Its fee is part of the backed gross
    (`:883-886`).
- **Redemption.**
  - Pays `min(atPar, proRata)`, both floored, with the fee rounded up (`:893-901`). The MOVVA is burned before USDT
    moves (`:541-545`).
  - Burn only touches the reserve's own balance; there is no `burnFrom`.
- **Where USDT can go:** only `_pay` (redeem recipient or hedge treasury) and the vault deposit; no vault exists on M1
  (`:944-981`).
- **Hedge path.** Hedge withdrawals keep the ratio ≥ the floor both projected and after paying (`:570-580`). Queued
  ones pay exactly once, to the recipient recorded at queue time, with the floor and breaker re-checked
  (`:613-635`).
- **Strict and band readings stay apart.**
  - Every value-moving path reads `_rate(false)`, which refuses an FX leg older than `fxMaxAge` at any hour
    (`:351-373`).
  - Only `brlCentsPerUnit` and `bandBrlPerUsdtE18` read the band (`:345, :386`), and the escrows use it only to admit
    or refuse a price.
- **Rate bounds.** `FxOutOfRange` holds R$ 1–100 at 1e-6 (SRM-1, `:366`); timestamps from the future are refused
  (`:358, :367`).
- **Freezes.** Frozen idle USDT counts as zero (`:858-860`), and frozen payees are refused (`:988-991`).
- **Reentrancy.** Every state-changing user function is `nonReentrant`.
- **The invariant suite holds:** supply equals minted less burned; redeem never pays above `min(par, ratio)`; hedge
  withdrawals never breach the floor; the band never reports above R$ 1.

**Open:** SRM1-10 (hedge queue: the contract is unchanged, but `--finalize` now refuses while one is
queued), SRM1-11 (treasurer), SRM1-21 (smaller items). **Fixed (contracts), after the
review:** SRM1-7 (breaker), SRM1-20 (redemptions could be frozen before finalize).

### 5.2 PythFxOracle and FxMarketHours

- **Attackers:** whoever posts Pyth updates (anyone); Pyth itself.

**Held:**
- price > 0;
- exponent bounded to ±18 before any power of ten (`PythFxOracle.sol:227`);
- confidence within `maxConfBps` (`:229`);
- 5-minute future skew (`:230`);
- the strict reading refuses anything older than `maxAge` (`:169-174`);
- the band takes the last close only outside 13:30–21:00 UTC on weekdays, for at most `closedMaxAge` (`:177-187`);
- the date arithmetic is Hinnant's `civil_from_days`, tested across leap years.

**Residual (accepted, SRM-15):** a poster may choose among the updates signed since the last post. After
renunciation the leg can never be repointed (section 8).

### 5.3 FiatEscrow and OffRampEscrow (Movva pair)

- **Holds:** the LP's offered MOVVA (on-ramp) and the seller's MOVVA for sale (off-ramp).
- **Attackers:** takers, sellers, LPs, the arbitrator, witnesses.

**Held:**
- **Single settlement within an escrow.** Every exit is gated on the order's or sale's state:
  - FiatEscrow: release `:687`, cancel `:743`, expire `:778`, dispute `:801`, resolve `:872`, timeout `:949`;
  - OffRampEscrow: `:336-576`.
  - `lockedWei` is decremented once per order.
  - The payee is only the recipient or the pool, the LP, or the seller's `refundTo`.
  - The escrow invariant suite (11 invariants) holds.
- **Rulings.** They are bound to escrow, order and chain (RulingLib's EIP-712 domain). They post, wait `RULING_DELAY`,
  and execute before the deadline. A ruling and the timeout are mutually exclusive (`FiatEscrow.sol:894-924`). Paying
  the side that escrowed nothing needs an arbitrator registered no later than the dispute (`:911`).
- **The bank-rail gate** (SR2-34) is checked at open (`FiatEscrow.sol:503`, `OffRampEscrow.sol:307`). The verifier is
  re-checked at settlement (SR2-7, `:702`, Off `:416`).
- **Decimals** are pinned at post time (SR2-13).
- **The rewards hook cannot block a settlement:** it runs with a bounded gas stipend, copies no return data, and a
  failure only emits an event (`LPRegistry.sol:456-465`).
- **Native ETH** is delisted and cannot be re-listed after finalize.

**Open:** SRM1-2. **Fixed (contracts):** SRM1-3, SRM1-4, SRM1-12, SRM1-13.

### 5.4 ReclaimZkTlsVerifier

- **Attackers:** colluding witnesses; a party presenting someone else's genuine claim.

**Held:**
- the provider must be "http" (`:233`);
- the claim identifier is recomputed from the claim (`:238-244`);
- witness signatures need a quorum, strictly ascending signers and low-s (`:310-328`);
- endpoints are allowed by provider hash plus a URL prefix that stops at a host boundary (`:275-286`, `:675-697`);
- the claim is bound to the order id (`:263`);
- the payment fields are read only from `extractedParameters` (`:266-267`);
- each endpoint carries its own rail mask (`:270`).

**Not checked by the contract:** epoch, owner, `timestampS` (informational).

**Residual:** colluding witnesses can sign a session that never happened. After finalize, no witness or endpoint can be
added or revoked.

**Added after the review: client audit finding M-03, 21 October 2026. Fixed in the source; the Sepolia verifiers keep
the old code.** The order binding above is the PROVER's `contextMessage`, and on the on-ramp the prover is the LP. So
an LP could prove an honest taker's credit against a sybil order of its own, which pays at least `brlCents` to the same
key. That spent the `bankTxId`, and the taker's own proof then reverted `ReceiptReplayed`. The verifier now binds the
order through a field the bank writes. An endpoint flagged `endpointRequiresOrderTxid` settles a non-boleto payment
only if the extracted `txid` (the PIX charge's, BR Code 62-05 or the cob's) is a 25-35 character prefix of
`base32(keccak256(abi.encode(block.chainid, msg.sender, orderId)))`, with `msg.sender` the escrow. The escrows are
unchanged. The header of `ReclaimZkTlsVerifier.sol` has the full argument, and `docs/audit-scope.md` ("Known issues")
lists the residual dependencies. The main one is that the bank's receipt page must show the txid, which is to be
confirmed per bank.

### 5.5 LPRegistry, NodeRewards, FeeSplitter

**Held:**
- the books identity `accounted == carry + outstanding + unfinalized funding` (NodeRewards invariants, 5 hold);
- voided shares are rounded so allocations always cover claims;
- `FeeSplitter.split` is permissionless and cannot be undone by a failing `sync` (`FeeSplitter.sol:82-102`).

**On M1:** the LP reward share is 0 and every fee goes to `<seed>/treasury/0`. After finalize the LP set, credit and
phase are frozen, and reputation changes nothing: only Phase A and institutional LPs exist, and their cap ignores
`disputesLost` (`LPRegistry.sol:350-354`).

### 5.6 AspRootQuorum

- **Attackers:** a minority of ASPs; lost keys.

**Held:**
- distinct, non-zero ASPs and a strict-majority threshold (`AspRootQuorum.sol:73-87`);
- a vote is a transaction, not a signature, so nothing can be replayed across chains or accounts;
- proposal = keccak(round, root, CID) (`:95-97`), with one vote per ASP per proposal (`:114`);
- the round advances on every posting, so votes from earlier rounds never complete (`:119-124`);
- its only external call is `updateRoot`;
- it has no owner, setter, receive or fallback;
- it has no code that could renounce or transfer ASP_POSTMAN.

**Fixed (contracts), after the review:** SRM1-14 (votes can be withdrawn and lapse after `VOTE_TTL`; a canonical
CID procedure in `packages/ops/src/asp-cid.ts`).

### 5.7 OwnerlessPaymaster

- **Holds:** a 1 ETH stake and a 0.1 ETH deposit at the EntryPoint.
- **Attackers:** anyone with a free account from the public factories; a bundler.

**Held:**
- **Nothing can withdraw.** The only external calls are `depositTo` and `addStake` (`:376-388`). The EntryPoint lets
  only the staked address itself call `withdrawTo` / `unlockStake` / `withdrawStake`.
- **Reservation.** Validation reserves the full `maxCost` against the per-account and global counters, with exact
  narrowings (`:309-331`).
- **Refund.** `postOp`'s charge covers postOp's gas, the EntryPoint overhead and v0.7's 10% unused-gas penalty, capped
  at the reservation. It cannot underflow or revert except by running out of gas, and validation demands at least 25k
  gas for it (`:292, :341-369`).
- **Windows.** A future window fails AA32 and reverts the whole bundle, so the counters cannot be pushed ahead of the
  clock. An old-window op is counted in the later window when one is open.
- **paymasterAndData.** Its length must be exactly 91 (`:288`). An unknown or disabled factory index yields address 0
  and is refused (`:434-443`).
- **CREATE2 derivation** is correct for SafeProxyFactory and for KernelFactory's Solady ERC-1967 proxy, and is proven on
  Sepolia (AA33 `NotFromFactory` for another factory or a wrong salt).

**Accepted by design** (`docs/ownerless-paymaster.md`): the global cap is the only bound on the drain, and the provenance
rule is a filter, not a Sybil defence.

**Open:** the Sepolia deposit top-up for SRM1-16 (the tooling is fixed; a human sends it). SRM1-5 is fixed in the wallet, but the paymaster still accepts any fee. SRM1-15 is fixed (see 5.9).

### 5.8 Kernel modules

**Held:**

- **PasskeyCoSignerValidator:**
  - both signatures are verified over the same digest, and both checks always run (`:199-214`);
  - the challenge binds `userOpHash` (sender, chain, EntryPoint), the validity window and the validator address
    (`UserOpChallenge.sol`);
  - ERC-1271 receives Kernel's wrapped hash;
  - high-s co-signer signatures are rejected;
  - re-initialisation is guarded, and config is keyed by `msg.sender`.
- **FrostValidator:** a malformed body returns invalid rather than reverting.
- **KernelAvatarAdapter:**
  - the caller is the trailing 20 bytes Kernel appends;
  - only CALL is allowed;
  - a different Delay is refused.

**Open:** two informational items in SRM1-21.

### 5.9 AuditGrantRegistry and ShieldedNoteLog

**Held:**
- no funds, no admin;
- all state keyed by `msg.sender`, so nobody can forge another's grant or append in their name;
- loops only over the caller's calldata.

**Fixed after the review:** SRM1-6 (wallet), SRM1-15 (auditor TypeScript).

### 5.10 Deploy and finalize tooling

**Held** (`scripts/deploy-movva-rail.ts`):
- `--finalize` refuses unless every pool is registered (`:910-913`);
- it refuses unless someone holds ASP_POSTMAN and every holder is a strict-majority `AspRootQuorum` of at least two
  ASPs on this Entrypoint (`:916-931`);
- it renounces DEFAULT_ADMIN_ROLE if held, then OWNER_ROLE, and checks that nobody holds either (`:933-956`);
- it sets the guardian to `0x…dEaD` before the reserve's governor, and checks it live (`:966-977`, `:996-998`);
- it refuses while minting is paused (`:964`);
- it completes setup where open, then hands every governor to `0x…dEaD` and checks each (`:984-1004`);
- every action is conditional on current state, so a rerun is idempotent.
- **Pending scheduled changes need no check:** `DelayedGovernance.execute` is governor-only
  (`DelayedGovernance.sol:159`), so a change scheduled before renunciation can never run after it.
  `ReviewM1_Movva.t.sol:test_Held_AChangeScheduledBeforeFinalizeIsDeadAfterIt` checks this.
- **`--broadcast-sepolia` guards** (`:1627-1665`): chain id; not anvil or hardhat; the exact confirmation string; the key
  matches the address; a secret seed; a clean tree; a fresh rehearsal with 0 failures; balance ≥ 2× the projected gas.
- **The privilege inventory** classifies every ABI function. An unknown function fails. Zero-argument probes always
  ABI-decode, so a stranger whose call is refused for another reason shows up as a FAIL, never as a false pass.

**Open:** none of SRM1-1, SRM1-8, SRM1-9 any more: each is fixed in `scripts/deploy-movva-rail.ts` and
`scripts/privilege-inventory.ts` (status in section 6). The line numbers above are those of the reviewed commit
`3809c2b`; the guards now live in `stepFinalize`, whose checks all run before its first send.

**Note on the chain:** `deploy-movva-rail.ts` refuses any chain but Sepolia (`:506`). The mainnet path is the runbook
(`docs/runbook-mainnet-deploy.md`) and has no automated equivalent of these guards yet.

---

## 6. Findings

Status: **open** (no change made; a decision or a fix is pending), **accepted** (a documented client decision),
**fixed (tooling)** (fixed after the review in the deploy tooling only; no contract changed; commit `81e8c08`),
**fixed (contracts)** (fixed after the review in the contracts, for the fresh MOVVA-only deployment: SRM1-3,
SRM1-4, SRM1-7, SRM1-12, SRM1-13, SRM1-14, SRM1-20 and SRM1-22), **fixed (wallet)** (fixed after the review in the TypeScript wallet and viewing key only; no contract
changed: SRM1-5, SRM1-6, SRM1-15), **fixed (removed)** (the code the finding is about was deleted after the review:
SRM1-19, with the savings path, client decision D1, 14 October 2026). The review itself changed no code. "Repro"
names the test in `contracts/test/ReviewM1_*.t.sol`; a fixed
finding's repro is inverted to assert the fix.

| ID | Severity | Component | Description | Impact | Status | Recommendation |
|---|---|---|---|---|---|---|
| SRM1-1 | High (if finalized with real value; informational for a test-value Sepolia rail) | deploy tooling / ramp configuration | `--finalize` checks the postman but not the other keys that remain for ever. Witnesses, the arbitrator, the LP and the endpoints all derive from one test seed | The seed holder can forge any payment proof and drain the book. Real witnesses or bank templates can never be added | fixed (tooling): `--finalize` refuses while any permanent role is a seed-derived identity (or a Safe of them) or an endpoint is an illustrative template; rehearsal opt-out `MOVVA_FINALIZE_ALLOW_TEST_KEYS=yes-this-is-a-rehearsal`, refused on chain id 1, recorded as a substitution | Refuse `--finalize` while any remaining role is a test identity or the endpoints are the illustrative templates |
| SRM1-2 | High | FiatEscrow, OffRampEscrow | A stolen arbitrator key, after renunciation, can lock every offer as a taker, dispute and RELEASE to itself; nobody can revoke it | The on-ramp book is drained; the off-ramp is reachable only with LP credit | accepted (Option A), but understated in docs | ≥ 2 arbitrator keys before finalize, held apart; correct the prose; consider keeping the brakes (`renounceRiskIncreasing`) |
| SRM1-3 | Medium | FiatEscrow, OffRampEscrow | A dispute raised before settlement blocks a valid proof (`WrongState`); only a ruling can pay the counterparty | With the desk absent, the side that escrowed keeps both legs at no cost | fixed (contracts): a valid proof settles a DISPUTED order or sale before the dispute deadline, for a payment inside `[lockedAt/claimedAt, payBy]` with every proof check unchanged; it closes the dispute (`DisputeResolved`, arbitrator zero), and only an LP that disputed its own on-ramp order records a lost dispute | Let a valid proof settle a disputed order or sale; refuse finalize with one arbitrator |
| SRM1-4 | Medium (availability) | FiatEscrow, LPRegistry | A taker escrows nothing, locks a whole offer and disputes; the liquidity and the LP's credit stay frozen up to 30 days | One LP on M1: off-ramp claims revert `LPNotEligible`, so holders cannot exit to PIX | fixed (contracts): a taker's dispute takes the order out of its offer and releases its credit at once, and if it ends unpaid pays the LP directly (no re-lock); no bond, so no-ETH takers are unaffected; the LP's capital can still be held up to `DISPUTE_TIMEOUT` | Shorter timeout or a bond for taker disputes; separate credit for disputed liquidity |
| SRM1-5 | Medium (known) | OwnerlessPaymaster, wallet | The paymaster never bounds the fee per gas; the wallet signs a fixed 1 gwei priority fee | On Sepolia the deposit drains ~1,000× faster than gas needs; any Sybil can burn MAX_COST_PER_OP per op | fixed (wallet): the executors sign the market's tip (the bundler's `rundler_maxPriorityFeePerGas` minimum, else `eth_maxPriorityFeePerGas`, else fee history), floored at 0.001 gwei and capped at 2 gwei, `maxFeePerGas` = 2 × base + tip, lowered to fit the paymaster's `MAX_COST_PER_OP` or refused (`packages/wallet/src/fees.ts`). The paymaster still accepts any fee from other wallets (the repro stands) | Wallet: priority fee from the network, capped. Next paymaster: an immutable priority-fee cap |
| SRM1-6 | Medium (audit completeness; no funds) (known) | wallet, ShieldedNoteLog | The change note's encrypted record is not appended after a partial withdrawal | A disclosure shows the pre-withdrawal deposit; without pool reconciliation, a balance that is too high | fixed (wallet): every record is queued in the wallet store with a random 6–72 h delay and appended later, batched per chain, from the chain's owner (`ViewingKeyService.deferNoteLogAppends`/`flushNoteLogAppends`, `MovvaWallet.appendDeferredNotes`); the queue survives restarts and reads the on-chain head first, so it appends once; the auditor reports a lagging log as `pending-append`, distinct from `missing` | Append on a cadence decoupled from withdrawals; until then, mark ShieldedNoteLog-backed statements incomplete |
| SRM1-7 | Medium (where a breaker is deployed; not on the Sepolia M1 rail) | MovvaReserve, DivergenceBreaker | The breaker is immutable and a dead tripping source halts it for good; with `HALTS_REDEEM=true` (the default) every USDT exit stops | All reserve USDT is locked for ever; only `recapitalize` works | fixed (contracts): a tripping source dead (reverting, malformed or zero with its full gas) on a claim nobody withdrew for `DEAD_AFTER` (immutable, 7–365 days, DeployMovva 30) is left out of redemptions only; anyone's `poke` opens a claim, any read that answers withdraws it; mint and hedge withdrawals still halt on it. Sepolia keeps the old code | Deploy with `HALTS_REDEEM=false`, or make a long-dead source stop counting for redemptions, or accept it in writing |
| SRM1-8 | Low | deploy tooling | Some finalize refusals fire after OWNER_ROLE is already renounced; `mintPaused` is read once before `setGuardian` lands | A refused run leaves a partly finalized state; a guardian can front-run into a permanent pause | fixed (tooling): every check runs before the first send; `setGuardian` goes first, with `mintPaused` re-read before and after it and again before the reserve's `transferGovernor`; a pause stops the run with the governor live | Check every precondition before the first send; re-read `mintPaused` before the reserve's `transferGovernor` |
| SRM1-9 | Low | deploy tooling | The postman check takes anything that answers like a quorum; no exact-set checks on the other permanent roles; the "before" inventory is never evaluated | An impostor or an extra role holder passes the guards | fixed (tooling): the postman must be the recorded quorum running the build's code with the recorded getters; every role holder is checked against the record's exact set; `privilegeChecks(before)` must pass; the record's role txs must be in the fetched logs | Exact sets against the record; a bytecode match for the quorum; run `privilegeChecks` before renouncing |
| SRM1-10 | Low | MovvaReserve | Queued hedge withdrawals never expire and survive revoking the treasurer and renunciation; finalize does not look | Anyone can execute an old request at any time (to the recorded treasury, above the floor) | fixed (tooling): `--finalize` refuses while any request is unexecuted (read from storage); the inventory lists them and fails a finalized rail that has one. The contract still has no expiry | Refuse finalize with unexecuted requests; an expiry in a future version |
| SRM1-11 | Low (decision) | MovvaReserve | The treasurer remains for ever, and with `distribute` dead (since removed: it no longer exists, D1) all backing above 103% is within its reach | A compromised treasurer and treasury can lower backing from ~108% to 103% | mitigated (custody), still a client decision: since 17 October 2026 the treasurer and hedge treasury are 2-of-3 Safes (custody phase 2); their permanence after finalize stands | If M1 has no hedge desk, `setTreasurer(0)` (instant) before finalize; with the hedge sleeve, keep the Safes and record them |
| SRM1-12 | Low | escrows | `usedBankTxId` is per escrow, so one PIX can settle an on-ramp order and an off-ramp sale when the payee commitments match | Double use needs a reused salted commitment | fixed (contracts): bank tx ids are spent in the shared `LPRegistry` (`consumeBankTxId`, escrows only), so one PIX settles one position across both escrows | One nullifier set across escrows (e.g. in the registry); correct the docs |
| SRM1-13 | Low | OffRampEscrow | `releaseStaleClaim` records nothing and `claimSale` has no cooldown | An LP can keep a seller from `cancelSale` indefinitely | fixed (contracts): the seller can cancel a claim past `payBy` directly, and a claim that ends unsettled starts a per-sale `CLAIM_COOLDOWN` (30 min) in which nobody can re-claim | Let the seller cancel a claimed sale after `payBy`; or a strike or cooldown |
| SRM1-14 | Low | AspRootQuorum | Votes cannot be withdrawn and do not expire within a round; proposals key on the exact CID string | A vote an ASP abandoned can still complete a quorum later; honest ASPs with different CID encodings never agree | fixed (contracts): `unvote` withdraws a vote, and a vote lapses after the immutable `VOTE_TTL` (1 hour–30 days, rail 3 days); only live votes count, still THRESHOLD of them for the exact root and CID. Canonical CID: `packages/ops/src/asp-cid.ts`. Sepolia keeps the old code | `unvote` or a vote deadline in a future version; a canonical CID procedure now |
| SRM1-15 | Low | viewing-key auditor (TS) | `audit.ts` compares an attestation with the on-chain anchor only when count ≤ anchor | A user can rewrite anchored records, append one, and pass the anchor check | fixed (wallet): when the attestation is longer than the anchor, `auditDisclosure` checks the received chain's head at the anchored count against the anchored head, and fails the report otherwise | Check that the anchored head is a prefix of the attested chain |
| SRM1-16 | Low (configuration) | OwnerlessPaymaster on Sepolia | `MAX_COST_GLOBAL` (0.2 ETH) is twice the deposit (0.1 ETH) | The global cap never binds; ten Sybil ops reserve the whole deposit in one window | fixed (tooling); Sepolia deposit top-up pending (human): the deploy refuses a deposit under 3 × `MAX_COST_GLOBAL`, `--verify` fails one and prints the top-up, the monitor's `paymaster_global_cap` alerts | Deposit ≥ k × `MAX_COST_GLOBAL`, or a lower cap |
| SRM1-17 | Informational (known) | wallet, app, OwnerlessPaymaster | Paymaster validation needs ~300k gas on Sepolia; an example still signs 200k; the app cannot build the 91-byte paymasterData | A fresh account's first op fails AA33 at simulation; the app cannot use the paymaster yet | fixed (wallet): `ownerlessPaymasterAndData` builds the 91 bytes per operation (salt, window, 300k on Sepolia), both executors take it, the app takes `account.ownerlessPaymaster`, the example signs the wallet's figure; the real contract accepts it on anvil. Fixed (app, co-signer, 18 October 2026): fresh passkey accounts are readied with no SponsorGate, and sub-wallets use the paymaster | Build the paymasterData in the wallet/app (salt, window, 300k on Sepolia); fix the example |
| SRM1-18 | Informational (known) | Sepolia | Anonymity set of 1: the pool held one deposit | The Task 3 withdrawal is attributable by elimination | accepted (stand-in) | Not a contract property; see section 9 |
| SRM1-19 | Informational | MovvaReserve | `previewDistribute` reports an amount `distribute` refuses (`NoSavings`) | Misleads off-chain readers only | fixed (removed): both functions and the savings path were deleted (D1, 14 October 2026) | Return zero while `savings` is unset, or drop the dormant path |
| SRM1-20 | Informational | MovvaReserve | Before finalize the governor can freeze redemptions instantly (a 1 s max age, or removing every gateway) | Contradicts "nobody can pause redemptions"; moot after finalize | fixed (contracts): max ages have floors (USDT/USD 1 day, FX 15 minutes) on every path; the prose says precisely what can stop a redemption before and after finalize (removing every gateway remains, before finalize). Sepolia keeps the old code | Reword the claim; a lower bound on max ages |
| SRM1-21 | Informational | various | Smaller observations and wrong prose (list below) | none directly | fixed (contracts, tooling, prose), each item below; the stand-in USDT accepted | as listed |
| SRM1-22 | Medium | FiatEscrow, OffRampEscrow (RulingLib) | Rulings are verified with `ecrecover` only, so the client-approved Safe multisig arbitrator can never rule; the escrows are not upgradeable | Arbitration custody stays on one ECDSA key (feeding SRM1-2 and -3); registering the Safe and removing the key would make RELEASE impossible | fixed (contracts): a signature that is not 65 bytes names a contract arbitrator (`arbitrator ‖ signature`) and is accepted only if that registered contract's `isValidSignature` returns the magic value under STATICCALL; the new pair is deployed with the 2-of-3 Safe as its only arbitrator | Either new escrows that accept EIP-1271 rulings, or an interim arbitrator key in a KMS/HSM, ideally two (SRM1-2) |
| SRM1-23 | Informational | deploy tooling / custody plan | `--finalize` sends the guardian to `0x…dEaD` (C2) while the custody plan first rotates it to a 2-of-3 Safe | The Safe guardian lives only until finalize; while it lives, two of its signers can pause minting, and a pause landing before finalize's `setGuardian` becomes permanent (SRM1-8) | fixed (docs): `docs/deployments.md` says the guardian Safe is pre-finalization only and is replaced by `0x…dEaD` at finalize (C2); the race is closed by the SRM1-8 fix | State in the custody plan that the guardian Safe is pre-finalization only; fix SRM1-8 before finalizing a rail with a Safe guardian |

### SRM1-1 — The keys that remain for ever are test identities, and finalize does not check them
**Severity: high if `--finalize` runs on this configuration with real value; informational on a test-value Sepolia
rail.** `scripts/deploy-movva-rail.ts`. **Fixed (tooling)**; the configuration itself is unchanged.

**Where the identities come from.** On the MOVVA-only rail every role that "remains by necessity" derives from one
secret, `MOVVA_TEST_KEY_SEED` (`identities()`, `:262-275`):
- the 2-of-3 zkTLS witnesses (`ZKTLS_WITNESSES`, `:795`);
- the only arbitrator (`ARBITRATOR`, `:794`);
- the only LP and gateway (`INSTITUTIONAL_LPS`, `:802`);
- the reserve's treasurer and hedge treasury.

The bank endpoints are the illustrative receipt templates (`docs/deployments.md`, "Substitutions (rehearsal only)").

**What finalize checks.** `stepFinalize` (`:895-1010`) checks the ASP postman, the guardian and the pause. It checks
nothing about these roles. Once the governors are `0x…dEaD`:
- nobody can revoke them;
- nobody can add a real Reclaim witness or a real bank template. `setWitness` and `allowEndpoint` are risk-increasing
  and governor-only (`ReclaimZkTlsVerifier.sol:579-607`).

**Impact.** The seed holder can sign a zkTLS receipt for any order or sale (`ReclaimZkTlsVerifier.sol:310-328`):
- settle every on-ramp order and drain every offer;
- `claimSale` and `settleWithProof` any open sale at once.

This is documented as a substitution, but the finalize path does not enforce the substitution's precondition.

**Recommendation.**
- Make `--finalize` refuse while any remaining role is derived from the test seed, or while the endpoints are the
  illustrative templates.
- On Sepolia, either do not finalize the ramp's governors or record explicitly that the finalized rail is a
  demonstration whose witnesses are Mova's.

**Fix (tooling, after the review).** `stepFinalize` (`testKeyFindings`, `PERMANENT_KEY_ROLES`) reads every holder of the
roles that remain for ever from the inventory taken before finalizing: zkTLS witnesses, escrow arbitrators, registry LPs,
the reserve's gateways, treasurer and hedge treasury, the FeeSplitter's treasury and the quorum's ASPs. It refuses while
any is an address the test seed derives (`witness/*`, `arbitrator/*`, `lp/*`, `guardian/*`, `treasurer/*`,
`hedge-treasury/*`, `treasury/*`, `asp/*`, and the custody rehearsal's `custody/<role>/signer/*`; for the run's seed,
the public rehearsal seed and the recorded identities), or a Safe whose threshold of owners are such keys, and while any
allowed zkTLS endpoint is one of `packages/ramp`'s receipt templates or sits on a reserved test domain
(`api.banco-lp.example`). A rehearsal or testnet may proceed with `MOVVA_FINALIZE_ALLOW_TEST_KEYS=yes-this-is-a-rehearsal`
(process environment only). It is refused on chain id 1 whatever the variable says, and a run that uses it records a
`FINALIZED WITH TEST KEYS` substitution in the deployment JSON, `finalize.testKeys`, and a banner and a Substitutions
section in `VERIFICATION.md`. The refusal fires before anything is sent (SRM1-8); the fork rehearsals are in `docs/deployments.md`, "The `--finalize` guards (SRM1-1, -8, -9, -10)".

### SRM1-2 — A stolen arbitrator key drains the on-ramp book, and nobody can revoke it
**Severity: high. Accepted with Option A, but stated too weakly.** `FiatEscrow.sol`, `OffRampEscrow.sol`.

**The attack, checked precisely.**
1. The key holder needs no registry status to be an on-ramp taker (`FiatEscrow._lock`, `:621-675`: no bond, no
   registry check).
2. It locks all free liquidity of every offer, in many orders and one block.
3. It disputes each (`:797-806`) and posts a RELEASE ruling.
4. It executes 24 hours later (`RULING_DELAY`).

The arbitrator was registered before the dispute, so `ArbitratorNewerThanDispute` (`:911`) does not stop it.
`closeOffer` recovers nothing from a disputed order. On the off-ramp it additionally needs an LP with credit; on M1
that LP derives from the same seed (SRM1-1).

**Before renunciation** the defence is revoking the arbitrator, which is instant and voids every posted ruling.
**After it**, `setArbitrator` reverts `NotGovernor`.

**Ping-pong.** An honest desk holding the same key cannot reliably defend, because posting a different ruling restarts
the delay. Whoever posts last before `deadline − 2 × RULING_DELAY` wins (`:913-920`; NatSpec `:832-835`).

**Prose that becomes false after finalize:**
- `FiatEscrow.sol:103-108`, `:819-827`, `:832-834` ("revoking … is instant");
- `OffRampEscrow.sol:64-67`, `:466-473`;
- `docs/deployments.md`, "Privileges, and `--finalize`" ("A ruling reaches only a disputed order"). The arbitrator can create the disputed
  orders itself.

**Repro:** `ReviewM1_Ramp.t.sol:test_M1_StolenArbitratorKeyTakesTheWholeOfferAndNobodyCanRevoke`.

**Recommendation.**
- Register at least two arbitrator keys, held by separate parties, before finalizing; on these escrows they must be
  ECDSA keys, for example in KMS/HSMs, since a Safe cannot rule (SRM1-22). Have `--finalize` refuse
  with one. A second key cannot outvote a stolen one, but it can always REFUND: a refund is accepted from any current
  arbitrator. Under ping-pong, that leaves only the last-poster race.
- Correct the prose.
- The structural fix is the one `docs/deployments.md`, "Privileges, and `--finalize`" (last paragraph) describes: renounce the risk-increasing powers and keep
  the brakes. That is a contract change for the client to approve.

### SRM1-3 — A dispute pre-empts a valid proof
**Severity: medium.** `FiatEscrow.sol:687, :797-806, :947-955`; `OffRampEscrow.sol:411, :448-456, :566-576` (line numbers as reviewed). **Fixed (contracts).**

**The mechanism.** Either party may dispute at any time while the order is LOCKED (or the sale CLAIMED). From then on
`releaseWithProof` / `settleWithProof` revert `WrongState`, and only a RELEASE ruling can pay the side that escrowed
nothing. After finalize there is one arbitrator, and it can never be replaced or joined.

**The two cases.**
- **On-ramp.** The LP disputes as soon as the PIX lands. If the desk does not rule within 30 days, `expireDispute`
  returns the MOVVA to the offer, and the LP keeps the BRL too. The timeout records a lost dispute against an LP that
  raised one. An institutional LP's cap ignores that (`LPRegistry.sol:350-354`), so it costs nothing.
- **Off-ramp.** The seller disputes ahead of the LP's settlement: from the bank notification, or by front-running the
  `settleWithProof` transaction. The timeout refunds the seller, who keeps the PIX too. A seller is a fresh address with
  nothing to lose.

**Even with a live desk**, every such case costs at least `RULING_DELAY` plus the desk's turnaround.

**How much the code already admits.** The code's own comment accepts that a timeout favours the escrower and that the
LP "is the only party on this leg a dispute could profit, by holding a paid order until the desk is unreachable"
(`FiatEscrow.sol:940-947`). What is new is that a valid proof, which would settle the case objectively, cannot be used
once a dispute is open. After renunciation, desk availability can never be improved.

**Repro:**
- `ReviewM1_Ramp.t.sol:test_M1_LPPreemptsATakersValidProofAndKeepsBothLegs`, now `test_M1_Fixed_LPCannotPreemptATakersValidProof`;
- `ReviewM1_Ramp.t.sol:test_M1_SellerPreemptsTheLPsValidProofAndKeepsBothLegs`, now `test_M1_Fixed_SellerCannotPreemptTheLPsValidProof`.

**Recommendation.**
- **Contract change, for the next version:** accept a valid proof on a DISPUTED order or sale, for a receipt inside
  `[lockedAt/claimedAt, payBy]`, deciding against the party who disputed.
- **Now:** at least two arbitrator keys (SRM1-2), and a desk availability commitment written into the M1 operations.

### SRM1-4 — A taker who escrows nothing can freeze the book and stall exits
**Severity: medium (availability).** `FiatEscrow._lock` `:621-675`, `raiseDispute` `:797-806`, `_unlock`
`:1197-1203`; `LPRegistry.reserveExposure` `:399-409` (line numbers as reviewed). **Fixed (contracts).**

**The mechanism.**
1. A stranger locks the whole of an offer. There is no bond and no registry check.
2. It disputes immediately. The liquidity is now frozen for `DISPUTE_TIMEOUT` (30 days) instead of `PAY_WINDOW`,
   unless the desk signs a REFUND for each order (one day plus turnaround each).
3. The LP's credit stays reserved meanwhile, and one credit number covers both escrows. So the LP's `claimSale` reverts
   `LPNotEligible`.

**Impact.** On M1 (one LP, R$ 50,000 of credit) that stops every exit to PIX.

- At expiry the griefer can expire and re-lock in one transaction, ahead of the LP's `closeOffer`.
- The cost is gas.
- It contradicts `OffRampEscrow.sol:23` ("an idle taker wastes an LP's capital for a pay window. Bounded and cheap").

**Repro:** `ReviewM1_Ramp.t.sol:test_M1_AFreeTakerFreezesTheBookAndStallsEveryExit`, now `test_M1_Fixed_AFreeTakerCannotFreezeTheLPsCreditOrStallExits`.

**Recommendation.**
- **Next version:** a short timeout for taker-raised on-ramp disputes, a taker bond, or disputed liquidity counted
  apart from off-ramp credit.
- **Now:** keep on-ramp offers small relative to the LP's credit, so an attack freezes only part of it, and run the
  desk with a REFUND-within-hours target.

### SRM1-5 — The paymaster does not bound the gas price; the wallet signs a fixed 1 gwei tip (known)
**Severity: medium.** `OwnerlessPaymaster.sol:282-295, :341-369`; `packages/wallet/src/executor.ts:389-390`;
`packages/wallet/src/kernel-executor.ts:116-117`. **Fixed (wallet).**

**The mechanism.**
- **Paymaster.** `_check` never reads `userOp.gasFees`. The only cost bound is `maxCost ≤ MAX_COST_PER_OP` (`:293`).
  `postOp` charges `actualGasCost` at whatever `actualUserOpFeePerGas` the op paid.
- **Wallet.** It signs `maxPriorityFeePerGas = 1 gwei` and `maxFeePerGas = 2 × base + 1 gwei`. EntryPoint v0.7 charges
  `min(maxFee, base + priority)`, which is base + 1 gwei, and the bundler's beneficiary keeps the difference over the
  base fee.

**The numbers.**
- On Sepolia (base fee ~0.001 gwei) that is about 1,000× the fee needed. At the 18 wei recorded on 14 October it is far
  more.
- The six Task 2 ops cost 0.00685 ETH of deposit, about 0.00114 ETH each.
- At that rate the 0.1 ETH deposit lasts about 87 ops, less than one window of the global cap.

**Without the wallet bug.** Any free account from the public factories can sign a fee that makes `maxCost` exactly
`MAX_COST_PER_OP`. Ten such ops drain the deposit, and a bundler that is the attacker keeps it.
`docs/ownerless-paymaster.md` accepts the attacker-bundler case. The new point is that honest public bundlers also
pocket the wallet's tip.

**Repro:** `ReviewM1_Accounts.t.sol:test_Demo_PaymasterSponsorsAnyGasPriceUpToMaxCostPerOp`. An op at ~2.46 gwei gets
the same `validationData` as one at 19 wei, and is charged ~0.01 ETH.

**Recommendation.**
- **Wallet:** take the priority fee from the network (`eth_maxPriorityFeePerGas` or the bundler), with a ceiling.
- **Next paymaster:** an immutable cap on `maxPriorityFeePerGas` (`userOp.gasFees >> 128`). That is calldata, so
  ERC-7562 allows reading it in validation. Optionally also cap `preVerificationGas`.

This contract is immutable and ownerless, so changing it means a new deployment and a new stake. The old 1 ETH stays
locked for ever (`docs/ownerless-paymaster.md`).

**Fix (wallet, after the review).** `packages/wallet/src/fees.ts`; both executors.
- **The tip** comes from the bundler when the submitter is one that publishes a minimum (rundler's
  `rundler_maxPriorityFeePerGas`, forwarded through the co-signer's submitter wrappers), else from the node's
  `eth_maxPriorityFeePerGas`, else from the median of `eth_feeHistory`. With no answer at all the executor refuses
  rather than guessing.
- **Floor and cap.** The tip is held between 0.001 gwei and 2 gwei (both configurable). A bundler minimum is always
  honoured above the floor; one above the cap is refused before anyone signs, since the bundler would reject anything
  lower.
- **`maxFeePerGas`** keeps its shape: 2 × base + tip.
- **`MAX_COST_PER_OP`.** With `paymasterMaxCostPerOp` set, the executor computes the EntryPoint's prefund (every gas
  limit, paymaster limits included, times `maxFeePerGas`). If that is over the cap, it lowers `maxFeePerGas` to fit,
  provided base + tip still fits; otherwise it refuses before signing. At Sepolia's fees (18 wei base, 0.001 gwei tip)
  a Kernel op's maxCost is about 4 × 10⁻⁶ ETH against the 0.01 ETH cap.
- **Tests:** `packages/wallet/test/executor-fees.test.ts`.

The repro `test_Demo_PaymasterSponsorsAnyGasPriceUpToMaxCostPerOp` is **not** inverted. It shows a property of the
contract, which did not change: any other wallet can still sign a fee that makes `maxCost` equal `MAX_COST_PER_OP`. The
next paymaster's priority-fee cap remains the fix for that.

### SRM1-6 — The change note's encrypted record is not appended (known)
**Severity: medium for audit completeness; no funds at risk.** `ShieldedNoteLog.sol:65-78`;
`packages/wallet/src/movva/withdrawal.ts`; `scripts/task3-withdraw-to-pix.ts:384, :1231`. **Fixed (wallet).**

**The mechanism.** `ShieldedNoteLog` records whatever its owner appends; nothing links it to pool commitments. The
wallet's withdrawal path has no note-log code at all. Task 3 deliberately skipped the append for the 302.1563 MOVVA
change note, because an append from user/0 minutes after an anonymous withdrawal would link the two by timing:
`NoteAppended` indexes `owner`.

**Impact.**
- user/0's on-chain October chain still shows only the 502.1563 deposit, so the Task 2 "complete" statement is now
  stale.
- An auditor who reconciles against the pool should get a truncated lineage (spent, successor not disclosed;
  `packages/viewing-key/src/reconcile.ts`) and an incomplete report. This was read from the code, not run.
- An auditor who does not reconcile sees a balance that is too high.

**Recommendation.**
- Append on a fixed cadence decoupled from withdrawals: batched, with padding or dummy records. Or use vault mode with
  periodic anchors.
- Until the wallet does one of these, state on every ShieldedNoteLog-backed disclosure that it is complete only up to
  the last append.

**Fix (wallet, after the review).**
- **Deferred append.** `ViewingKeyService.deferNoteLogAppends` queues every record the service writes. Deposits, spends
  and change are treated alike, so the queue does not reveal the kind. Each record gets a `notBefore` drawn from a
  CSPRNG, uniform over 6–72 h after the movement (`packages/viewing-key/src/append-queue.ts`). The queue lives in the
  wallet store (`WalletSnapshot.pendingAppends`), so a restart neither drops a record nor re-draws its time.
- **Sending.** `flushNoteLogAppends` (the wallet's `appendDeferredNotes`, `packages/wallet/src/note-log.ts`) runs on the
  wallet's own cadence, never inside a movement. Per chain, it sends every record past the on-chain head up to the last
  due one, as one `appendNotes` from the account that owns the chain.
- **Idempotent.** The flush reads `headOf` first and drops records the log already holds. A head that is not the
  device's own record refuses.
- **Auditor.** `auditDisclosure`'s `noteLog` option reports each attested chain as `complete`, `pending-append`
  (received, chained to the signed head, not on the log yet; the report is not complete), `missing`, `omitted` or
  `diverged`.
- **Not hidden:** that the owner's chain for that month grew. Dummy records would hide it, but they would also be notes
  in every statement.
- **Tests:** `packages/viewing-key/test/deferred-append.test.ts` and `packages/wallet/test/note-log.test.ts`.
- **Live chain:** the Task 3 change note on Sepolia is still unappended until the wallet flushes it.

### SRM1-7 — A retired breaker source would lock the reserve for good
**Severity: medium where a breaker is deployed; not live on the Sepolia M1 rail (`MOVVA_RAIL_BREAKER=off`, and
`BREAKER == 0` skips every check: `MovvaReserve.sol:327, :491, :535, :563, :623`).** **Fixed (contracts).**

**Defaults.** For a mainnet deployment through `DeployMovva` directly, the breaker is ON by default
(`DeployMovva.s.sol:92-94, :305-307`), with `HALTS_REDEEM=true` (`:366`) and the Chainlink and TWAP sources set to
trip.

**The mechanism.** `BREAKER` is immutable (`MovvaReserve.sol:180, :315`). `DivergenceBreaker` has no setter and counts
a reverting tripping source as disagreeing. So if one source dies for good, mint, redeem, `withdrawToHedge` and
`executeHedgeWithdrawal` all revert for ever. Ways a source dies:
- Chainlink deprecates BRL/USD;
- a pool migrates;
- in-range liquidity stays under `MIN_LIQUIDITY`.

This holds even with a live governor: no setter touches the breaker. SRM-16 accepted a temporary halt, not the
permanent case.

**Repro:** `ReviewM1_Movva.t.sol:test_M1_2_ADeadTrippingSourceLocksTheReserveForever`. With the governor renounced and
365 days passed, every exit reverts `SourceUnavailable`; `recapitalize` still works.

**Related, low:** the TWAP source's liquidity floor is a spot reading (`UniswapV3TwapSource.sol:71`). One swap in the
same block can halt a single mint or redeem. The code calls it "crude", but `docs/movva.md`'s cost model omits it.

**Recommendation.** Before any mainnet deployment with a breaker, do one of:
- deploy with `MOVVA_BREAKER_HALTS_REDEEM=false`;
- make a source unavailable for N days stop counting for `checkRedeem` (a contract change);
- accept the permanent case in writing.

**Fix (contracts, after the review): the second option.** `DivergenceBreaker` takes an immutable `DEAD_AFTER`
(7 to 365 days; `DeployMovva`'s `MOVVA_BREAKER_DEAD_AFTER`, 30 days by default, `HALTS_REDEEM` still true). It stays
keyless: no owner, no setter, no role.
- **Dead** means `brlPerUsdtE18()`, given its full `SOURCE_GAS` (500,000), reverts - which every source does when its
  reading is stale beyond its own max age, too thin or out of range - or returns anything but 32 bytes of a non-zero
  rate.
- **The claim.** Anyone may `poke()`. A tripping source found dead with no open claim gets one dated now
  (`SourceReportedDead`); a claim is never moved. Every poke, and every `check` and `checkRedeem` that passes (so every
  mint, redemption and hedge withdrawal that passes), withdraws the claim of each source it read answering
  (`SourceAlive`). The claims are one storage word, the breaker's only state.
- **The verdicts.** `checkRedeem` leaves a source out only if it is dead in that call AND its claim is at least
  `DEAD_AFTER` old; a source that answers is always compared. `check` (mint, `withdrawToHedge`,
  `executeHedgeWithdrawal`) ignores claims. Our choice: mint and hedge withdrawals stay halted on a dead source for
  ever. They grow or move the backing on a degraded set of prices and are no holder's exit, so such a reserve winds
  down to redemptions; a successor needs a new deployment. Exits can no longer be locked for ever.
- **A live source cannot be made to look dead.** An attacker needs a claim nobody withdrew for `DEAD_AFTER`, plus the
  source dead in the redemption. One successful read by anyone in that time withdraws the claim, so they would have to
  keep it dead in every block anyone reads it for 30 days. A diverging source answers, so during a real divergence it
  keeps halting redemptions. A starved read never counts: `poke` reverts `InsufficientGas`, and `checkRedeem` reverts
  rather than leave a source out, unless the read had all its gas. Residual: a claim on a source that recovered stands
  until someone reads it; the monitor's new `movva_breaker_claims` fails on any claim against a source that answers,
  and the runbook says to `poke()` it through a private relay.
- **The cost.** After `DEAD_AFTER` a redemption is priced by the reserve's rate and the remaining sources, as if the
  dead source had never been configured; with every tripping source dead, by the reserve's rate alone, which is what
  `HALTS_REDEEM=false` gives from day one.

`check` and `checkRedeem` are no longer `view` (they withdraw claims); the reserve calls them as before, now with a
CALL rather than a STATICCALL, under its `nonReentrant`. Size: DivergenceBreaker 3,048 bytes (1,918 before).

Tests: `ReviewM1_Movva.t.sol:test_M1_2_Fixed_ADeadTrippingSourceNoLongerLocksExits` (the repro, inverted: renounced
governor, a year on, redemptions pay; mint and hedge still halt). `MovvaBreaker.t.sol`: the clock to the second, the
remaining sources still halting a divergence, the attack (a one-block knock-out withdrawn by a mint, a redemption, a
poke with a diverging answer), an old claim never leaving out a source that answers, starved reads, informational
sources never claimed, `HALTS_REDEEM=false`, a fuzz that claims only relax redemptions for sources dead now, and the
invariant suite `BreakerClaimsInvariantTest` (the claims equal a model's; no mint with a dead source; no redemption
with a source dead and not long dead; `redeemOpen` exactly when every source answers or is long dead).
The contracts on Sepolia are immutable and keep the old code: the 6 October rail and the fork-rehearsed MOVVA-only rail are unchanged, and only a deployment from this code gets the fix.

### SRM1-8 — Finalize refuses after the irreversible step, and reads the pause once
**Severity: low.** `scripts/deploy-movva-rail.ts:951, :962-977, :996-1007` (at `3809c2b`). **Fixed (tooling).**

**Refusals after the irreversible step.** OWNER_ROLE is renounced at `:951`. Three refusals run only after it:
- minting is paused (`:964`);
- the reserve's governor is already `0x…dEaD` while the guardian is live (`:969`);
- a governor is not the deployer (the throw after the loop).

A run that refuses there leaves a partly finalized state: the Entrypoint is immutable, the governors are still live.
That state is recoverable by rerunning, since every action is conditional, except for the guardian case at `:969`.

**Reading the pause once.** `mintPaused` is read at `:962` and never again. The guardian key can call `pauseMint` in
the window before `setGuardian` lands. The run then hands the reserve's governor to `0x…dEaD` with minting paused, and
nobody can ever resume it. The post-run check (`:1141`) catches it only afterwards.

On the live path all of this needs chain state to change between the mandatory fork rehearsal and the broadcast, which
is why it is low.

**Recommendation.**
- Move every read-only precondition ahead of the first `send()`: `mintPaused`, the guardian and governor state of all
  eight contracts, and the `forGovernor` list.
- Re-read `mintPaused` after `setGuardian` and immediately before the reserve's `transferGovernor`.

**Fix (tooling, after the review).** `stepFinalize` is now two phases. Phase A runs every check read-only and lists every
problem it finds, then refuses before the first send: pools, the evaluated inventory, exact sets, the postman, the hedge
queue, test keys, `mintPaused`, the guardian/governor state, and the governors that are not the deployer's (their
calldata is printed only once every other check passes). Phase B sends, least reversible last: `setGuardian(0x…dEaD)`
first (reversible while the governor lives), with `mintPaused` read immediately before it and again after it lands; then
the Entrypoint's OWNER_ROLE; then the governors, the reserve's first, after re-reading its guardian and `mintPaused` once
more. A pause that slips in while `setGuardian` is in flight stops the run before anything irreversible, with the
reserve's governor still able to `resumeMint`. the fork rehearsals are in `docs/deployments.md`, "The `--finalize` guards (SRM1-1, -8, -9, -10)" (scenario 5 front-runs `setGuardian` with `pauseMint` in the
same block).

### SRM1-9 — Finalize's guards are not exact-set checks
**Severity: low.** `scripts/deploy-movva-rail.ts:914-931, :901-903` (at `3809c2b`); `scripts/privilege-inventory.ts`.
**Fixed (tooling).**

**The postman check is duck-typed.** It accepts any ASP_POSTMAN holder that answers `ENTRYPOINT`, `THRESHOLD` and
`ASP_COUNT` plausibly (`:920-931`). It does not check:
- that the holder is the recorded quorum;
- that its runtime code is `AspRootQuorum`;
- that the threshold is ≤ the count (an impostor reporting 99-of-3 passes);
- that the ASPs exclude the deployer.

The strong checks run only in the verification after finalize (`:1110-1119`).

**Role discovery is narrower than the inventory's.** It uses four candidate addresses (`:914`); the inventory uses
every known one (`privilege-inventory.ts:763`). The "before" inventory is taken (`:901-903`) but `privilegeChecks` is
never run on it before renouncing.

**No exact-set checks on the permanent roles.** Nowhere is it checked that:
- the only gateway is the test LP (`:1148` checks only that the test LP is one);
- the treasurer, hedge treasury and yield vault are as recorded;
- the witness count is as expected (`:1205`);
- the test arbitrator is the only arbitrator (`:1173`);
- the allowed-verifier set and LP tiers are as recorded;
- no unexpected pool is registered.

The forge scripts assert these at deploy time (`DeployMovva.s.sol:400-459`, `DeployRamp.s.sol:306-340, :676-746`), so
drift can only come from governor actions in between.

**Log completeness.** Log reads fail closed on errors (`:692-707`). A provider that silently returns partial logs
would hide a role holder.

**Recommendation.**
- Exact sets against the record, and a bytecode match for the quorum.
- Run `privilegeChecks(before)` and refuse on any failure.
- Assert that the record's own `RoleGranted` transactions appear in the fetched logs.

**Fix (tooling, after the review).** Before renouncing anything, `stepFinalize` now:
- runs `privilegeChecks` on the "before" inventory and refuses on any failure (the one exception is "OWNER_ROLE held by
  the owner alone" on a rerun after OWNER_ROLE is already gone);
- runs `exactHolderChecks` (new in `privilege-inventory.ts`) against `expectedHolders(d)`: every gateway, treasurer,
  hedge treasury, fee recipient, sMovva, yield vault, FeeSplitter treasury and rewards, NodeRewards registry and
  exclusions, registry escrows, rewards hook and LPs, witnesses, endpoints, and each escrow's arbitrators, verifiers and
  listed assets must be exactly the recorded set, with no extra holder. A legitimate change since deployment (a custody
  rotation) is declared in the deployment JSON's `expectedHolders`;
- takes role holders from the inventory, whose candidates are every address the record knows plus every account a
  `RoleGranted`/`RoleRevoked` log names, and refuses any OWNER_ROLE/DEFAULT_ADMIN_ROLE holder but the deployer and
  any role it does not know;
- checks that the `asp` step's own `grantRole`/`revokeRole` transactions are among the fetched logs (`entrypointRoleTxs`);
- requires the ASP_POSTMAN holder to be exactly the recorded `AspRootQuorum`, whose runtime code matches the build's
  (`compareRuntime`, immutables masked) and whose `ENTRYPOINT`, `THRESHOLD`, `ASP_COUNT` and `asps()` are the recorded
  ones, a strict majority of at least two, without the deployer.

The exact-set checks also join the verification of a finalized record. the fork rehearsals are in `docs/deployments.md`, "The `--finalize` guards (SRM1-1, -8, -9, -10)" (scenario 4: an extra postman, and
an impostor quorum that answers every getter correctly).

### SRM1-10 — Queued hedge withdrawals never expire
**Severity: low.** `MovvaReserve.sol:231-238, :595-635`. **Fixed (tooling)**; the contract is unchanged.

**The behaviour.** A `HedgeRequest` has no expiry. A request queued before `--finalize` can be executed by anyone, at
any later time. It survives `setTreasurer(0)` followed by `transferGovernor(0x…dEaD)`. DelayedGovernance changes, by
contrast, expire after `EXECUTION_WINDOW` (14 days).

`--finalize` does not look at `hedgeRequestCount`, and the inventory does not either.

**Impact is small.** Payment goes only to the hedge treasury recorded at queue time, and the 103% floor and the breaker
are re-checked at execution (`:625-632`). But a third party chooses the timing, and no brake remains.

**Repro:** `ReviewM1_Movva.t.sol:test_M1_1_AQueuedHedgeRequestSurvivesRevocationAndRenunciationAndNeverExpires`
(a stranger executes 40,000 USDT a year later).

**Recommendation.**
- Finalize refuses, or lists them, while any request is unexecuted; add them to the inventory.
- An expiry in a future version.

**Fix (tooling, after the review).** `queuedHedgeWithdrawals` (`privilege-inventory.ts`) reads `hedgeRequestCount` and
then `hedgeRequests(id)` for each id from storage; no logs are needed. `--finalize` refuses while any request is
unexecuted, naming each (amount, destination, executable-from). The inventory records the queue and the count for the
reserve, and on a finalized rail fails "no queued hedge withdrawal is left unexecuted". The expiry remains a
recommendation for a future contract version. The repro test above pins the contract's behaviour, which is unchanged, so
it stands as is. the fork rehearsals are in `docs/deployments.md`, "The `--finalize` guards (SRM1-1, -8, -9, -10)" (scenario 3).

### SRM1-11 — The treasurer is a permanent USDT outflow, and nothing rebuilds the buffer
**Severity: low (a decision for the client).** `MovvaReserve.sol:556-635, :701-705`. **Mitigated (custody), still a client decision.**

The treasurer is not among the roles the client listed as remaining. `docs/deployments.md`, "What remains, by necessity" does list it.

**After finalize the treasurer cannot be revoked.** It can:
- send up to 8% of the reserve a day instantly;
- queue more, executable after one day;
- do both to the fixed hedge treasury, down to 103% backing at the current rate.

With `distribute` dead (sMovva is out of M1), nothing returns the reserve to the 108% target. *(Since 15 October 2026
`distribute` no longer exists at all - the savings path was removed, D1 - so the same holds without it; this finding stays
open.)* Every unit of backing
above 103% is within the treasurer's reach for ever. If both the treasurer and the hedge-treasury keys are compromised,
holders lose that buffer. The 103% floor protects them only against the rate as the oracle reports it.

**Recommendation.** If M1 has no hedge desk, call `setTreasurer(address(0))` before finalizing. It is instant, by design
(`:701-705`). If hedging is part of M1, record the treasurer and hedge treasury among the keys that remain, with their
custody.

The custody rehearsal (`26d345d`, `docs/deployments.md`, "Custody rotation rehearsal") rotates both roles to 2-of-3
Safes through the delayed setters, with phase 2 executing 48 hours later. That mitigates the key-compromise half of
this finding. It does not change the permanence: after finalize, those Safes and their signer sets are fixed for ever.
Phase 2 was executed on Sepolia on 17 October 2026 (`ade9c9f`). The treasurer is `0x6C41…6561` and the hedge treasury
`0x4464…6Cdb`, each a 2-of-3 Safe; the old test keys are refused. The open part is the client's: whether the treasurer
should remain after finalize at all. The hedge sleeve (next milestone, B2–B7) is a reason to keep it.

### SRM1-12 — One PIX can settle an on-ramp order and an off-ramp sale
**Severity: low.** `FiatEscrow.sol:260, :725-727`; `OffRampEscrow.sol:137, :428-434` (line numbers as reviewed).
**Fixed (contracts).** The set of spent bank transaction ids now lives in `LPRegistry` (`usedBankTxId`,
`consumeBankTxId`), which both escrows already share; an escrow (current or retired, never anyone else) spends an id
on settlement, and a replay on either escrow reverts `ReceiptReplayed`. Both escrows keep a `usedBankTxId(bytes32)`
view that reads the registry. Pinned by `ReviewM1_Ramp.t.sol:test_M1_Fixed_*` (both orders, a grief attempt, a fuzz
over both escrows) and `LPRegistry.t.sol`.

**The mechanism.** `usedBankTxId` is a mapping on each escrow. One bank transaction id can therefore settle an order on
the Movva `FiatEscrow` and a sale on the Movva `OffRampEscrow`, when both name the same payee commitment and both
zkTLS sessions bind it.

**Impact.** Real harm needs an LP to reuse one salt across its offer and its own sale; the LP node salts afresh per
offer (`packages/lp-node/src/offers.ts:295-301`).

**Docs that say otherwise:**
- `FiatEscrow.sol:53` says the set "is global";
- `docs/security-review-phase2.md` ("Reviewed and cleared") says a receipt "settles exactly one order, ever".

**Repro (as reviewed):** `test_M1_OneBankTxIdSettlesAnOrderAndASale`, now inverted as `ReviewM1_Ramp.t.sol:test_M1_Fixed_OneBankTxIdCannotSettleAnOrderAndASale`.

**Recommendation.** One nullifier set shared by both escrows, for example in the registry, in a future version.
Correct the two claims now.

### SRM1-13 — A stale claim is free to renew
**Severity: low.** `OffRampEscrow.sol:24-27, :355-374, :378-389` (line numbers as reviewed). **Fixed (contracts).**
`cancelSale` also takes a sale whose claim is past `payBy` (releasing the LP's credit), and every claim that ends
unsettled with the sale still open (`releaseStaleClaim`, `abandonClaim`) starts a per-sale `CLAIM_COOLDOWN`
(30 minutes) in which nobody, the same LP or another identity, can claim it; the seller can cancel throughout. The header now says so
instead of pointing at `recordDispute`. Pinned by `ReviewM1_Ramp.t.sol:test_M1_Fixed_AnLPCannotRenewAStaleClaimToBlockCancel`
and `OffRampEscrow.t.sol` ("The seller can always cancel").

**The behaviour.** `releaseStaleClaim` records nothing, and `claimSale` has no cooldown. An LP that batches a release
with a re-claim keeps an EOA seller from ever reaching `cancelSale`, which needs OPEN. The seller's only exit is
`raiseDispute`, which takes 30 days without a desk.

The header claims repeated claiming "is what `recordDispute` is for", but nothing calls it there.

**Repro (as reviewed):** `test_M1_AnLPCanRenewAStaleClaimForeverAtNoCost`, now inverted as `ReviewM1_Ramp.t.sol:test_M1_Fixed_AnLPCannotRenewAStaleClaimToBlockCancel`.

**Recommendation.** Let the seller cancel a CLAIMED sale once `payBy` has passed, or record a strike and add a cooldown.

### SRM1-14 — Quorum votes cannot be withdrawn, and CIDs must match byte for byte
**Severity: low.** `AspRootQuorum.sol:95-125`. **Fixed (contracts).**

**Votes stand until the round advances.** `vote` has no unvote and no deadline; the round advances only when a root is
posted (`:120`). An ASP that voted for root X and then switched to X′ (say, after flagging a label) leaves its X vote
standing. A single other ASP can complete X at any later time in that round.

This stays inside the 2-of-3 trust model, since that ASP did once vote for X. But the header's guarantee "a minority of
ASPs can never post a root the others did not approve" holds only in the moment.

**CIDs must match exactly.** Proposals key on the exact CID string (`:96`). Honest ASPs that agree on the root but
encode the CID differently (v0 vs v1, different chunking) never reach a quorum.

**Repro:** `ReviewM1_Accounts.t.sol:test_Demo_AStaleVoteTheAspAbandonedStillCompletesAQuorum`.

**Recommendation.**
- **Now (operational):** fix a canonical CID procedure in the ASPs' runbook.
- **Next version:** `unvote(root, cid)` for the current round, or a vote deadline.

**Fix (contracts, after the review): both.** A vote counts only while it is LIVE: cast in the current round, not
withdrawn, and less than `VOTE_TTL` old. `VOTE_TTL` is an immutable constructor argument, 1 hour to 30 days
(`BadVoteTtl`); `deploy-movva-rail.ts` passes 3 days, which covers a weekend between two ASPs' approvals.
- `unvote(root, cid)` withdraws the caller's own live vote in the current round (`Unvoted`; `NotVoted` otherwise).
  No ASP can withdraw another's.
- `votedAt(proposal, asp)` replaces the vote counter. `votes(proposal)` and `hasVoted(proposal, asp)` keep their
  signatures and now count live votes only. A lapsed vote can be renewed by voting again; a live one still cannot be
  cast twice (`AlreadyVoted`).
- The vote that brings THRESHOLD distinct live votes for the exact root and CID together posts the root, as before.
  The core property holds, narrowed in time: 2 of 3 ASPs must each hold a live vote for exactly that root and CID at
  the moment of posting. The ASP set is bounded at 16 (`TooManyAsps`) because votes are counted by walking it.

**The canonical CID procedure** is code: `packages/ops/src/asp-cid.ts`. An ASP writes the set as a fixed UTF-8 document
(`movva-association-set/1`, the chain id, the Entrypoint, the root, the count, then each label as 0x + 64 lower-case hex
in insertion order; LF line ends, a final LF), and the CID is CIDv1, raw codec, sha2-256, base32 lower case: always
59 characters starting `bafkrei`. It is computed from the bytes, never read from an IPFS client, and the document is
pinned as one raw block. `associationSetCid(set, rootOf)` also refuses labels that do not rebuild the root with the
ASP's own tree. Honest ASPs therefore produce byte-identical CID strings. Tests: `packages/ops/test/asp-cid.test.ts`
(IPFS's own CIDs for two raw blocks, the exact document, two ASPs writing the same set differently, every change to
the set changing the CID, refusals).

Tests (contracts): `ReviewM1_Accounts.t.sol:test_Fixed_AStaleVoteTheAspAbandonedNoLongerCompletesAQuorum` (the repro,
inverted) and `test_Fixed_AVoteWithdrawnAtOnceNeverCountsEvenInsideTheTtl`. `AspRootQuorum.t.sol`, against the real
Entrypoint: unvote, its refusals (a stranger, nothing to withdraw, another ASP's vote, an earlier round, a lapsed
vote), expiry to the second and renewal, recasting, the exact root and CID live together, the constructor bounds, and
a fuzz of votes, withdrawals and waits against a model of live votes. Size: AspRootQuorum 2,691 bytes.

The contracts on Sepolia are immutable and keep the old code: the 6 October rail and the fork-rehearsed MOVVA-only rail are unchanged, and only a deployment from this code gets the fix. The deploy script's post-run check compares the recorded quorum's code with this build (SRM1-9), so a
`--verify` or `--finalize` of an existing Sepolia rail must run from a checkout of the code it was deployed with.

### SRM1-15 — The auditor does not check that an anchored head is a prefix of the attested chain
**Severity: low.** `packages/viewing-key/src/audit.ts:173-192`; `contracts/AuditGrantRegistry.sol:202-211`. **Fixed (wallet).**

**The gap.** `anchorChain` can only enforce that the count never decreases; it never sees the records. The auditor
compares an attestation with the anchor only when `att.count < anchor.count`, or when the counts are equal and the
heads differ.

When `att.count > anchor.count` it never checks that `recordHash(chain[anchor.count − 1]) == anchor.head`. A vault-mode
user can therefore rewrite records already anchored, append one more, and pass the anchor check. Pool reconciliation
backstops deposits from declared accounts, but not notes the escrow delivered.

**Recommendation.** Add the prefix check. Optionally check every historical `ChainAnchored` event, not only the
latest.

**Fix (wallet, after the review).** When `att.count > anchor.count`, `auditDisclosure` checks the received chain's head
at `anchor.count` against the anchored head. If they differ ("not a prefix of the attested chain"), or the anchored
records were not all received, the report is incomplete. Anchored heads are compared normalised (with or without
`0x`). Only the latest anchor is checked. Test: `packages/viewing-key/test/anchors.test.ts`, "rewritten and then
extended".

### SRM1-16 — The Sepolia paymaster's global cap is above its deposit
**Severity: low (configuration).** `docs/deployments.md`, "Task 2 — accounts, ownerless paymaster, viewing keys" (the address table and "The paymaster's policy"). **Fixed (tooling); Sepolia deposit top-up pending (human).**

The deployment has `MAX_COST_GLOBAL` = 0.2 ETH and a deposit of 0.1 ETH, so the cap that "bounds the drain" never
binds. Five free Sybil accounts sending two ops each at `MAX_COST_PER_OP` reserve the whole deposit in one window.
Every op then fails AA31 until someone tops up.

**Repro:** `ReviewM1_Accounts.t.sol:test_Demo_TenOpsInOneWindowReserveTheWholeDeployedDeposit`.

**Recommendation.** Fund at least k × `MAX_COST_GLOBAL` for the k windows you will pay for, or deploy with a lower cap.

**Fix (tooling, after the review).** k = 3. In any n windows' worth of time the paymaster pays at most (n + 2) ×
`MAX_COST_GLOBAL` (fixed-window alignment and the grace period each add one), so 3 × the cap is the least deposit at
which the cap, not the deposit, ends a worst-case burst inside one window's length. Fund (n + 2) × for n windows.
- `scripts/deploy-account-stack.ts` defaults `OWNERLESS_DEPOSIT_WEI` to 3 × `OWNERLESS_MAX_COST_GLOBAL` (0.6 ETH) and
  refuses less before anything runs, and again in preflight. `DeployAccountStack.s.sol` has the same default and a
  `require`.
- `--verify` fails a deployed paymaster whose deposit is under 3 × its `MAX_COST_GLOBAL()`, and prints the exact top-up
  as an `EntryPoint.depositTo(paymaster)` command.
- The ops monitor's `paymaster_global_cap` (packages/ops `checks.ts`) reads `MAX_COST_GLOBAL()` from the paymaster:
  warn under 3 × (`PAYMASTER_GLOBAL_CAP_WINDOWS`), fail under one cap. A paymaster without it (SponsorPaymaster) is ok.
  Test: `packages/ops/test/checks.test.ts`, "3 x MAX_COST_GLOBAL".

**Pending: the live deposit.** Read on Sepolia at block 11,940,224 (18 October 2026): deposit 0.089484605742290609 ETH
against 0.6 ETH needed. The top-up, 510,515,394,257,709,391 wei, is a human's to send (`docs/deployments.md`, "The
deposit must cover 3 × `MAX_COST_GLOBAL`"). Nothing was broadcast.

### SRM1-17 — Paymaster validation gas on Sepolia, and nothing in the app builds the ownerless paymasterData (known)
**Informational.** **Fixed (wallet; then app and co-signer, 18 October 2026).**

**Validation gas.** Sepolia charges ~105k gas per storage slot written from zero, and an account's first op writes up
to two. At 150k the first op failed AA33. The Task 2 and Task 3 scripts sign 300k
(`scripts/deploy-account-stack.ts:740-741`), but `packages/smart-account/examples/erc7562-ownerless.ts:74` still signs
200k. Too low a limit fails at simulation; the paymaster is never charged.

**No wallet default.** The wallet executors pass `paymasterAndData` through unchanged (`executor.ts:391`,
`kernel-executor.ts`), so nothing in the wallet sets the limit either.

**The app.** It expects a static, SponsorPaymaster-format `paymasterAndData` (`packages/app/src/lib/deployment.ts:65-66,
166`) and calls `sponsored(address)` (`packages/app/src/wallet/account.ts:209-213`), which `OwnerlessPaymaster` does
not have. The ownerless paymaster needs 91 bytes, with a per-account salt and a window that changes daily. Anything
else is AA33 `BadPaymasterData`.

**Recommendation.** Build the 91-byte data in the wallet (salt, `currentWindow()`, 300k on Sepolia, 100–200k on
standard pricing), and fix the example.

**Fix (wallet, after the review).** `packages/wallet/src/ownerless-paymaster.ts`; both executors; the app.
- **The data.** `ownerlessPaymasterAndData(config, account)` builds the 91 bytes for every operation: the factory index
  and CREATE2 salt from the account's own deployment, the window from the latest block's timestamp, and the
  validation gas per chain (`ownerlessVerificationGas`: 300k on Sepolia, measured; 200k on standard pricing). It refuses
  before anyone signs when the salt does not produce the sender.
- **The executors.** `paymasterAndData` on `SafeExecutor` and `KernelExecutor` takes fixed bytes, as before, or such a
  function, called per operation before the fees and the signature.
- **The app.** A deployment's `account.ownerlessPaymaster: { address }` replaces `paymasterAndData`. The account reads
  `WINDOW` and `MAX_COST_PER_OP` from the contract and fits the fees under the cap. It counts as sponsored when the
  contract's own `accountAddress(index, salt)` is the account, instead of calling `sponsored(address)`.
- **The example.** `erc7562-ownerless.ts` signs the wallet's figure for its chain instead of a hard-coded 200k.
  `deploy-account-stack.ts` reads its 300k from the wallet and encodes with the wallet's encoder.

Test: `packages/wallet/test/ownerless-paymaster-anvil.test.ts`. On anvil with Sepolia's chain id, the canonical
EntryPoint v0.7, Safe 1.4.1, Kernel v3.1 and `OwnerlessPaymaster` from the root build, the executors send:
- a fresh Safe's first operation (initCode, 0 wei) and a later one;
- a Kernel account's first and later operations.

All are sponsored, with `Sponsored` counted in the window the wallet named, and they carry Sepolia's 300k. A wrong
salt, the wrong factory index, a future window, a 24,999 postOp limit and a 90-byte value are each refused with the
contract's own error.

**Fixed, what that left open (18 October 2026).** Two things still stood between a user and this paymaster:

- **A fresh passkey account depended on a SponsorGate.** Its first operation needs its passkey signer (Safe) or the
  account itself (Kernel) on-chain beforehand, and only the co-signer's sponsorship module created them, only with
  `COSIGNER_SPONSOR_GATE`. Now the module runs without a gate (`COSIGNER_SPONSOR_OWNERLESS_PAYMASTER`): it creates them
  from its operator key under the same bounds, and allowlists nothing. Neither creation can ride in the first operation
  under ERC-7562 (OP-031, STO-022). docs/ownerless-paymaster.md, "Onboarding without a SponsorGate", gives the options
  weighed and the trade-off.
- **Sub-wallet sessions did not use the paymaster** (`SubWalletManager.availability`). Now a sub-wallet's account is the
  1-of-1 Safe of its own key, and so are its sale accounts. Each carries `ownerlessPaymasterAndData` from its first
  operation (`subWalletExecutor`, `openSoleOwnerSafe`). Sub-wallets are available wherever this paymaster is configured.

Tests:

- `packages/app/test/ownerless-onboarding-anvil.test.ts`, on anvil with the canonical contracts and the real co-signer
  service with no gate:
  - a fresh passkey Safe and a fresh passkey Kernel account are enrolled, readied, and their first and later operations
    are sponsored;
  - a sub-wallet's Safe and a sub-wallet sale account have their first operations sponsored.
- `packages/wallet/test/ownerless-paymaster-anvil.test.ts`: a sub-wallet's first and later operations are sponsored.
- `packages/cosigner/test/sponsorship.test.ts`: the module with no gate (what it sends, never a gate call, the daily cap
  over prepared accounts, the configuration).

The anvil test also caught an app bug, now fixed. A Kernel account, created by the co-signer before its first operation,
never got its recovery setup, because the app keyed that on the account having no code. It now keys on the Delay.

### SRM1-18 — Anonymity set of one on Sepolia (known)
**Informational; accepted as a stand-in.**

When Task 3 withdrew, the Movva pool held exactly one deposit (Task 1's). The proof hides which note was spent, but
there was only one, so the withdrawal is attributable by elimination. The Task 3 record says so
(`deployments/sepolia-task3-withdraw.json`, `privacy`).

This is a property of usage, not of the contracts. On mainnet the anonymity set is everyone whose deposit is in the
same ASP root. Timing, amounts (a 200-of-502 withdrawal to a fresh Safe, then a 199 MOVVA sale) and the
ShieldedNoteLog append pattern (SRM1-6) are linkage vectors the wallet must manage.

### SRM1-19 — The dormant savings path still answers previews
**Informational.** `MovvaReserve.sol:463-466` against `:664` (line numbers as reviewed). **Fixed (removed).** The savings
path was deleted after the review, per client decision D1 (14 October 2026): `MovvaReserve` has neither
`previewDistribute` nor `distribute`, nor `savings`/`setSavings`, so there is no preview left to disagree with anything.
The repro is now `ReviewM1_Movva.t.sol:test_M1_3_FixedByRemoval_NoPreviewAndNoDistribution`, which asserts that the
removed selectors are not there.

`previewDistribute` returns a positive amount while `distribute` reverts `NoSavings`. `IMovvaReserve` documents zero
"when there is nothing to distribute". It misleads only off-chain readers, such as the distribution keeper, which
M1 does not run.

**Repro (as reviewed):** `ReviewM1_Movva.t.sol:test_M1_3_PreviewDistributeReportsAMintThatDistributeRefuses`, now
`test_M1_3_FixedByRemoval_NoPreviewAndNoDistribution`.

**Recommendation.** Remove the savings path with sMovva in the later removal phase. *(Done, 15 October 2026.)*

### SRM1-20 — Before finalize, the governor can freeze redemptions instantly
**Informational; moot after `--finalize`.** `MovvaReserve.sol:683-688, :767-773`. **Fixed (contracts).**

**Two instant levers.**
- Lowering a max age is classed as risk-reducing, so it is instant. A max age of 1 second makes every redeem revert
  `StaleLeg`, and undoing it waits out the delay.
- Removing every gateway is also instant.

Both contradict "The guardian cannot pause redemptions; nobody can" (`:100-101`).

**Repro:** `ReviewM1_Movva.t.sol:test_M1_4_TheGovernorCanFreezeRedemptionsInstantlyBeforeFinalize`.

**Recommendation.** Reword the claim; optionally add a lower bound on max ages.

**Fix (contracts, after the review): both.** `_setOracle`, which the constructor and `setOracle` share, refuses a
USDT/USD max age under `MIN_USDT_USD_MAX_AGE` (1 day, the Chainlink feed's heartbeat) and an FX max age under
`MIN_FX_MAX_AGE` (15 minutes: Pyth is pull-based and anyone may post a price), `BadMaxAge`, on the instant and the
scheduled path alike. Tightening to the floors stays instant and leaves a healthy leg fresh, so the 1-second lever is
gone. `DeployMovva` refuses the same values before anything is sent. The prose (`MovvaReserve`'s header, now "Who can
stop a redemption"; `IMovvaReserve.mintPaused`; `pauseMint`; `docs/movva.md`, "Governance") now says exactly what is
true:
- before `--finalize`, the governor can stop redemptions instantly by removing every gateway (removing one is
  instant because that is how a compromised gateway is cut off), and `PythFxOracle`'s own governor can still tighten
  its own limits instantly (`contracts/ramp`, not changed here);
- after `--finalize` no key can stop a redemption; the breaker, a stale or out-of-bounds leg, the asset issuer's
  freezes and the yield vault's liquidity still can, with no key.

Tests: `ReviewM1_Movva.t.sol:test_M1_4_Fixed_AMaxAgeCanNoLongerFreezeRedemptions` (the repro, inverted; removing
every gateway still stops redemptions before finalize), `MovvaReserve.t.sol:test_MaxAgesHaveFloorsOnEveryPath` and
`testFuzz_NoMaxAgeUnderItsFloorIsEverStored`. MovvaReserve with every fix in this pass: 21,268 bytes, 3,308 under
EIP-170 (299 more than before).

The contracts on Sepolia are immutable and keep the old code: the 6 October rail and the fork-rehearsed MOVVA-only rail are unchanged, and only a deployment from this code gets the fix.

### SRM1-21 — Smaller observations and prose that is wrong
**Informational.** **Fixed (contracts, tooling and prose), item by item below; the stand-in USDT is accepted.**

**MovvaReserve**
- **A frozen gateway can still redeem.** `redeem` checks only that `to` is not frozen (`:533`), not `msg.sender`. A
  Tether-blacklisted gateway can redeem to another address, which is a compliance exposure that could lead Tether to
  freeze the reserve. *Fixed (contracts, after the review):* `redeem` also refuses a frozen `msg.sender`
  (`FrozenByAssetIssuer`, the reserve's own freeze check). Tests: `test_AFrozenGatewayCannotRedeemToAnotherAddress`,
  and `MovvaInvariant`'s gateway freezes.
- **The constructor does not bound `HEDGE_QUEUE_DELAY`** (`:316`). At 0, the queue would be an instant bypass of the
  daily limit. DeployMovva bounds it to 1 hour–30 days and asserts it (`:214-217, :432`); only a hand-rolled deployment
  is exposed. *Fixed (contracts, after the review):* the constructor enforces the same 1 hour–30 days
  (`BadHedgeQueueDelay`). Test: `test_TheConstructorBoundsTheHedgeQueueDelay`.
- **The USDT/USD leg has no sanity bound of its own** (`:355-360`); only the FX leg is bounded. *Fixed (contracts,
  after the review):* the leg must read US$ 0.50 to 1.50 (`MIN_USDT_USD_BPS`, `MAX_USDT_USD_BPS`), in any feed
  decimals, or every pricing action reverts `UsdtUsdOutOfRange`. The band catches a feed that is not a dollar
  stablecoin's (ETH/USD, BRL/USD, an inverted pair, a unit slip) and nothing a stablecoin does short of collapse: the
  deepest depegs of USDT (about 0.85) and USDC (about 0.87) are priced as reported. The cost: below half a dollar
  minting and redeeming stop until the feed is back inside, which after finalize nobody can change. DeployMovva checks
  the feed's current answer against it. Tests: `test_AUsdtUsdAnswerOutsideItsBandIsRefused`,
  `testFuzz_TheUsdtUsdBandIsExactlyHalfToOneAndAHalfDollars`, and `MovvaInvariant`'s pegs outside the band.

**FrostValidator and SchnorrVerifier**
- **`FrostValidator._checkKey` accepts a group key x in [N, P)** (`FrostValidator.sol:139-141`). `ecrecover` rejects
  r ≥ N, so such a key would brick that account's FROST validator. The probability is about 2^-128 for a random DKG
  key. Fix: require x < N. *Fixed (contracts, after the review, `2d1f1de`):* `_checkKey` requires 0 < x < N; the test
  installs a real curve point with N < x < P and is refused.
- **`SchnorrVerifier.sol:6` claims RFC 9591 FROST(secp256k1, SHA-256).** Its H2 (`:83-92`) is a custom double-SHA-256
  wide reduction, not RFC 9591's `hash_to_field`. It is consistent with `packages/mpc` and sound in the random-oracle
  model, but it will not interoperate with other FROST implementations. Correct the claim. *Fixed (`2d1f1de`):* the
  header says the hash-to-scalar is our own and does not interoperate.
- **The 160-bit address comparison** in the `ecrecover` construction (`SchnorrVerifier.sol:136`) was re-examined. A
  fixed R needs about 2^160 work, and c depends on R, so there is no birthday shortcut. We agree with the header.

**OwnerlessPaymaster.** Its header (`:77-78`) says provenance pins "a proxy of a pinned implementation". It does not:
Safe's `setup` delegatecalls arbitrary code, and Kernel has `upgradeTo`. The paymaster's safety does not depend on it,
because cost is bounded by `maxCost`. Correct the wording. *Fixed (`54d5d8a`):* the header says provenance pins the
factory, not the account's code, and that the bound is `maxCost` and the limits.

**FiatEscrow.** `POOL` (`:203`, set at `:432`) is unused, because `rescueShielded` takes the pool as an argument. Its
NatSpec ("ragequit lives here") misleads. `ORACLE` is unused apart from the native-ETH listing (known). *Fixed
(`2d1f1de`):* the NatSpec calls `POOL` informational only; comment-only, the size is unchanged.

**Prose to correct**
- `docs/deployments.md`, "What remains, by necessity" says the postman "only it can renounce". `AspRootQuorum` has no path to `renounceRole`, so
  nobody can ever remove it. *Fixed (`2d1f1de`).*
- `docs/deployments.md`, "What remains, by necessity" lists the guardian as remaining. C2 superseded that. *Fixed (`2d1f1de`).*
- `AspRootQuorum.sol:37-38` says "private withdrawals stop for good". Deposits already in the last posted root keep
  withdrawing privately. *Fixed (contracts, after the review):* the header now says no new root is posted, deposits
  in the last posted root keep withdrawing privately, and later deposits leave by ragequit.

**Deploy tooling**
- The broadcast guard's `web3_clientVersion … .catch(() => '')` (`deploy-movva-rail.ts:1630`) lets a node that errors
  on that method through. The chain-id check is the primary guard. *Fixed (`2d1f1de`):* such a node is refused.
- A resumed finalize overwrites `privileges-before.json` with the partial state. Keep the first one. *Fixed
  (`2d1f1de`):* the first inventory is kept, and a resumed one is written beside it.

**The Sepolia stand-in USDT (`TetherLike`)** is fully permissionless (`contracts/test/ERC4626Adapter.t.sol:34-72`).
Anyone can blacklist the reserve, the gateway or the hedge treasury, pause it, or switch on a transfer fee. Intake then
halts with `TransferFeeCharged`. That is accepted as a stand-in (`docs/deployments.md`, "Substitutions (rehearsal only)"), but the demo's
availability depends on nobody doing it. *Accepted as a stand-in; no change.*

### SRM1-22 — The escrows accept only ECDSA rulings, so a Safe multisig cannot arbitrate
**Severity: medium (custody design gap; a client decision).** `contracts/ramp/RulingLib.sol:130-137`, reached from
`FiatEscrow._admitRuling` (`FiatEscrow.sol:905`) and `OffRampEscrow._admitRuling` (`OffRampEscrow.sol:531`). **Fixed (contracts).**

**The mechanism.** `RulingLib._recover` accepts only a 65-byte signature, refuses high-s, and recovers the signer with
`ecrecover`. The escrows then require that address to be a registered arbitrator. There is no EIP-1271 path. A contract
arbitrator, such as the client-approved 2-of-3 Safe, has no key. Its approval (`isValidSignature` returns
`0x1626ba7e`) is not a 65-byte ECDSA signature, so it is rejected as `MalformedSignature` before the arbitrator check.

**Proven on the deployed bytecode.** `scripts/custody-rehearsal.ts` (commit `26d345d`) checked it read-only on all
four escrows of the 6 October rail. It ran `resolveDispute` as an `eth_call` against a dispute that exists only as a
state override:
- the test arbitrator's ruling is admitted;
- the Safe's 2-of-3 ruling is rejected (`MalformedSignature`);
- a single Safe signer is rejected (`NotArbitrator`).

On a fork it also played the full rotation: schedule the add, wait 48 hours, execute. The registered Safe still could
not rule. Removing the test key would have left nobody able to RELEASE, leaving only `expireDispute`'s refund after
30 days. So the rehearsal keeps the arbitrator on its test key.

**Impact.** The custody model the client approved cannot be applied to the one role whose compromise drains the book
(SRM1-2). It cannot be changed in place either: the escrows are not upgradeable, and after `--finalize` the arbitrator
set is fixed for ever. Whatever key rules on the day of finalization rules for the life of the rail. That makes SRM1-2
and SRM1-3 depend entirely on how that key is held.

**Recommendation.** Before finalizing, the client chooses one of:
1. **New escrows that verify EIP-1271 rulings.** `SignatureChecker.isValidSignatureNow` against the registered
   arbitrator, with the same EIP-712 digest, keeping the low-s rule for EOAs. Then register the Safe. This is a code
   change, a redeploy of the Movva pair, a review of the new verification path, and a migration of LP offers.
2. **An interim ECDSA arbitrator key in a KMS/HSM**, ideally two, held apart (SRM1-2), registered through the delayed
   `setArbitrator` before finalize. This needs no code change. The key's custody, signing policy and audit trail then
   carry the whole dispute path.

Either way, `--finalize` should refuse while the only arbitrator is a seed-derived test key (SRM1-1).

**Fix (contracts, after the review): option 1.** `RulingLib._recover` keeps the ECDSA path unchanged for a 65-byte
signature. Any other length is a contract arbitrator's, encoded `abi.encodePacked(arbitrator, signature)`:
`_contractSigner` refuses a name with no code (`MalformedSignature`), STATICCALLs
`isValidSignature(digest, signature)`, and accepts only a return of at least 32 bytes starting with `0x1626ba7e`
(otherwise `ContractSignatureRejected(arbitrator)`). The escrows then apply exactly the checks a key gets:
`arbitratorSince` (a named but unregistered contract is `NotArbitrator`), `ArbitratorNewerThanDispute` for a RELEASE,
the posted-ruling digest, `RULING_DELAY`, revocation voiding a posted ruling. The digest is unchanged, so a ruling is
bound to its escrow and chain for a Safe as for a key. A Safe's signatures are 65 bytes per owner, so its encoding
(20 + 65k) can never be read as a key's. `SignatureChecker` was not used, to keep the EOA rule (65 bytes, low s) exact
and FiatEscrow under EIP-170 (24,352 bytes, 224 to spare).

What it rests on: a contract arbitrator is as strong as its own validation. The Safe's is its 2-of-3 owner threshold,
checked by its CompatibilityFallbackHandler over the SafeMessage hash of the ruling digest. A contract that approves
everything would approve every ruling, and registering any arbitrator still waits out `GOVERNANCE_DELAY` in public.

Tests:
- `FiatEscrow.t.sol` and `OffRampEscrow.t.sol`, against a 2-of-3 stand-in: two owners rule; one owner, a repeated
  owner, an owner's own key, a flipped outcome and another escrow's approval are refused; an unregistered or
  code-less name, a reverting validator, a short return and the legacy magic value are refused; a multisig newer than
  the dispute can only REFUND; revoking it voids its posted ruling.
- `RulingLib.t.sol`: every other length without a contract is still `MalformedSignature`.
- `ContractArbitratorFork.t.sol`: a real Safe 1.4.1 2-of-3 from the canonical factory, singleton and fallback handler,
  on a Sepolia fork. Its owners' SafeMessage signatures RELEASE a disputed order; one owner is refused.
- `packages/ramp/test/disputes.test.ts`: the offline SafeMessage hash equals the deployed arbitrator Safe's
  `getMessageHash`, and approvals are assembled sorted by owner.

**Deployment.** `scripts/redeploy-escrows.ts` with `contracts/script/DeployEscrowPair.s.sol`:
1. deploys a pair configured from the live pair's own state, with the Safe as its only arbitrator;
2. schedules `LPRegistry.setEscrow` for it;
3. after 48 hours, activates it and retires the old pair. Retiring is instant, and the old pair's open orders still
   settle.

The custody rehearsal then proves, on that pair, that the Safe rules and the test key does not.

### SRM1-23 — Finalize retires the guardian that the custody plan has just moved to a Safe
**Informational.** `scripts/deploy-movva-rail.ts:966-977`; `docs/deployments.md`, "Custody rotation rehearsal" and
"The MOVVA-only rail" (C2). **Fixed (docs)**, with the race closed by the SRM1-8 fix.

**The two documents disagree on the guardian's lifetime.**
- The custody plan's phase 1 rotates the reserve's guardian from its test key to a 2-of-3 Safe, and proves the Safe
  can `pauseMint`.
- `--finalize` (client decision C2) then sends the guardian to `0x…dEaD` before renouncing the reserve's governor. It
  refuses to renounce the governor otherwise, and refuses to finalize at all while minting is paused.

Both are consistent with the client's decisions: the Safe guardian exists only until finalization. But the custody
plan does not say so, and it changes the race in SRM1-8. Between finalize's read of `mintPaused` and its `setGuardian`
landing, any two of the Safe's three signers can pause minting. The run then renounces the governor with minting
paused, which is permanent. With a single test key that took one key; with the Safe it takes two signers acting in
that window. The window is the same.

**Recommendation.**
- State in the custody plan that the guardian Safe is pre-finalization only.
- Fix SRM1-8 before finalizing a rail with a Safe guardian: re-read `mintPaused` after `setGuardian` and immediately
  before the reserve's `transferGovernor`.
- Have the Safe's signers agree not to pause during the finalization window.

**Fix (docs, after the review).** `docs/deployments.md` now says, in the custody rotation section and in the `--finalize`
section, that the guardian Safe is pre-finalization only and that `--finalize` replaces it with `0x…dEaD` (C2), and
that a pause landing while `setGuardian` is in flight now stops finalize with the governor live (SRM1-8). The signers'
agreement not to pause during the window remains good practice; it is no longer what keeps a pause from becoming
permanent.

---

## 7. Tooling results

All runs were on this machine on 14 October 2026, at commit `9a554ed`. The other session's uncommitted files under
`packages/*` touch no Solidity. Raw outputs are in `docs/security-review-m1/` (section 12).

### 7.1 Invariant fuzzing

`FOUNDRY_OUT=<scratch>/review-out FOUNDRY_CACHE_PATH=<scratch>/review-cache $(bash scripts/foundry.sh path) test
--match-contract Invariant -vv` (Foundry v0.3.0, pinned).

**6 suites, 46 tests, 46 passed, 0 failed** (476 s). The 27 invariant functions:

| Suite | Invariants | Runs × calls | Result |
|---|---|---|---|
| `EscrowInvariant.t.sol:FiatEscrowInvariantTest` | every order settles at most once; escrow holds exactly its offers; offer locked = its open orders; credit matches offers; no bad receipt releases; no third address is paid | 256 × 200 | 6/6 hold |
| `EscrowInvariant.t.sol:OffRampEscrowInvariantTest` | every sale settles at most once; escrow holds exactly its open sales; credit matches live claims; no bad receipt settles; no third address is paid | 256 × 200 | 5/5 hold |
| `MovvaInvariant.t.sol` (supply reconciliation) | supply = minted − burned; supply moves only through mint/redeem/distribute; redeem ≤ min(par, ratio); withdrawToHedge never breaches the floor; ratios stay ordered; band ≤ R$ 1; distribute never at or below target | 128 × 200 | 7/7 hold |
| `MovvaBreaker.t.sol:HedgeQueueInvariantTest` | queued withdrawals pay exactly once, exactly to the recipient of record (+19 unit and fuzz tests in the suite) | 32 × 100 | 1/1 holds |
| `NodeRewardsInvariant.t.sol` | books add up and are backed; claims never exceed funding; no claim past its bounds; a failing hook never blocks a settlement; share/limit changes follow the delay | 64 × 120 | 5/5 hold |
| `SponsorGate.t.sol` (out of M1 scope, in the suite) | 3 | ~250 × 500 | 3/3 hold |

**What the invariant suites do not cover:**
- the escrow invariants run on mocks with ETH and a 6-decimal token, each escrow with its own registry. They do not
  exercise the zkTLS verifier, `rescueShielded`, the Movva-pair configuration, the post-renunciation state, a shared
  registry or bank-tx set across escrows, or adversarial arbitrators and dispute griefing (SRM1-2 to -4, -12);
- there is no stateful invariant for `OwnerlessPaymaster`. It has a fuzzed property over random Sybil bundles instead
  (`OwnerlessPaymasterPropertyTest`, passes);
- there is no stateful invariant for `AspRootQuorum`. It has a fuzz of "no root without a quorum" instead.

### 7.2 Full Foundry suite

`… forge test --no-match-contract Invariant` gave **79 suites, 844 tests, 844 passed, 0 failed, 0 skipped** (25 s).

**Caveat: 91 of the 844 pass vacuously.** These are the 13 fork suites (AaveUSDTFork, RampRescueFork, MovvaFork,
PasskeyRecoveryFork, PythFork, OracleFork, HyperCoreReadFork, IssuerFreezeFork, LidoAdapterFork, two UsdtRampFork
suites, YieldFork, SuperstateUSTBFork). They return early without `FORK_RPC` / `HYPEREVM_RPC`, and this machine's `.env`
has neither. So **753 tests actually ran**. The fork tests, including `RampRescueFork` (the escrow's rescue against a
real pool's label), were not exercised by this review.

The three new `ReviewM1_*.t.sol` files are not in that count. Run on their own (`--match-path
'contracts/test/ReviewM1_*.t.sol'`) they gave **17 passed, 0 failed**: 6 Movva, 7 ramp, 4 accounts.

Re-run with them present, the same command gave **83 suites, 861 tests, 861 passed** (844 + 17), after commit
`26d345d`, which touched only `scripts/` and `docs/`.

**None of the review's tests is a failing reproduction.** Each asserts the behaviour its finding documents, so it
passes on the current code, and `forge test --no-match-contract Invariant` stays green with them. A fix for a finding
will make its test FAIL. That is the signal to invert the test into a regression test, not to delete it. The
contracts are `ReviewM1MovvaTest`, `ReviewM1RampTest`, `ReviewM1_AccountsTest` and `ReviewM1_QuorumTest`; all match
`--no-match-contract 'ReviewM1'` if they need excluding.

The smart-account package's own Foundry project (`packages/smart-account/contracts`, including `FixturesTest` and
`KernelIntegration.t.sol`) was **not** run in this review.

### 7.3 Slither

Slither 0.11.6 (crytic-compile 0.4.2), solc 0.8.28, run one file at a time. The repo script fails on the pinned
Foundry's build-info.

```
PYTHONPATH=<pkgs> <pkgs>/bin/slither <file> --compile-force-framework solc \
  --solc /root/.local/share/svm/0.8.28/solc-0.8.28 \
  --solc-remaps "@openzeppelin/contracts/=node_modules/@openzeppelin/contracts/ forge-std/=lib/forge-std/src/" \
  --exclude-dependencies --filter-paths "lib/|node_modules/|test/|script/" --exclude pyth-unchecked-confidence
```

The pinned forge's directory was on PATH. For the smart-account modules the flags were those of
`scripts/slither-smart-account.sh`, without its `forge build`, with FrostValidator flattened.

**With the in-source suppressions honoured: 0 high, 0 medium** across all 19 files. That is 65 low (timestamp 36,
reentrancy-events 13, reentrancy-benign 12, calls-loop 4), 104 informational (naming-convention 57, low-level-calls 20,
assembly 16, costly-loop 5, cyclomatic-complexity 3, unindexed-event-address 2, too-many-digits 1) and 1 optimization.
ShieldedNoteLog, KernelAvatarAdapter and UserOpChallenge report nothing.

| File | H | M | L | I |
|---|---:|---:|---:|---:|
| AspRootQuorum | 0 | 0 | 1 | 3 |
| OwnerlessPaymaster | 0 | 0 | 1 | 12 |
| Movva | 0 | 0 | 0 | 1 |
| MovvaReserve | 0 | 0 | 10 | 13 (+1 opt) |
| ScaledFxBandOracle | 0 | 0 | 0 | 1 |
| FeeSplitter | 0 | 0 | 3 | 5 |
| DivergenceBreaker | 0 | 0 | 4 | 3 |
| FiatEscrow | 0 | 0 | 15 | 17 |
| OffRampEscrow | 0 | 0 | 13 | 12 |
| LPRegistry | 0 | 0 | 3 | 5 |
| ReclaimZkTlsVerifier | 0 | 0 | 3 | 11 |
| PythFxOracle | 0 | 0 | 6 | 4 |
| NodeRewards | 0 | 0 | 4 | 13 |
| AuditGrantRegistry | 0 | 0 | 2 | 0 |
| ShieldedNoteLog | 0 | 0 | 0 | 0 |
| PasskeyCoSignerValidator / FrostValidator (flattened) / KernelAvatarAdapter / UserOpChallenge | 0 | 0 | 0 | 2 / 2 / 0 / 0 |

**The suppressed findings, triaged on their merits.** Zero medium/high only means something if the suppressions are
right, so Slither was re-run with `--show-ignored-findings`. That surfaces **5 high and 25 medium** that the in-source
`slither-disable` comments hide. One of the mediums is in the out-of-scope `ChainlinkBrlOracle`, pulled in by import.
Each was re-read at the site. **None is a true positive:**

| Detector (count) | Site | Verdict |
|---|---|---|
| reentrancy-balance, high (3) | `MovvaReserve.mint` `:502`, `withdrawToHedge` `:576`, `executeHedgeWithdrawal` `:629` | **False positive.** All three are `nonReentrant`. The balance read after the call brackets exactly that intake or payment. The callee is the USDT token or the vault, which only a delayed governor change could set (none on M1, and none after finalize). `_pay` re-reads the ratio from state after paying. |
| arbitrary-send-eth, high (1) | `FiatEscrow._send` `:1239-1243` | **False positive.** The payee is always read from the order or offer record (taker-named recipient, LP of record, seller's refund address) and the amount is that record's. On the Movva pair, native ETH is delisted, so the path is unreachable. |
| reentrancy-eth, high (1), and reentrancy-no-eth, medium (1) | `FiatEscrow._deliver` `:1047-1103` | **False positive.** The write-after-call records the commitment the pool returns, which does not exist before the call. Both callers are `nonReentrant`. The callee is the upstream Entrypoint, a UUPS proxy whose implementation is fixed only once `OWNER_ROLE` is renounced or held by the timelock (itself `nonReentrant`), and the Movva pool pulls MOVVA, which has no transfer hooks. |
| incorrect-equality (11) | `MovvaReserve` `:391, :512, :538, :867, :951`; `FiatEscrow` `:908, :1015`; `OffRampEscrow` `:534, :596`; `FeeSplitter` `:86`; `NodeRewards` `:461` | **False positive.** Each is a zero sentinel (`since == 0`, `amount == 0`, `total == 0`, "holds nothing") or a comparison of two booleans that Slither sees as derived from a timestamp. None compares a balance an attacker can steer to an exact value for profit. NodeRewards' strict `_holdsNothing` is deliberate: a donation only forces the delay. |
| unused-return (11) | `MovvaReserve` `:355, :807, :810, :956, :978`; `FiatEscrow` `:1092, :1150`; `FeeSplitter` `:96`; ChainlinkBrlOracle (out of scope) | **False positive.** The returns are re-read from balances (vault `deposit` / `withdraw` / `redeem`), are fields not needed (`latestRoundData`'s round ids; `assetConfig`'s fee fields), or are deliberately caught (`FeeSplitter`'s `try sync()`). |
| divide-before-multiply (2) | `FxMarketHours.monthDay` `:55, :58` | **False positive.** Hinnant's `civil_from_days` floors on purpose before each product. `FxMarketHoursTest.test_MonthAndDayAcrossLeapYears` pins it. |

The visible lows were read by class:
- **timestamp:** windows of minutes to days (pay windows, dispute timeouts, epochs, max ages); a proposer's skew is
  seconds.
- **reentrancy-benign / reentrancy-events:** events after calls to immutable or delayed callees, inside `nonReentrant`
  entry points.
- **calls-loop:** bounded (the breaker's sources; the escrows' fixed lists).

None changes an outcome. This agrees with `docs/security-tooling.md` §2.

### 7.4 Mythril

Mythril **v0.24.8** from its official image pinned by digest (`docker.io/mythril/myth@sha256:49e11758…`, the local
copy; the registry was unreachable), under podman, solc 0.8.28 with evmVersion Shanghai (the script's header explains
why: Mythril lacks MCOPY). Run through the repository's gate, `scripts/mythril.sh`, both modes, with the script's
defaults: source timeout 600 s, runtime 300 s, max depth 128, 2 transactions, create timeout 1,800 s, 2 GB per
analysis. Because the machine was loaded (6 cores, load 6-12), it ran **one job at a time** over the **in-scope set
only**: 14 contracts. The 13 out-of-scope contracts the script also knows (yield, adapters, sMovva, Sponsor*, the
other oracles) were not run.

```
MYTHRIL_JOBS=1 MYTHRIL_OUT=<scratch>/mythril-m1/reports bash scripts/mythril.sh MovvaReserve Movva OffRampEscrow \
  FiatEscrow OwnerlessPaymaster AspRootQuorum ScaledFxBandOracle FeeSplitter LPRegistry ReclaimZkTlsVerifier \
  PythFxOracle NodeRewards AuditGrantRegistry ShieldedNoteLog
```

Wall time: 20:48 to 00:09 (about 3 h 20 min).

**Gate result: 14 contracts × 2 modes, 43 findings, 0 not allowlisted, 0 analyses failed.** 10 allowlist entries
matched nothing in this run, which the gate reports and does not fail on: which paths a run reaches varies with
machine speed. One analysis (ReclaimZkTlsVerifier, source) produced no usable result in 600 s and was retried at 300 s, as
the script does. Coverage is of the runtime code, from Mythril's own coverage plugin. The gate's floor is 20% in
a contract's best mode.

| Contract | Source cov. | Runtime cov. | Findings (source / runtime) | Classes |
|---|---:|---:|---|---|
| MovvaReserve | 2.52% | 43.78% | 0 / 2 | SWC-123 (fallback), SWC-116 (`executeHedgeWithdrawal`) |
| Movva | 86.20% | 92.03% | 1 / 1 | SWC-116 (OpenZeppelin `permit` deadline) |
| OffRampEscrow | 37.15% | 46.49% | 0 / 5 | SWC-123 (fallback), SWC-116 ×4 (claim, settle, stale-claim, dispute windows) |
| FiatEscrow | 29.67% | 43.83% | 0 / 4 | SWC-116 ×4 (release, boleto, reclaim, dispute windows) |
| OwnerlessPaymaster | 60.66% | 59.25% | 0 / 3 | SWC-123 ×3 (the EntryPoint calls at address 0) |
| AspRootQuorum | not explored (allowlisted) | 98.70% | – / 0 | none |
| ScaledFxBandOracle | 91.12% | 57.48% | 1 / 1 | SWC-113 (BandRead's two reads), SWC-123 (fallback) |
| FeeSplitter | 63.73% | 79.14% | 0 / 5 | SWC-123 ×2, SWC-116 ×3 (DelayedGovernance windows) |
| LPRegistry | 55.10% | 64.73% | 0 / 7 | SWC-101 ×7 (enum/zero equality compiled as subtraction) |
| ReclaimZkTlsVerifier | not explored (allowlisted) | 27.79% | – / 0 | none |
| PythFxOracle | 61.71% | 58.60% | 0 / 7 | SWC-123 (fallback), SWC-116 ×6 (`FxMarketHours.inCoreSession`) |
| NodeRewards | 36.62% | 61.38% | 0 / 3 | SWC-123 (fallback), SWC-116 ×2 (epoch clock) |
| AuditGrantRegistry | 90.78% | 98.98% | 1 / 2 | SWC-116 (grant windows) |
| ShieldedNoteLog | 95.26% | 97.88% | 0 / 0 | none |

**Triage (none is a vulnerability).** Each class was re-read at its site against `scripts/mythril-allowlist.txt`:

- **SWC-116, timestamp dependence (25).** Every site is a window or a stamp in minutes to days:
  - the escrows' 30- and 45-minute pay windows, the boleto windows and the 30-day dispute timeout;
  - the 24-hour hedge queue;
  - the FX session edges (13:30 and 21:00 UTC);
  - NodeRewards' weekly epoch;
  - grant validity;
  - `permit` deadlines;
  - DelayedGovernance's days.

  A proposer's influence is seconds. The FX session edge is the closest call: a proposer can place a block a few
  seconds either side of 13:30 or 21:00 UTC. That changes only whether a band reads the last close or refuses, never
  what a value-moving path reads (section 5.2).
- **SWC-123, requirement violation (10).** Every instance is in the runtime mode, at the contract declaration or in
  a governance setter.
  - **Runtime code at address 0.** Runtime code carries zero immutables, and Mythril runs it at address 0. So a call to
    an immutable (the EntryPoint, oracle, registry or USDT) is a call to the contract itself, with a selector it does
    not have. For OwnerlessPaymaster the reported inputs are exactly `0x`, `addStake()` and `getDeposit()`.
  - **Setters reached through `execute`.** `DelayedGovernance.execute` bubbles the setter's own refusal (FeeSplitter
    `setLpRewardShare`).

  The source mode, where the constructor sets the immutables, reports none.
- **SWC-101, integer arithmetic (7, LPRegistry).** At `capOf` / `availableCents` (`LPRegistry.sol:353-363`) and
  `DelayedGovernance.cancel` (`:147`). Each is an `==` test on an enum or a zero sentinel that the optimizer compiles
  as a subtraction, whose result is only a JUMPI condition. Nothing is stored. The file contains `unchecked`, so the
  script leaves Mythril's overflow module on there.
- **SWC-113, multiple calls (1).** `BandRead` reads the two immutable sources; no caller-supplied address is involved.

**Coverage, honestly.**
- **MovvaReserve's source mode reached 2.52%.** The constructor deploys Movva and runs `_setOracle` over symbolic
  addresses, and little survives it. Its runtime mode reached 43.78%, which carries the contract over the floor.
- **AspRootQuorum and ReclaimZkTlsVerifier explored nothing in source mode.** Their constructors decode symbolic
  arrays. This is allowlisted as NOT EXPLORED, and their runtime modes cover them (98.70% and 27.79%).
- **The escrows' coverage (30-46%) leaves most of the dispute and ruling logic unexplored symbolically.** That is where
  SRM1-2 to -4 and -13 live. They were found by reading, not by Mythril.

Symbolic execution bounded at two transactions does not reach multi-step states such as lock → dispute → post →
execute in source mode. The runtime mode's arbitrary storage approximates them.

This matches the 19 September run in kind (`docs/security-tooling.md` §3: 119 findings over 27 contracts, all false
positives). The counts differ because only the in-scope 14 ran, and because exploration is time-bounded on a loaded
machine (§3.1 there).

### 7.5 Circomspect

Circomspect **0.9.0**, built for this review with `cargo install circomspect --version 0.9.0 --locked`, run by
`CIRCOMSPECT=<bin> bash scripts/circomspect.sh` over `protocol/circuits/circuits/*.circom`. All three templates were
analysed (CommitmentHasher, LeanIMTInclusionProof, Withdraw).

Result: **3 warnings, 0 not allowlisted.**
- CS0017 at `withdraw.circom:111` (`contextSquared` binds the public `context`);
- CS0018 at `withdraw.circom:100` (the new commitment's nullifier hash is deliberately discarded);
- CS0010 at `merkleTree.circom:50` (`Num2Bits(32)` cannot alias below 254 bits).

These are the same three as on 19 September, triaged in `docs/security-tooling.md` §4 and
`scripts/circomspect-allowlist.txt`. The circuits are upstream's and byte-identical (section 3).

### 7.6 Upstream checks

See section 3:
- **byte-identical:** Solidity (18 files) and circom (3 files);
- **11/11 artifacts hash-match**;
- **R1CS reproduce:** all three circuits;
- **audited unit suite:** 110/110;
- **not run:** the integration suite (no RPC), and the circuit and relayer suites.

---

## 8. Residual risks the client has explicitly accepted

These are decisions, not findings. They are listed so that the auditor, and anyone reading the finalized rail, sees
the whole price of Option A in one place. Sources: `docs/deployments.md` ("The MOVVA-only rail"; "Privileges, and `--finalize`"),
`docs/ownerless-paymaster.md`, `AspRootQuorum.sol:28-38`.

1. **No brakes after renunciation.** Nobody can:
   - revoke a leaked witness, attestor or arbitrator key (SRM1-2);
   - revoke a verifier or endpoint, delist an asset or lower a cap;
   - suspend an LP or open Phase B;
   - add or remove a gateway (if every gateway key is lost, nobody can redeem MOVVA again);
   - repoint the FX or USDT/USD leg;
   - withdraw the Entrypoint's vetting fees, which stay there for good;
   - raise a pool's relay-fee cap;
   - wind down a pool, including upstream's ETH pool;
   - upgrade the Entrypoint to take an upstream fix;
   - add real Reclaim witnesses or bank templates after the fact (SRM1-1).
2. **Minting can never be paused.** The guardian is renounced to `0x…dEaD`, and the governor with it. Redemptions could
   never be paused once setup was complete. Only the backing floor (100% for mint), the supply cap (1,000,000 MOVVA,
   fixed for ever), the oracle's freshness and, where deployed, the breaker stop minting.
3. **Losing the ASP quorum stops new private withdrawals, not exits.**
   - With two of three ASP keys lost, the last root is the latest root for ever. Notes already in it withdraw
     privately; later deposits can only ragequit.
   - Ragequit needs no root, but only the original depositor can call it. Notes the escrow delivered exit through
     `rescueShielded`.
   - Two colluding ASPs can censor, admit, or roll back the root.
4. **The ownerless paymaster: Sybil and availability.**
   - Anyone can spend the global budget early in a window and deny sponsorship until the next window.
   - A bundler that is the attacker keeps up to `MAX_COST_GLOBAL` per window as ETH.
   - Nobody can pause it, change its policy, or recover the 1 ETH stake. Changing the policy means a new paymaster and
     a new stake.
   - SRM1-5 and SRM1-16 make this worse than it needs to be on Sepolia.
5. **Oracle retirement is permanent.** If Pyth retires FX.USD/BRL, mint, redeem and the hedge path revert `StaleRate`
   for ever, and the escrows' band stops after `closedMaxAge`. Two cases are not named in the docs today; we suggest
   adding them to `docs/deployments.md`, "What finalizing costs":
   - a deprecated Chainlink USDT/USD proxy has the same effect;
   - so does a Pyth confidence interval that stays above the fixed `maxConfBps`.
6. **Off-hours.** Value moves only while the FX market is open, about 27% of the week. The band carries the last close
   for up to four days. A poster may choose among the updates signed since the last post (SRM-15).
7. **Dispute default.** An undecided dispute refunds the side that escrowed (`expireDispute`). SRM1-3 adds the case
   where a valid proof exists; fixed in the contracts after the review: a valid proof settles a disputed order or sale.
8. **Tether.** A freeze of the reserve, with no vault on M1, stops every redemption until Tether lifts it (SRM-4's
   vault mitigation does not exist on this rail). A freeze of the only gateway stops minting through it for ever.

---

## 9. Sepolia stand-ins and what mainnet needs instead

| Stand-in on Sepolia | Mainnet requirement | Notes |
|---|---|---|
| `TetherLike` stand-in USDT (anyone can mint, pause, blacklist) | Real USDT (`0xdAC1…1ec7`) | The reserve's intake refuses a transfer fee, and its freeze handling is SRM-4/SR2-22..29. The stand-in makes availability depend on nobody griefing it (SRM1-21) |
| Chainlink **USDC/USD** as the USD leg | Chainlink **USDT/USD** | The heartbeat is similar (~24 h); the reserve's `usdtUsdMaxAge` must match the mainnet feed |
| Pyth FX.USD/BRL posted by our script | Pyth FX.USD/BRL kept warm by Mova's Pyth keeper (permissionless) | Mainnet has no posted feed until the keeper posts (`docs/audit-scope.md:298-308`) |
| Test zkTLS witnesses `<seed>/witness/0..2` and illustrative bank templates | Reclaim's witnesses and per-bank templates, with an application credential | **Must be in place before finalizing the ramp** (SRM1-1); afterwards they cannot be added |
| One test arbitrator | At least two ECDSA keys (KMS/HSM) held by independent parties, or new EIP-1271-aware escrows for the client-approved Safe (SRM1-2, -3, -22) | The custody rehearsal (`26d345d`) moves the guardian, treasurer and hedge treasury to 2-of-3 Safes; the arbitrator, gateway, witnesses and LPs are planned, not rotated |
| One test LP/gateway with R$ 50,000 credit | Contracted institutional LPs and gateways, each with its own custody | The gateway set is fixed for ever after finalize |
| Test ASPs `<seed>/asp/0..2` (asp/0 stands for Movva) | Three independent ASP entities, confirmed by the client, with a canonical CID procedure (SRM1-14) | A real set means a new `AspRootQuorum`, granted before `--finalize` |
| Software P-256 key as the passkey | A device authenticator (WebAuthn), with PRF where the seed derives from it | The on-chain WebAuthn path is the real one; only the authenticator is simulated |
| The deployer as relayer and bundler (`EntryPoint.handleOps` from a script) | A public relayer (upstream's, fee-validated: three of its fee tests are empty `it.skip`s upstream, `docs/audit-scope.md:355-360`) and public ERC-7562 bundlers | The paymaster needs a stake every bundler accepts (Rundler: 1 ETH, ≥ 1 day; done) |
| Anonymity set of 1 | An anonymity set large enough that timing and amounts do not identify (SRM1-18) | |
| Wallet's fixed 1 gwei tip (fixed in the wallet after the review) | Network-derived tip with a ceiling (SRM1-5) | The live Task 2/3 ops were signed before the fix |
| `paymasterVerificationGasLimit` 300k (Sepolia pricing) | 100–200k on standard pricing; the wallet must compute it, not hard-code it (SRM1-17) | Fixed: the wallet picks it per chain (`ownerlessVerificationGas`) |
| No divergence breaker | A decision: breaker on with `HALTS_REDEEM=false`, or with a dead-source rule, or off (SRM1-7) | DeployMovva defaults to ON with `HALTS_REDEEM=true` and the dead-source rule (`MOVVA_BREAKER_DEAD_AFTER`, 30 days), fixed after the review |
| `deploy-movva-rail.ts` (Sepolia only, `:506`) | A mainnet path with the same finalize guards, SRM1-1/8/9/10 included (the Sepolia script has them since this review) | The runbook today is manual (`docs/runbook-mainnet-deploy.md`) |
| The live Task 1–3 runs on the **6 October rail** (not finalized, not MOVVA-only) | A MOVVA-only rail deployed fresh, with the quorum, then `--finalize` | Fork rehearsal only so far: 250 pass / 7 expected / 1 fail, the "commit is clean" check, because of an unrelated uncommitted file (`docs/deployments.md`, "The MOVVA-only rail", rehearsal table) |

---

## 10. What this review did not cover

- **Fork tests.** 91 tests in 13 suites returned early without an RPC (section 7.2), so no mainnet-fork behaviour was
  re-checked. That includes real USDT, Chainlink, Pyth, and the escrow rescue against a real pool.
- **The smart-account Foundry project's own suite**, including `FixturesTest`. It proves the vendored validator
  bytecode is the current build, and was not run.
- **Vendored bytecode at source level:** EntryPoint v0.7, Safe 1.4.1, Safe4337Module, the WebAuthn signer and FCL
  P-256 verifier, Kernel v3.1, Zodiac Delay. We relied on their known semantics, and on the code-hash checks against
  the fixtures in `docs/deployments.md`, "Already on Sepolia: checked, not deployed".
- **Live on-chain state.** No RPC call was made to Sepolia. Every statement about deployed state comes from the
  repository's records.
- **Off-chain components:**
  - the LP node, co-signer, arbitration desk, relayer, zap relayer, Pyth keeper and app;
  - `packages/mpc` (FROST and DKG), the first item in `docs/audit-scope.md`'s list;
  - `packages/viewing-key` beyond `audit.ts`'s anchor check.
- **Specific scripts and paths:** `deployment-record.ts` (bytecode and immutables matching); the boleto paths in
  depth.
- **Upstream's integration, circuit and relayer suites** were not re-run here (section 3).
- **Economic analysis** of the hedge (the 103% floor against BRL volatility) and of LP incentives.
- **Out-of-scope contracts** (section 2): sMovva in depth, yield, Hyperliquid, SponsorPaymaster/Gate, the other
  oracles.
- **No formal verification.** Mythril's symbolic execution is bounded by depth, transactions and time (section 7.4);
  it proves nothing.
- **The other session's uncommitted changes** under `packages/app`, `cosigner`, `movva` and `wallet` were not reviewed.
  Where a finding cites one of those paths, it cites the working tree at the time of this review.

---

## 11. Focus areas for the independent auditor

In the order we would spend the time:

1. **The finalized state as a whole**, because nothing can be fixed after it. Take the
   `--finalize` rehearsal's end state and try to move value with the keys that remain:
   - gateway, treasurer, arbitrator, witnesses, LP, ASPs;
   - permissionless callers: `executeHedgeWithdrawal`, `recapitalize`, `split`, `sync`, `finalize`.

   Check our claim that pending scheduled changes are dead (`DelayedGovernance.execute` is governor-only), and look for
   anything else that survives renunciation the way hedge requests do (SRM1-10).
2. **Disputes and rulings** in `FiatEscrow` / `OffRampEscrow`:
   - the ping-pong between rulings;
   - `ArbitratorNewerThanDispute`;
   - dispute-before-proof (SRM1-3);
   - the free-taker freeze (SRM1-4);
   - the stale-claim loop (SRM1-13);
   - whether two arbitrator keys actually bound a stolen one;
   - what a desk outage costs, with no governor.
   - if the client chooses EIP-1271-aware escrows (SRM1-22), the new contract-signer path: replay across escrows,
     a Safe's owner set changing between posting and executing a ruling, and `ArbitratorNewerThanDispute` for a
     contract arbitrator.
3. **`MovvaReserve` value paths:**
   - mint at exactly 100%;
   - redeem under partial backing;
   - the hedge bucket's refill arithmetic and the queue;
   - frozen-USDT accounting with no vault;
   - the strict/band split;
   - `PythFxOracle`'s session edges (13:30 and 21:00 UTC, weekends, 25 December, 1 January, leap years) and its
     confidence and exponent handling;
   - if a breaker will be deployed, its dead-source claims (SRM1-7, fixed after the review): `poke`, the withdrawal
     of claims by passing checks, the gas floor, and whether any sequence makes a live source look dead.
4. **`ReclaimZkTlsVerifier`:**
   - the JSON context reader (attacker-influenced input) and the identifier recomputation;
   - the URL-prefix host boundary;
   - cross-escrow receipt replay (SRM1-12);
   - the fields the contract does not check (epoch, owner, `timestampS`).
5. **`OwnerlessPaymaster` under ERC-7562:**
   - the window and grace binding;
   - the postOp charge bound against v0.7's real debit;
   - storage access under bundler simulation with Sepolia's pricing;
   - whether a fee cap (SRM1-5) can be added without breaking the bounds.
6. **`AspRootQuorum` with the Entrypoint:**
   - liveness and safety at 2-of-3;
   - root rollback;
   - stale votes (SRM1-14, fixed after the review: `unvote`, `VOTE_TTL`, live-vote counting);
   - that `latestRoot` is global across pools.
7. **Kernel modules.** `PasskeyCoSignerValidator`'s 2-of-2 is the only thing enforcing "no single party can spend" on
   Kernel (Kernel lets any installed validator authorise alone). Then `KernelAvatarAdapter`'s open fallback.
8. **The finalize tooling's guards** (SRM1-1, -8, -9, -10, fixed in tooling after this review). They are what stands
   between a mistaken configuration and a permanent one.
9. **Our integration with upstream:**
   - `rescueShielded` and label derivation (`ShieldedDepositLabel.lastLabel`, checked by the fork test we could not run
     here);
   - the escrow's shielded delivery;
   - the relay-fee cap after renunciation.
10. **The viewing key's completeness claims:** the change-note gap (SRM1-6) and the anchor prefix (SRM1-15). A report
    to a tax authority rests on them.

The off-chain cryptography (`packages/mpc`, `sealed-share.ts`, `seed-source.ts`) remains the top item in
`docs/audit-scope.md`. It is outside M1's on-chain scope, but not outside the product's.

---

## 12. Reproducing this review

```bash
S=<scratch dir>
FORGE=$(bash scripts/foundry.sh path)        # Foundry v0.3.0, pinned

# invariants and the full suite, in private build directories
FOUNDRY_OUT=$S/review-out FOUNDRY_CACHE_PATH=$S/review-cache $FORGE test --match-contract Invariant -vv
FOUNDRY_OUT=$S/review-out FOUNDRY_CACHE_PATH=$S/review-cache $FORGE test --no-match-contract Invariant
FOUNDRY_OUT=$S/review-out FOUNDRY_CACHE_PATH=$S/review-cache $FORGE test --match-path 'contracts/test/ReviewM1_*.t.sol' -vv

# Mythril, in-scope set, one job
MYTHRIL_JOBS=1 MYTHRIL_OUT=$S/mythril bash scripts/mythril.sh MovvaReserve Movva OffRampEscrow FiatEscrow \
  OwnerlessPaymaster AspRootQuorum ScaledFxBandOracle FeeSplitter LPRegistry ReclaimZkTlsVerifier PythFxOracle \
  NodeRewards AuditGrantRegistry ShieldedNoteLog

# Circomspect 0.9.0
CIRCOMSPECT=<path>/circomspect bash scripts/circomspect.sh

# upstream provenance: as scripts/verify-protocol.sh section 2, against a fresh clone at c312dcd58f;
# circuits: (cd protocol/circuits && node scripts/verify-artifacts.mjs); audited unit suite:
(cd protocol/contracts && FOUNDRY_OUT=$S/pp-out FOUNDRY_CACHE_PATH=$S/pp-cache $FORGE test --match-contract Unit --fuzz-seed 1)
```

**Raw outputs** (`docs/security-review-m1/`):
- `slither/`: the text report per file and `findings.json` (every detector result: impact, confidence, check,
  description), plus `ignored/` with the same for the run that shows suppressed findings. The full Slither JSON
  (with source maps, 16 MB) is not committed;
- `mythril/`: per contract and mode, the JSON reports, plus the gate's output (`gate.txt`), the header and timings.
  The verbose per-analysis logs (with bytecode) stay in the scratch directory;
- `forge/`: the invariant log (summary), the full-suite summary, the ReviewM1 run;
- `circomspect.log`;
- `upstream/`: provenance, the circuit reproduction, the unit-suite summary.
