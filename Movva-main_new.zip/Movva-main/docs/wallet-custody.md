# Wallet custody — keys, parties, failures, recovery

For engineers and an external auditor. It covers who holds which key, what each party can do
on its own, what each failure costs, and how recovery works. It also lists what nobody outside
this team has reviewed yet. Service-by-service availability is in
[availability.md](availability.md), and this document is the account-layer detail behind it.

The client requirement is *seedless self-custody wallets (ERC-4337 + passkey + MPC)* that
*reuse Safe/Kernel smart accounts*. The deployment invariant is *if any off-chain service dies
or is compromised, no user loses funds or access*.

## 1. What ships

| | Recommended production default | Option (single signature) |
|---|---|---|
| Account | Safe 1.4.1 + Safe4337Module 0.3.0 (ERC-4337, EntryPoint v0.7) | same |
| Owners | **2-of-2**: the passkey's `SafeWebAuthnSigner` + a server ECDSA key | **1-of-1**: `FrostSigner`, a 2-of-2 FROST group (device + server) |
| Device secret | none (the passkey signs on-chain) | the FROST share, **sealed under the passkey's PRF** |
| Recovery | Zodiac Delay 1.1.1 module; the passkey signer is its only module | same |
| Pool seed | passkey PRF **only**: without PRF there is no wallet (§2.1) | same |
| Audit status | account, owners and Delay are external audited contracts; see §8 for the one caveat | adds our unaudited `packages/mpc` and `SchnorrVerifier.sol` |

**Safe 2-of-2 is the default** until `packages/mpc` and `contracts/SchnorrVerifier.sol` have been
externally audited. FROST is for the case where one indistinguishable on-chain signature becomes
a product requirement. Both configurations use the same recovery module.

A **Kernel v3.1** account (ZeroDev) offers both configurations too. It uses the same passkey
verifier, the same FROST verifier and the same Zodiac Delay recovery module, and adds two validators
and an adapter of our own. §10 goes through the requirements of this document one by one and states
where Kernel meets them and where it does not. The Safe remains the recommended account: on Kernel the
2-of-2 rule itself is unaudited code of ours (§10.3).

## 2. The key tree

```
                        ┌──────────────── passkey (WebAuthn credential; platform-synced) ────────────────┐
                        │                                                                                │
         P-256 signing key (never leaves the authenticator)                    PRF secret (never leaves it)
                        │                                                                                │
         SafeWebAuthnSigner(x, y, FCL verifier)                 ┌────────────────────────┴───────────────────┐
           ├─ Safe owner #1 (2-of-2 config)                     │                                            │
           └─ the ONLY module of the Delay (both configs)  PRF(POOL_SEED_SALT)                        PRF(SHARE_SEAL_SALT)
                                                                │ HMAC "PP/v1/seed"                          │ HKDF "PP/v1/frost-share-seal"
                                                           pool seed                                    seal key (XChaCha20-Poly1305)
                                                           ├─ PP/v1/spend → nullifier/secret per note        │
                                                           ├─ PP/v1/view  → audit viewing keys          sealed FROST device share
                                                           └─ PP/v1/ident                                (FROST config only)

server
  ├─ ECDSA key → Safe owner #2 (2-of-2 config)
  └─ FROST share #2 (FROST config; from the DKG, never knew the group secret)

FROST config:  DKG(device, server) → group key Y → FrostSigner(Y) → Safe's only owner

no PRF:  no wallet. The app refuses to create or open one (§2.1).
```

What the device stores: the credential id and the passkey's public key, which are not secret, and the app's records,
sealed under a key derived from the seed (packages/app/src/wallet/stores.ts). In the FROST configuration it also
stores the sealed share. Nothing on the device yields the seed without a user-verified PRF assertion.

What keeps these separate:

- **The pool seed and the seal key use two PRF salts.** The authenticator therefore returns
  unrelated values, and each is fed through a different KDF label. Neither yields the other
  (`sealed-share.test.ts` performs the mistake of opening with the pool-seed output). A browser
  evaluates both in one assertion with `prf.eval.first` and `prf.eval.second`.
- **Signing uses the P-256 key and never the PRF.** The passkey authorises a `SafeOp` (EIP-712,
  domain `Safe4337Module`) and a Delay `ModuleTx` (EIP-712, domain = the Delay proxy). The two
  domains differ, so an assertion over one cannot be replayed as the other.
- **DKG shares are generated jointly.** No party, including the server, ever computes the
  group secret (§5).

### 2.1 No PRF, no wallet (audit H-03, 21 October 2026)

The app used to offer a recovery-code path to browsers without PRF, built on
`RecoverableSplitSeedSource`. Its implementation did not deliver the 2-of-3 property this document
described:

- the device share was plaintext hex in `localStorage`;
- the server share was released by a bare GET keyed by the 4-byte wallet tag, with no
  authentication. That tag is also inside every share and inside the recovery code;
- so the browser profile alone opened the wallet (device share plus a GET), and so did the recovery
  code alone (code plus a GET);
- and the seed derived the smart account's owner key, so that one factor could spend, veto
  recovery and withdraw the shielded notes.

The path was removed for mainnet rather than repaired. **Creating or unlocking a wallet requires a
passkey with PRF.** A browser that reports no PRF (`getClientCapabilities`) is told, before any
passkey is created, to use another browser or device. A registration or assertion without PRF output
opens nothing and stores nothing. There is no fallback. The app has no share server, no device share
and no seed-derived owner. The dev stack serves no `/api/shares`. Wallets the old path created exist
only on Sepolia and local stacks. Onboarding tells their owners that this version does not open
them, tells them to move any test balance with an earlier build and their code, and offers to delete
the plaintext share. `packages/app/test/seed.test.ts` keeps the path out of the app's source.

`RecoverableSplitSeedSource` and its tests remain in `packages/smart-account` as library code, and no
shipped app uses them. Re-enabling a non-PRF path would require all of the following. The server
share is released only after a second, independent factor is verified, and never by tag alone. The
device share is held in non-extractable storage, or sealed. The account's owner is never derived
from the seed. Until then, the "Non-PRF user" cases this document used to list do not apply.

## 3. What each party can do alone

| Party | Can | Cannot |
|---|---|---|
| **Passkey holder** (user-verified assertions) | Queue any Safe transaction on the Delay; after the cooldown anyone executes it. Derive the pool seed (every wallet: PRF is required) and so **withdraw ASP-approved shielded notes privately, at once**. | Spend from the Safe immediately. Veto. Shorten the cooldown, except through a queued transaction that itself waits out the cooldown. |
| **Server** (its key or FROST share) | Refuse to co-sign. Relay anything anyone signed. Execute a queued transaction once its cooldown has passed, which only does what the passkey queued. | Sign a Safe transaction (2-of-2, or 2-of-2 FROST). Queue on the Delay: it is not a module, and it cannot forge a P-256 assertion. Veto or reconfigure the Delay: its owner is the Safe. Execute early. Execute anything other than what was queued. Read the FROST device share: it is sealed. Derive the pool seed: it holds no part of it. |
| **Device storage without the passkey** (a copied browser profile) | Learn the credential id and the passkey's public key, which are public on-chain once the account is used. | Open the wallet, read the sealed records, open the sealed FROST share or sign: each needs a user-verified assertion of the passkey. |
| **Anyone with gas** | Relay a signed queue request. Execute a queued transaction after its cooldown. Call `skipExpired`. | Anything not signed by the passkey. |
| **Safe owners together** (passkey + server) | Everything, including `setTxNonce` (the veto) and disabling or reconfiguring the Delay. | — |

Every "cannot" in the server row is performed as an attack in
`contracts/test/PasskeyRecoveryFork.t.sol`, against real Safe 1.4.1, Safe4337Module,
SafeWebAuthnSigner and Delay 1.1.1 on mainnet state.

## 4. Recovery: the flow and its cooldown

```
 t = 0        passkey signs ModuleTx(execTransactionFromModule(to, value, data, CALL), salt)
              any address relays it                 → Delay emits TransactionAdded   (~330-360k gas)
 0 … 7d       executeNextTx reverts "Transaction is still in cooldown"
              the owners (passkey + server) may setTxNonce(queueNonce) to skip it   ← the veto
 7d … 14d     ANYONE calls executeNextTx(to, value, data, CALL)                     (~72k gas for an exit)
              the Delay calls Safe.execTransactionFromModule → the call runs AS THE SAFE
 > 14d        not executed: expired; anyone calls skipExpired to clear the head of the queue
```

`src/recovery.ts` builds each step. The helpers are `encodeRecoverySetup`, `buildQueueRequest`,
`encodeSignedQueue`, `encodeExecuteNextTx`, `encodeVeto`, `readRecoveryQueue` and
`parseTransactionAdded`. `examples/passkey-recovery.ts` runs them against the deployed bytecode.

**What gets queued when the server is gone:**

- `PrivacyPool.ragequit(...)`, for deposits the ASP never approved.
- `FiatEscrow.rescueShielded` (and, until savings was removed by client decision D1 on 14 October 2026,
  `ShieldedYieldRouter.rescue`). Each requires `msg.sender == recipient`, and the Delay's call comes from the Safe.
- A transfer of the Safe's own balance.
- **`swapOwner(prev, deadServer, newServer)`**. After it executes, the account is a normal 2-of-2
  again with a new co-signer, so access is restored rather than just funds. The fork test does
  this and then spends with the new pair.

**Installation.** Recovery must be installed while both owners are available. Install it at
account creation: `encodeRecoverySetup` batches deploying the Delay proxy, enabling it on the Safe
and enabling the passkey signer on the Delay into one UserOperation. The example bundles that with
the Safe's own deployment for 923k gas. A Safe created without the module has none of the
guarantees in this section.

**Parameters, which are product decisions set to conservative defaults:**

- **Cooldown: 7 days, with a minimum of 3 days enforced by the helpers.** It must exceed the
  time a user or the monitor needs to notice a queued transaction.
- **Expiration: 7 days, never 0.** The Delay executes strictly in order, and a queued call that
  reverts cannot be executed, so it blocks the queue. With a server available the owners would
  skip it; recovery exists for when the server is not. Once the call expires, anyone can skip
  it. The fork test performs this case. The cost is that a failed attempt delays recovery by up
  to one more window.

**Gas.** Neither step can be paid from the Safe's balance without the server, and the
`SponsorPaymaster` is our service. The relayer and the executor are "any address with ETH". That
can be the user's own fresh EOA or a third-party relayer. A ragequit is public anyway (see
availability.md).

**What to monitor.** The event is `TransactionAdded(uint256 indexed queueNonce, bytes32 indexed
txHash, address to, uint256 value, bytes data, uint8 operation)`, topic0
`0x4c8a9c748e976c17c2eb2c2bc50da76eac9cd90ff529f0fe900e0c10a179f031`, emitted by each user's
Delay proxy. Only the passkey can cause it, so any occurrence the user did not start is a passkey
compromise, and it is visible for the full cooldown. On an alarm, notify the user and ask them to
veto. The veto is a 2-of-2 Safe transaction that calls `setTxNonce(queueNonce)` and emits
`TxNonceSet(uint256)`. Also watch the Safe's module and owner events: `DisabledModule`,
`AddedOwner`, `RemovedOwner`, `ChangedThreshold`. The wallet UI should show `readRecoveryQueue`
on every open, so a dead monitor does not mean nobody looks. The co-signer's recovery-alert
watcher (§11.2) follows this event for every enrolled account and pushes an alert to the user's
devices until the transaction is vetoed, executed or expires; its progress is
`mova_cosigner_recovery_watch_block` on the co-signer's `/metrics`.

## 5. The MPC path: DKG and the sealed share

**DKG** (`packages/mpc/src/dkg.ts`) is the FROST paper's PedPoP. Each party samples a
polynomial of degree t-1. It broadcasts Feldman commitments and a Schnorr proof of possession of
its constant term, bound to its identifier and to a session id. The session id commits to a
fresh context string, the threshold and the participant set. Each party then sends every other
party its evaluation privately. Each recipient checks every proof and every share, and a
failure names each culprit. The group key is a sum of commitments, which are points. The secret
behind it is a sum of scalars that no function computes: the dealer is gone from `src/`, and
`dkg.test.ts` asserts that nothing exported can return a group secret and that no scalar any
party sees is it.

The tests also perform broadcast **equivocation**: one party shows different commitments to
different peers, each set internally valid. Without the transcript hash carried in round 2,
two honest parties would each finish with a different group key.

**The transport** (`packages/mpc/src/dkg-transport.ts`, and `/v1/frost/dkg/*` in
`packages/cosigner`). The protocol above needs an authenticated broadcast for round 1 and an
authenticated, encrypted channel for round 2, because `DkgShareMessage.share` is a secret and a
man in the middle on an unauthenticated channel is simply a participant. `DkgSession` is that
channel, and it is what lets a browser and the co-signer generate a key at all.

*Authenticated.* Every message is signed by its sender's long-term key over
`SHA256(DST || version || round || session id || from || to || transcript || SHA256(payload))`.
The co-signer signs with the ECDSA key its accounts already name on-chain, which the device
checks by recovery against the address in `GET /v1/info`; the device signs with a per-run key
that one user-verified passkey assertion authorises at `start`. The scheme is injectable
(`DkgAuth`), and a message is verified only under the key the run was **given** for that party,
never one the message names.

*The transcript* binds the session id (and so the context, threshold and participant set), every
party's long-term public key, and every party's whole round-1 payload - commitments, proof of
possession and X25519 key. So: a message cannot be replayed into a run with other parameters or
other participants; a party showing different commitments to different peers gives them different
transcripts and round 2 aborts naming it; and no peer can be steered onto an encryption key the
others never saw. Round 2 and round 3 carry that hash and sign it, so the two halves cannot be
shown different runs. The DKG's own transcript travels inside the sealed round-2 payload and
`dkgFinalize` checks it as well - two independent equivocation checks.

*Encrypted.* Only round 2, the only secret: a fresh X25519 ephemeral to the recipient's round-1
key, HKDF-SHA256 to a one-message key, XChaCha20-Poly1305 with the envelope as associated data.
The server never sees the device's share and the device never sees the server's.

*Refused, by aborting and naming the party:* a session id used twice, a message replayed, a
second message from one party in a round, a round out of order, a message from another run or
addressed to another party, a signature that does not verify, a payload of the wrong shape, a
different transcript, a ciphertext that does not open, and anything `dkg.ts` itself rejects. A
failed session is dead: a failed DKG is abandoned, never retried with the same polynomial.

*On the server side* the run is keyed by `chainId:passkeySigner` - a FROST account has no address
until the group key exists, because the address commits to the key, so the run is named by the
passkey that will be the account's recovery signer. One completed run per such reference; a
second is refused. A run that reached round 2 leaves the server's share stored but **not
complete**, and an incomplete share never signs, so a device that walks away mid-run leaves
nothing usable behind. The device confirms the key with a second assertion, which is the
out-of-band comparison this section used to ask the caller to do by hand.

**Sealed share** (`packages/smart-account/src/sealed-share.ts`). After the DKG the device stores
only `sealShare(keyShare, PRF(SHARE_SEAL_SALT), credentialId)`: XChaCha20-Poly1305 with
associated data covering participant id, group key, verification share and credential id. Each
signing session calls `openShare`. That requires a user-verified assertion for the PRF output,
plus the expected credential and group key. The call checks the tag and then checks the share
against its verification point. The blob is safe to back up to the server, because it is useless
without the passkey. With the server share it is still one share of a 2-of-2.

**What the combination buys.** Spending needs the passkey *and* the server in both configurations.
In the default configuration both are on-chain owners. In the FROST configuration the passkey
gates the device share and the chain sees one signature.

## 6. What each failure costs

Legend: **S** = funds held by the Safe itself. **A** = shielded notes whose deposit label is in a
posted ASP root, withdrawable by proof with the spending key alone and no account signature.
**N** = shielded notes not in an ASP root, whose only exit is `ragequit` from the depositor (the
Safe). "Recovery" means the §4 path, installed at account creation.

Every wallet is a PRF wallet (§2.1), so the table has one column.

| Failure | Cost |
|---|---|
| Device lost or wiped, passkey synced | Nothing lost. The seed is recomputed and the passkey is still an owner. FROST: restore the sealed blob from backup, or recover and re-run the DKG. |
| Browser profile copied (device storage stolen), passkey not | Nothing. The profile holds no secret and no part of the seed (§3). |
| **Server dead** | S, N: recovery, delayed by the cooldown but not lost. Access: `swapOwner` after the cooldown. A: private withdrawal meanwhile. |
| **Server compromised** | It cannot spend, queue, veto or execute early. Refusing to co-sign is the same as dead: recovery swaps it out. A FROST server share alone reveals nothing. |
| Passkey compromised, user still has it | **A: lost immediately.** The PRF yields the seed, and a withdrawal needs no account signature, so no account-layer control can stop it. S, N: a queued drain is public for 7 days, and the owners veto it. |
| Passkey lost, no sync | **A, N lost** (seed gone). **S frozen** (no quorum, no recovery signer). Not a service failure. |
| Server dead **and** passkey compromised | A: lost. S, N: **lost**. The attacker's queued drain cannot be vetoed without the server, and queues execute in order. |
| Server **and** passkey compromised | Everything lost: that is the 2-of-2. |
| Server dead **and** passkey lost | A, N lost. S frozen. |
| Monitor dead | No effect on funds. A passkey-compromise queue relies on the user seeing it in the app within the cooldown. |
| Bundler, paymaster or relayer dead | Normal spending needs a bundler, and any bundler works. Recovery uses none of them. |
| Safe created **without** recovery, server dead | S frozen. **N frozen**. A: private withdrawal only. |

**The trade that is not made:** a server-alone veto would stop the "server dead and passkey
compromised" loss. It would also let a compromised server freeze every recovery, which is the
failure this design exists to remove. The requirement is that a compromised server cannot veto,
and the code enforces it.

## 7. Why the server alone cannot act, in the code

- **Queue.** `Modifier.moduleOnly` accepts `msg.sender` only if it is an enabled module, or a
  signature from one appended to the calldata. The server is not a module, and its own ECDSA
  signature over the `ModuleTx` recovers to the server, which is not a module either. A
  contract signature naming the passkey signer is checked by `SafeWebAuthnSigner` as a P-256
  assertion with the user-verification flag. Each case is a test.
- **Replay and redirection.** The digest covers the calldata prefix, a salt, the chain id and the
  Delay address. `consumed[signer][hash]` refuses a second use, and a genuine signature on
  other calldata is refused. The server cannot invalidate the passkey's hashes:
  `invalidate()` writes only the caller's own namespace.
- **Veto and reconfiguration.** `setTxNonce`, `setTxCooldown`, `enableModule` and
  `disableModule` are `onlyOwner`, and the owner is the Safe. A server-only UserOperation fails
  signature validation with AA24.
- **Early or substituted execution.** `executeNextTx` checks the head's creation time against
  the cooldown and its hash against the arguments.

## 8. Verification of the reused contracts, and what remains unaudited

**Addresses.** The addresses are identical on Ethereum mainnet and Sepolia, and so are the
runtime code hashes (`eth_getCode` via the public RPC).

| Contract | Address | Runtime keccak | How verified |
|---|---|---|---|
| Zodiac Delay Modifier **1.1.1** (mastercopy) | `0x824175b945838d127C1ca83CbcE11D8e44F6dF01` | `0xdd928edd…c577b8` | The `@gnosis-guild/zodiac` 5.0.1 canonical table lists it. Sourcify matches runtime and creation on chains 1 and 11155111. We recompiled Sourcify's sources with solc 0.8.20 (optimizer off, paris): the executable bytecode is byte-identical on both chains, and only the 32-byte metadata hash differs. The 1.1.0 → 1.1.1 source diff is the `success &&` fix plus formatting. |
| Zodiac Delay 1.1.0 — **not used** | `0x01F8cabB808D7dE0dF4202D4B60C8310d2f1339b` | `0xacfe2969…02c0fd` | Listed under `FAULTY` in the zodiac 5.0.1 SDK. Its SignatureChecker ignores the ERC-1271 call's success flag. The fork test performs the attack: 1.1.0 accepts a module that reverts with the magic value, and 1.1.1 refuses it. |
| Zodiac ModuleProxyFactory 1.2.0 | `0x000000000000aDdB49795b0f9bA5BC298cDda236` | `0x01623cbc…c5f21e` | Canonical table. Sourcify match. Recompiled with solc 0.8.6: identical except the metadata hash. |
| Safe 1.4.1 singleton / ProxyFactory / MultiSendCallOnly | `0x41675C09…` / `0x4e1DCf7A…` / `0x9641d764…` | match the registry | `@safe-global/safe-deployments` 1.37.63 code hashes. |
| Safe4337Module 0.3.0, SafeModuleSetup 0.3.0 | `0x75cf1146…`, `0x2dd68b00…` | identical on both chains | `@safe-global/safe-modules-deployments` 3.0.10, chains 1 and 11155111. |
| SafeWebAuthnSignerFactory 0.2.1 | `0x1d31F259…` | identical on both chains | Same registry. |
| Kernel v3.1 implementation / KernelFactory / FactoryStaker (meta factory) | `0xBAC849bB…` / `0xaac5D424…` / `0xd703aaE7…` | `0xad223735…` (chain 1 only, see below) / `0xeecde6f4…` / `0x4527f364…` | Rebuilt from tag `v3.1`, commit `03f7f5cf`. The init code appears verbatim in the deployment transactions, and CREATE2 with salt 0 gives the canonical addresses. `packages/smart-account/fixtures/README.md` has the details. |
| EntryPoint v0.7.0 | `0x00000000…a032` | `0x8db5ff69…82fc58` | Byte-identical to `@account-abstraction/contracts@0.7.0`. CREATE2 recomputed from the creation transaction. |

Every contract above has its mainnet init code vendored in `packages/smart-account/fixtures/canonical`,
and each fixture is proven by CREATE2 to land at the mainnet address. `examples/accounts-live.ts`
deploys them all on an empty anvil and checks each runtime hash. The Kernel implementation's runtime
hash matches only on chain 1, because its constructor stores `block.chainid` in immutables; accounts are
proxies and rebuild those values at run time.

The fork test asserts these code hashes in `setUp`. `verifyRecoveryDeployments()` asserts the
Zodiac and MultiSend hashes from TypeScript before installation.

**External audits of the reused pieces**, as listed in their repositories. We did not re-audit
any of them.

- Safe 1.4.1 has multiple audits.
- Safe4337Module 0.3.0: Ackee, Certora and Nethermind.
- SafeWebAuthnSigner 0.2.1: Certora, Nethermind and a Hats competition.
- Zodiac Delay: G0 Group, Sep 2021 (the Delay module). G0 Group, Feb 2023 (`Modifier.sol` at
  zodiac commit `2ddb81b`). Côme du Crest, "Zodiac Signature Patch Audit", June 2026 (1.1.1).

**The caveat an auditor should weigh.** The passkey queues through Zodiac's *signature-based*
module authentication (`SignatureChecker`, ERC-1271). The Feb 2023 audit predates that code: at
commit `2ddb81b` there is no `contracts/signature` directory. The June 2026 audit states that it
verifies only the fix and relies on earlier audits for the rest. So the queue, cooldown, veto and
execution logic is audited, but the signature path we authenticate through has had no full audit
of its own. We read it (§7), and the fork test attacks it.

If that is not acceptable, there is an alternative that avoids the path entirely. Make the
Delay's module a 1-of-1 Safe owned by the passkey signer, so that queueing is
`Safe.execTransaction` → `delay.execTransactionFromModule`. Every step is then a `msg.sender`
path under audited code. The cost is one more Safe per user. It needs a helper change, not a
contract.

**Unaudited, and ours:**

- `packages/mpc`: FROST signing and the DKG. This is from-spec cryptography.
- `contracts/SchnorrVerifier.sol` / `FrostSigner`.
- `packages/smart-account/src/sealed-share.ts`: the AEAD construction, the key derivation and
  what is bound.
- `packages/smart-account/src/seed-source.ts`: `PrfSeedSource` and `openSeed`, which the app uses,
  and the GF(2^8) Shamir split, the wallet tag and the recovery-code encoding, which no shipped app
  uses (§2.1).
- `packages/smart-account/src/recovery.ts`: encodings. These are differentially tested against
  the deployed Delay (`moduleTxHash` against the contract's own view and against viem's EIP-712)
  and exercised end to end on a fork, but not audited.
- Kernel only: `packages/smart-account/contracts/src/PasskeyCoSignerValidator.sol` (the 2-of-2 rule
  itself), `FrostValidator.sol`, `KernelAvatarAdapter.sol` (in the recovery path) and
  `UserOpChallenge.sol`. Also `src/kernel*.ts` and `packages/wallet/src/kernel-executor.ts`. §10.3 has
  the details.

**Open, deliberately:**

- **Bundler admission.** ERC-7562 was checked against Rundler's rules on a local geth, not against a
  hosted mainnet bundler. The Safe is admitted from its first operation. A Kernel account's first
  operation through the meta factory is not, unless the account is deployed by a plain transaction
  first (§10.3, item 9). The paymaster must be staked (`docs/runbook-mainnet-deploy.md`, 3c).

- **Channel security for the DKG and signing sessions.** The DKG's transport is now built
  (§5: `packages/mpc/src/dkg-transport.ts` and `/v1/frost/dkg/*`), and it is as unaudited as the
  protocol it carries. The SIGNING session relies on TLS, the API key, and one passkey assertion
  over the operation's digest that both rounds carry: `/v1/frost/commit` opens a session only once
  that assertion verifies, the session is bound to that digest and route, and `/v1/frost/sign`
  verifies the same assertion again (the API key alone opens nothing; it ships in the app). The
  session exchanges no secret, so there is nothing to encrypt, but nothing authenticates the
  commitment list end to end beyond the checks in §7.
- **Monitor wiring.** Subscribing `packages/ops` to each user's Delay and alarming on
  `TransactionAdded` is not done. This change does not own that package.
- **More than one passkey.** A second authenticator as an extra owner and Delay module would
  remove "passkey lost, no sync", but not for the PRF seed: a different credential has a
  different PRF secret.
- **Hardware.** The authenticator is simulated in tests (real P-256, real HMAC). The on-chain
  half is real.
- **JavaScript memory.** An opened share or a combined seed is a value in process memory for
  the session and cannot be wiped.
- **The parameters** (7-day cooldown and window, the 3-day minimum) are product decisions. The
  defaults are implemented as the conservative choice. The non-PRF fallback was decided on 21
  October 2026: it is off (§2.1). A user whose browser lacks PRF cannot onboard until they switch
  browser or device.

## 9. Where the tests are

| Claim | Test |
|---|---|
| DKG keys sign through FROST and verify on-chain | `packages/mpc/test/dkg.test.ts`, `dkg-onchain.test.ts` (fresh keys through `FrostSigner` on an EVM), `contracts/test/SchnorrVerifier.t.sol` (DKG vectors) |
| Tampered share, bad or replayed or copied proof, zero secret, duplicates, equivocation, reuse | `packages/mpc/test/dkg.test.ts` |
| No group secret is materialised | `dkg.test.ts`, "the group secret is never materialised" |
| Sealed share: passkey required, domain separation, tamper-evident, bound | `packages/smart-account/test/sealed-share.test.ts` |
| Passkey-only recovery, cooldown, veto, server-alone attacks, expiry liveness, 1.1.0 fault | `contracts/test/PasskeyRecoveryFork.t.sol` (`FORK_RPC=… forge test --match-contract PasskeyRecoveryForkTest`) |
| TypeScript helpers against deployed bytecode | `packages/smart-account/examples/passkey-recovery.ts` (anvil fork), `test/recovery.test.ts` |
| Split seed (library only, unused by the app): server dead, device lost, one share reveals nothing, migration keeps the wallet | `packages/smart-account/test/seed-source.test.ts` |
| The app: no PRF, no wallet; nothing stored without PRF; the removed path stays out of the source and the dev stack; onboarding's one-factor copy | `packages/app/test/seed.test.ts`, `packages/app/test/screens.test.ts` (onboarding) |
| Both accounts, both configurations, on an empty chain through a real bundler and paymaster: creation, gasless spend, one party alone refused, ERC-1271 via viem, passkey-only recovery after the cooldown | `packages/smart-account/examples/accounts-live.ts` (anvil + Alto, 64 checks) |
| Vendored bytecode is mainnet's (CREATE2 address, runtime hash) and our fixtures match the build | `packages/smart-account/contracts/test/Fixtures.t.sol` |
| Kernel: passkey AND server, window signed, UV required, high-s refused, not a hook, rotation | `contracts/test/PasskeyCoSignerValidator.t.sol` (real Safe WebAuthn verifier) |
| Kernel: FROST group signatures from `packages/mpc` accepted, garbage refused without reverting | `contracts/test/FrostValidator.t.sol` (vectors from `scripts/frost-vectors.ts`) |
| Kernel through the real EntryPoint: AA24 for one signer, AA22 for an expired window, atomic batch, ERC-1271, recovery, veto, co-signer rotation, every server-alone attack | `contracts/test/KernelIntegration.t.sol` (run from `packages/smart-account/contracts`) |
| Kernel TypeScript against the real bytecode: address prediction, ERC-1271 for both validators, recovery installation | `packages/smart-account/test/kernel-evm.test.ts`, `kernel.test.ts` |
| The wallet executors: Kernel, the Safe with a contract (passkey or FROST) owner, the bundler submitter | `packages/wallet/test/executor-kernel.test.ts`, `executor-safe-owners.test.ts` |

## 10. Kernel v3.1

The client's diagram names "Safe/Kernel". Kernel v3.1 (zerodevapp/kernel, tag `v3.1`, commit
`03f7f5cf5871cda0070e4223f196f5b577f6cde2`) is implemented next to the Safe. It covers account
creation, operations, ERC-1271, both custody configurations and recovery, and is used through
`KernelExecutor` in `packages/wallet`.

### 10.1 How the Safe design maps onto Kernel

Kernel has no owners and no threshold. A **validator** contract decides whether an operation or a
signature is valid. The account has one root validator and may have more, and **each installed
validator is a complete authority on its own**. So "2-of-2" cannot be two validators. It has to be one
validator that requires both signers.

| Safe design | Kernel implementation |
|---|---|
| Safe 1.4.1 proxy, Safe4337Module 0.3.0 | Kernel v3.1 ERC-1967 proxy, created by KernelFactory through the staked meta factory (FactoryStaker). The address is CREATE2 over `keccak256(initData ++ salt)`, so it commits to the root validator and its keys (`predictKernelAddress`, checked against `KernelFactory.getAddress` on the real bytecode). |
| Owners: `SafeWebAuthnSigner` + server ECDSA, threshold 2 | Root validator **`PasskeyCoSignerValidator`**, which stores the passkey key (x, y, verifiers) and the server address, and requires BOTH. The passkey assertion goes to the canonical `SafeWebAuthnSignerFactory.isValidSignatureForSigner`: the same audited P-256 code, verifier and signature encoding as the Safe path. The server's signature is checked with OpenZeppelin 5.1 `ECDSA.tryRecover`. |
| Option: `FrostSigner` as the only owner | Root validator **`FrostValidator`**, which stores the group key and calls `SchnorrVerifier.verify` (imported from `contracts/SchnorrVerifier.sol`) over the same 32-byte message. |
| SafeOp digest with `validAfter`/`validUntil` | Kernel passes validators the EntryPoint's `userOpHash`, which has no validity window. Both validators take Safe4337Module's 12-byte window header and have the signers sign `UserOpChallenge(userOpHash, validAfter, validUntil, validator)`. The EntryPoint enforces the window (AA22). The executor signs 15 minutes, as for the Safe. |
| ERC-1271 via `SafeMessage` | Kernel's `isValidSignature(hash, sig)` asks the root validator about an EIP-712 wrapper of `hash` in the account's own domain ("Kernel", "0.3.1"). The same two signers sign that wrapper. viem's `verifyTypedData` accepts it, and before deployment it accepts an ERC-6492 wrapper (`KernelExecutor.signTypedData`), which the Safe executor does not offer. |
| Recovery: Zodiac Delay 1.1.1, passkey signer as its only module | **The same Delay mastercopy, factory and setup**: owner = avatar = target = the account. Kernel does not implement `execTransactionFromModule`, so **`KernelAvatarAdapter`** is installed twice. As a fallback for that selector, any caller may reach it, and it checks that the caller Kernel appends is the account's Delay. As an executor, it calls back `executeFromExecutor`. `kernelRecoverySetupCalls` installs everything in the account's first operation, next to its first real calls. |
| `swapOwner(deadServer, newServer)` after the cooldown | `PasskeyCoSignerValidator.rotateCoSigner(newServer)`, a call the account makes to the validator, queued on the Delay (`encodeRotateCoSigner`). `FrostValidator.rotateGroupKey` is its counterpart after a new DKG. |
| Veto: the owners call `setTxNonce` | Unchanged: an account operation signed by passkey and server calls `setTxNonce`. |

### 10.2 The requirements, one by one

| Requirement (§3, §4, §6, §7) | Kernel | Where it is shown |
|---|---|---|
| The passkey alone cannot spend immediately | Met. The validator requires the server's signature too, and the account refuses AA24. | `KernelIntegration.t.sol` `test_passkeyAlone_isAA24`; `accounts-live.ts` §3 |
| The server alone cannot spend | Met. It cannot produce a P-256 assertion, so AA24. | `test_serverAlone_isAA24`; `accounts-live.ts` §3 |
| The server cannot queue, veto, reconfigure or execute early | Met. It is not a Delay module (`NotAuthorized`), and the Delay's owner is the account (`OwnableUnauthorizedAccount`). Calling the account's module entry point directly fails with `NotTheDelay`, and it cannot call `execute` or `installModule` (`InvalidCaller`). | `test_recovery_serverAlone_cannotQueueVetoOrExecute`, `test_noCallerButTheEntryPoint_reachesExecute`; `accounts-live.ts` §3 |
| Server dead: funds out after the cooldown, and access restored | Met. The passkey queues the exit, anyone executes it after 7 days, and a queued `rotateCoSigner` makes the account a 2-of-2 again with a new server. | `test_recovery_passkeyAlone_afterTheCooldown_exitsAsTheAccount`, `test_recovery_restoresAccess_byRotatingTheCoSigner`; `accounts-live.ts` §3 |
| A stolen passkey's queued drain is visible and vetoable | Met. The same `TransactionAdded` event, and the veto by passkey + server. | `test_recovery_ownersVeto_aStolenPasskeysDrain`; `accounts-live.ts` §3 |
| Expiry keeps a reverting queued call from jamming recovery | Met. It is the same Delay, with the same configuration and the same helpers. | as for the Safe |
| Gasless through `SponsorPaymaster` | Met. | `accounts-live.ts` §3, §4 |
| Admitted by a public bundler from the first operation | Met, with the account deployed first: the co-signer creates it at enrolment, so no operation carries initCode (§10.3 item 9). The Safe needs nothing of the kind. | `erc7562-live.ts` B0; `cosigner-live.ts` §4 |
| ERC-1271 that the LP node's `verifyTypedData` accepts | Met, including before deployment (ERC-6492). | `kernel-evm.test.ts`; `accounts-live.ts` §3, §4 |
| FROST: one signature, and one share alone is refused | Met. | `FrostValidator.t.sol`; `accounts-live.ts` §4 |
| Only audited contracts in the spending and recovery path | **Not met** (§10.3). | |

### 10.3 What Kernel cannot match

1. **The 2-of-2 rule is our code.** On the Safe, "both owners" is Safe 1.4.1's own threshold check,
   and we wrote no Solidity in the spending path. Kernel has no multi-signer primitive. ZeroDev's
   WeightedECDSAValidator takes ECDSA guardians only, and its WebAuthnValidator and permission signers
   each check one key. So the AND lives in `PasskeyCoSignerValidator`, which is unaudited. It delegates
   each check to audited code (Safe's WebAuthn stack, OpenZeppelin ECDSA), but the composition, the
   per-account storage and the challenge format are ours. This is the main reason the Safe stays the
   recommendation.
2. **Adding a validator adds an authority; it does not add a signer.** On the Safe, adding an owner
   still goes through the threshold. On Kernel, every additional validator, permission, or validator
   enabled in "enable mode" can authorise the selectors it is enabled for on its own. Only the root
   signers can install one, and the wallet never does. A monitor must still treat `ModuleInstalled`
   (type 1), `PermissionInstalled`, `RootValidatorUpdated`, `SelectorSet` and `Upgraded` on an account
   as the equivalent of `AddedOwner` / `ChangedThreshold` on a Safe. The same applies to ERC-1271: a
   signature can name any installed validator (`0x01 ++ address`).
3. **The recovery path contains unaudited code.** The Delay is audited, but `KernelAvatarAdapter` is
   ours. Its fallback selector is open to every caller by necessity: Kernel's default admits only the
   EntryPoint, and the Delay is not the EntryPoint. Its safety rests on checking the caller that Kernel
   appends; the argument is in the contract, and the attacks are tests.
4. **Recovery cannot DELEGATECALL.** The Safe's Delay can queue a DELEGATECALL, and the adapter refuses
   one. A queued call can still do anything the account can do by CALL, including `upgradeTo`,
   `changeRootValidator` and module changes on itself. So a stolen passkey that survives the veto window
   has the same power as on the Safe, but it cannot run foreign code in the account's storage.
5. **A root validator that is a hook opens the account to everyone.** Kernel's
   `onlyEntryPointOrSelfOrRoot` admits any caller to `execute`, `installModule` and `upgradeTo` when the
   root validator answers `isModuleType(4)`. Both validators answer false, and tests pin that. Any
   future validator must answer false too, and nothing in Kernel enforces it.
6. **Upgrades are a first-class call.** The account is an ERC-1967 proxy with `upgradeTo`, callable by
   the root signers or, after the cooldown, by a queued recovery call. A Safe can also be pointed at
   other code by its owners (by DELEGATECALL). The difference is visibility: on Kernel the monitor watches
   `Upgraded`.
7. **Audit status of Kernel itself.** The `audits/` directory at tag `v3.1` holds ChainLight's Kernel
   v3.0 report and Kalos reports for earlier versions, the v3 plugins and WebAuthn. None is named for
   v3.1, and we have not compared the v3.0 audit scope with the v3.1 diff. We did not re-audit Kernel.
8. **Rotating the passkey.** `PasskeyCoSignerValidator` rotates only the co-signer. A new passkey
   credential means a new root validator (`changeRootValidator`), and a new Delay module for recovery.
   The Safe does this with `swapOwner` plus `enableModule`.
9. **Bundler admission (ERC-7562).** Checked on 2026-09-15, and again on 2026-09-17, with
   `packages/smart-account/examples/erc7562-live.ts`.
   It runs the stack on geth `--dev` (JavaScript tracers, mainnet's forks through Osaka) and sends every
   operation through Rundler v0.11.0 in safe mode: Alchemy's open-source bundler, default minimum stake
   1 ETH and unstake delay one day. The repository's Alto 0.0.21 could not be the judge. Its safe mode
   decodes the traced simulation with an ABI that lacks the EntryPoint's `DelegateAndRevert` wrapper, so it
   fails every v0.7 operation whatever the operation. It also sends no tracer timeout, and geth's 5-second
   default cuts off a P-256 validation first.
   - **Later operations are admitted** for both validators. That includes the owners' veto on the Delay,
     and the first operation after a recovery rotated the co-signer through the Delay. The validators read
     only storage keyed by the account (STO-021). `PasskeyCoSignerValidator` calls the Safe WebAuthn
     factory, its singleton and the FCL verifier; `FrostValidator` calls `ecrecover`. None of them reads
     storage or a banned opcode.
   - **A first operation with initCode through ZeroDev's meta factory is refused:** `account uses banned
     opcode: CREATE2` (rows B1 and C1, which stay in the run as the documented behaviour of that path).
     Rundler counts CREATE2 in the deployment frame only when the initCode factory
     itself executes it (`crates/sim/src/simulation/v0_7/context.rs`). Kernel v3.1's FactoryStaker creates
     the account through KernelFactory. ERC-7562 OP-031 allows exactly that ("by the factory itself, or by
     a utility contract it calls"). A bundler following the ERC's text should therefore admit it, if it
     counts the meta factory's mainnet stake as staked: 0.1 ETH and 86400 s, read from mainnet, where
     Rundler's default floor is 1 ETH. Not tested against a hosted bundler.
   - **KernelFactory itself as the factory is refused too**, for a rule we should not avoid. The
     validator's `onInstall` writes the account's keys into the validator's storage during deployment,
     which STO-022 allows only with a staked factory, and KernelFactory has none: `Sender storage ...
     accessed during deployment. Factory (or None) must be staked`.
   - **So no operation of a Kernel account ever carries initCode, and this is now built.** The account is
     created by a plain transaction to `KernelFactory.createAccount` before its first operation; anyone may
     send it, because the init data fixes the validator and its keys, and it produces the same CREATE2
     address the initCode would have. The co-signer's sponsorship module sends it at enrolment, next to
     `SponsorGate.sponsor` (§11.1); the app waits for the account to have code before its first operation
     (`packages/app/src/wallet/account.ts`, `ready`), and `KernelExecutor` omits initCode once it does.
     Row **B0** is exactly that first operation - a Kernel account with `PasskeyCoSignerValidator`, created
     beforehand, installing recovery and depositing in one operation - and Rundler in safe mode **accepts**
     it. The Safe path is unchanged: it is admitted from its first operation, initCode and all.
   - **The Safe is admitted from its first operation**, through the unstaked SafeProxyFactory, for the
     passkey + co-signer owners and a single-owner Safe alike. ERC-1271 was checked on the same chain for
     all three configurations.
   - **P-256 in Solidity is slow under a JavaScript tracer.** Tracing one FCL verification took longer
     than geth's 5-second default. Hosted bundlers trace natively; a self-hosted one needs a longer
     tracer timeout (Rundler's `--tracer_timeout` default, 10 s, was enough here) and a longer timeout on
     its own RPC client: on a busy machine Rundler's default 10 s gave up on geth mid-trace and answered
     `provider request timeout from client side`, which is not a verdict on the operation. The run now
     starts it with `--provider_client_timeout_seconds 60`; no validation rule or stake floor is changed. Ethereum L1 has the
     P256VERIFY precompile at 0x100 since Osaka (EIP-7951; an `eth_call` to it on mainnet verified a test
     signature on 2026-09-15), and ERC-7562 OP-062 admits it. `P256.Verifiers` can name it ahead of the FCL
     fallback. The wallet's signers name only the FCL verifier, and changing that changes every passkey
     signer's address.

The deployments are identical in both custody configurations. What is ours is listed under "Unaudited,
and ours" in §8.

## 11. The co-signer service

Until `packages/cosigner` existed, "the server" in this document was a key held by an example. The service runs
the server half of every configuration above. It is the second owner of a Safe, the `coSigner` of a Kernel
`PasskeyCoSignerValidator`, and the server participant in two-party FROST signing. It never runs on Flux. Its
package README has the API, the policy file and the full threat model.

**The rule it enforces.** No co-signature or FROST signature share leaves the service unless the same request carries a
user-verified passkey assertion. That assertion must verify over the exact digest the service is about to sign, for the
passkey the account trusts. The service recomputes the digest itself: the `SafeOp` for a Safe, the `UserOpChallenge`
for a Kernel account, or the ERC-1271 wrapper of typed data. It never signs a hash from a request. It reads the passkey
from the chain, never from the request:

- a Safe owner's `SafeWebAuthnSigner` configuration, with its address checked against the factory's CREATE2;
- `PasskeyCoSignerValidator.configOf`;
- for a FROST account, the recovery Delay's only module.

An account not yet deployed is bound through the CREATE2 address that commits to its owners or validator configuration.
The P-256 check in TypeScript mirrors Safe's WebAuthn library: the same client-data reconstruction, the
user-verification flag, and malleable s accepted. `examples/cosigner-live.ts` compares its verdict with the deployed
factory's `isValidSignatureForSigner`. Where it is stricter than the chain, the extra checks are user presence, a
duplicate challenge refused, and optional RP-id and origin pins. Being stricter can only produce a refusal.

**The veto (§4) keeps the trade from §6.** The service co-signs `setTxNonce` only through its veto route, and only when
all of these hold:

- the call is alone in its operation;
- it targets the account's own Delay;
- it skips transactions that are actually queued;
- the window is at most 15 minutes;
- the passkey signed that operation.

So the user vetoes and the server never vetoes alone. A request without the passkey, or with the passkey's signature over any
other operation, is refused (`passkey_required`, `bad_passkey_signature`). The service also serves the queue
(`GET /v1/queue`) so the wallet can show it on every open, which §4 already requires.

**What the policy adds to the table in §3.** Once the passkey has signed, the service refuses everything its deployment
does not list. Its limits:

- **Targets.** Calls are allowed only to the deployment's contracts. Token approvals are allowed only to those contracts.
- **Authority.** Any authority change is refused (Safe owners, modules, fallback handler, guard; Kernel modules, root
  validator, upgrades; the Delay's configuration; validator rotations). The exceptions are the documented recovery
  setup at the start of the first operation, a rotation to a co-signer the deployment lists, and the veto.
- **Window and throughput.** Validity windows are short. Each account has a rate limit, and each token can have a
  rolling 24-hour value limit.

Every decision is appended and fsynced to an audit log before the answer leaves. That covers signed, reused (an
identical request answered again) and refused with its code. Operations whose EntryPoint nonce is spent are refused as
replays. FROST sessions are single-use, and a refused request burns its session. A FROST session is opened only
under the passkey's assertion over the operation it is for, and the session table is bounded so that a FROST
account's recovery veto always has room: each account has a few co-signing slots plus one slot reserved for the veto
of a recovery queued now, each API client has a commit rate limit (the veto is exempt), and a full table evicts the
oldest co-signing session, never a veto for a co-signing commit (`packages/cosigner/README.md`, "FROST signing
sessions").

**What this changes in §6, and what it does not.**

- **A compromised co-signer alone can still only refuse.** Refusing is equivalent to the server being dead, and recovery
  replaces it. It learns which accounts use it and what they do.
- **A compromised passkey with the co-signer honest is now bounded.** It can only use the deployment's contracts, at the
  rate and daily limits, and every attempt is in the audit log.
- **Two losses stay as in §6.** The "A" notes of a PRF user are lost at once. A drain queued through the Delay stays
  visible for the cooldown and must be vetoed.
- **Passkey and co-signer compromised together hold the 2-of-2.** The policy runs inside the compromised party, so
  everything is lost. That row of §6 does not change.

The co-signer's key belongs in a KMS or HSM (`kmsKey`). A key file is refused in production mode unless the operator
sets `COSIGNER_ALLOW_FILE_KEY_IN_PRODUCTION=1` explicitly.

The server's FROST shares cannot live in a KMS (a KMS does not run FROST), so they are envelope-encrypted on disk:
AES-256-GCM under a per-share data key, the data key wrapped by a KMS key (`COSIGNER_FROST_KMS_MODULE`), the
ciphertext bound by its AAD to the group key, account reference and participant id. Production refuses shares
recoverable from the disk alone - plaintext, or under a local wrapping key - unless
`COSIGNER_ALLOW_FROST_SHARE_FILE_IN_PRODUCTION=1`, a flag separate from the key file's (`packages/cosigner/README.md`,
"FROST share custody").

| Claim | Test |
|---|---|
| Every refusal: forged, missing or misdirected passkey signature; expired, unbounded or long window; disallowed target, spender or transfer; every authority change on Safe and Kernel; replay and idempotency; rate and daily limits; stale enrolment; server-alone and out-of-range vetoes | `packages/cosigner/test/service.test.ts`, `policy.test.ts`, `webauthn.test.ts` |
| FROST: passkey first (at the commit too), a session used once and bound to its digest and route, burned on refusal, own commitment unchanged, expiry, the veto's reserved slot, client limits, eviction | `packages/cosigner/test/frost.test.ts` |
| HTTP authentication, body limits, no secret in any response; file-key production guard; KMS signature normalisation | `packages/cosigner/test/server.test.ts`, `custody-config.test.ts` |
| FROST shares sealed on disk: round trip, a data key per share, tampering and AAD mismatch refused, another wrapping key refused, plaintext migration, production refusal, the share flag separate from the key flag | `packages/cosigner/test/frost-shares.test.ts` |
| `RemoteCoSigner` in place of the local server key gives byte-identical signatures inside the real `SafeExecutor` and `KernelExecutor`, routes vetoes, runs the device's FROST half | `packages/cosigner/test/client.test.ts` |
| On anvil with mainnet's bytecode, a bundler and the paymaster: the production entrypoint co-signs sponsored first operations for a Safe and a Kernel account over HTTP, refuses authority changes, vetoes a stolen passkey's queued drain with a fresh passkey signature, refuses the server-alone veto and a replay, and records all of it | `packages/cosigner/examples/cosigner-live.ts` |
| Never a Flux app; its own compose profile; loopback ports; key custody never inline | `packages/ops/test/packaging.test.ts` |

### 11.1 Sponsorship without a hot paymaster owner

`SponsorPaymaster` has one owner, and that owner does everything, from allowlisting an account to withdrawing the gas
deposit. In production the owner is a multisig, so a new account could only be sponsored by a multisig transaction.
`contracts/SponsorGate.sol` is now that owner. It splits the powers:

- **Operators** are revocable keys, one per co-signer instance. They may only `sponsor`, `sponsorBatch` or `unsponsor`.
  They cannot withdraw, stake, change the cost limit or the budgets, or move ownership.
- **A count budget** limits them: together they add at most `maxSponsorsPerWindow` accounts per day (twice that across
  a window boundary). Each of those accounts spends at most the paymaster's per-account gas budget, and the gate refuses
  operators while the paymaster enforces no such budget.
- **The governor** (a multisig) keeps every owner power, through forwarding functions of the same names. It is a plain
  two-step governor, not `DelayedGovernance`. No third party is exposed to the gas deposit and could act on a warning,
  so a delay would only slow key rotation and incident response. A **guardian** may revoke operators and lower the
  budget, and nothing else.

**With `OwnerlessPaymaster` there is no gate** (`COSIGNER_SPONSOR_OWNERLESS_PAYMASTER` instead of `COSIGNER_SPONSOR_GATE`):
the paymaster admits accounts by their CREATE2 address, so step 3 below does not exist, and the module only creates the
passkey signer or the Kernel account, from the same operator key under the same limits. docs/ownerless-paymaster.md
("Onboarding without a SponsorGate") says why that is the co-signer's job and not the first operation's.

The co-signer's sponsorship module (`packages/cosigner/src/sponsorship.ts`) acts after a successful, passkey-verified
enrolment, which has already bound the account to the passkey the chain names:

1. For a Kernel account that does not exist yet, it calls `KernelFactory.createAccount(initData, salt)`. A public
   bundler refuses a Kernel first operation that creates the account through Kernel's meta factory (§10.3), so the
   account has to exist before it sends anything. Safe accounts are admitted from their first operation and are not
   deployed here.
2. For a Safe whose `SafeWebAuthnSigner` is not deployed yet, it calls `createSigner` on the canonical factory. A
   Safe validates its first operation through that contract.
3. It calls `SponsorGate.sponsor(account)`.

**The deployment it sends is never the one a request handed it.** `initData` and `salt` are written onto the enrolment
record only after `resolveBinding` has checked that `predictKernelAddress` over them is the account being enrolled, and
the module recomputes that address again before sending, refusing with `deployment_mismatch` - and sending nothing - if
it is not the enrolled account. The factory call itself is rebuilt here, on the canonical `KernelFactory`. The account's
code is re-read immediately before the send, so a second enrolment, another replica, or a deployment the user sent
themselves all stop it; `createAccount` is in any case a no-op on an account that exists.

Every transaction comes from the module's own operator key, never the co-signer key. In production that key is in a
KMS. A key file is refused in production unless `COSIGNER_ALLOW_SPONSOR_FILE_KEY_IN_PRODUCTION=1`, and the entrypoint
refuses an operator key equal to the co-signer key. The module applies:

- its own global and per-client rate limits;
- a daily cap below the gate's budget (the entrypoint refuses to start otherwise), rebuilt from the audit log on restart.

It is idempotent: a second enrolment deploys nothing and sponsors nothing. It never re-sponsors an account whose
sponsorship was removed on-chain. Every decision is an audit record (`t: "sponsor"`), with its transactions -
`accountTx` for a Kernel account's creation, `signerTx` for a Safe's passkey signer, `sponsorTx` for the allowlisting -
and `GET /v1/sponsorship` reports the same three.

**What a stolen operator key costs.** At most the gate's budget in new accounts per day, each within the paymaster's
per-account budget, plus the key's ETH float. It can also unsponsor accounts, which denies service until the governor
restores them. Deploying Kernel accounts adds nothing to that: `createAccount` is permissionless, its result is fixed by
the init data, and the key pays only its own gas. The guardian or the governor revokes the key in one transaction.

**Sale accounts, and what stays linkable.** A sale account (`packages/wallet/src/movva/sell.ts`) is opened with a fresh
P-256 key, never the user's passkey. Its enrolment carries only what the protocol needs: the account, its CREATE2
deployment, and an assertion by that key. A Kernel sale account is created by this module before its first operation,
like any other; `sell` still refuses any account with a history, and reads its EntryPoint nonce to tell "deployed and
untouched" from "used" (`saleAccountIsFresh`). Sponsorship adds no identifier. Its limits are keyed by API client and
globally, never by user, passkey or device, so no stored field ties a sale account to the user's account. What remains
is off-chain metadata the co-signer and the sponsor see anyway:

- the user's account and the sale account are enrolled by the same client (the app's API key), and from the same
  network address unless the client hides it;
- they are enrolled close together in time: the user's account at onboarding, the sale account moments before its
  sale;
- a sale account's sponsorship - and, for Kernel, its creation - lands on-chain seconds after its enrolment.

Anyone who sees the co-signer's requests or its logs can correlate a user's session with the sale accounts it opens.
The chain shows only that the operator sponsored an account. Removing the timing link needs sale accounts enrolled
ahead of need, from a pool, or through a relay the co-signer cannot tie to the user. That is the app's choice, and it
is not built.

### 11.2 Recovery alerts when the app is closed

§4's cooldown protects a user only if someone notices the queued transaction. The wallet shows the queue while it is
open; `packages/cosigner/src/recovery-alerts.ts` covers the week it may stay closed.

- **Subscribe.** `POST /v1/alerts/subscribe` takes a Web Push subscription and a fresh, user-verified assertion by the
  passkey the account trusts, over `alertsSubscribeChallenge`. The assertion must be issued within 5 minutes and is
  accepted once. The endpoint must be on a known push service, because the service sends requests to it.
- **Unsubscribe.** `POST /v1/alerts/unsubscribe` takes the same proof. It is refused while the account has anything
  queued, so a thief holding the passkey cannot silence the alerts about their own drain. The device receives a last
  notice that its alerts were turned off.
- **Watch.** The watcher follows `TransactionAdded` on every enrolled account's Delay. A log counts after N
  confirmations, and the cursor is persisted. Each account's queue is also read from state the first time the watcher
  sees it.
- **Alert schedule.** An alert goes out at once, again every 24 hours, and once more within 24 hours of the cooldown's
  end. Alerts stop when the Delay's `txNonce` passes the transaction (vetoed or executed) or when it expires. Times are
  the chain's, like the cooldown.
- **Payload.** "Uma recuperação foi solicitada na sua conta Movva", with the time the transaction becomes executable.
  It carries no amount and no address. It is encrypted with aes128gcm (RFC 8291) and sent with VAPID (RFC 8292), both
  built on node:crypto and tested against RFC 8291's vector.
- **Failures.** 404 and 410 remove the subscription; 429 and 5xx are retried.

What the alerts do not change:

- A user who never subscribed a device, or whose push service drops the message, depends on opening the app.
- The push service learns that a message went to the device, when, and its size.
- A thief holding the passkey can subscribe their own device, which gains them nothing. They can also unsubscribe the
  user's devices before queueing anything; each device then shows the "alerts turned off" notice.

| Claim | Test |
|---|---|
| Operators reach no owner power; the budget refuses the account past it and counts an account once; revoked keys are refused; the guardian only brakes; fuzz and invariant runs over all of it | `contracts/test/SponsorGate.t.sol` |
| The module creates a Safe's signer and sponsors from the operator key, is idempotent, never re-sponsors a removed account, keeps its cap across a restart, refuses with a code, stores no user identifier | `packages/cosigner/test/sponsorship.test.ts` |
| aes128gcm matches RFC 8291's test vector; the VAPID JWT verifies; endpoints and delivery outcomes | `packages/cosigner/test/webpush.test.ts` |
| Subscriptions need a fresh passkey assertion; unsubscribing is refused while a recovery is queued; the watcher alerts after confirmations, re-alerts on schedule, stops at veto or expiry, drops gone subscriptions, resumes from its cursor; the browser helpers | `packages/cosigner/test/alerts.test.ts` |
| On anvil: the gate owns the paymaster; a Safe and a Kernel account are sponsored by the co-signer at enrolment and then operate; a queued drain reaches a local push endpoint and decrypts with the subscription's keys; the operator key is refused a withdraw; the budget refuses the next account; revocation stops the co-signer | `packages/cosigner/examples/cosigner-live.ts` |

## 12. Sub-wallets are outside the key tree

Sub-wallets (Rev. 3 section 6.2-6.3, VK-7) are not nodes of the tree in section 2. Each has its own BIP-39 phrase, generated on the
device from fresh entropy, and its keys (shielded spending and viewing, account, local store) are a function of that phrase alone:
not of the passkey, the MPC shares, the primary's seed or another sub-wallet. There is no master seed and no hierarchy, so a
compromised sub-wallet seed yields nothing of the primary's or of any other sub-wallet's (KI-1..KI-6; T-10 as far as software shows
it: `packages/wallet/test/movva-subwallet.test.ts` and step 18b of the live example). Movva never generates, receives, stores or
backs up a phrase; the device keeps a sealed registry of public facts and each sub-wallet's derived 32-byte root (not the phrase)
under the unlocked wallet's key, so the sub-wallet opens without retyping its phrase. That has a consequence the tree does not: an
attacker who has both the device and the primary's unlock can open the device-held roots of the sub-wallets on it. A leaked
phrase, which is what T-10 tests, opens only its own sub-wallet.

What is not done: recovery is the phrase and a rescan of the pool, and nothing else - guardian recovery is off and not built, so a
lost phrase is a lost sub-wallet. Moves between sub-wallets are V2. A disclosure package can combine the sub-wallets the user
selects (one master viewing key each), but nothing can show that the selection is every sub-wallet the person has: open.

Gas: on a deployment whose paymaster is `OwnerlessPaymaster`, a sub-wallet's account is the 1-of-1 Safe of its own account key
(`subWalletSafe`, salted from its root), and the sale accounts it opens are 1-of-1 Safes on fresh keys. The paymaster admits them
by their CREATE2 address from their first operation, which creates them; there is no co-signer, no enrolment and nothing
allowlisted (docs/ownerless-paymaster.md, "Sub-wallets"). A `SponsorPaymaster` deployment still sponsors only accounts the
co-signer enrolled, so sub-wallets stay unavailable there outside the dev stack.
