# Runbook — mainnet deployment of the Movva rail

For the person doing the deployment, start to finish. The rail is the MOVVA-only one the client decided on 14 October
2026: deposit PIX -> mint Movva -> hold it as shielded notes in the Movva Privacy Pool -> withdraw to PIX through the
Movva FiatEscrow / OffRampEscrow pair. There is no ETH/USDT ramp pair, no ETH or USDT band oracle and no savings
product (D1); the reserve holds Tether's USDT. The whole rail is one command, `scripts/deploy-movva-rail.ts`, which
refuses to broadcast until the same run has passed on a fresh fork of mainnet. Every command here has been run against a
mainnet fork (`deployments/mainnet-movva-rail.rehearsal.json`, 21 October 2026); what changes on the day is the RPC, the
signer, and the real Safe and role holders.

**Nothing in this runbook may be run from the development server.** It was compromised on 11 September 2026 and has
not been rebuilt. A mainnet key must never touch it. Use a clean machine that has never held this repository's `.env`.

Setup on that machine: `npm ci` (it links the gitignored Solidity libraries; `scripts/foundry.sh` refuses with "run npm
ci first" if they are missing), then `forge build` in the repo root and in `protocol/contracts` with
`$(bash scripts/foundry.sh path)`.

## Before the day

| Gate | How to confirm it |
|---|---|
| External audit complete, findings resolved | The auditor's report, and a commit that closes each finding (the 21 October 2026 findings H-02, M-07, M-18, M-19, M-20, L-01 are closed by the commits that introduced this runbook) |
| Scope frozen | A tag on the audited commit; deploy that tag, not `HEAD`. `--broadcast-mainnet` refuses a tree with any uncommitted file outside `deployments/` |
| Governor Safe ready | A Safe 1.4.x on mainnet, **2 of 3 or stricter, no module**, none of its owners the deployer or a test key; the signers can reach it and have executed a test transaction from it. It becomes every DelayedGovernance contract's governor and, by default, the Entrypoint timelock's proposer, canceller and executor (`MOVVA_RAIL_GOVERNOR`; `MOVVA_RAIL_OWNER_SAFE` names a different Safe for the timelock) |
| Roles named | `MOVVA_RAIL_ROLES=<roles.json>`: `{ "witnesses": [3], "asps": [3], "arbitrator", "lp", "guardian", "treasurer", "hedgeTreasury", "treasury" }`. Arbitrator, guardian, treasurer and hedge treasury are 2-of-3 Safes (the custody model of 12/14 October 2026); the witnesses are Reclaim's production set; asp/0 is Movva, asp/1 and asp/2 the two independent ASPs; `lp` is the first gateway / institutional LP. A live mainnet run refuses any role that is a test identity |
| zkTLS credentialed, bank endpoints reviewed | A Reclaim application credential, and for each Phase A LP's bank the provider template, its `providerHash`, URL prefix and rails, reviewed as in "zkTLS endpoints" below. A live mainnet run refuses an illustrative endpoint (packages/ramp's receipt templates, or a reserved test domain): pass the reviewed list with `MOVVA_RAIL_ZKTLS_ENDPOINTS=<endpoints.json>` |
| FX leg decided | The default on mainnet is the keyless Chainlink BRL/USD leg (`MOVVA_FX_SOURCE=chainlink`, `MOVVA_CHAINLINK_BRL_USD=0x3126E7F38D5f60f4E2B6ec3511C7bdbD79317Df1`): no keeper, no governor. `MOVVA_FX_SOURCE=pyth` keeps Pyth's FX.USD/BRL, which then needs the Pyth keeper running with Hermes access before anything prices. "Prices" below |
| Divergence breaker decided | `MOVVA_RAIL_BREAKER=off` deploys none, and the record says so. On mainnet that is the client's decision to record: the orchestrator does not yet pass breaker sources (a TWAP pool, an independent BRL/USD source) to `DeployMovva.s.sol`. The rehearsal ran without one |
| Entrypoint owner end state | Decided (H-02, 21 October 2026): OWNER_ROLE ends with the EntrypointTimelock (7 days, the Safe). `--owner-mode renounce` exists for testnets only; `--broadcast-mainnet` refuses it |
| Finalization decided | Whether, and when, `--finalize` renounces every governor (section 6). It cannot be undone, and it removes every instant brake in "If something is wrong after deployment" |
| USDT risks accepted | The client has read SR2-20 to SR2-29 in `security-review-phase2.md`: Tether can freeze the reserve's USDT |
| Phase A LPs onboarded on testnet | At least two, each having completed a full on-ramp and off-ramp by PIX, settled on a zkTLS proof of its own bank session |
| Monitoring ready | The monitor runs against Sepolia, its alerts reach a channel someone reads, and it alerts on every `ChangeScheduled` (governors) and `CallScheduled` (the timelock) event |
| Gas funded | The mainnet-fork rehearsal measured **39.10M gas over 56 transactions** (safes 0.31M, protocol 5.96M, Movva 10.90M, pool 1.91M, ASP quorum 0.90M, ramp 17.03M, the Safe's setup batch 0.17M, owner 1.92M). Multiply by the day's gas price and fund twice that; the script checks it before broadcasting. Plus the relayer float and the paymaster deposit and stake (section 3c) |

If any row is unconfirmed, stop. Every one of them is cheaper to fix before deployment than after.

## Who governs, once the run ends

Three powers, three holders. None is the deployer.

| Power | Holder | How fast |
|---|---|---|
| Every DelayedGovernance contract - the reserve, the FX leg (Pyth only: the Chainlink leg has no governor), FeeSplitter, NodeRewards, the LP registry, the zkTLS verifier, both Movva escrows | **the governor Safe**, from setup: the forge scripts hand each contract over with setup still open, and the Safe itself sends `completeSetup` (M-07) | risk-increasing changes wait `GOVERNANCE_DELAY` (48 h); risk-reducing ones are instant |
| The Privacy Pools Entrypoint's OWNER_ROLE (upgrade the UUPS proxy, register / configure / wind down / remove pools, withdraw fees, grant and revoke every role, ASP_POSTMAN included) | **the EntrypointTimelock** (`contracts/governance/EntrypointTimelock.sol`, OpenZeppelin 5.1.0's TimelockController unchanged) | every action is scheduled by the Safe and waits **7 days**; the Safe can cancel it at any time before |
| ASP_POSTMAN (which deposits may withdraw privately) | the immutable 2-of-3 **AspRootQuorum** | a root posts when 2 of the 3 ASPs vote for it |

Why the timelock's executor is the Safe and not open (`address(0)`): an open executor adds liveness only for operations
the Safe already proposed - if the Safe is lost nothing new can be proposed either - while it lets anyone choose *when*
a ready operation lands inside its window (an upgrade before the relayer and the ASPs are ready for it, a
`withdrawFees` front-running a configuration change). The timelock has no admin but itself, so adding a proposer or
shortening the delay is itself a 7-day operation.

The deployer holds OWNER_ROLE only inside the run: registering the Movva pool and moving ASP_POSTMAN to the quorum both
need it, and through the timelock each would split one deployment over weeks. The owner step ends it before the run
does, and the run checks the exact holder set (the timelock alone holds OWNER_ROLE; the deployer holds no Entrypoint
role). A run that stops in between is resumed with `--resume`, never left there.

### Delayed changes on the governed contracts

| Waits out the delay | Instant |
|---|---|
| allowing a verifier; adding an arbitrator | revoking either |
| listing an asset, re-enabling it, changing its oracle | delisting |
| adding a witness; lowering a threshold | removing one; raising a threshold |
| allowing a zkTLS bank endpoint | revoking one |
| registering an escrow with the registry | removing one |
| admitting an institution, raising credit, reinstating an LP | cutting credit, `SUSPENDED`, `NONE` |
| opening network Phase B or C | closing back to an earlier phase |
| the reserve: a gateway, a higher fee or cap, a lower ratio, the vault, oracle, treasurer, hedge treasury or fee recipient | revoking a gateway, lowering a fee or cap, the guardian (`setGuardian`), `pauseMint` / `resumeMint` |
| the Pyth leg: repointing the feed, loosening a limit | tightening an age or the confidence bound |

`transferGovernor` is instant and one step. Every governed setter is sent **from the Safe**: build the calldata, propose
it in the Safe, collect two signatures, execute. A delayed one is `schedule(bytes)` now and `execute(bytes)` after the
delay, with the same calldata, both from the Safe:

```bash
CALL=$(cast calldata "setVerifier(address,bool)" $NEW_VERIFIER true)
cast calldata "schedule(bytes)" $CALL     # propose this to the Safe, target $ESCROW
cast call $ESCROW "readyAt(bytes32)(uint256)" $(cast keccak $CALL) --rpc-url $RPC_URL
# ... GOVERNANCE_DELAY later, and within 14 days:
cast calldata "execute(bytes)" $CALL      # propose this to the Safe, target $ESCROW
```

Calling a delayed setter directly reverts with `ChangeMustBeScheduled(selector)`. That is the contract working.

### Entrypoint owner actions, through the timelock

Every one is two Safe transactions seven days apart, to the timelock (`$TIMELOCK` in the record, `contracts.ownership`):

```bash
OP=$(cast calldata "withdrawFees(address,address)" $MOVVA_TOKEN $TREASURY)            # what OWNER_ROLE calls
SALT=$(cast keccak "withdraw-fees-$(date +%F)")
cast calldata "schedule(address,uint256,bytes,bytes32,bytes32,uint256)" $ENTRYPOINT 0 $OP 0x$(printf '0%.0s' {1..64}) $SALT 604800
#   -> propose to the Safe, target $TIMELOCK. CallScheduled is public for the whole 7 days.
cast call $TIMELOCK "hashOperation(address,uint256,bytes,bytes32,bytes32)(bytes32)" $ENTRYPOINT 0 $OP 0x$(printf '0%.0s' {1..64}) $SALT --rpc-url $RPC_URL
cast call $TIMELOCK "isOperationReady(bytes32)(bool)" $ID --rpc-url $RPC_URL           # true after 7 days
cast calldata "execute(address,uint256,bytes,bytes32,bytes32)" $ENTRYPOINT 0 $OP 0x$(printf '0%.0s' {1..64}) $SALT
#   -> propose to the Safe, target $TIMELOCK
cast calldata "cancel(bytes32)" $ID                                                    # the Safe, any time before
```

The same shape upgrades the Entrypoint (`upgradeToAndCall`), reconfigures the Movva pool (`updatePoolConfiguration`),
or replaces the ASP postman (`grantRole` / `revokeRole`). The rehearsal drove one such operation end to end on the fork
(scheduled by the Safe, refused before the delay and for the deployer after it, executed by the Safe), inside a
snapshot it then reverted.

## zkTLS endpoints

**PIX, boleto and TED settle only through this path** (SR2-34). `ReclaimZkTlsVerifier` is the only verifier;
`FiatEscrow.postOffer` and `OffRampEscrow.openSale` refuse a verifier that does not prove a bank session. A proof settles
only against an allowlisted endpoint: the Reclaim `providerHash` of the bank's provider template, the URL prefix its
`url` must start with, and the rails it may prove (2 = PIX, 6 = PIX + BOLETO).

`MOVVA_RAIL_ZKTLS_ENDPOINTS=<endpoints.json>`, a list of `{ "kind", "providerHash", "urlPrefix", "railMask" }`, replaces
the illustrative receipt templates the rehearsal uses. Before listing an endpoint, check, and have a second person check:

- the prefix is `https://<exact lowercase host>/...` for the bank's real API host;
- the template's `responseMatches` capture **every** field the verifier reads (`bankTxId`, `payeeKeyHash`, `payerRef`,
  `amountBrlCents`, `paidAt`, `rail`) from parts of the response the payer cannot write (SR2-11);
- `providerHash` is what `hashProviderParams` in `packages/ramp/src/reclaim.ts` computes for that template;
- the BOLETO rail is set only where the template captures the paid barcode, hashed, and the amount from the
  bank-written receipt.

## Prices

- **The USDT/USD leg** (the reserve's): Chainlink USDT/USD `0x3E7d1eAB13ad0104d2750B8863b489D65364e32D`, max age 90,000 s
  (its daily heartbeat while the peg holds, plus an hour).
- **The FX leg, default on mainnet: Chainlink BRL/USD** `0x3126E7F38D5f60f4E2B6ec3511C7bdbD79317Df1` ("BRL / USD",
  8 decimals, 24 h heartbeat, 0.5% deviation) through a keyless `ChainlinkFxOracle`: every setting immutable, no governor.
  Its max age is 93,600 s (26 h) on the leg and on the reserve. Its **rate refuses outside FxMarketHours' core session**
  (13:30-21:00 UTC, weekdays; `MarketClosed`), so the reserve mints and redeems only while the FX market trades; its
  **band** reading answers at every hour, so the escrows trade at night and at weekends on the last answer. Never configure
  the retired proxy `0x0eBDc65E7e9132Cb41ac5cbD0101B799D7aDb475` (it answers a contract `No access`; DeployMovva refuses it).
- **Or Pyth** (`MOVVA_FX_SOURCE=pyth`): a `PythFxOracle` over FX.USD/BRL on `0x4305FB66699C3B2702D4d05CF36551390A4c69C6`,
  max age 3,600 s, closed-market max age four days, confidence bound 100 bps. Pyth exists on Ethereum only once someone
  posts it: **nothing prices until the keeper (`packages/yield`) has posted on mainnet**, and inside the core session it
  must post at least hourly. Its governor is the Safe.

`npx tsx scripts/fx-parity.ts` compares the two (first run, 19 October 2026: +1.46 bps). The monitor reads
`MarketClosed` as the closed market, as it reads `StaleRate` for Pyth (`MOVVA_RATE_WARN_SECONDS=90000
MOVVA_RATE_FAIL_SECONDS=93600` for the Chainlink leg).

## 1. Rehearse on a mainnet fork

The rehearsal is the test. Run it on the day, from the machine that will deploy, ideally inside the FX core session
(outside it the rate refuses by design and the verification marks those reads `expected`):

```bash
MAINNET_RPC=<archive-capable RPC> MAINNET_DEPLOYER_ADDRESS=<deployer> \
MOVVA_RAIL_GOVERNOR=<governor Safe> MOVVA_RAIL_ROLES=roles.json MOVVA_RAIL_ZKTLS_ENDPOINTS=endpoints.json \
MOVVA_RAIL_BREAKER=off \
  npx tsx scripts/deploy-movva-rail.ts --chain mainnet --port 8953 --out deployments/mainnet-movva-rail.rehearsal.json
```

Without `MAINNET_RPC` a rehearsal falls back to the read-only `https://ethereum-rpc.publicnode.com`. Without
`MOVVA_RAIL_GOVERNOR` / `MOVVA_RAIL_ROLES` it uses the test seed's Safe and identities and prints each as a
`MAINNET (fork rehearsal)` warning - exactly what a live run would refuse. With a named Safe the fork impersonates its
owners (approveHash, then execTransaction): the Safe's own threshold check still runs.

What the 21 October 2026 rehearsal did (`deployments/mainnet-movva-rail.rehearsal.json`, its record directory beside it):
fork of mainnet at block 26,239,817, commit b7769a3, a fresh deployer; 56 transactions, 39,097,304 gas; **267 pass, 3
expected (the Chainlink rate outside the core session: MarketClosed), 0 fail**; 20/20 addresses run this build; the
governor Safe governs all 7 governed contracts with setup closed by it; OWNER_ROLE held by the EntrypointTimelock alone;
upstream's ETH pool wound down and removed.

The Sepolia rehearsals of the same code are `deployments/sepolia-movva-governed-rail.rehearsal.json` (deployed),
`...finalized.rehearsal.json` (finalized, timelock owner), `...renounced.rehearsal.json` (finalized, `--owner-mode
renounce`) and `deployments/sepolia-movva-final-rail.finalize.rehearsal.json` (the live 20 October rail, resumed through
the new steps and finalized on a fork, with its hedge sleeve and permissionless pair; rehearsed from commit 1209c48,
before the escrow and DelayedGovernance fixes of 21 October were merged. A resume refuses a checkout whose deployed
inputs differ from the rail's, so that rail's governance hand-over and finalize run from a checkout of its own contract
sources with these scripts, not from this branch's HEAD).

## 2. Deploy

```bash
MAINNET_RPC=... MAINNET_DEPLOYER_ADDRESS=... MAINNET_DEPLOYER_KEY=... \
MOVVA_RAIL_CONFIRM=deploy-to-ethereum-mainnet-from-<deployer, lowercase> \
MOVVA_TEST_KEY_SEED=<a secret> MOVVA_RAIL_GOVERNOR=<governor Safe> MOVVA_RAIL_ROLES=roles.json \
MOVVA_RAIL_ZKTLS_ENDPOINTS=endpoints.json MOVVA_RAIL_BREAKER=off \
  npx tsx scripts/deploy-movva-rail.ts --broadcast-mainnet --out deployments/mainnet-movva-rail.json
```

It refuses unless: the RPC answers chain id 1 and is not a local node; the tree is a commit; the confirm phrase names
mainnet and this deployer; the key is the deployer's; the governor Safe and every role are named, and none is a test
identity; no endpoint is illustrative; the owner mode is the timelock; a full rehearsal on a fresh mainnet fork passes
with zero failures; and the deployer holds twice the measured gas at today's price. Then, in order:

1. **safes**: reads the governor Safe (1.4.x, at least 2 of 3, no module, not the deployer's).
2. **protocol**: upstream's `Deploy.s.sol:EthereumMainnet` (verifiers, the Entrypoint behind its proxy, upstream's ETH
   pool), owner and postman the deployer for the length of the run.
3. **usdt**: reads Tether's USDT (no stand-in).
4. **movva**: `DeployMovva.s.sol` - reserve and token, the FX leg, the band adapter, FeeSplitter and NodeRewards - wired by
   the deployer and handed to the Safe with setup **open** (`MOVVA_LEAVE_SETUP_OPEN=yes`). On chain id 1 it refuses a
   governor that is the deployer or has no code.
5. **pools**: the Movva PrivacyPoolComplex through CreateX with upstream's salt, `registerPool` (1 Movva minimum, 10 bps
   vetting fee, 100 bps relay-fee cap).
6. **asp**: the 2-of-3 AspRootQuorum; `grantRole(ASP_POSTMAN, quorum)`, `revokeRole(ASP_POSTMAN, deployer)`; the quorum
   is then the only holder.
7. **ramp**: `DeployRamp.s.sol` with `MAIN_PAIR=off`: the registry, the zkTLS verifier and the Movva pair, handed to the
   Safe with setup open (`LEAVE_SETUP_OPEN=yes`).
8. **bind**: `admin rewards:registry` builds `NodeRewards.setRegistry(registry)`, checked.
9. **governance**: **the Safe signs here.** One Safe transaction, a MultiSendCallOnly batch: the bind, then
   `completeSetup()` on every governed contract, the reserve last. With real signers the run stops with the transaction,
   its safeTxHash and a Safe{Wallet} Transaction Builder file in the work dir (`governance.safe-tx.json`); the signers
   execute it, and the same command with `--resume` continues.
10. **owner**: while the deployer still owns: `windDownPool` and `removePool` on upstream's unused ETH pool (it refuses
    if the pool was ever used), `withdrawFees` for MOVVA and ETH to the treasury if the Entrypoint holds any (its balance
    is then checked 0), the Movva pool's configuration checked. Then the EntrypointTimelock, `grantRole(OWNER_ROLE,
    timelock)`, `renounceRole(OWNER_ROLE, deployer)`, and the exact holder set.
11. **verify** and **record**, read-only (section 2b).

Every step is written to the deployment JSON as it completes; a stopped run resumes with `--resume`, and an interrupted
forge broadcast is continued, never re-run.

## 2b. The record, before anything else

The run writes `deployments/mainnet-movva-rail/`: `VERIFICATION.md`, `privileges.json`, `etherscan-verify.sh`, `abi/`.
It checks every address's code against this checkout's build (immutables masked, libraries linked), every creation
transaction's init code and constructor arguments, and every source file's hash; records the build hash and fails if a
build input is uncommitted; dry-runs each `forge verify-contract` command; and takes the privilege inventory - every role
holder, switch and EIP-1967 slot, every state-changing function probed from a stranger, the deployer and each holder.
**Stop on any failure.** `npx tsx scripts/deploy-movva-rail.ts --verify deployments/mainnet-movva-rail.json --rpc
$MAINNET_RPC` re-runs it read-only at any time.

Then verify the sources on Etherscan: `ETHERSCAN_API_KEY=... bash deployments/mainnet-movva-rail/etherscan-verify.sh`. Library
paths in it are spelled through the remapping (`poseidon-solidity/PoseidonT3.sol:...`); do not "fix" them.

## 3. Check the wiring before any money moves

The verification is these checks as code; read them by hand once more:

```bash
for C in $MOVVA_RESERVE $FEE_SPLITTER $NODE_REWARDS $REGISTRY $ZKTLS $MOVVA_ONRAMP $MOVVA_OFFRAMP; do
  cast call $C "governor()(address)" --rpc-url $RPC_URL          # the governor Safe, every one
  cast call $C "setupComplete()(bool)" --rpc-url $RPC_URL        # true
  cast call $C "pendingChanges()(uint64)" --rpc-url $RPC_URL      # 0: nothing risk-increasing already queued (M-06)
  cast call $C "GOVERNANCE_DELAY()(uint256)" --rpc-url $RPC_URL  # 172800
done
cast call $MOVVA_ONRAMP "TAKER_DISPUTE_TIMEOUT()(uint64)" --rpc-url $RPC_URL   # 432000 (5 days, H-04)
cast call $MOVVA_ONRAMP "MAX_VETTING_FEE_BPS()(uint256)" --rpc-url $RPC_URL    # 10: >= the Movva pool's vettingFeeBPS
ROLE=$(cast keccak OWNER_ROLE)
cast call $ENTRYPOINT "hasRole(bytes32,address)(bool)" $ROLE $TIMELOCK --rpc-url $RPC_URL   # true
cast call $ENTRYPOINT "hasRole(bytes32,address)(bool)" $ROLE $DEPLOYER --rpc-url $RPC_URL   # false
cast call $TIMELOCK "getMinDelay()(uint256)" --rpc-url $RPC_URL                             # 604800
cast call $TIMELOCK "hasRole(bytes32,address)(bool)" $(cast keccak EXECUTOR_ROLE) 0x0000000000000000000000000000000000000000 --rpc-url $RPC_URL   # false: not open
cast call $ENTRYPOINT "assetConfig(address)(address,uint256,uint256,uint256)" 0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE --rpc-url $RPC_URL   # all zero: ETH pool removed
cast call $ENTRYPOINT "assetConfig(address)(address,uint256,uint256,uint256)" $MOVVA_TOKEN --rpc-url $RPC_URL   # the Movva pool, 1e18, 10, 100
cast call $ZKTLS "provesBankSession()(bool)" --rpc-url $RPC_URL                             # true
cast call $MOVVA_RESERVE "bandBrlPerUsdtE18()(uint256,uint64)" --rpc-url $RPC_URL           # ~5.06e18 at any hour
cast call $MOVVA_RESERVE "brlPerUsdtE18()(uint256,uint64)" --rpc-url $RPC_URL               # the same inside the core session; MarketClosed outside
for E in $MOVVA_ONRAMP $MOVVA_OFFRAMP; do
  cast call $E "assets(address)(address,uint8,bool)" $MOVVA_TOKEN --rpc-url $RPC_URL        # $MOVVA_RESERVE, 18, true
  cast call $E "assets(address)(address,uint8,bool)" 0x0000000000000000000000000000000000000000 --rpc-url $RPC_URL   # enabled = false
done
```

`DeployMovva`, `DeployRamp`, `DeployEscrowPair` and `DeployPermissionlessRegistry` refuse, on chain id 1, a governor
with no code or equal to the deploying key, and `DeployRamp` refuses a `MAX_VETTING_FEE_BPS` below the fee the pool
charges at deploy. A `DelayedGovernance` contract refuses `schedule` until its setup is complete, so `pendingChanges` is
zero at hand-over; anything it counts afterwards was scheduled in public, after setup, and waits the full delay.

The on-ramp's two new immutables (the escrow fixes of 21 October 2026): a dispute its taker raised expires after
`TAKER_DISPUTE_TIMEOUT` (5 days, bounded 3-7), and a shielded delivery is refused above `MAX_VETTING_FEE_BPS` (10, at
most 100) of vetting fee. **A timelock operation that raises the Movva pool's vettingFeeBPS above that cap stops every
shielded delivery** (the escrows deliver in the open instead): keep the two in step. The orchestrator passes both
explicitly (`TAKER_DISPUTE_TIMEOUT`, `MAX_VETTING_FEE_BPS`), records them in the deployment's parameters, and verifies
them.

## 3b. Before the first gateway opens

- **Seed the buffer**: `recapitalize` to the 108% target, so the reserve starts at rest (`docs/movva.md`, "Sizing the
  buffer"). Inside a core session: minting and redeeming wait for the market.
- **Gateways** beyond `MOVVA_GATEWAYS` are admitted with `admin movva:gateway` from the Safe, which waits out the delay.
  Onboarding is `runbook-lp-onboarding.md`; the hedge is `runbook-movva-hedge.md`.

## 3c. The gas sponsor: stake it, or no public bundler carries it

Public bundlers run each operation's validation under ERC-7562 and drop what breaks it. `SponsorPaymaster` passes only
with a **stake at the EntryPoint** (its validation reads its own storage and returns a context for `postOp`). Unstaked,
every sponsored operation is refused. Stake at least 1 ETH with an unstake delay of at least 86,400 s, separate from the
gas deposit; SponsorGate owns the paymaster, so its governor sends it:

```bash
npm run -w @mova/ops admin -- paymaster:add-stake $SPONSOR_GATE 86400 1000000000000000000
cast call 0x0000000071727De22E5E9d8BAf0edAc6f37da032 'getDepositInfo(address)((uint256,bool,uint112,uint32,uint48))' $PAYMASTER
# expect: (deposit, true, stake >= 1e18, 86400 or more, 0)
```

**Never `unlockStake` while the paymaster sponsors anyone**: bundlers refuse every sponsored operation from that block.

## 4. Start the monitor (and the keeper, on the Pyth leg) before the first trade

```bash
RPC_URL=$MAINNET_RPC PP_ENTRYPOINT=$ENTRYPOINT MOVVA_RESERVE=$MOVVA_RESERVE ORACLE=$BAND_ADAPTER \
ESCROW=$MOVVA_ONRAMP OFFRAMP_ESCROW=$MOVVA_OFFRAMP RELAYER=$RELAYER PAYMASTER=$PAYMASTER \
MOVVA_RATE_WARN_SECONDS=90000 MOVVA_RATE_FAIL_SECONDS=93600 ALERT_WEBHOOK=$SLACK_WEBHOOK \
  npm run -w @mova/ops monitor
```

Confirm by hand, once: `curl $MONITOR/status` lists every check with a reading. A `ChangeScheduled` event on a governed
contract, or a `CallScheduled` on the timelock, that nobody on your side proposed means a Safe signer set is
compromised: the delay is your window. Revoke, suspend and pause are instant; `cancel` the timelock operation from the
Safe; tell LPs and users to exit.

With `MOVVA_FX_SOURCE=pyth` the Pyth keeper must already be running: it is what makes anything price.

## 5. First trade, deliberately small

The smallest amount the Movva pool's minimum allows (1 Movva), with an LP who knows it is a test. Watch the whole path:
the order locks, the zkTLS proof of the LP's bank session verifies, the escrow releases, the shielded balance appears,
the monitor stays quiet. Then the reverse: an off-ramp whose BRL lands in a real bank account, settled by the LP's proof
of its own payout.

## 6. Finalizing, if the client chooses it

`--finalize` (`npx tsx scripts/deploy-movva-rail.ts --broadcast-mainnet --finalize --resume --out
deployments/mainnet-movva-rail.json`) gives up every power the contracts' own functions allow giving up, only after every
check has passed, least reversible last. Rehearse it on a fork first, exactly as section 1, with `--finalize --resume`
on a copy of the record.

**A. Checks, before anything is sent**: the Movva pool registered and upstream's ETH pool already removed; the
privilege inventory and every role holder exactly the recorded set; OWNER_ROLE held by the recorded EntrypointTimelock
alone and the deployer holding no Entrypoint role; the postman the recorded quorum running this build's code; no queued
hedge withdrawal; no permanent role held by a test identity (refused on chain id 1, whatever any variable says); minting
not paused; and every governor - the rail's and its **siblings'** (any record in `deployments/` naming the rail's
reserve, registry or token: the hedge sleeve's HedgeSubWallet, a permissionless escrow pair; or `--siblings`) - the Safe,
the deployer or already `0x...dEaD`. A chain scan of `GovernorTransferred` / `SetupCompleted` since the rail's first block
must find no contract governed by the deployer or the Safe outside that set (M-19). The sleeve's keeper and the venue's
operator are EOAs by design: each must equal its record (`MOVVA_FINALIZE_SLEEVE_KEEPER=revoke` revokes the keeper).

**B. Then**: the reserve's guardian to `0x...dEaD` (by the Safe), with `mintPaused` read around it; the Entrypoint
untouched - the timelock keeps OWNER_ROLE; every governor, the rail's and the siblings', to `0x...dEaD` in one Safe batch
(`completeSetup` first where still open). The record is re-taken: every governor `0x...dEaD`, the deployer and the Safe
refused by every governor function, OWNER_ROLE with the timelock alone.

**What remains, by necessity**: the AspRootQuorum's three ASPs; the escrows' arbitrator Safe; the zkTLS witnesses; the
gateway(s) and institutional LP(s); the reserve's treasurer and hedge treasury Safes; the FeeSplitter's treasury; the
EntrypointTimelock and the Safe behind it (every Entrypoint action, 7 days); a sibling sleeve's keeper and venue operator.
The reserve's **guardian does not remain**: it goes to `0x...dEaD` with the governors (C2), so after finalizing nobody can
pause minting. None of the remaining keys can be rotated by a governor again, because there is none.

Fees: with the timelock as owner the vetting fee (10 bps) stays and stays collectable - `withdrawFees` is a 7-day timelock
operation. `--owner-mode renounce` (testnets only) instead withdraws every fee, sets the vetting fee to 0 and the relay
cap to 300 bps (a cap that must last for ever: a 1% cap leaves small withdrawals unrelayable at a gas spike), prints a
loud warning that both become immutable, and then renounces OWNER_ROLE.

## If something is wrong after deployment

Mova's contracts are immutable: no proxy, no upgrade path, no admin withdrawal. The one upgradeable contract is the
Entrypoint (upstream's UUPS proxy), and only through the timelock. Every action below is **instant** for the governor
Safe, unless marked. **After section 6, no governor action exists.**

| Problem | Action |
|---|---|
| The zkTLS verifier or a bank endpoint is wrong | `setVerifier(<verifier>, false)` on both escrows, or `revokeEndpoint(<providerHash>)` on the verifier. Revoking the verifier stops every PIX and boleto settlement |
| A witness key leaked | `setWitness(<key>, false)`. The threshold does not drop with it; schedule a replacement |
| An arbitrator key leaked | `setArbitrator(<key>, false)` on both escrows. A replacement waits out the delay - keep a second arbitrator registered |
| The BRL rate is wrong | `pauseMint()` (the guardian or the Safe), then repoint the reserve's oracle (`setOracle`, delayed). On the Pyth leg, tighten `setLimits` (instant). The escrows' band reads the same leg: delist Movva on both escrows if bad offers pass |
| The Pyth keeper is down (Pyth leg only) | Restart it, or post an update by hand from any funded key; posting is permissionless |
| Chainlink BRL/USD missed its heartbeat inside the session | Minting, redeeming and the bands refuse (`StaleAnswer`) until it posts; nothing to repoint at once |
| Tether paused USDT or blacklisted the reserve | The reserve cannot move USDT; `pauseMint()`, tell gateways. What it holds is frozen until Tether acts |
| An LP is misbehaving | `setTier(<lp>, 4, 0)` (`SUSPENDED`) on the registry; `setGateway(<lp>, false)` on the reserve |
| A Safe signer set is compromised | Governed contracts: the delay is the window - users and LPs exit, the remaining signers `transferGovernor` to a fresh Safe (instant). Entrypoint: the Safe `cancel`s any timelock operation it did not intend; a new proposer is itself a 7-day operation |
| The Entrypoint needs a fix | An `upgradeToAndCall` scheduled through the timelock: public for 7 days before it can run |
| Something worse | A new deployment with explicit user migration. Users can always exit: escrow timeouts refund permissionlessly and pool ragequit needs no service |

Re-enabling anything in this table is a delayed change.
