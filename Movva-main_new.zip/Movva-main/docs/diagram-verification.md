# The architecture diagram, box by box

**What this is.** Every box of the Movva architecture diagram ("Privacy-Preserving Payments Rail on Ethereum L1"),
checked against what this repository actually does, with the command or file that proves it. Written 17 September 2026,
against commit `74f84b1` on `phase-1-shielded-rail`.

**How to read the status column:**

| | Meaning |
|---|---|
| **Works** | Proven by a run against the real contracts on a local chain, or by the contracts' own test suite. |
| **Works, differs** | Built and proven, but not as the diagram draws it. The difference was decided deliberately and is stated here. |
| **Built, never real** | The code exists and is tested, but has never run against a real bank, a real chain or a real counterparty. |
| **Not built** | Named in the diagram, absent here. |
| **Removed (D1)** | Built, then deleted by client decision D1 (14 October 2026), which removed savings (sMovva, its shielded pool, the savings relayer) from M1. |

**Update, 15 October 2026.** Since D1 the scope is deposit PIX -> mint MOVVA -> hold as shielded notes -> withdraw to
PIX, and yield is Movva's (the issuer's), not a user product. The rows below that showed savings as working now say so.

**The runs referred to below**, all on a local chain against real bytecode, each printing OK or FAIL per check:

| Run | Checks |
|---|---|
| `packages/lp-node/examples/lp-node-live.ts` | 54 |
| `packages/lp-node/examples/lp-node-movva-live.ts` | 54 |
| `packages/smart-account/examples/accounts-live.ts` | 65 |
| `packages/cosigner/examples/cosigner-live.ts` | 93 |
| `packages/smart-account/examples/erc7562-live.ts` | 51 |
| `packages/wallet/examples/movva-wallet-live.ts` (EOA / Kernel / Safe) | 126 / 163 / 163 |
| `npx playwright test -c packages/app/e2e` (the app in Chromium) | 21 tests |

Plus 2,340 TypeScript tests, 820 Solidity tests, 53 in the smart-account project, and `npm run verify -- --offline`
(fork provenance), 7 passed.

## 1. Ramp On (deposit to yield)

| Diagram box | Status | What proves it |
|---|---|---|
| **User** — deposits reais (PIX/boleto), sees a BRL balance, self-custody | **Works** | The wallet run buys by PIX and boleto and states every balance in reais; the app shows R$ amounts only. |
| **Fiat Ramp Network** — PIX, boleto, credit card; licensed LPs/PSPs; OTC desks and fintechs; P2P partners | **Works** for the software, without the credit card; **Built, never real** for the partners | The LP node runs PIX and boleto against a mock bank; the credit card was removed from the MVP on 24 September 2026 (Rev. 3 §2.2). No real bank has been connected, and there are no real LPs yet. |
| **BRL → USDT** — liquidity providers, oracle price bands (Pyth/Chainlink USD/BRL) | **Works** | The LP node quotes inside a band built from Chainlink USDT/USD and Pyth FX.USD/BRL; an offer outside the band is refused. `PythFxOracle`, `ChainlinkSignedFxOracle`, `ScaledFxBandOracle`. |
| **Mint MOVVA** — "1:1 with USDT (on-chain)" | **Works, differs** | Movva is pegged to **R$ 1,00**, minted against USDT at the oracle rate, not one Movva per USDT. The client decided this on 14 September; the reasons are in [movva.md](movva.md), "Where this differs from the architecture diagram". The gateway run mints, redeems and burns on the real reserve. |
| **Wallet Client** — smart account (Safe/Kernel), ERC-4337 + passkey + MPC, manages funds and viewing keys | **Works** | Safe 2-of-2 (passkey + server co-signer) by default, Kernel optional, both through EntryPoint v0.7, a real bundler and a paymaster. FROST (MPC) accounts work too. The whole Movva flow runs from a smart account. |
| **Yield** — USDT in segregated vaults, staking and tokenized T-bills, yield to MOVVA | **Removed (D1)** for users; **Built, never real** for the strategies | There is no user yield: sMovva and its vesting distributions were removed with savings, and the reserve's surplus stays in the reserve as Mova's. The reserve can place its USDT in one ERC-4626 `YieldVault` (`setYieldVault`, governor-delayed), whose adapters are sUSDS, Aave v3 USDT, Lido staking and Superstate USTB. No strategy has run with real money, and the T-bill fund must allowlist the vault first. |

## 2. Infrastructure and services

| Diagram box | Status | What proves it |
|---|---|---|
| **Relayers (ERC-4337)** | **Works** | The Privacy Pools relayer submits shielded exits (`ProtocolRelayer`). (Mova's own `@mova/zap-relayer`, which submitted savings moves, is **Removed (D1)**.) Account abstraction itself is the bundler plus `SponsorPaymaster`, so a user never holds ETH. |
| **Watchers (transaction monitoring)** | **Works** | `packages/ops` monitor: pools, oracles and their freshness, escrows, the Movva reserve's ratio and rate, relayer and paymaster funding, the paymaster's stake, sponsorship budget, governance changes, node rewards. It runs in the dev stack and reports its sweeps. |
| **Attestors (zkTLS proofs)** | **Works, differs** | PIX, boleto and TED settle **only** on a zkTLS proof of the bank session; the attestor quorum and its keys were deleted on 24 September 2026. That is stricter than the diagram, decided on 14 September (SR2-34), because a colluding quorum could otherwise release a bank payment that never happened. Every bank proof so far is signed by local test witnesses over a mock bank: no real Reclaim session yet. |
| **Keepers (automation)** | **Works** | Three: the yield vault keeper (through `KeeperGate`), the HyperEVM keeper and the Pyth keeper. None can pay itself. (The Movva distribution keeper is **Removed (D1)**.) |
| **Replicated on Flux** | **Not built** (specs only) | Flux specs exist for the matcher, note vault, monitor and the keepers (the distribution keeper's spec went with savings, D1). Services that hold keys (LP node, co-signer) are deliberately never Flux apps, since a Flux node operator can read an app's environment. Nothing is deployed to Flux; that needs your account and collateral. |
| **Strict invariant** — if any service dies or is compromised, no user loses funds or access | **Works, differs** | Checked service by service in [availability.md](availability.md), which says plainly where it does **not** hold: some outage combinations freeze funds, and colluding witnesses (bank rails) can release an LP's escrow. A user's shielded funds cannot be taken by any single service, and a private withdrawal needs no service of Mova's. Since 15 September the co-signer also pushes an alert when a recovery is queued, so a stolen passkey cannot quietly wait out the 7-day delay. |

## 3. Ramp Off (exit yield to fiat)

| Diagram box | Status | What proves it |
|---|---|---|
| **User** — requests withdrawal (USDT → BRL) by PIX/boleto | **Works** | The wallet sells to a PIX key and pays a boleto, both from an account unlinked to the user. |
| **Sell USDT to liquidity provider nodes** | **Works** | The off-ramp escrow holds the sale until the LP proves the bank payment; the LP node claims, pays and proves. |
| **Burn MOVVA** — convert back to USDT | **Works, differs** | The LP node redeems the Movva it bought at the reserve, which burns it against USDT at the oracle rate, not 1:1. |
| **Receive BRL** — PIX or boleto to the user's bank account | **Works** | PIX payouts and paying a boleto for exactly its amount, each proven by zkTLS. A bill due today is refused near midnight in Brasília, when an LP could no longer pay it. |
| **Yield back to MOVVA** — auto-compound yield and rewards | **Removed (D1)** for yield; **Works** for rewards | sMovva and its distributions were removed with savings: no yield goes back to holders. Node-provider rewards are claimed by the LP node. |

## 4. Selective disclosure (viewing key)

| Diagram point | Status | What proves it |
|---|---|---|
| Derived from the spending key (read-only) | **Works** | The viewing root comes one-way from the spending key; tests assert viewing material yields no spending authority. |
| Scoped and temporary (time or transaction range) | **Works** | Grants cover a fiscal period or named transactions, with a validity window. |
| Revocable by the user | **Works** | Registered on `AuditGrantRegistry`; revoking stops the note vault releasing anything further, and issuing seals the note chains so no key reads later notes. |
| Shared with auditors or tax authorities to prove balances and income | **Works** | The wallet run issues grants and an auditor verifies the balance against the chain, then produces one statement for the period, with the tax year's figures. (The sMovva balance it also covered went with savings, D1.) |

## 5. Incentives and fees

| Diagram point | Status | What proves it |
|---|---|---|
| Fee from transactions (user ↔ node provider) | **Works** | The reserve charges mint and redeem fees, each proven against its own events in the runs; the LP's spread is its own. |
| Yield share (from vaults) | **Works, differs** | All of the reserve's yield is Mova's: it stays in the reserve as surplus and leaves only through the hedge path. The distribution fee, Mova's share of yield paid to savers, is **Removed (D1)**. |
| Node provider rewards | **Works** | `NodeRewards` pays LPs a share of Mova's fees in proportion to settled volume, fed by `LPRegistry`'s hook, with `FeeSplitter` forwarding that share. The share is **0 at deployment** until you set it. |

## 6. Key architectural decisions

| Decision | Status | Notes |
|---|---|---|
| Fork Privacy Pools, no new zk circuits | **Works** | `protocol/` is upstream's code at commit `c312dcd58f`. `npm run verify -- --offline` passed all 7 checks it can run without the network, upstream's own audited suite (110 tests) included. Three need the network and run in CI: the byte-for-byte comparison against a fresh upstream clone, the circuits reproducing their vendored artifacts, and the fork-based integration suite. Everything shielded uses upstream's circuits only. |
| Reuse Safe/Kernel smart accounts | **Works** | Mainnet bytecode of Safe 1.4.1 and Kernel v3.1, with Mova's own validators for the passkey + co-signer rule. |
| Reuse existing relayer infra | **Works** | The upstream relayer service for exits. (Mova's own, for savings zaps, is **Removed (D1)**.) |
| Build the P2P ramp layer (escrow, zkTLS attestors, LP network) | **Works** | Two escrows, the LP registry with its tiers, both verifiers, the matcher and the LP node. |
| Build yield adapters | **Works, never real** | Four adapters, tested against forks of the real protocols where an RPC is available. |
| All funds in immutable Ethereum contracts | **Works** | No proxy over Mova's own contracts; risk-raising admin changes wait out a public delay (`DelayedGovernance`). |
| Off-chain services run on Flux | **Not built** | See above. |
| Network bootstrap: Phase A licensed LPs, B affiliated, C open retail | **Works** in code | The registry has the three tiers and the escrows enforce them. No real LP is onboarded. |
| BRL-only UX; deposit reais, see reais, withdraw by PIX/boleto | **Works** | The app is Portuguese and shows only reais. |
| USD/ETH exposure under the hood | **Works, differs** | The reserve holds USDT and states its backing ratio; the treasury and hedge design is written down ([runbook-movva-hedge.md](runbook-movva-hedge.md)) but no desk is running. |
| BRL ↔ USD: LP competition plus oracle sanity bands, no derivatives, no BRL perp | **Works** | Pyth FX.USD/BRL with Mova's keeper, Chainlink as the alternative, bands on every quote. No derivative is used anywhere. |

## 7. Technology stack and key features

| Item | Status | Notes |
|---|---|---|
| Ethereum L1, immutable contracts | **Works** | |
| Privacy Pools (0xbow fork) | **Works** | |
| Safe/Kernel smart accounts, ERC-4337 + passkey + MPC | **Works** | Also checked against a bundler that enforces ERC-4337's validation rules, which admits both account kinds: the co-signer creates a Kernel account at enrolment, so its first operation no longer carries the creation a bundler would refuse. |
| zkTLS (P2P verification) | **Works, never real** | Verifier, client and receipt templates are built and enforced on-chain; no Reclaim credential yet, so every proof so far comes from local test witnesses. |
| Pyth / Chainlink USD/BRL oracle | **Works, never real** | The Pyth leg has run only against a mock Pyth. Chainlink's BRL feed is stale since 2023, so Pyth plus Mova's keeper is the default. |
| Flux (off-chain services) | **Not built** | |
| Hyperliquid (delta-neutral yield) | **Built, never real** | The vault and keeper exist and are simulator-tested; nothing has traded on HyperCore. |
| Seedless self-custody, no loss if services fail | **Works, differs** | Passkey-derived, with recovery after a 7-day delay and alerts; the honest limits are in availability.md. |
| Shielded yield (staking, tokenized T-bills) | **Built, never real** for the reserve; **Removed (D1)** for users | The adapters invest the reserve's USDT; the shielded user path (router, share pool) was removed with savings. |
| Compliant, audit-ready, differentiated from mixers | **Works** | Deposits are vetted by the ASP; disclosures prove balances and income to an auditor. **No external audit has been done**, which remains the one gate before real money. |

## What is missing before this serves a real user

None of these is code:

1. Real liquidity providers, with bank accounts and PIX keys.
2. A Reclaim credential and a provider template per bank, because PIX and boleto settle only on zkTLS proofs.
3. A Pyth Hermes credential and a funded keeper key.
4. Keys in a KMS for the co-signer and its sponsor operator, plus a VAPID key for alerts.
5. A funded deployer, and the paymaster's 1 ETH stake.
6. Admin roles on a multisig.
7. An external audit.
8. A Flux account, if the services are to be replicated there.
