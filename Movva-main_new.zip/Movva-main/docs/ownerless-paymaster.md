# Ownerless paymaster

The client's decision B1 (14 October 2026): *"Ownerless paymaster. It sponsors only accounts that qualify by an
on-chain rule, with no signing key: accounts created by your account factory, under per-account rate limits.
Anyone can top up its deposit. Its stake is locked permanently and can never be withdrawn. No one can pause,
censor, or change the policy."* It pays gas for the primary account and for every sub-wallet's account.

`contracts/OwnerlessPaymaster.sol` implements it for EntryPoint v0.7. It is not in any deploy script yet;
`SponsorPaymaster` and `SponsorGate` are unchanged.

## What nobody can do

There is no owner, admin, signer, pause, setter or upgrade path, and no `delegatecall` or `selfdestruct` in
the runtime code. Every policy parameter is an immutable set in the constructor. The only state is the usage
counters, and only the EntryPoint can change them, through validation and `postOp`. The contract calls only the
immutable EntryPoint, and only `depositTo` and `addStake`.

- **Deposit.** Anyone tops it up: `deposit()`, a plain ETH transfer, or `EntryPoint.depositTo(paymaster)`.
- **Stake.** Anyone adds to it with `addStake()`, always with the immutable `UNSTAKE_DELAY_SEC` (at least one
  day). The EntryPoint lets only the staked address itself call `unlockStake`, `withdrawStake` and `withdrawTo`.
  This contract has no code that calls them, so the stake stays locked and the deposit leaves only as gas.

To retire it, stop funding it. To change the policy, deploy a new one. The old one keeps its stake, and keeps
sponsoring until its deposit runs out.

## Who qualifies

An account qualifies when its address is the CREATE2 address of one of two immutable factories, with that
factory's proxy init code hash, for a salt the operation supplies:

| Index | Factory | Proxy init code hash | CREATE2 salt the client supplies |
|---|---|---|---|
| 0 | Safe 1.4.1 `SafeProxyFactory` `0x4e1DCf7A…` | `keccak256(proxyCreationCode() ++ uint256(Safe 1.4.1 singleton))` | `keccak256(keccak256(initializer) ++ saltNonce)` |
| 1 | Kernel v3.1 `KernelFactory` `0xaac5D424…` | `keccak256(Solady ERC-1967 proxy over the Kernel v3.1 implementation)` | `keccak256(initData ++ salt)` |

The address is the proof, so no key and no registry are needed. One check covers both cases:

- **The op deploys the account (initCode).** The EntryPoint runs the factory and checks the result is `sender`
  before it calls the paymaster.
- **The account already exists.** The check is identical. A Kernel account is created by a plain transaction
  to `KernelFactory` before its first op (wallet-custody.md §10.3).

A sub-wallet's account (no passkey, its own key as the only owner) comes from the same factories. The rule never
looks at owners, so it qualifies the same way. The wallet already computes both salts when it predicts the
address (`predictSafeAddress`, `predictKernelAddress`).

**This is a filter, not a Sybil defence.** Both factories are public. Anyone can create any number of qualifying
accounts, free, with any owners. The rule fixes *what kind* of contract is sponsored: a proxy of a pinned
implementation. It cannot tell a user from an attacker. A proxy can later be pointed at other code by its owners,
which does not matter here: the rule bounds gas, not behaviour.

## Limits, and the trade-off the client should sign off

Time is cut into fixed windows of `WINDOW` seconds. The limits per window are:

- `MAX_COST_PER_OP` wei per operation (the EntryPoint's `maxCost`);
- `MAX_OPS_PER_ACCOUNT` operations and `MAX_COST_PER_ACCOUNT` wei per account;
- `MAX_COST_GLOBAL` wei for all accounts together.

**The global cap is the only bound on how fast the deposit can be drained.** One person running many accounts
through the public factory gets a full per-account budget for each of them. So the per-account limits only
spread the budget; they do not cap it. In any n consecutive windows the paymaster pays at most
(n + 2) x `MAX_COST_GLOBAL`: one extra window from fixed-window alignment, one from the grace period (below).

What the global cap costs is **availability**:

- An attacker can spend the whole global budget early in a window, free. Everyone is then unsponsored until the
  next window, and nobody can stop it, because nobody controls the contract.
- A bundler that is the attacker also keeps what the paymaster pays it: priority fees, `preVerificationGas`
  and EntryPoint v0.7's 10% penalty on unused gas. The budget can therefore be turned into the attacker's ETH at
  up to `MAX_COST_GLOBAL` per window.

Choose `MAX_COST_GLOBAL` as the loss per window you accept. Fund the deposit for the number of windows you are
willing to pay for: (n + 2) x `MAX_COST_GLOBAL` for n windows, and never less than **3 x `MAX_COST_GLOBAL`** (n = 1).
Below that, a worst-case burst inside one window's length of time empties the deposit before the cap binds, and every
operation fails AA31 until someone tops it up (SRM1-16). The deploy refuses less, `--verify` and the monitor
(`paymaster_global_cap`) flag a deposit that has fallen below it. A per-account or per-user limit that resists Sybils would need an identity the chain can
check, such as a passkey attestation or a signer. That is the key the decision rules out.

## Where gas is charged, and why there

Validation **reserves** `maxCost` against the account's counter and the global counter. `postOp` then refunds
the reservation down to an upper bound of the real cost.

**Why validation.** The EntryPoint validates every op in a bundle before it executes any. A cap that validation
only checks, and `postOp` settles, lets a bundle of N Sybil ops each pass against the same pre-bundle total, and
the cap is overshot N times. Reserving in validation means each op sees the reservations made before it.
`test_GlobalCapHoldsInsideOneBundle` shows this through the real EntryPoint.

**Why a bounded refund.** EntryPoint v0.7 tells `postOp` a cost that leaves out two things it adds afterwards:
`postOp`'s own gas, and the 10% penalty on unused execution gas. So `postOp` charges `actualGasCost` plus, at the
op's gas price:

    paymasterPostOpGasLimit + 10,000 + (callGasLimit + paymasterPostOpGasLimit) / 10

The charge is capped at `maxCost`. The real debit can never exceed `maxCost`, because `maxCost` is the prefund.
The EntryPoint's own overhead measured about 1,300 gas.

**If `postOp` reverts or does not run**, the EntryPoint undoes `postOp`'s changes but keeps validation's, so the
full `maxCost` stays charged. That is the safe direction. Validation refuses a `paymasterPostOpGasLimit` below
25,000. `postOp` uses about 5,000.

## ERC-7562

| Rule | How the contract complies |
|---|---|
| OP-011: no TIMESTAMP, NUMBER or other block data in validation | The client names the window in `paymasterData`. Validation returns `validAfter` = the window's start and `validUntil` = its end + `GRACE`, and the EntryPoint enforces them (AA32). So an op counted in window k can only execute in window k or its grace period, and no client can spend now against a future window. If a later window is already open, the op is counted there instead, so counters only move forward. |
| STO-031 / EREP-050: own storage and a context are allowed only to a staked paymaster | Validation writes the sender-keyed counter and the global counter, and returns a context. The paymaster must hold at least a bundler's minimum stake (Rundler: 1 ETH) with an unstake delay of at least one day. |
| No other calls in validation | Validation calls no other contract. Provenance is a keccak over calldata and immutables. |

**Shared state and reputation.** The global counter is shared, so when the global budget runs out, ops already
in a mempool fail on-chain, and a bundler may throttle this paymaster. That is the cap working, and it ends with
the window.

**Grace period.** `GRACE` (less than `WINDOW`) keeps an op signed near the end of a window valid long enough for a
bundler to accept it.

`packages/smart-account/examples/erc7562-ownerless.ts` sends the wallet's ops through Rundler v0.11.0 in safe
mode on geth. Run on 14 October 2026, and again on 18 October 2026 with Rundler's default arguments, every row did what it
expects (38 OK, 0 FAIL):

- the primary account on Safe: its first op (initCode, through the unstaked SafeProxyFactory) and a later op
  were accepted;
- the primary account on Kernel, created beforehand: its first op and a later op were accepted;
- a sub-wallet Safe: its first op (initCode) and a later op were accepted;
- a salt that does not produce the account was refused (`AA33`, `NotFromFactory`);
- the same code unstaked was refused for a later op and for a first op. Rundler's reason was "entity
  stake/unstake delay too low", naming slot 1 (the global counter), which is what STO-031 predicts.

The 14 October run used `RUNDLER_ARGS="--tracer_timeout 60s"`. On that machine, which was loaded, P-256 verification
under geth's JavaScript tracer overran Rundler's default 10 seconds on some passkey rows; the bundler reported
a tracer timeout, not a rule. The flag changes no validation rule. On 18 October the same happened once more, to O8
under load (it passed with the flag), and a run with the default arguments on a quieter machine passed every row.

**What the 18 October re-run fixed.** Since SRM1-5 the executors sign the bundler's least tip when the submitter says
what it is (`minPriorityFeePerGas`, which `BundlerSubmitter` reads from `rundler_maxPriorityFeePerGas`), else the node's
estimate floored at 0.001 gwei. The example's own submitter did not say, so every row signed 0.001 gwei and Rundler
refused all of them at its precheck ("maxPriorityFeePerGas is 1000000 but must be at least 50000000"), before any
validation rule ran: 29 OK, 9 FAIL. The example's submitter now forwards Rundler's figure, as `BundlerSubmitter` does.
`erc7562-live.ts` (the CI job) had the same gap, and one more: its X2 row computed the budget it must exceed with the old
fixed 1 gwei tip, about 20 times the real one, so X2 fitted under it and was accepted. It now prices X2 with the
executors' own fee source. Re-run on 18 October: 52 OK, 0 FAIL, and the two known Rundler refusals of a Kernel first
operation through the meta factory (B1, C1), which is why no Kernel operation carries initCode.

## paymasterAndData

    paymaster (20) ++ paymasterVerificationGasLimit (16) ++ paymasterPostOpGasLimit (16)
      ++ factory index (1) ++ CREATE2 salt (32) ++ window (uint48, 6)

The window is `floor(now / WINDOW)` (`currentWindow()`) when the op is signed. `accountAddress(index, salt)` and
`remaining(account)` are views for clients.

**The wallet builds it** (`packages/wallet/src/ownerless-paymaster.ts`, SRM1-17). `ownerlessPaymasterAndData(config,
account)` is passed as `SafeExecutor` / `KernelExecutor`'s `paymasterAndData`, which now also takes a function the
executor calls for every operation. It names the factory index and the CREATE2 salt from the account's own deployment
(Safe owners, threshold and salt nonce; Kernel initData and salt), the window from the latest block's timestamp, and
the validation gas for the chain (`ownerlessVerificationGas`: 300,000 on Sepolia, 200,000 elsewhere), and it refuses
before anyone signs when the salt does not produce the sender. `readOwnerlessPolicy` reads `WINDOW` and
`MAX_COST_PER_OP`; pass the latter as `paymasterMaxCostPerOp`. The app takes `account.ownerlessPaymaster: { address }`
in its deployment JSON in place of `paymasterAndData` (`packages/app/src/lib/deployment.ts`). That the contract accepts
these bytes is tested against the real bytecode: `packages/wallet/test/ownerless-paymaster-anvil.test.ts` sends the
executors' operations through the canonical EntryPoint v0.7 into `OwnerlessPaymaster` on anvil. Validation costs about 50,000 gas the first time an account is seen
(two fresh storage slots) and less after that. A `paymasterVerificationGasLimit` of 100,000 to 200,000 is ample on
an EVM with standard storage pricing. Sepolia does not price it that way: it charges about 105,000 gas per slot written from zero.
There, the paymaster's first op failed at 150,000 (`AA33`, out of gas), and 300,000 is what the Task 2 rehearsal signs
(docs/deployments.md).

## Onboarding without a SponsorGate

A fresh passkey account needs one thing on-chain before its first operation, and the paymaster cannot provide it:

- **A Safe** validates its first operation through its passkey owner, the `SafeWebAuthnSigner` proxy at its CREATE2
  address. Until that contract exists, `checkSignatures` has nothing to call and the operation fails validation.
- **A Kernel account** must already exist (wallet-custody.md §10.3): its initCode through `KernelFactory` writes the
  validator's storage during deployment, which ERC-7562 allows only with a staked factory (STO-022), and through the meta
  factory Rundler refuses it (`banned opcode: CREATE2`).

Both creations are permissionless calls on canonical factories. Until now only the co-signer's sponsorship module made
them, at enrolment, and only when `COSIGNER_SPONSOR_GATE` was set.

**The ways considered:**

| Way | Verdict |
|---|---|
| The first operation's initCode also creates the signer (a batched setup call) | Not admissible. ERC-7562 OP-031 allows CREATE2 once in the deployment phase, for the sender. A second one, the signer's, through an unstaked factory, is refused. |
| The first operation's calls create the signer (or the Kernel account) | Too late. Validation runs before execution and needs the signer; a Kernel operation without the account has no `validateUserOp` to call. |
| The app sends the creating transaction itself | The user holds no ETH: that is the reason for a paymaster. |
| A throwaway 1-of-1 Safe, sponsored by this paymaster, whose execution creates the signer or the Kernel account | Admissible: its first operation is a plain Safe deployment (row O5), and execution has no ERC-7562 limits. But each onboarding then costs the paymaster two operations from the shared global budget. That budget is the scarce resource here, and an attacker can already spend it free (see "Limits"). It also adds a client flow and a second account per user. |
| **The co-signer creates them, with no gate, from its operator key, bounded** | **Chosen.** |

**Why the co-signer.** Every passkey account is 2-of-2 with the co-signer (or, on Kernel, needs its signature in the
validator), so it already depends on the co-signer for every operation, including the first. Creating the signer at
enrolment adds no new party. The module already does exactly this in gate mode, with tested idempotency, a re-read
before each send, deployments rebuilt only from what the enrolment verified, rate limits, a daily cap, an operator float
floor and an audit record. Without a gate, the only change is that it skips allowlisting. The cost lands on an operator
key the deployment funds, not on the shared paymaster budget. The operations it unblocks are the ones the paymaster
pays for.

**The trade-off.** The operator key is a hot key holding ETH (KMS in production). What it can lose is bounded:

- at most `COSIGNER_SPONSOR_DAILY_CAP` accounts a day, each one signer creation or one Kernel account creation;
- the rate limits;
- its float, which the module refuses to go below.

A stolen key can spend only its own float, and has no power over the paymaster. If the co-signer is down, new accounts
cannot be readied. Their operations could not be co-signed either.

**Configured as:** `COSIGNER_SPONSOR_OWNERLESS_PAYMASTER=<paymaster>` instead of `COSIGNER_SPONSOR_GATE`, with the
operator key as before. The entrypoint refuses an address that does not answer `WINDOW()` and `MAX_COST_PER_OP()`.
`packages/cosigner/src/sponsorship.ts` then sends no gate call; audit records say `prepared` and carry `signerTx` or
`accountTx`, never `sponsorTx`. The view's status stays `sponsored`, so the app's `prepare()` is unchanged.

**Tested end to end:** `packages/app/test/ownerless-onboarding-anvil.test.ts`, on anvil, with:

- the canonical contracts from `packages/smart-account/fixtures`;
- `OwnerlessPaymaster` from the root build;
- the real co-signer service over HTTP, its module given no gate.

A fresh passkey Safe and a fresh passkey Kernel account each go through the app's `openSmartAccount` and `prepare()`. The
operator creates the signer (Safe) or the account (Kernel). The account's first operation goes through the EntryPoint into
the paymaster and is sponsored: recovery setup plus a call, passkey and co-signer signatures. A later operation is sponsored
too. The account never holds ETH. CI runs the test after the build. ERC-7562 admission of the same shapes is rows O1-O4
of the Rundler run above: O1 is a passkey Safe's first operation after a plain transaction created its signer.

The test also found, and fixed, an app bug that predates this work. The app installed recovery only while the account
had no code. A Kernel account always has code before its first operation, because the co-signer creates it, so it never
got recovery. The test is now whether the recovery Delay exists (`packages/app/src/wallet/account.ts`).

## Sub-wallets

A sub-wallet has no passkey and no co-signer. On a deployment whose paymaster is this one, its account is the 1-of-1 Safe
of its own account key (`subWalletSafe` in `packages/wallet/src/movva/subwallet.ts`, salted from the sub-wallet's root).
The canonical SafeProxyFactory creates it in its first operation, and the paymaster admits it by its address:

- `subWalletExecutor` and `soleOwnerSafeExecutor` build a `SafeExecutor` with `ownerlessPaymasterAndData`;
- the app opens a sub-wallet's session on that account (`WalletSession.open({ subWallet: true })`, `openSoleOwnerSafe`);
- the app opens the sub-wallet's sale accounts the same way, each a 1-of-1 Safe on a fresh key;
- `SubWalletManager` records the Safe as the sub-wallet's account, and `availability()` is ok wherever this paymaster is
  configured.

On a SponsorPaymaster deployment sub-wallets stay unavailable outside the dev stack, as before.

Tested:

- `packages/wallet/test/ownerless-paymaster-anvil.test.ts`: a sub-wallet's first operation (initCode) and a later one,
  sponsored.
- `packages/app/test/ownerless-onboarding-anvil.test.ts`: the same through the app's `openSoleOwnerSafe`, and a sub-wallet
  sale account's first operation. No co-signer enrolment.
- `packages/app/test/subwallets.test.ts`: availability, and the recorded account.

Row O5 is the same first operation through Rundler.

## To decide at deployment

`WINDOW`, `GRACE`, the four limits, the stake amount and the deposit (at least 3 x `MAX_COST_GLOBAL`). The constructor refuses incoherent
values: a zero or duplicate factory, a grace of at least one window, a per-op limit above the per-account limit,
a per-account limit above the global limit, a delay under a day. A wrong init code hash sponsors nobody. The
forge tests derive both hashes from the deployed factories, and the deploy step should check them the same way.

## Tests and tooling

- `contracts/test/OwnerlessPaymaster.t.sol` runs against the canonical bytecode in
  `packages/smart-account/fixtures`: EntryPoint v0.7, Safe 1.4.1, Safe4337Module, the passkey signer stack,
  Kernel v3.1 and its factory, and our vendored PasskeyCoSignerValidator. It covers:
  - sponsorship of each account kind;
  - refusals of accounts from another factory instance, from our factory with another singleton, and with a
    wrong salt;
  - each limit, and the global cap inside one bundle and across a window reset;
  - the clock binding at the window and grace boundaries;
  - funding by anyone, and that nothing can withdraw;
  - a fuzzed property: random Sybil bundles, gas limits, fees and clock moves, measured by what the EntryPoint
    actually debited. It checks per-op, per-account and global spend per window, and that the paymaster never
    counts less than it paid.
- `foundry.toml` lets tests read `packages/smart-account/fixtures`, read-only, for this.
- Slither and Mythril (`scripts/mythril.sh`) cover the contract.
