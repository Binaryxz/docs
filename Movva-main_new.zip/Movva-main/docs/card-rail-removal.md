# The card rail and the attestor quorum were removed (24 September 2026)

## The decision

The client, 24 September 2026: *"Cards stay out of the MVP. Bank rails have been zkTLS-only since 14 September. If cards
are out of scope, delete the card attestor keys entirely. Fewer live keys, less risk."* Rev. 3 §2.2 also removes the
credit card rail.

The attestor quorum (`AttestorQuorumVerifier`, its three PSP attestor keys and the `packages/attestor` service) existed
only to settle card captures. Since 14 September (SR2-34) no PIX, boleto or TED offer or sale can name it, so with cards
gone it settled nothing and every key registered in it was a live key for no purpose. It was deleted.

What did **not** change: `ReclaimZkTlsVerifier`, the zkTLS witnesses, every bank rail (PIX, boleto, TED), both escrows'
bank-rail behaviour, the `BankRailNeedsZkTls` rule and the LP node's PIX and boleto code. `IAttestorVerifier` stays as the
verifier interface (its name predates the removal); its `Rail` enum lost `CARD = 4`.

This removed surface and added no privileged function.

## What was removed, by layer

### Contracts

| Removed | Detail |
|---|---|
| `contracts/ramp/AttestorQuorumVerifier.sol` | The 3-key (M-of-N) EIP-712 attestor verifier, its `setAttestor` / `setThreshold` governance, `provesBankSession() == false`. |
| `FiatEscrow` card branch | `CARD_BIT`, the card-only offer rule (`railMask != CARD_BIT` revert `BadOffer`), the institutional-only gate at `postOffer` and again at `_lock`, and `error CardNeedsInstitutionalLP`. `postOffer` now reads: every offer's verifier must prove the bank session or the post reverts `BankRailNeedsZkTls` (the card `else` branch is gone). |
| `OffRampEscrow` card gate | `CARD_BIT` and the `BadSale` revert for a sale accepting CARD. |
| `IAttestorVerifier.Rail.CARD` | Enum value 4. `Payment.rail` can no longer decode to it. |
| `ILPRegistry.isInstitutional` / `LPRegistry.isInstitutional` | Existed only to gate card offers. The INSTITUTIONAL tier itself, its credit limit and its use by NodeRewards are unchanged. |
| `contracts/test/AttestorQuorumVerifier.t.sol`, `contracts/test/CardRail.t.sol` | 14 + 9 tests of removed behaviour. |
| `DeployRamp.s.sol` | No quorum deployed, wired, handed over or asserted; `ATTESTORS` / `ATTESTOR_THRESHOLD` are gone. `ZKTLS_WITNESSES` (required) and `ZKTLS_THRESHOLD` (default 2) replace what the witnesses used to default to. |

Changed tests (not deleted): `DeployRamp.t.sol` (no quorum; five delayed contracts, not six), `RampIntegration.t.sol` (the
real quorum is replaced by a four-line stub verifier whose `provesBankSession()` is false, so the "a verifier that does not
prove the bank session is refused for every bank rail" check stays), `OffRampEscrow.t.sol` (the `~CARD` mask term).

Behaviour to know: a sale or offer whose `railMask` sets bit 4 is no longer refused for that bit (nothing reads it; no
verifier can attest a rail 4). It was a card-specific refusal and is not replaced.

### Off-chain services and tooling

| Removed | Detail |
|---|---|
| `packages/attestor/` (26 files) | The PSP attestor service, its client, mock PSP and mock transmitter, API Pix / Open Finance / card acquirer sources, its 5 test files (60 tests) and `attestor-live.ts`. Workspace is the `packages/*` glob; `package-lock.json` lost the `packages/attestor` and `node_modules/@mova/attestor` entries only. |
| `packages/ops` | The `attestor` compose service and its `attestor-data` volume, the Dockerfile `COPY packages/attestor`, the `attestor:set` admin command, the ops packaging test (launch sites 19 to 18, compose services eleven to ten). There was no Flux spec. |
| CI | The `attestor-live.ts` step of `.github/workflows/verify.yml`. |
| Scripts | `deploy-movva-rail.ts` (no quorum deployment, no `attestor/*` test identities, no `ATTESTORS` env, no quorum assertions), `rail-artifacts.ts`, `privilege-inventory.ts` (the `AttestorQuorumVerifier` entry), `deployment-record.ts` (text), `mythril.sh` and `mythril-allowlist.txt` (the quorum's entries). The witness identities derive exactly as before. |
| `packages/ramp` | The EIP-712 `Attestor` client (`attest`, `attestBoleto`, `attestCard`), `encodeQuorumProof`, `ObservedCardCapture`, `ObservedBoletoPayment`, all card commitments and fee helpers (`cardMerchantCommitment`, `cardFee`, `cardCheckoutTotal`, `cardTransactionId`, `MAX_CARD_FEE_BPS`), `Rail.CARD`; tests `card.test.ts` (17) and `attestor.test.ts` (10). `Rail`, `railMask`, `OrderTerms`, `ObservedPayment` and the PIX key commitments stay in `src/attestor.ts`. |
| `packages/lp-node` | `card.ts`, `card-onramp.ts`, `MockAcquirer`, `acquirers/pagarme.ts` (the Pagar.me adapter), `QuorumProver`, `AttestorEndpoint`, the `onramp.card` config section, `ACQUIRER_MODULE`, `ATTESTOR_KEYS_FILE`, the card book (`#card` status keys, `not_institutional`, `no_card_prover`, `card_fee_changed`), the `GET /v1/onramp/card-fee` route, the `CARD` payment instruction, the card journal records and their compaction, card metrics, the `/acquirer` side of the dev mock-bank API, `chain.institutional()`, `CardNeedsInstitutionalLP` in the ABI, `acquirer-sandbox-check.ts`; tests `card.test.ts` (22), `attestation.test.ts` (10), `acquirers/` (31). A configuration that still names `onramp.card`, `ACQUIRER_MODULE`, `ATTESTOR_KEYS_FILE` or the `CARD` rail is **refused with a message**, not ignored. Old journals: their `order.card.*` records are no longer read (the store ignores unknown record types). |
| `packages/wallet` | Card quotes and locks (`quoteBuyByRail` defaults to `['pix']`, the `card` rail name, `cardFee` line), card instruction verification and its 11 refusal codes, `cardCheckoutHosts`, `maxCardFeeBps`, `LpNodeClient.cardFee`, `chain.isInstitutional`, the ledger's `cardFee` evidence; test `movva-card.test.ts` (13). `quoteDeposit` still has `institutionalOnly` (a matcher tier filter, not a card concept). |
| `packages/viewing-key` | `card-fee.ts` (`CardFeeEvidence`, the offer commitment check), `NotePayload.cardFeeBRLCents` / `cardFeeEvidence`, the `card_fee_mismatch` finding and `cardFeesVerified`, the offer read in escrow attributions (it existed only to verify card fees), `cardFeeCents` and the `taxa_cartao_brl` CSV column; test `card-fee.test.ts` (5). The tax CSV loses the `taxa_cartao_brl` column. |
| `packages/app` | Card UI (rail option, fee line, checkout link, dev "pay card" button, open-checkouts row), `trust.cardCheckoutHosts` in the deployment JSON and Ajustes, card refusal texts, and the card steps of `smoke.ts` and `dev-stack.ts` (no card book, no quorum, no `MockAcquirer`, no `/pay-card`). |
| Examples | `onramp.ts` / `offramp.ts` no longer deploy a quorum to demonstrate its refusal (contract tests do); `lp-node-live.ts` and `movva-wallet-live.ts` lose their card steps (the numbered step 9 of the wallet run is gone; later steps keep their numbers). |

### Documents

README, TESTING and the READMEs of lp-node, wallet, app and viewing-key were updated; `runbook-psp-attestor.md` was
deleted; the LP-onboarding and mainnet-deploy runbooks lose their card and attestor sections (`ATTESTORS` is now
`ZKTLS_WITNESSES`); availability, audit-readiness, rev3-conformance, diagram-verification, movva.md and the viewing-key
audit doc were corrected. `docs/HANDOVER.md` is deliberately not edited by this change; the lines it needs are listed in the hand-off report.
The security-review documents (`security-review-phase2.md` and others) describe the code as it was when reviewed and are
left as history.

## Test counts

Deleted test cases: forge 23 (quorum 14, CardRail 9); vitest 168 (attestor package 60, ramp 27, lp-node 63, wallet 13,
viewing-key 5, counted as `it(` blocks of the deleted files), plus the card cases removed from files that stay
(config, caps, compaction, server, dev-mock-bank, zktls, screens, refusals, tax-export, combined-statement,
intermediary-disclosure, movva-audit).

## Sizes (EIP-170, 24,576 bytes)

`FiatEscrow` 23,076 deployed (was 23,488), `OffRampEscrow` 18,363, `LPRegistry` 9,863, `ReclaimZkTlsVerifier` 15,246.

## Restoring cards from git history

Nothing here is unrecoverable. The last commit that still contains the card rail and the quorum is the parent of the commit
that removed them (`4e19c45` was `HEAD` when this was done):

```bash
git log --diff-filter=D --oneline -- contracts/ramp/AttestorQuorumVerifier.sol   # the removal commit; use its parent below
P=<parent of the removal commit>
git show $P:contracts/ramp/AttestorQuorumVerifier.sol            # the contract
git ls-tree -r --name-only $P packages/attestor                  # the service
git diff $P <removal-commit> -- contracts packages scripts       # every edit, to revert hunk by hunk
git checkout $P -- packages/attestor packages/lp-node/src/card.ts packages/lp-node/src/card-onramp.ts \
  packages/lp-node/src/acquirers contracts/ramp/AttestorQuorumVerifier.sol contracts/test/CardRail.t.sol
```

Restoring is not only a checkout. A returning card rail needs, in order: the `Rail.CARD` enum value and the FiatEscrow /
OffRampEscrow branches back (re-measure EIP-170: FiatEscrow was 23,488 bytes of 24,576), `isInstitutional` on the registry,
the deploy script's quorum and its governance hand-over, new attestor keys under the same governance delay (the old keys were
never used on a deployed immutable contract and should not be reused), the packaging and CI steps, and the card steps of the
live examples. Contracts that have been deployed immutably after this change cannot take cards back at all: the escrows would
have to be redeployed, which is a liquidity migration, not an upgrade. Plan for that before deciding to bring cards back.

If cards return, the open design question recorded in `docs/client-feedback-immutability.md` (proposal 3) comes back with
them: a card capture has no bank session to prove, so settling it needs either named attestors again or a zkTLS session
against the acquirer's own dashboard, which is new work.
