# Runbook — onboarding a licensed PSP as a card-capture attestor

The escrows release crypto for a card order when `AttestorQuorumVerifier` sees M of its N attestors sign that the card
partner's acquirer captured the charge. The client chose licensed PSPs as those attestors, integrated through the standard
APIs PSPs already run. Each PSP runs `packages/attestor` with one key. What it signs, and why it never takes the LP's word
for anything, is SR2-33 in `security-review-phase2.md`; the card rail's own rules are SR2-32.

## Card captures only

Since 14 September 2026 a quorum settles nothing else (SR2-34). PIX, boleto and TED settle only on a zkTLS proof of the
bank session. `AttestorQuorumVerifier.provesBankSession()` is false, as a constant, and the escrows refuse any offer whose
rail mask is not CARD alone, and every sale, on a verifier that returns false (`BankRailNeedsZkTls`). The reason is what a
quorum could do on those rails: M colluding or compromised attestors could sign a PIX payment that never happened and
release an LP's escrow, or, on the off-ramp, take a seller's crypto for a payout never sent. A capture at a licensed
acquirer has no bank session a payer could prove, and the card partner carries chargebacks under contract, so the card
rail keeps the quorum.

So the service's API Pix, Open Finance and boleto-ledger sources, though still built and tested, settle nothing: there is
no PIX or boleto offer or sale their signatures could release. Do not configure them for production, and do not onboard a
PSP to attest PIX or boleto. An LP's bank payments are proven by zkTLS (`runbook-lp-onboarding.md`, Step 3).

What an attestor key can do if it leaks: sign any capture for any card order. One key alone is not enough - the quorum
needs M - so the design rests on **independent** PSPs, each holding its own key, none of them Mova or the card partner.

## Before anything on-chain happens

1. **A contract with the PSP** covering: the read-only access it will hold to the card partner's acquirer account, how
   fast it answers, how it tells Mova about an incident (a leaked key, a revoked credential), and that it never runs two
   processes on one key.
2. **Read-only acquirer credentials** for the card partner's merchant account, one set per PSP, so each PSP reads the
   capture on its own. The attestor refuses anything not CAPTURED, a merchant account or fee that does not open the
   offer's commitment, and any total other than the order's amount plus the committed fee
   (`runbook-lp-onboarding.md`, Step 3b'). `bankTxId` is the acquirer-scoped transaction id, so one capture settles one
   order.
3. **The key**, generated offline, stored as a file readable only by the service (0600), never in an environment variable
   or a repository. The service prints its address at startup, never the key.

## Run the service

Self-hosted by the PSP, never on Flux (it holds a key):

```bash
docker compose -f packages/ops/docker-compose.yml --profile attestor up --build
```

| Variable | |
|---|---|
| `RPC_URL`, `CHAIN_ID` | The chain; the service refuses a different chain |
| `VERIFIER`, `REGISTRY`, `ESCROW`, `OFFRAMP_ESCROW` | The deployment it attests for. `VERIFIER` is the card quorum |
| `ATTESTOR_KEY_FILE` | The key file |
| `SOURCES_FILE` | `sources.json`: which acquirer source serves which card partner, credentials by file path only |
| `JOURNAL_FILE` | Every signature and burned request nonce, fsynced: a persistent, encrypted, backed-up volume, **one process per file** |
| `PORT` / `API_PORT` | Operations (`/healthz`, `/readyz`, `/status`, `/metrics`) and the LP-facing `POST /v1/attest`; both on loopback, the API behind the PSP's TLS reverse proxy |

Check `/readyz`, then `/status`: it lists the LPs and sources configured, never a credential. Until the key is registered
the service warns that it is not an attestor yet.

## Register it

Adding an attestor is risk-increasing and waits out `GOVERNANCE_DELAY`:

```bash
admin gov:schedule attestor:set <quorum> <attestor address> true    # the multisig signs; executable after the delay
admin gov:execute  attestor:set <quorum> <attestor address> true
```

Keep **at least threshold + 2** attestors registered, so one PSP going down or being removed never freezes settlement.
Lowering the threshold also waits out the delay; raising it is instant.

Then point the card partner's LP node at it: its `PROVER_MODULE` builds a `QuorumProver` over `RemoteAttestor` endpoints,
one per PSP (`packages/attestor/src/client.ts`). The node passes each attestor the disclosure with every proof, and submits
only a capture one quorum signed.

## Operate

- **Alert on** the refusal counters by code - `source_disagrees` and `terms_disagree` mean someone asked the PSP to sign
  something its records or the chain contradict, and are worth a look every time - on source errors, and on a source
  reporting not ok (an acquirer credential rejected or expired).
- **Back up the journal.** A new process on a restored journal still refuses a replayed request and a transaction id reused
  for another order; one on a lost journal does not remember which orders it signed.

## Rotate a key

Schedule the new address (`attestor:set ... true`, delayed), start the new service, and once it is registered remove the old
address - `attestor:set <quorum> <old> false` is instant.

## When something goes wrong

| Incident | Do |
|---|---|
| A key leaked, or the PSP reports a compromise | Remove it at once: `admin attestor:set <quorum> <attestor> false --execute` (instant). Check every card order released since the suspected time against the acquirer's records |
| A PSP's service is down | Nothing, while at least M others answer. Below M, card orders expire unpaid and the partner voids or refunds their charges (`runbook-lp-onboarding.md`, Step 3b'); bring it back or register another |
| An acquirer credential revoked or expired | That PSP stops attesting for that partner only; renew the credential |
| `source_disagrees` from one PSP while others signed | The capture is not what the LP node claimed to that PSP. Treat the order as disputed until the acquirer's records agree |
| An LP asks for a PIX or boleto attestation | There is nothing to sign that could settle: no bank-rail offer or sale can name the quorum (`BankRailNeedsZkTls`). The LP proves its own bank session by zkTLS (`runbook-lp-onboarding.md`, Step 3) |
