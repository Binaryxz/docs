# MVP Scope Rev. 3, checked against this repository

**What this is.** Rev. 3 of the Movva MVP Scope (14 September 2026) read section by section against what this
repository builds, with the file or run that settles each line. Written 17 September 2026 against commit `0f42422`.

**Read this first.** Rev. 3 supersedes Rev. 2, and this repository was built against Rev. 2 plus the client's decisions
of 14 September. Most of Rev. 3 is built. Sub-wallets with independent seed phrases were the other open requirement
and were built on 5 October 2026 (§2 below). One requirement is not met: **MOVVA minted and burned only by the escrow**.
That is not an oversight but a genuine conflict between Rev. 3 §5.1 and what the client decided on 14 September; it needs
a decision, not code, first. The live rail has the reserve mint, per our recommendation, and no decision is recorded.

| | Meaning |
|---|---|
| **Built** | In the repository and proven by a test or a run against real contracts. |
| **Built, differs** | Built, but not as Rev. 3 specifies. The difference and its origin are stated. |
| **Not built** | Absent. |
| **Removed (D1)** | Built, then deleted by client decision D1 (14 October 2026), which removed savings (sMovva, its shielded pool, the savings relayer) from M1. |

**Update, 15 October 2026.** Client decision D1 removed savings from M1: the scope is deposit PIX -> mint MOVVA -> hold
as shielded notes -> withdraw to PIX, and yield is Movva's (the issuer's), not a user product. `SavingsMovva` (sMovva),
its pool, `ShieldedYieldRouter`, `@mova/zap-relayer` and the Movva distribution keeper were deleted, and `MovvaReserve`
no longer distributes. The rows below that claimed savings or zaps as built now say so.

## The two things that need a decision before code

### 1. Who mints MOVVA (§5.1, §7.1, ESC-7, T-03, T-09)

- **Rev. 3:** the ramp escrow mints MOVVA on settlement of an on-ramp order, for exactly the order's BRL amount, and
  burns it on off-ramp. Total supply equals escrow mints minus escrow burns. No other address can create MOVVA.
- **Here:** `MovvaReserve` mints Movva against USDT at the Chainlink x Pyth rate and burns it on redemption. A liquidity
  provider mints at the reserve and sells that Movva through the escrow; the escrow settles the trade and never creates
  supply. The token itself matches Rev. 3's other requirements exactly: `contracts/movva/Movva.sol` has **no owner, no
  settable minter, no pause, no freeze and no upgrade**, and its minter is fixed at construction.
- **Why the difference:** on 14 September the client chose to keep Movva at R$ 1,00 backed by a USDT reserve rather than
  minting it one-for-one against the settlement asset ([movva.md](movva.md), "Where this differs from the architecture
  diagram"). Rev. 3 §5.1 defers backing to a separate treasury document; `MovvaReserve` *is* that backing design, so the
  two documents describe the same money differently.
- **What it changes if Rev. 3 wins:** the escrow would have to hold the minting right, the reserve would become the
  escrow's counterparty rather than the LP's, and the supply invariant in T-03 and T-09 would be checked against escrow
  events instead of reserve events. That is a contract change in the middle of the rail, not a configuration change.

### 2. Sub-wallets with independent seed phrases (§6.2, §6.3, §9.5, T-10, T-11)

**Built on 5 October 2026 (`c6e5444`, `packages/wallet/src/movva/subwallet.ts`), after the client's answers of
24 September.** This section said "not built" until then. Each sub-wallet has its own BIP-39 seed from fresh device
entropy, and its own spending, viewing and account keys, in the same pools as the primary. Live, two sub-wallets were
funded through the real on-ramp, one was restored from its phrase alone, and a leaked phrase opened none of the other
14 notes. Not built, by decision: moving funds between sub-wallets (V2). Separately, yield sub-wallets under offline
seeds (§9.5) are not built; the reserve's hedge sleeve uses a contract-controlled sub-wallet instead (below).

What Rev. 3 asks for, and what exists today:

| Requirement | Status |
|---|---|
| Each sub-wallet its own BIP-39 seed, generated on the device from fresh entropy | **Built** (`newSubWalletPhrase`, `subwallet.ts`) |
| Independent: no master seed, no shared derivation | **Built**: a phrase's keys depend on that phrase alone; `checkSubWalletPhrase` refuses one that derives to anything already registered |
| Movva never stores a seed or knows which sub-wallets are a user's | Holds for what exists: the co-signer stores no seed, and the note vault holds ciphertext only |
| Recovery by rescanning the pool from the seed | The machinery exists (`recoverByPrecommitment` rebuilds a balance from chain and vault), keyed on the wallet's own material rather than a sub-wallet seed |
| Moving funds between wallets only through the shielded transfer path | Removed from scope by the client on 12 October 2026: users deposit and withdraw only, and `ShieldedTransferRouter` was deleted |
| Limits apply to the user across all sub-wallets | Built per LP, keyed on the payer their bank names ([caps](../packages/lp-node/README.md)); it does not aggregate across LPs |
| Key isolation KI-1 to KI-6 | Holds for the keys that exist (one passkey, one co-signer, trade-only keeper keys through `KeeperGate`), and is tested for sub-wallets: a leaked phrase opens no other sub-wallet's notes (`c6e5444`) |
| Yield sub-wallets with caps and offline sharded withdrawal keys (§9.5) | **Not built.** The reserve's hedge sleeve is a contract-controlled sub-wallet instead (`contracts/hedge/HedgeSubWallet.sol`: funds leave only to the 2-of-3 hedge Safe, the keeper is trade-only, caps on-chain), closer to §9.6 than to §9.5 |

## Section by section

### 1-4. Architecture, deployment model, failure invariant

| Rev. 3 | Status | Evidence |
|---|---|---|
| Shielded pool: fork of Privacy Pools, immutable, no admin withdrawal | **Built** | `protocol/` is upstream at `c312dcd58f`; `npm run verify` checks it is unmodified |
| MOVVA token: immutable ERC-20, no admin keys | **Built** | `contracts/movva/Movva.sol` |
| MOVVA minted only by the escrow | **Built, differs** | See decision 1 |
| Smart accounts: ERC-4337, passkey + MPC, sponsored gas | **Built** | Safe 2-of-2 and Kernel, FROST as the MPC option, `SponsorPaymaster`; `accounts-live.ts` 65 checks, `cosigner-live.ts` 113 |
| Sub-wallets | **Not built** | See decision 2 |
| Ramp escrow: locks, releases on proof, refunds on timeout, dispute path | **Built** | `FiatEscrow`, `OffRampEscrow`; `lp-node-live.ts` 54 checks |
| zkTLS attestors, no attestor holds funds | **Built, stricter** | Bank rails settle only on a zkTLS proof of the bank session (SR2-34); the attestor quorum and its keys were deleted on 24 September 2026 |
| Relayers and bundlers: liveness only, self-relay fallback | **Built** | Privacy Pools relayer for exits, Alto plus paymaster; a user can self-relay. (`@mova/zap-relayer`, for savings: **Removed (D1)**) |
| Watchers and keepers, permissionless refunds | **Built** | `packages/ops` monitor; timeouts and refunds are open calls |
| Oracle layer: Pyth and Chainlink bands, halt on divergence or staleness | **Built** | `PythFxOracle`, `ChainlinkSignedFxOracle`, band oracles; a stale rate refuses |
| Yield vault and adapters, non-rebasing shares | **Built, differs** | `YieldVault` (ERC-4626 over sUSDS, Aave USDT, Lido, Superstate) invests the reserve's USDT, and its yield is Mova's. Rev. 3 wants one blended sMOVVA share over the three sleeves; `SavingsMovva` (sMovva), which paid savers the reserve's surplus, is **Removed (D1)**: there is no user-facing share |
| Yield keepers with trade-only keys | **Built, differs** | `KeeperGate` bounds what a keeper may do and the HyperCore vault's keeper triggers only bounded actions; Hyperliquid has never been traded |
| Backend API: order lifecycle, LP registry, matching, dashboard, exports | **Built, differs** | There is no backend service and no database: matching is `packages/ramp`'s matcher, the LP's own node holds its journal, and exports are generated on the user's device |
| Immutability rule: no proxy, no admin, no pause on fund-holding contracts | **Built, differs** | No proxies and no admin withdrawal anywhere. Governed parameters exist behind `DelayedGovernance` (risk-raising changes wait in public, risk-reducing are instant), the yield vault has a guardian that can pause deposits and pull funds back into the vault, and `IssuerFreeze` reacts to the USDT issuer freezing. Rev. 3's "no pause or freeze that can trap funds" holds: no such power can stop a user exiting |
| Failure invariant, service by service | **Built, qualified** | [availability.md](availability.md) works through every service and says where it does not hold: some outage combinations freeze funds, and colluding witnesses or attestors can release an LP's escrow |

### 5. MOVVA token and the note lifecycle

| Rev. 3 | Status | Evidence |
|---|---|---|
| 1 MOVVA = R$ 1,00 presented to the user | **Built** | The whole wallet and app speak reais |
| Held only as shielded notes; no public balance in the app | **Built, differs** | True in the normal flow; the app also shows Movva delivered in the open when a shielded delivery becomes impossible, and offers to re-shield it. That is the emergency exit Rev. 3 keeps in §5.2 step 7 |
| Escrow is the on-chain depositor of the user's note | **Built** | The escrow deposits into the pool; the user's address is never the depositor |
| Ragequit routed so the note owner receives the funds, bound to the proof | **Built** | `rescueShielded` on the escrow, proof-bound |
| Supply invariant, watched continuously | **Built, differs** | The monitor reconciles the reserve's supply, collateral and fees against its events; Rev. 3 wants it against escrow mints and burns (decision 1) |
| §5.3 shielded transfer, Option A (no new circuits) | **Removed from scope** | The client removed §5.3 from scope on 12 October 2026: no transfers between users, between sub-wallets, or shielded internal transfers. `ShieldedTransferRouter` and the wallet's transfer path were deleted |

### 6. Wallet

Primary account: **built** (ERC-4337, passkey, no seed, sponsored gas, recovery without the platform being able to
spend). MPC: **built** as an option (FROST 2-of-2, and since 17 September the key is generated with the device over an
authenticated, encrypted transport). Sub-wallets: **not built** (decision 2).

### 7. P2P fiat ramp

| Rev. 3 | Status | Evidence |
|---|---|---|
| On-ramp: quote, LP locks, user pays, proof, escrow settles, refund on timeout | **Built** | `lp-node-live.ts`, `movva-wallet-live.ts` |
| Off-ramp: lock, LP pays PIX, proof, burn, permissionless return on timeout | **Built** | Same runs; boleto payouts also exist, which Rev. 3 does not ask for |
| Phase A institutional LPs, then B, then C | **Built** in code | `LPRegistry` tiers; no real LP onboarded |
| Rate formation, sanity band, halt on oracle failure | **Built** | |
| MED reversal borne by the LP | **Built, partly** | The LP posts collateral and the escrow's rulings decide; no MED-specific handling |
| ESC-1 proof binding | **Built** | Proofs bind order, amount, payee and deadline; replay and cross-order refused |
| ESC-2 attestor quorum, no single attestor releases | **Built, stricter** | zkTLS witnesses m-of-n for every bank rail; there is no other verifier (the attestor quorum was deleted on 24 September 2026) |
| ESC-3 permissionless timeout | **Built** | |
| ESC-4 single settlement | **Built** | Enforced on-chain by order state |
| ESC-5 no admin path | **Built, qualified** | No key can release, redirect or seize an escrow. A governor can change parameters and revoke a verifier, in public and after a delay; an arbitrator can rule only between the order's two parties |
| ESC-6 bounded arbitration | **Built** | Rulings are delayed and bounded to the counterparties |
| ESC-7 MOVVA mint/burn on settlement | **Built, differs** | Decision 1 |
| Credit card removed from the MVP | **Built** | The card rail, the attestor quorum and the PSP attestor service were deleted on the client's 24 September 2026 decision (`docs/card-rail-removal.md`) |

### 8. Audit viewing key

VK-1 to VK-6: **built**, and proven by a run in which an auditor reconstructs the statement from chain data
(`movva-wallet-live.ts` steps 14-16, `audit-demo.ts`). VK-7: the sMovva leg it covered is **Removed (D1)** with savings,
so a statement covers Movva notes only; **not built for sub-wallets**, which do not exist.

Two of §8.3's open questions are already answered in code, and the client should confirm both:
- **Epochs are months**, as §8.2 suggests.
- **Issuance and revocation are recorded on-chain** (`AuditGrantRegistry`), which is what makes revocation verifiable
  and sealing provable. §8.3 asks whether that is wanted, noting it reveals that an audit exists and when.
- **Completeness is attested**, the stronger property §8.3 raises: the auditor checks the disclosure against pool state,
  so an omitted in-period movement is detected.

### 9. Shielded yield

| Rev. 3 | Status | Evidence |
|---|---|---|
| Opt-in, stays shielded, one relayed transaction | **Removed (D1)** | `ShieldedYieldRouter` and its relayed zaps were deleted with savings; there is no user-facing yield |
| One blended share, non-rebasing | **Removed (D1)** | sMovva (a single non-rebasing share paying the reserve's surplus) was deleted; the reserve's yield is Mova's |
| Staking sleeve | **Built, never real** | `LidoStakingAdapter` (wstETH), fork-tested |
| Tokenized T-bills | **Built, never real** | `SuperstateUSTBAdapter`; the issuer must allowlist the vault |
| Delta-neutral on Hyperliquid | **Built, never real** | `contracts/hyperliquid/*`, simulator-tested, never traded |
| Risk controls: hedge tolerance, no unhedged staking, funding, margin floor, liquid buffer, depeg halt, caps | **Built, partly** | Allocation caps, a deposit cap and a drawdown breaker are in `YieldVault`; the hedge rules live in the HyperCore vault and its keeper. Tolerances and caps are unset numbers |
| Segregated yield sub-wallets, offline sharded keys, per-wallet caps | **Not built** | Decision 2; the build is closer to §9.6's contract-controlled option |
| Exits: liquid buffer, queue, permissionless L1 redemption | **Built, partly** | ERC-4626 redemption is open to the holder; there is no exit queue with a stated maximum time |

### 10-11. Data and stack

Rev. 3 names PostgreSQL entities for users, orders, LPs, attestations, viewing keys, supply reconciliations and yield
sub-wallets, plus encrypted snapshots every 10 minutes. **Not built, by design:** there is no backend database. Orders
live on-chain, each LP keeps its own journal, viewing-key grants are on-chain, and the device holds what is the user's.
Anything Rev. 3 expects a backend to serve (a dashboard, invoices) is affected by this; see the gaps below. The rest of
the stack matches: TypeScript, Solidity with Foundry, Safe/Kernel, viem, WebAuthn, Pyth/Chainlink, React (Vite rather
than Next.js), Flux specs.

### 12. Limits, resilience, B2B

| Rev. 3 | Status | Evidence |
|---|---|---|
| Tier 0-4 daily inbound and outbound caps | **Built, unset** | Built 17 September in the LP node, off until configured. **Rev. 3 §12.1 supplies the numbers** this repository was missing: 2.000/1.000, 5.000/2.500, 10.000/5.000, 20.000/10.000, 30.000/15.000 |
| Limits apply to the verified user across sub-wallets, at the order layer | **Built, differs** | Enforced per LP node against the payer their bank names; it does not aggregate across LPs, and the standard PIX API names no payer |
| Retention (10% to 1%, for 30 or 90 days) | **Not built** | Nothing holds back part of a settlement |
| Withdrawal speed by tier (T+2, T+1, instant) | **Not built** | Every sale settles as fast as the LP pays |
| Attestation idempotency and backoff | **Built** | The LP node persists an idempotency key before every bank call |
| Service replication on Flux | **Not built** | Specs for 6 services; nothing deployed |
| Permissionless recovery | **Built** | |
| Contract immutability | **Built, qualified** | See §4 above |
| Key segregation | **Built, partly** | True of the keys that exist; sub-wallets are decision 2 |
| Audit posture: external review of fork deltas, token, escrow, account modules, vault | **Not done** | [audit-scope.md](audit-scope.md) is written for exactly this review |
| Invoices and QR payment requests | **Not built** | PIX BR Codes are built for paying an order; invoices are not |
| Conversion timing dashboard | **Not built** | |
| Accounting export with receipt and conversion dates, and yield accrual, from the user's own keys | **Built** | The tax year and CSVs come from the user's device |

### 14. Critical tests

| Test | Status |
|---|---|
| T-01 credit without payment | **Passing**: settlement needs a valid unspent proof; replay, forgery and cross-order are refused |
| T-02 escrow non-settlement | **Passing**: permissionless timeout refunds |
| T-03 ledger integrity | **Passing for this design**: supply, collateral and fees reconcile against the reserve's events after every step of the live run. Against escrow mints and burns it is decision 1 |
| T-04 viewing key read-only | **Passing**: one-way derivation, asserted adversarially in tests |
| T-05 viewing key scope | **Passing**: in-period only, and revocation ends further reading |
| T-06 service failure invariant | **Passing, qualified**: a user can exit with every Mova service down; [availability.md](availability.md) lists the combinations that still hurt |
| T-07 oracle deviation | **Passing** |
| T-08 seedless recovery | **Passing**: passkey plus co-signer, recovery after a delay, and the server alone can never spend |
| T-09 no admin mint | **Passing for the token** (no owner, no settable minter, no pause, no upgrade); the minter is the reserve, not the escrow (decision 1) |
| T-10 sub-wallet isolation | **Cannot run**: no sub-wallets |
| T-11 keeper compromise | **Partly**: keeper keys are bounded by `KeeperGate` and cannot pay themselves; never run on Hyperliquid testnet |
| T-12 yield caps | **Partly**: vault and adapter caps are enforced; there are no yield sub-wallet caps |
| T-13 yield exit offline | **Partly**: redemption is open to the holder; no exit queue |
| T-14 yield and sub-wallet privacy | **No longer applies to yield**: user-facing yield and its relayed zaps were removed (D1); no sub-wallets |

## What Rev. 3 asks for that is not here

1. **Sub-wallets with independent seeds**, for users and for yield capital, with the isolation rules and caps (§6.2, §6.3, §9.5) and tests T-10 and T-11.
2. **Escrow-minted MOVVA** (§5.1, ESC-7), if Rev. 3 wins over the 14 September decision.
3. **Retention and tiered withdrawal speed** (§12.1).
4. **A backend with the Rev. 3 data model**, and with it invoices, QR payment requests and the conversion-timing dashboard (§10, §12.3).
5. **Flux deployment** (§4.3), which needs your account.
6. **Yield as Rev. 3 frames it**: one blended share over the three sleeves, an exit queue with a stated maximum time, and the risk numbers set (§9.4, §9.7). Since D1 (14 October 2026) there is no user-facing yield in M1 at all; the reserve's vault is Mova's.
7. **The external security review** (§12.2).

## What this repository has beyond Rev. 3

Boleto payouts, node-provider rewards, the co-signer service with sponsorship and
recovery alerts, per-payer caps in the LP node, a Portuguese PWA tested in a real browser, and a services container
image. None of it conflicts with Rev. 3.
