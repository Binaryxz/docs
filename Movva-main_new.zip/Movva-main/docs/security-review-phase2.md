# Internal security review — Phase 2 (BRL ramp)

Reviewer: internal. Date: 2026-09-10. Scope: everything under `contracts/ramp/` and
`packages/ramp/`, plus the Phase 2 additions to the deploy tooling.

**This is not an external audit and does not substitute for one.** It is written by the same
party that wrote the code, which is exactly the weakness that produced the first finding
below: the vulnerable function carried a comment asserting the property it did not have, and
that comment survived several passes because the author kept reading their own intent.

Phase 1's review is `security-review-phase1.md`. The load-bearing difference is that Phase 2
contracts **hold value** — LP liquidity and seller escrow — where Phase 1's held none.

## Findings

### SR2-1 — Anyone could steal a shielded rescue by front-running the proof
**Severity: high.** `contracts/ramp/FiatEscrow.sol`, `rescueShielded`. **Fixed.**

`Delivery.SHIELDED` makes the escrow the pool's depositor of record, so takers cannot
`ragequit` for themselves; `rescueShielded` exists to give that escape hatch back. It took
`(orderId, bytes ragequitCall)`, required the caller to own that order, and paid the
recovered ETH to **that order's** recipient.

A ragequit proof is public the moment it is broadcast. So:

1. the victim submits `rescueShielded(victimOrder, proof)`;
2. an attacker holding **any** released shielded order copies `proof` out of the mempool;
3. they call `rescueShielded(attackerOrder, proof)` with a higher fee;
4. the escrow performs the victim's ragequit, and `_send(ord.recipient, recovered)` pays
   the **attacker**.

The escrow is depositor of record for every shielded delivery, which is what makes one
person's proof spendable through another person's order.

The function's own comment read *"the proceeds go to the address they named at lock time,
not to the caller, so it cannot be front-run in the mempool either."* That is true of the
victim's order and irrelevant: the payout followed the *caller's* order. A false claim in a
comment is worse than no comment, because it stops the next reader from looking.

**Fix.** A rescue is routed by **commitment**, not by the caller's order. The commitment the
pool returns at deposit time is recorded (`orderOfCommitment`), and `rescueShielded` looks up
the owning order from it, requires `msg.sender` to be that order's recipient, and pays there.
The payee is now a property of the money rather than of the transaction. The arbitrary
`bytes` was also replaced with a typed `RagequitProof`, so the escrow can no longer be made
to call anything else on the pool.

Regression: `contracts/test/RampRescue.t.sol` performs the attack and asserts it reverts.

### SR2-2 — The shielded escape hatch could never have worked
**Severity: high (availability).** Same function. **Fixed.**

`rescueShielded` called `POOL_ENTRYPOINT`. `ragequit` is on `PrivacyPool`, not on
`Entrypoint` — `grep -c ragequit Entrypoint.sol` returns 0. Every call would have reverted.

So the mitigation offered for the one genuine downside of shielded delivery — that the taker
gives up their own ragequit right — was inert. Users choosing privacy would have been told
they retained an escape hatch that did not exist, and would have found out only when they
needed it.

Found by reading the code for SR2-1 rather than by any test, because every test exercised the
happy path through a mock that answered whatever it was asked. The escrow now takes the pool
address separately from the entrypoint, and `RampRescue.t.sol` uses a pool-shaped double that
pays a ragequit the way `PrivacyPool` does.

### SR2-3 — LP credit limits were denominated in asset units
**Severity: medium.** `LPRegistry`. **Fixed.**

Introduced by adding ERC-20 settlement. `canQuote(lp, amount)` compared a raw token amount
against one cap, so the same number meant 5 ETH or 0.000005 USDC depending on the asset.
Reputation earned settling stablecoins would have authorised an enormous ETH position, and a
cap sized for ETH was effectively unlimited for a 6-decimal token. Limits and settled volume
are now in BRL centavos, the one unit every leg already shares.

### SR2-4 — Off-ramp settlements built no reputation, silently
**Severity: medium.** `LPRegistry`. **Fixed.**

`recordSettled` must not revert: it runs inside a release path, after the counterparty's BRL
has already left their bank. So an unrecognised caller returned quietly — and the registry
recognised exactly one escrow, which was the on-ramp. Every off-ramp settlement was dropped
with no event and no error. Failing quiet is correct here; failing quiet on the wrong
condition is how half a product's reputation disappears without a trace. The registry now
holds a set of escrows.

### SR2-5 — Token pulls happened before state was written
**Severity: low.** Both escrows. **Fixed.**

`postOffer`, `fundOffer` and `openSale` made no external calls until ERC-20 support existed.
Pulling a token hands control to it, and a callback token could observe or re-enter against
half-written state. They are now checks-effects-interactions and `nonReentrant`.

### SR2-6 — A party could impersonate the other and freeze funds indefinitely
**Severity: high.** `packages/ramp/src/arbitration-desk.ts`. **Fixed.**

`EvidenceRef.submittedBy` was a plain field the caller set. The desk's central promise is
that silence has a defined outcome, so a dispute cannot be used to freeze money by refusing
to participate — `ruleByDefault` applies the default outcome once the window closes with one
side unheard, and refuses when both sides responded.

Both sides responded was computed from that self-declared field. So a taker could submit one
piece of evidence as themselves and a second labelled `submittedBy: 'lp'`, the case would
read as contested, `ruleByDefault` would refuse forever, and the escrowed funds would stay
frozen — the exact failure the deadline exists to prevent, performed by the party who opened
the dispute.

**Fix.** The submitting side is recovered from an EIP-712 signature bound to the case, the
order and the escrow, and matched against the parties recorded from the escrow's own view of
the order. A non-party is refused by name. `submittedBy` is now derived, never declared, and
`submitter` records the address that actually signed.

Found by asking what each claim in the module's header would take to falsify, rather than by
reading the code for mistakes.

### SR2-7 — Revoking a compromised verifier did not stop live offers
**Severity: high.** Both escrows. **Fixed.**

`allowedVerifier` was checked when an offer or sale was created and never again. Revocation
is the governor's only lever against a broken or compromised attestor, and checking it once
made that lever useless against precisely the case it exists for: every offer already
carrying the bad verifier would keep settling — including forged payments — until each LP
individually closed their own offer.

**Fix.** The allowlist is re-checked at settlement. The cost is that revocation strands
orders already locked whose takers may have paid; that is what the dispute path is for, and
it is the right trade — a stuck order is recoverable, a verifier minting settlements is not.
`test_ARevokedVerifierLeavesTheDisputePathOpen` pins the recovery.

### SR2-8 — Oracle freshness could be made to run backwards
**Severity: low.** `SignedPriceOracle`. **Fixed.**

`sequence` was monotonic but `publishedAt` was not. A quorum could publish a higher sequence
carrying an older timestamp — deliberately, or from one publisher's wrong clock — and the
escrows, which judge staleness by `publishedAt`, would begin refusing trades against a price
that was in fact current. Now refused; republishing at the same instant is still allowed.

### SR2-9 — The Pyth adapter inverted the BRL quote
**Severity: medium.** `contracts/ramp/PythBrlOracle.sol`. **Fixed 2026-09-10.**

Chainlink's mainnet aggregator quotes **BRL/USD** (~0.185 USD per BRL). Pyth publishes
**FX.USD/BRL** (~5.4 BRL per USD). Those are reciprocals, and the adapter *divided* by the
rate — correct for Chainlink's direction, wrong for Pyth's by roughly 29x. Wired to the real
feed it would have priced 1 ETH at about R$460 instead of R$13,400.

The escrows use the oracle as a band, so the failure mode was refusal rather than theft:
every honest offer would fall outside the band and be rejected. It would have read as "the
ramp is broken", not "the oracle is inverted".

Nothing caught it because the unit tests seeded the mock at `0.2` — the same wrong
assumption that produced the formula wrote the fixture that checked it. This is the exact
shape of the two Phase 1 bugs (`labelOf`, ragequit reconciliation) and it recurred despite
being documented.

**Fix.** Multiply rather than divide, the field is renamed `usdBrlId` so the direction is
stated where it is used, and two tests assert the *direction* rather than the arithmetic: a
stronger dollar must make ETH worth MORE in BRL, and the result must fall inside a
plausibility band an inverted quote cannot satisfy.

Found by asking what "Pyth has no BRL feed" actually meant, rather than accepting it.

### SR2-10 — The PIX key "hash" was reversible for most real keys
**Severity: high (privacy).** `packages/ramp/src/attestor.ts`, used by both escrows. **Fixed 2026-09-11.**

Offers and sales stored `keccak256(pixKey)`, and `OffRampEscrow`'s header said that kept the
key private. For a random key it did. But most PIX keys are a CPF, a phone number or an email,
and those spaces are small: roughly a billion valid CPFs, so hashing all of them and matching
the on-chain value is minutes of work. On the off-ramp that linked an address that had just
exited the shielded pool to a named person, publicly and permanently. That defeats the
product's purpose.

**Fix.** The on-chain value is `keccak256(abi.encode(domain, normalisedKey, salt))` with a
fresh secret 32-byte salt per offer or sale, shared off-chain only with the counterparty and
the attestors. The contracts needed no change, since they only compare the value with what an
attestor reports. Keys are normalised to the DICT canonical form, so a bank's formatting can't
stop a real payment from settling, and CPF/CNPJ check digits are validated, so a typo fails
when the offer is created rather than after a buyer has locked an order.

`test/pix-key.test.ts` recovers a CPF from a bare hash by enumeration, then shows the same
search failing against the commitment. Its check-digit vectors were computed by hand, not by
the code under test.

Found while writing a production checklist, by asking what an on-chain value would reveal to
someone who enumerated it.

**Addendum, 14 September 2026: PIX charges (`cob`).** An LP node can now serve a Banco Central API Pix charge per order
instead of a static code (`onramp.pixCharge: "cob"`), because some PSPs list only charge-paid Pix. The salted commitment is
unchanged, and the PIX key and salt still go only to the order's signature-verified taker. What the wallet adds
(`packages/wallet/src/pix-cob.ts`): before showing the dynamic code it fetches the charge from its location on an allowlisted
PSP host and verifies the PSP's JWS as the Banco Central's Pix security manual requires (EV site certificate for the host,
`jku` on the same host, the `x5c` chain to a trusted root, the key's thumbprint, a non-HMAC algorithm), then requires the
signed `chave` to be the key that opens the offer's commitment, the amount to be the order's and fixed, the txid to be the
one derived from this order, and the charge active and expiring before the pay window closes. The location is a capability
URL that reveals key, amount and txid to whoever holds it; it is served only to the taker and never logged or shown in
`/status`. Registered QR-site certificates (published only to Pix participants) and certificate revocation need network
services: the wallet refuses charges unless a revocation source is configured, and a host allowlist stands in for the
registered-site list. Tests: `packages/lp-node/test/cob.test.ts`, `packages/wallet/test/pix-cob.test.ts` and
`movva-cob.test.ts` (another key, amount or txid; an expired charge; a host off the list; a bad signature; a key from another
domain; an HMAC JWS; an untrusted root; a revoked certificate; a restart between charge creation and record).

### SR2-11 — A zkTLS proof of a session with ANY server settled orders
**Severity: critical.** `contracts/ramp/ReclaimZkTlsVerifier.sol`, `DeployRamp.s.sol`,
`packages/ramp/src/reclaim.ts`, `reclaim-client.ts`. **Fixed 2026-09-13.**

The verifier compared `keccak256(claimInfo.provider)` with one stored hash, and the deploy
script defaulted that hash to `"http"`. In a real Reclaim proof every HTTP claim has provider
`"http"`; the URL, method and response matchers live in `claimInfo.parameters`, which was only
hashed into the identifier and never checked. The payment fields were read from `context` with
a first-match substring search, and the client put them there itself at session-request time.

So the attack needed no collusion at all. A taker locks an order, runs a server that answers
`{"amountBrlCents":"...","payeeKeyHash":"<the offer's key>",...}`, asks real witnesses to
observe a session with it, and presents the honestly signed claim. Provider `"http"`, identifier
correct, quorum valid: the escrow released without a centavo of BRL moving. The header's own
sentence - "a witness cannot invent a payment" - was true, and irrelevant: nobody had to invent
anything, because nothing asked which server the session was with.

**The Reclaim format this now assumes.** Checked against Reclaim's attestor-core and its
Solidity SDK, and written into the contract header so the next change to Reclaim is a visible
break rather than a silent one:

1. `identifier = keccak256(provider \n parameters \n context)`, with `context` canonicalised
   (RFC 8785) by the witness before hashing - so a context that verifies is byte-for-byte the
   canonical one that was signed.
2. For an HTTP claim the witness opens TLS to the host of `parameters.url` and then writes two
   context fields itself before signing (`assertValidProviderTranscript`):
   `providerHash = hashProviderParams(params)` - keccak of the canonical `{url, method, body,
   responseMatches, responseRedactions}` template, placeholders unsubstituted, overwriting any
   prover value - and `extractedParameters`, the regex groups captured from the bank's
   response, which replaces the prover's object wholesale **only when the template extracts
   at least one group**.
3. Everything else in the context (`contextAddress`, `contextMessage`, extra keys) is the
   prover's. `contextMessage` carries the order id.

**Fix.**

- The verifier keeps an allowlist of bank endpoints: `providerHash => URL prefix`. A proof
  settles only if (a) `provider == "http"`, (b) the witness-written `context.providerHash` is
  allowlisted - which pins the URL template, method, body, extraction regexes and redactions,
  so a prover cannot point a session elsewhere or lift an "amount" out of a memo field - and
  (c) `parameters.url` starts with that endpoint's prefix. The prefix is validated on entry to
  be `https://<lowercase host>[:port]/...` with no `@`, `\`, `?`, `#`, `%` or `{`, so the
  trailing `/` is a host boundary: `https://bank.com.evil.io/`, userinfo tricks, a bank URL
  embedded as a path, a downgrade to `http` and another port all fail.
- Payment fields are read only from `context.extractedParameters`; the order binding only
  from `context.contextMessage`.
- The JSON reader is strict and single-pass per object: the document must be exactly one
  well-formed object; every member of a searched object is scanned, so a duplicate key (which
  `JSON.parse` resolves as last-wins) reverts; any escaped key (`"url"` is `url` to
  `JSON.parse`) reverts; a backslash inside a value we read reverts, since raw bytes are what
  is compared; a nested key of the same name is not mistaken for the top-level one. The byte
  primitives are assembly - the first version cost 1.8M gas for a 1.7KB proof; it is now
  ~470k.
- The constructor refuses an empty allowlist, and `DeployRamp.s.sol` reads
  `ZKTLS_PROVIDER_HASHES` / `ZKTLS_URL_PREFIXES` with no default, so an unconfigured
  deployment fails instead of shipping with `"http"`.
- `reclaim-client.ts` now binds only the order id when requesting a session, and checks a
  proof's endpoint against the on-chain allowlist before a settlement is attempted.

**Governor obligation, stated because the contract cannot check it.** Allowlist a template
only if its `responseMatches` capture *every* field the verifier reads, from parts of the bank
response the payer cannot write. A template that captures nothing leaves the prover's own
`extractedParameters` in place (assumption 2). Allowing an endpoint waits out the governance
delay (SR2-14), so a mistaken template is public for 48 hours before it can settle anything.

Regression: `ReclaimZkTlsVerifier.t.sol` performs the attack with an attacker template and
with an allowlisted template pointed at another host; look-alike hosts, escaped slashes,
duplicate and escaped keys, nested keys, malformed JSON, prover-written fields outside
`extractedParameters`, a duplicated `providerHash`, and prefixes without a host boundary are
all refused; the genuine proof verifies. `ZkTlsRampIntegration.t.sol` runs the attack through
the escrow. `ReclaimZkTlsVerifierTs.t.sol` verifies a proof built by `reclaim.ts` on-chain, so
the TypeScript and the contract cannot drift apart unnoticed.

### SR2-12 — No real Reclaim witness signature could ever have verified
**Severity: high (availability).** Same verifier, and `signAsWitness` in `reclaim.ts`. **Fixed
2026-09-13.**

Reclaim witnesses sign the serialised claim string with an EIP-191 personal signature:
`keccak256("\x19Ethereum Signed Message:\n" + len + serialised)` (attestor-core
`createSignDataForClaim`; Reclaim's own `Claims.sol`). Our verifier reconstructed
`personalSign(keccak256(serialised))`, and `signAsWitness` produced exactly that - with a
comment insisting the double hash was correct. Code and test agreed; the network did not. Every
genuine proof would have recovered to a random address and failed `UnknownWitness`. Found
while reading Reclaim's source for SR2-11. The Phase 1 bug shape again: the model and the
check were written from the same assumption.

### SR2-13 — Changing an asset's decimals repriced every live offer
**Severity: high.** `FiatEscrow.setAsset`, `lockOrder`. **Fixed 2026-09-13.**

`lockOrder` computed the taker's obligation as `ceilDiv(wei * price, 10 ** assets[asset].decimals)`
from asset config the governor could rewrite at any time. Re-listing a live 6-decimal token as
36 decimals made every order against its offers cost R$0.01. **Fix:** decimals are fixed the
first time an asset is configured (delisting and relisting can change the oracle and the
enabled flag, never the decimals), and each offer pins the decimals it was posted with.
`OffRampEscrow` was checked: a sale's `brlCents` is the seller's own fixed number and decimals
only feed the band check at `openSale`, so it could not be repriced; the same fixed-decimals
rule applies there anyway. Regression: `RampErc20.t.sol` performs the relisting attack, and
separately rewrites the config slot directly to show a live offer still prices at its pinned
decimals.

### SR2-14 — One governor key could steal, in one block, with no warning
**Severity: high.** Both escrows, both verifiers, `LPRegistry`; `YieldVault` is SR3-4.
**Fixed 2026-09-13.**

Each governor function was bounded; their combination was not:

- **Escrows.** Allow its own arbitrator key, lock orders as the taker (or claim sales as an LP),
  dispute them, sign RELEASE and submit. The `resolveDispute` NatSpec said the governor "cannot
  drain an offer". It could, order by order.
- **Verifiers.** `setAttestor(self)` + `setThreshold(1)`, then sign payments that never
  happened. The quorum verifier's header said no LP's liquidity was exposed to an attestor set
  it did not choose; the governor chose the set, after the LP had.

**Fix: `contracts/common/DelayedGovernance.sol`.** One shared base. Risk-increasing changes
are scheduled on-chain with their full calldata and can only be executed after
`GOVERNANCE_DELAY` (immutable per deployment; 48 hours by default; bounded to 24 hours - 30
days) and within a 14-day window after that; risk-reducing changes stay instant. Each setter
classifies the change from current state, so `setVerifier(v, false)` is instant and
`setVerifier(v, true)` is not. A new contract starts in setup, where changes are instant and
all user business is refused, so a deploy script can wire it; `completeSetup()` is
irreversible. `transferGovernor` is instant - rotating a compromised key must not wait - and
the new governor faces the same delays.

| Delayed (schedule, wait, execute) | Instant |
|---|---|
| `setVerifier(v, true)`, `setArbitrator(a, true)` | revoking either |
| `setAsset` listing, re-enabling, or changing the oracle | delisting |
| `setAttestor`/`setWitness(x, true)`, lowering `setThreshold` | removing, raising |
| `allowEndpoint` (zkTLS) | `revokeEndpoint` |
| `LPRegistry.setEscrow(e, true)`, `setPhase` forward, `setTier` admitting/raising/reinstating | removing an escrow, closing a phase, lowering credit, `SUSPENDED`, `NONE` |

Two further holes had to be closed for the delay to mean anything:

- **Hostages taken during the delay.** A governor could schedule its arbitrator, then at once
  lock orders as the taker and dispute them. A disputed order is frozen - at the time only the
  governor submitted rulings (anyone may since SR2-17) - so the LP's `closeOffer` cannot recover
  it, and the arbitrator would rule RELEASE the moment it landed. Now a ruling that pays the counterparty (the taker on-ramp,
  the LP off-ramp) must come from an arbitrator registered no later than the dispute was
  raised; a ruling returning funds to the party who escrowed them is accepted from any current
  arbitrator, so rotating an arbitrator key never strands a dispute. Keep a second arbitrator
  key registered so that a dispute where the counterparty genuinely paid survives a rotation.
- **Removal as a threshold cut.** Removing an attestor or witness used to lower the threshold
  to the remaining count "so orders never freeze". A governor colluding with one attestor could
  remove the others and leave it signing alone - an undelayed path to 1-of-1. Removal no longer
  touches the threshold; verification fails closed until a lower threshold is scheduled, and
  stranded orders have the dispute path, as with a revoked verifier (SR2-7). The two tests that
  pinned the old behaviour were changed to pin the new one.

Regression: `DelayedGovernance.t.sol` (schedule, delay, expiry, cancel, selector allowlist,
bypass attempts, setup gating); the arbitrator theft and the hostage bypass are performed in
`FiatEscrow.t.sol` and `OffRampEscrow.t.sol`, the quorum-of-one in
`AttestorQuorumVerifier.t.sol`.

### SR2-15 — Credit limits bounded each position, not the LP; retail was open on day one
**Severity: medium.** `LPRegistry`, both escrows. **Fixed 2026-09-13.**

`canQuote(lp, amount)` was asked once per offer or claim and compared that one position with
the whole limit. Twenty offers each just under a R$5,000 retail cap put R$100,000 at risk, and
`fundOffer` topped an offer up without asking at all. Separately, `register()` was
permissionless, so open retail P2P - the client's Phase C - was live from deployment.

**Fix.** Exposure is reserved, not checked. The registry holds each LP's live exposure across
every offer, order and claimed sale on both escrows; an escrow reserves when it takes exposure
on (post, fund, claim) and releases when it ends (settle, close, abandon, stale claim, dispute),
and a reservation over the limit fails. It lives in the registry because credit is one number
across the product - two escrows each enforcing the full limit would allow twice it. Only
registered escrows reserve, and each can release only what it reserved, so a retired or faulty
escrow cannot free another's.

Network phases are stored in the registry: A (governor-admitted INSTITUTIONAL LPs only), B (an
active institution may sponsor AFFILIATED LPs whose credit is carved out of - and, as a group,
never exceeds - its own limit; suspending the sponsor stops its affiliates), C (permissionless
RETAIL at the base cap). `Tier` is now `NONE, RETAIL, AFFILIATED, INSTITUTIONAL, SUSPENDED`.
Opening a phase is delayed; closing is instant and also stops AFFILIATED/RETAIL LPs opening new
positions, because the incident that justifies stopping new entrants justifies that too; live
positions run off normally. Reputation is unchanged: settlements raise retail caps, lost
disputes halve retail and affiliate caps.

Regression: `LPRegistry.t.sol` - phases, carve-outs, the group bound under limit cuts, sponsor
suspension, escrow isolation, a fuzzed accounting invariant, and the many-small-offers,
`fundOffer` and cross-escrow bypasses performed through the real escrows.

### SR2-16 — The deploy script left the oracle's governor with the deployer
**Severity: low.** `DeployRamp.s.sol`. **Fixed 2026-09-13.** `_handOver` transferred every
governor except the oracle's, and `_assertWired` did not check it, so every deployment left
`setFeeds` / `setPublisher` with a deploying key. Both are fixed, and `DeployRamp.t.sol` now
runs the script and checks the oracle, setup closure on every delayed contract, and that the
script refuses to deploy without a zkTLS endpoint allowlist.

### SR2-17 — A dead desk or an absent governor froze disputed escrow forever
**Severity: high (availability).** Both escrows, `arbitration-desk.ts`. **Fixed 2026-09-13.**

A `DISPUTED` order or sale had no timeout, and `resolveDispute` was governor-only. Two parties
stood between a dispute and its end - the desk that signs and the governor that submits - and
either being gone froze the escrowed amount indefinitely. The client's requirement is that no
service dying costs a user access to funds; the desk is a service, and a single missing
multisig transaction was enough.

**Fix, in three parts.**

1. **Anyone submits a signed ruling.** The arbitrator's EIP-712 signature is the authority; the
   submitter is a courier, normally the party the ruling favours. Replay stays impossible: the
   struct names the escrow and the order, the domain names the chain, and an order or sale
   leaves `DISPUTED` once. The "arbitrator registered no later than the dispute" rule for
   rulings that pay the counterparty is unchanged.
2. **A ruling is posted before it executes.** Governor-only submission had been, without anyone
   writing it down, the only check between a *stolen arbitrator key* and the money. Opened to
   anyone, a stolen key drains every on-ramp offer: lock orders as a taker (no deposit needed),
   dispute, sign `RELEASE`, submit, repeat. So the first submission only *posts* the ruling
   (`RulingPosted`), and the same ruling submitted again after `RULING_DELAY` (1 day) executes,
   re-verified in full - a revoked arbitrator's posted rulings never execute. A different valid
   ruling replaces a pending one (how a rotated-in key supersedes a revoked one); resubmitting
   the same ruling early reverts rather than resetting its clock. The desk's
   `postedRulingsNotSigned` compares posted rulings with its own records: a match failure is a
   stolen key, found a day before it can pay anyone.
3. **Disputes expire.** `DISPUTE_TIMEOUT` is immutable per deployment (default 30 days, bounded
   7-90 days in the constructor). A ruling must be posted with a `RULING_DELAY` to spare after it
   becomes executable and must execute before `disputedAt + DISPUTE_TIMEOUT`; from that second
   on only `expireDispute` applies, callable by anyone. So a ruling and the default are never
   both valid.

**The default is REFUND TO ORIGIN**, the desk's existing default and for its stated reason: it
cannot be gamed by staying silent. On-ramp, the locked liquidity returns to the LP's offer (its
credit frees when the LP withdraws, as on every other unpaid ending); off-ramp, the crypto goes
to the seller's refund address and the LP's exposure is released. It is also exactly what the
escrow does when nobody disputes anything - an unproven order expires to the LP, an unproven
claim goes stale and the seller cancels - so a dispute nobody decides is worth nothing but the
time it froze the funds.

**Reputation on a timeout** (decided, not incidental). A timeout is no finding on the merits, so
it never records settled volume - a dispute cannot farm credit. It records a lost dispute
**only when the LP raised it**: the LP chose to freeze the trade and carried the burden of
getting it decided, and on the on-ramp the LP is the one party a dispute could profit (hold a
paid order until the desk is unreachable). A counterparty's unanswered dispute costs the LP
nothing; otherwise anyone could halve a retail LP's limit by disputing during a desk outage.

**The desk follows the chain's clock.** It reads `disputedAt` and `DISPUTE_TIMEOUT` when a case
opens, refuses a response window longer than half the timeout, cuts a late case's window short
so a ruling still fits, and refuses to sign within `rulingMarginSeconds` (default 3 days, never
under two `RULING_DELAY`s) of the deadline - it will not hand a party a ruling the chain can no
longer execute. `submission()` now says when the ruling becomes executable and when it expires.

Regression: `FiatEscrow.t.sol` and `OffRampEscrow.t.sol` - the governor gone and the favoured
party submitting; the desk dead and a stranger expiring; expiry one second early refused; a
ruling at the deadline refused; a ruling posted too late refused; replay once executed, at
another order and at another escrow (same arbitrator key registered on both) refused; a stolen
key's posted ruling voided by revocation, with the LP (on-ramp) or seller (off-ramp) made whole
by the timeout; early resubmission not resetting the delay; the timeout bounds. The book-keeping
fuzz test in `LPRegistry.t.sol` drives orders and sales through every ending - proof, cancel,
expiry, stale claim, unissued boleto, `RELEASE`/`REFUND` ruling, timeout - and checks escrow
balances and registry exposure against the live records after every step (a mutation that drops
the off-ramp expiry's exposure release fails it on the first run). `arbitration-desk.test.ts`
checks the desk's constants against the Solidity source. `offramp.ts` runs the posted-then-executed
ruling and the 30-day expiry on a mainnet fork.

### SR2-18 — Any taker could halve a retail LP's credit limit for the price of gas
**Severity: medium.** `FiatEscrow.resolveDispute`. **Fixed 2026-09-13.**

On the on-ramp a `REFUND` ruling means the *taker* never paid - the LP was right - yet it called
`recordDispute(lp)`, which halves a retail or affiliated LP's limit (up to eight times). Locking an
order costs nothing but gas, so any taker could lock, dispute, and let the desk's default (or a
ruling on the merits) cut the LP it was trading against. Found while deciding how a timeout
should count, by writing down who each outcome actually finds against.

**Fix.** Reputation now follows what the arbitrator found, on both legs:

| Ending | On-ramp (LP escrowed; taker pays BRL) | Off-ramp (seller escrowed; LP pays BRL) |
|---|---|---|
| `RELEASE` ruling | settled volume; a lost dispute too if the LP raised it | settled volume |
| `REFUND` ruling | nothing (the taker did not pay) | lost dispute (the LP did not pay) |
| timeout | lost dispute only if the LP raised it | lost dispute only if the LP raised it |

Regression: `test_ATakerWhoNeverPaidCannotCutTheLPsLimitByDisputing` performs the griefing three
times and asserts the limit is untouched; the other rows each have a test.

### SR2-19 — "Boleto" was a bitmask, not a rail
**Severity: medium (functional, and a latent binding gap).** Both escrows, the zkTLS verifier,
`attestor.ts`, new `boleto.ts`. **Fixed 2026-09-13.**

`Rail.BOLETO` existed as an enum value and a mask bit, but every payee was a PIX-key commitment.
A boleto is not an address: it is one document registered by its payee for one amount. "Paying a
PIX key by boleto" means nothing, so a boleto attestation could only ever have been a PIX
attestation with a different label - and the escrows accepted exactly that.

**Fix - the binding, per direction.**

- **On-ramp.** A taker locks with `lockOrderByBoleto`; the LP must `issueBoleto(orderId,
  commitment)` within `BOLETO_ISSUE_WINDOW` (1 hour), committing to a boleto it registered for
  that order's amount; the pay window (3 days, a weekend) starts at issue. The order settles only
  on an attestation of **that commitment, rail BOLETO, amount exactly `brlCents`, paid after
  issue**. One commitment serves one order, ever. An LP that never issues costs the taker
  nothing (cancel is free; anyone reclaims after the window). A PIX order refuses a BOLETO-rail
  proof and vice versa. A boleto-only offer needs no PIX key.
- **Off-ramp.** A sale whose payee is a bill commits to the bill's barcode and names BOLETO **and
  nothing else**: a mask mixing BOLETO with key rails is refused at `openSale`, because one
  commitment cannot be both a key and a barcode. A BOLETO settlement must be for exactly
  `brlCents`.
- **Why exact.** A boleto's amount is written in its line. A payment of another amount is not a
  payment of the document the counterparty checked - it is a different boleto, or a late one with
  charges - and the escrow cannot see the line through the commitment to tell which.
- **What the chain cannot check, the SDK does before money moves.** `boleto.ts` parses both
  FEBRABAN formats with every check digit (47-digit bank line: three mod-10 fields and the
  mod-11 general digit; 48-digit collection line: the value identifier selects mod 10 or mod 11
  and says whether the value is reais at all), converts line and barcode, refuses a zero-amount
  or reference-quantity document, an amount other than the order's, and an overdue boleto
  (Brasília date). `verifyBoletoCommitment` is the taker's check of an LP-issued boleto and the
  LP's check of a seller's bill.
- **Attestors derive the payee.** `Attestor.attest` refuses the BOLETO rail outright;
  `attestBoleto` takes the line the bank shows as paid plus the salt, recomputes the commitment
  itself, and refuses a different boleto, a document amount or settled amount other than the
  order's, or a counterparty that does not accept BOLETO. An attestor that signed a commitment
  it was handed would be the bearer-receipt problem again.
- **zkTLS endpoints carry rails.** `ReclaimZkTlsVerifier.endpointRails` - PIX-only when an
  endpoint is allowed, widened by `setEndpointRails` through the governance delay, narrowed
  instantly, cleared on revoke. A PIX-receipt template can no longer vouch for a boleto payment
  however its `rail` capture behaves. `reclaim-client.ts` checks it before a settlement.

**The due-date factor rolled over, and the naive decoder is wrong.** The factor counted days
since 07/10/1997 and reached 9999 on 21/02/2025; FEBRABAN (Comunicado FB-009/2023) restarted it at
1000 on 22/02/2025, which "passa a ser a nova data de referência", and the new cycle reaches 9999
on 13/10/2049 and restarts again on 14/10/2049 (C6 Bank, Layout CNAB 400 v2.7, Julho 2025). A
decoder that still adds the factor to 1997 dates every current boleto in 2000-2002, and an
"overdue" check then refuses all of them. `dueDateFromFactor` picks, among dates 9000 days apart,
the one nearest a reference date.

Regression: `FiatEscrow.t.sol` (issue window, issuer, uniqueness, a different boleto, a proof
bound to another order, wrong amount over and under, PIX proof on a boleto order and the reverse,
payment before issue, weekend settlement), `OffRampEscrow.t.sol` (bill payee, mixed mask, PIX on a
bill, another bill, wrong amount, proof for another sale), `RampIntegration.t.sol` (real quorum:
a PIX-signed attestation of the boleto's commitment is refused, and relabelling its rail breaks
the signatures), `ZkTlsRampIntegration.t.sol` and `ReclaimZkTlsVerifier.t.sol` (endpoint rails),
`boleto.test.ts` (spec worked examples, lines from an independent implementation, rollover
boundaries, every rejection), `attestor.test.ts`. Both examples run a boleto path on a fork.

**EIP-170.** `FiatEscrow` was at 93% of the contract size limit before this change and is within
150 bytes of it after. The room came from refactors that change no behaviour (calldata rulings
hashed once, one reputation path, a storage-pointer `setAsset`) and from dropping public getters
that duplicate others (`isArbitrator` -> `arbitratorSince`, `offerExposureCents` -> the
registry's `reservedBy`, the boleto window constants -> the events that carry the deadlines) and
the rationale string from dispute events (it is in the posting transaction's calldata). The next
feature on this contract needs a split, not another trim.

## USDT as a settlement asset

Reviewer: internal. Date: 2026-09-14. Scope: the new `contracts/ramp/ChainlinkSignedFxOracle.sol`,
`IPriceOracle`, the USDT path in `DeployRamp.s.sol`, the FX helpers in `price-publisher.ts`, and
both escrows' behaviour around three contracts we do not control: Tether's token
(`0xdAC17F958D2ee523a2206206994597C13D831ec7`), Chainlink's USDT/USD proxy
(`0x3E7d1eAB13ad0104d2750B8863b489D65364e32D`) and 0xbow's mainnet Privacy Pools Entrypoint
(`0x6818809EefCe719E480a7526D76bD3e561526b46`) with its USDT pool
(`0xe859C0bD25f260BaEE534Fb52e307D3b64D24572`).

**Neither escrow changed.** `FiatEscrow` is 148 bytes from the EIP-170 limit, so every item below
is resolved outside the escrows or recorded as open.

**Evidence.** `contracts/test/UsdtRampFork.t.sol` runs 22 tests on an Ethereum mainnet fork against
the real token, feed, Entrypoint and pool; every Tether power is exercised as the token's real
owner, not simulated. `ChainlinkSignedFxOracle.t.sol` covers the oracle, `DeployRamp.t.sol` the
deployment path, and `docs/runbook-mainnet-deploy.md` records a full rehearsal on an anvil fork.
Facts read from the chain at block 25,971,545: USDT has 6 decimals, a zero fee, and is neither
paused nor deprecated; the USDT/USD proxy has 8 decimals and a contract can read it; the Entrypoint
routes USDT to the pool above, with `minimumDepositAmount` 25 USDT and vetting fee 0. (The ETH
pool's are 0.01 ETH and 50 bps.)

### SR2-20 — The price interface's unit was wrong for every token without 18 decimals
**Severity: low (documentation; would have failed closed).** `IPriceOracle`. **Fixed 2026-09-14.**

`IPriceOracle.brlCentsPerUnit` was documented as "centavos per 1e18 units". The escrows compute
`ceilDiv(units * price, 10**decimals)` (`FiatEscrow._lock`) and `brlCents * 10**decimals / units`
(`OffRampEscrow.openSale`), so the price is per **whole token**. For ETH the two readings agree.
For USDT, an oracle written to the documented sentence would have quoted 1e12 too high, and every
offer would have fallen outside the band. No token oracle had been written yet. The interface now
names the unit, gives an ETH and a USDT example, and says where the escrows compute it.
`ChainlinkSignedFxOracleEscrowTest` shows 540 (R$5.40 per USDT) accepted on both escrows and 600
refused.

### SR2-21 — A cross that reports its oldest leg cannot price USDT on L1
**Severity: medium (availability; a design gap, found before any USDT oracle existed).**
**Resolved by `ChainlinkSignedFxOracle`.**

This had two parts:

1. `SignedPriceOracle` made publishers sign a BRL price for each asset. For USDT, that means
   signing a stablecoin price that moves with both FX and the peg. A depeg reached the band only
   if the publishers noticed it.
2. The obvious fix is to cross Chainlink USDT/USD with a signed FX rate and report the older
   leg's time, as `ChainlinkBrlOracle` does. That version would almost never trade. The feed
   updates on a 24-hour heartbeat while the peg holds: the fourteen update intervals before the
   fork block were each 86,400 to 86,448 seconds, and its answer was 12,000 seconds old at the
   block. Both escrows refuse a price whose `updatedAt` is more than `MAX_PRICE_AGE` old, and that
   is a one-hour constant. Reporting the Chainlink leg's time would have made USDT untradeable for
   about 23 hours of every day.

**Fix.** `ChainlinkSignedFxOracle` returns Chainlink ASSET/USD × the signed rate, where the signed
rate is a `SignedPriceOracle` whose publishers sign BRL centavos per US dollar and nothing else.
The result is rounded to the nearest centavo per token.

- **Each leg has its own max age.** `assetMaxAge` is chosen for the feed's heartbeat: 25 hours for
  USDT/USD, 75 minutes for ETH/USD, whose intervals measured up to 3,636 s over 16 rounds.
  `fxMaxAge` defaults to one hour. A stale leg reverts `StaleLeg(leg, updatedAt)`.
- **`updatedAt` is the FX leg's publish time.** The escrow's one-hour backstop therefore applies to
  the signed leg, which has no heartbeat of its own. A publisher going quiet still stops trading
  within the hour.
- **No borrowed freshness.** An FX timestamp more than five minutes in the future is refused.
- **One number for every asset.** ETH uses the same FX leg with its own feed
  (`ORACLE_KIND=signed-fx`). A USDT depeg reaches the band through Chainlink.
- **Governance.** Repointing either leg or lengthening either max age waits out the governance
  delay; tightening an age is instant (SR2-30).

**Unit tick.** The signed rate and an LP's quote are both in centavos, a tick of about 0.19% at
R$5.40. That is how Brazilian P2P desks quote BRL/USDT, and it sits well inside the escrows' band
(`BAND_BPS`, default 500), so it is kept. The band is an immutable per escrow, not per asset, so
USDT gets the same 5% as ETH. For a stablecoin that is wide, and the taker's own limit price remains
the real protection.

**Evidence.**

- `test_TheFeedsCadenceIsLongerThanTheEscrowsPriceWindow` re-reads the latest intervals on every
  run. It asserts that one exceeds `MAX_PRICE_AGE` and that all fit within `assetMaxAge`.
- `test_TheOracleReadsTheRealFeedAndPricesUsdtInCentavos` and
  `test_ADepegOnTheFeedRefusesOffersQuotedAtThePeg` exercise the real feed and a depeg.
- The unit tests assert direction, not just arithmetic (SR2-9's lesson): a stronger dollar raises
  the band, and a depeg lowers it. The rounding vectors are worked by hand and shared with
  `crossBrlCentsPerUnit` in TypeScript.
- `PricePublisher.signFx` takes a quote with its direction in the field name (`brlPerUsd` or
  `usdPerBrl`). Before anything is signed, it refuses a result outside R$1 to R$100 per dollar,
  which is where an inverted quote (about 19) or a mis-scaled one lands.

### SR2-22 — Tether can switch on a transfer fee
**Severity: medium.** **Resolved at intake; payouts accepted; shielded delivery waits.**

Tested as the real owner, `setParams(20, 0)` and `setParams(0, 50)` revert, and `setParams(19, 49)`
sets 19 bps capped at 49 USDT per transfer. Larger fees are reachable only by writing storage, or
through deprecation (SR2-29).

- **Intake is refused cleanly.** `postOffer`, `fundOffer` and `openSale` revert
  `UnexpectedAmountReceived(sent, arrived)`: 1,000 USDT sent at 19 bps arrives as 998.1. The same
  happens at 1% uncapped, written to storage. Nothing is escrowed and no credit is reserved.
- **Payouts while the fee is on keep the books straight.** Direct release, `closeOffer` and
  off-ramp settlement each move exactly the booked amount out of the escrow. The recipient receives
  it minus Tether's cut (100 USDT becomes 99.81), and the escrow's balance equals its books after
  every step. The recipient bears the fee, as on any USDT transfer. The escrow cannot refuse a
  payout without stranding it.
- **Shielded delivery cannot settle while the fee is on.** The Entrypoint pulls the order's
  amount, receives less, and then the pool pulls the full amount from the Entrypoint. The
  Entrypoint held 0 USDT at the fork block, so the call reverts. The order stays `LOCKED` and the
  books do not move. The same proof settles the order once the fee is off. A taker who pays while
  the fee is on should dispute before `payBy`: a `RELEASE` ruling repeats the same delivery once
  the fee is off, which is the path tested for a pause (SR2-23).
- **A failed USDT transfer burns gas.** USDT's balance arithmetic fails with the INVALID opcode
  (the trace shows `InvalidFEOpcode` in `transferFrom`), which consumes all gas forwarded to it. A
  relayer whose release fails this way pays close to its whole gas limit.
- **Monitor.** `usdt_state` fails while `basisPointsRate` is above zero.

### SR2-23 — Tether can pause USDT
**Severity: medium (availability).** **Cannot be fixed in the escrows; recovery path pinned.**

- **Only USDT movement stops.** Every call that would move USDT reverts whole: posting, closing,
  cancelling, releasing, settling and executing a ruling. Calls that move none keep working:
  `lockOrder`, `claimSale`, `raiseDispute`, and posting a ruling. After `unpause`, every path
  resumes.
- **A taker who pays during a pause** cannot release. If they raise a dispute before `payBy`, a
  `RELEASE` ruling can be posted during the pause and executed after it (tested).
- **A pause longer than `DISPUTE_TIMEOUT` hurts the paying taker.** On the on-ramp,
  `expireDispute` moves no USDT, so it applies during the pause: the order returns to the LP's
  offer and a taker who paid loses the trade. On the off-ramp, `expireDispute` pays the seller, so
  it waits for the unpause and then refunds (tested).
- **Monitor.** `usdt_state` fails while the token is paused. The response is to tell takers not to
  pay USDT orders, and to dispute any paid order before its window closes.

### SR2-24 — Blacklisted counterparties
**Severity: low for the escrows' funds.** **Resolved: nothing new starts with a listed party.**

Tether checks only the sender of a transfer (tested):

- **A blacklisted LP or seller cannot escrow.** `postOffer` and `openSale` revert
  `TransferFromFailed`, and nothing is escrowed.
- **A counterparty blacklisted after escrow strands nothing in the escrow.** A release to a listed
  recipient, `closeOffer` to a listed LP, `cancelSale` to a listed refund address, and settlement
  to a listed LP all succeed. The USDT lands frozen at that address, where `destroyBlackFunds` can
  zero it (tested on a recipient). Exits are deliberately not screened: refusing them would strand
  the funds in the escrow instead.

**What was open:** the escrow did not consult Tether's list, so a listed LP's live offer kept
selling its USDT for BRL, and a DIRECT order could lock toward a recipient that would receive frozen
USDT. Suspending the LP in the registry did not reach liquidity already posted.

**Fix.** Both escrows now ask the token's issuer (`IssuerFreeze`: Tether's `isBlackListed`, Circle's
`isBlacklisted`, gas-capped) before anything new starts. `lockOrder` refuses a listed LP and a listed
DIRECT recipient; `claimSale` refuses a listed LP; `openSale` refuses a listed refund address.
`FrozenByAssetIssuer(who)` names the party. The matcher also drops listed LPs' offers from its book
(`BLACKLIST_TOKENS`), so takers are not quoted them in the first place. Tested offline in
`RampIssuerFreeze.t.sol` and against real Tether in `UsdtRampFork.t.sol`.

### SR2-25 — Tether blacklisting an escrow freezes every USDT position on it
**Severity: high impact, likelihood outside our control.** **Bounded; what is already inside cannot
be recovered by any escrow code.**

Once an escrow is listed, every USDT payout and every shielded delivery reverts, for every LP and
seller on that escrow at once (tested). `destroyBlackFunds(escrow)` then zeroes the escrow's
balance while its books still owe the full amount, and removing the escrow from the list afterwards
restores nothing (tested). The escrows have no sweep, and should not have one: a sweep would be a
governor withdrawal. Tether's list is state in the USDT contract, so ETH held by the same escrow is
unaffected.

**What was worse, and is fixed.** Tether does not check recipients, so a listed escrow kept
accepting new offers, top-ups and sales - each one frozen on arrival - and kept locking orders, so
takers paid BRL for USDT that could never leave, and LPs claimed sales they could never be paid for.
Stopping that depended on the governor delisting USDT by hand. Now the escrow checks its own listing:
`postOffer`, `fundOffer`, `openSale`, `lockOrder` and `claimSale` all revert `FrozenByAssetIssuer`
while it is listed, and resume by themselves if Tether unlists it before burning anything.

**Bounding the loss.** `assetCap(asset)` is the most an escrow may hold of a token, checked on its
balance after every intake. Setting a first cap or lowering one is instant; raising or removing one
waits out `GOVERNANCE_DELAY`. `DeployRamp` refuses to list a token that exposes an issuer blacklist
without a cap (`ASSET_CAP_TOKENS` / `ASSET_CAPS`), and the monitor's `asset_cap:<token>` warns at 80%
and fails at the cap. The cap counts anything sent to the escrow, so a donation can fill it: the
griefer loses what they donate, and the governor can raise the cap after the delay.

**Room for it.** FiatEscrow was 148 bytes under EIP-170 at 10,000 optimizer runs. The repository now
compiles at 1,000 runs (`foundry.toml`), which freed about 3.1 KB and measured under 100 gas more per
escrow call (roughly 0.03%). FiatEscrow is 22,926 bytes with these changes.

**Still a decision:** how large each cap is. It is the most Mova is willing to lose to one listing.

### SR2-26 — Tether blacklisting the Entrypoint or the USDT pool
**Severity: medium.** **Entrypoint: resolved. Pool: inherent to shielded USDT.**

- **Entrypoint listed.** The Entrypoint is the sender of the pool's pull, so every shielded USDT
  delivery reverts. Delivery mode was fixed at lock, a `RELEASE` ruling delivered the same way and
  failed the same way, and the timeout refunded the LP: a taker who had paid had **no on-chain path
  to the USDT**.
  **Fix:** `takeDeliveryDirect(orderId)`. The rescue address named at lock - and only it - can switch
  a LOCKED or DISPUTED shielded order to direct delivery to itself. The taker trades privacy for that
  one order for the money; the LP is indifferent. Every later proven release or RELEASE ruling pays
  the rescue address directly. New shielded orders are refused while the Entrypoint is listed.
  Proven against real Tether and 0xbow's Entrypoint for both paths, a proof and a ruling
  (`UsdtRampFork.t.sol`).
- **Pool listed.** The pool is only a recipient on deposit, so deliveries still land. But every
  transfer out of the pool reverts, and withdrawals and ragequits both pay by transfer from the pool
  (`PrivacyPoolComplex._push`). Every shielded USDT note is frozen, and `rescueShielded`, being a
  ragequit, cannot help (tested). This risk comes with shielded USDT whatever our contracts do. What
  the escrow can do, it does: no new shielded order locks while the pool is listed.
- **Monitor.** `usdt_state` watches `PP_ENTRYPOINT` and `USDT_POOL`.

### SR2-27 — A shielded order below the pool's minimum
**Severity: medium (a taker could pay BRL for an order that cannot be delivered).** **Resolved.**

The escrow did not read `Entrypoint.assetConfig(asset).minimumDepositAmount`, which is 25 USDT on
0xbow's USDT pool. A 10 USDT `SHIELDED` order locked normally, its release reverted with the
Entrypoint's `MinimumDepositAmount`, a `RELEASE` ruling failed the same way, and the order expired
back to the LP.

**Fix, on-chain.** `lockOrder` reads the pool and its minimum for every SHIELDED order and reverts
`BelowPoolMinimum(minimum)` below it, or `BadOrder` for an asset with no pool. The same read screens
the Entrypoint and pool against the issuer's blacklist (SR2-26).

**The minimum can still move.** In the vendored Entrypoint, `updatePoolConfiguration` lets the owner
role change the minimum and the vetting fee at any time, so an order above the minimum at lock can
fall below it before release. `takeDeliveryDirect` is the way out, proven on the fork by raising the
real pool's minimum from 0xbow's owner after lock. A non-zero vetting fee shields less than the
order's amount; the USDT pool's fee is 0 today, which the fork test asserts.

**Matcher, too.** With `PP_ENTRYPOINT` set, a quote asked for `delivery=shielded` never contains a
leg below the minimum and shrinks an earlier leg rather than leave a remainder no leg may take
(`orderbook.test.ts`, `matcher-service.test.ts`). The wallet's `MatcherClient` always asks for it.

### SR2-28 — USDT refuses to change one non-zero allowance to another
**Severity: none for the escrows (cleared).** **Client obligation.**

`SafeTransferLib.safeApprove` zeroes an allowance before setting it, and `_deliver` resets it
afterwards. This was confirmed against the real token: back-to-back shielded deliveries settle,
and a stale non-zero allowance planted in storage does not stop a delivery and is 0 after it
(tested).

The token refuses the same change from an LP or seller too (tested). A client with a leftover
allowance to an escrow must `approve(0)` before approving again.

### SR2-29 — Tether can deprecate the token and forward every call elsewhere
**Severity: medium.** **Open.**

`deprecate(addr)` makes the token forward `transfer`, `transferFrom`, `approve` and `balanceOf` to a
contract Tether chooses. Tested with an address that has no code: intake and payouts revert and the
books do not move, which freezes the escrows the way a pause does. What a working successor would
do is outside this review. The escrows would still measure intake, so a fee is still refused, and
would keep the decimals pinned at listing; nothing else is guaranteed.

`usdt_state` fails on `deprecated()` and names the `upgradedAddress`. The response is to delist
USDT, which is instant, and review the successor before relisting, which is delayed.

## 14 September 2026: oracle governance, a frozen sequence, and the card rail

### SR2-30 — An oracle's governor could change who signs a price, or where it comes from, instantly
**Severity: high** (`MovvaReserve` mints and redeems at the signed FX rate). `SignedPriceOracle`,
`ChainlinkSignedFxOracle`, `ChainlinkBrlOracle`, `PythBrlOracle`. **Fixed.**

**What.** `setPublisher(self, true)` and `setThreshold(1)` in one block let the FX leg's governor sign
any rate alone. The reserve would have minted and redeemed at it anywhere inside its R$ 1-100 sanity
range, bypassing the reserve's own delayed `setOracle`. `setLegs` and `setFeeds` repointed a band
instantly, bypassing SR2-14's delayed oracle change on the escrow one contract deeper. And removing a
publisher lowered the threshold automatically: an undelayed path to 1-of-1, the flaw SR2-14 closed for
attestors.

**Fix.** All four inherit `DelayedGovernance`:

| Function | Delayed | Instant |
|---|---|---|
| `SignedPriceOracle.setPublisher` | adding a key that is not a publisher | removing one |
| `SignedPriceOracle.setThreshold` | lowering it | raising it |
| `ChainlinkSignedFxOracle.setLegs` | repointing a leg, lengthening a max age | tightening an age, legs unchanged |
| `ChainlinkBrlOracle.setFeeds` | repointing a feed, lengthening `maxAge` | tightening `maxAge` |
| `PythBrlOracle.setFeeds` | repointing an id, lengthening `maxAge`, widening `maxConfBps` | tightening either |

Removal no longer touches the threshold. A governor holding one publisher key could otherwise remove
the rest and sign alone; now removal can only shrink the set able to sign, and at worst freezes the
price (the consumers fail closed) until a lower threshold executes through the delay. Every oracle
refuses to price until `completeSetup()`, so no consumer relies on an oracle whose governor still has
instant power; the escrows, the cross, `ScaledFxBandOracle` and `MovvaReserve` all fail closed on one.
Both deploy scripts close the oracles' setup and assert it, and `DeployMovva` refuses an existing FX
leg still in setup or with a shorter delay. The monitor follows each oracle from the contracts that
use it and alerts on its scheduled changes.

**Tests.** `SignedPriceOracle.t.sol` (classification, scheduled path, setup gating,
`test_ACompromisedGovernorMustScheduleInPublicAndARotatedGovernorCancels`,
`test_RemovalNeverLowersTheThresholdAndAFrozenSetRecoversThroughTheDelay`,
`test_AGovernorCannotRemoveItsWayToAQuorumOfOne`); the classification tests in
`ChainlinkSignedFxOracle.t.sol`, `ChainlinkBrlOracle.t.sol`, `PythBrlOracle.t.sol`;
`MovvaFxLegGovernanceTest.test_APendingPublisherChangeCannotMoveTheMintPriceBeforeTheDelay` (one second
before the delay ends a mint still prices at the honest rate); `DeployRamp.t.sol`, `DeployMovva.t.sol`;
`packages/ops` `watch.test.ts` and `admin.test.ts`.

**Trade-offs.** A dead feed now fails closed until a scheduled repoint executes: schedule when a
deprecation is announced. Removing publishers below the threshold freezes the rate for the length of
the delay: run with headroom (N ≥ M + 2).

### SR2-31 — One quorum signature could freeze a signed oracle for good
**Severity: low** (availability; needs a quorum). `SignedPriceOracle.submit`. **Fixed.**

`sequence` only had to increase. A quorum - colluding, or with leaked keys - could sign
`sequence = type(uint64).max`, after which every honest price was `StaleSequence`, and recovery meant a
new oracle plus a delayed repoint of every consumer. A sequence may no longer exceed its own
`publishedAt`, which is itself at most `MAX_FUTURE_SKEW` (five minutes) ahead of the chain, so the
furthest a quorum can push it is five minutes past now. Publishers already derive the sequence from the
clock (`sequenceFromTime` in `packages/ramp/src/price-publisher.ts`), so they carry on once the chain
passes it.

Tests: `SignedPriceOracle.t.sol` `test_ASequenceCannotRunAheadOfItsTimestamp`,
`test_TheFurthestASequenceCanJumpIsTheClockSkew`.

### SR2-32 — Cards, the one rail whose payment can be taken back after release
**Severity: design** (built, not found). `IAttestorVerifier.Rail.CARD`, `FiatEscrow`, `OffRampEscrow`,
`LPRegistry.isInstitutional`, `packages/ramp/src/attestor.ts` `attestCard`.

The flow calls for card on-ramps. A card payment can be charged back for months after the escrow has
released. On a retail or affiliated LP's offer that is a stolen card buying crypto from someone who never
keeps the money, and a shielded delivery turns it into a laundering route. So the risk is assigned in the
contract, to the one party that can carry it: a licensed card partner (3-D Secure, its own fraud
screening, chargeback liability under contract), admitted as an INSTITUTIONAL LP.

- `postOffer` takes the CARD rail only on an offer of an INSTITUTIONAL LP, and only alone: the offer's
  commitment is to a merchant account at an acquirer, not to a PIX key (`CardNeedsInstitutionalLP`,
  `BadOffer`).
- `_lock` re-checks it, so a partner suspended or downgraded after posting takes no new card orders;
  an order locked before still settles, because the cardholder may already have been charged.
- `openSale` refuses the CARD bit: nobody is paid out by card.
- The attestor signs only a CAPTURED charge (never an authorisation, a void, a refund or a chargeback),
  for the merchant account and card fee the offer commits to, for exactly the order's amount plus that fee
  (any other total is installment interest or another charge), and attests the order's amount - the
  amount settled net of the fee the payer chose by paying by card (IAttestorVerifier guarantee 3) - with
  `bankTxId` the acquirer-scoped transaction id, so one capture settles one order.

Tests: `contracts/test/CardRail.t.sol` (8, including a PIX receipt refused on a card order and a card
capture refused on a PIX order under the real quorum), `packages/ramp/test/card.test.ts`.

**The LP node's side** (`packages/lp-node/src/card.ts`, `card-onramp.ts`). A card offer is posted only while the
registry says the LP is institutional (else it is pulled as `not_institutional`) and only with a prover that can
attest captures. A checkout is created only once the lock is N blocks deep, for the order's amount plus the committed
card fee, expiring before `payBy`, with its idempotency key journaled first, and the fee journaled with the offer's salt. A capture matches its order by the node's order reference only;
no PIX credit ever matches a card order; an authorisation is never proven. Every charge that bought nothing - all of
them on a cancelled order, all but the proving one on a released order - is voided or refunded once its ending is N
deep, each reversal's key journaled before the call, and a refund the acquirer refuses is held for a human.
`packages/lp-node/test` performs each: a capture for another order, an authorisation never captured, a partial
capture, a charge captured after cancellation, a downgraded LP, a crash between checkout and record, a refund
whose response is lost.

One defect was found only when the wallet paid a card order end to end: the LP node passed every API response
through `redact`, which cuts URLs to their host, so the instructions served a taker the checkout link
`https://<acquirer>/[redacted]` - a card order nobody could pay. The node's own live example had paid the mock
acquirer directly and never used the served link. Instructions now go to the verified taker verbatim, and a
response containing any configured secret is refused rather than scrubbed (`containsSecret` in
`packages/ops/src/redact.ts`); `server.test.ts` serves a full checkout URL and refuses a leaked RPC key, and
`lp-node-live.ts` pays at the link it was served.
`FiatEscrow` is 23,333 bytes (1,243 under EIP-170).

**What it does not do.** Nothing on-chain undoes a released order when a charge is later reversed: that
is the partner's loss, by contract. How the ASP treats card-funded deposits is a policy decision (see
open risks).

**The card fee, disclosed at checkout (client decision, 14 September 2026).** The first version grossed a card
offer's price up by the acquirer's fee. Movva's escrow pair allows ±3% around the reserve's price (SRM-14), which left
room for a card fee of only about 1.7% - below most Brazilian credit-card fees. The fee is now a separate charge the
cardholder sees before paying, as Lei 13.455/2017 allows (prices may differ by payment instrument): a card offer is
priced like the LP's PIX offer, and the checkout charges `brlCents + ceil(brlCents × feeBps / 10_000)`. The rate is
bound on-chain without a contract change - it is part of the offer's merchant commitment,
`cardMerchantCommitment({ acquirerId, merchantId, feeBps }, salt)` under a new `v2` domain - so an LP node cannot raise
it after posting: the wallet refuses instructions whose fee does not open the commitment, or exceeds its own
`maxCardFeeBps` (default 4%), and the attestors recompute it before signing. An LP node publishes each card offer's
fee for quotes (`GET /v1/onramp/card-fee`); that figure is the node's word until the commitment is checked at
instructions, before anything is payable. The escrow still sees and releases the order's amount. Tests:
`packages/ramp/test/card.test.ts` (order plus fee accepted and attested at the order; the order alone, a centavo either
way, an installment total and a fee other than the committed one refused; v1 commitments do not open),
`packages/lp-node/test/card.test.ts` (a Movva card offer at 3.5% posts at R$ 1,01 on the 300 bps pair, where the grossed-up
price would have been refused), `packages/wallet/test/movva-card.test.ts`; `movva-wallet-live.ts` buys R$ 100,00 + R$ 3,50 by
card and refuses a node stating 4,50% against a committed 3,50%.

**A real acquirer: Stone's Pagar.me API v5** (`packages/lp-node/src/acquirers/pagarme.ts`, client decision to use
traditional providers' published APIs). Cielo, Rede and Getnet were evaluated first and each failed a requirement the
node's safety rests on (no idempotency or lookup by reference before payment; documentation unreadable; no documented way
to give a payment-link charge back); the evaluation is in the module header. The adapter creates a checkout only after
looking the order up by its reference, with `Idempotency-Key` covering a lost response; offers exactly one installment
(a checkout echoing any other option is closed and refused, so no installment interest can reach the attested total);
makes the link expire no later than the node's `expiresAt`, and refunds, once, any charge authorised or captured after it,
since the docs do not say Pagar.me refuses one; and reverses a charge only after reading its state. `bankTxId` is scoped to
Pagar.me's charge id (`ch_...`), not the underlying acquirer's TID/NSU. Tested against a mock built from Pagar.me's official
SDK and documented behaviour - its documentation site refuses automated readers - including through the real node (a crash
after the order is created leaves one charge; a lost refund response refunds once; a late capture never proves the order).
**Unverified until a sandbox run**: whether order creation accepts the partner's customer record without a billing address,
the test host, whether closing an order disables an open checkout page, and v5 rate limits.

### SR2-33 — Licensed PSPs attest payments without taking the LP's word
**Severity: design** (built, not found). `packages/attestor`.

**Superseded in part by SR2-34 (14 September 2026): the attestor service now signs card captures only.** A PIX,
boleto or TED request is refused (`bank_rail_needs_zktls`) before any signature check or source read, the entrypoint
refuses to start with a bank source configured, and the escrows refuse to open a bank-rail offer or sale on a quorum
anyway. The API Pix and Open Finance readers below remain in the package as bank-fact sources an LP can use to know a
payment arrived, not as anything that signs. What follows is the design as built for all rails; the request, terms,
journal and card findings still apply.

The client chose licensed PSPs as the payment attestors behind `AttestorQuorumVerifier`, rather than depending on Reclaim
zkTLS credentials. A quorum member's signature releases escrowed crypto, so each attestor service must establish every
fact it signs on its own:

- **Who asks.** A request is EIP-712 signed (`Mova-Attestor-Request`, a domain distinct from the attestation's, so a
  request signature can never pass as a payment signature) by an LP admitted in `LPRegistry`, and must be that order's
  offer LP or that sale's claimant; nonces are burned in the journal, and requests are rate-limited per LP.
- **The terms** come from the escrow, never from the request: a request whose terms differ is `terms_disagree`.
- **The payment** comes from the PSP's own records through a `PaymentSource`: the standard API Pix (`GET /pix/{e2eid}`,
  for an account the PSP holds or services), Open Finance Brasil account data under the LP's consent, a boleto ledger
  plugin, or a card acquirer's read methods. A source record that differs from the claim is `source_disagrees`; then the
  `Attestor` refusals apply (payee, amount, a payment before the lock, rail, captured card total).
- **One bank id, one order.** The journal refuses to sign one `bankTxId` for two orders, across restarts; one source per
  rail per LP, because one payment seen through two sources would have two ids.

**Residual risks.**
- **Open Finance carries no end-to-end id.** The Accounts API (2.4.2) exposes the institution's `transactionId`, not the
  PIX end-to-end id, nor the credited key or a boleto line. An Open Finance attestation's `bankTxId` is therefore a
  different id for the same payment than an API Pix attestation's, so the two cannot combine in one quorum, and the
  escrow's replay protection - keyed on `bankTxId` - would not see one credit settling two orders if **one LP** used an
  API Pix quorum on one offer and an Open Finance quorum on another. Only the LP's own node can request attestations, so
  this is the LP's configuration to get right: **one id scheme per rail across all of an LP's verifiers**
  (`docs/runbook-psp-attestor.md`). Within one verifier the LP node now proves under the id its attestors signed
  (`QuorumProver` groups returned signatures by the exact payment), so an all-Open-Finance quorum works; it excludes any
  signed payment that does not prove the order, submits only a payment exactly one quorum signed, and never proves a
  second payment for an order - that last memory is in-process, so a restart forgets it.
- **`payerRef` is signed as given**: no source shows it. It is for disputes and sanctions review, never for settlement.
- **A colluding quorum** still forges a settlement, bounded by order size and the LP's credit (`docs/availability.md`).

Tests: `packages/attestor/test` (a forged or altered request, an unregistered LP, another LP's order, terms disagreeing,
a PSP record differing in key, amount, time or id, a refunded Pix, a payment before the lock, one id for two orders
sequentially and concurrently, a boleto for another amount, replay, a torn journal line, secrets absent from every
output; card: an authorisation, a chargeback, a total without the fee, a partial capture, the wrong fee; Open Finance: a
consent not authorised or expired, the wrong account, non-settled entries); `examples/attestor-live.ts` releases a PIX and a
card order on two independent services' 2-of-2 against the real verifier and escrow, keeps an order locked when one
PSP's record is R$ 1,00 short, and releases an order on a second verifier's 2-of-2 of Open Finance attestors, burning the
hash of the bank's `transactionId`. `packages/lp-node/test/attestation.test.ts` covers the grouping: a mixed quorum refused
with its reason, two payments each with a quorum refused, a wrong payee, amount, time or rail excluded even with two
signers, a duplicated attestor counted once, and no second payment for one order.

### SR2-34 — A colluding attestor quorum could settle a bank payment that never happened
**Severity: high (design). Closed for PIX, boleto and TED.** `IAttestorVerifier`, `FiatEscrow.postOffer`,
`OffRampEscrow.openSale`, `AttestorQuorumVerifier`, `ReclaimZkTlsVerifier`.

The architecture promises that a compromised service costs no user or LP their funds, and `docs/availability.md` recorded
that it did not hold for the ramp: M colluding attestors could sign a PIX or boleto payment that never happened and release
an LP's escrow (or, on the off-ramp, take a seller's crypto for a payout never sent). Each LP chose its verifier per offer,
which bounded who trusted a quorum but not what the quorum could do to them. Mova decided (14 September 2026) that bank
payments settle only on a proof of the bank session.

**Fix.** `IAttestorVerifier` gains `provesBankSession()`. `ReclaimZkTlsVerifier` returns true; `AttestorQuorumVerifier`
returns false, as a `pure` constant, so the deployed quorum can never be named for a bank rail. `FiatEscrow.postOffer`
refuses any offer whose mask is not CARD alone when its verifier returns false, and `OffRampEscrow.openSale` refuses every
sale whose verifier returns false - there are no card payouts - both with `BankRailNeedsZkTls`. The quorum keeps the card
rail, where a capture at an acquirer has no bank session a payer could prove (SR2-32).

**What it does not do.**
- **It does not make a verifier honest.** The answer is the verifier's own. A verifier that lies about it is a malicious
  contract, and allowing any verifier already waits out `GOVERNANCE_DELAY`, in public.
- **Witnesses can still collude.** A quorum of Reclaim witnesses can sign a claim about a session that never happened
  (`ReclaimZkTlsVerifier`, "What it does NOT buy"). The trust moves from named PSPs to the witness set, whose changes are
  delayed; forgery by witnesses is still bounded only by order size and the LP's credit.
- **It is read when an offer or sale opens, not at settlement.** A verifier's answer must be constant; revoking a verifier
  (instant, and re-checked at settlement) remains the lever against a broken one.
- **Nothing settles by PIX or boleto until the zkTLS path is credentialed.** The Reclaim credential and per-bank templates
  in "Open risks" below were a gap; they are now a precondition for launch. The licensed-PSP attestor service (SR2-33)
  serves card captures only.

Tests: `CardRail.t.sol` (`test_AQuorumSettlesCardsAndNoBankRail`: PIX, boleto and TED offers and sales naming the real
quorum refused on both escrows; the same through a bank-session verifier open), `RampIntegration.t.sol`
(`test_TheRealQuorumCannotBeNamedForABankRail`), `ZkTlsRampIntegration.t.sol` (off-ramp PIX payout and a bill paid,
each settled by a zkTLS proof; a proof for one sale refused on another), `UsdtRampFork.t.sol` (USDT PIX on both ramps,
now by zkTLS).

### SR2-35 — The USD/BRL rate comes from Pyth, whose market closes most of the week
**Severity: design.** `PythFxOracle`, `FxMarketHours`, `IBandPriceOracle`/`BandRead`, `ScaledFxBandOracle`,
`MovvaReserve`, `DeployRamp`, `DeployMovva`.

Mova chose Pyth's FX.USD/BRL over named publishers (14 September 2026). It was absent from Ethereum only because nobody
posted it (`PythFork.t.sol`); Mova's keeper now does. But Pyth publishes it on a schedule - weekdays 08:00-17:00 New
York, closed at weekends, on 25 December and on 1 January (Hermes feed metadata, read 14 September 2026) - about 73% of
the week closed. The escrows refuse any price older than `MAX_PRICE_AGE`, one hour, immutable. A plain Pyth leg would
have stopped the ramps every night and weekend, while PIX runs 24/7. Mova's rule: **trading continues on the last close;
value creation waits for the market.**

**Design.** `PythFxOracle` has two readings. The RATE (`brlCentsPerUnit`, reais per dollar at 1e-6) refuses a price older
than `maxAge` at any hour; `MovvaReserve` mints, redeems, withdraws to the hedge and distributes at it. A BAND's price
(`brlCentsPerUnitForBand`) is the rate inside the core session and, outside it, the last price up to `closedMaxAge` old,
stamped with the current block. `ScaledFxBandOracle` (so every `ChainlinkSignedFxOracle` cross) and the reserve's own band,
`MovvaReserve.brlCentsPerUnit`, read a source's band reading through `BandRead`. `FxMarketHours` names the core session
without daylight-saving rules: 13:30-21:00 UTC on weekdays other than the two holidays, the hours open under both New York
offsets, starting half an hour late so the keeper can post the day's first price.

**Residual risks.**
- **A move while the market is closed reaches no band until it reopens.** A band admits offers against Friday's close all
  weekend. A band never sets a trade's price, and a taker sees the price; Movva's band is R$ 1,00 x min(1, ratio), which
  the rate moves only under partial backing.
- **A keeper outage outside the core session looks like a closure.** Bands run on the last price the keeper posted, for up
  to `closedMaxAge` (four days). The rate is refused at once, so minting stops and the monitor alerts.
- **About two hours a day are misread as closed** (12:00-13:30 UTC in New York summer, 21:00-22:00 UTC in winter): bands
  accept the last price then. The rate does not.
- **A holiday Pyth adds** is a day bands refuse inside the core session: it fails closed. `FxMarketHours` must follow the
  schedule; changing it means a new `PythFxOracle` and a delayed repoint.
- **LPs cannot mint off-hours.** An LP out of Movva stops quoting until the market reopens; inventory before the close.
- **Trust moves, it does not vanish**: from named publishers to Pyth's publishers and the Wormhole guardians that sign
  updates. Repointing the feed or loosening a limit waits out the delay (SR2-30's rule).
- **`BandRead` falls back to the strict reading on any revert** of the band reading, which refuses the same price for at
  least the same reason. A source whose fallback returns without data is unsupported and fails closed.

Tests: `PythFxOracle.t.sol` (both readings at every hour boundary, a weekend, Christmas, the closed limit, bad prices, the
keeper's paid and never-backwards updates, the ramps' USDT band all weekend on Friday's close; `FxMarketHoursTest` for the
session and leap years), `MovvaOffHours.t.sol` (over a weekend mint, redeem and the ratio refuse while a Movva offer posts
and a sale inside the band opens; Monday wants a fresh price), `DeployRamp.t.sol` 2b and `DeployMovva.t.sol` 4 (the Pyth leg
deployed by default, handed over, pricing once posted).

### SR2-36 — Node-provider rewards pay for settled volume, and an LP can manufacture volume
**Severity: design** (built, not found). `NodeRewards`, `FeeSplitter`, `IRewardsHook`, `LPRegistry.setRewardsHook` /
`recordSettled`, `DeployMovva`, `DeployRamp`, `packages/lp-node/src/rewards.ts`.

The client's flow lists "node provider rewards" beside Mova's fees and yield share. They are built as a share of Mova's fee
revenue paid to LPs in proportion to the BRL volume they settle. LPRegistry's header says why this repo never made reputation a
score: an LP can take its own offer from a second address, pay its own PIX from a second account, prove a real payment and
settle, all day, for the price of gas. A reward per settled real turns that into income, so the farming is bounded in the
contracts and what is left is written down here.

**Design.** `FeeSplitter` is the reserve's fee recipient; anyone may `split()`, sending `lpRewardShareBps` of the Movva it holds to
`NodeRewards` and the rest to Mova's treasury. The share is **0 at deployment** and never above 5,000 bps. `LPRegistry.recordSettled`
reports each settlement, on every escrow the registry accepts, through an optional hook; `NodeRewards.onSettled` adds eligible centavos
to the LP's volume for the current epoch (7 days by default). Once an epoch has ended and its review (3 days) has passed, anyone
finalizes it: its budget is the smaller of what was funded during it plus what earlier epochs could not pay, and `rewardBpsOfVolume` of
its volume. Each LP claims `budget x its volume / epoch volume`, up to the per-LP cap. No loop runs over LPs; nothing expires; what an
epoch cannot pay rolls forward.

**What bounds farming.**

| Bound | Where | What it stops |
|---|---|---|
| Only INSTITUTIONAL and AFFILIATED LPs earn, by the tier at settlement | `onSettled` | A farm of fresh Phase C addresses; a suspended LP |
| An epoch pays at most `rewardBpsOfVolume` of its volume: 10 bps by default (the mint fee), 20 hard cap (mint plus redeem) | `_finalize` | A manufactured real earning more than minting it paid Mova, however large the pool |
| At most `maxRewardPerLpPerEpoch` per LP per epoch (R$ 10.000,00 by default), fixed when the epoch is finalized; the excess rolls forward | `claim` | One LP taking a week's pool |
| Settlements under `minCountedCents` (R$ 10,00) do not count | `onSettled` | Dust in the books. Not farming: a farmer uses large orders |
| During each epoch's review the governor voids an LP's volume for it, instantly, and excludes the LP from new volume | `voidVolume`, `setExcluded` | Farming found after the fact, before it is paid |
| Budgets come only from tokens received, and claims never exceed them | accounting; `NodeRewardsInvariant.t.sol` | Rewards nobody funded |
| Raising the share, the rate or the cap, lowering the minimum, a new treasury, rewards contract or hook, a new registry once funded, and reinstating an LP wait out `GOVERNANCE_DELAY` | `DelayedGovernance` | A governor quietly enlarging the prize |

**Two choices worth their own sentence.**

- **A void rolls forward; it does not redistribute.** The voided volume stays in the epoch's denominator and its share of the budget
  goes to the next epoch. Redistributing it would let a governor move one LP's rewards to another at once. As built, voiding and
  excluding are brakes, like a suspension: an LP loses by them and nobody gains.
- **A hook short of gas reverts the settlement; it never skips.** A skipped hook would let whoever submits a release with a tight gas
  limit erase an LP's volume, and `eth_estimateGas` - the least gas at which a transaction does not revert - would choose exactly that
  limit for honest settlements too. `recordSettled` therefore requires `REWARDS_HOOK_MIN_GAS` (111,587) before it calls the hook with
  `REWARDS_HOOK_GAS` (100,000) through a raw CALL that copies no return data; a hook that reverts, loops, re-enters or returns 150 KB
  costs the settlement at most that budget and a `RewardsHookFailed` event. `ILPRegistry` still says `recordSettled` MUST NOT revert:
  running out of gas is the one exception, as it is for any call, and no funds wait on it. The escrows' bytecode is unchanged.

**Residual risks.**

- **An eligible LP can still farm within the caps.** A self-trade by an INSTITUTIONAL or AFFILIATED LP counts, and earns up to 10 bps of
  what it settles, up to R$ 10.000,00 of Movva a week, out of fees other gateways paid. The registry does not see the taker, and refusing
  `taker == LP` would change both escrows' bytecode (FiatEscrow is 1,088 bytes under EIP-170) for a check a second address defeats. What
  answers it is off-chain: the LP's contract makes self-dealing a breach, and each epoch's review is the window for the desk to look for
  one taker settling again and again with one LP and for the governor to void and exclude (`docs/runbook-lp-onboarding.md`, Step 3e).
- **Affiliates multiply the cap.** A sponsor creates affiliates without a governor vote (Phase B), each earning for itself up to its own
  cap. Their credit is carved out of the sponsor's, which bounds what they hold at risk at once, not how often they settle. Excluding a
  sponsor does not exclude its affiliates; suspending it does (a suspended sponsor's affiliates keep their tier but lose their credit, so
  they stop opening positions).
- **Gas.** With a hook set, each settlement needs 111,587 gas available at the hook and spends what NodeRewards uses: `recordSettled`
  measured 128,000-136,000 gas with NodeRewards counting (`forge test --gas-report`, `NodeRewards.t.sol`), against about 27,000 without a
  hook. On L1 that is paid by whoever settles, usually the LP's node.
- **Epoch attribution.** Fees are booked into the epoch in which they are split or synced. Fees paid late in a week and split the next
  fund the next week; a split whose `sync` fails books its tokens at the next `sync`, into a later epoch.
- **Binding the first registry is instant** while NodeRewards has never been funded and holds nothing, because DeployMovva closes its setup
  before DeployRamp deploys the registry. A governor could bind a registry of its own and count fabricated volume. With the share at 0 by
  default nothing reaches NodeRewards before a delayed share raise, during which the bound registry is public (`node_rewards_wiring`, the
  event watcher). A donation of one base unit forces every later binding through the delay.
- **Limits in force at finalization apply to the epoch being finalized.** Lowering the rate or the cap during an epoch's review cuts rewards
  not yet final, instantly, as a suspension cuts credit.
- **Rewards follow volume, not risk or service.** An LP settling large institutional orders earns more than one keeping PIX offers posted
  through the night. Weighting by anything else is a product decision, not made here.

**Contract sizes.** `LPRegistry` 9,962 bytes (was 9,154), `NodeRewards` 9,967, `FeeSplitter` 5,169; `FiatEscrow` (23,488),
`OffRampEscrow` (18,397) and `MovvaReserve` (20,181) unchanged.

Tests: `NodeRewards.t.sol` - `NodeRewardsTest` (tiers and the minimum; pro-rata inside the volume bound and the pool; an empty epoch
rolling forward; the cap rolled forward at claim; one claim across epochs a year later; claim refusals; a void that raises no other share;
exclusion instant and reinstatement delayed; every limit classified by direction; the first binding instant only while nothing was funded;
constructor bounds; a fuzzed sequence checked against the books after every step), `RewardsHookTest` (a reverting, a looping and a
150 KB return-data hook never block a settlement and cost under the budget; a re-entrant hook finds the books final; across gas limits a
settlement either gives the hook its whole budget or reverts), `FeeSplitterTest` (default 0, the split, delay rules, a token mismatch, a
rewards contract refusing `sync`), `NodeRewardsIntegrationTest` (a gateway's mint fee reaches the splitter, a real FiatEscrow settlement is
counted by the real registry, finalized and claimed at the 10 bps bound); `NodeRewardsInvariant.t.sol` (claimed never exceeds funded, the
books add up and are backed, a failing hook never blocks a settlement, share and limit changes follow the delay rules, no claim past its
bounds); `DeployMovva.t.sol` and `DeployRamp.t.sol` (refusals, wiring, hand-over, the binding); `packages/lp-node/test/rewards.test.ts`,
`packages/ops/test/admin.test.ts`, `checks.test.ts`, `watch.test.ts`; `examples/lp-node-movva-live.ts` steps 7 and 11 on the real contracts.

## Reviewed and cleared

- **Receipt binding.** A bank receipt settles exactly one order, ever: `usedBankTxId` is
  global rather than per-order (and, since the M1 review's SRM1-12, kept in the `LPRegistry` both
  escrows share, so it is also global across the on-ramp and the off-ramp), proofs are bound to an order id, and a receipt must
  post-date the lock (on-ramp) or the claim (off-ramp). The off-ramp uses the claim
  deliberately — otherwise an LP who genuinely paid a seller once could reuse that transfer
  against a later sale by the same person.
- **Governor powers - NOT cleared; this entry was wrong.** It read: "bounded by
  construction ... cannot mint, cannot drain an offer, cannot touch the pool". Each function
  was bounded; the governor holding several of them was not (SR2-14). What is true now: a
  ruling still reaches only a `DISPUTED` order, moves only that order's escrowed amount, and
  can go to exactly two places, and the governor cannot choose the direction - nor, since
  SR2-17, is it needed to submit one: anyone submits, and a posted ruling waits a day in public
  before it executes. What bounds a malicious governor is no longer the
  function bodies but the delay: every change that would let it move value or accept a claim
  it could not before is public for `GOVERNANCE_DELAY` first. It is left in this list, struck,
  because the Phase 2 lesson below is exactly this: a confident sentence nobody tried to
  falsify.
- **Oracle as a band.** A compromised price feed can widen or narrow which offers are
  postable. It cannot move value, because the price of a trade is what the LP posted and the
  taker accepted. This is the single best structural decision in Phase 2 and it should
  survive any refactor.
- **The matcher holds nothing.** No key, no `writeContract`, no `sendTransaction`; asserted
  mechanically in `matcher-live.ts` rather than promised here.
- **Fee-on-transfer tokens** are rejected at the door by measuring what actually arrived,
  rather than mis-accounted later. Confirmed against real USDT with Tether's fee switched on. A
  fee switched on after funds are escrowed is not refused at payout; see SR2-22.

## Open risks that are decisions, not defects

- **`AttestorQuorumVerifier` is trusted, and settles card captures only** (SR2-34). M colluding
  attestors can forge a capture that never happened, bounded by order size and the card partner's
  credit. PIX, boleto and TED settle only through `ReclaimZkTlsVerifier`, whose witnesses can
  censor and, colluding, still sign a session that never happened - a broader and more public set
  than named PSPs, not no trust.
- **The zkTLS path is wired to the real network but not credentialed.** Session request,
  polling, conversion, signature ordering, witness checking and the endpoint allowlist check
  are production code (`reclaim-client.ts`), and rotation is handled
  (`examples/reclaim-witnesses.ts`). What is missing is a Reclaim application credential and a
  bank provider template - and the template must extract the payment fields in the formats
  the verifier reads (0x-hex hashes, decimal digits). A bank response does not naturally
  contain a salted PIX-key commitment, so a real template needs Reclaim's hashed redactions or
  a verifier revision; it can fail to settle, not settle wrongly. Witness rotation now waits
  out the governance delay: schedule new witnesses when Reclaim announces an epoch, not after
  proofs start failing. `signAsWitness`
  remains for tests. Note that this gap cannot be closed by code: a proof attests to a TLS
  session between a real person and their real bank, and if it could be produced without
  one, it would be worthless. Since SR2-34 it is no longer one path among two: until it is
  closed, nothing settles by PIX or boleto.
- **PIX reversal risk is unallocated.** A payment can be genuine and reversed days later.
  No on-chain mechanism observes that. Who carries it is a business decision that has not
  been made.
- **`SignedPriceOracle` names its trust.** Where no BRL feed exists, a quorum publishes the
  price. That is weaker than a maintained feed, and was chosen deliberately over not deploying. On
  L1 the quorum now signs only the BRL/USD rate, and each asset's USD leg comes from Chainlink
  (SR2-21). Mova's deployments now take that rate from Pyth instead, posted by Mova's keeper
  (SR2-35); the signed oracle remains a supported alternative (`FX_SOURCE=signed`).
- **USDT carries Tether's powers over it.** A pause, a fee, a blacklist or a deprecation each
  reach escrowed USDT (SR2-22 to SR2-29). An escrow on Tether's blacklist has no path out
  (SR2-25). A shielded USDT order below the pool minimum cannot settle, and nothing on-chain stops
  it being locked (SR2-27).
- **Arbitration is a human process.** The chain makes rulings attributable, not correct.
- **Refund-to-origin favours the escrower when the desk is gone for the whole timeout.** A taker
  who really paid (on-ramp) or an LP who really paid (off-ramp) and never obtained a signed ruling
  within `DISPUTE_TIMEOUT` loses the trade: the escrowed asset returns to the side that put it up.
  That is the same outcome as no dispute at all, which is why silence cannot game it, but it
  means desk availability is still worth money to the paying side - 30 days of it.
- **A stolen arbitrator key needs someone watching, within a day.** With submission open to
  anyone, the governor no longer gatekeeps what a desk key signs. What stops a stolen key is the
  one-day posting delay plus a revocation inside it: the desk's `postedRulingsNotSigned` (or any
  monitor comparing `RulingPosted` with the desk's cases) must alert, and the governor must
  revoke. This is a governor-*liveness* dependency for the compromise case only; the dead-desk
  and absent-governor cases no longer have one. The monitor does not yet watch `RulingPosted`.
  Relatedly, two *contradicting* valid rulings (two arbitrators disagreeing, or one stolen key)
  can replace each other on every submission, each restarting the other's delay, until one
  signer is revoked or the deadline refunds; the escrow cannot tell which arbitrator is right.
- **A boleto the LP issued stays payable after the order ends.** If a taker cancels, or the order
  expires, after the LP issued a boleto, the LP must cancel ("baixar") it at its bank; a taker
  who pays it anyway has paid the LP for nothing, and no on-chain mechanism sees that. The
  zkTLS path for boletos has the same template gap as PIX, one step worse: a bank receipt shows
  the barcode, not a salted commitment to it, so a production template needs hashed redaction
  of the barcode.
- **The governance delay is notice, not a veto.** It protects users who watch
  `ChangeScheduled` and act; the monitor should alert on every one. It does not constrain
  parties already trusted before a change: existing arbitrators, attestors and witnesses. The
  delay must exceed the time users need to exit - for the yield vault, the slowest adapter's
  withdrawal queue. (A governor can no longer freeze disputes by withholding submission; see
  SR2-17.)
- **The oracles' own setters are delayed now** (SR2-30), because Movva mints at a signed rate
  and a band is no longer the only thing a price decides. The cost is that a dead feed stays dead
  for the length of the delay: schedule a repoint when a deprecation is announced, not after.
- **Card-funded shielded deposits and the ASP.** A card order is identifiable from chain state (its
  offer's rail mask). Whether the ASP holds card-funded deposits out of the association set for the
  partner's fraud window - so a stolen-card purchase cannot be withdrawn privately before a chargeback
  is likely - is Mova's ASP policy to set with the card partner. Ragequit stays available either way,
  and a rescue pays the address named at lock, in the open.

## What has not been done

- No formal verification, no symbolic execution, no fuzzing beyond Foundry's default runs.
- No economic or game-theoretic analysis of LP incentives, and none of the reputation
  formula's resistance to farming beyond the argument that farming a *limit* is self-funding
  in the wrong direction.
- No load testing of the matcher, and no analysis of what it costs to run at scale.
- **No external audit**, which remains the single largest gap in this project.

## Where the bugs have been, across both phases

Phase 1's two real bugs shared a shape: the model and the test agreed because the same
assumption produced and checked the value. Phase 2's two high-severity findings share a
different one, worth naming separately:

**The code asserted a property in prose, and the prose was checked by nobody.**

SR2-6 and SR2-7 came from the same place and were found by inverting the method: taking each
claim in a header — "silence has a defined outcome", "an LP who does not trust a given
attestor simply does not select it" — and asking what it would take to falsify. Both fell
immediately. It is a cheaper review technique than reading for mistakes, and it works
because a confident comment is a hypothesis nobody has tested.

`rescueShielded` claimed it could not be front-run, and could. It claimed to call a function
that did not exist where it was calling. Both survived review passes because a confident
comment reads as a completed argument. The remedy applied here is to turn each such claim
into a test that performs the attack — `RampRescue.t.sol` front-runs, `matcher-live.ts`
greps its own source for a signer — so the assertion fails when it stops being true.

The September 13 findings (SR2-11 to SR2-16) are both shapes at once. "A witness cannot invent
a payment" was true and did not matter, because nothing asked which server the witness was
watching; the signature scheme was checked only against our own signer. "The governor cannot
drain an offer" was true of every function taken alone. Both were found by stating the claim
as an attack - *run your own server*, *hold all the governor's powers at once* - and then
writing that attack as a test before touching the code.
