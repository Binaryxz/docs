# Internal security review — Movva (the BRL-pegged token and its reserve)

Reviewer: internal. Date: 2026-09-14, revised the same day for the sized parameters (108% target, 103%
withdraw floor, 8% daily hedge limit) and the ratio ordering rule (SRM-13). Scope: `contracts/movva/` (`Movva`, `MovvaReserve`, `SavingsMovva` (since removed, D1),
`ScaledFxBandOracle`, `IMovvaReserve`), `contracts/script/DeployMovva.s.sol`, and the Movva commands in
`packages/ops/src/bin/admin.ts`. Design: `docs/movva.md`.

> **Update, 15 October 2026: savings removed (client decision D1, 14 October 2026).** `SavingsMovva` (sMovva) and its
> tests, the Movva distribution keeper and `MovvaReserve`'s savings path (`distribute`, `previewDistribute`,
> `savings`/`setSavings`, the distribution fee and the daily distribution cap) were deleted. Movva is minted only by
> `mint`; the surplus above the target stays in the reserve as backing and is Mova's, reached only through the hedge
> path. So SRM-2, SRM-3 and SRM-7 and the savings-specific risks below no longer apply to the current code; they are
> marked *(removed, D1)* and kept as the record. A wrong rate inside the bounds, acting alone, now moves nothing
> ("The rate"). Fees are 0.10% to mint and 0.10% to redeem.

**This is not an external audit and does not substitute for one.** It is written by the party that wrote
the code, the same day. It follows the method of the Phase 2 and 3 reviews: every claim a docblock makes
is a test that tries to break it, and every finding below names that test.

Movva is the first contract in this repo that **creates money**. The escrows hold what two parties
agreed; the yield vault holds what depositors put in. The reserve mints a token whose value depends on an
off-chain hedge, a signed exchange rate and a stablecoin issuer. So the questions are no longer only "who
may call what" but "what does a wrong number cost, and who pays it".

## Tests

| File | What | Count |
|---|---|---|
| `contracts/test/MovvaReserve.t.sol` | Unit: token, rate, accounting, mint, redeem, hedge, recapitalize, no distribution (`MovvaNoDistributionTest`: the surplus stays; the removed selectors are not there; it replaced the distribute tests, D1), band oracle (incl. a real `FiatEscrow`), `ScaledFxBandOracle` (incl. the real `ChainlinkSignedFxOracle`), every privileged function instant vs delayed, the ratio ordering rule, ±5% dollar moves from rest | 82 |
| `contracts/test/SavingsMovva.t.sol` *(removed, D1)* | Vesting, sandwich, inflation attack, dust savers, the real `ShieldedYieldRouter` | 9 (deleted) |
| `contracts/test/MovvaInvariant.t.sol` | Handler with 12 actions, including the governor re-setting ratios in and out of order (no save, unsave or distribute actions since D1); 6 invariants at 128 runs x 200 calls (`invariant_DistributeNeverMintsAtOrBelowTarget` removed, D1) | 6 |
| `contracts/test/DeployMovva.t.sol` | The deploy script: refusals, wiring, hand-over, first mint, the breaker and hedge-queue settings | 1 |
| `contracts/test/MovvaBreaker.t.sol` | The divergence breaker (unit and a never-latches fuzz), its TWAP and Chainlink sources, the reserve's hedge timelock (unit, fuzz, a stateful invariant), `LimitedYieldVault` | see audit-scope.md |
| `contracts/test/MovvaFork.t.sol` | Mainnet fork: real USDT, Chainlink USDT/USD, Aave v3 USDT wrapper (Aave yield stays in the reserve as surplus: `test_AaveYieldStaysInTheReserveAsSurplus`), Tether's owner | 6 |
| `packages/lp-node/test/gateway.test.ts`, `gateway-safety.test.ts` | The LP node as a gateway: every reserve refusal checked before simulating, minting only to a need, holding below par, crash/reorg/nonce recovery, a property test over all of it; `examples/lp-node-movva-live.ts` against the real bytecode | 42 |
| `packages/yield/test/movva-keeper.test.ts`, `movva-keeper-anvil.test.ts` *(removed, D1)* | The distribution keeper: never while vesting, with no savers or below the minimum before the max wait; replica races; a run against the real reserve and sMovva | 31 + the anvil run (deleted) |

The offline tests use a Tether-like token with Tether's quirks (no return values, sender-only
blacklist, fee switch), a real `SignedPriceOracle` signed by test keys, and a real `YieldVault` +
`ERC4626Adapter` over an Aave-wrapper-like target whose liquidity the test controls.

## Findings

Each was found while building the contracts, before they held anything. They are recorded because the
design choice that fixed each one is load-bearing, and a later "simplification" would reopen it.

### SRM-1 — A reserve pointed at the ramps' FX instance would mint at a rate 10,000x off
**Severity: critical if it happened.** `MovvaReserve.brlPerUsdtE18`. **Prevented.**

The ramps' FX leg is a `SignedPriceOracle` signed in centavos per dollar (540). The reserve's is the same
contract signed in millionths (5_400_000), because a centavo tick (0.19%) is too coarse to mint and redeem
at. Both instances expose the same function, `brlCentsPerUnit`, and the EIP-712 type publishers sign still
names the field `brlCentsPerUnit` for both. A deployment pointing the reserve at the centavo instance, or a
publisher tool signing the wrong unit, would price USDT at R$ 0.00054, and every redemption would be capped
only by the pro-rata rule.

**Fix.** The reserve refuses an FX leg outside R$ 1 to R$ 100 per dollar at 1e-6 (`FxOutOfRange`), and the
deploy script refuses an existing leg outside that range before deploying anything. `ScaledFxBandOracle`
lets the ramps read the millionths instance, so there need not be two instances at all.

Tests: `MovvaRateTest.test_AnFxRateInTheWrongUnitIsRefused`, `DeployMovvaTest` (the centavo instance
refused), `ScaledFxBandOracleTest.test_TheRampsCrossAndTheReserveReadTheSameSignature`.

### SRM-2 — Distributions could be sandwiched
**Severity: high (value to searchers).** `SavingsMovva`. **Fixed by design.** *(Removed with savings, client decision D1, 14 October 2026.)*

`distribute` is permissionless and mints into sMovva in one transaction. Counted at once, a searcher could
deposit in the block before and redeem in the block after, taking a share of yield proportional to capital
held for twelve seconds.

**Fix.** A distribution is excluded from `totalAssets` and vests linearly over `VESTING_PERIOD` (8 hours,
immutable, bounded 1 hour to 7 days). A new distribution is refused while the last one vests
(`StillVesting`). Folding the unvested remainder into a fresh period was rejected: anyone calling
`distribute` every block with a dust surplus would make the remainder decay geometrically and never
finish. Refusing costs at most one period of delay, and the reserve's allowance keeps accruing meanwhile.

Tests: `SavingsMovvaTest.test_DepositingJustBeforeAndLeavingJustAfterEarnsNothing` (a searcher with 10x the
savers' balance gets back at most what it deposited; one block later, twelve seconds' worth pro rata),
`test_ADistributionVestsLinearlyOverEightHours`, `MovvaDistributeTest.test_RefusedWhileTheLastDistributionVests`.

### SRM-3 — "Distribute the surplus" would have pushed the ratio below target
**Severity: medium.** `MovvaReserve._distributable`. **Fixed.** *(Removed with savings, client decision D1, 14 October 2026.)*

`surplusBrlE18` is reserve minus `target x liabilities`. Minting that much adds it to liabilities, so the
ratio after would be below target by `target x surplus`. The reserve mints the most that keeps
`(supply + amount) x target <= reserve`, which is `reserve / target - supply`.

Tests: `MovvaDistributeTest.test_ItNeverMintsTheRatioBelowTarget` (at 108.05%, 2,777.777777777777777777
Movva and not a wei more: the ratio after is exactly 10,800 bps, and one wei more would read 10,799);
invariant `invariant_DistributeNeverMintsAtOrBelowTarget`.

### SRM-4 — A frozen reserve would have paid early redeemers with value that cannot be paid
**Severity: high (fairness under a Tether freeze).** `MovvaReserve.totalUsdt`, `_pay`. **Fixed.**

Tether can blacklist the reserve. Its idle USDT is then stuck (and can be burned with `destroyBlackFunds`);
the yield-vault position is vault shares and still redeemable. Counting frozen idle USDT in the ratio would
let redeemers take the payable part at a ratio that includes the unpayable part, and leave stayers holding
the frozen coins.

**Fix.** Idle USDT counts as zero while the reserve is frozen. Redemptions and hedge withdrawals are paid
straight from the vault to the recipient (`vault.withdraw(assets, to, reserve)`), so the payable part still
pays, pro rata to what is payable. Intake (mint, recapitalize) is refused while frozen: a frozen address can
still receive USDT, and would only grow the frozen pile. `pullFromVault` is refused while frozen, because it
would turn payable shares into frozen USDT.

Tests: `MovvaRedeemTest.test_AFrozenReservePaysRedemptionsFromTheVaultProRata`,
`MovvaMintTest.test_NoIntakeWhileTetherHasFrozenTheReserve`,
`MovvaGovernanceTest.test_PullingFromTheVaultIsRefusedWhileFrozen`; on the fork with Tether's real owner,
`MovvaForkTest.test_TetherFreezingTheReserve` (ratio 9,499 bps frozen, 94,999 USDT redeemed from Aave while
frozen, 10,055 bps once lifted: the stayers kept the frozen USDT's value).

### SRM-5 — A vault's rounding at mint would have been charged to every holder
**Severity: low.** `MovvaReserve.mint`. **Fixed.**

Pricing a mint from `usdtIn` ignores that depositing into the vault can book a unit less. Movva is minted
for the value the reserve actually booked (total after minus total before), never more than `usdtIn`,
after checking that `usdtIn` arrived in full (Tether's fee switch, `TransferFeeCharged`).

Tests: `MovvaMintTest.testFuzz_MintNeverDilutesAFullyBackedReserve`, `test_ATransferFeeOnIntakeIsRefused`;
invariant (mint never creates more than `usdtIn x rate`).

### SRM-6 — At exactly par, Aave's rounding stops minting
**Severity: low (availability).** Operational. **Documented; not changed.**

Observed on the fork: after 1,000,000 USDT minted and 900,000 allocated to Aave, the reserve holds a base
unit less than it minted against, and `collateralRatioBps` - rounded down, as it must be - reads 9,999. With
the default 100% mint floor the next mint reverts `CollateralRatioTooLow(9999, 10000)` until a buffer exists.
On mainnet one block of Aave interest (about 10,000 base units on 900,000 USDT) restores it; the test shows
exactly that.

Relaxing the rounding to fix this would let every mint round against holders. The answer is the one the
design already has: **launch with a buffer**. The issuer recapitalizes the 8% that puts the reserve at its
108% target before opening gateways (docs/movva.md, "Sizing the buffer"), and the reserve rests there. The
same unit of rounding then reads 10,799 instead of 10,800, which blocks nothing (fork:
`test_TheRealMovesTenPercentBothWays`).

Test: `MovvaForkTest.test_AGatewayMintsRealUsdtIntoAaveAtTheRealFeedsRate`.

### SRM-7 — Distributing into a vault of dust savers strands the distribution
**Severity: low.** `SavingsMovva.notifyDistribution`. **Fixed.** *(Removed with savings, client decision D1, 14 October 2026.)*

sMovva's six virtual decimals protect against the inflation attack by absorbing donations into virtual
shares. A distribution into a vault with a few wei of real shares is, to the arithmetic, a donation: nearly
all of it would belong to nobody. sMovva refuses a distribution with less than one whole share outstanding
(`NoSavers`).

Tests: `SavingsMovvaTest.test_NoDistributionIntoAVaultWithLessThanOneShare`,
`test_TheFirstDepositorCannotRobTheNext`, `MovvaDistributeTest.test_RefusedWithNoSavers`.

Residual: if every saver leaves while a distribution vests, its unvested remainder stays in sMovva for
whoever saves next. It is still Movva backed by the reserve; it is simply nobody's yet.

### SRM-8 — "Lowering a limit is instant" is backwards for a floor
**Severity: high if copied literally.** `MovvaReserve.setCollateralRatios`. **Fixed.**

docs/movva.md said lowering a limit is instant. For a cap (supply, hedge limit, distribution cap, fees) that
is right. For a collateral ratio it is the opposite: lowering `minMintCollateralRatioBps` lets Movva be minted
into a less-backed reserve, lowering `minWithdraw...` lets more USDT go to the hedge, lowering the target
lets more be distributed. The setter classifies by risk: lowering any ratio waits, raising is instant, and
none may be below 100%, and they must stay ordered (SRM-13). docs/movva.md now says so.

Test: `MovvaGovernanceTest.test_LoweringACollateralRatioWaitsRaisingDoesNot`, `test_NoRatioBelowOneHundredPercent`.

### SRM-9 — A token minter that can burn anyone's balance
**Severity: medium (defence in depth).** `Movva.burn`. **Designed out.**

A `burn(from, amount)` restricted to the reserve would make any reserve bug a way to destroy balances in
wallets, Privacy Pools and sMovva. `Movva.burn` destroys only the reserve's own balance; a redeeming gateway
transfers Movva to the reserve first (allowance or permit).

Tests: `MovvaTokenTest.test_TheReserveCanOnlyBurnWhatItHolds`, `test_APermitReplacesTheApproval`.

### SRM-10 — Instant oracle legs would let a governor and one gateway print Movva
**Severity: high.** `MovvaReserve.setOracle`. **Fixed.**

The ramps' band oracles repoint instantly, correctly, because a band cannot move value. The reserve's rate
does. Repointing a leg or lengthening a max age waits out the delay; only tightening an age is instant.

Test: `MovvaGovernanceTest.test_RepointingAnOracleWaitsTighteningAnAgeDoesNot`. See "What stays trusted" for
the part this does not cover: the FX oracle's own publisher set.

### SRM-11 — Adding backing waited on the oracle
**Severity: low (availability).** `MovvaReserve.recapitalize`. **Fixed.**

The event carries the ratio after, and reading it reverts when a leg is stale. Recapitalizing during an FX
publisher outage - exactly when the issuer may want to add backing - would have reverted. The ratio is read
with a `try`; the event then carries 0, meaning unreadable.

Test: `MovvaRecapitalizeTest.test_RecapitalizingWorksWithAStaleRate`.

### SRM-12 — Pulling out of the vault would be undone by the next mint
**Severity: low.** `MovvaReserve.pullFromVault`. **Fixed.**

Every intake sweeps idle USDT into the vault. A governor pulling USDT out of a vault under stress would see
it swept back by the next gateway mint. `pullFromVault` also pauses vault deposits until
`setVaultDepositsPaused(false)`.

Test: `MovvaGovernanceTest.test_TheYieldVaultChangesOnlyWhenEmpty`, `test_VaultDepositsPauseAndResumeInstantly`.

### SRM-13 — The proposed withdraw floor sat above the target, and the hedge could not be fed
**Severity: high (the peg's mechanism).** Parameters and `MovvaReserve.setCollateralRatios`. **Fixed.**

Found by the hedge desk's stress tool (`shock()` in `packages/movva`), not by a test of the contract - every
rule was enforced exactly as written. The rules were wrong together. `distribute` pays out everything above
the target, so the reserve rests AT the target. *(Since D1 there is no `distribute`; the issuer keeps the reserve at the
target by taking surplus out through the hedge path, so the sizing argument stands.)* The first proposal put that target at 102% and the withdraw
floor at 105%. At rest, the treasurer could withdraw nothing; a dollar rally's first ~3% of reserve gains were
unreachable exactly when the B3 short called for margin, and the 2% daily limit covered under half of a
one-day 5% call. The issuer would have posted its own capital for moves the reserve was built to absorb.

**Fix.** Defaults re-sized with the same tool: target 108%, withdraw floor 103%, hedge limit 8% of the reserve
per day (mint floor 100% and distribution cap 10 bps a day unchanged). From rest, the reserve alone covers a
±5% one-day move and the 2024 rally spread over 252 sessions (docs/movva.md, "Sizing the buffer"). And the
contract now refuses any setting where the order breaks - `minMint <= minWithdraw <= target`, else
`RatiosOutOfOrder` - on the instant path and when a delayed change executes. The first proposal's ratios can no
longer be set; the deploy script refuses them before broadcasting anything.

Tests: `MovvaGovernanceTest.test_RatiosOutOfOrderAreRefused` (each violation), `test_TheFirstProposalIsRefusedThroughTheDelay`,
`test_EqualRatiosAreAllowed`, `test_TheDefaultsAreTheSizedOnesAndInOrder`; `MovvaHedgeTest.test_AFivePercentDollarRallyFromRestIsWithdrawnToTargetInOneDay`
(113.4% after the rally; 51,428.571428 USDT back to exactly 10,800 bps, worth R$ 291.600 against R$ 270.000 of
variation margin, inside the 86,400 USDT limit, with room above the floor for the initial-margin add-on) and
`test_AFivePercentDollarFallFromRestStaysFullyBacked` (102.6%: mint and par redemption continue);
invariant `invariant_RatiosStayInOrder` (the governor re-sets ratios in and out of order, on both paths);
`DeployMovvaTest` (102/105 refused).

The trade: a larger buffer is capital the issuer ties up at launch (8% of the supply it opens with), and a
larger hedge limit lets a compromised treasurer key move up to 16% of the reserve in a day - still only to the
issuer's own hedge account, and never below 103%.

### SRM-14 — A 100 bps band on the Movva escrows stalled exits under partial backing
**Severity: medium (liquidity exactly when it matters).** `contracts/script/DeployRamp.s.sol` `MOVVA_BAND_BPS`.
**Fixed (default 300).**

The reserve is Movva's band oracle, and its mid is the collateral ratio rounded to the **nearest** whole centavo,
because the escrows quote whole centavos per token. At 98.56% backing the mid is 99 while a gateway's redemption
pays 98.56. The escrows refuse `diff * 10_000 > mid * BAND_BPS`, so at the first default of 100 bps only a sale
at exactly 99 passed - above what redeeming pays. No LP buys at a loss, so no holder could sell Movva on the
off-ramp until backing recovered: exits stalled exactly when holders most want out. Found building the wallet's
sale path (`packages/wallet/src/movva/sell.ts`), which has to price a sale inside both the band and the LP node's
margin check.

**Fix.** The default band is 300 bps. The lowest admitted price is then at least ~1.5% under the redemption value
at every ratio (the worst case is a ratio at x.5%, e.g. 98.5% -> mid 99 -> 97 admitted), and at par offers pass at
97-103 centavos. The band is a fat-finger bound, not the peg: the price a user gets comes from LPs competing in the
matcher and is checked by the wallet before anything is locked. A finer fix - sub-centavo band prices, or an exact
cross-multiplied band check - would change `IPriceOracle` and both escrows, and was not made.

Note that a gateway's own policy can still decline to buy below par: the LP node holds Movva rather than redeem
under `minCollateralRatioBps` (default 100%), and does not claim sales it would have to hold. The band now leaves
that choice to the LP instead of making it for them.

Tests: `DeployRampTest._movvaGetsItsOwnTightPair` (at par 100 and 103 pass, 104 refused; at 90% backing 88 passes,
93 refused; at 98.56% a sale at 97 centavos opens and 96 is refused).

### SRM-15 — With Pyth as the FX leg, the rate is stale most of the week
**Severity: high if unhandled (the product closed at night and at weekends, or minting at a weekend-old rate).**
`MovvaReserve` (`_rate`, `bandBrlPerUsdtE18`, `brlCentsPerUnit`), `PythFxOracle`, `ScaledFxBandOracle`. **Designed
around (14 September 2026).**

Mova replaced the signed FX leg with Pyth's FX.USD/BRL (SR2-35 in security-review-phase2.md). Pyth publishes it only on
weekdays, 08:00-17:00 New York time. A reserve that read it as before had two bad options: refuse everything off-hours -
including its band, so Movva's escrow pair stopped quoting and no user could buy or sell Movva at night or at weekends -
or accept a weekend-old rate everywhere, letting a gateway mint or redeem at Friday's close after a weekend move it can see
in crypto markets.

**Fix.** The reserve reads its FX leg two ways. Everything that moves value - `mint`, `redeem`, `withdrawToHedge`,
`distribute` (removed since, D1), and the ratios and previews that price them - reads the leg's rate and refuses once it is older than
`fxMaxAge`, at any hour. The band, `brlCentsPerUnit`, and `bandBrlPerUsdtE18` read it as a band (`BandRead`): outside
the FX core session, the last close, stamped current. So Movva keeps trading on its escrow pair while minting and
redeeming wait for the market; an LP sells the Movva it holds and stops quoting when it runs out.

**Residual risks.**
- **Under partial backing the band's ratio uses the close.** The mid is R$ 1,00 x min(1, ratio); a weekend move changes
  the ratio only the rate can see. The band bounds a fat finger, not a price, and no value moves at it.
- **Selection by whoever posts.** Posting a Pyth update is permissionless, and any update newer than the stored price
  is accepted. A gateway can therefore post, from the updates Hermes has signed since the last post, the one most
  favourable to the mint or redemption it is about to make. The choice is bounded by how far the rate moves within the
  keeper's refresh interval, and the 10 bps fees remove the incentive for moves below that. It replaces the signed leg's
  lag arbitrage ("The rate" below) rather than adding to it.
- **Reopening.** The first price after a weekend can differ from Friday's close by the whole weekend's move. Nothing
  mints or redeems in between, so nothing is priced at the gap; the band jumps at once.

Tests: `MovvaOffHours.t.sol` (over a weekend mint, redeem and the ratio refuse with the leg's `StaleRate`, the band
reads par from Friday's close stamped current, a Movva offer posts and a holder's sale inside the band opens; at
Monday's core session the band refuses until the keeper posts, then minting resumes), `PythFxOracle.t.sol`.

### SRM-16 — A rate that nobody cross-checks, and a breaker that needs a key, are both wrong
**Severity: medium (a wrong rate inside R$ 1-100 over-mints or over-pays; a key-operated pause is an admin key).**
`MovvaReserve` (`BREAKER`, `breakerTripped`), `DivergenceBreaker`, `ChainlinkCrossSource`, `UniswapV3TwapSource`.
**Built (24 September 2026, client decision).**

The reserve's one rate (Chainlink x Pyth) was the only thing between a bad feed and a mispriced mint or redemption; a
pause for it would have needed a key, which the client's principle forbids. The breaker compares the reserve's rate with
independent sources at call time and reverts mint, redeem and hedge withdrawals (and `distribute`, until it was removed with savings, D1) while they disagree beyond a
deploy-time band, with no state, no setter and no owner - it cannot latch (`testFuzz_NeverLatches`), and nobody can lift it.
A tripping source that reverts, is stale or thin counts as disagreeing; it never substitutes.

**Residual risks.**
- **Denial of service.** A tripping thin-liquidity TWAP lets whoever can move it halt mint and redeem, with no key
  involved. This is the price of "no key" plus "a TWAP can trip it"; docs/movva.md ("The divergence breaker") sets out the
  cost, the mitigations (wide band, deep pool, `trips=false`) and the median-of-three alternative that removes it, which is
  not built. It is a decision for the client, not a defect.
- **A halted redeem.** The breaker halts redemptions, which the reserve's earlier rule said nobody could. Deploy option
  `MOVVA_BREAKER_HALTS_REDEEM=false` restores it. A halt coincides with the moments of most stress.
- **A correlated failure** of every source (all stale) halts everything until one is fresh, as designed.
- **The TWAP's own error**: a tick average rounds, and `observe` needs history for the window; a freshly created or
  re-initialised pool halts the breaker (reverts) until it has it.
- **Coverage.** Setting `MOVVA_BREAKER=off` removes it; a breaker whose only source has `trips=false` can never halt.

Tests: `MovvaBreaker.t.sol` (`BreakerTest`: halts each action, clears itself with no call, a reverting or zero source halts,
the exact band edge, a non-tripping source cannot halt, `HALTS_REDEEM=false`, constructor refusals; `SourcesTest`: the TWAP
at both token orders, thin liquidity and short history revert, the Chainlink cross and its staleness), `DeployMovva.t.sol`
(wiring, refusals, `MOVVA_BREAKER=off`).

### SRM-17 — The hedge withdrawal limit had no way past it but a governor change
**Severity: low (operational), with a design note.** `MovvaReserve` (`queueHedgeWithdrawal`, `executeHedgeWithdrawal`),
`LimitedYieldVault`. **Built (24 September 2026, client decision).**

Above `hedgeLimitBps` per day the treasurer was stuck. The client's rule is a timelock, not a multisig: the request is
announced and anyone executes it after the delay, with nobody able to cancel, approve or reorder it. The reserve's queue
fixes the recipient and amount at announcement, re-checks the ratio floor, the breaker and recipient at execution, and marks
a request done before paying. `LimitedYieldVault` does the same for a vault owner above a per-owner daily limit, escrowing
the shares at request time.

**Residual risks.** The treasurer (one key) can queue until the floor binds: the delay and the floor are the bound, the
treasurer is not removed. No cancel: a request the floor still allows will execute. The vault's limit is per address
(sybil-able). A queued vault request pays the value at execution, not at request. Gateway redeems have no limit (open
question in docs/movva.md).

Tests: `MovvaBreaker.t.sol` (the hedge queue: waits, executes once for exactly the amount to the recorded recipient even
after the hedge treasury is repointed, floor and breaker bind at execution, no cancel selector, fuzz of exact payment, and
`HedgeQueueInvariantTest`: over random queueing, executing and waiting, the hedge account receives exactly the executed
requests, once each, and a request's recorded amount and recipient never change; `LimitedYieldVaultTest`: limit, refill,
slow lane burns exactly the queued shares once, allowance, fuzz).

## Threat model

### The rate

`brlPerUsdtE18 = Chainlink USDT/USD x BRL/USD`, the BRL/USD leg Pyth's FX.USD/BRL through `PythFxOracle` (or a signed
quorum's). Each leg is checked against its own max age (25 hours, 1 hour), zero, negative and future timestamps are
refused, and the FX leg must be in R$ 1-100.

- **Stale legs** revert every action that prices anything. The band oracle reverts too while the FX market is open;
  while it is closed the band reads the last close and the ramps keep quoting Movva (SRM-15). `recapitalize` does not
  wait (SRM-11). Tests: `test_EachLegHasItsOwnMaxAge`,
  `test_ZeroNegativeAndFutureAnswersAreRefused`, `test_FeedDecimalsAboveEighteenAreRefused`,
  `test_AnFxOracleWithNoPriceYetReverts`, `test_TheBandRevertsWhenTheRateIsStale`.
- **A wrong rate inside the bounds** is the residual risk. What it can do depends on who acts on it:
  - *alone* (no gateway, no treasurer): nothing. Since the savings removal (D1, 14 October 2026) Movva is minted only
    by `mint`, which only a gateway calls. (Before it, the one path was `distribute`, capped at
    `maxDistributionBpsPerDay` of supply per day: at the default 10 bps, a rate 43% too high cost 0.1% of supply a day.
    `test_AWrongRateWithoutAGatewayMovesAtMostTheDistributionCap` went with it.)
  - *with a gateway*: a high rate over-mints (bounded by the supply cap and the gateway's contract with the
    issuer); a low rate over-pays redemptions, but never more than the redeemer's pro-rata share of the
    whole reserve, because the payout is `min(par, pro rata)`. Tests: `testFuzz_RedeemNeverPaysMoreThanMinOfParAndProRata`,
    invariant `invariant_RedeemNeverPaysMoreThanMinOfParAndRatio`.
  - *with the treasurer*: at most the hedge limit per day, only to the fixed hedge treasury.
- **Lag arbitrage.** A gateway that sees the market move before the rate on-chain does can redeem at the stale
  rate when the real weakens, or mint when it strengthens, capturing up to the unposted move on its volume. With
  Pyth the gateway can also post the update it prefers among those signed since the last post (SRM-15), so the
  exposure is the move within the keeper's refresh interval. The FX max age bounds the lag to an hour; the
  keeper's cadence should keep it far shorter, and fees above the typical lag remove the incentive. The reserve deploys with 10 bps to mint and
  10 bps to redeem (docs/movva.md, "Fees"), so a lag under 0.1% is not worth exploiting on one leg; a larger one
  still is. This is why gateways are contracted institutions (docs/movva.md, "Why LPs mint").
- **A USDT depeg** reaches the ratio through Chainlink, bounded by the feed's own deviation threshold.
  Tests: `test_ADepegOnTheFeedLowersTheRatio`; fork `test_AUsdtDepegReachesTheRatioThroughTheFeed` (mocked
  $0.90: 9,002 bps, band 90 centavos, pro-rata redemption).

### Gateways

Admitted only through the delay, removed instantly. A gateway can mint (while the ratio is at least the mint
floor, within the supply cap, with a slippage bound) and redeem (never more than min(1, ratio) of par). It
cannot pause anything, move USDT anywhere else, or touch a holder's Movva. Everyone who is not a gateway exits
by selling Movva to one over the off-ramp: **Movva holders have no direct on-chain redemption right**, which
is a legal and commercial promise the issuer makes, not a contract property. Tests: `MovvaMintTest`,
`MovvaRedeemTest`, `test_AddingAGatewayWaitsRemovingDoesNot`.

On the gateway's own side (`packages/lp-node`, "The Movva gateway"): the node trusts the reserve's rate
unless the LP configures `usdtPrice`, so a rate that reads low when it mints, or high when it redeems, costs
the LP - bounded by its per-mint and daily caps, which have no defaults. A mint or redeem transaction stuck in
the mempool blocks further gateway transactions until it mines or drops. An intent whose nonce was spent
without a recorded hash counts as having moved money (`CONSUMED`). Safety assumes no reorg deeper than the
node's `confirmations`, as for the rest of the node.

### Treasurer and hedge treasury

`withdrawToHedge` sends USDT only to `hedgeTreasury` (changing it waits), only while the ratio AFTER is at least
`minWithdrawCollateralRatioBps` (103%), and within a bucket of `hedgeLimitBps` (8%) of the reserve that drains
continuously at that rate per 24 hours. Worst case in any 24 hours: two limits (a full bucket, then a day of
refill; 1.75 limits measured with hourly withdrawals, because the limit shrinks with the reserve); the floor
binds independently - from rest at 108% it allows 5% of the reserve, 50,000 USDT per 1,080,000. A compromised
treasurer key moves surplus above 103% to the issuer's own account and nothing else; revoking it is instant.
Tests: `MovvaHedgeTest` (9), including `test_AtMostTwoLimitsInAnyDay`, `test_NeverBelowTheWithdrawFloor`, the two
±5% moves from rest; invariant `invariant_WithdrawToHedgeNeverBreachesTheFloor`.

### Governor and guardian

Every risk-increasing change waits out `GOVERNANCE_DELAY` (48 hours by default) in public; see the reserve's
header for the list and `MovvaGovernanceTest` (20 tests) for each. The self-call cannot be aimed at `mint`,
`withdrawToHedge`, `pullFromVault` or `pauseMint` (`test_OnlyGovernanceFunctionsCanBeScheduled`; `distribute` was on this list until it was removed, D1).
No governance function moves USDT anywhere but back into the reserve (`pullFromVault`). The guardian can only
pause minting; nobody can pause redemptions (`test_TheGuardianPausesMintAndOnlyTheGovernorResumes`).

What the delay protects is limited by who can react: gateways can redeem during it; ordinary holders can only
sell to gateways. A malicious scheduled change (a new vault, oracle or gateway) is visible for 48 hours to the
monitor and to anyone watching `ChangeScheduled`.

### The issuer's off-chain hedge

Not enforceable on-chain. If the issuer does not hedge, the 8% buffer absorbs a real strengthening of up to
about 7.4%; beyond that the ratio shows below 100% within one FX publication, minting stops, redemptions go pro
rata, and the band oracle drops below R$ 1,00 on the ramps. Fork, from rest at 108% (10,799 bps after Aave
rounding), `test_TheRealMovesTenPercentBothWays`:

- real +10%: 11,879 bps; a full day's limit, 86,400 USDT, to the hedge account, leaving 10,929 bps. That
  releases R$ 513.187 against R$ 540.120 of variation margin on the $1,000,000 short: a 10% day is beyond one
  day's limit by R$ 26.932 (0.5% of supply) before the broker's initial-margin add-on and conversion costs,
  which is what the free margin at the broker is for.
- real -10% from the same rest: 9,719 bps; minting refused; a 10% redemption pays 107,999 USDT where par was
  111,111; the short's gain, 111,142 USDT, covers the 108,001 USDT that restores 10,800 bps, and minting resumes.

If the issuer does not bring hedge gains back, the reserve stays short: the contracts publish it; they cannot
fix it.

### USDT and Tether's powers

- **Blacklist** the reserve: SRM-4. A blacklisted recipient or hedge treasury is refused
  (`test_NobodyIsPaidIntoAFrozenAddress`, `test_AFrozenHedgeTreasuryIsNotPaid`).
- **destroyBlackFunds**: burns frozen idle USDT, which already counted as zero.
- **Fee switch** (up to 19 bps, 49 USDT): intake refused; exits deliver less to the recipient, as on `YieldVault`.
- **Pause**: every transfer stops; views keep working; nothing can be minted or redeemed until it lifts.
- **Upgrade/deprecate**: USDT's proxy-like `deprecate` can redirect calls to a new contract. Out of scope for
  code; a monitored event.

### Aave and the yield vault

The reserve deposits into one `YieldVault(USDT)`, which allocates to Aave through the `ERC4626Adapter`. Aave
losses and the vault's valuation reach the ratio through `previewRedeem`. Borrowed-out liquidity makes large
redemptions wait: they revert up front with what is available and burn nothing. Fork:
`test_RedemptionBeyondAavesInstantLiquidityRefusesCleanly` (349,999 USDT payable of ~1,000,000; the whole
supply refused; exactly the payable amount redeemed). The vault's own keeper, guardian and governor are trust
points for the reserve: **use a dedicated `YieldVault` instance for the reserve**, not the shielded yield
product's vault, so its liquidity, deposit cap and governance are the reserve's alone.

### Rounding

Always against the reserve: the vault at `previewRedeem`; reais and the ratio rounded down; `liabilitiesUsdt`
up; mint priced from what was booked (SRM-5); mint and redeem fees rounded up; sMovva's unvested amount rounded
up (so its assets round down) *(sMovva removed, D1)*. The one visible cost is SRM-6.

### Reentrancy

Every state-changing external function on the reserve is `nonReentrant`. The only
external contracts called are USDT (no hooks), Movva (no hooks) and the governor-chosen vault (itself
`nonReentrant`); sMovva, fixed to the reserve and `nonReentrant` too, was removed with savings (D1). Redeem burns before
paying; withdrawToHedge writes the bucket before paying. (`distribute`, removed, wrote its clock before minting.) Intake measures what arrived before minting, the
order OpenZeppelin's ERC-4626 uses.

### The band oracle on the ramps

`brlCentsPerUnit` is R$ 1,00 x min(1, ratio), to the nearest centavo, never above 100
(`invariant_TheBandNeverReportsAboveOneReal`). Nearest means a reserve at 99.5% still bands at R$ 1,00: a buyer
can pay up to half a centavo per Movva more than a pro-rata redemption returns. The ramps quote whole centavos,
so this is the band's resolution, not a choice of it. A real `FiatEscrow` with Movva listed accepts a 100-centavo
offer at par and refuses it at 90% (`test_TheReserveIsMovvasBandOnTheOnRamp`).

## What stays trusted

- **The issuer**, to hedge the dollar exposure and bring gains back (docs/movva.md, "What stays trusted").
- **Pyth's publishers and the Wormhole guardians**, for the rate (SR2-35 in docs/security-review-phase2.md). The
  FX oracle's governor is not: repointing the feed or loosening its limits waits out its `GOVERNANCE_DELAY`, and
  the reserve refuses a leg still in setup (SR2-30). Mova's Pyth keeper is trusted only to keep posting: it can
  post signed updates or none, and choosing among recent ones is SRM-15's residual. A deployment on a
  `SignedPriceOracle` leg trusts its publisher quorum instead, under the same delay (SR2-30, SR2-31).
- **Chainlink** for USDT/USD; **Tether** for USDT; **Aave** and the yield vault's roles for the vault position.
- **Gateways**, as contracted institutions, for the value a wrong or lagging rate can move.
- **The governor multisig**, within the 48-hour delay.

## Open risks that are decisions, not defects

- **No freeze on Movva.** Deliberate until legal counsel decides (docs/movva.md). Adding one later is a new
  token.
- **Non-gateway holders cannot redeem on-chain.** The peg for them is the gateways' off-ramp liquidity.
- *(Removed, D1: there is no `distribute`.)* **Distribution delay griefing.** Anyone can call `distribute` as soon as a vest ends with whatever small
  surplus exists, pushing a larger distribution back by one period. Surplus is not lost, but allowance is:
  every distribution restarts the allowance clock, so a dust distribution after a quiet day also discards up
  to a day of accrued allowance (found while building the distribution keeper). The keeper
  (`packages/yield/src/movva-keeper.ts`) only avoids doing this itself - it waits for a minimum or a
  day's wait, above a gas floor; it cannot stop anyone else. Advancing the clock in proportion to the
  allowance used would remove most of the incentive and is a candidate contract change.
- *(Removed, D1: there is no sMovva.)* **All savers leaving mid-vest** strand the unvested remainder for future savers (SRM-7).
- **The buffer and the sizing rest on placeholders.** B3 initial margin (10% of notional in the shock tool) and
  conversion cost (30 bps) are assumptions until the broker confirms them; the 252-session case spreads the
  2024 move evenly, which a real path does not. Re-run `shock()` with the broker's figures before launch.
- **Fees are a benchmark, not a measurement.** They deploy at 0.10% to mint and 0.10% to redeem (the 20% distribution fee went with savings, D1), set by comparison with a fiat stablecoin issuer (and, for the removed distribution fee, a renda fixa fund) (docs/movva.md, "Fees"). A 10 bps fee deters rate-lag arbitrage only for lags under 0.1%; a larger lag remains a gateway's to exploit, bounded as "The rate" sets out.
- **The hedge limit counts the reserve after a withdrawal shrinks it**, so a shrinking reserve refills a little
  slower than a day (`test_TheLimitRefillsContinuously`). Conservative, and stated.

## What has not been done

- Slither ran over `contracts/movva` only (the repo's detector set, `--fail-medium`): exit 0. Its medium
  findings were triaged in place with a reason beside each suppression - `reentrancy-balance` on the two
  intentional before/after brackets (mint's booked value, withdrawToHedge's ratio re-read), `incorrect-equality`
  on zero-amount guards, `unused-return` on vault calls whose effect is re-read, `missing-zero-check` on
  `setTreasurer` (zero revokes). What remains is low or informational: timestamp comparisons (every max age
  and, before D1, the vesting clock are timestamps by design), naming of immutables, and one `this.` read in
  `recapitalize` (the `try` needs an external call). The repository-wide gate has not been run in this pass.
- No external audit. No formal verification of the rounding claims beyond the invariant campaign.
- The Pyth keeper (`packages/yield`), hedge statements (`packages/movva`) and the monitor's Movva alerts are other work.
