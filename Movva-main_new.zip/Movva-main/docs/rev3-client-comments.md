# The client's comments on Rev. 3, read as requirements

**What this is.** Jhon's fifteen comments on the MVP Scope Rev. 3 (Google Doc, evening of 16 September 2026), each
turned into what it asks of the build, what it changes against what exists, and what still has to be asked. Written
17 September 2026 against commit `5cd9e5e`. The comments are quoted as written.

**The short version.** The comments do three different things at once:

- **Cut scope for V1.** Tiers, retention and daily caps go; shielded transfers and moves between sub-wallets go to V2;
  V1 is "hold, sell USDT, burn MOVVA".
- **Change two foundations.** Replace the Privacy Pools fork with the Kohaku SDK and Umbra, and make the MPC
  permissionless and decentralised rather than a Movva-run co-signer. Either is a re-architecture, not a feature.
- **Widen the ramp.** Liquidity from centralised and decentralised exchanges as well as P2P providers.

Two things are pending on the client's side: the yield venue ("until Monday", 21 September) and, by implication, the
treasury and backing document that Rev. 3 §9.7 waits for.

## 1. "Use Kohaku SDK and Umbra instead of a fork" (four comments: §1, §2.3, §4.1, §4.2)

**What was said.** On every mention of the Privacy Pools fork: *"We think is better and simple use to build using
Kohaku SDK and Umbra instead fork."*

**What those are, as of September 2026.**
- **Kohaku** is the Ethereum Foundation's privacy-wallet toolkit, released as an SDK on 25 May 2026. It is a wallet-side
  library: it lets a wallet route through existing privacy protocols and generate stealth addresses, and it relays
  through the ERC-4337 mempool. Its **Railgun** integration is operational; its **Privacy Pools** and Tornado
  integrations were still in development at the SDK release. It is not a shielded pool itself.
- **Umbra** (ScopeLift) is stealth addresses: ERC-5564 and ERC-6538. A payer derives a one-time address from the
  recipient's spending and viewing public keys and announces an encrypted secret; the recipient scans announcements with
  the viewing key. It hides **who received**. It does not hide the amount, does not break the link between a deposit
  and a later withdrawal, and has no pool, no association set and no compliance layer.

**What the request means.** "Instead of a fork" means Movva stops deploying and owning its own Privacy Pools contracts
and instead uses, through Kohaku, a privacy protocol someone else runs, with Umbra for receiving at unlinkable
addresses. There are two readings, and they lead to different products:

| Reading | What holds the shielded balance | What it gives | What it costs |
|---|---|---|---|
| **Kohaku → Railgun** (the operational integration) | Railgun's shielded balance, which takes any ERC-20, so MOVVA can be shielded as is | Native shielded transfers with **hidden amounts** (Rev. 3 §5.3 Option B, for free), native viewing keys (the "Railgun-style" key Rev. 3 §8 names), an existing relayer network | Railgun's compliance model (Private Proofs of Innocence), its fees and its broadcaster network replace the ASP, the fork deltas and every shielded component here |
| **Kohaku → canonical Privacy Pools** (0xbow's deployment, unforked) | 0xbow's pools | Keeps the association-set compliance model Rev. 3 is written around | 0xbow decides which assets get a pool and who is approved; the MOVVA and sMOVVA pools (sMOVVA since removed, D1), the escrow-as-depositor design, the yield and transfer adapters and the ragequit routing all disappear or move outside Movva's control; the Kohaku integration was not finished at release |

Umbra fits either reading in a narrow role: giving a user a fresh address per receipt, which this repository does today
with a fresh smart account per sale.

**What it changes against what exists.** Nearly everything shielded. The escrow depositing into the pool under the
user's precommitment, `ShieldedYieldRouter` and the zap relayer (both since removed with savings, client decision D1, 14 October 2026), `packages/viewing-key`
(notes, epochs, disclosure, the auditor's reconciliation against pool state, the note vault), the wallet's ledgers, the
app's prover worker and its restore, and the Sepolia rehearsal all sit on Movva's own pools. Under Railgun the audit
viewing key would be Railgun's, and the disclosure package, scoping and revocation would be rebuilt over it; under
canonical Privacy Pools the viewing key work survives but the pools and adapters do not.

**Ask at the call.**
1. Which protocol behind Kohaku: Railgun, or Privacy Pools on 0xbow's deployment?
2. Is the association-set (ASP) compliance model still required, or is Railgun's proof-of-innocence acceptable? Rev. 3
   §5.1 and §8 both assume the ASP.
3. Who approves a MOVVA pool if the pools are not Movva's?
4. Is Umbra wanted for receiving only, or as the whole privacy layer? On its own it does not meet Rev. 3 §3's
   "without linking sender and recipient on-chain" for anything but the receiving side.
5. Does "simpler" mean fewer contracts to audit, or faster delivery? Under Railgun the audit surface moves to Railgun's
   circuits, which are audited, but the integration and the viewing-key rebuild are new.

## 2. "Permissionless and decentralised MPC" (§1 and §5.1)

**What was said.** On "MPC": *"We defined permisionless and descentralized MPC."* On the token's "Admin keys: none" row:
*"MPC also"*, read as: the MPC must have no admin either.

**What exists.** The account's second key is a Movva-run co-signer (`packages/cosigner`): it signs only after a
user-verified passkey signature over the same operation, refuses authority changes, serves the recovery veto, and
since this week generates FROST keys with the device. It is trust-minimised, but it is one operator, and Movva runs it.

**What the request means.** The second share moves to a network that anyone may join and that no one, Movva included,
administers. Candidates are threshold-signature networks (for example Lit Protocol, Silence Laboratories, or a FROST
network of independent operators). Whether the network signs ECDSA or Schnorr decides which account type it fits:
ECDSA suits a Safe owner or the Kernel passkey validator's co-signer slot; Schnorr suits `FrostValidator`, which is
already built for a group key.

**What survives.** The passkey, the recovery Delay and its veto, the policy that refuses authority changes, and the
FROST validator. What goes: the co-signer as signer of record. What is new: the network's enrolment and its liveness
and cost model.

**Ask at the call.**
1. Which network, or which properties define "permissionless" here: anyone can run a node, anyone can enrol, or both?
2. Who pays the network's fees per signature?
3. Does the policy layer (refusing owner changes, the veto) stay, and where does it run if Movva runs no signer?
4. Recovery when the network is unreachable: Rev. 3 §4.3 requires passkey signing to continue.

## 3. "Not only P2P but CEX and DEX also" (MVP capabilities table and §2 fiat rails)

**What was said.** On the on-ramp and off-ramp rows and on the fiat-rails row: *"Not only P2P but CEX and DEX also."*

**What the request means.** BRL should enter and leave not only through peer-to-peer liquidity providers proving bank
payments, but also through centralised exchanges (BRL pairs on Binance, Mercado Bitcoin, Bitso, Foxbit and the like)
and decentralised exchanges (on-chain swaps between USDT and a BRL stablecoin such as BRZ or BRLA).

**What exists.** A P2P network only: escrow, zkTLS proofs, the LP node, the matcher. The LP node is, in effect, what an
exchange desk would run to act as a liquidity provider.

**What each route needs.**
- **CEX as a route:** an exchange account holding funds (custodial by nature), the exchange's KYC on that account, its
  API for BRL deposits and PIX payouts, and a reconciliation between the exchange ledger and the escrow. The cleanest
  fit with what exists is *a CEX acting as a Phase A LP*: the LP node with a bank adapter and a pricing adapter backed
  by the exchange. That keeps the escrow and the proof requirement. A route where the user's BRL goes into Movva's
  exchange account is a custodial float, which Rev. 3 §2 removed.
- **DEX as a route:** a liquid USDT/BRL-stablecoin pool on Ethereum L1, oracle bands over the swap price, and the
  stablecoin issuer's own fiat rail for the last leg to PIX. It provides crypto-to-crypto conversion, not BRL in a bank
  account, so on its own it is not an on-ramp.

**Ask at the call.**
1. CEX as an LP (non-custodial for Movva, the exchange bears custody), or CEX as Movva's own float?
2. Which BRL stablecoin for DEX, and who makes its fiat leg?
3. Does the proof-of-payment requirement (§7.5) apply to exchange settlements, or is the exchange's API record enough?

## 4. Tiers, retention and daily caps: removed (§2.1, §5.1 area, §6.2)

**What was said.** *"this we will remove"* (the tier and retention matrix), *"We will remove tiers maybe next version"*,
*"we remove this"* (limits across sub-wallets).

**What it means.** No tier ladder, no retention, no per-user daily caps in V1; possibly in a later version.

**What exists.** Per-payer caps were built in the LP node on 17 September and are **off unless configured**, so nothing
has to be removed: leave them unset. The retention and withdrawal-speed items Rev. 3 §12.1 asked for were not built and
now need not be. The scope document's §2.1, §6.2 and §12.1 should be edited accordingly.

## 5. Shielded transfers and moves between sub-wallets: V2 (§2.3, §5.2 step 4)

**What was said.** *"Only V2. First the user can hold and sell usdt and burn movva."* and *"V2"*.

**What it means.** V1 has no shielded internal transfer and no move between sub-wallets. V1's user flow is: hold, sell
USDT, burn MOVVA.

**What exists.** Nothing, since 12 October 2026: the client removed shielded transfers (§5.3) from scope - users deposit
and withdraw only - and `ShieldedTransferRouter`, built and proven on a fork, was deleted rather than kept out of V1.
The phrase "hold and sell USDT" needs care: today the user holds **MOVVA** (shielded) and the **reserve** holds USDT;
a user never holds USDT. If V1 users are to hold and sell USDT themselves, that is a shielded USDT pool and an off-ramp
that takes USDT from the user, which is closer to Rev. 2's original ramp than to the Movva rail.

**Ask at the call.** Does the V1 user hold USDT, MOVVA, or both? "Burn MOVVA" by the user means redeeming at the
reserve, which today only a gateway LP does.

## 6. Sub-wallets hold "MOVVA and others" (§6.2, moving funds)

**What was said.** On "moving funds only through the shielded transfer path": *"Yes it is possible, movva and others."*

**What it means.** Sub-wallets are wanted, and they hold more than MOVVA: other assets, USDT at least. Moving between
them is possible (and, per comment 5, V2).

**What exists.** No sub-wallets; see [rev3-conformance.md](rev3-conformance.md), decision 2. The requirement grows by
one dimension: multi-asset.

## 7. "Miss ZK proof, but a fork of zkp2p has this" (§5.1 supply invariant)

**What was said.** *"Miss ZK proof. but if fork zkp2p have this to proof the payment."*

**What it means.** The mint path must rest on a zero-knowledge proof of the fiat payment, as ZKP2P does.

**What exists.** It does, and it is enforced on-chain: `ReclaimZkTlsVerifier` accepts a zkTLS proof of the payer's bank
session, and since SR2-34 a PIX or boleto order **cannot** settle any other way. That is the ZKP2P V2 model. What ZKP2P
V3 adds and this repository lacks is a vendor-agnostic attestation layer (TLSNotary, Primus and Reclaim proofs
normalised into one signed attestation); here the verifier speaks Reclaim's format only. Forking ZKP2P's escrow instead
of using `FiatEscrow` is possible but would drop the BRL-specific parts (boleto, disputes with delayed rulings, the
band oracles, shielded delivery).

**Ask at the call.** Is one proof provider acceptable for launch, or is provider-agnostic attestation required?

## 8. Yield venue: decided by Monday (§1, "Hyperliquid")

**What was said.** *"This we will define until monday."*

**What it means.** The delta-neutral venue is open. The HyperCore vault and keeper here are built for Hyperliquid and
never traded; a different venue means a different adapter.

## What V1 looks like if every comment is applied

| Area | V1 |
|---|---|
| Shielded balance | Through the Kohaku SDK, on Railgun or on 0xbow's Privacy Pools (to decide); Umbra for receiving |
| Account | ERC-4337 with a passkey and a decentralised, permissionless MPC network as the second key |
| Ramp | P2P LPs with zkTLS proofs, plus CEX and DEX routes |
| Transfers | None in V1 |
| Sub-wallets | Independent seeds, multi-asset; moves between them in V2 |
| Limits | None |
| Yield | Sleeves as Rev. 3 §9, venue pending |
| Viewing key | Required; its construction depends on the shielding protocol chosen |

**What is reused from this repository under that V1:** the ramp (escrows, zkTLS verifier, LP node, matcher, node
rewards), the Movva reserve and token, the yield vault and adapters, the app's rails and Portuguese surface, the ops
tooling and the container image. **What is rebuilt:** every shielded component and the co-signer's role. **What is
built new:** sub-wallets, the MPC network integration, CEX and DEX routes.

## The questions, collected

1. Kohaku over Railgun or over canonical Privacy Pools; is the ASP model still required?
2. Which MPC network, and who pays its fees and runs its policy?
3. CEX as a liquidity provider, or as Movva's own float? Which BRL stablecoin for DEX?
4. Does the V1 user hold USDT, MOVVA or both, and who burns MOVVA?
5. One zkTLS provider at launch, or provider-agnostic attestation?
6. Who mints MOVVA: the escrow (Rev. 3 §5.1) or the reserve (the 14 September decision)? Unchanged from
   [rev3-conformance.md](rev3-conformance.md) and still open.
7. The yield venue, on Monday.
