# Response to the client audit of 21 October 2026

For the client's auditors and the second audit. It gives each finding the audit raised, what we found when we checked
it against the deployed code, what we changed, and where. The fixes go into a new frozen commit and a new Sepolia
deployment; the second audit reviews that commit, not a zip.

**What was audited.** The audit reviewed a zip (`Mova-main.zip`) and the contracts on Sepolia. The zip mixed code from
different dates: it contained the savings code removed on 14 October (decision D1, commit `772adf5`) and files from
20 October. Every finding below was checked against the frozen commit the Sepolia contracts were built from,
`audit-freeze-2026-10-20` (`2e442a4`), whose deployed bytecode matches byte for byte (`scripts/compare-deployed.py`).

## Findings

| ID | Verdict on `2e442a4` | Change | Status |
|---|---|---|---|
| H-01 | Not in the code: the savings zap and `ShieldedYieldRouter` were removed on 14 October; no remaining path writes the user's address this way | Documentation: the `FiatEscrow` header overstated deposit-side privacy (the taker is public as the order's caller and recipient) | done (docs; `FiatEscrow` header corrected in `ff058b8`) |
| H-02 | Confirmed; also, `FiatEscrow` did not cap the pool's vetting fee | Entrypoint `OWNER_ROLE` to a 7-day `TimelockController` run by a 2-of-3 Safe; `FiatEscrow` refuses a shielded delivery above a vetting-fee cap fixed at deploy; descriptions corrected | fixed: fee cap `ff058b8`; timelock `fe3e348`, `49208b5` |
| H-03 | Confirmed, and wider: the recovery code alone also opened a no-PRF wallet | The no-PRF path is removed; a passkey with PRF is required; UI text and `docs/wallet-custody.md` corrected | fixed: `d51cff9` |
| H-04 | Partly: credit was already freed on a taker's dispute (SRM1-4); the deployed timeout is 30 days, not 90; capital could still be held | A shorter timeout for disputes the taker raises; the taker may dispute only until `payBy`; on the off-ramp the LP may dispute only until `payBy` | fixed: `ff058b8` |
| M-01, M-04, M-05 | Confirmed in the optional venue adapter (`contracts/hyperliquid`, deployed nowhere). The deployed `HedgeSubWallet` has no shares (M-01 n/a), but related gaps: instant tightening could disable `deleverage`, and paired legs were not checked for matching fills | Adapter: spot-deviation checks, holding period, exit-path parameters delayed, `_reduceBoth` never buys back alone. Sleeve: parameter floors and caps, delayed exit-blocking changes, matched-fill check | fixed: adapter `b1c1a79`; sleeve `0e65e6b` |
| M-03 | Confirmed | `ReclaimZkTlsVerifier` binds a PIX proof to the order through the charge's `txid`, derived from the escrow and the order id; the LP node issues BR Codes with it and the wallet checks it before paying | fixed: `1727739` (verifier) and follow-ups; depends on the bank page showing the txid |
| M-06 | Confirmed; low risk (nothing was scheduled during setup on Sepolia) | `schedule` refused until setup is complete; a public `pendingChanges` counter | fixed: `60884c0` |
| M-07 | Confirmed (Sepolia was left unfinalized for review) | Governors handed to a 2-of-3 Safe before `completeSetup`; deploy scripts refuse a governor without code on mainnet | fixed: `47ef092`, `49208b5` |
| M-08 | Confirmed, for FROST accounts | Passkey proof at `frostCommit`; per-account and per-key limits; capacity reserved for the recovery veto | fixed: `c53e955` |
| M-09 | Partly: production refused the file store by default, but shared its override with the signing key | Envelope-encrypted share store; its own production flag; the entrypoint respects the configuration | fixed: `53e0bff` |
| M-18 | Confirmed (250.92 MOVVA of fees would have been locked) | Before renouncing: wind down the unused ETH pool, withdraw all fees to the treasury, set the fee settings deliberately | fixed: `49208b5` |
| M-19 | Confirmed | Finalize covers the hedge sleeve and the permissionless pair, and refuses while a governed contract is outside the recorded set | fixed: `49208b5` |
| M-20 | Confirmed | The orchestrator runs on chain 1 with a mainnet-fork rehearsal; the runbook is rewritten for the MOVVA-only rail | fixed: `49208b5`, runbook `b27622b` |
| M-23 | Confirmed | Canonical addresses per chain built into the app; mismatches refused; https outside localhost; switching asks for confirmation | fixed: `b0c0794`, `89b084b` |
| L-01 | Not reproduced: all three Foundry projects compile and the invariant suites pass (95/95). Likely cause: building without `npm ci`, which creates the gitignored library links | A clear error when the links are missing; a setup line at the top of the README | fixed: `c28f9f4` |

**State of the fixes.** All of the above are on branch `phase-1-shielded-rail`. Every suite passes on the merged
code: `forge test` 1,146 of 1,146 (100 suites), TypeScript 2,545 of 2,545 (183 files), typecheck clean; Slither
`--fail-medium` passes on every changed contract. Contract sizes: `FiatEscrow` 24,563 bytes (13 under EIP-170),
`OffRampEscrow` 19,918, `ReclaimZkTlsVerifier` 16,278, `HedgeSubWallet` 23,468. Fork rehearsals of the fixed rail pass with no failures:
Sepolia deployed (278 pass), Sepolia finalized with the timelock (315 pass), finalized with renunciation (299 pass), and a
mainnet fork (267 pass); the "expected" checks in each are only the closed FX market. The new frozen commit and the
Sepolia deployment built from it follow.

## The client's rule for the backing (21 October 2026): the principal-locked reserve

The client asked that the backing in `MovvaReserve` follow three rules. We enforce them in the reserve contract, not
in each user's account: per-account backing would publish each user's balance and link it to their account (defeating
the Privacy Pool), would have to move with every MOVVA transfer, would drift with BRL/USD, and could not be frozen
inside an account its user controls.

1. **The principal never leaves.** There is no withdrawal function: `withdrawToHedge`, `queueHedgeWithdrawal`,
   `executeHedgeWithdrawal`, the hedge rate limit and the withdraw floor are removed. USDT leaves only by `redeem`,
   which is gateway-only: the off-ramp's LPs, who paid a seller BRL, redeem that MOVVA for USDT.
2. **The principal is invested** in one ERC-4626 vault the client chooses (`yieldVault`; a new vault waits the
   governance delay, and funds only move between the reserve and its vault).
3. **Only the yield leaves, only to Mova.** The permissionless `harvestYield()` pays the fixed `yieldRecipient` (Mova's
   Safe; any change waits the governance delay, in either direction) only what sits above
   `max(principalUsdt, liabilities at the 108% target)`. `principalUsdt` is a cost basis: USDT in by `mint` and
   `recapitalize`, less USDT out by `redeem`.

The hedges (the issuer's FX hedge and the delta-neutral sleeve) now run on Mova's own capital; their gains come back by
`recapitalize` and become principal. Tested by unit tests for each rule and an invariant suite
(`contracts/test/MovvaPrincipalLockInvariant.t.sol`): reserve USDT falls only by redemptions and harvests, harvests
never breach the floor, no role ever holds the reserve's USDT, and the principal is the cost basis.

**Residual trust point.** The yield source itself: a vault that loses value or refuses withdrawals loses principal.
Changing the vault waits the 48-hour public delay; we recommend an allowlist of audited vaults.

## The statements that did not match the chain

None of the six is in the repository's records; they came from our summaries. Each is corrected here and in the
documentation.

1. **"Entrypoint immutable, no owner."** Incorrect before finalization. The Entrypoint is upstream's UUPS proxy and
   `OWNER_ROLE` was on the deployer's key. After the fix, `OWNER_ROLE` is held only by the timelock (H-02).
2. **"ASP 2 of 3."** The AspRootQuorum is the only `ASP_POSTMAN`, but while the deployer held `OWNER_ROLE` it could
   grant the role to anyone. With the timelock, granting it takes 7 days in public. (The final rail's record still
   names the deployer under `contracts.protocol.postman`: that is the postman at protocol deployment, revoked two steps
   later, `asp` step.)
3. **"The guardian renounced the pause along with the governors."** That describes `--finalize`, which has not run on
   Sepolia. On the final rail the reserve's guardian is the 2-of-3 guardian Safe and the governors were the deployer's
   key (M-07).
4. **"MOVVA: only the escrow can mint and burn."** Incorrect. Only `MovvaReserve` mints and burns (`Movva.RESERVE`,
   immutable). The escrows move MOVVA; they never mint it.
5. **"Delta-neutral strategy contract, keyless."** Inaccurate. `HedgeSubWallet` has no trading key on the venue and
   can send funds only to the hedge-treasury Safe, but it has a trade-only keeper (it chooses when, never what or how
   much) and a governor; on Sepolia both are the deployer's key, as is the test venue's operator.
6. **"PermissionlessLPRegistry not deployed."** It was deployed on 20 October, after the audit's snapshot, at
   `0x21e135789297A0E7F2924Eb25FD074c223AB727D` with its own escrow pair (`deployments/sepolia-movva-final-permissionless.json`).
   It runs beside the curated `LPRegistry`; it does not replace it yet.

## The audit's requests

1. Fix the blockers: the table above.
2. Explain the discrepancies: the section above.
3. A git commit, and the deployed bytecode against it: a new tag with the fixes, and `scripts/compare-deployed.py`
   over every address.
4. `--finalize` on Sepolia, with transaction hashes: on the fixed deployment, once M-18 and M-19 are in.
5. L-01: the table above.
6. A second audit: after the new commit.
