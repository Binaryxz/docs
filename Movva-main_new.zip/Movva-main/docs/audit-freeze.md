# Audit freeze, 21 October 2026

For the client's auditors and the second audit. It names the commit to audit and the final addresses on Sepolia, says
contract by contract whether the code at each address is the code in that commit, and lists the finalization
transactions.

## The commit

The frozen commit is the git tag **`audit-freeze-2026-10-21`**: `d4eef51a21880b20a6dcf750ee0739c09397b9f9`, branch
`phase-1-shielded-rail`. It contains every fix of the audit of 21 October 2026
([audit-response-2026-10-21.md](audit-response-2026-10-21.md)) and the client's principal-locked reserve rule. Every
contract below was deployed from it. Later commits add deployment records, documentation and deploy-tool options only:
`git diff audit-freeze-2026-10-21 HEAD -- contracts protocol/contracts/src packages/smart-account/contracts/src` is
empty. It supersedes `audit-freeze-2026-10-20` (`2e442a4`).

## Rebuilding and checking it

```bash
git checkout audit-freeze-2026-10-21
npm ci                                            # creates the library links the Foundry projects need
eval "$(bash scripts/foundry.sh export)"          # the pinned Foundry
forge build && (cd protocol/contracts && forge build) && (cd packages/smart-account/contracts && forge build)
forge test                                        # 100 suites, 1,110 tests, all passing at the freeze
npx vitest run                                    # TypeScript: 182 files, 2,530 tests, all passing at the freeze
RPC_URL=<a Sepolia node> python3 scripts/compare-deployed.py \
  deployments/sepolia-movva-v4-rail/etherscan-verify.sh \
  deployments/sepolia-v4-hedge-sleeve/etherscan-verify.sh \
  deployments/sepolia-movva-v4-permissionless/etherscan-verify.sh \
  deployments/sepolia-account-stack-frost-v2/etherscan-verify.sh \
  deployments/sepolia-account-stack/etherscan-verify.sh
```

The rail's own record does more: `deployments/sepolia-movva-v4-rail/VERIFICATION.md` has every source hash, the
creation code and constructor arguments of each creation transaction, a privilege inventory of every function, and
332 passing checks after finalization. Every contract is source-verified on Etherscan.

## The v4 rail, finalized

Deployed and finalized on 21 October 2026 from `0x51d8E8E425c0431741246513F8A63Dd7d7c175Eb`.

- **Governance:** every governed contract's governor was the 2-of-3 governor Safe `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1` before setup
  closed (M-07); the Safe closed setup, then renounced every governor to `0x…dEaD` at finalization.
- **The Entrypoint's `OWNER_ROLE`:** held only by a 7-day `TimelockController` `0xeE518057F6fe17385D67c8659abc77Ac5a601ed7`, whose only
  proposer, canceller and executor is the governor Safe (H-02). The deployer holds no Entrypoint role.
- **The reserve:** principal-locked (client rule). Its guardian was renounced to `0x…dEaD`. Its `yieldRecipient` is the
  test treasury on Sepolia and can no longer change; mainnet uses the Safe the client names.
- **Before renouncing (M-18):** the unused ETH pool was wound down and removed; the Entrypoint held no fees.
- **Covered by finalization (M-19):** the rail's 8 governed contracts, the permissionless pair's 2 escrows and the hedge
  sleeve. The sleeve's keeper stays a trade-only key (`0x4D0d…8853`), separate from its former governor.

| Transaction | Hash |
|---|---|
| governor Safe setup batch (9 calls) | `0x074fe56d00026c407ef384870c47346a6eb48725976a2e24ab520a3c6ead0a5c` |
| Entrypoint.windDownPool (upstream's ETH pool) | `0xc51cd1f1689271fce7419644ac2db5b996a0c0c77f9e89f282d6e4013d45db9b` |
| Entrypoint.removePool (upstream's ETH pool) | `0xc9a3724782328a7a45e8ebc5e6c9c1ccaf58174d5db50d437e0c262b88d50b33` |
| create EntrypointTimelock (OpenZeppelin TimelockController; 7 days; proposer, canceller, executor: the Safe) | `0xa5581d2f8877ab626093ba94a03c1869a243913befb9c293732d04d9c75c811a` |
| Entrypoint.grantRole OWNER_ROLE EntrypointTimelock | `0x41dab5c9a6be687881f45942c3435114cdd899ce0aa1fccd75f1414ece49517c` |
| Entrypoint.renounceRole OWNER_ROLE deployer | `0x9e6d63d9d809ee5e4f15720b09fcd50b7bf9a04d0f37447d49fe3c5a1024d742` |
| MovvaReserve: setGuardian(0x...dEaD) | `0x9e1d6880839c9f9b3635a1f31d200bd2ad9b3d2667d71ac05397565feb6634b8` |
| governor Safe: 10 renunciation call(s) | `0x87136f0d6ef74112b529b09758925933dacb4da1ecf2cdcf5b53d9fb4da2b5e3` |
| deployments/sepolia-v4-hedge-sleeve.json subWallet: transferGovernor(0x...dEaD) | `0x5a4644277cc2ce5e02f4e56f21ebac6ae69e0be141dba496f5424b5712a06c89` |

## Every contract on Sepolia, against the frozen source

**The v4 rail (21 October 2026)** (`deployments/sepolia-movva-v4-rail/`)

| Contract | Address | Matches the frozen source | Note |
|---|---|---|---|
| ERC1967Proxy | [`0x81d45264fbC3E1cD303891bb8f4ae9EA2DEB2CcC`](https://sepolia.etherscan.io/address/0x81d45264fbC3E1cD303891bb8f4ae9EA2DEB2CcC#code) | yes, byte for byte |  |
| Entrypoint | [`0xa39fBfb71D89Dde0d75AD23334613EFd695fAadb`](https://sepolia.etherscan.io/address/0xa39fBfb71D89Dde0d75AD23334613EFd695fAadb#code) | yes, byte for byte |  |
| WithdrawalVerifier | [`0xA9c58610Dae19933b6B21c677D472945DE695446`](https://sepolia.etherscan.io/address/0xA9c58610Dae19933b6B21c677D472945DE695446#code) | yes, byte for byte |  |
| CommitmentVerifier | [`0x7165F26B50A5901a02f4D661507545f2fb94F91C`](https://sepolia.etherscan.io/address/0x7165F26B50A5901a02f4D661507545f2fb94F91C#code) | yes, byte for byte |  |
| PrivacyPoolSimple | [`0x8e730dF009Bdfa5A685d9b8Cde84449F94d7b12d`](https://sepolia.etherscan.io/address/0x8e730dF009Bdfa5A685d9b8Cde84449F94d7b12d#code) | yes, byte for byte |  |
| PoseidonT3 | [`0x8ffdA7Ed8B4aD98C2C34f54B76821711F4a6f2C5`](https://sepolia.etherscan.io/address/0x8ffdA7Ed8B4aD98C2C34f54B76821711F4a6f2C5#code) | **no** | Pre-existing public library; the rail record recompiles its own verify input and matches it exactly (`deployments/sepolia-movva-v4-rail/VERIFICATION.md`). |
| PoseidonT4 | [`0xe393dd7287Db9982e6f845824854Baf8b8e823AF`](https://sepolia.etherscan.io/address/0xe393dd7287Db9982e6f845824854Baf8b8e823AF#code) | **no** | As PoseidonT3. |
| TetherLike | [`0xCDf4eCDa722285d3f5D24c791EC5506D718424a0`](https://sepolia.etherscan.io/address/0xCDf4eCDa722285d3f5D24c791EC5506D718424a0#code) | yes, byte for byte |  |
| MovvaReserve | [`0xa357968D9beC2b3Cc9057c4aF37431780D91287a`](https://sepolia.etherscan.io/address/0xa357968D9beC2b3Cc9057c4aF37431780D91287a#code) | yes, byte for byte |  |
| Movva | [`0xdDb321e26e4e77432fA3E160431f25cCB4700Fa2`](https://sepolia.etherscan.io/address/0xdDb321e26e4e77432fA3E160431f25cCB4700Fa2#code) | yes, byte for byte |  |
| PythFxOracle | [`0x90474f2B222d0E0a8dfC4c4F138b041B1921F18F`](https://sepolia.etherscan.io/address/0x90474f2B222d0E0a8dfC4c4F138b041B1921F18F#code) | yes, byte for byte |  |
| ScaledFxBandOracle | [`0xaC4c0Fe25ed07B446f8377A97f4aA175020d2B13`](https://sepolia.etherscan.io/address/0xaC4c0Fe25ed07B446f8377A97f4aA175020d2B13#code) | yes, byte for byte |  |
| FeeSplitter | [`0xB81615658A4a51b4d3c2e144d492794Beb001099`](https://sepolia.etherscan.io/address/0xB81615658A4a51b4d3c2e144d492794Beb001099#code) | yes, byte for byte |  |
| NodeRewards | [`0xe446ceA7089704e5cC746edf97F9eedeA4851FF0`](https://sepolia.etherscan.io/address/0xe446ceA7089704e5cC746edf97F9eedeA4851FF0#code) | yes, byte for byte |  |
| PrivacyPoolComplex | [`0x3ac4EE315D13e9a4243954852917eAf69232a6f3`](https://sepolia.etherscan.io/address/0x3ac4EE315D13e9a4243954852917eAf69232a6f3#code) | yes, byte for byte |  |
| EntrypointTimelock | [`0xeE518057F6fe17385D67c8659abc77Ac5a601ed7`](https://sepolia.etherscan.io/address/0xeE518057F6fe17385D67c8659abc77Ac5a601ed7#code) | yes, byte for byte |  |
| AspRootQuorum | [`0xa897FB804917715A0220339640D5e55B59b85339`](https://sepolia.etherscan.io/address/0xa897FB804917715A0220339640D5e55B59b85339#code) | yes, byte for byte |  |
| LPRegistry | [`0x8a31C07b24d83908c11BE0a81ABFA465454d0344`](https://sepolia.etherscan.io/address/0x8a31C07b24d83908c11BE0a81ABFA465454d0344#code) | yes, byte for byte |  |
| ReclaimZkTlsVerifier | [`0x84ae5FFC1F84b19498cE5a376200709b4df55508`](https://sepolia.etherscan.io/address/0x84ae5FFC1F84b19498cE5a376200709b4df55508#code) | yes, byte for byte |  |
| FiatEscrow | [`0x3e79B0582b8EAb2FDEcFf0c9da43143e3915eB14`](https://sepolia.etherscan.io/address/0x3e79B0582b8EAb2FDEcFf0c9da43143e3915eB14#code) | yes, byte for byte |  |
| OffRampEscrow | [`0xCCdA1AA24d45Bc673b090F80363aC38D50D0d81C`](https://sepolia.etherscan.io/address/0xCCdA1AA24d45Bc673b090F80363aC38D50D0d81C#code) | yes, byte for byte |  |

**Its hedge sleeve: Mova's own capital (21 October 2026)** (`deployments/sepolia-v4-hedge-sleeve/`)

| Contract | Address | Matches the frozen source | Note |
|---|---|---|---|
| SimHedgeVenue | [`0x52d7e5fdee5ab90a425a23b962c4ecff405dca95`](https://sepolia.etherscan.io/address/0x52d7e5fdee5ab90a425a23b962c4ecff405dca95#code) | yes, byte for byte |  |
| HedgeSubWallet | [`0x6fef0ea790f64d81944098bc13bdbc0f4c9e546c`](https://sepolia.etherscan.io/address/0x6fef0ea790f64d81944098bc13bdbc0f4c9e546c#code) | yes, byte for byte |  |

**The permissionless LP registry and its escrow pair (21 October 2026)** (`deployments/sepolia-movva-v4-permissionless/`)

| Contract | Address | Matches the frozen source | Note |
|---|---|---|---|
| PermissionlessLPRegistry | [`0x6B19B2e4B8d8afe7E9BC775782E96D1cB00EDa9E`](https://sepolia.etherscan.io/address/0x6B19B2e4B8d8afe7E9BC775782E96D1cB00EDa9E#code) | yes, byte for byte |  |
| FiatEscrow | [`0x7dB64fDa2A95C25E5F7f23F9118CFb99b2695015`](https://sepolia.etherscan.io/address/0x7dB64fDa2A95C25E5F7f23F9118CFb99b2695015#code) | yes, byte for byte |  |
| OffRampEscrow | [`0x413fa4eb0C730D1fA459C38A38fF7bAA68f56bFe`](https://sepolia.etherscan.io/address/0x413fa4eb0C730D1fA459C38A38fF7bAA68f56bFe#code) | yes, byte for byte |  |

**The corrected FrostValidator (20 October 2026)** (`deployments/sepolia-account-stack-frost-v2/`)

| Contract | Address | Matches the frozen source | Note |
|---|---|---|---|
| FrostValidator | [`0xBb6Bb2779FAd749F87342d7E471513272c901158`](https://sepolia.etherscan.io/address/0xBb6Bb2779FAd749F87342d7E471513272c901158#code) | yes, byte for byte |  |

**The account stack (14 October 2026)** (`deployments/sepolia-account-stack/`)

| Contract | Address | Matches the frozen source | Note |
|---|---|---|---|
| PasskeyCoSignerValidator | [`0x7Ecc6B0edF79CACC4DaB559830111cC1c8702990`](https://sepolia.etherscan.io/address/0x7Ecc6B0edF79CACC4DaB559830111cC1c8702990#code) | yes, byte for byte |  |
| FrostValidator | [`0x58997113b2572F9Bc6ca243a0Ffff0C1924AB223`](https://sepolia.etherscan.io/address/0x58997113b2572F9Bc6ca243a0Ffff0C1924AB223#code) | **no** | Superseded by the corrected FrostValidator above; new accounts use that one. |
| KernelAvatarAdapter | [`0x8214602c7991b48dEa1A5Cd58b06dCCF7840fAb0`](https://sepolia.etherscan.io/address/0x8214602c7991b48dEa1A5Cd58b06dCCF7840fAb0#code) | yes, byte for byte |  |
| OwnerlessPaymaster | [`0x98a488006bB816a03930Edfec76Fda95a8ee069d`](https://sepolia.etherscan.io/address/0x98a488006bB816a03930Edfec76Fda95a8ee069d#code) | yes (code; metadata differs: comments) | Kept: same code; redeploying would lock another 1 ETH stake. |
| AuditGrantRegistry | [`0x8BcCa7574d7A87Ea225DFB4ab1Ced6947e33414A`](https://sepolia.etherscan.io/address/0x8BcCa7574d7A87Ea225DFB4ab1Ced6947e33414A#code) | yes, byte for byte |  |
| ShieldedNoteLog | [`0x9eE65d4b3B55A545721138B814d1227e7DFdB1a5`](https://sepolia.etherscan.io/address/0x9eE65d4b3B55A545721138B814d1227e7DFdB1a5#code) | yes, byte for byte |  |

The two Poseidon rows: `compare-deployed.py` reads the protocol build's artifact, while these libraries were published
by their author; the rail's record recompiles each library's own verification input and matches it exactly.

## The earlier rails

The rails of 6, 15 and 20 October 2026 and the v3 rail of 21 October (`deployments/sepolia-movva-v3-rail.json`, the
audit fixes without the principal-locked reserve) are superseded and kept as records.
