# Internal security review — Phase 1

Task 1.6, second half. Reviewer: internal. Date: 2026-09-08.

**Scope: our own code only.** `protocol/` is upstream's audited code, unmodified and
verified byte-identical (`npm run verify`); it carries its own Oxorio and Auditware reports
in `protocol/audit/`. Reviewing it again here would add nothing. What is reviewed is
everything we wrote: `packages/viewing-key`, `packages/smart-account`, `contracts/`, and the
fork's build and deployment wiring.

This is an internal review, not an external audit. It does not substitute for one.

## Findings

### SR-3 — The vault enforced revocation from a view with no freshness bound
**Severity: high.** `packages/viewing-key/src/vault.ts`. **Fixed 2026-09-10.**

Found by a later pass that inverted the review method: instead of reading for mistakes, take
each claim a header makes and ask what would falsify it. The vault's header says *"this is
the layer where revocation bites"*.

`ChainGrantRegistry` is snapshot-and-serve, and that is the right shape for an auditor
verifying a disclosure offline against a fixed view — a verification that issues fresh RPC
calls as it walks can observe the registry changing underneath it. But the **vault** uses the
same interface to *enforce* revocation, and there a stale snapshot does not fail closed. It
fails **open**: a grant revoked after the snapshot still reads `revokedAt == 0`, so an
ex-auditor keeps being served ciphertexts. Nothing in the vault bounded the age of that view,
and nothing scheduled a `refresh()`.

The window was therefore unbounded in principle — however long until someone happened to
refresh — against the one control this layer exists to provide.

**Fix.** `GrantRegistryReader` may report `snapshotAt`; a snapshotting reader must. The vault
takes `maxRegistryAgeSeconds` (default 120) and **refuses to serve** from a view older than
that, logging the refusal, rather than serving a grant it cannot vouch for. A reader that is
always current leaves `snapshotAt` undefined and is unaffected.

Regression: `test/vault-staleness.test.ts` revokes behind a frozen snapshot and asserts the
vault serves within the bound, refuses past it, and honours the revocation once re-taken.



### SR-1 — Ragequit exits invisible to reconciliation, overstating the audited balance
**Severity: high.** `packages/viewing-key/src/pool/rpc-source.ts`. **Fixed.**

The L1 event is `Ragequit(address indexed ragequitter, uint256 commitment, uint256 label,
uint256 value)` — it carries **no nullifier hash**, and no indexer can compute one without
the depositor's secret. The RPC decoder fabricated `spentNullifierHash: '0'` to satisfy the
type. Consequences, all silent:

- nullifier hash `0` was marked spent instead of the real one
- every ragequit collided on the same map key, so only the last survived
- `ragequitOf(realHash)` returned undefined, so `reconcileWithPool` never saw the exit
- the exited commitment still counted toward `unspentValueWei`

The last point is the damaging one: **a fiscal report handed to Receita Federal would
overstate the shielded balance**, claiming funds that had already left the pool.

Why no test caught it: `LocalPrivacyPool` holds the secrets, so it populates nullifier
hashes correctly, and the model agreed with itself. Only the L1 path was wrong. This is the
same failure shape as the keccak-vs-Poseidon label bug found in 1.5 — *a value the contract
derives must be checked against the contract, never against our own derivation.*

Fix: ragequits are indexed and looked up by **commitment**, the only identifier the chain
actually emits. `PoolStateSource.ragequitOfCommitment` is now the lookup reconciliation
uses; `spentNullifierHash` is optional and documented as model-only. `unspentValueWei`
excludes exited commitments explicitly rather than relying on the nullifier being spent.
Regression tests in `test/ragequit-indexed.test.ts` drive the real decode path.

### SR-2 — Unbounded request-nonce retention
**Severity: low.** `packages/viewing-key/src/vault.ts`. **Fixed.**

`NoteVault` kept every request nonce per grant for the process lifetime. A proof is already
rejected once its timestamp is more than `PROOF_SKEW_SECONDS` (300s) from now, so a nonce
older than that can never be replayed — retaining it buys nothing while growing without
bound. An authenticated auditor could drive that growth indefinitely within its rate limit.

Fix: nonces are stored with their timestamp and pruned to the replay window. Tests assert
that replay protection inside the window is unchanged, and that a pruned nonce is still
refused — by the timestamp check rather than the nonce set.

### SR-4 — Fiscal statements were wrong for any user with history outside the period
**Severity: high.** `packages/viewing-key/src/audit.ts`, `src/reconcile.ts`. **Fixed 2026-09-13.**

Found by running the auditor tool on the cases real users are in, which no test covered: every
existing test audited a period with no activity before it and none after it.

- **Activity after the period.** Reconciliation judged a past quarter against today's
  spent-set. A user who deposited in January and withdrew in May, audited for Q1 in October,
  got `truncated_lineage` (error), `reconciled: false`, a pool balance of 0 instead of 1 ETH -
  and the finding named the May transaction. The only way to clear it was to disclose May.
- **Money held before the period.** `closingBalanceBRLCents` was the sum of in-period
  movements. A quarter that opened with R$ 20.000 shielded and saw one R$ 5.000 withdrawal was
  reported as **-R$ 5.000,00**, `complete: true`.
- **The wrong period.** `FiscalReport.period` carried the key's validity window, not the
  audited period.

Fix: every check is evaluated at the period's boundaries using pool event times; spends after
the period are neither faulted nor named. Bundles carry signed **opening positions** (pool
anchors only, never the pre-period movement), verified as held at the period start, with every
declared pre-period lineage required. The statement gives opening balance, movements and
closing balance. A dating check refuses a movement filed in a different period than its
commitment's insertion block. `test/fiscal-statement.test.ts`.

### SR-5 — An expired grant could still read notes written after it was issued
**Severity: medium.** `packages/viewing-key/src/wallet-service.ts`. **Fixed 2026-09-13.**

Rotation happened only on revocation. A grant covering the current month that simply expired
left its chain writable, so every later note that month was readable with the expired key by
anyone holding the ciphertext - with `ShieldedNoteLog`, anyone. Expiry was policy, enforced
only by a vault that was not running as a service. Fix: issuance seals every chain the grant
covers (`AuditGrantRegistry.registerAndRotate`, atomic); revocation rotates only what an older
grant left open.

### SR-6 — The vault was handed every disclosed viewing key
**Severity: medium.** `packages/viewing-key/src/vault.ts`. **Fixed 2026-09-13.**

`NoteVault.serve` took the whole bundle, epoch secrets included, to verify its signature - so a
networked vault operator could decrypt every period its users disclosed, contradicting the
vault's own claim that its operator learns nothing. The signature covers a commitment to the
material, so the vault now verifies the public form (`toPublicDisclosure`) and refuses a
request that carries keys. Writes were also unauthenticated: anyone could file undecryptable
records under a victim's subject and make every audit of that user fail. `putAuthenticated`
requires the owner's identity-key proof. The vault now runs as a service
(`src/vault-service.ts`); before this it existed only in process.

### SR-7 — Smaller findings from the same pass
**Fixed 2026-09-13.**

- **Unsigned transfer tickets** (`src/transfer.ts`): whoever relayed a ticket could swap its key
  and precommitment and take the payment. Tickets are now signed by the recipient's identity
  key, and senders can pin the recipient.
- **Guessable registry epoch keys** (`src/wallet-service.ts`): rotations are public events, and
  `keccak256("pool:month")` told any observer which months a user was audited for. Now keyed by
  the viewing root.
- **Withdrawals recorded without a time** (`src/wallet-service.ts`): the model stamped them with
  the block number, i.e. 1970. Harmless until reconciliation compared times.
- **Transaction-scoped grants audited a zero-length period** at `validFrom`, describing no note.
- **`POOL_EVENT_SIGNATURES`** described Withdrawn and Ragequit events the contract does not
  have; now pinned to the decoder's topics by a test. The ragequit `label` is decoded.

### SR-8 — A dishonest user could still get a "complete" statement
**Severity: critical.** `packages/viewing-key/src/reconcile.ts`, `src/audit.ts`. **Fixed 2026-09-13.**

A second adversarial pass, run against the SR-4 to SR-7 fixes with a reproduction script per
finding, attacked the statement as the user it describes. Four ways to reconcile a false one:

- **Spend state was the user's word.** `nullifierHash` is not bound to a commitment by anything
  an auditor can recompute. Swapping it made a position withdrawn in February read as held all
  quarter: `complete: true`, closing R$ 20.000 against a true R$ 5.000. Fix: the wallet attaches
  a proof per anchor from upstream's audited `commitment.circom` (the ragequit circuit, same
  ceremony keys - no new circuit), and reconciliation trusts a nullifier hash only when a
  verified proof binds it (`src/proofs.ts`). A report without proofs cannot be complete.
- **Lineage claims were trusted.** A 1 ETH withdrawal remainder relabelled `lineageIndex: 0`
  satisfied deposit coverage for a 10 ETH deposit. Fix: coverage matches the deposit's own
  commitment; predecessors and successors are found through the chain's withdrawal links;
  position and kind are checked against how the chain inserted each commitment.
- **BRL figures were unchecked.** A movement booked at R$ 1,00, or a rate stated consistently
  false, reconciled; a fabricated unanchored debit lowered the closing balance. Fix: amounts are
  checked against the wei they moved, restatement mismatches are errors, rates are checked
  against a reference price when one is supplied (`brlVerified` otherwise false), and unanchored
  notes are excluded from every figure.
- **Aliases double-counted.** A commitment spelled in hex was a second map key. Fix: canonical
  decimal encodings only; duplicates are errors.

Also fixed from that pass: honest users faulted at period boundaries (membership is now decided
by block time, with single-note keys for notes that straddle a month); opening positions and a
pre-period sender's identity reaching the vault (now a commitment only, and no attestation);
anyone able to write refusals into a user's access log (logging waits for authentication and the
grant's signature, and the log is bounded); a torn store line corrupting later appends; chain
refreshes triggered by unauthenticated requests; rotations under the old epoch key ignored
after the key change; a snapshot registry reader answering 0 for rotations it never fetched.

**Left open, and stated in every report's `assumptions`:** a lineage that began as an inbound
transfer and is omitted entirely cannot be detected - its depositor of record is a router, not
the user. `test/dishonest-disclosure.test.ts`.

### SR-9 — A recovered balance counted a ragequit exit as still held
**Severity: medium.** `packages/viewing-key/src/recovery.ts` `recoverFromChain`. **Fixed 2026-09-14.**

Recovery decided whether a position was still held from the spent-nullifier set alone. A ragequit exits a
position without a nullifier, and pool state rebuilt from real logs never marks one spent, so a wallet
recovered on a new device would have shown a ragequit-exited position as held: an overstated balance, and a
fiscal statement built on it. Found while adding recovery by precommitment. Recovery now matches the pool's
`Ragequit` events by commitment (the event carries no nullifier hash). `test/recovery-ragequit.test.ts` pins the
fixed behaviour.

### SR-10 — BRL checks were silently vacuous for assets with more than 18 decimals
**Severity: medium.** `packages/viewing-key/src/reconcile.ts`. **Fixed 2026-09-14.**

Reconciliation checked each movement's reais against its base units at a price per 10^18 units. sMovva shares
have 24 decimals, so the per-unit price rounded to zero and every BRL check passed whatever the note said. A
note now states its `rateScale` and every check uses it. `test/intermediary-disclosure.test.ts` (a false sMovva
share price, a wrong scale).

### SR-11 — The IRPF acquisition cost of a ramp purchase left out what it really cost
**Severity: low (a tax figure the user files).** `packages/viewing-key/src/tax-export.ts`. **Fixed 2026-09-14.**

The cost basis was the value the pool moved, which excludes the LP's spread and the pool's vetting fee, so cost
was understated and every later gain overstated. Notes now carry `settlementBRLCents`, what was actually paid,
and cost uses it; an escrow purchase whose stated settlement disagrees with the order is `settlement_mismatch`.

Card purchases (added the same day, with the disclosed card fee): the fee charged on top of the order is acquisition
cost too, but it could not go into `settlementBRLCents` without tripping `settlement_mismatch`. Notes carry
`cardFeeBRLCents` with the opening of the card offer's commitment; reconciliation verifies it against the offer's
`railMask` and `pixKeyHash` and the order's `brlCents` (`card_fee_mismatch`), and cost is settlement plus fee.
`test/card-fee.test.ts`, `test/intermediary-disclosure.test.ts`.

### SR-12 — A service with no pool configured issued bundles an auditor always rejects
**Severity: low (availability of an honest audit).** `packages/viewing-key/src/wallet-service.ts`. **Fixed.**

Such a service stamped disclosures with pool scope `0`, which reconciliation rejects, so an honest user's
grant could never verify. The Movva ledger attaches its pool's state before issuing, and `ViewingKeyService` now
refuses to issue a disclosure with no pool state attached rather than produce a bundle no auditor accepts.

## Reviewed, no change needed

**Read-only property (requirement 4).** Holds. Viewing material is an HKDF child of the
spending secret; the withdrawal witness `(nullifier, secret)` derives from the spend branch
and never enters a note or bundle; `assertNoWitness` now walks the payload recursively; the
registry holds no funds. Asserted from four directions in `test/readonly.test.ts` and
`test/pool-audit.test.ts`.

**Vault authentication order.** Correct, and deliberately so: the auditor proof is verified
*before* the grant's existence, revocation state or rate limit is touched. An
unauthenticated caller therefore cannot probe grant state, burn another auditor's rate
limit, or appear in the user's access log.

**Auditor proof construction.** The signature covers `(grantId, nonce, at)`, so a proof
cannot be moved between grants; nonces are single-use per grant; skew is bounded at 300s.

**Scope enforcement.** Cryptographic, not filtered — out-of-scope records are encrypted
under keys the auditor was never given. The vault filter and the auditor tool's refusal are
defence in depth, not the boundary.

**Safe 2-of-2 threshold.** Enforced by the deployed contracts and *demonstrated* rather than
asserted: `smart-account-deposit.ts` submits a single-owner UserOperation to the real
EntryPoint and requires it to fail (AA24).

**`signSafeOp` v-encoding.** Signs the EIP-712 digest with `v` left at 27/28. Shifting by 4
(the eth_sign convention) makes Safe re-prefix and recover a stranger; that mistake was made
during 1.2 and is now pinned by a test.

**`rpc-source.ts` has no signer.** Deliberate: plain JSON-RPC over `fetch`, no client
library, no key material. A read-only auditor tool cannot move funds even by accident,
because it holds nothing to sign with.

**Contracts.** `AuditGrantRegistry` and `ShieldedNoteLog` hold no value (`test_HoldsNoValue`),
grants are keyed per `(owner, grantId)` so registration cannot be front-run, revocation is
owner-only and idempotent, rotation is monotonic (fuzzed), and anchors are append-only.

## Added after the first pass

**`SponsorPaymaster`** (`contracts/SponsorPaymaster.sol`) was written after this review
began, so it is reviewed here rather than assumed. It sits in the validation path of every
operation it sponsors, which is why it is deliberately minimal: no signature-based
sponsorship (that puts an off-chain signer in the critical path), no ERC-20 accounting, and
`postOp` is inert because reverting there after a successful call is a known way to brick an
account. It holds no user funds and cannot move them — everything sent to it goes straight
to the EntryPoint deposit. The worst a bug can do is drain its own gas deposit, which is why
sponsorship is an explicit on-chain allowlist and `maxCostAllowed` bounds a single
operation. 13 tests cover access control, policy, the cost boundary (fuzzed), and funding.

~~Residual risk: an allowlisted account can still consume sponsored gas repeatedly.~~
**Closed.** `setBudget(window, perAccount)` adds a rolling per-account gas budget, checked
in validation and settled in `postOp` from the ACTUAL cost. `maxCostAllowed` still caps a
single operation; the budget caps the sum.

One imprecision is accepted and documented in the contract: several operations in one bundle
each pass validation before any settles, so an account can overshoot by up to one bundle,
bounded by `maxCostAllowed` per operation. The alternative — charging the estimate up front
and refunding in `postOp` — adds failure modes to the one path that must never revert.
`postOp` is now a write path, so it is written to be unrevertable: no requires, no external
calls, and a saturating add so a pinned account cannot wrap back to zero. 23 tests.

**Deposits made by contracts (14 September 2026).** Users hold Movva, and their notes are deposited by the ramp
escrow and the yield router, not by their own accounts. The design - adoption only of what pool state confirms
and the witness opens, and attributions read from the contracts' own state - is in `docs/audit-viewing-key.md`,
"Deposits a contract made". Reviewed the same way as SR-8: each way a dishonest user could omit or restate such a
movement is an attack in `test/intermediary-disclosure.test.ts`. The residuals are stated in every report: without
the contracts' attributions an omission is not detectable, and a sale's proceeds are the user's statement.

**A second device sealing to stale rotations (14 September 2026).** Expiry is cryptographic because issuing a grant
rotates the note chains it reads. A second device that never saw the rotation kept writing under the old keys, which
the grant's holder can open - a leak `test/rotation-source.test.ts` demonstrates. A service with a rotation source now
reads the chain registry and refuses to write for an epoch it has not read recently, and the Movva wallet cannot be
built without one unless it says explicitly that there is no registry.

## Open risks — not code defects

1. **`terms.accounts` is an attestation, not a proof.** A deposit from an undeclared account
   is undetectable on-chain. The mitigation is the KYC'd ramp, which does not exist yet.
2. **Revocation cannot retract what was already decrypted.** Correctly documented; it must
   reach product copy. "Revoke" has to read as *stop future access*.
3. ~~The passkey is not in the spending path.~~ **Closed.** The passkey is now a Safe owner
   via `SafeWebAuthnSigner`, with P-256 verified on-chain; a wrong-digest assertion is
   rejected. What remains is that the authenticator itself is still simulated in software -
   the on-chain half is real, the hardware half has never been exercised.
4. **MPC is now implemented, unaudited, and not on-chain.** `packages/mpc` is 2-of-2 FROST
   threshold Schnorr (RFC 9591) — the key is never assembled and one signature reaches the
   chain instead of two. It is the only from-specification cryptography in the repo and the
   first thing an external reviewer should look at; `docs/audit-scope.md` ranks it above
   everything else. Keys now come from a PedPoP DKG (`packages/mpc/src/dkg.ts`), so no party
   ever holds the group secret; the device share is sealed under the passkey PRF, and a Zodiac
   Delay module lets the passkey alone recover a Safe after a cooldown if the server dies
   (`docs/wallet-custody.md`). Until it is reviewed AND a Schnorr verifier contract exists,
   the on-chain path remains what follows.
   **Safe 2-of-2 is the shipping answer today.**
   It delivers the required property — no single compromised party can move funds — with
   audited contracts, nothing unaudited in the spending path, and no vendor. The cost is
   that two signatures are visible on-chain rather than one; for a regulated BRL rail an
   auditable co-signing policy is arguably a feature. No phone is involved: the second owner
   is a server key. Reopen only if single-signature indistinguishability becomes a product
   requirement.
5. **Relayer fee ceiling.** A pool's `maxRelayFeeBPS` bounds the smallest relayable
   withdrawal, since gas is a fixed cost spread over the amount. Choose it for BRL ticket
   sizes deliberately.
6. **ASP operator trust.** Withdrawals require an ASP root posted by the postman role. In the
   demos we hold that role ourselves. In production it is a separate operator whose
   liveness and honesty the withdrawal path depends on.
7. ~~Circuits are not compiled in our tree.~~ **Closed.** All three circuits recompile with
   the pinned circom to byte-identical R1CS, so the vendored proving keys demonstrably
   correspond to the circom source beside them, not merely to upstream's copy of it.
8. **No external review.** Required before mainnet. Unchanged and still the gating item.
9. ~~Nothing is deployed.~~ **Partly closed.** The stack is live on Sepolia — see
   `docs/deployments.md`. That removes "it has only ever run on a fork", but a testnet is
   still not mainnet: no economic adversaries, no MEV, no real reorg pressure, and the
   deployer key was generated on the build machine, which is acceptable for a testnet and
   not beyond it. All eight contracts are Etherscan-verified, so a reviewer can read the
   deployed source rather than take this document's word for it.
10. **Sponsor key custody.** `SponsorPaymaster` has an owner who controls the allowlist and
    can withdraw the gas deposit. That key is now part of the system's security, and nothing
    here says how it is stored. It is not a user-funds risk, but it is a real operational one.

## Method and limits

Findings came from reading our code against the deployed contracts, and from running the
system on a mainnet fork. Both fixed bugs were found the same way — by comparing what the
model believes against what the chain actually emits. That is the review technique that
worked, and the one to repeat.

**Property-based testing was added after this review** (`test/properties.test.ts`, 16
properties over the key tree, note encryption and chain integrity), precisely because both
Phase 1 bugs were cases where hand-written tests agreed with the implementation. It
immediately earned its place: the property "rejects a chain with any record dropped" FAILED,
correctly. A chain prefix is a valid chain, so removing the last record leaves something
internally consistent — truncation is caught by comparing head and count against an on-chain
anchor, not by linkage. The claim was too strong and is now stated precisely, with a second
property asserting the limit rather than hiding it.

Static analysis was also added (`npm run slither`): five findings, all reviewed, none
actionable — the triage is in `docs/audit-scope.md` and we would rather have it challenged
than silently accepted.

Reconciliation is now covered too (`test/reconcile-properties.test.ts`, 10 properties over
integrity, coverage, balance and pool scope) — it is the part that decides whether a number
handed to a tax authority is right, so leaving it to hand-built scenarios was the weakest
spot in the suite.

CI found four defects across its first three runs, one of which invalidated a claim this
document had been making: an unanchored `lib/` in `.gitignore` excluded three files of
audited protocol source from every commit, so the published repository could not build and
"byte-identical to upstream" held only for the working tree. See `docs/audit-scope.md`.

The other three were reproducibility defects found on the very first run, all of the same kind: the
repo depended on state accumulated by hand on the build machine. A hand-installed `solc`
binary the EVM harness shelled out to; a `lib/forge-std` left behind by an old
`forge install`; and no committed lockfile, so every build re-resolved its dependencies.
Everything "verified" before this had been verified on that machine. All three are fixed -
the harness uses the `solc` npm package already in the tree, forge-std is linked from
node_modules on postinstall, and the lockfile is committed.

There is now CI (`.github/workflows/verify.yml`). For the whole of Phase 1 there was none,
which meant every claim in this document depended on someone remembering to run
`npm run verify` by hand. It now runs on every push, with the RPC-dependent job skipping
cleanly when secrets are absent rather than failing.

Still not done: formal verification or
symbolic execution, timing/side-channel analysis of the crypto (we use `@noble`, which is
constant-time by design, but have not audited our own usage), dependency supply-chain
review, and any review of operational security for the relayer's and sponsor's signing
keys.
