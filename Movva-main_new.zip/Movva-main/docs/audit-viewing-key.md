# Audit viewing keys — design

Selective disclosure for shielded BRL balances: the user can hand an auditor a
**read-only, scoped, time-boxed, revocable** key that decrypts exactly the history they
authorised, and nothing else.

## Key tree

Derived from the wallet seed (passkey + MPC). The viewing and identity branches hang off the
**spending key**, so the spending key alone regenerates everything:

```
seed
 └── "PP/v1/spend"  → spending secret     withdrawal authority; never leaves the device
      ├── "PP/v1/view"   → viewing root   never shared directly, only slices of it
      └── "PP/v1/ident"  → ed25519 identity  signs disclosure bundles; no spend power
```

Under the viewing root:

```
viewing root
 ├── epoch secret   HKDF(root, "PP/v1/view/epoch/<epochId>/r<rotation>")   ← what an auditor gets
 │    └── note key  HKDF(epoch, "PP/v1/view/note/<noteId>")                ← finest scope
 └── rotation tag   HKDF(root, "PP/v1/view/rotation-tag")                  ← registry epoch keys
```

Two scope granularities fall out of this for free:

| Grant | Material handed over | What it opens |
|---|---|---|
| Fiscal period | epoch secrets for the months in range | every note in those months |
| Specific transactions | per-note keys | exactly those notes |

Derivation is one-way at every level: a note key reveals nothing about its epoch secret
or its siblings, and an epoch secret reveals nothing about the viewing root or any other
epoch. `epochId` may not contain `/`, so no epoch string can impersonate another
domain-separated label.

Epochs are whole months in **America/Sao_Paulo**. A fiscal-period grant decrypts whole months;
notes in those months that fall outside the signed period are decrypted by the auditor's tool
but excluded from the statement.

## Note records

Each shielded movement appends one AEAD record (XChaCha20-Poly1305) to a per-`(epoch,
rotation)` **hash chain**. The cleartext header carries only routing and chain links —
`poolId, epochId, rot, seq, noteId, prevHash` — and is bound in as AAD, so a record
cannot be replayed under a different sequence number or pool. Amounts, counterparties,
PIX references and memos are all inside the ciphertext.

The chain detects a record that was **written and then withheld**: contiguous `seq`, intact
`prevHash` links, and the signed per-epoch `{count, head}` attestation pin the expected
length. On its own it cannot detect a movement the wallet never logged at all — `seq` would
stay contiguous. That is what pool reconciliation is for.

Every note that has a pool footprint carries a BRL restatement of its commitment's balance
(`valueBRLCents`): at the stated rate when there is one, otherwise the lineage's previous BRL
value carried forward by the movement. Without it a position cannot be put into BRL, and the
statement cannot close.

## The fiscal statement

What a tax authority needs for a period is the balance at each end and the movements in
between. `auditDisclosure` produces exactly that:

| Field | Meaning |
|---|---|
| `period` | the audited period as signed in `terms.period` — not the key's validity |
| `validity` | when the key may be used |
| `openingBalanceBRLCents` | BRL restatement of every position held when the period began |
| `movementsBRLCents` | net of the in-period movements (`totalsByKind` itemises them) |
| `closingBalanceBRLCents` | BRL restatement of every position held when the period ended (without pool state, unverifiable notes are added too) |
| `ragequitExitsBRLCents` | positions that left the pool by ragequit in the period — value out with no movement note |
| `revaluationBRLCents` | closing − opening − movements + exits: positions restated at different rates. Never a missing movement — those are findings |
| `pool.openingValueWei`, `pool.closingValueWei` | the same two positions in the pool asset, derived from pool state |
| `complete` | every movement and position in the period is disclosed, consistent with pool state, and its spend state **proven** |
| `spendStateProven` | every disclosed anchor's nullifier hash is bound by a verified commitment proof |
| `brlVerified` | every BRL figure carries a rate, agrees with its wei at that rate, and the rate was checked against a reference price |
| `unverified`, `assumptions` | what the report could not check, and what no pool state can establish — stated in the report, not left to this document |

With pool state, a movement belongs to the period its **block** fell in, not the time its note
states, and a note with no pool footprint is left out of every figure (it is listed as
`unanchored_note`): nothing can verify it, and it once let a fabricated debit lower a closing
balance.

### Opening positions

A period that begins with money already shielded cannot be stated from in-period notes: the
opening balance lives in notes from before the period, which the grant must not reveal.

So a fiscal-period bundle carries, signed, an **opening position** for every lineage the user
held when the period began — the latest commitment in it. Each is a pool anchor only
(`value, label, precommitment, commitment, nullifierHash, lineageIndex, valueBRLCents`): the
auditor learns what was held, not the movement that produced it. No pre-period PIX reference,
counterparty, sender attestation or memo, and no key for any pre-period month, reaches the
auditor. The signature covers a commitment to the positions, and the vault receives only that
commitment — balances are no more the vault's business than keys are.

A movement recorded just before a month boundary and mined just after it belongs to the period
the chain put it in, while its note lives in the neighbouring month. The bundle then carries
that single note's key (`scope.noteIds`), not the neighbouring month's.

## Pool reconciliation — verifying against the shielded pool

A note set the user authored proves nothing by itself. The auditor re-derives everything
from pool state ([reconcile.ts](../packages/viewing-key/src/reconcile.ts)), against an
indexer it can run itself.

Each anchor carries `value`, `label`, `precommitment`, `commitment`, `nullifierHash`,
`lineageIndex`. It never carries `nullifier` or `secret` — those *are* the withdrawal
witness. `precommitment` is their Poseidon image, so it lets the auditor recompute the
commitment while inverting it means breaking Poseidon. `assertNoWitness` enforces the
omission at seal time, and opening positions are rebuilt field by field so nothing else can
ride along.

### Chain facts, not claims

A note's `nullifierHash`, `lineageIndex`, `kind` and date are what the user wrote. A second
adversarial pass showed each could be abused while the report still said `complete`: a swapped
nullifier hash made a withdrawn position look held; a withdrawal's remainder relabelled as
position 0 passed for a deposit a tenth of the real one's size; a commitment spelled in hex was
counted twice. So each is now either read from the event log or bound by proof:

- **Spend state is proven.** `nullifierHash = Poseidon(nullifier)` is not bound to the
  commitment by anything the auditor can recompute — only the witness links them. The wallet
  therefore attaches, per disclosed anchor, a proof from upstream's audited `commitment.circom`
  (the circuit ragequit uses), with its ceremony keys: it proves knowledge of a witness giving
  exactly this commitment and this nullifier hash, and reveals nothing beyond the anchor
  ([proofs.ts](../packages/viewing-key/src/proofs.ts)). No new circuit. An anchor without a valid
  proof is `unproven_anchor`, its spend state is not used, and a report without proofs cannot be
  complete.
- **Lineages follow the chain.** `insertionOf` says whether a commitment was minted by a deposit
  or re-committed by a withdrawal, and which nullifier that withdrawal spent. Predecessors and
  successors are found by those links, not by index arithmetic; a claimed position or kind the
  chain contradicts is `lineage_mismatch` / `kind_mismatch`; deposit coverage matches the
  deposit's own commitment.
- **Encodings are canonical.** Anchor fields must be canonical decimal field elements
  (`non_canonical_anchor`), and one commitment may appear once (`duplicate_commitment`).

### Deposits a contract made: the ramp escrow

Users hold Movva, and almost none of their notes are deposited by their own account. A purchase is
delivered into the pool by `FiatEscrow` (shielded delivery), and a sale is funded by a relayed exit. (Until
14 October 2026 a save or a withdrawal from savings was also a zap by `ShieldedYieldRouter`; savings, the
router and their attribution were removed by client decision D1.) The pool records the contract as depositor of
record, so "every deposit by a declared account must be disclosed" found nothing to hold the user to.

- **The wallet adopts, it does not assert.** `ViewingKeyService.reserveDeposit` hands out the witness for a
  deposit a contract will make, from the same counter every other path uses, so no index is reused.
  `adoptDeposit` and `adoptSpend` record a movement only when the pool state confirms it (the commitment was
  inserted by a deposit under this precommitment, or the withdrawal spent this position and inserted this
  successor) **and** the user's witness opens it. The note is dated by the block. Adopted lineages go through
  the same `proveDisclosure` path as any other.
- **The auditor reads who each deposit was for from the contract that made it.**
  `fetchEscrowAttributions` reads released shielded orders (attributed to the taker, or the rescue address
  named at lock) from the escrow's own state and events (`fetchRouterAttributions`, for the removed router's
  zaps, went with savings), and `IndexedPoolState.attribute` loads them. Reconciliation then raises
  `undisclosed_deposit` and `undisclosed_opening_position` for these exactly as for a direct deposit, and the
  report names the contracts it checked. An attribution naming a deposit that contract did not make is refused.
  Without attributions an omission is not detectable, and the report says so (`unowned_label` and a stated
  assumption). The facts are on-chain, not the user's word.
- **What was paid is not what the pool moved.** A note carries `amountBRLCents`, the value the pool moved
  (R$ 494,55 after the vetting fee), and `settlementBRLCents`, what was paid or received outside the pool
  (R$ 500,00 by PIX). An escrow order records what it required, so a purchase whose stated settlement
  disagrees is `settlement_mismatch`. A **sale's** settlement is the user's statement: sales open from an
  account with no history, so nothing on-chain ties the PIX received to the user.
- **Assets with more than 18 decimals.** sMovva shares had 24, so a share price per 10^18 base units rounded
  to zero, and a note stated its `rateScale` (sMovva: per 10^30). sMovva was removed with savings (D1, 14 October
  2026); Movva has 18 decimals.

Tests: `test/intermediary-disclosure.test.ts` (an omitted escrow delivery, an omitted pre-period escrow
lineage, the same omissions without attributions, an inflated or missing purchase cost, a forged attribution,
silence about post-period activity; the zap and sMovva cases were removed with savings), and the Movva wallet's
end-to-end run (`packages/wallet/examples/movva-wallet-live.ts`), where an auditor verifies the balance against
the chain.

### One statement for the period, across both balances

> **Since 14 October 2026 (client decision D1) a user holds Movva only**: sMovva, its pool and the wallet's
> savings ledger were removed, so the Movva-plus-sMovva statement below, the savings pool's revaluation and the
> "yield" term no longer arise for a primary wallet. This section is kept as the design of combining per-pool
> statements under one identity.

A user holds Movva and sMovva, two pools, and Receita Federal wants one picture of what the person held and
earned. `combineStatements` (`packages/viewing-key/src/combined-statement.ts`) is auditor-side and adds no
trust: each per-pool report is still verified on its own, and the combination re-checks each grant's
signature and that each report came from that grant, is scoped to a fiscal period and was reconciled against
its pool. It refuses statements for a different subject, period, auditor or declared accounts, and the same
pool or grant twice. Movements are merged by the time the pool recorded them; one whose transaction also
touched the other pool is a move between the person's own balances, not money in or out. The savings pool's
revaluation is income. The total must add up - opening + money in and out + between balances + yield -
ragequit exits = closing - and when the auditor names the pools that must be covered, a pool with activity for
a declared account and no statement is `missing_statement`.

Combining needs one identity across the pools, and nothing else shared: each pool has its own spending key and
viewing root under that identity, and the wallet refuses a shared spending key, a shared viewing root or two
identities.

### Everything is judged as of the audited period

An audit of last year is run this year, after the user has kept transacting. Reconciliation
therefore evaluates spends and insertions **at the period's boundaries**, using the block time
of each pool event, rather than against whatever block the auditor's indexer is at:

- a commitment spent **after** the period counts as held at its end, and the later spend is
  never named in a finding. Judging a past quarter against today's spent-set used to report
  every later withdrawal as a truncated disclosure — an error against an honest user that could
  only be cleared by disclosing the out-of-scope withdrawal;
- the closing position is what was held at `period.toTs`, not what is held today.

### The checks

Each closes a different way to lie:

1. **Integrity** — recompute `Poseidon(value, label, precommitment)` and require the result
   to be a leaf of the attested root. An edited amount fails here (`commitment_mismatch`,
   `not_in_tree`).
2. **Dating** — the block that inserted each commitment must agree with the note's stated time
   (default tolerance 6 hours). A disagreement that moves a movement across the period
   boundary is an error (`timestamp_mismatch`): otherwise income could be filed in a different
   fiscal year from the one it arrived in.
3. **Deposit coverage** — `Deposited` carries the depositor address in clear on L1. For the
   accounts the user attests to (signed into `terms.accounts`), every deposit inside the
   signed period must be disclosed (`undisclosed_deposit`). Out-of-period deposits stay
   private.
4. **Opening coverage** — every lineage a declared account opened before the period must have
   an opening position actually held at the period start, or have ended by ragequit before it
   (`undisclosed_opening_position`). An opening position inserted inside the period, or
   already spent before it, is refused (`opening_position_invalid`) — that is how a larger,
   older balance would be passed off as the opening one.
5. **Lineage continuity** — a commitment spent inside the period creates exactly one successor,
   which must be disclosed (`truncated_lineage`, `spent_flag_mismatch`); a disclosed movement
   must continue a disclosed position. A ragequit ends a lineage legitimately (`ragequit_exit`).

6. **BRL figures** — every movement's amount must agree with the wei it moved at its own stated
   rate (`brl_amount_mismatch`), every restatement with its balance (`brl_rate_outside_band`),
   and — given a reference price (`rateReference`, e.g. a USD/BRL × ETH/USD history) — every rate
   with the market (`brl_rate_implausible`). Without a reference, a consistently false rate would
   pass, so `brlVerified` stays false and the report says why.

The reference ships as [price-reference.ts](../packages/viewing-key/src/price-reference.ts):
Banco Central's PTAX USD/BRL closing rate (public Olinda API, Brasília time, previous business
day before a bulletin) times the asset's USD price from a Chainlink feed's on-chain round
history (binary search across the proxy's phases), for exactly the insertion times the
disclosure contains (`disclosedTimestamps`). Every value used is kept in `sources`, so a report
can cite it and anyone can recompute it. USD stablecoins are priced at exactly 1 USD, stated as
an assumption.

```ts
const times = disclosedTimestamps(bundle, records, pool);
const ref = await RateReference.build(times, { asset: { kind: 'chainlink', feed: ETH_USD }, rpcUrl });
auditDisclosure(bundle, records, { now, pool, proven, rateReference: ref.at });
```

Transaction-scoped grants run the integrity, dating and BRL checks only:
they deliberately disclose part of the user's activity, and faulting them for what they leave
out would punish exactly the privacy the grant exists to give.

**Two residual assumptions**, both stated in every complete-mode report's `assumptions`:

- **`terms.accounts`.** A user could deposit from an account they do not declare. That is not
  solvable inside the pool; it is solved where the address is already bound to an identity —
  the KYC'd fiat ramp.
- **Lineages a contract deposited for the user.** Their depositor of record is an escrow,
  not the user, so the pool cannot enumerate them unless that contract's deposits are
  attributed (above). One the user leaves out entirely — neither disclosed when it arrived nor as
  an opening position later — is otherwise not detectable; nor is its balance. Corroborate with
  counterparties. (There are no user-to-user transfers: the client removed Rev. 3 §5.3 from scope
  on 12 October 2026, and the transfer router was deleted.)

`auditDisclosure` called without a `pool` source says so in `warnings` and sets
`poolVerified: false`.

## Grant lifecycle

1. **Issue** — the client builds a `DisclosureBundle`: public `terms` (pool, subject, auditor,
   purpose, `accounts`, `registrar`, audited `period`, scope, validity window, nonce), the
   `attest` heads, the `opening` positions, and the scoped key `material`. Signed by the
   identity key over the terms digest, the attestations, the opening positions **and a
   commitment to the material**, so none of them can be altered after the fact.
2. **Register and seal** — `registerAndRotate(grantId, subject, validFrom, expiry, pointer,
   epochKeys)` in one transaction: the grant goes on-chain and every note chain it can read is
   rotated. See *Expiry is cryptographic* below. No key material, no amounts, no
   counterparties ever touch the chain.
3. **Audit** — the auditor sends the vault the **public form** of the bundle
   (`toPublicDisclosure`: the material replaced by its commitment) with a proof of its key;
   verifies the full bundle's signature, the window and the on-chain status itself; refuses any
   record outside the granted scope; checks chain continuity; reconciles against pool state;
   produces the statement.
4. **Revoke** — `revoke(grantId)`, or `revokeAndRotate` for a grant issued before sealing
   existed.

### Subject binding

A bundle is signed by an off-chain ed25519 key; a registration is authorised by an L1
account. Binding them stops an auditor being handed a bundle whose "live" status was
registered by someone else. The auditor requires:

```
status.subject == terms.subject   AND   status.owner == terms.registrar ∈ terms.accounts
```

and `terms.accounts` is itself covered by the signature. An attacker may register any
subject key they like, but only under their own address — absent from the victim's signed
account list, and the signature over that list cannot be forged.

Grants are keyed on `(owner, grantId)`, not `grantId` alone: keying on the hash alone would
let anyone front-run a registration and permanently block the real subject with
`AlreadyRegistered`.

### Note-chain anchors

`{count, head}` in a bundle is self-attested — the user's own signature over their own
numbers, which proves authorship, not completeness. `anchorChain(chainKey, head, count)`
commits the head of each note chain **as the user transacts**, append-only: `count` may never
decrease, and re-anchoring the same count with a different head is rejected.

So an auditor comparing the bundle's attestation with the earlier anchor detects a disclosure
that omits committed history, or records rewritten at the same length. The timing is the whole
point — an anchor written at disclosure time commits to whatever the user chose to disclose
and proves nothing, which is why `anchorChains()` is a periodic client operation rather than
something the disclosure path does for you. When no anchor exists, the report says so instead
of implying it checked.

## The note vault

`NoteVault` holds ciphertext and releases it to auditors against a live grant.
[vault-service.ts](../packages/viewing-key/src/vault-service.ts) runs it over HTTP
(`src/bin/vault.ts`), with an append-only JSON-lines store.

- **It never receives a key.** The signature over a bundle covers a commitment to the material,
  so the vault verifies authorship from the public form. It used to be handed the whole bundle,
  epoch secrets included, which let a vault operator read every period its users disclosed. A
  request still carrying material is refused; `VaultClient` refuses before sending. Opening
  positions travel the same way, as a commitment.
- **Every route authenticates itself; there is no operator credential.** Auditors prove the key
  named in `terms.auditorKey` with a single-use nonce and bounded clock skew. Owners prove their
  identity key to file records (`putAuthenticated`), to fetch their own records back, and to
  read their access log. Unauthenticated writes would let anyone file undecryptable records
  under a victim's subject and make every audit of that user fail. Filed records must extend
  the stored chain in order; a retry is a no-op.
- **It gates on `isLive`**, refreshing the grant from the chain before serving it, and refuses a
  registry view older than its bound — a stale view fails *open* for revocation.
- **It filters to the grant's scope and the grantor's own records**, rate-limits per grant, and
  keeps a bounded access log of every release and refusal, readable by the owner only. A request
  is logged only after the auditor's proof and the bundle's signature verify: every field of an
  unverified request — the auditor's name included — is the sender's choice, and refusals used
  to let anyone write whatever they liked into a user's log.

None of this is the security boundary — the key scope is. A fully compromised vault leaks
ciphertexts and metadata (counts, epochs, timing), and can refuse to serve; it cannot widen what
any auditor can read. Holding no secret, it can be replicated on machines nobody trusts: wallets
file with every replica, auditors ask any one.

## Expiry is cryptographic

An epoch secret decrypts its `(epoch, rotation)` chain forever. If that chain stayed writable
after issuance, anything recorded into it later — the rest of the current month, or a
late-settled note dated into a past one — would be readable with a key that has expired, by
anyone holding the ciphertext (with `ShieldedNoteLog`, everyone).

So issuing a fiscal-period grant **seals** the chains it covers: their rotation is bumped in the
same transaction that registers the grant, and later notes land in a fresh chain whose secret
the grant's material cannot derive. A grant covers exactly the notes that existed when it was
issued. Revoking it then has nothing left to rotate; revocation rotates only chains an older
grant left open. Per-note grants need no sealing: a note key opens one note.

Registry epoch keys are keyed by the viewing root (`epochKeyFor`), not a plain hash of the
month: rotations are public events under the user's address, and a guessable key let any chain
observer read which months a user was audited for, and which grants they revoked.

## The user's own tax figures

A disclosure proves a period to someone else. The user filing their own IRPF needs different
numbers: each asset at **acquisition cost** on 31 December of both years, and the year's
disposals with their cost and gain. Cost depends on every movement since the first, so
[tax-export.ts](../packages/viewing-key/src/tax-export.ts) computes it owner-side from the full
history (`ViewingKeyService.annualTaxSummary`): weighted average cost, units taken from pool
anchors, months in Brasília time, a suggested Bens e Direitos code (08.02 for ETH, 08.03 for
stablecoins) and a semicolon CSV for an accountant. It reports facts; it does not decide
exemptions or the treatment of self-custodied assets under Lei 14.754/2023 - every summary
says so.

For Movva, acquisition cost is the reais actually paid - `settlementBRLCents`, so the LP's spread and the
pool's vetting fee are part of the cost - and a sale's proceeds are the reais received. Movva is a stablecoin
line (08.03). There is no savings yield to recognise: sMovva (formerly its own asset, 08.99, with its gain
recognised when savings were withdrawn) was removed with savings by client decision D1, 14 October 2026.

## What revocation does and does not do

Being precise here matters more than the marketing line:

- It **does** stop the ex-auditor fetching further ciphertexts — the note vault gates
  every release on the on-chain grant status.
- Notes written after issuance were **already** out of reach (sealing, above). This is real
  forward secrecy, not a policy promise.
- It **does not**, and cannot, retract plaintext the auditor already decrypted, nor records the
  auditor already fetched — and with `ShieldedNoteLog`, the covered records are public, so the
  auditor can re-read them without the vault. No cryptosystem can take this back. Product copy
  must say *"stop future access"*, never *"take back what you shared"*. An audit that could be
  retroactively erased would be worthless to the auditor anyway.

## Read-only by construction

Four independent reasons a viewing key of any scope cannot move funds:

1. **Derivation** — viewing material is an HKDF *child* of the spending secret. Going back
   up means inverting HKDF-Extract over SHA-512. The same holds for the pool witness
   `(nullifier, secret)`, which hangs off `spend` and is unreachable from `view`.
2. **Protocol** — withdrawal needs the nullifier secret from the spending branch. No
   function in this package takes viewing material and returns spending material; every
   viewing function maps viewing-branch input to viewing-branch output.
3. **Disclosure content** — a bundle carries epoch secrets or note keys, plus `precommitment`
   as an anchor. Withdrawal needs `(nullifier, secret)`; only their Poseidon image is ever
   published, and `assertNoWitness` refuses to seal a note containing either.
4. **Contract** — the registry holds no funds and has no reference to the pool's
   withdrawal logic, so it is structurally incapable of authorising a spend.
5. **Commitment proofs** — the proofs a bundle carries are valid *ragequit* proofs, which is
   worth stating exactly. `PrivacyPool.ragequit` accepts one only from the lineage's original
   depositor and pays only that account, so the auditor cannot use it. Someone who already
   controlled the user's depositor account could use a leaked proof to force the position out
   of the pool back to that account. For a Safe depositor that account is guarded by the same
   passkey the spending key derives from, so this adds no practical capability; for a bare EOA
   depositor it does, and product copy for EOA users should say so.

`test/readonly.test.ts` asserts (1) and (2), including that re-deriving a wallet from any
viewing-branch value does not reproduce the spending secret. `test/pool-audit.test.ts`
asserts (3) by scanning a full bundle and report for the witness values and the spending
key, and confirming only the Poseidon image is present.

## Threat model

| Adversary | Outcome |
|---|---|
| Note-vault operator (holds every ciphertext) | learns counts, epochs and timing, never content or balances — it never receives a key or an opening position, and refuses a request that carries keys. Can refuse to serve |
| Anyone writing to a user's access log | refused: nothing is logged until the auditor's proof and the grant's signature verify, and the log is bounded |
| Stranger writing to the vault under a victim's subject | refused: filing requires the owner's identity-key proof |
| Auditor exceeding scope | out-of-scope records fail authentication; the auditor tool *refuses* them rather than ignoring them, so an over-broad vault response is visible |
| Auditor after expiry or revocation | cannot fetch new ciphertexts; cannot read notes written after issuance, ever; retains what it already saw |
| Auditor looking past the period on L1 | **partly possible.** Each disclosed anchor names a commitment and nullifier hash that are public on-chain once used, so the auditor can find the one withdrawal that next spends each commitment held at period end (its time, amount and recipient), and the event that created each opening position. It cannot follow further — the successor's nullifier hash is not disclosed. Reports never name these events |
| Attacker registering a grant for someone else | rejected: `status.owner` is their own address, which is not in the victim's signed `accounts`, and per-owner keying stops them blocking the real registration |
| Lineage no declared account opened | flagged for follow-up (`unowned_label`), unless an attributed intermediary made it for a declared account or it is a re-shielded sale refund |
| User withholding a logged note | detectable via sequence gaps, broken chain links, or a head mismatch against the signed attestation |
| User never logging a movement | detectable — the deposit is on L1 under a declared account (`undisclosed_deposit`), or the lineage is truncated (`truncated_lineage`) |
| User editing an amount | detectable — the recomputed commitment is not in the tree (`commitment_mismatch`, `not_in_tree`) |
| User filing a movement in another period | detectable — the commitment's insertion block contradicts the note's date (`timestamp_mismatch`) |
| User understating the opening balance | detectable for lineages a declared account opened — a lineage with no position held at the start (`undisclosed_opening_position`), or a stale one passed off (`opening_position_invalid`). **Not** detectable for a lineage that began as an inbound transfer and is left out entirely (see assumptions) |
| User swapping a nullifier hash to hide a spend | detectable — no valid commitment proof binds it (`unproven_anchor`) |
| User relabelling a withdrawal's remainder as a deposit | detectable — the chain inserted it by a withdrawal (`lineage_mismatch`, `kind_mismatch`), and the real deposit is undisclosed |
| User booking a movement at the wrong BRL value | detectable against its own wei and rate (`brl_amount_mismatch`); a consistently false rate only against a reference price (`brl_rate_implausible`), otherwise `brlVerified: false` |
| User adding an unverifiable debit memo | excluded from every figure (`unanchored_note`) |
| User depositing from an undeclared account | **not** detectable on-chain; a false signed attestation, mitigated at the KYC'd ramp |
| User omitting a deposit the ramp escrow made for them | detectable when the auditor loads that contract's attributions (`undisclosed_deposit`, `undisclosed_opening_position`); without them, `unowned_label` and a stated assumption |
| User inflating what a purchase cost (to lower a later gain) | detectable - the escrow recorded what the order required (`settlement_mismatch`). A sale's proceeds are the user's statement |
| Anyone attributing a deposit to the wrong person | refused - an attribution must name a deposit the attributing contract made |
| Auditor attempting a withdrawal with what it was given | impossible: the witness `(nullifier, secret)` is never disclosed, only its Poseidon image |
| Chain observer | sees each grant's `grantId`, subject key, registering address and window, and that rotations happened — not which months (epoch keys are keyed). With anchors or `ShieldedNoteLog`, also note counts and write times per chain under the user's address |
| Leaked viewing key of any scope | zero spending authority; reads only within that scope, and only notes that existed when it was issued |

## Recovery

`recoverFromChain` rebuilds pool-side state from the spending key and public L1 data alone.
Deposits by the user's account come back from `Deposited` events in order, which fixes every
`depositIndex`; each lineage is then walked forward, a spent `nullifierHash` naming the
successor whose witness is the next index. This is why the witness is keyed on
`(depositIndex, lineageIndex)` rather than on anything device-local. A ragequit closes a
lineage. A deposit whose commitment the derived witness does not reproduce is *reported*, never
skipped — dropping it would understate the balance.

Deposits a contract made are not found by depositor, so `recoverByPrecommitment` walks the user's deposit
indices instead, checking each derived precommitment against the pool's events, stops after 100 unused
indices in a row, and moves the counter past everything it scanned. A ragequit is recognised by matching the pool's
`Ragequit` events by commitment, since that event carries no nullifier hash. Recovery used to look only at the
spent-nullifier set, which pool state rebuilt from real logs never sets for a ragequit, so an exited position would
have been counted as held (SR-9 in `security-review-phase1.md`).

Note **contents** (amounts, PIX references, counterparties) are only inside the encrypted
records, so they come from whichever backing holds them: the on-chain note log, or the owner
route on the vault (authenticated with the identity key, and logged). With the on-chain log
there is nothing extra to keep. With the vault alone, if those records are gone the balance is
still correct while the itemised statement is not — that limit should be in the product copy,
not discovered during an audit.

## Where note records live

Two backings, with a real trade-off rather than a preference:

| | Off-chain vault + `anchorChain` | `ShieldedNoteLog` |
|---|---|---|
| Cost | cheap; one anchor tx per period | calldata per note |
| Rollback | **detected** if an anchor already covered the missing notes | **impossible** — `seq`/`prevHash` enforced at write time |
| Availability | depends on the vault replicas | as durable as the chain |
| Revocation gating | meaningful for records not yet fetched | none; records are public (expiry still holds for later notes, by sealing) |
| Metadata leaked | vault operator sees counts and timing | anyone sees counts and timing |

A user proving a fiscal year to Receita Federal wants the log's guarantees. A user making many
small payments wants the vault. The client supports both, an auditor is told which backed the
report, and both use the same chain hash (below) so nothing has to be translated.

### One chain hash, three users

`NoteLog.head` (what a bundle attests), `AuditGrantRegistry.anchorChain` (the periodic
commitment) and `ShieldedNoteLog` (write-time enforcement) must agree, so the formula lives in
[chainhash.ts](../packages/viewing-key/src/chainhash.ts) once:

```
chainKey   = keccak256(utf8("<poolId>:<epochId>:r<rot>"))
recordHash = keccak256(abi.encode(chainKey, uint32 seq, prevHash, keccak256(record)))
record     = utf8(canonical JSON of the record)
```

These were briefly three different formulas, which made an auditor comparing an attested head
against an anchored one compare unrelated digests and report "records were rewritten" for an
honest user. A test replays real records through the deployed contract on an EVM and asserts
the client reproduces its head byte for byte, so drift fails a test rather than an audit.

Unlike registry epoch keys, `chainKey` is still a plain hash: an auditor needs it to check
anchors and record hashes. With anchors or the note log, a chain observer can therefore tell
which month a user's notes belong to. Keying it would mean carrying the chain key in each bundle
and changing the hash all three components share; it is listed below.

## Open items

- **`terms.accounts` remains an attestation.** A deposit from an undeclared account is a false
  signed statement, not something the maths catches. It is caught where the address is already
  bound to an identity — the KYC'd ramp. Nothing on-chain can close this; do not let the
  product copy imply otherwise.
- **One-hop linkage past the period** (threat model above) is inherent to verifying against a
  public pool. Product copy for a fiscal-period grant should say the auditor can see the next
  withdrawal of each position held at period end.
- **Note-log metadata.** `chainKey` is a guessable hash, and anchors and note-log writes come
  from the user's own address, so their counts and timing can be correlated with relayed
  withdrawals. Keyed chain keys and writes through a relayer would narrow this.
- **The Sepolia `AuditGrantRegistry` predates `registerAndRotate`.** Clients can seal with
  `register` followed by `rotateEpoch` per month until it is redeployed; the two-transaction
  window is the only difference.
- **The reference price is only as good as its sources.** `RateReference` uses Banco Central
  PTAX and a Chainlink feed; an auditor who trusts neither supplies their own `rateReference`.
- **Two devices writing the same month.** Each keeps its own chain; the vault accepts the first
  record at a sequence number and refuses a fork, so the second device must resync
  (`exportForOwner`) before writing. There is no automatic merge. What no longer depends on the
  device is **which rotation a note is sealed to**: with a rotation source
  (`ViewingKeyService.useRotationSource`, reading `ChainGrantRegistry`), a service takes the higher of
  its own mirror and the chain for each epoch, and refuses to write a note for an epoch it has not read
  in the last 120 seconds - so a device that did not issue a grant cannot seal a later note to keys that
  grant already covers. The Movva wallet requires one (`grantRotations`), or an explicit `'no-registry'`.
- **Contract-made deposits need the contracts' attributions.** An auditor who does not load
  `fetchEscrowAttributions` cannot detect an omitted Movva purchase; the
  report says so. `IndexedPoolState.attribute` must run after the logs are applied, or later deposits are
  skipped.
- **A sale's proceeds are a statement.** Selling from an unlinked account keeps the sale from being tied to the
  user on-chain, and for the same reason an auditor cannot verify the reais it brought.
- **Recovery by precommitment stops at a gap of 100 unused indices**, so a longer gap would hide later notes.
- **External review** of the key hierarchy, disclosure format, commitment-proof use, both
  contracts and the vault service before any mainnet deployment.
