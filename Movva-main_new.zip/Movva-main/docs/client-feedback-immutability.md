# The client's "like Bitcoin" proposals, read as requirements

**What this is.** The client's eight proposals after reading the Sepolia deployment report, each turned into what it
asks of the build, what already exists, what it costs, and what has to be decided. Written 24 September 2026 against
commit `3bc70c8`.

**The short version.** Proposals 3, 6 and 7 are mostly agreement with what is already here. Proposal 1 is one command
away, but has a price the report already named. Proposals 4, 5 and 8 are new work that is compatible with the goal.
**Proposal 2 is the one that cannot be done as written**: it requires editing the audited Privacy Pools code, which the
client's own rule forbids, and there is a way to get what they want without touching it.

**Two contradictions to settle first**, because everything else follows from them:

1. **"No admin keys" against "multisig approval" and "pause".** Proposal 1 renounces every role; proposals 4 and 5 ask
   for a circuit breaker and a multisig above a withdrawal limit. A breaker written in code and triggered by the
   contract itself needs no key and is compatible. A human multisig is an admin key by another name and is not.
2. **"No admin keys" against being able to revoke a leaked key.** Renouncing governance means nobody can ever revoke a
   compromised arbitrator, zkTLS witness or attestor key. `FiatEscrow`'s own comment says a stolen arbitrator key can
   drain every offer, and names revocation as the defence. Proposals 2 and 3 remove most of those keys, which is what
   makes proposal 1 safe; the order matters.

## 1. Renounce every privileged role

| | |
|---|---|
| **Asked** | No owner, no admin, no upgrade, no pause on the core: Entrypoint, pools, token, reserve, escrows. |
| **Exists** | `scripts/deploy-movva-rail.ts --finalize`, rehearsed: 15 transactions, no contract change. It renounces the Entrypoint's `OWNER_ROLE` (after which nobody can upgrade it, register pools or grant roles) and hands all 14 `DelayedGovernance` governors to `0x…dEaD` through the one-step `transferGovernor`. The **token already has no owner, no settable minter, no pause and no upgrade**. |
| **Cost, from the report** | Afterwards nobody can revoke a leaked arbitrator, witness or attestor key; resume minting after a guardian pause, so a pause becomes permanent; add or remove a gateway, and only gateways redeem, so losing every gateway key ends redemption for good; repoint an oracle if Pyth retires the feed. |
| **Options** | **(a)** Renounce everything as asked, accepting the above. **(b)** A one-way switch in `DelayedGovernance` that permanently disables every risk-raising change while keeping revocation and pausing: one new function, which the client must approve because it is a code change. **(c)** Do 2 and 3 first, so fewer keys exist to revoke, then (a) is far safer. |
| **Recommendation** | (c), then (a). Sequencing solves the conflict without a code change. |

## 2. Move the ASP outside the core

| | |
|---|---|
| **Asked** | Remove `ASP_POSTMAN` from the Entrypoint; each ASP an independent contract with its own governance; several ASPs, the user choosing; a ragequit fallback if an ASP stops publishing. |
| **Reality** | `ASP_POSTMAN` and `updateRoot` are **inside the audited Entrypoint** (`Entrypoint.sol:43, 82, 85, 93`), and the pool refuses any withdrawal whose ASP root is not the Entrypoint's latest (`PrivacyPool.sol:59`). Removing the role, or letting a pool accept a root from a user-chosen source, means editing audited code and re-auditing, and the second also touches what the withdrawal circuit binds. That is exactly what the client's own "do not edit the upstream audited code" rule excludes. |
| **What already satisfies part of it** | **Ragequit exists upstream** (`PrivacyPool.sol:132`): the original depositor can always exit without any ASP. In this rail the escrow is the depositor, so the escrow's `rescueShielded` routes it to the note's owner, bound to their proof. So "if the ASP stops publishing, users recover their deposit" is already true. |
| **How to get the rest without touching the core** | **The postman is an address, so make it a contract.** Point `ASP_POSTMAN` at a multisig, a DAO or an aggregator contract that publishes a root only when several independent providers agree. The ASP then has its own governance, exactly as asked, with **zero** core change and the anonymity set intact. |
| **What "several ASPs the user chooses" really costs** | Without core changes it means one Entrypoint and pool set per ASP. Every user who picks a different ASP is in a different anonymity set, and a shielded balance cannot move between them. Splitting the anonymity set is a privacy loss, and for a rail this size probably a large one. |
| **Ask the client** | Is an ASP contract with independent governance (one anonymity set) enough, or is user-selectable ASP worth both a fork of the audited core and a split anonymity set? |

## 3. Replace the human attestors with pure zkTLS

| | |
|---|---|
| **Asked** | Remove the 3+3 attestor keys that sign card and bank receipts; use zkTLS with an on-chain verifier only. |
| **Exists** | **Done for bank rails since 14 September** (SR2-34): `IAttestorVerifier.provesBankSession()`, and the escrows refuse to open a PIX, boleto or TED offer or any sale on a verifier that does not prove the bank session. The attestor quorum survives **only for card captures**. |
| **What remains** | Cards. Rev. 3 §2.2 **removes the credit card from the MVP**, so if that still holds, the quorum can be deleted outright and this proposal is complete with no new technology. If cards come back, a card capture has no bank session to prove; proving it would mean a zkTLS session against the acquirer's own dashboard, which is new work and depends on the partner's site. |
| **Ask the client** | Confirm cards stay out of the MVP. If yes, we delete the quorum and its keys entirely. |
| **Decided** | **24 September 2026: cards stay out of the MVP; the quorum, its keys and the PSP attestor service are deleted** (`docs/card-rail-removal.md`). This proposal is complete. |

## 4. Several oracles with circuit breakers

| | |
|---|---|
| **Asked** | Do not depend on one feed; aggregate Chainlink, Pyth and a DEX TWAP; pause mint and redeem automatically when they diverge. |
| **Exists** | The rate is already **two independent sources crossed**: Chainlink USDT/USD and Pyth FX.USD/BRL (`MovvaReserve._rate`), each with its own maximum age; a stale leg refuses rather than guesses. The ramps quote inside a band with its own oracle and age limit, and every escrow refuses an out-of-band price. `IssuerFreeze` stops new business if the token issuer freezes an address. |
| **Missing** | A third independent source, and an automatic divergence breaker that halts mint and redeem rather than refusing individual calls. |
| **Feasibility of the DEX TWAP** | A USD/BRL TWAP needs a BRL asset with deep on-chain liquidity on Ethereum L1. BRZ and BRLA exist but are thin; a TWAP over a shallow pool is easier to manipulate than the feed it is meant to check. Worth pricing against a second FX publisher instead (a signed-price publisher already exists: `SignedPriceOracle`). |
| **Compatible with proposal 1** | Yes, if the breaker is code that trips on its own. The existing pause needs a key to lift, which is the conflict named above; a breaker that clears when the feeds agree again needs nobody. |

## 5. Yield, and hot/cold withdrawal limits

| | |
|---|---|
| **Asked** | USDT in segregated vaults earning yield; instant withdrawals to a daily limit, timelock or multisig above it; yield returns to the wallet layer. |
| **Exists** | `YieldVault` (ERC-4626) over governor-listed adapters with per-adapter allocation caps, a deposit cap and a drawdown breaker; the reserve's `withdrawToHedge` is **already rate-limited** (`hedgeLimitBps` per window) and refuses to leave the collateral ratio below `minWithdrawCollateralRatioBps`; `KeeperGate` gives each keeper replica a revocable key and a daily turnover budget. Savers already receive yield as a rising sMovva share price. *(Since removed: client decision D1, 14 October 2026, took savings and sMovva out of M1; the reserve's yield is Mova's.)* |
| **Missing** | The explicit hot/cold split, and the escalation above the daily limit. |
| **Conflict** | "Multisig approval above the limit" is an admin key, which proposal 1 removes. A **timelock is the version that survives**: above the daily limit the withdrawal is announced on-chain and executes after a delay, with no one able to approve or block it. |
| **Ask the client** | Timelock rather than multisig above the limit? |

## 6. Clean up the orphaned contracts

| | |
|---|---|
| **Asked** | Renounce `OWNER_ROLE` on the contracts of the earlier abandoned deployment; document any lost key; make sure nothing points at them. |
| **Reality** | The 8 September Sepolia stack is listed in [deployments.md](deployments.md): Entrypoint proxy `0x3f77…`, the ETH pool, both verifiers, `AuditGrantRegistry`, `ShieldedNoteLog`, `SponsorPaymaster`. `OWNER_ROLE` and the paymaster's owner are the key rotated after the September incident (`0x941f…`). |
| **Feasible** | Yes, provided that key is still held: one renounce transaction per role, then the same privilege inventory re-run to prove nothing is left. Sepolia ETH only. |
| **Note** | These are testnet addresses, so the value at stake is zero; the reason to do it is hygiene and a clean report. |

## 7. Verification and audit

| Item | Status |
|---|---|
| Run the real CI through `workflow_dispatch` | Possible today. **Blocked in practice:** every job has been failing since 20 September with no runner assigned and no steps, which points at exhausted Actions minutes on a private repository. That needs the billing check before any CI claim is made. |
| The full privilege inventory (344 checks) on an RPC without the `eth_getLogs` cap | The 344 figure is from our own `--finalize` rehearsal. Running it against real Sepolia needs an RPC that serves wide log ranges: a paid Alchemy/QuickNode key, or an archive endpoint. |
| Professional audit: manual review plus a public competition, then a mitigation review | Agreed, and [audit-scope.md](audit-scope.md) exists for exactly this. External cost, and the client's decision. |
| Funded end-to-end testing on Sepolia once the Pyth BRL price refreshes | The 10 "expected" failures in the report are Sepolia's stale Pyth FX price. **We do not have to wait:** Mova's own Pyth keeper can post a fresh update to Sepolia, which is what it does in production. That needs a Hermes credential and a funded keeper key. |

## 8. Governance "like Bitcoin" (future)

| | |
|---|---|
| **Asked** | A governance token that cannot touch the immutable core; it governs only the periphery (ASPs, treasury, coordination); core changes happen by social fork and voluntary migration. |
| **Reality** | If proposals 1 and 2 are done, this is largely a **consequence rather than a feature**: a core with no roles cannot be governed by anything, and the only governable things left are the periphery contracts. |
| **New work** | The token, its distribution, and the DAO that owns the periphery: the ASP contract, the treasury, and the fee parameters that are not renounced. None of it exists today. |
| **Warning worth giving** | A governance token over a treasury attracts its own regulatory questions in Brazil, alongside the ones already open for offering yield. |

## What we would do, in what order

1. **Confirm cards are out** → delete the attestor quorum and its keys (proposal 3, complete).
2. **Point `ASP_POSTMAN` at a governed contract** rather than removing it (proposal 2's intent, no core change).
3. **Add the automatic divergence breaker** and decide the third price source (proposal 4).
4. **Replace the above-limit multisig with a timelock** (proposal 5).
5. **Then renounce everything** (proposal 1), by which point the keys that would have needed revoking are gone.
6. **Renounce the orphaned Sepolia roles** (proposal 6) and re-run the inventory.
7. **Fix CI billing, refresh the Sepolia Pyth price with our keeper, commission the audit** (proposal 7).
8. **Design the token and DAO** once the core is frozen (proposal 8).

## The questions to put on the call

1. Is an ASP contract with its own governance enough, or is user-selectable ASP worth forking the audited core and splitting the anonymity set?
2. Do cards stay out of the MVP?
3. Timelock instead of multisig above the withdrawal limit, so no key exists?
4. Automatic breaker that clears itself, or a pause someone must lift, which requires keeping a key?
5. Third price source: a DEX TWAP on thin BRL liquidity, or a second signed publisher?
6. Is the old Sepolia owner key still held, for the orphaned renouncements?
7. Who mints MOVVA, the reserve or the escrow? **Still open from Rev. 3, and it must close before an immutable deployment.**
