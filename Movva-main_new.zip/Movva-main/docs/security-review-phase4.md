# Internal security review — Phase 4 (shielded internal transfers)

Reviewer: internal. Date: 2026-09-13. Scope: `packages/viewing-key/src/transfer.ts`, the
`receiveTicket`/`send`/`receive` methods on `ViewingKeyService`,
`contracts/transfer/ShieldedTransferRouter.sol`, and two changes to Phase 1 code that this
work forced: `NoteVault.serve` and the inbound-transfer finding in `reconcile.ts`.

**This is not an external audit and does not substitute for one.** It is written by the party
that wrote the code, and the most serious finding below sat unnoticed in delivered code for
three phases.

## Findings

### SR4-1 — The note vault served every user's records to any registered grant
**Severity: high.** `packages/viewing-key/src/vault.ts`, `NoteVault.serve`. **Fixed.**
Phase 1 code, found during Phase 4.

`serve` authenticated the auditor and checked that *a* grant was registered, then selected
records with `byPool.get(poolId).filter(scopeAdmits)` — by pool and epoch, never by owner. So
a grant for March released every user's March records.

Demonstrated against the unfixed code before changing anything: three users shared one
vault, and Mallory's honest grant over her own notes was served **3 records, of which she owned
1**.

Two consequences, both serious:

- **Availability.** A shared vault is the production design. The moment a second user had a
  note in the audited month, the auditor was handed ciphertext it could not decrypt, and the
  whole audit failed with `invalid tag`. Tax disclosures would have stopped working at the
  second customer.
- **Privacy.** Contents stayed encrypted, but the cleartext headers of every other user's
  notes — epoch, rotation, sequence number, note id, and so timing and volume — went to an
  auditor authorised by someone else. And because the registries accept any `subject` a
  registrant names, *anyone* willing to register a grant could collect them.

**Why the obvious fix would have been exploitable.** Filtering by `terms.subject` alone looks
right and is not. Registration does not verify the bundle's signature — by design; the
binding between an ed25519 identity and an L1 account is enforced by checking the signature,
which the auditor did and the vault did not. With only a subject filter, an attacker could
register, under their own address, a grant *naming a victim's subject* and receive exactly that
victim's records.

**Fix.** `serve` now takes the whole signed bundle and runs `verifyDisclosure` — the same
check the auditor runs: signed by `subject`, registered by `registrar`, and `registrar` among
the attested accounts. Only then does it serve, and only from the owner's own index. The
verification runs after the existing refusals, so their messages are unchanged, and before the
rate limit, so a forged bundle cannot spend a real grant's quota.

**Why it survived three phases.** Every audit test used one user per vault. The model and the
tests agreed because the tests never built the world the bug needed — the same shape as the
Phase 1 label bug and the Phase 2 rescue bug. The transfer tests were simply the first to put
two users in one month.

Regression: `test/vault-isolation.test.ts` — an honest grant gets only its owner's records,
several users each get exactly their own, an audit still reconciles beside other users' notes,
a bundle naming someone else's subject is refused and logged with nothing served, and forged
attempts do not exhaust the real grant's rate limit.

### SR4-2 — An audit report showed an unsigned name in place of a verified key
**Severity: low.** `packages/viewing-key/src/reconcile.ts`. **Fixed.** Phase 1 code.

An inbound transfer's finding read `attested by ${senderLabel ?? senderSubject}`. But
`senderLabel` is not in the attestation digest — only the commitment, label, value and
recipient are signed — so it is whatever the sender chose to call themselves. A sender could
appear in a report to a tax authority as "Receita Federal", and the verifiable key would not be
shown at all.

**Fix.** The report always shows the key the signature verified, and shows the label only
marked as self-described and not covered by the signature.

## How transfers are built, and why

**Two operations, because there is no transfer circuit.** The sender proves a withdrawal to
`ShieldedTransferRouter`, which deposits into the same pool under a precommitment only the
recipient can open. Rev. 2 rules out new circuits, and upstream has none for transfers.

**The sender never holds spending material.** The recipient publishes a *ticket*: an X25519
key to encrypt to, and a precommitment — `Poseidon(nullifier, secret)` for secrets derived
from the recipient's own spending key. The sender and the router learn an image they cannot
invert. `assertNoWitness` runs inside the seal and refuses any payload carrying a nullifier,
secret, spending key or viewing root.

**The envelope is a message, not a chain record.** An earlier design sealed a note straight
into the recipient's chain. It cannot work: the anchor needs `nullifierHash`, which only the
recipient can compute, and a chain record needs the recipient's private `seq` and `prevHash`.
So the recipient opens the envelope and writes its own note with the complete anchor.

**The recipient does not take the sender's word.** Before adopting, `receive` recomputes the
commitment from the recipient's own witness and refuses one it could not spend, then checks the
pool actually contains it. Tested with a forged commitment and with a correctly built commitment
that was never deposited.

**Tickets are single-use, expire, and reserve an index up front.** A skipped deposit index
costs nothing; a reused one would put two lineages on one witness. Pending tickets are
persisted, so a restart between issuing a ticket and receiving its payment loses nothing.

**Nobody can redirect a transfer.** The recipient's precommitment, the relayer's fee, the
deadline and the rescue recipient travel in `Withdrawal.data`, which the pool binds into the
proof's context. Tested by swapping the precommitment and raising the fee; both are refused.

**The escape hatch is keyed by label.** The router is depositor of record, so `rescue`
returns ragequit to the recipient, routed by `(pool, label)` so it survives a partial spend —
the Phase 2 escrow bug, deliberately not repeated. Tested after a partial spend.

## Open risks that are decisions, not defects

- **A transfer links two notes to each other.** The withdrawn and deposited amounts are both
  public and differ only by fees. The notes are not linked to either *user* unless the sender's
  note already was — but a wallet should not transfer the exact amount of its own public deposit.
- **A transfer is not free.** The pool's vetting fee applies to the deposit side, on every hop.
- **The ASP needs a policy for router deposits.** Every transferred note is deposited by the
  router, so private withdrawal of it needs the ASP to approve a router-made label. The natural
  rule is to approve it when the withdrawal that funded it came from an approved label — the
  same open decision the yield router raised.
- **The rescue recipient is public.** A wallet should use a fresh address.
- **A ticket reveals that a user expects a payment.** It holds no secret, but treat it like an
  invoice rather than a public address.
- **The envelope's delivery channel sees metadata.** Delivered through the vault, its operator
  learns that *some* party delivered *something* to a given recipient subject, and when.

## What has not been done

- ~~No run against real proofs yet.~~ **Done.** `examples/shielded-transfer.ts` runs the whole
  flow on a mainnet fork against upstream's own ETH pool, with real groth16 proofs: Alice's
  transfer is accepted through the router, and Bob then proves a withdrawal of the note he
  received to an address with no history, which the real verifier accepts and pays in full.
  Nothing Alice holds rebuilds Bob's commitment, so no valid proof can exist for her.
- No external audit.
- Rev. 2 Phase 4's other items — per-user daily caps, accounting exports and the dashboard —
  are not built.
