# Delta-neutral yield on Hyperliquid (task 3.3)

Status: contracts and keeper built and tested against a simulated HyperCore and against real
HyperEVM read data. **Not deployed anywhere, not audited, and not connected to the shielded
vault.** Connecting it is a decision for the client, set out at the end of this document.

Sections 1 to 10 are the Hyperliquid-specific vault. **No venue has been chosen**: sections 11 and 12
are the venue-neutral sleeve (a risk engine, a venue interface, per-asset sub-wallets, and a test-only
simulated venue for Sepolia), for which Hyperliquid is one optional adapter among others.

```
contracts/hyperliquid/HyperCore.sol                   precompile reads + CoreWriter actions
contracts/hyperliquid/HyperCoreDeltaNeutralVault.sol  the product: shares, exits, roles, gates, governance
contracts/hyperliquid/DeltaNeutralStrategy.sol        linked library: book, next step, orders, funding
contracts/hyperliquid/IDeltaNeutral.sol               shared types, events, errors
contracts/test/HyperCoreDeltaNeutralVault.t.sol       bounds, breakers, keeper-offline exit
contracts/test/HyperCoreContractSize.t.sol            EIP-170/3860 sizes; the library runs only as the vault
contracts/test/utils/HyperCoreSim.sol                 HyperCore stand-in etched at the real addresses
contracts/test/HyperCoreReadFork.t.sol                the ABI decoded against live HyperEVM
packages/yield/src/hl-keeper.ts, src/bin/hl-keeper.ts the keeper
packages/yield/src/delta-neutral.ts                   backtest + the on-chain breaker, modelled
packages/ops/flux/hl-keeper.json                      Flux spec
```

## 1. What it is

An Ethena-style carry: long the spot asset on HyperCore, short the same size of its perpetual.
Price moves cancel; what is left is funding (paid to shorts while positive) less fees.

The earlier design stopped at a backtest because "running it needs collateral on Hyperliquid and
keys to trade it, which means custody outside the pool". This design removes the trading key:

- **The contract is the account.** `HyperCoreDeltaNeutralVault` holds USDC on HyperEVM and, as its
  own address, balances and positions on HyperCore. The only thing that moves them is the contract
  calling CoreWriter. There is no API wallet and no agent key.
- **The keeper chooses when, never what.** The keeper role can call `rebalance()` and `harvest()`,
  both argument-free. Every order is computed inside the contract from HyperCore precompile reads
  and bounded there.
- **Exits do not need the keeper.** `requestRedeem`, `processExits`, `claim` and `deleverage` are
  open to anyone.

It is still custody outside the Ethereum pool: the funds sit on Hyperliquid's chain, under its
validators (section 6).

## 2. Verified HyperEVM / HyperCore facts

Every value below was taken from Hyperliquid's documentation or code, then checked read-only
against mainnet. No transaction was sent.

Short names for the sources used in the table (all under `hyperliquid.gitbook.io/hyperliquid-docs/`):
- **[IHC]** `for-developers/hyperevm/interacting-with-hypercore`, including its `L1Read.sol` and
  `CoreWriter.sol` attachments
- **[TIMING]** `for-developers/hyperevm/interaction-timings`
- **[XFER]** `for-developers/hyperevm/hypercore-less-than-greater-than-hyperevm-transfers`
- **[CDW]** Circle's `developers.circle.com/cctp/references/coredepositwallet-contract-interface`

| Fact | Value | Source |
|---|---|---|
| CoreWriter | `0x3333…3333`, `sendRawAction(bytes)`; emits `RawAction(address indexed user, bytes data)`; deployed code is 544 bytes and does nothing but loop and emit | [IHC]; `eth_getCode` |
| Action encoding | `abi.encodePacked(uint8(1), uint24(actionId), abi.encode(...))` | [IHC]; matches live CoreDepositWallet logs (`01 00000d …`) |
| Limit order (id 1) | `(uint32 asset, bool isBuy, uint64 limitPx, uint64 sz, bool reduceOnly, uint8 tif, uint128 cloid)`; tif 3 = IOC; px and sz are ×10⁸ of the human value | [IHC] |
| USD class transfer (id 7) | `(uint64 ntl, bool toPerp)` | [IHC] |
| Send asset (id 13) | `(address dest, address subAccount, uint32 srcDex, uint32 dstDex, uint64 token, uint64 wei)`; `uint32.max` = spot | [IHC] |
| Asset ids | perp = index in `meta.universe` (BTC 0, ETH 1, HYPE 159); spot = 10000 + spot index | `api/asset-ids`; info API |
| Read precompiles | position `0x800`, spotBalance `0x801`, withdrawable `0x803`, markPx `0x806`, oraclePx `0x807`, spotPx `0x808`, perpAssetInfo `0x80a`, spotInfo `0x80b`, tokenInfo `0x80C`, bbo `0x80e`, accountMarginSummary `0x80F`, coreUserExists `0x810` | `L1Read.sol` |
| Price units | perp: human = raw / 10^(6 − szDecimals); spot: human = raw / 10^(8 − base szDecimals) | [IHC]; checked on mainnet: `oraclePx(1)` = 250990 → $2509.90 |
| USD units | accountMarginSummary, withdrawable, entryNtl: 1e6. USDC spot balance: 1e8 | mainnet reads vs info API |
| Tick and lot | ≤ 5 significant figures; ≤ 6 − szDecimals decimals (perps), 8 − szDecimals (spot); integer prices always allowed | `api/tick-and-lot-size` |
| USDC in | Circle's CoreDepositWallet `0x6B9E773128f453f5c2C60935Ee2DE2CBc5390A24`: `deposit(amount, dex)`, where 0 = perps and `uint32.max` = spot. `tokenInfo(0).evmContract` returns it. Tokens sent to it directly are lost. A new HyperCore account costs 1 USDC | [CDW]; `tokenInfo(0)` |
| USDC out | `sendAsset` to the system address `0x2000…0000`. Credited by a system transaction in the next EVM block. Gas is paid in HYPE from the sender's HyperCore spot balance | [XFER] |
| Timing | after an EVM block: EVM→Core transfers, then CoreWriter actions. Reads reflect HyperCore as of block construction. Orders are "delayed onchain for a few seconds" | [TIMING], [IHC] |
| Silent failure | HyperCore validates actions after the block. A rejected action leaves no EVM trace. An account that does not exist before the block cannot act | [TIMING], `api/activation-gas-fee` |
| Invalid read | consumes all gas passed to the call | [IHC]; observed `PrecompileError` |
| Funding | hourly, `F/8` where `F = premium + clamp(0.01% − premium, −0.05%, 0.05%)`; no precompile exposes it | `trading/funding` |
| Markets checked | ETH perp: szDecimals 4, max 25×. HYPE perp: 159, max 10×. UETH spot: @151, token 221, szDecimals 4, weiDecimals **9**. HYPE spot: @107, token 150, weiDecimals 8 | info API `meta` / `spotMeta` |

**Live check.** `contracts/test/HyperCoreReadForkTest` repeats this against `https://rpc.hyperliquid.xyz/evm`.
It sends each read as a raw `eth_call` and decodes the result with the library's own structs. It
passed on 2026-09-13 with ETH at $2,506.90. A local fork cannot run the precompiles, which are
native code in the node, so the test calls the live RPC instead.

## 3. How the contract trades

**Target.** Deployable capital is equity less claims and the HyperEVM buffer (`idleBufferBps`). At
target leverage L, a short of notional S needs S of spot and S/L of margin, so
`S = deployable × L / (L + 1)`.

**One step per keeper call, most urgent first.** Each step is re-derived from reads, never from
what the contract last sent.

0. No HyperCore account yet: bridge a little USDC. An action from a non-existent account is rejected.
1. A long perp position (never intended): close it, reduce-only.
2. Delta outside `deltaToleranceBps`. Too little short: sell perp, if exposure may grow and margin
   allows; otherwise sell spot. Too little spot: buy back short, reduce-only. It never buys spot to
   chase delta, because that could spend USDC owed to exits.
3. Leverage above `maxLeverageBps`: top up margin from spot USDC, else shrink both legs.
4. More exposure than target (unwinding, or equity fell): shrink both legs.
5. HyperEVM buffer low: bridge spot USDC back, or release margin above the hard cap.
6. Below target, and adding is allowed: fund margin, then spot USDC, then both IOC orders in one call.

**Every order** is IOC and priced `slippageBps` through the oracle (perp) or the spot price. Spot
trades only while spot is within `maxSpotDeviationBps` of the oracle. Buys round the tick down and
sells round it up, so rounding never widens the band. Sizes round down to the lot. Each order is at
most `maxOrderNotional` and is charged to `maxDailyTurnover`.

**Asynchrony.** Every call that acts, and every NAV-priced call (`deposit`, `requestRedeem`,
`checkpoint`), waits `settleSeconds` after the last action. `totalAssets()` can omit value that is
still in flight inside that window, but nothing priced runs there.
`test_NothingPricedRunsWhileActionsAreInFlight` checks this.

**Share pricing (client audit M-01, 21 Oct 2026).** NAV values the spot leg at the lower of the spot
price and the perp oracle. Before the fix nothing stopped a deposit priced off a spot price pushed
down on a thin book, so shares could be bought cheap. Now:

- `deposit`, `requestRedeem` and `checkpoint` revert `SpotOffOracle` while spot is more than
  `maxSpotDeviationBps` from the oracle. The keeper's `harvest` skips the breaker update instead of
  reverting, so a skewed book neither moves the high-water mark nor trips the breaker.
- `maxSpotDeviationBps` is 50 to 500 bps. Zero ("no band") is not a valid setting.
- Shares minted by a deposit are locked to their holder for `MIN_HOLD` (1 day). Locked shares can be
  neither redeemed nor transferred (the ERC-20 `_update` hook), so a transfer to a fresh address does
  not skip the hold. A deposit made for someone else locks only the shares it minted to them.

Inside the band a skew can still move the share price by at most the band times the spot leg's
share of NAV. The deposit then waits a day and pays `exitFeeBps` on the way out.
`test_BuyingSharesCheapOnADepressedSpotPriceDoesNotPay` measures a 1% skew on a $300k deposit at
$300 (0.1%).

**No half-closed hedge (M-05).** Shrinking both legs while spot is outside the band used to sell no
spot and still buy back the short, which left the vault long. Now the short bought back is at most
the spot sold with it, plus any short that is already unhedged. Off the band, with no excess short,
nothing is sent: the keeper's step and `deleverage()` do nothing (or revert `NothingToDo`), and
`processExits()` reverts `NothingToDo` once only a trade is left. It resumes when spot is back.

## 4. Bounds, and what a compromised keeper can do

Suggested launch parameters, with the Foundry test defaults in brackets where they differ:

| Parameter | Launch | Why |
|---|---|---|
| `targetLeverageBps` / `maxLeverageBps` | 2× / 3× | ETH liquidates a 2× short at +47% (backtest model); at most half the venue's max is enforced on-chain |
| `slippageBps` | 30 | band around the oracle |
| `maxOrderNotional` | $25,000 [$50,000] | per order, per leg |
| `maxDailyTurnover` | $200,000 [$2,000,000] | keeper-placed notional per 24h |
| `minActionInterval` / `settleSeconds` | 60 s / 5 s | pace, and time for actions to land; on-chain caps 1 day / 2 to 60 s |
| `deltaToleranceBps` / `maxSpotDeviationBps` | 200 / 100 | `maxSpotDeviationBps` 50 to 500 on-chain; `slippageBps` at least 10 |
| `idleBufferBps` / `exitFeeBps` | 1000 / 20 | instant exits; the fee pays for the unwind an exit causes |
| `fundingPauseE8` / `fundingUnwindE8` / `fundingTau` | 0 / −1141 (−10% APR) / 84 h | section 5 |
| `maxDrawdownBps` | 300 | |
| `depositCap` | $1,000,000 | |

**Worst case per keeper call.** At most two orders, one per leg, each at most `maxOrderNotional`.
Each fills at worst at the edge of the band and pays the taker fee: perps 4.5 bps, spot 7 bps at the
base tier (`trading/fees`).

- Formula: `2 × maxOrderNotional × (slippageBps + 7 bps)`
- At launch parameters: 2 × $25,000 × 0.37% = **$185 per call**.

**Worst case per day.** The turnover cap binds long before the rate limit does: at $25,000 per
order, the $200,000 budget is spent in four calls.

- Formula: `maxDailyTurnover × (slippageBps + 7 bps)`
- At launch parameters: $200,000 × 0.37% = **$740 per day, 0.074% of a full $1M vault**.
- A fixed 24h window allows twice that across a window boundary: $1,480 in any 24 hours.
- The guardian ends it immediately with `pauseExposure()`. Rotating the key uses `setKeeper`, which
  waits out the governance delay.

**Measured.** `test_ACompromisedKeeperFillingAtTheBandEdgeIsBoundedByTurnover` makes every fill
land exactly at its limit, as a keeper colluding with the only maker would arrange. With a $250,000
budget the keeper was stopped by `TurnoverExhausted`, and the vault lost $525.93, under the
$926 bound.

**What the keeper cannot do.**
- choose a price, a size or a direction;
- trade outside the band, or trade spot while it is off the oracle;
- raise leverage past the cap;
- spend USDC owed to claims (no new exposure while any claim is unfunded; tested);
- block exits (anyone can process them);
- pause or change anything.

**Also bounded.** `deleverage()` and `processExits()` are open to anyone, but they only reduce risk
or fund recorded claims, and every order they place uses the same band and size cap.

**Exit-path parameters never change at once (M-04).** `slippageBps`, `maxSpotDeviationBps`,
`settleSeconds`, `exitFeeBps` and `maxOrderNotional` are all read by `requestRedeem`,
`processExits` or `deleverage`. ANY change to one of them waits out the governance delay, in either
direction, because each is risky both ways:

- `exitFeeBps` up costs the holders who exit; down costs the holders who stay;
- `settleSeconds` up delays exits; down prices shares on value still in flight;
- `maxSpotDeviationBps` down blocks redemptions sooner; up gives a skew more room;
- `slippageBps` down can stop exit and deleverage orders filling; up loosens the keeper;
- `maxOrderNotional` down makes `processExits` crawl; up lets the keeper place bigger orders.

Other tightenings stay instant: turnover, leverage, tolerance, deposit cap, funding floors. Lengthening
`minActionInterval` is instant too, up to its one-day cap: it paces only the keeper, and no exit needs
the keeper. `test_EveryExitPathChangeWaits` and `test_ExitPathParamsHaveFloorsAndCaps` check this.

**The library split changes none of these bounds** (section 10). The numbers above were re-measured
after the split and are identical: the same $525.93 loss under the same forced fills, and the same
17 `processExits` steps for the keeper-offline exit.

## 5. Breakers

**Funding.** No precompile exposes funding, so the contract estimates it:

1. It reads best bid, best ask and the oracle.
2. It computes the premium as `(max(bid − oracle, 0) − max(oracle − ask, 0)) / oracle`, clamped to ±5% per sample.
3. It applies Hyperliquid's formula to get an hourly rate.
4. It averages that rate with weight `dt / (tau + dt)`.

Because each sample's weight is the time since the previous one, sampling more often adds precision,
not influence. `test_SpammingSamplesDoesNotAmplifyAManipulatedBook` checks this: a manipulated book
sampled 60 times in one minute leaves the 84-hour average near its resting value.

The thresholds are the ones the backtest validated: a pause floor of 0 and a 7-day window, where an
84-hour EMA is the equivalent of a 168-hour mean. Checked on 180 days of real ETH data
(`npx tsx packages/yield/examples/backtest.ts`, run 2026-09-13):

- The formula reproduces all **4,320** published hourly rates from their published premiums, with a
  maximum error of 5·10⁻¹¹.
- The EMA breaker would have paused for **457 h**; the backtest's trailing 7-day mean flags **450 h**.
  The two disagree in 109 h, mostly around transitions.
- Unwinding (below −10% APR) would have triggered for **11 h**.

**What is approximate.** The venue computes the premium from impact prices sampled every few
seconds; the contract uses best bid/ask, sampled only when called. The formula check above is exact.
How closely on-chain bbo samples track the venue's impact-price premium has **not** been measured.
The keeper compares the venue's published funding with the contract's estimate and reports on
`/status` when they disagree about the pause floor. That comparison is an operator signal only; the
contract does not read it.

**Drawdown.** A fall of `maxDrawdownBps` in the share price closes deposits and new exposure. Only
the governor can `resume()`, which re-bases the high-water mark.

## 6. Exits with the keeper offline

1. `requestRedeem(shares)` prices the shares at NAV less `exitFeeBps`. It pays at once from HyperEVM
   USDC that no earlier claim is owed; otherwise it records a claim. It refuses shares minted less
   than a day ago, and it refuses while spot is off the band (section 3).
2. Anyone calls `processExits()`, one step per settle window:
   - bridge HyperCore spot USDC to HyperEVM;
   - otherwise, move perp margin above the hard-cap requirement to spot;
   - otherwise, close both legs by the shortfall. While spot is off the band this rung sends
     nothing and `processExits` reverts `NothingToDo` (section 3, M-05).
3. Anyone calls `claim(id)`, which pays the receiver.

`test_AFullExitWorksWithTheKeeperOffline` runs this against the simulator. A holder with $300k in a
deployed position exits in **17** `processExits` steps (a $50k order cap). The holder who stays keeps
at least 99.9% of his share price. `deleverage()` protects the margin in a rally with nobody's key.

**Operational dependency.** Bridging USDC to HyperEVM costs HYPE on HyperCore. Anyone can top it up
with `fundCoreGas()`. If the vault's HyperCore HYPE runs out, step 2's first rung is rejected silently
and exits stall until someone funds it. Monitor it.

## 7. What could not be verified

- **End-to-end CoreWriter behaviour.** No transaction was sent, so every action's effect on HyperCore
  is untested: order fills, class transfers, sendAsset. Before any mainnet use this needs a run on
  HyperEVM testnet (chain 998, `https://rpc.hyperliquid-testnet.xyz/evm`).
- **Units of `usdClassTransfer.ntl`.** Assumed 1e6 USD, from hyper-evm-lib
  (`github.com/hyperliquid-dev/hyper-evm-lib`, by Obsidian, not Hyperliquid). The docs do not say.
- **Spot order `sz` scaling.** The docs say ×10⁸ for all orders; this has not been exercised on spot.
- **Timing.** The exact order delay, whether cancels are delayed, and the HYPE cost of HyperCore→EVM
  transfers at real base fees.
- **Account abstraction.** CoreWriter action 16 can switch an account to unified or portfolio margin.
  The contract never sends it and assumes separate spot and perp balances; the default for a new
  contract account is unverified.
- **Venue behaviour** outside the model: auto-deleveraging of profitable shorts, and liquidation
  mechanics at the venue's margin tiers.
- **The simulator** (`HyperCoreSim.sol`) encodes the documented rules but is not HyperCore.

## 8. Choosing the asset

| Pair | Spot leg custody | Notes |
|---|---|---|
| ETH perp (1) + UETH spot (@151) | UETH is Unit-bridged ETH: a 2-of-3 MPC guardian set (`docs.hyperunit.xyz/architecture/guardian-network`) | deepest perp; matches the backtest |
| HYPE perp (159) + HYPE spot (@107) | native to HyperCore | perp max 10×, so `maxLeverageBps` ≤ 5×; higher volatility and funding |

The contract takes the perp index and spot market as constructor arguments. It reads szDecimals,
weiDecimals and the quote token from HyperCore at deployment and refuses a spot market that is not
quoted in USDC.

## 9. The bridge, and the decision the client has to make

The client requirement reads: "all funds live in immutable Ethereum contracts; if any service dies
or is compromised, no user loses funds or access". **This product cannot meet that as long as its
funds are on Hyperliquid**, and no L1 adapter was built into the shielded `YieldVault`, deliberately.

**What a user would have to trust to move funds there.**

- **Circle CCTP V2** (Ethereum domain 0 → HyperEVM domain 19), then CoreDepositWallet into HyperCore:
  - Circle's attestation service;
  - Circle's upgradeable, pausable contracts: CoreDepositWallet has owner, pauser and rescuer roles,
    and USDC has a blacklist.
- **HyperBFT consensus.** HyperCore's state, including the vault's balances and positions, is what
  Hyperliquid's validators say it is:
  - more than two thirds of stake;
  - the active set is the top 27 validators by stake;
  - no automatic slashing (`hypercore/staking`).
- **The legacy Arbitrum bridge** (Bridge2, `0x2df1c51e…3df7`), if used:
  - withdrawals are signed by a **4-key** hot validator set (3 of 4 by power), not the full consensus set;
  - a 200-second dispute period, during which lockers can pause;
  - read on Arbitrum at block 504,832,412.
- **For ETH exposure via UETH:** Unit's guardian set.
- **The venue itself:** its oracle, matching, liquidation and auto-deleveraging.

**Why an adapter under the shielded vault is not a small step.**
- `YieldVault.totalAssets()` would have to count funds on another chain. Ethereum cannot read
  HyperEVM state trustlessly, so the valuation would come from an attestor or oracle quorum, a new
  service whose compromise could misprice every shielded share.
- Exits would take minutes to hours through CCTP rather than one transaction, and `maxWithdraw`
  would have to report that.
- Every movement between the vault and Hyperliquid is a public bridge transfer. It carries no user
  identity, but it publishes the aggregate flow.

**The options.**

1. **Keep it separate** (recommended until the client decides). The delta-neutral vault is its own
   HyperEVM product. A user who wants it moves funds out of the shielded pool, in the open, and
   accepts the trust list above. The shielded vault's guarantees are unchanged.
2. **Connect through a bridge adapter.** Accept CCTP + HyperBFT + an attested NAV for that slice of
   the shielded vault. Cap its allocation, and set `GOVERNANCE_DELAY` above the bridge's worst exit
   time. The availability invariant would then be false for that slice, and should be stated as
   false.
3. **Do not offer delta-neutral yield.** Ship T-bills (USTB) and staking only.

Whichever the client chooses, the contracts here do not change: they are the HyperEVM half of
options 1 and 2.

## 10. Contract size, the library split, and deploying it

**The problem.** As one contract, `HyperCoreDeltaNeutralVault` was 29,025 bytes of runtime code,
4,449 over EIP-170's 24,576. It could not be deployed on HyperEVM or any other EVM chain.
`forge test` does not enforce the limit, so the whole suite passed. Compiler settings were not
enough: it was still 24,684 bytes at `optimizer_runs = 1`, and 25,399 with via-IR.

**The split.** The HyperCore half moved into `DeltaNeutralStrategy`, an external library with
`public` functions, linked into the vault and reached by DELEGATECALL:

- **The library** reads the book, decides the next step, prices and sends orders, and estimates
  funding.
- **The vault** keeps everything else: the share token, deposits, `requestRedeem`, claims and
  `claim`, every role check, the reentrancy guard, the settle and rate-limit gates, the drawdown
  breaker and governance. It runs all of those first, then delegates.

**Why a linked library and not two contracts.** The size limit is a deployment constraint, not a
security boundary, so the split was chosen to add none.

| | Linked library (chosen) | Two contracts (shares / strategy) |
|---|---|---|
| HyperCore accounts | one: the library runs as the vault | two, or USDC shuttled between them |
| NAV | one book read | a sum across contracts |
| New interface to secure | none | a privileged vault↔strategy interface that moves USDC |
| Reentrancy guard | one | two, plus calls between them |
| Can the logic be swapped? | no: its address is in the vault's bytecode | depends on how the link is governed |
| What the logic can touch | one storage struct, `IDeltaNeutral.State` | its own storage and whatever the interface allows |

An internal library would not have helped: its code is inlined into the vault, so the size stays.

**Properties that still hold**, each checked by a test:

- **The keeper still only triggers bounded actions.** The keeper and anyone-may entry points are
  still the vault's, with the same modifiers and gates. The strategy code is unchanged in what it
  decides. All 18 vault tests pass without weakened assertions; only error and struct names now
  come from `IDeltaNeutral`, with the same selectors.
- **Nobody can drive the library directly.** Solc guards a library's state-changing functions so
  they revert unless DELEGATECALLed. A contract that does DELEGATECALL them acts on its own storage
  and its own HyperCore account. `test_TheStrategyLibraryCannotBeCalledDirectly` calls each entry
  point directly and gets the guard's empty revert. The same call to a view function succeeds, so
  the revert is the guard's and not a malformed call.
- **The strategy acts as the vault.** `test_TheStrategyActsAsTheVaultItself` checks that the
  strategy's events come from the vault's address, and that CoreWriter's `RawAction` records the
  vault as its user.
- **Governance and breakers are unchanged.** `setParams` still classifies a change as riskier
  through the same comparison, now `DeltaNeutralStrategy.riskier`, before `_authorizeChange`.
  There is no function to change the library.

**Sizes** at the repository's settings (solc 0.8.28, optimizer 1,000 runs), from
`forge build --sizes` and `HyperCoreContractSizeTest`, after the 21 October review fixes:

| Contract | Runtime (bytes) | Headroom under 24,576 | Initcode (bytes) |
|---|---|---|---|
| `HyperCoreDeltaNeutralVault` | 16,836 | 7,740 | 20,517 (21,477 with constructor args) |
| `DeltaNeutralStrategy` | 16,517 | 8,059 | 16,569 |
| `KeeperGate` (L1) | 5,361 | 19,215 | 5,853 |
| `SuperstateUSTBAdapter` (L1) | 9,983 | 14,593 | 12,815 |

`HyperCoreContractSizeTest` runs inside `forge test` and fails if any of these goes over EIP-170 or
EIP-3860. For the vault it measures the runtime code as deployed, with immutables filled in, and
the creation code with real constructor arguments. CI's `forge build --sizes` step covers every
other contract.

**Deploying.** No transaction has been sent; these are the steps the tooling requires.

1. **Use big blocks.** HyperEVM's fast blocks carry 3M gas and its slow blocks 30M
   (`for-developers/hyperevm/dual-block-architecture`). Deploying ~17–20 KB of code needs more than
   3M, so the deployer must first send the HyperCore action
   `{"type": "evmUserModify", "usingBigBlocks": true}`. That needs an existing HyperCore account.
   Unset it afterwards so keeper transactions go back to fast blocks. A keeper call is a handful of
   precompile reads and at most two CoreWriter actions, well inside 3M.
2. **Deploy the library, then the vault linked against it.**
   - `forge script` deploys and links the library automatically.
   - With `forge create`:
     ```bash
     forge create contracts/hyperliquid/DeltaNeutralStrategy.sol:DeltaNeutralStrategy \
       --rpc-url $HYPEREVM_RPC --private-key $DEPLOYER_KEY
     forge create contracts/hyperliquid/HyperCoreDeltaNeutralVault.sol:HyperCoreDeltaNeutralVault \
       --libraries contracts/hyperliquid/DeltaNeutralStrategy.sol:DeltaNeutralStrategy:<library address> \
       --constructor-args ... --rpc-url $HYPEREVM_RPC --private-key $DEPLOYER_KEY
     ```
   - Verify the vault with the same `--libraries` value.
   - Anyone checking a deployment should confirm that the address linked into the vault's bytecode
     is the verified `DeltaNeutralStrategy`.
3. **Then the usual setup:** fund the vault's HyperCore gas with `fundCoreGas()`, check the
   parameters, and call `completeSetup()`.

## 11. Venue-neutral risk engine

Status: built and tested against a simulated venue, against the HyperCore read path (decoding checked
with fixtures and once, read-only, against live HyperEVM), and against real Hyperliquid history. It
plans actions and sends none. No keeper executes it in production. Its venue readers are the
Hyperliquid one and, since section 12, `onchain-venue.ts` for any `IHedgeVenue` contract and its
`HedgeSubWallet` accounts.

**What it is for.** Task B6 runs the carry as Mova's hedge sleeve: segregated yield sub-wallets, traded by a
trade-only keeper. **Since the principal-locked reserve (client rule, 21 October 2026) the sleeve is Mova's own
capital**: the reserve has no hedge path any more (its USDT leaves only by redemption, and yield only by
`harvestYield` to Mova's `yieldRecipient`), so the hedge-treasury Safe is funded by Mova directly. The yield is Mova's.
The venue is not chosen yet, so the risk layer must not depend on one.

```
packages/yield/src/hedge-risk/types.ts              snapshot types; HedgeVenue (reads + abstract order primitives)
packages/yield/src/hedge-risk/config.ts             RiskLimits: defaults, validation, vaultBoundGaps()
packages/yield/src/hedge-risk/funding.ts            smoothed funding, N-period exit, re-entry hysteresis
packages/yield/src/hedge-risk/engine.ts             evaluateSleeve(): findings, ordered plan, permissions
packages/yield/src/hedge-risk/snapshot.ts           collectSnapshot(): parallel reads, timeouts, fail closed
packages/yield/src/hedge-risk/hyperliquid-venue.ts  HedgeVenue over the HyperCore precompiles + info API
packages/yield/src/hedge-risk/onchain-venue.ts      HedgeVenue over an IHedgeVenue contract + its HedgeSubWallets (section 12)
packages/yield/src/hedge-risk/sim-venue.ts          in-memory venue for tests and replays
packages/yield/src/hedge-risk/keeper.ts             reference executor of a plan (tests and replay only)
packages/yield/src/hedge-risk/replay.ts             history through engine + keeper
packages/yield/examples/hedge-risk-backtest.ts      the replay on real Hyperliquid data
packages/ops/src/hedge-risk.ts                      the `hedge_risk` monitor check and its /status JSON
```

**How it works.** `evaluateSleeve(snapshot, limits, memory)` is a pure function. Its input is one
snapshot of every sub-wallet: legs, prices, margin, funding, venue health, plus optional independent
reference prices. (It no longer reads the reserve: the sleeve is not reserve money.) The only state it
carries is the funding regime per venue and asset. It returns:

- **findings**: one per limit and scope, each `ok`, `warn` or `fail`, with a utilisation (1 = at the
  fail bound);
- **the worst finding**: highest level, then highest utilisation;
- **an ordered plan**: halt, unwind, add-margin, reduce, rebalance. Halting is free. An unwind
  supersedes any reduce or rebalance on the same position. Moving margin needs no trade. Reducing
  comes before re-hedging, so the delta fix is sized on the smaller book. Within a kind the order is
  fail before warn, then utilisation, then scope, so the plan is deterministic;
- **permissions**: per sub-wallet and asset, whether a keeper may add exposure, why not, and the
  allocation headroom.

A venue that throws, times out, returns stale data or prices off its oracle is never read as an empty
book, which would look hedged. It fails closed: the engine halts it, and the whole sleeve too when
its size is unknown.

**The limits, defaults and on-chain twins.** All limits live in `RiskLimits` (`config.ts`), each
documented where it is declared. `resolveRiskLimits` merges a partial config over the defaults and
reports every problem at once, unknown keys included.

| Limit | Default | Breach plans | On Hyperliquid's vault |
|---|---|---|---|
| `delta.toleranceBps` / `hardBps` | 200 / 1000 bps of the larger leg; ignored under $1,000 | rebalance: sell spot, or buy back the short reduce-only; never buy spot | `deltaToleranceBps` 200 |
| `margin.targetLeverage` / `warnLeverage` / `maxLeverage` | 2x / 2.5x / 3x | add idle cash to margin, then reduce both legs to the leverage that every breached limit allows (warn: routine; fail: urgent) | `targetLeverageBps` 2x, `maxLeverageBps` 3x (`deleverage()` opens above it) |
| `margin.warnMarginRatio` / `minMarginRatio` | 4 / 2.5 times maintenance | same remedy | maintenance = 1 / (2 x venue max leverage) |
| `liquidation.warnDistanceBps` / `minDistanceBps` | 3000 / 2000 bps (a 2x short liquidates at +47%, 3x at +31%) | same remedy; uses the venue's liquidation price when reported, else derives it | - |
| `funding.smoothingWindowHours` | 168 (the backtest's 7-day mean) | - | `fundingTau` 84 h EMA |
| `funding.pauseBelowAprBps` | 0: add nothing | - | `fundingPauseE8` 0 |
| `funding.adverseExitPeriods` | 168 periods below the pause floor: exit | unwind | - |
| `funding.exitBelowAprBps` | -10% APR smoothed: exit at once | unwind | `fundingUnwindE8` -1141 |
| `funding.predictedExitFloorAprBps` | -100% APR predicted: exit at once | unwind | none (no precompile exposes funding) |
| `funding.reentryAboveAprBps` / `reentryPeriods` / `reentryCooldownHours` | +3% APR for 24 periods, and 48 h out | - | - |
| `basis.warnBps` / `haltBps` | 50 / 100 bps of mark or spot from the index | halt the asset there; never unwind into a dislocated book | `maxSpotDeviationBps` 100 |
| `health.maxDataAgeSeconds` / `maxPriceAgeSeconds` | 120 / 120 s | fail closed: halt the venue | `settleSeconds` (reads are as of the block) |
| `health.maxOracleDeviationBps` | 150 bps from the reference price | fail closed | - |
| `health.unwindOnFailClosed` | false | also unwind a failed venue | - |
| `allocation.maxSleeveUsd` | $1,000,000 | same | `depositCap` |
| `allocation.defaultVenueMaxUsd` / `defaultAssetMaxUsd` | $500,000 per venue / $1,000,000 gross per asset | same, per scope | - |

`vaultBoundGaps(limits, vaultParams, venueMaxLeverage)` lists every limit looser than its on-chain
twin. The off-chain layer should alarm before the contract refuses. The defaults give an empty list
against the launch parameters in section 4. Two differences from the contract:

- The allocation limits are all absolute (`maxSleeveUsd`, per venue, per asset). The former
  `allocation.reserveShareBps` (a share of the reserve's USDT, from its `hedgeLimitBps`) was removed with the reserve's
  hedge path, and a config that still sets it is refused with that reason.
- The vault estimates funding from the book. The engine reads the venue's published history and
  predicted rate, so on Hyperliquid the two can disagree; `hl-keeper.ts` already reports when they do.

**Monitoring.** `HEDGE_RISK_CONFIG` (a JSON file: limits, venues, sub-wallets, optional `reserve` and
Chainlink `referenceFeeds`) makes the monitor run `hedge_risk` every sweep:

- **ok**: names the limit closest to its bound;
- **warn**: a limit past its warn bound, a funding exit in progress, or the reserve unverifiable;
- **fail**: a limit past its fail bound, or a venue that is unreachable, stale or off its oracle. A
  venue the monitor cannot reach counts as a fail, because the keeper would halt on it too;
- **unknown**: the sweep itself broke.

The value and threshold are the worst limit's. `HEDGE_RISK_STATUS_PORT` serves the JSON summary on
`/status`: breaches, the ordered plan, permissions and per-wallet metrics. Hyperliquid sub-wallets
are read on `HYPEREVM_RPC_URL`; `onchain-perps` venues (section 12) on the monitor's own `RPC_URL`.
Other venue kinds are refused until they have a reader.

**What the defaults would have done.** `npx tsx packages/yield/examples/hedge-risk-backtest.ts 180`,
run 2026-10-16 on real ETH data (4,320 hours, 2026-04-19 to 2026-10-16, ETH 2,279 → 2,413). One
sub-wallet held $400k at 2x, with an hourly keeper and base-tier fees:

| | APR | funding | fees | hours hedged | exits | reduces | gap liquidations | min liq. distance | max leverage |
|---|---|---|---|---|---|---|---|---|---|
| default limits | 4.26% | $9,863 | $1,540 | 4,010 | 1 | 12 | 0 | 2,979 bps | 3.09x |
| baseline: never exit on funding | 4.68% | $10,058 | $925 | 4,320 | 0 | 12 | 0 | 2,979 bps | 3.09x |

- **Health.** The verdict was ok for 4,307 hours, warn for 12 and fail for 1. The fail hour was a
  +5.9% one-hour rally (2026-08-19, 2.49x to 3.09x), reduced in the same hour.
- **The one exit** fired at the start: smoothed funding was -10.09% APR, the vault's own unwind rule.
  The sleeve re-entered 13 days later.
- **Over the longest window the API allows** (5,000 hourly candles, about 208 days), the result was
  3.68% APR against 3.99% for the baseline.
- **Funding alone over two years** (17,227 hours from 2024-10-29): the defaults exit 6 times and spend
  1,427 hours out.
  - Funding in those hours was net POSITIVE, +17 bps of notional, against about 138 bps of round-trip
    fees.
  - Exiting only below -10% APR smoothed (the vault's rule) exits 2 times.
  - The first candidate defaults (24-period exit, -30% APR predicted floor, +5% re-entry) exited 18
    times. That churn is why the shipped defaults are slower.
- **Conclusion.** On this history ETH funding mean-reverted faster than any exit rule paid for. The
  funding exits are tail insurance against a sustained negative regime, and on this data they cost
  0.3-0.4% APR. Whether to pay that is the client's call; the engine makes it one config change.

**Not modelled.** Margin tiers and auto-deleveraging; the venue's real predicted rate (the replay uses
the next hour's realised rate); basis (no history exists, so the replay uses mark = index = spot);
cross-venue transfer time.

## 12. The venue-neutral hedge sleeve on-chain (next milestone B2-B5, B7)

Status: built, tested, and rehearsed end to end on an anvil fork of Sepolia against the live MOVVA-only
rail and its live custody Safes. **Deployed on Sepolia on 20 October 2026** on the final reserve, against the
test-only simulator: `SimHedgeVenue` `0x0956f02fb0d74795f33d0ff68b063b727474b33b` and ETH `HedgeSubWallet`
`0x0121fe4ca2f134d0246d65d9b5a9073bd7eb58a1`, both Etherscan-verified
(`deployments/sepolia-final-hedge-sleeve.json`, `docs/audit-freeze.md`). The 17 October deployment
(`SimHedgeVenue` `0x2eeacd0d4b690748d30fd608347d232825dd0d12`, `HedgeSubWallet`
`0xef351ee80fdc6a84aec78cbaa2de2354f45b9b5e`) is **superseded** by it. It was never funded, and nothing
should point at it. **Not audited**, and **no venue is chosen**.

**The deployed `0x0121fe4c…` runs the 20 October code.** It does not have the 21 October review fixes
(section 12.1: floors and delayed exit-path changes, a delayed `resume()`, paired-fill checks). Those
need a new `HedgeSubWallet`. The sub-wallet's code is immutable and its venue is fixed at deployment. On Sepolia the venue is `SimHedgeVenue`, a simulator we control;
Hyperliquid stays what section 1 to 10 describe, one optional venue with its own vault.

```
contracts/hedge/IHedgeVenue.sol            the venue interface a real venue's adapter implements (+ IHedgePriceFeed)
contracts/hedge/HedgeSubWallet.sol         B2/B3: one segregated sub-wallet per asset and venue, trade-only keeper
contracts/hedge/SimHedgeVenue.sol          TEST ONLY: simulated spot + perps venue for Sepolia; refuses mainnets
contracts/test/HedgeSubWallet.t.sol        bounds, adversarial keeper / operator / venue, liquidation, keeper-free exit
contracts/test/SimHedgeVenue.t.sol         the simulator's mechanics and its operator's bounds
contracts/test/HedgeSleeveInvariant.t.sol  invariants under every role's actions in any order
packages/yield/src/hedge-risk/onchain-venue.ts  HedgeVenue over RPC for IHedgeVenue + HedgeSubWallet (read-only)
packages/ops/src/hedge-risk.ts             `hedge_risk` gains the `onchain-perps` venue kind
packages/ops/src/hedge-sleeve.ts           B5: each funding-path step as a Safe transaction (plans + executor)
packages/ops/src/bin/hedge-sleeve.ts       B5: the CLI, dry run by default (`--execute --confirm`)
scripts/deploy-hedge-sleeve.ts             B7: fork rehearsal + Sepolia gas projection; broadcast by name only
scripts/hedge-sleeve-rehearsal.ts          the whole path on a Sepolia fork, every step printed
scripts/hedge-sleeve-lib.ts                shared: env, anvil (ports 8960-8964), config, deployment, fork re-stamping
```

### 12.1 What was built

**`IHedgeVenue`** is the whole of what the sleeve needs from a venue: collateral `deposit` / `withdraw`,
`transferMargin` between cash and the margin account, `buySpot` / `sellSpot` / `increasePerp` /
`reducePerp` each with a limit price, and reads of cash, the spot and perp legs, the margin account
(equity, maintenance, initial, withdrawable), mark / index / spot with their timestamp, the hourly
funding rate and the venue's max leverage. The account is always `msg.sender`, so the sub-wallet
contract IS the venue account and no API or agent key exists. Three rules carry the security:

- **Prices are all-in.** A fill's reported price and its limit include every fee, so the limit bounds
  the whole cost of an order.
- **Reads revert rather than invent zeros.** An unreadable account must never look like an empty,
  perfectly hedged one (the same rule as the off-chain `HedgeVenue`).
- **It is synchronous.** A fill has happened, or not, when the call returns. An asynchronous venue
  needs an adapter that hides that, or a settle window as on `HyperCoreDeltaNeutralVault`.

**`HedgeSubWallet`** is one asset on one venue: long spot, short the same size of the perp.

- **Immutables:** the stablecoin, the venue, the asset, the reference feed, and `TREASURY`, the
  hedge-treasury 2-of-3 Safe.
- **Where money goes:** the stablecoin can only be in this contract, in its venue account, or at
  `TREASURY`. No function takes a recipient, and there is no arbitrary call.
- **The keeper** calls `rebalance()` and `harvest()`, both argument-free. One step per call, most
  urgent first, re-derived from venue reads every time:
  1. close any long perp;
  2. fix delta outside tolerance (never by buying spot);
  3. above max leverage, top up margin, else shrink both legs;
  4. above target, shrink both legs;
  5. below target, add both legs in one call.
- **Every order** is IOC, at most `maxOrderNotional`, at most two per call. Both are charged to the
  `maxWindowTurnover` window before anything leaves the contract.
- **Prices:** every order is limited `slippageBps` through an independent reference feed, not the
  venue's own price. Nothing trades unless the venue's mark, index and spot are each within
  `priceBandBps` of that reference, and both prices are fresh.
- **Funding:** an 84-hour EMA of the venue's reported rate (each sample weighted by the time since the
  last). Below `fundingPauseE8` nothing is added; below `fundingExitE8` the book unwinds.
- **Size:** `allocationCap` caps what the keeper may deploy.
- `harvest()` returns perp margin above target leverage, and the venue's cash, to the sub-wallet.
- Anyone may `deleverage()` above max leverage. The guardian, the governor or the treasury may
  `pauseExposure()` at once.
- **Paired legs fill together (21 Oct review).** `_venueOrder` returns each fill. A step that trades
  both legs (buy spot + open short, or close short + sell spot) reverts whole when the legs' unfilled
  remainders differ by more than `deltaToleranceBps` of the pair. A venue that fills one leg and not
  the other, partially or not at all, cannot leave the book unhedged. `IHedgeVenue` now requires a
  venue to return exactly what filled.
- **Governance (`DelayedGovernance`):** `setParams` waits 48 h when any field loosens a bound
  (`riskier`). Since the 21 October review it also waits when `slippageBps`, `priceBandBps`,
  `maxReferenceAge` or `maxOrderNotional` change in EITHER direction. Tightening those was "instant"
  before, so the governor could switch off the anyone-callable `deleverage()` backstop at once: a 1 bps
  band, a 60 s reference age or 1 bps of slippage can make every call revert. They are also floored even
  for a governor who waits:
  - `slippageBps` >= 10;
  - `priceBandBps` >= `slippageBps` + 20 (`BAND_COST_MARGIN_BPS`, room for the venue's spread and fee);
  - `maxReferenceAge` >= 1 h;
  - `minActionInterval` <= 1 day.

  Every other tightening is still instant. A new keeper waits; `setKeeper(0)` revokes at once.
- **`resume()` is delayed (21 Oct review).** It is scheduled and executed after 48 h, and it cannot
  take effect until the LATEST pause (guardian, governor or the treasury's `unwind`) is 48 h old. So a
  resume scheduled before a new incident cannot lift the new pause early. The reason is the Sepolia key
  layout below: the governor is the keeper's own EOA, and an instant resume would let that one key undo
  the guardian's pause in the next block. A pause only holds or unwinds the book under the keeper's
  bounds, so a slow resume costs forgone funding, never principal.

**The funding path (B5)** is Mova's capital -> hedge Safe -> `fund` (the reserve's `withdrawToHedge` was removed
with the principal-locked reserve, 21 October 2026), and home by `withdrawToTreasury` -> hedge Safe, from where Mova
may `recapitalize` the reserve (that USDT then becomes principal) or keep it. `packages/ops/src/hedge-sleeve.ts` builds
each step from chain reads with its checks. When the role is a contract, it reads it as a Safe (owners,
threshold, nonce) and emits the Safe transaction with its EIP-712 `safeTxHash`. Two calls by one Safe
(approve + fund, approve + recapitalize) are ONE Safe transaction through Safe 1.4.1's canonical
`MultiSendCallOnly`, whose code hash is checked: it can only CALL.

```bash
npm run -w @mova/ops hedge-sleeve -- status
npm run -w @mova/ops hedge-sleeve -- sleeve:fund 20000             # hedge Safe; --json prints a Safe{Wallet} Tx Builder file
npm run -w @mova/ops hedge-sleeve -- sleeve:withdraw all           # hedge Safe; sleeve:unwind first to bring the whole book
npm run -w @mova/ops hedge-sleeve -- reserve:recapitalize 20000    # hedge Safe
# then, to send: --execute --confirm <the subject printed>, with SAFE_SIGNER_KEYS (owners) and SAFE_SUBMITTER_KEY
```

A dry run sends nothing and prints the Safe transaction for its owners, which is the multisig workflow.
`--execute` needs `--confirm <subject>`, checks the chain's own `getTransactionHash` against the hash it
computed, and simulates before sending. `--impersonate` runs on an anvil fork only.

**The risk engine sees the on-chain sleeve.** `OnchainHedgeVenue` reads an `IHedgeVenue` and a
sub-wallet at one block. Its cash is venue cash plus the sub-wallet's idle stablecoin, and its funding
history comes from the simulator's rate changes. It never places an order: it is read-only, like the
Hyperliquid reader. `hedge_risk` accepts it as venue kind `onchain-perps`, read on the monitor's
`RPC_URL`. The deploy script writes the config for what it deployed
(`deployments/sepolia-hedge-sleeve.hedge-risk.json`).

### 12.2 Trust model

| Who | Can | Cannot |
|---|---|---|
| Hedge-treasury Safe (2-of-3), `TREASURY` | fund; withdraw (never margin below max leverage); `unwind` at its own limit prices without keeper or reference; pause; sweep stray tokens to itself | change itself, the venue or the asset (immutable); send funds anywhere but itself |
| Keeper | `rebalance()`, `harvest()`, at most once per `minActionInterval` | choose a size, price, direction or venue; withdraw; send funds anywhere; exceed the window; raise leverage past max; trade outside the band or on a stale price; add below the funding pause floor |
| Anyone | `deleverage()` above max leverage (reduces only); `sampleFunding()`; liquidate on the simulator | anything else |
| Guardian | `pauseExposure()` | resume, or change anything |
| Governor | tighten params at once, except the four the backstop trades through; loosen params, change any of those four, name a new keeper, or resume, after 48 h (a resume also waits until the latest pause is 48 h old); revoke the keeper at once | move funds; change the treasury, venue or asset; set the backstop's params below their floors |
| Simulator's `venueOperator` (TEST ONLY) | set funding within +-0.05%/h, mark and spot basis within +-2%, spread <= 1%, fee <= 0.5%; list markets | move, freeze or reassign any balance or position; withdraw seeded liquidity; change a listed market's leverage or maintenance |
| The venue itself | everything a venue can do to its deposits: this is venue risk | touch the sub-wallet's idle stablecoin; the sub-wallet's allowance to it is exact and reset to zero after every deposit |

**On Sepolia one EOA holds three roles.** The deployer key `0x4D0dF9bB92883cf5584c812EB84AABA55d688853`
is the sub-wallet's keeper, its governor, and the simulator's `venueOperator`
(`deployments/sepolia-final-hedge-sleeve.json`, `roles`). Whoever holds it can trade within the keeper's
bounds, change params under the rules above, and set the simulator's funding, basis and fees within
their caps. The treasury and the guardian are separate Safes. The 21 October fixes exist because of this
layout: with one key, "the governor may tighten at once" and "the governor may resume at once" were
powers of the keeper too. Splitting the roles before mainnet is section 12.8's question.

**Measured, not argued** (`HedgeSubWalletTest`, `HedgeSleeveInvariantTest`):

- **A compromised keeper colluding with the operator.** The operator sets spread + fee to exactly the
  50 bps band, so every fill lands on its limit. With a $250,000 window the keeper was stopped by
  `TurnoverExhausted` after $200,000. The book lost **$999.97**, under the turnover x band bound of
  $1,250. A fixed window allows twice that across a boundary; the guardian's pause ends it.
- **A compromised operator.** It sets the maximum adverse rate (-0.05%/h) on a $198k book. The 84 h
  average crosses the -10% APR exit floor and an hourly keeper unwinds everything in **8 hours**,
  losing **$1,036.81**. That is under the cap x notional x hours, plus the band out.
- **A venue that lies about fills.** A worse price than the limit, or more size than asked: the whole
  step reverts and nothing moves.
- **A venue that fills one leg.** `PartialFillVenue` is an honest proxy over the simulator that fills
  only part of chosen order kinds, and `LyingVenue` can report a perp fill of zero. A spot buy whose
  short does not fill, or a `deleverage()` whose buy-back does not fill, reverts `UnevenFill` with
  nothing traded. Both legs filling the same part is accepted: the hedge is smaller, not broken.
- **The backstop cannot be switched off.** The governor's 1 bps band, 60 s reference age and 1 bps
  slippage need 48 h and are then refused (`BadParams`); `deleverage()` keeps working.
- **Keeper revoked and reference feed dead.** The treasury `unwind`s at its own limits and withdraws
  everything: **$299,223.73 of $300,000**. That is four fills at 10 bps, plus funding.
- **A +45% rally with nobody watching.** Anyone liquidates the perp. The spot leg survives, and the
  treasury recovers **$297,883.64 of $300,000**.
- **Invariants.** 256 runs x 500 calls each of keeper, harvest, deleverage, liquidation, price moves,
  every operator knob within its bounds, and the treasury's fund / withdraw / unwind, with governor
  resumes (each one scheduled, the delay waited out, then executed):
  - no other role ever holds stablecoin;
  - the treasury's books close exactly;
  - the window never exceeds its budget;
  - no keeper step grows the short past max leverage;
  - no allowance is left standing;
  - the funding average stays in bounds.

### 12.3 The Sepolia rehearsal

`npx tsx scripts/hedge-sleeve-rehearsal.ts` (2026-10-17, fork of block ~11,930,780) ran the whole path
against the live reserve `0x975e…cBEc` and the live custody Safes.

1. Deploy the sleeve on the fork.
2. Execute the scheduled phase-2 changes `setTreasurer` / `setHedgeTreasury` to the Safes. Fork only:
   warped 11.8 h to their `readyAt`, then Chainlink and Pyth re-stamped to the fork's clock with their
   published values unchanged.
3. Fork only: recapitalize the reserve with 500,000 minted stand-in USDT, so its 8% hedge limit has
   room.
4. Treasurer Safe: `withdrawToHedge(20,000)`. (This rehearsal predates the principal-locked reserve of
   21 October 2026; the sleeve is now funded by Mova's capital directly into the hedge Safe.)
5. Hedge Safe: approve + `fund` in one Safe transaction.
6. The keeper builds a 5.4551 ETH / 5.4551 ETH book at exactly 2.00x in one step.
7. `hedge_risk` reads it on-chain: **OK**, closest limit margin.leverage at 67% of its bound.
8. The operator sets 0.02%/h for 2 h: **+$5.28** of funding.
9. `harvest` brings $186.80 home; the hedge Safe withdraws it and `recapitalize`s it.
10. The hedge Safe unwinds with no keeper, withdraws $19,765.68, and recapitalizes it.

Out $20,000.00, back $19,952.48: -$47.52 is four fills at 10 bps on $13.2k, less the funding. Every
Safe transaction was a real `execTransaction` on the live Safes' code and threshold, with approved-hash
signatures from impersonated owners. No key was used.

### 12.4 Deploying it (B7)

`scripts/deploy-hedge-sleeve.ts` sends seven transactions from one NEW key: the simulator, its ETH
market (Chainlink ETH/USD `0x694AA1769357215DE4FAC081bf1f309aDC325306`, checked read-only: "ETH / USD", 8
decimals), a 1,000,000 test-USDT seed, the sub-wallet, and `completeSetup`. A dry run (the default)
deploys on a fork, checks 19 properties, and replays the same transactions READ-ONLY on Sepolia with
`eth_simulateV1`, because Sepolia charges far more than the pinned Foundry for state creation:

| Transaction | Fork gas | Sepolia gas | x |
|---|---|---|---|
| create SimHedgeVenue | 3,088,521 | 21,713,531 | 7.03 |
| listMarket(ETH) | 205,954 | 816,794 | 3.97 |
| mint / approve / seed | 161,616 | 416,144 | 2.6 |
| create HedgeSubWallet | 5,201,948 | 36,246,828 | 6.97 |
| completeSetup | 27,670 | 28,870 | 1.04 |
| **total** | **8,685,709** | **59,222,167** | **6.8** |

- **The fee right now.** Sepolia's price at the time was 21 wei: a 20 wei base fee plus a 1 wei
  priority fee, against the 1.2 mwei the rail itself paid on 15 October. At that price x 1.5 the
  deployment needs 0.0000000019 ETH.
- **What to fund.** At the repo's 2 gwei reference x 1.5 it needs **0.178 ETH**. Fund the new key
  with at least that, because Sepolia's fees swing by orders of magnitude.
- **Gas limits.** Live limits are Sepolia's own estimate x 1.5. Both creations go above 2^24, which
  Sepolia accepts for state-creation gas: the rail's MovvaReserve used 41,258,173.

```bash
# dry run (fork + projection), from the main checkout with .env holding SEPOLIA_RPC:
SEPOLIA_HEDGE_DEPLOYER_ADDRESS=<new key's address> npx tsx scripts/deploy-hedge-sleeve.ts
# the real run, from a clean checkout of the commit, with SEPOLIA_HEDGE_DEPLOYER_KEY in .env:
HEDGE_SLEEVE_CONFIRM=deploy-hedge-sleeve-to-sepolia-from-<deployer address, lowercase> \
  npx tsx scripts/deploy-hedge-sleeve.ts --broadcast-sepolia
```

The broadcast refuses unless all of these hold:

- the confirmation string names the deployer;
- the RPC is Sepolia and not local;
- the tree has no uncommitted change outside `deployments/`;
- a fresh rehearsal and its projection pass;
- the key holds the projected ETH.

It writes `deployments/sepolia-hedge-sleeve.json` and the monitor config, and it can `--resume`. The
signing path itself was exercised on a fork with anvil's public dev key (`--rehearse-broadcast`). The
funding path then needs phase 2 of the custody rotation on Sepolia: the scheduled
`setHedgeTreasury(0x4464…6Cdb)` becomes executable at 2026-10-17 12:08 UTC.

### 12.5 What the simulator does NOT prove

- **The venue is the counterparty**, and its operator sets the funding rate. Fills, funding, spread and
  liquidation are a model, not a market: there is no order book, no depth, no slippage beyond the set
  spread, no other traders, no auto-deleveraging, no margin tiers and no insurance fund.
- **No real exposure.** The spot leg is a venue-internal number (no ETH moves), and its liquidity is
  minted test USDT.
- **A weaker price band.** On Sepolia the venue's oracle and the sub-wallet's reference are the same
  Chainlink feed, so the band only catches the operator's basis, not an oracle failure. On a real
  venue they are independent.
- **Nothing about any real venue:**
  - its fees, its liquidation engine, or its solvency in a crash;
  - its custody, legal or bridge risk;
  - whether its funding resembles the simulator's;
  - asynchronous settlement: the interface is synchronous by design.
- **What it does prove:** the sub-wallet's own logic under any venue behaviour within the interface,
  the bounds on every role, the exits, and the whole Safe-based funding path on the live custody
  contracts.

### 12.6 How a real venue plugs in

1. **Write an `IHedgeVenue` adapter** for the venue: on-chain, a contract that owns the venue account
   for exactly one sub-wallet; for an off-chain venue, an attested bridge, which the client must
   decide on (section 9's trust list applies). The adapter must:
   - report all-in prices;
   - return exactly what filled, never a fill it did not make (the sub-wallet's paired-leg check relies
     on it);
   - revert on any unreadable state;
   - hide asynchrony or refuse it.
2. **Deploy a new `HedgeSubWallet`** over it, with an independent reference feed. The sub-wallet's
   code does not change.
3. **Point the monitor at it:** an `onchain-perps` venue entry reads it unchanged. A venue whose
   funding history lives off-chain needs its own `HedgeVenue` reader, as Hyperliquid has.
4. **Run the same tests** against the adapter. A sub-wallet test suite against the adapter's
   fork-deployed venue is the acceptance gate.

### 12.7 Slither (per file, solc 0.8.28)

Slither 0.11 was run per file on `HedgeSubWallet`, `SimHedgeVenue` and `IHedgeVenue`. No high findings.

**21 October re-run** (`HedgeSubWallet`, `IHedgeVenue`, and the optional adapter's
`HyperCoreDeltaNeutralVault`, `DeltaNeutralStrategy`, `IDeltaNeutral`), `--fail-medium`: all pass, no
high or medium findings. Two mediums the fixes first introduced on the adapter were resolved:

- **`divide-before-multiply`, `_checkpoint`.** The share price was inlined and then multiplied by BPS
  in the drawdown comparison. It is now one `_sharePrice` helper, as `assetsPerShare()` always was;
  the arithmetic is unchanged.
- **`reentrancy-balance`, `deleverage`.** A false positive: the value tested after the CoreWriter call
  is the library's own "did anything", not a balance read back, and the vault's entry point is
  `nonReentrant`. Annotated.

`HedgeSubWallet` now also reports `cyclomatic-complexity` (informational) for `riskier` and
`_validate`, which are long boolean expressions by design.

**Mythril, 21 October** (`bash scripts/mythril.sh HedgeSubWallet`): passes the allowlist gate. The
runtime mode covered 37.37% of the runtime code and reported 10 findings, all in classes already triaged
(SWC-116 timestamps, SWC-123 nested-call requirements). The source mode produced no result on this
machine, as before: it is listed as NOT EXPLORED.

**Sizes, 21 October:** `HedgeSubWallet` 23,285 bytes runtime (1,291 under EIP-170), 27,521 initcode.

**Medium, fixed:**

- **`reentrancy-balance`, `withdrawToTreasury`.** It added what it asked the venue for instead of
  re-reading what arrived; it now re-reads its balance after the venue calls. The remaining report is
  path-insensitive and annotated.
- **`reentrancy-no-eth`, `_addExposure`.** The second leg's turnover charge came after the first
  leg's venue call. Both legs are now charged before anything leaves the contract, and every entry
  point is `nonReentrant` against an immutable venue.

**Medium, false positive:**

- **`arbitrary-send-erc20`, `fund`.** `from` is the immutable treasury, and only it can call.
  Annotated.

**Low and informational, accepted:**

- **`incorrect-equality`:** zero checks on amounts and sizes.
- **`uninitialized-local`:** zero is the intended default.
- **`unused-return`:** round ids from `latestRoundData`.
- **`missing-zero-check`:** zero revokes the keeper, by design.
- **`timestamp`:** windows, freshness and funding are time-based by design.
- **`calls-loop`, `costly-loop`:** bounded at 8 markets per account.
- **`reentrancy-benign`, `reentrancy-events`:** DelayedGovernance's shared `execute`, and events
  after `nonReentrant` venue calls.
- **Naming and assembly:** the repo's conventions and the shared governance base.

### 12.8 For the client to confirm

- **The venue.** Still open. Nothing here assumes one.
- **Hedge-treasury custody.** The sub-wallet's treasury is the hedge-treasury 2-of-3 Safe and its
  guardian is the custody guardian Safe. The governor (params, keeper) is the deployer key on Sepolia,
  as on the rail. Should governance move to a Safe?
- **The keeper.** The keeper key defaults to the deployer (`SEPOLIA_HEDGE_KEEPER` overrides it). Who
  runs it?
- **Sepolia sizes.** $25k per order, $200k per window, a $250k allocation cap, and a 3 h reference age
  (Sepolia's ETH/USD answers rarely). Mainnet sizes are section 4's launch values.
- **Resume.** Decided in the 21 October review: `resume()` on the sub-wallet waits out the delay
  (section 12.1). On the optional adapter `HyperCoreDeltaNeutralVault`, `resume()` is still the
  governor's and instant.
- **One key, three roles.** On Sepolia the keeper, the governor and the simulator's operator are one
  EOA (section 12.2). Should the governor be a Safe, and the keeper a separate trade-only key?
- **Allocation.** The cap is per sub-wallet, plus the engine's absolute caps (section 11). The sleeve is Mova's own
  capital, so how much to put in is Mova's decision, not a share of the reserve.

### 12.9 Reconciling the reserve, and the risk limits in force

The client asked which collateral the strategy uses and where it sits, so that the reserve can be
reconciled and the risk limits defined (19 October 2026).

**Collateral.** The reserve's own stablecoin, USDT on Sepolia. `HedgeSubWallet` refuses a venue whose
`collateral()` is not its `STABLE` (`BadVenue`). There is no conversion step and no third-party custody:
the sub-wallet's account on the venue holds the margin, and the sub-wallet holds the spot leg itself.
If a production venue margins only in USDC, the USDT to USDC conversion becomes an extra, reported step
of the funding path.

**Where it sits.** One read-only command adds the hedge path up against what MOVVA owes, pinned to one
block:

```bash
RPC_URL=$SEPOLIA_RPC npm run -s -w @mova/ops hedge-sleeve -- reconcile --record ../../deployments/sepolia-hedge-sleeve.json [--json]
```

| Line | Source |
|---|---|
| Owed to MOVVA holders | `liabilitiesBrlE18` (the supply at R$ 1,00), and `liabilitiesUsdt` at the current rate |
| In the reserve (on-chain) | `totalUsdt()`, with `collateralRatioBps()`. **This is the only figure the contracts count.** |
| Out on the hedge path | the hedge Safe's balance, the sub-wallet's idle USDT, venue cash, margin equity (signed), and the spot leg at the venue's mark |
| Sleeve result | the sub-wallet's value against `totalFunded - totalWithdrawn` |
| Combined ratio | the reserve plus the hedge path, over the liabilities. Off-chain only: it is what Movva can bring home, not what a redemption is paid from. |
| Top-up Movva owes for 100% | on-chain, and combined |

When the reserve refuses to price itself (its FX leg is older than `fxMaxAge`, as outside FX hours),
the command falls back to the last posted Pyth rate, crossed off-chain exactly as the reserve would,
and marks the line `STALE`. `packages/ops/test/reconcile.test.ts` checks the arithmetic and the
reserve's rounding.

On Sepolia, at block 11950677 (19 October, after the first funding):

- **Owed:** R$ 253.063,60, or 50,009.46 USDT.
- **In the reserve:** 52,563.64 USDT, a ratio of 105.10%.
- **Out on the hedge path:** 3,495.50 USDT, against 3,500 funded. The 4.50 difference is trading costs,
  before any funding was harvested.
- **Combined:** 112.09%.

**The risk limits in force.** The same command prints them, read from the chain:

| Limit | Value | Enforced by |
|---|---|---|
| Reserve target ratio | 108% | `targetCollateralRatioBps` (also the harvest floor's liabilities leg) |
| Mint refused below | 100% | `minMintCollateralRatioBps` |
| Principal out of the reserve | never | no withdrawal function exists; only `redeem` (gateways) and `harvestYield` |
| Yield out of the reserve | only above `max(principalUsdt, liabilities at 108%)`, only to `yieldRecipient` | `harvestYield` |
| Leverage | 2x target, 3x max (`deleverage()` is open to anyone above it) | `HedgeSubWallet` params |
| Delta tolerance | 2% | params |
| Price band, slippage | 1%, 0.5% | params |
| Funding | no new exposure below 0% APR; unwind below -10% APR | params |
| Allocation cap, max order, keeper turnover | 250,000 / 25,000 / 200,000 USDT per window (Sepolia sizes) | params |

These are the current defaults. The risk engine (section 11) adds its off-chain warn and fail bounds on
top. The client sets the production values. Loosening any on-chain bound waits out `GOVERNANCE_DELAY`;
tightening one is instant.

**A live coverage figure, for publication.** The client (19 October 2026), after Ethena: a live coverage
ratio, the delta-neutral position reported separately, and Movva committing to top up before coverage
falls below 100%. The same block-pinned read and the same sums, as a report meant to be published
(`packages/ops/src/coverage.ts`):

```bash
# With the sleeve (the record names the reserve and the sub-wallet):
RPC_URL=$SEPOLIA_RPC npm run -s -w @mova/ops hedge-sleeve -- coverage --record ../../deployments/sepolia-final-hedge-sleeve.json --json
# The reserve alone, before any sleeve exists:
RPC_URL=$SEPOLIA_RPC npm run -s -w @mova/ops hedge-sleeve -- coverage --reserve 0xb7a8bb1cBD2348c5d27546058d2fb3435cCd11B6 --json
```

Without `--json` it prints the same figures as text. The JSON (`schema: "movva-coverage/1"`) holds:

| Field | What it is |
|---|---|
| `block`, `blockTimestamp`, `blockTime`, `generatedAt` | the block every figure was read at, its time, and when the report was made |
| `rate` | reais per USDT; `source` is `reserve` (the contract priced itself) or `last-posted`; `stale`, `postedAt` and `ageSeconds` say how old a last-posted rate is |
| `liabilities` | what MOVVA holders are owed, in reais and in USDT at that rate |
| `onchain` | `totalUsdt()` and the ratio over the liabilities. **The figure the contracts count.** |
| `hedgePath` | reported separately: hedge Safe, sub-wallet idle, venue cash and margin equity (`venueEquity`), spot at mark, the total, and the sleeve's result against what funded it |
| `combined` | reserve plus hedge path, over the same liabilities. Off-chain, for information |
| `topUp` | USDT Movva would add for 100% on-chain, the same counting the hedge path, and back to the top-up point |
| `policy`, `state` | the target ratio, the top-up point, the mint and withdraw floors, the commitment in words; and where coverage stands: `at-or-above-target`, `below-target`, `top-up-due`, `under-backed` or `no-supply` |

Amounts are decimal strings in token units; ratios are basis points (`null` with no MOVVA in
circulation). Every number comes from the chain at one block. Nothing in the report is configured or
estimated, so it can be published as it stands. On a stale rate (the FX market closed) the report says so
in `rate`, and its figures are the reserve's own arithmetic on the last posted rate.

The monitor publishes the same report live. With `RESERVE_COVERAGE=true` beside `MOVVA_RESERVE`, and
`RESERVE_COVERAGE_RECORD` (this record) or `RESERVE_COVERAGE_SUBWALLET` for the sleeve, it adds the check
`reserve_coverage`:

| Level | When |
|---|---|
| `ok` | at or above the target ratio (108%). Between the top-up point and the target it is still `ok`, and the detail says it is under target |
| `warn` | below the top-up point: `RESERVE_COVERAGE_TOPUP_BPS`, by default 103%. This is where Movva's commitment says to top up |
| `fail` | below 100% on-chain. A redemption then pays its pro-rata share, whatever the hedge path holds |

A stale rate is reported as `STALE` at the start of the detail and is judged on the last-posted figures.
It is never shown as a bare `ok`. A last posting older than `RESERVE_COVERAGE_STALE_WARN_SECONDS` (four
days by default) warns on its own. The report is served on the monitor's unauthenticated `/coverage`,
inside `/status` (`coverage`), and as gauges on `/metrics`:

- `mova_reserve_coverage_ratio_bps{basis="onchain"|"combined"}`
- `mova_reserve_coverage_usdt{side=...}`
- `mova_reserve_coverage_rate_stale`

`/coverage` is the URL to put behind a public page. The runbook entry is in docs/runbook-incidents.md,
"`reserve_coverage`". Tests: `packages/ops/test/coverage.test.ts`.

On Sepolia, 20 October 2026 at 18:10 UTC, both reads were `STALE`, because the FX rate was last posted at
16:47 UTC on 19 October:

- **The first sleeve's reserve** (`sepolia-hedge-sleeve.json`, block 11956994): on-chain 105.11%, hedge
  path 3,496.13 USDT, combined 112.10%, no top-up owed, state `below-target`.
- **The final rail's reserve** (`sepolia-final-hedge-sleeve.json`): no MOVVA in circulation yet
  (`no-supply`), and nothing on the hedge path.

The wallet shows holders the same ratio, read live at the rate the reserve's band reads: on the
"Reserva e riscos" screen, and as a short line beside Início's backing notice. The delta-neutral
position appears on its own line on that screen. It is read from the sub-wallet named in the app's
deployment JSON (optional `contracts.hedgeSubWallet`, and `contracts.hedgeVenue`, which must match the
sub-wallet's `VENUE()`). It shows the amount allocated (funded, net of returns) and its value now.
Without a sub-wallet, the screen says that no strategy position is open.
