# Security tooling

**What this is.** Every security tool run over this repository ahead of the Sepolia review, each with its
version, the exact command, what it covered, what it found, and the triage of every finding. Written 19
September 2026 against commit `dbeec90` plus the changes it describes: the escrow invariant suite, the
extended Movva supply invariant, `scripts/mythril.sh`, `scripts/circomspect.sh` and their CI jobs. Each tool
is a job in `.github/workflows/verify.yml`.

> **Update, 12 October 2026.** The client removed shielded transfers (Rev. 3 §5.3) from scope and
> `ShieldedTransferRouter` was deleted. Its rows below are the record of the 19 September runs; `scripts/mythril.sh`
> and `scripts/mythril-allowlist.txt` no longer list it, so the next run covers 26 contracts.
>
> **Update, 15 October 2026: savings removed.** Client decision D1 (14 October 2026) removed savings from M1, and
> `SavingsMovva` (`contracts/movva/SavingsMovva.sol`) and `ShieldedYieldRouter` (`contracts/yield/ShieldedYieldRouter.sol`)
> were deleted with their tests. Their rows and mentions below (Slither's reentrancy row, Mythril's coverage list,
> per-contract table and SWC rows, `SavingsMovva`'s Mythril budget) are the record of the 19 September runs, marked
> *(removed, D1)*; the current procedure does not analyse them, so `scripts/mythril.sh` and `scripts/mythril-allowlist.txt`
> must not list them and the next full Mythril run covers 25 contracts (MovvaReserve alone was re-run on 15 October: 2 findings, both allowlisted, 0 unused allowlist entries; 2.53% source / 47.35% runtime coverage). `MovvaReserve` lost `distribute`,
> so §1.2's suite changed: `invariant_SupplyMovesOnlyThroughMintAndRedeem` replaces "...MintRedeemAndDistribute",
> `invariant_DistributeNeverMintsAtOrBelowTarget` is gone, and the handler has no save, unsave or distribute actions.
> The counts below are the 19 September ones.

**The short version.**

| Tool | Scope | Result |
|---|---|---|
| Invariant fuzzing, Foundry 0.3.0 (pinned) | Escrow single settlement (new), Movva supply reconciliation (extended), NodeRewards and SponsorGate | 26 invariants, all hold |
| Slither 0.11.6 | All 46 Solidity files we wrote, one at a time; the smart-account package | 0 high, 0 medium |
| Mythril 0.24.8 | The 27 contracts we deploy, from the constructor and from arbitrary storage | 119 findings, every one a false positive with its reason; 0 real |
| Circomspect 0.9.0 | The three circuit files, as vendored | 3 warnings and 7 notes, every one explained, none a vulnerability |
| Build reproducibility | 38 compiled artifacts, built from two directories | Identical to the byte, metadata hash included |

**No finding needs a contract change.** Nothing below is a vulnerability in our code; every finding is either
a detector's false positive, with the reason, or a design decision already documented, with where.

**What "green" means here, and what it does not.** Every result below was produced on this machine. The three
new CI jobs (`invariants`, `mythril`, `circomspect`) exist in the workflow but have not yet run on GitHub,
because this change is not pushed; "CI passed" becomes true the first time they run there. And these tools
find classes of bugs within bounds (fuzzing campaigns, symbolic depth, detector patterns); none proves their
absence. They do not replace the external audit ([audit-readiness.md](audit-readiness.md)).

## 1. Invariant fuzzing

All three suites are handler-based: the fuzzer calls a handler contract's actions in random order with random
arguments, the handler drives the real contracts through them (every call is allowed to revert), and after
every call Foundry checks each `invariant_` function. Foundry runs each invariant function as its own
campaign of *runs* sequences, each *depth* calls long, from a fresh random seed. A failure prints the call
sequence that broke it.

```
FORGE=$(bash scripts/foundry.sh path)
"$FORGE" test --match-contract Invariant -vv        # all suites; the CI job `invariants`
FOUNDRY_PROFILE=deep "$FORGE" test                  # deep: the nightly CI job `deep-fuzz`
```

**Deep fuzzing** (`[profile.deep]` in foundry.toml, added 18 October 2026). Every fuzz test runs 10,000 times,
against Foundry's default 256, and every invariant runs 1,000 sequences of 256 calls, against the per-push 64 to
256 sequences of 120 to 200 calls set in each file. The pinned Foundry applies a suite's
`forge-config: default.invariant.*` lines under every profile, so each suite that has them also carries
`forge-config: deep.invariant.*` lines (a new suite needs both, or `deep` silently runs it at the per-push figures).
It takes hours, so CI runs it nightly and on demand, not on push.

### 1.1 Escrow single settlement (new): `contracts/test/EscrowInvariant.t.sol`

**Parameters.** 256 runs x 200 calls per invariant, in the file's `forge-config` comments: 51,200 calls per
property, 563,200 per complete execution of the file.

**What is real and what is mocked.** `FiatEscrow`, `OffRampEscrow` and `LPRegistry` are the real contracts,
deployed and configured as the unit tests configure them (governor, delay, dispute timeout, a second asset,
the arbitrator, setup completed). The payment attestor is the unit tests' `MockVerifier`/`MockVerifier2`,
which returns a canned `Payment` for an order, so what is under test is the escrows' own checks on it: payee,
amount, rail, timing, replay. Prices are the unit tests' `MockOracle`, `MockOracle2` and `StableOracle`; the
second asset is `MockUSD` (6 decimals). One stand-in is new, `ShieldedSink`: the Privacy Pools Entrypoint and
pool in one, accepting both deposit shapes (ETH and ERC-20) and counting what it receives, so a shielded
delivery has exactly one place to go.

**On-ramp (`FiatEscrowInvariantTest`).** Two institutional LPs and one retail LP (a small credit limit that
moves with its record) post, top up and close offers in ETH and in the token, for PIX alone or PIX and boleto.
Three takers lock orders by PIX or by boleto, for direct or shielded delivery; LPs issue boletos; anyone
submits receipts, good ones and deliberately bad ones (predating the order or its boleto, replaying a receipt
that already settled another order, a centavo short, paid to someone else's key); takers cancel, switch a
shielded order to direct delivery, or dispute; either party disputes; the arbitration desk's key signs
rulings each way, which anyone posts and, after `RULING_DELAY`, executes; anyone expires lapsed orders and
timed-out disputes; time moves by minutes, hours, or a whole dispute timeout. `hammerSettled` takes an order
that has already ended and tries every path that ends or reopens one: a fresh good receipt, the taker's
cancel, the expiry, the dispute timeout, a new dispute from either side, a switch to direct delivery, a fresh
ruling each way and the one already posted.

| Invariant | Property |
|---|---|
| `invariant_EveryOrderSettlesAtMostOnce` | Every order settles at most once, by exactly one of release, cancel, expiry, a ruling or the dispute timeout. Once RELEASED or CANCELLED nothing succeeds against it again and its state never changes; every call is classified from the order's state before and after it |
| `invariant_EscrowHoldsExactlyItsOffers` | For ETH and for the token, the escrow's balance equals the sum over its offers of available plus locked liquidity, and equals what was paid in less what the handler saw paid out |
| `invariant_OfferLockedIsItsOpenOrders` | Each offer's `lockedWei` equals the sum of its LOCKED and DISPUTED orders |
| `invariant_NoThirdAddressIsPaid` | Every LP, taker, recipient, the pool stand-in and every bystander holds exactly its starting balance plus what the escrow owed it; a release paid the order's recipient (direct) or the pool (shielded) exactly the order's amount; the sum over all of them plus the escrow equals everything that exists, so nothing reached an address outside the book |
| `invariant_NoBadReceiptReleases` | No replayed, short, misaddressed or pre-order receipt ever releases |
| `invariant_CreditMatchesOffers` | The credit `LPRegistry` holds for each LP equals the BRL value of its offers' liquidity, `ceil((available + locked) x price / 10^decimals)` summed |

**Off-ramp (`OffRampEscrowInvariantTest`).** Three sellers open sales in ETH and the token, to a PIX key or to
a bill (BOLETO), and cancel unclaimed ones; two institutional LPs and one retail LP claim, abandon, let claims
go stale and settle with good and bad receipts (the same four kinds, plus a bill paid for more than its face
value); either side disputes; rulings each way; timeouts; time. `hammerSettled` again tries every path
against an ended sale, re-claiming included.

| Invariant | Property |
|---|---|
| `invariant_EverySaleSettlesAtMostOnce` | Every sale settles at most once, to the LP (a proven payment or a RELEASE ruling) or back to the seller (cancel, a REFUND ruling or the timeout), never both and never again |
| `invariant_EscrowHoldsExactlyItsOpenSales` | For each asset the escrow's balance equals the sum of its OPEN, CLAIMED and DISPUTED sales, and paid in less paid out |
| `invariant_NoThirdAddressIsPaid` | A settled sale paid its claiming LP, a refunded one the seller's refund address, exactly the sale's amount; every other address is untouched; nothing reached an address outside the book |
| `invariant_NoBadReceiptSettles` | No replayed, short, misaddressed, pre-claim or wrong-face-value receipt ever settles |
| `invariant_CreditMatchesLiveClaims` | The credit held for each LP is the sum of the sales it holds a live claim on |

**Fees owed.** Neither escrow charges or accrues a fee (`FiatEscrow`: "fees are not the escrow's concern";
`OffRampEscrow` has no fee state), so the conserved quantity is exactly the open book above. The rail's fees
are charged outside the escrows (the reserve's mint and redeem fees; the distribution fee was removed with savings, D1).

**Liveness, at the end of every run** (`afterInvariant`). Past every window and timeout, a stranger ends every
open order or sale and each LP closes each offer, receiving exactly its available liquidity; then both escrows
hold nothing and reserve no credit. So "settles exactly once" is checked in both directions: at most once
during the run, and at least once when it ends.

**Reach.** Successful calls per 200-call run, from the last run of each campaign (printed with `-vv`):

| On-ramp | per run | Off-ramp | per run |
|---|---|---|---|
| postOffer / fundOffer / closeOffer | 11.2 / 5.5 / 13.7 | openSale / cancelSale | 14.8 / 8.8 |
| lock (PIX) / lock (boleto) / issueBoleto | 3.8 / 2.3 / 0.5 | claimSale / abandonClaim / releaseStaleClaim | 6.4 / 2.6 / 0.2 |
| release (proven) / cancel / reclaimExpired | 1.5 / 2.2 / 0.5 | settle (proven) | 1.2 |
| takeDeliveryDirect / raiseDispute | 0.7 / 1.7 | raiseDispute | 2.4 |
| postRuling / executeRuling / expireDispute | 1.2 / 1.2 / 0.3 | postRuling / executeRuling / expireDispute | 2.8 / 0.8 / 1.6 |
| hammerSettled (about 10 attempts each) | 10.2 | hammerSettled (about 11 attempts each) | 12.2 |

Across one campaign of 256 runs that is roughly 300 to 400 proven settlements, a few hundred executed rulings
and as many timeouts, and 25,000 to 35,000 attempts to settle or reopen an order or sale that had already
ended, all of which reverted.

**Result.** All 11 hold, in every complete execution of the file since the handler was finished (five, each
on a fresh random seed, 2.8 million calls in all). No failing sequence, so nothing to escalate.

### 1.2 Supply reconciliation (extended): `contracts/test/MovvaInvariant.t.sol`

**What T-03 and T-09 mean here.** Rev. 3 wants total supply to equal what was minted less what was burned,
with no other way to create MOVVA. In this repository the minter is `MovvaReserve`, not the escrow
([rev3-conformance.md](rev3-conformance.md), decision 1, still open), so the property is: Movva's supply
equals everything the reserve has minted less everything it has burned.

**What was there** (19 September; since D1 there is no distribute, no savers and one invariant fewer - see the
update at the top). Six invariants over a year's worth of reserve operation (mint, redeem, distribute,
hedge withdrawals, recapitalization, FX and peg moves, ratio changes through the delay, vault allocation,
Tether freezing the reserve, savers): supply moves only through mint, redeem and distribute, each by exactly
what it reports; distribute never mints at or below target; hedge withdrawals never breach the floor; redeem
never pays more than min(1, ratio) of par and mint never more than the USDT in; the band never above R$ 1,00;
the ratios stay ordered.

**What was missing.** The check against a record of mints and burns. The handler's ghost supply started from
`totalSupply()` when the handler was built and advanced by observed `totalSupply()` changes, so "supply equals
minted minus burned" was never checked against anything but the supply itself.

**What was added.** `invariant_SupplyIsWhatTheReserveMintedLessWhatItBurned`: from before the token is
deployed, every Movva `Transfer` from the zero address (a mint) and to it (a burn) is booked from the token's
own events; after every call the supply must equal minted less burned. Each successful mint, redeem and
distribute is also checked to have emitted mint and burn events equal to the supply change it made (mint and
distribute never burn, redeem never mints), and `RESERVE` must still be the reserve. A mint anywhere else
would move the supply without entering the ledger and fail the first assertion.

**A tooling trap, found on the way.** The first version failed: supply 12.13M against a ledger of 10.66M, and
in another campaign a ledger with more burned than minted, which no real history can produce. The cause is
the pinned Foundry: `vm.recordLogs` also keeps events emitted inside calls that later revert (a redeem that
burns and then cannot pay). A three-line probe (an event, then a revert, inside `try`) recorded the reverted
event. The ledger now books only calls that succeeded. This was a test artifact, not a contract issue, and the
existing "supply moves only by what each call reports" invariant held throughout.

**Parameters.** 128 runs x 200 calls per invariant (unchanged). **Result.** All 7 held (19 September); all 6 hold since D1 (15 October 2026).

### 1.3 The suites that were already there

`NodeRewardsInvariant.t.sol`, 64 runs x 120 calls: five invariants (rewards claimed never exceed what was
funded, the books add up and are backed, a failing hook never blocks a settlement, share and limit changes
follow the delay, no claim pays past its bounds). `SponsorGateInvariantTest` in `SponsorGate.t.sol`, Foundry's
defaults (256 runs x 500 calls): three (a revoked operator never succeeds, a window never admits more than its
budget, operators never reach an owner's power). **Result.** All 8 hold. Both are in the `invariants` job.

**The job as a whole.** `forge test --match-contract Invariant -vv`: 5 suites, 26 invariants, 0 failed, about
three minutes.

## 2. Slither

**Version.** Slither 0.11.6 (crytic-compile 0.4.2), solc 0.8.28.

**Command.** One file at a time, because crytic-compile cannot read the build-info the pinned Foundry
writes; the CI job's `npm run slither` (whole tree, through Foundry) is unaffected and stays as it is:

```
slither <file> --compile-force-framework solc --solc <solc-0.8.28> \
  --solc-remaps "@openzeppelin/contracts/=node_modules/@openzeppelin/contracts/ forge-std/=lib/forge-std/src/" \
  --exclude-dependencies --filter-paths "lib/|node_modules/|test/|script/" \
  --exclude pyth-unchecked-confidence --fail-medium
bash scripts/slither-smart-account.sh
```

`pyth-unchecked-confidence` is excluded because the detector crashes on our code (see `scripts/slither.sh`;
the check it performs is done by `PythBrlOracle` and pinned by a test).

**Coverage.** All 46 `.sol` files under `contracts/` except `test/` and `script/`: `ramp/`, `movva/`,
`yield/`, `transfer/`, `common/`, `hyperliquid/` (not deployed on Sepolia, included anyway) and the root
contracts. Plus the smart-account package's four contracts (`KernelAvatarAdapter`,
`PasskeyCoSignerValidator`, `UserOpChallenge`, `FrostValidator`).

**Result.** 46 of 46 files exit 0 under `--fail-medium`; the smart-account script exits 0. Unique findings
across the files (shared code counted once): **0 high, 0 medium**, 83 low, 109 informational, 3
optimization.

| Low finding | Where | Why it is not a vulnerability |
|---|---|---|
| `timestamp` (57) | Every contract with a window: pay and claim windows, dispute and ruling deadlines, governance delays, oracle staleness, budget and grant windows | Intended. Every window is minutes to days; a proposer's influence on `block.timestamp` is seconds. The same class is triaged in [audit-scope.md](audit-scope.md), "Slither triage" |
| `reentrancy-benign` (11), `reentrancy-events` (10) | `FiatEscrow` release, ruling, `_deliver`, `expireDispute`; `OffRampEscrow` claim, stale claim, abandon; `DelayedGovernance.execute`; `YieldVault`, `KeeperGate`, `ShieldedYieldRouter` *(removed, D1)*, `ShieldedTransferRouter` *(removed)*, `ERC4626Adapter`, `LidoStakingAdapter`, `DeltaNeutralStrategy` | Each call is to a trusted, fixed callee or behind a guard: the escrows' writes after the pool deposit are the commitment index, inside `nonReentrant` (comment at `_deliver`); their other calls are to the immutable `LPRegistry`, which never calls back, and only an event follows; `DelayedGovernance.execute` calls itself, after deleting the schedule; the routers are `nonReentrant`; `KeeperGate` calls its immutable vault; the vault and adapters are covered in audit-scope.md |
| `calls-loop` (3) | `SponsorGate.sponsorBatch`, `YieldVault.totalAssets`, `liquidAssets` | Bounded (at most 100 accounts; at most 8 adapters) and to trusted callees; in audit-scope.md |
| `missing-zero-check` (2) | `SponsorGate` guardian | Zero means no guardian, on purpose; in audit-scope.md |

Informational: `naming-convention` (68: upper-case immutables and underscored names), `assembly` (10),
`low-level-calls` (10: `SafeTransferLib`'s token calls and the escrows' ETH sends and pool deposit, each
result checked; `DelayedGovernance.execute`'s call to itself, whose error is bubbled; Lido's stake-and-wrap;
Superstate's optional probe), `costly-loop` (8, bounded loops), `cyclomatic-complexity` (5),
`dead-code` (4, OpenZeppelin ERC-4626 hooks that OpenZeppelin calls), `unindexed-event-address` (3),
`unimplemented-functions` (1: `DelayedGovernance` is abstract, each child implements `_isDelayable`).
Optimization: `cache-array-length` (2), `var-read-using-this` (1). The smart-account package: 4
informational (`naming-convention` on `WEBAUTHN`, `GROUP_X`, `GROUP_Y`; `too-many-digits` on the P-256
constants).

**`OwnerlessPaymaster` (added 14 October 2026, after the run above).** `contracts/OwnerlessPaymaster.sol` exits 0
under `--fail-medium` with the same command: 0 high, 0 medium, 1 low, 12 informational. The low finding is
`timestamp` in `remaining()`, a view for off-chain clients. Validation and `postOp` read no block data. The 12
informational findings are `naming-convention` on the upper-case immutables.

## 3. Mythril

**Version.** Mythril 0.24.8, its latest release (March 2024), from the official image pinned by digest
(`docker.io/mythril/myth@sha256:49e11758e359d0b410f648df5bbcba28a52e091a78e4772b5c02b9043666b4ff`), run with
podman here and docker in CI. solc 0.8.28 is the official build, checked against its published SHA-256 and
mounted into the container. Python 3.14 on this machine cannot build Mythril's dependencies, hence the image.

**Command.** `bash scripts/mythril.sh` (the CI job `mythril` runs it with four parallel analyses). For each
contract it runs two analyses:

```
# source mode: compile, run the constructor with symbolic arguments, then two symbolic transactions
myth -v 4 analyze contracts/<file>.sol:<Contract> --solc-json <settings> -o json --disable-iprof \
  --create-timeout 1800 --execution-timeout 600 --max-depth 128 -t 2 --solver-timeout 25000
# runtime mode: the deployed code alone, from storage in which every slot may hold anything
myth -v 4 analyze -f <Contract>.hex --bin-runtime --unconstrained-storage -o json --disable-iprof \
  --execution-timeout 300 --max-depth 128 -t 2 --solver-timeout 25000 [-m <every module but IntegerArithmetics>]
```

`<settings>` is foundry.toml's remappings and optimizer (1,000 runs) with `evmVersion` Shanghai. Each
container is capped at 2 GB and given the highest OOM score (see "On this machine" below). One contract has a
budget of its own: `SavingsMovva`'s runtime exploration allocates far faster than any other here (ERC-4626
rounding, `mulDiv` over symbolic totals) and at 300 seconds it passed the cap and was killed, which the gate
reported as a failed analysis; it runs with 180 seconds and still covers 77% of its runtime. *(SavingsMovva was
removed with savings, D1, 14 October 2026; the special budget goes with it.)*

**Coverage.** The 27 contracts we deploy: `AttestorQuorumVerifier`, `ChainlinkBrlOracle`,
`ChainlinkSignedFxOracle`, `FiatEscrow`, `LPRegistry`, `NodeRewards`, `OffRampEscrow`, `PythBrlOracle`,
`PythFxOracle`, `ReclaimZkTlsVerifier`, `SignedPriceOracle` (ramp); `FeeSplitter`, `Movva`, `MovvaReserve`,
`SavingsMovva` *(removed, D1)*, `ScaledFxBandOracle` (movva); `KeeperGate`, `ShieldedYieldRouter` *(removed, D1)*, `YieldVault`,
`ERC4626Adapter`, `LidoStakingAdapter`, `SuperstateUSTBAdapter` (yield); `ShieldedTransferRouter`;
`SponsorPaymaster`, `SponsorGate`, `AuditGrantRegistry`, `ShieldedNoteLog`. `contracts/common` has only an
abstract contract and internal libraries (`DelayedGovernance`, `IssuerFreeze`, `ShieldedDepositLabel`,
`FxMarketHours`), none deployed on its own; each is analysed inside every contract that inherits or inlines
it, which is why `DelayedGovernance`'s functions appear under many contracts below. `hyperliquid/` is not
deployed on Sepolia and is not in scope here (Slither covers it).

**Why two modes.** The source mode is realistic: immutables are set by the constructor and storage starts
where deployment leaves it, but two transactions from a fresh deployment reach only shallow states (setup is
not even complete). The runtime mode starts from storage in which every slot may hold anything, so a disputed
order or a live claim is reachable at once. But runtime code carries zero immutables and Mythril runs it at
address 0, so a contract's call to its oracle, registry or vault is a call to *itself* with a selector it does
not have (solc omits the `extcodesize` check when it expects return data), and it also reaches states no
transaction sequence can produce, such as a counter out of step with the mapping it counts. Each mode covers
what the other cannot, and several runtime findings are artifacts of exactly this - each marked as such.

**Four things learned by checking Mythril's own work.** Mythril reports "no issues" as readily for code it
never reached as for code it explored, so every analysis here is checked for having run at all.

1. *MCOPY.* solc 0.8.28 targeting Cancun emits `MCOPY`, which Mythril 0.24.8 does not implement: every path
   through it would end as an invalid instruction. Both modes therefore analyse a Shanghai build of the same
   source with the same optimizer settings. What Mythril reasons about is our Solidity, not the byte-identical
   deployed runtime (whose reproducibility is section 5).
2. *Construction.* Creating a contract copies its whole runtime into memory one symbolic byte at a time,
   minutes for the large ones on a loaded machine, and Mythril counts it against the execution budget. The
   first attempt here reported zero findings for `FiatEscrow` after exploring 3.6% of its constructor and
   none of its code. And for constructors taking arrays (`AttestorQuorumVerifier`'s attestor list, for one),
   Mythril's solver judges every post-constructor state unreachable and explores nothing. The script
   therefore requires, for every analysis, that the first transaction started from at least one state and
   that the runtime code has a coverage figure; a mode that explored nothing fails the run unless it is
   listed as `NOT EXPLORED` with its reason, and every contract must be explored in at least one mode.
3. *Integer overflow on solc 0.8.* When Mythril compiles the source it disables its integer module for solc
   0.8 or later (checked arithmetic reverts on a wrap), unless the file contains `unchecked`. From bytecode it
   cannot see the compiler version, and would flag every checked operation, whose wrap it sees before solc's
   panic check reverts it. The runtime mode applies Mythril's own rule per contract: the module stays on for
   `LPRegistry`, `NodeRewards` and `SponsorPaymaster`, whose files contain `unchecked`.
4. *A positive control.* A 20-line contract with a reentrancy, a delegatecall to a caller-chosen address and
   a `tx.origin` check, through the same image, solc and settings: Mythril reported all of them (SWC-107,
   SWC-112, SWC-115, plus SWC-114). The pipeline finds what it should.

**On this machine.** A first full run with three parallel analyses pushed the machine out of memory at about
21:38, and the kernel killed another project's node (`kriptonyx.service`), which systemd restarted a minute
later. The containers are now capped and marked as the first thing to kill, and the runs here used two
parallel analyses.

**Result.** 119, 120 and 121 findings over the 54 analyses of three full local runs, and 119 and 122 in the
two CI runs of the same commit; every one triaged in `scripts/mythril-allowlist.txt` (70 entries: 64 classes
and six analyses that explored nothing) and explained below. **None is a vulnerability.** Three findings come
from the source mode and the rest from the runtime mode, which is what starting from arbitrary storage costs.
By severity as Mythril labels it in the reference run: 13 high, 47 medium, 59 low.

| Contract | source: coverage / findings | runtime: coverage / findings |
|---|---|---|
| `AttestorQuorumVerifier` | not explored | 87.30% / 4 |
| `ChainlinkBrlOracle` | 59.53% / 0 | 82.55% / 5 |
| `ChainlinkSignedFxOracle` | 55.95% / 0 | 72.09% / 4 |
| `FiatEscrow` | 29.32% / 0 | 43.82% / 4 |
| `LPRegistry` | 55.40% / 0 | 62.38% / 7 |
| `NodeRewards` | 36.54% / 0 | 61.82% / 4 |
| `OffRampEscrow` | 37.47% / 0 | 47.53% / 5 |
| `PythBrlOracle` | 55.48% / 0 | 51.27% / 1 |
| `PythFxOracle` | 62.58% / 0 | 58.78% / 7 |
| `ReclaimZkTlsVerifier` | not explored | 27.87% / 0 |
| `SignedPriceOracle` | not explored | 86.01% / 5 |
| `FeeSplitter` | 63.73% / 0 | 79.14% / 5 |
| `Movva` | 86.20% / 1 | 92.03% / 1 |
| `MovvaReserve` | 2.52% / 0 | 46.70% / 1 |
| `SavingsMovva` *(removed, D1)* | 67.37% / 0 | 76.75% / 2 |
| `ScaledFxBandOracle` | 91.12% / 1 | 57.48% / 1 |
| `KeeperGate` | 72.27% / 0 | 77.90% / 9 |
| `ShieldedYieldRouter` *(removed, D1)* | 36.19% / 0 | 54.49% / 3 |
| `YieldVault` | 19.42% / 0 | 60.00% / 3 |
| `ERC4626Adapter` | not explored | 70.10% / 2 |
| `LidoStakingAdapter` | not explored | 39.23% / 5 |
| `SuperstateUSTBAdapter` | not explored | 32.30% / 7 |
| `ShieldedTransferRouter` | 42.06% / 0 | 57.97% / 4 |
| `SponsorPaymaster` | 80.98% / 0 | 98.10% / 11 |
| `SponsorGate` | 68.13% / 0 | 74.48% / 14 |
| `AuditGrantRegistry` | 90.78% / 1 | 98.98% / 2 |
| `ShieldedNoteLog` | 95.26% / 0 | 97.88% / 0 |

**`OwnerlessPaymaster` (added 14 October 2026, after the run above;**
`MYTHRIL_JOBS=1 bash scripts/mythril.sh OwnerlessPaymaster`**).** Two runs:

- **Source mode:** 61.5% and 60.4% coverage, 0 findings.
- **Runtime mode:** 59.7% and 59.3% coverage, 3 x SWC-123 in `fallback`. The inputs are `0x`, `addStake()`
  and `getDeposit()`. This is the runtime-mode artifact triaged for the other contracts: with zero immutables,
  `ENTRYPOINT` is address 0, which is the contract itself. Allowlisted, pinned to `runtime`.
- **The first run also had 2 x SWC-101 in `accountAddress`,** at `_root`'s `index == 0` and `index == 1`
  tests: the optimizer's equality-as-subtraction pattern. It appeared only because a NatSpec comment contained
  the word "unchecked", which switched on the script's integer module (the grep in `scripts/mythril.sh`). The
  file has no `unchecked` block. The comment was reworded, and the second run, with the module off as for every
  other 0.8 file without `unchecked`, has no such finding.

The source-mode figures are low for the large contracts because Mythril counts the constructor against the
same budget: `MovvaReserve` (which deploys the token in its constructor) reached 2.5% and `YieldVault` 19.4%,
so for those two it is the runtime mode that carries the weight. Six constructors could not be executed
symbolically at all, each for a stated reason, and the runtime mode covers all six.

**Every finding, by class.**

| Class | Count | Where | Triage |
|---|---|---|---|
| SWC-116, dependence on a predictable environment variable | 51 | `DelayedGovernance.schedule` and `execute` (inherited by every governed contract), both escrows' windows and deadlines, the oracles' staleness checks, `NodeRewards`' epoch clock, `SavingsMovva.unvested` *(removed, D1)*, `ShieldedTransferRouter.transfer`'s relayed deadline, OpenZeppelin's `permit` deadline | By design, and the same class Slither reports. Every comparison is against a window the design states in hours or days - a 30-minute pay window, a 45-minute claim, a day's ruling delay, a 30-day dispute timeout, a governance delay of days, an oracle's maximum age. A proposer can move `block.timestamp` by seconds |
| SWC-123, requirement violation | 43 | Two shapes, both runtime-mode; the CI run also had them on `FeeSplitter.setTreasury` and `YieldVault` | (a) A scheduled setter reached through `DelayedGovernance.execute`: `execute` runs the change as a call to the contract itself and bubbles the setter's own error, so the "violated requirement" is the setter refusing its arguments and the whole transaction reverting. (b) `fallback`: the runtime code has zero immutables and Mythril runs it at address 0, so a call to the registry, oracle or vault is a call to itself with a selector it does not have, and the dispatcher reverts. The constructor sets those immutables in any deployment, and the source mode reports none of these |
| SWC-101, integer overflow or underflow | 12 | `LPRegistry`, `NodeRewards`, `SponsorPaymaster` (the three files with `unchecked`), and the shared `DelayedGovernance.cancel` | Three patterns, each read off the bytecode at the reported program counter: the optimizer compiling an equality test as a subtraction that only feeds a `JUMPI`; solc's ABI decoder bounds check, where the subtraction wraps and the signed comparison after it reverts; and `SponsorPaymaster._windowEnd`'s deliberate saturating add, `unchecked` because the `end < start` check right after it clamps to `type(uint256).max` |
| SWC-107, state access after an external call | 5 | `YieldVault.harvest`, both routers' `rescue` *(both routers since removed)*, `LidoStakingAdapter.claimExit` | The state after the call is OpenZeppelin's `ReentrancyGuard` releasing its own slot, the balance delta that measures what the call returned, and the vault's drawdown checkpoint. Every one of those functions is `nonReentrant`, and the callees are governor-listed adapters or the pool the caller's own deposit sits in |
| SWC-107, external call to a user-supplied address | 3 | `YieldVault.harvest(adapter)`, `ShieldedYieldRouter.rescue` *(removed, D1)*, `ShieldedTransferRouter.rescue` *(removed)* | `harvest` requires the adapter to be listed by the governor and the caller to be the keeper; the routers pay only the recipient recorded for that deposit and only when it is the caller. Unconstrained storage lets Mythril assume the mapping says whatever suits it |
| SWC-113, multiple calls in one transaction | 4 | `ScaledFxBandOracle.brlCentsPerUnit`, `LidoStakingAdapter.claimExit`, both routers' `rescue` *(both routers since removed)* | Two calls each, to immutable addresses (the band's two sources; Lido's queue and WETH) or to the pool and then the deposit's own recipient. Nothing loops over a list of strangers' contracts |
| SWC-105, unprotected ether withdrawal | 1 (CI run) | `OffRampEscrow`'s private `_send`, attributed to `cancelSale` | Unconstrained storage lets Mythril choose the sale it pays out: seller = the caller, state OPEN, `refundTo` = the caller, `weiAmount` = the whole balance. In the contract all four are written by `openSale`, by the seller, against ETH that seller paid in; `cancelSale` checks `s.seller == msg.sender` and OPEN, writes CANCELLED before paying, is `nonReentrant`, and pays exactly that sale's amount to the address the seller named. Checked against the source rather than taken on trust |
| SWC-114, transaction order dependence | 1 (CI run) | the same payout | The payout depends on the sale's state, which another transaction can change - the state machine doing its job. A claim landing before a cancel is the race `OPEN`/`CLAIMED` exists to resolve, and the loser reverts with `WrongState` rather than anyone being paid twice; those interleavings are what the escrow invariant fuzzes |
| SWC-124, write to an arbitrary storage location | 1 | `LidoStakingAdapter.claimExit` | The swap-and-pop `_pending[i] = _pending[_pending.length - 1]`. Unconstrained storage lets Mythril give that array any length, so its element slot looks arbitrary; the slot written is the array's own, and only this contract's push and pop change its length |

### 3.1 Two runs of the same commit do not find the same things

Symbolic execution here is bounded by wall-clock time, so how far it gets depends on the machine. Two runs of
the same workflow on the same commit (`ab07cd5`, one from the push trigger and one from the pull-request
trigger) gave different Mythril results: one reported 119 findings and passed, the other 122 and failed
against the first version of this gate. Nothing about the contracts differed - only which paths each runner
reached inside the same budgets. Three full local runs of the 27 contracts agree with that picture:

| | reference | run A | run B | CI (two runs of `ab07cd5`) |
|---|---|---|---|---|
| findings | 119 | 120 | 121 | 119 and 122 |
| distinct (contract, mode, class) | 47 | 48 | 48 | - |
| verdict under this gate | pass | pass | pass | pass (replayed) |

All three local runs used the same settings (600 s per source analysis, 300 s per runtime one, depth 128, two
transactions, two parallel analyses) and all three were judged by the final gate. The runner's retry existed
for run B only; run A's three killed analyses were re-run by hand at the same settings, which is what the
retry now does by itself.

What varies, measured between run A and run B:

- **Which public function a finding is attributed to** - 7 differences. Mythril names the function its run
  reached the code through: `OffRampEscrow`'s private `_send` came back as `cancelSale` on one runner, the
  same nested call in `ShieldedTransferRouter` as `transfer(...)`, `encodeTransfer` and `fallback` on three
  different runs.
- **Whether a class is reported at all on a contract** - 4 differences (each way: `NodeRewards` SWC-101 and
  `ShieldedTransferRouter` SWC-116 in A only; `OffRampEscrow` SWC-107 and `ShieldedYieldRouter` SWC-116 in B
  only), when a path is a few seconds beyond the budget.
- **Coverage** - within a point for most analyses, but up to 24 points where a retry changed the exploration
  order (`NodeRewards` source: 37.9% in A, 61.5% in B). Per contract, the *best* coverage across modes barely
  moves: the least-covered contract reads 27.9%, 27.9%, 27.8% across the three runs.

**How the gate absorbs that without going blind.**

1. **Findings match on contract, mode, SWC class and a function pattern** (`*` covers every function), with the
   reason recorded per entry naming the sites it covers. Function names and titles are not part of the key.
2. **SWC-116 and SWC-123 are triaged per contract from the source**, not one Mythril report at a time, because
   which of them a run surfaces is exactly what moves. Both shapes have been read at the site on every
   contract that can produce them, and a contract is listed only if its deployed code can: 24 of the 27
   compile a `TIMESTAMP` opcode and 25 make an external call, so `ERC4626Adapter`, `ScaledFxBandOracle` and
   `ShieldedNoteLog` are not listed for SWC-116, and `AuditGrantRegistry` and `ShieldedNoteLog` not for
   SWC-123 - one of those reporting it would be news and would fail. The other classes stay evidence-driven.
3. **An entry that matches nothing is printed as unused and never fails.** With classes pre-triaged, 18 to 19
   entries are unused in a given run; that is the variance, made visible.
4. **Resource noise is retried, not scored.** An analysis the kernel kills at the memory cap, or one that
   throws inside z3 after exploring, is retried once at half the budget (memory use tracks how far it got).
   Run B needed 16 retries on a loaded machine and still passed. An analysis that leaves no result after that
   is reported but does not itself fail the run; a registry hiccup no longer fails it either, since the image
   is pinned by digest and a local copy is the same bytes.

**What still fails, and was checked by injection rather than assumed:** a class nobody has triaged on that
contract (an SWC-112 delegatecall planted on `FiatEscrow` - fails); one of the runtime mode's artifacts
appearing in the source mode, where storage is whatever the constructor left (SWC-105 planted on
`OffRampEscrow` source - fails); a contract no mode explored (both of `ShieldedNoteLog`'s reports emptied -
fails); and the coverage floor, 20% of a contract's runtime in its best mode, which has about eight points of
margin on the least-covered contract.

**The six analyses that explored nothing** (all source mode; each contract is covered by its runtime mode):
`AttestorQuorumVerifier`, `ReclaimZkTlsVerifier` and `SignedPriceOracle` take arrays in their constructors
(attestors, witnesses, publishers) and loop over them, and Mythril finishes creation with no deployed state;
`ERC4626Adapter`, `LidoStakingAdapter` and `SuperstateUSTBAdapter` call the contracts they are wired to
during construction (`target.asset()`, the feed's `decimals()`, `redemption.USDC()`), which have no code at a
symbolic address. These are listed in the allowlist with those reasons, so they are visible rather than
silent, and they are the reason the script also requires a minimum coverage per contract.

### 3.2 Five more contracts (18 October 2026)

`scripts/mythril.sh` now also covers `DivergenceBreaker`, its two rate sources (`ChainlinkCrossSource`,
`UniswapV3TwapSource`), `LimitedYieldVault` and the hedge sleeve's `HedgeSubWallet`, 30 contracts in all.
`SimHedgeVenue` (TEST ONLY) and `contracts/hyperliquid` (an optional adapter, deployed nowhere) stay out.

Run locally under podman, both modes, `MYTHRIL_JOBS=2`:

| Contract | Source mode | Runtime coverage | Findings |
|---|---|---|---|
| DivergenceBreaker | not explored (a symbolic `SourceConfig[]`) | 93.1% | 2: block.timestamp in `poke`, multiple calls in `sourceRates` |
| ChainlinkCrossSource | not explored (calls `decimals()`) | 24.6% | 1: the runtime self-call artifact |
| UniswapV3TwapSource | not explored (calls `decimals()`) | 15.4%, under the 20% floor | 1: the runtime self-call artifact |
| LimitedYieldVault | 17.9% | 59.7% | 5: YieldVault's harvest findings, inherited; the redemption timelock |
| HedgeSubWallet | not explored (calls the venue and feeds) | 38.0% | 11: windows and timelocks, the self-call artifact, scheduled setters |

None is exploitable. Each is triaged by class in `scripts/mythril-allowlist.txt`, with the site it covers:
- block.timestamp in windows of minutes to days;
- runtime code calling itself at address 0 with zero immutables;
- setters reached through `DelayedGovernance.execute`;
- the breaker's reads, each a gas-capped staticcall whose failure marks that source dead, so one bad source cannot
  stop the others.

`UniswapV3TwapSource` is listed as THIN COVERAGE. Its one function is a pool read that the runtime mode cannot get
past, and its arithmetic is covered by `MovvaBreaker.t.sol`'s TWAP tests. With these entries the gate reports
20 findings, 0 not allowlisted, 0 analyses failed.

## 4. Circomspect

**Version.** Circomspect 0.9.0 (Trail of Bits), built with `cargo install circomspect --version 0.9.0
--locked`; it publishes no release binaries.

**Command.** `bash scripts/circomspect.sh` (the CI job `circomspect`), which runs

```
circomspect --level WARNING --sarif-file <out> protocol/circuits/circuits/*.circom
```

and gates the SARIF against `scripts/circomspect-allowlist.txt` by analysis id, file and line. It fails on a
warning not listed there, and also unless all three templates were actually analysed: circomspect answers
"No issues found" and exits 0 for a file it cannot read, which must not pass as clean.

**Coverage.** `commitment.circom` (`CommitmentHasher`), `merkleTree.circom` (`LeanIMTInclusionProof`) and
`withdraw.circom` (`Withdraw`), as they exist today: upstream's circuits, audited by Oxorio
(`protocol/audit/circuits_audit_oxorio.md`), byte-identical to upstream and checked against their vendored
artifacts by `npm run verify`. They were not edited. circomlib, which they include, is a dependency and is
not analysed, as Slither leaves OpenZeppelin alone. The circuits are built as `Withdraw(32)` and
`LeanIMTInclusionProof(32)` (`protocol/circuits/scripts/verify-artifacts.mjs`); circomspect analyses the
templates in the files it is given, so running it on `main` wrappers adds nothing (tried: it reports on no
template at all).

**Result.** 3 warnings, 0 errors; at INFO level, 7 more notes. None is a vulnerability.

| Id | Where | Finding | Why it is not a vulnerability |
|---|---|---|---|
| CS0017 | `withdraw.circom:111` | The intermediate signal `contextSquared` occurs in only one constraint | That constraint is the point. `context` (a hash binding the proof to the withdrawal's calldata and scope) is a public input that no other constraint uses; a Groth16 public input in no constraint is bound only if the proving toolchain adds constraints of its own for it (snarkjs does). Squaring it puts it in the circuit's own constraints, whatever the toolchain. `contextSquared` is fully determined by that one constraint and needs no other. It is Tornado Cash's `recipientSquare`, and the fix Oxorio recommended for `actualDepth` |
| CS0018 | `withdraw.circom:100` | The output `nullifierHash` of the new commitment's `CommitmentHasher` is not constrained | Deliberately discarded (`_ <== newCommitmentHasher.nullifierHash`, line 108): the new commitment's nullifier hash is revealed only when that commitment is spent later. `newNullifier` is still bound, through `newCommitmentHash` (Poseidon over the precommitment of nullifier and secret) and the check that it differs from the existing nullifier |
| CS0010 | `merkleTree.circom:50` | `Num2Bits(maxDepth)` may alias; consider `Num2Bits_strict` | Aliasing needs a bit width of 254 or more, where two decompositions can reach the same field element. The circuit is instantiated with `maxDepth = 32`: `Num2Bits(32)` forces `leafIndex < 2^32` with a unique decomposition |

The INFO notes: field arithmetic at `withdraw.circom:85` (`existingValue - withdrawnValue`, safe because both
`remainingValue` and `withdrawnValue` are range-checked to 128 bits, so an underflow, which lands near the
field modulus, fails the check; this is Oxorio's fixed finding "Lack of check for existingValue"), at
`withdraw.circom:111` (the squaring above), at `merkleTree.circom:74` (the multiplexer
`(a - b) * s + b` with `s` a bit from `IsZero`), and on `maxDepth + 1`, `i + 1`, `i++` and `i < maxDepth`
(`merkleTree.circom:31, 58, 74`), which are compile-time template parameters and loop variables, not signals.
The one upstream design point an auditor raised and left open, `actualDepth` not bounding the LeanIMT proof
("Potential inclusion proof manipulation", acknowledged as inapplicable because leaves are Poseidon(3)), is
not something circomspect flags and is in audit-scope.md's upstream section.

## 5. Build reproducibility

**Method.** The root project built twice with the pinned Foundry (`forge build --skip test --skip script`),
from this checkout into a scratch output directory and from a fresh `git clone` of it into another directory
(dependencies copied in as `npm ci` and `scripts/link-libs.mjs` would place them: `@openzeppelin/contracts`
5.1.0 and `forge-std`, linked into `lib/`). Then the runtime and creation bytecode of every artifact compiled
from `contracts/` outside `test/` and `script/` compared byte for byte, and again with the CBOR metadata
stripped.

**Result.** 38 of 38 artifacts identical, runtime and creation, including the metadata hash. They also match
the `forge-out/` the deploy script uses, byte for byte. Foundry hands solc project-relative source names and
remappings, so no absolute path reaches the metadata, and no setting needs to change. (Had they differed, the
usual culprit is an absolute path in the metadata; the fix would have been relative remappings, not
`bytecode_hash = "none"`, which would change every contract's bytecode and its source verification.)

## 6. Before deploying

- **Nothing to escalate from the tools.** No finding needs a contract change, and no invariant failed on the
  real contracts.
- **The Mythril job's trigger is a decision for you.** `invariants` and `circomspect` are fast and belong on
  every push. `mythril` takes about an hour and a half on four parallel analyses, and it runs twice on a
  pull request from a branch of this repository (once for the push, once for the PR), which is what produced
  the two differing runs above. The workflow is unchanged and still runs it on every push; the trigger I would
  use instead is a nightly schedule plus pull requests and manual dispatch:

  ```yaml
  # in the mythril job
  if: github.event_name != 'push' || github.ref == 'refs/heads/master'
  ```

  with `schedule: - cron: '0 3 * * *'` and `workflow_dispatch` added to the workflow's triggers. That keeps a
  daily result and a result on every pull request, without an hour and a half on every branch push. Say the
  word and it is a four-line change.
- **What the tools do not cover.** The invariants use the unit tests' attestor, oracle and pool stand-ins,
  so they test the escrows' accounting and state machine, not the zkTLS verifier (its own tests,
  `ReclaimZkTlsVerifier*.t.sol`, do that) or the pool. They do not drive `rescueShielded` (the pool
  stand-in has no ragequit; `RampRescue.t.sol` and `RampRescueFork.t.sol` test it) or governance changes
  mid-run (revoking an attestor or arbitrator, relisting an asset; their unit tests do). Mythril is bounded - two transactions,
  a depth of 128, and ten minutes per source-mode analysis or five per runtime-mode one - and reasons about a
  Shanghai build of the same source (section 3). Circomspect does
  not look into circomlib. Decision 1 in rev3-conformance.md (who mints MOVVA) is still open, and if the
  escrow becomes the minter, the supply invariant moves to the escrow's mints and burns.
