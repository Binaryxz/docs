# Testing Phase 1 yourself

Two paths. The first needs nothing but this repo and about five minutes. The second brings
up a chain and exercises the whole rail end to end.

Nothing here needs a phone, a browser, or an account anywhere.

---

## 1. Offline — no chain, no network, no keys

```bash
git clone https://github.com/alleycat1/mova
cd mova
git checkout phase-1-shielded-rail    # <- REQUIRED until PR #1 is merged
npm install                            # also links forge-std and lean-imt for foundry
npm test                               # 2303 tests (163 files, 18 October 2026)
```

**The checkout is not optional.** Phase 1 lives on a branch; `master` is still the
pre-Phase-1 state and has no `packages/mpc`, no `packages/smart-account` and no `protocol/`.
A plain clone runs a much smaller suite and looks like it worked. Verified from a clean
clone — omitting it was a real defect in an earlier version of this guide.

Expected from a fresh clone, in order:

```
npm install     ends with  link-libs: lib/forge-std -> node_modules/forge-std
                           link-libs: protocol/contracts/lib/lean-imt -> ...
npm test        Tests  2303 passed (2303)
```

`forge` is not on `$PATH` by default after a foundryup install, and this repo pins its own
version anyway:

```bash
FORGE=$(bash scripts/foundry.sh path)   # prints "fetching foundry v0.3.0" on first use
$FORGE test                             # 948 tests passed, 0 failed (fork suites pass by skipping without FORK_RPC)
```

The Kernel validators are their own Foundry project, and both smart accounts run end to end on a local
anvil with no RPC:

```bash
(cd packages/smart-account/contracts && $FORGE test)          # passkey + co-signer, FROST, recovery adapter
FOUNDRY_OUT=forge-out npx tsx packages/smart-account/examples/accounts-live.ts
#   a Safe and a Kernel account through EntryPoint v0.7, the Alto bundler and SponsorPaymaster:
#   passkey + co-signer, FROST 2-of-2, ERC-1271, and recovery after the cooldown. Needs the root
#   forge build (for SponsorPaymaster); prints OK/FAIL per check and exits non-zero on a failure.
FOUNDRY_OUT=forge-out npx tsx packages/cosigner/examples/cosigner-live.ts
#   the server co-signer as a process (anvil 8930-8939): enrolment before deployment, co-signing only over a
#   verified passkey signature, authority changes refused, the recovery veto, sponsorship through SponsorGate
#   at enrolment, a recovery alert received and decrypted at a local push endpoint, and a real FROST key
#   generation over /v1/frost/dkg/* whose group key becomes a Kernel account that signs through the bundler
npx tsx packages/smart-account/examples/erc7562-live.ts
#   ERC-4337's validation rules: the account stack copied into a geth --dev genesis and every scenario sent
#   through Rundler in safe mode (both downloaded and SHA-256 checked; about 6 minutes, ports 8960-8968).
#   geth needs about 1 GB of working space and refuses to start on a small or nearly full /tmp: point
#   ERC7562_WORKDIR (and, for the app's browser tests, TMPDIR) at a directory on disk where that is true.
bash scripts/slither-smart-account.sh    # Slither over the Kernel contracts, file by file
```

The venue-neutral hedge sleeve (docs/delta-neutral.md section 12). The forge tests run in the suite
above, invariants included. The vitest files start their own anvils: `hedge-risk-onchain.test.ts` on 8963
and `hedge-sleeve.test.ts` on 8964, the latter with Safe 1.4.1 from the vendored fixtures. The fork
scripts need SEPOLIA_RPC and use ports 8960-8964, which `erc7562-live.ts` also uses, so do not run them
together:

```bash
npx tsx scripts/hedge-sleeve-rehearsal.ts      # the whole funding path on a Sepolia fork, every step printed (8960)
npx tsx scripts/deploy-hedge-sleeve.ts         # B7 dry run: fork deploy + checks + Sepolia gas projection (8961)
```

The app in a real browser. Headless Chromium drives a virtual passkey authenticator with PRF against the dev
stack (anvil, the contracts, an LP node, the matcher, a relayer, the account stack with Alto, and the
co-signer with sponsorship and alerts on, on ports 8980-8989):

```bash
npx playwright install --with-deps chromium     # once
npx playwright test -c packages/app/e2e         # onboarding, buy, sell, resume, re-shield, escape hatch, veto, alerts
npx tsx packages/app/scripts/dev-stack.ts       # or the stack by hand, then http://localhost:8981
npx tsx packages/app/scripts/smoke.ts           # a buy and a sale against it, headless, without a browser
```

The same flows with the off-chain services running from the services image (packages/ops/Dockerfile) instead of
from source - the LP node, matcher, note vault, co-signer and monitor as containers with `--network=host`;
anvil, Alto and the gateway stay on the host. No Docker daemon is needed: podman builds and runs it
(`CONTAINER_RUNTIME=docker` for docker). Details in packages/app/README.md, "Image mode".

```bash
podman build --network=host --format docker -f packages/ops/Dockerfile -t localhost/mova-services:dev .
MOVA_SERVICES_IMAGE=localhost/mova-services:dev npx playwright test -c packages/app/e2e   # starts and removes its own containers
MOVA_SERVICES_IMAGE=localhost/mova-services:dev npx tsx packages/app/scripts/dev-stack.ts # or by hand: wait for the table
npx tsx packages/app/scripts/smoke.ts                                                    # against it, from another terminal
podman ps --filter name=movva-dev-                                                       # the six containers
# Ctrl+C in the stack's terminal stops and removes them: `podman ps -a --filter name=movva-dev-` is then empty
```

Three things worth running on their own, because each demonstrates a claim rather than
exercising code:

```bash
npx tsx packages/mpc/examples/two-party-sign.ts
#   the FROST protocol printed step by step: what each party sends, why the second
#   party cannot grind the nonce, and what one party alone can and cannot do

npm run demo
#   the audit viewing key: issue a scoped disclosure, audit it, revoke it

npm run slither
#   static analysis over our contracts; exits clean, triage in docs/audit-scope.md

"$(bash scripts/foundry.sh path)" test --match-contract Invariant -vv
#   the invariant suites: escrow single settlement, Movva supply against its mints and burns, NodeRewards
bash scripts/mythril.sh
#   Mythril over the 25 contracts we deploy, from the constructor and from arbitrary storage, in its pinned
#   container (podman or docker); about two hours at MYTHRIL_JOBS=3. Triage in docs/security-tooling.md
bash scripts/circomspect.sh
#   Circomspect over the circuits; needs `cargo install circomspect --version 0.9.0 --locked`
```

### The full verification

```bash
npm run verify                # 14 checks, ~5 min; needs network and, for the integration
                              # checks, RPC URLs in .env
npm run verify -- --offline   # 7 checks, 0 failed — what a clean clone with no .env gives
```

The count differs by what your environment can reach, so read the **`0 failed`**, not the
total: checks that cannot run are skipped and reported as skipped, never as passes.

This is the one to run if you only run one thing. It checks that the fork is byte-identical
to upstream, hash-checks all 14 zk artifacts, recompiles all three circuits to identical
R1CS, and runs 110 audited unit tests, 52 integration, 18 circuit, 13 relayer and ours.

CI runs the same checks on every push, so a green badge means these passed on a clean
machine rather than on mine.

---

## 2. Against a chain

### Sepolia — the Movva rail is not deployed yet

The 8 September Phase 1 stack on Sepolia is **abandoned**: its `OWNER_ROLE` sits on a key that is lost, so it cannot be
upgraded, renounced or reconfigured, and nothing here points at it any more (it is recorded, and monitored for
activity, in [deployments/abandoned-sepolia-2026-09-08.json](deployments/abandoned-sepolia-2026-09-08.json)). The rail
itself - token, reserve, the Movva pool, the escrows, the oracles - has been **rehearsed on a fork of
Sepolia but never broadcast**, because the deployer holds no ETH. See [docs/deployments.md](docs/deployments.md).

To rehearse the whole rail exactly as the real run would do it, on an anvil fork and with nothing broadcast:

```bash
set -a; . .env; set +a            # needs SEPOLIA_RPC in .env, and nothing else
npx tsx scripts/deploy-movva-rail.ts               # 59 transactions (69 with --finalize), then every check
npx tsx scripts/deploy-movva-rail.ts --finalize    # the same, then renounce every role
```

Each run writes `deployments/<name>/VERIFICATION.md` (what was deployed and where, the build hash, every check, every
privilege that remains). A real run needs about 0.25 Sepolia ETH on the deployer, and about 1.3 if the paymaster is
staked too ([docs/runbook-mainnet-deploy.md](docs/runbook-mainnet-deploy.md)).


### A local fork — everything, including the parts that need a bundler

A mainnet fork is the fastest way to exercise the whole rail, because CreateX, EntryPoint
v0.7 and the Safe contracts already exist on it.

```bash
set -a; . .env; set +a          # needs ETHEREUM_MAINNET_RPC
anvil --fork-url $ETHEREUM_MAINNET_RPC &

# deploy the protocol, then our contracts
cd protocol/contracts
A=0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266   # anvil #0
OWNER_ADDRESS=$A POSTMAN_ADDRESS=$A DEPLOYER_ADDRESS=$A ETHERSCAN_API_KEY=unset \
  $FORGE script script/Deploy.s.sol:EthereumMainnet --rpc-url http://127.0.0.1:8545 \
  --broadcast --private-key 0xac09...ff80 --slow
cd ../..
```

Note the addresses it prints, then:

```bash
# 1.5 — deposit, shielded balance, direct withdrawal
npx tsx packages/viewing-key/examples/live-pool.ts $ENTRYPOINT $POOL

# 1.3 — private withdrawal: user signs nothing, funds land at a fresh address
cd protocol/relayer && CONFIG_PATH=./config.local.json node dist/index.js &
cd ../..
npx tsx packages/viewing-key/examples/relayed-withdraw.ts $ENTRYPOINT $POOL

# 1.2 — passkey as a real on-chain Safe owner (P-256 verified on-chain)
npx tsx packages/smart-account/examples/passkey-owner.ts $ENTRYPOINT $POOL

# 1.2 — MPC: Safe with ONE owner that is a 2-of-2 FROST group
npx tsx packages/smart-account/examples/mpc-owner.ts $ENTRYPOINT $POOL

# 1.2 — gasless: the user holds no ETH at all
$FORGE create contracts/SponsorPaymaster.sol:SponsorPaymaster --broadcast \
  --rpc-url http://127.0.0.1:8545 --private-key 0xac09...ff80 \
  --constructor-args 0x0000000071727De22E5E9d8BAf0edAc6f37da032 $A
npx tsx packages/smart-account/examples/gasless-deposit.ts $PAYMASTER $ENTRYPOINT $POOL

# 1.2 — through a real bundler over the ERC-4337 RPC
export BUNDLER_EXECUTOR_KEY=0x7c85... BUNDLER_UTILITY_KEY=0x47e1...
npm run bundler &
npx tsx packages/smart-account/examples/bundler-deposit.ts $PAYMASTER $ENTRYPOINT $POOL
```

Every example prints `OK` / `FAIL` per assertion and exits non-zero on failure, so they can
be run unattended.

### Real hardware — the one part that cannot be automated

```bash
npx http-server packages/smart-account/browser -p 8080
# open http://localhost:8080/passkey-check.html
```

A USB security key is enough; no phone required. It reports whether your authenticator
supports the PRF extension, derives the pool seed twice and requires them identical, then
signs one challenge twice and requires the signatures to **differ** — which is why the seed
comes from PRF and not from a signature.

This is also how to decide the open PRF-fallback question: run it on the platforms your
users actually have.

---

## 3. The BRL ramp (Phase 2)

Needs the local fork from section 2 running, with Privacy Pools deployed — the ramp settles
into that same pool. Each script deploys its own ramp, so there is nothing else to set up.

PIX, boleto and TED settle only on a zkTLS proof of the bank session (SR2-34 in
`docs/security-review-phase2.md`): the escrows refuse a bank-rail offer or sale on a verifier that does not
prove the session (`BankRailNeedsZkTls`); the attestor quorum and the card rail were removed on 24 September 2026
(`docs/card-rail-removal.md`). There is no Reclaim application credential or bank
template yet, so a script that settles a bank payment proves it with a local test witness registered on
the zkTLS verifier. That exercises the verifier and the escrows, not Reclaim's network or a real bank.

```bash
export EP=<privacy pools entrypoint>     # printed by the protocol deploy
export PL=<privacy pools pool>
export FORGE=$(bash scripts/foundry.sh path)   # zktls-onramp runs the deploy script with it

npx tsx packages/ramp/examples/onramp.ts       $EP $PL   # BRL in by PIX or boleto -> shielded balance
npx tsx packages/ramp/examples/offramp.ts      $EP $PL   # shielded -> BRL, a paid bill, and disputes
npx tsx packages/ramp/examples/zktls-onramp.ts $EP $PL   # same, settled by a zkTLS proof
npx tsx packages/ramp/examples/matcher-live.ts           # the matching service
```

Run `offramp.ts` **last** on a shared fork: its dispute steps advance the chain clock by a day
and then by 30 days (`evm_increaseTime`), which is harmless to the scripts that deploy their own
contracts afterwards but confusing to read in a block explorer.

What each one is actually proving, beyond printing OK:

| Script | The assertion that matters |
|---|---|
| `onramp` | our independently rebuilt Merkle root equals the pool contract's after the release, and the same bank receipt cannot settle twice. Then a boleto order: the LP issues a real-format line for the order's exact amount and commits to it on-chain, the taker opens the commitment (and would refuse one R$ 1,00 dearer), a PIX receipt of the same money is refused, and the boleto receipt releases |
| `offramp` | a second LP cannot claim a sale another LP holds. Then a **bill**: the SDK refuses a sale priced off the bill's amount, the escrow refuses a boleto payee with a PIX rail, the LP opens the commitment before claiming, a proof of the wrong amount is refused (`WrongAmount`), and the paid bill settles. Then **disputes**: the desk reads a case from the chain and signs; the LP posts the ruling, cannot execute it early, and executes it a day later with no governor transaction; the desk recognises the posted ruling as its own; and a dispute nobody rules on is refused early, then expired by a stranger 30 days on, refunding the seller and freeing the LP's credit |
| `zktls-onramp` | deploys through `contracts/script/DeployRamp.s.sol` — the real script, which asserts its own wiring and closes setup — with one allowlisted bank endpoint; the governor cannot admit an LP without the delay, and a genuine proof presented against a **different** order is refused |
| `matcher-live` | the book follows the chain (a closed offer leaves it unprompted), and the service source contains no signer, no `writeContract`, no `sendTransaction`. Needs only an ETH/USD Chainlink feed at mainnet's address, so it also runs on a plain anvil with a mock feed planted there |

Every example wires its contracts during **setup**, when changes are immediate and user
business is refused, and then calls `completeSetup()` - the same order the deploy script
uses.

A representative run (mainnet fork at block 25970828, 2026-09-13):

```
onramp     R$ 6.271,93 paid by PIX  ->  0.4975 ETH shielded, root matches the contract
           R$ 2.508,77 paid by a boleto the LP issued for the order -> 0.2 ETH to the taker
offramp    1 ETH escrowed           ->  R$ 12.543,85 to the seller by PIX
           R$ 389,90 bill paid by boleto; ruling posted, executed a day later; 30-day expiry
zktls      proof verified on-chain; a proof for another order refused
matcher    quotes the cheaper LP; routes a boleto-only taker to the LP that accepts boletos
```

### Boletos and disputes, offline

```bash
npx vitest run packages/ramp/test/boleto.test.ts packages/ramp/test/pix-key.test.ts \
  packages/ramp/test/arbitration-desk.test.ts
$(bash scripts/foundry.sh path) test --match-contract "FiatEscrowTest|OffRampEscrowTest|LPExposureThroughEscrowsTest|ZkTlsRampIntegrationTest"
```

The boleto vectors are the specifications' own worked examples (FEBRABAN arrecadação v07,
Bradesco's cobrança layout) and lines built by an independent implementation - including both
sides of FEBRABAN's 22/02/2025 due-date factor restart. The forge suites perform the attacks:
a boleto proof against another order, another boleto, the wrong amount or the wrong rail; a
dispute with no governor, no desk, a late ruling, an early expiry, a replayed ruling and a
stolen arbitrator key; and a fuzzed run through every way an order or sale can end that checks
the escrows' balances and the registry's exposure after each step.

### Bank rails and the FX rate, offline

```bash
$(bash scripts/foundry.sh path) test --match-contract 'RampIntegration|SignedPriceOracle|ChainlinkSignedFxOracle|ChainlinkBrlOracle|PythBrlOracle|PythFxOracle|FxMarketHours|MovvaOffHours|MovvaFxLegGovernance'
```

`RampIntegration.t.sol` checks that a verifier that does not prove the bank session is refused for PIX, boleto and TED
offers on the on-ramp (`BankRailNeedsZkTls`).

The oracle suites perform the governance attack SR2-30 closed: a compromised governor adding itself as
a publisher and lowering the threshold is forced to schedule in public, and a rotated governor cancels
before it executes; one second before the delay ends, a Movva mint still prices at the honest rate. They
also freeze an oracle with a runaway sequence and show it is now bounded by the five-minute clock skew.

`PythFxOracle.t.sol` reads both of the Pyth leg's readings at every edge of the core session, over a
weekend, on Christmas and at the closed limit; refuses bad prices; pays for updates, which never go
backwards; and trades the ramps' USDT band all weekend on Friday's close (`FxMarketHoursTest` checks the
session itself, leap years included). `MovvaOffHours.t.sol` runs Mova's off-hours rule on the real reserve
and escrows: over a weekend mint, redeem and the ratio refuse while a Movva offer posts and a holder's sale
inside the band opens, and at Monday's core session the band too wants a fresh price before minting resumes.

### Both phases as one rail

The scripts above each prove a segment. This proves the joins:

```bash
npx tsx packages/ramp/examples/full-rail.ts $EP $PL
```

```
passkey (PRF)  ->  BRL in by PIX  ->  shielded balance in the real pool
               ->  a scoped disclosure an auditor verifies
               ->  real groth16 withdrawal to a fresh address
               ->  that address sells for BRL  ->  money in a bank account
```

Three things it checks that no other script did:

- the on-chain commitment **recomputes from the passkey wallet's own spending key**, so the
  shielded balance is the user's rather than the escrow's;
- an auditor reconstructs the BRL value of a **ramp** deposit, and the bundle carries no
  nullifier, secret or spending key;
- the off-ramp sale is funded by an **actual pool exit**, not by a transfer standing in for
  one — which is how the other off-ramp demo was written.

It takes a few minutes: two real groth16 proofs and about thirty transactions.

### The BRL price feeds, against real mainnet contracts

```bash
FORK_RPC=http://127.0.0.1:8545 \
  $(bash scripts/foundry.sh path) test --match-contract "PythFork|OracleFork" -vv
```

These pass by asserting that nobody has posted Pyth's FX.USD/BRL to Ethereum yet (Pyth publishes it
on Hermes, but a pull-based feed exists on a chain only once someone posts it there), and that the
BRL/USD proxy Chainlink's Feed Registry returns, `0x0eBDc65E7e9132Cb41ac5cbD0101B799D7aDb475`, is
gated to EOA readers and last updated in August 2023. That proxy is **retired**: the live one is
`0x3126E7F38D5f60f4E2B6ec3511C7bdbD79317Df1` (Chainlink's feed list, verified 19 October 2026), and a
contract reads it - `ChainlinkFxFork`, below. Mova's Pyth keeper posts FX.USD/BRL, so once it runs on
mainnet `PythFork` fails at any later block, which is the signal it was written to give; run it
against a fork from before the keeper's first update to keep testing the unposted case.

### Chainlink BRL/USD and ChainlinkFxOracle, against the real mainnet feed

```bash
MAINNET_FORK_RPC=https://ethereum-rpc.publicnode.com \
  $(bash scripts/foundry.sh path) test --match-contract ChainlinkFxFork -vv
```

Six tests (skipped without `MAINNET_FORK_RPC` or `FORK_RPC`). The live proxy's description and decimals; a contract
reading it and the band pricing at the fork's time; the rate inside and outside the core session at moments within the
real answer's validity window; the last ten heartbeat intervals fitting `MIN_MAX_AGE`; the retired proxy's August 2023
round and `No access`; and an unchanged `MovvaReserve` pricing through the leg with real USDT and USDT/USD. The public
RPC serves no archive state, so the suite forks the latest block and asserts what holds at any hour. On 19 October
2026 it passed: answer 19,752,930 (R$ 5,062540), 22 h old, longest of the last ten intervals 86,436 s.

### USDT on both ramps, against real mainnet contracts

No local node needed: `FORK_RPC` can be the public RPC.

```bash
FORK_RPC=https://ethereum-rpc.publicnode.com \
  $(bash scripts/foundry.sh path) test --match-contract "UsdtRampFork|UsdtFailureModesFork" -vv
```

22 tests against the real USDT token, Chainlink's USDT/USD feed and 0xbow's live Entrypoint, its
owner and its USDT pool. The on-ramp delivers USDT into the real pool as the taker's commitment; the off-ramp
pays the LP; expiry, stale claims, cancels and dispute timeouts refund. Tether's own powers are
used from its real owner address: the transfer fee, pause, blacklisting an LP, a recipient, an
escrow, the Entrypoint or the pool, and deprecation. Each outcome is in
`docs/security-review-phase2.md` (SR2-20 to SR2-29), including what the escrows now refuse while a
party is listed and how a paid taker whose shielded delivery became impossible takes it directly
(`takeDeliveryDirect`). The same safeguards run offline, and in CI, in `RampIssuerFreeze.t.sol`;
`IssuerFreeze.t.sol` checks the probe itself, against real USDT, USDC and WETH with `FORK_RPC` set.

The USDT band comes from `ChainlinkSignedFxOracle`: Chainlink's USDT/USD crossed with one BRL/USD leg,
Pyth's FX.USD/BRL by default or a quorum-signed rate, so one FX number serves every asset. USDT bought
and sold by PIX settles on both ramps by zkTLS proof.

### The LP node, end to end

```bash
npx vitest run packages/lp-node                                   # in-memory chain, MockBank, API Pix over mTLS
forge build                                                       # the artifacts it deploys
FOUNDRY_OUT=forge-out npx tsx packages/lp-node/examples/lp-node-live.ts   # starts its own anvil on :8745, ~1 min
```

The live run deploys the real escrows and registry, a zkTLS verifier for PIX and boleto,
then lets the node do an LP's whole job for ETH and a 6-decimal USDT: post
offers inside the band, serve a taker signed payment instructions, match the PIX credit and release on a
proof of the LP's bank session; issue a boleto; claim an off-ramp sale, wait for confirmations, pay,
prove the payout and collect. A bank response is then lost mid-payment and a new node process on the
same journal settles without paying twice. The bank and the zkTLS witnesses are the mocked parts; every
contract is real.

The unit suite also performs the node's operational failures: a stuck transaction replaced at the same
nonce under geth's replacement rules and a fee cap (anvil evicts rather than holds an underpriced
transaction, so a scripted node plays geth), journal compaction crashed after the write and after the rename
and with a torn file, a webhook body lying about amount, key and txid, and dispute evidence searched byte by
byte for a PIX key, salt, bank id or payer document.

### Movva: the LP node as a gateway, end to end

```bash
npx vitest run packages/lp-node/test/gateway.test.ts packages/lp-node/test/gateway-safety.test.ts
FOUNDRY_OUT=<build dir> npx tsx packages/lp-node/examples/lp-node-movva-live.ts   # anvil :8749, about 90 s
```

The safety file performs each refusal (no mint, not even simulated, while paused, frozen, stale, below the
ratio floor, at the supply cap or over the LP's fee limit; no redemption below par by default), the USDT
allowance quirk, a crash after approve, after broadcast and after the mint mined but before it was recorded,
reorgs shallower than `confirmations`, and a property test over random mixes of all of it: nothing refusable
is attempted, every mint is to a need, and no gateway transaction goes out while another is unfinished.

The live run deploys the real `MovvaReserve`, token, yield vault and the Movva escrow pair. The
node mints only what its Movva offer needs, a taker buys Movva by PIX, the node tops up only what was
drained, the same user sells Movva back, and the node redeems it at par less the fee - Movva supply falls.
It then pauses minting (the node reports `mint_paused`), drops the reserve to 94.99% (the offer is pulled
and Movva is held, not redeemed at a haircut), restores it, and restarts the node to show nothing is
minted or redeemed twice.

### Movva: the wallet, and an auditor, end to end

```bash
npx vitest run packages/wallet packages/viewing-key/test/intermediary-disclosure.test.ts
WALLET_FORGE_OUT=<build dir> npx tsx packages/wallet/examples/movva-wallet-live.ts   # anvil :8746
MOVVA_ACCOUNT=kernel ANVIL_PORT=8913 BUNDLER_PORT=8914 \
  WALLET_FORGE_OUT=<build dir> npx tsx packages/wallet/examples/movva-wallet-live.ts  # the user as a smart account
```

With `MOVVA_ACCOUNT=safe` or `kernel`, the user is a passkey + co-signer account. Every call it makes is a sponsored
UserOperation through EntryPoint v0.7, the Alto bundler and SponsorPaymaster, and each sale runs from a fresh smart
account. The run also covers:
- a sale resumed from persisted stores after its exit landed;
- a cancelled sale re-shielded, pending until the ASP approves it, then spendable;
- a delivery taken in the open and re-shielded;
- a sale across two notes;
- a bill due today refused at 23:30 in Brasília.

The run is the client's flow in one script, on a plain anvil with Mova's own Privacy Pools deployed directly (no
fork) and real groth16 proofs. The LP starts with USDT and no Movva; its node mints Movva at the reserve for its
PIX offer. The user buys by PIX and by boleto - each LP instruction verified on-chain first, a
node lying about its PIX key refused and the order cancelled for
free - and sells Movva back from an unlinked account; the node pays the PIX and redeems what it bought, which is
burned. (There is no saving step: savings was removed by client decision D1, 14 October 2026.) After every step Movva
supply, the reserve's USDT and the fee recipient's balance are checked against the reserve's events, so the fees
Mova earns on mint and redeem are proven, not assumed. Backing then turns `partial` and buying is
refused, and a stale rate makes it `unknown`. Finally the user issues audit grants, an auditor verifies both
balances against the chain and combines them into one statement for the period, the grant is revoked and the
vault refuses, and a second device recovers the same balance and seals its new notes past the revoked keys.

### Traditional providers: Banco Inter

```bash
npx vitest run packages/lp-node/test/banks
```

The adapter is tested against mocks built from the provider's published API documents (Inter's OpenAPI files), with every
request checked against a recorded schema, and through the real LP node: a response lost after Inter moved the money, a
refused connection, both journals lost. It has not run against the provider. (The Pagar.me card acquirer adapter was removed
with the card rail.) With sandbox credentials - never in CI:

```bash
npx tsx packages/lp-node/examples/bank-sandbox-check.ts        # lists Pix, queries a payment; R$ 0,01 only with its flag
```

It refuses a production host without an explicit flag.

## 4. Reserve yield (Phase 3)

The yield infrastructure is the Movva reserve's own: `MovvaReserve` holds its idle USDT in a `YieldVault`, and what
it earns is Mova's. The user-facing shielded yield round trip (the router, the share pool and its fork demos
`shielded-yield.ts` and `shielded-yield-usdt.ts`) was removed with savings (client decision D1, 14 October 2026).

Against real mainnet contracts:

```bash
FORK_RPC=http://127.0.0.1:8545 \
  $(bash scripts/foundry.sh path) test --match-contract "YieldFork|LidoAdapterFork|SuperstateUSTBFork" -vv
```

### Tokenized T-bills (Superstate USTB)

`SuperstateUSTBFork` needs no local node. `FORK_RPC` can be the public mainnet RPC itself. Set
`USTB_FORK_BLOCK` to pin a block, which needs an archive endpoint.

```bash
FORK_RPC=https://ethereum-rpc.publicnode.com \
  $(bash scripts/foundry.sh path) test --match-contract SuperstateUSTBFork -vv
```

It runs against the real USTB token, RedemptionIdle, SuperstateOracle and AllowlistV3. Whatever
only Superstate can do is done by pranking Superstate's own owner addresses (read from the
contracts) and calling Superstate's own functions:

- allowlisting the adapter;
- publishing a NAV checkpoint;
- draining the redemption facility.

The test's header lists each call. Expect:

```
fork block: 25970...
USDC out for 1,000,000 in, two days: 1000243957098     (6 decimals)
```

It also checks that:
- the largest NAV jump the oracle accepts leaves the vault's share price inside the adapter's bound;
- a revoked allowlist entry freezes only the USTB leg;
- the oracle's own expiry does not freeze the vault.

Unit tests cover what mainnet will not produce on demand (stale NAV, NAV drop, not allowlisted, empty
or failing facility, swapped subscription oracle):

```bash
$(bash scripts/foundry.sh path) test --match-contract "SuperstateUSTBAdapterTest|KeeperGateTest"
```

### USDT yield on Aave v3

```bash
FORK_RPC=https://ethereum-rpc.publicnode.com \
  $(bash scripts/foundry.sh path) test --match-contract AaveUSDTFork -vv
```

15 tests: a USDT `YieldVault` lending through `ERC4626Adapter` into Aave's USDT wrapper
(`0x7Bc3485026Ac48b6cf9BaF0A377477Fff5703Af8`). Real interest accrues over warped time; the supply
cap, borrowed-out liquidity, a frozen and a paused reserve, the wrapper's own pause, and USDT's
fee, pause and blacklist are each exercised. `docs/security-review-phase3.md` (SR3-8 to SR3-11)
records what each one found.

### Delta-neutral on Hyperliquid (HyperEVM)

The contract trades through CoreWriter and reads HyperCore through precompiles. In the tests, a
simulated HyperCore is etched at the real addresses. It applies actions only after the block, and
drops what HyperCore would reject.

```bash
$(bash scripts/foundry.sh path) test --match-contract "HyperCoreDeltaNeutralVaultTest|HyperCoreRoundingTest" -vv
```

Tests to look at:

- `test_ACompromisedKeeperFillingAtTheBandEdgeIsBoundedByTurnover` fills every order at its limit.
  It logs the loss, which must stay within turnover × (band + fee).
- `test_AFullExitWorksWithTheKeeperOffline` exits $300k with anyone-may calls only and logs the number
  of `processExits` steps.
- `test_PersistentlyNegativeFundingStopsNewExposureThenUnwinds`.

The read ABI, decoded against live HyperEVM mainnet (read-only `eth_call`s, no key):

```bash
HYPEREVM_RPC=https://rpc.hyperliquid.xyz/evm \
  $(bash scripts/foundry.sh path) test --match-contract HyperCoreReadFork -vv
```

`docs/delta-neutral.md` has the design, the verified facts with sources, the worst-case keeper loss,
what could not be verified, and the bridge decision the client has to make before any of this
touches the reserve's vault.

### Keepers

```bash
npx vitest run packages/yield      # keeper decisions, replica races, config, redaction, the funding model
```

- `vault-keeper` runs the L1 `YieldVault` through a `KeeperGate`, with one operator key per replica.
- `hl-keeper` asks the HyperEVM vault to `rebalance`/`harvest` and calls its anyone-may exit paths.

Both serve `/healthz`, `/readyz` and `/status`. Their Flux specs (`packages/ops/flux/vault-keeper.json`,
`hl-keeper.json`) explain why each is registered once per replica. Both are also in the compose file behind the
`keepers` profile. (The Movva distribution keeper, `movva-keeper`, was removed with savings: the reserve no
longer distributes.)

The Pyth keeper (`packages/yield`) posts Pyth's FX.USD/BRL to Ethereum from Hermes. Without it neither the
Movva reserve's rate nor the ramps' bands price on a real chain. Posting is permissionless and its key holds
no role.

`LidoAdapterFork` stakes through the real wstETH contract and prices it with Chainlink. It
also:

- sells on the real Curve pool;
- dumps 60,000 stETH into that pool to show an oracle-anchored minimum refuses the fill;
- queues an exit with Lido.

A long-running fork keeps mining with the wall clock while Chainlink's state stays frozen, so
setup re-stamps the feed's real answer as current when it looks stale. Tests about stale
feeds then mock it again.

The escrow's rescue index against the real pool's own `Deposited` event:

```bash
FORK_RPC=http://127.0.0.1:8545 PP_ENTRYPOINT=$EP PP_POOL=$PL \
  $(bash scripts/foundry.sh path) test --match-contract RampRescueFork -vv
```

Delta-neutral, over 180 days of real Hyperliquid funding and hourly prices (needs network,
no key):

```bash
npx tsx packages/yield/examples/backtest.ts
```

After the leverage table it checks the on-chain breaker: Hyperliquid's funding formula against every
published hourly rate, and the contract's 84-hour average against the backtest's 7-day mean. Run on
2026-09-13 it printed:

```
formula reproduces 4320 published hourly rates, max error 5.00e-11
EMA pause (< 0):         457 h   trailing 7-day mean < 0: 450 h   disagree: 109 h
```

## 5. Monitoring and admin tooling

Neither needs a chain of its own: point them at a fork, at Sepolia, or at mainnet.

```bash
npx vitest run packages/ops        # 228 tests: checks, alert transitions, HTTP surface
```

**The monitor.** Against the local fork from section 2:

```bash
RPC_URL=http://127.0.0.1:8545 PP_ENTRYPOINT=$EP PP_POOL=$PL \
  npm run -w @mova/ops monitor

curl localhost:9464/status    # the verdict, and every reading behind it
curl localhost:9464/metrics   # Prometheus exposition
```

Two behaviours worth checking yourself, because they are the design:

- **Stop the node and watch.** Checks turn `unknown`, not `ok` — a monitor that goes green
  because it cannot read is worse than none. The alert waits five minutes, so one flaky call
  is not a page.
- **`/healthz` stays 200 while the chain is broken.** The process is alive; the chain's
  verdict is `/status`. A monitor that marks itself unhealthy gets restarted by its
  supervisor exactly when it has something to report.

**The admin tool.** Dry run by default — it prints the call, the risk and a pasteable
`cast send`, and sends nothing:

```bash
npm run -w @mova/ops admin                                          # list every command
npm run -w @mova/ops admin -- vault:pause $VAULT                    # dry run
npm run -w @mova/ops admin -- lp:tier $REGISTRY $LP INSTITUTIONAL 500000               # dry run
npm run -w @mova/ops admin -- gov:schedule lp:tier $REGISTRY $LP INSTITUTIONAL 500000  # dry run
```

Add `--execute` with `GOVERNOR_KEY` set to send it. With a multisig governor, the dry run is
the workflow: the printed calldata is what you approve.

**Changes that raise risk wait.** Once a contract's setup is complete, admitting an LP, raising
a tier or credit, adding a verifier, arbitrator, attestor, witness or zkTLS endpoint, lowering
a threshold, listing an asset or opening a network phase reverts when sent directly
(`ChangeMustBeScheduled`). Schedule it with `gov:schedule <command> <args>`, and after the
contract's `GOVERNANCE_DELAY` send the same thing with `gov:execute`. Revocations, suspensions,
pauses and closing a phase are sent directly and apply at once. On a local fork,
`cast rpc evm_increaseTime 172800 && cast rpc evm_mine` skips the default 48-hour delay.

What each alert means and what to do about it is in
[docs/runbook-incidents.md](docs/runbook-incidents.md).

## What you should NOT expect to work

Stated so a failure here is not mistaken for a bug:

- **Nothing is audited.** `packages/mpc` and `contracts/SchnorrVerifier.sol` are
  from-specification cryptography written by one author. Do not put funds behind them.
- **No mainnet.** Sepolia and forks only.
- **PIX or boleto against a real bank.** They settle only on a zkTLS proof, and there is no Reclaim
  application credential or bank provider template yet; bank payments here are proven by a local test
  witness.
- **Minting Movva at a weekend.** Where the FX leg is Pyth's, the reserve refuses to mint or redeem outside
  market hours by design, while the bands keep trading on the last close.
- **Hosted bundlers and push services.** Smart-account operations have run through a local Alto and a local
  Rundler, and recovery alerts reached a local push endpoint; no hosted bundler or browser vendor push service
  has been used. A Kernel account's first operation through Kernel's meta factory is refused by a rule-enforcing
  bundler, so deploy it by a transaction first.
- **`SplitSeedSource`** (the no-PRF fallback) has unit tests but no wallet flow uses it; no
  example simulates a PRF-less device.
- **The relayer's fee-commitment validation** has three tests upstream left as empty
  `it.skip` stubs. See `docs/audit-scope.md`.
- **The DKG's transport is new and unaudited.** `packages/mpc/src/dkg-transport.ts` carries the
  protocol between device and server - every message signed by its sender's long-term key over a
  transcript binding the session, the identities and every round-1 payload, round-2 shares sealed
  to X25519 keys from round 1 - and `packages/cosigner` serves it on `/v1/frost/dkg/*`. It has
  unit tests for every refusal and a live run in `cosigner-live.ts`, but it is the newest
  cryptographic code in the repo and `docs/audit-scope.md` ranks it with `dkg.ts`. The signing
  session has no transport of its own beyond TLS, the API key and the per-request passkey
  assertion; it exchanges no secret.

## If something fails

| Symptom | Cause |
|---|---|
| `forge: command not found` | Use `$(bash scripts/foundry.sh path)`; the pinned version is not on `$PATH`. |
| `eth_getLogs` HTTP 400 | Free-tier RPC block-range cap. The fetcher adapts automatically; if it persists, set `POOL_DEPLOY_BLOCK`. |
| `RelayFeeGreaterThanMax()` | The pool's `maxRelayFeeBPS` is below base fee + gas in BPS. Withdraw more, or raise the ceiling — see FORK.md. |
| `AA21 didn't pay prefund` | The account has no ETH and no paymaster. That is the gasless demo's control case. |
| `AA24 signature error` | A signature the account rejected. For contract owners, check which ERC-1271 overload and magic value Safe expects. |
| Audited suite shows failures | You are not on the pinned foundry. `npm run verify` uses it for you. |
