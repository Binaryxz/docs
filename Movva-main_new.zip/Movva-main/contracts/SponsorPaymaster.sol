// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

/**
 * @title SponsorPaymaster
 * @notice Pays gas on behalf of allowlisted smart accounts, so a user never needs ETH.
 *
 * The rail's UX is BRL-only: the user deposits reais, sees reais, withdraws reais. Requiring
 * them to hold ETH to pay for their own transactions contradicts that at the first step.
 * This contract removes that requirement - the account transacts, the paymaster's EntryPoint
 * deposit covers the gas.
 *
 * DELIBERATELY SMALL. A paymaster sits in the validation path of every operation it
 * sponsors, so complexity here is risk. It holds no user funds and cannot move them: the
 * worst a bug can do is drain THIS contract's gas deposit, which is why sponsorship is an
 * explicit allowlist rather than open to anyone who asks.
 *
 * BUNDLER RULES (ERC-7562). Public bundlers simulate `validatePaymasterUserOp` under a tracer
 * and drop an operation whose validation breaks ERC-7562's rules. Checked against Rundler
 * v0.11.0 in safe mode on geth (packages/smart-account/examples/erc7562-live.ts):
 *  - Validation reads no block data. TIMESTAMP is banned there for every entity, staked or
 *    not [OP-011], and an earlier version read it to see whether a budget window had ended
 *    (Rundler: "paymaster uses banned opcode: TIMESTAMP"). The window is now expressed through
 *    `validationData`: an operation that does not fit the account's current window is returned
 *    with `validAfter` = the window's end, which the EntryPoint enforces (AA32 before then) and
 *    a bundler reports as not yet valid. `postOp` runs outside validation, reads the clock and
 *    opens the next window.
 *  - The paymaster MUST BE STAKED at the EntryPoint, with at least the bundler's minimum stake
 *    and an unstake delay of at least one day (ERC-7562's MIN_UNSTAKE_DELAY). Validation reads
 *    this contract's own storage (`maxCostAllowed`, the budget settings) [STO-031] and returns
 *    a context for `postOp` [EREP-050], and ERC-7562 allows both only to a staked paymaster
 *    (Rundler, unstaked: "entity stake/unstake delay too low", slot 2 = `maxCostAllowed`).
 *    docs/runbook-mainnet-deploy.md has the numbers.
 *
 * Not implemented on purpose:
 *  - no signature-based sponsorship (a verifying paymaster needs an off-chain signer in the
 *    critical path; the allowlist is auditable on-chain instead)
 *  - no ERC-20 fee collection (the treasury design is out of scope)
 * Limits that are enforced: `maxCostAllowed` per operation, and a per-account gas budget per
 * rolling window (`setBudget`, `setAccountBudget`).
 */
interface IEntryPoint {
    function depositTo(address account) external payable;
    function withdrawTo(address payable withdrawAddress, uint256 amount) external;
    function balanceOf(address account) external view returns (uint256);
    function addStake(uint32 unstakeDelaySec) external payable;
    function unlockStake() external;
    function withdrawStake(address payable withdrawAddress) external;
}

struct PackedUserOperation {
    address sender;
    uint256 nonce;
    bytes initCode;
    bytes callData;
    bytes32 accountGasLimits;
    uint256 preVerificationGas;
    bytes32 gasFees;
    bytes paymasterAndData;
    bytes signature;
}

contract SponsorPaymaster {
    /// @notice EntryPoint v0.7. Immutable: a swappable entrypoint is a swappable caller.
    IEntryPoint public immutable ENTRYPOINT;

    address public owner;

    /// @notice Accounts whose gas this paymaster will pay.
    mapping(address account => bool sponsored) public sponsored;

    /**
     * @notice Largest gas cost this paymaster will underwrite for a single operation.
     * @dev Bounds the damage from a sponsored account that is compromised or simply buggy:
     *      without it, one operation with an absurd gas limit drains the whole deposit.
     *      Zero means unlimited, which is only sensible on a local chain.
     */
    uint256 public maxCostAllowed;

    /**
     * @notice Rolling window over which a sponsored account's gas spend is budgeted.
     * @dev Zero disables the window: no spend is recorded, and a non-zero budget then only
     *      caps each operation. `maxCostAllowed` alone caps ONE operation; it does nothing
     *      about an allowlisted account that simply keeps transacting, which is the
     *      cost-control gap the window closes.
     */
    uint256 public budgetWindow;

    /// @notice Gas budget per account per window. Zero means unlimited.
    uint256 public defaultBudget;

    /// @notice Per-account override. Zero means "use the default".
    mapping(address account => uint256 budget) public budgetOf;

    /// @notice Gas settled against an account in its latest window (which may have ended).
    mapping(address account => uint256 spent) public spentInWindow;

    /// @notice When the account's latest window opened.
    mapping(address account => uint256 startedAt) public windowStartedAt;

    event SponsorshipSet(address indexed account, bool sponsored);
    event MaxCostSet(uint256 maxCost);
    event BudgetSet(uint256 window, uint256 defaultBudget);
    event AccountBudgetSet(address indexed account, uint256 budget);
    event GasSpent(address indexed account, uint256 amount, uint256 spentInWindow);
    event OwnerChanged(address indexed from, address indexed to);

    error NotOwner();
    error NotEntryPoint();
    error NotSponsored(address account);
    error CostAboveLimit(uint256 maxCost, uint256 limit);
    error BudgetExhausted(address account, uint256 spent, uint256 budget);
    error ZeroAddress();

    modifier onlyOwner() {
        if (msg.sender != owner) revert NotOwner();
        _;
    }

    modifier onlyEntryPoint() {
        if (msg.sender != address(ENTRYPOINT)) revert NotEntryPoint();
        _;
    }

    constructor(IEntryPoint _entryPoint, address _owner) {
        if (address(_entryPoint) == address(0) || _owner == address(0)) revert ZeroAddress();
        ENTRYPOINT = _entryPoint;
        owner = _owner;
    }

    /**
     * @notice Called by the EntryPoint during validation.
     * @dev The context is the account, so `postOp` can bill its budget without re-deriving
     *      anything. Deliberately not the cost: `postOp` is told the ACTUAL cost, and billing
     *      the pessimistic estimate would under-serve honest users.
     *
     *      `validationData` is 0 ("valid, no time bounds") when the operation fits the
     *      account's budget. When it does not fit the current window but would fit a fresh
     *      one, it is `validAfter` = the window's end and `validUntil` = 0 (no expiry): the
     *      EntryPoint refuses the operation until the window ends, and accepts it after, when
     *      the next window starts from zero spend. An operation larger than a whole budget,
     *      or with no window to wait for, reverts `BudgetExhausted`.
     *
     *      Reads no block data ([OP-011]; see the contract header). A window that has ended
     *      but not been settled still counts its old spend here, which can only turn "valid
     *      now" into "valid after a time already past", never the other way round.
     */
    function validatePaymasterUserOp(
        PackedUserOperation calldata userOp,
        bytes32,
        uint256 maxCost
    ) external view onlyEntryPoint returns (bytes memory context, uint256 validationData) {
        address account = userOp.sender;
        if (!sponsored[account]) revert NotSponsored(account);
        if (maxCostAllowed != 0 && maxCost > maxCostAllowed) {
            revert CostAboveLimit(maxCost, maxCostAllowed);
        }

        uint256 budget = budgetFor(account);
        if (budget != 0) {
            uint256 window = budgetWindow;
            uint256 spent = window == 0 ? 0 : spentInWindow[account];
            if (maxCost > budget || spent > budget - maxCost) {
                if (window == 0 || maxCost > budget) revert BudgetExhausted(account, spent, budget);
                uint256 opensAt = _windowEnd(windowStartedAt[account], window);
                // validAfter is 48 bits; a window that never ends in that range never reopens.
                if (opensAt > type(uint48).max) revert BudgetExhausted(account, spent, budget);
                validationData = opensAt << 208;
            }
        }

        return (abi.encode(account), validationData);
    }

    /**
     * @notice Called by the EntryPoint after execution, to bill actual gas to the budget.
     * @dev Must never revert. A revert here happens AFTER the user's call has already run,
     *      and in some modes bricks the operation - so every path is a saturating write with
     *      no requires, no external calls and no unbounded work.
     *
     *      This is where the window is settled, because the clock may be read here: an account
     *      whose window has ended, or that has no spend in it, starts a new window now.
     *
     *      Budgeting is enforced in `validatePaymasterUserOp` and settled here, which leaves
     *      one accepted imprecision: several operations in a single bundle each pass validation
     *      before any of them settles, so an account can exceed its budget by up to one
     *      bundle's worth. That overshoot is bounded by `maxCostAllowed` per operation (and a
     *      bundler's per-sender mempool limit), and the alternative - charging the estimate up
     *      front and refunding - adds failure modes to the path that must not fail.
     */
    function postOp(
        uint8,
        bytes calldata context,
        uint256 actualGasCost,
        uint256
    ) external onlyEntryPoint {
        if (context.length < 32) return;
        address account = abi.decode(context, (address));
        uint256 window = budgetWindow;
        if (window == 0) return;

        uint256 spent = spentInWindow[account];
        if (spent == 0 || block.timestamp >= _windowEnd(windowStartedAt[account], window)) {
            windowStartedAt[account] = block.timestamp;
            spent = 0;
        }

        unchecked {
            uint256 updated = spent + actualGasCost;
            // Saturate rather than overflow: an account pinned at the ceiling is refused by
            // validation, which is the correct outcome, and cannot wrap back to zero.
            if (updated < spent) updated = type(uint256).max;
            spentInWindow[account] = updated;
            emit GasSpent(account, actualGasCost, updated);
        }
    }

    /// @notice The budget applying to an account: its override, else the default.
    function budgetFor(address account) public view returns (uint256) {
        uint256 own = budgetOf[account];
        return own != 0 ? own : defaultBudget;
    }

    /**
     * @notice Gas spent in the account's current window, treating an ended window as 0.
     * @dev For off-chain readers. Validation does not call it: it reads the clock.
     */
    function spentSoFar(address account) public view returns (uint256) {
        uint256 window = budgetWindow;
        if (window == 0) return 0;
        if (block.timestamp >= _windowEnd(windowStartedAt[account], window)) return 0;
        return spentInWindow[account];
    }

    /// @dev start + window, saturating, so an absurd window cannot make `postOp` revert.
    function _windowEnd(uint256 start, uint256 window) internal pure returns (uint256 end) {
        unchecked {
            end = start + window;
            if (end < start) end = type(uint256).max;
        }
    }

    function setSponsored(address account, bool isSponsored) external onlyOwner {
        if (account == address(0)) revert ZeroAddress();
        sponsored[account] = isSponsored;
        emit SponsorshipSet(account, isSponsored);
    }

    function setSponsoredBatch(address[] calldata accounts, bool isSponsored) external onlyOwner {
        for (uint256 i; i < accounts.length; ++i) {
            if (accounts[i] == address(0)) revert ZeroAddress();
            sponsored[accounts[i]] = isSponsored;
            emit SponsorshipSet(accounts[i], isSponsored);
        }
    }

    function setMaxCostAllowed(uint256 maxCost) external onlyOwner {
        maxCostAllowed = maxCost;
        emit MaxCostSet(maxCost);
    }

    /// @notice Set the rolling budget window and the per-account default. Zero disables.
    function setBudget(uint256 window, uint256 perAccount) external onlyOwner {
        budgetWindow = window;
        defaultBudget = perAccount;
        emit BudgetSet(window, perAccount);
    }

    /// @notice Give one account a different budget. Zero restores the default.
    function setAccountBudget(address account, uint256 budget) external onlyOwner {
        if (account == address(0)) revert ZeroAddress();
        budgetOf[account] = budget;
        emit AccountBudgetSet(account, budget);
    }

    /// @notice Clear an account's spend, e.g. after a support decision. Owner only.
    function resetSpend(address account) external onlyOwner {
        spentInWindow[account] = 0;
        windowStartedAt[account] = block.timestamp;
        emit GasSpent(account, 0, 0);
    }

    function transferOwnership(address to) external onlyOwner {
        if (to == address(0)) revert ZeroAddress();
        emit OwnerChanged(owner, to);
        owner = to;
    }

    /// @notice Fund the gas deposit this paymaster spends from.
    function deposit() external payable {
        ENTRYPOINT.depositTo{value: msg.value}(address(this));
    }

    function getDeposit() external view returns (uint256) {
        return ENTRYPOINT.balanceOf(address(this));
    }

    function withdrawTo(address payable to, uint256 amount) external onlyOwner {
        ENTRYPOINT.withdrawTo(to, amount);
    }

    /**
     * @notice Stake at the EntryPoint. Bundlers refuse this paymaster's operations without it
     *         (see the contract header): at least their minimum stake, and `unstakeDelaySec` of at
     *         least 86400.
     */
    function addStake(uint32 unstakeDelaySec) external payable onlyOwner {
        ENTRYPOINT.addStake{value: msg.value}(unstakeDelaySec);
    }

    function unlockStake() external onlyOwner {
        ENTRYPOINT.unlockStake();
    }

    function withdrawStake(address payable to) external onlyOwner {
        ENTRYPOINT.withdrawStake(to);
    }

    receive() external payable {
        ENTRYPOINT.depositTo{value: msg.value}(address(this));
    }
}
