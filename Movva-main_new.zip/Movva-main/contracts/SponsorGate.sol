// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

/// @dev The part of SponsorPaymaster its owner can reach, plus the views the gate reads.
interface ISponsorPaymaster {
    function owner() external view returns (address);
    function sponsored(address account) external view returns (bool);
    function maxCostAllowed() external view returns (uint256);
    function budgetWindow() external view returns (uint256);
    function defaultBudget() external view returns (uint256);

    function setSponsored(address account, bool isSponsored) external;
    function setSponsoredBatch(address[] calldata accounts, bool isSponsored) external;
    function setMaxCostAllowed(uint256 maxCost) external;
    function setBudget(uint256 window, uint256 perAccount) external;
    function setAccountBudget(address account, uint256 budget) external;
    function resetSpend(address account) external;
    function transferOwnership(address to) external;
    function withdrawTo(address payable to, uint256 amount) external;
    function addStake(uint32 unstakeDelaySec) external payable;
    function unlockStake() external;
    function withdrawStake(address payable to) external;
}

/**
 * @title SponsorGate
 * @notice SponsorPaymaster's owner, as a contract, so a service can allowlist new accounts without
 *         holding the key that can also withdraw the gas deposit.
 *
 * ## Why the owner is not a hot key
 *
 * `SponsorPaymaster` has one `owner` that does everything: allowlist an account, set the cost limits,
 * withdraw the deposit and the stake, hand over ownership. In production that owner is a multisig, so
 * a new account could only be sponsored by a multisig transaction - which is why onboarding ran through
 * a dev endpoint. Giving the co-signer service that key instead would make a server compromise a theft
 * of the whole deposit.
 *
 * This contract is set as the paymaster's owner. It holds no funds of its own, and splits the owner's
 * powers in two:
 *
 *  - **operators** (revocable keys, one per service instance) may only `sponsor` an account, a batch of
 *    them, or `unsponsor` one. Never a withdrawal, the stake, the cost limits, the budgets or ownership.
 *  - **the governor** keeps every owner power, by forwarding: each paymaster owner function has a
 *    governor-only twin here with the same name and arguments.
 *
 * And it adds what the paymaster lacks: a **count budget**. Operators together may add at most
 * `maxSponsorsPerWindow` accounts per `WINDOW`. Re-sponsoring an account that is already sponsored costs
 * nothing, and neither does unsponsoring.
 *
 * ## Worst case
 *
 * With every operator key stolen at once, in any 24 hours the attacker adds at most
 * 2 x `maxSponsorsPerWindow` accounts (a full window's budget either side of a boundary; windows are
 * fixed, like KeeperGate's, so a block explorer shows exactly when one opens). Each account then spends
 * at most the paymaster's per-account budget per budget window, and at most `maxCostAllowed` per
 * operation. So operators may sponsor only while the paymaster enforces all three bounds
 * (`PaymasterUnbounded` otherwise): the gate turns "each account's gas is bounded" from a configuration
 * hope into a precondition. The attacker can also unsponsor existing accounts - a denial of service the
 * governor reverses with `setSponsoredBatch`. The guardian or the governor stops all of it with one
 * transaction (`setOperator(key, false)`, or a budget of zero). Nothing moves to the attacker.
 *
 * ## Why a plain governor and not DelayedGovernance
 *
 * DelayedGovernance makes a risky change visible for a delay so the people exposed to it can leave: LPs
 * close offers, holders redeem. Nobody is exposed here. The deposit is the operator's own gas money, no
 * user funds pass through the paymaster, and a user could do nothing with a warning that the deposit
 * will be withdrawn. What a delay would do is slow the things that must be fast: rotating a leaked
 * operator key (add the new one, revoke the old), raising `maxCostAllowed` when gas spikes, moving the
 * stake to a new paymaster. So governance is a plain governor - a multisig - with a two-step handover,
 * so a mistyped address cannot orphan the paymaster. The guardian can only brake.
 */
contract SponsorGate {
    /// @notice The budget window. Fixed rather than rolling; the worst case is stated above.
    uint256 public constant WINDOW = 1 days;
    /// @notice No budget above this: a typo must not hand out unbounded sponsorship.
    uint32 public constant MAX_SPONSORS_PER_WINDOW = 100_000;
    /// @notice Largest operator batch, so one call's gas stays bounded.
    uint256 public constant MAX_BATCH = 100;

    ISponsorPaymaster public immutable PAYMASTER;

    address public governor;
    address public pendingGovernor;
    /// @notice May revoke operators and lower the budget. Zero when none is set.
    address public guardian;

    mapping(address operator => bool allowed) public isOperator;
    uint32 public maxSponsorsPerWindow;
    uint64 public windowStart;
    uint32 public windowUsed;

    event OperatorSet(address indexed operator, bool allowed, address indexed by);
    event SponsorBudgetSet(uint32 maxSponsorsPerWindow, address indexed by);
    event GuardianSet(address indexed guardian);
    event GovernorTransferStarted(address indexed from, address indexed to);
    event GovernorTransferred(address indexed from, address indexed to);
    event Sponsored(address indexed operator, address indexed account);
    event Unsponsored(address indexed operator, address indexed account);

    error NotGovernor();
    error NotPendingGovernor();
    error NotOperator();
    error ZeroAddress();
    error BudgetTooLarge(uint32 requested, uint32 max);
    error SponsorBudgetExhausted(uint256 wanted, uint256 remaining);
    error BatchTooLarge(uint256 length, uint256 max);
    error PaymasterUnbounded();

    modifier onlyGovernor() {
        if (msg.sender != governor) revert NotGovernor();
        _;
    }

    modifier onlyOperator() {
        if (!isOperator[msg.sender]) revert NotOperator();
        _;
    }

    constructor(ISponsorPaymaster paymaster_, address governor_, address guardian_, uint32 maxSponsorsPerWindow_) {
        if (address(paymaster_) == address(0) || governor_ == address(0)) revert ZeroAddress();
        if (maxSponsorsPerWindow_ > MAX_SPONSORS_PER_WINDOW) {
            revert BudgetTooLarge(maxSponsorsPerWindow_, MAX_SPONSORS_PER_WINDOW);
        }
        PAYMASTER = paymaster_;
        governor = governor_;
        guardian = guardian_;
        maxSponsorsPerWindow = maxSponsorsPerWindow_;
        emit GovernorTransferred(address(0), governor_);
        emit GuardianSet(guardian_);
        emit SponsorBudgetSet(maxSponsorsPerWindow_, msg.sender);
    }

    /*//////////////////////////////////////////////////////////////
                              OPERATORS
    //////////////////////////////////////////////////////////////*/

    /// @notice Allowlist one account. Free when it is already sponsored; otherwise one unit of budget.
    function sponsor(address account) external onlyOperator {
        if (account == address(0)) revert ZeroAddress();
        _requireBounded();
        if (PAYMASTER.sponsored(account)) return;
        _consume(1);
        emit Sponsored(msg.sender, account);
        PAYMASTER.setSponsored(account, true);
    }

    /**
     * @notice Allowlist several accounts in one call. Charged once per distinct account not yet
     *         sponsored; the whole batch reverts if that exceeds what the window has left.
     */
    function sponsorBatch(address[] calldata accounts) external onlyOperator {
        uint256 length = accounts.length;
        if (length > MAX_BATCH) revert BatchTooLarge(length, MAX_BATCH);
        _requireBounded();
        bool[] memory isFresh = new bool[](length);
        uint256 fresh = 0;
        for (uint256 i; i < length; ++i) {
            address account = accounts[i];
            if (account == address(0)) revert ZeroAddress();
            if (PAYMASTER.sponsored(account) || _seenBefore(accounts, i)) continue;
            isFresh[i] = true;
            ++fresh;
        }
        if (fresh == 0) return;
        _consume(fresh);
        for (uint256 i; i < length; ++i) {
            if (isFresh[i]) emit Sponsored(msg.sender, accounts[i]);
        }
        PAYMASTER.setSponsoredBatch(accounts, true);
    }

    /// @notice Remove an account from the allowlist. Not budgeted: it removes gas exposure.
    function unsponsor(address account) external onlyOperator {
        if (account == address(0)) revert ZeroAddress();
        emit Unsponsored(msg.sender, account);
        PAYMASTER.setSponsored(account, false);
    }

    /// @notice Accounts operators may still add in the current window.
    function remainingSponsorships() public view returns (uint256) {
        uint256 used = block.timestamp >= uint256(windowStart) + WINDOW ? 0 : windowUsed;
        uint256 budget = maxSponsorsPerWindow;
        return used >= budget ? 0 : budget - used;
    }

    /// @notice When the current window closes and the budget refills; zero if no window is open.
    function windowEndsAt() external view returns (uint256) {
        uint256 end = uint256(windowStart) + WINDOW;
        return block.timestamp >= end ? 0 : end;
    }

    function _consume(uint256 count) private {
        uint256 remaining = remainingSponsorships();
        if (count > remaining) revert SponsorBudgetExhausted(count, remaining);
        if (block.timestamp >= uint256(windowStart) + WINDOW) {
            windowStart = uint64(block.timestamp);
            windowUsed = 0;
        }
        // Cannot overflow: count <= remaining <= maxSponsorsPerWindow - windowUsed <= type(uint32).max.
        windowUsed += uint32(count);
    }

    /// @dev Each account's gas is bounded only while the paymaster enforces a per-operation limit
    ///      and a per-account budget; without them the count budget bounds nothing.
    function _requireBounded() private view {
        if (PAYMASTER.maxCostAllowed() == 0 || PAYMASTER.budgetWindow() == 0 || PAYMASTER.defaultBudget() == 0) {
            revert PaymasterUnbounded();
        }
    }

    function _seenBefore(address[] calldata accounts, uint256 i) private pure returns (bool) {
        for (uint256 j; j < i; ++j) {
            if (accounts[j] == accounts[i]) return true;
        }
        return false;
    }

    /*//////////////////////////////////////////////////////////////
                    THE OWNER'S POWERS, KEPT BY THE GOVERNOR
    //////////////////////////////////////////////////////////////*/

    function setSponsored(address account, bool isSponsored) external onlyGovernor {
        PAYMASTER.setSponsored(account, isSponsored);
    }

    function setSponsoredBatch(address[] calldata accounts, bool isSponsored) external onlyGovernor {
        PAYMASTER.setSponsoredBatch(accounts, isSponsored);
    }

    function setMaxCostAllowed(uint256 maxCost) external onlyGovernor {
        PAYMASTER.setMaxCostAllowed(maxCost);
    }

    function setBudget(uint256 window, uint256 perAccount) external onlyGovernor {
        PAYMASTER.setBudget(window, perAccount);
    }

    function setAccountBudget(address account, uint256 budget) external onlyGovernor {
        PAYMASTER.setAccountBudget(account, budget);
    }

    function resetSpend(address account) external onlyGovernor {
        PAYMASTER.resetSpend(account);
    }

    /// @notice Pays out of the paymaster's EntryPoint deposit; the gate itself never holds the ETH.
    function withdrawTo(address payable to, uint256 amount) external onlyGovernor {
        PAYMASTER.withdrawTo(to, amount);
    }

    function addStake(uint32 unstakeDelaySec) external payable onlyGovernor {
        PAYMASTER.addStake{value: msg.value}(unstakeDelaySec);
    }

    function unlockStake() external onlyGovernor {
        PAYMASTER.unlockStake();
    }

    function withdrawStake(address payable to) external onlyGovernor {
        PAYMASTER.withdrawStake(to);
    }

    /**
     * @notice Hand the paymaster to another owner, taking the gate out of the path.
     * @dev One step, because the paymaster's own `transferOwnership` is: check the address.
     */
    function transferPaymasterOwnership(address to) external onlyGovernor {
        PAYMASTER.transferOwnership(to);
    }

    /*//////////////////////////////////////////////////////////////
                               GOVERNANCE
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Add or revoke an operator. The governor does either; the guardian may only revoke, so a
     *         leaked service key is cut off by whoever is awake for incidents.
     */
    function setOperator(address operator, bool allowed) external {
        if (!(msg.sender == governor || (msg.sender == guardian && !allowed))) {
            revert NotGovernor();
        }
        if (operator == address(0)) revert ZeroAddress();
        isOperator[operator] = allowed;
        emit OperatorSet(operator, allowed, msg.sender);
    }

    /// @notice Set the count budget. The governor sets any value up to the cap; the guardian may only lower it.
    function setMaxSponsorsPerWindow(uint32 count) external {
        bool lowering = count <= maxSponsorsPerWindow;
        if (!(msg.sender == governor || (msg.sender == guardian && lowering))) {
            revert NotGovernor();
        }
        if (count > MAX_SPONSORS_PER_WINDOW) revert BudgetTooLarge(count, MAX_SPONSORS_PER_WINDOW);
        maxSponsorsPerWindow = count;
        emit SponsorBudgetSet(count, msg.sender);
    }

    function setGuardian(address guardian_) external onlyGovernor {
        guardian = guardian_;
        emit GuardianSet(guardian_);
    }

    /// @notice Start handing governance over; `to` must accept. A later call replaces the pending address.
    function transferGovernor(address to) external onlyGovernor {
        if (to == address(0)) revert ZeroAddress();
        pendingGovernor = to;
        emit GovernorTransferStarted(governor, to);
    }

    function acceptGovernor() external {
        if (msg.sender != pendingGovernor) revert NotPendingGovernor();
        emit GovernorTransferred(governor, msg.sender);
        governor = msg.sender;
        pendingGovernor = address(0);
    }
}
