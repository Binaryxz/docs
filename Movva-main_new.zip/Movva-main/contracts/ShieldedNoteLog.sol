// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/**
 * @title ShieldedNoteLog
 * @notice On-chain, append-only log of encrypted note records - the note-emission hook the
 *         viewing-key design needs, in its strongest form.
 *
 * ## Why this exists alongside the vault
 *
 * Note records can live in two places, and the trade-off is real rather than cosmetic:
 *
 *  - **Off-chain vault + `AuditGrantRegistry.anchorChain`** (cheap): records are served by a
 *    replicated service, and the registry holds only a periodic head commitment. Revocation
 *    gating is meaningful because someone controls release. But availability depends on the
 *    vault, and a user who rolls their device back can shorten history between anchors -
 *    detectable only if an anchor already covered the missing notes.
 *
 *  - **This contract** (costlier, in calldata): every record is emitted as an event and the
 *    chain itself enforces `seq` and `prevHash`. Rolling back becomes impossible rather than
 *    merely detectable, and history cannot be censored or lost with the vault. The cost is
 *    calldata per note, and that anyone can see *that* a note was written, by whom and when -
 *    the contents stay encrypted, but the timing and count are public metadata.
 *
 * Neither is strictly better. A user disclosing to a tax authority wants the guarantees here;
 * a user making many small payments wants the vault. The client supports both, and an auditor
 * is told which one backed the report.
 *
 * ## What is stored versus emitted
 *
 * Storage holds two words per chain - the head and the count. The record itself is calldata,
 * reachable through the event log, so the contract stays cheap while remaining the
 * authoritative ordering. It holds no funds and cannot move any.
 */
contract ShieldedNoteLog {
    struct Chain {
        bytes32 head;
        uint32 count;
    }

    /// @notice owner => chainKey (keccak of pool, epoch, rotation) => chain state.
    mapping(address => mapping(bytes32 => Chain)) private _chains;

    event NoteAppended(
        address indexed owner,
        bytes32 indexed chainKey,
        uint32 seq,
        bytes32 prevHash,
        bytes32 recordHash,
        bytes record
    );

    error WrongSequence(uint32 expected, uint32 got);
    error WrongPrevHash(bytes32 expected, bytes32 got);
    error EmptyRecord();

    /**
     * @notice Append one encrypted record to a chain.
     * @param chainKey Identifies (pool, epoch, rotation). Opaque here.
     * @param seq Must equal the chain's current count: gaps and rewrites are impossible.
     * @param prevHash Must equal the chain's current head, so the caller proves it is
     *        extending the history it has actually seen rather than a stale copy.
     * @param record The encrypted note record. Opaque bytes; the contract never reads it.
     */
    function appendNote(bytes32 chainKey, uint32 seq, bytes32 prevHash, bytes calldata record)
        external
        returns (bytes32 recordHash)
    {
        if (record.length == 0) revert EmptyRecord();
        Chain storage c = _chains[msg.sender][chainKey];
        if (seq != c.count) revert WrongSequence(c.count, seq);
        if (prevHash != c.head) revert WrongPrevHash(c.head, prevHash);

        recordHash = keccak256(abi.encode(chainKey, seq, prevHash, keccak256(record)));
        c.head = recordHash;
        c.count = seq + 1;
        emit NoteAppended(msg.sender, chainKey, seq, prevHash, recordHash, record);
    }

    /// @notice Append several records to one chain in a single transaction.
    function appendNotes(
        bytes32 chainKey,
        uint32 firstSeq,
        bytes32 prevHash,
        bytes[] calldata records
    ) external returns (bytes32 head) {
        Chain storage c = _chains[msg.sender][chainKey];
        if (firstSeq != c.count) revert WrongSequence(c.count, firstSeq);
        if (prevHash != c.head) revert WrongPrevHash(c.head, prevHash);

        head = prevHash;
        uint32 seq = firstSeq;
        for (uint256 i; i < records.length; ++i) {
            if (records[i].length == 0) revert EmptyRecord();
            bytes32 recordHash = keccak256(abi.encode(chainKey, seq, head, keccak256(records[i])));
            emit NoteAppended(msg.sender, chainKey, seq, head, recordHash, records[i]);
            head = recordHash;
            seq += 1;
        }
        c.head = head;
        c.count = seq;
    }

    function headOf(address owner, bytes32 chainKey)
        external
        view
        returns (bytes32 head, uint32 count)
    {
        Chain storage c = _chains[owner][chainKey];
        return (c.head, c.count);
    }
}
