// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @dev The one Entrypoint function this contract calls. It is `onlyRole(ASP_POSTMAN)` there.
interface IEntrypointRoots {
    function updateRoot(uint256 root, string memory ipfsCID) external returns (uint256 index);
}

/**
 * @title AspRootQuorum
 * @notice The Entrypoint's ASP postman, as an immutable quorum of independent ASPs: an
 *         association-set root reaches the Entrypoint only when THRESHOLD of the fixed ASPs
 *         have voted for exactly that root and IPFS CID.
 *
 * ## Why this exists
 *
 * A private withdrawal must prove the Entrypoint's latest root, and only the holder of
 * ASP_POSTMAN can post one. OWNER_ROLE is that role's only admin, so once OWNER_ROLE is
 * renounced the postman can never be replaced. Held by one key, that is a single point of
 * failure: lose it and no new root is ever posted, so later deposits cannot withdraw privately; leak it and whoever holds it decides which
 * deposits are approved. (Funds are never trapped either way: ragequit needs no root, and
 * `FiatEscrow.rescueShielded` gives escrow-delivered notes the same exit.)
 *
 * Granting ASP_POSTMAN to this contract instead, before OWNER_ROLE is renounced, spreads
 * that role over several independent ASPs. It lives outside the audited Privacy Pools code
 * and changes none of it: to the Entrypoint it is simply the postman.
 *
 * ## What it guarantees, and what it gives up
 *
 *  - No root is posted unless THRESHOLD distinct ASPs hold a live vote for it in the current
 *    round (see "Rounds, withdrawn votes and expiry").
 *    THRESHOLD is a strict majority, so a minority of ASPs can never post a root the others
 *    did not approve, and two conflicting roots can never both reach a quorum.
 *  - It survives the loss or compromise of fewer than THRESHOLD ASPs for safety, and of up
 *    to ASP_COUNT - THRESHOLD ASPs for liveness.
 *  - It has no owner, no setter and no upgrade path. The ASP set, THRESHOLD and VOTE_TTL are
 *    fixed at deployment. Nobody can ever add, remove or replace an ASP - that is the price of an
 *    immutable periphery. If so many ASPs are lost that a quorum can never form again, no new root
 *    is ever posted: deposits already in the last posted root keep withdrawing privately against
 *    it, and every later deposit leaves by ragequit.
 *
 * ## Rounds, withdrawn votes and expiry (SRM1-14)
 *
 * Votes are counted per (round, root, CID). The round advances each time a root is posted,
 * so votes cast for an earlier round can never complete later. An ASP may vote for more than
 * one proposal in a round - to correct a mistaken root, or to join the majority after a split -
 * because one vote per round would let a three-way split stall the quorum forever. It cannot
 * hold two live votes for the same proposal.
 *
 * A vote counts only while it is LIVE: cast in the current round, not withdrawn with `unvote`,
 * and less than VOTE_TTL old. So a vote an ASP abandoned - it switched to a corrected root and
 * unvoted the old one, or simply let it lapse - can never complete a quorum later. The guarantee
 * is therefore: a root is posted only when THRESHOLD distinct ASPs each hold a live vote for
 * exactly that root and CID at the moment of posting, i.e. each approved it within the last
 * VOTE_TTL and none has withdrawn. An ASP whose vote lapsed and still approves votes again.
 *
 * ## The CID must match byte for byte
 *
 * A proposal is keyed on the exact CID string, so honest ASPs must derive the same string. The
 * canonical procedure (one CIDv1, raw codec, sha2-256, base32 lower case, over a canonical
 * association-set document) is `packages/ops/src/asp-cid.ts`; every ASP computes the CID with it
 * from the labels and the root, never from whatever its IPFS client prints.
 */
contract AspRootQuorum {
    /// @notice Bounds on VOTE_TTL. Under an hour honest ASPs could miss each other; over 30 days an
    ///         abandoned vote stays usable too long.
    uint256 public constant MIN_VOTE_TTL = 1 hours;
    uint256 public constant MAX_VOTE_TTL = 30 days;
    /// @notice Votes are counted by walking the ASP set, so it is bounded.
    uint256 public constant MAX_ASPS = 16;

    IEntrypointRoots public immutable ENTRYPOINT;
    /// @notice How many distinct ASPs must vote for the same proposal. Always > ASP_COUNT / 2.
    uint256 public immutable THRESHOLD;
    uint256 public immutable ASP_COUNT;
    /// @notice How long a vote stays live, in seconds.
    uint256 public immutable VOTE_TTL;

    mapping(address => bool) public isAsp;
    address[] private _asps;

    /// @notice How many roots this contract has posted; votes belong to the current round.
    uint256 public round;
    /// @notice When `asp` last voted for `proposal`; zero if never, or since it unvoted.
    mapping(bytes32 proposal => mapping(address asp => uint256)) public votedAt;

    event Voted(uint256 indexed round, address indexed asp, uint256 root, string ipfsCID, uint256 votes);
    event Unvoted(uint256 indexed round, address indexed asp, uint256 root, string ipfsCID, uint256 votes);
    event RootPosted(uint256 indexed round, uint256 root, string ipfsCID, uint256 entrypointIndex);

    error ZeroAddress();
    error DuplicateAsp(address asp);
    error ThresholdNotMajority(uint256 threshold, uint256 aspCount);
    error TooManyAsps(uint256 aspCount);
    error BadVoteTtl(uint256 voteTtl);
    error NotAnAsp();
    error AlreadyVoted();
    error NotVoted();
    error EmptyRoot();
    error InvalidIPFSCIDLength();

    constructor(IEntrypointRoots entrypoint, address[] memory asps_, uint256 threshold, uint256 voteTtl) {
        if (address(entrypoint) == address(0)) revert ZeroAddress();
        uint256 n = asps_.length;
        if (threshold == 0 || threshold > n || threshold * 2 <= n) revert ThresholdNotMajority(threshold, n);
        if (n > MAX_ASPS) revert TooManyAsps(n);
        if (voteTtl < MIN_VOTE_TTL || voteTtl > MAX_VOTE_TTL) revert BadVoteTtl(voteTtl);
        for (uint256 i; i < n; ++i) {
            address a = asps_[i];
            if (a == address(0)) revert ZeroAddress();
            if (isAsp[a]) revert DuplicateAsp(a);
            isAsp[a] = true;
        }
        ENTRYPOINT = entrypoint;
        THRESHOLD = threshold;
        ASP_COUNT = n;
        VOTE_TTL = voteTtl;
        _asps = asps_;
    }

    /// @notice The fixed ASP set, in deployment order.
    function asps() external view returns (address[] memory) {
        return _asps;
    }

    /// @notice The key a vote for `root` and `ipfsCID` is counted under in round `r`.
    function proposalId(uint256 r, uint256 root, string calldata ipfsCID) public pure returns (bytes32) {
        return keccak256(abi.encode(r, root, ipfsCID));
    }

    /// @notice Whether `asp` holds a live vote for `proposal`: cast, not withdrawn, under VOTE_TTL old.
    ///         (A proposal of an earlier round can never post, whatever this says.)
    function hasVoted(bytes32 proposal, address asp) public view returns (bool) {
        uint256 at = votedAt[proposal][asp];
        return at != 0 && block.timestamp < at + VOTE_TTL;
    }

    /// @notice How many live votes `proposal` holds now.
    function votes(bytes32 proposal) public view returns (uint256 count) {
        uint256 n = _asps.length;
        for (uint256 i; i < n; ++i) {
            if (hasVoted(proposal, _asps[i])) ++count;
        }
    }

    /**
     * @notice Vote, as one of the fixed ASPs, for posting `root` with `ipfsCID`. The vote that
     *         brings the live votes to THRESHOLD posts the root to the Entrypoint in the same
     *         transaction. A lapsed vote for the same proposal is renewed.
     * @return posted Whether this vote posted the root.
     */
    function vote(uint256 root, string calldata ipfsCID) external returns (bool posted) {
        if (!isAsp[msg.sender]) revert NotAnAsp();
        // The Entrypoint's own checks, applied up front so no vote is wasted on a proposal
        // that could never be posted.
        if (root == 0) revert EmptyRoot();
        uint256 cidLength = bytes(ipfsCID).length;
        if (cidLength < 32 || cidLength > 64) revert InvalidIPFSCIDLength();

        uint256 r = round;
        bytes32 p = proposalId(r, root, ipfsCID);
        if (hasVoted(p, msg.sender)) revert AlreadyVoted();
        votedAt[p][msg.sender] = block.timestamp;
        uint256 count = votes(p);
        emit Voted(r, msg.sender, root, ipfsCID, count);

        // Live votes move by one at a time and a post ends the round, so this is reached exactly once.
        if (count >= THRESHOLD) {
            round = r + 1;
            uint256 index = ENTRYPOINT.updateRoot(root, ipfsCID);
            emit RootPosted(r, root, ipfsCID, index);
            return true;
        }
    }

    /**
     * @notice Withdraw this ASP's live vote for `root` with `ipfsCID` in the current round - for
     *         example after it found a label it no longer approves. It then counts for nothing.
     */
    function unvote(uint256 root, string calldata ipfsCID) external {
        if (!isAsp[msg.sender]) revert NotAnAsp();
        uint256 r = round;
        bytes32 p = proposalId(r, root, ipfsCID);
        if (!hasVoted(p, msg.sender)) revert NotVoted();
        delete votedAt[p][msg.sender];
        emit Unvoted(r, msg.sender, root, ipfsCID, votes(p));
    }
}
