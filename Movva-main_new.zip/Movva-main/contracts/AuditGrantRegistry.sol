// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/**
 * @title AuditGrantRegistry
 * @notice Public, user-controlled lifecycle for selective-disclosure ("viewing key")
 *         grants over a shielded balance.
 *
 * Deliberately minimal, and deliberately *not* a place where secrets live:
 *  - only `grantId` (a hash of the public grant terms) and the subject's ed25519 public
 *    key are stored. No viewing key, no epoch secret, no amount, no counterparty;
 *  - it holds no funds and has no reference to the pool's spending logic, so it is
 *    structurally incapable of authorising a withdrawal;
 *  - only the registering account can revoke its own grants.
 *
 * ## Subject binding
 *
 * A disclosure bundle is signed by an off-chain ed25519 identity key, while a registration
 * is authorised by an L1 account. Binding the two is what stops an auditor being handed a
 * bundle whose "live" status was registered by somebody else. The binding is:
 *
 *   the auditor requires `subject == terms.subject` AND `owner ∈ terms.accounts`
 *
 * and `terms.accounts` is itself covered by the ed25519 signature. So an attacker cannot
 * register a grant that a victim's bundle would accept: they may publish any `subject` they
 * like, but `owner` will be their own address, which is absent from the victim's signed
 * account list, and the signature over that list cannot be forged.
 *
 * Grants are keyed by `(owner, grantId)` rather than `grantId` alone. Keying on the hash
 * alone would let anyone front-run a registration with the same `grantId` and permanently
 * block the real subject via `AlreadyRegistered`.
 *
 * ## What revocation does
 *
 * It stops future access: the note vault gates ciphertext release on `isLive`. Combined
 * with `rotateEpoch`, notes written after revocation are unreadable with the material the
 * ex-auditor holds. It cannot un-disclose plaintext already decrypted - nothing can.
 */
contract AuditGrantRegistry {
    struct Grant {
        address owner;
        /// @notice ed25519 public key that signed the disclosure bundle.
        bytes32 subject;
        uint64 validFrom;
        uint64 expiry;
        uint64 revokedAt;
        /// @notice Opaque pointer to the encrypted-terms blob (e.g. an IPFS CID).
        bytes32 termsPointer;
    }

    /// @dev keccak256(owner, grantId) => grant.
    mapping(bytes32 => Grant) private _grants;
    /// @notice owner => keccak256(poolId, epochId) => current rotation counter.
    mapping(address => mapping(bytes32 => uint32)) public rotation;

    /**
     * @notice Commitment to the length and head of a note chain, written as the user
     *         transacts - long before any audit is requested.
     *
     * This is what stops a user shortening their history at disclosure time. The signed
     * `{count, head}` in a bundle is self-attested and could say anything; an anchor made
     * earlier cannot be walked back, so an auditor comparing the two detects a disclosure
     * that omits notes the user already committed to. It also lets the user prove the note
     * vault dropped or altered a record, since the head would no longer reproduce.
     *
     * Only the head and count are stored - no ciphertext, no amounts.
     */
    struct ChainAnchor {
        bytes32 head;
        uint32 count;
        uint64 at;
    }

    /// @notice owner => keccak256(poolId, epochId, rot) => anchor.
    mapping(address => mapping(bytes32 => ChainAnchor)) private _anchors;

    event GrantRegistered(
        bytes32 indexed grantId,
        address indexed owner,
        bytes32 subject,
        uint64 validFrom,
        uint64 expiry,
        bytes32 termsPointer
    );
    event GrantRevoked(bytes32 indexed grantId, address indexed owner, uint64 timestamp);
    event EpochRotated(address indexed owner, bytes32 indexed epochKey, uint32 rotation);
    event ChainAnchored(
        address indexed owner, bytes32 indexed chainKey, bytes32 head, uint32 count
    );

    error AlreadyRegistered();
    error UnknownGrant();
    error BadWindow();
    error EmptySubject();
    error AnchorNotMonotonic();
    error EmptyAnchor();

    function slotOf(address owner, bytes32 grantId) public pure returns (bytes32) {
        return keccak256(abi.encode(owner, grantId));
    }

    function register(
        bytes32 grantId,
        bytes32 subject,
        uint64 validFrom,
        uint64 expiry,
        bytes32 termsPointer
    ) external {
        _register(grantId, subject, validFrom, expiry, termsPointer);
    }

    /**
     * @notice Register a grant and seal the note chains it can read, in one transaction - the
     *         intended client path for a fiscal-period grant.
     * @dev An epoch secret decrypts its `(epoch, rotation)` chain forever; expiry and
     *      revocation only stop the note vault from serving it. If the chain stayed writable
     *      after issuance, notes recorded into it later would be readable with a key that has
     *      expired - by anyone holding the ciphertext, which with `ShieldedNoteLog` is anyone.
     *      Bumping the rotation as the grant is registered makes it cover exactly the notes
     *      that existed at issuance. Atomic, so a grant never exists while its chains are open.
     */
    function registerAndRotate(
        bytes32 grantId,
        bytes32 subject,
        uint64 validFrom,
        uint64 expiry,
        bytes32 termsPointer,
        bytes32[] calldata epochKeys
    ) external {
        _register(grantId, subject, validFrom, expiry, termsPointer);
        _rotate(epochKeys);
    }

    function _register(
        bytes32 grantId,
        bytes32 subject,
        uint64 validFrom,
        uint64 expiry,
        bytes32 termsPointer
    ) private {
        if (subject == bytes32(0)) revert EmptySubject();
        if (expiry <= validFrom || expiry <= block.timestamp) revert BadWindow();
        bytes32 slot = slotOf(msg.sender, grantId);
        if (_grants[slot].owner != address(0)) revert AlreadyRegistered();

        _grants[slot] = Grant({
            owner: msg.sender,
            subject: subject,
            validFrom: validFrom,
            expiry: expiry,
            revokedAt: 0,
            termsPointer: termsPointer
        });
        emit GrantRegistered(grantId, msg.sender, subject, validFrom, expiry, termsPointer);
    }

    /// @notice Revoke early. Idempotent: the first revocation timestamp is the binding one.
    function revoke(bytes32 grantId) external {
        _revoke(grantId);
    }

    function _revoke(bytes32 grantId) private {
        Grant storage g = _grants[slotOf(msg.sender, grantId)];
        // Only the owner's own slot is reachable from msg.sender, so an unknown grant here
        // means the caller never registered it - no separate authorisation check needed.
        if (g.owner == address(0)) revert UnknownGrant();
        if (g.revokedAt == 0) {
            g.revokedAt = uint64(block.timestamp);
            emit GrantRevoked(grantId, msg.sender, g.revokedAt);
        }
    }

    /**
     * @notice Bump the rotation counter for one epoch, so the user's devices derive a fresh
     *         epoch viewing key. Notes written afterwards are unreadable with the revoked
     *         secret.
     */
    function rotateEpoch(bytes32 epochKey) external returns (uint32 next) {
        next = ++rotation[msg.sender][epochKey];
        emit EpochRotated(msg.sender, epochKey, next);
    }

    /// @notice Revoke and rotate in one transaction - the intended client path.
    function revokeAndRotate(bytes32 grantId, bytes32[] calldata epochKeys) external {
        _revoke(grantId);
        _rotate(epochKeys);
    }

    function _rotate(bytes32[] calldata epochKeys) private {
        for (uint256 i; i < epochKeys.length; ++i) {
            uint32 next = ++rotation[msg.sender][epochKeys[i]];
            emit EpochRotated(msg.sender, epochKeys[i], next);
        }
    }

    /**
     * @notice Commit to the current head of one note chain.
     * @dev Append-only: `count` may never decrease, so a user cannot quietly retract history
     *      they already published. Re-anchoring the same count with a different head is also
     *      rejected - that would mean rewriting records already committed to.
     */
    function anchorChain(bytes32 chainKey, bytes32 head, uint32 count) external {
        if (head == bytes32(0) || count == 0) revert EmptyAnchor();
        ChainAnchor storage a = _anchors[msg.sender][chainKey];
        if (count < a.count) revert AnchorNotMonotonic();
        if (count == a.count && a.head != head) revert AnchorNotMonotonic();
        a.head = head;
        a.count = count;
        a.at = uint64(block.timestamp);
        emit ChainAnchored(msg.sender, chainKey, head, count);
    }

    function anchorOf(address owner, bytes32 chainKey)
        external
        view
        returns (bytes32 head, uint32 count, uint64 at)
    {
        ChainAnchor storage a = _anchors[owner][chainKey];
        return (a.head, a.count, a.at);
    }

    function statusOf(address owner, bytes32 grantId)
        external
        view
        returns (bool exists, bytes32 subject, uint64 revokedAt, uint64 expiry)
    {
        Grant storage g = _grants[slotOf(owner, grantId)];
        return (g.owner != address(0), g.subject, g.revokedAt, g.expiry);
    }

    function isLive(address owner, bytes32 grantId) external view returns (bool) {
        Grant storage g = _grants[slotOf(owner, grantId)];
        return g.owner != address(0) && g.revokedAt == 0 && block.timestamp >= g.validFrom
            && block.timestamp <= g.expiry;
    }

    function grantOf(address owner, bytes32 grantId) external view returns (Grant memory) {
        return _grants[slotOf(owner, grantId)];
    }
}
