// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/**
 * @title HyperCore
 * @notice Reads HyperCore state through HyperEVM's read precompiles and writes HyperCore actions
 *         through the CoreWriter system contract.
 *
 * Every address, input encoding, return layout and action id below is copied from Hyperliquid's
 * own documentation, not from memory:
 *
 *  - hyperliquid.gitbook.io/hyperliquid-docs/for-developers/hyperevm/interacting-with-hypercore
 *    ("Read precompiles", "CoreWriter contract", and the `L1Read.sol` / `CoreWriter.sol` files
 *    attached to that page);
 *  - .../hyperevm/interaction-timings (what happens in which order after an EVM block);
 *  - .../api/asset-ids (perp id = index in meta.universe; spot id = 10000 + spot index);
 *  - .../api/tick-and-lot-size (at most 5 significant figures; at most 6 - szDecimals decimals
 *    for perps and 8 - szDecimals for spot; integer prices always allowed).
 *
 * Checked read-only against HyperEVM mainnet (chain 999) at EVM blocks 45,821,758-45,821,781:
 * `oraclePx(1)` decoded to 2510.1 with ETH's szDecimals 4, matching the info API; `perpAssetInfo(1)`
 * to ("ETH", 55, 4, 25, false); CoreWriter's deployed code is the documented 544-byte contract.
 * `contracts/test/HyperCoreReadFork.t.sol` repeats the decoding against the live RPC.
 *
 * ## Three facts that shape every caller
 *
 * 1. **A CoreWriter call cannot fail on the EVM side.** The contract only emits `RawAction`;
 *    HyperCore validates the action after the EVM block, and a rejected action leaves no trace a
 *    contract can read. So nothing may assume an action took effect. Callers re-derive state from
 *    precompile reads in a LATER block.
 * 2. **Reads are as of the start of the EVM block.** An action sent in block N is invisible to
 *    reads in block N. Order actions are additionally "delayed onchain for a few seconds".
 * 3. **An invalid precompile input consumes all gas passed to the call.** Every read here caps the
 *    gas it forwards and reports failure instead of reverting, so one bad read cannot burn a
 *    transaction's gas or brick a view.
 */
library HyperCore {
    address internal constant CORE_WRITER = 0x3333333333333333333333333333333333333333;

    address internal constant POSITION = 0x0000000000000000000000000000000000000800;
    address internal constant SPOT_BALANCE = 0x0000000000000000000000000000000000000801;
    address internal constant WITHDRAWABLE = 0x0000000000000000000000000000000000000803;
    address internal constant MARK_PX = 0x0000000000000000000000000000000000000806;
    address internal constant ORACLE_PX = 0x0000000000000000000000000000000000000807;
    address internal constant SPOT_PX = 0x0000000000000000000000000000000000000808;
    address internal constant PERP_ASSET_INFO = 0x000000000000000000000000000000000000080a;
    address internal constant SPOT_INFO = 0x000000000000000000000000000000000000080b;
    address internal constant TOKEN_INFO = 0x000000000000000000000000000000000000080C;
    address internal constant BBO = 0x000000000000000000000000000000000000080e;
    address internal constant ACCOUNT_MARGIN_SUMMARY = 0x000000000000000000000000000000000000080F;
    address internal constant CORE_USER_EXISTS = 0x0000000000000000000000000000000000000810;

    /// @dev Documented cost is 2000 + 65 * (input + output bytes); the largest read here is
    ///      tokenInfo, a few hundred bytes. Measured costs were about half the documented formula.
    uint256 internal constant READ_GAS = 100_000;

    // Action ids (uint24, big-endian after the version byte).
    uint24 internal constant LIMIT_ORDER = 1;
    uint24 internal constant SPOT_SEND = 6;
    uint24 internal constant USD_CLASS_TRANSFER = 7;
    uint24 internal constant SEND_ASSET = 13;

    /// @dev encodedTif: 1 = Alo, 2 = Gtc, 3 = Ioc.
    uint8 internal constant TIF_IOC = 3;
    /// @dev `uint32::MAX` names the spot dex in sendAsset and in CoreDepositWallet.deposit.
    uint32 internal constant SPOT_DEX = type(uint32).max;
    uint32 internal constant SPOT_ASSET_OFFSET = 10_000;
    uint64 internal constant USDC_TOKEN = 0;

    struct Position {
        int64 szi;
        uint64 entryNtl;
        int64 isolatedRawUsd;
        uint32 leverage;
        bool isIsolated;
    }

    struct SpotBalance {
        uint64 total;
        uint64 hold;
        uint64 entryNtl;
    }

    struct PerpAssetInfo {
        string coin;
        uint32 marginTableId;
        uint8 szDecimals;
        uint8 maxLeverage;
        bool onlyIsolated;
    }

    struct SpotInfo {
        string name;
        uint64[2] tokens;
    }

    struct TokenInfo {
        string name;
        uint64[] spots;
        uint64 deployerTradingFeeShare;
        address deployer;
        address evmContract;
        uint8 szDecimals;
        uint8 weiDecimals;
        int8 evmExtraWeiDecimals;
    }

    struct Bbo {
        uint64 bid;
        uint64 ask;
    }

    struct AccountMarginSummary {
        int64 accountValue;
        uint64 marginUsed;
        uint64 ntlPos;
        int64 rawUsd;
    }

    /*//////////////////////////////////////////////////////////////
                                  READS
    //////////////////////////////////////////////////////////////*/

    function _read(address precompile, bytes memory input) private view returns (bool, bytes memory) {
        // slither-disable-next-line low-level-calls
        (bool ok, bytes memory out) = precompile.staticcall{gas: READ_GAS}(input);
        return (ok && out.length > 0, out);
    }

    /// @notice Perp position. `szi` is signed and scaled by 10^szDecimals; positive is long.
    function position(address user, uint16 perp) internal view returns (bool ok, Position memory p) {
        bytes memory out;
        (ok, out) = _read(POSITION, abi.encode(user, perp));
        if (ok) p = abi.decode(out, (Position));
    }

    /// @notice Spot balance in the token's wei (10^weiDecimals; USDC is 8).
    function spotBalance(address user, uint64 token) internal view returns (bool ok, SpotBalance memory b) {
        bytes memory out;
        (ok, out) = _read(SPOT_BALANCE, abi.encode(user, token));
        if (ok) b = abi.decode(out, (SpotBalance));
    }

    /// @notice USD withdrawable from the perp account, 1e6.
    function withdrawable(address user) internal view returns (bool ok, uint64 w) {
        bytes memory out;
        (ok, out) = _read(WITHDRAWABLE, abi.encode(user));
        if (ok) w = abi.decode(out, (uint64));
    }

    /// @notice Perp mark and oracle prices: human price = raw / 10^(6 - szDecimals).
    function markPx(uint32 perp) internal view returns (bool ok, uint64 px) {
        bytes memory out;
        (ok, out) = _read(MARK_PX, abi.encode(perp));
        if (ok) px = abi.decode(out, (uint64));
    }

    function oraclePx(uint32 perp) internal view returns (bool ok, uint64 px) {
        bytes memory out;
        (ok, out) = _read(ORACLE_PX, abi.encode(perp));
        if (ok) px = abi.decode(out, (uint64));
    }

    /// @notice Spot price: human price = raw / 10^(8 - base token szDecimals).
    function spotPx(uint32 spot) internal view returns (bool ok, uint64 px) {
        bytes memory out;
        (ok, out) = _read(SPOT_PX, abi.encode(spot));
        if (ok) px = abi.decode(out, (uint64));
    }

    function perpAssetInfo(uint32 perp) internal view returns (bool ok, PerpAssetInfo memory info) {
        bytes memory out;
        (ok, out) = _read(PERP_ASSET_INFO, abi.encode(perp));
        if (ok) info = abi.decode(out, (PerpAssetInfo));
    }

    /// @notice A spot market's name and its [base, quote] token indices.
    function spotInfo(uint32 spot) internal view returns (bool ok, SpotInfo memory info) {
        bytes memory out;
        (ok, out) = _read(SPOT_INFO, abi.encode(spot));
        if (ok) info = abi.decode(out, (SpotInfo));
    }

    function tokenInfo(uint32 token) internal view returns (bool ok, TokenInfo memory info) {
        bytes memory out;
        (ok, out) = _read(TOKEN_INFO, abi.encode(token));
        if (ok) info = abi.decode(out, (TokenInfo));
    }

    /// @notice Best bid and ask for an asset id, in the perp price scale for perps.
    function bbo(uint32 asset) internal view returns (bool ok, Bbo memory b) {
        bytes memory out;
        (ok, out) = _read(BBO, abi.encode(asset));
        if (ok) b = abi.decode(out, (Bbo));
    }

    /// @notice Perp account on dex `perpDex` (0 = the default perp dex). USD values 1e6.
    function accountMarginSummary(uint32 perpDex, address user)
        internal
        view
        returns (bool ok, AccountMarginSummary memory s)
    {
        bytes memory out;
        (ok, out) = _read(ACCOUNT_MARGIN_SUMMARY, abi.encode(perpDex, user));
        if (ok) s = abi.decode(out, (AccountMarginSummary));
    }

    /// @notice A CoreWriter action from an address with no HyperCore account is rejected.
    function coreUserExists(address user) internal view returns (bool ok, bool exists) {
        bytes memory out;
        (ok, out) = _read(CORE_USER_EXISTS, abi.encode(user));
        if (ok) exists = abi.decode(out, (bool));
    }

    /*//////////////////////////////////////////////////////////////
                                 ACTIONS
    //////////////////////////////////////////////////////////////*/

    /// @dev Version byte 1, then the action id as three big-endian bytes, then plain abi.encode.
    function _send(uint24 id, bytes memory payload) private {
        ICoreWriter(CORE_WRITER).sendRawAction(abi.encodePacked(uint8(1), id, payload));
    }

    /**
     * @notice Place a limit order. `limitPx` and `sz` are 10^8 times the human value, whatever
     *         the asset's szDecimals (docs), and must still respect tick and lot rules.
     */
    function limitOrder(uint32 asset, bool isBuy, uint64 limitPx, uint64 sz, bool reduceOnly, uint8 tif, uint128 cloid)
        internal
    {
        _send(LIMIT_ORDER, abi.encode(asset, isBuy, limitPx, sz, reduceOnly, tif, cloid));
    }

    /**
     * @notice Move USD between the perp and spot balances.
     * @dev `ntl` units are not stated in the docs. hyper-evm-lib (Obsidian, github.com/hyperliquid-dev/
     *      hyper-evm-lib) treats them as 1e6, which matches the perp side's 1e6 precompile units.
     *      UNVERIFIED end to end: no transaction was sent while writing this.
     */
    function usdClassTransfer(uint64 ntl, bool toPerp) internal {
        _send(USD_CLASS_TRANSFER, abi.encode(ntl, toPerp));
    }

    /**
     * @notice Send a spot asset. To a token's system address (0x20 followed by the big-endian token
     *         index; USDC's is 0x2000...0000) this bridges it to HyperEVM, credited by a system
     *         transaction in the next EVM block, paid for in HYPE from the sender's HyperCore spot
     *         balance ("200k gas at the next block's base fee").
     */
    function sendAsset(address destination, uint32 sourceDex, uint32 destinationDex, uint64 token, uint64 amountWei)
        internal
    {
        _send(SEND_ASSET, abi.encode(destination, address(0), sourceDex, destinationDex, token, amountWei));
    }

    function systemAddress(uint64 token) internal pure returns (address) {
        return address(uint160(0x2000000000000000000000000000000000000000) + uint160(token));
    }

    /*//////////////////////////////////////////////////////////////
                              TICK AND LOT
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Round a 1e8-scaled price to a valid tick: at most 5 significant figures, at most
     *         `maxDecimals` decimals, integers always allowed.
     * @param up Round up (for sells, so the limit stays at or above the band floor) or down (buys).
     */
    function roundPx(uint256 pxE8, uint256 maxDecimals, bool up) internal pure returns (uint256) {
        if (pxE8 == 0) return 0;
        uint256 magnitude = 0; // floor(log10(pxE8))
        for (uint256 x = pxE8; x >= 10; x /= 10) ++magnitude;
        uint256 unit = magnitude >= 4 ? 10 ** (magnitude - 4) : 1;
        if (unit > 1e8) unit = 1e8; // an integer price is always a valid tick
        uint256 decUnit = maxDecimals >= 8 ? 1 : 10 ** (8 - maxDecimals);
        if (decUnit > unit) unit = decUnit;
        // Rounding to a tick is the point of dividing first.
        // slither-disable-next-line divide-before-multiply
        uint256 down = (pxE8 / unit) * unit;
        return up && down < pxE8 ? down + unit : down;
    }

    /// @notice Round a 1e8-scaled size down to `szDecimals`.
    function roundSz(uint256 szE8, uint256 szDecimals) internal pure returns (uint256) {
        uint256 unit = szDecimals >= 8 ? 1 : 10 ** (8 - szDecimals);
        // slither-disable-next-line divide-before-multiply
        return (szE8 / unit) * unit;
    }
}

interface ICoreWriter {
    function sendRawAction(bytes calldata data) external;
}

/// @dev Circle's CoreDepositWallet on HyperEVM (mainnet 0x6B9E773128f453f5c2C60935Ee2DE2CBc5390A24,
///      which `tokenInfo(0).evmContract` returns). HyperCore credits USDC through this contract, not
///      through a transfer to USDC's system address; tokens sent to it directly are lost
///      (developers.circle.com/cctp/references/coredepositwallet-contract-interface).
interface ICoreDepositWallet {
    /// @param destinationDex 0 = the default perp dex, type(uint32).max = spot. Credits msg.sender.
    function deposit(uint256 amount, uint32 destinationDex) external;
}
