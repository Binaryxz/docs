// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {HyperCore} from "./HyperCore.sol";
import {IDeltaNeutral} from "./IDeltaNeutral.sol";

/**
 * @title DeltaNeutralStrategy
 * @notice The HyperCore half of `HyperCoreDeltaNeutralVault`: reading the book, deciding the next
 *         bounded step, placing orders through CoreWriter, estimating funding. A linked library.
 *
 * ## Why a linked library, and not a second contract
 *
 * The vault did not fit EIP-170 (29,025 bytes against 24,576), and no compiler setting brought it
 * under with room to grow. The size limit is a deployment constraint, not a security boundary, so
 * the split was chosen to add none:
 *
 *  - **One account.** Every `public` function here is reached by DELEGATECALL from the vault, so it
 *    runs as the vault: `address(this)` is the vault in every precompile read, `msg.sender` at
 *    CoreWriter is the vault, USDC moves from the vault's balance. There is still exactly one
 *    HyperCore account and one set of balances. Two contracts would have meant two accounts (or
 *    USDC shuttled between them), a NAV summed across them, and an interface between them that
 *    needs its own access control - a new place for a bug that moves funds.
 *  - **No new caller.** The vault keeps every entry point, every role check, the reentrancy guard
 *    and the settle and rate-limit gates, then delegates. This library has no access control of its
 *    own and needs none: solc makes a library's state-modifying functions revert unless they are
 *    DELEGATECALLed, and a contract that delegatecalls them acts on its own storage and its own
 *    HyperCore account, never the vault's.
 *  - **No new governance.** The library's address is linked into the vault's bytecode at deployment.
 *    Nothing can replace it; changing the strategy means deploying a new vault, as before.
 *  - **One storage pointer.** The library receives `IDeltaNeutral.State` and nothing else, so it
 *    cannot touch share balances, claims, roles or the governance queue.
 *
 * The code below is the vault's former strategy section, unchanged in what it decides. Every bound in
 * docs/delta-neutral.md §4 applies as before: the split moves no check across the delegatecall
 * except as a whole function, and the vault still performs all gating before delegating.
 *
 * ## Deployment
 *
 * Deploy this library first, then the vault linked against it. `forge script` and `forge test` link
 * automatically; with `forge create`, pass
 * `--libraries contracts/hyperliquid/DeltaNeutralStrategy.sol:DeltaNeutralStrategy:<address>`.
 * Verify the vault with the same `--libraries` value. See docs/delta-neutral.md §10.
 */
library DeltaNeutralStrategy {
    using SafeERC20 for IERC20;

    struct Plan {
        uint256 equity;
        uint256 shortfall;
        uint256 shortN;
        uint256 spotN;
        uint256 target;
        uint256 tol;
        bool spotSane;
        bool mayAdd;
    }

    struct Order {
        uint32 asset;
        bool isBuy;
        uint64 px;
        uint64 sz;
        bool reduceOnly;
    }

    uint256 internal constant BPS = 10_000;
    uint256 internal constant E8 = 1e8;
    uint256 internal constant WINDOW = 1 days;
    /// @dev hyperliquid.gitbook.io/hyperliquid-docs/trading/funding: F(8h) = premium +
    ///      clamp(0.01% - premium, -0.05%, 0.05%), paid hourly at F / 8. In 1e8 units.
    int256 internal constant INTEREST_8H_E8 = 10_000;
    int256 internal constant CLAMP_8H_E8 = 50_000;
    /// @dev One premium sample is clamped to +-5%: beyond that it is a broken book, not funding.
    int256 internal constant MAX_PREMIUM_E8 = 5_000_000;
    /// @dev Moves below one dollar are not worth an action (and USDC dust cannot pay the bridge).
    uint256 internal constant MIN_MOVE = 1e6;
    /// @dev Hard bounds `validate` applies to the exit-path parameters (M-01, M-04).
    uint256 internal constant MIN_SLIPPAGE_BPS = 10;
    uint256 internal constant MIN_SPOT_DEVIATION_BPS = 50;
    uint256 internal constant MAX_SETTLE_SECONDS = 60;
    uint256 internal constant MAX_ACTION_INTERVAL = 1 days;

    /*//////////////////////////////////////////////////////////////
                    ENTRY POINTS (DELEGATECALLED BY THE VAULT)
    //////////////////////////////////////////////////////////////*/

    /// @notice The funding estimate's resting value (premium inside the clamp): 0.01% per 8h, at 1e18.
    function initialFundingEmaE18() public pure returns (int256) {
        return (INTEREST_8H_E8 * 1e10) / 8;
    }

    /**
     * @notice Market facts from HyperCore itself, so a wrong index fails at deployment instead of
     *         trading the wrong asset. The spot market must quote its base token against USDC
     *         (token 0), and the perp must allow cross margin.
     */
    function readMarket(uint32 perp, uint32 spotMarket) public view returns (IDeltaNeutral.Market memory m) {
        (bool okPerp, HyperCore.PerpAssetInfo memory perpInfo) = HyperCore.perpAssetInfo(perp);
        (bool okSpot, HyperCore.SpotInfo memory spotInfo) = HyperCore.spotInfo(spotMarket);
        if (!okPerp || !okSpot || spotInfo.tokens[1] != HyperCore.USDC_TOKEN || perpInfo.onlyIsolated) {
            revert IDeltaNeutral.BadMarket();
        }
        (bool okToken, HyperCore.TokenInfo memory tokenInfo) = HyperCore.tokenInfo(uint32(spotInfo.tokens[0]));
        if (!okToken || tokenInfo.weiDecimals > 18 || perpInfo.szDecimals > 6 || tokenInfo.szDecimals > 8) {
            revert IDeltaNeutral.BadMarket();
        }
        m.perp = perp;
        m.spotMarket = spotMarket;
        m.spotToken = spotInfo.tokens[0];
        m.perpSzDecimals = perpInfo.szDecimals;
        m.spotSzDecimals = tokenInfo.szDecimals;
        m.spotWeiDecimals = tokenInfo.weiDecimals;
        m.maxLeverage = perpInfo.maxLeverage;
    }

    /**
     * @notice Everything the vault holds, in USDC (1e6): HyperEVM USDC, HyperCore spot USDC, the spot
     *         asset at the lower of its spot price and the perp oracle, and the perp account value.
     * @dev Reverts when HyperCore cannot be read: there is no honest NAV then.
     */
    function totalAssets(IDeltaNeutral.Market memory m) public view returns (uint256) {
        IDeltaNeutral.Book memory b = _book(m);
        return b.evmUsdc + b.coreUsdc + b.spotValue + b.perpValue;
    }

    /**
     * @notice `totalAssets`, and whether the spot price is within `maxDevBps` of the perp oracle.
     * @dev The spot leg is valued at min(spot, oracle). Without the band check a spot price pushed
     *      down on a thin book prices shares low, and a deposit buys them cheap (M-01). The vault
     *      refuses every share-priced operation when `spotSane` is false.
     */
    function pricedAssets(IDeltaNeutral.Market memory m, uint256 maxDevBps)
        public
        view
        returns (uint256 assets, bool spotSane)
    {
        IDeltaNeutral.Book memory b = _book(m);
        assets = b.evmUsdc + b.coreUsdc + b.spotValue + b.perpValue;
        spotSane = _within(b.spotPxE6, b.oraclePxE6, maxDevBps);
    }

    /// @notice Record a funding sample from the current book.
    function sampleFunding(IDeltaNeutral.State storage s, IDeltaNeutral.Market memory m) public {
        _sampleFunding(s, _book(m));
    }

    /// @notice The single most urgent step towards the target position. Reverts `NothingToDo` when none.
    function rebalance(IDeltaNeutral.State storage s, IDeltaNeutral.Market memory m) public {
        IDeltaNeutral.Book memory b = _book(m);
        _sampleFunding(s, b);
        if (!_step(s, m, b)) revert IDeltaNeutral.NothingToDo();
    }

    /// @notice Sample funding and return perp margin above target leverage to spot. Moves nothing out.
    function harvest(IDeltaNeutral.State storage s, IDeltaNeutral.Market memory m) public {
        IDeltaNeutral.Book memory b = _book(m);
        _sampleFunding(s, b);
        uint256 targetMargin = (b.ntlPos * BPS) / s.params.targetLeverageBps;
        uint256 excess = b.perpValue > targetMargin ? b.perpValue - targetMargin : 0;
        if (excess > b.withdrawablePerp) excess = b.withdrawablePerp;
        if (excess >= MIN_MOVE) {
            _acted(s, "harvest perp margin to spot", 0);
            HyperCore.usdClassTransfer(uint64(excess), false);
        }
    }

    /**
     * @notice One liquidity step towards the USDC recorded claims are owed. Reverts `NothingToDo` when
     *         HyperEVM USDC already covers them or there is nothing left to raise it from.
     * @dev The ladder: bridge spot USDC; else release perp margin down to `maxLeverageBps`; else close
     *      both legs by the shortfall. Not charged to the keeper's turnover: claims bound it.
     */
    function processExits(IDeltaNeutral.State storage s, IDeltaNeutral.Market memory m) public {
        IDeltaNeutral.Book memory b = _book(m);
        uint256 shortfall = s.totalOwed > b.evmUsdc ? s.totalOwed - b.evmUsdc : 0;
        // slither-disable-next-line incorrect-equality
        if (shortfall == 0) revert IDeltaNeutral.NothingToDo();
        _sampleFunding(s, b);
        if (!_raiseUsdc(s, m, b, shortfall, false)) revert IDeltaNeutral.NothingToDo();
    }

    /// @notice Protect the margin past `maxLeverageBps`. Reverts `NothingToDo` below it, and when the
    ///         only step left would trade spot outside the band.
    function deleverage(IDeltaNeutral.State storage s, IDeltaNeutral.Market memory m) public {
        IDeltaNeutral.Book memory b = _book(m);
        if (!_overLeveraged(s, b)) revert IDeltaNeutral.NothingToDo();
        bool acted = _deleverage(s, m, b, false);
        // `acted` is what this call decided, not a balance read back: CoreWriter only records the
        // action for after the block, and the vault's entry point is nonReentrant.
        // slither-disable-next-line reentrancy-balance
        if (!acted) revert IDeltaNeutral.NothingToDo();
    }

    /**
     * @notice Reverts `BadParams` unless every field is within its hard bound.
     * @dev The exit path has floors and caps, not just a delay (M-01, M-04): `slippageBps` at least
     *      10 bps, `maxSpotDeviationBps` 50 to 500 bps, `settleSeconds` 2 to 60, `minActionInterval`
     *      at most a day. A governor cannot set a band that never fills or a settle window that
     *      never ends, even after waiting.
     */
    function validate(IDeltaNeutral.Params memory p, uint8 venueMax) public pure {
        if (
            p.targetLeverageBps < BPS / 2 || p.targetLeverageBps > p.maxLeverageBps
            // At most half the venue's own maximum leverage.
            || uint256(p.maxLeverageBps) * 2 > uint256(venueMax) * BPS || p.slippageBps < MIN_SLIPPAGE_BPS
                || p.slippageBps > 200 || p.deltaToleranceBps == 0 || p.deltaToleranceBps > 2_000
                || p.maxSpotDeviationBps < MIN_SPOT_DEVIATION_BPS || p.maxSpotDeviationBps > 500
                || p.idleBufferBps > BPS || p.maxDrawdownBps == 0 || p.maxDrawdownBps >= BPS || p.exitFeeBps > 200
                || p.fundingUnwindE8 > p.fundingPauseE8 || p.fundingTau == 0 || p.settleSeconds < 2
                || p.settleSeconds > MAX_SETTLE_SECONDS || p.minActionInterval > MAX_ACTION_INTERVAL
                || p.maxOrderNotional == 0
        ) revert IDeltaNeutral.BadParams();
    }

    /**
     * @notice True when the change must wait out the governance delay: any field of `n` loosens the
     *         corresponding bound in `o`, or any exit-path field changes at all.
     * @dev The exit path - `requestRedeem`, `processExits`, `deleverage` - reads `slippageBps`,
     *      `maxSpotDeviationBps`, `settleSeconds`, `exitFeeBps` and `maxOrderNotional`. Each of them
     *      is riskier in BOTH directions: one way loosens a bound on the keeper or on share pricing,
     *      the other makes exits slower, dearer or impossible (a band that never fills, a fee raised
     *      under a holder's feet, a settle window that never ends, orders too small to unwind). So no
     *      exit-path parameter changes instantly (M-04); holders see it coming and can leave first.
     */
    function riskier(IDeltaNeutral.Params memory n, IDeltaNeutral.Params memory o) public pure returns (bool) {
        return n.targetLeverageBps > o.targetLeverageBps || n.maxLeverageBps > o.maxLeverageBps
            || n.slippageBps != o.slippageBps || n.deltaToleranceBps > o.deltaToleranceBps
            || n.maxSpotDeviationBps != o.maxSpotDeviationBps || n.idleBufferBps < o.idleBufferBps
            || n.maxDrawdownBps > o.maxDrawdownBps || n.exitFeeBps != o.exitFeeBps
            || n.fundingPauseE8 < o.fundingPauseE8 || n.fundingUnwindE8 < o.fundingUnwindE8
            || n.fundingTau > o.fundingTau || n.minActionInterval < o.minActionInterval
            || n.settleSeconds != o.settleSeconds || n.maxOrderNotional != o.maxOrderNotional
            || n.maxDailyTurnover > o.maxDailyTurnover || n.depositCap > o.depositCap;
    }

    /*//////////////////////////////////////////////////////////////
                              READING CORE
    //////////////////////////////////////////////////////////////*/

    function _book(IDeltaNeutral.Market memory m) internal view returns (IDeltaNeutral.Book memory b) {
        _readPrices(m, b);
        _readPositions(m, b);
        _readAccount(b);
        b.evmUsdc = m.usdc.balanceOf(address(this));
    }

    function _readPrices(IDeltaNeutral.Market memory m, IDeltaNeutral.Book memory b) internal view {
        (bool ok1, uint64 oracle) = HyperCore.oraclePx(m.perp);
        (bool ok2, uint64 spot) = HyperCore.spotPx(m.spotMarket);
        (bool ok3, HyperCore.Bbo memory bbo) = HyperCore.bbo(m.perp);
        if (!(ok1 && ok2 && ok3) || oracle == 0 || spot == 0) revert IDeltaNeutral.CoreUnreadable();
        b.oracleRaw = oracle;
        b.oraclePxE6 = uint256(oracle) * 10 ** m.perpSzDecimals;
        b.spotPxE6 = (uint256(spot) * 10 ** m.spotSzDecimals) / 100;
        b.bid = bbo.bid;
        b.ask = bbo.ask;
    }

    function _readPositions(IDeltaNeutral.Market memory m, IDeltaNeutral.Book memory b) internal view {
        (bool ok1, HyperCore.Position memory pos) = HyperCore.position(address(this), uint16(m.perp));
        (bool ok2, HyperCore.SpotBalance memory base) = HyperCore.spotBalance(address(this), m.spotToken);
        if (!(ok1 && ok2)) revert IDeltaNeutral.CoreUnreadable();
        if (pos.szi < 0) b.shortE8 = uint256(uint64(-pos.szi)) * 10 ** (8 - m.perpSzDecimals);
        else b.longPerpE8 = uint256(uint64(pos.szi)) * 10 ** (8 - m.perpSzDecimals);
        // Wei decimals differ by token and can exceed 8 (UETH has 9, UBTC 10 in spotMeta).
        b.spotE8 = m.spotWeiDecimals >= 8
            ? uint256(base.total) / 10 ** (m.spotWeiDecimals - 8)
            : uint256(base.total) * 10 ** (8 - m.spotWeiDecimals);
        uint256 px = b.spotPxE6 < b.oraclePxE6 ? b.spotPxE6 : b.oraclePxE6;
        b.spotValue = (b.spotE8 * px) / E8;
    }

    function _readAccount(IDeltaNeutral.Book memory b) internal view {
        (bool ok1, HyperCore.SpotBalance memory usdc) = HyperCore.spotBalance(address(this), HyperCore.USDC_TOKEN);
        (bool ok2, HyperCore.AccountMarginSummary memory acct) = HyperCore.accountMarginSummary(0, address(this));
        (bool ok3, uint64 w) = HyperCore.withdrawable(address(this));
        (bool ok4, bool exists) = HyperCore.coreUserExists(address(this));
        if (!(ok1 && ok2 && ok3 && ok4)) revert IDeltaNeutral.CoreUnreadable();
        b.perpValue = acct.accountValue > 0 ? uint256(uint64(acct.accountValue)) : 0;
        b.ntlPos = acct.ntlPos;
        b.withdrawablePerp = w;
        b.coreUsdc = usdc.total / 100; // USDC has 8 decimals on HyperCore, 6 on HyperEVM
        b.coreUser = exists;
    }

    /*//////////////////////////////////////////////////////////////
                                 STRATEGY
    //////////////////////////////////////////////////////////////*/

    function _step(IDeltaNeutral.State storage s, IDeltaNeutral.Market memory m, IDeltaNeutral.Book memory b)
        internal
        returns (bool)
    {
        Plan memory pl = _plan(s, b);

        // 0. No HyperCore account yet: a CoreWriter action from it would be rejected. Bridge first.
        if (!b.coreUser) return _bridgeToCore(s, m, b, pl.equity, false, 2 * MIN_MOVE);

        // 1. A long perp position is never intended. Close it, reduce-only.
        if (b.longPerpE8 > 0) {
            _send(_prepare(s, m, false, false, _cap(s, b.longPerpE8, b.oraclePxE6), b.oraclePxE6, true, true));
            return true;
        }

        // 2. Delta outside tolerance.
        if (_fixDelta(s, m, b, pl)) return true;

        // 3. Leverage past the hard cap.
        if (_overLeveraged(s, b) && _deleverage(s, m, b, true)) return true;

        // 4. More exposure than the target (unwinding, or equity fell): shrink both legs. Nothing
        //    while spot is outside the band: `_reduceBoth` will not close a hedged short alone.
        if (
            pl.shortN > pl.target + pl.tol
                && _reduceBoth(s, m, b, _cap(s, ((pl.shortN - pl.target) * E8) / b.oraclePxE6, b.oraclePxE6), true)
        ) return true;

        // 5. Keep the HyperEVM buffer: exits are paid from it.
        uint256 buffer = s.totalOwed + (pl.equity * s.params.idleBufferBps) / BPS;
        if (b.evmUsdc + MIN_MOVE < buffer && (b.coreUsdc >= MIN_MOVE || _freeMargin(s, b) >= MIN_MOVE)) {
            return _raiseUsdc(s, m, b, buffer - b.evmUsdc, true);
        }

        // 6. Add exposure towards the target.
        if (pl.mayAdd && pl.target > pl.shortN + pl.tol) return _addExposure(s, m, b, pl);
        return false;
    }

    function _plan(IDeltaNeutral.State storage s, IDeltaNeutral.Book memory b) internal view returns (Plan memory pl) {
        IDeltaNeutral.Params memory p = s.params;
        uint256 eq = b.evmUsdc + b.coreUsdc + b.spotValue + b.perpValue;
        pl.equity = eq > s.totalOwed ? eq - s.totalOwed : 0;
        pl.shortfall = s.totalOwed > b.evmUsdc ? s.totalOwed - b.evmUsdc : 0;
        pl.shortN = (b.shortE8 * b.oraclePxE6) / E8;
        pl.spotN = (b.spotE8 * b.oraclePxE6) / E8;
        pl.spotSane = _within(b.spotPxE6, b.oraclePxE6, p.maxSpotDeviationBps);
        // Unwind to zero when paused or funding is deeply negative. Hold size when adding is not
        // allowed: drawdown, mildly negative funding, unfunded claims, spot off the oracle.
        int256 funding = s.fundingEmaE18 / 1e10;
        bool unwind = s.exposurePaused || funding < p.fundingUnwindE8;
        // slither-disable-next-line incorrect-equality
        pl.mayAdd = !unwind && !s.drawdownTripped && funding >= p.fundingPauseE8 && pl.shortfall == 0
            && pl.spotSane;
        // Spot plus margin is target x (1 + 1/leverage); both come out of equity less the buffer.
        pl.target = unwind
            ? 0
            : (pl.equity * (BPS - p.idleBufferBps) * p.targetLeverageBps) / (BPS * (BPS + p.targetLeverageBps));
        if (!pl.mayAdd && pl.target > pl.shortN) pl.target = pl.shortN;
        pl.tol = (pl.target * p.deltaToleranceBps) / BPS + MIN_MOVE;
    }

    function _fixDelta(
        IDeltaNeutral.State storage s,
        IDeltaNeutral.Market memory m,
        IDeltaNeutral.Book memory b,
        Plan memory pl
    ) internal returns (bool) {
        uint256 larger = pl.shortN > pl.spotN ? pl.shortN : pl.spotN;
        uint256 diffN = pl.shortN > pl.spotN ? pl.shortN - pl.spotN : pl.spotN - pl.shortN;
        // slither-disable-next-line incorrect-equality
        if (larger == 0 || diffN * BPS <= larger * s.params.deltaToleranceBps || diffN < MIN_MOVE) return false;
        if (b.spotE8 > b.shortE8) {
            uint256 size = _cap(s, b.spotE8 - b.shortE8, b.oraclePxE6);
            // Too little short: sell perp while exposure may grow and margin allows; else sell spot.
            if (pl.mayAdd && _leverageAfter(b, size) <= s.params.maxLeverageBps) {
                _send(_prepare(s, m, false, false, size, b.oraclePxE6, false, true));
            } else if (pl.spotSane) {
                _send(_prepare(s, m, true, false, size, b.spotPxE6, false, true));
            } else {
                return false;
            }
        } else {
            // Too little spot: close some short, reduce-only. Never buy spot to chase it: that would
            // spend USDC that may be owed to exits.
            uint256 size = _cap(s, b.shortE8 - b.spotE8, b.oraclePxE6);
            _send(_prepare(s, m, false, true, size, b.oraclePxE6, true, true));
        }
        return true;
    }

    function _overLeveraged(IDeltaNeutral.State storage s, IDeltaNeutral.Book memory b) internal view returns (bool) {
        // slither-disable-next-line incorrect-equality
        return b.ntlPos > 0 && (b.perpValue == 0 || b.ntlPos * BPS > b.perpValue * s.params.maxLeverageBps);
    }

    /// @dev Top up margin back to target leverage from spot USDC if that is enough; otherwise move
    ///      what there is and shrink both legs in the same call (the transfer lands before the orders).
    ///      False when it did nothing: no spot USDC, and spot outside the band (`_reduceBoth`).
    function _deleverage(
        IDeltaNeutral.State storage s,
        IDeltaNeutral.Market memory m,
        IDeltaNeutral.Book memory b,
        bool budgeted
    ) internal returns (bool) {
        uint256 wanted = (b.ntlPos * BPS) / s.params.targetLeverageBps;
        uint256 topUp = wanted > b.perpValue ? wanted - b.perpValue : 0;
        bool acted = false;
        if (b.coreUsdc >= MIN_MOVE) {
            _acted(s, "top up margin from spot", 0);
            HyperCore.usdClassTransfer(uint64(b.coreUsdc < topUp ? b.coreUsdc : topUp), true);
            if (b.coreUsdc >= topUp) return true;
            acted = true;
        }
        return _reduceBoth(s, m, b, _cap(s, b.shortE8, b.oraclePxE6), budgeted) || acted;
    }

    /// @dev One liquidity step towards `amount` USDC on HyperEVM. `budgeted` charges orders to the
    ///      keeper's turnover window; exits are not budgeted, since claims bound them.
    function _raiseUsdc(
        IDeltaNeutral.State storage s,
        IDeltaNeutral.Market memory m,
        IDeltaNeutral.Book memory b,
        uint256 amount,
        bool budgeted
    ) internal returns (bool) {
        if (b.coreUsdc >= MIN_MOVE) {
            uint256 x = b.coreUsdc < amount ? b.coreUsdc : amount;
            _acted(s, "bridge USDC to HyperEVM", 0);
            HyperCore.sendAsset(
                HyperCore.systemAddress(HyperCore.USDC_TOKEN),
                HyperCore.SPOT_DEX,
                HyperCore.SPOT_DEX,
                HyperCore.USDC_TOKEN,
                uint64(x * 100)
            );
            return true;
        }
        uint256 free = _freeMargin(s, b);
        if (free >= MIN_MOVE) {
            _acted(s, "release perp margin to spot", 0);
            HyperCore.usdClassTransfer(uint64(free < amount ? free : amount), false);
            return true;
        }
        // Selling spot raises the USDC; closing the same size of short keeps delta flat and frees
        // margin for the next step. While spot is outside the band neither happens (M-05), and
        // `processExits` reverts `NothingToDo` until it is back.
        return (b.shortE8 > 0 || b.spotE8 > 0)
            && _reduceBoth(s, m, b, (amount * (BPS + s.params.slippageBps) * E8) / (b.oraclePxE6 * BPS), budgeted);
    }

    /// @dev Perp margin above what `maxLeverageBps` requires: it can leave without raising risk.
    function _freeMargin(IDeltaNeutral.State storage s, IDeltaNeutral.Book memory b) internal view returns (uint256) {
        uint256 required = (b.ntlPos * BPS) / s.params.maxLeverageBps;
        uint256 excess = b.perpValue > required ? b.perpValue - required : 0;
        return excess < b.withdrawablePerp ? excess : b.withdrawablePerp;
    }

    /// @dev Margin first, then spot USDC, then both orders in the same call. When neither can be
    ///      funded any further, the chunk shrinks to what the balances already support.
    function _addExposure(
        IDeltaNeutral.State storage s,
        IDeltaNeutral.Market memory m,
        IDeltaNeutral.Book memory b,
        Plan memory pl
    ) internal returns (bool) {
        IDeltaNeutral.Params memory p = s.params;
        uint256 chunkN = pl.target - pl.shortN;
        if (chunkN > p.maxOrderNotional) chunkN = p.maxOrderNotional;
        uint256 marginNeed = ((pl.shortN + chunkN) * BPS) / p.targetLeverageBps;
        if (b.perpValue < marginNeed) {
            uint256 gap = marginNeed - b.perpValue;
            if (b.coreUsdc >= MIN_MOVE) {
                _acted(s, "fund margin from spot", 0);
                HyperCore.usdClassTransfer(uint64(b.coreUsdc < gap ? b.coreUsdc : gap), true);
                return true;
            }
            if (_bridgeToCore(s, m, b, pl.equity, true, gap)) return true;
            uint256 supported = (b.perpValue * p.targetLeverageBps) / BPS;
            chunkN = supported > pl.shortN ? supported - pl.shortN : 0;
        }
        uint256 spotCost = (chunkN * (BPS + p.slippageBps)) / BPS;
        if (b.coreUsdc < spotCost) {
            if (_bridgeToCore(s, m, b, pl.equity, false, spotCost - b.coreUsdc)) return true;
            uint256 affordable = (b.coreUsdc * BPS) / (BPS + p.slippageBps + 10);
            if (affordable < chunkN) chunkN = affordable;
        }
        if (chunkN < MIN_MOVE) return false;
        uint256 sizeE8 = (chunkN * E8) / b.oraclePxE6;
        Order memory buySpot = _prepare(s, m, true, true, sizeE8, b.spotPxE6, false, true);
        Order memory sellPerp = _prepare(s, m, false, false, sizeE8, b.oraclePxE6, false, true);
        _send(buySpot);
        _send(sellPerp);
        return true;
    }

    /// @dev Bridge up to `wanted` USDC - never what is owed or the buffer - to HyperCore through
    ///      Circle's CoreDepositWallet: to the perp dex for margin, to spot otherwise. The extra dollar
    ///      covers Circle's fee for creating the HyperCore account on the first deposit.
    function _bridgeToCore(
        IDeltaNeutral.State storage s,
        IDeltaNeutral.Market memory m,
        IDeltaNeutral.Book memory b,
        uint256 eq,
        bool toPerp,
        uint256 wanted
    ) internal returns (bool) {
        uint256 keep = s.totalOwed + (eq * s.params.idleBufferBps) / BPS;
        if (b.evmUsdc <= keep + MIN_MOVE) return false;
        uint256 amount = b.evmUsdc - keep;
        if (amount > wanted + MIN_MOVE) amount = wanted + MIN_MOVE;
        if (amount > s.params.maxOrderNotional) amount = s.params.maxOrderNotional;
        _acted(s, toPerp ? "bridge USDC to perp margin" : "bridge USDC to spot", 0);
        m.usdc.forceApprove(address(m.depositWallet), amount);
        m.depositWallet.deposit(amount, toPerp ? 0 : HyperCore.SPOT_DEX);
        return true;
    }

    /**
     * @dev Close `sizeE8` of both legs together: buy back the short (reduce-only), sell spot. Both
     *      orders are prepared - and charged to the turnover window - before either is sent.
     *
     *      The short bought back is never more than the spot sold with it plus whatever short is
     *      already unhedged (M-05). Spot outside the band is not sold, and closing the short on its
     *      own would leave the vault long the spot it still holds - exactly the exposure the vault
     *      exists not to have. So off the band only an excess short is closed, and with none there
     *      is nothing to do: returns false and sends nothing.
     */
    function _reduceBoth(
        IDeltaNeutral.State storage s,
        IDeltaNeutral.Market memory m,
        IDeltaNeutral.Book memory b,
        uint256 sizeE8,
        bool budgeted
    ) internal returns (bool) {
        uint256 spotSz = 0;
        if (_within(b.spotPxE6, b.oraclePxE6, s.params.maxSpotDeviationBps)) {
            // Rounded to the spot lot here, so the perp is capped by what will actually be sold.
            spotSz = HyperCore.roundSz(_cap(s, sizeE8 < b.spotE8 ? sizeE8 : b.spotE8, b.oraclePxE6), m.spotSzDecimals);
        }
        uint256 shortSz = _cap(s, sizeE8 < b.shortE8 ? sizeE8 : b.shortE8, b.oraclePxE6);
        uint256 shortMax = spotSz + (b.shortE8 > b.spotE8 ? b.shortE8 - b.spotE8 : 0);
        if (shortSz > shortMax) shortSz = shortMax;
        Order memory perp = _prepare(s, m, false, true, shortSz, b.oraclePxE6, true, budgeted);
        Order memory spot = _prepare(s, m, true, false, spotSz, b.spotPxE6, false, budgeted);
        // slither-disable-next-line incorrect-equality
        if (perp.sz == 0 && spot.sz == 0) return false;
        _send(perp);
        _send(spot);
        return true;
    }

    /**
     * @dev Price an IOC order `slippageBps` through `refPxE6` - the perp oracle for perps, the spot
     *      price for spot, which `_plan` requires to be near the oracle - and round it to a valid tick:
     *      buys down, sells up, so the tick never widens the band. Size rounds down to the lot
     *      (api/tick-and-lot-size: at most 6 - szDecimals price decimals for perps, 8 - szDecimals for
     *      spot). Charges the turnover window and records the action before any external call. A size
     *      that rounds to zero prepares an order `_send` skips.
     */
    function _prepare(
        IDeltaNeutral.State storage s,
        IDeltaNeutral.Market memory m,
        bool isSpot,
        bool isBuy,
        uint256 sizeE8,
        uint256 refPxE6,
        bool reduceOnly,
        bool budgeted
    ) internal returns (Order memory o) {
        uint256 szDecimals = isSpot ? m.spotSzDecimals : m.perpSzDecimals;
        uint256 sz = HyperCore.roundSz(sizeE8, szDecimals);
        if (sz < 1) return o;
        uint256 band = isBuy ? BPS + s.params.slippageBps : BPS - s.params.slippageBps;
        uint256 px = HyperCore.roundPx((refPxE6 * band * 100) / BPS, (isSpot ? 8 : 6) - szDecimals, !isBuy);
        uint256 notional = (sz * refPxE6) / E8;
        if (budgeted) _spendTurnover(s, notional);
        _acted(s, isBuy ? "buy" : "sell", notional);
        o = Order({
            asset: isSpot ? HyperCore.SPOT_ASSET_OFFSET + m.spotMarket : m.perp,
            isBuy: isBuy,
            px: uint64(px),
            sz: uint64(sz),
            reduceOnly: reduceOnly
        });
    }

    function _send(Order memory o) internal {
        if (o.sz > 0) HyperCore.limitOrder(o.asset, o.isBuy, o.px, o.sz, o.reduceOnly, HyperCore.TIF_IOC, 0);
    }

    function _cap(IDeltaNeutral.State storage s, uint256 sizeE8, uint256 pxE6) internal view returns (uint256) {
        uint256 maxSize = (uint256(s.params.maxOrderNotional) * E8) / pxE6;
        return sizeE8 < maxSize ? sizeE8 : maxSize;
    }

    function _leverageAfter(IDeltaNeutral.Book memory b, uint256 addShortE8) internal pure returns (uint256) {
        // slither-disable-next-line incorrect-equality
        if (b.perpValue == 0) return type(uint256).max;
        return ((b.ntlPos + (addShortE8 * b.oraclePxE6) / E8) * BPS) / b.perpValue;
    }

    function _within(uint256 a, uint256 ref, uint256 bps) internal pure returns (bool) {
        uint256 diff = a > ref ? a - ref : ref - a;
        return diff * BPS <= ref * bps;
    }

    function _spendTurnover(IDeltaNeutral.State storage s, uint256 notional) internal {
        if (block.timestamp >= uint256(s.turnoverWindowStart) + WINDOW) {
            s.turnoverWindowStart = uint64(block.timestamp);
            s.turnoverUsed = 0;
        }
        if (s.turnoverUsed + notional > s.params.maxDailyTurnover) revert IDeltaNeutral.TurnoverExhausted();
        s.turnoverUsed += notional;
    }

    function _acted(IDeltaNeutral.State storage s, string memory step, uint256 notional) internal {
        s.lastCoreActionAt = uint64(block.timestamp);
        emit IDeltaNeutral.CoreAction(step, notional);
    }

    /*//////////////////////////////////////////////////////////////
                               FUNDING
    //////////////////////////////////////////////////////////////*/

    /**
     * @dev Estimate hourly funding from the book the way Hyperliquid computes it from impact prices:
     *      premium = (max(bid - oracle, 0) - max(oracle - ask, 0)) / oracle, then
     *      F(8h) = premium + clamp(0.01% - premium, -0.05%, 0.05%), hourly = F / 8.
     *      `packages/yield/src/delta-neutral.ts` checks the formula reproduces Hyperliquid's published
     *      hourly rates from its published premiums, and backtests this average's breaker.
     *      Best bid and ask stand in for impact prices. Each sample's weight is the time since the
     *      previous one, so sampling more often adds precision, not influence.
     */
    function _sampleFunding(IDeltaNeutral.State storage s, IDeltaNeutral.Book memory b) internal {
        uint256 dt = block.timestamp - s.lastFundingSampleAt;
        // slither-disable-next-line incorrect-equality
        if (dt == 0) return;
        int256 oracle = int256(b.oracleRaw);
        int256 above = int256(b.bid) > oracle ? int256(b.bid) - oracle : int256(0);
        int256 below = oracle > int256(b.ask) ? oracle - int256(b.ask) : int256(0);
        int256 premium = ((above - below) * int256(E8)) / oracle;
        if (premium > MAX_PREMIUM_E8) premium = MAX_PREMIUM_E8;
        if (premium < -MAX_PREMIUM_E8) premium = -MAX_PREMIUM_E8;
        int256 adj = INTEREST_8H_E8 - premium;
        if (adj > CLAMP_8H_E8) adj = CLAMP_8H_E8;
        if (adj < -CLAMP_8H_E8) adj = -CLAMP_8H_E8;
        int256 hourlyE18 = ((premium + adj) * 1e10) / 8;

        uint256 tau = s.params.fundingTau;
        if (dt > 4 * tau) dt = 4 * tau;
        int256 ema = s.fundingEmaE18;
        ema += ((hourlyE18 - ema) * int256(dt)) / int256(tau + dt);
        s.fundingEmaE18 = ema;
        s.lastFundingSampleAt = uint64(block.timestamp);
        emit IDeltaNeutral.FundingSampled(hourlyE18 / 1e10, ema / 1e10);
    }
}
