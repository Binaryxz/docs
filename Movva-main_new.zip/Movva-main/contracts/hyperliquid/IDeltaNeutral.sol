// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {ICoreDepositWallet} from "./HyperCore.sol";

/**
 * @title IDeltaNeutral
 * @notice The types, events and errors shared by `HyperCoreDeltaNeutralVault` and the
 *         `DeltaNeutralStrategy` library it delegates its HyperCore logic to.
 *
 * Declared once, here, so the vault's ABI carries every event and error the strategy can emit or
 * revert with (the strategy runs in the vault's context, so its events are the vault's events),
 * and so the two can never disagree about a struct's layout. Solidity does not resolve an
 * inherited error through the derived contract's name, so tests refer to errors as
 * `IDeltaNeutral.NothingToDo`; the selectors are what they always were.
 */
interface IDeltaNeutral {
    struct Params {
        /// Short notional over perp margin at target, in bps (20_000 = 2x).
        uint16 targetLeverageBps;
        /// The keeper never adds exposure past this, and above it anyone may `deleverage`.
        uint16 maxLeverageBps;
        /// IOC limit band around the reference price; 10 to 200 bps. Any change waits: exits and
        /// `deleverage` trade inside it, so narrowing it can stop them filling.
        uint16 slippageBps;
        /// |spot size - short size| tolerated, as bps of the larger leg's notional.
        uint16 deltaToleranceBps;
        /// Spot trades, and shares are priced (deposit, requestRedeem, checkpoint), only while the spot
        /// price is within this of the perp oracle. At least 50 bps: a band tight enough to block
        /// every exit is not a setting. Any change waits out the governance delay.
        uint16 maxSpotDeviationBps;
        /// Equity kept as USDC on HyperEVM for instant exits.
        uint16 idleBufferBps;
        uint16 maxDrawdownBps;
        /// Charged on redemptions and left in the vault: it pays for the unwind an exit causes. Any
        /// change waits: up costs exiting holders, down costs the ones who stay.
        uint16 exitFeeBps;
        /// Hourly funding estimate (1e8 = 100%) below which no new exposure is added.
        int32 fundingPauseE8;
        /// Below this, exposure is actively unwound.
        int32 fundingUnwindE8;
        /// Time constant of the funding estimate's exponential average, seconds.
        uint32 fundingTau;
        /// Seconds between keeper calls; at most one day.
        uint32 minActionInterval;
        /// Seconds after a CoreWriter action before anything priced or acting runs; 2 to 60. Any
        /// change waits: longer delays exits, shorter prices shares on value still in flight.
        uint32 settleSeconds;
        /// USD (1e6) per order, per leg, per call - exits included. Any change waits: a tiny cap
        /// would make `processExits` crawl.
        uint64 maxOrderNotional;
        /// USD (1e6) of keeper-placed order notional per 24h window.
        uint64 maxDailyTurnover;
        /// USD (1e6) of equity above which deposits stop.
        uint64 depositCap;
    }

    /**
     * @dev Everything the strategy reads or writes in the vault's storage, in one struct so the
     *      library receives a single storage pointer and nothing else: not the share balances, not
     *      the claims, not the roles, not the governance queue.
     */
    struct State {
        Params params;
        /// Kept at 1e18 so a one-hour sample against an 84-hour time constant is not truncated to
        /// nothing: at 1e8 the average stalled 84 units short of a steady input (SR3-7).
        int256 fundingEmaE18;
        uint64 lastFundingSampleAt;
        uint64 lastCoreActionAt;
        uint64 turnoverWindowStart;
        uint256 turnoverUsed;
        /// USDC owed to recorded claims. Written by the vault; the strategy only reads it.
        uint256 totalOwed;
        bool exposurePaused;
        bool drawdownTripped;
    }

    /// @dev The market, rebuilt from the vault's immutables on every call. `maxLeverage` is the
    ///      venue's own maximum, read from HyperCore at deployment.
    struct Market {
        IERC20 usdc;
        ICoreDepositWallet depositWallet;
        uint32 perp;
        uint32 spotMarket;
        uint64 spotToken;
        uint8 perpSzDecimals;
        uint8 spotSzDecimals;
        uint8 spotWeiDecimals;
        uint8 maxLeverage;
    }

    /// @dev What the strategy reads before deciding anything. Sizes are human x 1e8 (CoreWriter's
    ///      scale); prices human x 1e6; USD 1e6.
    struct Book {
        uint256 oracleRaw;
        uint256 oraclePxE6;
        uint256 spotPxE6;
        uint256 bid;
        uint256 ask;
        uint256 shortE8;
        uint256 longPerpE8;
        uint256 spotE8;
        uint256 spotValue;
        uint256 perpValue;
        uint256 ntlPos;
        uint256 withdrawablePerp;
        uint256 coreUsdc;
        uint256 evmUsdc;
        bool coreUser;
    }

    event Deposited(address indexed from, address indexed receiver, uint256 assets, uint256 shares);
    event Redeemed(address indexed owner, address indexed receiver, uint256 shares, uint256 assets);
    event ClaimQueued(uint256 indexed id, address indexed receiver, uint256 shares, uint256 assets);
    event ClaimPaid(uint256 indexed id, address indexed receiver, uint256 assets);
    event CoreAction(string step, uint256 notional);
    event FundingSampled(int256 hourlyE8, int256 emaE8);
    event CircuitBreaker(string which, bool tripped);
    event ParamsSet(Params p);
    event RoleSet(string role, address indexed account);

    error NotKeeper();
    error NotGuardianOrGovernor();
    error CoreUnreadable();
    error BadMarket();
    error BadParams();
    error NotSettled(uint256 readyAt);
    error TooSoon(uint256 readyAt);
    error NothingToDo();
    error DepositsClosed();
    error OverDepositCap();
    error ZeroAmount();
    error UnknownClaim();
    error NotYetLiquid(uint256 needed, uint256 available);
    error TurnoverExhausted();
    /// @dev The spot price is outside `maxSpotDeviationBps` of the perp oracle: no honest share price.
    error SpotOffOracle();
    /// @dev Shares minted less than `MIN_HOLD` ago cannot be redeemed or transferred until `until`.
    error SharesLocked(uint256 until);
}
