// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IPriceOracle} from "./IPriceOracle.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";

/**
 * @title SignedPriceOracle
 * @notice A BRL price published by an M-of-N quorum of signers (task 2.5, third option).
 *
 * ## Why this exists, and what it costs
 *
 * There is no usable BRL/USD feed on Ethereum L1. Pyth carries none; Chainlink's aggregator
 * is gated to EOA readers and last updated in August 2023. Both of our feed adapters
 * correctly refuse to price BRL there, which left the ramp undeployable on mainnet - a
 * blocker that no amount of correctness in the escrows fixes.
 *
 * This is the honest third option: name the parties who publish the price, make their
 * signatures public and attributable, and let the escrow use it as a sanity band. It is
 * strictly weaker than a maintained decentralised feed and is not pretending otherwise. Use
 * ChainlinkBrlOracle or PythBrlOracle on any chain where a live BRL feed exists; use this
 * where none does, and know exactly whose word you are taking.
 *
 * ## What a corrupt quorum can actually do
 *
 * Less than it first appears, because the escrows use the oracle as a BAND and never as the
 * price. A trade's price is what the LP posted and the taker accepted; the oracle only
 * decides which pairs are too absurd to allow. So M colluding publishers can widen the band
 * until silly offers become postable, or narrow it until honest ones are refused - a
 * censorship and nuisance power, not a way to move value. That distinction is the whole
 * reason the band design was worth keeping.
 *
 * The remaining exposure is a user who does not read the price they are accepting. The band
 * is a backstop against fat fingers, not a substitute for the taker's own limit price, and
 * `MatchRequest.maxPriceBrlCentsPerEth` exists for that reason.
 *
 * ## Push, not pull
 *
 * Anyone may submit a signed price; the signatures are what authorise it, not the sender.
 * That means keeping the oracle fresh is permissionless work a relayer can do, and a
 * publisher going offline degrades freshness rather than halting the system - until the
 * quorum cannot be met, at which point this reverts and the escrows stop trading. Which is
 * the correct failure: no price must stop a trade, never allow one at a guess.
 *
 * ## Who decides who signs (DelayedGovernance)
 *
 * The quorum is only as trustworthy as the key that picks it. This instance is the FX leg of
 * the ramps' USDT band (ChainlinkSignedFxOracle) and, signed in millionths, the rate
 * MovvaReserve mints and redeems at. The reserve delays repointing its FX leg - and this
 * contract used to let its governor `setPublisher(itself, true)` and `setThreshold(1)` in one
 * block, then sign any rate alone. So:
 *
 *  - Adding a publisher and lowering the threshold wait out GOVERNANCE_DELAY in public: the
 *    exact calldata is on-chain before it can run, long enough for gateways to redeem, LPs to
 *    close offers, and the owners of the key to rotate it and cancel.
 *  - Raising the threshold and removing a publisher are instant. Removal is the response to a
 *    leaked publisher key and must be as fast as the governor can sign.
 *
 * Removal never touches the threshold. It used to drag the threshold down to the remaining
 * count, "so the price never freezes" - which made removal an undelayed threshold cut. From
 * the attacker's side: a governor holding one publisher key (its own, or a colluding
 * publisher's) removes every other publisher and is left signing 1-of-1 with no notice at all.
 * Without the auto-lowering, removal can only shrink the set of coalitions able to sign; no
 * signature valid after it was invalid before. What an instant removal CAN still do is freeze
 * the price, if it leaves fewer publishers than the threshold: nothing can be signed, the rate
 * goes stale within its consumers' max age, and they stop. That is a brake, and the same power
 * the governor of a consumer already has instantly (tightening a max age on the reserve or a
 * cross). Recovery - a lower threshold or a re-added publisher - waits out the delay, like any
 * other change that lets a key sign again. Refusing a removal that would leave the set below
 * the threshold would be worse: with a 2-of-2 set and both keys leaked, the governor could
 * then remove neither, and the thieves would keep signing.
 *
 * ## Setup, and why reading the price waits for it
 *
 * For an oracle the user business is reading the price. `brlCentsPerUnit` reverts
 * `SetupIncomplete` until `completeSetup()`, so no escrow, cross or reserve can price anything
 * from an instance whose governor still has instant power over who signs - every consumer
 * fails closed on it, as on a stale price. `submit` works during setup, so a deployment can
 * have a rate ready the moment setup closes.
 */
contract SignedPriceOracle is IPriceOracle, DelayedGovernance {
    bytes32 private constant PRICE_TYPEHASH =
        keccak256("Price(uint256 brlCentsPerUnit,uint64 publishedAt,uint64 sequence)");
    bytes32 private constant DOMAIN_TYPEHASH = keccak256(
        "EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)"
    );

    mapping(address => bool) public isPublisher;
    uint256 public publisherCount;
    uint256 public threshold;

    uint256 public price;
    uint64 public publishedAt;
    /// @notice Monotonic, so an old signed price cannot be replayed over a newer one.
    uint64 public sequence;

    /// @notice Refuse a price whose timestamp is further ahead of the chain than this.
    uint64 public constant MAX_FUTURE_SKEW = 5 minutes;

    event PriceSubmitted(uint256 price, uint64 publishedAt, uint64 sequence);
    event PublisherSet(address indexed publisher, bool active);
    event ThresholdSet(uint256 threshold);
    // `governor`, `transferGovernor`, `GovernorTransferred(address indexed, address indexed)`,
    // `NotGovernor()` and `ZeroAddress()` were declared here and are now DelayedGovernance's,
    // with identical signatures: the getter, the event topic and the error selectors off-chain
    // readers decode are unchanged.

    error BadThreshold();
    error BadPrice();
    error StaleSequence(uint64 got, uint64 have);
    error SequenceAheadOfTimestamp(uint64 sequence, uint64 publishedAt);
    error StaleTimestamp(uint64 got, uint64 have);
    error TimestampInFuture(uint64 publishedAt, uint256 now_);
    error NotEnoughSignatures(uint256 got, uint256 need);
    error SignaturesUnsorted();
    error UnknownPublisher(address signer);
    error MalformedSignature();
    error NoPriceYet();

    constructor(address governor_, uint256 governanceDelay, address[] memory publishers, uint256 threshold_)
        DelayedGovernance(governor_, governanceDelay)
    {
        for (uint256 i; i < publishers.length; ++i) {
            if (publishers[i] == address(0)) revert ZeroAddress();
            if (!isPublisher[publishers[i]]) {
                isPublisher[publishers[i]] = true;
                ++publisherCount;
                emit PublisherSet(publishers[i], true);
            }
        }
        _setThreshold(threshold_);
    }

    /**
     * @notice Publish a price signed by a quorum.
     * @param signatures Sorted strictly ascending by recovered signer - duplicates are how
     *        an M-of-N check silently becomes 1-of-N.
     */
    function submit(
        uint256 brlCents,
        uint64 publishedAt_,
        uint64 sequence_,
        bytes[] calldata signatures
    ) external {
        if (brlCents == 0) revert BadPrice();
        if (sequence_ <= sequence) revert StaleSequence(sequence_, sequence);
        // A sequence may not run ahead of its own timestamp. Monotonic alone, one quorum signature
        // over sequence = type(uint64).max froze the oracle for good: every later price was
        // "stale", and recovery meant a new oracle and a delayed repoint of every consumer.
        // Tied to publishedAt - itself at most MAX_FUTURE_SKEW ahead of the chain - the furthest a
        // quorum can push the sequence is five minutes past now, after which publishers deriving
        // it from the clock (price-publisher.ts sequenceFromTime) carry on.
        if (sequence_ > publishedAt_) revert SequenceAheadOfTimestamp(sequence_, publishedAt_);
        // Freshness must not go backwards. A quorum could otherwise sign a higher sequence
        // carrying an older timestamp - deliberately or by a publisher's clock being wrong -
        // and the escrows, which judge staleness by publishedAt, would start refusing trades
        // against a price that is in fact current.
        if (publishedAt_ < publishedAt) revert StaleTimestamp(publishedAt_, publishedAt);
        // A future timestamp would let a quorum mint freshness that outlives their signing.
        if (publishedAt_ > block.timestamp + MAX_FUTURE_SKEW) {
            revert TimestampInFuture(publishedAt_, block.timestamp);
        }
        if (signatures.length < threshold) {
            revert NotEnoughSignatures(signatures.length, threshold);
        }

        bytes32 d = digest(brlCents, publishedAt_, sequence_);
        address last = address(0);
        for (uint256 i; i < signatures.length; ++i) {
            address signer = _recover(d, signatures[i]);
            if (!isPublisher[signer]) revert UnknownPublisher(signer);
            if (signer <= last) revert SignaturesUnsorted();
            last = signer;
        }

        price = brlCents;
        publishedAt = publishedAt_;
        sequence = sequence_;
        emit PriceSubmitted(brlCents, publishedAt_, sequence_);
    }

    /// @inheritdoc IPriceOracle
    /// @dev Reverts `SetupIncomplete` until setup is complete (see the header), and before any
    ///      price exists. The escrows also enforce their own MAX_PRICE_AGE against
    ///      `publishedAt`, so staleness is judged where the money is.
    function brlCentsPerUnit() external view returns (uint256, uint64) {
        _requireSetupComplete();
        if (publishedAt == 0) revert NoPriceYet();
        return (price, publishedAt);
    }

    function digest(uint256 brlCents, uint64 at, uint64 seq) public view returns (bytes32) {
        bytes32 structHash = keccak256(abi.encode(PRICE_TYPEHASH, brlCents, at, seq));
        return keccak256(abi.encodePacked("\x19\x01", domainSeparator(), structHash));
    }

    function domainSeparator() public view returns (bytes32) {
        return keccak256(
            abi.encode(
                DOMAIN_TYPEHASH,
                keccak256("PrivacyPoolsBRL-Price"),
                keccak256("1"),
                block.chainid,
                address(this)
            )
        );
    }

    /*//////////////////////////////////////////////////////////////
                              GOVERNANCE
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Adding a publisher waits out the governance delay; removing one is instant.
     * @dev Removal leaves the threshold where it is, even above the remaining count: see "Who
     *      decides who signs" in the header for why an instant removal must not be a threshold
     *      cut, and why a freeze is the acceptable cost. A signed price not yet submitted stops
     *      counting a removed publisher at once, because `submit` checks the set when it runs.
     */
    function setPublisher(address publisher, bool active) external {
        _authorizeChange(active && !isPublisher[publisher]);
        if (publisher == address(0)) revert ZeroAddress();
        if (isPublisher[publisher] == active) return;
        isPublisher[publisher] = active;
        if (active) ++publisherCount;
        else --publisherCount;
        emit PublisherSet(publisher, active);
    }

    /// @notice Lowering the threshold waits out the governance delay; raising it is instant.
    ///         Either way it must be reachable by the current set, checked again on execution.
    function setThreshold(uint256 t) external {
        _authorizeChange(t < threshold);
        _setThreshold(t);
    }

    function _isDelayable(bytes4 selector) internal pure override returns (bool) {
        return selector == SignedPriceOracle.setPublisher.selector
            || selector == SignedPriceOracle.setThreshold.selector;
    }

    function _setThreshold(uint256 t) private {
        if (t == 0 || t > publisherCount) revert BadThreshold();
        threshold = t;
        emit ThresholdSet(t);
    }

    function _recover(bytes32 d, bytes memory sig) private pure returns (address) {
        if (sig.length != 65) revert MalformedSignature();
        bytes32 r;
        bytes32 s;
        uint8 v;
        assembly {
            r := mload(add(sig, 32))
            s := mload(add(sig, 64))
            v := byte(0, mload(add(sig, 96)))
        }
        if (uint256(s) > 0x7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5D576E7357A4501DDFE92F46681B20A0) {
            revert MalformedSignature();
        }
        address signer = ecrecover(d, v, r, s);
        if (signer == address(0)) revert MalformedSignature();
        return signer;
    }
}
