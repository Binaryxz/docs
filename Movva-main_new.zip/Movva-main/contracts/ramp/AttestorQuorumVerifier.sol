// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IAttestorVerifier} from "./IAttestorVerifier.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";

/**
 * @title AttestorQuorumVerifier
 * @notice Task 2.2, Phase A: M-of-N signed attestations that a PIX payment settled.
 *
 * ## What this is, stated plainly
 *
 * This is a TRUSTED verifier. A quorum of named attestors - a licensed PSP, an Open Finance
 * (Open Banking Brasil) reader, the protocol's own operator - each observe a bank settlement
 * and sign an EIP-712 statement about it. M of N agreeing releases the escrow.
 *
 * It is not zero-knowledge and it is not trust-minimised. M colluding attestors can forge a
 * payment that never happened and drain every offer that selected this verifier. The honest
 * description is "a multisig over reality", and the reason to build it first is that it is
 * the only design that works against Brazilian banking as it exists today: PIX has no
 * consumer-verifiable receipt a contract can check, and Open Finance access is licensed.
 *
 * The trust is bounded in three ways, and those bounds are the actual security argument:
 *
 *  1. Per-verifier opt-in, with notice. An LP selects the verifier for their own offer. An
 *     earlier version of this comment said nobody's liquidity was exposed to an attestor set
 *     they did not choose - but the governor chooses the set, and could add its own key and
 *     set the threshold to one in a single block, after every LP had opted in. Adding an
 *     attestor and lowering the threshold now wait out GOVERNANCE_DELAY in public, so an LP
 *     who does not accept the new set can close before it can sign anything. Removing an
 *     attestor and raising the threshold stay instant.
 *  2. Attestors are named on-chain and their signatures are public. Forgery is detectable
 *     after the fact and attributable to a licensed entity - which is what makes a licence
 *     worth anything here.
 *  3. It sits behind IAttestorVerifier, so a zkTLS implementation replaces it without
 *     touching the contract that holds the money. That migration is the point of the
 *     interface, not an afterthought.
 *
 * ## Card only
 *
 * That migration has happened for bank payments. Mova decided (14 September 2026) that PIX,
 * boleto and TED settle only on a zkTLS proof of the bank session, so the escrows refuse any
 * offer or sale on those rails through a verifier whose `provesBankSession()` is false - this
 * one. What remains for a quorum is the card rail: a capture at a licensed acquirer has no bank
 * session a payer could prove, and the card partner carries its chargeback risk under contract.
 *
 * ## Binding
 *
 * The signed struct contains `orderId`. A receipt for a genuine payment is otherwise a
 * bearer instrument: an attacker watches for any real payment to an LP's PIX key and
 * presents it against their own order. Attestors MUST refuse to sign for an order whose
 * amount and payee do not match what they observed - the escrow re-checks payee and amount,
 * but only the attestor can see the bank.
 *
 * For a boleto the payee is a salted commitment to the barcode paid, and an attestor MUST derive
 * it from the paid document it observed (line plus the salt it was given) rather than sign a
 * commitment handed to it - `Attestor.attestBoleto` in packages/ramp/src/attestor.ts. The rail is
 * inside the signed struct, so a PIX attestation cannot be relabelled as a boleto payment.
 */
contract AttestorQuorumVerifier is IAttestorVerifier, DelayedGovernance {
    bytes32 private constant PAYMENT_TYPEHASH = keccak256(
        "Payment(bytes32 orderId,bytes32 bankTxId,bytes32 payeeKeyHash,bytes32 payerRef,uint256 amountBrlCents,uint64 paidAt,uint8 rail)"
    );
    bytes32 private constant DOMAIN_TYPEHASH =
        keccak256("EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)");

    mapping(address => bool) public isAttestor;
    uint256 public attestorCount;
    uint256 public threshold;

    event AttestorSet(address indexed attestor, bool active);
    event ThresholdSet(uint256 threshold);

    error BadThreshold();
    error NotEnoughSignatures(uint256 got, uint256 need);
    error SignaturesUnsorted();
    error UnknownAttestor(address signer);
    error MalformedProof();

    constructor(
        address governor_,
        uint256 governanceDelay,
        address[] memory attestors,
        uint256 threshold_
    ) DelayedGovernance(governor_, governanceDelay) {
        for (uint256 i; i < attestors.length; ++i) {
            if (attestors[i] == address(0)) revert ZeroAddress();
            if (!isAttestor[attestors[i]]) {
                isAttestor[attestors[i]] = true;
                ++attestorCount;
                emit AttestorSet(attestors[i], true);
            }
        }
        _setThreshold(threshold_);
    }

    function attestorKind() external pure returns (string memory) {
        return "quorum/eip712/pix-v1";
    }

    /// @inheritdoc IAttestorVerifier
    /// @dev False: a quorum swears to a payment rather than proving the bank session, so the
    ///      escrows accept this verifier for card captures only - see "Card only" in the header.
    function provesBankSession() external pure returns (bool) {
        return false;
    }

    /**
     * @param proof abi.encode(Payment fields..., bytes[] signatures)
     * @dev Signatures must be sorted by recovered signer, strictly ascending. That is how
     *      duplicates are rejected: without it, M copies of one attestor's signature satisfy
     *      an M-of-N threshold, which is the classic way a quorum check turns into a 1-of-N.
     */
    function verifyPayment(bytes32 orderId, bytes calldata proof)
        external
        view
        returns (Payment memory p)
    {
        _requireSetupComplete();
        bytes[] memory sigs;
        uint8 rail;
        (p.bankTxId, p.payeeKeyHash, p.payerRef, p.amountBrlCents, p.paidAt, rail, sigs) =
            abi.decode(proof, (bytes32, bytes32, bytes32, uint256, uint64, uint8, bytes[]));
        p.rail = Rail(rail);

        if (sigs.length < threshold) revert NotEnoughSignatures(sigs.length, threshold);

        bytes32 digest = hashPayment(orderId, p);
        // Starts at the zero address deliberately: signers must ascend strictly, and no
        // valid ecrecover result is zero (that case reverts as MalformedProof).
        address last = address(0);
        for (uint256 i; i < sigs.length; ++i) {
            address signer = _recover(digest, sigs[i]);
            if (!isAttestor[signer]) revert UnknownAttestor(signer);
            if (signer <= last) revert SignaturesUnsorted();
            last = signer;
        }
    }

    function hashPayment(bytes32 orderId, Payment memory p) public view returns (bytes32) {
        bytes32 structHash = keccak256(
            abi.encode(
                PAYMENT_TYPEHASH,
                orderId,
                p.bankTxId,
                p.payeeKeyHash,
                p.payerRef,
                p.amountBrlCents,
                p.paidAt,
                uint8(p.rail)
            )
        );
        return keccak256(abi.encodePacked("\x19\x01", domainSeparator(), structHash));
    }

    function domainSeparator() public view returns (bytes32) {
        return keccak256(
            abi.encode(
                DOMAIN_TYPEHASH,
                keccak256("PrivacyPoolsBRL-Attestor"),
                keccak256("1"),
                block.chainid,
                address(this)
            )
        );
    }

    /*//////////////////////////////////////////////////////////////
                              GOVERNANCE
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Adding an attestor waits out the governance delay; removing one is instant.
     * @dev Removal no longer drags the threshold down with the set. It did, "so orders never
     *      freeze" - which made removal a threshold-lowering path that skipped any delay: a
     *      governor colluding with one attestor could remove the others and leave that one
     *      signing alone. If removals leave the threshold above the set, verification fails
     *      closed until a lower threshold is scheduled or attestors are re-added; stranded
     *      orders have the dispute path, as with a revoked verifier (SR2-7).
     */
    function setAttestor(address attestor, bool active) external {
        _authorizeChange(active && !isAttestor[attestor]);
        if (attestor == address(0)) revert ZeroAddress();
        if (isAttestor[attestor] == active) return;
        isAttestor[attestor] = active;
        if (active) ++attestorCount;
        else --attestorCount;
        emit AttestorSet(attestor, active);
    }

    /// @notice Lowering the threshold waits out the governance delay; raising it is instant.
    function setThreshold(uint256 t) external {
        _authorizeChange(t < threshold);
        _setThreshold(t);
    }

    function _isDelayable(bytes4 selector) internal pure override returns (bool) {
        return selector == AttestorQuorumVerifier.setAttestor.selector
            || selector == AttestorQuorumVerifier.setThreshold.selector;
    }

    function _setThreshold(uint256 t) private {
        if (t == 0 || t > attestorCount) revert BadThreshold();
        threshold = t;
        emit ThresholdSet(t);
    }

    function _recover(bytes32 digest, bytes memory sig) private pure returns (address) {
        if (sig.length != 65) revert MalformedProof();
        bytes32 r;
        bytes32 s;
        uint8 v;
        assembly {
            r := mload(add(sig, 32))
            s := mload(add(sig, 64))
            v := byte(0, mload(add(sig, 96)))
        }
        // Reject the high-s half of each signature pair. Both halves are valid ECDSA, so
        // without this one attestor's approval has two encodings - and a caller that treats
        // the proof bytes as an identifier would see them as different proofs.
        if (uint256(s) > 0x7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5D576E7357A4501DDFE92F46681B20A0) {
            revert MalformedProof();
        }
        address signer = ecrecover(digest, v, r, s);
        if (signer == address(0)) revert MalformedProof();
        return signer;
    }
}
