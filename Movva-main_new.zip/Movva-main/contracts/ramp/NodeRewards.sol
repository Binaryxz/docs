// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {Math} from "@openzeppelin/contracts/utils/math/Math.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {IRewardsHook} from "./IRewardsHook.sol";
import {LPRegistry} from "./LPRegistry.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";

/**
 * @title NodeRewards
 * @notice Node-provider rewards: a share of Mova's fee revenue, paid to the LPs who settle BRL volume, in
 *         proportion to it, epoch by epoch. Design: docs/movva.md, "Fees". Threat model: SR2-36 in
 *         docs/security-review-phase2.md.
 *
 * ## Where the money comes from
 *
 * Mova's revenue is Movva paid to `MovvaReserve.feeRecipient`: the mint and redeem fees gateways pay.
 * `FeeSplitter` is that recipient, and forwards `lpRewardShareBps` of what it receives
 * here and the rest to Mova's treasury. Nothing here mints: every reward paid is a token somebody paid in. Tokens
 * sent directly are counted too, by `sync`, as a donation to the epoch in which they are booked.
 *
 * ## How it is shared, with no loop over LPs
 *
 * Time is cut into epochs of `EPOCH_LENGTH` from deployment. `LPRegistry.recordSettled` reports each settlement
 * through `onSettled`, and an eligible one adds its centavos to the LP's volume for the current epoch and to the
 * epoch's total: two storage writes, however many LPs there are.
 *
 * Once an epoch has ended and its `REVIEW_PERIOD` has passed, anyone may `finalize` it, epochs in order. Its pool is
 * what was booked during it plus everything earlier epochs could not pay (`carry`); its budget is the smaller of
 * that pool and `rewardBpsOfVolume` of its volume. From then on the LP `claim`s, whenever it likes, for any list of
 * finalized epochs: `budget x its volume / the epoch's volume`, at most the epoch's per-LP cap.
 *
 * Nothing expires. An LP's unclaimed rewards wait for it, across any number of epochs. What an epoch cannot pay rolls
 * forward into the next one finalized: its whole pool when nobody eligible settled, the part of the pool above the
 * volume bound, the share of any voided volume, and - at the moment an LP claims - whatever lay above its cap.
 *
 * ## Farming, and what bounds it
 *
 * An LP can settle orders with itself: take its own offer from another address, pay its own PIX from another
 * account, and prove the payment. Fabricated volume costs it gas and nothing else, which is why LPRegistry refuses
 * to turn reputation into a score. Rewards in proportion to volume are exactly such a score, so the bounds are
 * enforced here rather than hoped for:
 *
 *  - **Who earns.** Only INSTITUTIONAL and AFFILIATED LPs, by the tier the registry reports at settlement:
 *    contracted parties, admitted through the governance delay or sponsored by one, for whom self-dealing is a
 *    breach with a named counterparty. Phase C's permissionless RETAIL LPs earn nothing, nor do SUSPENDED ones, so
 *    a farm cannot be built from fresh addresses.
 *  - **No more per real than a real trade pays in fees.** An epoch's budget never exceeds `rewardBpsOfVolume` of its
 *    volume: by default 10 bps, the reserve's mint fee, and never more than 20 (mint plus redeem). A fabricated
 *    R$ 1,00 of volume earns at most what Mova charged a gateway for minting that real, however large the pool.
 *  - **A ceiling per LP per epoch**, `maxRewardPerLpPerEpoch`, fixed for an epoch when it is finalized.
 *  - **A minimum counted settlement**, `minCountedCents`. This keeps dust out of the books; it does not stop a
 *    farmer, who uses large orders.
 *  - **A review period.** Until `REVIEW_PERIOD` after an epoch ends, the governor may `voidVolume` an LP's volume
 *    for it, at once, and `setExcluded` stops an LP's new volume counting. A voided share is not divided among the
 *    other LPs - that would let a governor move one LP's rewards to another instantly - it rolls forward, exactly as
 *    if the volume had never been settled.
 *  - **Only what was paid in.** Budgets come from tokens received; claims never exceed them.
 *
 * ## What it does not do
 *
 *  - **It cannot tell a self-trade from a trade.** The registry reports the LP and the amount, not the taker.
 *    Passing the taker would change both escrows' bytecode - FiatEscrow sits 1,088 bytes under EIP-170 - for a check
 *    that a second address defeats. An eligible LP farming within the caps is the residual risk (SR2-36).
 *  - **It does not price the reward token.** `TOKEN_PER_CENT` fixes the conversion at deployment: 1e16 for Movva,
 *    R$ 1,00 a token. Another token is another NodeRewards, and a delayed repoint of the hook and the splitter.
 *  - **It pays nobody who does not claim.** There is no push: an LP whose node never claims is never paid, and its
 *    rewards stay here, booked, for as long as it takes.
 *
 * ## Governance (DelayedGovernance)
 *
 * Delayed, because each lets someone claim value they could not before: binding a registry once this contract has
 * been funded; raising the reward rate or the per-LP cap; lowering the minimum; reinstating an excluded LP.
 *
 * Instant, because each can only reduce what is paid: unbinding the registry; lowering the rate or the cap; raising
 * the minimum; excluding an LP; voiding an LP's volume while its epoch is in review. An LP loses rewards to these as
 * it loses credit to a suspension, and nobody else gains from them.
 *
 * Binding the registry is instant while this contract has never been funded and holds nothing. DeployMovva deploys
 * it before DeployRamp deploys the registry, so the first binding comes after its setup has closed, and until funds
 * arrive there is nothing a wrongly bound registry could take. From the first funds on, a new registry waits out the
 * delay like any other change.
 */
contract NodeRewards is IRewardsHook, DelayedGovernance, ReentrancyGuard {
    using SafeERC20 for IERC20;

    struct Epoch {
        /// Eligible volume counted in the epoch, in centavos, including any voided since.
        uint256 volumeCents;
        /// Volume the governor voided while the epoch was in review.
        uint256 voidedCents;
        /// Reward tokens booked while it was the current epoch.
        uint256 funded;
        /// Set at finalization: what its volume shares, before voiding.
        uint256 budget;
        /// Set at finalization: the most one LP may be paid for it.
        uint256 lpCap;
    }

    uint16 public constant BPS = 10_000;
    /// @notice Rewards never exceed 20 bps of the volume that earns them: the reserve's mint and redeem fees together.
    uint16 public constant MAX_REWARD_BPS_OF_VOLUME = 20;
    uint256 public constant MIN_EPOCH_LENGTH = 1 days;
    uint256 public constant MAX_EPOCH_LENGTH = 28 days;
    uint256 public constant MIN_REVIEW_PERIOD = 1 days;
    uint256 public constant MAX_REVIEW_PERIOD = 14 days;
    /// @notice Most epochs one `finalize` or `claim` handles; call again for more.
    uint256 public constant MAX_EPOCHS_PER_CALL = 52;
    /// @notice Most epochs `claimableIn` scans in one read.
    uint256 public constant MAX_SCAN = 104;

    IERC20 public immutable REWARD_TOKEN;
    /// @notice Reward-token base units worth one BRL centavo: 1e16 for Movva.
    uint256 public immutable TOKEN_PER_CENT;
    /// @notice Epoch 0 starts here: the deployment block's time.
    uint256 public immutable GENESIS;
    uint256 public immutable EPOCH_LENGTH;
    uint256 public immutable REVIEW_PERIOD;

    /// @notice The only caller whose settlement reports count. Zero: nothing counts.
    address public registry;
    /// @notice An epoch's budget is at most this share of its volume, in bps.
    uint16 public rewardBpsOfVolume = 10;
    /// @notice The most one LP is paid for one epoch, in reward-token base units.
    uint256 public maxRewardPerLpPerEpoch;
    /// @notice Settlements below this many centavos are not counted.
    uint256 public minCountedCents = 1_000;
    /// @notice An excluded LP's new settlements are not counted. What it has already earned stays claimable.
    mapping(address => bool) public excluded;

    mapping(uint256 => Epoch) public epochs;
    /// @notice Epoch => LP => eligible volume counted, in centavos (zeroed if voided).
    mapping(uint256 => mapping(address => uint256)) public volumeOf;
    /// @notice Epoch => LP => claimed.
    mapping(uint256 => mapping(address => bool)) public claimed;

    /// @notice Every epoch below this is finalized.
    uint256 public nextToFinalize;
    /// @notice Tokens no epoch has been able to pay: the next finalized epoch's pool starts from here.
    uint256 public carry;
    /// @notice Tokens allocated to finalized epochs and not yet claimed (or rolled forward from a claim).
    uint256 public outstanding;
    /// @notice Every token booked and not yet paid out: carry + outstanding + what unfinalized epochs were funded.
    uint256 public accounted;
    uint256 public totalFunded;
    uint256 public totalClaimed;
    /// @notice When any LP last claimed; zero before the first claim.
    uint64 public lastClaimAt;

    event VolumeCounted(uint256 indexed epoch, address indexed lp, uint256 brlCents);
    event Funded(uint256 indexed epoch, uint256 amount);
    event EpochFinalized(uint256 indexed epoch, uint256 pool, uint256 budget, uint256 allocated, uint256 carryAfter);
    event Claimed(uint256 indexed epoch, address indexed lp, address to, uint256 paid, uint256 rolledForward);
    event VolumeVoided(uint256 indexed epoch, address indexed lp, uint256 brlCents);
    event RegistrySet(address indexed registry);
    event RewardLimitsSet(uint16 rewardBpsOfVolume, uint256 maxRewardPerLpPerEpoch, uint256 minCountedCents);
    event ExcludedSet(address indexed lp, bool excluded);

    error NotRegistry();
    error NotAContract();
    error BadEpochLength();
    error BadReviewPeriod();
    error BadTokenPerCent();
    error RateTooHigh();
    error TooManyEpochs();
    error NotFinalized(uint256 epoch);
    error AlreadyClaimed(uint256 epoch);
    error NothingToClaim(uint256 epoch);
    error ReviewClosed(uint256 epoch);
    error NothingToVoid();

    /**
     * @param tokenPerCent Reward-token base units per BRL centavo: 1e16 for Movva (18 decimals, R$ 1,00 a token).
     * @dev The per-LP cap starts at R$ 10.000,00 of the token, the rate at 10 bps and the minimum at R$ 10,00; the
     *      deploy script sets its own values during setup.
     */
    constructor(
        address token,
        uint256 tokenPerCent,
        uint256 epochLength,
        uint256 reviewPeriod,
        address governor_,
        uint256 governanceDelay
    ) DelayedGovernance(governor_, governanceDelay) {
        if (token == address(0)) revert ZeroAddress();
        if (token.code.length == 0) revert NotAContract();
        if (tokenPerCent == 0) revert BadTokenPerCent();
        if (epochLength < MIN_EPOCH_LENGTH || epochLength > MAX_EPOCH_LENGTH) revert BadEpochLength();
        if (reviewPeriod < MIN_REVIEW_PERIOD || reviewPeriod > MAX_REVIEW_PERIOD) revert BadReviewPeriod();
        REWARD_TOKEN = IERC20(token);
        TOKEN_PER_CENT = tokenPerCent;
        EPOCH_LENGTH = epochLength;
        REVIEW_PERIOD = reviewPeriod;
        GENESIS = block.timestamp;
        maxRewardPerLpPerEpoch = 1_000_000 * tokenPerCent;
    }

    /*//////////////////////////////////////////////////////////////
                                 EPOCHS
    //////////////////////////////////////////////////////////////*/

    function currentEpoch() public view returns (uint256) {
        return (block.timestamp - GENESIS) / EPOCH_LENGTH;
    }

    /// @notice When `epoch` ends, and volume stops counting towards it.
    function epochEnd(uint256 epoch) public view returns (uint256) {
        return GENESIS + (epoch + 1) * EPOCH_LENGTH;
    }

    /// @notice When `epoch`'s review ends: from then on it can be finalized, and its volume can no longer be voided.
    function finalizableAt(uint256 epoch) public view returns (uint256) {
        return epochEnd(epoch) + REVIEW_PERIOD;
    }

    /// @notice How many epochs `finalize` would finalize now, before its per-call bound.
    function finalizableEpochs() public view returns (uint256) {
        if (block.timestamp < GENESIS + EPOCH_LENGTH + REVIEW_PERIOD) return 0;
        // Epochs [0, ready) have ended and passed review.
        uint256 ready = (block.timestamp - GENESIS - REVIEW_PERIOD) / EPOCH_LENGTH;
        return ready > nextToFinalize ? ready - nextToFinalize : 0;
    }

    /*//////////////////////////////////////////////////////////////
                              VOLUME (HOOK)
    //////////////////////////////////////////////////////////////*/

    /**
     * @inheritdoc IRewardsHook
     * @dev Refuses anyone but the bound registry: the registry swallows the revert and emits RewardsHookFailed,
     *      which is how a hook left unbound shows up. Everything else that is not counted returns quietly.
     */
    function onSettled(address lp, uint256 brlCents, uint8 tier) external {
        if (msg.sender != registry) revert NotRegistry();
        _requireSetupComplete();
        if (brlCents < minCountedCents || excluded[lp]) return;
        if (tier != uint8(LPRegistry.Tier.INSTITUTIONAL) && tier != uint8(LPRegistry.Tier.AFFILIATED)) return;
        uint256 e = currentEpoch();
        volumeOf[e][lp] += brlCents;
        epochs[e].volumeCents += brlCents;
        emit VolumeCounted(e, lp, brlCents);
    }

    /*//////////////////////////////////////////////////////////////
                                FUNDING
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Book reward tokens that arrived since the last sync into the current epoch. Anyone may call it;
     *         FeeSplitter calls it after every transfer here.
     * @dev Books the balance above `accounted`, so a token sent by any route counts exactly once.
     */
    function sync() public returns (uint256 received) {
        _requireSetupComplete();
        uint256 balance = REWARD_TOKEN.balanceOf(address(this));
        uint256 booked = accounted;
        if (balance <= booked) return 0;
        received = balance - booked;
        accounted = balance;
        totalFunded += received;
        uint256 e = currentEpoch();
        epochs[e].funded += received;
        emit Funded(e, received);
    }

    /*//////////////////////////////////////////////////////////////
                              FINALIZATION
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Finalize up to `maxEpochs` epochs whose review has ended, oldest first. Anyone may call it.
     * @dev In order, because each epoch's pool starts from what the ones before could not pay. The limits in
     *      force now are the ones the finalized epochs keep: lowering the rate or the cap during review reaches
     *      the epoch in review, and nothing earlier.
     */
    function finalize(uint256 maxEpochs) external returns (uint256 count) {
        _requireSetupComplete();
        if (maxEpochs > MAX_EPOCHS_PER_CALL) maxEpochs = MAX_EPOCHS_PER_CALL;
        uint256 e = nextToFinalize;
        // The bound is the caller's argument, capped: no loop here runs over LPs.
        // slither-disable-next-line timestamp
        while (count < maxEpochs && block.timestamp >= finalizableAt(e)) {
            _finalize(e);
            unchecked {
                ++e;
                ++count;
            }
        }
        nextToFinalize = e;
    }

    function _finalize(uint256 e) private {
        Epoch storage ep = epochs[e];
        uint256 pool = carry + ep.funded;
        uint256 budget = 0;
        uint256 allocated = 0;
        uint256 volume = ep.volumeCents;
        if (volume != 0) {
            uint256 byVolume = Math.mulDiv(volume * TOKEN_PER_CENT, rewardBpsOfVolume, BPS);
            budget = pool < byVolume ? pool : byVolume;
            // The voided share rolls forward, rounded down, so what stays allocated always covers every claim.
            allocated = budget - Math.mulDiv(budget, ep.voidedCents, volume);
        }
        ep.budget = budget;
        ep.lpCap = maxRewardPerLpPerEpoch;
        carry = pool - allocated;
        outstanding += allocated;
        emit EpochFinalized(e, pool, budget, allocated, pool - allocated);
    }

    /*//////////////////////////////////////////////////////////////
                                 CLAIMS
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Claim the caller's rewards for finalized epochs, paid to `to`.
     * @dev Each epoch pays `budget x volume / epoch volume`, rounded down, up to the epoch's per-LP cap; the part
     *      above the cap rolls forward. An epoch in which the caller has no volume, one not finalized, or one
     *      already claimed reverts the whole claim, so a node's mistake costs a simulation rather than a silent no-op.
     */
    function claim(uint256[] calldata epochIds, address to) external nonReentrant returns (uint256 paid) {
        _requireSetupComplete();
        if (to == address(0)) revert ZeroAddress();
        if (epochIds.length > MAX_EPOCHS_PER_CALL) revert TooManyEpochs();
        uint256 rolled = 0;
        for (uint256 i; i < epochIds.length; ++i) {
            uint256 e = epochIds[i];
            if (e >= nextToFinalize) revert NotFinalized(e);
            if (claimed[e][msg.sender]) revert AlreadyClaimed(e);
            uint256 v = volumeOf[e][msg.sender];
            if (v == 0) revert NothingToClaim(e);
            claimed[e][msg.sender] = true;
            (uint256 share, uint256 pay) = _owed(e, v);
            outstanding -= share;
            rolled += share - pay;
            paid += pay;
            emit Claimed(e, msg.sender, to, pay, share - pay);
        }
        carry += rolled;
        accounted -= paid;
        totalClaimed += paid;
        lastClaimAt = uint64(block.timestamp);
        if (paid != 0) REWARD_TOKEN.safeTransfer(to, paid);
    }

    /// @notice What `claim` would pay `lp` for these epochs now; zero for any it could not claim.
    function claimable(address lp, uint256[] calldata epochIds) external view returns (uint256 total) {
        for (uint256 i; i < epochIds.length; ++i) {
            uint256 e = epochIds[i];
            if (e >= nextToFinalize || claimed[e][lp]) continue;
            uint256 v = volumeOf[e][lp];
            if (v == 0) continue;
            (, uint256 pay) = _owed(e, v);
            total += pay;
        }
    }

    /**
     * @notice The finalized, unclaimed epochs from `fromEpoch` (at most `count`, at most MAX_SCAN) in which `lp` has
     *         a share to claim, and what claiming them all would pay.
     * @dev For an LP's node: a view over epochs the caller bounds, never over LPs.
     */
    function claimableIn(address lp, uint256 fromEpoch, uint256 count)
        external
        view
        returns (uint256 total, uint256[] memory epochIds)
    {
        uint256 end = fromEpoch + (count > MAX_SCAN ? MAX_SCAN : count);
        if (end > nextToFinalize) end = nextToFinalize;
        uint256[] memory found = new uint256[](end > fromEpoch ? end - fromEpoch : 0);
        uint256 n = 0;
        for (uint256 e = fromEpoch; e < end; ++e) {
            if (claimed[e][lp]) continue;
            uint256 v = volumeOf[e][lp];
            if (v == 0) continue;
            (uint256 share, uint256 pay) = _owed(e, v);
            // Nothing allocated to it (an epoch with an empty pool): claiming would only spend gas.
            if (share == 0) continue;
            total += pay;
            found[n++] = e;
        }
        epochIds = new uint256[](n);
        for (uint256 i; i < n; ++i) {
            epochIds[i] = found[i];
        }
    }

    /// @dev An LP's pro-rata share of a finalized epoch's budget, and what of it is paid under the epoch's cap.
    function _owed(uint256 e, uint256 v) private view returns (uint256 share, uint256 pay) {
        Epoch storage ep = epochs[e];
        share = Math.mulDiv(ep.budget, v, ep.volumeCents);
        pay = share < ep.lpCap ? share : ep.lpCap;
    }

    /*//////////////////////////////////////////////////////////////
                               GOVERNANCE
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Bind the registry whose settlement reports count; zero unbinds.
     * @dev Delayed for any new registry once this contract has been funded or holds tokens: the registry decides
     *      whose volume shares the pool. Instant before then (see "Governance" in the header), and unbinding is
     *      always instant - it stops volume counting and pays nobody.
     */
    function setRegistry(address r) external {
        _authorizeChange(r != address(0) && r != registry && !_holdsNothing());
        if (r != address(0) && r.code.length == 0) revert NotAContract();
        registry = r;
        emit RegistrySet(r);
    }

    /**
     * @notice Raising the rate or the per-LP cap, or lowering the minimum, is delayed; the opposite of each is
     *         instant. The rate can never pass MAX_REWARD_BPS_OF_VOLUME.
     */
    function setRewardLimits(uint16 bpsOfVolume, uint256 lpCap, uint256 minCents) external {
        _authorizeChange(
            bpsOfVolume > rewardBpsOfVolume || lpCap > maxRewardPerLpPerEpoch || minCents < minCountedCents
        );
        if (bpsOfVolume > MAX_REWARD_BPS_OF_VOLUME) revert RateTooHigh();
        (rewardBpsOfVolume, maxRewardPerLpPerEpoch, minCountedCents) = (bpsOfVolume, lpCap, minCents);
        emit RewardLimitsSet(bpsOfVolume, lpCap, minCents);
    }

    /// @notice Excluding an LP is instant; reinstating one waits out the delay.
    function setExcluded(address lp, bool isExcluded) external {
        _authorizeChange(!isExcluded && excluded[lp]);
        if (lp == address(0)) revert ZeroAddress();
        excluded[lp] = isExcluded;
        emit ExcludedSet(lp, isExcluded);
    }

    /**
     * @notice Instant, governor only: void `lp`'s volume for an epoch still in review, current or ended.
     * @dev The voided share rolls forward at finalization rather than raising anyone else's (see the header). Once
     *      the review has ended the epoch's shares are fixed, finalized or not: an LP can finalize the moment it may.
     */
    function voidVolume(uint256 epoch, address lp) external {
        _authorizeChange(false);
        // slither-disable-next-line timestamp
        if (epoch > currentEpoch() || block.timestamp >= finalizableAt(epoch)) revert ReviewClosed(epoch);
        uint256 v = volumeOf[epoch][lp];
        if (v == 0) revert NothingToVoid();
        volumeOf[epoch][lp] = 0;
        epochs[epoch].voidedCents += v;
        emit VolumeVoided(epoch, lp, v);
    }

    function _isDelayable(bytes4 selector) internal pure override returns (bool) {
        return selector == NodeRewards.setRegistry.selector || selector == NodeRewards.setRewardLimits.selector
            || selector == NodeRewards.setExcluded.selector;
    }

    /// @dev Never funded, and holding no tokens: nothing a registry could direct.
    function _holdsNothing() private view returns (bool) {
        // Strict on purpose: one base unit held is something to protect. A donation that forces the delay costs its
        // sender the tokens and the governor 48 hours, nothing more.
        // slither-disable-next-line incorrect-equality
        return totalFunded == 0 && REWARD_TOKEN.balanceOf(address(this)) == 0;
    }
}
