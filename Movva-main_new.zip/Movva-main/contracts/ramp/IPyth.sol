// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @dev The surface of Pyth's on-chain contract this repo uses. Vendored rather than imported so the
///      repo keeps one dependency graph; the struct layout and the selectors are Pyth's and must not
///      drift (PythFork.t.sol reads the deployed contract through it).
interface IPyth {
    struct Price {
        int64 price;
        uint64 conf; // confidence interval, same exponent as `price`
        int32 expo;
        uint256 publishTime;
    }

    /// @dev Reverts if no price within `age` seconds. That is the behaviour we want.
    function getPriceNoOlderThan(bytes32 id, uint256 age) external view returns (Price memory);

    /// @dev The latest price however old; reverts only for a feed never posted on this chain.
    function getPriceUnsafe(bytes32 id) external view returns (Price memory);

    /// @dev What `updatePriceFeeds` charges for these updates, in wei.
    function getUpdateFee(bytes[] calldata updateData) external view returns (uint256 feeAmount);

    /// @dev Verify and store signed price updates fetched from Hermes. Anyone may call it: the
    ///      signatures are the authority, the sender only pays the fee and the gas.
    function updatePriceFeeds(bytes[] calldata updateData) external payable;
}
