// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IPriceOracle} from "./IPriceOracle.sol";
import {IAggregatorV3} from "./ChainlinkBrlOracle.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";

/**
 * @title ChainlinkSignedFxOracle
 * @notice BRL centavos per whole token of an asset: a Chainlink ASSET/USD feed crossed with a
 *         BRL-per-USD rate - Pyth's, through PythFxOracle and ScaledFxBandOracle (Mova's choice since
 *         14 September 2026), or a signed quorum's. The name predates Pyth.
 *
 *      centavos per token  =  (USD per token, from Chainlink)  x  (centavos per USD, signed)
 *
 * ## Why this shape, on Ethereum L1
 *
 * There is no contract-readable, maintained BRL/USD feed on L1 (OracleFork.t.sol, PythFork.t.sol),
 * which is why SignedPriceOracle exists. Used directly, it makes publishers sign a crypto price
 * per asset: one number for ETH, another for USDT, each moving on crypto time, each a separate
 * way to be wrong. But only one leg of those prices is actually missing on L1 - BRL. The
 * USD leg of ETH and of USDT is published by Chainlink, readable by contracts, and maintained.
 *
 * So publishers sign ONE number - the FX rate, centavos per US dollar - into a SignedPriceOracle
 * instance that prices nothing else, and every asset crosses its own Chainlink feed with it.
 * What this buys:
 *
 *  - a USDT depeg reaches the band through Chainlink, without anyone having to notice it and
 *    sign a different stablecoin price;
 *  - listing another USD-quoted asset needs a feed address, not a new publisher process;
 *  - the publishers' trust is narrowed to the one quantity nobody on L1 can read.
 *
 * It is still a band, never the price (IPriceOracle): a wrong leg can censor or admit absurd
 * offers, not move value.
 *
 * ## Each leg keeps its own clock - and why `updatedAt` is the FX leg's
 *
 * A cross is only as fresh as its stalest leg, so each leg is checked against its OWN max age
 * and a stale one reverts the whole price. What is reported as `updatedAt` is the FX leg's
 * publish time, and that is deliberate rather than generous.
 *
 * Chainlink feeds do not update on a clock the escrows share. They update when the answer
 * deviates past a threshold, or when a heartbeat lapses. The mainnet USDT/USD feed's heartbeat
 * is a day: the fourteen update intervals before block 25,971,545 were each between 86,400 and
 * 86,448 seconds (UsdtRampFork.t.sol re-reads the latest ones). An unchanged answer that is
 * twenty hours old is not stale in Chainlink's own terms - it means the peg has not moved by
 * the deviation threshold since.
 * The escrows, though, refuse any price whose `updatedAt` is older than MAX_PRICE_AGE, one
 * hour. Reporting the older of the two legs, as ChainlinkBrlOracle does for its two feeds,
 * would have made USDT untradeable for about twenty-three hours of every day.
 *
 * So the Chainlink leg is judged here, against the age that fits that feed's heartbeat
 * (`assetMaxAge`), and the escrow's own one-hour backstop applies to the leg that has no
 * heartbeat of its own: the rate a quorum of people signs. A publisher going quiet still stops
 * trading within the hour; a Chainlink feed missing its heartbeat stops it at `assetMaxAge`.
 *
 * ## Units
 *
 * The FX leg is an oracle whose `brlCentsPerUnit` means centavos per ONE US DOLLAR - about 540 at
 * R$5.40: ScaledFxBandOracle over PythFxOracle, which serves the last close while the FX market is
 * closed so this band keeps working, or a SignedPriceOracle signed in centavos. Its tick is a centavo, about 0.19% of the rate, far inside any sanity
 * band; the result is rounded to the nearest centavo per token. A publisher that signs the
 * wrong unit (an ETH price, or the rate scaled by 1e8) produces a mid off by orders of
 * magnitude, and every offer then falls outside the band: it fails closed.
 *
 * ## Governance (DelayedGovernance)
 *
 * Repointing either leg, or lengthening either max age, waits out GOVERNANCE_DELAY; tightening
 * a max age with both legs unchanged is instant. This used to be instant throughout, on the
 * grounds that a band cannot move value and a delay would slow replacing a dead feed. But
 * pointing an escrow's asset at a different ORACLE is delayed (SR2-14), and `setLegs` reaches
 * the same result one contract further in: repoint `usdBrl` at a contract the governor
 * controls and the band is whatever it says, with no notice. The same held for the signed FX
 * leg's own publishers, and delaying one without the other would close nothing. A dead feed
 * already fails closed (the leg reverts); replacing it lets a new source price trades, which
 * is the kind of change that waits. Schedule it when the feed's deprecation is announced.
 *
 * Until `completeSetup()` the cross refuses to price (`SetupIncomplete`), for the reason
 * SignedPriceOracle gives: nothing may rely on an oracle whose governor still acts instantly.
 */
contract ChainlinkSignedFxOracle is IPriceOracle, DelayedGovernance {
    /// @notice Chainlink ASSET/USD: US dollars per whole token, `decimals()` decimals.
    IAggregatorV3 public assetUsd;
    /// @notice SignedPriceOracle whose publishers sign BRL centavos per ONE US DOLLAR.
    IPriceOracle public usdBrl;
    /// @notice Oldest Chainlink answer accepted. Set from the feed's heartbeat, plus a grace.
    uint64 public assetMaxAge;
    /// @notice Oldest signed FX rate accepted.
    uint64 public fxMaxAge;

    /// @notice A leg's timestamp may be this far ahead of the chain, as SignedPriceOracle
    ///         allows, and no further: freshness from the future outlives the signing.
    uint64 public constant MAX_FUTURE_SKEW = 5 minutes;

    event LegsSet(address assetUsd, address usdBrl, uint64 assetMaxAge, uint64 fxMaxAge);
    // `governor`, `transferGovernor`, `GovernorTransferred`, `NotGovernor()` and `ZeroAddress()`
    // are DelayedGovernance's now, with the signatures this contract declared itself.

    error BadMaxAge();
    error BadPrice(address leg, int256 answer);
    error StaleLeg(address leg, uint256 updatedAt);
    error LegFromFuture(address leg, uint256 updatedAt);
    error FeedDecimalsOutOfRange(address feed, uint8 decimals);
    error PriceRoundsToZero();

    constructor(
        address assetUsd_,
        address usdBrl_,
        uint64 assetMaxAge_,
        uint64 fxMaxAge_,
        address governor_,
        uint256 governanceDelay
    ) DelayedGovernance(governor_, governanceDelay) {
        _setLegs(assetUsd_, usdBrl_, assetMaxAge_, fxMaxAge_);
    }

    /// @notice Repointing either leg or lengthening either max age waits out the governance
    ///         delay; tightening an age, legs unchanged, is instant. See Governance above.
    function setLegs(address assetUsd_, address usdBrl_, uint64 assetMaxAge_, uint64 fxMaxAge_) external {
        _authorizeChange(
            assetUsd_ != address(assetUsd) || usdBrl_ != address(usdBrl) || assetMaxAge_ > assetMaxAge
                || fxMaxAge_ > fxMaxAge
        );
        _setLegs(assetUsd_, usdBrl_, assetMaxAge_, fxMaxAge_);
    }

    /// @inheritdoc IPriceOracle
    /// @dev `updatedAt` is the FX leg's publish time; the Chainlink leg has been checked against
    ///      `assetMaxAge` before this returns. See the header for why they are not the same.
    function brlCentsPerUnit() external view returns (uint256 price, uint64 updatedAt) {
        _requireSetupComplete();
        (uint256 usd, uint8 dec) = _assetLeg();
        (uint256 fx, uint64 fxAt) = _fxLeg();
        updatedAt = fxAt;
        // Nearest rather than floor: this is a band's midpoint, and flooring would bias every
        // mid down by up to a centavo per token - about 0.19% on USDT.
        uint256 scale = 10 ** dec;
        price = (usd * fx + scale / 2) / scale;
        if (price == 0) revert PriceRoundsToZero();
    }

    function _assetLeg() private view returns (uint256 usd, uint8 dec) {
        IAggregatorV3 feed = assetUsd;
        // roundId, startedAt and answeredInRound are unused for the reason ChainlinkBrlOracle
        // gives: freshness is judged by updatedAt alone.
        // slither-disable-next-line unused-return
        (, int256 answer,, uint256 at,) = feed.latestRoundData();
        if (answer <= 0) revert BadPrice(address(feed), answer);
        if (at == 0 || block.timestamp > at + assetMaxAge) revert StaleLeg(address(feed), at);
        dec = feed.decimals();
        // Before it reaches 10 ** dec: a corrupt feed must not be able to ask for a power that
        // overflows or burns the caller's gas.
        if (dec > 18) revert FeedDecimalsOutOfRange(address(feed), dec);
        usd = uint256(answer);
    }

    function _fxLeg() private view returns (uint256 fx, uint64 at) {
        IPriceOracle leg = usdBrl;
        // SignedPriceOracle reverts NoPriceYet before any price, and SetupIncomplete before its
        // setup closes; both reach the caller.
        (fx, at) = leg.brlCentsPerUnit();
        if (fx == 0) revert BadPrice(address(leg), 0);
        if (uint256(at) > block.timestamp + MAX_FUTURE_SKEW) revert LegFromFuture(address(leg), at);
        if (block.timestamp > uint256(at) + fxMaxAge) revert StaleLeg(address(leg), at);
    }

    function _isDelayable(bytes4 selector) internal pure override returns (bool) {
        return selector == ChainlinkSignedFxOracle.setLegs.selector;
    }

    function _setLegs(address assetUsd_, address usdBrl_, uint64 assetMaxAge_, uint64 fxMaxAge_) private {
        if (assetUsd_ == address(0) || usdBrl_ == address(0)) revert ZeroAddress();
        // Zero would refuse every price; that is a mistake to report, not a setting to store.
        if (assetMaxAge_ == 0 || fxMaxAge_ == 0) revert BadMaxAge();
        assetUsd = IAggregatorV3(assetUsd_);
        usdBrl = IPriceOracle(usdBrl_);
        assetMaxAge = assetMaxAge_;
        fxMaxAge = fxMaxAge_;
        emit LegsSet(assetUsd_, usdBrl_, assetMaxAge_, fxMaxAge_);
    }
}
