// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/**
 * @title IAttestorVerifier
 * @notice The boundary between the escrow and a proof that a fiat payment really happened
 *         (task 2.2). The escrow never parses a bank response itself; it asks this.
 *
 * ## Why this is an interface and not an implementation detail
 *
 * The escrow's correctness rests on one question - "did payer P send N centavos to PIX key
 * K, and has this exact bank transaction never been used before?" - and that question has
 * several plausible answers: a zkTLS proof (TLSNotary / Reclaim / zkPass), a licensed
 * PSP webhook signature, or an Open Finance (Open Banking Brasil) consent read. Only the
 * first proves the bank session itself; the others are named parties' word. So the escrows
 * settle a bank payment - PIX, boleto or TED - only through a verifier that proves the session
 * (`provesBankSession`) (Mova's decision, 14 September 2026). Cards, the one rail that had no
 * bank session to prove, were removed on 24 September 2026: see docs/card-rail-removal.md.
 *
 * Pinning one of those into the escrow would mean redeploying the contract that holds
 * everyone's liquidity in order to change how a receipt is checked. So the escrow holds a
 * *set* of verifiers, and each offer names which one it will accept. An LP who does not
 * trust a given attestor simply does not select it. That choice only means something if the
 * attestor cannot change underneath the LP: a verifier's signer set is governed, so adding a
 * signer or lowering a threshold waits out GOVERNANCE_DELAY (see DelayedGovernance), and an
 * LP who rejects the change can close first.
 *
 * ## What a verifier MUST guarantee
 *
 * The escrow enforces replay protection itself, keyed on `bankTxId`, so a verifier does not
 * need to. What a verifier alone can guarantee, and what the escrow therefore relies on:
 *
 *  1. `bankTxId` is the bank's own identifier for the settled transaction (for PIX, the
 *     end-to-end id `E...`; for a boleto, the payment's authentication code), unique per
 *     payment and not chosen by the payer. If a payer can influence it, replay protection
 *     collapses into a nonce the attacker controls.
 *  2. `payeeKeyHash` is the destination the money actually reached, not the one requested:
 *     the salted commitment to the PIX key credited or, for a boleto, to the barcode of the
 *     document actually paid, recomputed from what the bank shows. Paying the wrong key or
 *     the wrong boleto must not verify.
 *  3. `amountBrlCents` is the amount *settled*, net of any fee the payer could have chosen,
 *     and is not roundable in the payer's favour.
 *  4. `paidAt` is the bank's settlement time, so the escrow can reject a receipt that
 *     predates the order it is being used to settle.
 *  5. The proof is bound to `orderId`. Without this a receipt for a genuine payment can be
 *     lifted from one order and spent on another - see the escrow's note on binding.
 *
 * A verifier that cannot guarantee (1) or (5) is not safe to register, however good its
 * cryptography is.
 */
interface IAttestorVerifier {
    /**
     * @notice Which Brazilian payment rail settled.
     *
     * The rail is part of what is attested, not metadata, because the rails do not settle
     * alike and a contract that treats them alike will be wrong about finality. PIX is
     * near-instant and irrevocable except by dispute (MED). A BOLETO is a payment slip:
     * the payer settles at a bank or app and the funds reach the payee on a banking-day
     * cycle, so "paid" and "settled" can be a day apart. TED is same-day interbank within
     * banking hours.
     *
     * Both legs of the ramp carry a rail, but they carry it for different reasons. On the
     * on-ramp the taker chooses how to pay, so an LP that cannot reconcile boletos declines
     * them. On the off-ramp the LP chooses how to pay the seller, and a seller who needs
     * the money today should not be handed a boleto - which is why a sale names the rails
     * it will accept rather than letting the payer pick.
     *
     * A BOLETO also names a different kind of payee. A PIX key belongs to someone for good; a
     * boleto is a document registered for one amount. So on the on-ramp a boleto order has
     * its own step - the LP issues a boleto for that order and commits to it - and on the
     * off-ramp a sale whose payee is a bill names BOLETO and no other rail. An LP that cannot
     * issue or reconcile boletos leaves BOLETO out of its offer's mask.
     */
    enum Rail {
        UNSPECIFIED,
        PIX,
        BOLETO,
        TED
    }

    /// @notice A settled fiat payment, as attested.
    struct Payment {
        bytes32 bankTxId; // bank's unique id (PIX end-to-end id, boleto authentication), hashed
        bytes32 payeeKeyHash; // salted commitment to the PIX key credited, or the boleto paid
        bytes32 payerRef; // opaque, stable per payer; for dispute + sanctions review
        uint256 amountBrlCents; // settled amount in centavos
        uint64 paidAt; // bank settlement timestamp
        Rail rail; // which rail actually settled it
    }

    /**
     * @notice Verify an attestation and return what it proves.
     * @dev MUST revert on an invalid proof rather than returning a zeroed struct - a
     *      caller that forgets to check a boolean should fail closed.
     * @param orderId The escrow order this proof is presented against. Implementations MUST
     *        check the proof is bound to it.
     * @param proof   Opaque, verifier-specific.
     */
    function verifyPayment(bytes32 orderId, bytes calldata proof)
        external
        view
        returns (Payment memory);

    /// @notice Human-readable identifier, e.g. "zktls/reclaim/pix-v1". For operators.
    function attestorKind() external view returns (string memory);

    /**
     * @notice Whether this verifier proves the bank session itself - a zkTLS proof of a session
     *         with the bank - rather than taking named parties' word that a payment happened.
     * @dev The escrows open a PIX, boleto or TED offer or sale only on a verifier that returns
     *      true (FiatEscrow.postOffer, OffRampEscrow.openSale), so a colluding quorum can never
     *      settle a bank payment that did not happen. MUST be constant: it is read when an offer
     *      or sale opens, not again at settlement.
     */
    function provesBankSession() external view returns (bool);
}
