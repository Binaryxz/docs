// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IBandPriceOracle} from "./IBandPriceOracle.sol";
import {IAggregatorV3} from "./ChainlinkBrlOracle.sol";
import {FxMarketHours} from "../common/FxMarketHours.sol";

/// @dev The one view IAggregatorV3 leaves out, read once at construction to check what the feed is.
interface IAggregatorDescription {
    function description() external view returns (string memory);
}

/**
 * @title ChainlinkFxOracle
 * @notice Reais per US dollar at 1e-6 - the unit MovvaReserve prices in (R$ 5,0625 is 5_062_500) - from a
 *         Chainlink BRL/USD aggregator, which quotes the other way round: US dollars per ONE real, 8
 *         decimals (0.1975293 is 19_752_930). An alternative to PythFxOracle for the reserve's FX leg, read
 *         the same two ways and refusing the same hours.
 *
 * ## The feed (verified 19 October 2026)
 *
 * Ethereum mainnet BRL/USD is the proxy 0x3126E7F38D5f60f4E2B6ec3511C7bdbD79317Df1 (Chainlink's feed list,
 * reference-data-directory.vercel.app/feeds-mainnet.json): description "BRL / USD", 8 decimals, heartbeat
 * 86,400 s, deviation threshold 0.5%, aggregator 0x3A9763662BFCa861340d1D40bA5e5A2a29Bc5f3e. A contract can
 * read it (ChainlinkFxFork.t.sol). It is not the address the repository tested in September:
 * 0x0eBDc65E7e9132Cb41ac5cbD0101B799D7aDb475, still what Chainlink's Feed Registry returns for BRL/USD, is a
 * retired proxy - last updated 25 August 2023 and answering a contract `No access`. Sepolia has no BRL/USD
 * feed at all, so this leg is for mainnet; Sepolia keeps Pyth.
 *
 * ## Units and rounding
 *
 *     brlPerUsdE6 = floor(10^(6 + decimals) / answer)
 *
 * The reciprocal, floored - the direction PythFxOracle truncates in, so the two legs round alike and
 * swapping one for the other changes nothing about rounding. The error is under one millionth of a real
 * per dollar: 0.2 parts per million of R$ 5,06, or 0.002 bps, against fees of 10 bps. Its direction: a rate
 * that low by a millionth mints a minter fewer Movva and pays a redeemer more USDT, each by at most
 * 0.2 ppm, which no tick choice can turn into a profit. The feed itself resolves 1e-8 dollars per real.
 *
 * ## Two readings, as PythFxOracle - and why the RATE checks the clock
 *
 * Mova's decision (14 September 2026): minting and redeeming wait for the FX market; trading on the
 * ramps does not.
 *
 *  - `brlCentsPerUnit` is the RATE, which MovvaReserve mints and redeems at. It refuses outside
 *    FxMarketHours' core session (13:30-21:00 UTC, weekdays, not 25 December or 1 January), and inside
 *    it refuses an answer older than MAX_AGE. `updatedAt` is the round's own time, so the reserve's
 *    `fxMaxAge` judges it too, and must cover the heartbeat: set it to MAX_AGE.
 *  - `brlCentsPerUnitForBand` is a BAND's reading. Inside the core session it is the rate's answer no
 *    older than MAX_AGE; outside it, the last answer no older than CLOSED_MAX_AGE. Either way it is
 *    stamped with the current block's time.
 *
 * PythFxOracle needs no clock for its rate, because Pyth stops publishing when the market closes: the
 * price's own age refuses it every night. Chainlink does not stop. Its heartbeat posts a round every
 * 24 hours whatever the market does - on Saturday 17 and Sunday 18 October 2026 at 19:13 UTC, the
 * Saturday round carrying a move made after Friday's 19:13 round, presumably to the close (0.19708316 to
 * 0.19752930, +0.23%, under the deviation threshold, so only the heartbeat posted it). Age alone never
 * tells this leg the market is closed. With
 * no gate, MAX_AGE (26 hours) would have the reserve mint and redeem all weekend at Friday's close, and
 * at the reopening anyone who saw the weekend's news would trade the gap against the reserve - the risk
 * the 14 September decision closes. So the rate asks FxMarketHours, as PythFxOracle's band does.
 *
 * The core session errs one way: about 90 minutes a day the market is open and the rate refuses anyway
 * (12:00-13:30 UTC in New York summer, 13:00-13:30 and 21:00-22:00 UTC in winter) - hours a mint waits,
 * never hours it prices a closed market. FxMarketHours encodes Pyth's schedule; Chainlink lists this
 * feed's hours as `Forex_BRL`. The core session sits inside the weekday hours of either. What neither
 * knows is an unscheduled closure - Carnival, a Brazilian or US holiday - when the feed may sit on its
 * heartbeat with the reserve open; the same residual PythFxOracle has.
 *
 * The band is stamped current INSIDE the session too, where PythFxOracle passes its publish time through,
 * for the reason ChainlinkSignedFxOracle gives for its USDT/USD leg: the escrows refuse any band older
 * than MAX_PRICE_AGE, one hour, and a deviation-triggered feed's answer is routinely many hours old while
 * still current - it is posted again only once the market moves 0.5%. Passing the round's time through
 * would stop every band for most of every day. The feed's own clock is judged here, against MAX_AGE.
 *
 * ## The deviation threshold: what the rate can lag by
 *
 * Inside the session the answer is the market to within the 0.5% deviation threshold, plus the time a
 * deviation round takes to land. A gateway that sees the market can mint when the on-chain rate is up to
 * ~50 bps richer than the market, or redeem when it is up to ~50 bps poorer, for a gain of up to
 * 50 - 10 = ~40 bps of the trade after the reserve's 10 bps fee, paid by the reserve. It is bounded per
 * trade by the threshold and in size by the supply cap; only contracted gateways mint and redeem. Closing
 * it is the client's choice, not this contract's: mint and redeem fees each at least the threshold
 * (50 bps, under the 100 bps caps), or a second, independent source in the DivergenceBreaker with a band
 * near the threshold. The breaker's default band (300 bps) does not catch a 50 bps lag, and its
 * ChainlinkCrossSource over this same feed is not independent of this leg (DeployMovva refuses the pair).
 * docs/movva.md, "The rate", has the comparison.
 *
 * ## Checks on every read
 *
 * An answer above zero; a completed round (updatedAt != 0); updatedAt no more than MAX_FUTURE_SKEW ahead
 * of the chain; the feed's decimals still the ones it had at deployment (an aggregator upgrade behind the
 * proxy may change them, and this refuses rather than mis-scale); and the result inside
 * [MIN_BRL_PER_USD_E6, MAX_BRL_PER_USD_E6]. An inverted feed (reais per dollar, ~5e8) reads as 0.2 and is
 * refused; so is a feed in the wrong unit.
 *
 * ## No governor, and why
 *
 * Every setting is an immutable chosen at deployment, inside bounds this constructor enforces; there is
 * no owner, no setter and no role. PythFxOracle is governed because its source is a price id on a pull
 * oracle that Mova itself keeps warm and whose confidence limit may want tuning. A Chainlink proxy is
 * already the indirection: when Chainlink upgrades the aggregator (a new OCR contract) it repoints the
 * proxy (`aggregator()`), and the address read here stays the same. What can still change is Chainlink
 * retiring the proxy, as it retired 0x0eBDc...b475; this leg then reverts - fails closed - and the remedy
 * is a new ChainlinkFxOracle (or PythFxOracle) behind the reserve's own `setOracle`, which already waits
 * out the reserve's governance delay. A governor here would be a second lever on the same number, with
 * its own delay, setup and hand-over to check, and nothing it could do that `setOracle` cannot. After
 * the reserve is finalized neither lever exists; a retired proxy then stops minting and redeeming for
 * good, exactly as a PythFxOracle whose governor finalize renounced would on a retired price id.
 *
 * The cost of immutable bounds is the same permanence, which is why the deployment's range is the
 * reserve's own (R$ 1 to R$ 100): this bound catches a unit or inversion mistake, and must not be a view
 * about where the real may go.
 */
contract ChainlinkFxOracle is IBandPriceOracle {
    /// @notice The Chainlink BRL/USD proxy: US dollars per ONE real, DECIMALS decimals.
    IAggregatorV3 public immutable FEED;
    /// @notice The feed's decimals at deployment; a read that finds others refuses.
    uint8 public immutable DECIMALS;
    /// @notice The oldest answer that is still the rate inside the core session, and a band's limit there.
    uint64 public immutable MAX_AGE;
    /// @notice The oldest answer a band takes outside the core session.
    uint64 public immutable CLOSED_MAX_AGE;
    /// @notice The sanity range of the result, reais per US dollar at 1e-6.
    uint256 public immutable MIN_BRL_PER_USD_E6;
    uint256 public immutable MAX_BRL_PER_USD_E6;
    /// @dev 10^(6 + DECIMALS): the numerator of the reciprocal.
    uint256 private immutable SCALE;

    /// @notice What `description()` must say at deployment.
    string public constant DESCRIPTION = "BRL / USD";
    /// @notice MAX_AGE bounds. The heartbeat is 86,400 s and its rounds land up to a minute late (86,424 and
    ///         86,436 s apart on 16-18 October 2026), so below 25 hours a quiet market would read stale every
    ///         day - a freeze of every redemption. Above two days a missed heartbeat goes unnoticed.
    uint64 public constant MIN_MAX_AGE = 25 hours;
    uint64 public constant MAX_MAX_AGE = 2 days;
    /// @notice As PythFxOracle: the longest closure on the schedule, a holiday beside a weekend, is 88 hours.
    uint64 public constant MAX_CLOSED_MAX_AGE = 4 days;
    /// @notice The widest sanity range accepted: MovvaReserve's own, R$ 1 to R$ 100 per dollar.
    uint256 public constant FLOOR_BRL_PER_USD_E6 = 1e6;
    uint256 public constant CEILING_BRL_PER_USD_E6 = 100e6;
    /// @notice As SignedPriceOracle, PythFxOracle and the reserve allow: freshness from the future outlives the round.
    uint64 public constant MAX_FUTURE_SKEW = 5 minutes;

    error ZeroAddress();
    error NotBrlUsd(string description);
    error BadDecimals(uint8 decimals);
    error BadLimits();
    error BadAnswer(int256 answer);
    error IncompleteRound();
    error AnswerFromFuture(uint256 updatedAt);
    error StaleAnswer(uint256 updatedAt);
    error DecimalsChanged(uint8 decimals);
    error RateOutOfRange(uint256 brlPerUsdE6);
    error MarketClosed(uint256 timestamp);

    constructor(address feed, uint64 maxAge, uint64 closedMaxAge, uint256 minBrlPerUsdE6, uint256 maxBrlPerUsdE6) {
        if (feed == address(0)) revert ZeroAddress();
        // The same age refuses a quiet market every day below the floor, and misses a dead feed above the
        // ceiling. Outside the session a band takes at least what it takes inside it.
        if (
            maxAge < MIN_MAX_AGE || maxAge > MAX_MAX_AGE || closedMaxAge < maxAge || closedMaxAge > MAX_CLOSED_MAX_AGE
                || minBrlPerUsdE6 < FLOOR_BRL_PER_USD_E6 || maxBrlPerUsdE6 > CEILING_BRL_PER_USD_E6
                || minBrlPerUsdE6 >= maxBrlPerUsdE6
        ) revert BadLimits();
        // Pointed at USDT/USD, ETH/USD or an inverted pair, every read would refuse on the range - or, for a
        // feed near R$ 1-100 by chance, price. Asking the feed what it is costs nothing at deployment.
        string memory d = IAggregatorDescription(feed).description();
        if (keccak256(bytes(d)) != keccak256(bytes(DESCRIPTION))) revert NotBrlUsd(d);
        uint8 dec = IAggregatorV3(feed).decimals();
        // 18 bounds 10^(6 + dec) far inside uint256; zero decimals would leave no precision to invert.
        if (dec == 0 || dec > 18) revert BadDecimals(dec);
        FEED = IAggregatorV3(feed);
        DECIMALS = dec;
        SCALE = 10 ** (6 + uint256(dec));
        MAX_AGE = maxAge;
        CLOSED_MAX_AGE = closedMaxAge;
        MIN_BRL_PER_USD_E6 = minBrlPerUsdE6;
        MAX_BRL_PER_USD_E6 = maxBrlPerUsdE6;
    }

    /// @notice The rate: reais per US dollar at 1e-6. Refused outside the core session, and inside it
    ///         once the answer is older than MAX_AGE.
    /// @dev `updatedAt` is the round's own time: the reserve's `fxMaxAge` must be at least MAX_AGE.
    function brlCentsPerUnit() external view returns (uint256 price, uint64 updatedAt) {
        // The clock first: while the market is closed there is no rate, however fresh the heartbeat.
        if (!FxMarketHours.inCoreSession(block.timestamp)) revert MarketClosed(block.timestamp);
        uint256 at;
        (price, at) = _read();
        if (block.timestamp > at + MAX_AGE) revert StaleAnswer(at);
        updatedAt = uint64(at);
    }

    /// @inheritdoc IBandPriceOracle
    /// @dev Stamped with the current block at every hour; see "Two readings" for why inside the session too.
    function brlCentsPerUnitForBand() external view returns (uint256 price, uint64 updatedAt) {
        uint256 at;
        (price, at) = _read();
        uint256 limit = FxMarketHours.inCoreSession(block.timestamp) ? MAX_AGE : CLOSED_MAX_AGE;
        if (block.timestamp > at + limit) revert StaleAnswer(at);
        updatedAt = uint64(block.timestamp);
    }

    /// @notice True inside FxMarketHours' core session, when the rate prices. For readers (the monitor).
    function inCoreSession() external view returns (bool) {
        return FxMarketHours.inCoreSession(block.timestamp);
    }

    /// @dev Reais per dollar at 1e-6 and the round's time, after every check but age.
    function _read() private view returns (uint256 price, uint256 at) {
        // roundId, startedAt and answeredInRound carry no staleness signal on OCR aggregators; freshness
        // is judged by updatedAt alone, as everywhere else in this repository.
        // slither-disable-next-line unused-return
        (, int256 answer,, uint256 updatedAt,) = FEED.latestRoundData();
        if (answer <= 0) revert BadAnswer(answer);
        if (updatedAt == 0) revert IncompleteRound();
        if (updatedAt > block.timestamp + MAX_FUTURE_SKEW) revert AnswerFromFuture(updatedAt);
        uint8 dec = FEED.decimals();
        if (dec != DECIMALS) revert DecimalsChanged(dec);
        // Floor; see "Units and rounding". An answer above SCALE reads as zero and is refused by the range.
        price = SCALE / uint256(answer);
        if (price < MIN_BRL_PER_USD_E6 || price > MAX_BRL_PER_USD_E6) revert RateOutOfRange(price);
        at = updatedAt;
    }
}
