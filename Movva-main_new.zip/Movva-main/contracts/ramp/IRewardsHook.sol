// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/**
 * @notice What LPRegistry tells a rewards contract about each settlement it records.
 * @dev Called from `LPRegistry.recordSettled` with a fixed gas budget and its outcome ignored (see LPRegistry,
 *      "Rewards hook"). An implementation must therefore be cheap, and must treat the call as a report rather
 *      than a request: whatever it does, it cannot make a settlement fail.
 */
interface IRewardsHook {
    /// @param lp The LP whose position settled.
    /// @param brlCents The settled amount, in BRL centavos, as the escrow reported it.
    /// @param tier The LP's `LPRegistry.Tier`, by index, at the moment of settlement.
    function onSettled(address lp, uint256 brlCents, uint8 tier) external;
}
