// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {ILPRegistry} from "./ILPRegistry.sol";
import {IRewardsHook} from "./IRewardsHook.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";

/**
 * @title LPRegistry
 * @notice LP onboarding, network phases, tiers, credit and reputation (tasks 2.3 and 2.7).
 *
 * ## Reputation here is a limit, not a score
 *
 * The temptation is a number that goes up, shown to users. That is worse than useless in a
 * ramp: a public score is a target, cheap to farm with self-dealing (an LP takes their own
 * offers, pays themselves BRL, and settles honestly all day), and users cannot price it.
 *
 * What this stores instead is a *credit limit*. Reputation controls how much an LP is
 * allowed to have at risk at one time, and nothing else. Farming a limit still requires
 * posting real capital and settling real payments, and the only thing it buys is permission
 * to post more capital. That makes the attack self-funding in the wrong direction.
 *
 * The one place settled volume does pay is node-provider rewards, because Mova chose to share
 * its fee revenue with the LPs who carry the flow. That lives in NodeRewards, behind the hook
 * below, with its own bounds against exactly this farming (SR2-36), and it changes nothing here:
 * a limit is still a limit.
 *
 * ## The limit is on the LP, not on each position
 *
 * "At one time" means across everything the LP has live: every offer and order on the
 * on-ramp and every claimed sale on the off-ramp. An earlier version compared each offer or
 * sale with the limit separately, so twenty offers each just under a R$5,000 retail cap put
 * R$100,000 at risk, and `fundOffer` topped an offer up without asking at all. The escrows
 * now reserve exposure here when they take it on and release it when it ends, and a
 * reservation that would take the LP's total over its limit fails.
 *
 * The total is kept here rather than in each escrow because an LP's credit is one number
 * across the product - reputation already was - and two escrows each enforcing the full
 * limit would allow twice the limit. Only registered escrows may reserve, and each escrow can
 * only release what IT reserved, so a misbehaving or retired escrow cannot free exposure
 * another escrow is still holding.
 *
 * ## Network phases (client requirement: institutional first)
 *
 *  - Phase A: only licensed LPs (PSPs, OTC desks, fintechs), admitted by the governor as
 *    INSTITUTIONAL with a credit limit set by contract and licence. `register()` reverts.
 *  - Phase B: additionally, an active INSTITUTIONAL LP may sponsor AFFILIATED LPs - its
 *    partner network ("vinculados"). An affiliate's credit is CARVED OUT of the sponsor's
 *    own limit: the sponsor gives up that much headroom, and the group - sponsor plus every
 *    affiliate - can never have more at risk than the sponsor's limit. Suspending the
 *    sponsor stops all of its affiliates taking new exposure.
 *  - Phase C: additionally, permissionless RETAIL self-registration, with the base cap that
 *    grows with settled volume.
 *
 * Opening a phase is risk-increasing and waits out the governance delay. Closing one is
 * instant: it is the lever for "retail onboarding is being abused, stop it now". A phase
 * does not only gate onboarding - AFFILIATED LPs have no credit below Phase B and RETAIL LPs
 * none below Phase C - because the incident that justifies stopping new entrants also
 * justifies stopping those tiers from opening new positions. Nothing already live is
 * touched: releases never consult the phase, so open positions settle or expire normally.
 * Phases therefore only move backwards through that instant close, and only forwards
 * through the delay.
 *
 * ## Rewards hook
 *
 * Optionally, the registry tells a rewards contract (NodeRewards) about every settlement it
 * records - the LP, the centavos, and the LP's tier at that moment - so rewards can follow
 * settled volume without either escrow changing. Setting a hook waits out the governance delay:
 * it decides whose volume shares Mova's fees. Removing one is instant.
 *
 * The call gets REWARDS_HOOK_GAS and its outcome is ignored - a failure only emits
 * RewardsHookFailed - and its return data is never copied, so a hook that reverts, loops, or
 * answers with a mountain of data cannot block a settlement or make it cost more than the
 * budget. It runs after the registry's own books are written, so a hook calling back in finds
 * them final.
 *
 * One thing does revert: a transaction that reaches the hook with too little gas left to give it
 * its full budget (RewardsHookNeedsGas). Skipping the hook instead would let anyone who submits a
 * release with a tight gas limit erase an LP's volume - and `eth_estimateGas`, which searches for
 * the least gas at which a transaction does not revert, would land on exactly that limit for
 * every honest settlement too. With the check, the least gas that succeeds is gas that pays the
 * hook. Like running out of gas, it is fixed by sending more; no funds wait on it.
 *
 * ## One bank transaction, one settlement
 *
 * A bank transaction id is spent here, not in each escrow. Each escrow used to keep its own
 * `usedBankTxId`, so one PIX could settle an order on the on-ramp AND a sale on the off-ramp
 * when both named the same payee commitment and both zkTLS sessions bound it (SRM1-12): the
 * payer or payee of a PIX can prove the same receipt twice, bound to two ids. Both escrows
 * already share this registry - it is immutable in each, and credit is one number across them
 * for the same reason - so the set of spent ids lives beside the credit, and a settlement on any
 * escrow refuses an id another escrow has spent (`consumeBankTxId`).
 *
 * Only an escrow may spend one, or anyone watching the mempool could spend the id of a payment
 * before its proof lands and strand the order. "An escrow" includes a retired one
 * (`wasEscrow`): retiring an escrow must not strand its live orders, whose takers may already
 * have paid - the same reason `releaseExposure` is open to it. A retired escrow can only spend
 * the id of a payment its own verifier proved for one of its own positions.
 *
 * Note what is deliberately absent: no KYC data, no names, no documents, not even hashes of
 * them. Admission is a governor decision made off-chain and recorded here as a tier. A
 * registry that stored personal data would make every LP's identity a permanent public
 * record, which is a strange thing to build into a privacy protocol.
 */
contract LPRegistry is ILPRegistry, DelayedGovernance {
    /// @dev The numeric order is part of the ABI: off-chain tooling encodes tiers by index.
    enum Tier {
        NONE,
        RETAIL,
        AFFILIATED,
        INSTITUTIONAL,
        SUSPENDED
    }

    enum Phase {
        A, // institutional only
        B, // + sponsored affiliates
        C // + open retail
    }

    struct LP {
        Tier tier;
        uint256 settledCents; // lifetime settled volume, BRL centavos
        uint32 settlements;
        uint32 disputesLost;
        // INSTITUTIONAL: the governor-set credit limit. AFFILIATED: the credit its sponsor
        // carved out for it. RETAIL: unused (the formula applies). Kept on suspension.
        uint256 manualCapCents;
        address sponsor; // AFFILIATED: the institution it draws on; kept while exposure is live
        uint256 exposureCents; // live BRL exposure across every registered escrow
    }

    /// @notice A brand-new retail LP may have this much at risk at once: R$5,000.
    /// @dev Denominated in centavos so one limit covers every settlement asset - see
    ///      ILPRegistry. Asset-denominated caps cannot be compared across tokens.
    uint256 public constant BASE_CAP_CENTS = 500_000;
    /// @notice Each settled centavo raises the cap by this much, up to MAX_RETAIL_CAP_CENTS.
    uint256 public constant CAP_PER_SETTLED_BPS = 2_000; // 20% of settled volume
    /// @notice R$250,000.
    uint256 public constant MAX_RETAIL_CAP_CENTS = 25_000_000;
    /// @notice Lost disputes cut the cap in half each, so damage compounds faster than trust.
    uint32 public constant MAX_HALVINGS = 8;
    /// @notice Gas the rewards hook is given for each settlement. See "Rewards hook".
    uint256 public constant REWARDS_HOOK_GAS = 100_000;
    /// @notice Gas `recordSettled` must still have when it calls a hook: the hook's budget, the
    ///         1/64 EIP-150 holds back from any call, and the call's own cost with room to spare.
    uint256 public constant REWARDS_HOOK_MIN_GAS = REWARDS_HOOK_GAS + REWARDS_HOOK_GAS / 63 + 10_000;

    Phase public phase;
    mapping(address => LP) public lps;
    /// @notice Escrows whose settlement reports and exposure reservations this registry accepts.
    /// @dev A set, not a single address. It was a single address, and that silently
    ///      discarded every off-ramp settlement: recordSettled must not revert (it runs
    ///      inside a release path, after someone's BRL has already left their bank), so an
    ///      unrecognised caller returns quietly - and half the product's reputation went
    ///      nowhere with no error anywhere. Failing quiet is right; failing quiet on the
    ///      wrong condition is how a whole feature disappears without a trace.
    mapping(address => bool) public isEscrow;
    /// @notice Sponsor => total credit it has carved out for its affiliates.
    mapping(address => uint256) public carvedOutCents;
    /// @notice Sponsor (or unsponsored LP) => its own exposure plus its affiliates'.
    mapping(address => uint256) public groupExposureCents;
    /// @notice Escrow => LP => exposure that escrow reserved and has not released.
    mapping(address => mapping(address => uint256)) public reservedBy;
    /// @notice Told of every settlement recorded (IRewardsHook); zero for none. See "Rewards hook".
    address public rewardsHook;
    /// @notice Escrows this registry has ever accepted. Unlike `isEscrow`, never cleared: a
    ///         retired escrow may still spend bank transaction ids to settle what it holds.
    mapping(address => bool) public wasEscrow;
    /// @notice Bank transactions that have settled a position on any escrow of this registry.
    ///         See "One bank transaction, one settlement".
    mapping(bytes32 => bool) public usedBankTxId;

    event Registered(address indexed lp, Tier tier);
    event TierChanged(address indexed lp, Tier from, Tier to, uint256 creditCents);
    event PhaseSet(Phase from, Phase to);
    event AffiliateSponsored(address indexed sponsor, address indexed affiliate, uint256 creditCents);
    event AffiliateRevoked(address indexed sponsor, address indexed affiliate);
    event ExposureReserved(address indexed lp, address indexed escrow, uint256 brlCents, uint256 total);
    event ExposureReleased(address indexed lp, address indexed escrow, uint256 brlCents, uint256 total);
    event Settled(address indexed lp, uint256 brlCents, uint256 newCap);
    event DisputeLost(address indexed lp, uint32 total, uint256 newCap);
    event EscrowSet(address indexed escrow, bool allowed);
    event RewardsHookSet(address indexed hook);
    /// @notice The rewards hook reverted or ran out of its gas: this settlement counted for no rewards.
    event RewardsHookFailed(address indexed hook, address indexed lp, uint256 brlCents);
    event BankTxIdConsumed(bytes32 indexed bankTxId, address indexed escrow);

    error NotEscrow();
    error AlreadyRegistered();
    error PhaseNotOpen(Phase required);
    error PhaseUnchanged();
    error NotSponsor();
    error BadAffiliate();
    error BadTier();
    error BadCredit();
    error CreditExceedsSponsor();
    error BadRewardsHook();
    error RewardsHookNeedsGas(uint256 gasLeft);

    constructor(address governor_, uint256 governanceDelay)
        DelayedGovernance(governor_, governanceDelay)
    {}

    /*//////////////////////////////////////////////////////////////
                               GOVERNANCE
    //////////////////////////////////////////////////////////////*/

    /// @notice Registering an escrow waits out the governance delay; removing one is instant.
    /// @dev A registered escrow can reserve credit and record settlements - which raise
    ///      retail caps - so adding one is adding a party that can move limits.
    function setEscrow(address escrow_, bool allowed) external {
        _authorizeChange(allowed && !isEscrow[escrow_]);
        if (escrow_ == address(0)) revert ZeroAddress();
        isEscrow[escrow_] = allowed;
        if (allowed) wasEscrow[escrow_] = true;
        emit EscrowSet(escrow_, allowed);
    }

    /// @notice Open the next network phase (delayed), or close back to an earlier one (instant).
    function setPhase(Phase next) external {
        _authorizeChange(next > phase);
        if (next == phase) revert PhaseUnchanged();
        emit PhaseSet(phase, next);
        phase = next;
    }

    /**
     * @notice Point settlement reports at a rewards contract (delayed), or stop them (zero, instant).
     * @dev The hook decides whose settled volume shares Mova's fees, so a new one is a party that can
     *      move value. It must be a contract: a call to an address without code succeeds and would
     *      hide a typo behind a hook that never fails.
     */
    function setRewardsHook(address hook) external {
        _authorizeChange(hook != address(0) && hook != rewardsHook);
        if (hook != address(0) && hook.code.length == 0) revert BadRewardsHook();
        rewardsHook = hook;
        emit RewardsHookSet(hook);
    }

    /**
     * @notice Admit, re-tier or remove an LP.
     * @dev Instant when it can only reduce risk: SUSPENDED, NONE, or lowering an
     *      institution's credit. Everything else - admitting an institution, raising its
     *      credit, reinstating a suspended LP, making someone RETAIL - waits out the delay.
     *
     *      SUSPENDED keeps the credit and sponsor on record so reinstatement restores them;
     *      `creditCents` is ignored. NONE clears the credit and frees an affiliate's
     *      carve-out. AFFILIATED is only for reinstating an affiliate that still has its
     *      sponsor; creating affiliates is the sponsor's call, through `sponsorAffiliate`.
     */
    function setTier(address lp, Tier tier, uint256 creditCents) external {
        LP storage r = lps[lp];
        Tier from = r.tier;
        bool riskIncreasing = false;
        if (tier == Tier.INSTITUTIONAL) {
            riskIncreasing = from != Tier.INSTITUTIONAL || creditCents > r.manualCapCents;
        } else if (tier == Tier.RETAIL || tier == Tier.AFFILIATED) {
            riskIncreasing = from != tier;
        }
        _authorizeChange(riskIncreasing);
        if (lp == address(0)) revert ZeroAddress();

        if (tier == Tier.INSTITUTIONAL) {
            // An affiliate's exposure is accounted to its sponsor's group; it must leave
            // that group (and have nothing live in it) before standing on its own.
            if (r.sponsor != address(0)) revert BadTier();
            r.manualCapCents = creditCents;
        } else if (tier == Tier.RETAIL) {
            if (r.sponsor != address(0)) revert BadTier();
            if (creditCents != 0) revert BadCredit();
            r.manualCapCents = 0;
        } else if (tier == Tier.AFFILIATED) {
            if (r.sponsor == address(0)) revert BadTier();
            if (creditCents != r.manualCapCents) revert BadCredit();
        } else if (tier == Tier.NONE) {
            _dropAffiliation(lp, r);
            r.manualCapCents = 0;
        }
        r.tier = tier;
        emit TierChanged(lp, from, tier, r.manualCapCents);
    }

    function _isDelayable(bytes4 selector) internal pure override returns (bool) {
        return selector == LPRegistry.setEscrow.selector || selector == LPRegistry.setTier.selector
            || selector == LPRegistry.setPhase.selector || selector == LPRegistry.setRewardsHook.selector;
    }

    /*//////////////////////////////////////////////////////////////
                               ONBOARDING
    //////////////////////////////////////////////////////////////*/

    /// @notice Permissionless retail onboarding, Phase C only. The cap, not the gate, is the
    ///         control - once the network has been opened to retail at all.
    /// @dev An LP the governor removed (tier NONE) may register again, and keeps its history:
    ///      re-registering must not launder lost disputes.
    function register() external {
        _requireSetupComplete();
        if (phase < Phase.C) revert PhaseNotOpen(Phase.C);
        LP storage r = lps[msg.sender];
        if (r.tier != Tier.NONE || r.sponsor != address(0)) revert AlreadyRegistered();
        r.tier = Tier.RETAIL;
        emit Registered(msg.sender, Tier.RETAIL);
    }

    /**
     * @notice Sponsor an affiliated LP, or change its credit. Phase B onwards; caller must be
     *         an active INSTITUTIONAL LP.
     * @dev Not delayed, because it cannot add risk the governor did not already approve: the
     *      credit comes out of the sponsor's own delayed limit, and the reservation check
     *      caps the whole group at that limit whatever the carve-outs say. Raising a
     *      carve-out requires the sponsor to have that much unused headroom right now.
     */
    function sponsorAffiliate(address affiliate, uint256 creditCents) external {
        _requireSetupComplete();
        if (phase < Phase.B) revert PhaseNotOpen(Phase.B);
        LP storage s = lps[msg.sender];
        if (s.tier != Tier.INSTITUTIONAL) revert NotSponsor();
        if (affiliate == address(0) || affiliate == msg.sender) revert BadAffiliate();
        if (creditCents == 0) revert BadCredit();

        LP storage a = lps[affiliate];
        uint256 previous = 0;
        bool isNew = a.tier != Tier.AFFILIATED || a.sponsor != msg.sender;
        if (isNew) {
            // Only a blank address with nothing live can join a group: its exposure would
            // otherwise be counted against the wrong sponsor when it is released.
            if (a.tier != Tier.NONE || a.sponsor != address(0) || a.exposureCents != 0) {
                revert BadAffiliate();
            }
        } else {
            previous = a.manualCapCents;
        }

        uint256 carved = carvedOutCents[msg.sender] - previous + creditCents;
        if (creditCents > previous && carved + s.exposureCents > s.manualCapCents) {
            revert CreditExceedsSponsor();
        }
        carvedOutCents[msg.sender] = carved;
        a.tier = Tier.AFFILIATED;
        a.sponsor = msg.sender;
        a.manualCapCents = creditCents;
        if (isNew) emit Registered(affiliate, Tier.AFFILIATED);
        emit AffiliateSponsored(msg.sender, affiliate, creditCents);
    }

    /// @notice End an affiliation. The sponsor can always do this, whatever its own tier.
    function revokeAffiliate(address affiliate) external {
        LP storage a = lps[affiliate];
        if (a.sponsor != msg.sender || (a.tier != Tier.AFFILIATED && a.tier != Tier.SUSPENDED)) {
            revert NotSponsor();
        }
        Tier from = a.tier;
        _dropAffiliation(affiliate, a);
        a.manualCapCents = 0;
        a.tier = Tier.NONE;
        emit TierChanged(affiliate, from, Tier.NONE, 0);
    }

    /// @dev Frees an affiliate's carve-out. The sponsor link survives while the affiliate
    ///      still has exposure live, so its release is subtracted from the right group.
    function _dropAffiliation(address lp, LP storage r) private {
        address sponsor = r.sponsor;
        if (sponsor == address(0)) return;
        carvedOutCents[sponsor] = _sub(carvedOutCents[sponsor], r.manualCapCents);
        if (r.exposureCents == 0) r.sponsor = address(0);
        emit AffiliateRevoked(sponsor, lp);
    }

    /*//////////////////////////////////////////////////////////////
                              CREDIT LIMITS
    //////////////////////////////////////////////////////////////*/

    /// @notice The LP's credit limit, before subtracting anything it has live.
    function capOf(address lp) public view returns (uint256) {
        LP storage r = lps[lp];
        if (r.tier == Tier.INSTITUTIONAL) {
            return r.manualCapCents; // set by contract and licence, not by on-chain history
        }
        if (r.tier == Tier.AFFILIATED) {
            if (phase < Phase.B) return 0;
            LP storage s = lps[r.sponsor];
            if (s.tier != Tier.INSTITUTIONAL) return 0; // a suspended sponsor stops its network
            uint256 carved = r.manualCapCents >> _halvings(r.disputesLost);
            return carved < s.manualCapCents ? carved : s.manualCapCents;
        }
        if (r.tier == Tier.RETAIL) {
            if (phase < Phase.C) return 0;
            uint256 cap = BASE_CAP_CENTS + (r.settledCents * CAP_PER_SETTLED_BPS) / 10_000;
            if (cap > MAX_RETAIL_CAP_CENTS) cap = MAX_RETAIL_CAP_CENTS;
            return cap >> _halvings(r.disputesLost);
        }
        return 0; // NONE, SUSPENDED
    }

    /// @notice How much more exposure the LP may take on right now.
    function availableCents(address lp) public view returns (uint256) {
        uint256 cap = capOf(lp);
        if (cap == 0) return 0;
        LP storage r = lps[lp];
        if (r.tier == Tier.INSTITUTIONAL) {
            // Its own positions may use only what it has not carved out for affiliates...
            uint256 own = _sub(_sub(cap, carvedOutCents[lp]), r.exposureCents);
            // ...and the whole group may never exceed its limit.
            return _min(own, _sub(cap, groupExposureCents[lp]));
        }
        if (r.tier == Tier.AFFILIATED) {
            uint256 sponsorCap = lps[r.sponsor].manualCapCents;
            return _min(_sub(cap, r.exposureCents), _sub(sponsorCap, groupExposureCents[r.sponsor]));
        }
        return _sub(cap, r.exposureCents);
    }

    function canQuote(address lp, uint256 brlCents) external view returns (bool) {
        return setupComplete && brlCents <= availableCents(lp);
    }

    /*//////////////////////////////////////////////////////////////
                         ESCROW-FACING ACCOUNTING
    //////////////////////////////////////////////////////////////*/

    /// @inheritdoc ILPRegistry
    function reserveExposure(address lp, uint256 brlCents) external returns (bool) {
        if (!isEscrow[msg.sender]) revert NotEscrow();
        _requireSetupComplete();
        if (brlCents > availableCents(lp)) return false;
        LP storage r = lps[lp];
        r.exposureCents += brlCents;
        reservedBy[msg.sender][lp] += brlCents;
        groupExposureCents[_group(lp, r)] += brlCents;
        emit ExposureReserved(lp, msg.sender, brlCents, r.exposureCents);
        return true;
    }

    /**
     * @inheritdoc ILPRegistry
     * @dev Deliberately not gated on `isEscrow`: an escrow retired while it still holds
     *      reservations must be able to give them back, or its LPs' credit is stuck forever.
     *      What gates it is `reservedBy` - a caller can only release what it reserved.
     */
    function releaseExposure(address lp, uint256 brlCents) external {
        uint256 held = reservedBy[msg.sender][lp];
        if (brlCents > held) brlCents = held;
        if (brlCents == 0) return;
        reservedBy[msg.sender][lp] = held - brlCents;
        LP storage r = lps[lp];
        address group = _group(lp, r);
        r.exposureCents = _sub(r.exposureCents, brlCents);
        groupExposureCents[group] = _sub(groupExposureCents[group], brlCents);
        if (r.exposureCents == 0 && r.sponsor != address(0) && r.tier == Tier.NONE) {
            r.sponsor = address(0);
        }
        emit ExposureReleased(lp, msg.sender, brlCents, r.exposureCents);
    }

    /**
     * @dev MUST NOT revert: it is called inside the escrow's release path, and a registry
     *      bug must never be able to strand a taker's funds after their BRL has left their
     *      bank account. An unauthorised caller is ignored rather than reverted for the same
     *      reason - fail quiet here, not closed. A rewards hook is told last, and cannot make it
     *      revert; the one exception is a call left with too little gas to pay the hook its
     *      budget, which the sender fixes with more gas (see "Rewards hook").
     */
    function recordSettled(address lp, uint256 brlCents) external {
        if (!isEscrow[msg.sender]) return;
        LP storage r = lps[lp];
        unchecked {
            r.settledCents += brlCents;
            r.settlements += 1;
        }
        emit Settled(lp, brlCents, capOf(lp));
        address hook = rewardsHook;
        if (hook != address(0)) _notifyRewards(hook, lp, brlCents, r.tier);
    }

    /**
     * @dev A raw CALL with a fixed gas budget and no return data copied: see "Rewards hook". The
     *      outcome is checked - a failure is an event, never a revert.
     */
    function _notifyRewards(address hook, address lp, uint256 brlCents, Tier tier) private {
        bytes memory data = abi.encodeCall(IRewardsHook.onSettled, (lp, brlCents, uint8(tier)));
        if (gasleft() < REWARDS_HOOK_MIN_GAS) revert RewardsHookNeedsGas(gasleft());
        bool ok;
        // Assembly so that nothing the hook returns is copied into this frame's memory.
        assembly {
            ok := call(REWARDS_HOOK_GAS, hook, 0, add(data, 32), mload(data), 0, 0)
        }
        if (!ok) emit RewardsHookFailed(hook, lp, brlCents);
    }

    function recordDispute(address lp) external {
        if (!isEscrow[msg.sender]) return;
        LP storage r = lps[lp];
        unchecked {
            r.disputesLost += 1;
        }
        emit DisputeLost(lp, r.disputesLost, capOf(lp));
    }

    /**
     * @inheritdoc ILPRegistry
     * @dev Reverts for a caller that was never an escrow: see "One bank transaction, one
     *      settlement". A replay returns false rather than reverting, so the escrow names it.
     */
    function consumeBankTxId(bytes32 bankTxId) external returns (bool fresh) {
        if (!wasEscrow[msg.sender]) revert NotEscrow();
        if (usedBankTxId[bankTxId]) return false;
        usedBankTxId[bankTxId] = true;
        emit BankTxIdConsumed(bankTxId, msg.sender);
        return true;
    }

    /*//////////////////////////////////////////////////////////////
                                 UTIL
    //////////////////////////////////////////////////////////////*/

    function _group(address lp, LP storage r) private view returns (address) {
        return r.sponsor != address(0) ? r.sponsor : lp;
    }

    function _halvings(uint32 disputesLost) private pure returns (uint32) {
        return disputesLost > MAX_HALVINGS ? MAX_HALVINGS : disputesLost;
    }

    function _sub(uint256 a, uint256 b) private pure returns (uint256) {
        return a > b ? a - b : 0;
    }

    function _min(uint256 a, uint256 b) private pure returns (uint256) {
        return a < b ? a : b;
    }
}
