// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IPriceOracle} from "./IPriceOracle.sol";
import {IPyth} from "./IPyth.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";

/**
 * @title PythBrlOracle
 * @notice BRL centavos per 1 ETH from Pyth, as an alternative to Chainlink (task 2.5).
 *
 * Same job and same contract of behaviour as ChainlinkBrlOracle: cross ETH/USD with
 * BRL/USD, revert rather than serve a price nobody is maintaining. Two feeds are needed
 * here for the same reason - Pyth publishes no ETH/BRL.
 *
 * ## What Pyth gives us that Chainlink does not, and why it is used
 *
 * Every Pyth price carries a confidence interval. That is a genuinely better input for a
 * sanity band than a bare number, because the interesting failure is not "the price is
 * wrong" but "nobody currently knows the price" - a thin BRL market at 3am, or the seconds
 * around a violent move. A wide confidence band is the publisher saying exactly that.
 *
 * So `maxConfBps` rejects a price whose interval is too wide relative to the price itself,
 * and the escrow stops trading rather than banding around a number the publisher is
 * hedging. Without this check Pyth would be strictly worse than Chainlink here: same
 * staleness risk, plus the illusion of precision.
 *
 * ## The pull model, and the caveat that comes with it
 *
 * Pyth is pull-based: prices are only as fresh as the last update someone paid to post.
 * `getPriceNoOlderThan` enforces the age, and this contract deliberately does NOT call
 * `updatePriceFeeds` - doing so would make a read payable and put a price update inside the
 * escrow's trade path, where a failed update becomes a failed trade. Keeping the feed warm
 * is an operational job, and if nobody does it, this reverts. That is the correct failure.
 *
 * ## Governance (DelayedGovernance)
 *
 * Repointing either price id, lengthening the max age or widening the confidence bound waits
 * out GOVERNANCE_DELAY; tightening the age or the bound, ids unchanged, is instant. An escrow
 * pointed at a different oracle waits (SR2-14), and swapping the feeds inside this one is the
 * same change. Until `completeSetup()` the cross refuses to price.
 */
contract PythBrlOracle is IPriceOracle, DelayedGovernance {
    IPyth public immutable PYTH;
    bytes32 public ethUsdId;
    /**
     * @notice Pyth's `FX.USD/BRL` feed: **BRL per one USD** (~5.4), not USD per BRL.
     *
     * The direction is named in the field because getting it wrong is silent and large.
     * Chainlink's mainnet aggregator quotes BRL/USD (~0.20 USD per BRL) and Pyth quotes
     * USD/BRL - reciprocals. This contract divided by the rate, which is correct for
     * Chainlink's direction and wrong for Pyth's by a factor of about 29. Nothing caught it
     * because the unit tests fed a mock seeded with 0.2, so the same wrong assumption
     * produced the code and the fixture that checked it.
     */
    bytes32 public usdBrlId;
    uint256 public maxAge;
    /// @notice Reject a price whose confidence interval exceeds this share of the price.
    uint256 public maxConfBps;

    event FeedsSet(bytes32 ethUsdId, bytes32 usdBrlId, uint256 maxAge, uint256 maxConfBps);
    // `governor`, `transferGovernor`, `GovernorTransferred`, `NotGovernor()` and `ZeroAddress()`
    // are DelayedGovernance's now, with the signatures this contract declared itself.

    error BadFeedId();
    error BadPrice(bytes32 id, int64 price);
    error ConfidenceTooWide(bytes32 id, uint64 conf, int64 price);
    error ExponentOutOfRange(bytes32 id, int32 expo);

    constructor(
        address pyth,
        bytes32 ethUsdId_,
        bytes32 usdBrlId_,
        uint256 maxAge_,
        uint256 maxConfBps_,
        address governor_,
        uint256 governanceDelay
    ) DelayedGovernance(governor_, governanceDelay) {
        if (pyth == address(0)) revert ZeroAddress();
        if (ethUsdId_ == bytes32(0) || usdBrlId_ == bytes32(0)) revert BadFeedId();
        PYTH = IPyth(pyth);
        ethUsdId = ethUsdId_;
        usdBrlId = usdBrlId_;
        maxAge = maxAge_;
        maxConfBps = maxConfBps_;
    }

    /// @notice Repointing an id, lengthening the max age or widening the confidence bound waits
    ///         out the governance delay; tightening either, ids unchanged, is instant.
    function setFeeds(bytes32 ethUsdId_, bytes32 usdBrlId_, uint256 maxAge_, uint256 maxConfBps_) external {
        _authorizeChange(
            ethUsdId_ != ethUsdId || usdBrlId_ != usdBrlId || maxAge_ > maxAge || maxConfBps_ > maxConfBps
        );
        if (ethUsdId_ == bytes32(0) || usdBrlId_ == bytes32(0)) revert BadFeedId();
        ethUsdId = ethUsdId_;
        usdBrlId = usdBrlId_;
        maxAge = maxAge_;
        maxConfBps = maxConfBps_;
        emit FeedsSet(ethUsdId_, usdBrlId_, maxAge_, maxConfBps_);
    }

    function brlCentsPerUnit() external view returns (uint256 price, uint64 updatedAt) {
        _requireSetupComplete();
        (uint256 eth, int32 ethExpo, uint256 ethAt) = _read(ethUsdId);
        (uint256 brl, int32 brlExpo, uint256 brlAt) = _read(usdBrlId);

        // USD per ETH times BRL per USD gives BRL per ETH; times 100 gives centavos.
        //
        //   centavos = eth * 10^ethExpo * brl * 10^brlExpo * 100
        //
        // Pyth exponents are negative, so the combined scale divides. MULTIPLYING here is
        // the whole correction: this used to divide, which is right for a BRL/USD feed and
        // wrong for Pyth's USD/BRL by roughly 29x.
        int256 sum = int256(ethExpo) + int256(brlExpo);
        uint256 num = eth * brl * 100;
        price = sum >= 0 ? num * (10 ** uint256(sum)) : num / (10 ** uint256(-sum));
        updatedAt = uint64(ethAt < brlAt ? ethAt : brlAt); // freshness of the stalest leg
    }

    function _isDelayable(bytes4 selector) internal pure override returns (bool) {
        return selector == PythBrlOracle.setFeeds.selector;
    }

    function _read(bytes32 id) private view returns (uint256 value, int32 expo, uint256 at) {
        IPyth.Price memory p = PYTH.getPriceNoOlderThan(id, maxAge);
        if (p.price <= 0) revert BadPrice(id, p.price);
        // Guard the exponent before it reaches 10 ** n: a corrupt or unexpected feed could
        // otherwise ask for an astronomically large power and burn the caller's gas.
        if (p.expo < -18 || p.expo > 18) revert ExponentOutOfRange(id, p.expo);

        // Confidence check, kept adjacent to the read so it cannot drift away from it:
        // reject when the published interval is wide relative to the price itself.
        uint256 abs = uint256(uint64(p.price));
        uint256 tolerance = (abs * maxConfBps) / 10_000;
        if (p.conf > tolerance) revert ConfidenceTooWide(id, p.conf, p.price);

        return (abs, p.expo, p.publishTime);
    }
}
