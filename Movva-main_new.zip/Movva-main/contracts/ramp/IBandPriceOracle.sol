// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IPriceOracle} from "./IPriceOracle.sol";

/**
 * @title IBandPriceOracle
 * @notice A price source whose market closes, read two ways.
 *
 * `brlCentsPerUnit` (IPriceOracle) is the price as last traded, refused once stale: what anything that
 * moves value at the price reads. `brlCentsPerUnitForBand` is what a sanity band reads: the same price
 * while the market trades, and, while it is closed, the last close - stamped with the time of the read,
 * because it stands until the market reopens. A band admits or refuses offers and never sets a trade's
 * price (IPriceOracle), so it can keep working on a closing price when a mint must not. See PythFxOracle.
 */
interface IBandPriceOracle is IPriceOracle {
    /// @notice The price for a sanity band, in the unit of `brlCentsPerUnit`.
    /// @return price     As `brlCentsPerUnit` while the market trades; the last close while it is closed.
    /// @return updatedAt The publish time while the market trades; the current block's while it is closed.
    function brlCentsPerUnitForBand() external view returns (uint256 price, uint64 updatedAt);
}

/// @notice How a band reads a price source: through `brlCentsPerUnitForBand` when it has one.
library BandRead {
    /**
     * @dev A source without the band reading - SignedPriceOracle, a Chainlink cross, a test double -
     *      reverts on the unknown selector and is read through `brlCentsPerUnit` instead, exactly as
     *      before. A band reading that reverts for a reason of its own (a close older than its limit, a
     *      wide confidence interval, setup open) falls through to `brlCentsPerUnit` too, which refuses
     *      the same price for at least the same reason: it is the stricter reading of the same source.
     *      A source whose fallback returns successfully without data is not supported; decoding the
     *      empty answer reverts, which fails closed.
     */
    function read(IPriceOracle source) internal view returns (uint256 price, uint64 updatedAt) {
        try IBandPriceOracle(address(source)).brlCentsPerUnitForBand() returns (uint256 p, uint64 t) {
            return (p, t);
        } catch {
            return source.brlCentsPerUnit();
        }
    }
}
