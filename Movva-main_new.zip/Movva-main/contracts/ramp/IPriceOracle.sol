// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/**
 * @title IPriceOracle
 * @notice BRL-per-asset price, used only as a SANITY BAND (task 2.5).
 *
 * The oracle is deliberately not the price. The price of an order is whatever the LP posted
 * and the taker accepted; the oracle exists to reject the pairs that are obviously wrong -
 * a fat-fingered offer three decimal places off, or an LP hoping a confused user accepts
 * 10x the market rate.
 *
 * That distinction matters for the threat model. If the oracle *were* the price, then
 * manipulating it would move real value, and a ramp settling in BRL would inherit every
 * oracle attack that has ever drained a lending market. As a band, a manipulated oracle can
 * at worst widen or narrow what offers are accepted - it cannot mint a favourable trade.
 * This is why the escrow refuses to trade when the oracle is stale rather than falling back
 * to a last-known price: no price is a safe answer here, a wrong one is not.
 */
interface IPriceOracle {
    /**
     * @notice Current BRL centavos per ONE WHOLE TOKEN of the asset: per 10**decimals base
     *         units, where decimals is the asset's in the escrow's AssetConfig. For ETH that
     *         is per 1e18 wei (R$13,400.00 per ETH is 1,340,000); for USDT, per 1e6 base units
     *         (R$5.40 per USDT is 540).
     * @dev This used to say "per 1e18 units", which is the same thing for ETH and wrong by 1e12
     *      for a 6-decimal token. The escrows compute `ceilDiv(units * price, 10**decimals)`
     *      (FiatEscrow._lock) and `brlCents * 10**decimals / units` (OffRampEscrow.openSale), so
     *      the price is per whole token. An oracle written to the old sentence would price USDT
     *      a trillion times too high, and every USDT offer would fall outside the band.
     *
     *      MUST revert if no fresh price is available. Returning a stale or zero price
     *      silently is the failure mode this interface exists to prevent.
     */
    function brlCentsPerUnit() external view returns (uint256 price, uint64 updatedAt);
}
