// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {Math} from "@openzeppelin/contracts/utils/math/Math.sol";
import {YieldVault} from "./YieldVault.sol";

/**
 * @title LimitedYieldVault
 * @notice YieldVault with a per-owner daily withdrawal limit and, above it, an announce-then-anyone-
 *         executes timelock (client decision, 24 Sep 2026, "Withdrawal limits": "timelock above the
 *         daily limit, not multisig ... a timelock lets the user withdraw, just with a delay - no one
 *         approves on their behalf").
 *
 * ## Rules
 *
 *  - **Instant lane.** `withdraw` / `redeem` pay at once while the owner's bucket has room. The bucket
 *    is `DAILY_LIMIT_BPS` of `totalAssets()` per owner, drains continuously over 24 hours (as the
 *    reserve's hedge bucket does), and an exit over the room reverts with `ExceedsDailyLimit`.
 *    `maxWithdraw` / `maxRedeem` report the room, so ERC-4626 integrators see it.
 *  - **Slow lane.** `requestRedeem(shares, receiver, owner)` takes `shares` from the owner (the caller is
 *    the owner or has allowance) into the vault's own custody and announces the request. After
 *    `WITHDRAW_DELAY` ANYONE may call `executeRedeem(id)`: it burns exactly those shares and pays their
 *    value then (`previewRedeem`) to exactly the recorded receiver, once. Nobody can cancel, approve,
 *    change or reorder it - not the owner, the guardian or the governor: a cancel right is an admin key,
 *    and the owner's own signature is the only authority a request ever needs. The shares are locked
 *    for the delay, so a request cannot be reused, and the owner takes the price at execution (yield
 *    accrues to a request; a loss lands on it as it does on every holder).
 *  - Delay and limit are immutable. There is no new privileged function, and the existing roles gain
 *    nothing: a parameter change cannot front-run a queued request because there is none to change.
 *
 * ## What it does not do
 *
 *  - The limit is per ADDRESS: an owner who splits shares over many addresses has many buckets. It is a
 *    speed bump for one key, not a defence against a whale; the slow lane is open to anyone at any size.
 *  - Do not use it as the MovvaReserve's yield vault unless the limit exceeds the largest redemption
 *    the reserve must pay in a day: the reserve is one owner and its payouts out of the vault would hit
 *    the bucket (docs/movva.md, "Timelocks above a daily limit", open question).
 *  - Execution still needs liquidity: a request the adapters cannot fund reverts and waits.
 */
contract LimitedYieldVault is YieldVault {
    struct Request {
        address receiver;
        uint64 executeAfter;
        bool executed;
        uint256 shares;
    }

    uint16 public immutable DAILY_LIMIT_BPS;
    uint64 public immutable WITHDRAW_DELAY;

    struct Bucket {
        uint64 at;
        uint192 used;
    }

    mapping(address => Bucket) internal _buckets;
    mapping(uint256 => Request) public requests;
    uint256 public requestCount;

    event RedeemRequested(
        uint256 indexed id, address indexed owner, address indexed receiver, uint256 shares, uint64 executeAfter
    );
    event RedeemExecuted(uint256 indexed id, address indexed receiver, uint256 shares, uint256 assets, address executor);

    error ExceedsDailyLimit(uint256 assets, uint256 room);
    error UnknownRequest(uint256 id);
    error RequestNotReady(uint256 id, uint64 executeAfter);
    error RequestDone(uint256 id);
    error BadLimit();
    error ZeroRequest();

    constructor(
        IERC20 asset_,
        string memory name_,
        string memory symbol_,
        address governor_,
        address guardian_,
        address keeper_,
        uint256 depositCap_,
        uint16 maxDrawdownBps_,
        uint256 governanceDelay,
        uint16 dailyLimitBps,
        uint64 withdrawDelay
    )
        YieldVault(asset_, name_, symbol_, governor_, guardian_, keeper_, depositCap_, maxDrawdownBps_, governanceDelay)
    {
        if (dailyLimitBps == 0 || dailyLimitBps > BPS || withdrawDelay < 1 hours || withdrawDelay > 30 days) {
            revert BadLimit();
        }
        DAILY_LIMIT_BPS = dailyLimitBps;
        WITHDRAW_DELAY = withdrawDelay;
    }

    /// @notice Assets `owner` may still withdraw instantly now.
    function instantRoom(address owner) public view returns (uint256) {
        (uint256 used, uint256 limit) = _bucket(owner);
        return limit > used ? limit - used : 0;
    }

    function maxWithdraw(address owner) public view override returns (uint256) {
        uint256 base = super.maxWithdraw(owner);
        uint256 room = instantRoom(owner);
        return base < room ? base : room;
    }

    function maxRedeem(address owner) public view override returns (uint256) {
        uint256 base = super.maxRedeem(owner);
        uint256 room = convertToShares(instantRoom(owner));
        return base < room ? base : room;
    }

    function withdraw(uint256 assets, address receiver, address owner) public override returns (uint256) {
        _spend(owner, assets);
        return super.withdraw(assets, receiver, owner);
    }

    function redeem(uint256 shares, address receiver, address owner) public override returns (uint256) {
        _spend(owner, previewRedeem(shares));
        return super.redeem(shares, receiver, owner);
    }

    /// @notice Announce an exit of `shares`, executable by anyone after WITHDRAW_DELAY, paid to `receiver`.
    function requestRedeem(uint256 shares, address receiver, address holder) external nonReentrant returns (uint256 id) {
        if (shares == 0 || receiver == address(0)) revert ZeroRequest();
        if (msg.sender != holder) _spendAllowance(holder, msg.sender, shares);
        _transfer(holder, address(this), shares);
        id = requestCount++;
        uint64 at = uint64(block.timestamp) + WITHDRAW_DELAY;
        requests[id] = Request({receiver: receiver, executeAfter: at, executed: false, shares: shares});
        emit RedeemRequested(id, holder, receiver, shares, at);
    }

    /// @notice Pay a request once its delay has passed. Anyone, once; exactly its shares, to its receiver.
    function executeRedeem(uint256 id) external nonReentrant returns (uint256 assets) {
        Request storage r = requests[id];
        if (r.receiver == address(0)) revert UnknownRequest(id);
        if (r.executed) revert RequestDone(id);
        if (block.timestamp < r.executeAfter) revert RequestNotReady(id, r.executeAfter);
        r.executed = true;
        (address to, uint256 shares) = (r.receiver, r.shares);
        assets = previewRedeem(shares);
        // The vault is both caller and owner here, so ERC-4626 spends no allowance.
        _withdraw(address(this), to, address(this), assets, shares);
        emit RedeemExecuted(id, to, shares, assets, msg.sender);
    }

    function _spend(address owner, uint256 assets) internal {
        (uint256 used, uint256 limit) = _bucket(owner);
        uint256 room = limit > used ? limit - used : 0;
        if (assets > room) revert ExceedsDailyLimit(assets, room);
        _buckets[owner] = Bucket({at: uint64(block.timestamp), used: uint192(used + assets)});
    }

    function _bucket(address owner) internal view returns (uint256 used, uint256 limit) {
        limit = Math.mulDiv(totalAssets(), DAILY_LIMIT_BPS, BPS);
        Bucket memory b = _buckets[owner];
        uint256 drained = Math.mulDiv(limit, block.timestamp - b.at, 1 days);
        used = b.used > drained ? b.used - drained : 0;
    }
}
