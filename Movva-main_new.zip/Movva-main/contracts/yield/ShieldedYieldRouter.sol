// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {IERC4626} from "@openzeppelin/contracts/interfaces/IERC4626.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {ShieldedDepositLabel} from "../common/ShieldedDepositLabel.sol";

/// @dev Mirrors the forked protocol's IPrivacyPool and ProofLib, so selectors match exactly.
interface IShieldedPool {
    struct Withdrawal {
        address processooor;
        bytes data;
    }

    struct WithdrawProof {
        uint256[2] pA;
        uint256[2][2] pB;
        uint256[2] pC;
        uint256[8] pubSignals;
    }

    struct RagequitProof {
        uint256[2] pA;
        uint256[2][2] pB;
        uint256[2] pC;
        uint256[4] pubSignals;
    }

    function ASSET() external view returns (address);
    function SCOPE() external view returns (uint256);
    function withdraw(Withdrawal memory w, WithdrawProof memory p) external;
    function ragequit(RagequitProof memory p) external;
}

interface IShieldedEntrypoint {
    function deposit(uint256 precommitment) external payable returns (uint256 commitment);
    function deposit(IERC20 asset, uint256 value, uint256 precommitment) external returns (uint256 commitment);
    function assetConfig(address asset)
        external
        view
        returns (address pool, uint256 minimumDepositAmount, uint256 vettingFeeBPS, uint256 maxRelayFeeBPS);
}

interface IWETH {
    function deposit() external payable;
    function withdraw(uint256) external;
}

/**
 * @title ShieldedYieldRouter
 * @notice Moves a shielded balance into a yield vault and back without it ever touching an
 *         address that belongs to the user (task 3.2).
 *
 * ## How funds stay private
 *
 * A yield position is a note in a Privacy Pool whose asset is the VAULT'S SHARE TOKEN. The
 * note's share count never changes while the share price rises, so yield compounds inside
 * the pool with nothing to claim (task 3.4). A claim would have to pay somewhere, and that
 * payment would link the note to an address.
 *
 * To enter, the user proves a withdrawal from the asset pool (USDS, or ETH) with this router
 * as the `processooor`. The pool pays the router, which deposits into the vault and deposits
 * the shares into the share pool under a fresh precommitment only the user can open. Leaving
 * is the same in reverse. On-chain, the router is the withdrawer and the depositor, so the
 * two sides are linked to each other but not to the user. The anonymity set is whoever else
 * zaps through the router.
 *
 * ## Why the parameters cannot be tampered with
 *
 * Everything the router acts on is in `Withdrawal.data`, and the pool checks that the proof's
 * context equals `keccak256(abi.encode(withdrawal, SCOPE))`. So the vault, the minimum
 * output, the deadline, the relayer's fee and the rescue recipient are all fixed by the
 * user's proof. Anyone may submit it, which is what lets a relayer pay the gas, but nobody
 * can change what it does. A different vault or a lower minimum is a different context,
 * and the pool rejects the proof.
 *
 * ## The escape hatch
 *
 * The router is the pool's depositor of record for every zap, so only the router can
 * ragequit those notes. Without help, a user whose ASP approval lapsed would be stuck.
 * `rescue` gives the hatch back. It is routed by (pool, label), because the pool tracks
 * ragequit per label and a partial withdrawal leaves the remainder in a successor note with
 * the same label. The proceeds go to the recipient the user fixed in their proof when they
 * zapped, never to the caller, so a published proof cannot be front-run.
 */
contract ShieldedYieldRouter is ReentrancyGuard {
    using SafeERC20 for IERC20;

    address internal constant NATIVE_ASSET = ShieldedDepositLabel.NATIVE_ASSET;

    /// @notice What a zap does. ABI-encoded into `Withdrawal.data`, and so bound by the proof.
    struct Zap {
        /// Allowlisted ERC-4626 vault. Direction follows the source pool's asset: the vault's
        /// underlying (or ETH, for a WETH vault) goes in; the vault's shares come out.
        address vault;
        /// Precommitment for the note created on the other side.
        uint256 precommitment;
        /// Minimum shares (going in) or underlying (coming out), after the relayer's fee and
        /// before the destination pool's vetting fee.
        uint256 minOut;
        /// Coming out of a WETH vault: deposit into the native ETH pool instead of a WETH pool.
        bool nativeOut;
        /// Who a rescue of the new note pays. Fixed now, because the proof is public later.
        address rescueRecipient;
        /// Paid `relayFee` of the underlying asset for submitting the transaction.
        address relayer;
        uint256 relayFee;
        uint64 deadline;
    }

    IShieldedEntrypoint public immutable ENTRYPOINT;
    address public immutable WETH;

    address public governor;
    mapping(address => bool) public allowedVault;
    /// @notice pool => label => who a rescue pays.
    mapping(address => mapping(uint256 => address)) public rescueRecipient;

    event Zapped(
        address indexed fromPool,
        address indexed toPool,
        address indexed vault,
        uint256 amountIn,
        uint256 amountOut,
        uint256 label
    );
    event Rescued(address indexed pool, uint256 indexed label, address indexed recipient, uint256 amount);
    event VaultSet(address indexed vault, bool allowed);
    event GovernorTransferred(address indexed previous, address indexed next);

    error NotGovernor();
    error ZeroAddress();
    error WrongProcessooor();
    error Expired();
    error VaultNotAllowed();
    error UnknownPool();
    error AssetMismatch();
    error FeeExceedsAmount();
    error InsufficientOutput(uint256 out, uint256 minOut);
    error UnknownDeposit();
    error NotRecipient();
    error TransferFailed();

    modifier onlyGovernor() {
        if (msg.sender != governor) revert NotGovernor();
        _;
    }

    constructor(address entrypoint, address weth, address governor_) {
        if (entrypoint == address(0) || weth == address(0) || governor_ == address(0)) revert ZeroAddress();
        ENTRYPOINT = IShieldedEntrypoint(entrypoint);
        WETH = weth;
        governor = governor_;
    }

    /*//////////////////////////////////////////////////////////////
                                  ZAP
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Execute a zap proven by the user. Callable by anyone, typically a relayer.
     * @param fromPool The pool the proof withdraws from. Must be the Entrypoint's pool for its asset.
     * @return commitment The note created in the destination pool.
     */
    function zap(IShieldedPool fromPool, IShieldedPool.Withdrawal calldata w, IShieldedPool.WithdrawProof calldata p)
        external
        nonReentrant
        returns (uint256 commitment)
    {
        if (w.processooor != address(this)) revert WrongProcessooor();
        Zap memory z = abi.decode(w.data, (Zap));
        if (block.timestamp > z.deadline) revert Expired();
        if (!allowedVault[z.vault]) revert VaultNotAllowed();
        if (z.rescueRecipient == address(0)) revert ZeroAddress();

        address inAsset = fromPool.ASSET();
        // slither-disable-next-line unused-return
        (address registered,,,) = ENTRYPOINT.assetConfig(inAsset);
        if (registered != address(fromPool)) revert UnknownPool();

        // The pool verifies the proof, including that `w` is exactly what the user signed
        // into the context, and pays the router.
        // The delta is the point: only what this withdrawal paid in is acted on, never a
        // balance left over from before. `zap` and `rescue` are nonReentrant, and the pool
        // was just checked against the Entrypoint's registry.
        uint256 before = _balance(inAsset);
        // slither-disable-next-line reentrancy-balance
        fromPool.withdraw(w, p);
        uint256 received = _balance(inAsset) - before;

        // `out` is the vault's own return value, not a balance, so the "stale balance" slither
        // reports for the minOut check below does not exist.
        // slither-disable-next-line reentrancy-balance
        (address outAsset, uint256 out) =
            inAsset == z.vault ? _redeemShares(z, received) : _depositUnderlying(z, inAsset, received);
        if (out < z.minOut) revert InsufficientOutput(out, z.minOut);

        address toPool;
        uint256 label;
        (commitment, toPool, label) = _shield(outAsset, out, z);
        emit Zapped(address(fromPool), toPool, z.vault, received, out, label);
    }

    /// @notice The proof context a client must prove for `data` against `pool`.
    function context(address pool, bytes calldata data) external view returns (uint256) {
        IShieldedPool.Withdrawal memory w = IShieldedPool.Withdrawal({processooor: address(this), data: data});
        return uint256(keccak256(abi.encode(w, IShieldedPool(pool).SCOPE())))
            % ShieldedDepositLabel.SNARK_SCALAR_FIELD;
    }

    /// @notice Encode a zap for `Withdrawal.data`.
    function encodeZap(Zap calldata z) external pure returns (bytes memory) {
        return abi.encode(z);
    }

    function _depositUnderlying(Zap memory z, address inAsset, uint256 received)
        internal
        returns (address, uint256)
    {
        address underlying = IERC4626(z.vault).asset();
        bool nativeIn = inAsset == NATIVE_ASSET;
        if (nativeIn ? underlying != WETH : inAsset != underlying) revert AssetMismatch();

        uint256 amount = _payRelayer(inAsset, z, received);
        if (nativeIn) IWETH(WETH).deposit{value: amount}();
        IERC20(underlying).forceApprove(z.vault, amount);
        return (z.vault, IERC4626(z.vault).deposit(amount, address(this)));
    }

    function _redeemShares(Zap memory z, uint256 shares) internal returns (address, uint256) {
        address underlying = IERC4626(z.vault).asset();
        uint256 assets = IERC4626(z.vault).redeem(shares, address(this), address(this));
        assets = _payRelayer(underlying, z, assets);
        if (!z.nativeOut) return (underlying, assets);
        if (underlying != WETH) revert AssetMismatch();
        IWETH(WETH).withdraw(assets);
        return (NATIVE_ASSET, assets);
    }

    function _payRelayer(address asset, Zap memory z, uint256 amount) internal returns (uint256) {
        if (z.relayFee == 0) return amount;
        if (z.relayFee > amount) revert FeeExceedsAmount();
        if (z.relayer == address(0)) revert ZeroAddress();
        _send(asset, z.relayer, z.relayFee);
        return amount - z.relayFee;
    }

    /**
     * @dev Deposit into the destination pool and record who a rescue of that note pays.
     *      The deposit just bumped the pool's nonce, so its last label is this note's.
     */
    function _shield(address asset, uint256 amount, Zap memory z)
        internal
        returns (uint256 commitment, address pool, uint256 label)
    {
        if (asset == NATIVE_ASSET) {
            commitment = ENTRYPOINT.deposit{value: amount}(z.precommitment);
        } else {
            IERC20(asset).forceApprove(address(ENTRYPOINT), amount);
            commitment = ENTRYPOINT.deposit(IERC20(asset), amount, z.precommitment);
        }
        // slither-disable-next-line unused-return
        (pool,,,) = ENTRYPOINT.assetConfig(asset);
        label = ShieldedDepositLabel.lastLabel(pool);
        rescueRecipient[pool][label] = z.rescueRecipient;
    }

    /*//////////////////////////////////////////////////////////////
                              ESCAPE HATCH
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Ragequit a zapped note on its owner's behalf and pay the recipient fixed at zap time.
     * @param pool The pool holding the note.
     * @param proof A ragequit proof for any unspent commitment in the note's lineage.
     */
    function rescue(IShieldedPool pool, IShieldedPool.RagequitProof calldata proof)
        external
        nonReentrant
        returns (uint256 amount)
    {
        uint256 label = proof.pubSignals[3];
        address recipient = rescueRecipient[address(pool)][label];
        if (recipient == address(0)) revert UnknownDeposit();
        if (msg.sender != recipient) revert NotRecipient();

        address asset = pool.ASSET();
        uint256 before = _balance(asset);
        // slither-disable-next-line reentrancy-balance
        pool.ragequit(proof);
        amount = _balance(asset) - before;
        if (amount > 0) _send(asset, recipient, amount);
        emit Rescued(address(pool), label, recipient, amount);
    }

    /*//////////////////////////////////////////////////////////////
                               GOVERNANCE
    //////////////////////////////////////////////////////////////*/

    /// @notice List or delist a vault. Delisting stops new zaps in and out; rescues still work.
    function setVault(address vault, bool allowed) external onlyGovernor {
        if (vault == address(0)) revert ZeroAddress();
        allowedVault[vault] = allowed;
        emit VaultSet(vault, allowed);
    }

    function transferGovernor(address next) external onlyGovernor {
        if (next == address(0)) revert ZeroAddress();
        emit GovernorTransferred(governor, next);
        governor = next;
    }

    /*//////////////////////////////////////////////////////////////
                                 ASSETS
    //////////////////////////////////////////////////////////////*/

    function _balance(address asset) internal view returns (uint256) {
        return asset == NATIVE_ASSET ? address(this).balance : IERC20(asset).balanceOf(address(this));
    }

    /// @dev `to` is never the caller's choice: it is the relayer bound into the user's proof,
    ///      or the rescue recipient the user bound into their proof at zap time.
    function _send(address asset, address to, uint256 amount) internal {
        if (asset == NATIVE_ASSET) {
            // slither-disable-next-line arbitrary-send-eth,low-level-calls
            (bool ok,) = to.call{value: amount}("");
            if (!ok) revert TransferFailed();
        } else {
            IERC20(asset).safeTransfer(to, amount);
        }
    }

    /// @dev ETH arrives from the native pool on withdraw and ragequit, and from WETH on unwrap.
    ///      Every amount the router acts on is a balance delta within one call, so stray ETH
    ///      cannot be spent by a later zap. It just stays here.
    receive() external payable {}
}
