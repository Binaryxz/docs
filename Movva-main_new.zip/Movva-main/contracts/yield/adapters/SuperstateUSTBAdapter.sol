// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {IERC20Metadata} from "@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol";
import {IERC4626} from "@openzeppelin/contracts/interfaces/IERC4626.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {IYieldAdapter} from "../IYieldAdapter.sol";

/// @dev Superstate USTB (FundToken v1.3.0, proxy 0x43415eB6ff9DB7E26A15b704e7A3eDCe97d31C4e).
///      Signatures copied from the verified implementation 0xB3AC55dd09aA70e9BfBb12F45Cd38a1F1597588C
///      (etherscan.io/address/0xB3AC55dd09aA70e9BfBb12F45Cd38a1F1597588C#code).
interface IUSTB {
    function isAllowed(address addr) external view returns (bool);
    function paused() external view returns (bool);
    function isAccountingPaused() external view returns (bool);
    function superstateOracle() external view returns (address);
    function maximumOracleDelay() external view returns (uint256);
    /// @dev Returns `StablecoinConfig{address sweepDestination; uint96 fee}`, a static tuple, so it
    ///      decodes identically as two values.
    function supportedStablecoins(address stablecoin) external view returns (address sweepDestination, uint96 fee);
    /// @dev msg.sender pays `inAmount` (transferFrom to the sweep destination); msg.sender receives
    ///      USTB priced by `superstateOracle()`, less the stablecoin's fee. `_mint` checks the allowlist.
    function subscribe(uint256 inAmount, address stablecoin) external;
}

/// @dev Superstate RedemptionIdle (proxy 0x4c21B7577C8FE8b0B0669165ee7C8f67fa1454Cf), instant USTB -> USDC
///      from USDC it holds idle. Source: github.com/superstateinc/onchain-redemptions (src/RedemptionIdle.sol)
///      and the verified implementation 0x8EfbA8AF37Af48d2e0a04b0aAe60F0E9bC8dE007.
interface IUSTBRedemption {
    function SUPERSTATE_TOKEN() external view returns (address);
    function USDC() external view returns (address);
    /// @dev Immutable in RedemptionIdle: the SuperstateOracle below, which the token's owner cannot swap.
    function CHAINLINK_FEED_ADDRESS() external view returns (address);
    function MINIMUM_ACCEPTABLE_PRICE() external view returns (uint256);
    function redemptionFee() external view returns (uint256);
    function paused() external view returns (bool);
    /// @dev Rounds up, so redeeming the result pays at least `usdcOutAmount`.
    function calculateUstbIn(uint256 usdcOutAmount) external view returns (uint256 ustbInAmount, uint256 price);
    /// @dev The most USTB its USDC balance can pay for, rounded down.
    function maxUstbRedemptionAmount() external view returns (uint256 superstateTokenAmount, uint256 price);
    /// @dev Reverts InsufficientBalance when it holds less USDC than the payout; transferFrom(msg.sender)
    ///      requires msg.sender to be allowlisted.
    function redeem(address to, uint256 superstateTokenInAmount) external;
}

/// @dev SuperstateOracle 0xE4fA682f94610cCd170680cc3B045d77D9E528a8 (onchain-redemptions src/oracle/SuperstateOracle.sol).
///      `latestRoundData` extrapolates linearly from the two newest effective checkpoints and always
///      reports `updatedAt = block.timestamp`, so freshness has to be judged from the checkpoint itself.
interface ISuperstateNavOracle {
    function decimals() external view returns (uint8);
    function latestRoundData() external view returns (uint80, int256, uint256, uint256, uint80);
    function checkpoints(uint256 index) external view returns (uint64 timestamp, uint64 effectiveAt, uint128 navs);
}

/**
 * @title SuperstateUSTBAdapter
 * @notice Tokenized T-bills as a yield source (task 3.1): Superstate's USTB, subscribed and
 *         redeemed on-chain in USDC, valued from the NAV Superstate publishes on-chain.
 *
 * ## Why USTB (checked against mainnet at block 25,970,523)
 *
 *  - **Both directions are on-chain and atomic.** `USTB.subscribe` mints at NAV in the same call;
 *    `RedemptionIdle.redeem` pays USDC from a balance it holds (2.06M USDC at that block).
 *    BUIDL has no on-chain subscription and its Circle redemption facility reported zero liquidity;
 *    USYC's NAV reporter has no on-chain bounds; OUSG and USDY work, but need an Ondo ID, KYC
 *    registry entries, compliance and rate-limiter configuration per holder.
 *  - **Nobody on our side can push the NAV.** Only Superstate's oracle owner can add a checkpoint.
 *  - **Onboarding a contract is one issuer call** (`AllowlistV3.setProtocolAddressPermission`), and
 *    Superstate's docs say audited DeFi protocols may be added; RedemptionIdle itself is added that way.
 *
 * What it does not settle is **eligibility**: Superstate's getting-started page lists funds as
 * "only available to Qualified Purchasers in supported countries", and Brazil was not on that list.
 * Whether Superstate will allowlist a vault whose depositors are Brazilian users is a question for
 * Superstate, not for this code. Until it does, this adapter reports zero deposit capacity and says why.
 *
 * ## Valuation: the issuer's NAV, bounded by what a NAV can plausibly do
 *
 * The NAV comes from RedemptionIdle's own feed (`CHAINLINK_FEED_ADDRESS`, immutable there) - the
 * price the adapter would actually be paid at - rather than the token's `superstateOracle()`, which
 * the token owner can change. Three checks sit on top, because the issuer's contract enforces only
 * that a new checkpoint is within $1.00 of the last (about 9% of a $11 NAV):
 *
 *  - **Freshness**: the effective checkpoint must be younger than `maxNavAge`. `latestRoundData`
 *    always reports `updatedAt = now`, so its own age says nothing.
 *  - **Floor**: at least RedemptionIdle's `MINIMUM_ACCEPTABLE_PRICE` ($7), below which the issuer's
 *    own contracts refuse to price.
 *  - **Rate of change**: the NAV used is `min(oracle, ref)`, where `ref` may rise at most
 *    `maxNavGrowthBpsPerYear` since it was last recorded and never falls. A bad checkpoint that
 *    jumps the NAV cannot lift the vault's share price faster than that - the difference would
 *    otherwise be paid to whoever redeems first. A drop passes straight through, so a real loss
 *    reaches the share price (and the vault's drawdown breaker) at once, and a correction back up
 *    to `ref` is not throttled.
 *
 * When the NAV fails a check the adapter does what the Lido adapter does with a stale feed: it
 * values the position at the last trusted NAV less `staleHaircutBps`, refuses new subscriptions and
 * offers no instant exit. Views never revert.
 *
 * ## Exits
 *
 * `maxInstantWithdraw` is what can leave now: idle USDC, plus USTB only while it is actually
 * redeemable - token and redemption unpaused, the adapter allowlisted, a trusted NAV - and never
 * more than RedemptionIdle holds. So the vault's `maxWithdraw` reports the facility's liquidity
 * rather than the fund's size. `withdraw` never reverts because of the issuer: if redemption is
 * unavailable it returns what it has, and the vault decides whether that is enough.
 *
 * Being removed from the allowlist freezes the USTB leg, not the vault: holders can still take
 * everything else, and the USTB stays valued and redeemable the day the issuer restores access.
 */
contract SuperstateUSTBAdapter is IYieldAdapter, ReentrancyGuard {
    using SafeERC20 for IERC20;

    uint256 internal constant BPS = 10_000;
    /// @dev RedemptionIdle `_setRedemptionFee`: "Fee cannot exceed 10 basis points". Assumed when unreadable.
    uint256 internal constant MAX_ISSUER_FEE_BPS = 10;
    uint256 internal constant YEAR = 365 days;

    address public immutable override vault;
    /// @notice USDC.
    address public immutable override asset;
    IUSTB public immutable USTB;
    IUSTBRedemption public immutable REDEMPTION;
    ISuperstateNavOracle public immutable NAV_ORACLE;
    uint256 internal immutable NAV_SCALE;
    uint256 internal immutable USTB_SCALE;
    uint256 internal immutable ASSET_SCALE;
    uint256 public immutable MIN_NAV;

    uint256 public immutable maxNavAge;
    uint16 public immutable maxNavGrowthBpsPerYear;
    uint16 public immutable staleHaircutBps;
    uint16 public immutable maxEntryCostBps;

    /// @notice The rate-of-change reference: never decreases, rises at most at `maxNavGrowthBpsPerYear`.
    uint128 public navRef;
    uint64 public navRefAt;
    /// @notice The last NAV this adapter trusted, used (haircut) while the oracle cannot be.
    uint128 public lastGoodNav;

    event Subscribed(uint256 usdcIn, uint256 ustbOut, uint256 valueAdded);
    event Redeemed(uint256 ustbIn, uint256 usdcOut);
    event RedemptionUnavailable(bytes reason);
    event NavRecorded(uint256 oracleNav, uint256 ref);

    error NotVault();
    error ZeroAddress();
    error AssetMismatch();
    error BadParams();
    error OracleUnavailable();
    error DepositsBlocked(string reason);
    error EntryTooExpensive(uint256 valueAdded, uint256 assetsIn);

    modifier onlyVault() {
        if (msg.sender != vault) revert NotVault();
        _;
    }

    constructor(
        address vault_,
        IUSTB ustb_,
        IUSTBRedemption redemption_,
        uint256 maxNavAge_,
        uint16 maxNavGrowthBpsPerYear_,
        uint16 staleHaircutBps_,
        uint16 maxEntryCostBps_
    ) {
        if (vault_ == address(0) || address(ustb_) == address(0) || address(redemption_) == address(0)) {
            revert ZeroAddress();
        }
        address usdc = redemption_.USDC();
        if (redemption_.SUPERSTATE_TOKEN() != address(ustb_) || IERC4626(vault_).asset() != usdc) {
            revert AssetMismatch();
        }
        if (
            maxNavAge_ == 0 || maxNavGrowthBpsPerYear_ == 0 || staleHaircutBps_ >= BPS
                || maxEntryCostBps_ >= BPS
        ) revert BadParams();
        vault = vault_;
        asset = usdc;
        USTB = ustb_;
        REDEMPTION = redemption_;
        NAV_ORACLE = ISuperstateNavOracle(redemption_.CHAINLINK_FEED_ADDRESS());
        NAV_SCALE = 10 ** NAV_ORACLE.decimals();
        USTB_SCALE = 10 ** IERC20Metadata(address(ustb_)).decimals();
        ASSET_SCALE = 10 ** IERC20Metadata(usdc).decimals();
        MIN_NAV = redemption_.MINIMUM_ACCEPTABLE_PRICE();
        maxNavAge = maxNavAge_;
        maxNavGrowthBpsPerYear = maxNavGrowthBpsPerYear_;
        staleHaircutBps = staleHaircutBps_;
        maxEntryCostBps = maxEntryCostBps_;

        // Start the bound from a NAV that passes every check; an adapter born stale has no anchor.
        (bool ok, uint256 nav) = oracleNav();
        if (!ok) revert OracleUnavailable();
        navRef = uint128(nav);
        navRefAt = uint64(block.timestamp);
        lastGoodNav = uint128(nav);
    }

    function name() external pure returns (string memory) {
        return "Superstate USTB (tokenized T-bills)";
    }

    /*//////////////////////////////////////////////////////////////
                                   NAV
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice The issuer's NAV per USTB and whether it passes freshness and the floor.
     * @return ok False when the oracle reverts, the checkpoint is older than `maxNavAge`, or the
     *            NAV is below the issuer's own minimum.
     * @return nav The raw oracle NAV (feed decimals) when readable, else 0.
     */
    function oracleNav() public view returns (bool ok, uint256 nav) {
        // slither-disable-next-line unused-return
        try NAV_ORACLE.latestRoundData() returns (uint80 roundId, int256 answer, uint256, uint256, uint80) {
            if (answer <= 0) return (false, 0);
            nav = uint256(answer);
            // slither-disable-next-line unused-return
            try NAV_ORACLE.checkpoints(roundId) returns (uint64, uint64 effectiveAt, uint128) {
                ok = nav >= MIN_NAV && block.timestamp <= uint256(effectiveAt) + maxNavAge;
            } catch {
                ok = false;
            }
        } catch {
            return (false, 0);
        }
    }

    /// @notice The rate-of-change reference as it stands now: max(recorded, oracle), capped by growth.
    function boundedRef(uint256 oracleNav_) public view returns (uint256) {
        uint256 ref = navRef;
        uint256 ceiling = ref + (ref * maxNavGrowthBpsPerYear * (block.timestamp - navRefAt)) / (BPS * YEAR);
        uint256 r = oracleNav_ > ref ? oracleNav_ : ref;
        return r < ceiling ? r : ceiling;
    }

    /**
     * @notice The NAV this adapter values USTB at.
     * @return trusted Whether the oracle passed every check. When false, `nav` already carries the haircut.
     */
    function valuationNav() public view returns (bool trusted, uint256 nav) {
        (bool ok, uint256 o) = oracleNav();
        if (ok) {
            uint256 ref = boundedRef(o);
            return (true, o < ref ? o : ref);
        }
        uint256 last = lastGoodNav;
        if (o > 0 && o < last) last = o;
        return (false, (last * (BPS - staleHaircutBps)) / BPS);
    }

    /// @notice Record the current bound. Anyone may: the reference never falls and rises only at the capped rate.
    function poke() public {
        (bool ok, uint256 o) = oracleNav();
        if (!ok) return;
        uint256 ref = boundedRef(o);
        navRef = uint128(ref);
        navRefAt = uint64(block.timestamp);
        lastGoodNav = uint128(o < ref ? o : ref);
        emit NavRecorded(o, ref);
    }

    /*//////////////////////////////////////////////////////////////
                                VALUATION
    //////////////////////////////////////////////////////////////*/

    function _redemptionFeeBps() internal view returns (uint256) {
        try REDEMPTION.redemptionFee() returns (uint256 f) {
            return f > MAX_ISSUER_FEE_BPS ? MAX_ISSUER_FEE_BPS : f;
        } catch {
            return MAX_ISSUER_FEE_BPS;
        }
    }

    /// @dev USDC a USTB amount is worth at `nav`, after the redemption fee, rounded down.
    function _ustbValue(uint256 ustb, uint256 nav) internal view returns (uint256) {
        return (ustb * nav * ASSET_SCALE * (BPS - _redemptionFeeBps())) / (NAV_SCALE * USTB_SCALE * BPS);
    }

    function totalValue() external view returns (uint256) {
        (, uint256 nav) = valuationNav();
        return IERC20(asset).balanceOf(address(this)) + _ustbValue(IERC20(address(USTB)).balanceOf(address(this)), nav);
    }

    /// @notice Whether USTB can be redeemed right now, and if not, why.
    function redemptionBlocker() public view returns (string memory) {
        (bool ok,) = oracleNav();
        if (!ok) return "USTB NAV is stale, unreadable or below the issuer's floor";
        if (_readBool(address(USTB), IUSTB.paused.selector, true)) return "USTB is paused";
        if (_readBool(address(USTB), IUSTB.isAccountingPaused.selector, true)) return "USTB accounting is paused";
        if (_readBool(address(REDEMPTION), IUSTBRedemption.paused.selector, true)) return "USTB redemptions are paused";
        if (!_allowed(address(this))) return "adapter is not on the USTB allowlist";
        return "";
    }

    function maxInstantWithdraw() external view returns (uint256) {
        uint256 idle = IERC20(asset).balanceOf(address(this));
        if (bytes(redemptionBlocker()).length != 0) return idle;
        uint256 bal = IERC20(address(USTB)).balanceOf(address(this));
        (, uint256 nav) = valuationNav();
        uint256 value = _ustbValue(bal, nav);
        uint256 payable_ = _facilityPayout(bal);
        return idle + (value < payable_ ? value : payable_);
    }

    /**
     * @dev What redeeming as much of `bal` as the facility can fund would actually pay, computed the
     *      way RedemptionIdle computes it. Reporting the facility's raw USDC balance instead was
     *      wrong by the rounding of whole USTB units: the vault asked for exactly that much, got a
     *      few units less, and reverted the holder's withdrawal (caught by a unit test).
     */
    function _facilityPayout(uint256 bal) internal view returns (uint256) {
        // slither-disable-next-line unused-return
        try REDEMPTION.maxUstbRedemptionAmount() returns (uint256 m, uint256 price) {
            m = m > 0 ? m - 1 : 0;
            if (m > bal) m = bal;
            // One division rounds down at least as far as RedemptionIdle's two (floor the gross, then
            // subtract the floored fee), so this never reports more than the facility pays.
            return (m * price * ASSET_SCALE * (BPS - _redemptionFeeBps())) / (NAV_SCALE * USTB_SCALE * BPS);
        } catch {
            return 0;
        }
    }

    /// @notice Why a subscription would fail now; empty when it would not.
    function depositBlocker() public view returns (string memory) {
        if (!_allowed(address(this))) return "adapter is not on the USTB allowlist";
        (bool ok,) = oracleNav();
        if (!ok) return "USTB NAV is stale, unreadable or below the issuer's floor";
        if (_readBool(address(USTB), IUSTB.paused.selector, true)) return "USTB is paused";
        if (_readBool(address(USTB), IUSTB.isAccountingPaused.selector, true)) return "USTB accounting is paused";
        try USTB.superstateOracle() returns (address o) {
            if (o == address(0)) return "USTB on-chain subscriptions are disabled";
            // Subscriptions are priced by the token's oracle, which its owner can change; redemptions
            // and this adapter's valuation by RedemptionIdle's immutable one. Refuse if they diverge.
            if (o != address(NAV_ORACLE)) return "USTB subscriptions are priced by a different oracle than redemptions";
        } catch {
            return "USTB oracle unreadable";
        }
        try USTB.supportedStablecoins(asset) returns (address sweep, uint96 fee) {
            if (sweep == address(0)) return "USTB does not accept this stablecoin";
            if (fee + _redemptionFeeBps() > maxEntryCostBps) return "USTB fees exceed the adapter's maximum entry cost";
        } catch {
            return "USTB stablecoin config unreadable";
        }
        return "";
    }

    /// @notice How much the adapter would subscribe right now: unbounded, or zero with `depositBlocker` saying why.
    function maxDeposit() external view returns (uint256) {
        return bytes(depositBlocker()).length == 0 ? type(uint256).max : 0;
    }

    function _allowed(address who) internal view returns (bool) {
        try USTB.isAllowed(who) returns (bool a) {
            return a;
        } catch {
            return false;
        }
    }

    /// @dev A boolean view, or `fallback_` when it reverts or returns garbage: views here never revert.
    function _readBool(address target, bytes4 selector, bool fallback_) internal view returns (bool) {
        (bool ok, bytes memory ret) = target.staticcall(abi.encodeWithSelector(selector));
        if (!ok || ret.length < 32) return fallback_;
        return abi.decode(ret, (bool));
    }

    /*//////////////////////////////////////////////////////////////
                               VAULT CALLS
    //////////////////////////////////////////////////////////////*/

    function deposit(uint256 assets) external onlyVault nonReentrant returns (uint256 valueAdded) {
        poke();
        string memory why = depositBlocker();
        if (bytes(why).length != 0) revert DepositsBlocked(why);

        IERC20 usdc = IERC20(asset);
        IERC20 ustb = IERC20(address(USTB));
        uint256 before = ustb.balanceOf(address(this));
        usdc.forceApprove(address(USTB), assets);
        // USTB is the issuer's contract fixed at construction, deposit is vault-only and nonReentrant,
        // and the balance delta across this call is exactly what the check below must measure.
        // slither-disable-next-line reentrancy-balance
        USTB.subscribe(assets, asset);
        uint256 got = ustb.balanceOf(address(this)) - before;

        // Checked against the redemption NAV, not the subscription price: a swapped or wrong token
        // oracle that mints too few USTB shows up here, whatever the token's own math believed.
        (, uint256 nav) = valuationNav();
        valueAdded = _ustbValue(got, nav);
        if (valueAdded * BPS < assets * (BPS - maxEntryCostBps)) revert EntryTooExpensive(valueAdded, assets);
        emit Subscribed(assets, got, valueAdded);
    }

    function withdraw(uint256 assets, address to) external onlyVault nonReentrant returns (uint256 sent) {
        poke();
        IERC20 usdc = IERC20(asset);
        uint256 have = usdc.balanceOf(address(this));

        if (have < assets && bytes(redemptionBlocker()).length == 0) {
            uint256 need = assets - have;
            uint256 facility = usdc.balanceOf(address(REDEMPTION));
            if (need > facility) need = facility;
            uint256 bal = IERC20(address(USTB)).balanceOf(address(this));
            uint256 ustbIn = 0;
            if (need > 0 && bal > 0) {
                ustbIn = bal;
                // calculateUstbIn rounds up, which is right for "at least `need`" and wrong at the
                // facility's edge: asking for exactly what it holds overshoots by a few units and the
                // whole redemption reverts. So also cap by the facility's own rounded-down maximum,
                // less one unit for its fee rounding. If either cannot price, nothing is redeemed.
                // slither-disable-next-line unused-return
                try REDEMPTION.calculateUstbIn(need) returns (uint256 x, uint256) {
                    if (x < ustbIn) ustbIn = x;
                } catch {
                    ustbIn = 0;
                }
                // slither-disable-next-line unused-return
                try REDEMPTION.maxUstbRedemptionAmount() returns (uint256 m, uint256) {
                    m = m > 0 ? m - 1 : 0;
                    if (m < ustbIn) ustbIn = m;
                } catch {
                    ustbIn = 0;
                }
            }
            if (ustbIn > 0) {
                IERC20(address(USTB)).forceApprove(address(REDEMPTION), ustbIn);
                uint256 beforeUsdc = usdc.balanceOf(address(this));
                // The issuer can pause, de-allowlist or drain the facility between the checks above
                // and this call. None of that may revert a holder's exit: take what redeems, report the rest.
                try REDEMPTION.redeem(address(this), ustbIn) {
                    emit Redeemed(ustbIn, usdc.balanceOf(address(this)) - beforeUsdc);
                } catch (bytes memory reason) {
                    emit RedemptionUnavailable(reason);
                }
                IERC20(address(USTB)).forceApprove(address(REDEMPTION), 0);
            }
            have = usdc.balanceOf(address(this));
        }

        sent = have < assets ? have : assets;
        if (sent > 0) usdc.safeTransfer(to, sent);
    }

    /// @dev USTB accrues in its NAV; there is nothing to claim. Recording the NAV bound is still useful.
    function harvest() external onlyVault returns (uint256) {
        poke();
        return 0;
    }
}
