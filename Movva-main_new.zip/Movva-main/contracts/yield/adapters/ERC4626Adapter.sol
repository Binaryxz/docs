// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {IERC4626} from "@openzeppelin/contracts/interfaces/IERC4626.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {IYieldAdapter} from "../IYieldAdapter.sol";

/**
 * @title ERC4626Adapter
 * @notice Any permissionless ERC-4626 yield vault as a yield source (task 3.1).
 *
 * Fork-tested against two targets:
 *
 *  - **Sky's sUSDS** (the Sky Savings Rate) behind a USDS vault, `YieldFork.t.sol`. sUSDS is a
 *    savings rate rather than a tokenized T-bill fund, though its reserves include T-bill positions.
 *  - **Aave v3's "Wrapped Aave Ethereum USDT"** (StataTokenV2, 0x7Bc3485026Ac48b6cf9BaF0A377477Fff5703Af8)
 *    behind a USDT vault, `AaveUSDTFork.t.sol`: real interest, the supply cap, borrowed-out
 *    liquidity, a frozen and a paused reserve, the wrapper's own pause, and USDT's fee switch,
 *    blacklist and pause.
 *
 * The tokenized T-bill funds that are actual T-bill products were checked against mainnet
 * when this was written, and the results decide what can plug in here:
 *
 *  - Ondo OUSG requires KYC. An unregistered contract reports `getKYCStatus == false`, so
 *    a vault could not hold it without Ondo onboarding the vault as an investor.
 *  - Ondo USDY accepted a simulated transfer into an unregistered contract. It keeps a
 *    blocklist and a sanctions list, though, so Ondo can freeze a contract - and a shielded
 *    pool holding USDY would be frozen for every depositor at once.
 *  - BlackRock BUIDL could not be tested; Securitize tokens are generally restricted to
 *    registered investor wallets.
 *
 * So this adapter takes permissionless vaults. A permissioned T-bill fund needs its own adapter,
 * and the issuer's allowlisting on top: `SuperstateUSTBAdapter` is that adapter for Superstate's
 * USTB, chosen after the same comparison was repeated on 2026-09-13.
 *
 * ## What the Aave wrapper changed here
 *
 * A generic adapter is only as honest as its target's ERC-4626 views. The Aave wrapper's views are
 * honest about Aave, but not about the wrapper itself:
 *
 *  - **The wrapper has its own pause**, which any Aave emergency admin can set (`setPaused`). Its
 *    `maxWithdraw` and `maxDeposit` check the reserve's pause and freeze flags, but not the wrapper's
 *    own `paused()`, so they keep promising liquidity that `withdraw` refuses. Passed straight
 *    through, the vault's `maxWithdraw` would make the same promise, and a holder who withdrew that
 *    much would see the whole call revert inside this adapter. So this adapter probes an optional
 *    `paused()` on the target and reports nothing liquid while it returns true. `withdraw` never
 *    reverts because the target refused: it returns what it sent.
 *  - **Withdrawals pay the vault directly** (`TARGET.withdraw(assets, to, this)`). The first version
 *    pulled into the adapter and then transferred on. With USDT, that makes the adapter one more
 *    address Tether can blacklist, and a blacklisted address can receive USDT but not send it: the
 *    whole Aave leg would freeze. Paid directly, a blacklisted adapter cannot stop an exit, only new
 *    allocations. It is also one USDT transfer fewer if Tether ever switches its fee on.
 *  - **Capacity belongs to the target.** Aave refuses a supply over the reserve's cap, and refuses
 *    all supply while the reserve is frozen or paused. The vault cannot see that, so this adapter
 *    exposes the optional keeper views `maxDeposit()` and `depositBlocker()` (see `IYieldAdapter`),
 *    and the keeper does not plan an allocation the source will refuse.
 *
 * What remains, each with a fork test: exits beyond Aave's available liquidity wait for borrowers
 * to repay, and the vault's `maxWithdraw` says so up front; a frozen reserve still pays out; a paused
 * reserve or wrapper freezes only this leg, which stays valued. A blacklisted VAULT is frozen by
 * Tether whatever any adapter does. Aave losses reach the wrapper's price only through the liquidity
 * index. A reserve deficit, Aave's bad-debt ledger, does not move it.
 */
contract ERC4626Adapter is IYieldAdapter {
    using SafeERC20 for IERC20;

    IERC4626 public immutable TARGET;
    address public immutable override vault;
    address public immutable override asset;
    string private _name;

    /// @notice The target refused a withdrawal its own views allowed; the vault got nothing from it.
    event TargetWithdrawFailed(uint256 assets, bytes reason);

    error NotVault();
    error AssetMismatch();
    error ZeroAddress();

    modifier onlyVault() {
        if (msg.sender != vault) revert NotVault();
        _;
    }

    constructor(address vault_, IERC4626 target_, string memory name_) {
        if (vault_ == address(0) || address(target_) == address(0)) revert ZeroAddress();
        vault = vault_;
        TARGET = target_;
        asset = target_.asset();
        if (IERC4626(vault_).asset() != asset) revert AssetMismatch();
        _name = name_;
    }

    function name() external view returns (string memory) {
        return _name;
    }

    /// @dev previewRedeem rounds down, which is the conservative direction. A pause does not
    ///      change what the position is worth, so it is not reflected here.
    function totalValue() public view returns (uint256) {
        return TARGET.previewRedeem(TARGET.balanceOf(address(this)))
            + IERC20(asset).balanceOf(address(this));
    }

    /// @notice Idle asset, plus what the target says it would pay now: nothing from it while paused.
    function maxInstantWithdraw() external view returns (uint256 max) {
        max = IERC20(asset).balanceOf(address(this));
        if (!targetPaused()) max += TARGET.maxWithdraw(address(this));
    }

    /**
     * @notice True when the target exposes `paused()` and it returns true.
     * @dev Optional on the target, so it is read with a staticcall. A target without the function
     *      (sUSDS) reverts or returns nothing, and counts as not paused. The answer is decoded as a
     *      word rather than a bool, so a malformed one cannot make this view revert.
     */
    function targetPaused() public view returns (bool) {
        // slither-disable-next-line low-level-calls
        (bool ok, bytes memory ret) = address(TARGET).staticcall(abi.encodeWithSignature("paused()"));
        return ok && ret.length >= 32 && abi.decode(ret, (uint256)) != 0;
    }

    /*//////////////////////////////////////////////////////////////
                      OPTIONAL VIEWS THE KEEPER READS
    //////////////////////////////////////////////////////////////*/

    /// @notice The most the target would accept from this adapter now, and zero while it is paused.
    ///         For the Aave wrapper: the reserve's remaining supply cap, or zero while the reserve is
    ///         frozen or paused.
    function maxDeposit() public view returns (uint256) {
        if (targetPaused()) return 0;
        try TARGET.maxDeposit(address(this)) returns (uint256 m) {
            return m;
        } catch {
            return 0;
        }
    }

    /// @notice Why `maxDeposit()` is zero; empty when it is not.
    function depositBlocker() external view returns (string memory) {
        if (targetPaused()) return "target vault is paused";
        if (maxDeposit() == 0) return "target vault accepts no deposits (at its supply cap, frozen or paused)";
        return "";
    }

    /*//////////////////////////////////////////////////////////////
                                 FUNDS
    //////////////////////////////////////////////////////////////*/

    /// @dev forceApprove: USDT reverts an approval from one non-zero allowance to another.
    function deposit(uint256 assets) external onlyVault returns (uint256) {
        IERC20(asset).forceApprove(address(TARGET), assets);
        // Shares minted are not needed: totalValue reads the share balance directly.
        // slither-disable-next-line unused-return
        TARGET.deposit(assets, address(this));
        return assets;
    }

    /**
     * @notice Send up to `assets` to `to`: from the target first, paid to `to` directly, then from
     *         any idle balance held here.
     * @dev Never reverts because the target refused, whether from a pause its views do not report or
     *      liquidity borrowed out between the view and the call. The vault re-reads its own balance
     *      and decides whether what arrived is enough. `sent` is what was sent, not what arrived: a
     *      token with a transfer fee delivers less, and the vault's re-read catches that as well.
     */
    function withdraw(uint256 assets, address to) external onlyVault returns (uint256 sent) {
        if (!targetPaused()) {
            uint256 avail = TARGET.maxWithdraw(address(this));
            uint256 take = assets < avail ? assets : avail;
            if (take > 0) {
                // Shares burned are not needed: the vault re-reads what arrived.
                // slither-disable-next-line unused-return
                try TARGET.withdraw(take, to, address(this)) returns (uint256) {
                    sent = take;
                } catch (bytes memory reason) {
                    emit TargetWithdrawFailed(take, reason);
                }
            }
        }
        if (sent < assets) {
            uint256 idle = IERC20(asset).balanceOf(address(this));
            uint256 more = assets - sent < idle ? assets - sent : idle;
            if (more > 0) {
                sent += more;
                IERC20(asset).safeTransfer(to, more);
            }
        }
    }

    /// @dev Vaults that compound in their share price (sUSDS, the Aave wrapper) have nothing to
    ///      harvest. The Aave USDT wrapper's `rewardTokens()` was empty on 2026-09-14.
    function harvest() external view onlyVault returns (uint256) {
        return 0;
    }
}
