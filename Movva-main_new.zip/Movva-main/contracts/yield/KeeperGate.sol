// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IYieldAdapter} from "./IYieldAdapter.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";

/// @dev The part of YieldVault the keeper role can reach, plus the two views the gate needs.
interface IKeeperVault {
    function allocate(IYieldAdapter adapter, uint256 assets) external;
    function deallocate(IYieldAdapter adapter, uint256 assets) external;
    function harvest(IYieldAdapter adapter) external;
    function totalAssets() external view returns (uint256);
    function guardian() external view returns (address);
}

/**
 * @title KeeperGate
 * @notice The vault's keeper, as a contract, so a keeper can run replicated on machines nobody
 *         vetted without one key being every replica's key.
 *
 * ## Why the keeper is not an EOA
 *
 * `YieldVault` has exactly one `keeper` address. Running the keeper service on Flux with that
 * address as an EOA means the key sits in the environment of every replica, readable by every
 * node operator, and every replica races the others on one nonce. The keeper cannot take funds
 * - `allocate` only pays listed adapters, `deallocate` and `harvest` only pay the vault - but
 * it can still cost holders money: every deallocation from the Lido adapter sells on Curve
 * within `maxSlippageBps`, and nothing on the vault limits how often. A leaked key could churn
 * allocate/deallocate all day and burn up to that slippage on every round trip.
 *
 * This contract is set as the vault's keeper instead. It holds no funds and has no function
 * that moves tokens; it forwards the three keeper calls, and adds what the vault lacks:
 *
 *  - **one key per replica.** Each instance gets its own operator address. Revoking one is
 *    instant, by the governor or by the vault's guardian, and does not touch the others.
 *  - **a turnover budget.** `allocate` and `deallocate` together may move at most
 *    `maxTurnoverBps` of the vault's assets per `WINDOW`. That bounds what a compromised
 *    operator can burn in slippage per day, whatever it does: see "Worst case" below.
 *
 * `harvest` is not budgeted: an adapter's harvest pays only the vault, and moves no principal.
 *
 * ## Worst case
 *
 * With every operator key compromised at once, in any 24 hours the attacker can move at most
 * 2 x `maxTurnoverBps` of total assets (a full window's budget either side of a window
 * boundary), and each unit moved costs at most the worst exit cost of the adapter it leaves -
 * `maxSlippageBps` for Lido, zero for sUSDS, the issuer's redemption fee for a T-bill fund. At
 * a 10% budget and Lido's 50 bps that is 0.1% of the vault per day, until the guardian revokes
 * the keys, which is one transaction. It cannot move anything to itself.
 *
 * ## What waits
 *
 * Adding an operator is equivalent to handing out the keeper role, which the vault delays
 * (SR3-4), so it waits out `GOVERNANCE_DELAY` here too. Raising the budget waits. Revoking an
 * operator and lowering the budget are instant. No keeper call is forwarded before
 * `completeSetup()`: otherwise a gate left in setup would keep instant operator changes behind a
 * vault whose own keeper change had been delayed, and the delay would protect nobody.
 */
contract KeeperGate is DelayedGovernance {
    uint16 public constant BPS = 10_000;
    /// @notice The budget window. Fixed windows rather than rolling: simpler to reason about on
    ///         a block explorer, and the worst case (two budgets across a boundary) is stated.
    uint256 public constant WINDOW = 1 days;

    IKeeperVault public immutable VAULT;

    mapping(address => bool) public isOperator;
    uint16 public maxTurnoverBps;
    uint64 public windowStart;
    uint256 public windowUsed;

    event OperatorSet(address indexed operator, bool allowed, address indexed by);
    event MaxTurnoverSet(uint16 bps);
    event Forwarded(bytes4 indexed selector, address indexed operator, address indexed adapter, uint256 assets);

    error NotOperator();
    error BadBps();
    error TurnoverBudgetExceeded(uint256 wanted, uint256 remaining);

    modifier onlyOperator() {
        if (!isOperator[msg.sender]) revert NotOperator();
        _;
    }

    constructor(IKeeperVault vault_, address governor_, uint256 governanceDelay, uint16 maxTurnoverBps_)
        DelayedGovernance(governor_, governanceDelay)
    {
        if (address(vault_) == address(0)) revert ZeroAddress();
        if (maxTurnoverBps_ == 0 || maxTurnoverBps_ > BPS) revert BadBps();
        VAULT = vault_;
        maxTurnoverBps = maxTurnoverBps_;
    }

    /*//////////////////////////////////////////////////////////////
                               KEEPER CALLS
    //////////////////////////////////////////////////////////////*/

    function allocate(IYieldAdapter adapter, uint256 assets) external onlyOperator {
        _requireSetupComplete();
        _consume(assets);
        VAULT.allocate(adapter, assets);
        emit Forwarded(this.allocate.selector, msg.sender, address(adapter), assets);
    }

    function deallocate(IYieldAdapter adapter, uint256 assets) external onlyOperator {
        _requireSetupComplete();
        _consume(assets);
        VAULT.deallocate(adapter, assets);
        emit Forwarded(this.deallocate.selector, msg.sender, address(adapter), assets);
    }

    function harvest(IYieldAdapter adapter) external onlyOperator {
        _requireSetupComplete();
        VAULT.harvest(adapter);
        emit Forwarded(this.harvest.selector, msg.sender, address(adapter), 0);
    }

    /// @notice What operators may still move in the current window.
    function remainingTurnover() public view returns (uint256) {
        uint256 budget = (VAULT.totalAssets() * maxTurnoverBps) / BPS;
        uint256 used = block.timestamp >= uint256(windowStart) + WINDOW ? 0 : windowUsed;
        return used >= budget ? 0 : budget - used;
    }

    /// @dev Charged before the call, on the amount requested: an adapter may return less than
    ///      asked, but a request is what an attacker controls.
    function _consume(uint256 assets) internal {
        uint256 remaining = remainingTurnover();
        if (assets > remaining) revert TurnoverBudgetExceeded(assets, remaining);
        if (block.timestamp >= uint256(windowStart) + WINDOW) {
            windowStart = uint64(block.timestamp);
            windowUsed = 0;
        }
        windowUsed += assets;
    }

    /*//////////////////////////////////////////////////////////////
                               GOVERNANCE
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Adding an operator waits out the delay; revoking is instant.
     * @dev The vault's guardian may revoke too, without the governor: a leaked replica key is
     *      incident response, and the guardian is who is awake for incidents.
     */
    function setOperator(address operator, bool allowed) external {
        if (!(msg.sender == VAULT.guardian() && !allowed)) {
            _authorizeChange(allowed && !isOperator[operator]);
        }
        if (operator == address(0)) revert ZeroAddress();
        isOperator[operator] = allowed;
        emit OperatorSet(operator, allowed, msg.sender);
    }

    /// @notice Raising the budget waits out the delay; lowering it is instant.
    function setMaxTurnover(uint16 bps) external {
        _authorizeChange(bps > maxTurnoverBps);
        if (bps == 0 || bps > BPS) revert BadBps();
        maxTurnoverBps = bps;
        emit MaxTurnoverSet(bps);
    }

    function _isDelayable(bytes4 selector) internal pure override returns (bool) {
        return selector == KeeperGate.setOperator.selector || selector == KeeperGate.setMaxTurnover.selector;
    }
}
