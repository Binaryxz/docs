// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/**
 * @title IYieldAdapter
 * @notice One source of yield behind the shielded yield vault (task 3.1).
 *
 * The vault never talks to Lido, Sky or a T-bill issuer directly. Each source sits behind
 * this interface, so adding one is a governed deployment rather than a change to the
 * contract that holds everyone's shares.
 *
 * ## Two rules every adapter must keep
 *
 * **`totalValue()` must be conservative.** It is summed into the vault's share price, and
 * every deposit and withdrawal is priced from it. An adapter that reports its best case -
 * stETH at 1:1 during a depeg, a T-bill at par before settlement - lets early withdrawers
 * leave at that price and hands the difference to whoever stays. Value at the lower of the
 * redemption rate and the market, and haircut anything whose price cannot be checked.
 *
 * **Views must not revert.** `totalValue()` and `maxInstantWithdraw()` sit inside the
 * vault's `totalAssets()`, which every ERC-4626 entry point calls. If an oracle an adapter
 * depends on is deprecated and starts reverting, a reverting view would freeze every share
 * in the vault, including withdrawals of value held elsewhere. Degrade to a pessimistic
 * value instead.
 *
 * ## Optional views the keeper reads
 *
 * An adapter whose source can refuse deposits - a permissioned fund that has not allowlisted
 * the vault, a paused issuer, a lending market at its supply cap - may also expose
 * `maxDeposit() returns (uint256)` and `depositBlocker() returns (string)`. The vault does not
 * call them; the keeper service does, so it does not plan an allocation the source will refuse
 * (`SuperstateUSTBAdapter`, `ERC4626Adapter`). The keeper stays `capHeadroomBps` below the stated
 * figure, because a source can state more room than it will take: Aave's USDT wrapper does, by
 * the treasury interest Aave books before it checks the cap (`AaveUSDTFork.t.sol`). The views are
 * not part of this interface, so existing adapters keep their ABI.
 */
interface IYieldAdapter {
    /// @notice The token this adapter accepts and returns. Must equal the vault's asset.
    function asset() external view returns (address);

    /// @notice The only address allowed to move funds through this adapter.
    function vault() external view returns (address);

    /// @notice Conservative value of everything the adapter holds, in `asset` units.
    function totalValue() external view returns (uint256);

    /// @notice How much `asset` could be returned right now, without a queue.
    function maxInstantWithdraw() external view returns (uint256);

    /**
     * @notice Put `assets` to work. The vault transfers them to the adapter first.
     * @return valueAdded Conservative value added to `totalValue()`.
     */
    function deposit(uint256 assets) external returns (uint256 valueAdded);

    /**
     * @notice Return up to `assets` to `to`, instantly.
     * @return assetsOut What was actually sent; may be less than asked.
     */
    function withdraw(uint256 assets, address to) external returns (uint256 assetsOut);

    /**
     * @notice Convert any separately-paid rewards into `asset` and send them to the vault.
     * @dev Sources that compound in their own share price (wstETH, sUSDS) return 0.
     */
    function harvest() external returns (uint256 assetsOut);

    function name() external view returns (string memory);
}
