// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {IERC20Metadata} from "@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";
import {IHedgeVenue, IHedgePriceFeed} from "./IHedgeVenue.sol";

/**
 * @title HedgeSubWallet
 * @notice One segregated yield sub-wallet of the reserve's delta-neutral hedge sleeve (task B2), for
 *         ONE asset on ONE venue, with a trade-only keeper (task B3). Long spot, short the same size
 *         of the perp; price moves cancel and what is left is funding, less fees. The yield is Mova's:
 *         it returns to MovvaReserve by `recapitalize` (docs/delta-neutral.md §12).
 *
 * ## Venue-neutral
 *
 * The venue is reached only through `IHedgeVenue`, fixed at deployment. The venue is not chosen;
 * on Sepolia it is `SimHedgeVenue`, a simulator. A real venue gets an `IHedgeVenue` adapter and a
 * new sub-wallet; nothing here changes. `HyperCoreDeltaNeutralVault` is the same design specialised
 * to one venue; this contract keeps its rules (a keeper that chooses when, never what; exits that do
 * not need the keeper) and removes every venue assumption.
 *
 * ## Where money can go
 *
 * `TREASURY` - the hedge 2-of-3 Safe, the reserve's `hedgeTreasury` - is immutable and is the ONLY
 * address funds ever leave the sleeve to. The stablecoin moves between three places and no others:
 * this contract's own balance, its account on `VENUE` (also immutable), and `TREASURY`. There is no
 * function that takes a recipient, no arbitrary call, and no way to change the treasury or the venue.
 *
 *  - `fund(amount)` (treasury): the treasury's stablecoin in.
 *  - `withdrawToTreasury(amount)` (treasury): idle stablecoin, then venue cash, then perp margin above
 *    what `maxLeverageBps` needs, to the treasury. Never below that margin: unwind first.
 *  - `unwind(sellLimitPx, buyLimitPx)` (treasury): close both legs at the treasury's own limits and
 *    bring every free dollar back here, without the keeper or the reference feed.
 *
 * ## The keeper chooses when, never what
 *
 * The keeper may call `rebalance()` and `harvest()`, both argument-free. Every order is computed here
 * from venue reads and bounded here:
 *
 *  - sizes come from `targetLeverageBps` and the sub-wallet's own value capped at `allocationCap`;
 *  - each order is at most `maxOrderNotional`, at most two per call (one per leg), and all keeper
 *    orders together at most `maxWindowTurnover` per `WINDOW`;
 *  - every order is an IOC limit `slippageBps` through an INDEPENDENT reference price
 *    (`REFERENCE`, a Chainlink-style feed), not the venue's own; and nothing trades unless the venue's
 *    mark, index and spot are each within `priceBandBps` of that reference and both are fresh;
 *  - leverage is never raised past `maxLeverageBps`, and delta is brought back within
 *    `deltaToleranceBps`, never by buying spot (that would grow the book, not hedge it);
 *  - funding is an exponential average of the venue's reported rate: below `fundingPauseE8` nothing
 *    is added, below `fundingExitE8` the book is unwound.
 *
 * The keeper cannot withdraw, cannot pick a size, price or direction, and cannot send funds anywhere:
 * `rebalance` moves stablecoin only from this contract to the venue, by what the step it computed
 * needs, and `harvest` only from the venue back here.
 *
 * Worst case for a compromised keeper per window, colluding with the venue: `maxWindowTurnover` of
 * notional filled at the edge of the band, each dollar losing `slippageBps` (fills are all-in,
 * `IHedgeVenue`, so the limit bounds the fee too); a fixed window allows twice that across a boundary.
 * `HedgeSubWalletTest` measures it. `deleverage` is open to anyone and not charged to
 * the window, but it only ever reduces a book that is over `maxLeverageBps`, so a churn it causes must
 * be rebuilt by the keeper's budgeted calls. The guardian ends all of it with `pauseExposure()`, and
 * the governor revokes the keeper at once with `setKeeper(address(0))`.
 *
 * ## Exits with the keeper offline
 *
 * Nothing that brings money home needs the keeper: `deleverage()` (anyone) protects the margin in a
 * rally; the treasury can `unwind` at its own limits and `withdrawToTreasury`. The treasury owns the
 * funds - it is where they are allowed to go - so letting it choose an exit price adds no risk.
 *
 * ## Paired legs fill together
 *
 * A step that trades both legs (`_addExposure`: buy spot and open short; `_reduceBoth`: close short
 * and sell spot) reads each leg's fill and reverts the whole step when their unfilled remainders
 * differ by more than `deltaToleranceBps` of the pair. A venue that fills one leg and not the other -
 * a partial fill, an empty book, a lying adapter - cannot leave the book unhedged: nothing happens.
 *
 * ## Governance
 *
 * `setParams` waits out `GOVERNANCE_DELAY` when any field loosens a bound (`riskier`), and also when
 * any field the backstop and the exits trade through changes at all: `slippageBps`, `priceBandBps`,
 * `maxReferenceAge` and `maxOrderNotional`. Tightening those is not "safer": a 1 bps band, a 60 s
 * reference age or a one-dollar order cap would quietly disable `deleverage()`. `_validate` also
 * floors them (`slippageBps` >= 10, `priceBandBps` >= `slippageBps` + 20, `maxReferenceAge` >= 1 h)
 * and caps `minActionInterval` at a day, so even a governor who waits cannot switch the backstop
 * off. Every other tightening is instant, as on `HyperCoreDeltaNeutralVault`.
 *
 * A new keeper waits; revoking it is instant. The guardian (instant) can only pause. `resume()` is
 * delayed too, and a pause always stands for at least `GOVERNANCE_DELAY`: on Sepolia one key is
 * keeper and governor, and an instant resume would let that key undo the guardian's pause at once.
 * Pausing only holds or unwinds the book under the keeper's bounds, so waiting to lift it costs
 * forgone funding, never principal.
 */
contract HedgeSubWallet is ReentrancyGuard, DelayedGovernance {
    using SafeERC20 for IERC20;

    struct Params {
        /// Short notional over margin equity at target, bps (20_000 = 2x).
        uint16 targetLeverageBps;
        /// Never added past; above it anyone may `deleverage`. At most half the venue's maximum.
        uint16 maxLeverageBps;
        /// |spot - short| tolerated, bps of the larger leg.
        uint16 deltaToleranceBps;
        /// Each order's limit, bps through the reference price.
        uint16 slippageBps;
        /// The venue's mark, index and spot must each be within this of the reference to trade.
        uint16 priceBandBps;
        /// Hourly funding average (1e8 = 100%) below which nothing is added.
        int32 fundingPauseE8;
        /// Below this the book is unwound.
        int32 fundingExitE8;
        /// Time constant of the funding average, seconds.
        uint32 fundingTau;
        /// Seconds between keeper calls.
        uint32 minActionInterval;
        /// Oldest reference (and venue) price anything trades on, seconds.
        uint32 maxReferenceAge;
        /// Stablecoin units per order.
        uint64 maxOrderNotional;
        /// Stablecoin units of keeper-placed notional per WINDOW.
        uint64 maxWindowTurnover;
        /// Most of the sub-wallet's value the keeper may deploy, stablecoin units.
        uint64 allocationCap;
    }

    /// @dev Everything a step decides from, read at once. Quantities WAD, prices WAD USD, money in
    ///      stablecoin units.
    struct Book {
        uint256 ref;
        uint256 mark;
        uint256 index;
        uint256 spotPx;
        uint256 spotQty;
        uint256 shortQty;
        uint256 longQty;
        int256 equity;
        uint256 withdrawable;
        uint256 venueCash;
        uint256 idle;
        /// Short notional at the reference, and at the higher of mark and reference (leverage).
        uint256 shortN;
        uint256 levN;
        uint256 spotN;
        uint256 nav;
    }

    enum Kind {
        BuySpot,
        SellSpot,
        OpenShort,
        CloseShort,
        CloseLong
    }

    struct Plan {
        uint256 target;
        uint256 tol;
        bool mayAdd;
    }

    uint256 internal constant BPS = 10_000;
    uint256 internal constant WAD = 1e18;
    /// @notice The turnover window. Fixed, not rolling, as on KeeperGate: the worst case across a
    ///         boundary (two budgets) is stated rather than hidden.
    uint256 public constant WINDOW = 1 days;
    /// @dev A venue-reported rate past 1%/hour is a broken venue, not funding: clamp the sample.
    int256 internal constant MAX_SAMPLE = 1e16;
    /// @notice Hard bounds `_validate` applies to what the `deleverage` backstop and exits trade through.
    uint256 public constant MIN_SLIPPAGE_BPS = 10;
    /// @notice `priceBandBps` must clear `slippageBps` by at least this: room for the venue's own
    ///         spread and fee between its price and the reference, so a normal book is in band.
    uint256 public constant BAND_COST_MARGIN_BPS = 20;
    uint256 public constant MIN_REFERENCE_AGE = 1 hours;
    uint256 public constant MAX_ACTION_INTERVAL = 1 days;

    IERC20 public immutable STABLE;
    IHedgeVenue public immutable VENUE;
    bytes32 public immutable ASSET;
    /// @notice The only address funds leave the sleeve to: the hedge 2-of-3 Safe.
    address public immutable TREASURY;
    /// @notice The independent price every order is limited against and the venue is checked against.
    IHedgePriceFeed public immutable REFERENCE;
    /// @notice The venue's own max leverage for the asset when this was deployed.
    uint256 public immutable VENUE_MAX_LEVERAGE_BPS;
    /// @dev 10^(18 - stable decimals), and 10^(18 - reference decimals).
    uint256 internal immutable SCALE;
    uint256 internal immutable REF_SCALE;
    /// @dev One whole stablecoin unit: smaller moves are not worth an action.
    uint256 internal immutable MIN_MOVE;

    address public keeper;
    address public guardian;
    bool public exposurePaused;
    /// @notice When exposure was last paused; `resume` cannot take effect before this plus the delay.
    uint64 public pausedAt;
    uint64 public lastKeeperActionAt;
    uint64 public lastFundingSampleAt;
    uint64 public windowStart;
    uint256 public windowUsed;
    /// @notice Hourly funding average, 1e18 = 100% per hour.
    int256 public fundingEmaE18;
    uint256 public totalFunded;
    uint256 public totalWithdrawn;
    Params internal _params;

    event Funded(uint256 amount);
    event WithdrawnToTreasury(uint256 amount);
    event Order(Kind indexed kind, uint256 qty, uint256 avgPx, uint256 notional, bool budgeted);
    event MarginMoved(int256 amount);
    event Harvested(uint256 marginReleased, uint256 cashReturned);
    event FundingSampled(int256 venueRateE18, int256 emaE18);
    event ExposurePaused(address indexed by, bool paused);
    event Unwound(address indexed by);
    event ParamsSet(Params p);
    event RoleSet(string role, address indexed account);

    error NotKeeper();
    error NotTreasury();
    error NotGuardianOrGovernor();
    error ZeroAmount();
    error BadParams();
    error BadVenue();
    error BadReference(int256 answer);
    error StaleReference(uint256 updatedAt);
    error StaleVenuePrice(uint256 updatedAt);
    /// @dev `which`: 0 mark, 1 index, 2 spot.
    error OutOfBand(uint8 which, uint256 px, uint256 ref);
    error TooSoon(uint256 readyAt);
    error NothingToDo();
    error TurnoverExhausted(uint256 wanted, uint256 remaining);
    error FillOutsideLimit(uint256 avgPx, uint256 limitPx);
    error Overfilled(uint256 filled, uint256 qty);
    error InsufficientLiquid(uint256 wanted, uint256 available);
    /// @dev Two legs traded as a pair filled unequally: `missA` and `missB` unfilled of `size`.
    error UnevenFill(uint256 missA, uint256 missB, uint256 size);
    error PausedTooRecently(uint256 until);

    modifier onlyKeeper() {
        if (msg.sender != keeper) revert NotKeeper();
        _;
    }

    modifier onlyTreasury() {
        if (msg.sender != TREASURY) revert NotTreasury();
        _;
    }

    constructor(
        IERC20 stable,
        IHedgeVenue venue,
        bytes32 asset,
        IHedgePriceFeed referenceFeed,
        address treasury,
        address governor_,
        address guardian_,
        address keeper_,
        uint256 governanceDelay,
        Params memory p
    ) DelayedGovernance(governor_, governanceDelay) {
        if (
            address(stable) == address(0) || address(venue) == address(0)
                || address(referenceFeed) == address(0) || treasury == address(0)
                || guardian_ == address(0) || keeper_ == address(0)
        ) revert ZeroAddress();
        // The venue must settle in this stablecoin, or every balance below is in the wrong unit.
        if (address(venue.collateral()) != address(stable)) revert BadVenue();
        uint8 d = IERC20Metadata(address(stable)).decimals();
        uint8 rd = referenceFeed.decimals();
        if (d > 18 || rd > 18) revert BadVenue();
        STABLE = stable;
        VENUE = venue;
        ASSET = asset;
        REFERENCE = referenceFeed;
        TREASURY = treasury;
        SCALE = 10 ** (18 - d);
        REF_SCALE = 10 ** (18 - rd);
        MIN_MOVE = 10 ** d;
        // Reverts for an asset the venue does not list, so a wrong id fails here.
        uint256 venueMax = venue.maxLeverageBps(asset);
        VENUE_MAX_LEVERAGE_BPS = venueMax;
        keeper = keeper_;
        guardian = guardian_;
        _validate(p, venueMax);
        _params = p;
        // Start the average at what the venue reports now; zero would read as funding collapsing.
        fundingEmaE18 = _clampRate(venue.fundingRate(asset));
        lastFundingSampleAt = uint64(block.timestamp);
        emit ParamsSet(p);
    }

    /*//////////////////////////////////////////////////////////////
                                 VIEWS
    //////////////////////////////////////////////////////////////*/

    function getParams() external view returns (Params memory) {
        return _params;
    }

    function fundingEmaE8() public view returns (int256) {
        return fundingEmaE18 / 1e10;
    }

    /// @notice What the keeper may still place in the current window, stablecoin units.
    function remainingTurnover() public view returns (uint256) {
        uint256 used = block.timestamp >= uint256(windowStart) + WINDOW ? 0 : windowUsed;
        uint256 cap = _params.maxWindowTurnover;
        return used >= cap ? 0 : cap - used;
    }

    // The book itself (legs, margin, value, leverage) is read from the venue: `IHedgeVenue`'s views
    // with this contract as the account, plus `STABLE.balanceOf(this)` for idle cash. The off-chain
    // reader, packages/yield/src/hedge-risk/onchain-venue.ts, does exactly that.

    /*//////////////////////////////////////////////////////////////
                                TREASURY
    //////////////////////////////////////////////////////////////*/

    /// @notice Bring the treasury's stablecoin in. The treasury approves this contract first.
    function fund(uint256 amount) external nonReentrant onlyTreasury {
        _requireSetupComplete();
        // A zero amount is refused.
        // slither-disable-next-line incorrect-equality
        if (amount == 0) revert ZeroAmount();
        uint256 before = STABLE.balanceOf(address(this));
        // `from` is the immutable treasury, and only the treasury can call this.
        // slither-disable-next-line arbitrary-send-erc20
        STABLE.safeTransferFrom(TREASURY, address(this), amount);
        uint256 got = STABLE.balanceOf(address(this)) - before;
        totalFunded += got;
        emit Funded(got);
    }

    /**
     * @notice Pay `amount` to the treasury - `type(uint256).max` for everything available - from idle
     *         stablecoin, then venue cash, then perp margin above what `maxLeverageBps` requires at
     *         the venue's mark. Reverts if less than a stated amount is available.
     * @dev Needs neither the keeper nor the reference feed: an exit must not depend on either.
     */
    function withdrawToTreasury(uint256 amount)
        external
        nonReentrant
        onlyTreasury
        returns (uint256 paid)
    {
        // A zero amount is refused; the max sentinel means everything.
        // slither-disable-next-line incorrect-equality
        if (amount == 0) revert ZeroAmount();
        bool all = amount == type(uint256).max;
        uint256 idle = STABLE.balanceOf(address(this));
        if (all || idle < amount) {
            uint256 want = all ? type(uint256).max : amount - idle;
            uint256 vc = VENUE.cash(address(this));
            if (want > 0 && vc > 0) {
                uint256 x = vc < want ? vc : want;
                VENUE.withdraw(x);
                want -= x;
            }
            if (want > 0) {
                uint256 free = _freeMargin();
                if (free > 0) {
                    uint256 x = free < want ? free : want;
                    _moveMargin(-int256(x));
                    VENUE.withdraw(x);
                }
            }
            // What actually arrived, not what the venue was asked for.
            idle = STABLE.balanceOf(address(this));
        }
        paid = all ? idle : amount;
        // `idle` was re-read after the last venue call above, so it is not stale.
        // slither-disable-next-line reentrancy-balance
        if (paid > idle) revert InsufficientLiquid(amount, idle);
        // Nothing was paid out: refuse rather than emit a zero withdrawal.
        // slither-disable-next-line incorrect-equality
        if (paid == 0) revert ZeroAmount();
        totalWithdrawn += paid;
        STABLE.safeTransfer(TREASURY, paid);
        emit WithdrawnToTreasury(paid);
    }

    /**
     * @notice Close both legs at the treasury's own limits, pause exposure, and bring every free
     *         dollar back from the venue to this contract (then `withdrawToTreasury`). Needs neither
     *         the keeper nor the reference feed. Spot and a long perp sell at no less than
     *         `sellLimitPx`; the short buys back at no more than `buyLimitPx` (WAD USD).
     */
    function unwind(uint256 sellLimitPx, uint256 buyLimitPx) external nonReentrant onlyTreasury {
        // Always (re)pauses: an unwind is the latest pause, which a resume must then wait out.
        _pause();
        IHedgeVenue.PerpPosition memory pos = VENUE.perpPosition(address(this), ASSET);
        if (pos.size < 0) {
            _venueOrder(Kind.CloseShort, uint256(-pos.size), buyLimitPx, false, 0);
        } else if (pos.size > 0) {
            _venueOrder(Kind.CloseLong, uint256(pos.size), sellLimitPx, false, 0);
        }
        uint256 spot = VENUE.spotBalance(address(this), ASSET);
        if (spot > 0) _venueOrder(Kind.SellSpot, spot, sellLimitPx, false, 0);
        uint256 w = VENUE.marginAccount(address(this)).withdrawable;
        if (w > 0) _moveMargin(-int256(w));
        uint256 vc = VENUE.cash(address(this));
        if (vc > 0) VENUE.withdraw(vc);
        emit Unwound(msg.sender);
    }

    /// @notice Recover a token sent here by mistake, to the treasury. Not the stablecoin, which
    ///         leaves only through `withdrawToTreasury`.
    function sweep(IERC20 token) external nonReentrant onlyTreasury {
        if (address(token) == address(STABLE)) revert BadParams();
        token.safeTransfer(TREASURY, token.balanceOf(address(this)));
    }

    /*//////////////////////////////////////////////////////////////
                                 KEEPER
    //////////////////////////////////////////////////////////////*/

    /// @notice Take the single most urgent step towards the target book. Reverts `NothingToDo` when
    ///         there is none, so a keeper's simulation says so without spending gas.
    function rebalance() external onlyKeeper nonReentrant {
        _requireSetupComplete();
        _keeperGate();
        _sampleFunding();
        Book memory b = _book();
        if (!_step(b)) revert NothingToDo();
    }

    /**
     * @notice Refresh the funding average, return perp margin above target leverage to venue cash,
     *         and bring the venue's cash back to this contract, where the treasury can withdraw it.
     *         Moves nothing out of the sleeve.
     */
    function harvest() external onlyKeeper nonReentrant {
        _keeperGate();
        _sampleFunding();
        Book memory b = _book();
        uint256 targetMargin = (b.levN * BPS) / _params.targetLeverageBps;
        uint256 excess = b.equity > int256(targetMargin) ? uint256(b.equity) - targetMargin : 0;
        if (excess > b.withdrawable) excess = b.withdrawable;
        uint256 released = 0;
        if (excess >= MIN_MOVE) {
            _moveMargin(-int256(excess));
            released = excess;
        }
        uint256 vc = VENUE.cash(address(this));
        if (vc > 0) VENUE.withdraw(vc);
        emit Harvested(released, vc);
    }

    /// @notice Protect the margin when leverage is past `maxLeverageBps`. Anyone may call, so a rally
    ///         with the keeper offline does not end in a liquidation nobody tried to prevent.
    function deleverage() external nonReentrant {
        Book memory b = _book();
        if (!_overLeveraged(b)) revert NothingToDo();
        _deleverage(b, false);
    }

    /// @notice Record a funding sample. Anyone may: a sample's weight is the time since the last one,
    ///         so sampling more often adds precision, not influence.
    function sampleFunding() external nonReentrant {
        _sampleFunding();
    }

    function _keeperGate() internal {
        uint256 ready = uint256(lastKeeperActionAt) + _params.minActionInterval;
        if (block.timestamp < ready) revert TooSoon(ready);
        lastKeeperActionAt = uint64(block.timestamp);
    }

    /*//////////////////////////////////////////////////////////////
                               GOVERNANCE
    //////////////////////////////////////////////////////////////*/

    /// @notice Stop adding exposure and unwind (under the keeper's bounds). Guardian, governor or
    ///         treasury; instant.
    function pauseExposure() external {
        if (msg.sender != guardian && msg.sender != governor && msg.sender != TREASURY) {
            revert NotGuardianOrGovernor();
        }
        _pause();
    }

    function _pause() internal {
        exposurePaused = true;
        pausedAt = uint64(block.timestamp);
        emit ExposurePaused(msg.sender, true);
    }

    /**
     * @notice Lift a pause. Delayed: schedule it, then execute it after `GOVERNANCE_DELAY`. And not
     *         before the LATEST pause is `GOVERNANCE_DELAY` old, so a resume scheduled before a new
     *         pause cannot lift that new pause early. Instant (a no-op) when nothing is paused, and
     *         during setup.
     */
    function resume() external {
        _authorizeChange(exposurePaused);
        uint256 until = uint256(pausedAt) + GOVERNANCE_DELAY;
        if (setupComplete && exposurePaused && block.timestamp < until) revert PausedTooRecently(until);
        exposurePaused = false;
        emit ExposurePaused(msg.sender, false);
    }

    /// @notice Delayed when any field loosens a bound or touches what exits trade through
    ///         (`riskier`); instant when every field tightens and none of those changes.
    function setParams(Params calldata p) external {
        _authorizeChange(riskier(p, _params));
        _validate(p, VENUE_MAX_LEVERAGE_BPS);
        _params = p;
        emit ParamsSet(p);
    }

    /// @notice A new keeper waits out the delay; revoking (zero) is instant.
    function setKeeper(address k) external {
        _authorizeChange(k != address(0) && k != keeper);
        keeper = k;
        emit RoleSet("keeper", k);
    }

    /// @notice Instant: the guardian can only pause.
    function setGuardian(address g) external {
        _authorizeChange(false);
        if (g == address(0)) revert ZeroAddress();
        guardian = g;
        emit RoleSet("guardian", g);
    }

    /**
     * @notice True when the change must wait: any field of `n` loosens the corresponding bound in
     *         `o`, or any field the `deleverage` backstop and the exits trade through changes at all.
     * @dev `slippageBps`, `priceBandBps`, `maxReferenceAge` and `maxOrderNotional` are riskier in
     *      both directions: wider loosens the keeper, narrower can make `deleverage()` revert on
     *      every call (no fill inside the limit, every venue price "out of band", every reference
     *      "stale", orders too small to matter). A governor - on Sepolia the keeper's own key - must
     *      not be able to switch the backstop off at once. `minActionInterval` only paces the keeper,
     *      which no exit needs, so lengthening it (capped at a day) stays instant.
     */
    function riskier(Params memory n, Params memory o) public pure returns (bool) {
        return n.targetLeverageBps > o.targetLeverageBps || n.maxLeverageBps > o.maxLeverageBps
            || n.deltaToleranceBps > o.deltaToleranceBps || n.slippageBps != o.slippageBps
            || n.priceBandBps != o.priceBandBps || n.fundingPauseE8 < o.fundingPauseE8
            || n.fundingExitE8 < o.fundingExitE8 || n.fundingTau > o.fundingTau
            || n.minActionInterval < o.minActionInterval || n.maxReferenceAge != o.maxReferenceAge
            || n.maxOrderNotional != o.maxOrderNotional || n.maxWindowTurnover > o.maxWindowTurnover
            || n.allocationCap > o.allocationCap;
    }

    function _validate(Params memory p, uint256 venueMax) internal pure {
        if (
            // At most half the venue's own maximum, so the venue's maintenance is far below.
            p.targetLeverageBps < BPS / 2 || p.targetLeverageBps > p.maxLeverageBps
                || uint256(p.maxLeverageBps) * 2 > venueMax || p.slippageBps < MIN_SLIPPAGE_BPS
                || p.slippageBps > 300 || p.priceBandBps < uint256(p.slippageBps) + BAND_COST_MARGIN_BPS
                || p.priceBandBps > 500 || p.deltaToleranceBps == 0 || p.deltaToleranceBps > 2_000
                || p.fundingExitE8 > p.fundingPauseE8 || p.fundingTau == 0 || p.fundingTau > 30 days
                || p.maxReferenceAge < MIN_REFERENCE_AGE || p.maxReferenceAge > 2 days
                || p.minActionInterval > MAX_ACTION_INTERVAL || p.maxOrderNotional == 0
                || p.maxWindowTurnover < p.maxOrderNotional || p.allocationCap == 0
        ) revert BadParams();
    }

    function _isDelayable(bytes4 selector) internal pure override returns (bool) {
        return selector == HedgeSubWallet.setParams.selector
            || selector == HedgeSubWallet.setKeeper.selector
            || selector == HedgeSubWallet.resume.selector;
    }

    /*//////////////////////////////////////////////////////////////
                                READING
    //////////////////////////////////////////////////////////////*/

    /// @dev The book, with both prices fresh and the venue inside the band, or a revert.
    function _book() internal view returns (Book memory b) {
        Params memory p = _params;
        b.ref = _reference(p.maxReferenceAge);
        IHedgeVenue.Prices memory pr = VENUE.prices(ASSET);
        if (pr.updatedAt > block.timestamp || block.timestamp - pr.updatedAt > p.maxReferenceAge) {
            revert StaleVenuePrice(pr.updatedAt);
        }
        (b.mark, b.index, b.spotPx) = (pr.mark, pr.index, pr.spot);
        _inBand(0, b.mark, b.ref, p.priceBandBps);
        _inBand(1, b.index, b.ref, p.priceBandBps);
        _inBand(2, b.spotPx, b.ref, p.priceBandBps);

        IHedgeVenue.PerpPosition memory pos = VENUE.perpPosition(address(this), ASSET);
        if (pos.size < 0) b.shortQty = uint256(-pos.size);
        else b.longQty = uint256(pos.size);
        b.spotQty = VENUE.spotBalance(address(this), ASSET);
        IHedgeVenue.MarginAccount memory ma = VENUE.marginAccount(address(this));
        b.equity = ma.equity;
        b.withdrawable = ma.withdrawable;
        b.venueCash = VENUE.cash(address(this));
        b.idle = STABLE.balanceOf(address(this));

        b.shortN = _n(b.shortQty, b.ref);
        b.levN = _n(b.shortQty, b.mark > b.ref ? b.mark : b.ref);
        b.spotN = _n(b.spotQty, b.ref);
        uint256 spotValue = _n(b.spotQty, b.spotPx < b.ref ? b.spotPx : b.ref);
        // A margin deficit (negative equity, bad debt a liquidation left) is owed out of this value.
        uint256 gross = b.idle + b.venueCash + spotValue;
        uint256 deficit = b.equity < 0 ? uint256(-b.equity) : 0;
        b.nav = gross > deficit ? gross - deficit + (b.equity > 0 ? uint256(b.equity) : 0) : 0;
    }

    /// @dev Margin to move in for the account to hold `want` of equity. A deficit is part of it: margin moved into a
    ///      negative account first pays the deficit, so counting it as zero would open the book above its leverage.
    function _marginGap(uint256 want, int256 equity) internal pure returns (uint256) {
        if (equity < 0) return want + uint256(-equity);
        return want > uint256(equity) ? want - uint256(equity) : 0;
    }

    function _reference(uint256 maxAge) internal view returns (uint256) {
        // Round ids are not used; answer and updatedAt are checked below.
        // slither-disable-next-line unused-return
        (, int256 answer,, uint256 at,) = REFERENCE.latestRoundData();
        if (answer <= 0 || at == 0 || at > block.timestamp) revert BadReference(answer);
        if (block.timestamp - at > maxAge) revert StaleReference(at);
        return uint256(answer) * REF_SCALE;
    }

    function _inBand(uint8 which, uint256 px, uint256 ref, uint256 bandBps) internal pure {
        uint256 diff = px > ref ? px - ref : ref - px;
        if (diff * BPS > ref * bandBps) revert OutOfBand(which, px, ref);
    }

    /// @dev Margin above what `maxLeverageBps` requires at the venue's own mark, capped by what the
    ///      venue lets out. Needs no reference price.
    function _freeMargin() internal view returns (uint256) {
        IHedgeVenue.MarginAccount memory ma = VENUE.marginAccount(address(this));
        if (ma.withdrawable == 0 || ma.equity <= 0) return 0;
        uint256 required = 0;
        IHedgeVenue.PerpPosition memory pos = VENUE.perpPosition(address(this), ASSET);
        if (pos.size != 0) {
            required = (_n(_abs(pos.size), VENUE.prices(ASSET).mark) * BPS) / _params.maxLeverageBps;
        }
        uint256 eq = uint256(ma.equity);
        uint256 excess = eq > required ? eq - required : 0;
        return excess < ma.withdrawable ? excess : ma.withdrawable;
    }

    /*//////////////////////////////////////////////////////////////
                                STRATEGY
    //////////////////////////////////////////////////////////////*/

    function _step(Book memory b) internal returns (bool) {
        Plan memory pl = _plan(b);

        // 1. A long perp is never intended: close it, reduce-only.
        if (b.longQty > 0) {
            uint256 sz = _cap(b, b.longQty);
            _budget(b, sz);
            _venueOrder(Kind.CloseLong, sz, _sellLimit(b), true, b.ref);
            return true;
        }
        // 2. Delta outside tolerance.
        if (_fixDelta(b, pl)) return true;
        // 3. Leverage past the hard cap.
        if (_overLeveraged(b)) {
            _deleverage(b, true);
            return true;
        }
        // 4. More exposure than the target (paused, funding exit, value fell, cap lowered).
        if (b.shortN > pl.target + pl.tol) {
            _reduceBoth(b, _q(b.shortN - pl.target, b.ref), true);
            return true;
        }
        // 5. Add towards the target.
        if (pl.mayAdd && pl.target > b.shortN + pl.tol) return _addExposure(b, pl);
        return false;
    }

    function _plan(Book memory b) internal view returns (Plan memory pl) {
        Params memory p = _params;
        int256 funding = fundingEmaE18 / 1e10;
        bool unwinding = exposurePaused || funding < p.fundingExitE8;
        pl.mayAdd = !unwinding && funding >= p.fundingPauseE8;
        uint256 deployable = b.nav < p.allocationCap ? b.nav : p.allocationCap;
        // Spot S plus margin S / L is S (1 + 1/L): S = deployable x L / (1 + L), less room for the
        // limit band the two fills may cost.
        pl.target = unwinding
            ? 0
            : (deployable * p.targetLeverageBps * (BPS - 2 * uint256(p.slippageBps)))
                / (BPS * (BPS + uint256(p.targetLeverageBps)));
        // Hold size (never grow it) whenever adding is not allowed.
        if (!pl.mayAdd && pl.target > b.shortN) pl.target = b.shortN;
        pl.tol = (pl.target * p.deltaToleranceBps) / BPS + MIN_MOVE;
    }

    function _fixDelta(Book memory b, Plan memory pl) internal returns (bool) {
        uint256 larger = b.shortN > b.spotN ? b.shortN : b.spotN;
        uint256 diff = b.shortN > b.spotN ? b.shortN - b.spotN : b.spotN - b.shortN;
        // An empty book has no delta to fix.
        // slither-disable-next-line incorrect-equality
        if (larger == 0 || diff * BPS <= larger * _params.deltaToleranceBps || diff < MIN_MOVE) {
            return false;
        }
        if (b.spotQty > b.shortQty) {
            uint256 size = _cap(b, b.spotQty - b.shortQty);
            _budget(b, size);
            // Too little short: sell perp while exposure may grow and leverage allows; else sell spot.
            if (pl.mayAdd && _leverageAfter(b, size) <= _params.maxLeverageBps) {
                _venueOrder(Kind.OpenShort, size, _sellLimit(b), true, b.ref);
            } else {
                _venueOrder(Kind.SellSpot, size, _sellLimit(b), true, b.ref);
            }
        } else {
            // Too little spot: buy back short, reduce-only. Never buy spot to chase delta: that grows
            // the book where a hedge should shrink it.
            uint256 size = _cap(b, b.shortQty - b.spotQty);
            _budget(b, size);
            _venueOrder(Kind.CloseShort, size, _buyLimit(b), true, b.ref);
        }
        return true;
    }

    function _overLeveraged(Book memory b) internal view returns (bool) {
        return b.levN > 0
            && (b.equity <= 0 || b.levN * BPS > uint256(b.equity) * _params.maxLeverageBps);
    }

    /// @dev Top up margin back to target leverage from cash if that is enough; otherwise move what
    ///      there is and shrink both legs by one order.
    function _deleverage(Book memory b, bool budgeted) internal {
        uint256 topUp = _marginGap((b.levN * BPS) / _params.targetLeverageBps, b.equity);
        uint256 avail = b.idle + b.venueCash;
        if (topUp > 0 && avail >= MIN_MOVE) {
            uint256 x = avail < topUp ? avail : topUp;
            _toVenueCash(b, x);
            _moveMargin(int256(x));
            if (avail >= topUp) return;
        }
        _reduceBoth(b, _cap(b, b.shortQty), budgeted);
    }

    /// @dev Close `qty` of both legs together: buy back the short (reduce-only), sell the spot.
    function _reduceBoth(Book memory b, uint256 qty, bool budgeted) internal {
        uint256 shortSz = _cap(b, qty < b.shortQty ? qty : b.shortQty);
        uint256 spotSz = _cap(b, qty < b.spotQty ? qty : b.spotQty);
        // Both legs already flat: there is nothing to reduce.
        // slither-disable-next-line incorrect-equality
        if (shortSz == 0 && spotSz == 0) revert NothingToDo();
        if (budgeted) {
            _budget(b, shortSz);
            _budget(b, spotSz);
        }
        uint256 fs = _venueOrder(Kind.CloseShort, shortSz, _buyLimit(b), budgeted, b.ref);
        uint256 fp = _venueOrder(Kind.SellSpot, spotSz, _sellLimit(b), budgeted, b.ref);
        if (shortSz > 0 && spotSz > 0) {
            _checkPair(shortSz - fs, spotSz - fp, shortSz > spotSz ? shortSz : spotSz);
        }
    }

    /// @dev Margin, then spot cash, then both legs in the same call. The chunk shrinks to what the
    ///      sub-wallet's own cash can fund.
    function _addExposure(Book memory b, Plan memory pl) internal returns (bool) {
        uint256 chunk = _chunk(b, pl);
        if (chunk < MIN_MOVE) return false;
        uint256 marginNeed = _marginGap(((b.levN + chunk) * BPS) / _params.targetLeverageBps, b.equity);
        uint256 qty = _q(chunk, b.ref);
        // Both legs are charged to the window before anything leaves this contract.
        _budget(b, qty);
        _budget(b, qty);
        _toVenueCash(b, marginNeed + (chunk * (BPS + 2 * uint256(_params.slippageBps))) / BPS);
        if (marginNeed > 0) _moveMargin(int256(marginNeed));
        uint256 fb = _venueOrder(Kind.BuySpot, qty, _buyLimit(b), true, b.ref);
        uint256 fs = _venueOrder(Kind.OpenShort, qty, _sellLimit(b), true, b.ref);
        _checkPair(qty - fb, qty - fs, qty);
        return true;
    }

    /// @dev Revert unless two legs traded as a pair left unfilled amounts within `deltaToleranceBps`
    ///      of `size` of each other: a pair that fills one-sided would unhedge the book.
    function _checkPair(uint256 missA, uint256 missB, uint256 size) internal view {
        uint256 d = missA > missB ? missA - missB : missB - missA;
        if (d * BPS > size * _params.deltaToleranceBps) revert UnevenFill(missA, missB, size);
    }

    /// @dev The next chunk of short notional to add: towards the target, at most one order, and no
    ///      more than idle plus venue cash can fund as margin (BPS / L per unit) plus spot (one unit
    ///      plus two bands, for the fill and its fee).
    function _chunk(Book memory b, Plan memory pl) internal view returns (uint256 chunk) {
        Params memory p = _params;
        chunk = pl.target - b.shortN;
        if (chunk > p.maxOrderNotional) chunk = p.maxOrderNotional;
        uint256 gap0 = _marginGap((b.levN * BPS) / p.targetLeverageBps, b.equity);
        uint256 perUnitBps = (BPS * BPS) / p.targetLeverageBps + BPS + 2 * uint256(p.slippageBps);
        uint256 avail = b.idle + b.venueCash;
        if (gap0 + (chunk * perUnitBps) / BPS > avail) {
            chunk = avail > gap0 ? ((avail - gap0) * BPS) / perUnitBps : 0;
        }
    }

    function _leverageAfter(Book memory b, uint256 addShortQty) internal view returns (uint256) {
        if (b.equity <= 0) return type(uint256).max;
        uint256 px = b.mark > b.ref ? b.mark : b.ref;
        return ((b.levN + _n(addShortQty, px)) * BPS) / uint256(b.equity);
    }

    /*//////////////////////////////////////////////////////////////
                              VENUE CALLS
    //////////////////////////////////////////////////////////////*/

    /**
     * @dev One IOC order: close short and close long are reduce-only. A keeper order has already
     *      been charged to the window (`_budget`) on its requested notional, before any venue call
     *      of its step; its fill is checked against the limit and the size after the call: a venue
     *      that reports a worse fill reverts the whole step. Returns what filled, for the pair check.
     */
    function _venueOrder(Kind kind, uint256 qty, uint256 limitPx, bool budgeted, uint256 ref)
        internal
        returns (uint256 filled)
    {
        // A zero-size order is no order.
        // slither-disable-next-line incorrect-equality
        if (qty == 0) return 0;
        uint256 notional = 0;
        if (ref > 0) notional = _n(qty, ref);
        uint256 avgPx;
        bool buy = kind == Kind.BuySpot || kind == Kind.CloseShort;
        if (kind == Kind.BuySpot) {
            (filled, avgPx) = VENUE.buySpot(ASSET, qty, limitPx);
        } else if (kind == Kind.SellSpot) {
            (filled, avgPx) = VENUE.sellSpot(ASSET, qty, limitPx);
        } else if (kind == Kind.OpenShort) {
            (filled, avgPx) = VENUE.increasePerp(ASSET, false, qty, limitPx);
        } else {
            (filled, avgPx) = VENUE.reducePerp(ASSET, qty, limitPx);
        }
        if (filled > qty) revert Overfilled(filled, qty);
        if (filled > 0 && (buy ? avgPx > limitPx : avgPx < limitPx)) {
            revert FillOutsideLimit(avgPx, limitPx);
        }
        emit Order(kind, filled, avgPx, notional, budgeted);
    }

    /// @dev Make sure the venue holds `amount` of this account's cash, depositing idle stablecoin
    ///      as needed. The allowance is exact and reset after, so the venue can never pull more.
    function _toVenueCash(Book memory b, uint256 amount) internal {
        if (b.venueCash >= amount) {
            b.venueCash -= amount;
            return;
        }
        uint256 x = amount - b.venueCash;
        if (x > b.idle) x = b.idle;
        if (x > 0) {
            STABLE.forceApprove(address(VENUE), x);
            VENUE.deposit(x);
            STABLE.forceApprove(address(VENUE), 0);
            b.idle -= x;
        }
        b.venueCash = 0;
    }

    function _moveMargin(int256 amount) internal {
        VENUE.transferMargin(amount);
        emit MarginMoved(amount);
    }

    /// @dev Charge an order of `qty` to the keeper's window, at the reference price.
    function _budget(Book memory b, uint256 qty) internal {
        if (qty > 0) _spendTurnover(_n(qty, b.ref));
    }

    function _spendTurnover(uint256 notional) internal {
        if (block.timestamp >= uint256(windowStart) + WINDOW) {
            windowStart = uint64(block.timestamp);
            windowUsed = 0;
        }
        uint256 cap = _params.maxWindowTurnover;
        if (windowUsed + notional > cap) {
            revert TurnoverExhausted(notional, cap > windowUsed ? cap - windowUsed : 0);
        }
        windowUsed += notional;
    }

    /// @dev The sample's weight is the time since the previous one, capped at 4 tau.
    function _sampleFunding() internal {
        uint256 dt = block.timestamp - lastFundingSampleAt;
        // No time has passed since the last sample: nothing to fold in.
        // slither-disable-next-line incorrect-equality
        if (dt == 0) return;
        int256 rate = _clampRate(VENUE.fundingRate(ASSET));
        uint256 tau = _params.fundingTau;
        if (dt > 4 * tau) dt = 4 * tau;
        int256 ema = fundingEmaE18;
        ema += ((rate - ema) * int256(dt)) / int256(tau + dt);
        fundingEmaE18 = ema;
        lastFundingSampleAt = uint64(block.timestamp);
        emit FundingSampled(rate, ema);
    }

    /*//////////////////////////////////////////////////////////////
                                  MATH
    //////////////////////////////////////////////////////////////*/

    /// @dev Cap a quantity at `maxOrderNotional` at the reference price.
    function _cap(Book memory b, uint256 qty) internal view returns (uint256) {
        uint256 maxQty = _q(_params.maxOrderNotional, b.ref);
        return qty < maxQty ? qty : maxQty;
    }

    function _buyLimit(Book memory b) internal view returns (uint256) {
        return (b.ref * (BPS + _params.slippageBps)) / BPS;
    }

    function _sellLimit(Book memory b) internal view returns (uint256) {
        return (b.ref * (BPS - _params.slippageBps) + BPS - 1) / BPS;
    }

    /// @dev Notional of `qty` (WAD) at `px` (WAD USD), stablecoin units, rounded down.
    function _n(uint256 qty, uint256 px) internal view returns (uint256) {
        return (qty * px) / (WAD * SCALE);
    }

    /// @dev Quantity (WAD) worth `notional` stablecoin units at `px`, rounded down.
    function _q(uint256 notional, uint256 px) internal view returns (uint256) {
        return (notional * WAD * SCALE) / px;
    }

    function _clampRate(int256 r) internal pure returns (int256) {
        return r > MAX_SAMPLE ? MAX_SAMPLE : (r < -MAX_SAMPLE ? -MAX_SAMPLE : r);
    }

    function _abs(int256 x) internal pure returns (uint256) {
        return x >= 0 ? uint256(x) : uint256(-x);
    }
}
