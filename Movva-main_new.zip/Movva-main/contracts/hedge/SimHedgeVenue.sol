// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {IERC20Metadata} from "@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {IHedgeVenue, IHedgePriceFeed} from "./IHedgeVenue.sol";

/**
 * @title SimHedgeVenue
 * @notice ============================== TEST ONLY - NOT FOR MAINNET ==============================
 *
 *         A SIMULATED spot + perpetuals venue, so the hedge sleeve (`HedgeSubWallet`) can run end to
 *         end on Sepolia without choosing a real venue. It is the counterparty to every trade, its
 *         funding rate is whatever its `venueOperator` key sets, and it has no order book, no other
 *         traders and no insurance fund. It refuses to deploy on the main networks it knows of.
 *         Nothing it shows about fills, funding or liquidation is evidence about any real venue.
 *
 *         ==========================================================================================
 *
 * ## What it models
 *
 *  - **Collateral**: one ERC-20 stablecoin (on Sepolia the rail's stand-in USDT). Each account has a
 *    cash balance and, separately, a cross-margin account; `transferMargin` moves money between them.
 *  - **Markets**: one per asset, priced from a Chainlink-style aggregator (on Sepolia, Chainlink
 *    ETH/USD `0x694AA1769357215DE4FAC081bf1f309aDC325306`). The index is the feed's answer; the mark
 *    and the spot price are the index moved by an operator-set basis, so a dislocated venue can be
 *    rehearsed. The spot balance is venue-internal: buying "ETH" moves no ETH token anywhere, which is
 *    why no real ETH is needed on a testnet.
 *  - **Costs**: every fill is all-in, as `IHedgeVenue` requires: a buy fills at the price times
 *    (1 + `spreadBps` + `feeBps`), a sell at the price times (1 - both). Nothing is charged on top,
 *    so a caller's limit price bounds the whole cost of a fill.
 *  - **Funding**: accrues continuously on every perp position at the operator's hourly rate, against
 *    the index, positive paying shorts. It is a simulator: there is no premium, the operator decides.
 *  - **Margin**: initial margin is notional / max leverage; maintenance is half of it (Hyperliquid's
 *    rule, "half the initial margin at max leverage"). Below maintenance ANYONE may `liquidate`, which
 *    closes every perp of the account at the mark and pays `LIQUIDATION_FEE_BPS` of the closed notional
 *    to the liquidator; any deficit past zero is recorded as `badDebt`.
 *
 * ## The operator, and what it cannot do
 *
 * `venueOperator` lists markets and sets the knobs. Every knob is bounded by a constant here, so a
 * compromised operator key is a bounded cost, which is the property the sub-wallet's tests measure:
 *
 *  - funding at most `MAX_FUNDING_RATE` per hour either way (0.05%/h, ~438% APR): the most it can
 *    drain from a position is that rate times its notional, per hour, until the sub-wallet's funding
 *    exit floor unwinds it;
 *  - mark and spot at most `MAX_BASIS_BPS` (2%) off the oracle, spread at most `MAX_SPREAD_BPS` (1%),
 *    fee at most `MAX_FEE_BPS` (0.5%);
 *  - a market's max leverage (and so its maintenance rate) is fixed when it is listed: the operator
 *    cannot raise maintenance to liquidate a healthy account;
 *  - it cannot move, freeze or reassign any account's cash, collateral, spot or position, and it has
 *    no withdrawal of its own. Seeded liquidity is one-way.
 *
 * ## Liquidity: who pays the gains
 *
 * Every balance is a claim on this contract's token balance. The venue is the counterparty, so an
 * account's realised gains and positive funding are paid out of what OTHER deposits and the seed put
 * in. `seed(amount)` adds liquidity that nobody can claim. `houseLiquidity()` reports the token
 * balance less every realised claim (cash plus margin collateral); unrealised PnL is not in it. A
 * `withdraw` the token balance cannot cover reverts `VenueIlliquid`.
 *
 * For the delta-neutral sleeve the venue is short the spot it sold and long the perp the sleeve
 * shorted: price moves cancel inside the venue, and what it actually pays out is funding (less the
 * spread and fee it earns). The operator should therefore seed at least
 *
 *      notional x MAX_FUNDING_RATE x the hours the sleeve may run at the maximum rate
 *
 * plus, for any account that is NOT hedged here, the largest gain its naked position could make.
 * On Sepolia the stand-in USDT can be minted by anyone, so the deploy script mints and seeds
 * 1,000,000 test USDT, which covers a $100k book at the maximum rate for over 20,000 hours.
 *
 * ## Prices and time
 *
 * Trading, liquidation and moving margin out need a fresh oracle answer (at most `MAX_PRICE_AGE`
 * old); without one they revert, so an oracle outage freezes perps rather than mis-pricing them.
 * Depositing, withdrawing cash and moving cash into margin never need a price. Views report the last
 * answer with its time and leave freshness to the caller.
 */
contract SimHedgeVenue is IHedgeVenue, ReentrancyGuard {
    using SafeERC20 for IERC20;

    /// @notice Read this before using the contract.
    string public constant WARNING =
        "TEST ONLY: SIMULATED HEDGE VENUE, NOT A REAL VENUE, NOT FOR MAINNET";

    uint256 internal constant BPS = 10_000;
    uint256 internal constant WAD = 1e18;
    /// @notice The operator's funding-rate bound, per hour either way: 0.05%/h, about 438% a year.
    int256 public constant MAX_FUNDING_RATE = 5e14;
    uint256 public constant MAX_BASIS_BPS = 200;
    uint256 public constant MAX_SPREAD_BPS = 100;
    uint256 public constant MAX_FEE_BPS = 50;
    /// @notice Paid to whoever liquidates, out of the liquidated account's remaining collateral.
    uint256 public constant LIQUIDATION_FEE_BPS = 50;
    /// @notice A market may be listed at 2x to 50x; its maintenance is fixed from that at listing.
    uint256 public constant MIN_LISTED_LEVERAGE_BPS = 20_000;
    uint256 public constant MAX_LISTED_LEVERAGE_BPS = 500_000;
    /// @dev Bounds the per-account loops in equity and liquidation.
    uint256 public constant MAX_MARKETS_PER_ACCOUNT = 8;

    struct Market {
        IHedgePriceFeed oracle;
        uint8 oracleDecimals;
        bool listed;
        uint32 maxLeverageBps;
        uint32 maintenanceBps;
        int16 markBasisBps;
        int16 spotBasisBps;
        uint64 fundingUpdatedAt;
        /// WAD per hour.
        int256 fundingRate;
        /// Funding paid per whole unit of a long since listing, WAD USD.
        int256 cumFunding;
    }

    struct Position {
        int256 size;
        uint256 entryPx;
        /// `cumFunding` when this position last settled funding.
        int256 fundingIndex;
    }

    struct FundingChange {
        uint64 at;
        int192 rate;
    }

    IERC20 internal immutable COLLATERAL;
    /// @dev 10^(18 - collateral decimals): WAD USD to collateral units.
    uint256 internal immutable SCALE;
    /// @notice The oldest oracle answer trading, liquidation and margin withdrawal accept, seconds.
    uint256 public immutable MAX_PRICE_AGE;

    address public venueOperator;
    uint16 public spreadBps;
    uint16 public feeBps;

    mapping(bytes32 => Market) internal _markets;
    bytes32[] internal _assets;
    mapping(bytes32 => FundingChange[]) internal _fundingChanges;

    /// @notice Collateral an account holds outside its margin account (`IHedgeVenue.cash`).
    mapping(address => uint256) public cash;
    /// @notice Margin collateral: deposits into margin, realised PnL, settled funding and fees. Signed.
    mapping(address => int256) public collateralOf;
    mapping(address => mapping(bytes32 => uint256)) internal _spot;
    mapping(address => mapping(bytes32 => Position)) internal _positions;
    mapping(address => bytes32[]) internal _accountAssets;
    mapping(address => mapping(bytes32 => bool)) internal _accountHas;

    uint256 public totalCash;
    int256 public totalCollateral;
    /// @notice Deficits of liquidated accounts, absorbed by the venue's liquidity.
    uint256 public badDebt;

    event MarketListed(
        bytes32 indexed asset, address oracle, uint256 maxLeverageBps, uint256 maintenanceBps
    );
    event FundingRateSet(bytes32 indexed asset, int256 ratePerHour);
    event BasisSet(bytes32 indexed asset, int256 markBasisBps, int256 spotBasisBps);
    event FeesSet(uint256 spreadBps, uint256 feeBps);
    event VenueOperatorSet(address indexed operator);
    event Seeded(address indexed from, uint256 amount);
    event Deposited(address indexed account, uint256 amount);
    event Withdrawn(address indexed account, uint256 amount);
    event MarginTransferred(address indexed account, int256 amount);
    event Filled(
        address indexed account, bytes32 indexed asset, string kind, uint256 qty, uint256 px
    );
    event FundingSettled(address indexed account, bytes32 indexed asset, int256 amount);
    event Liquidated(
        address indexed account,
        address indexed by,
        uint256 notional,
        uint256 penalty,
        uint256 badDebt
    );

    error NotOperator();
    error MainnetRefused(uint256 chainId);
    error ZeroAddress();
    error ZeroAmount();
    error BadCollateral();
    error BadMaxAge();
    error UnknownMarket(bytes32 asset);
    error AlreadyListed(bytes32 asset);
    error OutOfBounds();
    error BadOraclePrice(int256 answer);
    error StalePrice(uint256 updatedAt);
    error PriceOutsideLimit(uint256 px, uint256 limitPx);
    error InsufficientCash(uint256 wanted, uint256 available);
    error InsufficientSpot(uint256 wanted, uint256 available);
    error InsufficientMargin(int256 equity, uint256 required);
    error NotWithdrawable(uint256 wanted, uint256 withdrawable);
    error WrongDirection();
    error NoPosition();
    error TooManyMarkets();
    error NotLiquidatable(int256 equity, uint256 maintenance);
    error VenueIlliquid(uint256 balance, uint256 wanted);

    modifier onlyOperator() {
        if (msg.sender != venueOperator) revert NotOperator();
        _;
    }

    constructor(
        IERC20 collateral_,
        address operator_,
        uint256 maxPriceAge,
        uint16 spreadBps_,
        uint16 feeBps_
    ) {
        // Ethereum, OP, BNB, Gnosis, Polygon, HyperEVM, Base, Arbitrum, Avalanche, Linea, Scroll.
        uint256 c = block.chainid;
        if (
            c == 1 || c == 10 || c == 56 || c == 100 || c == 137 || c == 999 || c == 8453
                || c == 42161 || c == 43114 || c == 59144 || c == 534352
        ) revert MainnetRefused(c);
        if (address(collateral_) == address(0) || operator_ == address(0)) revert ZeroAddress();
        uint8 d = IERC20Metadata(address(collateral_)).decimals();
        if (d > 18) revert BadCollateral();
        if (maxPriceAge == 0 || maxPriceAge > 2 days) revert BadMaxAge();
        if (spreadBps_ > MAX_SPREAD_BPS || feeBps_ > MAX_FEE_BPS) revert OutOfBounds();
        COLLATERAL = collateral_;
        SCALE = 10 ** (18 - d);
        MAX_PRICE_AGE = maxPriceAge;
        venueOperator = operator_;
        (spreadBps, feeBps) = (spreadBps_, feeBps_);
        emit VenueOperatorSet(operator_);
        emit FeesSet(spreadBps_, feeBps_);
    }

    /// @inheritdoc IHedgeVenue
    function collateral() external view returns (IERC20) {
        return COLLATERAL;
    }

    /*//////////////////////////////////////////////////////////////
                                OPERATOR
    //////////////////////////////////////////////////////////////*/

    /// @notice List `asset` priced from `oracle`. Max leverage, and with it maintenance, never change.
    function listMarket(
        bytes32 asset,
        IHedgePriceFeed oracle,
        uint32 maxLeverage,
        int256 fundingRatePerHour
    ) external onlyOperator {
        if (address(oracle) == address(0)) revert ZeroAddress();
        Market storage m = _markets[asset];
        if (m.listed) revert AlreadyListed(asset);
        if (maxLeverage < MIN_LISTED_LEVERAGE_BPS || maxLeverage > MAX_LISTED_LEVERAGE_BPS) {
            revert OutOfBounds();
        }
        if (fundingRatePerHour > MAX_FUNDING_RATE || fundingRatePerHour < -MAX_FUNDING_RATE) {
            revert OutOfBounds();
        }
        uint8 d = oracle.decimals();
        if (d > 18) revert OutOfBounds();
        m.oracle = oracle;
        m.oracleDecimals = d;
        m.listed = true;
        m.maxLeverageBps = maxLeverage;
        // Half the initial margin at max leverage: 10x -> 10% initial, 5% maintenance.
        m.maintenanceBps = uint32((BPS * BPS) / (2 * uint256(maxLeverage)));
        m.fundingRate = fundingRatePerHour;
        m.fundingUpdatedAt = uint64(block.timestamp);
        _rawIndex(m); // the oracle must answer now
        _assets.push(asset);
        _fundingChanges[asset].push(
            FundingChange(uint64(block.timestamp), int192(fundingRatePerHour))
        );
        emit MarketListed(asset, address(oracle), maxLeverage, m.maintenanceBps);
        emit FundingRateSet(asset, fundingRatePerHour);
    }

    /// @notice The simulated funding rate, per hour, WAD; accrues at the old rate up to now first.
    function setFundingRate(bytes32 asset, int256 ratePerHour) external onlyOperator {
        if (ratePerHour > MAX_FUNDING_RATE || ratePerHour < -MAX_FUNDING_RATE) revert OutOfBounds();
        Market storage m = _market(asset);
        _accrue(m);
        m.fundingRate = ratePerHour;
        _fundingChanges[asset].push(FundingChange(uint64(block.timestamp), int192(ratePerHour)));
        emit FundingRateSet(asset, ratePerHour);
    }

    /// @notice Move the mark and the spot price off the oracle, bps each way, to rehearse a dislocation.
    function setBasis(bytes32 asset, int16 markBasisBps, int16 spotBasisBps)
        external
        onlyOperator
    {
        if (_abs(markBasisBps) > MAX_BASIS_BPS || _abs(spotBasisBps) > MAX_BASIS_BPS) {
            revert OutOfBounds();
        }
        Market storage m = _market(asset);
        _accrue(m);
        (m.markBasisBps, m.spotBasisBps) = (markBasisBps, spotBasisBps);
        emit BasisSet(asset, markBasisBps, spotBasisBps);
    }

    function setFees(uint16 spreadBps_, uint16 feeBps_) external onlyOperator {
        if (spreadBps_ > MAX_SPREAD_BPS || feeBps_ > MAX_FEE_BPS) revert OutOfBounds();
        (spreadBps, feeBps) = (spreadBps_, feeBps_);
        emit FeesSet(spreadBps_, feeBps_);
    }

    function setVenueOperator(address operator_) external onlyOperator {
        if (operator_ == address(0)) revert ZeroAddress();
        venueOperator = operator_;
        emit VenueOperatorSet(operator_);
    }

    /// @notice Add liquidity that nobody can claim: it pays the gains and funding accounts earn.
    ///         Anyone may seed; nobody, the operator included, can take it back.
    function seed(uint256 amount) external nonReentrant {
        if (amount == 0) revert ZeroAmount();
        uint256 got = _pull(amount);
        emit Seeded(msg.sender, got);
    }

    /*//////////////////////////////////////////////////////////////
                               COLLATERAL
    //////////////////////////////////////////////////////////////*/

    /// @inheritdoc IHedgeVenue
    function deposit(uint256 amount) external nonReentrant {
        if (amount == 0) revert ZeroAmount();
        uint256 got = _pull(amount);
        cash[msg.sender] += got;
        totalCash += got;
        emit Deposited(msg.sender, got);
    }

    /// @inheritdoc IHedgeVenue
    function withdraw(uint256 amount) external nonReentrant {
        if (amount == 0) revert ZeroAmount();
        uint256 have = cash[msg.sender];
        if (amount > have) revert InsufficientCash(amount, have);
        uint256 bal = COLLATERAL.balanceOf(address(this));
        if (bal < amount) revert VenueIlliquid(bal, amount);
        cash[msg.sender] = have - amount;
        totalCash -= amount;
        COLLATERAL.safeTransfer(msg.sender, amount);
        emit Withdrawn(msg.sender, amount);
    }

    /// @inheritdoc IHedgeVenue
    function transferMargin(int256 amount) external nonReentrant {
        if (amount == 0) revert ZeroAmount();
        address a = msg.sender;
        if (amount > 0) {
            uint256 x = uint256(amount);
            uint256 have = cash[a];
            if (x > have) revert InsufficientCash(x, have);
            cash[a] = have - x;
            totalCash -= x;
            _addCollateral(a, amount);
        } else {
            uint256 x = uint256(-amount);
            _settleAll(a);
            uint256 w = _withdrawable(a, true);
            if (x > w) revert NotWithdrawable(x, w);
            _addCollateral(a, amount);
            cash[a] += x;
            totalCash += x;
        }
        emit MarginTransferred(a, amount);
    }

    /*//////////////////////////////////////////////////////////////
                                 ORDERS
    //////////////////////////////////////////////////////////////*/

    /// @inheritdoc IHedgeVenue
    function buySpot(bytes32 asset, uint256 qty, uint256 limitPx)
        external
        nonReentrant
        returns (uint256 filled, uint256 avgPx)
    {
        if (qty == 0) revert ZeroAmount();
        Market storage m = _market(asset);
        (, uint256 spotPx) = _markSpot(m, true);
        avgPx = _buyPx(spotPx, limitPx);
        uint256 cost = _col(qty, avgPx, true);
        uint256 have = cash[msg.sender];
        if (cost > have) revert InsufficientCash(cost, have);
        _track(msg.sender, asset);
        cash[msg.sender] = have - cost;
        totalCash -= cost;
        _spot[msg.sender][asset] += qty;
        emit Filled(msg.sender, asset, "buy spot", qty, avgPx);
        return (qty, avgPx);
    }

    /// @inheritdoc IHedgeVenue
    function sellSpot(bytes32 asset, uint256 qty, uint256 limitPx)
        external
        nonReentrant
        returns (uint256 filled, uint256 avgPx)
    {
        if (qty == 0) revert ZeroAmount();
        Market storage m = _market(asset);
        uint256 held = _spot[msg.sender][asset];
        if (qty > held) revert InsufficientSpot(qty, held);
        (, uint256 spotPx) = _markSpot(m, true);
        avgPx = _sellPx(spotPx, limitPx);
        uint256 proceeds = _col(qty, avgPx, false);
        _spot[msg.sender][asset] = held - qty;
        cash[msg.sender] += proceeds;
        totalCash += proceeds;
        emit Filled(msg.sender, asset, "sell spot", qty, avgPx);
        return (qty, avgPx);
    }

    /// @inheritdoc IHedgeVenue
    function increasePerp(bytes32 asset, bool isLong, uint256 size, uint256 limitPx)
        external
        nonReentrant
        returns (uint256 filled, uint256 avgPx)
    {
        if (size == 0) revert ZeroAmount();
        address a = msg.sender;
        Market storage m = _market(asset);
        _track(a, asset);
        _settle(a, asset, m);
        Position storage p = _positions[a][asset];
        if (p.size != 0 && (p.size > 0) != isLong) revert WrongDirection();
        (uint256 mark,) = _markSpot(m, true);
        avgPx = isLong ? _buyPx(mark, limitPx) : _sellPx(mark, limitPx);
        uint256 held = _abs(p.size);
        // The entry is the all-in fill, so the spread and fee show at once as unrealised loss.
        p.entryPx = (held * p.entryPx + size * avgPx) / (held + size);
        p.size = isLong ? p.size + int256(size) : p.size - int256(size);
        (int256 eq,, uint256 init) = _account(a, true);
        if (eq < int256(init)) revert InsufficientMargin(eq, init);
        emit Filled(a, asset, isLong ? "open long" : "open short", size, avgPx);
        return (size, avgPx);
    }

    /// @inheritdoc IHedgeVenue
    function reducePerp(bytes32 asset, uint256 size, uint256 limitPx)
        external
        nonReentrant
        returns (uint256 filled, uint256 avgPx)
    {
        if (size == 0) revert ZeroAmount();
        address a = msg.sender;
        Market storage m = _market(asset);
        _settle(a, asset, m);
        Position storage p = _positions[a][asset];
        if (p.size == 0) revert NoPosition();
        (uint256 mark,) = _markSpot(m, true);
        bool short = p.size < 0;
        avgPx = short ? _buyPx(mark, limitPx) : _sellPx(mark, limitPx);
        uint256 held = _abs(p.size);
        filled = size < held ? size : held;
        _addCollateral(a, _pnl(p.size, filled, p.entryPx, avgPx));
        p.size = short ? p.size + int256(filled) : p.size - int256(filled);
        if (p.size == 0) p.entryPx = 0;
        emit Filled(a, asset, short ? "close short" : "close long", filled, avgPx);
    }

    /// @dev The all-in price of a buy at reference `px`: spread plus fee, rounded up; held to `limitPx`.
    function _buyPx(uint256 px, uint256 limitPx) internal view returns (uint256 all) {
        all = _up(px, BPS + spreadBps + feeBps);
        if (all > limitPx) revert PriceOutsideLimit(all, limitPx);
    }

    /// @dev The all-in price of a sell: spread plus fee off, rounded down; held to `limitPx`.
    function _sellPx(uint256 px, uint256 limitPx) internal view returns (uint256 all) {
        all = (px * (BPS - spreadBps - feeBps)) / BPS;
        if (all < limitPx) revert PriceOutsideLimit(all, limitPx);
    }

    /*//////////////////////////////////////////////////////////////
                              LIQUIDATION
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Close every perp of `account` at the mark once its equity is below maintenance. Anyone
     *         may call; the caller's cash receives `LIQUIDATION_FEE_BPS` of the closed notional, out
     *         of what collateral is left. A deficit past zero becomes `badDebt`.
     */
    function liquidate(address account) external nonReentrant {
        _settleAll(account);
        (int256 eq, uint256 maint,) = _account(account, true);
        // An account with no maintenance requirement holds nothing.
        // slither-disable-next-line incorrect-equality
        if (maint == 0 || eq >= int256(maint)) revert NotLiquidatable(eq, maint);
        uint256 notional = 0;
        bytes32[] storage list = _accountAssets[account];
        for (uint256 i; i < list.length; ++i) {
            Position storage p = _positions[account][list[i]];
            if (p.size == 0) continue;
            (uint256 mark,) = _markSpot(_markets[list[i]], true);
            uint256 held = _abs(p.size);
            notional += _col(held, mark, false);
            _addCollateral(account, _pnl(p.size, held, p.entryPx, mark));
            p.size = 0;
            p.entryPx = 0;
        }
        int256 left = collateralOf[account];
        uint256 penalty = (notional * LIQUIDATION_FEE_BPS) / BPS;
        if (left < int256(penalty)) penalty = left > 0 ? uint256(left) : 0;
        if (penalty > 0) {
            _addCollateral(account, -int256(penalty));
            cash[msg.sender] += penalty;
            totalCash += penalty;
            left -= int256(penalty);
        }
        uint256 deficit = 0;
        if (left < 0) {
            deficit = uint256(-left);
            badDebt += deficit;
            _addCollateral(account, -left);
        }
        emit Liquidated(account, msg.sender, notional, penalty, deficit);
    }

    /*//////////////////////////////////////////////////////////////
                                 READS
    //////////////////////////////////////////////////////////////*/

    /// @inheritdoc IHedgeVenue
    function spotBalance(address account, bytes32 asset) external view returns (uint256) {
        return _spot[account][asset];
    }

    /// @inheritdoc IHedgeVenue
    function perpPosition(address account, bytes32 asset)
        external
        view
        returns (PerpPosition memory)
    {
        Position storage p = _positions[account][asset];
        return PerpPosition({size: p.size, entryPx: p.entryPx});
    }

    /// @inheritdoc IHedgeVenue
    function marginAccount(address account) external view returns (MarginAccount memory a) {
        (a.equity, a.maintenance, a.initial) = _account(account, false);
        a.withdrawable = _withdrawable(account, false);
    }

    /// @inheritdoc IHedgeVenue
    function prices(bytes32 asset) external view returns (Prices memory p) {
        Market storage m = _market(asset);
        (uint256 index, uint256 at) = _rawIndex(m);
        p.index = index;
        p.mark = _basis(index, m.markBasisBps);
        p.spot = _basis(index, m.spotBasisBps);
        p.updatedAt = at;
    }

    /// @inheritdoc IHedgeVenue
    function fundingRate(bytes32 asset) external view returns (int256) {
        return _market(asset).fundingRate;
    }

    /// @inheritdoc IHedgeVenue
    function maxLeverageBps(bytes32 asset) external view returns (uint256) {
        return _market(asset).maxLeverageBps;
    }

    /// @notice Every listed asset.
    function listedAssets() external view returns (bytes32[] memory) {
        return _assets;
    }

    function marketInfo(bytes32 asset)
        external
        view
        returns (
            address oracle,
            uint256 maxLeverage,
            uint256 maintenanceBps,
            int256 markBasisBps,
            int256 spotBasisBps,
            int256 ratePerHour
        )
    {
        Market storage m = _market(asset);
        return (
            address(m.oracle),
            m.maxLeverageBps,
            m.maintenanceBps,
            m.markBasisBps,
            m.spotBasisBps,
            m.fundingRate
        );
    }

    /// @notice Every rate the operator has set for `asset`, oldest first, from index `from`: the
    ///         simulated funding history (the rate is piecewise constant between changes).
    function fundingHistory(bytes32 asset, uint256 from)
        external
        view
        returns (uint64[] memory at, int256[] memory ratePerHour)
    {
        _market(asset);
        FundingChange[] storage h = _fundingChanges[asset];
        uint256 n = from < h.length ? h.length - from : 0;
        at = new uint64[](n);
        ratePerHour = new int256[](n);
        for (uint256 i; i < n; ++i) {
            at[i] = h[from + i].at;
            ratePerHour[i] = h[from + i].rate;
        }
    }

    /// @notice The token balance less every realised claim (cash and margin collateral), collateral
    ///         units. Negative means the venue could not pay every account at once. Unrealised PnL
    ///         and unsettled funding are not counted.
    function houseLiquidity() external view returns (int256) {
        return int256(COLLATERAL.balanceOf(address(this))) - int256(totalCash) - totalCollateral;
    }

    /*//////////////////////////////////////////////////////////////
                                INTERNALS
    //////////////////////////////////////////////////////////////*/

    function _market(bytes32 asset) internal view returns (Market storage m) {
        m = _markets[asset];
        if (!m.listed) revert UnknownMarket(asset);
    }

    /// @dev The oracle's answer as WAD USD, and its time. Freshness is the caller's business.
    function _rawIndex(Market storage m) internal view returns (uint256 px, uint256 updatedAt) {
        // Round ids are not used; answer and updatedAt are checked below.
        // slither-disable-next-line unused-return
        (, int256 answer,, uint256 at,) = m.oracle.latestRoundData();
        if (answer <= 0 || at == 0 || at > block.timestamp) revert BadOraclePrice(answer);
        px = uint256(answer) * 10 ** (18 - m.oracleDecimals);
        updatedAt = at;
    }

    function _index(Market storage m, bool strict) internal view returns (uint256 px) {
        uint256 at;
        (px, at) = _rawIndex(m);
        if (strict && block.timestamp - at > MAX_PRICE_AGE) revert StalePrice(at);
    }

    function _markSpot(Market storage m, bool strict)
        internal
        view
        returns (uint256 mark, uint256 spotPx)
    {
        uint256 index = _index(m, strict);
        return (_basis(index, m.markBasisBps), _basis(index, m.spotBasisBps));
    }

    function _basis(uint256 px, int16 bps) internal pure returns (uint256) {
        return (px * uint256(int256(BPS) + bps)) / BPS;
    }

    /// @dev Funding accrues on the last oracle answer, fresh or not: it is bookkeeping, and every
    ///      trade that could exploit a stale index is refused on freshness anyway.
    function _cumNow(Market storage m) internal view returns (int256) {
        (uint256 index,) = _rawIndex(m);
        uint256 dt = block.timestamp - m.fundingUpdatedAt;
        return m.cumFunding + (m.fundingRate * int256(index) * int256(dt)) / 3600 / int256(WAD);
    }

    function _accrue(Market storage m) internal {
        m.cumFunding = _cumNow(m);
        m.fundingUpdatedAt = uint64(block.timestamp);
    }

    /// @dev Pay `account`'s funding on `asset` into its collateral: a long pays a positive rate.
    function _settle(address account, bytes32 asset, Market storage m) internal {
        _accrue(m);
        Position storage p = _positions[account][asset];
        int256 owed = _funding(p, m.cumFunding);
        p.fundingIndex = m.cumFunding;
        if (owed != 0) {
            _addCollateral(account, owed);
            emit FundingSettled(account, asset, owed);
        }
    }

    function _settleAll(address account) internal {
        bytes32[] storage list = _accountAssets[account];
        for (uint256 i; i < list.length; ++i) {
            _settle(account, list[i], _markets[list[i]]);
        }
    }

    /// @dev Funding a position is owed (positive) or owes since it last settled, collateral units.
    function _funding(Position storage p, int256 cum) internal view returns (int256) {
        return -(p.size * (cum - p.fundingIndex)) / int256(WAD) / int256(SCALE);
    }

    /// @dev Equity, maintenance and initial margin across the account's markets.
    function _account(address account, bool strict)
        internal
        view
        returns (int256 eq, uint256 maint, uint256 init)
    {
        eq = collateralOf[account];
        bytes32[] storage list = _accountAssets[account];
        for (uint256 i; i < list.length; ++i) {
            Position storage p = _positions[account][list[i]];
            if (p.size == 0) continue;
            Market storage m = _markets[list[i]];
            (uint256 mark,) = _markSpot(m, strict);
            uint256 held = _abs(p.size);
            eq += _pnl(p.size, held, p.entryPx, mark) + _funding(p, _cumNow(m));
            uint256 notional = _col(held, mark, true);
            maint += (notional * m.maintenanceBps + BPS - 1) / BPS;
            init += (notional * BPS + m.maxLeverageBps - 1) / m.maxLeverageBps;
        }
    }

    /// @dev Margin that may go back to cash: realised collateral above what open positions need.
    function _withdrawable(address account, bool strict) internal view returns (uint256) {
        (int256 eq,, uint256 init) = _account(account, strict);
        int256 c = collateralOf[account];
        int256 free = eq - int256(init);
        int256 w = c < free ? c : free;
        return w > 0 ? uint256(w) : 0;
    }

    /// @dev PnL of closing `qty` of a position of `size` entered at `entry`, at `px`, collateral units.
    function _pnl(int256 size, uint256 qty, uint256 entry, uint256 px)
        internal
        view
        returns (int256)
    {
        int256 diff = int256(px) - int256(entry);
        int256 v = (int256(qty) * diff) / int256(WAD) / int256(SCALE);
        return size > 0 ? v : -v;
    }

    /// @dev Notional of `qty` at `px` in collateral units, rounded up or down.
    function _col(uint256 qty, uint256 px, bool up) internal view returns (uint256) {
        uint256 d = WAD * SCALE;
        uint256 n = qty * px;
        return up ? (n + d - 1) / d : n / d;
    }

    function _up(uint256 px, uint256 factorBps) internal pure returns (uint256) {
        return (px * factorBps + BPS - 1) / BPS;
    }

    function _addCollateral(address account, int256 delta) internal {
        collateralOf[account] += delta;
        totalCollateral += delta;
    }

    function _track(address account, bytes32 asset) internal {
        if (_accountHas[account][asset]) return;
        if (_accountAssets[account].length >= MAX_MARKETS_PER_ACCOUNT) revert TooManyMarkets();
        _accountHas[account][asset] = true;
        _accountAssets[account].push(asset);
    }

    function _pull(uint256 amount) internal returns (uint256 got) {
        uint256 before = COLLATERAL.balanceOf(address(this));
        COLLATERAL.safeTransferFrom(msg.sender, address(this), amount);
        got = COLLATERAL.balanceOf(address(this)) - before;
    }

    function _abs(int256 x) internal pure returns (uint256) {
        return x >= 0 ? uint256(x) : uint256(-x);
    }
}
