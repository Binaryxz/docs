// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

interface IPoolLabelSource {
    function SCOPE() external view returns (uint256);
    function nonce() external view returns (uint256);
}

/**
 * @title ShieldedDepositLabel
 * @notice Recover the label a Privacy Pool assigned to a deposit this contract just made.
 *
 * ## Why a contract that deposits on someone's behalf needs the label
 *
 * When a contract (the ramp's escrow) deposits into a pool for a user,
 * the POOL records that contract as the depositor. Only the depositor may `ragequit`, so the
 * user's escape hatch now runs through the contract, which must know whose funds are whose.
 *
 * The obvious key is the commitment the deposit returned. It is the wrong key. `ragequit`
 * checks `depositors[label]`, and a label survives a private partial withdrawal while the
 * commitment does not: withdrawing part of a deposit spends the commitment and inserts a
 * successor with the SAME label and the remaining value. Keyed by commitment, the escape
 * hatch works only for a user who never touched their deposit, which is to say it quietly
 * stops working the first time it is used as intended. That was a real bug in FiatEscrow.
 *
 * ## The formula, and why it is safe to recompute
 *
 * `PrivacyPool.deposit` computes
 *
 *     label = keccak256(abi.encodePacked(SCOPE, ++nonce)) % SNARK_SCALAR_FIELD
 *
 * and does not return it. Reading `nonce` immediately after our own deposit, in the same
 * call frame, gives exactly the value that deposit used: the Entrypoint is nonReentrant, so
 * no other deposit into that pool can land in between.
 *
 * Recomputing a value the contract derives is the pattern behind the worst bug in this
 * project (`labelOf`, Phase 1). So this was checked against a real `Deposited` event on a
 * mainnet fork before it was written, and `RampRescue.t.sol` re-checks it on every run.
 */
library ShieldedDepositLabel {
    /// @dev Equal to Constants.SNARK_SCALAR_FIELD in the forked protocol.
    uint256 internal constant SNARK_SCALAR_FIELD =
        21888242871839275222246405745257275088548364400416034343698204186575808495617;

    /// @dev The Entrypoint's key for native ETH in `assetConfig`.
    address internal constant NATIVE_ASSET = 0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE;

    /// @notice The label of the most recent deposit into `pool`.
    /// @dev Only meaningful when called in the same call frame as that deposit.
    function lastLabel(address pool) internal view returns (uint256) {
        IPoolLabelSource p = IPoolLabelSource(pool);
        return uint256(keccak256(abi.encodePacked(p.SCOPE(), p.nonce()))) % SNARK_SCALAR_FIELD;
    }
}
