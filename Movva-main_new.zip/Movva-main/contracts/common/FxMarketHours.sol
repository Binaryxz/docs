// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/**
 * @title FxMarketHours
 * @notice Whether the FX.USD/BRL market is certainly trading, from a timestamp alone.
 *
 * Pyth publishes FX.USD/BRL on the schedule in its feed metadata (Hermes, checked 14 September 2026):
 *
 *     America/New_York;0800-1700,0800-1700,0800-1700,0800-1700,0800-1700,C,C;1225/C,0101/C
 *
 * weekdays 08:00-17:00 New York time, closed at weekends, on 25 December and on 1 January. Outside it
 * the price does not move, however often a keeper posts it.
 *
 * New York is UTC-5 in winter and UTC-4 in summer, and knowing which on-chain means encoding US
 * daylight saving rules that Congress can change. This does not. The CORE SESSION is the part of the
 * schedule that is open under both offsets - 13:00 to 21:00 UTC - starting half an hour late, 13:30,
 * so a keeper has time to post the day's first price before anything insists on it. Inside the core
 * session the market is trading whatever the offset. Outside it the market may be closed; for about
 * two hours a day (12:00-13:30 UTC in summer, 21:00-22:00 UTC in winter) it is in fact open.
 *
 * Which way that errs is the point: PythFxOracle refuses an old price for being old at every hour for
 * anything that moves value, and only a BAND treats the hours outside the core session as closed. So
 * the hours this misreads are hours a band accepts the last price it has - never hours a mint does.
 *
 * If Pyth changes the schedule, this must change with it.
 */
library FxMarketHours {
    /// @notice Core session, in seconds after midnight UTC: open from 13:30, closed from 21:00.
    uint256 internal constant CORE_OPEN_UTC = 13 hours + 30 minutes;
    uint256 internal constant CORE_CLOSE_UTC = 21 hours;

    /// @notice True when `t` is inside the core session: 13:30-21:00 UTC, Monday to Friday, except
    ///         25 December and 1 January (the dates are New York's too at those hours).
    function inCoreSession(uint256 t) internal pure returns (bool) {
        uint256 secondOfDay = t % 1 days;
        if (secondOfDay < CORE_OPEN_UTC || secondOfDay >= CORE_CLOSE_UTC) return false;
        uint256 dayNumber = t / 1 days;
        // 1 January 1970 was a Thursday, so (days + 4) % 7 is 0 on a Sunday and 6 on a Saturday.
        uint256 weekday = (dayNumber + 4) % 7;
        if (weekday == 0 || weekday == 6) return false;
        (uint256 month, uint256 day) = monthDay(dayNumber);
        return !((month == 12 && day == 25) || (month == 1 && day == 1));
    }

    /// @notice Month (1-12) and day of the month (1-31) of the UTC date `dayNumber` days after
    ///         1 January 1970. Howard Hinnant's `civil_from_days`, for non-negative days.
    /// @dev Every division here is meant to floor before the product that follows it: the algorithm counts
    ///      whole years, leap days and months, and a product taken first would count fractions of them.
    ///      Slither's divide-before-multiply is answered by FxMarketHoursTest.test_MonthAndDayAcrossLeapYears.
    function monthDay(uint256 dayNumber) internal pure returns (uint256 month, uint256 day) {
        uint256 z = dayNumber + 719_468;
        uint256 doe = z % 146_097; // day of the 400-year era, [0, 146096]
        uint256 yoe = (doe - doe / 1460 + doe / 36_524 - doe / 146_096) / 365; // [0, 399]
        // slither-disable-next-line divide-before-multiply
        uint256 doy = doe - (365 * yoe + yoe / 4 - yoe / 100); // day of the March-based year, [0, 365]
        uint256 mp = (5 * doy + 2) / 153; // March = 0, [0, 11]
        // slither-disable-next-line divide-before-multiply
        day = doy - (153 * mp + 2) / 5 + 1;
        month = mp < 10 ? mp + 3 : mp - 9;
    }
}
