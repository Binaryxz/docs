// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/**
 * @title IssuerFreeze
 * @notice Whether a stablecoin's issuer has frozen an address.
 *
 * USDT and USDC can each freeze any address: Tether through `isBlackListed(address)`, Circle
 * through `isBlacklisted(address)`. A frozen address can still RECEIVE the token - both issuers
 * check only the sender of a transfer - so a frozen contract that keeps taking deposits turns
 * every new deposit into frozen money. The contracts here ask before they take any.
 *
 * ## Why the probe is written like this
 *
 *  - **Optional.** Most tokens have neither function. A call to one that does not exist either
 *    reverts or returns nothing, and both read as "not frozen".
 *  - **Gas-capped.** A token whose fallback writes state (WETH's deposits) makes a STATICCALL fail
 *    by exceptional halt, which consumes all the gas it was given - by default 63/64 of what the
 *    caller has left. Uncapped, merely asking WETH would starve the rest of the transaction.
 *    `PROBE_GAS` covers Tether's mapping read and USDC's proxy hop with room to spare
 *    (`IssuerFreeze.t.sol` measures both against the real tokens on a fork).
 *  - **Decoded as a word.** A malformed answer cannot make the caller revert.
 *
 * What this cannot do is unfreeze anything: funds already held by a frozen address stay frozen
 * until the issuer says otherwise. It only stops the pile growing.
 */
library IssuerFreeze {
    /// @dev Tether's `isBlackListed(address)`.
    bytes4 internal constant TETHER = 0xe47d6060;
    /// @dev Circle's `isBlacklisted(address)`.
    bytes4 internal constant CIRCLE = 0xfe575a87;
    uint256 internal constant PROBE_GAS = 30_000;

    function isFrozen(address token, address who) internal view returns (bool) {
        return _asks(token, TETHER, who) || _asks(token, CIRCLE, who);
    }

    function _asks(address token, bytes4 selector, address who) private view returns (bool) {
        // A token that is not a contract answers every call with success and no data.
        if (token.code.length == 0) return false;
        // slither-disable-next-line low-level-calls
        (bool ok, bytes memory ret) = token.staticcall{gas: PROBE_GAS}(abi.encodeWithSelector(selector, who));
        return ok && ret.length >= 32 && abi.decode(ret, (uint256)) != 0;
    }
}
