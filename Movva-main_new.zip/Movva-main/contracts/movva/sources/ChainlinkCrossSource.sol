// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Math} from "@openzeppelin/contracts/utils/math/Math.sol";
import {IPriceSource} from "../IPriceSource.sol";
import {IAggregatorV3} from "../../ramp/ChainlinkBrlOracle.sol";

/**
 * @title ChainlinkCrossSource
 * @notice Reais per USDT from two Chainlink feeds, USDT/USD and BRL/USD: an `IPriceSource` that shares
 *         no publisher with the reserve's Pyth FX leg, so the DivergenceBreaker compares two
 *         independent BRL rates. Immutable; a stale, zero or negative answer reverts (the breaker reads
 *         that as disagreement).
 */
contract ChainlinkCrossSource is IPriceSource {
    IAggregatorV3 public immutable USDT_USD;
    IAggregatorV3 public immutable BRL_USD;
    uint64 public immutable USDT_USD_MAX_AGE;
    uint64 public immutable BRL_USD_MAX_AGE;
    uint8 internal immutable USDT_DEC;
    uint8 internal immutable BRL_DEC;

    error BadFeed();
    error StaleOrBad(address feed);

    constructor(address usdtUsd, address brlUsd, uint64 usdtMaxAge, uint64 brlMaxAge) {
        if (usdtUsd == address(0) || brlUsd == address(0) || usdtMaxAge == 0 || brlMaxAge == 0) revert BadFeed();
        USDT_USD = IAggregatorV3(usdtUsd);
        BRL_USD = IAggregatorV3(brlUsd);
        USDT_USD_MAX_AGE = usdtMaxAge;
        BRL_USD_MAX_AGE = brlMaxAge;
        USDT_DEC = USDT_USD.decimals();
        BRL_DEC = BRL_USD.decimals();
        if (USDT_DEC > 18 || BRL_DEC > 18) revert BadFeed();
    }

    /// @inheritdoc IPriceSource
    function brlPerUsdtE18() external view returns (uint256) {
        uint256 u = _read(USDT_USD, USDT_USD_MAX_AGE);
        uint256 b = _read(BRL_USD, BRL_USD_MAX_AGE);
        // (u / 10^du) / (b / 10^db) x 1e18
        uint256 rate = Math.mulDiv(u * 10 ** BRL_DEC, 1e18, b * 10 ** USDT_DEC);
        return rate;
    }

    function _read(IAggregatorV3 f, uint64 maxAge) internal view returns (uint256) {
        // slither-disable-next-line unused-return
        (, int256 answer,, uint256 at,) = f.latestRoundData();
        if (answer <= 0 || at == 0 || block.timestamp > at + maxAge || at > block.timestamp + 5 minutes) {
            revert StaleOrBad(address(f));
        }
        return uint256(answer);
    }
}
