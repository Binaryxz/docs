// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Math} from "@openzeppelin/contracts/utils/math/Math.sol";
import {IPriceSource} from "../IPriceSource.sol";

interface IUniswapV3PoolLike {
    function token0() external view returns (address);
    function token1() external view returns (address);
    function liquidity() external view returns (uint128);
    function observe(uint32[] calldata secondsAgos)
        external
        view
        returns (int56[] memory tickCumulatives, uint160[] memory secondsPerLiquidityCumulativeX128s);
}

interface IDecimals {
    function decimals() external view returns (uint8);
}

/**
 * @title UniswapV3TwapSource
 * @notice Reais per USDT from the time-weighted average tick of a Uniswap v3 USDT / BRL-stablecoin pool
 *         (for example BRZ). A `IPriceSource` for the DivergenceBreaker.
 *
 * Immutable: pool, window and the liquidity floor are constructor arguments. It reverts - which the
 * breaker reads as "disagree, halt" - when the pool's history is shorter than the window (`observe`
 * reverts) or when the pool's in-range liquidity is under `MIN_LIQUIDITY`. It never falls back to
 * another source or to the last good value.
 *
 * Manipulability: a TWAP over `WINDOW` seconds in a thin pool is moved by whoever pays to hold the tick
 * for that long. `MIN_LIQUIDITY` is a crude floor (current in-range liquidity, itself readable only
 * as a spot value), not a defence. See DivergenceBreaker, "The cost".
 */
contract UniswapV3TwapSource is IPriceSource {
    IUniswapV3PoolLike public immutable POOL;
    uint32 public immutable WINDOW;
    uint128 public immutable MIN_LIQUIDITY;
    bool public immutable USDT_IS_TOKEN0;
    uint8 public immutable USDT_DECIMALS;
    uint8 public immutable BRL_DECIMALS;

    int256 internal constant MAX_TICK = 887_272;
    uint256 internal constant ONE = 1e27;
    /// @dev 1.0001 at 1e27.
    uint256 internal constant TICK_BASE = 1_000_100_000_000_000_000_000_000_000;

    error BadPool();
    error BadWindow();
    error ThinLiquidity(uint128 liquidity, uint128 minimum);
    error TickOutOfRange(int256 tick);
    error RateOutOfRange();

    constructor(address pool, address usdt, address brlToken, uint32 window, uint128 minLiquidity) {
        if (pool == address(0) || usdt == address(0) || brlToken == address(0)) revert BadPool();
        if (window < 60 || window > 7 days) revert BadWindow();
        IUniswapV3PoolLike p = IUniswapV3PoolLike(pool);
        address t0 = p.token0();
        address t1 = p.token1();
        if (!((t0 == usdt && t1 == brlToken) || (t0 == brlToken && t1 == usdt))) revert BadPool();
        POOL = p;
        WINDOW = window;
        MIN_LIQUIDITY = minLiquidity;
        USDT_IS_TOKEN0 = t0 == usdt;
        USDT_DECIMALS = IDecimals(usdt).decimals();
        BRL_DECIMALS = IDecimals(brlToken).decimals();
    }

    /// @inheritdoc IPriceSource
    function brlPerUsdtE18() external view returns (uint256 rate) {
        uint128 liq = POOL.liquidity();
        if (liq < MIN_LIQUIDITY || liq == 0) revert ThinLiquidity(liq, MIN_LIQUIDITY);
        uint32[] memory ago = new uint32[](2);
        ago[0] = WINDOW;
        // The seconds-per-liquidity accumulator is not needed.
        // slither-disable-next-line unused-return
        (int56[] memory cum,) = POOL.observe(ago);
        int256 delta = int256(cum[1]) - int256(cum[0]);
        int256 tick = delta / int256(uint256(WINDOW));
        // Round toward negative infinity, as Uniswap's own oracle library does.
        if (delta < 0 && delta % int256(uint256(WINDOW)) != 0) tick--;
        // ratio = token1 raw units per token0 raw unit = 1.0001^tick, at 1e27.
        uint256 ratio = _ratioAtTick(tick);
        uint256 uScale = 10 ** USDT_DECIMALS;
        uint256 bScale = 10 ** BRL_DECIMALS;
        if (USDT_IS_TOKEN0) {
            // BRL raw per USDT raw.
            rate = Math.mulDiv(ratio, uScale * 1e18, bScale * ONE);
        } else {
            // ratio = USDT raw per BRL raw; invert.
            rate = Math.mulDiv(ONE * uScale, 1e18, ratio * bScale);
        }
        if (rate == 0) revert RateOutOfRange();
    }

    /// @dev 1.0001^tick at 1e27 by square-and-multiply. Each step rounds down by at most 1e-27, so the
    ///      error across 20 steps is far below a basis point at any tick a BRL pool can reach.
    function _ratioAtTick(int256 tick) internal pure returns (uint256 r) {
        uint256 abs = uint256(tick < 0 ? -tick : tick);
        if (abs > uint256(MAX_TICK)) revert TickOutOfRange(tick);
        r = ONE;
        uint256 b = TICK_BASE;
        while (abs != 0) {
            if (abs & 1 == 1) r = Math.mulDiv(r, b, ONE);
            abs >>= 1;
            if (abs != 0) b = Math.mulDiv(b, b, ONE);
        }
        if (tick < 0) r = Math.mulDiv(ONE, ONE, r);
    }
}
