// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {ERC4626} from "@openzeppelin/contracts/token/ERC20/extensions/ERC4626.sol";
import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {Math} from "@openzeppelin/contracts/utils/math/Math.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {IMovvaReserve} from "./IMovvaReserve.sol";

/**
 * @title SavingsMovva
 * @notice sMovva: an ERC-4626 vault over Movva whose share price rises as the reserve distributes
 *         surplus into it. Design: docs/movva.md, "Savings".
 *
 * ## Why a share price, and not a reward
 *
 * For the same reason `YieldVault` is one. Savers hold sMovva inside a Privacy Pool, and a pool
 * note is a fixed amount that cannot grow. A reward paid to a note would link the note to the
 * payment; a rising share price pays every note at once, touches none, and reveals nothing. To the
 * `ShieldedYieldRouter` this is a plain ERC-4626: it calls `deposit(assets, router)` and
 * `redeem(shares, router, router)` and nothing else, and neither is limited here.
 *
 * ## Why distributions vest
 *
 * `MovvaReserve.distribute` mints Movva into this contract in one transaction, and anyone can call
 * it. If that Movva counted at once, a searcher could deposit a large balance in the block before a
 * distribution, withdraw in the block after, and take a share of yield that savers waited days
 * for - with capital that was here for twelve seconds. So a distribution is excluded from
 * `totalAssets` when it arrives and released linearly over `VESTING_PERIOD`. A deposit made just
 * before and withdrawn just after earns the fraction that vested in between: nothing, within a
 * block.
 *
 * A new distribution is refused while the previous one is still vesting (`StillVesting`), as
 * Ethena's sUSDe does. The alternative - folding the unvested remainder into a fresh period - lets
 * anyone who calls `distribute` every block with a dust surplus push everyone's yield back
 * indefinitely: the remainder decays geometrically instead of reaching zero. Refusing costs at most
 * a delay of one period, and nothing is lost by it: the reserve's distribution allowance keeps
 * accruing, up to a day's worth, while this vests.
 *
 * ## Inflation attack
 *
 * The same decimals offset as `YieldVault`: six virtual decimals, so a first depositor cannot rob the
 * next by donating. The reserve will not distribute into a vault with less than one whole share
 * outstanding (`NoSavers`), because the virtual shares would absorb nearly all of it: the Movva would
 * not be stolen, only stuck, backed and in circulation for nobody.
 *
 * ## What no one can do
 *
 * There is no governor. The reserve is fixed at deployment and can only add Movva, through
 * `notifyDistribution`. Nobody can pause, take or redirect a saver's Movva.
 */
contract SavingsMovva is ERC4626, ReentrancyGuard {
    /// @notice Bounds on the vesting period chosen at deployment.
    uint256 public constant MIN_VESTING_PERIOD = 1 hours;
    uint256 public constant MAX_VESTING_PERIOD = 7 days;

    /// @notice The only address that can notify a distribution.
    address public immutable RESERVE;
    /// @notice How long each distribution takes to count in full.
    uint256 public immutable VESTING_PERIOD;

    /// @notice The last distribution, and when it started vesting.
    uint256 public vestingAmount;
    uint64 public vestingStart;

    event DistributionNotified(uint256 amount, uint256 vestedAt);

    error NotReserve();
    error BadVestingPeriod(uint256 period);
    error StillVesting(uint256 unvested);
    error NoSavers();
    error NotFunded(uint256 amount, uint256 balance);

    constructor(IMovvaReserve reserve_, uint256 vestingPeriod)
        ERC20("Savings Movva", "sMOVVA")
        ERC4626(IERC20(reserve_.MOVVA()))
    {
        if (vestingPeriod < MIN_VESTING_PERIOD || vestingPeriod > MAX_VESTING_PERIOD) {
            revert BadVestingPeriod(vestingPeriod);
        }
        RESERVE = address(reserve_);
        VESTING_PERIOD = vestingPeriod;
    }

    /// @dev Six decimals of offset, as YieldVault: sMovva has 24 decimals.
    function _decimalsOffset() internal pure override returns (uint8) {
        return 6;
    }

    /*//////////////////////////////////////////////////////////////
                               ACCOUNTING
    //////////////////////////////////////////////////////////////*/

    /// @notice Of the last distribution, what has not vested yet. Rounded up, so assets round down.
    function unvested() public view returns (uint256) {
        uint256 elapsed = block.timestamp - vestingStart;
        if (elapsed >= VESTING_PERIOD) return 0;
        return Math.mulDiv(vestingAmount, VESTING_PERIOD - elapsed, VESTING_PERIOD, Math.Rounding.Ceil);
    }

    /// @notice Movva held, less what is still vesting.
    function totalAssets() public view override returns (uint256) {
        uint256 held = IERC20(asset()).balanceOf(address(this));
        uint256 locked = unvested();
        // Exits pay out of vested assets only, so held never falls below locked; saturate anyway,
        // because a reverting totalAssets would freeze every share.
        return held > locked ? held - locked : 0;
    }

    /*//////////////////////////////////////////////////////////////
                              DISTRIBUTION
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Reserve only: `amount` Movva has just been minted to this contract; vest it.
     * @dev Refused while the previous distribution vests (see the header), and into a vault with
     *      less than one whole share, where the virtual shares would absorb it.
     */
    function notifyDistribution(uint256 amount) external nonReentrant {
        if (msg.sender != RESERVE) revert NotReserve();
        uint256 still = unvested();
        if (still != 0) revert StillVesting(still);
        if (totalSupply() < 10 ** decimals()) revert NoSavers();
        uint256 held = IERC20(asset()).balanceOf(address(this));
        if (held < amount) revert NotFunded(amount, held);
        vestingAmount = amount;
        vestingStart = uint64(block.timestamp);
        emit DistributionNotified(amount, block.timestamp + VESTING_PERIOD);
    }

    /*//////////////////////////////////////////////////////////////
                             ERC-4626 ENTRY
    //////////////////////////////////////////////////////////////*/

    // Movva has no transfer hooks, so none of these can be re-entered through the asset. The guard
    // is cheap and keeps that true of any path the vault grows.

    function deposit(uint256 assets, address receiver) public override nonReentrant returns (uint256) {
        return super.deposit(assets, receiver);
    }

    function mint(uint256 shares, address receiver) public override nonReentrant returns (uint256) {
        return super.mint(shares, receiver);
    }

    function withdraw(uint256 assets, address receiver, address owner)
        public
        override
        nonReentrant
        returns (uint256)
    {
        return super.withdraw(assets, receiver, owner);
    }

    function redeem(uint256 shares, address receiver, address owner)
        public
        override
        nonReentrant
        returns (uint256)
    {
        return super.redeem(shares, receiver, owner);
    }
}
