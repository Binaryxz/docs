// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/**
 * @title IPriceSource
 * @notice One independent reading of reais per whole USDT, for the DivergenceBreaker to compare
 *         with the reserve's own rate. Never a substitute for it: a source that cannot answer is
 *         read as DISAGREEING (the breaker halts), not as absent. The one exception is a source dead
 *         for the breaker's whole `DEAD_AFTER`, which stops counting for redemptions only (SRM1-7).
 */
interface IPriceSource {
    /// @notice Reais per ONE whole USDT, scaled 1e18. MUST revert if there is no fresh, deep-enough
    ///         reading. Returning a stale or zero rate silently is the failure this interface prevents.
    function brlPerUsdtE18() external view returns (uint256 rate);
}

/**
 * @notice What MovvaReserve asks of the breaker: revert if the sources disagree.
 * @dev `check` and `checkRedeem` are not `view`: a call that passes records that every source it read
 *      answered, which withdraws any open dead-source claim against them (DivergenceBreaker, "Dead
 *      sources"). They never record a source as dead; only `poke` does.
 */
interface IDivergenceBreaker {
    /// @notice Reverts while the sources disagree beyond the band, or any tripping source cannot answer
    ///         (mint-side and hedge flows). A long-dead source still halts here.
    function check(uint256 primaryRateE18) external;
    /// @notice As `check`, but a no-op when this breaker was deployed not to halt redemptions, and a
    ///         tripping source dead for `DEAD_AFTER` is left out instead of halting.
    function checkRedeem(uint256 primaryRateE18) external;
    /// @notice True while `check` would pass: the sources are in band (or a source with `trips` false is not).
    function inBand(uint256 primaryRateE18) external view returns (bool);
}
