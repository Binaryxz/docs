// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IPriceOracle} from "../ramp/IPriceOracle.sol";
import {BandRead} from "../ramp/IBandPriceOracle.sol";

/**
 * @title ScaledFxBandOracle
 * @notice The signed BRL-per-USD rate at 1e-6, re-expressed as BRL centavos per US dollar, so the
 *         ramps' band and the Movva reserve read ONE signed number.
 *
 * ## Why this exists
 *
 * `MovvaReserve` mints and redeems at the FX rate, and a centavo tick - 0.19% of R$ 5,40 - is too
 * coarse for that: a gateway could choose which side of a tick to mint on. So its FX leg is a
 * `SignedPriceOracle` instance whose publishers sign reais per dollar scaled by 1e6 (5.4012 is
 * 5_401_200). The ramps' `ChainlinkSignedFxOracle` wants centavos per dollar (540). Two instances,
 * signed separately, would be two numbers that can disagree, and two chances for a publisher's
 * tooling to sign the wrong unit into the wrong contract. This adapter lets the ramps' cross use
 * the reserve's instance: point `ChainlinkSignedFxOracle.usdBrl` here, and publishers sign once.
 *
 * ## What it does, and what it leaves to the caller
 *
 * It divides by 1e4 and rounds to the nearest centavo, as `ChainlinkSignedFxOracle` rounds its
 * product: this is a band's midpoint, and flooring would bias it down by up to half a centavo.
 * It passes the source's `publishedAt` through unchanged and does not judge freshness itself:
 * `ChainlinkSignedFxOracle` checks the FX leg against its own `fxMaxAge` and refuses a timestamp
 * from the future, and the escrows check the result against `MAX_PRICE_AGE`. A source with no
 * price yet reverts (`SignedPriceOracle.NoPriceYet`), and so does this; so does a source whose
 * setup is still open (`SetupIncomplete`); a rate that rounds to zero centavos is refused rather
 * than returned.
 *
 * No governance of its own: the source is immutable, so this adapter adds no lever. Whoever reads
 * it inherits exactly the source's governance - PythFxOracle's delayed feed and limit changes, or a
 * SignedPriceOracle's delayed publisher and threshold changes. Repointing the ramps at another rate
 * is the ramps' `setLegs`, which waits out that oracle's governance delay.
 *
 * ## A band, off-hours
 *
 * Everything that reads this is a band, so it reads its source as a band (BandRead): a PythFxOracle's
 * `brlCentsPerUnitForBand`, which serves the last close, stamped current, while the FX market is
 * closed. The ramps keep trading off-hours; the reserve, which reads the source's rate directly, does
 * not mint on it. A source without a band reading is read as before.
 */
contract ScaledFxBandOracle is IPriceOracle {
    /// @notice BRL per US dollar, scaled 1e6: a PythFxOracle, or a SignedPriceOracle signed in that unit.
    IPriceOracle public immutable SOURCE;
    /// @notice 1e6 (the source's scale) over 1e2 (centavos per real).
    uint256 public constant SCALE = 1e4;

    error ZeroAddress();
    error PriceRoundsToZero();

    constructor(IPriceOracle source) {
        if (address(source) == address(0)) revert ZeroAddress();
        SOURCE = source;
    }

    /// @inheritdoc IPriceOracle
    /// @dev Centavos per ONE US dollar, nearest; `updatedAt` is the source's band reading's.
    function brlCentsPerUnit() external view returns (uint256 price, uint64 updatedAt) {
        uint256 e6;
        (e6, updatedAt) = BandRead.read(SOURCE);
        price = (e6 + SCALE / 2) / SCALE;
        if (price == 0) revert PriceRoundsToZero();
    }
}
