// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {ERC20Permit} from "@openzeppelin/contracts/token/ERC20/extensions/ERC20Permit.sol";

/**
 * @title Movva
 * @notice A BRL-pegged token: one Movva is R$ 1,00. Design: docs/movva.md.
 *
 * ## Who can create and destroy it
 *
 * Only `RESERVE`, and `RESERVE` is whoever deployed this contract. `MovvaReserve` deploys the
 * token in its own constructor, so the two addresses are bound in one transaction and neither
 * can ever point anywhere else: there is no setter, no owner and no upgrade.
 *
 * The alternatives were worse. A token taking the reserve's address as a constructor argument
 * needs that address before the reserve exists, which means predicting a CREATE address from a
 * deployer nonce - one stray transaction from that key between the two deployments and the token
 * trusts an address nobody controls, with no way to fix it. A token with a one-shot
 * `setReserve` has a window in which whoever calls it first owns the money supply. Deploying the
 * token from the reserve has neither: by the time anyone can see the token, its minter is fixed.
 *
 * ## What the reserve can and cannot do to a holder
 *
 * `mint` creates Movva for anyone. `burn` destroys Movva the reserve ITSELF holds - there is no
 * `burnFrom` that skips an allowance. A redeeming gateway transfers its Movva to the reserve (by
 * allowance or permit) and the reserve burns its own balance. So even a bug in the reserve could
 * not destroy a balance in anyone else's wallet, a Privacy Pool or an escrow.
 *
 * ## What it deliberately lacks
 *
 * No pause, no blacklist, no freeze. Whether a regulated issuer must be able to freeze Movva is an
 * open legal question (docs/movva.md, "Still to decide"); until it is answered the token has no such
 * power rather than an unused one somebody could be ordered, or tricked, to use. Compliance today
 * sits at the edges: gateway KYC, Mova's ASP and viewing keys.
 */
contract Movva is ERC20Permit {
    /// @notice The only address that can mint, and the only balance that can be burned.
    address public immutable RESERVE;

    error NotReserve();

    constructor() ERC20("Movva", "MOVVA") ERC20Permit("Movva") {
        RESERVE = msg.sender;
    }

    /// @notice Reserve only: create `amount` Movva for `to`.
    function mint(address to, uint256 amount) external {
        if (msg.sender != RESERVE) revert NotReserve();
        _mint(to, amount);
    }

    /// @notice Reserve only: destroy `amount` of the reserve's own Movva.
    function burn(uint256 amount) external {
        if (msg.sender != RESERVE) revert NotReserve();
        _burn(msg.sender, amount);
    }
}
