// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IPriceSource, IDivergenceBreaker} from "./IPriceSource.sol";

/**
 * @title DivergenceBreaker
 * @notice A self-clearing, keyless circuit breaker for MovvaReserve (client decision, 24 Sep 2026,
 *         "Breaker": it pauses automatically when prices diverge and resumes when they return to
 *         band; no key needed; if BRL liquidity is thin it pauses, it does not substitute a source).
 *
 * ## What it is
 *
 * Immutable and ownerless: no owner, no setter, no role. The verdict is a function of the sources'
 * CURRENT answers, so there is nothing to latch and nothing to lift: the moment the sources agree
 * again `check` stops reverting. Its only state is one word of dead-source claims (below), which
 * can relax the redemption verdict for a source that is dead, and can never cause a halt.
 *
 * It compares the reserve's own rate (Chainlink USDT/USD x Pyth FX.USD/BRL, passed in by the
 * reserve) with N further `IPriceSource`s. Among the reserve's rate and every source flagged
 * `trips`, the spread must satisfy `max - min <= min x BAND_BPS / 10_000`. A tripping source that
 * cannot answer counts as DISAGREEING: the breaker halts, it never drops the source and carries
 * on (that would let an attacker who can knock a source out choose the set that is compared). A
 * source with `trips` false is informational only (`sourceRates`, for the monitor).
 *
 * ## Dead sources (SRM1-7)
 *
 * A source is DEAD at a given moment when `brlPerUsdtE18()`, given `SOURCE_GAS`, reverts (which is
 * what each source does when its own reading is stale beyond its own max age, too thin, or out of
 * range), returns anything but 32 bytes, or returns zero. Without more, a source that dies for good
 * - a deprecated Chainlink feed, a migrated or drained pool - would halt the breaker for ever, and
 * with `HALTS_REDEEM` every USDT exit with it.
 *
 * So a tripping source that has been dead for `DEAD_AFTER` (an immutable, 7 to 365 days) stops
 * counting for REDEMPTIONS: `checkRedeem` leaves it out and compares the rest. Mint and hedge
 * withdrawals (`check`) still halt on it for ever. Those grow or shrink the backing on a degraded
 * set of prices and are not a holder's exit; redemption is, and an exit must never be locked for
 * ever by a dead source. The cost: after `DEAD_AFTER` a redemption is priced by the remaining
 * sources and the reserve's own rate, as if that source had never been configured.
 *
 * "Dead for `DEAD_AFTER`" is established on-chain, never assumed:
 *  - ANYONE may `poke`. A tripping source that is dead in the poke, with no open claim, gets one:
 *    `deadSince` = now (`SourceReportedDead`). An open claim is never moved later or earlier.
 *  - Every `poke`, and every `check` and `checkRedeem` that passes, withdraws the claim of every
 *    source it read answering (`SourceAlive`). A reserve in use clears claims by itself: any mint,
 *    redemption or hedge withdrawal that passes is proof the sources it read are alive.
 *  - `checkRedeem` leaves a source out only if it is dead in THAT call AND its claim is at least
 *    `DEAD_AFTER` old. A source that answers is always compared, whatever its claim says.
 *
 * Why a live source cannot be made to look dead. To leave a source out of a redemption, an attacker
 * needs a claim that has stood unwithdrawn for `DEAD_AFTER`, and the source dead in that call.
 *  - A claim is withdrawn by the first successful read of the source in any `poke` or passing
 *    check. One transaction from anyone - a monitor, a gateway, a holder - while the source answers
 *    withdraws it; the attacker would have to keep the source dead in every block anyone reads it,
 *    for the whole of `DEAD_AFTER`, and a source that can be kept dead that long is dead. A poke sent
 *    through a private relay cannot be sandwiched to make a thin TWAP fail around it.
 *  - Gas cannot fake death. Each read is capped at `SOURCE_GAS`; `poke` refuses outright, and
 *    `checkRedeem` refuses to leave a source out, unless the read had all of it (`InsufficientGas`).
 *    A read starved by its caller is never taken as a dead source.
 *  - A claim never halts anything: `check` ignores claims, and `checkRedeem` consults one only for a
 *    source that already failed in that call, and only to leave it out.
 * During a real divergence the diverging source ANSWERS - divergence is not death - so a poke or
 * any passing check withdraws its claim and it keeps halting redemptions.
 *
 * Residual: a claim on a source that recovered stands until someone reads that source successfully.
 * If nobody pokes and no mint, redemption or hedge withdrawal passes for `DEAD_AFTER`, the next
 * moment that source fails a redemption would leave it out. The monitor alerts on any open claim
 * against a source that answers; the runbook says to `poke` it (packages/ops, `movva_breaker`).
 *
 * ## The cost: a denial-of-service lever
 *
 * A tripping source is a switch for the halt. A thin-liquidity Uniswap TWAP can be moved by anyone
 * with capital for the window it averages over, so whoever can move it can stop mint and redeem for
 * as long as they pay to hold it there. That is what the client asked for and what this implements;
 * the band and which sources trip are deploy-time constants so it can be tuned (wide band, deep pool,
 * long window) or the TWAP made non-tripping. docs/movva.md, "The divergence breaker", sets out the
 * median-of-three alternative (strong feeds trip the halt, the TWAP only moves a median).
 */
contract DivergenceBreaker is IDivergenceBreaker {
    struct SourceConfig {
        IPriceSource source;
        bool trips;
    }

    uint16 public constant BPS = 10_000;
    uint256 public constant MAX_SOURCES = 8;
    /// @notice Bounds on `DEAD_AFTER`. Below a week a held manipulation, or a monitor's weekend, is
    ///         too close; above a year an exit waits too long on a retired source.
    uint64 public constant MIN_DEAD_AFTER = 7 days;
    uint64 public constant MAX_DEAD_AFTER = 365 days;
    /// @notice Gas each source read gets. A source that needs more is dead.
    uint256 public constant SOURCE_GAS = 500_000;
    /// @dev Gas that must be left before a read for the source to receive all of SOURCE_GAS after
    ///      EIP-150's 63/64 and the call's own cost. Below it a failed read proves nothing.
    uint256 internal constant READ_GAS_FLOOR = SOURCE_GAS + SOURCE_GAS / 63 + 10_000;
    uint256 internal constant NONE = type(uint256).max;

    /// @notice Widest allowed disagreement among the compared rates, in basis points of the lowest.
    uint16 public immutable BAND_BPS;
    /// @notice Whether the breaker also stops `redeem`. True follows the client; false keeps exits open.
    bool public immutable HALTS_REDEEM;
    /// @notice How long a tripping source must have been dead, on an unwithdrawn claim, before
    ///         `checkRedeem` leaves it out. `check` (mint, hedge) never does.
    uint64 public immutable DEAD_AFTER;

    IPriceSource[] internal _sources;
    bool[] internal _trips;
    /// @dev Eight 32-bit timestamps, source i in bits [32i, 32i + 32): when an open claim says source i
    ///      died. Zero: no claim. 32 bits of seconds last until 2106.
    uint256 internal _claims;

    /// @notice A tripping source was found dead with no open claim against it; its clock starts at `since`.
    event SourceReportedDead(uint256 indexed index, uint256 since);
    /// @notice A source with an open claim answered; the claim, dated `deadSince`, is withdrawn.
    event SourceAlive(uint256 indexed index, uint256 deadSince);

    error BadBand();
    error BadSources();
    error BadDeadAfter();
    error InsufficientGas();
    error SourceUnavailable(uint256 index);
    error SourcesDiverge(uint256 low, uint256 high, uint256 bandBps);

    constructor(uint16 bandBps, bool haltsRedeem, uint64 deadAfter, SourceConfig[] memory cfg) {
        if (bandBps == 0 || bandBps >= BPS) revert BadBand();
        if (deadAfter < MIN_DEAD_AFTER || deadAfter > MAX_DEAD_AFTER) revert BadDeadAfter();
        if (cfg.length == 0 || cfg.length > MAX_SOURCES) revert BadSources();
        BAND_BPS = bandBps;
        HALTS_REDEEM = haltsRedeem;
        DEAD_AFTER = deadAfter;
        for (uint256 i; i < cfg.length; ++i) {
            if (address(cfg[i].source) == address(0)) revert BadSources();
            _sources.push(cfg[i].source);
            _trips.push(cfg[i].trips);
        }
    }

    function sourceCount() external view returns (uint256) {
        return _sources.length;
    }

    function sourceAt(uint256 i) external view returns (IPriceSource source, bool trips) {
        return (_sources[i], _trips[i]);
    }

    /// @notice When the open claim against source `i` says it died; zero for none.
    function deadSince(uint256 i) public view returns (uint256) {
        if (i >= _sources.length) revert BadSources();
        return _claimOf(_claims, i);
    }

    /// @notice True when source `i` has an open claim at least `DEAD_AFTER` old. It is then left out
    ///         of a redemption - but only while it is also dead in that redemption.
    function longDead(uint256 i) external view returns (bool) {
        if (i >= _sources.length) revert BadSources();
        return _isLongDead(_claims, i);
    }

    /// @inheritdoc IDivergenceBreaker
    function check(uint256 primaryRateE18) public {
        _enforce(primaryRateE18, false);
    }

    /// @inheritdoc IDivergenceBreaker
    function checkRedeem(uint256 primaryRateE18) external {
        if (HALTS_REDEEM) _enforce(primaryRateE18, true);
    }

    /// @inheritdoc IDivergenceBreaker
    function inBand(uint256 primaryRateE18) external view returns (bool) {
        (bool ok,,, uint256 bad,) = _evaluate(primaryRateE18, false);
        return ok && bad == NONE;
    }

    /// @notice True while `checkRedeem` would pass (always, with `HALTS_REDEEM` false). For the monitor.
    function redeemOpen(uint256 primaryRateE18) external view returns (bool) {
        if (!HALTS_REDEEM) return true;
        (bool ok,,, uint256 bad,) = _evaluate(primaryRateE18, true);
        return ok && bad == NONE;
    }

    /**
     * @notice Anyone: read every tripping source with its full gas. A dead one with no open claim
     *         gets one dated now; a live one has its claim withdrawn. Nothing here can halt or
     *         release anything by itself: see "Dead sources" in the header.
     */
    function poke() external {
        uint256 claims = _claims;
        uint256 next = claims;
        uint256 n = _sources.length;
        for (uint256 i; i < n; ++i) {
            if (!_trips[i]) continue;
            if (gasleft() < READ_GAS_FLOOR) revert InsufficientGas();
            (bool good,) = _read(_sources[i]);
            uint256 since = _claimOf(claims, i);
            if (good) {
                if (since != 0) {
                    next = _setClaim(next, i, 0);
                    emit SourceAlive(i, since);
                }
            } else if (since == 0) {
                next = _setClaim(next, i, block.timestamp);
                emit SourceReportedDead(i, block.timestamp);
            }
        }
        if (next != claims) _claims = next;
    }

    /// @notice Every source's current answer, for the monitor: 0 where a source cannot answer.
    function sourceRates() external view returns (uint256[] memory rates) {
        rates = new uint256[](_sources.length);
        for (uint256 i; i < rates.length; ++i) {
            (, uint256 r) = _read(_sources[i]);
            rates[i] = r;
        }
    }

    function _enforce(uint256 primary, bool redeem) internal {
        (bool ok, uint256 low, uint256 high, uint256 bad, uint256 alive) = _evaluate(primary, redeem);
        if (bad != NONE) revert SourceUnavailable(bad);
        if (!ok) revert SourcesDiverge(low, high, BAND_BPS);
        _withdrawClaims(alive);
    }

    /**
     * @dev The verdict. `redeem` leaves out a tripping source that is dead now and long dead on its
     *      claim, and only after a read that had all of SOURCE_GAS. `alive` has bit i set for every
     *      tripping source that answered.
     */
    function _evaluate(uint256 primary, bool redeem)
        internal
        view
        returns (bool ok, uint256 low, uint256 high, uint256 bad, uint256 alive)
    {
        bad = NONE;
        low = primary;
        high = primary;
        uint256 claims = redeem ? _claims : 0;
        uint256 n = _sources.length;
        for (uint256 i; i < n; ++i) {
            if (!_trips[i]) continue;
            bool fullGas = gasleft() >= READ_GAS_FLOOR;
            (bool good, uint256 r) = _read(_sources[i]);
            if (good) {
                alive |= 1 << i;
                if (r < low) low = r;
                if (r > high) high = r;
                continue;
            }
            if (redeem && _isLongDead(claims, i)) {
                // Never take a starved read as death: the caller must give the source its gas.
                if (!fullGas) revert InsufficientGas();
                continue;
            }
            if (bad == NONE) bad = i;
        }
        ok = low != 0 && (high - low) * BPS <= low * BAND_BPS;
    }

    /// @dev Withdraw the open claims of the sources in `alive`. One read of the claims word; a write
    ///      only when there was a claim to withdraw.
    function _withdrawClaims(uint256 alive) internal {
        uint256 claims = _claims;
        if (claims == 0 || alive == 0) return;
        uint256 next = claims;
        uint256 n = _sources.length;
        for (uint256 i; i < n; ++i) {
            if (alive & (1 << i) == 0) continue;
            uint256 since = _claimOf(claims, i);
            if (since == 0) continue;
            next = _setClaim(next, i, 0);
            emit SourceAlive(i, since);
        }
        if (next != claims) _claims = next;
    }

    function _isLongDead(uint256 claims, uint256 i) internal view returns (bool) {
        uint256 since = _claimOf(claims, i);
        return since != 0 && block.timestamp >= since + DEAD_AFTER;
    }

    function _claimOf(uint256 claims, uint256 i) internal pure returns (uint256) {
        return (claims >> (32 * i)) & type(uint32).max;
    }

    function _setClaim(uint256 claims, uint256 i, uint256 at) internal pure returns (uint256) {
        uint256 shift = 32 * i;
        return (claims & ~(uint256(type(uint32).max) << shift)) | (uint256(uint32(at)) << shift);
    }

    /**
     * @dev One read, capped at SOURCE_GAS, copying at most 32 bytes back. Good only for exactly 32
     *      bytes of a non-zero rate.
     */
    function _read(IPriceSource s) internal view returns (bool good, uint256 rate) {
        bytes4 selector = IPriceSource.brlPerUsdtE18.selector;
        uint256 gasCap = SOURCE_GAS;
        bool success;
        uint256 size;
        assembly ("memory-safe") {
            mstore(0x00, selector)
            success := staticcall(gasCap, s, 0x00, 0x04, 0x00, 0x20)
            size := returndatasize()
            rate := mload(0x00)
        }
        if (!success || size != 32) return (false, 0);
        good = rate != 0;
    }
}
