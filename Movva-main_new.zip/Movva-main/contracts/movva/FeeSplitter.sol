// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";

/// @dev What the splitter needs of NodeRewards.
interface INodeRewardsFunding {
    function REWARD_TOKEN() external view returns (IERC20);
    function sync() external returns (uint256);
}

/**
 * @title FeeSplitter
 * @notice Mova's fee revenue, split: `lpRewardShareBps` of the Movva it receives to NodeRewards, for the LPs who
 *         settle BRL volume, and the rest to Mova's treasury. DeployMovva makes it `MovvaReserve.feeRecipient`.
 *         Design: docs/movva.md, "Fees". Threat model: SR2-36 in docs/security-review-phase2.md.
 *
 * The reserve pays its fees by minting or transferring Movva to the fee recipient, with no callback, so fees
 * accumulate here until anyone calls `split()`. Whatever is here when it is called splits at the share in force at
 * that moment.
 *
 * ## The share
 *
 * It starts at zero: until Mova chooses a number, every fee reaches the treasury exactly as it did before this
 * contract existed. Raising it waits out GOVERNANCE_DELAY - a larger reward is a larger prize for manufacturing
 * volume (SR2-36), so LPs and the monitor get notice - and it can never pass MAX_LP_REWARD_SHARE_BPS (50%). Lowering
 * it is instant.
 *
 * Changing the treasury waits: it is where Mova's revenue goes, the rule the reserve applies to its own fee
 * recipient. Pointing at a new rewards contract waits; removing it (zero) is instant and sends everything to the
 * treasury, as a share of zero would.
 *
 * ## What it does not do
 *
 * It holds no reserve USDT and mints nothing. It moves only TOKEN, and only to the treasury and the rewards contract;
 * there is no sweep, so any other token sent here stays here. It does not decide who earns - NodeRewards does. And a
 * rewards contract that refuses its `sync` cannot stop the treasury being paid: the tokens it was sent are booked by
 * the next `sync` anyone sends, into the epoch current then.
 */
contract FeeSplitter is DelayedGovernance, ReentrancyGuard {
    using SafeERC20 for IERC20;

    uint16 public constant BPS = 10_000;
    /// @notice The LPs' share can never pass half of Mova's fee revenue.
    uint16 public constant MAX_LP_REWARD_SHARE_BPS = 5_000;

    /// @notice The fee token: Movva.
    IERC20 public immutable TOKEN;
    /// @notice Mova's treasury: everything that is not the LPs' share.
    address public treasury;
    /// @notice NodeRewards; zero sends the whole of every split to the treasury.
    address public rewards;
    uint16 public lpRewardShareBps;

    event Split(uint256 total, uint256 toRewards, uint256 toTreasury);
    event TreasurySet(address indexed treasury);
    event RewardsSet(address indexed rewards);
    event LpRewardShareSet(uint16 bps);
    /// @notice The rewards contract was paid but refused to book it; the next `sync` anyone sends books it.
    event RewardsSyncFailed(address indexed rewards);

    error ShareTooHigh();
    error RewardsTokenMismatch();

    constructor(address token, address treasury_, address rewards_, address governor_, uint256 governanceDelay)
        DelayedGovernance(governor_, governanceDelay)
    {
        if (token == address(0) || treasury_ == address(0)) revert ZeroAddress();
        TOKEN = IERC20(token);
        treasury = treasury_;
        if (rewards_ != address(0)) _checkRewards(rewards_);
        rewards = rewards_;
    }

    /**
     * @notice Send everything here: the LPs' share to the rewards contract, the rest to the treasury. Anyone may call.
     * @dev Rounded down for the LPs, so the treasury takes the remainder and nothing is left behind.
     */
    function split() external nonReentrant returns (uint256 toRewards, uint256 toTreasury) {
        _requireSetupComplete();
        uint256 total = TOKEN.balanceOf(address(this));
        // Nothing to move is a no-op, not an error: a keeper calling on a timer should not revert.
        // slither-disable-next-line incorrect-equality
        if (total == 0) return (0, 0);
        address r = rewards;
        if (r != address(0)) toRewards = (total * lpRewardShareBps) / BPS;
        toTreasury = total - toRewards;
        emit Split(total, toRewards, toTreasury);
        if (toTreasury != 0) TOKEN.safeTransfer(treasury, toTreasury);
        if (toRewards != 0) {
            TOKEN.safeTransfer(r, toRewards);
            // Booked into the epoch it arrives in. A refusal is recorded, never allowed to undo the split.
            // slither-disable-next-line unused-return
            try INodeRewardsFunding(r).sync() returns (uint256) {}
            catch {
                emit RewardsSyncFailed(r);
            }
        }
    }

    /*//////////////////////////////////////////////////////////////
                               GOVERNANCE
    //////////////////////////////////////////////////////////////*/

    /// @notice Raising the LPs' share waits out the delay; lowering it is instant. Never above 50%.
    function setLpRewardShare(uint16 bps) external {
        _authorizeChange(bps > lpRewardShareBps);
        if (bps > MAX_LP_REWARD_SHARE_BPS) revert ShareTooHigh();
        lpRewardShareBps = bps;
        emit LpRewardShareSet(bps);
    }

    /// @notice Delayed: this address is paid Mova's revenue.
    function setTreasury(address t) external {
        _authorizeChange(t != treasury);
        if (t == address(0)) revert ZeroAddress();
        treasury = t;
        emit TreasurySet(t);
    }

    /// @notice A new rewards contract waits out the delay; removing it (zero) is instant.
    /// @dev No zero check on purpose: zero is how the rewards contract is removed.
    function setRewards(address r) external {
        _authorizeChange(r != address(0) && r != rewards);
        if (r != address(0)) _checkRewards(r);
        rewards = r;
        emit RewardsSet(r);
    }

    function _isDelayable(bytes4 selector) internal pure override returns (bool) {
        return selector == FeeSplitter.setLpRewardShare.selector || selector == FeeSplitter.setTreasury.selector
            || selector == FeeSplitter.setRewards.selector;
    }

    /// @dev A rewards contract must pay out the token this splits, or the LPs' share would be stranded there.
    function _checkRewards(address r) private view {
        if (r.code.length == 0 || address(INodeRewardsFunding(r).REWARD_TOKEN()) != address(TOKEN)) {
            revert RewardsTokenMismatch();
        }
    }
}
