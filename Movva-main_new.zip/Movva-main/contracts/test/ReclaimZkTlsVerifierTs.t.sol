// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Governed} from "./utils/Governed.sol";
import {ReclaimZkTlsVerifier} from "../ramp/ReclaimZkTlsVerifier.sol";
import {IAttestorVerifier} from "../ramp/IAttestorVerifier.sol";

/**
 * A proof built by packages/ramp/src/reclaim.ts, verified by the contract.
 *
 * The Solidity tests build proofs with their own helper, and the TypeScript tests check the
 * TypeScript against itself. Neither catches the two disagreeing - on canonical key order,
 * on the provider hash, on what exactly a witness signs - and that disagreement is the
 * Phase 1 bug shape. This fixture was produced by `buildProof` with witness keys 0x11 and
 * 0x02, `hashProviderParams` over the template below, and `encodeProof`:
 *
 *   url      https://api.bank.example/pix/v2/{{e2eId}}   method GET   body ""
 *   matches  [{type: regex, value: "endToEndId":"(?<bankTxId>0x[0-9a-f]{64})"}]
 *   redact   [{jsonPath: $.pix}]
 *
 * Regenerate it if reclaim.ts's encoding changes; if this test fails after such a change,
 * the change broke settlement.
 */
contract ReclaimZkTlsVerifierTsTest is Governed {
    bytes32 constant TS_TEMPLATE = 0xd7b39f13e8f8837b9f70fbc902179092d596e355705935de93bc0289f9782647;
    bytes32 constant ORDER = bytes32(uint256(0xA11CE));

    function _tsProof() internal pure returns (bytes memory) {
        return
            hex"0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000"
            hex"0000000000000000000000000000000000000040000000000000000000000000000000000000000000000000"
            hex"0000000000000480000000000000000000000000000000000000000000000000000000000000006000000000"
            hex"000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000"
            hex"000000000000000000000000000001e000000000000000000000000000000000000000000000000000000000"
            hex"0000000468747470000000000000000000000000000000000000000000000000000000000000000000000000"
            hex"0000000000000000000000000000000000000000000001187b22626f6479223a22222c226d6574686f64223a"
            hex"22474554222c22706172616d56616c756573223a7b226532654964223a224530303030303030303230323630"
            hex"393133227d2c22726573706f6e73654d617463686573223a5b7b2274797065223a227265676578222c227661"
            hex"6c7565223a225c22656e64546f456e6449645c223a5c22283f3c62616e6b547849643e30785b302d39612d66"
            hex"5d7b36347d295c22227d5d2c22726573706f6e7365526564616374696f6e73223a5b7b226a736f6e50617468"
            hex"223a22242e706978222c227265676578223a22222c227850617468223a22227d5d2c2275726c223a22687474"
            hex"70733a2f2f6170692e62616e6b2e6578616d706c652f7069782f76322f7b7b65326549647d7d227d00000000"
            hex"0000000000000000000000000000000000000000000000000000000000000000000002317b22636f6e746578"
            hex"7441646472657373223a22307830303030303030303030303030303030303030303030303030303030303030"
            hex"303030303030303030222c22636f6e746578744d657373616765223a22307830303030303030303030303030"
            hex"3030303030303030303030303030303030303030303030303030303030303030303030303030303030303030"
            hex"30306131316365222c22657874726163746564506172616d6574657273223a7b22616d6f756e7442726c4365"
            hex"6e7473223a2231353030303030222c2262616e6b54784964223a223078373162663339613166343138363362"
            hex"6332333232643062643630316630633139376532373937393861626531623963306534333038366465353939"
            hex"3362646564222c22706169644174223a2231373030303030303030222c2270617965654b657948617368223a"
            hex"2230783637663639613336653566666532636131346136313966613463613036643531336130613761366465"
            hex"3061383862663034303931376465623438613035613838222c227061796572526566223a2230786637386631"
            hex"3565363835626261393761616134323161666333363465323533336636663062336235363064636136313731"
            hex"393239343032303664383036623765222c227261696c223a2231227d2c2270726f766964657248617368223a"
            hex"2230786437623339663133653866383833376239663730666263393032313739303932643539366533353537"
            hex"3035393335646539336263303238396639373832363437227d000000000000000000000000000000c3981528"
            hex"f5840fd1e378768dfdcc26c5ee4e21d52022aa1118fb96e56f59fd7d000000000000000000000000252dae0a"
            hex"4b9d9b80f504f6418acd2d364c0c59cd00000000000000000000000000000000000000000000000000000000"
            hex"6553f10000000000000000000000000000000000000000000000000000000000000000010000000000000000"
            hex"0000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000"
            hex"0000000000000000000000020000000000000000000000000000000000000000000000000000000000000040"
            hex"00000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000"
            hex"00000000000000000000000000000000000000410fa5815e2b986a2021f918a8a9bcb87ac98a7501436afb02"
            hex"88909cea896d100e18b12baf62a8282bfc3bbacef23f8b88cce94f9a30ccbf2435df4f1d73523e0b1c000000"
            hex"0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
            hex"000000000000000000000000000000418d9aa2833b4802c68a8042d082ef58fb3f95686934c80872a5c046e2"
            hex"aa48d6371f20e6155bf61f2d11fba428a61e50acaa59c07dc6332db8481df8258e2636021c00000000000000"
            hex"000000000000000000000000000000000000000000000000";
    }

    function _verifier(bytes32 template, string memory prefix)
        internal
        returns (ReclaimZkTlsVerifier)
    {
        address[] memory set = new address[](2);
        set[0] = vm.addr(0x11);
        set[1] = vm.addr(0x02);
        bytes32[] memory hashes = new bytes32[](1);
        hashes[0] = template;
        string[] memory prefixes = new string[](1);
        prefixes[0] = prefix;
        ReclaimZkTlsVerifier v = new ReclaimZkTlsVerifier(address(0x60F), DELAY, set, 2, hashes, prefixes);
        _completeSetup(address(v));
        return v;
    }

    function test_AProofBuiltByTheTypeScriptClientVerifies() public {
        ReclaimZkTlsVerifier v = _verifier(TS_TEMPLATE, "https://api.bank.example/pix/v2/");
        IAttestorVerifier.Payment memory p = v.verifyPayment(ORDER, _tsProof());
        assertEq(p.bankTxId, keccak256("E2E-TS-0001"));
        assertEq(p.payeeKeyHash, keccak256("seller@pix"));
        assertEq(p.payerRef, keccak256("payer"));
        assertEq(p.amountBrlCents, 1_500_000);
        assertEq(p.paidAt, 1_700_000_000);
        assertEq(uint8(p.rail), uint8(IAttestorVerifier.Rail.PIX));
    }

    /// The provider hash the TypeScript computes is the one the verifier must allowlist.
    function test_TheSameProofIsRefusedUnderAnyOtherTemplateOrHost() public {
        ReclaimZkTlsVerifier other =
            _verifier(keccak256("another template"), "https://api.bank.example/pix/v2/");
        bytes memory proof = _tsProof();
        vm.expectRevert(
            abi.encodeWithSelector(ReclaimZkTlsVerifier.EndpointNotAllowed.selector, TS_TEMPLATE)
        );
        other.verifyPayment(ORDER, proof);

        ReclaimZkTlsVerifier otherHost = _verifier(TS_TEMPLATE, "https://api.otherbank.example/");
        vm.expectRevert(ReclaimZkTlsVerifier.UrlNotAllowed.selector);
        otherHost.verifyPayment(ORDER, proof);
    }
}
