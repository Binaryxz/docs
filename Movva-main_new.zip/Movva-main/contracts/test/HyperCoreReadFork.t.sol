// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import {HyperCore} from "../hyperliquid/HyperCore.sol";

/**
 * The precompile ABI in `HyperCore.sol`, decoded against real HyperEVM mainnet data.
 *
 * A local fork cannot run HyperEVM's precompiles - they are native code in the node, and an
 * `eth_call` to them is answered from live HyperCore state only by a HyperEVM RPC. So this test
 * sends each read as a raw `eth_call` to the RPC and decodes the bytes with the library's own
 * structs. A layout mismatch (a missing field, a wrong width, a string where a number was assumed)
 * fails `abi.decode` or the sanity checks below.
 *
 * Read-only. Skips without HYPEREVM_RPC (mainnet: https://rpc.hyperliquid.xyz/evm, chain 999).
 */
contract HyperCoreReadForkTest is Test {
    /// Circle's CoreDepositWallet, which `tokenInfo(0).evmContract` names as USDC's linked contract.
    address constant CORE_DEPOSIT_WALLET = 0x6B9E773128f453f5c2C60935Ee2DE2CBc5390A24;
    /// Hyperliquidity Provider strategy account used by the research read (a large cross-margin ETH position).
    address constant HLP_STRATEGY = 0x010461C14e146ac35Fe42271BDC1134EE31C703a;
    uint32 constant ETH_PERP = 1;
    uint32 constant HYPE_SPOT = 107;

    string rpcUrl;

    function setUp() public {
        rpcUrl = vm.envOr("HYPEREVM_RPC", string(""));
    }

    function _call(address to, bytes memory data) internal returns (bytes memory) {
        string memory params = string.concat(
            '[{"to":"', vm.toString(to), '","data":"', vm.toString(data), '"},"latest"]'
        );
        return vm.rpc(rpcUrl, "eth_call", params);
    }

    function test_TheReadPrecompilesDecodeRealHyperCoreState() public {
        if (bytes(rpcUrl).length == 0) return;

        HyperCore.PerpAssetInfo memory eth =
            abi.decode(_call(HyperCore.PERP_ASSET_INFO, abi.encode(ETH_PERP)), (HyperCore.PerpAssetInfo));
        assertEq(eth.coin, "ETH");
        assertEq(eth.szDecimals, 4);
        assertGt(eth.maxLeverage, 1);
        assertFalse(eth.onlyIsolated);

        uint64 oracle = abi.decode(_call(HyperCore.ORACLE_PX, abi.encode(ETH_PERP)), (uint64));
        uint64 mark = abi.decode(_call(HyperCore.MARK_PX, abi.encode(ETH_PERP)), (uint64));
        HyperCore.Bbo memory bbo = abi.decode(_call(HyperCore.BBO, abi.encode(ETH_PERP)), (HyperCore.Bbo));
        // Human price = raw / 10^(6 - szDecimals). ETH somewhere between $100 and $100,000.
        assertGt(oracle, 100 * 10 ** (6 - eth.szDecimals));
        assertLt(oracle, 100_000 * 10 ** (6 - eth.szDecimals));
        assertApproxEqRel(mark, oracle, 0.02e18, "mark near oracle");
        assertLe(bbo.bid, bbo.ask, "bid below ask");
        assertApproxEqRel(bbo.bid, oracle, 0.02e18, "book in the oracle's scale");
        emit log_named_uint("ETH oraclePx raw (/100 = USD)", oracle);

        HyperCore.SpotInfo memory hype = abi.decode(_call(HyperCore.SPOT_INFO, abi.encode(HYPE_SPOT)), (HyperCore.SpotInfo));
        assertEq(hype.tokens[1], HyperCore.USDC_TOKEN, "HYPE/USDC quotes in USDC");
        HyperCore.TokenInfo memory hypeToken =
            abi.decode(_call(HyperCore.TOKEN_INFO, abi.encode(uint32(hype.tokens[0]))), (HyperCore.TokenInfo));
        assertEq(hypeToken.name, "HYPE");
        uint64 hypePx = abi.decode(_call(HyperCore.SPOT_PX, abi.encode(HYPE_SPOT)), (uint64));
        // Spot: human = raw / 10^(8 - szDecimals). HYPE between $1 and $10,000.
        assertGt(hypePx, 1 * 10 ** (8 - hypeToken.szDecimals));
        assertLt(hypePx, 10_000 * 10 ** (8 - hypeToken.szDecimals));

        HyperCore.TokenInfo memory usdc =
            abi.decode(_call(HyperCore.TOKEN_INFO, abi.encode(uint32(0))), (HyperCore.TokenInfo));
        assertEq(usdc.name, "USDC");
        assertEq(usdc.weiDecimals, 8);
        assertEq(usdc.evmContract, CORE_DEPOSIT_WALLET, "USDC links to Circle's CoreDepositWallet");
        assertEq(usdc.evmExtraWeiDecimals, -2);

        HyperCore.AccountMarginSummary memory acct = abi.decode(
            _call(HyperCore.ACCOUNT_MARGIN_SUMMARY, abi.encode(uint32(0), HLP_STRATEGY)),
            (HyperCore.AccountMarginSummary)
        );
        HyperCore.Position memory pos =
            abi.decode(_call(HyperCore.POSITION, abi.encode(HLP_STRATEGY, uint16(ETH_PERP))), (HyperCore.Position));
        uint64 w = abi.decode(_call(HyperCore.WITHDRAWABLE, abi.encode(HLP_STRATEGY)), (uint64));
        assertGe(acct.accountValue, 0);
        assertLe(uint256(acct.marginUsed), uint256(acct.ntlPos) + 1, "margin used within notional");
        assertLe(uint256(w), uint256(uint64(acct.accountValue)) + 1, "withdrawable within account value");
        emit log_named_int("HLP strategy ETH szi", pos.szi);

        HyperCore.SpotBalance memory cdwUsdc = abi.decode(
            _call(HyperCore.SPOT_BALANCE, abi.encode(CORE_DEPOSIT_WALLET, uint64(0))), (HyperCore.SpotBalance)
        );
        assertLe(cdwUsdc.hold, cdwUsdc.total);
        assertTrue(abi.decode(_call(HyperCore.CORE_USER_EXISTS, abi.encode(CORE_DEPOSIT_WALLET)), (bool)));

        bytes memory code = vm.rpc(rpcUrl, "eth_getCode", string.concat('["', vm.toString(HyperCore.CORE_WRITER), '","latest"]'));
        assertEq(code.length, 544, "CoreWriter is the documented 544-byte contract");
    }
}
