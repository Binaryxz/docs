// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {Governed} from "./Governed.sol";
import {TetherLike} from "../ERC4626Adapter.t.sol";
import {IHedgeVenue, IHedgePriceFeed} from "../../hedge/IHedgeVenue.sol";
import {SimHedgeVenue} from "../../hedge/SimHedgeVenue.sol";
import {HedgeSubWallet} from "../../hedge/HedgeSubWallet.sol";

/// A Chainlink-style feed the tests move by hand.
contract HedgeFeed is IHedgePriceFeed {
    int256 public answer;
    uint256 public at;
    uint8 public immutable dec;
    uint80 internal round = 1;

    constructor(int256 a, uint8 d) {
        (answer, at, dec) = (a, block.timestamp, d);
    }

    function set(int256 a, uint256 t) external {
        (answer, at) = (a, t);
        ++round;
    }

    function decimals() external view returns (uint8) {
        return dec;
    }

    function latestRoundData() external view returns (uint80, int256, uint256, uint256, uint80) {
        return (round, answer, at, at, round);
    }
}

/**
 * A venue that lies: it reports fills worse than the limit, or bigger than asked, or fills one leg
 * of a pair and not the other. Everything else is a flat, empty account priced at a fixed $2,500.
 * For checking that the sub-wallet verifies what a venue tells it instead of trusting it.
 */
contract LyingVenue is IHedgeVenue {
    using SafeERC20 for IERC20;

    IERC20 internal immutable C;
    /// 0 honest-looking, 1 price past the limit, 2 overfill, 3 perp orders fill nothing (spot in
    /// full), 4 every order fills exactly half.
    uint8 public mode;
    mapping(address => uint256) public cash;

    constructor(IERC20 c) {
        C = c;
    }

    function setMode(uint8 m) external {
        mode = m;
    }

    function collateral() external view returns (IERC20) {
        return C;
    }

    function deposit(uint256 amount) external {
        C.safeTransferFrom(msg.sender, address(this), amount);
        cash[msg.sender] += amount;
    }

    function withdraw(uint256 amount) external {
        cash[msg.sender] -= amount;
        C.safeTransfer(msg.sender, amount);
    }

    function transferMargin(int256) external {}

    function _fill(uint256 qty, uint256 limitPx, bool buy)
        internal
        view
        returns (uint256, uint256)
    {
        if (mode == 1) return (qty, buy ? limitPx + 1 : limitPx - 1);
        if (mode == 2) return (qty + 1, limitPx);
        if (mode == 4) return (qty / 2, limitPx);
        return (qty, limitPx);
    }

    function _perpFill(uint256 qty, uint256 limitPx, bool buy)
        internal
        view
        returns (uint256, uint256)
    {
        if (mode == 3) return (0, 0);
        return _fill(qty, limitPx, buy);
    }

    function buySpot(bytes32, uint256 q, uint256 l) external view returns (uint256, uint256) {
        return _fill(q, l, true);
    }

    function sellSpot(bytes32, uint256 q, uint256 l) external view returns (uint256, uint256) {
        return _fill(q, l, false);
    }

    function increasePerp(bytes32, bool isLong, uint256 q, uint256 l)
        external
        view
        returns (uint256, uint256)
    {
        return _perpFill(q, l, isLong);
    }

    function reducePerp(bytes32, uint256 q, uint256 l) external view returns (uint256, uint256) {
        return _perpFill(q, l, true);
    }

    function spotBalance(address, bytes32) external pure returns (uint256) {
        return 0;
    }

    function perpPosition(address, bytes32) external pure returns (PerpPosition memory) {}

    function marginAccount(address) external pure returns (MarginAccount memory) {}

    function prices(bytes32) external view returns (Prices memory) {
        return Prices({mark: 2_500e18, index: 2_500e18, spot: 2_500e18, updatedAt: block.timestamp});
    }

    function fundingRate(bytes32) external pure returns (int256) {
        return 0;
    }

    function maxLeverageBps(bytes32) external pure returns (uint256) {
        return 100_000;
    }
}

/**
 * An HONEST venue that fills only part of what it is asked: a proxy over a real `SimHedgeVenue`,
 * trading there as one account, that scales each order kind's size by `fillBps` (0 fills nothing and
 * calls nothing) and reports exactly what filled. The book, margin and prices are the simulator's,
 * so a sub-wallet on it builds and runs a real hedge - until one leg of a pair stops filling.
 */
contract PartialFillVenue is IHedgeVenue {
    using SafeERC20 for IERC20;

    SimHedgeVenue public immutable inner;
    IERC20 internal immutable C;
    /// By kind: 0 buySpot, 1 sellSpot, 2 increasePerp, 3 reducePerp.
    uint16[4] public fillBps = [10_000, 10_000, 10_000, 10_000];

    constructor(SimHedgeVenue v) {
        inner = v;
        C = v.collateral();
    }

    function setFill(uint8 kind, uint16 bps) external {
        fillBps[kind] = bps;
    }

    function collateral() external view returns (IERC20) {
        return C;
    }

    function deposit(uint256 amount) external {
        C.safeTransferFrom(msg.sender, address(this), amount);
        C.forceApprove(address(inner), amount);
        inner.deposit(amount);
    }

    function withdraw(uint256 amount) external {
        inner.withdraw(amount);
        C.safeTransfer(msg.sender, amount);
    }

    function transferMargin(int256 amount) external {
        inner.transferMargin(amount);
    }

    function _part(uint8 kind, uint256 q) internal view returns (uint256) {
        return (q * fillBps[kind]) / 10_000;
    }

    function buySpot(bytes32 a, uint256 q, uint256 l) external returns (uint256, uint256) {
        q = _part(0, q);
        return q == 0 ? (0, 0) : inner.buySpot(a, q, l);
    }

    function sellSpot(bytes32 a, uint256 q, uint256 l) external returns (uint256, uint256) {
        q = _part(1, q);
        return q == 0 ? (0, 0) : inner.sellSpot(a, q, l);
    }

    function increasePerp(bytes32 a, bool isLong, uint256 q, uint256 l)
        external
        returns (uint256, uint256)
    {
        q = _part(2, q);
        return q == 0 ? (0, 0) : inner.increasePerp(a, isLong, q, l);
    }

    function reducePerp(bytes32 a, uint256 q, uint256 l) external returns (uint256, uint256) {
        q = _part(3, q);
        return q == 0 ? (0, 0) : inner.reducePerp(a, q, l);
    }

    function cash(address) external view returns (uint256) {
        return inner.cash(address(this));
    }

    function spotBalance(address, bytes32 a) external view returns (uint256) {
        return inner.spotBalance(address(this), a);
    }

    function perpPosition(address, bytes32 a) external view returns (PerpPosition memory) {
        return inner.perpPosition(address(this), a);
    }

    function marginAccount(address) external view returns (MarginAccount memory) {
        return inner.marginAccount(address(this));
    }

    function prices(bytes32 a) external view returns (Prices memory) {
        return inner.prices(a);
    }

    function fundingRate(bytes32 a) external view returns (int256) {
        return inner.fundingRate(a);
    }

    function maxLeverageBps(bytes32 a) external view returns (uint256) {
        return inner.maxLeverageBps(a);
    }
}

/**
 * The sleeve under test: stand-in USDT (Tether's no-return-value transfers), the simulated venue on
 * its own oracle, an independent reference feed, and one ETH sub-wallet funded by the treasury.
 * `_tick` advances time and refreshes both feeds, as a live oracle would.
 */
abstract contract HedgeSleeveBase is Governed {
    TetherLike usdt;
    HedgeFeed venueFeed;
    HedgeFeed refFeed;
    SimHedgeVenue venue;
    HedgeSubWallet wallet;

    address gov = makeAddr("gov");
    address guardian = makeAddr("guardian");
    address keeper = makeAddr("keeper");
    address treasury = makeAddr("treasury");
    address operator = makeAddr("operator");
    address stranger = makeAddr("stranger");

    bytes32 constant ETH = "ETH";
    int256 constant PX = 2_500e8;
    /// 0.00125% an hour, 10.95% a year: Hyperliquid's resting rate, here simply set.
    int256 constant RESTING_RATE = 1.25e13;
    uint256 constant SEED = 10_000_000e6;

    function _params() internal pure returns (HedgeSubWallet.Params memory p) {
        p = HedgeSubWallet.Params({
            targetLeverageBps: 20_000,
            maxLeverageBps: 30_000,
            deltaToleranceBps: 200,
            slippageBps: 50,
            priceBandBps: 100,
            fundingPauseE8: 0,
            fundingExitE8: -1_141, // -10% a year, hourly
            fundingTau: 84 hours,
            minActionInterval: 60,
            maxReferenceAge: 1 hours,
            maxOrderNotional: 50_000e6,
            maxWindowTurnover: 2_000_000e6,
            allocationCap: 5_000_000e6
        });
    }

    function setUp() public virtual {
        vm.warp(1_789_000_000);
        usdt = new TetherLike();
        venueFeed = new HedgeFeed(PX, 8);
        refFeed = new HedgeFeed(PX, 8);
        venue = new SimHedgeVenue(IERC20(address(usdt)), operator, 1 hours, 5, 5);
        vm.startPrank(operator);
        venue.listMarket(ETH, venueFeed, 100_000, RESTING_RATE);
        usdt.mint(operator, SEED);
        usdt.approve(address(venue), SEED);
        venue.seed(SEED);
        vm.stopPrank();
        wallet = _newWallet(_params());
        _completeSetup(address(wallet));
    }

    function _newWallet(HedgeSubWallet.Params memory p) internal returns (HedgeSubWallet) {
        return new HedgeSubWallet(
            IERC20(address(usdt)), venue, ETH, refFeed, treasury, gov, guardian, keeper, DELAY, p
        );
    }

    function _fund(uint256 amount) internal {
        usdt.mint(treasury, amount);
        vm.startPrank(treasury);
        usdt.approve(address(wallet), amount);
        wallet.fund(amount);
        vm.stopPrank();
    }

    /// Move time and keep both feeds fresh at their current answers.
    function _tick(uint256 dt) internal {
        vm.warp(block.timestamp + dt);
        venueFeed.set(venueFeed.answer(), block.timestamp);
        refFeed.set(refFeed.answer(), block.timestamp);
    }

    function _setPrice(int256 px) internal {
        venueFeed.set(px, block.timestamp);
        refFeed.set(px, block.timestamp);
    }

    /// Run the keeper until it has nothing to do; returns the number of steps taken.
    function _rebalanceUntilDone(uint256 max) internal returns (uint256 steps) {
        for (; steps < max; ++steps) {
            _tick(61);
            vm.prank(keeper);
            try wallet.rebalance() {}
            catch (bytes memory err) {
                assertEq(
                    bytes4(err),
                    HedgeSubWallet.NothingToDo.selector,
                    "stopped by something other than done"
                );
                return steps;
            }
        }
    }

    function _short() internal view returns (uint256) {
        int256 s = venue.perpPosition(address(wallet), ETH).size;
        return s < 0 ? uint256(-s) : 0;
    }

    function _spotQty() internal view returns (uint256) {
        return venue.spotBalance(address(wallet), ETH);
    }

    /// The sub-wallet's value at the venue's own prices (spot at the lower of spot and index).
    function _value() internal view returns (uint256) {
        IHedgeVenue.Prices memory pr = venue.prices(ETH);
        IHedgeVenue.MarginAccount memory ma = venue.marginAccount(address(wallet));
        uint256 px = pr.spot < pr.index ? pr.spot : pr.index;
        return usdt.balanceOf(address(wallet)) + venue.cash(address(wallet))
            + (ma.equity > 0 ? uint256(ma.equity) : 0) + (_spotQty() * px) / 1e30;
    }

    /// Short notional over equity at the mark, bps.
    function _leverage() internal view returns (uint256) {
        IHedgeVenue.MarginAccount memory ma = venue.marginAccount(address(wallet));
        uint256 ntl = (_short() * venue.prices(ETH).mark) / 1e30;
        if (ntl == 0) return 0;
        if (ma.equity <= 0) return type(uint256).max;
        return (ntl * 10_000) / uint256(ma.equity);
    }
}
