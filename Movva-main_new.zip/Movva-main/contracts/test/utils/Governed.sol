// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import {DelayedGovernance} from "../../common/DelayedGovernance.sol";

/// Helpers for contracts whose risk-increasing changes wait out a governance delay.
abstract contract Governed is Test {
    /// The delay every test deployment uses; production defaults to the same.
    uint256 internal constant DELAY = 48 hours;
    /// The dispute timeout every test escrow uses; the deploy script's default is the same.
    uint256 internal constant DISPUTE_TIMEOUT = 30 days;
    /// The on-ramp's timeout for a dispute its TAKER raised (H-04); the deploy scripts' default.
    uint256 internal constant TAKER_DISPUTE_TIMEOUT = 5 days;
    /// The on-ramp's cap on a shielded delivery's vetting fee (H-02); the deploy scripts' default.
    uint256 internal constant MAX_VETTING_FEE_BPS = 10;

    /// Close setup, after which risk-increasing changes must be scheduled.
    function _completeSetup(address target) internal {
        vm.prank(DelayedGovernance(target).governor());
        DelayedGovernance(target).completeSetup();
    }

    /// Schedule a change, wait out the delay, and execute it - the only way a risk-increasing
    /// change reaches a live contract.
    function _afterDelay(address target, bytes memory call) internal {
        address gov = DelayedGovernance(target).governor();
        vm.prank(gov);
        DelayedGovernance(target).schedule(call);
        vm.warp(block.timestamp + DelayedGovernance(target).GOVERNANCE_DELAY());
        vm.prank(gov);
        DelayedGovernance(target).execute(call);
    }
}
