// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Vm} from "forge-std/Vm.sol";
import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {HyperCore} from "../../hyperliquid/HyperCore.sol";

contract SimUSDC is ERC20 {
    constructor() ERC20("USD Coin", "USDC") {}

    function decimals() public pure override returns (uint8) {
        return 6;
    }

    function mint(address to, uint256 v) external {
        _mint(to, v);
    }
}

/// Answers a precompile address by forwarding the raw input to the simulator. Etched at 0x08xx.
contract PrecompileStub {
    HyperCoreSim internal immutable SIM;

    constructor(HyperCoreSim sim) {
        SIM = sim;
    }

    fallback(bytes calldata input) external returns (bytes memory) {
        return SIM.read(address(this), input);
    }
}

/// CoreWriter as deployed: record the action, emit, never fail. Etched at 0x3333...3333.
contract CoreWriterStub {
    HyperCoreSim internal immutable SIM;

    event RawAction(address indexed user, bytes data);

    constructor(HyperCoreSim sim) {
        SIM = sim;
    }

    function sendRawAction(bytes calldata data) external {
        SIM.record(msg.sender, data);
        emit RawAction(msg.sender, data);
    }
}

/// HYPE's system address: native HYPE sent here is credited to the sender on HyperCore.
contract HypeSystemStub {
    HyperCoreSim internal immutable SIM;

    constructor(HyperCoreSim sim) {
        SIM = sim;
    }

    receive() external payable {
        SIM.creditHype(msg.sender, msg.value / 1e10); // 18 decimals on HyperEVM, 8 on HyperCore
    }
}

/// Circle's CoreDepositWallet: pulls USDC on HyperEVM, credits HyperCore after the block.
contract SimDepositWallet {
    HyperCoreSim internal immutable SIM;
    SimUSDC internal immutable USDC;

    constructor(HyperCoreSim sim, SimUSDC usdc) {
        SIM = sim;
        USDC = usdc;
    }

    function deposit(uint256 amount, uint32 destinationDex) external {
        require(USDC.transferFrom(msg.sender, address(this), amount), "pull");
        SIM.queueDeposit(msg.sender, amount, destinationDex);
    }

    /// The system transaction that pays out a HyperCore -> HyperEVM transfer in the next block.
    function systemPay(address to, uint256 amount) external {
        require(msg.sender == address(SIM), "system");
        require(USDC.transfer(to, amount), "pay");
    }
}

/**
 * A small HyperCore, faithful where the vault's safety depends on it:
 *
 *  - actions are recorded when CoreWriter is called and applied only when the test "ends the
 *    block" (`processBlock`), deposits first, then actions in order - the documented sequence;
 *  - reads reflect only processed state, so an action is invisible in the block that sent it;
 *  - an action HyperCore would reject (no account, bad tick or lot, insufficient balance or
 *    margin, reduce-only that would grow a position) is dropped silently, as on HyperCore;
 *  - IOC orders fill at the market price only if the limit crosses it;
 *  - perp accounting is cross margin: account value = cash + size x mark.
 *
 * Units follow the docs: perp prices raw = human x 10^(6 - szDecimals), spot raw = human x
 * 10^(8 - szDecimals), sizes szi x 10^szDecimals, USD 1e6, USDC wei 1e8, CoreWriter px/sz 1e8.
 */
contract HyperCoreSim {
    Vm internal constant vm = Vm(address(uint160(uint256(keccak256("hevm cheat code")))));

    struct Account {
        bool exists;
        int64 szi;
        int256 cash; // 1e6 USD
        uint256 hype; // HyperCore HYPE for bridge gas, wei 1e8
        mapping(uint64 => uint256) spot; // wei
    }

    struct Pending {
        address user;
        bytes data;
    }

    struct Deposit {
        address user;
        uint256 amount; // 1e6
        uint32 dex;
    }

    SimUSDC public immutable usdc;
    SimDepositWallet public depositWallet;

    uint32 public constant PERP = 1;
    uint32 public constant SPOT = 151;
    uint64 public constant BASE_TOKEN = 221;
    uint8 public constant PERP_SZ = 4;
    uint8 public constant SPOT_SZ = 4;
    // UETH as listed in spotMeta: spot index 151, token 221, szDecimals 4, weiDecimals 9.
    uint8 public constant WEI = 9;
    uint8 public constant MAX_LEV = 25;
    uint256 public constant CROSS_LEV = 10;

    uint64 public oracleRaw = 250_000; // $2,500.00
    uint64 public markRaw = 250_000;
    uint64 public spotRaw = 25_000_000; // $2,500.00
    uint64 public bid = 249_990;
    uint64 public ask = 250_010;
    /// Fill price for IOC orders; 0 = the oracle (perp) / spot price.
    uint64 public perpFillRaw;
    uint64 public spotFillRaw;
    uint256 public takerPerpBps = 5; // 4.5 bps rounded up
    uint256 public takerSpotBps = 7;
    bool public rejectEverything;
    /// Fill every IOC order at its own limit: the worst price the band allows, as a colluding maker gives.
    bool public fillAtLimit;
    uint64 public spotQuoteToken; // 0 = USDC

    mapping(address => Account) internal accounts;
    Pending[] internal pending;
    Deposit[] internal deposits;

    // What the vault sent, for tests to inspect.
    struct OrderLog {
        uint32 asset;
        bool isBuy;
        uint64 limitPx;
        uint64 sz;
        bool reduceOnly;
        uint8 tif;
        bool filled;
    }

    OrderLog[] public orders;
    uint256 public rejected;

    constructor(SimUSDC usdc_) {
        usdc = usdc_;
    }

    function setDepositWallet(SimDepositWallet w) external {
        depositWallet = w;
    }

    /*//////////////////////////////////////////////////////////////
                               TEST CONTROLS
    //////////////////////////////////////////////////////////////*/

    function setPrices(uint64 oracle, uint64 spot) external {
        oracleRaw = oracle;
        markRaw = oracle;
        spotRaw = spot;
        bid = oracle - 10;
        ask = oracle + 10;
    }

    function setBook(uint64 b, uint64 a) external {
        bid = b;
        ask = a;
    }

    function setFills(uint64 perpRaw, uint64 spotRaw_) external {
        perpFillRaw = perpRaw;
        spotFillRaw = spotRaw_;
    }

    function setFillAtLimit(bool f) external {
        fillAtLimit = f;
    }

    function setRejectEverything(bool r) external {
        rejectEverything = r;
    }

    function setSpotQuoteToken(uint64 t) external {
        spotQuoteToken = t;
    }

    /// Pay (or charge) one hour of funding: positive rate means longs pay shorts.
    function payFunding(address user, int256 hourlyE8) external {
        Account storage a = accounts[user];
        a.cash += (-int256(a.szi) * int256(uint256(oracleRaw)) * hourlyE8) / 1e8;
    }

    /// Take value out of an account's perp cash, as a liquidation or an exploit would.
    function slash(address user, uint256 usd6) external {
        accounts[user].cash -= int256(usd6);
    }

    function creditHype(address user, uint256 wei8) external {
        accounts[user].hype += wei8;
    }

    function pendingCount() external view returns (uint256) {
        return pending.length;
    }

    function orderCount() external view returns (uint256) {
        return orders.length;
    }

    function orderAt(uint256 i) external view returns (OrderLog memory) {
        return orders[i];
    }

    function szi(address user) external view returns (int64) {
        return accounts[user].szi;
    }

    function spotOf(address user, uint64 token) external view returns (uint256) {
        return accounts[user].spot[token];
    }

    /*//////////////////////////////////////////////////////////////
                             EVM-SIDE HOOKS
    //////////////////////////////////////////////////////////////*/

    function record(address user, bytes calldata data) external {
        pending.push(Pending({user: user, data: data}));
    }

    function queueDeposit(address user, uint256 amount, uint32 dex) external {
        require(msg.sender == address(depositWallet), "cdw");
        deposits.push(Deposit({user: user, amount: amount, dex: dex}));
    }

    /**
     * End the EVM block: EVM -> Core transfers, then CoreWriter actions, in order. Order delays of
     * "a few seconds" are folded in here; tests warp past `settleSeconds` before reading again.
     */
    function processBlock() external {
        for (uint256 i; i < deposits.length; ++i) {
            Deposit memory d = deposits[i];
            Account storage a = accounts[d.user];
            uint256 amount = d.amount;
            if (!a.exists) {
                a.exists = true;
                amount = amount > 1e6 ? amount - 1e6 : 0; // Circle's newCoreAccountFee, 1 USDC
            }
            if (d.dex == 0) a.cash += int256(amount);
            else a.spot[HyperCore.USDC_TOKEN] += amount * 100;
        }
        delete deposits;
        for (uint256 i; i < pending.length; ++i) {
            if (!_apply(pending[i].user, pending[i].data)) ++rejected;
        }
        delete pending;
    }

    function _apply(address user, bytes memory data) internal returns (bool) {
        Account storage a = accounts[user];
        if (rejectEverything || !a.exists || data.length < 4 || uint8(data[0]) != 1) return false;
        uint24 id = (uint24(uint8(data[1])) << 16) | (uint24(uint8(data[2])) << 8) | uint24(uint8(data[3]));
        bytes memory payload = new bytes(data.length - 4);
        for (uint256 i; i < payload.length; ++i) payload[i] = data[i + 4];

        if (id == HyperCore.LIMIT_ORDER) return _order(user, payload);
        if (id == HyperCore.USD_CLASS_TRANSFER) {
            (uint64 ntl, bool toPerp) = abi.decode(payload, (uint64, bool));
            if (toPerp) {
                if (a.spot[HyperCore.USDC_TOKEN] < uint256(ntl) * 100) return false;
                a.spot[HyperCore.USDC_TOKEN] -= uint256(ntl) * 100;
                a.cash += int256(uint256(ntl));
            } else {
                if (_withdrawable(user) < ntl) return false;
                a.cash -= int256(uint256(ntl));
                a.spot[HyperCore.USDC_TOKEN] += uint256(ntl) * 100;
            }
            return true;
        }
        if (id == HyperCore.SEND_ASSET) {
            (address dest,, uint32 src, uint32 dst, uint64 token, uint64 amountWei) =
                abi.decode(payload, (address, address, uint32, uint32, uint64, uint64));
            if (dest != HyperCore.systemAddress(token) || token != HyperCore.USDC_TOKEN) return false;
            if (src != HyperCore.SPOT_DEX || dst != HyperCore.SPOT_DEX) return false;
            if (a.spot[token] < amountWei || a.hype == 0) return false; // bridge gas is paid in HYPE
            a.spot[token] -= amountWei;
            a.hype -= 1;
            depositWallet.systemPay(user, amountWei / 100);
            return true;
        }
        return false;
    }

    function _order(address user, bytes memory payload) internal returns (bool) {
        (uint32 asset, bool isBuy, uint64 limitPx, uint64 sz, bool reduceOnly, uint8 tif,) =
            abi.decode(payload, (uint32, bool, uint64, uint64, bool, uint8, uint128));
        orders.push(OrderLog(asset, isBuy, limitPx, sz, reduceOnly, tif, false));
        if (tif != HyperCore.TIF_IOC) return false;
        bool ok = asset == PERP ? _perp(user, isBuy, limitPx, sz, reduceOnly) : asset == 10_000 + SPOT
            ? _spot(user, isBuy, limitPx, sz)
            : false;
        orders[orders.length - 1].filled = ok;
        return ok;
    }

    function _validTick(uint64 px, uint256 maxDecimals) internal pure returns (bool) {
        return HyperCore.roundPx(px, maxDecimals, false) == px;
    }

    function _perp(address user, bool isBuy, uint64 limitPx, uint64 sz, bool reduceOnly) internal returns (bool) {
        if (!_validTick(limitPx, 6 - PERP_SZ) || sz % 10 ** (8 - PERP_SZ) != 0) return false;
        uint256 fillRaw = fillAtLimit ? limitPx / 10 ** (2 + PERP_SZ) : perpFillRaw == 0 ? oracleRaw : perpFillRaw;
        uint256 fillE8 = fillRaw * 10 ** (2 + PERP_SZ);
        if (isBuy ? limitPx < fillE8 : limitPx > fillE8) return false; // IOC: no cross, no fill
        Account storage a = accounts[user];
        int64 dsz = int64(uint64(sz / 10 ** (8 - PERP_SZ)));
        int64 next = isBuy ? a.szi + dsz : a.szi - dsz;
        if (reduceOnly && (_abs(next) > _abs(a.szi) || (a.szi > 0 && next < 0) || (a.szi < 0 && next > 0))) {
            return false;
        }
        int256 notional = int256(uint256(uint64(dsz))) * int256(fillRaw);
        int256 fee = (notional * int256(takerPerpBps)) / 10_000;
        int256 cash = a.cash + (isBuy ? -notional : notional) - fee;
        // Initial margin at the venue's max leverage must hold after an order that grows the position.
        if (_abs(next) > _abs(a.szi)) {
            int256 value = cash + int256(next) * int256(uint256(markRaw));
            if (value * int256(uint256(MAX_LEV)) < int256(uint256(_abs(next))) * int256(uint256(markRaw))) return false;
        }
        a.cash = cash;
        a.szi = next;
        return true;
    }

    function _spot(address user, bool isBuy, uint64 limitPx, uint64 sz) internal returns (bool) {
        if (!_validTick(limitPx, 8 - SPOT_SZ) || sz % 10 ** (8 - SPOT_SZ) != 0) return false;
        uint256 fillRaw = fillAtLimit ? limitPx / 10 ** SPOT_SZ : spotFillRaw == 0 ? spotRaw : spotFillRaw;
        uint256 fillE8 = fillRaw * 10 ** SPOT_SZ;
        if (isBuy ? limitPx < fillE8 : limitPx > fillE8) return false;
        Account storage a = accounts[user];
        uint256 baseWei = (uint256(sz) * 10 ** WEI) / 1e8;
        uint256 quoteWei = (uint256(sz) * fillE8) / 1e8; // USDC wei (1e8)
        uint256 fee = (quoteWei * takerSpotBps) / 10_000;
        if (isBuy) {
            if (a.spot[HyperCore.USDC_TOKEN] < quoteWei + fee) return false;
            a.spot[HyperCore.USDC_TOKEN] -= quoteWei + fee;
            a.spot[BASE_TOKEN] += baseWei;
        } else {
            if (a.spot[BASE_TOKEN] < baseWei) return false;
            a.spot[BASE_TOKEN] -= baseWei;
            a.spot[HyperCore.USDC_TOKEN] += quoteWei - fee;
        }
        return true;
    }

    function _abs(int64 x) internal pure returns (uint64) {
        return x < 0 ? uint64(-x) : uint64(x);
    }

    function _value(address user) internal view returns (int256) {
        Account storage a = accounts[user];
        return a.cash + int256(a.szi) * int256(uint256(markRaw));
    }

    function _withdrawable(address user) internal view returns (uint64) {
        Account storage a = accounts[user];
        uint256 ntl = uint256(_abs(a.szi)) * markRaw;
        uint256 margin = ntl / CROSS_LEV;
        if (ntl / 10 > margin) margin = ntl / 10;
        int256 w = _value(user) - int256(margin);
        return w > 0 ? uint64(uint256(w)) : 0;
    }

    /*//////////////////////////////////////////////////////////////
                               PRECOMPILES
    //////////////////////////////////////////////////////////////*/

    function read(address precompile, bytes calldata input) external view returns (bytes memory) {
        if (precompile == HyperCore.POSITION) {
            (address user, uint16 perp) = abi.decode(input, (address, uint16));
            Account storage a = accounts[user];
            int64 s = perp == PERP ? a.szi : int64(0);
            return abi.encode(HyperCore.Position(s, uint64(_abs(s)) * oracleRaw, 0, uint32(CROSS_LEV), false));
        }
        if (precompile == HyperCore.SPOT_BALANCE) {
            (address user, uint64 token) = abi.decode(input, (address, uint64));
            return abi.encode(HyperCore.SpotBalance(uint64(accounts[user].spot[token]), 0, 0));
        }
        if (precompile == HyperCore.WITHDRAWABLE) {
            return abi.encode(_withdrawable(abi.decode(input, (address))));
        }
        if (precompile == HyperCore.MARK_PX) return abi.encode(markRaw);
        if (precompile == HyperCore.ORACLE_PX) return abi.encode(oracleRaw);
        if (precompile == HyperCore.SPOT_PX) return abi.encode(spotRaw);
        if (precompile == HyperCore.PERP_ASSET_INFO) {
            return abi.encode(HyperCore.PerpAssetInfo("ETH", 55, PERP_SZ, MAX_LEV, false));
        }
        if (precompile == HyperCore.SPOT_INFO) {
            return abi.encode(HyperCore.SpotInfo("UETH/USDC", [BASE_TOKEN, spotQuoteToken]));
        }
        if (precompile == HyperCore.TOKEN_INFO) {
            uint64[] memory spots = new uint64[](1);
            spots[0] = SPOT;
            return abi.encode(HyperCore.TokenInfo("UETH", spots, 0, address(0), address(0), SPOT_SZ, WEI, 0));
        }
        if (precompile == HyperCore.BBO) return abi.encode(HyperCore.Bbo(bid, ask));
        if (precompile == HyperCore.ACCOUNT_MARGIN_SUMMARY) {
            (, address user) = abi.decode(input, (uint32, address));
            Account storage a = accounts[user];
            uint256 ntl = uint256(_abs(a.szi)) * markRaw;
            return abi.encode(
                HyperCore.AccountMarginSummary(int64(_value(user)), uint64(ntl / CROSS_LEV), uint64(ntl), int64(a.cash))
            );
        }
        if (precompile == HyperCore.CORE_USER_EXISTS) {
            return abi.encode(accounts[abi.decode(input, (address))].exists);
        }
        revert("unsimulated precompile");
    }

    /// Put the stubs at the real addresses.
    function install() external {
        PrecompileStub stub = new PrecompileStub(this);
        address[11] memory at = [
            HyperCore.POSITION,
            HyperCore.SPOT_BALANCE,
            HyperCore.WITHDRAWABLE,
            HyperCore.MARK_PX,
            HyperCore.ORACLE_PX,
            HyperCore.SPOT_PX,
            HyperCore.PERP_ASSET_INFO,
            HyperCore.SPOT_INFO,
            HyperCore.TOKEN_INFO,
            HyperCore.BBO,
            HyperCore.ACCOUNT_MARGIN_SUMMARY
        ];
        for (uint256 i; i < at.length; ++i) vm.etch(at[i], address(stub).code);
        vm.etch(HyperCore.CORE_USER_EXISTS, address(stub).code);
        vm.etch(HyperCore.CORE_WRITER, address(new CoreWriterStub(this)).code);
        vm.etch(0x2222222222222222222222222222222222222222, address(new HypeSystemStub(this)).code);
    }
}
