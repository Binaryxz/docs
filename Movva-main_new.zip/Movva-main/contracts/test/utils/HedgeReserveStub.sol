// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";

/**
 * MovvaReserve's side of the hedge sleeve's funding path and nothing else, for the funding-path CLI's anvil
 * test (packages/ops/test/hedge-sleeve.test.ts): the same view and function names as the principal-locked
 * reserve (client rule, 21 October 2026), none of the oracle or token machinery. There is no hedge
 * withdrawal: the sleeve is funded by Movva's own capital through the hedge Safe, and `recapitalize` is one
 * way - what comes in is principal. The fork rehearsal (scripts/hedge-sleeve-rehearsal.ts) runs the real reserve.
 */
contract HedgeReserveStub {
    using SafeERC20 for IERC20;

    IERC20 public immutable USDT;
    address public immutable yieldRecipient;
    uint256 public principalUsdt;

    constructor(IERC20 usdt, address yieldRecipient_) {
        (USDT, yieldRecipient) = (usdt, yieldRecipient_);
    }

    function totalUsdt() public view returns (uint256) {
        return USDT.balanceOf(address(this));
    }

    /// @dev The real reserve also keeps the liabilities at the target ratio; the stub has none.
    function harvestableYield() external view returns (uint256) {
        uint256 t = totalUsdt();
        return t > principalUsdt ? t - principalUsdt : 0;
    }

    function setupComplete() external pure returns (bool) {
        return true;
    }

    function recapitalize(uint256 usdt) external {
        USDT.safeTransferFrom(msg.sender, address(this), usdt);
        principalUsdt += usdt;
    }
}
