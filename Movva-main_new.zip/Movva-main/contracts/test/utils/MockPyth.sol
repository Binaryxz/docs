// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IPyth} from "../../ramp/IPyth.sol";

/**
 * Pyth's on-chain contract as far as this repo uses it: stored prices read three ways, and posted
 * updates paid for with a fee.
 *
 * An update here is `abi.encode(id, price, conf, expo, publishTime)` with no signature: the real
 * contract verifies Wormhole-signed accumulator updates, which nothing in the repo reimplements. What
 * this keeps is everything a consumer or a keeper can observe - a feed that does not exist until
 * posted, an update that must be paid for, an older update that does not overwrite a newer price -
 * so the keeper's anvil runs and the examples exercise the same calls they make on mainnet.
 */
contract MockPyth is IPyth {
    mapping(bytes32 => Price) internal prices;
    mapping(bytes32 => bool) internal exists;
    /// @notice Wei charged per update, as `getUpdateFee` reports it. Mainnet Pyth charges 1 wei.
    uint256 public feePerUpdate;

    error PriceFeedNotFound();
    error StalePrice();
    error InsufficientFee();

    constructor(uint256 feePerUpdate_) {
        feePerUpdate = feePerUpdate_;
    }

    /// @notice Store a price directly, as if an update had been posted.
    function set(bytes32 id, int64 price, uint64 conf, int32 expo, uint256 publishTime) public {
        prices[id] = Price(price, conf, expo, publishTime);
        exists[id] = true;
    }

    /// @notice The update bytes `updatePriceFeeds` accepts for this price.
    function updateData(bytes32 id, int64 price, uint64 conf, int32 expo, uint256 publishTime)
        external
        pure
        returns (bytes memory)
    {
        return abi.encode(id, price, conf, expo, publishTime);
    }

    function getPriceNoOlderThan(bytes32 id, uint256 age) external view returns (Price memory) {
        if (!exists[id]) revert PriceFeedNotFound();
        // Pyth measures the distance either way from block.timestamp.
        uint256 t = prices[id].publishTime;
        uint256 diff = t > block.timestamp ? t - block.timestamp : block.timestamp - t;
        if (diff > age) revert StalePrice();
        return prices[id];
    }

    function getPriceUnsafe(bytes32 id) external view returns (Price memory) {
        if (!exists[id]) revert PriceFeedNotFound();
        return prices[id];
    }

    function getUpdateFee(bytes[] calldata updates) public view returns (uint256) {
        return updates.length * feePerUpdate;
    }

    /// @dev As Pyth: an update older than the stored price is accepted and ignored.
    function updatePriceFeeds(bytes[] calldata updates) external payable {
        if (msg.value < getUpdateFee(updates)) revert InsufficientFee();
        for (uint256 i; i < updates.length; ++i) {
            (bytes32 id, int64 price, uint64 conf, int32 expo, uint256 publishTime) =
                abi.decode(updates[i], (bytes32, int64, uint64, int32, uint256));
            if (exists[id] && publishTime <= prices[id].publishTime) continue;
            set(id, price, conf, expo, publishTime);
        }
    }
}
