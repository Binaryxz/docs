// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {ILPRegistry} from "../../ramp/ILPRegistry.sol";

/// Stands in for an escrow: the getters `bindEscrows` reads, and a pass-through for every escrow-only registry call.
/// The integration suite (PermissionlessRampIntegration.t.sol) runs the real, unchanged escrows instead.
contract EscrowStub {
    address public REGISTRY;
    uint64 public DISPUTE_TIMEOUT;
    uint64 public RULING_DELAY = 1 days;

    constructor(address registry, uint64 disputeTimeout) {
        REGISTRY = registry;
        DISPUTE_TIMEOUT = disputeTimeout;
    }

    function setRulingDelay(uint64 d) external {
        RULING_DELAY = d;
    }

    function reserve(address lp, uint256 cents) external returns (bool) {
        return ILPRegistry(REGISTRY).reserveExposure(lp, cents);
    }

    function release(address lp, uint256 cents) external {
        ILPRegistry(REGISTRY).releaseExposure(lp, cents);
    }

    function settled(address lp, uint256 cents) external {
        ILPRegistry(REGISTRY).recordSettled(lp, cents);
    }

    function dispute(address lp) external {
        ILPRegistry(REGISTRY).recordDispute(lp);
    }

    function consume(bytes32 id) external returns (bool) {
        return ILPRegistry(REGISTRY).consumeBankTxId(id);
    }

    /// Spend an id on another registry, as that registry's escrow (the predecessor's, in the tests).
    function consumeOn(address registry, bytes32 id) external returns (bool) {
        return ILPRegistry(registry).consumeBankTxId(id);
    }
}

/// An 18-decimal ERC20 that anyone can mint, for tests that need MOVVA's transfer semantics and not its reserve.
contract TestMovva is ERC20 {
    uint8 private immutable DEC;

    constructor(uint8 dec) ERC20("Test Movva", "tMOVVA") {
        DEC = dec;
    }

    function decimals() public view override returns (uint8) {
        return DEC;
    }

    function mint(address to, uint256 amount) external {
        _mint(to, amount);
    }
}
