// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";

/**
 * A minimal threshold multisig with EIP-1271, standing in for the arbitrator Safe in unit
 * tests. Signatures are 65 bytes per owner over the digest itself, sorted by owner, as Safe
 * requires of its own. The real Safe 1.4.1 (SafeMessage wrapping, CompatibilityFallbackHandler)
 * is exercised against Sepolia in ContractArbitratorFork.t.sol.
 */
contract Multisig1271 {
    mapping(address => bool) public isOwner;
    uint256 public immutable threshold;

    constructor(address[] memory owners, uint256 t) {
        for (uint256 i; i < owners.length; i++) isOwner[owners[i]] = true;
        threshold = t;
    }

    function isValidSignature(bytes32 hash, bytes calldata sigs) external view returns (bytes4) {
        if (sigs.length != threshold * 65) return 0xffffffff;
        address last;
        for (uint256 i; i < threshold; i++) {
            bytes calldata s = sigs[i * 65:(i + 1) * 65];
            address o = ecrecover(hash, uint8(s[64]), bytes32(s[0:32]), bytes32(s[32:64]));
            if (!isOwner[o] || o <= last) return 0xffffffff;
            last = o;
        }
        return 0x1626ba7e;
    }
}

/// Says yes to anything: what a contract arbitrator with no checks of its own is worth.
contract YesMan1271 {
    function isValidSignature(bytes32, bytes calldata) external pure returns (bytes4) {
        return 0x1626ba7e;
    }
}

/// Misbehaving validators: a revert, a short return, and a wrong magic value.
contract Bad1271 {
    uint8 public mode; // 0 revert, 1 returns 4 bytes, 2 wrong value

    function setMode(uint8 m) external {
        mode = m;
    }

    function isValidSignature(bytes32, bytes calldata) external view returns (bytes4) {
        if (mode == 0) revert("no");
        if (mode == 1) {
            assembly {
                mstore(0, 0x1626ba7e00000000000000000000000000000000000000000000000000000000)
                return(0, 4)
            }
        }
        return 0x20c13b0b; // the legacy (bytes,bytes) magic, not this function's
    }
}

/// Encodes a contract arbitrator's signature the way the escrows read it.
abstract contract ContractArbitratorSigning is Test {
    /// `threshold` owners' signatures over `d`, sorted by owner, prefixed with the multisig.
    function _multisigSig(address multisig, bytes32 d, uint256[] memory keys)
        internal
        pure
        returns (bytes memory sig)
    {
        uint256 n = keys.length;
        for (uint256 i; i < n; i++) {
            for (uint256 j = i + 1; j < n; j++) {
                if (vm.addr(keys[j]) < vm.addr(keys[i])) (keys[i], keys[j]) = (keys[j], keys[i]);
            }
        }
        bytes memory inner;
        for (uint256 i; i < n; i++) {
            (uint8 v, bytes32 r, bytes32 s) = vm.sign(keys[i], d);
            inner = abi.encodePacked(inner, r, s, v);
        }
        sig = abi.encodePacked(multisig, inner);
    }
}
