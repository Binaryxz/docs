// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Governed} from "./utils/Governed.sol";
import {FiatEscrow} from "../ramp/FiatEscrow.sol";
import {OffRampEscrow} from "../ramp/OffRampEscrow.sol";
import {LPRegistry} from "../ramp/LPRegistry.sol";
import {AttestorQuorumVerifier} from "../ramp/AttestorQuorumVerifier.sol";
import {ChainlinkBrlOracle} from "../ramp/ChainlinkBrlOracle.sol";
import {IAttestorVerifier} from "../ramp/IAttestorVerifier.sol";
import {MockFeed, PoolStub} from "./RampIntegration.t.sol";
import {MockVerifier} from "./FiatEscrow.t.sol";

/**
 * The card on-ramp: a licensed card partner sells as an INSTITUTIONAL LP, a captured charge is
 * attested like any payment, and the escrow keeps cards away from everyone who cannot carry a
 * chargeback - retail and affiliated LPs, a suspended partner, and the off-ramp.
 *
 * Why the rules exist: a card payment can be reversed months after the escrow released. On a
 * retail LP's offer that is a stolen card buying crypto from a person who never sees the money,
 * and a shielded delivery makes it a laundering route. The partner carries that risk by contract
 * (3-D Secure, its own fraud screening, chargeback liability), so only the partner may take cards.
 *
 * The card rail is also the one rail a quorum of attestors still settles: a capture has no bank session
 * to prove, while PIX, boleto and TED settle only on a proof of one (IAttestorVerifier.provesBankSession).
 * `bank` stands in for a zkTLS verifier wherever these tests need a bank rail beside the card one.
 */
contract CardRailTest is Governed {
    FiatEscrow escrow;
    OffRampEscrow offramp;
    LPRegistry registry;
    AttestorQuorumVerifier verifier;
    MockVerifier bank;
    ChainlinkBrlOracle oracle;
    PoolStub pool;

    uint256 k1 = 0xA11CE;
    uint256 k2 = 0xB0B;
    address governor = address(0x60F);
    address partner = makeAddr("cardPartner");
    address retail = makeAddr("retailLp");
    address affiliate = makeAddr("affiliateLp");
    address taker = makeAddr("taker");
    address payout = makeAddr("payout");

    bytes32 constant MERCHANT = keccak256("cardMerchantCommitment(acquirer, merchant, salt)");
    bytes32 constant PIX = keccak256("pixKeyCommitment(key, salt)");
    uint16 constant CARD_MASK = uint16(1 << uint8(IAttestorVerifier.Rail.CARD));
    uint16 constant PIX_MASK = uint16(1 << uint8(IAttestorVerifier.Rail.PIX));
    uint16 constant BOLETO_MASK = uint16(1 << uint8(IAttestorVerifier.Rail.BOLETO));

    function setUp() public {
        vm.warp(1_700_000_000);
        // 1 ETH = R$15,000 = 1,500,000 centavos
        oracle = new ChainlinkBrlOracle(address(new MockFeed(3000e8, 8)), address(new MockFeed(0.2e8, 8)), 1 hours, governor, DELAY);
        _completeSetup(address(oracle));

        address[] memory set = new address[](2);
        (set[0], set[1]) = vm.addr(k1) < vm.addr(k2) ? (vm.addr(k1), vm.addr(k2)) : (vm.addr(k2), vm.addr(k1));
        verifier = new AttestorQuorumVerifier(governor, DELAY, set, 2);
        _completeSetup(address(verifier));

        pool = new PoolStub();
        registry = new LPRegistry(governor, DELAY);
        escrow = new FiatEscrow(
            address(oracle), address(registry), address(pool), address(pool), 500, governor, DELAY, DISPUTE_TIMEOUT
        );
        offramp = new OffRampEscrow(address(oracle), address(registry), 500, governor, DELAY, DISPUTE_TIMEOUT);

        vm.startPrank(governor);
        registry.setEscrow(address(escrow), true);
        registry.setEscrow(address(offramp), true);
        // Phase C, so a retail LP and an affiliate exist to be refused for their tier alone.
        registry.setPhase(LPRegistry.Phase.C);
        registry.setTier(partner, LPRegistry.Tier.INSTITUTIONAL, 1_000_000_00);
        registry.completeSetup();
        bank = new MockVerifier();
        escrow.setVerifier(address(verifier), true);
        escrow.setVerifier(address(bank), true);
        escrow.completeSetup();
        offramp.setVerifier(address(verifier), true);
        offramp.setVerifier(address(bank), true);
        offramp.completeSetup();
        vm.stopPrank();

        vm.deal(partner, 50 ether);
        vm.deal(retail, 1 ether);
        vm.deal(affiliate, 1 ether);
        vm.deal(taker, 5 ether);
    }

    function _cardOffer(address lp, uint256 amount) internal returns (bytes32) {
        vm.prank(lp);
        return escrow.postOffer{value: amount}(
            address(0), amount, 1_500_000, MERCHANT, 0.01 ether, amount, address(verifier), CARD_MASK
        );
    }

    function _payment(bytes32 payee, IAttestorVerifier.Rail rail, bytes32 txId)
        internal
        view
        returns (IAttestorVerifier.Payment memory)
    {
        return IAttestorVerifier.Payment({
            bankTxId: txId,
            payeeKeyHash: payee,
            payerRef: keccak256("cardholder"),
            amountBrlCents: 1_500_000,
            paidAt: uint64(block.timestamp),
            rail: rail
        });
    }

    function _quorumProof(bytes32 orderId, IAttestorVerifier.Payment memory p) internal view returns (bytes memory) {
        bytes32 digest = verifier.hashPayment(orderId, p);
        bytes[] memory sigs = new bytes[](2);
        (uint8 v1, bytes32 r1, bytes32 s1) = vm.sign(k1, digest);
        (uint8 v2, bytes32 r2, bytes32 s2) = vm.sign(k2, digest);
        (sigs[0], sigs[1]) = vm.addr(k1) < vm.addr(k2)
            ? (abi.encodePacked(r1, s1, v1), abi.encodePacked(r2, s2, v2))
            : (abi.encodePacked(r2, s2, v2), abi.encodePacked(r1, s1, v1));
        return abi.encode(p.bankTxId, p.payeeKeyHash, p.payerRef, p.amountBrlCents, p.paidAt, uint8(p.rail), sigs);
    }

    /// The whole card on-ramp: the partner's card-only offer, a shielded order, a captured charge
    /// attested by the real quorum, and delivery into the pool.
    function test_TheCardPartnerSellsAgainstACapturedCharge() public {
        bytes32 offerId = _cardOffer(partner, 10 ether);
        vm.prank(taker);
        bytes32 orderId = escrow.lockOrder(offerId, 1 ether, FiatEscrow.Delivery.SHIELDED, payout, 999);

        IAttestorVerifier.Payment memory p = _payment(MERCHANT, IAttestorVerifier.Rail.CARD, keccak256("acquirer:TID-0001"));
        escrow.releaseWithProof(orderId, _quorumProof(orderId, p));

        assertEq(pool.received(), 1 ether, "paid by card, delivered shielded");
        assertTrue(escrow.usedBankTxId(p.bankTxId), "the capture is burned");
    }

    /// Retail and affiliated LPs can trade - a PIX offer of the same size posts - but not by card.
    function test_OnlyAnInstitutionCanPostACardOffer() public {
        vm.prank(retail);
        registry.register();
        vm.prank(partner);
        registry.sponsorAffiliate(affiliate, 5_000_00);

        for (uint256 i; i < 2; ++i) {
            address lp = i == 0 ? retail : affiliate;
            vm.prank(lp);
            escrow.postOffer{value: 0.2 ether}(
                address(0), 0.2 ether, 1_500_000, PIX, 0.01 ether, 0.2 ether, address(bank), PIX_MASK
            );

            vm.prank(lp);
            vm.expectRevert(FiatEscrow.CardNeedsInstitutionalLP.selector);
            escrow.postOffer{value: 0.2 ether}(
                address(0), 0.2 ether, 1_500_000, MERCHANT, 0.01 ether, 0.2 ether, address(verifier), CARD_MASK
            );
        }
        assertFalse(registry.isInstitutional(retail));
        assertFalse(registry.isInstitutional(affiliate));
        assertTrue(registry.isInstitutional(partner));
    }

    /// One offer, one payee commitment: a merchant account is not a PIX key, and a boleto is not a card.
    function test_ACardOfferTakesNoOtherRail() public {
        vm.startPrank(partner);
        vm.expectRevert(FiatEscrow.BadOffer.selector);
        escrow.postOffer{value: 1 ether}(
            address(0), 1 ether, 1_500_000, MERCHANT, 0.01 ether, 1 ether, address(verifier), CARD_MASK | PIX_MASK
        );
        vm.expectRevert(FiatEscrow.BadOffer.selector);
        escrow.postOffer{value: 1 ether}(
            address(0), 1 ether, 1_500_000, MERCHANT, 0.01 ether, 1 ether, address(verifier), CARD_MASK | BOLETO_MASK
        );
        vm.stopPrank();
    }

    /// Suspension stops new card orders at once; an order locked before it still settles, because
    /// the cardholder may already have been charged.
    function test_ASuspendedPartnerTakesNoNewCardOrdersButFinishesLockedOnes() public {
        bytes32 offerId = _cardOffer(partner, 10 ether);
        vm.prank(taker);
        bytes32 before = escrow.lockOrder(offerId, 1 ether, FiatEscrow.Delivery.DIRECT, payout, 0);

        vm.prank(governor);
        registry.setTier(partner, LPRegistry.Tier.SUSPENDED, 0);
        assertFalse(registry.isInstitutional(partner));

        vm.prank(taker);
        vm.expectRevert(FiatEscrow.CardNeedsInstitutionalLP.selector);
        escrow.lockOrder(offerId, 1 ether, FiatEscrow.Delivery.DIRECT, payout, 0);

        IAttestorVerifier.Payment memory p = _payment(MERCHANT, IAttestorVerifier.Rail.CARD, keccak256("acquirer:TID-0002"));
        escrow.releaseWithProof(before, _quorumProof(before, p));
        assertEq(payout.balance, 1 ether);
    }

    /// A PIX receipt cannot settle a card order - even signed by the real quorum for the right order,
    /// payee and amount - and a card capture cannot settle a PIX order.
    function test_ReceiptsDoNotCrossRails() public {
        bytes32 cardOffer = _cardOffer(partner, 10 ether);
        vm.prank(partner);
        bytes32 pixOffer = escrow.postOffer{value: 10 ether}(
            address(0), 10 ether, 1_500_000, PIX, 0.01 ether, 5 ether, address(bank), PIX_MASK
        );

        vm.startPrank(taker);
        bytes32 cardOrder = escrow.lockOrder(cardOffer, 1 ether, FiatEscrow.Delivery.DIRECT, payout, 0);
        bytes32 pixOrder = escrow.lockOrder(pixOffer, 1 ether, FiatEscrow.Delivery.DIRECT, payout, 0);
        vm.stopPrank();

        IAttestorVerifier.Payment memory pixToMerchant = _payment(MERCHANT, IAttestorVerifier.Rail.PIX, keccak256("E2E-1"));
        bytes memory proof = _quorumProof(cardOrder, pixToMerchant);
        vm.expectRevert(FiatEscrow.RailNotAccepted.selector);
        escrow.releaseWithProof(cardOrder, proof);

        bank.setProof(
            pixOrder,
            MockVerifier.Canned({
                bankTxId: keccak256("acquirer:TID-3"),
                payeeKeyHash: PIX,
                amountBrlCents: 1_500_000,
                paidAt: uint64(block.timestamp),
                rail: IAttestorVerifier.Rail.CARD,
                bound: true
            })
        );
        vm.expectRevert(FiatEscrow.RailNotAccepted.selector);
        escrow.releaseWithProof(pixOrder, "");
    }

    /// The quorum settles cards and nothing else: an offer or a sale naming it for PIX, boleto or TED is
    /// refused, on both escrows, before anything is escrowed.
    function test_AQuorumSettlesCardsAndNoBankRail() public {
        assertFalse(verifier.provesBankSession());
        uint16 tedMask = uint16(1 << uint8(IAttestorVerifier.Rail.TED));
        uint16[3] memory masks = [PIX_MASK, BOLETO_MASK, tedMask];
        vm.startPrank(partner);
        for (uint256 i; i < masks.length; ++i) {
            vm.expectRevert(FiatEscrow.BankRailNeedsZkTls.selector);
            escrow.postOffer{value: 1 ether}(
                address(0), 1 ether, 1_500_000, PIX, 0.01 ether, 1 ether, address(verifier), masks[i]
            );
            vm.expectRevert(OffRampEscrow.BankRailNeedsZkTls.selector);
            offramp.openSale{value: 1 ether}(address(0), 1 ether, 1_500_000, PIX, address(verifier), masks[i], partner);
        }
        // The same offer and sale through a verifier that proves the bank session open.
        escrow.postOffer{value: 1 ether}(address(0), 1 ether, 1_500_000, PIX, 0.01 ether, 1 ether, address(bank), PIX_MASK);
        offramp.openSale{value: 1 ether}(address(0), 1 ether, 1_500_000, PIX, address(bank), PIX_MASK, partner);
        vm.stopPrank();
    }

    function test_ACardOfferCannotBeLockedForABoleto() public {
        bytes32 offerId = _cardOffer(partner, 10 ether);
        vm.prank(taker);
        vm.expectRevert(FiatEscrow.RailNotAccepted.selector);
        escrow.lockOrderByBoleto(offerId, 1 ether, FiatEscrow.Delivery.DIRECT, payout, 0);
    }

    /// One capture pays for one order.
    function test_ACaptureSettlesOnlyOnce() public {
        bytes32 offerId = _cardOffer(partner, 10 ether);
        vm.startPrank(taker);
        bytes32 first = escrow.lockOrder(offerId, 1 ether, FiatEscrow.Delivery.DIRECT, payout, 0);
        bytes32 second = escrow.lockOrder(offerId, 1 ether, FiatEscrow.Delivery.DIRECT, payout, 0);
        vm.stopPrank();

        IAttestorVerifier.Payment memory p = _payment(MERCHANT, IAttestorVerifier.Rail.CARD, keccak256("acquirer:TID-4"));
        escrow.releaseWithProof(first, _quorumProof(first, p));
        bytes memory again = _quorumProof(second, p);
        vm.expectRevert(FiatEscrow.ReceiptReplayed.selector);
        escrow.releaseWithProof(second, again);
    }

    /// Nobody is paid out by card: a sale naming CARD, alone or beside a key rail, is refused.
    function test_NobodyIsPaidOutByCard() public {
        vm.startPrank(taker);
        vm.expectRevert(OffRampEscrow.BadSale.selector);
        offramp.openSale{value: 1 ether}(address(0), 1 ether, 1_500_000, PIX, address(verifier), CARD_MASK, payout);
        vm.expectRevert(OffRampEscrow.BadSale.selector);
        offramp.openSale{value: 1 ether}(
            address(0), 1 ether, 1_500_000, PIX, address(verifier), CARD_MASK | PIX_MASK, payout
        );
        // The same sale by PIX opens, through a verifier that proves the bank session.
        offramp.openSale{value: 1 ether}(address(0), 1 ether, 1_500_000, PIX, address(bank), PIX_MASK, payout);
        vm.stopPrank();
    }
}
