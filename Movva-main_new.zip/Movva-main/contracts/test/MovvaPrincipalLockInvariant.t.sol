// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import {console2} from "forge-std/console2.sol";
import {MovvaBase} from "./MovvaReserve.t.sol";
import {TetherLike} from "./ERC4626Adapter.t.sol";
import {FxTestFeed} from "./ChainlinkSignedFxOracle.t.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {IERC4626} from "@openzeppelin/contracts/interfaces/IERC4626.sol";
import {SignedPriceOracle} from "../ramp/SignedPriceOracle.sol";
import {YieldVault} from "../yield/YieldVault.sol";
import {Movva} from "../movva/Movva.sol";
import {MovvaReserve} from "../movva/MovvaReserve.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";

/**
 * The principal-locked reserve driven at random: gateways minting and redeeming, Mova recapitalizing,
 * the vault earning, the real moving both ways, Tether freezing the reserve, anyone harvesting, AND the
 * governor and the guardian using every power they have - pulling from the vault, pausing deposits,
 * switching the yield vault through the delay, moving the yield recipient through the delay, lowering
 * the target through the delay, pausing mint - plus strangers and the governor trying to aim every
 * function at themselves.
 *
 * Every call measures the reserve's USDT RAW - idle (frozen or not) plus the value of its shares in
 * either vault - before and after, and books what it may change.
 */
contract PrincipalLockHandler is Test {
    MovvaReserve reserve;
    Movva movva;
    TetherLike usdt;
    FxTestFeed feed;
    SignedPriceOracle fx;
    YieldVault[2] vaults;
    address gateway;
    address gov;
    address guardian;
    address[2] recipients;
    address stranger = makeAddr("stranger");
    uint256 p1;
    uint256 p2;
    uint64 seq;
    uint256 fxNow;

    /// USDT in: mints, recapitalizations, and vault income donated while the reserve held shares.
    uint256 public ghostIn;
    uint256 public ghostRedeemed;
    uint256 public ghostHarvested;
    /// Rounding the vaults may charge on the way out, a few base units per exit.
    uint256 public dust;
    /// The principal as the rule defines it: in through mint and recapitalize, out through redeem, floored at zero.
    uint256 public ghostPrincipal;

    /// A call other than redeem or harvest that lowered the reserve's USDT beyond rounding.
    uint256 public leakViolations;
    /// A redeem or harvest that took more than it reported paying, beyond rounding.
    uint256 public exitViolations;
    /// A harvest that left the reserve below max(principal, liabilities at the target), or paid someone else.
    uint256 public floorViolations;
    mapping(bytes32 => uint256) public calls;

    constructor(
        MovvaReserve r,
        TetherLike u,
        FxTestFeed f,
        SignedPriceOracle o,
        YieldVault[2] memory v,
        address[4] memory roles, // gateway, gov, guardian, yield recipient
        uint256[2] memory keys,
        uint64 seq_,
        uint256 fxNow_,
        uint256 principal
    ) {
        (reserve, usdt, feed, fx, vaults) = (r, u, f, o, v);
        movva = Movva(r.MOVVA());
        (gateway, gov, guardian) = (roles[0], roles[1], roles[2]);
        recipients = [roles[3], makeAddr("Mova's second Safe")];
        (p1, p2, seq, fxNow) = (keys[0], keys[1], seq_, fxNow_);
        ghostPrincipal = principal;
        ghostIn = principal;
        usdt.mint(address(this), 1e18);
        usdt.approve(address(reserve), type(uint256).max);
    }

    function assets() public view returns (uint256 a) {
        a = usdt.balanceOf(address(reserve));
        for (uint256 i; i < 2; ++i) {
            a += vaults[i].previewRedeem(vaults[i].balanceOf(address(reserve)));
        }
    }

    function recipientBalances() public view returns (uint256) {
        return usdt.balanceOf(recipients[0]) + usdt.balanceOf(recipients[1]);
    }

    /// Anything else must not lower the reserve's USDT (rounding aside).
    modifier noLeak() {
        uint256 before = assets();
        uint256 paidOut = recipientBalances();
        _;
        if (assets() + 3 < before) ++leakViolations;
        if (recipientBalances() != paidOut) ++leakViolations;
        dust += 3;
    }

    /*//////////////////////////////////////////////////////////////
                               MONEY IN / OUT
    //////////////////////////////////////////////////////////////*/

    function mint(uint256 amount) external {
        amount = bound(amount, 1e6, 2_000_000e6);
        uint256 before = assets();
        vm.prank(gateway);
        try reserve.mint(amount, gateway, 0) {
            ghostIn += amount;
            ghostPrincipal += amount;
            if (assets() + 3 < before + amount) ++leakViolations;
            ++calls["mint"];
        } catch {}
    }

    function redeem(uint256 amount) external {
        uint256 bal = movva.balanceOf(gateway);
        if (bal == 0) return;
        amount = bound(amount, 1, bal);
        uint256 before = assets();
        vm.prank(gateway);
        try reserve.redeem(amount, gateway, 0) returns (uint256 paid) {
            ghostRedeemed += paid;
            ghostPrincipal = ghostPrincipal > paid ? ghostPrincipal - paid : 0;
            if (assets() + paid + 3 < before) ++exitViolations;
            dust += 3;
            ++calls["redeem"];
        } catch {}
    }

    function recapitalize(uint256 amount) external {
        amount = bound(amount, 1, 300_000e6);
        uint256 before = assets();
        try reserve.recapitalize(amount) {
            ghostIn += amount;
            ghostPrincipal += amount;
            if (assets() + 3 < before + amount) ++leakViolations;
            ++calls["recapitalize"];
        } catch {}
    }

    /// Anyone harvests; it pays only the yield recipient of record, and leaves the floor intact.
    function harvest(uint8 who) external {
        address caller = [stranger, gov, guardian, gateway][who % 4];
        address to = reserve.yieldRecipient();
        uint256 before = assets();
        uint256 had = usdt.balanceOf(to);
        uint256 callerHad = usdt.balanceOf(caller);
        uint256 otherHad = recipientBalances() - had;
        vm.prank(caller);
        try reserve.harvestYield() returns (uint256 paid) {
            ghostHarvested += paid;
            if (usdt.balanceOf(to) - had != paid) ++floorViolations;
            if (caller != to && usdt.balanceOf(caller) != callerHad) ++floorViolations;
            if (recipientBalances() - usdt.balanceOf(to) != otherHad) ++floorViolations;
            (uint256 rate,) = reserve.brlPerUsdtE18();
            uint256 floor = (movva.totalSupply() * reserve.targetCollateralRatioBps() * 1e6 + rate * 10_000 - 1) / (rate * 10_000);
            if (reserve.principalUsdt() > floor) floor = reserve.principalUsdt();
            if (reserve.totalUsdt() < floor) ++floorViolations;
            if (assets() + paid + 3 < before) ++exitViolations;
            dust += 3;
            ++calls["harvest"];
        } catch {}
    }

    /// The current vault earns: income donated to it, at most 5% of the reserve's position at a time, as
    /// interest would. (Not into an empty or dust position: there a donation only inflates the share
    /// price, and the next deposit's rounding is a whole share of it - a property of that vault's share
    /// granularity, not a path out of the reserve.)
    function earn(uint256 amount) external {
        IERC4626 v = reserve.yieldVault();
        if (address(v) == address(0)) return;
        uint256 position = v.previewRedeem(v.balanceOf(address(reserve)));
        if (position < 1_000e6) return;
        amount = bound(amount, 0, position / 20);
        uint256 before = assets();
        usdt.mint(address(v), amount);
        ghostIn += assets() - before;
        ++calls["earn"];
    }

    /*//////////////////////////////////////////////////////////////
                         THE WORLD (NO MONEY MOVES)
    //////////////////////////////////////////////////////////////*/

    function moveFx(uint256 bps, bool up) external noLeak {
        bps = bound(bps, 0, 1_500);
        uint256 next = up ? (fxNow * (10_000 + bps)) / 10_000 : (fxNow * (10_000 - bps)) / 10_000;
        if (next < 2e6) next = 2e6;
        if (next > 20e6) next = 20e6;
        _publish(next);
        ++calls["moveFx"];
    }

    function warp(uint256 dt) external noLeak {
        _wait(bound(dt, 1 minutes, 12 hours));
    }

    function freeze(uint8 seed) external noLeak {
        if (seed < 64) usdt.addBlackList(address(reserve));
        else usdt.removeBlackList(address(reserve));
        ++calls[seed < 64 ? bytes32("freeze") : bytes32("unfreeze")];
    }

    /*//////////////////////////////////////////////////////////////
                     EVERY POWER THE ROLES HAVE (NO MONEY MOVES)
    //////////////////////////////////////////////////////////////*/

    function govPull(uint256 amount, bool all) external noLeak {
        vm.prank(gov);
        try reserve.pullFromVault(all ? type(uint256).max : bound(amount, 1, 1_000_000e6)) {
            ++calls["govPull"];
        } catch {}
    }

    function govPauseDeposits(bool paused) external noLeak {
        vm.prank(gov);
        reserve.setVaultDepositsPaused(paused);
    }

    /// The client chooses another source: everything back from the current vault, then the delay, then on.
    function govSwitchVault() external noLeak {
        IERC4626 cur = reserve.yieldVault();
        address next = address(cur) == address(vaults[0]) ? address(vaults[1]) : address(vaults[0]);
        if (cur.balanceOf(address(reserve)) != 0) {
            vm.prank(gov);
            try reserve.pullFromVault(type(uint256).max) {}
            catch {
                return; // frozen, or the vault has no liquidity now
            }
        }
        if (_throughTheDelay(abi.encodeCall(MovvaReserve.setYieldVault, (next)))) {
            vm.prank(gov);
            reserve.setVaultDepositsPaused(false);
            ++calls["govSwitchVault"];
        }
    }

    /// The yield recipient moves between Mova's two Safes, through the delay, either way.
    function govMoveRecipient() external noLeak {
        address next = reserve.yieldRecipient() == recipients[0] ? recipients[1] : recipients[0];
        if (_throughTheDelay(abi.encodeCall(MovvaReserve.setYieldRecipient, (next)))) ++calls["govMoveRecipient"];
    }

    /// The governor lowers the target (through the delay) or raises it (instantly): it moves the floor,
    /// never a USDT.
    function govTarget(uint256 bps) external noLeak {
        uint16 t = uint16(bound(bps, 10_000, 12_000));
        bytes memory call = abi.encodeCall(MovvaReserve.setCollateralRatios, (t, 10_000));
        if (t >= reserve.targetCollateralRatioBps()) {
            vm.prank(gov);
            reserve.setCollateralRatios(t, 10_000);
        } else if (!_throughTheDelay(call)) {
            return;
        }
        ++calls["govTarget"];
    }

    function guardianPauses(bool resume) external noLeak {
        vm.prank(resume ? gov : guardian);
        resume ? reserve.resumeMint() : reserve.pauseMint();
    }

    /// The governor, the guardian or a stranger aims a function at itself. Whatever succeeds pays no one.
    function abuse(uint8 who, uint8 which) external noLeak {
        address a = [stranger, gov, guardian][who % 3];
        bytes[8] memory c = [
            abi.encodeCall(MovvaReserve.setYieldRecipient, (a)),
            abi.encodeCall(MovvaReserve.setYieldVault, (a)),
            abi.encodeCall(MovvaReserve.setFeeRecipient, (a)),
            abi.encodeCall(MovvaReserve.setGateway, (a, true)),
            abi.encodeCall(MovvaReserve.pullFromVault, (type(uint256).max)),
            abi.encodeWithSignature("withdrawToHedge(uint256)", 1e6),
            abi.encodeWithSignature("queueHedgeWithdrawal(uint256)", 1e6),
            abi.encodeCall(DelayedGovernance.execute, (abi.encodeCall(MovvaReserve.setYieldRecipient, (a))))
        ];
        uint256 had = usdt.balanceOf(a);
        vm.prank(a);
        (bool ok,) = address(reserve).call(c[which % 8]);
        ok;
        if (usdt.balanceOf(a) != had) ++leakViolations;
        ++calls["abuse"];
    }

    /*//////////////////////////////////////////////////////////////
                                 HELPERS
    //////////////////////////////////////////////////////////////*/

    /// Schedule, wait the delay with both legs kept live, execute. False if it could not run.
    function _throughTheDelay(bytes memory call) internal returns (bool) {
        vm.prank(gov);
        try reserve.schedule(call) {}
        catch {
            return false;
        }
        _wait(reserve.GOVERNANCE_DELAY());
        vm.prank(gov);
        try reserve.execute(call) {
            return true;
        } catch {
            vm.prank(gov);
            reserve.cancel(call);
            return false;
        }
    }

    function _wait(uint256 dt) internal {
        vm.warp(block.timestamp + dt);
        feed.set(feed.answer(), block.timestamp);
        _publish(fxNow);
    }

    function _publish(uint256 e6) internal {
        uint64 at = uint64(block.timestamp);
        bytes32 d = fx.digest(e6, at, ++seq);
        (uint256 lo, uint256 hi) = vm.addr(p1) < vm.addr(p2) ? (p1, p2) : (p2, p1);
        bytes[] memory sigs = new bytes[](2);
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(lo, d);
        sigs[0] = abi.encodePacked(r, s, v);
        (v, r, s) = vm.sign(hi, d);
        sigs[1] = abi.encodePacked(r, s, v);
        fx.submit(e6, at, seq, sigs);
        fxNow = e6;
    }
}

/**
 * INVARIANTS of the principal-locked reserve (client rule, 21 October 2026):
 *
 *  - the reserve's USDT (idle + vault) never decreases except by redemptions and harvests: it is
 *    exactly what came in less what those two paid, up to the vaults' rounding;
 *  - a harvest never takes the reserve below max(principal, liabilities at the target ratio), and
 *    pays only the yield recipient of record;
 *  - the yield recipients hold exactly what was harvested, and no role or stranger ever holds a USDT;
 *  - `principalUsdt` is the cost basis: in through mint and recapitalize, out through redeem.
 */
/// forge-config: default.invariant.runs = 128
/// forge-config: default.invariant.depth = 100
/// forge-config: deep.invariant.runs = 1000
/// forge-config: deep.invariant.depth = 256
contract MovvaPrincipalLockInvariantTest is MovvaBase {
    PrincipalLockHandler handler;
    YieldVault other;

    function setUp() public override {
        super.setUp();
        other = new YieldVault(IERC20(address(usdt)), "Other source", "oUSDT", gov, guardian, keeper, 1e15, 100, DELAY);
        vm.prank(gov);
        other.completeSetup();
        _mint(1_000_000 * U);
        vm.prank(gateway);
        reserve.recapitalize(80_000 * U); // at rest, at the 108% target
        handler = new PrincipalLockHandler(
            reserve,
            usdt,
            feed,
            fx,
            [vault, other],
            [gateway, gov, guardian, yieldTo],
            [P1, P2],
            fxSeq,
            fxNow,
            reserve.principalUsdt()
        );
        targetContract(address(handler));
    }

    function invariant_ReserveUsdtFallsOnlyByRedemptionsAndHarvests() public view {
        assertEq(handler.leakViolations(), 0, "USDT left the reserve other than by redeem or harvest");
        assertEq(handler.exitViolations(), 0, "a redeem or harvest took more than it paid");
        uint256 expected = handler.ghostIn() - handler.ghostRedeemed() - handler.ghostHarvested();
        assertApproxEqAbs(handler.assets(), expected, handler.dust(), "the reserve holds in - redeemed - harvested");
        assertGe(handler.assets() + handler.dust(), expected);
    }

    function invariant_HarvestsNeverBreachTheFloor() public view {
        assertEq(handler.floorViolations(), 0, "a harvest went below max(principal, target) or paid someone else");
    }

    function invariant_OnlyTheYieldRecipientsHoldHarvestsAndNoRoleHoldsAUsdt() public view {
        assertEq(handler.recipientBalances(), handler.ghostHarvested(), "the recipients hold exactly the harvests");
        assertEq(usdt.balanceOf(gov), 0, "the governor");
        assertEq(usdt.balanceOf(guardian), 0, "the guardian");
        assertEq(usdt.balanceOf(stranger), 0, "a stranger (the handler's is the same address)");
    }

    function invariant_PrincipalIsTheCostBasis() public view {
        assertEq(reserve.principalUsdt(), handler.ghostPrincipal());
    }

    /// Not an invariant: how much of the state space each run reached (-vv).
    function afterInvariant() public view {
        string[13] memory names = [
            "mint", "redeem", "recapitalize", "harvest", "earn", "moveFx", "freeze", "govPull",
            "govSwitchVault", "govMoveRecipient", "govTarget", "abuse", "unfreeze"
        ];
        for (uint256 i; i < names.length; ++i) {
            console2.log(names[i], handler.calls(bytes32(bytes(names[i]))));
        }
    }
}
