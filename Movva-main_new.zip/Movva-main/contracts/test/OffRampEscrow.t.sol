// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Governed} from "./utils/Governed.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";
import {OffRampEscrow} from "../ramp/OffRampEscrow.sol";
import {LPRegistry} from "../ramp/LPRegistry.sol";
import {IAttestorVerifier} from "../ramp/IAttestorVerifier.sol";
import {IPriceOracle} from "../ramp/IPriceOracle.sol";
import {RulingLib} from "../ramp/RulingLib.sol";
import {Multisig1271, ContractArbitratorSigning} from "./utils/Multisig1271.sol";

contract MockVerifier2 is IAttestorVerifier {
    struct Canned {
        bytes32 bankTxId;
        bytes32 payeeKeyHash;
        uint256 amountBrlCents;
        uint64 paidAt;
        Rail rail;
        bool bound;
    }

    mapping(bytes32 => Canned) public canned;

    function setProof(bytes32 id, Canned memory c) external {
        canned[id] = c;
    }

    function verifyPayment(bytes32 id, bytes calldata) external view returns (Payment memory) {
        Canned memory c = canned[id];
        require(c.bound, "proof not bound");
        return Payment({
            bankTxId: c.bankTxId,
            payeeKeyHash: c.payeeKeyHash,
            payerRef: bytes32(uint256(9)),
            amountBrlCents: c.amountBrlCents,
            paidAt: c.paidAt,
            rail: c.rail
        });
    }

    function attestorKind() external pure returns (string memory) {
        return "mock/offramp";
    }

    function provesBankSession() external pure returns (bool) {
        return true;
    }
}

contract MockOracle2 is IPriceOracle {
    uint256 public price = 1_500_000;
    uint64 public updatedAt;

    function set(uint256 p) external {
        price = p;
    }

    function setUpdatedAt(uint64 t) external {
        updatedAt = t;
    }

    function brlCentsPerUnit() external view returns (uint256, uint64) {
        return (price, updatedAt == 0 ? uint64(block.timestamp) : updatedAt);
    }
}

contract OffRampEscrowTest is Governed, ContractArbitratorSigning {
    OffRampEscrow escrow;
    LPRegistry registry;
    MockVerifier2 verifier;
    MockOracle2 oracle;

    address governor = address(0x60F);
    address seller = address(0x5E11E1);
    // NOT low addresses: EIP-2537 put BLS12-381 precompiles at 0x0b..0x11, so paying
    // address(0x11) burns all gas and reverts - which reads exactly like a payout bug.
    address lp = makeAddr("lp");
    address lp2 = makeAddr("lp2");
    address refund = makeAddr("refund");
    address retail = makeAddr("retail");

    bytes32 constant SELLER_PIX = keccak256("seller@pix");
    uint16 constant PIX_MASK = uint16(1 << uint8(IAttestorVerifier.Rail.PIX));
    uint16 constant BOLETO_MASK = uint16(1 << uint8(IAttestorVerifier.Rail.BOLETO));

    uint256 arbKey = 0xA2B;

    function _ruling(bytes32 saleId, string memory outcome)
        internal
        view
        returns (RulingLib.Ruling memory r, bytes memory sig)
    {
        r = RulingLib.Ruling({
            orderId: saleId,
            outcome: outcome,
            evidenceRoot: keccak256("evidence"),
            rationale: "reviewed the seller's statement",
            ruledAt: uint64(block.timestamp),
            byDefault: false
        });
        (uint8 v, bytes32 rr, bytes32 ss) = vm.sign(arbKey, _rulingDigest(r));
        sig = abi.encodePacked(rr, ss, v);
    }

    /// The digest an arbitrator, key or multisig, signs for this escrow.
    function _rulingDigest(RulingLib.Ruling memory r) internal view returns (bytes32) {
        bytes32 structHash = keccak256(
            abi.encode(
                keccak256(
                    "Ruling(bytes32 orderId,address escrow,string outcome,bytes32 evidenceRoot,string rationale,uint64 ruledAt,bool byDefault)"
                ),
                r.orderId, address(escrow), keccak256(bytes(r.outcome)), r.evidenceRoot,
                keccak256(bytes(r.rationale)), r.ruledAt, r.byDefault
            )
        );
        bytes32 domain = keccak256(
            abi.encode(
                keccak256(
                    "EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)"
                ),
                keccak256("PrivacyPoolsBRL-Dispute"), keccak256("1"), block.chainid, address(escrow)
            )
        );
        return keccak256(abi.encodePacked("\x19\x01", domain, structHash));
    }

    /// Post a signed ruling, wait out RULING_DELAY, execute it.
    function _rule(bytes32 id, RulingLib.Ruling memory r, bytes memory sig) internal {
        escrow.resolveDispute(id, r, sig);
        vm.warp(block.timestamp + escrow.RULING_DELAY());
        escrow.resolveDispute(id, r, sig);
    }

    function setUp() public {
        vm.warp(1_700_000_000);
        oracle = new MockOracle2();
        verifier = new MockVerifier2();
        registry = new LPRegistry(governor, DELAY);
        escrow = new OffRampEscrow(address(oracle), address(registry), 500, governor, DELAY, DISPUTE_TIMEOUT);

        vm.startPrank(governor);
        registry.setEscrow(address(escrow), true);
        registry.setTier(lp, LPRegistry.Tier.INSTITUTIONAL, 1_000_000_00);
        registry.setTier(lp2, LPRegistry.Tier.INSTITUTIONAL, 1_000_000_00);
        escrow.setVerifier(address(verifier), true);
        escrow.setArbitrator(vm.addr(arbKey), true);
        registry.setPhase(LPRegistry.Phase.C);
        registry.completeSetup();
        escrow.completeSetup();
        vm.stopPrank();
        vm.prank(retail);
        registry.register();

        vm.deal(seller, 10 ether);
    }

    function _open(uint16 mask) internal returns (bytes32) {
        vm.prank(seller);
        return escrow.openSale{value: 1 ether}(
            address(0), 1 ether, 1_500_000, SELLER_PIX, address(verifier), mask, refund
        );
    }

    function _proof(bytes32 id, uint256 cents, IAttestorVerifier.Rail rail, uint64 paidAt)
        internal
    {
        verifier.setProof(
            id,
            MockVerifier2.Canned({
                bankTxId: keccak256(abi.encode(id, cents, rail)),
                payeeKeyHash: SELLER_PIX,
                amountBrlCents: cents,
                paidAt: paidAt,
                rail: rail,
                bound: true
            })
        );
    }

    /*//////////////////////////////////////////////////////////////
                              HAPPY PATH
    //////////////////////////////////////////////////////////////*/

    function test_OffRamp_SellerGetsBrlLPGetsEth() public {
        bytes32 id = _open(PIX_MASK);
        vm.prank(lp);
        escrow.claimSale(id);

        _proof(id, 1_500_000, IAttestorVerifier.Rail.PIX, uint64(block.timestamp));
        uint256 before = lp.balance;
        escrow.settleWithProof(id, "");

        assertEq(lp.balance - before, 1 ether, "LP paid BRL, collected the ETH");
    }

    /*//////////////////////////////////////////////////////////////
                        SELLING TO PAY A BILL
    //////////////////////////////////////////////////////////////*/

    /// Stands in for boletoCommitment(the bill's barcode, salt).
    bytes32 constant BILL = keccak256("the seller's electricity bill, salted");

    /// A sale whose payee is a boleto: the commitment to the bill, BOLETO and nothing else.
    function _openBill(uint256 cents) internal returns (bytes32) {
        vm.prank(seller);
        return escrow.openSale{value: 1 ether}(
            address(0), 1 ether, cents, BILL, address(verifier), BOLETO_MASK, refund
        );
    }

    function _billProof(bytes32 id, bytes32 payee, uint256 cents, IAttestorVerifier.Rail rail) internal {
        verifier.setProof(
            id,
            MockVerifier2.Canned({
                bankTxId: keccak256(abi.encode(id, payee, cents, rail)),
                payeeKeyHash: payee,
                amountBrlCents: cents,
                paidAt: uint64(block.timestamp),
                rail: rail,
                bound: true
            })
        );
    }

    function test_ASaleWhosePayeeIsABillSettlesWhenTheLPPaysIt() public {
        bytes32 id = _openBill(1_500_000);
        vm.prank(lp);
        escrow.claimSale(id);
        _billProof(id, BILL, 1_500_000, IAttestorVerifier.Rail.BOLETO);
        escrow.settleWithProof(id, "");
        assertEq(lp.balance, 1 ether);
    }

    /// One commitment is a key or a barcode. A mask mixing them would let a PIX transfer to
    /// nobody's key "pay" a bill, so it is refused when the sale is opened.
    function test_ASaleCannotMixABoletoPayeeWithKeyRails() public {
        vm.prank(seller);
        vm.expectRevert(OffRampEscrow.BadSale.selector);
        escrow.openSale{value: 1 ether}(
            address(0), 1 ether, 1_500_000, BILL, address(verifier), BOLETO_MASK | PIX_MASK, refund
        );
    }

    function test_APixTransferCannotPayABill() public {
        bytes32 id = _openBill(1_500_000);
        vm.prank(lp);
        escrow.claimSale(id);
        _billProof(id, BILL, 1_500_000, IAttestorVerifier.Rail.PIX);
        vm.expectRevert(OffRampEscrow.RailNotAccepted.selector);
        escrow.settleWithProof(id, "");
    }

    /// Paying some other bill - the LP's own, say - is not paying the seller's.
    function test_PayingADifferentBillDoesNotSettle() public {
        bytes32 id = _openBill(1_500_000);
        vm.prank(lp);
        escrow.claimSale(id);
        _billProof(id, keccak256("the LP's own bill"), 1_500_000, IAttestorVerifier.Rail.BOLETO);
        vm.expectRevert(OffRampEscrow.WrongPayee.selector);
        escrow.settleWithProof(id, "");
    }

    /// A bill is paid for its face value, which the sale must equal.
    function test_ABillPaidForAnotherAmountDoesNotSettle() public {
        bytes32 id = _openBill(1_500_000);
        vm.prank(lp);
        escrow.claimSale(id);
        _billProof(id, BILL, 1_500_001, IAttestorVerifier.Rail.BOLETO);
        vm.expectRevert(OffRampEscrow.WrongAmount.selector);
        escrow.settleWithProof(id, "");
        _billProof(id, BILL, 1_499_999, IAttestorVerifier.Rail.BOLETO);
        vm.expectRevert(OffRampEscrow.Underpaid.selector);
        escrow.settleWithProof(id, "");
    }

    /// And a proof bound to one sale is refused on another, even for the same bill.
    function test_ABillPaymentBoundToAnotherSaleDoesNotSettle() public {
        bytes32 a = _openBill(1_500_000);
        bytes32 b = _openBill(1_500_000);
        vm.prank(lp);
        escrow.claimSale(b);
        _billProof(a, BILL, 1_500_000, IAttestorVerifier.Rail.BOLETO);
        vm.expectRevert(bytes("proof not bound"));
        escrow.settleWithProof(b, "");
    }

    /// A seller who needs the money today must not be handed a banking-day instrument.
    function test_SellerWhoAcceptsOnlyPixRefusesABoleto() public {
        bytes32 id = _open(PIX_MASK);
        vm.prank(lp);
        escrow.claimSale(id);
        _proof(id, 1_500_000, IAttestorVerifier.Rail.BOLETO, uint64(block.timestamp));
        vm.expectRevert(OffRampEscrow.RailNotAccepted.selector);
        escrow.settleWithProof(id, "");
    }

    function test_UnspecifiedRailIsNeverAccepted() public {
        // The most permissive sale that can exist: every rail bit but BOLETO (a bill is its own
        // payee).
        bytes32 id = _open(uint16(0xFFFF) & ~BOLETO_MASK);
        vm.prank(lp);
        escrow.claimSale(id);
        _proof(id, 1_500_000, IAttestorVerifier.Rail.UNSPECIFIED, uint64(block.timestamp));
        vm.expectRevert(OffRampEscrow.RailNotAccepted.selector);
        escrow.settleWithProof(id, "");
    }

    /*//////////////////////////////////////////////////////////////
                    THE SELLER MUST NOT BE FROZEN
    //////////////////////////////////////////////////////////////*/

    /// The griefing attack this contract exists to bound: claim, never pay.
    function test_StaleClaimCanBeClearedByAnyone() public {
        bytes32 id = _open(PIX_MASK);
        vm.prank(lp);
        escrow.claimSale(id);

        vm.warp(block.timestamp + 46 minutes);
        vm.prank(address(0xBEEF)); // a stranger, because a gasless seller must not be stuck
        escrow.releaseStaleClaim(id);

        // Another LP can serve the seller once the cooldown that leaves the seller a window to
        // cancel in has passed (SRM1-13).
        vm.warp(block.timestamp + escrow.CLAIM_COOLDOWN());
        vm.prank(lp2);
        escrow.claimSale(id);
        _proof(id, 1_500_000, IAttestorVerifier.Rail.PIX, uint64(block.timestamp));
        escrow.settleWithProof(id, "");
        assertEq(lp2.balance, 1 ether);
    }

    function test_ExpiredClaimantCannotStillSettle() public {
        bytes32 id = _open(PIX_MASK);
        vm.prank(lp);
        escrow.claimSale(id);
        _proof(id, 1_500_000, IAttestorVerifier.Rail.PIX, uint64(block.timestamp));
        vm.warp(block.timestamp + 46 minutes);
        vm.expectRevert(OffRampEscrow.WindowExpired.selector);
        escrow.settleWithProof(id, "");
    }

    function test_SellerCanCancelWhileUnclaimed() public {
        bytes32 id = _open(PIX_MASK);
        vm.prank(seller);
        escrow.cancelSale(id);
        assertEq(refund.balance, 1 ether, "refund goes to the named address, not msg.sender");
    }

    /// The mirror-image attack: seller yanks the ETH after the BRL has been sent.
    function test_SellerCannotCancelUnderALiveClaim() public {
        bytes32 id = _open(PIX_MASK);
        vm.prank(lp);
        escrow.claimSale(id);
        vm.prank(seller);
        vm.expectRevert(OffRampEscrow.WrongState.selector);
        escrow.cancelSale(id);
    }

    function test_TwoLPsCannotBothClaim() public {
        bytes32 id = _open(PIX_MASK);
        vm.prank(lp);
        escrow.claimSale(id);
        vm.prank(lp2);
        vm.expectRevert(OffRampEscrow.AlreadyClaimed.selector);
        escrow.claimSale(id);
    }

    function test_LiveClaimCannotBeClearedEarly() public {
        bytes32 id = _open(PIX_MASK);
        vm.prank(lp);
        escrow.claimSale(id);
        vm.expectRevert(OffRampEscrow.ClaimStillLive.selector);
        escrow.releaseStaleClaim(id);
    }

    function test_LPCanHandBackAClaimEarly() public {
        bytes32 id = _open(PIX_MASK);
        vm.prank(lp);
        escrow.claimSale(id);
        vm.prank(lp);
        escrow.abandonClaim(id);
        (,,,,,,,,,,, OffRampEscrow.SaleState st) = escrow.sales(id);
        assertEq(uint8(st), uint8(OffRampEscrow.SaleState.OPEN), "handed back at once");
        // Claimable again after CLAIM_COOLDOWN, the seller's window to cancel in (SRM1-13).
        vm.warp(block.timestamp + escrow.CLAIM_COOLDOWN());
        vm.prank(lp2);
        escrow.claimSale(id);
    }

    /*//////////////////////////////////////////////////////////////
          THE SELLER CAN ALWAYS CANCEL; A CLAIM CANNOT BE RENEWED (SRM1-13)
    //////////////////////////////////////////////////////////////*/

    function _stateOf(bytes32 id) internal view returns (OffRampEscrow.SaleState st) {
        (,,,,,,,,,,, st) = escrow.sales(id);
    }

    /// A stale claim protects nobody: the seller cancels it directly, and the LP's credit is freed.
    function test_SellerCanCancelAStaleClaimDirectly() public {
        bytes32 id = _open(PIX_MASK);
        vm.prank(lp);
        escrow.claimSale(id);
        vm.warp(block.timestamp + escrow.PAY_WINDOW() + 1);

        vm.expectEmit(true, true, false, true, address(escrow));
        emit OffRampEscrow.SaleUnclaimed(id, lp, true);
        vm.prank(seller);
        escrow.cancelSale(id);

        assertEq(refund.balance, 1 ether, "the crypto back to the refund address");
        assertEq(uint8(_stateOf(id)), uint8(OffRampEscrow.SaleState.CANCELLED));
        assertEq(registry.reservedBy(address(escrow), lp), 0, "the stale LP's credit is freed");
    }

    /// At payBy exactly the claim is still live: settleWithProof would still accept a proof.
    function test_SellerCannotCancelAClaimAtItsLastLiveSecond() public {
        bytes32 id = _open(PIX_MASK);
        vm.prank(lp);
        escrow.claimSale(id);
        vm.warp(block.timestamp + escrow.PAY_WINDOW());
        vm.prank(seller);
        vm.expectRevert(OffRampEscrow.WrongState.selector);
        escrow.cancelSale(id);
        // ...and the LP can still settle in that second.
        _proof(id, 1_500_000, IAttestorVerifier.Rail.PIX, uint64(block.timestamp));
        escrow.settleWithProof(id, "");
    }

    /// Only the seller: a stranger cannot cancel a stale-claimed sale on the seller's behalf.
    function test_OnlyTheSellerCancelsAStaleClaim() public {
        bytes32 id = _open(PIX_MASK);
        vm.prank(lp);
        escrow.claimSale(id);
        vm.warp(block.timestamp + escrow.PAY_WINDOW() + 1);
        vm.prank(lp);
        vm.expectRevert(OffRampEscrow.NotSeller.selector);
        escrow.cancelSale(id);
    }

    /// Adversarial: the LP releases its own stale claim and re-claims in the same block. The
    /// re-claim is refused, and the seller's cancel, ordered after the release, lands.
    function test_AStaleClaimCannotBeRenewedInTheSameBlock() public {
        bytes32 id = _open(PIX_MASK);
        vm.prank(lp);
        escrow.claimSale(id);
        vm.warp(block.timestamp + escrow.PAY_WINDOW() + 1);

        vm.startPrank(lp);
        escrow.releaseStaleClaim(id);
        vm.expectRevert(
            abi.encodeWithSelector(
                OffRampEscrow.ClaimCoolingDown.selector, uint64(block.timestamp) + escrow.CLAIM_COOLDOWN()
            )
        );
        escrow.claimSale(id);
        vm.stopPrank();

        vm.prank(seller);
        escrow.cancelSale(id);
        assertEq(refund.balance, 1 ether);
    }

    /// Adversarial: abandoning a live claim just before payBy and re-claiming - by the same LP or
    /// by another identity (a sponsored affiliate, a retail address) - is refused too; the
    /// cooldown is per sale, not per LP.
    function test_AnAbandonedClaimCannotBeRenewedByAnyLP() public {
        bytes32 id = _open(PIX_MASK);
        vm.prank(lp);
        escrow.claimSale(id);
        vm.warp(block.timestamp + escrow.PAY_WINDOW() - 1);
        vm.prank(lp);
        escrow.abandonClaim(id);

        uint64 at = uint64(block.timestamp) + escrow.CLAIM_COOLDOWN();
        vm.prank(lp);
        vm.expectRevert(abi.encodeWithSelector(OffRampEscrow.ClaimCoolingDown.selector, at));
        escrow.claimSale(id);
        vm.prank(lp2);
        vm.expectRevert(abi.encodeWithSelector(OffRampEscrow.ClaimCoolingDown.selector, at));
        escrow.claimSale(id);
        vm.prank(retail);
        vm.expectRevert(abi.encodeWithSelector(OffRampEscrow.ClaimCoolingDown.selector, at));
        escrow.claimSale(id);
        assertEq(escrow.claimableAt(id), at);

        // The seller's cancel lands at any moment of the cooldown; here, its last second.
        vm.warp(at - 1);
        vm.prank(seller);
        escrow.cancelSale(id);
        assertEq(refund.balance, 1 ether);
    }

    /// Adversarial, the review's loop (SRM1-13): an LP that renews its claim whenever it can never
    /// shuts the seller out. Every cycle leaves the seller a cancellable window, without a race.
    function test_RenewingClaimsNeverLocksTheSellerOut() public {
        bytes32 id = _open(PIX_MASK);
        for (uint256 i; i < 5; ++i) {
            vm.prank(lp);
            escrow.claimSale(id);
            vm.warp(block.timestamp + escrow.PAY_WINDOW() + 1);
            vm.prank(lp);
            escrow.releaseStaleClaim(id);
            vm.prank(lp);
            vm.expectRevert(); // ClaimCoolingDown: the renewal must wait
            escrow.claimSale(id);
            vm.warp(block.timestamp + escrow.CLAIM_COOLDOWN());
        }
        // Mid-claim the seller cannot leave; once the claim is stale it can, at once.
        vm.prank(lp);
        escrow.claimSale(id);
        vm.prank(seller);
        vm.expectRevert(OffRampEscrow.WrongState.selector);
        escrow.cancelSale(id);
        vm.warp(block.timestamp + escrow.PAY_WINDOW() + 1);
        vm.prank(seller);
        escrow.cancelSale(id);
        assertEq(refund.balance, 1 ether);
    }

    /// A sale nobody has claimed is claimable at once: the cooldown follows only an ended claim.
    function test_AFreshSaleHasNoCooldown() public {
        bytes32 id = _open(PIX_MASK);
        assertEq(escrow.claimableAt(id), 0);
        vm.prank(lp);
        escrow.claimSale(id);
    }

    /// A settled sale can never be cancelled, stale or not (its payBy is past, but it is SETTLED).
    function test_ASettledSaleIsNotCancellable() public {
        bytes32 id = _open(PIX_MASK);
        vm.prank(lp);
        escrow.claimSale(id);
        _proof(id, 1_500_000, IAttestorVerifier.Rail.PIX, uint64(block.timestamp));
        escrow.settleWithProof(id, "");
        vm.warp(block.timestamp + escrow.PAY_WINDOW() + 1);
        vm.prank(seller);
        vm.expectRevert(OffRampEscrow.WrongState.selector);
        escrow.cancelSale(id);
    }

    /// A disputed sale stays out of cancelSale even once its payBy is past: the dispute path ends it.
    function test_ADisputedSaleIsNotCancellable() public {
        bytes32 id = _open(PIX_MASK);
        vm.prank(lp);
        escrow.claimSale(id);
        vm.prank(lp);
        escrow.raiseDispute(id, "paid, receipt late");
        vm.warp(block.timestamp + escrow.PAY_WINDOW() + 1);
        vm.prank(seller);
        vm.expectRevert(OffRampEscrow.WrongState.selector);
        escrow.cancelSale(id);
    }

    /// H-04: the LP disputes only while its claim is live. A stale claim cannot settle any more, so
    /// an LP's dispute then could only freeze the seller's money; the seller cancels instead.
    function test_AnLPCannotDisputeAStaleClaim() public {
        bytes32 id = _open(PIX_MASK);
        vm.prank(lp);
        escrow.claimSale(id);
        (,,,,,,,,, uint64 payBy,,) = escrow.sales(id);
        vm.warp(payBy + 1);
        vm.prank(lp);
        vm.expectRevert(OffRampEscrow.WindowExpired.selector);
        escrow.raiseDispute(id, "paid late");
        uint256 before = refund.balance;
        vm.prank(seller);
        escrow.cancelSale(id);
        assertEq(refund.balance - before, 1 ether, "nothing the LP did could hold the seller's money");
    }

    /// Up to and including `payBy` the LP may still dispute, and the seller is never windowed.
    function test_AnLPMayDisputeUntilPayByAndTheSellerIsNotWindowed() public {
        bytes32 a = _open(PIX_MASK);
        bytes32 b = _open(PIX_MASK);
        vm.startPrank(lp);
        escrow.claimSale(a);
        escrow.claimSale(b);
        vm.stopPrank();
        (,,,,,,,,, uint64 payBy,,) = escrow.sales(a);
        vm.warp(payBy);
        vm.prank(lp);
        escrow.raiseDispute(a, "paid, attestor down");
        vm.warp(payBy + 1);
        vm.prank(seller);
        escrow.raiseDispute(b, "the LP says it paid; nothing arrived");
        assertEq(uint8(_stateOf(a)), uint8(OffRampEscrow.SaleState.DISPUTED));
        assertEq(uint8(_stateOf(b)), uint8(OffRampEscrow.SaleState.DISPUTED));
    }

    /*//////////////////////////////////////////////////////////////
                          RECEIPT INTEGRITY
    //////////////////////////////////////////////////////////////*/

    function test_PayingSomeoneElseDoesNotSettle() public {
        bytes32 id = _open(PIX_MASK);
        vm.prank(lp);
        escrow.claimSale(id);
        verifier.setProof(
            id,
            MockVerifier2.Canned({
                bankTxId: keccak256("x"),
                payeeKeyHash: keccak256("attacker@pix"),
                amountBrlCents: 1_500_000,
                paidAt: uint64(block.timestamp),
                rail: IAttestorVerifier.Rail.PIX,
                bound: true
            })
        );
        vm.expectRevert(OffRampEscrow.WrongPayee.selector);
        escrow.settleWithProof(id, "");
    }

    function test_ShortPayingTheSellerDoesNotSettle() public {
        bytes32 id = _open(PIX_MASK);
        vm.prank(lp);
        escrow.claimSale(id);
        _proof(id, 1_499_999, IAttestorVerifier.Rail.PIX, uint64(block.timestamp));
        vm.expectRevert(OffRampEscrow.Underpaid.selector);
        escrow.settleWithProof(id, "");
    }

    /// An LP who genuinely paid this seller once must not reuse that transfer on a later sale.
    function test_ReceiptPredatingTheClaimIsRejected() public {
        bytes32 id = _open(PIX_MASK);
        uint64 old = uint64(block.timestamp);
        vm.warp(block.timestamp + 1 hours);
        vm.prank(lp);
        escrow.claimSale(id);
        _proof(id, 1_500_000, IAttestorVerifier.Rail.PIX, old);
        vm.expectRevert(OffRampEscrow.ReceiptPredatesClaim.selector);
        escrow.settleWithProof(id, "");
    }

    function test_SameReceiptCannotSettleTwoSales() public {
        bytes32 a = _open(PIX_MASK);
        bytes32 b = _open(PIX_MASK);
        vm.prank(lp);
        escrow.claimSale(a);
        vm.prank(lp);
        escrow.claimSale(b);

        MockVerifier2.Canned memory c = MockVerifier2.Canned({
            bankTxId: keccak256("one transfer"),
            payeeKeyHash: SELLER_PIX,
            amountBrlCents: 1_500_000,
            paidAt: uint64(block.timestamp),
            rail: IAttestorVerifier.Rail.PIX,
            bound: true
        });
        verifier.setProof(a, c);
        verifier.setProof(b, c);

        escrow.settleWithProof(a, "");
        vm.expectRevert(OffRampEscrow.ReceiptReplayed.selector);
        escrow.settleWithProof(b, "");
    }

    /*//////////////////////////////////////////////////////////////
                          PRICE AND DISPUTES
    //////////////////////////////////////////////////////////////*/

    /// This is the leg where a mistake means giving ETH away for centavos.
    function test_AbsurdlyCheapSaleIsRefused() public {
        vm.prank(seller);
        vm.expectRevert(OffRampEscrow.PriceOutsideBand.selector);
        escrow.openSale{value: 1 ether}(
            address(0), 1 ether, 100, SELLER_PIX, address(verifier), PIX_MASK, refund
        );
    }

    function test_SellerCannotOpenAgainstAStalePrice() public {
        vm.warp(block.timestamp + 10 days);
        oracle.setUpdatedAt(uint64(block.timestamp - 2 hours));
        vm.prank(seller);
        vm.expectRevert(OffRampEscrow.StalePrice.selector);
        escrow.openSale{value: 1 ether}(
            address(0), 1 ether, 1_500_000, SELLER_PIX, address(verifier), PIX_MASK, refund
        );
    }

    function test_DisputeCanPayTheLPWhenTheyReallyPaid() public {
        bytes32 id = _open(PIX_MASK);
        vm.prank(lp);
        escrow.claimSale(id);
        vm.prank(lp);
        escrow.raiseDispute(id, "attestor offline, I paid");
        (RulingLib.Ruling memory r, bytes memory sig) = _ruling(id, "RELEASE");
        _rule(id, r, sig);
        assertEq(lp.balance, 1 ether);
    }

    function test_DisputeRefundsTheSellerAndPenalisesTheLP() public {
        // R$3,000, inside a new retail LP's R$5,000 cap. The default 1 ETH sale is
        // R$15,000 here, which a retail LP is correctly not allowed to take on.
        vm.prank(seller);
        bytes32 id = escrow.openSale{value: 0.2 ether}(
            address(0), 0.2 ether, 300_000, SELLER_PIX, address(verifier), PIX_MASK, refund
        );
        vm.prank(retail);
        escrow.claimSale(id);
        vm.prank(seller);
        escrow.raiseDispute(id, "never received");

        uint256 capBefore = registry.capOf(retail);
        (RulingLib.Ruling memory r, bytes memory sig) = _ruling(id, "REFUND");
        _rule(id, r, sig);
        assertEq(refund.balance, 0.2 ether, "seller made whole");
        assertEq(registry.capOf(retail), capBefore / 2, "LP's limit cut");
    }

    /**
     * The off-ramp version of the governor theft: be the claiming LP, dispute, and have a
     * freshly added arbitrator rule that the LP paid. Adding the arbitrator waits, sellers
     * can cancel unclaimed sales meanwhile, and a sale disputed before the arbitrator existed
     * cannot be released to the LP by it.
     */
    function test_AGovernorsNewArbitratorCannotPayItselfForASaleItNeverPaid() public {
        bytes32 hostage = _open(PIX_MASK);
        bytes32 bystander = _open(PIX_MASK);
        uint256 govArbKey = 0x60F60F;
        bytes memory addArb = abi.encodeCall(OffRampEscrow.setArbitrator, (vm.addr(govArbKey), true));

        vm.prank(governor);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, OffRampEscrow.setArbitrator.selector)
        );
        escrow.setArbitrator(vm.addr(govArbKey), true);
        vm.prank(governor);
        escrow.schedule(addArb);

        // lp stands in for an LP the governor controls: claims and disputes during the delay.
        vm.prank(lp);
        escrow.claimSale(hostage);
        vm.prank(lp);
        escrow.raiseDispute(hostage, "paid, attestor down");

        // A seller who reads the schedule cancels what is still unclaimed.
        vm.prank(seller);
        escrow.cancelSale(bystander);
        assertEq(refund.balance, 1 ether);

        vm.warp(block.timestamp + DELAY);
        vm.prank(governor);
        escrow.execute(addArb);

        arbKey = govArbKey;
        (RulingLib.Ruling memory r, bytes memory sig) = _ruling(hostage, "RELEASE");
        vm.prank(governor);
        vm.expectRevert(
            abi.encodeWithSelector(OffRampEscrow.ArbitratorNewerThanDispute.selector, vm.addr(govArbKey))
        );
        escrow.resolveDispute(hostage, r, sig);
        assertEq(lp.balance, 0);
    }

    /*//////////////////////////////////////////////////////////////
                         DISPUTES END
    //////////////////////////////////////////////////////////////*/

    function _claimedAndDisputedBy(address by) internal returns (bytes32 id) {
        vm.prank(seller);
        // R$1,500: two of these fit inside a new retail LP's R$5,000 limit at once.
        id = escrow.openSale{value: 0.1 ether}(
            address(0), 0.1 ether, 150_000, SELLER_PIX, address(verifier), PIX_MASK, refund
        );
        vm.prank(retail);
        escrow.claimSale(id);
        vm.prank(by);
        escrow.raiseDispute(id, "disputed");
    }

    function _lost(address who) internal view returns (uint32 lost) {
        (,,, lost,,,) = registry.lps(who);
    }

    /// No governor at all: the LP the ruling favours submits it itself.
    function test_WithNoGovernorTheLPSubmitsTheRulingThatPaysIt() public {
        bytes32 id = _open(PIX_MASK);
        vm.prank(lp);
        escrow.claimSale(id);
        vm.prank(lp);
        escrow.raiseDispute(id, "paid, attestor down");
        (RulingLib.Ruling memory r, bytes memory sig) = _ruling(id, "RELEASE");
        vm.prank(governor);
        escrow.transferGovernor(address(0xdead));
        vm.startPrank(lp);
        escrow.resolveDispute(id, r, sig);
        vm.warp(block.timestamp + 1 days);
        escrow.resolveDispute(id, r, sig);
        vm.stopPrank();
        assertEq(lp.balance, 1 ether);
    }

    /// The desk is dead. After the timeout anyone refunds the seller and frees the LP's credit.
    function test_ADeadDeskCannotFreezeASale_TheTimeoutRefundsTheSeller() public {
        bytes32 id = _claimedAndDisputedBy(seller);
        (,,,,,, uint256 exposure) = registry.lps(retail);
        assertEq(exposure, 150_000, "the claim holds the LP's credit");

        vm.warp(block.timestamp + DISPUTE_TIMEOUT);
        vm.prank(address(0xBEEF));
        escrow.expireDispute(id);

        assertEq(refund.balance, 0.1 ether, "seller made whole at the refund address");
        (,,,,,, exposure) = registry.lps(retail);
        assertEq(exposure, 0, "credit released");
        assertEq(registry.reservedBy(address(escrow), retail), 0);
        assertEq(_lost(retail), 0, "a seller's unanswered dispute costs the LP nothing");
        assertEq(address(escrow).balance, 0);
    }

    function test_AnLPsOwnDisputeThatTimesOutCountsAgainstIt() public {
        bytes32 id = _claimedAndDisputedBy(retail);
        vm.warp(block.timestamp + DISPUTE_TIMEOUT);
        escrow.expireDispute(id);
        assertEq(_lost(retail), 1);
        (, uint256 settled,,,,,) = registry.lps(retail);
        assertEq(settled, 0, "a timeout is never volume");
    }

    function test_ExpiringASaleBeforeTheTimeoutIsRefused() public {
        bytes32 id = _claimedAndDisputedBy(seller);
        uint64 deadline = uint64(block.timestamp + DISPUTE_TIMEOUT);
        vm.warp(deadline - 1);
        vm.expectRevert(abi.encodeWithSelector(OffRampEscrow.DisputeStillOpen.selector, deadline));
        escrow.expireDispute(id);
    }

    function test_ARulingOnASaleAfterTheDeadlineIsRefused() public {
        bytes32 id = _claimedAndDisputedBy(retail);
        uint64 deadline = uint64(block.timestamp + DISPUTE_TIMEOUT);
        vm.warp(deadline);
        (RulingLib.Ruling memory r, bytes memory sig) = _ruling(id, "RELEASE");
        vm.expectRevert(abi.encodeWithSelector(OffRampEscrow.DisputeExpired.selector, deadline));
        escrow.resolveDispute(id, r, sig);
    }

    function test_ASaleRulingCannotBeReplayedOnceExecuted() public {
        bytes32 id = _claimedAndDisputedBy(seller);
        (RulingLib.Ruling memory r, bytes memory sig) = _ruling(id, "REFUND");
        _rule(id, r, sig);
        vm.expectRevert(OffRampEscrow.WrongState.selector);
        escrow.resolveDispute(id, r, sig);
        vm.warp(block.timestamp + DISPUTE_TIMEOUT);
        vm.expectRevert(OffRampEscrow.WrongState.selector);
        escrow.expireDispute(id);
    }

    function test_ASaleRulingCannotBeMovedToAnotherSale() public {
        bytes32 a = _claimedAndDisputedBy(seller);
        bytes32 b = _claimedAndDisputedBy(seller);
        (RulingLib.Ruling memory r, bytes memory sig) = _ruling(a, "REFUND");
        vm.expectRevert(OffRampEscrow.RulingForAnotherOrder.selector);
        escrow.resolveDispute(b, r, sig);
    }

    /// The off-ramp form of a stolen key: claim sales as an LP, dispute, rule RELEASE for itself.
    function test_AStolenArbitratorKeyCannotPayItselfForSalesItNeverPaid() public {
        bytes32 id = _open(PIX_MASK);
        vm.prank(lp); // an LP account the thief controls
        escrow.claimSale(id);
        vm.prank(lp);
        escrow.raiseDispute(id, "paid, attestor down");
        (RulingLib.Ruling memory r, bytes memory sig) = _ruling(id, "RELEASE");
        escrow.resolveDispute(id, r, sig);

        vm.prank(governor);
        escrow.setArbitrator(vm.addr(arbKey), false);
        vm.warp(block.timestamp + 1 days);
        vm.expectRevert(abi.encodeWithSelector(OffRampEscrow.NotArbitrator.selector, vm.addr(arbKey)));
        escrow.resolveDispute(id, r, sig);

        vm.warp(block.timestamp + DISPUTE_TIMEOUT);
        escrow.expireDispute(id);
        assertEq(refund.balance, 1 ether, "the seller, not the thief");
        assertEq(lp.balance, 0);
    }

    function test_AnOffRampRulingWaitsADay() public {
        bytes32 id = _claimedAndDisputedBy(seller);
        (RulingLib.Ruling memory r, bytes memory sig) = _ruling(id, "REFUND");
        escrow.resolveDispute(id, r, sig);
        uint64 executableAt = uint64(block.timestamp + 1 days);
        vm.expectRevert(abi.encodeWithSelector(OffRampEscrow.RulingNotReady.selector, executableAt));
        escrow.resolveDispute(id, r, sig);
        vm.warp(executableAt);
        escrow.resolveDispute(id, r, sig);
        assertEq(refund.balance, 0.1 ether);
    }

    function test_TheOffRampDisputeTimeoutIsBounded() public {
        vm.expectRevert(abi.encodeWithSelector(OffRampEscrow.BadDisputeTimeout.selector, uint256(6 days)));
        new OffRampEscrow(address(oracle), address(registry), 500, governor, DELAY, 6 days);
        vm.expectRevert(abi.encodeWithSelector(OffRampEscrow.BadDisputeTimeout.selector, uint256(91 days)));
        new OffRampEscrow(address(oracle), address(registry), 500, governor, DELAY, 91 days);
    }

    function test_NoSalesBeforeSetupIsComplete() public {
        OffRampEscrow fresh = new OffRampEscrow(address(oracle), address(registry), 500, governor, DELAY, DISPUTE_TIMEOUT);
        vm.prank(seller);
        vm.expectRevert(DelayedGovernance.SetupIncomplete.selector);
        fresh.openSale{value: 1 ether}(
            address(0), 1 ether, 1_500_000, SELLER_PIX, address(verifier), PIX_MASK, refund
        );
    }

    /// The governor can only ever pick between the LP and the seller's own refund address.
    function test_GovernorCannotReachAnUndisputedSale() public {
        bytes32 id = _open(PIX_MASK);
        vm.prank(lp);
        escrow.claimSale(id);
        (RulingLib.Ruling memory r, bytes memory sig) = _ruling(id, "RELEASE");
        vm.prank(governor);
        vm.expectRevert(OffRampEscrow.WrongState.selector);
        escrow.resolveDispute(id, r, sig);
    }

    /// The bug this replaced: one registry served one escrow, so off-ramp settlements were
    /// dropped in silence and an LP could work this leg forever without building any limit.
    function test_OffRampSettlementsBuildReputation() public {
        vm.prank(seller);
        bytes32 id = escrow.openSale{value: 0.2 ether}(
            address(0), 0.2 ether, 300_000, SELLER_PIX, address(verifier), PIX_MASK, refund
        );
        uint256 capBefore = registry.capOf(retail);
        vm.prank(retail);
        escrow.claimSale(id);
        _proof(id, 300_000, IAttestorVerifier.Rail.PIX, uint64(block.timestamp));
        escrow.settleWithProof(id, "");

        assertGt(registry.capOf(retail), capBefore, "settling on the off-ramp raised the limit");
        (, uint256 settledCents,,,,,) = registry.lps(retail);
        assertEq(settledCents, 300_000, "in centavos, comparable with the on-ramp");
    }

    /// A registry must ignore reports from a contract it does not know, and do so quietly.
    function test_AnUnknownEscrowIsIgnoredRatherThanReverting() public {
        uint256 capBefore = registry.capOf(lp);
        vm.prank(address(0xBAD));
        registry.recordSettled(lp, 999_999_999); // must not revert, must not count
        assertEq(registry.capOf(lp), capBefore);
    }

    /// Revocation must reach live sales too - see FiatEscrow's equivalent.
    function test_RevokingAVerifierStopsSettlementOnLiveSales() public {
        bytes32 id = _open(PIX_MASK);
        vm.prank(lp);
        escrow.claimSale(id);
        _proof(id, 1_500_000, IAttestorVerifier.Rail.PIX, uint64(block.timestamp));

        vm.prank(governor);
        escrow.setVerifier(address(verifier), false);

        vm.expectRevert(OffRampEscrow.VerifierNotAllowed.selector);
        escrow.settleWithProof(id, "");
    }

    function test_UneligibleLPCannotClaim() public {
        bytes32 id = _open(PIX_MASK);
        vm.prank(address(0xBAD));
        vm.expectRevert(OffRampEscrow.LPNotEligible.selector);
        escrow.claimSale(id);
    }

    /*//////////////////////////////////////////////////////////////
          CONTRACT ARBITRATORS: THE 2-OF-3 SAFE RULES (SRM1-22)
    //////////////////////////////////////////////////////////////*/

    function _multisigArbitrator() internal returns (Multisig1271 ms, uint256[] memory two) {
        address[] memory owners = new address[](3);
        two = new uint256[](2);
        for (uint256 i; i < 3; i++) owners[i] = vm.addr(0x5AFE01 + i);
        (two[0], two[1]) = (0x5AFE01, 0x5AFE03);
        ms = new Multisig1271(owners, 2);
        _afterDelay(address(escrow), abi.encodeCall(OffRampEscrow.setArbitrator, (address(ms), true)));
        vm.prank(governor);
        escrow.setArbitrator(vm.addr(arbKey), false);
    }

    function test_AMultisigArbitratorPaysTheLPWithTwoOfThree() public {
        (Multisig1271 ms, uint256[] memory two) = _multisigArbitrator();
        bytes32 id = _open(PIX_MASK);
        vm.prank(lp);
        escrow.claimSale(id);
        vm.prank(lp);
        escrow.raiseDispute(id, "attestor offline, I paid");
        (RulingLib.Ruling memory r, bytes memory eoaSig) = _ruling(id, "RELEASE");
        vm.expectRevert(abi.encodeWithSelector(OffRampEscrow.NotArbitrator.selector, vm.addr(arbKey)));
        escrow.resolveDispute(id, r, eoaSig);

        _rule(id, r, _multisigSig(address(ms), _rulingDigest(r), two));
        assertEq(lp.balance, 1 ether);
    }

    function test_OneMultisigOwnerAloneCannotRuleASale() public {
        (Multisig1271 ms,) = _multisigArbitrator();
        bytes32 id = _claimedAndDisputedBy(seller);
        (RulingLib.Ruling memory r,) = _ruling(id, "REFUND");
        uint256[] memory one = new uint256[](1);
        one[0] = 0x5AFE02;
        vm.expectRevert(abi.encodeWithSelector(RulingLib.ContractSignatureRejected.selector, address(ms)));
        escrow.resolveDispute(id, r, _multisigSig(address(ms), _rulingDigest(r), one));
    }
}
