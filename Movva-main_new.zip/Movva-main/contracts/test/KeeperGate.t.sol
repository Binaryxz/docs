// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Governed} from "./utils/Governed.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {YieldVault} from "../yield/YieldVault.sol";
import {KeeperGate, IKeeperVault} from "../yield/KeeperGate.sol";
import {MockAsset, MockAdapter} from "./YieldVault.t.sol";

/// A source that charges an exit cost, like the Lido adapter's Curve slippage.
contract LossyAdapter is MockAdapter {
    uint256 public constant EXIT_COST_BPS = 50;

    constructor(address vault_, MockAsset token_) MockAdapter(vault_, token_) {}

    function withdraw(uint256 assets, address to) external override returns (uint256 out) {
        require(msg.sender == vault, "vault");
        uint256 bal = token.balanceOf(address(this));
        uint256 gross = assets < bal ? assets : bal;
        uint256 cost = (gross * EXIT_COST_BPS) / 10_000;
        token.burn(address(this), cost);
        out = gross - cost;
        require(token.transfer(to, out), "transfer");
    }
}

/**
 * The keeper as a contract: per-replica operator keys and a turnover budget in front of the
 * vault's keeper role. The attacks here are what a leaked Flux replica key would try.
 */
contract KeeperGateTest is Governed {
    MockAsset usd;
    YieldVault vault;
    KeeperGate gate;
    LossyAdapter lido;

    address gov = makeAddr("gov");
    address guardian = makeAddr("guardian");
    address op1 = makeAddr("replica-1");
    address op2 = makeAddr("replica-2");
    address alice = makeAddr("alice");
    address stranger = makeAddr("stranger");

    uint16 constant BUDGET_BPS = 1_000; // 10% of assets per day

    function setUp() public {
        usd = new MockAsset();
        // The vault is deployed with a placeholder keeper and pointed at the gate during setup,
        // the way a deployment script would wire it.
        vault = new YieldVault(IERC20(address(usd)), "Y", "y", gov, guardian, gov, 1e30, 500, DELAY);
        gate = new KeeperGate(IKeeperVault(address(vault)), gov, DELAY, BUDGET_BPS);
        lido = new LossyAdapter(address(vault), usd);
        vm.startPrank(gov);
        vault.addAdapter(lido, 10_000);
        vault.setKeeper(address(gate));
        vault.completeSetup();
        gate.setOperator(op1, true);
        gate.setOperator(op2, true);
        gate.completeSetup();
        vm.stopPrank();

        usd.mint(alice, 1_000_000e18);
        vm.startPrank(alice);
        usd.approve(address(vault), type(uint256).max);
        vault.deposit(1_000_000e18, alice);
        vm.stopPrank();
    }

    function test_OperatorsDriveTheVaultOnlyThroughTheGate() public {
        vm.prank(op1);
        gate.allocate(lido, 50_000e18);
        vm.prank(op2);
        gate.deallocate(lido, 10_000e18);
        assertEq(lido.totalValue(), 40_000e18);

        // A replica key is not the vault's keeper, so it cannot bypass the budget.
        vm.prank(op1);
        vm.expectRevert(YieldVault.NotKeeper.selector);
        vault.allocate(lido, 1);

        vm.prank(stranger);
        vm.expectRevert(KeeperGate.NotOperator.selector);
        gate.allocate(lido, 1);
    }

    /**
     * The attack the budget exists for: a leaked key churns a source with an exit cost, round
     * trip after round trip, to burn holders' money. The vault alone would let it continue all
     * day. The gate stops it at the budget, and the loss is bounded by budget x exit cost.
     */
    function test_ALeakedKeyCannotChurnPastTheBudget() public {
        uint256 before = vault.totalAssets();
        uint256 chunk = 25_000e18;
        uint256 moved;
        vm.startPrank(op1);
        while (true) {
            if (gate.remainingTurnover() < 2 * chunk) break;
            gate.allocate(lido, chunk);
            gate.deallocate(lido, chunk);
            moved += 2 * chunk;
        }
        uint256 remaining = gate.remainingTurnover();
        vm.expectRevert(
            abi.encodeWithSelector(KeeperGate.TurnoverBudgetExceeded.selector, remaining + 1, remaining)
        );
        gate.allocate(lido, remaining + 1);
        vm.stopPrank();

        uint256 lost = before - vault.totalAssets();
        uint256 budget = (before * BUDGET_BPS) / 10_000;
        assertLe(moved, budget, "never moved more than one budget in the window");
        // Each deallocation paid the exit cost on half the turnover.
        assertLe(lost, (budget / 2) * lido.EXIT_COST_BPS() / 10_000 + 1, "loss bounded by budget x exit cost");
        assertGt(lost, 0, "the attack did cost something, which is why it is bounded");
    }

    /// Two replicas share one budget: running more instances does not multiply it.
    function test_ReplicasShareOneBudget() public {
        uint256 half = gate.remainingTurnover() / 2;
        vm.prank(op1);
        gate.allocate(lido, half);
        vm.prank(op2);
        gate.allocate(lido, half);
        vm.prank(op2);
        vm.expectRevert();
        gate.deallocate(lido, 1e18);
    }

    function test_TheBudgetRefillsAfterTheWindow() public {
        uint256 all = gate.remainingTurnover();
        vm.prank(op1);
        gate.allocate(lido, all);
        assertEq(gate.remainingTurnover(), 0);
        vm.warp(block.timestamp + gate.WINDOW());
        assertGt(gate.remainingTurnover(), 0);
        vm.prank(op1);
        gate.deallocate(lido, all);
    }

    /// The operator never receives anything, whatever it calls.
    function test_NothingEverReachesAnOperator() public {
        vm.startPrank(op1);
        gate.allocate(lido, 30_000e18);
        lido.earn(1_000e18);
        gate.harvest(lido);
        gate.deallocate(lido, 31_000e18);
        vm.stopPrank();
        assertEq(usd.balanceOf(op1), 0);
        assertEq(usd.balanceOf(address(gate)), 0);
    }

    /*//////////////////////////////////////////////////////////////
                               GOVERNANCE
    //////////////////////////////////////////////////////////////*/

    /// Adding a replica key is handing out the keeper role, so it waits like setKeeper does.
    function test_AddingAnOperatorWaitsRevokingDoesNot() public {
        vm.prank(gov);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, KeeperGate.setOperator.selector)
        );
        gate.setOperator(stranger, true);

        _afterDelay(address(gate), abi.encodeCall(KeeperGate.setOperator, (stranger, true)));
        assertTrue(gate.isOperator(stranger));

        vm.prank(gov);
        gate.setOperator(stranger, false);
        assertFalse(gate.isOperator(stranger));
    }

    /// A leaked replica key is contained by the guardian at once, without the governor.
    function test_TheGuardianRevokesALeakedKeyButCannotAddOne() public {
        vm.prank(guardian);
        gate.setOperator(op1, false);
        vm.prank(op1);
        vm.expectRevert(KeeperGate.NotOperator.selector);
        gate.allocate(lido, 1);
        vm.prank(op2);
        gate.allocate(lido, 1e18); // the other replica is untouched

        vm.prank(guardian);
        vm.expectRevert(DelayedGovernance.NotGovernor.selector);
        gate.setOperator(stranger, true);
    }

    function test_RaisingTheBudgetWaitsLoweringDoesNot() public {
        vm.prank(gov);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, KeeperGate.setMaxTurnover.selector)
        );
        gate.setMaxTurnover(BUDGET_BPS + 1);
        vm.prank(gov);
        gate.setMaxTurnover(100);
        assertEq(gate.maxTurnoverBps(), 100);
        vm.prank(gov);
        vm.expectRevert(KeeperGate.BadBps.selector);
        gate.setMaxTurnover(0);
    }

    /// A gate still in setup would keep instant operator changes behind a delayed vault keeper.
    function test_NoCallIsForwardedBeforeTheGateCompletesSetup() public {
        KeeperGate fresh = new KeeperGate(IKeeperVault(address(vault)), gov, DELAY, BUDGET_BPS);
        vm.prank(gov);
        fresh.setOperator(op1, true);
        vm.prank(op1);
        vm.expectRevert(DelayedGovernance.SetupIncomplete.selector);
        fresh.allocate(lido, 1);
    }
}
