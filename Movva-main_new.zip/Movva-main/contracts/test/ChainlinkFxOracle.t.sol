// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Governed} from "./utils/Governed.sol";
import {FxTestFeed} from "./ChainlinkSignedFxOracle.t.sol";
import {ChainlinkFxOracle} from "../ramp/ChainlinkFxOracle.sol";
import {IPriceOracle} from "../ramp/IPriceOracle.sol";
import {ChainlinkSignedFxOracle} from "../ramp/ChainlinkSignedFxOracle.sol";
import {ScaledFxBandOracle} from "../movva/ScaledFxBandOracle.sol";

/// A Chainlink aggregator proxy as ChainlinkFxOracle reads it: description, decimals, the latest round.
contract MockBrlUsdAggregator {
    string public description = "BRL / USD";
    uint8 public decimals;
    int256 public answer;
    uint256 public updatedAt;
    uint80 public roundId;
    string public refusal;

    constructor(uint8 d) {
        decimals = d;
    }

    function set(int256 a, uint256 t) external {
        (answer, updatedAt) = (a, t);
        roundId++;
    }

    function setDecimals(uint8 d) external {
        decimals = d;
    }

    function setDescription(string calldata s) external {
        description = s;
    }

    /// What a retired proxy answers a contract: Error("No access").
    function refuse(string calldata why) external {
        refusal = why;
    }

    function latestRoundData() external view returns (uint80, int256, uint256, uint256, uint80) {
        if (bytes(refusal).length > 0) revert(refusal);
        return (roundId, answer, updatedAt, updatedAt, roundId);
    }
}

/**
 * ChainlinkFxOracle against a mock aggregator: units and rounding, every refusal, the rate's market hours
 * and the band's two limits. The rounds of 16-18 October 2026 are the real feed's (ChainlinkFxFork.t.sol
 * reads them back).
 */
contract ChainlinkFxOracleTest is Governed {
    /// Wednesday 16 September 2026, 15:00 UTC: inside the core session.
    uint256 constant WED_1500 = 1_789_570_800;
    /// Friday 18 September, 20:00 UTC; Saturday 15:00 UTC; Monday 21 September, 13:30 UTC.
    uint256 constant FRI_2000 = 1_789_761_600;
    uint256 constant SAT_1500 = 1_789_830_000;
    uint256 constant MON_1330 = 1_789_997_400;
    /// 25 December 2026, a Friday, 15:00 UTC.
    uint256 constant CHRISTMAS_1500 = 1_798_210_800;

    /// The real feed's rounds: Friday 16, Saturday 17 and Sunday 18 October 2026, and Monday's open.
    uint256 constant FRI_16_OCT_1913 = 1_792_177_991;
    uint256 constant SAT_17_OCT_1913 = 1_792_264_427;
    uint256 constant SUN_18_OCT_1914 = 1_792_350_851;
    uint256 constant MON_19_OCT_1330 = 1_792_416_600;

    /// 0.1975293 US dollars per real, the answer of 18 October: 1e14 / 19_752_930 = 5_062_540.09.
    int256 constant ANSWER = 19_752_930;
    uint256 constant E6 = 5_062_540;

    uint64 constant MAX_AGE = 26 hours;
    uint64 constant CLOSED_MAX_AGE = 4 days;

    MockBrlUsdAggregator feed;
    ChainlinkFxOracle oracle;

    function setUp() public {
        vm.warp(WED_1500);
        feed = new MockBrlUsdAggregator(8);
        feed.set(ANSWER, WED_1500 - 20 hours); // a quiet market: the last round is the heartbeat's
        oracle = new ChainlinkFxOracle(address(feed), MAX_AGE, CLOSED_MAX_AGE, 1e6, 100e6);
    }

    function _bothRefuse(bytes memory err) internal {
        vm.expectRevert(err);
        oracle.brlCentsPerUnit();
        vm.expectRevert(err);
        oracle.brlCentsPerUnitForBand();
    }

    /*//////////////////////////////////////////////////////////////
                           UNITS AND ROUNDING
    //////////////////////////////////////////////////////////////*/

    function test_ReadsReaisPerDollarInMillionthsFromDollarsPerReal() public view {
        (uint256 rate, uint64 at) = oracle.brlCentsPerUnit();
        assertEq(rate, E6, "1 / 0.1975293 = R$ 5,062540 per dollar, floored");
        assertEq(at, WED_1500 - 20 hours, "the rate passes the round's own time through");
        (uint256 band, uint64 bandAt) = oracle.brlCentsPerUnitForBand();
        assertEq(band, rate, "the band reads the same answer");
        assertEq(bandAt, WED_1500, "stamped current: the escrows allow a band an hour, the feed posts daily");
        assertEq(oracle.DECIMALS(), 8);
        assertTrue(oracle.inCoreSession());
    }

    /// Floor, exactly: price x answer <= 10^14 < (price + 1) x answer, for every answer the range admits.
    function testFuzz_TheReciprocalIsTheFloor(uint256 raw) public {
        // 1e14 / 100e6 = 1e6 and 1e14 / 1e6 = 1e8: the answers between R$ 100 and R$ 1 per dollar.
        uint256 answer = bound(raw, 1e6, 1e8);
        feed.set(int256(answer), block.timestamp);
        (uint256 price,) = oracle.brlCentsPerUnit();
        assertLe(price * answer, 1e14);
        assertGt((price + 1) * answer, 1e14);
    }

    function test_AnyDecimalsUpTo18ScaleTheSame() public {
        for (uint8 d = 1; d <= 18; d++) {
            MockBrlUsdAggregator f = new MockBrlUsdAggregator(d);
            // 0.2 dollars per real at d decimals, for d >= 1.
            f.set(int256(2 * 10 ** uint256(d - 1)), block.timestamp);
            ChainlinkFxOracle o = new ChainlinkFxOracle(address(f), MAX_AGE, CLOSED_MAX_AGE, 1e6, 100e6);
            (uint256 price,) = o.brlCentsPerUnit();
            assertEq(price, 5_000_000, "R$ 5,00 per dollar at every scale");
        }
        // The real answer at 18 decimals: the same floor as at 8.
        MockBrlUsdAggregator f18 = new MockBrlUsdAggregator(18);
        f18.set(ANSWER * 1e10, block.timestamp);
        (uint256 p18,) = new ChainlinkFxOracle(address(f18), MAX_AGE, CLOSED_MAX_AGE, 1e6, 100e6).brlCentsPerUnit();
        assertEq(p18, E6);
    }

    /*//////////////////////////////////////////////////////////////
                              MARKET HOURS
    //////////////////////////////////////////////////////////////*/

    /// The heartbeat keeps the answer young all weekend; the rate refuses anyway.
    function test_TheRateRefusesOutsideTheCoreSessionHoweverFreshTheAnswer() public {
        uint256[6] memory closed = [
            SAT_1500, // a Saturday
            SAT_1500 + 1 days, // a Sunday
            CHRISTMAS_1500, // 25 December, a Friday
            MON_1330 - 1, // 13:29:59 on Monday: the keeper's half hour
            FRI_2000 + 1 hours, // 21:00:00 on Friday: New York's summer close
            WED_1500 + 7 hours // 22:00 on a Wednesday
        ];
        for (uint256 i; i < closed.length; i++) {
            vm.warp(closed[i]);
            feed.set(ANSWER, closed[i]); // a round this very second
            vm.expectRevert(abi.encodeWithSelector(ChainlinkFxOracle.MarketClosed.selector, closed[i]));
            oracle.brlCentsPerUnit();
            (uint256 band, uint64 at) = oracle.brlCentsPerUnitForBand();
            assertEq(band, E6, "the band keeps trading");
            assertEq(at, closed[i]);
            assertFalse(oracle.inCoreSession());
        }
        vm.warp(MON_1330);
        feed.set(ANSWER, MON_1330 - 18 hours);
        (uint256 rate,) = oracle.brlCentsPerUnit();
        assertEq(rate, E6, "13:30:00 on Monday: the rate prices again");
    }

    /// Inside the session the rate takes an answer up to MAX_AGE old - a day's heartbeat and some.
    function test_InsideTheSessionTheRateTakesAnAnswerUpToMaxAge() public {
        feed.set(ANSWER, block.timestamp - MAX_AGE);
        (, uint64 at) = oracle.brlCentsPerUnit();
        assertEq(at, block.timestamp - MAX_AGE);
        uint256 late = block.timestamp - MAX_AGE - 1;
        feed.set(ANSWER, late);
        _bothRefuse(abi.encodeWithSelector(ChainlinkFxOracle.StaleAnswer.selector, late));
    }

    /// A heartbeat missed over a weekend: a band takes the last answer up to CLOSED_MAX_AGE off-hours, and
    /// refuses it once the core session opens with nothing newer than MAX_AGE.
    function test_OutsideTheSessionABandTakesTheLastAnswerUpToClosedMaxAge() public {
        vm.warp(FRI_2000);
        feed.set(ANSWER, FRI_2000);
        vm.warp(MON_1330 - 1); // 65.5 hours on, every weekend heartbeat missed
        (uint256 band, uint64 at) = oracle.brlCentsPerUnitForBand();
        assertEq(band, E6);
        assertEq(at, MON_1330 - 1);
        vm.warp(MON_1330);
        _bothRefuse(abi.encodeWithSelector(ChainlinkFxOracle.StaleAnswer.selector, FRI_2000));

        // And off-hours, past CLOSED_MAX_AGE, the band stops too.
        vm.warp(SAT_1500);
        feed.set(ANSWER, SAT_1500 - CLOSED_MAX_AGE - 1);
        vm.expectRevert(abi.encodeWithSelector(ChainlinkFxOracle.StaleAnswer.selector, SAT_1500 - CLOSED_MAX_AGE - 1));
        oracle.brlCentsPerUnitForBand();
        feed.set(ANSWER, SAT_1500 - CLOSED_MAX_AGE);
        (, at) = oracle.brlCentsPerUnitForBand();
        assertEq(at, SAT_1500);
    }

    /// The real rounds of 16-18 October 2026. Friday's is the rate; Saturday's heartbeat carries the late
    /// Friday close, which no mint may use; Monday's open prices at Sunday's heartbeat, 18 hours old.
    function test_TheWeekendOf16OctoberAsTheFeedPostedIt() public {
        vm.warp(FRI_16_OCT_1913);
        feed.set(19_708_316, FRI_16_OCT_1913);
        (uint256 rate,) = oracle.brlCentsPerUnit();
        assertEq(rate, 5_074_000, "Friday 19:13 UTC, inside the session");

        vm.warp(SAT_17_OCT_1913);
        feed.set(19_752_930, SAT_17_OCT_1913);
        vm.expectRevert(abi.encodeWithSelector(ChainlinkFxOracle.MarketClosed.selector, SAT_17_OCT_1913));
        oracle.brlCentsPerUnit();
        (uint256 band,) = oracle.brlCentsPerUnitForBand();
        assertEq(band, E6, "the bands move to the close (-0.23% reais per dollar); minting does not");

        vm.warp(SUN_18_OCT_1914);
        feed.set(19_752_930, SUN_18_OCT_1914);
        vm.expectRevert(abi.encodeWithSelector(ChainlinkFxOracle.MarketClosed.selector, SUN_18_OCT_1914));
        oracle.brlCentsPerUnit();

        vm.warp(MON_19_OCT_1330);
        (uint256 monday, uint64 at) = oracle.brlCentsPerUnit();
        assertEq(monday, E6);
        assertEq(at, SUN_18_OCT_1914, "the heartbeat's round, 18 hours old: within MAX_AGE");
    }

    /*//////////////////////////////////////////////////////////////
                                REFUSALS
    //////////////////////////////////////////////////////////////*/

    function test_EveryReadingRefusesABadAnswer() public {
        feed.set(0, block.timestamp);
        _bothRefuse(abi.encodeWithSelector(ChainlinkFxOracle.BadAnswer.selector, int256(0)));
        feed.set(-1, block.timestamp);
        _bothRefuse(abi.encodeWithSelector(ChainlinkFxOracle.BadAnswer.selector, int256(-1)));

        feed.set(ANSWER, 0);
        _bothRefuse(abi.encodeWithSelector(ChainlinkFxOracle.IncompleteRound.selector));

        uint256 ahead = block.timestamp + 5 minutes;
        feed.set(ANSWER, ahead);
        oracle.brlCentsPerUnit(); // within the skew
        feed.set(ANSWER, ahead + 1);
        _bothRefuse(abi.encodeWithSelector(ChainlinkFxOracle.AnswerFromFuture.selector, ahead + 1));

        // An aggregator upgrade behind the proxy that changed the scale: refused, never mis-scaled.
        feed.set(ANSWER, block.timestamp);
        feed.setDecimals(18);
        _bothRefuse(abi.encodeWithSelector(ChainlinkFxOracle.DecimalsChanged.selector, uint8(18)));
        feed.setDecimals(8);

        // An inverted feed (reais per dollar, 5.06 at 8 decimals) and one in the wrong unit.
        feed.set(506_254_000, block.timestamp);
        _bothRefuse(abi.encodeWithSelector(ChainlinkFxOracle.RateOutOfRange.selector, uint256(197_529)));
        feed.set(999_999, block.timestamp); // under a cent of a dollar per real: R$ 100,000100
        _bothRefuse(abi.encodeWithSelector(ChainlinkFxOracle.RateOutOfRange.selector, uint256(100_000_100)));
        feed.set(1e14 + 1, block.timestamp); // rounds to zero
        _bothRefuse(abi.encodeWithSelector(ChainlinkFxOracle.RateOutOfRange.selector, uint256(0)));

        // The range's edges are inside.
        feed.set(1e6, block.timestamp);
        (uint256 p,) = oracle.brlCentsPerUnit();
        assertEq(p, 100e6);
        feed.set(1e8, block.timestamp);
        (p,) = oracle.brlCentsPerUnit();
        assertEq(p, 1e6);
    }

    /// A retired proxy answers a contract "No access": both readings fail closed with its reason.
    function test_ARetiredFeedFailsClosed() public {
        feed.refuse("No access");
        vm.expectRevert(bytes("No access"));
        oracle.brlCentsPerUnit();
        vm.expectRevert(bytes("No access"));
        oracle.brlCentsPerUnitForBand();
    }

    /// A tighter range is the deployer's to choose, inside the reserve's own.
    function test_ATighterRangeRefusesOutsideIt() public {
        ChainlinkFxOracle tight = new ChainlinkFxOracle(address(feed), MAX_AGE, CLOSED_MAX_AGE, 2e6, 5e6);
        vm.expectRevert(abi.encodeWithSelector(ChainlinkFxOracle.RateOutOfRange.selector, E6));
        tight.brlCentsPerUnit();
        assertEq(tight.MIN_BRL_PER_USD_E6(), 2e6);
        assertEq(tight.MAX_BRL_PER_USD_E6(), 5e6);
    }

    function test_TheConstructorRefusesMistakes() public {
        vm.expectRevert(ChainlinkFxOracle.ZeroAddress.selector);
        new ChainlinkFxOracle(address(0), MAX_AGE, CLOSED_MAX_AGE, 1e6, 100e6);

        bytes memory bad = abi.encodeWithSelector(ChainlinkFxOracle.BadLimits.selector);
        uint64[2] memory ages = [uint64(25 hours - 1), uint64(2 days + 1)];
        for (uint256 i; i < 2; i++) {
            vm.expectRevert(bad);
            new ChainlinkFxOracle(address(feed), ages[i], CLOSED_MAX_AGE, 1e6, 100e6);
        }
        new ChainlinkFxOracle(address(feed), 25 hours, 25 hours, 1e6, 100e6); // the edges are allowed
        new ChainlinkFxOracle(address(feed), 2 days, 4 days, 1e6, 100e6);
        vm.expectRevert(bad);
        new ChainlinkFxOracle(address(feed), MAX_AGE, MAX_AGE - 1, 1e6, 100e6); // closed below open
        vm.expectRevert(bad);
        new ChainlinkFxOracle(address(feed), MAX_AGE, 4 days + 1, 1e6, 100e6);
        vm.expectRevert(bad);
        new ChainlinkFxOracle(address(feed), MAX_AGE, CLOSED_MAX_AGE, 1e6 - 1, 100e6);
        vm.expectRevert(bad);
        new ChainlinkFxOracle(address(feed), MAX_AGE, CLOSED_MAX_AGE, 1e6, 100e6 + 1);
        vm.expectRevert(bad);
        new ChainlinkFxOracle(address(feed), MAX_AGE, CLOSED_MAX_AGE, 5e6, 5e6);

        // Pointed at the wrong feed.
        FxTestFeed noDescription = new FxTestFeed(1e8, 8);
        vm.expectRevert();
        new ChainlinkFxOracle(address(noDescription), MAX_AGE, CLOSED_MAX_AGE, 1e6, 100e6);
        MockBrlUsdAggregator usdt = new MockBrlUsdAggregator(8);
        usdt.setDescription("USDT / USD");
        vm.expectRevert(abi.encodeWithSelector(ChainlinkFxOracle.NotBrlUsd.selector, "USDT / USD"));
        new ChainlinkFxOracle(address(usdt), MAX_AGE, CLOSED_MAX_AGE, 1e6, 100e6);
        MockBrlUsdAggregator usdBrl = new MockBrlUsdAggregator(8);
        usdBrl.setDescription("USD / BRL");
        vm.expectRevert(abi.encodeWithSelector(ChainlinkFxOracle.NotBrlUsd.selector, "USD / BRL"));
        new ChainlinkFxOracle(address(usdBrl), MAX_AGE, CLOSED_MAX_AGE, 1e6, 100e6);

        // Decimals with no precision to invert, or past what the scale is built for.
        MockBrlUsdAggregator d0 = new MockBrlUsdAggregator(0);
        vm.expectRevert(abi.encodeWithSelector(ChainlinkFxOracle.BadDecimals.selector, uint8(0)));
        new ChainlinkFxOracle(address(d0), MAX_AGE, CLOSED_MAX_AGE, 1e6, 100e6);
        MockBrlUsdAggregator d19 = new MockBrlUsdAggregator(19);
        vm.expectRevert(abi.encodeWithSelector(ChainlinkFxOracle.BadDecimals.selector, uint8(19)));
        new ChainlinkFxOracle(address(d19), MAX_AGE, CLOSED_MAX_AGE, 1e6, 100e6);
    }

    /// Keyless: nothing answers a governor's call, and every setting is a getter on an immutable.
    function test_ThereIsNoGovernorAndNothingToSet() public {
        (bool ok,) = address(oracle).call(abi.encodeWithSignature("governor()"));
        assertFalse(ok, "no governor");
        (ok,) = address(oracle).call(abi.encodeWithSignature("owner()"));
        assertFalse(ok, "no owner");
        (ok,) = address(oracle).call(abi.encodeWithSignature("setLimits(uint64,uint64,uint16)", 1, 1, 1));
        assertFalse(ok, "no setter");
        assertEq(address(oracle.FEED()), address(feed));
        assertEq(oracle.MAX_AGE(), MAX_AGE);
        assertEq(oracle.CLOSED_MAX_AGE(), CLOSED_MAX_AGE);
    }

    /*//////////////////////////////////////////////////////////////
                           THE RAMPS' BAND
    //////////////////////////////////////////////////////////////*/

    /// The ramps' USDT band over this leg: Chainlink USDT/USD crossed with the centavo adapter, inside the
    /// session on an answer 20 hours old - the escrows' one-hour check passes because the band is stamped
    /// current - and all weekend on the last answer.
    function test_TheRampsUsdtBandTradesInSessionAndAllWeekend() public {
        ScaledFxBandOracle cents = new ScaledFxBandOracle(oracle);
        FxTestFeed usdtUsd = new FxTestFeed(99_972_163, 8);
        ChainlinkSignedFxOracle usdt =
            new ChainlinkSignedFxOracle(address(usdtUsd), address(cents), 90_000, 1 hours, address(this), DELAY);
        usdt.completeSetup();

        (uint256 price, uint64 at) = usdt.brlCentsPerUnit();
        assertEq(price, 506, "0.99972163 x 506 centavos = R$ 5,06 per USDT");
        assertEq(at, WED_1500, "fresh for the escrows, though the round is 20 hours old");

        vm.warp(SAT_1500);
        feed.set(ANSWER, SAT_1500 - 2 hours); // Saturday's heartbeat
        usdtUsd.set(99_972_163, SAT_1500);
        (price, at) = usdt.brlCentsPerUnit();
        assertEq(price, 506);
        assertEq(at, SAT_1500);
    }

    /// A reader that knows only IPriceOracle - MovvaReserve's rate path - gets the rate, and the refusal
    /// off-hours.
    function test_AnIPriceOracleReaderGetsTheRate() public {
        IPriceOracle asRate = IPriceOracle(address(oracle));
        (uint256 rate,) = asRate.brlCentsPerUnit();
        assertEq(rate, E6);
        vm.warp(SAT_1500);
        vm.expectRevert(abi.encodeWithSelector(ChainlinkFxOracle.MarketClosed.selector, SAT_1500));
        asRate.brlCentsPerUnit();
    }
}
