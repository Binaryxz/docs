// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {ShieldedTransferRouter} from "../transfer/ShieldedTransferRouter.sol";
import {IShieldedPool} from "../yield/ShieldedYieldRouter.sol";
// The yield router's doubles already follow upstream's rules where they matter here: the
// proof context check, per-label depositors, successor notes with the same label, and the
// Entrypoint's vetting fee. Reusing them keeps both routers tested against one model.
import {Token, PoolMock, EntrypointMock, NATIVE} from "./ShieldedYieldRouter.t.sol";

contract ShieldedTransferRouterTest is Test {
    uint256 constant FEE_BPS = 50;

    Token usds;
    EntrypointMock ep;
    PoolMock usdsPool;
    PoolMock ethPool;
    ShieldedTransferRouter router;

    address alice = makeAddr("alice");
    address bobRescue = makeAddr("bob-fresh-rescue-address");
    address relayer = makeAddr("relayer");
    address attacker = makeAddr("attacker");
    uint256 pre = 1;

    function setUp() public {
        usds = new Token("USDS");
        ep = new EntrypointMock();
        usdsPool = new PoolMock(address(usds), address(ep));
        ethPool = new PoolMock(NATIVE, address(ep));
        ep.register(address(usds), address(usdsPool), FEE_BPS);
        ep.register(NATIVE, address(ethPool), FEE_BPS);
        router = new ShieldedTransferRouter(address(ep));
    }

    /*//////////////////////////////////////////////////////////////
                                HELPERS
    //////////////////////////////////////////////////////////////*/

    function _usdsNote(uint256 amount) internal returns (uint256 id) {
        usds.mint(alice, amount);
        vm.startPrank(alice);
        usds.approve(address(ep), amount);
        id = ep.deposit(IERC20(address(usds)), amount, ++pre);
        vm.stopPrank();
    }

    function _ethNote(uint256 amount) internal returns (uint256 id) {
        vm.deal(alice, amount);
        vm.prank(alice);
        id = ep.deposit{value: amount}(++pre);
    }

    /// Bob's precommitment, as it would arrive in his receive ticket.
    function _data(uint256 bobPrecommitment, uint256 fee) internal view returns (bytes memory) {
        return abi.encode(
            ShieldedTransferRouter.Transfer({
                precommitment: bobPrecommitment,
                rescueRecipient: bobRescue,
                relayer: relayer,
                relayFee: fee,
                deadline: uint64(block.timestamp + 1 hours)
            })
        );
    }

    function _proof(PoolMock pool, uint256 note, uint256 value, bytes memory data)
        internal
        view
        returns (IShieldedPool.Withdrawal memory w, IShieldedPool.WithdrawProof memory p)
    {
        w = IShieldedPool.Withdrawal({processooor: address(router), data: data});
        p.pubSignals[1] = note;
        p.pubSignals[2] = value;
        p.pubSignals[7] = router.context(address(pool), data);
    }

    function _send(PoolMock pool, uint256 note, uint256 value, bytes memory data) internal returns (uint256) {
        (IShieldedPool.Withdrawal memory w, IShieldedPool.WithdrawProof memory p) = _proof(pool, note, value, data);
        vm.prank(relayer);
        return router.transfer(IShieldedPool(address(pool)), w, p);
    }

    function _value(PoolMock pool, uint256 note) internal view returns (uint256 v) {
        (, v,) = pool.notes(note);
    }

    function _label(PoolMock pool, uint256 note) internal view returns (uint256 l) {
        (l,,) = pool.notes(note);
    }

    /*//////////////////////////////////////////////////////////////
                              THE TRANSFER
    //////////////////////////////////////////////////////////////*/

    function test_ValueMovesFromOneNoteToAnother() public {
        uint256 note = _usdsNote(1_000e18);
        uint256 bobPre = 0xB0B;

        uint256 bobNote = _send(usdsPool, note, 400e18, _data(bobPre, 0));

        assertEq(_value(usdsPool, bobNote), 400e18 - (400e18 * FEE_BPS) / 10_000, "less the vetting fee");
        // Alice's own deposit paid the vetting fee too, so her note is worth 995e18, not 1_000e18.
        assertEq(_value(usdsPool, usdsPool.lastNote() - 1), _value(usdsPool, note) - 400e18, "Alice keeps the remainder");
    }

    /**
     * The recipient's note is registered under the precommitment from their ticket, and the
     * depositor of record is the router - never Alice, never Bob.
     */
    function test_NeitherUserIsTheDepositorOfRecord() public {
        uint256 note = _usdsNote(100e18);
        uint256 bobNote = _send(usdsPool, note, _value(usdsPool, note), _data(0xB0B, 0));
        uint256 label = _label(usdsPool, bobNote);

        assertEq(usdsPool.depositors(label), address(router));
        assertTrue(usdsPool.depositors(label) != alice);
    }

    function test_NativeEthTransfersToo() public {
        uint256 note = _ethNote(2 ether);
        uint256 bobNote = _send(ethPool, note, 1 ether, _data(0xB0B, 0));
        assertEq(_value(ethPool, bobNote), 1 ether - (1 ether * FEE_BPS) / 10_000);
        assertEq(address(router).balance, 0, "router keeps nothing");
    }

    function test_TheRelayerIsPaidFromTheTransferredValue() public {
        uint256 note = _usdsNote(100e18);
        uint256 v = _value(usdsPool, note);
        uint256 bobNote = _send(usdsPool, note, v, _data(0xB0B, 2e18));

        assertEq(usds.balanceOf(relayer), 2e18);
        assertEq(_value(usdsPool, bobNote), (v - 2e18) - ((v - 2e18) * FEE_BPS) / 10_000);
        assertEq(usds.balanceOf(address(router)), 0, "router keeps nothing");
    }

    function test_TheRescueRecipientIsRecordedUnderThePoolsOwnLabel() public {
        uint256 note = _usdsNote(100e18);
        uint256 bobNote = _send(usdsPool, note, _value(usdsPool, note), _data(0xB0B, 0));
        assertEq(router.rescueRecipient(address(usdsPool), _label(usdsPool, bobNote)), bobRescue);
    }

    /*//////////////////////////////////////////////////////////////
                        THE PROOF BINDS THE TRANSFER
    //////////////////////////////////////////////////////////////*/

    /**
     * A relayer holding Alice's proof must not be able to redirect the payment - by swapping
     * Bob's precommitment for its own, raising its fee, or naming itself as rescue recipient.
     * Each is a different context, and the pool refuses it.
     */
    function test_ARelayerCannotRedirectThePayment() public {
        uint256 note = _usdsNote(100e18);
        bytes memory signed = _data(0xB0B, 1e18);
        (IShieldedPool.Withdrawal memory w, IShieldedPool.WithdrawProof memory p) =
            _proof(usdsPool, note, 100e18, signed);

        ShieldedTransferRouter.Transfer memory t = abi.decode(signed, (ShieldedTransferRouter.Transfer));
        t.precommitment = 0xBAD;
        w.data = abi.encode(t);

        vm.prank(attacker);
        vm.expectRevert(bytes("ContextMismatch"));
        router.transfer(IShieldedPool(address(usdsPool)), w, p);
    }

    function test_ARelayerCannotRaiseItsOwnFee() public {
        uint256 note = _usdsNote(100e18);
        bytes memory signed = _data(0xB0B, 1e18);
        (IShieldedPool.Withdrawal memory w, IShieldedPool.WithdrawProof memory p) =
            _proof(usdsPool, note, 100e18, signed);

        ShieldedTransferRouter.Transfer memory t = abi.decode(signed, (ShieldedTransferRouter.Transfer));
        t.relayFee = 50e18;
        w.data = abi.encode(t);

        vm.expectRevert(bytes("ContextMismatch"));
        router.transfer(IShieldedPool(address(usdsPool)), w, p);
    }

    function test_TheRouterMustBeTheProcessooor() public {
        uint256 note = _usdsNote(100e18);
        (IShieldedPool.Withdrawal memory w, IShieldedPool.WithdrawProof memory p) =
            _proof(usdsPool, note, 100e18, _data(0xB0B, 0));
        w.processooor = attacker;
        vm.expectRevert(ShieldedTransferRouter.WrongProcessooor.selector);
        router.transfer(IShieldedPool(address(usdsPool)), w, p);
    }

    function test_AnExpiredTransferIsRefusedAndNothingMoves() public {
        uint256 note = _usdsNote(100e18);
        (IShieldedPool.Withdrawal memory w, IShieldedPool.WithdrawProof memory p) =
            _proof(usdsPool, note, 100e18, _data(0xB0B, 0));
        vm.warp(block.timestamp + 2 hours);

        vm.expectRevert(ShieldedTransferRouter.Expired.selector);
        router.transfer(IShieldedPool(address(usdsPool)), w, p);

        (,, bool spent) = usdsPool.notes(note);
        assertFalse(spent, "Alice's note was not spent");
    }

    function test_APoolTheEntrypointDoesNotKnowIsRefused() public {
        PoolMock fake = new PoolMock(address(usds), address(ep));
        (IShieldedPool.Withdrawal memory w, IShieldedPool.WithdrawProof memory p) =
            _proof(fake, 1, 1, _data(0xB0B, 0));
        vm.expectRevert(ShieldedTransferRouter.UnknownPool.selector);
        router.transfer(IShieldedPool(address(fake)), w, p);
    }

    function test_AFeeLargerThanTheTransferIsRefused() public {
        uint256 note = _usdsNote(100e18);
        (IShieldedPool.Withdrawal memory w, IShieldedPool.WithdrawProof memory p) =
            _proof(usdsPool, note, _value(usdsPool, note), _data(0xB0B, 101e18));
        vm.expectRevert(ShieldedTransferRouter.FeeExceedsAmount.selector);
        router.transfer(IShieldedPool(address(usdsPool)), w, p);
    }

    function test_AMissingRescueRecipientIsRefused() public {
        uint256 note = _usdsNote(100e18);
        bytes memory data = abi.encode(
            ShieldedTransferRouter.Transfer({
                precommitment: 0xB0B, rescueRecipient: address(0), relayer: relayer, relayFee: 0,
                deadline: uint64(block.timestamp + 1 hours)
            })
        );
        (IShieldedPool.Withdrawal memory w, IShieldedPool.WithdrawProof memory p) = _proof(usdsPool, note, 100e18, data);
        vm.expectRevert(ShieldedTransferRouter.ZeroAddress.selector);
        router.transfer(IShieldedPool(address(usdsPool)), w, p);
    }

    /*//////////////////////////////////////////////////////////////
                              ESCAPE HATCH
    //////////////////////////////////////////////////////////////*/

    function _ragequit(PoolMock pool, uint256 note) internal view returns (IShieldedPool.RagequitProof memory p) {
        p.pubSignals[0] = note;
        p.pubSignals[3] = _label(pool, note);
    }

    function test_TheRecipientCanRescueTheirNote() public {
        uint256 note = _usdsNote(100e18);
        uint256 bobNote = _send(usdsPool, note, _value(usdsPool, note), _data(0xB0B, 0));
        uint256 value = _value(usdsPool, bobNote);

        IShieldedPool.RagequitProof memory p = _ragequit(usdsPool, bobNote);
        vm.prank(bobRescue);
        router.rescue(IShieldedPool(address(usdsPool)), p);
        assertEq(usds.balanceOf(bobRescue), value);
    }

    /// The Phase 2 escrow bug, not repeated: the hatch must survive a partial exit.
    function test_TheRescueStillWorksAfterAPartialSpend() public {
        uint256 note = _usdsNote(1_000e18);
        uint256 bobNote = _send(usdsPool, note, _value(usdsPool, note), _data(0xB0B, 0));
        uint256 value = _value(usdsPool, bobNote);

        // Bob spends a quarter privately; the remainder moves to a successor with the same label.
        usdsPool.withdraw(
            IShieldedPool.Withdrawal({processooor: address(this), data: ""}),
            _selfProof(usdsPool, bobNote, value / 4)
        );
        uint256 successor = usdsPool.lastNote();
        assertEq(_label(usdsPool, successor), _label(usdsPool, bobNote), "same lineage");

        IShieldedPool.RagequitProof memory p = _ragequit(usdsPool, successor);
        vm.prank(bobRescue);
        router.rescue(IShieldedPool(address(usdsPool)), p);
        assertEq(usds.balanceOf(bobRescue), value - value / 4);
    }

    function _selfProof(PoolMock pool, uint256 note, uint256 value)
        internal
        view
        returns (IShieldedPool.WithdrawProof memory p)
    {
        IShieldedPool.Withdrawal memory w = IShieldedPool.Withdrawal({processooor: address(this), data: ""});
        p.pubSignals[1] = note;
        p.pubSignals[2] = value;
        p.pubSignals[7] = uint256(keccak256(abi.encode(w, pool.SCOPE())))
            % 21888242871839275222246405745257275088548364400416034343698204186575808495617;
    }

    function test_APublishedRescueProofCannotBeFrontRun() public {
        uint256 note = _usdsNote(100e18);
        uint256 bobNote = _send(usdsPool, note, _value(usdsPool, note), _data(0xB0B, 0));
        IShieldedPool.RagequitProof memory p = _ragequit(usdsPool, bobNote);

        vm.prank(attacker);
        vm.expectRevert(ShieldedTransferRouter.NotRecipient.selector);
        router.rescue(IShieldedPool(address(usdsPool)), p);
        assertEq(usds.balanceOf(attacker), 0);
    }

    function test_AnUnknownLabelCannotBeRescued() public {
        IShieldedPool.RagequitProof memory p;
        p.pubSignals[3] = 42;
        vm.prank(bobRescue);
        vm.expectRevert(ShieldedTransferRouter.UnknownDeposit.selector);
        router.rescue(IShieldedPool(address(usdsPool)), p);
    }

    /// Accepting ETH from pools and unwraps is necessary; it must not let stray ETH fund a transfer.
    function test_StrayEthCannotFundSomeoneElsesTransfer() public {
        vm.deal(address(router), 5 ether);
        // A 2 ETH note, so a 1 ETH withdrawal fits after Alice's own deposit paid its fee.
        uint256 note = _ethNote(2 ether);
        uint256 bobNote = _send(ethPool, note, 1 ether, _data(0xB0B, 0));

        assertEq(_value(ethPool, bobNote), 1 ether - (1 ether * FEE_BPS) / 10_000, "only the withdrawal was deposited");
        assertEq(address(router).balance, 5 ether, "the stray ETH was never touched");
    }

    receive() external payable {}
}
