// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Governed} from "./utils/Governed.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {IERC4626} from "@openzeppelin/contracts/interfaces/IERC4626.sol";
import {YieldVault} from "../yield/YieldVault.sol";
import {ERC4626Adapter} from "../yield/adapters/ERC4626Adapter.sol";

/**
 * The yield vault against Sky's real sUSDS on a mainnet fork.
 *
 * Unit tests prove the vault's accounting against a mock whose value the test moves by hand.
 * This proves the adapter against the real contract whose value moves on its own: sUSDS
 * accrues the Sky Savings Rate per second, so warping time must show up as yield in the
 * vault's share price with nobody calling anything on anyone's position.
 *
 * Skips without FORK_RPC.
 */
contract YieldForkTest is Governed {
    address constant USDS = 0xdC035D45d973E3EC169d2276DDab16f1e407384F;
    address constant SUSDS = 0xa3931d71877C0E7a3148CB7Eb4463524FEc27fbD;
    /// A large USDS holder on mainnet, found from pre-fork Transfer logs.
    address constant HOLDER = 0x99CD4Ec3f88A45940936F469E4bB72A2A701EEB9;

    bool forked;
    YieldVault vault;
    ERC4626Adapter adapter;
    address gov = makeAddr("gov");
    address keeper = makeAddr("keeper");
    address alice = makeAddr("alice");

    function setUp() public {
        string memory rpc = vm.envOr("FORK_RPC", string(""));
        if (bytes(rpc).length == 0) return;
        vm.createSelectFork(rpc);
        forked = true;

        vault = new YieldVault(IERC20(USDS), "Shielded Yield USDS", "syUSDS", gov, gov, keeper, 1e30, 100, DELAY);
        adapter = new ERC4626Adapter(address(vault), IERC4626(SUSDS), "Sky Savings Rate (sUSDS)");
        vm.startPrank(gov);
        vault.addAdapter(adapter, 10_000);
        vault.completeSetup();
        vm.stopPrank();

        vm.prank(HOLDER);
        require(IERC20(USDS).transfer(alice, 100_000e18), "fund");
        vm.prank(alice);
        IERC20(USDS).approve(address(vault), type(uint256).max);
    }

    function _depositAndAllocate() internal {
        vm.prank(alice);
        vault.deposit(100_000e18, alice);
        vm.prank(keeper);
        vault.allocate(adapter, 90_000e18);
    }

    function _accrue(uint256 secs) internal {
        vm.warp(block.timestamp + secs);
        // sUSDS folds accrued rate into its share price on drip(); call it so views are current.
        (bool ok,) = SUSDS.call(abi.encodeWithSignature("drip()"));
        ok;
    }

    function test_TheAdapterPutsFundsIntoTheRealSavingsRate() public {
        if (!forked) return;
        _depositAndAllocate();
        assertGt(IERC4626(SUSDS).balanceOf(address(adapter)), 0, "adapter holds real sUSDS shares");
        assertApproxEqAbs(vault.totalAssets(), 100_000e18, 2, "worth what went in, less rounding");
    }

    /// The point of the phase: value grows while every position sits untouched.
    function test_YieldAccruesWhileNothingIsTouched() public {
        if (!forked) return;
        _depositAndAllocate();
        uint256 sharesBefore = vault.balanceOf(alice);
        uint256 before = vault.totalAssets();

        _accrue(30 days);

        uint256 gained = vault.totalAssets() - before;
        assertEq(vault.balanceOf(alice), sharesBefore, "no position was touched");
        // 90,000 at a savings rate of a few percent for 30 days: tens to hundreds of USDS.
        assertGt(gained, 50e18, "the savings rate accrued");
        assertLt(gained, 1_000e18, "and not an implausible amount");
    }

    function test_ARoundTripReturnsPrincipalPlusYield() public {
        if (!forked) return;
        _depositAndAllocate();
        _accrue(30 days);
        uint256 shares = vault.balanceOf(alice);
        vm.prank(alice);
        uint256 out = vault.redeem(shares, alice, alice);
        assertGt(out, 100_000e18, "more came out than went in");
        assertEq(IERC20(USDS).balanceOf(alice), out);
    }

    /// previewRedeem rounds down, so the vault never counts more than sUSDS would pay.
    function test_TheAdapterValuesConservatively() public {
        if (!forked) return;
        _depositAndAllocate();
        _accrue(7 days);
        uint256 held = IERC4626(SUSDS).balanceOf(address(adapter));
        assertLe(adapter.totalValue(), IERC4626(SUSDS).convertToAssets(held));
    }
}
