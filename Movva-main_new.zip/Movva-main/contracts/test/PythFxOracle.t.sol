// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Governed} from "./utils/Governed.sol";
import {MockPyth} from "./utils/MockPyth.sol";
import {FxTestFeed} from "./ChainlinkSignedFxOracle.t.sol";
import {PythFxOracle} from "../ramp/PythFxOracle.sol";
import {IPriceOracle} from "../ramp/IPriceOracle.sol";
import {ChainlinkSignedFxOracle} from "../ramp/ChainlinkSignedFxOracle.sol";
import {ScaledFxBandOracle} from "../movva/ScaledFxBandOracle.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";
import {FxMarketHours} from "../common/FxMarketHours.sol";

/// A price source with no band reading, shaped like SignedPriceOracle.
contract PlainFx is IPriceOracle {
    uint256 public price;
    uint64 public at;

    function set(uint256 p, uint64 t) external {
        (price, at) = (p, t);
    }

    function brlCentsPerUnit() external view returns (uint256, uint64) {
        return (price, at);
    }
}

/// The core session against Pyth's published schedule, at dates checked against a calendar.
contract FxMarketHoursTest is Governed {
    function test_TheCoreSessionIsWeekdaysFrom1330To2100Utc() public pure {
        assertTrue(FxMarketHours.inCoreSession(1_789_570_800), "Wednesday 16 September 2026, 15:00 UTC");
        assertFalse(FxMarketHours.inCoreSession(1_789_565_399), "13:29:59: the keeper's half hour after the winter open");
        assertTrue(FxMarketHours.inCoreSession(1_789_565_400), "13:30:00");
        assertTrue(FxMarketHours.inCoreSession(1_789_592_399), "20:59:59");
        assertFalse(FxMarketHours.inCoreSession(1_789_592_400), "21:00:00: New York's summer close");
    }

    function test_WeekendsAndTheTwoHolidaysAreNeverCore() public pure {
        assertFalse(FxMarketHours.inCoreSession(1_789_830_000), "Saturday 19 September, 15:00 UTC");
        assertFalse(FxMarketHours.inCoreSession(1_789_830_000 + 1 days), "Sunday, 15:00 UTC");
        assertFalse(FxMarketHours.inCoreSession(1_798_210_800), "25 December 2026, a Friday");
        assertFalse(FxMarketHours.inCoreSession(1_798_815_600), "1 January 2027, a Friday");
        assertTrue(FxMarketHours.inCoreSession(1_798_124_400), "24 December is an ordinary Thursday");
    }

    function test_MonthAndDayAcrossLeapYears() public pure {
        (uint256 m, uint256 d) = FxMarketHours.monthDay(0);
        assertEq(m * 100 + d, 101, "1 January 1970");
        (m, d) = FxMarketHours.monthDay(uint256(1_835_449_200) / 1 days);
        assertEq(m * 100 + d, 229, "29 February 2028");
        (m, d) = FxMarketHours.monthDay(uint256(1_835_481_600) / 1 days);
        assertEq(m * 100 + d, 301, "1 March 2028");
        (m, d) = FxMarketHours.monthDay(uint256(951_825_600) / 1 days);
        assertEq(m * 100 + d, 229, "29 February 2000: divisible by 400, a leap year");
        (m, d) = FxMarketHours.monthDay(uint256(4_107_596_400) / 1 days - 1);
        assertEq(m * 100 + d, 228, "28 February 2100: divisible by 100, not a leap year");
        (m, d) = FxMarketHours.monthDay(uint256(4_107_596_400) / 1 days);
        assertEq(m * 100 + d, 301, "1 March 2100");
    }
}

contract PythFxOracleTest is Governed {
    bytes32 constant USD_BRL = 0xd2db4dbf1aea74e0f666b0e8f73b9580d407f5e5cf931940b06dc633d7a95906;
    /// Wednesday 16 September 2026, 15:00 UTC: inside the core session.
    uint256 constant WED_1500 = 1_789_570_800;
    /// Friday 18 September, 20:00 UTC: the last hour before New York's summer close.
    uint256 constant FRI_2000 = 1_789_761_600;
    uint256 constant SAT_1500 = 1_789_830_000;
    /// Monday 21 September, 13:30 UTC: the core session opens.
    uint256 constant MON_1330 = 1_789_997_400;

    address governor = address(0x60F);
    MockPyth pyth;
    PythFxOracle oracle;

    function setUp() public {
        vm.warp(WED_1500);
        pyth = new MockPyth(1);
        pyth.set(USD_BRL, 540_123, 50, -5, block.timestamp); // R$ 5,40123, confidence 0,0005
        oracle = new PythFxOracle(address(pyth), USD_BRL, 1 hours, 4 days, 100, governor, DELAY);
        _completeSetup(address(oracle));
    }

    function _closeOnFriday() internal {
        vm.warp(FRI_2000);
        pyth.set(USD_BRL, 540_123, 50, -5, FRI_2000);
    }

    function _bothRefuse(bytes memory err) internal {
        vm.expectRevert(err);
        oracle.brlCentsPerUnit();
        vm.expectRevert(err);
        oracle.brlCentsPerUnitForBand();
    }

    function test_ReadsReaisPerDollarInMillionths() public view {
        (uint256 rate, uint64 at) = oracle.brlCentsPerUnit();
        assertEq(rate, 5_401_230);
        assertEq(at, WED_1500);
        (uint256 band, uint64 bandAt) = oracle.brlCentsPerUnitForBand();
        assertEq(band, rate, "while the market trades, a band's price is the rate");
        assertEq(bandAt, at);
    }

    function test_ExponentsEitherSideOfTheScale() public {
        pyth.set(USD_BRL, 540_123_456, 1, -8, block.timestamp);
        (uint256 rate,) = oracle.brlCentsPerUnit();
        assertEq(rate, 5_401_234, "floored at a millionth of a real");
        pyth.set(USD_BRL, 5, 0, 0, block.timestamp);
        (rate,) = oracle.brlCentsPerUnit();
        assertEq(rate, 5_000_000);
    }

    /// The rate moves value: an old price is refused at every hour, trading or not.
    function test_TheRateRefusesAnOldPriceEvenWhileTheMarketIsClosed() public {
        _closeOnFriday();
        vm.warp(SAT_1500);
        vm.expectRevert(abi.encodeWithSelector(PythFxOracle.StaleRate.selector, FRI_2000));
        oracle.brlCentsPerUnit();
    }

    /// A band keeps Friday's close all weekend, stamped current, until the core session reopens.
    function test_ABandTakesTheLastCloseUntilTheCoreSessionReopens() public {
        _closeOnFriday();
        vm.warp(SAT_1500);
        (uint256 price, uint64 at) = oracle.brlCentsPerUnitForBand();
        assertEq(price, 5_401_230, "Friday's close");
        assertEq(at, SAT_1500, "stamped with the read, so the escrows' one-hour check passes");
        vm.warp(MON_1330 - 1);
        (, at) = oracle.brlCentsPerUnitForBand();
        assertEq(at, MON_1330 - 1, "Monday before the core session: still the close");

        vm.warp(MON_1330);
        vm.expectRevert(abi.encodeWithSelector(PythFxOracle.StaleRate.selector, FRI_2000));
        oracle.brlCentsPerUnitForBand();

        // The keeper posts the morning's price, and both readings price again.
        pyth.set(USD_BRL, 541_000, 50, -5, MON_1330);
        (price, at) = oracle.brlCentsPerUnitForBand();
        assertEq(price, 5_410_000);
        assertEq(at, MON_1330);
    }

    /// Inside the core session the market is trading, so an old price is a missing one - for bands too.
    function test_InsideTheCoreSessionABandRefusesAnOldPrice() public {
        vm.warp(WED_1500 + 61 minutes);
        vm.expectRevert(abi.encodeWithSelector(PythFxOracle.StaleRate.selector, WED_1500));
        oracle.brlCentsPerUnitForBand();
    }

    function test_ChristmasIsAClosure() public {
        uint256 thursday2000 = 1_798_124_400 + 5 hours; // 24 December 2026, 20:00 UTC
        vm.warp(thursday2000);
        pyth.set(USD_BRL, 540_123, 50, -5, thursday2000);
        vm.warp(1_798_210_800); // Friday 25 December, 15:00 UTC
        (, uint64 at) = oracle.brlCentsPerUnitForBand();
        assertEq(at, 1_798_210_800);
    }

    function test_AClosingPriceOlderThanTheClosedLimitIsRefused() public {
        _closeOnFriday();
        vm.prank(governor);
        oracle.setLimits(1 hours, 12 hours, 100); // tightening: instant
        vm.warp(FRI_2000 + 12 hours); // Saturday 08:00 UTC
        oracle.brlCentsPerUnitForBand();
        vm.warp(FRI_2000 + 12 hours + 1);
        vm.expectRevert(abi.encodeWithSelector(PythFxOracle.StaleRate.selector, FRI_2000));
        oracle.brlCentsPerUnitForBand();
    }

    function test_AZeroClosedLimitStopsBandsOffHoursToo() public {
        vm.prank(governor);
        oracle.setLimits(1 hours, 0, 100);
        _closeOnFriday();
        vm.warp(SAT_1500);
        vm.expectRevert(abi.encodeWithSelector(PythFxOracle.StaleRate.selector, FRI_2000));
        oracle.brlCentsPerUnitForBand();
    }

    function test_EveryReadingRefusesABadPrice() public {
        // A confidence interval wider than 1% of the price: nobody currently knows the rate.
        pyth.set(USD_BRL, 540_123, 6_000, -5, block.timestamp);
        _bothRefuse(abi.encodeWithSelector(PythFxOracle.ConfidenceTooWide.selector, uint64(6_000), int64(540_123)));
        pyth.set(USD_BRL, 0, 0, -5, block.timestamp);
        _bothRefuse(abi.encodeWithSelector(PythFxOracle.BadPrice.selector, int64(0)));
        pyth.set(USD_BRL, -540_123, 0, -5, block.timestamp);
        _bothRefuse(abi.encodeWithSelector(PythFxOracle.BadPrice.selector, int64(-540_123)));
        pyth.set(USD_BRL, 540_123, 0, 19, block.timestamp);
        _bothRefuse(abi.encodeWithSelector(PythFxOracle.ExponentOutOfRange.selector, int32(19)));
        pyth.set(USD_BRL, 540_123, 50, -5, block.timestamp + 5 minutes + 1);
        _bothRefuse(abi.encodeWithSelector(PythFxOracle.PriceFromFuture.selector, block.timestamp + 5 minutes + 1));
        pyth.set(USD_BRL, 5, 0, -7, block.timestamp);
        _bothRefuse(abi.encodeWithSelector(PythFxOracle.PriceRoundsToZero.selector));
    }

    function test_AFeedNeverPostedOnThisChainRefuses() public {
        PythFxOracle unposted =
            new PythFxOracle(address(pyth), keccak256("not posted"), 1 hours, 4 days, 100, governor, DELAY);
        _completeSetup(address(unposted));
        vm.expectRevert(MockPyth.PriceFeedNotFound.selector);
        unposted.brlCentsPerUnit();
    }

    function test_NothingPricesUntilSetupCloses() public {
        PythFxOracle fresh = new PythFxOracle(address(pyth), USD_BRL, 1 hours, 4 days, 100, governor, DELAY);
        vm.expectRevert(DelayedGovernance.SetupIncomplete.selector);
        fresh.brlCentsPerUnit();
        vm.expectRevert(DelayedGovernance.SetupIncomplete.selector);
        fresh.brlCentsPerUnitForBand();
    }

    function test_TheConstructorRefusesMistakes() public {
        vm.expectRevert(DelayedGovernance.ZeroAddress.selector);
        new PythFxOracle(address(0), USD_BRL, 1 hours, 4 days, 100, governor, DELAY);
        vm.expectRevert(PythFxOracle.BadFeedId.selector);
        new PythFxOracle(address(pyth), bytes32(0), 1 hours, 4 days, 100, governor, DELAY);
        vm.expectRevert(PythFxOracle.BadLimits.selector);
        new PythFxOracle(address(pyth), USD_BRL, 0, 4 days, 100, governor, DELAY);
        vm.expectRevert(PythFxOracle.BadLimits.selector);
        new PythFxOracle(address(pyth), USD_BRL, 1 hours, 4 days + 1, 100, governor, DELAY);
        vm.expectRevert(PythFxOracle.BadLimits.selector);
        new PythFxOracle(address(pyth), USD_BRL, 1 hours, 4 days, 0, governor, DELAY);
        vm.expectRevert(PythFxOracle.BadLimits.selector);
        new PythFxOracle(address(pyth), USD_BRL, 1 hours, 4 days, 1_001, governor, DELAY);
    }

    /// Tightening is a brake; anything that admits a price it did not before waits.
    function test_TighteningIsInstantRepointingOrLooseningWaits() public {
        vm.startPrank(governor);
        oracle.setLimits(30 minutes, 2 days, 50);
        assertEq(oracle.maxAge(), 30 minutes);
        assertEq(oracle.closedMaxAge(), 2 days);
        assertEq(oracle.maxConfBps(), 50);

        bytes32 other = keccak256("another feed");
        bytes[4] memory loosen = [
            abi.encodeCall(PythFxOracle.setLimits, (31 minutes, 2 days, 50)),
            abi.encodeCall(PythFxOracle.setLimits, (30 minutes, 2 days + 1, 50)),
            abi.encodeCall(PythFxOracle.setLimits, (30 minutes, 2 days, 51)),
            abi.encodeCall(PythFxOracle.setFeed, (other))
        ];
        for (uint256 i; i < loosen.length; ++i) {
            (bool ok, bytes memory ret) = address(oracle).call(loosen[i]);
            assertFalse(ok, "a loosening change went through without the delay");
            bytes4 selector = i == 3 ? PythFxOracle.setFeed.selector : PythFxOracle.setLimits.selector;
            assertEq(ret, abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, selector));
        }
        vm.stopPrank();

        _afterDelay(address(oracle), loosen[3]);
        assertEq(oracle.usdBrlId(), other);
    }

    /// What the keeper does: pay the fee and post; an older update never overwrites a newer price.
    function test_UpdatesArePaidForAndNeverGoBackwards() public {
        vm.warp(block.timestamp + 1);
        bytes[] memory u = new bytes[](1);
        u[0] = pyth.updateData(USD_BRL, 541_000, 50, -5, block.timestamp);
        vm.expectRevert(MockPyth.InsufficientFee.selector);
        pyth.updatePriceFeeds(u);
        pyth.updatePriceFeeds{value: pyth.getUpdateFee(u)}(u);
        (uint256 rate,) = oracle.brlCentsPerUnit();
        assertEq(rate, 5_410_000);

        u[0] = pyth.updateData(USD_BRL, 530_000, 50, -5, block.timestamp - 10);
        pyth.updatePriceFeeds{value: 1}(u);
        (rate,) = oracle.brlCentsPerUnit();
        assertEq(rate, 5_410_000, "the older update was ignored");
    }

    /// The ramps' USDT band end to end: Chainlink USDT/USD crossed with Pyth through the centavo adapter,
    /// pricing all Saturday on Friday's close and refusing once Monday's core session opens without a price.
    function test_TheRampsUsdtBandTradesAllWeekendOnFridaysClose() public {
        ScaledFxBandOracle cents = new ScaledFxBandOracle(oracle);
        FxTestFeed usdtUsd = new FxTestFeed(99_972_163, 8);
        ChainlinkSignedFxOracle usdt =
            new ChainlinkSignedFxOracle(address(usdtUsd), address(cents), 90_000, 1 hours, governor, DELAY);
        _completeSetup(address(usdt));

        _closeOnFriday();
        vm.warp(SAT_1500);
        usdtUsd.set(99_972_163, SAT_1500); // Chainlink's crypto feed trades all weekend
        (uint256 price, uint64 at) = usdt.brlCentsPerUnit();
        assertEq(price, 540, "0.99972163 x 540 = R$ 5,40 per USDT");
        assertEq(at, SAT_1500, "fresh enough for the escrows' one-hour check");

        vm.warp(MON_1330);
        usdtUsd.set(99_972_163, MON_1330);
        vm.expectRevert(abi.encodeWithSelector(PythFxOracle.StaleRate.selector, FRI_2000));
        usdt.brlCentsPerUnit();
    }

    function test_TheAdapterReadsASourceWithoutABandReadingAsBefore() public {
        PlainFx plain = new PlainFx();
        plain.set(5_401_230, uint64(block.timestamp - 3 hours));
        (uint256 price, uint64 at) = new ScaledFxBandOracle(plain).brlCentsPerUnit();
        assertEq(price, 540);
        assertEq(at, block.timestamp - 3 hours, "passed through: no closed-market stamp without a band reading");
    }
}
