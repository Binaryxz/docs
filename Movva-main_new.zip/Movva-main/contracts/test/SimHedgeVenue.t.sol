// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {HedgeSleeveBase, HedgeFeed} from "./utils/HedgeSleeveBase.sol";
import {IHedgeVenue} from "../hedge/IHedgeVenue.sol";
import {SimHedgeVenue} from "../hedge/SimHedgeVenue.sol";

/**
 * The TEST-ONLY venue simulator on its own: the mechanics the sub-wallet relies on (all-in fills
 * held to the limit, funding to shorts at the operator's rate, margin, liquidation by anyone) and
 * the bounds on its operator.
 */
contract SimHedgeVenueTest is HedgeSleeveBase {
    address alice = makeAddr("alice");

    function _deposit(address who, uint256 amount) internal {
        usdt.mint(who, amount);
        vm.startPrank(who);
        usdt.approve(address(venue), amount);
        venue.deposit(amount);
        vm.stopPrank();
    }

    function test_ItSaysWhatItIsAndRefusesMainnets() public {
        assertEq(
            venue.WARNING(), "TEST ONLY: SIMULATED HEDGE VENUE, NOT A REAL VENUE, NOT FOR MAINNET"
        );
        uint256[3] memory ids = [uint256(1), 42161, 8453];
        for (uint256 i; i < ids.length; ++i) {
            vm.chainId(ids[i]);
            vm.expectRevert(abi.encodeWithSelector(SimHedgeVenue.MainnetRefused.selector, ids[i]));
            new SimHedgeVenue(IERC20(address(usdt)), operator, 1 hours, 5, 5);
        }
        vm.chainId(11155111);
        new SimHedgeVenue(IERC20(address(usdt)), operator, 1 hours, 5, 5);
    }

    function test_CashInAndOutAndAnIlliquidVenueSaysSo() public {
        _deposit(alice, 1_000e6);
        assertEq(venue.cash(alice), 1_000e6);
        vm.prank(alice);
        venue.withdraw(400e6);
        assertEq(usdt.balanceOf(alice), 400e6);
        vm.prank(alice);
        vm.expectRevert(
            abi.encodeWithSelector(SimHedgeVenue.InsufficientCash.selector, 700e6, 600e6)
        );
        venue.withdraw(700e6);
        // Seed is not a claim: house liquidity is everything not owed.
        assertEq(venue.houseLiquidity(), int256(SEED));
    }

    function test_SpotFillsAreAllInAndHeldToTheLimit() public {
        _deposit(alice, 100_000e6);
        // 5 bps spread + 5 bps fee: buy at 2,502.50.
        vm.prank(alice);
        vm.expectRevert(
            abi.encodeWithSelector(SimHedgeVenue.PriceOutsideLimit.selector, 2_502.5e18, 2_502e18)
        );
        venue.buySpot(ETH, 1e18, 2_502e18);
        vm.prank(alice);
        (uint256 q, uint256 px) = venue.buySpot(ETH, 10e18, 2_502.5e18);
        assertEq(q, 10e18);
        assertEq(px, 2_502.5e18);
        assertEq(
            venue.cash(alice), 100_000e6 - 25_025e6, "nothing charged on top of the all-in price"
        );
        vm.prank(alice);
        (, px) = venue.sellSpot(ETH, 10e18, 0);
        assertEq(px, 2_497.5e18);
        assertEq(venue.cash(alice), 100_000e6 - 50e6, "a round trip costs 2 x 10 bps");
    }

    function test_PerpPnLAndTheEntryCarryTheCost() public {
        _deposit(alice, 10_000e6);
        vm.startPrank(alice);
        venue.transferMargin(int256(10_000e6));
        venue.increasePerp(ETH, false, 10e18, 0); // short 10 at 2,497.50
        vm.stopPrank();
        assertEq(venue.perpPosition(alice, ETH).entryPx, 2_497.5e18);
        // Mark at 2,500: down 25 at once (the cost of the fill).
        assertEq(venue.marginAccount(alice).equity, 10_000e6 - 25e6);
        _setPrice(2_400e8);
        vm.prank(alice);
        (uint256 f, uint256 px) = venue.reducePerp(ETH, 20e18, type(uint256).max); // reduce-only: 10
        assertEq(f, 10e18);
        assertEq(px, 2_402.4e18);
        assertEq(venue.collateralOf(alice), 10_000e6 + 951e6, "(2,497.50 - 2,402.40) x 10");
        assertEq(venue.perpPosition(alice, ETH).size, 0);
        vm.prank(alice);
        vm.expectRevert(SimHedgeVenue.NoPosition.selector);
        venue.reducePerp(ETH, 1e18, type(uint256).max);
    }

    function test_FundingAccruesToShortsAtTheOperatorsRate() public {
        _deposit(alice, 10_000e6);
        vm.startPrank(alice);
        venue.transferMargin(int256(10_000e6));
        venue.increasePerp(ETH, false, 10e18, 0);
        vm.stopPrank();
        int256 eq0 = venue.marginAccount(alice).equity;
        vm.prank(operator);
        venue.setFundingRate(ETH, 1e14); // 0.01% an hour
        _tick(10 hours);
        // 10 ETH x $2,500 x 0.01% x 10 h = $25 (plus the resting rate accrued before the change: 0).
        assertEq(venue.marginAccount(alice).equity - eq0, 25e6);
        vm.prank(operator);
        venue.setFundingRate(ETH, -1e14);
        _tick(10 hours);
        assertEq(venue.marginAccount(alice).equity - eq0, 0, "a negative rate takes it back");
        (uint64[] memory at, int256[] memory r) = venue.fundingHistory(ETH, 0);
        assertEq(at.length, 3);
        assertEq(r[0], RESTING_RATE);
        assertEq(r[2], -1e14);
    }

    function test_MarginComesBackOnlyAboveTheInitialRequirement() public {
        _deposit(alice, 10_000e6);
        vm.startPrank(alice);
        venue.transferMargin(int256(10_000e6));
        venue.increasePerp(ETH, false, 20e18, 0); // $50k at 10x needs $5k initial
        IHedgeVenue.MarginAccount memory m = venue.marginAccount(alice);
        assertEq(m.initial, 50_000e6 / 10);
        assertEq(m.maintenance, 50_000e6 / 20);
        assertEq(m.withdrawable, uint256(m.equity) - m.initial);
        vm.expectRevert();
        venue.transferMargin(-int256(m.withdrawable + 1));
        venue.transferMargin(-int256(m.withdrawable));
        vm.expectRevert();
        venue.increasePerp(ETH, false, 1e18, 0); // no room left above initial
        vm.stopPrank();
    }

    function test_AnyoneLiquidatesBelowMaintenanceAndADeficitIsBadDebt() public {
        _deposit(alice, 6_000e6);
        vm.startPrank(alice);
        venue.transferMargin(int256(6_000e6));
        venue.increasePerp(ETH, false, 20e18, 0);
        vm.stopPrank();
        vm.prank(stranger);
        vm.expectRevert();
        venue.liquidate(alice);
        // +2% leaves equity ~$5k against $2.55k maintenance: still healthy. +12%: under.
        _setPrice(2_800e8);
        vm.prank(stranger);
        venue.liquidate(alice);
        assertEq(venue.perpPosition(alice, ETH).size, 0);
        // Entered at 2,497.50 (the fill's cost is in the entry): 6,000 - 20 x 302.5 = -50. No
        // penalty to pay, 50 of bad debt.
        assertEq(venue.cash(stranger), 0);
        assertEq(venue.badDebt(), 50e6);
        assertEq(venue.collateralOf(alice), 0);
    }

    function test_ALiquidatorIsPaidFromWhatIsLeft() public {
        _deposit(alice, 6_000e6);
        vm.startPrank(alice);
        venue.transferMargin(int256(6_000e6));
        venue.increasePerp(ETH, false, 20e18, 0);
        vm.stopPrank();
        _setPrice(2_740e8); // equity 6,000 - 20 x 242.5 = 1,150 < 2,740 maintenance
        vm.prank(stranger);
        venue.liquidate(alice);
        assertEq(venue.cash(stranger), (54_800e6 * 50) / 10_000, "0.5% of the closed notional");
        assertEq(venue.badDebt(), 0);
    }

    function test_AStaleOracleFreezesTradingButNeverCash() public {
        _deposit(alice, 10_000e6);
        vm.warp(block.timestamp + 2 hours); // feeds not refreshed
        vm.startPrank(alice);
        vm.expectRevert();
        venue.buySpot(ETH, 1e18, type(uint256).max);
        venue.transferMargin(int256(1_000e6)); // into margin needs no price
        venue.withdraw(9_000e6);
        vm.stopPrank();
        assertEq(usdt.balanceOf(alice), 9_000e6);
    }

    function test_TheOperatorsKnobsAreBounded() public {
        vm.startPrank(operator);
        int256 max = venue.MAX_FUNDING_RATE();
        vm.expectRevert(SimHedgeVenue.OutOfBounds.selector);
        venue.setFundingRate(ETH, max + 1);
        vm.expectRevert(SimHedgeVenue.OutOfBounds.selector);
        venue.setFundingRate(ETH, -max - 1);
        vm.expectRevert(SimHedgeVenue.OutOfBounds.selector);
        venue.setBasis(ETH, 201, 0);
        vm.expectRevert(SimHedgeVenue.OutOfBounds.selector);
        venue.setFees(101, 0);
        vm.expectRevert(SimHedgeVenue.OutOfBounds.selector);
        venue.setFees(0, 51);
        // Max leverage, and so maintenance, is fixed at listing: no relisting.
        vm.expectRevert(abi.encodeWithSelector(SimHedgeVenue.AlreadyListed.selector, ETH));
        venue.listMarket(ETH, venueFeed, 20_000, 0);
        vm.expectRevert(SimHedgeVenue.OutOfBounds.selector);
        venue.listMarket("BTC", venueFeed, 600_000, 0);
        vm.stopPrank();

        vm.startPrank(stranger);
        vm.expectRevert(SimHedgeVenue.NotOperator.selector);
        venue.setFundingRate(ETH, 0);
        vm.expectRevert(SimHedgeVenue.NotOperator.selector);
        venue.setVenueOperator(stranger);
        vm.stopPrank();
    }

    function test_BasisMovesMarkAndSpotOffTheOracle() public {
        vm.prank(operator);
        venue.setBasis(ETH, 100, -50);
        IHedgeVenue.Prices memory p = venue.prices(ETH);
        assertEq(p.index, 2_500e18);
        assertEq(p.mark, 2_525e18);
        assertEq(p.spot, 2_487.5e18);
        assertEq(p.updatedAt, block.timestamp);
    }

    function test_UnknownMarketsRevertRatherThanReadAsEmpty() public {
        vm.expectRevert(
            abi.encodeWithSelector(SimHedgeVenue.UnknownMarket.selector, bytes32("BTC"))
        );
        venue.prices("BTC");
        vm.expectRevert(
            abi.encodeWithSelector(SimHedgeVenue.UnknownMarket.selector, bytes32("BTC"))
        );
        venue.fundingRate("BTC");
    }
}
