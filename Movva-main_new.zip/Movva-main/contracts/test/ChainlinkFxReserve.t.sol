// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Governed} from "./utils/Governed.sol";
import {TetherLike} from "./ERC4626Adapter.t.sol";
import {FxTestFeed} from "./ChainlinkSignedFxOracle.t.sol";
import {MockBrlUsdAggregator} from "./ChainlinkFxOracle.t.sol";
import {MockVerifier3} from "./RampErc20.t.sol";
import {PoolStub} from "./RampIntegration.t.sol";
import {ChainlinkFxOracle} from "../ramp/ChainlinkFxOracle.sol";
import {FiatEscrow} from "../ramp/FiatEscrow.sol";
import {OffRampEscrow} from "../ramp/OffRampEscrow.sol";
import {LPRegistry} from "../ramp/LPRegistry.sol";
import {IAttestorVerifier} from "../ramp/IAttestorVerifier.sol";
import {Movva} from "../movva/Movva.sol";
import {MovvaReserve} from "../movva/MovvaReserve.sol";

/**
 * The reserve with ChainlinkFxOracle as its FX leg, unchanged: Chainlink USDT/USD (a mock) crossed with
 * Chainlink BRL/USD inverted. Inside the core session it mints and redeems on an answer up to a day old -
 * so its `fxMaxAge` must cover the heartbeat - and at the weekend it waits, while LPs keep selling the
 * Movva they hold on its band, stamped current.
 */
contract ChainlinkFxReserveTest is Governed {
    /// Wednesday 16 September 2026, 15:00 UTC; Saturday 19th, 15:00; Monday 21st, 13:30.
    uint256 constant WED_1500 = 1_789_570_800;
    uint256 constant SAT_1500 = 1_789_830_000;
    uint256 constant MON_1330 = 1_789_997_400;
    /// 0.1975293 dollars per real: R$ 5,062540 per dollar.
    int256 constant ANSWER = 19_752_930;
    uint256 constant U = 1e6;
    uint16 constant PIX_MASK = uint16(1 << uint8(IAttestorVerifier.Rail.PIX));

    address gov = makeAddr("gov");
    address gateway = makeAddr("gateway");
    address seller = makeAddr("seller");

    MockBrlUsdAggregator brlUsd;
    ChainlinkFxOracle fx;
    FxTestFeed usdtUsd;
    TetherLike usdt;
    MovvaReserve reserve;
    Movva movva;
    FiatEscrow onramp;
    OffRampEscrow offramp;
    MockVerifier3 verifier;

    function setUp() public {
        vm.warp(WED_1500);
        brlUsd = new MockBrlUsdAggregator(8);
        brlUsd.set(ANSWER, WED_1500 - 20 hours); // a quiet day: the last round is yesterday's heartbeat
        fx = new ChainlinkFxOracle(address(brlUsd), 26 hours, 4 days, 1e6, 100e6);
        usdtUsd = new FxTestFeed(1e8, 8);
        usdt = new TetherLike();
        reserve = new MovvaReserve(
            MovvaReserve.Config({
                usdt: address(usdt),
                usdtUsdFeed: address(usdtUsd),
                fxOracle: address(fx),
                usdtUsdMaxAge: 25 hours,
                fxMaxAge: 26 hours, // the leg's MAX_AGE: anything shorter refuses a healthy, quiet feed
                governor: gov,
                governanceDelay: DELAY,
                guardian: makeAddr("guardian"),
                feeRecipient: makeAddr("fees"),
                yieldRecipient: makeAddr("yield recipient"),
                supplyCap: 1_000_000e18,
                breaker: address(0)
            })
        );
        movva = Movva(reserve.MOVVA());

        LPRegistry registry = new LPRegistry(gov, DELAY);
        PoolStub pool = new PoolStub();
        verifier = new MockVerifier3();
        onramp = new FiatEscrow(address(reserve), address(registry), address(pool), address(pool), 300, gov, DELAY, DISPUTE_TIMEOUT, TAKER_DISPUTE_TIMEOUT, MAX_VETTING_FEE_BPS);
        offramp = new OffRampEscrow(address(reserve), address(registry), 300, gov, DELAY, DISPUTE_TIMEOUT);

        vm.startPrank(gov);
        reserve.setGateway(gateway, true);
        reserve.setFees(10, 10); // the deployment default, 10 bps each way
        reserve.completeSetup();
        registry.setEscrow(address(onramp), true);
        registry.setEscrow(address(offramp), true);
        registry.setTier(gateway, LPRegistry.Tier.INSTITUTIONAL, 100_000_000);
        registry.completeSetup();
        onramp.setAsset(address(movva), address(reserve), 18, true);
        offramp.setAsset(address(movva), address(reserve), 18, true);
        onramp.setVerifier(address(verifier), true);
        offramp.setVerifier(address(verifier), true);
        onramp.completeSetup();
        offramp.completeSetup();
        vm.stopPrank();

        usdt.mint(gateway, 10_000 * U);
        vm.startPrank(gateway);
        usdt.approve(address(reserve), type(uint256).max);
        movva.approve(address(reserve), type(uint256).max);
        movva.approve(address(onramp), type(uint256).max);
        vm.stopPrank();
    }

    function test_InsideTheSessionTheReserveMintsAndRedeemsOnTheChainlinkLeg() public {
        (uint256 rate, uint64 at) = reserve.brlPerUsdtE18();
        assertEq(rate, 5_062_540e12, "US$ 1,00 x R$ 5,062540");
        assertEq(at, WED_1500 - 20 hours, "the round's own time, 20 hours old and inside fxMaxAge");

        vm.startPrank(gateway);
        uint256 minted = reserve.mint(1_000 * U, gateway, 0);
        // 1,000 USDT x 5.06254 = 5,062.54 reais, less the 10 bps fee.
        assertEq(minted, 5_062.54e18 - 5.06254e18);
        assertEq(reserve.collateralRatioBps(), 10_000, "the fee is Movva too, minted out of the same USDT");
        uint256 out = reserve.redeem(1_000e18, gateway, 0);
        vm.stopPrank();
        // 1,000 Movva less the 10 bps fee, at the rate: 999 / 5.06254, floored.
        assertEq(out, 197_331_774, "US$ 197.331774");
        (uint256 cents,) = reserve.brlCentsPerUnit();
        assertEq(cents, 100);
    }

    /// The reason the deployment sets fxMaxAge to the leg's MAX_AGE: with the Pyth default of an hour the
    /// reserve would refuse a healthy Chainlink answer for most of every day.
    function test_AnHourFxMaxAgeRefusesAHealthyQuietFeed() public {
        vm.prank(gov);
        reserve.setOracle(address(usdtUsd), address(fx), 25 hours, 1 hours); // tightening is instant
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.StaleLeg.selector, address(fx), WED_1500 - 20 hours));
        reserve.brlPerUsdtE18();
        // The band is stamped current, so Movva's band keeps working whatever the reserve's fxMaxAge.
        (uint256 cents, uint64 at) = reserve.brlCentsPerUnit();
        assertEq(cents, 100);
        assertEq(at, WED_1500);
    }

    function test_OverTheWeekendLpsTradeMovvaButNobodyMintsOrRedeems() public {
        vm.prank(gateway);
        reserve.mint(1_000 * U, gateway, 0);

        // Saturday: Chainlink's heartbeat posts a round two hours ago, and USDT/USD trades as ever.
        vm.warp(SAT_1500);
        brlUsd.set(ANSWER, SAT_1500 - 2 hours);
        usdtUsd.set(1e8, SAT_1500);
        bytes memory closed = abi.encodeWithSelector(ChainlinkFxOracle.MarketClosed.selector, SAT_1500);

        vm.startPrank(gateway);
        vm.expectRevert(closed);
        reserve.mint(100 * U, gateway, 0);
        vm.expectRevert(closed);
        reserve.redeem(100e18, gateway, 0);
        vm.stopPrank();
        vm.expectRevert(closed);
        reserve.collateralRatioBps();

        // The band does not wait: the last answer, stamped now.
        (uint256 mid, uint64 at) = reserve.brlCentsPerUnit();
        assertEq(mid, 100);
        assertEq(at, SAT_1500);
        (uint256 rate,) = reserve.bandBrlPerUsdtE18();
        assertEq(rate, 5_062_540e12);

        // So a PIX offer of Movva the LP already holds posts, and a holder's sale inside the band opens.
        vm.startPrank(gateway);
        onramp.postOffer(address(movva), 1_000e18, 101, keccak256("lp@pix"), 1e18, 1_000e18, address(verifier), PIX_MASK);
        movva.transfer(seller, 100e18);
        vm.stopPrank();
        vm.startPrank(seller);
        movva.approve(address(offramp), type(uint256).max);
        offramp.openSale(address(movva), 100e18, 9_900, keccak256("seller@pix"), address(verifier), PIX_MASK, seller);
        vm.stopPrank();

        // Monday 13:30: the session opens on Sunday's heartbeat, 18 hours old, and minting resumes.
        vm.warp(MON_1330);
        brlUsd.set(19_700_000, MON_1330 - 18 hours);
        usdtUsd.set(1e8, MON_1330);
        (rate, at) = reserve.brlPerUsdtE18();
        assertEq(rate, 5_076_142e12, "1 / 0.197 = 5.076142, floored");
        assertEq(at, MON_1330 - 18 hours);
        vm.prank(gateway);
        assertGt(reserve.mint(100 * U, gateway, 0), 0);
    }

    /// A feed that misses its heartbeat inside the session: everything that prices refuses, the band too.
    function test_AMissedHeartbeatInsideTheSessionStopsEverything() public {
        uint256 late = WED_1500 - 26 hours - 1;
        brlUsd.set(ANSWER, late);
        bytes memory stale = abi.encodeWithSelector(ChainlinkFxOracle.StaleAnswer.selector, late);
        vm.prank(gateway);
        vm.expectRevert(stale);
        reserve.mint(100 * U, gateway, 0);
        // The band path falls back to the rate (BandRead), which refuses for the same reason.
        vm.expectRevert(stale);
        reserve.brlCentsPerUnit();
    }

    /// The reserve's own bounds still apply on top of the leg's.
    function test_TheReserveRefusesAUsdtUsdLegOutOfRangeAsBefore() public {
        usdtUsd.set(0.4e8, block.timestamp);
        vm.expectRevert(abi.encodeWithSelector(MovvaReserve.UsdtUsdOutOfRange.selector, int256(0.4e8)));
        reserve.brlPerUsdtE18();
    }
}
