// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {
    LidoStakingAdapter,
    IStEthEthFeed,
    IWstETH,
    ICurveStEthPool
} from "../yield/adapters/LidoStakingAdapter.sol";

/**
 * The Lido adapter against real Lido, Curve and Chainlink on a mainnet fork.
 *
 * The test contract plays the vault (asset, keeper and guardian), so each case is about
 * the adapter's own behaviour: how it values stETH, when it refuses new stake, and how
 * both exit paths behave. Vault accounting is covered separately in YieldVault.t.sol.
 *
 * Depeg and oracle-failure cases mock only the Chainlink feed. Lido, Curve and wstETH stay
 * real, including a real pool imbalance for the sandwich case.
 *
 * Skips without FORK_RPC.
 */
contract LidoAdapterForkTest is Test {
    address constant WETH = 0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2;
    address constant WSTETH = 0x7f39C581F595B53c5cb19bD0b3f8dA6c935E2Ca0;
    address constant STETH = 0xae7ab96520DE3A18E5e111B5EaAb095312D7fE84;
    address constant CURVE = 0xDC24316b9AE028F1497c275EB9192a3Ea0f67022;
    address constant FEED = 0x86392dC19c0b719886221c78AB11eb8Cf5c52812;
    address constant QUEUE = 0x889edC2eDab5f40e902b864aD4d7AdE8E412F9B1;

    uint16 constant MAX_DEPEG_BPS = 200;
    uint16 constant MAX_SLIPPAGE_BPS = 50;
    uint16 constant STALE_HAIRCUT_BPS = 500;

    bool live;
    LidoStakingAdapter adapter;
    address recipient = makeAddr("recipient");

    // The adapter reads these from its vault.
    function asset() external pure returns (address) {
        return WETH;
    }

    function keeper() external view returns (address) {
        return address(this);
    }

    function guardian() external view returns (address) {
        return address(this);
    }

    function setUp() public {
        string memory rpc = vm.envOr("FORK_RPC", string(""));
        if (bytes(rpc).length == 0) return;
        vm.createSelectFork(rpc);
        live = true;

        // A long-running local fork keeps mining with the wall clock while Chainlink's state
        // stays frozen at the fork block, so the feed soon looks stale - 73 hours on the node
        // this was written against. The adapter is right to refuse that. Keep the feed's REAL
        // answer and re-stamp it as current, so these tests price with the live market.
        // Tests about depegs and stale oracles mock the feed again, and the newest mock wins.
        (, int256 answer,, uint256 updatedAt,) = IStEthEthFeed(FEED).latestRoundData();
        if (block.timestamp > updatedAt + 24 hours) _mockFeed(answer, block.timestamp);
        adapter = new LidoStakingAdapter(
            address(this), WETH, WSTETH, STETH, CURVE, FEED, QUEUE,
            25 hours, MAX_DEPEG_BPS, MAX_SLIPPAGE_BPS, STALE_HAIRCUT_BPS
        );
        // The adapter's deterministic address can already hold dust ETH on a mainnet fork.
        // The adapter rightly counts it as idle, but it would blur every exact check below.
        vm.deal(address(adapter), 0);
    }

    function _stake(uint256 amount) internal {
        deal(WETH, address(adapter), amount);
        adapter.deposit(amount);
    }

    function _mockFeed(int256 answer, uint256 updatedAt) internal {
        vm.mockCall(
            FEED,
            abi.encodeWithSelector(IStEthEthFeed.latestRoundData.selector),
            abi.encode(uint80(1), answer, uint256(0), updatedAt, uint80(1))
        );
    }

    function test_DepositStakesAndIsValuedConservatively() public {
        if (!live) return;
        _stake(10 ether);

        assertGt(IERC20(WSTETH).balanceOf(address(adapter)), 0, "holds wstETH");
        assertEq(IERC20(WETH).balanceOf(address(adapter)), 0, "no WETH left idle");

        // Worth no more than the ETH staked (market price is capped at par), and within
        // the live stETH/ETH discount of it.
        uint256 v = adapter.totalValue();
        assertLe(v, 10 ether, "never above par");
        assertGt(v, 9.95 ether, "within the market discount");
    }

    /// wstETH's redemption rate is what rises. The adapter's value must follow it.
    function test_ValueFollowsTheRedemptionRate() public {
        if (!live) return;
        _stake(10 ether);
        uint256 before = adapter.totalValue();
        uint256 wst = IERC20(WSTETH).balanceOf(address(adapter));
        uint256 stEth = IWstETH(WSTETH).getStETHByWstETH(wst);

        vm.mockCall(
            WSTETH,
            abi.encodeWithSelector(IWstETH.getStETHByWstETH.selector, wst),
            abi.encode(stEth * 101 / 100)
        );
        assertApproxEqRel(adapter.totalValue(), before * 101 / 100, 1e14, "one percent of yield shows up");
    }

    /**
     * Valued at the MARKET when the market is below redemption, so the loss reaches the
     * share price at once and trips the vault's drawdown breaker, and new stake stops.
     */
    function test_ADepegIsPricedInAndStopsNewStake() public {
        if (!live) return;
        _stake(10 ether);
        uint256 stEth = IWstETH(WSTETH).getStETHByWstETH(IERC20(WSTETH).balanceOf(address(adapter)));

        _mockFeed(0.95e18, block.timestamp);
        assertApproxEqAbs(adapter.totalValue(), stEth * 95 / 100, 10, "valued at the market");
        assertTrue(adapter.depegged());

        deal(WETH, address(adapter), 1 ether);
        vm.expectRevert(LidoStakingAdapter.Depegged.selector);
        adapter.deposit(1 ether);
    }

    function test_ASmallDiscountDoesNotStopStake() public {
        if (!live) return;
        _mockFeed(0.99e18, block.timestamp);
        assertFalse(adapter.depegged());
        _stake(1 ether);
    }

    /**
     * No trustworthy price: haircut the valuation, refuse new stake, and offer no instant
     * exit, because an instant sale needs a minimum output and none is honest without a price.
     */
    function test_AStaleOracleHaircutsAndClosesTheInstantExit() public {
        if (!live) return;
        _stake(10 ether);
        uint256 stEth = IWstETH(WSTETH).getStETHByWstETH(IERC20(WSTETH).balanceOf(address(adapter)));

        _mockFeed(1e18, block.timestamp - 26 hours);
        assertEq(adapter.totalValue(), stEth * (10_000 - STALE_HAIRCUT_BPS) / 10_000, "pessimistic");
        assertEq(adapter.maxInstantWithdraw(), 0, "no instant exit");
        assertTrue(adapter.depegged(), "stake refused");

        vm.expectRevert(LidoStakingAdapter.OracleUnavailable.selector);
        adapter.withdraw(1 ether, recipient);
    }

    function test_ARevertingOracleDoesNotFreezeTheViews() public {
        if (!live) return;
        _stake(1 ether);
        vm.mockCallRevert(FEED, abi.encodeWithSelector(IStEthEthFeed.latestRoundData.selector), "down");
        (bool ok,) = adapter.marketPrice();
        assertFalse(ok);
        assertGt(adapter.totalValue(), 0);
        assertEq(adapter.maxInstantWithdraw(), 0);
    }

    function test_AnInstantExitSellsOnCurveAndPaysInFull() public {
        if (!live) return;
        _stake(10 ether);
        uint256 before = adapter.totalValue();
        assertGe(adapter.maxInstantWithdraw(), 1 ether);

        uint256 got = adapter.withdraw(1 ether, recipient);
        assertEq(got, 1 ether);
        assertEq(IERC20(WETH).balanceOf(recipient), 1 ether, "paid in WETH");

        // Staked ETH is marked at the lower of redemption and the Chainlink price, and Curve
        // can pay slightly more than that mark, so the book value may fall by a little LESS
        // than the payout. Either way the difference is small at this size.
        uint256 spent = before - adapter.totalValue();
        assertApproxEqRel(spent, 1 ether, 0.01e18, "within one percent of the payout");
    }

    /**
     * Someone dumps stETH into Curve first. The minimum output comes from the Chainlink
     * price, not from the pool, so the sale refuses to fill at the manipulated price.
     */
    function test_AManipulatedPoolFailsTheOracleMinimum() public {
        if (!live) return;
        _stake(10 ether);

        address whale = makeAddr("whale");
        vm.deal(whale, 60_000 ether);
        vm.startPrank(whale);
        (bool ok,) = STETH.call{value: 60_000 ether}("");
        assertTrue(ok, "whale staked");
        uint256 dump = IERC20(STETH).balanceOf(whale);
        IERC20(STETH).approve(CURVE, dump);
        ICurveStEthPool(CURVE).exchange(1, 0, dump, 0);
        vm.stopPrank();

        vm.expectRevert();
        adapter.withdraw(1 ether, recipient);
    }

    /// Queued stETH stays on the books, so a large exit through Lido does not read as a loss.
    function test_AQueuedExitStaysCountedUntilClaimed() public {
        if (!live) return;
        _stake(10 ether);
        uint256 before = adapter.totalValue();
        uint256 wst = IERC20(WSTETH).balanceOf(address(adapter));

        uint256[] memory ids = adapter.requestExit(wst);
        assertEq(ids.length, 1);
        assertEq(IERC20(WSTETH).balanceOf(address(adapter)), 0, "wstETH moved into the queue");
        assertGt(adapter.pendingStEth(), 0);
        assertEq(adapter.pendingRequests().length, 1);
        assertApproxEqAbs(adapter.totalValue(), before, 10, "still counted");
        assertEq(adapter.maxInstantWithdraw(), 0, "but not instantly withdrawable");

        // Lido has not finalized it on this fork, so the claim must fail inside the queue.
        uint256 id = ids[0];
        vm.expectRevert();
        adapter.claimExit(id);
    }

    function test_OnlyTheKeeperOrGuardianQueuesExits() public {
        if (!live) return;
        _stake(1 ether);
        vm.prank(makeAddr("stranger"));
        vm.expectRevert(LidoStakingAdapter.NotKeeperOrGuardian.selector);
        adapter.requestExit(1);
    }

    function test_AnUnknownRequestCannotBeClaimed() public {
        if (!live) return;
        vm.expectRevert(LidoStakingAdapter.NotPending.selector);
        adapter.claimExit(123);
    }

    function test_OnlyTheVaultMovesFunds() public {
        if (!live) return;
        vm.startPrank(makeAddr("stranger"));
        vm.expectRevert(LidoStakingAdapter.NotVault.selector);
        adapter.deposit(1);
        vm.expectRevert(LidoStakingAdapter.NotVault.selector);
        adapter.withdraw(1, recipient);
        vm.stopPrank();
    }

    function test_StrayEthIsRefused() public {
        if (!live) return;
        address sender = makeAddr("sender");
        vm.deal(sender, 1 ether);
        vm.prank(sender);
        (bool ok,) = address(adapter).call{value: 1 ether}("");
        assertFalse(ok);
    }
}
