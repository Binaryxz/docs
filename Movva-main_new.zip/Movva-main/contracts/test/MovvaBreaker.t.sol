// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {MovvaBase} from "./MovvaReserve.t.sol";
import {TetherLike} from "./ERC4626Adapter.t.sol";
import {FxTestFeed} from "./ChainlinkSignedFxOracle.t.sol";
import {Governed} from "./utils/Governed.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {MovvaReserve} from "../movva/MovvaReserve.sol";
import {DivergenceBreaker} from "../movva/DivergenceBreaker.sol";
import {IPriceSource} from "../movva/IPriceSource.sol";
import {UniswapV3TwapSource} from "../movva/sources/UniswapV3TwapSource.sol";
import {ChainlinkCrossSource} from "../movva/sources/ChainlinkCrossSource.sol";
import {LimitedYieldVault} from "../yield/LimitedYieldVault.sol";

/// A source the test sets directly, including to revert.
contract MockPriceSource is IPriceSource {
    uint256 public rate;
    bool public down;

    function set(uint256 r) external {
        rate = r;
        down = false;
    }

    function fail() external {
        down = true;
    }

    function brlPerUsdtE18() external view returns (uint256) {
        require(!down, "source down");
        return rate;
    }
}

/// Just enough of a Uniswap v3 pool: a settable mean tick and liquidity.
contract MockPool {
    address public token0;
    address public token1;
    uint128 public liquidity = 1e18;
    int56 public meanTick;
    bool public shortHistory;

    constructor(address t0, address t1) {
        (token0, token1) = (t0, t1);
    }

    function setTick(int56 t) external {
        meanTick = t;
    }

    function setLiquidity(uint128 l) external {
        liquidity = l;
    }

    function setShort(bool s) external {
        shortHistory = s;
    }

    function observe(uint32[] calldata ago) external view returns (int56[] memory c, uint160[] memory s) {
        require(!shortHistory, "OLD");
        c = new int56[](2);
        s = new uint160[](2);
        c[0] = 0;
        c[1] = meanTick * int56(uint56(ago[0]));
    }
}

/// A source that answers only given more than 300,000 gas, as a deep pool history might; or, killed, never.
contract GasHungrySource is IPriceSource {
    uint256 internal immutable RATE;
    bool public dead;

    constructor(uint256 r) {
        RATE = r;
    }

    function kill() external {
        dead = true;
    }

    function brlPerUsdtE18() external view returns (uint256) {
        require(!dead, "retired");
        require(gasleft() > 300_000, "starved");
        return RATE;
    }
}

contract Dec {
    uint8 public decimals;

    constructor(uint8 d) {
        decimals = d;
    }
}

/// The reserve with a breaker over two mock sources, band 3%, halting redeem too.
contract BreakerTest is MovvaBase {
    /// DeployMovva's default.
    uint64 constant DEAD_AFTER = 30 days;
    MockPriceSource a;
    MockPriceSource b;
    DivergenceBreaker brk;

    function _config() internal view override returns (MovvaReserve.Config memory c) {
        c = super._config();
        c.breaker = address(brkAddr);
    }

    address brkAddr;

    function setUp() public virtual override {
        // The breaker must exist before the reserve is built in the base setUp.
        a = new MockPriceSource();
        b = new MockPriceSource();
        a.set(FX * 1e12);
        b.set(FX * 1e12);
        DivergenceBreaker.SourceConfig[] memory cfg = new DivergenceBreaker.SourceConfig[](2);
        cfg[0] = DivergenceBreaker.SourceConfig(a, true);
        cfg[1] = DivergenceBreaker.SourceConfig(b, true);
        brk = new DivergenceBreaker(300, true, DEAD_AFTER, cfg);
        brkAddr = address(brk);
        super.setUp();
        // The mocks must read like the live legs after the base warps.
        _sync();
    }

    function _sync() internal {
        a.set(_rate());
        b.set(_rate());
    }

    function test_InBandMintAndRedeemWork() public {
        uint256 got = _mint(1_000 * U);
        assertGt(got, 0);
        assertFalse(reserve.breakerTripped());
        _redeem(got / 2);
    }

    function test_DivergenceHaltsMintRedeemAndHarvest() public {
        _mint(1_000_000 * U);
        vm.prank(gateway);
        reserve.recapitalize(80_000 * U);
        b.set(_rate() * 110 / 100); // 10% apart
        assertTrue(reserve.breakerTripped());
        vm.startPrank(gateway);
        vm.expectRevert(abi.encodeWithSelector(DivergenceBreaker.SourcesDiverge.selector, _rate(), _rate() * 110 / 100, 300));
        reserve.mint(1 * U, gateway, 0);
        vm.expectRevert();
        reserve.redeem(1e18, gateway, 0);
        vm.stopPrank();
        vm.prank(stranger);
        vm.expectRevert(abi.encodeWithSelector(DivergenceBreaker.SourcesDiverge.selector, _rate(), _rate() * 110 / 100, 300));
        reserve.harvestYield();
        // What it does not stop: adding backing.
        vm.prank(gateway);
        reserve.recapitalize(1 * U);
    }

    function test_ClearsItselfWhenBackInBand_NoCallNeeded() public {
        _mint(10_000 * U);
        b.set(_rate() * 120 / 100);
        vm.prank(gateway);
        vm.expectRevert();
        reserve.mint(1 * U, gateway, 0);
        b.set(_rate() * 102 / 100); // inside 3%
        assertFalse(reserve.breakerTripped());
        _mint(1 * U);
        _redeem(1e18);
    }

    function test_ASourceThatRevertsHaltsRatherThanBeingDropped() public {
        a.fail();
        assertTrue(reserve.breakerTripped());
        vm.prank(gateway);
        vm.expectRevert(abi.encodeWithSelector(DivergenceBreaker.SourceUnavailable.selector, 0));
        reserve.mint(1 * U, gateway, 0);
        a.set(_rate());
        assertFalse(reserve.breakerTripped());
    }

    function test_AZeroSourceHalts() public {
        a.set(0);
        assertTrue(reserve.breakerTripped());
    }

    function test_ABandOfExactlyTheBandPasses() public {
        b.set(_rate() * 10_300 / 10_000);
        assertFalse(reserve.breakerTripped());
        b.set(_rate() * 10_300 / 10_000 + 1e12);
        assertTrue(reserve.breakerTripped());
    }

    /// The breaker latches no halt (its only state, dead-source claims, cannot halt anything; none is opened
    /// here): for any pair of source answers the verdict equals the pure spread rule,
    /// and a trip followed by a return to band is never remembered.
    function testFuzz_NeverLatches(uint256 ra, uint256 rb, bool downA, bool downB) public {
        ra = bound(ra, 1e18, 20e18);
        rb = bound(rb, 1e18, 20e18);
        uint256 p = _rate();
        a.set(ra);
        b.set(rb);
        if (downA) a.fail();
        if (downB) b.fail();
        bool expectOk = !downA && !downB;
        if (expectOk) {
            uint256 lo = _min(_min(p, ra), rb);
            uint256 hi = _max(_max(p, ra), rb);
            expectOk = (hi - lo) * 10_000 <= lo * 300;
        }
        assertEq(brk.inBand(p), expectOk, "verdict is the sources' present state");
        assertEq(reserve.breakerTripped(), !expectOk);
        // Return to band: it clears with no call, whatever came before.
        _sync();
        assertFalse(reserve.breakerTripped());
        _mint(1 * U);
    }

    function _min(uint256 x, uint256 y) internal pure returns (uint256) {
        return x < y ? x : y;
    }

    function _max(uint256 x, uint256 y) internal pure returns (uint256) {
        return x > y ? x : y;
    }

    function test_NonTrippingSourceCannotHalt() public {
        DivergenceBreaker.SourceConfig[] memory cfg = new DivergenceBreaker.SourceConfig[](2);
        cfg[0] = DivergenceBreaker.SourceConfig(a, true);
        cfg[1] = DivergenceBreaker.SourceConfig(b, false);
        DivergenceBreaker soft = new DivergenceBreaker(300, true, DEAD_AFTER, cfg);
        b.set(_rate() * 3);
        assertTrue(soft.inBand(_rate()));
        b.fail();
        soft.check(_rate());
        assertEq(soft.sourceRates()[1], 0);
    }

    function test_HaltsRedeemFalseKeepsExitsOpen() public {
        DivergenceBreaker.SourceConfig[] memory cfg = new DivergenceBreaker.SourceConfig[](1);
        cfg[0] = DivergenceBreaker.SourceConfig(a, true);
        DivergenceBreaker open = new DivergenceBreaker(300, false, DEAD_AFTER, cfg);
        uint256 p = _rate();
        a.set(p * 2);
        vm.expectRevert();
        open.check(p);
        open.checkRedeem(p);
    }

    function test_ConstructorRefusals() public {
        DivergenceBreaker.SourceConfig[] memory none = new DivergenceBreaker.SourceConfig[](0);
        vm.expectRevert(DivergenceBreaker.BadSources.selector);
        new DivergenceBreaker(300, true, DEAD_AFTER, none);
        DivergenceBreaker.SourceConfig[] memory one = new DivergenceBreaker.SourceConfig[](1);
        one[0] = DivergenceBreaker.SourceConfig(a, true);
        vm.expectRevert(DivergenceBreaker.BadBand.selector);
        new DivergenceBreaker(0, true, DEAD_AFTER, one);
        vm.expectRevert(DivergenceBreaker.BadBand.selector);
        new DivergenceBreaker(10_000, true, DEAD_AFTER, one);
        vm.expectRevert(DivergenceBreaker.BadDeadAfter.selector);
        new DivergenceBreaker(300, true, 7 days - 1, one);
        vm.expectRevert(DivergenceBreaker.BadDeadAfter.selector);
        new DivergenceBreaker(300, true, 365 days + 1, one);
        new DivergenceBreaker(300, true, 7 days, one);
        new DivergenceBreaker(300, true, 365 days, one);
    }

    /*//////////////////////////////////////////////////////////////
          DEAD SOURCES (SRM1-7): a long-dead source stops counting
          for redemptions, and only for redemptions
    //////////////////////////////////////////////////////////////*/

    /// Source `a` retires. Claimed dead by a poke, it halts everything until DEAD_AFTER has passed on
    /// the claim; then redemptions price without it, while mint and harvests stay halted.
    function test_ALongDeadSourceStopsCountingForRedemptionsOnly() public {
        _mint(1_000_000 * U);
        vm.prank(gateway);
        reserve.recapitalize(80_000 * U);
        a.fail();
        vm.expectEmit(address(brk));
        emit DivergenceBreaker.SourceReportedDead(0, block.timestamp);
        vm.prank(stranger);
        brk.poke();
        uint256 since = brk.deadSince(0);
        assertEq(since, block.timestamp);
        assertEq(brk.deadSince(1), 0, "b answers: no claim");

        // One second short: still halted, with the reason.
        _warp(DEAD_AFTER - 1);
        assertFalse(brk.longDead(0));
        assertFalse(brk.redeemOpen(_rate()));
        vm.prank(gateway);
        vm.expectRevert(abi.encodeWithSelector(DivergenceBreaker.SourceUnavailable.selector, 0));
        reserve.redeem(1e18, gateway, 0);

        _warp(1);
        assertTrue(brk.longDead(0));
        assertTrue(brk.redeemOpen(_rate()));
        assertFalse(brk.inBand(_rate()), "the mint verdict ignores claims");
        assertTrue(reserve.breakerTripped(), "the reserve's view is the mint verdict");
        uint256 before = usdt.balanceOf(gateway);
        _redeem(1_000e18);
        assertGt(usdt.balanceOf(gateway), before, "the exit is open");
        vm.prank(gateway);
        vm.expectRevert(abi.encodeWithSelector(DivergenceBreaker.SourceUnavailable.selector, 0));
        reserve.mint(1 * U, gateway, 0);
        vm.prank(stranger);
        vm.expectRevert(abi.encodeWithSelector(DivergenceBreaker.SourceUnavailable.selector, 0));
        reserve.harvestYield();
        assertEq(brk.deadSince(0), since, "a claim is never moved");
        // A second poke does not move it either.
        brk.poke();
        assertEq(brk.deadSince(0), since);
    }

    /// Leaving a long-dead source out never leaves out a live one: the rest must still agree.
    function test_TheRemainingSourcesStillHaltARedemptionThatDiverges() public {
        _mint(10_000 * U);
        a.fail();
        brk.poke();
        _warp(DEAD_AFTER);
        uint256 p = _rate();
        b.set(p * 110 / 100);
        vm.prank(gateway);
        vm.expectRevert(abi.encodeWithSelector(DivergenceBreaker.SourcesDiverge.selector, p, p * 110 / 100, 300));
        reserve.redeem(1e18, gateway, 0);
        // And b dead but unclaimed halts too.
        b.fail();
        vm.prank(gateway);
        vm.expectRevert(abi.encodeWithSelector(DivergenceBreaker.SourceUnavailable.selector, 1));
        reserve.redeem(1e18, gateway, 0);
    }

    /// The attack the fix must survive: knock a LIVE source out for one block to start a claim, then,
    /// during a real divergence long after, knock it out again to redeem without it. Any read of the
    /// source answering in between - a poke, or a mint or redemption that passes - withdraws the
    /// claim, and a diverging source answers.
    function test_AnAttackerCannotMakeALiveSourceLookDead() public {
        _mint(100_000 * U);
        // The attacker makes `a` fail for one block (say a thin TWAP pushed out of range) and pokes.
        a.fail();
        vm.prank(stranger);
        brk.poke();
        uint256 since = brk.deadSince(0);
        assertGt(since, 0);
        a.set(_rate());

        // (1) Ordinary traffic withdraws it: a passing mint read `a` answering.
        _warp(1 days);
        vm.expectEmit(address(brk));
        emit DivergenceBreaker.SourceAlive(0, since);
        _mint(1 * U);
        assertEq(brk.deadSince(0), 0, "a passing mint is proof of life");

        // (2) A redemption that passes withdraws one too.
        a.fail();
        brk.poke();
        a.set(_rate());
        _redeem(1e18);
        assertEq(brk.deadSince(0), 0, "a passing redemption is proof of life");

        // (3) No traffic at all, but one poke while it answers - even with a diverging answer.
        a.fail();
        brk.poke();
        _warp(DEAD_AFTER / 2);
        a.set(_rate() * 120 / 100); // a real divergence: `a` is right, the reserve's rate is not
        vm.prank(makeAddr("monitor"));
        brk.poke();
        assertEq(brk.deadSince(0), 0, "divergence is not death");
        _warp(DEAD_AFTER);
        a.fail(); // the attacker knocks it out again, for the redemption
        vm.prank(gateway);
        vm.expectRevert(abi.encodeWithSelector(DivergenceBreaker.SourceUnavailable.selector, 0));
        reserve.redeem(1e18, gateway, 0);
        // A new claim restarts the whole clock.
        brk.poke();
        assertEq(brk.deadSince(0), block.timestamp);
        assertFalse(brk.longDead(0));
    }

    /// A source that answers is compared, whatever its claim says: an old claim never leaves out a
    /// source that is alive in the redemption itself.
    function test_AnOldClaimNeverLeavesOutASourceThatAnswers() public {
        _mint(10_000 * U);
        a.fail();
        brk.poke();
        _warp(DEAD_AFTER + 1 days);
        uint256 p = _rate();
        a.set(p * 110 / 100); // back, and diverging
        assertTrue(brk.longDead(0), "the claim is old");
        vm.prank(gateway);
        vm.expectRevert(abi.encodeWithSelector(DivergenceBreaker.SourcesDiverge.selector, p, p * 110 / 100, 300));
        reserve.redeem(1e18, gateway, 0);
    }

    /// Gas cannot fake death: a poke with too little gas for a full read refuses rather than record a
    /// claim, and a redemption check starved below a full read refuses rather than leave a source out.
    function test_AStarvedReadIsNeverTakenAsDeath() public {
        GasHungrySource hungry = new GasHungrySource(_rate());
        DivergenceBreaker.SourceConfig[] memory cfg = new DivergenceBreaker.SourceConfig[](1);
        cfg[0] = DivergenceBreaker.SourceConfig(hungry, true);
        DivergenceBreaker g = new DivergenceBreaker(300, true, DEAD_AFTER, cfg);
        uint256 p = _rate();
        g.check(p); // alive, given its gas

        // Starved, the read would fail; it must not be taken as death.
        (bool ok, bytes memory ret) = address(g).call{gas: 305_000}(abi.encodeCall(DivergenceBreaker.poke, ()));
        assertFalse(ok);
        assertEq(bytes4(ret), DivergenceBreaker.InsufficientGas.selector);
        assertEq(g.deadSince(0), 0);
        // Given its gas it answers, so a poke records nothing.
        g.poke();
        assertEq(g.deadSince(0), 0);

        // Really dead, claimed, long dead: a starved redemption check refuses to leave it out...
        hungry.kill();
        g.poke();
        vm.warp(block.timestamp + DEAD_AFTER);
        (ok, ret) = address(g).call{gas: 305_000}(abi.encodeCall(DivergenceBreaker.checkRedeem, (p)));
        assertFalse(ok);
        assertEq(bytes4(ret), DivergenceBreaker.InsufficientGas.selector);
        // ...and one with the gas leaves it out.
        g.checkRedeem(p);
    }

    /// Keyless: poke is anyone's; an informational source is never claimed.
    function test_PokeIsAnyonesAndIgnoresNonTrippingSources() public {
        DivergenceBreaker.SourceConfig[] memory cfg = new DivergenceBreaker.SourceConfig[](2);
        cfg[0] = DivergenceBreaker.SourceConfig(a, true);
        cfg[1] = DivergenceBreaker.SourceConfig(b, false);
        DivergenceBreaker soft = new DivergenceBreaker(300, true, DEAD_AFTER, cfg);
        b.fail();
        vm.prank(makeAddr("anyone"));
        soft.poke();
        assertEq(soft.deadSince(1), 0, "an informational source is never claimed");
        vm.expectRevert(DivergenceBreaker.BadSources.selector);
        soft.deadSince(2);
    }

    /// HALTS_REDEEM=false: redemptions were never halted, so claims change nothing for them.
    function test_WithHaltsRedeemFalseClaimsChangeNothing() public {
        DivergenceBreaker.SourceConfig[] memory cfg = new DivergenceBreaker.SourceConfig[](1);
        cfg[0] = DivergenceBreaker.SourceConfig(a, true);
        DivergenceBreaker open = new DivergenceBreaker(300, false, DEAD_AFTER, cfg);
        a.fail();
        open.poke();
        vm.warp(block.timestamp + DEAD_AFTER);
        assertTrue(open.redeemOpen(1e18));
        open.checkRedeem(1e18);
        vm.expectRevert(abi.encodeWithSelector(DivergenceBreaker.SourceUnavailable.selector, 0));
        open.check(1e18);
    }

    /// Claims can only relax the REDEMPTION verdict, and only for a source that fails now: for any
    /// answers and any claim ages, the mint verdict is the claim-free rule, and the redemption verdict
    /// is that rule with exactly the failing, long-dead sources left out.
    function testFuzz_ClaimsOnlyRelaxRedemptionsForSourcesDeadNow(
        uint256 ra,
        uint256 rb,
        bool downA,
        bool downB,
        bool claimA,
        bool claimB,
        uint256 age
    ) public {
        ra = bound(ra, 1e18, 20e18);
        rb = bound(rb, 1e18, 20e18);
        age = bound(age, 0, 2 * DEAD_AFTER);
        if (claimA) a.fail();
        if (claimB) b.fail();
        brk.poke();
        _warp(age);
        uint256 p = _rate();
        a.set(ra);
        b.set(rb);
        if (downA) a.fail();
        if (downB) b.fail();
        bool skipA = downA && claimA && age >= DEAD_AFTER;
        bool skipB = downB && claimB && age >= DEAD_AFTER;
        assertEq(brk.inBand(p), !downA && !downB && _spreadOk(p, ra, rb, true, true), "mint: claims never matter");
        bool redeemOk = (!downA || skipA) && (!downB || skipB) && _spreadOk(p, ra, rb, !downA, !downB);
        assertEq(brk.redeemOpen(p), redeemOk, "redeem: only dead-now, long-dead sources are left out");
        try brk.checkRedeem(p) {
            assertTrue(redeemOk);
            // A passing check withdraws the claim of every source it read answering.
            if (!downA) assertEq(brk.deadSince(0), 0);
            if (!downB) assertEq(brk.deadSince(1), 0);
        } catch {
            assertFalse(redeemOk);
        }
    }

    function _spreadOk(uint256 p, uint256 ra, uint256 rb, bool withA, bool withB) internal pure returns (bool) {
        uint256 lo = p;
        uint256 hi = p;
        if (withA) (lo, hi) = (_min(lo, ra), _max(hi, ra));
        if (withB) (lo, hi) = (_min(lo, rb), _max(hi, rb));
        return (hi - lo) * 10_000 <= lo * 300;
    }

    function test_BandOracleIsNotHalted() public view {
        // brlCentsPerUnit is a sanity band for the ramps and is left as it was.
        reserve.brlCentsPerUnit();
    }
}

/// The TWAP and Chainlink-cross sources.
contract SourcesTest is Governed {
    Dec usdtT;
    Dec brz;

    function setUp() public {
        usdtT = new Dec(6);
        brz = new Dec(18);
    }

    /// token0 = USDT (6), token1 = BRZ (18): BRL raw per USDT raw = 5.4e12 -> tick ~ ln(5.4e12)/ln(1.0001).
    function test_TwapRateUsdtIsToken0() public {
        MockPool pool = new MockPool(address(usdtT), address(brz));
        // ln(5.4e12) / ln(1.0001) = 29.2236.../0.000099995 ~= 293_189
        pool.setTick(293_189);
        UniswapV3TwapSource s = new UniswapV3TwapSource(address(pool), address(usdtT), address(brz), 1800, 1);
        uint256 r = s.brlPerUsdtE18();
        assertApproxEqRel(r, 5.4e18, 0.001e18);
    }

    function test_TwapRateUsdtIsToken1() public {
        // token0 = BRZ, token1 = USDT: the tick is the negative of the other.
        Dec lowBrz = new Dec(18);
        (address t0, address t1) = address(lowBrz) < address(usdtT) ? (address(lowBrz), address(usdtT)) : (address(usdtT), address(lowBrz));
        MockPool pool = new MockPool(t0, t1);
        bool usdtIs0 = t0 == address(usdtT);
        pool.setTick(usdtIs0 ? int56(293_189) : int56(-293_189));
        UniswapV3TwapSource s = new UniswapV3TwapSource(address(pool), address(usdtT), address(lowBrz), 1800, 1);
        assertApproxEqRel(s.brlPerUsdtE18(), 5.4e18, 0.001e18);
    }

    function test_TwapRevertsWhenThinOrShort() public {
        MockPool pool = new MockPool(address(usdtT), address(brz));
        pool.setTick(293_189);
        UniswapV3TwapSource s = new UniswapV3TwapSource(address(pool), address(usdtT), address(brz), 1800, 1e12);
        pool.setLiquidity(1e11);
        vm.expectRevert();
        s.brlPerUsdtE18();
        pool.setLiquidity(1e13);
        s.brlPerUsdtE18();
        pool.setShort(true);
        vm.expectRevert();
        s.brlPerUsdtE18();
    }

    function test_TwapNegativeTickRoundsDown() public {
        MockPool pool = new MockPool(address(usdtT), address(brz));
        pool.setTick(-100);
        UniswapV3TwapSource s = new UniswapV3TwapSource(address(pool), address(usdtT), address(brz), 60, 1);
        // a tiny rate, but a valid nonzero reading at 1e-12 scale
        s.brlPerUsdtE18();
    }

    function test_ChainlinkCross() public {
        vm.warp(1_800_000_000);
        FxTestFeed u = new FxTestFeed(1e8, 8); // $1
        FxTestFeed br = new FxTestFeed(18_518_518, 8); // $0.18518518 per real
        ChainlinkCrossSource s = new ChainlinkCrossSource(address(u), address(br), 25 hours, 25 hours);
        assertApproxEqRel(s.brlPerUsdtE18(), 5.4e18, 1e12);
        vm.warp(block.timestamp + 26 hours);
        vm.expectRevert();
        s.brlPerUsdtE18();
    }
}

/// LimitedYieldVault: the per-owner daily limit and the timelock above it.
contract LimitedYieldVaultTest is Governed {
    TetherLike usdt;
    LimitedYieldVault vault;
    address gov = makeAddr("gov");
    address alice = makeAddr("alice");
    address bob = makeAddr("bob");
    address carol = makeAddr("carol");
    uint256 constant U = 1e6;

    function setUp() public {
        vm.warp(1_800_000_000);
        usdt = new TetherLike();
        vault = new LimitedYieldVault(
            IERC20(address(usdt)), "v", "v", gov, makeAddr("g"), makeAddr("k"), 1e15, 100, DELAY, 1_000, 1 days
        );
        vm.prank(gov);
        vault.completeSetup();
        usdt.mint(alice, 1_000_000 * U);
        usdt.mint(bob, 9_000_000 * U);
        vm.startPrank(alice);
        usdt.approve(address(vault), type(uint256).max);
        vault.deposit(1_000_000 * U, alice);
        vm.stopPrank();
        vm.startPrank(bob);
        usdt.approve(address(vault), type(uint256).max);
        vault.deposit(9_000_000 * U, bob);
        vm.stopPrank();
    }

    function test_InstantWithinTheLimit() public {
        // 10% of 10,000,000 = 1,000,000
        assertEq(vault.instantRoom(alice), 1_000_000 * U);
        vm.prank(alice);
        vault.withdraw(400_000 * U, alice, alice);
        assertEq(usdt.balanceOf(alice), 400_000 * U);
    }

    function test_AboveTheLimitRevertsInstantly() public {
        vm.prank(bob);
        vm.expectRevert();
        vault.withdraw(2_000_000 * U, bob, bob);
    }

    function test_SlowLaneExecutesOnceForExactlyTheSharesToTheReceiver() public {
        uint256 shares = vault.balanceOf(bob);
        vm.prank(bob);
        uint256 id = vault.requestRedeem(shares, carol, bob);
        assertEq(vault.balanceOf(bob), 0);
        vm.expectRevert();
        vault.executeRedeem(id);
        vm.warp(block.timestamp + 1 days);
        uint256 supplyBefore = vault.totalSupply();
        vm.prank(makeAddr("anyone"));
        uint256 paid = vault.executeRedeem(id);
        assertEq(usdt.balanceOf(carol), paid);
        assertApproxEqAbs(paid, 9_000_000 * U, 2);
        assertEq(supplyBefore - vault.totalSupply(), shares, "burned exactly the queued shares");
        vm.expectRevert(abi.encodeWithSelector(LimitedYieldVault.RequestDone.selector, id));
        vault.executeRedeem(id);
    }

    function test_NobodyCancels() public {
        vm.prank(bob);
        vault.requestRedeem(1e12, bob, bob);
        (bool ok,) = address(vault).call(abi.encodeWithSignature("cancelRedeem(uint256)", 0));
        assertFalse(ok);
    }

    function test_RequestNeedsAllowanceFromOthers() public {
        vm.prank(carol);
        vm.expectRevert();
        vault.requestRedeem(1e12, carol, bob);
        vm.prank(bob);
        vault.approve(carol, 1e12);
        vm.prank(carol);
        vault.requestRedeem(1e12, carol, bob);
    }

    function test_BucketRefillsOverADay() public {
        vm.prank(alice);
        vault.withdraw(500_000 * U, alice, alice);
        assertEq(vault.instantRoom(alice), vault.totalAssets() / 10 - 500_000 * U);
        vm.warp(block.timestamp + 12 hours);
        // the limit shrank with total assets; room is at most the limit
        assertLe(vault.instantRoom(alice), vault.totalAssets() / 10);
        vm.warp(block.timestamp + 12 hours);
        assertEq(vault.instantRoom(alice), vault.totalAssets() / 10);
    }

    function testFuzz_ASlowRequestPaysItsSharesOnceToItsReceiver(uint256 shares, uint256 wait) public {
        shares = bound(shares, 1e6, vault.balanceOf(bob));
        wait = bound(wait, 1 days, 400 days);
        vm.prank(bob);
        uint256 id = vault.requestRedeem(shares, carol, bob);
        uint256 expect = vault.previewRedeem(shares);
        vm.warp(block.timestamp + wait);
        uint256 supply = vault.totalSupply();
        uint256 got = vault.executeRedeem(id);
        assertEq(got, expect);
        assertEq(usdt.balanceOf(carol), got);
        assertEq(supply - vault.totalSupply(), shares);
        vm.expectRevert();
        vault.executeRedeem(id);
        assertEq(usdt.balanceOf(carol), got);
    }
}

import {Test, console2} from "forge-std/Test.sol";

/// SRM1-7: sources dying and reviving, pokes, mints, redemptions and waits, against a model of the claims.
contract BreakerClaimsHandler is Test {
    MovvaReserve reserve;
    DivergenceBreaker brk;
    MockPriceSource[2] src;
    address gateway;
    uint64 immutable DEAD_AFTER;

    /// The claim the model says each source carries: set by a poke that finds it dead with none,
    /// cleared by any poke, mint or redemption that read it answering.
    uint256[2] public modelClaim;
    /// A mint while a source was dead; a redemption while a source was dead and not long dead on
    /// the model's claim.
    uint256 public violations;
    mapping(bytes32 => uint256) public calls;

    constructor(MovvaReserve r, DivergenceBreaker b, MockPriceSource a, MockPriceSource c, address g) {
        (reserve, brk, gateway) = (r, b, g);
        src[0] = a;
        src[1] = c;
        DEAD_AFTER = b.DEAD_AFTER();
    }

    function kill(uint8 i) external {
        src[i % 2].fail();
        ++calls["kill"];
    }

    function revive(uint8 i) external {
        (uint256 rate,) = reserve.brlPerUsdtE18();
        src[i % 2].set(rate);
        ++calls["revive"];
    }

    function poke(address who) external {
        vm.prank(who);
        brk.poke();
        for (uint256 i; i < 2; ++i) {
            if (!src[i].down()) modelClaim[i] = 0;
            else if (modelClaim[i] == 0) modelClaim[i] = block.timestamp;
        }
        ++calls["poke"];
    }

    function mint(uint256 amount) external {
        amount = bound(amount, 1e6, 10_000e6);
        bool anyDown = src[0].down() || src[1].down();
        vm.prank(gateway);
        try reserve.mint(amount, gateway, 0) {
            if (anyDown) ++violations;
            _alive();
            ++calls["mint"];
        } catch {}
    }

    function redeem(uint256 amount) external {
        uint256 bal = IERC20(reserve.MOVVA()).balanceOf(gateway);
        if (bal < 1e18) return;
        amount = bound(amount, 1e18, bal);
        vm.prank(gateway);
        try reserve.redeem(amount, gateway, 0) {
            for (uint256 i; i < 2; ++i) {
                if (src[i].down() && !modelLongDead(i)) ++violations;
            }
            _alive();
            ++calls[src[0].down() || src[1].down() ? bytes32("redeemPastADeadSource") : bytes32("redeem")];
        } catch {}
    }

    function modelLongDead(uint256 i) public view returns (bool) {
        return modelClaim[i] != 0 && block.timestamp >= modelClaim[i] + DEAD_AFTER;
    }

    function down(uint256 i) external view returns (bool) {
        return src[i].down();
    }

    function _alive() internal {
        for (uint256 i; i < 2; ++i) {
            if (!src[i].down()) modelClaim[i] = 0;
        }
    }
}

/**
 * SRM1-7 as invariants. Whatever the sequence of deaths, revivals, pokes (by anyone), mints,
 * redemptions and waits of up to twenty days:
 *  - the breaker's claims are exactly the model's: a claim starts only at a poke that found the source
 *    dead, is never moved, and ends at the first poke or passing check that read the source answering;
 *  - no mint passes while a tripping source is dead, and no redemption passes while one is dead and
 *    not long dead on its claim;
 *  - exits are never locked by a long-dead source: with every source answering at the rate or long
 *    dead, `redeemOpen` is true, and with any source dead and not long dead it is false.
 */
/// forge-config: default.invariant.runs = 64
/// forge-config: default.invariant.depth = 100
/// forge-config: deep.invariant.runs = 1000
/// forge-config: deep.invariant.depth = 256
contract BreakerClaimsInvariantTest is BreakerTest {
    BreakerClaimsHandler h;

    function setUp() public override {
        super.setUp();
        _mint(1_000_000 * U);
        vm.prank(gateway);
        reserve.recapitalize(80_000 * U);
        h = new BreakerClaimsHandler(reserve, brk, a, b, gateway);
        targetContract(address(h));
        targetContract(address(this));
        bytes4[] memory sel = new bytes4[](1);
        sel[0] = this.handlerWait.selector;
        targetSelector(FuzzSelector({addr: address(this), selectors: sel}));
    }

    /// The clock moves with the legs re-published; a live source keeps answering at the rate.
    function handlerWait(uint256 dt) external {
        _warp(bound(dt, 0, 20 days));
        if (!a.down()) a.set(_rate());
        if (!b.down()) b.set(_rate());
    }

    function invariant_ClaimsAreExactlyTheModels() public view {
        assertEq(brk.deadSince(0), h.modelClaim(0), "source 0's claim");
        assertEq(brk.deadSince(1), h.modelClaim(1), "source 1's claim");
        assertEq(h.violations(), 0, "a mint with a dead source, or a redemption with one not long dead");
    }

    function invariant_ALongDeadSourceNeverLocksExits() public view {
        bool open = true;
        for (uint256 i; i < 2; ++i) {
            if (h.down(i) && !h.modelLongDead(i)) open = false;
        }
        assertEq(brk.redeemOpen(_rate()), open);
        assertEq(brk.inBand(_rate()), !h.down(0) && !h.down(1), "the mint verdict never reads a claim");
    }

    /// The handler can reach the state the fix is for: a redemption that passes a long-dead source.
    function test_TheHandlerReachesARedemptionPastADeadSource() public {
        h.kill(0);
        h.poke(stranger);
        this.handlerWait(20 days);
        this.handlerWait(20 days);
        h.redeem(1e18);
        assertEq(h.calls("redeemPastADeadSource"), 1);
        assertEq(h.violations(), 0);
        h.mint(1e6);
        assertEq(h.calls("mint"), 0, "and no mint past it");
    }

    /// Not an invariant: how much of the state space each run reached, in successful calls (-vv).
    function afterInvariant() public view {
        string[6] memory names = ["kill", "revive", "poke", "mint", "redeem", "redeemPastADeadSource"];
        for (uint256 i; i < names.length; ++i) {
            console2.log(names[i], h.calls(bytes32(bytes(names[i]))));
        }
    }
}
