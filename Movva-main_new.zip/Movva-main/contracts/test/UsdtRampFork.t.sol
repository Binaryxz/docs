// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Vm} from "forge-std/Test.sol";
import {console2} from "forge-std/console2.sol";
import {ReclaimProofBuilder} from "./utils/ReclaimProofBuilder.sol";
import {FiatEscrow} from "../ramp/FiatEscrow.sol";
import {OffRampEscrow} from "../ramp/OffRampEscrow.sol";
import {LPRegistry} from "../ramp/LPRegistry.sol";
import {ReclaimZkTlsVerifier} from "../ramp/ReclaimZkTlsVerifier.sol";
import {IAttestorVerifier} from "../ramp/IAttestorVerifier.sol";
import {SignedPriceOracle} from "../ramp/SignedPriceOracle.sol";
import {ChainlinkSignedFxOracle} from "../ramp/ChainlinkSignedFxOracle.sol";
import {SafeTransferLib} from "../ramp/SafeTransferLib.sol";
import {RulingLib} from "../ramp/RulingLib.sol";

/// Tether's mainnet token, as far as these tests touch it. Pre-0.4.22 ERC-20: no return values.
interface ITetherToken {
    function owner() external view returns (address);
    function decimals() external view returns (uint256);
    function balanceOf(address) external view returns (uint256);
    function allowance(address, address) external view returns (uint256);
    function transfer(address, uint256) external;
    function approve(address, uint256) external;
    function paused() external view returns (bool);
    function pause() external;
    function unpause() external;
    function basisPointsRate() external view returns (uint256);
    function maximumFee() external view returns (uint256);
    function setParams(uint256 newBasisPoints, uint256 newMaxFee) external;
    function isBlackListed(address) external view returns (bool);
    function addBlackList(address) external;
    function removeBlackList(address) external;
    function destroyBlackFunds(address) external;
    function deprecated() external view returns (bool);
    function deprecate(address upgradedAddress) external;
}

interface IChainlinkRounds {
    function decimals() external view returns (uint8);
    function description() external view returns (string memory);
    function latestRoundData() external view returns (uint80, int256, uint256, uint256, uint80);
    function getRoundData(uint80) external view returns (uint80, int256, uint256, uint256, uint80);
}

interface IEntrypointUsdt {
    function assetConfig(address)
        external
        view
        returns (address pool, uint256 minimumDepositAmount, uint256 vettingFeeBPS, uint256 maxRelayFeeBPS);
    function deposit(address asset, uint256 value, uint256 precommitment) external returns (uint256);
    function updatePoolConfiguration(address asset, uint256 minimumDepositAmount, uint256 vettingFeeBPS, uint256 maxRelayFeeBPS) external;
    function hasRole(bytes32 role, address account) external view returns (bool);
}

interface IPoolView {
    function ASSET() external view returns (address);
    function depositors(uint256 label) external view returns (address);
    function dead() external view returns (bool);
}

/**
 * USDT as a first-class ramp asset, against the real contracts on an Ethereum mainnet fork:
 * Tether's token, Chainlink's USDT/USD feed, and 0xbow's live Privacy Pools Entrypoint and
 * USDT pool. Only our own contracts are deployed; the publishers, zkTLS witnesses and arbitrator
 * are test keys, because what is under test is how our escrows behave around those real
 * contracts - including when Tether uses the powers its token gives it. PIX settles here as it
 * must everywhere, on a zkTLS proof of the bank session (IAttestorVerifier.provesBankSession); the
 * FX leg is a signed quorum's, the supported alternative to Pyth, because the band only needs a rate.
 *
 * USDT is put in place by writing its `balances` slot (slot 2). The layout is not assumed:
 * `test_TheMainnetFactsTheseTestsRestOn` checks every slot these tests write against the
 * token's own getters, so a wrong slot fails there rather than silently testing nothing.
 *
 *   FORK_RPC=https://ethereum-rpc.publicnode.com forge test --match-path contracts/test/UsdtRampFork.t.sol
 *
 * Optional FORK_BLOCK pins the block. Skips without FORK_RPC, or when the RPC is not mainnet.
 */
abstract contract UsdtForkBase is ReclaimProofBuilder {
    address constant USDT = 0xdAC17F958D2ee523a2206206994597C13D831ec7;
    address constant USDT_USD = 0x3E7d1eAB13ad0104d2750B8863b489D65364e32D;
    address constant ETH_USD = 0x5f4eC3Df9cbd43714FE2740f5E3616155c5b8419;
    /// 0xbow's live mainnet deployment. Our Sepolia deployment runs its own Entrypoint.
    address constant ENTRYPOINT = 0x6818809EefCe719E480a7526D76bD3e561526b46;
    /// 0xbow's Entrypoint owner (a Safe), as in upstream's mainnet upgrade test; `hasRole` is checked.
    address constant EP_OWNER = 0xAd7f9A19E2598b6eFE0A25C84FB1c87F81eB7159;
    address constant USDT_POOL = 0xe859C0bD25f260BaEE534Fb52e307D3b64D24572;
    address constant ETH_POOL = 0xF241d57C6DebAe225c0F2e6eA1529373C9A9C9fB;

    uint256 constant SNARK_FIELD =
        21888242871839275222246405745257275088548364400416034343698204186575808495617;
    /// 24h heartbeat plus an hour; the deploy runbook's USD_FEED_MAX_AGES for USDT.
    uint64 constant USDT_USD_MAX_AGE = 25 hours;
    /// An illustrative R$5.40 per US dollar. The band only needs the LP's quote inside it.
    uint256 constant FX_CENTS = 540;

    bool live;
    ITetherToken usdt = ITetherToken(USDT);

    SignedPriceOracle fx;
    ChainlinkSignedFxOracle oracle;
    LPRegistry registry;
    ReclaimZkTlsVerifier zktls;
    FiatEscrow onramp;
    OffRampEscrow offramp;

    uint256 constant PUB1 = 0xF1;
    uint256 constant PUB2 = 0xF2;
    uint256 constant ATT1 = 0xA11CE;
    uint256 constant ATT2 = 0xB0B;
    uint256 constant ARB = 0xA4B;

    address gov = makeAddr("multisig");
    address lp = makeAddr("lp");
    address lp2 = makeAddr("lp2");
    address taker = makeAddr("taker");
    address payout = makeAddr("payout");
    address seller = makeAddr("seller");
    address refund = makeAddr("seller-refund");

    bytes32 constant LP_PIX = keccak256("lp pix commitment");
    bytes32 constant SELLER_PIX = keccak256("seller pix commitment");
    uint16 constant PIX_MASK = uint16(1 << uint8(IAttestorVerifier.Rail.PIX));

    uint64 fxSeq;
    uint256 receipts;
    uint256 precommitments;

    function setUp() public virtual {
        string memory rpc = vm.envOr("FORK_RPC", string(""));
        if (bytes(rpc).length == 0) return;
        uint256 blk = vm.envOr("FORK_BLOCK", uint256(0));
        if (blk == 0) vm.createSelectFork(rpc);
        else vm.createSelectFork(rpc, blk);
        if (USDT.code.length == 0 || USDT_USD.code.length == 0 || ENTRYPOINT.code.length == 0) return;
        live = true;

        address[] memory publishers = new address[](2);
        (publishers[0], publishers[1]) = (vm.addr(PUB1), vm.addr(PUB2));
        fx = new SignedPriceOracle(gov, DELAY, publishers, 2);
        oracle = new ChainlinkSignedFxOracle(USDT_USD, address(fx), USDT_USD_MAX_AGE, 1 hours, gov, DELAY);
        // The escrows' native-ETH oracle, crossed with the same signed FX leg.
        ChainlinkSignedFxOracle ethOracle = new ChainlinkSignedFxOracle(ETH_USD, address(fx), 75 minutes, 1 hours, gov, DELAY);

        address[] memory witnesses = new address[](2);
        (witnesses[0], witnesses[1]) = (vm.addr(ATT1), vm.addr(ATT2));
        zktls = new ReclaimZkTlsVerifier(gov, DELAY, witnesses, 2, _one(BANK_TEMPLATE), _oneString(BANK_PREFIX));
        registry = new LPRegistry(gov, DELAY);
        onramp = new FiatEscrow(address(ethOracle), address(registry), ENTRYPOINT, ETH_POOL, 500, gov, DELAY, DISPUTE_TIMEOUT, TAKER_DISPUTE_TIMEOUT, MAX_VETTING_FEE_BPS);
        offramp = new OffRampEscrow(address(ethOracle), address(registry), 500, gov, DELAY, DISPUTE_TIMEOUT);

        vm.startPrank(gov);
        fx.completeSetup();
        oracle.completeSetup();
        ethOracle.completeSetup();
        zktls.completeSetup();
        registry.setEscrow(address(onramp), true);
        registry.setEscrow(address(offramp), true);
        registry.setTier(lp, LPRegistry.Tier.INSTITUTIONAL, 100_000_000);
        registry.setTier(lp2, LPRegistry.Tier.INSTITUTIONAL, 100_000_000);
        registry.completeSetup();
        onramp.setVerifier(address(zktls), true);
        offramp.setVerifier(address(zktls), true);
        onramp.setArbitrator(vm.addr(ARB), true);
        offramp.setArbitrator(vm.addr(ARB), true);
        onramp.setAsset(USDT, address(oracle), 6, true);
        offramp.setAsset(USDT, address(oracle), 6, true);
        onramp.completeSetup();
        offramp.completeSetup();
        vm.stopPrank();

        _publishFx(FX_CENTS);
        for (uint256 i; i < 5; ++i) {
            address a = [lp, lp2, seller, taker, payout][i];
            _mint(a, 10_000e6);
        }
    }

    /*//////////////////////////////////////////////////////////////
                                HELPERS
    //////////////////////////////////////////////////////////////*/

    /// Write Tether's `balances[to]` (slot 2), and prove the token reads it back.
    function _mint(address to, uint256 amount) internal {
        vm.store(USDT, keccak256(abi.encode(to, uint256(2))), bytes32(amount));
        assertEq(usdt.balanceOf(to), amount, "USDT balances slot");
    }

    function _publishFx(uint256 cents) internal {
        uint64 at = uint64(block.timestamp);
        bytes32 d = fx.digest(cents, at, ++fxSeq);
        (uint256 lo, uint256 hi) = vm.addr(PUB1) < vm.addr(PUB2) ? (PUB1, PUB2) : (PUB2, PUB1);
        bytes[] memory sigs = new bytes[](2);
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(lo, d);
        sigs[0] = abi.encodePacked(r, s, v);
        (v, r, s) = vm.sign(hi, d);
        sigs[1] = abi.encodePacked(r, s, v);
        fx.submit(cents, at, fxSeq, sigs);
    }

    function _mid() internal view returns (uint256 mid) {
        (mid,) = oracle.brlCentsPerUnit();
    }

    function _post(address who, uint256 amount) internal returns (bytes32 offerId) {
        uint256 mid = _mid();
        vm.startPrank(who);
        usdt.approve(address(onramp), amount);
        offerId = onramp.postOffer(USDT, amount, mid, LP_PIX, 1e6, amount, address(zktls), PIX_MASK);
        vm.stopPrank();
    }

    function _lock(bytes32 offerId, uint256 amount, FiatEscrow.Delivery delivery)
        internal
        returns (bytes32 orderId, uint256 precommitment)
    {
        if (delivery == FiatEscrow.Delivery.SHIELDED) {
            precommitment = uint256(keccak256(abi.encode("taker precommitment", offerId, ++precommitments))) % SNARK_FIELD;
        }
        vm.prank(taker);
        orderId = onramp.lockOrder(offerId, amount, delivery, payout, precommitment);
    }

    function _open(uint256 amount) internal returns (bytes32 saleId) {
        uint256 cents = (amount * _mid()) / 1e6;
        vm.startPrank(seller);
        usdt.approve(address(offramp), amount);
        saleId = offramp.openSale(USDT, amount, cents, SELLER_PIX, address(zktls), PIX_MASK, refund);
        vm.stopPrank();
    }

    function _orderCents(bytes32 orderId) internal view returns (uint256 cents) {
        (,,, cents,,,,,,,) = onramp.orders(orderId);
    }

    function _orderState(bytes32 orderId) internal view returns (FiatEscrow.OrderState st) {
        (,,,,,, st,,,,) = onramp.orders(orderId);
    }

    function _saleState(bytes32 saleId) internal view returns (OffRampEscrow.SaleState st) {
        (,,,,,,,,,,, st) = offramp.sales(saleId);
    }

    function _saleCents(bytes32 saleId) internal view returns (uint256 cents) {
        (,,, cents,,,,,,,,) = offramp.sales(saleId);
    }

    /// What the on-ramp owes, from its own books: every offer's available plus locked.
    function _onrampOwes(bytes32 offerId) internal view returns (uint256) {
        (,, uint256 available, uint256 locked,,,,,,,,) = onramp.offers(offerId);
        return available + locked;
    }

    /// Two witnesses sign a zkTLS claim, from the allowlisted bank endpoint, of a PIX payment of
    /// `cents` to `payee`, bound to `id` (an order or a sale).
    function _proof(bytes32 id, uint256 cents, bytes32 payee) internal returns (bytes memory) {
        Fields memory f = Fields({
            orderId: id,
            bankTxId: keccak256(abi.encode("E2E PIX", id, ++receipts)),
            payeeKeyHash: payee,
            payerRef: keccak256("payer"),
            amountBrlCents: cents,
            paidAt: block.timestamp,
            rail: uint8(IAttestorVerifier.Rail.PIX)
        });
        uint256[] memory keys = new uint256[](2);
        (keys[0], keys[1]) = (ATT1, ATT2);
        return abi.encode(_proof(_params(BANK_URL), _context(f, BANK_TEMPLATE), keys));
    }

    function _ruling(address escrow, bytes32 id, string memory outcome)
        internal
        view
        returns (RulingLib.Ruling memory r, bytes memory sig)
    {
        r = RulingLib.Ruling({
            orderId: id,
            outcome: outcome,
            evidenceRoot: keccak256("bank statement"),
            rationale: "payment confirmed by the payer's bank",
            ruledAt: uint64(block.timestamp),
            byDefault: false
        });
        bytes32 structHash = keccak256(
            abi.encode(
                keccak256(
                    "Ruling(bytes32 orderId,address escrow,string outcome,bytes32 evidenceRoot,string rationale,uint64 ruledAt,bool byDefault)"
                ),
                r.orderId,
                escrow,
                keccak256(bytes(r.outcome)),
                r.evidenceRoot,
                keccak256(bytes(r.rationale)),
                r.ruledAt,
                r.byDefault
            )
        );
        bytes32 domain = keccak256(
            abi.encode(
                keccak256("EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)"),
                keccak256("PrivacyPoolsBRL-Dispute"),
                keccak256("1"),
                block.chainid,
                escrow
            )
        );
        (uint8 v, bytes32 rr, bytes32 s) = vm.sign(ARB, keccak256(abi.encodePacked("\x19\x01", domain, structHash)));
        sig = abi.encodePacked(rr, s, v);
    }

    function _asTether(bytes memory call) internal {
        vm.prank(usdt.owner());
        (bool ok,) = USDT.call(call);
        require(ok, "Tether owner call failed");
    }
}

/// The two ramps, end to end, in USDT.
contract UsdtRampForkTest is UsdtForkBase {
    /**
     * Every external fact the rest of this file leans on, read from the chain rather than
     * remembered: the token's decimals and the storage slots the tests write, the feed's shape,
     * and which pool the Entrypoint routes USDT to, with what minimum.
     */
    function test_TheMainnetFactsTheseTestsRestOn() public view {
        if (!live) return;
        assertEq(usdt.decimals(), 6, "USDT has 6 decimals");
        // Slots 0 (owner, with `paused` packed above it), 3, 4 and 9 against their getters.
        assertEq(address(uint160(uint256(vm.load(USDT, bytes32(uint256(0)))))), usdt.owner(), "slot 0 is owner");
        assertEq(uint256(vm.load(USDT, bytes32(uint256(3)))), usdt.basisPointsRate(), "slot 3 is basisPointsRate");
        assertEq(uint256(vm.load(USDT, bytes32(uint256(4)))), usdt.maximumFee(), "slot 4 is maximumFee");
        assertEq(uint256(vm.load(USDT, bytes32(uint256(9)))), 6, "slot 9 is decimals");
        assertEq(usdt.basisPointsRate(), 0, "no transfer fee today");
        assertFalse(usdt.paused());
        assertFalse(usdt.deprecated());

        assertEq(IChainlinkRounds(USDT_USD).decimals(), 8);
        assertEq(IChainlinkRounds(USDT_USD).description(), "USDT / USD");

        (address pool, uint256 minimum,,) = IEntrypointUsdt(ENTRYPOINT).assetConfig(USDT);
        assertEq(pool, USDT_POOL, "0xbow routes USDT deposits to this pool");
        assertEq(IPoolView(USDT_POOL).ASSET(), USDT);
        assertFalse(IPoolView(USDT_POOL).dead(), "the pool accepts deposits");
        assertEq(minimum, 25e6, "minimum shielded deposit: 25 USDT");
        assertFalse(usdt.isBlackListed(ENTRYPOINT) || usdt.isBlackListed(USDT_POOL));
    }

    /// Our contract reads the real feed - no access gate, unlike the retired BRL/USD proxy in
    /// OracleFork.t.sol (the live one has none either: ChainlinkFxFork.t.sol) - and the cross
    /// lands on a plausible R$ per USDT.
    function test_TheOracleReadsTheRealFeedAndPricesUsdtInCentavos() public view {
        if (!live) return;
        (uint256 price, uint64 at) = oracle.brlCentsPerUnit();
        (, int256 answer,,,) = IChainlinkRounds(USDT_USD).latestRoundData();
        console2.log("USDT/USD answer (8dp):", uint256(answer));
        console2.log("centavos per USDT at R$5.40/USD:", price);
        assertEq(price, (uint256(answer) * FX_CENTS + 5e7) / 1e8, "the cross, by hand");
        assertEq(at, uint64(block.timestamp), "reported freshness is the signed rate's");
        // Within 5% of the peg: a larger gap means USDT has depegged, and someone should look.
        assertApproxEqRel(price, FX_CENTS, 0.05e18, "R$ per USDT near R$ per USD");
    }

    /**
     * The on-chain reason `updatedAt` is the FX leg's time. The feed's normal cadence is its
     * heartbeat, and that is longer than the one hour the escrows accept: a cross reporting its
     * older leg would be refused most of the day. And every interval fits inside the max age
     * this deployment uses, so the leg is not refused while Chainlink is healthy.
     */
    function test_TheFeedsCadenceIsLongerThanTheEscrowsPriceWindow() public view {
        if (!live) return;
        (uint80 id,,, uint256 prev,) = IChainlinkRounds(USDT_USD).latestRoundData();
        console2.log("USDT/USD latest answer age (s):", block.timestamp - prev);
        uint256 longest;
        for (uint80 i = 1; i <= 6; ++i) {
            (,,, uint256 at,) = IChainlinkRounds(USDT_USD).getRoundData(id - i);
            uint256 gap = prev - at;
            console2.log("  interval (s):", gap);
            assertLe(gap, oracle.assetMaxAge(), "an interval longer than the leg's max age");
            if (gap > longest) longest = gap;
            prev = at;
        }
        assertGt(longest, onramp.MAX_PRICE_AGE(), "the feed updates less often than the escrow's price window");
    }

    /**
     * On-ramp, shielded: the LP escrows USDT, the taker locks and pays, two attestors sign, and
     * the USDT is deposited into 0xbow's USDT pool as a commitment to the taker's precommitment.
     */
    function test_OnRamp_UsdtLandsInTheRealPoolAsTheTakersCommitment() public {
        if (!live) return;
        bytes32 offerId = _post(lp, 1_000e6);
        assertEq(usdt.balanceOf(address(onramp)), 1_000e6, "the escrow holds the LP's USDT");

        (bytes32 orderId, uint256 precommitment) = _lock(offerId, 100e6, FiatEscrow.Delivery.SHIELDED);
        uint256 cents = _orderCents(orderId);
        assertEq(cents, 100 * _mid(), "100 USDT at the quoted centavos per whole USDT");

        uint256 poolBefore = usdt.balanceOf(USDT_POOL);
        bytes memory proof = _proof(orderId, cents, LP_PIX);
        vm.recordLogs();
        vm.prank(makeAddr("relayer")); // anyone may submit; the destination was fixed at lock
        onramp.releaseWithProof(orderId, proof);
        Vm.Log[] memory logs = vm.getRecordedLogs();

        bool found;
        uint256 commitment;
        uint256 label;
        for (uint256 i; i < logs.length; ++i) {
            if (
                logs[i].emitter == USDT_POOL
                    && logs[i].topics[0] == keccak256("Deposited(address,uint256,uint256,uint256,uint256)")
            ) {
                uint256 value;
                uint256 pre;
                (commitment, label, value, pre) = abi.decode(logs[i].data, (uint256, uint256, uint256, uint256));
                assertEq(address(uint160(uint256(logs[i].topics[1]))), address(onramp), "escrow is depositor of record");
                assertEq(value, 100e6, "no vetting fee on the USDT pool: the full amount is shielded");
                assertEq(pre, precommitment, "the commitment is to the taker's precommitment");
                found = true;
            }
        }
        assertTrue(found, "the real USDT pool emitted Deposited");
        assertEq(usdt.balanceOf(USDT_POOL) - poolBefore, 100e6, "the pool holds the USDT");
        assertEq(usdt.balanceOf(address(onramp)), 900e6);
        assertEq(uint256(_orderState(orderId)), uint256(FiatEscrow.OrderState.RELEASED));
        (,,,,,,,,,, uint256 recorded) = onramp.orders(orderId);
        assertEq(recorded, commitment, "the escrow recorded the pool's commitment");
        assertEq(onramp.labelOfOrder(orderId), label, "and the pool's label");
        // orderForLabel, the reverse index rescue routes by, is internal (FiatEscrow size); the rescue below uses it.
        assertEq(IPoolView(USDT_POOL).depositors(label), address(onramp));
        assertEq(usdt.allowance(address(onramp), ENTRYPOINT), 0, "no allowance left standing");
        (, uint256 settled,,,,,) = registry.lps(lp);
        assertEq(settled, cents, "the settlement built the LP's reputation");
        assertEq(_onrampOwes(offerId), usdt.balanceOf(address(onramp)), "books equal balance");
    }

    function test_OnRamp_DirectDeliveryPaysTheTakersAddress() public {
        if (!live) return;
        bytes32 offerId = _post(lp, 1_000e6);
        (bytes32 orderId,) = _lock(offerId, 250e6, FiatEscrow.Delivery.DIRECT);
        uint256 before = usdt.balanceOf(payout);
        onramp.releaseWithProof(orderId, _proof(orderId, _orderCents(orderId), LP_PIX));
        assertEq(usdt.balanceOf(payout) - before, 250e6);
        assertEq(_onrampOwes(offerId), usdt.balanceOf(address(onramp)), "books equal balance");
    }

    /// Off-ramp: the seller escrows USDT, an LP claims and pays the seller's PIX key, and
    /// collects the USDT.
    function test_OffRamp_SellerEscrowsUsdtAndTheLpCollectsIt() public {
        if (!live) return;
        bytes32 saleId = _open(200e6);
        assertEq(usdt.balanceOf(address(offramp)), 200e6);
        vm.prank(lp);
        offramp.claimSale(saleId);
        uint256 before = usdt.balanceOf(lp);
        offramp.settleWithProof(saleId, _proof(saleId, _saleCents(saleId), SELLER_PIX));
        assertEq(usdt.balanceOf(lp) - before, 200e6, "the LP paid BRL and holds the USDT");
        assertEq(usdt.balanceOf(address(offramp)), 0);
        assertEq(uint256(_saleState(saleId)), uint256(OffRampEscrow.SaleState.SETTLED));
    }

    /// An unpaid order expires (anyone reclaims it) and the LP withdraws every unit it escrowed.
    function test_OnRamp_AnUnpaidOrderExpiresAndTheLpWithdrawsEverything() public {
        if (!live) return;
        uint256 start = usdt.balanceOf(lp);
        bytes32 offerId = _post(lp, 1_000e6);
        (bytes32 orderId,) = _lock(offerId, 400e6, FiatEscrow.Delivery.SHIELDED);
        vm.warp(block.timestamp + onramp.PAY_WINDOW() + 1);
        vm.prank(makeAddr("stranger"));
        onramp.reclaimExpired(orderId);
        vm.prank(lp);
        onramp.closeOffer(offerId);
        assertEq(usdt.balanceOf(lp), start, "every unit back");
        assertEq(usdt.balanceOf(address(onramp)), 0);
        assertEq(registry.reservedBy(address(onramp), lp), 0, "and all of the LP's credit");
    }

    /// A stale claim clears; the seller cancels; a disputed sale nobody rules on expires to the
    /// seller's refund address after DISPUTE_TIMEOUT. All in USDT.
    function test_OffRamp_StaleClaimsCancelsAndTimeoutsRefundTheSeller() public {
        if (!live) return;
        bytes32 stale = _open(100e6);
        bytes32 disputed = _open(300e6);
        vm.startPrank(lp);
        offramp.claimSale(stale);
        offramp.claimSale(disputed);
        vm.stopPrank();
        vm.prank(seller);
        offramp.raiseDispute(disputed, "no PIX arrived");

        vm.warp(block.timestamp + offramp.PAY_WINDOW() + 1);
        offramp.releaseStaleClaim(stale);
        vm.prank(seller);
        offramp.cancelSale(stale);
        assertEq(usdt.balanceOf(refund), 100e6);

        vm.warp(block.timestamp + DISPUTE_TIMEOUT);
        vm.prank(makeAddr("stranger"));
        offramp.expireDispute(disputed);
        assertEq(usdt.balanceOf(refund), 400e6, "refund to origin, in USDT");
        assertEq(usdt.balanceOf(address(offramp)), 0);
        assertEq(registry.reservedBy(address(offramp), lp), 0);
    }

    /**
     * A depeg reaches the band through the feed. The proxy's answer is replaced with $0.94 at
     * the current time (a simulated depeg; the real feed is at the peg), and an offer quoted at
     * the peg can no longer be locked.
     */
    function test_ADepegOnTheFeedRefusesOffersQuotedAtThePeg() public {
        if (!live) return;
        bytes32 offerId = _post(lp, 1_000e6);
        (uint80 id,,,,) = IChainlinkRounds(USDT_USD).latestRoundData();
        vm.mockCall(
            USDT_USD,
            abi.encodeWithSelector(IChainlinkRounds.latestRoundData.selector),
            abi.encode(id + 1, int256(94_000_000), block.timestamp, block.timestamp, id + 1)
        );
        assertEq(_mid(), 508, "0.94 x 540 = 507.6 -> 508");
        vm.expectRevert(FiatEscrow.PriceOutsideBand.selector);
        _lock(offerId, 100e6, FiatEscrow.Delivery.DIRECT);
    }

    /**
     * The pool's minimum. A SHIELDED order under 25 USDT used to lock - the escrow did not read the
     * pool's minimum - and then could never settle, while the taker paid (SR2-27). The escrow now
     * reads it at lock and refuses. The minimum can still move afterwards: 0xbow's owner raises it
     * with `updatePoolConfiguration`, the paid order's shielded release reverts, and the taker's
     * rescue address takes the delivery directly instead of losing it.
     */
    function test_APoolMinimumIsEnforcedAtLock_AndARaiseAfterLockIsEscaped() public {
        if (!live) return;
        bytes32 offerId = _post(lp, 1_000e6);
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.BelowPoolMinimum.selector, 25e6));
        _lock(offerId, 10e6, FiatEscrow.Delivery.SHIELDED);

        // The cause, from the Entrypoint directly.
        vm.startPrank(taker);
        usdt.approve(ENTRYPOINT, 10e6);
        vm.expectRevert(bytes4(keccak256("MinimumDepositAmount()")));
        IEntrypointUsdt(ENTRYPOINT).deposit(USDT, 10e6, 12345);
        vm.stopPrank();

        (bytes32 orderId,) = _lock(offerId, 30e6, FiatEscrow.Delivery.SHIELDED);
        bytes memory proof = _proof(orderId, _orderCents(orderId), LP_PIX);
        assertTrue(IEntrypointUsdt(ENTRYPOINT).hasRole(keccak256("OWNER_ROLE"), EP_OWNER), "0xbow's owner, on-chain");
        (, , uint256 fee, uint256 maxRelay) = IEntrypointUsdt(ENTRYPOINT).assetConfig(USDT);
        vm.prank(EP_OWNER);
        IEntrypointUsdt(ENTRYPOINT).updatePoolConfiguration(USDT, 50e6, fee, maxRelay);
        vm.expectRevert(FiatEscrow.TransferFailed.selector);
        onramp.releaseWithProof(orderId, proof);

        uint256 before = usdt.balanceOf(payout);
        vm.prank(payout); // the rescue address named at lock
        onramp.takeDeliveryDirect(orderId);
        onramp.releaseWithProof(orderId, proof);
        assertEq(usdt.balanceOf(payout) - before, 30e6, "the paid taker has the USDT, in the open");
    }
}

/**
 * What Tether can do to the token, and what each does to our escrows.
 *
 * Every power used here is the real token's own: the owner's `setParams`, `pause`,
 * `addBlackList`, `destroyBlackFunds` and `deprecate`, pranked from the real owner. The one
 * exception is a transfer fee above the owner's own cap, written to storage directly, to show
 * the escrows refuse any fee rather than only the ones Tether can currently switch on.
 *
 * The property that matters throughout: the escrows' books never disagree with their balance
 * because of something the token did during a call. Either a call moves exactly what the
 * books say, or it reverts and moves nothing.
 */
contract UsdtFailureModesForkTest is UsdtForkBase {
    /*//////////////////////////////////////////////////////////////
                              TRANSFER FEE
    //////////////////////////////////////////////////////////////*/

    /// Tether's owner can switch on at most 19 bps, capped at 49 USDT per transfer.
    function test_Fee_TetherCapsWhatItsOwnerCanSwitchOn() public {
        if (!live) return;
        address owner = usdt.owner();
        vm.startPrank(owner);
        vm.expectRevert();
        usdt.setParams(20, 0);
        vm.expectRevert();
        usdt.setParams(0, 50);
        usdt.setParams(19, 49);
        vm.stopPrank();
        assertEq(usdt.basisPointsRate(), 19);
        assertEq(usdt.maximumFee(), 49e6, "the cap is in whole USDT");
    }

    /// With a fee on, nothing enters either escrow: the intake measures what arrived.
    function test_Fee_OnIntake_BothEscrowsRefuseCleanly() public {
        if (!live) return;
        bytes32 offerId = _post(lp, 1_000e6); // before the fee, to test top-ups too
        _asTether(abi.encodeCall(ITetherToken.setParams, (19, 49)));
        uint256 mid = _mid();

        vm.startPrank(lp2);
        usdt.approve(address(onramp), 1_000e6);
        // 1,000 USDT x 19 bps = 1.9 USDT kept by Tether.
        vm.expectRevert(abi.encodeWithSelector(SafeTransferLib.UnexpectedAmountReceived.selector, 1_000e6, 998.1e6));
        onramp.postOffer(USDT, 1_000e6, mid, LP_PIX, 1e6, 1_000e6, address(zktls), PIX_MASK);
        vm.stopPrank();

        vm.startPrank(lp);
        usdt.approve(address(onramp), 500e6);
        vm.expectRevert(abi.encodeWithSelector(SafeTransferLib.UnexpectedAmountReceived.selector, 500e6, 499.05e6));
        onramp.fundOffer(offerId, 500e6);
        vm.stopPrank();

        vm.startPrank(seller);
        usdt.approve(address(offramp), 100e6);
        vm.expectRevert(abi.encodeWithSelector(SafeTransferLib.UnexpectedAmountReceived.selector, 100e6, 99.81e6));
        offramp.openSale(USDT, 100e6, 100 * mid, SELLER_PIX, address(zktls), PIX_MASK, refund);
        vm.stopPrank();

        // Beyond anything setParams allows: 1% with no cap, written to storage.
        vm.store(USDT, bytes32(uint256(3)), bytes32(uint256(100)));
        vm.store(USDT, bytes32(uint256(4)), bytes32(type(uint256).max));
        vm.startPrank(lp2);
        vm.expectRevert(abi.encodeWithSelector(SafeTransferLib.UnexpectedAmountReceived.selector, 1_000e6, 990e6));
        onramp.postOffer(USDT, 1_000e6, mid, LP_PIX, 1e6, 1_000e6, address(zktls), PIX_MASK);
        vm.stopPrank();

        assertEq(usdt.balanceOf(address(onramp)), 1_000e6, "only the pre-fee offer is held");
        assertEq(_onrampOwes(offerId), 1_000e6, "and the books did not move");
        assertEq(usdt.balanceOf(address(offramp)), 0);
        assertEq(registry.reservedBy(address(onramp), lp2), 0, "no credit reserved for the refused offer");
    }

    /**
     * A fee switched on while USDT is already escrowed. Payouts still leave, the books still
     * match the balance, and the RECIPIENT bears Tether's cut - as on any USDT transfer. A
     * shielded delivery cannot settle while the fee is on (the Entrypoint forwards more than it
     * received and the pool's pull fails), reverts whole, and settles once the fee is off.
     */
    function test_Fee_SwitchedOnWhileEscrowed_PayoutsBalanceAndShieldedWaits() public {
        if (!live) return;
        bytes32 offerId = _post(lp, 1_000e6);
        (bytes32 direct,) = _lock(offerId, 100e6, FiatEscrow.Delivery.DIRECT);
        (bytes32 shielded,) = _lock(offerId, 100e6, FiatEscrow.Delivery.SHIELDED);
        bytes32 saleId = _open(100e6);
        vm.prank(lp2);
        offramp.claimSale(saleId);

        _asTether(abi.encodeCall(ITetherToken.setParams, (19, 49)));
        assertEq(usdt.balanceOf(ENTRYPOINT), 0, "the Entrypoint holds no USDT to cover a shortfall");

        uint256 before = usdt.balanceOf(payout);
        onramp.releaseWithProof(direct, _proof(direct, _orderCents(direct), LP_PIX));
        assertEq(usdt.balanceOf(payout) - before, 99.81e6, "the taker receives 100 less Tether's 19 bps");
        assertEq(_onrampOwes(offerId), usdt.balanceOf(address(onramp)), "books equal balance after a fee payout");

        bytes memory proof = _proof(shielded, _orderCents(shielded), LP_PIX);
        vm.expectRevert(FiatEscrow.TransferFailed.selector);
        onramp.releaseWithProof(shielded, proof);
        assertEq(uint256(_orderState(shielded)), uint256(FiatEscrow.OrderState.LOCKED), "reverted whole");
        assertEq(_onrampOwes(offerId), usdt.balanceOf(address(onramp)));

        before = usdt.balanceOf(lp2);
        offramp.settleWithProof(saleId, _proof(saleId, _saleCents(saleId), SELLER_PIX));
        assertEq(usdt.balanceOf(lp2) - before, 99.81e6, "the off-ramp LP bears the fee on collection");
        assertEq(usdt.balanceOf(address(offramp)), 0);

        _asTether(abi.encodeCall(ITetherToken.setParams, (0, 0)));
        onramp.releaseWithProof(shielded, proof);
        assertEq(uint256(_orderState(shielded)), uint256(FiatEscrow.OrderState.RELEASED), "settles once the fee is off");

        _asTether(abi.encodeCall(ITetherToken.setParams, (19, 49)));
        before = usdt.balanceOf(lp);
        vm.prank(lp);
        onramp.closeOffer(offerId);
        // 800 USDT x 19 bps = 1.52 USDT, under the 49 USDT cap.
        assertEq(usdt.balanceOf(lp) - before, 798.48e6);
        assertEq(usdt.balanceOf(address(onramp)), 0, "the escrow paid out exactly what its books held");
    }

    /*//////////////////////////////////////////////////////////////
                                 PAUSE
    //////////////////////////////////////////////////////////////*/

    /**
     * A pause stops every USDT movement and nothing else. Calls that would move USDT revert
     * whole; bookkeeping that moves none - locking, disputing, claiming, posting a ruling -
     * carries on; and after the unpause every path resumes. A taker who paid during the pause
     * is carried across it by a dispute, whose RELEASE executes once USDT moves again.
     */
    function test_Pause_FreezesMovementNotBookkeeping_AndADisputeCarriesAPaidTaker() public {
        if (!live) return;
        bytes32 offerId = _post(lp, 1_000e6);
        bytes32 openSale = _open(100e6);
        vm.prank(lp2);
        usdt.approve(address(onramp), 1_000e6);

        _asTether(abi.encodeWithSignature("pause()"));
        assertTrue(usdt.paused());

        uint256 mid = _mid();
        vm.prank(lp2);
        vm.expectRevert(abi.encodeWithSelector(SafeTransferLib.TransferFromFailed.selector, USDT, lp2, 1_000e6));
        onramp.postOffer(USDT, 1_000e6, mid, LP_PIX, 1e6, 1_000e6, address(zktls), PIX_MASK);
        vm.prank(seller);
        vm.expectRevert(abi.encodeWithSelector(SafeTransferLib.TransferFailed.selector, USDT, refund, 100e6));
        offramp.cancelSale(openSale);
        vm.prank(lp);
        vm.expectRevert(abi.encodeWithSelector(SafeTransferLib.TransferFailed.selector, USDT, lp, 1_000e6));
        onramp.closeOffer(offerId);

        // Bookkeeping continues.
        (bytes32 orderId,) = _lock(offerId, 100e6, FiatEscrow.Delivery.DIRECT);
        vm.prank(lp2);
        offramp.claimSale(openSale);

        // The taker pays; the release cannot move USDT.
        bytes memory proof = _proof(orderId, _orderCents(orderId), LP_PIX);
        vm.expectRevert(abi.encodeWithSelector(SafeTransferLib.TransferFailed.selector, USDT, payout, 100e6));
        onramp.releaseWithProof(orderId, proof);

        // The pay window runs out during the pause. The dispute, raised in time, keeps the
        // order from expiring back to the LP.
        vm.prank(taker);
        onramp.raiseDispute(orderId, "paid; release blocked by the USDT pause");
        (RulingLib.Ruling memory r, bytes memory sig) = _ruling(address(onramp), orderId, "RELEASE");
        onramp.resolveDispute(orderId, r, sig); // posted, while paused
        vm.warp(block.timestamp + 1 days);
        vm.expectRevert(abi.encodeWithSelector(SafeTransferLib.TransferFailed.selector, USDT, payout, 100e6));
        onramp.resolveDispute(orderId, r, sig);

        _asTether(abi.encodeWithSignature("unpause()"));
        onramp.resolveDispute(orderId, r, sig);
        assertEq(usdt.balanceOf(payout), 10_000e6 + 100e6, "delivered after the unpause");
        assertEq(_onrampOwes(offerId), usdt.balanceOf(address(onramp)), "books equal balance");
    }

    /**
     * A pause longer than the dispute timeout. The on-ramp timeout moves no USDT, so it
     * applies during the pause: the order returns to the LP's offer and a taker who paid loses
     * the trade (refund to origin). The off-ramp timeout pays the seller, so it waits for the
     * unpause - and then refunds.
     */
    function test_Pause_OutlastingTheDisputeTimeoutRefundsToOrigin() public {
        if (!live) return;
        bytes32 offerId = _post(lp, 1_000e6);
        (bytes32 orderId,) = _lock(offerId, 100e6, FiatEscrow.Delivery.DIRECT);
        bytes32 saleId = _open(100e6);
        vm.prank(lp2);
        offramp.claimSale(saleId);
        vm.prank(taker);
        onramp.raiseDispute(orderId, "paid");
        vm.prank(lp2);
        offramp.raiseDispute(saleId, "paid");

        _asTether(abi.encodeWithSignature("pause()"));
        vm.warp(block.timestamp + DISPUTE_TIMEOUT);
        onramp.expireDispute(orderId);
        assertEq(_onrampOwes(offerId), 1_000e6, "back on the LP's offer");
        vm.expectRevert(abi.encodeWithSelector(SafeTransferLib.TransferFailed.selector, USDT, refund, 100e6));
        offramp.expireDispute(saleId);

        _asTether(abi.encodeWithSignature("unpause()"));
        offramp.expireDispute(saleId);
        assertEq(usdt.balanceOf(refund), 100e6);
    }

    /*//////////////////////////////////////////////////////////////
                               BLACKLIST
    //////////////////////////////////////////////////////////////*/

    /// Tether checks the SENDER. A blacklisted LP or seller cannot put USDT into an escrow.
    function test_Blacklist_AListedLpOrSellerCannotEscrow() public {
        if (!live) return;
        uint256 mid = _mid();
        _asTether(abi.encodeCall(ITetherToken.addBlackList, (lp2)));
        _asTether(abi.encodeCall(ITetherToken.addBlackList, (seller)));

        vm.startPrank(lp2);
        usdt.approve(address(onramp), 1_000e6);
        vm.expectRevert(abi.encodeWithSelector(SafeTransferLib.TransferFromFailed.selector, USDT, lp2, 1_000e6));
        onramp.postOffer(USDT, 1_000e6, mid, LP_PIX, 1e6, 1_000e6, address(zktls), PIX_MASK);
        vm.stopPrank();

        vm.startPrank(seller);
        usdt.approve(address(offramp), 100e6);
        vm.expectRevert(abi.encodeWithSelector(SafeTransferLib.TransferFromFailed.selector, USDT, seller, 100e6));
        offramp.openSale(USDT, 100e6, 100 * mid, SELLER_PIX, address(zktls), PIX_MASK, refund);
        vm.stopPrank();
    }

    /**
     * Tether does NOT check the recipient. Blacklisting an LP, taker, seller or refund address
     * after USDT is escrowed strands nothing in the escrow: every payout still leaves, to an
     * address that can then not move it - and that Tether can zero with destroyBlackFunds. What
     * changed (SR2-24): nothing NEW starts with a listed party. A listed LP's live offer no longer
     * sells, a listed LP cannot claim a sale, and a listed refund address cannot open one.
     */
    function test_Blacklist_ListedCounterpartiesStillGetPaid_ButStartNothingNew() public {
        if (!live) return;
        bytes32 offerId = _post(lp, 1_000e6);
        (bytes32 orderId,) = _lock(offerId, 100e6, FiatEscrow.Delivery.DIRECT);
        bytes32 cancelled = _open(100e6);
        bytes32 settled = _open(200e6);
        bytes32 unclaimed = _open(50e6);
        vm.prank(lp2);
        offramp.claimSale(settled);

        for (uint256 i; i < 5; ++i) {
            _asTether(abi.encodeCall(ITetherToken.addBlackList, ([lp, lp2, payout, seller, refund][i])));
        }

        uint256 before = usdt.balanceOf(payout);
        onramp.releaseWithProof(orderId, _proof(orderId, _orderCents(orderId), LP_PIX));
        assertEq(usdt.balanceOf(payout) - before, 100e6, "paid to a blacklisted recipient");
        // A listed LP's offer no longer sells, to a listed recipient or to anyone else.
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.FrozenByAssetIssuer.selector, lp));
        _lock(offerId, 100e6, FiatEscrow.Delivery.DIRECT);
        vm.prank(lp);
        onramp.closeOffer(offerId);
        assertEq(usdt.balanceOf(address(onramp)), 0, "nothing left behind in the on-ramp");

        vm.prank(seller);
        offramp.cancelSale(cancelled);
        offramp.settleWithProof(settled, _proof(settled, _saleCents(settled), SELLER_PIX));
        assertEq(usdt.balanceOf(refund), 100e6);

        // Nothing new with a listed party: a listed LP claims nothing, a listed refund address sells nothing.
        vm.prank(lp2);
        vm.expectRevert(abi.encodeWithSelector(OffRampEscrow.FrozenByAssetIssuer.selector, lp2));
        offramp.claimSale(unclaimed);
        uint256 cents = (50e6 * _mid()) / 1e6;
        vm.prank(seller);
        vm.expectRevert(abi.encodeWithSelector(OffRampEscrow.FrozenByAssetIssuer.selector, refund));
        offramp.openSale(USDT, 50e6, cents, SELLER_PIX, address(zktls), PIX_MASK, refund);
        vm.prank(seller);
        offramp.cancelSale(unclaimed);
        assertEq(usdt.balanceOf(refund), 150e6);
        assertEq(usdt.balanceOf(address(offramp)), 0, "nothing left behind in the off-ramp");

        // Frozen where it landed, and burnable there.
        vm.prank(payout);
        vm.expectRevert();
        usdt.transfer(taker, 1);
        _asTether(abi.encodeCall(ITetherToken.destroyBlackFunds, (payout)));
        assertEq(usdt.balanceOf(payout), 0, "Tether destroyed the recipient's USDT");
    }

    /**
     * The escrow itself blacklisted: the failure with no way out for what is already in it. Every
     * payout and every shielded delivery reverts, for every LP and seller on that escrow at once,
     * and destroyBlackFunds zeroes the balance while the books still record it. Unlisting after a
     * burn does not help: the escrow holds nothing to pay with. The escrows have no sweep and
     * should not have one - it would be a governor withdrawal. What is bounded now (SR2-25): the
     * escrow takes no new USDT, locks no new order and admits no new claim once listed, and
     * `assetCap` limits what it can hold in the first place.
     */
    function test_Blacklist_TheEscrowItself_FreezesEveryPositionWithNoPathOut() public {
        if (!live) return;
        bytes32 offerId = _post(lp, 1_000e6);
        (bytes32 direct,) = _lock(offerId, 100e6, FiatEscrow.Delivery.DIRECT);
        (bytes32 shielded,) = _lock(offerId, 100e6, FiatEscrow.Delivery.SHIELDED);
        bytes32 saleId = _open(100e6);

        _asTether(abi.encodeCall(ITetherToken.addBlackList, (address(onramp))));
        _asTether(abi.encodeCall(ITetherToken.addBlackList, (address(offramp))));

        // What changed: the frozen pile no longer grows. No new offer, order, sale or claim.
        uint256 mid = _mid();
        vm.startPrank(lp2);
        usdt.approve(address(onramp), 100e6);
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.FrozenByAssetIssuer.selector, address(onramp)));
        onramp.postOffer(USDT, 100e6, mid, LP_PIX, 1e6, 100e6, address(zktls), PIX_MASK);
        vm.stopPrank();
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.FrozenByAssetIssuer.selector, address(onramp)));
        _lock(offerId, 100e6, FiatEscrow.Delivery.DIRECT);
        vm.startPrank(seller);
        usdt.approve(address(offramp), 100e6);
        vm.expectRevert(abi.encodeWithSelector(OffRampEscrow.FrozenByAssetIssuer.selector, address(offramp)));
        offramp.openSale(USDT, 100e6, 100 * mid, SELLER_PIX, address(zktls), PIX_MASK, refund);
        vm.stopPrank();
        vm.prank(lp2);
        vm.expectRevert(abi.encodeWithSelector(OffRampEscrow.FrozenByAssetIssuer.selector, address(offramp)));
        offramp.claimSale(saleId);

        bytes memory directProof = _proof(direct, _orderCents(direct), LP_PIX);
        vm.expectRevert(abi.encodeWithSelector(SafeTransferLib.TransferFailed.selector, USDT, payout, 100e6));
        onramp.releaseWithProof(direct, directProof);
        bytes memory shieldedProof = _proof(shielded, _orderCents(shielded), LP_PIX);
        vm.expectRevert(FiatEscrow.TransferFailed.selector);
        onramp.releaseWithProof(shielded, shieldedProof);
        vm.prank(lp);
        vm.expectRevert(abi.encodeWithSelector(SafeTransferLib.TransferFailed.selector, USDT, lp, 800e6));
        onramp.closeOffer(offerId);
        vm.prank(seller);
        vm.expectRevert(abi.encodeWithSelector(SafeTransferLib.TransferFailed.selector, USDT, refund, 100e6));
        offramp.cancelSale(saleId);

        _asTether(abi.encodeCall(ITetherToken.destroyBlackFunds, (address(onramp))));
        assertEq(usdt.balanceOf(address(onramp)), 0, "Tether burned every LP's USDT in the escrow");
        assertEq(_onrampOwes(offerId), 1_000e6, "while the books still owe it");
        _asTether(abi.encodeCall(ITetherToken.removeBlackList, (address(onramp))));
        vm.prank(lp);
        vm.expectRevert(abi.encodeWithSelector(SafeTransferLib.TransferFailed.selector, USDT, lp, 800e6));
        onramp.closeOffer(offerId);
    }

    /**
     * Shielded delivery depends on the Entrypoint, which is the SENDER of the pool's pull, so
     * listing it stops shielded delivery. A taker who had paid used to have only the dispute path,
     * whose RELEASE delivered the same way and failed the same way, and the timeout returned the
     * USDT to the LP (SR2-26). Now no new shielded order locks while it is listed, and a paid one is
     * taken directly by its rescue address - after a proven payment, or through a RELEASE ruling.
     * Direct delivery is unaffected throughout.
     */
    function test_Blacklist_TheEntrypointStopsShieldedDelivery_AndAPaidTakerTakesItDirect() public {
        if (!live) return;
        bytes32 offerId = _post(lp, 1_000e6);
        (bytes32 direct,) = _lock(offerId, 100e6, FiatEscrow.Delivery.DIRECT);
        (bytes32 proven,) = _lock(offerId, 100e6, FiatEscrow.Delivery.SHIELDED);
        (bytes32 ruled,) = _lock(offerId, 100e6, FiatEscrow.Delivery.SHIELDED);

        _asTether(abi.encodeCall(ITetherToken.addBlackList, (ENTRYPOINT)));
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.FrozenByAssetIssuer.selector, ENTRYPOINT));
        _lock(offerId, 100e6, FiatEscrow.Delivery.SHIELDED);

        uint256 before = usdt.balanceOf(payout);
        bytes memory proof = _proof(proven, _orderCents(proven), LP_PIX);
        vm.expectRevert(FiatEscrow.TransferFailed.selector);
        onramp.releaseWithProof(proven, proof);
        onramp.releaseWithProof(direct, _proof(direct, _orderCents(direct), LP_PIX));
        assertEq(usdt.balanceOf(payout) - before, 100e6, "direct delivery does not touch the Entrypoint");

        vm.prank(payout);
        onramp.takeDeliveryDirect(proven);
        onramp.releaseWithProof(proven, proof);
        assertEq(usdt.balanceOf(payout) - before, 200e6, "the paid shielded taker has the USDT, in the open");

        // The dispute path: a RELEASE ruling posted while shielded, executed after the switch.
        vm.prank(taker);
        onramp.raiseDispute(ruled, "paid; shielded delivery blocked");
        (RulingLib.Ruling memory r, bytes memory sig) = _ruling(address(onramp), ruled, "RELEASE");
        onramp.resolveDispute(ruled, r, sig);
        vm.warp(block.timestamp + 1 days);
        vm.prank(payout);
        onramp.takeDeliveryDirect(ruled);
        onramp.resolveDispute(ruled, r, sig);
        assertEq(usdt.balanceOf(payout) - before, 300e6, "and so does the one who had to dispute");
        assertEq(_onrampOwes(offerId), usdt.balanceOf(address(onramp)), "books equal balance");
    }

    /**
     * The pool is only a RECIPIENT on deposit, so listing it does not stop delivery: the USDT
     * lands. What stops is every transfer out of the pool - and withdrawals and ragequits both
     * pay by transfer from the pool (PrivacyPoolComplex._push), so every USDT note in it is
     * frozen, and `rescueShielded` cannot help, since it is a ragequit.
     */
    function test_Blacklist_ThePoolStillTakesDeliveriesButCanPayNobody() public {
        if (!live) return;
        bytes32 offerId = _post(lp, 1_000e6);
        (bytes32 orderId,) = _lock(offerId, 100e6, FiatEscrow.Delivery.SHIELDED);
        _asTether(abi.encodeCall(ITetherToken.addBlackList, (USDT_POOL)));
        onramp.releaseWithProof(orderId, _proof(orderId, _orderCents(orderId), LP_PIX));
        assertEq(uint256(_orderState(orderId)), uint256(FiatEscrow.OrderState.RELEASED), "delivered into a listed pool");
        // It still takes deliveries, so the escrow refuses to lock new orders into it.
        vm.expectRevert(abi.encodeWithSelector(FiatEscrow.FrozenByAssetIssuer.selector, USDT_POOL));
        _lock(offerId, 100e6, FiatEscrow.Delivery.SHIELDED);
        vm.prank(USDT_POOL);
        vm.expectRevert();
        usdt.transfer(taker, 1);
    }

    /*//////////////////////////////////////////////////////////////
                          APPROVE, DEPRECATE
    //////////////////////////////////////////////////////////////*/

    /**
     * USDT refuses to change a non-zero allowance to another non-zero value. The escrow approves
     * the Entrypoint for every shielded delivery, so without zeroing first the second delivery
     * would revert if anything were left over. SafeTransferLib zeroes first and resets after,
     * so back-to-back deliveries work and a planted stale allowance is harmless.
     */
    function test_ApproveToZero_ShieldedDeliveriesSurviveUsdtsApproveRule() public {
        if (!live) return;
        vm.startPrank(taker);
        usdt.approve(lp, 1);
        vm.expectRevert();
        usdt.approve(lp, 2);
        vm.stopPrank();

        bytes32 offerId = _post(lp, 1_000e6);
        (bytes32 first,) = _lock(offerId, 100e6, FiatEscrow.Delivery.SHIELDED);
        (bytes32 second,) = _lock(offerId, 100e6, FiatEscrow.Delivery.SHIELDED);
        (bytes32 third,) = _lock(offerId, 100e6, FiatEscrow.Delivery.SHIELDED);
        onramp.releaseWithProof(first, _proof(first, _orderCents(first), LP_PIX));
        onramp.releaseWithProof(second, _proof(second, _orderCents(second), LP_PIX));
        assertEq(usdt.allowance(address(onramp), ENTRYPOINT), 0);

        // allowed[escrow][entrypoint] is slot keccak(entrypoint, keccak(escrow, 5)).
        bytes32 slot = keccak256(abi.encode(ENTRYPOINT, keccak256(abi.encode(address(onramp), uint256(5)))));
        vm.store(USDT, slot, bytes32(uint256(1)));
        assertEq(usdt.allowance(address(onramp), ENTRYPOINT), 1, "a stale allowance is really there");
        onramp.releaseWithProof(third, _proof(third, _orderCents(third), LP_PIX));
        assertEq(uint256(_orderState(third)), uint256(FiatEscrow.OrderState.RELEASED));
        assertEq(usdt.allowance(address(onramp), ENTRYPOINT), 0, "and none after");

        // The LP's side of the same rule: an allowance left over from a partial post must be
        // zeroed by the client before approving again. The escrow cannot do that for it.
        vm.startPrank(lp);
        usdt.approve(address(onramp), 500e6);
        onramp.fundOffer(offerId, 200e6);
        vm.expectRevert();
        usdt.approve(address(onramp), 500e6);
        usdt.approve(address(onramp), 0);
        usdt.approve(address(onramp), 500e6);
        vm.stopPrank();
    }

    /**
     * `deprecate` forwards every call to another contract, whatever it does. Pointed at an
     * address with no code, every transfer and balance read reverts: the escrows freeze as
     * under a pause, move nothing and recover nothing until Tether points it somewhere working.
     * A working successor inherits the escrows' measured intake (a fee is still refused) and
     * the pinned decimals, and nothing else - see SR2-29.
     */
    function test_Deprecate_ToNothingFreezesTheEscrowsLikeAPause() public {
        if (!live) return;
        bytes32 offerId = _post(lp, 1_000e6);
        uint256 mid = _mid();
        vm.prank(lp2);
        usdt.approve(address(onramp), 1_000e6);
        _asTether(abi.encodeCall(ITetherToken.deprecate, (makeAddr("no code here"))));
        assertTrue(usdt.deprecated());

        vm.prank(lp2);
        vm.expectRevert(abi.encodeWithSelector(SafeTransferLib.TransferFromFailed.selector, USDT, lp2, 1_000e6));
        onramp.postOffer(USDT, 1_000e6, mid, LP_PIX, 1e6, 1_000e6, address(zktls), PIX_MASK);
        vm.prank(lp);
        vm.expectRevert(abi.encodeWithSelector(SafeTransferLib.TransferFailed.selector, USDT, lp, 1_000e6));
        onramp.closeOffer(offerId);
        assertEq(_onrampOwes(offerId), 1_000e6, "the books did not move");
    }
}
