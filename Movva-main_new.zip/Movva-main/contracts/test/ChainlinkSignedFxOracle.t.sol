// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Governed} from "./utils/Governed.sol";
import {MockUSD} from "./RampErc20.t.sol";
import {ChainlinkSignedFxOracle} from "../ramp/ChainlinkSignedFxOracle.sol";
import {IAggregatorV3} from "../ramp/ChainlinkBrlOracle.sol";
import {SignedPriceOracle} from "../ramp/SignedPriceOracle.sol";
import {FiatEscrow} from "../ramp/FiatEscrow.sol";
import {OffRampEscrow} from "../ramp/OffRampEscrow.sol";
import {LPRegistry} from "../ramp/LPRegistry.sol";
import {IAttestorVerifier} from "../ramp/IAttestorVerifier.sol";
import {IPriceOracle} from "../ramp/IPriceOracle.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";

/// A Chainlink proxy whose answer, timestamp and decimals the test sets.
contract FxTestFeed is IAggregatorV3 {
    int256 public answer;
    uint256 public at;
    uint8 public dec;

    constructor(int256 a, uint8 d) {
        (answer, dec, at) = (a, d, block.timestamp);
    }

    function set(int256 a, uint256 t) external {
        (answer, at) = (a, t);
    }

    function decimals() external view returns (uint8) {
        return dec;
    }

    function latestRoundData() external view returns (uint80, int256, uint256, uint256, uint80) {
        return (1, answer, at, at, 1);
    }
}

/// A leg that answers whatever its owner says: what a governor could point a cross at.
contract OwnedLeg is IPriceOracle {
    uint256 public price;

    constructor(uint256 p) {
        price = p;
    }

    function brlCentsPerUnit() external view returns (uint256, uint64) {
        return (price, uint64(block.timestamp));
    }
}

/**
 * The USDT/BRL band: a Chainlink USD leg times a signed FX leg.
 *
 * Numbers are worked by hand in the comments beside them, not produced by the contract - the
 * Phase 1 and SR2-9 bugs were each a formula and its fixture written from one assumption. The
 * same vectors are asserted in packages/ramp/test/price-publisher.test.ts against
 * `crossBrlCentsPerUnit`, so the TypeScript a publisher uses to predict the band cannot drift
 * from this contract unnoticed.
 */
contract ChainlinkSignedFxOracleTest is Governed {
    uint256 p1 = 0xF1;
    uint256 p2 = 0xF2;
    address governor = address(0x60F);

    SignedPriceOracle fx;
    FxTestFeed usdtUsd;
    ChainlinkSignedFxOracle oracle;

    uint64 constant USDT_MAX_AGE = 25 hours; // the mainnet feed's 24h heartbeat, plus an hour
    uint64 constant FX_MAX_AGE = 1 hours;
    uint64 seq;

    function setUp() public {
        vm.warp(1_800_000_000);
        address[] memory set = new address[](2);
        (set[0], set[1]) = (vm.addr(p1), vm.addr(p2));
        fx = new SignedPriceOracle(governor, DELAY, set, 2);
        usdtUsd = new FxTestFeed(99_972_163, 8); // $0.99972163, as the mainnet feed read on the fork
        oracle = new ChainlinkSignedFxOracle(address(usdtUsd), address(fx), USDT_MAX_AGE, FX_MAX_AGE, governor, DELAY);
        _completeSetup(address(fx));
        _completeSetup(address(oracle));
    }

    function _setLegs(address feed, address leg, uint64 feedAge, uint64 fxAge) internal pure returns (bytes memory) {
        return abi.encodeCall(ChainlinkSignedFxOracle.setLegs, (feed, leg, feedAge, fxAge));
    }

    function _publish(uint256 centsPerUsd) internal {
        _publishAt(centsPerUsd, uint64(block.timestamp));
    }

    function _publishAt(uint256 centsPerUsd, uint64 at) internal {
        ++seq;
        bytes32 d = fx.digest(centsPerUsd, at, seq);
        (uint256 lo, uint256 hi) = vm.addr(p1) < vm.addr(p2) ? (p1, p2) : (p2, p1);
        bytes[] memory sigs = new bytes[](2);
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(lo, d);
        sigs[0] = abi.encodePacked(r, s, v);
        (v, r, s) = vm.sign(hi, d);
        sigs[1] = abi.encodePacked(r, s, v);
        fx.submit(centsPerUsd, at, seq, sigs);
    }

    function _price() internal view returns (uint256 p) {
        (p,) = oracle.brlCentsPerUnit();
    }

    /*//////////////////////////////////////////////////////////////
                               THE CROSS
    //////////////////////////////////////////////////////////////*/

    /// 0.99972163 USD x 540 centavos/USD = 539.849 centavos -> 540 to the nearest centavo.
    function test_CrossesUsdtUsdWithTheSignedRate() public {
        _publish(540);
        assertEq(_price(), 540, "R$5.40 per USDT at a 0.9997 peg");
    }

    /// ETH/USD 2,483.68328680 (8dp) x 540 = 1,341,188.97 centavos -> 1,341,189.
    function test_TheSameFxLegPricesEthThroughItsOwnFeed() public {
        _publish(540);
        FxTestFeed ethUsd = new FxTestFeed(248_368_328_680, 8);
        ChainlinkSignedFxOracle eth =
            new ChainlinkSignedFxOracle(address(ethUsd), address(fx), 75 minutes, FX_MAX_AGE, governor, DELAY);
        _completeSetup(address(eth));
        (uint256 p,) = eth.brlCentsPerUnit();
        assertEq(p, 1_341_189, "one signed number serves both assets");
    }

    /// $0.01 x 250 = 2.5 centavos -> 3; $0.0099996 x 250 = 2.4999 -> 2. Nearest, half up.
    function test_RoundsToTheNearestCentavo() public {
        _publish(250);
        usdtUsd.set(1_000_000, block.timestamp);
        assertEq(_price(), 3, "half rounds up");
        usdtUsd.set(999_960, block.timestamp);
        assertEq(_price(), 2, "below half rounds down");
    }

    /// The feed's decimals are read, not assumed: $1 as 6, 8 and 18 decimals is R$5.40 each time.
    function test_UsesTheFeedsOwnDecimals() public {
        usdtUsd = new FxTestFeed(1e6, 6);
        _afterDelay(address(oracle), _setLegs(address(usdtUsd), address(fx), USDT_MAX_AGE, FX_MAX_AGE));
        usdtUsd.set(1e6, block.timestamp);
        _publish(540);
        assertEq(_price(), 540);
        usdtUsd = new FxTestFeed(1e18, 18);
        _afterDelay(address(oracle), _setLegs(address(usdtUsd), address(fx), USDT_MAX_AGE, FX_MAX_AGE));
        usdtUsd.set(1e18, block.timestamp);
        _publish(540);
        assertEq(_price(), 540);
    }

    /**
     * Direction, not arithmetic (SR2-9). A stronger dollar must make a USDT worth MORE reais,
     * and a depeg must make it worth fewer - by the depeg, since the FX leg did not move. A
     * formula that divided by the rate would fail both, whatever fixture it was checked with.
     */
    function test_AStrongerDollarRaisesTheBandAndADepegLowersIt() public {
        _publish(540);
        uint256 base = _price();
        _publish(600);
        assertGt(_price(), base, "more reais per dollar, more reais per USDT");
        assertEq(_price(), 600, "0.99972163 x 600 = 599.83 -> 600");

        usdtUsd.set(95_000_000, block.timestamp); // USDT at $0.95
        assertEq(_price(), 570, "0.95 x 600 = 570: the depeg reaches the band through Chainlink");
    }

    /*//////////////////////////////////////////////////////////////
                        EACH LEG, ITS OWN CLOCK
    //////////////////////////////////////////////////////////////*/

    /**
     * The design decision in one test. The mainnet USDT/USD feed updates once a day when the
     * peg holds, so its answer is routinely many hours old and still current. Reporting the
     * older leg would put that age in front of the escrow's one-hour MAX_PRICE_AGE and stop
     * USDT trading for most of the day. The FX leg's time is what is reported.
     */
    function test_ReportsTheFxLegsTimeWhileTheFeedIsWithinItsHeartbeat() public {
        usdtUsd.set(99_972_163, block.timestamp);
        vm.warp(block.timestamp + 23 hours);
        _publish(540);
        vm.warp(block.timestamp + 10 minutes);
        (uint256 p, uint64 at) = oracle.brlCentsPerUnit();
        assertEq(p, 540);
        assertEq(at, block.timestamp - 10 minutes, "the signed rate's publish time, not the feed's");
    }

    function test_AFeedPastItsOwnMaxAgeStopsThePrice() public {
        uint256 fedAt = block.timestamp;
        usdtUsd.set(99_972_163, fedAt);
        vm.warp(fedAt + USDT_MAX_AGE);
        _publish(540);
        assertEq(_price(), 540, "exactly at the max age is still accepted");
        vm.warp(block.timestamp + 1);
        _publish(540);
        vm.expectRevert(
            abi.encodeWithSelector(ChainlinkSignedFxOracle.StaleLeg.selector, address(usdtUsd), fedAt)
        );
        oracle.brlCentsPerUnit();
    }

    /// A healthy Chainlink leg cannot mask publishers who have gone quiet.
    function test_AFxRatePastItsMaxAgeStopsThePrice() public {
        _publish(540);
        uint256 publishedAt = block.timestamp;
        vm.warp(block.timestamp + FX_MAX_AGE + 1);
        usdtUsd.set(99_972_163, block.timestamp); // the feed is perfectly fresh
        vm.expectRevert(
            abi.encodeWithSelector(ChainlinkSignedFxOracle.StaleLeg.selector, address(fx), publishedAt)
        );
        oracle.brlCentsPerUnit();
    }

    /// Before any rate exists there is no price - the FX leg's own refusal reaches the caller.
    function test_NoFxRateYetMeansNoPrice() public {
        vm.expectRevert(SignedPriceOracle.NoPriceYet.selector);
        oracle.brlCentsPerUnit();
    }

    /// Freshness cannot be borrowed from the future. The oracle permits the same five minutes
    /// of clock skew SignedPriceOracle does, and no more.
    function test_AnFxTimestampFromTheFutureIsRefused() public {
        uint64 at = uint64(block.timestamp);
        _publishAt(540, at);
        vm.warp(at - 5 minutes);
        assertEq(_price(), 540, "five minutes of skew is tolerated");
        vm.warp(at - 5 minutes - 1);
        vm.expectRevert(abi.encodeWithSelector(ChainlinkSignedFxOracle.LegFromFuture.selector, address(fx), at));
        oracle.brlCentsPerUnit();
    }

    function test_ANonPositiveOrUnwrittenAnswerIsRefused() public {
        _publish(540);
        usdtUsd.set(0, block.timestamp);
        vm.expectRevert(abi.encodeWithSelector(ChainlinkSignedFxOracle.BadPrice.selector, address(usdtUsd), int256(0)));
        oracle.brlCentsPerUnit();
        usdtUsd.set(-1, block.timestamp);
        vm.expectRevert(abi.encodeWithSelector(ChainlinkSignedFxOracle.BadPrice.selector, address(usdtUsd), int256(-1)));
        oracle.brlCentsPerUnit();
        usdtUsd.set(1e8, 0); // a round that never completed
        vm.expectRevert(abi.encodeWithSelector(ChainlinkSignedFxOracle.StaleLeg.selector, address(usdtUsd), 0));
        oracle.brlCentsPerUnit();
    }

    function test_AFeedAskingForAnAbsurdPowerOfTenIsRefused() public {
        usdtUsd = new FxTestFeed(1e8, 77);
        _afterDelay(address(oracle), _setLegs(address(usdtUsd), address(fx), USDT_MAX_AGE, FX_MAX_AGE));
        usdtUsd.set(1e8, block.timestamp);
        _publish(540);
        vm.expectRevert(
            abi.encodeWithSelector(ChainlinkSignedFxOracle.FeedDecimalsOutOfRange.selector, address(usdtUsd), 77)
        );
        oracle.brlCentsPerUnit();
    }

    /// A price below half a centavo per token is no price: zero would make the band accept all.
    function test_APriceThatRoundsToZeroIsRefused() public {
        _publish(1);
        usdtUsd.set(1e7, block.timestamp); // $0.10 x 1 centavo = 0.1 centavo
        vm.expectRevert(ChainlinkSignedFxOracle.PriceRoundsToZero.selector);
        oracle.brlCentsPerUnit();
    }

    /*//////////////////////////////////////////////////////////////
                               GOVERNANCE
    //////////////////////////////////////////////////////////////*/

    function test_OnlyTheGovernorRepointsLegsOrHandsOver() public {
        vm.expectRevert(DelayedGovernance.NotGovernor.selector);
        oracle.setLegs(address(usdtUsd), address(fx), 1, 1);
        vm.expectRevert(DelayedGovernance.NotGovernor.selector);
        oracle.transferGovernor(address(this));

        vm.startPrank(governor);
        // Tightening takes the instant path, where a zero age is still refused.
        vm.expectRevert(ChainlinkSignedFxOracle.BadMaxAge.selector);
        oracle.setLegs(address(usdtUsd), address(fx), 0, 1);
        vm.expectRevert(ChainlinkSignedFxOracle.BadMaxAge.selector);
        oracle.setLegs(address(usdtUsd), address(fx), 1, 0);
        vm.expectEmit(address(oracle));
        emit ChainlinkSignedFxOracle.LegsSet(address(usdtUsd), address(fx), 2 hours, 30 minutes);
        oracle.setLegs(address(usdtUsd), address(fx), 2 hours, 30 minutes);
        vm.expectRevert(DelayedGovernance.ZeroAddress.selector);
        oracle.transferGovernor(address(0));
        oracle.transferGovernor(address(0xBEEF));
        vm.stopPrank();
        assertEq(oracle.governor(), address(0xBEEF));
        assertEq(oracle.assetMaxAge(), 2 hours);
        assertEq(oracle.fxMaxAge(), 30 minutes);
    }

    /// Repointing a leg is delayed, so a zero leg is refused where it would land: on execution.
    function test_AZeroLegIsRefusedThroughTheDelay() public {
        bytes[2] memory zero = [
            _setLegs(address(0), address(fx), USDT_MAX_AGE, FX_MAX_AGE),
            _setLegs(address(usdtUsd), address(0), USDT_MAX_AGE, FX_MAX_AGE)
        ];
        for (uint256 i; i < 2; ++i) {
            vm.prank(governor);
            oracle.schedule(zero[i]);
        }
        vm.warp(block.timestamp + DELAY);
        for (uint256 i; i < 2; ++i) {
            vm.prank(governor);
            vm.expectRevert(DelayedGovernance.ZeroAddress.selector);
            oracle.execute(zero[i]);
        }
    }

    /**
     * Each way `setLegs` can admit a price it would not have: a new feed, a new FX leg, or either
     * age lengthened - alone or mixed with a tightening. Tightening alone, or nothing changing, is
     * instant.
     */
    function test_RepointingOrLengtheningWaitsTighteningDoesNot() public {
        SignedPriceOracle otherLeg = new SignedPriceOracle(governor, DELAY, _one(), 1);
        FxTestFeed otherFeed = new FxTestFeed(1e8, 8);
        bytes[5] memory waits = [
            _setLegs(address(otherFeed), address(fx), USDT_MAX_AGE, FX_MAX_AGE),
            _setLegs(address(usdtUsd), address(otherLeg), USDT_MAX_AGE, FX_MAX_AGE),
            _setLegs(address(usdtUsd), address(fx), USDT_MAX_AGE + 1, FX_MAX_AGE),
            _setLegs(address(usdtUsd), address(fx), USDT_MAX_AGE, FX_MAX_AGE + 1),
            _setLegs(address(usdtUsd), address(fx), USDT_MAX_AGE - 1, FX_MAX_AGE + 1)
        ];
        for (uint256 i; i < waits.length; ++i) {
            vm.prank(governor);
            (bool ok, bytes memory ret) = address(oracle).call(waits[i]);
            assertFalse(ok, "a risk-increasing change went through without the delay");
            assertEq(ret, abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, ChainlinkSignedFxOracle.setLegs.selector));
        }
        vm.startPrank(governor);
        oracle.setLegs(address(usdtUsd), address(fx), USDT_MAX_AGE, FX_MAX_AGE); // unchanged
        oracle.setLegs(address(usdtUsd), address(fx), USDT_MAX_AGE - 1, FX_MAX_AGE - 1);
        vm.stopPrank();
        assertEq(oracle.assetMaxAge(), USDT_MAX_AGE - 1);

        _afterDelay(address(oracle), waits[4]);
        assertEq(oracle.assetMaxAge(), USDT_MAX_AGE - 1);
        assertEq(oracle.fxMaxAge(), FX_MAX_AGE + 1);
    }

    /**
     * The gap this closes, from the governor's side. Pointing the cross's FX leg at a contract it
     * controls would set the band to anything, and it used to be one instant call. Now it is
     * refused, and while it waits in the queue the band is still the publishers' rate.
     */
    function test_TheGovernorCannotInstantlyHandTheBandToItsOwnLeg() public {
        OwnedLeg mine = new OwnedLeg(5_000);
        _publish(540);
        bytes memory repoint = _setLegs(address(usdtUsd), address(mine), USDT_MAX_AGE, FX_MAX_AGE);
        vm.prank(governor);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, ChainlinkSignedFxOracle.setLegs.selector)
        );
        oracle.setLegs(address(usdtUsd), address(mine), USDT_MAX_AGE, FX_MAX_AGE);

        vm.prank(governor);
        oracle.schedule(repoint);
        vm.warp(block.timestamp + DELAY - 1);
        usdtUsd.set(99_972_163, block.timestamp);
        _publish(540);
        assertEq(_price(), 540, "the band is still the signed rate a second before the delay ends");
        assertEq(address(oracle.usdBrl()), address(fx));
    }

    function test_OnlySetLegsCanBeScheduled() public {
        bytes[2] memory calls =
            [abi.encodeCall(DelayedGovernance.transferGovernor, (address(1))), abi.encodeCall(DelayedGovernance.completeSetup, ())];
        for (uint256 i; i < 2; ++i) {
            vm.prank(governor);
            vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.NotDelayable.selector, bytes4(calls[i])));
            oracle.schedule(calls[i]);
        }
    }

    /// The cross itself refuses to price until its own setup closes.
    function test_TheCrossRefusesToPriceUntilItsSetupCloses() public {
        _publish(540);
        ChainlinkSignedFxOracle fresh =
            new ChainlinkSignedFxOracle(address(usdtUsd), address(fx), USDT_MAX_AGE, FX_MAX_AGE, governor, DELAY);
        vm.expectRevert(DelayedGovernance.SetupIncomplete.selector);
        fresh.brlCentsPerUnit();
        _completeSetup(address(fresh));
        (uint256 p,) = fresh.brlCentsPerUnit();
        assertEq(p, 540);
    }

    /// And fails closed on an FX leg still in setup, even one holding a signed rate.
    function test_TheCrossFailsClosedOnAnFxLegStillInSetup() public {
        address[] memory set = new address[](2);
        (set[0], set[1]) = (vm.addr(p1), vm.addr(p2));
        SignedPriceOracle freshLeg = new SignedPriceOracle(governor, DELAY, set, 2);
        fx = freshLeg; // _publish signs into `fx`
        _publish(540);
        ChainlinkSignedFxOracle cross =
            new ChainlinkSignedFxOracle(address(usdtUsd), address(freshLeg), USDT_MAX_AGE, FX_MAX_AGE, governor, DELAY);
        _completeSetup(address(cross));
        vm.expectRevert(DelayedGovernance.SetupIncomplete.selector);
        cross.brlCentsPerUnit();
        _completeSetup(address(freshLeg));
        (uint256 p,) = cross.brlCentsPerUnit();
        assertEq(p, 540);
    }

    function test_TheConstructorRefusesAnUnusableConfiguration() public {
        vm.expectRevert(DelayedGovernance.ZeroAddress.selector);
        new ChainlinkSignedFxOracle(address(usdtUsd), address(fx), 1, 1, address(0), DELAY);
        vm.expectRevert(ChainlinkSignedFxOracle.BadMaxAge.selector);
        new ChainlinkSignedFxOracle(address(usdtUsd), address(fx), 0, 1, governor, DELAY);
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.BadGovernanceDelay.selector, 1 hours));
        new ChainlinkSignedFxOracle(address(usdtUsd), address(fx), 1, 1, governor, 1 hours);
    }

    function _one() internal view returns (address[] memory set) {
        set = new address[](1);
        set[0] = vm.addr(p1);
    }
}

/**
 * The oracle behind the real escrows, pricing a 6-decimal token: the unit IPriceOracle now
 * documents (centavos per whole token) is the unit both escrows compute with.
 */
contract ChainlinkSignedFxOracleEscrowTest is Governed {
    uint256 p1 = 0xF1;
    uint256 p2 = 0xF2;
    address governor = address(0x60F);
    address lp = makeAddr("lp");
    address seller = makeAddr("seller");

    SignedPriceOracle fx;
    FxTestFeed usdtUsd;
    ChainlinkSignedFxOracle oracle;
    MockUSD usdt;
    FiatEscrow onramp;
    OffRampEscrow offramp;
    LPRegistry registry;
    uint64 seq;

    bytes32 constant PIX = keccak256("lp@pix");
    uint16 constant PIX_MASK = uint16(1 << uint8(IAttestorVerifier.Rail.PIX));

    function setUp() public {
        vm.warp(1_800_000_000);
        address[] memory set = new address[](2);
        (set[0], set[1]) = (vm.addr(p1), vm.addr(p2));
        fx = new SignedPriceOracle(governor, DELAY, set, 2);
        usdtUsd = new FxTestFeed(99_972_163, 8);
        usdt = new MockUSD();
        registry = new LPRegistry(governor, DELAY);
        // A deliberately generous FX max age, to show the escrow's own MAX_PRICE_AGE still bites.
        oracle = new ChainlinkSignedFxOracle(address(usdtUsd), address(fx), 25 hours, 6 hours, governor, DELAY);
        onramp = new FiatEscrow(address(oracle), address(registry), address(0xBEEF), address(0xBEEF), 500, governor, DELAY, DISPUTE_TIMEOUT, TAKER_DISPUTE_TIMEOUT, MAX_VETTING_FEE_BPS);
        offramp = new OffRampEscrow(address(oracle), address(registry), 500, governor, DELAY, DISPUTE_TIMEOUT);
        vm.startPrank(governor);
        fx.completeSetup();
        oracle.completeSetup();
        registry.setEscrow(address(onramp), true);
        registry.setEscrow(address(offramp), true);
        registry.setTier(lp, LPRegistry.Tier.INSTITUTIONAL, 100_000_000);
        registry.completeSetup();
        onramp.setVerifier(address(this), true);
        offramp.setVerifier(address(this), true);
        onramp.setAsset(address(usdt), address(oracle), 6, true);
        offramp.setAsset(address(usdt), address(oracle), 6, true);
        onramp.completeSetup();
        offramp.completeSetup();
        vm.stopPrank();
        usdt.mint(lp, 10_000e6);
        usdt.mint(seller, 10_000e6);
    }

    function attestorKind() external pure returns (string memory) {
        return "test";
    }

    function provesBankSession() external pure returns (bool) {
        return true;
    }

    function _publish(uint256 centsPerUsd) internal {
        ++seq;
        uint64 at = uint64(block.timestamp);
        bytes32 d = fx.digest(centsPerUsd, at, seq);
        (uint256 lo, uint256 hi) = vm.addr(p1) < vm.addr(p2) ? (p1, p2) : (p2, p1);
        bytes[] memory sigs = new bytes[](2);
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(lo, d);
        sigs[0] = abi.encodePacked(r, s, v);
        (v, r, s) = vm.sign(hi, d);
        sigs[1] = abi.encodePacked(r, s, v);
        fx.submit(centsPerUsd, at, seq, sigs);
    }

    function _post(uint256 price) internal returns (bytes32) {
        vm.startPrank(lp);
        usdt.approve(address(onramp), 1000e6);
        bytes32 id = onramp.postOffer(address(usdt), 1000e6, price, PIX, 25e6, 500e6, address(this), PIX_MASK);
        vm.stopPrank();
        return id;
    }

    /// R$5.40 per USDT is 540: inside a 5% band around the 540 mid; R$6.00 is 11% out.
    function test_TheBandIsInCentavosPerWholeUsdt() public {
        _publish(540);
        _post(540);
        vm.startPrank(lp);
        usdt.approve(address(onramp), 0);
        usdt.approve(address(onramp), 1000e6);
        vm.expectRevert(FiatEscrow.PriceOutsideBand.selector);
        onramp.postOffer(address(usdt), 1000e6, 600, PIX, 25e6, 500e6, address(this), PIX_MASK);
        vm.stopPrank();

        // Off-ramp: 100 USDT for R$540.00 -> 54,000 * 1e6 / 100e6 = 540 per whole token.
        vm.startPrank(seller);
        usdt.approve(address(offramp), 100e6);
        offramp.openSale(address(usdt), 100e6, 54_000, PIX, address(this), PIX_MASK, seller);
        vm.stopPrank();
    }

    /// The feed a day old (inside its heartbeat) and the rate fresh: the escrow trades.
    function test_TheEscrowTradesWhileTheFeedIsHoursOld() public {
        vm.warp(block.timestamp + 20 hours); // feed last answered 20h ago
        _publish(540);
        bytes32 offerId = _post(540);
        vm.prank(makeAddr("taker"));
        onramp.lockOrder(offerId, 100e6, FiatEscrow.Delivery.DIRECT, makeAddr("payout"), 0);
    }

    /**
     * Belt and braces. With the oracle's FX max age set longer than an hour, the escrow's own
     * MAX_PRICE_AGE still refuses a rate older than that - because the time reported is the
     * signed rate's, the leg with no heartbeat of its own.
     */
    function test_TheEscrowsOwnPriceAgeStillAppliesToTheSignedRate() public {
        _publish(540);
        bytes32 offerId = _post(540);
        vm.warp(block.timestamp + 1 hours + 1);
        vm.expectRevert(FiatEscrow.StalePrice.selector);
        vm.prank(makeAddr("taker"));
        onramp.lockOrder(offerId, 100e6, FiatEscrow.Delivery.DIRECT, makeAddr("payout"), 0);
    }

    /// A depeg reaches takers: an offer posted at the peg cannot be locked 6% below it.
    function test_ADepegRefusesOffersPostedAtThePeg() public {
        _publish(540);
        bytes32 offerId = _post(540);
        usdtUsd.set(94_000_000, block.timestamp); // $0.94 -> mid 508; 540 is 6.3% above
        vm.expectRevert(FiatEscrow.PriceOutsideBand.selector);
        vm.prank(makeAddr("taker"));
        onramp.lockOrder(offerId, 100e6, FiatEscrow.Delivery.DIRECT, makeAddr("payout"), 0);
    }
}
