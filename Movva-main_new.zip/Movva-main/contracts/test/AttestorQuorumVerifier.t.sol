// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Governed} from "./utils/Governed.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";
import {AttestorQuorumVerifier} from "../ramp/AttestorQuorumVerifier.sol";
import {IAttestorVerifier} from "../ramp/IAttestorVerifier.sol";

contract AttestorQuorumVerifierTest is Governed {
    AttestorQuorumVerifier v;

    uint256 k1 = 0xA11CE;
    uint256 k2 = 0xB0B;
    uint256 k3 = 0xC0FFEE;
    uint256 kEvil = 0xBAD;

    address a1;
    address a2;
    address a3;
    address governor = address(0x60F);

    bytes32 constant ORDER = keccak256("order-1");

    function setUp() public {
        a1 = vm.addr(k1);
        a2 = vm.addr(k2);
        a3 = vm.addr(k3);
        address[] memory set = new address[](3);
        set[0] = a1;
        set[1] = a2;
        set[2] = a3;
        v = new AttestorQuorumVerifier(governor, DELAY, set, 2);
        _completeSetup(address(v));
    }

    function _payment() internal pure returns (IAttestorVerifier.Payment memory p) {
        p = IAttestorVerifier.Payment({
            bankTxId: keccak256("E12345"),
            payeeKeyHash: keccak256("lp@pix"),
            payerRef: keccak256("payer"),
            amountBrlCents: 3_000_000,
            paidAt: 1_700_000_000,
            rail: IAttestorVerifier.Rail.PIX
        });
    }

    function _sign(uint256 key, bytes32 orderId, IAttestorVerifier.Payment memory p)
        internal
        view
        returns (bytes memory)
    {
        (uint8 sv, bytes32 r, bytes32 s) = vm.sign(key, v.hashPayment(orderId, p));
        return abi.encodePacked(r, s, sv);
    }

    /// @dev The contract requires signatures sorted by signer, so sort by address.
    function _sorted(uint256 ka, uint256 kb, bytes32 orderId)
        internal
        view
        returns (bytes[] memory sigs)
    {
        IAttestorVerifier.Payment memory p = _payment();
        sigs = new bytes[](2);
        if (vm.addr(ka) < vm.addr(kb)) {
            sigs[0] = _sign(ka, orderId, p);
            sigs[1] = _sign(kb, orderId, p);
        } else {
            sigs[0] = _sign(kb, orderId, p);
            sigs[1] = _sign(ka, orderId, p);
        }
    }

    function _proof(bytes[] memory sigs) internal pure returns (bytes memory) {
        IAttestorVerifier.Payment memory p = _payment();
        return abi.encode(
            p.bankTxId, p.payeeKeyHash, p.payerRef, p.amountBrlCents, p.paidAt, uint8(p.rail), sigs
        );
    }

    function test_QuorumOfTwoVerifies() public view {
        IAttestorVerifier.Payment memory got = v.verifyPayment(ORDER, _proof(_sorted(k1, k2, ORDER)));
        assertEq(got.bankTxId, keccak256("E12345"));
        assertEq(got.amountBrlCents, 3_000_000);
    }

    function test_OneSignatureIsNotAQuorum() public {
        bytes[] memory one = new bytes[](1);
        one[0] = _sign(k1, ORDER, _payment());
        vm.expectRevert(
            abi.encodeWithSelector(AttestorQuorumVerifier.NotEnoughSignatures.selector, 1, 2)
        );
        v.verifyPayment(ORDER, _proof(one));
    }

    /// The classic way an M-of-N check degrades into 1-of-N.
    function test_TheSameAttestorTwiceIsNotAQuorum() public {
        bytes[] memory dup = new bytes[](2);
        dup[0] = _sign(k1, ORDER, _payment());
        dup[1] = _sign(k1, ORDER, _payment());
        vm.expectRevert(AttestorQuorumVerifier.SignaturesUnsorted.selector);
        v.verifyPayment(ORDER, _proof(dup));
    }

    function test_OutsiderSignatureIsRejected() public {
        bytes[] memory sigs = new bytes[](2);
        IAttestorVerifier.Payment memory p = _payment();
        // Deliberately unsorted-proof-safe: pick the ordering that puts the evil key second
        // so the failure is attribution, not ordering.
        if (vm.addr(k1) < vm.addr(kEvil)) {
            sigs[0] = _sign(k1, ORDER, p);
            sigs[1] = _sign(kEvil, ORDER, p);
        } else {
            sigs[0] = _sign(kEvil, ORDER, p);
            sigs[1] = _sign(k1, ORDER, p);
        }
        vm.expectRevert(
            abi.encodeWithSelector(AttestorQuorumVerifier.UnknownAttestor.selector, vm.addr(kEvil))
        );
        v.verifyPayment(ORDER, _proof(sigs));
    }

    /// The property the whole escrow rests on: a real receipt cannot be moved to another order.
    function test_ProofForOneOrderDoesNotVerifyForAnother() public {
        bytes memory proof = _proof(_sorted(k1, k2, ORDER));
        vm.expectRevert(); // recovers signers for a different digest; none are attestors
        v.verifyPayment(keccak256("order-2"), proof);
    }

    /// Any field change invalidates the quorum.
    function test_TamperingWithTheAmountInvalidatesIt() public {
        bytes[] memory sigs = _sorted(k1, k2, ORDER);
        IAttestorVerifier.Payment memory p = _payment();
        bytes memory tampered = abi.encode(
            p.bankTxId, p.payeeKeyHash, p.payerRef, uint256(1), p.paidAt, uint8(p.rail), sigs
        );
        vm.expectRevert();
        v.verifyPayment(ORDER, tampered);
    }

    function test_MalleatedHighSSignatureIsRejected() public {
        IAttestorVerifier.Payment memory p = _payment();
        (uint8 sv, bytes32 r, bytes32 s) = vm.sign(k1, v.hashPayment(ORDER, p));
        uint256 N = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141;
        bytes32 flippedS = bytes32(N - uint256(s));
        uint8 flippedV = sv == 27 ? 28 : 27;
        bytes[] memory sigs = new bytes[](2);
        sigs[0] = abi.encodePacked(r, flippedS, flippedV);
        sigs[1] = _sign(k2, ORDER, p);
        vm.expectRevert(AttestorQuorumVerifier.MalformedProof.selector);
        v.verifyPayment(ORDER, _proof(sigs));
    }

    /*//////////////////////////////////////////////////////////////
                              GOVERNANCE
    //////////////////////////////////////////////////////////////*/

    /**
     * Changed behaviour. Removing attestors used to drag the threshold down with the set, "so
     * orders never freeze". That made removal an undelayed way to lower the threshold: a
     * governor colluding with one attestor removes the others and that one signs alone.
     * Now the threshold stays, verification fails closed, and lowering it must be scheduled.
     */
    function test_RemovingAttestorsNeverLowersTheThreshold() public {
        vm.startPrank(governor);
        v.setAttestor(a1, false);
        v.setAttestor(a2, false); // count now 1, threshold still 2
        vm.stopPrank();
        assertEq(v.attestorCount(), 1);
        assertEq(v.threshold(), 2, "the threshold did not follow the set down");

        bytes[] memory one = new bytes[](1);
        one[0] = _sign(k3, ORDER, _payment());
        vm.expectRevert(abi.encodeWithSelector(AttestorQuorumVerifier.NotEnoughSignatures.selector, 1, 2));
        v.verifyPayment(ORDER, _proof(one));

        vm.prank(governor);
        vm.expectRevert(
            abi.encodeWithSelector(
                DelayedGovernance.ChangeMustBeScheduled.selector, AttestorQuorumVerifier.setThreshold.selector
            )
        );
        v.setThreshold(1);
    }

    /**
     * The theft the delay exists for: the governor adds its own key and drops the threshold
     * to one, then signs a payment that never happened. It can no longer do that in one
     * block; both steps are announced and wait GOVERNANCE_DELAY, which is the LPs' window to
     * close offers that select this verifier.
     */
    function test_AGovernorCannotInstantlyMakeItselfAQuorumOfOne() public {
        uint256 govKey = 0x60F60F;
        address govAttestor = vm.addr(govKey);
        vm.startPrank(governor);
        vm.expectRevert(
            abi.encodeWithSelector(
                DelayedGovernance.ChangeMustBeScheduled.selector, AttestorQuorumVerifier.setAttestor.selector
            )
        );
        v.setAttestor(govAttestor, true);
        v.schedule(abi.encodeCall(AttestorQuorumVerifier.setAttestor, (govAttestor, true)));
        v.schedule(abi.encodeCall(AttestorQuorumVerifier.setThreshold, (1)));
        vm.stopPrank();

        // For the whole delay, a self-signed "payment" is worthless.
        vm.warp(block.timestamp + DELAY - 1);
        bytes[] memory forged = new bytes[](1);
        forged[0] = _sign(govKey, ORDER, _payment());
        bytes memory proof = _proof(forged);
        vm.expectRevert(abi.encodeWithSelector(AttestorQuorumVerifier.NotEnoughSignatures.selector, 1, 2));
        v.verifyPayment(ORDER, proof);

        // Only after it - in public - does the change land.
        vm.warp(block.timestamp + 1);
        vm.startPrank(governor);
        v.execute(abi.encodeCall(AttestorQuorumVerifier.setAttestor, (govAttestor, true)));
        v.execute(abi.encodeCall(AttestorQuorumVerifier.setThreshold, (1)));
        vm.stopPrank();
        assertEq(v.verifyPayment(ORDER, proof).amountBrlCents, 3_000_000);
    }

    function test_RaisingTheThresholdAndRemovingAttestorsAreInstant() public {
        vm.startPrank(governor);
        v.setThreshold(3);
        v.setAttestor(a3, false);
        vm.stopPrank();
        assertEq(v.threshold(), 3);
        assertFalse(v.isAttestor(a3));
    }

    function test_NothingVerifiesBeforeSetupIsComplete() public {
        address[] memory set = new address[](2);
        set[0] = a1;
        set[1] = a2;
        AttestorQuorumVerifier fresh = new AttestorQuorumVerifier(governor, DELAY, set, 2);
        bytes memory proof = _proof(_sorted(k1, k2, ORDER));
        vm.expectRevert(DelayedGovernance.SetupIncomplete.selector);
        fresh.verifyPayment(ORDER, proof);
    }

    function test_ThresholdAboveTheSetIsRejected() public {
        vm.prank(governor);
        vm.expectRevert(AttestorQuorumVerifier.BadThreshold.selector);
        v.setThreshold(4);
    }

    function test_OnlyGovernorChangesTheAttestorSet() public {
        vm.expectRevert(DelayedGovernance.NotGovernor.selector);
        v.setAttestor(address(0xFEE), true);
    }

    function test_RemovedAttestorNoLongerCounts() public {
        // Build the proof BEFORE arming expectRevert: _sorted() calls hashPayment(), and a
        // non-reverting call between the cheatcode and the call under test consumes it.
        bytes memory proof = _proof(_sorted(k1, k2, ORDER));
        vm.prank(governor);
        v.setAttestor(a2, false);
        vm.expectRevert(
            abi.encodeWithSelector(AttestorQuorumVerifier.UnknownAttestor.selector, a2)
        );
        v.verifyPayment(ORDER, proof);
    }
}
