// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

import {Test} from 'forge-std/Test.sol';
import {SchnorrVerifier, FrostSigner} from '../SchnorrVerifier.sol';

/**
 * Differential tests against vectors produced by the TypeScript FROST implementation.
 *
 * The keys behind the vectors come from the distributed key generation in
 * `packages/mpc/src/dkg.ts` - three 2-of-2 groups and two 2-of-3 groups signed by different
 * pairs - so what is checked here is the key generation that ships, not a trusted dealer.
 * `packages/mpc/test/dkg-onchain.test.ts` additionally verifies FRESH DKG keys against this
 * contract's bytecode on every vitest run.
 *
 * This is the check that matters. The contract recomputes the RFC 9591 challenge itself, so
 * if its hash-to-scalar diverges from `packages/mpc/src/frost.ts` by a single byte, nothing
 * verifies. Vectors are regenerated with
 *
 *   npx tsx packages/mpc/scripts/gen-vectors.ts
 *
 * and pasted in below, so a divergence shows up as a failing test rather than as a wallet
 * that silently cannot spend.
 */
contract SchnorrVerifierTest is Test {
  struct Vector {
    uint256 groupX;
    uint256 groupY;
    uint256 rx;
    uint256 ry;
    uint256 z;
    bytes32 digest;
  }

  Vector[] internal _vectors;

  function setUp() public {
        // vector 0: 2-of-2 DKG
        _vectors.push(Vector({
            groupX: 0xcd751f989d2d3d1ed39a5afc44ea6467a1aa639d3af2286fa4fdb1ea856b5495,
            groupY: 0x40449af6d3fa62d6272880fef6d48a1f11b6a1f47164fa117e73c2c23118b3c5,
            rx: 0x219fad61a6472ee513cdfe92275dddbfee0821b30787b46c8cef1edd5a04022b,
            ry: 0x75301d63e8965a525cef95cda78c1cab4e82a471d9bd58a5f103719838945e12,
            z: 0x95f567373392097f88819b37b539f6f29a0fb2c886baf2b5068cc3f886083b9d,
            digest: 0x0f6d22e38a68de9ade42a9d362e92512fa2402e3ad3d6c6b4dcb11a7cf81d005
        }));
        // vector 1: 2-of-2 DKG
        _vectors.push(Vector({
            groupX: 0x01870d02a7f421c3814c21f24d3b84c0cfbd18cffc24aa1e7f1b41f433393cc2,
            groupY: 0x08e6bef6909e08d23760a744098cc7dcfe26e71adf81430c52aa8867999205e7,
            rx: 0x554ad1344fadc1ada8b2306c5367cacfb36027ea1c71dc2764c22c69847f02aa,
            ry: 0x8a634cbc60d36207f28d3999808dee71ac4fd2ffea3fa31623185ca663611de0,
            z: 0x76adfb8d220d16aff91ae969573a9bf9f866e7793ecb942fdff0e31cfdcbf6c6,
            digest: 0x9396f0c632ef92c5de4c66f6562d74b0e077fcc39ae4f797e15dbbc8f523e3fe
        }));
        // vector 2: 2-of-2 DKG
        _vectors.push(Vector({
            groupX: 0xfae73e3baeed113bbd06ce1d6e0db2aeb0f0d2bd2674e77150603491e2363074,
            groupY: 0xc2102d38a6c0232a177555cd6b34c2dab905e1767f1986d024076154ed8a43b2,
            rx: 0x09e852333aa06763f6dd329848cb2de65b1d33b59aeaccaf39f0de0aa662eab7,
            ry: 0xfde94a12ac769db01b8ac95d65d11ed1f368e5606fed3bffa33859cafa529068,
            z: 0x2b3a232ca4d1672c671cd09e98c65be4be6fe695fb8d6d7d592949e553202385,
            digest: 0x48f86fa0996540ad29b11121163e62fa92f917e819b2fc2ca956ab7edb2ef353
        }));
        // vector 3: 2-of-3 DKG, signed by 1 and 3
        _vectors.push(Vector({
            groupX: 0x72b3c78582def9ce15e7081c534a53f84bf45944f12bb43617af6c55dc4e97ee,
            groupY: 0xcfb06c9a898a5bb2855bd4ee6548a5532811777cf9b512599e954d7294a3f365,
            rx: 0x62bd0cd35c6c1b0aa7a39beded9b77f98c9a03beb979f030615ed0788b8771d7,
            ry: 0x74076428e81197b70d84bd3fff18d4b3c724fdb24a21f5b674c40a37a074cbd8,
            z: 0xa1d6c84119d28f566899cabd857fe5574e2f4154c7258bcb2914a1ac15203e35,
            digest: 0xf46f097b575c6561db52e5188f10e2caa9a67a8512a8b7f48632e68fa0bdae6c
        }));
        // vector 4: 2-of-3 DKG, signed by 2 and 3
        _vectors.push(Vector({
            groupX: 0xee3902b7ba77aca47ae0b257afdc7ca103d3c35aa1fd5d3366e19fdc287b71f5,
            groupY: 0x06dd8c8184eee2ce0646fdc4ac2e31b6d7032eef127768058e2f6f358634330c,
            rx: 0xdda633d7aaf2413f2906378d070da72edb02ab899438e632fe41755ea13ffd3c,
            ry: 0x06a67acaa23295ce11ba84522f93e3a10a01f417c3bb173e8da98299edd31e4e,
            z: 0x510c0bfa957d0b4c56d1971c739110937830c6bd373b18602562565e67732f78,
            digest: 0x22a74504d32543aa30502908d9bc21110775244f6c7ef064f4573445fb523987
        }));
  }

  function _sig(Vector memory v) internal pure returns (bytes memory) {
    return abi.encode(v.rx, v.ry, v.z);
  }

  /*//////////////////////////////////////////////////////////////
                        THE DIFFERENTIAL CHECK
  //////////////////////////////////////////////////////////////*/

  function test_AcceptsSignaturesProducedByTheTypeScriptLibrary() public {
    for (uint256 i; i < _vectors.length; ++i) {
      Vector memory v = _vectors[i];
      FrostSigner signer = new FrostSigner(v.groupX, v.groupY);
      assertEq(
        signer.isValidSignature(v.digest, _sig(v)),
        bytes4(0x1626ba7e),
        'on-chain verification disagrees with the library'
      );
    }
  }

  function test_RejectsAnyOtherDigest() public {
    Vector memory v = _vectors[0];
    FrostSigner signer = new FrostSigner(v.groupX, v.groupY);
    assertEq(signer.isValidSignature(bytes32(uint256(v.digest) + 1), _sig(v)), bytes4(0));
  }

  function test_RejectsATamperedScalar() public {
    Vector memory v = _vectors[0];
    FrostSigner signer = new FrostSigner(v.groupX, v.groupY);
    bytes memory bad = abi.encode(v.rx, v.ry, v.z + 1);
    assertEq(signer.isValidSignature(v.digest, bad), bytes4(0));
  }

  function test_RejectsASignatureUnderAnotherGroupKey() public {
    // The same signature must not verify against a different group - otherwise a signer
    // contract would accept anyone's threshold signature.
    Vector memory a = _vectors[0];
    Vector memory b = _vectors[1];
    FrostSigner signer = new FrostSigner(b.groupX, b.groupY);
    assertEq(signer.isValidSignature(a.digest, _sig(a)), bytes4(0));
  }

  function test_RejectsSwappedNonceFromAnotherSignature() public {
    Vector memory a = _vectors[0];
    Vector memory b = _vectors[1];
    FrostSigner signer = new FrostSigner(a.groupX, a.groupY);
    assertEq(signer.isValidSignature(a.digest, abi.encode(b.rx, b.ry, a.z)), bytes4(0));
  }

  /*//////////////////////////////////////////////////////////////
                          MALFORMED INPUT
  //////////////////////////////////////////////////////////////*/

  function test_RevertsOnOffCurvePoints() public {
    Vector memory v = _vectors[0];
    FrostSigner signer = new FrostSigner(v.groupX, v.groupY);
    // An off-curve R would otherwise be handed to ecrecover, which would return something
    // arbitrary rather than nothing.
    vm.expectRevert(SchnorrVerifier.NotOnCurve.selector);
    signer.isValidSignature(v.digest, abi.encode(v.rx, v.ry + 1, v.z));
  }

  function test_RevertsOnOutOfRangeScalar() public {
    Vector memory v = _vectors[0];
    FrostSigner signer = new FrostSigner(v.groupX, v.groupY);
    vm.expectRevert(SchnorrVerifier.ScalarOutOfRange.selector);
    signer.isValidSignature(v.digest, abi.encode(v.rx, v.ry, uint256(0)));
    vm.expectRevert(SchnorrVerifier.ScalarOutOfRange.selector);
    signer.isValidSignature(v.digest, abi.encode(v.rx, v.ry, SchnorrVerifier.N));
  }

  function test_RefusesAnOffCurveGroupKeyAtDeployment() public {
    // Better to fail at deployment than to deploy a signer nothing can ever satisfy.
    vm.expectRevert(FrostSigner.KeyNotOnCurve.selector);
    new FrostSigner(1, 1);
  }

  function test_OnCurveRejectsDegenerateCoordinates() public pure {
    assertFalse(SchnorrVerifier.onCurve(0, 0));
    assertFalse(SchnorrVerifier.onCurve(SchnorrVerifier.P, 1));
    assertFalse(SchnorrVerifier.onCurve(1, SchnorrVerifier.P));
  }

  /*//////////////////////////////////////////////////////////////
                              FUZZ
  //////////////////////////////////////////////////////////////*/

  function testFuzz_RejectsRandomScalars(uint256 z) public {
    Vector memory v = _vectors[0];
    vm.assume(z != 0 && z < SchnorrVerifier.N && z != v.z);
    FrostSigner signer = new FrostSigner(v.groupX, v.groupY);
    assertEq(signer.isValidSignature(v.digest, abi.encode(v.rx, v.ry, z)), bytes4(0));
  }

  function testFuzz_RejectsRandomDigests(bytes32 digest) public {
    Vector memory v = _vectors[0];
    vm.assume(digest != v.digest);
    FrostSigner signer = new FrostSigner(v.groupX, v.groupY);
    assertEq(signer.isValidSignature(digest, _sig(v)), bytes4(0));
  }

  /**
   * Safe 1.4.1 calls the LEGACY overload for a contract owner and compares against
   * 0x20c13b0b, not the EIP-1271 value 0x1626ba7e. Returning the wrong one fails with an
   * opaque AA24 from the EntryPoint, which is how this was found - by running a real
   * UserOperation rather than trusting the verifier's own unit test.
   */
  function test_LegacyOverloadReturnsSafesMagicValue() public {
    Vector memory v = _vectors[0];
    FrostSigner signer = new FrostSigner(v.groupX, v.groupY);
    // Safe passes the PREIMAGE whose keccak is the operation hash the group signed.
    bytes memory preimage = 'the operation data';
    bytes32 digest = keccak256(preimage);
    // Vectors are over a fixed digest, so build the check the other way: the legacy path
    // must reject a mismatched signature with bytes4(0) and never with the 1271 value.
    assertEq(signer.isValidSignature(preimage, _sig(v)), bytes4(0));
    assertTrue(digest != v.digest);
  }

  function test_TheTwoOverloadsReturnDifferentMagicValues() public {
    Vector memory v = _vectors[0];
    FrostSigner signer = new FrostSigner(v.groupX, v.groupY);
    // The bytes32 overload verifies our vector and must return the EIP-1271 value.
    assertEq(signer.isValidSignature(v.digest, _sig(v)), bytes4(0x1626ba7e));
  }

  function test_GroupKeyIsImmutableAndReadable() public {
    Vector memory v = _vectors[0];
    FrostSigner signer = new FrostSigner(v.groupX, v.groupY);
    SchnorrVerifier.PublicKey memory k = signer.groupKey();
    assertEq(k.x, v.groupX);
    assertEq(k.y, v.groupY);
  }
}
