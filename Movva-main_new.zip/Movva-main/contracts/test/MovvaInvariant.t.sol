// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import {Vm} from "forge-std/Vm.sol";
import {console2} from "forge-std/console2.sol";
import {MovvaBase} from "./MovvaReserve.t.sol";
import {TetherLike, StataLike} from "./ERC4626Adapter.t.sol";
import {FxTestFeed} from "./ChainlinkSignedFxOracle.t.sol";
import {SignedPriceOracle} from "../ramp/SignedPriceOracle.sol";
import {YieldVault} from "../yield/YieldVault.sol";
import {ERC4626Adapter} from "../yield/adapters/ERC4626Adapter.sol";
import {Movva} from "../movva/Movva.sol";
import {MovvaReserve} from "../movva/MovvaReserve.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";

/// Movva minted and burned in `logs`, read from the token's own Transfer events: from address(0) is a
/// mint, to address(0) a burn. Only the reserve can do either (Movva.mint and Movva.burn check it).
function movvaMintsAndBurns(Vm.Log[] memory logs, address token) pure returns (uint256 minted, uint256 burned) {
    bytes32 transfer = keccak256("Transfer(address,address,uint256)");
    for (uint256 i; i < logs.length; ++i) {
        if (logs[i].emitter != token || logs[i].topics.length != 3 || logs[i].topics[0] != transfer) continue;
        uint256 value = abi.decode(logs[i].data, (uint256));
        if (logs[i].topics[1] == bytes32(0)) minted += value;
        if (logs[i].topics[2] == bytes32(0)) burned += value;
    }
}

/**
 * Drives the reserve the way a year of operation would: gateways minting and redeeming, the real
 * moving both ways (publishers re-signing the FX leg), USDT's peg wobbling on the Chainlink leg, the
 * yield harvested to Mova, the issuer recapitalizing, Aave-like interest and borrowed-out
 * liquidity, Tether freezing and unfreezing the reserve,
 * and time passing. Every call that must not happen is allowed to revert; every call that succeeds
 * is checked against the rule it is bound by, from state read before it ran.
 */
contract MovvaHandler is Test {
    MovvaReserve reserve;
    Movva movva;
    TetherLike usdt;
    FxTestFeed feed;
    SignedPriceOracle fx;
    YieldVault vault;
    StataLike stata;
    ERC4626Adapter adapter;
    address gateway;
    address keeper;
    address yieldTo;
    address feeTo;
    address gov;
    uint256 p1;
    uint256 p2;

    uint64 seq;
    uint256 public fxNow;

    uint256 public ghostSupply;
    /// @notice Every Movva the reserve has minted, and burned, since the token was deployed, from the
    ///         token's own events. Independent of totalSupply, which is what they are checked against.
    uint256 public ghostMinted;
    uint256 public ghostBurned;
    /// @notice A burn in mint or a mint in redeem, or a call whose events disagree with the
    ///         supply change it made.
    uint256 public ledgerViolations;
    /// @notice Every USDT `harvestYield` reported paying, all to the yield recipient.
    uint256 public ghostYield;
    uint256 public supplyViolations;
    /// @notice A harvest that left the reserve below max(principal, liabilities at the target), or paid
    ///         other than it reported.
    uint256 public harvestViolations;
    uint256 public redeemViolations;
    uint256 public mintViolations;
    uint256 public orderViolations;
    /// @notice A redemption the asset issuer had frozen the gateway for (SRM1-21).
    uint256 public frozenViolations;
    /// @notice A redemption or harvest with no readable rate: a USDT/USD answer outside
    ///         US$ 0.50 to 1.50 (SRM1-21) is the way the handler makes one.
    uint256 public unpricedViolations;
    /// @notice A third party a gateway redeems to.
    address internal payee = makeAddr("payee");
    mapping(bytes32 => uint256) public calls;

    struct Wiring {
        MovvaReserve reserve;
        TetherLike usdt;
        FxTestFeed feed;
        SignedPriceOracle fx;
        YieldVault vault;
        StataLike stata;
        ERC4626Adapter adapter;
        address gateway;
        address keeper;
        address yieldTo;
        address feeTo;
        address gov;
        uint256 p1;
        uint256 p2;
        uint64 seq;
        uint256 fxNow;
        uint256 minted; // by the reserve during setup, from the token's events
        uint256 burned;
    }

    constructor(Wiring memory w) {
        reserve = w.reserve;
        movva = Movva(w.reserve.MOVVA());
        usdt = w.usdt;
        feed = w.feed;
        fx = w.fx;
        vault = w.vault;
        stata = w.stata;
        adapter = w.adapter;
        gateway = w.gateway;
        keeper = w.keeper;
        yieldTo = w.yieldTo;
        feeTo = w.feeTo;
        gov = w.gov;
        p1 = w.p1;
        p2 = w.p2;
        seq = w.seq;
        fxNow = w.fxNow;
        ghostSupply = movva.totalSupply();
        ghostMinted = w.minted;
        ghostBurned = w.burned;
        usdt.mint(address(this), 1e18);
        usdt.approve(address(reserve), type(uint256).max);
    }

    /**
     * @dev Books the Movva the reserve minted and burned in the call just made, from the token's events
     *      recorded since the vm.recordLogs() right before it. Called only once that call has SUCCEEDED:
     *      the pinned Foundry's recordLogs also keeps events emitted inside calls that then reverted (a
     *      redeem that burns and then cannot pay), and those never happened on-chain. Only mint may
     *      mint, and only redeem may burn.
     */
    function _book(bool mayMint, bool mayBurn) internal returns (uint256 minted, uint256 burned) {
        (minted, burned) = movvaMintsAndBurns(vm.getRecordedLogs(), address(movva));
        if ((minted != 0 && !mayMint) || (burned != 0 && !mayBurn)) ++ledgerViolations;
        ghostMinted += minted;
        ghostBurned += burned;
    }

    /// @dev `calls` counts SUCCESSFUL calls, so the campaign's reach can be read after it.
    modifier supplyUnchanged() {
        uint256 before = movva.totalSupply();
        _;
        if (movva.totalSupply() != before) ++supplyViolations;
    }

    /*//////////////////////////////////////////////////////////////
                        ACTIONS THAT MAY MOVE SUPPLY
    //////////////////////////////////////////////////////////////*/

    function mint(uint256 amount) external {
        amount = bound(amount, 1, 3_000_000e6);
        uint256 supply = movva.totalSupply();
        uint256 feeBefore = movva.balanceOf(feeTo);
        (uint256 rate, bool ok) = _rate();
        vm.recordLogs();
        vm.prank(gateway);
        try reserve.mint(amount, gateway, 0) returns (uint256 out) {
            uint256 minted = movva.totalSupply() - supply;
            (uint256 booked,) = _book(true, false);
            if (booked != minted) ++ledgerViolations;
            if (!ok || minted != out + (movva.balanceOf(feeTo) - feeBefore)) ++supplyViolations;
            if (minted > (amount * rate) / 1e6) ++mintViolations;
            ghostSupply += minted;
            ++calls["mint"];
        } catch {}
    }

    /// @dev To the gateway itself, or (`toOther`) to a third party: a frozen gateway may do neither.
    function redeem(uint256 amount, bool toOther) external {
        uint256 bal = movva.balanceOf(gateway);
        if (bal == 0) return;
        amount = bound(amount, 1, bal);
        address to = toOther ? payee : gateway;
        (uint256 rate, bool ok) = _rate();
        if (!ok) {
            // No readable rate (a USDT/USD answer outside its band, say): nothing may be priced.
            vm.prank(gateway);
            try reserve.redeem(amount, to, 0) {
                ++unpricedViolations;
            } catch {}
            return;
        }
        bool gatewayFrozen = usdt.isBlackListed(gateway);
        uint256 total = reserve.totalUsdt();
        uint256 supply = movva.totalSupply();
        uint256 fee = (amount * reserve.redeemFeeBps() + 9_999) / 10_000;
        uint256 feeBefore = movva.balanceOf(feeTo);
        vm.recordLogs();
        vm.prank(gateway);
        try reserve.redeem(amount, to, 0) returns (uint256 out) {
            if (gatewayFrozen) ++frozenViolations;
            (, uint256 booked) = _book(false, true);
            if (booked != supply - movva.totalSupply()) ++ledgerViolations;
            uint256 net = amount - fee;
            // min(1, ratio) of par, where par is net / rate and the ratio is total x rate / supply.
            if (out > (net * 1e6) / rate || out > (net * total) / supply) ++redeemViolations;
            uint256 burned = supply - movva.totalSupply();
            if (burned != net || movva.balanceOf(feeTo) - feeBefore != fee) ++supplyViolations;
            ghostSupply -= burned;
            ++calls["redeem"];
        } catch {}
    }

    /*//////////////////////////////////////////////////////////////
                        ACTIONS THAT MUST NOT MOVE SUPPLY
    //////////////////////////////////////////////////////////////*/

    /// Anyone harvests. It pays only the yield recipient, exactly what it reports, and never takes the
    /// reserve below max(principal, liabilities at the target ratio).
    function harvest(address caller) external supplyUnchanged {
        (uint256 rate, bool ok) = _rate();
        uint256 was = usdt.balanceOf(yieldTo);
        vm.prank(caller);
        try reserve.harvestYield() returns (uint256 paid) {
            if (!ok) ++unpricedViolations;
            uint256 got = usdt.balanceOf(yieldTo) - was;
            ghostYield += got;
            if (got != paid) ++harvestViolations;
            uint256 floor = (movva.totalSupply() * reserve.targetCollateralRatioBps() * 1e6 + rate * 10_000 - 1) / (rate * 10_000);
            if (reserve.principalUsdt() > floor) floor = reserve.principalUsdt();
            if (reserve.totalUsdt() < floor) ++harvestViolations;
            ++calls["harvest"];
        } catch {}
    }

    function recapitalize(uint256 amount) external supplyUnchanged {
        amount = bound(amount, 1, 200_000e6);
        try reserve.recapitalize(amount) {
            ++calls["recapitalize"];
        } catch {}
    }

    /**
     * The governor re-sets the two collateral ratios. Half the time the pair is sorted into order,
     * half the time it is whatever the fuzzer drew, so both sides of mint floor <= target are tried. A
     * change that lowers either ratio goes through the delay (schedule, wait, execute, with the oracle
     * legs kept fresh); one that only raises is sent directly. An in-order change must succeed and an
     * out-of-order one must revert with RatiosOutOfOrder, on either path.
     */
    function setRatios(uint256 a, uint256 b, bool sorted) external supplyUnchanged {
        uint16 x = uint16(bound(a, 10_000, 11_500));
        uint16 y = uint16(bound(b, 10_000, 11_500));
        if (sorted && x > y) (x, y) = (y, x);
        (uint16 minMint, uint16 target) = (x, y);
        bool ordered = minMint <= target;
        bytes memory call = abi.encodeCall(MovvaReserve.setCollateralRatios, (target, minMint));
        bool lowering = target < reserve.targetCollateralRatioBps() || minMint < reserve.minMintCollateralRatioBps();

        bool ok;
        bytes memory ret;
        if (lowering) {
            vm.prank(gov);
            try reserve.schedule(call) {}
            catch {
                return; // the same change is already queued from an earlier call
            }
            vm.warp(block.timestamp + reserve.GOVERNANCE_DELAY());
            feed.set(feed.answer(), block.timestamp);
            _publish(fxNow);
            vm.prank(gov);
            (ok, ret) = address(reserve).call(abi.encodeCall(DelayedGovernance.execute, (call)));
        } else {
            vm.prank(gov);
            (ok, ret) = address(reserve).call(call);
        }
        if (ok != ordered) ++orderViolations;
        if (!ok && keccak256(ret) != keccak256(abi.encodeWithSelector(MovvaReserve.RatiosOutOfOrder.selector))) {
            ++orderViolations;
        }
        if (ok) ++calls["setRatios"];
        else ++calls["setRatiosRefused"];
    }

    /// The real moves up to 15% either way, and the publishers sign it.
    function moveFx(uint256 bps, bool up) external supplyUnchanged {
        bps = bound(bps, 0, 1_500);
        uint256 next = up ? (fxNow * (10_000 + bps)) / 10_000 : (fxNow * (10_000 - bps)) / 10_000;
        if (next < 1e6) next = 1e6;
        if (next > 100e6) next = 100e6;
        _publish(next);
        ++calls["moveFx"];
    }

    /// USDT/USD between 0.85 and 1.02; one time in eight anywhere from zero to US$ 3, so outside the
    /// reserve's US$ 0.50 to 1.50 band too, where nothing may be priced.
    function movePeg(uint256 price, uint8 wild) external supplyUnchanged {
        if (wild < 32) feed.set(int256(bound(price, 1, 300_000_000)), block.timestamp);
        else feed.set(int256(bound(price, 85_000_000, 102_000_000)), block.timestamp);
        (, bool ok) = _rate();
        ++calls[ok ? bytes32("pegPriced") : bytes32("pegUnpriced")];
    }

    /// Tether lists the gateway a quarter of the time it is asked, and lifts it otherwise.
    function freezeGateway(uint8 seed) external supplyUnchanged {
        bool on = seed < 64;
        if (on) usdt.addBlackList(gateway);
        else usdt.removeBlackList(gateway);
        ++calls[on ? bytes32("freezeGateway") : bytes32("unfreezeGateway")];
    }

    function warp(uint256 dt) external supplyUnchanged {
        vm.warp(block.timestamp + bound(dt, 1 minutes, 12 hours));
        feed.set(feed.answer(), block.timestamp);
        _publish(fxNow);
    }

    function allocate(uint256 amount) external supplyUnchanged {
        uint256 idle = usdt.balanceOf(address(vault));
        if (idle == 0) return;
        vm.prank(keeper);
        try vault.allocate(adapter, bound(amount, 1, idle)) {
            ++calls["allocate"];
        } catch {}
    }

    function earn(uint256 amount) external supplyUnchanged {
        stata.earn(usdt, bound(amount, 0, 20_000e6));
    }

    function squeezeLiquidity(uint256 amount) external supplyUnchanged {
        stata.setLiquidity(bound(amount, 0, 2_000_000e6));
    }

    /// Tether lists the reserve a quarter of the time it is asked, and lifts it otherwise.
    function freeze(uint8 seed) external supplyUnchanged {
        bool on = seed < 64;
        if (on) usdt.addBlackList(address(reserve));
        else usdt.removeBlackList(address(reserve));
        ++calls[on ? bytes32("freeze") : bytes32("unfreeze")];
    }

    /*//////////////////////////////////////////////////////////////
                                 HELPERS
    //////////////////////////////////////////////////////////////*/

    function _rate() internal view returns (uint256 rate, bool ok) {
        try reserve.brlPerUsdtE18() returns (uint256 r, uint64) {
            return (r, true);
        } catch {
            return (0, false);
        }
    }

    function _publish(uint256 e6) internal {
        uint64 at = uint64(block.timestamp);
        bytes32 d = fx.digest(e6, at, ++seq);
        (uint256 lo, uint256 hi) = vm.addr(p1) < vm.addr(p2) ? (p1, p2) : (p2, p1);
        bytes[] memory sigs = new bytes[](2);
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(lo, d);
        sigs[0] = abi.encodePacked(r, s, v);
        (v, r, s) = vm.sign(hi, d);
        sigs[1] = abi.encodePacked(r, s, v);
        fx.submit(e6, at, seq, sigs);
        fxNow = e6;
    }
}

/**
 * The on-chain backstop as invariants (docs/movva.md, "The backstop, on-chain"), from rest at the
 * 108% target (the issuer's 8% launch buffer), and non-zero fees. The governor re-sets the ratios
 * during the run, in and out of order:
 *
 *  - Movva's supply changes only through mint and redeem, and each by exactly what it reports (there
 *    is no distribution: the surplus is never minted);
 *  - the supply equals everything the reserve has minted less everything it has burned since the
 *    token was deployed, from the token's own events (T-03, T-09);
 *  - harvestYield never leaves the reserve below max(principal, liabilities at the target) (the
 *    principal-locked reserve's own suite, MovvaPrincipalLockInvariant, adds the governor's side);
 *  - redeem never pays more than min(1, ratio) of par;
 *  - mint never creates more Movva than the USDT in at the rate;
 *  - the band oracle never reports more than R$ 1,00;
 *  - the yield recipient receives USDT only through harvestYield;
 *  - the ratios stay ordered, mint floor <= target, and an out-of-order change
 *    always reverts RatiosOutOfOrder while an in-order one always applies;
 *  - a gateway the asset issuer froze never redeems, to itself or to anyone (SRM1-21);
 *  - nothing is minted, redeemed or harvested while USDT/USD reads outside US$ 0.50 to
 *    1.50 (SRM1-21).
 */
/// forge-config: default.invariant.runs = 128
/// forge-config: default.invariant.depth = 200
/// forge-config: deep.invariant.runs = 1000
/// forge-config: deep.invariant.depth = 256
contract MovvaInvariantTest is MovvaBase {
    MovvaHandler handler;

    function setUp() public override {
        // From before the token exists, so the ledger of mints and burns starts at zero.
        vm.recordLogs();
        super.setUp();
        _afterDelay(address(reserve), abi.encodeCall(MovvaReserve.setFees, (30, 40)));
        _warp(0);
        _mint(1_000_000 * U);
        // The issuer's launch buffer: the reserve starts at rest, at the 108% target.
        vm.prank(gateway);
        reserve.recapitalize(80_000 * U);
        (uint256 minted, uint256 burned) = movvaMintsAndBurns(vm.getRecordedLogs(), address(movva));
        handler = new MovvaHandler(
            MovvaHandler.Wiring({
                reserve: reserve,
                usdt: usdt,
                feed: feed,
                fx: fx,
                vault: vault,
                stata: stata,
                adapter: adapter,
                gateway: gateway,
                keeper: keeper,
                yieldTo: yieldTo,
                feeTo: feeTo,
                gov: gov,
                p1: P1,
                p2: P2,
                seq: fxSeq,
                fxNow: fxNow,
                minted: minted,
                burned: burned
            })
        );
        targetContract(address(handler));
    }

    function invariant_SupplyMovesOnlyThroughMintAndRedeem() public view {
        assertEq(handler.supplyViolations(), 0, "supply moved outside mint/redeem, or by other than reported");
        assertEq(movva.totalSupply(), handler.ghostSupply());
    }

    /**
     * Rev. 3 T-03 and T-09 as this design implements them (docs/rev3-conformance.md, decision 1): the
     * supply is exactly what the reserve has minted less what it has burned, counted from deployment
     * off the token's own mint and burn events rather than read back from totalSupply; the reserve,
     * fixed at construction, is the only minter; mint only mints, redeem only burns, and
     * each call's events agree with the supply change it made. A mint anywhere else would move the
     * supply without entering the ledger, and fail the first assertion.
     */
    function invariant_SupplyIsWhatTheReserveMintedLessWhatItBurned() public view {
        assertEq(movva.totalSupply(), handler.ghostMinted() - handler.ghostBurned(), "supply != minted - burned");
        assertEq(movva.RESERVE(), address(reserve), "the minter moved");
        assertEq(handler.ledgerViolations(), 0, "a call's mint and burn events disagree with its supply change");
    }

    function invariant_HarvestNeverBreachesTheFloor() public view {
        assertEq(handler.harvestViolations(), 0);
        assertEq(usdt.balanceOf(yieldTo), handler.ghostYield(), "USDT reached the yield recipient another way");
    }

    function invariant_RedeemNeverPaysMoreThanMinOfParAndRatio() public view {
        assertEq(handler.redeemViolations(), 0);
        assertEq(handler.mintViolations(), 0);
    }

    /// The ratios are always ordered and never below 100%, whatever the governor tried.
    function invariant_RatiosStayInOrder() public view {
        assertEq(handler.orderViolations(), 0, "an out-of-order change went through, or an in-order one failed");
        uint16 minMint = reserve.minMintCollateralRatioBps();
        assertGe(minMint, 10_000);
        assertLe(minMint, reserve.targetCollateralRatioBps());
    }

    /// SRM1-21: no redemption for a gateway the asset issuer froze, to itself or to anyone; and no
    /// redemption or harvest while USDT/USD reads outside US$ 0.50 to 1.50 (mint's twin is
    /// in `supplyViolations`).
    function invariant_NoExitForAFrozenGatewayAndNothingPricedOutsideTheUsdBand() public view {
        assertEq(handler.frozenViolations(), 0, "a frozen gateway redeemed");
        assertEq(handler.unpricedViolations(), 0, "value moved with no readable rate");
    }

    function invariant_TheBandNeverReportsAboveOneReal() public view {
        try reserve.brlCentsPerUnit() returns (uint256 price, uint64) {
            assertLe(price, 100);
        } catch {}
    }

    /// Not an invariant: how much of the state space each run reached, in successful calls (-vv).
    function afterInvariant() public view {
        string[14] memory names = [
            "mint", "redeem", "harvest", "recapitalize", "moveFx", "allocate", "freeze", "unfreeze",
            "setRatios", "setRatiosRefused", "freezeGateway", "unfreezeGateway", "pegPriced", "pegUnpriced"
        ];
        for (uint256 i; i < names.length; ++i) {
            console2.log(names[i], handler.calls(bytes32(bytes(names[i]))));
        }
        console2.log("minted since deployment (e18)", handler.ghostMinted() / 1e18);
        console2.log("burned since deployment (e18)", handler.ghostBurned() / 1e18);
    }
}
