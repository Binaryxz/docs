// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import {Governed} from "./utils/Governed.sol";
import {RewardToken, RevertingHook, LoopingHook} from "./NodeRewards.t.sol";
import {LPRegistry} from "../ramp/LPRegistry.sol";
import {NodeRewards} from "../ramp/NodeRewards.sol";
import {FeeSplitter} from "../movva/FeeSplitter.sol";

/**
 * Drives node-provider rewards as a long stretch of operation would: LPs of every tier settling (through a real
 * LPRegistry), fees split in, donations, time passing, epochs finalized and claimed out of order, the governor voiding,
 * excluding and reinstating, the LP share and the reward limits moved both ways, and the registry's hook swapped
 * between NodeRewards and hooks that revert or burn all their gas. Every call that must not succeed may fail; every
 * governance call is checked against its classification, from state read before it ran.
 */
contract RewardsHandler is Test {
    LPRegistry registry;
    NodeRewards rewards;
    FeeSplitter splitter;
    RewardToken token;
    address gov;
    address[4] lps;
    address[3] hooks;

    uint256 public settleReverts;
    uint256 public delayViolations;
    uint256 public boundViolations;
    uint256 public ghostPaid;

    constructor(
        LPRegistry r,
        NodeRewards n,
        FeeSplitter s,
        RewardToken t,
        address gov_,
        address[4] memory lps_,
        address[3] memory hooks_
    ) {
        (registry, rewards, splitter, token, gov, lps, hooks) = (r, n, s, t, gov_, lps_, hooks_);
    }

    /// This handler is the escrow: a settlement with ample gas must never revert, whatever the hook does.
    function settle(uint256 lpSeed, uint256 cents) external {
        try registry.recordSettled{gas: 400_000}(lps[lpSeed % 4], bound(cents, 0, 5_000_000)) {}
        catch {
            ++settleReverts;
        }
    }

    function swapHook(uint256 kind) external {
        address next = hooks[kind % 3];
        if (registry.rewardsHook() == next) return;
        vm.prank(gov);
        registry.setRewardsHook(address(0)); // removal: instant
        vm.prank(gov);
        try registry.setRewardsHook(next) {
            ++delayViolations; // installing went through without the delay
        } catch {}
        bytes memory call = abi.encodeCall(LPRegistry.setRewardsHook, (next));
        vm.prank(gov);
        registry.schedule(call);
        vm.warp(block.timestamp + registry.GOVERNANCE_DELAY());
        vm.prank(gov);
        registry.execute(call);
    }

    function fees(uint256 amount) external {
        token.mint(address(splitter), bound(amount, 0, 1_000_000e18));
        splitter.split();
    }

    function donate(uint256 amount, bool sync) external {
        token.mint(address(rewards), bound(amount, 0, 10_000e18));
        if (sync) rewards.sync();
    }

    function warp(uint256 dt) external {
        vm.warp(block.timestamp + bound(dt, 1, 5 days));
    }

    function finalize(uint256 n) external {
        rewards.finalize(bound(n, 0, 6));
    }

    function claim(uint256 lpSeed) external {
        address lp = lps[lpSeed % 4];
        (uint256 total, uint256[] memory ids) = rewards.claimableIn(lp, 0, rewards.nextToFinalize());
        if (ids.length == 0) return;
        if (ids.length > 52) return;
        for (uint256 i; i < ids.length; ++i) {
            (uint256 volume,,, uint256 budget, uint256 lpCap) = rewards.epochs(ids[i]);
            uint256 v = rewards.volumeOf(ids[i], lp);
            uint256 share = budget * v / volume;
            if (share > v * 1e16 * rewards.MAX_REWARD_BPS_OF_VOLUME() / 10_000) ++boundViolations;
            if ((share < lpCap ? share : lpCap) > lpCap) ++boundViolations;
        }
        uint256 before = token.balanceOf(lp);
        vm.prank(lp);
        rewards.claim(ids, lp);
        uint256 got = token.balanceOf(lp) - before;
        if (got != total) ++boundViolations;
        ghostPaid += got;
    }

    function voidVolume(uint256 lpSeed, bool previous) external {
        uint256 e = rewards.currentEpoch();
        if (previous && e > 0) --e;
        address lp = lps[lpSeed % 4];
        if (rewards.volumeOf(e, lp) == 0 || block.timestamp >= rewards.finalizableAt(e)) return;
        vm.prank(gov);
        rewards.voidVolume(e, lp);
    }

    function exclude(uint256 lpSeed, bool on) external {
        address lp = lps[lpSeed % 4];
        bool was = rewards.excluded(lp);
        vm.prank(gov);
        try rewards.setExcluded(lp, on) {
            if (!on && was) ++delayViolations; // a reinstatement went through at once
        } catch {
            if (on || !was) ++delayViolations; // an exclusion, or a no-op, was refused
        }
    }

    function setShare(uint256 bps, bool throughQueue) external {
        bps = bound(bps, 0, 6_000);
        uint16 current = splitter.lpRewardShareBps();
        vm.prank(gov);
        try splitter.setLpRewardShare(uint16(bps)) {
            if (bps > current) ++delayViolations;
        } catch {
            if (bps <= current) ++delayViolations;
        }
        if (!throughQueue || bps <= current || bps > 5_000) return;
        bytes memory call = abi.encodeCall(FeeSplitter.setLpRewardShare, (uint16(bps)));
        vm.prank(gov);
        splitter.schedule(call);
        vm.warp(block.timestamp + splitter.GOVERNANCE_DELAY() - 1);
        vm.prank(gov);
        try splitter.execute(call) {
            ++delayViolations; // executed before its delay
        } catch {}
        vm.warp(block.timestamp + 1);
        vm.prank(gov);
        splitter.execute(call);
        if (splitter.lpRewardShareBps() != bps) ++delayViolations;
    }

    function setLimits(uint256 rate, uint256 cap, uint256 minCents) external {
        rate = bound(rate, 0, 20);
        cap = bound(cap, 0, 20_000e18);
        minCents = bound(minCents, 0, 10_000);
        bool loosens = rate > rewards.rewardBpsOfVolume() || cap > rewards.maxRewardPerLpPerEpoch()
            || minCents < rewards.minCountedCents();
        vm.prank(gov);
        try rewards.setRewardLimits(uint16(rate), cap, minCents) {
            if (loosens) ++delayViolations;
        } catch {
            if (!loosens) ++delayViolations;
        }
    }
}

/// forge-config: default.invariant.runs = 64
/// forge-config: default.invariant.depth = 120
/// forge-config: deep.invariant.runs = 1000
/// forge-config: deep.invariant.depth = 256
contract NodeRewardsInvariantTest is Governed {
    RewardsHandler handler;
    RewardToken token;
    LPRegistry registry;
    NodeRewards rewards;
    FeeSplitter splitter;

    function setUp() public {
        vm.warp(1_800_000_000);
        address gov = makeAddr("gov");
        address inst = makeAddr("institution");
        address inst2 = makeAddr("institution 2");
        address aff = makeAddr("affiliate");
        address retail = makeAddr("retail");
        token = new RewardToken();
        registry = new LPRegistry(gov, DELAY);
        rewards = new NodeRewards(address(token), 1e16, 7 days, 3 days, gov, DELAY);
        splitter = new FeeSplitter(address(token), makeAddr("treasury"), address(rewards), gov, DELAY);
        handler = new RewardsHandler(
            registry,
            rewards,
            splitter,
            token,
            gov,
            [inst, inst2, aff, retail],
            [address(rewards), address(new RevertingHook()), address(new LoopingHook())]
        );
        vm.startPrank(gov);
        registry.setEscrow(address(handler), true);
        registry.setTier(inst, LPRegistry.Tier.INSTITUTIONAL, 1_000_000_000);
        registry.setTier(inst2, LPRegistry.Tier.INSTITUTIONAL, 1_000_000_000);
        registry.setPhase(LPRegistry.Phase.C);
        registry.setRewardsHook(address(rewards));
        rewards.setRegistry(address(registry));
        splitter.setLpRewardShare(2_000);
        registry.completeSetup();
        rewards.completeSetup();
        splitter.completeSetup();
        vm.stopPrank();
        vm.prank(inst);
        registry.sponsorAffiliate(aff, 1_000_000);
        vm.prank(retail);
        registry.register();
        targetContract(address(handler));
    }

    function invariant_RewardsClaimedNeverExceedWhatWasFunded() public view {
        assertLe(rewards.totalClaimed(), rewards.totalFunded());
        assertEq(rewards.totalClaimed(), handler.ghostPaid(), "paid out other than through claims");
    }

    function invariant_TheBooksAddUpAndAreBacked() public view {
        assertEq(rewards.accounted(), rewards.totalFunded() - rewards.totalClaimed());
        assertGe(token.balanceOf(address(rewards)), rewards.accounted(), "owes more than it holds");
        uint256 unfinalized;
        for (uint256 e = rewards.nextToFinalize(); e <= rewards.currentEpoch(); ++e) {
            (,, uint256 funded,,) = rewards.epochs(e);
            unfinalized += funded;
        }
        assertEq(rewards.accounted(), rewards.carry() + rewards.outstanding() + unfinalized);
    }

    function invariant_AFailingHookNeverBlocksASettlement() public view {
        assertEq(handler.settleReverts(), 0);
    }

    function invariant_ShareAndLimitChangesFollowTheDelayRules() public view {
        assertEq(handler.delayViolations(), 0);
        assertLe(splitter.lpRewardShareBps(), splitter.MAX_LP_REWARD_SHARE_BPS());
        assertLe(rewards.rewardBpsOfVolume(), rewards.MAX_REWARD_BPS_OF_VOLUME());
    }

    function invariant_NoClaimPaysPastItsBounds() public view {
        assertEq(handler.boundViolations(), 0);
    }
}
