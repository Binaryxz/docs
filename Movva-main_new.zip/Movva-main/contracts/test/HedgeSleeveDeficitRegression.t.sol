// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

import {HedgeSleeveBase} from "./utils/HedgeSleeveBase.sol";
import {HedgeSleeveHandler} from "./HedgeSleeveInvariant.t.sol";

/**
 * Regression: the invariant run's counterexample for "a keeper step levered past the cap" (20 Oct 2026).
 *
 * The sequence unwinds, lets the price run until the venue liquidates the account into a margin deficit
 * (negative equity, no position), resumes, and lets the keeper rebalance. The sub-wallet sized the new margin as if
 * the equity were zero, so part of what it moved in only paid the deficit and the book opened near 6x against a 3x
 * cap. `_marginGap` now counts the deficit, and NAV nets it.
 *
 * Since 21 Oct `resume()` is delayed, so the handler's `resume` schedules it and waits out the delay (feeds kept
 * fresh) before executing it. The sequence still reaches the deficit: with `_marginGap` treating a deficit as zero
 * equity again, this test fails with "a keeper step levered past the cap".
 */
contract HedgeSleeveDeficitRegressionTest is HedgeSleeveBase {
    HedgeSleeveHandler handler;

    function setUp() public override {
        super.setUp();
        handler = new HedgeSleeveHandler(usdt, venueFeed, refFeed, venue, wallet, keeper, treasury, operator, stranger);
        _fund(200_000e6);
        _rebalanceUntilDone(20);
    }

    function _call(bytes memory data) internal {
        (bool ok,) = address(handler).call(data);
        require(ok, "handler call reverted");
    }

    function test_aMarginDeficitIsFilledBeforeExposureIsSized() public {
        _call(hex"807763ab"); // unwind()
        _call(hex"046f7da2"); // resume()
        _call(hex"f4993018000000000000000000000000000000053e5f74afb3a32d09b39497d474fe9fd5"); // rebalance(uint256)
        _call(hex"38d0743600000002a4553d8b7071bfdfe2950fefdada0e594852fc49d5a523aaebd4ecac0000000000000000000000000000000000000000000000000000000000000001"); // withdraw(uint256,bool)
        _call(hex"ca1d209d0000000000000000000000000000000000000000000000000002f9e40ab18a01"); // fund(uint256)
        _call(hex"f4993018f0880fa9cf34dc0a77f101a09955a834f6bfc0be68993a860258262161f13db0"); // rebalance(uint256)
        _call(hex"38d07436000000000000000000000000000000000000000000000000000000020a8fad420000000000000000000000000000000000000000000000000000000000000001"); // withdraw(uint256,bool)
        _call(hex"0e88e615000000000000000000000000000000000000000000000000000000000000052f0000000000000000000000000000000000000000000000000000000000000001"); // movePrice(uint256,bool)
        _call(hex"0e88e615fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffd0000000000000000000000000000000000000000000000000000000000000001"); // movePrice(uint256,bool)
        _call(hex"0e88e615fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffc0000000000000000000000000000000000000000000000000000000000000001"); // movePrice(uint256,bool)
        _call(hex"807763ab"); // unwind()
        _call(hex"046f7da2"); // resume()
        _call(hex"f4993018000000000000000000000000000000000001eaa6ef9f471bcac0c6c883909cd8"); // rebalance(uint256)
        assertFalse(handler.keeperOverLevered(), "a keeper step levered past the cap");
    }
}
