// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Governed} from "./utils/Governed.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {Vm} from "forge-std/Vm.sol";
import {HyperCore, ICoreDepositWallet} from "../hyperliquid/HyperCore.sol";
import {IDeltaNeutral} from "../hyperliquid/IDeltaNeutral.sol";
import {DeltaNeutralStrategy} from "../hyperliquid/DeltaNeutralStrategy.sol";
import {HyperCoreDeltaNeutralVault as Vault} from "../hyperliquid/HyperCoreDeltaNeutralVault.sol";
import {HyperCoreSim, SimUSDC, SimDepositWallet} from "./utils/HyperCoreSim.sol";

/**
 * Deployability, checked where the tests run.
 *
 * `forge test` does not enforce EIP-170 or EIP-3860, and HyperCoreDeltaNeutralVault passed its whole
 * suite at 29,025 bytes of runtime code - 4,449 over the limit, undeployable on any EVM chain. These
 * tests measure what a deployment would actually meet: the vault's runtime code as deployed (with its
 * immutables filled in), the strategy library's runtime and creation code, and each creation code
 * together with its real constructor arguments. The sizes are compiled with the repository's own
 * optimizer settings, because `forge test` compiles with them.
 *
 * They also pin what the split into a linked library must not change: the strategy runs as the vault,
 * and nobody can drive the library's state-changing functions except by DELEGATECALL, on their own
 * storage and their own HyperCore account.
 */
contract HyperCoreContractSizeTest is Governed {
    uint256 constant EIP170_RUNTIME = 24_576;
    uint256 constant EIP3860_INITCODE = 49_152;

    SimUSDC usdc;
    HyperCoreSim sim;
    SimDepositWallet cdw;

    function setUp() public {
        usdc = new SimUSDC();
        sim = new HyperCoreSim(usdc);
        sim.install();
        cdw = new SimDepositWallet(sim, usdc);
        sim.setDepositWallet(cdw);
    }

    function _params() internal pure returns (IDeltaNeutral.Params memory) {
        return IDeltaNeutral.Params({
            targetLeverageBps: 20_000,
            maxLeverageBps: 30_000,
            slippageBps: 30,
            deltaToleranceBps: 200,
            maxSpotDeviationBps: 100,
            idleBufferBps: 1_000,
            maxDrawdownBps: 300,
            exitFeeBps: 20,
            fundingPauseE8: 0,
            fundingUnwindE8: -1_141,
            fundingTau: 84 hours,
            minActionInterval: 60,
            settleSeconds: 5,
            maxOrderNotional: 25_000e6,
            maxDailyTurnover: 200_000e6,
            depositCap: 1_000_000e6
        });
    }

    function _ctorArgs() internal view returns (bytes memory) {
        return abi.encode(
            "Delta-neutral ETH (Hyperliquid)", "dnETH", IERC20(address(usdc)), ICoreDepositWallet(address(cdw)),
            uint32(1), uint32(151), address(1), address(2), address(3), DELAY, _params()
        );
    }

    function _report(string memory name, uint256 runtime, uint256 initcode) internal {
        emit log_named_uint(string.concat(name, " runtime bytes"), runtime);
        emit log_named_uint(string.concat(name, " runtime headroom"), EIP170_RUNTIME - runtime);
        emit log_named_uint(string.concat(name, " initcode bytes"), initcode);
        assertLe(runtime, EIP170_RUNTIME, string.concat(name, ": runtime over EIP-170"));
        assertLe(initcode, EIP3860_INITCODE, string.concat(name, ": initcode over EIP-3860"));
    }

    function test_TheVaultAsDeployedFitsEIP170AndEIP3860() public {
        bytes memory args = _ctorArgs();
        Vault vault = new Vault(
            "Delta-neutral ETH (Hyperliquid)", "dnETH", IERC20(address(usdc)), ICoreDepositWallet(address(cdw)),
            1, 151, address(1), address(2), address(3), DELAY, _params()
        );
        uint256 initcode = vm.getCode("HyperCoreDeltaNeutralVault.sol:HyperCoreDeltaNeutralVault").length + args.length;
        _report("HyperCoreDeltaNeutralVault", address(vault).code.length, initcode);
    }

    function test_TheStrategyLibraryFitsEIP170AndEIP3860() public {
        bytes memory creation = vm.getCode("DeltaNeutralStrategy.sol:DeltaNeutralStrategy");
        address lib = _create(creation);
        _report("DeltaNeutralStrategy", lib.code.length, creation.length);
    }

    /// The other contracts this work added, measured the same way from their creation code.
    function test_TheOtherYieldContractsFitEIP170AndEIP3860() public {
        string[2] memory names = [
            string("KeeperGate.sol:KeeperGate"),
            string("SuperstateUSTBAdapter.sol:SuperstateUSTBAdapter")
        ];
        for (uint256 i; i < names.length; ++i) {
            uint256 runtime = vm.getDeployedCode(names[i]).length;
            // Constructor arguments are a handful of words for both; allow a generous kilobyte.
            _report(names[i], runtime, vm.getCode(names[i]).length + 1_024);
        }
    }

    /**
     * Solc guards a library's state-changing functions so they revert unless DELEGATECALLed. Called
     * directly, the strategy's entry points do nothing to anyone: there is no way to aim them at the
     * vault's storage or its HyperCore account from outside.
     */
    function test_TheStrategyLibraryCannotBeCalledDirectly() public {
        address lib = _create(vm.getCode("DeltaNeutralStrategy.sol:DeltaNeutralStrategy"));
        IDeltaNeutral.Market memory m = IDeltaNeutral.Market({
            usdc: IERC20(address(usdc)), depositWallet: ICoreDepositWallet(address(cdw)), perp: 1, spotMarket: 151,
            spotToken: 221, perpSzDecimals: 4, spotSzDecimals: 4, spotWeiDecimals: 9, maxLeverage: 25
        });
        // The same encoding reaches a view function without trouble, so the reverts below are the
        // guard's and not a malformed call's.
        (bool viewOk,) = lib.call(abi.encodeWithSelector(DeltaNeutralStrategy.totalAssets.selector, m));
        assertTrue(viewOk, "views are callable directly");
        bytes4[5] memory selectors = [
            DeltaNeutralStrategy.rebalance.selector,
            DeltaNeutralStrategy.harvest.selector,
            DeltaNeutralStrategy.processExits.selector,
            DeltaNeutralStrategy.deleverage.selector,
            DeltaNeutralStrategy.sampleFunding.selector
        ];
        for (uint256 i; i < selectors.length; ++i) {
            // Slot 0 as the storage pointer; the call must not get as far as reading it.
            (bool ok, bytes memory ret) = lib.call(abi.encodeWithSelector(selectors[i], uint256(0), m));
            assertFalse(ok, "a direct call to a state-changing strategy function must revert");
            // Solc's library call guard reverts with no data, before any strategy code (which would
            // revert with a custom error, or act) runs.
            assertEq(ret.length, 0, "stopped by the call guard, not by the strategy");
        }
        assertEq(sim.pendingCount(), 0, "and it reached CoreWriter with nothing");
    }

    /// The strategy runs as the vault: its CoreWriter actions and its events are the vault's own.
    function test_TheStrategyActsAsTheVaultItself() public {
        vm.warp(1_789_000_000);
        Vault vault = new Vault(
            "Delta-neutral ETH (Hyperliquid)", "dnETH", IERC20(address(usdc)), ICoreDepositWallet(address(cdw)),
            1, 151, address(this), address(this), address(this), DELAY, _params()
        );
        vault.completeSetup();
        usdc.mint(address(this), 100_000e6);
        usdc.approve(address(vault), type(uint256).max);
        vault.deposit(100_000e6, address(this));

        // First step: bridge a little USDC to create the vault's HyperCore account.
        vm.expectEmit(address(vault));
        emit IDeltaNeutral.CoreAction("bridge USDC to spot", 0);
        vault.rebalance();
        sim.processBlock();
        vm.warp(block.timestamp + 61);

        assertGt(sim.spotOf(address(vault), 0), 0, "the HyperCore balance belongs to the vault");

        // Second step: CoreWriter sees the vault as the sender (RawAction's indexed `user`), because
        // the library's code ran in the vault's context.
        vm.recordLogs();
        vault.rebalance();
        Vm.Log[] memory logs = vm.getRecordedLogs();
        uint256 raw;
        for (uint256 i; i < logs.length; ++i) {
            if (logs[i].emitter != HyperCore.CORE_WRITER) continue;
            ++raw;
            assertEq(address(uint160(uint256(logs[i].topics[1]))), address(vault), "CoreWriter's user is the vault");
        }
        assertGt(raw, 0, "the step reached CoreWriter");
    }

    function _create(bytes memory creation) internal returns (address a) {
        assembly {
            a := create(0, add(creation, 0x20), mload(creation))
        }
        require(a != address(0), "create failed");
    }
}
