// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import {IssuerFreeze} from "../common/IssuerFreeze.sol";

/// Exposes the internal library so each probe runs as its own call with a measurable gas budget.
contract FreezeProbe {
    function isFrozen(address token, address who) external view returns (bool) {
        return IssuerFreeze.isFrozen(token, who);
    }
}

contract TetherList {
    mapping(address => bool) public isBlackListed;
    function list(address who) external { isBlackListed[who] = true; }
}

contract CircleList {
    mapping(address => bool) internal _listed;
    function isBlacklisted(address who) external view returns (bool) { return _listed[who]; }
    function list(address who) external { _listed[who] = true; }
}

/// WETH's shape: an unknown selector lands in a payable fallback that writes storage. Under
/// STATICCALL that is an exceptional halt, which burns every unit of gas the call was given.
contract WethLike {
    mapping(address => uint256) public balanceOf;
    fallback() external payable { balanceOf[msg.sender] += msg.value; }
}

contract RevertsEverything {
    fallback() external { revert("no"); }
}

/// Answers `true` in a malformed way: one byte instead of a word.
contract ShortAnswer {
    fallback() external {
        assembly {
            mstore(0, 0x0100000000000000000000000000000000000000000000000000000000000000)
            return(0, 1)
        }
    }
}

contract IssuerFreezeTest is Test {
    FreezeProbe probe = new FreezeProbe();
    address who = makeAddr("who");

    function test_ReadsTethersList() public {
        TetherList t = new TetherList();
        assertFalse(probe.isFrozen(address(t), who));
        t.list(who);
        assertTrue(probe.isFrozen(address(t), who));
    }

    function test_ReadsCirclesList() public {
        CircleList c = new CircleList();
        assertFalse(probe.isFrozen(address(c), who));
        c.list(who);
        assertTrue(probe.isFrozen(address(c), who));
    }

    function test_ATokenWithoutAListIsNeverFrozen() public {
        assertFalse(probe.isFrozen(address(new RevertsEverything()), who));
        assertFalse(probe.isFrozen(address(new ShortAnswer()), who), "a malformed answer is not a yes");
        assertFalse(probe.isFrozen(makeAddr("an EOA, not a token"), who));
    }

    /// Uncapped, asking WETH would leave the caller 1/64 of its gas. Capped, it costs the cap at most.
    function test_AStateWritingFallbackCannotStarveTheCaller() public {
        WethLike weth = new WethLike();
        uint256 before = gasleft();
        assertFalse(probe.isFrozen{gas: 1_000_000}(address(weth), who));
        uint256 used = before - gasleft();
        assertLt(used, 2 * IssuerFreeze.PROBE_GAS + 20_000, "at most both capped probes were spent");
    }
}

/// Against the real tokens: the lists are read, and the cap is ample for both. Skips without FORK_RPC.
contract IssuerFreezeForkTest is Test {
    address constant USDT = 0xdAC17F958D2ee523a2206206994597C13D831ec7;
    address constant USDC = 0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48;
    address constant WETH = 0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2;
    FreezeProbe probe;
    bool live;

    function setUp() public {
        string memory rpc = vm.envOr("FORK_RPC", string(""));
        if (bytes(rpc).length == 0) return;
        vm.createSelectFork(rpc);
        probe = new FreezeProbe();
        live = true;
    }

    function test_RealTetherAndCircleListsAreReadWithinTheCap() public {
        if (!live) return;
        address someone = makeAddr("someone");
        assertFalse(probe.isFrozen(USDT, someone));
        assertFalse(probe.isFrozen(USDC, someone));

        vm.prank(_owner(USDT));
        (bool ok,) = USDT.call(abi.encodeWithSignature("addBlackList(address)", someone));
        assertTrue(ok, "Tether's owner listed the address");
        assertTrue(probe.isFrozen(USDT, someone), "USDT: listed");

        (, bytes memory b) = USDC.staticcall(abi.encodeWithSignature("blacklister()"));
        vm.prank(abi.decode(b, (address)));
        (ok,) = USDC.call(abi.encodeWithSignature("blacklist(address)", someone));
        assertTrue(ok, "Circle's blacklister listed the address");
        assertTrue(probe.isFrozen(USDC, someone), "USDC: listed, through its proxy");

        // A fresh address, so the list slot is cold: each answer well inside the cap.
        for (uint256 i; i < 2; ++i) {
            (address token, bytes4 sel) = i == 0 ? (USDT, IssuerFreeze.TETHER) : (USDC, IssuerFreeze.CIRCLE);
            uint256 g = gasleft();
            (ok,) = token.staticcall{gas: IssuerFreeze.PROBE_GAS}(abi.encodeWithSelector(sel, makeAddr(i == 0 ? "cold-t" : "cold-c")));
            uint256 used = g - gasleft();
            assertTrue(ok, "answered within the cap");
            emit log_named_uint(i == 0 ? "USDT isBlackListed gas" : "USDC isBlacklisted gas", used);
            assertLt(used, IssuerFreeze.PROBE_GAS / 2, "with at least half the cap to spare");
        }
    }

    function test_RealWethCostsTheCapNotTheTransaction() public {
        if (!live) return;
        uint256 g = gasleft();
        assertFalse(probe.isFrozen{gas: 500_000}(WETH, makeAddr("someone")));
        assertLt(g - gasleft(), 2 * IssuerFreeze.PROBE_GAS + 20_000);
    }

    function _owner(address token) private view returns (address) {
        (, bytes memory b) = token.staticcall(abi.encodeWithSignature("owner()"));
        return abi.decode(b, (address));
    }
}
