// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import {ShieldedNoteLog} from "../ShieldedNoteLog.sol";

contract ShieldedNoteLogTest is Test {
    ShieldedNoteLog internal noteLog;

    address internal alice = address(0xA11CE);
    address internal bob = address(0xB0B);
    bytes32 internal constant CHAIN = keccak256("pool:2025-01:r0");

    function setUp() public {
        noteLog = new ShieldedNoteLog();
    }

    function _hash(bytes32 chainKey, uint32 seq, bytes32 prev, bytes memory record)
        internal
        pure
        returns (bytes32)
    {
        return keccak256(abi.encode(chainKey, seq, prev, keccak256(record)));
    }

    function test_AppendsAndChains() public {
        vm.startPrank(alice);
        bytes32 h0 = noteLog.appendNote(CHAIN, 0, bytes32(0), "note-0");
        assertEq(h0, _hash(CHAIN, 0, bytes32(0), "note-0"));

        bytes32 h1 = noteLog.appendNote(CHAIN, 1, h0, "note-1");
        vm.stopPrank();

        (bytes32 head, uint32 count) = noteLog.headOf(alice, CHAIN);
        assertEq(head, h1);
        assertEq(count, 2);
    }

    /// The chain must be impossible to rewind, not merely detectable after the fact.
    function test_RejectsSequenceReuse() public {
        vm.startPrank(alice);
        bytes32 h0 = noteLog.appendNote(CHAIN, 0, bytes32(0), "note-0");
        noteLog.appendNote(CHAIN, 1, h0, "note-1");

        vm.expectRevert(abi.encodeWithSelector(ShieldedNoteLog.WrongSequence.selector, 2, 1));
        noteLog.appendNote(CHAIN, 1, h0, "substituted");
        vm.stopPrank();
    }

    function test_RejectsSequenceGap() public {
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(ShieldedNoteLog.WrongSequence.selector, 0, 3));
        noteLog.appendNote(CHAIN, 3, bytes32(0), "note-3");
    }

    function test_RejectsStalePrevHash() public {
        vm.startPrank(alice);
        bytes32 h0 = noteLog.appendNote(CHAIN, 0, bytes32(0), "note-0");
        // Extending from something other than the true head means the writer has not seen
        // the current history.
        vm.expectRevert(
            abi.encodeWithSelector(ShieldedNoteLog.WrongPrevHash.selector, h0, bytes32(0))
        );
        noteLog.appendNote(CHAIN, 1, bytes32(0), "note-1");
        vm.stopPrank();
    }

    function test_RejectsEmptyRecord() public {
        vm.prank(alice);
        vm.expectRevert(ShieldedNoteLog.EmptyRecord.selector);
        noteLog.appendNote(CHAIN, 0, bytes32(0), "");
    }

    function test_ChainsAreScopedPerOwner() public {
        vm.prank(alice);
        noteLog.appendNote(CHAIN, 0, bytes32(0), "alice-note");
        // Bob's chain under the same key is independent and starts empty.
        vm.prank(bob);
        noteLog.appendNote(CHAIN, 0, bytes32(0), "bob-note");

        (bytes32 aliceHead, uint32 aliceCount) = noteLog.headOf(alice, CHAIN);
        (bytes32 bobHead, uint32 bobCount) = noteLog.headOf(bob, CHAIN);
        assertEq(aliceCount, 1);
        assertEq(bobCount, 1);
        assertTrue(aliceHead != bobHead, "different records must yield different heads");
    }

    function test_EmitsTheRecordForIndexers() public {
        vm.prank(alice);
        vm.expectEmit(true, true, false, true);
        emit ShieldedNoteLog.NoteAppended(
            alice, CHAIN, 0, bytes32(0), _hash(CHAIN, 0, bytes32(0), "note-0"), "note-0"
        );
        noteLog.appendNote(CHAIN, 0, bytes32(0), "note-0");
    }

    function test_BatchAppendMatchesIndividualAppends() public {
        bytes[] memory batch = new bytes[](3);
        batch[0] = "n0";
        batch[1] = "n1";
        batch[2] = "n2";

        vm.prank(alice);
        bytes32 batched = noteLog.appendNotes(CHAIN, 0, bytes32(0), batch);

        vm.startPrank(bob);
        bytes32 h = noteLog.appendNote(CHAIN, 0, bytes32(0), "n0");
        h = noteLog.appendNote(CHAIN, 1, h, "n1");
        h = noteLog.appendNote(CHAIN, 2, h, "n2");
        vm.stopPrank();

        assertEq(batched, h, "batching must produce the identical chain");
        (, uint32 count) = noteLog.headOf(alice, CHAIN);
        assertEq(count, 3);
    }

    function test_BatchRejectsWrongStart() public {
        bytes[] memory batch = new bytes[](1);
        batch[0] = "n0";
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(ShieldedNoteLog.WrongSequence.selector, 0, 5));
        noteLog.appendNotes(CHAIN, 5, bytes32(0), batch);
    }

    function testFuzz_ChainIsAppendOnly(uint8 n) public {
        vm.assume(n > 0 && n < 25);
        vm.startPrank(alice);
        bytes32 head = bytes32(0);
        for (uint32 i; i < n; i++) {
            head = noteLog.appendNote(CHAIN, i, head, abi.encodePacked("note", i));
        }
        vm.stopPrank();

        (bytes32 storedHead, uint32 count) = noteLog.headOf(alice, CHAIN);
        assertEq(count, n);
        assertEq(storedHead, head);

        // No sequence below the count can be written again, at any prevHash.
        vm.startPrank(alice);
        for (uint32 i; i < n; i++) {
            vm.expectRevert();
            noteLog.appendNote(CHAIN, i, head, "rewrite");
        }
        vm.stopPrank();
    }

    function test_HoldsNoValue() public {
        vm.deal(alice, 1 ether);
        vm.prank(alice);
        (bool ok,) = address(noteLog).call{value: 1 ether}("");
        assertFalse(ok, "note log must reject ether");
        assertEq(address(noteLog).balance, 0);
    }
}
