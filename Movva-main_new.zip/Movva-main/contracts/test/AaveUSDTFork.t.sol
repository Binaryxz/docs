// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Governed} from "./utils/Governed.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {IERC4626} from "@openzeppelin/contracts/interfaces/IERC4626.sol";
import {ERC4626} from "@openzeppelin/contracts/token/ERC20/extensions/ERC4626.sol";
import {YieldVault} from "../yield/YieldVault.sol";
import {ERC4626Adapter} from "../yield/adapters/ERC4626Adapter.sol";
import {KeeperGate, IKeeperVault} from "../yield/KeeperGate.sol";

/// @dev TetherToken at 0xdAC17F958D2ee523a2206206994597C13D831ec7, from its verified source. No
///      function returns a value, which is why nothing here goes through the typed IERC20 interface.
interface IUSDT {
    function owner() external view returns (address);
    function approve(address spender, uint256 value) external;
    function transfer(address to, uint256 value) external;
    function allowance(address owner, address spender) external view returns (uint256);
    function basisPointsRate() external view returns (uint256);
    function maximumFee() external view returns (uint256);
    function setParams(uint256 newBasisPoints, uint256 newMaxFee) external;
    function isBlackListed(address who) external view returns (bool);
    function addBlackList(address evilUser) external;
    function removeBlackList(address clearedUser) external;
    function destroyBlackFunds(address blackListedUser) external;
    function pause() external;
    function unpause() external;
}

/// @dev Aave v3 Pool 0x87870Bca3F3fD6335C3F4ce8392D69350B4fA4E2 (POOL_REVISION 11 at the time of writing).
interface IAavePool {
    function getConfiguration(address asset) external view returns (uint256);
    function getVirtualUnderlyingBalance(address asset) external view returns (uint128);
    function getReserveNormalizedIncome(address asset) external view returns (uint256);
    function getReserveDeficit(address asset) external view returns (uint256);
    function supply(address asset, uint256 amount, address onBehalfOf, uint16 referralCode) external;
    function borrow(address asset, uint256 amount, uint256 rateMode, uint16 referralCode, address onBehalfOf)
        external;
    function repay(address asset, uint256 amount, uint256 rateMode, address onBehalfOf) external returns (uint256);
    function ADDRESSES_PROVIDER() external view returns (address);
}

interface IAaveAddressesProvider {
    function getACLAdmin() external view returns (address);
    function getACLManager() external view returns (address);
    function getPoolConfigurator() external view returns (address);
}

interface IAaveACLManager {
    function isPoolAdmin(address) external view returns (bool);
    function addEmergencyAdmin(address) external;
}

interface IAaveConfigurator {
    function setSupplyCap(address asset, uint256 newSupplyCap) external;
    function setBorrowCap(address asset, uint256 newBorrowCap) external;
    function setReserveFreeze(address asset, bool freeze) external;
    function setReservePause(address asset, bool paused) external;
}

/// @dev StataTokenV2 behind 0x7Bc3485026Ac48b6cf9BaF0A377477Fff5703Af8.
interface IStata {
    function setPaused(bool paused) external;
    function paused() external view returns (bool);
    function canPause(address actor) external view returns (bool);
    function aToken() external view returns (address);
}

/// @dev The 0xbow Privacy Pools Entrypoint on mainnet.
interface IEntrypointLive {
    function deposit(address asset, uint256 value, uint256 precommitment) external returns (uint256);
    function assetConfig(address asset) external view returns (address, uint256, uint256, uint256);
}

/**
 * USDT yield through Aave v3's USDT wrapper and the generic ERC4626Adapter, on a mainnet fork.
 *
 * ## What is real and what is simulated
 *
 * Deposits, allocations, interest, borrows, repayments and exits all go through the real USDT,
 * the real Aave Pool and the real StataTokenV2 wrapper, unmodified, at whatever rates, caps and
 * liquidity mainnet has at the fork block. Interest is Aave's own: the test only moves the clock.
 *
 * What the issuers would do is done by pranking the issuers' own admin addresses, read from the
 * contracts at the fork block, and calling their own functions. No storage is written:
 *
 *  - **Aave governance** (`AddressesProvider.getACLAdmin()`, checked to be a pool admin) changes a
 *    supply cap, removes the USDT borrow cap so the reserve can be borrowed dry, freezes or pauses
 *    the reserve, and grants itself the emergency-admin role that pauses the wrapper.
 *  - **Tether** (`USDT.owner()`) switches the transfer fee on with `setParams`, blacklists, burns
 *    blacklisted funds with `destroyBlackFunds`, and pauses the token.
 *  - **Test balances** come from forge's `deal`: USDT for depositors, WETH for the borrower.
 *
 * Skips without FORK_RPC. `AAVE_USDT_FORK_BLOCK` pins a block, which needs an archive RPC.
 */
contract AaveUSDTForkTest is Governed {
    address constant USDT = 0xdAC17F958D2ee523a2206206994597C13D831ec7;
    address constant WETH = 0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2;
    address constant STATA = 0x7Bc3485026Ac48b6cf9BaF0A377477Fff5703Af8;
    address constant AAVE_POOL = 0x87870Bca3F3fD6335C3F4ce8392D69350B4fA4E2;
    address constant ENTRYPOINT = 0x6818809EefCe719E480a7526D76bD3e561526b46;

    uint256 constant RAY = 1e27;
    uint256 constant DEPOSIT = 1_000_000e6;
    uint256 constant ALLOCATED = 900_000e6;

    bool live;
    YieldVault vault;
    ERC4626Adapter adapter;
    IAavePool aave = IAavePool(AAVE_POOL);
    address aclAdmin;
    IAaveConfigurator configurator;

    address gov = makeAddr("gov");
    address guardian = makeAddr("guardian");
    address keeper = makeAddr("keeper");
    address alice = makeAddr("alice");
    address bob = makeAddr("bob");
    address borrower = makeAddr("borrower");

    function setUp() public {
        string memory rpc = vm.envOr("FORK_RPC", string(""));
        if (bytes(rpc).length == 0) return;
        uint256 blk = vm.envOr("AAVE_USDT_FORK_BLOCK", uint256(0));
        if (blk == 0) vm.createSelectFork(rpc);
        else vm.createSelectFork(rpc, blk);
        live = true;

        vault = new YieldVault(IERC20(USDT), "Shielded Yield USDT", "syUSDT", gov, guardian, keeper, 1e15, 100, DELAY);
        adapter = new ERC4626Adapter(address(vault), IERC4626(STATA), "Aave v3 USDT (stataUSDT)");
        vm.startPrank(gov);
        vault.addAdapter(adapter, 10_000);
        vault.completeSetup();
        vm.stopPrank();

        IAaveAddressesProvider ap = IAaveAddressesProvider(aave.ADDRESSES_PROVIDER());
        aclAdmin = ap.getACLAdmin();
        configurator = IAaveConfigurator(ap.getPoolConfigurator());
        require(IAaveACLManager(ap.getACLManager()).isPoolAdmin(aclAdmin), "ACL admin is not a pool admin");

        deal(USDT, alice, DEPOSIT);
        deal(USDT, bob, DEPOSIT);
        vm.prank(alice);
        IUSDT(USDT).approve(address(vault), type(uint256).max);
        vm.prank(bob);
        IUSDT(USDT).approve(address(vault), type(uint256).max);
    }

    /*//////////////////////////////////////////////////////////////
                                 HELPERS
    //////////////////////////////////////////////////////////////*/

    function _depositAndAllocate() internal {
        vm.prank(alice);
        vault.deposit(DEPOSIT, alice);
        vm.prank(keeper);
        vault.allocate(adapter, ALLOCATED);
    }

    function _redeemAll(address who) internal returns (uint256 out) {
        uint256 shares = vault.balanceOf(who);
        vm.prank(who);
        out = vault.redeem(shares, who, who);
    }

    function _config() internal view returns (uint256) {
        return aave.getConfiguration(USDT);
    }

    function _supplyCapWhole() internal view returns (uint256) {
        return (_config() >> 116) & ((1 << 36) - 1);
    }

    /// Aave's ReserveDataLegacy, only the fields read here.
    function _rates() internal view returns (uint256 liquidityRate, uint256 borrowRate) {
        (bool ok, bytes memory ret) = AAVE_POOL.staticcall(abi.encodeWithSignature("getReserveData(address)", USDT));
        require(ok, "getReserveData");
        (, , liquidityRate, , borrowRate) = abi.decode(ret, (uint256, uint128, uint128, uint128, uint128));
    }

    function _bps(uint256 rayRate) internal pure returns (uint256) {
        return (rayRate * 10_000) / RAY;
    }

    function _tether() internal view returns (address) {
        return IUSDT(USDT).owner();
    }

    /*//////////////////////////////////////////////////////////////
                         THE SOURCE, AS MAINNET HAS IT
    //////////////////////////////////////////////////////////////*/

    /// The wrapper is a permissionless ERC-4626 over real USDT, and the generic adapter takes it.
    function test_TheGenericAdapterPutsUSDTIntoRealAave() public {
        if (!live) return;
        (uint256 lr, uint256 br) = _rates();
        emit log_named_uint("fork block", block.number);
        emit log_named_uint("wrapper totalAssets (USDT)", IERC4626(STATA).totalAssets() / 1e6);
        emit log_named_uint("reserve available liquidity (USDT)", aave.getVirtualUnderlyingBalance(USDT) / 1e6);
        emit log_named_uint("wrapper maxDeposit, supply-cap room (USDT)", IERC4626(STATA).maxDeposit(address(1)) / 1e6);
        emit log_named_uint("supply rate (bps, APR)", _bps(lr));
        emit log_named_uint("variable borrow rate (bps, APR)", _bps(br));
        emit log_named_uint("reserve deficit (USDT base units)", aave.getReserveDeficit(USDT));

        assertEq(IERC4626(STATA).asset(), USDT);
        assertEq(adapter.asset(), USDT);
        assertFalse(adapter.targetPaused(), "the live wrapper is not paused");
        assertEq(adapter.maxDeposit(), IERC4626(STATA).maxDeposit(address(adapter)));
        assertEq(adapter.depositBlocker(), "");

        _depositAndAllocate();
        assertGt(IERC20(STATA).balanceOf(address(adapter)), 0, "adapter holds real wrapper shares");
        assertEq(IERC20(USDT).balanceOf(address(adapter)), 0, "and no loose USDT");
        assertApproxEqAbs(vault.totalAssets(), DEPOSIT, 2, "worth what went in, less rounding");
        assertEq(vault.decimals(), 12, "six asset decimals plus the six-decimal offset");
    }

    /// Thirty days of Aave interest raise assets-per-share with nobody touching a position.
    function test_RealAaveInterestRaisesAssetsPerShare() public {
        if (!live) return;
        _depositAndAllocate();
        (uint256 lr,) = _rates();
        uint256 sharesBefore = vault.balanceOf(alice);
        uint256 priceBefore = vault.assetsPerShare();
        uint256 assetsBefore = vault.totalAssets();
        uint256 indexBefore = aave.getReserveNormalizedIncome(USDT);

        vm.warp(block.timestamp + 30 days);
        uint256 priceAfter = vault.assetsPerShare();
        uint256 gained = vault.totalAssets() - assetsBefore;

        // The views extrapolate Aave's index. A real supply by someone else writes the index to
        // storage; the vault's value must not change when it does.
        uint256 viewValue = adapter.totalValue();
        deal(USDT, bob, 1_000e6);
        vm.startPrank(bob);
        IUSDT(USDT).approve(AAVE_POOL, 1_000e6);
        aave.supply(USDT, 1_000e6, bob, 0);
        vm.stopPrank();
        assertApproxEqAbs(adapter.totalValue(), viewValue, 1, "the accrued index is the stored index");

        uint256 indexAfter = aave.getReserveNormalizedIncome(USDT);
        uint256 apyBps = ((priceAfter - priceBefore) * 10_000 * 365 days) / (priceBefore * 30 days);
        emit log_named_uint("assetsPerShare before (per 1e12 shares)", priceBefore);
        emit log_named_uint("assetsPerShare after 30 days", priceAfter);
        emit log_named_uint("USDT gained on 900,000 allocated (base units)", gained);
        emit log_named_uint("vault annualised (bps, 90% allocated)", apyBps);
        emit log_named_uint("Aave supply rate at fork (bps)", _bps(lr));
        emit log_named_uint("Aave income index growth (ppm)", ((indexAfter - indexBefore) * 1e6) / indexBefore);

        assertEq(vault.balanceOf(alice), sharesBefore, "no position was touched");
        assertGt(priceAfter, priceBefore, "assets per share rose");
        // Linear accrual at the fork's supply rate on the allocated part, within 1%.
        uint256 expected = (ALLOCATED * lr * 30 days) / (RAY * 365 days);
        assertApproxEqRel(gained, expected, 0.01e18, "the gain is Aave's rate, not something else");

        vault.checkpoint();
        assertEq(vault.highWaterAssetsPerShare(), priceAfter, "the high-water mark follows real yield");
    }

    function test_AnInstantRoundTripReturnsPrincipalPlusInterest() public {
        if (!live) return;
        _depositAndAllocate();
        vm.warp(block.timestamp + 30 days);
        uint256 out = _redeemAll(alice);
        assertGt(out, DEPOSIT, "more came out than went in");
        assertEq(IERC20(USDT).balanceOf(alice), out);
        // The wrapper burns shares rounding up per withdrawal; at most one share of dust is left.
        assertLe(IERC20(STATA).balanceOf(address(adapter)), 1, "the whole position was redeemed in one call");
        emit log_named_uint("USDT out for 1,000,000 in, 30 days", out);
    }

    /// previewRedeem rounds down: the vault never books more than an exit actually pays.
    function test_TheAdapterValuesConservatively() public {
        if (!live) return;
        _depositAndAllocate();
        vm.warp(block.timestamp + 7 days);
        uint256 held = IERC20(STATA).balanceOf(address(adapter));
        uint256 booked = adapter.totalValue();
        assertLe(booked, IERC4626(STATA).convertToAssets(held), "no more than the wrapper's own rate");

        uint256 before = IERC20(USDT).balanceOf(address(vault));
        vm.prank(guardian);
        vault.deallocate(adapter, booked);
        assertEq(IERC20(USDT).balanceOf(address(vault)) - before, booked, "the booked value is exactly what exits");
        assertLe(adapter.totalValue(), 1, "at most a unit of rounding left behind");
    }

    /*//////////////////////////////////////////////////////////////
                               AAVE LIMITS
    //////////////////////////////////////////////////////////////*/

    /**
     * Supply cap. The wrapper's `maxDeposit` is the cap's remaining room, the adapter repeats it for
     * the keeper, and an allocation over it reverts without moving anything.
     *
     * The room is overstated, though. Aave checks the cap after `updateState`, which first books the
     * treasury's share of the interest accrued since the reserve was last touched
     * (`accruedToTreasury`). The wrapper's view reads that figure before it is booked. So allocating
     * exactly `maxDeposit` reverts `SupplyCapExceeded()` whenever the reserve has gone even one block
     * untouched. At the fork's rates that is about 0.36 USDT a second. The keeper therefore stays
     * `capHeadroomBps` below a source's stated capacity (vault-keeper.ts) and treats this revert as
     * "not now".
     */
    function test_TheSupplyCapBoundsAllocationsAndTheAdapterSaysSo() public {
        if (!live) return;
        vm.prank(alice);
        vault.deposit(DEPOSIT, alice);

        uint256 room = IERC4626(STATA).maxDeposit(address(adapter));
        uint256 supplied = _supplyCapWhole() * 1e6 - room;
        uint256 newCap = supplied / 1e6 + 1 + 500_000;
        vm.prank(aclAdmin);
        configurator.setSupplyCap(USDT, newCap);
        // One block with nobody touching the USDT reserve.
        vm.warp(block.timestamp + 12);

        uint256 capacity = adapter.maxDeposit();
        emit log_named_uint("capacity under the lowered cap (USDT base units)", capacity);
        emit log_named_uint("unbooked treasury accrual the view omits (USDT base units)", _unbookedTreasury());
        assertEq(capacity, IERC4626(STATA).maxDeposit(address(adapter)));
        assertGt(capacity, 450_000e6, "about the 500,000 of room the new cap left");
        assertLt(capacity, ALLOCATED);

        // Over the stated room: the wrapper's own ERC-4626 check refuses it.
        vm.prank(keeper);
        vm.expectRevert(
            abi.encodeWithSelector(ERC4626.ERC4626ExceededMaxDeposit.selector, address(adapter), ALLOCATED, capacity)
        );
        vault.allocate(adapter, ALLOCATED);
        assertEq(IERC20(USDT).balanceOf(address(vault)), DEPOSIT, "nothing moved");

        // Exactly the stated room passes the wrapper's check and fails Aave's, by the unbooked
        // treasury accrual...
        vm.prank(keeper);
        vm.expectRevert(bytes4(keccak256("SupplyCapExceeded()")));
        vault.allocate(adapter, capacity);
        // ...and by nothing else: the stated room less that accrual goes in.
        uint256 snap = vm.snapshotState();
        uint256 exact = capacity - _unbookedTreasury() - 1;
        vm.prank(keeper);
        vault.allocate(adapter, exact);
        vm.revertToState(snap);
        // The keeper's default 50 bps of headroom goes in too.
        uint256 planned = capacity - (capacity * 50) / 10_000;
        vm.prank(keeper);
        vault.allocate(adapter, planned);
        assertLe(adapter.maxDeposit(), capacity - planned, "the cap is nearly full");

        // Governance sets the cap below current supply: no room at all, and the adapter says why.
        vm.prank(aclAdmin);
        configurator.setSupplyCap(USDT, newCap - 600_000);
        assertEq(adapter.maxDeposit(), 0);
        assertEq(adapter.depositBlocker(), "target vault accepts no deposits (at its supply cap, frozen or paused)");
        // A supply cap does not limit exits.
        assertGe(_redeemAll(alice), DEPOSIT - 2);
    }

    /// scaledDebt x (borrow index growth) x reserve factor: what updateState will add to the treasury.
    function _unbookedTreasury() internal view returns (uint256) {
        (bool ok, bytes memory ret) = AAVE_POOL.staticcall(abi.encodeWithSignature("getReserveData(address)", USDT));
        require(ok, "getReserveData");
        (, , , uint256 borrowIndex, uint256 borrowRate, , uint256 lastUpdate, , , , address debtToken) = abi.decode(
            ret, (uint256, uint128, uint128, uint128, uint128, uint128, uint40, uint16, address, address, address)
        );
        uint256 debt = IERC20(debtToken).totalSupply();
        uint256 reserveFactor = (_config() >> 64) & 0xffff;
        borrowIndex;
        return (debt * borrowRate * (block.timestamp - lastUpdate) * reserveFactor) / (RAY * 365 days * 10_000);
    }

    /**
     * Borrowers take nearly all of Aave's USDT. The vault's maxWithdraw reports what can leave, a
     * withdrawal of exactly that arrives, a full redemption is refused up front rather than failing
     * half way, and the rest comes out when the borrower repays.
     */
    function test_HighUtilisationLimitsExitsToAavesAvailableLiquidity() public {
        if (!live) return;
        _depositAndAllocate();

        // Borrow the reserve down to 250,000 USDT of liquidity. Aave's USDT borrow cap is below
        // what is available, so governance lifts it first.
        uint256 leave = 250_000e6;
        vm.prank(aclAdmin);
        configurator.setBorrowCap(USDT, 0);
        uint256 debt = aave.getVirtualUnderlyingBalance(USDT) - leave;
        deal(WETH, borrower, 300_000e18);
        vm.startPrank(borrower);
        IERC20(WETH).approve(AAVE_POOL, type(uint256).max);
        aave.supply(WETH, 300_000e18, borrower, 0);
        aave.borrow(USDT, debt, 2, 0, borrower);
        vm.stopPrank();
        (uint256 lr, uint256 br) = _rates();
        emit log_named_uint("borrowed (USDT)", debt / 1e6);
        emit log_named_uint("supply rate at ~100% utilisation (bps)", _bps(lr));
        emit log_named_uint("borrow rate at ~100% utilisation (bps)", _bps(br));

        uint256 aaveLiquid = adapter.maxInstantWithdraw();
        assertLe(aaveLiquid, leave, "the adapter reports Aave's liquidity, not the position");
        assertGt(aaveLiquid, leave - 10e6);
        assertApproxEqAbs(adapter.totalValue(), ALLOCATED, 2, "and still values the whole position");
        uint256 promised = vault.maxWithdraw(alice);
        assertEq(promised, DEPOSIT - ALLOCATED + aaveLiquid);

        uint256 shares = vault.balanceOf(alice);
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(ERC4626.ERC4626ExceededMaxRedeem.selector, alice, shares, vault.maxRedeem(alice)));
        vault.redeem(shares, alice, alice);

        vm.prank(alice);
        vault.withdraw(promised, alice, alice);
        assertEq(IERC20(USDT).balanceOf(alice), promised, "exactly what maxWithdraw promised arrived");
        assertLe(vault.maxWithdraw(alice), 2, "and nothing more is liquid");

        // The borrower repays; the rest of the position is liquid again.
        deal(USDT, borrower, debt + 1_000e6);
        vm.startPrank(borrower);
        IUSDT(USDT).approve(AAVE_POOL, type(uint256).max);
        aave.repay(USDT, type(uint256).max, 2, borrower);
        vm.stopPrank();
        _redeemAll(alice);
        assertGe(IERC20(USDT).balanceOf(alice), DEPOSIT - 2, "every unit came back");
    }

    /// A frozen reserve takes no new supply but pays out: allocations stop, exits do not.
    function test_AFrozenReserveRefusesAllocationsButPaysOut() public {
        if (!live) return;
        _depositAndAllocate();
        vm.prank(aclAdmin);
        configurator.setReserveFreeze(USDT, true);

        assertEq(adapter.maxDeposit(), 0);
        assertEq(adapter.depositBlocker(), "target vault accepts no deposits (at its supply cap, frozen or paused)");
        vm.prank(keeper);
        vm.expectRevert();
        vault.allocate(adapter, 50_000e6);

        assertApproxEqAbs(vault.maxWithdraw(alice), DEPOSIT, 2, "the whole position is still liquid");
        assertGe(_redeemAll(alice), DEPOSIT - 2);
    }

    /**
     * A paused reserve pays nothing. The Aave leg is frozen but still valued (no false loss, no
     * breaker), idle USDT still pays out, the guardian's pull returns zero instead of reverting, and
     * everything exits once Aave unpauses.
     */
    function test_APausedReserveFreezesOnlyTheAaveLeg() public {
        if (!live) return;
        _depositAndAllocate();
        uint256 price = vault.assetsPerShare();
        vm.prank(aclAdmin);
        configurator.setReservePause(USDT, true);

        assertEq(IERC4626(STATA).maxWithdraw(address(adapter)), 0, "the wrapper's own view sees a paused reserve");
        assertEq(adapter.maxInstantWithdraw(), 0);
        assertEq(adapter.maxDeposit(), 0);
        assertEq(vault.assetsPerShare(), price, "a pause is not a loss");
        vault.checkpoint();
        assertFalse(vault.depositsPaused(), "and does not trip the breaker");

        assertEq(vault.maxWithdraw(alice), DEPOSIT - ALLOCATED);
        vm.prank(alice);
        vault.withdraw(DEPOSIT - ALLOCATED, alice, alice);

        vm.prank(guardian);
        vault.deallocate(adapter, ALLOCATED);
        assertApproxEqAbs(adapter.totalValue(), ALLOCATED, 2, "a refused pull moves nothing and reverts nothing");

        vm.prank(aclAdmin);
        configurator.setReservePause(USDT, false);
        _redeemAll(alice);
        assertGe(IERC20(USDT).balanceOf(alice), DEPOSIT - 2);
    }

    /**
     * The wrapper's OWN pause. Its maxWithdraw/maxDeposit do not check it, so they keep promising.
     * The adapter reads `paused()` and does not pass the promise on: without that, the vault's
     * maxWithdraw would include the whole Aave leg and a withdrawal of it would revert.
     */
    function test_TheWrappersOwnPauseIsInvisibleToItsViewsButNotToTheAdapter() public {
        if (!live) return;
        _depositAndAllocate();
        IAaveACLManager acl = IAaveACLManager(IAaveAddressesProvider(aave.ADDRESSES_PROVIDER()).getACLManager());
        vm.prank(aclAdmin);
        acl.addEmergencyAdmin(aclAdmin);
        assertTrue(IStata(STATA).canPause(aclAdmin));
        vm.prank(aclAdmin);
        IStata(STATA).setPaused(true);

        // The wrapper says the position is liquid, and refuses to pay it.
        uint256 wrapperSays = IERC4626(STATA).maxWithdraw(address(adapter));
        assertApproxEqAbs(wrapperSays, ALLOCATED, 2, "the wrapper's view ignores its own pause");
        vm.prank(address(adapter));
        vm.expectRevert(bytes4(keccak256("EnforcedPause()")));
        IERC4626(STATA).withdraw(1e6, address(adapter), address(adapter));

        assertTrue(adapter.targetPaused());
        assertEq(adapter.maxInstantWithdraw(), 0, "the adapter does not repeat the promise");
        assertEq(adapter.maxDeposit(), 0);
        assertEq(adapter.depositBlocker(), "target vault is paused");
        assertEq(vault.maxWithdraw(alice), DEPOSIT - ALLOCATED, "so the vault promises only what is idle");
        vm.prank(alice);
        vault.withdraw(DEPOSIT - ALLOCATED, alice, alice);

        // Called anyway (the guardian pulling), the adapter returns zero without reverting.
        vm.prank(address(vault));
        assertEq(adapter.withdraw(ALLOCATED, address(vault)), 0);

        vm.prank(aclAdmin);
        IStata(STATA).setPaused(false);
        _redeemAll(alice);
        assertGe(IERC20(USDT).balanceOf(alice), DEPOSIT - 2);
    }

    /*//////////////////////////////////////////////////////////////
                               USDT QUIRKS
    //////////////////////////////////////////////////////////////*/

    /// USDT returns nothing and refuses approve(non-zero -> non-zero). forceApprove handles both.
    function test_USDTApprovalsGoThroughForceApprove() public {
        if (!live) return;
        vm.prank(alice);
        (bool ok, bytes memory ret) = USDT.call(abi.encodeWithSignature("approve(address,uint256)", bob, 1));
        assertTrue(ok);
        assertEq(ret.length, 0, "no return value: a typed IERC20.approve would fail to decode");
        vm.prank(alice);
        (ok,) = USDT.call(abi.encodeWithSignature("approve(address,uint256)", bob, 2));
        assertFalse(ok, "approve from a non-zero allowance to a non-zero one reverts");

        // Leave the adapter a stale non-zero allowance to the wrapper, then allocate through it.
        vm.prank(address(adapter));
        IUSDT(USDT).approve(STATA, 1);
        _depositAndAllocate();
        assertEq(IUSDT(USDT).allowance(address(adapter), STATA), 0, "forceApprove reset it, the wrapper used it all");
        assertApproxEqAbs(adapter.totalValue(), ALLOCATED, 2);
    }

    /**
     * Tether switches the transfer fee on, at the most its contract allows (19 bps, 49 USDT cap).
     *
     *  - deposits are refused: they would have minted shares for USDT that never arrived;
     *  - exits from idle work, and the leaver pays the fee;
     *  - an exit that needs the Aave leg reverts, because the vault receives the fee less than it
     *    asked for: until the guardian pulls the leg into idle, which costs the vault one fee;
     *  - allocations revert: the adapter receives less than it must supply;
     *  - the live 0xbow Entrypoint refuses USDT deposits: it forwards the full amount to the pool
     *    and holds no USDT to cover the fee. So zaps into and out of the shielded vault stop at the
     *    pool, whatever this code does.
     */
    function test_ATransferFeeIsRefusedAtTheDoorAndCostsLeaversNotStayers() public {
        if (!live) return;
        _depositAndAllocate();
        // Control: the live Entrypoint takes a USDT deposit before the fee.
        deal(USDT, bob, DEPOSIT + 100e6);
        vm.startPrank(bob);
        IUSDT(USDT).approve(ENTRYPOINT, type(uint256).max);
        IEntrypointLive(ENTRYPOINT).deposit(USDT, 100e6, uint256(keccak256("mova-usdt-fee-control")) % (1 << 250));
        vm.stopPrank();

        vm.prank(_tether());
        IUSDT(USDT).setParams(19, 49);
        assertEq(IUSDT(USDT).basisPointsRate(), 19);
        assertEq(IUSDT(USDT).maximumFee(), 49e6);
        assertEq(uint256(vm.load(USDT, bytes32(uint256(3)))), 19, "slot 3 is basisPointsRate");
        assertEq(uint256(vm.load(USDT, bytes32(uint256(4)))), 49e6, "slot 4 is maximumFee");

        uint256 price = vault.assetsPerShare();
        vm.prank(bob);
        vm.expectRevert(abi.encodeWithSelector(YieldVault.TransferFeeCharged.selector, 10_000e6, 10_000e6 - 19e6));
        vault.deposit(10_000e6, bob);

        vm.prank(alice);
        vault.withdraw(50_000e6, alice, alice);
        assertEq(IERC20(USDT).balanceOf(alice), 50_000e6 - 49e6, "the leaver paid Tether's fee");
        assertEq(vault.assetsPerShare(), price, "the stayers paid nothing");

        uint256 promised = vault.maxWithdraw(alice);
        assertGt(promised, 100_000e6, "maxWithdraw still counts the Aave leg");
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(YieldVault.InsufficientLiquidity.selector, 100_000e6, 100_000e6 - 49e6));
        vault.withdraw(100_000e6, alice, alice);

        vm.prank(keeper);
        vm.expectRevert();
        vault.allocate(adapter, 10_000e6);

        vm.startPrank(bob);
        vm.expectRevert();
        IEntrypointLive(ENTRYPOINT).deposit(USDT, 100e6, uint256(keccak256("mova-usdt-fee")) % (1 << 250));
        vm.stopPrank();

        // The operational answer: pull the leg into idle. One fee, paid by the vault.
        uint256 assetsBefore = vault.totalAssets();
        vm.prank(guardian);
        vault.deallocate(adapter, ALLOCATED);
        assertApproxEqAbs(assetsBefore - vault.totalAssets(), 49e6, 2, "the pull cost one capped fee");
        uint256 out = _redeemAll(alice);
        assertGt(out, DEPOSIT - 50_000e6 - 100e6, "everyone else can leave");
    }

    /// Tether blacklists the adapter. Exits still work: the wrapper pays the vault directly.
    function test_ABlacklistedAdapterCannotFreezeExits() public {
        if (!live) return;
        _depositAndAllocate();
        vm.prank(_tether());
        IUSDT(USDT).addBlackList(address(adapter));
        assertTrue(IUSDT(USDT).isBlackListed(address(adapter)));

        vm.prank(keeper);
        vm.expectRevert();
        vault.allocate(adapter, 50_000e6);

        assertApproxEqAbs(vault.maxWithdraw(alice), DEPOSIT, 2);
        assertGe(_redeemAll(alice), DEPOSIT - 2, "the whole position exited past a blacklisted adapter");
    }

    /**
     * Tether blacklists the VAULT. Nothing an adapter does helps: the vault cannot send USDT, so
     * every holder is frozen. A blacklist does not stop USDT arriving, so the vault used to keep
     * taking deposits it could never repay (SR3-9); it now asks Tether first and refuses, and every
     * ERC-4626 limit reads zero. Tether then burns the vault's idle USDT. That is a real loss, and
     * anyone's checkpoint trips the drawdown breaker. Once the vault is off the list, withdrawals
     * are open under the breaker and holders share what is left: the Aave leg, which Tether could
     * not burn because the vault never held it as USDT.
     */
    function test_ABlacklistedVaultFreezesEveryoneAndABurnTripsTheBreaker() public {
        if (!live) return;
        _depositAndAllocate();
        vm.prank(bob);
        vault.deposit(10_000e6, bob);
        vm.prank(_tether());
        IUSDT(USDT).addBlackList(address(vault));

        uint256 shares = vault.balanceOf(alice);
        vm.prank(alice);
        vm.expectRevert();
        vault.redeem(shares / 10, alice, alice);
        vm.prank(keeper);
        vm.expectRevert();
        vault.allocate(adapter, 1e6);

        assertTrue(vault.frozenByAssetIssuer(), "the vault sees Tether's list");
        assertEq(vault.maxDeposit(bob), 0);
        assertEq(vault.maxWithdraw(alice), 0);
        assertEq(vault.maxRedeem(alice), 0);
        uint256 bobShares = vault.balanceOf(bob);
        vm.prank(bob);
        vm.expectRevert(YieldVault.FrozenByAssetIssuer.selector);
        vault.deposit(10_000e6, bob);
        assertEq(vault.balanceOf(bob), bobShares, "no deposit into a frozen vault");

        uint256 price = vault.assetsPerShare();
        vm.prank(_tether());
        IUSDT(USDT).destroyBlackFunds(address(vault));
        assertEq(IERC20(USDT).balanceOf(address(vault)), 0, "idle USDT burned");
        assertApproxEqAbs(adapter.totalValue(), ALLOCATED, 2, "the Aave leg is untouched");
        uint256 burnt = vault.assetsPerShare();
        assertLt(burnt * 100, price * 90, "a loss of more than 10%");

        vm.expectEmit(address(vault));
        emit YieldVault.CircuitBreakerTripped(burnt, vault.highWaterAssetsPerShare());
        vm.prank(makeAddr("anyone"));
        vault.checkpoint();
        assertTrue(vault.depositsPaused());

        vm.prank(_tether());
        IUSDT(USDT).removeBlackList(address(vault));
        uint256 outA = _redeemAll(alice);
        uint256 outB = _redeemAll(bob);
        emit log_named_uint("alice out after the burn (USDT)", outA / 1e6);
        emit log_named_uint("bob out after the burn (USDT)", outB / 1e6);
        assertApproxEqAbs(outA + outB, ALLOCATED, 2, "holders shared the Aave leg");
        assertApproxEqRel(outB * DEPOSIT, outA * 10_000e6, 1e12, "pro rata: both bore the same loss");

        vm.prank(gov);
        vault.resumeDeposits();
    }

    /// A listing that Tether lifts before burning anything: deposits resume on their own, with no
    /// governor action, because the vault holds no frozen flag of its own - it asks each time.
    function test_AVaultFrozenAndUnfrozenResumesByItself() public {
        if (!live) return;
        _depositAndAllocate();
        vm.prank(_tether());
        IUSDT(USDT).addBlackList(address(vault));
        vm.prank(bob);
        vm.expectRevert(YieldVault.FrozenByAssetIssuer.selector);
        vault.deposit(1_000e6, bob);

        vm.prank(_tether());
        IUSDT(USDT).removeBlackList(address(vault));
        assertFalse(vault.frozenByAssetIssuer());
        vm.prank(bob);
        vault.deposit(1_000e6, bob);
        assertGt(vault.balanceOf(bob), 0, "deposits resumed without a governor");
        assertGt(vault.maxRedeem(alice), 0);
    }

    /// Tether pauses USDT. Views keep working, every transfer stops, a pull returns zero, and
    /// everything exits after the unpause.
    function test_APausedUSDTFreezesTransfersButNotTheVaultsViews() public {
        if (!live) return;
        _depositAndAllocate();
        vm.prank(_tether());
        IUSDT(USDT).pause();

        assertApproxEqAbs(vault.totalAssets(), DEPOSIT, 2, "valuation does not revert");
        vm.prank(alice);
        vm.expectRevert();
        vault.withdraw(1e6, alice, alice);
        vm.prank(guardian);
        vault.deallocate(adapter, 1e6);
        assertApproxEqAbs(adapter.totalValue(), ALLOCATED, 2, "the adapter caught the wrapper's revert");

        vm.prank(_tether());
        IUSDT(USDT).unpause();
        assertGe(_redeemAll(alice), DEPOSIT - 2);
    }

    /*//////////////////////////////////////////////////////////////
                         KEEPER GATE AT SIX DECIMALS
    //////////////////////////////////////////////////////////////*/

    /// The gate's budget is bps of totalAssets in base units, so it needs no decimals: 10% of a
    /// 1,000,000 USDT vault is 100,000e6, charged against real Aave allocations.
    function test_TheKeeperGateBudgetsAUSDTVaultInBaseUnits() public {
        if (!live) return;
        YieldVault v = new YieldVault(IERC20(USDT), "Shielded Yield USDT", "syUSDT", gov, guardian, gov, 1e15, 100, DELAY);
        ERC4626Adapter a = new ERC4626Adapter(address(v), IERC4626(STATA), "Aave v3 USDT (stataUSDT)");
        KeeperGate gate = new KeeperGate(IKeeperVault(address(v)), gov, DELAY, 1_000);
        address op = makeAddr("replica");
        vm.startPrank(gov);
        v.addAdapter(a, 10_000);
        v.setKeeper(address(gate));
        v.completeSetup();
        gate.setOperator(op, true);
        gate.completeSetup();
        vm.stopPrank();
        vm.startPrank(alice);
        IUSDT(USDT).approve(address(v), type(uint256).max);
        v.deposit(DEPOSIT, alice);
        vm.stopPrank();

        assertEq(gate.remainingTurnover(), 100_000e6);
        vm.prank(op);
        gate.allocate(a, 60_000e6);
        vm.prank(op);
        gate.deallocate(a, 20_000e6);
        uint256 left = gate.remainingTurnover();
        assertApproxEqAbs(left, 20_000e6, 1, "both directions count, against assets less a unit of rounding");
        vm.prank(op);
        vm.expectRevert(abi.encodeWithSelector(KeeperGate.TurnoverBudgetExceeded.selector, left + 1, left));
        gate.allocate(a, left + 1);
        vm.warp(block.timestamp + 1 days);
        vm.prank(op);
        gate.allocate(a, 100_000e6 - 10);
        assertApproxEqAbs(a.totalValue(), 140_000e6, 1_000e6, "real wrapper shares, plus a day of interest");
    }
}
