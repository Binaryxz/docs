// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {MovvaBase} from "./MovvaReserve.t.sol";
import {PoolMock, EntrypointMock} from "./ShieldedYieldRouter.t.sol";
import {ShieldedYieldRouter, IShieldedPool} from "../yield/ShieldedYieldRouter.sol";
import {SavingsMovva} from "../movva/SavingsMovva.sol";
import {MovvaReserve} from "../movva/MovvaReserve.sol";

/**
 * sMovva: distributions vest, so yield goes to savers who were there while it vested; the first
 * depositor cannot rob the next; only the reserve adds to it; and the shielded yield router takes it
 * as a plain ERC-4626.
 *
 * Every distribution here is a real `MovvaReserve.distribute` from a reserve above its target ratio,
 * not a mint the test performs: the vesting is tested against what the reserve actually sends.
 */
contract SavingsMovvaTest is MovvaBase {
    address searcher = makeAddr("searcher");

    function setUp() public override {
        super.setUp();
        _mint(1_000_000 * U);
        _save(100_000e18);
        _publishFx(5_940_000); // 110%, above the 108% target: 5,400 Movva a day to distribute
        _warp(1 days);
    }

    function _distribute() internal returns (uint256 toSavings) {
        (toSavings,) = reserve.distribute();
    }

    function test_ADistributionVestsLinearlyOverEightHours() public {
        assertEq(savings.VESTING_PERIOD(), 8 hours);
        assertEq(savings.decimals(), 24, "18 plus the six-decimal offset");
        uint256 shares = savings.balanceOf(saver);
        assertEq(_distribute(), 5_400e18);
        assertEq(savings.totalAssets(), 100_000e18, "nothing counts at once");
        assertEq(savings.unvested(), 5_400e18);

        vm.warp(block.timestamp + 2 hours);
        assertEq(savings.totalAssets(), 101_350e18, "a quarter");
        vm.warp(block.timestamp + 2 hours);
        assertEq(savings.totalAssets(), 102_700e18, "half");
        vm.warp(block.timestamp + 4 hours);
        assertEq(savings.totalAssets(), 105_400e18, "all of it");
        assertEq(savings.unvested(), 0);
        assertApproxEqAbs(savings.previewRedeem(shares), 105_400e18, 1, "the saver's shares carry it");
    }

    /**
     * The sandwich: a searcher with 10x the savers' balance deposits in the block before `distribute`
     * and redeems in the block after. It takes nothing. One block later it has earned twelve seconds
     * of vesting on its share, and the savers who stay for the period earn the rest.
     */
    function test_DepositingJustBeforeAndLeavingJustAfterEarnsNothing() public {
        vm.prank(gateway);
        movva.transfer(searcher, 1_000_000e18);
        vm.startPrank(searcher);
        movva.approve(address(savings), type(uint256).max);
        uint256 shares = savings.deposit(1_000_000e18, searcher);
        vm.stopPrank();

        assertEq(_distribute(), 5_400e18, "saving does not change supply, so the cap is still 5,400");
        vm.prank(searcher);
        uint256 out = savings.redeem(shares, searcher, searcher);
        assertLe(out, 1_000_000e18, "not a wei of the distribution");
        assertApproxEqAbs(out, 1_000_000e18, 1);

        // Same again, leaving one block later: twelve seconds of an eight-hour vest, on 10/11 of the vault.
        vm.warp(block.timestamp + 8 hours);
        _publishFx(fxNow);
        feed.set(1e8, block.timestamp);
        vm.prank(searcher);
        shares = savings.deposit(1_000_000e18, searcher);
        uint256 got = _distribute();
        vm.warp(block.timestamp + 12);
        vm.prank(searcher);
        out = savings.redeem(shares, searcher, searcher);
        uint256 fair = (got * 12 * 1_000_000) / (8 hours * 1_105_400);
        assertApproxEqAbs(out - 1_000_000e18, fair, 1e6, "twelve seconds' worth, pro rata");
        assertLt(out - 1_000_000e18, got / 2_000, "under 0.05% of the distribution");

        // The saver who stayed collects the rest.
        vm.warp(block.timestamp + 8 hours);
        uint256 saverOut = savings.previewRedeem(savings.balanceOf(saver));
        assertGt(saverOut, 100_000e18 + 5_400e18 + got - got / 1_000);
    }

    function test_OnlyTheReserveNotifies() public {
        vm.prank(gov);
        vm.expectRevert(SavingsMovva.NotReserve.selector);
        savings.notifyDistribution(0);
    }

    function test_TheReserveCannotNotifyMovvaItDidNotSend() public {
        vm.prank(address(reserve));
        vm.expectRevert(abi.encodeWithSelector(SavingsMovva.NotFunded.selector, 100_001e18, 100_000e18));
        savings.notifyDistribution(100_001e18);
    }

    function test_TheVestingPeriodIsBoundedAtDeployment() public {
        vm.expectRevert(abi.encodeWithSelector(SavingsMovva.BadVestingPeriod.selector, 1 hours - 1));
        new SavingsMovva(reserve, 1 hours - 1);
        vm.expectRevert(abi.encodeWithSelector(SavingsMovva.BadVestingPeriod.selector, 7 days + 1));
        new SavingsMovva(reserve, 7 days + 1);
        SavingsMovva s = new SavingsMovva(reserve, 7 days);
        assertEq(s.asset(), address(movva));
        assertEq(s.RESERVE(), address(reserve));
    }

    /// Dust savers: the virtual shares would absorb a distribution, so the reserve does not send one.
    function test_NoDistributionIntoAVaultWithLessThanOneShare() public {
        SavingsMovva s2 = new SavingsMovva(reserve, 8 hours);
        _afterDelay(address(reserve), abi.encodeCall(MovvaReserve.setSavings, (address(s2))));
        _warp(0);
        vm.prank(gateway);
        movva.transfer(saver, 1);
        vm.startPrank(saver);
        movva.approve(address(s2), 1);
        s2.deposit(1, saver);
        vm.stopPrank();
        assertEq(s2.totalSupply(), 1e6, "one wei of Movva is 1e6 wei of shares, far under one sMovva");
        vm.expectRevert(SavingsMovva.NoSavers.selector);
        reserve.distribute();
    }

    /// The inflation attack, with the attacker's best donation: the victim loses nothing that matters.
    function test_TheFirstDepositorCannotRobTheNext() public {
        SavingsMovva fresh = new SavingsMovva(reserve, 8 hours);
        address victim = makeAddr("victim");
        vm.startPrank(gateway);
        movva.transfer(searcher, 10_001e18);
        movva.transfer(victim, 10_000e18);
        vm.stopPrank();

        vm.startPrank(searcher);
        movva.approve(address(fresh), 1);
        fresh.deposit(1, searcher);
        movva.transfer(address(fresh), 10_000e18); // the donation
        vm.stopPrank();

        vm.startPrank(victim);
        movva.approve(address(fresh), 10_000e18);
        uint256 shares = fresh.deposit(10_000e18, victim);
        vm.stopPrank();
        assertGt(shares, 0);
        assertApproxEqRel(fresh.previewRedeem(shares), 10_000e18, 1e12, "within a millionth");
        // The attacker's 1e6 share wei stand beside 1e6 virtual ones: half its donation went to them.
        uint256 attacker = fresh.previewRedeem(fresh.balanceOf(searcher));
        assertApproxEqRel(attacker, 5_000e18, 0.001e18, "half the donation lost, nothing won");
    }

    /// Leaving mid-vest pays the vested share and leaves the unvested Movva in place.
    function test_ExitsNeverReachTheUnvestedPart() public {
        _distribute();
        vm.warp(block.timestamp + 4 hours);
        uint256 shares = savings.balanceOf(saver);
        vm.prank(saver);
        uint256 out = savings.redeem(shares, saver, saver);
        assertApproxEqAbs(out, 102_700e18, 1);
        assertGe(movva.balanceOf(address(savings)), savings.unvested(), "what vests is still here");
        assertEq(savings.totalAssets(), movva.balanceOf(address(savings)) - savings.unvested());
    }
}

/**
 * sMovva behind the real ShieldedYieldRouter, with the router test's pool and Entrypoint doubles
 * (which follow upstream PrivacyPool's label, context and processooor rules). A shielded Movva
 * balance becomes a shielded sMovva note; the reserve distributes; after vesting the note zaps back
 * into more shielded Movva, and no address of the user's ever holds either token.
 */
contract SavingsMovvaRouterTest is MovvaBase {
    EntrypointMock ep;
    PoolMock movvaPool;
    PoolMock sharePool;
    ShieldedYieldRouter router;
    address user = makeAddr("user");
    address relayer = makeAddr("relayer");
    uint256 pre = 1;

    function setUp() public override {
        super.setUp();
        ep = new EntrypointMock();
        movvaPool = new PoolMock(address(movva), address(ep));
        sharePool = new PoolMock(address(savings), address(ep));
        ep.register(address(movva), address(movvaPool), 0);
        ep.register(address(savings), address(sharePool), 0);
        router = new ShieldedYieldRouter(address(ep), makeAddr("weth"), gov);
        vm.prank(gov);
        router.setVault(address(savings), true);

        _mint(1_000_000 * U);
        _save(100_000e18);
    }

    function _zap(uint256 note, uint256 value, PoolMock from) internal returns (uint256) {
        bytes memory data = abi.encode(
            ShieldedYieldRouter.Zap({
                vault: address(savings),
                precommitment: ++pre,
                minOut: 0,
                nativeOut: false,
                rescueRecipient: user,
                relayer: relayer,
                relayFee: 0,
                deadline: uint64(block.timestamp + 1 hours)
            })
        );
        IShieldedPool.Withdrawal memory w = IShieldedPool.Withdrawal({processooor: address(router), data: data});
        IShieldedPool.WithdrawProof memory p;
        p.pubSignals[1] = note;
        p.pubSignals[2] = value;
        p.pubSignals[7] = router.context(address(from), data);
        vm.prank(relayer);
        return router.zap(IShieldedPool(address(from)), w, p);
    }

    function _value(PoolMock pool, uint256 note) internal view returns (uint256 v) {
        (, v,) = pool.notes(note);
    }

    function test_ShieldedMovvaZapsIntoSMovvaEarnsAndZapsBack() public {
        // The user's shielded Movva, bought over the on-ramp.
        vm.prank(gateway);
        movva.transfer(user, 50_000e18);
        vm.startPrank(user);
        movva.approve(address(ep), 50_000e18);
        uint256 note = ep.deposit(IERC20(address(movva)), 50_000e18, ++pre);
        vm.stopPrank();

        uint256 shareNote = _zap(note, 50_000e18, movvaPool);
        uint256 shares = _value(sharePool, shareNote);
        assertEq(shares, 50_000e24, "one Movva wei is 1e6 share wei while nothing has been distributed");
        assertEq(movva.balanceOf(user), 0);
        assertEq(savings.balanceOf(user), 0);

        // The real weakens 10% (110%, above the 108% target), and a day later the reserve distributes;
        // the note is untouched.
        _publishFx(5_940_000);
        _warp(1 days);
        (uint256 toSavings,) = reserve.distribute();
        assertEq(toSavings, 5_400e18);
        _warp(8 hours);
        assertEq(_value(sharePool, shareNote), shares, "the note never changes");

        uint256 back = _zap(shareNote, shares, sharePool);
        uint256 expected = (50_000e18 * 5_400e18) / 150_000e18;
        assertApproxEqAbs(_value(movvaPool, back) - 50_000e18, expected, 2, "a third of the distribution, shielded");
        assertEq(movva.balanceOf(address(router)), 0);
        assertEq(savings.balanceOf(address(router)), 0);
        assertEq(movva.balanceOf(user), 0, "never in the open");
    }
}
