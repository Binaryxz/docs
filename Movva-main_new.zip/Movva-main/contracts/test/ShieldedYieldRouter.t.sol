// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {ERC4626} from "@openzeppelin/contracts/token/ERC20/extensions/ERC4626.sol";
import {ShieldedYieldRouter, IShieldedPool} from "../yield/ShieldedYieldRouter.sol";

address constant NATIVE = 0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE;
uint256 constant P = 21888242871839275222246405745257275088548364400416034343698204186575808495617;

contract Token is ERC20 {
    constructor(string memory n) ERC20(n, n) {}

    function mint(address to, uint256 amount) external {
        _mint(to, amount);
    }
}

contract Vault4626 is ERC4626 {
    constructor(IERC20 a) ERC20("vault", "vault") ERC4626(a) {}
}

contract WETHMock is ERC20 {
    constructor() ERC20("WETH", "WETH") {}

    function deposit() external payable {
        _mint(msg.sender, msg.value);
    }

    function withdraw(uint256 amount) external {
        _burn(msg.sender, amount);
        (bool ok,) = msg.sender.call{value: amount}("");
        require(ok, "unwrap");
    }
}

/**
 * A pool that follows upstream PrivacyPool's rules wherever the router depends on them:
 *
 *  - SCOPE and labels are derived exactly as upstream derives them,
 *  - the depositor is recorded per label,
 *  - withdraw requires msg.sender == processooor and checks the proof context against
 *    keccak256(abi.encode(withdrawal, SCOPE)), then pays the processooor,
 *  - a withdrawal spends a note and inserts a successor with the same label,
 *  - ragequit checks the label's depositor and accepts any unspent note of that lineage.
 *
 * Proofs are not verified. Public signal [1] names the note being spent, standing in for its
 * nullifier; the real circuit is exercised by the fork demo.
 */
contract PoolMock {
    struct Note {
        uint256 label;
        uint256 value;
        bool spent;
    }

    address public immutable ASSET;
    address public immutable ENTRYPOINT;
    uint256 public immutable SCOPE;
    uint256 public nonce;
    uint256 public lastNote;
    mapping(uint256 => address) public depositors;
    mapping(uint256 => Note) public notes;

    constructor(address asset_, address entrypoint_) {
        ASSET = asset_;
        ENTRYPOINT = entrypoint_;
        SCOPE = uint256(keccak256(abi.encodePacked(address(this), block.chainid, asset_))) % P;
        lastNote = uint256(uint160(address(this))) << 16;
    }

    function deposit(address depositor, uint256 value, uint256) external payable returns (uint256 id) {
        require(msg.sender == ENTRYPOINT, "only entrypoint");
        uint256 label = uint256(keccak256(abi.encodePacked(SCOPE, ++nonce))) % P;
        depositors[label] = depositor;
        if (ASSET == NATIVE) require(msg.value == value, "value");
        else IERC20(ASSET).transferFrom(msg.sender, address(this), value);
        id = ++lastNote;
        notes[id] = Note(label, value, false);
    }

    function withdraw(IShieldedPool.Withdrawal memory w, IShieldedPool.WithdrawProof memory p) external {
        require(msg.sender == w.processooor, "InvalidProcessooor");
        require(p.pubSignals[7] == uint256(keccak256(abi.encode(w, SCOPE))) % P, "ContextMismatch");
        Note storage n = notes[p.pubSignals[1]];
        uint256 v = p.pubSignals[2];
        require(!n.spent && n.value >= v, "bad note");
        n.spent = true;
        notes[++lastNote] = Note(n.label, n.value - v, false);
        _push(msg.sender, v);
    }

    function ragequit(IShieldedPool.RagequitProof memory p) external {
        uint256 label = p.pubSignals[3];
        require(depositors[label] == msg.sender, "OnlyOriginalDepositor");
        Note storage n = notes[p.pubSignals[0]];
        require(n.label == label && !n.spent && n.value > 0, "InvalidCommitment");
        n.spent = true;
        _push(msg.sender, n.value);
    }

    function _push(address to, uint256 v) internal {
        if (ASSET == NATIVE) {
            (bool ok,) = to.call{value: v}("");
            require(ok, "push");
        } else {
            IERC20(ASSET).transfer(to, v);
        }
    }
}

/// Mirrors upstream Entrypoint: pulls with transferFrom, deducts the vetting fee, and deposits
/// on behalf of msg.sender.
contract EntrypointMock {
    struct Cfg {
        address pool;
        uint256 feeBps;
    }

    mapping(address => Cfg) internal cfg;

    function register(address asset, address pool, uint256 feeBps) external {
        cfg[asset] = Cfg(pool, feeBps);
        if (asset != NATIVE) IERC20(asset).approve(pool, type(uint256).max);
    }

    function assetConfig(address asset) external view returns (address, uint256, uint256, uint256) {
        return (cfg[asset].pool, 0, cfg[asset].feeBps, 0);
    }

    function deposit(uint256 pre) external payable returns (uint256) {
        Cfg memory c = cfg[NATIVE];
        uint256 v = msg.value - (msg.value * c.feeBps) / 10_000;
        return PoolMock(c.pool).deposit{value: v}(msg.sender, v, pre);
    }

    function deposit(IERC20 asset, uint256 value, uint256 pre) external returns (uint256) {
        asset.transferFrom(msg.sender, address(this), value);
        Cfg memory c = cfg[address(asset)];
        uint256 v = value - (value * c.feeBps) / 10_000;
        return PoolMock(c.pool).deposit(msg.sender, v, pre);
    }
}

contract ShieldedYieldRouterTest is Test {
    uint256 constant SHARE_FEE_BPS = 50;

    Token usds;
    WETHMock weth;
    Vault4626 vault;
    Vault4626 wethVault;
    EntrypointMock ep;
    PoolMock usdsPool;
    PoolMock sharePool;
    PoolMock ethPool;
    PoolMock wethSharePool;
    ShieldedYieldRouter router;

    address gov = makeAddr("gov");
    address user = makeAddr("user");
    address relayer = makeAddr("relayer");
    address attacker = makeAddr("attacker");
    uint256 pre = 1;

    function setUp() public {
        usds = new Token("USDS");
        weth = new WETHMock();
        vault = new Vault4626(usds);
        wethVault = new Vault4626(IERC20(address(weth)));
        ep = new EntrypointMock();

        usdsPool = new PoolMock(address(usds), address(ep));
        sharePool = new PoolMock(address(vault), address(ep));
        ethPool = new PoolMock(NATIVE, address(ep));
        wethSharePool = new PoolMock(address(wethVault), address(ep));
        ep.register(address(usds), address(usdsPool), 0);
        ep.register(address(vault), address(sharePool), SHARE_FEE_BPS);
        ep.register(NATIVE, address(ethPool), 0);
        ep.register(address(wethVault), address(wethSharePool), SHARE_FEE_BPS);

        router = new ShieldedYieldRouter(address(ep), address(weth), gov);
        vm.startPrank(gov);
        router.setVault(address(vault), true);
        router.setVault(address(wethVault), true);
        vm.stopPrank();

        // Seed the vaults so share prices are not the degenerate first-deposit case.
        usds.mint(address(this), 1_000e18);
        usds.approve(address(vault), type(uint256).max);
        vault.deposit(1_000e18, address(this));
        vm.deal(address(this), 10 ether);
        weth.deposit{value: 5 ether}();
        weth.approve(address(wethVault), type(uint256).max);
        wethVault.deposit(5 ether, address(this));
    }

    receive() external payable {}

    /*//////////////////////////////////////////////////////////////
                                HELPERS
    //////////////////////////////////////////////////////////////*/

    /// A shielded USDS balance the user owns.
    function _usdsNote(uint256 amount) internal returns (uint256 id) {
        usds.mint(user, amount);
        vm.startPrank(user);
        usds.approve(address(ep), amount);
        id = ep.deposit(IERC20(address(usds)), amount, ++pre);
        vm.stopPrank();
    }

    function _ethNote(uint256 amount) internal returns (uint256 id) {
        vm.deal(user, amount);
        vm.prank(user);
        id = ep.deposit{value: amount}(++pre);
    }

    function _zap(address v, uint256 minOut, bool nativeOut, uint256 fee) internal returns (bytes memory) {
        return abi.encode(
            ShieldedYieldRouter.Zap({
                vault: v,
                precommitment: ++pre,
                minOut: minOut,
                nativeOut: nativeOut,
                rescueRecipient: user,
                relayer: relayer,
                relayFee: fee,
                deadline: uint64(block.timestamp + 1 hours)
            })
        );
    }

    function _proof(PoolMock pool, uint256 note, uint256 value, bytes memory data)
        internal
        view
        returns (IShieldedPool.Withdrawal memory w, IShieldedPool.WithdrawProof memory p)
    {
        w = IShieldedPool.Withdrawal({processooor: address(router), data: data});
        p.pubSignals[1] = note;
        p.pubSignals[2] = value;
        p.pubSignals[7] = router.context(address(pool), data);
    }

    function _zapFrom(PoolMock pool, uint256 note, uint256 value, bytes memory data) internal returns (uint256) {
        (IShieldedPool.Withdrawal memory w, IShieldedPool.WithdrawProof memory p) = _proof(pool, note, value, data);
        vm.prank(relayer);
        return router.zap(IShieldedPool(address(pool)), w, p);
    }

    function _value(PoolMock pool, uint256 note) internal view returns (uint256 v) {
        (, v,) = pool.notes(note);
    }

    function _label(PoolMock pool, uint256 note) internal view returns (uint256 l) {
        (l,,) = pool.notes(note);
    }

    /*//////////////////////////////////////////////////////////////
                               ZAPPING IN
    //////////////////////////////////////////////////////////////*/

    function test_ZapInTurnsAShieldedBalanceIntoShieldedShares() public {
        uint256 note = _usdsNote(1_000e18);
        uint256 expectedShares = vault.previewDeposit(400e18);

        uint256 shareNote = _zapFrom(usdsPool, note, 400e18, _zap(address(vault), 0, false, 0));

        uint256 afterFee = expectedShares - (expectedShares * SHARE_FEE_BPS) / 10_000;
        assertEq(_value(sharePool, shareNote), afterFee, "shares shielded, less the vetting fee");
        assertEq(_value(usdsPool, usdsPool.lastNote()), 600e18, "the rest stays shielded as USDS");

        // Neither the user nor the router holds anything in the open.
        assertEq(usds.balanceOf(user), 0);
        assertEq(vault.balanceOf(user), 0);
        assertEq(usds.balanceOf(address(router)), 0);
        assertEq(vault.balanceOf(address(router)), 0);
    }

    function test_TheRescueRecipientIsRecordedUnderThePoolsOwnLabel() public {
        uint256 note = _usdsNote(100e18);
        uint256 shareNote = _zapFrom(usdsPool, note, 100e18, _zap(address(vault), 0, false, 0));
        uint256 label = _label(sharePool, shareNote);
        assertEq(router.rescueRecipient(address(sharePool), label), user);
        assertEq(sharePool.depositors(label), address(router));
    }

    /*//////////////////////////////////////////////////////////////
                         YIELD AND ZAPPING OUT
    //////////////////////////////////////////////////////////////*/

    /// The whole point: the note does not change, the price does, and leaving pays more.
    function test_YieldCompoundsInsideThePoolAndZapOutReturnsIt() public {
        uint256 note = _usdsNote(1_000e18);
        uint256 shareNote = _zapFrom(usdsPool, note, 1_000e18, _zap(address(vault), 0, false, 0));
        uint256 shares = _value(sharePool, shareNote);

        // Ten percent yield lands in the vault. Nothing about the note is touched.
        usds.mint(address(vault), usds.balanceOf(address(vault)) / 10);
        assertEq(_value(sharePool, shareNote), shares, "the note is unchanged");

        uint256 expected = vault.previewRedeem(shares);
        uint256 usdsNote = _zapFrom(sharePool, shareNote, shares, _zap(address(vault), 0, false, 0));

        assertEq(_value(usdsPool, usdsNote), expected, "every unit of yield comes back shielded");
        assertGt(expected, 1_090e18, "more than went in, after the 0.5% share-pool fee");
        assertEq(usds.balanceOf(user), 0, "and still never in the open");
    }

    function test_NativeEthRoundTrip() public {
        uint256 note = _ethNote(2 ether);
        uint256 shareNote = _zapFrom(ethPool, note, 2 ether, _zap(address(wethVault), 0, false, 0));
        uint256 shares = _value(wethSharePool, shareNote);
        assertGt(shares, 0);

        uint256 back = _zapFrom(wethSharePool, shareNote, shares, _zap(address(wethVault), 0, true, 0));
        // Back in the native pool: the ETH that went in, less the share pool's vetting fee.
        assertApproxEqAbs(_value(ethPool, back), 2 ether - (2 ether * SHARE_FEE_BPS) / 10_000, 2);
        assertEq(address(router).balance, 0);
        assertEq(weth.balanceOf(address(router)), 0);
    }

    function test_NativeOutRequiresAWethVault() public {
        uint256 note = _usdsNote(100e18);
        uint256 shareNote = _zapFrom(usdsPool, note, 100e18, _zap(address(vault), 0, false, 0));
        uint256 shares = _value(sharePool, shareNote);
        bytes memory data = _zap(address(vault), 0, true, 0);
        (IShieldedPool.Withdrawal memory w, IShieldedPool.WithdrawProof memory p) =
            _proof(sharePool, shareNote, shares, data);
        vm.expectRevert(ShieldedYieldRouter.AssetMismatch.selector);
        router.zap(IShieldedPool(address(sharePool)), w, p);
    }

    /*//////////////////////////////////////////////////////////////
                         THE PROOF BINDS THE ZAP
    //////////////////////////////////////////////////////////////*/

    /// A relayer holding the proof cannot swap the parameters: a different vault, minimum,
    /// fee or rescue recipient is a different context, and the pool refuses it.
    function test_ARelayerCannotChangeWhatTheProofAuthorised() public {
        uint256 note = _usdsNote(100e18);
        bytes memory signed = _zap(address(vault), 99e18, false, 1e18);
        (IShieldedPool.Withdrawal memory w, IShieldedPool.WithdrawProof memory p) =
            _proof(usdsPool, note, 100e18, signed);

        ShieldedYieldRouter.Zap memory z = abi.decode(signed, (ShieldedYieldRouter.Zap));
        z.relayFee = 50e18;
        z.minOut = 0;
        w.data = abi.encode(z);

        vm.prank(relayer);
        vm.expectRevert(bytes("ContextMismatch"));
        router.zap(IShieldedPool(address(usdsPool)), w, p);
    }

    function test_TheRouterMustBeTheProcessooor() public {
        uint256 note = _usdsNote(100e18);
        bytes memory data = _zap(address(vault), 0, false, 0);
        (IShieldedPool.Withdrawal memory w, IShieldedPool.WithdrawProof memory p) = _proof(usdsPool, note, 100e18, data);
        w.processooor = attacker;
        vm.expectRevert(ShieldedYieldRouter.WrongProcessooor.selector);
        router.zap(IShieldedPool(address(usdsPool)), w, p);
    }

    function test_TheMinimumOutputIsEnforcedAndNothingMoves() public {
        uint256 note = _usdsNote(100e18);
        bytes memory data = _zap(address(vault), type(uint128).max, false, 0);
        (IShieldedPool.Withdrawal memory w, IShieldedPool.WithdrawProof memory p) = _proof(usdsPool, note, 100e18, data);
        uint256 out = vault.previewDeposit(100e18);
        vm.expectRevert(
            abi.encodeWithSelector(ShieldedYieldRouter.InsufficientOutput.selector, out, uint256(type(uint128).max))
        );
        router.zap(IShieldedPool(address(usdsPool)), w, p);
        (,, bool spent) = usdsPool.notes(note);
        assertFalse(spent, "the note was not spent");
    }

    function test_AnExpiredZapIsRefused() public {
        uint256 note = _usdsNote(100e18);
        bytes memory data = _zap(address(vault), 0, false, 0);
        (IShieldedPool.Withdrawal memory w, IShieldedPool.WithdrawProof memory p) = _proof(usdsPool, note, 100e18, data);
        vm.warp(block.timestamp + 2 hours);
        vm.expectRevert(ShieldedYieldRouter.Expired.selector);
        router.zap(IShieldedPool(address(usdsPool)), w, p);
    }

    function test_AnUnlistedVaultIsRefused() public {
        Vault4626 rogue = new Vault4626(usds);
        uint256 note = _usdsNote(100e18);
        bytes memory data = _zap(address(rogue), 0, false, 0);
        (IShieldedPool.Withdrawal memory w, IShieldedPool.WithdrawProof memory p) = _proof(usdsPool, note, 100e18, data);
        vm.expectRevert(ShieldedYieldRouter.VaultNotAllowed.selector);
        router.zap(IShieldedPool(address(usdsPool)), w, p);
    }

    function test_APoolTheEntrypointDoesNotKnowIsRefused() public {
        PoolMock fake = new PoolMock(address(usds), address(ep));
        bytes memory data = _zap(address(vault), 0, false, 0);
        (IShieldedPool.Withdrawal memory w, IShieldedPool.WithdrawProof memory p) = _proof(fake, 1, 1, data);
        vm.expectRevert(ShieldedYieldRouter.UnknownPool.selector);
        router.zap(IShieldedPool(address(fake)), w, p);
    }

    function test_AVaultForTheWrongAssetIsRefused() public {
        uint256 note = _ethNote(1 ether);
        bytes memory data = _zap(address(vault), 0, false, 0); // a USDS vault, fed ETH
        (IShieldedPool.Withdrawal memory w, IShieldedPool.WithdrawProof memory p) = _proof(ethPool, note, 1 ether, data);
        vm.expectRevert(ShieldedYieldRouter.AssetMismatch.selector);
        router.zap(IShieldedPool(address(ethPool)), w, p);
    }

    function test_TheRelayerIsPaidFromTheWithdrawnFunds() public {
        uint256 note = _usdsNote(100e18);
        uint256 expectedShares = vault.previewDeposit(95e18);
        uint256 shareNote = _zapFrom(usdsPool, note, 100e18, _zap(address(vault), 0, false, 5e18));
        assertEq(usds.balanceOf(relayer), 5e18);
        assertEq(_value(sharePool, shareNote), expectedShares - (expectedShares * SHARE_FEE_BPS) / 10_000);
    }

    function test_AFeeLargerThanTheWithdrawalIsRefused() public {
        uint256 note = _usdsNote(100e18);
        bytes memory data = _zap(address(vault), 0, false, 101e18);
        (IShieldedPool.Withdrawal memory w, IShieldedPool.WithdrawProof memory p) = _proof(usdsPool, note, 100e18, data);
        vm.expectRevert(ShieldedYieldRouter.FeeExceedsAmount.selector);
        router.zap(IShieldedPool(address(usdsPool)), w, p);
    }

    /*//////////////////////////////////////////////////////////////
                              ESCAPE HATCH
    //////////////////////////////////////////////////////////////*/

    function _ragequit(PoolMock pool, uint256 note) internal view returns (IShieldedPool.RagequitProof memory p) {
        p.pubSignals[0] = note;
        p.pubSignals[3] = _label(pool, note);
    }

    function test_TheRouterRescuesAZappedNoteToItsRecipient() public {
        uint256 note = _usdsNote(100e18);
        uint256 shareNote = _zapFrom(usdsPool, note, 100e18, _zap(address(vault), 0, false, 0));
        uint256 shares = _value(sharePool, shareNote);

        IShieldedPool.RagequitProof memory p = _ragequit(sharePool, shareNote);
        vm.prank(user);
        router.rescue(IShieldedPool(address(sharePool)), p);
        assertEq(vault.balanceOf(user), shares, "the shares, which the user can redeem");
    }

    /// The Phase 2 escrow bug, not repeated: the hatch must survive a partial exit.
    function test_TheRescueStillWorksAfterAPartialZapOut() public {
        uint256 note = _usdsNote(1_000e18);
        uint256 shareNote = _zapFrom(usdsPool, note, 1_000e18, _zap(address(vault), 0, false, 0));
        uint256 shares = _value(sharePool, shareNote);

        _zapFrom(sharePool, shareNote, shares / 4, _zap(address(vault), 0, false, 0));
        uint256 successor = sharePool.lastNote();
        assertEq(_label(sharePool, successor), _label(sharePool, shareNote), "same lineage");

        IShieldedPool.RagequitProof memory p = _ragequit(sharePool, successor);
        vm.prank(user);
        router.rescue(IShieldedPool(address(sharePool)), p);
        assertEq(vault.balanceOf(user), shares - shares / 4);
    }

    function test_APublishedRescueProofCannotBeFrontRun() public {
        uint256 note = _usdsNote(100e18);
        uint256 shareNote = _zapFrom(usdsPool, note, 100e18, _zap(address(vault), 0, false, 0));
        IShieldedPool.RagequitProof memory p = _ragequit(sharePool, shareNote);

        vm.prank(attacker);
        vm.expectRevert(ShieldedYieldRouter.NotRecipient.selector);
        router.rescue(IShieldedPool(address(sharePool)), p);
        assertEq(vault.balanceOf(attacker), 0);
    }

    function test_AnUnknownLabelCannotBeRescued() public {
        IShieldedPool.RagequitProof memory p;
        p.pubSignals[3] = 42;
        vm.prank(user);
        vm.expectRevert(ShieldedYieldRouter.UnknownDeposit.selector);
        router.rescue(IShieldedPool(address(sharePool)), p);
    }

    function test_NativeRescuePaysEth() public {
        uint256 note = _ethNote(1 ether);
        uint256 shareNote = _zapFrom(ethPool, note, 1 ether, _zap(address(wethVault), 0, false, 0));
        uint256 shares = _value(wethSharePool, shareNote);
        uint256 back = _zapFrom(wethSharePool, shareNote, shares, _zap(address(wethVault), 0, true, 0));

        IShieldedPool.RagequitProof memory p = _ragequit(ethPool, back);
        uint256 before = user.balance;
        vm.prank(user);
        router.rescue(IShieldedPool(address(ethPool)), p);
        assertEq(user.balance - before, _value(ethPool, back));
    }

    /*//////////////////////////////////////////////////////////////
                               GOVERNANCE
    //////////////////////////////////////////////////////////////*/

    function test_OnlyTheGovernorListsVaults() public {
        vm.prank(attacker);
        vm.expectRevert(ShieldedYieldRouter.NotGovernor.selector);
        router.setVault(attacker, true);
    }

    function test_DelistingAVaultStopsZapsButNotRescues() public {
        uint256 note = _usdsNote(100e18);
        uint256 shareNote = _zapFrom(usdsPool, note, 100e18, _zap(address(vault), 0, false, 0));
        vm.prank(gov);
        router.setVault(address(vault), false);

        uint256 shares = _value(sharePool, shareNote);
        bytes memory data = _zap(address(vault), 0, false, 0);
        (IShieldedPool.Withdrawal memory w, IShieldedPool.WithdrawProof memory p) =
            _proof(sharePool, shareNote, shares, data);
        vm.expectRevert(ShieldedYieldRouter.VaultNotAllowed.selector);
        router.zap(IShieldedPool(address(sharePool)), w, p);

        IShieldedPool.RagequitProof memory rq = _ragequit(sharePool, shareNote);
        vm.prank(user);
        router.rescue(IShieldedPool(address(sharePool)), rq);
        assertEq(vault.balanceOf(user), shares);
    }
}
