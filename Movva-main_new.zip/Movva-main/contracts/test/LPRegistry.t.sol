// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Governed} from "./utils/Governed.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";
import {LPRegistry} from "../ramp/LPRegistry.sol";
import {FiatEscrow} from "../ramp/FiatEscrow.sol";
import {OffRampEscrow} from "../ramp/OffRampEscrow.sol";
import {IAttestorVerifier} from "../ramp/IAttestorVerifier.sol";
import {IPriceOracle} from "../ramp/IPriceOracle.sol";
import {RulingLib} from "../ramp/RulingLib.sol";

/// A second escrow, so reservations from two callers can be told apart.
contract EscrowStub {
    LPRegistry immutable registry;

    constructor(LPRegistry r) {
        registry = r;
    }

    function reserve(address lp, uint256 cents) external returns (bool) {
        return registry.reserveExposure(lp, cents);
    }

    function release(address lp, uint256 cents) external {
        registry.releaseExposure(lp, cents);
    }

    function consume(bytes32 bankTxId) external returns (bool) {
        return registry.consumeBankTxId(bankTxId);
    }
}

contract LPRegistryTest is Governed {
    LPRegistry registry;
    EscrowStub other;

    address gov = makeAddr("gov");
    address inst = makeAddr("inst");
    address inst2 = makeAddr("inst2");
    address aff = makeAddr("aff");
    address aff2 = makeAddr("aff2");
    address retail = makeAddr("retail");

    uint256 constant INST_CREDIT = 1_000_000; // R$10,000

    function setUp() public {
        registry = new LPRegistry(gov, DELAY);
        other = new EscrowStub(registry);
        vm.startPrank(gov);
        // This test contract plays one escrow and EscrowStub the other.
        registry.setEscrow(address(this), true);
        registry.setEscrow(address(other), true);
        registry.setTier(inst, LPRegistry.Tier.INSTITUTIONAL, INST_CREDIT);
        registry.setTier(inst2, LPRegistry.Tier.INSTITUTIONAL, INST_CREDIT);
        registry.completeSetup();
        vm.stopPrank();
    }

    function _open(LPRegistry.Phase p) internal {
        _afterDelay(address(registry), abi.encodeCall(LPRegistry.setPhase, (p)));
    }

    function _reserve(address lp, uint256 cents) internal returns (bool) {
        return registry.reserveExposure(lp, cents);
    }

    function _exposure(address lp) internal view returns (uint256 e) {
        (,,,,,, e) = registry.lps(lp);
    }

    /*//////////////////////////////////////////////////////////////
                           TIERS AND PHASES
    //////////////////////////////////////////////////////////////*/

    /// Off-chain tooling encodes tiers by index; this order is part of the ABI.
    function test_TheTierOrderIsFixed() public pure {
        assertEq(uint8(LPRegistry.Tier.NONE), 0);
        assertEq(uint8(LPRegistry.Tier.RETAIL), 1);
        assertEq(uint8(LPRegistry.Tier.AFFILIATED), 2);
        assertEq(uint8(LPRegistry.Tier.INSTITUTIONAL), 3);
        assertEq(uint8(LPRegistry.Tier.SUSPENDED), 4);
    }

    /// The previous registry let anyone register as RETAIL on day one.
    function test_PhaseAIsInstitutionalOnly() public {
        assertEq(uint8(registry.phase()), uint8(LPRegistry.Phase.A));
        vm.prank(retail);
        vm.expectRevert(abi.encodeWithSelector(LPRegistry.PhaseNotOpen.selector, LPRegistry.Phase.C));
        registry.register();
        vm.prank(inst);
        vm.expectRevert(abi.encodeWithSelector(LPRegistry.PhaseNotOpen.selector, LPRegistry.Phase.B));
        registry.sponsorAffiliate(aff, 100_000);
        assertTrue(_reserve(inst, INST_CREDIT), "a licensed LP trades from day one");
    }

    function test_OnboardingAnInstitutionWaitsOutTheDelay() public {
        address newcomer = makeAddr("newcomer");
        vm.prank(gov);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, LPRegistry.setTier.selector)
        );
        registry.setTier(newcomer, LPRegistry.Tier.INSTITUTIONAL, INST_CREDIT);
        _afterDelay(
            address(registry), abi.encodeCall(LPRegistry.setTier, (newcomer, LPRegistry.Tier.INSTITUTIONAL, INST_CREDIT))
        );
        assertEq(registry.capOf(newcomer), INST_CREDIT);
    }

    function test_RaisingCreditWaitsButCuttingAndSuspendingDoNot() public {
        vm.startPrank(gov);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, LPRegistry.setTier.selector)
        );
        registry.setTier(inst, LPRegistry.Tier.INSTITUTIONAL, INST_CREDIT + 1);
        registry.setTier(inst, LPRegistry.Tier.INSTITUTIONAL, INST_CREDIT / 2);
        assertEq(registry.capOf(inst), INST_CREDIT / 2);
        registry.setTier(inst, LPRegistry.Tier.SUSPENDED, 0);
        assertEq(registry.capOf(inst), 0);
        // Reinstating is adding risk back.
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, LPRegistry.setTier.selector)
        );
        registry.setTier(inst, LPRegistry.Tier.INSTITUTIONAL, INST_CREDIT / 2);
        vm.stopPrank();
    }

    function test_OpeningAPhaseWaitsButClosingOneIsInstant() public {
        vm.prank(gov);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, LPRegistry.setPhase.selector)
        );
        registry.setPhase(LPRegistry.Phase.C);

        _open(LPRegistry.Phase.C);
        vm.prank(retail);
        registry.register();

        vm.prank(gov);
        registry.setPhase(LPRegistry.Phase.A); // retail is being abused: close it now
        address late = makeAddr("late");
        vm.prank(late);
        vm.expectRevert(abi.encodeWithSelector(LPRegistry.PhaseNotOpen.selector, LPRegistry.Phase.C));
        registry.register();
    }

    /*//////////////////////////////////////////////////////////////
                     PHASE B: SPONSORED AFFILIATES
    //////////////////////////////////////////////////////////////*/

    function test_AnAffiliatesCreditIsCarvedOutOfItsSponsor() public {
        _open(LPRegistry.Phase.B);
        vm.prank(inst);
        registry.sponsorAffiliate(aff, 400_000);

        (LPRegistry.Tier tier,,,, uint256 credit, address sponsor,) = registry.lps(aff);
        assertEq(uint8(tier), uint8(LPRegistry.Tier.AFFILIATED));
        assertEq(sponsor, inst);
        assertEq(credit, 400_000);
        assertEq(registry.availableCents(aff), 400_000);
        assertEq(registry.availableCents(inst), 600_000, "the sponsor gave that headroom up");

        assertFalse(_reserve(aff, 400_001));
        assertFalse(_reserve(inst, 600_001));
        assertTrue(_reserve(aff, 400_000));
        assertTrue(_reserve(inst, 600_000));
        assertEq(registry.groupExposureCents(inst), INST_CREDIT, "the group is exactly at the sponsor's limit");
        assertFalse(_reserve(aff, 1));
        assertFalse(_reserve(inst, 1));
    }

    function test_ASponsorCannotCarveOutMoreThanItHasFree() public {
        _open(LPRegistry.Phase.B);
        vm.prank(inst);
        vm.expectRevert(LPRegistry.CreditExceedsSponsor.selector);
        registry.sponsorAffiliate(aff, INST_CREDIT + 1);

        assertTrue(_reserve(inst, 700_000));
        vm.prank(inst);
        vm.expectRevert(LPRegistry.CreditExceedsSponsor.selector);
        registry.sponsorAffiliate(aff, 300_001);
        vm.prank(inst);
        registry.sponsorAffiliate(aff, 300_000);
        vm.prank(inst);
        vm.expectRevert(LPRegistry.CreditExceedsSponsor.selector);
        registry.sponsorAffiliate(aff2, 1);
    }

    /// Cutting the sponsor's limit below what it carved out still caps the whole group.
    function test_TheGroupNeverExceedsTheSponsorsLimitEvenAfterItIsCut() public {
        _open(LPRegistry.Phase.B);
        vm.startPrank(inst);
        registry.sponsorAffiliate(aff, 400_000);
        registry.sponsorAffiliate(aff2, 400_000);
        vm.stopPrank();
        assertTrue(_reserve(aff, 300_000));

        vm.prank(gov);
        registry.setTier(inst, LPRegistry.Tier.INSTITUTIONAL, 350_000);
        assertFalse(_reserve(aff2, 50_001), "aff2's own carve-out is not enough on its own");
        assertTrue(_reserve(aff2, 50_000));
        assertFalse(_reserve(inst, 1));
        assertEq(registry.groupExposureCents(inst), 350_000);
    }

    function test_SuspendingASponsorStopsItsAffiliatesButNotTheirReleases() public {
        _open(LPRegistry.Phase.B);
        vm.prank(inst);
        registry.sponsorAffiliate(aff, 400_000);
        assertTrue(_reserve(aff, 100_000));

        vm.prank(gov);
        registry.setTier(inst, LPRegistry.Tier.SUSPENDED, 0);
        assertEq(registry.capOf(aff), 0);
        assertFalse(_reserve(aff, 1));

        registry.releaseExposure(aff, 100_000);
        assertEq(_exposure(aff), 0);
        assertEq(registry.groupExposureCents(inst), 0);
    }

    function test_OnlyAnInstitutionSponsorsAndOnlyBlankAddressesJoin() public {
        _open(LPRegistry.Phase.C);
        vm.prank(retail);
        registry.register();

        vm.prank(retail);
        vm.expectRevert(LPRegistry.NotSponsor.selector);
        registry.sponsorAffiliate(aff, 1);

        vm.startPrank(inst);
        vm.expectRevert(LPRegistry.BadAffiliate.selector);
        registry.sponsorAffiliate(retail, 1); // already an LP in its own right
        vm.expectRevert(LPRegistry.BadAffiliate.selector);
        registry.sponsorAffiliate(inst2, 1);
        registry.sponsorAffiliate(aff, 100_000);
        vm.stopPrank();

        vm.prank(inst2);
        vm.expectRevert(LPRegistry.BadAffiliate.selector);
        registry.sponsorAffiliate(aff, 100_000); // someone else's affiliate

        // An affiliate cannot be promoted out from under its sponsor's group while linked.
        bytes memory promote = abi.encodeCall(LPRegistry.setTier, (aff, LPRegistry.Tier.INSTITUTIONAL, 1));
        vm.prank(gov);
        registry.schedule(promote);
        vm.warp(block.timestamp + DELAY);
        vm.prank(gov);
        vm.expectRevert(LPRegistry.BadTier.selector);
        registry.execute(promote);
    }

    function test_RevokingAnAffiliateFreesTheCarveOutOnceItsExposureIsGone() public {
        _open(LPRegistry.Phase.B);
        vm.prank(inst);
        registry.sponsorAffiliate(aff, 400_000);
        assertTrue(_reserve(aff, 150_000));

        vm.prank(inst);
        registry.revokeAffiliate(aff);
        assertEq(registry.carvedOutCents(inst), 0);
        assertEq(registry.capOf(aff), 0);
        // Its live exposure still counts against the group it was taken in...
        assertEq(registry.groupExposureCents(inst), 150_000);
        assertEq(registry.availableCents(inst), INST_CREDIT - 150_000);
        // ...and it cannot join another group until that exposure is released.
        vm.prank(inst2);
        vm.expectRevert(LPRegistry.BadAffiliate.selector);
        registry.sponsorAffiliate(aff, 1);

        registry.releaseExposure(aff, 150_000);
        assertEq(registry.groupExposureCents(inst), 0);
        vm.prank(inst2);
        registry.sponsorAffiliate(aff, 1);
    }

    /*//////////////////////////////////////////////////////////////
                         PHASE C: OPEN RETAIL
    //////////////////////////////////////////////////////////////*/

    function test_PhaseCOpensRetailAtTheBaseCap() public {
        _open(LPRegistry.Phase.C);
        vm.prank(retail);
        registry.register();
        assertEq(registry.capOf(retail), registry.BASE_CAP_CENTS());
        vm.prank(retail);
        vm.expectRevert(LPRegistry.AlreadyRegistered.selector);
        registry.register();
    }

    /// The bypass: many positions each under the cap. The limit is on the total.
    function test_ManySmallReservationsCannotExceedTheCap() public {
        _open(LPRegistry.Phase.C);
        vm.prank(retail);
        registry.register();
        for (uint256 i; i < 5; ++i) {
            assertTrue(i % 2 == 0 ? _reserve(retail, 100_000) : other.reserve(retail, 100_000));
        }
        assertFalse(_reserve(retail, 1), "R$5,000 across both escrows, not R$5,000 each");
        assertFalse(other.reserve(retail, 1));
        assertFalse(registry.canQuote(retail, 1));
    }

    function test_ClosingRetailStopsNewRetailExposureButNotReleases() public {
        _open(LPRegistry.Phase.C);
        vm.prank(retail);
        registry.register();
        assertTrue(_reserve(retail, 200_000));
        vm.prank(gov);
        registry.setPhase(LPRegistry.Phase.B);
        assertFalse(_reserve(retail, 1));
        registry.releaseExposure(retail, 200_000);
        assertEq(_exposure(retail), 0);
    }

    /// Lost disputes still halve the cap; settlements still raise it.
    function test_RetailReputationStillMovesTheCap() public {
        _open(LPRegistry.Phase.C);
        vm.prank(retail);
        registry.register();
        registry.recordSettled(retail, 1_000_000);
        assertEq(registry.capOf(retail), 500_000 + 200_000);
        registry.recordDispute(retail);
        assertEq(registry.capOf(retail), 350_000);
        assertTrue(_reserve(retail, 350_000));
        assertFalse(_reserve(retail, 1));
    }

    /*//////////////////////////////////////////////////////////////
                          WHO MAY RESERVE
    //////////////////////////////////////////////////////////////*/

    function test_OnlyRegisteredEscrowsReserve() public {
        vm.prank(makeAddr("stranger"));
        vm.expectRevert(LPRegistry.NotEscrow.selector);
        registry.reserveExposure(inst, 1);
    }

    /// Otherwise one escrow - or anyone - could wipe the exposure another is holding.
    function test_AnEscrowCanOnlyReleaseWhatItReserved() public {
        assertTrue(_reserve(inst, 800_000));
        other.release(inst, 800_000);
        vm.prank(makeAddr("stranger"));
        registry.releaseExposure(inst, 800_000);
        assertEq(_exposure(inst), 800_000);
        assertFalse(other.reserve(inst, 200_001));
    }

    /// A retired escrow's LPs must not have credit stuck forever.
    function test_ARetiredEscrowCanStillReleaseItsReservations() public {
        assertTrue(other.reserve(inst, 500_000));
        vm.prank(gov);
        registry.setEscrow(address(other), false);
        vm.expectRevert(LPRegistry.NotEscrow.selector);
        other.reserve(inst, 1);
        other.release(inst, 500_000);
        assertEq(_exposure(inst), 0);
    }

    /*//////////////////////////////////////////////////////////////
               ONE BANK TRANSACTION, ONE SETTLEMENT (SRM1-12)
    //////////////////////////////////////////////////////////////*/

    /// The set is the registry's, so a second escrow sees the first one's spend.
    function test_ABankTxIdIsSpentOnceAcrossEscrows() public {
        EscrowStub second = new EscrowStub(registry);
        _afterDelay(address(registry), abi.encodeCall(LPRegistry.setEscrow, (address(second), true)));

        bytes32 id = keccak256("E2E-ONE-PIX");
        assertTrue(other.consume(id), "first spend");
        assertTrue(registry.usedBankTxId(id));
        assertFalse(other.consume(id), "the same escrow again");
        assertFalse(second.consume(id), "another escrow of the same registry");
        assertTrue(second.consume(keccak256("E2E-ANOTHER")), "a different transaction is unaffected");
    }

    /// Otherwise anyone could burn the id of a payment before its proof lands, stranding the order.
    function test_OnlyAnEscrowSpendsABankTxId() public {
        bytes32 id = keccak256("E2E-VICTIM");
        vm.prank(makeAddr("stranger"));
        vm.expectRevert(LPRegistry.NotEscrow.selector);
        registry.consumeBankTxId(id);
        vm.prank(gov);
        vm.expectRevert(LPRegistry.NotEscrow.selector);
        registry.consumeBankTxId(id);
        assertFalse(registry.usedBankTxId(id));
        assertTrue(other.consume(id), "still spendable by the escrow whose proof it is");
    }

    /// Retiring an escrow must not strand its live orders, whose takers may already have paid.
    function test_ARetiredEscrowCanStillSpendABankTxId() public {
        vm.prank(gov);
        registry.setEscrow(address(other), false);
        assertTrue(registry.wasEscrow(address(other)));
        assertTrue(other.consume(keccak256("E2E-LATE")));
    }

    function test_AddingAnEscrowWaitsOutTheDelay() public {
        EscrowStub rogue = new EscrowStub(registry);
        vm.prank(gov);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, LPRegistry.setEscrow.selector)
        );
        registry.setEscrow(address(rogue), true);
    }

    function test_NoReservationsBeforeSetupIsComplete() public {
        LPRegistry fresh = new LPRegistry(gov, DELAY);
        vm.startPrank(gov);
        fresh.setEscrow(address(this), true);
        fresh.setTier(inst, LPRegistry.Tier.INSTITUTIONAL, INST_CREDIT);
        vm.stopPrank();
        vm.expectRevert(DelayedGovernance.SetupIncomplete.selector);
        fresh.reserveExposure(inst, 1);
        assertFalse(fresh.canQuote(inst, 1));
    }

    /*//////////////////////////////////////////////////////////////
                              INVARIANT
    //////////////////////////////////////////////////////////////*/

    /// Whatever the order of reservations, releases, carve-outs and limit cuts, no group ever
    /// holds more than its sponsor's limit at the moment of any successful reservation, and
    /// every LP's exposure is exactly the sum of what the two escrows hold for it.
    function testFuzz_ExposureAccountingHolds(uint256 seed) public {
        _open(LPRegistry.Phase.B);
        vm.startPrank(inst);
        registry.sponsorAffiliate(aff, 300_000);
        registry.sponsorAffiliate(aff2, 300_000);
        vm.stopPrank();
        address[3] memory who = [inst, aff, aff2];

        for (uint256 step; step < 40; ++step) {
            seed = uint256(keccak256(abi.encode(seed, step)));
            address lp = who[seed % 3];
            uint256 cents = (seed >> 8) % 400_000;
            uint256 op = (seed >> 64) % 5;
            if (op == 0) {
                if (_reserve(lp, cents)) {
                    (,,,, uint256 limit,,) = registry.lps(inst);
                    assertLe(registry.groupExposureCents(inst), limit, "group over the sponsor's limit");
                }
            } else if (op == 1) {
                if (other.reserve(lp, cents)) {
                    (,,,, uint256 limit,,) = registry.lps(inst);
                    assertLe(registry.groupExposureCents(inst), limit, "group over the sponsor's limit");
                }
            } else if (op == 2) {
                registry.releaseExposure(lp, cents);
            } else if (op == 3) {
                other.release(lp, cents);
            } else {
                // Cutting the sponsor's limit is instant, and must not break the group bound.
                (,,,, uint256 current,,) = registry.lps(inst);
                uint256 cut = cents % 100_000;
                vm.prank(gov);
                registry.setTier(inst, LPRegistry.Tier.INSTITUTIONAL, current > cut ? current - cut : current);
            }
            uint256 sum;
            for (uint256 k; k < 3; ++k) {
                uint256 held = registry.reservedBy(address(this), who[k]) + registry.reservedBy(address(other), who[k]);
                assertEq(_exposure(who[k]), held, "exposure equals what the escrows hold");
                sum += held;
            }
            assertEq(registry.groupExposureCents(inst), sum, "the group is the sum of its members");
        }
    }
}

/*//////////////////////////////////////////////////////////////
                  THE SAME RULES, THROUGH THE ESCROWS
//////////////////////////////////////////////////////////////*/

contract ExposureOracle is IPriceOracle {
    function brlCentsPerUnit() external view returns (uint256, uint64) {
        return (3_000_000, uint64(block.timestamp)); // R$30,000 per ETH
    }
}

contract ExposureVerifier is IAttestorVerifier {
    mapping(bytes32 => Payment) internal p;

    function setProof(bytes32 id, Payment memory pay) external {
        p[id] = pay;
    }

    function verifyPayment(bytes32 id, bytes calldata) external view returns (Payment memory) {
        require(p[id].amountBrlCents != 0, "not bound");
        return p[id];
    }

    function attestorKind() external pure returns (string memory) {
        return "mock/exposure";
    }

    function provesBankSession() external pure returns (bool) {
        return true;
    }
}

contract ExposureEntrypoint {
    uint256 public constant SCOPE = 7;
    uint256 public nonce;

    function deposit(uint256) external payable returns (uint256) {
        return ++nonce;
    }

    function assetConfig(address) external view returns (address, uint256, uint256, uint256) {
        return (address(this), 0, 0, 0);
    }
}

contract LPExposureThroughEscrowsTest is Governed {
    LPRegistry registry;
    FiatEscrow onramp;
    OffRampEscrow offramp;
    ExposureVerifier verifier;

    address gov = makeAddr("gov");
    address retail = makeAddr("retail");
    address taker = makeAddr("taker");
    address seller = makeAddr("seller");
    bytes32 constant PIX = keccak256("retail@pix");
    uint16 constant PIX_MASK = uint16(1 << uint8(IAttestorVerifier.Rail.PIX));
    uint16 constant BOLETO_MASK = uint16(1 << uint8(IAttestorVerifier.Rail.BOLETO));
    uint256 constant PRICE = 3_000_000;
    uint256 constant ARB = 0xA2B;

    function setUp() public {
        vm.warp(1_700_000_000);
        ExposureOracle oracle = new ExposureOracle();
        ExposureEntrypoint ep = new ExposureEntrypoint();
        verifier = new ExposureVerifier();
        registry = new LPRegistry(gov, DELAY);
        onramp = new FiatEscrow(address(oracle), address(registry), address(ep), address(ep), 500, gov, DELAY, DISPUTE_TIMEOUT, TAKER_DISPUTE_TIMEOUT, MAX_VETTING_FEE_BPS);
        offramp = new OffRampEscrow(address(oracle), address(registry), 500, gov, DELAY, DISPUTE_TIMEOUT);
        vm.startPrank(gov);
        registry.setEscrow(address(onramp), true);
        registry.setEscrow(address(offramp), true);
        registry.setPhase(LPRegistry.Phase.C);
        onramp.setVerifier(address(verifier), true);
        offramp.setVerifier(address(verifier), true);
        onramp.setArbitrator(vm.addr(ARB), true);
        offramp.setArbitrator(vm.addr(ARB), true);
        registry.completeSetup();
        onramp.completeSetup();
        offramp.completeSetup();
        vm.stopPrank();

        vm.prank(retail);
        registry.register(); // R$5,000 of credit
        vm.deal(retail, 10 ether);
        vm.deal(seller, 10 ether);
    }

    /// 0.1 ETH at R$30,000 is R$3,000 - inside the R$5,000 cap on its own.
    function _post() internal returns (bytes32) {
        vm.prank(retail);
        return onramp.postOffer{value: 0.1 ether}(
            address(0), 0.1 ether, PRICE, PIX, 0.01 ether, 0.1 ether, address(verifier), PIX_MASK
        );
    }

    function _exposure() internal view returns (uint256 e) {
        (,,,,,, e) = registry.lps(retail);
    }

    /// The finding: each offer was checked against the cap alone, so N offers were N caps.
    function test_ASecondOfferThatWouldExceedTheLimitIsRefused() public {
        bytes32 first = _post();
        assertEq(_exposure(), 300_000);
        vm.prank(retail);
        vm.expectRevert(FiatEscrow.LPNotEligible.selector);
        onramp.postOffer{value: 0.1 ether}(
            address(0), 0.1 ether, PRICE, PIX, 0.01 ether, 0.1 ether, address(verifier), PIX_MASK
        );

        // Closing the first gives the credit back.
        vm.prank(retail);
        onramp.closeOffer(first);
        assertEq(_exposure(), 0);
        _post();
    }

    /// fundOffer used to skip the credit check entirely.
    function test_ToppingUpAnOfferCountsAgainstTheLimit() public {
        bytes32 offerId = _post();
        vm.prank(retail);
        vm.expectRevert(FiatEscrow.LPNotEligible.selector);
        onramp.fundOffer{value: 0.1 ether}(offerId, 0.1 ether);
        vm.prank(retail);
        onramp.fundOffer{value: 0.05 ether}(offerId, 0.05 ether); // R$1,500 more fits
        assertEq(_exposure(), 450_000);
    }

    /// One limit across both legs of the product.
    function test_OnRampLiquidityAndOffRampClaimsShareOneLimit() public {
        bytes32 offerId = _post(); // R$3,000 held
        vm.prank(seller);
        bytes32 saleId = offramp.openSale{value: 0.1 ether}(
            address(0), 0.1 ether, 300_000, keccak256("seller@pix"), address(verifier), PIX_MASK, seller
        );
        vm.prank(retail);
        vm.expectRevert(OffRampEscrow.LPNotEligible.selector);
        offramp.claimSale(saleId);

        // Half the offer settles; its credit comes back exactly.
        vm.prank(taker);
        bytes32 orderId = onramp.lockOrder(offerId, 0.1 ether, FiatEscrow.Delivery.DIRECT, taker, 0);
        verifier.setProof(
            orderId,
            IAttestorVerifier.Payment({
                bankTxId: keccak256("tx1"), payeeKeyHash: PIX, payerRef: bytes32(0),
                amountBrlCents: 300_000, paidAt: uint64(block.timestamp), rail: IAttestorVerifier.Rail.PIX
            })
        );
        onramp.releaseWithProof(orderId, "");
        assertEq(_exposure(), 0, "settled liquidity is no longer at risk");

        vm.prank(retail);
        offramp.claimSale(saleId);
        assertEq(_exposure(), 300_000);
    }

    /// Every way a claim ends gives the credit back: abandoned, stale, settled, disputed.
    function test_EveryWayAClaimEndsReleasesItsCredit() public {
        vm.prank(seller);
        bytes32 saleId = offramp.openSale{value: 0.1 ether}(
            address(0), 0.1 ether, 300_000, keccak256("seller@pix"), address(verifier), PIX_MASK, seller
        );
        vm.prank(retail);
        offramp.claimSale(saleId);
        vm.prank(retail);
        offramp.abandonClaim(saleId);
        assertEq(_exposure(), 0, "abandoned");

        vm.warp(block.timestamp + offramp.CLAIM_COOLDOWN()); // SRM1-13: the seller's window
        vm.prank(retail);
        offramp.claimSale(saleId);
        vm.warp(block.timestamp + 46 minutes);
        offramp.releaseStaleClaim(saleId);
        assertEq(_exposure(), 0, "stale");

        vm.warp(block.timestamp + offramp.CLAIM_COOLDOWN());
        vm.prank(retail);
        offramp.claimSale(saleId);
        verifier.setProof(
            saleId,
            IAttestorVerifier.Payment({
                bankTxId: keccak256("tx2"), payeeKeyHash: keccak256("seller@pix"), payerRef: bytes32(0),
                amountBrlCents: 300_000, paidAt: uint64(block.timestamp), rail: IAttestorVerifier.Rail.PIX
            })
        );
        offramp.settleWithProof(saleId, "");
        assertEq(_exposure(), 0, "settled");
    }

    /// An order that expires unpaid returns liquidity to the offer, which is still at risk;
    /// the credit is freed when the LP actually withdraws it.
    function test_ExpiredOrdersKeepCreditUntilTheLiquidityLeaves() public {
        bytes32 offerId = _post();
        vm.prank(taker);
        bytes32 orderId = onramp.lockOrder(offerId, 0.05 ether, FiatEscrow.Delivery.DIRECT, taker, 0);
        vm.warp(block.timestamp + 31 minutes);
        onramp.reclaimExpired(orderId);
        assertEq(_exposure(), 300_000);
        vm.prank(retail);
        onramp.closeOffer(offerId);
        assertEq(_exposure(), 0);
        assertEq(registry.reservedBy(address(onramp), retail), 0);
    }


    /*//////////////////////////////////////////////////////////////
         THE BOOKS, THROUGH EVERY WAY AN ORDER OR SALE CAN END
    //////////////////////////////////////////////////////////////*/

    bytes32 internal fuzzOffer;
    bytes32[] internal fuzzOrders;
    bytes32[] internal fuzzSales;
    uint256 internal fuzzStep;
    /// Orders the taker disputed: out of the offer and its credit while disputed (SRM1-4).
    mapping(bytes32 => bool) internal fuzzByTaker;

    function _signRuling(address at, bytes32 id, string memory outcome)
        internal
        view
        returns (RulingLib.Ruling memory r, bytes memory sig)
    {
        r = RulingLib.Ruling(id, outcome, keccak256("evidence"), "fuzzed", uint64(block.timestamp), false);
        bytes32 structHash = keccak256(
            abi.encode(
                keccak256(
                    "Ruling(bytes32 orderId,address escrow,string outcome,bytes32 evidenceRoot,string rationale,uint64 ruledAt,bool byDefault)"
                ),
                r.orderId, at, keccak256(bytes(r.outcome)), r.evidenceRoot, keccak256(bytes(r.rationale)),
                r.ruledAt, r.byDefault
            )
        );
        bytes32 domain = keccak256(
            abi.encode(
                keccak256("EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)"),
                keccak256("PrivacyPoolsBRL-Dispute"), keccak256("1"), block.chainid, at
            )
        );
        (uint8 v, bytes32 rr, bytes32 ss) = vm.sign(ARB, keccak256(abi.encodePacked("\x19\x01", domain, structHash)));
        sig = abi.encodePacked(rr, ss, v);
    }

    function _orderState(bytes32 id) internal view returns (FiatEscrow.OrderState st, uint256 wei_, uint256 cents) {
        (, , wei_, cents,,, st,,,,) = onramp.orders(id);
    }

    function _saleState(bytes32 id) internal view returns (OffRampEscrow.SaleState st, uint256 wei_, uint256 cents) {
        (,, wei_, cents,,,,,,,, st) = offramp.sales(id);
    }

    function _payOrder(bytes32 id, uint256 cents) internal {
        (,, bytes32 commitment) = onramp.boletoOf(id);
        (uint64 issueBy,,) = onramp.boletoOf(id);
        bool boleto = issueBy != 0;
        verifier.setProof(
            id,
            IAttestorVerifier.Payment({
                bankTxId: keccak256(abi.encode(id, ++fuzzStep)),
                payeeKeyHash: boleto ? commitment : PIX,
                payerRef: bytes32(0),
                amountBrlCents: cents,
                paidAt: uint64(block.timestamp),
                rail: boleto ? IAttestorVerifier.Rail.BOLETO : IAttestorVerifier.Rail.PIX
            })
        );
        try onramp.releaseWithProof(id, "") {} catch {}
    }

    /**
     * Drive one offer and a stream of sales through every ending there is - proof, cancel,
     * expiry, stale claim, abandoned claim, a boleto never issued, a RELEASE or REFUND ruling,
     * a dispute that times out - in any order, and check the books after every step: the
     * escrows hold exactly what their live records say, and the registry holds exactly the
     * exposure those records carry. A path that forgot to release credit, or released it twice,
     * breaks an equality here.
     */
    function testFuzz_EveryEndingKeepsTheBooks(uint256 seed) public {
        vm.prank(retail);
        fuzzOffer = onramp.postOffer{value: 0.1 ether}(
            address(0), 0.1 ether, PRICE, PIX, 0.01 ether, 0.1 ether, address(verifier), PIX_MASK | BOLETO_MASK
        );

        for (uint256 step; step < 30; ++step) {
            seed = uint256(keccak256(abi.encode(seed, step)));
            uint256 op = seed % 12;
            uint256 pick = seed >> 16;
            if (op == 0) {
                vm.prank(taker);
                try onramp.lockOrder(fuzzOffer, 0.01 ether + (pick % 3) * 0.01 ether, FiatEscrow.Delivery.DIRECT, taker, 0)
                returns (bytes32 id) {
                    fuzzOrders.push(id);
                } catch {}
            } else if (op == 1) {
                vm.prank(taker);
                try onramp.lockOrderByBoleto(fuzzOffer, 0.01 ether + (pick % 3) * 0.01 ether, FiatEscrow.Delivery.DIRECT, taker, 0)
                returns (bytes32 id) {
                    fuzzOrders.push(id);
                    if (pick % 4 != 0) {
                        vm.prank(retail);
                        onramp.issueBoleto(id, keccak256(abi.encode("boleto", id)));
                    }
                } catch {}
            } else if (fuzzOrders.length > 0 && op <= 5) {
                bytes32 id = fuzzOrders[pick % fuzzOrders.length];
                (FiatEscrow.OrderState st,, uint256 cents) = _orderState(id);
                if (op == 2 && (st == FiatEscrow.OrderState.LOCKED || st == FiatEscrow.OrderState.DISPUTED)) {
                    // A disputed order settles by proof too (SRM1-3); late receipts are refused.
                    _payOrder(id, cents);
                } else if (op == 3 && st == FiatEscrow.OrderState.LOCKED) {
                    address by = pick % 2 == 0 ? taker : retail;
                    vm.prank(by);
                    try onramp.raiseDispute(id, "fuzz") {
                        fuzzByTaker[id] = by == taker;
                    } catch {}
                } else if (op == 4 && st == FiatEscrow.OrderState.DISPUTED) {
                    (RulingLib.Ruling memory r, bytes memory sig) =
                        _signRuling(address(onramp), id, pick % 2 == 0 ? "RELEASE" : "REFUND");
                    try onramp.resolveDispute(id, r, sig) {} catch {}
                    vm.warp(block.timestamp + 1 days);
                    try onramp.resolveDispute(id, r, sig) {} catch {}
                } else if (op == 5) {
                    if (st == FiatEscrow.OrderState.DISPUTED) {
                        vm.warp(block.timestamp + DISPUTE_TIMEOUT);
                        onramp.expireDispute(id);
                    } else if (st == FiatEscrow.OrderState.LOCKED) {
                        if (pick % 2 == 0) {
                            vm.prank(taker);
                            onramp.cancelOrder(id);
                        } else {
                            vm.warp(block.timestamp + 3 days + 1);
                            onramp.reclaimExpired(id);
                        }
                    }
                }
            } else if (op == 6) {
                vm.prank(seller);
                bytes32 id = offramp.openSale{value: 0.02 ether}(
                    address(0), 0.02 ether, 60_000, keccak256("seller@pix"), address(verifier), PIX_MASK, seller
                );
                fuzzSales.push(id);
                vm.prank(retail);
                try offramp.claimSale(id) {} catch {}
            } else if (fuzzSales.length > 0) {
                bytes32 id = fuzzSales[pick % fuzzSales.length];
                (OffRampEscrow.SaleState st,, uint256 cents) = _saleState(id);
                if (op == 7 && st == OffRampEscrow.SaleState.CLAIMED) {
                    verifier.setProof(
                        id,
                        IAttestorVerifier.Payment({
                            bankTxId: keccak256(abi.encode(id, ++fuzzStep)), payeeKeyHash: keccak256("seller@pix"),
                            payerRef: bytes32(0), amountBrlCents: cents, paidAt: uint64(block.timestamp),
                            rail: IAttestorVerifier.Rail.PIX
                        })
                    );
                    try offramp.settleWithProof(id, "") {} catch {}
                } else if (op == 8 && st == OffRampEscrow.SaleState.CLAIMED) {
                    // Refused once the claim is stale (H-04); the claim then ends some other way.
                    vm.prank(pick % 2 == 0 ? seller : retail);
                    try offramp.raiseDispute(id, "fuzz") {} catch {}
                } else if (op == 9 && st == OffRampEscrow.SaleState.DISPUTED) {
                    (RulingLib.Ruling memory r, bytes memory sig) =
                        _signRuling(address(offramp), id, pick % 2 == 0 ? "RELEASE" : "REFUND");
                    try offramp.resolveDispute(id, r, sig) {} catch {}
                    vm.warp(block.timestamp + 1 days);
                    try offramp.resolveDispute(id, r, sig) {} catch {}
                } else if (op == 10 && st == OffRampEscrow.SaleState.DISPUTED) {
                    vm.warp(block.timestamp + DISPUTE_TIMEOUT);
                    offramp.expireDispute(id);
                } else if (op == 11 && st == OffRampEscrow.SaleState.CLAIMED) {
                    if (pick % 2 == 0) {
                        vm.prank(retail);
                        offramp.abandonClaim(id);
                    } else {
                        vm.warp(block.timestamp + 46 minutes);
                        offramp.releaseStaleClaim(id);
                    }
                } else if (op == 11 && st == OffRampEscrow.SaleState.OPEN) {
                    vm.prank(seller);
                    offramp.cancelSale(id);
                }
            }
            _assertBooks();
        }
    }

    function _assertBooks() internal view {
        (,, uint256 available, uint256 locked,,,,,,,,) = onramp.offers(fuzzOffer);
        uint256 live;
        uint256 apart; // disputed by their takers: held for the order alone, outside the offer
        for (uint256 i; i < fuzzOrders.length; ++i) {
            (FiatEscrow.OrderState st, uint256 wei_,) = _orderState(fuzzOrders[i]);
            if (st == FiatEscrow.OrderState.DISPUTED && fuzzByTaker[fuzzOrders[i]]) apart += wei_;
            else if (st == FiatEscrow.OrderState.LOCKED || st == FiatEscrow.OrderState.DISPUTED) live += wei_;
        }
        assertEq(locked, live, "locked liquidity is exactly the live orders in the offer");
        assertEq(address(onramp).balance, available + locked + apart, "the on-ramp holds the offer and the taker-disputed orders");
        uint256 offerCredit = ((available + locked) * PRICE + 1e18 - 1) / 1e18;
        assertEq(registry.reservedBy(address(onramp), retail), offerCredit, "on-ramp credit is the offer's value");

        uint256 held;
        uint256 claimed;
        for (uint256 i; i < fuzzSales.length; ++i) {
            (OffRampEscrow.SaleState st, uint256 wei_, uint256 cents) = _saleState(fuzzSales[i]);
            if (st == OffRampEscrow.SaleState.OPEN || st == OffRampEscrow.SaleState.CLAIMED || st == OffRampEscrow.SaleState.DISPUTED) {
                held += wei_;
            }
            if (st == OffRampEscrow.SaleState.CLAIMED || st == OffRampEscrow.SaleState.DISPUTED) claimed += cents;
        }
        assertEq(address(offramp).balance, held, "the off-ramp holds exactly the live sales");
        assertEq(registry.reservedBy(address(offramp), retail), claimed, "off-ramp credit is the live claims");
        assertEq(_exposure(), offerCredit + claimed, "the LP's exposure is the sum of both");
    }
}
