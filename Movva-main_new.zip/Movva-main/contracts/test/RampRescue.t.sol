// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Governed} from "./utils/Governed.sol";
import {FiatEscrow, IPrivacyPoolRagequit} from "../ramp/FiatEscrow.sol";
import {LPRegistry} from "../ramp/LPRegistry.sol";
import {IAttestorVerifier} from "../ramp/IAttestorVerifier.sol";
import {IPriceOracle} from "../ramp/IPriceOracle.sol";

contract FixedOracle2 is IPriceOracle {
    function brlCentsPerUnit() external view returns (uint256, uint64) {
        return (1_500_000, uint64(block.timestamp));
    }
}

/**
 * A pool that follows PrivacyPool's rules where they matter for the escape hatch:
 *
 *  - labels are computed exactly as the real pool computes them,
 *  - the depositor is recorded per LABEL,
 *  - a private partial withdrawal spends a commitment and inserts a successor with the SAME
 *    label and the remaining value,
 *  - ragequit checks the label's depositor and accepts any unspent commitment in the lineage.
 *
 * The first version of this double keyed everything by commitment - the same wrong key the
 * escrow used - so the test and the code agreed with each other and missed that the rescue
 * stopped working after a user's first partial withdrawal. It also plays the Entrypoint, so
 * the escrow can ask it which pool holds an asset.
 */
contract PoolLike {
    uint256 internal constant P =
        21888242871839275222246405745257275088548364400416034343698204186575808495617;
    uint256 public constant SCOPE = 0xC0FFEE;
    uint256 public nonce;
    mapping(uint256 => address) public depositors;
    mapping(uint256 => uint256) public valueOf;
    mapping(uint256 => uint256) public labelOf;
    mapping(uint256 => bool) public spent;
    uint256 internal nextCommitment = 1000;

    function assetConfig(address) external view returns (address, uint256, uint256, uint256) {
        return (address(this), 0, 0, 0);
    }

    function deposit(uint256) external payable returns (uint256 c) {
        uint256 label = uint256(keccak256(abi.encodePacked(SCOPE, ++nonce))) % P;
        depositors[label] = msg.sender;
        c = ++nextCommitment;
        valueOf[c] = msg.value;
        labelOf[c] = label;
    }

    /// A private partial withdrawal: pay `amount` out and leave the rest in a successor.
    function withdrawPart(uint256 c, uint256 amount, address to) external returns (uint256 successor) {
        require(!spent[c] && valueOf[c] >= amount, "bad withdraw");
        spent[c] = true;
        successor = ++nextCommitment;
        valueOf[successor] = valueOf[c] - amount;
        labelOf[successor] = labelOf[c];
        (bool ok,) = to.call{value: amount}("");
        require(ok, "payout");
    }

    function ragequit(IPrivacyPoolRagequit.RagequitProof memory proof) external {
        uint256 c = proof.pubSignals[0];
        uint256 label = proof.pubSignals[3];
        require(depositors[label] == msg.sender, "OnlyOriginalDepositor");
        require(labelOf[c] == label && valueOf[c] > 0, "not in this lineage");
        require(!spent[c], "already exited");
        spent[c] = true;
        (bool ok,) = msg.sender.call{value: valueOf[c]}("");
        require(ok, "payout");
    }

    receive() external payable {}
}

contract RampRescueTest is Governed {
    FiatEscrow escrow;
    LPRegistry registry;
    PoolLike pool;

    address governor = address(0x60F);
    address lp = makeAddr("lp");
    address victim = makeAddr("victim");
    address attacker = makeAddr("attacker");
    address elsewhere = makeAddr("elsewhere");
    bytes32 constant PIX = keccak256("lp@pix");
    uint16 constant PIX_MASK = uint16(1 << uint8(IAttestorVerifier.Rail.PIX));

    function setUp() public {
        vm.warp(1_700_000_000);
        pool = new PoolLike();
        registry = new LPRegistry(governor, DELAY);
        escrow = new FiatEscrow(
            address(new FixedOracle2()), address(registry), address(pool), address(pool), 500, governor, DELAY, DISPUTE_TIMEOUT,
            TAKER_DISPUTE_TIMEOUT,
            MAX_VETTING_FEE_BPS
        );
        vm.startPrank(governor);
        registry.setEscrow(address(escrow), true);
        registry.setTier(lp, LPRegistry.Tier.INSTITUTIONAL, 100_000_000);
        registry.completeSetup();
        escrow.setVerifier(address(this), true);
        escrow.completeSetup();
        vm.stopPrank();
        vm.deal(lp, 50 ether);
    }

    /// Doubles as the attestor: every proof settles, so these tests are about the rescue path.
    /// The escrow staticcalls this, so the bank transaction id comes from the order, not a counter.
    function verifyPayment(bytes32 orderId, bytes calldata)
        external
        view
        returns (IAttestorVerifier.Payment memory p)
    {
        p = IAttestorVerifier.Payment({
            bankTxId: keccak256(abi.encode(orderId)),
            payeeKeyHash: PIX,
            payerRef: bytes32(uint256(1)),
            amountBrlCents: type(uint256).max,
            paidAt: uint64(block.timestamp),
            rail: IAttestorVerifier.Rail.PIX
        });
    }

    function attestorKind() external pure returns (string memory) {
        return "test";
    }

    function provesBankSession() external pure returns (bool) {
        return true;
    }

    function _shieldedOrder(address recipient) internal returns (bytes32 orderId, uint256 commitment) {
        vm.prank(lp);
        bytes32 offerId = escrow.postOffer{value: 5 ether}(
            address(0), 5 ether, 1_500_000, PIX, 0.01 ether, 2 ether, address(this), PIX_MASK
        );
        vm.prank(recipient);
        orderId = escrow.lockOrder(offerId, 1 ether, FiatEscrow.Delivery.SHIELDED, recipient, 42);
        escrow.releaseWithProof(orderId, "");
        (,,,,,,,,,, commitment) = escrow.orders(orderId);
    }

    function _proofFor(uint256 commitment)
        internal
        view
        returns (IPrivacyPoolRagequit.RagequitProof memory p)
    {
        p.pubSignals[0] = commitment;
        p.pubSignals[3] = pool.labelOf(commitment);
    }

    /*//////////////////////////////////////////////////////////////
                              THE HATCH
    //////////////////////////////////////////////////////////////*/

    function test_TheShieldedEscapeHatchWorks() public {
        (, uint256 c) = _shieldedOrder(victim);
        IPrivacyPoolRagequit.RagequitProof memory proof = _proofFor(c);
        vm.prank(victim);
        escrow.rescueShielded(address(pool), proof);
        assertEq(victim.balance, 1 ether);
    }

    /**
     * The bug this replaced.
     *
     * The escrow indexed rescues by the commitment its deposit returned. A private partial
     * withdrawal spends that commitment and leaves the remainder in a successor with the same
     * label - and the escrow did not recognise the successor. So the escape hatch only worked
     * for a user who had never touched their deposit, and failed exactly when used as intended.
     */
    function test_TheHatchStillWorksAfterAPartialWithdrawal() public {
        (, uint256 c) = _shieldedOrder(victim);
        uint256 successor = pool.withdrawPart(c, 0.4 ether, elsewhere);

        IPrivacyPoolRagequit.RagequitProof memory proof = _proofFor(successor);
        vm.prank(victim);
        escrow.rescueShielded(address(pool), proof);
        assertEq(victim.balance, 0.6 ether, "the remainder came home");
    }

    /// Anyone holding a released shielded order must not be able to spend a victim's proof.
    function test_AnAttackerCannotFrontRunAVictimsRescueProof() public {
        (, uint256 victimCommitment) = _shieldedOrder(victim);
        _shieldedOrder(attacker);

        IPrivacyPoolRagequit.RagequitProof memory proof = _proofFor(victimCommitment);
        vm.prank(attacker);
        vm.expectRevert(FiatEscrow.NotTaker.selector);
        escrow.rescueShielded(address(pool), proof);
        assertEq(attacker.balance, 0);

        vm.prank(victim);
        escrow.rescueShielded(address(pool), proof);
        assertEq(victim.balance, 1 ether);
    }

    /// The label the escrow records must be the one the pool assigned.
    function test_TheRecordedLabelIsThePoolsOwn() public {
        (bytes32 orderId, uint256 c) = _shieldedOrder(victim);
        assertEq(escrow.labelOfOrder(orderId), pool.labelOf(c));
        // The reverse index, orderForLabel, is internal (FiatEscrow size): every rescue test here routes through it.
    }

    function test_TheRescueCallsThePoolNotTheEntrypoint() public view {
        assertEq(escrow.POOL(), address(pool));
    }

    function test_AnUnknownLabelIsRefused() public {
        _shieldedOrder(victim);
        IPrivacyPoolRagequit.RagequitProof memory p;
        p.pubSignals[3] = 123_456;
        vm.prank(victim);
        vm.expectRevert(FiatEscrow.BadOrder.selector);
        escrow.rescueShielded(address(pool), p);
    }

    /// Labels are only meaningful per pool, so the lookup is keyed by both.
    function test_ARescueNamingTheWrongPoolIsRefused() public {
        (, uint256 c) = _shieldedOrder(victim);
        IPrivacyPoolRagequit.RagequitProof memory proof = _proofFor(c);
        vm.prank(victim);
        vm.expectRevert(FiatEscrow.BadOrder.selector);
        escrow.rescueShielded(address(0xBEEF), proof);
    }

    function test_ADirectOrderHasNothingToRescue() public {
        vm.prank(lp);
        bytes32 offerId = escrow.postOffer{value: 5 ether}(
            address(0), 5 ether, 1_500_000, PIX, 0.01 ether, 2 ether, address(this), PIX_MASK
        );
        vm.prank(victim);
        bytes32 orderId = escrow.lockOrder(offerId, 1 ether, FiatEscrow.Delivery.DIRECT, victim, 0);
        escrow.releaseWithProof(orderId, "");
        assertEq(escrow.labelOfOrder(orderId), 0);
    }

    function test_ARescueCannotBeReplayed() public {
        (, uint256 c) = _shieldedOrder(victim);
        IPrivacyPoolRagequit.RagequitProof memory proof = _proofFor(c);
        vm.prank(victim);
        escrow.rescueShielded(address(pool), proof);
        vm.prank(victim);
        vm.expectRevert(bytes("already exited"));
        escrow.rescueShielded(address(pool), proof);
    }
}
