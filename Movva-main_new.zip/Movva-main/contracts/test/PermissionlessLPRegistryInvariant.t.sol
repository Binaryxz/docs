// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import {PermissionlessLPRegistry} from "../ramp/PermissionlessLPRegistry.sol";
import {Movva} from "../movva/Movva.sol";
import {EscrowStub} from "./utils/PermissionlessRegistryKit.sol";

/// Drives the registry the way LPs and the two escrows can: join, top up, exit, withdraw, reserve, release, settle,
/// lose a dispute, a stranger's reports, donations, and time. Counts every outcome the rules forbid.
contract PermissionlessRegistryHandler is Test {
    PermissionlessLPRegistry public reg;
    Movva public movva;
    EscrowStub[2] public escrows;
    address[4] public lps;

    uint256 public donated;
    uint256 public lastSlashed;
    /// Times `totalSlashed` was seen to go down.
    uint256 public slashDecreases;
    /// How often each outcome the invariants are about was reached, for `afterInvariant`'s log.
    uint256 public joins;
    uint256 public withdrawals;
    uint256 public slashes;
    uint256 public reservations;
    /// Withdrawals that succeeded before the unbonding period ended, or with exposure live.
    uint256 public badWithdrawals;
    /// Reservations that succeeded beyond the credit, or for an LP with no credit.
    uint256 public overReservations;
    /// MUST-NOT-revert calls that reverted.
    uint256 public reverts;
    /// Withdrawals that returned a different amount from the bond.
    uint256 public wrongPayouts;
    /// LP => its credit was cut (a slash, or an exit) while it had exposure live, since its exposure was last zero.
    mapping(address => bool) public cutWhileLive;

    constructor(PermissionlessLPRegistry r, Movva m, EscrowStub a, EscrowStub b) {
        reg = r;
        movva = m;
        escrows = [a, b];
        for (uint256 i; i < 4; ++i) {
            lps[i] = makeAddr(string.concat("lp", vm.toString(i)));
            vm.prank(lps[i]);
            movva.approve(address(reg), type(uint256).max);
        }
    }

    /// Every action ends here: slashed MOVVA only ever accumulates.
    modifier watched() {
        _;
        uint256 now_ = reg.totalSlashed();
        if (now_ < lastSlashed) ++slashDecreases;
        lastSlashed = now_;
    }

    function _lp(uint256 i) internal view returns (address) {
        return lps[i % 4];
    }

    function _bond(address lp)
        internal
        view
        returns (uint256 amount, uint256 exposure, uint64 exitAt)
    {
        (amount, exposure,, exitAt,,) = reg.bonds(lp);
    }

    function _fund(address lp, uint256 amount) internal {
        uint256 bal = movva.balanceOf(lp);
        if (bal < amount) {
            vm.prank(movva.RESERVE());
            movva.mint(lp, amount - bal);
        }
    }

    function join(uint256 i, uint256 amount) external watched {
        address lp = _lp(i);
        amount = bound(amount, reg.MIN_BOND() - 1, 200_000e18);
        _fund(lp, amount);
        vm.prank(lp);
        try reg.join(amount) {
            ++joins;
        } catch {}
    }

    function topUp(uint256 i, uint256 amount) external watched {
        address lp = _lp(i);
        amount = bound(amount, 0, 50_000e18);
        _fund(lp, amount);
        vm.prank(lp);
        try reg.topUp(amount) {} catch {}
    }

    function requestExit(uint256 i) external watched {
        address lp = _lp(i);
        (, uint256 exposure,) = _bond(lp);
        vm.prank(lp);
        try reg.requestExit() {
            if (exposure != 0) cutWhileLive[lp] = true;
        } catch {}
    }

    function withdraw(uint256 i) external watched {
        address lp = _lp(i);
        (uint256 amount, uint256 exposure, uint64 exitAt) = _bond(lp);
        uint256 before = movva.balanceOf(lp);
        vm.prank(lp);
        try reg.withdraw() {
            if (
                exitAt == 0 || block.timestamp < uint256(exitAt) + reg.UNBONDING_PERIOD()
                    || exposure != 0
            ) {
                ++badWithdrawals;
            }
            if (movva.balanceOf(lp) - before != amount) ++wrongPayouts;
            ++withdrawals;
        } catch {}
    }

    function reserve(uint256 i, uint256 e, uint256 cents) external watched {
        address lp = _lp(i);
        uint256 cap = reg.capOf(lp);
        (, uint256 exposure,) = _bond(lp);
        // Mostly within what is available, sometimes just past it.
        uint256 avail = reg.availableCents(lp);
        cents = bound(cents, 0, avail + avail / 8 + 1);
        try escrows[e % 2].reserve(lp, cents) returns (bool ok) {
            // A reservation of nothing adds nothing, so it may succeed even after a slash or an exit left exposure above
            // a renewed credit; anything else must fit, and an LP with no credit gets nothing at all.
            if (ok && (cap == 0 || (cents != 0 && exposure + cents > cap))) ++overReservations;
            if (ok) ++reservations;
        } catch {
            ++reverts; // a bound escrow's reservation answers, it does not revert
        }
    }

    function release(uint256 i, uint256 e, uint256 cents) external watched {
        address lp = _lp(i);
        cents = bound(cents, 0, 3_000_000);
        try escrows[e % 2].release(lp, cents) {}
        catch {
            ++reverts;
        }
        (, uint256 exposure,) = _bond(lp);
        if (exposure == 0) cutWhileLive[lp] = false;
    }

    function settle(uint256 i, uint256 e, uint256 cents) external watched {
        try escrows[e % 2].settled(_lp(i), cents) {}
        catch {
            ++reverts;
        }
    }

    function loseDispute(uint256 i, uint256 e) external watched {
        // One call in four: a slash empties a bond, and a handler that slashes on every other call reaches little else.
        if (e % 4 != 0) return;
        address lp = _lp(i);
        (uint256 amount, uint256 exposure,) = _bond(lp);
        try escrows[(e / 4) % 2].dispute(lp) {
            if (amount != 0 && exposure != 0) cutWhileLive[lp] = true;
            if (amount != 0) ++slashes;
        } catch {
            ++reverts;
        }
    }

    /// Nobody but a bound escrow moves anything with a report.
    function strangerReports(uint256 i, uint256 cents) external watched {
        address lp = _lp(i);
        vm.startPrank(makeAddr("stranger"));
        try reg.recordDispute(lp) {}
        catch {
            ++reverts;
        }
        try reg.recordSettled(lp, cents) {}
        catch {
            ++reverts;
        }
        try reg.releaseExposure(lp, cents) {}
        catch {
            ++reverts;
        }
        vm.stopPrank();
    }

    function donate(uint256 amount) external watched {
        amount = bound(amount, 0, 1_000e18);
        address d = makeAddr("donor");
        _fund(d, amount);
        vm.prank(d);
        movva.transfer(address(reg), amount);
        donated += amount;
    }

    function warp(uint256 dt) external watched {
        vm.warp(block.timestamp + bound(dt, 0, 20 days));
    }

    function lpCount() external pure returns (uint256) {
        return 4;
    }
}

/**
 * The registry's invariants, under any sequence of the handler's actions:
 *  - the books balance: the sum of every bond is `totalBonded`, and the registry holds exactly `totalBonded` plus
 *    `totalSlashed` plus whatever was donated - slashed and donated MOVVA never leaves;
 *  - an LP's exposure is exactly what the two escrows hold reserved for it;
 *  - no reservation ever succeeds past the credit, and exposure stays within the credit unless the credit was cut
 *    (a slash, an exit) while the exposure was live;
 *  - no withdrawal ever succeeds before the unbonding period ends or while any exposure is live, and each pays
 *    exactly the bond;
 *  - credit is zero while exiting or below the minimum bond, and otherwise the bond in centavos, rounded down;
 *  - `totalSlashed` never goes down, and no path the escrows need never to revert ever reverts.
 */
/// forge-config: default.invariant.runs = 128
/// forge-config: default.invariant.depth = 200
/// forge-config: deep.invariant.runs = 1000
/// forge-config: deep.invariant.depth = 256
contract PermissionlessLPRegistryInvariantTest is Test {
    PermissionlessLPRegistry reg;
    Movva movva;
    PermissionlessRegistryHandler handler;
    EscrowStub fiat;
    EscrowStub off;

    function setUp() public {
        vm.warp(1_800_000_000);
        movva = new Movva();
        reg = new PermissionlessLPRegistry(address(movva), address(0), 5_000e18, 36 days);
        fiat = new EscrowStub(address(reg), 30 days);
        off = new EscrowStub(address(reg), 30 days);
        reg.bindEscrows(address(fiat), address(off));
        handler = new PermissionlessRegistryHandler(reg, movva, fiat, off);
        // The handler mints through the reserve's role: this test deployed Movva, so it is the RESERVE.
        vm.label(address(this), "movva reserve");
        targetContract(address(handler));
    }

    function _bond(address lp)
        internal
        view
        returns (uint256 amount, uint256 exposure, uint64 exitAt)
    {
        (amount, exposure,, exitAt,,) = reg.bonds(lp);
    }

    function invariant_TheBooksBalance() public view {
        uint256 sum;
        for (uint256 i; i < handler.lpCount(); ++i) {
            (uint256 amount,,) = _bond(handler.lps(i));
            sum += amount;
        }
        assertEq(sum, reg.totalBonded(), "sum of bonds");
        assertEq(
            movva.balanceOf(address(reg)),
            reg.totalBonded() + reg.totalSlashed() + handler.donated(),
            "MOVVA held = bonded + slashed + donated"
        );
    }

    function invariant_ExposureIsWhatTheEscrowsHold() public view {
        for (uint256 i; i < handler.lpCount(); ++i) {
            address lp = handler.lps(i);
            (, uint256 exposure,) = _bond(lp);
            assertEq(
                exposure,
                reg.reservedBy(address(fiat), lp) + reg.reservedBy(address(off), lp),
                "exposure"
            );
        }
    }

    function invariant_ExposureNeverExceedsCredit() public view {
        assertEq(handler.overReservations(), 0, "a reservation past the credit");
        for (uint256 i; i < handler.lpCount(); ++i) {
            address lp = handler.lps(i);
            (, uint256 exposure,) = _bond(lp);
            if (!handler.cutWhileLive(lp)) {
                assertLe(exposure, reg.capOf(lp), "exposure over credit");
            }
        }
    }

    function invariant_NoWithdrawalEarlyOrWithExposureLive() public view {
        assertEq(
            handler.badWithdrawals(), 0, "a withdrawal before unbonding, or with exposure live"
        );
        assertEq(handler.wrongPayouts(), 0, "a withdrawal that did not pay exactly the bond");
    }

    function invariant_CreditIsTheBondOrNothing() public view {
        for (uint256 i; i < handler.lpCount(); ++i) {
            address lp = handler.lps(i);
            (uint256 amount,, uint64 exitAt) = _bond(lp);
            uint256 expected = exitAt != 0 || amount < reg.MIN_BOND() ? 0 : amount / 1e16;
            assertEq(reg.capOf(lp), expected, "capOf");
        }
    }

    /// Not a check: how far each run got, so a handler that never reaches a withdrawal or a slash shows up.
    function afterInvariant() public {
        emit log_named_uint("joins", handler.joins());
        emit log_named_uint("reservations", handler.reservations());
        emit log_named_uint("slashes", handler.slashes());
        emit log_named_uint("withdrawals", handler.withdrawals());
    }

    function invariant_SlashesOnlyAccumulateAndNothingReverts() public view {
        assertEq(handler.slashDecreases(), 0, "totalSlashed went down");
        assertEq(handler.reverts(), 0, "a must-not-revert path reverted");
    }
}
