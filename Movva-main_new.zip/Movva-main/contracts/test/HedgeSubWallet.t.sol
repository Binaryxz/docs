// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {Vm} from "forge-std/Vm.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";
import {HedgeSleeveBase, HedgeFeed, LyingVenue, PartialFillVenue} from "./utils/HedgeSleeveBase.sol";
import {TetherLike} from "./ERC4626Adapter.t.sol";
import {IHedgeVenue} from "../hedge/IHedgeVenue.sol";
import {SimHedgeVenue} from "../hedge/SimHedgeVenue.sol";
import {HedgeSubWallet} from "../hedge/HedgeSubWallet.sol";

/**
 * The venue-neutral sub-wallet (B2) and its trade-only keeper (B3) against the simulated venue:
 * the book it builds, every bound on the keeper, what a compromised keeper or venue operator can
 * cost, liquidation, and exits with the keeper gone.
 */
contract HedgeSubWalletTest is HedgeSleeveBase {
    uint256 constant BPS = 10_000;

    function _build(uint256 amount) internal {
        _fund(amount);
        _rebalanceUntilDone(40);
    }

    function _refPx() internal view returns (uint256) {
        return uint256(refFeed.answer()) * 1e10;
    }

    /*//////////////////////////////////////////////////////////////
                              DEPLOYMENT
    //////////////////////////////////////////////////////////////*/

    function test_TheConstructorRefusesAVenueItCannotBeHedgedOn() public {
        TetherLike other = new TetherLike();
        SimHedgeVenue v2 = new SimHedgeVenue(IERC20(address(other)), operator, 1 hours, 5, 5);
        vm.expectRevert(HedgeSubWallet.BadVenue.selector);
        new HedgeSubWallet(
            IERC20(address(usdt)),
            v2,
            ETH,
            refFeed,
            treasury,
            gov,
            guardian,
            keeper,
            DELAY,
            _params()
        );
        vm.expectRevert(
            abi.encodeWithSelector(SimHedgeVenue.UnknownMarket.selector, bytes32("BTC"))
        );
        new HedgeSubWallet(
            IERC20(address(usdt)),
            venue,
            "BTC",
            refFeed,
            treasury,
            gov,
            guardian,
            keeper,
            DELAY,
            _params()
        );
        HedgeSubWallet.Params memory p = _params();
        p.maxLeverageBps = 60_000; // over half the venue's 10x
        vm.expectRevert(HedgeSubWallet.BadParams.selector);
        _newWallet(p);
    }

    function test_NothingIsTakenOnBeforeSetupIsComplete() public {
        HedgeSubWallet w = _newWallet(_params());
        usdt.mint(treasury, 1_000e6);
        vm.startPrank(treasury);
        usdt.approve(address(w), 1_000e6);
        vm.expectRevert(DelayedGovernance.SetupIncomplete.selector);
        w.fund(1_000e6);
        vm.stopPrank();
        vm.prank(keeper);
        vm.expectRevert(DelayedGovernance.SetupIncomplete.selector);
        w.rebalance();
    }

    function test_BothContractsFitEip170() public view {
        assertLt(address(wallet).code.length, 24_576, "HedgeSubWallet runtime");
        assertLt(address(venue).code.length, 24_576, "SimHedgeVenue runtime");
    }

    /*//////////////////////////////////////////////////////////////
                               THE BOOK
    //////////////////////////////////////////////////////////////*/

    function test_TheKeeperBuildsTheTargetBookInBoundedSteps() public {
        _fund(300_000e6);
        vm.recordLogs();
        _tick(61);
        vm.prank(keeper);
        wallet.rebalance();
        vm.prank(keeper);
        vm.expectRevert(
            abi.encodeWithSelector(HedgeSubWallet.TooSoon.selector, block.timestamp + 60)
        );
        wallet.rebalance();
        uint256 steps = 1 + _rebalanceUntilDone(40);
        assertGe(steps, 4, "a $198k book in $50k orders");
        // Target: 300k x 2 / 3, less the two bands = 198,000.
        uint256 shortN = (_short() * _refPx()) / 1e30;
        assertApproxEqRel(shortN, 198_000e6, 0.02e18);
        assertApproxEqRel(_spotQty(), _short(), 0.02e18, "delta inside tolerance");
        assertApproxEqRel(_leverage(), 20_000, 0.03e18, "at target leverage");
        assertLe(wallet.windowUsed(), 2 * 200_000e6, "two legs of at most the book");
        // Every order was at most maxOrderNotional.
        Vm.Log[] memory logs = vm.getRecordedLogs();
        bytes32 orderTopic = keccak256("Order(uint8,uint256,uint256,uint256,bool)");
        uint256 orders;
        for (uint256 i; i < logs.length; ++i) {
            if (logs[i].emitter != address(wallet) || logs[i].topics[0] != orderTopic) continue;
            (,, uint256 notional,) = abi.decode(logs[i].data, (uint256, uint256, uint256, bool));
            assertLe(notional, 50_000e6, "an order over maxOrderNotional");
            ++orders;
        }
        assertGe(orders, 8, "both legs, chunk by chunk");
        _tick(61);
        vm.prank(keeper);
        vm.expectRevert(HedgeSubWallet.NothingToDo.selector);
        wallet.rebalance();
    }

    function test_OnlyTheKeeperRebalancesAndOnlyTheTreasuryMovesMoney() public {
        _fund(10_000e6);
        vm.startPrank(stranger);
        vm.expectRevert(HedgeSubWallet.NotKeeper.selector);
        wallet.rebalance();
        vm.expectRevert(HedgeSubWallet.NotKeeper.selector);
        wallet.harvest();
        vm.stopPrank();
        address[3] memory notTreasury = [keeper, guardian, gov];
        for (uint256 i; i < 3; ++i) {
            vm.startPrank(notTreasury[i]);
            vm.expectRevert(HedgeSubWallet.NotTreasury.selector);
            wallet.withdrawToTreasury(1);
            vm.expectRevert(HedgeSubWallet.NotTreasury.selector);
            wallet.unwind(0, type(uint256).max);
            vm.expectRevert(HedgeSubWallet.NotTreasury.selector);
            wallet.fund(1);
            vm.stopPrank();
        }
    }

    function test_TheKeeperCanSendNothingAnywhere() public {
        _build(300_000e6);
        _tick(1 days);
        vm.prank(keeper);
        wallet.harvest();
        // Every dollar is in the wallet or its venue account; the keeper received nothing.
        assertEq(usdt.balanceOf(keeper), 0);
        assertEq(usdt.balanceOf(stranger), 0);
        assertEq(usdt.allowance(address(wallet), address(venue)), 0, "no allowance left behind");
        assertEq(usdt.balanceOf(treasury), 0, "nor does anything leave without the treasury asking");
    }

    function test_TheAllocationCapBoundsTheBook() public {
        HedgeSubWallet.Params memory p = _params();
        p.allocationCap = 100_000e6;
        vm.prank(gov);
        wallet.setParams(p); // a lower cap is instant
        _build(300_000e6);
        assertApproxEqRel((_short() * _refPx()) / 1e30, 66_000e6, 0.02e18);
        assertGt(usdt.balanceOf(address(wallet)), 190_000e6, "the rest stays idle");
    }

    function test_HarvestBringsFundingHome() public {
        _build(300_000e6);
        vm.prank(operator);
        venue.setFundingRate(ETH, 2e14); // 0.02% an hour
        uint256 idle0 = usdt.balanceOf(address(wallet));
        uint256 v0 = _value();
        _tick(1 days);
        vm.prank(keeper);
        wallet.harvest();
        // ~79 ETH short x $2,500 x 0.02% x 24 h ~ $950 of funding; the margin above 2x comes back.
        assertGt(_value() - v0, 900e6);
        assertGt(
            usdt.balanceOf(address(wallet)) - idle0, 800e6, "funding is back in the sub-wallet"
        );
        assertEq(venue.cash(address(wallet)), 0);
        assertApproxEqRel(_leverage(), 20_000, 0.03e18);
    }

    /*//////////////////////////////////////////////////////////////
                         BOUNDS ON THE KEEPER
    //////////////////////////////////////////////////////////////*/

    function test_ACompromisedKeeperFillingAtTheBandEdgeIsBoundedByTurnover() public {
        HedgeSubWallet.Params memory p = _params();
        p.maxWindowTurnover = 250_000e6;
        vm.prank(gov);
        wallet.setParams(p); // lowering a cap is instant
        _fund(1_000_000e6);
        // The operator colludes: spread + fee exactly the keeper's 50 bps band, so every fill lands
        // on its limit.
        vm.prank(operator);
        venue.setFees(45, 5);
        uint256 before = _value();
        bool exhausted;
        for (uint256 i; i < 40 && !exhausted; ++i) {
            _tick(61);
            vm.prank(keeper);
            try wallet.rebalance() {}
            catch (bytes memory err) {
                exhausted = bytes4(err) == HedgeSubWallet.TurnoverExhausted.selector;
                assertTrue(exhausted, "stopped by the budget, not by running out of work");
            }
        }
        assertTrue(exhausted);
        assertLe(wallet.windowUsed(), 250_000e6, "turnover never exceeded");
        uint256 lost = before - _value();
        assertLe(lost, (250_000e6 * 50) / BPS + 1e6, "loss within turnover x band");
        emit log_named_uint("worst-case loss, USDT (1e6)", lost);
        emit log_named_uint("keeper turnover used, USDT (1e6)", wallet.windowUsed());
        // A new window restores the budget, and the guardian can end it at once instead.
        vm.prank(guardian);
        wallet.pauseExposure();
        assertTrue(wallet.exposurePaused());
    }

    function test_NothingTradesOutsideTheBandAroundTheReference() public {
        _build(100_000e6);
        vm.prank(operator);
        venue.setBasis(ETH, 150, 0); // mark 1.5% off; the band is 1%
        _tick(61);
        vm.prank(keeper);
        vm.expectRevert(
            abi.encodeWithSelector(
                HedgeSubWallet.OutOfBand.selector, uint8(0), 2_537.5e18, 2_500e18
            )
        );
        wallet.rebalance();
        vm.expectRevert();
        wallet.deleverage();
        // The venue's own oracle drifting off the independent reference is the same.
        vm.prank(operator);
        venue.setBasis(ETH, 0, 0);
        venueFeed.set(2_530e8, block.timestamp);
        vm.prank(keeper);
        vm.expectRevert(
            abi.encodeWithSelector(HedgeSubWallet.OutOfBand.selector, uint8(0), 2_530e18, 2_500e18)
        );
        wallet.rebalance();
    }

    function test_AStaleReferenceStopsTheKeeper() public {
        _fund(100_000e6);
        vm.warp(block.timestamp + 2 hours);
        venueFeed.set(PX, block.timestamp); // the venue is fine; the reference is not
        uint256 refAt = refFeed.at();
        vm.prank(keeper);
        vm.expectRevert(abi.encodeWithSelector(HedgeSubWallet.StaleReference.selector, refAt));
        wallet.rebalance();
    }

    function test_AVenueThatReportsAWorseFillIsNotBelieved() public {
        LyingVenue liar = new LyingVenue(IERC20(address(usdt)));
        HedgeSubWallet w = new HedgeSubWallet(
            IERC20(address(usdt)),
            IHedgeVenue(address(liar)),
            ETH,
            refFeed,
            treasury,
            gov,
            guardian,
            keeper,
            DELAY,
            _params()
        );
        _completeSetup(address(w));
        usdt.mint(treasury, 100_000e6);
        vm.startPrank(treasury);
        usdt.approve(address(w), 100_000e6);
        w.fund(100_000e6);
        vm.stopPrank();
        _tick(61);
        liar.setMode(1);
        vm.prank(keeper);
        vm.expectRevert();
        w.rebalance();
        liar.setMode(2);
        vm.prank(keeper);
        vm.expectRevert();
        w.rebalance();
        assertEq(usdt.balanceOf(address(w)), 100_000e6, "both reverted whole: nothing moved");
    }

    /*//////////////////////////////////////////////////////////////
                               FUNDING
    //////////////////////////////////////////////////////////////*/

    function _fastFunding() internal {
        HedgeSubWallet.Params memory p = _params();
        p.fundingTau = 1 hours;
        vm.prank(gov);
        wallet.setParams(p); // a shorter average is a tighter breaker: instant
    }

    function test_FundingBelowThePauseFloorAddsNothing() public {
        _fastFunding();
        _fund(300_000e6);
        _tick(61);
        vm.prank(keeper);
        wallet.rebalance(); // one chunk in
        uint256 held = _short();
        vm.prank(operator);
        venue.setFundingRate(ETH, -1e12); // -0.88% APR: under the pause floor, over the exit
        for (uint256 h; h < 8; ++h) {
            _tick(1 hours);
            wallet.sampleFunding();
        }
        assertLt(wallet.fundingEmaE8(), 0);
        assertGt(wallet.fundingEmaE8(), -1_141);
        _rebalanceUntilDone(10);
        assertEq(_short(), held, "holds what is open, adds nothing");
    }

    function test_FundingBelowTheExitFloorUnwinds() public {
        _fastFunding();
        _build(300_000e6);
        vm.prank(operator);
        venue.setFundingRate(ETH, -2e13); // -17.5% APR
        for (uint256 h; h < 8; ++h) {
            _tick(1 hours);
            wallet.sampleFunding();
        }
        _rebalanceUntilDone(20);
        assertEq(_short(), 0);
        assertLt(_spotQty(), 1e15);
    }

    /// The operator's worst: the maximum adverse rate at once. The 84-hour average reaches the exit
    /// floor within hours and the keeper unwinds; the cost is bounded by the rate's cap times the
    /// notional and that time, plus the fills.
    function test_ACompromisedVenueOperatorIsBoundedByTheExitFloor() public {
        _build(300_000e6);
        uint256 v0 = _value();
        uint256 notional = (_short() * _refPx()) / 1e30;
        int256 worst = -venue.MAX_FUNDING_RATE();
        vm.prank(operator);
        venue.setFundingRate(ETH, worst);
        uint256 hoursOut;
        for (; hoursOut < 48 && _short() > 0; ++hoursOut) {
            _tick(1 hours);
            vm.prank(keeper);
            try wallet.rebalance() {} catch {}
        }
        assertEq(_short(), 0, "unwound");
        uint256 lost = v0 - _value();
        uint256 bound = (notional * 5 * hoursOut) / BPS + (2 * notional * 50) / BPS;
        assertLe(lost, bound, "funding at the cap for those hours, plus the band on the way out");
        emit log_named_uint("hours to unwind at the maximum adverse rate", hoursOut);
        emit log_named_uint("loss, USDT (1e6)", lost);
    }

    function test_SpammingSamplesDoesNotAmplifyAManipulatedRate() public {
        int256 worst = -venue.MAX_FUNDING_RATE();
        vm.prank(operator);
        venue.setFundingRate(ETH, worst);
        for (uint256 i; i < 60; ++i) {
            vm.warp(block.timestamp + 1);
            vm.prank(stranger);
            wallet.sampleFunding();
        }
        assertGt(
            wallet.fundingEmaE8(), 1_200, "a minute of samples moves an 84-hour average by a minute"
        );
    }

    /*//////////////////////////////////////////////////////////////
                      RALLIES, LIQUIDATION, PAUSE
    //////////////////////////////////////////////////////////////*/

    function test_AnyoneDeleveragesARallyWithTheKeeperOffline() public {
        _build(300_000e6);
        _setPrice(3_125e8); // +25%
        assertGt(_leverage(), 30_000);
        vm.prank(stranger);
        vm.expectRevert(HedgeSubWallet.NotKeeper.selector);
        wallet.rebalance();
        for (uint256 i; i < 20; ++i) {
            vm.prank(stranger);
            try wallet.deleverage() {}
            catch (bytes memory err) {
                assertEq(bytes4(err), HedgeSubWallet.NothingToDo.selector);
                break;
            }
        }
        assertLe(_leverage(), 30_000, "back under the cap by nobody's key");
        assertApproxEqRel(_spotQty(), _short(), 0.03e18, "both legs shrank together");
    }

    function test_WithNobodyWatchingARallyEndsInALiquidationAndTheSpotLegSurvives() public {
        _build(300_000e6);
        _setPrice(3_625e8); // +45%
        vm.prank(stranger);
        venue.liquidate(address(wallet));
        assertEq(_short(), 0);
        // The treasury takes what is left, keeper or no keeper.
        vm.prank(gov);
        wallet.setKeeper(address(0));
        vm.startPrank(treasury);
        wallet.unwind((_refPx() * 99) / 100, (_refPx() * 101) / 100);
        uint256 paid = wallet.withdrawToTreasury(type(uint256).max);
        vm.stopPrank();
        assertGt(paid, 290_000e6, "hedged: only the liquidation penalty and fills are lost");
        emit log_named_uint("recovered after liquidation, USDT (1e6)", paid);
    }

    function test_TheGuardianPausesExposureAndTheKeeperUnwinds() public {
        _build(200_000e6);
        vm.prank(stranger);
        vm.expectRevert(HedgeSubWallet.NotGuardianOrGovernor.selector);
        wallet.pauseExposure();
        vm.prank(guardian);
        wallet.pauseExposure();
        _rebalanceUntilDone(20);
        assertEq(_short(), 0);
        vm.prank(guardian);
        vm.expectRevert(DelayedGovernance.NotGovernor.selector);
        wallet.resume();
        // Lifting the pause waits out the delay (it is the governor's, and on Sepolia the keeper's key).
        vm.prank(gov);
        vm.expectRevert(
            abi.encodeWithSelector(
                DelayedGovernance.ChangeMustBeScheduled.selector, HedgeSubWallet.resume.selector
            )
        );
        wallet.resume();
        _afterDelay(address(wallet), abi.encodeCall(HedgeSubWallet.resume, ()));
        assertFalse(wallet.exposurePaused());
        _rebalanceUntilDone(20);
        assertGt(_short(), 0);
    }

    /*//////////////////////////////////////////////////////////////
                         EXITS WITHOUT A KEEPER
    //////////////////////////////////////////////////////////////*/

    function test_TheTreasuryExitsWithTheKeeperGoneAndTheReferenceDead() public {
        _build(300_000e6);
        vm.prank(gov);
        wallet.setKeeper(address(0)); // revoking is instant
        vm.warp(block.timestamp + 6 hours);
        venueFeed.set(PX, block.timestamp); // the venue still prices; the reference feed is dead
        vm.prank(stranger);
        vm.expectRevert();
        wallet.deleverage();

        vm.startPrank(treasury);
        wallet.unwind(2_475e18, 2_525e18);
        uint256 paid = wallet.withdrawToTreasury(type(uint256).max);
        vm.stopPrank();
        assertEq(_short(), 0);
        assertEq(_spotQty(), 0);
        assertEq(venue.cash(address(wallet)), 0);
        assertEq(venue.collateralOf(address(wallet)), 0);
        assertEq(usdt.balanceOf(address(wallet)), 0);
        assertEq(usdt.balanceOf(treasury), paid);
        // In: 2 legs x 10 bps; out: the same again; plus funding earned meanwhile.
        assertGt(paid, (300_000e6 * 9_950) / BPS);
        emit log_named_uint("keeper-free exit recovered, USDT (1e6)", paid);
    }

    function test_WithdrawingNeverTakesMarginBelowTheMaxLeverageRequirement() public {
        _build(300_000e6);
        vm.prank(treasury);
        uint256 paid = wallet.withdrawToTreasury(type(uint256).max);
        assertGt(paid, 0);
        assertLe(_leverage(), 30_000 + 1, "still margined for 3x");
        vm.prank(treasury);
        vm.expectRevert();
        wallet.withdrawToTreasury(1_000_000e6);
    }

    function test_SweepRecoversStrayTokensToTheTreasuryOnly() public {
        TetherLike stray = new TetherLike();
        stray.mint(address(wallet), 5e6);
        vm.prank(treasury);
        wallet.sweep(IERC20(address(stray)));
        assertEq(stray.balanceOf(treasury), 5e6);
        vm.prank(treasury);
        vm.expectRevert(HedgeSubWallet.BadParams.selector);
        wallet.sweep(IERC20(address(usdt)));
    }

    /*//////////////////////////////////////////////////////////////
            THE BACKSTOP CANNOT BE SWITCHED OFF AT ONCE (21 OCT REVIEW)
    //////////////////////////////////////////////////////////////*/

    function _expectBadParams(HedgeSubWallet.Params memory p) internal {
        vm.expectRevert(HedgeSubWallet.BadParams.selector);
        _newWallet(p);
    }

    /// Floors and caps that hold even for a governor willing to wait.
    function test_TheBackstopsParamsHaveFloors() public {
        HedgeSubWallet.Params memory p = _params();
        p.slippageBps = 9; // under MIN_SLIPPAGE_BPS
        _expectBadParams(p);
        p = _params();
        p.priceBandBps = 69; // under slippage (50) + BAND_COST_MARGIN_BPS (20)
        _expectBadParams(p);
        p = _params();
        p.maxReferenceAge = 1 hours - 1;
        _expectBadParams(p);
        p = _params();
        p.minActionInterval = 1 days + 1;
        _expectBadParams(p);
        // The edges are valid.
        p = _params();
        p.slippageBps = 10;
        p.priceBandBps = 30;
        p.maxReferenceAge = 1 hours;
        p.minActionInterval = 1 days;
        _newWallet(p);
    }

    /**
     * The review's attack: the governor (on Sepolia, the keeper's own key) tightens the band to 1 bps,
     * the reference age to 60 s and the slippage to 1 bps, so `deleverage()` - anyone's backstop -
     * reverts on every call. None of it is instant, and none of it is valid even after the delay.
     */
    function test_TheGovernorCannotDisableDeleverage() public {
        HedgeSubWallet.Params memory p = _params();
        p.priceBandBps = 1;
        p.maxReferenceAge = 60;
        p.slippageBps = 1;
        vm.prank(gov);
        vm.expectRevert(
            abi.encodeWithSelector(
                DelayedGovernance.ChangeMustBeScheduled.selector, HedgeSubWallet.setParams.selector
            )
        );
        wallet.setParams(p);
        bytes memory call = abi.encodeCall(HedgeSubWallet.setParams, (p));
        vm.prank(gov);
        wallet.schedule(call);
        vm.warp(block.timestamp + DELAY);
        vm.prank(gov);
        vm.expectRevert(HedgeSubWallet.BadParams.selector);
        wallet.execute(call);

        // And the backstop still works afterwards.
        _tick(61);
        _build(300_000e6);
        _setPrice(3_125e8);
        vm.prank(stranger);
        wallet.deleverage();
    }

    /// Every field the backstop trades through waits, in both directions.
    function test_EveryChangeTheBackstopTradesThroughWaits() public {
        HedgeSubWallet.Params[7] memory ps;
        for (uint256 i; i < 7; ++i) ps[i] = _params();
        ps[0].slippageBps = 30; // narrower: fills may stop landing inside the limit
        ps[1].slippageBps = 70; // wider: a looser band for the keeper
        ps[2].priceBandBps = 80; // narrower: a normal book reads "out of band"
        ps[3].priceBandBps = 200; // wider
        ps[4].maxReferenceAge = 2 hours; // longer: staler prices accepted
        ps[5].maxOrderNotional = 1e6; // smaller: a deleverage of one dollar at a time
        ps[6].maxOrderNotional = 100_000e6; // larger
        for (uint256 i; i < 7; ++i) {
            vm.prank(gov);
            vm.expectRevert(
                abi.encodeWithSelector(
                    DelayedGovernance.ChangeMustBeScheduled.selector,
                    HedgeSubWallet.setParams.selector
                )
            );
            wallet.setParams(ps[i]);
        }
        // Shorter, from two hours back to one, waits as well: it is how "every price is stale" starts.
        _afterDelay(address(wallet), abi.encodeCall(HedgeSubWallet.setParams, (ps[4])));
        HedgeSubWallet.Params memory shorter = wallet.getParams();
        shorter.maxReferenceAge = 1 hours;
        vm.prank(gov);
        vm.expectRevert(
            abi.encodeWithSelector(
                DelayedGovernance.ChangeMustBeScheduled.selector, HedgeSubWallet.setParams.selector
            )
        );
        wallet.setParams(shorter);
    }

    function test_KeeperPaceIsCappedAtADay() public {
        HedgeSubWallet.Params memory p = _params();
        p.minActionInterval = 1 days; // slower keeper: instant, up to the cap
        vm.prank(gov);
        wallet.setParams(p);
        p.minActionInterval = 1 days + 1;
        vm.prank(gov);
        vm.expectRevert(HedgeSubWallet.BadParams.selector);
        wallet.setParams(p);
        p.minActionInterval = 60; // faster: waits
        vm.prank(gov);
        vm.expectRevert(
            abi.encodeWithSelector(
                DelayedGovernance.ChangeMustBeScheduled.selector, HedgeSubWallet.setParams.selector
            )
        );
        wallet.setParams(p);
    }

    /// A resume scheduled before a new pause cannot lift that pause early.
    function test_APauseStandsForAtLeastTheDelay() public {
        vm.prank(gov);
        wallet.resume(); // nothing paused: a no-op, instant
        vm.prank(guardian);
        wallet.pauseExposure();
        bytes memory call = abi.encodeCall(HedgeSubWallet.resume, ());
        vm.prank(gov);
        wallet.schedule(call);
        vm.warp(block.timestamp + DELAY - 1 hours);
        vm.prank(guardian);
        wallet.pauseExposure(); // a second incident
        vm.warp(block.timestamp + 1 hours);
        vm.prank(gov);
        vm.expectRevert(
            abi.encodeWithSelector(
                HedgeSubWallet.PausedTooRecently.selector, block.timestamp + DELAY - 1 hours
            )
        );
        wallet.execute(call);
        assertTrue(wallet.exposurePaused(), "the second pause stands");
        // The treasury's unwind pauses too, and counts as the latest pause.
        vm.prank(treasury);
        wallet.unwind(0, type(uint256).max);
        assertEq(wallet.pausedAt(), block.timestamp);
    }

    /*//////////////////////////////////////////////////////////////
                       PAIRED LEGS FILL TOGETHER
    //////////////////////////////////////////////////////////////*/

    function _partialWallet() internal returns (PartialFillVenue pv, HedgeSubWallet w) {
        pv = new PartialFillVenue(venue);
        w = new HedgeSubWallet(
            IERC20(address(usdt)),
            IHedgeVenue(address(pv)),
            ETH,
            refFeed,
            treasury,
            gov,
            guardian,
            keeper,
            DELAY,
            _params()
        );
        _completeSetup(address(w));
        usdt.mint(treasury, 300_000e6);
        vm.startPrank(treasury);
        usdt.approve(address(w), 300_000e6);
        w.fund(300_000e6);
        vm.stopPrank();
    }

    function _pvShort(PartialFillVenue pv) internal view returns (uint256) {
        int256 x = venue.perpPosition(address(pv), ETH).size;
        return x < 0 ? uint256(-x) : 0;
    }

    /// A venue that fills the spot buy and not the short: the step reverts whole, nothing is unhedged.
    function test_APairThatFillsOneLegIsRefused() public {
        (PartialFillVenue pv, HedgeSubWallet w) = _partialWallet();
        pv.setFill(2, 0); // the short never fills
        _tick(61);
        vm.prank(keeper);
        try w.rebalance() {
            revert("a one-legged pair was accepted");
        } catch (bytes memory err) {
            assertEq(bytes4(err), HedgeSubWallet.UnevenFill.selector);
        }
        assertEq(venue.spotBalance(address(pv), ETH), 0, "no spot bought");
        assertEq(usdt.balanceOf(address(w)), 300_000e6, "nothing moved");

        // Both legs filling the same part is a hedge, just smaller: accepted.
        pv.setFill(0, 5_000);
        pv.setFill(2, 5_000);
        vm.prank(keeper);
        w.rebalance();
        assertGt(_pvShort(pv), 0);
        assertApproxEqRel(venue.spotBalance(address(pv), ETH), _pvShort(pv), 0.001e18);
    }

    /// The anyone-callable deleverage on a venue that stops filling the buy-back: refused, not half-done.
    function test_ADeleverageWhoseShortDoesNotFillIsRefused() public {
        (PartialFillVenue pv, HedgeSubWallet w) = _partialWallet();
        for (uint256 i; i < 40; ++i) {
            _tick(61);
            vm.prank(keeper);
            try w.rebalance() {}
            catch {
                break;
            }
        }
        assertGt(_pvShort(pv), 0, "a book was built");
        _setPrice(3_125e8); // +25%: over 3x
        pv.setFill(3, 0); // the short buy-back stops filling; the spot sale still would
        bool refused;
        for (uint256 i; i < 10 && !refused; ++i) {
            uint256 s0 = venue.spotBalance(address(pv), ETH);
            vm.prank(stranger);
            try w.deleverage() {}
            catch (bytes memory err) {
                if (bytes4(err) == HedgeSubWallet.NothingToDo.selector) break;
                assertEq(bytes4(err), HedgeSubWallet.UnevenFill.selector);
                refused = true;
                assertEq(venue.spotBalance(address(pv), ETH), s0, "no spot sold alone");
            }
        }
        assertTrue(refused, "the one-legged reduction was refused");
        // Once both legs fill (even partly, together), the backstop works.
        pv.setFill(1, 5_000);
        pv.setFill(3, 5_000);
        vm.prank(stranger);
        w.deleverage();
        assertApproxEqRel(venue.spotBalance(address(pv), ETH), _pvShort(pv), 0.03e18);
    }

    function test_ALyingVenueThatFillsOneLegIsNotBelieved() public {
        LyingVenue liar = new LyingVenue(IERC20(address(usdt)));
        HedgeSubWallet w = new HedgeSubWallet(
            IERC20(address(usdt)),
            IHedgeVenue(address(liar)),
            ETH,
            refFeed,
            treasury,
            gov,
            guardian,
            keeper,
            DELAY,
            _params()
        );
        _completeSetup(address(w));
        usdt.mint(treasury, 100_000e6);
        vm.startPrank(treasury);
        usdt.approve(address(w), 100_000e6);
        w.fund(100_000e6);
        vm.stopPrank();
        _tick(61);
        liar.setMode(3); // perp orders report nothing filled
        vm.prank(keeper);
        try w.rebalance() {
            revert("accepted");
        } catch (bytes memory err) {
            assertEq(bytes4(err), HedgeSubWallet.UnevenFill.selector);
        }
        assertEq(usdt.balanceOf(address(w)), 100_000e6, "reverted whole");
        liar.setMode(4); // both legs half: consistent, accepted
        vm.prank(keeper);
        w.rebalance();
    }

    /*//////////////////////////////////////////////////////////////
                               GOVERNANCE
    //////////////////////////////////////////////////////////////*/

    function test_LooserParamsWaitAndTighterOnesDoNot() public {
        HedgeSubWallet.Params memory p = _params();
        p.targetLeverageBps = 25_000;
        vm.prank(gov);
        vm.expectRevert(
            abi.encodeWithSelector(
                DelayedGovernance.ChangeMustBeScheduled.selector, HedgeSubWallet.setParams.selector
            )
        );
        wallet.setParams(p);
        _afterDelay(address(wallet), abi.encodeCall(HedgeSubWallet.setParams, (p)));
        assertEq(wallet.getParams().targetLeverageBps, 25_000);

        HedgeSubWallet.Params memory q = wallet.getParams();
        q.allocationCap = 1_000_000e6; // tighter, and nothing an exit trades through: instant
        q.maxWindowTurnover = 500_000e6;
        q.minActionInterval = 1 hours;
        vm.prank(gov);
        wallet.setParams(q);
        assertEq(wallet.getParams().allocationCap, 1_000_000e6);

        vm.prank(stranger);
        vm.expectRevert(DelayedGovernance.NotGovernor.selector);
        wallet.setParams(q);
        q.maxWindowTurnover = 1; // under one order
        vm.prank(gov);
        vm.expectRevert(HedgeSubWallet.BadParams.selector);
        wallet.setParams(q);
    }

    function test_ANewKeeperWaitsAndRevokingDoesNot() public {
        address k2 = makeAddr("k2");
        vm.prank(gov);
        vm.expectRevert(
            abi.encodeWithSelector(
                DelayedGovernance.ChangeMustBeScheduled.selector, HedgeSubWallet.setKeeper.selector
            )
        );
        wallet.setKeeper(k2);
        vm.prank(gov);
        wallet.setKeeper(address(0));
        assertEq(wallet.keeper(), address(0));
        _afterDelay(address(wallet), abi.encodeCall(HedgeSubWallet.setKeeper, (k2)));
        assertEq(wallet.keeper(), k2);
        vm.prank(gov);
        wallet.setGuardian(stranger);
        assertEq(wallet.guardian(), stranger);
    }
}
