// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

import {Test, Vm} from "forge-std/Test.sol";
import {Base64} from "@openzeppelin/contracts/utils/Base64.sol";

/*//////////////////////////////////////////////////////////////
                  INTERFACES OF THE DEPLOYED CONTRACTS
//////////////////////////////////////////////////////////////*/

interface ISafe {
    function setup(
        address[] calldata owners,
        uint256 threshold,
        address to,
        bytes calldata data,
        address fallbackHandler,
        address paymentToken,
        uint256 payment,
        address payable paymentReceiver
    ) external;
    function getOwners() external view returns (address[] memory);
    function getThreshold() external view returns (uint256);
    function isModuleEnabled(address module) external view returns (bool);
    function enableModule(address module) external;
    function swapOwner(address prevOwner, address oldOwner, address newOwner) external;
}

interface ISafeProxyFactory {
    function createProxyWithNonce(address singleton, bytes memory initializer, uint256 saltNonce)
        external
        returns (address proxy);
}

interface ISafeModuleSetup {
    function enableModules(address[] calldata modules) external;
}

struct PackedUserOperation {
    address sender;
    uint256 nonce;
    bytes initCode;
    bytes callData;
    bytes32 accountGasLimits;
    uint256 preVerificationGas;
    bytes32 gasFees;
    bytes paymasterAndData;
    bytes signature;
}

interface IEntryPoint {
    error FailedOp(uint256 opIndex, string reason);

    function handleOps(PackedUserOperation[] calldata ops, address payable beneficiary) external;
    function getNonce(address sender, uint192 key) external view returns (uint256);
    function depositTo(address account) external payable;
}

interface ISafe4337Module {
    function getOperationHash(PackedUserOperation calldata userOp) external view returns (bytes32);
    function executeUserOp(address to, uint256 value, bytes memory data, uint8 operation) external;
}

interface IWebAuthnSignerFactory {
    function createSigner(uint256 x, uint256 y, uint176 verifiers) external returns (address);
}

interface IModuleProxyFactory {
    function deployModule(address masterCopy, bytes memory initializer, uint256 saltNonce)
        external
        returns (address proxy);
}

interface IMultiSend {
    function multiSend(bytes memory transactions) external payable;
}

/// Zodiac Delay Modifier 1.1.1, as deployed. Errors and events copied from its verified source.
interface IDelay {
    error NotAuthorized(address sender);
    error HashAlreadyConsumed(bytes32);
    error OwnableUnauthorizedAccount(address account);

    event TransactionAdded(
        uint256 indexed queueNonce, bytes32 indexed txHash, address to, uint256 value, bytes data, uint8 operation
    );

    function setUp(bytes memory initParams) external;
    function owner() external view returns (address);
    function avatar() external view returns (address);
    function target() external view returns (address);
    function txCooldown() external view returns (uint256);
    function txExpiration() external view returns (uint256);
    function txNonce() external view returns (uint256);
    function queueNonce() external view returns (uint256);
    function txCreatedAt(uint256) external view returns (uint256);
    function enableModule(address module) external;
    function disableModule(address prevModule, address module) external;
    function isModuleEnabled(address module) external view returns (bool);
    function execTransactionFromModule(address to, uint256 value, bytes calldata data, uint8 operation)
        external
        returns (bool);
    function executeNextTx(address to, uint256 value, bytes calldata data, uint8 operation) external;
    function skipExpired() external;
    function setTxNonce(uint256 nonce) external;
    function setTxCooldown(uint256 cooldown) external;
    function moduleTxHash(bytes calldata data, bytes32 salt) external view returns (bytes32);
}

/*//////////////////////////////////////////////////////////////
                           TEST CONTRACTS
//////////////////////////////////////////////////////////////*/

/**
 * Stands in for `PrivacyPool.ragequit`: only the ORIGINAL DEPOSITOR may exit, whatever proof it
 * brings. That is the property that made ragequit need the server co-signer - the depositor is
 * the user's Safe - and the one this test has to get past with the server gone.
 */
contract DepositorOnlyPool {
    mapping(address => uint256) public deposited;

    error NotTheDepositor();

    function deposit() external payable {
        deposited[msg.sender] += msg.value;
    }

    function ragequit() external {
        uint256 value = deposited[msg.sender];
        if (value == 0) revert NotTheDepositor();
        deposited[msg.sender] = 0;
        (bool ok,) = msg.sender.call{value: value}("");
        require(ok, "refund failed");
    }
}

contract AlwaysReverts {
    fallback() external {
        revert("this call always fails");
    }
}

/// A module that answers every ERC-1271 query by REVERTING with the magic value.
contract RevertsWithMagicValue {
    fallback() external {
        bytes memory data = abi.encode(bytes4(0x1626ba7e));
        assembly {
            revert(add(data, 32), mload(data))
        }
    }
}

/**
 * Passkey-only recovery for a Safe 2-of-2 (passkey + server), on mainnet state.
 *
 * THE PROBLEM. The user's Safe is the depositor of record, `ragequit` must come from the
 * depositor, and a Safe transaction needs both owners. So if the server co-signer is gone and
 * the deposit is not in an ASP root, the funds are frozen - the invariant "if any service dies
 * no user loses funds or access" fails for the service we run most of.
 *
 * THE DESIGN, reusing audited contracts and deploying nothing of our own:
 *   - a Zodiac Delay Modifier 1.1.1 proxy (canonical mastercopy via the canonical
 *     ModuleProxyFactory) is enabled as a module on the Safe, owned by the Safe;
 *   - the passkey's SafeWebAuthnSigner - already a Safe owner - is enabled as a module ON THE
 *     DELAY. Delay 1.1.1 authenticates a module either as msg.sender or by an ERC-1271
 *     signature appended to calldata, so the passkey queues a transaction by signing it, and
 *     ANY address relays it;
 *   - after the cooldown, anyone executes it, and the Delay executes it as the Safe;
 *   - during the cooldown the Safe's owners (passkey + server, 2-of-2) can skip it.
 *
 * WHAT THIS TEST PERFORMS rather than asserts: passkey-only queue; execution refused before
 * the cooldown and accepted after; a depositor-only exit and an owner swap going through with
 * no server signature; the owners' veto; and every way a server acting alone might try to
 * queue, execute early, veto or reconfigure - each refused. It also performs the attack on the
 * FAULTY Delay 1.1.0, which is why the pinned mastercopy is 1.1.1.
 *
 * Skips without FORK_RPC. Set FORK_BLOCK to pin the block (and reuse forge's RPC cache).
 */
contract PasskeyRecoveryForkTest is Test {
    /*////////////////////////////////////////////////////////////
                    CANONICAL ADDRESSES (mainnet = Sepolia)
    ////////////////////////////////////////////////////////////*/

    IEntryPoint constant ENTRYPOINT = IEntryPoint(0x0000000071727De22E5E9d8BAf0edAc6f37da032);
    ISafeProxyFactory constant SAFE_FACTORY = ISafeProxyFactory(0x4e1DCf7AD4e460CfD30791CCC4F9c8a4f820ec67);
    address constant SAFE_SINGLETON = 0x41675C099F32341bf84BFc5382aF534df5C7461a;
    address constant SAFE_MODULE_SETUP = 0x2dd68b007B46fBe91B9A7c3EDa5A7a1063cB5b47;
    ISafe4337Module constant SAFE_4337_MODULE = ISafe4337Module(0x75cf11467937ce3F2f357CE24ffc3DBF8fD5c226);
    address constant MULTISEND_CALL_ONLY = 0x9641d764fc13c8B624c04430C7356C1C7C8102e2;
    IWebAuthnSignerFactory constant WEBAUTHN_FACTORY =
        IWebAuthnSignerFactory(0x1d31F259eE307358a26dFb23EB365939E8641195);
    address constant FCL_P256_VERIFIER = 0xA86e0054C51E4894D88762a017ECc5E5235f5DBA;

    IModuleProxyFactory constant MODULE_PROXY_FACTORY =
        IModuleProxyFactory(0x000000000000aDdB49795b0f9bA5BC298cDda236);
    /// Delay 1.1.1: the patched release. Never 1.1.0 - see the last test.
    address constant DELAY_MASTERCOPY = 0x824175b945838d127C1ca83CbcE11D8e44F6dF01;
    address constant DELAY_MASTERCOPY_FAULTY_110 = 0x01F8cabB808D7dE0dF4202D4B60C8310d2f1339b;

    // Runtime code hashes read from mainnet and Sepolia (identical), and for the Safe
    // contracts matching the safe-deployments registry. Pinned so a fork of the wrong chain,
    // or a future account at these addresses, fails here rather than passing vacuously.
    bytes32 constant DELAY_111_CODEHASH = 0xdd928eddfff7b68bd8fff28178c29e3388c1d098051d9262f151c4b534c577b8;
    bytes32 constant MODULE_FACTORY_CODEHASH = 0x01623cbcf010a1c326230f1b2d5f48a66b440232ee49096102bc84967dc5f21e;
    bytes32 constant SAFE_SINGLETON_CODEHASH = 0x1fe2df852ba3299d6534ef416eefa406e56ced995bca886ab7a553e6d0c5e1c4;
    bytes32 constant MULTISEND_CALL_ONLY_CODEHASH =
        0xecd5bd14a08c5d2122379900b2f272bdf107a7e92423c10dd5fe3254386c9939;
    bytes32 constant SAFE_4337_MODULE_CODEHASH = 0x2aea997c4e3cf0e2f333025372e219abcfde81c21fc2f8fb066414a5685dd3e0;


    /*////////////////////////////////////////////////////////////
                               PARAMETERS
    ////////////////////////////////////////////////////////////*/

    /// The recommended defaults (packages/smart-account/src/recovery.ts, DEFAULT_RECOVERY).
    uint256 constant COOLDOWN = 7 days;
    uint256 constant EXPIRATION = 7 days;

    uint256 constant P256_N = 0xFFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551;
    string constant RP_ID = "wallet.brl.example";
    string constant CLIENT_DATA_FIELDS = '"origin":"https://wallet.brl.example","crossOrigin":false';

    bool live;

    uint256 passkeyKey = uint256(keccak256("passkey")) % P256_N;
    address passkeySigner;
    address server;
    uint256 serverKey;
    address safe;
    IDelay delay;
    DepositorOnlyPool pool;
    address relayer = makeAddr("any relayer");
    address bundler = makeAddr("bundler");

    function setUp() public {
        string memory rpc = vm.envOr("FORK_RPC", string(""));
        if (bytes(rpc).length == 0) return;
        // Pin with FORK_BLOCK to reuse forge's RPC cache across runs. Unset, it forks the head:
        // a non-archive endpoint (the public ones) serves state only ~100 blocks back, so a
        // hard-coded block would stop working minutes after it was chosen. Nothing here
        // depends on the block beyond the contracts existing, which the code hashes pin.
        uint256 forkBlock = vm.envOr("FORK_BLOCK", uint256(0));
        if (forkBlock == 0) vm.createSelectFork(rpc);
        else vm.createSelectFork(rpc, forkBlock);
        live = true;

        assertEq(DELAY_MASTERCOPY.codehash, DELAY_111_CODEHASH, "Delay 1.1.1 mastercopy");
        assertEq(address(MODULE_PROXY_FACTORY).codehash, MODULE_FACTORY_CODEHASH, "ModuleProxyFactory 1.2.0");
        assertEq(SAFE_SINGLETON.codehash, SAFE_SINGLETON_CODEHASH, "Safe 1.4.1 singleton");
        assertEq(MULTISEND_CALL_ONLY.codehash, MULTISEND_CALL_ONLY_CODEHASH, "MultiSendCallOnly 1.4.1");
        assertEq(address(SAFE_4337_MODULE).codehash, SAFE_4337_MODULE_CODEHASH, "Safe4337Module 0.3.0");

        serverKey = uint256(keccak256("server co-signer"));
        server = vm.addr(serverKey);
        (uint256 x, uint256 y) = vm.publicKeyP256(passkeyKey);
        passkeySigner = WEBAUTHN_FACTORY.createSigner(x, y, uint176(uint160(FCL_P256_VERIFIER)));

        // The production account: Safe 1.4.1, 2-of-2, Safe4337Module enabled at setup.
        address[] memory owners = new address[](2);
        owners[0] = passkeySigner;
        owners[1] = server;
        address[] memory modules = new address[](1);
        modules[0] = address(SAFE_4337_MODULE);
        safe = SAFE_FACTORY.createProxyWithNonce(
            SAFE_SINGLETON,
            abi.encodeCall(
                ISafe.setup,
                (
                    owners,
                    2,
                    SAFE_MODULE_SETUP,
                    abi.encodeCall(ISafeModuleSetup.enableModules, (modules)),
                    address(SAFE_4337_MODULE),
                    address(0),
                    0,
                    payable(address(0))
                )
            ),
            uint256(keccak256("recovery fork test"))
        );
        vm.deal(safe, 10 ether);
        pool = new DepositorOnlyPool();

        // Normal life, both owners signing: deposit into the pool (the Safe becomes the
        // depositor of record), then set up recovery in one UserOperation.
        _userOp(abi.encodeCall(SAFE_4337_MODULE.executeUserOp, (address(pool), 3 ether, abi.encodeCall(pool.deposit, ()), 0)), true, true);
        assertEq(pool.deposited(safe), 3 ether);

        delay = IDelay(_predictDelay());
        _userOp(_recoverySetupCallData(), true, true);
    }

    /*////////////////////////////////////////////////////////////
                          SETUP IS WHAT WE THINK
    ////////////////////////////////////////////////////////////*/

    function test_RecoveryIsWiredAsDesigned() public view {
        if (!live) return;
        assertTrue(address(delay).code.length > 0, "delay proxy deployed");
        assertTrue(ISafe(safe).isModuleEnabled(address(delay)), "delay is a Safe module");
        assertTrue(delay.isModuleEnabled(passkeySigner), "passkey signer is a Delay module");
        assertFalse(delay.isModuleEnabled(server), "server is NOT a Delay module");
        assertEq(delay.owner(), safe, "owners (2-of-2) control the delay");
        assertEq(delay.avatar(), safe);
        assertEq(delay.target(), safe);
        assertEq(delay.txCooldown(), COOLDOWN);
        assertEq(delay.txExpiration(), EXPIRATION);
        // Safe owners and threshold are untouched: normal spending is still 2-of-2.
        assertEq(ISafe(safe).getThreshold(), 2);
        assertEq(ISafe(safe).getOwners().length, 2);
    }

    /*////////////////////////////////////////////////////////////
                    THE INVARIANT: SERVER DEAD, FUNDS OUT
    ////////////////////////////////////////////////////////////*/

    function test_PasskeyAloneExitsTheDepositorOnlyPoolWithTheServerOffline() public {
        if (!live) return;
        bytes memory ragequit = abi.encodeCall(pool.ragequit, ());
        uint256 safeBefore = safe.balance;

        // From here on the server signs nothing. The passkey signs a queue request, and an
        // arbitrary relayer - not the server, not the user - submits it.
        bytes memory queue = _passkeyQueue(address(pool), 0, ragequit, keccak256("salt-1"));
        vm.expectEmit(true, true, false, true, address(delay));
        emit IDelay.TransactionAdded(0, keccak256(abi.encodePacked(address(pool), uint256(0), ragequit, uint8(0))), address(pool), 0, ragequit, 0);
        vm.prank(relayer);
        (bool ok,) = address(delay).call(queue);
        assertTrue(ok, "passkey-signed queue accepted");
        uint256 queuedAt = block.timestamp;

        // Not before the cooldown - including one second before it ends.
        vm.expectRevert(bytes("Transaction is still in cooldown"));
        delay.executeNextTx(address(pool), 0, ragequit, 0);
        vm.warp(queuedAt + COOLDOWN - 1);
        vm.expectRevert(bytes("Transaction is still in cooldown"));
        delay.executeNextTx(address(pool), 0, ragequit, 0);

        // After it, anyone executes, and the Delay calls the pool AS THE SAFE.
        vm.warp(queuedAt + COOLDOWN);
        vm.prank(relayer);
        delay.executeNextTx(address(pool), 0, ragequit, 0);
        assertEq(pool.deposited(safe), 0, "exited");
        assertEq(safe.balance, safeBefore + 3 ether, "funds back in the Safe");
    }

    /**
     * Funds out is half the invariant; the other half is ACCESS. With the server gone for good,
     * the passkey replaces it as an owner through the same delayed path, and the account is a
     * working 2-of-2 again with a new co-signer - no funds moved to get there.
     */
    function test_PasskeyAloneReplacesADeadServerAndSpendingResumes() public {
        if (!live) return;
        (address newServer, uint256 newServerKey) = makeAddrAndKey("replacement co-signer");
        address[] memory owners = ISafe(safe).getOwners();
        address prev = owners[0] == server ? address(0x1) : owners[0];
        bytes memory swap = abi.encodeCall(ISafe.swapOwner, (prev, server, newServer));

        vm.prank(relayer);
        (bool ok,) = address(delay).call(_passkeyQueue(safe, 0, swap, keccak256("swap")));
        assertTrue(ok);
        vm.warp(block.timestamp + COOLDOWN);
        delay.executeNextTx(safe, 0, swap, 0);

        owners = ISafe(safe).getOwners();
        assertTrue(owners[0] == newServer || owners[1] == newServer, "new co-signer is an owner");
        assertTrue(owners[0] != server && owners[1] != server, "dead server removed");
        assertEq(ISafe(safe).getThreshold(), 2, "still 2-of-2");

        // Ordinary spending with passkey + new co-signer.
        serverKey = newServerKey;
        server = newServer;
        address payee = makeAddr("payee");
        _userOp(abi.encodeCall(SAFE_4337_MODULE.executeUserOp, (payee, 1 ether, "", 0)), true, true);
        assertEq(payee.balance, 1 ether);
    }

    /*////////////////////////////////////////////////////////////
                       THE OWNERS' VETO (2-of-2)
    ////////////////////////////////////////////////////////////*/

    /**
     * A stolen passkey queues a drain. It is visible for the whole cooldown - the monitor watches
     * `TransactionAdded` on the Delay - and passkey + server skip it.
     */
    function test_OwnersVetoAQueuedTransactionDuringTheCooldown() public {
        if (!live) return;
        address thief = makeAddr("thief");
        vm.prank(relayer);
        (bool ok,) = address(delay).call(_passkeyQueue(thief, 5 ether, "", keccak256("drain")));
        assertTrue(ok);
        assertEq(delay.queueNonce(), 1);

        // The veto is a 2-of-2 Safe transaction: setTxNonce past the queue.
        _userOp(abi.encodeCall(SAFE_4337_MODULE.executeUserOp, (address(delay), 0, abi.encodeCall(delay.setTxNonce, (1)), 0)), true, true);
        assertEq(delay.txNonce(), 1);

        vm.warp(block.timestamp + COOLDOWN + 1);
        vm.expectRevert(bytes("Transaction queue is empty"));
        delay.executeNextTx(thief, 5 ether, "", 0);
        assertEq(thief.balance, 0);
    }

    /*////////////////////////////////////////////////////////////
                  A COMPROMISED SERVER, ACTING ALONE
    ////////////////////////////////////////////////////////////*/

    function test_ServerAloneCannotQueueByCallingDirectly() public {
        if (!live) return;
        vm.prank(server);
        vm.expectRevert(abi.encodeWithSelector(IDelay.NotAuthorized.selector, server));
        delay.execTransactionFromModule(server, 5 ether, "", 0);
    }

    function test_ServerAloneCannotQueueWithItsOwnSignature() public {
        if (!live) return;
        bytes memory prefix = abi.encodeCall(IDelay.execTransactionFromModule, (server, 5 ether, "", 0));
        bytes32 salt = keccak256("server-salt");
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(serverKey, delay.moduleTxHash(prefix, salt));
        vm.prank(server);
        vm.expectRevert(abi.encodeWithSelector(IDelay.NotAuthorized.selector, server));
        (bool ok,) = address(delay).call(abi.encodePacked(prefix, salt, r, s, v));
        ok;
    }

    /// The server claims to be the passkey module, with an assertion the passkey never made.
    function test_ServerAloneCannotQueueByForgingAPasskeySignature() public {
        if (!live) return;
        bytes memory prefix = abi.encodeCall(IDelay.execTransactionFromModule, (server, 5 ether, "", 0));
        bytes32 salt = keccak256("forged");
        bytes32 hash = delay.moduleTxHash(prefix, salt);
        // A well-formed WebAuthn assertion over the right challenge, from a DIFFERENT P-256 key.
        bytes memory forged = _webauthn(hash, uint256(keccak256("not the passkey")) % P256_N);
        vm.prank(server);
        vm.expectRevert(abi.encodeWithSelector(IDelay.NotAuthorized.selector, server));
        (bool ok,) = address(delay).call(_withContractSignature(prefix, forged, salt));
        ok;
    }

    function test_ServerAloneCannotVetoReconfigureOrBypassTheDelay() public {
        if (!live) return;
        vm.prank(relayer);
        (bool ok,) = address(delay).call(_passkeyQueue(address(pool), 0, abi.encodeCall(pool.ragequit, ()), keccak256("x")));
        assertTrue(ok);

        bytes memory ownerOnly = abi.encodeWithSelector(IDelay.OwnableUnauthorizedAccount.selector, server);
        vm.startPrank(server);
        vm.expectRevert(ownerOnly);
        delay.setTxNonce(1); // veto
        vm.expectRevert(ownerOnly);
        delay.setTxCooldown(0); // shorten the window
        vm.expectRevert(ownerOnly);
        delay.enableModule(server); // make itself a module
        vm.expectRevert(ownerOnly);
        delay.disableModule(address(0x1), passkeySigner); // remove the passkey's path
        vm.stopPrank();

        // Nor through the Safe: a server-only UserOperation fails signature validation.
        PackedUserOperation memory op = _buildOp(
            abi.encodeCall(SAFE_4337_MODULE.executeUserOp, (address(delay), 0, abi.encodeCall(delay.setTxNonce, (1)), 0))
        );
        op.signature = abi.encodePacked(uint48(0), uint48(0), _serverSig(SAFE_4337_MODULE.getOperationHash(op)));
        PackedUserOperation[] memory ops = new PackedUserOperation[](1);
        ops[0] = op;
        vm.prank(bundler, bundler);
        vm.expectRevert(abi.encodeWithSelector(IEntryPoint.FailedOp.selector, 0, "AA24 signature error"));
        ENTRYPOINT.handleOps(ops, payable(bundler));

        // Nor by executing early, nor by executing something other than what was queued.
        vm.prank(server);
        vm.expectRevert(bytes("Transaction is still in cooldown"));
        delay.executeNextTx(address(pool), 0, abi.encodeCall(pool.ragequit, ()), 0);
        vm.warp(block.timestamp + COOLDOWN);
        vm.prank(server);
        vm.expectRevert(bytes("Transaction hashes do not match"));
        delay.executeNextTx(server, 3 ether, "", 0);
        assertEq(delay.txNonce(), 0, "the queue is untouched");
    }

    /*////////////////////////////////////////////////////////////
                     SIGNATURE HYGIENE ON THE QUEUE
    ////////////////////////////////////////////////////////////*/

    function test_ASignedQueueRequestCannotBeReplayed() public {
        if (!live) return;
        bytes memory queue = _passkeyQueue(address(pool), 0, abi.encodeCall(pool.ragequit, ()), keccak256("once"));
        vm.prank(relayer);
        (bool ok,) = address(delay).call(queue);
        assertTrue(ok);
        bytes32 hash = delay.moduleTxHash(_prefix(address(pool), 0, abi.encodeCall(pool.ragequit, ())), keccak256("once"));
        vm.prank(relayer);
        vm.expectRevert(abi.encodeWithSelector(IDelay.HashAlreadyConsumed.selector, hash));
        (ok,) = address(delay).call(queue);
        assertEq(delay.queueNonce(), 1);
    }

    /// A relayer cannot swap the destination under a genuine passkey signature.
    function test_APasskeySignatureDoesNotCoverAnotherTransaction() public {
        if (!live) return;
        bytes32 salt = keccak256("bound");
        bytes32 signedHash = delay.moduleTxHash(_prefix(address(pool), 0, abi.encodeCall(pool.ragequit, ())), salt);
        bytes memory sig = _webauthn(signedHash, passkeyKey);
        bytes memory swapped = _withContractSignature(_prefix(relayer, 5 ether, ""), sig, salt);
        vm.prank(relayer);
        vm.expectRevert(abi.encodeWithSelector(IDelay.NotAuthorized.selector, relayer));
        (bool ok,) = address(delay).call(swapped);
        ok;
    }

    /// Our EIP-712 reconstruction (and recovery.ts's) agrees with the deployed contract's.
    function test_ModuleTxHashMatchesTheDeployedDelay() public view {
        if (!live) return;
        bytes memory prefix = _prefix(address(pool), 1, hex"1234");
        bytes32 salt = keccak256("s");
        assertEq(delay.moduleTxHash(prefix, salt), _moduleTxHash(address(delay), prefix, salt));
    }

    /*////////////////////////////////////////////////////////////
                  LIVENESS: A FAILING TX MUST NOT JAM IT
    ////////////////////////////////////////////////////////////*/

    /**
     * The Delay executes strictly in order, and a queued call that REVERTS cannot be executed,
     * so it sits at the head of the queue. With the server gone nobody can skip it - except
     * expiry. This is why the expiration is non-zero: with 0 one bad call freezes recovery for
     * good. Here it costs one expiration window.
     */
    function test_AFailingQueuedCallExpiresInsteadOfBlockingRecoveryForever() public {
        if (!live) return;
        address broken = address(new AlwaysReverts());
        bytes memory ragequit = abi.encodeCall(pool.ragequit, ());
        uint256 t0 = block.timestamp;

        vm.prank(relayer);
        (bool ok,) = address(delay).call(_passkeyQueue(broken, 0, "", keccak256("broken")));
        assertTrue(ok);
        vm.warp(t0 + COOLDOWN);
        vm.expectRevert(bytes("Module transaction failed"));
        delay.executeNextTx(broken, 0, "", 0);

        // The user queues the real exit; it is stuck behind the failing call...
        vm.prank(relayer);
        (ok,) = address(delay).call(_passkeyQueue(address(pool), 0, ragequit, keccak256("exit")));
        assertTrue(ok);
        vm.warp(t0 + 2 * COOLDOWN);
        vm.expectRevert(bytes("Transaction hashes do not match"));
        delay.executeNextTx(address(pool), 0, ragequit, 0);

        // ...until the failing call expires and anyone skips it.
        vm.warp(t0 + COOLDOWN + EXPIRATION + 1);
        delay.skipExpired();
        assertEq(delay.txNonce(), 1);
        delay.executeNextTx(address(pool), 0, ragequit, 0);
        assertEq(pool.deposited(safe), 0);
    }

    /*////////////////////////////////////////////////////////////
                 WHY 1.1.1 AND NOT THE 1.1.0 MASTERCOPY
    ////////////////////////////////////////////////////////////*/

    /**
     * Delay 1.1.0's SignatureChecker ignored whether the ERC-1271 staticcall SUCCEEDED, so a
     * module whose verification path can be made to revert with the magic value authorises
     * anything. Gnosis Guild marks 1.1.0 FAULTY and 1.1.1 fixes it (audit: "Zodiac Signature
     * Patch Audit", June 2026). Performed here against both deployed mastercopies.
     */
    function test_TheFaultyDelay110AcceptsARevertingSignerAnd111DoesNot() public {
        if (!live) return;
        address module = address(new RevertsWithMagicValue());
        bytes memory init = abi.encodeCall(IDelay.setUp, (abi.encode(address(this), safe, safe, COOLDOWN, EXPIRATION)));
        IDelay faulty = IDelay(MODULE_PROXY_FACTORY.deployModule(DELAY_MASTERCOPY_FAULTY_110, init, 1));
        IDelay patched = IDelay(MODULE_PROXY_FACTORY.deployModule(DELAY_MASTERCOPY, init, 2));
        faulty.enableModule(module);
        patched.enableModule(module);

        bytes memory prefix = abi.encodeCall(IDelay.execTransactionFromModule, (relayer, 5 ether, "", 0));
        bytes memory junk = abi.encodePacked(prefix, hex"00", bytes32(0), bytes32(uint256(uint160(module))), bytes32(prefix.length), uint8(0));

        vm.prank(relayer);
        (bool ok,) = address(faulty).call(junk);
        assertTrue(ok, "1.1.0 accepts a signature that was never valid");
        assertEq(faulty.queueNonce(), 1);

        vm.prank(relayer);
        vm.expectRevert(abi.encodeWithSelector(IDelay.NotAuthorized.selector, relayer));
        (ok,) = address(patched).call(junk);
        assertEq(patched.queueNonce(), 0);
    }

    /*////////////////////////////////////////////////////////////
                                HELPERS
    ////////////////////////////////////////////////////////////*/

    /// Deterministic proxy address: ModuleProxyFactory's CREATE2 over a minimal proxy.
    function _predictDelay() internal view returns (address) {
        bytes memory code = abi.encodePacked(
            hex"602d8060093d393df3363d3d373d3d3d363d73", DELAY_MASTERCOPY, hex"5af43d82803e903d91602b57fd5bf3"
        );
        bytes32 salt = keccak256(abi.encodePacked(keccak256(_delayInitializer()), _delaySaltNonce()));
        return vm.computeCreate2Address(salt, keccak256(code), address(MODULE_PROXY_FACTORY));
    }

    function _delayInitializer() internal view returns (bytes memory) {
        return abi.encodeCall(IDelay.setUp, (abi.encode(safe, safe, safe, COOLDOWN, EXPIRATION)));
    }

    function _delaySaltNonce() internal pure returns (uint256) {
        return 0;
    }

    /// deploy Delay proxy, enable it on the Safe, enable the passkey signer on the Delay.
    function _recoverySetupCallData() internal view returns (bytes memory) {
        bytes memory d1 = abi.encodeCall(
            IModuleProxyFactory.deployModule, (DELAY_MASTERCOPY, _delayInitializer(), _delaySaltNonce())
        );
        bytes memory d2 = abi.encodeCall(ISafe.enableModule, (address(delay)));
        bytes memory d3 = abi.encodeCall(IDelay.enableModule, (passkeySigner));
        bytes memory batch = abi.encodePacked(
            abi.encodePacked(uint8(0), address(MODULE_PROXY_FACTORY), uint256(0), d1.length, d1),
            abi.encodePacked(uint8(0), safe, uint256(0), d2.length, d2),
            abi.encodePacked(uint8(0), address(delay), uint256(0), d3.length, d3)
        );
        // DELEGATECALL, but only into the canonical MultiSendCallOnly, which can only CALL.
        return abi.encodeCall(
            SAFE_4337_MODULE.executeUserOp, (MULTISEND_CALL_ONLY, 0, abi.encodeCall(IMultiSend.multiSend, (batch)), 1)
        );
    }

    function _prefix(address to, uint256 value, bytes memory data) internal pure returns (bytes memory) {
        return abi.encodeCall(IDelay.execTransactionFromModule, (to, value, data, 0));
    }

    /// EIP-712 ModuleTx(bytes data,bytes32 salt), domain (chainId, verifyingContract).
    function _moduleTxHash(address verifying, bytes memory prefix, bytes32 salt) internal view returns (bytes32) {
        bytes32 domain = keccak256(
            abi.encode(keccak256("EIP712Domain(uint256 chainId,address verifyingContract)"), block.chainid, verifying)
        );
        bytes32 structHash = keccak256(abi.encode(keccak256("ModuleTx(bytes data,bytes32 salt)"), keccak256(prefix), salt));
        return keccak256(abi.encodePacked(bytes1(0x19), bytes1(0x01), domain, structHash));
    }

    /// calldata ++ contract signature ++ salt ++ r(signer) ++ s(offset) ++ v(0), Zodiac's layout.
    function _withContractSignature(bytes memory prefix, bytes memory signature, bytes32 salt)
        internal
        view
        returns (bytes memory)
    {
        return abi.encodePacked(
            prefix, signature, salt, bytes32(uint256(uint160(passkeySigner))), bytes32(prefix.length), uint8(0)
        );
    }

    function _passkeyQueue(address to, uint256 value, bytes memory data, bytes32 salt) internal view returns (bytes memory) {
        bytes memory prefix = _prefix(to, value, data);
        return _withContractSignature(prefix, _webauthn(_moduleTxHash(address(delay), prefix, salt), passkeyKey), salt);
    }

    /// A WebAuthn assertion over `challenge`, encoded the way SafeWebAuthnSigner decodes it.
    function _webauthn(bytes32 challenge, uint256 key) internal pure returns (bytes memory) {
        bytes memory authenticatorData = abi.encodePacked(sha256(bytes(RP_ID)), uint8(0x05), uint32(1)); // UP|UV
        bytes memory clientDataJSON = abi.encodePacked(
            '{"type":"webauthn.get","challenge":"',
            Base64.encodeURL(abi.encodePacked(challenge)),
            '",',
            CLIENT_DATA_FIELDS,
            "}"
        );
        bytes32 message = sha256(abi.encodePacked(authenticatorData, sha256(clientDataJSON)));
        (bytes32 r, bytes32 s) = vm.signP256(key, message);
        uint256 lowS = uint256(s) > P256_N / 2 ? P256_N - uint256(s) : uint256(s);
        return abi.encode(authenticatorData, CLIENT_DATA_FIELDS, uint256(r), lowS);
    }

    function _serverSig(bytes32 hash) internal view returns (bytes memory) {
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(serverKey, hash);
        return abi.encodePacked(r, s, v);
    }

    function _buildOp(bytes memory callData) internal view returns (PackedUserOperation memory op) {
        op.sender = safe;
        op.nonce = ENTRYPOINT.getNonce(safe, 0);
        op.callData = callData;
        op.accountGasLimits = bytes32((uint256(2_500_000) << 128) | uint256(1_000_000));
        op.preVerificationGas = 100_000;
        op.gasFees = bytes32((uint256(1 gwei) << 128) | uint256(20 gwei));
        op.signature = abi.encodePacked(uint48(0), uint48(0)); // validAfter/validUntil, read by the hash
    }

    /// A UserOperation signed by the chosen owners, Safe's signature layout, through EntryPoint.
    function _userOp(bytes memory callData, bool withPasskey, bool withServer) internal {
        PackedUserOperation memory op = _buildOp(callData);
        bytes32 opHash = SAFE_4337_MODULE.getOperationHash(op);

        uint256 count = (withPasskey ? 1 : 0) + (withServer ? 1 : 0);
        bytes memory statics;
        bytes memory dynamics;
        bytes memory passkeySig = _webauthn(opHash, passkeyKey);
        bool passkeyFirst = uint160(passkeySigner) < uint160(server);
        for (uint256 i; i < 2; ++i) {
            bool isPasskey = (i == 0) == passkeyFirst;
            if (isPasskey && withPasskey) {
                statics = abi.encodePacked(
                    statics, bytes32(uint256(uint160(passkeySigner))), bytes32(count * 65 + dynamics.length), uint8(0)
                );
                dynamics = abi.encodePacked(dynamics, passkeySig.length, passkeySig);
            } else if (!isPasskey && withServer) {
                statics = abi.encodePacked(statics, _serverSig(opHash));
            }
        }
        op.signature = abi.encodePacked(uint48(0), uint48(0), statics, dynamics);
        PackedUserOperation[] memory ops = new PackedUserOperation[](1);
        ops[0] = op;
        vm.recordLogs();
        vm.prank(bundler, bundler);
        ENTRYPOINT.handleOps(ops, payable(bundler));
        // handleOps does not revert when the inner call fails, so check the event's flag.
        Vm.Log[] memory logs = vm.getRecordedLogs();
        bytes32 userOpEvent = keccak256("UserOperationEvent(bytes32,address,address,uint256,bool,uint256,uint256)");
        for (uint256 i; i < logs.length; ++i) {
            if (logs[i].topics[0] == userOpEvent) {
                (, bool success,,) = abi.decode(logs[i].data, (uint256, bool, uint256, uint256));
                assertTrue(success, "UserOperation inner call failed");
                return;
            }
        }
        fail();
    }
}
