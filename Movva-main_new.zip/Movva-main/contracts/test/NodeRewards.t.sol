// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {Governed} from "./utils/Governed.sol";
import {MovvaBase} from "./MovvaReserve.t.sol";
import {ExposureEntrypoint, ExposureOracle, ExposureVerifier} from "./LPRegistry.t.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";
import {LPRegistry} from "../ramp/LPRegistry.sol";
import {NodeRewards} from "../ramp/NodeRewards.sol";
import {IRewardsHook} from "../ramp/IRewardsHook.sol";
import {FiatEscrow} from "../ramp/FiatEscrow.sol";
import {IAttestorVerifier} from "../ramp/IAttestorVerifier.sol";
import {FeeSplitter} from "../movva/FeeSplitter.sol";
import {MovvaReserve} from "../movva/MovvaReserve.sol";

/// An 18-decimal reward token anyone can mint, standing in for Movva where the reserve is not the point.
contract RewardToken is ERC20 {
    constructor() ERC20("Reward", "RWD") {}

    function mint(address to, uint256 amount) external {
        _mint(to, amount);
    }
}

/// A hook that refuses every report.
contract RevertingHook is IRewardsHook {
    function onSettled(address, uint256, uint8) external pure {
        revert("hook refuses");
    }
}

/// A hook that never returns: it burns whatever gas it is given.
contract LoopingHook is IRewardsHook {
    function onSettled(address, uint256, uint8) external pure {
        uint256 i;
        while (true) {
            unchecked {
                ++i;
            }
        }
    }
}

/// A hook that answers with ~150 KB of return data, paid for inside its own budget.
contract ReturnDataBombHook {
    fallback() external {
        assembly {
            return(0, 150000)
        }
    }
}

/// Records the gas it was given.
contract GasMeterHook is IRewardsHook {
    uint256 public seen;

    function reset() external {
        seen = 1;
    }

    function onSettled(address, uint256, uint8) external {
        seen = gasleft();
    }
}

/// Calls back into the registry from inside the hook.
contract ReentrantHook is IRewardsHook {
    LPRegistry immutable registry;
    bool public reentered;

    constructor(LPRegistry r) {
        registry = r;
    }

    function onSettled(address lp, uint256 brlCents, uint8) external {
        registry.recordSettled(lp, brlCents); // not an escrow: ignored
        registry.releaseExposure(lp, brlCents); // reserved nothing: a no-op
        reentered = true;
    }
}

abstract contract NodeRewardsBase is Governed {
    uint256 internal constant ONE = 1e18;
    uint256 internal constant PER_CENT = 1e16;

    RewardToken token;
    LPRegistry registry;
    NodeRewards rewards;
    FeeSplitter splitter;

    address gov = makeAddr("gov");
    address treasury = makeAddr("mova treasury");
    address inst = makeAddr("institution");
    address inst2 = makeAddr("institution 2");
    address aff = makeAddr("affiliate");
    address retail = makeAddr("retail");
    address stranger = makeAddr("stranger");

    function setUp() public virtual {
        vm.warp(1_800_000_000);
        token = new RewardToken();
        registry = new LPRegistry(gov, DELAY);
        rewards = new NodeRewards(address(token), PER_CENT, 7 days, 3 days, gov, DELAY);
        splitter = new FeeSplitter(address(token), treasury, address(rewards), gov, DELAY);
        vm.startPrank(gov);
        // This test contract is the escrow that reports settlements.
        registry.setEscrow(address(this), true);
        registry.setTier(inst, LPRegistry.Tier.INSTITUTIONAL, 1_000_000_000);
        registry.setTier(inst2, LPRegistry.Tier.INSTITUTIONAL, 1_000_000_000);
        registry.setPhase(LPRegistry.Phase.C);
        registry.setRewardsHook(address(rewards));
        rewards.setRegistry(address(registry));
        splitter.setLpRewardShare(2_000);
        registry.completeSetup();
        rewards.completeSetup();
        splitter.completeSetup();
        vm.stopPrank();
        vm.prank(inst);
        registry.sponsorAffiliate(aff, 1_000_000);
        vm.prank(retail);
        registry.register();
    }

    function _settle(address lp, uint256 cents) internal {
        registry.recordSettled(lp, cents);
    }

    /// `fees` reach the splitter, and 20% of them reach NodeRewards, booked into the current epoch.
    function _fees(uint256 fees) internal {
        token.mint(address(splitter), fees);
        splitter.split();
    }

    function _finalizeThrough(uint256 epoch) internal {
        if (block.timestamp < rewards.finalizableAt(epoch)) vm.warp(rewards.finalizableAt(epoch));
        rewards.finalize(52);
    }

    function _claim(address lp, uint256 epoch) internal returns (uint256) {
        uint256[] memory ids = new uint256[](1);
        ids[0] = epoch;
        vm.prank(lp);
        return rewards.claim(ids, lp);
    }

    function _epoch(uint256 e)
        internal
        view
        returns (uint256 volume, uint256 voided, uint256 funded, uint256 budget, uint256 lpCap)
    {
        (volume, voided, funded, budget, lpCap) = rewards.epochs(e);
    }

    function _mustSchedule(bytes4 selector) internal {
        vm.expectRevert(abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, selector));
    }
}

contract NodeRewardsTest is NodeRewardsBase {
    /*//////////////////////////////////////////////////////////////
                               COUNTING
    //////////////////////////////////////////////////////////////*/

    function test_OnlyInstitutionsAndAffiliatesEarnAndDustDoesNotCount() public {
        _settle(inst, 10_000);
        _settle(aff, 20_000);
        _settle(retail, 30_000); // Phase C's permissionless tier: a farm of fresh addresses earns nothing
        _settle(inst, 999); // under the R$ 10,00 minimum
        vm.prank(gov);
        registry.setTier(inst2, LPRegistry.Tier.SUSPENDED, 0); // instant
        _settle(inst2, 40_000);

        assertEq(rewards.volumeOf(0, inst), 10_000);
        assertEq(rewards.volumeOf(0, aff), 20_000);
        assertEq(rewards.volumeOf(0, retail), 0, "retail does not earn");
        assertEq(rewards.volumeOf(0, inst2), 0, "a suspended LP does not earn");
        (uint256 volume,,,,) = _epoch(0);
        assertEq(volume, 30_000);
        // The registry's own books are untouched by any of it.
        (, uint256 settled,,,,,) = registry.lps(retail);
        assertEq(settled, 30_000);
    }

    function test_OnlyTheBoundRegistryReports() public {
        vm.prank(stranger);
        vm.expectRevert(NodeRewards.NotRegistry.selector);
        rewards.onSettled(stranger, 1_000_000, uint8(LPRegistry.Tier.INSTITUTIONAL));
        vm.expectRevert(NodeRewards.NotRegistry.selector);
        rewards.onSettled(inst, 1_000_000, uint8(LPRegistry.Tier.INSTITUTIONAL)); // the escrow, not the registry
    }

    /*//////////////////////////////////////////////////////////////
                               SHARING
    //////////////////////////////////////////////////////////////*/

    /// R$ 40.000 settled earns at most 10 bps: 40 tokens, split 3:1, however much the fees brought in.
    function test_AnEpochPaysProRataUpToTheVolumeBoundAndRollsTheRestForward() public {
        _settle(inst, 3_000_000);
        _settle(aff, 1_000_000);
        _fees(5_000 * ONE); // 1.000 tokens to NodeRewards, 4.000 to the treasury
        assertEq(token.balanceOf(treasury), 4_000 * ONE);
        (,, uint256 funded,,) = _epoch(0);
        assertEq(funded, 1_000 * ONE, "booked into the epoch it arrived in");

        vm.warp(rewards.finalizableAt(0) - 1);
        assertEq(rewards.finalizableEpochs(), 0, "still in review");
        assertEq(rewards.finalize(52), 0);
        vm.warp(rewards.finalizableAt(0));
        assertEq(rewards.finalizableEpochs(), 1);
        assertEq(rewards.finalize(52), 1);
        (,,, uint256 budget,) = _epoch(0);
        assertEq(budget, 40 * ONE, "4.000.000 centavos x 10 bps");
        assertEq(rewards.carry(), 960 * ONE);
        assertEq(rewards.outstanding(), 40 * ONE);

        (uint256 total, uint256[] memory ids) = rewards.claimableIn(inst, 0, 10);
        assertEq(total, 30 * ONE);
        assertEq(ids.length, 1);
        assertEq(_claim(inst, 0), 30 * ONE);
        assertEq(_claim(aff, 0), 10 * ONE);
        assertEq(token.balanceOf(inst), 30 * ONE);
        assertEq(token.balanceOf(aff), 10 * ONE);
        assertEq(rewards.outstanding(), 0);
        assertEq(rewards.accounted(), 960 * ONE);
        assertEq(rewards.totalClaimed(), 40 * ONE);
        assertEq(rewards.lastClaimAt(), block.timestamp);
    }

    function test_WhenFeesAreShortThePoolBinds() public {
        _settle(inst, 3_000_000);
        _settle(aff, 1_000_000);
        _fees(50 * ONE); // 10 tokens, under the 40 the volume would allow
        _finalizeThrough(0);
        assertEq(_claim(inst, 0), 7.5e18);
        assertEq(_claim(aff, 0), 2.5e18);
        assertEq(rewards.carry(), 0);
    }

    function test_AnEpochNobodyEligibleSettledRollsItsWholePoolForward() public {
        _settle(retail, 5_000_000);
        _fees(50 * ONE); // 10 tokens in epoch 0, which has no eligible volume
        vm.warp(rewards.epochEnd(0));
        _settle(inst, 1_000_000); // epoch 1: at most 10 tokens
        _fees(25 * ONE); // 5 more
        _finalizeThrough(1);
        (,,, uint256 budget0,) = _epoch(0);
        (,,, uint256 budget1,) = _epoch(1);
        assertEq(budget0, 0);
        assertEq(budget1, 10 * ONE, "epoch 0's 10 carried into epoch 1's pool of 15");
        assertEq(rewards.carry(), 5 * ONE);
        assertEq(_claim(inst, 1), 10 * ONE);
    }

    function test_AboveTheCapIsRolledForwardWhenClaimed() public {
        vm.prank(gov);
        rewards.setRewardLimits(10, 5 * ONE, 1_000); // lowering the cap is instant
        _settle(inst, 3_000_000);
        _settle(aff, 1_000_000);
        _fees(5_000 * ONE);
        _finalizeThrough(0);
        assertEq(_claim(inst, 0), 5 * ONE, "a 30 share, capped at 5");
        assertEq(_claim(aff, 0), 5 * ONE, "a 10 share, capped at 5");
        assertEq(rewards.carry(), 990 * ONE, "960 left over, and 30 above the caps");

        vm.warp(rewards.epochEnd(0) + 1 days + 3 days); // epoch 1 is running
        _settle(inst, 1_000_000);
        _finalizeThrough(rewards.currentEpoch() - 1);
        _finalizeThrough(rewards.currentEpoch());
        uint256 e = rewards.currentEpoch() - 1;
        (,,, uint256 budget,) = _epoch(e);
        assertEq(budget, 10 * ONE, "the rolled-forward pool pays the next epoch's volume");
        assertEq(_claim(inst, e), 5 * ONE);
    }

    /// Rewards wait for the LP however long it takes, and one claim collects several epochs.
    function test_NothingExpiresAndOneClaimSpansEpochs() public {
        uint256[] memory ids = new uint256[](3);
        for (uint256 i; i < 3; ++i) {
            vm.warp(rewards.epochEnd(0) - 7 days + i * 7 days + 1 hours);
            _settle(inst, 1_000_000);
            _fees(50 * ONE);
            ids[i] = rewards.currentEpoch();
        }
        vm.warp(block.timestamp + 365 days);
        rewards.finalize(52);
        assertEq(rewards.claimable(inst, ids), 30 * ONE);
        vm.prank(inst);
        assertEq(rewards.claim(ids, inst), 30 * ONE);
        assertEq(rewards.claimable(inst, ids), 0);
    }

    function test_AClaimRefusesTheUnfinalizedTheClaimedAndTheEmpty() public {
        _settle(inst, 1_000_000);
        _fees(50 * ONE);
        vm.prank(inst);
        uint256[] memory ids = new uint256[](1);
        vm.expectRevert(abi.encodeWithSelector(NodeRewards.NotFinalized.selector, 0));
        rewards.claim(ids, inst);
        _finalizeThrough(0);
        vm.prank(aff);
        vm.expectRevert(abi.encodeWithSelector(NodeRewards.NothingToClaim.selector, 0));
        rewards.claim(ids, aff);
        _claim(inst, 0);
        vm.prank(inst);
        vm.expectRevert(abi.encodeWithSelector(NodeRewards.AlreadyClaimed.selector, 0));
        rewards.claim(ids, inst);
        vm.prank(inst);
        vm.expectRevert(DelayedGovernance.ZeroAddress.selector);
        rewards.claim(ids, address(0));
        vm.prank(inst);
        vm.expectRevert(NodeRewards.TooManyEpochs.selector);
        rewards.claim(new uint256[](53), inst);
    }

    function test_SyncBooksADonationOnceIntoTheCurrentEpoch() public {
        vm.warp(rewards.epochEnd(1) + 1);
        token.mint(address(rewards), 7 * ONE);
        assertEq(rewards.sync(), 7 * ONE);
        assertEq(rewards.sync(), 0, "booked once");
        (,, uint256 funded,,) = _epoch(2);
        assertEq(funded, 7 * ONE);
        assertEq(rewards.totalFunded(), 7 * ONE);
    }

    /*//////////////////////////////////////////////////////////////
                         REVIEW: VOID AND EXCLUDE
    //////////////////////////////////////////////////////////////*/

    /// A voided share rolls forward: the other LP is paid exactly what it would have been paid anyway.
    function test_VoidedVolumeRollsForwardAndRaisesNobodyElsesShare() public {
        _settle(inst, 3_000_000);
        _settle(aff, 1_000_000);
        _fees(5_000 * ONE);
        vm.warp(rewards.epochEnd(0) + 1); // ended, in review
        vm.prank(gov);
        rewards.voidVolume(0, inst);
        assertEq(rewards.volumeOf(0, inst), 0);
        (uint256 volume, uint256 voided,,,) = _epoch(0);
        assertEq(volume, 4_000_000, "the denominator keeps the voided volume");
        assertEq(voided, 3_000_000);

        _finalizeThrough(0);
        assertEq(rewards.outstanding(), 10 * ONE, "only the affiliate's share stays allocated");
        assertEq(rewards.carry(), 990 * ONE);
        assertEq(_claim(aff, 0), 10 * ONE, "unchanged by the void");
        vm.prank(inst);
        uint256[] memory ids = new uint256[](1);
        vm.expectRevert(abi.encodeWithSelector(NodeRewards.NothingToClaim.selector, 0));
        rewards.claim(ids, inst);
    }

    function test_VoidingIsTheGovernorsInstantlyAndOnlyInReview() public {
        _settle(inst, 3_000_000);
        vm.prank(stranger);
        vm.expectRevert(DelayedGovernance.NotGovernor.selector);
        rewards.voidVolume(0, inst);
        vm.prank(gov);
        vm.expectRevert(NodeRewards.NothingToVoid.selector);
        rewards.voidVolume(0, aff);
        vm.prank(gov);
        vm.expectRevert(abi.encodeWithSelector(NodeRewards.ReviewClosed.selector, 1));
        rewards.voidVolume(1, inst); // an epoch that has not begun
        vm.warp(rewards.finalizableAt(0));
        vm.prank(gov);
        vm.expectRevert(abi.encodeWithSelector(NodeRewards.ReviewClosed.selector, 0));
        rewards.voidVolume(0, inst); // the review is over, finalized or not
    }

    function test_ExclusionIsInstantReinstatementWaitsAndEarnedRewardsStay() public {
        _settle(inst, 1_000_000);
        vm.prank(gov);
        rewards.setExcluded(inst, true);
        _settle(inst, 2_000_000);
        assertEq(rewards.volumeOf(0, inst), 1_000_000, "excluded: new volume does not count");

        vm.prank(gov);
        _mustSchedule(NodeRewards.setExcluded.selector);
        rewards.setExcluded(inst, false);

        _fees(50 * ONE);
        _finalizeThrough(0);
        assertEq(_claim(inst, 0), 10 * ONE, "what was earned before the exclusion is still paid");

        _afterDelay(address(rewards), abi.encodeCall(NodeRewards.setExcluded, (inst, false)));
        _settle(inst, 1_000_000);
        assertEq(rewards.volumeOf(rewards.currentEpoch(), inst), 1_000_000, "counted again once reinstated");
    }

    /*//////////////////////////////////////////////////////////////
                               GOVERNANCE
    //////////////////////////////////////////////////////////////*/

    function test_EachLimitIsClassifiedByDirection() public {
        vm.startPrank(gov);
        _mustSchedule(NodeRewards.setRewardLimits.selector);
        rewards.setRewardLimits(11, 10_000 * ONE, 1_000); // a higher rate
        _mustSchedule(NodeRewards.setRewardLimits.selector);
        rewards.setRewardLimits(10, 10_001 * ONE, 1_000); // a higher cap
        _mustSchedule(NodeRewards.setRewardLimits.selector);
        rewards.setRewardLimits(10, 10_000 * ONE, 999); // a lower minimum
        rewards.setRewardLimits(5, 1 * ONE, 5_000); // all three the safe way: instant
        vm.stopPrank();
        assertEq(rewards.rewardBpsOfVolume(), 5);

        _afterDelay(address(rewards), abi.encodeCall(NodeRewards.setRewardLimits, (20, 10_000 * ONE, 1_000)));
        assertEq(rewards.rewardBpsOfVolume(), 20, "through the delay, up to the hard cap");
        bytes memory tooHigh = abi.encodeCall(NodeRewards.setRewardLimits, (21, 10_000 * ONE, 1_000));
        vm.prank(gov);
        rewards.schedule(tooHigh);
        vm.warp(block.timestamp + DELAY);
        vm.prank(gov);
        vm.expectRevert(NodeRewards.RateTooHigh.selector);
        rewards.execute(tooHigh);
    }

    function test_BindingARegistryIsInstantOnlyWhileNothingWasEverFunded() public {
        NodeRewards fresh = new NodeRewards(address(token), PER_CENT, 7 days, 3 days, gov, DELAY);
        LPRegistry other = new LPRegistry(gov, DELAY);
        vm.startPrank(gov);
        fresh.completeSetup();
        fresh.setRegistry(address(registry)); // after setup, but holding nothing: instant
        fresh.setRegistry(address(other));
        vm.expectRevert(NodeRewards.NotAContract.selector);
        fresh.setRegistry(stranger);
        vm.stopPrank();

        token.mint(address(fresh), 1); // the smallest donation is something to protect
        vm.startPrank(gov);
        _mustSchedule(NodeRewards.setRegistry.selector);
        fresh.setRegistry(address(registry));
        fresh.setRegistry(address(0)); // unbinding stays instant
        _mustSchedule(NodeRewards.setRegistry.selector);
        fresh.setRegistry(address(other));
        vm.stopPrank();
        _afterDelay(address(fresh), abi.encodeCall(NodeRewards.setRegistry, (address(other))));
        assertEq(fresh.registry(), address(other));
    }

    function test_TheConstructorRefusesWhatWouldBreakTheBooks() public {
        vm.expectRevert(NodeRewards.NotAContract.selector);
        new NodeRewards(stranger, PER_CENT, 7 days, 3 days, gov, DELAY);
        vm.expectRevert(NodeRewards.BadTokenPerCent.selector);
        new NodeRewards(address(token), 0, 7 days, 3 days, gov, DELAY);
        vm.expectRevert(NodeRewards.BadEpochLength.selector);
        new NodeRewards(address(token), PER_CENT, 1 days - 1, 3 days, gov, DELAY);
        vm.expectRevert(NodeRewards.BadReviewPeriod.selector);
        new NodeRewards(address(token), PER_CENT, 7 days, 14 days + 1, gov, DELAY);
    }

    function test_NothingRunsBeforeSetupCloses() public {
        NodeRewards open = new NodeRewards(address(token), PER_CENT, 7 days, 3 days, gov, DELAY);
        vm.expectRevert(DelayedGovernance.SetupIncomplete.selector);
        open.sync();
        vm.expectRevert(DelayedGovernance.SetupIncomplete.selector);
        open.finalize(1);
    }

    /*//////////////////////////////////////////////////////////////
                                  FUZZ
    //////////////////////////////////////////////////////////////*/

    /**
     * Any sequence of settlements, fees, time, voids, finalizations and claims: no claim pays past the per-LP cap or
     * past the rate bound on the claimant's own volume, and the books always add up to what was funded.
     */
    function testFuzz_ClaimsNeverExceedFundsOrTheirBounds(uint256 seed) public {
        address[4] memory who = [inst, inst2, aff, retail];
        uint256 paid;
        for (uint256 step; step < 40; ++step) {
            seed = uint256(keccak256(abi.encode(seed, step)));
            address lp = who[seed % 4];
            uint256 op = (seed >> 8) % 6;
            uint256 x = seed >> 64;
            if (op == 0) {
                _settle(lp, x % 5_000_000);
            } else if (op == 1) {
                _fees(x % (100_000 * ONE));
            } else if (op == 2) {
                vm.warp(block.timestamp + 1 hours + x % 4 days);
            } else if (op == 3) {
                rewards.finalize(1 + x % 4);
            } else if (op == 4) {
                paid += _claimAllChecked(lp);
            } else {
                uint256 e = rewards.currentEpoch();
                if (rewards.volumeOf(e, lp) != 0) {
                    vm.prank(gov);
                    rewards.voidVolume(e, lp);
                }
            }
            _assertBooks(paid);
        }
        vm.warp(block.timestamp + 30 days);
        rewards.finalize(52);
        for (uint256 i; i < 4; ++i) {
            paid += _claimAllChecked(who[i]);
        }
        _assertBooks(paid);
    }

    function _claimAllChecked(address lp) internal returns (uint256 got) {
        (uint256 total, uint256[] memory ids) = rewards.claimableIn(lp, 0, rewards.nextToFinalize());
        if (ids.length == 0) return 0;
        for (uint256 i; i < ids.length; ++i) {
            (uint256 volume,,, uint256 budget, uint256 lpCap) = _epoch(ids[i]);
            uint256 v = rewards.volumeOf(ids[i], lp);
            uint256 share = budget * v / volume;
            assertLe(share < lpCap ? share : lpCap, lpCap, "past the per-LP cap");
            assertLe(share, v * PER_CENT * rewards.MAX_REWARD_BPS_OF_VOLUME() / 10_000, "more per centavo than the rate allows");
        }
        uint256 before = token.balanceOf(lp);
        vm.prank(lp);
        rewards.claim(ids, lp);
        got = token.balanceOf(lp) - before;
        assertEq(got, total, "claimableIn said what claim pays");
    }

    function _assertBooks(uint256 paid) internal view {
        assertEq(rewards.totalClaimed(), paid);
        assertLe(rewards.totalClaimed(), rewards.totalFunded(), "claimed more than was funded");
        assertEq(rewards.accounted(), rewards.totalFunded() - rewards.totalClaimed());
        assertGe(token.balanceOf(address(rewards)), rewards.accounted());
        uint256 unfinalized;
        for (uint256 e = rewards.nextToFinalize(); e <= rewards.currentEpoch(); ++e) {
            (,, uint256 funded,,) = _epoch(e);
            unfinalized += funded;
        }
        assertEq(rewards.accounted(), rewards.carry() + rewards.outstanding() + unfinalized, "the books do not add up");
    }
}

/*//////////////////////////////////////////////////////////////
                     THE REGISTRY'S REWARDS HOOK
//////////////////////////////////////////////////////////////*/

contract RewardsHookTest is NodeRewardsBase {
    function _install(address hook) internal {
        vm.prank(gov);
        registry.setRewardsHook(address(0));
        _afterDelay(address(registry), abi.encodeCall(LPRegistry.setRewardsHook, (hook)));
    }

    function test_SettingAHookWaitsAndRemovingItDoesNot() public {
        RevertingHook h = new RevertingHook();
        vm.prank(gov);
        _mustSchedule(LPRegistry.setRewardsHook.selector);
        registry.setRewardsHook(address(h));
        vm.prank(gov);
        registry.setRewardsHook(address(0));
        assertEq(registry.rewardsHook(), address(0));
        _settle(inst, 1_000_000); // no hook: nothing reported, nothing required
        assertEq(rewards.volumeOf(0, inst), 0);
        _afterDelay(address(registry), abi.encodeCall(LPRegistry.setRewardsHook, (address(rewards))));
        _settle(inst, 1_000_000);
        assertEq(rewards.volumeOf(rewards.currentEpoch(), inst), 1_000_000);
    }

    function test_AHookMustBeAContract() public {
        bytes memory call = abi.encodeCall(LPRegistry.setRewardsHook, (stranger));
        vm.prank(gov);
        registry.schedule(call);
        vm.warp(block.timestamp + DELAY);
        vm.prank(gov);
        vm.expectRevert(LPRegistry.BadRewardsHook.selector);
        registry.execute(call);
    }

    /// The finding this hook must never become: a reward contract that can hold a taker's funds hostage.
    function test_ARevertingLoopingOrBombingHookNeverBlocksASettlement() public {
        address[3] memory hooks = [address(new RevertingHook()), address(new LoopingHook()), address(new ReturnDataBombHook())];
        for (uint256 i; i < hooks.length; ++i) {
            _install(hooks[i]);
            (, uint256 before,,,,,) = registry.lps(inst);
            if (i < 2) {
                vm.expectEmit(address(registry));
                emit LPRegistry.RewardsHookFailed(hooks[i], inst, 1_000_000);
            }
            uint256 g = gasleft();
            _settle(inst, 1_000_000);
            uint256 used = g - gasleft();
            (, uint256 afterwards,,,,,) = registry.lps(inst);
            assertEq(afterwards, before + 1_000_000, "the settlement was recorded");
            // The hook's budget plus the registry's own work: the bomb's 150 KB was never copied into this frame.
            assertLt(used, registry.REWARDS_HOOK_GAS() + 45_000, "a hook cost the settlement more than its budget");
        }
    }

    function test_AHookCallingBackInFindsTheBooksFinal() public {
        ReentrantHook h = new ReentrantHook(registry);
        _install(address(h));
        _settle(inst, 1_000_000);
        assertTrue(h.reentered());
        (, uint256 settled, uint32 settlements,,,,) = registry.lps(inst);
        assertEq(settled, 1_000_000, "the reentrant report was ignored");
        assertEq(settlements, 1);
    }

    /**
     * With a tight gas limit the call either gives the hook its whole budget, or reverts - never skips it. Skipping
     * would let anyone releasing an order erase the LP's volume, and eth_estimateGas would pick exactly that limit.
     */
    function test_TheHookGetsItsWholeBudgetOrTheSettlementReverts() public {
        GasMeterHook meter = new GasMeterHook();
        _install(address(meter));
        uint256 succeeded;
        uint256 refused;
        for (uint256 gas = 60_000; gas <= 200_000; gas += 2_500) {
            meter.reset();
            try registry.recordSettled{gas: gas}(inst, 1_000_000) {
                ++succeeded;
                assertGe(meter.seen(), 97_000, "a settlement succeeded while its hook was starved");
            } catch (bytes memory reason) {
                ++refused;
                if (reason.length >= 4) assertEq(bytes4(reason), LPRegistry.RewardsHookNeedsGas.selector);
            }
        }
        assertGt(succeeded, 0);
        assertGt(refused, 0);
    }

    function test_AnUnboundRewardsContractOnlyCostsTheLpItsVolume() public {
        vm.prank(gov);
        rewards.setRegistry(address(0)); // instant
        vm.expectEmit(address(registry));
        emit LPRegistry.RewardsHookFailed(address(rewards), inst, 1_000_000);
        _settle(inst, 1_000_000);
        assertEq(rewards.volumeOf(0, inst), 0);
    }
}

/*//////////////////////////////////////////////////////////////
                              FEE SPLITTER
//////////////////////////////////////////////////////////////*/

contract FeeSplitterTest is NodeRewardsBase {
    function test_TheShareStartsAtZeroAndEverythingReachesTheTreasury() public {
        FeeSplitter s = new FeeSplitter(address(token), treasury, address(rewards), gov, DELAY);
        vm.prank(gov);
        s.completeSetup();
        assertEq(s.lpRewardShareBps(), 0);
        token.mint(address(s), 1_000 * ONE);
        (uint256 toRewards, uint256 toTreasury) = s.split();
        assertEq(toRewards, 0);
        assertEq(toTreasury, 1_000 * ONE);
        assertEq(token.balanceOf(treasury), 1_000 * ONE);
        (toRewards, toTreasury) = s.split();
        assertEq(toRewards + toTreasury, 0, "nothing left: a no-op, not a revert");
    }

    function test_SplitsTheLpShareToRewardsAndBooksItThere() public {
        token.mint(address(splitter), 1_001);
        vm.prank(stranger); // anyone
        (uint256 toRewards, uint256 toTreasury) = splitter.split();
        assertEq(toRewards, 200, "rounded down for the LPs");
        assertEq(toTreasury, 801, "the treasury takes the remainder");
        (,, uint256 funded,,) = _epoch(0);
        assertEq(funded, 200);
        assertEq(token.balanceOf(address(splitter)), 0);
    }

    function test_RaisingTheShareWaitsLoweringDoesNotAndHalfIsTheMost() public {
        vm.startPrank(gov);
        _mustSchedule(FeeSplitter.setLpRewardShare.selector);
        splitter.setLpRewardShare(2_001);
        splitter.setLpRewardShare(1_000); // instant
        vm.stopPrank();
        assertEq(splitter.lpRewardShareBps(), 1_000);
        _afterDelay(address(splitter), abi.encodeCall(FeeSplitter.setLpRewardShare, (5_000)));
        assertEq(splitter.lpRewardShareBps(), 5_000);
        bytes memory tooMuch = abi.encodeCall(FeeSplitter.setLpRewardShare, (5_001));
        vm.prank(gov);
        splitter.schedule(tooMuch);
        vm.warp(block.timestamp + DELAY - 1);
        vm.prank(gov);
        vm.expectRevert();
        splitter.execute(tooMuch); // not yet
        vm.warp(block.timestamp + 1);
        vm.prank(gov);
        vm.expectRevert(FeeSplitter.ShareTooHigh.selector);
        splitter.execute(tooMuch);
    }

    function test_TreasuryAndRewardsChangesFollowTheDelay() public {
        address newTreasury = makeAddr("new treasury");
        vm.startPrank(gov);
        _mustSchedule(FeeSplitter.setTreasury.selector);
        splitter.setTreasury(newTreasury);
        NodeRewards next = new NodeRewards(address(token), PER_CENT, 7 days, 3 days, gov, DELAY);
        _mustSchedule(FeeSplitter.setRewards.selector);
        splitter.setRewards(address(next));
        splitter.setRewards(address(0)); // removing is instant, and sends everything to the treasury
        vm.stopPrank();
        token.mint(address(splitter), 100);
        (uint256 toRewards,) = splitter.split();
        assertEq(toRewards, 0);
        assertEq(token.balanceOf(treasury), 100);
        _afterDelay(address(splitter), abi.encodeCall(FeeSplitter.setTreasury, (newTreasury)));
        assertEq(splitter.treasury(), newTreasury);
    }

    function test_ARewardsContractPayingAnotherTokenIsRefused() public {
        NodeRewards wrong = new NodeRewards(address(new RewardToken()), PER_CENT, 7 days, 3 days, gov, DELAY);
        vm.expectRevert(FeeSplitter.RewardsTokenMismatch.selector);
        new FeeSplitter(address(token), treasury, address(wrong), gov, DELAY);
        FeeSplitter s = new FeeSplitter(address(token), treasury, address(0), gov, DELAY);
        vm.prank(gov);
        vm.expectRevert(FeeSplitter.RewardsTokenMismatch.selector);
        s.setRewards(address(wrong));
        vm.prank(gov);
        vm.expectRevert(FeeSplitter.RewardsTokenMismatch.selector);
        s.setRewards(stranger);
    }

    function test_ARewardsContractThatRefusesToBookDoesNotStopTheTreasury() public {
        NodeRewards inSetup = new NodeRewards(address(token), PER_CENT, 7 days, 3 days, gov, DELAY);
        FeeSplitter s = new FeeSplitter(address(token), treasury, address(inSetup), gov, DELAY);
        vm.startPrank(gov);
        s.setLpRewardShare(5_000);
        s.completeSetup();
        vm.stopPrank();
        token.mint(address(s), 100);
        vm.expectEmit(address(s));
        emit FeeSplitter.RewardsSyncFailed(address(inSetup));
        s.split();
        assertEq(token.balanceOf(treasury), 50);
        assertEq(token.balanceOf(address(inSetup)), 50);
        vm.prank(gov);
        inSetup.completeSetup();
        assertEq(inSetup.sync(), 50, "booked by the next sync");
    }

    function test_SplitWaitsForSetupToClose() public {
        FeeSplitter s = new FeeSplitter(address(token), treasury, address(rewards), gov, DELAY);
        vm.expectRevert(DelayedGovernance.SetupIncomplete.selector);
        s.split();
    }
}

/*//////////////////////////////////////////////////////////////
          INTEGRATION: A REAL SETTLEMENT ON A REAL FIATESCROW
//////////////////////////////////////////////////////////////*/

/**
 * The whole path on real contracts: a gateway mints Movva at the reserve and pays the mint fee to the FeeSplitter; it
 * sells Movva over a real FiatEscrow, which settles against a PIX proof and reports to the real LPRegistry, whose hook
 * counts the volume in NodeRewards; the fees are split, the epoch finalized, and the gateway claims.
 */
contract NodeRewardsIntegrationTest is MovvaBase {
    LPRegistry registry;
    FiatEscrow onramp;
    ExposureVerifier verifier;
    NodeRewards rewards;
    FeeSplitter splitter;
    address taker = makeAddr("taker");
    address movvaTreasury = makeAddr("mova treasury");
    bytes32 constant PIX = keccak256("gateway@pix");
    uint16 constant PIX_MASK = uint16(1 << uint8(IAttestorVerifier.Rail.PIX));

    function setUp() public override {
        super.setUp();
        registry = new LPRegistry(gov, DELAY);
        rewards = new NodeRewards(address(movva), 1e16, 7 days, 3 days, gov, DELAY);
        splitter = new FeeSplitter(address(movva), movvaTreasury, address(rewards), gov, DELAY);
        verifier = new ExposureVerifier();
        ExposureEntrypoint ep = new ExposureEntrypoint();
        onramp = new FiatEscrow(
            address(new ExposureOracle()), address(registry), address(ep), address(ep), 300, gov, DELAY, DISPUTE_TIMEOUT,
            TAKER_DISPUTE_TIMEOUT,
            MAX_VETTING_FEE_BPS
        );
        vm.startPrank(gov);
        registry.setEscrow(address(onramp), true);
        registry.setTier(gateway, LPRegistry.Tier.INSTITUTIONAL, 100_000_000);
        registry.setRewardsHook(address(rewards));
        rewards.setRegistry(address(registry));
        splitter.setLpRewardShare(2_000);
        onramp.setVerifier(address(verifier), true);
        onramp.setAsset(address(movva), address(reserve), 18, true);
        registry.completeSetup();
        rewards.completeSetup();
        splitter.completeSetup();
        onramp.completeSetup();
        vm.stopPrank();
        // The reserve is live: pointing its fees at the splitter, and charging one, each waits out its delay.
        _afterDelay(address(reserve), abi.encodeCall(MovvaReserve.setFeeRecipient, (address(splitter))));
        _afterDelay(address(reserve), abi.encodeCall(MovvaReserve.setFees, (10, 10)));
        _warp(0); // fresh oracle legs after the delays
    }

    function test_ARealSettlementEarnsTheGatewayItsShareOfTheFees() public {
        _mint(100_000 * U);
        uint256 fees = movva.balanceOf(address(splitter));
        assertGt(fees, 539e18, "the 10 bps mint fee on ~R$ 540.000 went to the splitter");

        vm.startPrank(gateway);
        movva.approve(address(onramp), type(uint256).max);
        bytes32 offerId =
            onramp.postOffer(address(movva), 10_000e18, 100, PIX, 1e18, 10_000e18, address(verifier), PIX_MASK);
        vm.stopPrank();
        vm.prank(taker);
        bytes32 orderId = onramp.lockOrder(offerId, 5_000e18, FiatEscrow.Delivery.DIRECT, taker, 0);
        verifier.setProof(
            orderId,
            IAttestorVerifier.Payment({
                bankTxId: keccak256("e2e pix"),
                payeeKeyHash: PIX,
                payerRef: bytes32(0),
                amountBrlCents: 500_000,
                paidAt: uint64(block.timestamp),
                rail: IAttestorVerifier.Rail.PIX
            })
        );
        onramp.releaseWithProof(orderId, "");
        assertEq(movva.balanceOf(taker), 5_000e18, "the taker received the Movva");
        assertEq(rewards.volumeOf(0, gateway), 500_000, "the registry's hook counted R$ 5.000,00 for the gateway");

        (uint256 toRewards, uint256 toTreasury) = splitter.split();
        assertEq(toRewards, fees * 2_000 / 10_000);
        assertEq(movva.balanceOf(movvaTreasury), toTreasury);

        vm.warp(rewards.finalizableAt(0));
        rewards.finalize(1);
        uint256[] memory ids = new uint256[](1);
        vm.prank(gateway);
        uint256 paid = rewards.claim(ids, gateway);
        // R$ 5.000,00 settled earns at most 10 bps: R$ 5,00 of Movva. The rest of the LPs' share rolls forward.
        assertEq(paid, 5e18);
        assertEq(rewards.carry(), toRewards - 5e18);
        assertEq(movva.balanceOf(address(rewards)), toRewards - 5e18);
    }
}
