// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Governed} from "./utils/Governed.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {YieldVault} from "../yield/YieldVault.sol";
import {
    SuperstateUSTBAdapter,
    IUSTB,
    IUSTBRedemption,
    ISuperstateNavOracle
} from "../yield/adapters/SuperstateUSTBAdapter.sol";

interface IAllowlistV3 {
    function owner() external view returns (address);
    function setProtocolAddressPermission(address addr, string calldata instrument, bool isAllowed) external;
}

interface IOwned {
    function owner() external view returns (address);
}

interface ISuperstateOracleAdmin {
    function addCheckpoint(uint64 timestamp, uint64 effectiveAt, uint128 navs, bool shouldOverrideEffectiveAt) external;
    function maximumAcceptablePriceDelta() external view returns (uint256);
}

interface IRedemptionAdmin {
    function withdraw(address token, address to, uint256 amount) external;
}

interface IUSTBQuote {
    function calculateSuperstateTokenOut(uint256 inAmount, address stablecoin)
        external
        view
        returns (uint256 out, uint256 afterFee, uint256 fee);
}

/**
 * The USTB adapter against Superstate's real contracts on a mainnet fork.
 *
 * ## What is simulated, exactly
 *
 * Everything the issuer would do is done by pranking the issuer's own owner addresses - read
 * from the contracts at the fork block, never typed in - and calling the issuer's own functions.
 * No storage is written and no issuer contract is replaced:
 *
 *  - **Allowlisting the vault's adapter**: `AllowlistV3.setProtocolAddressPermission(adapter,
 *    "USTB", true)` from `AllowlistV3.owner()`. This is how RedemptionIdle itself is allowlisted,
 *    and what Superstate's docs describe for DeFi protocols. In reality it needs Superstate's
 *    agreement; nothing here obtains that.
 *  - **Publishing a NAV**: `SuperstateOracle.addCheckpoint(...)` from `SuperstateOracle.owner()`,
 *    satisfying the contract's own rules (chronological, effective now or later, within
 *    `maximumAcceptablePriceDelta`). The NAV published is the oracle's own extrapolated value, so
 *    "accrual" is the fund's real trajectory, not a number we chose - except in the bad-NAV test,
 *    which publishes the largest jump the issuer's contract accepts.
 *  - **Emptying the redemption facility**: `RedemptionIdle.withdraw(USDC, sink, balance)` from its owner.
 *  - **Test USDC** for depositors comes from forge's `deal`.
 *
 * Subscriptions and redemptions go through `USTB.subscribe` and `RedemptionIdle.redeem`
 * unmodified, at whatever fees, pauses and liquidity mainnet has at the fork block.
 *
 * Skips without FORK_RPC. `USTB_FORK_BLOCK` pins a block, which needs an archive RPC; the
 * public node this was developed against serves only the last few hundred blocks, so the default
 * is the latest block and every assertion is written to hold at any recent one.
 */
contract SuperstateUSTBForkTest is Governed {
    address constant USDC = 0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48;
    address constant USTB = 0x43415eB6ff9DB7E26A15b704e7A3eDCe97d31C4e;
    address constant REDEMPTION = 0x4c21B7577C8FE8b0B0669165ee7C8f67fa1454Cf;
    address constant ORACLE = 0xE4fA682f94610cCd170680cc3B045d77D9E528a8;
    address constant ALLOWLIST = 0x02f1fA8B196d21c7b733EB2700B825611d8A38E5;

    uint256 constant MAX_NAV_AGE = 4 days;
    uint16 constant MAX_GROWTH_BPS = 1_000;

    bool live;
    YieldVault vault;
    SuperstateUSTBAdapter adapter;
    address gov = makeAddr("gov");
    address keeper = makeAddr("keeper");
    address alice = makeAddr("alice");
    address sink = makeAddr("sink");

    function setUp() public {
        string memory rpc = vm.envOr("FORK_RPC", string(""));
        if (bytes(rpc).length == 0) return;
        uint256 blk = vm.envOr("USTB_FORK_BLOCK", uint256(0));
        if (blk == 0) vm.createSelectFork(rpc);
        else vm.createSelectFork(rpc, blk);
        live = true;

        vault = new YieldVault(IERC20(USDC), "Shielded T-bills", "syUSDC", gov, gov, keeper, 1e18, 500, DELAY);
        adapter = new SuperstateUSTBAdapter(
            address(vault), IUSTB(USTB), IUSTBRedemption(REDEMPTION), MAX_NAV_AGE, MAX_GROWTH_BPS, 100, 25
        );
        vm.startPrank(gov);
        vault.addAdapter(adapter, 9_500);
        vault.completeSetup();
        vm.stopPrank();

        deal(USDC, alice, 1_000_000e6);
        vm.prank(alice);
        IERC20(USDC).approve(address(vault), type(uint256).max);
    }

    function _allowlist(bool allowed) internal {
        vm.prank(IAllowlistV3(ALLOWLIST).owner());
        IAllowlistV3(ALLOWLIST).setProtocolAddressPermission(address(adapter), "USTB", allowed);
    }

    function _depositAndAllocate() internal {
        vm.prank(alice);
        vault.deposit(1_000_000e6, alice);
        vm.prank(keeper);
        vault.allocate(adapter, 900_000e6);
    }

    /// Publish a checkpoint the way Superstate's automation does: yesterday's 5pm NAV, effective now.
    function _publish(uint256 navs) internal {
        (uint80 round,,,,) = ISuperstateNavOracle(ORACLE).latestRoundData();
        (uint64 ts, uint64 eff,) = ISuperstateNavOracle(ORACLE).checkpoints(round);
        // A newer checkpoint may be pending (published, not yet effective); build on that one.
        try ISuperstateNavOracle(ORACLE).checkpoints(uint256(round) + 1) returns (uint64 t2, uint64 e2, uint128) {
            ts = t2;
            eff = e2;
        } catch {}
        uint64 stamp = uint64(block.timestamp - 16 hours);
        if (stamp <= ts) stamp = ts + 1;
        uint64 effective = uint64(block.timestamp) > eff ? uint64(block.timestamp) : eff + 1;
        vm.prank(IOwned(ORACLE).owner());
        ISuperstateOracleAdmin(ORACLE).addCheckpoint(stamp, effective, uint128(navs), true);
        if (effective > block.timestamp) vm.warp(effective);
    }

    function _nav() internal view returns (uint256) {
        (, int256 a,,,) = ISuperstateNavOracle(ORACLE).latestRoundData();
        return uint256(a);
    }

    /*//////////////////////////////////////////////////////////////
                                  TESTS
    //////////////////////////////////////////////////////////////*/

    /// Before Superstate onboards the vault, the real token refuses it and the adapter says so.
    function test_TheRealAllowlistRefusesAnUnlistedVaultAndTheAdapterSaysWhy() public {
        if (!live) return;
        emit log_named_uint("fork block", block.number);
        assertFalse(IUSTB(USTB).isAllowed(address(adapter)));
        assertEq(adapter.maxDeposit(), 0);
        assertEq(adapter.depositBlocker(), "adapter is not on the USTB allowlist");
        (bool ok, uint256 nav) = adapter.oracleNav();
        assertTrue(ok, "the live NAV passes freshness and the floor");
        assertGt(nav, 7e6);
    }

    /// Deposit -> real subscription -> NAV accrues and is published -> real redemption.
    function test_SubscribeAccrueAndRedeemAgainstTheRealFund() public {
        if (!live) return;
        _allowlist(true);
        assertEq(adapter.depositBlocker(), "", "nothing else stands in the way at this block");

        (uint256 quoted,,) = IUSTBQuote(USTB).calculateSuperstateTokenOut(900_000e6, USDC);
        _depositAndAllocate();
        uint256 held = IERC20(USTB).balanceOf(address(adapter));
        assertEq(held, quoted, "minted exactly what the fund quoted");
        assertGe(adapter.totalValue() * 10_000, 900_000e6 * uint256(10_000 - 25), "entry cost within bound");
        assertLe(adapter.totalValue(), 900_000e6, "never valued above cost at entry");

        // Two days pass. Superstate publishes the NAV its own oracle extrapolates to.
        uint256 before = vault.totalAssets();
        vm.warp(block.timestamp + 2 days);
        _publish(_nav());
        uint256 after_ = vault.totalAssets();
        assertGt(after_, before, "T-bill yield reached the share price");
        // A few percent a year on 900k for two days: tens to a few hundred USDC.
        assertLt(after_ - before, 500e6, "and not an implausible amount");

        uint256 shares = vault.balanceOf(alice);
        vm.prank(alice);
        uint256 out = vault.redeem(shares, alice, alice);
        assertGt(out, 1_000_000e6 - 1_000e6, "principal back, less at most the stated costs");
        assertEq(IERC20(USTB).balanceOf(address(adapter)), 0, "every USTB went back through RedemptionIdle");
        emit log_named_uint("USDC out for 1,000,000 in, two days", out);
    }

    /**
     * Superstate's oracle accepts a checkpoint up to `maximumAcceptablePriceDelta` ($1.00 at the
     * time of writing, ~9%) above the last. Published, it moves the real oracle's answer at once.
     * The adapter's rate bound keeps it out of the share price.
     */
    function test_TheLargestNavJumpTheIssuerAcceptsCannotInflateTheSharePrice() public {
        if (!live) return;
        _allowlist(true);
        _depositAndAllocate();
        uint256 price = vault.assetsPerShare();

        uint256 delta = ISuperstateOracleAdmin(ORACLE).maximumAcceptablePriceDelta();
        (uint80 round,,,,) = ISuperstateNavOracle(ORACLE).latestRoundData();
        (,, uint128 lastNavs) = ISuperstateNavOracle(ORACLE).checkpoints(round);
        vm.warp(block.timestamp + 1 hours);
        _publish(uint256(lastNavs) + delta - 1);
        assertGt(_nav(), (uint256(lastNavs) * 10_300) / 10_000, "the real oracle jumped");

        uint256 elapsed = 2 hours;
        uint256 cap = (price * MAX_GROWTH_BPS * elapsed) / (10_000 * 365 days) + 2;
        assertLe(vault.assetsPerShare(), price + cap, "the vault's share price did not");
    }

    /// The facility is empty: holders can take idle USDC, and maxWithdraw says that is all.
    function test_AnEmptyRedemptionFacilityLimitsExitsToWhatIsIdle() public {
        if (!live) return;
        _allowlist(true);
        _depositAndAllocate();
        uint256 bal = IERC20(USDC).balanceOf(REDEMPTION);
        vm.prank(IOwned(REDEMPTION).owner());
        IRedemptionAdmin(REDEMPTION).withdraw(USDC, sink, bal);

        assertEq(adapter.maxInstantWithdraw(), 0);
        assertEq(vault.maxWithdraw(alice), 100_000e6);
        vm.prank(alice);
        vault.withdraw(100_000e6, alice, alice);

        // Superstate refills it: the rest comes out.
        vm.prank(sink);
        require(IERC20(USDC).transfer(REDEMPTION, bal), "refill");
        uint256 shares = vault.balanceOf(alice);
        vm.prank(alice);
        vault.redeem(shares, alice, alice);
        assertGt(IERC20(USDC).balanceOf(alice), 999_000e6);
    }

    /// Superstate revokes the adapter: the USTB leg freezes against the real token, nothing else.
    function test_ARevokedAllowlistEntryFreezesOnlyTheUSTBLeg() public {
        if (!live) return;
        _allowlist(true);
        _depositAndAllocate();
        _allowlist(false);

        assertEq(adapter.redemptionBlocker(), "adapter is not on the USTB allowlist");
        assertEq(vault.maxWithdraw(alice), 100_000e6);
        vm.prank(address(vault));
        assertEq(adapter.withdraw(1_000e6, alice), 0, "no revert against the real token");
        vm.prank(alice);
        vault.withdraw(100_000e6, alice, alice);

        _allowlist(true);
        uint256 shares = vault.balanceOf(alice);
        vm.prank(alice);
        vault.redeem(shares, alice, alice);
        assertGt(IERC20(USDC).balanceOf(alice), 999_000e6);
    }

    /// No checkpoint for five days: the real oracle starts reverting. The vault must not freeze.
    function test_TheRealOracleExpiringDoesNotFreezeTheVault() public {
        if (!live) return;
        _allowlist(true);
        _depositAndAllocate();
        uint256 v = adapter.totalValue();
        vm.warp(block.timestamp + 6 days);
        vm.expectRevert();
        ISuperstateNavOracle(ORACLE).latestRoundData();

        assertApproxEqRel(adapter.totalValue(), (v * 99) / 100, 2e15, "last good NAV less the haircut");
        assertEq(adapter.maxInstantWithdraw(), 0);
        vm.prank(alice);
        vault.withdraw(100_000e6, alice, alice);
    }
}
