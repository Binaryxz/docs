// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Governed} from "./utils/Governed.sol";
import {FiatEscrow} from "../ramp/FiatEscrow.sol";
import {LPRegistry} from "../ramp/LPRegistry.sol";
import {IAttestorVerifier} from "../ramp/IAttestorVerifier.sol";
import {RulingLib} from "../ramp/RulingLib.sol";
import {MockVerifier, MockOracle, MockEntrypoint} from "./FiatEscrow.t.sol";

interface ISafeProxyFactory {
    function createProxyWithNonce(address singleton, bytes memory initializer, uint256 saltNonce)
        external
        returns (address proxy);
}

interface ISafe {
    function setup(
        address[] calldata owners,
        uint256 threshold,
        address to,
        bytes calldata data,
        address fallbackHandler,
        address paymentToken,
        uint256 payment,
        address paymentReceiver
    ) external;
    /// Served by the CompatibilityFallbackHandler.
    function getMessageHash(bytes memory message) external view returns (bytes32);
    function isValidSignature(bytes32 hash, bytes calldata signature) external view returns (bytes4);
}

/**
 * SRM1-22 against the REAL Safe: a Safe 1.4.1 2-of-3 with the CompatibilityFallbackHandler,
 * built from the canonical factory and singleton (the custody Safes' exact setup, see
 * scripts/custody-rehearsal.ts), registered as a fresh FiatEscrow's only arbitrator.
 *
 * Its owners sign the Safe's SafeMessage hash of the ruling digest, which is what the Safe
 * app's "sign message" produces; the escrow is handed `safe ‖ signatures` and asks the Safe.
 * The unit tests use a stand-in multisig; this is what proves the encoding, the fallback
 * handler under STATICCALL and the threshold are the real ones.
 *
 * Skipped unless FORK_RPC is set (the addresses are canonical on mainnet and Sepolia):
 *   FORK_RPC=$SEPOLIA_RPC forge test --match-path contracts/test/ContractArbitratorFork.t.sol
 */
contract ContractArbitratorForkTest is Governed {
    address constant SAFE_FACTORY = 0x4e1DCf7AD4e460CfD30791CCC4F9c8a4f820ec67;
    address constant SAFE_SINGLETON = 0x41675C099F32341bf84BFc5382aF534df5C7461a;
    address constant SAFE_FALLBACK = 0xfd0732Dc9E303f09fCEf3a7388Ad10A83459Ec99;

    bool live;
    FiatEscrow escrow;
    MockVerifier verifier;
    ISafe safe;
    uint256[3] keys = [uint256(0x5AFE01), 0x5AFE02, 0x5AFE03];
    address governor = makeAddr("governor");
    address lp = makeAddr("lp");
    address taker = makeAddr("taker");
    address payout = makeAddr("payout");
    bytes32 constant PIX = keccak256("lp@pix");

    function setUp() public {
        string memory rpc = vm.envOr("FORK_RPC", string(""));
        if (bytes(rpc).length == 0) return;
        vm.createSelectFork(rpc);
        if (SAFE_FACTORY.code.length == 0 || SAFE_SINGLETON.code.length == 0 || SAFE_FALLBACK.code.length == 0) return;
        live = true;

        address[] memory owners = new address[](3);
        for (uint256 i; i < 3; i++) owners[i] = vm.addr(keys[i]);
        bytes memory init = abi.encodeCall(
            ISafe.setup, (owners, 2, address(0), "", SAFE_FALLBACK, address(0), 0, address(0))
        );
        safe = ISafe(ISafeProxyFactory(SAFE_FACTORY).createProxyWithNonce(SAFE_SINGLETON, init, uint256(keccak256("srm1-22"))));

        MockEntrypoint entrypoint = new MockEntrypoint();
        verifier = new MockVerifier();
        LPRegistry registry = new LPRegistry(governor, DELAY);
        escrow = new FiatEscrow(
            address(new MockOracle()), address(registry), address(entrypoint), address(entrypoint), 500, governor, DELAY, DISPUTE_TIMEOUT,
            TAKER_DISPUTE_TIMEOUT,
            MAX_VETTING_FEE_BPS
        );
        vm.startPrank(governor);
        registry.setEscrow(address(escrow), true);
        registry.setTier(lp, LPRegistry.Tier.INSTITUTIONAL, 1_000_000_00);
        registry.completeSetup();
        escrow.setVerifier(address(verifier), true);
        escrow.setArbitrator(address(safe), true); // the Safe is the only arbitrator
        escrow.completeSetup();
        vm.stopPrank();
        vm.deal(lp, 10 ether);
    }

    function _disputed() internal returns (bytes32 orderId) {
        vm.prank(lp);
        bytes32 offerId = escrow.postOffer{value: 5 ether}(
            address(0), 5 ether, 3_000_000, PIX, 0.01 ether, 5 ether, address(verifier),
            uint16(1 << uint8(IAttestorVerifier.Rail.PIX))
        );
        vm.prank(taker);
        orderId = escrow.lockOrder(offerId, 1 ether, FiatEscrow.Delivery.DIRECT, payout, 0);
        vm.warp(block.timestamp + 1);
        vm.prank(taker);
        escrow.raiseDispute(orderId, "paid, attestor down");
    }

    function _ruling(bytes32 orderId) internal view returns (RulingLib.Ruling memory r, bytes32 d) {
        r = RulingLib.Ruling({
            orderId: orderId,
            outcome: "RELEASE",
            evidenceRoot: keccak256("evidence"),
            rationale: "bank statement shows the payment",
            ruledAt: uint64(block.timestamp),
            byDefault: false
        });
        d = this.digestOf(r);
    }

    function digestOf(RulingLib.Ruling calldata r) external view returns (bytes32) {
        return RulingLib.digest(r, address(escrow));
    }

    /// Owners' ECDSA signatures over the Safe's message hash of `d`, sorted by owner.
    function _safeSig(bytes32 d, uint256[] memory signers) internal view returns (bytes memory sigs) {
        bytes32 h = safe.getMessageHash(abi.encode(d));
        for (uint256 i; i < signers.length; i++) {
            for (uint256 j = i + 1; j < signers.length; j++) {
                if (vm.addr(signers[j]) < vm.addr(signers[i])) (signers[i], signers[j]) = (signers[j], signers[i]);
            }
        }
        for (uint256 i; i < signers.length; i++) {
            (uint8 v, bytes32 r, bytes32 s) = vm.sign(signers[i], h);
            sigs = abi.encodePacked(sigs, r, s, v);
        }
    }

    function test_ARealSafeTwoOfThreeRulesAndOneOwnerCannot() public {
        if (!live) return;
        bytes32 orderId = _disputed();
        (RulingLib.Ruling memory r, bytes32 d) = _ruling(orderId);

        uint256[] memory one = new uint256[](1);
        one[0] = keys[1];
        bytes memory oneSig = abi.encodePacked(address(safe), _safeSig(d, one)); // before expectRevert: it calls the Safe
        vm.expectRevert(abi.encodeWithSelector(RulingLib.ContractSignatureRejected.selector, address(safe)));
        escrow.resolveDispute(orderId, r, oneSig);

        uint256[] memory two = new uint256[](2);
        (two[0], two[1]) = (keys[2], keys[0]);
        bytes memory inner = _safeSig(d, two);
        assertEq(safe.isValidSignature(d, inner), bytes4(0x1626ba7e), "the Safe itself approves");

        bytes memory sig = abi.encodePacked(address(safe), inner);
        escrow.resolveDispute(orderId, r, sig);
        vm.warp(block.timestamp + 1 days); // RULING_DELAY
        vm.prank(taker);
        escrow.resolveDispute(orderId, r, sig);
        assertEq(payout.balance, 1 ether, "released on the Safe's 2-of-3 ruling");
    }
}
