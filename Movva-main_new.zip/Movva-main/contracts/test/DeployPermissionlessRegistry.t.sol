// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Governed} from "./utils/Governed.sol";
import {DeployPermissionlessRegistry} from "../script/DeployPermissionlessRegistry.s.sol";
import {FiatEscrow} from "../ramp/FiatEscrow.sol";
import {OffRampEscrow} from "../ramp/OffRampEscrow.sol";
import {LPRegistry} from "../ramp/LPRegistry.sol";
import {PermissionlessLPRegistry} from "../ramp/PermissionlessLPRegistry.sol";
import {Movva} from "../movva/Movva.sol";
import {PlrOracle, PlrPool, PlrVerifier} from "./PermissionlessRampIntegration.t.sol";

/// The deploy script against a local copy of a live rail: a curated LPRegistry with its registered pair, MOVVA listed
/// (and capped) on both, ETH delisted as on Sepolia, a zkTLS verifier and an arbitrator. Local only: nothing here, or
/// in the script, has been run against a live network.
contract DeployPermissionlessRegistryTest is Governed {
    address governor = makeAddr("live governor");
    address arbitrator = makeAddr("arbitrator Safe");
    FiatEscrow oldOn;
    OffRampEscrow oldOff;
    LPRegistry old;
    Movva movva;
    PlrVerifier zktls;
    PlrOracle oracle;

    function setUp() public {
        vm.warp(1_800_000_000);
        movva = new Movva();
        oracle = new PlrOracle();
        zktls = new PlrVerifier();
        PlrPool pool = new PlrPool();
        old = new LPRegistry(governor, DELAY);
        oldOn = new FiatEscrow(
            address(oracle),
            address(old),
            address(pool),
            address(pool),
            500,
            governor,
            DELAY,
            DISPUTE_TIMEOUT,
            TAKER_DISPUTE_TIMEOUT,
            MAX_VETTING_FEE_BPS
        );
        oldOff =
            new OffRampEscrow(address(oracle), address(old), 500, governor, DELAY, DISPUTE_TIMEOUT);
        vm.startPrank(governor);
        old.setEscrow(address(oldOn), true);
        old.setEscrow(address(oldOff), true);
        old.completeSetup();
        oldOn.setAsset(address(movva), address(oracle), 18, true);
        oldOff.setAsset(address(movva), address(oracle), 18, true);
        oldOn.setAssetCap(address(movva), 1_000_000e18);
        oldOff.setAssetCap(address(movva), 1_000_000e18);
        oldOn.setAsset(address(0), address(oracle), 18, false);
        oldOff.setAsset(address(0), address(oracle), 18, false);
        oldOn.setVerifier(address(zktls), true);
        oldOff.setVerifier(address(zktls), true);
        oldOn.setArbitrator(arbitrator, true);
        oldOff.setArbitrator(arbitrator, true);
        oldOn.completeSetup();
        oldOff.completeSetup();
        vm.stopPrank();

        vm.setEnv("OLD_ONRAMP", vm.toString(address(oldOn)));
        vm.setEnv("OLD_OFFRAMP", vm.toString(address(oldOff)));
        vm.setEnv("MOVVA_TOKEN", vm.toString(address(movva)));
        vm.setEnv("ZKTLS_VERIFIER", vm.toString(address(zktls)));
        vm.setEnv("ARBITRATORS", vm.toString(arbitrator));
        // Every test sets the same values (the environment is shared by tests running in parallel); UNBONDING_PERIOD
        // is left unset, so `run()` derives it. Other inputs go through `deploy` directly.
        vm.setEnv("MIN_BOND", vm.toString(uint256(5_000e18)));
    }

    function test_DeploysTheRegistryAndAnUnchangedPairBoundToIt() public {
        DeployPermissionlessRegistry.Deployed memory d = new DeployPermissionlessRegistry().run();
        PermissionlessLPRegistry r = d.registry;
        assertTrue(r.escrowsBound());
        assertEq(r.fiatEscrow(), address(d.onramp));
        assertEq(r.offRampEscrow(), address(d.offramp));
        assertEq(address(d.onramp.REGISTRY()), address(r));
        assertEq(address(d.offramp.REGISTRY()), address(r));
        assertEq(address(r.PREDECESSOR()), address(old));
        assertEq(address(r.MOVVA()), address(movva));
        assertEq(r.MIN_BOND(), 5_000e18);
        assertEq(
            r.UNBONDING_PERIOD(),
            DISPUTE_TIMEOUT + 1 days + 4 days + 1 days,
            "derived from the live pair"
        );
        assertEq(d.onramp.governor(), governor);
        assertEq(d.offramp.governor(), governor);
        assertTrue(d.onramp.setupComplete() && d.offramp.setupComplete());
        assertEq(d.onramp.assetCap(address(movva)), 1_000_000e18);
        assertEq(d.onramp.arbitratorSince(arbitrator), block.timestamp);
        // The same escrow code as the live pair, byte for byte except the immutables (registry and governor's
        // constructor values are immutables or storage; the runtime length is identical).
        assertEq(address(d.onramp).code.length, address(oldOn).code.length);
        assertEq(address(d.offramp).code.length, address(oldOff).code.length);
        assertLe(address(r).code.length, 24_576);
        // The deployer's one power is spent.
        address deployer = r.DEPLOYER();
        vm.prank(deployer);
        vm.expectRevert(PermissionlessLPRegistry.AlreadyBound.selector);
        r.bindEscrows(address(d.onramp), address(d.offramp));
        // Nothing changed on the live rail.
        assertTrue(old.isEscrow(address(oldOn)) && old.isEscrow(address(oldOff)));
    }

    function _inputs(uint256 minBond, uint256 unbonding)
        internal
        view
        returns (DeployPermissionlessRegistry.Inputs memory p)
    {
        p.oldOn = oldOn;
        p.oldOff = oldOff;
        p.movva = address(movva);
        p.zktls = address(zktls);
        p.arbitrators = new address[](1);
        p.arbitrators[0] = arbitrator;
        p.minBond = minBond;
        p.unbonding = unbonding;
    }

    function test_ExplicitParametersAreKept() public {
        DeployPermissionlessRegistry.Deployed memory d =
            new DeployPermissionlessRegistry().deploy(_inputs(10_000e18, 60 days));
        assertEq(d.registry.MIN_BOND(), 10_000e18);
        assertEq(d.registry.UNBONDING_PERIOD(), 60 days);
    }

    function test_AnUnbondingPeriodInsideTheDisputeWindowIsRefused() public {
        DeployPermissionlessRegistry script = new DeployPermissionlessRegistry();
        // timeout + ruling delay + margin exactly: not longer, so bindEscrows refuses and the broadcast fails.
        DeployPermissionlessRegistry.Inputs memory p = _inputs(5_000e18, DISPUTE_TIMEOUT + 5 days);
        vm.expectRevert();
        script.deploy(p);
    }

    /// The new on-ramp takes the live on-ramp's taker dispute timeout (H-04) and vetting fee cap (H-02)
    /// when the live one has them; explicit inputs win.
    function test_TheOnrampsNewParametersAreCopiedOrGiven() public {
        DeployPermissionlessRegistry.Deployed memory d = new DeployPermissionlessRegistry().run();
        assertEq(d.onramp.TAKER_DISPUTE_TIMEOUT(), oldOn.TAKER_DISPUTE_TIMEOUT());
        assertEq(d.onramp.MAX_VETTING_FEE_BPS(), oldOn.MAX_VETTING_FEE_BPS());
        assertEq(d.onramp.pendingChanges(), 0);

        DeployPermissionlessRegistry.Inputs memory p = _inputs(5_000e18, 0);
        p.takerDisputeTimeout = 3 days;
        p.maxVettingFeeBps = 50;
        d = new DeployPermissionlessRegistry().deploy(p);
        assertEq(d.onramp.TAKER_DISPUTE_TIMEOUT(), 3 days);
        assertEq(d.onramp.MAX_VETTING_FEE_BPS(), 50);
    }

    /// On chain id 1 the live pair's governor must be a contract, not a key.
    function test_OnMainnetAKeyGovernorIsRefused() public {
        uint256 chain = block.chainid;
        vm.chainId(1);
        DeployPermissionlessRegistry script = new DeployPermissionlessRegistry();
        vm.expectRevert(bytes("governor: no code; on mainnet it must be a Safe or timelock, not a key"));
        script.deploy(_inputs(5_000e18, 0));
        vm.chainId(chain);
    }

    function test_AnUnlistedBondTokenIsRefused() public {
        DeployPermissionlessRegistry script = new DeployPermissionlessRegistry();
        DeployPermissionlessRegistry.Inputs memory p = _inputs(5_000e18, 0);
        p.movva = address(new Movva()); // a token the live pair does not list
        vm.expectRevert(bytes("MOVVA_TOKEN: not listed on the live pair"));
        script.deploy(p);
    }
}
