// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

import {Test} from "forge-std/Test.sol";
import {SponsorPaymaster, IEntryPoint} from "../SponsorPaymaster.sol";
import {SponsorGate, ISponsorPaymaster} from "../SponsorGate.sol";
import {MockEntryPoint} from "./SponsorPaymaster.t.sol";

/**
 * SponsorGate in front of the real SponsorPaymaster. The attacks here are what a leaked co-signer
 * operator key would try: reach an owner power, add accounts past the budget, keep working after
 * revocation.
 */
contract SponsorGateTest is Test {
    MockEntryPoint ep;
    SponsorPaymaster pm;
    SponsorGate gate;

    address gov = makeAddr("gov");
    address guardian = makeAddr("guardian");
    address op1 = makeAddr("cosigner-1");
    address op2 = makeAddr("cosigner-2");
    address stranger = makeAddr("stranger");
    address payable treasury = payable(makeAddr("treasury"));

    uint32 constant BUDGET = 3;

    function setUp() public {
        ep = new MockEntryPoint();
        pm = new SponsorPaymaster(IEntryPoint(address(ep)), gov);
        gate = new SponsorGate(ISponsorPaymaster(address(pm)), gov, guardian, BUDGET);
        vm.deal(gov, 100 ether);
        vm.startPrank(gov);
        pm.deposit{value: 10 ether}();
        pm.transferOwnership(address(gate));
        gate.setBudget(1 days, 0.5 ether);
        gate.setMaxCostAllowed(0.05 ether);
        gate.setOperator(op1, true);
        gate.setOperator(op2, true);
        vm.stopPrank();
    }

    function _acct(uint256 i) internal pure returns (address) {
        return address(uint160(0xA11CE0000 + i));
    }

    /*//////////////////////////////////////////////////////////////
                               OPERATORS
    //////////////////////////////////////////////////////////////*/

    function test_AnOperatorSponsorsThroughTheGate() public {
        vm.expectEmit(address(gate));
        emit SponsorGate.Sponsored(op1, _acct(1));
        vm.prank(op1);
        gate.sponsor(_acct(1));
        assertTrue(pm.sponsored(_acct(1)));
        assertEq(gate.remainingSponsorships(), BUDGET - 1);

        // An operator key is not the paymaster's owner: it cannot go around the budget.
        vm.prank(op1);
        vm.expectRevert(SponsorPaymaster.NotOwner.selector);
        pm.setSponsored(_acct(2), true);
    }

    function test_TheBudgetRefusesTheNPlusFirstAccount() public {
        vm.prank(op1);
        gate.sponsor(_acct(1));
        vm.prank(op2); // replicas share one budget
        gate.sponsor(_acct(2));
        vm.prank(op1);
        gate.sponsor(_acct(3));
        assertEq(gate.remainingSponsorships(), 0);

        vm.prank(op2);
        vm.expectRevert(abi.encodeWithSelector(SponsorGate.SponsorBudgetExhausted.selector, 1, 0));
        gate.sponsor(_acct(4));
        assertFalse(pm.sponsored(_acct(4)));

        // The governor is not budgeted: it keeps the owner's power.
        vm.prank(gov);
        gate.setSponsored(_acct(4), true);
        assertTrue(pm.sponsored(_acct(4)));
    }

    function test_AlreadySponsoredAndUnsponsoringCostNothing() public {
        vm.startPrank(op1);
        gate.sponsor(_acct(1));
        gate.sponsor(_acct(1));
        gate.sponsor(_acct(1));
        assertEq(gate.remainingSponsorships(), BUDGET - 1);
        gate.unsponsor(_acct(1));
        assertFalse(pm.sponsored(_acct(1)));
        assertEq(gate.remainingSponsorships(), BUDGET - 1);
        // Adding it back is a new addition.
        gate.sponsor(_acct(1));
        assertEq(gate.remainingSponsorships(), BUDGET - 2);
        vm.stopPrank();
    }

    function test_ABatchIsChargedPerDistinctNewAccount() public {
        vm.prank(op1);
        gate.sponsor(_acct(1));
        address[] memory batch = new address[](4);
        (batch[0], batch[1], batch[2], batch[3]) = (_acct(1), _acct(2), _acct(2), _acct(3));
        vm.prank(op2);
        gate.sponsorBatch(batch);
        assertEq(gate.remainingSponsorships(), 0);
        assertTrue(pm.sponsored(_acct(2)) && pm.sponsored(_acct(3)));

        // All or nothing: a batch needing more than what is left changes nothing.
        vm.warp(block.timestamp + 1 days);
        address[] memory big = new address[](4);
        for (uint256 i; i < 4; ++i) big[i] = _acct(10 + i);
        vm.prank(op1);
        vm.expectRevert(abi.encodeWithSelector(SponsorGate.SponsorBudgetExhausted.selector, 4, 3));
        gate.sponsorBatch(big);
        assertFalse(pm.sponsored(_acct(10)));

        address[] memory tooMany = new address[](101);
        vm.prank(op1);
        vm.expectRevert(abi.encodeWithSelector(SponsorGate.BatchTooLarge.selector, 101, 100));
        gate.sponsorBatch(tooMany);
    }

    function test_TheBudgetRefillsWhenTheWindowCloses() public {
        vm.startPrank(op1);
        for (uint256 i; i < BUDGET; ++i) gate.sponsor(_acct(i));
        vm.expectRevert(abi.encodeWithSelector(SponsorGate.SponsorBudgetExhausted.selector, 1, 0));
        gate.sponsor(_acct(99));
        uint256 end = gate.windowEndsAt();
        vm.warp(end - 1);
        vm.expectRevert(abi.encodeWithSelector(SponsorGate.SponsorBudgetExhausted.selector, 1, 0));
        gate.sponsor(_acct(99));
        vm.warp(end);
        assertEq(gate.remainingSponsorships(), BUDGET);
        gate.sponsor(_acct(99));
        vm.stopPrank();
    }

    function test_OperatorsAreRefusedWhileThePaymasterBoundsNothing() public {
        vm.prank(gov);
        gate.setBudget(0, 0);
        vm.prank(op1);
        vm.expectRevert(SponsorGate.PaymasterUnbounded.selector);
        gate.sponsor(_acct(1));
        vm.prank(gov);
        gate.setBudget(1 days, 0.5 ether);
        vm.prank(gov);
        gate.setMaxCostAllowed(0);
        address[] memory one = new address[](1);
        one[0] = _acct(1);
        vm.prank(op1);
        vm.expectRevert(SponsorGate.PaymasterUnbounded.selector);
        gate.sponsorBatch(one);
    }

    function test_ZeroAddressesAreRefused() public {
        vm.startPrank(op1);
        vm.expectRevert(SponsorGate.ZeroAddress.selector);
        gate.sponsor(address(0));
        vm.expectRevert(SponsorGate.ZeroAddress.selector);
        gate.unsponsor(address(0));
        address[] memory batch = new address[](2);
        batch[0] = _acct(1);
        vm.expectRevert(SponsorGate.ZeroAddress.selector);
        gate.sponsorBatch(batch);
        vm.stopPrank();
    }

    /*//////////////////////////////////////////////////////////////
                  NOTHING BUT SPONSORSHIP REACHES AN OPERATOR
    //////////////////////////////////////////////////////////////*/

    function test_AnOperatorReachesNoOwnerPower() public {
        address[] memory batch = new address[](1);
        batch[0] = _acct(1);
        bytes[] memory calls = new bytes[](16);
        calls[0] = abi.encodeCall(SponsorGate.withdrawTo, (payable(op1), 1 ether));
        calls[1] = abi.encodeCall(SponsorGate.withdrawStake, (payable(op1)));
        calls[2] = abi.encodeCall(SponsorGate.unlockStake, ());
        calls[3] = abi.encodeCall(SponsorGate.addStake, (1));
        calls[4] = abi.encodeCall(SponsorGate.setMaxCostAllowed, (100 ether));
        calls[5] = abi.encodeCall(SponsorGate.setBudget, (0, 0));
        calls[6] = abi.encodeCall(SponsorGate.setAccountBudget, (_acct(1), 100 ether));
        calls[7] = abi.encodeCall(SponsorGate.resetSpend, (_acct(1)));
        calls[8] = abi.encodeCall(SponsorGate.transferPaymasterOwnership, (op1));
        calls[9] = abi.encodeCall(SponsorGate.setSponsored, (_acct(1), true));
        calls[10] = abi.encodeCall(SponsorGate.setSponsoredBatch, (batch, true));
        calls[11] = abi.encodeCall(SponsorGate.setOperator, (stranger, true));
        calls[12] = abi.encodeCall(SponsorGate.setMaxSponsorsPerWindow, (1000));
        calls[13] = abi.encodeCall(SponsorGate.setGuardian, (op1));
        calls[14] = abi.encodeCall(SponsorGate.transferGovernor, (op1));
        calls[15] = abi.encodeCall(SponsorGate.setOperator, (op2, false));
        uint256 depositBefore = pm.getDeposit();
        for (uint256 i; i < calls.length; ++i) {
            vm.prank(op1);
            (bool ok, bytes memory ret) = address(gate).call(calls[i]);
            assertFalse(ok, "an operator reached an owner or governance power");
            assertEq(bytes4(ret), SponsorGate.NotGovernor.selector);
        }
        // And straight at the paymaster: not its owner.
        vm.prank(op1);
        vm.expectRevert(SponsorPaymaster.NotOwner.selector);
        pm.withdrawTo(payable(op1), 1 ether);
        assertEq(pm.getDeposit(), depositBefore);
        assertEq(pm.owner(), address(gate));
        assertEq(pm.maxCostAllowed(), 0.05 ether);
        vm.prank(op1);
        vm.expectRevert(SponsorGate.NotPendingGovernor.selector);
        gate.acceptGovernor();
    }

    function test_TheGovernorKeepsEveryOwnerPower() public {
        vm.startPrank(gov);
        gate.setSponsored(_acct(1), true);
        address[] memory batch = new address[](2);
        (batch[0], batch[1]) = (_acct(2), _acct(3));
        gate.setSponsoredBatch(batch, true);
        assertTrue(pm.sponsored(_acct(1)) && pm.sponsored(_acct(2)) && pm.sponsored(_acct(3)));
        gate.setMaxCostAllowed(0.2 ether);
        assertEq(pm.maxCostAllowed(), 0.2 ether);
        gate.setBudget(2 days, 1 ether);
        assertEq(pm.budgetWindow(), 2 days);
        assertEq(pm.defaultBudget(), 1 ether);
        gate.setAccountBudget(_acct(1), 3 ether);
        assertEq(pm.budgetOf(_acct(1)), 3 ether);
        gate.resetSpend(_acct(1));

        gate.withdrawTo(treasury, 4 ether);
        assertEq(treasury.balance, 4 ether);
        assertEq(pm.getDeposit(), 6 ether);
        gate.addStake{value: 2 ether}(86_400);
        assertEq(ep.stake(), 2 ether);
        gate.unlockStake();
        gate.withdrawStake(treasury);

        gate.transferPaymasterOwnership(stranger);
        assertEq(pm.owner(), stranger);
        vm.stopPrank();
        // Once the paymaster is gone, the gate's operators reach nothing.
        vm.prank(op1);
        vm.expectRevert(SponsorPaymaster.NotOwner.selector);
        gate.sponsor(_acct(9));
    }

    /*//////////////////////////////////////////////////////////////
                               GOVERNANCE
    //////////////////////////////////////////////////////////////*/

    function test_ARevokedOperatorIsRefused() public {
        vm.prank(gov);
        gate.setOperator(op1, false);
        vm.prank(op1);
        vm.expectRevert(SponsorGate.NotOperator.selector);
        gate.sponsor(_acct(1));
        vm.prank(op1);
        vm.expectRevert(SponsorGate.NotOperator.selector);
        gate.unsponsor(_acct(1));
        vm.prank(op2);
        gate.sponsor(_acct(1)); // the other replica is untouched
    }

    function test_TheGuardianBrakesButCannotAccelerate() public {
        vm.prank(guardian);
        gate.setOperator(op1, false);
        assertFalse(gate.isOperator(op1));
        vm.prank(guardian);
        vm.expectRevert(SponsorGate.NotGovernor.selector);
        gate.setOperator(op1, true);

        vm.prank(guardian);
        gate.setMaxSponsorsPerWindow(1);
        assertEq(gate.maxSponsorsPerWindow(), 1);
        vm.prank(guardian);
        vm.expectRevert(SponsorGate.NotGovernor.selector);
        gate.setMaxSponsorsPerWindow(2);
        vm.prank(guardian);
        gate.setMaxSponsorsPerWindow(0); // stop all operator sponsorship
        vm.prank(op2);
        vm.expectRevert(abi.encodeWithSelector(SponsorGate.SponsorBudgetExhausted.selector, 1, 0));
        gate.sponsor(_acct(1));

        vm.prank(guardian);
        vm.expectRevert(SponsorGate.NotGovernor.selector);
        gate.withdrawTo(payable(guardian), 1);

        // Without a guardian, the zero address brakes nothing: only the governor acts.
        vm.prank(gov);
        gate.setGuardian(address(0));
        vm.prank(guardian);
        vm.expectRevert(SponsorGate.NotGovernor.selector);
        gate.setOperator(op2, false);
    }

    function test_TheBudgetIsCapped() public {
        vm.prank(gov);
        vm.expectRevert(abi.encodeWithSelector(SponsorGate.BudgetTooLarge.selector, 100_001, 100_000));
        gate.setMaxSponsorsPerWindow(100_001);
        vm.expectRevert(abi.encodeWithSelector(SponsorGate.BudgetTooLarge.selector, 100_001, 100_000));
        new SponsorGate(ISponsorPaymaster(address(pm)), gov, guardian, 100_001);
        vm.expectRevert(SponsorGate.ZeroAddress.selector);
        new SponsorGate(ISponsorPaymaster(address(0)), gov, guardian, 1);
        vm.expectRevert(SponsorGate.ZeroAddress.selector);
        new SponsorGate(ISponsorPaymaster(address(pm)), address(0), guardian, 1);
    }

    function test_GovernanceChangesHandsInTwoSteps() public {
        address next = makeAddr("next-multisig");
        vm.prank(gov);
        gate.transferGovernor(next);
        assertEq(gate.governor(), gov, "nothing changes until the new governor accepts");
        vm.prank(stranger);
        vm.expectRevert(SponsorGate.NotPendingGovernor.selector);
        gate.acceptGovernor();
        vm.prank(next);
        gate.acceptGovernor();
        assertEq(gate.governor(), next);
        assertEq(gate.pendingGovernor(), address(0));
        vm.prank(gov);
        vm.expectRevert(SponsorGate.NotGovernor.selector);
        gate.withdrawTo(payable(gov), 1);
        vm.prank(next);
        vm.expectRevert(SponsorGate.ZeroAddress.selector);
        gate.transferGovernor(address(0));
    }

    /*//////////////////////////////////////////////////////////////
                                  FUZZ
    //////////////////////////////////////////////////////////////*/

    /// However operators split their additions into single calls and batches, a window never admits more than the budget.
    function testFuzz_AWindowNeverAdmitsMoreThanTheBudget(uint32 budget, uint256 seed) public {
        budget = uint32(bound(budget, 0, 40));
        vm.prank(gov);
        gate.setMaxSponsorsPerWindow(budget);
        uint256 added;
        for (uint256 step; step < 30; ++step) {
            uint256 r = uint256(keccak256(abi.encode(seed, step)));
            address who = r % 2 == 0 ? op1 : op2;
            if (r % 3 == 0) {
                address[] memory batch = new address[](1 + (r >> 8) % 5);
                for (uint256 i; i < batch.length; ++i) batch[i] = _acct((r >> (16 + i * 8)) % 64);
                uint256 before = gate.remainingSponsorships();
                vm.prank(who);
                try gate.sponsorBatch(batch) {
                    added += before - gate.remainingSponsorships();
                } catch {}
            } else {
                uint256 before = gate.remainingSponsorships();
                vm.prank(who);
                try gate.sponsor(_acct(r % 64)) {
                    added += before - gate.remainingSponsorships();
                } catch {}
            }
            assertLe(added, budget);
        }
        uint256 sponsoredCount;
        for (uint256 i; i < 64; ++i) {
            if (pm.sponsored(_acct(i))) ++sponsoredCount;
        }
        assertEq(sponsoredCount, added, "every sponsored account was charged exactly once");
    }
}

/*//////////////////////////////////////////////////////////////
                              INVARIANTS
//////////////////////////////////////////////////////////////*/

/**
 * Drives the gate as a long stretch of operation would: two operators (one of them leaked) sponsoring,
 * batching and unsponsoring, time passing, the governor and guardian revoking, re-adding and moving the
 * budget both ways, and the governor forwarding owner calls. Ghost counters record what must never happen.
 */
contract SponsorGateHandler is Test {
    SponsorGate gate;
    SponsorPaymaster pm;
    address gov;
    address guardian;
    address[2] ops;
    address[] accounts;

    /// Additions by operators in the gate's current window, and the highest budget in force during it.
    uint256 public ghostAddedInWindow;
    uint256 public ghostMaxBudgetInWindow;
    uint256 public revokedSuccesses;
    uint256 public ownerPowerReached;
    uint256 public ghostDeposit;

    constructor(SponsorGate g, SponsorPaymaster p, address gov_, address guardian_, address[2] memory ops_) {
        (gate, pm, gov, guardian, ops) = (g, p, gov_, guardian_, ops_);
        for (uint256 i; i < 24; ++i) accounts.push(address(uint160(0xBEEF00 + i)));
        ghostMaxBudgetInWindow = g.maxSponsorsPerWindow();
        ghostDeposit = p.getDeposit();
    }

    /// The gate opens a new window only inside `_consume`; the ghost follows its `windowStart` exactly.
    function _follow(uint256 windowOpen, uint256 fresh) internal {
        if (gate.windowStart() != windowOpen) {
            ghostAddedInWindow = 0;
            ghostMaxBudgetInWindow = gate.maxSponsorsPerWindow();
        }
        ghostAddedInWindow += fresh;
    }

    function _countNew(address[] memory list) internal view returns (uint256 n) {
        for (uint256 i; i < list.length; ++i) {
            bool dup;
            for (uint256 j; j < i; ++j) {
                if (list[j] == list[i]) dup = true;
            }
            if (!dup && !pm.sponsored(list[i])) ++n;
        }
    }

    function sponsor(uint256 opSeed, uint256 accountSeed) external {
        address op = ops[opSeed % 2];
        address account = accounts[accountSeed % accounts.length];
        bool allowed = gate.isOperator(op);
        bool fresh = !pm.sponsored(account);
        uint256 windowOpen = gate.windowStart();
        vm.prank(op);
        try gate.sponsor(account) {
            if (!allowed) ++revokedSuccesses;
            if (fresh) _follow(windowOpen, 1);
        } catch {}
    }

    function sponsorBatch(uint256 opSeed, uint256 seed, uint8 size) external {
        address op = ops[opSeed % 2];
        address[] memory list = new address[](bound(size, 1, 6));
        for (uint256 i; i < list.length; ++i) list[i] = accounts[uint256(keccak256(abi.encode(seed, i))) % accounts.length];
        bool allowed = gate.isOperator(op);
        uint256 fresh = _countNew(list);
        uint256 windowOpen = gate.windowStart();
        vm.prank(op);
        try gate.sponsorBatch(list) {
            if (!allowed) ++revokedSuccesses;
            if (fresh > 0) _follow(windowOpen, fresh);
        } catch {}
    }

    function unsponsor(uint256 opSeed, uint256 accountSeed) external {
        address op = ops[opSeed % 2];
        bool allowed = gate.isOperator(op);
        vm.prank(op);
        try gate.unsponsor(accounts[accountSeed % accounts.length]) {
            if (!allowed) ++revokedSuccesses;
        } catch {}
    }

    /// A leaked operator tries every owner power.
    function operatorReachesForOwnerPowers(uint256 opSeed, uint256 which) external {
        address op = ops[opSeed % 2];
        bytes memory call;
        uint256 w = which % 6;
        if (w == 0) call = abi.encodeCall(SponsorGate.withdrawTo, (payable(op), 1));
        else if (w == 1) call = abi.encodeCall(SponsorGate.setMaxCostAllowed, (type(uint256).max));
        else if (w == 2) call = abi.encodeCall(SponsorGate.setBudget, (1, type(uint256).max));
        else if (w == 3) call = abi.encodeCall(SponsorGate.transferPaymasterOwnership, (op));
        else if (w == 4) call = abi.encodeCall(SponsorGate.setMaxSponsorsPerWindow, (type(uint32).max));
        else call = abi.encodeCall(SponsorGate.setOperator, (op, true));
        vm.prank(op);
        (bool ok,) = address(gate).call(call);
        if (ok) ++ownerPowerReached;
        vm.prank(op);
        try pm.withdrawTo(payable(op), 1) {
            ++ownerPowerReached;
        } catch {}
    }

    function setOperator(uint256 opSeed, bool allowed, bool byGuardian) external {
        vm.prank(byGuardian ? guardian : gov);
        try gate.setOperator(ops[opSeed % 2], allowed) {} catch {}
    }

    function setBudget(uint32 count, bool byGuardian) external {
        count = uint32(bound(count, 0, 12));
        vm.prank(byGuardian ? guardian : gov);
        try gate.setMaxSponsorsPerWindow(count) {
            // A raise counts toward the open window; an expired one is replaced at the next addition.
            if (block.timestamp < uint256(gate.windowStart()) + gate.WINDOW() && count > ghostMaxBudgetInWindow) {
                ghostMaxBudgetInWindow = count;
            }
        } catch {}
    }

    function governorWithdraws(uint256 amount) external {
        amount = bound(amount, 0, 0.01 ether);
        vm.prank(gov);
        gate.withdrawTo(payable(gov), amount);
        ghostDeposit -= amount;
    }

    function warp(uint256 dt) external {
        vm.warp(block.timestamp + bound(dt, 1, 30 hours));
    }
}

contract SponsorGateInvariantTest is Test {
    SponsorGate gate;
    SponsorPaymaster pm;
    SponsorGateHandler handler;
    address gov = makeAddr("gov");

    function setUp() public {
        MockEntryPoint ep = new MockEntryPoint();
        pm = new SponsorPaymaster(IEntryPoint(address(ep)), gov);
        address guardian = makeAddr("guardian");
        gate = new SponsorGate(ISponsorPaymaster(address(pm)), gov, guardian, 5);
        address[2] memory ops = [makeAddr("op-a"), makeAddr("op-b-leaked")];
        vm.deal(gov, 10 ether);
        vm.startPrank(gov);
        pm.deposit{value: 5 ether}();
        pm.transferOwnership(address(gate));
        gate.setBudget(1 days, 0.5 ether);
        gate.setMaxCostAllowed(0.05 ether);
        gate.setOperator(ops[0], true);
        gate.setOperator(ops[1], true);
        vm.stopPrank();
        handler = new SponsorGateHandler(gate, pm, gov, guardian, ops);
        targetContract(address(handler));
    }

    function invariant_AWindowNeverAdmitsMoreThanItsBudget() public view {
        assertLe(handler.ghostAddedInWindow(), handler.ghostMaxBudgetInWindow());
        assertEq(gate.windowUsed(), handler.ghostAddedInWindow(), "the gate charged exactly the new accounts");
    }

    function invariant_ARevokedOperatorNeverSucceeds() public view {
        assertEq(handler.revokedSuccesses(), 0);
    }

    function invariant_OperatorsNeverReachAnOwnerPower() public view {
        assertEq(handler.ownerPowerReached(), 0);
        assertEq(pm.owner(), address(gate));
        assertEq(gate.governor(), gov);
        assertEq(pm.maxCostAllowed(), 0.05 ether);
        assertEq(pm.budgetWindow(), 1 days);
        assertEq(pm.defaultBudget(), 0.5 ether);
        assertEq(pm.getDeposit(), handler.ghostDeposit(), "only the governor's withdrawals moved the deposit");
    }
}
