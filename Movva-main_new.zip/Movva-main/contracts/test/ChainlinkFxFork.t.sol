// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import {IAggregatorV3} from "../ramp/ChainlinkBrlOracle.sol";
import {ChainlinkFxOracle} from "../ramp/ChainlinkFxOracle.sol";
import {MovvaReserve} from "../movva/MovvaReserve.sol";
import {FxMarketHours} from "../common/FxMarketHours.sol";

interface IChainlinkProxy is IAggregatorV3 {
    function description() external view returns (string memory);
    function aggregator() external view returns (address);
    function getRoundData(uint80 roundId)
        external
        view
        returns (uint80, int256 answer, uint256 startedAt, uint256 updatedAt, uint80 answeredInRound);
}

/**
 * ChainlinkFxOracle and the reserve against the REAL Chainlink BRL/USD feed on Ethereum mainnet.
 *
 * The repository concluded in September 2026 that no Chainlink BRL/USD was usable on L1, from the proxy
 * the Feed Registry still returns (OracleFork.t.sol). That proxy is retired. The live one, in Chainlink's
 * own feed list on 19 October 2026, is 0x3126...7Df1, and this suite reads it from a contract.
 *
 * Forks the latest block (the public RPC serves no archive state), so it asserts what holds at any hour:
 * the band at the fork's time, and the rate at a moment of the answer's own validity window chosen inside
 * and outside the core session with `vm.warp`.
 *
 * Skips without MAINNET_FORK_RPC (or FORK_RPC, as the other fork suites and CI's fork job set it):
 *
 *   MAINNET_FORK_RPC=https://ethereum-rpc.publicnode.com forge test --match-contract ChainlinkFxFork -vv
 */
contract ChainlinkFxForkTest is Test {
    /// Chainlink BRL/USD, Ethereum mainnet: the live proxy and, behind it on 19 October 2026, its aggregator.
    address constant BRL_USD = 0x3126E7F38D5f60f4E2B6ec3511C7bdbD79317Df1;
    address constant BRL_USD_AGGREGATOR = 0x3A9763662BFCa861340d1D40bA5e5A2a29Bc5f3e;
    /// The retired proxy the September finding was about, and its last round's time (25 August 2023).
    address constant RETIRED_BRL_USD = 0x0eBDc65E7e9132Cb41ac5cbD0101B799D7aDb475;
    uint256 constant RETIRED_LAST_UPDATE = 1_692_977_915;
    /// Real USDT and Chainlink USDT/USD, for the reserve end to end.
    address constant USDT = 0xdAC17F958D2ee523a2206206994597C13D831ec7;
    address constant USDT_USD = 0x3E7d1eAB13ad0104d2750B8863b489D65364e32D;

    uint64 constant MAX_AGE = 26 hours;
    uint64 constant CLOSED_MAX_AGE = 4 days;

    bool forked;

    function setUp() public {
        string memory rpc = vm.envOr("MAINNET_FORK_RPC", vm.envOr("FORK_RPC", string("")));
        if (bytes(rpc).length == 0) return;
        vm.createSelectFork(rpc);
        forked = true;
    }

    function _oracle() internal returns (ChainlinkFxOracle) {
        return new ChainlinkFxOracle(BRL_USD, MAX_AGE, CLOSED_MAX_AGE, 1e6, 100e6);
    }

    function test_TheLiveProxyIsBrlUsdAtEightDecimals() public {
        if (!forked) return;
        IChainlinkProxy p = IChainlinkProxy(BRL_USD);
        assertEq(p.description(), "BRL / USD");
        assertEq(p.decimals(), 8);
        // Informational: Chainlink may upgrade the aggregator behind the proxy; that is the point of a proxy.
        if (p.aggregator() != BRL_USD_AGGREGATOR) emit log_named_address("aggregator changed to", p.aggregator());
    }

    /// A CONTRACT reads it - the thing the retired proxy refuses - and the answer is a plausible real.
    function test_AContractReadsTheLiveFeedAndTheBandPrices() public {
        if (!forked) return;
        ChainlinkFxOracle o = _oracle();
        (, int256 answer,, uint256 at,) = IAggregatorV3(BRL_USD).latestRoundData();
        emit log_named_int("answer, US$ per real x 1e8", answer);
        emit log_named_uint("updatedAt", at);
        emit log_named_uint("age at the fork, seconds", block.timestamp - at);
        assertGt(answer, 0);
        assertLe(block.timestamp - at, MAX_AGE, "the live feed keeps its heartbeat");

        (uint256 band, uint64 stamped) = o.brlCentsPerUnitForBand();
        assertEq(band, 1e14 / uint256(answer), "the reciprocal, floored");
        assertEq(stamped, block.timestamp);
        // Between R$ 3 and R$ 10 per dollar: wide, but it would catch an inversion or a unit slip.
        assertGt(band, 3e6);
        assertLt(band, 10e6);
        emit log_named_uint("brlPerUsdE6", band);
        emit log_named_string("core session at the fork", FxMarketHours.inCoreSession(block.timestamp) ? "yes" : "no");
    }

    /// The rate inside and outside the core session, at moments within the real answer's validity window.
    function test_TheRateFollowsTheCoreSessionOnTheRealAnswer() public {
        if (!forked) return;
        ChainlinkFxOracle o = _oracle();
        (, int256 answer,, uint256 at,) = IAggregatorV3(BRL_USD).latestRoundData();
        uint256 expected = 1e14 / uint256(answer);
        (uint256 inside, bool foundInside) = _firstMoment(at, at + MAX_AGE, true);
        (uint256 outside, bool foundOutside) = _firstMoment(at, at + MAX_AGE, false);
        // 26 hours always hold both a core-session minute and a closed one, except across a weekend or
        // a holiday, where only the closed one is guaranteed.
        assertTrue(foundOutside, "a 26-hour window always holds a closed hour");
        if (foundInside) {
            vm.warp(inside);
            (uint256 rate, uint64 rateAt) = o.brlCentsPerUnit();
            assertEq(rate, expected);
            assertEq(rateAt, at, "the round's own time");
        }
        vm.warp(outside);
        vm.expectRevert(abi.encodeWithSelector(ChainlinkFxOracle.MarketClosed.selector, outside));
        o.brlCentsPerUnit();
        (uint256 band,) = o.brlCentsPerUnitForBand();
        assertEq(band, expected, "the band keeps trading on the same answer");
        vm.warp(at + MAX_AGE + 1);
        if (FxMarketHours.inCoreSession(block.timestamp)) {
            vm.expectRevert(abi.encodeWithSelector(ChainlinkFxOracle.StaleAnswer.selector, at));
            o.brlCentsPerUnit();
        }
    }

    /// The heartbeat MIN_MAX_AGE is built on: the last ten intervals between rounds, read back from the proxy.
    function test_TheRealHeartbeatIsADayAndFitsMaxAge() public {
        if (!forked) return;
        IChainlinkProxy p = IChainlinkProxy(BRL_USD);
        (uint80 id,,, uint256 at,) = p.latestRoundData();
        uint256 longest;
        for (uint256 i; i < 10; i++) {
            (,,, uint256 before,) = p.getRoundData(id - uint80(i) - 1);
            uint256 gap = at - before;
            if (gap > longest) longest = gap;
            at = before;
        }
        emit log_named_uint("longest of the last ten intervals, seconds", longest);
        assertLe(longest, 25 hours, "inside MIN_MAX_AGE, so MAX_AGE = 26 h has an hour and more to spare");
        assertGe(longest, 23 hours, "a quiet market posts on the heartbeat, about a day apart");
    }

    /// The September finding was about a retired proxy: an EOA still reads its last round, from August
    /// 2023; a contract gets "No access". The new oracle cannot be pointed at it.
    function test_TheRetiredProxyIsStaleAndRefusesContracts() public {
        if (!forked) return;
        address eoa = makeAddr("an EOA");
        vm.prank(eoa, eoa);
        (,,, uint256 at,) = IAggregatorV3(RETIRED_BRL_USD).latestRoundData();
        assertEq(at, RETIRED_LAST_UPDATE, "last updated 25 August 2023");
        vm.expectRevert(bytes("No access"));
        IAggregatorV3(RETIRED_BRL_USD).latestRoundData();
        vm.expectRevert();
        new ChainlinkFxOracle(RETIRED_BRL_USD, MAX_AGE, CLOSED_MAX_AGE, 1e6, 100e6);
    }

    /// The reserve, unchanged, on real USDT, real USDT/USD and the real BRL/USD through ChainlinkFxOracle.
    function test_TheReserveAcceptsTheLegEndToEnd() public {
        if (!forked) return;
        ChainlinkFxOracle o = _oracle();
        MovvaReserve reserve = new MovvaReserve(
            MovvaReserve.Config({
                usdt: USDT,
                usdtUsdFeed: USDT_USD,
                fxOracle: address(o),
                usdtUsdMaxAge: 25 hours,
                fxMaxAge: MAX_AGE,
                governor: address(this),
                governanceDelay: 48 hours,
                guardian: makeAddr("guardian"),
                feeRecipient: makeAddr("fees"),
                yieldRecipient: makeAddr("yield recipient"),
                supplyCap: 1_000_000e18,
                breaker: address(0)
            })
        );
        (uint256 band, uint64 bandAt) = reserve.bandBrlPerUsdtE18();
        assertGt(band, 3e18);
        assertLt(band, 10e18);
        assertEq(bandAt, block.timestamp);
        (uint256 cents,) = reserve.brlCentsPerUnit();
        assertEq(cents, 100, "nothing minted: Movva's band is par");
        emit log_named_uint("reserve band rate, reais per USDT x 1e18", band);
        if (FxMarketHours.inCoreSession(block.timestamp)) {
            (uint256 rate,) = reserve.brlPerUsdtE18();
            assertEq(rate, band, "inside the session the rate and the band agree");
        } else {
            vm.expectRevert(abi.encodeWithSelector(ChainlinkFxOracle.MarketClosed.selector, block.timestamp));
            reserve.brlPerUsdtE18();
        }
    }

    /// The first whole minute in [from, to] that is (or is not) inside the core session.
    function _firstMoment(uint256 from, uint256 to, bool core) internal pure returns (uint256, bool) {
        for (uint256 t = from - (from % 1 minutes) + 1 minutes; t <= to; t += 1 minutes) {
            if (FxMarketHours.inCoreSession(t) == core) return (t, true);
        }
        return (0, false);
    }
}
