// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Governed} from "./utils/Governed.sol";
import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {ERC4626} from "@openzeppelin/contracts/token/ERC20/extensions/ERC4626.sol";
import {YieldVault} from "../yield/YieldVault.sol";
import {
    SuperstateUSTBAdapter,
    IUSTB,
    IUSTBRedemption,
    ISuperstateNavOracle
} from "../yield/adapters/SuperstateUSTBAdapter.sol";

contract MockUSDC is ERC20 {
    constructor() ERC20("USD Coin", "USDC") {}

    function decimals() public pure override returns (uint8) {
        return 6;
    }

    function mint(address to, uint256 v) external {
        _mint(to, v);
    }

    function burn(address from, uint256 v) external {
        _burn(from, v);
    }
}

/// SuperstateOracle's shape: an extrapolated answer and the checkpoint behind it.
contract MockNavOracle is ISuperstateNavOracle {
    uint256 public answer = 11_200_000; // $11.20
    uint64 public effectiveAt;
    bool public reverts;

    constructor() {
        effectiveAt = uint64(block.timestamp);
    }

    function set(uint256 a, uint64 eff) external {
        answer = a;
        effectiveAt = eff;
    }

    function setReverts(bool r) external {
        reverts = r;
    }

    function decimals() external pure returns (uint8) {
        return 6;
    }

    function latestRoundData() external view returns (uint80, int256, uint256, uint256, uint80) {
        // The real oracle reverts StaleCheckpoint five days after the checkpoint took effect.
        require(!reverts, "StaleCheckpoint");
        return (7, int256(answer), block.timestamp, block.timestamp, 7);
    }

    function checkpoints(uint256 i) external view returns (uint64, uint64, uint128) {
        require(i == 7, "index");
        return (effectiveAt - 20 hours, effectiveAt, uint128(answer));
    }
}

/// USTB's subscription and transfer rules, including its allowlist on mint and transferFrom.
contract MockUSTB is ERC20, IUSTB {
    MockUSDC public immutable usdc;
    address public sweep = address(0x5EE9);
    uint96 public fee;
    address public superstateOracle;
    uint256 public maximumOracleDelay = 3600;
    bool public paused;
    bool public isAccountingPaused;
    bool public viewsRevert;
    /// Mint this many bps fewer tokens than the price says: a wrong subscription oracle.
    uint256 public shortMintBps;
    mapping(address => bool) public allowed;

    constructor(MockUSDC usdc_, address oracle_) ERC20("USTB", "USTB") {
        usdc = usdc_;
        superstateOracle = oracle_;
    }

    function decimals() public pure override returns (uint8) {
        return 6;
    }

    function setAllowed(address a, bool v) external {
        allowed[a] = v;
    }

    function setPaused(bool p, bool acct) external {
        paused = p;
        isAccountingPaused = acct;
    }

    function setOracle(address o) external {
        superstateOracle = o;
    }

    function setFee(uint96 f) external {
        fee = f;
    }

    function setShortMint(uint256 bps) external {
        shortMintBps = bps;
    }

    function setViewsRevert(bool r) external {
        viewsRevert = r;
    }

    function isAllowed(address addr) external view returns (bool) {
        require(!viewsRevert, "broken");
        return allowed[addr];
    }

    function supportedStablecoins(address s) external view returns (address, uint96) {
        return s == address(usdc) ? (sweep, fee) : (address(0), uint96(0));
    }

    function subscribe(uint256 inAmount, address stablecoin) external {
        require(!paused && !isAccountingPaused, "paused");
        require(superstateOracle != address(0), "OnchainSubscriptionsDisabled");
        require(stablecoin == address(usdc), "StablecoinNotSupported");
        require(allowed[msg.sender], "InsufficientPermissions");
        (, int256 price,,,) = ISuperstateNavOracle(superstateOracle).latestRoundData();
        uint256 afterFee = inAmount - (inAmount * fee) / 10_000;
        uint256 out = (afterFee * 1e6 * 1e6) / (uint256(price) * 1e6);
        out -= (out * shortMintBps) / 10_000;
        require(usdc.transferFrom(msg.sender, sweep, inAmount), "pay");
        _mint(msg.sender, out);
    }

    function transferFrom(address src, address dst, uint256 amount) public override returns (bool) {
        require(allowed[src] && allowed[dst], "InsufficientPermissions");
        require(!paused, "paused");
        return super.transferFrom(src, dst, amount);
    }

    function burn(uint256 amount) external {
        require(!isAccountingPaused, "AccountingIsPaused");
        _burn(msg.sender, amount);
    }
}

/// RedemptionIdle: instant USDC from its own balance, at its immutable feed's price.
contract MockRedemption is IUSTBRedemption {
    MockUSTB public immutable ustb;
    MockUSDC public immutable usdc;
    MockNavOracle public immutable feed;
    uint256 public redemptionFee;
    bool public paused;
    bool public failNext;

    error InsufficientBalance();

    constructor(MockUSTB ustb_, MockUSDC usdc_, MockNavOracle feed_) {
        ustb = ustb_;
        usdc = usdc_;
        feed = feed_;
    }

    function SUPERSTATE_TOKEN() external view returns (address) {
        return address(ustb);
    }

    function USDC() external view returns (address) {
        return address(usdc);
    }

    function CHAINLINK_FEED_ADDRESS() external view returns (address) {
        return address(feed);
    }

    function MINIMUM_ACCEPTABLE_PRICE() external pure returns (uint256) {
        return 7_000_000;
    }

    function setFee(uint256 f) external {
        redemptionFee = f;
    }

    function setPaused(bool p) external {
        paused = p;
    }

    /// The issuer drains the facility between the adapter's checks and its redeem call.
    function setFailNext(bool f) external {
        failNext = f;
    }

    function _price() internal view returns (uint256) {
        (, int256 p,,,) = feed.latestRoundData();
        return uint256(p);
    }

    function maxUstbRedemptionAmount() external view returns (uint256, uint256) {
        uint256 before = (usdc.balanceOf(address(this)) * 10_000) / (10_000 - redemptionFee);
        uint256 p = _price();
        return ((before * 1e6) / p, p);
    }

    function calculateUstbIn(uint256 usdcOut) external view returns (uint256, uint256) {
        uint256 before = (usdcOut * 10_000) / (10_000 - redemptionFee);
        uint256 p = _price();
        return ((before * 1e6 + p - 1) / p, p);
    }

    function redeem(address to, uint256 amount) external {
        require(!paused, "EnforcedPause");
        if (failNext) revert InsufficientBalance();
        uint256 gross = (amount * _price()) / 1e6;
        uint256 out = gross - (gross * redemptionFee) / 10_000;
        if (usdc.balanceOf(address(this)) < out) revert InsufficientBalance();
        require(ustb.transferFrom(msg.sender, address(this), amount), "pull");
        require(usdc.transfer(to, out), "pay");
        ustb.burn(amount);
    }
}

/**
 * The USTB adapter against doubles that follow the issuer's contracts' rules. The fork test
 * (`SuperstateUSTBFork.t.sol`) runs the same flows against the real contracts; these cover the
 * states mainnet will not produce on demand: a stale or bad NAV, an empty facility, a revoked
 * allowlist entry, a swapped subscription oracle.
 */
contract SuperstateUSTBAdapterTest is Governed {
    MockUSDC usdc;
    MockNavOracle feed;
    MockUSTB ustb;
    MockRedemption redemption;
    YieldVault vault;
    SuperstateUSTBAdapter adapter;

    address gov = makeAddr("gov");
    address keeper = makeAddr("keeper");
    address alice = makeAddr("alice");
    address mallory = makeAddr("mallory");

    uint256 constant MAX_NAV_AGE = 4 days;
    uint16 constant MAX_GROWTH_BPS = 1_000; // 10% a year
    uint16 constant STALE_HAIRCUT_BPS = 100;
    uint16 constant MAX_ENTRY_COST_BPS = 25;

    function setUp() public {
        vm.warp(1_789_000_000);
        usdc = new MockUSDC();
        feed = new MockNavOracle();
        ustb = new MockUSTB(usdc, address(feed));
        redemption = new MockRedemption(ustb, usdc, feed);
        ustb.setAllowed(address(redemption), true);
        usdc.mint(address(redemption), 5_000_000e6);

        vault = new YieldVault(IERC20(address(usdc)), "Shielded T-bills", "syUSDC", gov, gov, keeper, 1e18, 500, DELAY);
        adapter = new SuperstateUSTBAdapter(
            address(vault), ustb, redemption, MAX_NAV_AGE, MAX_GROWTH_BPS, STALE_HAIRCUT_BPS, MAX_ENTRY_COST_BPS
        );
        vm.startPrank(gov);
        vault.addAdapter(adapter, 9_000);
        vault.completeSetup();
        vm.stopPrank();

        usdc.mint(alice, 1_000_000e6);
        usdc.mint(mallory, 1_000_000e6);
        vm.prank(alice);
        usdc.approve(address(vault), type(uint256).max);
        vm.prank(mallory);
        usdc.approve(address(vault), type(uint256).max);
    }

    function _allowlist() internal {
        ustb.setAllowed(address(adapter), true);
    }

    function _depositAndAllocate(uint256 amount, uint256 allocated) internal {
        vm.prank(alice);
        vault.deposit(amount, alice);
        vm.prank(keeper);
        vault.allocate(adapter, allocated);
    }

    /*//////////////////////////////////////////////////////////////
                              HAPPY PATH
    //////////////////////////////////////////////////////////////*/

    function test_SubscribesAndValuesAtTheIssuerNav() public {
        _allowlist();
        _depositAndAllocate(1_000_000e6, 900_000e6);
        assertEq(ustb.balanceOf(address(adapter)), uint256(900_000e6 * 1e6) / 11_200_000, "minted at NAV");
        assertApproxEqAbs(adapter.totalValue(), 900_000e6, 1e6, "worth what went in");
        assertApproxEqAbs(vault.totalAssets(), 1_000_000e6, 1e6);
        assertEq(adapter.maxInstantWithdraw(), adapter.totalValue(), "fully redeemable while the facility is funded");
    }

    function test_ARoundTripThroughTheFacilityReturnsPrincipalPlusNavGrowth() public {
        _allowlist();
        _depositAndAllocate(1_000_000e6, 900_000e6);
        vm.warp(block.timestamp + 1 days);
        feed.set(11_201_200, uint64(block.timestamp)); // one day of ~3.9% a year
        uint256 shares = vault.balanceOf(alice);
        vm.prank(alice);
        uint256 out = vault.redeem(shares, alice, alice);
        assertGt(out, 1_000_000e6, "the NAV growth came out");
        assertEq(ustb.balanceOf(address(adapter)), 0, "all USTB redeemed");
    }

    /*//////////////////////////////////////////////////////////////
                               ALLOWLIST
    //////////////////////////////////////////////////////////////*/

    /// Before the issuer onboards the vault: zero capacity, a reason, and no surprise reverts.
    function test_NotAllowlistedReportsZeroCapacityAndWhy() public {
        assertEq(adapter.maxDeposit(), 0);
        assertEq(adapter.depositBlocker(), "adapter is not on the USTB allowlist");
        vm.prank(alice);
        vault.deposit(100_000e6, alice);
        vm.prank(keeper);
        vm.expectRevert(
            abi.encodeWithSelector(SuperstateUSTBAdapter.DepositsBlocked.selector, "adapter is not on the USTB allowlist")
        );
        vault.allocate(adapter, 50_000e6);
        // The vault is otherwise fine: holders come and go.
        vm.prank(alice);
        vault.withdraw(100_000e6, alice, alice);
    }

    /**
     * The issuer removes the vault from its allowlist while it holds USTB. The USTB leg freezes;
     * nothing else does. Holders can take every idle dollar, `maxWithdraw` says exactly that,
     * and the adapter's withdraw returns what it can instead of reverting the vault.
     */
    function test_RevokedAllowlistFreezesOnlyTheUSTBLeg() public {
        _allowlist();
        _depositAndAllocate(1_000_000e6, 600_000e6);
        ustb.setAllowed(address(adapter), false);

        assertEq(adapter.maxInstantWithdraw(), 0, "USTB is not redeemable now");
        assertApproxEqAbs(adapter.totalValue(), 600_000e6, 1e6, "but it is still worth what it is worth");
        assertEq(vault.maxWithdraw(alice), 400_000e6, "maxWithdraw reports what can actually leave");

        vm.prank(alice);
        vault.withdraw(400_000e6, alice, alice);

        vm.prank(address(vault));
        assertEq(adapter.withdraw(1e6, alice), 0, "no revert, nothing sent");

        // Access restored: the frozen leg is redeemable again, with nothing lost.
        ustb.setAllowed(address(adapter), true);
        uint256 shares = vault.balanceOf(alice);
        vm.prank(alice);
        assertApproxEqAbs(vault.redeem(shares, alice, alice), 600_000e6, 1e6);
    }

    /*//////////////////////////////////////////////////////////////
                               LIQUIDITY
    //////////////////////////////////////////////////////////////*/

    function test_MaxWithdrawIsBoundedByTheFacilityNotTheFund() public {
        _allowlist();
        _depositAndAllocate(1_000_000e6, 900_000e6);
        vm.prank(address(0xdead));
        usdc.burn(address(redemption), usdc.balanceOf(address(redemption)) - 250_000e6);

        uint256 instant = adapter.maxInstantWithdraw();
        assertLe(instant, 250_000e6, "never more than the facility holds");
        assertApproxEqAbs(instant, 250_000e6, 30, "less only the rounding of whole USTB units");
        uint256 max = vault.maxWithdraw(alice);
        assertEq(max, 100_000e6 + instant, "idle + what the facility would actually pay");
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(ERC4626.ERC4626ExceededMaxWithdraw.selector, alice, 400_000e6, max));
        vault.withdraw(400_000e6, alice, alice);

        // Exactly what maxWithdraw promised must go through: the promise is the point.
        vm.prank(alice);
        vault.withdraw(max, alice, alice);
        assertEq(usdc.balanceOf(alice), max);
    }

    /// SR3-6 as a property: whatever the facility holds, the fee and the NAV, `maxWithdraw` can be withdrawn.
    function testFuzz_WhatMaxWithdrawPromisesCanBeWithdrawn(uint64 facility, uint32 allocated, uint16 fee, uint32 navUp)
        public
    {
        _allowlist();
        uint256 alloc = bound(uint256(allocated), 1e6, 900_000e6); // the adapter's 90% cap
        vm.prank(alice);
        vault.deposit(1_000_000e6, alice);
        vm.prank(keeper);
        vault.allocate(adapter, alloc);

        redemption.setFee(bound(uint256(fee), 0, 10));
        vm.warp(block.timestamp + 1 days);
        feed.set(11_200_000 + bound(uint256(navUp), 0, 5_000), uint64(block.timestamp));
        uint256 target = bound(uint256(facility), 0, 2_000_000e6);
        uint256 bal = usdc.balanceOf(address(redemption));
        if (target < bal) usdc.burn(address(redemption), bal - target);
        else usdc.mint(address(redemption), target - bal);

        uint256 max = vault.maxWithdraw(alice);
        vm.prank(alice);
        vault.withdraw(max, alice, alice);
        assertEq(usdc.balanceOf(alice), max);
    }

    function test_AnEmptyFacilityLeavesIdleExitsOpen() public {
        _allowlist();
        _depositAndAllocate(1_000_000e6, 900_000e6);
        vm.prank(address(0xdead));
        usdc.burn(address(redemption), usdc.balanceOf(address(redemption)));
        assertEq(adapter.maxInstantWithdraw(), 0);
        vm.prank(alice);
        vault.withdraw(100_000e6, alice, alice);
    }

    /// The facility empties between the adapter's check and its redeem call. The adapter must not
    /// revert, and the vault must not underpay: it reverts the withdrawal as a whole instead.
    function test_AFacilityThatFailsMidCallNeitherRevertsTheAdapterNorUnderpaysAHolder() public {
        _allowlist();
        _depositAndAllocate(1_000_000e6, 900_000e6);
        redemption.setFailNext(true);

        vm.prank(address(vault));
        vm.expectEmit(false, false, false, false, address(adapter));
        emit SuperstateUSTBAdapter.RedemptionUnavailable("");
        assertEq(adapter.withdraw(10_000e6, address(vault)), 0);

        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(YieldVault.InsufficientLiquidity.selector, 500_000e6, 100_000e6));
        vault.withdraw(500_000e6, alice, alice);
        assertEq(usdc.balanceOf(alice), 0);
    }

    /*//////////////////////////////////////////////////////////////
                                  NAV
    //////////////////////////////////////////////////////////////*/

    /// A NAV the issuer stopped publishing: haircut value, no new subscriptions, no instant exits.
    function test_AStaleNavIsHaircutAndStopsSubscriptionsAndInstantExits() public {
        _allowlist();
        _depositAndAllocate(1_000_000e6, 900_000e6);
        uint256 fresh = adapter.totalValue();

        vm.warp(block.timestamp + MAX_NAV_AGE + 1);
        (bool trusted,) = adapter.valuationNav();
        assertFalse(trusted);
        assertApproxEqRel(adapter.totalValue(), (fresh * 99) / 100, 1e14, "1% haircut");
        assertEq(adapter.maxInstantWithdraw(), 0);
        assertEq(adapter.maxDeposit(), 0);
        assertEq(adapter.depositBlocker(), "USTB NAV is stale, unreadable or below the issuer's floor");
    }

    /// Past the oracle's own expiry it reverts. The vault must still price, and holders still exit idle.
    function test_ARevertingOracleCannotFreezeTheVault() public {
        _allowlist();
        _depositAndAllocate(1_000_000e6, 900_000e6);
        feed.setReverts(true);
        uint256 total = vault.totalAssets();
        assertApproxEqRel(total, 100_000e6 + 891_000e6, 1e15, "idle + USTB at the last good NAV less 1%");
        vm.prank(alice);
        vault.withdraw(100_000e6, alice, alice);
    }

    /**
     * The attack the rate bound exists for. The issuer's contract accepts any checkpoint within
     * $1.00 of the last - about 9% here. Mallory deposits before a bad checkpoint lands and redeems
     * after it: without the bound she takes ~9% of the pool from Alice. With it, a day's worth of
     * the capped rate is all the share price can move.
     */
    function test_ABadNavSpikeCannotBeRedeemedAgainstOtherHolders() public {
        _allowlist();
        _depositAndAllocate(1_000_000e6, 900_000e6);
        vm.prank(mallory);
        vault.deposit(1_000_000e6, mallory);
        vm.prank(keeper);
        vault.allocate(adapter, 800_000e6);

        vm.warp(block.timestamp + 1 days);
        feed.set(11_200_000 + 990_000, uint64(block.timestamp));

        uint256 shares = vault.balanceOf(mallory);
        vm.prank(mallory);
        uint256 out = vault.redeem(shares, mallory, mallory);
        uint256 maxGain = (1_000_000e6 * uint256(MAX_GROWTH_BPS)) / 10_000 / 365 + 1e6;
        assertLe(out, 1_000_000e6 + maxGain, "at most one day of the capped rate");
        assertLt(out, 1_010_000e6, "nowhere near the 9% spike");
    }

    function test_ANavDropReachesTheSharePriceAtOnceAndTripsTheBreaker() public {
        _allowlist();
        _depositAndAllocate(1_000_000e6, 900_000e6);
        feed.set((11_200_000 * 90) / 100, uint64(block.timestamp));
        assertApproxEqAbs(adapter.totalValue(), 810_000e6, 1e6, "a 10% drop, immediately");
        vault.checkpoint();
        assertTrue(vault.depositsPaused());
    }

    /// The bound never falls, so a dip that is corrected is not throttled on the way back.
    function test_ACorrectedDipIsNotThrottledOnTheWayBack() public {
        _allowlist();
        _depositAndAllocate(1_000_000e6, 900_000e6);
        uint256 before = adapter.totalValue();
        feed.set(11_000_000, uint64(block.timestamp));
        adapter.poke();
        assertLt(adapter.totalValue(), before);
        feed.set(11_200_000, uint64(block.timestamp));
        assertEq(adapter.totalValue(), before, "back in full");
    }

    function testFuzz_TheReferenceRisesNoFasterThanTheCap(uint32 dt, uint32 jumpBps) public {
        uint256 elapsed = bound(uint256(dt), 0, 400 days);
        uint256 jump = bound(uint256(jumpBps), 0, 50_000);
        vm.warp(block.timestamp + elapsed);
        feed.set(11_200_000 + (11_200_000 * jump) / 10_000, uint64(block.timestamp));
        (bool ok, uint256 nav) = adapter.valuationNav();
        assertTrue(ok);
        assertLe(nav, 11_200_000 + (11_200_000 * uint256(MAX_GROWTH_BPS) * elapsed) / (10_000 * 365 days));
        adapter.poke(); // anyone may; it cannot move the bound faster either
        assertLe(adapter.navRef(), 11_200_000 + (11_200_000 * uint256(MAX_GROWTH_BPS) * elapsed) / (10_000 * 365 days));
    }

    function test_ANavBelowTheIssuersFloorIsNotTrusted() public {
        feed.set(6_900_000, uint64(block.timestamp));
        (bool ok,) = adapter.oracleNav();
        assertFalse(ok);
    }

    /*//////////////////////////////////////////////////////////////
                             SUBSCRIPTIONS
    //////////////////////////////////////////////////////////////*/

    /// The token owner points subscriptions at another oracle. The adapter refuses to subscribe.
    function test_ASwappedSubscriptionOracleIsRefused() public {
        _allowlist();
        MockNavOracle other = new MockNavOracle();
        ustb.setOracle(address(other));
        assertEq(adapter.depositBlocker(), "USTB subscriptions are priced by a different oracle than redemptions");
    }

    /// Whatever the token's math believed, a subscription worth less than it cost reverts.
    function test_ASubscriptionThatMintsTooLittleReverts() public {
        _allowlist();
        ustb.setShortMint(100); // 1% short
        vm.prank(alice);
        vault.deposit(100_000e6, alice);
        vm.prank(keeper);
        vm.expectRevert();
        vault.allocate(adapter, 50_000e6);
    }

    function test_FeesAreInTheValuationAndCappedByTheEntryCost() public {
        _allowlist();
        redemption.setFee(10);
        _depositAndAllocate(1_000_000e6, 500_000e6);
        assertApproxEqAbs(adapter.totalValue(), (500_000e6 * 9_990) / 10_000, 1e6, "valued net of the exit fee");
        ustb.setFee(10);
        assertEq(adapter.depositBlocker(), "", "20 bps of issuer fees fit a 25 bps entry cost");
        SuperstateUSTBAdapter strict =
            new SuperstateUSTBAdapter(address(vault), ustb, redemption, MAX_NAV_AGE, MAX_GROWTH_BPS, 100, 15);
        ustb.setAllowed(address(strict), true);
        assertEq(strict.depositBlocker(), "USTB fees exceed the adapter's maximum entry cost");
    }

    function test_PausesBlockSubscriptionsAndInstantExitsWithReasons() public {
        _allowlist();
        _depositAndAllocate(1_000_000e6, 500_000e6);
        ustb.setPaused(true, false);
        assertEq(adapter.depositBlocker(), "USTB is paused");
        assertEq(adapter.maxInstantWithdraw(), 0);
        ustb.setPaused(false, true);
        assertEq(adapter.redemptionBlocker(), "USTB accounting is paused");
        ustb.setPaused(false, false);
        redemption.setPaused(true);
        assertEq(adapter.redemptionBlocker(), "USTB redemptions are paused");
        assertEq(adapter.maxInstantWithdraw(), 0);
    }

    /// Views sit inside the vault's totalAssets: a broken token view must not freeze the vault.
    function test_ViewsNeverRevertWhenTheIssuerContractsDo() public {
        _allowlist();
        _depositAndAllocate(1_000_000e6, 500_000e6);
        ustb.setViewsRevert(true);
        feed.setReverts(true);
        adapter.totalValue();
        adapter.maxInstantWithdraw();
        assertEq(adapter.maxDeposit(), 0);
        vault.totalAssets();
        vm.prank(alice);
        vault.withdraw(500_000e6, alice, alice);
    }

    function test_OnlyTheVaultMovesFunds() public {
        vm.startPrank(mallory);
        vm.expectRevert(SuperstateUSTBAdapter.NotVault.selector);
        adapter.deposit(1);
        vm.expectRevert(SuperstateUSTBAdapter.NotVault.selector);
        adapter.withdraw(1, mallory);
        vm.expectRevert(SuperstateUSTBAdapter.NotVault.selector);
        adapter.harvest();
        vm.stopPrank();
    }

    function test_ConstructorRefusesAMismatchedOrStaleSetup() public {
        MockUSDC other = new MockUSDC();
        YieldVault wrong = new YieldVault(IERC20(address(other)), "x", "x", gov, gov, keeper, 1, 500, DELAY);
        vm.expectRevert(SuperstateUSTBAdapter.AssetMismatch.selector);
        new SuperstateUSTBAdapter(address(wrong), ustb, redemption, MAX_NAV_AGE, MAX_GROWTH_BPS, 100, 25);

        feed.setReverts(true);
        vm.expectRevert(SuperstateUSTBAdapter.OracleUnavailable.selector);
        new SuperstateUSTBAdapter(address(vault), ustb, redemption, MAX_NAV_AGE, MAX_GROWTH_BPS, 100, 25);
    }
}
