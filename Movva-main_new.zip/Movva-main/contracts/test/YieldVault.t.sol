// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Governed} from "./utils/Governed.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";
import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {ERC4626} from "@openzeppelin/contracts/token/ERC20/extensions/ERC4626.sol";
import {YieldVault} from "../yield/YieldVault.sol";
import {IYieldAdapter} from "../yield/IYieldAdapter.sol";

contract MockAsset is ERC20 {
    constructor() ERC20("Mock USD", "mUSD") {}

    function mint(address to, uint256 v) external {
        _mint(to, v);
    }

    function burn(address from, uint256 v) external {
        _burn(from, v);
    }
}

/// A yield source whose value the test can move: earn, lose, or become illiquid.
contract MockAdapter is IYieldAdapter {
    MockAsset public immutable token;
    address public immutable override vault;
    uint256 public instantCap = type(uint256).max;

    constructor(address vault_, MockAsset token_) {
        vault = vault_;
        token = token_;
    }

    function asset() external view returns (address) {
        return address(token);
    }

    function name() external pure returns (string memory) {
        return "mock";
    }

    function totalValue() public view returns (uint256) {
        return token.balanceOf(address(this));
    }

    function maxInstantWithdraw() external view returns (uint256) {
        uint256 v = totalValue();
        return v < instantCap ? v : instantCap;
    }

    function deposit(uint256 assets) external view returns (uint256) {
        require(msg.sender == vault, "vault");
        return assets;
    }

    function withdraw(uint256 assets, address to) external virtual returns (uint256 out) {
        require(msg.sender == vault, "vault");
        uint256 bal = token.balanceOf(address(this));
        uint256 cap = instantCap < bal ? instantCap : bal;
        out = assets < cap ? assets : cap;
        require(token.transfer(to, out), "transfer");
    }

    function harvest() external pure returns (uint256) {
        return 0;
    }

    function earn(uint256 v) external {
        token.mint(address(this), v);
    }

    function lose(uint256 v) external {
        token.burn(address(this), v);
    }

    function setInstantCap(uint256 c) external {
        instantCap = c;
    }
}

contract YieldVaultTest is Governed {
    MockAsset usd;
    YieldVault vault;
    MockAdapter a1;
    MockAdapter a2;

    address gov = makeAddr("gov");
    address guardian = makeAddr("guardian");
    address keeper = makeAddr("keeper");
    address alice = makeAddr("alice");
    address bob = makeAddr("bob");
    address stranger = makeAddr("stranger");

    uint256 constant CAP = 1_000_000e18;

    function setUp() public {
        usd = new MockAsset();
        vault = new YieldVault(
            IERC20(address(usd)), "Shielded Yield USD", "syUSD", gov, guardian, keeper, CAP, 500, DELAY
        );
        a1 = new MockAdapter(address(vault), usd);
        a2 = new MockAdapter(address(vault), usd);
        vm.startPrank(gov);
        vault.addAdapter(a1, 6_000);
        vault.addAdapter(a2, 6_000);
        vault.completeSetup();
        vm.stopPrank();

        usd.mint(alice, 100_000e18);
        usd.mint(bob, 100_000e18);
        vm.prank(alice);
        usd.approve(address(vault), type(uint256).max);
        vm.prank(bob);
        usd.approve(address(vault), type(uint256).max);
    }

    function _deposit(address who, uint256 amt) internal returns (uint256 shares) {
        vm.prank(who);
        shares = vault.deposit(amt, who);
    }

    function _redeemAll(address who) internal returns (uint256 out) {
        uint256 shares = vault.balanceOf(who);
        vm.prank(who);
        out = vault.redeem(shares, who, who);
    }

    /*//////////////////////////////////////////////////////////////
                             SHARE ACCOUNTING
    //////////////////////////////////////////////////////////////*/

    function test_DepositAndRedeemRoundTrip() public {
        _deposit(alice, 10_000e18);
        uint256 out = _redeemAll(alice);
        assertApproxEqAbs(out, 10_000e18, 1);
        assertApproxEqAbs(usd.balanceOf(alice), 100_000e18, 1);
    }

    /// Rounding must never favour the redeemer: a vault that pays one wei too much can be
    /// drained one wei at a time.
    function testFuzz_RedeemNeverPaysMoreThanDeposited(uint96 amt) public {
        vm.assume(amt > 0 && amt <= 100_000e18);
        _deposit(alice, amt);
        assertLe(_redeemAll(alice), amt);
    }

    /**
     * The classic first-depositor attack: deposit one wei, donate a large amount straight to
     * the vault so the share price explodes, and let the next depositor's shares round down
     * to nothing. The decimals offset makes the donation cost the attacker, not the victim.
     */
    function test_FirstDepositorDonationAttackIsUneconomic() public {
        _deposit(bob, 1);
        vm.prank(bob);
        require(usd.transfer(address(vault), 10_000e18), "donate");

        _deposit(alice, 10_000e18);
        uint256 aliceOut = _redeemAll(alice);
        assertGe(aliceOut, 9_999e18, "the victim keeps essentially everything");

        _redeemAll(bob);
        assertLt(usd.balanceOf(bob), 100_000e18, "the attacker ends up poorer than they started");
    }

    /// Yield reaches every holder through the share price. No position is touched to pay it,
    /// which is what lets a shielded note earn without being linked to its payout.
    function test_YieldCompoundsWithoutTouchingAnyPosition() public {
        uint256 aliceShares = _deposit(alice, 10_000e18);
        _deposit(bob, 10_000e18);
        vm.prank(keeper);
        vault.allocate(a1, 12_000e18);

        a1.earn(2_000e18);

        assertEq(vault.balanceOf(alice), aliceShares, "share count never changed");
        assertApproxEqRel(_redeemAll(alice), 11_000e18, 1e12, "but it is worth 10% more");
        assertApproxEqRel(vault.previewRedeem(vault.balanceOf(bob)), 11_000e18, 1e12);
    }

    /// The last holder must always be able to leave once the price has moved at all.
    function test_TheLastHolderCanRedeemEverythingAfterAGain() public {
        _deposit(alice, 10_000e18);
        vm.prank(keeper);
        vault.allocate(a1, 6_000e18);
        a1.earn(123_456_789); // an awkward, non-round gain
        assertEq(vault.maxRedeem(alice), vault.balanceOf(alice));
        uint256 out = _redeemAll(alice);
        assertEq(vault.totalSupply(), 0, "nothing stranded");
        assertApproxEqAbs(out, 10_000e18 + 123_456_789, 2);
    }

    function test_TheLastHolderCanRedeemEverythingAfterALoss() public {
        _deposit(alice, 10_000e18);
        vm.prank(keeper);
        vault.allocate(a1, 6_000e18);
        a1.lose(1_234e18 + 7);
        assertEq(vault.maxRedeem(alice), vault.balanceOf(alice));
        _redeemAll(alice);
        assertEq(vault.totalSupply(), 0, "nothing stranded");
    }

    function testFuzz_FullExitIsAlwaysPossibleWhileLiquid(uint96 dep, uint64 gain, bool loss) public {
        uint256 amount = bound(uint256(dep), 1e6, 100_000e18);
        _deposit(alice, amount);
        uint256 allocated = (amount * 60) / 100;
        vm.prank(keeper);
        vault.allocate(a1, allocated);
        if (loss) a1.lose(bound(uint256(gain), 0, allocated));
        else a1.earn(gain);
        assertEq(vault.maxRedeem(alice), vault.balanceOf(alice));
        _redeemAll(alice);
        assertEq(vault.totalSupply(), 0);
    }

    /*//////////////////////////////////////////////////////////////
                          CAPS AND LIQUIDITY
    //////////////////////////////////////////////////////////////*/

    function test_DepositCapIsEnforced() public {
        vm.prank(gov);
        vault.setDepositCap(5_000e18);
        vm.prank(alice);
        vm.expectRevert(
            abi.encodeWithSelector(
                ERC4626.ERC4626ExceededMaxDeposit.selector, alice, 6_000e18, 5_000e18
            )
        );
        vault.deposit(6_000e18, alice);
    }

    function test_AllocationCapIsEnforced() public {
        _deposit(alice, 10_000e18);
        vm.prank(keeper);
        vault.allocate(a1, 6_000e18);
        vm.prank(keeper);
        vm.expectRevert(YieldVault.OverAllocationCap.selector);
        vault.allocate(a1, 1);
    }

    function test_WithdrawPullsFromAdaptersWhenIdleIsShort() public {
        _deposit(alice, 10_000e18);
        vm.startPrank(keeper);
        vault.allocate(a1, 6_000e18);
        vault.allocate(a2, 4_000e18);
        vm.stopPrank();
        assertEq(usd.balanceOf(address(vault)), 0);

        assertApproxEqAbs(_redeemAll(alice), 10_000e18, 1);
        assertEq(a1.totalValue() + a2.totalValue(), 0);
    }

    /// A withdrawal the vault cannot fund instantly must fail up front, not half-way.
    function test_WithdrawBeyondInstantLiquidityFailsUpFront() public {
        _deposit(alice, 10_000e18);
        vm.prank(keeper);
        vault.allocate(a1, 6_000e18);
        a1.setInstantCap(1_000e18);

        assertEq(vault.maxWithdraw(alice), 5_000e18, "4,000 idle + 1,000 instant");
        vm.prank(alice);
        vm.expectRevert(
            abi.encodeWithSelector(
                ERC4626.ERC4626ExceededMaxWithdraw.selector, alice, 6_000e18, 5_000e18
            )
        );
        vault.withdraw(6_000e18, alice, alice);
    }

    /*//////////////////////////////////////////////////////////////
                           CIRCUIT BREAKER
    //////////////////////////////////////////////////////////////*/

    function test_CircuitBreakerTripsOnADrawdownAndLeavesWithdrawalsOpen() public {
        _deposit(alice, 10_000e18);
        vm.prank(keeper);
        vault.allocate(a1, 6_000e18);

        a1.lose(1_000e18); // -10% of the vault, limit is 5%
        vault.checkpoint();

        assertTrue(vault.depositsPaused(), "deposits stop");
        assertEq(vault.maxDeposit(bob), 0);
        vm.prank(bob);
        vm.expectRevert(
            abi.encodeWithSelector(ERC4626.ERC4626ExceededMaxDeposit.selector, bob, 1, 0)
        );
        vault.deposit(1, bob);

        assertApproxEqAbs(_redeemAll(alice), 9_000e18, 1, "but holders can still leave, at the real value");
    }

    function test_ASmallDipDoesNotTripTheBreaker() public {
        _deposit(alice, 10_000e18);
        vm.prank(keeper);
        vault.allocate(a1, 6_000e18);
        a1.lose(300e18); // -3%
        vault.checkpoint();
        assertFalse(vault.depositsPaused());
    }

    function test_ResumingAcknowledgesTheLoss() public {
        _deposit(alice, 10_000e18);
        vm.prank(keeper);
        vault.allocate(a1, 6_000e18);
        a1.lose(1_000e18);
        vault.checkpoint();

        vm.prank(gov);
        vault.resumeDeposits();
        assertFalse(vault.depositsPaused());
        assertEq(vault.highWaterAssetsPerShare(), vault.assetsPerShare(), "the loss is the new baseline");
        _deposit(bob, 1_000e18);
    }

    /// The check must not depend on one operator staying online.
    function test_AnyoneCanRunTheDrawdownCheck() public {
        _deposit(alice, 10_000e18);
        vm.prank(keeper);
        vault.allocate(a1, 6_000e18);
        a1.lose(1_000e18);
        vm.prank(stranger);
        vault.checkpoint();
        assertTrue(vault.depositsPaused());
    }

    function test_AllocationsStopWhilePaused() public {
        _deposit(alice, 10_000e18);
        vm.prank(guardian);
        vault.pauseDeposits();
        vm.prank(keeper);
        vm.expectRevert(YieldVault.DepositsArePaused.selector);
        vault.allocate(a1, 1_000e18);
    }

    /*//////////////////////////////////////////////////////////////
                               ROLES
    //////////////////////////////////////////////////////////////*/

    function test_OnlyKeeperAllocates() public {
        _deposit(alice, 10_000e18);
        vm.prank(stranger);
        vm.expectRevert(YieldVault.NotKeeper.selector);
        vault.allocate(a1, 1_000e18);
        vm.prank(guardian);
        vm.expectRevert(YieldVault.NotKeeper.selector);
        vault.allocate(a1, 1_000e18);
    }

    /// The guardian can pull funds out of a source under stress, and only back into the vault.
    function test_GuardianCanPullFundsBackButOnlyIntoTheVault() public {
        _deposit(alice, 10_000e18);
        vm.prank(keeper);
        vault.allocate(a1, 6_000e18);

        vm.prank(guardian);
        vault.deallocate(a1, 6_000e18);
        assertEq(usd.balanceOf(address(vault)), 10_000e18);
        assertEq(usd.balanceOf(guardian), 0);

        vm.prank(stranger);
        vm.expectRevert(YieldVault.NotGuardianOrKeeper.selector);
        vault.deallocate(a1, 1);
    }

    function test_GuardianPausesButOnlyGovernorResumes() public {
        vm.prank(guardian);
        vault.pauseDeposits();
        vm.prank(guardian);
        vm.expectRevert(DelayedGovernance.NotGovernor.selector);
        vault.resumeDeposits();
    }

    function test_AdapterForAnotherVaultOrAssetIsRejected() public {
        // A vault still in setup, where adding an adapter is instant, isolates the check.
        YieldVault fresh = new YieldVault(
            IERC20(address(usd)), "Fresh", "fr", gov, guardian, keeper, CAP, 500, DELAY
        );
        MockAdapter wrongVault = new MockAdapter(stranger, usd);
        MockAdapter wrongAsset = new MockAdapter(address(fresh), new MockAsset());
        vm.startPrank(gov);
        vm.expectRevert(YieldVault.BadAdapter.selector);
        fresh.addAdapter(wrongVault, 1_000);
        vm.expectRevert(YieldVault.BadAdapter.selector);
        fresh.addAdapter(wrongAsset, 1_000);
        vm.stopPrank();
    }

    /*//////////////////////////////////////////////////////////////
                         DELAYED GOVERNANCE
    //////////////////////////////////////////////////////////////*/

    /**
     * The theft the delay exists for: list an adapter the governor wrote, make itself keeper,
     * and allocate the vault into it. Each step now waits, in public, and every holder can
     * redeem in full before the first one lands.
     */
    function test_AGovernorCannotListAnAdapterTakeTheKeeperAndAllocateInOneBlock() public {
        _deposit(alice, 10_000e18);
        MockAdapter evil = new MockAdapter(address(vault), usd);

        vm.startPrank(gov);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, YieldVault.addAdapter.selector)
        );
        vault.addAdapter(evil, 10_000);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, YieldVault.setKeeper.selector)
        );
        vault.setKeeper(gov);
        vault.schedule(abi.encodeCall(YieldVault.addAdapter, (evil, 10_000)));
        vault.schedule(abi.encodeCall(YieldVault.setKeeper, (gov)));
        vm.stopPrank();

        // Alice sees both announcements and leaves with everything, before either can run.
        assertApproxEqAbs(_redeemAll(alice), 10_000e18, 1);

        vm.warp(block.timestamp + DELAY);
        vm.startPrank(gov);
        vault.execute(abi.encodeCall(YieldVault.addAdapter, (evil, 10_000)));
        vault.execute(abi.encodeCall(YieldVault.setKeeper, (gov)));
        vm.stopPrank();
        assertEq(vault.keeper(), gov);
        assertEq(usd.balanceOf(address(vault)), 0, "there was nothing left to take");
    }

    /// The brakes are not delayed: a compromised keeper is contained at once.
    function test_DeactivatingAnAdapterAndLoweringCapsAreInstant() public {
        _deposit(alice, 10_000e18);
        vm.startPrank(gov);
        vault.updateAdapter(a1, 6_000, false);
        vault.setDepositCap(1);
        vault.setMaxDrawdown(100);
        vault.setGuardian(stranger);
        vm.stopPrank();
        vm.prank(keeper);
        vm.expectRevert(YieldVault.AdapterInactive.selector);
        vault.allocate(a1, 1_000e18);

        vm.startPrank(gov);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, YieldVault.updateAdapter.selector)
        );
        vault.updateAdapter(a1, 6_000, true);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, YieldVault.setDepositCap.selector)
        );
        vault.setDepositCap(CAP);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, YieldVault.setMaxDrawdown.selector)
        );
        vault.setMaxDrawdown(900);
        vm.stopPrank();
    }

    /// Nobody's money goes in while every change is still instant.
    function test_NoDepositsOrAllocationsBeforeSetupIsComplete() public {
        YieldVault fresh = new YieldVault(
            IERC20(address(usd)), "Fresh", "fr", gov, guardian, keeper, CAP, 500, DELAY
        );
        assertEq(fresh.maxDeposit(alice), 0);
        vm.prank(alice);
        usd.approve(address(fresh), type(uint256).max);
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(ERC4626.ERC4626ExceededMaxDeposit.selector, alice, 1, 0));
        fresh.deposit(1, alice);
        vm.prank(keeper);
        vm.expectRevert(DelayedGovernance.SetupIncomplete.selector);
        fresh.allocate(a1, 0);
    }

    /// No value is ever dropped from the books by removing a source that still holds funds.
    function test_NonEmptyAdapterCannotBeRemoved() public {
        _deposit(alice, 10_000e18);
        vm.prank(keeper);
        vault.allocate(a1, 5_000e18);

        vm.prank(gov);
        vm.expectRevert(YieldVault.AdapterNotEmpty.selector);
        vault.removeAdapter(a1);

        vm.prank(keeper);
        vault.deallocate(a1, 5_000e18);
        vm.prank(gov);
        vault.removeAdapter(a1);
        assertEq(vault.adapters().length, 1);
        assertApproxEqAbs(vault.totalAssets(), 10_000e18, 0);
    }
}
