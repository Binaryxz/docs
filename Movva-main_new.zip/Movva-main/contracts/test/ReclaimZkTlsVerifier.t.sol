// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {ReclaimZkTlsVerifier} from "../ramp/ReclaimZkTlsVerifier.sol";
import {IAttestorVerifier} from "../ramp/IAttestorVerifier.sol";
import {ReclaimProofBuilder} from "./utils/ReclaimProofBuilder.sol";
import {DelayedGovernance} from "../common/DelayedGovernance.sol";

contract ReclaimZkTlsVerifierTest is ReclaimProofBuilder {
    ReclaimZkTlsVerifier v;

    uint256 w1 = 0x11;
    uint256 w2 = 0x2;
    uint256 w3 = 0x3;
    uint256 wEvil = 0xBAD;
    address governor = address(0x60F);

    bytes32 constant ORDER = bytes32(uint256(0xA11CE));
    bytes32 constant BANK_TX = bytes32(uint256(0xE2E1));
    bytes32 constant PAYEE = keccak256("seller@pix");

    function setUp() public {
        address[] memory set = new address[](3);
        set[0] = vm.addr(w1);
        set[1] = vm.addr(w2);
        set[2] = vm.addr(w3);
        v = new ReclaimZkTlsVerifier(governor, DELAY, set, 2, _one(BANK_TEMPLATE), _oneString(BANK_PREFIX));
        _completeSetup(address(v));
    }

    function _two() internal view returns (uint256[] memory k) {
        k = new uint256[](2);
        k[0] = w1;
        k[1] = w2;
    }

    function _fields(uint256 cents) internal pure returns (Fields memory) {
        return Fields({
            orderId: ORDER,
            bankTxId: BANK_TX,
            payeeKeyHash: PAYEE,
            payerRef: keccak256("payer"),
            amountBrlCents: cents,
            paidAt: 1_700_000_000,
            rail: 1
        });
    }

    function _genuine() internal view returns (ReclaimZkTlsVerifier.Proof memory) {
        return _proof(_params(BANK_URL), _context(_fields(1_500_000), BANK_TEMPLATE), _two());
    }

    /// A proof whose parameters are `params` and whose context is otherwise genuine.
    function _withParams(string memory params) internal view returns (bytes memory) {
        return abi.encode(_proof(params, _context(_fields(1_500_000), BANK_TEMPLATE), _two()));
    }

    function _withContext(string memory ctx) internal view returns (bytes memory) {
        return abi.encode(_proof(_params(BANK_URL), ctx, _two()));
    }

    /*//////////////////////////////////////////////////////////////
                           THE GENUINE PROOF
    //////////////////////////////////////////////////////////////*/

    function test_VerifiesAGenuineProofAndReadsTheFields() public view {
        IAttestorVerifier.Payment memory p = v.verifyPayment(ORDER, abi.encode(_genuine()));
        assertEq(p.bankTxId, BANK_TX);
        assertEq(p.payeeKeyHash, PAYEE);
        assertEq(p.payerRef, keccak256("payer"));
        assertEq(p.amountBrlCents, 1_500_000);
        assertEq(p.paidAt, 1_700_000_000);
        assertEq(uint8(p.rail), uint8(IAttestorVerifier.Rail.PIX));
    }

    /// Reclaim witnesses personal-sign the serialised claim STRING. The previous verifier
    /// expected a signature over its keccak, which no real witness produces.
    function test_ASignatureOverTheHashOfTheClaimIsNotAWitnessSignature() public {
        ReclaimZkTlsVerifier.Proof memory p = _genuine();
        bytes memory ser = abi.encodePacked(
            _hex32(p.signedClaim.claim.identifier), "\n", _hexAddr(p.signedClaim.claim.owner),
            "\n", vm.toString(uint256(p.signedClaim.claim.timestampS)), "\n",
            vm.toString(uint256(p.signedClaim.claim.epoch))
        );
        bytes32 oldDigest =
            keccak256(abi.encodePacked("\x19Ethereum Signed Message:\n32", keccak256(ser)));
        (uint8 v1, bytes32 r1, bytes32 s1) = vm.sign(w1, oldDigest);
        (uint8 v2, bytes32 r2, bytes32 s2) = vm.sign(w2, oldDigest);
        p.signedClaim.signatures = new bytes[](2);
        p.signedClaim.signatures[0] = abi.encodePacked(r1, s1, v1);
        p.signedClaim.signatures[1] = abi.encodePacked(r2, s2, v2);
        vm.expectRevert(); // recovers some other address: UnknownWitness
        v.verifyPayment(ORDER, abi.encode(p));
    }

    /*//////////////////////////////////////////////////////////////
                      WHICH SERVER WAS THE SESSION WITH
    //////////////////////////////////////////////////////////////*/

    /**
     * The attack this file exists for. Every real Reclaim HTTP claim has provider "http",
     * so checking the provider string admitted a session with ANY server. The attacker runs
     * their own server, has the witnesses observe a session returning the payment fields
     * they want, and presents it. The witness honestly records a different template hash.
     */
    function test_ASessionWithTheAttackersOwnServerIsRefused() public {
        bytes32 attackerTemplate = keccak256("template: evil.example /fake-receipt");
        ReclaimZkTlsVerifier.Proof memory p = _proof(
            _params("https://evil.example/fake-receipt"),
            _context(_fields(99_000_000), attackerTemplate),
            _two()
        );
        vm.expectRevert(
            abi.encodeWithSelector(ReclaimZkTlsVerifier.EndpointNotAllowed.selector, attackerTemplate)
        );
        v.verifyPayment(ORDER, abi.encode(p));
    }

    /// Defence in depth: even under an allowlisted template hash, the URL must be the bank's.
    function test_AnAllowlistedTemplateHashCannotVouchForAnotherHost() public {
        vm.expectRevert(ReclaimZkTlsVerifier.UrlNotAllowed.selector);
        v.verifyPayment(ORDER, _withParams(_params("https://evil.example/pix/v2/{{e2eId}}")));
    }

    function test_LookAlikeHostsAreRefused() public {
        string[6] memory lookalikes = [
            "https://api.bank.example.evil.io/pix/v2/x", // suffix domain
            "https://api.bank.example@evil.io/pix/v2/x", // userinfo: host is evil.io
            "https://api.bank.exampleevil.io/pix/v2/x", // no boundary
            "http://api.bank.example/pix/v2/x", // downgrade
            "https://evil.io/https://api.bank.example/pix/v2/", // bank URL as a path
            "https://api.bank.example:8443/pix/v2/x" // another port is another server
        ];
        for (uint256 i; i < lookalikes.length; ++i) {
            bytes memory proof = _withParams(_params(lookalikes[i]));
            vm.expectRevert(ReclaimZkTlsVerifier.UrlNotAllowed.selector);
            v.verifyPayment(ORDER, proof);
        }
    }

    /// `\/` is `/` to JSON.parse. Raw bytes are compared here, so escapes are refused outright.
    function test_EscapedSlashesInTheUrlAreRefused() public {
        bytes memory proof = _withParams(_params("https:\\/\\/api.bank.example\\/pix\\/v2\\/x"));
        vm.expectRevert(abi.encodeWithSelector(ReclaimZkTlsVerifier.EscapedValue.selector, "url"));
        v.verifyPayment(ORDER, proof);
    }

    /// JSON.parse keeps the LAST duplicate. A reader that took the first would see the bank.
    function test_ADuplicateUrlKeyIsRefused() public {
        string memory params = string(
            abi.encodePacked(
                '{"method":"GET","url":"', BANK_URL, '","url":"https://evil.example/x"}'
            )
        );
        bytes memory proof = _withParams(params);
        vm.expectRevert(abi.encodeWithSelector(ReclaimZkTlsVerifier.DuplicateKey.selector, "url"));
        v.verifyPayment(ORDER, proof);
    }

    /// `"\u0075rl"` is `"url"` to JSON.parse, and would be the last - winning - url key.
    function test_AnEscapedKeyIsRefused() public {
        string memory params = string(
            abi.encodePacked(
                '{"method":"GET","url":"', BANK_URL, '","\\u0075rl":"https://evil.example/x"}'
            )
        );
        bytes memory proof = _withParams(params);
        vm.expectRevert(ReclaimZkTlsVerifier.EscapedKey.selector);
        v.verifyPayment(ORDER, proof);
    }

    /// A bank URL tucked inside a nested object is not the URL the witness connects to.
    function test_ANestedUrlKeyIsNotMistakenForTheRealOne() public {
        string memory params = string(
            abi.encodePacked(
                '{"paramValues":{"url":"', BANK_URL, '"} , "url" : "https://evil.example/x"}'
            )
        );
        bytes memory proof = _withParams(params);
        vm.expectRevert(ReclaimZkTlsVerifier.UrlNotAllowed.selector);
        v.verifyPayment(ORDER, proof);
    }

    function test_MalformedParametersAreRefused() public {
        bytes memory trailing = _withParams(string(abi.encodePacked(_params(BANK_URL), "x")));
        vm.expectRevert(ReclaimZkTlsVerifier.MalformedJson.selector);
        v.verifyPayment(ORDER, trailing);

        bytes memory truncated = _withParams('{"url":"https://api.bank.example/pix/v2/x"');
        vm.expectRevert(ReclaimZkTlsVerifier.MalformedJson.selector);
        v.verifyPayment(ORDER, truncated);

        bytes memory mismatched = _withParams(
            '{"a":{"b":1],"url":"https://api.bank.example/pix/v2/x"}'
        );
        vm.expectRevert(ReclaimZkTlsVerifier.MalformedJson.selector);
        v.verifyPayment(ORDER, mismatched);
    }

    function test_OnlyTheHttpProviderIsAccepted() public {
        ReclaimZkTlsVerifier.Proof memory p = _genuine();
        p.claimInfo.provider = "not-http";
        vm.expectRevert(ReclaimZkTlsVerifier.ProviderNotAllowed.selector);
        v.verifyPayment(ORDER, abi.encode(p));
    }

    /// Revoking an endpoint stops its proofs at once.
    function test_ARevokedEndpointNoLongerSettles() public {
        bytes memory proof = abi.encode(_genuine());
        vm.prank(governor);
        v.revokeEndpoint(BANK_TEMPLATE);
        vm.expectRevert(
            abi.encodeWithSelector(ReclaimZkTlsVerifier.EndpointNotAllowed.selector, BANK_TEMPLATE)
        );
        v.verifyPayment(ORDER, proof);
    }

    /*//////////////////////////////////////////////////////////////
                  WHERE THE PAYMENT FIELDS COME FROM
    //////////////////////////////////////////////////////////////*/

    /// A prover-written key outside `extractedParameters` is never read.
    function test_AProverWrittenAmountOutsideTheExtractedParametersIsIgnored() public view {
        Fields memory f = _fields(1_500_000);
        string memory ctx = string(
            abi.encodePacked(
                '{"amountBrlCents":"999999999",',
                '"contextAddress":"0x0000000000000000000000000000000000000000",',
                '"contextMessage":"', _hex32(ORDER), '",',
                '"extractedParameters":', _extracted(f), ',',
                '"providerHash":"', _hex32(BANK_TEMPLATE), '"}'
            )
        );
        IAttestorVerifier.Payment memory p = v.verifyPayment(ORDER, _withContext(ctx));
        assertEq(p.amountBrlCents, 1_500_000, "read what the witness extracted");
    }

    function test_ADuplicateFieldInsideTheExtractedParametersIsRefused() public {
        Fields memory f = _fields(1_500_000);
        string memory ext = string(
            abi.encodePacked(
                '{"amountBrlCents":"1","amountBrlCents":"1500000",',
                '"bankTxId":"', _hex32(f.bankTxId), '","paidAt":"1700000000",',
                '"payeeKeyHash":"', _hex32(f.payeeKeyHash), '","payerRef":"', _hex32(f.payerRef),
                '","rail":"1"}'
            )
        );
        string memory ctx = string(
            abi.encodePacked(
                '{"contextMessage":"', _hex32(ORDER), '","extractedParameters":', ext,
                ',"providerHash":"', _hex32(BANK_TEMPLATE), '"}'
            )
        );
        bytes memory proof = _withContext(ctx);
        vm.expectRevert(
            abi.encodeWithSelector(ReclaimZkTlsVerifier.DuplicateKey.selector, "amountBrlCents")
        );
        v.verifyPayment(ORDER, proof);
    }

    function test_ADuplicateProviderHashIsRefused() public {
        string memory ctx = string(
            abi.encodePacked(
                '{"contextMessage":"', _hex32(ORDER), '","extractedParameters":',
                _extracted(_fields(1_500_000)), ',"providerHash":"', _hex32(keccak256("evil")),
                '","providerHash":"', _hex32(BANK_TEMPLATE), '"}'
            )
        );
        bytes memory proof = _withContext(ctx);
        vm.expectRevert(
            abi.encodeWithSelector(ReclaimZkTlsVerifier.DuplicateKey.selector, "providerHash")
        );
        v.verifyPayment(ORDER, proof);
    }

    function test_AMissingExtractedFieldRevertsRatherThanReadingZero() public {
        string memory ctx = string(
            abi.encodePacked(
                '{"contextMessage":"', _hex32(ORDER),
                '","extractedParameters":{"bankTxId":"', _hex32(BANK_TX),
                '"},"providerHash":"', _hex32(BANK_TEMPLATE), '"}'
            )
        );
        bytes memory proof = _withContext(ctx);
        vm.expectRevert(abi.encodeWithSelector(ReclaimZkTlsVerifier.MissingField.selector, "amountBrlCents"));
        v.verifyPayment(ORDER, proof);
    }

    function test_NonNumericAmountIsRejected() public {
        Fields memory f = _fields(1_500_000);
        string memory ext = string(
            abi.encodePacked(
                '{"amountBrlCents":"1.5e6","bankTxId":"', _hex32(f.bankTxId),
                '","paidAt":"1700000000","payeeKeyHash":"', _hex32(f.payeeKeyHash),
                '","payerRef":"', _hex32(f.payerRef), '","rail":"1"}'
            )
        );
        string memory ctx = string(
            abi.encodePacked(
                '{"contextMessage":"', _hex32(ORDER), '","extractedParameters":', ext,
                ',"providerHash":"', _hex32(BANK_TEMPLATE), '"}'
            )
        );
        bytes memory proof = _withContext(ctx);
        vm.expectRevert(abi.encodeWithSelector(ReclaimZkTlsVerifier.BadNumber.selector, "amountBrlCents"));
        v.verifyPayment(ORDER, proof);
    }

    /*//////////////////////////////////////////////////////////////
                           BINDING AND QUORUM
    //////////////////////////////////////////////////////////////*/

    /// The attack this proof shape invites: keep the signatures, swap the context.
    function test_SwappingTheContextBreaksTheIdentifier() public {
        ReclaimZkTlsVerifier.Proof memory p = _genuine();
        p.claimInfo.context = _context(_fields(99_000_000), BANK_TEMPLATE); // richer
        vm.expectRevert(ReclaimZkTlsVerifier.IdentifierMismatch.selector);
        v.verifyPayment(ORDER, abi.encode(p));
    }

    function test_TamperingWithParametersBreaksTheIdentifier() public {
        ReclaimZkTlsVerifier.Proof memory p = _genuine();
        p.claimInfo.parameters = _params("https://api.bank.example/pix/v2/other");
        vm.expectRevert(ReclaimZkTlsVerifier.IdentifierMismatch.selector);
        v.verifyPayment(ORDER, abi.encode(p));
    }

    /// Binding: a genuine proof for one order is worthless against another.
    function test_ProofIsBoundToItsOrder() public {
        bytes memory encoded = abi.encode(_genuine());
        vm.expectRevert(ReclaimZkTlsVerifier.OrderMismatch.selector);
        v.verifyPayment(bytes32(uint256(0xDEAD)), encoded);
    }

    function test_OneWitnessIsNotAQuorum() public {
        uint256[] memory one = new uint256[](1);
        one[0] = w1;
        ReclaimZkTlsVerifier.Proof memory p =
            _proof(_params(BANK_URL), _context(_fields(1_500_000), BANK_TEMPLATE), one);
        vm.expectRevert(
            abi.encodeWithSelector(ReclaimZkTlsVerifier.NotEnoughSignatures.selector, 1, 2)
        );
        v.verifyPayment(ORDER, abi.encode(p));
    }

    function test_TheSameWitnessTwiceIsNotAQuorum() public {
        ReclaimZkTlsVerifier.Proof memory p = _genuine();
        p.signedClaim.signatures[1] = p.signedClaim.signatures[0];
        vm.expectRevert(ReclaimZkTlsVerifier.SignaturesUnsorted.selector);
        v.verifyPayment(ORDER, abi.encode(p));
    }

    function test_UnknownWitnessIsRejected() public {
        uint256[] memory k = new uint256[](2);
        k[0] = w1;
        k[1] = wEvil;
        ReclaimZkTlsVerifier.Proof memory p =
            _proof(_params(BANK_URL), _context(_fields(1_500_000), BANK_TEMPLATE), k);
        vm.expectRevert(
            abi.encodeWithSelector(ReclaimZkTlsVerifier.UnknownWitness.selector, vm.addr(wEvil))
        );
        v.verifyPayment(ORDER, abi.encode(p));
    }

    /*//////////////////////////////////////////////////////////////
                              GOVERNANCE
    //////////////////////////////////////////////////////////////*/

    /// The deploy default that caused all this was "http", which allowlisted every server.
    function test_ItCannotBeDeployedWithoutAnEndpointAllowlist() public {
        address[] memory set = new address[](1);
        set[0] = vm.addr(w1);
        vm.expectRevert(ReclaimZkTlsVerifier.NoEndpoints.selector);
        new ReclaimZkTlsVerifier(governor, DELAY, set, 1, new bytes32[](0), new string[](0));
    }

    function test_APrefixWithoutAHostBoundaryCannotBeAllowlisted() public {
        string[8] memory bad = [
            "https://api.bank.example", // no "/" after the host: matches .evil.io suffixes
            "http://api.bank.example/", // not TLS
            "https://api.bank.example@evil.io/",
            "https://API.bank.example/", // the witness lowercases hosts; bytes would never match
            "https://api.bank.example/pix?x=", // query characters change parsing
            "https://api.bank.example/{{host}}/",
            "https:///pix/", // empty host
            "https://api.bank.example\\@evil.io/"
        ];
        // A verifier still in setup, where allowing is instant, isolates the validation.
        address[] memory set = new address[](1);
        set[0] = vm.addr(w1);
        ReclaimZkTlsVerifier fresh =
            new ReclaimZkTlsVerifier(governor, DELAY, set, 1, _one(BANK_TEMPLATE), _oneString(BANK_PREFIX));
        vm.startPrank(governor);
        for (uint256 i; i < bad.length; ++i) {
            vm.expectRevert(ReclaimZkTlsVerifier.BadUrlPrefix.selector);
            fresh.allowEndpoint(keccak256(bytes(bad[i])), bad[i]);
        }
        vm.stopPrank();
    }

    /// Changed behaviour: removal no longer lowers the threshold (see AttestorQuorumVerifier).
    function test_RemovingWitnessesNeverLowersTheThreshold() public {
        vm.startPrank(governor);
        v.setWitness(vm.addr(w1), false);
        v.setWitness(vm.addr(w2), false);
        vm.stopPrank();
        assertEq(v.witnessCount(), 1);
        assertEq(v.threshold(), 2, "fails closed rather than becoming 1-of-1");
    }

    /// Adding a witness, lowering the threshold, and allowing an endpoint all wait.
    function test_RiskIncreasingVerifierChangesMustBeScheduled() public {
        vm.startPrank(governor);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, ReclaimZkTlsVerifier.setWitness.selector)
        );
        v.setWitness(vm.addr(wEvil), true);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, ReclaimZkTlsVerifier.setThreshold.selector)
        );
        v.setThreshold(1);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, ReclaimZkTlsVerifier.allowEndpoint.selector)
        );
        v.allowEndpoint(keccak256("evil template"), "https://evil.example/");
        vm.stopPrank();

        _afterDelay(address(v), abi.encodeCall(ReclaimZkTlsVerifier.allowEndpoint, (keccak256("t2"), "https://api.bank2.example/")));
        assertEq(v.endpointUrlPrefix(keccak256("t2")), "https://api.bank2.example/");
    }

    function test_OnlyGovernorChangesWitnessesAndEndpoints() public {
        vm.expectRevert(DelayedGovernance.NotGovernor.selector);
        v.setWitness(address(0xFEE), true);
        vm.expectRevert(DelayedGovernance.NotGovernor.selector);
        v.allowEndpoint(keccak256("x"), "https://evil.example/");
        vm.expectRevert(DelayedGovernance.NotGovernor.selector);
        v.revokeEndpoint(BANK_TEMPLATE);
    }

    /*//////////////////////////////////////////////////////////////
                        WHICH RAILS AN ENDPOINT MAY ATTEST
    //////////////////////////////////////////////////////////////*/

    uint16 constant PIX_BIT = uint16(1 << 1);
    uint16 constant BOLETO_BIT = uint16(1 << 2);

    function _boletoFields() internal pure returns (Fields memory f) {
        f = _fields(1_500_000);
        f.payeeKeyHash = keccak256("boleto commitment");
        f.rail = 2;
    }

    /**
     * A PIX-receipt template whose rail capture turns out to match "2" must not become a way
     * to settle boleto orders: every endpoint is PIX-only until the governor says otherwise.
     */
    function test_APixReceiptEndpointCannotAttestABoleto() public {
        assertEq(v.endpointRails(BANK_TEMPLATE), PIX_BIT, "allowlisted endpoints start PIX-only");
        bytes memory proof = abi.encode(_proof(_params(BANK_URL), _context(_boletoFields(), BANK_TEMPLATE), _two()));
        vm.expectRevert(
            abi.encodeWithSelector(ReclaimZkTlsVerifier.RailNotAllowedForEndpoint.selector, BANK_TEMPLATE, uint8(2))
        );
        v.verifyPayment(ORDER, proof);
    }

    /// Widening an endpoint to boletos is the same power as allowing one, so it waits.
    function test_WideningAnEndpointToBoletoWaitsNarrowingDoesNot() public {
        vm.prank(governor);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, ReclaimZkTlsVerifier.setEndpointRails.selector)
        );
        v.setEndpointRails(BANK_TEMPLATE, PIX_BIT | BOLETO_BIT);

        _afterDelay(address(v), abi.encodeCall(ReclaimZkTlsVerifier.setEndpointRails, (BANK_TEMPLATE, PIX_BIT | BOLETO_BIT)));
        IAttestorVerifier.Payment memory p = v.verifyPayment(
            ORDER, abi.encode(_proof(_params(BANK_URL), _context(_boletoFields(), BANK_TEMPLATE), _two()))
        );
        assertEq(uint8(p.rail), uint8(IAttestorVerifier.Rail.BOLETO));
        assertEq(p.payeeKeyHash, keccak256("boleto commitment"));

        // Narrowing back to boleto-only is instant, and then a PIX receipt is refused.
        vm.prank(governor);
        v.setEndpointRails(BANK_TEMPLATE, BOLETO_BIT);
        vm.expectRevert(
            abi.encodeWithSelector(ReclaimZkTlsVerifier.RailNotAllowedForEndpoint.selector, BANK_TEMPLATE, uint8(1))
        );
        v.verifyPayment(ORDER, abi.encode(_genuine()));
    }

    function test_EndpointRailMasksAreValidatedAndDieWithTheEndpoint() public {
        // Validated during setup too, where the change itself would be instant.
        address[] memory set = new address[](1);
        set[0] = vm.addr(w1);
        ReclaimZkTlsVerifier fresh =
            new ReclaimZkTlsVerifier(governor, DELAY, set, 1, _one(BANK_TEMPLATE), _oneString(BANK_PREFIX));
        vm.startPrank(governor);
        vm.expectRevert(ReclaimZkTlsVerifier.BadRailMask.selector);
        fresh.setEndpointRails(BANK_TEMPLATE, PIX_BIT | 1); // UNSPECIFIED is never settleable

        vm.expectRevert(ReclaimZkTlsVerifier.BadRailMask.selector);
        v.setEndpointRails(BANK_TEMPLATE, 0);
        vm.expectRevert(
            abi.encodeWithSelector(ReclaimZkTlsVerifier.EndpointNotAllowed.selector, keccak256("unknown"))
        );
        fresh.setEndpointRails(keccak256("unknown"), PIX_BIT);
        v.revokeEndpoint(BANK_TEMPLATE);
        vm.stopPrank();
        assertEq(v.endpointRails(BANK_TEMPLATE), 0, "revoking clears the rails too");
    }

    function test_OnlyGovernorSetsEndpointRails() public {
        vm.prank(address(0xBAD));
        vm.expectRevert(DelayedGovernance.NotGovernor.selector);
        v.setEndpointRails(BANK_TEMPLATE, PIX_BIT);
    }

    /*//////////////////////////////////////////////////////////////
               THE ORDER'S TXID, A BANK-WRITTEN BINDING (M-03)
    //////////////////////////////////////////////////////////////*/

    /// The escrow the tests call `verifyPayment` from: the txid is derived from the CALLER.
    address constant ESCROW = address(0xE5C);
    bytes32 constant SYBIL = bytes32(uint256(0x5B11));

    function _requireTxid() internal {
        vm.prank(governor);
        v.setEndpointOrderTxid(BANK_TEMPLATE, true); // instant: it only narrows what settles
    }

    function _proofWithTxid(bytes32 orderId, string memory txid, Fields memory f) internal view returns (bytes memory) {
        f.orderId = orderId;
        return abi.encode(_proof(_params(BANK_URL), _contextWithTxid(f, BANK_TEMPLATE, txid), _two()));
    }

    function _txid(bytes32 orderId, uint256 n) internal view returns (string memory) {
        return _orderTxid(block.chainid, ESCROW, orderId, n);
    }

    /// A known answer, shared with packages/ramp (reclaim.test.ts, "orderTxid"): chain 1, this
    /// escrow and order. Everyone who derives the txid - verifier, LP node, wallet - must agree.
    function test_TheOrderTxidDerivationMatchesTheSharedVector() public pure {
        string memory t = _orderTxid(1, ESCROW, ORDER, 35);
        assertEq(t, "5DNJELJK734WBOLP6FPSHGWQRRYWXS5MEZS", "the vector packages/ramp checks too");
    }

    function test_AFlaggedEndpointSettlesTheOrderItsTxidNames() public {
        _requireTxid();
        // A static BR Code's 25 characters, and an API Pix cob's 35: both prefixes of one string.
        vm.startPrank(ESCROW);
        IAttestorVerifier.Payment memory p = v.verifyPayment(ORDER, _proofWithTxid(ORDER, _txid(ORDER, 25), _fields(1_500_000)));
        assertEq(p.bankTxId, BANK_TX);
        p = v.verifyPayment(ORDER, _proofWithTxid(ORDER, _txid(ORDER, 35), _fields(1_500_000)));
        assertEq(p.amountBrlCents, 1_500_000);
        p = v.verifyPayment(ORDER, _proofWithTxid(ORDER, _txid(ORDER, 30), _fields(1_500_000)));
        assertEq(p.payeeKeyHash, PAYEE);
        vm.stopPrank();
    }

    /**
     * M-03 itself, at the verifier: the LP proves an honest taker's credit - which carries the
     * taker's order's txid, written by the bank - against its own sybil order. `contextMessage` is
     * the prover's to choose; the txid is not.
     */
    function test_AFlaggedEndpointRefusesACreditPaidForAnotherOrder() public {
        _requireTxid();
        bytes memory proof = _proofWithTxid(SYBIL, _txid(ORDER, 25), _fields(1_500_000));
        vm.prank(ESCROW);
        vm.expectRevert(ReclaimZkTlsVerifier.OrderTxidMismatch.selector);
        v.verifyPayment(SYBIL, proof);
        // The same credit through the cob form of the taker's txid: still the taker's order.
        proof = _proofWithTxid(SYBIL, _txid(ORDER, 35), _fields(1_500_000));
        vm.prank(ESCROW);
        vm.expectRevert(ReclaimZkTlsVerifier.OrderTxidMismatch.selector);
        v.verifyPayment(SYBIL, proof);
    }

    /// The txid names an order on one escrow: another escrow (or a direct call) derives another.
    function test_ATxidIsBoundToTheEscrowThatAsks() public {
        _requireTxid();
        bytes memory proof = _proofWithTxid(ORDER, _txid(ORDER, 25), _fields(1_500_000));
        vm.prank(address(0xE5D));
        vm.expectRevert(ReclaimZkTlsVerifier.OrderTxidMismatch.selector);
        v.verifyPayment(ORDER, proof);
        vm.prank(ESCROW);
        v.verifyPayment(ORDER, proof);
    }

    function test_AFlaggedEndpointRefusesAPaymentWithoutATxid() public {
        _requireTxid();
        vm.prank(ESCROW);
        vm.expectRevert(abi.encodeWithSelector(ReclaimZkTlsVerifier.MissingField.selector, "txid"));
        v.verifyPayment(ORDER, abi.encode(_genuine()));
    }

    function test_AFlaggedEndpointRefusesMalformedTxids() public {
        _requireTxid();
        string memory full = _txid(ORDER, 35);
        string[6] memory bad = [
            _txid(ORDER, 24), // shorter than any BR Code's txid the node issues
            string.concat(full, "A"), // 36: longer than a cob txid may be
            "***", // a static code with no txid
            _lower(_txid(ORDER, 25)), // the right letters, the wrong case
            string.concat(_txid(ORDER, 24), "0"), // one character off
            "" // empty
        ];
        for (uint256 i; i < bad.length; ++i) {
            vm.prank(ESCROW);
            vm.expectRevert(ReclaimZkTlsVerifier.OrderTxidMismatch.selector);
            v.verifyPayment(ORDER, _proofWithTxid(ORDER, bad[i], _fields(1_500_000)));
        }
        // Not a string at all.
        string memory ctx =
            _contextAround(ORDER, string.concat(_extractedWithoutBrace(_fields(1_500_000)), ',"txid":12345}'), BANK_TEMPLATE);
        vm.prank(ESCROW);
        vm.expectRevert(abi.encodeWithSelector(ReclaimZkTlsVerifier.MissingField.selector, "txid"));
        v.verifyPayment(ORDER, _withContext(ctx));
    }

    /// Two txids in one document: one would win in JSON.parse, so the reader refuses both - flagged or not.
    function test_ADuplicateTxidIsRefusedEvenUnflagged() public {
        string memory twice = _contextAround(
            ORDER,
            string.concat(
                _extractedWithoutBrace(_fields(1_500_000)), ',"txid":"', _txid(ORDER, 25), '","txid":"', _txid(SYBIL, 25), '"}'
            ),
            BANK_TEMPLATE
        );
        vm.prank(ESCROW);
        vm.expectRevert(abi.encodeWithSelector(ReclaimZkTlsVerifier.DuplicateKey.selector, "txid"));
        v.verifyPayment(ORDER, _withContext(twice));
    }

    /// An endpoint without the flag works as before: no txid needed, and one present is not read.
    function test_AnUnflaggedEndpointIsUnchanged() public {
        assertFalse(v.endpointRequiresOrderTxid(BANK_TEMPLATE), "off unless set");
        vm.startPrank(ESCROW);
        v.verifyPayment(ORDER, abi.encode(_genuine()));
        v.verifyPayment(SYBIL, _proofWithTxid(SYBIL, _txid(ORDER, 25), _fields(1_500_000)));
        v.verifyPayment(ORDER, _proofWithTxid(ORDER, "anything", _fields(1_500_000)));
        vm.stopPrank();
        // And from any caller, as before.
        v.verifyPayment(ORDER, abi.encode(_genuine()));
    }

    /// A boleto is bound to its order by the commitment the escrow holds, and has no txid.
    function test_ABoletoOnAFlaggedEndpointNeedsNoTxid() public {
        _afterDelay(address(v), abi.encodeCall(ReclaimZkTlsVerifier.setEndpointRails, (BANK_TEMPLATE, PIX_BIT | BOLETO_BIT)));
        _requireTxid();
        vm.startPrank(ESCROW);
        IAttestorVerifier.Payment memory p = v.verifyPayment(
            ORDER, abi.encode(_proof(_params(BANK_URL), _context(_boletoFields(), BANK_TEMPLATE), _two()))
        );
        assertEq(uint8(p.rail), uint8(IAttestorVerifier.Rail.BOLETO));
        // While a PIX credit through the same endpoint still needs one.
        vm.expectRevert(abi.encodeWithSelector(ReclaimZkTlsVerifier.MissingField.selector, "txid"));
        v.verifyPayment(ORDER, abi.encode(_genuine()));
        vm.stopPrank();
    }

    /// Requiring the txid narrows what settles, so it is instant; dropping it widens, so it waits.
    function test_RequiringTheTxidIsInstantDroppingItWaits() public {
        vm.expectEmit(address(v));
        emit ReclaimZkTlsVerifier.EndpointOrderTxidSet(BANK_TEMPLATE, true);
        _requireTxid();
        assertTrue(v.endpointRequiresOrderTxid(BANK_TEMPLATE));

        vm.prank(governor);
        vm.expectRevert(
            abi.encodeWithSelector(DelayedGovernance.ChangeMustBeScheduled.selector, ReclaimZkTlsVerifier.setEndpointOrderTxid.selector)
        );
        v.setEndpointOrderTxid(BANK_TEMPLATE, false);

        _afterDelay(address(v), abi.encodeCall(ReclaimZkTlsVerifier.setEndpointOrderTxid, (BANK_TEMPLATE, false)));
        assertFalse(v.endpointRequiresOrderTxid(BANK_TEMPLATE));
        v.verifyPayment(ORDER, abi.encode(_genuine()));
    }

    function test_OnlyGovernorSetsTheTxidRequirement() public {
        vm.prank(address(0xBAD));
        vm.expectRevert(DelayedGovernance.NotGovernor.selector);
        v.setEndpointOrderTxid(BANK_TEMPLATE, true);
        vm.prank(governor);
        vm.expectRevert(ReclaimZkTlsVerifier.BadUrlPrefix.selector);
        v.setEndpointOrderTxid(bytes32(0), true);
    }

    /// Set before the endpoint exists and kept through a revocation: a re-allowed endpoint is never live without it.
    function test_TheTxidRequirementOutlivesTheEndpoint() public {
        bytes32 next = keccak256("template: api.bank.example pix received v2");
        vm.startPrank(governor);
        v.setEndpointOrderTxid(next, true);
        v.revokeEndpoint(BANK_TEMPLATE);
        v.setEndpointOrderTxid(BANK_TEMPLATE, true);
        vm.stopPrank();
        assertTrue(v.endpointRequiresOrderTxid(next), "settable before allowEndpoint");
        _afterDelay(address(v), abi.encodeCall(ReclaimZkTlsVerifier.allowEndpoint, (BANK_TEMPLATE, BANK_PREFIX)));
        assertTrue(v.endpointRequiresOrderTxid(BANK_TEMPLATE), "survives revocation");
        vm.prank(ESCROW);
        vm.expectRevert(abi.encodeWithSelector(ReclaimZkTlsVerifier.MissingField.selector, "txid"));
        v.verifyPayment(ORDER, abi.encode(_genuine()));
    }

    function testFuzz_OnlyTheOrdersOwnTxidSettles(bytes32 orderId, bytes32 other, uint8 len) public {
        vm.assume(orderId != other);
        _requireTxid();
        uint256 n = 25 + (uint256(len) % 11);
        vm.startPrank(ESCROW);
        v.verifyPayment(orderId, _proofWithTxid(orderId, _txid(orderId, n), _fields(1_500_000)));
        vm.expectRevert(ReclaimZkTlsVerifier.OrderTxidMismatch.selector);
        v.verifyPayment(orderId, _proofWithTxid(orderId, _txid(other, n), _fields(1_500_000)));
        vm.stopPrank();
    }

    /// The extracted object without its closing brace, to append members to.
    function _extractedWithoutBrace(Fields memory f) internal pure returns (string memory) {
        bytes memory ext = bytes(_extracted(f));
        bytes memory head = new bytes(ext.length - 1);
        for (uint256 i; i < head.length; ++i) {
            head[i] = ext[i];
        }
        return string(head);
    }

    function _lower(string memory s) internal pure returns (string memory) {
        bytes memory b = bytes(s);
        for (uint256 i; i < b.length; ++i) {
            if (b[i] >= "A" && b[i] <= "Z") b[i] = bytes1(uint8(b[i]) + 32);
        }
        return string(b);
    }
}
