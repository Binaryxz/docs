// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {ShieldedDepositLabel} from "../common/ShieldedDepositLabel.sol";
import {IShieldedPool, IShieldedEntrypoint} from "../yield/ShieldedYieldRouter.sol";

/**
 * @title ShieldedTransferRouter
 * @notice Moves value from one user's shielded note to another's without either address
 *         appearing on-chain (Rev. 2 Phase 4, shielded internal transfers).
 *
 * ## Why a withdrawal and a deposit
 *
 * Upstream Privacy Pools has no transfer circuit, and Rev. 2 rules out writing one. So the
 * sender proves a withdrawal with this router as `processooor`, and the router deposits the
 * proceeds back into the SAME pool under a precommitment that only the recipient can open.
 * On-chain it is one transaction by the router: a note is spent and a note appears, and
 * neither user signed anything that names them.
 *
 * The recipient supplies the precommitment in advance (a "receive ticket" off-chain). It is
 * `Poseidon(nullifier, secret)` for secrets derived from the recipient's own spending key, so
 * the sender - and this router - learn an image they cannot invert. Nobody but the recipient
 * can spend the result.
 *
 * ## What it costs, stated plainly
 *
 * The pool charges its vetting fee on the deposit side, so a transfer is not free. And the
 * withdrawn amount and the deposited amount are both public and differ only by fees, so the
 * two notes are publicly linked TO EACH OTHER. They are not linked to either user unless the
 * sender's note already was. A wallet should not transfer the exact amount of one of its own
 * public deposits.
 *
 * ## Why nobody can alter a transfer
 *
 * The recipient's precommitment, the relayer's fee, the deadline and the rescue recipient
 * all travel in `Withdrawal.data`, which the pool binds into the proof's context. A relayer
 * who swaps any of them changes the context, and the pool rejects the proof. That is what
 * lets anyone submit the transaction without being able to redirect it.
 *
 * ## The escape hatch
 *
 * This router is the depositor of record for every transferred note, so only it can
 * ragequit one. `rescue` gives that back to the recipient, routed by (pool, label) because
 * the pool tracks ragequit per label and a partial withdrawal leaves the remainder in a
 * successor with the same label - the bug that broke the Phase 2 escrow's hatch, not
 * repeated here. The payee is fixed in the proof at transfer time, so a published rescue
 * proof cannot be front-run.
 */
contract ShieldedTransferRouter is ReentrancyGuard {
    using SafeERC20 for IERC20;

    address internal constant NATIVE_ASSET = ShieldedDepositLabel.NATIVE_ASSET;

    /// @notice What a transfer does. ABI-encoded into `Withdrawal.data`, so bound by the proof.
    struct Transfer {
        /// The recipient's precommitment, from their receive ticket.
        uint256 precommitment;
        /// Who a rescue of the new note pays. Fixed now, because the proof is public later.
        address rescueRecipient;
        /// Paid `relayFee` of the pool asset for submitting the transaction.
        address relayer;
        uint256 relayFee;
        uint64 deadline;
    }

    IShieldedEntrypoint public immutable ENTRYPOINT;

    /// @notice pool => label => who a rescue pays.
    mapping(address => mapping(uint256 => address)) public rescueRecipient;

    event Transferred(address indexed pool, uint256 withdrawn, uint256 deposited, uint256 indexed label);
    event Rescued(address indexed pool, uint256 indexed label, address indexed recipient, uint256 amount);

    error ZeroAddress();
    error WrongProcessooor();
    error Expired();
    error UnknownPool();
    error FeeExceedsAmount();
    error UnknownDeposit();
    error NotRecipient();
    error TransferFailed();

    constructor(address entrypoint) {
        if (entrypoint == address(0)) revert ZeroAddress();
        ENTRYPOINT = IShieldedEntrypoint(entrypoint);
    }

    /**
     * @notice Execute a transfer proven by the sender. Callable by anyone, typically a relayer.
     * @param pool The pool the proof withdraws from, and the pool the recipient's note lands in.
     * @return commitment The recipient's new note.
     */
    function transfer(IShieldedPool pool, IShieldedPool.Withdrawal calldata w, IShieldedPool.WithdrawProof calldata p)
        external
        nonReentrant
        returns (uint256 commitment)
    {
        if (w.processooor != address(this)) revert WrongProcessooor();
        Transfer memory t = abi.decode(w.data, (Transfer));
        if (block.timestamp > t.deadline) revert Expired();
        if (t.rescueRecipient == address(0)) revert ZeroAddress();

        address asset = pool.ASSET();
        // slither-disable-next-line unused-return
        (address registered,,,) = ENTRYPOINT.assetConfig(asset);
        if (registered != address(pool)) revert UnknownPool();

        // Only what this withdrawal paid in is acted on, never a balance left over from before.
        uint256 before = _balance(asset);
        // slither-disable-next-line reentrancy-balance
        pool.withdraw(w, p);
        uint256 withdrawn = _balance(asset) - before;

        uint256 amount = withdrawn;
        if (t.relayFee > 0) {
            if (t.relayFee > amount) revert FeeExceedsAmount();
            if (t.relayer == address(0)) revert ZeroAddress();
            _send(asset, t.relayer, t.relayFee);
            amount -= t.relayFee;
        }

        if (asset == NATIVE_ASSET) {
            commitment = ENTRYPOINT.deposit{value: amount}(t.precommitment);
        } else {
            IERC20(asset).forceApprove(address(ENTRYPOINT), amount);
            commitment = ENTRYPOINT.deposit(IERC20(asset), amount, t.precommitment);
        }

        // The deposit just bumped the pool's nonce, so its last label is the recipient's note.
        uint256 label = ShieldedDepositLabel.lastLabel(address(pool));
        rescueRecipient[address(pool)][label] = t.rescueRecipient;
        emit Transferred(address(pool), withdrawn, amount, label);
    }

    /// @notice The proof context a client must prove for `data` against `pool`.
    function context(address pool, bytes calldata data) external view returns (uint256) {
        IShieldedPool.Withdrawal memory w = IShieldedPool.Withdrawal({processooor: address(this), data: data});
        return uint256(keccak256(abi.encode(w, IShieldedPool(pool).SCOPE())))
            % ShieldedDepositLabel.SNARK_SCALAR_FIELD;
    }

    /// @notice Encode a transfer for `Withdrawal.data`.
    function encodeTransfer(Transfer calldata t) external pure returns (bytes memory) {
        return abi.encode(t);
    }

    /**
     * @notice Ragequit a transferred note and pay the recipient fixed at transfer time.
     * @param pool The pool holding the note.
     * @param proof A ragequit proof for any unspent commitment in the note's lineage.
     */
    function rescue(IShieldedPool pool, IShieldedPool.RagequitProof calldata proof)
        external
        nonReentrant
        returns (uint256 amount)
    {
        uint256 label = proof.pubSignals[3];
        address recipient = rescueRecipient[address(pool)][label];
        if (recipient == address(0)) revert UnknownDeposit();
        if (msg.sender != recipient) revert NotRecipient();

        address asset = pool.ASSET();
        uint256 before = _balance(asset);
        // slither-disable-next-line reentrancy-balance
        pool.ragequit(proof);
        amount = _balance(asset) - before;
        if (amount > 0) _send(asset, recipient, amount);
        emit Rescued(address(pool), label, recipient, amount);
    }

    function _balance(address asset) internal view returns (uint256) {
        return asset == NATIVE_ASSET ? address(this).balance : IERC20(asset).balanceOf(address(this));
    }

    /// @dev `to` is never the caller's choice: it is the relayer or rescue recipient bound into
    ///      the sender's proof.
    function _send(address asset, address to, uint256 amount) internal {
        if (asset == NATIVE_ASSET) {
            // slither-disable-next-line arbitrary-send-eth,low-level-calls
            (bool ok,) = to.call{value: amount}("");
            if (!ok) revert TransferFailed();
        } else {
            IERC20(asset).safeTransfer(to, amount);
        }
    }

    /// @dev ETH arrives from the native pool on withdraw and ragequit. Every amount acted on is
    ///      a balance delta within one call, so stray ETH cannot fund someone else's transfer.
    receive() external payable {}
}
