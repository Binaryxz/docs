#!/usr/bin/env bash
# Etherscan source verification for the account stack on Sepolia (deployments/sepolia-account-stack.json).
# Built at commit 5290121c278d2e502c9725fb3c8fd0c44b31bd76; each creation's on-chain init code (after the Arachnid
# factory's 32-byte salt) matches that build byte for byte. Submitted through the Etherscan V2 API by
# scripts/etherscan-verify-v2.py, run from a checkout of that commit.
set -euo pipefail
: "${ETHERSCAN_API_KEY:?set ETHERSCAN_API_KEY}"
FORGE="${FORGE:-$(bash scripts/foundry.sh path)}"
# PasskeyCoSignerValidator: account stack
(cd packages/smart-account/contracts && "$FORGE" verify-contract 0x7Ecc6B0edF79CACC4DaB559830111cC1c8702990 src/PasskeyCoSignerValidator.sol:PasskeyCoSignerValidator --chain sepolia --compiler-version v0.8.28+commit.7893614a --num-of-optimizations 1000 --evm-version cancun --constructor-args 0x0000000000000000000000001d31f259ee307358a26dfb23eb365939e8641195 --etherscan-api-key "$ETHERSCAN_API_KEY" --watch)
# FrostValidator: account stack
(cd packages/smart-account/contracts && "$FORGE" verify-contract 0x58997113b2572F9Bc6ca243a0Ffff0C1924AB223 src/FrostValidator.sol:FrostValidator --chain sepolia --compiler-version v0.8.28+commit.7893614a --num-of-optimizations 1000 --evm-version cancun --etherscan-api-key "$ETHERSCAN_API_KEY" --watch)
# KernelAvatarAdapter: account stack
(cd packages/smart-account/contracts && "$FORGE" verify-contract 0x8214602c7991b48dEa1A5Cd58b06dCCF7840fAb0 src/KernelAvatarAdapter.sol:KernelAvatarAdapter --chain sepolia --compiler-version v0.8.28+commit.7893614a --num-of-optimizations 1000 --evm-version cancun --etherscan-api-key "$ETHERSCAN_API_KEY" --watch)
# OwnerlessPaymaster: account stack
"$FORGE" verify-contract 0x98a488006bB816a03930Edfec76Fda95a8ee069d contracts/OwnerlessPaymaster.sol:OwnerlessPaymaster --chain sepolia --compiler-version v0.8.28+commit.7893614a --num-of-optimizations 1000 --evm-version cancun --constructor-args 0x0000000000000000000000000000000071727de22e5e9d8baf0edac6f37da0320000000000000000000000004e1dcf7ad4e460cfd30791ccc4f9c8a4f820ec6776733d705f71b79841c0ee960a0ca880f779cde7ef446c989e6d23efc0a4adfb000000000000000000000000aac5d4240af87249b3f71bc8e4a2cae074a3e41985d96aa1c9a65886d094915d76ccae85f14027a02c1647dde659f869460f03e600000000000000000000000000000000000000000000000000000000000151800000000000000000000000000000000000000000000000000000000000000e10000000000000000000000000000000000000000000000000002386f26fc10000000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000470de4df82000000000000000000000000000000000000000000000000000002c68af0bb1400000000000000000000000000000000000000000000000000000000000000015180 --etherscan-api-key "$ETHERSCAN_API_KEY" --watch
# AuditGrantRegistry: account stack
"$FORGE" verify-contract 0x8BcCa7574d7A87Ea225DFB4ab1Ced6947e33414A contracts/AuditGrantRegistry.sol:AuditGrantRegistry --chain sepolia --compiler-version v0.8.28+commit.7893614a --num-of-optimizations 1000 --evm-version cancun --etherscan-api-key "$ETHERSCAN_API_KEY" --watch
# ShieldedNoteLog: account stack
"$FORGE" verify-contract 0x9eE65d4b3B55A545721138B814d1227e7DFdB1a5 contracts/ShieldedNoteLog.sol:ShieldedNoteLog --chain sepolia --compiler-version v0.8.28+commit.7893614a --num-of-optimizations 1000 --evm-version cancun --etherscan-api-key "$ETHERSCAN_API_KEY" --watch
