#!/usr/bin/env bash
# Etherscan source verification for the corrected FrostValidator on Sepolia (deployments/sepolia-account-stack-frost-v2.json).
# Built at audit-freeze-2026-10-20 (2e442a4): fixtures/mova/FrostValidator.json equals the smart-account build. Deployed
# through the Arachnid factory with salt 0. Submit with scripts/etherscan-verify-v2.py.
set -euo pipefail
: "${ETHERSCAN_API_KEY:?set ETHERSCAN_API_KEY}"
FORGE="${FORGE:-$(bash scripts/foundry.sh path)}"
# FrostValidator: account stack (SRM1-21: refuses a group key with x >= N)
(cd packages/smart-account/contracts && "$FORGE" verify-contract 0xBb6Bb2779FAd749F87342d7E471513272c901158 src/FrostValidator.sol:FrostValidator --chain sepolia --compiler-version v0.8.28+commit.7893614a --num-of-optimizations 1000 --evm-version cancun --etherscan-api-key "$ETHERSCAN_API_KEY" --watch)
