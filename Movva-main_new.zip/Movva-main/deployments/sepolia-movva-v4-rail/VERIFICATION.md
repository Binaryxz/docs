# Verification report: Movva rail on Sepolia (MOVVA only)

Generated 2026-10-21T21:04:03.419Z by `scripts/deploy-movva-rail.ts`. Everything below was read from the chain after the deployment, and every number in it comes from the deployment JSON and `deployments/sepolia-movva-v4-rail/privileges.json`.

## Summary

| | |
|---|---|
| Chain | Sepolia, chain id 11155111 |
| Commit | `d4eef51a21880b20a6dcf750ee0739c09397b9f9` on `phase-1-shielded-rail`, clean tree |
| Build hash | `b4b93cba59a75ffc2c373ac66c8267ccece39ffbe5039fc2d824feae0d4ae06c` |
| Deployer | `0x51d8E8E425c0431741246513F8A63Dd7d7c175Eb` |
| Contracts | 21 addresses, 21 distinct contracts, 21 running this build |
| Transactions | 61, 266,577,525 gas; blocks 11964251 to 11964910 |
| Checks | **332 pass, 8 expected, 0 fail** |
| Governance | finalized: every governor handed to `0x000000000000000000000000000000000000dEaD`, the reserve's guardian too, the Entrypoint's OWNER_ROLE renounced; ASP_POSTMAN held by the AspRootQuorum alone |
| **Test keys made permanent** | **18 role(s) that remain for ever are held by seed-derived test identities, or are the illustrative zkTLS templates** (`MOVVA_FINALIZE_ALLOW_TEST_KEYS=yes-this-is-a-rehearsal`). A demonstration only: see Substitutions |

> **Finalized with test keys (SRM1-1 opt-out, `MOVVA_FINALIZE_ALLOW_TEST_KEYS=yes-this-is-a-rehearsal`).** `--finalize` normally refuses while any role that outlives it is a test identity. This run was told to proceed anyway, so the following can never be replaced or revoked by anyone:

> - zkTLS witness 0x05EfF3D8e0ad59Aa8abFd94E0b08402ec0850Fbf: witness/0 (MOVVA_TEST_KEY_SEED)
> - zkTLS witness 0x8771D8B0038061D7872e4c2C69cD63F54380CBAb: witness/1 (MOVVA_TEST_KEY_SEED)
> - zkTLS witness 0x72C1a86B73Ca01Fec5e07160AE14a32849eE5214: witness/2 (MOVVA_TEST_KEY_SEED)
> - Movva FiatEscrow arbitrator 0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7: arbitrator (recorded test identity)
> - Movva OffRampEscrow arbitrator 0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7: arbitrator (recorded test identity)
> - registry LP 0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C: lp/0, the test LP and gateway (MOVVA_TEST_KEY_SEED)
> - reserve gateway 0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C: lp/0, the test LP and gateway (MOVVA_TEST_KEY_SEED)
> - reserve yield recipient 0x622F626F912AD25d36D9B8F48907Ac941F755ACb: treasury/0 (MOVVA_TEST_KEY_SEED)
> - FeeSplitter treasury 0x622F626F912AD25d36D9B8F48907Ac941F755ACb: treasury/0 (MOVVA_TEST_KEY_SEED)
> - AspRootQuorum ASP 0x6f239a1A5818808E63BB6F35A88B9876a79aa973: asp/0 (MOVVA_TEST_KEY_SEED)
> - AspRootQuorum ASP 0xc8510850c5bF41B52399473F234577B2d8Ef0B16: asp/1 (MOVVA_TEST_KEY_SEED)
> - AspRootQuorum ASP 0x323574Eb0c63b764F06832f15B21956bb8979FC9: asp/2 (MOVVA_TEST_KEY_SEED)
> - Entrypoint owner timelock proposer 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1: a 2-of-3 Safe whose owners custody/governor/signer/0 (MOVVA_TEST_KEY_SEED), custody/governor/signer/1 (MOVVA_TEST_KEY_SEED), custody/governor/signer/2 (MOVVA_TEST_KEY_SEED) are test keys
> - Entrypoint owner timelock executor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1: a 2-of-3 Safe whose owners custody/governor/signer/0 (MOVVA_TEST_KEY_SEED), custody/governor/signer/1 (MOVVA_TEST_KEY_SEED), custody/governor/signer/2 (MOVVA_TEST_KEY_SEED) are test keys
> - zkTLS endpoint 0xb54d2a19bba3a502dc449c083cd2579885618e4e0487435aae1673f06baf0c05: URL prefix https://api.banco-lp.example/ is on a reserved test domain (RFC 2606)
> - zkTLS endpoint 0xd8d90d629dc91348bf69c3c5148cd5bf1efdc99220a15a6f42d6ad42eeb2bb20: URL prefix https://api.banco-lp.example/ is on a reserved test domain (RFC 2606)
> - zkTLS endpoint 0x8259a0510dbf7425215eada80e9a8fcc1bac48d4e24e3cea67b5185b482abf77: URL prefix https://api.banco-lp.example/ is on a reserved test domain (RFC 2606)
> - zkTLS endpoint 0xf02c2badc915c0c690ccba5dd00202b6efcc3d49a1c1197db4026f075aaddc1a: URL prefix https://api.banco-lp.example/ is on a reserved test domain (RFC 2606)
>
> Whoever holds the test seed can forge payment proofs and rule disputes on this deployment for ever. It must never hold real value.

## Substitutions

What this deployment uses in place of the production component, as the deployment JSON records it:

- USDT: a stand-in TetherLike (contracts/test/ERC4626Adapter.t.sol) - 6 decimals and Tether's isBlackListed/pause/fee surface, but mint, pause and blacklist are open to anyone. Sepolia has no canonical USDT
- USDT/USD leg: Chainlink USDC/USD on Sepolia (0xA2F78ab2355fe2f984D808B5CeE7FD0A93D5270E, ~24h heartbeat), for the reserve
- custody (MOVVA_RAIL_CUSTODY=deployments/sepolia-movva-only-custody-rehearsal.json): the reserve's guardian and the escrows' only arbitrator are that record's 2-of-3 Safes from setup (its hedge-treasury Safe is recorded as the sleeve's treasury, not a reserve role), whose signers are test keys derived from the seed; witnesses, the institutional LP / Movva gateway and the treasury: test keys derived from the seed
- reserve yield recipient: the treasury 0x622F626F912AD25d36D9B8F48907Ac941F755ACb, a test key derived from the seed (MOVVA_RAIL_YIELD_RECIPIENT unset). The client rule of 21 October 2026 makes it Mova's Safe; harvestYield pays it, and only it, the yield above max(principal, liabilities at the target)
- ASPs: the AspRootQuorum's three ASPs are test keys derived from the seed (asp/0 stands for Movva; asp/1 and asp/2 for the two independent ASPs the client has yet to confirm)
- governor Safe: a 2-of-3 Safe 1.4.1 whose signers are test keys derived from the seed (movva-rail/<seed>/custody/governor/signer/0..2); it governs every DelayedGovernance contract from setup and drives the Entrypoint owner timelock
- Scope (client decisions, 14 October 2026): MOVVA only. No savings (D1: the code has no sMovva, no sMovva pool and no `distribute`; the reserve's surplus stays in it), no ETH/USDT ramp pair and no ETH or USDT band oracle. The ETH pool is upstream's, deployed by its protocol script; the product does not use it, and the owner step winds it down and removes it (M-18)
- zkTLS endpoints: the four illustrative receipt templates of packages/ramp receiptTemplates(prefix), not a real bank's
- Privacy Pools: a fresh upstream stack owned by the deployer until the owner step, not Mova's 8 September Entrypoint (its OWNER_ROLE key is not on this machine)
- Divergence breaker: none (MOVVA_BREAKER=off). Sepolia has no BRL/USD Chainlink feed or BRL stablecoin pool to read as a second price source, so this run deploys the reserve without one; the breaker is proven by its tests, not by this deployment
- FINALIZED WITH TEST KEYS (MOVVA_FINALIZE_ALLOW_TEST_KEYS=yes-this-is-a-rehearsal, SRM1-1 opt-out): the roles that remain for ever are held by seed-derived test identities, or are packages/ramp's illustrative zkTLS templates, and nobody can ever replace them - zkTLS witness 0x05EfF3D8e0ad59Aa8abFd94E0b08402ec0850Fbf: witness/0 (MOVVA_TEST_KEY_SEED); zkTLS witness 0x8771D8B0038061D7872e4c2C69cD63F54380CBAb: witness/1 (MOVVA_TEST_KEY_SEED); zkTLS witness 0x72C1a86B73Ca01Fec5e07160AE14a32849eE5214: witness/2 (MOVVA_TEST_KEY_SEED); Movva FiatEscrow arbitrator 0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7: arbitrator (recorded test identity); Movva OffRampEscrow arbitrator 0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7: arbitrator (recorded test identity); registry LP 0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C: lp/0, the test LP and gateway (MOVVA_TEST_KEY_SEED); reserve gateway 0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C: lp/0, the test LP and gateway (MOVVA_TEST_KEY_SEED); reserve yield recipient 0x622F626F912AD25d36D9B8F48907Ac941F755ACb: treasury/0 (MOVVA_TEST_KEY_SEED); FeeSplitter treasury 0x622F626F912AD25d36D9B8F48907Ac941F755ACb: treasury/0 (MOVVA_TEST_KEY_SEED); AspRootQuorum ASP 0x6f239a1A5818808E63BB6F35A88B9876a79aa973: asp/0 (MOVVA_TEST_KEY_SEED); AspRootQuorum ASP 0xc8510850c5bF41B52399473F234577B2d8Ef0B16: asp/1 (MOVVA_TEST_KEY_SEED); AspRootQuorum ASP 0x323574Eb0c63b764F06832f15B21956bb8979FC9: asp/2 (MOVVA_TEST_KEY_SEED); Entrypoint owner timelock proposer 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1: a 2-of-3 Safe whose owners custody/governor/signer/0 (MOVVA_TEST_KEY_SEED), custody/governor/signer/1 (MOVVA_TEST_KEY_SEED), custody/governor/signer/2 (MOVVA_TEST_KEY_SEED) are test keys; Entrypoint owner timelock executor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1: a 2-of-3 Safe whose owners custody/governor/signer/0 (MOVVA_TEST_KEY_SEED), custody/governor/signer/1 (MOVVA_TEST_KEY_SEED), custody/governor/signer/2 (MOVVA_TEST_KEY_SEED) are test keys; zkTLS endpoint 0xb54d2a19bba3a502dc449c083cd2579885618e4e0487435aae1673f06baf0c05: URL prefix https://api.banco-lp.example/ is on a reserved test domain (RFC 2606); zkTLS endpoint 0xd8d90d629dc91348bf69c3c5148cd5bf1efdc99220a15a6f42d6ad42eeb2bb20: URL prefix https://api.banco-lp.example/ is on a reserved test domain (RFC 2606); zkTLS endpoint 0x8259a0510dbf7425215eada80e9a8fcc1bac48d4e24e3cea67b5185b482abf77: URL prefix https://api.banco-lp.example/ is on a reserved test domain (RFC 2606); zkTLS endpoint 0xf02c2badc915c0c690ccba5dd00202b6efcc3d49a1c1197db4026f075aaddc1a: URL prefix https://api.banco-lp.example/ is on a reserved test domain (RFC 2606). A rehearsal or testnet demonstration only: whoever holds the test seed can forge payment proofs and rule disputes on it for ever

## What was deployed, and where

| Contract | Address | Source | Source sha256 | Runtime sha256 (build) | On chain |
|---|---|---|---|---|---|
| Privacy Pools Entrypoint (proxy) | `0x81d45264fbC3E1cD303891bb8f4ae9EA2DEB2CcC` | `node_modules/@openzeppelin/contracts/proxy/ERC1967/ERC1967Proxy.sol` | `03cdbd59c384fe18`… | `f1f38be5dd06d358`… | identical |
| Entrypoint implementation | `0xa39fBfb71D89Dde0d75AD23334613EFd695fAadb` | `protocol/contracts/src/contracts/Entrypoint.sol` | `8245c32d50ae6582`… | `6408ed2ab26661a7`… | identical outside immutables |
| Withdrawal Groth16 verifier | `0xA9c58610Dae19933b6B21c677D472945DE695446` | `protocol/contracts/src/contracts/verifiers/WithdrawalVerifier.sol` | `7b6991befbc9a94a`… | `77bfc587acc64f36`… | identical |
| Ragequit (commitment) Groth16 verifier | `0x7165F26B50A5901a02f4D661507545f2fb94F91C` | `protocol/contracts/src/contracts/verifiers/CommitmentVerifier.sol` | `de24f75d21d651c0`… | `ebae2d48b14ac64f`… | identical |
| ETH Privacy Pool (upstream's; unused by the product) | `0x8e730dF009Bdfa5A685d9b8Cde84449F94d7b12d` | `protocol/contracts/src/contracts/implementations/PrivacyPoolSimple.sol` | `f0d97040fd5bd00d`… | `92fdf5ae69da7a5d`… | identical outside immutables |
| PoseidonT3 library (pre-existing) | `0x8ffdA7Ed8B4aD98C2C34f54B76821711F4a6f2C5` | `node_modules/poseidon-solidity/PoseidonT3.sol` | `08a7493be3783816`… | `23a48ae4bae13d19`… | identical |
| PoseidonT4 library (pre-existing) | `0xe393dd7287Db9982e6f845824854Baf8b8e823AF` | `node_modules/poseidon-solidity/PoseidonT4.sol` | `289e22a19a20bcec`… | `e2f5e98664dbafbe`… | identical |
| Stand-in USDT (TetherLike) | `0xCDf4eCDa722285d3f5D24c791EC5506D718424a0` | `contracts/test/ERC4626Adapter.t.sol` | `ac9bee3e80a850f4`… | `c4def54d8f2056a8`… | identical |
| MovvaReserve | `0xa357968D9beC2b3Cc9057c4aF37431780D91287a` | `contracts/movva/MovvaReserve.sol` | `37f9fc245f919d8a`… | `c270a64bae72fd5f`… | identical outside immutables |
| Movva (token) | `0xdDb321e26e4e77432fA3E160431f25cCB4700Fa2` | `contracts/movva/Movva.sol` | `abe9ea0c2812eb1d`… | `18f3d0777c02361a`… | identical outside immutables |
| Movva FX leg (PythFxOracle) | `0x90474f2B222d0E0a8dfC4c4F138b041B1921F18F` | `contracts/ramp/PythFxOracle.sol` | `c5379bb7abb161ea`… | `d45cc28a7d80c55a`… | identical outside immutables |
| Movva band adapter (ScaledFxBandOracle) | `0xaC4c0Fe25ed07B446f8377A97f4aA175020d2B13` | `contracts/movva/ScaledFxBandOracle.sol` | `ddd60c94d0d23dab`… | `29eef9b7be2f7574`… | identical outside immutables |
| FeeSplitter | `0xB81615658A4a51b4d3c2e144d492794Beb001099` | `contracts/movva/FeeSplitter.sol` | `b1b0eaf84b158a40`… | `18eadbf70af9fe51`… | identical outside immutables |
| NodeRewards | `0xe446ceA7089704e5cC746edf97F9eedeA4851FF0` | `contracts/ramp/NodeRewards.sol` | `0c37db72b176a0a4`… | `850bf2870800a15c`… | identical outside immutables |
| Movva Privacy Pool | `0x3ac4EE315D13e9a4243954852917eAf69232a6f3` | `protocol/contracts/src/contracts/implementations/PrivacyPoolComplex.sol` | `0f9c34f0bfd03a35`… | `d1e5735be46a6b62`… | identical outside immutables |
| Entrypoint owner (TimelockController, 7 days) | `0xeE518057F6fe17385D67c8659abc77Ac5a601ed7` | `contracts/governance/EntrypointTimelock.sol` | `7dc3b06555a5221c`… | `2223a8d3ec55b092`… | identical |
| AspRootQuorum (ASP postman, 2 of 3) | `0xa897FB804917715A0220339640D5e55B59b85339` | `contracts/AspRootQuorum.sol` | `c3302c2b2d6f11e4`… | `b84a2e177df7b2a6`… | identical outside immutables |
| LPRegistry | `0x8a31C07b24d83908c11BE0a81ABFA465454d0344` | `contracts/ramp/LPRegistry.sol` | `e3b84eb7ba5327fd`… | `10f6e8c2bdce1ef1`… | identical outside immutables |
| ReclaimZkTlsVerifier (PIX, boleto, TED) | `0x84ae5FFC1F84b19498cE5a376200709b4df55508` | `contracts/ramp/ReclaimZkTlsVerifier.sol` | `dd23ae989f1c5ad3`… | `238ac12364f5066c`… | identical outside immutables |
| FiatEscrow (Movva on-ramp) | `0x3e79B0582b8EAb2FDEcFf0c9da43143e3915eB14` | `contracts/ramp/FiatEscrow.sol` | `6624254e1f70665e`… | `125722a97053b212`… | identical outside immutables |
| OffRampEscrow (Movva off-ramp) | `0xCCdA1AA24d45Bc673b090F80363aC38D50D0d81C` | `contracts/ramp/OffRampEscrow.sol` | `e42299b4e00de3cd`… | `2596e84c30440320`… | identical outside immutables |

Full hashes, artifacts and constructor arguments are in the deployment JSON under `record.contracts`. ABIs: `deployments/sepolia-movva-v4-rail/abi/` (21 files; the Entrypoint proxy's callable ABI is `Entrypoint.json`).

## Build

**Build hash `b4b93cba59a75ffc2c373ac66c8267ccece39ffbe5039fc2d824feae0d4ae06c`**: sha256 over the concatenated runtime bytecode (artifact deployedBytecode, library placeholders as 20 zero bytes, immutables as compiled) of every distinct deployed contract, sorted by its hex. Recompute it from a checkout of the commit with `npx tsx scripts/deployment-record.ts build-hash <deployment.json>` after `forge build` in the repo root and in `protocol/contracts`.

| Contract | Build | Runtime bytes | Runtime sha256 |
|---|---|---:|---|
| AspRootQuorum | root | 2,691 | `b84a2e177df7b2a6efe5726f408f6278977a4b2ed198fbe5eb69f5f6025bf6b4` |
| CommitmentVerifier | protocol | 1,582 | `ebae2d48b14ac64f45fd3df64ea84a60145ec212916915548cf93a7651b80f23` |
| Entrypoint | protocol | 13,490 | `6408ed2ab26661a75035495c8676b15f9f44321fcf9b611a811efb3c82be7395` |
| EntrypointTimelock | root | 7,143 | `2223a8d3ec55b0925ea6995ef2411df618db27317959330126024e1c7f59c814` |
| ERC1967Proxy | protocol | 122 | `f1f38be5dd06d358ef10a9010c1b52388094c454ae2b594351c124196c631df2` |
| FeeSplitter | root | 5,333 | `18eadbf70af9fe5116972c4dae156f51ca2bb9026b627d8a2e22f5f547339a78` |
| FiatEscrow | root | 24,563 | `125722a97053b21275ea0d4bf8f97118a9e7742259d90f2bf656740b7b4ee1be` |
| LPRegistry | root | 10,366 | `10f6e8c2bdce1ef1216269f4d102eda3c1f21d830fa2efa09410c39f335fc9ae` |
| Movva | root | 4,516 | `18f3d0777c02361a2824fa09b856fbd3b69d603202599ccf8fd5aa015f0c7425` |
| MovvaReserve | root | 19,045 | `c270a64bae72fd5f49a2ca8d72b97e33b35c27c77a0cf0396df1c02fdb6a03f2` |
| NodeRewards | root | 10,116 | `850bf2870800a15c24e28347d24e86c594e66c8f069f924284dbc83a5db6efcd` |
| OffRampEscrow | root | 19,918 | `2596e84c30440320913bef7deb060900e47ee11c74c7345ec659c2ccbce8457a` |
| PoseidonT3 | protocol | 23,522 | `23a48ae4bae13d19ecdb8321c33ae70c31bd5b1c37972bc673f2d073b6026fb6` |
| PoseidonT4 | protocol | 12,584 | `e2f5e98664dbafbeb3b29dfaf490adad71c401b9fa5076c9e0b1efd853d59071` |
| PrivacyPoolComplex | protocol | 7,720 | `d1e5735be46a6b62a4e7e72e1372455087813ac08eec4f1d9880b4d23e185216` |
| PrivacyPoolSimple | protocol | 7,378 | `92fdf5ae69da7a5d9a6beaa4074806c821cbabc887dfecee95576c93e4b1c57a` |
| PythFxOracle | root | 6,269 | `d45cc28a7d80c55a3bd491a7b2fa6a202158bdf480f87b998de4ff65b62e1d34` |
| ReclaimZkTlsVerifier | root | 16,278 | `238ac12364f5066c03d49f2ebc573617efd9911177b4c144ce6f86e4e16a51f4` |
| ScaledFxBandOracle | root | 770 | `29eef9b7be2f757447a6acaf5533270f9013c322761574801b0c83a2246672c5` |
| TetherLike | root | 2,317 | `c4def54d8f2056a8f4dd87432da5e7edebd9af892d284bf4e53f60e4681d1e01` |
| WithdrawalVerifier | protocol | 1,947 | `77bfc587acc64f361df684b77293f84073e4894b61bd870fc078510562fb7bb8` |

| Build | Config | Compiler | Optimizer | EVM | viaIR | Metadata hash |
|---|---|---|---|---|---|---|
| protocol | `protocol/contracts/foundry.toml` | 0.8.28+commit.7893614a (sha256 9a0fb7e0db2c0641…) | on, 10000 runs | cancun | false | none (no CBOR) |
| root | `foundry.toml` | 0.8.28+commit.7893614a (sha256 9a0fb7e0db2c0641…) | on, 1000 runs | cancun | false | ipfs |

Forge: `forge 0.3.0 (5a8bd89 2024-12-19T17:17:10.245193696Z)`. Sources: 117 files compiled into the deployed contracts, every one identical on disk to the keccak256 its build recorded.

## Checks

Every check the verification pass ran, grouped: 332 pass, 8 expected, 0 fail. "Expected" is only ever a price refusal the check predicted exactly (see Prices).

### Code at every address (22 pass)

<details><summary>22 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | code at protocol.entrypoint | 0x81d45264fbC3E1cD303891bb8f4ae9EA2DEB2CcC |
| pass | code at protocol.entrypointImplementation | 0xa39fBfb71D89Dde0d75AD23334613EFd695fAadb |
| pass | code at protocol.withdrawalVerifier | 0xA9c58610Dae19933b6B21c677D472945DE695446 |
| pass | code at protocol.commitmentVerifier | 0x7165F26B50A5901a02f4D661507545f2fb94F91C |
| pass | code at protocol.ethPool | 0x8e730dF009Bdfa5A685d9b8Cde84449F94d7b12d |
| pass | code at protocol.poseidonT3 | 0x8ffdA7Ed8B4aD98C2C34f54B76821711F4a6f2C5 |
| pass | code at protocol.poseidonT4 | 0xe393dd7287Db9982e6f845824854Baf8b8e823AF |
| pass | code at standInUsdt | 0xCDf4eCDa722285d3f5D24c791EC5506D718424a0 |
| pass | code at movva.reserve | 0xa357968D9beC2b3Cc9057c4aF37431780D91287a |
| pass | code at movva.token | 0xdDb321e26e4e77432fA3E160431f25cCB4700Fa2 |
| pass | code at movva.fxLeg | 0x90474f2B222d0E0a8dfC4c4F138b041B1921F18F |
| pass | code at movva.bandAdapter | 0xaC4c0Fe25ed07B446f8377A97f4aA175020d2B13 |
| pass | code at movva.feeSplitter | 0xB81615658A4a51b4d3c2e144d492794Beb001099 |
| pass | code at movva.nodeRewards | 0xe446ceA7089704e5cC746edf97F9eedeA4851FF0 |
| pass | code at pools.movva | 0x3ac4EE315D13e9a4243954852917eAf69232a6f3 |
| pass | code at asp.quorum | 0xa897FB804917715A0220339640D5e55B59b85339 |
| pass | code at ramp.registry | 0x8a31C07b24d83908c11BE0a81ABFA465454d0344 |
| pass | code at ramp.zktls | 0x84ae5FFC1F84b19498cE5a376200709b4df55508 |
| pass | code at ramp.movvaOnramp | 0x3e79B0582b8EAb2FDEcFf0c9da43143e3915eB14 |
| pass | code at ramp.movvaOfframp | 0xCCdA1AA24d45Bc673b090F80363aC38D50D0d81C |
| pass | code at ownership.timelock | 0xeE518057F6fe17385D67c8659abc77Ac5a601ed7 |
| pass | code at ownership.safe | 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |

</details>

### Governance: governor, setup, delay (32 pass)

<details><summary>32 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | MovvaReserve governor (renounced) | 0x000000000000000000000000000000000000dEaD |
| pass | MovvaReserve setupComplete | true |
| pass | MovvaReserve pendingChanges (nothing queued) | 0 |
| pass | MovvaReserve GOVERNANCE_DELAY | 172800 |
| pass | Movva FX leg (PythFxOracle) governor (renounced) | 0x000000000000000000000000000000000000dEaD |
| pass | Movva FX leg (PythFxOracle) setupComplete | true |
| pass | Movva FX leg (PythFxOracle) pendingChanges (nothing queued) | 0 |
| pass | Movva FX leg (PythFxOracle) GOVERNANCE_DELAY | 172800 |
| pass | FeeSplitter governor (renounced) | 0x000000000000000000000000000000000000dEaD |
| pass | FeeSplitter setupComplete | true |
| pass | FeeSplitter pendingChanges (nothing queued) | 0 |
| pass | FeeSplitter GOVERNANCE_DELAY | 172800 |
| pass | NodeRewards governor (renounced) | 0x000000000000000000000000000000000000dEaD |
| pass | NodeRewards setupComplete | true |
| pass | NodeRewards pendingChanges (nothing queued) | 0 |
| pass | NodeRewards GOVERNANCE_DELAY | 172800 |
| pass | LPRegistry governor (renounced) | 0x000000000000000000000000000000000000dEaD |
| pass | LPRegistry setupComplete | true |
| pass | LPRegistry pendingChanges (nothing queued) | 0 |
| pass | LPRegistry GOVERNANCE_DELAY | 172800 |
| pass | ReclaimZkTlsVerifier governor (renounced) | 0x000000000000000000000000000000000000dEaD |
| pass | ReclaimZkTlsVerifier setupComplete | true |
| pass | ReclaimZkTlsVerifier pendingChanges (nothing queued) | 0 |
| pass | ReclaimZkTlsVerifier GOVERNANCE_DELAY | 172800 |
| pass | Movva FiatEscrow governor (renounced) | 0x000000000000000000000000000000000000dEaD |
| pass | Movva FiatEscrow setupComplete | true |
| pass | Movva FiatEscrow pendingChanges (nothing queued) | 0 |
| pass | Movva FiatEscrow GOVERNANCE_DELAY | 172800 |
| pass | Movva OffRampEscrow governor (renounced) | 0x000000000000000000000000000000000000dEaD |
| pass | Movva OffRampEscrow setupComplete | true |
| pass | Movva OffRampEscrow pendingChanges (nothing queued) | 0 |
| pass | Movva OffRampEscrow GOVERNANCE_DELAY | 172800 |

</details>

### owner (6 pass)

<details><summary>6 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | Entrypoint OWNER_ROLE held by the TimelockController (H-02) | true |
| pass | Entrypoint OWNER_ROLE: the deployer renounced it | false |
| pass | Entrypoint DEFAULT_ADMIN_ROLE: not the deployer | false |
| pass | Entrypoint: the TimelockController is the only OWNER_ROLE holder and the deployer holds no role (every RoleGranted account re-checked) | OWNER_ROLE 0xeE518057F6fe17385D67c8659abc77Ac5a601ed7 |
| pass | TimelockController getMinDelay (7 days) | 604800 |
| pass | TimelockController: the Safe 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 alone proposes, cancels and executes; executor not open; it administers itself | PROPOSER, CANCELLER, EXECUTOR: the Safe; DEFAULT_ADMIN: the timelock |

</details>

### Privacy Pools: Entrypoint roles and pools (7 pass)

<details><summary>7 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | Entrypoint: upstream's ETH pool removed (M-18) | 0x0000000000000000000000000000000000000000 |
| pass | upstream's ETH pool wound down (dead) | true |
| pass | Entrypoint holds no MOVVA fees | 0 units |
| pass | Entrypoint holds no ETH | 0 wei |
| pass | Entrypoint Movva pool (as the clean-up set it) | 0x3ac4EE315D13e9a4243954852917eAf69232a6f3,1000000000000000000,10,100 |
| pass | Movva pool ENTRYPOINT | 0x81d45264fbC3E1cD303891bb8f4ae9EA2DEB2CcC |
| pass | Movva pool ASSET | 0xdDb321e26e4e77432fA3E160431f25cCB4700Fa2 |

</details>

### ASP postman: the AspRootQuorum (12 pass)

<details><summary>12 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | AspRootQuorum ENTRYPOINT | 0x81d45264fbC3E1cD303891bb8f4ae9EA2DEB2CcC |
| pass | AspRootQuorum THRESHOLD | 2 |
| pass | AspRootQuorum ASP_COUNT | 3 |
| pass | AspRootQuorum asps() are the recorded ASPs, in order | 0x6f239a1A5818808E63BB6F35A88B9876a79aa973,0xc8510850c5bF41B52399473F234577B2d8Ef0B16,0x323574Eb0c63b764F06832f15B21956bb8979FC9 |
| pass | the recorded ASPs are the seed's asp/0..2 (asp/0 = Movva; asp/1, asp/2 stand-ins) | 0x6f239a1A5818808E63BB6F35A88B9876a79aa973,0xc8510850c5bF41B52399473F234577B2d8Ef0B16,0x323574Eb0c63b764F06832f15B21956bb8979FC9 |
| pass | AspRootQuorum isAsp(asp/0) | true |
| pass | AspRootQuorum isAsp(asp/1) | true |
| pass | AspRootQuorum isAsp(asp/2) | true |
| pass | AspRootQuorum isAsp(deployer) is false | false |
| pass | Entrypoint ASP_POSTMAN held by the AspRootQuorum | true |
| pass | Entrypoint ASP_POSTMAN revoked from the deployer | false |
| pass | Entrypoint ASP_POSTMAN held by the quorum only (every RoleGranted account re-checked) | 0xa897FB804917715A0220339640D5e55B59b85339 |

</details>

### Movva: reserve, FX leg, fees, rewards (45 pass)

<details><summary>45 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | reserve MOVVA | 0xdDb321e26e4e77432fA3E160431f25cCB4700Fa2 |
| pass | token RESERVE | 0xa357968D9beC2b3Cc9057c4aF37431780D91287a |
| pass | reserve USDT (stand-in) | 0xCDf4eCDa722285d3f5D24c791EC5506D718424a0 |
| pass | reserve USDT/USD feed (Chainlink USDC/USD) | 0xA2F78ab2355fe2f984D808B5CeE7FD0A93D5270E |
| pass | reserve FX oracle | 0x90474f2B222d0E0a8dfC4c4F138b041B1921F18F |
| pass | reserve has no distribute() (D1: no savings path) | reverts with no data; selector not in the code |
| pass | reserve has no previewDistribute() (D1: no savings path) | reverts with no data; selector not in the code |
| pass | reserve has no savings() (D1: no savings path) | reverts with no data; selector not in the code |
| pass | reserve has no distributionFeeBps() (D1: no savings path) | reverts with no data; selector not in the code |
| pass | reserve has no withdrawToHedge(uint256) (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no queueHedgeWithdrawal(uint256) (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no executeHedgeWithdrawal(uint256) (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no hedgeWithdrawable() (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no hedgeLimitBps() (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no hedgeUsed() (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no hedgeUsedAt() (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no hedgeRequests(uint256) (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no hedgeRequestCount() (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no HEDGE_QUEUE_DELAY() (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no minWithdrawCollateralRatioBps() (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no treasurer() (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no hedgeTreasury() (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no setTreasurer(address) (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no setHedgeTreasury(address) (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no setLimits(uint256,uint16) (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no sweep(address) (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve has no rescue(address,address,uint256) (principal-locked: no hedge or sweep path) | reverts with no data; selector not in the code |
| pass | reserve yield recipient (principal-locked: the only payee of harvestYield) | 0x622F626F912AD25d36D9B8F48907Ac941F755ACb |
| pass | reserve principalUsdt (the cost basis: mint + recapitalize - redeem) | 0 with a supply of 0 |
| pass | reserve setYieldRecipient from the governor must be scheduled (delayed both ways) | ChangeMustBeScheduled |
| pass | reserve guardian (renounced) | 0x000000000000000000000000000000000000dEaD |
| pass | reserve mintPaused | false |
| pass | reserve fee recipient is the FeeSplitter | 0xB81615658A4a51b4d3c2e144d492794Beb001099 |
| pass | reserve fees (mint, redeem bps) | 10,10 |
| pass | reserve supply cap | 1000000000000000000000000 |
| pass | reserve gateway (the off-ramp's redeemer): test LP 0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C | true |
| pass | reserve gateway (the off-ramp's redeemer): institutional LP 0xf491FA29debC0D12d8F7c57B17995C2346F025AD | true |
| pass | Movva FX leg PYTH | 0xDd24F84d36BF92C65F92307595335bdFab5Bbd21 |
| pass | Movva FX leg usdBrlId | 0xd2db4dbf1aea74e0f666b0e8f73b9580d407f5e5cf931940b06dc633d7a95906 |
| pass | Movva FX leg maxAge / closedMaxAge / maxConfBps | 3600,345600,100 |
| pass | Movva band adapter SOURCE | 0x90474f2B222d0E0a8dfC4c4F138b041B1921F18F |
| pass | FeeSplitter rewards | 0xe446ceA7089704e5cC746edf97F9eedeA4851FF0 |
| pass | FeeSplitter treasury | 0x622F626F912AD25d36D9B8F48907Ac941F755ACb |
| pass | NodeRewards REWARD_TOKEN | 0xdDb321e26e4e77432fA3E160431f25cCB4700Fa2 |
| pass | NodeRewards bound to the registry | 0x8a31C07b24d83908c11BE0a81ABFA465454d0344 |

</details>

### Ramp wiring: registry, escrows, oracles (26 pass)

<details><summary>26 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | registry phase (0 = A) | 0 |
| pass | registry rewards hook | 0xe446ceA7089704e5cC746edf97F9eedeA4851FF0 |
| pass | registry accepts Movva FiatEscrow | true |
| pass | Movva FiatEscrow allows the zkTLS verifier | true |
| pass | Movva FiatEscrow arbitrator | true |
| pass | Movva FiatEscrow dispute timeout | 2592000 |
| pass | registry accepts Movva OffRampEscrow | true |
| pass | Movva OffRampEscrow allows the zkTLS verifier | true |
| pass | Movva OffRampEscrow arbitrator | true |
| pass | Movva OffRampEscrow dispute timeout | 2592000 |
| pass | registry: test LP is INSTITUTIONAL with its credit | tier 3, 5000000 centavos |
| pass | registry: extra LP 0xf491FA29debC0D12d8F7c57B17995C2346F025AD is INSTITUTIONAL with its credit | tier 3, 5000000 centavos |
| pass | Movva FiatEscrow TAKER_DISPUTE_TIMEOUT | 432000 |
| pass | Movva FiatEscrow MAX_VETTING_FEE_BPS | 10 |
| pass | Movva FiatEscrow MAX_VETTING_FEE_BPS covers the Movva pool's vetting fee | true |
| pass | Movva FiatEscrow Entrypoint / Movva pool | 0x81d45264fbC3E1cD303891bb8f4ae9EA2DEB2CcC,0x3ac4EE315D13e9a4243954852917eAf69232a6f3 |
| pass | Movva FiatEscrow BAND_BPS | 300 |
| pass | Movva FiatEscrow lists Movva (reserve, 18, enabled) | 0xa357968D9beC2b3Cc9057c4aF37431780D91287a,18,true |
| pass | Movva FiatEscrow native ETH delisted | false |
| pass | Movva FiatEscrow stand-in USDT not listed | false |
| pass | Movva FiatEscrow ORACLE (constructor; seeds only the delisted native-ETH entry) | 0xa357968D9beC2b3Cc9057c4aF37431780D91287a |
| pass | Movva OffRampEscrow BAND_BPS | 300 |
| pass | Movva OffRampEscrow lists Movva (reserve, 18, enabled) | 0xa357968D9beC2b3Cc9057c4aF37431780D91287a,18,true |
| pass | Movva OffRampEscrow native ETH delisted | false |
| pass | Movva OffRampEscrow stand-in USDT not listed | false |
| pass | Movva OffRampEscrow ORACLE (constructor; seeds only the delisted native-ETH entry) | 0xa357968D9beC2b3Cc9057c4aF37431780D91287a |

</details>

### Verifiers: who proves what (7 pass)

<details><summary>7 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | ReclaimZkTlsVerifier provesBankSession | true |
| pass | zktls witnesses + threshold | true |
| pass | zktls endpointCount | 4 |
| pass | zktls endpoint pix-received (rails, prefix) | 2,https://api.banco-lp.example/ |
| pass | zktls endpoint pix-sent (rails, prefix) | 2,https://api.banco-lp.example/ |
| pass | zktls endpoint boleto-received (rails, prefix) | 4,https://api.banco-lp.example/ |
| pass | zktls endpoint boleto-paid (rails, prefix) | 4,https://api.banco-lp.example/ |

</details>

### Prices: Chainlink freshness and the Pyth leg (1 pass, 8 expected)

<details><summary>9 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | Chainlink USDC/USD fresh for its max age | 99985000 (8 dp), 38496 s old, max 90000 |
| expected | Pyth FX.USD/BRL on Sepolia | publishTime 1792529999, 86029 s old at block 11964915; core session open |
| expected | Movva FX leg brlCentsPerUnit (the rate) | StaleRate(1792529999) - Pyth's FX.USD/BRL is stale |
| expected | Movva FX leg brlCentsPerUnitForBand | StaleRate(1792529999) - Pyth's FX.USD/BRL is stale |
| expected | Movva band adapter brlCentsPerUnit | StaleRate(1792529999) - Pyth's FX.USD/BRL is stale |
| expected | reserve brlPerUsdtE18 (mint/redeem rate) | StaleRate(1792529999) - Pyth's FX.USD/BRL is stale |
| expected | reserve bandBrlPerUsdtE18 (Movva band) | StaleRate(1792529999) - Pyth's FX.USD/BRL is stale |
| expected | reserve brlCentsPerUnit (the Movva pair's band) | StaleRate(1792529999) - Pyth's FX.USD/BRL is stale |
| expected | reserve harvestableYield (the yield above max(principal, target)) | StaleRate(1792529999) - Pyth's FX.USD/BRL is stale |

</details>

### Bytecode: each address runs this commit's build (42 pass)

<details><summary>42 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | every source file the deployed contracts were compiled from is the file on disk (keccak256 in the build metadata) | 117 files |
| pass | the commit is clean for every build input | d4eef51a21880b20a6dcf750ee0739c09397b9f9, tree clean |
| pass | no build input changed during the run | HEAD moved from d4eef51a21880b20a6dcf750ee0739c09397b9f9 to 257b21b1b5cbde6853dfa3563974220df413e9a4; the 33 file(s) that differ (deployments/sepolia-movva-v4-permissionless.json, deployments/sepolia-movva-v4-permissionless.rehearsal.json, deployments/sepolia-movva-v4-permissionless/etherscan-verify.sh, deployments/sepolia-movva-v4-rail.json, deployments/sepolia-movva-v4-rail/VERIFICATION.md, depl |
| pass | Privacy Pools Entrypoint (proxy) runs the build's ERC1967Proxy | 0x81d45264fbC3E1cD303891bb8f4ae9EA2DEB2CcC: 122 bytes, identical |
| pass | Privacy Pools Entrypoint (proxy): creation code is the build's, followed by its constructor arguments | tx 0x8a235362b728dc272331601efdef4b0a0187306bf9bb662e38d7e03493cdb330 (createx), 192 bytes of arguments |
| pass | Entrypoint implementation runs the build's Entrypoint | 0xa39fBfb71D89Dde0d75AD23334613EFd695fAadb: 13490 bytes, identical outside 3 immutable site(s) (96 bytes masked) |
| pass | Entrypoint implementation: creation code is the build's, followed by its constructor arguments | tx 0x91462f36e9628cde39e863cd04a25b2ad4e8dbab9026d24b39f1ae11678d1578 (createx), 0 bytes of arguments |
| pass | Withdrawal Groth16 verifier runs the build's WithdrawalVerifier | 0xA9c58610Dae19933b6B21c677D472945DE695446: 1947 bytes, identical |
| pass | Withdrawal Groth16 verifier: creation code is the build's, followed by its constructor arguments | tx 0xe83a176aad5c85bb325ecf749c18ac217cb83965bb63409c79529d83769ec96b (createx), 0 bytes of arguments |
| pass | Ragequit (commitment) Groth16 verifier runs the build's CommitmentVerifier | 0x7165F26B50A5901a02f4D661507545f2fb94F91C: 1582 bytes, identical |
| pass | Ragequit (commitment) Groth16 verifier: creation code is the build's, followed by its constructor arguments | tx 0x943507d8b5982f38734f9336a8978cff4e792b95b2de09c6729c121145acf2e7 (createx), 0 bytes of arguments |
| pass | ETH Privacy Pool (upstream's; unused by the product) runs the build's PrivacyPoolSimple | 0x8e730dF009Bdfa5A685d9b8Cde84449F94d7b12d: 7378 bytes, identical outside 12 immutable site(s) (384 bytes masked) |
| pass | ETH Privacy Pool (upstream's; unused by the product): creation code is the build's, followed by its constructor arguments | tx 0xc6ef188dd635ae6b07def707ee28d7eb6f9df6b02a135f3e6e12fa6009b514c4 (createx), 96 bytes of arguments |
| pass | PoseidonT3 library runs the build's PoseidonT3 | 0x8ffdA7Ed8B4aD98C2C34f54B76821711F4a6f2C5: 23522 bytes, identical |
| pass | PoseidonT4 library runs the build's PoseidonT4 | 0xe393dd7287Db9982e6f845824854Baf8b8e823AF: 12584 bytes, identical |
| pass | Stand-in USDT (TetherLike) runs the build's TetherLike | 0xCDf4eCDa722285d3f5D24c791EC5506D718424a0: 2317 bytes, identical |
| pass | Stand-in USDT (TetherLike): creation code is the build's, followed by its constructor arguments | tx 0xb8ba05efb79bfafd47a8303bdd044822fa14ae777c4af635d7ac3007a3084fd1 (create), 0 bytes of arguments |
| pass | MovvaReserve runs the build's MovvaReserve | 0xa357968D9beC2b3Cc9057c4aF37431780D91287a: 19045 bytes, identical outside 32 immutable site(s) (1024 bytes masked) |
| pass | MovvaReserve: creation code is the build's, followed by its constructor arguments | tx 0x1bbdd954ea74c13e9c090f61dfd69eb3f0cf169c03f0e35bb8f6b3ba49ca57ea (create), 384 bytes of arguments |
| pass | Movva (token) runs the build's Movva | 0xdDb321e26e4e77432fA3E160431f25cCB4700Fa2: 4516 bytes, identical outside 10 immutable site(s) (320 bytes masked) |
| pass | Movva FX leg (PythFxOracle) runs the build's PythFxOracle | 0x90474f2B222d0E0a8dfC4c4F138b041B1921F18F: 6269 bytes, identical outside 5 immutable site(s) (160 bytes masked) |
| pass | Movva FX leg (PythFxOracle): creation code is the build's, followed by its constructor arguments | tx 0x3846a2a65c8e64173847768565b909b118423aeb1f368ab59b916f58b9a54f94 (create), 224 bytes of arguments |
| pass | Movva band adapter (ScaledFxBandOracle) runs the build's ScaledFxBandOracle | 0xaC4c0Fe25ed07B446f8377A97f4aA175020d2B13: 770 bytes, identical outside 2 immutable site(s) (64 bytes masked) |
| pass | Movva band adapter (ScaledFxBandOracle): creation code is the build's, followed by its constructor arguments | tx 0x3b438a42872c1387130496e21516d69359583743760309f9e81a249c3c401882 (create), 32 bytes of arguments |
| pass | FeeSplitter runs the build's FeeSplitter | 0xB81615658A4a51b4d3c2e144d492794Beb001099: 5333 bytes, identical outside 8 immutable site(s) (256 bytes masked) |
| pass | FeeSplitter: creation code is the build's, followed by its constructor arguments | tx 0x328367891709277eaeb69b90befae953804c121dea3ed9dc429dc67f0cd36846 (create), 160 bytes of arguments |
| pass | NodeRewards runs the build's NodeRewards | 0xe446ceA7089704e5cC746edf97F9eedeA4851FF0: 10116 bytes, identical outside 23 immutable site(s) (736 bytes masked) |
| pass | NodeRewards: creation code is the build's, followed by its constructor arguments | tx 0xf6b75053ac694d76399df8393831481d538446b66acb4f1028f4cc4a02497710 (create), 192 bytes of arguments |
| pass | Movva Privacy Pool runs the build's PrivacyPoolComplex | 0x3ac4EE315D13e9a4243954852917eAf69232a6f3: 7720 bytes, identical outside 14 immutable site(s) (448 bytes masked) |
| pass | Movva Privacy Pool: creation code is the build's, followed by its constructor arguments | tx 0x1e7cc950a1d992aa826c21f5eec7394f11209a959b32c39515e88c289f613f30 (createx), 128 bytes of arguments |
| pass | Entrypoint owner (TimelockController, 7 days) runs the build's EntrypointTimelock | 0xeE518057F6fe17385D67c8659abc77Ac5a601ed7: 7143 bytes, identical |
| pass | Entrypoint owner (TimelockController, 7 days): creation code is the build's, followed by its constructor arguments | tx 0xa5581d2f8877ab626093ba94a03c1869a243913befb9c293732d04d9c75c811a (create), 256 bytes of arguments |
| pass | AspRootQuorum (ASP postman, 2 of 3) runs the build's AspRootQuorum | 0xa897FB804917715A0220339640D5e55B59b85339: 2691 bytes, identical outside 7 immutable site(s) (224 bytes masked) |
| pass | AspRootQuorum (ASP postman, 2 of 3): creation code is the build's, followed by its constructor arguments | tx 0x2e69c3fc9b0e222d886a7a619b33793a0e642de1c222494de821bd238575ecb0 (create), 256 bytes of arguments |
| pass | LPRegistry runs the build's LPRegistry | 0x8a31C07b24d83908c11BE0a81ABFA465454d0344: 10366 bytes, identical outside 3 immutable site(s) (96 bytes masked) |
| pass | LPRegistry: creation code is the build's, followed by its constructor arguments | tx 0x44df9627cfaa21339563b1af440f826e06fb3e86d5b6a47bab8e86f157c2c4c7 (create), 64 bytes of arguments |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED) runs the build's ReclaimZkTlsVerifier | 0x84ae5FFC1F84b19498cE5a376200709b4df55508: 16278 bytes, identical outside 3 immutable site(s) (96 bytes masked) |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): creation code is the build's, followed by its constructor arguments | tx 0x18210310c178fc06976264f8bbd1d21c15aa65be62b453a68c4c2afc3a440f83 (create), 896 bytes of arguments |
| pass | FiatEscrow (Movva on-ramp) runs the build's FiatEscrow | 0x3e79B0582b8EAb2FDEcFf0c9da43143e3915eB14: 24563 bytes, identical outside 28 immutable site(s) (896 bytes masked) |
| pass | FiatEscrow (Movva on-ramp): creation code is the build's, followed by its constructor arguments | tx 0x9d9a1da936419b4e18ec9cea0836a702e6eed95657aed5aeef1ca653dbefeba8 (create), 320 bytes of arguments |
| pass | OffRampEscrow (Movva off-ramp) runs the build's OffRampEscrow | 0xCCdA1AA24d45Bc673b090F80363aC38D50D0d81C: 19918 bytes, identical outside 23 immutable site(s) (736 bytes masked) |
| pass | OffRampEscrow (Movva off-ramp): creation code is the build's, followed by its constructor arguments | tx 0xceb1f086b71a37778c73adfae1fa1eb408a1db357606b73d0ce2c47b26dab326 (create), 192 bytes of arguments |

</details>

### Etherscan readiness (dry run, nothing submitted) (21 pass)

<details><summary>21 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | Privacy Pools Entrypoint (proxy): the verify-contract input recompiles to the code at the address | 8 sources, runs 10000, bytecodeHash none: runtime exact, creation code and arguments equal the creation transaction |
| pass | Entrypoint implementation: the verify-contract input recompiles to the code at the address | 27 sources, runs 10000, bytecodeHash none: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | Withdrawal Groth16 verifier: the verify-contract input recompiles to the code at the address | 1 sources, runs 10000, bytecodeHash none: runtime exact, creation code and arguments equal the creation transaction |
| pass | Ragequit (commitment) Groth16 verifier: the verify-contract input recompiles to the code at the address | 1 sources, runs 10000, bytecodeHash none: runtime exact, creation code and arguments equal the creation transaction |
| pass | ETH Privacy Pool (upstream's; unused by the product): the verify-contract input recompiles to the code at the address | 15 sources, runs 10000, bytecodeHash none: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | PoseidonT3 library: the verify-contract input recompiles to the code at the address | 1 sources, runs 10000, bytecodeHash none: runtime exact |
| pass | PoseidonT4 library: the verify-contract input recompiles to the code at the address | 1 sources, runs 10000, bytecodeHash none: runtime exact |
| pass | Stand-in USDT (TetherLike): the verify-contract input recompiles to the code at the address | 44 sources, runs 1000, bytecodeHash ipfs: runtime exact, creation code and arguments equal the creation transaction |
| pass | MovvaReserve: the verify-contract input recompiles to the code at the address | 37 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | Movva (token): the verify-contract input recompiles to the code at the address | 20 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables |
| pass | Movva FX leg (PythFxOracle): the verify-contract input recompiles to the code at the address | 6 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | Movva band adapter (ScaledFxBandOracle): the verify-contract input recompiles to the code at the address | 3 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | FeeSplitter: the verify-contract input recompiles to the code at the address | 11 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | NodeRewards: the verify-contract input recompiles to the code at the address | 17 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | Movva Privacy Pool: the verify-contract input recompiles to the code at the address | 21 sources, runs 10000, bytecodeHash none: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | Entrypoint owner (TimelockController, 7 days): the verify-contract input recompiles to the code at the address | 13 sources, runs 1000, bytecodeHash ipfs: runtime exact, creation code and arguments equal the creation transaction |
| pass | AspRootQuorum (ASP postman, 2 of 3): the verify-contract input recompiles to the code at the address | 1 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | LPRegistry: the verify-contract input recompiles to the code at the address | 4 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): the verify-contract input recompiles to the code at the address | 3 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | FiatEscrow (Movva on-ramp): the verify-contract input recompiles to the code at the address | 9 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | OffRampEscrow (Movva off-ramp): the verify-contract input recompiles to the code at the address | 8 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |

</details>

### Privileges: roles, gates, proxies (111 pass)

<details><summary>111 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | Privacy Pools Entrypoint (proxy): every state-changing function classified | 15 functions in the ABI, all in the catalog |
| pass | Privacy Pools Entrypoint (proxy): a stranger is refused by every gated function | 11 gated functions, each refused with its own error |
| pass | Privacy Pools Entrypoint (proxy): EIP-1967 implementation is the recorded one; admin and beacon slots empty | implementation 0xa39fBfb71D89Dde0d75AD23334613EFd695fAadb, admin empty, beacon empty |
| pass | Entrypoint: OWNER_ROLE held by the recorded timelock alone (every owner action waits its delay) | 0xeE518057F6fe17385D67c8659abc77Ac5a601ed7 |
| pass | Entrypoint: the deployer passes none of its 8 owner functions | refused by every one |
| pass | Entrypoint: no DEFAULT_ADMIN_ROLE holder | none |
| pass | Entrypoint: ASP_POSTMAN held by the postman alone | 0xa897FB804917715A0220339640D5e55B59b85339 |
| pass | Entrypoint: no role beyond OWNER_ROLE, ASP_POSTMAN and DEFAULT_ADMIN_ROLE was ever granted | none |
| pass | Entrypoint implementation: every state-changing function classified | 15 functions in the ABI, all in the catalog |
| pass | Entrypoint implementation: a stranger is refused by every gated function | 11 gated functions, each refused with its own error |
| pass | Entrypoint implementation: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | Entrypoint implementation: initializers disabled (nobody can initialize it and take its roles) | Initializable version 18446744073709551615 |
| pass | Withdrawal Groth16 verifier: every state-changing function classified | 0 functions in the ABI, all in the catalog |
| pass | Withdrawal Groth16 verifier: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | Ragequit (commitment) Groth16 verifier: every state-changing function classified | 0 functions in the ABI, all in the catalog |
| pass | Ragequit (commitment) Groth16 verifier: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | ETH Privacy Pool (upstream's; unused by the product): every state-changing function classified | 4 functions in the ABI, all in the catalog |
| pass | ETH Privacy Pool (upstream's; unused by the product): a stranger is refused by every gated function | 2 gated functions, each refused with its own error |
| pass | ETH Privacy Pool (upstream's; unused by the product): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | PoseidonT3 library: every state-changing function classified | 0 functions in the ABI, all in the catalog |
| pass | PoseidonT3 library: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | PoseidonT4 library: every state-changing function classified | 0 functions in the ABI, all in the catalog |
| pass | PoseidonT4 library: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | Stand-in USDT (TetherLike): every state-changing function classified | 8 functions in the ABI, all in the catalog |
| pass | Stand-in USDT (TetherLike): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | MovvaReserve: every state-changing function classified | 22 functions in the ABI, all in the catalog |
| pass | MovvaReserve: a stranger is refused by every gated function | 20 gated functions, each refused with its own error |
| pass | MovvaReserve: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | MovvaReserve: no pending scheduled change | none |
| pass | MovvaReserve: guardian is 0x...dEaD, and nobody passes pauseMint | guardian 0x000000000000000000000000000000000000dEaD; pauseMint refused with NotGuardianOrGovernor for all 4 probed callers |
| pass | MovvaReserve: governor is 0x...dEaD, and the deployer passes none of its 18 governor functions | governor 0x000000000000000000000000000000000000dEaD |
| pass | Movva (token): every state-changing function classified | 6 functions in the ABI, all in the catalog |
| pass | Movva (token): a stranger is refused by every gated function | 2 gated functions, each refused with its own error |
| pass | Movva (token): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | Movva FX leg (PythFxOracle): every state-changing function classified | 7 functions in the ABI, all in the catalog |
| pass | Movva FX leg (PythFxOracle): a stranger is refused by every gated function | 7 gated functions, each refused with its own error |
| pass | Movva FX leg (PythFxOracle): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | Movva FX leg (PythFxOracle): no pending scheduled change | none |
| pass | Movva FX leg (PythFxOracle): governor is 0x...dEaD, and the deployer passes none of its 7 governor functions | governor 0x000000000000000000000000000000000000dEaD |
| pass | Movva band adapter (ScaledFxBandOracle): every state-changing function classified | 0 functions in the ABI, all in the catalog |
| pass | Movva band adapter (ScaledFxBandOracle): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | FeeSplitter: every state-changing function classified | 9 functions in the ABI, all in the catalog |
| pass | FeeSplitter: a stranger is refused by every gated function | 8 gated functions, each refused with its own error |
| pass | FeeSplitter: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | FeeSplitter: no pending scheduled change | none |
| pass | FeeSplitter: governor is 0x...dEaD, and the deployer passes none of its 8 governor functions | governor 0x000000000000000000000000000000000000dEaD |
| pass | NodeRewards: every state-changing function classified | 13 functions in the ABI, all in the catalog |
| pass | NodeRewards: a stranger is refused by every gated function | 10 gated functions, each refused with its own error |
| pass | NodeRewards: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | NodeRewards: no pending scheduled change | none |
| pass | NodeRewards: governor is 0x...dEaD, and the deployer passes none of its 9 governor functions | governor 0x000000000000000000000000000000000000dEaD |
| pass | Movva Privacy Pool: every state-changing function classified | 4 functions in the ABI, all in the catalog |
| pass | Movva Privacy Pool: a stranger is refused by every gated function | 2 gated functions, each refused with its own error |
| pass | Movva Privacy Pool: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | Entrypoint owner (TimelockController, 7 days): every state-changing function classified | 13 functions in the ABI, all in the catalog |
| pass | Entrypoint owner (TimelockController, 7 days): a stranger is refused by every gated function | 9 gated functions, each refused with its own error |
| pass | Entrypoint owner (TimelockController, 7 days): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | AspRootQuorum (ASP postman, 2 of 3): every state-changing function classified | 2 functions in the ABI, all in the catalog |
| pass | AspRootQuorum (ASP postman, 2 of 3): a stranger is refused by every gated function | 2 gated functions, each refused with its own error |
| pass | AspRootQuorum (ASP postman, 2 of 3): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | AspRootQuorum (ASP postman, 2 of 3): its ASPs are exactly the recorded 3 | 0x6f239a1A5818808E63BB6F35A88B9876a79aa973, 0xc8510850c5bF41B52399473F234577B2d8Ef0B16, 0x323574Eb0c63b764F06832f15B21956bb8979FC9 |
| pass | AspRootQuorum (ASP postman, 2 of 3): only its ASPs pass vote | admitted: 0x6f239a1A5818808E63BB6F35A88B9876a79aa973, 0x323574Eb0c63b764F06832f15B21956bb8979FC9, 0xc8510850c5bF41B52399473F234577B2d8Ef0B16 |
| pass | LPRegistry: every state-changing function classified | 17 functions in the ABI, all in the catalog |
| pass | LPRegistry: a stranger is refused by every gated function | 11 gated functions, each refused with its own error |
| pass | LPRegistry: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | LPRegistry: no pending scheduled change | none |
| pass | LPRegistry: governor is 0x...dEaD, and the deployer passes none of its 9 governor functions | governor 0x000000000000000000000000000000000000dEaD |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): every state-changing function classified | 11 functions in the ABI, all in the catalog |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): a stranger is refused by every gated function | 11 gated functions, each refused with its own error |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): no pending scheduled change | none |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): governor is 0x...dEaD, and the deployer passes none of its 11 governor functions | governor 0x000000000000000000000000000000000000dEaD |
| pass | FiatEscrow (Movva on-ramp): every state-changing function classified | 24 functions in the ABI, all in the catalog |
| pass | FiatEscrow (Movva on-ramp): a stranger is refused by every gated function | 9 gated functions, each refused with its own error |
| pass | FiatEscrow (Movva on-ramp): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | FiatEscrow (Movva on-ramp): no pending scheduled change | none |
| pass | FiatEscrow (Movva on-ramp): governor is 0x...dEaD, and the deployer passes none of its 9 governor functions | governor 0x000000000000000000000000000000000000dEaD |
| pass | OffRampEscrow (Movva off-ramp): every state-changing function classified | 18 functions in the ABI, all in the catalog |
| pass | OffRampEscrow (Movva off-ramp): a stranger is refused by every gated function | 9 gated functions, each refused with its own error |
| pass | OffRampEscrow (Movva off-ramp): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | OffRampEscrow (Movva off-ramp): no pending scheduled change | none |
| pass | OffRampEscrow (Movva off-ramp): governor is 0x...dEaD, and the deployer passes none of its 9 governor functions | governor 0x000000000000000000000000000000000000dEaD |
| pass | ETH Privacy Pool (upstream's; unused by the product): ENTRYPOINT (immutable) is exactly the recorded set | 0x81d45264fbC3E1cD303891bb8f4ae9EA2DEB2CcC |
| pass | Movva Privacy Pool: ENTRYPOINT (immutable) is exactly the recorded set | 0x81d45264fbC3E1cD303891bb8f4ae9EA2DEB2CcC |
| pass | Entrypoint owner (TimelockController, 7 days): proposer is exactly the recorded set | 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | Entrypoint owner (TimelockController, 7 days): canceller is exactly the recorded set | 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | Entrypoint owner (TimelockController, 7 days): executor is exactly the recorded set | 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | Entrypoint owner (TimelockController, 7 days): admin (DEFAULT_ADMIN_ROLE) is exactly the recorded set | 0xeE518057F6fe17385D67c8659abc77Ac5a601ed7 |
| pass | AspRootQuorum (ASP postman, 2 of 3): ASP is exactly the recorded set | 0x6f239a1A5818808E63BB6F35A88B9876a79aa973, 0xc8510850c5bF41B52399473F234577B2d8Ef0B16, 0x323574Eb0c63b764F06832f15B21956bb8979FC9 |
| pass | AspRootQuorum (ASP postman, 2 of 3): ENTRYPOINT (immutable) is exactly the recorded set | 0x81d45264fbC3E1cD303891bb8f4ae9EA2DEB2CcC |
| pass | MovvaReserve: guardian is exactly the recorded set | 0x000000000000000000000000000000000000dEaD |
| pass | MovvaReserve: gateway is exactly the recorded set | 0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C, 0xf491FA29debC0D12d8F7c57B17995C2346F025AD |
| pass | MovvaReserve: yield recipient (payee) is exactly the recorded set | 0x622F626F912AD25d36D9B8F48907Ac941F755ACb |
| pass | MovvaReserve: fee recipient (payee) is exactly the recorded set | 0xB81615658A4a51b4d3c2e144d492794Beb001099 |
| pass | MovvaReserve: yield vault is exactly the recorded set | none |
| pass | Movva (token): minter (RESERVE, immutable) is exactly the recorded set | 0xa357968D9beC2b3Cc9057c4aF37431780D91287a |
| pass | FeeSplitter: treasury (payee) is exactly the recorded set | 0x622F626F912AD25d36D9B8F48907Ac941F755ACb |
| pass | FeeSplitter: rewards (payee) is exactly the recorded set | 0xe446ceA7089704e5cC746edf97F9eedeA4851FF0 |
| pass | NodeRewards: registry (reports settlements) is exactly the recorded set | 0x8a31C07b24d83908c11BE0a81ABFA465454d0344 |
| pass | NodeRewards: excluded LP is exactly the recorded set | none |
| pass | LPRegistry: escrow is exactly the recorded set | 0x3e79B0582b8EAb2FDEcFf0c9da43143e3915eB14, 0xCCdA1AA24d45Bc673b090F80363aC38D50D0d81C |
| pass | LPRegistry: rewards hook is exactly the recorded set | 0xe446ceA7089704e5cC746edf97F9eedeA4851FF0 |
| pass | LPRegistry: LP (tier > NONE) is exactly the recorded set | 0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C, 0xf491FA29debC0D12d8F7c57B17995C2346F025AD |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): witness is exactly the recorded set | 0x05EfF3D8e0ad59Aa8abFd94E0b08402ec0850Fbf, 0x8771D8B0038061D7872e4c2C69cD63F54380CBAb, 0x72C1a86B73Ca01Fec5e07160AE14a32849eE5214 |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): bank endpoint (providerHash) is exactly the recorded set | 0xb54d2a19bba3a502dc449c083cd2579885618e4e0487435aae1673f06baf0c05, 0xd8d90d629dc91348bf69c3c5148cd5bf1efdc99220a15a6f42d6ad42eeb2bb20, 0x8259a0510dbf7425215eada80e9a8fcc1bac48d4e24e3cea67b5185b482abf77, 0xf02c2badc915c0c690ccba5dd00202b6efcc3d49a1c1197db4026f075aaddc1a |
| pass | FiatEscrow (Movva on-ramp): arbitrator is exactly the recorded set | 0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7 |
| pass | FiatEscrow (Movva on-ramp): allowed verifier is exactly the recorded set | 0x84ae5FFC1F84b19498cE5a376200709b4df55508 |
| pass | FiatEscrow (Movva on-ramp): listed asset (enabled) is exactly the recorded set | 0xdDb321e26e4e77432fA3E160431f25cCB4700Fa2 |
| pass | OffRampEscrow (Movva off-ramp): arbitrator is exactly the recorded set | 0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7 |
| pass | OffRampEscrow (Movva off-ramp): allowed verifier is exactly the recorded set | 0x84ae5FFC1F84b19498cE5a376200709b4df55508 |
| pass | OffRampEscrow (Movva off-ramp): listed asset (enabled) is exactly the recorded set | 0xdDb321e26e4e77432fA3E160431f25cCB4700Fa2 |

</details>

## Privileges

Read from the chain at block 11964915, after `--finalize`; the inventory before it was taken at block 11964862. For every contract: who holds each role, what the role can and cannot do (as the contract's code says, with the lines), and which state-changing functions the chain admits each caller to. The function list is the ABI of the build, so a function nobody classified would show as UNKNOWN and fail the checks: 0 do.

Probing: every state-changing function was `eth_call`ed with zero arguments from a stranger (`0x21f474a941692095F3122E1C82b9f24EC237f975`, holds nothing), the deployer and every current holder. "Refused" means the contract's own authorization error; "admitted" means the call got past the gate (it may then revert on the zero arguments). Nothing was sent.

### What --finalize renounced

- MovvaReserve (0xa357968D9beC2b3Cc9057c4aF37431780D91287a): guardian 0xd67DDA7D07CAa45d6f8e7C1dD0a170585e6B086c -> 0x000000000000000000000000000000000000dEaD (setGuardian, instant, sent by its governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1). With the governor gone too, nobody can call pauseMint.
- MovvaReserve (0xa357968D9beC2b3Cc9057c4aF37431780D91287a): governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 -> 0x000000000000000000000000000000000000dEaD.
- Movva FX leg (PythFxOracle) (0x90474f2B222d0E0a8dfC4c4F138b041B1921F18F): governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 -> 0x000000000000000000000000000000000000dEaD.
- FeeSplitter (0xB81615658A4a51b4d3c2e144d492794Beb001099): governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 -> 0x000000000000000000000000000000000000dEaD.
- NodeRewards (0xe446ceA7089704e5cC746edf97F9eedeA4851FF0): governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 -> 0x000000000000000000000000000000000000dEaD.
- LPRegistry (0x8a31C07b24d83908c11BE0a81ABFA465454d0344): governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 -> 0x000000000000000000000000000000000000dEaD.
- ReclaimZkTlsVerifier (PIX, boleto, TED) (0x84ae5FFC1F84b19498cE5a376200709b4df55508): governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 -> 0x000000000000000000000000000000000000dEaD.
- FiatEscrow (Movva on-ramp) (0x3e79B0582b8EAb2FDEcFf0c9da43143e3915eB14): governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 -> 0x000000000000000000000000000000000000dEaD.
- OffRampEscrow (Movva off-ramp) (0xCCdA1AA24d45Bc673b090F80363aC38D50D0d81C): governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 -> 0x000000000000000000000000000000000000dEaD.
- deployments/sepolia-movva-v4-permissionless.json ramp.movvaOnramp (0x7dB64fDa2A95C25E5F7f23F9118CFb99b2695015): governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 -> 0x000000000000000000000000000000000000dEaD.
- deployments/sepolia-movva-v4-permissionless.json ramp.movvaOfframp (0x413fa4eb0C730D1fA459C38A38fF7bAA68f56bFe): governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 -> 0x000000000000000000000000000000000000dEaD.
- deployments/sepolia-v4-hedge-sleeve.json subWallet (0x6feF0EA790F64D81944098bC13BDbc0F4C9E546C): governor 0x51d8E8E425c0431741246513F8A63Dd7d7c175Eb -> 0x000000000000000000000000000000000000dEaD.
- Before renouncing anything: the inventory at block 11964862 passed 72/72 privilege checks and 29/29 exact-set checks against the record.
- Entrypoint ASP_POSTMAN: the recorded AspRootQuorum 0xa897FB804917715A0220339640D5e55B59b85339 alone, running this build's code (2691 bytes, identical outside 7 immutable site(s) (224 bytes masked)), 2 of 3 ASPs, bound to this Entrypoint.
- MovvaReserve yield recipient 0x622F626F912AD25d36D9B8F48907Ac941F755ACb: after --finalize the only payee of harvestYield, for good (no governor will remain to move it).
- deployments/sepolia-v4-hedge-sleeve.json subWallet (0x6feF0EA790F64D81944098bC13BDbc0F4C9E546C): keeper 0x4D0dF9bB92883cf5584c812EB84AABA55d688853 stays: an EOA by design, equal to its record; it acts only inside the sleeve's immutable bounds and pays only TREASURY.
- deployments/sepolia-v4-hedge-sleeve.json venue (0x52D7e5fDEe5ab90A425a23B962c4eCff405dca95): venue operator 0x51d8E8E425c0431741246513F8A63Dd7d7c175Eb stays: an EOA by design (a simulator's price and funding feed; not governed, no delay to renounce).
- Chain scan (GovernorTransferred / SetupCompleted since block 11964251): 11 governed contract(s) found, none outside the 11 renounced here.
- Entrypoint fees: 0 MOVVA units held now; they stay collectable by the TimelockController 0xeE518057F6fe17385D67c8659abc77Ac5a601ed7 (withdrawFees(MOVVA, treasury), a 7-day operation the Safe proposes). The owner step withdrew what it held before the hand-over: nothing.
- Entrypoint OWNER_ROLE: kept by the TimelockController 0xeE518057F6fe17385D67c8659abc77Ac5a601ed7 (7 days; proposer, canceller and executor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1). The deployer holds no Entrypoint role.
- Entrypoint ASP_POSTMAN: kept by 0xa897FB804917715A0220339640D5e55B59b85339. It posts the roots every private withdrawal needs; only a 7-day timelock operation could replace it.
- 11 DelayedGovernance contracts (8 of the rail, 3 of its siblings): 11 handed to 0x000000000000000000000000000000000000dEaD now; setup completed here on 0.

**How.** Each `DelayedGovernance` governor was handed to `0x000000000000000000000000000000000000dEaD` with `transferGovernor` (`contracts/common/DelayedGovernance.sol:143`). That transfer is one step and instant, and refuses only `address(0)`. So it is a real renunciation, not a pending two-step one. No key is known for `0x000000000000000000000000000000000000dEaD`, and no contract can be deployed there. The Entrypoint's OWNER_ROLE was given up with `renounceRole`. Every role's admin is OWNER_ROLE (`protocol/contracts/src/contracts/Entrypoint.sol:81`), so nobody can grant any role again. The reserve's guardian was sent to `0x000000000000000000000000000000000000dEaD` with `setGuardian` (`contracts/movva/MovvaReserve.sol:631`) before its governor was handed over: that setter is instant even after setup (it calls `_authorizeChange(false)`) and refuses only `address(0)`. The guardian's only power is `pauseMint` (`contracts/movva/MovvaReserve.sol:742`), which only the guardian or the governor passes, so with both at `0x000000000000000000000000000000000000dEaD` nobody can pause minting. No contract change was needed for any of it.

**What that makes impossible.** Each item below is a function only the renounced key could call:

- upgrading the Entrypoint, or adding, removing, reconfiguring or winding down a pool (`protocol/contracts/src/contracts/Entrypoint.sol:308`, `protocol/contracts/src/contracts/Entrypoint.sol:183`, `protocol/contracts/src/contracts/Entrypoint.sol:256`).
- recovering vetting fees. Every deposit's vetting fee (each pool's `vettingFeeBPS`, in the Entrypoint checks above) stays in the Entrypoint for good: only OWNER_ROLE can withdraw them (`protocol/contracts/src/contracts/Entrypoint.sol:264`, `protocol/contracts/src/contracts/Entrypoint.sol:332`).
- raising a pool's relay-fee cap. A relayer quote above it reverts `RelayFeeGreaterThanMax` for good. Users can still withdraw directly, or ragequit (`protocol/contracts/src/contracts/Entrypoint.sol:157`).
- replacing or removing the ASP postman. Its admin role is OWNER_ROLE. The postman is the AspRootQuorum 0xa897FB804917715A0220339640D5e55B59b85339, 2 of 3 fixed ASPs with no owner and no setter, so neither the postman nor its ASP set can ever change (`protocol/contracts/src/contracts/Entrypoint.sol:82`).
- revoking a leaked zkTLS witness key. A quorum of leaked keys can prove payments that never happened, and each such proof releases an order's crypto (`contracts/ramp/ReclaimZkTlsVerifier.sol:674`).
- revoking a leaked arbitrator key. FiatEscrow's own NatSpec says a stolen arbitrator key can drain every offer, one disputed order at a time. The one defence it names is revoking the key within RULING_DELAY (`contracts/ramp/FiatEscrow.sol:1007`, `contracts/ramp/FiatEscrow.sol:1214`, `contracts/ramp/OffRampEscrow.sol:706`).
- revoking a verifier or a bank endpoint, delisting an asset, or lowering a cap on an escrow (`contracts/ramp/FiatEscrow.sol:1206`, `contracts/ramp/ReclaimZkTlsVerifier.sol:705`, `contracts/ramp/FiatEscrow.sol:534`).
- suspending a misbehaving LP, admitting a new one, or opening Phase B or C. The network stays in its current phase with its current LPs (`contracts/ramp/LPRegistry.sol:252`, `contracts/ramp/LPRegistry.sol:221`).
- pausing Movva minting, or resuming it. The guardian and the governor, the only callers of `pauseMint`, are both 0x...dEaD, and `--finalize` refuses while minting is paused, so minting stays open for good (redemptions never could be paused). The divergence breaker, where one is deployed, still halts by itself (`contracts/movva/MovvaReserve.sol:742`, `contracts/movva/MovvaReserve.sol:748`).
- adding or removing a Movva gateway. Only gateways redeem Movva for USDT, so if every gateway key is lost nobody can redeem again (`contracts/movva/MovvaReserve.sol:623`, `contracts/movva/MovvaReserve.sol:527`).
- repointing the reserve's oracle when Pyth retires the feed. Minting and redeeming would stop at a dead feed for good (`contracts/movva/MovvaReserve.sol:685`).
- changing the yield recipient or the yield vault. The yield recipient fixed at --finalize is the only address harvestYield ever pays, and the vault the principal is invested in stays the source for good (pulling it back into the reserve needs the governor too) (`contracts/movva/MovvaReserve.sol:640`, `contracts/movva/MovvaReserve.sol:698`, `contracts/movva/MovvaReserve.sol:714`).
- voiding farmed volume or excluding an LP from node-provider rewards (`contracts/ramp/NodeRewards.sol:441`, `contracts/ramp/NodeRewards.sol:429`).
- executing any change scheduled before the handover (`contracts/common/DelayedGovernance.sol:181`).

Every "instant" brake in `docs/runbook-mainnet-deploy.md` ("If something is wrong after deployment") is one of these. After `--finalize` that table has no one to act on it. The contracts themselves never relied on a governor for users to exit: escrow timeouts refund without permission, and ragequit needs no service.

### What remains, and why

| Contract | Role | Held by |
|---|---|---|
| Privacy Pools Entrypoint (proxy) | OWNER_ROLE | `0xeE518057F6fe17385D67c8659abc77Ac5a601ed7` |
| Privacy Pools Entrypoint (proxy) | ASP_POSTMAN | `0xa897FB804917715A0220339640D5e55B59b85339` |
| MovvaReserve | gateway | `0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C`, `0xf491FA29debC0D12d8F7c57B17995C2346F025AD` |
| Entrypoint owner (TimelockController, 7 days) | proposer | `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1` |
| Entrypoint owner (TimelockController, 7 days) | canceller | `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1` |
| Entrypoint owner (TimelockController, 7 days) | executor | `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1` |
| AspRootQuorum (ASP postman, 2 of 3) | ASP | `0x6f239a1A5818808E63BB6F35A88B9876a79aa973`, `0xc8510850c5bF41B52399473F234577B2d8Ef0B16`, `0x323574Eb0c63b764F06832f15B21956bb8979FC9` |
| LPRegistry | LP (tier > NONE) | `0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C`, `0xf491FA29debC0D12d8F7c57B17995C2346F025AD` |
| ReclaimZkTlsVerifier (PIX, boleto, TED) | witness | `0x05EfF3D8e0ad59Aa8abFd94E0b08402ec0850Fbf`, `0x8771D8B0038061D7872e4c2C69cD63F54380CBAb`, `0x72C1a86B73Ca01Fec5e07160AE14a32849eE5214` |
| FiatEscrow (Movva on-ramp) | arbitrator | `0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7` |
| OffRampEscrow (Movva off-ramp) | arbitrator | `0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7` |

Why each remains:

- **ASP postman** (Entrypoint `ASP_POSTMAN`). A private withdrawal must prove membership in the latest association-set root (`protocol/contracts/src/contracts/PrivacyPool.sol:59`), and only the postman posts roots (`protocol/contracts/src/contracts/Entrypoint.sol:93`). Without it, new deposits could only leave by ragequit (`protocol/contracts/src/contracts/PrivacyPool.sol:132`). It can admit or leave out deposits; it cannot move funds. The postman is the AspRootQuorum `0xa897FB804917715A0220339640D5e55B59b85339`: a root is posted only when 2 of its 3 fixed ASPs (`0x6f239a1A5818808E63BB6F35A88B9876a79aa973`, `0xc8510850c5bF41B52399473F234577B2d8Ef0B16`, `0x323574Eb0c63b764F06832f15B21956bb8979FC9`) vote for it (`contracts/AspRootQuorum.sol:139`). The ASPs are the keys that remain; the set cannot change.
- **Arbitrator**, on each escrow. Some disputes no proof can settle: bank downtime, a reversed payment. A ruling reaches only a DISPUTED order and pays one of its two counterparties. A RELEASE needs an arbitrator registered before the dispute (`contracts/ramp/FiatEscrow.sol:1098`). Rulings execute a day after posting (`contracts/ramp/FiatEscrow.sol:296`). With no arbitrator, a dispute can only time out back to the LP (`contracts/ramp/FiatEscrow.sol:1139`).
- **zkTLS witnesses.** They are the proof. Their signatures are what `verifyPayment` checks, and nothing on-chain can replace them.
- **Movva gateways and the yield recipient.** Only gateways mint and redeem (`contracts/movva/MovvaReserve.sol:296`): the gateways are the institutional LPs that settle the off-ramp, and a redemption is the only way the reserve's principal leaves. The reserve is principal-locked (client rule, 21 October 2026): it has no hedge path, and only the yield above max(principal, liabilities at the target) leaves, by `harvestYield`, to the yield recipient alone (`contracts/movva/MovvaReserve.sol:564`). The guardian is `0x000000000000000000000000000000000000dEaD`: nobody can pause minting (`contracts/movva/MovvaReserve.sol:742`).
- **LPs** in the registry. Their tier and credit limit bound what each may have at risk.
- **Keepers: none with on-chain power.** The Pyth keeper posts prices to Pyth, which anyone may do. `split`, `sync` and `finalize` are open to anyone.
- **Bound to code, not keys:** Movva's minter (`RESERVE`, immutable), each pool's `ENTRYPOINT` (immutable), the quorum's `ENTRYPOINT`, ASP set and `THRESHOLD` (immutable), and the escrows the registry accepts.
- **Outside this deployment:** Pyth (its own governance can upgrade it), the Chainlink feeds (their proxies are owned by Chainlink), CreateX, and on mainnet Tether's USDT, which can freeze an escrow. These are trusted as they are and not inventoried here.

### Per contract

#### Privacy Pools Entrypoint (proxy)

`0x81d45264fbC3E1cD303891bb8f4ae9EA2DEB2CcC` - `ERC1967Proxy` running `Entrypoint`, `protocol/contracts/src/contracts/Entrypoint.sol`. Privacy Pools' Entrypoint (upstream 0xbow, UUPS behind an ERC1967Proxy): deposits into and relays withdrawals from every pool, and holds the ASP root. **Holds funds.**

- DEFAULT_ADMIN_ROLE (admin OWNER_ROLE): **nobody**
- OWNER_ROLE (admin OWNER_ROLE): `0xeE518057F6fe17385D67c8659abc77Ac5a601ed7`
- ASP_POSTMAN (admin OWNER_ROLE): `0xa897FB804917715A0220339640D5e55B59b85339`
- EIP-1967: implementation `0xa39fBfb71D89Dde0d75AD23334613EFd695fAadb`, admin `empty`, beacon `empty`

- **OWNER_ROLE** can upgrade the Entrypoint's code; register and remove pools; change a pool's minimum deposit, vetting fee and relay-fee cap; wind a pool down; withdraw every fee the Entrypoint holds, to any address; grant and revoke every role, OWNER_ROLE included. It cannot move pooled notes without an upgrade: a withdrawal needs the note's zero-knowledge proof. With an upgrade it can: the Entrypoint's code relays every withdrawal and holds depositors' ERC-20 approvals, so an upgrade is the one path from this role to users' money. (`node_modules/@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol:92`, `protocol/contracts/src/contracts/Entrypoint.sol:183`, `protocol/contracts/src/contracts/Entrypoint.sol:220`, `protocol/contracts/src/contracts/Entrypoint.sol:239`, `protocol/contracts/src/contracts/Entrypoint.sol:256`, `protocol/contracts/src/contracts/Entrypoint.sol:264`, …)
- **ASP_POSTMAN** can publish the association-set root. A private withdrawal must prove membership in the latest root, so the postman decides which deposits may withdraw privately. It cannot move funds, or stop a depositor leaving publicly: ragequit returns a deposit to its original depositor with no root at all. (`protocol/contracts/src/contracts/Entrypoint.sol:93`)
- **DEFAULT_ADMIN_ROLE** can call nothing: no Entrypoint function checks it, and it administers no role (every role's admin is OWNER_ROLE). Listed because AccessControl defines it. It cannot be held by anyone OWNER_ROLE did not grant it to. `initialize` grants it to nobody.

<details><summary>15 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `receive()` | only the Entrypoint (immutable) | - | Accept ETH only from the registered native pool (relayed withdrawals). | not probed (plain ETH transfer) | `protocol/contracts/src/contracts/Entrypoint.sol:298` |
| `deposit(address,uint256,uint256)` | anyone | - | Make an ERC20 deposit into the Privacy Pool <sub>(NatSpec)</sub> | open | `protocol/contracts/src/contracts/Entrypoint.sol:111` |
| `deposit(uint256)` | anyone | - | Make a native asset deposit into the Privacy Pool <sub>(NatSpec)</sub> | open | `protocol/contracts/src/contracts/Entrypoint.sol:111` |
| `grantRole(bytes32,address)` | the role's admin role (OWNER_ROLE, for every role here) (key) | instant | Grant a role. OWNER_ROLE is the admin of OWNER_ROLE, ASP_POSTMAN and DEFAULT_ADMIN_ROLE. | `0xeE51…1ed7` OWNER_ROLE | `node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol:143` |
| `initialize(address,address)` | nobody: the initializer has run (on the implementation: disabled) | - | Initializes the contract state <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:69` |
| `registerPool(address,address,uint256,uint256,uint256)` | an OWNER_ROLE holder (key) | instant | Register a Privacy Pool in the registry <sub>(NatSpec)</sub> | `0xeE51…1ed7` OWNER_ROLE | `protocol/contracts/src/contracts/Entrypoint.sol:183` |
| `relay(…)` | anyone carrying a proof the contract's verifier accepts | - | Process a withdrawal <sub>(NatSpec)</sub> | open | `protocol/contracts/src/contracts/Entrypoint.sol:133` |
| `removePool(address)` | an OWNER_ROLE holder (key) | instant | Remove a Privacy Pool from the registry <sub>(NatSpec)</sub> | `0xeE51…1ed7` OWNER_ROLE | `protocol/contracts/src/contracts/Entrypoint.sol:220` |
| `renounceRole(bytes32,address)` | only for the caller's own role | instant | Give up a role the caller holds (it must name itself). | **nobody** (every probed caller refused) | `node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol:178` |
| `revokeRole(bytes32,address)` | the role's admin role (OWNER_ROLE, for every role here) (key) | instant | Revoke a role from an account. | `0xeE51…1ed7` OWNER_ROLE | `node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol:158` |
| `updatePoolConfiguration(address,uint256,uint256,uint256)` | an OWNER_ROLE holder (key) | instant | Updates the configuration of a specific pool <sub>(NatSpec)</sub> | `0xeE51…1ed7` OWNER_ROLE | `protocol/contracts/src/contracts/Entrypoint.sol:239` |
| `updateRoot(uint256,string)` | an ASP_POSTMAN holder (key) | instant | Push a new root to the association root set <sub>(NatSpec)</sub> | `0xa897…5339` ASP_POSTMAN | `protocol/contracts/src/contracts/Entrypoint.sol:93` |
| `upgradeToAndCall(address,bytes)` | an OWNER_ROLE holder (key) | instant | Replace the Entrypoint's code (UUPS; `_authorizeUpgrade` is onlyRole(OWNER_ROLE)). | `0xeE51…1ed7` OWNER_ROLE | `node_modules/@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol:92` |
| `windDownPool(address)` | an OWNER_ROLE holder (key) | instant | Irreversebly halt deposits from a Privacy Pool <sub>(NatSpec)</sub> | inconclusive (bare revert): `0xeE51…1ed7` OWNER_ROLE | `protocol/contracts/src/contracts/Entrypoint.sol:256` |
| `withdrawFees(address,address)` | an OWNER_ROLE holder (key) | instant | Withdraw fees from the Entrypoint <sub>(NatSpec)</sub> | inconclusive (bare revert): `0xeE51…1ed7` OWNER_ROLE | `protocol/contracts/src/contracts/Entrypoint.sol:264` |

</details>

#### Entrypoint implementation

`0xa39fBfb71D89Dde0d75AD23334613EFd695fAadb` - `Entrypoint`, `protocol/contracts/src/contracts/Entrypoint.sol`. The Entrypoint's implementation. Its own storage is never initialized (the constructor disables initializers), so no role exists in it, and `upgradeToAndCall` refuses a direct call (onlyProxy). It is code the proxy runs, not a second Entrypoint.

- EIP-1967 slots: empty (not a proxy)
- initializers disabled

<details><summary>15 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `receive()` | only the Entrypoint (immutable) | - | Accept ETH only from the registered native pool (relayed withdrawals). | not probed (plain ETH transfer) | `protocol/contracts/src/contracts/Entrypoint.sol:298` |
| `deposit(address,uint256,uint256)` | anyone | - | Make an ERC20 deposit into the Privacy Pool <sub>(NatSpec)</sub> | open | `protocol/contracts/src/contracts/Entrypoint.sol:111` |
| `deposit(uint256)` | anyone | - | Make a native asset deposit into the Privacy Pool <sub>(NatSpec)</sub> | open | `protocol/contracts/src/contracts/Entrypoint.sol:111` |
| `grantRole(bytes32,address)` | the role's admin role (OWNER_ROLE, for every role here) (key) | instant | Grant a role. OWNER_ROLE is the admin of OWNER_ROLE, ASP_POSTMAN and DEFAULT_ADMIN_ROLE. | **nobody** (every probed caller refused) | `node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol:143` |
| `initialize(address,address)` | nobody: the initializer has run (on the implementation: disabled) | - | Initializes the contract state <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:69` |
| `registerPool(address,address,uint256,uint256,uint256)` | an OWNER_ROLE holder (key) | instant | Register a Privacy Pool in the registry <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:183` |
| `relay(…)` | anyone carrying a proof the contract's verifier accepts | - | Process a withdrawal <sub>(NatSpec)</sub> | open | `protocol/contracts/src/contracts/Entrypoint.sol:133` |
| `removePool(address)` | an OWNER_ROLE holder (key) | instant | Remove a Privacy Pool from the registry <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:220` |
| `renounceRole(bytes32,address)` | only for the caller's own role | instant | Give up a role the caller holds (it must name itself). | **nobody** (every probed caller refused) | `node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol:178` |
| `revokeRole(bytes32,address)` | the role's admin role (OWNER_ROLE, for every role here) (key) | instant | Revoke a role from an account. | **nobody** (every probed caller refused) | `node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol:158` |
| `updatePoolConfiguration(address,uint256,uint256,uint256)` | an OWNER_ROLE holder (key) | instant | Updates the configuration of a specific pool <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:239` |
| `updateRoot(uint256,string)` | an ASP_POSTMAN holder (key) | instant | Push a new root to the association root set <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:93` |
| `upgradeToAndCall(address,bytes)` | an OWNER_ROLE holder (key) | instant | Replace the Entrypoint's code (UUPS; `_authorizeUpgrade` is onlyRole(OWNER_ROLE)). | **nobody** (every probed caller refused) | `node_modules/@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol:92` |
| `windDownPool(address)` | an OWNER_ROLE holder (key) | instant | Irreversebly halt deposits from a Privacy Pool <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:256` |
| `withdrawFees(address,address)` | an OWNER_ROLE holder (key) | instant | Withdraw fees from the Entrypoint <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:264` |

</details>

#### Withdrawal Groth16 verifier

`0xA9c58610Dae19933b6B21c677D472945DE695446` - `WithdrawalVerifier`, `protocol/contracts/src/contracts/verifiers/WithdrawalVerifier.sol`. Groth16 verifier for withdrawal proofs: pure code, no state.

- EIP-1967 slots: empty (not a proxy)

No state-changing functions.

#### Ragequit (commitment) Groth16 verifier

`0x7165F26B50A5901a02f4D661507545f2fb94F91C` - `CommitmentVerifier`, `protocol/contracts/src/contracts/verifiers/CommitmentVerifier.sol`. Groth16 verifier for ragequit (commitment) proofs: pure code, no state.

- EIP-1967 slots: empty (not a proxy)

No state-changing functions.

#### ETH Privacy Pool (upstream's; unused by the product)

`0x8e730dF009Bdfa5A685d9b8Cde84449F94d7b12d` - `PrivacyPoolSimple`, `protocol/contracts/src/contracts/implementations/PrivacyPoolSimple.sol`. A Privacy Pool for native ETH (upstream 0xbow). No owner; bound to one Entrypoint and one asset at construction. **Holds funds.**

- ENTRYPOINT (immutable): `0x81d45264fbC3E1cD303891bb8f4ae9EA2DEB2CcC`
- dead = `true` (wound down: no new deposits)
- EIP-1967 slots: empty (not a proxy)

- **ENTRYPOINT** can deposit on a depositor's behalf, and wind the pool down. It cannot withdraw: that needs a note's proof, or its original depositor for ragequit. (`protocol/contracts/src/contracts/PrivacyPool.sol:82`, `protocol/contracts/src/contracts/PrivacyPool.sol:157`)

<details><summary>4 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `deposit(address,uint256,uint256)` | only the Entrypoint (immutable) | - | Deposit funds into the Privacy Pool <sub>(NatSpec)</sub> | `0x81d4…2CcC` ENTRYPOINT | `protocol/contracts/src/contracts/PrivacyPool.sol:82` |
| `ragequit((uint256[2],uint256[2][2],uint256[2],uint256[4]))` | a party to that offer, order, sale, note or reward | - | Publicly withdraw funds to original depositor without exposing secrets <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `protocol/contracts/src/contracts/PrivacyPool.sol:132` |
| `windDown()` | only the Entrypoint (immutable) | - | Irreversibly suspends deposits <sub>(NatSpec)</sub> | `0x81d4…2CcC` ENTRYPOINT | `protocol/contracts/src/contracts/PrivacyPool.sol:157` |
| `withdraw(…)` | anyone carrying a proof the contract's verifier accepts | - | Privately withdraw funds by spending an existing commitment <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `protocol/contracts/src/contracts/PrivacyPool.sol:110` |

</details>

#### PoseidonT3 library

`0x8ffdA7Ed8B4aD98C2C34f54B76821711F4a6f2C5` - `PoseidonT3`, `node_modules/poseidon-solidity/PoseidonT3.sol`. Poseidon hash library (2 inputs): pure code, no state. Linked into the pools.

- EIP-1967 slots: empty (not a proxy)

No state-changing functions.

#### PoseidonT4 library

`0xe393dd7287Db9982e6f845824854Baf8b8e823AF` - `PoseidonT4`, `node_modules/poseidon-solidity/PoseidonT4.sol`. Poseidon hash library (3 inputs): pure code, no state. Linked into the pools.

- EIP-1967 slots: empty (not a proxy)

No state-changing functions.

#### Stand-in USDT (TetherLike)

`0xCDf4eCDa722285d3f5D24c791EC5506D718424a0` - `TetherLike`, `contracts/test/ERC4626Adapter.t.sol`. Rehearsal stand-in for USDT (contracts/test/ERC4626Adapter.t.sol): Tether's surface, 6 decimals. NOT a mainnet contract.

- owner (receives transfer fees): `0x51d8E8E425c0431741246513F8A63Dd7d7c175Eb`
- paused = `false` (transfers refused)
- EIP-1967 slots: empty (not a proxy)

- **anyone** can mint, pause, blacklist and set fees: every function is open, so its balances mean nothing. It cannot be stopped: there is no owner check anywhere. It exists only because Sepolia has no canonical USDT. (`contracts/test/ERC4626Adapter.t.sol:34`, `contracts/test/ERC4626Adapter.t.sol:70`, `contracts/test/ERC4626Adapter.t.sol:62`, `contracts/test/ERC4626Adapter.t.sol:56`)

<details><summary>8 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `addBlackList(address)` | anyone | - | Blacklist an address. Open to everyone. | open | `contracts/test/ERC4626Adapter.t.sol:62` |
| `approve(address,uint256)` | anyone | - | Set an allowance over the caller's own balance. | open | `contracts/test/ERC4626Adapter.t.sol:51` |
| `mint(address,uint256)` | anyone | - | Create tokens for anyone. Open to everyone: this is a test token. | open | `contracts/test/ERC4626Adapter.t.sol:34` |
| `removeBlackList(address)` | anyone | - | Unblacklist an address. Open to everyone. | open | `contracts/test/ERC4626Adapter.t.sol:66` |
| `setParams(uint256,uint256)` | anyone | - | Set the transfer fee (< 20 bps, < 50 tokens), paid to `owner`. Open to everyone. | open | `contracts/test/ERC4626Adapter.t.sol:56` |
| `setPaused(bool)` | anyone | - | Pause or unpause transfers. Open to everyone. | open | `contracts/test/ERC4626Adapter.t.sol:70` |
| `transfer(address,uint256)` | anyone | - | Move the caller's own balance. | open | `contracts/test/ERC4626Adapter.t.sol:39` |
| `transferFrom(address,address,uint256)` | anyone | - | Move a balance within an allowance its owner gave the caller. | open | `contracts/test/ERC4626Adapter.t.sol:44` |

</details>

#### MovvaReserve

`0xa357968D9beC2b3Cc9057c4aF37431780D91287a` - `MovvaReserve`, `contracts/movva/MovvaReserve.sol`. Holds the USDT backing Movva; mints and redeems Movva for gateways at the Pyth FX rate. Principal-locked (client rule, 21 October 2026): its USDT leaves only by redemption (gateways: the off-ramp's LPs) and, above max(principal, liabilities at the target ratio), by harvestYield to the fixed yield recipient. No hedge path, no sweep, no savings path (no sMovva, no `distribute`). **Holds funds.**

- governor `0x000000000000000000000000000000000000dEaD`: **renounced** (was `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`); setup complete; delay 48 h; 0 pending change(s)
- guardian: `0x000000000000000000000000000000000000dEaD`
- gateway: `0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C`, `0xf491FA29debC0D12d8F7c57B17995C2346F025AD`
- yield recipient (payee): `0x622F626F912AD25d36D9B8F48907Ac941F755ACb`
- fee recipient (payee): `0xB81615658A4a51b4d3c2e144d492794Beb001099`
- yield vault: none
- mintPaused = `false` (gateways cannot mint)
- vaultDepositsPaused = `false` (no USDT goes into the yield vault)
- supplyCap = `1000000000000000000000000` (most Movva that may exist (1e18 = R$ 1,00))
- principalUsdt = `0` (the cost basis (USDT in by mint and recapitalize, less out by redeem): no harvest goes below it)
- EIP-1967 slots: empty (not a proxy)

- **governor** can add and remove gateways; replace the guardian, the fee recipient and (always after the delay) the yield recipient; change fees (hard caps 1% mint, 1% redeem), collateral ratios (never under 100%), the supply cap, the oracle legs and their max ages, and the yield vault; pull USDT back from the vault into the reserve; pause and resume vault deposits and minting. After setup, every change that adds risk waits GOVERNANCE_DELAY; removing, lowering and pausing are instant. It cannot mint or burn Movva itself, send the reserve's USDT anywhere (principal-locked: pullFromVault only brings it back into the reserve; only redeem and harvestYield pay out), pause redemptions, or pass the hard fee caps. (`contracts/movva/MovvaReserve.sol:623`, `contracts/movva/MovvaReserve.sol:631`, `contracts/movva/MovvaReserve.sol:640`, `contracts/movva/MovvaReserve.sol:646`, `contracts/movva/MovvaReserve.sol:654`, `contracts/movva/MovvaReserve.sol:666`, …)
- **guardian** can pause minting, at once. It cannot resume minting (governor only) or do anything else. (`contracts/movva/MovvaReserve.sol:742`)
- **gateway** can mint Movva for USDT it pays in, and redeem Movva for USDT, at the oracle rate less fees, within the supply cap and the mint collateral floor. The gateways are the institutional LPs that settle the off-ramp: a redemption is the only way the principal leaves. It cannot mint without paying in. A wrong rate inside the oracle bounds is the residual risk the contract names: it is why only contracted gateways mint and redeem. (`contracts/movva/MovvaReserve.sol:479`, `contracts/movva/MovvaReserve.sol:527`)

<details><summary>22 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x0000…dEaD` governor, renounced, guardian | `contracts/common/DelayedGovernance.sol:166` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced, guardian | `contracts/common/DelayedGovernance.sol:137` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced, guardian | `contracts/common/DelayedGovernance.sol:181` |
| `harvestYield()` | anyone | - | Anyone: pay `harvestableYield()` to `yieldRecipient`, pulling from the yield vault as needed. <sub>(NatSpec)</sub> | open | `contracts/movva/MovvaReserve.sol:564` |
| `mint(uint256,address,uint256)` | a gateway (key) | - | Gateway only: deposit USDT, receive Movva worth it at the oracle rate, less the mint fee. <sub>(NatSpec)</sub> | `0x3ce8…3f5C` gateway<br>`0xf491…25AD` gateway | `contracts/movva/MovvaReserve.sol:479` |
| `pauseMint()` | the guardian or the governor (key) | instant | Guardian or governor: stop minting. There is no pause for redemptions; see "Who can stop a redemption" in the header for what can stop one. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced, guardian | `contracts/movva/MovvaReserve.sol:742` |
| `pullFromVault(uint256)` | the governor (key) | instant | Instant, governor only: bring `usdt` back from the vault into the reserve, and stop depositing into it until `setVaultDepositsPaused(false)`. `type(uint256).max` redeems every share. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced, guardian | `contracts/movva/MovvaReserve.sol:714` |
| `recapitalize(uint256)` | anyone | - | Anyone: add USDT without minting. It becomes principal. <sub>(NatSpec)</sub> | open | `contracts/movva/MovvaReserve.sol:604` |
| `redeem(uint256,address,uint256)` | a gateway (key) | - | Gateway only: burn Movva, receive USDT worth min(1, collateral ratio) of it, less the redeem fee. <sub>(NatSpec)</sub> | `0x3ce8…3f5C` gateway<br>`0xf491…25AD` gateway | `contracts/movva/MovvaReserve.sol:527` |
| `resumeMint()` | the governor (key) | instant | Resume minting. | `0x0000…dEaD` governor, renounced, guardian | `contracts/movva/MovvaReserve.sol:748` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x0000…dEaD` governor, renounced, guardian | `contracts/common/DelayedGovernance.sol:155` |
| `setCollateralRatios(uint16,uint16)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | LOWERING a ratio is delayed (it lets value out at less backing); raising is instant. Neither may be below 100%, and the mint floor may not exceed the target. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced, guardian | `contracts/movva/MovvaReserve.sol:666` |
| `setFeeRecipient(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Delayed: this address is paid every fee. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced, guardian | `contracts/movva/MovvaReserve.sol:646` |
| `setFees(uint16,uint16)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Raising either fee is delayed; lowering is instant. Hard caps apply either way. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced, guardian | `contracts/movva/MovvaReserve.sol:654` |
| `setGateway(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Adding a gateway waits out the delay; removing one is instant. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced, guardian | `contracts/movva/MovvaReserve.sol:623` |
| `setGuardian(address)` | the governor (key) | instant | Instant: the guardian can only pause minting. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced, guardian | `contracts/movva/MovvaReserve.sol:631` |
| `setOracle(address,address,uint64,uint64)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Repointing either leg or lengthening a max age is delayed; only tightening an age is instant, and never below `MIN_USDT_USD_MAX_AGE` / `MIN_FX_MAX_AGE` (SRM1-20). The rate prices every mint and red... <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced, guardian | `contracts/movva/MovvaReserve.sol:685` |
| `setSupplyCap(uint256)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Raising the supply cap is delayed; lowering it is instant. A cap of zero stops minting. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced, guardian | `contracts/movva/MovvaReserve.sol:675` |
| `setVaultDepositsPaused(bool)` | the governor (key) | instant | Instant either way: the vault was chosen through the delay, and exits are unaffected. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced, guardian | `contracts/movva/MovvaReserve.sol:734` |
| `setYieldRecipient(address)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Always delayed, in either direction: this address is the only place yield is paid, and there is no "safer" value to move it to at once (client rule, 21 October 2026). <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced, guardian | `contracts/movva/MovvaReserve.sol:640` |
| `setYieldVault(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Choose the yield vault. A new vault is delayed; removing it (zero) is instant. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced, guardian | `contracts/movva/MovvaReserve.sol:698` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x0000…dEaD` governor, renounced, guardian | `contracts/common/DelayedGovernance.sol:143` |

</details>

#### Movva (token)

`0xdDb321e26e4e77432fA3E160431f25cCB4700Fa2` - `Movva`, `contracts/movva/Movva.sol`. The Movva ERC-20 (R$ 1,00). Its only minter is the MovvaReserve that deployed it.

- minter (RESERVE, immutable): `0xa357968D9beC2b3Cc9057c4aF37431780D91287a`
- EIP-1967 slots: empty (not a proxy)

- **RESERVE** can mint to anyone, and burn its own balance. It cannot burn anyone else's Movva. No owner, no pause, no blacklist, no upgrade. (`contracts/movva/Movva.sol:49`, `contracts/movva/Movva.sol:55`)

<details><summary>6 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `approve(address,uint256)` | anyone | - | Set an allowance over the caller's own balance. | open | `node_modules/@openzeppelin/contracts/token/ERC20/ERC20.sol:127` |
| `burn(uint256)` | only the MovvaReserve (immutable) | - | Reserve only: destroy `amount` of the reserve's own Movva. <sub>(NatSpec)</sub> | `0xa357…287a` minter | `contracts/movva/Movva.sol:55` |
| `mint(address,uint256)` | only the MovvaReserve (immutable) | - | Reserve only: create `amount` Movva for `to`. <sub>(NatSpec)</sub> | `0xa357…287a` minter | `contracts/movva/Movva.sol:49` |
| `permit(…)` | anyone | - | EIP-2612: set an allowance with the owner's signature. | open | `node_modules/@openzeppelin/contracts/token/ERC20/extensions/ERC20Permit.sol:44` |
| `transfer(address,uint256)` | anyone | - | Move the caller's own balance. | open | `node_modules/@openzeppelin/contracts/token/ERC20/ERC20.sol:104` |
| `transferFrom(address,address,uint256)` | anyone | - | Move a balance within an allowance its owner gave the caller. | open | `node_modules/@openzeppelin/contracts/token/ERC20/ERC20.sol:149` |

</details>

#### Movva FX leg (PythFxOracle)

`0x90474f2B222d0E0a8dfC4c4F138b041B1921F18F` - `PythFxOracle`, `contracts/ramp/PythFxOracle.sol`. The BRL/USD FX leg over Pyth's FX.USD/BRL, with a band reading for the hours the FX market is closed.

- governor `0x000000000000000000000000000000000000dEaD`: **renounced** (was `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`); setup complete; delay 48 h; 0 pending change(s)
- EIP-1967 slots: empty (not a proxy)

- **governor** can repoint the Pyth price id, and loosen or tighten the max ages and the confidence bound (loosening waits GOVERNANCE_DELAY, tightening is instant). It cannot post a price (Pyth prices are posted permissionlessly on Pyth) or change which Pyth contract it reads: PYTH is immutable. (`contracts/ramp/PythFxOracle.sol:140`, `contracts/ramp/PythFxOracle.sol:148`, `contracts/common/DelayedGovernance.sol:143`)

<details><summary>7 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:166` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:137` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:181` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:155` |
| `setFeed(bytes32)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Repointing the feed waits out the governance delay. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/PythFxOracle.sol:140` |
| `setLimits(uint64,uint64,uint16)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Loosening any limit waits out the governance delay; tightening is instant. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/PythFxOracle.sol:148` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:143` |

</details>

#### Movva band adapter (ScaledFxBandOracle)

`0xaC4c0Fe25ed07B446f8377A97f4aA175020d2B13` - `ScaledFxBandOracle`, `contracts/movva/ScaledFxBandOracle.sol`. Reads an FX leg and re-expresses it in centavos; no governance of its own: SOURCE is immutable.

- EIP-1967 slots: empty (not a proxy)

No state-changing functions.

#### FeeSplitter

`0xB81615658A4a51b4d3c2e144d492794Beb001099` - `FeeSplitter`, `contracts/movva/FeeSplitter.sol`. The reserve's fee recipient: splits Movva fee revenue between NodeRewards and Mova's treasury. **Holds funds.**

- governor `0x000000000000000000000000000000000000dEaD`: **renounced** (was `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`); setup complete; delay 48 h; 0 pending change(s)
- treasury (payee): `0x622F626F912AD25d36D9B8F48907Ac941F755ACb`
- rewards (payee): `0xe446ceA7089704e5cC746edf97F9eedeA4851FF0`
- lpRewardShareBps = `0` (the LPs' share of fee revenue)
- EIP-1967 slots: empty (not a proxy)

- **governor** can change the LPs' share (never above 50%), the treasury and the rewards contract. It cannot take what the splitter holds: `split` pays only the treasury and the rewards contract, and anyone may call it. (`contracts/movva/FeeSplitter.sol:109`, `contracts/movva/FeeSplitter.sol:117`, `contracts/movva/FeeSplitter.sol:126`, `contracts/common/DelayedGovernance.sol:143`)

<details><summary>9 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:166` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:137` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:181` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:155` |
| `setLpRewardShare(uint16)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Raising the LPs' share waits out the delay; lowering it is instant. Never above 50%. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/movva/FeeSplitter.sol:109` |
| `setRewards(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | A new rewards contract waits out the delay; removing it (zero) is instant. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/movva/FeeSplitter.sol:126` |
| `setTreasury(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Delayed: this address is paid Mova's revenue. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/movva/FeeSplitter.sol:117` |
| `split()` | anyone | - | Send everything here: the LPs' share to the rewards contract, the rest to the treasury. Anyone may call. <sub>(NatSpec)</sub> | open | `contracts/movva/FeeSplitter.sol:82` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:143` |

</details>

#### NodeRewards

`0xe446ceA7089704e5cC746edf97F9eedeA4851FF0` - `NodeRewards`, `contracts/ramp/NodeRewards.sol`. Node-provider rewards: fee revenue shared among INSTITUTIONAL and AFFILIATED LPs by settled BRL volume, epoch by epoch. **Holds funds.**

- governor `0x000000000000000000000000000000000000dEaD`: **renounced** (was `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`); setup complete; delay 48 h; 0 pending change(s)
- registry (reports settlements): `0x8a31C07b24d83908c11BE0a81ABFA465454d0344`
- excluded LP: none
- EIP-1967 slots: empty (not a proxy)

- **governor** can bind or unbind the registry, set the reward limits (within MAX_REWARD_BPS_OF_VOLUME), exclude or reinstate an LP, and void an LP's volume while its epoch is in review. It cannot pay anyone: rewards go only to LPs claiming their own shares, and voided shares roll forward instead of going to anyone else. (`contracts/ramp/NodeRewards.sol:408`, `contracts/ramp/NodeRewards.sol:419`, `contracts/ramp/NodeRewards.sol:429`, `contracts/ramp/NodeRewards.sol:441`, `contracts/common/DelayedGovernance.sol:143`)
- **registry** can report settlements, which count as volume. It cannot pay rewards. (`contracts/ramp/NodeRewards.sol:236`)

<details><summary>13 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:166` |
| `claim(uint256[],address)` | a party to that offer, order, sale, note or reward | - | Claim the caller's rewards for finalized epochs, paid to `to`. <sub>(NatSpec)</sub> | open | `contracts/ramp/NodeRewards.sol:324` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:137` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:181` |
| `finalize(uint256)` | anyone | - | Finalize up to `maxEpochs` epochs whose review has ended, oldest first. Anyone may call it. <sub>(NatSpec)</sub> | open | `contracts/ramp/NodeRewards.sol:279` |
| `onSettled(address,uint256,uint8)` | only the bound LPRegistry | - | Count a settlement's volume for the LP. | `0x8a31…0344` registry | `contracts/ramp/NodeRewards.sol:236` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:155` |
| `setExcluded(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Excluding an LP is instant; reinstating one waits out the delay. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/NodeRewards.sol:429` |
| `setRegistry(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Bind the registry whose settlement reports count; zero unbinds. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/NodeRewards.sol:408` |
| `setRewardLimits(uint16,uint256,uint256)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Raising the rate or the per-LP cap, or lowering the minimum, is delayed; the opposite of each is instant. The rate can never pass MAX_REWARD_BPS_OF_VOLUME. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/NodeRewards.sol:419` |
| `sync()` | anyone | - | Book reward tokens that arrived since the last sync into the current epoch. Anyone may call it; FeeSplitter calls it after every transfer here. <sub>(NatSpec)</sub> | open | `contracts/ramp/NodeRewards.sol:256` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:143` |
| `voidVolume(uint256,address)` | the governor (key) | instant | Instant, governor only: void `lp`'s volume for an epoch still in review, current or ended. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/NodeRewards.sol:441` |

</details>

#### Movva Privacy Pool

`0x3ac4EE315D13e9a4243954852917eAf69232a6f3` - `PrivacyPoolComplex`, `protocol/contracts/src/contracts/implementations/PrivacyPoolComplex.sol`. A Privacy Pool for an ERC-20 (Movva) (upstream 0xbow). No owner; bound to one Entrypoint and one asset at construction. **Holds funds.**

- ENTRYPOINT (immutable): `0x81d45264fbC3E1cD303891bb8f4ae9EA2DEB2CcC`
- dead = `false` (wound down: no new deposits)
- EIP-1967 slots: empty (not a proxy)

- **ENTRYPOINT** can deposit on a depositor's behalf, and wind the pool down. It cannot withdraw: that needs a note's proof, or its original depositor for ragequit. (`protocol/contracts/src/contracts/PrivacyPool.sol:82`, `protocol/contracts/src/contracts/PrivacyPool.sol:157`)

<details><summary>4 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `deposit(address,uint256,uint256)` | only the Entrypoint (immutable) | - | Deposit funds into the Privacy Pool <sub>(NatSpec)</sub> | `0x81d4…2CcC` ENTRYPOINT | `protocol/contracts/src/contracts/PrivacyPool.sol:82` |
| `ragequit((uint256[2],uint256[2][2],uint256[2],uint256[4]))` | a party to that offer, order, sale, note or reward | - | Publicly withdraw funds to original depositor without exposing secrets <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `protocol/contracts/src/contracts/PrivacyPool.sol:132` |
| `windDown()` | only the Entrypoint (immutable) | - | Irreversibly suspends deposits <sub>(NatSpec)</sub> | `0x81d4…2CcC` ENTRYPOINT | `protocol/contracts/src/contracts/PrivacyPool.sol:157` |
| `withdraw(…)` | anyone carrying a proof the contract's verifier accepts | - | Privately withdraw funds by spending an existing commitment <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `protocol/contracts/src/contracts/PrivacyPool.sol:110` |

</details>

#### Entrypoint owner (TimelockController, 7 days)

`0xeE518057F6fe17385D67c8659abc77Ac5a601ed7` - `EntrypointTimelock`, `contracts/governance/EntrypointTimelock.sol`. OpenZeppelin 5.1.0 TimelockController, unchanged (contracts/governance/EntrypointTimelock.sol adds nothing): the Entrypoint's OWNER_ROLE holder (H-02). Every call it makes waits getMinDelay() (7 days) after a proposer schedules it; the Safe is its only proposer, canceller and executor, and it administers its own roles.

- proposer: `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`
- canceller: `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`
- executor: `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`
- admin (DEFAULT_ADMIN_ROLE): `0xeE518057F6fe17385D67c8659abc77Ac5a601ed7`
- getMinDelay = `604800` (seconds every operation waits between schedule and execute)
- EIP-1967 slots: empty (not a proxy)

- **proposer / canceller / executor (the Safe)** can schedule any call from the timelock - so any Entrypoint OWNER_ROLE action: upgrade, pools, fees, roles - and run it once getMinDelay() (7 days) has passed; cancel any queued operation at once. It cannot run anything sooner than the delay, shorten the delay without waiting it, or add a proposer without a delayed operation. Every scheduled operation is public (CallScheduled) for the whole delay. (`node_modules/@openzeppelin/contracts/governance/TimelockController.sol:266`, `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:291`, `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:358`, `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:385`, `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:334`)
- **DEFAULT_ADMIN_ROLE (the timelock itself)** can grant and revoke the timelock's roles and change its delay - only through its own delayed operations. It cannot act without a proposer scheduling it: nobody else holds the admin role. (`node_modules/@openzeppelin/contracts/access/AccessControl.sol:122`, `node_modules/@openzeppelin/contracts/access/AccessControl.sol:137`, `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:449`)

<details><summary>13 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `receive()` | anyone | - | Accept ETH (it holds none for the rail). | not probed (plain ETH transfer) | `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:155` |
| `cancel(bytes32)` | a holder of the timelock's CANCELLER_ROLE (the Safe) (key) | instant | Drop a queued operation before it runs. | `0x956E…dCa1` proposer, canceller, executor | `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:334` |
| `execute(address,uint256,bytes,bytes32,bytes32)` | a holder of the timelock's EXECUTOR_ROLE (the Safe; not open) (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a queued call once its delay has passed (calls the Entrypoint as OWNER_ROLE). | `0x956E…dCa1` proposer, canceller, executor | `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:358` |
| `executeBatch(address[],uint256[],bytes[],bytes32,bytes32)` | a holder of the timelock's EXECUTOR_ROLE (the Safe; not open) (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a queued batch once its delay has passed. | `0x956E…dCa1` proposer, canceller, executor | `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:385` |
| `grantRole(bytes32,address)` | only the timelock itself, through an operation that waited its minimum delay | only once a scheduled change has waited GOVERNANCE_DELAY | Grant a timelock role. DEFAULT_ADMIN_ROLE administers every role and only the timelock holds it, so only an operation that waited the delay can. | `0xeE51…1ed7` admin | `node_modules/@openzeppelin/contracts/access/AccessControl.sol:122` |
| `onERC1155BatchReceived(…)` | anyone | - | ERC-1155 batch receiver hook. | open | `node_modules/@openzeppelin/contracts/token/ERC1155/utils/ERC1155Holder.sol:33` |
| `onERC1155Received(address,address,uint256,uint256,bytes)` | anyone | - | ERC-1155 receiver hook. | open | `node_modules/@openzeppelin/contracts/token/ERC1155/utils/ERC1155Holder.sol:23` |
| `onERC721Received(address,address,uint256,bytes)` | anyone | - | ERC-721 receiver hook: accept a token sent to the timelock. | open | `node_modules/@openzeppelin/contracts/token/ERC721/utils/ERC721Holder.sol:21` |
| `renounceRole(bytes32,address)` | only for the caller's own role | instant | Give up a timelock role the caller holds (it must name itself). | **nobody** (every probed caller refused) | `node_modules/@openzeppelin/contracts/access/AccessControl.sol:157` |
| `revokeRole(bytes32,address)` | only the timelock itself, through an operation that waited its minimum delay | only once a scheduled change has waited GOVERNANCE_DELAY | Revoke a timelock role: an operation of the timelock itself. | `0xeE51…1ed7` admin | `node_modules/@openzeppelin/contracts/access/AccessControl.sol:137` |
| `schedule(address,uint256,bytes,bytes32,bytes32,uint256)` | a holder of the timelock's PROPOSER_ROLE (the Safe) (key) | instant | Queue one call (target, value, data) to run after at least getMinDelay(). | `0x956E…dCa1` proposer, canceller, executor | `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:266` |
| `scheduleBatch(…)` | a holder of the timelock's PROPOSER_ROLE (the Safe) (key) | instant | Queue a batch of calls to run together after at least getMinDelay(). | `0x956E…dCa1` proposer, canceller, executor | `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:291` |
| `updateDelay(uint256)` | only the timelock itself, through an operation that waited its minimum delay | only once a scheduled change has waited GOVERNANCE_DELAY | Change the minimum delay: only as an operation of the timelock itself, so a shorter delay waits the current one. | `0xeE51…1ed7` admin | `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:449` |

</details>

#### AspRootQuorum (ASP postman, 2 of 3)

`0xa897FB804917715A0220339640D5e55B59b85339` - `AspRootQuorum`, `contracts/AspRootQuorum.sol`. The Entrypoint's ASP postman as an immutable THRESHOLD-of-ASP_COUNT quorum (contracts/AspRootQuorum.sol): a root reaches the Entrypoint only when THRESHOLD of the fixed ASPs voted for exactly that root and CID. No owner, no setter, no upgrade.

- ASP: `0x6f239a1A5818808E63BB6F35A88B9876a79aa973`, `0xc8510850c5bF41B52399473F234577B2d8Ef0B16`, `0x323574Eb0c63b764F06832f15B21956bb8979FC9`
- ENTRYPOINT (immutable): `0x81d45264fbC3E1cD303891bb8f4ae9EA2DEB2CcC`
- THRESHOLD = `2` (distinct ASP votes that post a root)
- ASP_COUNT = `3` (ASPs, fixed at deployment)
- round = `0` (roots posted so far; votes count only in the current round)
- EIP-1967 slots: empty (not a proxy)

- **ASP** can vote for a root and CID in the current round. THRESHOLD distinct votes for the same proposal post it to the Entrypoint at once. It cannot post a root alone (THRESHOLD is a strict majority), vote twice for one proposal, move funds, or change the ASP set or THRESHOLD: nobody can, ever. (`contracts/AspRootQuorum.sol:152`, `contracts/AspRootQuorum.sol:180`)

<details><summary>2 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `unvote(uint256,string)` | one of the ASPs fixed at deployment (key) | instant | Withdraw this ASP's live vote for `root` with `ipfsCID` in the current round - for example after it found a label it no longer approves. It then counts for nothing. <sub>(NatSpec)</sub> | `0xc851…0B16` ASP<br>`0x6f23…a973` ASP<br>`0x3235…9FC9` ASP | `contracts/AspRootQuorum.sol:180` |
| `vote(uint256,string)` | one of the ASPs fixed at deployment (key) | instant | Vote, as one of the fixed ASPs, for posting `root` with `ipfsCID`. The vote that brings the live votes to THRESHOLD posts the root to the Entrypoint in the same transaction. A lapsed vote for the s... <sub>(NatSpec)</sub> | `0x6f23…a973` ASP<br>`0x3235…9FC9` ASP<br>`0xc851…0B16` ASP | `contracts/AspRootQuorum.sol:152` |

</details>

#### LPRegistry

`0x8a31C07b24d83908c11BE0a81ABFA465454d0344` - `LPRegistry`, `contracts/ramp/LPRegistry.sol`. LP onboarding, network phases, tiers, credit and exposure across every escrow.

- governor `0x000000000000000000000000000000000000dEaD`: **renounced** (was `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`); setup complete; delay 48 h; 0 pending change(s)
- escrow: `0x3e79B0582b8EAb2FDEcFf0c9da43143e3915eB14`, `0xCCdA1AA24d45Bc673b090F80363aC38D50D0d81C`
- rewards hook: `0xe446ceA7089704e5cC746edf97F9eedeA4851FF0`
- LP (tier > NONE): `0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C`, `0xf491FA29debC0D12d8F7c57B17995C2346F025AD`
- phase = `0` (0 = A (governor-admitted institutions only), 1 = B (+ affiliates), 2 = C (+ retail))
- EIP-1967 slots: empty (not a proxy)

- **governor** can accept and drop escrows, open and close network phases, set the rewards hook, and admit, re-tier, suspend or remove LPs with their credit limits. It cannot move funds: the registry holds none. It decides how much an LP may have at risk, and which escrows may reserve it. (`contracts/ramp/LPRegistry.sol:212`, `contracts/ramp/LPRegistry.sol:221`, `contracts/ramp/LPRegistry.sol:234`, `contracts/ramp/LPRegistry.sol:252`, `contracts/common/DelayedGovernance.sol:143`)
- **escrow** can reserve and release LPs' exposure and record settlements and lost disputes. It cannot release exposure another escrow reserved. (`contracts/ramp/LPRegistry.sol:423`, `contracts/ramp/LPRegistry.sol:441`, `contracts/ramp/LPRegistry.sol:464`, `contracts/ramp/LPRegistry.sol:491`, `contracts/ramp/LPRegistry.sol:505`)

<details><summary>17 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:166` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:137` |
| `consumeBankTxId(bytes32)` | only an escrow the registry accepts | - | Spend a bank transaction id on a settlement: true the first time, false ever after, whichever escrow of this registry spent it. Only an escrow (current or retired) may call, or anyone could burn th... <sub>(NatSpec)</sub> | `0xCCdA…d81C` escrow<br>`0x3e79…eB14` escrow | `contracts/ramp/LPRegistry.sol:505` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:181` |
| `recordDispute(address)` | only an escrow the registry accepts | - | Called by the escrow when a dispute is ruled against the LP. MUST NOT revert. <sub>(NatSpec)</sub> | `0x21f4…f975` stranger<br>`0x3e79…eB14` escrow<br>`0xf491…25AD` LP<br>`0xCCdA…d81C` escrow<br>`0x3ce8…3f5C` LP<br>`0x0000…dEaD` governor, renounced<br>`0x51d8…75Eb` deployer | `contracts/ramp/LPRegistry.sol:491` |
| `recordSettled(address,uint256)` | only an escrow the registry accepts | - | Record a settlement (ignored when the caller is not an accepted escrow). | `0x21f4…f975` stranger<br>`0x3e79…eB14` escrow<br>`0xCCdA…d81C` escrow<br>`0x3ce8…3f5C` LP<br>`0xf491…25AD` LP<br>`0x0000…dEaD` governor, renounced<br>`0x51d8…75Eb` deployer | `contracts/ramp/LPRegistry.sol:464` |
| `register()` | anyone | - | Permissionless retail onboarding, Phase C only. The cap, not the gate, is the control - once the network has been opened to retail at all. <sub>(NatSpec)</sub> | open | `contracts/ramp/LPRegistry.sol:297` |
| `releaseExposure(address,uint256)` | only an escrow the registry accepts | - | Give back exposure this escrow reserved. MUST NOT revert: it runs on release and refund paths, after money has moved. <sub>(NatSpec)</sub> | `0x21f4…f975` stranger<br>`0x0000…dEaD` governor, renounced<br>`0x3ce8…3f5C` LP<br>`0x3e79…eB14` escrow<br>`0xf491…25AD` LP<br>`0xCCdA…d81C` escrow<br>`0x51d8…75Eb` deployer | `contracts/ramp/LPRegistry.sol:441` |
| `reserveExposure(address,uint256)` | only an escrow the registry accepts | - | Take on `brlCents` of exposure for `lp`, or return false if it would exceed the LP's remaining credit. Only a registered escrow may call. <sub>(NatSpec)</sub> | `0x3e79…eB14` escrow<br>`0xCCdA…d81C` escrow | `contracts/ramp/LPRegistry.sol:423` |
| `revokeAffiliate(address)` | a party to that offer, order, sale, note or reward | - | End an affiliation. The sponsor can always do this, whatever its own tier. <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/LPRegistry.sol:348` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:155` |
| `setEscrow(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Registering an escrow waits out the governance delay; removing one is instant. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/LPRegistry.sol:212` |
| `setPhase(uint8)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Open the next network phase (delayed), or close back to an earlier one (instant). <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/LPRegistry.sol:221` |
| `setRewardsHook(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Point settlement reports at a rewards contract (delayed), or stop them (zero, instant). <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/LPRegistry.sol:234` |
| `setTier(address,uint8,uint256)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Admit, re-tier or remove an LP. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/LPRegistry.sol:252` |
| `sponsorAffiliate(address,uint256)` | an INSTITUTIONAL LP, from Phase B | - | Sponsor an affiliated LP, or change its credit. Phase B onwards; caller must be an active INSTITUTIONAL LP. <sub>(NatSpec)</sub> | open | `contracts/ramp/LPRegistry.sol:314` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:143` |

</details>

#### ReclaimZkTlsVerifier (PIX, boleto, TED)

`0x84ae5FFC1F84b19498cE5a376200709b4df55508` - `ReclaimZkTlsVerifier`, `contracts/ramp/ReclaimZkTlsVerifier.sol`. PIX and boleto verifier: Reclaim zkTLS claims of the payer's own bank session, signed by a threshold of witnesses.

- governor `0x000000000000000000000000000000000000dEaD`: **renounced** (was `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`); setup complete; delay 48 h; 0 pending change(s)
- witness: `0x05EfF3D8e0ad59Aa8abFd94E0b08402ec0850Fbf`, `0x8771D8B0038061D7872e4c2C69cD63F54380CBAb`, `0x72C1a86B73Ca01Fec5e07160AE14a32849eE5214`
- bank endpoint (providerHash): `0xb54d2a19bba3a502dc449c083cd2579885618e4e0487435aae1673f06baf0c05`, `0xd8d90d629dc91348bf69c3c5148cd5bf1efdc99220a15a6f42d6ad42eeb2bb20`, `0x8259a0510dbf7425215eada80e9a8fcc1bac48d4e24e3cea67b5185b482abf77`, `0xf02c2badc915c0c690ccba5dd00202b6efcc3d49a1c1197db4026f075aaddc1a`
- threshold = `2` (witness signatures needed)
- witnessCount = `3` (witnesses)
- endpointCount = `4` (allowed bank endpoints)
- EIP-1967 slots: empty (not a proxy)

- **governor** can add and remove witnesses, change the threshold, allow and revoke bank endpoints, the rails each may attest and whether its PIX payments must carry the order's txid (adding, allowing, lowering and dropping the txid requirement wait; removing, revoking, raising and requiring are instant). It cannot prove a payment itself, unless it adds itself as witnesses through the delay. (`contracts/ramp/ReclaimZkTlsVerifier.sol:674`, `contracts/ramp/ReclaimZkTlsVerifier.sol:685`, `contracts/ramp/ReclaimZkTlsVerifier.sol:697`, `contracts/ramp/ReclaimZkTlsVerifier.sol:705`, `contracts/ramp/ReclaimZkTlsVerifier.sol:722`, `contracts/ramp/ReclaimZkTlsVerifier.sol:743`, …)
- **witness** can sign Reclaim claims: `threshold` of them prove that a bank session on an allowed endpoint showed the payment. It cannot vouch for an endpoint the governor has not allowed, or a rail the endpoint may not attest.

<details><summary>11 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `allowEndpoint(bytes32,string)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Allow a bank endpoint: the template's Reclaim `providerHash` and the URL prefix its `url` must start with. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/ReclaimZkTlsVerifier.sol:697` |
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:166` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:137` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:181` |
| `revokeEndpoint(bytes32)` | the governor (key) | instant | Revoking an endpoint is instant. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/ReclaimZkTlsVerifier.sol:705` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:155` |
| `setEndpointOrderTxid(bytes32,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Require, or stop requiring, that an endpoint's non-boleto payments carry the order's txid: the M-03 binding in the header. Set it on every endpoint whose page is a PIX credit to the LP (`pix-receiv... <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/ReclaimZkTlsVerifier.sol:743` |
| `setEndpointRails(bytes32,uint16)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Set which rails an allowlisted endpoint may attest, as a bitmask over Rail. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/ReclaimZkTlsVerifier.sol:722` |
| `setThreshold(uint256)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Lowering the threshold waits out the governance delay; raising it is instant. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/ReclaimZkTlsVerifier.sol:685` |
| `setWitness(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Adding a witness waits out the governance delay; removing one is instant. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/ReclaimZkTlsVerifier.sol:674` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:143` |

</details>

#### FiatEscrow (Movva on-ramp)

`0x3e79B0582b8EAb2FDEcFf0c9da43143e3915eB14` - `FiatEscrow`, `contracts/ramp/FiatEscrow.sol`. On-ramp escrow: an LP escrows crypto in an offer; a taker locks an order, pays BRL, and the crypto is released on a proof of payment. **Holds funds.**

- governor `0x000000000000000000000000000000000000dEaD`: **renounced** (was `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`); setup complete; delay 48 h; 0 pending change(s)
- arbitrator: `0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7`
- allowed verifier: `0x84ae5FFC1F84b19498cE5a376200709b4df55508`
- listed asset (enabled): `0xdDb321e26e4e77432fA3E160431f25cCB4700Fa2`
- EIP-1967 slots: empty (not a proxy)

- **governor** can list and delist assets and their band oracles, allow and revoke payment verifiers, add and remove arbitrators, set asset caps. After setup, listing, allowing, adding and raising wait GOVERNANCE_DELAY; delisting, revoking, removing and lowering are instant. It cannot move an offer's liquidity or an order's funds, change an asset's decimals once set, or decide a dispute: a ruling needs an arbitrator's signature. Its power over funds is indirect: which verifiers and arbitrators the escrow believes. (`contracts/ramp/FiatEscrow.sol:534`, `contracts/ramp/FiatEscrow.sol:1206`, `contracts/ramp/FiatEscrow.sol:1214`, `contracts/ramp/FiatEscrow.sol:1226`, `contracts/common/DelayedGovernance.sol:143`, `contracts/common/DelayedGovernance.sol:155`, …)
- **arbitrator** can sign a ruling on a DISPUTED order: RELEASE to the taker's named recipient, or REFUND to the LP (its offer; its own address after a taker's dispute). Anyone submits it; it executes only after RULING_DELAY (1 day), re-verified then, and before DISPUTE_TIMEOUT. A RELEASE needs an arbitrator registered no later than the dispute was raised. It cannot reach an order that is not in dispute, an LP's free liquidity, more than the disputed amount, or any payee but the order's two counterparties. (`contracts/ramp/FiatEscrow.sol:1057`)

<details><summary>24 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `receive()` | anyone | - | Accept ETH: meant for ragequit proceeds from a pool. ETH sent here any other way is credited to nobody, and no function can take it out. | not probed (plain ETH transfer) | `contracts/ramp/FiatEscrow.sol:1508` |
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:166` |
| `cancelOrder(bytes32)` | a party to that offer, order, sale, note or reward | - | Give up before paying. Returns the liquidity immediately rather than making the LP wait out the window for capital nobody is going to use. <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:866` |
| `closeOffer(bytes32)` | a party to that offer, order, sale, note or reward | - | Close an offer and return its free liquidity to the LP. The LP may always; ANYONE may once the registry gives the LP no credit at all (`capOf` zero: removed, suspended, or an affiliate whose sponso... <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:638` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:137` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:181` |
| `expireDispute(bytes32)` | anyone | - | After the dispute's timeout with no ruling (`disputeDeadline`: DISPUTE_TIMEOUT for an LP's dispute, TAKER_DISPUTE_TIMEOUT for a taker's), anyone returns the order's liquidity to the LP: to its offe... <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:1139` |
| `fundOffer(bytes32,uint256)` | a party to that offer, order, sale, note or reward | - | Add liquidity to the caller's own offer. | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:610` |
| `issueBoleto(bytes32,bytes32)` | a party to that offer, order, sale, note or reward | - | The LP commits to the boleto it registered for this order. <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:694` |
| `lockOrder(bytes32,uint256,uint8,address,uint256)` | anyone | - | Lock liquidity to pay for by PIX or TED, to the offer's key. <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:655` |
| `lockOrderByBoleto(bytes32,uint256,uint8,address,uint256)` | anyone | - | Lock liquidity to pay for by boleto. The LP must then issue one: see issueBoleto. <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:671` |
| `postOffer(…)` | an LP the registry lets quote | - | Post an offer and escrow its liquidity (the registry must let the LP quote it). | open | `contracts/ramp/FiatEscrow.sol:551` |
| `raiseDispute(bytes32,string)` | a party to that offer, order, sale, note or reward | - | Freeze an order pending arbitration. The cases this exists for are the ones no proof can settle: the taker paid but the attestor cannot produce a proof (bank downtime, an unsupported statement form... <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:977` |
| `reclaimExpired(bytes32)` | anyone | - | After the window, anyone may return unpaid liquidity to the LP. <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:913` |
| `releaseWithProof(bytes32,bytes)` | anyone carrying a proof the contract's verifier accepts | - | Present proof the BRL was paid, and take delivery. <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:800` |
| `rescueShielded(…)` | a party to that offer, order, sale, note or reward | - | The order's recipient ragequits a shielded delivery back out of the pool, to itself. | open | `contracts/ramp/FiatEscrow.sol:1176` |
| `resolveDispute(…)` | anyone carrying a registered arbitrator's signed ruling (key) | - | Submit an arbitrator's signed ruling. Anyone may submit it: the first submission posts it, and the same ruling submitted again after RULING_DELAY executes it. <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:1057` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:155` |
| `setArbitrator(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Adding an arbitrator waits out the governance delay; removing one is instant. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/FiatEscrow.sol:1214` |
| `setAsset(address,address,uint8,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | List or delist a settlement asset. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/FiatEscrow.sol:534` |
| `setAssetCap(address,uint256)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Lowering or setting a first cap is instant; raising or removing one is delayed. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/FiatEscrow.sol:1226` |
| `setVerifier(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Allowing a verifier waits out the governance delay; revoking one is instant. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/FiatEscrow.sol:1206` |
| `takeDeliveryDirect(bytes32)` | a party to that offer, order, sale, note or reward | - | Take a shielded order's delivery in the open instead, to the rescue address. A shielded delivery can become impossible after the taker has paid: the Entrypoint or the pool can be frozen by the toke... <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:894` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:143` |

</details>

#### OffRampEscrow (Movva off-ramp)

`0xCCdA1AA24d45Bc673b090F80363aC38D50D0d81C` - `OffRampEscrow`, `contracts/ramp/OffRampEscrow.sol`. Off-ramp escrow: a seller escrows crypto in a sale; an LP claims it, pays the seller BRL, and is paid the crypto on a proof. **Holds funds.**

- governor `0x000000000000000000000000000000000000dEaD`: **renounced** (was `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`); setup complete; delay 48 h; 0 pending change(s)
- arbitrator: `0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7`
- allowed verifier: `0x84ae5FFC1F84b19498cE5a376200709b4df55508`
- listed asset (enabled): `0xdDb321e26e4e77432fA3E160431f25cCB4700Fa2`
- EIP-1967 slots: empty (not a proxy)

- **governor** can list and delist assets and their band oracles, allow and revoke payment verifiers, add and remove arbitrators, set asset caps. After setup, listing, allowing, adding and raising wait GOVERNANCE_DELAY; delisting, revoking, removing and lowering are instant. It cannot move a sale's escrowed crypto, change an asset's decimals once set, or decide a dispute: a ruling needs an arbitrator's signature. Its power over funds is indirect: which verifiers and arbitrators the escrow believes. (`contracts/ramp/OffRampEscrow.sol:296`, `contracts/ramp/OffRampEscrow.sol:698`, `contracts/ramp/OffRampEscrow.sol:706`, `contracts/ramp/OffRampEscrow.sol:727`, `contracts/common/DelayedGovernance.sol:143`, `contracts/common/DelayedGovernance.sol:155`, …)
- **arbitrator** can sign a ruling on a DISPUTED sale: pay the claiming LP, or return the crypto to the seller. Anyone submits it; it executes only after RULING_DELAY (1 day), re-verified then. Paying the LP needs an arbitrator registered no later than the dispute was raised. It cannot reach a sale that is not in dispute, or pay anyone but the sale's two counterparties. (`contracts/ramp/OffRampEscrow.sol:606`)

<details><summary>18 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `abandonClaim(bytes32)` | a party to that offer, order, sale, note or reward | - | Give the claim back early, without penalty. The sale is cancellable at once and claimable again after CLAIM_COOLDOWN, by any LP, this one included. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:444` |
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:166` |
| `cancelSale(bytes32)` | a party to that offer, order, sale, note or reward | - | Withdraw a sale nobody holds a live claim on: an unclaimed one, or one whose claim is past its `payBy` (the stale claim is released first, freeing the LP's credit). Never available while a claim is... <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/OffRampEscrow.sol:381` |
| `claimSale(bytes32)` | an LP the registry lets quote | - | Take exclusivity on a sale in order to pay it. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:409` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:137` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:181` |
| `expireDispute(bytes32)` | anyone | - | After DISPUTE_TIMEOUT with no ruling, anyone returns the escrowed crypto to the seller's refund address and frees the LP's credit. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:681` |
| `openSale(…)` | anyone | - | Escrow ETH and ask for BRL. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:322` |
| `raiseDispute(bytes32,string)` | a party to that offer, order, sale, note or reward | - | Freeze a claimed sale pending arbitration. The seller may, while the claim stands; the claiming LP only while its claim is live, `block.timestamp <= payBy` (H-04). <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/OffRampEscrow.sol:557` |
| `releaseStaleClaim(bytes32)` | anyone | - | Clear a claim nobody honoured. Callable by anyone: leaving this to the seller would mean a seller without gas stays frozen. The sale is open again: cancellable at once, claimable after CLAIM_COOLDOWN. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:435` |
| `resolveDispute(…)` | anyone carrying a registered arbitrator's signed ruling (key) | - | Submit an arbitrator's signed ruling. Anyone may submit it: the first submission posts it, and the same ruling submitted again after RULING_DELAY executes it. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:606` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:155` |
| `setArbitrator(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Adding an arbitrator waits out the governance delay; removing one is instant. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/OffRampEscrow.sol:706` |
| `setAsset(address,address,uint8,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | List or delist a settlement asset. Decimals are fixed once first set. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/OffRampEscrow.sol:296` |
| `setAssetCap(address,uint256)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Lowering or setting a first cap is instant; raising or removing one is delayed. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/OffRampEscrow.sol:727` |
| `setVerifier(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Allowing a verifier waits out the governance delay; revoking one is instant. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/OffRampEscrow.sol:698` |
| `settleWithProof(bytes32,bytes)` | anyone carrying a proof the contract's verifier accepts | - | Prove the seller was paid, and collect the escrowed ETH. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:485` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:143` |

</details>

## Etherscan verification

`deployments/sepolia-movva-v4-rail/etherscan-verify.sh` holds the exact `forge verify-contract` command for each address, with its constructor arguments and linked libraries. **They were not run.** Each was dry-run instead: forge wrote the standard-JSON input it would submit (`--show-standard-json-input`), solc 0.8.28+commit.7893614a compiled it, and the result was compared with the code at the address and with the creation transaction's init code: 21 of 21 match.

Library paths are spelled through the remapping (`poseidon-solidity/PoseidonT3.sol`). Forge 0.3.0 writes any other spelling into the input as a path solc does not match. The pools then compile with unlinked placeholders, and Etherscan would not match them. The dry run fails any input whose libraries are left unlinked.

## What was NOT verified

- Etherscan itself. The verify commands were generated and dry-run offline, not submitted. The dry run repeats Etherscan's compile with the same solc, but not Etherscan's service.
- That the code is correct. This report proves which code is deployed and who can call it. Whether that code is safe is the audit's question (`docs/audit-scope.md`).
- Behaviour. No deposit, order, dispute, mint or withdrawal was executed here: the verification pass is read-only. Those flows are exercised by the Foundry and vitest suites.
- Immutable values byte by byte. They are masked in the bytecode comparison and checked through their getters by the wiring checks (Entrypoint, pools, oracles, tokens, delays, timeouts).
- The exact source text of the Privacy Pools contracts. The protocol build omits CBOR metadata (`bytecode_hash = "none"`), so for those contracts the match proves the bytecode. Their source files are hashed against the build's metadata separately.
- The Poseidon libraries' creation. They were already on the chain at deterministic addresses; their code is matched, their creation is not.
- Key custody. The inventory shows which addresses hold the remaining roles. It cannot show who holds those keys or how they are kept.
- Contracts outside the deployment: Pyth, the Chainlink feeds and their owners, CreateX and (on mainnet) USDT.
- Off-chain services: the relayer, the ASP that computes roots, the Pyth keeper and the monitor.
- Live prices. Pyth's FX.USD/BRL is stale on this chain, so the 8 checks that read it can only confirm each reader refuses it with exactly `StaleRate` (see Prices). A fresh-price read was not possible here.
