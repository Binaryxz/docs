# Verification report: Movva rail on Sepolia (MOVVA only)

Generated 2026-10-21T08:31:26.925Z by `scripts/deploy-movva-rail.ts`. Everything below was read from the chain after the deployment, and every number in it comes from the deployment JSON and `deployments/sepolia-movva-final-rail.finalize.rehearsal/privileges.json`.

> **Rehearsal, not a deployment.** The chain is an anvil fork of Sepolia (chain id 11155111) at block 11961227, and the deployer was impersonated. Nothing was broadcast to Sepolia. A real run from the same deployer nonce should produce the same addresses; it writes its own copy of this report.

## Summary

| | |
|---|---|
| Chain | Sepolia, chain id 11155111 (fork at block 11961227) |
| Commit | `2e442a40ab377d9b8a12c95ac6aafe5d6f53812f` on `phase-1-shielded-rail`, clean tree |
| Build hash | `b2545027c9f5cce3961509ba54f1e02f5d0e4f169d1cb083128aae233d2e3812` |
| Deployer | `0x4D0dF9bB92883cf5584c812EB84AABA55d688853` |
| Contracts | 21 addresses, 21 distinct contracts, 21 running this build |
| Transactions | 80, 257,306,546 gas; blocks 11952716 to 11961247 |
| Checks | **305 pass, 3 expected, 0 fail** |
| Governance | finalized: every governor handed to `0x000000000000000000000000000000000000dEaD`, the reserve's guardian too, the Entrypoint's OWNER_ROLE renounced; ASP_POSTMAN held by the AspRootQuorum alone |
| **Test keys made permanent** | **19 role(s) that remain for ever are held by seed-derived test identities, or are the illustrative zkTLS templates** (`MOVVA_FINALIZE_ALLOW_TEST_KEYS=yes-this-is-a-rehearsal`). A demonstration only: see Substitutions |

> **Finalized with test keys (SRM1-1 opt-out, `MOVVA_FINALIZE_ALLOW_TEST_KEYS=yes-this-is-a-rehearsal`).** `--finalize` normally refuses while any role that outlives it is a test identity. This run was told to proceed anyway, so the following can never be replaced or revoked by anyone:

> - zkTLS witness 0x05EfF3D8e0ad59Aa8abFd94E0b08402ec0850Fbf: witness/0 (MOVVA_TEST_KEY_SEED)
> - zkTLS witness 0x8771D8B0038061D7872e4c2C69cD63F54380CBAb: witness/1 (MOVVA_TEST_KEY_SEED)
> - zkTLS witness 0x72C1a86B73Ca01Fec5e07160AE14a32849eE5214: witness/2 (MOVVA_TEST_KEY_SEED)
> - Movva FiatEscrow arbitrator 0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7: arbitrator (recorded test identity)
> - Movva OffRampEscrow arbitrator 0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7: arbitrator (recorded test identity)
> - registry LP 0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C: lp/0, the test LP and gateway (MOVVA_TEST_KEY_SEED)
> - reserve gateway 0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C: lp/0, the test LP and gateway (MOVVA_TEST_KEY_SEED)
> - reserve treasurer 0x6C41c72A11fAf1E9FB0c462F9A3C32e3B1D26561: treasurer (recorded test identity)
> - reserve hedge treasury 0x4464eddDd3c021BFa48f5e6c7E96163056806Cdb: hedgeTreasury (recorded test identity)
> - FeeSplitter treasury 0x622F626F912AD25d36D9B8F48907Ac941F755ACb: treasury/0 (MOVVA_TEST_KEY_SEED)
> - AspRootQuorum ASP 0x6f239a1A5818808E63BB6F35A88B9876a79aa973: asp/0 (MOVVA_TEST_KEY_SEED)
> - AspRootQuorum ASP 0xc8510850c5bF41B52399473F234577B2d8Ef0B16: asp/1 (MOVVA_TEST_KEY_SEED)
> - AspRootQuorum ASP 0x323574Eb0c63b764F06832f15B21956bb8979FC9: asp/2 (MOVVA_TEST_KEY_SEED)
> - Entrypoint owner timelock proposer 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1: a 2-of-3 Safe whose owners custody/governor/signer/0 (MOVVA_TEST_KEY_SEED), custody/governor/signer/1 (MOVVA_TEST_KEY_SEED), custody/governor/signer/2 (MOVVA_TEST_KEY_SEED) are test keys
> - Entrypoint owner timelock executor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1: a 2-of-3 Safe whose owners custody/governor/signer/0 (MOVVA_TEST_KEY_SEED), custody/governor/signer/1 (MOVVA_TEST_KEY_SEED), custody/governor/signer/2 (MOVVA_TEST_KEY_SEED) are test keys
> - zkTLS endpoint 0x4c64b9b374d341ba16e93be319434f3450db8fd8ea8ee3a201253f364db722b9: URL prefix https://api.banco-lp.example/ is on a reserved test domain (RFC 2606)
> - zkTLS endpoint 0xd8d90d629dc91348bf69c3c5148cd5bf1efdc99220a15a6f42d6ad42eeb2bb20: URL prefix https://api.banco-lp.example/ is on a reserved test domain (RFC 2606)
> - zkTLS endpoint 0x8259a0510dbf7425215eada80e9a8fcc1bac48d4e24e3cea67b5185b482abf77: URL prefix https://api.banco-lp.example/ is on a reserved test domain (RFC 2606)
> - zkTLS endpoint 0xf02c2badc915c0c690ccba5dd00202b6efcc3d49a1c1197db4026f075aaddc1a: URL prefix https://api.banco-lp.example/ is on a reserved test domain (RFC 2606)
>
> Whoever holds the test seed can forge payment proofs and rule disputes on this deployment for ever. It must never hold real value.

## Substitutions

What this deployment uses in place of the production component, as the deployment JSON records it:

- USDT: a stand-in TetherLike (contracts/test/ERC4626Adapter.t.sol) - 6 decimals and Tether's isBlackListed/pause/fee surface, but mint, pause and blacklist are open to anyone. Sepolia has no canonical USDT
- USDT/USD leg: Chainlink USDC/USD on Sepolia (0xA2F78ab2355fe2f984D808B5CeE7FD0A93D5270E, ~24h heartbeat), for the reserve
- custody (MOVVA_RAIL_CUSTODY=deployments/sepolia-movva-only-custody-rehearsal.json): the reserve's guardian, treasurer and hedge treasury and the escrows' only arbitrator are that record's 2-of-3 Safes from setup, whose signers are test keys derived from the seed; witnesses, the institutional LP / Movva gateway and the treasury: test keys derived from the seed
- ASPs: the AspRootQuorum's three ASPs are test keys derived from the seed (asp/0 stands for Movva; asp/1 and asp/2 for the two independent ASPs the client has yet to confirm)
- Scope (client decisions, 14 October 2026): MOVVA only. No savings (D1: the code has no sMovva, no sMovva pool and no `distribute`; the reserve's surplus stays in it), no ETH/USDT ramp pair and no ETH or USDT band oracle. The ETH pool is upstream's, deployed by its protocol script; the product does not use it
- zkTLS endpoints: the four illustrative receipt templates of packages/ramp receiptTemplates(prefix), not a real bank's
- Privacy Pools: a fresh upstream stack owned by the deployer, not Mova's 8 September Entrypoint (its OWNER_ROLE key is not on this machine)
- Divergence breaker: none (MOVVA_BREAKER=off). Sepolia has no BRL/USD Chainlink feed or BRL stablecoin pool to read as a second price source, so this run deploys the reserve without one; the breaker is proven by its tests, not by this deployment
- FINALIZED WITH TEST KEYS (MOVVA_FINALIZE_ALLOW_TEST_KEYS=yes-this-is-a-rehearsal, SRM1-1 opt-out): the roles that remain for ever are held by seed-derived test identities, or are packages/ramp's illustrative zkTLS templates, and nobody can ever replace them - zkTLS witness 0x05EfF3D8e0ad59Aa8abFd94E0b08402ec0850Fbf: witness/0 (MOVVA_TEST_KEY_SEED); zkTLS witness 0x8771D8B0038061D7872e4c2C69cD63F54380CBAb: witness/1 (MOVVA_TEST_KEY_SEED); zkTLS witness 0x72C1a86B73Ca01Fec5e07160AE14a32849eE5214: witness/2 (MOVVA_TEST_KEY_SEED); Movva FiatEscrow arbitrator 0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7: arbitrator (recorded test identity); Movva OffRampEscrow arbitrator 0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7: arbitrator (recorded test identity); registry LP 0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C: lp/0, the test LP and gateway (MOVVA_TEST_KEY_SEED); reserve gateway 0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C: lp/0, the test LP and gateway (MOVVA_TEST_KEY_SEED); reserve treasurer 0x6C41c72A11fAf1E9FB0c462F9A3C32e3B1D26561: treasurer (recorded test identity); reserve hedge treasury 0x4464eddDd3c021BFa48f5e6c7E96163056806Cdb: hedgeTreasury (recorded test identity); FeeSplitter treasury 0x622F626F912AD25d36D9B8F48907Ac941F755ACb: treasury/0 (MOVVA_TEST_KEY_SEED); AspRootQuorum ASP 0x6f239a1A5818808E63BB6F35A88B9876a79aa973: asp/0 (MOVVA_TEST_KEY_SEED); AspRootQuorum ASP 0xc8510850c5bF41B52399473F234577B2d8Ef0B16: asp/1 (MOVVA_TEST_KEY_SEED); AspRootQuorum ASP 0x323574Eb0c63b764F06832f15B21956bb8979FC9: asp/2 (MOVVA_TEST_KEY_SEED); Entrypoint owner timelock proposer 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1: a 2-of-3 Safe whose owners custody/governor/signer/0 (MOVVA_TEST_KEY_SEED), custody/governor/signer/1 (MOVVA_TEST_KEY_SEED), custody/governor/signer/2 (MOVVA_TEST_KEY_SEED) are test keys; Entrypoint owner timelock executor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1: a 2-of-3 Safe whose owners custody/governor/signer/0 (MOVVA_TEST_KEY_SEED), custody/governor/signer/1 (MOVVA_TEST_KEY_SEED), custody/governor/signer/2 (MOVVA_TEST_KEY_SEED) are test keys; zkTLS endpoint 0x4c64b9b374d341ba16e93be319434f3450db8fd8ea8ee3a201253f364db722b9: URL prefix https://api.banco-lp.example/ is on a reserved test domain (RFC 2606); zkTLS endpoint 0xd8d90d629dc91348bf69c3c5148cd5bf1efdc99220a15a6f42d6ad42eeb2bb20: URL prefix https://api.banco-lp.example/ is on a reserved test domain (RFC 2606); zkTLS endpoint 0x8259a0510dbf7425215eada80e9a8fcc1bac48d4e24e3cea67b5185b482abf77: URL prefix https://api.banco-lp.example/ is on a reserved test domain (RFC 2606); zkTLS endpoint 0xf02c2badc915c0c690ccba5dd00202b6efcc3d49a1c1197db4026f075aaddc1a: URL prefix https://api.banco-lp.example/ is on a reserved test domain (RFC 2606). A rehearsal or testnet demonstration only: whoever holds the test seed can forge payment proofs and rule disputes on it for ever

## What was deployed, and where

| Contract | Address | Source | Source sha256 | Runtime sha256 (build) | On chain |
|---|---|---|---|---|---|
| Privacy Pools Entrypoint (proxy) | `0x73f7f0DF3D2D99014B0ef66441254b6428069CBd` | `node_modules/@openzeppelin/contracts/proxy/ERC1967/ERC1967Proxy.sol` | `03cdbd59c384fe18`… | `f1f38be5dd06d358`… | identical |
| Entrypoint implementation | `0x639C9134b89b2C11d0727C28c9485b4e08D02015` | `protocol/contracts/src/contracts/Entrypoint.sol` | `8245c32d50ae6582`… | `6408ed2ab26661a7`… | identical outside immutables |
| Withdrawal Groth16 verifier | `0x9911c1AD91E8e858a1575355D018B9865F0Bb169` | `protocol/contracts/src/contracts/verifiers/WithdrawalVerifier.sol` | `7b6991befbc9a94a`… | `77bfc587acc64f36`… | identical |
| Ragequit (commitment) Groth16 verifier | `0x68f98d2F64B90bA37FfC6bEda67285c7450b8bbC` | `protocol/contracts/src/contracts/verifiers/CommitmentVerifier.sol` | `de24f75d21d651c0`… | `ebae2d48b14ac64f`… | identical |
| ETH Privacy Pool (upstream's; unused by the product) | `0xaFB7928bd0D9a0EFbe1b190100404f5860C972d7` | `protocol/contracts/src/contracts/implementations/PrivacyPoolSimple.sol` | `f0d97040fd5bd00d`… | `92fdf5ae69da7a5d`… | identical outside immutables |
| PoseidonT3 library (pre-existing) | `0x8ffdA7Ed8B4aD98C2C34f54B76821711F4a6f2C5` | `node_modules/poseidon-solidity/PoseidonT3.sol` | `08a7493be3783816`… | `23a48ae4bae13d19`… | identical |
| PoseidonT4 library (pre-existing) | `0xe393dd7287Db9982e6f845824854Baf8b8e823AF` | `node_modules/poseidon-solidity/PoseidonT4.sol` | `289e22a19a20bcec`… | `e2f5e98664dbafbe`… | identical |
| Stand-in USDT (TetherLike) | `0x964b674998B95077A7411939508Eb1b44c49006a` | `contracts/test/ERC4626Adapter.t.sol` | `ac9bee3e80a850f4`… | `e79fadd569db876d`… | identical |
| MovvaReserve | `0xb7a8bb1cBD2348c5d27546058d2fb3435cCd11B6` | `contracts/movva/MovvaReserve.sol` | `f36a12e577ec3bb8`… | `343620768cad5d71`… | identical outside immutables |
| Movva (token) | `0x22E1e640752eB91461566B70e6D8099583588f04` | `contracts/movva/Movva.sol` | `abe9ea0c2812eb1d`… | `18f3d0777c02361a`… | identical outside immutables |
| Movva FX leg (PythFxOracle) | `0xa2D3eD9D27eb2dD85d654DF2930beC35DA6408Dc` | `contracts/ramp/PythFxOracle.sol` | `c5379bb7abb161ea`… | `87d01fe507ab8e28`… | identical outside immutables |
| Movva band adapter (ScaledFxBandOracle) | `0x903EadfB122b93F93410BF365BFD6580592bb752` | `contracts/movva/ScaledFxBandOracle.sol` | `ddd60c94d0d23dab`… | `29eef9b7be2f7574`… | identical outside immutables |
| FeeSplitter | `0xd9CDC14b8eF222fb6da29Be38f5b5aeC535f94Fc` | `contracts/movva/FeeSplitter.sol` | `b1b0eaf84b158a40`… | `bc7c97c7f8d5ea4b`… | identical outside immutables |
| NodeRewards | `0x28eCd6562C4CdD6B45Aa41e863a2621e27f5E70d` | `contracts/ramp/NodeRewards.sol` | `0c37db72b176a0a4`… | `e646ed2972a474bb`… | identical outside immutables |
| Movva Privacy Pool | `0x026Ec9F01973F219Ecc30148209e1FFb9C995DDa` | `protocol/contracts/src/contracts/implementations/PrivacyPoolComplex.sol` | `0f9c34f0bfd03a35`… | `d1e5735be46a6b62`… | identical outside immutables |
| Entrypoint owner (TimelockController, 7 days) | `0x339509214B92e788f548e3117f7149B9eA9A5316` | `contracts/governance/EntrypointTimelock.sol` | `7dc3b06555a5221c`… | `2223a8d3ec55b092`… | identical |
| AspRootQuorum (ASP postman, 2 of 3) | `0xBb7098C0465455e3C2074894Ddc6c475496909af` | `contracts/AspRootQuorum.sol` | `c3302c2b2d6f11e4`… | `b84a2e177df7b2a6`… | identical outside immutables |
| LPRegistry | `0x3C7f5f7dDF970af011f549C67C50BB7d14670248` | `contracts/ramp/LPRegistry.sol` | `e3b84eb7ba5327fd`… | `24af870f12d040c3`… | identical outside immutables |
| ReclaimZkTlsVerifier (PIX, boleto, TED) | `0x9970AF29DDFc335ad337eBF4eAe9f01800845712` | `contracts/ramp/ReclaimZkTlsVerifier.sol` | `d6ab36d018df7ed9`… | `16a8e69606673fd1`… | identical outside immutables |
| FiatEscrow (Movva on-ramp) | `0xA61613d65fD6F7cb5B59BcA2f59E649d55386e09` | `contracts/ramp/FiatEscrow.sol` | `f972608c04805c45`… | `e97dbf9e54303272`… | identical outside immutables |
| OffRampEscrow (Movva off-ramp) | `0xaff85ba17C001a7aE3A806AE5fE143dD17a47892` | `contracts/ramp/OffRampEscrow.sol` | `a5a80347f7b685b9`… | `6e8c78e63f22f027`… | identical outside immutables |

Full hashes, artifacts and constructor arguments are in the deployment JSON under `record.contracts`. ABIs: `deployments/sepolia-movva-final-rail.finalize.rehearsal/abi/` (21 files; the Entrypoint proxy's callable ABI is `Entrypoint.json`).

## Build

**Build hash `b2545027c9f5cce3961509ba54f1e02f5d0e4f169d1cb083128aae233d2e3812`**: sha256 over the concatenated runtime bytecode (artifact deployedBytecode, library placeholders as 20 zero bytes, immutables as compiled) of every distinct deployed contract, sorted by its hex. Recompute it from a checkout of the commit with `npx tsx scripts/deployment-record.ts build-hash <deployment.json>` after `forge build` in the repo root and in `protocol/contracts`.

| Contract | Build | Runtime bytes | Runtime sha256 |
|---|---|---:|---|
| AspRootQuorum | root | 2,691 | `b84a2e177df7b2a6efe5726f408f6278977a4b2ed198fbe5eb69f5f6025bf6b4` |
| CommitmentVerifier | protocol | 1,582 | `ebae2d48b14ac64f45fd3df64ea84a60145ec212916915548cf93a7651b80f23` |
| Entrypoint | protocol | 13,490 | `6408ed2ab26661a75035495c8676b15f9f44321fcf9b611a811efb3c82be7395` |
| EntrypointTimelock | root | 7,143 | `2223a8d3ec55b0925ea6995ef2411df618db27317959330126024e1c7f59c814` |
| ERC1967Proxy | protocol | 122 | `f1f38be5dd06d358ef10a9010c1b52388094c454ae2b594351c124196c631df2` |
| FeeSplitter | root | 5,169 | `bc7c97c7f8d5ea4b5f2889dbab2b0e7fa67ff0e077eacd9c5eaa45810ec81161` |
| FiatEscrow | root | 24,576 | `e97dbf9e5430327271211cffd5a530fbba53200d05e7e404e7ec1e21d779b6fa` |
| LPRegistry | root | 10,180 | `24af870f12d040c36d3226e3644b7ddf00bb94fd2e74c6aadb7fb6a7d27bf679` |
| Movva | root | 4,516 | `18f3d0777c02361a2824fa09b856fbd3b69d603202599ccf8fd5aa015f0c7425` |
| MovvaReserve | root | 21,268 | `343620768cad5d7173afa19f7f23edb19113661ef9f3150237ee8b33dbed6413` |
| NodeRewards | root | 9,967 | `e646ed2972a474bbac7725144377ee6876523c4c0a29d7b2acd2f155bba3c340` |
| OffRampEscrow | root | 19,753 | `6e8c78e63f22f027514a218af553f4a251d17826e29bae2a5ee135839fa26b9a` |
| PoseidonT3 | protocol | 23,522 | `23a48ae4bae13d19ecdb8321c33ae70c31bd5b1c37972bc673f2d073b6026fb6` |
| PoseidonT4 | protocol | 12,584 | `e2f5e98664dbafbeb3b29dfaf490adad71c401b9fa5076c9e0b1efd853d59071` |
| PrivacyPoolComplex | protocol | 7,720 | `d1e5735be46a6b62a4e7e72e1372455087813ac08eec4f1d9880b4d23e185216` |
| PrivacyPoolSimple | protocol | 7,378 | `92fdf5ae69da7a5d9a6beaa4074806c821cbabc887dfecee95576c93e4b1c57a` |
| PythFxOracle | root | 6,130 | `87d01fe507ab8e282dcce4e3c5d33ad9355ba3a874597f00202c0f8662cec739` |
| ReclaimZkTlsVerifier | root | 15,246 | `16a8e69606673fd16a8c4d3f047c0b0cbc9f8d3cbaf324944a70c0b3f073f47e` |
| ScaledFxBandOracle | root | 770 | `29eef9b7be2f757447a6acaf5533270f9013c322761574801b0c83a2246672c5` |
| TetherLike | root | 2,317 | `e79fadd569db876d684e98898b0dbb7e61268a04cdc3d34c4f8a22aa52e9ee46` |
| WithdrawalVerifier | protocol | 1,947 | `77bfc587acc64f361df684b77293f84073e4894b61bd870fc078510562fb7bb8` |

| Build | Config | Compiler | Optimizer | EVM | viaIR | Metadata hash |
|---|---|---|---|---|---|---|
| protocol | `protocol/contracts/foundry.toml` | 0.8.28+commit.7893614a (sha256 9a0fb7e0db2c0641…) | on, 10000 runs | cancun | false | none (no CBOR) |
| root | `foundry.toml` | 0.8.28+commit.7893614a (sha256 9a0fb7e0db2c0641…) | on, 1000 runs | cancun | false | ipfs |

Forge: `forge 0.3.0 (5a8bd89 2024-12-19T17:17:10.245193696Z)`. Sources: 117 files compiled into the deployed contracts, every one identical on disk to the keccak256 its build recorded.

## Checks

Every check the verification pass ran, grouped: 305 pass, 3 expected, 0 fail. "Expected" is only ever a price refusal the check predicted exactly (see Prices).

### Code at every address (22 pass)

<details><summary>22 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | code at protocol.entrypoint | 0x73f7f0DF3D2D99014B0ef66441254b6428069CBd |
| pass | code at protocol.entrypointImplementation | 0x639C9134b89b2C11d0727C28c9485b4e08D02015 |
| pass | code at protocol.withdrawalVerifier | 0x9911c1AD91E8e858a1575355D018B9865F0Bb169 |
| pass | code at protocol.commitmentVerifier | 0x68f98d2F64B90bA37FfC6bEda67285c7450b8bbC |
| pass | code at protocol.ethPool | 0xaFB7928bd0D9a0EFbe1b190100404f5860C972d7 |
| pass | code at protocol.poseidonT3 | 0x8ffdA7Ed8B4aD98C2C34f54B76821711F4a6f2C5 |
| pass | code at protocol.poseidonT4 | 0xe393dd7287Db9982e6f845824854Baf8b8e823AF |
| pass | code at standInUsdt | 0x964b674998B95077A7411939508Eb1b44c49006a |
| pass | code at movva.reserve | 0xb7a8bb1cBD2348c5d27546058d2fb3435cCd11B6 |
| pass | code at movva.token | 0x22E1e640752eB91461566B70e6D8099583588f04 |
| pass | code at movva.fxLeg | 0xa2D3eD9D27eb2dD85d654DF2930beC35DA6408Dc |
| pass | code at movva.bandAdapter | 0x903EadfB122b93F93410BF365BFD6580592bb752 |
| pass | code at movva.feeSplitter | 0xd9CDC14b8eF222fb6da29Be38f5b5aeC535f94Fc |
| pass | code at movva.nodeRewards | 0x28eCd6562C4CdD6B45Aa41e863a2621e27f5E70d |
| pass | code at pools.movva | 0x026Ec9F01973F219Ecc30148209e1FFb9C995DDa |
| pass | code at asp.quorum | 0xBb7098C0465455e3C2074894Ddc6c475496909af |
| pass | code at ramp.registry | 0x3C7f5f7dDF970af011f549C67C50BB7d14670248 |
| pass | code at ramp.zktls | 0x9970AF29DDFc335ad337eBF4eAe9f01800845712 |
| pass | code at ramp.movvaOnramp | 0xA61613d65fD6F7cb5B59BcA2f59E649d55386e09 |
| pass | code at ramp.movvaOfframp | 0xaff85ba17C001a7aE3A806AE5fE143dD17a47892 |
| pass | code at ownership.timelock | 0x339509214B92e788f548e3117f7149B9eA9A5316 |
| pass | code at ownership.safe | 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |

</details>

### Governance: governor, setup, delay (24 pass)

<details><summary>24 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | MovvaReserve governor (renounced) | 0x000000000000000000000000000000000000dEaD |
| pass | MovvaReserve setupComplete | true |
| pass | MovvaReserve GOVERNANCE_DELAY | 172800 |
| pass | Movva FX leg (PythFxOracle) governor (renounced) | 0x000000000000000000000000000000000000dEaD |
| pass | Movva FX leg (PythFxOracle) setupComplete | true |
| pass | Movva FX leg (PythFxOracle) GOVERNANCE_DELAY | 172800 |
| pass | FeeSplitter governor (renounced) | 0x000000000000000000000000000000000000dEaD |
| pass | FeeSplitter setupComplete | true |
| pass | FeeSplitter GOVERNANCE_DELAY | 172800 |
| pass | NodeRewards governor (renounced) | 0x000000000000000000000000000000000000dEaD |
| pass | NodeRewards setupComplete | true |
| pass | NodeRewards GOVERNANCE_DELAY | 172800 |
| pass | LPRegistry governor (renounced) | 0x000000000000000000000000000000000000dEaD |
| pass | LPRegistry setupComplete | true |
| pass | LPRegistry GOVERNANCE_DELAY | 172800 |
| pass | ReclaimZkTlsVerifier governor (renounced) | 0x000000000000000000000000000000000000dEaD |
| pass | ReclaimZkTlsVerifier setupComplete | true |
| pass | ReclaimZkTlsVerifier GOVERNANCE_DELAY | 172800 |
| pass | Movva FiatEscrow governor (renounced) | 0x000000000000000000000000000000000000dEaD |
| pass | Movva FiatEscrow setupComplete | true |
| pass | Movva FiatEscrow GOVERNANCE_DELAY | 172800 |
| pass | Movva OffRampEscrow governor (renounced) | 0x000000000000000000000000000000000000dEaD |
| pass | Movva OffRampEscrow setupComplete | true |
| pass | Movva OffRampEscrow GOVERNANCE_DELAY | 172800 |

</details>

### owner (6 pass)

<details><summary>6 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | Entrypoint OWNER_ROLE held by the TimelockController (H-02) | true |
| pass | Entrypoint OWNER_ROLE: the deployer renounced it | false |
| pass | Entrypoint DEFAULT_ADMIN_ROLE: not the deployer | false |
| pass | Entrypoint: the TimelockController is the only OWNER_ROLE holder and the deployer holds no role (every RoleGranted account re-checked) | OWNER_ROLE 0x339509214B92e788f548e3117f7149B9eA9A5316 |
| pass | TimelockController getMinDelay (7 days) | 604800 |
| pass | TimelockController: the Safe 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 alone proposes, cancels and executes; executor not open; it administers itself | PROPOSER, CANCELLER, EXECUTOR: the Safe; DEFAULT_ADMIN: the timelock |

</details>

### Privacy Pools: Entrypoint roles and pools (7 pass)

<details><summary>7 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | Entrypoint: upstream's ETH pool removed (M-18) | 0x0000000000000000000000000000000000000000 |
| pass | upstream's ETH pool wound down (dead) | true |
| pass | Entrypoint holds no MOVVA fees | 0 units |
| pass | Entrypoint holds no ETH | 0 wei |
| pass | Entrypoint Movva pool (as the clean-up set it) | 0x026Ec9F01973F219Ecc30148209e1FFb9C995DDa,1000000000000000000,10,100 |
| pass | Movva pool ENTRYPOINT | 0x73f7f0DF3D2D99014B0ef66441254b6428069CBd |
| pass | Movva pool ASSET | 0x22E1e640752eB91461566B70e6D8099583588f04 |

</details>

### ASP postman: the AspRootQuorum (12 pass)

<details><summary>12 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | AspRootQuorum ENTRYPOINT | 0x73f7f0DF3D2D99014B0ef66441254b6428069CBd |
| pass | AspRootQuorum THRESHOLD | 2 |
| pass | AspRootQuorum ASP_COUNT | 3 |
| pass | AspRootQuorum asps() are the recorded ASPs, in order | 0x6f239a1A5818808E63BB6F35A88B9876a79aa973,0xc8510850c5bF41B52399473F234577B2d8Ef0B16,0x323574Eb0c63b764F06832f15B21956bb8979FC9 |
| pass | the recorded ASPs are the seed's asp/0..2 (asp/0 = Movva; asp/1, asp/2 stand-ins) | 0x6f239a1A5818808E63BB6F35A88B9876a79aa973,0xc8510850c5bF41B52399473F234577B2d8Ef0B16,0x323574Eb0c63b764F06832f15B21956bb8979FC9 |
| pass | AspRootQuorum isAsp(asp/0) | true |
| pass | AspRootQuorum isAsp(asp/1) | true |
| pass | AspRootQuorum isAsp(asp/2) | true |
| pass | AspRootQuorum isAsp(deployer) is false | false |
| pass | Entrypoint ASP_POSTMAN held by the AspRootQuorum | true |
| pass | Entrypoint ASP_POSTMAN revoked from the deployer | false |
| pass | Entrypoint ASP_POSTMAN held by the quorum only (every RoleGranted account re-checked) | 0xBb7098C0465455e3C2074894Ddc6c475496909af |

</details>

### Movva: reserve, FX leg, fees, rewards (23 pass)

<details><summary>23 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | reserve MOVVA | 0x22E1e640752eB91461566B70e6D8099583588f04 |
| pass | token RESERVE | 0xb7a8bb1cBD2348c5d27546058d2fb3435cCd11B6 |
| pass | reserve USDT (stand-in) | 0x964b674998B95077A7411939508Eb1b44c49006a |
| pass | reserve USDT/USD feed (Chainlink USDC/USD) | 0xA2F78ab2355fe2f984D808B5CeE7FD0A93D5270E |
| pass | reserve FX oracle | 0xa2D3eD9D27eb2dD85d654DF2930beC35DA6408Dc |
| pass | reserve has no distribute() (D1: no savings path) | reverts with no data |
| pass | reserve has no previewDistribute() (D1: no savings path) | reverts with no data |
| pass | reserve has no savings() (D1: no savings path) | reverts with no data |
| pass | reserve has no distributionFeeBps() (D1: no savings path) | reverts with no data |
| pass | reserve guardian (renounced) | 0x000000000000000000000000000000000000dEaD |
| pass | reserve mintPaused | false |
| pass | reserve fee recipient is the FeeSplitter | 0xd9CDC14b8eF222fb6da29Be38f5b5aeC535f94Fc |
| pass | reserve fees (mint, redeem bps) | 10,10 |
| pass | reserve supply cap | 1000000000000000000000000 |
| pass | reserve gateway: test LP | true |
| pass | Movva FX leg PYTH | 0xDd24F84d36BF92C65F92307595335bdFab5Bbd21 |
| pass | Movva FX leg usdBrlId | 0xd2db4dbf1aea74e0f666b0e8f73b9580d407f5e5cf931940b06dc633d7a95906 |
| pass | Movva FX leg maxAge / closedMaxAge / maxConfBps | 3600,345600,100 |
| pass | Movva band adapter SOURCE | 0xa2D3eD9D27eb2dD85d654DF2930beC35DA6408Dc |
| pass | FeeSplitter rewards | 0x28eCd6562C4CdD6B45Aa41e863a2621e27f5E70d |
| pass | FeeSplitter treasury | 0x622F626F912AD25d36D9B8F48907Ac941F755ACb |
| pass | NodeRewards REWARD_TOKEN | 0x22E1e640752eB91461566B70e6D8099583588f04 |
| pass | NodeRewards bound to the registry | 0x3C7f5f7dDF970af011f549C67C50BB7d14670248 |

</details>

### Ramp wiring: registry, escrows, oracles (23 pass)

<details><summary>23 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | registry phase (0 = A) | 0 |
| pass | registry rewards hook | 0x28eCd6562C4CdD6B45Aa41e863a2621e27f5E70d |
| pass | registry accepts Movva FiatEscrow | true |
| pass | Movva FiatEscrow allows the zkTLS verifier | true |
| pass | Movva FiatEscrow arbitrator | true |
| pass | Movva FiatEscrow dispute timeout | 2592000 |
| pass | registry accepts Movva OffRampEscrow | true |
| pass | Movva OffRampEscrow allows the zkTLS verifier | true |
| pass | Movva OffRampEscrow arbitrator | true |
| pass | Movva OffRampEscrow dispute timeout | 2592000 |
| pass | registry: test LP is INSTITUTIONAL with its credit | tier 3, 5000000 centavos |
| pass | registry: extra LP 0xf491FA29debC0D12d8F7c57B17995C2346F025AD is INSTITUTIONAL with its credit | tier 3, 5000000 centavos |
| pass | Movva FiatEscrow Entrypoint / Movva pool | 0x73f7f0DF3D2D99014B0ef66441254b6428069CBd,0x026Ec9F01973F219Ecc30148209e1FFb9C995DDa |
| pass | Movva FiatEscrow BAND_BPS | 300 |
| pass | Movva FiatEscrow lists Movva (reserve, 18, enabled) | 0xb7a8bb1cBD2348c5d27546058d2fb3435cCd11B6,18,true |
| pass | Movva FiatEscrow native ETH delisted | false |
| pass | Movva FiatEscrow stand-in USDT not listed | false |
| pass | Movva FiatEscrow ORACLE (constructor; seeds only the delisted native-ETH entry) | 0xb7a8bb1cBD2348c5d27546058d2fb3435cCd11B6 |
| pass | Movva OffRampEscrow BAND_BPS | 300 |
| pass | Movva OffRampEscrow lists Movva (reserve, 18, enabled) | 0xb7a8bb1cBD2348c5d27546058d2fb3435cCd11B6,18,true |
| pass | Movva OffRampEscrow native ETH delisted | false |
| pass | Movva OffRampEscrow stand-in USDT not listed | false |
| pass | Movva OffRampEscrow ORACLE (constructor; seeds only the delisted native-ETH entry) | 0xb7a8bb1cBD2348c5d27546058d2fb3435cCd11B6 |

</details>

### Verifiers: who proves what (7 pass)

<details><summary>7 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | ReclaimZkTlsVerifier provesBankSession | true |
| pass | zktls witnesses + threshold | true |
| pass | zktls endpointCount | 4 |
| pass | zktls endpoint pix-received (rails, prefix) | 2,https://api.banco-lp.example/ |
| pass | zktls endpoint pix-sent (rails, prefix) | 2,https://api.banco-lp.example/ |
| pass | zktls endpoint boleto-received (rails, prefix) | 4,https://api.banco-lp.example/ |
| pass | zktls endpoint boleto-paid (rails, prefix) | 4,https://api.banco-lp.example/ |

</details>

### Prices: Chainlink freshness and the Pyth leg (5 pass, 3 expected)

<details><summary>8 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | Chainlink USDC/USD fresh for its max age | 99983259 (8 dp), 36658 s old, max 90000 |
| expected | Pyth FX.USD/BRL on Sepolia | publishTime 1792529999, 41459 s old at block 11961247; core session closed |
| expected | Movva FX leg brlCentsPerUnit (the rate) | StaleRate(1792529999) - Pyth's FX.USD/BRL is stale |
| pass | Movva FX leg brlCentsPerUnitForBand | answered 0x00000000000000000000000000000000000000000000000000000000004cb8e6000000000000000000000000000000000000000000000000000000006ad87842 |
| pass | Movva band adapter brlCentsPerUnit | answered 0x00000000000000000000000000000000000000000000000000000000000001f7000000000000000000000000000000000000000000000000000000006ad87842 |
| expected | reserve brlPerUsdtE18 (mint/redeem rate) | StaleRate(1792529999) - Pyth's FX.USD/BRL is stale |
| pass | reserve bandBrlPerUsdtE18 (Movva band) | answered 0x00000000000000000000000000000000000000000000000045c44d756dd1e220000000000000000000000000000000000000000000000000000000006ad87842 |
| pass | reserve brlCentsPerUnit (the Movva pair's band) | answered 0x0000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000006ad87842 |

</details>

### Bytecode: each address runs this commit's build (42 pass)

<details><summary>42 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | every source file the deployed contracts were compiled from is the file on disk (keccak256 in the build metadata) | 117 files |
| pass | the commit is clean for every build input | 2e442a40ab377d9b8a12c95ac6aafe5d6f53812f, tree clean |
| pass | no build input changed during the run | HEAD moved from 2e442a40ab377d9b8a12c95ac6aafe5d6f53812f to a3b8a9510eb0f6ae5ac20c8df91ebfdf8d41e07e; the 215 file(s) that differ (README.md, contracts/governance/EntrypointTimelock.sol, contracts/script/DeployMovva.s.sol, contracts/script/DeployRamp.s.sol, contracts/test/DeployMovva.t.sol, contracts/test/EntrypointTimelock.t.sol, deployments/mainnet-movva-rail.rehearsal.json, deployments/mainnet- |
| pass | Privacy Pools Entrypoint (proxy) runs the build's ERC1967Proxy | 0x73f7f0DF3D2D99014B0ef66441254b6428069CBd: 122 bytes, identical |
| pass | Privacy Pools Entrypoint (proxy): creation code is the build's, followed by its constructor arguments | tx 0xa733dfd89858580a000b105c3a98d8f149d94c0b3437ca5553e63cd4003b5350 (createx), 192 bytes of arguments |
| pass | Entrypoint implementation runs the build's Entrypoint | 0x639C9134b89b2C11d0727C28c9485b4e08D02015: 13490 bytes, identical outside 3 immutable site(s) (96 bytes masked) |
| pass | Entrypoint implementation: creation code is the build's, followed by its constructor arguments | tx 0x3d8ce39b24938d77c3992417da8e5e5c2dda6e50b9bca5c96a854c743b817e25 (createx), 0 bytes of arguments |
| pass | Withdrawal Groth16 verifier runs the build's WithdrawalVerifier | 0x9911c1AD91E8e858a1575355D018B9865F0Bb169: 1947 bytes, identical |
| pass | Withdrawal Groth16 verifier: creation code is the build's, followed by its constructor arguments | tx 0x7f12131bb8a09ff9c687434dc3f3b63b8b9b30b0ea4cc69839d4c21800d7c6ec (createx), 0 bytes of arguments |
| pass | Ragequit (commitment) Groth16 verifier runs the build's CommitmentVerifier | 0x68f98d2F64B90bA37FfC6bEda67285c7450b8bbC: 1582 bytes, identical |
| pass | Ragequit (commitment) Groth16 verifier: creation code is the build's, followed by its constructor arguments | tx 0x7bfb345fe0514c1ce37e3237a8c8df76e44cf7baccb80eb50b48f6a8f54a2c28 (createx), 0 bytes of arguments |
| pass | ETH Privacy Pool (upstream's; unused by the product) runs the build's PrivacyPoolSimple | 0xaFB7928bd0D9a0EFbe1b190100404f5860C972d7: 7378 bytes, identical outside 12 immutable site(s) (384 bytes masked) |
| pass | ETH Privacy Pool (upstream's; unused by the product): creation code is the build's, followed by its constructor arguments | tx 0x0cc85cd7a4e1525bb7d802bcac28c2e0be3c3cbe669854a6880c0c16f51603b6 (createx), 96 bytes of arguments |
| pass | PoseidonT3 library runs the build's PoseidonT3 | 0x8ffdA7Ed8B4aD98C2C34f54B76821711F4a6f2C5: 23522 bytes, identical |
| pass | PoseidonT4 library runs the build's PoseidonT4 | 0xe393dd7287Db9982e6f845824854Baf8b8e823AF: 12584 bytes, identical |
| pass | Stand-in USDT (TetherLike) runs the build's TetherLike | 0x964b674998B95077A7411939508Eb1b44c49006a: 2317 bytes, identical |
| pass | Stand-in USDT (TetherLike): creation code is the build's, followed by its constructor arguments | tx 0x8231914fe37572538e61d6c008a83bfe3020d5c99c2f5d3111311c3f7e9dfb83 (create), 0 bytes of arguments |
| pass | MovvaReserve runs the build's MovvaReserve | 0xb7a8bb1cBD2348c5d27546058d2fb3435cCd11B6: 21268 bytes, identical outside 35 immutable site(s) (1120 bytes masked) |
| pass | MovvaReserve: creation code is the build's, followed by its constructor arguments | tx 0xa447f2bcab28fd323767bf141080e4123502cfb2bb8c6046a4116704a614fc2a (create), 448 bytes of arguments |
| pass | Movva (token) runs the build's Movva | 0x22E1e640752eB91461566B70e6D8099583588f04: 4516 bytes, identical outside 10 immutable site(s) (320 bytes masked) |
| pass | Movva FX leg (PythFxOracle) runs the build's PythFxOracle | 0xa2D3eD9D27eb2dD85d654DF2930beC35DA6408Dc: 6130 bytes, identical outside 5 immutable site(s) (160 bytes masked) |
| pass | Movva FX leg (PythFxOracle): creation code is the build's, followed by its constructor arguments | tx 0x44cbf7a8d589c958bc25f9c4486f9639f61fbf5eb0949a96a5708c4bfa07419a (create), 224 bytes of arguments |
| pass | Movva band adapter (ScaledFxBandOracle) runs the build's ScaledFxBandOracle | 0x903EadfB122b93F93410BF365BFD6580592bb752: 770 bytes, identical outside 2 immutable site(s) (64 bytes masked) |
| pass | Movva band adapter (ScaledFxBandOracle): creation code is the build's, followed by its constructor arguments | tx 0x6750f6079ff198bb1235c45d75867a6b90343be425d4dce9e14aee0685880362 (create), 32 bytes of arguments |
| pass | FeeSplitter runs the build's FeeSplitter | 0xd9CDC14b8eF222fb6da29Be38f5b5aeC535f94Fc: 5169 bytes, identical outside 8 immutable site(s) (256 bytes masked) |
| pass | FeeSplitter: creation code is the build's, followed by its constructor arguments | tx 0x356e042d4a2581c800f7a3561e8953a0824ef877dd9390ffd6b7688aaccb2587 (create), 160 bytes of arguments |
| pass | NodeRewards runs the build's NodeRewards | 0x28eCd6562C4CdD6B45Aa41e863a2621e27f5E70d: 9967 bytes, identical outside 23 immutable site(s) (736 bytes masked) |
| pass | NodeRewards: creation code is the build's, followed by its constructor arguments | tx 0xd64ad9b41b2a9057d64b2dbfaa622daa96239ea45520e8f05148f68a6e7314ea (create), 192 bytes of arguments |
| pass | Movva Privacy Pool runs the build's PrivacyPoolComplex | 0x026Ec9F01973F219Ecc30148209e1FFb9C995DDa: 7720 bytes, identical outside 14 immutable site(s) (448 bytes masked) |
| pass | Movva Privacy Pool: creation code is the build's, followed by its constructor arguments | tx 0xed080a5352efb7d575c2d6b51487891bd1ac1eb647805331b9e11a63dd117ae0 (createx), 128 bytes of arguments |
| pass | Entrypoint owner (TimelockController, 7 days) runs the build's EntrypointTimelock | 0x339509214B92e788f548e3117f7149B9eA9A5316: 7143 bytes, identical |
| pass | Entrypoint owner (TimelockController, 7 days): creation code is the build's, followed by its constructor arguments | tx 0xb016c3163b7dce0f5e067c35d8f538e2535794f180e8d0973d4123c57bfaba66 (create), 256 bytes of arguments |
| pass | AspRootQuorum (ASP postman, 2 of 3) runs the build's AspRootQuorum | 0xBb7098C0465455e3C2074894Ddc6c475496909af: 2691 bytes, identical outside 7 immutable site(s) (224 bytes masked) |
| pass | AspRootQuorum (ASP postman, 2 of 3): creation code is the build's, followed by its constructor arguments | tx 0x666bc6f67e97c2db74e7d5f61aa27c30ba86d7c562f7ab7f90409770da016251 (create), 256 bytes of arguments |
| pass | LPRegistry runs the build's LPRegistry | 0x3C7f5f7dDF970af011f549C67C50BB7d14670248: 10180 bytes, identical outside 3 immutable site(s) (96 bytes masked) |
| pass | LPRegistry: creation code is the build's, followed by its constructor arguments | tx 0xb8dbfb1a430c895fe574e0cf4c1c6cc29893a10d4cfc30e9968ed9c071d7cb10 (create), 64 bytes of arguments |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED) runs the build's ReclaimZkTlsVerifier | 0x9970AF29DDFc335ad337eBF4eAe9f01800845712: 15246 bytes, identical outside 3 immutable site(s) (96 bytes masked) |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): creation code is the build's, followed by its constructor arguments | tx 0x0da8b8ed920a5274941e4631f7ac7b38e4ef2e9a34fb32d1f5c6e1525ec5442e (create), 896 bytes of arguments |
| pass | FiatEscrow (Movva on-ramp) runs the build's FiatEscrow | 0xA61613d65fD6F7cb5B59BcA2f59E649d55386e09: 24576 bytes, identical outside 27 immutable site(s) (864 bytes masked) |
| pass | FiatEscrow (Movva on-ramp): creation code is the build's, followed by its constructor arguments | tx 0x948407c62856fa13d0e105fbc32a82842df33829f47eccb9444861f554957e95 (create), 256 bytes of arguments |
| pass | OffRampEscrow (Movva off-ramp) runs the build's OffRampEscrow | 0xaff85ba17C001a7aE3A806AE5fE143dD17a47892: 19753 bytes, identical outside 23 immutable site(s) (736 bytes masked) |
| pass | OffRampEscrow (Movva off-ramp): creation code is the build's, followed by its constructor arguments | tx 0x83f041d84b6ee6751c48e64032467462f2218bf193c0b140f0901706c782f895 (create), 192 bytes of arguments |

</details>

### Etherscan readiness (dry run, nothing submitted) (21 pass)

<details><summary>21 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | Privacy Pools Entrypoint (proxy): the verify-contract input recompiles to the code at the address | 8 sources, runs 10000, bytecodeHash none: runtime exact, creation code and arguments equal the creation transaction |
| pass | Entrypoint implementation: the verify-contract input recompiles to the code at the address | 27 sources, runs 10000, bytecodeHash none: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | Withdrawal Groth16 verifier: the verify-contract input recompiles to the code at the address | 1 sources, runs 10000, bytecodeHash none: runtime exact, creation code and arguments equal the creation transaction |
| pass | Ragequit (commitment) Groth16 verifier: the verify-contract input recompiles to the code at the address | 1 sources, runs 10000, bytecodeHash none: runtime exact, creation code and arguments equal the creation transaction |
| pass | ETH Privacy Pool (upstream's; unused by the product): the verify-contract input recompiles to the code at the address | 15 sources, runs 10000, bytecodeHash none: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | PoseidonT3 library: the verify-contract input recompiles to the code at the address | 1 sources, runs 10000, bytecodeHash none: runtime exact |
| pass | PoseidonT4 library: the verify-contract input recompiles to the code at the address | 1 sources, runs 10000, bytecodeHash none: runtime exact |
| pass | Stand-in USDT (TetherLike): the verify-contract input recompiles to the code at the address | 44 sources, runs 1000, bytecodeHash ipfs: runtime exact, creation code and arguments equal the creation transaction |
| pass | MovvaReserve: the verify-contract input recompiles to the code at the address | 37 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | Movva (token): the verify-contract input recompiles to the code at the address | 20 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables |
| pass | Movva FX leg (PythFxOracle): the verify-contract input recompiles to the code at the address | 6 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | Movva band adapter (ScaledFxBandOracle): the verify-contract input recompiles to the code at the address | 3 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | FeeSplitter: the verify-contract input recompiles to the code at the address | 11 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | NodeRewards: the verify-contract input recompiles to the code at the address | 17 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | Movva Privacy Pool: the verify-contract input recompiles to the code at the address | 21 sources, runs 10000, bytecodeHash none: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | Entrypoint owner (TimelockController, 7 days): the verify-contract input recompiles to the code at the address | 13 sources, runs 1000, bytecodeHash ipfs: runtime exact, creation code and arguments equal the creation transaction |
| pass | AspRootQuorum (ASP postman, 2 of 3): the verify-contract input recompiles to the code at the address | 1 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | LPRegistry: the verify-contract input recompiles to the code at the address | 4 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): the verify-contract input recompiles to the code at the address | 3 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | FiatEscrow (Movva on-ramp): the verify-contract input recompiles to the code at the address | 9 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | OffRampEscrow (Movva off-ramp): the verify-contract input recompiles to the code at the address | 8 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |

</details>

### Privileges: roles, gates, proxies (113 pass)

<details><summary>113 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | Privacy Pools Entrypoint (proxy): every state-changing function classified | 15 functions in the ABI, all in the catalog |
| pass | Privacy Pools Entrypoint (proxy): a stranger is refused by every gated function | 11 gated functions, each refused with its own error |
| pass | Privacy Pools Entrypoint (proxy): EIP-1967 implementation is the recorded one; admin and beacon slots empty | implementation 0x639C9134b89b2C11d0727C28c9485b4e08D02015, admin empty, beacon empty |
| pass | Entrypoint: OWNER_ROLE held by the recorded timelock alone (every owner action waits its delay) | 0x339509214B92e788f548e3117f7149B9eA9A5316 |
| pass | Entrypoint: the deployer passes none of its 8 owner functions | refused by every one |
| pass | Entrypoint: no DEFAULT_ADMIN_ROLE holder | none |
| pass | Entrypoint: ASP_POSTMAN held by the postman alone | 0xBb7098C0465455e3C2074894Ddc6c475496909af |
| pass | Entrypoint: no role beyond OWNER_ROLE, ASP_POSTMAN and DEFAULT_ADMIN_ROLE was ever granted | none |
| pass | Entrypoint implementation: every state-changing function classified | 15 functions in the ABI, all in the catalog |
| pass | Entrypoint implementation: a stranger is refused by every gated function | 11 gated functions, each refused with its own error |
| pass | Entrypoint implementation: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | Entrypoint implementation: initializers disabled (nobody can initialize it and take its roles) | Initializable version 18446744073709551615 |
| pass | Withdrawal Groth16 verifier: every state-changing function classified | 0 functions in the ABI, all in the catalog |
| pass | Withdrawal Groth16 verifier: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | Ragequit (commitment) Groth16 verifier: every state-changing function classified | 0 functions in the ABI, all in the catalog |
| pass | Ragequit (commitment) Groth16 verifier: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | ETH Privacy Pool (upstream's; unused by the product): every state-changing function classified | 4 functions in the ABI, all in the catalog |
| pass | ETH Privacy Pool (upstream's; unused by the product): a stranger is refused by every gated function | 2 gated functions, each refused with its own error |
| pass | ETH Privacy Pool (upstream's; unused by the product): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | PoseidonT3 library: every state-changing function classified | 0 functions in the ABI, all in the catalog |
| pass | PoseidonT3 library: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | PoseidonT4 library: every state-changing function classified | 0 functions in the ABI, all in the catalog |
| pass | PoseidonT4 library: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | Stand-in USDT (TetherLike): every state-changing function classified | 8 functions in the ABI, all in the catalog |
| pass | Stand-in USDT (TetherLike): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | MovvaReserve: every state-changing function classified | 25 functions in the ABI, all in the catalog |
| pass | MovvaReserve: a stranger is refused by every gated function | 23 gated functions, each refused with its own error |
| pass | MovvaReserve: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | MovvaReserve: no pending scheduled change | none |
| pass | MovvaReserve: no queued hedge withdrawal is left unexecuted | none |
| pass | MovvaReserve: guardian is 0x...dEaD, and nobody passes pauseMint | guardian 0x000000000000000000000000000000000000dEaD; pauseMint refused with NotGuardianOrGovernor for all 4 probed callers |
| pass | MovvaReserve: governor is 0x...dEaD, and the deployer passes none of its 19 governor functions | governor 0x000000000000000000000000000000000000dEaD |
| pass | Movva (token): every state-changing function classified | 6 functions in the ABI, all in the catalog |
| pass | Movva (token): a stranger is refused by every gated function | 2 gated functions, each refused with its own error |
| pass | Movva (token): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | Movva FX leg (PythFxOracle): every state-changing function classified | 7 functions in the ABI, all in the catalog |
| pass | Movva FX leg (PythFxOracle): a stranger is refused by every gated function | 7 gated functions, each refused with its own error |
| pass | Movva FX leg (PythFxOracle): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | Movva FX leg (PythFxOracle): no pending scheduled change | none |
| pass | Movva FX leg (PythFxOracle): governor is 0x...dEaD, and the deployer passes none of its 7 governor functions | governor 0x000000000000000000000000000000000000dEaD |
| pass | Movva band adapter (ScaledFxBandOracle): every state-changing function classified | 0 functions in the ABI, all in the catalog |
| pass | Movva band adapter (ScaledFxBandOracle): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | FeeSplitter: every state-changing function classified | 9 functions in the ABI, all in the catalog |
| pass | FeeSplitter: a stranger is refused by every gated function | 8 gated functions, each refused with its own error |
| pass | FeeSplitter: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | FeeSplitter: no pending scheduled change | none |
| pass | FeeSplitter: governor is 0x...dEaD, and the deployer passes none of its 8 governor functions | governor 0x000000000000000000000000000000000000dEaD |
| pass | NodeRewards: every state-changing function classified | 13 functions in the ABI, all in the catalog |
| pass | NodeRewards: a stranger is refused by every gated function | 10 gated functions, each refused with its own error |
| pass | NodeRewards: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | NodeRewards: no pending scheduled change | none |
| pass | NodeRewards: governor is 0x...dEaD, and the deployer passes none of its 9 governor functions | governor 0x000000000000000000000000000000000000dEaD |
| pass | Movva Privacy Pool: every state-changing function classified | 4 functions in the ABI, all in the catalog |
| pass | Movva Privacy Pool: a stranger is refused by every gated function | 2 gated functions, each refused with its own error |
| pass | Movva Privacy Pool: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | Entrypoint owner (TimelockController, 7 days): every state-changing function classified | 13 functions in the ABI, all in the catalog |
| pass | Entrypoint owner (TimelockController, 7 days): a stranger is refused by every gated function | 9 gated functions, each refused with its own error |
| pass | Entrypoint owner (TimelockController, 7 days): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | AspRootQuorum (ASP postman, 2 of 3): every state-changing function classified | 2 functions in the ABI, all in the catalog |
| pass | AspRootQuorum (ASP postman, 2 of 3): a stranger is refused by every gated function | 2 gated functions, each refused with its own error |
| pass | AspRootQuorum (ASP postman, 2 of 3): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | AspRootQuorum (ASP postman, 2 of 3): its ASPs are exactly the recorded 3 | 0x6f239a1A5818808E63BB6F35A88B9876a79aa973, 0xc8510850c5bF41B52399473F234577B2d8Ef0B16, 0x323574Eb0c63b764F06832f15B21956bb8979FC9 |
| pass | AspRootQuorum (ASP postman, 2 of 3): only its ASPs pass vote | admitted: 0x6f239a1A5818808E63BB6F35A88B9876a79aa973, 0x323574Eb0c63b764F06832f15B21956bb8979FC9, 0xc8510850c5bF41B52399473F234577B2d8Ef0B16 |
| pass | LPRegistry: every state-changing function classified | 17 functions in the ABI, all in the catalog |
| pass | LPRegistry: a stranger is refused by every gated function | 11 gated functions, each refused with its own error |
| pass | LPRegistry: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | LPRegistry: no pending scheduled change | none |
| pass | LPRegistry: governor is 0x...dEaD, and the deployer passes none of its 9 governor functions | governor 0x000000000000000000000000000000000000dEaD |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): every state-changing function classified | 10 functions in the ABI, all in the catalog |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): a stranger is refused by every gated function | 10 gated functions, each refused with its own error |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): no pending scheduled change | none |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): governor is 0x...dEaD, and the deployer passes none of its 10 governor functions | governor 0x000000000000000000000000000000000000dEaD |
| pass | FiatEscrow (Movva on-ramp): every state-changing function classified | 24 functions in the ABI, all in the catalog |
| pass | FiatEscrow (Movva on-ramp): a stranger is refused by every gated function | 9 gated functions, each refused with its own error |
| pass | FiatEscrow (Movva on-ramp): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | FiatEscrow (Movva on-ramp): no pending scheduled change | none |
| pass | FiatEscrow (Movva on-ramp): governor is 0x...dEaD, and the deployer passes none of its 9 governor functions | governor 0x000000000000000000000000000000000000dEaD |
| pass | OffRampEscrow (Movva off-ramp): every state-changing function classified | 18 functions in the ABI, all in the catalog |
| pass | OffRampEscrow (Movva off-ramp): a stranger is refused by every gated function | 9 gated functions, each refused with its own error |
| pass | OffRampEscrow (Movva off-ramp): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | OffRampEscrow (Movva off-ramp): no pending scheduled change | none |
| pass | OffRampEscrow (Movva off-ramp): governor is 0x...dEaD, and the deployer passes none of its 9 governor functions | governor 0x000000000000000000000000000000000000dEaD |
| pass | ETH Privacy Pool (upstream's; unused by the product): ENTRYPOINT (immutable) is exactly the recorded set | 0x73f7f0DF3D2D99014B0ef66441254b6428069CBd |
| pass | Movva Privacy Pool: ENTRYPOINT (immutable) is exactly the recorded set | 0x73f7f0DF3D2D99014B0ef66441254b6428069CBd |
| pass | Entrypoint owner (TimelockController, 7 days): proposer is exactly the recorded set | 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | Entrypoint owner (TimelockController, 7 days): canceller is exactly the recorded set | 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | Entrypoint owner (TimelockController, 7 days): executor is exactly the recorded set | 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 |
| pass | Entrypoint owner (TimelockController, 7 days): admin (DEFAULT_ADMIN_ROLE) is exactly the recorded set | 0x339509214B92e788f548e3117f7149B9eA9A5316 |
| pass | AspRootQuorum (ASP postman, 2 of 3): ASP is exactly the recorded set | 0x6f239a1A5818808E63BB6F35A88B9876a79aa973, 0xc8510850c5bF41B52399473F234577B2d8Ef0B16, 0x323574Eb0c63b764F06832f15B21956bb8979FC9 |
| pass | AspRootQuorum (ASP postman, 2 of 3): ENTRYPOINT (immutable) is exactly the recorded set | 0x73f7f0DF3D2D99014B0ef66441254b6428069CBd |
| pass | MovvaReserve: guardian is exactly the recorded set | 0x000000000000000000000000000000000000dEaD |
| pass | MovvaReserve: treasurer is exactly the recorded set | 0x6C41c72A11fAf1E9FB0c462F9A3C32e3B1D26561 |
| pass | MovvaReserve: gateway is exactly the recorded set | 0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C |
| pass | MovvaReserve: hedge treasury (payee) is exactly the recorded set | 0x4464eddDd3c021BFa48f5e6c7E96163056806Cdb |
| pass | MovvaReserve: fee recipient (payee) is exactly the recorded set | 0xd9CDC14b8eF222fb6da29Be38f5b5aeC535f94Fc |
| pass | MovvaReserve: yield vault is exactly the recorded set | none |
| pass | Movva (token): minter (RESERVE, immutable) is exactly the recorded set | 0xb7a8bb1cBD2348c5d27546058d2fb3435cCd11B6 |
| pass | FeeSplitter: treasury (payee) is exactly the recorded set | 0x622F626F912AD25d36D9B8F48907Ac941F755ACb |
| pass | FeeSplitter: rewards (payee) is exactly the recorded set | 0x28eCd6562C4CdD6B45Aa41e863a2621e27f5E70d |
| pass | NodeRewards: registry (reports settlements) is exactly the recorded set | 0x3C7f5f7dDF970af011f549C67C50BB7d14670248 |
| pass | NodeRewards: excluded LP is exactly the recorded set | none |
| pass | LPRegistry: escrow is exactly the recorded set | 0xA61613d65fD6F7cb5B59BcA2f59E649d55386e09, 0xaff85ba17C001a7aE3A806AE5fE143dD17a47892 |
| pass | LPRegistry: rewards hook is exactly the recorded set | 0x28eCd6562C4CdD6B45Aa41e863a2621e27f5E70d |
| pass | LPRegistry: LP (tier > NONE) is exactly the recorded set | 0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C, 0xf491FA29debC0D12d8F7c57B17995C2346F025AD |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): witness is exactly the recorded set | 0x05EfF3D8e0ad59Aa8abFd94E0b08402ec0850Fbf, 0x8771D8B0038061D7872e4c2C69cD63F54380CBAb, 0x72C1a86B73Ca01Fec5e07160AE14a32849eE5214 |
| pass | ReclaimZkTlsVerifier (PIX, boleto, TED): bank endpoint (providerHash) is exactly the recorded set | 0x4c64b9b374d341ba16e93be319434f3450db8fd8ea8ee3a201253f364db722b9, 0xd8d90d629dc91348bf69c3c5148cd5bf1efdc99220a15a6f42d6ad42eeb2bb20, 0x8259a0510dbf7425215eada80e9a8fcc1bac48d4e24e3cea67b5185b482abf77, 0xf02c2badc915c0c690ccba5dd00202b6efcc3d49a1c1197db4026f075aaddc1a |
| pass | FiatEscrow (Movva on-ramp): arbitrator is exactly the recorded set | 0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7 |
| pass | FiatEscrow (Movva on-ramp): allowed verifier is exactly the recorded set | 0x9970AF29DDFc335ad337eBF4eAe9f01800845712 |
| pass | FiatEscrow (Movva on-ramp): listed asset (enabled) is exactly the recorded set | 0x22E1e640752eB91461566B70e6D8099583588f04 |
| pass | OffRampEscrow (Movva off-ramp): arbitrator is exactly the recorded set | 0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7 |
| pass | OffRampEscrow (Movva off-ramp): allowed verifier is exactly the recorded set | 0x9970AF29DDFc335ad337eBF4eAe9f01800845712 |
| pass | OffRampEscrow (Movva off-ramp): listed asset (enabled) is exactly the recorded set | 0x22E1e640752eB91461566B70e6D8099583588f04 |

</details>

## Privileges

Read from the chain at block 11961247, after `--finalize`; the inventory before it was taken at block 11961242. For every contract: who holds each role, what the role can and cannot do (as the contract's code says, with the lines), and which state-changing functions the chain admits each caller to. The function list is the ABI of the build, so a function nobody classified would show as UNKNOWN and fail the checks: 0 do.

Probing: every state-changing function was `eth_call`ed with zero arguments from a stranger (`0x21f474a941692095F3122E1C82b9f24EC237f975`, holds nothing), the deployer and every current holder. "Refused" means the contract's own authorization error; "admitted" means the call got past the gate (it may then revert on the zero arguments). Nothing was sent.

### What --finalize renounced

- MovvaReserve (0xb7a8bb1cBD2348c5d27546058d2fb3435cCd11B6): guardian 0xd67DDA7D07CAa45d6f8e7C1dD0a170585e6B086c -> 0x000000000000000000000000000000000000dEaD (setGuardian, instant, sent by its governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1). With the governor gone too, nobody can call pauseMint.
- MovvaReserve (0xb7a8bb1cBD2348c5d27546058d2fb3435cCd11B6): governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 -> 0x000000000000000000000000000000000000dEaD.
- Movva FX leg (PythFxOracle) (0xa2D3eD9D27eb2dD85d654DF2930beC35DA6408Dc): governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 -> 0x000000000000000000000000000000000000dEaD.
- FeeSplitter (0xd9CDC14b8eF222fb6da29Be38f5b5aeC535f94Fc): governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 -> 0x000000000000000000000000000000000000dEaD.
- NodeRewards (0x28eCd6562C4CdD6B45Aa41e863a2621e27f5E70d): governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 -> 0x000000000000000000000000000000000000dEaD.
- LPRegistry (0x3C7f5f7dDF970af011f549C67C50BB7d14670248): governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 -> 0x000000000000000000000000000000000000dEaD.
- ReclaimZkTlsVerifier (PIX, boleto, TED) (0x9970AF29DDFc335ad337eBF4eAe9f01800845712): governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 -> 0x000000000000000000000000000000000000dEaD.
- FiatEscrow (Movva on-ramp) (0xA61613d65fD6F7cb5B59BcA2f59E649d55386e09): governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 -> 0x000000000000000000000000000000000000dEaD.
- OffRampEscrow (Movva off-ramp) (0xaff85ba17C001a7aE3A806AE5fE143dD17a47892): governor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1 -> 0x000000000000000000000000000000000000dEaD.
- deployments/sepolia-final-hedge-sleeve.json subWallet (0x0121fe4ca2f134D0246D65d9B5A9073bD7eb58a1): governor 0x4D0dF9bB92883cf5584c812EB84AABA55d688853 -> 0x000000000000000000000000000000000000dEaD.
- deployments/sepolia-movva-final-permissionless.json ramp.movvaOnramp (0xF5fb3C7545839A56c6Ccc0CBFf770773323372dC): governor 0x4D0dF9bB92883cf5584c812EB84AABA55d688853 -> 0x000000000000000000000000000000000000dEaD.
- deployments/sepolia-movva-final-permissionless.json ramp.movvaOfframp (0x53354C364f04Bc2059d27bCB53cBE84cdd7232DC): governor 0x4D0dF9bB92883cf5584c812EB84AABA55d688853 -> 0x000000000000000000000000000000000000dEaD.
- Before renouncing anything: the inventory at block 11961242 passed 72/72 privilege checks and 30/30 exact-set checks against the record.
- Entrypoint ASP_POSTMAN: the recorded AspRootQuorum 0xBb7098C0465455e3C2074894Ddc6c475496909af alone, running this build's code (2691 bytes, identical outside 7 immutable site(s) (224 bytes masked)), 2 of 3 ASPs, bound to this Entrypoint.
- MovvaReserve hedge queue: no queued withdrawal left unexecuted.
- deployments/sepolia-movva-final-rail.json: names this rail but adds no contract with code on this chain beyond the rail and the records before it (a rehearsal record, or one already covered): skipped
- deployments/sepolia-final-hedge-sleeve.rehearsal.json: names this rail but adds no contract with code on this chain beyond the rail and the records before it (a rehearsal record, or one already covered): skipped
- deployments/sepolia-movva-final-permissionless.rehearsal.json: names this rail but adds no contract with code on this chain beyond the rail and the records before it (a rehearsal record, or one already covered): skipped
- deployments/sepolia-movva-final-rail.rehearsal.json: names this rail but adds no contract with code on this chain beyond the rail and the records before it (a rehearsal record, or one already covered): skipped
- deployments/sepolia-final-hedge-sleeve.json subWallet (0x0121fe4ca2f134D0246D65d9B5A9073bD7eb58a1): keeper 0x4D0dF9bB92883cf5584c812EB84AABA55d688853 stays: an EOA by design, equal to its record; it acts only inside the sleeve's immutable bounds and pays only TREASURY.
- deployments/sepolia-final-hedge-sleeve.json venue (0x0956F02fB0D74795F33D0Ff68b063B727474b33b): venue operator 0x4D0dF9bB92883cf5584c812EB84AABA55d688853 stays: an EOA by design (a simulator's price and funding feed; not governed, no delay to renounce).
- Chain scan (GovernorTransferred / SetupCompleted since block 11952716): 11 governed contract(s) found, none outside the 11 renounced here.
- Entrypoint fees: 0 MOVVA units held now; they stay collectable by the TimelockController 0x339509214B92e788f548e3117f7149B9eA9A5316 (withdrawFees(MOVVA, treasury), a 7-day operation the Safe proposes). The owner step withdrew what it held before the hand-over: 250924550880083310000 MOVVA.
- Entrypoint OWNER_ROLE: kept by the TimelockController 0x339509214B92e788f548e3117f7149B9eA9A5316 (7 days; proposer, canceller and executor 0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1). The deployer holds no Entrypoint role.
- Entrypoint ASP_POSTMAN: kept by 0xBb7098C0465455e3C2074894Ddc6c475496909af. It posts the roots every private withdrawal needs; only a 7-day timelock operation could replace it.
- 11 DelayedGovernance contracts (8 of the rail, 3 of its siblings): 11 handed to 0x000000000000000000000000000000000000dEaD now; setup completed here on 0.

**How.** Each `DelayedGovernance` governor was handed to `0x000000000000000000000000000000000000dEaD` with `transferGovernor` (`contracts/common/DelayedGovernance.sol:125`). That transfer is one step and instant, and refuses only `address(0)`. So it is a real renunciation, not a pending two-step one. No key is known for `0x000000000000000000000000000000000000dEaD`, and no contract can be deployed there. The Entrypoint's OWNER_ROLE was given up with `renounceRole`. Every role's admin is OWNER_ROLE (`protocol/contracts/src/contracts/Entrypoint.sol:81`), so nobody can grant any role again. The reserve's guardian was sent to `0x000000000000000000000000000000000000dEaD` with `setGuardian` (`contracts/movva/MovvaReserve.sol:692`) before its governor was handed over: that setter is instant even after setup (it calls `_authorizeChange(false)`) and refuses only `address(0)`. The guardian's only power is `pauseMint` (`contracts/movva/MovvaReserve.sol:822`), which only the guardian or the governor passes, so with both at `0x000000000000000000000000000000000000dEaD` nobody can pause minting. No contract change was needed for any of it.

**What that makes impossible.** Each item below is a function only the renounced key could call:

- upgrading the Entrypoint, or adding, removing, reconfiguring or winding down a pool (`protocol/contracts/src/contracts/Entrypoint.sol:308`, `protocol/contracts/src/contracts/Entrypoint.sol:183`, `protocol/contracts/src/contracts/Entrypoint.sol:256`).
- recovering vetting fees. Every deposit's vetting fee (each pool's `vettingFeeBPS`, in the Entrypoint checks above) stays in the Entrypoint for good: only OWNER_ROLE can withdraw them (`protocol/contracts/src/contracts/Entrypoint.sol:264`, `protocol/contracts/src/contracts/Entrypoint.sol:332`).
- raising a pool's relay-fee cap. A relayer quote above it reverts `RelayFeeGreaterThanMax` for good. Users can still withdraw directly, or ragequit (`protocol/contracts/src/contracts/Entrypoint.sol:157`).
- replacing or removing the ASP postman. Its admin role is OWNER_ROLE. The postman is the AspRootQuorum 0xBb7098C0465455e3C2074894Ddc6c475496909af, 2 of 3 fixed ASPs with no owner and no setter, so neither the postman nor its ASP set can ever change (`protocol/contracts/src/contracts/Entrypoint.sol:82`).
- revoking a leaked zkTLS witness key. A quorum of leaked keys can prove payments that never happened, and each such proof releases an order's crypto (`contracts/ramp/ReclaimZkTlsVerifier.sol:579`).
- revoking a leaked arbitrator key. FiatEscrow's own NatSpec says a stolen arbitrator key can drain every offer, one disputed order at a time. The one defence it names is revoking the key within RULING_DELAY (`contracts/ramp/FiatEscrow.sol:912`, `contracts/ramp/FiatEscrow.sol:1111`, `contracts/ramp/OffRampEscrow.sol:685`).
- revoking a verifier or a bank endpoint, delisting an asset, or lowering a cap on an escrow (`contracts/ramp/FiatEscrow.sol:1103`, `contracts/ramp/ReclaimZkTlsVerifier.sol:610`, `contracts/ramp/FiatEscrow.sol:472`).
- suspending a misbehaving LP, admitting a new one, or opening Phase B or C. The network stays in its current phase with its current LPs (`contracts/ramp/LPRegistry.sol:252`, `contracts/ramp/LPRegistry.sol:221`).
- pausing Movva minting, or resuming it. The guardian and the governor, the only callers of `pauseMint`, are both 0x...dEaD, and `--finalize` refuses while minting is paused, so minting stays open for good (redemptions never could be paused). The divergence breaker, where one is deployed, still halts by itself (`contracts/movva/MovvaReserve.sol:822`, `contracts/movva/MovvaReserve.sol:828`).
- adding or removing a Movva gateway. Only gateways redeem Movva for USDT, so if every gateway key is lost nobody can redeem again (`contracts/movva/MovvaReserve.sol:684`, `contracts/movva/MovvaReserve.sol:544`).
- revoking the treasurer, or repointing the reserve's oracle when Pyth retires the feed. Minting and redeeming would stop at a dead feed for good (`contracts/movva/MovvaReserve.sol:702`, `contracts/movva/MovvaReserve.sol:765`).
- voiding farmed volume or excluding an LP from node-provider rewards (`contracts/ramp/NodeRewards.sol:441`, `contracts/ramp/NodeRewards.sol:429`).
- executing any change scheduled before the handover (`contracts/common/DelayedGovernance.sol:159`).

Every "instant" brake in `docs/runbook-mainnet-deploy.md` ("If something is wrong after deployment") is one of these. After `--finalize` that table has no one to act on it. The contracts themselves never relied on a governor for users to exit: escrow timeouts refund without permission, and ragequit needs no service.

### What remains, and why

| Contract | Role | Held by |
|---|---|---|
| Privacy Pools Entrypoint (proxy) | OWNER_ROLE | `0x339509214B92e788f548e3117f7149B9eA9A5316` |
| Privacy Pools Entrypoint (proxy) | ASP_POSTMAN | `0xBb7098C0465455e3C2074894Ddc6c475496909af` |
| MovvaReserve | treasurer | `0x6C41c72A11fAf1E9FB0c462F9A3C32e3B1D26561` |
| MovvaReserve | gateway | `0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C` |
| Entrypoint owner (TimelockController, 7 days) | proposer | `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1` |
| Entrypoint owner (TimelockController, 7 days) | canceller | `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1` |
| Entrypoint owner (TimelockController, 7 days) | executor | `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1` |
| AspRootQuorum (ASP postman, 2 of 3) | ASP | `0x6f239a1A5818808E63BB6F35A88B9876a79aa973`, `0xc8510850c5bF41B52399473F234577B2d8Ef0B16`, `0x323574Eb0c63b764F06832f15B21956bb8979FC9` |
| LPRegistry | LP (tier > NONE) | `0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C`, `0xf491FA29debC0D12d8F7c57B17995C2346F025AD` |
| ReclaimZkTlsVerifier (PIX, boleto, TED) | witness | `0x05EfF3D8e0ad59Aa8abFd94E0b08402ec0850Fbf`, `0x8771D8B0038061D7872e4c2C69cD63F54380CBAb`, `0x72C1a86B73Ca01Fec5e07160AE14a32849eE5214` |
| FiatEscrow (Movva on-ramp) | arbitrator | `0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7` |
| OffRampEscrow (Movva off-ramp) | arbitrator | `0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7` |

Why each remains:

- **ASP postman** (Entrypoint `ASP_POSTMAN`). A private withdrawal must prove membership in the latest association-set root (`protocol/contracts/src/contracts/PrivacyPool.sol:59`), and only the postman posts roots (`protocol/contracts/src/contracts/Entrypoint.sol:93`). Without it, new deposits could only leave by ragequit (`protocol/contracts/src/contracts/PrivacyPool.sol:132`). It can admit or leave out deposits; it cannot move funds. The postman is the AspRootQuorum `0xBb7098C0465455e3C2074894Ddc6c475496909af`: a root is posted only when 2 of its 3 fixed ASPs (`0x6f239a1A5818808E63BB6F35A88B9876a79aa973`, `0xc8510850c5bF41B52399473F234577B2d8Ef0B16`, `0x323574Eb0c63b764F06832f15B21956bb8979FC9`) vote for it (`contracts/AspRootQuorum.sol:139`). The ASPs are the keys that remain; the set cannot change.
- **Arbitrator**, on each escrow. Some disputes no proof can settle: bank downtime, a reversed payment. A ruling reaches only a DISPUTED order and pays one of its two counterparties. A RELEASE needs an arbitrator registered before the dispute (`contracts/ramp/FiatEscrow.sol:1003`). Rulings execute a day after posting (`contracts/ramp/FiatEscrow.sol:256`). With no arbitrator, a dispute can only time out back to the LP (`contracts/ramp/FiatEscrow.sol:1042`).
- **zkTLS witnesses.** They are the proof. Their signatures are what `verifyPayment` checks, and nothing on-chain can replace them.
- **Movva gateways and treasurer.** Only gateways mint and redeem (`contracts/movva/MovvaReserve.sol:309`). The treasurer alone funds the hedge, within `hedgeLimitBps` and the withdraw floor (`contracts/movva/MovvaReserve.sol:577`). The guardian is `0x000000000000000000000000000000000000dEaD`: nobody can pause minting (`contracts/movva/MovvaReserve.sol:822`).
- **LPs** in the registry. Their tier and credit limit bound what each may have at risk.
- **Keepers: none with on-chain power.** The Pyth keeper posts prices to Pyth, which anyone may do. `split`, `sync` and `finalize` are open to anyone.
- **Bound to code, not keys:** Movva's minter (`RESERVE`, immutable), each pool's `ENTRYPOINT` (immutable), the quorum's `ENTRYPOINT`, ASP set and `THRESHOLD` (immutable), and the escrows the registry accepts.
- **Outside this deployment:** Pyth (its own governance can upgrade it), the Chainlink feeds (their proxies are owned by Chainlink), CreateX, and on mainnet Tether's USDT, which can freeze an escrow. These are trusted as they are and not inventoried here.

### Per contract

#### Privacy Pools Entrypoint (proxy)

`0x73f7f0DF3D2D99014B0ef66441254b6428069CBd` - `ERC1967Proxy` running `Entrypoint`, `protocol/contracts/src/contracts/Entrypoint.sol`. Privacy Pools' Entrypoint (upstream 0xbow, UUPS behind an ERC1967Proxy): deposits into and relays withdrawals from every pool, and holds the ASP root. **Holds funds.**

- DEFAULT_ADMIN_ROLE (admin OWNER_ROLE): **nobody**
- OWNER_ROLE (admin OWNER_ROLE): `0x339509214B92e788f548e3117f7149B9eA9A5316`
- ASP_POSTMAN (admin OWNER_ROLE): `0xBb7098C0465455e3C2074894Ddc6c475496909af`
- EIP-1967: implementation `0x639C9134b89b2C11d0727C28c9485b4e08D02015`, admin `empty`, beacon `empty`

- **OWNER_ROLE** can upgrade the Entrypoint's code; register and remove pools; change a pool's minimum deposit, vetting fee and relay-fee cap; wind a pool down; withdraw every fee the Entrypoint holds, to any address; grant and revoke every role, OWNER_ROLE included. It cannot move pooled notes without an upgrade: a withdrawal needs the note's zero-knowledge proof. With an upgrade it can: the Entrypoint's code relays every withdrawal and holds depositors' ERC-20 approvals, so an upgrade is the one path from this role to users' money. (`node_modules/@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol:92`, `protocol/contracts/src/contracts/Entrypoint.sol:183`, `protocol/contracts/src/contracts/Entrypoint.sol:220`, `protocol/contracts/src/contracts/Entrypoint.sol:239`, `protocol/contracts/src/contracts/Entrypoint.sol:256`, `protocol/contracts/src/contracts/Entrypoint.sol:264`, …)
- **ASP_POSTMAN** can publish the association-set root. A private withdrawal must prove membership in the latest root, so the postman decides which deposits may withdraw privately. It cannot move funds, or stop a depositor leaving publicly: ragequit returns a deposit to its original depositor with no root at all. (`protocol/contracts/src/contracts/Entrypoint.sol:93`)
- **DEFAULT_ADMIN_ROLE** can call nothing: no Entrypoint function checks it, and it administers no role (every role's admin is OWNER_ROLE). Listed because AccessControl defines it. It cannot be held by anyone OWNER_ROLE did not grant it to. `initialize` grants it to nobody.

<details><summary>15 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `receive()` | only the Entrypoint (immutable) | - | Accept ETH only from the registered native pool (relayed withdrawals). | not probed (plain ETH transfer) | `protocol/contracts/src/contracts/Entrypoint.sol:298` |
| `deposit(address,uint256,uint256)` | anyone | - | Make an ERC20 deposit into the Privacy Pool <sub>(NatSpec)</sub> | open | `protocol/contracts/src/contracts/Entrypoint.sol:111` |
| `deposit(uint256)` | anyone | - | Make a native asset deposit into the Privacy Pool <sub>(NatSpec)</sub> | open | `protocol/contracts/src/contracts/Entrypoint.sol:111` |
| `grantRole(bytes32,address)` | the role's admin role (OWNER_ROLE, for every role here) (key) | instant | Grant a role. OWNER_ROLE is the admin of OWNER_ROLE, ASP_POSTMAN and DEFAULT_ADMIN_ROLE. | `0x3395…5316` OWNER_ROLE | `node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol:143` |
| `initialize(address,address)` | nobody: the initializer has run (on the implementation: disabled) | - | Initializes the contract state <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:69` |
| `registerPool(address,address,uint256,uint256,uint256)` | an OWNER_ROLE holder (key) | instant | Register a Privacy Pool in the registry <sub>(NatSpec)</sub> | `0x3395…5316` OWNER_ROLE | `protocol/contracts/src/contracts/Entrypoint.sol:183` |
| `relay(…)` | anyone carrying a proof the contract's verifier accepts | - | Process a withdrawal <sub>(NatSpec)</sub> | open | `protocol/contracts/src/contracts/Entrypoint.sol:133` |
| `removePool(address)` | an OWNER_ROLE holder (key) | instant | Remove a Privacy Pool from the registry <sub>(NatSpec)</sub> | `0x3395…5316` OWNER_ROLE | `protocol/contracts/src/contracts/Entrypoint.sol:220` |
| `renounceRole(bytes32,address)` | only for the caller's own role | instant | Give up a role the caller holds (it must name itself). | **nobody** (every probed caller refused) | `node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol:178` |
| `revokeRole(bytes32,address)` | the role's admin role (OWNER_ROLE, for every role here) (key) | instant | Revoke a role from an account. | `0x3395…5316` OWNER_ROLE | `node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol:158` |
| `updatePoolConfiguration(address,uint256,uint256,uint256)` | an OWNER_ROLE holder (key) | instant | Updates the configuration of a specific pool <sub>(NatSpec)</sub> | `0x3395…5316` OWNER_ROLE | `protocol/contracts/src/contracts/Entrypoint.sol:239` |
| `updateRoot(uint256,string)` | an ASP_POSTMAN holder (key) | instant | Push a new root to the association root set <sub>(NatSpec)</sub> | `0xBb70…09af` ASP_POSTMAN | `protocol/contracts/src/contracts/Entrypoint.sol:93` |
| `upgradeToAndCall(address,bytes)` | an OWNER_ROLE holder (key) | instant | Replace the Entrypoint's code (UUPS; `_authorizeUpgrade` is onlyRole(OWNER_ROLE)). | `0x3395…5316` OWNER_ROLE | `node_modules/@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol:92` |
| `windDownPool(address)` | an OWNER_ROLE holder (key) | instant | Irreversebly halt deposits from a Privacy Pool <sub>(NatSpec)</sub> | inconclusive (bare revert): `0x3395…5316` OWNER_ROLE | `protocol/contracts/src/contracts/Entrypoint.sol:256` |
| `withdrawFees(address,address)` | an OWNER_ROLE holder (key) | instant | Withdraw fees from the Entrypoint <sub>(NatSpec)</sub> | inconclusive (bare revert): `0x3395…5316` OWNER_ROLE | `protocol/contracts/src/contracts/Entrypoint.sol:264` |

</details>

#### Entrypoint implementation

`0x639C9134b89b2C11d0727C28c9485b4e08D02015` - `Entrypoint`, `protocol/contracts/src/contracts/Entrypoint.sol`. The Entrypoint's implementation. Its own storage is never initialized (the constructor disables initializers), so no role exists in it, and `upgradeToAndCall` refuses a direct call (onlyProxy). It is code the proxy runs, not a second Entrypoint.

- EIP-1967 slots: empty (not a proxy)
- initializers disabled

<details><summary>15 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `receive()` | only the Entrypoint (immutable) | - | Accept ETH only from the registered native pool (relayed withdrawals). | not probed (plain ETH transfer) | `protocol/contracts/src/contracts/Entrypoint.sol:298` |
| `deposit(address,uint256,uint256)` | anyone | - | Make an ERC20 deposit into the Privacy Pool <sub>(NatSpec)</sub> | open | `protocol/contracts/src/contracts/Entrypoint.sol:111` |
| `deposit(uint256)` | anyone | - | Make a native asset deposit into the Privacy Pool <sub>(NatSpec)</sub> | open | `protocol/contracts/src/contracts/Entrypoint.sol:111` |
| `grantRole(bytes32,address)` | the role's admin role (OWNER_ROLE, for every role here) (key) | instant | Grant a role. OWNER_ROLE is the admin of OWNER_ROLE, ASP_POSTMAN and DEFAULT_ADMIN_ROLE. | **nobody** (every probed caller refused) | `node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol:143` |
| `initialize(address,address)` | nobody: the initializer has run (on the implementation: disabled) | - | Initializes the contract state <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:69` |
| `registerPool(address,address,uint256,uint256,uint256)` | an OWNER_ROLE holder (key) | instant | Register a Privacy Pool in the registry <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:183` |
| `relay(…)` | anyone carrying a proof the contract's verifier accepts | - | Process a withdrawal <sub>(NatSpec)</sub> | open | `protocol/contracts/src/contracts/Entrypoint.sol:133` |
| `removePool(address)` | an OWNER_ROLE holder (key) | instant | Remove a Privacy Pool from the registry <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:220` |
| `renounceRole(bytes32,address)` | only for the caller's own role | instant | Give up a role the caller holds (it must name itself). | **nobody** (every probed caller refused) | `node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol:178` |
| `revokeRole(bytes32,address)` | the role's admin role (OWNER_ROLE, for every role here) (key) | instant | Revoke a role from an account. | **nobody** (every probed caller refused) | `node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol:158` |
| `updatePoolConfiguration(address,uint256,uint256,uint256)` | an OWNER_ROLE holder (key) | instant | Updates the configuration of a specific pool <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:239` |
| `updateRoot(uint256,string)` | an ASP_POSTMAN holder (key) | instant | Push a new root to the association root set <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:93` |
| `upgradeToAndCall(address,bytes)` | an OWNER_ROLE holder (key) | instant | Replace the Entrypoint's code (UUPS; `_authorizeUpgrade` is onlyRole(OWNER_ROLE)). | **nobody** (every probed caller refused) | `node_modules/@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol:92` |
| `windDownPool(address)` | an OWNER_ROLE holder (key) | instant | Irreversebly halt deposits from a Privacy Pool <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:256` |
| `withdrawFees(address,address)` | an OWNER_ROLE holder (key) | instant | Withdraw fees from the Entrypoint <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:264` |

</details>

#### Withdrawal Groth16 verifier

`0x9911c1AD91E8e858a1575355D018B9865F0Bb169` - `WithdrawalVerifier`, `protocol/contracts/src/contracts/verifiers/WithdrawalVerifier.sol`. Groth16 verifier for withdrawal proofs: pure code, no state.

- EIP-1967 slots: empty (not a proxy)

No state-changing functions.

#### Ragequit (commitment) Groth16 verifier

`0x68f98d2F64B90bA37FfC6bEda67285c7450b8bbC` - `CommitmentVerifier`, `protocol/contracts/src/contracts/verifiers/CommitmentVerifier.sol`. Groth16 verifier for ragequit (commitment) proofs: pure code, no state.

- EIP-1967 slots: empty (not a proxy)

No state-changing functions.

#### ETH Privacy Pool (upstream's; unused by the product)

`0xaFB7928bd0D9a0EFbe1b190100404f5860C972d7` - `PrivacyPoolSimple`, `protocol/contracts/src/contracts/implementations/PrivacyPoolSimple.sol`. A Privacy Pool for native ETH (upstream 0xbow). No owner; bound to one Entrypoint and one asset at construction. **Holds funds.**

- ENTRYPOINT (immutable): `0x73f7f0DF3D2D99014B0ef66441254b6428069CBd`
- dead = `true` (wound down: no new deposits)
- EIP-1967 slots: empty (not a proxy)

- **ENTRYPOINT** can deposit on a depositor's behalf, and wind the pool down. It cannot withdraw: that needs a note's proof, or its original depositor for ragequit. (`protocol/contracts/src/contracts/PrivacyPool.sol:82`, `protocol/contracts/src/contracts/PrivacyPool.sol:157`)

<details><summary>4 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `deposit(address,uint256,uint256)` | only the Entrypoint (immutable) | - | Deposit funds into the Privacy Pool <sub>(NatSpec)</sub> | `0x73f7…9CBd` ENTRYPOINT | `protocol/contracts/src/contracts/PrivacyPool.sol:82` |
| `ragequit((uint256[2],uint256[2][2],uint256[2],uint256[4]))` | a party to that offer, order, sale, note or reward | - | Publicly withdraw funds to original depositor without exposing secrets <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `protocol/contracts/src/contracts/PrivacyPool.sol:132` |
| `windDown()` | only the Entrypoint (immutable) | - | Irreversibly suspends deposits <sub>(NatSpec)</sub> | `0x73f7…9CBd` ENTRYPOINT | `protocol/contracts/src/contracts/PrivacyPool.sol:157` |
| `withdraw(…)` | anyone carrying a proof the contract's verifier accepts | - | Privately withdraw funds by spending an existing commitment <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `protocol/contracts/src/contracts/PrivacyPool.sol:110` |

</details>

#### PoseidonT3 library

`0x8ffdA7Ed8B4aD98C2C34f54B76821711F4a6f2C5` - `PoseidonT3`, `node_modules/poseidon-solidity/PoseidonT3.sol`. Poseidon hash library (2 inputs): pure code, no state. Linked into the pools.

- EIP-1967 slots: empty (not a proxy)

No state-changing functions.

#### PoseidonT4 library

`0xe393dd7287Db9982e6f845824854Baf8b8e823AF` - `PoseidonT4`, `node_modules/poseidon-solidity/PoseidonT4.sol`. Poseidon hash library (3 inputs): pure code, no state. Linked into the pools.

- EIP-1967 slots: empty (not a proxy)

No state-changing functions.

#### Stand-in USDT (TetherLike)

`0x964b674998B95077A7411939508Eb1b44c49006a` - `TetherLike`, `contracts/test/ERC4626Adapter.t.sol`. Rehearsal stand-in for USDT (contracts/test/ERC4626Adapter.t.sol): Tether's surface, 6 decimals. NOT a mainnet contract.

- owner (receives transfer fees): `0x4D0dF9bB92883cf5584c812EB84AABA55d688853`
- paused = `false` (transfers refused)
- EIP-1967 slots: empty (not a proxy)

- **anyone** can mint, pause, blacklist and set fees: every function is open, so its balances mean nothing. It cannot be stopped: there is no owner check anywhere. It exists only because Sepolia has no canonical USDT. (`contracts/test/ERC4626Adapter.t.sol:34`, `contracts/test/ERC4626Adapter.t.sol:70`, `contracts/test/ERC4626Adapter.t.sol:62`, `contracts/test/ERC4626Adapter.t.sol:56`)

<details><summary>8 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `addBlackList(address)` | anyone | - | Blacklist an address. Open to everyone. | open | `contracts/test/ERC4626Adapter.t.sol:62` |
| `approve(address,uint256)` | anyone | - | Set an allowance over the caller's own balance. | open | `contracts/test/ERC4626Adapter.t.sol:51` |
| `mint(address,uint256)` | anyone | - | Create tokens for anyone. Open to everyone: this is a test token. | open | `contracts/test/ERC4626Adapter.t.sol:34` |
| `removeBlackList(address)` | anyone | - | Unblacklist an address. Open to everyone. | open | `contracts/test/ERC4626Adapter.t.sol:66` |
| `setParams(uint256,uint256)` | anyone | - | Set the transfer fee (< 20 bps, < 50 tokens), paid to `owner`. Open to everyone. | open | `contracts/test/ERC4626Adapter.t.sol:56` |
| `setPaused(bool)` | anyone | - | Pause or unpause transfers. Open to everyone. | open | `contracts/test/ERC4626Adapter.t.sol:70` |
| `transfer(address,uint256)` | anyone | - | Move the caller's own balance. | open | `contracts/test/ERC4626Adapter.t.sol:39` |
| `transferFrom(address,address,uint256)` | anyone | - | Move a balance within an allowance its owner gave the caller. | open | `contracts/test/ERC4626Adapter.t.sol:44` |

</details>

#### MovvaReserve

`0xb7a8bb1cBD2348c5d27546058d2fb3435cCd11B6` - `MovvaReserve`, `contracts/movva/MovvaReserve.sol`. Holds the USDT backing Movva; mints and redeems Movva for gateways at the Pyth FX rate. Its surplus stays in it: there is no savings path (no sMovva, no `distribute`). **Holds funds.**

- governor `0x000000000000000000000000000000000000dEaD`: **renounced** (was `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`); setup complete; delay 48 h; 0 pending change(s)
- guardian: `0x000000000000000000000000000000000000dEaD`
- treasurer: `0x6C41c72A11fAf1E9FB0c462F9A3C32e3B1D26561`
- gateway: `0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C`
- hedge treasury (payee): `0x4464eddDd3c021BFa48f5e6c7E96163056806Cdb`
- fee recipient (payee): `0xd9CDC14b8eF222fb6da29Be38f5b5aeC535f94Fc`
- yield vault: none
- mintPaused = `false` (gateways cannot mint)
- vaultDepositsPaused = `false` (no USDT goes into the yield vault)
- supplyCap = `1000000000000000000000000` (most Movva that may exist (1e18 = R$ 1,00))
- hedgeRequestCount = `0` (hedge withdrawals ever queued; each executes once, by anyone, and never expires (SRM1-10))
- EIP-1967 slots: empty (not a proxy)

- **governor** can add and remove gateways; replace the guardian, treasurer, hedge treasury and fee recipient; change fees (hard caps 1% mint, 1% redeem), collateral ratios (never under 100%), the supply cap and the hedge limit, the oracle legs and their max ages, and the yield vault; pull USDT back from the vault into the reserve; pause and resume vault deposits and minting. After setup, every change that adds risk waits GOVERNANCE_DELAY; removing, lowering and pausing are instant. It cannot mint or burn Movva itself, send the reserve's USDT anywhere (pullFromVault only brings it back into the reserve), pause redemptions, or pass the hard fee caps. (`contracts/movva/MovvaReserve.sol:684`, `contracts/movva/MovvaReserve.sol:692`, `contracts/movva/MovvaReserve.sol:702`, `contracts/movva/MovvaReserve.sol:709`, `contracts/movva/MovvaReserve.sol:717`, `contracts/movva/MovvaReserve.sol:725`, …)
- **guardian** can pause minting, at once. It cannot resume minting (governor only) or do anything else. (`contracts/movva/MovvaReserve.sol:822`)
- **treasurer** can send USDT to the hedge treasury, and only there: at most hedgeLimitBps (8%) of the reserve per rolling 24 hours at once, and above that only by announcing a withdrawal that anyone can execute after the queue delay (24 h), never leaving the collateral ratio under the withdraw floor (103%). It cannot choose the destination, pass the limit or the floor, or cancel, approve or reorder an announced withdrawal. (`contracts/movva/MovvaReserve.sol:577`, `contracts/movva/MovvaReserve.sol:619`)
- **gateway** can mint Movva for USDT it pays in, and redeem Movva for USDT, at the oracle rate less fees, within the supply cap and the mint collateral floor. It cannot mint without paying in. A wrong rate inside the oracle bounds is the residual risk the contract names: it is why only contracted gateways mint and redeem. (`contracts/movva/MovvaReserve.sol:498`, `contracts/movva/MovvaReserve.sol:544`)

<details><summary>25 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x0000…dEaD` governor, renounced, guardian | `contracts/common/DelayedGovernance.sol:145` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced, guardian | `contracts/common/DelayedGovernance.sol:119` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced, guardian | `contracts/common/DelayedGovernance.sol:159` |
| `executeHedgeWithdrawal(uint256)` | anyone | - | Pay a queued hedge withdrawal once its delay has passed. Callable by anyone, once. <sub>(NatSpec)</sub> | open | `contracts/movva/MovvaReserve.sol:637` |
| `mint(uint256,address,uint256)` | a gateway (key) | - | Gateway only: deposit USDT, receive Movva worth it at the oracle rate, less the mint fee. <sub>(NatSpec)</sub> | `0x3ce8…3f5C` gateway | `contracts/movva/MovvaReserve.sol:498` |
| `pauseMint()` | the guardian or the governor (key) | instant | Guardian or governor: stop minting. There is no pause for redemptions; see "Who can stop a redemption" in the header for what can stop one. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced, guardian | `contracts/movva/MovvaReserve.sol:822` |
| `pullFromVault(uint256)` | the governor (key) | instant | Instant, governor only: bring `usdt` back from the vault into the reserve, and stop depositing into it until `setVaultDepositsPaused(false)`. `type(uint256).max` redeems every share. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced, guardian | `contracts/movva/MovvaReserve.sol:794` |
| `queueHedgeWithdrawal(uint256)` | the treasurer (key) | - | Announce a hedge withdrawal that may exceed the daily limit. It waits `HEDGE_QUEUE_DELAY`, then ANYONE may execute it, exactly once, for exactly `usdt`, to exactly the hedge treasury as it is now. ... <sub>(NatSpec)</sub> | `0x6C41…6561` treasurer | `contracts/movva/MovvaReserve.sol:619` |
| `recapitalize(uint256)` | anyone | - | Anyone: add USDT without minting. <sub>(NatSpec)</sub> | open | `contracts/movva/MovvaReserve.sol:666` |
| `redeem(uint256,address,uint256)` | a gateway (key) | - | Gateway only: burn Movva, receive USDT worth min(1, collateral ratio) of it, less the redeem fee. <sub>(NatSpec)</sub> | `0x3ce8…3f5C` gateway | `contracts/movva/MovvaReserve.sol:544` |
| `resumeMint()` | the governor (key) | instant | Resume minting. | `0x0000…dEaD` governor, renounced, guardian | `contracts/movva/MovvaReserve.sol:828` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x0000…dEaD` governor, renounced, guardian | `contracts/common/DelayedGovernance.sol:136` |
| `setCollateralRatios(uint16,uint16,uint16)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | LOWERING a ratio is delayed (it lets value out at less backing); raising is instant. None may be below 100%, and they must stay ordered: mint floor <= withdraw floor <= target. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced, guardian | `contracts/movva/MovvaReserve.sol:740` |
| `setFeeRecipient(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Delayed: this address is paid every fee. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced, guardian | `contracts/movva/MovvaReserve.sol:717` |
| `setFees(uint16,uint16)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Raising either fee is delayed; lowering is instant. Hard caps apply either way. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced, guardian | `contracts/movva/MovvaReserve.sol:725` |
| `setGateway(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Adding a gateway waits out the delay; removing one is instant. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced, guardian | `contracts/movva/MovvaReserve.sol:684` |
| `setGuardian(address)` | the governor (key) | instant | Instant: the guardian can only pause minting. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced, guardian | `contracts/movva/MovvaReserve.sol:692` |
| `setHedgeTreasury(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Delayed: this address is where hedge withdrawals go. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced, guardian | `contracts/movva/MovvaReserve.sol:709` |
| `setLimits(uint256,uint16)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Raising the supply cap or the hedge limit is delayed; lowering either is instant. A supply cap of zero stops minting. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced, guardian | `contracts/movva/MovvaReserve.sol:754` |
| `setOracle(address,address,uint64,uint64)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Repointing either leg or lengthening a max age is delayed; only tightening an age is instant, and never below `MIN_USDT_USD_MAX_AGE` / `MIN_FX_MAX_AGE` (SRM1-20). The rate prices every mint and red... <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced, guardian | `contracts/movva/MovvaReserve.sol:765` |
| `setTreasurer(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | A new treasurer waits out the delay; revoking the role (zero) is instant. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced, guardian | `contracts/movva/MovvaReserve.sol:702` |
| `setVaultDepositsPaused(bool)` | the governor (key) | instant | Instant either way: the vault was chosen through the delay, and exits are unaffected. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced, guardian | `contracts/movva/MovvaReserve.sol:814` |
| `setYieldVault(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Choose the yield vault. A new vault is delayed; removing it (zero) is instant. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced, guardian | `contracts/movva/MovvaReserve.sol:778` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x0000…dEaD` governor, renounced, guardian | `contracts/common/DelayedGovernance.sol:125` |
| `withdrawToHedge(uint256)` | the treasurer (key) | - | Treasurer only, bounded: send USDT to the hedge treasury without breaching the withdraw floor. <sub>(NatSpec)</sub> | `0x6C41…6561` treasurer | `contracts/movva/MovvaReserve.sol:577` |

</details>

#### Movva (token)

`0x22E1e640752eB91461566B70e6D8099583588f04` - `Movva`, `contracts/movva/Movva.sol`. The Movva ERC-20 (R$ 1,00). Its only minter is the MovvaReserve that deployed it.

- minter (RESERVE, immutable): `0xb7a8bb1cBD2348c5d27546058d2fb3435cCd11B6`
- EIP-1967 slots: empty (not a proxy)

- **RESERVE** can mint to anyone, and burn its own balance. It cannot burn anyone else's Movva. No owner, no pause, no blacklist, no upgrade. (`contracts/movva/Movva.sol:49`, `contracts/movva/Movva.sol:55`)

<details><summary>6 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `approve(address,uint256)` | anyone | - | Set an allowance over the caller's own balance. | open | `node_modules/@openzeppelin/contracts/token/ERC20/ERC20.sol:127` |
| `burn(uint256)` | only the MovvaReserve (immutable) | - | Reserve only: destroy `amount` of the reserve's own Movva. <sub>(NatSpec)</sub> | `0xb7a8…11B6` minter | `contracts/movva/Movva.sol:55` |
| `mint(address,uint256)` | only the MovvaReserve (immutable) | - | Reserve only: create `amount` Movva for `to`. <sub>(NatSpec)</sub> | `0xb7a8…11B6` minter | `contracts/movva/Movva.sol:49` |
| `permit(…)` | anyone | - | EIP-2612: set an allowance with the owner's signature. | open | `node_modules/@openzeppelin/contracts/token/ERC20/extensions/ERC20Permit.sol:44` |
| `transfer(address,uint256)` | anyone | - | Move the caller's own balance. | open | `node_modules/@openzeppelin/contracts/token/ERC20/ERC20.sol:104` |
| `transferFrom(address,address,uint256)` | anyone | - | Move a balance within an allowance its owner gave the caller. | open | `node_modules/@openzeppelin/contracts/token/ERC20/ERC20.sol:149` |

</details>

#### Movva FX leg (PythFxOracle)

`0xa2D3eD9D27eb2dD85d654DF2930beC35DA6408Dc` - `PythFxOracle`, `contracts/ramp/PythFxOracle.sol`. The BRL/USD FX leg over Pyth's FX.USD/BRL, with a band reading for the hours the FX market is closed.

- governor `0x000000000000000000000000000000000000dEaD`: **renounced** (was `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`); setup complete; delay 48 h; 0 pending change(s)
- EIP-1967 slots: empty (not a proxy)

- **governor** can repoint the Pyth price id, and loosen or tighten the max ages and the confidence bound (loosening waits GOVERNANCE_DELAY, tightening is instant). It cannot post a price (Pyth prices are posted permissionlessly on Pyth) or change which Pyth contract it reads: PYTH is immutable. (`contracts/ramp/PythFxOracle.sol:140`, `contracts/ramp/PythFxOracle.sol:148`, `contracts/common/DelayedGovernance.sol:125`)

<details><summary>7 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:145` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:119` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:159` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:136` |
| `setFeed(bytes32)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Repointing the feed waits out the governance delay. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/PythFxOracle.sol:140` |
| `setLimits(uint64,uint64,uint16)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Loosening any limit waits out the governance delay; tightening is instant. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/PythFxOracle.sol:148` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:125` |

</details>

#### Movva band adapter (ScaledFxBandOracle)

`0x903EadfB122b93F93410BF365BFD6580592bb752` - `ScaledFxBandOracle`, `contracts/movva/ScaledFxBandOracle.sol`. Reads an FX leg and re-expresses it in centavos; no governance of its own: SOURCE is immutable.

- EIP-1967 slots: empty (not a proxy)

No state-changing functions.

#### FeeSplitter

`0xd9CDC14b8eF222fb6da29Be38f5b5aeC535f94Fc` - `FeeSplitter`, `contracts/movva/FeeSplitter.sol`. The reserve's fee recipient: splits Movva fee revenue between NodeRewards and Mova's treasury. **Holds funds.**

- governor `0x000000000000000000000000000000000000dEaD`: **renounced** (was `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`); setup complete; delay 48 h; 0 pending change(s)
- treasury (payee): `0x622F626F912AD25d36D9B8F48907Ac941F755ACb`
- rewards (payee): `0x28eCd6562C4CdD6B45Aa41e863a2621e27f5E70d`
- lpRewardShareBps = `0` (the LPs' share of fee revenue)
- EIP-1967 slots: empty (not a proxy)

- **governor** can change the LPs' share (never above 50%), the treasury and the rewards contract. It cannot take what the splitter holds: `split` pays only the treasury and the rewards contract, and anyone may call it. (`contracts/movva/FeeSplitter.sol:109`, `contracts/movva/FeeSplitter.sol:117`, `contracts/movva/FeeSplitter.sol:126`, `contracts/common/DelayedGovernance.sol:125`)

<details><summary>9 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:145` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:119` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:159` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:136` |
| `setLpRewardShare(uint16)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Raising the LPs' share waits out the delay; lowering it is instant. Never above 50%. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/movva/FeeSplitter.sol:109` |
| `setRewards(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | A new rewards contract waits out the delay; removing it (zero) is instant. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/movva/FeeSplitter.sol:126` |
| `setTreasury(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Delayed: this address is paid Mova's revenue. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/movva/FeeSplitter.sol:117` |
| `split()` | anyone | - | Send everything here: the LPs' share to the rewards contract, the rest to the treasury. Anyone may call. <sub>(NatSpec)</sub> | open | `contracts/movva/FeeSplitter.sol:82` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:125` |

</details>

#### NodeRewards

`0x28eCd6562C4CdD6B45Aa41e863a2621e27f5E70d` - `NodeRewards`, `contracts/ramp/NodeRewards.sol`. Node-provider rewards: fee revenue shared among INSTITUTIONAL and AFFILIATED LPs by settled BRL volume, epoch by epoch. **Holds funds.**

- governor `0x000000000000000000000000000000000000dEaD`: **renounced** (was `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`); setup complete; delay 48 h; 0 pending change(s)
- registry (reports settlements): `0x3C7f5f7dDF970af011f549C67C50BB7d14670248`
- excluded LP: none
- EIP-1967 slots: empty (not a proxy)

- **governor** can bind or unbind the registry, set the reward limits (within MAX_REWARD_BPS_OF_VOLUME), exclude or reinstate an LP, and void an LP's volume while its epoch is in review. It cannot pay anyone: rewards go only to LPs claiming their own shares, and voided shares roll forward instead of going to anyone else. (`contracts/ramp/NodeRewards.sol:408`, `contracts/ramp/NodeRewards.sol:419`, `contracts/ramp/NodeRewards.sol:429`, `contracts/ramp/NodeRewards.sol:441`, `contracts/common/DelayedGovernance.sol:125`)
- **registry** can report settlements, which count as volume. It cannot pay rewards. (`contracts/ramp/NodeRewards.sol:236`)

<details><summary>13 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:145` |
| `claim(uint256[],address)` | a party to that offer, order, sale, note or reward | - | Claim the caller's rewards for finalized epochs, paid to `to`. <sub>(NatSpec)</sub> | open | `contracts/ramp/NodeRewards.sol:324` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:119` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:159` |
| `finalize(uint256)` | anyone | - | Finalize up to `maxEpochs` epochs whose review has ended, oldest first. Anyone may call it. <sub>(NatSpec)</sub> | open | `contracts/ramp/NodeRewards.sol:279` |
| `onSettled(address,uint256,uint8)` | only the bound LPRegistry | - | Count a settlement's volume for the LP. | `0x3C7f…0248` registry | `contracts/ramp/NodeRewards.sol:236` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:136` |
| `setExcluded(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Excluding an LP is instant; reinstating one waits out the delay. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/NodeRewards.sol:429` |
| `setRegistry(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Bind the registry whose settlement reports count; zero unbinds. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/NodeRewards.sol:408` |
| `setRewardLimits(uint16,uint256,uint256)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Raising the rate or the per-LP cap, or lowering the minimum, is delayed; the opposite of each is instant. The rate can never pass MAX_REWARD_BPS_OF_VOLUME. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/NodeRewards.sol:419` |
| `sync()` | anyone | - | Book reward tokens that arrived since the last sync into the current epoch. Anyone may call it; FeeSplitter calls it after every transfer here. <sub>(NatSpec)</sub> | open | `contracts/ramp/NodeRewards.sol:256` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:125` |
| `voidVolume(uint256,address)` | the governor (key) | instant | Instant, governor only: void `lp`'s volume for an epoch still in review, current or ended. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/NodeRewards.sol:441` |

</details>

#### Movva Privacy Pool

`0x026Ec9F01973F219Ecc30148209e1FFb9C995DDa` - `PrivacyPoolComplex`, `protocol/contracts/src/contracts/implementations/PrivacyPoolComplex.sol`. A Privacy Pool for an ERC-20 (Movva) (upstream 0xbow). No owner; bound to one Entrypoint and one asset at construction. **Holds funds.**

- ENTRYPOINT (immutable): `0x73f7f0DF3D2D99014B0ef66441254b6428069CBd`
- dead = `false` (wound down: no new deposits)
- EIP-1967 slots: empty (not a proxy)

- **ENTRYPOINT** can deposit on a depositor's behalf, and wind the pool down. It cannot withdraw: that needs a note's proof, or its original depositor for ragequit. (`protocol/contracts/src/contracts/PrivacyPool.sol:82`, `protocol/contracts/src/contracts/PrivacyPool.sol:157`)

<details><summary>4 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `deposit(address,uint256,uint256)` | only the Entrypoint (immutable) | - | Deposit funds into the Privacy Pool <sub>(NatSpec)</sub> | `0x73f7…9CBd` ENTRYPOINT | `protocol/contracts/src/contracts/PrivacyPool.sol:82` |
| `ragequit((uint256[2],uint256[2][2],uint256[2],uint256[4]))` | a party to that offer, order, sale, note or reward | - | Publicly withdraw funds to original depositor without exposing secrets <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `protocol/contracts/src/contracts/PrivacyPool.sol:132` |
| `windDown()` | only the Entrypoint (immutable) | - | Irreversibly suspends deposits <sub>(NatSpec)</sub> | `0x73f7…9CBd` ENTRYPOINT | `protocol/contracts/src/contracts/PrivacyPool.sol:157` |
| `withdraw(…)` | anyone carrying a proof the contract's verifier accepts | - | Privately withdraw funds by spending an existing commitment <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `protocol/contracts/src/contracts/PrivacyPool.sol:110` |

</details>

#### Entrypoint owner (TimelockController, 7 days)

`0x339509214B92e788f548e3117f7149B9eA9A5316` - `EntrypointTimelock`, `contracts/governance/EntrypointTimelock.sol`. OpenZeppelin 5.1.0 TimelockController, unchanged (contracts/governance/EntrypointTimelock.sol adds nothing): the Entrypoint's OWNER_ROLE holder (H-02). Every call it makes waits getMinDelay() (7 days) after a proposer schedules it; the Safe is its only proposer, canceller and executor, and it administers its own roles.

- proposer: `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`
- canceller: `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`
- executor: `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`
- admin (DEFAULT_ADMIN_ROLE): `0x339509214B92e788f548e3117f7149B9eA9A5316`
- getMinDelay = `604800` (seconds every operation waits between schedule and execute)
- EIP-1967 slots: empty (not a proxy)

- **proposer / canceller / executor (the Safe)** can schedule any call from the timelock - so any Entrypoint OWNER_ROLE action: upgrade, pools, fees, roles - and run it once getMinDelay() (7 days) has passed; cancel any queued operation at once. It cannot run anything sooner than the delay, shorten the delay without waiting it, or add a proposer without a delayed operation. Every scheduled operation is public (CallScheduled) for the whole delay. (`node_modules/@openzeppelin/contracts/governance/TimelockController.sol:266`, `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:291`, `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:358`, `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:385`, `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:334`)
- **DEFAULT_ADMIN_ROLE (the timelock itself)** can grant and revoke the timelock's roles and change its delay - only through its own delayed operations. It cannot act without a proposer scheduling it: nobody else holds the admin role. (`node_modules/@openzeppelin/contracts/access/AccessControl.sol:122`, `node_modules/@openzeppelin/contracts/access/AccessControl.sol:137`, `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:449`)

<details><summary>13 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `receive()` | anyone | - | Accept ETH (it holds none for the rail). | not probed (plain ETH transfer) | `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:155` |
| `cancel(bytes32)` | a holder of the timelock's CANCELLER_ROLE (the Safe) (key) | instant | Drop a queued operation before it runs. | `0x956E…dCa1` proposer, canceller, executor | `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:334` |
| `execute(address,uint256,bytes,bytes32,bytes32)` | a holder of the timelock's EXECUTOR_ROLE (the Safe; not open) (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a queued call once its delay has passed (calls the Entrypoint as OWNER_ROLE). | `0x956E…dCa1` proposer, canceller, executor | `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:358` |
| `executeBatch(address[],uint256[],bytes[],bytes32,bytes32)` | a holder of the timelock's EXECUTOR_ROLE (the Safe; not open) (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a queued batch once its delay has passed. | `0x956E…dCa1` proposer, canceller, executor | `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:385` |
| `grantRole(bytes32,address)` | only the timelock itself, through an operation that waited its minimum delay | only once a scheduled change has waited GOVERNANCE_DELAY | Grant a timelock role. DEFAULT_ADMIN_ROLE administers every role and only the timelock holds it, so only an operation that waited the delay can. | `0x3395…5316` admin | `node_modules/@openzeppelin/contracts/access/AccessControl.sol:122` |
| `onERC1155BatchReceived(…)` | anyone | - | ERC-1155 batch receiver hook. | open | `node_modules/@openzeppelin/contracts/token/ERC1155/utils/ERC1155Holder.sol:33` |
| `onERC1155Received(address,address,uint256,uint256,bytes)` | anyone | - | ERC-1155 receiver hook. | open | `node_modules/@openzeppelin/contracts/token/ERC1155/utils/ERC1155Holder.sol:23` |
| `onERC721Received(address,address,uint256,bytes)` | anyone | - | ERC-721 receiver hook: accept a token sent to the timelock. | open | `node_modules/@openzeppelin/contracts/token/ERC721/utils/ERC721Holder.sol:21` |
| `renounceRole(bytes32,address)` | only for the caller's own role | instant | Give up a timelock role the caller holds (it must name itself). | **nobody** (every probed caller refused) | `node_modules/@openzeppelin/contracts/access/AccessControl.sol:157` |
| `revokeRole(bytes32,address)` | only the timelock itself, through an operation that waited its minimum delay | only once a scheduled change has waited GOVERNANCE_DELAY | Revoke a timelock role: an operation of the timelock itself. | `0x3395…5316` admin | `node_modules/@openzeppelin/contracts/access/AccessControl.sol:137` |
| `schedule(address,uint256,bytes,bytes32,bytes32,uint256)` | a holder of the timelock's PROPOSER_ROLE (the Safe) (key) | instant | Queue one call (target, value, data) to run after at least getMinDelay(). | `0x956E…dCa1` proposer, canceller, executor | `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:266` |
| `scheduleBatch(…)` | a holder of the timelock's PROPOSER_ROLE (the Safe) (key) | instant | Queue a batch of calls to run together after at least getMinDelay(). | `0x956E…dCa1` proposer, canceller, executor | `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:291` |
| `updateDelay(uint256)` | only the timelock itself, through an operation that waited its minimum delay | only once a scheduled change has waited GOVERNANCE_DELAY | Change the minimum delay: only as an operation of the timelock itself, so a shorter delay waits the current one. | `0x3395…5316` admin | `node_modules/@openzeppelin/contracts/governance/TimelockController.sol:449` |

</details>

#### AspRootQuorum (ASP postman, 2 of 3)

`0xBb7098C0465455e3C2074894Ddc6c475496909af` - `AspRootQuorum`, `contracts/AspRootQuorum.sol`. The Entrypoint's ASP postman as an immutable THRESHOLD-of-ASP_COUNT quorum (contracts/AspRootQuorum.sol): a root reaches the Entrypoint only when THRESHOLD of the fixed ASPs voted for exactly that root and CID. No owner, no setter, no upgrade.

- ASP: `0x6f239a1A5818808E63BB6F35A88B9876a79aa973`, `0xc8510850c5bF41B52399473F234577B2d8Ef0B16`, `0x323574Eb0c63b764F06832f15B21956bb8979FC9`
- ENTRYPOINT (immutable): `0x73f7f0DF3D2D99014B0ef66441254b6428069CBd`
- THRESHOLD = `2` (distinct ASP votes that post a root)
- ASP_COUNT = `3` (ASPs, fixed at deployment)
- round = `1` (roots posted so far; votes count only in the current round)
- EIP-1967 slots: empty (not a proxy)

- **ASP** can vote for a root and CID in the current round. THRESHOLD distinct votes for the same proposal post it to the Entrypoint at once. It cannot post a root alone (THRESHOLD is a strict majority), vote twice for one proposal, move funds, or change the ASP set or THRESHOLD: nobody can, ever. (`contracts/AspRootQuorum.sol:152`, `contracts/AspRootQuorum.sol:180`)

<details><summary>2 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `unvote(uint256,string)` | one of the ASPs fixed at deployment (key) | instant | Withdraw this ASP's live vote for `root` with `ipfsCID` in the current round - for example after it found a label it no longer approves. It then counts for nothing. <sub>(NatSpec)</sub> | `0x6f23…a973` ASP<br>`0xc851…0B16` ASP<br>`0x3235…9FC9` ASP | `contracts/AspRootQuorum.sol:180` |
| `vote(uint256,string)` | one of the ASPs fixed at deployment (key) | instant | Vote, as one of the fixed ASPs, for posting `root` with `ipfsCID`. The vote that brings the live votes to THRESHOLD posts the root to the Entrypoint in the same transaction. A lapsed vote for the s... <sub>(NatSpec)</sub> | `0x6f23…a973` ASP<br>`0x3235…9FC9` ASP<br>`0xc851…0B16` ASP | `contracts/AspRootQuorum.sol:152` |

</details>

#### LPRegistry

`0x3C7f5f7dDF970af011f549C67C50BB7d14670248` - `LPRegistry`, `contracts/ramp/LPRegistry.sol`. LP onboarding, network phases, tiers, credit and exposure across every escrow.

- governor `0x000000000000000000000000000000000000dEaD`: **renounced** (was `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`); setup complete; delay 48 h; 0 pending change(s)
- escrow: `0xA61613d65fD6F7cb5B59BcA2f59E649d55386e09`, `0xaff85ba17C001a7aE3A806AE5fE143dD17a47892`
- rewards hook: `0x28eCd6562C4CdD6B45Aa41e863a2621e27f5E70d`
- LP (tier > NONE): `0x3ce8D02B51e9c56FDBA521dA6500dF09fb953f5C`, `0xf491FA29debC0D12d8F7c57B17995C2346F025AD`
- phase = `0` (0 = A (governor-admitted institutions only), 1 = B (+ affiliates), 2 = C (+ retail))
- EIP-1967 slots: empty (not a proxy)

- **governor** can accept and drop escrows, open and close network phases, set the rewards hook, and admit, re-tier, suspend or remove LPs with their credit limits. It cannot move funds: the registry holds none. It decides how much an LP may have at risk, and which escrows may reserve it. (`contracts/ramp/LPRegistry.sol:212`, `contracts/ramp/LPRegistry.sol:221`, `contracts/ramp/LPRegistry.sol:234`, `contracts/ramp/LPRegistry.sol:252`, `contracts/common/DelayedGovernance.sol:125`)
- **escrow** can reserve and release LPs' exposure and record settlements and lost disputes. It cannot release exposure another escrow reserved. (`contracts/ramp/LPRegistry.sol:423`, `contracts/ramp/LPRegistry.sol:441`, `contracts/ramp/LPRegistry.sol:464`, `contracts/ramp/LPRegistry.sol:491`, `contracts/ramp/LPRegistry.sol:505`)

<details><summary>17 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:145` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:119` |
| `consumeBankTxId(bytes32)` | only an escrow the registry accepts | - | Spend a bank transaction id on a settlement: true the first time, false ever after, whichever escrow of this registry spent it. Only an escrow (current or retired) may call, or anyone could burn th... <sub>(NatSpec)</sub> | `0xA616…6e09` escrow<br>`0xaff8…7892` escrow | `contracts/ramp/LPRegistry.sol:505` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:159` |
| `recordDispute(address)` | only an escrow the registry accepts | - | Called by the escrow when a dispute is ruled against the LP. MUST NOT revert. <sub>(NatSpec)</sub> | `0x21f4…f975` stranger<br>`0x4D0d…8853` deployer<br>`0xA616…6e09` escrow<br>`0xaff8…7892` escrow<br>`0x3ce8…3f5C` LP<br>`0xf491…25AD` LP<br>`0x0000…dEaD` governor, renounced | `contracts/ramp/LPRegistry.sol:491` |
| `recordSettled(address,uint256)` | only an escrow the registry accepts | - | Record a settlement (ignored when the caller is not an accepted escrow). | `0x21f4…f975` stranger<br>`0x4D0d…8853` deployer<br>`0xA616…6e09` escrow<br>`0xaff8…7892` escrow<br>`0x3ce8…3f5C` LP<br>`0xf491…25AD` LP<br>`0x0000…dEaD` governor, renounced | `contracts/ramp/LPRegistry.sol:464` |
| `register()` | anyone | - | Permissionless retail onboarding, Phase C only. The cap, not the gate, is the control - once the network has been opened to retail at all. <sub>(NatSpec)</sub> | open | `contracts/ramp/LPRegistry.sol:297` |
| `releaseExposure(address,uint256)` | only an escrow the registry accepts | - | Give back exposure this escrow reserved. MUST NOT revert: it runs on release and refund paths, after money has moved. <sub>(NatSpec)</sub> | `0x4D0d…8853` deployer<br>`0x21f4…f975` stranger<br>`0xA616…6e09` escrow<br>`0xaff8…7892` escrow<br>`0x3ce8…3f5C` LP<br>`0xf491…25AD` LP<br>`0x0000…dEaD` governor, renounced | `contracts/ramp/LPRegistry.sol:441` |
| `reserveExposure(address,uint256)` | only an escrow the registry accepts | - | Take on `brlCents` of exposure for `lp`, or return false if it would exceed the LP's remaining credit. Only a registered escrow may call. <sub>(NatSpec)</sub> | `0xA616…6e09` escrow<br>`0xaff8…7892` escrow | `contracts/ramp/LPRegistry.sol:423` |
| `revokeAffiliate(address)` | a party to that offer, order, sale, note or reward | - | End an affiliation. The sponsor can always do this, whatever its own tier. <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/LPRegistry.sol:348` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:136` |
| `setEscrow(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Registering an escrow waits out the governance delay; removing one is instant. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/LPRegistry.sol:212` |
| `setPhase(uint8)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Open the next network phase (delayed), or close back to an earlier one (instant). <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/LPRegistry.sol:221` |
| `setRewardsHook(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Point settlement reports at a rewards contract (delayed), or stop them (zero, instant). <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/LPRegistry.sol:234` |
| `setTier(address,uint8,uint256)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Admit, re-tier or remove an LP. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/LPRegistry.sol:252` |
| `sponsorAffiliate(address,uint256)` | an INSTITUTIONAL LP, from Phase B | - | Sponsor an affiliated LP, or change its credit. Phase B onwards; caller must be an active INSTITUTIONAL LP. <sub>(NatSpec)</sub> | open | `contracts/ramp/LPRegistry.sol:314` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:125` |

</details>

#### ReclaimZkTlsVerifier (PIX, boleto, TED)

`0x9970AF29DDFc335ad337eBF4eAe9f01800845712` - `ReclaimZkTlsVerifier`, `contracts/ramp/ReclaimZkTlsVerifier.sol`. PIX and boleto verifier: Reclaim zkTLS claims of the payer's own bank session, signed by a threshold of witnesses.

- governor `0x000000000000000000000000000000000000dEaD`: **renounced** (was `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`); setup complete; delay 48 h; 0 pending change(s)
- witness: `0x05EfF3D8e0ad59Aa8abFd94E0b08402ec0850Fbf`, `0x8771D8B0038061D7872e4c2C69cD63F54380CBAb`, `0x72C1a86B73Ca01Fec5e07160AE14a32849eE5214`
- bank endpoint (providerHash): `0x4c64b9b374d341ba16e93be319434f3450db8fd8ea8ee3a201253f364db722b9`, `0xd8d90d629dc91348bf69c3c5148cd5bf1efdc99220a15a6f42d6ad42eeb2bb20`, `0x8259a0510dbf7425215eada80e9a8fcc1bac48d4e24e3cea67b5185b482abf77`, `0xf02c2badc915c0c690ccba5dd00202b6efcc3d49a1c1197db4026f075aaddc1a`
- threshold = `2` (witness signatures needed)
- witnessCount = `3` (witnesses)
- endpointCount = `4` (allowed bank endpoints)
- EIP-1967 slots: empty (not a proxy)

- **governor** can add and remove witnesses, change the threshold, allow and revoke bank endpoints and the rails each may attest (adding, allowing and lowering wait; removing, revoking and raising are instant). It cannot prove a payment itself, unless it adds itself as witnesses through the delay. (`contracts/ramp/ReclaimZkTlsVerifier.sol:579`, `contracts/ramp/ReclaimZkTlsVerifier.sol:590`, `contracts/ramp/ReclaimZkTlsVerifier.sol:602`, `contracts/ramp/ReclaimZkTlsVerifier.sol:610`, `contracts/ramp/ReclaimZkTlsVerifier.sol:627`, `contracts/common/DelayedGovernance.sol:125`)
- **witness** can sign Reclaim claims: `threshold` of them prove that a bank session on an allowed endpoint showed the payment. It cannot vouch for an endpoint the governor has not allowed, or a rail the endpoint may not attest.

<details><summary>10 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `allowEndpoint(bytes32,string)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Allow a bank endpoint: the template's Reclaim `providerHash` and the URL prefix its `url` must start with. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/ReclaimZkTlsVerifier.sol:602` |
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:145` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:119` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:159` |
| `revokeEndpoint(bytes32)` | the governor (key) | instant | Revoking an endpoint is instant. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/ReclaimZkTlsVerifier.sol:610` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:136` |
| `setEndpointRails(bytes32,uint16)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Set which rails an allowlisted endpoint may attest, as a bitmask over Rail. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/ReclaimZkTlsVerifier.sol:627` |
| `setThreshold(uint256)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Lowering the threshold waits out the governance delay; raising it is instant. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/ReclaimZkTlsVerifier.sol:590` |
| `setWitness(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Adding a witness waits out the governance delay; removing one is instant. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/ReclaimZkTlsVerifier.sol:579` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:125` |

</details>

#### FiatEscrow (Movva on-ramp)

`0xA61613d65fD6F7cb5B59BcA2f59E649d55386e09` - `FiatEscrow`, `contracts/ramp/FiatEscrow.sol`. On-ramp escrow: an LP escrows crypto in an offer; a taker locks an order, pays BRL, and the crypto is released on a proof of payment. **Holds funds.**

- governor `0x000000000000000000000000000000000000dEaD`: **renounced** (was `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`); setup complete; delay 48 h; 0 pending change(s)
- arbitrator: `0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7`
- allowed verifier: `0x9970AF29DDFc335ad337eBF4eAe9f01800845712`
- listed asset (enabled): `0x22E1e640752eB91461566B70e6D8099583588f04`
- EIP-1967 slots: empty (not a proxy)

- **governor** can list and delist assets and their band oracles, allow and revoke payment verifiers, add and remove arbitrators, set asset caps. After setup, listing, allowing, adding and raising wait GOVERNANCE_DELAY; delisting, revoking, removing and lowering are instant. It cannot move an offer's liquidity or an order's funds, change an asset's decimals once set, or decide a dispute: a ruling needs an arbitrator's signature. Its power over funds is indirect: which verifiers and arbitrators the escrow believes. (`contracts/ramp/FiatEscrow.sol:472`, `contracts/ramp/FiatEscrow.sol:1103`, `contracts/ramp/FiatEscrow.sol:1111`, `contracts/ramp/FiatEscrow.sol:1123`, `contracts/common/DelayedGovernance.sol:125`, `contracts/common/DelayedGovernance.sol:136`, …)
- **arbitrator** can sign a ruling on a DISPUTED order: RELEASE to the taker's named recipient, or REFUND to the LP (its offer; its own address after a taker's dispute). Anyone submits it; it executes only after RULING_DELAY (1 day), re-verified then, and before DISPUTE_TIMEOUT. A RELEASE needs an arbitrator registered no later than the dispute was raised. It cannot reach an order that is not in dispute, an LP's free liquidity, more than the disputed amount, or any payee but the order's two counterparties. (`contracts/ramp/FiatEscrow.sol:962`)

<details><summary>24 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `receive()` | anyone | - | Accept ETH: meant for ragequit proceeds from a pool. ETH sent here any other way is credited to nobody, and no function can take it out. | not probed (plain ETH transfer) | `contracts/ramp/FiatEscrow.sol:1381` |
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:145` |
| `cancelOrder(bytes32)` | a party to that offer, order, sale, note or reward | - | Give up before paying. Returns the liquidity immediately rather than making the LP wait out the window for capital nobody is going to use. <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:804` |
| `closeOffer(bytes32)` | a party to that offer, order, sale, note or reward | - | Close an offer and return its free liquidity to the LP. The LP may always; ANYONE may once the registry gives the LP no credit at all (`capOf` zero: removed, suspended, or an affiliate whose sponso... <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:576` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:119` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:159` |
| `expireDispute(bytes32)` | anyone | - | After DISPUTE_TIMEOUT with no ruling, anyone returns the order's liquidity to the LP: to its offer after the LP's own dispute, to the LP itself after a taker's. <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:1042` |
| `fundOffer(bytes32,uint256)` | a party to that offer, order, sale, note or reward | - | Add liquidity to the caller's own offer. | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:548` |
| `issueBoleto(bytes32,bytes32)` | a party to that offer, order, sale, note or reward | - | The LP commits to the boleto it registered for this order. <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:632` |
| `lockOrder(bytes32,uint256,uint8,address,uint256)` | anyone | - | Lock liquidity to pay for by PIX or TED, to the offer's key. <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:593` |
| `lockOrderByBoleto(bytes32,uint256,uint8,address,uint256)` | anyone | - | Lock liquidity to pay for by boleto. The LP must then issue one: see issueBoleto. <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:609` |
| `postOffer(…)` | an LP the registry lets quote | - | Post an offer and escrow its liquidity (the registry must let the LP quote it). | open | `contracts/ramp/FiatEscrow.sol:489` |
| `raiseDispute(bytes32,string)` | a party to that offer, order, sale, note or reward | - | Freeze an order pending arbitration. The cases this exists for are the ones no proof can settle: the taker paid but the attestor cannot produce a proof (bank downtime, an unsupported statement form... <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:883` |
| `reclaimExpired(bytes32)` | anyone | - | After the window, anyone may return unpaid liquidity to the LP. <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:840` |
| `releaseWithProof(bytes32,bytes)` | anyone carrying a proof the contract's verifier accepts | - | Present proof the BRL was paid, and take delivery. <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:738` |
| `rescueShielded(…)` | a party to that offer, order, sale, note or reward | - | The order's recipient ragequits a shielded delivery back out of the pool, to itself. | open | `contracts/ramp/FiatEscrow.sol:1073` |
| `resolveDispute(…)` | anyone carrying a registered arbitrator's signed ruling (key) | - | Submit an arbitrator's signed ruling. Anyone may submit it: the first submission posts it, and the same ruling submitted again after RULING_DELAY executes it. <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:962` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:136` |
| `setArbitrator(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Adding an arbitrator waits out the governance delay; removing one is instant. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/FiatEscrow.sol:1111` |
| `setAsset(address,address,uint8,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | List or delist a settlement asset. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/FiatEscrow.sol:472` |
| `setAssetCap(address,uint256)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Lowering or setting a first cap is instant; raising or removing one is delayed. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/FiatEscrow.sol:1123` |
| `setVerifier(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Allowing a verifier waits out the governance delay; revoking one is instant. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/FiatEscrow.sol:1103` |
| `takeDeliveryDirect(bytes32)` | a party to that offer, order, sale, note or reward | - | Take a shielded order's delivery in the open instead, to the rescue address. A shielded delivery can become impossible after the taker has paid: the Entrypoint or the pool can be frozen by the toke... <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:827` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:125` |

</details>

#### OffRampEscrow (Movva off-ramp)

`0xaff85ba17C001a7aE3A806AE5fE143dD17a47892` - `OffRampEscrow`, `contracts/ramp/OffRampEscrow.sol`. Off-ramp escrow: a seller escrows crypto in a sale; an LP claims it, pays the seller BRL, and is paid the crypto on a proof. **Holds funds.**

- governor `0x000000000000000000000000000000000000dEaD`: **renounced** (was `0x956E93E2ee65D78006FDF7e3ed59C5E05300dCa1`); setup complete; delay 48 h; 0 pending change(s)
- arbitrator: `0x5d2D6f2c6BCc3dbF988eDa77875ED80abEf480d7`
- allowed verifier: `0x9970AF29DDFc335ad337eBF4eAe9f01800845712`
- listed asset (enabled): `0x22E1e640752eB91461566B70e6D8099583588f04`
- EIP-1967 slots: empty (not a proxy)

- **governor** can list and delist assets and their band oracles, allow and revoke payment verifiers, add and remove arbitrators, set asset caps. After setup, listing, allowing, adding and raising wait GOVERNANCE_DELAY; delisting, revoking, removing and lowering are instant. It cannot move a sale's escrowed crypto, change an asset's decimals once set, or decide a dispute: a ruling needs an arbitrator's signature. Its power over funds is indirect: which verifiers and arbitrators the escrow believes. (`contracts/ramp/OffRampEscrow.sol:296`, `contracts/ramp/OffRampEscrow.sol:677`, `contracts/ramp/OffRampEscrow.sol:685`, `contracts/ramp/OffRampEscrow.sol:706`, `contracts/common/DelayedGovernance.sol:125`, `contracts/common/DelayedGovernance.sol:136`, …)
- **arbitrator** can sign a ruling on a DISPUTED sale: pay the claiming LP, or return the crypto to the seller. Anyone submits it; it executes only after RULING_DELAY (1 day), re-verified then. Paying the LP needs an arbitrator registered no later than the dispute was raised. It cannot reach a sale that is not in dispute, or pay anyone but the sale's two counterparties. (`contracts/ramp/OffRampEscrow.sol:585`)

<details><summary>18 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `abandonClaim(bytes32)` | a party to that offer, order, sale, note or reward | - | Give the claim back early, without penalty. The sale is cancellable at once and claimable again after CLAIM_COOLDOWN, by any LP, this one included. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:444` |
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:145` |
| `cancelSale(bytes32)` | a party to that offer, order, sale, note or reward | - | Withdraw a sale nobody holds a live claim on: an unclaimed one, or one whose claim is past its `payBy` (the stale claim is released first, freeing the LP's credit). Never available while a claim is... <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/OffRampEscrow.sol:381` |
| `claimSale(bytes32)` | an LP the registry lets quote | - | Take exclusivity on a sale in order to pay it. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:409` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:119` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:159` |
| `expireDispute(bytes32)` | anyone | - | After DISPUTE_TIMEOUT with no ruling, anyone returns the escrowed crypto to the seller's refund address and frees the LP's credit. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:660` |
| `openSale(…)` | anyone | - | Escrow ETH and ask for BRL. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:322` |
| `raiseDispute(bytes32,string)` | a party to that offer, order, sale, note or reward | - | The seller or the claiming LP freezes a sale for arbitration. | every probe refused on its zero arguments | `contracts/ramp/OffRampEscrow.sol:538` |
| `releaseStaleClaim(bytes32)` | anyone | - | Clear a claim nobody honoured. Callable by anyone: leaving this to the seller would mean a seller without gas stays frozen. The sale is open again: cancellable at once, claimable after CLAIM_COOLDOWN. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:435` |
| `resolveDispute(…)` | anyone carrying a registered arbitrator's signed ruling (key) | - | Submit an arbitrator's signed ruling. Anyone may submit it: the first submission posts it, and the same ruling submitted again after RULING_DELAY executes it. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:585` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:136` |
| `setArbitrator(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Adding an arbitrator waits out the governance delay; removing one is instant. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/OffRampEscrow.sol:685` |
| `setAsset(address,address,uint8,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | List or delist a settlement asset. Decimals are fixed once first set. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/OffRampEscrow.sol:296` |
| `setAssetCap(address,uint256)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Lowering or setting a first cap is instant; raising or removing one is delayed. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/OffRampEscrow.sol:706` |
| `setVerifier(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Allowing a verifier waits out the governance delay; revoking one is instant. <sub>(NatSpec)</sub> | `0x0000…dEaD` governor, renounced | `contracts/ramp/OffRampEscrow.sol:677` |
| `settleWithProof(bytes32,bytes)` | anyone carrying a proof the contract's verifier accepts | - | Prove the seller was paid, and collect the escrowed ETH. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:485` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x0000…dEaD` governor, renounced | `contracts/common/DelayedGovernance.sol:125` |

</details>

## Etherscan verification

`deployments/sepolia-movva-final-rail.finalize.rehearsal/etherscan-verify.sh` holds the exact `forge verify-contract` command for each address, with its constructor arguments and linked libraries. **They were not run.** Each was dry-run instead: forge wrote the standard-JSON input it would submit (`--show-standard-json-input`), solc 0.8.28+commit.7893614a compiled it, and the result was compared with the code at the address and with the creation transaction's init code: 21 of 21 match.

Library paths are spelled through the remapping (`poseidon-solidity/PoseidonT3.sol`). Forge 0.3.0 writes any other spelling into the input as a path solc does not match. The pools then compile with unlinked placeholders, and Etherscan would not match them. The dry run fails any input whose libraries are left unlinked.

## What was NOT verified

- That this runs on Sepolia. This is an anvil fork with an impersonated deployer: the chain, the gas and the addresses are a rehearsal of the real run.
- Etherscan itself. The verify commands were generated and dry-run offline, not submitted. The dry run repeats Etherscan's compile with the same solc, but not Etherscan's service.
- That the code is correct. This report proves which code is deployed and who can call it. Whether that code is safe is the audit's question (`docs/audit-scope.md`).
- Behaviour. No deposit, order, dispute, mint or withdrawal was executed here: the verification pass is read-only. Those flows are exercised by the Foundry and vitest suites.
- Immutable values byte by byte. They are masked in the bytecode comparison and checked through their getters by the wiring checks (Entrypoint, pools, oracles, tokens, delays, timeouts).
- The exact source text of the Privacy Pools contracts. The protocol build omits CBOR metadata (`bytecode_hash = "none"`), so for those contracts the match proves the bytecode. Their source files are hashed against the build's metadata separately.
- The Poseidon libraries' creation. They were already on the chain at deterministic addresses; their code is matched, their creation is not.
- Key custody. The inventory shows which addresses hold the remaining roles. It cannot show who holds those keys or how they are kept.
- Contracts outside the deployment: Pyth, the Chainlink feeds and their owners, CreateX and (on mainnet) USDT.
- Off-chain services: the relayer, the ASP that computes roots, the Pyth keeper and the monitor.
- Live prices. Pyth's FX.USD/BRL is stale on this chain, so the 3 checks that read it can only confirm each reader refuses it with exactly `StaleRate` (see Prices). A fresh-price read was not possible here.
