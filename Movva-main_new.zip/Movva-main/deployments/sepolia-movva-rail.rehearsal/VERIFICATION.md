# Verification report: Movva rail on Sepolia

Generated 2026-09-19T18:55:12.352Z by `scripts/deploy-movva-rail.ts`. Everything below was read from the chain after the deployment, and every number in it comes from the deployment JSON and `deployments/sepolia-movva-rail.rehearsal/privileges.json`.

> **Rehearsal, not a deployment.** The chain is an anvil fork of Sepolia (chain id 11155111) at block 11739459, and the deployer was impersonated. Nothing was broadcast to Sepolia. A real run from the same deployer nonce should produce the same addresses; it writes its own copy of this report.

## Summary

| | |
|---|---|
| Chain | Sepolia, chain id 11155111 (fork at block 11739459) |
| Commit | `dbeec90515d6ec1bf66f7a0a6f83337e50d87632` on `phase-1-shielded-rail`, **with uncommitted changes** (listed below) |
| Build hash | `7cee8f879cbd15e9c97bdbf0ce3c82a88bc0e1a95e7de03b9b6ec9029bec9f21` |
| Deployer | `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214` |
| Contracts | 28 addresses, 22 distinct contracts, 28 running this build |
| Transactions | 93, 55,526,732 gas; blocks 11739460 to 11739552 |
| Checks | **329 pass, 10 expected, 0 fail** |
| Governance | governors: `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214`; Entrypoint OWNER_ROLE: `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214` |

## What was deployed, and where

| Contract | Address | Source | Source sha256 | Runtime sha256 (build) | On chain |
|---|---|---|---|---|---|
| Privacy Pools Entrypoint (proxy) | `0x25efe3a412a69a2848AA1e2A90c0f0080d2de469` | `node_modules/@openzeppelin/contracts/proxy/ERC1967/ERC1967Proxy.sol` | `03cdbd59c384fe18`… | `f1f38be5dd06d358`… | identical |
| Entrypoint implementation | `0xD726E05f28A27c5af85A1890244a00B29dE9449E` | `protocol/contracts/src/contracts/Entrypoint.sol` | `8245c32d50ae6582`… | `6408ed2ab26661a7`… | identical outside immutables |
| Withdrawal Groth16 verifier | `0xa6a4327FC63c88EA69372A388217f0BA7d42f897` | `protocol/contracts/src/contracts/verifiers/WithdrawalVerifier.sol` | `7b6991befbc9a94a`… | `77bfc587acc64f36`… | identical |
| Ragequit (commitment) Groth16 verifier | `0xB1c6d175d5D8aF7330FC35fc9579b67153ebcD41` | `protocol/contracts/src/contracts/verifiers/CommitmentVerifier.sol` | `de24f75d21d651c0`… | `ebae2d48b14ac64f`… | identical |
| ETH Privacy Pool | `0x8fD2422a51f400e88aB40065343f9eBF892bec91` | `protocol/contracts/src/contracts/implementations/PrivacyPoolSimple.sol` | `f0d97040fd5bd00d`… | `92fdf5ae69da7a5d`… | identical outside immutables |
| PoseidonT3 library (pre-existing) | `0x8ffdA7Ed8B4aD98C2C34f54B76821711F4a6f2C5` | `node_modules/poseidon-solidity/PoseidonT3.sol` | `08a7493be3783816`… | `23a48ae4bae13d19`… | identical |
| PoseidonT4 library (pre-existing) | `0xe393dd7287Db9982e6f845824854Baf8b8e823AF` | `node_modules/poseidon-solidity/PoseidonT4.sol` | `289e22a19a20bcec`… | `e2f5e98664dbafbe`… | identical |
| Stand-in USDT (TetherLike) | `0xc241A572883241946a6780E996808C321b06baB0` | `contracts/test/ERC4626Adapter.t.sol` | `ac9bee3e80a850f4`… | `3cc6754d07b7ffbc`… | identical |
| MovvaReserve | `0xB64178cFEbb96baa9955eF70eA4C23bF9aC0914b` | `contracts/movva/MovvaReserve.sol` | `0d8dbaef35dff7ce`… | `73e59d9f7e6e1e6d`… | identical outside immutables |
| Movva (token) | `0xCe80e2e723b6cEDa9fF5E770bfCa9651F7220428` | `contracts/movva/Movva.sol` | `efaf1d6fb96d5e2b`… | `a34a2451a773c81d`… | identical outside immutables |
| SavingsMovva (sMovva) | `0x935827E58349bF489A13FcB3105dBD2Dd53Bb8CE` | `contracts/movva/SavingsMovva.sol` | `43827246f4d2682e`… | `012571d9f44e02ba`… | identical outside immutables |
| Movva FX leg (PythFxOracle) | `0x6A7Fa8E2A5CfA74DacFf15C6ed9674b55DbAB96A` | `contracts/ramp/PythFxOracle.sol` | `c5379bb7abb161ea`… | `87d01fe507ab8e28`… | identical outside immutables |
| Movva band adapter (ScaledFxBandOracle) | `0x4f524BFFc6E6E5c5962D48F597EAE6b86dF2814A` | `contracts/movva/ScaledFxBandOracle.sol` | `ddd60c94d0d23dab`… | `29eef9b7be2f7574`… | identical outside immutables |
| FeeSplitter | `0x230378a1C00AA61E05Edde834A576B5feC5a6372` | `contracts/movva/FeeSplitter.sol` | `b1b0eaf84b158a40`… | `bc7c97c7f8d5ea4b`… | identical outside immutables |
| NodeRewards | `0x3A59156F79a9a1e00C212a1e2dF5Aa20EA84EAE1` | `contracts/ramp/NodeRewards.sol` | `ff5039a7f4d80bad`… | `c80b4edde4b67900`… | identical outside immutables |
| Movva Privacy Pool | `0x85f4dc7c9C3AF5C62BA744ee08B87B74C638a040` | `protocol/contracts/src/contracts/implementations/PrivacyPoolComplex.sol` | `0f9c34f0bfd03a35`… | `d1e5735be46a6b62`… | identical outside immutables |
| sMovva Privacy Pool | `0x7342F695AdD5a0f878f4DB8576891D8B58AcfD42` | `protocol/contracts/src/contracts/implementations/PrivacyPoolComplex.sol` | `0f9c34f0bfd03a35`… | `d1e5735be46a6b62`… | identical outside immutables |
| ETH band oracle (ChainlinkSignedFxOracle) | `0x067a1C950B02114a0757Ef2801151b00b2d89080` | `contracts/ramp/ChainlinkSignedFxOracle.sol` | `6f1ecae604db583b`… | `17fda03281194631`… | identical outside immutables |
| Ramp FX leg (ScaledFxBandOracle) | `0xd011cA5c9BA5CfAfc7c2Ff4d190dD81290beAA95` | `contracts/movva/ScaledFxBandOracle.sol` | `ddd60c94d0d23dab`… | `29eef9b7be2f7574`… | identical outside immutables |
| Ramp FX source (PythFxOracle) | `0xEF3909f59b4ffe446ba9B14E813bd076F77dD782` | `contracts/ramp/PythFxOracle.sol` | `c5379bb7abb161ea`… | `87d01fe507ab8e28`… | identical outside immutables |
| USDT band oracle (ChainlinkSignedFxOracle) | `0x4bc6D57898B61764E95F924CbbA8F06B352B1b79` | `contracts/ramp/ChainlinkSignedFxOracle.sol` | `6f1ecae604db583b`… | `17fda03281194631`… | identical outside immutables |
| LPRegistry | `0xD0937a624384900D68a01D082c0233b3987b0fbb` | `contracts/ramp/LPRegistry.sol` | `e2d50504bf506ca9`… | `84db184c4d029e2b`… | identical outside immutables |
| AttestorQuorumVerifier (cards) | `0x3883306655E0D64A6766e609B0ED655f4452B0a7` | `contracts/ramp/AttestorQuorumVerifier.sol` | `e159db10fa5f220b`… | `333fc59424945025`… | identical outside immutables |
| ReclaimZkTlsVerifier (PIX, boleto) | `0xBcB02060Ee4f3734F4a206dD319d8D5621d1697E` | `contracts/ramp/ReclaimZkTlsVerifier.sol` | `d6ab36d018df7ed9`… | `344ee132b35210bc`… | identical outside immutables |
| FiatEscrow (on-ramp: ETH, USDT) | `0x09f0dAc9d938444b3f86a639504D38521100f994` | `contracts/ramp/FiatEscrow.sol` | `bdba6b565a940100`… | `d1eb1c25b24a1c78`… | identical outside immutables |
| OffRampEscrow (off-ramp: ETH, USDT) | `0xC640d520768790A817FdC50A1af17Af810d8FaaC` | `contracts/ramp/OffRampEscrow.sol` | `be48320f7886413b`… | `781eb2b7f2fd7e19`… | identical outside immutables |
| FiatEscrow (Movva on-ramp) | `0xF9A41BFc51E3FBc0593a8112f9834B8D011914b7` | `contracts/ramp/FiatEscrow.sol` | `bdba6b565a940100`… | `d1eb1c25b24a1c78`… | identical outside immutables |
| OffRampEscrow (Movva off-ramp) | `0x7E4aa58924e379279a6A6458A9a319209c48BCfe` | `contracts/ramp/OffRampEscrow.sol` | `be48320f7886413b`… | `781eb2b7f2fd7e19`… | identical outside immutables |

Full hashes, artifacts and constructor arguments are in the deployment JSON under `record.contracts`. ABIs: `deployments/sepolia-movva-rail.rehearsal/abi/` (22 files; the Entrypoint proxy's callable ABI is `Entrypoint.json`).

## Build

**Build hash `7cee8f879cbd15e9c97bdbf0ce3c82a88bc0e1a95e7de03b9b6ec9029bec9f21`**: sha256 over the concatenated runtime bytecode (artifact deployedBytecode, library placeholders as 20 zero bytes, immutables as compiled) of every distinct deployed contract, sorted by its hex. Recompute it from a checkout of the commit with `npx tsx scripts/deployment-record.ts build-hash <deployment.json>` after `forge build` in the repo root and in `protocol/contracts`.

| Contract | Build | Runtime bytes | Runtime sha256 |
|---|---|---:|---|
| AttestorQuorumVerifier | root | 6,116 | `333fc5942494502591a68e9ed91392c1e6e120e3bb0ab642a08cd0e030f772eb` |
| ChainlinkSignedFxOracle | root | 5,204 | `17fda032811946311633f054758869d678b9842c825c8bad7c55c7748c974ad4` |
| CommitmentVerifier | protocol | 1,582 | `ebae2d48b14ac64f45fd3df64ea84a60145ec212916915548cf93a7651b80f23` |
| Entrypoint | protocol | 13,490 | `6408ed2ab26661a75035495c8676b15f9f44321fcf9b611a811efb3c82be7395` |
| ERC1967Proxy | protocol | 122 | `f1f38be5dd06d358ef10a9010c1b52388094c454ae2b594351c124196c631df2` |
| FeeSplitter | root | 5,169 | `bc7c97c7f8d5ea4b5f2889dbab2b0e7fa67ff0e077eacd9c5eaa45810ec81161` |
| FiatEscrow | root | 23,488 | `d1eb1c25b24a1c787fdd88faa2f039fa08c85b4a4214cbd2f7c3725e69292c52` |
| LPRegistry | root | 9,962 | `84db184c4d029e2b356526e082f8f4afb7fb78d73b922bc106421ca5a6c2cfeb` |
| Movva | root | 4,516 | `a34a2451a773c81de920722e93b00aa6ee5d92603e801fadab124b541509c5e1` |
| MovvaReserve | root | 20,181 | `73e59d9f7e6e1e6d497f83c26a9ef5afddac5dcdcd14fe51df66aa49d7a50e0d` |
| NodeRewards | root | 9,967 | `c80b4edde4b67900af3a08e7c937057a76d2dc8b76887007c3b2e8aa1c96fefb` |
| OffRampEscrow | root | 18,397 | `781eb2b7f2fd7e19b0d59b33ecef1f3bd2158e1dd0815a3d5ebc66a4c779cc53` |
| PoseidonT3 | protocol | 23,522 | `23a48ae4bae13d19ecdb8321c33ae70c31bd5b1c37972bc673f2d073b6026fb6` |
| PoseidonT4 | protocol | 12,584 | `e2f5e98664dbafbeb3b29dfaf490adad71c401b9fa5076c9e0b1efd853d59071` |
| PrivacyPoolComplex | protocol | 7,720 | `d1e5735be46a6b62a4e7e72e1372455087813ac08eec4f1d9880b4d23e185216` |
| PrivacyPoolSimple | protocol | 7,378 | `92fdf5ae69da7a5d9a6beaa4074806c821cbabc887dfecee95576c93e4b1c57a` |
| PythFxOracle | root | 6,130 | `87d01fe507ab8e282dcce4e3c5d33ad9355ba3a874597f00202c0f8662cec739` |
| ReclaimZkTlsVerifier | root | 15,246 | `344ee132b35210bcf387dab583db0d67044e458a7ff6d1e8e9d6f94cfe4e1a27` |
| SavingsMovva | root | 5,974 | `012571d9f44e02bab0177cbbf69bdd0cb227ec444f3111f441778cbadf4e7030` |
| ScaledFxBandOracle | root | 770 | `29eef9b7be2f757447a6acaf5533270f9013c322761574801b0c83a2246672c5` |
| TetherLike | root | 2,317 | `3cc6754d07b7ffbc49ec234a166a6f8c89d82c34a9bd564581778efea45e7317` |
| WithdrawalVerifier | protocol | 1,947 | `77bfc587acc64f361df684b77293f84073e4894b61bd870fc078510562fb7bb8` |

| Build | Config | Compiler | Optimizer | EVM | viaIR | Metadata hash |
|---|---|---|---|---|---|---|
| protocol | `protocol/contracts/foundry.toml` | 0.8.28+commit.7893614a (sha256 9a0fb7e0db2c0641…) | on, 10000 runs | cancun | false | none (no CBOR) |
| root | `foundry.toml` | 0.8.28+commit.7893614a (sha256 9a0fb7e0db2c0641…) | on, 1000 runs | cancun | false | ipfs |

Forge: `forge 0.3.0 (5a8bd89 2024-12-19T17:17:10.245193696Z)`. Sources: 110 files compiled into the deployed contracts, every one identical on disk to the keccak256 its build recorded.

**Uncommitted changes when this ran** (diff sha256 `db305730f4c8efd7fac282070fcf052e1c3e76256f119e93d3a998c9d987c4e2`):

- `M` `contracts/test/MovvaInvariant.t.sol`
- `M` `docs/deployments.md`
- `M` `docs/runbook-mainnet-deploy.md`
- `M` `scripts/deploy-movva-rail.ts`
- `??` `contracts/test/EscrowInvariant.t.sol`
- `??` `scripts/deployment-record.ts`
- `??` `scripts/mythril-allowlist.txt`
- `??` `scripts/mythril.sh`
- `??` `scripts/privilege-inventory.ts`
- `??` `scripts/rail-artifacts.ts`
- 52 file(s) under `deployments/`: deployment records and ABIs, never compiled (listed in the deployment JSON's `record.git`)

None of them is a source any deployed contract was compiled from, or a build config: the deployed code is the commit's. A real deployment refuses to start from a dirty tree.

## Checks

Every check the verification pass ran, grouped: 329 pass, 10 expected, 0 fail. "Expected" is only ever a price refusal the check predicted exactly (see Prices).

### Code at every address (28 pass)

<details><summary>28 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | code at protocol.entrypoint | 0x25efe3a412a69a2848AA1e2A90c0f0080d2de469 |
| pass | code at protocol.entrypointImplementation | 0xD726E05f28A27c5af85A1890244a00B29dE9449E |
| pass | code at protocol.withdrawalVerifier | 0xa6a4327FC63c88EA69372A388217f0BA7d42f897 |
| pass | code at protocol.commitmentVerifier | 0xB1c6d175d5D8aF7330FC35fc9579b67153ebcD41 |
| pass | code at protocol.ethPool | 0x8fD2422a51f400e88aB40065343f9eBF892bec91 |
| pass | code at protocol.poseidonT3 | 0x8ffdA7Ed8B4aD98C2C34f54B76821711F4a6f2C5 |
| pass | code at protocol.poseidonT4 | 0xe393dd7287Db9982e6f845824854Baf8b8e823AF |
| pass | code at standInUsdt | 0xc241A572883241946a6780E996808C321b06baB0 |
| pass | code at movva.reserve | 0xB64178cFEbb96baa9955eF70eA4C23bF9aC0914b |
| pass | code at movva.token | 0xCe80e2e723b6cEDa9fF5E770bfCa9651F7220428 |
| pass | code at movva.savings | 0x935827E58349bF489A13FcB3105dBD2Dd53Bb8CE |
| pass | code at movva.fxLeg | 0x6A7Fa8E2A5CfA74DacFf15C6ed9674b55DbAB96A |
| pass | code at movva.bandAdapter | 0x4f524BFFc6E6E5c5962D48F597EAE6b86dF2814A |
| pass | code at movva.feeSplitter | 0x230378a1C00AA61E05Edde834A576B5feC5a6372 |
| pass | code at movva.nodeRewards | 0x3A59156F79a9a1e00C212a1e2dF5Aa20EA84EAE1 |
| pass | code at pools.movva | 0x85f4dc7c9C3AF5C62BA744ee08B87B74C638a040 |
| pass | code at pools.savings | 0x7342F695AdD5a0f878f4DB8576891D8B58AcfD42 |
| pass | code at ramp.ethOracle | 0x067a1C950B02114a0757Ef2801151b00b2d89080 |
| pass | code at ramp.fxLeg | 0xd011cA5c9BA5CfAfc7c2Ff4d190dD81290beAA95 |
| pass | code at ramp.fxSource | 0xEF3909f59b4ffe446ba9B14E813bd076F77dD782 |
| pass | code at ramp.usdtOracle | 0x4bc6D57898B61764E95F924CbbA8F06B352B1b79 |
| pass | code at ramp.registry | 0xD0937a624384900D68a01D082c0233b3987b0fbb |
| pass | code at ramp.quorum | 0x3883306655E0D64A6766e609B0ED655f4452B0a7 |
| pass | code at ramp.zktls | 0xBcB02060Ee4f3734F4a206dD319d8D5621d1697E |
| pass | code at ramp.onramp | 0x09f0dAc9d938444b3f86a639504D38521100f994 |
| pass | code at ramp.offramp | 0xC640d520768790A817FdC50A1af17Af810d8FaaC |
| pass | code at ramp.movvaOnramp | 0xF9A41BFc51E3FBc0593a8112f9834B8D011914b7 |
| pass | code at ramp.movvaOfframp | 0x7E4aa58924e379279a6A6458A9a319209c48BCfe |

</details>

### Governance: governor, setup, delay (42 pass)

<details><summary>42 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | MovvaReserve governor | 0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214 |
| pass | MovvaReserve setupComplete | true |
| pass | MovvaReserve GOVERNANCE_DELAY | 172800 |
| pass | Movva FX leg (PythFxOracle) governor | 0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214 |
| pass | Movva FX leg (PythFxOracle) setupComplete | true |
| pass | Movva FX leg (PythFxOracle) GOVERNANCE_DELAY | 172800 |
| pass | FeeSplitter governor | 0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214 |
| pass | FeeSplitter setupComplete | true |
| pass | FeeSplitter GOVERNANCE_DELAY | 172800 |
| pass | NodeRewards governor | 0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214 |
| pass | NodeRewards setupComplete | true |
| pass | NodeRewards GOVERNANCE_DELAY | 172800 |
| pass | ramp FX source (PythFxOracle) governor | 0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214 |
| pass | ramp FX source (PythFxOracle) setupComplete | true |
| pass | ramp FX source (PythFxOracle) GOVERNANCE_DELAY | 172800 |
| pass | ETH oracle governor | 0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214 |
| pass | ETH oracle setupComplete | true |
| pass | ETH oracle GOVERNANCE_DELAY | 172800 |
| pass | USDT oracle governor | 0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214 |
| pass | USDT oracle setupComplete | true |
| pass | USDT oracle GOVERNANCE_DELAY | 172800 |
| pass | LPRegistry governor | 0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214 |
| pass | LPRegistry setupComplete | true |
| pass | LPRegistry GOVERNANCE_DELAY | 172800 |
| pass | AttestorQuorumVerifier governor | 0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214 |
| pass | AttestorQuorumVerifier setupComplete | true |
| pass | AttestorQuorumVerifier GOVERNANCE_DELAY | 172800 |
| pass | ReclaimZkTlsVerifier governor | 0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214 |
| pass | ReclaimZkTlsVerifier setupComplete | true |
| pass | ReclaimZkTlsVerifier GOVERNANCE_DELAY | 172800 |
| pass | FiatEscrow governor | 0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214 |
| pass | FiatEscrow setupComplete | true |
| pass | FiatEscrow GOVERNANCE_DELAY | 172800 |
| pass | OffRampEscrow governor | 0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214 |
| pass | OffRampEscrow setupComplete | true |
| pass | OffRampEscrow GOVERNANCE_DELAY | 172800 |
| pass | Movva FiatEscrow governor | 0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214 |
| pass | Movva FiatEscrow setupComplete | true |
| pass | Movva FiatEscrow GOVERNANCE_DELAY | 172800 |
| pass | Movva OffRampEscrow governor | 0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214 |
| pass | Movva OffRampEscrow setupComplete | true |
| pass | Movva OffRampEscrow GOVERNANCE_DELAY | 172800 |

</details>

### Privacy Pools: Entrypoint roles and pools (9 pass)

<details><summary>9 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | Entrypoint OWNER_ROLE held by the owner | true |
| pass | Entrypoint ASP_POSTMAN held by the postman | true |
| pass | Entrypoint ETH pool | 0x8fD2422a51f400e88aB40065343f9eBF892bec91 |
| pass | Entrypoint Movva pool | 0x85f4dc7c9C3AF5C62BA744ee08B87B74C638a040,1000000000000000000,10,100 |
| pass | Entrypoint sMovva pool | 0x7342F695AdD5a0f878f4DB8576891D8B58AcfD42,1000000000000000000000000,10,100 |
| pass | Movva pool ENTRYPOINT | 0x25efe3a412a69a2848AA1e2A90c0f0080d2de469 |
| pass | Movva pool ASSET | 0xCe80e2e723b6cEDa9fF5E770bfCa9651F7220428 |
| pass | sMovva pool ENTRYPOINT | 0x25efe3a412a69a2848AA1e2A90c0f0080d2de469 |
| pass | sMovva pool ASSET | 0x935827E58349bF489A13FcB3105dBD2Dd53Bb8CE |

</details>

### Movva: reserve, FX leg, fees, rewards (21 pass)

<details><summary>21 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | reserve MOVVA | 0xCe80e2e723b6cEDa9fF5E770bfCa9651F7220428 |
| pass | token RESERVE | 0xB64178cFEbb96baa9955eF70eA4C23bF9aC0914b |
| pass | reserve USDT (stand-in) | 0xc241A572883241946a6780E996808C321b06baB0 |
| pass | reserve USDT/USD feed (Chainlink USDC/USD) | 0xA2F78ab2355fe2f984D808B5CeE7FD0A93D5270E |
| pass | reserve FX oracle | 0x6A7Fa8E2A5CfA74DacFf15C6ed9674b55DbAB96A |
| pass | reserve sMovva | 0x935827E58349bF489A13FcB3105dBD2Dd53Bb8CE |
| pass | reserve fee recipient is the FeeSplitter | 0x230378a1C00AA61E05Edde834A576B5feC5a6372 |
| pass | reserve fees (mint, redeem, distribution bps) | 10,10,2000 |
| pass | reserve supply cap | 1000000000000000000000000 |
| pass | reserve gateway: test LP | true |
| pass | Movva FX leg PYTH | 0xDd24F84d36BF92C65F92307595335bdFab5Bbd21 |
| pass | Movva FX leg usdBrlId | 0xd2db4dbf1aea74e0f666b0e8f73b9580d407f5e5cf931940b06dc633d7a95906 |
| pass | Movva FX leg maxAge / closedMaxAge / maxConfBps | 3600,345600,100 |
| pass | ramp FX source PYTH | 0xDd24F84d36BF92C65F92307595335bdFab5Bbd21 |
| pass | ramp FX source usdBrlId | 0xd2db4dbf1aea74e0f666b0e8f73b9580d407f5e5cf931940b06dc633d7a95906 |
| pass | ramp FX source maxAge / closedMaxAge / maxConfBps | 3600,345600,100 |
| pass | Movva band adapter SOURCE | 0x6A7Fa8E2A5CfA74DacFf15C6ed9674b55DbAB96A |
| pass | FeeSplitter rewards | 0x3A59156F79a9a1e00C212a1e2dF5Aa20EA84EAE1 |
| pass | FeeSplitter treasury | 0x1577D5b15F09C2A47F6f3dB80f7b2EB47095897E |
| pass | NodeRewards REWARD_TOKEN | 0xCe80e2e723b6cEDa9fF5E770bfCa9651F7220428 |
| pass | NodeRewards bound to the registry | 0xD0937a624384900D68a01D082c0233b3987b0fbb |

</details>

### Ramp wiring: registry, escrows, oracles (38 pass)

<details><summary>38 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | registry phase (0 = A) | 0 |
| pass | registry rewards hook | 0x3A59156F79a9a1e00C212a1e2dF5Aa20EA84EAE1 |
| pass | registry accepts FiatEscrow | true |
| pass | FiatEscrow allows both verifiers | true |
| pass | FiatEscrow arbitrator | true |
| pass | FiatEscrow dispute timeout | 2592000 |
| pass | registry accepts OffRampEscrow | true |
| pass | OffRampEscrow allows both verifiers | true |
| pass | OffRampEscrow arbitrator | true |
| pass | OffRampEscrow dispute timeout | 2592000 |
| pass | registry accepts Movva FiatEscrow | true |
| pass | Movva FiatEscrow allows both verifiers | true |
| pass | Movva FiatEscrow arbitrator | true |
| pass | Movva FiatEscrow dispute timeout | 2592000 |
| pass | registry accepts Movva OffRampEscrow | true |
| pass | Movva OffRampEscrow allows both verifiers | true |
| pass | Movva OffRampEscrow arbitrator | true |
| pass | Movva OffRampEscrow dispute timeout | 2592000 |
| pass | registry: test LP is INSTITUTIONAL with its credit | tier 3, 5000000 centavos |
| pass | FiatEscrow ORACLE (ETH band) | 0x067a1C950B02114a0757Ef2801151b00b2d89080 |
| pass | FiatEscrow BAND_BPS | 500 |
| pass | FiatEscrow lists stand-in USDT (oracle, 6, enabled) | 0x4bc6D57898B61764E95F924CbbA8F06B352B1b79,6,true |
| pass | FiatEscrow stand-in USDT cap | 250000000000 |
| pass | OffRampEscrow ORACLE (ETH band) | 0x067a1C950B02114a0757Ef2801151b00b2d89080 |
| pass | OffRampEscrow BAND_BPS | 500 |
| pass | OffRampEscrow lists stand-in USDT (oracle, 6, enabled) | 0x4bc6D57898B61764E95F924CbbA8F06B352B1b79,6,true |
| pass | OffRampEscrow stand-in USDT cap | 250000000000 |
| pass | FiatEscrow Entrypoint / ETH pool | 0x25efe3a412a69a2848AA1e2A90c0f0080d2de469,0x8fD2422a51f400e88aB40065343f9eBF892bec91 |
| pass | Movva FiatEscrow Entrypoint / Movva pool | 0x25efe3a412a69a2848AA1e2A90c0f0080d2de469,0x85f4dc7c9C3AF5C62BA744ee08B87B74C638a040 |
| pass | Movva FiatEscrow BAND_BPS | 300 |
| pass | Movva FiatEscrow lists Movva (reserve, 18, enabled) | 0xB64178cFEbb96baa9955eF70eA4C23bF9aC0914b,18,true |
| pass | Movva FiatEscrow native ETH delisted | false |
| pass | Movva OffRampEscrow BAND_BPS | 300 |
| pass | Movva OffRampEscrow lists Movva (reserve, 18, enabled) | 0xB64178cFEbb96baa9955eF70eA4C23bF9aC0914b,18,true |
| pass | Movva OffRampEscrow native ETH delisted | false |
| pass | ETH oracle legs (ETH/USD, FX leg, max age) | 0x694AA1769357215DE4FAC081bf1f309aDC325306,0xd011cA5c9BA5CfAfc7c2Ff4d190dD81290beAA95,4500 |
| pass | USDT oracle legs (USDC/USD, FX leg, max age) | 0xA2F78ab2355fe2f984D808B5CeE7FD0A93D5270E,0xd011cA5c9BA5CfAfc7c2Ff4d190dD81290beAA95,90000 |
| pass | ramp FX leg SOURCE | 0xEF3909f59b4ffe446ba9B14E813bd076F77dD782 |

</details>

### Verifiers: who proves what (9 pass)

<details><summary>9 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | ReclaimZkTlsVerifier provesBankSession | true |
| pass | AttestorQuorumVerifier provesBankSession | false |
| pass | quorum attestors + threshold | true |
| pass | zktls witnesses + threshold | true |
| pass | zktls endpointCount | 4 |
| pass | zktls endpoint pix-received (rails, prefix) | 2,https://api.banco-lp.example/ |
| pass | zktls endpoint pix-sent (rails, prefix) | 2,https://api.banco-lp.example/ |
| pass | zktls endpoint boleto-received (rails, prefix) | 4,https://api.banco-lp.example/ |
| pass | zktls endpoint boleto-paid (rails, prefix) | 4,https://api.banco-lp.example/ |

</details>

### Prices: Chainlink freshness and the Pyth leg (2 pass, 10 expected)

<details><summary>12 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | Chainlink ETH/USD fresh for its max age | 264037720000 (8 dp), 1551 s old, max 4500 |
| pass | Chainlink USDC/USD fresh for its max age | 99987172 (8 dp), 9411 s old, max 90000 |
| expected | Pyth FX.USD/BRL on Sepolia | publishTime 1783080563, 6763504 s old at block 11739552; core session closed |
| expected | ramp FX source brlCentsPerUnit (the rate) | StaleRate(1783080563) - Pyth's FX.USD/BRL is stale on Sepolia |
| expected | ramp FX source brlCentsPerUnitForBand | StaleRate(1783080563) - Pyth's FX.USD/BRL is stale on Sepolia |
| expected | ramp FX leg (centavo adapter) brlCentsPerUnit | StaleRate(1783080563) - Pyth's FX.USD/BRL is stale on Sepolia |
| expected | ETH band (ETH oracle brlCentsPerUnit) | StaleRate(1783080563) - Pyth's FX.USD/BRL is stale on Sepolia |
| expected | USDT band (USDT oracle brlCentsPerUnit) | StaleRate(1783080563) - Pyth's FX.USD/BRL is stale on Sepolia |
| expected | Movva FX leg brlCentsPerUnit (the rate) | StaleRate(1783080563) - Pyth's FX.USD/BRL is stale on Sepolia |
| expected | Movva band adapter brlCentsPerUnit | StaleRate(1783080563) - Pyth's FX.USD/BRL is stale on Sepolia |
| expected | reserve brlPerUsdtE18 (mint/redeem rate) | StaleRate(1783080563) - Pyth's FX.USD/BRL is stale on Sepolia |
| expected | reserve bandBrlPerUsdtE18 (Movva band) | StaleRate(1783080563) - Pyth's FX.USD/BRL is stale on Sepolia |

</details>

### Bytecode: each address runs this commit's build (56 pass)

<details><summary>56 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | every source file the deployed contracts were compiled from is the file on disk (keccak256 in the build metadata) | 110 files |
| pass | the commit is clean for every build input | dbeec90515d6ec1bf66f7a0a6f83337e50d87632 (other uncommitted files, none a build input: 62) |
| pass | no build input changed during the run | commit dbeec90515d6ec1bf66f7a0a6f83337e50d87632 throughout |
| pass | Privacy Pools Entrypoint (proxy) runs the build's ERC1967Proxy | 0x25efe3a412a69a2848AA1e2A90c0f0080d2de469: 122 bytes, identical |
| pass | Privacy Pools Entrypoint (proxy): creation code is the build's, followed by its constructor arguments | tx 0xff7a5861c52884a400a25627f16b35aba82bc9adc93eeaea08d8884703a5a238 (createx), 192 bytes of arguments |
| pass | Entrypoint implementation runs the build's Entrypoint | 0xD726E05f28A27c5af85A1890244a00B29dE9449E: 13490 bytes, identical outside 3 immutable site(s) (96 bytes masked) |
| pass | Entrypoint implementation: creation code is the build's, followed by its constructor arguments | tx 0xb8592cd99157e5408a74cdd9df50ffe022b17fd98dcdf09ceae26179dd9cf45c (createx), 0 bytes of arguments |
| pass | Withdrawal Groth16 verifier runs the build's WithdrawalVerifier | 0xa6a4327FC63c88EA69372A388217f0BA7d42f897: 1947 bytes, identical |
| pass | Withdrawal Groth16 verifier: creation code is the build's, followed by its constructor arguments | tx 0x875cdad02c04235ba4edfbe04b33c4091081ad77db911caacfcf2a594e40dd75 (createx), 0 bytes of arguments |
| pass | Ragequit (commitment) Groth16 verifier runs the build's CommitmentVerifier | 0xB1c6d175d5D8aF7330FC35fc9579b67153ebcD41: 1582 bytes, identical |
| pass | Ragequit (commitment) Groth16 verifier: creation code is the build's, followed by its constructor arguments | tx 0x72804268392df5593eac09389c695ea5cecd536116ddefd27b7a1237f095b3de (createx), 0 bytes of arguments |
| pass | ETH Privacy Pool runs the build's PrivacyPoolSimple | 0x8fD2422a51f400e88aB40065343f9eBF892bec91: 7378 bytes, identical outside 12 immutable site(s) (384 bytes masked) |
| pass | ETH Privacy Pool: creation code is the build's, followed by its constructor arguments | tx 0xdb61b5324a3ed246f7fcd6c7dad443cd504464e86044d29c521723575d5a64af (createx), 96 bytes of arguments |
| pass | PoseidonT3 library runs the build's PoseidonT3 | 0x8ffdA7Ed8B4aD98C2C34f54B76821711F4a6f2C5: 23522 bytes, identical |
| pass | PoseidonT4 library runs the build's PoseidonT4 | 0xe393dd7287Db9982e6f845824854Baf8b8e823AF: 12584 bytes, identical |
| pass | Stand-in USDT (TetherLike) runs the build's TetherLike | 0xc241A572883241946a6780E996808C321b06baB0: 2317 bytes, identical |
| pass | Stand-in USDT (TetherLike): creation code is the build's, followed by its constructor arguments | tx 0xa57c0b48fa1893826e337b2fa19013c0e2129a07e5af30cd964fd36f211c9521 (create), 0 bytes of arguments |
| pass | MovvaReserve runs the build's MovvaReserve | 0xB64178cFEbb96baa9955eF70eA4C23bF9aC0914b: 20181 bytes, identical outside 25 immutable site(s) (800 bytes masked) |
| pass | MovvaReserve: creation code is the build's, followed by its constructor arguments | tx 0x28890a5c1ca45985a5d2c63a4f7e7ceaf139b32a8d432f3223d738bd14c60a4d (create), 384 bytes of arguments |
| pass | Movva (token) runs the build's Movva | 0xCe80e2e723b6cEDa9fF5E770bfCa9651F7220428: 4516 bytes, identical outside 10 immutable site(s) (320 bytes masked) |
| pass | SavingsMovva (sMovva) runs the build's SavingsMovva | 0x935827E58349bF489A13FcB3105dBD2Dd53Bb8CE: 5974 bytes, identical outside 13 immutable site(s) (416 bytes masked) |
| pass | SavingsMovva (sMovva): creation code is the build's, followed by its constructor arguments | tx 0x296d4dc0a6e962e3c81d4496ddde559bb229d0262b23178721e09c91e495b345 (create), 64 bytes of arguments |
| pass | Movva FX leg (PythFxOracle) runs the build's PythFxOracle | 0x6A7Fa8E2A5CfA74DacFf15C6ed9674b55DbAB96A: 6130 bytes, identical outside 5 immutable site(s) (160 bytes masked) |
| pass | Movva FX leg (PythFxOracle): creation code is the build's, followed by its constructor arguments | tx 0x819c070725f50ccdc42ae0d022e4730505d4b9bd01a6ef4f79cf3a3f7b017fcd (create), 224 bytes of arguments |
| pass | Movva band adapter (ScaledFxBandOracle) runs the build's ScaledFxBandOracle | 0x4f524BFFc6E6E5c5962D48F597EAE6b86dF2814A: 770 bytes, identical outside 2 immutable site(s) (64 bytes masked) |
| pass | Movva band adapter (ScaledFxBandOracle): creation code is the build's, followed by its constructor arguments | tx 0x282290ea82b1488058bcb9c2e95e5020926777e77674a07191a9a7d3fe62c0af (create), 32 bytes of arguments |
| pass | FeeSplitter runs the build's FeeSplitter | 0x230378a1C00AA61E05Edde834A576B5feC5a6372: 5169 bytes, identical outside 8 immutable site(s) (256 bytes masked) |
| pass | FeeSplitter: creation code is the build's, followed by its constructor arguments | tx 0xbaf98cc0cf9cb73af31adefd2a66acd4c59ee4ab93e994d2bb9b01f8e53af857 (create), 160 bytes of arguments |
| pass | NodeRewards runs the build's NodeRewards | 0x3A59156F79a9a1e00C212a1e2dF5Aa20EA84EAE1: 9967 bytes, identical outside 23 immutable site(s) (736 bytes masked) |
| pass | NodeRewards: creation code is the build's, followed by its constructor arguments | tx 0xb58bc9985d8dbdde40e721fdb882b75ce3923c9a9d5399335aed2e288ca3ef0d (create), 192 bytes of arguments |
| pass | Movva Privacy Pool runs the build's PrivacyPoolComplex | 0x85f4dc7c9C3AF5C62BA744ee08B87B74C638a040: 7720 bytes, identical outside 14 immutable site(s) (448 bytes masked) |
| pass | Movva Privacy Pool: creation code is the build's, followed by its constructor arguments | tx 0x741db91dea9b4a08b1fbae90ac4707861de514508f41f9392edf41d756f5ab7f (createx), 128 bytes of arguments |
| pass | sMovva Privacy Pool runs the build's PrivacyPoolComplex | 0x7342F695AdD5a0f878f4DB8576891D8B58AcfD42: 7720 bytes, identical outside 14 immutable site(s) (448 bytes masked) |
| pass | sMovva Privacy Pool: creation code is the build's, followed by its constructor arguments | tx 0x2ede58ba0eb2909cb5e8a3e96e485a85de876ae0dcb9d781f7133549f6f6fe21 (createx), 128 bytes of arguments |
| pass | ETH band oracle (ChainlinkSignedFxOracle) runs the build's ChainlinkSignedFxOracle | 0x067a1C950B02114a0757Ef2801151b00b2d89080: 5204 bytes, identical outside 3 immutable site(s) (96 bytes masked) |
| pass | ETH band oracle (ChainlinkSignedFxOracle): creation code is the build's, followed by its constructor arguments | tx 0x1543e1629439bcb3682fdf362b0424fa02d5be880d9a524766e871159afe8581 (create), 192 bytes of arguments |
| pass | Ramp FX leg (ScaledFxBandOracle) runs the build's ScaledFxBandOracle | 0xd011cA5c9BA5CfAfc7c2Ff4d190dD81290beAA95: 770 bytes, identical outside 2 immutable site(s) (64 bytes masked) |
| pass | Ramp FX leg (ScaledFxBandOracle): creation code is the build's, followed by its constructor arguments | tx 0xf1e1a616ad1ebd2ab2a7acfefc4a5c790392b8984465372b703fec15ac314fca (create), 32 bytes of arguments |
| pass | Ramp FX source (PythFxOracle) runs the build's PythFxOracle | 0xEF3909f59b4ffe446ba9B14E813bd076F77dD782: 6130 bytes, identical outside 5 immutable site(s) (160 bytes masked) |
| pass | Ramp FX source (PythFxOracle): creation code is the build's, followed by its constructor arguments | tx 0xf63de373f9fd6277be93677db89d651ad8edca1d04404670789eb119a7b0795a (create), 224 bytes of arguments |
| pass | USDT band oracle (ChainlinkSignedFxOracle) runs the build's ChainlinkSignedFxOracle | 0x4bc6D57898B61764E95F924CbbA8F06B352B1b79: 5204 bytes, identical outside 3 immutable site(s) (96 bytes masked) |
| pass | USDT band oracle (ChainlinkSignedFxOracle): creation code is the build's, followed by its constructor arguments | tx 0x963ef34a58b045ccec16a48a4097794783fbaeef0ab669bbc3bfd25335af4bed (create), 192 bytes of arguments |
| pass | LPRegistry runs the build's LPRegistry | 0xD0937a624384900D68a01D082c0233b3987b0fbb: 9962 bytes, identical outside 3 immutable site(s) (96 bytes masked) |
| pass | LPRegistry: creation code is the build's, followed by its constructor arguments | tx 0x9502ffc8e8b6d3c657a317ff0a6c641db1b839d1a092aa5f451d33b8e4ce62fa (create), 64 bytes of arguments |
| pass | AttestorQuorumVerifier (cards) runs the build's AttestorQuorumVerifier | 0x3883306655E0D64A6766e609B0ED655f4452B0a7: 6116 bytes, identical outside 3 immutable site(s) (96 bytes masked) |
| pass | AttestorQuorumVerifier (cards): creation code is the build's, followed by its constructor arguments | tx 0x2038652140aaad75cd709047a1a9e03b426885d9c2cc22c9a7908407f73c7f22 (create), 256 bytes of arguments |
| pass | ReclaimZkTlsVerifier (PIX, boleto) runs the build's ReclaimZkTlsVerifier | 0xBcB02060Ee4f3734F4a206dD319d8D5621d1697E: 15246 bytes, identical outside 3 immutable site(s) (96 bytes masked) |
| pass | ReclaimZkTlsVerifier (PIX, boleto): creation code is the build's, followed by its constructor arguments | tx 0x6f2b0106c7f981727f0bbd060d7a8102476300082fac6524414e8177d8fff45b (create), 896 bytes of arguments |
| pass | FiatEscrow (on-ramp: ETH, USDT) runs the build's FiatEscrow | 0x09f0dAc9d938444b3f86a639504D38521100f994: 23488 bytes, identical outside 25 immutable site(s) (800 bytes masked) |
| pass | FiatEscrow (on-ramp: ETH, USDT): creation code is the build's, followed by its constructor arguments | tx 0xe570eb450ac6992d8f70ec8a56c08d48a17626460373dcf4ccd0ee4cc0fc5054 (create), 256 bytes of arguments |
| pass | OffRampEscrow (off-ramp: ETH, USDT) runs the build's OffRampEscrow | 0xC640d520768790A817FdC50A1af17Af810d8FaaC: 18397 bytes, identical outside 20 immutable site(s) (640 bytes masked) |
| pass | OffRampEscrow (off-ramp: ETH, USDT): creation code is the build's, followed by its constructor arguments | tx 0x69172b3447f093aa308df4b68f90c04fa72046079333b7caac9887e25b83f3e0 (create), 192 bytes of arguments |
| pass | FiatEscrow (Movva on-ramp) runs the build's FiatEscrow | 0xF9A41BFc51E3FBc0593a8112f9834B8D011914b7: 23488 bytes, identical outside 25 immutable site(s) (800 bytes masked) |
| pass | FiatEscrow (Movva on-ramp): creation code is the build's, followed by its constructor arguments | tx 0x69fc4fd1077201a78f9841e2317afcacc334401177fc2d2483752d7a64429fd2 (create), 256 bytes of arguments |
| pass | OffRampEscrow (Movva off-ramp) runs the build's OffRampEscrow | 0x7E4aa58924e379279a6A6458A9a319209c48BCfe: 18397 bytes, identical outside 20 immutable site(s) (640 bytes masked) |
| pass | OffRampEscrow (Movva off-ramp): creation code is the build's, followed by its constructor arguments | tx 0xc7269dbfc65663bff6caf90ce841d03b1898835e278b6d24112323069f48f5c3 (create), 192 bytes of arguments |

</details>

### Etherscan readiness (dry run, nothing submitted) (28 pass)

<details><summary>28 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | Privacy Pools Entrypoint (proxy): the verify-contract input recompiles to the code at the address | 8 sources, runs 10000, bytecodeHash none: runtime exact, creation code and arguments equal the creation transaction |
| pass | Entrypoint implementation: the verify-contract input recompiles to the code at the address | 27 sources, runs 10000, bytecodeHash none: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | Withdrawal Groth16 verifier: the verify-contract input recompiles to the code at the address | 1 sources, runs 10000, bytecodeHash none: runtime exact, creation code and arguments equal the creation transaction |
| pass | Ragequit (commitment) Groth16 verifier: the verify-contract input recompiles to the code at the address | 1 sources, runs 10000, bytecodeHash none: runtime exact, creation code and arguments equal the creation transaction |
| pass | ETH Privacy Pool: the verify-contract input recompiles to the code at the address | 15 sources, runs 10000, bytecodeHash none: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | PoseidonT3 library: the verify-contract input recompiles to the code at the address | 1 sources, runs 10000, bytecodeHash none: runtime exact |
| pass | PoseidonT4 library: the verify-contract input recompiles to the code at the address | 1 sources, runs 10000, bytecodeHash none: runtime exact |
| pass | Stand-in USDT (TetherLike): the verify-contract input recompiles to the code at the address | 44 sources, runs 1000, bytecodeHash ipfs: runtime exact, creation code and arguments equal the creation transaction |
| pass | MovvaReserve: the verify-contract input recompiles to the code at the address | 36 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | Movva (token): the verify-contract input recompiles to the code at the address | 20 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables |
| pass | SavingsMovva (sMovva): the verify-contract input recompiles to the code at the address | 20 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | Movva FX leg (PythFxOracle): the verify-contract input recompiles to the code at the address | 6 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | Movva band adapter (ScaledFxBandOracle): the verify-contract input recompiles to the code at the address | 3 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | FeeSplitter: the verify-contract input recompiles to the code at the address | 11 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | NodeRewards: the verify-contract input recompiles to the code at the address | 17 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | Movva Privacy Pool: the verify-contract input recompiles to the code at the address | 21 sources, runs 10000, bytecodeHash none: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | sMovva Privacy Pool: the verify-contract input recompiles to the code at the address | 21 sources, runs 10000, bytecodeHash none: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | ETH band oracle (ChainlinkSignedFxOracle): the verify-contract input recompiles to the code at the address | 4 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | Ramp FX leg (ScaledFxBandOracle): the verify-contract input recompiles to the code at the address | 3 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | Ramp FX source (PythFxOracle): the verify-contract input recompiles to the code at the address | 6 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | USDT band oracle (ChainlinkSignedFxOracle): the verify-contract input recompiles to the code at the address | 4 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | LPRegistry: the verify-contract input recompiles to the code at the address | 4 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | AttestorQuorumVerifier (cards): the verify-contract input recompiles to the code at the address | 3 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | ReclaimZkTlsVerifier (PIX, boleto): the verify-contract input recompiles to the code at the address | 3 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | FiatEscrow (on-ramp: ETH, USDT): the verify-contract input recompiles to the code at the address | 9 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | OffRampEscrow (off-ramp: ETH, USDT): the verify-contract input recompiles to the code at the address | 8 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | FiatEscrow (Movva on-ramp): the verify-contract input recompiles to the code at the address | 9 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |
| pass | OffRampEscrow (Movva off-ramp): the verify-contract input recompiles to the code at the address | 8 sources, runs 1000, bytecodeHash ipfs: runtime exact-except-immutables, creation code and arguments equal the creation transaction |

</details>

### Privileges: roles, gates, proxies (96 pass)

<details><summary>96 checks</summary>

| Result | Check | Detail |
|---|---|---|
| pass | Privacy Pools Entrypoint (proxy): every state-changing function classified | 15 functions in the ABI, all in the catalog |
| pass | Privacy Pools Entrypoint (proxy): a stranger is refused by every gated function | 11 gated functions, each refused with its own error |
| pass | Privacy Pools Entrypoint (proxy): EIP-1967 implementation is the recorded one; admin and beacon slots empty | implementation 0xD726E05f28A27c5af85A1890244a00B29dE9449E, admin empty, beacon empty |
| pass | Entrypoint: OWNER_ROLE held by the owner alone | 0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214 |
| pass | Entrypoint: no DEFAULT_ADMIN_ROLE holder | none |
| pass | Entrypoint: ASP_POSTMAN held by the postman alone | 0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214 |
| pass | Entrypoint: no role beyond OWNER_ROLE, ASP_POSTMAN and DEFAULT_ADMIN_ROLE was ever granted | none |
| pass | Entrypoint implementation: every state-changing function classified | 15 functions in the ABI, all in the catalog |
| pass | Entrypoint implementation: a stranger is refused by every gated function | 11 gated functions, each refused with its own error |
| pass | Entrypoint implementation: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | Entrypoint implementation: initializers disabled (nobody can initialize it and take its roles) | Initializable version 18446744073709551615 |
| pass | Withdrawal Groth16 verifier: every state-changing function classified | 0 functions in the ABI, all in the catalog |
| pass | Withdrawal Groth16 verifier: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | Ragequit (commitment) Groth16 verifier: every state-changing function classified | 0 functions in the ABI, all in the catalog |
| pass | Ragequit (commitment) Groth16 verifier: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | ETH Privacy Pool: every state-changing function classified | 4 functions in the ABI, all in the catalog |
| pass | ETH Privacy Pool: a stranger is refused by every gated function | 2 gated functions, each refused with its own error |
| pass | ETH Privacy Pool: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | PoseidonT3 library: every state-changing function classified | 0 functions in the ABI, all in the catalog |
| pass | PoseidonT3 library: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | PoseidonT4 library: every state-changing function classified | 0 functions in the ABI, all in the catalog |
| pass | PoseidonT4 library: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | Stand-in USDT (TetherLike): every state-changing function classified | 8 functions in the ABI, all in the catalog |
| pass | Stand-in USDT (TetherLike): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | MovvaReserve: every state-changing function classified | 25 functions in the ABI, all in the catalog |
| pass | MovvaReserve: a stranger is refused by every gated function | 23 gated functions, each refused with its own error |
| pass | MovvaReserve: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | MovvaReserve: no pending scheduled change | none |
| pass | Movva (token): every state-changing function classified | 6 functions in the ABI, all in the catalog |
| pass | Movva (token): a stranger is refused by every gated function | 2 gated functions, each refused with its own error |
| pass | Movva (token): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | SavingsMovva (sMovva): every state-changing function classified | 8 functions in the ABI, all in the catalog |
| pass | SavingsMovva (sMovva): a stranger is refused by every gated function | 1 gated functions, each refused with its own error |
| pass | SavingsMovva (sMovva): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | Movva FX leg (PythFxOracle): every state-changing function classified | 7 functions in the ABI, all in the catalog |
| pass | Movva FX leg (PythFxOracle): a stranger is refused by every gated function | 7 gated functions, each refused with its own error |
| pass | Movva FX leg (PythFxOracle): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | Movva FX leg (PythFxOracle): no pending scheduled change | none |
| pass | Movva band adapter (ScaledFxBandOracle): every state-changing function classified | 0 functions in the ABI, all in the catalog |
| pass | Movva band adapter (ScaledFxBandOracle): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | FeeSplitter: every state-changing function classified | 9 functions in the ABI, all in the catalog |
| pass | FeeSplitter: a stranger is refused by every gated function | 8 gated functions, each refused with its own error |
| pass | FeeSplitter: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | FeeSplitter: no pending scheduled change | none |
| pass | NodeRewards: every state-changing function classified | 13 functions in the ABI, all in the catalog |
| pass | NodeRewards: a stranger is refused by every gated function | 10 gated functions, each refused with its own error |
| pass | NodeRewards: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | NodeRewards: no pending scheduled change | none |
| pass | Movva Privacy Pool: every state-changing function classified | 4 functions in the ABI, all in the catalog |
| pass | Movva Privacy Pool: a stranger is refused by every gated function | 2 gated functions, each refused with its own error |
| pass | Movva Privacy Pool: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | sMovva Privacy Pool: every state-changing function classified | 4 functions in the ABI, all in the catalog |
| pass | sMovva Privacy Pool: a stranger is refused by every gated function | 2 gated functions, each refused with its own error |
| pass | sMovva Privacy Pool: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | ETH band oracle (ChainlinkSignedFxOracle): every state-changing function classified | 6 functions in the ABI, all in the catalog |
| pass | ETH band oracle (ChainlinkSignedFxOracle): a stranger is refused by every gated function | 6 gated functions, each refused with its own error |
| pass | ETH band oracle (ChainlinkSignedFxOracle): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | ETH band oracle (ChainlinkSignedFxOracle): no pending scheduled change | none |
| pass | Ramp FX leg (ScaledFxBandOracle): every state-changing function classified | 0 functions in the ABI, all in the catalog |
| pass | Ramp FX leg (ScaledFxBandOracle): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | Ramp FX source (PythFxOracle): every state-changing function classified | 7 functions in the ABI, all in the catalog |
| pass | Ramp FX source (PythFxOracle): a stranger is refused by every gated function | 7 gated functions, each refused with its own error |
| pass | Ramp FX source (PythFxOracle): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | Ramp FX source (PythFxOracle): no pending scheduled change | none |
| pass | USDT band oracle (ChainlinkSignedFxOracle): every state-changing function classified | 6 functions in the ABI, all in the catalog |
| pass | USDT band oracle (ChainlinkSignedFxOracle): a stranger is refused by every gated function | 6 gated functions, each refused with its own error |
| pass | USDT band oracle (ChainlinkSignedFxOracle): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | USDT band oracle (ChainlinkSignedFxOracle): no pending scheduled change | none |
| pass | LPRegistry: every state-changing function classified | 16 functions in the ABI, all in the catalog |
| pass | LPRegistry: a stranger is refused by every gated function | 10 gated functions, each refused with its own error |
| pass | LPRegistry: not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | LPRegistry: no pending scheduled change | none |
| pass | AttestorQuorumVerifier (cards): every state-changing function classified | 7 functions in the ABI, all in the catalog |
| pass | AttestorQuorumVerifier (cards): a stranger is refused by every gated function | 7 gated functions, each refused with its own error |
| pass | AttestorQuorumVerifier (cards): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | AttestorQuorumVerifier (cards): no pending scheduled change | none |
| pass | ReclaimZkTlsVerifier (PIX, boleto): every state-changing function classified | 10 functions in the ABI, all in the catalog |
| pass | ReclaimZkTlsVerifier (PIX, boleto): a stranger is refused by every gated function | 10 gated functions, each refused with its own error |
| pass | ReclaimZkTlsVerifier (PIX, boleto): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | ReclaimZkTlsVerifier (PIX, boleto): no pending scheduled change | none |
| pass | FiatEscrow (on-ramp: ETH, USDT): every state-changing function classified | 24 functions in the ABI, all in the catalog |
| pass | FiatEscrow (on-ramp: ETH, USDT): a stranger is refused by every gated function | 9 gated functions, each refused with its own error |
| pass | FiatEscrow (on-ramp: ETH, USDT): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | FiatEscrow (on-ramp: ETH, USDT): no pending scheduled change | none |
| pass | OffRampEscrow (off-ramp: ETH, USDT): every state-changing function classified | 18 functions in the ABI, all in the catalog |
| pass | OffRampEscrow (off-ramp: ETH, USDT): a stranger is refused by every gated function | 9 gated functions, each refused with its own error |
| pass | OffRampEscrow (off-ramp: ETH, USDT): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | OffRampEscrow (off-ramp: ETH, USDT): no pending scheduled change | none |
| pass | FiatEscrow (Movva on-ramp): every state-changing function classified | 24 functions in the ABI, all in the catalog |
| pass | FiatEscrow (Movva on-ramp): a stranger is refused by every gated function | 9 gated functions, each refused with its own error |
| pass | FiatEscrow (Movva on-ramp): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | FiatEscrow (Movva on-ramp): no pending scheduled change | none |
| pass | OffRampEscrow (Movva off-ramp): every state-changing function classified | 18 functions in the ABI, all in the catalog |
| pass | OffRampEscrow (Movva off-ramp): a stranger is refused by every gated function | 9 gated functions, each refused with its own error |
| pass | OffRampEscrow (Movva off-ramp): not a proxy (EIP-1967 slots empty) | implementation empty, admin empty, beacon empty |
| pass | OffRampEscrow (Movva off-ramp): no pending scheduled change | none |

</details>

## Privileges

Read from the chain at block 11739552. For every contract: who holds each role, what the role can and cannot do (as the contract's code says, with the lines), and which state-changing functions the chain admits each caller to. The function list is the ABI of the build, so a function nobody classified would show as UNKNOWN and fail the checks: 0 do.

Probing: every state-changing function was `eth_call`ed with zero arguments from a stranger (`0x21f474a941692095F3122E1C82b9f24EC237f975`, holds nothing), the deployer and every current holder. "Refused" means the contract's own authorization error; "admitted" means the call got past the gate (it may then revert on the zero arguments). Nothing was sent.

### What remains, and why

| Contract | Role | Held by |
|---|---|---|
| Privacy Pools Entrypoint (proxy) | OWNER_ROLE | `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214` |
| Privacy Pools Entrypoint (proxy) | ASP_POSTMAN | `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214` |
| MovvaReserve | governor | `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214` |
| MovvaReserve | guardian | `0xD8BE774dA02aC76cDd52Eb82e8cF542B280FC87B` |
| MovvaReserve | treasurer | `0x5106689101d3d30382602cDE71C0dC5Ba1951baf` |
| MovvaReserve | gateway | `0xc3c8f1204250E69e1Fe45f74BE8e1Ee31C26De6c` |
| Movva FX leg (PythFxOracle) | governor | `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214` |
| FeeSplitter | governor | `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214` |
| NodeRewards | governor | `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214` |
| ETH band oracle (ChainlinkSignedFxOracle) | governor | `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214` |
| Ramp FX source (PythFxOracle) | governor | `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214` |
| USDT band oracle (ChainlinkSignedFxOracle) | governor | `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214` |
| LPRegistry | governor | `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214` |
| LPRegistry | LP (tier > NONE) | `0xc3c8f1204250E69e1Fe45f74BE8e1Ee31C26De6c` |
| AttestorQuorumVerifier (cards) | governor | `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214` |
| AttestorQuorumVerifier (cards) | attestor | `0xb93061a48E8Fc98417020963c82Ce15DA50079AB`, `0x3365BA2091fA21cD0A672780d222A50D92D2b096`, `0xA6BBbb40C7199f5D5B31205411dcA3F2A3e55091` |
| ReclaimZkTlsVerifier (PIX, boleto) | governor | `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214` |
| ReclaimZkTlsVerifier (PIX, boleto) | witness | `0x39b7fdF462673ef8cccDC1CAeFBf89DDAd7f7AAE`, `0xAbE8305411A49deB2843DCbdc3f0F831914c8817`, `0x791AB620eec7379f58baa8F9537Db6958f509c8b` |
| FiatEscrow (on-ramp: ETH, USDT) | governor | `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214` |
| FiatEscrow (on-ramp: ETH, USDT) | arbitrator | `0xD3C96EBe25C52CA6afD0AC2F54482FB8ecb4ac6C` |
| OffRampEscrow (off-ramp: ETH, USDT) | governor | `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214` |
| OffRampEscrow (off-ramp: ETH, USDT) | arbitrator | `0xD3C96EBe25C52CA6afD0AC2F54482FB8ecb4ac6C` |
| FiatEscrow (Movva on-ramp) | governor | `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214` |
| FiatEscrow (Movva on-ramp) | arbitrator | `0xD3C96EBe25C52CA6afD0AC2F54482FB8ecb4ac6C` |
| OffRampEscrow (Movva off-ramp) | governor | `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214` |
| OffRampEscrow (Movva off-ramp) | arbitrator | `0xD3C96EBe25C52CA6afD0AC2F54482FB8ecb4ac6C` |

Why each remains:

- **ASP postman** (Entrypoint `ASP_POSTMAN`). A private withdrawal must prove membership in the latest association-set root (`protocol/contracts/src/contracts/PrivacyPool.sol:59`), and only the postman posts roots (`protocol/contracts/src/contracts/Entrypoint.sol:93`). Without it, new deposits could only leave by ragequit (`protocol/contracts/src/contracts/PrivacyPool.sol:132`). It can admit or leave out deposits; it cannot move funds.
- **Arbitrator**, on each escrow. Some disputes no proof can settle: bank downtime, a reversed payment. A ruling reaches only a DISPUTED order and pays one of its two counterparties. A RELEASE needs an arbitrator registered before the dispute (`contracts/ramp/FiatEscrow.sol:924`). Rulings execute a day after posting (`contracts/ramp/FiatEscrow.sol:241`). With no arbitrator, a dispute can only time out back to the LP (`contracts/ramp/FiatEscrow.sol:960`).
- **zkTLS witnesses and card attestors.** They are the proof. Their signatures are what `verifyPayment` checks, and nothing on-chain can replace them.
- **Movva gateways, treasurer and guardian.** Only gateways mint and redeem (`contracts/movva/MovvaReserve.sol:250`). The treasurer alone funds the hedge, within `hedgeLimitBps` and the withdraw floor (`contracts/movva/MovvaReserve.sol:498`). The guardian can only pause minting (`contracts/movva/MovvaReserve.sol:718`).
- **LPs** in the registry. Their tier and credit limit bound what each may have at risk.
- **Keepers: none with on-chain power.** The Pyth keeper posts prices to Pyth, which anyone may do. `distribute`, `split`, `sync` and `finalize` are open to anyone.
- **Bound to code, not keys:** Movva's minter and sMovva's reserve (`RESERVE`, immutable), each pool's `ENTRYPOINT` (immutable), and the escrows the registry accepts.
- **Outside this deployment:** Pyth (its own governance can upgrade it), the Chainlink feeds (their proxies are owned by Chainlink), CreateX, and on mainnet Tether's USDT, which can freeze an escrow. These are trusted as they are and not inventoried here.

### Per contract

#### Privacy Pools Entrypoint (proxy)

`0x25efe3a412a69a2848AA1e2A90c0f0080d2de469` - `ERC1967Proxy` running `Entrypoint`, `protocol/contracts/src/contracts/Entrypoint.sol`. Privacy Pools' Entrypoint (upstream 0xbow, UUPS behind an ERC1967Proxy): deposits into and relays withdrawals from every pool, and holds the ASP root. **Holds funds.**

- DEFAULT_ADMIN_ROLE (admin OWNER_ROLE): **nobody**
- OWNER_ROLE (admin OWNER_ROLE): `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214`
- ASP_POSTMAN (admin OWNER_ROLE): `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214`
- EIP-1967: implementation `0xD726E05f28A27c5af85A1890244a00B29dE9449E`, admin `empty`, beacon `empty`

- **OWNER_ROLE** can upgrade the Entrypoint's code; register and remove pools; change a pool's minimum deposit, vetting fee and relay-fee cap; wind a pool down; withdraw every fee the Entrypoint holds, to any address; grant and revoke every role, OWNER_ROLE included. It cannot move pooled notes without an upgrade: a withdrawal needs the note's zero-knowledge proof. With an upgrade it can: the Entrypoint's code relays every withdrawal and holds depositors' ERC-20 approvals, so an upgrade is the one path from this role to users' money. (`node_modules/@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol:92`, `protocol/contracts/src/contracts/Entrypoint.sol:183`, `protocol/contracts/src/contracts/Entrypoint.sol:220`, `protocol/contracts/src/contracts/Entrypoint.sol:239`, `protocol/contracts/src/contracts/Entrypoint.sol:256`, `protocol/contracts/src/contracts/Entrypoint.sol:264`, …)
- **ASP_POSTMAN** can publish the association-set root. A private withdrawal must prove membership in the latest root, so the postman decides which deposits may withdraw privately. It cannot move funds, or stop a depositor leaving publicly: ragequit returns a deposit to its original depositor with no root at all. (`protocol/contracts/src/contracts/Entrypoint.sol:93`)
- **DEFAULT_ADMIN_ROLE** can call nothing: no Entrypoint function checks it, and it administers no role (every role's admin is OWNER_ROLE). Listed because AccessControl defines it. It cannot be held by anyone OWNER_ROLE did not grant it to. `initialize` grants it to nobody.

<details><summary>15 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `receive()` | only the Entrypoint (immutable) | - | Accept ETH only from the registered native pool (relayed withdrawals). | not probed (plain ETH transfer) | `protocol/contracts/src/contracts/Entrypoint.sol:298` |
| `deposit(address,uint256,uint256)` | anyone | - | Make an ERC20 deposit into the Privacy Pool <sub>(NatSpec)</sub> | open | `protocol/contracts/src/contracts/Entrypoint.sol:111` |
| `deposit(uint256)` | anyone | - | Make a native asset deposit into the Privacy Pool <sub>(NatSpec)</sub> | open | `protocol/contracts/src/contracts/Entrypoint.sol:111` |
| `grantRole(bytes32,address)` | the role's admin role (OWNER_ROLE, for every role here) (key) | instant | Grant a role. OWNER_ROLE is the admin of OWNER_ROLE, ASP_POSTMAN and DEFAULT_ADMIN_ROLE. | `0x4C0A…d214` OWNER_ROLE, ASP_POSTMAN, deployer | `node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol:143` |
| `initialize(address,address)` | nobody: the initializer has run (on the implementation: disabled) | - | Initializes the contract state <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:69` |
| `registerPool(address,address,uint256,uint256,uint256)` | an OWNER_ROLE holder (key) | instant | Register a Privacy Pool in the registry <sub>(NatSpec)</sub> | `0x4C0A…d214` OWNER_ROLE, ASP_POSTMAN, deployer | `protocol/contracts/src/contracts/Entrypoint.sol:183` |
| `relay(…)` | anyone carrying a proof the contract's verifier accepts | - | Process a withdrawal <sub>(NatSpec)</sub> | open | `protocol/contracts/src/contracts/Entrypoint.sol:133` |
| `removePool(address)` | an OWNER_ROLE holder (key) | instant | Remove a Privacy Pool from the registry <sub>(NatSpec)</sub> | `0x4C0A…d214` OWNER_ROLE, ASP_POSTMAN, deployer | `protocol/contracts/src/contracts/Entrypoint.sol:220` |
| `renounceRole(bytes32,address)` | only for the caller's own role | instant | Give up a role the caller holds (it must name itself). | **nobody** (every probed caller refused) | `node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol:178` |
| `revokeRole(bytes32,address)` | the role's admin role (OWNER_ROLE, for every role here) (key) | instant | Revoke a role from an account. | `0x4C0A…d214` OWNER_ROLE, ASP_POSTMAN, deployer | `node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol:158` |
| `updatePoolConfiguration(address,uint256,uint256,uint256)` | an OWNER_ROLE holder (key) | instant | Updates the configuration of a specific pool <sub>(NatSpec)</sub> | `0x4C0A…d214` OWNER_ROLE, ASP_POSTMAN, deployer | `protocol/contracts/src/contracts/Entrypoint.sol:239` |
| `updateRoot(uint256,string)` | an ASP_POSTMAN holder (key) | instant | Push a new root to the association root set <sub>(NatSpec)</sub> | `0x4C0A…d214` OWNER_ROLE, ASP_POSTMAN, deployer | `protocol/contracts/src/contracts/Entrypoint.sol:93` |
| `upgradeToAndCall(address,bytes)` | an OWNER_ROLE holder (key) | instant | Replace the Entrypoint's code (UUPS; `_authorizeUpgrade` is onlyRole(OWNER_ROLE)). | `0x4C0A…d214` OWNER_ROLE, ASP_POSTMAN, deployer | `node_modules/@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol:92` |
| `windDownPool(address)` | an OWNER_ROLE holder (key) | instant | Irreversebly halt deposits from a Privacy Pool <sub>(NatSpec)</sub> | inconclusive (bare revert): `0x4C0A…d214` OWNER_ROLE, ASP_POSTMAN, deployer | `protocol/contracts/src/contracts/Entrypoint.sol:256` |
| `withdrawFees(address,address)` | an OWNER_ROLE holder (key) | instant | Withdraw fees from the Entrypoint <sub>(NatSpec)</sub> | inconclusive (bare revert): `0x4C0A…d214` OWNER_ROLE, ASP_POSTMAN, deployer | `protocol/contracts/src/contracts/Entrypoint.sol:264` |

</details>

#### Entrypoint implementation

`0xD726E05f28A27c5af85A1890244a00B29dE9449E` - `Entrypoint`, `protocol/contracts/src/contracts/Entrypoint.sol`. The Entrypoint's implementation. Its own storage is never initialized (the constructor disables initializers), so no role exists in it, and `upgradeToAndCall` refuses a direct call (onlyProxy). It is code the proxy runs, not a second Entrypoint.

- EIP-1967 slots: empty (not a proxy)
- initializers disabled

<details><summary>15 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `receive()` | only the Entrypoint (immutable) | - | Accept ETH only from the registered native pool (relayed withdrawals). | not probed (plain ETH transfer) | `protocol/contracts/src/contracts/Entrypoint.sol:298` |
| `deposit(address,uint256,uint256)` | anyone | - | Make an ERC20 deposit into the Privacy Pool <sub>(NatSpec)</sub> | open | `protocol/contracts/src/contracts/Entrypoint.sol:111` |
| `deposit(uint256)` | anyone | - | Make a native asset deposit into the Privacy Pool <sub>(NatSpec)</sub> | open | `protocol/contracts/src/contracts/Entrypoint.sol:111` |
| `grantRole(bytes32,address)` | the role's admin role (OWNER_ROLE, for every role here) (key) | instant | Grant a role. OWNER_ROLE is the admin of OWNER_ROLE, ASP_POSTMAN and DEFAULT_ADMIN_ROLE. | **nobody** (every probed caller refused) | `node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol:143` |
| `initialize(address,address)` | nobody: the initializer has run (on the implementation: disabled) | - | Initializes the contract state <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:69` |
| `registerPool(address,address,uint256,uint256,uint256)` | an OWNER_ROLE holder (key) | instant | Register a Privacy Pool in the registry <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:183` |
| `relay(…)` | anyone carrying a proof the contract's verifier accepts | - | Process a withdrawal <sub>(NatSpec)</sub> | open | `protocol/contracts/src/contracts/Entrypoint.sol:133` |
| `removePool(address)` | an OWNER_ROLE holder (key) | instant | Remove a Privacy Pool from the registry <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:220` |
| `renounceRole(bytes32,address)` | only for the caller's own role | instant | Give up a role the caller holds (it must name itself). | **nobody** (every probed caller refused) | `node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol:178` |
| `revokeRole(bytes32,address)` | the role's admin role (OWNER_ROLE, for every role here) (key) | instant | Revoke a role from an account. | **nobody** (every probed caller refused) | `node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol:158` |
| `updatePoolConfiguration(address,uint256,uint256,uint256)` | an OWNER_ROLE holder (key) | instant | Updates the configuration of a specific pool <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:239` |
| `updateRoot(uint256,string)` | an ASP_POSTMAN holder (key) | instant | Push a new root to the association root set <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:93` |
| `upgradeToAndCall(address,bytes)` | an OWNER_ROLE holder (key) | instant | Replace the Entrypoint's code (UUPS; `_authorizeUpgrade` is onlyRole(OWNER_ROLE)). | **nobody** (every probed caller refused) | `node_modules/@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol:92` |
| `windDownPool(address)` | an OWNER_ROLE holder (key) | instant | Irreversebly halt deposits from a Privacy Pool <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:256` |
| `withdrawFees(address,address)` | an OWNER_ROLE holder (key) | instant | Withdraw fees from the Entrypoint <sub>(NatSpec)</sub> | **nobody** (every probed caller refused) | `protocol/contracts/src/contracts/Entrypoint.sol:264` |

</details>

#### Withdrawal Groth16 verifier

`0xa6a4327FC63c88EA69372A388217f0BA7d42f897` - `WithdrawalVerifier`, `protocol/contracts/src/contracts/verifiers/WithdrawalVerifier.sol`. Groth16 verifier for withdrawal proofs: pure code, no state.

- EIP-1967 slots: empty (not a proxy)

No state-changing functions.

#### Ragequit (commitment) Groth16 verifier

`0xB1c6d175d5D8aF7330FC35fc9579b67153ebcD41` - `CommitmentVerifier`, `protocol/contracts/src/contracts/verifiers/CommitmentVerifier.sol`. Groth16 verifier for ragequit (commitment) proofs: pure code, no state.

- EIP-1967 slots: empty (not a proxy)

No state-changing functions.

#### ETH Privacy Pool

`0x8fD2422a51f400e88aB40065343f9eBF892bec91` - `PrivacyPoolSimple`, `protocol/contracts/src/contracts/implementations/PrivacyPoolSimple.sol`. A Privacy Pool for native ETH (upstream 0xbow). No owner; bound to one Entrypoint and one asset at construction. **Holds funds.**

- ENTRYPOINT (immutable): `0x25efe3a412a69a2848AA1e2A90c0f0080d2de469`
- dead = `false` (wound down: no new deposits)
- EIP-1967 slots: empty (not a proxy)

- **ENTRYPOINT** can deposit on a depositor's behalf, and wind the pool down. It cannot withdraw: that needs a note's proof, or its original depositor for ragequit. (`protocol/contracts/src/contracts/PrivacyPool.sol:82`, `protocol/contracts/src/contracts/PrivacyPool.sol:157`)

<details><summary>4 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `deposit(address,uint256,uint256)` | only the Entrypoint (immutable) | - | Deposit funds into the Privacy Pool <sub>(NatSpec)</sub> | `0x25ef…e469` ENTRYPOINT | `protocol/contracts/src/contracts/PrivacyPool.sol:82` |
| `ragequit((uint256[2],uint256[2][2],uint256[2],uint256[4]))` | a party to that offer, order, sale, note or reward | - | Publicly withdraw funds to original depositor without exposing secrets <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `protocol/contracts/src/contracts/PrivacyPool.sol:132` |
| `windDown()` | only the Entrypoint (immutable) | - | Irreversibly suspends deposits <sub>(NatSpec)</sub> | `0x25ef…e469` ENTRYPOINT | `protocol/contracts/src/contracts/PrivacyPool.sol:157` |
| `withdraw(…)` | anyone carrying a proof the contract's verifier accepts | - | Privately withdraw funds by spending an existing commitment <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `protocol/contracts/src/contracts/PrivacyPool.sol:110` |

</details>

#### PoseidonT3 library

`0x8ffdA7Ed8B4aD98C2C34f54B76821711F4a6f2C5` - `PoseidonT3`, `node_modules/poseidon-solidity/PoseidonT3.sol`. Poseidon hash library (2 inputs): pure code, no state. Linked into the pools.

- EIP-1967 slots: empty (not a proxy)

No state-changing functions.

#### PoseidonT4 library

`0xe393dd7287Db9982e6f845824854Baf8b8e823AF` - `PoseidonT4`, `node_modules/poseidon-solidity/PoseidonT4.sol`. Poseidon hash library (3 inputs): pure code, no state. Linked into the pools.

- EIP-1967 slots: empty (not a proxy)

No state-changing functions.

#### Stand-in USDT (TetherLike)

`0xc241A572883241946a6780E996808C321b06baB0` - `TetherLike`, `contracts/test/ERC4626Adapter.t.sol`. Rehearsal stand-in for USDT (contracts/test/ERC4626Adapter.t.sol): Tether's surface, 6 decimals. NOT a mainnet contract.

- owner (receives transfer fees): `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214`
- paused = `false` (transfers refused)
- EIP-1967 slots: empty (not a proxy)

- **anyone** can mint, pause, blacklist and set fees: every function is open, so its balances mean nothing. It cannot be stopped: there is no owner check anywhere. It exists only because Sepolia has no canonical USDT. (`contracts/test/ERC4626Adapter.t.sol:34`, `contracts/test/ERC4626Adapter.t.sol:70`, `contracts/test/ERC4626Adapter.t.sol:62`, `contracts/test/ERC4626Adapter.t.sol:56`)

<details><summary>8 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `addBlackList(address)` | anyone | - | Blacklist an address. Open to everyone. | open | `contracts/test/ERC4626Adapter.t.sol:62` |
| `approve(address,uint256)` | anyone | - | Set an allowance over the caller's own balance. | open | `contracts/test/ERC4626Adapter.t.sol:51` |
| `mint(address,uint256)` | anyone | - | Create tokens for anyone. Open to everyone: this is a test token. | open | `contracts/test/ERC4626Adapter.t.sol:34` |
| `removeBlackList(address)` | anyone | - | Unblacklist an address. Open to everyone. | open | `contracts/test/ERC4626Adapter.t.sol:66` |
| `setParams(uint256,uint256)` | anyone | - | Set the transfer fee (< 20 bps, < 50 tokens), paid to `owner`. Open to everyone. | open | `contracts/test/ERC4626Adapter.t.sol:56` |
| `setPaused(bool)` | anyone | - | Pause or unpause transfers. Open to everyone. | open | `contracts/test/ERC4626Adapter.t.sol:70` |
| `transfer(address,uint256)` | anyone | - | Move the caller's own balance. | open | `contracts/test/ERC4626Adapter.t.sol:39` |
| `transferFrom(address,address,uint256)` | anyone | - | Move a balance within an allowance its owner gave the caller. | open | `contracts/test/ERC4626Adapter.t.sol:44` |

</details>

#### MovvaReserve

`0xB64178cFEbb96baa9955eF70eA4C23bF9aC0914b` - `MovvaReserve`, `contracts/movva/MovvaReserve.sol`. Holds the USDT backing Movva; mints and redeems Movva for gateways at the Pyth FX rate; distributes surplus to sMovva. **Holds funds.**

- governor `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214`; setup complete; delay 48 h; 0 pending change(s)
- guardian: `0xD8BE774dA02aC76cDd52Eb82e8cF542B280FC87B`
- treasurer: `0x5106689101d3d30382602cDE71C0dC5Ba1951baf`
- gateway: `0xc3c8f1204250E69e1Fe45f74BE8e1Ee31C26De6c`
- hedge treasury (payee): `0x746F3CAC9E3D114071647256B7D52948fAB509Cc`
- fee recipient (payee): `0x230378a1C00AA61E05Edde834A576B5feC5a6372`
- sMovva (distribution payee): `0x935827E58349bF489A13FcB3105dBD2Dd53Bb8CE`
- yield vault: none
- mintPaused = `false` (gateways cannot mint)
- vaultDepositsPaused = `false` (no USDT goes into the yield vault)
- supplyCap = `1000000000000000000000000` (most Movva that may exist (1e18 = R$ 1,00))
- EIP-1967 slots: empty (not a proxy)

- **governor** can add and remove gateways; replace the guardian, treasurer, hedge treasury and fee recipient; change fees (hard caps 1% mint, 1% redeem, 50% of distributions), collateral ratios (never under 100%), the supply cap and the hedge and distribution limits, the oracle legs and their max ages, the yield vault and sMovva; pull USDT back from the vault into the reserve; pause and resume vault deposits and minting. After setup, every change that adds risk waits GOVERNANCE_DELAY; removing, lowering and pausing are instant. It cannot mint or burn Movva itself, send the reserve's USDT anywhere (pullFromVault only brings it back into the reserve), pause redemptions, or pass the hard fee caps. (`contracts/movva/MovvaReserve.sol:570`, `contracts/movva/MovvaReserve.sol:578`, `contracts/movva/MovvaReserve.sol:588`, `contracts/movva/MovvaReserve.sol:595`, `contracts/movva/MovvaReserve.sol:603`, `contracts/movva/MovvaReserve.sol:611`, …)
- **guardian** can pause minting, at once. It cannot resume minting (governor only) or do anything else. (`contracts/movva/MovvaReserve.sol:718`)
- **treasurer** can send USDT to the hedge treasury, and only there: at most hedgeLimitBps (8%) of the reserve per rolling 24 hours, never leaving the collateral ratio under the withdraw floor (103%). It cannot choose the destination, or pass the limit or the floor. (`contracts/movva/MovvaReserve.sol:498`)
- **gateway** can mint Movva for USDT it pays in, and redeem Movva for USDT, at the oracle rate less fees, within the supply cap and the mint collateral floor. It cannot mint without paying in. A wrong rate inside the oracle bounds is the residual risk the contract names: it is why only contracted gateways mint and redeem. (`contracts/movva/MovvaReserve.sol:423`, `contracts/movva/MovvaReserve.sol:468`)

<details><summary>25 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:145` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:119` |
| `distribute()` | anyone | - | Anyone, rate-limited: mint the surplus above target as Movva to sMovva and the fee recipient. <sub>(NatSpec)</sub> | open | `contracts/movva/MovvaReserve.sol:549` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:159` |
| `mint(uint256,address,uint256)` | a gateway (key) | - | Gateway only: deposit USDT, receive Movva worth it at the oracle rate, less the mint fee. <sub>(NatSpec)</sub> | `0xc3c8…De6c` gateway | `contracts/movva/MovvaReserve.sol:423` |
| `pauseMint()` | the guardian or the governor (key) | instant | Guardian or governor: stop minting. Redemptions cannot be paused. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer<br>`0xD8BE…C87B` guardian | `contracts/movva/MovvaReserve.sol:718` |
| `pullFromVault(uint256)` | the governor (key) | instant | Instant, governor only: bring `usdt` back from the vault into the reserve, and stop depositing into it until `setVaultDepositsPaused(false)`. `type(uint256).max` redeems every share. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/movva/MovvaReserve.sol:683` |
| `recapitalize(uint256)` | anyone | - | Anyone: add USDT without minting. <sub>(NatSpec)</sub> | open | `contracts/movva/MovvaReserve.sol:530` |
| `redeem(uint256,address,uint256)` | a gateway (key) | - | Gateway only: burn Movva, receive USDT worth min(1, collateral ratio) of it, less the redeem fee. <sub>(NatSpec)</sub> | `0xc3c8…De6c` gateway | `contracts/movva/MovvaReserve.sol:468` |
| `resumeMint()` | the governor (key) | instant | Resume minting. | `0x4C0A…d214` governor, deployer | `contracts/movva/MovvaReserve.sol:724` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:136` |
| `setCollateralRatios(uint16,uint16,uint16)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | LOWERING a ratio is delayed (it lets value out at less backing); raising is instant. None may be below 100%, and they must stay ordered: mint floor <= withdraw floor <= target. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/movva/MovvaReserve.sol:628` |
| `setFeeRecipient(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Delayed: this address is paid every fee. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/movva/MovvaReserve.sol:603` |
| `setFees(uint16,uint16,uint16)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Raising any fee is delayed; lowering is instant. Hard caps apply either way. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/movva/MovvaReserve.sol:611` |
| `setGateway(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Adding a gateway waits out the delay; removing one is instant. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/movva/MovvaReserve.sol:570` |
| `setGuardian(address)` | the governor (key) | instant | Instant: the guardian can only pause minting. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/movva/MovvaReserve.sol:578` |
| `setHedgeTreasury(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Delayed: this address is where hedge withdrawals go. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/movva/MovvaReserve.sol:595` |
| `setLimits(uint256,uint16,uint16)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Raising the supply cap, the hedge limit or the distribution cap is delayed; lowering any of them is instant. A supply cap of zero stops minting and distributing. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/movva/MovvaReserve.sol:642` |
| `setOracle(address,address,uint64,uint64)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Repointing either leg or lengthening a max age is delayed; only tightening an age is instant. The rate prices every mint and redemption, so unlike the ramps' band oracles its legs are not an instan... <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/movva/MovvaReserve.sol:654` |
| `setSavings(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Delayed: sMovva receives every distribution. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/movva/MovvaReserve.sol:710` |
| `setTreasurer(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | A new treasurer waits out the delay; revoking the role (zero) is instant. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/movva/MovvaReserve.sol:588` |
| `setVaultDepositsPaused(bool)` | the governor (key) | instant | Instant either way: the vault was chosen through the delay, and exits are unaffected. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/movva/MovvaReserve.sol:703` |
| `setYieldVault(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Choose the yield vault. A new vault is delayed; removing it (zero) is instant. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/movva/MovvaReserve.sol:667` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:125` |
| `withdrawToHedge(uint256)` | the treasurer (key) | - | Treasurer only, bounded: send USDT to the hedge treasury without breaching the withdraw floor. <sub>(NatSpec)</sub> | `0x5106…1baf` treasurer | `contracts/movva/MovvaReserve.sol:498` |

</details>

#### Movva (token)

`0xCe80e2e723b6cEDa9fF5E770bfCa9651F7220428` - `Movva`, `contracts/movva/Movva.sol`. The Movva ERC-20 (R$ 1,00). Its only minter is the MovvaReserve that deployed it.

- minter (RESERVE, immutable): `0xB64178cFEbb96baa9955eF70eA4C23bF9aC0914b`
- EIP-1967 slots: empty (not a proxy)

- **RESERVE** can mint to anyone, and burn its own balance. It cannot burn anyone else's Movva. No owner, no pause, no blacklist, no upgrade. (`contracts/movva/Movva.sol:49`, `contracts/movva/Movva.sol:55`)

<details><summary>6 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `approve(address,uint256)` | anyone | - | Set an allowance over the caller's own balance. | open | `node_modules/@openzeppelin/contracts/token/ERC20/ERC20.sol:127` |
| `burn(uint256)` | only the MovvaReserve (immutable) | - | Reserve only: destroy `amount` of the reserve's own Movva. <sub>(NatSpec)</sub> | `0xB641…914b` minter | `contracts/movva/Movva.sol:55` |
| `mint(address,uint256)` | only the MovvaReserve (immutable) | - | Reserve only: create `amount` Movva for `to`. <sub>(NatSpec)</sub> | `0xB641…914b` minter | `contracts/movva/Movva.sol:49` |
| `permit(…)` | anyone | - | EIP-2612: set an allowance with the owner's signature. | open | `node_modules/@openzeppelin/contracts/token/ERC20/extensions/ERC20Permit.sol:44` |
| `transfer(address,uint256)` | anyone | - | Move the caller's own balance. | open | `node_modules/@openzeppelin/contracts/token/ERC20/ERC20.sol:104` |
| `transferFrom(address,address,uint256)` | anyone | - | Move a balance within an allowance its owner gave the caller. | open | `node_modules/@openzeppelin/contracts/token/ERC20/ERC20.sol:149` |

</details>

#### SavingsMovva (sMovva)

`0x935827E58349bF489A13FcB3105dBD2Dd53Bb8CE` - `SavingsMovva`, `contracts/movva/SavingsMovva.sol`. sMovva: an ERC-4626 vault over Movva whose share price rises as the reserve distributes surplus into it. **Holds funds.**

- RESERVE (immutable): `0xB64178cFEbb96baa9955eF70eA4C23bF9aC0914b`
- EIP-1967 slots: empty (not a proxy)

- **RESERVE** can announce a distribution it has minted in, which then vests. It cannot move or freeze shares. No owner; deposits and withdrawals are never limited. (`contracts/movva/SavingsMovva.sol:120`)

<details><summary>8 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `approve(address,uint256)` | anyone | - | Set an allowance over the caller's own balance. | open | `node_modules/@openzeppelin/contracts/token/ERC20/ERC20.sol:127` |
| `deposit(uint256,address)` | anyone | - | ERC-4626 deposit of Movva for shares. | open | `contracts/movva/SavingsMovva.sol:139` |
| `mint(uint256,address)` | anyone | - | ERC-4626 mint of shares for Movva. | open | `contracts/movva/SavingsMovva.sol:143` |
| `notifyDistribution(uint256)` | only the MovvaReserve (immutable) | - | Reserve only: `amount` Movva has just been minted to this contract; vest it. <sub>(NatSpec)</sub> | `0xB641…914b` RESERVE | `contracts/movva/SavingsMovva.sol:120` |
| `redeem(uint256,address,address)` | a party to that offer, order, sale, note or reward | - | ERC-4626 redeem of an owner's shares (owner or allowance). | open | `contracts/movva/SavingsMovva.sol:156` |
| `transfer(address,uint256)` | anyone | - | Move the caller's own balance. | open | `node_modules/@openzeppelin/contracts/token/ERC20/ERC20.sol:104` |
| `transferFrom(address,address,uint256)` | anyone | - | Move a balance within an allowance its owner gave the caller. | open | `node_modules/@openzeppelin/contracts/token/ERC20/ERC20.sol:149` |
| `withdraw(uint256,address,address)` | a party to that offer, order, sale, note or reward | - | ERC-4626 withdraw of an owner's Movva (owner or allowance). | open | `contracts/movva/SavingsMovva.sol:147` |

</details>

#### Movva FX leg (PythFxOracle)

`0x6A7Fa8E2A5CfA74DacFf15C6ed9674b55DbAB96A` - `PythFxOracle`, `contracts/ramp/PythFxOracle.sol`. The BRL/USD FX leg over Pyth's FX.USD/BRL, with a band reading for the hours the FX market is closed.

- governor `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214`; setup complete; delay 48 h; 0 pending change(s)
- EIP-1967 slots: empty (not a proxy)

- **governor** can repoint the Pyth price id, and loosen or tighten the max ages and the confidence bound (loosening waits GOVERNANCE_DELAY, tightening is instant). It cannot post a price (Pyth prices are posted permissionlessly on Pyth) or change which Pyth contract it reads: PYTH is immutable. (`contracts/ramp/PythFxOracle.sol:140`, `contracts/ramp/PythFxOracle.sol:148`, `contracts/common/DelayedGovernance.sol:125`)

<details><summary>7 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:145` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:119` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:159` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:136` |
| `setFeed(bytes32)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Repointing the feed waits out the governance delay. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/PythFxOracle.sol:140` |
| `setLimits(uint64,uint64,uint16)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Loosening any limit waits out the governance delay; tightening is instant. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/PythFxOracle.sol:148` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:125` |

</details>

#### Movva band adapter (ScaledFxBandOracle)

`0x4f524BFFc6E6E5c5962D48F597EAE6b86dF2814A` - `ScaledFxBandOracle`, `contracts/movva/ScaledFxBandOracle.sol`. Reads an FX leg and re-expresses it in centavos; no governance of its own: SOURCE is immutable.

- EIP-1967 slots: empty (not a proxy)

No state-changing functions.

#### FeeSplitter

`0x230378a1C00AA61E05Edde834A576B5feC5a6372` - `FeeSplitter`, `contracts/movva/FeeSplitter.sol`. The reserve's fee recipient: splits Movva fee revenue between NodeRewards and Mova's treasury. **Holds funds.**

- governor `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214`; setup complete; delay 48 h; 0 pending change(s)
- treasury (payee): `0x1577D5b15F09C2A47F6f3dB80f7b2EB47095897E`
- rewards (payee): `0x3A59156F79a9a1e00C212a1e2dF5Aa20EA84EAE1`
- lpRewardShareBps = `0` (the LPs' share of fee revenue)
- EIP-1967 slots: empty (not a proxy)

- **governor** can change the LPs' share (never above 50%), the treasury and the rewards contract. It cannot take what the splitter holds: `split` pays only the treasury and the rewards contract, and anyone may call it. (`contracts/movva/FeeSplitter.sol:109`, `contracts/movva/FeeSplitter.sol:117`, `contracts/movva/FeeSplitter.sol:126`, `contracts/common/DelayedGovernance.sol:125`)

<details><summary>9 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:145` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:119` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:159` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:136` |
| `setLpRewardShare(uint16)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Raising the LPs' share waits out the delay; lowering it is instant. Never above 50%. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/movva/FeeSplitter.sol:109` |
| `setRewards(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | A new rewards contract waits out the delay; removing it (zero) is instant. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/movva/FeeSplitter.sol:126` |
| `setTreasury(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Delayed: this address is paid Mova's revenue. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/movva/FeeSplitter.sol:117` |
| `split()` | anyone | - | Send everything here: the LPs' share to the rewards contract, the rest to the treasury. Anyone may call. <sub>(NatSpec)</sub> | open | `contracts/movva/FeeSplitter.sol:82` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:125` |

</details>

#### NodeRewards

`0x3A59156F79a9a1e00C212a1e2dF5Aa20EA84EAE1` - `NodeRewards`, `contracts/ramp/NodeRewards.sol`. Node-provider rewards: fee revenue shared among INSTITUTIONAL and AFFILIATED LPs by settled BRL volume, epoch by epoch. **Holds funds.**

- governor `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214`; setup complete; delay 48 h; 0 pending change(s)
- registry (reports settlements): `0xD0937a624384900D68a01D082c0233b3987b0fbb`
- excluded LP: none
- EIP-1967 slots: empty (not a proxy)

- **governor** can bind or unbind the registry, set the reward limits (within MAX_REWARD_BPS_OF_VOLUME), exclude or reinstate an LP, and void an LP's volume while its epoch is in review. It cannot pay anyone: rewards go only to LPs claiming their own shares, and voided shares roll forward instead of going to anyone else. (`contracts/ramp/NodeRewards.sol:408`, `contracts/ramp/NodeRewards.sol:419`, `contracts/ramp/NodeRewards.sol:429`, `contracts/ramp/NodeRewards.sol:441`, `contracts/common/DelayedGovernance.sol:125`)
- **registry** can report settlements, which count as volume. It cannot pay rewards. (`contracts/ramp/NodeRewards.sol:236`)

<details><summary>13 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:145` |
| `claim(uint256[],address)` | a party to that offer, order, sale, note or reward | - | Claim the caller's rewards for finalized epochs, paid to `to`. <sub>(NatSpec)</sub> | open | `contracts/ramp/NodeRewards.sol:324` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:119` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:159` |
| `finalize(uint256)` | anyone | - | Finalize up to `maxEpochs` epochs whose review has ended, oldest first. Anyone may call it. <sub>(NatSpec)</sub> | open | `contracts/ramp/NodeRewards.sol:279` |
| `onSettled(address,uint256,uint8)` | only the bound LPRegistry | - | Count a settlement's volume for the LP. | `0xD093…0fbb` registry | `contracts/ramp/NodeRewards.sol:236` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:136` |
| `setExcluded(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Excluding an LP is instant; reinstating one waits out the delay. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/NodeRewards.sol:429` |
| `setRegistry(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Bind the registry whose settlement reports count; zero unbinds. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/NodeRewards.sol:408` |
| `setRewardLimits(uint16,uint256,uint256)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Raising the rate or the per-LP cap, or lowering the minimum, is delayed; the opposite of each is instant. The rate can never pass MAX_REWARD_BPS_OF_VOLUME. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/NodeRewards.sol:419` |
| `sync()` | anyone | - | Book reward tokens that arrived since the last sync into the current epoch. Anyone may call it; FeeSplitter calls it after every transfer here. <sub>(NatSpec)</sub> | open | `contracts/ramp/NodeRewards.sol:256` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:125` |
| `voidVolume(uint256,address)` | the governor (key) | instant | Instant, governor only: void `lp`'s volume for an epoch still in review, current or ended. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/NodeRewards.sol:441` |

</details>

#### Movva Privacy Pool

`0x85f4dc7c9C3AF5C62BA744ee08B87B74C638a040` - `PrivacyPoolComplex`, `protocol/contracts/src/contracts/implementations/PrivacyPoolComplex.sol`. A Privacy Pool for an ERC-20 (Movva, sMovva) (upstream 0xbow). No owner; bound to one Entrypoint and one asset at construction. **Holds funds.**

- ENTRYPOINT (immutable): `0x25efe3a412a69a2848AA1e2A90c0f0080d2de469`
- dead = `false` (wound down: no new deposits)
- EIP-1967 slots: empty (not a proxy)

- **ENTRYPOINT** can deposit on a depositor's behalf, and wind the pool down. It cannot withdraw: that needs a note's proof, or its original depositor for ragequit. (`protocol/contracts/src/contracts/PrivacyPool.sol:82`, `protocol/contracts/src/contracts/PrivacyPool.sol:157`)

<details><summary>4 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `deposit(address,uint256,uint256)` | only the Entrypoint (immutable) | - | Deposit funds into the Privacy Pool <sub>(NatSpec)</sub> | `0x25ef…e469` ENTRYPOINT | `protocol/contracts/src/contracts/PrivacyPool.sol:82` |
| `ragequit((uint256[2],uint256[2][2],uint256[2],uint256[4]))` | a party to that offer, order, sale, note or reward | - | Publicly withdraw funds to original depositor without exposing secrets <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `protocol/contracts/src/contracts/PrivacyPool.sol:132` |
| `windDown()` | only the Entrypoint (immutable) | - | Irreversibly suspends deposits <sub>(NatSpec)</sub> | `0x25ef…e469` ENTRYPOINT | `protocol/contracts/src/contracts/PrivacyPool.sol:157` |
| `withdraw(…)` | anyone carrying a proof the contract's verifier accepts | - | Privately withdraw funds by spending an existing commitment <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `protocol/contracts/src/contracts/PrivacyPool.sol:110` |

</details>

#### sMovva Privacy Pool

`0x7342F695AdD5a0f878f4DB8576891D8B58AcfD42` - `PrivacyPoolComplex`, `protocol/contracts/src/contracts/implementations/PrivacyPoolComplex.sol`. A Privacy Pool for an ERC-20 (Movva, sMovva) (upstream 0xbow). No owner; bound to one Entrypoint and one asset at construction. **Holds funds.**

- ENTRYPOINT (immutable): `0x25efe3a412a69a2848AA1e2A90c0f0080d2de469`
- dead = `false` (wound down: no new deposits)
- EIP-1967 slots: empty (not a proxy)

- **ENTRYPOINT** can deposit on a depositor's behalf, and wind the pool down. It cannot withdraw: that needs a note's proof, or its original depositor for ragequit. (`protocol/contracts/src/contracts/PrivacyPool.sol:82`, `protocol/contracts/src/contracts/PrivacyPool.sol:157`)

<details><summary>4 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `deposit(address,uint256,uint256)` | only the Entrypoint (immutable) | - | Deposit funds into the Privacy Pool <sub>(NatSpec)</sub> | `0x25ef…e469` ENTRYPOINT | `protocol/contracts/src/contracts/PrivacyPool.sol:82` |
| `ragequit((uint256[2],uint256[2][2],uint256[2],uint256[4]))` | a party to that offer, order, sale, note or reward | - | Publicly withdraw funds to original depositor without exposing secrets <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `protocol/contracts/src/contracts/PrivacyPool.sol:132` |
| `windDown()` | only the Entrypoint (immutable) | - | Irreversibly suspends deposits <sub>(NatSpec)</sub> | `0x25ef…e469` ENTRYPOINT | `protocol/contracts/src/contracts/PrivacyPool.sol:157` |
| `withdraw(…)` | anyone carrying a proof the contract's verifier accepts | - | Privately withdraw funds by spending an existing commitment <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `protocol/contracts/src/contracts/PrivacyPool.sol:110` |

</details>

#### ETH band oracle (ChainlinkSignedFxOracle)

`0x067a1C950B02114a0757Ef2801151b00b2d89080` - `ChainlinkSignedFxOracle`, `contracts/ramp/ChainlinkSignedFxOracle.sol`. An asset band: Chainlink ASSET/USD crossed with the FX leg, in BRL centavos per unit.

- governor `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214`; setup complete; delay 48 h; 0 pending change(s)
- EIP-1967 slots: empty (not a proxy)

- **governor** can repoint either leg and change their max ages (repointing and lengthening wait; tightening is instant). It cannot set a price. (`contracts/ramp/ChainlinkSignedFxOracle.sol:119`, `contracts/common/DelayedGovernance.sol:125`)

<details><summary>6 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:145` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:119` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:159` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:136` |
| `setLegs(address,address,uint64,uint64)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Repointing either leg or lengthening either max age waits out the governance delay; tightening an age, legs unchanged, is instant. See Governance above. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/ChainlinkSignedFxOracle.sol:119` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:125` |

</details>

#### Ramp FX leg (ScaledFxBandOracle)

`0xd011cA5c9BA5CfAfc7c2Ff4d190dD81290beAA95` - `ScaledFxBandOracle`, `contracts/movva/ScaledFxBandOracle.sol`. Reads an FX leg and re-expresses it in centavos; no governance of its own: SOURCE is immutable.

- EIP-1967 slots: empty (not a proxy)

No state-changing functions.

#### Ramp FX source (PythFxOracle)

`0xEF3909f59b4ffe446ba9B14E813bd076F77dD782` - `PythFxOracle`, `contracts/ramp/PythFxOracle.sol`. The BRL/USD FX leg over Pyth's FX.USD/BRL, with a band reading for the hours the FX market is closed.

- governor `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214`; setup complete; delay 48 h; 0 pending change(s)
- EIP-1967 slots: empty (not a proxy)

- **governor** can repoint the Pyth price id, and loosen or tighten the max ages and the confidence bound (loosening waits GOVERNANCE_DELAY, tightening is instant). It cannot post a price (Pyth prices are posted permissionlessly on Pyth) or change which Pyth contract it reads: PYTH is immutable. (`contracts/ramp/PythFxOracle.sol:140`, `contracts/ramp/PythFxOracle.sol:148`, `contracts/common/DelayedGovernance.sol:125`)

<details><summary>7 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:145` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:119` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:159` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:136` |
| `setFeed(bytes32)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Repointing the feed waits out the governance delay. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/PythFxOracle.sol:140` |
| `setLimits(uint64,uint64,uint16)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Loosening any limit waits out the governance delay; tightening is instant. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/PythFxOracle.sol:148` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:125` |

</details>

#### USDT band oracle (ChainlinkSignedFxOracle)

`0x4bc6D57898B61764E95F924CbbA8F06B352B1b79` - `ChainlinkSignedFxOracle`, `contracts/ramp/ChainlinkSignedFxOracle.sol`. An asset band: Chainlink ASSET/USD crossed with the FX leg, in BRL centavos per unit.

- governor `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214`; setup complete; delay 48 h; 0 pending change(s)
- EIP-1967 slots: empty (not a proxy)

- **governor** can repoint either leg and change their max ages (repointing and lengthening wait; tightening is instant). It cannot set a price. (`contracts/ramp/ChainlinkSignedFxOracle.sol:119`, `contracts/common/DelayedGovernance.sol:125`)

<details><summary>6 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:145` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:119` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:159` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:136` |
| `setLegs(address,address,uint64,uint64)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Repointing either leg or lengthening either max age waits out the governance delay; tightening an age, legs unchanged, is instant. See Governance above. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/ChainlinkSignedFxOracle.sol:119` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:125` |

</details>

#### LPRegistry

`0xD0937a624384900D68a01D082c0233b3987b0fbb` - `LPRegistry`, `contracts/ramp/LPRegistry.sol`. LP onboarding, network phases, tiers, credit and exposure across every escrow.

- governor `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214`; setup complete; delay 48 h; 0 pending change(s)
- escrow: `0x09f0dAc9d938444b3f86a639504D38521100f994`, `0xC640d520768790A817FdC50A1af17Af810d8FaaC`, `0xF9A41BFc51E3FBc0593a8112f9834B8D011914b7`, `0x7E4aa58924e379279a6A6458A9a319209c48BCfe`
- rewards hook: `0x3A59156F79a9a1e00C212a1e2dF5Aa20EA84EAE1`
- LP (tier > NONE): `0xc3c8f1204250E69e1Fe45f74BE8e1Ee31C26De6c`
- phase = `0` (0 = A (governor-admitted institutions only), 1 = B (+ affiliates), 2 = C (+ retail))
- EIP-1967 slots: empty (not a proxy)

- **governor** can accept and drop escrows, open and close network phases, set the rewards hook, and admit, re-tier, suspend or remove LPs with their credit limits. It cannot move funds: the registry holds none. It decides how much an LP may have at risk, and which escrows may reserve it. (`contracts/ramp/LPRegistry.sol:189`, `contracts/ramp/LPRegistry.sol:197`, `contracts/ramp/LPRegistry.sol:210`, `contracts/ramp/LPRegistry.sol:228`, `contracts/common/DelayedGovernance.sol:125`)
- **escrow** can reserve and release LPs' exposure and record settlements and lost disputes. It cannot release exposure another escrow reserved. (`contracts/ramp/LPRegistry.sol:406`, `contracts/ramp/LPRegistry.sol:424`, `contracts/ramp/LPRegistry.sol:447`, `contracts/ramp/LPRegistry.sol:474`)

<details><summary>16 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:145` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:119` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:159` |
| `recordDispute(address)` | only an escrow the registry accepts | - | Called by the escrow when a dispute is ruled against the LP. MUST NOT revert. <sub>(NatSpec)</sub> | `0x21f4…f975` stranger<br>`0x4C0A…d214` governor, deployer<br>`0x09f0…f994` escrow<br>`0xC640…FaaC` escrow<br>`0xF9A4…14b7` escrow<br>`0x7E4a…BCfe` escrow<br>`0xc3c8…De6c` LP | `contracts/ramp/LPRegistry.sol:474` |
| `recordSettled(address,uint256)` | only an escrow the registry accepts | - | Record a settlement (ignored when the caller is not an accepted escrow). | `0x21f4…f975` stranger<br>`0x4C0A…d214` governor, deployer<br>`0x09f0…f994` escrow<br>`0xC640…FaaC` escrow<br>`0xF9A4…14b7` escrow<br>`0x7E4a…BCfe` escrow<br>`0xc3c8…De6c` LP | `contracts/ramp/LPRegistry.sol:447` |
| `register()` | anyone | - | Permissionless retail onboarding, Phase C only. The cap, not the gate, is the control - once the network has been opened to retail at all. <sub>(NatSpec)</sub> | open | `contracts/ramp/LPRegistry.sol:273` |
| `releaseExposure(address,uint256)` | only an escrow the registry accepts | - | Give back exposure this escrow reserved. MUST NOT revert: it runs on release and refund paths, after money has moved. <sub>(NatSpec)</sub> | `0x21f4…f975` stranger<br>`0x4C0A…d214` governor, deployer<br>`0x09f0…f994` escrow<br>`0xC640…FaaC` escrow<br>`0xF9A4…14b7` escrow<br>`0x7E4a…BCfe` escrow<br>`0xc3c8…De6c` LP | `contracts/ramp/LPRegistry.sol:424` |
| `reserveExposure(address,uint256)` | only an escrow the registry accepts | - | Take on `brlCents` of exposure for `lp`, or return false if it would exceed the LP's remaining credit. Only a registered escrow may call. <sub>(NatSpec)</sub> | `0x09f0…f994` escrow<br>`0xC640…FaaC` escrow<br>`0xF9A4…14b7` escrow<br>`0x7E4a…BCfe` escrow | `contracts/ramp/LPRegistry.sol:406` |
| `revokeAffiliate(address)` | a party to that offer, order, sale, note or reward | - | End an affiliation. The sponsor can always do this, whatever its own tier. <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/LPRegistry.sol:324` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:136` |
| `setEscrow(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Registering an escrow waits out the governance delay; removing one is instant. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/LPRegistry.sol:189` |
| `setPhase(uint8)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Open the next network phase (delayed), or close back to an earlier one (instant). <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/LPRegistry.sol:197` |
| `setRewardsHook(address)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Point settlement reports at a rewards contract (delayed), or stop them (zero, instant). <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/LPRegistry.sol:210` |
| `setTier(address,uint8,uint256)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Admit, re-tier or remove an LP. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/LPRegistry.sol:228` |
| `sponsorAffiliate(address,uint256)` | an INSTITUTIONAL LP, from Phase B | - | Sponsor an affiliated LP, or change its credit. Phase B onwards; caller must be an active INSTITUTIONAL LP. <sub>(NatSpec)</sub> | open | `contracts/ramp/LPRegistry.sol:290` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:125` |

</details>

#### AttestorQuorumVerifier (cards)

`0x3883306655E0D64A6766e609B0ED655f4452B0a7` - `AttestorQuorumVerifier`, `contracts/ramp/AttestorQuorumVerifier.sol`. Card-payment verifier: a threshold of licensed-PSP attestors signs each capture.

- governor `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214`; setup complete; delay 48 h; 0 pending change(s)
- attestor: `0xb93061a48E8Fc98417020963c82Ce15DA50079AB`, `0x3365BA2091fA21cD0A672780d222A50D92D2b096`, `0xA6BBbb40C7199f5D5B31205411dcA3F2A3e55091`
- threshold = `2` (attestor signatures needed)
- attestorCount = `3` (attestors)
- EIP-1967 slots: empty (not a proxy)

- **governor** can add and remove attestors, and change the threshold (adding and lowering wait; removing and raising are instant). It cannot attest a payment itself, unless it adds itself through the delay. (`contracts/ramp/AttestorQuorumVerifier.sol:181`, `contracts/ramp/AttestorQuorumVerifier.sol:192`, `contracts/common/DelayedGovernance.sol:125`)
- **attestor** can sign card-capture attestations: `threshold` of them prove a CARD payment to an escrow that allows this verifier. It cannot prove any other rail (provesBankSession is false), or settle on an escrow that has not allowed this verifier.

<details><summary>7 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:145` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:119` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:159` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:136` |
| `setAttestor(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Adding an attestor waits out the governance delay; removing one is instant. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/AttestorQuorumVerifier.sol:181` |
| `setThreshold(uint256)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Lowering the threshold waits out the governance delay; raising it is instant. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/AttestorQuorumVerifier.sol:192` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:125` |

</details>

#### ReclaimZkTlsVerifier (PIX, boleto)

`0xBcB02060Ee4f3734F4a206dD319d8D5621d1697E` - `ReclaimZkTlsVerifier`, `contracts/ramp/ReclaimZkTlsVerifier.sol`. PIX and boleto verifier: Reclaim zkTLS claims of the payer's own bank session, signed by a threshold of witnesses.

- governor `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214`; setup complete; delay 48 h; 0 pending change(s)
- witness: `0x39b7fdF462673ef8cccDC1CAeFBf89DDAd7f7AAE`, `0xAbE8305411A49deB2843DCbdc3f0F831914c8817`, `0x791AB620eec7379f58baa8F9537Db6958f509c8b`
- bank endpoint (providerHash): `0x4c64b9b374d341ba16e93be319434f3450db8fd8ea8ee3a201253f364db722b9`, `0xd8d90d629dc91348bf69c3c5148cd5bf1efdc99220a15a6f42d6ad42eeb2bb20`, `0x8259a0510dbf7425215eada80e9a8fcc1bac48d4e24e3cea67b5185b482abf77`, `0xf02c2badc915c0c690ccba5dd00202b6efcc3d49a1c1197db4026f075aaddc1a`
- threshold = `2` (witness signatures needed)
- witnessCount = `3` (witnesses)
- endpointCount = `4` (allowed bank endpoints)
- EIP-1967 slots: empty (not a proxy)

- **governor** can add and remove witnesses, change the threshold, allow and revoke bank endpoints and the rails each may attest (adding, allowing and lowering wait; removing, revoking and raising are instant). It cannot prove a payment itself, unless it adds itself as witnesses through the delay. (`contracts/ramp/ReclaimZkTlsVerifier.sol:579`, `contracts/ramp/ReclaimZkTlsVerifier.sol:590`, `contracts/ramp/ReclaimZkTlsVerifier.sol:602`, `contracts/ramp/ReclaimZkTlsVerifier.sol:610`, `contracts/ramp/ReclaimZkTlsVerifier.sol:627`, `contracts/common/DelayedGovernance.sol:125`)
- **witness** can sign Reclaim claims: `threshold` of them prove that a bank session on an allowed endpoint showed the payment. It cannot vouch for an endpoint the governor has not allowed, or a rail the endpoint may not attest.

<details><summary>10 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `allowEndpoint(bytes32,string)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Allow a bank endpoint: the template's Reclaim `providerHash` and the URL prefix its `url` must start with. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/ReclaimZkTlsVerifier.sol:602` |
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:145` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:119` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:159` |
| `revokeEndpoint(bytes32)` | the governor (key) | instant | Revoking an endpoint is instant. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/ReclaimZkTlsVerifier.sol:610` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:136` |
| `setEndpointRails(bytes32,uint16)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Set which rails an allowlisted endpoint may attest, as a bitmask over Rail. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/ReclaimZkTlsVerifier.sol:627` |
| `setThreshold(uint256)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Lowering the threshold waits out the governance delay; raising it is instant. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/ReclaimZkTlsVerifier.sol:590` |
| `setWitness(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Adding a witness waits out the governance delay; removing one is instant. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/ReclaimZkTlsVerifier.sol:579` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:125` |

</details>

#### FiatEscrow (on-ramp: ETH, USDT)

`0x09f0dAc9d938444b3f86a639504D38521100f994` - `FiatEscrow`, `contracts/ramp/FiatEscrow.sol`. On-ramp escrow: an LP escrows crypto in an offer; a taker locks an order, pays BRL, and the crypto is released on a proof of payment. **Holds funds.**

- governor `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214`; setup complete; delay 48 h; 0 pending change(s)
- arbitrator: `0xD3C96EBe25C52CA6afD0AC2F54482FB8ecb4ac6C`
- allowed verifier: `0x3883306655E0D64A6766e609B0ED655f4452B0a7`, `0xBcB02060Ee4f3734F4a206dD319d8D5621d1697E`
- listed asset (enabled): `0x0000000000000000000000000000000000000000`, `0xc241A572883241946a6780E996808C321b06baB0`
- EIP-1967 slots: empty (not a proxy)

- **governor** can list and delist assets and their band oracles, allow and revoke payment verifiers, add and remove arbitrators, set asset caps. After setup, listing, allowing, adding and raising wait GOVERNANCE_DELAY; delisting, revoking, removing and lowering are instant. It cannot move an offer's liquidity or an order's funds, change an asset's decimals once set, or decide a dispute: a ruling needs an arbitrator's signature. Its power over funds is indirect: which verifiers and arbitrators the escrow believes. (`contracts/ramp/FiatEscrow.sol:458`, `contracts/ramp/FiatEscrow.sol:1015`, `contracts/ramp/FiatEscrow.sol:1023`, `contracts/ramp/FiatEscrow.sol:1035`, `contracts/common/DelayedGovernance.sol:125`, `contracts/common/DelayedGovernance.sol:136`, …)
- **arbitrator** can sign a ruling on a DISPUTED order: RELEASE to the taker's named recipient, or REFUND to the LP's offer. Anyone submits it; it executes only after RULING_DELAY (1 day), re-verified then, and before DISPUTE_TIMEOUT. A RELEASE needs an arbitrator registered no later than the dispute was raised. It cannot reach an order that is not in dispute, an LP's free liquidity, more than the disputed amount, or any payee but the order's two counterparties. (`contracts/ramp/FiatEscrow.sol:879`)

<details><summary>24 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `receive()` | anyone | - | Accept ETH: meant for ragequit proceeds from a pool. ETH sent here any other way is credited to nobody, and no function can take it out. | not probed (plain ETH transfer) | `contracts/ramp/FiatEscrow.sol:1259` |
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:145` |
| `cancelOrder(bytes32)` | a party to that offer, order, sale, note or reward | - | Give up before paying. Returns the liquidity immediately rather than making the LP wait out the window for capital nobody is going to use. <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:753` |
| `closeOffer(bytes32)` | a party to that offer, order, sale, note or reward | - | Withdraw unlocked liquidity and stop quoting. <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:560` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:119` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:159` |
| `expireDispute(bytes32)` | anyone | - | After DISPUTE_TIMEOUT with no ruling, anyone returns the order's liquidity to the LP's offer. <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:960` |
| `fundOffer(bytes32,uint256)` | a party to that offer, order, sale, note or reward | - | Add liquidity to the caller's own offer. | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:542` |
| `issueBoleto(bytes32,bytes32)` | a party to that offer, order, sale, note or reward | - | The LP commits to the boleto it registered for this order. <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:615` |
| `lockOrder(bytes32,uint256,uint8,address,uint256)` | anyone | - | Lock liquidity to pay for by PIX or TED, to the offer's key. <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:576` |
| `lockOrderByBoleto(bytes32,uint256,uint8,address,uint256)` | anyone | - | Lock liquidity to pay for by boleto. The LP must then issue one: see issueBoleto. <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:592` |
| `postOffer(…)` | an LP the registry lets quote | - | Post an offer and escrow its liquidity (the registry must let the LP quote it). | open | `contracts/ramp/FiatEscrow.sol:475` |
| `raiseDispute(bytes32,string)` | a party to that offer, order, sale, note or reward | - | Freeze an order pending arbitration. The cases this exists for are the ones no proof can settle: the taker paid but the attestor cannot produce a proof (bank downtime, an unsupported statement form... <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:810` |
| `reclaimExpired(bytes32)` | anyone | - | After the window, anyone may return unpaid liquidity to the LP. <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:789` |
| `releaseWithProof(bytes32,bytes)` | anyone carrying a proof the contract's verifier accepts | - | Present proof the BRL was paid, and take delivery. <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:698` |
| `rescueShielded(…)` | a party to that offer, order, sale, note or reward | - | The order's recipient ragequits a shielded delivery back out of the pool, to itself. | open | `contracts/ramp/FiatEscrow.sol:985` |
| `resolveDispute(…)` | anyone carrying a registered arbitrator's signed ruling (key) | - | Submit an arbitrator's signed ruling. Anyone may submit it: the first submission posts it, and the same ruling submitted again after RULING_DELAY executes it. <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:879` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:136` |
| `setArbitrator(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Adding an arbitrator waits out the governance delay; removing one is instant. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/FiatEscrow.sol:1023` |
| `setAsset(address,address,uint8,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | List or delist a settlement asset. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/FiatEscrow.sol:458` |
| `setAssetCap(address,uint256)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Lowering or setting a first cap is instant; raising or removing one is delayed. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/FiatEscrow.sol:1035` |
| `setVerifier(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Allowing a verifier waits out the governance delay; revoking one is instant. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/FiatEscrow.sol:1015` |
| `takeDeliveryDirect(bytes32)` | a party to that offer, order, sale, note or reward | - | Take a shielded order's delivery in the open instead, to the rescue address. A shielded delivery can become impossible after the taker has paid: the Entrypoint or the pool can be frozen by the toke... <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:776` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:125` |

</details>

#### OffRampEscrow (off-ramp: ETH, USDT)

`0xC640d520768790A817FdC50A1af17Af810d8FaaC` - `OffRampEscrow`, `contracts/ramp/OffRampEscrow.sol`. Off-ramp escrow: a seller escrows crypto in a sale; an LP claims it, pays the seller BRL, and is paid the crypto on a proof. **Holds funds.**

- governor `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214`; setup complete; delay 48 h; 0 pending change(s)
- arbitrator: `0xD3C96EBe25C52CA6afD0AC2F54482FB8ecb4ac6C`
- allowed verifier: `0x3883306655E0D64A6766e609B0ED655f4452B0a7`, `0xBcB02060Ee4f3734F4a206dD319d8D5621d1697E`
- listed asset (enabled): `0x0000000000000000000000000000000000000000`, `0xc241A572883241946a6780E996808C321b06baB0`
- EIP-1967 slots: empty (not a proxy)

- **governor** can list and delist assets and their band oracles, allow and revoke payment verifiers, add and remove arbitrators, set asset caps. After setup, listing, allowing, adding and raising wait GOVERNANCE_DELAY; delisting, revoking, removing and lowering are instant. It cannot move a sale's escrowed crypto, change an asset's decimals once set, or decide a dispute: a ruling needs an arbitrator's signature. Its power over funds is indirect: which verifiers and arbitrators the escrow believes. (`contracts/ramp/OffRampEscrow.sol:260`, `contracts/ramp/OffRampEscrow.sol:587`, `contracts/ramp/OffRampEscrow.sol:595`, `contracts/ramp/OffRampEscrow.sol:611`, `contracts/common/DelayedGovernance.sol:125`, `contracts/common/DelayedGovernance.sol:136`, …)
- **arbitrator** can sign a ruling on a DISPUTED sale: pay the claiming LP, or return the crypto to the seller. Anyone submits it; it executes only after RULING_DELAY (1 day), re-verified then. Paying the LP needs an arbitrator registered no later than the dispute was raised. It cannot reach a sale that is not in dispute, or pay anyone but the sale's two counterparties. (`contracts/ramp/OffRampEscrow.sol:496`)

<details><summary>18 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `abandonClaim(bytes32)` | a party to that offer, order, sale, note or reward | - | Give the claim back early, without penalty. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:396` |
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:145` |
| `cancelSale(bytes32)` | a party to that offer, order, sale, note or reward | - | Withdraw an unclaimed sale. Never available while an LP holds a live claim, or the seller could take the ETH back after the BRL had already been sent. <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/OffRampEscrow.sol:340` |
| `claimSale(bytes32)` | an LP the registry lets quote | - | Take exclusivity on a sale in order to pay it. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:359` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:119` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:159` |
| `expireDispute(bytes32)` | anyone | - | After DISPUTE_TIMEOUT with no ruling, anyone returns the escrowed crypto to the seller's refund address and frees the LP's credit. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:570` |
| `openSale(…)` | anyone | - | Escrow ETH and ask for BRL. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:286` |
| `raiseDispute(bytes32,string)` | a party to that offer, order, sale, note or reward | - | The seller or the claiming LP freezes a sale for arbitration. | every probe refused on its zero arguments | `contracts/ramp/OffRampEscrow.sol:452` |
| `releaseStaleClaim(bytes32)` | anyone | - | Clear a claim nobody honoured. Callable by anyone: leaving this to the seller would mean a seller without gas stays frozen. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:382` |
| `resolveDispute(…)` | anyone carrying a registered arbitrator's signed ruling (key) | - | Submit an arbitrator's signed ruling. Anyone may submit it: the first submission posts it, and the same ruling submitted again after RULING_DELAY executes it. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:496` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:136` |
| `setArbitrator(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Adding an arbitrator waits out the governance delay; removing one is instant. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/OffRampEscrow.sol:595` |
| `setAsset(address,address,uint8,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | List or delist a settlement asset. Decimals are fixed once first set. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/OffRampEscrow.sol:260` |
| `setAssetCap(address,uint256)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Lowering or setting a first cap is instant; raising or removing one is delayed. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/OffRampEscrow.sol:611` |
| `setVerifier(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Allowing a verifier waits out the governance delay; revoking one is instant. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/OffRampEscrow.sol:587` |
| `settleWithProof(bytes32,bytes)` | anyone carrying a proof the contract's verifier accepts | - | Prove the seller was paid, and collect the escrowed ETH. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:413` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:125` |

</details>

#### FiatEscrow (Movva on-ramp)

`0xF9A41BFc51E3FBc0593a8112f9834B8D011914b7` - `FiatEscrow`, `contracts/ramp/FiatEscrow.sol`. On-ramp escrow: an LP escrows crypto in an offer; a taker locks an order, pays BRL, and the crypto is released on a proof of payment. **Holds funds.**

- governor `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214`; setup complete; delay 48 h; 0 pending change(s)
- arbitrator: `0xD3C96EBe25C52CA6afD0AC2F54482FB8ecb4ac6C`
- allowed verifier: `0x3883306655E0D64A6766e609B0ED655f4452B0a7`, `0xBcB02060Ee4f3734F4a206dD319d8D5621d1697E`
- listed asset (enabled): `0xCe80e2e723b6cEDa9fF5E770bfCa9651F7220428`
- EIP-1967 slots: empty (not a proxy)

- **governor** can list and delist assets and their band oracles, allow and revoke payment verifiers, add and remove arbitrators, set asset caps. After setup, listing, allowing, adding and raising wait GOVERNANCE_DELAY; delisting, revoking, removing and lowering are instant. It cannot move an offer's liquidity or an order's funds, change an asset's decimals once set, or decide a dispute: a ruling needs an arbitrator's signature. Its power over funds is indirect: which verifiers and arbitrators the escrow believes. (`contracts/ramp/FiatEscrow.sol:458`, `contracts/ramp/FiatEscrow.sol:1015`, `contracts/ramp/FiatEscrow.sol:1023`, `contracts/ramp/FiatEscrow.sol:1035`, `contracts/common/DelayedGovernance.sol:125`, `contracts/common/DelayedGovernance.sol:136`, …)
- **arbitrator** can sign a ruling on a DISPUTED order: RELEASE to the taker's named recipient, or REFUND to the LP's offer. Anyone submits it; it executes only after RULING_DELAY (1 day), re-verified then, and before DISPUTE_TIMEOUT. A RELEASE needs an arbitrator registered no later than the dispute was raised. It cannot reach an order that is not in dispute, an LP's free liquidity, more than the disputed amount, or any payee but the order's two counterparties. (`contracts/ramp/FiatEscrow.sol:879`)

<details><summary>24 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `receive()` | anyone | - | Accept ETH: meant for ragequit proceeds from a pool. ETH sent here any other way is credited to nobody, and no function can take it out. | not probed (plain ETH transfer) | `contracts/ramp/FiatEscrow.sol:1259` |
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:145` |
| `cancelOrder(bytes32)` | a party to that offer, order, sale, note or reward | - | Give up before paying. Returns the liquidity immediately rather than making the LP wait out the window for capital nobody is going to use. <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:753` |
| `closeOffer(bytes32)` | a party to that offer, order, sale, note or reward | - | Withdraw unlocked liquidity and stop quoting. <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:560` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:119` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:159` |
| `expireDispute(bytes32)` | anyone | - | After DISPUTE_TIMEOUT with no ruling, anyone returns the order's liquidity to the LP's offer. <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:960` |
| `fundOffer(bytes32,uint256)` | a party to that offer, order, sale, note or reward | - | Add liquidity to the caller's own offer. | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:542` |
| `issueBoleto(bytes32,bytes32)` | a party to that offer, order, sale, note or reward | - | The LP commits to the boleto it registered for this order. <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:615` |
| `lockOrder(bytes32,uint256,uint8,address,uint256)` | anyone | - | Lock liquidity to pay for by PIX or TED, to the offer's key. <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:576` |
| `lockOrderByBoleto(bytes32,uint256,uint8,address,uint256)` | anyone | - | Lock liquidity to pay for by boleto. The LP must then issue one: see issueBoleto. <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:592` |
| `postOffer(…)` | an LP the registry lets quote | - | Post an offer and escrow its liquidity (the registry must let the LP quote it). | open | `contracts/ramp/FiatEscrow.sol:475` |
| `raiseDispute(bytes32,string)` | a party to that offer, order, sale, note or reward | - | Freeze an order pending arbitration. The cases this exists for are the ones no proof can settle: the taker paid but the attestor cannot produce a proof (bank downtime, an unsupported statement form... <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:810` |
| `reclaimExpired(bytes32)` | anyone | - | After the window, anyone may return unpaid liquidity to the LP. <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:789` |
| `releaseWithProof(bytes32,bytes)` | anyone carrying a proof the contract's verifier accepts | - | Present proof the BRL was paid, and take delivery. <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:698` |
| `rescueShielded(…)` | a party to that offer, order, sale, note or reward | - | The order's recipient ragequits a shielded delivery back out of the pool, to itself. | open | `contracts/ramp/FiatEscrow.sol:985` |
| `resolveDispute(…)` | anyone carrying a registered arbitrator's signed ruling (key) | - | Submit an arbitrator's signed ruling. Anyone may submit it: the first submission posts it, and the same ruling submitted again after RULING_DELAY executes it. <sub>(NatSpec)</sub> | open | `contracts/ramp/FiatEscrow.sol:879` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:136` |
| `setArbitrator(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Adding an arbitrator waits out the governance delay; removing one is instant. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/FiatEscrow.sol:1023` |
| `setAsset(address,address,uint8,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | List or delist a settlement asset. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/FiatEscrow.sol:458` |
| `setAssetCap(address,uint256)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Lowering or setting a first cap is instant; raising or removing one is delayed. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/FiatEscrow.sol:1035` |
| `setVerifier(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Allowing a verifier waits out the governance delay; revoking one is instant. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/FiatEscrow.sol:1015` |
| `takeDeliveryDirect(bytes32)` | a party to that offer, order, sale, note or reward | - | Take a shielded order's delivery in the open instead, to the rescue address. A shielded delivery can become impossible after the taker has paid: the Entrypoint or the pool can be frozen by the toke... <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/FiatEscrow.sol:776` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:125` |

</details>

#### OffRampEscrow (Movva off-ramp)

`0x7E4aa58924e379279a6A6458A9a319209c48BCfe` - `OffRampEscrow`, `contracts/ramp/OffRampEscrow.sol`. Off-ramp escrow: a seller escrows crypto in a sale; an LP claims it, pays the seller BRL, and is paid the crypto on a proof. **Holds funds.**

- governor `0x4C0AA1208f8e3e1664EdACc9E0275C18363ed214`; setup complete; delay 48 h; 0 pending change(s)
- arbitrator: `0xD3C96EBe25C52CA6afD0AC2F54482FB8ecb4ac6C`
- allowed verifier: `0x3883306655E0D64A6766e609B0ED655f4452B0a7`, `0xBcB02060Ee4f3734F4a206dD319d8D5621d1697E`
- listed asset (enabled): `0xCe80e2e723b6cEDa9fF5E770bfCa9651F7220428`
- EIP-1967 slots: empty (not a proxy)

- **governor** can list and delist assets and their band oracles, allow and revoke payment verifiers, add and remove arbitrators, set asset caps. After setup, listing, allowing, adding and raising wait GOVERNANCE_DELAY; delisting, revoking, removing and lowering are instant. It cannot move a sale's escrowed crypto, change an asset's decimals once set, or decide a dispute: a ruling needs an arbitrator's signature. Its power over funds is indirect: which verifiers and arbitrators the escrow believes. (`contracts/ramp/OffRampEscrow.sol:260`, `contracts/ramp/OffRampEscrow.sol:587`, `contracts/ramp/OffRampEscrow.sol:595`, `contracts/ramp/OffRampEscrow.sol:611`, `contracts/common/DelayedGovernance.sol:125`, `contracts/common/DelayedGovernance.sol:136`, …)
- **arbitrator** can sign a ruling on a DISPUTED sale: pay the claiming LP, or return the crypto to the seller. Anyone submits it; it executes only after RULING_DELAY (1 day), re-verified then. Paying the LP needs an arbitrator registered no later than the dispute was raised. It cannot reach a sale that is not in dispute, or pay anyone but the sale's two counterparties. (`contracts/ramp/OffRampEscrow.sol:496`)

<details><summary>18 state-changing functions</summary>

| Function | Who may call | Speed | What it does (the contract's NatSpec where it has one) | Admitted on chain | Line |
|---|---|---|---|---|---|
| `abandonClaim(bytes32)` | a party to that offer, order, sale, note or reward | - | Give the claim back early, without penalty. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:396` |
| `cancel(bytes)` | the governor (key) | instant | Drop a queued change. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:145` |
| `cancelSale(bytes32)` | a party to that offer, order, sale, note or reward | - | Withdraw an unclaimed sale. Never available while an LP holds a live claim, or the seller could take the ETH back after the BRL had already been sent. <sub>(NatSpec)</sub> | every probe refused on its zero arguments | `contracts/ramp/OffRampEscrow.sol:340` |
| `claimSale(bytes32)` | an LP the registry lets quote | - | Take exclusivity on a sale in order to pay it. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:359` |
| `completeSetup()` | the governor (key) | instant | End setup. From here on, every risk-increasing change waits out the delay. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:119` |
| `execute(bytes)` | the governor (key) | only once a scheduled change has waited GOVERNANCE_DELAY | Run a scheduled change once its delay has passed. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:159` |
| `expireDispute(bytes32)` | anyone | - | After DISPUTE_TIMEOUT with no ruling, anyone returns the escrowed crypto to the seller's refund address and frees the LP's credit. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:570` |
| `openSale(…)` | anyone | - | Escrow ETH and ask for BRL. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:286` |
| `raiseDispute(bytes32,string)` | a party to that offer, order, sale, note or reward | - | The seller or the claiming LP freezes a sale for arbitration. | every probe refused on its zero arguments | `contracts/ramp/OffRampEscrow.sol:452` |
| `releaseStaleClaim(bytes32)` | anyone | - | Clear a claim nobody honoured. Callable by anyone: leaving this to the seller would mean a seller without gas stays frozen. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:382` |
| `resolveDispute(…)` | anyone carrying a registered arbitrator's signed ruling (key) | - | Submit an arbitrator's signed ruling. Anyone may submit it: the first submission posts it, and the same ruling submitted again after RULING_DELAY executes it. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:496` |
| `schedule(bytes)` | the governor (key) | instant | Queue one of this contract's delayable setters with its exact calldata; executable after GOVERNANCE_DELAY, for 14 days. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:136` |
| `setArbitrator(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Adding an arbitrator waits out the governance delay; removing one is instant. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/OffRampEscrow.sol:595` |
| `setAsset(address,address,uint8,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | List or delist a settlement asset. Decimals are fixed once first set. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/OffRampEscrow.sol:260` |
| `setAssetCap(address,uint256)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Lowering or setting a first cap is instant; raising or removing one is delayed. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/OffRampEscrow.sol:611` |
| `setVerifier(address,bool)` | the governor (key) | waits GOVERNANCE_DELAY when it adds risk; instant when it removes risk | Allowing a verifier waits out the governance delay; revoking one is instant. <sub>(NatSpec)</sub> | `0x4C0A…d214` governor, deployer | `contracts/ramp/OffRampEscrow.sol:587` |
| `settleWithProof(bytes32,bytes)` | anyone carrying a proof the contract's verifier accepts | - | Prove the seller was paid, and collect the escrowed ETH. <sub>(NatSpec)</sub> | open | `contracts/ramp/OffRampEscrow.sol:413` |
| `transferGovernor(address)` | the governor (key) | instant | Hand every governor power to another address at once. One step: no acceptance, no delay; only address(0) is refused. | `0x4C0A…d214` governor, deployer | `contracts/common/DelayedGovernance.sol:125` |

</details>

## Etherscan verification

`deployments/sepolia-movva-rail.rehearsal/etherscan-verify.sh` holds the exact `forge verify-contract` command for each address, with its constructor arguments and linked libraries. **They were not run.** Each was dry-run instead: forge wrote the standard-JSON input it would submit (`--show-standard-json-input`), solc 0.8.28+commit.7893614a compiled it, and the result was compared with the code at the address and with the creation transaction's init code: 28 of 28 match.

Library paths are spelled through the remapping (`poseidon-solidity/PoseidonT3.sol`). Forge 0.3.0 writes any other spelling into the input as a path solc does not match. The pools then compile with unlinked placeholders, and Etherscan would not match them. The dry run fails any input whose libraries are left unlinked.

## What was NOT verified

- That this runs on Sepolia. This is an anvil fork with an impersonated deployer: the chain, the gas and the addresses are a rehearsal of the real run.
- Etherscan itself. The verify commands were generated and dry-run offline, not submitted. The dry run repeats Etherscan's compile with the same solc, but not Etherscan's service.
- That the code is correct. This report proves which code is deployed and who can call it. Whether that code is safe is the audit's question (`docs/audit-scope.md`).
- Behaviour. No deposit, order, dispute, mint or withdrawal was executed here: the verification pass is read-only. Those flows are exercised by the Foundry and vitest suites.
- Immutable values byte by byte. They are masked in the bytecode comparison and checked through their getters by the wiring checks (Entrypoint, pools, oracles, tokens, delays, timeouts).
- The exact source text of the Privacy Pools contracts. The protocol build omits CBOR metadata (`bytecode_hash = "none"`), so for those contracts the match proves the bytecode. Their source files are hashed against the build's metadata separately.
- The Poseidon libraries' creation. They were already on the chain at deterministic addresses; their code is matched, their creation is not.
- Key custody. The inventory shows which addresses hold the remaining roles. It cannot show who holds those keys or how they are kept.
- Contracts outside the deployment: Pyth, the Chainlink feeds and their owners, CreateX and (on mainnet) USDT.
- Off-chain services: the relayer, the ASP that computes roots, the Pyth keeper and the monitor.
- The identities (witnesses, attestors, arbitrator, LP, guardian, treasurer) are test keys from the public seed `public-sepolia-rehearsal`: anyone can derive them. The real run refuses that seed.
- Live prices. Pyth's FX.USD/BRL is stale on this chain, so the 10 checks that read it can only confirm each reader refuses it with exactly `StaleRate` (see Prices). A fresh-price read was not possible here.
