#!/usr/bin/env bash
# Etherscan source verification for the new Movva escrow pair on Sepolia (deployments/sepolia-movva-only-escrows-v2.json).
# Built from commit 8e55613d8714bdb50df66c6d2f68922903bf60f4; contracts/ramp is unchanged since then.
# Pinned forge only speaks Etherscan V1; submit with: FORGE=$(bash scripts/foundry.sh path) python3 scripts/etherscan-verify-v2.py <this file> deployments/sepolia-movva-only-escrows-v2/etherscan-verified.json
# Constructor arguments are the tails of the two creation transactions (0xfe45c92b..., 0x65bfc46f...).
#   ETHERSCAN_API_KEY=... bash deployments/sepolia-movva-only-escrows-v2/etherscan-verify.sh
set -euo pipefail
cd "$(dirname "$0")/$(git -C "$(dirname "$0")" rev-parse --show-cdup)"
: "${ETHERSCAN_API_KEY:?set ETHERSCAN_API_KEY}"
FORGE="${FORGE:-$(bash scripts/foundry.sh path)}"
test -z "$(git diff 8e55613d8714bdb50df66c6d2f68922903bf60f4 -- contracts/ramp contracts/movva foundry.toml)" || { echo "contracts differ from 8e55613; check it out first" >&2; exit 1; }

# ramp.movvaOnramp: FiatEscrow (Movva on-ramp, v2) (FiatEscrow)
"$FORGE" verify-contract 0x74b26272E0899B246678e0502304Ab102fB87Cf1 contracts/ramp/FiatEscrow.sol:FiatEscrow --chain sepolia --compiler-version v0.8.28+commit.7893614a --num-of-optimizations 1000 --evm-version cancun --constructor-args 0x000000000000000000000000975e0f416f04012e64ed680cfba9586acb4acbec000000000000000000000000f2cfbb21df5af92807679cc9451098dc9d2b901d000000000000000000000000a185426022108e054d8f2f3f6fb3c96a464522880000000000000000000000003072ca3aae4911d55245e46ce3aa45eeb2d0dacb000000000000000000000000000000000000000000000000000000000000012c0000000000000000000000003c43f785ca057df159f2e15e7cc44ab2986c2779000000000000000000000000000000000000000000000000000000000002a3000000000000000000000000000000000000000000000000000000000000278d00 --etherscan-api-key "$ETHERSCAN_API_KEY" --watch

# ramp.movvaOfframp: OffRampEscrow (Movva off-ramp, v2) (OffRampEscrow)
"$FORGE" verify-contract 0x9bf5b2373cEe41B595a1E29Fd049920F8487f6D1 contracts/ramp/OffRampEscrow.sol:OffRampEscrow --chain sepolia --compiler-version v0.8.28+commit.7893614a --num-of-optimizations 1000 --evm-version cancun --constructor-args 0x000000000000000000000000975e0f416f04012e64ed680cfba9586acb4acbec000000000000000000000000f2cfbb21df5af92807679cc9451098dc9d2b901d000000000000000000000000000000000000000000000000000000000000012c0000000000000000000000003c43f785ca057df159f2e15e7cc44ab2986c2779000000000000000000000000000000000000000000000000000000000002a3000000000000000000000000000000000000000000000000000000000000278d00 --etherscan-api-key "$ETHERSCAN_API_KEY" --watch
