/**
 * Recovery alerts in Chromium, against scripts/dev-stack.ts, whose co-signer sends them:
 *
 *   onboarding -> Início offers the alerts once -> "Ativar alertas": this device subscribed with a passkey assertion
 *   -> a recovery queued on the account's Delay with the passkey (a stolen passkey's move) -> the co-signer pushes an
 *   encrypted alert to the subscription, which decrypts with its keys -> handed to the app's service worker, it shows the
 *   notification in Portuguese; clicked, it closes -> turning alerts off is refused while the recovery is queued, and the
 *   switch stays on -> after the veto it turns off, and the device gets the last notice.
 *
 * WHAT IS MOCKED, exactly:
 *  - PushManager, in the page. Headless Chromium has no push service: `pushManager.subscribe` is refused ("Registration
 *    failed - permission denied") even with notifications granted. An init script replaces `PushManager.prototype`'s
 *    `subscribe`, `getSubscription` and `permissionState` with a subscription whose endpoint is this stack's push sink
 *    (http://127.0.0.1:8981/api/dev/push/<id>) and whose `p256dh` and `auth` are a real P-256 key pair and a random
 *    secret made in the page with WebCrypto. The test keeps the private key, and decrypts what the co-signer sent
 *    (RFC 8291) as a browser would.
 *  - The push service handing the message to the worker: CDP `ServiceWorker.deliverPushMessage` gives the decrypted
 *    payload to the app's own service worker (dist/sw.js), as Chrome does with a message its push service delivers.
 *  - The click: a `NotificationEvent` dispatched in the worker, on the notification Chromium showed.
 *
 * Not mocked: the co-signer (subscribing and unsubscribing proven by the virtual authenticator's passkey assertions, the
 * refusal while a recovery is queued, its watcher, aes128gcm and VAPID), the service worker and its handlers, the
 * notification itself (Chromium's own, read back with getNotifications: full Chromium, `channel: 'chromium'`, since the
 * headless shell denies notifications), the recovery queued on the Delay, and the veto.
 */
import { createDecipheriv, createECDH, hkdfSync } from 'node:crypto';
import { expect, test, type Page } from '@playwright/test';
import { openApp, accountShown, balanceShown, buyByPix, nav, openContext, saveFailureContext, type Opened } from './helpers.js';

test.use({ channel: 'chromium' });
test.describe.configure({ mode: 'serial' });

const APP_ORIGIN = 'http://localhost:8981';
const SUBSCRIPTION = 'mova-e2e:push-subscription';
const PUSH_SINK = 'http://127.0.0.1:8981/api/dev/push/';

interface MockedSubscription { endpoint: string; p256dh: string; auth: string; d: string; applicationServerKey: string }
interface PushMessage { id: string; at: number; headers: Record<string, string>; body: string }
interface AlertPayload { v: number; type: string; title: string; body: string; kind?: string; executableAt?: number; tag: string }

/** In every page of the context: PushManager replaced by a subscription to this stack's push sink (see the header). */
function pushManagerMock(args: { key: string; sink: string }): void {
  const b64u = (b: Uint8Array) => btoa(String.fromCharCode(...b)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  const bytes = (s: string) => Uint8Array.from(atob(s.replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((s.length + 3) % 4)), (c) => c.charCodeAt(0));
  type Stored = { endpoint: string; p256dh: string; auth: string; d: string; applicationServerKey: string };
  const load = (): Stored | undefined => {
    const raw = localStorage.getItem(args.key);
    return raw ? JSON.parse(raw) as Stored : undefined;
  };
  const wrap = (s: Stored) => ({
    endpoint: s.endpoint, expirationTime: null,
    options: { userVisibleOnly: true, applicationServerKey: bytes(s.applicationServerKey).buffer },
    getKey: (name: string) => bytes(name === 'auth' ? s.auth : s.p256dh).buffer,
    toJSON: () => ({ endpoint: s.endpoint, expirationTime: null, keys: { p256dh: s.p256dh, auth: s.auth } }),
    unsubscribe: async () => { localStorage.removeItem(args.key); return true; },
  }) as unknown as PushSubscription;
  PushManager.prototype.getSubscription = async function getSubscription() {
    const s = load();
    return s ? wrap(s) : null;
  };
  PushManager.prototype.permissionState = async function permissionState() { return 'granted' as PermissionState; };
  PushManager.prototype.subscribe = async function subscribe(options?: PushSubscriptionOptionsInit) {
    const pair = await crypto.subtle.generateKey({ name: 'ECDH', namedCurve: 'P-256' }, true, ['deriveBits']);
    const raw = new Uint8Array(await crypto.subtle.exportKey('raw', pair.publicKey));
    const jwk = await crypto.subtle.exportKey('jwk', pair.privateKey);
    const key = options?.applicationServerKey;
    const serverKey = typeof key === 'string' ? bytes(key)
      : key instanceof ArrayBuffer ? new Uint8Array(key)
        : new Uint8Array((key as ArrayBufferView).buffer, (key as ArrayBufferView).byteOffset, (key as ArrayBufferView).byteLength);
    const stored: Stored = {
      endpoint: `${args.sink}${crypto.randomUUID()}`, p256dh: b64u(raw), auth: b64u(crypto.getRandomValues(new Uint8Array(16))), d: jwk.d!,
      applicationServerKey: b64u(serverKey),
    };
    localStorage.setItem(args.key, JSON.stringify(stored));
    return wrap(stored);
  };
}

/** RFC 8291 (aes128gcm), the user agent's side: what a browser does with what its push service received. */
function decryptWebPush(body: Buffer, privateKey: string, auth: string): string {
  const salt = body.subarray(0, 16);
  const idlen = body.readUInt8(20);
  const asPublic = body.subarray(21, 21 + idlen);
  const record = body.subarray(21 + idlen);
  const ecdh = createECDH('prime256v1');
  ecdh.setPrivateKey(Buffer.from(privateKey, 'base64url'));
  const uaPublic = ecdh.getPublicKey();
  const hkdf = (salt_: Buffer, ikm: Buffer, info: Buffer, length: number) => Buffer.from(hkdfSync('sha256', ikm, salt_, info, length));
  const ikm = hkdf(Buffer.from(auth, 'base64url'), ecdh.computeSecret(asPublic), Buffer.concat([Buffer.from('WebPush: info\0'), uaPublic, asPublic]), 32);
  const cek = hkdf(salt, ikm, Buffer.from('Content-Encoding: aes128gcm\0'), 16);
  const nonce = hkdf(salt, ikm, Buffer.from('Content-Encoding: nonce\0'), 12);
  const decipher = createDecipheriv('aes-128-gcm', cek, nonce);
  decipher.setAuthTag(record.subarray(record.length - 16));
  const padded = Buffer.concat([decipher.update(record.subarray(0, record.length - 16)), decipher.final()]);
  let end = padded.length - 1;
  while (end >= 0 && padded[end] === 0) end--;
  return padded.subarray(0, end).toString('utf8');
}

const subscriptionOf = async (page: Page) => page.evaluate((key) => JSON.parse(localStorage.getItem(key) ?? 'null') as MockedSubscription | null, SUBSCRIPTION);

async function messagesFor(page: Page, endpoint: string): Promise<PushMessage[]> {
  const { messages } = await (await page.request.get('/api/dev/push')).json() as { messages: PushMessage[] };
  return messages.filter((m) => m.id === endpoint.slice(PUSH_SINK.length));
}

const notificationsShown = (page: Page) => page.evaluate(async () => (await (await navigator.serviceWorker.ready).getNotifications())
  .map((n) => ({ title: n.title, body: n.body, tag: n.tag, data: n.data as { type?: string; url?: string } })));

/** What a stolen passkey would do: queue a transaction on the account's recovery Delay (as movva.spec.ts does). */
async function queueRecovery(page: Page, account: string): Promise<void> {
  const request = await (await page.request.post('/api/dev/recovery/request', { data: { account } })).json() as { hash: string };
  const identity = await page.evaluate(() => JSON.parse(localStorage.getItem('mova:identity:v1')!) as { credentialId: string; passkey: { x: string; y: string } });
  const assertion = await page.evaluate(async ({ hash, credentialId }) => {
    const id = Uint8Array.from(atob(credentialId.replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((credentialId.length + 3) % 4)), (c) => c.charCodeAt(0));
    const challenge = Uint8Array.from(hash.slice(2).match(/../g)!, (x) => parseInt(x, 16));
    const hex = (b: ArrayBuffer) => `0x${Array.from(new Uint8Array(b), (x) => x.toString(16).padStart(2, '0')).join('')}`;
    const credential = await navigator.credentials.get({ publicKey: { challenge, allowCredentials: [{ type: 'public-key', id }], userVerification: 'required' } }) as PublicKeyCredential;
    const r = credential.response as AuthenticatorAssertionResponse;
    return { authenticatorData: hex(r.authenticatorData), clientDataJSON: hex(r.clientDataJSON), signature: hex(r.signature) };
  }, { hash: request.hash, credentialId: identity.credentialId });
  const queued = await (await page.request.post('/api/dev/recovery/queue', { data: { account, owner: identity.passkey, assertion } })).json() as { queued: boolean };
  expect(queued.queued).toBe(true);
}

test.describe('Movva in a browser: recovery alerts from the co-signer, with the app closed', () => {
  let opened: Opened;
  let account: string;
  let alert: AlertPayload;

  test.beforeAll(async ({ browser }, testInfo) => {
    opened = await openContext(browser, testInfo);
    await opened.context.grantPermissions(['notifications'], { origin: APP_ORIGIN });
    await opened.context.addInitScript(pushManagerMock, { key: SUBSCRIPTION, sink: PUSH_SINK });
  });

  test.afterEach(async ({}, testInfo) => {
    await saveFailureContext(testInfo, [['alerts', opened]]);
  });

  test.afterAll(async () => {
    await opened?.context.close();
  });

  test('after onboarding Início offers the alerts once; "Ativar alertas" subscribes this device, proven with the passkey', async () => {
    const { page } = opened;
    await openApp(page);
    await page.getByRole('button', { name: 'Criar carteira com passkey' }).click();
    await expect(await balanceShown(page)).toHaveText('R$ 0,00');

    const offer = page.getByTestId('recovery-alerts-offer');
    await expect(offer).toContainText('Ativar alertas de recuperação?', { timeout: 60_000 });
    await expect(offer).toContainText('você tem 7 dias para vetar');
    const answered = page.waitForResponse((r) => r.url().endsWith('/v1/alerts/subscribe') && r.request().method() === 'POST');
    await offer.getByRole('button', { name: 'Ativar alertas' }).click();
    const response = await answered;
    expect(response.status()).toBe(200);
    expect(await response.json()).toMatchObject({ subscribed: true, created: true, pending: 0 });
    const sent = response.request().postDataJSON() as { account: string; subscription: { endpoint: string; keys: { p256dh: string; auth: string } }; passkeySignature: string };
    const mocked = (await subscriptionOf(page))!;
    expect(sent.subscription).toEqual({ endpoint: mocked.endpoint, keys: { p256dh: mocked.p256dh, auth: mocked.auth } });
    expect(sent.subscription.endpoint.startsWith(PUSH_SINK)).toBe(true);
    expect(sent.passkeySignature).toMatch(/^0x[0-9a-f]{200,}$/);
    await expect(offer).toContainText('Alertas de recuperação ativados');

    account = (await accountShown(page)).address;
    expect(sent.account.toLowerCase()).toBe(account.toLowerCase());
    await nav(page, 'Ajustes');
    const card = page.getByTestId('recovery-alerts');
    await expect(card).toContainText('você tem 7 dias para vetar');
    await expect(card.getByRole('switch', { name: 'Alertas de recuperação' })).toBeChecked();
    await nav(page, 'Início');
    await balanceShown(page);
    await expect(page.getByTestId('recovery-alerts-offer')).toHaveCount(0);
  });

  test('a recovery queued with the passkey reaches this device: the co-signer\'s push decrypts with the subscription\'s keys, and the service worker shows it', async () => {
    const { page, cdp, context } = opened;
    // The account's first operation installs its recovery Delay.
    await buyByPix(page, '20,00');
    await queueRecovery(page, account);

    const mocked = (await subscriptionOf(page))!;
    let messages: PushMessage[] = [];
    await expect(async () => {
      messages = await messagesFor(page, mocked.endpoint);
      expect(messages.length).toBeGreaterThan(0);
    }).toPass({ timeout: 2 * 60_000, intervals: [2_000] });
    expect(messages[0]!.headers['content-encoding']).toBe('aes128gcm');
    expect(messages[0]!.headers.authorization).toMatch(/^vapid /i);
    alert = JSON.parse(decryptWebPush(Buffer.from(messages[0]!.body, 'base64'), mocked.d, mocked.auth)) as AlertPayload;
    expect(alert).toMatchObject({ v: 1, type: 'mova.recovery-requested', title: 'Movva', body: 'Uma recuperação foi solicitada na sua conta Movva', kind: 'queued' });
    const days = (alert.executableAt! - Date.now() / 1000) / 86_400;
    expect(days).toBeGreaterThan(6.5);
    expect(days).toBeLessThan(7.5);

    // Chrome hands the message to the worker: one that is not a recovery alert shows nothing; the alert shows.
    const registrations: string[] = [];
    cdp.on('ServiceWorker.workerRegistrationUpdated', (e) => {
      for (const r of e.registrations) if (r.scopeURL.startsWith(`${APP_ORIGIN}/`) && !r.isDeleted) registrations.push(r.registrationId);
    });
    await cdp.send('ServiceWorker.enable');
    await expect.poll(() => registrations.length).toBeGreaterThan(0);
    const deliver = (data: string) => cdp.send('ServiceWorker.deliverPushMessage', { origin: APP_ORIGIN, registrationId: registrations[0]!, data });
    await deliver(JSON.stringify({ hello: 'world' }));
    await page.waitForTimeout(1_500);
    expect(await notificationsShown(page)).toEqual([]);
    await deliver(JSON.stringify(alert));
    await expect.poll(() => notificationsShown(page), { timeout: 30_000 }).toEqual([expect.objectContaining({
      title: 'Movva', tag: 'mova-recovery',
      body: expect.stringMatching(/^Uma recuperação foi solicitada na sua conta Movva\. Se não foi você, abra o app e vete antes de \d{2}\/\d{2}\/\d{4},? \d{2}:\d{2}\.$/),
      data: expect.objectContaining({ type: 'mova.recovery-requested', url: `${APP_ORIGIN}/#/inicio` }),
    })]);

    // A click on it, dispatched in the worker: the app's handler closes it (and focuses the app's window).
    const worker = context.serviceWorkers().find((w) => w.url().startsWith(`${APP_ORIGIN}/`));
    expect(worker).toBeDefined();
    const left = await worker!.evaluate(async () => {
      const scope = self as unknown as {
        registration: ServiceWorkerRegistration; dispatchEvent(e: Event): boolean;
        NotificationEvent: new (type: string, init: { notification: Notification }) => Event;
      };
      const [shown] = await scope.registration.getNotifications();
      scope.dispatchEvent(new scope.NotificationEvent('notificationclick', { notification: shown! }));
      await new Promise((r) => setTimeout(r, 500));
      return (await scope.registration.getNotifications()).length;
    });
    expect(left).toBe(0);
  });

  test('while the recovery is queued, turning alerts off is refused in Portuguese and the switch stays on; after the veto it turns off, with a last notice', async () => {
    const { page } = opened;
    await nav(page, 'Ajustes');
    const card = page.getByTestId('recovery-alerts');
    const toggle = card.getByRole('switch', { name: 'Alertas de recuperação' });
    await expect(toggle).toBeChecked();
    const refused = page.waitForResponse((r) => r.url().endsWith('/v1/alerts/unsubscribe'));
    await toggle.click();
    const answer = await refused;
    expect(answer.status()).toBe(409);
    expect((await answer.json() as { error: string }).error).toBe('recovery_pending');
    await expect(card.getByRole('alert')).toContainText('Recuperação pendente: alertas mantidos');
    await expect(card.getByRole('alert')).toContainText('Vete a recuperação no Início');
    await expect(toggle).toBeChecked();

    await nav(page, 'Início');
    const queue = page.getByTestId('recovery-queue');
    await expect(queue).toBeVisible({ timeout: 60_000 });
    await queue.getByRole('button', { name: 'Vetar a recuperação' }).click();
    await expect(page.getByTestId('recovery-vetoed')).toBeVisible({ timeout: 3 * 60_000 });

    await nav(page, 'Ajustes');
    // The co-signer counts the recovery as queued until its watcher has seen the veto confirmed: asked again until then.
    await expect(async () => {
      if (!(await toggle.isChecked())) return;
      const r = page.waitForResponse((x) => x.url().endsWith('/v1/alerts/unsubscribe'), { timeout: 60_000 });
      await toggle.click();
      expect((await r).status()).toBe(200);
    }).toPass({ timeout: 3 * 60_000, intervals: [5_000] });
    await expect(toggle).not.toBeChecked();
    await expect(card.getByTestId('recovery-alerts-state')).toHaveText('Desativados neste aparelho');

    const mocked = (await subscriptionOf(page))!;
    await expect(async () => {
      const payloads = (await messagesFor(page, mocked.endpoint)).map((m) => JSON.parse(decryptWebPush(Buffer.from(m.body, 'base64'), mocked.d, mocked.auth)) as AlertPayload);
      expect(payloads.find((p) => p.type === 'mova.alerts-off')).toMatchObject({ title: 'Movva', body: 'Os alertas de recuperação da sua conta Movva foram desativados neste dispositivo' });
    }).toPass({ timeout: 60_000, intervals: [2_000] });
  });
});
