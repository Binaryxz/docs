/**
 * The delivery escape hatch, in headless Chromium against scripts/dev-stack.ts, on a Safe 2-of-2.
 *
 *   a new wallet locks R$ 30,00 by PIX -> the Entrypoint's owner raises the Movva pool's minimum deposit above the order
 *   (`raisePoolMinimum`), so its shielded delivery would revert -> the order is paid, and the LP node's release reverts
 *   -> the order says why the delivery is impossible, stops showing where to pay, and offers "Receber fora do saldo
 *   protegido" with its privacy cost -> taken (takeDeliveryDirect, a sponsored operation of the account), the LP's next
 *   release pays the account in the open: "Entregue fora do saldo protegido"
 *   -> while the pool still refuses, "Devolver ao saldo protegido" waits, with the reason -> the minimum restored, it
 *   re-shields the Movva from the account: "aguardando aprovação" while the dev ASP holds its approvals, then available.
 */
import { expect, test, type Page } from '@playwright/test';
import {
  openApp, accountReport, accountShown, balanceShown, centavos, expectSponsoredThroughBundler, nav, openContext, saveFailureContext, setFaults, type Opened,
} from './helpers.js';

test.describe.configure({ mode: 'serial' });

/** Movva held by `who`, from the chain through the stack's RPC. */
async function movvaHeld(page: Page, who: string): Promise<bigint> {
  const d = await (await page.request.get('/api/deployment.json')).json() as { contracts: { movva: string } };
  const r = await page.request.post('/api/rpc', {
    data: { jsonrpc: '2.0', id: 1, method: 'eth_call', params: [{ to: d.contracts.movva, data: `0x70a08231${who.slice(2).toLowerCase().padStart(64, '0')}` }, 'latest'] },
  });
  return BigInt((await r.json() as { result: string }).result);
}

test.describe('Movva in a browser: a paid order the pool can no longer take, delivered in the open and put back', () => {
  let opened: Opened;
  let account: string;

  test.beforeAll(async ({ browser }, testInfo) => {
    opened = await openContext(browser, testInfo);
  });

  test.afterEach(async ({}, testInfo) => {
    await saveFailureContext(testInfo, [['escape', opened]]);
  });

  test.afterAll(async () => {
    // Whatever happened above, the specs after this one get the pool as deployed.
    if (opened && !opened.page.isClosed()) await setFaults(opened.page, { raisePoolMinimum: false, holdAsp: false }).catch(() => undefined);
    await opened?.context.close();
  });

  test('an order locked by PIX; the pool minimum then raised above it; the order paid', async () => {
    const { page } = opened;
    await openApp(page);
    await page.getByRole('button', { name: 'Criar carteira com passkey' }).click();
    await expect(await balanceShown(page)).toHaveText('R$ 0,00');
    account = (await accountShown(page)).address;

    await nav(page, 'Comprar');
    await page.getByLabel('Valor em reais').fill('30,00');
    await page.getByRole('button', { name: 'Ver formas de pagamento' }).click();
    await page.getByTestId('rail-pix').click();
    await page.getByRole('button', { name: 'Travar pedido: R$ 30,00 por PIX' }).click();
    const order = page.getByTestId('order');
    await expect(order.getByRole('img', { name: 'QR Code PIX de R$ 30,00' })).toBeVisible({ timeout: 3 * 60_000 });
    await expect(order.getByTestId('delivery-blocked')).toHaveCount(0);
    const brCode = (await order.getByTestId('copy-PIX copia e cola').innerText()).trim();

    expect((await setFaults(page, { raisePoolMinimum: true })).raisePoolMinimum).toBe(true);
    // Paid at the bank as the instructions said: the LP node sees the credit and proves it, and its release reverts.
    const paid = await page.request.post('/api/dev/pay-pix', { data: { pixCopiaECola: brCode } });
    expect(paid.ok()).toBe(true);
  });

  test('the order says why its shielded delivery is impossible and offers "Receber fora do saldo protegido"; taken, it is delivered in the open', async () => {
    const { page } = opened;
    const order = page.getByTestId('order');
    const blocked = order.getByTestId('delivery-blocked');
    await expect(blocked).toBeVisible({ timeout: 60_000 });
    await expect(blocked).toContainText('A entrega no saldo protegido não é possível agora');
    await expect(blocked.getByTestId('delivery-block')).toContainText('O pool de Movva exige agora um depósito mínimo de R$ 1.000.000,00');
    await expect(blocked).toContainText('Se já pagou');
    await expect(blocked.getByTestId('direct-delivery-cost')).toContainText('visíveis na blockchain como seus');
    // Where to pay is no longer shown; cancelling stays free while the order is locked.
    await expect(order.getByRole('img', { name: /QR Code PIX/ })).toHaveCount(0);
    await expect(order.getByRole('button', { name: 'Cancelar pedido (gratuito)' })).toBeVisible();
    // Paid and not released: the LP node cannot deliver it into the pool.
    await expect(order).toContainText('Aguardando pagamento');
    expect(await movvaHeld(page, account)).toBe(0n);

    await blocked.getByRole('button', { name: 'Receber fora do saldo protegido' }).click();
    await expect(order).toContainText('Entregue fora do saldo protegido', { timeout: 4 * 60_000 });
    await expect(order.getByTestId('delivery-blocked')).toHaveCount(0);
    expect(await movvaHeld(page, account)).toBeGreaterThan(29n * 10n ** 18n);
    // The lock (which created the Safe) and takeDeliveryDirect: two sponsored operations of the account.
    expectSponsoredThroughBundler(await accountReport(page, account), 2);
  });

  test('"Devolver ao saldo protegido" waits while the pool refuses; once it accepts, the Movva is re-shielded: awaiting approval, then available', async () => {
    const { page } = opened;
    const order = page.getByTestId('order');
    const back = order.getByTestId('reshield-delivery');
    await expect(back.getByTestId('reshield-visible')).toContainText('visível na blockchain como seu');
    const waits = back.getByTestId('reshield-waits');
    await expect(waits).toContainText('O pool ainda não aceita este depósito.', { timeout: 60_000 });
    await expect(waits).toContainText('R$ 1.000.000,00');
    await expect(back.getByRole('button', { name: 'Devolver ao saldo protegido' })).toHaveCount(0);

    await setFaults(page, { raisePoolMinimum: false, holdAsp: true });
    const button = back.getByRole('button', { name: 'Devolver ao saldo protegido' });
    await expect(button).toBeVisible({ timeout: 60_000 });
    await button.click();
    const done = order.getByTestId('reshielded');
    await expect(done).toContainText('Devolvido ao saldo protegido', { timeout: 4 * 60_000 });
    await expect(done).toContainText('aguardando aprovação');
    const amount = /(R\$ [\d.]+,\d{2}) voltaram/.exec(await done.innerText())![1]!;
    expect(centavos(amount)).toBeGreaterThan(2_900n);
    expect(await movvaHeld(page, account)).toBe(0n);

    await nav(page, 'Início');
    await balanceShown(page);
    await expect(page.getByTestId('awaiting-approval')).toHaveText(amount, { timeout: 60_000 });
    await expect(page.getByTestId('available')).toHaveText('R$ 0,00');
    await expect(page.getByTestId('in-the-open')).toHaveCount(0);
    await expect(page.getByTestId('blocked-deliveries')).toHaveCount(0);

    await setFaults(page, { holdAsp: false });
    await expect(page.getByTestId('awaiting-approval')).toHaveCount(0, { timeout: 2 * 60_000 });
    await expect(page.getByTestId('available')).toHaveText(amount);
    // The deposit back was the account's own third operation, visibly the user's.
    expectSponsoredThroughBundler(await accountReport(page, account), 3);
  });
});
