/**
 * Build the app the stack's gateway serves (dist/), so the browser opens this tree's code - unless MOVA_E2E_SKIP_BUILD=1.
 * The gateway reads dist/ on every request, so building while the stack deploys is fine.
 */
import { execFileSync } from 'node:child_process';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

export default function globalSetup(): void {
  if (process.env.MOVA_E2E_SKIP_BUILD === '1') return;
  const app = resolve(dirname(fileURLToPath(import.meta.url)), '..');
  execFileSync('npx', ['vite', 'build', '--logLevel', 'warn'], { cwd: app, stdio: 'inherit' });
}
