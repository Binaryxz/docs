/**
 * The app in a real browser (headless Chromium), against the local demo stack.
 *
 *   npx playwright install chromium                        # once (CI: --with-deps)
 *   npx playwright test -c packages/app/e2e                # builds the app, starts scripts/dev-stack.ts, runs e2e/*.spec.ts
 *
 * The stack takes ports 8981-8985; the app is opened at http://localhost:8981 - not 127.0.0.1, which Chrome refuses as a
 * passkey's relying party. `MOVA_E2E_REUSE_STACK=1` runs against a stack already started by hand, and
 * `MOVA_E2E_SKIP_BUILD=1` against the dist/ already built. Screenshots and traces of a failure go to e2e/artifacts
 * (gitignored). On a machine without Chromium's system libraries, point LD_LIBRARY_PATH at them: nothing here names a path.
 *
 * Image mode: `MOVA_SERVICES_IMAGE=localhost/mova-services:dev` (and `CONTAINER_RUNTIME`, podman by default) is passed to
 * the stack, which then runs the LP node, matcher, note vault, co-signer and monitor as containers from that
 * image (see packages/app/README.md, "Image mode"); the specs are the same.
 */
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { defineConfig, devices } from '@playwright/test';

const here = dirname(fileURLToPath(import.meta.url));
const APP = resolve(here, '..');
const SERVICES_IMAGE = process.env.MOVA_SERVICES_IMAGE?.trim() || undefined;

export default defineConfig({
  testDir: here,
  testMatch: '*.spec.ts',
  outputDir: resolve(here, 'artifacts'),
  globalSetup: resolve(here, 'global-setup.ts'),
  fullyParallel: false,
  workers: 1,
  retries: 0,
  // Proofs are made in the browser (a Web Worker) and deliveries and sales wait for the LP node: minutes, not seconds.
  timeout: 15 * 60_000,
  expect: { timeout: 30_000 },
  reporter: [['list']],
  use: {
    ...devices['Desktop Chrome'],
    baseURL: 'http://localhost:8981',
    headless: true,
    screenshot: 'only-on-failure',
    trace: 'retain-on-failure',
    actionTimeout: 60_000,
    navigationTimeout: 60_000,
  },
  webServer: {
    command: 'npx tsx scripts/dev-stack.ts',
    cwd: APP,
    url: 'http://127.0.0.1:8981/api/deployment.json',
    // Deploying the account stack (and starting Alto and the co-signer), the contracts, and the LP node's first offers; in
    // image mode also starting six containers, whose services compile their TypeScript as they start.
    timeout: (SERVICES_IMAGE ? 15 : 10) * 60_000,
    reuseExistingServer: process.env.MOVA_E2E_REUSE_STACK === '1',
    env: SERVICES_IMAGE ? { MOVA_SERVICES_IMAGE: SERVICES_IMAGE, CONTAINER_RUNTIME: process.env.CONTAINER_RUNTIME?.trim() || 'podman' } : {},
    stdout: 'pipe',
    stderr: 'pipe',
    // In image mode the stack stops and removes its containers before it exits: give it that long before a SIGKILL.
    gracefulShutdown: { signal: 'SIGTERM', timeout: SERVICES_IMAGE ? 60_000 : 20_000 },
  },
});
