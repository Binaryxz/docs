/**
 * Recovery alerts on this device (src/wallet/alerts.ts), against a fake co-signer and a fake PushManager: when this device
 * counts as subscribed, what subscribing sends, and what unsubscribing does when refused.
 */
import { describe, expect, it, vi } from 'vitest';
import { CoSignerRefused, type PushSubscriptionLike } from '@mova/cosigner/client';
import { AlertsUnavailableHere, disableRecoveryAlerts, enableRecoveryAlerts, recoveryAlertsView, type AlertsDeps, type AlertsRecord } from '../src/wallet/alerts.js';

const ACCOUNT = '0x00000000000000000000000000000000000000aa' as const;
const COSIGNER = '0x00000000000000000000000000000000000000cc' as const;
const VAPID_BYTES = Uint8Array.from([4, ...Array.from({ length: 64 }, (_, i) => i + 1)]);
const VAPID = Buffer.from(VAPID_BYTES).toString('base64url');
const P256DH = Buffer.from(Uint8Array.from([4, ...Array.from({ length: 64 }, () => 9)])).toString('base64url');
const AUTH = Buffer.from(new Uint8Array(16).fill(5)).toString('base64url');
const ENDPOINT = 'https://fcm.googleapis.com/fcm/send/device-1';

function world(o: { alerts?: boolean; browser?: boolean; browserEndpoint?: string; recorded?: string; unsubscribe?: () => Promise<{ unsubscribed: true }> } = {}) {
  const subscription = (endpoint: string, key: Uint8Array): PushSubscriptionLike => ({
    endpoint, options: { applicationServerKey: key.slice().buffer as ArrayBuffer },
    toJSON: () => ({ endpoint, keys: { p256dh: P256DH, auth: AUTH } }),
    unsubscribe: vi.fn(async () => { current = null; return true; }),
  });
  let current: PushSubscriptionLike | null = o.browserEndpoint ? subscription(o.browserEndpoint, VAPID_BYTES) : null;
  const pushManager = {
    getSubscription: vi.fn(async () => current),
    subscribe: vi.fn(async (opts: { userVisibleOnly: boolean; applicationServerKey: Uint8Array }) => (current = subscription(ENDPOINT, opts.applicationServerKey))),
  };
  let record: AlertsRecord | undefined = o.recorded ? { endpoint: o.recorded, at: 1 } : undefined;
  const cosigner = {
    info: vi.fn(async () => ({ alerts: o.alerts === false ? null : { vapidPublicKey: VAPID, subscribeTypehash: '0x01', unsubscribeTypehash: '0x02', maxProofAgeSeconds: 300 } })),
    subscribeAlerts: vi.fn(async () => ({ subscribed: true as const, created: true, pending: 0 })),
    unsubscribeAlerts: vi.fn(o.unsubscribe ?? (async () => ({ unsubscribed: true as const }))),
  };
  const sign = vi.fn();
  const deps: AlertsDeps = {
    cosigner: cosigner as unknown as AlertsDeps['cosigner'], account: ACCOUNT, coSigner: COSIGNER, sign,
    registration: async () => (o.browser === false ? undefined : { pushManager }),
    record: { read: () => record, write: (r) => { record = r; }, remove: () => { record = undefined; } },
    now: () => 1_700_000_000,
  };
  return { deps, cosigner, pushManager, sign, record: () => record, browser: () => current };
}

describe('whether this device receives recovery alerts', () => {
  it('not for an EOA, a co-signer without alerts, or a browser without Push', async () => {
    expect(await recoveryAlertsView(undefined)).toEqual({ available: false, unavailable: 'eoa', subscribed: false });
    expect(await recoveryAlertsView(world({ alerts: false }).deps)).toEqual({ available: false, unavailable: 'cosigner', subscribed: false });
    expect(await recoveryAlertsView(world({ browser: false }).deps)).toEqual({ available: false, unavailable: 'browser', subscribed: false });
  });

  it('subscribed only while the browser still holds the subscription this device recorded', async () => {
    expect(await recoveryAlertsView(world().deps)).toEqual({ available: true, subscribed: false });
    expect(await recoveryAlertsView(world({ browserEndpoint: ENDPOINT, recorded: ENDPOINT }).deps)).toEqual({ available: true, subscribed: true });
    expect((await recoveryAlertsView(world({ recorded: ENDPOINT }).deps)).subscribed).toBe(false);
    expect((await recoveryAlertsView(world({ browserEndpoint: `${ENDPOINT}-other`, recorded: ENDPOINT }).deps)).subscribed).toBe(false);
  });
});

describe('turning them on', () => {
  it('subscribes the browser for the co-signer\'s VAPID key, registers it with the passkey, and records it', async () => {
    const w = world();
    expect(await enableRecoveryAlerts(w.deps)).toEqual({ pending: 0 });
    expect(w.pushManager.subscribe).toHaveBeenCalledOnce();
    const [opts] = w.pushManager.subscribe.mock.calls[0]!;
    expect(opts.userVisibleOnly).toBe(true);
    expect(new Uint8Array(opts.applicationServerKey)).toEqual(VAPID_BYTES);
    expect(w.cosigner.subscribeAlerts).toHaveBeenCalledWith({
      account: ACCOUNT, coSigner: COSIGNER, subscription: { endpoint: ENDPOINT, keys: { p256dh: P256DH, auth: AUTH } }, sign: w.sign,
    });
    expect(w.record()).toEqual({ endpoint: ENDPOINT, at: 1_700_000_000 });
  });

  it('refused without Push or without the co-signer\'s alerts; a co-signer refusal records nothing', async () => {
    await expect(enableRecoveryAlerts(world({ browser: false }).deps)).rejects.toBeInstanceOf(AlertsUnavailableHere);
    await expect(enableRecoveryAlerts(world({ alerts: false }).deps)).rejects.toMatchObject({ code: 'alerts_disabled' });
    const w = world();
    w.cosigner.subscribeAlerts.mockRejectedValueOnce(new CoSignerRefused(422, 'push_endpoint_refused', 'the endpoint is not on a push service this co-signer sends to'));
    await expect(enableRecoveryAlerts(w.deps)).rejects.toMatchObject({ code: 'push_endpoint_refused' });
    expect(w.record()).toBeUndefined();
  });
});

describe('turning them off', () => {
  it('unsubscribes this browser\'s endpoint with the passkey and forgets the record; the browser keeps its push subscription', async () => {
    const w = world({ browserEndpoint: ENDPOINT, recorded: ENDPOINT });
    await disableRecoveryAlerts(w.deps);
    expect(w.cosigner.unsubscribeAlerts).toHaveBeenCalledWith({ account: ACCOUNT, coSigner: COSIGNER, endpoint: ENDPOINT, sign: w.sign });
    expect(w.record()).toBeUndefined();
    expect(w.browser()).not.toBeNull();
  });

  it('refused while a recovery is queued: the refusal reaches the screen, and the device stays subscribed', async () => {
    const w = world({ browserEndpoint: ENDPOINT, recorded: ENDPOINT, unsubscribe: async () => { throw new CoSignerRefused(409, 'recovery_pending', 'the account has a queued recovery transaction'); } });
    await expect(disableRecoveryAlerts(w.deps)).rejects.toMatchObject({ code: 'recovery_pending' });
    expect(w.record()).toEqual({ endpoint: ENDPOINT, at: 1 });
    expect((await recoveryAlertsView(w.deps)).subscribed).toBe(true);
  });

  it('a device the co-signer never had is simply off', async () => {
    const w = world({ browserEndpoint: ENDPOINT, recorded: ENDPOINT, unsubscribe: async () => { throw new CoSignerRefused(404, 'subscription_unknown', 'that device is not subscribed'); } });
    await disableRecoveryAlerts(w.deps);
    expect(w.record()).toBeUndefined();
  });
});
