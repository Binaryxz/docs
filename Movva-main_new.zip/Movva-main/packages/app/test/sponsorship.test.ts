/**
 * Before an account's first operation (src/wallet/account.ts, `enrolAndSponsor`): enrolled with the co-signer, then
 * sponsored by its sponsorship module through SponsorGate - the production path, with no endpoint of the app's own.
 */
import { describe, expect, it, vi } from 'vitest';
import { SponsorshipNotGranted, type RemoteSponsorship } from '@mova/cosigner/client';
import { AccountSetupError, enrolAndSponsor } from '../src/wallet/account.js';

const ACCOUNT = '0x00000000000000000000000000000000000000aa' as const;
const view = (status: RemoteSponsorship['status'], over: Partial<RemoteSponsorship> = {}): RemoteSponsorship => ({ chainId: 31337, account: ACCOUNT, status, ...over });

function steps(o: { enrolled?: boolean; ready?: boolean[]; enrolAnswers?: (RemoteSponsorship | undefined)[]; current?: RemoteSponsorship; wait?: () => Promise<RemoteSponsorship> } = {}) {
  const readies = [...(o.ready ?? [false, true])];
  const answers = [...(o.enrolAnswers ?? [view('pending')])];
  return {
    enrolled: vi.fn(async () => o.enrolled ?? false),
    enrol: vi.fn(async () => {
      const a = answers.shift();
      return a ? { sponsorship: a } : {};
    }),
    ready: vi.fn(async () => (readies.length > 1 ? readies.shift()! : readies[0]!)),
    sponsorship: vi.fn(async () => o.current ?? view('none')),
    waitForSponsorship: vi.fn(o.wait ?? (async () => view('sponsored'))),
  };
}

describe('enrolment, then the co-signer\'s sponsorship', () => {
  it('a new account: enrolled with one assertion, then waited for until the co-signer sponsored it', async () => {
    const s = steps();
    expect(await enrolAndSponsor(s)).toEqual({ enrolled: true, sponsored: true });
    expect(s.enrol).toHaveBeenCalledOnce();
    expect(s.waitForSponsorship).toHaveBeenCalledOnce();
    expect(s.sponsorship).not.toHaveBeenCalled();
  });

  it('an account that can already transact asks nothing more: no enrolment, no wait', async () => {
    const s = steps({ enrolled: true, ready: [true] });
    expect(await enrolAndSponsor(s)).toEqual({ enrolled: false, sponsored: false });
    expect(s.enrol).not.toHaveBeenCalled();
    expect(s.waitForSponsorship).not.toHaveBeenCalled();
  });

  it('enrolled but never asked, or refused for a reason that may pass: enrolling again asks again', async () => {
    for (const current of [view('none'), view('refused', { code: 'daily_cap', retryable: true }), view('failed', { code: 'transaction_failed', retryable: true })]) {
      const s = steps({ enrolled: true, current });
      expect(await enrolAndSponsor(s), current.status).toEqual({ enrolled: false, sponsored: true });
      expect(s.enrol, current.status).toHaveBeenCalledOnce();
      expect(s.waitForSponsorship, current.status).toHaveBeenCalledOnce();
    }
  });

  it('refused for good: not asked again, and the refusal reaches the screen', async () => {
    const revoked = view('refused', { code: 'sponsorship_revoked', retryable: false });
    const s = steps({ enrolled: true, current: revoked, wait: async () => { throw new SponsorshipNotGranted(revoked); } });
    await expect(enrolAndSponsor(s)).rejects.toBeInstanceOf(SponsorshipNotGranted);
    expect(s.enrol).not.toHaveBeenCalled();
  });

  it('sponsored already in the enrolment\'s answer: no wait', async () => {
    const s = steps({ enrolAnswers: [view('sponsored', { sponsorTx: '0x01' })] });
    expect(await enrolAndSponsor(s)).toEqual({ enrolled: true, sponsored: true });
    expect(s.waitForSponsorship).not.toHaveBeenCalled();
  });

  it('the co-signer calls it sponsored but the paymaster does not: refused before any operation', async () => {
    await expect(enrolAndSponsor(steps({ ready: [false] }))).rejects.toBeInstanceOf(AccountSetupError);
  });

  it('called sponsored, but the account still has no code: enrolling again asks the service to finish it', async () => {
    // What a Kernel account enrolled before the service deployed accounts looks like: allowlisted on the paymaster,
    // no code, so its first operation would have to carry initCode. Enrolling again is what makes the service deploy it.
    const s = steps({ enrolled: true, current: view('sponsored', { sponsorTx: '0x01' }), enrolAnswers: [view('pending')] });
    expect(await enrolAndSponsor(s)).toEqual({ enrolled: false, sponsored: true });
    expect(s.enrol).toHaveBeenCalledOnce();
    expect(s.waitForSponsorship).toHaveBeenCalledOnce();
  });
});
