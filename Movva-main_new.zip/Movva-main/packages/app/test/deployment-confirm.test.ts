// @vitest-environment happy-dom
/**
 * The app's side of M-23: the deployment JSON it loads at start (from a URL, or saved in localStorage) is never used
 * silently unless it is exactly the one this device accepted, or its chain's canonical deployment on a first use. A
 * local chain shows a strong warning and needs an explicit tick. A changed file shows what differs. A file
 * contradicting its chain's record is refused before anything is offered. Loading another deployment from Ajustes
 * goes through the same confirmation.
 */
import { act, createElement } from 'react';
import { createRoot, type Root } from 'react-dom/client';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { getAddress } from 'viem';
import { CANONICAL_DEPLOYMENTS } from '../src/lib/canonical.js';
import { App } from '../src/ui/App.js';
import { UNPINNED_ACK, UNPINNED_WARNING } from '../src/ui/DeploymentConfirm.js';

(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

const ORIGIN = 'http://127.0.0.1:8981';
const a = (n: number) => getAddress(`0x${n.toString(16).padStart(40, '0')}`);
const CONTRACTS = ['movva', 'reserve', 'onramp', 'offramp', 'entrypoint', 'movvaPool', 'saleVerifier', 'auditGrantRegistry'];
const localJson = (over: Record<string, unknown> = {}) => ({
  version: 1, name: 'Movva · demonstração local (anvil)', chainId: 31337, rpcUrl: '/api/rpc', fromBlock: '1',
  contracts: Object.fromEntries(CONTRACTS.map((k, i) => [k, a(i + 1)])),
  services: { matcher: '/api/matcher', lpNodes: [{ lp: a(20), url: '/api/lp' }], relayer: '/api/relayer', asp: '/api/asp' },
  ...over,
});

let mounted: Root | undefined;
let served: Record<string, unknown>;

beforeEach(() => {
  (window as unknown as { happyDOM: { setURL(u: string): void } }).happyDOM.setURL(`${ORIGIN}/`);
  localStorage.clear();
  served = { '/api/deployment.json': localJson() };
  vi.stubGlobal('fetch', vi.fn(async (input: string | URL) => {
    const u = new URL(String(input));
    const body = served[u.pathname];
    return body ? new Response(JSON.stringify(body), { status: 200 }) : new Response('{}', { status: 404 });
  }));
});
afterEach(() => {
  act(() => mounted?.unmount());
  mounted = undefined;
  document.body.innerHTML = '';
  vi.unstubAllGlobals();
});

const settle = async () => {
  for (let i = 0; i < 5; i++) await act(async () => { await new Promise((r) => setTimeout(r, 0)); });
};

async function start(): Promise<HTMLElement> {
  const host = document.createElement('div');
  document.body.appendChild(host);
  mounted = createRoot(host);
  await act(async () => { mounted!.render(createElement(App)); });
  await settle();
  return host;
}

const button = (host: HTMLElement, text: string) => [...host.querySelectorAll('button')].find((b) => b.textContent?.includes(text)) as HTMLButtonElement | undefined;
const click = async (el: Element | undefined) => {
  if (!el) throw new Error('nothing to click');
  await act(async () => { (el as HTMLElement).click(); });
  await settle();
};

describe('the deployment the app starts with', () => {
  it('a local chain (no canonical record): a strong warning, and nothing is used until the risk is ticked and confirmed', async () => {
    const host = await start();
    const confirm = host.querySelector('[data-testid=deployment-confirm]')!;
    expect(confirm).not.toBeNull();
    expect(host.querySelector('[data-testid=unpinned-warning]')!.textContent).toBe(UNPINNED_WARNING(31337));
    expect(host.querySelector('[data-testid=recovery-explained]')).toBeNull();
    const use = button(host, 'Usar este deployment')!;
    expect(use.disabled).toBe(true);
    expect(localStorage.getItem('mova:deployment-accepted:v1')).toBeNull();

    const tick = [...host.querySelectorAll('label')].find((l) => l.textContent === UNPINNED_ACK)!.querySelector('input')!;
    await click(tick);
    expect(button(host, 'Usar este deployment')!.disabled).toBe(false);
    await click(button(host, 'Usar este deployment'));
    expect(host.querySelector('[data-testid=deployment-confirm]')).toBeNull();
    expect(host.querySelector('[data-testid=recovery-explained]')).not.toBeNull();
    expect(JSON.parse(localStorage.getItem('mova:deployment-accepted:v1')!)).toMatchObject({ chainId: '31337', 'contracts.movvaPool': a(6) });
  });

  it('once accepted, the same deployment opens without asking', async () => {
    let host = await start();
    await click([...host.querySelectorAll('label')].find((l) => l.textContent === UNPINNED_ACK)!.querySelector('input')!);
    await click(button(host, 'Usar este deployment'));
    act(() => mounted?.unmount());
    document.body.innerHTML = '';
    host = await start();
    expect(host.querySelector('[data-testid=deployment-confirm]')).toBeNull();
    expect(host.querySelector('[data-testid=recovery-explained]')).not.toBeNull();
  });

  it('a JSON saved in localStorage that differs from the accepted one is not used silently: the diff is shown, and refusing uses nothing', async () => {
    let host = await start();
    await click([...host.querySelectorAll('label')].find((l) => l.textContent === UNPINNED_ACK)!.querySelector('input')!);
    await click(button(host, 'Usar este deployment'));
    act(() => mounted?.unmount());
    document.body.innerHTML = '';

    const swapped = localJson({ contracts: { ...localJson().contracts as Record<string, string>, movvaPool: a(0x66) } });
    localStorage.setItem('mova:deployment-json', JSON.stringify(swapped));
    host = await start();
    const diff = host.querySelector('[data-testid=deployment-diff]')!;
    expect(diff).not.toBeNull();
    const rows = [...diff.querySelectorAll('tbody tr')].map((r) => [...r.querySelectorAll('td')].map((td) => td.textContent));
    expect(rows).toEqual([['Pool Movva', a(6), a(0x66)]]);
    await click(button(host, 'Recusar'));
    expect(host.textContent).toContain('Deployment recusado');
    expect(host.querySelector('.topbar')!.textContent).toContain('sem deployment');
    expect(JSON.parse(localStorage.getItem('mova:deployment-accepted:v1')!)['contracts.movvaPool']).toBe(a(6));
  });

  it('a file claiming a chain with a canonical record, with another contract, is refused naming the field; nothing is offered', async () => {
    const sepolia = CANONICAL_DEPLOYMENTS[11155111]!;
    localStorage.setItem('mova:deployment-json', JSON.stringify({
      version: 1, chainId: 11155111, rpcUrl: 'https://rpc.example', fromBlock: sepolia.fromBlock,
      contracts: { ...sepolia.contracts, movvaPool: a(0xbad) },
      services: { matcher: 'https://m.example', lpNodes: [{ lp: a(9), url: 'https://lp.example' }], relayer: 'https://r.example', asp: 'https://a.example' },
    }));
    const host = await start();
    expect(host.querySelector('[data-testid=deployment-confirm]')).toBeNull();
    expect(host.textContent).toContain('Deployment não confere com o registro');
    expect(host.textContent).toContain(`Pool Movva (registro ${sepolia.contracts.movvaPool}, arquivo ${a(0xbad)})`);
    expect(localStorage.getItem('mova:deployment-accepted:v1')).toBeNull();
  });

  it('a deployment URL over plain http to another host is refused', async () => {
    localStorage.setItem('mova:deployment-url', 'http://movva.example/api/deployment.json');
    const host = await start();
    expect(host.textContent).toContain('URL do deployment: use https');
    expect(fetch).not.toHaveBeenCalled();
  });
});

describe('loading another deployment in Ajustes', () => {
  it('goes through the same confirmation, with the diff; keeping the current one changes nothing', async () => {
    let host = await start();
    await click([...host.querySelectorAll('label')].find((l) => l.textContent === UNPINNED_ACK)!.querySelector('input')!);
    await click(button(host, 'Usar este deployment'));
    location.hash = '#/ajustes';
    await settle();
    host = document.body.firstElementChild as HTMLElement;
    served['/other.json'] = localJson({ name: 'Outra', services: { ...localJson().services as object, relayer: '/outro-relayer' } });
    const input = [...host.querySelectorAll('input')].find((i) => i.value.endsWith('/api/deployment.json'))!;
    await act(async () => {
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')!.set!.call(input, `${ORIGIN}/other.json`);
      input.dispatchEvent(new Event('input', { bubbles: true }));
    });
    await click(button(host, 'Carregar'));
    const rows = [...host.querySelectorAll('[data-testid=deployment-diff] tbody tr')].map((r) => r.getAttribute('data-field'));
    expect(rows).toEqual(['name', 'services.relayer']);
    expect(host.querySelector('[data-testid=unpinned-warning]')).not.toBeNull();
    await click(button(host, 'Manter o atual'));
    expect(host.querySelector('[data-testid=deployment-confirm]')).toBeNull();
    expect(host.querySelector('.topbar')!.textContent).toContain('demonstração local');
    expect(localStorage.getItem('mova:deployment-url')).toBeNull();
  });
});
