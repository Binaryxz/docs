/**
 * The wallet's seed comes from a passkey's PRF and from nothing else (audit H-03): a registration or an assertion
 * without PRF output opens no wallet and stores nothing, a browser that says it has no PRF is refused before a passkey
 * is created, and a wallet left by the removed recovery-code path is neither opened nor kept. The removed path is gone
 * from the app's source and from the dev stack.
 */
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { p256 } from '@noble/curves/nist';
import { bytesToHex } from '@noble/hashes/utils';
import { PasskeyAuthenticator, SeedUnavailableError, derivePoolSeed } from '@mova/smart-account';
import {
  PrfUnsupported, createWithPasskey, discardLegacyIdentity, hasLegacyIdentity, loadIdentity, prfSupport, unlockWithPasskey,
} from '../src/passkey/seed.js';
import { MemoryKeyValue } from '../src/wallet/stores.js';

const APP = fileURLToPath(new URL('..', import.meta.url));
const IDENTITY = 'mova:identity:v1';

const spkiOf = (a: PasskeyAuthenticator) => Uint8Array.from([
  0x30, 0x59, 0x30, 0x13, 0x06, 0x07, 0x2a, 0x86, 0x48, 0xce, 0x3d, 0x02, 0x01, 0x06, 0x08, 0x2a, 0x86, 0x48, 0xce, 0x3d, 0x03, 0x01, 0x07,
  0x03, 0x42, 0x00, ...p256.getPublicKey(a.export().privateKey, false),
]);

/** A browser whose passkey is `auth`: its registration returns `prf` as the client extension result. */
function browser(o: { prf?: { enabled?: boolean; results?: { first?: ArrayBuffer } }; assertionPrf?: Uint8Array; caps?: Record<string, boolean> }) {
  const auth = PasskeyAuthenticator.create('localhost');
  const rawId = new Uint8Array(16).fill(7).buffer;
  const create = vi.fn(async () => ({
    rawId, response: { getPublicKey: () => spkiOf(auth).buffer, getPublicKeyAlgorithm: () => -7 },
    getClientExtensionResults: () => (o.prf ? { prf: o.prf } : {}),
  }));
  const get = vi.fn(async () => ({
    rawId, response: {},
    getClientExtensionResults: () => (o.assertionPrf ? { prf: { results: { first: o.assertionPrf.slice().buffer } } } : {}),
  }));
  vi.stubGlobal('navigator', { credentials: { create, get } });
  vi.stubGlobal('PublicKeyCredential', o.caps ? { getClientCapabilities: async () => o.caps } : {});
  return { create, get };
}

afterEach(() => vi.unstubAllGlobals());

describe('a wallet needs a passkey with PRF', () => {
  it('a registration without PRF throws PrfUnsupported and stores nothing', async () => {
    browser({ prf: { enabled: false } });
    const kv = new MemoryKeyValue();
    await expect(createWithPasskey(kv)).rejects.toBeInstanceOf(PrfUnsupported);
    expect(kv.keys()).toEqual([]);
  });

  it('a browser that says it has no PRF is refused before any passkey is created', async () => {
    const { create } = browser({ caps: { 'extension:prf': false }, prf: { enabled: true } });
    expect(await prfSupport()).toBe(false);
    await expect(createWithPasskey(new MemoryKeyValue())).rejects.toBeInstanceOf(PrfUnsupported);
    expect(create).not.toHaveBeenCalled();
  });

  it('with PRF: the seed is the PRF output\'s, and only the credential and public key are kept', async () => {
    const prf = new Uint8Array(32).fill(3);
    browser({ prf: { enabled: true, results: { first: prf.slice().buffer } } });
    const kv = new MemoryKeyValue();
    const { seed, identity } = await createWithPasskey(kv);
    expect(bytesToHex(seed)).toBe(bytesToHex(derivePoolSeed(prf)));
    expect(identity.kind).toBe('webauthn-prf');
    const stored = JSON.parse(kv.get(IDENTITY)!) as Record<string, unknown>;
    expect(Object.keys(stored).sort()).toEqual(['createdAt', 'credentialId', 'kind', 'passkey', 'v']);
    expect(kv.keys()).toEqual([IDENTITY]);
  });

  it('an assertion without PRF output opens nothing, and nothing else is tried', async () => {
    const { get } = browser({});
    const fetchSpy = vi.fn();
    vi.stubGlobal('fetch', fetchSpy);
    const kv = new MemoryKeyValue();
    await expect(unlockWithPasskey(kv)).rejects.toBeInstanceOf(SeedUnavailableError);
    expect(get).toHaveBeenCalled();
    expect(fetchSpy).not.toHaveBeenCalled();
    expect(kv.keys()).toEqual([]);
  });
});

describe('a wallet from the removed recovery-code path', () => {
  it('is not loaded as an identity, is recognised, and is deleted with its plaintext device share', () => {
    const kv = new MemoryKeyValue();
    kv.set(IDENTITY, JSON.stringify({ v: 1, kind: 'split-share', deviceShare: 'ab'.repeat(38), createdAt: 1 }));
    expect(loadIdentity(kv)).toBeUndefined();
    expect(hasLegacyIdentity(kv)).toBe(true);
    discardLegacyIdentity(kv);
    expect(kv.get(IDENTITY)).toBeNull();
  });

  it('discarding touches nothing else: a PRF identity stays', () => {
    const kv = new MemoryKeyValue();
    const prf = JSON.stringify({ v: 1, kind: 'webauthn-prf', credentialId: 'AA', createdAt: 1 });
    kv.set(IDENTITY, prf);
    expect(hasLegacyIdentity(kv)).toBe(false);
    discardLegacyIdentity(kv);
    expect(kv.get(IDENTITY)).toBe(prf);
    expect(loadIdentity(kv)?.kind).toBe('webauthn-prf');
  });
});

describe('the removed path stays removed', () => {
  const files = (dir: string): string[] => readdirSync(dir).flatMap((n) => {
    const p = join(dir, n);
    return statSync(p).isDirectory() ? files(p) : /\.(ts|tsx)$/.test(n) ? [p] : [];
  });

  it('no app source splits a seed, keeps a device share, or fetches a server share', () => {
    for (const f of files(join(APP, 'src'))) {
      const src = readFileSync(f, 'utf8');
      expect(src, f).not.toMatch(/RecoverableSplitSeedSource|SplitSeedSource|decodeRecoveryCode|fetchServerShare|unlockWithShares|createWithRecoveryCode|derive-from-seed|services\.shares/);
    }
  });

  it('the dev stack serves no share server and names none in its deployment', () => {
    const stack = readFileSync(join(APP, 'scripts', 'dev-stack.ts'), 'utf8');
    expect(stack).not.toMatch(/\/api\/shares|shares: '/);
  });
});
