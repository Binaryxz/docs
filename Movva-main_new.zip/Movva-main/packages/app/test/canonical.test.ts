/**
 * The trust root (audit M-23): canonical deployments embedded per chain and generated from the repository's records;
 * a file for a pinned chain refused on any mismatch, naming the field; a chain without a record only after
 * confirmation; https for every endpoint but this machine's; and no deployment used silently unless it is exactly the
 * one this device accepted, or the canonical one on a first use.
 */
import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import { getAddress } from 'viem';
import { CANONICAL_DEPLOYMENTS, DeploymentNotCanonical, canonicalFor, checkCanonical, type CanonicalDeployment } from '../src/lib/canonical.js';
import { assessDeployment, diffSummaries, loadAccepted, saveAccepted, summarize } from '../src/lib/deployment-trust.js';
import { DeploymentInvalid, parseDeployment, withOverrides } from '../src/lib/deployment.js';
import { describeError } from '../src/lib/refusals.js';
import { MemoryKeyValue } from '../src/wallet/stores.js';
import { GENERATED, SEPOLIA_RECORDS, canonicalDeployments, readFromRepo, renderModule, sepoliaCanonical, type ReadRecord } from '../scripts/canonical-deployments.js';

const SEPOLIA = 11155111;
const sepolia = CANONICAL_DEPLOYMENTS[SEPOLIA]!;
const a = (n: number) => getAddress(`0x${n.toString(16).padStart(40, '0')}`);

/** A deployment JSON for Sepolia naming exactly the canonical contracts, with https endpoints. */
const sepoliaJson = (c: CanonicalDeployment = sepolia) => ({
  version: 1, name: 'Movva Sepolia', chainId: c.chainId, rpcUrl: 'https://rpc.sepolia.example', fromBlock: c.fromBlock,
  contracts: { ...c.contracts },
  services: { matcher: 'https://m.example', lpNodes: [{ lp: a(9), url: 'https://lp.example' }], relayer: 'https://r.example', asp: 'https://asp.example', vault: 'https://v.example' },
  account: {
    kind: 'safe', kinds: ['safe', 'kernel'], bundler: 'https://bundler.example', ownerlessPaymaster: { address: c.account!.ownerlessPaymaster },
    cosigner: { url: 'https://cosigner.example', address: a(77) }, kernel: { ...c.account!.kernel },
  },
});
const SOURCE = 'https://app.movva.example/api/deployment.json';
const parse = (j: unknown, source = SOURCE) => parseDeployment(j, source);

const localJson = () => ({
  version: 1, chainId: 31337, rpcUrl: '/api/rpc', fromBlock: '1',
  contracts: Object.fromEntries(['movva', 'reserve', 'onramp', 'offramp', 'entrypoint', 'movvaPool', 'saleVerifier', 'auditGrantRegistry'].map((k, i) => [k, a(i + 1)])),
  services: { matcher: '/m', lpNodes: [{ lp: a(20), url: '/lp' }], relayer: '/r', asp: '/a' },
});
const local = (j: unknown = localJson()) => parse(j, 'http://127.0.0.1:8981/api/deployment.json');

describe('the canonical records in the bundle', () => {
  it('the committed module is exactly what the generator writes from the deployment records', () => {
    expect(readFileSync(GENERATED, 'utf8')).toBe(renderModule(canonicalDeployments()));
  });

  it('Sepolia comes from the final rail, the hedge sleeve and the account stack, field by field', () => {
    const rail = readFromRepo(SEPOLIA_RECORDS.rail) as { contracts: Record<string, Record<string, string>>; firstBlock: number | string };
    const hedge = readFromRepo(SEPOLIA_RECORDS.hedge) as { contracts: Record<string, string> };
    const account = readFromRepo(SEPOLIA_RECORDS.account) as { contracts: Record<string, string> };
    const g = (x: string) => getAddress(x);
    expect(sepolia.contracts).toEqual({
      movva: g(rail.contracts.movva!.token!), reserve: g(rail.contracts.movva!.reserve!),
      onramp: g(rail.contracts.ramp!.movvaOnramp!), offramp: g(rail.contracts.ramp!.movvaOfframp!),
      entrypoint: g(rail.contracts.protocol!.entrypoint!), movvaPool: g(rail.contracts.pools!.movva!),
      saleVerifier: g(rail.contracts.ramp!.zktls!), lpRegistry: g(rail.contracts.ramp!.registry!), aspQuorum: g(rail.contracts.asp!.quorum!),
      auditGrantRegistry: g(account.contracts.auditGrantRegistry!),
      hedgeSubWallet: g(hedge.contracts.subWallet!), hedgeVenue: g(hedge.contracts.venue!),
    });
    expect(sepolia.fromBlock).toBe(String(rail.firstBlock));
    expect(sepolia.account).toEqual({
      ownerlessPaymaster: g(account.contracts.ownerlessPaymaster!),
      kernel: { passkeyValidator: g(account.contracts.passkeyCoSignerValidator!), adapter: g(account.contracts.kernelAvatarAdapter!) },
    });
    // No record names the co-signer: nothing is pinned for it.
    expect(sepolia.account?.coSigner).toBeUndefined();
    expect(sepolia.sources).toEqual([SEPOLIA_RECORDS.rail, SEPOLIA_RECORDS.hedge, SEPOLIA_RECORDS.account]);
    expect(canonicalFor(31337)).toBeUndefined();
  });

  /** The repository's records, with one changed. */
  const patched = (path: string, patch: (r: Record<string, unknown>) => void): ReadRecord => (p) => {
    const r = structuredClone(readFromRepo(p)) as Record<string, unknown>;
    if (p === path) patch(r);
    return r;
  };

  it('the generator refuses a record that is not live, has a failed check or an unfinished step, or a sleeve on another reserve', () => {
    expect(() => sepoliaCanonical(patched(SEPOLIA_RECORDS.rail, (r) => { r.mode = 'rehearsal'; }))).toThrow(/mode rehearsal, expected live/);
    expect(() => sepoliaCanonical(patched(SEPOLIA_RECORDS.account, (r) => { (r.verification as { fail: number }).fail = 1; }))).toThrow(/verification.fail is 1/);
    expect(() => sepoliaCanonical(patched(SEPOLIA_RECORDS.rail, (r) => { (r.steps as Record<string, { status: string }>).ramp!.status = 'pending'; }))).toThrow(/step ramp is pending/);
    expect(() => sepoliaCanonical(patched(SEPOLIA_RECORDS.hedge, (r) => { (r.contracts as Record<string, string>).reserve = a(5); }))).toThrow(/not the final rail's/);
    expect(() => sepoliaCanonical(patched(SEPOLIA_RECORDS.rail, (r) => { delete (r.contracts as Record<string, Record<string, string>>).pools!.movva; }))).toThrow(/contracts.pools.movva is missing/);
    expect(() => sepoliaCanonical(patched(SEPOLIA_RECORDS.rail, (r) => { r.chainId = 1; }))).toThrow(/chainId 1, expected 11155111/);
  });

  it('a co-signer named by a record is pinned; two different ones are refused', () => {
    const named = sepoliaCanonical(patched(SEPOLIA_RECORDS.account, (r) => { r.cosigner = { address: a(77).toLowerCase() }; }));
    expect(named.account?.coSigner).toBe(a(77));
    const both: ReadRecord = (p) => {
      const r = structuredClone(readFromRepo(p)) as Record<string, unknown>;
      if (p === SEPOLIA_RECORDS.rail) r.coSigner = a(1);
      if (p === SEPOLIA_RECORDS.account) r.coSigner = a(2);
      return r;
    };
    expect(() => sepoliaCanonical(both)).toThrow(/different co-signers/);
  });
});

describe('a file for a chain with a canonical record', () => {
  it('naming exactly its contracts: used without asking on a first use', () => {
    const d = parse(sepoliaJson());
    expect(checkCanonical(d)).toBe('canonical');
    expect(assessDeployment(d, undefined)).toEqual({ kind: 'use', pinned: 'canonical' });
  });

  it('any other contract address is refused, naming the field, what the record says and what the file says', () => {
    for (const key of ['movva', 'reserve', 'onramp', 'offramp', 'entrypoint', 'movvaPool', 'saleVerifier', 'auditGrantRegistry', 'lpRegistry', 'aspQuorum', 'hedgeSubWallet', 'hedgeVenue'] as const) {
      const j = sepoliaJson();
      j.contracts[key] = a(0xbad);
      const d = parse(j);
      let thrown: unknown;
      try { checkCanonical(d); } catch (e) { thrown = e; }
      expect(thrown, key).toBeInstanceOf(DeploymentNotCanonical);
      expect((thrown as DeploymentNotCanonical).diffs).toEqual([expect.objectContaining({ field: `contracts.${key}`, expected: sepolia.contracts[key], actual: a(0xbad) })]);
      // No confirmation can accept it.
      expect(() => assessDeployment(d, summarize(d))).toThrow(DeploymentNotCanonical);
    }
  });

  it('the refusal reads in Portuguese with every differing field', () => {
    const j = sepoliaJson();
    j.contracts.movvaPool = a(1);
    j.contracts.onramp = a(2);
    let thrown: unknown;
    try { checkCanonical(parse(j)); } catch (e) { thrown = e; }
    const v = describeError(thrown);
    expect(v.title).toBe('Deployment não confere com o registro');
    expect(v.detail).toContain('o arquivo diz ser da rede 11155111');
    expect(v.detail).toContain(`Pool Movva (registro ${sepolia.contracts.movvaPool}, arquivo ${a(1)})`);
    expect(v.detail).toContain(`Escrow de compra (registro ${sepolia.contracts.onramp}, arquivo ${a(2)})`);
  });

  it('a paymaster, Kernel validator or adapter other than the record\'s is refused; the co-signer too, once a record pins it', () => {
    const pm = sepoliaJson();
    pm.account.ownerlessPaymaster = { address: a(3) };
    expect(() => checkCanonical(parse(pm))).toThrow(/Paymaster/);
    const sponsor = sepoliaJson() as Record<string, unknown> & { account: Record<string, unknown> };
    delete sponsor.account.ownerlessPaymaster;
    sponsor.account.paymasterAndData = `0x${'ab'.repeat(20)}${'00'.repeat(32)}`;
    expect(() => checkCanonical(parse(sponsor))).toThrow(/Paymaster/);
    const kv = sepoliaJson();
    kv.account.kernel = { passkeyValidator: a(4), adapter: sepolia.account!.kernel!.adapter };
    expect(() => checkCanonical(parse(kv))).toThrow(/Validador Kernel/);
    const pinned = { ...sepolia, account: { ...sepolia.account, coSigner: a(78) } };
    expect(() => checkCanonical(parse(sepoliaJson()), { [SEPOLIA]: pinned })).toThrow(/Cossignatário \(registro 0x0{38}4[eE], arquivo 0x0{38}4[dD]\)/);
    expect(checkCanonical(parse({ ...sepoliaJson(), account: { ...sepoliaJson().account, cosigner: { url: 'https://c.example', address: a(78) } } }), { [SEPOLIA]: pinned })).toBe('canonical');
  });

  it('a contract the record does not have is refused; one the file leaves out is not used, so it passes', () => {
    const noHedge = { ...sepolia, contracts: { ...sepolia.contracts } };
    delete noHedge.contracts.hedgeSubWallet;
    delete noHedge.contracts.hedgeVenue;
    expect(() => checkCanonical(parse(sepoliaJson()), { [SEPOLIA]: noHedge })).toThrow(/Sub-carteira da estratégia \(registro sem valor/);
    const j = sepoliaJson();
    delete (j.contracts as Partial<typeof j.contracts>).lpRegistry;
    delete (j.contracts as Partial<typeof j.contracts>).aspQuorum;
    expect(checkCanonical(parse(j))).toBe('canonical');
  });

  it('a start block later than the record\'s is refused (it would hide history); an earlier one reads more and passes', () => {
    expect(() => checkCanonical(parse({ ...sepoliaJson(), fromBlock: String(BigInt(sepolia.fromBlock) + 1n) }))).toThrow(/Bloco inicial/);
    expect(checkCanonical(parse({ ...sepoliaJson(), fromBlock: '1' }))).toBe('canonical');
  });
});

describe('a file for a chain without a canonical record (a local stack)', () => {
  it('is never used silently on a first use: it needs a confirmation, flagged as unpinned', () => {
    expect(assessDeployment(local(), undefined)).toEqual({ kind: 'confirm', pinned: 'unpinned', changes: [], hadAccepted: false });
  });

  it('once accepted, the same file is used without asking again', () => {
    const kv = new MemoryKeyValue();
    saveAccepted(kv, local());
    expect(assessDeployment(local(), loadAccepted(kv))).toEqual({ kind: 'use', pinned: 'unpinned' });
  });
});

describe('switching deployments', () => {
  it('a file that differs from the one accepted here asks first, and shows each change', () => {
    const kv = new MemoryKeyValue();
    saveAccepted(kv, local());
    const j = localJson();
    j.contracts.movvaPool = a(66);
    const moved = local(j);
    const v = assessDeployment(moved, loadAccepted(kv));
    expect(v).toMatchObject({ kind: 'confirm', pinned: 'unpinned', hadAccepted: true });
    expect(v.kind === 'confirm' && v.changes).toEqual([{ field: 'contracts.movvaPool', label: 'Pool Movva', before: a(6), after: a(66) }]);
  });

  it('even to the canonical deployment: from a local one, Sepolia is shown as a change before it is used', () => {
    const kv = new MemoryKeyValue();
    saveAccepted(kv, local());
    const v = assessDeployment(parse(sepoliaJson()), loadAccepted(kv));
    expect(v).toMatchObject({ kind: 'confirm', pinned: 'canonical', hadAccepted: true });
    expect(v.kind === 'confirm' && v.changes.map((c) => c.field)).toEqual(expect.arrayContaining(['chainId', 'contracts.movva', 'rpcUrl']));
  });

  it('the summary leaves the co-signer\'s API key out, and a garbled stored summary counts as none', () => {
    const j = sepoliaJson();
    (j.account.cosigner as { apiKey?: string }).apiKey = 'k'.repeat(48);
    expect(JSON.stringify(summarize(parse(j)))).not.toContain('kkkk');
    const kv = new MemoryKeyValue();
    kv.set('mova:deployment-accepted:v1', '{"chainId": 1}x');
    expect(loadAccepted(kv)).toBeUndefined();
    kv.set('mova:deployment-accepted:v1', '{"chainId": 1}');
    expect(loadAccepted(kv)).toBeUndefined();
    expect(diffSummaries({ a: '1' }, { a: '1' })).toEqual([]);
  });
});

describe('endpoints: https, except on this machine', () => {
  const withRpc = (rpcUrl: string, source = SOURCE) => () => parse({ ...sepoliaJson(), rpcUrl }, source);

  it('https anywhere, and http to localhost, 127.0.0.1 or ::1, are accepted', () => {
    expect(withRpc('https://rpc.example')().rpcUrl).toBe('https://rpc.example');
    for (const u of ['http://localhost:8545', 'http://127.0.0.1:8545', 'http://[::1]:8545']) expect(withRpc(u)().rpcUrl).toBe(u);
    expect(local().services.matcher).toBe('http://127.0.0.1:8981/m');
  });

  it('http to any other host is refused, naming the field, for every endpoint and for overrides', () => {
    expect(withRpc('http://rpc.example')).toThrow(new DeploymentInvalid('rpcUrl: use https (http://rpc.example/); http só é aceito em localhost ou 127.0.0.1'));
    expect(withRpc('http://192.168.0.10:8545')).toThrow(/rpcUrl: use https/);
    // A relative endpoint resolved against a plain-http host is refused the same way.
    expect(withRpc('/api/rpc', 'http://movva.example/api/deployment.json')).toThrow(/rpcUrl: use https \(http:\/\/movva.example\/api\/rpc\)/);
    for (const [path, set] of [
      ['services.matcher', (j: ReturnType<typeof sepoliaJson>) => { j.services.matcher = 'http://m.example'; }],
      ['services.lpNodes[0].url', (j: ReturnType<typeof sepoliaJson>) => { j.services.lpNodes[0]!.url = 'http://lp.example'; }],
      ['services.relayer', (j: ReturnType<typeof sepoliaJson>) => { j.services.relayer = 'http://r.example'; }],
      ['services.asp', (j: ReturnType<typeof sepoliaJson>) => { j.services.asp = 'http://a.example'; }],
      ['services.vault', (j: ReturnType<typeof sepoliaJson>) => { j.services.vault = 'http://v.example'; }],
      ['account.bundler', (j: ReturnType<typeof sepoliaJson>) => { j.account.bundler = 'http://b.example'; }],
      ['account.cosigner.url', (j: ReturnType<typeof sepoliaJson>) => { j.account.cosigner.url = 'http://c.example'; }],
    ] as const) {
      const j = sepoliaJson();
      set(j);
      expect(() => parse(j), path).toThrow(new RegExp(`${path.replace(/[[\].]/g, '\\$&')}: use https`));
    }
    expect(() => withOverrides(parse(sepoliaJson()), { cosigner: 'http://evil.example' })).toThrow(/cossignatário: use https/);
    expect(() => withOverrides(parse(sepoliaJson()), { rpcUrl: 'http://127.0.0.1:8545' })).not.toThrow();
  });
});

