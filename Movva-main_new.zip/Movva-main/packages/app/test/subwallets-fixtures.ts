import { subWalletKeysFromSeed } from '@mova/wallet';
import { parseDeployment } from '../src/lib/deployment.js';
import { MemoryKeyValue } from '../src/wallet/stores.js';
import { SubWalletManager, type SubSession } from '../src/wallet/subwallets.js';

export const addr = (n: number) => `0x${n.toString(16).padStart(40, '0')}` as `0x${string}`;
export const contracts = Object.fromEntries(['movva', 'reserve', 'onramp', 'offramp', 'entrypoint', 'movvaPool', 'saleVerifier', 'auditGrantRegistry'].map((k, i) => [k, addr(i + 1)]));
export const deployment = parseDeployment({
  version: 1, chainId: 31337, rpcUrl: '/api/rpc', fromBlock: '1', contracts,
  services: { matcher: '/m', lpNodes: [{ lp: addr(20), url: '/lp' }], relayer: '/r', asp: '/a', vault: '/v' },
}, 'http://127.0.0.1:8981/api/deployment.json');
export const primarySeed = new Uint8Array(32).fill(0x42);
export const primaryAddress = addr(0x99);
export const hex = (b: Uint8Array) => Array.from(b, (x) => x.toString(16).padStart(2, '0')).join('');

export function setup(kv = new MemoryKeyValue()) {
  const opened: Uint8Array[] = [];
  const shared: string[] = [];
  const mk = () => new SubWalletManager({
    kv, deployment, primarySeed, primaryAddress, now: () => 1_800_000_000,
    open: async (seed) => {
      opened.push(seed);
      const keys = subWalletKeysFromSeed(seed);
      const session = {
        address: keys.account.address, restoreOrFile: async () => ({ restored: false, positions: 2, notes: 1 }), ensureGas: async () => undefined,
        shareWithAuditor: async (r: { purpose: string }) => {
          shared.push(keys.id);
          return { share: { grants: [{ ledger: 'movva', grantId: `g-${keys.id.slice(0, 6)}`, bundle: { terms: { subject: keys.id, purpose: r.purpose } }, forVault: {} }], period: { fromTs: 1, toTs: 2 }, expiresAt: 99 } };
        },
      } as unknown as SubSession;
      return session;
    },
  });
  return { kv, mk, manager: mk(), opened, shared };
}

