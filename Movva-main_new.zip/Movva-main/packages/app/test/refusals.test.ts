import { describe, expect, it } from 'vitest';
import {
  AspRefused, BuyRefused, ExecutionFailed, LpNodeError, MovvaWalletRefused, PaymentRefused, ReshieldRefused, SaleRefused, type RefusalCode,
} from '@mova/wallet';
import { SeedSourceMismatchError, SeedUnavailableError } from '@mova/smart-account';
import { InputInvalid } from '../src/lib/format.js';
import { PasskeyUnavailable, PrfUnsupported } from '../src/passkey/seed.js';
import { RemoteServiceError } from '../src/wallet/remote.js';
import { StoreUnreadable } from '../src/wallet/stores.js';
import { SaleInterrupted, SaleKeyMissing } from '../src/wallet/sale-errors.js';
import { AlertsUnavailableHere } from '../src/wallet/alerts.js';
import { CoSignerRefused, SponsorshipNotGranted } from '@mova/cosigner/client';
import {
  COSIGNER_REFUSALS, PAYMENT_REFUSALS, RESHIELD_REFUSALS, SALE_REFUSALS, SPONSORSHIP_REFUSALS, describeError, unavailableReason,
} from '../src/lib/refusals.js';

/*
 * The tables are Record<RefusalCode, ...> and Record<SaleRefusalCode, ...>: a code the wallet adds without a sentence
 * here fails `tsc`. These tests check what the type cannot: the words.
 */
const ENGLISH = /\b(the|does not|refused|this order|wallet|cannot)\b/i;
const ORDER = '0x00000000000000000000000000000000000000000000000000000000000000aa' as const;

describe('payment refusals', () => {
  it('every code is explained in Portuguese', () => {
    const entries = Object.entries(PAYMENT_REFUSALS);
    expect(entries.length).toBeGreaterThanOrEqual(34);
    for (const [code, text] of entries) {
      expect(text.length, code).toBeGreaterThan(20);
      expect(text, code).not.toMatch(ENGLISH);
    }
  });

  it('says do not pay, why, and that cancelling is free while the order is locked', () => {
    const v = describeError(new PaymentRefused('pix_key_does_not_open_commitment', 'the PIX key does not open the commitment', ORDER, { action: 'cancelOrder', free: true }));
    expect(v.title).toBe('Não pague: as instruções não conferem');
    expect(v.detail).toBe(`${PAYMENT_REFUSALS.pix_key_does_not_open_commitment} O que fazer: cancele o pedido. Enquanto ele está travado, cancelar é gratuito e nada foi cobrado.`);
    expect(v).toMatchObject({ tone: 'danger', code: 'pix_key_does_not_open_commitment', action: 'cancelOrder', actionLabel: 'Cancelar pedido (gratuito)' });
    expect(v.technical).toBe('the PIX key does not open the commitment');
  });

  it('no suggestion, no cancel button: the order is no longer locked', () => {
    const v = describeError(new PaymentRefused('pay_window_closed' satisfies RefusalCode, 'x', ORDER));
    expect(v.action).toBeUndefined();
    expect(v.detail).toBe(PAYMENT_REFUSALS.pay_window_closed);
  });

  it('a dynamic PIX charge says why the browser does not take it', () => {
    expect(PAYMENT_REFUSALS.pix_location_host_not_allowed).toContain('o provedor precisa oferecer um código PIX estático');
  });
});

describe('sale refusals', () => {
  it('every code has a title and an explanation in Portuguese', () => {
    for (const [code, r] of Object.entries(SALE_REFUSALS)) {
      expect(r.title.length, code).toBeGreaterThan(5);
      expect(`${r.title} ${r.detail}`, code).not.toMatch(ENGLISH);
    }
  });

  it('an overdue bill: why no LP pays it, and what to do', () => {
    const v = describeError(new SaleRefused('the bill was due 2026-09-10', 'boleto_overdue'));
    expect(v.title).toBe('Boleto vencido');
    expect(v.detail).toBe('O vencimento já passou (horário de Brasília). Pago com atraso, o boleto custa mais do que diz, e nenhum provedor paga boleto vencido. Peça ao emissor um boleto atualizado.');
  });

  it('a bill with no due date, and a collection bill', () => {
    expect(describeError(new SaleRefused('x', 'boleto_no_due_date')).title).toBe('Boleto sem vencimento');
    expect(describeError(new SaleRefused('x', 'boleto_no_due_date')).detail).toContain('(fator 0000)');
    expect(describeError(new SaleRefused('x', 'boleto_collection')).title).toBe('Guia de arrecadação');
  });

  it('retryable refusals offer to try again', () => {
    expect(describeError(new SaleRefused('x', 'no_price'))).toMatchObject({ action: 'retry', actionLabel: 'Tentar de novo' });
  });
});

describe('putting Movva back, and sales that stop half-way', () => {
  it('every re-shield refusal has its own Portuguese sentence', () => {
    const entries = Object.entries(RESHIELD_REFUSALS);
    expect(entries.length).toBeGreaterThanOrEqual(5);
    for (const [code, r] of entries) {
      expect(r!.title.length, code).toBeGreaterThan(5);
      expect(`${r!.title} ${r!.detail}`, code).not.toMatch(ENGLISH);
    }
  });

  it('under the pool minimum: the wallet\'s own figures, in Portuguese', () => {
    const v = describeError(new ReshieldRefused('R$ 0,50 of Movva is under the pool\'s minimum deposit of R$ 1,00: the Entrypoint would refuse it', 'reshield_below_minimum'));
    expect(v).toMatchObject({ tone: 'danger', title: 'Valor abaixo do mínimo do pool', code: 'reshield_below_minimum' });
    expect(v.detail).toBe('São R$ 0,50 em Movva, abaixo do depósito mínimo do pool, de R$ 1,00: o pool recusaria o depósito. Nada foi enviado, e os Movva continuam na conta.');
    expect(v.technical).toContain('minimum deposit');
  });

  it('a re-shield speaks of the deposit, a sale of the sale', () => {
    expect(describeError(new ReshieldRefused('x', 'pool_mismatch')).detail).toContain('o depósito cairia onde a carteira não procura');
    expect(describeError(new SaleRefused('x', 'pool_mismatch')).detail).toContain('Nada foi vendido');
    expect(describeError(new ReshieldRefused('x', 'exit_pending'))).toMatchObject({ title: 'Aguardando o relayer', action: 'wait' });
    expect(describeError(new ReshieldRefused('x', 'no_pending_sale')).title).toBe(SALE_REFUSALS.no_pending_sale.title);
  });

  it('a sale larger than a note: allow several notes; larger than several: sell less', () => {
    expect(describeError(new SaleRefused('a sale is funded from one note, and your largest note is smaller than that', 'note_too_small')).detail).toContain('permita usar várias notas');
    expect(describeError(new SaleRefused('a sale is funded from at most 8 notes here, and your 8 largest do not add up to that; sell less at once', 'note_too_small')).detail)
      .toBe('Nem somando até 8 notas do seu saldo o valor fecha. Venda um valor menor.');
    expect(describeError(new SaleRefused('x', 'boleto_due_today_too_late')).title).toBe('Boleto vence hoje e já é tarde');
  });

  it('a sale interrupted after its exit: why, where to go on, and no "try again", which would start a second sale', () => {
    const v = describeError(new SaleInterrupted('pending:0a', new ExecutionFailed('eth_sendUserOperation: dev-stack fault')));
    expect(v).toMatchObject({ tone: 'warn', title: 'Venda interrompida', technical: 'eth_sendUserOperation: dev-stack fault' });
    expect(v.detail).toBe('A venda parou depois que a saída do seu saldo foi enviada (operação não enviada). Nada se perde e nada é repetido sem você: continue ou cancele esta venda em Vendas em andamento.');
    expect(v.action).toBeUndefined();
    const refused = describeError(new SaleInterrupted('pending:0a', new SaleRefused('x', 'chain_mismatch')));
    expect(refused).toMatchObject({ code: 'chain_mismatch' });
    expect(refused.detail).toContain('(a blockchain não confirma a venda)');
  });

  it('a sale account whose key this device does not hold, and an operation the bundler did not take', () => {
    expect(describeError(new SaleKeyMissing('0x01')).title).toBe('Chave da conta da venda ausente');
    expect(describeError(new ExecutionFailed('eth_sendUserOperation: AA21 didn\'t pay prefund'))).toMatchObject({ title: 'Operação não enviada', action: 'retry' });
    expect(describeError(new ExecutionFailed('the UserOperation was included, but its calls reverted')).title).toBe('Transação revertida');
  });
});

describe('the co-signer\'s sponsorship and recovery alerts', () => {
  const NEW_CODES = ['sponsorship_disabled', 'alerts_disabled', 'proof_expired', 'push_endpoint_refused', 'recovery_pending', 'subscription_unknown', 'too_many_subscriptions'];
  const ACCOUNT = '0x00000000000000000000000000000000000000aa' as const;

  it('every new co-signer refusal has its own sentence in Portuguese', () => {
    for (const code of NEW_CODES) {
      const v = describeError(new CoSignerRefused(409, code, 'x'));
      expect(COSIGNER_REFUSALS[code], code).toBeDefined();
      expect(v, code).toMatchObject({ code, title: COSIGNER_REFUSALS[code]!.title, detail: COSIGNER_REFUSALS[code]!.detail });
      expect(`${v.title} ${v.detail}`, code).not.toMatch(ENGLISH);
    }
    expect(describeError(new CoSignerRefused(409, 'recovery_pending', 'x')).detail).toContain('Vete a recuperação no Início');
    expect(describeError(new CoSignerRefused(401, 'proof_expired', 'x'))).toMatchObject({ action: 'retry', actionLabel: 'Tentar de novo' });
  });

  it('an account the co-signer did not sponsor: why, nothing sent, and a retry only when it may pass', () => {
    const later = describeError(new SponsorshipNotGranted({ chainId: 1, account: ACCOUNT, status: 'refused', code: 'daily_cap', retryable: true }));
    expect(later).toMatchObject({ tone: 'danger', title: 'Conta não patrocinada', code: 'daily_cap', action: 'retry', actionLabel: 'Tentar de novo' });
    expect(later.detail).toBe(`${SPONSORSHIP_REFUSALS.daily_cap!.detail} Nada foi enviado.`);
    expect(describeError(new SponsorshipNotGranted({ chainId: 1, account: ACCOUNT, status: 'refused', code: 'sponsorship_revoked', retryable: false })).action).toBeUndefined();
    expect(describeError(new SponsorshipNotGranted({ chainId: 1, account: ACCOUNT, status: 'pending', message: 'still pending when the wait ran out' })).action).toBe('retry');
    for (const [code, r] of Object.entries(SPONSORSHIP_REFUSALS)) expect(r.detail, code).not.toMatch(ENGLISH);
  });

  it('alerts this device cannot receive, said why', () => {
    expect(describeError(new AlertsUnavailableHere('browser'))).toMatchObject({ title: 'Alertas indisponíveis aqui', detail: expect.stringContaining('notificações push') });
    expect(describeError(new AlertsUnavailableHere('cosigner')).detail).toBe(COSIGNER_REFUSALS.alerts_disabled!.detail);
  });
});

describe('everything else the wallet throws', () => {
  it('the LP node still preparing a boleto or a charge is a wait, not an error', () => {
    expect(describeError(new LpNodeError(409, 'LP node /v1/onramp/instructions: 409 boleto not issued yet'))).toMatchObject({ tone: 'info', action: 'wait', title: 'Aguardando o provedor' });
  });

  it('a cap the provider holds is final, not a wait, and says what happens to the money', () => {
    const buy = describeError(new LpNodeError(409, 'LP node /v1/onramp/instructions: 409 cap_reached', 'cap_reached'));
    expect(buy).toMatchObject({ tone: 'warn', code: 'cap_reached', title: 'Este parceiro não vai concluir a compra' });
    expect(buy.action).toBeUndefined();
    expect(buy.detail).toContain('devolvido por Pix');
    expect(buy.detail).not.toMatch(/R\$/); // the node never tells the wallet the limit or the total
    const sale = describeError(new LpNodeError(409, 'LP node /v1/offramp/payee: 409 cap_reached', 'cap_reached'));
    expect(sale.title).toBe('Este parceiro não vai receber esta venda');
    expect(sale.detail).toContain('Nada saiu do seu saldo');
    const unknown = describeError(new LpNodeError(409, 'LP node /v1/onramp/instructions: 409 payer_unidentified', 'payer_unidentified'));
    expect(unknown.detail).toContain('não identificou quem pagou');
  });

  it('buying under partial backing', () => {
    const v = describeError(new MovvaWalletRefused('Movva is 97,20% backed right now; buying at R$ 1,00 would pay for backing that is not there'));
    expect(v.title).toBe('Compras suspensas: lastro parcial');
    expect(v.detail).toContain('O Movva está com lastro de 97,20% agora.');
  });

  it('taking delivery in the open, refused: only the rescue address, and only while the order waits', () => {
    expect(describeError(new BuyRefused('only the rescue address named at lock can take delivery')).title).toBe('Entrega fora do saldo recusada');
    const expired = describeError(new BuyRefused('the quote has expired; quote again'));
    expect([expired.title, expired.action, expired.actionLabel]).toEqual(['Cotação expirada', 'retry', 'Cotar de novo']);
    expect(describeError(new BuyRefused('only a shielded order that is locked or disputed can switch to direct delivery')).detail).toContain('pode já ter sido liberado');
  });

  it('a note the ASP has not approved yet', () => {
    expect(describeError(new AspRefused('the ASP has not approved this note, so the pool would refuse the withdrawal'))).toMatchObject({ title: 'Aguardando aprovação', action: 'retry' });
  });

  it('a form field', () => {
    expect(describeError(new InputInvalid('Período inválido', 'O início precisa ser anterior ao fim.'))).toMatchObject({ title: 'Período inválido', tone: 'warn' });
  });

  it('opening the wallet: matched by class, not by name, which a production build minifies away', () => {
    // A production bundle renames `class SeedUnavailableError` to something like `class lo`, and it sets no `name`.
    class lo extends SeedUnavailableError {}
    class Bh extends PrfUnsupported {}
    expect(describeError(new lo('webauthn-prf', 'no configured seed source can produce a seed on this device')))
      .toMatchObject({ title: 'Não foi possível abrir a carteira', detail: expect.stringContaining('extensão PRF') });
    // No PRF, no wallet: no sentence offers another way in (the recovery-code path is gone, audit H-03).
    for (const v of [describeError(new lo('webauthn-prf', 'x')), describeError(new Bh('x')), describeError(new SeedSourceMismatchError('webauthn-prf', 'split-share'))]) {
      expect(v.detail).not.toMatch(/código de recuperação|servidor de partes/);
    }
    expect(describeError(new Bh('x'))).toMatchObject({ title: 'Passkey sem PRF', detail: expect.stringContaining('Use outro navegador ou aparelho') });
    expect(describeError(new SeedSourceMismatchError('webauthn-prf', 'split-share')).title).toBe('Outra origem de chave');
    expect(describeError(new PasskeyUnavailable('A passkey não foi criada.'))).toMatchObject({ title: 'Passkey indisponível', detail: 'A passkey não foi criada.' });
    expect(describeError(new StoreUnreadable('x')).title).toBe('Dados locais ilegíveis');
    expect(describeError(new RemoteServiceError('relayer', 502, 'x')).title).toBe('Serviço indisponível');
    expect(describeError(new DOMException('The operation either timed out or was not allowed.', 'NotAllowedError')).title).toBe('Passkey não confirmada');
    // An error that merely calls itself one of ours is not.
    expect(describeError(Object.assign(new Error('x'), { name: 'SeedUnavailableError' })).title).toBe('Algo deu errado');
  });

  it('anything unknown: a plain sentence, with the message kept for the details', () => {
    expect(describeError(new Error('boom'))).toMatchObject({ title: 'Algo deu errado', technical: 'boom' });
  });

  it('why a rail could not be quoted', () => {
    expect(unavailableReason('no liquidity on the requested rails right now')).toBe('Sem liquidez neste meio de pagamento agora.');
    expect(unavailableReason('something new')).toBe('Indisponível no momento.');
  });
});
