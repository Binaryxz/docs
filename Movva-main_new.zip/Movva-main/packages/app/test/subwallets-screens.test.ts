// @vitest-environment happy-dom
/** The sub-wallet screens, rendered over a real manager with fake sessions: what is said, and what is (not) kept on screen. */
import { act, createElement, type ReactElement } from 'react';
import { createRoot, type Root } from 'react-dom/client';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { newSubWalletPhrase } from '@mova/wallet';
import { COMPLETENESS_OPEN, LOST_SEED_WARNING, NO_MOVES_V2, SubWallets } from '../src/ui/SubWallets.js';
import { setup } from './subwallets-fixtures.js';

(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

let mounted: Root | undefined;
afterEach(() => { act(() => mounted?.unmount()); mounted = undefined; document.body.innerHTML = ''; });

async function render(element: ReactElement): Promise<HTMLElement> {
  const host = document.createElement('div');
  document.body.appendChild(host);
  mounted = createRoot(host);
  await act(async () => { mounted!.render(element); });
  return host;
}
const settle = () => act(async () => { await new Promise((r) => setTimeout(r, 5)); });
const click = async (el: Element | null | undefined) => { if (!el) throw new Error('nothing to click'); await act(async () => { (el as HTMLElement).click(); }); await settle(); };
async function type(el: Element | null | undefined, value: string) {
  if (!el) throw new Error('nothing to type into');
  const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
  await act(async () => { Object.getOwnPropertyDescriptor(proto, 'value')!.set!.call(el, value); el.dispatchEvent(new Event('input', { bubbles: true })); });
}
const button = (host: HTMLElement, text: string) => [...host.querySelectorAll('button')].find((b) => b.textContent?.includes(text));
const field = (host: HTMLElement, label: string) => [...host.querySelectorAll('label.field')].find((l) => l.textContent?.includes(label))?.querySelector('input, textarea, select');

const NOW = 1_800_000_000;
const screen = (m: ReturnType<typeof setup>['manager'], onSwitch = vi.fn(), activeId?: string) =>
  createElement(SubWallets, { manager: m, activeId, onSwitch, now: NOW });

describe('create a sub-wallet', () => {
  it('says a lost seed is a lost sub-wallet, shows the phrase once, asks for words back, and then keeps no phrase on screen', async () => {
    const { manager } = setup();
    const host = await render(screen(manager));
    await click(button(host, 'Criar'));
    expect(host.textContent).toContain(LOST_SEED_WARNING);
    expect(host.textContent).toContain('perde esta sub-carteira');
    await type(field(host, 'Nome da sub-carteira'), 'Reserva');
    await click(button(host, 'Gerar a frase'));
    const words = [...host.querySelectorAll('[data-testid=seed-words] li')].map((li) => li.textContent!);
    expect(words).toHaveLength(12);
    expect(host.textContent).toContain('uma única vez');
    await click(button(host, 'Anotei'));
    // The words are gone from the screen; only the positions asked remain.
    expect(host.querySelector('[data-testid=seed-words]')).toBeNull();
    const labels = [...host.querySelectorAll('label.field span')].map((s) => s.textContent!).filter((t) => t.startsWith('Palavra nº'));
    expect(labels).toHaveLength(3);
    const positions = labels.map((l) => Number(l.replace('Palavra nº ', '')));
    const inputs = [...host.querySelectorAll('label.field')].filter((l) => l.textContent?.startsWith('Palavra nº')).map((l) => l.querySelector('input'));
    // Wrong words: refused, nothing created.
    for (const i of inputs) await type(i, 'errado');
    await click(button(host, 'Confirmar e criar'));
    expect(host.textContent).toContain('não conferem');
    expect(manager.list()).toEqual([]);
    // Right words.
    for (const [k, i] of inputs.entries()) await type(i, words[positions[k] - 1]);
    await click(button(host, 'Confirmar e criar'));
    expect(manager.list().map((v) => v.label)).toEqual(['Reserva']);
    expect(host.textContent).toContain('Sub-carteira criada');
    expect(host.textContent).toContain('só no seu papel');
    for (const w of new Set(words)) if (w.length > 5) expect(host.textContent!.includes(` ${w} `)).toBe(false);
  }, 30_000);

  it('refuses a name left empty', async () => {
    const { manager } = setup();
    const host = await render(screen(manager));
    await click(button(host, 'Criar'));
    await click(button(host, 'Gerar a frase'));
    expect(host.textContent).toContain('Dê um nome');
    expect(host.querySelector('[data-testid=seed-words]')).toBeNull();
  });
});

describe('list, switch and restore', () => {
  it('lists the primary and the sub-wallets, and switches to one', async () => {
    const { manager } = setup();
    const d = manager.draft(); const w = d.phrase.split(' ');
    await manager.create('Viagem', d.positions.map((p) => w[p - 1]));
    const onSwitch = vi.fn();
    const host = await render(screen(manager, onSwitch));
    expect(host.textContent).toContain('Carteira principal');
    expect(host.textContent).toContain('Em uso');
    expect(host.querySelectorAll('[data-testid=subwallet]')).toHaveLength(1);
    expect(host.textContent).toContain(NO_MOVES_V2);
    await click(button(host, 'Usar esta sub-carteira'));
    expect(onSwitch).toHaveBeenCalledWith(manager.list()[0].id);
  });

  it('restores from a phrase, and refuses a bad one in Portuguese', async () => {
    const { manager } = setup();
    const host = await render(screen(manager));
    await click(button(host, 'Restaurar'));
    await type(field(host, 'Nome'), 'Antiga');
    await type(field(host, 'Frase de 12 ou 24 palavras'), 'uma frase que não é válida');
    await click(host.querySelector('[data-testid=restore-subwallet] button[type=submit]'));
    expect(host.textContent).toContain('a frase não é válida');
    await type(field(host, 'Frase de 12 ou 24 palavras'), newSubWalletPhrase());
    await click(host.querySelector('[data-testid=restore-subwallet] button[type=submit]'));
    expect(host.textContent).toContain('2 posição(ões) reencontrada(s)');
    expect(manager.list().map((v) => v.label)).toEqual(['Antiga']);
  }, 30_000);
});

describe('compartilhar com o auditor', () => {
  it('shares only the selected sub-wallets, in one package, and says what the package cannot prove', async () => {
    const { manager, shared } = setup();
    const ids: string[] = [];
    for (const name of ['A', 'B', 'C']) {
      const d = manager.draft(); const w = d.phrase.split(' ');
      ids.push((await manager.create(name, d.positions.map((p) => w[p - 1]))).id);
    }
    const host = await render(screen(manager));
    await click(button(host, 'Auditor'));
    expect(host.textContent).toContain(COMPLETENESS_OPEN);
    await click(host.querySelector('[data-testid=share-subwallets] button[type=submit]'));
    expect(host.textContent).toContain('Escolha as sub-carteiras');
    await click(host.querySelector('input[aria-label=A]'));
    await click(host.querySelector('input[aria-label=C]'));
    await type(field(host, 'Chave pública do auditor'), 'cd'.repeat(32));
    await click(host.querySelector('[data-testid=share-subwallets] button[type=submit]'));
    expect(shared).toEqual([ids[0], ids[2]]);
    expect(host.textContent).toContain('2 sub-carteira(s) em um só pacote');
    expect(button(host, 'Baixar pacote do auditor')).toBeDefined();
  }, 30_000);
});
