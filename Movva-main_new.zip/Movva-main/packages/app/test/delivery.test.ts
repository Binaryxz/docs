/**
 * The delivery escape hatch in Portuguese (src/lib/delivery.ts): each reason a shielded delivery would be refused, with its
 * figures, what to do, the one-sentence privacy cost of taking the Movva in the open, and which orders to show. The reads
 * themselves are test/delivery-check.test.ts.
 */
import { describe, expect, it } from 'vitest';
import { reais } from '@mova/wallet';
import { DELIVERY_BLOCKED_EXPLAINED, DIRECT_DELIVERY_COST, blockedDeliveries, deliveryBlockText, type DeliveryBlock } from '../src/lib/delivery.js';
import type { OrderActivity } from '../src/wallet/port.js';

const addr = (n: number) => `0x${n.toString(16).padStart(40, '0')}` as `0x${string}`;
const hash = (n: number) => `0x${n.toString(16).padStart(64, '0')}` as `0x${string}`;
const M = 10n ** 18n;
const ENGLISH = /\b(the|does not|refused|this order|wallet|cannot)\b/i;

describe('said in Portuguese', () => {
  it('each reason, with the figures in reais', () => {
    expect(deliveryBlockText({ kind: 'below_pool_minimum', minimum: 1_000_000n * M, amount: 29_850n * 10n ** 15n }))
      .toBe('O pool de Movva exige agora um depósito mínimo de R$ 1.000.000,00, acima dos R$ 29,85 em Movva a depositar: o depósito seria recusado.');
    // A minimum between two centavos is never shown under what it is.
    expect(deliveryBlockText({ kind: 'below_pool_minimum', minimum: M + 1n, amount: M })).toContain('mínimo de R$ 1,01');
    expect(deliveryBlockText({ kind: 'frozen', party: 'entrypoint' }))
      .toBe('O emissor do token bloqueou o Entrypoint do Privacy Pools: o depósito seria recusado, ou os Movva ficariam congelados no pool.');
    const all: DeliveryBlock[] = [
      { kind: 'pool_not_registered' }, { kind: 'pool_changed', pool: addr(1) }, { kind: 'pool_wound_down' },
      { kind: 'below_pool_minimum', minimum: M, amount: 1n }, { kind: 'frozen', party: 'account' },
    ];
    for (const b of all) expect(deliveryBlockText(b), b.kind).not.toMatch(ENGLISH);
    expect(DELIVERY_BLOCKED_EXPLAINED).toContain('Se você ainda não pagou, não pague');
  });

  it('the privacy cost of taking delivery in the open, in one sentence', () => {
    expect(DIRECT_DELIVERY_COST.endsWith('.')).toBe(true);
    expect(DIRECT_DELIVERY_COST.slice(0, -1)).not.toMatch(/[.!?]\s/);
    expect(DIRECT_DELIVERY_COST).toContain('visíveis na blockchain como seus');
  });
});

describe('orders to show', () => {
  it('only orders waiting to be released whose shielded delivery is blocked', () => {
    const order = (n: number, delivery?: OrderActivity['delivery']): OrderActivity => ({
      orderId: hash(n), rail: 'pix', amount: 3_000n, createdAt: 0, payBy: 0,
      status: { orderId: hash(n), amount: reais(3_000n), formatted: 'R$ 30,00', state: 'awaiting_payment', payBy: 0 }, ...(delivery ? { delivery } : {}),
    });
    const below: DeliveryBlock = { kind: 'below_pool_minimum', minimum: 1_000_000n * M, amount: 30n * M };
    const shown = blockedDeliveries([
      order(1, { pending: true, delivery: 'shielded', blocks: [below], directRefused: false }),
      order(2, { pending: true, delivery: 'shielded', blocks: [], directRefused: false }),
      order(3, { pending: true, delivery: 'direct', blocks: [], directRefused: false }),
      order(4, { pending: false, delivery: 'shielded', blocks: [below], directRefused: false }),
      order(5),
    ]);
    expect(shown.map((o) => o.orderId)).toEqual([hash(1)]);
  });
});
