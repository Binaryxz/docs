/**
 * The state logic behind sales in progress, Movva in the open and a balance awaiting approval (src/lib/pending.ts): what
 * each stage says, which buttons it offers - none while an exit may still land, or while a call on it is running - what
 * resuming came to, and the figures.
 */
import { describe, expect, it } from 'vitest';
import { reais, type MovvaBalance, type Reshielded, type ResumedSale } from '@mova/wallet';
import {
  AWAITING_APPROVAL_EXPLAINED, DELIVERY_RESHIELD_VISIBLE, SEVERAL_NOTES_COST, balanceFigures, givenUpReason, inTheOpen, pendingSaleView,
  reshieldedView, resumeOutcomeView,
} from '../src/lib/pending.js';
import type { OrderActivity, PendingSaleItem, ReshieldActivity, SaleActivity } from '../src/wallet/port.js';

const addr = (n: number) => `0x${n.toString(16).padStart(40, '0')}` as `0x${string}`;
const hash = (n: number) => `0x${n.toString(16).padStart(64, '0')}` as `0x${string}`;
const NOW = Date.parse('2026-09-14T15:00:00Z') / 1000;

const sale = (over: Partial<PendingSaleItem> = {}): PendingSaleItem => ({
  id: 'pending:0a', account: addr(7), stage: 'exited', rail: 'pix', receive: reais(990n), receiveFormatted: 'R$ 9,90',
  exited: reais(1_000n), exitedFormatted: 'R$ 10,00', notes: 1, createdAt: NOW, payee: '+5511987654321', ...over,
});

const figure = (v: ReturnType<typeof pendingSaleView>, label: string) => v.figures.find((f) => f.label === label)?.value;

describe('a sale in progress', () => {
  it('stopped between its exit and openSale: what happened, what is left, how much, and both ways on', () => {
    const v = pendingSaleView(sale());
    expect(v.title).toBe('Venda por PIX · R$ 9,90');
    expect(v.badge).toEqual({ label: 'Venda não aberta', tone: 'warn' });
    expect(v.happened).toBe('Os Movva saíram do seu saldo para a conta desta venda, mas a venda não chegou a ser aberta.');
    expect(v.left).toBe('Falta abrir a venda e enviar o destinatário aos provedores.');
    expect(figure(v, 'Chega por PIX')).toBe('R$ 9,90');
    expect(figure(v, 'Já saiu do seu saldo')).toBe('R$ 10,00');
    expect(figure(v, 'Iniciada em')).toBe('14/09/2026 às 12:00');
    expect(figure(v, 'Notas usadas')).toBeUndefined();
    expect(v.actions).toEqual(['continue', 'cancel']);
  });

  it('an openSale not seen, an open sale no LP node accepted, and an exit not yet seen each say what the device knows', () => {
    const opening = pendingSaleView(sale({ stage: 'opening' }));
    expect(opening.badge.label).toBe('Abertura não confirmada');
    expect(opening.left).toContain('para nunca abrir duas');
    expect(opening.actions).toEqual(['continue', 'cancel']);
    const open = pendingSaleView(sale({ stage: 'open', saleId: hash(1) }));
    expect(open.badge.label).toBe('Sem provedor');
    expect(open.happened).toContain('nenhum provedor recebeu o destinatário');
    const exiting = pendingSaleView(sale({ stage: 'exiting', exited: reais(0n), exitedFormatted: 'R$ 0,00' }));
    expect(figure(exiting, 'Já saiu do seu saldo')).toBe('nada confirmado ainda');
    expect(exiting.left).toContain('uma saída que ainda pode entrar nunca é enviada de novo');
    expect(exiting.actions).toEqual(['continue', 'cancel']);
  });

  it('an exit still with the relayer: "Aguardando o relayer", and no button while it may land', () => {
    for (const intent of ['continue', 'cancel'] as const) {
      const v = pendingSaleView(sale({ stage: 'exiting', waitingForRelayer: intent }));
      expect(v.badge).toEqual({ label: 'Aguardando o relayer', tone: 'info' });
      expect(v.actions).toEqual([]);
      expect(v.left).toContain('Nada é enviado de novo enquanto isso.');
    }
    expect(pendingSaleView(sale({ waitingForRelayer: 'continue' })).left).toContain('continua a venda');
    expect(pendingSaleView(sale({ waitingForRelayer: 'cancel' })).left).toContain('devolve ao saldo');
  });

  it('a sale being made or resumed on this device offers nothing until that call returns', () => {
    const v = pendingSaleView(sale({ busy: true, waitingForRelayer: 'continue' }));
    expect(v.actions).toEqual([]);
    expect(v.badge.label).toBe('Em andamento');
  });

  it('given up: only "Devolver ao saldo protegido", with the reason in words', () => {
    const v = pendingSaleView(sale({ stage: 'reshielding', givenUp: 'price_moved' }));
    expect(v.actions).toEqual(['reshield']);
    expect(v.badge.label).toBe('Voltando ao saldo');
    expect(v.happened).toBe('A venda foi desfeita: o preço mudou. Os Movva ainda não voltaram ao saldo protegido.');
    expect(givenUpReason('cancelled')).toBe('você cancelou');
    expect(givenUpReason('boleto_due_today_too_late')).toBe('boleto vence hoje e já é tarde');
  });

  it('a bill: its amount and due date; a sale across notes counts them', () => {
    const v = pendingSaleView(sale({ rail: 'boleto', dueDate: '2026-09-24', notes: 2 }));
    expect(v.title).toBe('Pagamento de boleto · R$ 9,90');
    expect(figure(v, 'Valor do boleto')).toBe('R$ 9,90');
    expect(figure(v, 'Vencimento')).toBe('24/09/2026');
    expect(figure(v, 'Notas usadas')).toBe('2');
  });
});

describe('what resuming came to', () => {
  const s = sale();
  const reshielded: Reshielded = {
    source: 'sale_account', from: addr(7), amount: reais(994n), formatted: 'R$ 9,94', fee: reais(1n), feeFormatted: 'R$ 0,01',
    transactionHash: hash(2), awaitingApproval: true,
  };
  const view = (out: ResumedSale) => resumeOutcomeView(out, s);

  it('open, and to how many LP nodes; claimed, paid, abandoned; waiting for the relayer says it on the sale itself', () => {
    expect(view({ id: s.id, state: 'exit_pending' })).toBeUndefined();
    expect(view({ id: s.id, state: 'open', saleId: hash(1), disclosedTo: 1 }))
      .toEqual({ tone: 'ok', title: 'Venda aberta', detail: 'A venda de R$ 9,90 está aberta, e um provedor recebeu o destinatário. Acompanhe em Vender.' });
    expect(view({ id: s.id, state: 'open', saleId: hash(1), disclosedTo: 2 })!.detail).toContain('2 provedores receberam');
    expect(view({ id: s.id, state: 'open', saleId: hash(1), disclosedTo: 0 })).toMatchObject({ tone: 'warn', title: 'Venda aberta, sem provedor' });
    expect(view({ id: s.id, state: 'abandoned' })!.detail).toContain('o seu saldo não mudou');
    expect(view({ id: s.id, state: 'settled', saleId: hash(1) })!.title).toBe('PIX enviado');
    expect(resumeOutcomeView({ id: s.id, state: 'settled', saleId: hash(1) }, { ...s, rail: 'boleto' })!.title).toBe('Boleto pago');
    expect(view({ id: s.id, state: 'claimed', saleId: hash(1) })!.title).toBe('Um provedor já está pagando');
  });

  it('put back: how much, the pool fee, and that it cannot be spent until the ASP approves it', () => {
    expect(view({ id: s.id, state: 'reshielded', reason: 'cancelled', reshielded })).toEqual({
      tone: 'ok', title: 'Devolvido ao saldo protegido',
      detail: 'R$ 9,94 voltaram ao saldo protegido (taxa do pool: R$ 0,01). Até a ASP aprovar o depósito, esse valor aparece como aguardando aprovação e não pode ser vendido.',
    });
    expect(reshieldedView({ ...reshielded, awaitingApproval: false }).detail).toBe('R$ 9,94 voltaram ao saldo protegido (taxa do pool: R$ 0,01).');
  });
});

describe('the balance', () => {
  const base: MovvaBalance = {
    total: reais(3_000n), totalFormatted: 'R$ 30,00', available: reais(3_000n), availableFormatted: 'R$ 30,00',
    backing: { status: 'full', collateralRatioBps: 10_235n, rateUpdatedAt: NOW, marketClosed: false }, atParHolds: true, valuedAt: NOW,
  };

  it('with nothing pending, available is the wallet\'s own figure', () => {
    expect(balanceFigures(base)).toEqual({ spendableFormatted: 'R$ 30,00' });
  });

  it('a re-shielded note awaiting approval, apart from what can be spent; sales in progress beside it', () => {
    const b = { ...base, pending: { awaitingApproval: reais(994n), awaitingApprovalFormatted: 'R$ 9,94', salesInProgress: 1, inSales: reais(1_000n), inSalesFormatted: 'R$ 10,00' } };
    expect(balanceFigures(b)).toEqual({ spendableFormatted: 'R$ 20,06', awaitingApproval: 'R$ 9,94', inSales: { formatted: 'R$ 10,00', count: 1 } });
    const onlySales = { ...base, pending: { awaitingApproval: reais(0n), awaitingApprovalFormatted: 'R$ 0,00', salesInProgress: 2, inSales: reais(1_500n), inSalesFormatted: 'R$ 15,00' } };
    expect(balanceFigures(onlySales)).toEqual({ spendableFormatted: 'R$ 30,00', inSales: { formatted: 'R$ 15,00', count: 2 } });
    expect(AWAITING_APPROVAL_EXPLAINED).toContain('a prova é feita contra a raiz que a ASP publica');
  });
});

describe('Movva in the open', () => {
  it('deliveries taken in the open and cancelled sales, until put back; a sale in progress is left to its own card', () => {
    const order = (n: number, state: 'delivered_in_the_open' | 'cancelled'): OrderActivity => ({
      orderId: hash(n), rail: 'pix', amount: 5_000n, createdAt: NOW, payBy: NOW,
      status: state === 'cancelled'
        ? { orderId: hash(n), amount: reais(5_000n), formatted: 'R$ 50,00', state }
        : { orderId: hash(n), amount: reais(5_000n), formatted: 'R$ 50,00', state, to: addr(9) },
    });
    const recorded = (n: number, state: 'cancelled' | 'settled'): SaleActivity => ({
      saleId: hash(n), rail: 'pix', receive: 990n, cost: 1_000n, fee: 10n, account: addr(7), payee: '+5511987654321', disclosedTo: 1, createdAt: NOW,
      status: { saleId: hash(n), receive: reais(990n), formatted: 'R$ 9,90', rail: 'pix', state },
    });
    const putBack = (ref: string): ReshieldActivity => ({
      source: 'sale_account', ref, amount: 994n, fee: 1n, from: addr(7), transactionHash: hash(99), awaitingApproval: false, createdAt: NOW,
    });
    const open = inTheOpen({
      orders: [order(1, 'delivered_in_the_open'), order(2, 'delivered_in_the_open'), order(3, 'cancelled')],
      sales: [recorded(11, 'cancelled'), recorded(12, 'cancelled'), recorded(13, 'settled'), recorded(14, 'cancelled')],
      reshields: [putBack(hash(2)), putBack(hash(12).toUpperCase().replace('0X', '0x'))],
      pending: [sale({ stage: 'reshielding', saleId: hash(14) })],
    });
    expect(open.orders.map((o) => o.orderId)).toEqual([hash(1)]);
    expect(open.sales.map((s) => s.saleId)).toEqual([hash(11)]);
  });
});

describe('said in one sentence', () => {
  it('the privacy cost of several notes, and that a delivery\'s deposit is the user\'s own', () => {
    for (const s of [SEVERAL_NOTES_COST, DELIVERY_RESHIELD_VISIBLE]) {
      expect(s.endsWith('.')).toBe(true);
      expect(s.slice(0, -1)).not.toMatch(/[.!?]\s/);
    }
    expect(SEVERAL_NOTES_COST).toContain('são de uma mesma pessoa');
    expect(DELIVERY_RESHIELD_VISIBLE).toContain('visível na blockchain como seu');
  });
});
