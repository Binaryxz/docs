/**
 * The app's account against either paymaster (src/wallet/account.ts, `accountPaymaster`): SponsorPaymaster's fixed
 * bytes and allowlist, or OwnerlessPaymaster's data built per operation from what the contract reports (SRM1-17).
 */
import { describe, expect, it } from 'vitest';
import { getAddress, size, type Address, type Hex } from 'viem';
import { decodeOwnerlessPaymasterAndData, ownerlessAccountAddress, type OwnerlessAccount, type PaymasterAndDataContext } from '@mova/wallet';
import { AccountSetupError, accountPaymaster } from '../src/wallet/account.js';

const a = (n: number) => getAddress(`0x${n.toString(16).padStart(40, '0')}`);
const PM = a(0x9a);
const SEPOLIA = 11_155_111;
const ACCOUNT: OwnerlessAccount = { factory: 'safe', owners: [a(1), a(2)], threshold: 2, saltNonce: 5n };

/** A chain where `PM` is an OwnerlessPaymaster with a one-day window that derives `derives` for every salt. */
function chain(o: { derives?: Address; ownerless?: boolean; sponsored?: boolean } = {}) {
  const reads: string[] = [];
  return {
    reads,
    readContract: async (r: { functionName: string; args?: readonly unknown[] }) => {
      reads.push(r.functionName);
      if (r.functionName === 'WINDOW' || r.functionName === 'MAX_COST_PER_OP') {
        if (o.ownerless === false) throw new Error('execution reverted');
        return r.functionName === 'WINDOW' ? 86_400n : 10n ** 16n;
      }
      if (r.functionName === 'accountAddress') return o.derives ?? a(0);
      if (r.functionName === 'sponsored') return o.sponsored ?? false;
      throw new Error(`unexpected read ${r.functionName}`);
    },
  };
}

describe('the app account and its paymaster', () => {
  it('ownerless: 91 bytes per operation for the account, with the chain\'s window and gas, and the contract\'s per-op cap', async () => {
    const { address } = ownerlessAccountAddress(ACCOUNT);
    const pub = chain({ derives: address });
    const pm = (await accountPaymaster({ ownerlessPaymaster: { address: PM } }, SEPOLIA, pub as never))(ACCOUNT, address);
    expect(pm.paymasterMaxCostPerOp).toBe(10n ** 16n);
    const ctx: PaymasterAndDataContext = { sender: address, chainId: SEPOLIA, blockTimestamp: 1_792_316_232n };
    const bytes = await (pm.paymasterAndData as (c: PaymasterAndDataContext) => Hex)(ctx);
    expect(size(bytes)).toBe(91);
    expect(decodeOwnerlessPaymasterAndData(bytes)).toMatchObject({ paymaster: PM, verificationGasLimit: 300_000n, factory: 'safe', window: 20_744n });
    // Sponsored when the contract's own CREATE2 derivation for the salt is this account: nothing to allowlist.
    expect(await pm.sponsored()).toBe(true);
    const elsewhere = (await accountPaymaster({ ownerlessPaymaster: { address: PM } }, SEPOLIA, chain({ derives: a(7) }) as never))(ACCOUNT, address);
    expect(await elsewhere.sponsored()).toBe(false);
  });

  it('ownerless: the deployment may set the gas limits', async () => {
    const { address } = ownerlessAccountAddress(ACCOUNT);
    const pm = (await accountPaymaster({ ownerlessPaymaster: { address: PM, verificationGasLimit: 350_000n, postOpGasLimit: 40_000n } }, SEPOLIA, chain() as never))(ACCOUNT, address);
    const bytes = await (pm.paymasterAndData as (c: PaymasterAndDataContext) => Hex)({ sender: address, chainId: SEPOLIA, blockTimestamp: 0n });
    expect(decodeOwnerlessPaymasterAndData(bytes)).toMatchObject({ verificationGasLimit: 350_000n, postOpGasLimit: 40_000n, window: 0n });
  });

  it('ownerless: a contract that is not one is refused when the account opens, in Portuguese', async () => {
    await expect(accountPaymaster({ ownerlessPaymaster: { address: PM } }, SEPOLIA, chain({ ownerless: false }) as never))
      .rejects.toThrow(AccountSetupError);
  });

  it('SponsorPaymaster: the fixed bytes, and its allowlist', async () => {
    const fixed = `0x${'ab'.repeat(20)}${'00'.repeat(32)}` as Hex;
    const pub = chain({ sponsored: true });
    const pm = (await accountPaymaster({ paymasterAndData: fixed }, SEPOLIA, pub as never))(ACCOUNT, a(0x5afe));
    expect(pm.paymasterAndData).toBe(fixed);
    expect(pm.paymasterMaxCostPerOp).toBeUndefined();
    expect(await pm.sponsored()).toBe(true);
    expect(pub.reads).toEqual(['sponsored']);
    await expect(accountPaymaster({}, SEPOLIA, pub as never)).rejects.toThrow(/não nomeia um paymaster/);
  });
});
