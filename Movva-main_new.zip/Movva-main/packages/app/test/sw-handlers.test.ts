/**
 * The service worker's push and notification-click handlers (src/sw/handlers.ts), over @mova/cosigner/client's: a
 * recovery alert becomes a notification in Portuguese with the veto deadline in Brasília, opening Início; any other
 * message or notification is left alone.
 */
import { describe, expect, it, vi } from 'vitest';
import { alertUrl, onNotificationClick, onPush } from '../src/sw/handlers.js';

const SCOPE = 'https://app.movva.example/';
const recovery = {
  v: 1, type: 'mova.recovery-requested', title: 'Movva', body: 'Uma recuperação foi solicitada na sua conta Movva', kind: 'queued',
  executableAt: Date.parse('2026-09-22T15:00:00Z') / 1000, tag: 'mova-recovery',
};

function pushEvent(data: unknown, parses = true) {
  const waits: Promise<unknown>[] = [];
  const event = {
    data: { json: () => { if (!parses) throw new SyntaxError('not JSON'); return data; } },
    waitUntil: (p: Promise<unknown>) => { waits.push(p); },
  };
  return { event, waits };
}

const registration = () => {
  const shown: [string, Record<string, unknown>][] = [];
  return { shown, reg: { scope: SCOPE, showNotification: vi.fn(async (title: string, options?: Record<string, unknown>) => { shown.push([title, options ?? {}]); }) } };
};

describe('a push', () => {
  it('a recovery alert: a notification in Portuguese with the veto deadline in Brasília, opening Início', async () => {
    const { shown, reg } = registration();
    const { event, waits } = pushEvent(recovery);
    expect(onPush(event, reg)).toBe(true);
    await Promise.all(waits);
    const [title, options] = shown[0]!;
    expect(title).toBe('Movva');
    expect(options.body).toMatch(/^Uma recuperação foi solicitada na sua conta Movva\. Se não foi você, abra o app e vete antes de 22\/09\/2026,? 12:00\.$/);
    expect(options).toMatchObject({ tag: 'mova-recovery', requireInteraction: true, data: { url: 'https://app.movva.example/#/inicio', type: 'mova.recovery-requested', kind: 'queued' } });
  });

  it('the last notice when alerts are turned off: shown as it came, without a deadline', async () => {
    const { shown, reg } = registration();
    const off = { v: 1, type: 'mova.alerts-off', title: 'Movva', body: 'Os alertas de recuperação da sua conta Movva foram desativados neste dispositivo', tag: 'mova-recovery' };
    const { event, waits } = pushEvent(off);
    expect(onPush(event, reg)).toBe(true);
    await Promise.all(waits);
    expect(shown[0]![1]).toMatchObject({ body: off.body, requireInteraction: false });
  });

  it('any other message is left alone', () => {
    const { reg } = registration();
    expect(onPush(pushEvent({ hello: 'world' }).event, reg)).toBe(false);
    expect(onPush(pushEvent(undefined, false).event, reg)).toBe(false);
    expect(onPush(pushEvent({ ...recovery, v: 2 }).event, reg)).toBe(false);
    expect(reg.showNotification).not.toHaveBeenCalled();
  });

  it('Início under the worker\'s scope, wherever the app is served', () => {
    expect(alertUrl('https://example.org/movva/')).toBe('https://example.org/movva/#/inicio');
  });
});

describe('a click on the notification', () => {
  const click = (data: unknown) => {
    const waits: Promise<unknown>[] = [];
    const close = vi.fn();
    return { event: { notification: { data, close }, waitUntil: (p: Promise<unknown>) => { waits.push(p); } }, waits, close };
  };

  it('focuses the app\'s open window, or opens Início', async () => {
    const focus = vi.fn(async () => undefined);
    const withWindow = { matchAll: vi.fn(async () => [{ url: SCOPE, focus }]), openWindow: vi.fn(async () => undefined) };
    const a = click({ type: 'mova.recovery-requested', url: `${SCOPE}#/inicio` });
    expect(onNotificationClick(a.event, withWindow)).toBe(true);
    await Promise.all(a.waits);
    expect(a.close).toHaveBeenCalled();
    expect(focus).toHaveBeenCalled();
    expect(withWindow.openWindow).not.toHaveBeenCalled();

    const none = { matchAll: vi.fn(async () => []), openWindow: vi.fn(async () => undefined) };
    const b = click({ type: 'mova.recovery-requested', url: `${SCOPE}#/inicio` });
    expect(onNotificationClick(b.event, none)).toBe(true);
    await Promise.all(b.waits);
    expect(none.openWindow).toHaveBeenCalledWith(`${SCOPE}#/inicio`);
  });

  it('another notification is left alone', () => {
    const c = click({ type: 'something-else' });
    expect(onNotificationClick(c.event, { matchAll: vi.fn(), openWindow: vi.fn() })).toBe(false);
    expect(c.close).not.toHaveBeenCalled();
  });
});
