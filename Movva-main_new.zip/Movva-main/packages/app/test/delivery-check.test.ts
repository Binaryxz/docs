/**
 * src/wallet/delivery-check.ts against a fake chain and a fake `eth_call`: the reads that decide whether a shielded delivery
 * (or Movva going back) would be refused - the pool's minimum, its registration, `dead()`, and IssuerFreeze's gas-capped
 * probe on each party - and the blocks they come to.
 */
import { describe, expect, it } from 'vitest';
import { decodeFunctionData, encodeAbiParameters, parseAbi, type Address, type Hex } from 'viem';
import { Delivery, OrderState, type OrderView } from '@mova/wallet';
import {
  ISSUER_FREEZE_PROBE_GAS, depositBlocks, issuerFrozen, reshieldDeliveryBlocks, shieldedDeliveryCheck, type DeliveryReader, type DepositReads,
} from '../src/wallet/delivery-check.js';

const addr = (n: number) => `0x${n.toString(16).padStart(40, '0')}` as Address;
const hash = (n: number) => `0x${n.toString(16).padStart(64, '0')}` as Hex;
const M = 10n ** 18n;
const D = { movva: addr(1), entrypoint: addr(2), onramp: addr(3), movvaPool: addr(0x50) };
const ACCOUNT = addr(9);
const ORDER = hash(0xab);
const ABI = parseAbi([
  'function isBlackListed(address who) view returns (bool)', 'function isBlacklisted(address who) view returns (bool)', 'function dead() view returns (bool)',
]);
const word = (n: bigint) => encodeAbiParameters([{ type: 'uint256' }], [n]);

interface World {
  pool?: Address;
  minimum?: bigint;
  dead?: boolean | 'reverts';
  /** Which freeze list the token keeps, if any. */
  list?: 'isBlackListed' | 'isBlacklisted';
  frozen?: Address[];
  order?: Partial<OrderView>;
}

function world(w: World = {}) {
  const calls: { to: Address; fn: string; who?: Address; gas?: bigint }[] = [];
  const r: DeliveryReader = {
    chain: {
      deployment: D as unknown as DeliveryReader['chain']['deployment'],
      order: async () => ({
        offerId: hash(1), taker: ACCOUNT, amount: 30n * M, brlCents: 3_000n, lockedAt: 0n, payBy: 0n, state: OrderState.LOCKED,
        delivery: Delivery.SHIELDED, recipient: ACCOUNT, precommitment: 1n, commitment: 0n, ...w.order,
      }),
      assetConfig: async () => ({ pool: w.pool ?? D.movvaPool, minimumDeposit: w.minimum ?? M, vettingFeeBps: 10n, maxRelayFeeBps: 100n }),
    },
    client: {
      async call({ to, data, gas }) {
        const { functionName, args } = decodeFunctionData({ abi: ABI, data });
        const who = args?.[0] as Address | undefined;
        calls.push({ to, fn: functionName, who, gas });
        if (functionName === 'dead') {
          if (w.dead === 'reverts') throw new Error('execution reverted');
          return { data: word(w.dead ? 1n : 0n) };
        }
        if (w.list !== functionName) throw new Error('execution reverted');
        return { data: word((w.frozen ?? []).some((f) => f.toLowerCase() === who!.toLowerCase()) ? 1n : 0n) };
      },
    },
  };
  return { r, calls };
}

describe('IssuerFreeze\'s probe', () => {
  it('Tether\'s list, Circle\'s list, or neither; each asked with IssuerFreeze.PROBE_GAS', async () => {
    const tether = world({ list: 'isBlackListed', frozen: [ACCOUNT] });
    expect(await issuerFrozen(tether.r.client, D.movva, ACCOUNT)).toBe(true);
    expect(await issuerFrozen(tether.r.client, D.movva, D.onramp)).toBe(false);
    expect(await issuerFrozen(world({ list: 'isBlacklisted', frozen: [ACCOUNT] }).r.client, D.movva, ACCOUNT)).toBe(true);
    const none = world({ frozen: [ACCOUNT] });
    expect(await issuerFrozen(none.r.client, D.movva, ACCOUNT)).toBe(false);
    expect(none.calls.map((c) => c.fn)).toEqual(['isBlackListed', 'isBlacklisted']);
    expect(none.calls.every((c) => c.gas === ISSUER_FREEZE_PROBE_GAS && c.to === D.movva)).toBe(true);
    expect(ISSUER_FREEZE_PROBE_GAS).toBe(30_000n);
  });

  it('no code, or an answer shorter than a word, is not frozen', async () => {
    expect(await issuerFrozen({ call: async () => ({ data: undefined }) }, D.movva, ACCOUNT)).toBe(false);
    expect(await issuerFrozen({ call: async () => ({ data: '0x01' }) }, D.movva, ACCOUNT)).toBe(false);
  });
});

describe('a shielded order waiting to be released', () => {
  it('nothing stops it: pending, shielded, no block; the escrow, the Entrypoint, the pool and the rescue address were asked', async () => {
    const { r, calls } = world({ list: 'isBlackListed' });
    expect(await shieldedDeliveryCheck(r, ORDER)).toEqual({ pending: true, delivery: 'shielded', blocks: [], directRefused: false });
    const asked = new Set(calls.filter((c) => c.fn === 'isBlackListed').map((c) => c.who!.toLowerCase()));
    expect(asked).toEqual(new Set([D.onramp, D.entrypoint, D.movvaPool, ACCOUNT].map((a) => a.toLowerCase())));
    expect(calls.some((c) => c.fn === 'dead' && c.to === D.movvaPool)).toBe(true);
  });

  it('the pool\'s minimum raised above the order\'s Movva', async () => {
    const { r } = world({ minimum: 1_000_000n * M });
    expect((await shieldedDeliveryCheck(r, ORDER)).blocks).toEqual([{ kind: 'below_pool_minimum', minimum: 1_000_000n * M, amount: 30n * M }]);
  });

  it('no pool registered for Movva: nothing asked of a pool that is not there', async () => {
    const { r, calls } = world({ pool: addr(0), list: 'isBlackListed', frozen: [addr(0)] });
    expect((await shieldedDeliveryCheck(r, ORDER)).blocks).toEqual([{ kind: 'pool_not_registered' }]);
    expect(calls.some((c) => c.fn === 'dead' || c.who === addr(0))).toBe(false);
  });

  it('another pool registered, or the pool wound down; a dead() that does not answer blocks nothing', async () => {
    expect((await shieldedDeliveryCheck(world({ pool: addr(0x51) }).r, ORDER)).blocks).toEqual([{ kind: 'pool_changed', pool: addr(0x51) }]);
    expect((await shieldedDeliveryCheck(world({ dead: true }).r, ORDER)).blocks).toEqual([{ kind: 'pool_wound_down' }]);
    expect((await shieldedDeliveryCheck(world({ dead: 'reverts' }).r, ORDER)).blocks).toEqual([]);
  });

  it('the issuer froze the Entrypoint or the pool: blocked, and delivery in the open still possible', async () => {
    const { r } = world({ list: 'isBlacklisted', frozen: [D.entrypoint, D.movvaPool] });
    expect(await shieldedDeliveryCheck(r, ORDER)).toMatchObject({
      blocks: [{ kind: 'frozen', party: 'entrypoint' }, { kind: 'frozen', party: 'pool' }], directRefused: false,
    });
  });

  it('the issuer froze the escrow, or the rescue address: delivery in the open is refused too', async () => {
    expect(await shieldedDeliveryCheck(world({ list: 'isBlackListed', frozen: [D.onramp] }).r, ORDER))
      .toMatchObject({ blocks: [{ kind: 'frozen', party: 'escrow' }], directRefused: true });
    expect(await shieldedDeliveryCheck(world({ list: 'isBlackListed', frozen: [ACCOUNT] }).r, ORDER))
      .toMatchObject({ blocks: [], directRefused: true });
  });

  it('switched to the open, there is no shielded delivery left to block; a released order has nothing left to deliver', async () => {
    expect(await shieldedDeliveryCheck(world({ minimum: 1_000_000n * M, order: { delivery: Delivery.DIRECT } }).r, ORDER))
      .toEqual({ pending: true, delivery: 'direct', blocks: [], directRefused: false });
    const disputed = world({ minimum: 1_000_000n * M, order: { state: OrderState.DISPUTED } });
    expect((await shieldedDeliveryCheck(disputed.r, ORDER)).blocks).toHaveLength(1);
    const released = world({ minimum: 1_000_000n * M, order: { state: OrderState.RELEASED } });
    expect(await shieldedDeliveryCheck(released.r, ORDER)).toEqual({ pending: false, delivery: 'shielded', blocks: [], directRefused: false });
    expect(released.calls).toHaveLength(0);
  });
});

describe('Movva delivered in the open, going back', () => {
  it('sent from the account: its freeze counts, the escrow is not asked; the minimum as for a delivery', async () => {
    const frozen = world({ list: 'isBlackListed', frozen: [ACCOUNT], order: { state: OrderState.RELEASED, delivery: Delivery.DIRECT } });
    expect(await reshieldDeliveryBlocks(frozen.r, ORDER, ACCOUNT)).toEqual([{ kind: 'frozen', party: 'account' }]);
    expect(frozen.calls.some((c) => c.who === D.onramp)).toBe(false);
    expect(await reshieldDeliveryBlocks(world({ minimum: 1_000_000n * M }).r, ORDER, ACCOUNT))
      .toEqual([{ kind: 'below_pool_minimum', minimum: 1_000_000n * M, amount: 30n * M }]);
    expect(await reshieldDeliveryBlocks(world().r, ORDER, ACCOUNT)).toEqual([]);
  });
});

describe('the blocks, from the reads', () => {
  const reads = (over: Partial<DepositReads> = {}): DepositReads => ({
    registeredPool: D.movvaPool, expectedPool: D.movvaPool, minimumDeposit: M, amount: 30n * M, poolDead: false, frozen: {}, ...over,
  });

  it('the amount at the minimum passes; every block in the order the Movva meets it', () => {
    expect(depositBlocks(reads({ amount: M }))).toEqual([]);
    expect(depositBlocks(reads({ amount: M - 1n }))).toEqual([{ kind: 'below_pool_minimum', minimum: M, amount: M - 1n }]);
    expect(depositBlocks(reads({
      registeredPool: addr(0x51), poolDead: true, minimumDeposit: 100n * M, frozen: { pool: true, entrypoint: true, escrow: true, account: false },
    }))).toEqual([
      { kind: 'pool_changed', pool: addr(0x51) }, { kind: 'pool_wound_down' }, { kind: 'below_pool_minimum', minimum: 100n * M, amount: 30n * M },
      { kind: 'frozen', party: 'escrow' }, { kind: 'frozen', party: 'entrypoint' }, { kind: 'frozen', party: 'pool' },
    ]);
  });

  it('with no pool registered, a pool freeze is not a reason: there is no pool', () => {
    expect(depositBlocks(reads({ registeredPool: addr(0), frozen: { pool: true, entrypoint: true } })))
      .toEqual([{ kind: 'pool_not_registered' }, { kind: 'frozen', party: 'entrypoint' }]);
  });
});
