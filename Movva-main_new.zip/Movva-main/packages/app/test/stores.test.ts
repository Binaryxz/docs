import { describe, expect, it } from 'vitest';
import { privateKeyToAccount } from 'viem/accounts';
import { parse, stringify } from '../src/lib/json.js';
import { deriveAccountKey } from '../src/wallet/keys.js';
import { MemoryKeyValue, SealedStore, StoreUnreadable, storeKeyFromSeed } from '../src/wallet/stores.js';

const seed = (b: number) => new Uint8Array(32).fill(b);

describe('JSON with bigints', () => {
  it('round-trips bigints anywhere, and nothing else changes', () => {
    const v = { a: 1n, b: [2n, 'x', { c: 10n ** 30n }], d: -5n, e: null, f: 'text' };
    expect(parse(stringify(v))).toEqual(v);
  });

  it('an object that merely has a $bigint field among others stays an object', () => {
    expect(parse('{"$bigint":"1","other":true}')).toEqual({ $bigint: '1', other: true });
  });
});

describe('the sealed local store', () => {
  it('keeps records encrypted, and reads them back with the same seed', () => {
    const kv = new MemoryKeyValue();
    const store = new SealedStore(kv, storeKeyFromSeed(seed(1)), 'mova:test:');
    store.write('activity:sales', [{ payee: '+5511987654321', receive: 2_000n }]);
    const raw = kv.get('mova:test:activity:sales')!;
    expect(raw).not.toContain('5511987654321');
    expect(store.read('activity:sales')).toEqual([{ payee: '+5511987654321', receive: 2_000n }]);
  });

  it('another seed cannot read them', () => {
    const kv = new MemoryKeyValue();
    new SealedStore(kv, storeKeyFromSeed(seed(1)), 'mova:test:').write('x', { secret: 1 });
    expect(() => new SealedStore(kv, storeKeyFromSeed(seed(2)), 'mova:test:').read('x')).toThrow(StoreUnreadable);
  });

  it('a record moved under another name does not open: the name is bound to the ciphertext', () => {
    const kv = new MemoryKeyValue();
    const store = new SealedStore(kv, storeKeyFromSeed(seed(1)), 'mova:test:');
    store.write('sale-keys', { a: '0xkey' });
    kv.set('mova:test:activity:orders', kv.get('mova:test:sale-keys')!);
    expect(() => store.read('activity:orders')).toThrow(StoreUnreadable);
  });

  it('sale records by id, whatever the case; lists upsert newest first; clear forgets only this wallet', () => {
    const kv = new MemoryKeyValue();
    kv.set('other:app', 'kept');
    const store = new SealedStore(kv, storeKeyFromSeed(seed(1)), 'mova:test:');
    const sales = store.saleStore();
    const record = { saleId: '0xABCDEF' as const, account: '0x0000000000000000000000000000000000000001' as const, payee: { kind: 'pix' as const, pixKey: 'a@b.c' }, salt: '0x01' as const, receiveCents: '100' };
    sales.put(record);
    expect(sales.get('0xabcdef')).toEqual(record);
    store.upsert('l', { id: 1, v: 'a' }, (x: { id: number }) => x.id === 1);
    store.upsert('l', { id: 2, v: 'b' }, (x: { id: number }) => x.id === 2);
    store.upsert('l', { id: 1, v: 'c' }, (x: { id: number }) => x.id === 1);
    expect(store.list('l')).toEqual([{ id: 2, v: 'b' }, { id: 1, v: 'c' }]);
    store.clear();
    expect(kv.keys()).toEqual(['other:app']);
  });
});

describe('keys derived from the seed', () => {
  it('the account key is recomputed from the seed, and is not the store key', () => {
    const k = deriveAccountKey(seed(9));
    expect(deriveAccountKey(seed(9))).toBe(k);
    expect(deriveAccountKey(seed(8))).not.toBe(k);
    expect(k.slice(2)).not.toBe(Buffer.from(storeKeyFromSeed(seed(9))).toString('hex'));
    expect(privateKeyToAccount(k).address).toMatch(/^0x[0-9a-fA-F]{40}$/);
  });
});
