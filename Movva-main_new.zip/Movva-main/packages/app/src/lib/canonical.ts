/**
 * The trust root the bundle carries (audit M-23). The bundle embeds one canonical record of contract addresses per
 * chain, generated at build time from the repository's deployment records (scripts/canonical-deployments.ts writes
 * canonical-deployments.generated.ts). A deployment JSON loaded at runtime for one of those chains must name the same
 * contracts, or it is refused, and the refusal says which fields differ. A chain without a record (a local stack) is
 * usable only after the user confirms a strong warning (deployment-trust.ts).
 */
import { getAddress, type Address } from 'viem';
import { CANONICAL_DEPLOYMENTS } from './canonical-deployments.generated.js';
import type { CanonicalDeployment } from './canonical-types.js';
import { DeploymentInvalid, isSmartAccount, type AppDeployment } from './deployment.js';

export type { CanonicalDeployment } from './canonical-types.js';
export { CANONICAL_DEPLOYMENTS };

/** The contract fields a canonical record can pin, with how the app names them. */
export const CONTRACT_FIELD_LABELS = {
  movva: 'Movva (token)',
  reserve: 'Reserva',
  onramp: 'Escrow de compra',
  offramp: 'Escrow de venda',
  entrypoint: 'Entrypoint (Privacy Pools)',
  movvaPool: 'Pool Movva',
  saleVerifier: 'Verificador de vendas (zkTLS)',
  auditGrantRegistry: 'Registro de auditoria',
  lpRegistry: 'Registro de provedores de liquidez',
  aspQuorum: 'Quórum da ASP',
  hedgeSubWallet: 'Sub-carteira da estratégia',
  hedgeVenue: 'Contrato da estratégia',
} as const;

export type PinnedContract = keyof typeof CONTRACT_FIELD_LABELS;

export interface PinDiff {
  /** The deployment JSON's field, e.g. `contracts.movvaPool`. */
  field: string;
  label: string;
  /** What the canonical record says; undefined when it has no such field. */
  expected?: string;
  /** What the file says; undefined when it omits a field the record pins. */
  actual?: string;
}

export class DeploymentNotCanonical extends DeploymentInvalid {
  constructor(readonly chainId: number, readonly diffs: PinDiff[]) {
    super(`o arquivo diz ser da rede ${chainId}, mas difere do registro embutido no app em: `
      + `${diffs.map((d) => `${d.label} (registro ${d.expected ?? 'sem valor'}, arquivo ${d.actual ?? 'sem valor'})`).join('; ')}`);
  }
}

export const canonicalFor = (chainId: number, table: Readonly<Record<number, CanonicalDeployment>> = CANONICAL_DEPLOYMENTS): CanonicalDeployment | undefined =>
  Object.prototype.hasOwnProperty.call(table, chainId) ? table[chainId] : undefined;

const same = (a?: string, b?: string) => a !== undefined && b !== undefined && a.toLowerCase() === b.toLowerCase();

/** Every field where `d` differs from its chain's canonical record (none: it matches, or the chain has no record). */
export function canonicalDiffs(d: AppDeployment, canonical: CanonicalDeployment): PinDiff[] {
  const diffs: PinDiff[] = [];
  const contracts = d.contracts as unknown as Partial<Record<PinnedContract, Address>>;
  for (const key of Object.keys(CONTRACT_FIELD_LABELS) as PinnedContract[]) {
    const expected = canonical.contracts[key];
    const actual = contracts[key];
    if (actual === undefined) continue; // A field the file leaves out is not used: nothing to pin.
    if (!same(expected, actual)) diffs.push({ field: `contracts.${key}`, label: CONTRACT_FIELD_LABELS[key], expected, actual });
  }
  // A later start block would hide the contracts' earlier history; an earlier one only reads more.
  if (d.contracts.fromBlock > BigInt(canonical.fromBlock)) {
    diffs.push({ field: 'fromBlock', label: 'Bloco inicial', expected: canonical.fromBlock, actual: d.contracts.fromBlock.toString() });
  }
  const pins = canonical.account;
  if (pins && isSmartAccount(d.account)) {
    const a = d.account;
    if (pins.coSigner && !same(pins.coSigner, a.cosigner.address)) {
      diffs.push({ field: 'account.cosigner.address', label: 'Cossignatário', expected: pins.coSigner, actual: a.cosigner.address });
    }
    if (pins.ownerlessPaymaster) {
      const actual = a.ownerlessPaymaster?.address ?? (a.paymasterAndData ? getAddress(a.paymasterAndData.slice(0, 42)) : undefined);
      if (!same(pins.ownerlessPaymaster, actual)) diffs.push({ field: 'account.paymaster', label: 'Paymaster', expected: pins.ownerlessPaymaster, actual });
    }
    if (pins.kernel && a.kernel) {
      if (!same(pins.kernel.passkeyValidator, a.kernel.passkeyValidator)) {
        diffs.push({ field: 'account.kernel.passkeyValidator', label: 'Validador Kernel', expected: pins.kernel.passkeyValidator, actual: a.kernel.passkeyValidator });
      }
      if (!same(pins.kernel.adapter, a.kernel.adapter)) {
        diffs.push({ field: 'account.kernel.adapter', label: 'Adaptador de recuperação Kernel', expected: pins.kernel.adapter, actual: a.kernel.adapter });
      }
    }
  }
  return diffs;
}

/**
 * Check `d` against the bundle's records: 'canonical' when its chain has a record and every pinned field matches,
 * 'unpinned' when its chain has none. Throws `DeploymentNotCanonical` on any mismatch.
 */
export function checkCanonical(d: AppDeployment, table?: Readonly<Record<number, CanonicalDeployment>>): 'canonical' | 'unpinned' {
  const canonical = canonicalFor(d.chainId, table);
  if (!canonical) return 'unpinned';
  const diffs = canonicalDiffs(d, canonical);
  if (diffs.length > 0) throw new DeploymentNotCanonical(d.chainId, diffs);
  return 'canonical';
}
