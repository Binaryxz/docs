/**
 * "Reserva e riscos": what backs the balance, what investing the reserve risks, and the one rule the contracts apply
 * if the reserve ever fell short. The reserve is principal-locked (client rule, 21 October 2026): its USDT leaves only
 * by redemption, and only the yield above the backing goes to Movva's fixed Safe. One copy, shown in onboarding (src/ui/Onboarding.tsx), on its own screen
 * linked from Início (#/reserva) and in Ajustes, through src/ui/ReserveRisks.tsx.
 *
 * Plain on purpose, and generic about the yield source and any trading venue: none is named.
 * The pro-rata rule is MovvaReserve's: under-backed, a redemption pays the redeemer's pro-rata share of the reserve
 * (contracts/movva/MovvaReserve.sol), the same for every holder.
 */
export const RESERVE_RISKS = {
  title: 'Reserva e riscos',
  /** The user is shielded from FX. */
  fx: 'Você não fica exposto ao câmbio: seu saldo é em reais, a R$ 1,00 por Movva. A reserva guarda USDT (dólar digital) e é ela que absorve a variação do dólar contra o real.',
  /** The principal-locked reserve: invested, the principal only leaves by redemption, only the yield goes to Movva. */
  strategy: 'O USDT da reserva fica aplicado numa fonte de rendimento. O principal nunca sai da reserva: só sai no resgate, quando alguém vende Movva por reais. Só o rendimento acima do lastro sai, e só para a carteira da Movva.',
  risksIntro: 'Essa aplicação tem riscos:',
  risks: [
    'risco da fonte de rendimento: ela pode suspender saques por um tempo ou perder valor;',
    'risco de contrato inteligente: um erro nos contratos da reserva ou da fonte de rendimento pode causar perdas;',
    'risco de câmbio da reserva: se o real se valorizar muito, a reserva em dólar pode ficar curta.',
  ],
  /** Movva covers a shortfall with its own capital. */
  shortfall: 'Se a reserva ficar curta, a Movva cobre a diferença com capital próprio.',
  /** The contracts' equal-treatment rule below 100%. */
  equalTreatment: 'Uma regra que você precisa conhecer: os contratos tratam todos os titulares igualmente. Se a reserva um dia ficasse abaixo de 100%, cada resgate pagaria a sua parte proporcional da reserva, e não R$ 1,00 por Movva. Por isso a Movva se compromete a recompor a reserva antes que isso aconteça.',
} as const;

/**
 * The live figures on "Reserva e riscos" and beside Início's backing notice (src/lib/format.ts `coverageView`): the
 * reserve's coverage as its contract computes it, and Movva's delta-neutral position on a line of its own: it is Movva's
 * own capital, never the reserve's, and never part of the ratio. No venue named, as above.
 */
export const LIVE_COVERAGE = {
  title: 'Cobertura agora',
  /** Under the ratio. */
  ratioCaption: 'dos Movva em circulação, lido agora no contrato da reserva.',
  noSupply: 'Ainda não há Movva em circulação: a reserva cobre tudo.',
  unknown: 'Não foi possível ler a cobertura agora. Tente de novo em instantes.',
  /** While the FX market is closed: the ratio is at the last close. */
  closed: (at?: string) => `Mercado de câmbio fechado: índice no último fechamento${at ? `, atualizado em ${at}` : ''}.`,
  positionTitle: 'Posição delta-neutra da Movva (à parte)',
  position: (allocated: string, value: string) => `${allocated} de capital próprio da Movva na estratégia, valendo ${value} agora. Não é dinheiro da reserva e não entra no índice acima.`,
  noPosition: 'Nenhuma posição aberta na estratégia delta-neutra.',
  positionUnknown: 'Não foi possível ler a posição da estratégia agora.',
  /** Início, beside the backing notice. */
  home: (ratio: string, closed: boolean) => `Cobertura da reserva ${closed ? 'no último fechamento' : 'agora'}: ${ratio}.`,
  homeSeparate: 'A posição delta-neutra da Movva é informada à parte, em',
} as const;
