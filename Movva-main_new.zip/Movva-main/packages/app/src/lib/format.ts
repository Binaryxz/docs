/**
 * Everything the user reads, in Brazilian Portuguese: amounts always in reais (R$ 1.234,56), dates in Brasília,
 * and the balance's backing and each order's and sale's state in words.
 */
import { formatRatio, formatReais, parseReais, type Backing, type BuyStatus, type MovvaCoverage, type Reais, type SaleStatus } from '@mova/wallet';
import { LIVE_COVERAGE } from './reserve-risks.js';

export const BRASILIA = 'America/Sao_Paulo';

export const formatBRL = (cents: bigint): string => formatReais(cents);

/** `3,50%` from basis points. */
export const formatBps = (bps: bigint | number): string => formatRatio(BigInt(bps));

export class AmountInputError extends Error {}

/** A form field the user must correct: its title and what to do, in Portuguese. */
export class InputInvalid extends Error {
  constructor(readonly title: string, message: string) { super(message); }
}

/** What the user typed, in reais: "1.234,56", "1234,56", "R$ 50". Refused in words, never guessed. */
export function parseAmountInput(input: string): Reais {
  const s = input.trim();
  if (s === '') throw new AmountInputError('Informe um valor em reais.');
  let v: Reais;
  try {
    v = parseReais(s);
  } catch {
    throw new AmountInputError(`"${s}" não é um valor em reais. Use o formato 1.234,56.`);
  }
  if (v === 0n) throw new AmountInputError('O valor precisa ser maior que zero.');
  return v;
}

const dateTimeParts = new Intl.DateTimeFormat('pt-BR', {
  timeZone: BRASILIA, day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', hourCycle: 'h23',
});

const part = (parts: Intl.DateTimeFormatPart[], type: Intl.DateTimeFormatPartTypes) => parts.find((p) => p.type === type)?.value ?? '';

/** `20/01/2027 às 14:05`, in Brasília. */
export function formatDateTime(unixSeconds: number): string {
  const p = dateTimeParts.formatToParts(new Date(unixSeconds * 1000));
  return `${part(p, 'day')}/${part(p, 'month')}/${part(p, 'year')} às ${part(p, 'hour')}:${part(p, 'minute')}`;
}

/** `20/01/2027` from `2027-01-20`. */
export function formatIsoDate(isoDate: string): string {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(isoDate);
  return m ? `${m[3]}/${m[2]}/${m[1]}` : isoDate;
}

/** `2027-01-20`, today in Brasília. */
export function brasiliaIsoDate(unixSeconds: number): string {
  const p = dateTimeParts.formatToParts(new Date(unixSeconds * 1000));
  return `${part(p, 'year')}-${part(p, 'month')}-${part(p, 'day')}`;
}

/** How long until `deadline`, both unix seconds. */
export function formatTimeLeft(deadline: number, now: number): string {
  const s = deadline - now;
  if (s <= 0) return 'prazo encerrado';
  if (s < 60) return 'menos de 1 minuto';
  const m = Math.floor(s / 60);
  if (m < 60) return `${m} min`;
  const h = Math.floor(m / 60);
  const rest = m % 60;
  if (h < 24) return rest ? `${h} h ${rest} min` : `${h} h`;
  const d = Math.floor(h / 24);
  return d === 1 ? '1 dia' : `${d} dias`;
}

export type Tone = 'ok' | 'info' | 'warn' | 'danger';

export interface BackingView {
  tone: Tone;
  title: string;
  detail: string;
  /** While the FX market is closed: the backing is at the last close, and conversions wait for the market. */
  closedMarket?: string;
  /** True unless backing is full: every figure assumes R$ 1,00 per Movva, which is then not a fact. */
  conditional: boolean;
  /** The wallet's own reason, for "detalhes técnicos". */
  technical?: string;
}

/** No Movva in circulation: the reserve answers with uint256's maximum. */
const NO_SUPPLY = 2n ** 255n;

export function backingView(b: Backing): BackingView {
  if (b.status === 'unknown') {
    return {
      tone: 'danger', title: 'Lastro não confirmado', conditional: true, technical: b.reason,
      detail: 'Não foi possível confirmar as reservas agora. Os valores supõem R$ 1,00 por Movva, o que não está garantido, e as compras ficam suspensas até a leitura voltar.',
    };
  }
  const closedMarket = b.marketClosed
    ? `Mercado de câmbio fechado: o lastro usa o último fechamento${b.lastCloseAt ? ` (${formatDateTime(b.lastCloseAt)})` : ''}. Conversões na reserva aguardam a reabertura do mercado.`
    : undefined;
  if (b.status === 'full') {
    return {
      tone: 'ok', title: 'Lastro integral', conditional: false, closedMarket,
      detail: b.collateralRatioBps >= NO_SUPPLY
        ? 'Ainda não há Movva em circulação: as reservas cobrem tudo.'
        : `As reservas cobrem ${formatRatio(b.collateralRatioBps)} dos Movva em circulação.`,
    };
  }
  return {
    tone: 'warn', title: `Lastro parcial: ${b.ratio}`, conditional: true, closedMarket,
    detail: `As reservas cobrem ${b.ratio} dos Movva em circulação. Enquanto o lastro não for integral, R$ 1,00 por Movva não está garantido e as compras ficam suspensas.`,
  };
}

export interface StatusView {
  label: string;
  tone: Tone;
  /** Nothing more will happen without the user. */
  done: boolean;
  detail?: string;
}

export function buyStatusView(s: BuyStatus, now: number): StatusView {
  switch (s.state) {
    case 'awaiting_payment':
      return { label: 'Aguardando pagamento', tone: 'info', done: false, detail: `Pague ${s.formatted} até ${formatDateTime(s.payBy)} (${formatTimeLeft(s.payBy, now)}).` };
    case 'awaiting_boleto':
      return { label: 'Aguardando a emissão do boleto', tone: 'info', done: false, detail: `O provedor de liquidez tem até ${formatDateTime(s.issueBy)} para emitir o boleto.` };
    case 'expired':
      return { label: 'Prazo encerrado', tone: 'warn', done: true, detail: 'O pedido não foi pago a tempo. Nada foi cobrado.' };
    case 'disputed':
      return { label: 'Em disputa', tone: 'warn', done: false, detail: 'O pagamento está sendo analisado pela arbitragem.' };
    case 'cancelled':
      return { label: 'Cancelado', tone: 'info', done: true, detail: 'Pedido cancelado sem custo.' };
    case 'delivered':
      return { label: 'Entregue', tone: 'ok', done: true, detail: `${s.creditedFormatted} creditados no seu saldo (já descontada a taxa do pool).` };
    case 'delivered_in_the_open':
      return { label: 'Entregue fora do saldo protegido', tone: 'warn', done: true, detail: 'Os Movva foram entregues na sua conta, fora do saldo protegido.' };
  }
}

export function saleStatusView(s: SaleStatus, now: number, todayIso: string): StatusView {
  const bill = s.rail === 'boleto';
  switch (s.state) {
    case 'open':
      if (bill && s.dueDate && s.dueDate < todayIso) {
        return { label: 'Boleto vencido', tone: 'warn', done: false, detail: `O boleto venceu em ${formatIsoDate(s.dueDate)} e nenhum provedor paga boleto vencido: cancele a venda para receber os Movva de volta.` };
      }
      return { label: 'Aguardando um provedor de liquidez', tone: 'info', done: false, detail: bill ? `Boleto de ${s.formatted}${s.dueDate ? `, vence em ${formatIsoDate(s.dueDate)}` : ''}.` : `${s.formatted} por PIX.` };
    case 'claimed':
      return { label: bill ? 'Pagando o boleto' : 'Enviando o PIX', tone: 'info', done: false, detail: s.payBy ? `O provedor tem até ${formatDateTime(s.payBy)} (${formatTimeLeft(s.payBy, now)}) para pagar e provar.` : undefined };
    case 'settled':
      return { label: bill ? 'Boleto pago' : 'PIX enviado', tone: 'ok', done: true, detail: bill ? `Boleto de ${s.formatted} pago.` : `${s.formatted} enviados por PIX.` };
    case 'cancelled':
      return { label: 'Venda cancelada', tone: 'info', done: true, detail: 'Os Movva voltaram para a conta da venda, fora do saldo protegido.' };
    case 'disputed':
      return { label: 'Em disputa', tone: 'warn', done: false, detail: 'O pagamento está sendo analisado pela arbitragem.' };
  }
}

export const RAIL_LABEL: Record<'pix' | 'boleto', string> = { pix: 'PIX', boleto: 'Boleto' };

/** `3.495,51 USDT` from base units (6 decimals by default), floored to the cent; a loss reads `-12,30 USDT`. */
export function formatUsdt(base: bigint, decimals = 6): string {
  const neg = base < 0n;
  const a = neg ? -base : base;
  const cents = decimals >= 2 ? a / 10n ** BigInt(decimals - 2) : a * 10n ** BigInt(2 - decimals);
  const whole = (cents / 100n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  return `${neg ? '-' : ''}${whole},${(cents % 100n).toString().padStart(2, '0')} USDT`;
}

export interface CoverageView {
  /** `105,10%`; absent when the reserve could not be read or nothing is in circulation. */
  ratio?: string;
  tone: Tone;
  /** The line under the ratio, or what stands in for it. */
  caption: string;
  /** While the FX market is closed: the ratio is the last close's. */
  closedMarket?: string;
  /** The delta-neutral position, on its own line. */
  position: string;
  /** For "detalhes técnicos". */
  technical?: string;
}

/** "Reserva e riscos": the coverage the reserve's contract computes, and the strategy's position apart from it. */
export function coverageView(c: MovvaCoverage): CoverageView {
  const L = LIVE_COVERAGE;
  const h = c.hedge;
  const position = h.status === 'open'
    ? L.position(formatUsdt(h.allocated, h.decimals), formatUsdt(h.value, h.decimals))
    : h.status === 'none' ? L.noPosition : L.positionUnknown;
  const technical = [c.backing.status === 'unknown' ? c.backing.reason : undefined, h.status === 'unknown' ? h.reason : undefined].filter(Boolean).join('; ') || undefined;
  const b = c.backing;
  if (b.status === 'unknown') return { tone: 'danger', caption: L.unknown, position, technical };
  const closedMarket = b.marketClosed ? L.closed(b.lastCloseAt ? formatDateTime(b.lastCloseAt) : undefined) : undefined;
  if (b.collateralRatioBps >= NO_SUPPLY) return { tone: 'ok', caption: L.noSupply, closedMarket, position, technical };
  return {
    ratio: formatRatio(b.collateralRatioBps), tone: b.status === 'full' ? 'ok' : 'warn', caption: L.ratioCaption, closedMarket, position, technical,
  };
}

/** Início's short line beside the backing notice, or undefined when there is no ratio to state. */
export function homeCoverageLine(b: Backing): string | undefined {
  if (b.status === 'unknown' || b.collateralRatioBps >= NO_SUPPLY) return undefined;
  return LIVE_COVERAGE.home(formatRatio(b.collateralRatioBps), b.marketClosed);
}
