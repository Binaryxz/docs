import type { Address } from 'viem';

/**
 * One chain's canonical deployment as the bundle embeds it: the contract addresses the app trusts there, taken from
 * the repository's deployment records by scripts/canonical-deployments.ts. Only what a deployment JSON can name is
 * pinned. A field a record leaves out is absent here, and a file naming it for this chain is refused.
 */
export interface CanonicalDeployment {
  chainId: number;
  name: string;
  /** The repository's deployment records this entry was generated from. */
  sources: readonly string[];
  /** The first block of the record: a file may start reading earlier, never later. Decimal. */
  fromBlock: string;
  contracts: {
    movva: Address;
    reserve: Address;
    onramp: Address;
    offramp: Address;
    entrypoint: Address;
    movvaPool: Address;
    saleVerifier: Address;
    auditGrantRegistry: Address;
    lpRegistry?: Address;
    aspQuorum?: Address;
    hedgeSubWallet?: Address;
    hedgeVenue?: Address;
  };
  account?: {
    /** The deployment's co-signer, when a record names it. */
    coSigner?: Address;
    ownerlessPaymaster?: Address;
    kernel?: { passkeyValidator: Address; adapter: Address };
  };
}
