/**
 * When a deployment may be used without asking (audit M-23). The app remembers the last deployment the user accepted
 * on this device, as a flat summary of what matters: chain, contracts, account pins and endpoints. A deployment is
 * used silently only when it equals that summary, or when this device has accepted none yet and the deployment
 * matches its chain's canonical record. Anything else needs a confirmation: a saved JSON that changed, a file
 * imported in Ajustes, another URL. The confirmation shows what differs, and a chain without a canonical record
 * carries a strong warning. A file that contradicts its chain's record never reaches this point, because
 * `checkCanonical` refuses it.
 */
import { checkCanonical, CONTRACT_FIELD_LABELS, type CanonicalDeployment } from './canonical.js';
import { isSmartAccount, type AppDeployment } from './deployment.js';
import type { KeyValue } from '../wallet/stores.js';

export type DeploymentSummary = Record<string, string>;

const LABELS: Record<string, string> = {
  name: 'Nome', chainId: 'Chain ID', fromBlock: 'Bloco inicial', rpcUrl: 'RPC',
  ...Object.fromEntries(Object.entries(CONTRACT_FIELD_LABELS).map(([k, v]) => [`contracts.${k}`, v])),
  'services.matcher': 'Matcher', 'services.relayer': 'Relayer', 'services.asp': 'ASP', 'services.vault': 'Cofre de notas',
  'services.lpNodes': 'Nós de LP', 'account.kind': 'Tipo de conta', 'account.kinds': 'Tipos de conta oferecidos',
  'account.bundler': 'Bundler', 'account.paymaster': 'Paymaster', 'account.cosigner.address': 'Cossignatário',
  'account.cosigner.url': 'Serviço cossignatário', 'account.kernel.passkeyValidator': 'Validador Kernel',
  'account.kernel.adapter': 'Adaptador de recuperação Kernel', 'dev.url': 'API de teste',
};
export const fieldLabel = (field: string): string => LABELS[field] ?? field;

/** What the user accepts when they accept a deployment. The co-signer's API key is left out: it is not shown. */
export function summarize(d: AppDeployment): DeploymentSummary {
  const s: DeploymentSummary = {
    name: d.name, chainId: String(d.chainId), fromBlock: d.contracts.fromBlock.toString(), rpcUrl: d.rpcUrl,
    'services.matcher': d.services.matcher, 'services.relayer': d.services.relayer, 'services.asp': d.services.asp,
    'services.lpNodes': d.services.lpNodes.map((n) => `${n.lp} ${n.url}`).join(', '),
    'account.kind': d.account.kind,
  };
  const contracts = d.contracts as unknown as Record<string, unknown>;
  for (const k of Object.keys(CONTRACT_FIELD_LABELS)) if (typeof contracts[k] === 'string') s[`contracts.${k}`] = contracts[k] as string;
  if (d.services.vault) s['services.vault'] = d.services.vault;
  if (isSmartAccount(d.account)) {
    const a = d.account;
    s['account.kinds'] = a.kinds.join(', ');
    s['account.bundler'] = a.bundler;
    s['account.paymaster'] = a.ownerlessPaymaster ? `OwnerlessPaymaster ${a.ownerlessPaymaster.address}` : `SponsorPaymaster ${a.paymasterAndData}`;
    s['account.cosigner.address'] = a.cosigner.address;
    s['account.cosigner.url'] = a.cosigner.url;
    if (a.kernel) {
      s['account.kernel.passkeyValidator'] = a.kernel.passkeyValidator;
      s['account.kernel.adapter'] = a.kernel.adapter;
    }
  }
  if (d.dev) s['dev.url'] = d.dev.url;
  return s;
}

export interface DeploymentChange { field: string; label: string; before?: string; after?: string }

export function diffSummaries(before: DeploymentSummary, after: DeploymentSummary): DeploymentChange[] {
  const fields = [...new Set([...Object.keys(before), ...Object.keys(after)])];
  return fields.filter((f) => before[f] !== after[f]).map((f) => ({ field: f, label: fieldLabel(f), before: before[f], after: after[f] }));
}

const ACCEPTED = 'mova:deployment-accepted:v1';

export function loadAccepted(kv: KeyValue): DeploymentSummary | undefined {
  const raw = kv.get(ACCEPTED);
  if (!raw) return undefined;
  try {
    const v = JSON.parse(raw) as unknown;
    if (!v || typeof v !== 'object' || Array.isArray(v) || Object.values(v).some((x) => typeof x !== 'string')) return undefined;
    return v as DeploymentSummary;
  } catch {
    return undefined;
  }
}

export const saveAccepted = (kv: KeyValue, d: AppDeployment): void => kv.set(ACCEPTED, JSON.stringify(summarize(d)));

export type DeploymentVerdict =
  | { kind: 'use'; pinned: 'canonical' | 'unpinned' }
  | {
    kind: 'confirm';
    /** 'unpinned': the chain has no canonical record, and the user is warned before anything else. */
    pinned: 'canonical' | 'unpinned';
    /** What differs from the deployment last accepted on this device; empty when none was. */
    changes: DeploymentChange[];
    /** Whether this device had accepted a deployment before. */
    hadAccepted: boolean;
  };

/**
 * Whether `d` may be used now, or needs the user's confirmation first. Throws `DeploymentNotCanonical` when it
 * contradicts its chain's canonical record: no confirmation can accept that.
 */
export function assessDeployment(d: AppDeployment, accepted: DeploymentSummary | undefined, table?: Readonly<Record<number, CanonicalDeployment>>): DeploymentVerdict {
  const pinned = checkCanonical(d, table);
  if (accepted) {
    const changes = diffSummaries(accepted, summarize(d));
    return changes.length === 0 ? { kind: 'use', pinned } : { kind: 'confirm', pinned, changes, hadAccepted: true };
  }
  return pinned === 'canonical' ? { kind: 'use', pinned } : { kind: 'confirm', pinned, changes: [], hadAccepted: false };
}
