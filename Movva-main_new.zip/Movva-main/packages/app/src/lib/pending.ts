/**
 * What the screens say about money on its way in or out of the shielded balance: a sale that stopped half-way (what
 * happened, what is left, how much, and what can be done now), Movva sitting in the open that can be put back, a
 * re-shielded note the ASP has not approved yet, and the privacy cost of a sale funded from several notes.
 *
 * Pure, so every state is tested without a wallet (test/pending.test.ts). The rules that keep the money safe are the
 * wallet's - it reads the chain before it sends anything, and never exits or opens twice. What this decides is which
 * buttons a screen offers: none while a call on that sale is running on this device, and none while an exit's proof
 * may still land (`waitingForRelayer`), so nothing on the screen invites the user to send it again.
 */
import { formatReais, type MovvaBalance, type PendingSaleStage, type ResumedSale } from '@mova/wallet';
import type { OrderActivity, PendingSaleItem, ReshieldActivity, SaleActivity } from '../wallet/port.js';
import { formatDateTime, formatIsoDate, type Tone } from './format.js';
import { SALE_REFUSALS } from './refusals.js';

/*----------------------------- sales in progress ------------------------------*/

export type PendingAction = 'continue' | 'cancel' | 'reshield';

export const PENDING_ACTION_LABEL: Record<PendingAction, { idle: string; busy: string }> = {
  continue: { idle: 'Continuar venda', busy: 'Continuando a venda...' },
  cancel: { idle: 'Cancelar e devolver ao saldo', busy: 'Cancelando e devolvendo ao saldo...' },
  reshield: { idle: 'Devolver ao saldo protegido', busy: 'Devolvendo ao saldo protegido...' },
};

export interface PendingSaleView {
  /** `Venda por PIX · R$ 10,00` */
  title: string;
  badge: { label: string; tone: Tone };
  /** What happened. */
  happened: string;
  /** What is left. */
  left?: string;
  /** How much. */
  figures: { label: string; value: string }[];
  /** What the user can do now. Empty while nothing should be sent. */
  actions: PendingAction[];
}

const lowerFirst = (s: string) => s.charAt(0).toLowerCase() + s.slice(1);

/** Why a sale was given up, as the end of a sentence: "você cancelou", "o preço mudou". */
export function givenUpReason(reason: NonNullable<PendingSaleItem['givenUp']>): string {
  return reason === 'cancelled' ? 'você cancelou' : lowerFirst(SALE_REFUSALS[reason].title);
}

const STAGES: Record<Exclude<PendingSaleStage, 'reshielding'>, { label: string; tone: Tone; happened: string; left: string }> = {
  exiting: {
    label: 'Saída não confirmada', tone: 'info',
    happened: 'A saída do seu saldo para a conta desta venda foi enviada ao relayer, ou estava para ser, e este aparelho não chegou a vê-la na blockchain.',
    left: 'Falta confirmar a saída, abrir a venda e enviar o destinatário aos provedores. A carteira consulta a blockchain antes de enviar qualquer coisa: uma saída que ainda pode entrar nunca é enviada de novo.',
  },
  exited: {
    label: 'Venda não aberta', tone: 'warn',
    happened: 'Os Movva saíram do seu saldo para a conta desta venda, mas a venda não chegou a ser aberta.',
    left: 'Falta abrir a venda e enviar o destinatário aos provedores.',
  },
  opening: {
    label: 'Abertura não confirmada', tone: 'warn',
    happened: 'Os Movva saíram do seu saldo para a conta desta venda e a abertura foi pedida, mas este aparelho não viu a venda aberta na blockchain.',
    left: 'Falta abrir a venda (a carteira procura antes a venda já aberta, para nunca abrir duas) e enviar o destinatário aos provedores.',
  },
  open: {
    label: 'Sem provedor', tone: 'warn',
    happened: 'A venda está aberta, mas nenhum provedor recebeu o destinatário, então ninguém pode pagá-la.',
    left: 'Falta enviar o destinatário aos provedores de novo.',
  },
};

export function pendingSaleView(p: PendingSaleItem): PendingSaleView {
  const bill = p.rail === 'boleto';
  const title = `${bill ? 'Pagamento de boleto' : 'Venda por PIX'} · ${p.receiveFormatted}`;
  const figures = [
    { label: bill ? 'Valor do boleto' : 'Chega por PIX', value: p.receiveFormatted },
    { label: 'Já saiu do seu saldo', value: p.exited > 0n ? p.exitedFormatted : 'nada confirmado ainda' },
    ...(p.notes > 1 ? [{ label: 'Notas usadas', value: String(p.notes) }] : []),
    ...(p.dueDate ? [{ label: 'Vencimento', value: formatIsoDate(p.dueDate) }] : []),
    { label: 'Iniciada em', value: formatDateTime(p.createdAt) },
  ];
  if (p.busy) {
    return {
      title, figures, actions: [], badge: { label: 'Em andamento', tone: 'info' },
      happened: 'Esta venda está sendo feita agora neste aparelho. Espere a operação terminar.',
    };
  }
  if (p.waitingForRelayer) {
    return {
      title, figures, actions: [], badge: { label: 'Aguardando o relayer', tone: 'info' },
      happened: 'A prova da saída do seu saldo está com o relayer, e a saída ainda pode entrar na blockchain.',
      left: p.waitingForRelayer === 'continue'
        ? 'Nada é enviado de novo enquanto isso. A carteira consulta a blockchain a cada atualização e continua a venda quando a saída entrar, ou quando ela não puder mais entrar.'
        : 'Nada é enviado de novo enquanto isso. A carteira consulta a blockchain a cada atualização e devolve ao saldo o que tiver saído dele quando a saída entrar, ou quando ela não puder mais entrar.',
    };
  }
  if (p.stage === 'reshielding') {
    return {
      title, figures, actions: ['reshield'], badge: { label: 'Voltando ao saldo', tone: 'warn' },
      happened: `A venda foi desfeita: ${givenUpReason(p.givenUp ?? 'cancelled')}. Os Movva ainda não voltaram ao saldo protegido.`,
      left: 'Falta devolver os Movva ao saldo protegido, a partir da conta da venda.',
    };
  }
  const s = STAGES[p.stage];
  return { title, figures, actions: ['continue', 'cancel'], badge: { label: s.label, tone: s.tone }, happened: s.happened, left: s.left };
}

export interface OutcomeView { tone: Tone; title: string; detail: string }

/** What resuming a sale came to, said once the call returns. Undefined for `exit_pending`: the sale says it itself. */
export function resumeOutcomeView(out: ResumedSale, sale: Pick<PendingSaleItem, 'receiveFormatted' | 'rail'>): OutcomeView | undefined {
  switch (out.state) {
    case 'exit_pending':
      return undefined;
    case 'abandoned':
      return { tone: 'info', title: 'Nada saiu do seu saldo', detail: 'Nenhuma saída desta venda entrou na blockchain, e nenhuma pode mais entrar: a venda foi descartada e o seu saldo não mudou.' };
    case 'open':
      return out.disclosedTo > 0
        ? {
          tone: 'ok', title: 'Venda aberta',
          detail: `A venda de ${sale.receiveFormatted} está aberta, e ${out.disclosedTo === 1 ? 'um provedor recebeu' : `${out.disclosedTo} provedores receberam`} o destinatário. Acompanhe em Vender.`,
        }
        : { tone: 'warn', title: 'Venda aberta, sem provedor', detail: 'A venda está aberta, mas nenhum provedor recebeu o destinatário. Continue a venda de novo daqui a pouco, ou cancele.' };
    case 'claimed':
      return { tone: 'ok', title: 'Um provedor já está pagando', detail: `Um provedor já tinha o destinatário e assumiu a venda de ${sale.receiveFormatted}. Acompanhe em Vender.` };
    case 'settled':
      return { tone: 'ok', title: sale.rail === 'boleto' ? 'Boleto pago' : 'PIX enviado', detail: `Um provedor já tinha pago a venda de ${sale.receiveFormatted}.` };
    case 'disputed':
      return { tone: 'warn', title: 'Em disputa', detail: 'Um provedor assumiu a venda e o pagamento está sendo analisado pela arbitragem. Acompanhe em Vender.' };
    case 'reshielded':
      return reshieldedView(out.reshielded);
  }
}

/*----------------------------- Movva in the open ------------------------------*/

/** A delivery taken in the open goes back from the user's own account: said in one sentence before the button. */
export const DELIVERY_RESHIELD_VISIBLE =
  'O depósito de volta sai da sua própria conta, a mesma que travou este pedido, então fica visível na blockchain como seu; só o que você fizer depois com a nota fica protegido.';

/** A sale's Movva goes back from the sale account, which is not the user's. */
export const SALE_RESHIELD_UNLINKED = 'O depósito de volta sai da conta desta venda, uma conta nova, e não liga a venda às suas compras.';

export function reshieldedView(r: { amount: bigint; fee: bigint; awaitingApproval: boolean }): OutcomeView {
  return {
    tone: 'ok', title: 'Devolvido ao saldo protegido',
    detail: `${formatReais(r.amount)} voltaram ao saldo protegido (taxa do pool: ${formatReais(r.fee)}).${r.awaitingApproval
      ? ' Até a ASP aprovar o depósito, esse valor aparece como aguardando aprovação e não pode ser vendido.' : ''}`,
  };
}

/**
 * Orders delivered in the open and sales refunded to their sale account, that this device has not put back yet. A sale
 * still in progress is left out: its own card offers the way back.
 */
export function inTheOpen(a: { orders: OrderActivity[]; sales: SaleActivity[]; reshields: ReshieldActivity[]; pending: PendingSaleItem[] }): {
  orders: OrderActivity[]; sales: SaleActivity[];
} {
  const putBack = new Set(a.reshields.map((r) => r.ref.toLowerCase()));
  const inProgress = new Set(a.pending.flatMap((p) => (p.saleId ? [p.saleId.toLowerCase()] : [])));
  return {
    orders: a.orders.filter((o) => o.status?.state === 'delivered_in_the_open' && !putBack.has(o.orderId.toLowerCase())),
    sales: a.sales.filter((s) => s.status?.state === 'cancelled' && !putBack.has(s.saleId.toLowerCase()) && !inProgress.has(s.saleId.toLowerCase())),
  };
}

/*----------------------------- the balance ------------------------------*/

export interface BalanceFigures {
  /** What can be spent now: available, less re-shielded notes the ASP has not approved. */
  spendableFormatted: string;
  /** Present while a re-shielded note awaits the ASP. Part of the total, not of what can be spent. */
  awaitingApproval?: string;
  /** Present while sales are in progress: what their exits took out of available so far. In no other figure. */
  inSales?: { formatted: string; count: number };
}

export function balanceFigures(b: MovvaBalance): BalanceFigures {
  const p = b.pending;
  const awaiting = p ? BigInt(p.awaitingApproval) : 0n;
  const spendable = BigInt(b.available) - awaiting;
  return {
    spendableFormatted: awaiting > 0n ? formatReais(spendable < 0n ? 0n : spendable) : b.availableFormatted,
    ...(p && awaiting > 0n ? { awaitingApproval: p.awaitingApprovalFormatted } : {}),
    ...(p && p.salesInProgress > 0 ? { inSales: { formatted: p.inSalesFormatted, count: p.salesInProgress } } : {}),
  };
}

/** "Detalhes técnicos" beside a balance awaiting approval. */
export const AWAITING_APPROVAL_EXPLAINED =
  'Devolver Movva ao saldo protegido é um depósito novo no pool, que cria uma nota nova. O pool só aceita a prova de saque de uma nota cujo rótulo (label) '
  + 'a ASP, o conjunto de associação, já aprovou: a prova é feita contra a raiz que a ASP publica na blockchain. Até a aprovação, a nota conta no seu total, '
  + 'mas nenhuma venda ou saque pode usá-la. Se a ASP nunca a aprovar, a conta que depositou pode retirar o valor pelo ragequit, em público.';

export const IN_SALES_EXPLAINED =
  'Saiu do disponível para vendas que ainda não terminaram e não entra no total: vira pagamento quando a venda terminar, ou volta ao saldo se ela for desfeita.';

/*----------------------------- several notes ------------------------------*/

/** The privacy cost of funding one sale from several notes, in one sentence, beside the opt-in. */
export const SEVERAL_NOTES_COST =
  'Cada nota sai do seu saldo numa saída separada para a mesma conta de venda, então quem observa a blockchain fica sabendo que essas saídas são de uma mesma pessoa, e cada uma paga a tarifa do relayer.';
