/**
 * JSON that keeps bigints: the wallet's records, the relayer's receipts and the dev stack's answers all carry them.
 * A bigint is written as `{ "$bigint": "123" }` and read back as `123n`.
 */
export function stringify(value: unknown, space?: number): string {
  return JSON.stringify(value, (_k, v: unknown) => (typeof v === 'bigint' ? { $bigint: v.toString() } : v), space);
}

export function parse<T = unknown>(text: string): T {
  return JSON.parse(text, (_k, v: unknown) => {
    if (v && typeof v === 'object' && !Array.isArray(v)) {
      const keys = Object.keys(v);
      const big = (v as { $bigint?: unknown }).$bigint;
      if (keys.length === 1 && typeof big === 'string' && /^-?\d+$/.test(big)) return BigInt(big);
    }
    return v;
  }) as T;
}
