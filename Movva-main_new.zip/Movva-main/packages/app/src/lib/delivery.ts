/**
 * The delivery escape hatch in Portuguese: why a shielded delivery would be refused now (the reads and the blocks are
 * src/wallet/delivery-check.ts), what to do, and the one-sentence privacy cost of taking the Movva in the open.
 */
import { UNITS_PER_CENTAVO, ceilDiv, formatReais, reaisAtPar } from '@mova/wallet';
import type { OrderActivity } from '../wallet/port.js';
import type { DeliveryBlock, FrozenParty } from '../wallet/delivery-check.js';

export type { DeliveryBlock, DeliveryCheck, FrozenParty } from '../wallet/delivery-check.js';

/** Orders waiting to be released whose shielded delivery the pool would refuse, as last read. */
export function blockedDeliveries(orders: OrderActivity[]): OrderActivity[] {
  return orders.filter((o) => o.delivery?.pending === true && o.delivery.delivery === 'shielded' && o.delivery.blocks.length > 0);
}

const PARTY: Record<FrozenParty, string> = {
  escrow: 'o escrow de compra', account: 'a sua conta', entrypoint: 'o Entrypoint do Privacy Pools', pool: 'o pool de Movva',
};

export function deliveryBlockText(b: DeliveryBlock): string {
  switch (b.kind) {
    case 'pool_not_registered':
      return 'O pool de Movva não está mais registrado no Entrypoint do Privacy Pools: não há onde depositar.';
    case 'pool_changed':
      return 'O Entrypoint do Privacy Pools registra agora outro pool para o Movva, não o desta carteira: o depósito cairia onde a carteira não procura.';
    case 'pool_wound_down':
      return 'O pool de Movva foi encerrado e não aceita mais depósitos.';
    case 'below_pool_minimum':
      // The minimum rounded up and the amount down: never "a minimum of R$ 1,00 above R$ 1,00".
      return `O pool de Movva exige agora um depósito mínimo de ${formatReais(ceilDiv(b.minimum, UNITS_PER_CENTAVO))}, acima dos ${formatReais(reaisAtPar(b.amount))} em Movva a depositar: o depósito seria recusado.`;
    case 'frozen':
      return `O emissor do token bloqueou ${PARTY[b.party]}: o depósito seria recusado, ou os Movva ficariam congelados no pool.`;
  }
}

export const DELIVERY_BLOCKED_TITLE = 'A entrega no saldo protegido não é possível agora';

export const DELIVERY_BLOCKED_EXPLAINED =
  'Este pedido foi travado para entregar os Movva no seu saldo protegido, e o depósito no pool seria recusado agora. Se você ainda não pagou, '
  + 'não pague: cancele o pedido, o que é gratuito. Se já pagou, o provedor não consegue liberar os Movva e, quando o prazo acabar, o pedido volta '
  + 'para ele: receba os Movva fora do saldo protegido.';

/** The privacy cost of taking delivery in the open, in one sentence, beside the button. */
export const DIRECT_DELIVERY_COST =
  'Os Movva chegam à sua própria conta, a mesma que travou o pedido, visíveis na blockchain como seus, e só voltam ao saldo protegido com um depósito que também aparece como seu.';

export const DIRECT_DELIVERY_REFUSED =
  'O emissor do token bloqueou o escrow ou a sua conta, então receber fora do saldo protegido também seria recusado: nada pode ser liberado agora.';

export const DIRECT_DELIVERY_CHOSEN =
  'Você escolheu receber fora do saldo protegido: o provedor libera os Movva para a sua conta assim que provar o pagamento.';
