import { useEffect, useState } from 'react';
import type { Reais } from '@mova/wallet';
import { formatBRL, parseAmountInput } from '../lib/format.js';
import { balanceFigures } from '../lib/pending.js';
import { ErrorNotice, Field, Notice, Row, Spinner } from './components.js';
import { yieldText } from './Home.js';
import { useAction, useAsync, useWallet } from './hooks.js';

export function Savings() {
  const w = useWallet();
  const balance = useAsync(() => w.balance(), [w]);
  const [tab, setTab] = useState<'save' | 'withdraw'>('save');
  const [input, setInput] = useState('');
  const [all, setAll] = useState(false);
  const save = useAction(async () => w.save(parseAmountInput(input)));
  const withdraw = useAction(async () => w.withdrawSavings(all ? 'all' : parseAmountInput(input)));
  const action = tab === 'save' ? save : withdraw;
  const { reload } = balance;
  useEffect(() => { if (save.result || withdraw.result) reload(); }, [save.result, withdraw.result, reload]);

  let preview: Reais | undefined;
  try {
    preview = input.trim() ? parseAmountInput(input) : undefined;
  } catch {
    preview = undefined;
  }
  const b = balance.data;
  return (
    <>
      <h1>Poupança</h1>
      {b ? (
        <div className="card">
          <Row label="Na poupança" value={b.savings.formatted} strong />
          <Row label="Custo do que foi guardado" value={b.savings.costFormatted} />
          <Row label="Rendimento" value={yieldText(b)} />
          <Row label="Disponível para guardar" value={balanceFigures(b).spendableFormatted} />
        </div>
      ) : balance.error ? <ErrorNotice error={balance.error} onAction={reload} /> : <Spinner label="Lendo a poupança..." />}
      <p className="faint">A poupança rende com a distribuição do excedente das reservas. As tarifas entram no custo, então aparecem como rendimento negativo até o rendimento cobri-las. Para o imposto, o rendimento é reconhecido no resgate.</p>

      <div className="tabs" role="tablist">
        <button type="button" role="tab" className="tab" aria-selected={tab === 'save'} onClick={() => setTab('save')}>Guardar</button>
        <button type="button" role="tab" className="tab" aria-selected={tab === 'withdraw'} onClick={() => setTab('withdraw')}>Resgatar</button>
      </div>
      <form className="card" onSubmit={(e) => { e.preventDefault(); void action.run(); }}>
        <Field label={tab === 'save' ? 'Quanto guardar?' : 'Quanto resgatar?'}>
          <input className="amount-input" inputMode="decimal" placeholder="R$ 0,00" aria-label="Valor" value={input} disabled={tab === 'withdraw' && all}
            onChange={(e) => { setInput(e.target.value); save.reset(); withdraw.reset(); }} />
        </Field>
        {tab === 'withdraw' && (
          <label className="field" style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <input type="checkbox" style={{ width: 'auto' }} checked={all} onChange={(e) => setAll(e.target.checked)} />
            <span style={{ margin: 0 }}>Resgatar uma nota inteira da poupança</span>
          </label>
        )}
        <Row label="Tarifa do relayer" value={<span data-testid="relay-fee">{formatBRL(w.zapRelayFee)}</span>} />
        {tab === 'save' && preview !== undefined && preview > w.zapRelayFee && (
          <Row label="Vai para a poupança (antes do preço da cota)" value={formatBRL(preview - w.zapRelayFee)} />
        )}
        {tab === 'withdraw' && preview !== undefined && !all && preview > w.zapRelayFee && (
          <Row label="Volta ao disponível" value={formatBRL(preview - w.zapRelayFee)} />
        )}
        <p className="faint">Quem envia a transação é o relayer, pago pela tarifa acima: sua conta não aparece. Cada movimentação usa uma nota do saldo por vez.</p>
        {action.busy
          ? <Spinner label="Gerando a prova neste aparelho (pode levar até um minuto)..." />
          : <button type="submit">{tab === 'save' ? 'Guardar' : 'Resgatar'}</button>}
      </form>
      <ErrorNotice error={action.error} onAction={() => void action.run()} />
      {save.result && tab === 'save' && (
        <Notice tone="ok" title="Guardado">
          <p>{save.result.formatted} saíram do disponível para a poupança, incluindo a tarifa de {save.result.feeFormatted}.</p>
        </Notice>
      )}
      {withdraw.result && tab === 'withdraw' && (
        <Notice tone="ok" title="Resgatado">
          <p>Cotas no valor de {withdraw.result.formatted} voltaram ao disponível, menos a tarifa de {withdraw.result.feeFormatted}.</p>
        </Notice>
      )}
    </>
  );
}
