import { useEffect, useRef, useState } from 'react';
import type { Hex } from 'viem';
import { MAX_NOTES_PER_SALE, SaleRefused, type SaleQuote } from '@mova/wallet';
import { brasiliaIsoDate, formatBRL, formatIsoDate, parseAmountInput, saleStatusView } from '../lib/format.js';
import { SEVERAL_NOTES_COST } from '../lib/pending.js';
import { ErrorNotice, Field, Notice, Row, Spinner, StatusBadge } from './components.js';
import { useAction, useActivity, useAsync, useInterval, useWallet } from './hooks.js';
import { PendingSalesCard, ReshieldSale } from './PendingSales.js';
import { SaleInterrupted } from '../wallet/sale-errors.js';

type Detector = new (o: { formats: string[] }) => { detect(source: HTMLVideoElement): Promise<{ rawValue: string }[]> };
const barcodeDetector = (): Detector | undefined => (globalThis as { BarcodeDetector?: Detector }).BarcodeDetector;
const canScan = (): boolean => !!barcodeDetector() && !!globalThis.navigator?.mediaDevices?.getUserMedia;

/** Reads a boleto's barcode (Interleaved 2 of 5, 44 digits) with the camera, where the browser has BarcodeDetector. */
function BarcodeScanner({ onDetected }: { onDetected: (barcode: string) => void }) {
  const video = useRef<HTMLVideoElement>(null);
  const callback = useRef(onDetected);
  callback.current = onDetected;
  const [error, setError] = useState<string>();
  useEffect(() => {
    let stream: MediaStream | undefined;
    let stopped = false;
    void (async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
        if (!video.current || stopped) return;
        video.current.srcObject = stream;
        await video.current.play();
        const detector = new (barcodeDetector()!)({ formats: ['itf'] });
        while (!stopped) {
          const hit = (await detector.detect(video.current)).find((c) => /^\d{44}$/.test(c.rawValue));
          if (hit) {
            callback.current(hit.rawValue);
            return;
          }
          await new Promise((r) => setTimeout(r, 350));
        }
      } catch {
        setError('Não foi possível usar a câmera. Cole a linha digitável.');
      }
    })();
    return () => {
      stopped = true;
      stream?.getTracks().forEach((t) => t.stop());
    };
  }, []);
  return error ? <Notice tone="warn">{error}</Notice> : <video ref={video} playsInline muted style={{ width: '100%', borderRadius: 10 }} />;
}

/** As many notes as the wallet allows, once the user opts in: it still uses one whenever one funds the sale. */
const ACROSS_NOTES = { maxNotes: MAX_NOTES_PER_SALE };

/**
 * Several notes for one sale, opt-in and off by default: offered once the largest note cannot fund the sale, beside what
 * it costs in privacy, and kept on screen while chosen so it can be turned off again.
 */
export function SeveralNotesOption({ error, checked, onChange }: { error: unknown; checked: boolean; onChange: (checked: boolean) => void }) {
  if (!checked && !(error instanceof SaleRefused && error.code === 'note_too_small')) return null;
  return (
    <div className="card" data-testid="several-notes">
      <label className="field" style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 6 }}>
        <input type="checkbox" style={{ width: 'auto' }} checked={checked} onChange={(e) => onChange(e.target.checked)} />
        <span style={{ margin: 0 }}>Usar várias notas</span>
      </label>
      <p className="faint">{SEVERAL_NOTES_COST}</p>
    </div>
  );
}

function NotesUsed({ quote }: { quote: SaleQuote }) {
  if (!quote.notes || quote.notes < 2) return null;
  return <Row label="Notas do seu saldo" value={<span data-testid="sale-notes">{quote.notes} notas</span>} />;
}

function PixSale({ onOpened }: { onOpened: (saleId: Hex) => void }) {
  const w = useWallet();
  const [amount, setAmount] = useState('');
  const [pixKey, setPixKey] = useState('');
  const [several, setSeveral] = useState(false);
  const quote = useAction(async (acrossNotes: boolean = several) => (acrossNotes
    ? w.quoteSale(parseAmountInput(amount), { acrossNotes: ACROSS_NOTES })
    : w.quoteSale(parseAmountInput(amount))));
  const sell = useAction(async () => {
    const sale = await w.sell({ receive: parseAmountInput(amount), pixKey: pixKey.trim(), ...(several ? { acrossNotes: ACROSS_NOTES } : {}) });
    onOpened(sale.saleId);
    return sale;
  });
  const chooseSeveral = (on: boolean) => {
    setSeveral(on);
    quote.reset();
    sell.reset();
    void quote.run(on);
  };
  return (
    <>
      <form className="card" onSubmit={(e) => { e.preventDefault(); void quote.run(); }}>
        <Field label="Quanto deve chegar por PIX?">
          <input className="amount-input" inputMode="decimal" placeholder="R$ 0,00" aria-label="Valor a receber" value={amount}
            onChange={(e) => { setAmount(e.target.value); setSeveral(false); quote.reset(); sell.reset(); }} />
        </Field>
        <Field label="Chave PIX de destino" hint="CPF, CNPJ, e-mail, telefone (+55...) ou chave aleatória.">
          <input value={pixKey} aria-label="Chave PIX" autoComplete="off" onChange={(e) => { setPixKey(e.target.value); sell.reset(); }} />
        </Field>
        <button type="submit" disabled={quote.busy}>{quote.busy ? 'Cotando...' : 'Cotar venda'}</button>
      </form>
      <ErrorNotice error={quote.error} onAction={() => void quote.run()} />
      <SeveralNotesOption error={quote.error} checked={several} onChange={chooseSeveral} />
      {quote.result && !sell.result && !(sell.error instanceof SaleInterrupted) && (
        <div className="card" data-testid="sale-quote">
          <Row label="Chega por PIX" value={quote.result.receiveFormatted} strong />
          <Row label="Sai do seu saldo" value={quote.result.costFormatted} />
          <Row label="Tarifas (provedor e relayer)" value={quote.result.feeFormatted} />
          <NotesUsed quote={quote.result} />
          <p className="faint">A venda sai de uma conta nova, sem ligação com as suas compras. Só os provedores de liquidez recebem a chave PIX, porque são eles que pagam.</p>
          {sell.busy
            ? <Spinner label="Gerando a prova neste aparelho e abrindo a venda (pode levar até um minuto)..." />
            : <button type="button" disabled={!pixKey.trim()} onClick={() => void sell.run()}>Vender e receber {quote.result.receiveFormatted}</button>}
        </div>
      )}
      <ErrorNotice error={sell.error} onAction={() => void sell.run()} />
    </>
  );
}

function BoletoSale({ onOpened }: { onOpened: (saleId: Hex) => void }) {
  const w = useWallet();
  const [line, setLine] = useState('');
  const [scanning, setScanning] = useState(false);
  const [several, setSeveral] = useState(false);
  const quote = useAction(async (acrossNotes: boolean = several) => (acrossNotes
    ? w.quoteSale({ boletoLine: line.trim() }, { acrossNotes: ACROSS_NOTES })
    : w.quoteSale({ boletoLine: line.trim() })));
  const sell = useAction(async () => {
    const sale = await w.sell({ boletoLine: line.trim(), ...(several ? { acrossNotes: ACROSS_NOTES } : {}) });
    onOpened(sale.saleId);
    return sale;
  });
  const chooseSeveral = (on: boolean) => {
    setSeveral(on);
    quote.reset();
    sell.reset();
    void quote.run(on);
  };
  return (
    <>
      <form className="card" onSubmit={(e) => { e.preventDefault(); void quote.run(); }}>
        <Field label="Boleto a pagar" hint="O valor e o vencimento vêm do próprio boleto.">
          <textarea value={line} aria-label="Linha digitável" placeholder="Cole a linha digitável ou o código de barras"
            onChange={(e) => { setLine(e.target.value); setSeveral(false); quote.reset(); sell.reset(); }} />
        </Field>
        {canScan() && (
          <div className="actions" style={{ marginTop: 0, marginBottom: 12 }}>
            <button type="button" className="secondary" onClick={() => setScanning((s) => !s)}>{scanning ? 'Parar a leitura' : 'Ler o código de barras com a câmera'}</button>
          </div>
        )}
        {scanning && <BarcodeScanner onDetected={(code) => { setLine(code); setScanning(false); setSeveral(false); quote.reset(); }} />}
        <button type="submit" disabled={quote.busy || !line.trim()}>{quote.busy ? 'Conferindo...' : 'Conferir boleto'}</button>
      </form>
      <ErrorNotice error={quote.error} onAction={() => void quote.run()} />
      <SeveralNotesOption error={quote.error} checked={several} onChange={chooseSeveral} />
      {quote.result && !sell.result && !(sell.error instanceof SaleInterrupted) && (
        <div className="card" data-testid="bill-quote">
          <Row label="Valor do boleto" value={quote.result.receiveFormatted} strong />
          {quote.result.dueDate && <Row label="Vencimento" value={formatIsoDate(quote.result.dueDate)} />}
          <Row label="Sai do seu saldo" value={quote.result.costFormatted} />
          <Row label="Tarifas (provedor e relayer)" value={quote.result.feeFormatted} />
          <NotesUsed quote={quote.result} />
          <p className="faint">Um provedor de liquidez paga o boleto pelo valor exato dele e prova o pagamento. Boleto vencido não é pago: se vencer antes, cancele a venda.</p>
          {sell.busy
            ? <Spinner label="Gerando a prova neste aparelho e abrindo a venda (pode levar até um minuto)..." />
            : <button type="button" onClick={() => void sell.run()}>Pagar boleto de {quote.result.receiveFormatted}</button>}
        </div>
      )}
      <ErrorNotice error={sell.error} onAction={() => void sell.run()} />
    </>
  );
}

export function SaleTracker({ saleId }: { saleId: Hex }) {
  const w = useWallet();
  useActivity(w);
  const sale = w.sales().find((s) => s.saleId.toLowerCase() === saleId.toLowerCase());
  const status = useAsync(() => w.saleStatus(saleId), [w, saleId]);
  const now = w.now();
  const view = status.data ? saleStatusView(status.data, now, brasiliaIsoDate(now)) : undefined;
  useInterval(status.reload, view?.done ? null : 4_000);
  const inProgress = w.pendingSales().some((p) => p.saleId?.toLowerCase() === saleId.toLowerCase());
  // Cancelling refunds the sale account, in the open: the same tap deposits it back into the shielded balance.
  const cancel = useAction(async () => {
    try {
      return await w.reshieldSale(saleId);
    } finally {
      status.reload();
    }
  });
  const bill = (sale?.rail ?? status.data?.rail) === 'boleto';
  return (
    <div className="card" data-testid="sale">
      <div className="row">
        <span className="label">{bill ? 'Pagamento de boleto' : 'Venda por PIX'} · {formatBRL(sale?.receive ?? status.data?.receive ?? 0n)}</span>
        {view ? <StatusBadge view={view} /> : <Spinner label="" />}
      </div>
      {view?.detail && <p className="muted">{view.detail}</p>}
      {sale && <Row label={bill ? 'Boleto' : 'Chave PIX'} value={<span className="mono">{sale.payee}</span>} />}
      {sale && <Row label="Saiu do saldo" value={formatBRL(sale.cost)} />}
      {sale && sale.disclosedTo === 0 && status.data?.state === 'open' && (
        <Notice tone="warn" title="Nenhum provedor recebeu o destinatário">
          <p>Sem o destinatário, ninguém pode pagar esta venda. Continue a venda em Vendas em andamento para enviá-lo de novo, ou cancele.</p>
        </Notice>
      )}
      {status.data?.state === 'open' && sale && (
        <div className="actions">
          <button type="button" className="secondary" disabled={cancel.busy} onClick={() => void cancel.run()}>
            {cancel.busy ? 'Cancelando e devolvendo ao saldo...' : 'Cancelar e devolver ao saldo'}
          </button>
        </div>
      )}
      {status.data?.state === 'cancelled' && sale && !inProgress && <ReshieldSale saleId={saleId} />}
      <ErrorNotice error={cancel.error ?? status.error} />
    </div>
  );
}

export function Sell() {
  const w = useWallet();
  useActivity(w);
  const [tab, setTab] = useState<'pix' | 'boleto'>('pix');
  const [opened, setOpened] = useState<Hex>();
  const others = w.sales().filter((s) => s.saleId !== opened).slice(0, 5);
  return (
    <>
      <h1>Vender Movva</h1>
      <p className="muted">Receba reais por PIX ou pague um boleto com o seu saldo.</p>
      <PendingSalesCard poll />
      <div className="tabs" role="tablist">
        <button type="button" role="tab" className="tab" aria-selected={tab === 'pix'} onClick={() => setTab('pix')}>Enviar por PIX</button>
        <button type="button" role="tab" className="tab" aria-selected={tab === 'boleto'} onClick={() => setTab('boleto')}>Pagar boleto</button>
      </div>
      {tab === 'pix' ? <PixSale onOpened={setOpened} /> : <BoletoSale onOpened={setOpened} />}
      {opened && <SaleTracker saleId={opened} />}
      {others.length > 0 && <h2>Vendas anteriores</h2>}
      {others.map((s) => <SaleTracker key={s.saleId} saleId={s.saleId} />)}
    </>
  );
}
