import { useEffect, useState } from 'react';
import { isSmartAccount, type AppDeployment, type SmartAccountKind } from '../lib/deployment.js';
import {
  PrfUnsupported, createWithPasskey, discardLegacyIdentity, hasLegacyIdentity, loadIdentity, passkeySupport, prfSupport, unlockWithPasskey,
  type StoredIdentity,
} from '../passkey/seed.js';
import type { KeyValue } from '../wallet/stores.js';
import { ErrorNotice, Field, Notice, Spinner } from './components.js';
import { useAction } from './hooks.js';
import { ReserveRisksCard } from './ReserveRisks.js';

export const RECOVERY_EXPLAINED =
  'Sua carteira não tem senha nem frase secreta. A chave dela é calculada pela sua passkey cada vez que você desbloqueia, e nunca fica gravada neste aparelho. '
  + 'Se perder o aparelho, abra o app em outro com a mesma passkey (sincronizada pela sua conta Google ou Apple, pelo seu gerenciador de senhas, ou uma chave de segurança física): '
  + 'a carteira recalcula a mesma chave, reencontra seus saldos na blockchain e baixa o seu histórico, criptografado, do cofre de notas. '
  + 'Se perder a única passkey e ela não estiver sincronizada em lugar nenhum, o acesso à carteira se perde.';

/** What one factor alone can and cannot do (docs/wallet-custody.md §3), for a smart account. */
export const ONE_FACTOR_EXPLAINED =
  'O que cada parte faz sozinha: a passkey abre a carteira. Quem tiver a sua passkey pode sacar na hora o saldo privado já aprovado, '
  + 'e pode pedir uma recuperação da conta, que só se cumpre depois de 7 dias, aparece no app e pode ser vetada. '
  + 'Movimentar a conta na hora exige a passkey e o cossignatário da Movva juntos. O cossignatário sozinho não move nada. '
  + 'Este aparelho, sem a passkey, não abre nada: a chave não fica gravada nele.';

/** The same, for a deployment whose account is a plain EOA (local stacks). */
export const ONE_FACTOR_EXPLAINED_EOA =
  'O que cada parte faz sozinha: nesta rede a conta é simples (EOA), derivada da passkey, e a passkey sozinha move todo o saldo. '
  + 'Este aparelho, sem a passkey, não abre nada: a chave não fica gravada nele.';

export const NO_PRF_EXPLAINED =
  'A carteira Movva só funciona com uma passkey que ofereça a extensão PRF, que calcula a chave da carteira. '
  + 'Este navegador ou autenticador não a oferece, e não há outro caminho. '
  + 'Use outro navegador ou aparelho, atualizado, ou uma chave de segurança física com PRF.';

export const LEGACY_WALLET_EXPLAINED =
  'Esta carteira foi criada sem PRF, com código de recuperação. Esse caminho foi removido porque uma parte guardada neste navegador bastava para abri-la, '
  + 'e esta versão do app não abre a carteira. Ela só existiu em redes de teste (Sepolia ou local). '
  + 'Se havia saldo nela, mova-o com uma versão anterior do app e o seu código. Depois apague a carteira deste navegador e crie outra com uma passkey com PRF.';

export interface OnboardingProps {
  deployment: AppDeployment;
  kv: KeyValue;
  opening: boolean;
  error?: unknown;
  onUnlocked: (seed: Uint8Array, identity: StoredIdentity) => void;
}

export function Onboarding({ deployment, kv, opening, error, onUnlocked }: OnboardingProps) {
  const [identity, setIdentity] = useState(() => loadIdentity(kv));
  const [legacy, setLegacy] = useState(() => hasLegacyIdentity(kv));
  const [prf, setPrf] = useState<boolean | undefined>(undefined);
  const support = passkeySupport();
  const smart = isSmartAccount(deployment.account) ? deployment.account : undefined;
  const [accountKind, setAccountKind] = useState<SmartAccountKind | undefined>(smart?.kind);

  useEffect(() => {
    let live = true;
    if (support.available) void prfSupport().then((v) => { if (live) setPrf(v); });
    return () => { live = false; };
  }, [support.available]);

  const create = useAction(async () => {
    const r = await createWithPasskey(kv, { accountKind });
    onUnlocked(r.seed, r.identity);
  });
  const restore = useAction(async () => {
    const r = await unlockWithPasskey(kv, identity);
    setIdentity(r.identity);
    onUnlocked(r.seed, r.identity);
  });
  const busy = opening || create.busy || restore.busy;
  const noPrf = prf === false || create.error instanceof PrfUnsupported;
  const usable = support.available && !noPrf;

  return (
    <>
      <h1>Movva</h1>
      <p className="muted">Reais protegidos: compre Movva por PIX ou boleto e venda quando quiser, com o saldo privado.</p>
      <div className="card sunken">
        <h2>Como a recuperação funciona</h2>
        <p data-testid="recovery-explained">{RECOVERY_EXPLAINED}</p>
        <p data-testid="one-factor">{smart ? ONE_FACTOR_EXPLAINED : ONE_FACTOR_EXPLAINED_EOA}</p>
      </div>
      {opening && <Spinner label="Abrindo a carteira: lendo os pools e o cofre de notas..." />}
      <ErrorNotice error={error} />

      {!support.available && (
        <Notice tone="warn" title="Passkeys indisponíveis">
          <p>{support.reason}</p>
        </Notice>
      )}
      {support.available && noPrf && (
        <Notice tone="warn" title="Passkey sem PRF">
          <p data-testid="no-prf">{NO_PRF_EXPLAINED}</p>
          {create.error instanceof PrfUnsupported && <p className="faint">A passkey que acabou de ser criada não serve para a carteira: pode apagá-la do seu gerenciador de senhas.</p>}
        </Notice>
      )}

      {legacy && (
        <div className="card" data-testid="legacy-wallet">
          <h2>Carteira antiga, sem PRF</h2>
          <Notice tone="warn" title="Este caminho foi removido">
            <p>{LEGACY_WALLET_EXPLAINED}</p>
          </Notice>
          <button type="button" className="danger" onClick={() => {
            if (confirm('Apagar a carteira antiga deste navegador? Esta versão do app não a abre de qualquer forma.')) {
              discardLegacyIdentity(kv);
              setLegacy(false);
            }
          }}>Apagar a carteira antiga deste navegador</button>
        </div>
      )}

      {!legacy && identity && (
        <div className="card">
          <h2>Desbloquear</h2>
          <button type="button" disabled={busy || !usable} onClick={() => void restore.run()}>Desbloquear com a passkey</button>
          <ErrorNotice error={restore.error} onAction={() => void restore.run()} />
        </div>
      )}

      {!legacy && !identity && <ReserveRisksCard sunken />}

      {!legacy && !identity && usable && (
        <div className="card">
          <h2>Começar</h2>
          {smart && smart.kinds.length > 1 && (
            <Field label="Tipo de conta" hint="As duas exigem a sua passkey e o cossignatário para cada operação, e têm recuperação com prazo de 7 dias. A Safe usa só contratos auditados; a Kernel depende de um validador próprio, ainda sem auditoria.">
              <select aria-label="Tipo de conta" value={accountKind} onChange={(e) => setAccountKind(e.target.value as SmartAccountKind)}>
                {smart.kinds.map((k) => <option key={k} value={k}>{k === 'safe' ? 'Safe 2-de-2 (recomendada)' : 'Kernel'}</option>)}
              </select>
            </Field>
          )}
          <div className="actions" style={{ flexDirection: 'column' }}>
            <button type="button" disabled={busy} onClick={() => void create.run()}>Criar carteira com passkey</button>
            <button type="button" className="secondary" disabled={busy} onClick={() => void restore.run()}>Já tenho: restaurar com a passkey</button>
          </div>
          <ErrorNotice error={create.error ?? restore.error} onAction={() => void restore.run()} />
        </div>
      )}
    </>
  );
}
