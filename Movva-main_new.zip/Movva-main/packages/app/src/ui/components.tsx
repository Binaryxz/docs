import { useState, type ReactNode } from 'react';
import qrcode from 'qrcode-generator';
import type { StatusView, Tone } from '../lib/format.js';
import { describeError, type SuggestedAction } from '../lib/refusals.js';

export function Notice({ tone, title, children }: { tone: Tone; title?: string; children?: ReactNode }) {
  return (
    <div className={`notice ${tone}`} role={tone === 'danger' ? 'alert' : 'status'}>
      {title && <div className="title">{title}</div>}
      {children}
    </div>
  );
}

/** A refusal or failure, in Portuguese, with the way out when there is one. */
export function ErrorNotice({ error, onAction, busy }: { error: unknown; onAction?: (action: SuggestedAction) => void; busy?: boolean }) {
  if (error === undefined || error === null) return null;
  const v = describeError(error);
  return (
    <Notice tone={v.tone} title={v.title}>
      <p>{v.detail}</p>
      {v.action && v.actionLabel && onAction && (
        <div className="actions">
          <button type="button" className={v.action === 'cancelOrder' ? 'danger' : 'secondary'} disabled={busy} onClick={() => onAction(v.action!)}>
            {v.actionLabel}
          </button>
        </div>
      )}
      {v.technical && (
        <details>
          <summary>Detalhes técnicos{v.code ? ` (${v.code})` : ''}</summary>
          <span className="mono">{v.technical}</span>
        </details>
      )}
    </Notice>
  );
}

/**
 * A QR code of `text`, drawn as one SVG path. The BR Code is encoded as its UTF-8 bytes (the library's byte mode
 * takes one char per byte).
 */
export function QrCode({ text, label }: { text: string; label: string }) {
  const qr = qrcode(0, 'M');
  qr.addData(String.fromCharCode(...new TextEncoder().encode(text)), 'Byte');
  qr.make();
  const n = qr.getModuleCount();
  const quiet = 4;
  let d = '';
  for (let r = 0; r < n; r++) {
    for (let c = 0; c < n; c++) if (qr.isDark(r, c)) d += `M${c + quiet} ${r + quiet}h1v1h-1z`;
  }
  return (
    <div className="qr">
      <svg viewBox={`0 0 ${n + 2 * quiet} ${n + 2 * quiet}`} role="img" aria-label={label} shapeRendering="crispEdges">
        <rect width="100%" height="100%" fill="#fff" />
        <path d={d} fill="#000" />
      </svg>
    </div>
  );
}

export function CopyField({ label, value }: { label: string; value: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <div className="field">
      <div className="faint">{label}</div>
      <div className="copy">
        <div className="mono" data-testid={`copy-${label}`}>{value}</div>
        <button
          type="button"
          className="secondary"
          onClick={() => {
            void navigator.clipboard?.writeText(value).then(() => { setCopied(true); setTimeout(() => setCopied(false), 2_000); });
          }}
        >
          {copied ? 'Copiado' : 'Copiar'}
        </button>
      </div>
    </div>
  );
}

export function StatusBadge({ view }: { view: StatusView }) {
  return <span className={`badge ${view.tone}`}>{view.label}</span>;
}

export function Row({ label, value, strong }: { label: ReactNode; value: ReactNode; strong?: boolean }) {
  return (
    <div className={`row${strong ? ' strong' : ''}`}>
      <span className="label">{label}</span>
      <span className="value">{value}</span>
    </div>
  );
}

export function Spinner({ label }: { label: string }) {
  return <span className="spinner" role="status">{label}</span>;
}

export function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: ReactNode }) {
  return (
    <label className="field">
      <span>{label}</span>
      {children}
      {hint && <div className="faint">{hint}</div>}
    </label>
  );
}
