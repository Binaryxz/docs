import { useCallback, useEffect, useRef, useState } from 'react';
import type { Hex } from 'viem';
import { LpNodeError, PARTIAL_SHORTFALL_CENTS, PartialLock, type BuyOptions, type Rail, type RailQuote, type VerifiedPayment } from '@mova/wallet';
import { RAIL_LABEL, buyStatusView, formatBRL, formatBps, formatDateTime, formatIsoDate, parseAmountInput } from '../lib/format.js';
import { unavailableReason } from '../lib/refusals.js';
import { CopyField, ErrorNotice, Field, Notice, QrCode, Row, Spinner, StatusBadge } from './components.js';
import { useAction, useActivity, useAsync, useInterval, useWallet } from './hooks.js';
import { ReshieldDelivery } from './PendingSales.js';
import { DeliveryBlocked } from './Delivery.js';
import { DIRECT_DELIVERY_CHOSEN } from '../lib/delivery.js';

const RAILS: Rail[] = ['pix', 'boleto'];

/** "mais 1 min 20 s": what is left of a quote's validity. */
const secondsLeft = (s: number) => (s >= 60 ? `mais ${Math.floor(s / 60)} min ${s % 60} s` : `mais ${Math.max(0, s)} s`);

export function RailOptions({ options, selected, onSelect }: { options: BuyOptions; selected?: Rail; onSelect: (rail: Rail) => void }) {
  return (
    <div>
      <h2>Formas de pagamento para {options.askedFormatted}</h2>
      <IssuancePaused options={options} />
      <PartialOffer options={options} />
      {options.rails.map((q: RailQuote) => (
        <button type="button" key={q.rail} className="option" aria-pressed={selected === q.rail} onClick={() => onSelect(q.rail)} data-testid={`rail-${q.rail}`}>
          <div className="rail">{RAIL_LABEL[q.rail]}</div>
          <Row label="Valor do pedido" value={q.payFormatted} />
          <Row label="Total a pagar" value={q.totalFormatted} strong />
          <Row label="Você recebe em Movva" value={q.receiveFormatted} />
          <Row label="Custo sobre o que você recebe" value={formatBps(q.premiumBps)} />
          {q.payments > 1 && <div className="faint">Dividido em {q.payments} pagamentos separados.</div>}
        </button>
      ))}
      {options.unavailable.map((u) => (
        <div key={u.rail} className="faint" data-testid={`unavailable-${u.rail}`}>
          {RAIL_LABEL[u.rail]}: {options.issuance ? 'Pausado junto com as compras (veja acima).' : unavailableReason(u.reason)}
        </div>
      ))}
    </div>
  );
}

/** Why the book is short when the reserve is not issuing: a safety pause, not an ordinary lack of offers. */
function IssuancePaused({ options }: { options: BuyOptions }) {
  if (options.issuance === 'breaker_tripped') {
    return (
      <Notice tone="warn" title="Compras pausadas por segurança">
        <p>
          As fontes de preço do Movva discordam entre si além do limite de segurança, e a reserva suspendeu a emissão de novos
          Movva até que voltem a concordar. Por isso os provedores não conseguem repor as ofertas agora. Tente de novo mais tarde.
        </p>
      </Notice>
    );
  }
  if (options.issuance === 'mint_paused') {
    return (
      <Notice tone="warn" title="Compras pausadas">
        <p>A emissão de novos Movva está pausada pela reserva, e os provedores não conseguem repor as ofertas agora. Tente de novo mais tarde.</p>
      </Notice>
    );
  }
  return null;
}

/**
 * The book fills at most what its offers hold, and a quote is the largest purchase within the amount asked: when that is
 * less, say so before anyone locks, or the heading reads as if the whole amount were on offer.
 */
function PartialOffer({ options }: { options: BuyOptions }) {
  if (options.rails.length === 0) return null;
  const largest = options.rails.reduce((a, b) => (b.pay > a.pay ? b : a));
  if (options.asked - largest.pay < PARTIAL_SHORTFALL_CENTS) return null;
  return (
    <Notice tone="warn" title="Só parte do valor está disponível">
      <p>
        Os provedores oferecem no máximo {largest.payFormatted} agora, não {options.askedFormatted}. Cada forma de pagamento abaixo
        cobre só esse valor. Para o restante, faça um novo pedido depois, quando houver oferta.
      </p>
    </Notice>
  );
}

/** Where to pay, exactly as the wallet verified it against the chain. */
export function PaymentDetails({ payment }: { payment: VerifiedPayment }) {
  if (payment.rail === 'pix') {
    return (
      <>
        <QrCode text={payment.pixCopiaECola} label={`QR Code PIX de ${payment.formatted}`} />
        <CopyField label="PIX copia e cola" value={payment.pixCopiaECola} />
        <Row label="Valor" value={payment.formatted} strong />
        <Row label="Recebedor" value={`${payment.receiver.name} · ${payment.receiver.city}`} />
        <Row label="Pague até" value={formatDateTime(payment.payBy)} />
        <p className="faint">Código montado por esta carteira com a chave PIX e o valor conferidos na blockchain.</p>
      </>
    );
  }
  return (
    <>
      <CopyField label="Linha digitável" value={payment.line} />
      <Row label="Valor" value={payment.formatted} strong />
      {payment.dueDate && <Row label="Vencimento" value={formatIsoDate(payment.dueDate)} />}
      <Row label="Pague até" value={formatDateTime(payment.payBy)} />
      <p className="faint">Linha conferida com o boleto que o provedor registrou na blockchain para este pedido.</p>
    </>
  );
}

function DevPay({ payment }: { payment: VerifiedPayment }) {
  const w = useWallet();
  const pay = useAction(async () => {
    const dev = w.dev!;
    if (payment.rail === 'pix') await dev.payPix(payment.pixCopiaECola);
    else await dev.payBoleto(payment.line);
    return true;
  });
  return (
    <div className="card dev">
      <h2>Ambiente de teste</h2>
      <p className="faint">Simula este pagamento no banco de teste (MockBank). O provedor então prova o pagamento e libera os Movva.</p>
      <button type="button" disabled={pay.busy || pay.result === true} onClick={() => void pay.run()}>
        {pay.result ? 'Pagamento simulado' : `Simular pagamento por ${RAIL_LABEL[payment.rail]}`}
      </button>
      <ErrorNotice error={pay.error} />
    </div>
  );
}

export function OrderPayment({ orderId }: { orderId: Hex }) {
  const w = useWallet();
  useActivity(w);
  const order = w.orders().find((o) => o.orderId.toLowerCase() === orderId.toLowerCase());
  const status = useAsync(() => w.buyStatus(orderId), [w, orderId]);
  const view = status.data ? buyStatusView(status.data, w.now()) : undefined;
  const settled = view?.done ?? false;
  useInterval(status.reload, settled ? null : 3_000);
  const payable = !status.data || status.data.state === 'awaiting_payment' || status.data.state === 'awaiting_boleto';
  // Whether the pool would still take this order's shielded delivery: read from the chain while it waits to be released.
  const waitingRelease = status.data?.state === 'awaiting_payment' || status.data?.state === 'disputed';
  const delivery = useAsync(async () => (waitingRelease ? w.deliveryCheck(orderId) : undefined), [w, orderId, waitingRelease]);
  useInterval(delivery.reload, waitingRelease ? 5_000 : null);
  const check = waitingRelease ? delivery.data : undefined;
  const blocked = !!check?.pending && check.delivery === 'shielded' && check.blocks.length > 0;
  const direct = !!check?.pending && check.delivery === 'direct';

  const [payment, setPayment] = useState<VerifiedPayment | undefined>(order?.payment);
  const [instructionsError, setInstructionsError] = useState<unknown>();
  const fetching = useRef(false);
  const fetchInstructions = useCallback(async () => {
    if (fetching.current) return;
    fetching.current = true;
    try {
      setPayment(await w.paymentInstructions(orderId));
      setInstructionsError(undefined);
    } catch (e) {
      setInstructionsError(e);
    } finally {
      fetching.current = false;
    }
  }, [w, orderId]);
  // A 409 is "not yet" only while the node gives no code: a coded refusal (a cap, an unidentified payer) is final,
  // and polling it would leave the user watching a spinner for a purchase that will be refunded instead.
  const waitingForNode = instructionsError instanceof LpNodeError && instructionsError.status === 409 && instructionsError.code === undefined;
  useEffect(() => {
    if (!payment && payable && !settled) void fetchInstructions();
  }, [payment, payable, settled, fetchInstructions]);
  useInterval(() => void fetchInstructions(), !payment && payable && !settled && (instructionsError === undefined || waitingForNode) ? 2_500 : null);

  const cancel = useAction(async () => {
    await w.cancelBuy(orderId);
    status.reload();
  });
  const refused = instructionsError !== undefined && !waitingForNode;
  const rail = order?.rail ?? payment?.rail ?? 'pix';

  return (
    <div className="card" data-testid="order">
      <div className="row">
        <span className="label">{RAIL_LABEL[rail]} · {formatBRL(order?.amount ?? status.data?.amount ?? 0n)}</span>
        {view && <StatusBadge view={view} />}
      </div>
      {view?.detail && <p className="muted">{view.detail}</p>}
      {status.data?.state === 'delivered' && (
        <Notice tone="ok" title="Movva no seu saldo">
          <p>{status.data.creditedFormatted} creditados no saldo protegido.</p>
        </Notice>
      )}
      {status.data?.state === 'delivered_in_the_open' && <ReshieldDelivery orderId={orderId} amount={status.data.amount} />}
      {blocked && check && <DeliveryBlocked orderId={orderId} check={check} onChanged={() => { delivery.reload(); status.reload(); }} />}
      {direct && (
        <div data-testid="delivery-direct">
          <Notice tone="info" title="Entrega fora do saldo protegido"><p>{DIRECT_DELIVERY_CHOSEN}</p></Notice>
        </div>
      )}
      {payable && !settled && (
        <>
          {!payment && !instructionsError && <Spinner label="Conferindo as instruções de pagamento na blockchain..." />}
          {waitingForNode && (
            <Spinner label={status.data?.state === 'awaiting_boleto' ? 'Aguardando o provedor emitir o boleto...' : 'Aguardando o provedor preparar o pagamento...'} />
          )}
          {refused && (
            <ErrorNotice error={instructionsError} busy={cancel.busy} onAction={(a) => void (a === 'cancelOrder' ? cancel.run() : fetchInstructions())} />
          )}
          {payment && !refused && !blocked && <PaymentDetails payment={payment} />}
          {payment && !refused && !blocked && w.dev && status.data?.state === 'awaiting_payment' && <DevPay payment={payment} />}
          {status.data?.state === 'awaiting_payment' && !refused && (
            <div className="actions">
              <button type="button" className="secondary" disabled={cancel.busy} onClick={() => void cancel.run()}>
                {cancel.busy ? 'Cancelando...' : 'Cancelar pedido (gratuito)'}
              </button>
            </div>
          )}
        </>
      )}
      <ErrorNotice error={cancel.error} />
    </div>
  );
}

export function Buy({ orderId }: { orderId?: Hex }) {
  const w = useWallet();
  const [input, setInput] = useState('');
  const [options, setOptions] = useState<BuyOptions>();
  const [selected, setSelected] = useState<Rail>();
  const [locked, setLocked] = useState<Hex[]>(orderId ? [orderId] : []);
  useEffect(() => { setLocked(orderId ? [orderId] : []); }, [orderId]);

  const quote = useAction(async () => {
    const o = await w.quoteBuyByRail(parseAmountInput(input), RAILS);
    setOptions(o);
    setSelected(o.rails[0]?.rail);
    return o;
  });
  const lock = useAction(async (option: RailQuote) => {
    const orders = await w.buy(option);
    setLocked(orders.map((o) => o.orderId));
    return orders;
  });
  useEffect(() => {
    if (lock.error instanceof PartialLock) setLocked(lock.error.locked.map((o) => o.orderId));
  }, [lock.error]);
  /** Quote again, clearing a refusal of the old quote (expired, or offers changed). */
  const requote = () => { lock.reset(); void quote.run(); };
  const [now, setNow] = useState(() => Math.floor(Date.now() / 1000));
  useInterval(() => setNow(Math.floor(Date.now() / 1000)), options ? 1_000 : null);

  if (locked.length > 0) {
    return (
      <>
        <h1>{locked.length > 1 ? 'Pagar pedidos' : 'Pagar pedido'}</h1>
        <ErrorNotice error={lock.error} />
        {locked.map((id) => <OrderPayment key={id} orderId={id} />)}
        <div className="actions">
          <a className="button secondary" href="#/comprar" onClick={() => { setLocked([]); setOptions(undefined); lock.reset(); }}>Nova compra</a>
        </div>
      </>
    );
  }

  const chosen = options?.rails.find((r) => r.rail === selected);
  return (
    <>
      <h1>Comprar Movva</h1>
      <p className="muted">Você paga em reais e recebe Movva no saldo protegido, a R$ 1,00 cada.</p>
      <form className="card" onSubmit={(e) => { e.preventDefault(); requote(); }}>
        <Field label="Quanto você quer pagar?">
          <input
            className="amount-input" inputMode="decimal" placeholder="R$ 0,00" aria-label="Valor em reais" value={input}
            onChange={(e) => { setInput(e.target.value); setOptions(undefined); }}
          />
        </Field>
        <button type="submit" disabled={quote.busy}>{quote.busy ? 'Cotando...' : 'Ver formas de pagamento'}</button>
      </form>
      <ErrorNotice error={quote.error} onAction={() => void quote.run()} />
      {options && <RailOptions options={options} selected={selected} onSelect={setSelected} />}
      {chosen && (
        <div className="card">
          <p>Ao travar, o provedor reserva os Movva para você até o prazo de pagamento. Cancelar antes de pagar é gratuito.</p>
          {chosen.quote.expiresAt > now || lock.busy ? (
            <>
              <p className="faint" data-testid="quote-deadline">
                Cotação válida até {formatDateTime(chosen.quote.expiresAt)} ({secondsLeft(chosen.quote.expiresAt - now)}).
              </p>
              <button type="button" disabled={lock.busy} onClick={() => void lock.run(chosen)}>
                {lock.busy ? 'Travando o pedido...' : `Travar pedido: ${chosen.totalFormatted} por ${RAIL_LABEL[chosen.rail]}`}
              </button>
            </>
          ) : (
            <>
              <p className="faint" data-testid="quote-expired">
                A cotação expirou às {formatDateTime(chosen.quote.expiresAt)}: o preço só fica reservado por pouco tempo. Nada foi travado.
              </p>
              <button type="button" disabled={quote.busy} onClick={requote}>{quote.busy ? 'Cotando...' : 'Cotar de novo'}</button>
            </>
          )}
        </div>
      )}
      <ErrorNotice error={lock.error} onAction={requote} busy={quote.busy} />
    </>
  );
}
