import { useState } from 'react';
import type { MovvaTaxYear } from '@mova/wallet';
import { InputInvalid, brasiliaIsoDate, formatBRL, formatDateTime, formatIsoDate, type StatusView } from '../lib/format.js';
import { stringify } from '../lib/json.js';
import type { GrantState, ShareActivity } from '../wallet/port.js';
import { CopyField, ErrorNotice, Field, Notice, Row, Spinner, StatusBadge } from './components.js';
import { downloadText, useAction, useActivity, useAsync, useWallet } from './hooks.js';

const GRANT_STATE: Record<GrantState, StatusView> = {
  active: { label: 'Ativo', tone: 'ok', done: false },
  expired: { label: 'Expirado', tone: 'info', done: true },
  revoked: { label: 'Revogado', tone: 'warn', done: true },
  unknown: { label: 'Não encontrado na blockchain', tone: 'danger', done: false },
};

/** Midnight (or 23:59:59) of a `YYYY-MM-DD` in Brasília, which keeps UTC-3 all year. */
const brasiliaTs = (iso: string, endOfDay: boolean): number => Math.floor(Date.parse(`${iso}T${endOfDay ? '23:59:59' : '00:00:00'}-03:00`) / 1000);

const monthLabel = (m: string): string => (/^\d{4}-\d{2}$/.test(m) ? `${m.slice(5)}/${m.slice(0, 4)}` : m);

function auditorPackage(w: ReturnType<typeof useWallet>, s: ShareActivity): string {
  return stringify({
    kind: 'mova-audit-package', version: 1,
    chainId: w.deployment.chainId, auditGrantRegistry: w.deployment.contracts.auditGrantRegistry, vault: w.deployment.services.vault,
    account: w.address, auditor: s.auditor, purpose: s.purpose, period: s.share.period, expiresAt: s.share.expiresAt,
    grants: s.share.grants.map((g) => ({ ledger: g.ledger, grantId: g.grantId, bundle: g.bundle, forVault: g.forVault })),
  }, 2);
}

function ShareForm() {
  const w = useWallet();
  const today = brasiliaIsoDate(w.now());
  const [auditor, setAuditor] = useState('Receita Federal do Brasil');
  const [auditorKey, setAuditorKey] = useState('');
  const [purpose, setPurpose] = useState(`IRPF ${today.slice(0, 4)}`);
  const [from, setFrom] = useState(`${today.slice(0, 4)}-01-01`);
  const [to, setTo] = useState(today);
  const [days, setDays] = useState('30');
  const devKey = useAction(async () => {
    const k = await w.dev!.auditorKey();
    setAuditorKey(k.publicKey);
    return k;
  });
  const share = useAction(async () => {
    const key = auditorKey.trim().replace(/^0x/i, '').toLowerCase();
    if (!/^[0-9a-f]{64}$/.test(key)) throw new InputInvalid('Chave do auditor inválida', 'A chave pública do auditor tem 64 caracteres hexadecimais. Peça ao auditor a chave dele.');
    const fromTs = brasiliaTs(from, false);
    const toTs = Math.min(brasiliaTs(to, true), w.now());
    if (!(fromTs < toTs)) throw new InputInvalid('Período inválido', 'O início do período precisa ser anterior ao fim, e o período não pode começar no futuro.');
    const validDays = Number(days);
    if (!Number.isInteger(validDays) || validDays < 1 || validDays > 366) throw new InputInvalid('Validade inválida', 'Um compartilhamento vale de 1 a 366 dias.');
    return w.shareWithAuditor({ auditor: auditor.trim(), auditorKey: key, purpose: purpose.trim(), fromTs, toTs, validDays });
  });
  return (
    <form className="card" onSubmit={(e) => { e.preventDefault(); void share.run(); }}>
      <h2>Compartilhar um período</h2>
      <p className="faint">O auditor recebe as chaves de leitura só deste período, com provas que ele confere na blockchain. O registro fica público na blockchain; o conteúdo, não. Você pode revogar a qualquer momento.</p>
      <Field label="Auditor"><input value={auditor} onChange={(e) => setAuditor(e.target.value)} /></Field>
      <Field label="Chave pública do auditor" hint="Fornecida pelo auditor (64 caracteres hexadecimais).">
        <input value={auditorKey} onChange={(e) => setAuditorKey(e.target.value)} autoComplete="off" className="mono" />
      </Field>
      {w.dev && <button type="button" className="link" onClick={() => void devKey.run()}>Usar a chave do auditor de teste</button>}
      <Field label="Finalidade"><input value={purpose} onChange={(e) => setPurpose(e.target.value)} /></Field>
      <div className="grid2">
        <Field label="De"><input type="date" value={from} max={today} onChange={(e) => setFrom(e.target.value)} /></Field>
        <Field label="Até"><input type="date" value={to} max={today} onChange={(e) => setTo(e.target.value)} /></Field>
      </div>
      <Field label="Validade (dias)"><input inputMode="numeric" value={days} onChange={(e) => setDays(e.target.value)} /></Field>
      {share.busy ? <Spinner label="Gerando as provas e registrando o compartilhamento..." /> : <button type="submit">Compartilhar</button>}
      <ErrorNotice error={share.error ?? devKey.error} />
      {share.result && (
        <Notice tone="ok" title="Compartilhado">
          <p>{share.result.share.grants.length} autorização(ões) registrada(s) na blockchain. Baixe o pacote abaixo e entregue ao auditor.</p>
        </Notice>
      )}
    </form>
  );
}

function Grants() {
  const w = useWallet();
  const version = useActivity(w);
  const states = useAsync(() => w.grantStates(), [w, version]);
  const revoke = useAction(async (id: string) => {
    await w.revokeAuditor(id);
    states.reload();
  });
  const shares = w.shares();
  if (shares.length === 0) return null;
  return (
    <div className="card">
      <h2>Compartilhamentos</h2>
      <Notice tone="warn">
        <p>O pacote do auditor contém as chaves de leitura do período. Entregue somente ao auditor.</p>
      </Notice>
      {shares.map((s) => {
        const state = states.data?.[s.id];
        return (
          <div className="list-item" key={s.id} data-testid="grant">
            <div className="row">
              <span className="label"><strong>{s.auditor}</strong> · {s.purpose}</span>
              {state ? <StatusBadge view={GRANT_STATE[state]} /> : <Spinner label="" />}
            </div>
            <Row label="Período" value={`${formatDateTime(s.share.period.fromTs)} a ${formatDateTime(s.share.period.toTs)}`} />
            <Row label="Válido até" value={formatDateTime(s.share.expiresAt)} />
            <Row label="Saldo" value="Movva" />
            <div className="actions">
              <button type="button" className="secondary" onClick={() => downloadText(`auditoria-movva-${s.id.slice(0, 8)}.json`, auditorPackage(w, s), 'application/json')}>Baixar pacote do auditor</button>
              {state === 'active' && (
                <button type="button" className="danger" disabled={revoke.busy} onClick={() => void revoke.run(s.id)}>{revoke.busy ? 'Revogando...' : 'Revogar'}</button>
              )}
            </div>
          </div>
        );
      })}
      <ErrorNotice error={revoke.error ?? states.error} />
    </div>
  );
}

export function TaxYearView({ tax }: { tax: MovvaTaxYear }) {
  const assets = [
    { name: 'Movva', s: tax.movva.summary },
  ];
  return (
    <>
      <h2>Bens e Direitos</h2>
      <div className="table-wrap">
        <table className="plain">
          <thead><tr><th>Ativo</th><th>Código</th><th>31/12 anterior</th><th>31/12 do ano</th></tr></thead>
          <tbody>
            {assets.map(({ name, s }) => (
              <tr key={name}>
                <td>{name}</td>
                <td>{s.bensEDireitos.group}.{s.bensEDireitos.code}</td>
                <td>{formatBRL(s.bensEDireitos.previousYearCents)}</td>
                <td>{formatBRL(s.bensEDireitos.currentYearCents)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="faint">Valores ao custo de aquisição.</p>
      <h2>Alienações por mês (Movva)</h2>
      {tax.movva.summary.months.length === 0 ? <p className="faint">Nenhuma alienação no ano.</p> : (
        <div className="table-wrap">
          <table className="plain">
            <thead><tr><th>Mês</th><th>Recebido</th><th>Custo</th><th>Ganho</th></tr></thead>
            <tbody>
              {tax.movva.summary.months.map((m) => (
                <tr key={m.month}><td>{monthLabel(m.month)}</td><td>{formatBRL(m.proceedsCents)}</td><td>{formatBRL(m.costBasisCents)}</td><td>{formatBRL(m.gainCents)}</td></tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {tax.movva.summary.caveats.map((c) => <p className="faint" key={c}>{c}</p>)}
    </>
  );
}

function TaxYear() {
  const w = useWallet();
  useActivity(w);
  const current = Number(brasiliaIsoDate(w.now()).slice(0, 4));
  const [year, setYear] = useState(current);
  let tax: MovvaTaxYear | undefined;
  let error: unknown;
  try {
    tax = w.taxYear(year);
  } catch (e) {
    error = e;
  }
  return (
    <div className="card">
      <h2>Imposto de renda</h2>
      <Field label="Ano-calendário">
        <select value={year} onChange={(e) => setYear(Number(e.target.value))}>
          {[current, current - 1, current - 2].map((y) => <option key={y} value={y}>{y}</option>)}
        </select>
      </Field>
      <ErrorNotice error={error} />
      {tax && (
        <>
          <TaxYearView tax={tax} />
          <div className="actions">
            <button type="button" className="secondary" onClick={() => downloadText(`movva-${year}.csv`, tax!.movva.csv, 'text/csv;charset=utf-8')}>Baixar CSV (Movva)</button>
          </div>
        </>
      )}
    </div>
  );
}

export function Audit() {
  const w = useWallet();
  return (
    <>
      <h1>Auditoria e imposto</h1>
      <ShareForm />
      <Grants />
      <TaxYear />
      <p className="faint">Conta que registra os compartilhamentos:</p>
      <CopyField label="Sua conta" value={w.address} />
      <p className="faint">Período em horário de Brasília. Formatos: {formatIsoDate('2026-01-31')}.</p>
    </>
  );
}
