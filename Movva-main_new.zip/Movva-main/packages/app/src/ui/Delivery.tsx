/**
 * The delivery escape hatch (FiatEscrow `takeDeliveryDirect`): an order locked for delivery into the shielded balance
 * whose deposit the pool would refuse now - its minimum raised above the order, the pool wound down or no longer
 * registered, the token's issuer freezing a party - says why, and offers to take the Movva at the user's own account, in
 * the open, after one sentence on what that costs. Without it a paid order could not be released, and would expire back
 * to the LP with the user's reais.
 */
import type { Hex } from 'viem';
import {
  DELIVERY_BLOCKED_EXPLAINED, DELIVERY_BLOCKED_TITLE, DIRECT_DELIVERY_COST, DIRECT_DELIVERY_REFUSED, blockedDeliveries, deliveryBlockText,
  type DeliveryCheck,
} from '../lib/delivery.js';
import { RAIL_LABEL, formatBRL } from '../lib/format.js';
import { ErrorNotice, Notice, Spinner } from './components.js';
import { useAction, useActivity, useWallet } from './hooks.js';

export function DeliveryBlocked({ orderId, check, onChanged }: { orderId: Hex; check: DeliveryCheck; onChanged?: () => void }) {
  const w = useWallet();
  const take = useAction(async () => {
    try {
      await w.takeDeliveryDirect(orderId);
      return true;
    } finally {
      onChanged?.();
    }
  });
  return (
    <div data-testid="delivery-blocked">
      <Notice tone="danger" title={DELIVERY_BLOCKED_TITLE}>
        {check.blocks.map((b, i) => <p key={i} data-testid="delivery-block">{deliveryBlockText(b)}</p>)}
        <p>{DELIVERY_BLOCKED_EXPLAINED}</p>
        {check.directRefused ? <p>{DIRECT_DELIVERY_REFUSED}</p> : (
          <>
            <p data-testid="direct-delivery-cost">{DIRECT_DELIVERY_COST}</p>
            {take.busy
              ? <Spinner label="Mudando a entrega para a sua conta..." />
              : <div className="actions"><button type="button" onClick={() => void take.run()}>Receber fora do saldo protegido</button></div>}
          </>
        )}
      </Notice>
      <ErrorNotice error={take.error} />
    </div>
  );
}

/** On Início: every order waiting to be released whose shielded delivery the pool would refuse, as last read. */
export function BlockedDeliveriesCard() {
  const w = useWallet();
  useActivity(w);
  const orders = blockedDeliveries(w.orders());
  if (orders.length === 0) return null;
  return (
    <div className="card" data-testid="blocked-deliveries">
      <h2>Pedidos que não podem ser entregues no saldo protegido</h2>
      {orders.map((o) => (
        <div className="list-item" key={o.orderId}>
          <a className="label" href={`#/comprar/${o.orderId}`}>Compra por {RAIL_LABEL[o.rail]} · {formatBRL(o.amount)}</a>
          <DeliveryBlocked orderId={o.orderId} check={o.delivery!} />
        </div>
      ))}
    </div>
  );
}
