import { createContext, useCallback, useContext, useEffect, useRef, useState, useSyncExternalStore } from 'react';
import type { WalletPort } from '../wallet/port.js';

export const WalletContext = createContext<WalletPort | null>(null);

export function useWallet(): WalletPort {
  const w = useContext(WalletContext);
  if (!w) throw new Error('useWallet outside an unlocked wallet');
  return w;
}

/** Re-render when the wallet's activity (orders, sales, shares) changes. */
export function useActivity(port: WalletPort): number {
  return useSyncExternalStore((listener) => port.subscribe(listener), () => port.version());
}

export interface AsyncState<T> {
  data?: T;
  error?: unknown;
  loading: boolean;
  reload: () => void;
}

/** Run `fn` when `deps` change; keeps the last data while reloading, and ignores answers that arrive too late. */
export function useAsync<T>(fn: () => Promise<T>, deps: readonly unknown[]): AsyncState<T> {
  const [state, setState] = useState<{ data?: T; error?: unknown; loading: boolean }>({ loading: true });
  const [tick, setTick] = useState(0);
  const fnRef = useRef(fn);
  fnRef.current = fn;
  useEffect(() => {
    let live = true;
    setState((s) => ({ ...s, loading: true }));
    fnRef.current().then(
      (data) => { if (live) setState({ data, loading: false }); },
      (error: unknown) => { if (live) setState((s) => ({ data: s.data, error, loading: false })); },
    );
    return () => { live = false; };
  }, [...deps, tick]); // eslint-disable-line react-hooks/exhaustive-deps
  const reload = useCallback(() => setTick((t) => t + 1), []);
  return { ...state, reload };
}

export function useInterval(callback: () => void, ms: number | null): void {
  const ref = useRef(callback);
  useEffect(() => { ref.current = callback; }, [callback]);
  useEffect(() => {
    if (ms === null) return undefined;
    const id = setInterval(() => ref.current(), ms);
    return () => clearInterval(id);
  }, [ms]);
}

export interface Action<A extends unknown[], T> {
  run: (...args: A) => Promise<T | undefined>;
  busy: boolean;
  error?: unknown;
  result?: T;
  reset: () => void;
}

/** A user action: one at a time, its error kept for the screen to explain. */
export function useAction<A extends unknown[], T>(fn: (...args: A) => Promise<T>): Action<A, T> {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>();
  const [result, setResult] = useState<T>();
  const fnRef = useRef(fn);
  fnRef.current = fn;
  const run = useCallback(async (...args: A) => {
    setBusy(true);
    setError(undefined);
    try {
      const r = await fnRef.current(...args);
      setResult(r);
      return r;
    } catch (e) {
      setError(e);
      return undefined;
    } finally {
      setBusy(false);
    }
  }, []);
  const reset = useCallback(() => { setError(undefined); setResult(undefined); }, []);
  return { run, busy, error, result, reset };
}

/** Save a file the user asked for (a CSV, the auditor's package). */
export function downloadText(filename: string, text: string, type = 'text/plain;charset=utf-8'): void {
  const url = URL.createObjectURL(new Blob([text], { type }));
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1_000);
}
