import { useState } from 'react';
import type { Address } from 'viem';
import type { AppDeployment, EndpointOverrides, LpNodeEndpoint } from '../lib/deployment.js';
import { CONTRACT_FIELD_LABELS, canonicalFor, type PinnedContract } from '../lib/canonical.js';
import { CopyField, ErrorNotice, Field, Notice, Row } from './components.js';
import { useAction } from './hooks.js';
import { RecoveryAlertsCard } from './Alerts.js';
import { ReserveRisksCard } from './ReserveRisks.js';

export interface SettingsProps {
  deployment?: AppDeployment;
  deploymentError?: unknown;
  defaultUrl: string;
  overrides: EndpointOverrides;
  onLoadUrl: (url: string) => Promise<void>;
  onLoadJson: (text: string) => Promise<void>;
  onSaveOverrides: (o: EndpointOverrides) => void;
  session?: {
    address: Address; accountKind?: 'eoa' | 'safe' | 'kernel'; coSigner?: Address; vaultFailures: number; onLock: () => void; onForget: () => void;
  };
}

const ACCOUNT_KIND_LABEL = {
  safe: 'Safe 2-de-2: sua passkey e o cossignatário; gás pago pelo paymaster',
  kernel: 'Kernel: sua passkey e o cossignatário; gás pago pelo paymaster',
  eoa: 'Conta simples (EOA) derivada da passkey',
} as const;

const CONTRACT_LABELS = Object.entries(CONTRACT_FIELD_LABELS) as [PinnedContract, string][];

function DeploymentLoader({ defaultUrl, onLoadUrl, onLoadJson }: Pick<SettingsProps, 'defaultUrl' | 'onLoadUrl' | 'onLoadJson'>) {
  const [url, setUrl] = useState(defaultUrl);
  const load = useAction(async () => onLoadUrl(url));
  const file = useAction(async (f: File) => onLoadJson(await f.text()));
  return (
    <form className="card" onSubmit={(e) => { e.preventDefault(); void load.run(); }}>
      <h2>Carregar deployment</h2>
      <p className="faint">Antes de usar um deployment novo ou alterado, o app mostra o que muda e pede a sua confirmação. Endereços que não conferem com o registro embutido no app são recusados.</p>
      <Field label="URL do arquivo de deployment (JSON)"><input value={url} onChange={(e) => setUrl(e.target.value)} /></Field>
      <button type="submit" disabled={load.busy}>Carregar</button>
      <Field label="Ou escolha um arquivo">
        <input type="file" accept="application/json,.json" onChange={(e) => { const f = e.target.files?.[0]; if (f) void file.run(f); }} />
      </Field>
      <ErrorNotice error={load.error ?? file.error} />
    </form>
  );
}

function Endpoints({ deployment, overrides, onSaveOverrides }: { deployment: AppDeployment; overrides: EndpointOverrides; onSaveOverrides: (o: EndpointOverrides) => void }) {
  const [rpcUrl, setRpc] = useState(overrides.rpcUrl ?? deployment.rpcUrl);
  const [matcher, setMatcher] = useState(overrides.matcher ?? deployment.services.matcher);
  const [relayer, setRelayer] = useState(overrides.relayer ?? deployment.services.relayer);
  const [asp, setAsp] = useState(overrides.asp ?? deployment.services.asp);
  const [vault, setVault] = useState(overrides.vault ?? deployment.services.vault ?? '');
  const [nodes, setNodes] = useState<LpNodeEndpoint[]>(overrides.lpNodes ?? deployment.services.lpNodes);
  const [saved, setSaved] = useState(false);
  const setNode = (i: number, patch: Partial<LpNodeEndpoint>) => setNodes((n) => n.map((x, j) => (j === i ? { ...x, ...patch } : x)));
  return (
    <form className="card" onSubmit={(e) => {
      e.preventDefault();
      onSaveOverrides({ rpcUrl, matcher, relayer, asp, vault: vault || undefined, lpNodes: nodes });
      setSaved(true);
    }}>
      <h2>Serviços</h2>
      <Field label="RPC (nó Ethereum)"><input value={rpcUrl} onChange={(e) => { setRpc(e.target.value); setSaved(false); }} /></Field>
      <Field label="Matcher (livro de ofertas)"><input value={matcher} onChange={(e) => { setMatcher(e.target.value); setSaved(false); }} /></Field>
      <Field label="Relayer"><input value={relayer} onChange={(e) => { setRelayer(e.target.value); setSaved(false); }} /></Field>
      <Field label="ASP (aprovações)"><input value={asp} onChange={(e) => { setAsp(e.target.value); setSaved(false); }} /></Field>
      <Field label="Cofre de notas"><input value={vault} onChange={(e) => { setVault(e.target.value); setSaved(false); }} /></Field>
      <h2>Nós dos provedores de liquidez</h2>
      {nodes.map((n, i) => (
        <div key={i} className="card sunken">
          <Field label={`Endereço do provedor ${i + 1}`}><input className="mono" value={n.lp} onChange={(e) => { setNode(i, { lp: e.target.value as Address }); setSaved(false); }} /></Field>
          <Field label="URL do nó"><input value={n.url} onChange={(e) => { setNode(i, { url: e.target.value }); setSaved(false); }} /></Field>
          <button type="button" className="link" onClick={() => setNodes((all) => all.filter((_, j) => j !== i))}>Remover</button>
        </div>
      ))}
      <button type="button" className="link" onClick={() => setNodes((all) => [...all, { lp: '' as Address, url: '' }])}>Adicionar nó</button>
      <div className="actions">
        <button type="submit">Salvar</button>
        <button type="button" className="secondary" onClick={() => { onSaveOverrides({}); setSaved(true); }}>Usar os do deployment</button>
      </div>
      {saved && <Notice tone="ok">Salvo. A carteira foi bloqueada para reabrir com os novos serviços.</Notice>}
    </form>
  );
}

export function Settings(p: SettingsProps) {
  const d = p.deployment;
  return (
    <>
      <h1>Ajustes</h1>
      <ErrorNotice error={p.deploymentError} />
      {d && (
        <div className="card">
          <h2>Deployment</h2>
          <Row label="Rede" value={d.name} />
          <Row label="Chain ID" value={<span data-testid="chain-id">{d.chainId}</span>} />
          <Row label="Carregado de" value={<span className="mono">{d.source}</span>} />
          <Row label="Registro canônico" value={<span data-testid="canonical-status">{canonicalFor(d.chainId)
            ? 'Contratos conferidos com o registro embutido no app'
            : 'Nenhum para esta rede: endereços só do arquivo'}</span>} />
          {CONTRACT_LABELS.filter(([k]) => d.contracts[k] !== undefined).map(([k, label]) => <Row key={k} label={label} value={<span className="mono">{String(d.contracts[k])}</span>} />)}
          <Row label="Bloco inicial" value={d.contracts.fromBlock.toString()} />
          {d.trust.pixLocationHosts.length > 0 && (
            <Notice tone="info">
              <p>Cobranças PIX dinâmicas ({d.trust.pixLocationHosts.join(', ')}) não são aceitas no navegador: conferi-las exige ler o certificado TLS do site do PSP, que o navegador não expõe.</p>
            </Notice>
          )}
        </div>
      )}
      <DeploymentLoader defaultUrl={p.defaultUrl} onLoadUrl={p.onLoadUrl} onLoadJson={p.onLoadJson} />
      {d && <Endpoints deployment={d} overrides={p.overrides} onSaveOverrides={p.onSaveOverrides} />}
      {p.session && (
        <div className="card">
          <h2>Esta carteira</h2>
          <CopyField label="Conta" value={p.session.address} />
          <Row label="Tipo de conta" value={<span data-testid="account-kind">{ACCOUNT_KIND_LABEL[p.session.accountKind ?? 'eoa']}</span>} />
          {p.session.coSigner && <Row label="Cossignatário" value={<span className="mono">{p.session.coSigner}</span>} />}
          <Row label="Desbloqueio" value="Passkey (PRF)" />
          <Row label="Provas de conhecimento zero" value="Geradas neste aparelho" />
          {p.session.vaultFailures > 0 && <Notice tone="warn"><p>{p.session.vaultFailures} nota(s) não chegaram ao cofre; serão reenviadas no próximo desbloqueio.</p></Notice>}
          <div className="actions">
            <button type="button" className="secondary" onClick={p.session.onLock}>Bloquear</button>
            <button type="button" className="danger" onClick={() => { if (confirm('Apagar os dados desta carteira neste aparelho? Seu saldo continua na blockchain e volta com a passkey.')) p.session!.onForget(); }}>Esquecer este aparelho</button>
          </div>
        </div>
      )}
      {p.session && p.session.accountKind !== undefined && p.session.accountKind !== 'eoa' && <RecoveryAlertsCard />}
      <ReserveRisksCard />
    </>
  );
}
