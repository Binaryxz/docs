/**
 * Money on its way in or out of the shielded balance, on Início and Vender.
 *
 *  - **Sales in progress** (`pendingSales()`): a sale that stopped between its exit, its openSale and the LPs learning
 *    the payee - what happened, what is left, how much - with "Continuar venda" and "Cancelar e devolver ao saldo". A
 *    sale whose exit may still land says "Aguardando o relayer" and offers nothing, and the session asks again on each
 *    refresh; a sale being made or resumed right now offers nothing either.
 *  - **Movva in the open**: a delivery taken in the open (takeDeliveryDirect), and a sale refunded to its sale account,
 *    each with "Devolver ao saldo protegido". A delivery says first, in one sentence, that its deposit is the user's.
 */
import { useState } from 'react';
import type { Hex } from 'viem';
import { RAIL_LABEL, formatBRL } from '../lib/format.js';
import {
  DELIVERY_RESHIELD_VISIBLE, PENDING_ACTION_LABEL, SALE_RESHIELD_UNLINKED, inTheOpen, pendingSaleView, reshieldedView, resumeOutcomeView,
  type OutcomeView, type PendingAction,
} from '../lib/pending.js';
import { deliveryBlockText } from '../lib/delivery.js';
import type { PendingSaleItem } from '../wallet/port.js';
import { ErrorNotice, Notice, Row, Spinner, StatusBadge } from './components.js';
import { useAction, useActivity, useAsync, useInterval, useWallet } from './hooks.js';

function Outcome({ view, testId }: { view: OutcomeView; testId: string }) {
  return (
    <div data-testid={testId}>
      <Notice tone={view.tone} title={view.title}><p>{view.detail}</p></Notice>
    </div>
  );
}

function PendingSaleEntry({ item, onOutcome }: { item: PendingSaleItem; onOutcome: (id: string, view: OutcomeView | undefined) => void }) {
  const w = useWallet();
  const [working, setWorking] = useState<PendingAction>();
  const [error, setError] = useState<unknown>();
  const view = pendingSaleView(item);
  const act = async (action: PendingAction) => {
    setWorking(action);
    setError(undefined);
    try {
      if (action === 'reshield') {
        onOutcome(item.id, reshieldedView(await w.reshieldSale(item.id)));
      } else {
        const out = action === 'continue' ? await w.resumeSale(item.id) : await w.resumeSale(item.id, { cancel: true });
        onOutcome(item.id, resumeOutcomeView(out, item));
      }
    } catch (e) {
      setError(e);
    } finally {
      setWorking(undefined);
    }
  };
  return (
    <div className="list-item" data-testid="pending-sale" data-stage={item.stage}>
      <div className="row">
        <span className="label">{view.title}</span>
        <StatusBadge view={{ label: view.badge.label, tone: view.badge.tone, done: false }} />
      </div>
      {item.payee && <Row label={item.rail === 'boleto' ? 'Boleto' : 'Chave PIX'} value={<span className="mono">{item.payee}</span>} />}
      <p>{view.happened}</p>
      {view.left && <p className="muted">{view.left}</p>}
      {view.figures.map((f) => <Row key={f.label} label={f.label} value={f.value} />)}
      {working
        ? <Spinner label={PENDING_ACTION_LABEL[working].busy} />
        : view.actions.length > 0 && (
          <div className="actions">
            {view.actions.map((a) => (
              <button key={a} type="button" className={a === 'cancel' ? 'secondary' : undefined} onClick={() => void act(a)}>
                {PENDING_ACTION_LABEL[a].idle}
              </button>
            ))}
          </div>
        )}
      <ErrorNotice error={error ?? item.lastError} />
    </div>
  );
}

/**
 * Sales this device started and has not finished. `poll`: ask again about a sale waiting for the relayer from here (a
 * screen with no refresh of its own). `onSettled`: after an action, for the screen to read the balance again.
 */
export function PendingSalesCard({ poll = false, onSettled }: { poll?: boolean; onSettled?: () => void }) {
  const w = useWallet();
  useActivity(w);
  const items = w.pendingSales();
  const [outcomes, setOutcomes] = useState<{ id: string; view: OutcomeView }[]>([]);
  useInterval(() => void w.refreshActivity().catch(() => undefined), poll && items.some((p) => p.waitingForRelayer) ? 10_000 : null);
  if (items.length === 0 && outcomes.length === 0) return null;
  const onOutcome = (id: string, view: OutcomeView | undefined) => {
    setOutcomes((o) => [...o.filter((x) => x.id !== id), ...(view ? [{ id, view }] : [])]);
    onSettled?.();
  };
  return (
    <div className="card" data-testid="pending-sales">
      <h2>Vendas em andamento</h2>
      {items.length > 0 && (
        <p className="faint">
          Vendas que pararam no meio do caminho neste aparelho. Nada é repetido sem você: a carteira consulta a blockchain antes de enviar
          qualquer coisa, e nunca faz a mesma saída nem abre a mesma venda duas vezes.
        </p>
      )}
      {items.map((item) => <PendingSaleEntry key={item.id} item={item} onOutcome={onOutcome} />)}
      {outcomes.map(({ id, view }) => <Outcome key={id} view={view} testId="pending-outcome" />)}
    </div>
  );
}

function ReshieldButton({ busy, onClick }: { busy: boolean; onClick: () => void }) {
  return busy
    ? <Spinner label={PENDING_ACTION_LABEL.reshield.busy} />
    : <div className="actions"><button type="button" onClick={onClick}>{PENDING_ACTION_LABEL.reshield.idle}</button></div>;
}

/** An order delivered in the open (takeDeliveryDirect): back into the shielded balance from the user's own account, visibly. */
export function ReshieldDelivery({ orderId, amount, onSettled }: { orderId: Hex; amount?: bigint; onSettled?: () => void }) {
  const w = useWallet();
  useActivity(w);
  const done = w.reshields().find((r) => r.orderId?.toLowerCase() === orderId.toLowerCase());
  // What made it go out in the open may still hold: the pool is asked again until it would take the deposit.
  const blocks = useAsync(async () => (done ? [] : w.reshieldDeliveryBlocks(orderId)), [w, orderId, !!done]);
  const waitsForPool = (blocks.data?.length ?? 0) > 0;
  useInterval(blocks.reload, !done && waitsForPool ? 5_000 : null);
  const run = useAction(async () => {
    try {
      return await w.reshieldDelivery(orderId);
    } finally {
      onSettled?.();
    }
  });
  if (done) return <Outcome view={reshieldedView(done)} testId="reshielded" />;
  return (
    <div data-testid="reshield-delivery">
      <Notice tone="warn" title="Movva fora do saldo protegido">
        <p>{amount !== undefined ? `${formatBRL(amount)} em Movva deste pedido foram entregues` : 'Os Movva deste pedido foram entregues'} na sua conta, fora do saldo protegido.</p>
        <p data-testid="reshield-visible">{DELIVERY_RESHIELD_VISIBLE}</p>
        {waitsForPool ? (
          <div data-testid="reshield-waits">
            <p><strong>O pool ainda não aceita este depósito.</strong></p>
            {blocks.data!.map((b, i) => <p key={i}>{deliveryBlockText(b)}</p>)}
            <p className="faint">A carteira confere de novo a cada poucos segundos, e o botão volta quando o pool aceitar o depósito.</p>
          </div>
        ) : blocks.data === undefined && blocks.error === undefined
          ? <Spinner label="Conferindo se o pool aceita o depósito..." />
          : <ReshieldButton busy={run.busy} onClick={() => void run.run()} />}
      </Notice>
      <ErrorNotice error={run.error} />
    </div>
  );
}

/** A sale refunded to its sale account (cancelled, or a dispute that expired): back into the shielded balance from there. */
export function ReshieldSale({ saleId, onSettled }: { saleId: Hex; onSettled?: () => void }) {
  const w = useWallet();
  useActivity(w);
  const done = w.reshields().find((r) => r.saleId?.toLowerCase() === saleId.toLowerCase() || r.ref.toLowerCase() === saleId.toLowerCase());
  const run = useAction(async () => {
    try {
      return await w.reshieldSale(saleId);
    } finally {
      onSettled?.();
    }
  });
  if (done) return <Outcome view={reshieldedView(done)} testId="reshielded" />;
  return (
    <div data-testid="reshield-sale">
      <Notice tone="warn" title="Movva na conta da venda">
        <p>Os Movva desta venda voltaram para a conta da venda, fora do saldo protegido.</p>
        <p>{SALE_RESHIELD_UNLINKED}</p>
        <ReshieldButton busy={run.busy} onClick={() => void run.run()} />
      </Notice>
      <ErrorNotice error={run.error} />
    </div>
  );
}

/** On Início: every order and sale that left Movva in the open and has not been put back from this device. */
export function InTheOpenCard({ onSettled }: { onSettled?: () => void }) {
  const w = useWallet();
  useActivity(w);
  const open = inTheOpen({ orders: w.orders(), sales: w.sales(), reshields: w.reshields(), pending: w.pendingSales() });
  if (open.orders.length + open.sales.length === 0) return null;
  return (
    <div className="card" data-testid="in-the-open">
      <h2>Movva fora do saldo protegido</h2>
      {open.orders.map((o) => (
        <div className="list-item" key={o.orderId}>
          <a className="label" href={`#/comprar/${o.orderId}`}>Compra por {RAIL_LABEL[o.rail]} · {formatBRL(o.amount)}</a>
          <ReshieldDelivery orderId={o.orderId} amount={o.amount} onSettled={onSettled} />
        </div>
      ))}
      {open.sales.map((s) => (
        <div className="list-item" key={s.saleId}>
          <a className="label" href="#/vender">{s.rail === 'boleto' ? 'Pagamento de boleto cancelado' : 'Venda por PIX cancelada'} · {formatBRL(s.receive)}</a>
          <ReshieldSale saleId={s.saleId} onSettled={onSettled} />
        </div>
      ))}
    </div>
  );
}
