/**
 * Recovery alerts: the switch in Ajustes, and the one-time offer on Início after onboarding (src/wallet/alerts.ts).
 */
import { useAction, useActivity, useAsync, useWallet } from './hooks.js';
import { ErrorNotice, Notice, Spinner } from './components.js';
import type { AlertsUnavailable } from '../wallet/alerts.js';

/** Why alerts matter, in one sentence, beside the switch and the offer. */
export const RECOVERY_ALERTS_WHY =
  'Quem roubar a sua passkey pode pedir a recuperação da sua conta, e você tem 7 dias para vetar: com os alertas ativados, este aparelho avisa mesmo com o app fechado.';

export const ALERTS_UNAVAILABLE: Record<AlertsUnavailable, string> = {
  eoa: 'Uma conta simples (EOA) não tem recuperação com prazo, então não há o que alertar.',
  cosigner: 'O cossignatário deste deployment não envia alertas de recuperação.',
  browser: 'Este navegador não recebe notificações do app: abra o app instalado (ou a versão compilada) num navegador com notificações push.',
};

export function RecoveryAlertsCard() {
  const w = useWallet();
  useActivity(w);
  const view = useAsync(async () => (w.recoveryAlerts ? w.recoveryAlerts() : undefined), [w]);
  const toggle = useAction(async (on: boolean) => {
    try {
      if (on) await w.enableRecoveryAlerts!();
      else await w.disableRecoveryAlerts!();
      return on;
    } finally {
      view.reload();
    }
  });
  if (!w.recoveryAlerts) return null;
  const v = view.data;
  return (
    <div className="card" data-testid="recovery-alerts">
      <h2>Alertas de recuperação</h2>
      <p>{RECOVERY_ALERTS_WHY}</p>
      {v === undefined ? (
        view.error ? <ErrorNotice error={view.error} onAction={() => view.reload()} /> : <Spinner label="Conferindo os alertas deste aparelho..." />
      ) : !v.available ? (
        <Notice tone="info"><p data-testid="recovery-alerts-unavailable">{ALERTS_UNAVAILABLE[v.unavailable ?? 'browser']}</p></Notice>
      ) : (
        <label className="field" style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <input
            type="checkbox" role="switch" aria-label="Alertas de recuperação" style={{ width: 'auto' }} checked={v.subscribed} disabled={toggle.busy}
            onChange={(e) => void toggle.run(e.target.checked)}
          />
          <span style={{ margin: 0 }} data-testid="recovery-alerts-state">
            {toggle.busy ? 'Confirme com a sua passkey...' : v.subscribed ? 'Ativados neste aparelho' : 'Desativados neste aparelho'}
          </span>
        </label>
      )}
      <ErrorNotice error={toggle.error} />
    </div>
  );
}

/** Once per device and account, after onboarding: turn alerts on, or not now. */
export function RecoveryAlertsOffer() {
  const w = useWallet();
  useActivity(w);
  const answered = w.recoveryAlertsOffered ? w.recoveryAlertsOffered() : true;
  const view = useAsync(async () => (!answered && w.recoveryAlerts ? w.recoveryAlerts() : undefined), [w, answered]);
  const enable = useAction(async () => {
    await w.enableRecoveryAlerts!();
    return true;
  });
  if (enable.result) {
    return (
      <div data-testid="recovery-alerts-offer">
        <Notice tone="ok" title="Alertas de recuperação ativados">
          <p>Este aparelho avisa se alguém pedir a recuperação da sua conta. Você pode desativá-los em Ajustes.</p>
        </Notice>
      </div>
    );
  }
  if (answered || !view.data?.available || view.data.subscribed) return null;
  return (
    <div data-testid="recovery-alerts-offer">
      <Notice tone="info" title="Ativar alertas de recuperação?">
        <p>{RECOVERY_ALERTS_WHY}</p>
        <div className="actions">
          <button type="button" disabled={enable.busy} onClick={() => void enable.run()}>{enable.busy ? 'Confirme com a sua passkey...' : 'Ativar alertas'}</button>
          <button type="button" className="secondary" disabled={enable.busy} onClick={() => w.dismissRecoveryAlertsOffer?.()}>Agora não</button>
        </div>
        <ErrorNotice error={enable.error} />
      </Notice>
    </div>
  );
}
