/**
 * Sub-wallets: create (the phrase shown once, then a backup check), list and switch, restore from a phrase, and share
 * selected ones with an auditor in one package (Rev. 3 section 6.2-6.3, VK-7). Moves between sub-wallets are not here: V2.
 */
import { useState } from 'react';
import { SubWalletRefused } from '@mova/wallet';
import { InputInvalid, brasiliaIsoDate } from '../lib/format.js';
import type { SubWalletDraft, SubWalletPackageActivity, SubWalletView, SubWalletsPort } from '../wallet/port.js';
import { ErrorNotice, Field, Notice, Row, Spinner } from './components.js';
import { downloadText, useAction } from './hooks.js';

/** Said before the phrase is shown, and again beside it. */
export const LOST_SEED_WARNING = 'Se você perder esta frase, perde esta sub-carteira e tudo o que há nela. A Movva não gera, não recebe e não guarda a frase, não tem cópia e não consegue recuperá-la.';
export const SEED_SHOWN_ONCE = 'A frase aparece só agora, uma única vez. Anote as palavras em papel, na ordem, e guarde em lugar seguro, separado das frases das outras sub-carteiras. Não tire foto nem copie para um aplicativo.';
export const COMPLETENESS_OPEN = 'O pacote cobre apenas as sub-carteiras escolhidas. A Movva não guarda a lista das suas sub-carteiras e elas não compartilham nenhuma chave: não há como o auditor saber se alguma ficou de fora.';
export const NO_MOVES_V2 = 'Mover saldo entre sub-carteiras ainda não existe (previsto para a versão 2). Cada sub-carteira recebe e gasta por conta própria.';

/** A refusal of the sub-wallet rules, said as a form error. */
const said = async <T,>(f: () => Promise<T>): Promise<T> => {
  try {
    return await f();
  } catch (e) {
    if (e instanceof SubWalletRefused) throw new InputInvalid('Não foi possível', e.message);
    throw e;
  }
};

const brasiliaTs = (iso: string, endOfDay: boolean): number => Math.floor(Date.parse(`${iso}T${endOfDay ? '23:59:59' : '00:00:00'}-03:00`) / 1000);

export function CreateSubWallet({ manager, onCreated }: { manager: SubWalletsPort; onCreated?: (v: SubWalletView) => void }) {
  const [label, setLabel] = useState('');
  const [words, setWords] = useState<12 | 24>(12);
  const [draft, setDraft] = useState<SubWalletDraft>();
  const [step, setStep] = useState<'start' | 'show' | 'check'>('start');
  const [answers, setAnswers] = useState<string[]>([]);
  const generate = useAction(async () => said(async () => {
    if (!label.trim()) throw new InputInvalid('Dê um nome', 'Escolha um nome para reconhecer esta sub-carteira na lista.');
    const d = manager.draft(words);
    setDraft(d); setAnswers(d.positions.map(() => '')); setStep('show');
    return d;
  }));
  const create = useAction(async () => said(async () => {
    const v = await manager.create(label, answers);
    setDraft(undefined); setStep('start'); setLabel(''); setAnswers([]); // the phrase leaves the screen and memory here
    onCreated?.(v);
    return v;
  }));
  const availability = manager.availability();
  if (!availability.ok) return <Notice tone="warn" title="Indisponível neste ambiente"><p>{availability.reason}</p></Notice>;
  const phrase = draft?.phrase.split(' ') ?? [];
  return (
    <div className="card" data-testid="create-subwallet">
      <h2>Criar sub-carteira</h2>
      <Notice tone="warn" title="Leia antes de continuar"><p>{LOST_SEED_WARNING}</p></Notice>
      <p className="faint">Cada sub-carteira tem a sua própria frase de recuperação, gerada neste aparelho. Ela não deriva da sua conta principal, da passkey nem de outra sub-carteira. {NO_MOVES_V2}</p>
      {step === 'start' && (
        <form onSubmit={(e) => { e.preventDefault(); void generate.run(); }}>
          <Field label="Nome da sub-carteira"><input value={label} onChange={(e) => setLabel(e.target.value)} placeholder="Ex.: Reserva" /></Field>
          <Field label="Tamanho da frase">
            <select value={words} onChange={(e) => setWords(Number(e.target.value) === 24 ? 24 : 12)}>
              <option value={12}>12 palavras</option><option value={24}>24 palavras</option>
            </select>
          </Field>
          <button type="submit">Gerar a frase</button>
        </form>
      )}
      {step === 'show' && draft && (
        <div>
          <Notice tone="danger" title="Esta frase não será mostrada de novo"><p>{SEED_SHOWN_ONCE}</p></Notice>
          <ol className="recovery-code" data-testid="seed-words">
            {phrase.map((w, i) => <li key={i}><span className="mono">{w}</span></li>)}
          </ol>
          <button type="button" onClick={() => setStep('check')}>Anotei, continuar</button>
        </div>
      )}
      {step === 'check' && draft && (
        <form onSubmit={(e) => { e.preventDefault(); void create.run(); }}>
          <p>Para confirmar que você anotou, digite as palavras pedidas.</p>
          {draft.positions.map((p, i) => (
            <Field key={p} label={`Palavra nº ${p}`}>
              <input value={answers[i] ?? ''} autoComplete="off" autoCapitalize="none" spellCheck={false}
                onChange={(e) => setAnswers((a) => a.map((x, j) => (j === i ? e.target.value : x)))} />
            </Field>
          ))}
          {create.busy ? <Spinner label="Criando..." /> : <button type="submit">Confirmar e criar</button>}
          <button type="button" className="secondary" onClick={() => setStep('show')}>Voltar às palavras</button>
        </form>
      )}
      <ErrorNotice error={generate.error ?? create.error} />
      {create.result && <Notice tone="ok" title="Sub-carteira criada"><p>{create.result.label} está pronta. A frase não está mais neste aparelho: só no seu papel.</p></Notice>}
    </div>
  );
}

export function RestoreSubWallet({ manager, onRestored }: { manager: SubWalletsPort; onRestored?: (v: SubWalletView) => void }) {
  const [label, setLabel] = useState('');
  const [phrase, setPhrase] = useState('');
  const restore = useAction(async () => said(async () => {
    if (!label.trim()) throw new InputInvalid('Dê um nome', 'Escolha um nome para esta sub-carteira.');
    const r = await manager.restore(label, phrase);
    setPhrase('');
    onRestored?.(r.view);
    return r;
  }));
  const availability = manager.availability();
  if (!availability.ok) return <Notice tone="warn" title="Indisponível neste ambiente"><p>{availability.reason}</p></Notice>;
  return (
    <form className="card" data-testid="restore-subwallet" onSubmit={(e) => { e.preventDefault(); void restore.run(); }}>
      <h2>Restaurar sub-carteira</h2>
      <p className="faint">Digite a frase de uma sub-carteira. O aplicativo procura na blockchain as notas dela e só dela. Sem a frase, uma sub-carteira perdida não pode ser recuperada: não há recuperação por guardiões.</p>
      <Field label="Nome"><input value={label} onChange={(e) => setLabel(e.target.value)} /></Field>
      <Field label="Frase de 12 ou 24 palavras">
        <textarea rows={3} value={phrase} autoComplete="off" autoCapitalize="none" spellCheck={false} onChange={(e) => setPhrase(e.target.value)} />
      </Field>
      {restore.busy ? <Spinner label="Procurando as notas na blockchain..." /> : <button type="submit">Restaurar</button>}
      <ErrorNotice error={restore.error} />
      {restore.result && <Notice tone="ok" title="Restaurada"><p>{restore.result.positions} posição(ões) reencontrada(s) e {restore.result.notes} nota(s) do histórico baixada(s).</p></Notice>}
    </form>
  );
}

export function SubWalletList({ manager, activeId, onSwitch, onForget }: {
  manager: SubWalletsPort; activeId?: string; onSwitch: (id?: string) => void; onForget?: (id: string) => void;
}) {
  const [rev, setRev] = useState(0);
  void rev;
  const items = manager.list();
  const open = useAction(async (id: string) => { await manager.open(id); onSwitch(id); });
  return (
    <div className="card" data-testid="subwallet-list">
      <h2>Suas carteiras</h2>
      <div className="list-item">
        <div className="row"><span className="label"><strong>Carteira principal</strong></span>{activeId === undefined && <span className="badge ok">Em uso</span>}</div>
        {activeId !== undefined && <div className="actions"><button type="button" className="secondary" onClick={() => onSwitch(undefined)}>Usar a principal</button></div>}
      </div>
      {items.length === 0 && <p className="faint">Você ainda não tem sub-carteiras.</p>}
      {items.map((s) => (
        <div className="list-item" key={s.id} data-testid="subwallet">
          <div className="row"><span className="label"><strong>{s.label}</strong></span>{activeId === s.id && <span className="badge ok">Em uso</span>}</div>
          <Row label="Conta" value={<span className="mono">{s.account}</span>} />
          <Row label="Ativos" value={s.assets.map((a) => (a === 'movva' ? 'Movva' : a)).join(', ')} />
          <Row label="Frase" value={s.backedUp ? (s.restored ? 'restaurada por você' : 'anotada e conferida') : 'não conferida'} />
          <div className="actions">
            {activeId !== s.id && (
              <button type="button" className="secondary" disabled={open.busy} onClick={() => void open.run(s.id)}>{open.busy ? 'Abrindo...' : 'Usar esta sub-carteira'}</button>
            )}
            <button type="button" className="danger" onClick={() => {
              if (typeof confirm === 'function' && !confirm(`Esquecer "${s.label}" neste aparelho? O saldo continua na blockchain; só a frase o recupera.`)) return;
              manager.forget(s.id); if (activeId === s.id) onSwitch(undefined); onForget?.(s.id); setRev((r) => r + 1);
            }}>Esquecer neste aparelho</button>
          </div>
        </div>
      ))}
      <p className="faint">{NO_MOVES_V2}</p>
      <ErrorNotice error={open.error} />
    </div>
  );
}

export function ShareSubWallets({ manager, now }: { manager: SubWalletsPort; now: number }) {
  const items = manager.list();
  const today = brasiliaIsoDate(now);
  const [picked, setPicked] = useState<string[]>([]);
  const [auditor, setAuditor] = useState('Receita Federal do Brasil');
  const [auditorKey, setAuditorKey] = useState('');
  const [purpose, setPurpose] = useState(`IRPF ${today.slice(0, 4)}`);
  const [from, setFrom] = useState(`${today.slice(0, 4)}-01-01`);
  const [to, setTo] = useState(today);
  const [days, setDays] = useState('30');
  const share = useAction(async (): Promise<SubWalletPackageActivity> => said(async () => {
    if (picked.length === 0) throw new InputInvalid('Escolha as sub-carteiras', 'Marque ao menos uma sub-carteira para compartilhar.');
    const key = auditorKey.trim().replace(/^0x/i, '').toLowerCase();
    if (!/^[0-9a-f]{64}$/.test(key)) throw new InputInvalid('Chave do auditor inválida', 'A chave pública do auditor tem 64 caracteres hexadecimais.');
    const fromTs = brasiliaTs(from, false);
    const toTs = Math.min(brasiliaTs(to, true), now);
    if (!(fromTs < toTs)) throw new InputInvalid('Período inválido', 'O início do período precisa ser anterior ao fim.');
    const validDays = Number(days);
    if (!Number.isInteger(validDays) || validDays < 1 || validDays > 366) throw new InputInvalid('Validade inválida', 'Um compartilhamento vale de 1 a 366 dias.');
    return manager.shareWithAuditor(picked, { auditor: auditor.trim(), auditorKey: key, purpose: purpose.trim(), fromTs, toTs, validDays });
  }));
  const toggle = (id: string) => setPicked((p) => (p.includes(id) ? p.filter((x) => x !== id) : [...p, id]));
  return (
    <form className="card" data-testid="share-subwallets" onSubmit={(e) => { e.preventDefault(); void share.run(); }}>
      <h2>Compartilhar com o auditor</h2>
      <p className="faint">Um único pacote com as sub-carteiras que você escolher. Cada uma tem a sua própria chave de leitura; o auditor lê cada uma separadamente e o total é a soma delas.</p>
      <Notice tone="warn" title="O que o pacote não prova"><p>{COMPLETENESS_OPEN}</p></Notice>
      {items.length === 0 && <p className="faint">Você ainda não tem sub-carteiras para compartilhar.</p>}
      {items.map((s) => (
        <label key={s.id} className="field" style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <input type="checkbox" style={{ width: 'auto' }} checked={picked.includes(s.id)} onChange={() => toggle(s.id)} aria-label={s.label} />
          <span style={{ margin: 0 }}>{s.label} <span className="mono faint">{s.account.slice(0, 8)}...</span></span>
        </label>
      ))}
      <Field label="Auditor"><input value={auditor} onChange={(e) => setAuditor(e.target.value)} /></Field>
      <Field label="Chave pública do auditor" hint="Fornecida pelo auditor (64 caracteres hexadecimais).">
        <input value={auditorKey} onChange={(e) => setAuditorKey(e.target.value)} autoComplete="off" className="mono" />
      </Field>
      <Field label="Finalidade"><input value={purpose} onChange={(e) => setPurpose(e.target.value)} /></Field>
      <div className="grid2">
        <Field label="De"><input type="date" value={from} max={today} onChange={(e) => setFrom(e.target.value)} /></Field>
        <Field label="Até"><input type="date" value={to} max={today} onChange={(e) => setTo(e.target.value)} /></Field>
      </div>
      <Field label="Validade (dias)"><input inputMode="numeric" value={days} onChange={(e) => setDays(e.target.value)} /></Field>
      {share.busy ? <Spinner label="Gerando as provas de cada sub-carteira..." /> : <button type="submit">Compartilhar</button>}
      <ErrorNotice error={share.error} />
      {share.result && (
        <Notice tone="ok" title="Compartilhado">
          <p>{share.result.package.subWallets.length} sub-carteira(s) em um só pacote. Entregue o arquivo somente ao auditor.</p>
          <div className="actions">
            <button type="button" className="secondary" onClick={() => downloadText(`auditoria-subcarteiras-${share.result!.package.subWallets[0].id.slice(0, 8)}.json`, share.result!.json, 'application/json')}>Baixar pacote do auditor</button>
          </div>
        </Notice>
      )}
    </form>
  );
}

type Tab = 'lista' | 'criar' | 'restaurar' | 'compartilhar';
const TABS: [Tab, string][] = [['lista', 'Carteiras'], ['criar', 'Criar'], ['restaurar', 'Restaurar'], ['compartilhar', 'Auditor']];

/** The screen at `#/subcarteiras`. */
export function SubWallets({ manager, activeId, onSwitch, now }: { manager: SubWalletsPort; activeId?: string; onSwitch: (id?: string) => void; now: number }) {
  const [tab, setTab] = useState<Tab>('lista');
  return (
    <>
      <h1>Sub-carteiras</h1>
      <div className="tabs" role="tablist">
        {TABS.map(([t, label]) => <button key={t} type="button" role="tab" className="tab" aria-selected={tab === t} onClick={() => setTab(t)}>{label}</button>)}
      </div>
      {tab === 'lista' && <SubWalletList manager={manager} activeId={activeId} onSwitch={onSwitch} />}
      {tab === 'criar' && <CreateSubWallet manager={manager} />}
      {tab === 'restaurar' && <RestoreSubWallet manager={manager} />}
      {tab === 'compartilhar' && <ShareSubWallets manager={manager} now={now} />}
    </>
  );
}
