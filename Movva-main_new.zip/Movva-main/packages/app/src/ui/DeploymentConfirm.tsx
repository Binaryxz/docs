import { useState } from 'react';
import type { AppDeployment } from '../lib/deployment.js';
import type { DeploymentVerdict } from '../lib/deployment-trust.js';
import { Notice } from './components.js';

export const UNPINNED_WARNING = (chainId: number) =>
  `A rede ${chainId} não está entre as embutidas no app. Os endereços dos contratos vêm só deste arquivo e ninguém os conferiu: `
  + 'um arquivo falso pode desviar o seu dinheiro. Use só para testes locais.';
export const PINNED_NOTE = (chainId: number) => `Os contratos conferem com o registro embutido no app para a rede ${chainId}.`;
export const CHANGED_INTRO = 'Este deployment é diferente do último que você aceitou neste aparelho. Confira o que muda:';
export const UNPINNED_ACK = 'Entendo o risco e confio neste arquivo';

export interface DeploymentConfirmProps {
  deployment: AppDeployment;
  verdict: Extract<DeploymentVerdict, { kind: 'confirm' }>;
  onConfirm: () => void;
  onCancel: () => void;
  /** Whether a deployment is in use now, which cancelling keeps. */
  hasCurrent: boolean;
}

/** Before a new or changed deployment is used: what differs, and for a chain without a canonical record, the risk. */
export function DeploymentConfirm({ deployment: d, verdict, onConfirm, onCancel, hasCurrent }: DeploymentConfirmProps) {
  const [ack, setAck] = useState(false);
  const unpinned = verdict.pinned === 'unpinned';
  return (
    <div className="card" data-testid="deployment-confirm">
      <h1>Confirmar deployment</h1>
      <p><strong>{d.name}</strong> · chain {d.chainId}</p>
      <p className="faint mono">{d.source}</p>
      {unpinned ? (
        <Notice tone="danger" title="Rede sem registro canônico">
          <p data-testid="unpinned-warning">{UNPINNED_WARNING(d.chainId)}</p>
        </Notice>
      ) : (
        <Notice tone="ok"><p>{PINNED_NOTE(d.chainId)}</p></Notice>
      )}
      {verdict.changes.length > 0 && (
        <>
          <p>{CHANGED_INTRO}</p>
          <table className="diff" data-testid="deployment-diff">
            <thead><tr><th>Campo</th><th>Antes</th><th>Agora</th></tr></thead>
            <tbody>
              {verdict.changes.map((c) => (
                <tr key={c.field} data-field={c.field}>
                  <td>{c.label}</td>
                  <td className="mono">{c.before ?? '(nenhum)'}</td>
                  <td className="mono">{c.after ?? '(nenhum)'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </>
      )}
      {unpinned && (
        <label className="field" style={{ display: 'flex', gap: 8, alignItems: 'center', marginTop: 12 }}>
          <input type="checkbox" style={{ width: 'auto' }} checked={ack} onChange={(e) => setAck(e.target.checked)} />
          <span style={{ margin: 0 }}>{UNPINNED_ACK}</span>
        </label>
      )}
      <div className="actions">
        <button type="button" className={unpinned ? 'danger' : undefined} disabled={unpinned && !ack} onClick={onConfirm}>Usar este deployment</button>
        <button type="button" className="secondary" onClick={onCancel}>{hasCurrent ? 'Manter o atual' : 'Recusar'}</button>
      </div>
    </div>
  );
}
