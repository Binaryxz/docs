import { formatBRL } from '../lib/format.js';
import { CopyField, ErrorNotice, Notice, Row, Spinner } from './components.js';
import { useAction, useAsync, useInterval, useWallet } from './hooks.js';

/** The demo stack's controls. Only reachable when the deployment names a dev API. */
export function DevPanel() {
  const w = useWallet();
  const dev = w.dev;
  const state = useAsync(async () => (dev ? dev.state() : undefined), [dev]);
  useInterval(state.reload, 5_000);
  const bills = useAsync(async () => (dev ? (await dev.sampleBills()).bills : []), [dev]);
  const auditor = useAsync(async () => (dev ? dev.auditorKey() : undefined), [dev]);
  const fund = useAction(async () => dev!.fund(w.address));
  if (!dev) return <Notice tone="info">Este deployment não é um ambiente de teste.</Notice>;
  const s = state.data;
  return (
    <>
      <h1>Ambiente de teste</h1>
      <Notice tone="warn" title="Somente para testes">
        <p>Estes botões agem como o seu banco num ambiente local. Numa rede real eles não existem.</p>
      </Notice>
      <div className="card dev">
        <h2>Rede local</h2>
        {s ? (
          <>
            <Row label="Chain ID" value={s.chainId} />
            <Row label="Bloco" value={s.block} />
            <Row label="Nó do provedor" value={s.lpNode.ready ? 'pronto' : 'iniciando'} />
            {s.lpNode.lastTickError && <Row label="Último erro do nó" value={<span className="mono">{s.lpNode.lastTickError}</span>} />}
          </>
        ) : <Spinner label="Lendo o estado..." />}
        <div className="actions">
          <button type="button" className="secondary" disabled={fund.busy} onClick={() => void fund.run()}>Abastecer a conta com gás de teste</button>
        </div>
        {fund.result && <p className="faint">{fund.result.funded ? 'Conta abastecida.' : 'A conta já tinha gás.'}</p>}
        <ErrorNotice error={fund.error ?? state.error} />
      </div>
      <div className="card dev">
        <h2>Pagamentos feitos pelo provedor (banco de teste)</h2>
        {s && s.outgoing.length === 0 && <p className="faint">Nenhum ainda.</p>}
        {s?.outgoing.map((o, i) => (
          <Row key={i} label={`${o.kind} para ${o.destination}`} value={`${formatBRL(BigInt(o.amountCents))} · ${o.status}`} />
        ))}
      </div>
      <div className="card dev">
        <h2>Boletos de teste para vender</h2>
        {bills.data?.map((b) => (
          <div key={b.label} className="list-item">
            <strong>{b.label}</strong>
            <p className="faint">{b.expect}</p>
            <CopyField label="Linha digitável" value={b.line} />
          </div>
        ))}
      </div>
      <div className="card dev">
        <h2>Auditor de teste</h2>
        {auditor.data && <CopyField label={`Chave pública de ${auditor.data.name}`} value={auditor.data.publicKey} />}
      </div>
      <p className="faint">Para pagar um pedido, abra-o em Comprar: o botão de simulação aparece ao lado das instruções verificadas.</p>
    </>
  );
}
