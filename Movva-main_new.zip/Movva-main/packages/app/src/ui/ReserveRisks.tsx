/**
 * "Reserva e riscos" (src/lib/reserve-risks.ts): a card for onboarding and Ajustes, and the screen Início links to.
 * The screen, inside an unlocked wallet, also shows the reserve's live coverage and, on a line of its own, the
 * delta-neutral position (`LiveCoverageCard`, MovvaWallet.coverage).
 */
import { useContext } from 'react';
import { LIVE_COVERAGE, RESERVE_RISKS } from '../lib/reserve-risks.js';
import { coverageView } from '../lib/format.js';
import type { WalletPort } from '../wallet/port.js';
import { Notice, Spinner } from './components.js';
import { WalletContext, useAsync, useInterval } from './hooks.js';

export function ReserveRisksCard({ sunken, heading = true }: { sunken?: boolean; heading?: boolean }) {
  const r = RESERVE_RISKS;
  return (
    <div className={`card${sunken ? ' sunken' : ''}`} data-testid="reserve-risks">
      {heading && <h2>{r.title}</h2>}
      <p>{r.fx}</p>
      <p>{r.strategy}</p>
      <p>{r.risksIntro}</p>
      <ul className="plain-list">
        {r.risks.map((x) => <li key={x}>{x}</li>)}
      </ul>
      <p>{r.shortfall}</p>
      <p>{r.equalTreatment}</p>
    </div>
  );
}

/** The coverage the reserve's contract computes, read now, and the strategy's position apart from it. */
export function LiveCoverageCard({ wallet }: { wallet: WalletPort & { coverage: NonNullable<WalletPort['coverage']> } }) {
  const coverage = useAsync(() => wallet.coverage(), [wallet]);
  useInterval(coverage.reload, 15_000);
  const c = coverage.data;
  if (!c) {
    if (coverage.error) {
      return (
        <div data-testid="live-coverage">
          <Notice tone="danger" title={LIVE_COVERAGE.title}><p>{LIVE_COVERAGE.unknown}</p></Notice>
        </div>
      );
    }
    return <Spinner label="Lendo a reserva..." />;
  }
  const v = coverageView(c);
  return (
    <div className="card" data-testid="live-coverage">
      <h2>{LIVE_COVERAGE.title}</h2>
      {v.ratio && <div className="big" data-testid="coverage-ratio">{v.ratio}</div>}
      <p className={v.ratio ? 'faint' : undefined} data-testid="coverage-caption">{v.caption}</p>
      {v.closedMarket && <p className="faint" data-testid="coverage-closed">{v.closedMarket}</p>}
      <h2 style={{ marginTop: 16 }}>{LIVE_COVERAGE.positionTitle}</h2>
      <p data-testid="hedge-position">{v.position}</p>
      {v.technical && (
        <details>
          <summary>Detalhes técnicos</summary>
          <span className="mono">{v.technical}</span>
        </details>
      )}
    </div>
  );
}

export function ReserveRisks() {
  // Rendered without a wallet too (before unlocking): the copy alone then.
  const wallet = useContext(WalletContext);
  return (
    <>
      <h1>{RESERVE_RISKS.title}</h1>
      {wallet?.coverage && <LiveCoverageCard wallet={wallet as WalletPort & { coverage: NonNullable<WalletPort['coverage']> }} />}
      <ReserveRisksCard heading={false} />
      <a href="#/inicio">Voltar ao saldo</a>
    </>
  );
}
