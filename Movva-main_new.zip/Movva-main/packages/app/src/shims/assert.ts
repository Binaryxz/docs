/**
 * `assert` for the Privacy Pools SDK, whose browser build imports it without depending on it (it is Node's module;
 * nothing installs the npm package). The SDK only ever calls `assert(condition)`. The one alias vite.config.ts keeps.
 */
function assert(condition: unknown, message?: string): asserts condition {
  if (!condition) throw new Error(message ?? 'assertion failed');
}

assert.ok = assert;
assert.strictEqual = (a: unknown, b: unknown, message?: string): void => assert(a === b, message ?? `${String(a)} !== ${String(b)}`);

export default assert;
