/**
 * What the service worker does with a push and a notification click: a recovery alert from the co-signer is shown with
 * @mova/cosigner/client's own handlers, opening Início (where the recovery queue and its veto are); anything else is left
 * alone. Kept apart from worker.ts, which only registers listeners, so it is tested (test/sw-handlers.test.ts).
 */
import {
  handleRecoveryNotificationClick, handleRecoveryPush, type ClientsLike, type NotificationRegistrationLike, type PushEventLike,
} from '@mova/cosigner/client';

export const BRASILIA = 'America/Sao_Paulo';

/** Início, under the worker's scope. */
export const alertUrl = (scope: string): string => new URL('./#/inicio', scope).href;

/** True when it was a recovery alert (shown); false for any other message. */
export function onPush(event: PushEventLike, registration: NotificationRegistrationLike & { scope: string }): boolean {
  return handleRecoveryPush(event, { registration, url: alertUrl(registration.scope), locale: 'pt-BR', timeZone: BRASILIA });
}

/** Focuses the app's open window, or opens Início. False for a notification that is not a recovery alert. */
export function onNotificationClick(
  event: { notification: { data?: unknown; close(): void }; waitUntil(promise: Promise<unknown>): void },
  clients: ClientsLike,
): boolean {
  return handleRecoveryNotificationClick(event, { clients });
}
