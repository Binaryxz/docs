/**
 * What the screens call: the wallet session's surface, as an interface, so each screen is rendered in tests against a
 * fake that answers the way the wallet does.
 */
import type { Address, Hex } from 'viem';
import type {
  AcrossNotes, AuditorShare, BuyOptions, BuyStatus, LockedOrder, MovvaBalance, MovvaCoverage, MovvaTaxYear, OpenedSale, PendingSale, Rail, RailQuote, Reais,
  ReshieldSource, Reshielded, ResumedSale, SaleQuote, SaleStatus, SubWalletDisclosurePackage, VerifiedPayment,
} from '@mova/wallet';
import type { AppDeployment } from '../lib/deployment.js';
import type { DeliveryBlock, DeliveryCheck } from './delivery-check.js';
import type { RecoveryAlertsView } from './alerts.js';
import type { DevApi } from './dev.js';

export interface OrderActivity {
  orderId: Hex;
  rail: Rail;
  amount: bigint;
  createdAt: number;
  payBy: number;
  /** The instructions as the wallet verified them. Never an unverified node answer. */
  payment?: VerifiedPayment;
  status?: BuyStatus;
  /** While the order waits to be released: whether its shielded delivery is still possible, as last read from the chain. */
  delivery?: DeliveryCheck;
}

export interface SaleActivity {
  saleId: Hex;
  rail: 'pix' | 'boleto';
  receive: bigint;
  cost: bigint;
  fee: bigint;
  /** The fresh account the sale was opened from, whose key this device keeps to cancel. */
  account: Address;
  /** Who is paid, for the user's own list: the PIX key or the bill's line. */
  payee: string;
  dueDate?: string;
  disclosedTo: number;
  createdAt: number;
  status?: SaleStatus;
}

export interface ShareActivity {
  id: string;
  auditor: string;
  purpose: string;
  createdAt: number;
  share: AuditorShare;
  revokedAt?: number;
}

export type GrantState = 'active' | 'expired' | 'revoked' | 'unknown';

/** The account's recovery queue (Zodiac Delay), as the co-signer reads it: what a stolen passkey may have queued. */
export interface RecoveryQueueView {
  /** False while the account has no recovery installed (before its first operation). */
  installed: boolean;
  delay?: Address;
  /** Set when something is queued: `setTxNonce(vetoNonce)` skips all of it. */
  vetoNonce?: bigint;
  pending: {
    nonce: bigint;
    txHash: Hex;
    createdAt: number;
    /** Unix seconds after which anyone may execute it. */
    executableAt: number;
    expiresAt: number;
    to?: Address;
    value?: bigint;
  }[];
}

/** `acrossNotes`: fund the sale from several notes when no single one does - opt-in, as it links those exits to one person. */
export type SellRequest = ({ receive: Reais; pixKey: string } | { boletoLine: string }) & { acrossNotes?: AcrossNotes };

/**
 * A sale this device started and has not finished (`MovvaWallet.pendingSales`), with what the screens show beside it.
 * Nothing in it spends: the sale account's key stays sealed in the session.
 */
export interface PendingSaleItem extends PendingSale {
  /** Who is paid - the PIX key, or the bill's line - as this device's sealed journal keeps it. */
  payee?: string;
  /** Being made or resumed right now in this session: nothing more is offered until that call returns. */
  busy?: boolean;
  /**
   * The last resume found an exit's proof still with the relayer (`exit_pending`). What the user asked for then is asked
   * again on every refresh, and the wallet sends nothing until the exit lands or can no longer land.
   */
  waitingForRelayer?: 'continue' | 'cancel';
  /** Why the last resume of this sale on this device failed, for the screen to explain. */
  lastError?: unknown;
}

/** Movva put back into the shielded balance from where it sat in the open. */
export interface ReshieldActivity {
  source: ReshieldSource;
  /** What it put back: the sale (its sale id), a sale that never opened (its pending id), or the order. */
  ref: string;
  saleId?: Hex;
  orderId?: Hex;
  /** What entered the shielded balance, after the pool's vetting fee. */
  amount: bigint;
  fee: bigint;
  /** The account that deposited: the new note's depositor of record. */
  from: Address;
  transactionHash: Hex;
  /** The ASP had not approved the note when it was deposited. `balance().pending` says whether it still has not. */
  awaitingApproval: boolean;
  createdAt: number;
}

export interface ShareRequest {
  auditor: string;
  auditorKey: string;
  purpose: string;
  fromTs: number;
  toTs: number;
  validDays: number;
}

export interface WalletPort {
  readonly deployment: AppDeployment;
  /** The user's account: public, the taker of every order. */
  readonly address: Address;
  /** The relayer's share of a sale's exit, basis points. */
  readonly exitRelayFeeBps: bigint;
  /** eoa, or a smart account: every call a sponsored UserOperation the passkey and the co-signer sign. */
  readonly accountKind?: 'eoa' | 'safe' | 'kernel';
  readonly dev?: DevApi;
  now(): number;

  subscribe(listener: () => void): () => void;
  /** Bumped on every change to the activity below, for `useSyncExternalStore`. */
  version(): number;
  orders(): OrderActivity[];
  sales(): SaleActivity[];
  shares(): ShareActivity[];
  reshields(): ReshieldActivity[];

  balance(): Promise<MovvaBalance>;
  /**
   * The reserve's live coverage and its delta-neutral position, reported apart (MovvaWallet.coverage). Optional, so a
   * port without it still builds; "Reserva e riscos" then shows the copy alone.
   */
  coverage?(): Promise<MovvaCoverage>;
  /** Fetch this wallet's encrypted notes from the vault again, for a balance refused because notes are missing. */
  resyncFromVault(): Promise<number>;
  /** Ask the chain about every order and sale still in progress, adopting what was delivered. */
  refreshActivity(): Promise<void>;

  quoteBuyByRail(amount: Reais, rails: Rail[]): Promise<BuyOptions>;
  buy(option: RailQuote): Promise<LockedOrder[]>;
  paymentInstructions(orderId: Hex): Promise<VerifiedPayment>;
  buyStatus(orderId: Hex): Promise<BuyStatus>;
  cancelBuy(orderId: Hex): Promise<void>;
  /** Whether an order locked or disputed can still be delivered into the shielded balance, read from the chain now. */
  deliveryCheck(orderId: Hex): Promise<DeliveryCheck>;
  /** The escape hatch: a shielded order whose delivery the pool would refuse is released to this account instead, in the open. */
  takeDeliveryDirect(orderId: Hex): Promise<void>;
  /** Why the pool would refuse an order delivered in the open back from this account now; empty when nothing stops it. */
  reshieldDeliveryBlocks(orderId: Hex): Promise<DeliveryBlock[]>;

  quoteSale(what: Reais | { boletoLine: string }, opts?: { acrossNotes?: AcrossNotes }): Promise<SaleQuote>;
  sell(request: SellRequest): Promise<OpenedSale>;
  saleStatus(saleId: Hex): Promise<SaleStatus>;
  cancelSale(saleId: Hex): Promise<void>;

  /** Sales this device started and has not finished, oldest first, from the sealed journal. */
  pendingSales(): PendingSaleItem[];
  /** Take a sale in progress up where it stopped, from its sale account; `cancel` gives it up and puts its Movva back. */
  resumeSale(id: string, o?: { cancel?: boolean }): Promise<ResumedSale>;
  /** A cancelled or refunded sale's Movva back into the shielded balance, from its sale account (an open sale is cancelled first). */
  reshieldSale(saleIdOrPendingId: string): Promise<Reshielded>;
  /** An order delivered in the open (takeDeliveryDirect) back into the shielded balance, from this account: visibly the user's. */
  reshieldDelivery(orderId: Hex): Promise<Reshielded>;

  shareWithAuditor(request: ShareRequest): Promise<ShareActivity>;
  revokeAuditor(id: string): Promise<void>;
  grantStates(): Promise<Record<string, GrantState>>;
  taxYear(year: number): MovvaTaxYear;

  /** A smart account's recovery queue. Absent for an EOA. */
  recoveryQueue?(): Promise<RecoveryQueueView>;
  /** Veto everything queued, with the passkey and the co-signer. */
  vetoRecovery?(): Promise<void>;

  /** This device's recovery alerts: whether it can subscribe, and whether it is. Absent for an EOA. */
  recoveryAlerts?(): Promise<RecoveryAlertsView>;
  /** Subscribe this device to the co-signer's recovery alerts, with the passkey. */
  enableRecoveryAlerts?(): Promise<void>;
  /** Unsubscribe it, with the passkey; refused while a recovery is queued (`recovery_pending`). */
  disableRecoveryAlerts?(): Promise<void>;
  /** Whether the one-time offer to turn alerts on was answered on this device. */
  recoveryAlertsOffered?(): boolean;
  dismissRecoveryAlertsOffer?(): void;

  /** Sub-wallets (this wallet is the primary account; a sub-wallet's own port has none). */
  readonly subWallets?: SubWalletsPort;
}

/** A sub-wallet as the screens list it: public facts only. Never a phrase or a key. */
export interface SubWalletView {
  id: string;
  label: string;
  /** The sub-wallet's own account. */
  account: Address;
  assets: readonly string[];
  backedUp: boolean;
  restored: boolean;
  createdAt: number;
}

/** A phrase waiting for its backup check. Held in memory only, one at a time: the next draft replaces it. */
export interface SubWalletDraft {
  phrase: string;
  /** 1-based positions of the words to ask back. */
  positions: number[];
}

/**
 * Sub-wallets (Rev. 3 section 6.2, 6.3): more wallets, each with its own seed phrase, shielded keys and account, in the same pools.
 * The app never exports two sub-wallets' phrases together: a phrase exists only in a draft, shown once.
 */
export interface SubWalletsPort {
  /** Whether sub-wallets can be created on this deployment, and if not why, in Portuguese. */
  availability(): { ok: true } | { ok: false; reason: string };
  list(): SubWalletView[];
  /** A new phrase from fresh entropy; replaces any earlier draft. */
  draft(words?: 12 | 24): SubWalletDraft;
  /** Create from the current draft once the person has answered the backup check. Refuses wrong answers. */
  create(label: string, answers: readonly string[]): Promise<SubWalletView>;
  /** Restore from a phrase typed on this device, rescanning the pools for its notes. */
  restore(label: string, phrase: string): Promise<{ view: SubWalletView; positions: number; notes: number }>;
  /** The sub-wallet's own session, opened on first use: every screen of the app runs on it unchanged. */
  open(id: string): Promise<WalletPort>;
  /** Forget it on this device. Funds are untouched; the phrase restores it. */
  forget(id: string): void;
  /** ONE package for the selected sub-wallets (VK-7). */
  shareWithAuditor(ids: readonly string[], request: ShareRequest): Promise<SubWalletPackageActivity>;
}

export interface SubWalletPackageActivity {
  package: SubWalletDisclosurePackage;
  /** The package as the auditor receives it, JSON. */
  json: string;
}
