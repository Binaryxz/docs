/**
 * The local demo stack's dev API (scripts/dev-stack.ts): gas for the demo accounts, and "pay this" buttons that act
 * as the user's bank - they call the stack's MockBank, exactly what a real payment would make
 * the LP node see. Present only when the deployment JSON names a dev URL; never in a real deployment.
 */
import type { Address } from 'viem';
import { plainFetch, RemoteServiceError, type Fetch } from './remote.js';

export interface DevState {
  chainId: number;
  block: string;
  lpNode: { ready: boolean; lastTickError?: string };
  outgoing: { kind: string; destination: string; amountCents: string; status: string }[];
}

export interface SampleBill { label: string; line: string; expect: string }

export class DevApi {
  constructor(readonly url: string, private readonly fetchImpl: Fetch = plainFetch) {}

  private async req<T>(method: 'GET' | 'POST', path: string, body?: unknown): Promise<T> {
    const res = await this.fetchImpl(`${this.url}${path}`, method === 'GET' ? {} : {
      method, headers: { 'content-type': 'application/json' }, body: JSON.stringify(body ?? {}),
    });
    const json = await res.json().catch(() => ({})) as T & { error?: string };
    if (!res.ok) throw new RemoteServiceError('dev', res.status, `dev ${path}: ${res.status} ${json.error ?? ''}`.trim());
    return json;
  }

  state(): Promise<DevState> { return this.req('GET', '/state'); }
  /** Test ETH for gas, standing in for a paymaster. Only when the account is short of it. */
  fund(address: Address): Promise<{ funded: boolean }> { return this.req('POST', '/fund', { address }); }
  payPix(pixCopiaECola: string): Promise<{ paid: string }> { return this.req('POST', '/pay-pix', { pixCopiaECola }); }
  payBoleto(line: string): Promise<{ paid: string }> { return this.req('POST', '/pay-boleto', { line }); }
  sampleBills(): Promise<{ bills: SampleBill[] }> { return this.req('GET', '/sample-bills'); }
  auditorKey(): Promise<{ publicKey: string; name: string }> { return this.req('GET', '/auditor-key'); }
}
