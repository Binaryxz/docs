/**
 * The user's account as a smart account: a Safe 1.4.1 whose owners are the passkey's WebAuthn signer and the
 * deployment's co-signer, 2-of-2 (the default), or a Kernel v3.1 account whose root validator, PasskeyCoSignerValidator,
 * requires the same two keys (docs/wallet-custody.md, §10-11).
 *
 * Every call MovvaWallet makes from its `account` - lock an order, cancel it, register or revoke an audit grant - is
 * one UserOperation: the passkey signs its digest in the browser (`navigator.credentials.get`), the co-signer service
 * checks that signature and the operation against its policy and adds its half over HTTP (`RemoteCoSigner`), the
 * bundler submits it, and SponsorPaymaster pays the gas. The account holds no ETH. ERC-1271 signatures (the LP node's
 * payment-instructions requests) go the same way.
 *
 * What the app adds around the library's executors:
 *
 *  - **Recovery in the first operation.** While the account's recovery Delay has no code, the next `execute` is prefixed
 *    with the recovery setup (Zodiac Delay, 7-day cooldown, the passkey's signer as its only module): `recoverySetupCalls`
 *    for a Safe, `kernelRecoverySetupCalls` for Kernel. The co-signer's policy allows exactly that, at the start of an
 *    operation, and nothing else of the kind. The test is the Delay, not the account: a Kernel account is created by the
 *    co-signer before its first operation, so "has no code" would skip its recovery setup.
 *  - **Nothing this app sends ever carries a Kernel account's initCode.** `ready()` waits for the account to have code,
 *    which the co-signer's sponsorship creates at enrolment; `KernelExecutor` omits initCode from that point on. A public
 *    bundler refuses a Kernel first operation that creates the account through Kernel's meta factory (wallet-custody.md
 *    §10.3). The Safe is admitted from its first operation and is unaffected.
 *  - **Enrolment, then the co-signer's sponsorship, before the first operation** (`prepare`, `enrolAndSponsor`). The
 *    co-signer must know the counterfactual account (bound through its CREATE2 address and one passkey assertion). Its
 *    sponsorship module then allowlists the account on SponsorPaymaster through SponsorGate, from its own operator key -
 *    and, for a Safe, first creates the passkey signer contract the Safe validates its first operation through - and
 *    `prepare` waits for it (`waitForSponsorship`). Nobody holding the paymaster owner's key is involved, and nothing
 *    in the app allowlists anything itself (docs/wallet-custody.md §11.1). With OwnerlessPaymaster there is no gate and
 *    nothing to allowlist; the co-signer still creates the passkey signer or the Kernel account, and `prepare` is the same
 *    (docs/ownerless-paymaster.md, "Onboarding without a SponsorGate").
 *  - **Either paymaster.** A deployment names SponsorPaymaster (`paymasterAndData`, fixed bytes; the account must be
 *    allowlisted) or OwnerlessPaymaster (`ownerlessPaymaster`). The ownerless one sponsors any account its factories
 *    created, by CREATE2 address, so nothing allowlists it: every operation carries 91 bytes the wallet builds for it
 *    (the account's salt, the current window, the validation gas for the chain: `ownerlessPaymasterAndData`), and the
 *    fees are fitted under the contract's MAX_COST_PER_OP (`accountPaymaster`, SRM1-17).
 *  - **Accounts without a passkey** (`openSoleOwnerSafe`): a sub-wallet's own account, and the accounts its sales open from,
 *    are Safes with one owner, a key this page holds. On a deployment whose paymaster is OwnerlessPaymaster that is all
 *    they need: the SafeProxyFactory creates each in its first operation and the paymaster pays for it by its address,
 *    with no co-signer, no enrolment and nothing allowlisted.
 *  - **The co-signer is pinned.** /v1/info must name the address the deployment names, or nothing is signed.
 *  - **The recovery queue** (`queue`, `veto`): what the Delay holds, as the co-signer reads it, and the veto - an
 *    operation of `setTxNonce` alone, which the co-signer co-signs only on its veto route with the passkey's fresh
 *    signature.
 */
import { getAddress, parseAbi, size, slice, toHex, type Address, type LocalAccount, type PublicClient } from 'viem';
import {
  encodeVeto, kernelInitData, kernelRecoverySetupCalls, passkeyCoSignerInstallData, passkeyCoSignerSigner, predictKernelAddress,
  predictSafeAddress, predictSignerAddress, recoverySetupCalls,
  type PasskeyPublicKey, type WebAuthnAssertion,
} from '@mova/smart-account';
import {
  KernelExecutor, OWNERLESS_FACTORY_INDEX, OWNERLESS_PAYMASTER_ABI, SafeExecutor, ownerlessAccountAddress, ownerlessPaymasterAndData,
  passkeySafeOwner, readOwnerlessPolicy, soleOwnerSafeExecutor,
  type AccountExecutor, type Call, type Executed, type OwnerlessAccount, type PaymasterAndDataSource, type UserOpSubmitter,
} from '@mova/wallet';
import { CoSignerRefused, RemoteCoSigner, type RemoteSponsorship } from '@mova/cosigner/client';
import type { SmartAccountConfig, SmartAccountKind } from '../lib/deployment.js';
import type { RecoveryQueueView } from './port.js';

/** The key that owns the account beside the co-signer: the passkey, or a key held by the page (a sale account). */
export interface AccountOwnerKey {
  readonly publicKey: PasskeyPublicKey;
  sign(challenge: Uint8Array): Promise<WebAuthnAssertion>;
}

/** The account could not be set up: said in Portuguese, for the screen. */
export class AccountSetupError extends Error {}

const PAYMASTER_ABI = parseAbi(['function sponsored(address account) view returns (bool)']);

/** What one account's operations carry for the deployment's paymaster, and whether that paymaster will pay for it. */
export interface AccountPaymaster {
  paymasterAndData: PaymasterAndDataSource;
  /** OwnerlessPaymaster's MAX_COST_PER_OP: the executors fit the fees under it, or refuse before signing. */
  paymasterMaxCostPerOp?: bigint;
  /** SponsorPaymaster: allowlisted. OwnerlessPaymaster: its own `accountAddress` for the salt is this account. */
  sponsored(): Promise<boolean>;
}

/**
 * The deployment's paymaster, for accounts on `chainId`. For OwnerlessPaymaster the window length and the per-op cap
 * are read from the contract once here; a paymaster that does not answer them is not one this app can use.
 */
export async function accountPaymaster(config: Pick<SmartAccountConfig, 'paymasterAndData' | 'ownerlessPaymaster'>, chainId: number, pub: Pick<PublicClient, 'readContract'>) {
  const ownerless = config.ownerlessPaymaster;
  if (ownerless) {
    const paymaster = getAddress(ownerless.address);
    const policy = await ownerlessPolicy(pub, paymaster);
    return (account: OwnerlessAccount, address: Address): AccountPaymaster => {
      const { salt } = ownerlessAccountAddress(account);
      return {
        paymasterAndData: ownerlessPaymasterAndData({
          paymaster, chainId, windowSeconds: policy.windowSeconds,
          verificationGasLimit: ownerless.verificationGasLimit, postOpGasLimit: ownerless.postOpGasLimit,
        }, account),
        paymasterMaxCostPerOp: policy.maxCostPerOp,
        sponsored: async () => getAddress(await pub.readContract({
          address: paymaster, abi: OWNERLESS_PAYMASTER_ABI, functionName: 'accountAddress', args: [OWNERLESS_FACTORY_INDEX[account.factory], salt],
        }) as Address) === getAddress(address),
      };
    };
  }
  const fixed = config.paymasterAndData;
  if (!fixed || size(fixed) < 20) throw new AccountSetupError('o deployment não nomeia um paymaster');
  const paymaster = getAddress(slice(fixed, 0, 20));
  return (_account: OwnerlessAccount, address: Address): AccountPaymaster => ({
    paymasterAndData: fixed,
    sponsored: async () => await pub.readContract({ address: paymaster, abi: PAYMASTER_ABI, functionName: 'sponsored', args: [address] }) as boolean,
  });
}

/** OwnerlessPaymaster's WINDOW and MAX_COST_PER_OP; a paymaster that does not answer them is not one this app can use. */
async function ownerlessPolicy(pub: Pick<PublicClient, 'readContract'>, paymaster: Address): Promise<{ windowSeconds: bigint; maxCostPerOp: bigint }> {
  try {
    return await readOwnerlessPolicy(pub, paymaster);
  } catch (e) {
    throw new AccountSetupError(`o paymaster ${paymaster} não responde como OwnerlessPaymaster (WINDOW, MAX_COST_PER_OP): ${e instanceof Error ? e.message.split('\n')[0] : String(e)}`);
  }
}

/** True when accounts without a passkey (sub-wallets, their sale accounts) have their gas paid on this deployment. */
export const sponsorsSoleOwnerSafes = (config: Pick<SmartAccountConfig, 'ownerlessPaymaster'>): boolean => config.ownerlessPaymaster !== undefined;

/**
 * A Safe 1.4.1 whose only owner is `owner`, a key this page holds, with the deployment's OwnerlessPaymaster paying every
 * operation from the first, which creates it. For a sub-wallet's own account (`subWalletSaltNonce`) and the sale accounts
 * it opens; never the user's primary account, which is 2-of-2 with the passkey and the co-signer.
 */
export async function openSoleOwnerSafe(
  env: Pick<SmartAccountEnv, 'config' | 'chainId' | 'publicClient' | 'bundler'>, owner: LocalAccount, saltNonce: bigint,
): Promise<AccountExecutor> {
  const ownerless = env.config.ownerlessPaymaster;
  if (!ownerless) throw new AccountSetupError('este deployment só patrocina o gás de contas com passkey: falta account.ownerlessPaymaster');
  const paymaster = getAddress(ownerless.address);
  const policy = await ownerlessPolicy(env.publicClient, paymaster);
  return soleOwnerSafeExecutor({
    owner, saltNonce, chainId: env.chainId, publicClient: env.publicClient, submitter: env.bundler, gas: env.config.gas,
    paymaster: { paymaster, windowSeconds: policy.windowSeconds, verificationGasLimit: ownerless.verificationGasLimit, postOpGasLimit: ownerless.postOpGasLimit },
    maxCostPerOp: policy.maxCostPerOp,
  });
}

export interface SmartAccountEnv {
  config: SmartAccountConfig;
  chainId: number;
  publicClient: PublicClient;
  cosigner: RemoteCoSigner;
  bundler: UserOpSubmitter;
  /** How long `prepare` waits for the co-signer's sponsorship of a new account. Default two minutes. */
  sponsorshipTimeoutMs?: number;
}

export interface SmartAccount {
  readonly kind: SmartAccountKind;
  readonly address: Address;
  /** The owner key's SafeWebAuthnSigner: a Safe owner, and on both kinds the recovery Delay's only module. */
  readonly passkeySigner: Address;
  readonly coSigner: Address;
  readonly executor: AccountExecutor;
  deployed(): Promise<boolean>;
  /** Sponsored (and, for a Safe, its passkey signer created) and enrolled with the co-signer, doing what is missing. */
  prepare(): Promise<{ enrolled: boolean; sponsored: boolean }>;
  queue(): Promise<RecoveryQueueView>;
  /** Veto every queued recovery transaction. Undefined when nothing is queued. */
  veto(): Promise<Executed | undefined>;
}

/** The co-signer, checked against the deployment before anything is sent to it. */
export async function connectCoSigner(config: SmartAccountConfig, chainId: number, fetchImpl: typeof fetch): Promise<RemoteCoSigner> {
  const cosigner = new RemoteCoSigner({ url: config.cosigner.url, chainId, apiKey: config.cosigner.apiKey, fetch: fetchImpl });
  let info;
  try {
    info = await cosigner.info();
  } catch (e) {
    if (e instanceof CoSignerRefused) throw e;
    throw new AccountSetupError(`o cossignatário em ${config.cosigner.url} não respondeu (${e instanceof Error ? e.message : String(e)})`);
  }
  if (info.chainId !== chainId) throw new AccountSetupError(`o cossignatário atende a chain ${info.chainId}, e o deployment é da chain ${chainId}`);
  if (getAddress(info.coSigner) !== getAddress(config.cosigner.address)) {
    throw new AccountSetupError(`o cossignatário se identifica como ${info.coSigner}, mas o deployment fixa ${config.cosigner.address}: nada será assinado com ele`);
  }
  const validator = info.deployment?.passkeyValidator;
  if (config.kernel && validator && getAddress(validator) !== getAddress(config.kernel.passkeyValidator)) {
    throw new AccountSetupError('o cossignatário usa outro PasskeyCoSignerValidator que o deployment');
  }
  return cosigner;
}

const refusedWith = (e: unknown, ...codes: string[]) => e instanceof CoSignerRefused && codes.includes(e.code);

/** What `enrolAndSponsor` asks of the co-signer and the chain, for one account. */
export interface SponsorshipSteps {
  /** Enrolled with the co-signer already. */
  enrolled(): Promise<boolean>;
  /** Enrol (or enrol again), with a passkey assertion: the answer carries the sponsorship it started, when the service sponsors. */
  enrol(): Promise<{ sponsorship?: RemoteSponsorship }>;
  /**
   * Allowlisted on the paymaster, and whatever else the first operation needs on-chain: a Safe's passkey signer, a
   * Kernel account's own code. Both are the co-signer's to create at enrolment.
   */
  ready(): Promise<boolean>;
  sponsorship(): Promise<RemoteSponsorship>;
  /** Until granted; throws `SponsorshipNotGranted` when refused, failed, or still pending when the wait runs out. */
  waitForSponsorship(): Promise<RemoteSponsorship>;
}

/**
 * Before an account's first operation: enrolled with the co-signer, then sponsored by it. An account that can already
 * transact asks nothing. An enrolled account the chain is not ready for is enrolled again, which asks the service
 * again - whether its sponsorship was never requested (enrolled before the service sponsored, or forgotten across a
 * restart), was refused for a reason that may pass, or is reported as granted while something it creates is still
 * missing (a Kernel account it never deployed, a Safe's passkey signer). One refused for good
 * (`sponsorship_revoked`) is not asked again, and one already in flight is only waited for.
 */
export async function enrolAndSponsor(s: SponsorshipSteps): Promise<{ enrolled: boolean; sponsored: boolean }> {
  let enrolled = false;
  let started: RemoteSponsorship | undefined;
  if (!(await s.enrolled())) {
    started = (await s.enrol()).sponsorship;
    enrolled = true;
  }
  if (await s.ready()) return { enrolled, sponsored: false };
  let current = started ?? await s.sponsorship();
  const retry = current.status === 'refused' || current.status === 'failed' ? current.retryable === true : current.status !== 'pending';
  if (!enrolled && retry) current = (await s.enrol()).sponsorship ?? current;
  if (current.status !== 'sponsored') await s.waitForSponsorship();
  if (!(await s.ready())) {
    throw new AccountSetupError('o cossignatário informa a conta como patrocinada, mas ela ainda não pode operar neste deployment: '
      + 'o paymaster não a registra, ou a conta (Kernel) ou o signatário da passkey (Safe) ainda não existe na chain');
  }
  return { enrolled, sponsored: true };
}

export async function openSmartAccount(env: SmartAccountEnv, o: { kind: SmartAccountKind; owner: AccountOwnerKey; salt: bigint }): Promise<SmartAccount> {
  const { config, chainId, publicClient: pub, cosigner, bundler } = env;
  const coSigner = getAddress(config.cosigner.address);
  const owner = o.owner.publicKey;
  const sign = (challenge: Uint8Array) => o.owner.sign(challenge);
  const { gas } = config;
  const paymasterFor = await accountPaymaster(config, chainId, pub);
  const passkeySigner = await predictSignerAddress(pub, owner);

  let address: Address;
  let inner: AccountExecutor;
  let setupCalls: () => Call[];
  /** The recovery Delay the setup creates, at its CREATE2 address. */
  let delay: Address;
  let enrol: () => Promise<{ sponsorship?: RemoteSponsorship }>;
  let pm: AccountPaymaster;
  if (o.kind === 'safe') {
    const owners = [passkeySigner, coSigner];
    const safe = await predictSafeAddress(pub, owners, 2, o.salt);
    const remote = cosigner.safe({ safe, passkeySigner, coSigner });
    address = safe;
    pm = paymasterFor({ factory: 'safe', owners, threshold: 2, saltNonce: o.salt }, safe);
    inner = remote.wrap(new SafeExecutor({
      safe, chainId, publicClient: pub, owners: [passkeySafeOwner(passkeySigner, sign), remote.owner], submitter: remote.submitter(bundler),
      deploy: { owners, threshold: 2, saltNonce: o.salt }, gas, paymasterAndData: pm.paymasterAndData, paymasterMaxCostPerOp: pm.paymasterMaxCostPerOp,
    }));
    setupCalls = () => recoverySetupCalls(safe, passkeySigner).calls.map((c) => ({ to: c.to, data: c.data, value: c.value }));
    delay = recoverySetupCalls(safe, passkeySigner).delay;
    enrol = () => cosigner.enrol({ account: safe, type: 'safe', coSigner, passkey: owner, sign, safe: { owners, threshold: 2, saltNonce: o.salt } });
  } else {
    const kernel = config.kernel;
    if (!kernel) throw new AccountSetupError('este deployment não oferece contas Kernel');
    const deploy = { initData: kernelInitData({ rootValidator: kernel.passkeyValidator, validatorData: passkeyCoSignerInstallData({ passkey: owner, coSigner }) }), salt: o.salt };
    const account = predictKernelAddress(deploy);
    const remote = cosigner.kernel({ account, validator: kernel.passkeyValidator, coSigner });
    address = account;
    pm = paymasterFor({ factory: 'kernel', deployment: deploy }, account);
    inner = remote.wrap(new KernelExecutor({
      account, chainId, publicClient: pub, submitter: remote.submitter(bundler), deploy, gas,
      paymasterAndData: pm.paymasterAndData, paymasterMaxCostPerOp: pm.paymasterMaxCostPerOp,
      signer: passkeyCoSignerSigner({ validator: kernel.passkeyValidator, passkey: sign, coSigner: remote.coSign }),
    }));
    setupCalls = () => kernelRecoverySetupCalls({ account, passkey: owner, passkeySigner, adapter: kernel.adapter }).calls
      .map((c) => ({ to: c.to, data: c.data, value: (c as { value?: bigint }).value ?? 0n }));
    delay = kernelRecoverySetupCalls({ account, passkey: owner, passkeySigner, adapter: kernel.adapter }).delay;
    enrol = () => cosigner.enrol({ account, type: 'kernel', coSigner, passkey: owner, sign, kernel: { initData: deploy.initData, salt: toHex(o.salt, { size: 32 }) } });
  }

  const deployed = async () => {
    const code = await pub.getCode({ address });
    return !!code && code !== '0x';
  };
  const executor: AccountExecutor = {
    address, kind: inner.kind,
    signTypedData: (typedData) => inner.signTypedData(typedData),
    // The account's first operation installs recovery before anything else it does.
    execute: async (calls) => {
      const code = await pub.getCode({ address: delay });
      return inner.execute(code && code !== '0x' ? calls : [...setupCalls(), ...calls]);
    },
  };

  const enrolled = async (): Promise<boolean> => {
    try {
      await cosigner.queue(address);
      return true;
    } catch (e) {
      if (refusedWith(e, 'no_recovery_module')) return true;
      if (refusedWith(e, 'not_enrolled')) return false;
      throw e;
    }
  };
  const ready = async (): Promise<boolean> => {
    const [sponsored, signerCode, isDeployed] = await Promise.all([pm.sponsored(), pub.getCode({ address: passkeySigner }), deployed()]);
    // A Safe validates its first operation through its passkey owner, so that contract must exist first.
    const signerMissing = o.kind === 'safe' && !isDeployed && (!signerCode || signerCode === '0x');
    // A Kernel account must exist before its first operation: a rule-enforcing bundler refuses an operation whose
    // initCode creates it through Kernel's meta factory (docs/wallet-custody.md §10.3), so the co-signer deploys it at
    // enrolment and `KernelExecutor` then carries no initCode.
    const accountMissing = o.kind === 'kernel' && !isDeployed;
    return sponsored && !signerMissing && !accountMissing;
  };

  return {
    kind: o.kind, address, passkeySigner, coSigner, executor, deployed,
    async prepare() {
      return enrolAndSponsor({
        enrolled, enrol, ready,
        sponsorship: () => cosigner.sponsorship(address),
        waitForSponsorship: () => cosigner.waitForSponsorship(address, { timeoutMs: env.sponsorshipTimeoutMs ?? 120_000, intervalMs: 1_000 }),
      });
    },
    async queue() {
      try {
        const q = await cosigner.queue(address);
        return {
          installed: true, delay: q.delay, vetoNonce: q.vetoNonce,
          pending: q.pending.map((p) => ({
            nonce: p.nonce, txHash: p.txHash, createdAt: Number(p.createdAt), executableAt: Number(p.executableAt), expiresAt: Number(p.expiresAt),
            ...(p.call ? { to: p.call.to, value: p.call.value } : {}),
          })),
        };
      } catch (e) {
        if (refusedWith(e, 'no_recovery_module', 'not_enrolled')) return { installed: false, pending: [] };
        throw e;
      }
    },
    async veto() {
      const q = await cosigner.queue(address);
      if (q.vetoNonce === undefined) return undefined;
      return executor.execute([{ to: q.delay, data: encodeVeto(q.vetoNonce) }]);
    },
  };
}
