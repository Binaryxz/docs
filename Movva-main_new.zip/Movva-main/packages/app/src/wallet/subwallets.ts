/**
 * Sub-wallets on this device (Rev. 3 section 6.2-6.3, VK-7).
 *
 * Each is a wallet over its OWN 32-byte root, which comes from its own BIP-39 phrase and nothing else (packages/wallet
 * `subwallet.ts`). The app opens it with the code that opens the primary - `WalletSession.open` given that root - so it has its
 * own shielded keys, its own account and its own sealed records, in the same pools.
 *
 * What this device keeps, sealed under the unlocked wallet's key, and what it does not:
 *  - the **registry** (label, account address, assets, whether the backup was checked): public facts, never a phrase;
 *  - each sub-wallet's **root**, so it opens without asking for the phrase every time. The phrase cannot be recovered from it;
 *  - the **phrase** is never kept. It lives in a draft, in memory, until the backup check passes, and is shown once. The app
 *    has no screen or call that shows a phrase again, and no call that returns two phrases.
 * Movva's servers hold none of this. A lost phrase is a lost sub-wallet; on a new device the person restores each one from its
 * phrase, which rescans the pool for its notes.
 *
 * Its account: on a smart-account deployment whose paymaster is OwnerlessPaymaster, the 1-of-1 Safe of its own account key
 * (`subWalletSafe`), which the paymaster pays for from its first operation by its CREATE2 address - no passkey, no co-signer,
 * nothing allowlisted. On an EOA deployment, or the dev stack without that paymaster, the key itself as an EOA, funded by the
 * dev stack.
 */
import { getAddress, type Address } from 'viem';
import {
  SubWalletRefused, SubWalletRegistry, backupChallenge, createSubWallet, entryFor, restoreSubWallet, shareSubWalletsWithAuditor, subWalletKeysFromSeed,
  subWalletSafe,
  type BackupChallenge, type SubWalletEntry, type SubWalletGuard, type SubWalletKeys,
} from '@mova/wallet';
import { isSmartAccount, type AppDeployment } from '../lib/deployment.js';
import { sponsorsSoleOwnerSafes } from './account.js';
import { stringify } from '../lib/json.js';
import type { SubWalletDraft, SubWalletPackageActivity, SubWalletView, SubWalletsPort, ShareRequest, WalletPort } from './port.js';
import { SealedStore, storeKeyFromSeed, type KeyValue } from './stores.js';

const hex = (b: Uint8Array): string => Array.from(b, (x) => x.toString(16).padStart(2, '0')).join('');
const unhex = (s: string): Uint8Array => Uint8Array.from(s.match(/../g) ?? [], (x) => parseInt(x, 16));

/** How many words of the phrase the backup check asks back. */
export const BACKUP_WORDS_ASKED = 3;

/** What the manager needs of a session: the port, and the two calls that set a wallet up. `WalletSession` is one. */
export type SubSession = WalletPort & { restoreOrFile(): Promise<{ restored: boolean; positions: number; notes: number }>; ensureGas(): Promise<void> };

export interface SubWalletManagerOptions {
  kv: KeyValue;
  deployment: AppDeployment;
  /** The primary wallet's root, which seals the registry and which no sub-wallet may be, hold or derive. */
  primarySeed: Uint8Array;
  primaryAddress: Address;
  /** Open a session over a sub-wallet's own root (WalletSession.open with `subWallet`). */
  open: (seed: Uint8Array) => Promise<SubSession>;
  now: () => number;
  assets?: readonly string[];
}

export class SubWalletManager implements SubWalletsPort {
  private readonly store: SealedStore;
  private readonly registry: SubWalletRegistry;
  private readonly sessions = new Map<string, Promise<{ session: SubSession; summary: { restored: boolean; positions: number; notes: number } }>>();
  private current?: { phrase: string; keys: SubWalletKeys; challenge: BackupChallenge };

  constructor(private readonly o: SubWalletManagerOptions) {
    this.store = new SealedStore(o.kv, storeKeyFromSeed(o.primarySeed), `mova:subwallets:${o.deployment.chainId}:${o.primaryAddress.toLowerCase()}:`);
    this.registry = new SubWalletRegistry(this.store);
  }

  /** The sub-wallet's account is a sole-owner Safe the OwnerlessPaymaster pays for (else the key as an EOA). */
  private get sponsoredSafe(): boolean {
    const a = this.o.deployment.account;
    return isSmartAccount(a) && sponsorsSoleOwnerSafes(a);
  }

  availability(): { ok: true } | { ok: false; reason: string } {
    // A sub-wallet has no passkey and no co-signer. Its gas is paid by OwnerlessPaymaster, which admits its Safe by address;
    // or, on the dev stack, by the faucet. A SponsorPaymaster deployment allowlists only accounts the co-signer enrolled.
    if (isSmartAccount(this.o.deployment.account) && !this.sponsoredSafe && !this.o.deployment.dev) {
      return { ok: false, reason: 'Este ambiente patrocina o gás só de contas com passkey. Uma sub-carteira tem conta própria, sem a sua passkey, e ainda não tem patrocínio de gás aqui.' };
    }
    return { ok: true };
  }

  /** The registry entry: the sub-wallet's account is its Safe where that is what the session opens. */
  private entry(keys: SubWalletKeys, label: string, extra: Partial<SubWalletEntry>): SubWalletEntry {
    return entryFor(keys, label, this.o.now(), { ...extra, ...(this.sponsoredSafe ? { account: subWalletSafe(keys).address } : {}) });
  }

  private view(e: SubWalletEntry): SubWalletView {
    return { id: e.id, label: e.label, account: e.account, assets: e.assets, backedUp: e.backedUp, restored: e.restored === true, createdAt: e.createdAt };
  }

  list(): SubWalletView[] { return this.registry.list().map((e) => this.view(e)); }

  private guard(): SubWalletGuard {
    return { primaryRoot: this.o.primarySeed, primaryAccounts: [this.o.primaryAddress], existing: this.registry.ids() };
  }

  draft(words: 12 | 24 = 12): SubWalletDraft {
    this.assertAvailable();
    // One phrase at a time: the earlier draft is dropped, so two phrases are never on screen or in memory together.
    const { phrase, keys } = createSubWallet({ words, guard: this.guard(), assets: this.o.assets });
    const challenge = backupChallenge(phrase, BACKUP_WORDS_ASKED);
    this.current = { phrase, keys, challenge };
    return { phrase, positions: challenge.positions };
  }

  private assertAvailable(): void {
    const a = this.availability();
    if (!a.ok) throw new SubWalletRefused('bad_assets', a.reason);
  }

  async create(label: string, answers: readonly string[]): Promise<SubWalletView> {
    const d = this.current;
    if (!d) throw new SubWalletRefused('invalid_phrase', 'não há uma frase em andamento: gere uma nova');
    if (!d.challenge.verify(answers)) throw new SubWalletRefused('invalid_phrase', 'as palavras não conferem com a frase: confira o que você anotou');
    const entry = this.entry(d.keys, label, { backedUp: true });
    this.persist(d.keys, entry);
    this.current = undefined; // the phrase is gone from memory here
    return this.view(entry);
  }

  private roots(): Record<string, string> { return this.store.read<Record<string, string>>('roots') ?? {}; }

  private persist(keys: SubWalletKeys, entry: SubWalletEntry): void {
    this.registry.add(entry);
    this.store.write('roots', { ...this.roots(), [keys.id]: hex(keys.seed) }); // one sealed record: no key name carries an id
  }

  async restore(label: string, phrase: string): Promise<{ view: SubWalletView; positions: number; notes: number }> {
    this.assertAvailable();
    const keys = restoreSubWallet(phrase, { guard: this.guard(), assets: this.o.assets });
    const entry = this.entry(keys, label, { backedUp: true, restored: true });
    this.persist(keys, entry);
    try {
      // On this device it is "a new device": rebuild its positions from the pool, then its notes from the vault.
      const { summary: r } = await this.opened(keys.id);
      return { view: this.view(entry), positions: r.positions, notes: r.notes };
    } catch (e) {
      this.forget(keys.id);
      throw e;
    }
  }

  async open(id: string): Promise<SubSession> { return (await this.opened(id)).session; }

  private opened(id: string) {
    const known = this.sessions.get(id);
    if (known) return known;
    const root = this.roots()[id];
    if (!root || !this.registry.get(id)) return Promise.reject(new SubWalletRefused('invalid_phrase', 'esta sub-carteira não está neste aparelho: restaure-a pela frase'));
    const keys = subWalletKeysFromSeed(unhex(root), this.registry.get(id)!.assets);
    const opened = (async () => {
      const session = await this.o.open(keys.seed);
      await session.ensureGas().catch(() => undefined);
      // A reload is a new session on a device that kept the sub-wallet's records: this files its notes again, restoring nothing.
      return { session, summary: await session.restoreOrFile() };
    })();
    opened.catch(() => this.sessions.delete(id));
    this.sessions.set(id, opened);
    return opened;
  }

  forget(id: string): void {
    this.registry.remove(id);
    const { [id]: _gone, ...rest } = this.roots();
    this.store.write('roots', rest);
    this.sessions.delete(id);
  }

  async shareWithAuditor(ids: readonly string[], r: ShareRequest): Promise<SubWalletPackageActivity> {
    if (ids.length === 0) throw new SubWalletRefused('invalid_phrase', 'escolha ao menos uma sub-carteira');
    const selected = await Promise.all(ids.map(async (id) => {
      const w = await this.open(id);
      // Through the session, so the share is recorded with that sub-wallet and listed, and revocable, there.
      return { id, wallet: { shareWithAuditor: async () => (await w.shareWithAuditor(r)).share } };
    }));
    const pkg = await shareSubWalletsWithAuditor({ selected, ...r });
    const subject = (id: string) => getAddress(this.registry.get(id)!.account);
    return {
      package: pkg,
      json: stringify({
        kind: 'mova-subwallet-audit-package', version: 1, completeness: pkg.completeness,
        chainId: this.o.deployment.chainId, auditGrantRegistry: this.o.deployment.contracts.auditGrantRegistry, vault: this.o.deployment.services.vault,
        auditor: pkg.auditor, purpose: pkg.purpose, period: pkg.period, expiresAt: pkg.expiresAt,
        subWallets: pkg.subWallets.map((s) => ({
          id: s.id, account: subject(s.id),
          grants: s.share.grants.map((g) => ({ ledger: g.ledger, grantId: g.grantId, bundle: g.bundle, forVault: g.forVault })),
        })),
        note: 'Este pacote cobre apenas as sub-carteiras escolhidas. Não há como provar que são todas as do titular.',
      }, 2),
    };
  }
}
