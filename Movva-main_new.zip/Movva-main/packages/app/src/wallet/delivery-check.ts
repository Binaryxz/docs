/**
 * Can an order locked for delivery into the shielded balance still be delivered there - and can Movva delivered in the
 * open go back? Read from the chain, for the delivery escape hatch (FiatEscrow.takeDeliveryDirect).
 *
 * FiatEscrow's NatSpec names what makes a shielded delivery impossible after the taker has paid; each maps to reads:
 *
 *  - **the pool's minimum raised above the order**: `Entrypoint.assetConfig(movva).minimumDepositAmount` against the
 *    order's Movva - the Entrypoint's `_handleDeposit` reverts `MinimumDepositAmount`;
 *  - **the pool wound down**: `PrivacyPool.dead()` - the pool reverts `PoolIsDead`. Also no pool registered for Movva any
 *    more (`assetConfig(movva).pool` is zero: `PoolNotFound`), or another pool than this wallet's, where the note would
 *    land unseen;
 *  - **frozen by the token's issuer**: IssuerFreeze.sol's probe - Tether's `isBlackListed`, Circle's `isBlacklisted`, each
 *    capped at 30 000 gas, a revert or a short answer read as not frozen - on the escrow (it sends), the Entrypoint (it
 *    forwards to the pool) and the pool (a frozen pool takes the deposit and freezes every note in it). A frozen escrow or
 *    rescue address refuses delivery in the open too (`directRefused`). Movva itself keeps no freeze list today.
 *
 * Not detected: a release the LP node tried that reverted for any other reason. The node simulates before it sends, so
 * nothing lands on-chain, and its API does not report it. The escape hatch is offered whenever one of these reads shows a
 * block (the escrow itself allows `takeDeliveryDirect` on any shielded order still locked or disputed).
 *
 * Kept app-side for now, written only against `MovvaChain` and a raw `eth_call`, so it can move into @mova/wallet
 * unchanged. No Portuguese here: lib/delivery.ts says it.
 */
import { encodeFunctionData, getAddress, parseAbi, size, slice, zeroAddress, type Address, type Hex } from 'viem';
import { Delivery, OrderState, type MovvaChain } from '@mova/wallet';

export type FrozenParty = 'escrow' | 'account' | 'entrypoint' | 'pool';

export type DeliveryBlock =
  /** `assetConfig(movva).pool` is zero: the Entrypoint reverts `PoolNotFound`. */
  | { kind: 'pool_not_registered' }
  /** The Entrypoint deposits Movva into another pool than this wallet's ledger. */
  | { kind: 'pool_changed'; pool: Address }
  /** `PrivacyPool.dead()`: the pool reverts `PoolIsDead`. */
  | { kind: 'pool_wound_down' }
  /** The Entrypoint reverts `MinimumDepositAmount`. Both in base units, 10^18 per Movva. */
  | { kind: 'below_pool_minimum'; minimum: bigint; amount: bigint }
  /** The token's issuer froze a party the Movva passes through. */
  | { kind: 'frozen'; party: FrozenParty };

export interface DepositReads {
  /** The pool the Entrypoint registers for Movva: the zero address when there is none. */
  registeredPool: Address;
  /** This wallet's Movva pool, from the deployment. */
  expectedPool: Address;
  minimumDeposit: bigint;
  /** What would be deposited, base units. */
  amount: bigint;
  /** `dead()` of the registered pool; absent when there is none, or it did not answer. */
  poolDead?: boolean;
  /** The token issuer's freeze, per party that was asked. */
  frozen: Partial<Record<FrozenParty, boolean>>;
}

/** Where an order stands with its delivery. */
export interface DeliveryCheck {
  /** The order is locked or disputed: something is still to be delivered. */
  pending: boolean;
  /** Into the shielded balance, as locked; or to the rescue address in the open, once `takeDeliveryDirect` switched it. */
  delivery: 'shielded' | 'direct';
  /** Why a shielded delivery would be refused now. Empty when nothing the chain shows stops it. */
  blocks: DeliveryBlock[];
  /** The escrow or the rescue address is frozen by the token's issuer: a delivery in the open would be refused too. */
  directRefused: boolean;
}

export interface DeliveryReader {
  chain: Pick<MovvaChain, 'order' | 'assetConfig' | 'deployment'>;
  /** A raw `eth_call` (a viem PublicClient's `call`): the gas-capped freeze probe, and `dead()`. */
  client: { call(args: { to: Address; data: Hex; gas?: bigint }): Promise<{ data?: Hex }> };
}

/** IssuerFreeze.PROBE_GAS: enough for Tether's mapping read and USDC's proxy hop, and no more. */
export const ISSUER_FREEZE_PROBE_GAS = 30_000n;

const ISSUER_FREEZE_ABI = parseAbi(['function isBlackListed(address who) view returns (bool)', 'function isBlacklisted(address who) view returns (bool)']);
const POOL_DEAD_ABI = parseAbi(['function dead() view returns (bool)']);
const PARTIES: readonly FrozenParty[] = ['escrow', 'account', 'entrypoint', 'pool'];

/** The first word of an answer, as IssuerFreeze decodes it: shorter than a word is no answer. */
const firstWord = (data: Hex | undefined): bigint | undefined => (data && size(data) >= 32 ? BigInt(slice(data, 0, 32)) : undefined);

/** Whether `token`'s issuer froze `who`, asked as IssuerFreeze.sol asks: a missing function, a revert or no answer is no. */
export async function issuerFrozen(client: DeliveryReader['client'], token: Address, who: Address): Promise<boolean> {
  for (const functionName of ['isBlackListed', 'isBlacklisted'] as const) {
    try {
      const { data } = await client.call({ to: token, gas: ISSUER_FREEZE_PROBE_GAS, data: encodeFunctionData({ abi: ISSUER_FREEZE_ABI, functionName, args: [who] }) });
      if ((firstWord(data) ?? 0n) !== 0n) return true;
    } catch {
      // Reverted: this token keeps no such list.
    }
  }
  return false;
}

async function poolDead(client: DeliveryReader['client'], pool: Address): Promise<boolean | undefined> {
  try {
    const w = firstWord((await client.call({ to: pool, data: encodeFunctionData({ abi: POOL_DEAD_ABI, functionName: 'dead' }) })).data);
    return w === undefined ? undefined : w !== 0n;
  } catch {
    return undefined;
  }
}

/** Everything that decides whether the Entrypoint takes `amount` of Movva into this wallet's pool now, sent by `senders`. */
export async function readDeposit(r: DeliveryReader, amount: bigint, senders: Partial<Record<'escrow' | 'account', Address>>): Promise<DepositReads> {
  const d = r.chain.deployment;
  const cfg = await r.chain.assetConfig(d.movva);
  const pool = getAddress(cfg.pool);
  const registered = pool !== zeroAddress;
  const parties: [FrozenParty, Address][] = [
    ...(Object.entries(senders) as [FrozenParty, Address][]),
    ['entrypoint', d.entrypoint],
    ...(registered ? [['pool', pool] as [FrozenParty, Address]] : []),
  ];
  const [dead, frozen] = await Promise.all([
    registered ? poolDead(r.client, pool) : Promise.resolve(undefined),
    Promise.all(parties.map(async ([party, who]) => [party, await issuerFrozen(r.client, d.movva, who)] as const)),
  ]);
  return {
    registeredPool: pool, expectedPool: getAddress(d.movvaPool), minimumDeposit: cfg.minimumDeposit, amount,
    ...(dead !== undefined ? { poolDead: dead } : {}), frozen: Object.fromEntries(frozen),
  };
}

/** Why the deposit those reads describe would be refused, in the order the Movva meets each condition. */
export function depositBlocks(r: DepositReads): DeliveryBlock[] {
  const blocks: DeliveryBlock[] = [];
  const registered = getAddress(r.registeredPool) !== zeroAddress;
  if (!registered) {
    blocks.push({ kind: 'pool_not_registered' });
  } else {
    if (getAddress(r.registeredPool) !== getAddress(r.expectedPool)) blocks.push({ kind: 'pool_changed', pool: getAddress(r.registeredPool) });
    if (r.poolDead === true) blocks.push({ kind: 'pool_wound_down' });
    if (r.amount < r.minimumDeposit) blocks.push({ kind: 'below_pool_minimum', minimum: r.minimumDeposit, amount: r.amount });
  }
  for (const party of PARTIES) {
    if (r.frozen[party] === true && (party !== 'pool' || registered)) blocks.push({ kind: 'frozen', party });
  }
  return blocks;
}

/**
 * Whether an order locked for delivery into the shielded balance can still be delivered there, read now. Only an order
 * locked or disputed has anything left to deliver; one already switched to the open has no shielded delivery to block.
 */
export async function shieldedDeliveryCheck(r: DeliveryReader, orderId: Hex): Promise<DeliveryCheck> {
  const ord = await r.chain.order(orderId);
  const pending = ord.state === OrderState.LOCKED || ord.state === OrderState.DISPUTED;
  const delivery = ord.delivery === Delivery.DIRECT ? 'direct' as const : 'shielded' as const;
  if (!pending) return { pending, delivery, blocks: [], directRefused: false };
  const [reads, recipientFrozen] = await Promise.all([
    readDeposit(r, ord.amount, { escrow: r.chain.deployment.onramp }),
    issuerFrozen(r.client, r.chain.deployment.movva, ord.recipient),
  ]);
  return {
    pending, delivery, blocks: delivery === 'shielded' ? depositBlocks(reads) : [],
    // In the open, the escrow pays the rescue address itself: a freeze on either stops that too.
    directRefused: reads.frozen.escrow === true || recipientFrozen,
  };
}

/** Why the pool would refuse an order's Movva back from `account` (the rescue address it was delivered to), read now. */
export async function reshieldDeliveryBlocks(r: DeliveryReader, orderId: Hex, account: Address): Promise<DeliveryBlock[]> {
  const ord = await r.chain.order(orderId);
  return depositBlocks(await readDeposit(r, ord.amount, { account }));
}
