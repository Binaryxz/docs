/**
 * Withdrawal proofs on this device, off the UI thread.
 *
 * Funding a sale needs a groth16 proof of the Privacy Pools withdrawal circuit, one per note spent.
 * The witness is the note's nullifier and secret - the user's spending authority for that note - so the proof is made
 * here, in a Web Worker running the same SDK prover the Node wallet uses, over the circuit artifacts this app serves.
 * The worker is same-origin and the witness never leaves the browser. Whatever the worker answers, the proof's public
 * signals are checked against what was asked (`assertProofStates`) before the wallet uses it.
 */
import { assertProofStates, type ProveWithdrawalInput, type SolidityProof, type WithdrawalProver } from '@mova/wallet';

export interface ProverRequest { id: number; input: ProveWithdrawalInput; circuitsBaseUrl: string }
export type ProverResponse = { id: number; proof: SolidityProof } | { id: number; error: string };

interface WorkerLike {
  postMessage(message: ProverRequest): void;
  addEventListener(type: 'message', listener: (e: MessageEvent<ProverResponse>) => void): void;
  addEventListener(type: 'error', listener: (e: ErrorEvent) => void): void;
  terminate(): void;
}

export class WorkerWithdrawalProver implements WithdrawalProver {
  private worker?: WorkerLike;
  private nextId = 0;
  private readonly pending = new Map<number, { resolve: (p: SolidityProof) => void; reject: (e: Error) => void }>();

  constructor(private readonly o: { circuitsBaseUrl: string; createWorker?: () => WorkerLike }) {}

  private ensure(): WorkerLike {
    if (this.worker) return this.worker;
    const w: WorkerLike = this.o.createWorker?.()
      ?? (new Worker(new URL('./prover.worker.ts', import.meta.url), { type: 'module' }) as unknown as WorkerLike);
    w.addEventListener('message', (e: MessageEvent<ProverResponse>) => {
      const p = this.pending.get(e.data.id);
      if (!p) return;
      this.pending.delete(e.data.id);
      if ('error' in e.data) p.reject(new Error(`withdrawal prover: ${e.data.error}`));
      else p.resolve(e.data.proof);
    });
    w.addEventListener('error', (e: ErrorEvent) => {
      for (const p of this.pending.values()) p.reject(new Error(`withdrawal prover worker failed: ${e.message}`));
      this.pending.clear();
      this.worker?.terminate();
      this.worker = undefined;
    });
    this.worker = w;
    return w;
  }

  async prove(input: ProveWithdrawalInput): Promise<SolidityProof> {
    const worker = this.ensure();
    const id = ++this.nextId;
    const proof = await new Promise<SolidityProof>((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      worker.postMessage({ id, input, circuitsBaseUrl: this.o.circuitsBaseUrl });
    });
    assertProofStates(proof, input);
    return proof;
  }

  terminate(): void {
    this.worker?.terminate();
    this.worker = undefined;
  }
}
