/**
 * What the wallet keeps on this device, sealed.
 *
 * The viewing-key service's notes and lineage, each ledger's reservations, each sale's payee and salt, the sale
 * accounts' keys and the audit grants issued are private: together they are the user's financial history. They are
 * kept in the browser's storage encrypted with XChaCha20-Poly1305 under a key derived from the wallet's root seed,
 * which exists only in memory while the wallet is unlocked (the passkey recomputes it). The record's name is the
 * AEAD's associated data, so a record cannot be swapped for another. Nothing here moves funds: the spending keys are
 * re-derived from the seed, never stored.
 */
import { xchacha20poly1305 } from '@noble/ciphers/chacha';
import { hkdf } from '@noble/hashes/hkdf';
import { sha256 } from '@noble/hashes/sha2';
import { bytesToHex, hexToBytes, randomBytes, utf8ToBytes } from '@noble/hashes/utils';
import type { WalletSnapshot, WalletStore } from '@mova/viewing-key';
import type { Hex } from 'viem';
import type { LedgerSnapshot, LedgerStore, LegacyPixSaleRecord, SaleRecord, SaleStore } from '@mova/wallet';
import { parse, stringify } from '../lib/json.js';

/** Synchronous key-value storage: the wallet's stores are synchronous. */
export interface KeyValue {
  get(key: string): string | null;
  set(key: string, value: string): void;
  remove(key: string): void;
  keys(): string[];
}

export class MemoryKeyValue implements KeyValue {
  private readonly m = new Map<string, string>();
  get(key: string) { return this.m.get(key) ?? null; }
  set(key: string, value: string) { this.m.set(key, value); }
  remove(key: string) { this.m.delete(key); }
  keys() { return [...this.m.keys()]; }
}

export function browserKeyValue(storage: Storage = globalThis.localStorage): KeyValue {
  return {
    get: (k) => storage.getItem(k),
    set: (k, v) => storage.setItem(k, v),
    remove: (k) => storage.removeItem(k),
    keys: () => Array.from({ length: storage.length }, (_, i) => storage.key(i)).filter((k): k is string => k !== null),
  };
}

export class StoreUnreadable extends Error {}

/** The sealing key for this wallet's local records, from its root seed. */
export function storeKeyFromSeed(rootSeed: Uint8Array): Uint8Array {
  return hkdf(sha256, rootSeed, utf8ToBytes('Mova/app/v1/local-store'), utf8ToBytes('seal'), 32);
}

export class SealedStore {
  constructor(private readonly kv: KeyValue, private readonly key: Uint8Array, readonly prefix: string) {
    if (key.length !== 32) throw new Error('a store key is 32 bytes');
  }

  private id(name: string): string { return `${this.prefix}${name}`; }

  has(name: string): boolean { return this.kv.get(this.id(name)) !== null; }

  read<T>(name: string): T | undefined {
    const raw = this.kv.get(this.id(name));
    if (raw === null) return undefined;
    try {
      const { n, c } = JSON.parse(raw) as { n: string; c: string };
      const pt = xchacha20poly1305(this.key, hexToBytes(n), utf8ToBytes(this.id(name))).decrypt(hexToBytes(c));
      return parse<T>(new TextDecoder().decode(pt));
    } catch {
      throw new StoreUnreadable(`o registro local "${name}" não abre com esta chave: foi alterado, ou pertence a outra carteira`);
    }
  }

  write(name: string, value: unknown): void {
    const n = randomBytes(24);
    const c = xchacha20poly1305(this.key, n, utf8ToBytes(this.id(name))).encrypt(utf8ToBytes(stringify(value)));
    this.kv.set(this.id(name), JSON.stringify({ v: 1, n: bytesToHex(n), c: bytesToHex(c) }));
  }

  remove(name: string): void { this.kv.remove(this.id(name)); }

  /** Every record of this wallet, to forget the device. */
  clear(): void {
    for (const k of this.kv.keys()) if (k.startsWith(this.prefix)) this.kv.remove(k);
  }

  walletStore(name: string): WalletStore {
    return { load: () => this.read<WalletSnapshot>(name), save: (s) => this.write(name, s) };
  }

  ledgerStore(name: string): LedgerStore {
    return { load: () => this.read<LedgerSnapshot>(name), save: (s) => this.write(name, s) };
  }

  saleStore(name = 'sales'): SaleStore {
    return {
      put: (r: SaleRecord) => {
        const all = this.read<Record<string, SaleRecord>>(name) ?? {};
        all[r.saleId.toLowerCase()] = r;
        this.write(name, all);
      },
      get: (saleId: Hex): SaleRecord | LegacyPixSaleRecord | undefined => this.read<Record<string, SaleRecord>>(name)?.[saleId.toLowerCase()],
    };
  }

  /** A list kept under one name, newest first. */
  list<T>(name: string): T[] { return this.read<T[]>(name) ?? []; }

  upsert<T>(name: string, item: T, same: (a: T) => boolean): void {
    const all = this.list<T>(name);
    const i = all.findIndex(same);
    if (i >= 0) all[i] = item; else all.unshift(item);
    this.write(name, all);
  }
}
