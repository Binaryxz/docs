/**
 * The wallet's remote parts as HTTP clients: the relayer that submits proven withdrawals (so the user's account sends
 * nothing), the ASP's approved labels, and a note vault that keeps a copy of every encrypted note for a new device.
 *
 * Browsers refuse `fetch` called as a method of another object ("Illegal invocation"). The library clients bind the
 * fetch they store themselves; these app clients are handed `plainFetch`, which is safe to store and call as a method.
 */
import { Auditor, NoteVault, VaultClient, bytesToHex, ownerRequestTag, type GrantRegistryReader, type NoteRecord } from '@mova/viewing-key';
import { getAddress, type Address } from 'viem';
import type { AspSource, Call, Executed, Relayer } from '@mova/wallet';
import { parse, stringify } from '../lib/json.js';

export type Fetch = typeof fetch;

/** `fetch` that is safe to store on an object and call as a method. */
export const plainFetch: Fetch = (input, init) => globalThis.fetch(input, init);

export class RemoteServiceError extends Error {
  constructor(readonly service: string, readonly status: number, message: string) { super(message); }
}

async function call<T>(service: string, fetchImpl: Fetch, url: string, init?: RequestInit): Promise<T> {
  let res: Response;
  try {
    res = await fetchImpl(url, init);
  } catch (e) {
    throw new RemoteServiceError(service, 0, `${service}: ${url} unreachable (${e instanceof Error ? e.message : String(e)})`);
  }
  const text = await res.text();
  let body: unknown;
  try {
    body = text ? parse(text) : {};
  } catch {
    throw new RemoteServiceError(service, res.status, `${service}: ${res.status} with no JSON body`);
  }
  if (!res.ok) {
    const reason = body && typeof body === 'object' && typeof (body as { error?: unknown }).error === 'string' ? (body as { error: string }).error : 'no reason given';
    throw new RemoteServiceError(service, res.status, `${service}: ${res.status} ${reason}`);
  }
  return body as T;
}

/** The relayer, over HTTP: `GET <url>` names it, `POST <url>/submit` sends a call and answers with its receipt. */
export class HttpRelayer implements Relayer {
  private constructor(private readonly url: string, readonly address: Address, private readonly fetchImpl: Fetch) {}

  static async connect(url: string, fetchImpl: Fetch = plainFetch): Promise<HttpRelayer> {
    const b = await call<{ address?: unknown }>('relayer', fetchImpl, url);
    if (typeof b.address !== 'string') throw new RemoteServiceError('relayer', 200, 'relayer: the answer names no address');
    return new HttpRelayer(url.replace(/\/$/, ''), getAddress(b.address), fetchImpl);
  }

  submit(c: Call): Promise<Executed> {
    return call<Executed>('relayer', this.fetchImpl, `${this.url}/submit`, {
      method: 'POST', headers: { 'content-type': 'application/json' }, body: stringify({ to: c.to, data: c.data, value: c.value ?? 0n }),
    });
  }
}

/** The ASP's approved labels, in insertion order: the wallet rebuilds the tree and trusts only the Entrypoint's root. */
export class HttpAsp implements AspSource {
  constructor(private readonly url: string, private readonly fetchImpl: Fetch = plainFetch) {}

  async labels(): Promise<readonly bigint[]> {
    const b = await call<{ labels?: unknown }>('ASP', this.fetchImpl, `${this.url.replace(/\/$/, '')}/labels`);
    if (!Array.isArray(b.labels)) throw new RemoteServiceError('ASP', 200, 'ASP: the answer carries no labels');
    return b.labels.map((l) => BigInt(String(l)));
  }
}

/**
 * The viewing-key service writes each note to a `NoteVault`. This one keeps it, like any vault, and files a copy with
 * the remote vault in the background, signed with the wallet's identity key: ciphertext only, readable by nobody the
 * user has not granted. A note that could not be filed is retried by `fileAll` (on every unlock).
 */
export class MirroredVault extends NoteVault {
  private readonly client?: VaultClient;
  private queue: Promise<void> = Promise.resolve();
  failures = 0;
  lastError?: string;

  constructor(registry: GrantRegistryReader, private readonly o: { url?: string; identityPriv: Uint8Array; fetchImpl?: Fetch; now?: () => number }) {
    super(registry);
    if (o.url) this.client = new VaultClient(o.url, o.fetchImpl ?? plainFetch);
  }

  override put(record: NoteRecord, ownerSubject?: string): void {
    super.put(record, ownerSubject);
    if (ownerSubject) this.enqueue([record], ownerSubject);
  }

  /** File every record, again: the vault stores each once. */
  fileAll(records: readonly NoteRecord[], ownerSubject: string): Promise<void> {
    this.enqueue(records, ownerSubject);
    return this.queue;
  }

  private enqueue(records: readonly NoteRecord[], owner: string): void {
    const client = this.client;
    if (!client) return;
    const auditor = new Auditor(this.o.identityPriv);
    this.queue = this.queue.then(async () => {
      for (const record of records) {
        const at = this.o.now?.() ?? Math.floor(Date.now() / 1000);
        try {
          await client.putRecord(record, owner, auditor.prove(ownerRequestTag.put(record, owner), at));
        } catch (e) {
          this.failures += 1;
          this.lastError = e instanceof Error ? e.message : String(e);
        }
      }
    });
  }

  flushed(): Promise<void> { return this.queue; }
}

export const identitySubject = (identityPub: Uint8Array): string => bytesToHex(identityPub);
