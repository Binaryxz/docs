/**
 * The withdrawal prover's worker: the wallet's own `SdkWithdrawalProver`, pointed at the circuit artifacts this app
 * serves (`baseUrl`), so the SDK fetches them from the app's origin. Whatever it proves, `SdkWithdrawalProver` checks
 * the public signals against what was asked, and the main thread checks them again (worker-prover.ts).
 */
import { SdkWithdrawalProver } from '@mova/wallet';
import type { ProverRequest, ProverResponse } from './worker-prover.js';

const ctx = self as unknown as { onmessage: ((e: MessageEvent<ProverRequest>) => void) | null; postMessage(m: ProverResponse): void };

let prover: { base: string; prover: SdkWithdrawalProver } | undefined;

ctx.onmessage = (e) => void handle(e.data);

async function handle({ id, input, circuitsBaseUrl }: ProverRequest): Promise<void> {
  try {
    if (!prover || prover.base !== circuitsBaseUrl) prover = { base: circuitsBaseUrl, prover: new SdkWithdrawalProver({ baseUrl: circuitsBaseUrl }) };
    ctx.postMessage({ id, proof: await prover.prover.prove(input) });
  } catch (e) {
    ctx.postMessage({ id, error: e instanceof Error ? e.message : String(e) });
  }
}
