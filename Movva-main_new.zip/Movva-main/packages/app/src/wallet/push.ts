/**
 * The PWA service worker's registration, for push subscriptions (recovery alerts). Undefined in a browser without the
 * Push API, and before the worker is registered: the app registers src/sw/worker.ts (dist/sw.js) only in a production
 * build, so the dev server has none.
 */
import type { PushRegistrationLike } from '@mova/cosigner/client';

export async function browserPushRegistration(): Promise<PushRegistrationLike | undefined> {
  if (typeof navigator === 'undefined' || !('serviceWorker' in navigator) || typeof PushManager === 'undefined') return undefined;
  const registration = await navigator.serviceWorker.getRegistration();
  if (!registration) return undefined;
  // A subscription needs an active worker: wait for it a little, once one is installing.
  const ready = await Promise.race([navigator.serviceWorker.ready, new Promise<undefined>((r) => setTimeout(() => r(undefined), 5_000))]);
  return (ready ?? (registration.active ? registration : undefined)) as unknown as PushRegistrationLike | undefined;
}
