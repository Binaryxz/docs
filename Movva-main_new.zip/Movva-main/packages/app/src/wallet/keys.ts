/**
 * The keys an app session derives from the wallet's root seed, beside the ledgers' (movvaLedgerWallets).
 *
 * **The account.** The user's account is the taker and rescue address of every order and registers audit grants.
 * Under the Movva custody design it is a smart account - a Safe with the passkey as an owner, or a Kernel account
 * whose validator is the passkey with a server co-signer (packages/smart-account). The wallet library runs both
 * (`SafeExecutor` with `passkeySafeOwner`, `KernelExecutor`) through an ERC-4337 bundler (`BundlerSubmitter`), which
 * needs a bundler URL, the passkey's signer contract, the co-signer service and a paymaster; this app does not connect
 * those yet, and the demo chain (plain anvil) has no EntryPoint. So this app's account is an EOA whose key is derived
 * from the same root seed under its own label: recomputed on every unlock, never stored, recovered with the passkey
 * like everything else.
 *
 * **Sale accounts.** Each sale is opened from a fresh account with no history (sell.ts explains why), so its key is
 * random, not derived: two sales from derived keys would still be unlinkable, but a random key cannot be recomputed by
 * anyone who later learns the seed. The key is kept sealed with the sale's record, for cancelling.
 */
import { hkdf } from '@noble/hashes/hkdf';
import { sha256 } from '@noble/hashes/sha2';
import { bytesToHex, utf8ToBytes } from '@noble/hashes/utils';
import type { Hex } from 'viem';
import { generatePrivateKey, privateKeyToAccount } from 'viem/accounts';

export function deriveAccountKey(rootSeed: Uint8Array): Hex {
  if (rootSeed.length < 32) throw new Error('a root seed is at least 32 bytes');
  const key: Hex = `0x${bytesToHex(hkdf(sha256, rootSeed, utf8ToBytes('Mova/app/v1/account'), utf8ToBytes('eoa'), 32))}`;
  privateKeyToAccount(key); // refuses the ~2^-128 of outputs that are not a valid secp256k1 key
  return key;
}

export const newSaleAccountKey = (): Hex => generatePrivateKey();

/**
 * The salt of the user's smart account, from the root seed and the account's kind. With the passkey's public key and
 * the co-signer's address it fixes the account's address, so a new device with the same passkey finds the same
 * account without anything stored. Pseudorandom: the salt, public in the account's creation, says nothing of the seed.
 */
export function deriveAccountSalt(rootSeed: Uint8Array, kind: 'safe' | 'kernel'): bigint {
  if (rootSeed.length < 32) throw new Error('a root seed is at least 32 bytes');
  return BigInt(`0x${bytesToHex(hkdf(sha256, rootSeed, utf8ToBytes('Mova/app/v1/account-salt'), utf8ToBytes(kind), 32))}`);
}
