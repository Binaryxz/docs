/**
 * Recovery alerts on this device (packages/cosigner/src/recovery-alerts.ts, docs/wallet-custody.md §11.2).
 *
 * A stolen passkey can queue a recovery on the account's Delay; after the 7-day cooldown anyone executes it unless the
 * owners veto it, and the app shows the queue only while it is open. With alerts on, the co-signer pushes a notification
 * to this device - through the PWA's service worker (src/sw/) - when something is queued, again every day, and once more
 * before the cooldown ends.
 *
 * Subscribing and unsubscribing each need a fresh assertion by the account's passkey (the co-signer's challenge), and the
 * co-signer refuses to unsubscribe while a recovery is queued (`recovery_pending`): whoever holds the passkey could
 * otherwise silence the alerts about their own drain.
 *
 * The co-signer has no "is this device subscribed" call, so this device records the endpoint it subscribed, and counts
 * as subscribed only while the browser still holds that same push subscription.
 */
import {
  CoSignerRefused, subscribeRecoveryAlerts, unsubscribeRecoveryAlerts,
  type PasskeySign, type PushRegistrationLike, type RemoteCoSigner,
} from '@mova/cosigner/client';
import type { Address } from 'viem';

/** Why this device cannot subscribe: an EOA has no recovery Delay; a co-signer without alerts; a browser without Push. */
export type AlertsUnavailable = 'eoa' | 'cosigner' | 'browser';

export interface RecoveryAlertsView {
  available: boolean;
  unavailable?: AlertsUnavailable;
  /** This device is subscribed to the account's alerts. */
  subscribed: boolean;
}

export class AlertsUnavailableHere extends Error {
  constructor(readonly reason: AlertsUnavailable) {
    super(`recovery alerts are unavailable here (${reason})`);
  }
}

export interface AlertsRecord { endpoint: string; at: number }

export interface AlertsDeps {
  cosigner: Pick<RemoteCoSigner, 'info' | 'subscribeAlerts' | 'unsubscribeAlerts'>;
  account: Address;
  /** The co-signer's address, as pinned by the deployment. */
  coSigner: Address;
  /** The account's passkey. */
  sign: PasskeySign;
  /** The service worker's registration; undefined in a browser without Push, or before the PWA registered its worker. */
  registration: () => Promise<PushRegistrationLike | undefined>;
  /** Where this device keeps the endpoint it subscribed (sealed). */
  record: { read(): AlertsRecord | undefined; write(r: AlertsRecord): void; remove(): void };
  now: () => number;
}

export async function recoveryAlertsView(d: AlertsDeps | undefined): Promise<RecoveryAlertsView> {
  if (!d) return { available: false, unavailable: 'eoa', subscribed: false };
  if (!(await d.cosigner.info()).alerts) return { available: false, unavailable: 'cosigner', subscribed: false };
  const registration = await d.registration();
  if (!registration) return { available: false, unavailable: 'browser', subscribed: false };
  const [current, kept] = [await registration.pushManager.getSubscription(), d.record.read()];
  // A browser that dropped the subscription receives nothing, whatever this device recorded.
  return { available: true, subscribed: !!kept && !!current && current.endpoint === kept.endpoint };
}

/** Subscribe this browser for the co-signer's VAPID key, and register it with a fresh passkey assertion. From a user gesture. */
export async function enableRecoveryAlerts(d: AlertsDeps): Promise<{ pending: number }> {
  const alerts = (await d.cosigner.info()).alerts;
  if (!alerts) throw new CoSignerRefused(404, 'alerts_disabled', 'this co-signer does not send recovery alerts');
  const registration = await d.registration();
  if (!registration) throw new AlertsUnavailableHere('browser');
  const r = await subscribeRecoveryAlerts(registration, {
    cosigner: d.cosigner as RemoteCoSigner, account: d.account, coSigner: d.coSigner, sign: d.sign, vapidPublicKey: alerts.vapidPublicKey,
  });
  d.record.write({ endpoint: r.endpoint, at: d.now() });
  return { pending: r.pending };
}

/** Remove this device's subscription, with a fresh passkey assertion. Refused by the co-signer while a recovery is queued. */
export async function disableRecoveryAlerts(d: AlertsDeps): Promise<void> {
  const registration = await d.registration();
  if (!registration) throw new AlertsUnavailableHere('browser');
  try {
    await unsubscribeRecoveryAlerts(registration, { cosigner: d.cosigner as RemoteCoSigner, account: d.account, coSigner: d.coSigner, sign: d.sign });
  } catch (e) {
    // The co-signer never had this device: its alerts are off already.
    if (!(e instanceof CoSignerRefused && e.code === 'subscription_unknown')) throw e;
  }
  d.record.remove();
}
