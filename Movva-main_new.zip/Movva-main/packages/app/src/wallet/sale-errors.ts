/**
 * What the session says about a sale beside the wallet's own refusals, each said in Portuguese by lib/refusals.ts.
 */

/**
 * A sale stopped after an exit's proof left this device: its Movva may be at the sale account, or its exit with the
 * relayer. It is in `pendingSales()` under `pendingSale`, to be continued or given up there - never sold again from the
 * start, which would begin a second sale while the first one's Movva waits. `reason` is what stopped it.
 */
export class SaleInterrupted extends Error {
  constructor(readonly pendingSale: string, readonly reason: unknown) {
    super(reason instanceof Error ? reason.message : String(reason));
  }
}

/** This device holds no key for a sale account, so nothing can be sent from that account here. */
export class SaleKeyMissing extends Error {
  constructor(readonly account: string) {
    super(`this device holds no key for the sale account ${account}`);
  }
}
