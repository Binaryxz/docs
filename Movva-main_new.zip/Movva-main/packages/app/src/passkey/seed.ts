/**
 * Where this browser's wallet seed comes from: a passkey's PRF, and nothing else. A browser or authenticator without
 * PRF cannot create or open a wallet, and there is no fallback. The recovery-code path this module used to offer kept a
 * share in plain localStorage and fetched another with an unauthenticated GET, so one factor opened the wallet (audit
 * H-03). The seed goes through `openSeed` (packages/smart-account), which refuses any source other than the one the
 * wallet was created with.
 *
 * The seed is returned to the caller and held in memory while the wallet is unlocked. What this module persists is
 * only what identifies the wallet, the credential id and the passkey's public key, and none of it is secret.
 */
import {
  POOL_SEED_SALT, PrfSeedSource, assertionFromAuthenticatorResponse, navigatorPasskey, openSeed,
  passkeyPublicKeyFromAssertions, passkeyPublicKeyFromAttestation,
  type AuthenticatorAssertionResponseLike, type AuthenticatorAttestationResponseLike, type PasskeyPublicKey, type WebAuthnAssertion,
} from '@mova/smart-account';
import type { AccountOwnerKey } from '../wallet/account.js';
import type { KeyValue } from '../wallet/stores.js';

export type SeedKind = 'webauthn-prf';

export interface StoredIdentity {
  v: 1;
  kind: SeedKind;
  /** base64url: which passkey to ask. */
  credentialId?: string;
  /**
   * The passkey's P-256 public key (hex): the smart account's owner. Read from the registration, or - on a device that
   * never saw it - recovered from two assertions of the credential.
   */
  passkey?: { x: string; y: string };
  /** The smart account kind this wallet's account is: its address depends on it. */
  account?: 'safe' | 'kernel';
  createdAt: number;
}

const IDENTITY_KEY = 'mova:identity:v1';

const readIdentity = (kv: KeyValue): { v?: unknown; kind?: unknown } | undefined => {
  const raw = kv.get(IDENTITY_KEY);
  if (!raw) return undefined;
  try {
    const v = JSON.parse(raw) as unknown;
    return v && typeof v === 'object' ? v as { v?: unknown; kind?: unknown } : undefined;
  } catch {
    return undefined;
  }
};

/** This browser's wallet: a passkey (PRF) identity, or none. */
export function loadIdentity(kv: KeyValue): StoredIdentity | undefined {
  const v = readIdentity(kv);
  return v?.v === 1 && v.kind === 'webauthn-prf' ? v as StoredIdentity : undefined;
}

/**
 * Whether this browser holds a wallet from the removed recovery-code path. Such wallets exist only on Sepolia and local
 * stacks; the path never shipped on mainnet. This version does not open one. Onboarding says so, and
 * `discardLegacyIdentity` deletes the plaintext device share the wallet kept here.
 */
export function hasLegacyIdentity(kv: KeyValue): boolean {
  const v = readIdentity(kv);
  return v?.v === 1 && v.kind === 'split-share';
}

export function discardLegacyIdentity(kv: KeyValue): void {
  if (hasLegacyIdentity(kv)) kv.remove(IDENTITY_KEY);
}

export const saveIdentity = (kv: KeyValue, id: StoredIdentity): void => kv.set(IDENTITY_KEY, JSON.stringify(id));
export const forgetIdentity = (kv: KeyValue): void => kv.remove(IDENTITY_KEY);

export const b64url = (b: Uint8Array): string => btoa(String.fromCharCode(...b)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
export const fromB64url = (s: string): Uint8Array => Uint8Array.from(atob(s.replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((s.length + 3) % 4)), (c) => c.charCodeAt(0));
const word = (v: bigint): string => `0x${v.toString(16).padStart(64, '0')}`;
const storedKey = (k: PasskeyPublicKey): { x: string; y: string } => ({ x: word(k.x), y: word(k.y) });

export class PasskeyUnavailable extends Error {}
/** This browser or its authenticator has no PRF. It cannot hold a Movva wallet, and there is no fallback. */
export class PrfUnsupported extends Error {}

/** Whether this browser can use passkeys at all: WebAuthn, in a secure context. */
export function passkeySupport(): { available: boolean; reason?: string } {
  const g = globalThis as { PublicKeyCredential?: unknown; isSecureContext?: boolean; navigator?: { credentials?: unknown } };
  if (!g.PublicKeyCredential || !g.navigator?.credentials) return { available: false, reason: 'Este navegador não oferece passkeys (WebAuthn).' };
  if (!g.isSecureContext) return { available: false, reason: 'Passkeys exigem uma conexão segura (https ou localhost).' };
  return { available: true };
}

/**
 * Whether this browser reports PRF support through `PublicKeyCredential.getClientCapabilities`, where that exists.
 * `false` only when the browser explicitly says no, so onboarding can refuse before it creates a passkey that cannot
 * be used. `undefined` when the browser does not say, and then the registration's own PRF result decides.
 */
export async function prfSupport(): Promise<boolean | undefined> {
  const pkc = (globalThis as { PublicKeyCredential?: { getClientCapabilities?: () => Promise<Record<string, boolean | undefined>> } }).PublicKeyCredential;
  if (typeof pkc?.getClientCapabilities !== 'function') return undefined;
  try {
    const caps = await pkc.getClientCapabilities();
    return typeof caps['extension:prf'] === 'boolean' ? caps['extension:prf'] : undefined;
  } catch {
    return undefined;
  }
}

interface PrfResults { enabled?: boolean; results?: { first?: ArrayBuffer | ArrayBufferView } }
const prfOf = (c: PublicKeyCredential): PrfResults | undefined => (c.getClientExtensionResults() as { prf?: PrfResults }).prf;
const bytesOf = (b: ArrayBuffer | ArrayBufferView): Uint8Array => (b instanceof ArrayBuffer ? new Uint8Array(b) : new Uint8Array(b.buffer, b.byteOffset, b.byteLength));
const randomChallenge = () => crypto.getRandomValues(new Uint8Array(32));

/**
 * One touch per unlock: `openSeed` asks a source whether it is available and then for the seed, and each would be a
 * separate assertion. The PRF output is the same both times, so the first is kept for the second.
 */
function onceEvaluator(get: (salt: Uint8Array) => Promise<Uint8Array | null>, primed?: Uint8Array) {
  let first: Promise<Uint8Array | null> | undefined = primed ? Promise.resolve(primed) : undefined;
  return (salt: Uint8Array) => {
    if (salt !== POOL_SEED_SALT) return get(salt);
    first ??= get(salt);
    return first;
  };
}

async function assertPrf(credentialId?: string): Promise<{ prf: Uint8Array | null; rawId: Uint8Array; assertion?: WebAuthnAssertion }> {
  const cred = await navigator.credentials.get({
    publicKey: {
      challenge: randomChallenge(),
      allowCredentials: credentialId ? [{ type: 'public-key', id: fromB64url(credentialId) as BufferSource }] : [],
      userVerification: 'required',
      extensions: { prf: { eval: { first: POOL_SEED_SALT } } } as AuthenticationExtensionsClientInputs,
    },
  }) as PublicKeyCredential | null;
  if (!cred) throw new PasskeyUnavailable('Nenhuma passkey foi usada.');
  const first = prfOf(cred)?.results?.first;
  let assertion: WebAuthnAssertion | undefined;
  try {
    assertion = assertionFromAuthenticatorResponse(cred.response as unknown as AuthenticatorAssertionResponseLike);
  } catch {
    // Not an ES256 credential: it opens the seed, and cannot own a smart account.
  }
  return { prf: first ? bytesOf(first) : null, rawId: new Uint8Array(cred.rawId), assertion };
}

/**
 * A new wallet on a new passkey: ES256 (P-256), the only key a Safe WebAuthn signer or Kernel's validator verifies, its
 * public key kept as the account's owner. Throws `PrfUnsupported` when the authenticator cannot derive a seed, before
 * anything is stored.
 */
export async function createWithPasskey(
  kv: KeyValue, o: { label?: string; accountKind?: 'safe' | 'kernel' } = {},
): Promise<{ identity: StoredIdentity; seed: Uint8Array }> {
  if (await prfSupport() === false) throw new PrfUnsupported('Este navegador informa que não oferece a extensão PRF.');
  const label = o.label ?? 'Carteira Movva';
  const cred = await navigator.credentials.create({
    publicKey: {
      challenge: randomChallenge(),
      rp: { name: 'Movva' },
      user: { id: crypto.getRandomValues(new Uint8Array(16)), name: label, displayName: label },
      pubKeyCredParams: [{ type: 'public-key', alg: -7 }],
      // No authenticatorAttachment: a phone, a laptop or a USB security key all work.
      authenticatorSelection: { residentKey: 'required', userVerification: 'required' },
      extensions: { prf: { eval: { first: POOL_SEED_SALT } } } as AuthenticationExtensionsClientInputs,
    },
  }) as PublicKeyCredential | null;
  if (!cred) throw new PasskeyUnavailable('A passkey não foi criada.');
  const prf = prfOf(cred);
  const credentialId = b64url(new Uint8Array(cred.rawId));
  let passkey: PasskeyPublicKey;
  try {
    passkey = passkeyPublicKeyFromAttestation(cred.response as unknown as AuthenticatorAttestationResponseLike);
  } catch {
    throw new PasskeyUnavailable('A passkey foi criada, mas não é uma chave P-256 (ES256), a única que a conta inteligente verifica.');
  }
  if (!prf?.enabled && !prf?.results?.first) {
    throw new PrfUnsupported('A passkey foi criada, mas o autenticador não oferece a extensão PRF, que calcula a chave da carteira.');
  }
  const primed = prf.results?.first ? bytesOf(prf.results.first) : undefined;
  const evaluate = onceEvaluator(async () => (await assertPrf(credentialId)).prf, primed);
  const { seed } = await openSeed([new PrfSeedSource(evaluate)], 'webauthn-prf');
  const identity: StoredIdentity = {
    v: 1, kind: 'webauthn-prf', credentialId, passkey: storedKey(passkey), ...(o.accountKind ? { account: o.accountKind } : {}),
    createdAt: Math.floor(Date.now() / 1000),
  };
  saveIdentity(kv, identity);
  return { identity, seed };
}

/**
 * Open with a passkey: this device's (`identity`), or - restoring on a new device - whichever synced passkey the user
 * picks, whose PRF derives the same seed. Without PRF output there is no seed, and nothing else is tried.
 */
export async function unlockWithPasskey(kv: KeyValue, identity?: StoredIdentity): Promise<{ identity: StoredIdentity; seed: Uint8Array }> {
  let rawId: Uint8Array | undefined;
  let first: WebAuthnAssertion | undefined;
  const evaluate = onceEvaluator(async () => {
    const r = await assertPrf(identity?.credentialId);
    rawId = r.rawId;
    first = r.assertion;
    return r.prf;
  });
  const { seed } = await openSeed([new PrfSeedSource(evaluate)], 'webauthn-prf');
  const credentialId = identity?.credentialId ?? (rawId ? b64url(rawId) : undefined);
  let passkey = identity?.passkey;
  if (!passkey && credentialId && first) {
    // An assertion carries no public key, but an ECDSA signature has at most two candidates, and a second assertion of
    // the same credential leaves one: the account's owner, found on a device that never saw the registration.
    const second = await navigatorPasskey({ credentialId: fromB64url(credentialId) })(randomChallenge());
    passkey = storedKey(passkeyPublicKeyFromAssertions(first, second));
  }
  const next: StoredIdentity = {
    ...(identity ?? { v: 1 as const, kind: 'webauthn-prf' as const, createdAt: Math.floor(Date.now() / 1000) }),
    ...(credentialId ? { credentialId } : {}), ...(passkey ? { passkey } : {}),
  };
  if (!identity || next.passkey !== identity.passkey || next.credentialId !== identity.credentialId) saveIdentity(kv, next);
  return { identity: next, seed };
}

/** The passkey as the smart account's owner: its stored public key, and `navigator.credentials.get` to sign. */
export function browserAccountOwner(identity: StoredIdentity): AccountOwnerKey | undefined {
  if (identity.kind !== 'webauthn-prf' || !identity.passkey || !identity.credentialId) return undefined;
  return {
    publicKey: { x: BigInt(identity.passkey.x), y: BigInt(identity.passkey.y) },
    sign: navigatorPasskey({ credentialId: fromB64url(identity.credentialId) }),
  };
}
