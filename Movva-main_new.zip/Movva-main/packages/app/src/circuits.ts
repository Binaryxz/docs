/**
 * Where this app serves the Privacy Pools circuit artifacts (vite.config.ts copies them there), as an absolute URL.
 * The withdrawal prover's worker hands it to `SdkWithdrawalProver` (`baseUrl`); audit grants fetch the commitment circuit from
 * it (`commitmentArtifactsFrom`). Both read `artifacts/<circuit>.*` under it, the SDK's layout.
 */
export const CIRCUITS_PATH = 'circuits/sdk/';

export function circuitsBaseUrl(): string {
  const g = globalThis as { document?: { baseURI?: string }; location?: { href?: string } };
  const base = g.document?.baseURI ?? g.location?.href ?? 'http://localhost/';
  return new URL(CIRCUITS_PATH, base).href;
}
