/**
 * Image mode for scripts/dev-stack.ts: the off-chain services as containers from the services image
 * (packages/ops/Dockerfile) instead of in-process from source.
 *
 *   podman build --network=host --format docker -f packages/ops/Dockerfile -t localhost/mova-services:dev .
 *   MOVA_SERVICES_IMAGE=localhost/mova-services:dev npx tsx packages/app/scripts/dev-stack.ts
 *
 * Each container runs with --network=host, as the image's own user (`node`, uid 1000), with its service's config
 * directory mounted read-only at /app/config and a data directory of its own at /app/data, as
 * packages/ops/docker-compose.yml mounts them. Key files stay 0600 and are handed to uid 1000 (chown as root; `podman
 * unshare chown` for rootless podman; `--user` with a non-root docker client): the co-signer refuses a
 * key file group or others can read, so permissions are never widened.
 *
 * Every container is named `<prefix>-<service>` (MOVA_CONTAINER_PREFIX, default `movva-dev`): `stopAll` stops and
 * removes what this stack started and anything else under the prefix, and the next start removes what a killed stack
 * left behind. Each container's output is followed into `<dir>/<service>/container.log`.
 */
import { execFile, spawn, type ChildProcess } from 'node:child_process';
import { chmodSync, chownSync, closeSync, mkdirSync, openSync, writeFileSync } from 'node:fs';
import { createServer, type AddressInfo } from 'node:net';
import { basename, join } from 'node:path';

/** The image's `node` user (Dockerfile: USER node). */
export const IMAGE_USER = { uid: 1000, gid: 1000 } as const;

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const firstLine = (s: string) => s.trim().split('\n')[0] ?? '';

interface Ran { code: number; stdout: string; stderr: string }

function exec(cmd: string, args: readonly string[], timeoutMs = 120_000): Promise<Ran> {
  return new Promise((resolve) => {
    execFile(cmd, args, { timeout: timeoutMs, maxBuffer: 16 * 1024 * 1024, encoding: 'utf8' }, (err, stdout, stderr) => {
      if (!err) return resolve({ code: 0, stdout, stderr });
      const code = typeof (err as { code?: unknown }).code === 'number' ? (err as { code: number }).code : 127;
      resolve({ code, stdout: stdout ?? '', stderr: stderr || err.message });
    });
  });
}

/** A loopback port nothing listens on, from the OS: for listeners only the stack itself reads. */
export async function freePort(host = '127.0.0.1'): Promise<number> {
  const s = createServer();
  await new Promise<void>((res, rej) => {
    s.once('error', rej);
    s.listen(0, host, () => res());
  });
  const { port } = s.address() as AddressInfo;
  await new Promise<void>((res) => s.close(() => res()));
  return port;
}

export interface ContainerSpec {
  /** Short name: the container is `<prefix>-<service>`, its files under `<dir>/<service>`. */
  service: string;
  /** What the table calls it. */
  title: string;
  /** The command, as docker-compose.yml gives it (the image's entrypoint is tini). */
  command: string[];
  /** Plain settings only: every secret goes in a file under /app/config, never in the environment `inspect` shows. */
  env: Record<string, string>;
  /** Its listeners on the host network, for the table. */
  ports: { port: number; what: string }[];
  /** Polled until it answers 200. */
  readyUrl: string;
}

export interface ContainerInfo {
  name: string;
  service: string;
  title: string;
  ports: { port: number; what: string }[];
  log: string;
}

interface Entry { spec: ContainerSpec; name: string; log: string; follower?: ChildProcess }

export class ServiceContainers {
  readonly image: string;
  readonly runtime: string;
  readonly prefix: string;
  private readonly docker: boolean;
  private readonly ownership: 'chown' | 'unshare' | 'user';
  private readonly entries = new Map<string, Entry>();
  private readonly inFlight = new Set<Promise<void>>();
  private closing = false;

  constructor(private readonly o: { image: string; runtime?: string; prefix?: string; dir: string }) {
    this.image = o.image;
    this.runtime = o.runtime?.trim() || 'podman';
    this.prefix = o.prefix?.trim() || 'movva-dev';
    if (!/^[a-z0-9][a-z0-9_.-]{0,40}$/.test(this.prefix)) {
      throw new Error(`MOVA_CONTAINER_PREFIX is lowercase letters, digits, dots, dashes and underscores, not ${JSON.stringify(this.prefix)}`);
    }
    this.docker = basename(this.runtime).startsWith('docker');
    const uid = process.getuid?.();
    this.ownership = uid === undefined || uid === 0 ? 'chown' : this.docker ? 'user' : 'unshare';
  }

  name(service: string): string {
    return `${this.prefix}-${service}`;
  }

  logFile(service: string): string {
    return join(this.o.dir, service, 'container.log');
  }

  /** Before anything is deployed: the runtime answers, and holds the image. */
  async preflight(): Promise<void> {
    const r = await exec(this.runtime, ['image', 'inspect', '--format', '{{.Id}}', this.image], 60_000);
    if (r.code === 0) return;
    const build = this.docker
      ? `docker build -f packages/ops/Dockerfile -t ${this.image} .`
      : `podman build --network=host --format docker -f packages/ops/Dockerfile -t ${this.image} .`;
    throw new Error(`${this.runtime} has no image ${this.image} (${firstLine(r.stderr)}). Build it from the repository root: ${build}`);
  }

  /** Every container under the prefix, running or not. The name filter is a substring match in podman and docker alike; startsWith narrows it. */
  private async existing(): Promise<string[]> {
    const r = await exec(this.runtime, ['ps', '--all', '--filter', `name=${this.prefix}-`, '--format', '{{.Names}}'], 60_000);
    if (r.code !== 0) throw new Error(`${this.runtime} ps failed: ${firstLine(r.stderr)}`);
    return r.stdout.split(/\s+/).filter((n) => n.startsWith(`${this.prefix}-`));
  }

  /** What a stack killed without stopping left behind. Call it only once this stack holds the chain's port. */
  async removeLeftovers(): Promise<string[]> {
    const names = await this.existing();
    if (names.length) await exec(this.runtime, ['rm', '--force', ...names]);
    return names;
  }

  private dir(service: string, kind: 'config' | 'data'): string {
    const d = join(this.o.dir, service, kind);
    mkdirSync(d, { recursive: true, mode: 0o700 });
    chmodSync(d, 0o700);
    if (this.ownership === 'chown') chownSync(d, IMAGE_USER.uid, IMAGE_USER.gid);
    return d;
  }

  /** A file in the service's config directory - /app/config/<name> in its container - 0600, the image user's. Returns that path. */
  writeConfig(service: string, name: string, content: string): string {
    if (!/^[A-Za-z0-9_.-]+$/.test(name)) throw new Error(`not a file name: ${name}`);
    const file = join(this.dir(service, 'config'), name);
    writeFileSync(file, content, { mode: 0o600 });
    chmodSync(file, 0o600);
    if (this.ownership === 'chown') chownSync(file, IMAGE_USER.uid, IMAGE_USER.gid);
    return `/app/config/${name}`;
  }

  /** `run --detach`: resolves once the container exists, not once it is ready (`waitReady`). */
  async start(spec: ContainerSpec): Promise<void> {
    const run = this.run(spec);
    this.inFlight.add(run);
    try {
      await run;
    } finally {
      this.inFlight.delete(run);
    }
  }

  private async run(spec: ContainerSpec): Promise<void> {
    if (this.closing) throw new Error('the stack is stopping');
    if (this.entries.has(spec.service)) throw new Error(`${spec.service} is already started`);
    const name = this.name(spec.service);
    const config = this.dir(spec.service, 'config');
    const data = this.dir(spec.service, 'data');
    if (this.ownership === 'unshare') {
      const r = await exec(this.runtime, ['unshare', 'chown', '-R', `${IMAGE_USER.uid}:${IMAGE_USER.gid}`, config, data]);
      if (r.code !== 0) throw new Error(`${this.runtime} unshare chown failed: ${firstLine(r.stderr)}`);
    }
    const entry: Entry = { spec, name, log: this.logFile(spec.service) };
    this.entries.set(spec.service, entry);
    const r = await exec(this.runtime, [
      'run', '--detach', '--name', name, '--network=host', '--pull=never', '--label', 'movva.dev-stack=1',
      '--volume', `${config}:/app/config:ro`, '--volume', `${data}:/app/data`,
      ...(this.ownership === 'user' ? ['--user', `${process.getuid!()}:${process.getgid!()}`] : []),
      ...Object.entries(spec.env).flatMap(([k, v]) => ['--env', `${k}=${v}`]),
      this.image, ...spec.command,
    ]);
    if (r.code !== 0) throw new Error(`${this.runtime} run ${name} failed: ${firstLine(r.stderr)}`);
    const fd = openSync(entry.log, 'a');
    entry.follower = spawn(this.runtime, ['logs', '--follow', name], { stdio: ['ignore', fd, fd] });
    entry.follower.on('error', () => undefined);
    closeSync(fd);
  }

  /** Until its ready URL answers 200; refused at once if the container exits first, with the end of its log. */
  async waitReady(service: string, timeoutMs = 180_000): Promise<void> {
    const e = this.entries.get(service);
    if (!e) throw new Error(`${service} was not started`);
    const deadline = Date.now() + timeoutMs;
    for (let i = 0; ; i++) {
      if (this.closing) throw new Error('the stack is stopping');
      if (await fetch(e.spec.readyUrl, { signal: AbortSignal.timeout(5_000) }).then((r) => r.status === 200, () => false)) return;
      if (i % 4 === 3) {
        const state = await this.state(e.name);
        if (state && ['exited', 'stopped', 'dead'].includes(state.status)) {
          throw new Error(`${e.name} exited (${state.exitCode}) before ${e.spec.readyUrl} answered:\n${await this.logsTail(service)}`);
        }
      }
      if (Date.now() > deadline) throw new Error(`${e.name} did not answer ${e.spec.readyUrl} within ${Math.round(timeoutMs / 1000)} s:\n${await this.logsTail(service)}`);
      await sleep(500);
    }
  }

  private async state(name: string): Promise<{ status: string; exitCode: number } | undefined> {
    const r = await exec(this.runtime, ['inspect', '--type', 'container', '--format', '{{.State.Status}} {{.State.ExitCode}}', name], 30_000);
    if (r.code !== 0) return undefined;
    const [status = '', code = '0'] = r.stdout.trim().split(/\s+/);
    return { status, exitCode: Number(code) };
  }

  /** The end of a container's output, indented, for an error message. */
  async logsTail(service: string, lines = 40): Promise<string> {
    const r = await exec(this.runtime, ['logs', '--tail', String(lines), this.name(service)], 30_000);
    return `${r.stdout}${r.stderr}`.trim().split('\n').map((l) => `    | ${l}`).join('\n');
  }

  /**
   * Stop and remove every container under the prefix - what this stack started, a start still in flight once it lands,
   * and anything a killed stack left - and check none is left. Resolves with the names removed.
   */
  async stopAll(): Promise<string[]> {
    this.closing = true;
    await Promise.allSettled([...this.inFlight]);
    let names: string[];
    try {
      names = await this.existing();
    } catch {
      names = [...this.entries.values()].map((e) => e.name);
    }
    if (names.length) {
      await exec(this.runtime, ['stop', '--time', '10', ...names], 60_000);
      await exec(this.runtime, ['rm', '--force', ...names], 60_000);
    }
    for (const e of this.entries.values()) e.follower?.kill();
    const left = await this.existing().catch(() => []);
    if (left.length) {
      await exec(this.runtime, ['rm', '--force', ...left], 60_000);
      const still = await this.existing().catch(() => left);
      if (still.length) throw new Error(`${still.join(', ')} could not be removed: ${this.runtime} rm --force ${still.join(' ')}`);
    }
    return names;
  }

  describe(): ContainerInfo[] {
    return [...this.entries.values()].map((e) => ({ name: e.name, service: e.spec.service, title: e.spec.title, ports: e.spec.ports, log: e.log }));
  }

  /** The containers and their host ports, as lines of a table. */
  table(): string[] {
    const rows = [
      ['CONTAINER', 'SERVICE', 'PORTS (host network)'],
      ...this.describe().map((c) => [c.name, c.title, c.ports.map((p) => `${p.port} ${p.what}`).join(', ')]),
    ];
    const width = (i: number) => Math.max(...rows.map((r) => r[i]!.length));
    const [w0, w1] = [width(0), width(1)];
    return rows.map((r) => `${r[0]!.padEnd(w0)}  ${r[1]!.padEnd(w1)}  ${r[2]}`);
  }
}
