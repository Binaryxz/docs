/**
 * Preloaded (node --import) into the services dev-stack-extras.ts starts: a server that listens on a port without naming a
 * host binds 127.0.0.1, not every interface. The yield keepers' status server (packages/yield serveKeeper) names none, and a
 * development stack has no business answering on a public address.
 */
import { Server } from 'node:http';

const listen = Server.prototype.listen;
Server.prototype.listen = function (...args) {
  if (typeof args[0] === 'number' && typeof args[1] !== 'string') args.splice(1, 0, '127.0.0.1');
  return listen.apply(this, args);
};
