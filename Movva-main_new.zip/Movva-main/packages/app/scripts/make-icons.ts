/**
 * Draws the PWA's PNG icons (public/icons) from the same geometry as icon.svg - a teal rounded square, a white "M",
 * a mint dot - with 4x4 supersampling. Run once; the PNGs are kept with the source.
 *
 *   npx tsx packages/app/scripts/make-icons.ts
 */
import { mkdirSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { deflateSync } from 'node:zlib';

const OUT = join(dirname(fileURLToPath(import.meta.url)), '..', 'public', 'icons');

const CRC = Array.from({ length: 256 }, (_, n) => {
  let c = n;
  for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
  return c >>> 0;
});
const crc32 = (b: Buffer) => {
  let c = 0xffffffff;
  for (const x of b) c = CRC[(c ^ x) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
};
const chunk = (type: string, data: Buffer) => {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length);
  const body = Buffer.concat([Buffer.from(type, 'ascii'), data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(body));
  return Buffer.concat([len, body, crc]);
};

type RGBA = [number, number, number, number];

function png(size: number, pixel: (x: number, y: number) => RGBA): Buffer {
  const raw = Buffer.alloc((size * 4 + 1) * size);
  const S = 4;
  for (let y = 0; y < size; y++) {
    raw[y * (size * 4 + 1)] = 0;
    for (let x = 0; x < size; x++) {
      const acc = [0, 0, 0, 0];
      for (let sy = 0; sy < S; sy++) {
        for (let sx = 0; sx < S; sx++) {
          const p = pixel((x + (sx + 0.5) / S) / size * 512, (y + (sy + 0.5) / S) / size * 512);
          // premultiplied, so edges against transparency do not darken
          acc[0] += p[0] * p[3]; acc[1] += p[1] * p[3]; acc[2] += p[2] * p[3]; acc[3] += p[3];
        }
      }
      const o = y * (size * 4 + 1) + 1 + x * 4;
      const a = acc[3] / (S * S);
      raw[o] = a ? Math.round(acc[0] / acc[3]) : 0;
      raw[o + 1] = a ? Math.round(acc[1] / acc[3]) : 0;
      raw[o + 2] = a ? Math.round(acc[2] / acc[3]) : 0;
      raw[o + 3] = Math.round(a);
    }
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(size, 0);
  ihdr.writeUInt32BE(size, 4);
  ihdr[8] = 8; ihdr[9] = 6; ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
  return Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), chunk('IHDR', ihdr), chunk('IDAT', deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
}

const TEAL: RGBA = [0x0b, 0x6b, 0x57, 255];
const WHITE: RGBA = [255, 255, 255, 255];
const MINT: RGBA = [0x9f, 0xe3, 0xcf, 255];
const CLEAR: RGBA = [0, 0, 0, 0];
const M: [number, number][] = [[136, 368], [136, 152], [256, 284], [376, 152], [376, 368]];

function segmentDistance(px: number, py: number, [ax, ay]: [number, number], [bx, by]: [number, number]): number {
  const dx = bx - ax;
  const dy = by - ay;
  const t = Math.max(0, Math.min(1, ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy)));
  return Math.hypot(px - (ax + t * dx), py - (ay + t * dy));
}

/** The icon in its 512 space; `scale` shrinks the glyph toward the centre (a maskable icon's safe zone). */
function icon(rounded: boolean, scale: number) {
  return (x: number, y: number): RGBA => {
    if (rounded) {
      const r = 112;
      const cx = Math.min(Math.max(x, r), 512 - r);
      const cy = Math.min(Math.max(y, r), 512 - r);
      if (Math.hypot(x - cx, y - cy) > r) return CLEAR;
    }
    const gx = 256 + (x - 256) / scale;
    const gy = 256 + (y - 256) / scale;
    if (Math.hypot(gx - 256, gy - 400) <= 22) return MINT;
    for (let i = 0; i < M.length - 1; i++) if (segmentDistance(gx, gy, M[i], M[i + 1]) <= 22) return WHITE;
    return TEAL;
  };
}

mkdirSync(OUT, { recursive: true });
writeFileSync(join(OUT, 'icon-192.png'), png(192, icon(true, 1)));
writeFileSync(join(OUT, 'icon-512.png'), png(512, icon(true, 1)));
writeFileSync(join(OUT, 'icon-maskable-512.png'), png(512, icon(false, 0.8)));
console.log(`icons written to ${OUT}`);
