/**
 * The app's flows against the dev stack, headless: the wallet session the browser opens (src/wallet/session.ts), with
 * the deployment JSON, relayer, ASP, vault and dev API over HTTP through the gateway - everything as in the browser
 * except the prover (the Node SDK prover instead of the Web Worker) and the passkey (a software authenticator: real P-256
 * over the real WebAuthn payload, for RP id localhost and the app's origin, which the co-signer pins).
 *
 *   npx tsx packages/app/scripts/dev-stack.ts        # wait for "ready"
 *   npx tsx packages/app/scripts/smoke.ts [http://127.0.0.1:8981]
 *
 * Buys R$ 50,00 by PIX, pays it through the dev API, waits for
 * delivery; checks a bill past due is refused in Portuguese before anything moves; sells R$ 20,00 to a PIX key and
 * waits until the LP has paid and settled; then opens the same seed on a "new device" and checks it restores the same
 * balance from the pools and the note vault.
 *
 * On a smart-account stack (the default) the user's account is a Safe 2-of-2 - or Kernel, with MOVVA_ACCOUNT=kernel on the
 * stack - and every lock is a sponsored UserOperation the passkey and the co-signer sign: the run checks, from the chain,
 * that the account holds no ETH and that each of its operations went through the bundler, paid by the paymaster, and that
 * the sale was opened from an account that shares no owner with the user's. Both accounts are sponsored the production way:
 * at enrolment, by the co-signer's sponsorship module through SponsorGate, from its own operator key.
 */
import { PasskeyAuthenticator } from '@mova/smart-account';
import { releaseProofWorkers } from '@mova/viewing-key';
import { AspRefused, LpNodeError, SaleRefused, SdkWithdrawalProver, parseReais, type Reais } from '@mova/wallet';
import { parseDeployment } from '../src/lib/deployment.js';
import { backingView, buyStatusView, saleStatusView } from '../src/lib/format.js';
import { describeError } from '../src/lib/refusals.js';
import { WalletSession } from '../src/wallet/session.js';
import { MemoryKeyValue } from '../src/wallet/stores.js';

const BASE = (process.argv[2] ?? 'http://127.0.0.1:8981').replace(/\/$/, '');
const SELLER_PIX = '+5511987654321';
/** The origin the co-signer's policy pins: what a browser on the stack's gateway would send. */
const ORIGIN = 'http://localhost:8981';

interface AccountReport {
  address: string; balance: string; deployed: boolean; entryPointNonce: string; paymaster: string; bundlerExecutor: string; entryPoint: string;
  owners?: string[]; operations: { transactionHash: string; success: boolean; paymaster: string; bundle: { from: string; to: string | null } }[];
  sponsorship: { sponsored: boolean; gate: string; operator: string; byGate: { operator: string; from: string; to: string | null }[] };
}
const accountReport = async (address: string): Promise<AccountReport> => (await fetch(`${BASE}/api/dev/account?address=${address}`)).json() as Promise<AccountReport>;
const sponsoredThroughBundler = (r: AccountReport) => r.balance === '0' && r.operations.length > 0 && BigInt(r.entryPointNonce) === BigInt(r.operations.length)
  && r.operations.every((o) => o.success && o.paymaster.toLowerCase() === r.paymaster.toLowerCase()
    && o.bundle.from.toLowerCase() === r.bundlerExecutor.toLowerCase() && o.bundle.to?.toLowerCase() === r.entryPoint.toLowerCase());
/** Allowlisted by one SponsorGate.sponsor, sent by the co-signer's operator key: the production path. */
const sponsoredByCoSigner = (r: AccountReport) => r.sponsorship.sponsored && r.sponsorship.byGate.length === 1
  && r.sponsorship.byGate.every((s) => s.operator.toLowerCase() === r.sponsorship.operator.toLowerCase()
    && s.from.toLowerCase() === r.sponsorship.operator.toLowerCase() && s.to?.toLowerCase() === r.sponsorship.gate.toLowerCase());
const started = Date.now();
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const step = (s: string) => console.log(`\n\x1b[1m${s}\x1b[0m  (+${Math.round((Date.now() - started) / 1000)}s)`);
const info = (k: string, v: unknown) => console.log(`        ${k.padEnd(34)} ${v}`);
class Failed extends Error {}
const check = (cond: unknown, what: string) => {
  if (!cond) {
    console.log(`  \x1b[31mFAIL\x1b[0m  ${what}`);
    throw new Failed(what);
  }
  console.log(`  \x1b[32mOK\x1b[0m    ${what}`);
};

async function until<T>(what: string, seconds: number, fn: () => Promise<T | undefined>, retryOn: (e: unknown) => boolean = () => false): Promise<T> {
  const deadline = Date.now() + seconds * 1_000;
  let last: unknown;
  while (Date.now() < deadline) {
    try {
      const v = await fn();
      if (v !== undefined) return v;
    } catch (e) {
      if (!retryOn(e)) throw e;
      last = e;
    }
    await sleep(1_500);
  }
  throw new Failed(`timed out after ${seconds}s waiting for ${what}${last ? `: ${last instanceof Error ? last.message : String(last)}` : ''}`);
}

async function main() {
  step('1. The deployment JSON the app loads, and a wallet session opened from a new seed');
  const url = `${BASE}/api/deployment.json`;
  const deployment = parseDeployment(await (await fetch(url)).json(), url);
  info('deployment', `${deployment.name}, chain ${deployment.chainId}`);
  const rootSeed = crypto.getRandomValues(new Uint8Array(32));
  const passkey = PasskeyAuthenticator.create('localhost');
  const owner = { publicKey: passkey.publicKey(), sign: async (challenge: Uint8Array) => passkey.sign(challenge, ORIGIN) };
  const webauthn = { rpId: 'localhost', origin: ORIGIN };
  const session = await WalletSession.open({ deployment, rootSeed, kv: new MemoryKeyValue(), prover: new SdkWithdrawalProver(), owner, webauthn });
  await session.ensureGas();
  const restore = await session.restoreOrFile();
  check(!restore.restored && restore.positions === 0, `opened ${session.address}: a new wallet, nothing on-chain, nothing recovered`);
  const smart = session.accountKind !== 'eoa';
  if (smart) {
    const r = await accountReport(session.address);
    info('account', `${session.accountKind}, co-signer ${session.coSigner}`);
    check(!r.deployed && r.balance === '0' && r.operations.length === 0,
      `a ${session.accountKind === 'safe' ? 'Safe 2-of-2' : 'Kernel account'} of the passkey and the co-signer: counterfactual, no ETH, enrolled and sponsored`);
    check(sponsoredByCoSigner(r), `sponsored at enrolment by the co-signer's operator ${r.sponsorship.operator} through SponsorGate ${r.sponsorship.gate}`);
  }
  const empty = await session.balance();
  const backing = backingView(empty.backing);
  info('total', empty.totalFormatted);
  info('lastro', `${backing.title}: ${backing.detail}`);
  check(empty.total === 0n && empty.backing.status === 'full', 'an empty balance, in reais, fully backed');

  step('2. Buy R$ 50,00 by PIX: quote by rail, lock, verified instructions, pay through the dev API, delivered');
  const options = await session.quoteBuyByRail(parseReais('50'), ['pix', 'boleto']);
  for (const r of options.rails) info(`${r.rail}`, `pedido ${r.payFormatted} = ${r.totalFormatted}; recebe ${r.receiveFormatted}`);
  check(options.byRail.pix, 'PIX quoted, all in');
  const [order] = await session.buy(options.byRail.pix!);
  info('order', `${order.orderId} (${order.formatted})`);
  const pay = await until('verified PIX instructions', 90, () => session.paymentInstructions(order.orderId), (e) => e instanceof LpNodeError);
  if (pay.rail !== 'pix') throw new Failed(`PIX instructions expected, got ${pay.rail}`);
  check(pay.amount === order.amount && pay.pixCopiaECola.length > 50, `instructions verified on-chain: ${pay.formatted} to ${pay.receiver.name}; BR Code built by the wallet`);
  await session.dev!.payPix(pay.pixCopiaECola);
  const delivered = await until('delivery', 180, async () => {
    const s = await session.buyStatus(order.orderId);
    return s.state === 'delivered' ? s : undefined;
  });
  check(delivered.state === 'delivered', `delivered: ${buyStatusView(delivered, session.now()).detail}`);
  if (smart) {
    const r = await accountReport(session.address);
    check(r.deployed && sponsoredThroughBundler(r),
      `the lock created the account with its first UserOperation (recovery installed first): ${r.operations.length} operation(s), each through the bundler, paid by the paymaster; the account holds 0 ETH`);
  }

  step('3. A bill past its due date is refused, in Portuguese, before anything moves');
  const bills = (await session.dev!.sampleBills()).bills;
  const overdue = bills.find((b) => /vencido/i.test(b.label))!;
  const refused = await session.quoteSale({ boletoLine: overdue.line }).then(() => undefined, (e: unknown) => e);
  const view = describeError(refused);
  check(refused instanceof SaleRefused && refused.code === 'boleto_overdue' && view.title === 'Boleto vencido', `"${view.title}": ${view.detail}`);

  step('4. Sell R$ 20,00 to a PIX key: a proven, relayed exit to a fresh account; the LP pays and settles');
  const receive: Reais = parseReais('20');
  const quote = await until('the ASP to approve the deposits', 90, () => session.quoteSale(receive), (e) => e instanceof AspRefused);
  info('quote', `chega ${quote.receiveFormatted}, sai do saldo ${quote.costFormatted}, tarifas ${quote.feeFormatted}`);
  const t0 = Date.now();
  const sale = await until('the sale to open', 180, () => session.sell({ receive, pixKey: SELLER_PIX }), (e) => e instanceof AspRefused);
  info('proof, exit and sale', `${((Date.now() - t0) / 1000).toFixed(1)}s`);
  check(sale.disclosedTo >= 1, `sale ${sale.saleId} open for ${sale.receiveFormatted}; payee disclosed to ${sale.disclosedTo} LP node(s)`);
  const settled = await until('settlement', 240, async () => {
    const s = await session.saleStatus(sale.saleId);
    return s.state === 'settled' ? s : undefined;
  });
  const now = session.now();
  check(settled.state === 'settled', `${saleStatusView(settled, now, '2000-01-01').label}: ${saleStatusView(settled, now, '2000-01-01').detail}`);
  const outgoing = (await session.dev!.state()).outgoing;
  check(outgoing.some((o) => o.destination === SELLER_PIX && BigInt(o.amountCents) === sale.receive), `the LP's bank sent ${sale.receiveFormatted} by PIX to ${SELLER_PIX}`);
  if (smart) {
    const [mine, sellers] = await Promise.all([accountReport(session.address), (await fetch(`${BASE}/api/dev/sale-accounts`)).json() as Promise<{ accounts: AccountReport[] }>]);
    const seller = sellers.accounts.find((a) => a.address.toLowerCase() === (session.sales()[0]?.account ?? '').toLowerCase());
    const shared = (seller?.owners ?? []).filter((o) => (mine.owners ?? []).some((m) => m.toLowerCase() === o.toLowerCase()) && o.toLowerCase() !== session.coSigner!.toLowerCase());
    check(!!seller && seller.address.toLowerCase() !== session.address.toLowerCase() && sponsoredThroughBundler(seller) && shared.length === 0,
      `the sale account ${seller?.address}: its own owner key (not the passkey) and the co-signer, one sponsored operation through the bundler, 0 ETH`);
    check(!!seller && sponsoredByCoSigner(seller), 'the sale account was sponsored the same way: the co-signer\'s operator, through SponsorGate');
  }
  const after = await session.balance();
  info('available', after.availableFormatted);

  step('5. The same passkey on a new device: positions from the pools, notes from the vault, the same balance');
  await session.flushVault();
  const filed = await session.vaultStatus();
  info('notes on this device / in the vault', `Movva ${filed.local.movva}/${filed.filed.movva}${filed.failures ? `, ${filed.failures} failed: ${filed.lastError}` : ''}`);
  check(filed.failures === 0 && filed.filed.movva === filed.local.movva, 'every note this device wrote is in the vault');
  const phone = await WalletSession.open({ deployment, rootSeed, kv: new MemoryKeyValue(), prover: new SdkWithdrawalProver(), owner, webauthn });
  if (smart) check(phone.address === session.address && phone.accountKind === session.accountKind, `the same passkey and seed find the same account: ${phone.address}`);
  const restored = await phone.restoreOrFile();
  const phoneBalance = await phone.balance().catch(async (e: unknown) => {
    const s = await phone.vaultStatus();
    info('new device positions', `Movva ${phone.ledgers.movva.positions().map((p) => `${p.label}:${p.value}`).join(', ')}`);
    info('new device notes', `Movva ${s.local.movva}`);
    throw e;
  });
  info('restored', `${restored.positions} position(s), ${restored.notes} note(s)`);
  check(restored.restored && phoneBalance.total === after.total && phoneBalance.available === after.available,
    `the new device states the same balance: ${phoneBalance.totalFormatted}`);

  console.log('\n  \x1b[1mBuy by PIX, a refused bill, a sale paid by PIX and a restore - through the app\'s wallet session, against the dev stack.\x1b[0m\n');
}

main()
  .catch((e: unknown) => {
    if (!(e instanceof Failed)) console.error('\nfailed:', e instanceof Error ? (e as { shortMessage?: string }).shortMessage ?? e.message : e);
    process.exitCode = 1;
  })
  .finally(async () => {
    await releaseProofWorkers().catch(() => undefined);
    process.exit(process.exitCode ?? 0);
  });
