/**
 * A local Movva network for the app, on the real bytecode, with every service the app talks to.
 *
 *   npx tsx packages/app/scripts/dev-stack.ts          (or: npm run dev-stack -w @mova/app)
 *
 * then open the built app at http://localhost:8981 (npm run build -w @mova/app first), or run the app's dev server
 * (npm run dev -w @mova/app, http://localhost:8980), which proxies /api to this stack. Ctrl+C stops everything. Use
 * localhost, not 127.0.0.1: passkeys refuse an IP address as their relying party.
 *
 * Ports, all in 8980-8989: 8981 the gateway (the built app and /api), 8982 anvil, 8983 the LP node's API, 8984 the
 * matcher, 8985 the note vault, 8986 the co-signer (8988 its ops listener), 8989 the Alto bundler.
 *
 * The user's account is a smart account (MOVVA_ACCOUNT=safe, the default, or kernel; eoa for the old EOA path): before
 * anything else the stack puts packages/smart-account/examples/_account-stack.ts on the chain - EntryPoint v0.7, Safe
 * 1.4.1 with Safe4337Module and the passkey signer factory, Kernel v3.1 with PasskeyCoSignerValidator, the Zodiac Delay,
 * SponsorPaymaster from the root forge build, and Alto - and runs the co-signer service (packages/cosigner, its production
 * entrypoint with a development key file) with a policy that allowlists this deployment's contracts, CORS and WebAuthn
 * pinned to the app's origins (http://localhost:8981 and :8980, RP id localhost).
 *
 * Deploys what packages/wallet/examples/movva-wallet-live.ts deploys (its steps 1-4), the same way: MovvaReserve over a
 * Tether-like USDT, a settable USDT/USD feed and PythFxOracle over MockPyth; Mova's Privacy Pools (verifiers, Entrypoint
 * behind its proxy, the Movva pool); Movva's escrow pair with a zkTLS verifier for PIX and boleto; AuditGrantRegistry. The forge
 * artifacts are copied to a temp dir first, so a forge build running meanwhile cannot change them under the deploy.
 *
 * Runs, as that example wires them: an institutional LP node as a Movva gateway (MockBank, zkTLS proofs of its
 * bank's receipts from local witness keys),
 * the matcher, and a note vault. Plays, for the app: the relayer (submits Entrypoint.relay only), the
 * ASP (approves every deposit label and posts the root, as the example's postman does), the Pyth keeper (republishes
 * the FX rate and the USDT feed every minute, so backing stays current however long the demo runs), and a dev API: gas
 * for demo accounts, and "pay this PIX / boleto" buttons that act on MockBank as the user's bank would. There is no
 * share server: the app opens a wallet only with a PRF passkey (audit H-03 removed the recovery-code path).
 *
 * For the e2e tests, the dev API also has two switches (`POST /api/dev/faults`) that stop a flow where a real one can stop,
 * without any check being skipped: the next openSale UserOperation answered with a bundler error once (a sale whose exit
 * landed and whose openSale never reached the chain), the ASP's approvals held (a re-shielded note awaiting approval), the
 * Movva pool's minimum deposit raised above any order by the Entrypoint's owner (a shielded delivery made impossible, and
 * restored), and the next exit held by the relayer until released (a sale waiting for the relayer).
 *
 * Sponsorship is the production path: SponsorGate (contracts/SponsorGate.sol, read from SPONSOR_GATE_ARTIFACT, else
 * forge-out) owns SponsorPaymaster, which enforces a per-operation cost limit and a per-account budget; the co-signer's
 * sponsorship module sponsors every enrolled account through the gate from its own operator key (creating a Safe's
 * passkey signer first). The app waits for it (`waitForSponsorship`); no endpoint here allowlists anything. The co-signer
 * also sends recovery alerts (VAPID, aes128gcm) to any http(s) endpoint (development), and the gateway keeps what it
 * receives at /api/dev/push/<id> for the e2e tests, which play the browser's push service.
 *
 * Image mode: with MOVA_SERVICES_IMAGE=<image> (built from packages/ops/Dockerfile; CONTAINER_RUNTIME=podman, the
 * default, or docker) the stack deploys exactly as above, then runs the off-chain services as containers from that image
 * instead of in-process from source (scripts/dev-stack-containers.ts), all with --network=host: the LP node (LP_NODE_DEV=1)
 * on :8983, the matcher on :8984, the note vault on :8985, the co-signer on :8986 (ops :8988) and the monitor (on a free
 * port, also at /api/dev/monitor). The LP node's MockBank
 * stays here, where the dev API pays into them, and reach the container over a loopback dev bank API
 * (DEV_MOCK_BANK_URL, lp-node's dev-mock-bank.ts). Anvil, Alto, the gateway and its dev API, the ASP, the Pyth keeper and
 * the relayer stay on the host.
 * The containers are named `movva-dev-<service>` and removed on SIGINT, SIGTERM or a failed start; /api/dev/services lists
 * them.
 *
 * Extras: with DEV_STACK_EXTRAS=1 (source mode only) the stack also deploys and runs what the rail has beside the app's
 * flows - the divergence breaker, the reserve's yield vault behind a KeeperGate, the FeeSplitter and NodeRewards, the
 * real pyth-keeper and vault-keeper, per-payer caps on the LP node and the co-signer's FROST share store - with switches for a test console at /api/dev/extras. scripts/dev-stack-extras.ts says
 * what each one is and which demo parameters differ. Unset, none of it exists and the stack is as above.
 */
import { spawn, type ChildProcess } from 'node:child_process';
import { chmodSync, createReadStream, existsSync, mkdirSync, mkdtempSync, openSync, readFileSync, statSync, writeFileSync } from 'node:fs';
import { createServer, request as httpRequest, type IncomingMessage, type Server, type ServerResponse } from 'node:http';
import { tmpdir } from 'node:os';
import { dirname, extname, join, normalize, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { LeanIMT } from '@zk-kit/lean-imt';
import { poseidon2 } from 'poseidon-lite';
import {
  createPublicClient, createWalletClient, decodeFunctionData, defineChain, encodeFunctionData, formatEther, getAddress, hexToBytes, http, isAddress,
  isHex, parseAbi, parseAbiItem, parseEther, toFunctionSelector, toHex, type Abi, type Account, type Address, type Chain, type Hex, type PublicClient, type Transport, type WalletClient,
} from 'viem';
import { generatePrivateKey, privateKeyToAccount } from 'viem/accounts';
import { Auditor, ChainGrantRegistry, NoteVault, VaultService } from '@mova/viewing-key';
import {
  MatcherService, RECEIPT_KINDS, Rail, brasiliaToday, buildBankBoleto, buildCollectionBoleto, hashProviderParams, prepareSettlement,
  receiptRail, receiptRailMask, receiptTemplates,
} from '@mova/ramp';
import {
  JsonlJournal, LocalWitnessSession, LpNode, MockBank, ParPriceFeed, ViemRampChain, ZkTlsProver, serveDevMockBank, serveLpNode,
  type GatewayOptions, type LpRecord,
} from '@mova/lp-node';
import { AA_EVENTS_ABI, EoaExecutor, PP_ENTRYPOINT_ABI, parsePixBrCode } from '@mova/wallet';
import {
  MAINNET, PASSKEY_COSIGNER_VALIDATOR_ABI, assertionFromAuthenticatorResponse, buildQueueRequest, encodeSignedQueue,
  encodeWebAuthnSignature, parseTransactionAdded, predictDelayAddress, predictSignerAddress,
  type QueueRequest,
} from '@mova/smart-account';
import { generateVapidKeys } from '@mova/cosigner';
import { LIVE_GAS, deployAccountStack, type AccountStack } from '../../smart-account/examples/_account-stack.js';
import { parse, stringify } from '../src/lib/json.js';
import { ServiceContainers, freePort } from './dev-stack-containers.js';
import { DevStackExtras, EXTRAS, EXTRA_ARTIFACTS, ExtrasError } from './dev-stack-extras.js';

const APP = fileURLToPath(new URL('..', import.meta.url));
const ROOT = resolve(APP, '..', '..');
// Relative paths are the repository's, not the working directory's: the e2e starts this from packages/app, and a shell
// that exported FOUNDRY_OUT=forge-out for the live examples would otherwise point it at packages/app/forge-out.
const OUT = resolve(ROOT, process.env.WALLET_FORGE_OUT ?? process.env.FOUNDRY_OUT ?? 'forge-out');
const PROTOCOL_OUT = resolve(ROOT, process.env.PROTOCOL_OUT ?? 'protocol/contracts/out');
const ANVIL = join(ROOT, '.foundry-pinned/v0.3.0/anvil');
const DIST = join(APP, 'dist');
const STATE_DIR = join(APP, '.dev-stack');
/**
 * SponsorGate's artifact. forge-out may not have it yet: build it into a directory of your own, never into forge-out -
 *   FOUNDRY_OUT=<dir>/out FOUNDRY_CACHE_PATH=<dir>/cache $(bash scripts/foundry.sh path) build contracts/SponsorGate.sol
 * - and point SPONSOR_GATE_ARTIFACT at <dir>/out/SponsorGate.sol/SponsorGate.json.
 */
const SPONSOR_GATE_ARTIFACT = process.env.SPONSOR_GATE_ARTIFACT ? resolve(ROOT, process.env.SPONSOR_GATE_ARTIFACT) : join(OUT, 'SponsorGate.sol', 'SponsorGate.json');

const PORT = { gateway: 8981, anvil: 8982, lp: 8983, matcher: 8984, vault: 8985, cosigner: 8986, cosignerOps: 8988, bundler: 8989 } as const;
const ACCOUNT_KIND = (process.env.MOVA_ACCOUNT ?? 'safe') as 'safe' | 'kernel' | 'eoa';
if (!['safe', 'kernel', 'eoa'].includes(ACCOUNT_KIND)) {
  console.error(`[dev-stack] MOVA_ACCOUNT is safe, kernel or eoa, not ${ACCOUNT_KIND}`);
  process.exit(2);
}
/** The app's origins: the co-signer answers browsers from these (CORS) and accepts passkey assertions made on them. */
const APP_ORIGINS = ['http://localhost:8981', 'http://localhost:8980'];
const HOST = '127.0.0.1';
const RPC = `http://${HOST}:${PORT.anvil}`;
/**
 * Image mode: the off-chain services as containers from this image (packages/ops/Dockerfile), run by CONTAINER_RUNTIME
 * (podman, the default, or docker). Unset, they run in-process from source.
 */
const SERVICES_IMAGE = process.env.MOVA_SERVICES_IMAGE?.trim() || undefined;
if (EXTRAS && SERVICES_IMAGE) {
  console.error('[dev-stack] DEV_STACK_EXTRAS=1 runs its services from source: unset MOVA_SERVICES_IMAGE');
  process.exit(2);
}

/* The example's parameters, unchanged. */
const GOVERNANCE_DELAY = 24n * 3600n;
const DISPUTE_TIMEOUT = 30n * 24n * 3600n;
/** FiatEscrow's TAKER_DISPUTE_TIMEOUT (H-04) and MAX_VETTING_FEE_BPS (H-02): the deploy scripts' defaults. */
const TAKER_DISPUTE_TIMEOUT = 5n * 24n * 3600n;
const MAX_VETTING_FEE_BPS = 10n;
const TIER_INSTITUTIONAL = 3;
const MOVVA_BAND_BPS = 300n;
const VETTING_FEE_BPS = 10n;
const MAX_RELAY_FEE_BPS = 100n;
const MINT_FEE_BPS = 5;
const REDEEM_FEE_BPS = 5;
const U = 10n ** 6n;
const M = 10n ** 18n;
const OFFER_LIQUIDITY = 5_000n * M;
const NATIVE: Address = '0x0000000000000000000000000000000000000000';
const CID = 'bafybeigdyrzt5sfp7udm7hu76uh7y26nf3efuylqabf3oclgtqy55fbzdi';
const LP_PIX = 'liquidez@lp.example';
const LP_PAYER_ID = '12345678000195';
const LP_PAYER_REF_SECRET: Hex = `0x${'5a'.repeat(32)}`;
/** anvil's first two default accounts: the deployer, and the demo faucet. */
const FUNDER_KEY: Hex = '0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80';
const FAUCET_KEY: Hex = '0x59c6995e998f97a5a0044966f0945389dc9e86dae88c7a8412f4603b6b78690d';
const USD_BRL_ID: Hex = '0xd2db4dbf1aea74e0f666b0e8f73b9580d407f5e5cf931940b06dc633d7a95906';
const BANK_URL_PREFIX = 'https://api.banco-lp.example/';
const FX_E6 = 5_400_000n;
/** New accounts the gate lets operators add per day, and the co-signer's own cap below it (the co-signer refuses to start otherwise). */
const SPONSOR_GATE_BUDGET = 1_000;
const SPONSOR_DAILY_CAP = 500;

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const log = (s: string) => console.log(`[dev-stack] ${s}`);
type Wallet = WalletClient<Transport, Chain, Account>;

/*////////////////////////////////////////////////////////////
                 ARTIFACTS: A SNAPSHOT, NOT THE LIVE DIR
////////////////////////////////////////////////////////////*/

const OURS: [file: string, name: string][] = [
  ['DelayedGovernance.sol', 'DelayedGovernance'], ['ERC4626Adapter.t.sol', 'TetherLike'], ['ChainlinkSignedFxOracle.t.sol', 'FxTestFeed'],
  ['MovvaReserve.sol', 'MovvaReserve'], ['Movva.sol', 'Movva'], ['MockPyth.sol', 'MockPyth'],
  ['PythFxOracle.sol', 'PythFxOracle'], ['LPRegistry.sol', 'LPRegistry'], ['FiatEscrow.sol', 'FiatEscrow'], ['OffRampEscrow.sol', 'OffRampEscrow'],
  ['ReclaimZkTlsVerifier.sol', 'ReclaimZkTlsVerifier'],
  ['AuditGrantRegistry.sol', 'AuditGrantRegistry'],
  ...(EXTRAS ? EXTRA_ARTIFACTS : []),
];
const PROTOCOL = ['Entrypoint', 'PrivacyPoolComplex', 'PoseidonT3', 'PoseidonT4', 'WithdrawalVerifier', 'CommitmentVerifier', 'ERC1967Proxy'];

/**
 * Copy each artifact once it parses, retrying while a forge build may be rewriting it. An abstract contract
 * (DelayedGovernance, used for its ABI) has empty bytecode; every other one must have some.
 */
async function snapshotArtifacts(into: string): Promise<{ ours: string; protocol: string }> {
  const copy = async (from: string, to: string, abiOnly = false) => {
    for (let i = 0; i < 60; i++) {
      try {
        const text = readFileSync(from, 'utf8');
        const j = JSON.parse(text) as { abi?: unknown; bytecode?: { object?: string } };
        if (!Array.isArray(j.abi)) throw new Error('no abi');
        if (!abiOnly && (!j.bytecode?.object || j.bytecode.object === '0x')) throw new Error('no bytecode');
        mkdirSync(dirname(to), { recursive: true });
        writeFileSync(to, text);
        return;
      } catch {
        await sleep(1_000);
      }
    }
    throw new Error(`${from} was not a readable artifact for 60 s: build the contracts (forge build), or wait for the build in progress`);
  };
  const ours = join(into, 'forge-out');
  const protocol = join(into, 'protocol-out');
  for (const [file, name] of OURS) await copy(join(OUT, file, `${name}.json`), join(ours, file, `${name}.json`), name === 'DelayedGovernance');
  for (const name of PROTOCOL) await copy(join(PROTOCOL_OUT, `${name}.sol`, `${name}.json`), join(protocol, `${name}.sol`, `${name}.json`));
  if (!existsSync(SPONSOR_GATE_ARTIFACT)) {
    throw new Error(`${SPONSOR_GATE_ARTIFACT} is missing: build SponsorGate into a directory of your own (FOUNDRY_OUT=<dir>/out FOUNDRY_CACHE_PATH=<dir>/cache `
      + '$(bash scripts/foundry.sh path) build contracts/SponsorGate.sol) and set SPONSOR_GATE_ARTIFACT=<dir>/out/SponsorGate.sol/SponsorGate.json');
  }
  await copy(SPONSOR_GATE_ARTIFACT, join(ours, 'SponsorGate.sol', 'SponsorGate.json'));
  return { ours, protocol };
}

interface Artifact { abi: Abi; bytecode: Hex; links: Record<string, Record<string, { start: number; length: number }[]>> }
const artifactAt = (dir: string, file: string, name: string): Artifact => {
  const j = JSON.parse(readFileSync(join(dir, file, `${name}.json`), 'utf8')) as { abi: Abi; bytecode: { object: Hex; linkReferences?: Artifact['links'] } };
  return { abi: j.abi, bytecode: j.bytecode.object, links: j.bytecode.linkReferences ?? {} };
};

function link(a: Artifact, libs: Record<string, Address>): Hex {
  let hex = a.bytecode.slice(2);
  for (const file of Object.values(a.links)) {
    for (const [name, spots] of Object.entries(file)) {
      const at = libs[name];
      if (!at) throw new Error(`no address for library ${name}`);
      for (const { start, length } of spots) hex = hex.slice(0, start * 2) + at.slice(2).toLowerCase() + hex.slice((start + length) * 2);
    }
  }
  if (hex.includes('__$')) throw new Error('an unlinked library placeholder is left in the bytecode');
  return `0x${hex}`;
}

/*////////////////////////////////////////////////////////////
                              HELPERS
////////////////////////////////////////////////////////////*/

/** One queue per key: a wallet's transactions never race each other's nonce. */
const queues = new Map<string, Promise<unknown>>();
function serial<T>(key: string, fn: () => Promise<T>): Promise<T> {
  const next = (queues.get(key) ?? Promise.resolve()).then(fn, fn);
  queues.set(key, next.catch(() => undefined));
  return next;
}

class HttpError extends Error {
  constructor(readonly status: number, message: string) { super(message); }
}

const CORS = { 'access-control-allow-origin': '*', 'access-control-allow-methods': 'GET, POST, OPTIONS', 'access-control-allow-headers': 'content-type' };

function sendJson(rs: ServerResponse, status: number, body: unknown): void {
  rs.writeHead(status, { 'content-type': 'application/json', 'cache-control': 'no-store', ...CORS });
  rs.end(stringify(body));
}

async function rawBody(rq: IncomingMessage): Promise<Buffer> {
  const chunks: Buffer[] = [];
  let size = 0;
  for await (const c of rq) {
    size += (c as Buffer).length;
    if (size > 1024 * 1024) throw new HttpError(413, 'request body too large');
    chunks.push(c as Buffer);
  }
  return Buffer.concat(chunks);
}

async function readBody<T>(rq: IncomingMessage): Promise<T> {
  const body = await rawBody(rq);
  try {
    return parse<T>(body.toString('utf8') || '{}');
  } catch {
    throw new HttpError(400, 'request body is not JSON');
  }
}

/** Forward a request to a local service: its body streamed, or - when it was read first, to look at it - those bytes. */
function proxy(rq: IncomingMessage, rs: ServerResponse, port: number, path: string, body?: Buffer): void {
  const headers: Record<string, string | string[] | undefined> = { ...rq.headers, host: `${HOST}:${port}` };
  if (body) {
    delete headers['transfer-encoding'];
    headers['content-length'] = String(body.length);
  }
  const upstream = httpRequest({ host: HOST, port, path, method: rq.method, headers }, (res) => {
    rs.writeHead(res.statusCode ?? 502, { ...res.headers, ...CORS });
    res.pipe(rs);
  });
  upstream.on('error', (e) => sendJson(rs, 502, { error: `upstream ${port}: ${e.message}` }));
  if (body) upstream.end(body); else rq.pipe(upstream);
}

const MIME: Record<string, string> = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json',
  '.webmanifest': 'application/manifest+json', '.svg': 'image/svg+xml', '.png': 'image/png', '.wasm': 'application/wasm',
  '.zkey': 'application/octet-stream', '.vkey': 'application/json',
};

function serveStatic(rq: IncomingMessage, rs: ServerResponse, pathname: string): void {
  if (!existsSync(join(DIST, 'index.html'))) {
    rs.writeHead(404, { 'content-type': 'text/html; charset=utf-8' });
    rs.end('<p>O app ainda não foi compilado. Rode <code>npm run build -w @mova/app</code>, ou use o servidor de desenvolvimento: <code>npm run dev -w @mova/app</code> (porta 8980).</p>');
    return;
  }
  const rel = normalize(decodeURIComponent(pathname)).replace(/^([/\\])+/, '');
  let file = join(DIST, rel);
  if (!file.startsWith(DIST + sep) && file !== DIST) file = join(DIST, 'index.html');
  if (!existsSync(file) || statSync(file).isDirectory()) {
    // A missing file (an asset, a circuit artifact) is a 404, never the app's page with a 200: a service worker would
    // cache that page as the file. Only a path without an extension is a route of the app.
    if (extname(rel)) {
      rs.writeHead(404, { 'content-type': 'text/plain; charset=utf-8', 'cache-control': 'no-store' });
      rs.end('not found');
      return;
    }
    file = join(DIST, 'index.html');
  }
  rs.writeHead(200, {
    'content-type': MIME[extname(file)] ?? 'application/octet-stream',
    'cache-control': file.endsWith('index.html') || file.endsWith('sw.js') ? 'no-cache' : 'public, max-age=3600',
  });
  if (rq.method === 'HEAD') rs.end(); else createReadStream(file).pipe(rs);
}

async function rpcAnswers(url: string): Promise<boolean> {
  try {
    const r = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{"jsonrpc":"2.0","id":1,"method":"eth_chainId","params":[]}' });
    return r.ok;
  } catch {
    return false;
  }
}

/**
 * What stops what this stack started, run last first. Filled as the stack comes up, so a signal or a failure during
 * startup stops what already runs - containers included - and a stop registered while the others run still runs.
 */
const stops: (() => Promise<void> | void)[] = [];
let stopped: Promise<void> | undefined;
const shutdown = (): Promise<void> => (stopped ??= (async () => {
  while (stops.length) {
    try { await stops.pop()!(); } catch { /* keep stopping */ }
  }
})());

async function startAnvil(): Promise<ChildProcess> {
  if (await rpcAnswers(RPC)) throw new Error(`port ${PORT.anvil} already answers JSON-RPC: another stack is running`);
  const child = spawn(ANVIL, ['--port', String(PORT.anvil), '--host', HOST, '--block-time', '1', '--silent'], { stdio: 'ignore' });
  stops.push(() => { child.kill(); });
  for (let i = 0; i < 100; i++) {
    if (await rpcAnswers(RPC)) return child;
    await sleep(200);
  }
  child.kill();
  throw new Error(`anvil did not start on ${RPC}`);
}

/*////////////////////////////////////////////////////////////
                                MAIN
////////////////////////////////////////////////////////////*/

async function main(): Promise<void> {
  const work = mkdtempSync(join(tmpdir(), 'movva-dev-stack-'));
  const containers = SERVICES_IMAGE
    ? new ServiceContainers({ image: SERVICES_IMAGE, runtime: process.env.CONTAINER_RUNTIME, prefix: process.env.MOVA_CONTAINER_PREFIX, dir: join(work, 'containers') })
    : undefined;
  if (containers) {
    // Before minutes of deploying: the runtime answers, and holds the image.
    log(`image mode: the services from ${containers.image} (${containers.runtime}), as containers named ${containers.prefix}-*`);
    await containers.preflight();
  }
  log(`copying contract artifacts from ${OUT} and ${PROTOCOL_OUT} to ${work}`);
  const snap = await snapshotArtifacts(work);
  const ours = (name: string, file = `${name}.sol`) => artifactAt(snap.ours, file, name);
  const protocol = (name: string) => artifactAt(snap.protocol, `${name}.sol`, name);

  await startAnvil();
  try {
    if (containers) {
      // This stack holds the chain's port, so no other stack runs: containers under its prefix are a killed stack's.
      const left = await containers.removeLeftovers();
      if (left.length) log(`removed containers a stack killed without stopping left behind: ${left.join(', ')}`);
    }
    const chainId = await createPublicClient({ transport: http(RPC) }).getChainId();
    const chain = defineChain({ id: chainId, name: 'anvil', nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 }, rpcUrls: { default: { http: [RPC] } } });
    const pub = createPublicClient({ chain, transport: http(RPC), pollingInterval: 250 }) as PublicClient;
    const walletOf = (key: Hex): Wallet => createWalletClient({ account: privateKeyToAccount(key), chain, transport: http(RPC), pollingInterval: 250 });
    const funder = walletOf(FUNDER_KEY);
    const faucet = walletOf(FAUCET_KEY);
    const send = async (w: Wallet, address: Address, abi: Abi, functionName: string, args: unknown[] = []) => serial(w.account.address, async () => {
      const hash = await w.writeContract({ address, abi, functionName, args } as never);
      const r = await pub.waitForTransactionReceipt({ hash });
      if (r.status !== 'success') throw new Error(`${functionName} reverted`);
      return r;
    });
    const deployBytes = async (abi: Abi, bytecode: Hex, args: unknown[] = []): Promise<Address> => serial(funder.account.address, async () => {
      const hash = await funder.deployContract({ abi, bytecode, args } as never);
      const r = await pub.waitForTransactionReceipt({ hash });
      if (r.status !== 'success' || !r.contractAddress) throw new Error('a deployment reverted');
      return getAddress(r.contractAddress);
    });
    const deploy = (a: Artifact, args: unknown[] = []) => deployBytes(a.abi, a.bytecode, args);
    const read = <T>(address: Address, abi: Abi, functionName: string, args: unknown[] = []) => pub.readContract({ address, abi, functionName, args }) as Promise<T>;
    const fund = async (from: Wallet, to: Address, value: bigint) => serial(from.account.address, async () => {
      await pub.waitForTransactionReceipt({ hash: await from.sendTransaction({ to, value }) });
    });
    const GOVERNED = ours('DelayedGovernance');
    const hasCode = async (address: Address) => { const c = await pub.getCode({ address }); return !!c && c !== '0x'; };

    // First, on the empty chain: its canonical deployments send from the funder with nonces of their own.
    log(`0. Smart accounts: EntryPoint v0.7, Safe 1.4.1, Kernel v3.1, PasskeyCoSignerValidator, the Zodiac Delay, SponsorPaymaster, Alto on :${PORT.bundler}`);
    const stack: AccountStack = await deployAccountStack({
      rpc: RPC, chain, publicClient: pub, funder: privateKeyToAccount(FUNDER_KEY), bundlerPort: PORT.bundler,
      report: { ok: () => undefined, info: () => undefined, fail: (what) => { throw new Error(what); } },
    });
    stops.push(() => stack.stop());
    const stackBlock = await pub.getBlockNumber();

    log('0b. SponsorGate owns the paymaster: the co-signer\'s operator key sponsors enrolled accounts through it, within the paymaster\'s budgets');
    const GATE = ours('SponsorGate');
    const PAYMASTER_OWNER_ABI = parseAbi(['function transferOwnership(address to)', 'function owner() view returns (address)']);
    const sponsorOperatorKey = generatePrivateKey();
    const sponsorOperator = privateKeyToAccount(sponsorOperatorKey).address;
    const gateGuardian = privateKeyToAccount(generatePrivateKey()).address;
    const sponsorGate = await deploy(GATE, [stack.paymaster, funder.account.address, gateGuardian, SPONSOR_GATE_BUDGET]);
    await send(funder, stack.paymaster, PAYMASTER_OWNER_ABI, 'transferOwnership', [sponsorGate]);
    // The gate refuses operators while the paymaster bounds nothing: its governor (the deployer here, a multisig in
    // production) sets the per-account budget and the per-operation cost limit through it first.
    await send(funder, sponsorGate, GATE.abi, 'setBudget', [86_400n, parseEther('5')]);
    await send(funder, sponsorGate, GATE.abi, 'setMaxCostAllowed', [parseEther('1')]);
    await send(funder, sponsorGate, GATE.abi, 'setOperator', [sponsorOperator, true]);
    await fund(funder, sponsorOperator, parseEther('10'));
    if (getAddress(await read<Address>(stack.paymaster, PAYMASTER_OWNER_ABI, 'owner')) !== sponsorGate) throw new Error('the paymaster is not owned by the SponsorGate');

    log('1. Movva: reserve and token, with mint and redeem fees');
    const gov = walletOf(generatePrivateKey());
    const issuer = walletOf(generatePrivateKey());
    const lpKey = generatePrivateKey();
    const lp = walletOf(lpKey);
    const relayerW = walletOf(generatePrivateKey());
    const postman = walletOf(generatePrivateKey());
    const feeTo = privateKeyToAccount(generatePrivateKey()).address;
    for (const w of [gov, issuer, lp, relayerW, postman]) await fund(funder, w.account.address, parseEther('100'));

    const TETHER = ours('TetherLike', 'ERC4626Adapter.t.sol');
    const FEED = ours('FxTestFeed', 'ChainlinkSignedFxOracle.t.sol');
    const RESERVE = ours('MovvaReserve');
    const MOCK_PYTH = ours('MockPyth');
    const PYTH_FX = ours('PythFxOracle');
    const usdt = await deploy(TETHER);
    const usdFeed = await deploy(FEED, [100_000_000n, 8]);
    const pyth = await deploy(MOCK_PYTH, [1n]);
    const fx = await deploy(PYTH_FX, [pyth, USD_BRL_ID, 3_600n, 4n * 86_400n, 100, gov.account.address, GOVERNANCE_DELAY]);
    /**
     * The Pyth keeper's job: reais per dollar, and the USDT/USD feed, stamped with the current block. With the extras, once
     * the real pyth-keeper runs it posts the FX leg, and this keeps only the USDT/USD feed.
     */
    let pythKeeperRuns = false;
    const publishPrices = async () => {
      const at = (await pub.getBlock()).timestamp;
      if (!pythKeeperRuns) await send(funder, pyth, MOCK_PYTH.abi, 'set', [USD_BRL_ID, FX_E6, 100n, -6, at]);
      await send(funder, usdFeed, FEED.abi, 'set', [100_000_000n, at]);
    };
    await publishPrices();
    if (PYTH_FX.abi.some((x) => x.type === 'function' && x.name === 'completeSetup')) await send(gov, fx, PYTH_FX.abi, 'completeSetup');
    const extras = EXTRAS
      ? new DevStackExtras({ root: ROOT, host: HOST, rpc: RPC, chainId, work, pub, funder, gov, ours, deploy, send, read, fund, log, stops }, FX_E6)
      : undefined;
    if (extras) log('1x. Extras (DEV_STACK_EXTRAS=1): the divergence breaker over a settable source, before the reserve');
    const breaker = extras ? await extras.deployBreaker() : '0x0000000000000000000000000000000000000000';
    const reserve = await deploy(RESERVE, [{
      usdt, usdtUsdFeed: usdFeed, fxOracle: fx, usdtUsdMaxAge: 25n * 3600n, fxMaxAge: 3600n, governor: gov.account.address,
      governanceDelay: GOVERNANCE_DELAY, guardian: gov.account.address, feeRecipient: feeTo,
      // Principal-locked (21 October 2026): harvestYield pays only this address (Mova's treasury here), and only the yield.
      yieldRecipient: feeTo, supplyCap: 100_000_000n * M, breaker,
    }]);
    const movva = getAddress(await read<Address>(reserve, RESERVE.abi, 'MOVVA'));
    await send(gov, reserve, RESERVE.abi, 'setGateway', [lp.account.address, true]);
    await send(gov, reserve, RESERVE.abi, 'setFees', [MINT_FEE_BPS, REDEEM_FEE_BPS]);
    if (extras) {
      log('1y. Extras: NodeRewards and the FeeSplitter as the fee recipient, YieldVault + ERC4626Adapter over StataLike behind a KeeperGate');
      await extras.wireReserve({ reserve, movva, usdt, treasury: feeTo, delay: GOVERNANCE_DELAY });
    }
    await send(gov, reserve, RESERVE.abi, 'completeSetup');
    await send(funder, usdt, TETHER.abi, 'mint', [issuer.account.address, 1_100n * U]);
    await send(issuer, usdt, TETHER.abi, 'approve', [reserve, 1_100n * U]);
    await send(issuer, reserve, RESERVE.abi, 'recapitalize', [1_100n * U]);
    await send(funder, usdt, TETHER.abi, 'mint', [lp.account.address, 20_000n * U]);

    log('2. Privacy Pools: verifiers, Entrypoint behind its proxy, the Movva pool');
    const fromBlock = await pub.getBlockNumber();
    const EP = protocol('Entrypoint');
    const POOL = protocol('PrivacyPoolComplex');
    const poseidonT3 = await deploy(protocol('PoseidonT3'));
    const poseidonT4 = await deploy(protocol('PoseidonT4'));
    const withdrawalVerifier = await deploy(protocol('WithdrawalVerifier'));
    const commitmentVerifier = await deploy(protocol('CommitmentVerifier'));
    const implementation = await deploy(EP);
    // The ASP's postman is its own key, so its root posts never queue behind the deployer's transactions.
    const entrypoint = await deploy(protocol('ERC1967Proxy'), [
      implementation, encodeFunctionData({ abi: EP.abi, functionName: 'initialize', args: [funder.account.address, postman.account.address] }),
    ]);
    const poolFor = (asset: Address) => deployBytes(POOL.abi, link(POOL, { PoseidonT3: poseidonT3, PoseidonT4: poseidonT4 }), [entrypoint, withdrawalVerifier, commitmentVerifier, asset]);
    const movvaPool = await poolFor(movva);
    await send(funder, entrypoint, EP.abi, 'registerPool', [movva, movvaPool, M, VETTING_FEE_BPS, MAX_RELAY_FEE_BPS]);

    log('3. Movva\'s escrow pair: zkTLS for PIX and boleto, an institutional LP, the audit registry');
    const REG = ours('LPRegistry');
    const FIAT = ours('FiatEscrow');
    const ZKTLS = ours('ReclaimZkTlsVerifier');
    const registry = await deploy(REG, [gov.account.address, GOVERNANCE_DELAY]);
    const witnessKeys = [generatePrivateKey(), generatePrivateKey()];
    const templates = receiptTemplates(BANK_URL_PREFIX);
    const zktls = await deploy(ZKTLS, [
      gov.account.address, GOVERNANCE_DELAY, witnessKeys.map((k) => privateKeyToAccount(k).address), 2n,
      RECEIPT_KINDS.map((k) => hashProviderParams(templates[k])), RECEIPT_KINDS.map(() => BANK_URL_PREFIX),
    ]);
    for (const k of RECEIPT_KINDS) {
      if (receiptRail(k) === Rail.BOLETO) await send(gov, zktls, ZKTLS.abi, 'setEndpointRails', [hashProviderParams(templates[k]), receiptRailMask(k)]);
    }
    const onramp = await deploy(FIAT, [reserve, registry, entrypoint, movvaPool, MOVVA_BAND_BPS, gov.account.address, GOVERNANCE_DELAY, DISPUTE_TIMEOUT, TAKER_DISPUTE_TIMEOUT, MAX_VETTING_FEE_BPS]);
    const offramp = await deploy(ours('OffRampEscrow'), [reserve, registry, MOVVA_BAND_BPS, gov.account.address, GOVERNANCE_DELAY, DISPUTE_TIMEOUT]);
    await send(gov, registry, REG.abi, 'setEscrow', [onramp, true]);
    await send(gov, registry, REG.abi, 'setEscrow', [offramp, true]);
    await send(gov, registry, REG.abi, 'setTier', [lp.account.address, TIER_INSTITUTIONAL, 100_000_000n]);
    for (const e of [onramp, offramp]) {
      await send(gov, e, FIAT.abi, 'setAsset', [NATIVE, reserve, 18, false]);
      await send(gov, e, FIAT.abi, 'setAsset', [movva, reserve, 18, true]);
      await send(gov, e, FIAT.abi, 'setVerifier', [zktls, true]);
    }
    const grantRegistry = await deploy(ours('AuditGrantRegistry'));
    // Extras: NodeRewards as the registry's rewards hook before its setup closes, then bound to it while it holds nothing.
    if (extras) await extras.hookRegistry(registry);
    for (const c of [registry, zktls, onramp, offramp]) await send(gov, c, GOVERNED.abi, 'completeSetup');
    if (extras) await extras.bindRegistry(registry);

    log(`4. The LP node as a Movva gateway, the matcher and the note vault${containers ? `, as containers from ${containers.image}` : ''}`);
    const wall = () => BigInt(Math.floor(Date.now() / 1000));
    const bank = new MockBank({ now: wall, receiver: { name: 'LP Liquidez Ltda', city: 'Sao Paulo' } });
    const rampChain = new ViemRampChain({ publicClient: pub, walletClient: lp, registry, onramp, offramp, receiptWaitMs: 30_000 });
    const par = new ParPriceFeed(wall);
    const gateway: GatewayOptions = {
      reserve, usdt, movva,
      mint: { enabled: true, maxSlippageBps: 10, minMintUsdt: 1n * U, maxMintUsdt: 2_000n * U, maxMintUsdtPerDay: 5_000n * U, keepUsdt: 0n, maxFeeBps: 10, usdtCostBps: 0 },
      redeem: {
        enabled: true, keepMovva: 0n, minRedeemMovva: 10n * M, maxRedeemMovva: 10_000n * M, maxRedeemMovvaPerDay: 50_000n * M,
        maxSlippageBps: 10, minCollateralRatioBps: 10_000, maxFeeBps: 10, usdtSaleBps: 30,
      },
      maxRateDeviationBps: 100, maxReferenceAgeSeconds: 300,
    };
    const offerPricing = { spreadBps: 50, minSpreadBps: 20, maxOracleDeviationBps: 100, bandMarginBps: 50, refreshDriftBps: 60, maxReferenceAgeSeconds: 120, oracleStaleMarginSeconds: 300 };
    /** The LP's strategy: handed to the in-process node as it is, and written as the container's LP_CONFIG in image mode. */
    const lpOnramp = {
      escrow: onramp, pixKey: LP_PIX, receiver: { name: 'LP Liquidez Ltda', city: 'Sao Paulo' }, reclaimExpired: true, autoRefund: true,
      boletoDueDays: 3, reorgWindow: 16n, lateCreditGraceSeconds: 600, pixCharge: 'static' as const,
      assets: [{
        asset: movva, symbol: 'MOVVA', liquidity: OFFER_LIQUIDITY, minOrder: 10n * M, maxOrder: 2_000n * M, verifier: zktls, rails: [Rail.PIX, Rail.BOLETO],
        refillBelowBps: 2_000, feed: par, pricing: { ...offerPricing },
      }],
    };
    const lpOfframp = {
      escrow: offramp, rails: ['PIX', 'BOLETO'] as ('PIX' | 'BOLETO')[], maxOpenClaims: 3, minTimeToPaySeconds: 20 * 60, disputeMarginSeconds: 7 * 60,
      bankClockSkewSeconds: 1, raiseDisputeWhenUnproven: true, reorgWindow: 16n,
      assets: [{
        asset: movva, symbol: 'MOVVA', minSaleBrlCents: 100n, maxSaleBrlCents: 10_000_000n, feed: par,
        pricing: { minMarginBps: 50, maxOracleDeviationBps: 100, maxReferenceAgeSeconds: 120, oracleStaleMarginSeconds: 300 },
      }],
    };
    type LpStatus = { ready?: boolean; lastTick?: { error?: string } | null; onramp?: { assets?: { asset: string; quoting: boolean }[] } | null };
    /** The containerized LP node's /status (it answers 503 with the same body until ready). */
    const lpStatus = (): Promise<LpStatus | undefined> => fetch(`http://${HOST}:${PORT.lp}/status`, { signal: AbortSignal.timeout(5_000) })
      .then((r) => r.json() as Promise<LpStatus>).catch(() => undefined);
    /** The LP node as the dev API reports it, and a nudge after a payment where the node runs in this process. */
    let lpNodeState: () => Promise<{ ready: boolean; lastTickError?: string }>;
    let wakeLpNode: () => void = () => {};
    let devBankUrl: string | undefined;
    if (!containers) {
      const node = new LpNode({
        chain: rampChain, bank, journal: new JsonlJournal<LpRecord>(join(work, 'lp.jsonl')),
        provers: [
          new ZkTlsProver(zktls, new LocalWitnessSession({ witnessKeys, receipts: bank, templates, now: wall }), {
            witnesses: { addresses: witnessKeys.map((k) => privateKeyToAccount(k).address), threshold: 2 },
            endpoints: RECEIPT_KINDS.map((k) => ({ providerHash: hashProviderParams(templates[k]), urlPrefix: BANK_URL_PREFIX, rails: [receiptRail(k)] })),
            preflight: async (proof) => { await prepareSettlement(pub, zktls, proof); },
          }),
        ],
        confirmations: 2, fromBlock, reorgWindow: 16n, payerRefSecret: LP_PAYER_REF_SECRET, lpPayerId: LP_PAYER_ID,
        wallClock: wall, pollMs: 1_000,
        log: { info: () => {}, warn: () => {}, error: (m: string) => log(`lp-node error: ${m}`) },
        onramp: lpOnramp,
        offramp: lpOfframp,
        gateway,
        ...(extras ? extras.lpNodeOptions(lp.account.address, registry) : {}),
      });
      node.run();
      stops.push(() => node.stop());
      const api = serveLpNode(node, { mode: 'both', verifyTypedData: (args) => pub.verifyTypedData(args as never) });
      await api.listen(PORT.lp, HOST);
      stops.push(() => api.close());
      for (let i = 0; ; i++) {
        if (node.offers?.status.get(movva.toLowerCase())?.quoting) break;
        if (i > 240) throw new Error('the LP node posted no PIX offer within two minutes');
        await sleep(500);
      }
      lpNodeState = async () => {
        const n = node as unknown as { ready?: boolean; lastTick?: { error?: string } };
        return { ready: n.ready === true, lastTickError: n.lastTick?.error };
      };
      wakeLpNode = node.wake.bind(node);
      const matcher = new MatcherService({ client: pub, escrow: onramp, registry, fromBlock, entrypoint, pollMs: 1_000, quoteTtlSeconds: 120 });
      await matcher.listen(PORT.matcher, HOST);
      stops.push(() => matcher.close());
      const chainGrants = new ChainGrantRegistry({ url: RPC, registry: grantRegistry });
      const vaultService = new VaultService({ vault: new NoteVault(chainGrants), refreshGrant: async (owner, grantId) => { await chainGrants.refresh({ owner, grantIds: [grantId] }); } });
      await vaultService.listen(PORT.vault, HOST);
      stops.push(() => vaultService.close());
    } else {
      // The LP's bank stays here, where the dev API pays into them and reads what the bank sent; the
      // containerized node reaches them over DEV_MOCK_BANK_URL (lp-node dev-mock-bank.ts), on a loopback port the OS picks.
      const bankServer = serveDevMockBank({ bank, onError: (m) => log(`dev bank API: ${m}`) });
      devBankUrl = `http://${HOST}:${await bankServer.listen(0, HOST)}`;
      stops.push(() => bankServer.close());
      // Registered after the bank API, so run before it: the LP node's last tick still reaches its bank.
      stops.push(async () => {
        const removed = await containers.stopAll();
        if (removed.length) log(`stopped and removed ${removed.join(', ')}`);
      });
      const { assets: onrampAssets, reorgWindow: _onrampReorg, ...onrampTerms } = lpOnramp;
      const { assets: offrampAssets, reorgWindow: _offrampReorg, ...offrampTerms } = lpOfframp;
      const lpConfig = {
        registry, fromBlock, confirmations: 2, reorgWindow: 16, pollMs: 1_000, lpPayerId: LP_PAYER_ID,
        // Every book prices at par (ParPriceFeed above): the gateway's Movva, R$ 1,00.
        onramp: { ...onrampTerms, assets: onrampAssets.map(({ feed: _feed, pricing, rails, ...a }) => ({ ...a, rails: rails.map((r) => Rail[r]), price: { source: 'par' }, ...pricing })) },
        offramp: { ...offrampTerms, assets: offrampAssets.map(({ feed: _feed, pricing, ...a }) => ({ ...a, price: { source: 'par' }, ...pricing })) },
        gateway,
      };
      const lpFile = (name: string, content: string) => containers.writeConfig('lp-node', name, content);
      await containers.start({
        service: 'lp-node', title: 'LP node (LP_NODE_DEV=1)', command: ['node', '--import', 'tsx', 'packages/lp-node/src/bin/lp-node.ts'],
        env: {
          RPC_URL: RPC, CHAIN_ID: String(chainId), LP_NODE_DEV: '1', DEV_MOCK_BANK_URL: devBankUrl,
          LP_KEY_FILE: lpFile('lp_key', `${lpKey}\n`), PAYER_REF_SECRET_FILE: lpFile('payer_ref', `${LP_PAYER_REF_SECRET}\n`),
          LP_CONFIG: lpFile('lp.json', JSON.stringify(lpConfig, (_k, v: unknown) => (typeof v === 'bigint' ? v.toString() : v), 2)),
          ZKTLS_WITNESS_KEYS_FILE: lpFile('witnesses.json', JSON.stringify({ verifier: zktls, threshold: 2, keys: witnessKeys, urlPrefix: BANK_URL_PREFIX })),
          STATE_FILE: '/app/data/lp-node.jsonl', HOST, PORT: String(PORT.lp), HEALTH_PATH: '/healthz',
        },
        ports: [{ port: PORT.lp, what: 'API and ops' }], readyUrl: `http://${HOST}:${PORT.lp}/readyz`,
      });
      await containers.start({
        service: 'matcher', title: 'matcher', command: ['node', '--import', 'tsx', 'packages/ramp/src/bin/matcher.ts'],
        env: {
          RPC_URL: RPC, ESCROW: onramp, REGISTRY: registry, FROM_BLOCK: fromBlock.toString(), PP_ENTRYPOINT: entrypoint,
          POLL_MS: '1000', QUOTE_TTL_SECONDS: '120', HOST, PORT: String(PORT.matcher), HEALTH_PATH: '/health',
        },
        ports: [{ port: PORT.matcher, what: 'API' }], readyUrl: `http://${HOST}:${PORT.matcher}/health`,
      });
      await containers.start({
        service: 'vault', title: 'note vault', command: ['node', '--import', 'tsx', 'packages/viewing-key/src/bin/vault.ts'],
        env: { RPC_URL: RPC, REGISTRY: grantRegistry, DATA_FILE: '/app/data/vault.jsonl', HOST, PORT: String(PORT.vault), HEALTH_PATH: '/healthz' },
        ports: [{ port: PORT.vault, what: 'API' }], readyUrl: `http://${HOST}:${PORT.vault}/healthz`,
      });
      lpNodeState = async () => {
        const s = await lpStatus();
        return { ready: s?.ready === true, lastTickError: s?.lastTick?.error };
      };
    }

    /*------------------------------ the co-signer ------------------------------*/
    log(`5. The co-signer on :${PORT.cosigner} (ops :${PORT.cosignerOps})${containers ? ', as a container' : ''}: a development key file, this deployment's contracts as its policy, ${APP_ORIGINS.join(' and ')} pinned`);
    const cosignerDir = join(work, 'cosigner');
    const cosignerKey = generatePrivateKey();
    const coSignerAddress = privateKeyToAccount(cosignerKey).address;
    const cosignerApiKey = toHex(crypto.getRandomValues(new Uint8Array(24))).slice(2);
    const cosignerPolicy = JSON.stringify({
      chainId,
      deployment: { passkeyCoSignerValidator: stack.passkeyValidator, frostValidator: stack.frostValidator, kernelAvatarAdapter: stack.adapter },
      targets: [
        { address: onramp, label: 'FiatEscrow' }, { address: offramp, label: 'OffRampEscrow' }, { address: entrypoint, label: 'PrivacyPoolsEntrypoint' },
        { address: movvaPool, label: 'MovvaPool' },
        { address: grantRegistry, label: 'AuditGrantRegistry' },
      ],
      tokens: [
        { address: movva, label: 'Movva', transfer: false, dailyLimit: (1_000_000n * M).toString() },
      ],
      window: { maxSeconds: 1800, vetoMaxSeconds: 900 },
      rateLimit: { burst: 60, perMinute: 240 },
      webauthn: { rpIds: ['localhost'], origins: APP_ORIGINS },
    }, null, 2);
    // Its sponsorship operator key (never the co-signer key) and its VAPID key for recovery alerts: development key files.
    const cosignerFiles: [name: string, content: string][] = [
      ['cosigner_key', `${cosignerKey}\n`], ['sponsor_key', `${sponsorOperatorKey}\n`], ['vapid.json', JSON.stringify(generateVapidKeys())],
      ['api_keys', `movva-app:${cosignerApiKey}\n`], ['policy.json', cosignerPolicy],
    ];
    if (containers) {
      for (const [name, content] of cosignerFiles) containers.writeConfig('cosigner', name, content);
    } else {
      mkdirSync(cosignerDir, { recursive: true, mode: 0o700 });
      for (const [name, content] of cosignerFiles) {
        writeFileSync(join(cosignerDir, name), content, { mode: 0o600 });
        chmodSync(join(cosignerDir, name), 0o600);
      }
    }
    /** Where the co-signer finds its files: this process's temp dir, or its container's /app/config and /app/data. */
    const cosignerFile = (name: string) => (containers ? `/app/config/${name}` : join(cosignerDir, name));
    const cosignerData = (name: string) => (containers ? `/app/data/${name}` : join(cosignerDir, name));
    const cosignerEnv: Record<string, string> = {
      RPC_URL: RPC, CHAIN_ID: String(chainId), COSIGNER_MODE: 'development',
      COSIGNER_KEY_FILE: cosignerFile('cosigner_key'), COSIGNER_POLICY_FILE: cosignerFile('policy.json'), COSIGNER_API_KEYS_FILE: cosignerFile('api_keys'),
      COSIGNER_AUDIT_LOG: cosignerData('audit.jsonl'),
      HOST, PORT: String(PORT.cosigner), OPS_PORT: String(PORT.cosignerOps), CORS_ORIGINS: APP_ORIGINS.join(','),
      CLIENT_RATE_BURST: '200', CLIENT_RATE_PER_MINUTE: '2000',
      COSIGNER_SPONSOR_GATE: sponsorGate, COSIGNER_SPONSOR_KEY_FILE: cosignerFile('sponsor_key'), COSIGNER_SPONSOR_DAILY_CAP: String(SPONSOR_DAILY_CAP),
      COSIGNER_SPONSOR_RATE_BURST: '100', COSIGNER_SPONSOR_RATE_PER_MINUTE: '600', COSIGNER_SPONSOR_CLIENT_RATE_BURST: '100', COSIGNER_SPONSOR_CLIENT_RATE_PER_MINUTE: '600',
      COSIGNER_ALERTS_VAPID_KEY_FILE: cosignerFile('vapid.json'), COSIGNER_ALERTS_SUBJECT: 'mailto:dev@movva.localhost', COSIGNER_ALERTS_STATE: cosignerData('alerts.jsonl'),
      COSIGNER_ALERTS_CONFIRMATIONS: '1', COSIGNER_ALERTS_POLL_MS: '1000', COSIGNER_ALERTS_START_BLOCK: stackBlock.toString(), COSIGNER_PUSH_ALLOW_INSECURE: '1',
      ...(extras ? extras.cosignerEnv(cosignerData) : {}),
    };
    let cosignerLog: string;
    if (!containers) {
      cosignerLog = join(cosignerDir, 'cosigner.log');
      const cosignerOut = openSync(cosignerLog, 'a');
      const cosigner = spawn(process.execPath, ['--import', 'tsx', join(ROOT, 'packages/cosigner/src/bin/cosigner.ts')], {
        cwd: ROOT, stdio: ['ignore', cosignerOut, cosignerOut],
        env: { PATH: process.env.PATH ?? '', HOME: process.env.HOME ?? '', ...cosignerEnv },
      });
      stops.push(() => new Promise<void>((done) => {
        if (cosigner.exitCode !== null) return done();
        cosigner.once('exit', () => done());
        cosigner.kill('SIGTERM');
        setTimeout(done, 5_000);
      }));
      for (let i = 0; ; i++) {
        if (cosigner.exitCode !== null) throw new Error(`the co-signer exited (${cosigner.exitCode}): ${readFileSync(cosignerLog, 'utf8').slice(-800)}`);
        if (await fetch(`http://${HOST}:${PORT.cosignerOps}/readyz`).then((r) => r.status === 200, () => false)) break;
        if (i > 200) throw new Error(`the co-signer did not become ready within 60 s (log: ${cosignerLog})`);
        await sleep(300);
      }
    } else {
      await containers.start({
        service: 'cosigner', title: 'co-signer (development key file)', command: ['node', '--import', 'tsx', 'packages/cosigner/src/bin/cosigner.ts'],
        env: { ...cosignerEnv, HEALTH_PATH: '/healthz' },
        ports: [{ port: PORT.cosigner, what: 'API' }, { port: PORT.cosignerOps, what: 'ops' }], readyUrl: `http://${HOST}:${PORT.cosignerOps}/readyz`,
      });
      cosignerLog = containers.logFile('cosigner');
    }

    /*------------------------------ image mode: readiness, the monitor; the extras' keepers ------------------------------*/
    let monitorUrl: string | undefined;
    if (containers || extras) {
      log(containers
        ? '5b. Every container\'s readiness and the LP node\'s first offers, then the monitor'
        : '5b. Extras: the keepers - pyth-keeper (from a Hermes this stack plays) and vault-keeper');
    }
    if (extras) {
      await extras.startKeepers({ fx, pyth, usdBrlId: USD_BRL_ID, freePort: () => freePort(HOST) });
      pythKeeperRuns = true;
    }
    if (containers) {
      await Promise.all(['lp-node', 'matcher', 'vault', 'cosigner'].map((s) => containers.waitReady(s)));
      for (let i = 0; ; i++) {
        const books = (await lpStatus())?.onramp?.assets ?? [];
        if (books.some((b) => b.asset.toLowerCase() === movva.toLowerCase() && b.quoting)) break;
        if (i > 240) throw new Error(`the LP node posted no PIX offer within two minutes (${containers.logFile('lp-node')}):\n${await containers.logsTail('lp-node')}`);
        await sleep(500);
      }
      const monitorPort = await freePort(HOST);
      monitorUrl = `http://${HOST}:${monitorPort}`;
      await containers.start({
        service: 'monitor', title: 'monitor', command: ['node', '--import', 'tsx', 'packages/ops/src/bin/monitor.ts'],
        env: {
          RPC_URL: RPC, CHAIN_ID: String(chainId), HOST, PORT: String(monitorPort), HEALTH_PATH: '/healthz',
          PP_ENTRYPOINT: entrypoint, PP_POOL: movvaPool, ORACLE: fx, ESCROW: onramp, OFFRAMP_ESCROW: offramp, ASSETS: movva,
          MOVVA_RESERVE: reserve, RELAYER: relayerW.account.address,
          PAYMASTER: stack.paymaster, SPONSOR_GATE: sponsorGate, SPONSOR_OPERATORS: sponsorOperator,
          GOVERNED: [registry, zktls].join(','), WATCH_FROM_BLOCK: fromBlock.toString(),
        },
        ports: [{ port: monitorPort, what: 'healthz, status, metrics' }], readyUrl: `${monitorUrl}/readyz`,
      });
      await containers.waitReady('monitor');
      const sweep = await fetch(`${monitorUrl}/status`).then((r) => r.json() as Promise<{ verdict: string; checks: { id: string; level: string; detail: string }[] }>);
      const notOk = sweep.checks.filter((c) => c.level !== 'ok');
      log(`   the monitor's first sweep: ${sweep.verdict} (${sweep.checks.length} checks, ${notOk.length} not ok)`);
      for (const c of notOk) log(`     ${c.level} ${c.id}: ${c.detail}`);
    }

    /*------------------------------ reports for the demo's checks ------------------------------*/
    const SPONSORED_ABI = parseAbi(['function sponsored(address account) view returns (bool)']);
    const NONCE_ABI = parseAbi(['function getNonce(address sender, uint192 key) view returns (uint256)']);
    const OWNERS_ABI = parseAbi(['function getOwners() view returns (address[])']);
    const SALE_OPENED = parseAbiItem('event SaleOpened(bytes32 indexed saleId, uint256 weiAmount, uint256 brlCents, uint16 railMask)');
    const GATE_SPONSORED = parseAbiItem('event Sponsored(address indexed operator, address indexed account)');
    /** An account as the chain shows it: its ETH, its code, its UserOperations - which bundle carried each, who paid. */
    const accountReport = async (address: Address) => {
      const [balance, deployed, nonce, events, sponsoredNow, gateLogs] = await Promise.all([
        pub.getBalance({ address }), hasCode(address),
        pub.readContract({ address: MAINNET.entryPoint, abi: NONCE_ABI, functionName: 'getNonce', args: [address, 0n] }),
        pub.getLogs({ address: MAINNET.entryPoint, event: AA_EVENTS_ABI[0], args: { sender: address }, fromBlock: stackBlock, strict: true }),
        read<boolean>(stack.paymaster, SPONSORED_ABI, 'sponsored', [address]),
        pub.getLogs({ address: sponsorGate, event: GATE_SPONSORED, args: { account: address }, fromBlock: stackBlock, strict: true }),
      ]);
      // Who allowlisted it: SponsorGate's Sponsored events for the account, and the transactions that emitted them.
      const sponsorship = {
        sponsored: sponsoredNow, gate: sponsorGate, operator: sponsorOperator,
        byGate: await Promise.all(gateLogs.map(async (l) => {
          const tx = await pub.getTransaction({ hash: l.transactionHash });
          return { operator: l.args.operator, transactionHash: l.transactionHash, from: tx.from, to: tx.to };
        })),
      };
      const operations = await Promise.all(events.map(async (e) => {
        const tx = await pub.getTransaction({ hash: e.transactionHash });
        return {
          transactionHash: e.transactionHash, success: e.args.success, paymaster: e.args.paymaster, actualGasCost: e.args.actualGasCost.toString(),
          bundle: { from: tx.from, to: tx.to },
        };
      }));
      const owners = deployed ? await pub.readContract({ address, abi: OWNERS_ABI, functionName: 'getOwners' }).catch(() => undefined) : undefined;
      const kernelPasskey = deployed && !owners
        ? await pub.readContract({ address: stack.passkeyValidator, abi: PASSKEY_COSIGNER_VALIDATOR_ABI, functionName: 'configOf', args: [address] })
          .then((c) => ({ x: toHex(c.x), coSigner: c.coSigner }), () => undefined)
        : undefined;
      return {
        address, balance: balance.toString(), deployed, entryPointNonce: nonce.toString(), paymaster: stack.paymaster, bundlerExecutor: stack.bundlerExecutor,
        entryPoint: MAINNET.entryPoint, operations, ...(owners ? { owners } : {}), ...(kernelPasskey ? { kernelPasskey } : {}), sponsorship,
      };
    };
    const stranger = privateKeyToAccount(generatePrivateKey()).address;
    const recoveryRequests = new Map<Address, QueueRequest>();

    /*------------------------------ faults, for the e2e tests ------------------------------*/
    /**
     * Switches the e2e tests set through the dev API (`POST /api/dev/faults`), to stop a flow where a real one can stop.
     * Nothing in the app knows about them, and no check anywhere is skipped:
     *
     *  - `failNextOpenSale`: the next UserOperation whose calls include OffRampEscrow.openSale is answered with a bundler
     *    error instead of being submitted, once. The sale's exit has landed and its openSale never reaches the chain - as
     *    if the page had closed between the two - so the sale is left in progress on the device, to resume or give up.
     *  - `holdAsp`: the ASP approves no new deposit until released, so a re-shielded note stays awaiting approval for as
     *    long as a test looks at it. What was deposited meanwhile is approved once it is released.
     *  - `raisePoolMinimum`: the Entrypoint's owner (the deployer) raises the Movva pool's minimum deposit to R$ 1.000.000,00,
     *    above any order, so a shielded delivery reverts `MinimumDepositAmount` as FiatEscrow.takeDeliveryDirect's NatSpec
     *    describes; false restores it (R$ 1,00).
     *  - `holdNextExit`: the relayer takes the next Entrypoint.relay and answers with an error without submitting it, as a
     *    relayer that has the proof and has not sent it yet; `releaseHeldExits` submits what it holds.
     */
    const faults = { failNextOpenSale: false, holdAsp: false, holdNextExit: false, raisePoolMinimum: false };
    const heldExits: { to: Address; data: Hex }[] = [];
    const RAISED_MINIMUM = 1_000_000n * M;
    /** What the co-signer's recovery alerts POSTed to a subscription endpoint on this stack (/api/dev/push/<id>): as received, encrypted. */
    const pushed: { id: string; at: number; headers: Record<string, string>; body: string }[] = [];
    const OPEN_SALE_SELECTOR = toFunctionSelector(
      'function openSale(address asset, uint256 amount, uint256 brlCents, bytes32 payeeKeyHash, address verifier, uint16 railMask, address refundTo)',
    ).slice(2);
    /** Whether a UserOperation's callData carries a call to openSale: its selector at a byte boundary, anywhere in a batch. */
    const callsOpenSale = (callData: unknown): boolean => {
      if (typeof callData !== 'string') return false;
      const hex = callData.toLowerCase().replace(/^0x/, '');
      for (let i = hex.indexOf(OPEN_SALE_SELECTOR); i >= 0; i = hex.indexOf(OPEN_SALE_SELECTOR, i + 1)) {
        if (i % 2 === 0) return true;
      }
      return false;
    };
    /** The bundler, through the gateway: forwarded untouched, unless `failNextOpenSale` is set and this is that operation. */
    const bundler = async (rq: IncomingMessage, rs: ServerResponse): Promise<void> => {
      if (!faults.failNextOpenSale || rq.method !== 'POST') return proxy(rq, rs, PORT.bundler, '/');
      const body = await rawBody(rq);
      let call: { id?: unknown; method?: unknown; params?: unknown } | undefined;
      try {
        call = JSON.parse(body.toString('utf8')) as typeof call;
      } catch {
        call = undefined;
      }
      const params = call?.params;
      const op = Array.isArray(params) ? (params[0] as { callData?: unknown } | undefined) : undefined;
      if (call?.method === 'eth_sendUserOperation' && callsOpenSale(op?.callData)) {
        faults.failNextOpenSale = false;
        log('fault (failNextOpenSale): an openSale UserOperation was answered with a bundler error, not submitted');
        return sendJson(rs, 200, { jsonrpc: '2.0', id: call?.id ?? null, error: { code: -32603, message: 'dev-stack fault (failNextOpenSale): this openSale was not submitted' } });
      }
      return proxy(rq, rs, PORT.bundler, '/', body);
    };

    /*------------------------------ the ASP ------------------------------*/
    const DEPOSITED = parseAbiItem('event Deposited(address indexed _depositor, uint256 _commitment, uint256 _label, uint256 _value, uint256 _precommitmentHash)');
    const approved: bigint[] = [];
    const seen = new Set<string>();
    /** The labels of the root the Entrypoint holds: what the wallet rebuilds the tree from. */
    let published: bigint[] = [];
    let aspFrom = fromBlock;
    const aspTick = async () => {
      // Held (faults.holdAsp): nothing new is approved; what was deposited meanwhile is picked up once released.
      if (faults.holdAsp) return;
      const head = await pub.getBlockNumber();
      if (head < aspFrom) return;
      const logs = await pub.getLogs({ address: movvaPool, event: DEPOSITED, fromBlock: aspFrom, toBlock: head });
      const fresh = logs.map((l) => l.args._label!).filter((l) => !seen.has(l.toString()));
      aspFrom = head + 1n;
      if (fresh.length === 0) return;
      for (const l of fresh) { seen.add(l.toString()); approved.push(l); }
      const tree = new LeanIMT<bigint>((a, b) => poseidon2([a, b]));
      tree.insertMany([...approved]);
      const labels = [...approved];
      await send(postman, entrypoint, EP.abi, 'updateRoot', [tree.root, CID]);
      published = labels;
    };

    /*------------------------------ the relayer ------------------------------*/
    const relayer = new EoaExecutor({ wallet: relayerW, publicClient: pub });
    const relay = async (body: { to?: unknown; data?: unknown; value?: unknown }) => {
      if (typeof body.to !== 'string' || !isAddress(body.to) || typeof body.data !== 'string') throw new HttpError(400, 'a call is { to, data }');
      if (body.value !== undefined && body.value !== 0n) throw new HttpError(400, 'the relayer sends no value');
      const to = getAddress(body.to);
      let functionName: string;
      try {
        functionName = decodeFunctionData({ abi: PP_ENTRYPOINT_ABI, data: body.data as Hex }).functionName;
      } catch {
        throw new HttpError(403, 'the relayer submits Entrypoint.relay only');
      }
      if (!(to === entrypoint && functionName === 'relay')) throw new HttpError(403, 'the relayer submits Entrypoint.relay only');
      if (faults.holdNextExit) {
        faults.holdNextExit = false;
        heldExits.push({ to, data: body.data as Hex });
        log('fault (holdNextExit): the relayer took an exit and holds it, not submitted');
        throw new HttpError(502, 'dev-stack fault (holdNextExit): the relayer holds this exit and has not submitted it');
      }
      try {
        return await serial(relayerW.account.address, () => relayer.execute([{ to, data: body.data as Hex }]));
      } catch (e) {
        throw new HttpError(422, e instanceof Error ? (e as { shortMessage?: string }).shortMessage ?? e.message : String(e));
      }
    };

    /*------------------------------ dev API ------------------------------*/
    /** Where each service runs: in this process, or which container on which host ports. */
    const servicesReport = () => (containers
      ? { mode: 'image', image: containers.image, runtime: containers.runtime, containers: containers.describe(), devBankApi: devBankUrl, monitor: monitorUrl }
      : extras ? { mode: 'source', extras: extras.describeServices() } : { mode: 'source' });
    const auditor = Auditor.fromSeed(new Uint8Array(32).fill(7));
    const day = 86_400_000;
    const sampleBills = () => [
      {
        label: 'Boleto a vencer: R$ 45,90, vence em 10 dias',
        line: buildBankBoleto({ bankCode: '341', amountCents: 4_590n, freeField: '1234567890123456789012345', dueDate: brasiliaToday(new Date(Date.now() + 10 * day)) }).line,
        expect: 'Aceito: o valor e o vencimento vêm do próprio boleto.',
      },
      {
        label: 'Boleto vencido: R$ 30,00, venceu há 3 dias',
        line: buildBankBoleto({ bankCode: '341', amountCents: 3_000n, freeField: '9876543210987654321098765', dueDate: brasiliaToday(new Date(Date.now() - 3 * day)) }).line,
        expect: 'Recusado antes de qualquer movimentação: boleto vencido.',
      },
      {
        label: 'Boleto sem vencimento: R$ 25,00',
        line: buildBankBoleto({ bankCode: '237', amountCents: 2_500n, freeField: '1111122222333334444455555' }).line,
        expect: 'Recusado: sem data de vencimento, o banco dos provedores não paga.',
      },
      {
        label: 'Conta de consumo (arrecadação): R$ 80,00',
        line: buildCollectionBoleto({ segment: 2, valueIdentifier: 6, value: 8_000n, rest: '12345678901234567890123456789' }).line,
        expect: 'Recusado: guia de arrecadação, sem vencimento.',
      },
    ];
    /** Who paid, as the bank reports it: a CPF or CNPJ the caller names (the LP node's caps count per payer), else MockBank's default. */
    const payerOf = (v: unknown): string | undefined => {
      if (v === undefined) return undefined;
      if (typeof v !== 'string' || !/^(\d{11}|\d{14})$/.test(v)) throw new HttpError(400, 'payerId is a CPF (11 digits) or CNPJ (14)');
      return v;
    };
    const dev = async (method: string, path: string, rq: IncomingMessage, url: URL): Promise<unknown> => {
      if (path === '/extras' || path.startsWith('/extras/')) {
        if (!extras) throw new HttpError(404, 'the extras are off: start the stack with DEV_STACK_EXTRAS=1');
        try {
          return await extras.dev(method, path.slice('/extras'.length), () => readBody<Record<string, unknown>>(rq));
        } catch (e) {
          if (e instanceof HttpError) throw e;
          if (e instanceof ExtrasError) throw new HttpError(e.status, e.message);
          throw new HttpError(422, e instanceof Error ? (e as { shortMessage?: string }).shortMessage ?? e.message.split('\n')[0]! : String(e));
        }
      }
      if (method === 'GET' && path === '/state') {
        return {
          chainId, block: (await pub.getBlockNumber()).toString(),
          lpNode: await lpNodeState(),
          outgoing: bank.outgoing.slice(-10).reverse().map((o) => ({ kind: o.kind, destination: o.destination, amountCents: o.amountCents.toString(), status: o.result.status })),
          sponsorship: { gate: sponsorGate, operator: sponsorOperator },
        };
      }
      if (method === 'POST' && path === '/fund') {
        const { address } = await readBody<{ address?: string }>(rq);
        if (!address || !isAddress(address)) throw new HttpError(400, 'address required');
        const balance = await pub.getBalance({ address: getAddress(address) });
        if (Number(formatEther(balance)) >= 0.05) return { funded: false };
        await fund(faucet, getAddress(address), parseEther('0.5'));
        return { funded: true };
      }
      if (method === 'POST' && path === '/pay-pix') {
        const { pixCopiaECola, payerId } = await readBody<{ pixCopiaECola?: string; payerId?: unknown }>(rq);
        if (!pixCopiaECola) throw new HttpError(400, 'pixCopiaECola required');
        const code = parsePixBrCode(pixCopiaECola);
        if (code.amountCents === undefined) throw new HttpError(400, 'the code carries no amount');
        bank.receivePix({ amountCents: code.amountCents, creditedKey: code.key, txid: code.txid, payerId: payerOf(payerId) });
        wakeLpNode();
        return { paid: `PIX de ${code.amountCents} centavos para ${code.key}` };
      }
      if (method === 'POST' && path === '/pay-boleto') {
        const { line, payerId } = await readBody<{ line?: string; payerId?: unknown }>(rq);
        if (!line) throw new HttpError(400, 'line required');
        bank.payRegisteredBoleto(line, { payerId: payerOf(payerId) });
        wakeLpNode();
        return { paid: 'boleto' };
      }
      if (method === 'GET' && path === '/sample-bills') return { bills: sampleBills() };
      if (method === 'GET' && path === '/auditor-key') return { publicKey: auditor.publicKey, name: 'Auditor de teste' };
      if (method === 'GET' && path === '/push') return { messages: pushed };
      if (method === 'GET' && path === '/services') return servicesReport();
      if (method === 'GET' && path === '/monitor') {
        if (!monitorUrl) throw new HttpError(404, 'the monitor runs in image mode only (MOVA_SERVICES_IMAGE)');
        return (await fetch(`${monitorUrl}/status`)).json();
      }
      if (method === 'GET' && path === '/account') {
        const address = url.searchParams.get('address');
        if (!address || !isAddress(address)) throw new HttpError(400, 'address required');
        return accountReport(getAddress(address));
      }
      if (method === 'GET' && path === '/sale-accounts') {
        const opened = await pub.getLogs({ address: offramp, event: SALE_OPENED, fromBlock, strict: true });
        const sellers = [...new Set(await Promise.all(opened.map(async (l) => getAddress((await rampChain.sale(l.args.saleId)).seller))))];
        return { accounts: await Promise.all(sellers.map((a) => accountReport(a))) };
      }
      if (method === 'POST' && path === '/recovery/request') {
        // What a stolen passkey would queue on the account's recovery Delay: a transfer out. Signed by the page's passkey.
        const { account } = await readBody<{ account?: string }>(rq);
        if (!account || !isAddress(account)) throw new HttpError(400, 'account required');
        const target = getAddress(account);
        const call = { to: movva, value: 0n, data: encodeFunctionData({ abi: parseAbi(['function transfer(address to, uint256 amount) returns (bool)']), functionName: 'transfer', args: [stranger, M] }) };
        const request = buildQueueRequest(predictDelayAddress(target), BigInt(chainId), call);
        recoveryRequests.set(target, request);
        return { delay: request.delay, hash: request.hash, to: call.to };
      }
      if (method === 'POST' && path === '/recovery/queue') {
        const b = await readBody<{ account?: string; owner?: { x?: string; y?: string }; assertion?: { authenticatorData?: string; clientDataJSON?: string; signature?: string } }>(rq);
        if (!b.account || !isAddress(b.account)) throw new HttpError(400, 'account required');
        const request = recoveryRequests.get(getAddress(b.account));
        if (!request) throw new HttpError(409, 'POST /recovery/request first');
        const a = b.assertion;
        const o = b.owner;
        const hexes = [a?.authenticatorData, a?.clientDataJSON, a?.signature, o?.x, o?.y];
        if (!hexes.every((v) => typeof v === 'string' && isHex(v))) throw new HttpError(400, 'owner { x, y } and assertion { authenticatorData, clientDataJSON, signature }, as hex');
        const assertion = assertionFromAuthenticatorResponse({
          authenticatorData: hexToBytes(a!.authenticatorData as Hex), clientDataJSON: hexToBytes(a!.clientDataJSON as Hex), signature: hexToBytes(a!.signature as Hex),
        });
        const signer = await predictSignerAddress(pub, { x: BigInt(o!.x!), y: BigInt(o!.y!) });
        const receipt = await serial(faucet.account.address, async () => pub.waitForTransactionReceipt({
          hash: await faucet.sendTransaction({ to: request.delay, data: encodeSignedQueue(request, signer, encodeWebAuthnSignature(assertion)), gas: 2_000_000n }),
        }));
        if (receipt.status !== 'success') throw new HttpError(422, 'the Delay refused the signed request');
        const added = receipt.logs.map((l) => parseTransactionAdded(l)).find((x) => x !== null);
        if (!added) throw new HttpError(422, 'queued, but no TransactionAdded event');
        recoveryRequests.delete(getAddress(b.account));
        return { queued: true, delay: request.delay, queueNonce: added.queueNonce.toString() };
      }
      if (path === '/faults' && (method === 'GET' || method === 'POST')) {
        if (method === 'POST') {
          type Switch = 'failNextOpenSale' | 'holdAsp' | 'holdNextExit' | 'raisePoolMinimum' | 'releaseHeldExits';
          const b = await readBody<Partial<Record<Switch, unknown>>>(rq);
          for (const k of ['failNextOpenSale', 'holdAsp', 'holdNextExit', 'raisePoolMinimum', 'releaseHeldExits'] as const) {
            if (b[k] !== undefined && typeof b[k] !== 'boolean') throw new HttpError(400, `${k} is true or false`);
          }
          if (typeof b.raisePoolMinimum === 'boolean' && b.raisePoolMinimum !== faults.raisePoolMinimum) {
            await send(funder, entrypoint, EP.abi, 'updatePoolConfiguration', [movva, b.raisePoolMinimum ? RAISED_MINIMUM : M, VETTING_FEE_BPS, MAX_RELAY_FEE_BPS]);
            faults.raisePoolMinimum = b.raisePoolMinimum;
          }
          for (const k of ['failNextOpenSale', 'holdAsp', 'holdNextExit'] as const) {
            const v = b[k];
            if (typeof v === 'boolean') faults[k] = v;
          }
          if (b.releaseHeldExits === true) {
            for (const call of heldExits.splice(0)) {
              try {
                await serial(relayerW.account.address, () => relayer.execute([call]));
                log('fault (holdNextExit): a held exit was submitted');
              } catch (e) {
                log(`fault (holdNextExit): a held exit could not be submitted: ${e instanceof Error ? e.message.split('\n')[0] : String(e)}`);
              }
            }
          }
          log(`faults: ${JSON.stringify(faults)}, ${heldExits.length} exit(s) held`);
        }
        return { ...faults, heldExits: heldExits.length };
      }
      throw new HttpError(404, 'not found');
    };

    /*------------------------------ deployment ------------------------------*/
    const deployment = {
      version: 1,
      name: 'Movva · demonstração local (anvil)',
      chainId,
      rpcUrl: '/api/rpc',
      fromBlock: fromBlock.toString(),
      contracts: { movva, reserve, onramp, offramp, entrypoint, movvaPool, saleVerifier: zktls, auditGrantRegistry: grantRegistry },
      services: {
        matcher: '/api/matcher', lpNodes: [{ lp: lp.account.address, url: '/api/lp', name: 'LP Liquidez Ltda' }],
        relayer: '/api/relayer', asp: '/api/asp', vault: '/api/vault',
      },
      trust: { pixLocationHosts: [] },
      policy: { exitRelayFeeBps: '50', saleDiscountBps: '100' },
      account: ACCOUNT_KIND === 'eoa' ? { kind: 'eoa' } : {
        kind: ACCOUNT_KIND, kinds: ['safe', 'kernel'], bundler: '/api/bundler', paymasterAndData: stack.paymasterAndData,
        // Through the gateway, as the matcher, LP node and vault are: a browser that reaches the app reaches the co-signer
        // (over an SSH tunnel or a forwarded port, 8981 alone). The co-signer still runs on its own port, CORS pinned.
        cosigner: { url: '/api/cosigner', apiKey: cosignerApiKey, address: coSignerAddress },
        kernel: { passkeyValidator: stack.passkeyValidator, adapter: stack.adapter },
        gas: { verificationGasLimit: String(LIVE_GAS.verificationGasLimit), callGasLimit: String(LIVE_GAS.callGasLimit), preVerificationGas: String(LIVE_GAS.preVerificationGas) },
      },
      dev: { url: '/api/dev' },
      // The app reads none of this: the extras' contracts, for a console (their state: GET /api/dev/extras).
      ...(extras ? { extras: { ...extras.c, frostValidator: stack.frostValidator } } : {}),
    };
    mkdirSync(STATE_DIR, { recursive: true });
    writeFileSync(join(STATE_DIR, 'deployment.json'), `${JSON.stringify(deployment, null, 2)}\n`);

    /*------------------------------ gateway ------------------------------*/
    const handle = async (rq: IncomingMessage, rs: ServerResponse) => {
      const url = new URL(rq.url ?? '/', `http://${HOST}`);
      const p = url.pathname;
      if (!p.startsWith('/api/')) return serveStatic(rq, rs, p);
      if (rq.method === 'OPTIONS') {
        rs.writeHead(204, CORS);
        return rs.end();
      }
      const rest = (prefix: string) => `${p.slice(prefix.length) || '/'}${url.search}`;
      try {
        if (p === '/api/rpc') return proxy(rq, rs, PORT.anvil, '/');
        if (p === '/api/bundler') return await bundler(rq, rs);
        if (p === '/api/matcher' || p.startsWith('/api/matcher/')) return proxy(rq, rs, PORT.matcher, rest('/api/matcher'));
        if (p === '/api/lp' || p.startsWith('/api/lp/')) return proxy(rq, rs, PORT.lp, rest('/api/lp'));
        if (p === '/api/vault' || p.startsWith('/api/vault/')) return proxy(rq, rs, PORT.vault, rest('/api/vault'));
        if (p === '/api/cosigner' || p.startsWith('/api/cosigner/')) return proxy(rq, rs, PORT.cosigner, rest('/api/cosigner'));
        if (p === '/api/deployment.json') return sendJson(rs, 200, deployment);
        if (p === '/api/relayer' && rq.method === 'GET') return sendJson(rs, 200, { address: relayerW.account.address });
        if (p === '/api/relayer/submit' && rq.method === 'POST') return sendJson(rs, 200, await relay(await readBody(rq)));
        if (p === '/api/asp/labels' && rq.method === 'GET') return sendJson(rs, 200, { labels: published.map(String) });
        if (p.startsWith('/api/dev/push/') && rq.method === 'POST') {
          // The push service's side of a Web Push: the co-signer POSTs the encrypted alert here; kept as received.
          const id = p.slice('/api/dev/push/'.length);
          if (!/^[0-9a-zA-Z-]{1,64}$/.test(id)) throw new HttpError(400, 'a push id is 1 to 64 letters, digits or dashes');
          const body = await rawBody(rq);
          const header = (name: string) => { const v = rq.headers[name]; return Array.isArray(v) ? v.join(', ') : v ?? ''; };
          pushed.push({ id, at: Date.now(), body: body.toString('base64'), headers: Object.fromEntries(['content-encoding', 'authorization', 'ttl', 'urgency', 'topic'].map((h) => [h, header(h)])) });
          rs.writeHead(201, CORS);
          return rs.end();
        }
        if (p.startsWith('/api/dev/')) return sendJson(rs, 200, await dev(rq.method ?? 'GET', p.slice('/api/dev'.length), rq, url));
        throw new HttpError(404, 'not found');
      } catch (e) {
        const status = e instanceof HttpError ? e.status : 500;
        if (status === 500) log(`${rq.method} ${p}: ${e instanceof Error ? e.message : String(e)}`);
        return sendJson(rs, status, { error: e instanceof Error ? e.message : String(e) });
      }
    };
    const gatewayServer: Server = createServer((rq, rs) => void handle(rq, rs));
    await new Promise<void>((res, rej) => {
      gatewayServer.once('error', rej);
      gatewayServer.listen(PORT.gateway, HOST, () => res());
    });
    stops.push(() => new Promise<void>((r) => { gatewayServer.close(() => r()); gatewayServer.closeAllConnections(); }));

    /*------------------------------ loops ------------------------------*/
    let stopping = false;
    const loop = (name: string, ms: number, fn: () => Promise<void>) => {
      let timer: NodeJS.Timeout | undefined;
      const run = async () => {
        try { await fn(); } catch (e) { log(`${name}: ${e instanceof Error ? e.message.split('\n')[0] : String(e)}`); }
        if (!stopping) timer = setTimeout(() => void run(), ms);
      };
      void run();
      stops.push(() => { stopping = true; if (timer) clearTimeout(timer); });
    };
    loop('asp', 1_500, aspTick);
    loop('price keeper', 60_000, publishPrices);
    if (extras) loop('extras', 5_000, () => extras.tick());

    const ready = {
      // localhost, not the IP: passkeys refuse an IP address as their relying party.
      gateway: `http://${HOST}:${PORT.gateway}`, app: `http://localhost:${PORT.gateway}/`, devServer: 'http://localhost:8980/', rpc: RPC, chainId,
      deployment: join(STATE_DIR, 'deployment.json'),
      account: ACCOUNT_KIND, cosigner: `http://localhost:${PORT.cosigner}`, bundler: stack.bundlerUrl, paymaster: stack.paymaster,
      cosignerLog, bundlerLog: stack.bundlerLog, services: servicesReport(),
    };
    writeFileSync(join(STATE_DIR, 'ready.json'), `${JSON.stringify(ready, null, 2)}\n`);
    log('ready');
    log(`  app (built):        ${ready.app}${existsSync(join(DIST, 'index.html')) ? '' : '   (build it first: npm run build -w @mova/app)'}`);
    log(`  app (dev server):   ${ready.devServer}   (npm run dev -w @mova/app)`);
    log(`  deployment JSON:    ${ready.gateway}/api/deployment.json  ->  ${ready.deployment}`);
    log(`  anvil:              ${RPC} (chain ${chainId})`);
    log(`  account:            ${ACCOUNT_KIND}${ACCOUNT_KIND === 'eoa' ? '' : ` - co-signer ${coSignerAddress} on :${PORT.cosigner}, Alto on :${PORT.bundler}, SponsorPaymaster ${stack.paymaster}`}`);
    log(`  sponsorship:        SponsorGate ${sponsorGate}, the co-signer's operator ${sponsorOperator} (at most ${SPONSOR_DAILY_CAP} accounts a day)`);
    if (extras) {
      log(`  extras:             breaker ${extras.c.breaker}, YieldVault ${extras.c.yieldVault}, FeeSplitter ${extras.c.splitter}, NodeRewards ${extras.c.nodeRewards}`);
      log(`                      ${extras.describeServices().map((s) => `${s.name} :${s.opsPort ?? s.port}`).join(', ')}; logs in ${join(work, 'extras')}`);
      log(`                      state and switches: ${ready.gateway}/api/dev/extras`);
    }
    if (containers) {
      log(`  services:           containers from ${containers.image} (${containers.runtime}); logs in ${join(work, 'containers')}/<service>/container.log`);
      for (const line of containers.table()) log(`    ${line}`);
      log(`  on this host:       anvil :${PORT.anvil}, Alto :${PORT.bundler}, the gateway and dev API :${PORT.gateway}, the dev bank API ${devBankUrl}`
        + ' (MockBank, for the LP node), the relayer, the ASP and the Pyth keeper');
      log(`  monitor:            ${monitorUrl}/status (or ${ready.gateway}/api/dev/monitor); the containers: ${ready.gateway}/api/dev/services`);
    }
  } catch (e) {
    await shutdown();
    throw e;
  }
}

// From the start, not once ready: a signal while the stack deploys stops what already runs, containers included.
let signalled = false;
for (const signal of ['SIGINT', 'SIGTERM', 'SIGHUP'] as const) {
  process.on(signal, () => {
    if (signalled) return;
    signalled = true;
    log('stopping');
    void shutdown().finally(() => process.exit(0));
  });
}
let crashed = false;
process.on('uncaughtException', (e) => {
  if (crashed) return;
  crashed = true;
  try { console.error(`[dev-stack] crashed: ${e instanceof Error ? e.stack ?? e.message : String(e)}`); } catch { /* stderr may be gone */ }
  void shutdown().finally(() => process.exit(1));
});
main().catch((e: unknown) => {
  // A signal meanwhile stopped the stack under the startup: that is the stop, not a failure to report.
  if (signalled) return;
  console.error(`[dev-stack] failed: ${e instanceof Error ? (e as { shortMessage?: string }).shortMessage ?? e.message : String(e)}`);
  void shutdown().finally(() => process.exit(1));
});
