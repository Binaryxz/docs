/**
 * The dev stack's extras (DEV_STACK_EXTRAS=1, source mode only): what the rail deploys or runs beside the app's own flows,
 * on the same chain, so a test console can drive it. Off - the default - none of this exists and the stack is what it
 * always was.
 *
 *  - The divergence breaker: DivergenceBreaker over one tripping source, a settable MockPriceSource, built before the
 *    reserve as DeployMovva builds it (BREAKER is immutable). The stack keeps the source on the reserve's own rate; the dev
 *    API moves it off by a number of basis points, or takes it down, and back.
 *  - The FX leg's keeper: the real pyth-keeper (packages/yield) posting through MockPyth, from a Hermes this stack plays.
 *    That Hermes is live, stale (behind: nothing newer than a price an hour old) or closed (its market hours say so), and
 *    stale and closed backdate the chain's price past the oracle's maxAge at once, as an hour of either would.
 *  - The reserve's yield: YieldVault with an ERC4626Adapter over StataLike (Aave's stata wrapper as the tests stand it in)
 *    behind a KeeperGate, and the real vault-keeper as the gate's operator. The dev API pays the stata wrapper interest.
 *  - Fees to LPs: the reserve's fees go through a FeeSplitter (30% to NodeRewards), NodeRewards is the registry's rewards
 *    hook and bound to it, and the LP node claims (its `rewards` option). One-day epochs and reviews, the shortest the
 *    contract allows: a first claim is two days of chain time away. Nothing in the repository calls split(), which is
 *    open to anyone, so the stack does once a minute, as it plays the ASP.
 *  - Per-payer caps on the LP node: one combined daily limit per tier, Rev. 3 §12.1's outbound figures (the node keeps
 *    one total per payer, not one per direction). Every payer is tier 4 unless the dev API names another tier for it.
 *  - The co-signer's FROST share store.
 *
 * The keepers' status servers listen on every interface; they are preloaded with dev-stack-loopback.mjs, which binds
 * them to 127.0.0.1.
 */
import { spawn, type ChildProcess } from 'node:child_process';
import { chmodSync, mkdirSync, openSync, readFileSync, writeFileSync } from 'node:fs';
import { createServer, type Server } from 'node:http';
import { join } from 'node:path';
import {
  encodeAbiParameters, parseAbi, parseEther, type Abi, type Account, type Address, type Chain, type Hex, type PublicClient,
  type TransactionReceipt, type Transport, type WalletClient,
} from 'viem';
import { generatePrivateKey, privateKeyToAccount } from 'viem/accounts';
import type { CapsOptions, RewardsOptions, Tier } from '@mova/lp-node';

export const EXTRAS = process.env.DEV_STACK_EXTRAS === '1';

/** The extras' contracts, copied into the artifact snapshot with the stack's own. */
export const EXTRA_ARTIFACTS: [file: string, name: string][] = [
  ['DivergenceBreaker.sol', 'DivergenceBreaker'], ['MovvaBreaker.t.sol', 'MockPriceSource'],
  ['YieldVault.sol', 'YieldVault'], ['KeeperGate.sol', 'KeeperGate'], ['ERC4626Adapter.sol', 'ERC4626Adapter'], ['ERC4626Adapter.t.sol', 'StataLike'],
  ['NodeRewards.sol', 'NodeRewards'], ['FeeSplitter.sol', 'FeeSplitter'],
];

const BPS = 10_000n;
const U = 10n ** 6n;
const DAY = 86_400n;
const BREAKER_BAND_BPS = 300;
const LP_REWARD_SHARE_BPS = 3_000;
/** Movva per centavo of volume, as DeployMovva's NodeRewards: R$ 0,01 is 1e16. */
const MOVVA_PER_CENT = 10n ** 16n;
/** The FX leg's maxAge, as dev-stack deploys PythFxOracle. */
const FX_MAX_AGE = 3_600n;
/** Rev. 3 §12.1's daily outbound limits by tier, in centavos: one combined total per payer here. */
const TIER_DAILY_CENTS: Record<Tier, bigint> = { 0: 100_000n, 1: 250_000n, 2: 500_000n, 3: 1_000_000n, 4: 1_500_000n };
const DEFAULT_TIER: Tier = 4;

type Wallet = WalletClient<Transport, Chain, Account>;
interface Artifact { abi: Abi; bytecode: Hex }

export interface ExtrasContext {
  root: string;
  host: string;
  rpc: string;
  chainId: number;
  work: string;
  pub: PublicClient;
  funder: Wallet;
  gov: Wallet;
  ours: (name: string, file?: string) => Artifact;
  /** The stack's own deploy, which takes its fuller artifact type: a method, so the parameter is compared bivariantly. */
  deploy(a: Artifact, args?: unknown[]): Promise<Address>;
  send: (w: Wallet, address: Address, abi: Abi, functionName: string, args?: unknown[]) => Promise<TransactionReceipt>;
  read: <T>(address: Address, abi: Abi, functionName: string, args?: unknown[]) => Promise<T>;
  fund: (from: Wallet, to: Address, value: bigint) => Promise<void>;
  log: (s: string) => void;
  stops: (() => Promise<void> | void)[];
}

export type FxMode = 'live' | 'stale' | 'closed';
export type BreakerMode = 'follow' | 'diverge' | 'fail';

export class ExtrasError extends Error {
  constructor(readonly status: number, message: string) { super(message); }
}

const PYTH_READ_ABI = parseAbi([
  'struct Price { int64 price; uint64 conf; int32 expo; uint256 publishTime; }',
  'function getPriceUnsafe(bytes32 id) view returns (Price)',
  'function set(bytes32 id, int64 price, uint64 conf, int32 expo, uint256 publishTime)',
]);
const ERC20_ABI = parseAbi(['function balanceOf(address) view returns (uint256)', 'function totalSupply() view returns (uint256)']);
const FX_ORACLE_ABI = parseAbi(['function inCoreSession() view returns (bool)', 'function brlCentsPerUnit() view returns (uint256 price, uint64 updatedAt)']);

/** A read that reports its revert instead of throwing: the status shows a refusing contract as it refuses. */
async function attempt<T>(fn: () => Promise<T>): Promise<T | { error: string }> {
  try {
    return await fn();
  } catch (e) {
    const walked = (e as { walk?: (f: (x: unknown) => boolean) => unknown }).walk?.((x) => typeof (x as { data?: { errorName?: unknown } }).data?.errorName === 'string') as
      { data?: { errorName: string } } | undefined;
    return { error: walked?.data?.errorName ?? (e as { shortMessage?: string }).shortMessage ?? (e instanceof Error ? e.message.split('\n')[0]! : String(e)) };
  }
}

interface Service { name: string; port?: number; opsPort?: number; log: string; child: ChildProcess; address?: Address }

export class DevStackExtras {
  fxE6: bigint;
  fxMode: FxMode = 'live';
  /** Hermes' publish time while it is stale or closed: the backdated price it has nothing newer than. */
  private frozenAt?: bigint;
  breakerMode: BreakerMode = 'follow';
  divergeBps = 500;
  private readonly payerTiers = new Map<string, Tier>();
  readonly c: {
    priceSource?: Address; breaker?: Address; nodeRewards?: Address; splitter?: Address; treasury?: Address;
    stata?: Address; yieldVault?: Address; adapter?: Address; keeperGate?: Address;
  } = {};
  private refs: { reserve?: Address; movva?: Address; usdt?: Address; registry?: Address; lp?: Address; pyth?: Address; fx?: Address; usdBrlId?: Hex } = {};
  private readonly services: Service[] = [];
  private hermes?: { url: string; server: Server };
  private lastSplit = 0;
  private readonly keeperKeys = { vault: generatePrivateKey(), pyth: generatePrivateKey() };

  constructor(private readonly x: ExtrasContext, fxE6: bigint) {
    this.fxE6 = fxE6;
  }

  private a(name: string, file?: string) { return this.x.ours(name, file); }

  /** The breaker, before the reserve: its source set to the rate the reserve is about to price at. */
  async deployBreaker(): Promise<Address> {
    const SRC = this.a('MockPriceSource', 'MovvaBreaker.t.sol');
    this.c.priceSource = await this.x.deploy(SRC);
    await this.x.send(this.x.funder, this.c.priceSource, SRC.abi, 'set', [this.fxE6 * 10n ** 12n]);
    this.c.breaker = await this.x.deploy(this.a('DivergenceBreaker'), [BREAKER_BAND_BPS, true, [{ source: this.c.priceSource, trips: true }]]);
    return this.c.breaker;
  }

  /**
   * Before the reserve's setup closes: NodeRewards and the FeeSplitter as the fee recipient, and the yield vault behind
   * its gate. Each contract's own setup closes here; the reserve's is the caller's.
   */
  async wireReserve(p: { reserve: Address; movva: Address; usdt: Address; treasury: Address; delay: bigint }): Promise<void> {
    const { gov } = this.x;
    const g = gov.account.address;
    Object.assign(this.refs, { reserve: p.reserve, movva: p.movva, usdt: p.usdt });
    const RES = this.a('MovvaReserve');
    const NR = this.a('NodeRewards');
    const SPLIT = this.a('FeeSplitter');
    const VAULT = this.a('YieldVault');
    const GATE = this.a('KeeperGate');
    const GOVERNED = this.a('DelayedGovernance');

    this.c.treasury = p.treasury;
    this.c.nodeRewards = await this.x.deploy(NR, [p.movva, MOVVA_PER_CENT, DAY, DAY, g, p.delay]);
    this.c.splitter = await this.x.deploy(SPLIT, [p.movva, p.treasury, this.c.nodeRewards, g, p.delay]);
    await this.x.send(gov, p.reserve, RES.abi, 'setFeeRecipient', [this.c.splitter]);
    await this.x.send(gov, this.c.splitter, SPLIT.abi, 'setLpRewardShare', [LP_REWARD_SHARE_BPS]);
    for (const c of [this.c.splitter, this.c.nodeRewards]) await this.x.send(gov, c, GOVERNED.abi, 'completeSetup');

    this.c.stata = await this.x.deploy(this.a('StataLike', 'ERC4626Adapter.t.sol'), [p.usdt]);
    // The keeper is the gate; the governor stands in until the gate exists. Guardian: the governor, as the stack's reserve has.
    this.c.yieldVault = await this.x.deploy(VAULT, [p.usdt, 'Shielded Yield USDT', 'syUSDT', g, g, g, 10n ** 15n, 100, p.delay]);
    this.c.adapter = await this.x.deploy(this.a('ERC4626Adapter'), [this.c.yieldVault, this.c.stata, 'Aave v3 USDT (StataLike)']);
    // The whole vault's assets a day: the tests' 10% would leave most of the first deposit idle for days.
    this.c.keeperGate = await this.x.deploy(GATE, [this.c.yieldVault, g, p.delay, 10_000]);
    await this.x.send(gov, this.c.yieldVault, VAULT.abi, 'addAdapter', [this.c.adapter, 10_000]);
    await this.x.send(gov, this.c.yieldVault, VAULT.abi, 'setKeeper', [this.c.keeperGate]);
    await this.x.send(gov, this.c.keeperGate, GATE.abi, 'setOperator', [privateKeyToAccount(this.keeperKeys.vault).address, true]);
    await this.x.send(gov, this.c.yieldVault, GOVERNED.abi, 'completeSetup');
    await this.x.send(gov, this.c.keeperGate, GOVERNED.abi, 'completeSetup');
    await this.x.send(gov, p.reserve, RES.abi, 'setYieldVault', [this.c.yieldVault]);
  }

  /** Before the registry's setup closes: NodeRewards as its rewards hook (delayed afterwards). */
  async hookRegistry(registry: Address): Promise<void> {
    this.refs.registry = registry;
    await this.x.send(this.x.gov, registry, this.a('LPRegistry').abi, 'setRewardsHook', [this.c.nodeRewards]);
  }

  /** After: NodeRewards bound to the registry, at once while it holds nothing. */
  async bindRegistry(registry: Address): Promise<void> {
    await this.x.send(this.x.gov, this.c.nodeRewards!, this.a('NodeRewards').abi, 'setRegistry', [registry]);
  }

  /** The LP node's caps and rewards. */
  lpNodeOptions(lp: Address, registry: Address): { caps: CapsOptions; rewards: RewardsOptions } {
    this.refs.lp = lp;
    const tiers = Object.fromEntries(Object.entries(TIER_DAILY_CENTS).map(([t, d]) => [t, { dailyBrlCents: d }])) as CapsOptions['tiers'];
    return {
      caps: {
        tiers, defaultTier: DEFAULT_TIER, unknownPayer: 'refuse',
        tierSource: { tierOf: (f) => (f.payerId ? this.payerTiers.get(f.payerId) : undefined) },
      },
      rewards: { contract: this.c.nodeRewards!, registry, claim: true, minClaim: 0n, lookbackEpochs: 12 },
    };
  }

  /** The co-signer's FROST share store: with it, the co-signer serves /v1/frost/* (DKG, commit, sign). */
  cosignerEnv(data: (name: string) => string): Record<string, string> {
    return { COSIGNER_FROST_SHARES_FILE: data('frost-shares.json') };
  }

  /*------------------------------ services ------------------------------*/

  private dir(): string {
    const d = join(this.x.work, 'extras');
    mkdirSync(d, { recursive: true, mode: 0o700 });
    return d;
  }

  private async spawnService(s: { name: string; script: string; env: Record<string, string>; readyUrl: string; loopback?: boolean; port?: number; opsPort?: number; address?: Address }): Promise<Service> {
    const log = join(this.dir(), `${s.name}.log`);
    const out = openSync(log, 'a');
    const loopback = join(this.x.root, 'packages/app/scripts/dev-stack-loopback.mjs');
    const child = spawn(process.execPath, ['--import', 'tsx', ...(s.loopback ? ['--import', loopback] : []), join(this.x.root, s.script)], {
      cwd: this.x.root, stdio: ['ignore', out, out], env: { PATH: process.env.PATH ?? '', HOME: process.env.HOME ?? '', ...s.env },
    });
    this.x.stops.push(() => new Promise<void>((done) => {
      if (child.exitCode !== null) return done();
      child.once('exit', () => done());
      child.kill('SIGTERM');
      setTimeout(done, 5_000);
    }));
    for (let i = 0; ; i++) {
      if (child.exitCode !== null) throw new Error(`${s.name} exited (${child.exitCode}): ${readFileSync(log, 'utf8').slice(-800)}`);
      if (await fetch(s.readyUrl).then((r) => r.status === 200, () => false)) break;
      if (i > 300) throw new Error(`${s.name} did not become ready within 90 s (log: ${log})`);
      await new Promise((r) => setTimeout(r, 300));
    }
    const svc: Service = { name: s.name, port: s.port, opsPort: s.opsPort, log, child, address: s.address };
    this.services.push(svc);
    return svc;
  }

  private writeSecret(name: string, content: string): string {
    const file = join(this.dir(), name);
    writeFileSync(file, content, { mode: 0o600 });
    chmodSync(file, 0o600);
    return file;
  }

  /** Hermes as this stack plays it, then the two keepers. */
  async startKeepers(p: { fx: Address; pyth: Address; usdBrlId: Hex; freePort: () => Promise<number> }): Promise<void> {
    Object.assign(this.refs, { fx: p.fx, pyth: p.pyth, usdBrlId: p.usdBrlId });
    for (const k of Object.values(this.keeperKeys)) await this.x.fund(this.x.funder, privateKeyToAccount(k).address, parseEther('10'));
    await this.startHermes(p.usdBrlId);
    const rpc = this.x.rpc;
    const port = async () => p.freePort();
    const pythPort = await port();
    await this.spawnService({
      name: 'pyth-keeper', script: 'packages/yield/src/bin/pyth-keeper.ts', loopback: true, port: pythPort, address: privateKeyToAccount(this.keeperKeys.pyth).address,
      env: {
        RPC_URL: rpc, PYTH_FX_ORACLE: p.fx, KEEPER_KEY: this.keeperKeys.pyth, HERMES_URL: this.hermes!.url,
        REFRESH_SECONDS: '60', CLOSED_POLL_SECONDS: '30', INTERVAL_MS: '10000', PORT: String(pythPort),
      },
      readyUrl: `http://${this.x.host}:${pythPort}/readyz`,
    });
    const vaultPort = await port();
    await this.spawnService({
      name: 'vault-keeper', script: 'packages/yield/src/bin/vault-keeper.ts', loopback: true, port: vaultPort, address: privateKeyToAccount(this.keeperKeys.vault).address,
      env: {
        RPC_URL: rpc, VAULT: this.c.yieldVault!, KEEPER_GATE: this.c.keeperGate!, KEEPER_KEY: this.keeperKeys.vault, WEIGHTS: `${this.c.adapter}:1`,
        MIN_MOVE: String(1n * U), INTERVAL_MS: '15000', PORT: String(vaultPort),
      },
      readyUrl: `http://${this.x.host}:${vaultPort}/readyz`,
    });
  }

  private chainNow = async (): Promise<bigint> => (await this.x.pub.getBlock()).timestamp;

  /** /v2/updates/price/latest and /v2/price_feeds, as Hermes answers them, over MockPyth's update encoding. */
  private async startHermes(id: Hex): Promise<void> {
    const bare = id.slice(2).toLowerCase();
    const server = createServer((rq, rs) => {
      void (async () => {
        const url = new URL(rq.url ?? '/', 'http://hermes');
        const json = (status: number, body: unknown) => { rs.writeHead(status, { 'content-type': 'application/json' }); rs.end(JSON.stringify(body)); };
        try {
          if (url.pathname === '/v2/updates/price/latest') {
            const t = this.frozenAt ?? await this.chainNow();
            const data = encodeAbiParameters(
              [{ type: 'bytes32' }, { type: 'int64' }, { type: 'uint64' }, { type: 'int32' }, { type: 'uint256' }],
              [id, this.fxE6, 100n, -6, t],
            );
            return json(200, {
              binary: { encoding: 'hex', data: [data.slice(2)] },
              parsed: [{ id: bare, price: { price: this.fxE6.toString(), conf: '100', expo: -6, publish_time: Number(t) } }],
            });
          }
          if (url.pathname === '/v2/price_feeds') {
            return json(200, [{ id: bare, attributes: { asset_type: 'FX', base: 'USD', quote_currency: 'BRL' }, market_hours: { is_open: this.fxMode !== 'closed' } }]);
          }
          return json(404, { error: 'not found' });
        } catch (e) {
          return json(500, { error: e instanceof Error ? e.message : String(e) });
        }
      })();
    });
    await new Promise<void>((res, rej) => { server.once('error', rej); server.listen(0, this.x.host, () => res()); });
    const { port } = server.address() as { port: number };
    this.hermes = { url: `http://${this.x.host}:${port}`, server };
    this.x.stops.push(() => new Promise<void>((r) => { server.close(() => r()); server.closeAllConnections(); }));
  }

  /*------------------------------ the stack's own part ------------------------------*/

  /** The rate the reserve prices at now, at 1e18: the chain's Pyth price (the USDT/USD leg is held at 1.00). */
  private async onChainRateE18(): Promise<bigint> {
    const p = await this.x.read<{ price: bigint; expo: number }>(this.refs.pyth!, PYTH_READ_ABI, 'getPriceUnsafe', [this.refs.usdBrlId!]);
    return BigInt(p.price) * 10n ** BigInt(18 + p.expo);
  }

  /** Every few seconds: the breaker's source where its mode puts it, and the splitter's fees forwarded once a minute. */
  async tick(): Promise<void> {
    await this.syncBreaker();
    if (Date.now() - this.lastSplit >= 60_000) {
      this.lastSplit = Date.now();
      const held = await this.x.read<bigint>(this.refs.movva!, ERC20_ABI, 'balanceOf', [this.c.splitter!]);
      if (held > 0n) await this.x.send(this.x.funder, this.c.splitter!, this.a('FeeSplitter').abi, 'split');
    }
  }

  private async syncBreaker(): Promise<void> {
    const SRC = this.a('MockPriceSource', 'MovvaBreaker.t.sol');
    const [rate, down] = await Promise.all([
      this.x.read<bigint>(this.c.priceSource!, SRC.abi, 'rate'), this.x.read<boolean>(this.c.priceSource!, SRC.abi, 'down'),
    ]);
    if (this.breakerMode === 'fail') {
      if (!down) await this.x.send(this.x.funder, this.c.priceSource!, SRC.abi, 'fail');
      return;
    }
    const base = await this.onChainRateE18();
    const want = this.breakerMode === 'diverge' ? (base * (BPS + BigInt(this.divergeBps))) / BPS : base;
    if (down || rate !== want) await this.x.send(this.x.funder, this.c.priceSource!, SRC.abi, 'set', [want]);
  }

  /** Stale or closed: the chain's price backdated past maxAge, and Hermes with nothing newer. Live: Hermes current again. */
  private async setFx(mode: FxMode): Promise<void> {
    if (mode === 'live') {
      this.frozenAt = undefined;
    } else {
      const at = (await this.chainNow()) - FX_MAX_AGE - 1n;
      this.frozenAt = at;
      await this.x.send(this.x.funder, this.refs.pyth!, PYTH_READ_ABI, 'set', [this.refs.usdBrlId!, this.fxE6, 100n, -6, at]);
    }
    this.fxMode = mode;
  }

  /*------------------------------ dev API ------------------------------*/

  /** /api/dev/extras/*: the state, and the switches. */
  async dev(method: string, path: string, body: () => Promise<Record<string, unknown>>): Promise<unknown> {
    if (method === 'GET' && (path === '' || path === '/')) return this.status();
    if (method !== 'POST') throw new ExtrasError(404, 'not found');
    const b = await body();
    if (path === '/fx') {
      if (b.rateE6 !== undefined) {
        const r = typeof b.rateE6 === 'string' && /^\d+$/.test(b.rateE6) ? BigInt(b.rateE6) : undefined;
        if (r === undefined || r < 1_000_000n || r > 100_000_000n) throw new ExtrasError(400, 'rateE6 is reais per dollar at 1e-6, as a string, R$ 1,00 to R$ 100,00');
        this.fxE6 = r;
      }
      if (b.mode !== undefined) {
        if (b.mode !== 'live' && b.mode !== 'stale' && b.mode !== 'closed') throw new ExtrasError(400, 'mode is live, stale or closed');
        await this.setFx(b.mode);
      }
      this.x.log(`extras: FX ${this.fxMode} at ${this.fxE6} (1e-6)`);
      return this.status();
    }
    if (path === '/breaker') {
      if (b.mode !== 'follow' && b.mode !== 'diverge' && b.mode !== 'fail') throw new ExtrasError(400, 'mode is follow, diverge or fail');
      if (b.bps !== undefined) {
        if (typeof b.bps !== 'number' || !Number.isInteger(b.bps) || b.bps < -5_000 || b.bps > 5_000) throw new ExtrasError(400, 'bps is an integer, -5000 to 5000');
        this.divergeBps = b.bps;
      }
      this.breakerMode = b.mode;
      await this.syncBreaker();
      this.x.log(`extras: breaker source ${this.breakerMode}${this.breakerMode === 'diverge' ? ` ${this.divergeBps} bps` : ''}`);
      return this.status();
    }
    if (path === '/yield/earn') {
      const v = typeof b.usdt === 'string' && /^\d+$/.test(b.usdt) ? BigInt(b.usdt) : undefined;
      if (v === undefined || v === 0n || v > 1_000_000n) throw new ExtrasError(400, 'usdt is whole USDT, as a string, 1 to 1000000');
      await this.x.send(this.x.funder, this.c.stata!, this.a('StataLike', 'ERC4626Adapter.t.sol').abi, 'earn', [this.refs.usdt!, v * U]);
      this.x.log(`extras: the stata wrapper earned ${v} USDT`);
      return this.status();
    }
    if (path === '/split') {
      const r = await this.x.send(this.x.funder, this.c.splitter!, this.a('FeeSplitter').abi, 'split');
      this.lastSplit = Date.now();
      return { transactionHash: r.transactionHash };
    }
    if (path === '/payer-tier') {
      if (typeof b.payerId !== 'string' || !/^(\d{11}|\d{14})$/.test(b.payerId)) throw new ExtrasError(400, 'payerId is a CPF (11 digits) or CNPJ (14)');
      if (b.tier === null) this.payerTiers.delete(b.payerId);
      else if (typeof b.tier === 'number' && b.tier in TIER_DAILY_CENTS) this.payerTiers.set(b.payerId, b.tier as Tier);
      else throw new ExtrasError(400, 'tier is 0 to 4, or null for the default');
      return { payerTiers: Object.fromEntries(this.payerTiers) };
    }
    throw new ExtrasError(404, 'not found');
  }

  /** What the console shows: every extra's contracts as the chain reads now, and each service's own /status. */
  async status(): Promise<Record<string, unknown>> {
    // Every contract's errors with every read: the reserve bubbles the oracle's and the breaker's up unchanged.
    const errors = ['PythFxOracle', 'DivergenceBreaker', 'MovvaReserve', 'YieldVault', 'NodeRewards']
      .flatMap((n) => this.a(n).abi.filter((x) => x.type === 'error'));
    const r = <T>(address: Address, abi: Abi, fn: string, args: unknown[] = []) => attempt(() => this.x.read<T>(address, [...abi, ...errors], fn, args));
    const RES = this.a('MovvaReserve').abi;
    const NR = this.a('NodeRewards').abi;
    const SPLIT = this.a('FeeSplitter').abi;
    const VAULT = this.a('YieldVault').abi;
    const GATE = this.a('KeeperGate').abi;
    const ADAPTER = this.a('ERC4626Adapter').abi;
    const BRK = this.a('DivergenceBreaker').abi;
    const { reserve, movva, usdt, lp, fx, pyth, usdBrlId } = this.refs;
    const c = this.c;
    const epoch = await r<bigint>(c.nodeRewards!, NR, 'currentEpoch');
    const e = typeof epoch === 'bigint' ? epoch : 0n;
    const services = await Promise.all(this.services.map(async (s) => {
      const statusPort = s.opsPort ?? s.port;
      const st = statusPort ? await fetch(`http://${this.x.host}:${statusPort}/status`, { signal: AbortSignal.timeout(3_000) }).then((x) => x.json(), () => undefined) : undefined;
      return { name: s.name, port: s.port, opsPort: s.opsPort, address: s.address, running: s.child.exitCode === null, exitCode: s.child.exitCode, log: s.log, status: st };
    }));
    return {
      enabled: true,
      contracts: { ...c },
      chainTime: (await this.chainNow()).toString(),
      fx: {
        mode: this.fxMode, rateE6: this.fxE6.toString(), hermes: this.hermes?.url, hermesFrozenAt: this.frozenAt?.toString() ?? null, maxAge: FX_MAX_AGE.toString(),
        onChain: await r(pyth!, PYTH_READ_ABI, 'getPriceUnsafe', [usdBrlId!]),
        oracleRate: await r(fx!, FX_ORACLE_ABI, 'brlCentsPerUnit'),
        inCoreSession: await r(fx!, FX_ORACLE_ABI, 'inCoreSession'),
      },
      breaker: {
        address: c.breaker, source: c.priceSource, bandBps: BREAKER_BAND_BPS, haltsRedeem: true, mode: this.breakerMode, divergeBps: this.divergeBps,
        sourceRates: await r(c.breaker!, BRK, 'sourceRates'),
        reserveRate: await r(reserve!, RES, 'brlPerUsdtE18'),
        tripped: await r(reserve!, RES, 'breakerTripped'),
      },
      yield: {
        vault: c.yieldVault, adapter: c.adapter, gate: c.keeperGate, stata: c.stata,
        reserveVault: await r(reserve!, RES, 'yieldVault'),
        reserveTotalUsdt: await r(reserve!, RES, 'totalUsdt'),
        reserveIdleUsdt: await r(usdt!, ERC20_ABI, 'balanceOf', [reserve!]),
        reserveShares: await r(c.yieldVault!, ERC20_ABI, 'balanceOf', [reserve!]),
        vaultTotalAssets: await r(c.yieldVault!, VAULT, 'totalAssets'),
        vaultIdle: await r(usdt!, ERC20_ABI, 'balanceOf', [c.yieldVault!]),
        adapterValue: await r(c.adapter!, ADAPTER, 'totalValue'),
        assetsPerShare: await r(c.yieldVault!, VAULT, 'assetsPerShare'),
        depositsPaused: await r(c.yieldVault!, VAULT, 'depositsPaused'),
        remainingTurnover: await r(c.keeperGate!, GATE, 'remainingTurnover'),
      },
      fees: {
        splitter: c.splitter, nodeRewards: c.nodeRewards, treasury: c.treasury, lpRewardShareBps: LP_REWARD_SHARE_BPS,
        splitterHeld: await r(movva!, ERC20_ABI, 'balanceOf', [c.splitter!]),
        treasuryBalance: await r(movva!, ERC20_ABI, 'balanceOf', [c.treasury!]),
        rewardsBalance: await r(movva!, ERC20_ABI, 'balanceOf', [c.nodeRewards!]),
        rewardsRegistry: await r(c.nodeRewards!, NR, 'registry'),
        currentEpoch: epoch, epochEnd: await r(c.nodeRewards!, NR, 'epochEnd', [e]), finalizableAt: await r(c.nodeRewards!, NR, 'finalizableAt', [e]),
        epochLength: DAY.toString(), reviewPeriod: DAY.toString(),
        lpVolumeCents: lp ? await r(c.nodeRewards!, NR, 'volumeOf', [e, lp]) : null,
        epochs: await r(c.nodeRewards!, NR, 'epochs', [e]),
        totalFunded: await r(c.nodeRewards!, NR, 'totalFunded'), totalClaimed: await r(c.nodeRewards!, NR, 'totalClaimed'),
        lpClaimable: lp ? await r(c.nodeRewards!, NR, 'claimableIn', [lp, 0n, 104n]) : null,
      },
      reserve: {
        collateralRatioBps: await r(reserve!, RES, 'collateralRatioBps'),
        movvaSupply: await r(movva!, ERC20_ABI, 'totalSupply'),
      },
      caps: {
        tierDailyCents: Object.fromEntries(Object.entries(TIER_DAILY_CENTS).map(([t, v]) => [t, v.toString()])),
        defaultTier: DEFAULT_TIER, payerTiers: Object.fromEntries(this.payerTiers),
        note: "one combined daily total per payer (both directions), Rev. 3 §12.1's outbound figures",
      },
      frost: { sharesFile: 'the co-signer\'s frost-shares.json', endpoints: ['/v1/frost/dkg/start', '/v1/frost/dkg/round2', '/v1/frost/dkg/confirm', '/v1/frost/commit', '/v1/frost/sign'] },
      services,
    };
  }

  /** For /api/dev/services. */
  describeServices(): { name: string; port?: number; opsPort?: number; address?: Address; running: boolean; log: string }[] {
    return this.services.map((s) => ({ name: s.name, port: s.port, opsPort: s.opsPort, address: s.address, running: s.child.exitCode === null, log: s.log }));
  }

  get treasury(): Address | undefined { return this.c.treasury; }
}

