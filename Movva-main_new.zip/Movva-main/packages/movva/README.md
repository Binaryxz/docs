# @mova/movva

The issuer's hedge desk and reserve reporting for Movva, the BRL-pegged token backed by a USDT
reserve (docs/movva.md). The chain can see the reserve; it cannot see the short USD/BRL position
the issuer holds on B3 to turn that dollar reserve into a real one. This package makes the off-chain
half of the peg **correct** (the hedge and treasury arithmetic, in bigints) and **verifiable**
(signed, chained statements anyone can check against the reserve with an address and an RPC).

It holds no treasury key and sends no transaction. The only key it can read is the statement key,
and only `statement sign` reads it.

The reserve is **principal-locked** (client rule, 21 October 2026): its USDT leaves only by redemption
(the off-ramp's LPs, the gateways) and, above `max(principalUsdt, liabilities at the target ratio)`, by
`harvestYield` to the fixed `yieldRecipient`, Mova's Safe. There is no hedge withdrawal: the short's
margin is Mova's own capital, through its hedge Safe, never the reserve's. Hedge gains Mova brings back
come in by `recapitalize`, and become principal. The desk plans exactly those two treasury actions.

```
   IMovvaReserve (chain)                        broker statement (B3 positions, margin)
          │ reserve.ts: snapshot at one block             │ transcribed to positions.json, hashed
          ▼                                                ▼
   ┌──────────────┐   hedge.ts: target, ratio, orders,   ┌───────────────┐
   │  snapshot    │──▶ shocks, carry ◀────────────────────│  positions    │
   └──────┬───────┘                                       └──────┬────────┘
          │ treasury.ts: harvestYield / recapitalize             │ statement.ts: EIP-712, signed,
          │ plans → calldata / Safe batch (multisig signs)       │ chained, snapshot-bound
          ▼                                                      ▼
   report.ts: reserve ratio · hedge ratio · backing if the hedge holds  → JSON + text, published
          │
          ▼  @mova/ops monitor: movva_collateral_ratio, movva_rate, movva_hedge_statement, ...
```

## Modules

| File | What it does |
|---|---|
| `abi.ts` | `IMovvaReserve` transcribed (every function and event), plus the oracle-leg errors a stale rate bubbles up, and `MOVVA_RESERVE_EXTRA_ABI`: the breaker and the refusals a harvest or a recapitalization can meet. `test/abi.test.ts` checks it against the compiled interface and reserve, and that no hedge-withdrawal function is left. |
| `units.ts` | Bigint fixed point: rounding that states its direction (a limit rounds toward safety, a shock toward zero so ±m are exact opposites), strict decimal parsing, display formatting. No floats touch money. |
| `reserve.ts` | `readReserveSnapshot`: every figure at one pinned block, with its hash; a stale rate is an `UnpricedSnapshot` naming the revert, not an exception; the reserve's derived figures are recomputed and any disagreement listed - `harvestableYield()` included, against the formula. The principal, the yield recipient and the harvestable yield ride in `snapshot.yield`. |
| `hedge.ts` | Instruments (B3 DOL US$ 50,000, WDO US$ 10,000 - **confirm with the broker**), hedge ratio, `planHedge` (integer contracts, a ±band, never under the band floor), `shock` (the margin call against free margin, the rest Mova's own capital - the reserve pays none; recapitalization vs hedge cash), `recommendFreeMargin`, `carry`, PTAX 2024 preset. |
| `treasury.ts` | `planHarvestYield` (what is above the floor, which leg binds, what a rate `executionBufferBps` lower leaves, a warning when the reserve pays another recipient than expected; `simulateHarvest`), `planRecapitalize` (amount to the target after an execution buffer; it becomes principal): unsigned calldata and a Safe Transaction Builder batch. Refuses rather than trims. |
| `statement.ts` | The signed hedge statement: build, sign, publish as JSON, parse, verify (signature and domain, hash, arithmetic, chain link, freshness, snapshot against the chain). |
| `statement-store.ts` | One file per sequence, created exclusively and fsynced, plus an atomically replaced `latest.json` to publish. Refuses a fork, a gap and an overwrite. |
| `report.ts` | The backing report (JSON and text): reserve ratio, hedge ratio, backing if the hedge holds, and what none of them covers. |
| `config.ts` | Environment and JSON policy, secrets redacted. |
| `bin/movva-desk.ts` | The CLI. |
| `server.ts`, `bin/movva-desk-serve.ts` | The HTTP server for the web UI: `runDesk` per request, read-only and planning. |

## The statement

EIP-712, domain `{ name: "Movva Hedge Statement", version: "1", chainId, verifyingContract: <reserve> }`:

```
HedgeStatement(address issuer, uint64 sequence, uint64 asOf,
               uint64 reserveBlock, bytes32 reserveBlockHash, uint256 reserveBrlPerUsdtE18, uint256 reserveLiabilitiesUsdt,
               Position[] positions, int256 netShortUsdE6,
               int256 marginBalanceBrlCents, uint256 marginRequiredBrlCents,
               bytes32 brokerStatementSha256, bytes32 previousStatementHash)
Position(string instrument, string ticker, string expiry, string side,
         uint256 contracts, uint256 contractSizeUsd, uint256 averagePriceBrlPerUsdE6)
```

- The snapshot **figures** are signed, not only the block: a verifier with an archive node checks
  the reserve really had that rate and those liabilities at that block (and that block's hash).
- `netShortUsdE6` must equal the positions' sum; `marginBalanceBrlCents` is signed because a debit
  balance must be reportable.
- `previousStatementHash` is the EIP-712 hash of the previous statement (zero for sequence 1). A
  rewritten statement changes its hash and every later statement stops linking to it.
- Published as `{ "format": "movva-hedge-statement/v1", "domain", "message", "hash", "signature" }`
  with every integer a decimal string.

What a signature proves is **who** said it, not that it is **true**: positions and margin are the
issuer's claim, bound to the broker's document by SHA-256 for an auditor holding that document.

### Verifying a statement as a third party

```
RPC_URL=https://<archive node> MOVVA_RESERVE=0x… MOVVA_STATEMENT_ISSUER=0x<statement key address> \
  node --import tsx packages/movva/src/bin/movva-desk.ts statement verify latest.json --previous statement-000000000041.json
```

Exit 0 and `"valid": true` only when every check ran and passed; a snapshot that could not be read
is `unverifiable`, never assumed fine.

## CLI

```
RPC_URL=… MOVVA_RESERVE=0x… MOVVA_DESK_CONFIG=desk.json MOVVA_STATEMENT_DIR=/srv/movva/statements \
MOVVA_STATEMENT_ISSUER=0x… node --import tsx packages/movva/src/bin/movva-desk.ts <command>

snapshot        [--block N]                                    the reserve at one block
hedge-plan      [--positions F | --statement F] [--text]       orders to bring the hedge inside the band
shock           [--move 500,-500] [--stress BPS] [...] [--text] default: ±5%, ±10%, 2024 both ways
harvest-plan    [--from SENDER] [--safe]                       harvestYield (anyone may send); exits 3 when nothing
recap-plan      [--amount USDT] [--target-bps N] [--from SENDER] [--safe]
statement sign  --positions F --broker-doc F --margin-balance BRL --margin-required BRL [--as-of UNIX]
statement verify [F] [--previous F]                            exits 1 when not valid
report          [--statement F] [--text] [--out F]
```

`--snapshot F` (a saved `snapshot`) replaces the chain for planning, so plans can be made and
re-checked offline; `examples/` has three example reserves (at the target, at 103%, and at 120% with
yield above its principal), a positions file and a desk policy:

```
MOVVA_DESK_CONFIG=packages/movva/examples/desk.json node --import tsx packages/movva/src/bin/movva-desk.ts \
  shock --snapshot packages/movva/examples/reserve-at-target.json --positions packages/movva/examples/positions.json --text
```

Environment: `RPC_URL` (secret: carries the provider key), `CHAIN_ID` (checked against the RPC;
required offline for signing), `MOVVA_RESERVE`, `MOVVA_STATEMENT_ISSUER`, `MOVVA_STATEMENT_DIR`,
`MOVVA_DESK_CONFIG`, `MOVVA_STATEMENT_KEY_FILE` (preferred) or `MOVVA_STATEMENT_KEY`. Everything
printed is passed through `@mova/ops` `redact` with RPC_URL, the key and every secret-shaped variable.

Policy (`MOVVA_DESK_CONFIG`, all optional): `reserve`, `issuer`, `yieldRecipient` (the Safe a harvest is
expected to pay), `instruments` (`[{symbol, contractSizeUsd}]`), `tickers`, `hedgeBandBps` (200), `rollWithinDays`
(5), `executionBufferBps` (50), `stressMoveBps` (1000),
`initialMarginBps` (1000 - an assumption, to confirm), `conversionCostBps` (30), `statementMaxAgeSeconds`
(93600), `statementDir`. `hedgeTreasury`, `treasurer` and `withdrawDailyLimitBps` are refused by name: they
configured the reserve's hedge withdrawal, which no longer exists.

## Web UI

`src/server.ts` is the desk's HTTP surface for the desk UI, `mova-frontend`, which lives beside this
monorepo (`../mova-frontend`, outside the repository): read-only and planning, every route a
`runDesk` call in-process, no signing route and no statement key in its environment. Same variables as the CLI, plus
`MOVVA_DESK_HOST` (127.0.0.1), `MOVVA_DESK_PORT` (8990), `MOVVA_DESK_SNAPSHOT` (plan offline from a saved snapshot),
`MOVVA_DESK_POSITIONS` (positions to use while the store is empty) and `MOVVA_DESK_UI_DIR` (default `../mova-frontend/dist`):

```
(cd ../mova-frontend && npm install && npm run build)
RPC_URL=… MOVVA_RESERVE=0x… MOVVA_DESK_CONFIG=desk.json MOVVA_STATEMENT_DIR=… MOVVA_STATEMENT_ISSUER=0x… \
  npm run serve -w @mova/movva                       # http://127.0.0.1:8990
```

See `../mova-frontend/README.md`.

## Harvesting the yield

The reserve's USDT is invested in its ERC-4626 yield vault. `principalUsdt` is its cost basis - USDT in
through `mint` and `recapitalize`, less USDT out through `redeem` - and `harvestYield()` pays the yield
recipient only what is above

    max(principalUsdt, ceil(liabilities x targetCollateralRatioBps x 1e6 / (rate x 1e4)))

so the yield never leaves while holders are under-backed or the reserve is below its target. Anyone may
send it; it can pay no one else. `harvest-plan` reads the reserve's own `harvestableYield()`, checks it
against that formula, says which leg of the floor binds, and warns when a rate `executionBufferBps` lower
would leave less (the reserve pays what is above the floor when it executes, never more). It halts, as the
reserve does, while the rate is stale or the divergence breaker is tripped.

The reserve's refusals a simulation can meet (`NothingToHarvest`, `FrozenByAssetIssuer`, `SourcesDiverge`,
...) are in `MOVVA_RESERVE_EXTRA_ABI` (abi.ts), so a revert names its reason; `test/abi.test.ts` checks each
against the compiled `MovvaReserve` and `DivergenceBreaker`.

The hedge-withdrawal commands (`withdraw-plan`, `hedge-queue`, `queue-plan`, `execute-plan`) and their HTTP
routes were removed with the reserve's hedge path on 21 October 2026.

## Off-hours

The reserve's FX leg is Pyth's FX.USD/BRL (`PythFxOracle`), which trades weekdays 08:00-17:00 New York
time. Every weekday night and weekend the reserve's rate (`brlPerUsdtE18`) refuses (`StaleRate`), by
design: minting and redeeming wait for the market. The desk follows the same line. `snapshot` shows the
refusal and, beside it, `bandBrlPerUsdtE18` - the last close, as the ramps' band reads it. `report` prices at
that close and labels it (`rateSource: "band"`, and in words in `--text`). Everything that sizes a hedge,
moves USDT or signs a statement - `hedge-plan`, `shock`, `harvest-plan`, `recap-plan`, `statement sign` -
prices at the live rate only and refuses until the market reopens, saying so.

## Facts this package could not verify

Marked in code and docs as "to confirm":

- **With the broker**: that DOL and WDO are US$ 50,000 and US$ 10,000 per contract for this account
  (B3's product pages say so, read 14 September 2026), DOL's standard lot of 5, margin (B3's model
  plus the broker's add-on - the 10% default is a placeholder), fees and exchange charges, when
  daily settlement is debited, position limits, last trading day handling, and tax treatment.
- **Against the deployed reserve**: what `totalUsdt` counts (the vault position at `previewRedeem`), and the
  yield vault's liquidity when a harvest pulls from it.
- **Operationally**: the USDT/BRL conversion cost (30 bps default) and how long a conversion and a
  B3 margin deposit take.

Verified: B3 contract sizes, quote convention (reais per US$ 1,000), tick (R$ 0,50), expiry (first
business day of the month) and cash settlement from B3's DOL and WDO product pages; PTAX venda
R$ 4,8413 (29/12/2023) and R$ 6,1923 (31/12/2024) from the BCB PTAX service.

## What IMovvaReserve does not expose, and the workarounds

| Would add | Why | Workaround here |
|---|---|---|
| Custom errors declared in the interface (`StaleRate`, `NothingToHarvest`, …) | So tools decode refusals without the implementation's ABI | Oracle-leg errors listed; the reserve's in `MOVVA_RESERVE_EXTRA_ABI` |
| `idleUsdt()` (and the vault position) | How much of a harvest needs a vault exit | `USDT.balanceOf(reserve)` |
| `rateMaxAge()` per leg, or the leg timestamps separately | The monitor's warn threshold should sit inside the real one | Thresholds from docs/movva.md (FX 1h) |
| `Recapitalized`/`YieldHarvested` carrying the rate | Reconstruct the ratio history without archive reads | Archive reads |

## Tests

```
npx vitest run packages/movva
```

`test/abi.test.ts` compares the ABI with the compiled interface when a build exists. To run it
without touching the repository's `forge-out`:

```
FOUNDRY_OUT=/tmp/forge-movva/out FOUNDRY_CACHE_PATH=/tmp/forge-movva/cache forge build contracts/movva/IMovvaReserve.sol
MOVVA_FORGE_OUT=/tmp/forge-movva/out npx vitest run packages/movva/test/abi.test.ts
```

`test/hedge-properties.test.ts` (fast-check): hedge ratio bounds, rebalancing never under the band
floor and inside it whenever a contract fits, re-planning is stable, shocks are exactly symmetric,
a fully hedged reserve at 100% nets to zero, the reserve never pays margin, and the recommended free
margin is exactly the call. `test/monitor-compat.test.ts` keeps the monitor's transcription of the statement
format identical to this package's.
