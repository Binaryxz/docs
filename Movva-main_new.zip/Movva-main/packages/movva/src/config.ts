/**
 * Desk configuration: secrets and addresses from the environment, policy from a JSON file.
 *
 * The split packages/lp-node makes, for the same reasons. What the desk TUNES - the hedge band,
 * contract sizes, margin and conversion assumptions - is a document
 * the issuer reviews and versions (`MOVVA_DESK_CONFIG`). What it must PROTECT - the RPC URL, which
 * carries a provider key, and the statement signing key - comes from the environment or a
 * `*_FILE` path, is never written back out, and is redacted from everything the CLI prints.
 *
 * The statement key is read only by `statement sign`, and only then: every other command plans,
 * reads or verifies, and a process that does not need a key should not hold one. There is no
 * treasury key at all - see treasury.ts.
 *
 * Every problem is collected before failing, and messages name the variable or JSON path without
 * echoing its value. Every default that stands for a fact about B3, the broker or the deployed
 * reserve is marked "to confirm" where it is defined (hedge.ts, treasury.ts).
 */
import { getAddress, isAddress, type Address, type Hex } from 'viem';
import { DEFAULT_INSTRUMENTS, DEFAULT_SHOCK_ASSUMPTIONS, DEFAULT_STRESS_MOVE_BPS, type Instrument } from './hedge.js';
import { Fields } from './json.js';
import { DEFAULT_STATEMENT_MAX_AGE_SECONDS } from './statement.js';
import { DEFAULT_EXECUTION_BUFFER_BPS } from './treasury.js';

export type Env = Record<string, string | undefined>;

export class ConfigError extends Error {
  constructor(readonly problems: string[]) {
    super(`configuration is invalid:\n  - ${problems.join('\n  - ')}`);
  }
}

export interface DeskConfig {
  rpcUrl?: string;
  chainId?: number;
  reserve?: Address;
  /** The statement key's address: what statements must be signed by. */
  issuer?: Address;
  /** Mova's Safe the reserve is expected to pay its yield to, for anyone sending a harvest to compare. */
  yieldRecipient?: Address;
  instruments: Instrument[];
  tickers: Record<string, string>;
  hedgeBandBps: number;
  rollWithinDays: number;
  executionBufferBps: number;
  /** The one-day dollar rally standing free margin is sized for (default +10%). */
  stressMoveBps: number;
  initialMarginBps: number;
  conversionCostBps: number;
  statementMaxAgeSeconds: number;
  statementDir?: string;
  /** Every value that must never be printed. */
  secrets: string[];
}

export const DEFAULT_HEDGE_BAND_BPS = 200;

const SECRET_NAME = /(KEY|SECRET|TOKEN|PASSWORD|CREDENTIAL)/i;

export function deskConfigFromEnv(env: Env, readFile: (path: string) => string): DeskConfig {
  const problems: string[] = [];
  const addrEnv = (name: string): Address | undefined => {
    const v = env[name]?.trim();
    if (!v) return undefined;
    if (!isAddress(v, { strict: false })) {
      problems.push(`${name} must be an address`);
      return undefined;
    }
    return getAddress(v);
  };

  const rpcUrl = env.RPC_URL?.trim() || undefined;
  if (rpcUrl && !/^https?:\/\//.test(rpcUrl)) problems.push('RPC_URL must be an http(s) URL');
  let chainId: number | undefined;
  if (env.CHAIN_ID?.trim()) {
    if (!/^\d+$/.test(env.CHAIN_ID.trim())) problems.push('CHAIN_ID must be a positive integer');
    else chainId = Number(env.CHAIN_ID.trim());
  }

  let raw: Record<string, unknown> = {};
  const configPath = env.MOVVA_DESK_CONFIG?.trim();
  if (configPath) {
    try {
      const parsed = JSON.parse(readFile(configPath)) as unknown;
      if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) raw = parsed as Record<string, unknown>;
      else problems.push('MOVVA_DESK_CONFIG must hold a JSON object');
    } catch {
      problems.push('MOVVA_DESK_CONFIG could not be read or is not JSON');
    }
  }
  const f = new Fields();
  const P = 'config';
  const bps = (k: string, fallback: number) => f.int(raw, k, P, fallback, [0, 9_999]);
  // The principal-locked reserve (21 October 2026) has no hedge withdrawal: a policy that still names one would read as
  // configured while meaning nothing, so it is refused by name.
  for (const k of ['hedgeTreasury', 'treasurer', 'withdrawDailyLimitBps']) {
    if (raw[k] !== undefined) {
      f.problems.push(`${P}.${k}: removed with the principal-locked reserve (21 October 2026), which has no hedge withdrawal; `
        + 'hedge margin is Mova\'s own capital. Delete it');
    }
  }

  let instruments = [...DEFAULT_INSTRUMENTS];
  if (raw.instruments !== undefined) {
    instruments = f.arr(raw.instruments, `${P}.instruments`).map((x, i) => {
      const p = `${P}.instruments[${i}]`;
      const o = f.obj(x, p);
      const symbol = f.str(o, 'symbol', p, /^[A-Z0-9]{1,16}$/);
      const size = f.big(o, 'contractSizeUsd', p);
      if (size === 0n) f.problems.push(`${p}.contractSizeUsd must be positive`);
      const known = DEFAULT_INSTRUMENTS.find((d) => d.symbol === symbol);
      return {
        symbol, contractSizeUsd: size,
        source: typeof o.source === 'string' && o.source ? o.source
          : known && known.contractSizeUsd === size ? known.source : 'desk configuration; confirm with the broker',
      };
    });
    if (instruments.length === 0) f.problems.push(`${P}.instruments must list at least one instrument`);
  }
  const tickers: Record<string, string> = {};
  if (raw.tickers !== undefined) {
    const t = f.obj(raw.tickers, `${P}.tickers`);
    for (const k of Object.keys(t)) tickers[k] = f.str(t, k, `${P}.tickers`, /^[A-Z0-9]{1,16}$/);
  }

  const cfg: DeskConfig = {
    rpcUrl, chainId,
    reserve: addrEnv('MOVVA_RESERVE') ?? f.optAddress(raw, 'reserve', P),
    issuer: addrEnv('MOVVA_STATEMENT_ISSUER') ?? f.optAddress(raw, 'issuer', P),
    yieldRecipient: f.optAddress(raw, 'yieldRecipient', P),
    instruments, tickers,
    hedgeBandBps: bps('hedgeBandBps', DEFAULT_HEDGE_BAND_BPS),
    rollWithinDays: f.int(raw, 'rollWithinDays', P, 5, [0, 60]),
    executionBufferBps: bps('executionBufferBps', DEFAULT_EXECUTION_BUFFER_BPS),
    stressMoveBps: f.int(raw, 'stressMoveBps', P, DEFAULT_STRESS_MOVE_BPS, [1, 9_999]),
    initialMarginBps: bps('initialMarginBps', DEFAULT_SHOCK_ASSUMPTIONS.initialMarginBps),
    conversionCostBps: bps('conversionCostBps', DEFAULT_SHOCK_ASSUMPTIONS.conversionCostBps),
    statementMaxAgeSeconds: f.int(raw, 'statementMaxAgeSeconds', P, DEFAULT_STATEMENT_MAX_AGE_SECONDS, [60, 30 * 86_400]),
    statementDir: env.MOVVA_STATEMENT_DIR?.trim() || (raw.statementDir === undefined ? undefined : f.str(raw, 'statementDir', P)),
    secrets: [],
  };
  problems.push(...f.problems);
  if (problems.length) throw new ConfigError(problems);

  // Everything secret-shaped in the environment is redacted, not only what this file reads.
  cfg.secrets = [
    ...(rpcUrl ? [rpcUrl] : []),
    ...Object.entries(env).filter(([k, v]) => SECRET_NAME.test(k) && !k.endsWith('_FILE') && !!v && v.length >= 8).map(([, v]) => v!),
  ];
  return cfg;
}

/**
 * The statement signing key, from `MOVVA_STATEMENT_KEY_FILE` (preferred: a mounted secret) or
 * `MOVVA_STATEMENT_KEY`. Added to `cfg.secrets` so nothing printed afterwards can contain it.
 */
export function statementKeyFromEnv(env: Env, readFile: (path: string) => string, cfg: DeskConfig): Hex {
  const file = env.MOVVA_STATEMENT_KEY_FILE?.trim();
  const direct = env.MOVVA_STATEMENT_KEY?.trim();
  if (file && direct) throw new ConfigError(['set MOVVA_STATEMENT_KEY_FILE or MOVVA_STATEMENT_KEY, not both']);
  let v = direct ?? '';
  if (file) {
    try {
      v = readFile(file).trim();
    } catch {
      throw new ConfigError(['MOVVA_STATEMENT_KEY_FILE could not be read']);
    }
  }
  if (!v) throw new ConfigError(['MOVVA_STATEMENT_KEY_FILE (or MOVVA_STATEMENT_KEY) is required to sign a statement']);
  if (!/^0x[0-9a-fA-F]{64}$/.test(v)) throw new ConfigError(['MOVVA_STATEMENT_KEY must be a 0x-prefixed 32-byte hex key']);
  cfg.secrets.push(v, v.slice(2));
  return v as Hex;
}
