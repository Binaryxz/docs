/**
 * Plans for the two treasury actions the principal-locked reserve has: `recapitalize` and `harvestYield`.
 *
 * ## The principal-locked reserve (client rule, 21 October 2026)
 *
 * The reserve's USDT backing can never be withdrawn by anyone: it leaves only by redemption, which the off-ramp's
 * LPs (the gateways) do, and - above `max(principalUsdt, liabilities at the target ratio)` - by `harvestYield`, which
 * pays only the fixed `yieldRecipient` (Mova's Safe). There is no `withdrawToHedge`, no hedge-withdrawal queue, no
 * treasurer and no hedge treasury any more: margin for the hedge is Mova's own capital, through its hedge Safe,
 * never the reserve's. Hedge gains Mova chooses to bring back come in by `recapitalize`, and become principal.
 *
 * ## Plan, never send
 *
 * This module holds no key and sends nothing. It produces the amount, the ratio it leaves, which
 * rule binds, and unsigned calldata - for a recapitalization, for the multisig that holds the USDT, whose signers
 * should each be able to reproduce the plan from the same block; a harvest anyone may send, since it can only pay
 * the yield recipient. The separation is the point: the software that reads the reserve and does the arithmetic
 * is the software most likely to be wrong.
 *
 * ## Time passes between the plan and the transaction
 *
 * A multisig executes hours after the plan, at a different rate. So the recapitalization planner works at a rate
 * moved against the reserve by `executionBufferBps` and reports the ratio at both rates: it still reaches its target
 * after that move. A harvest is computed by the reserve itself when it executes, so it needs no buffer; the plan
 * shows what would still be harvestable after the same move, which is what a signer can expect to see paid.
 */
import { encodeFunctionData, type Address, type Hex, type PublicClient } from 'viem';
import { ERC20_ABI, MOVVA_RESERVE_ABI, MOVVA_RESERVE_DESK_ABI } from './abi.js';
import { ratioBps, usdtForRatio } from './hedge.js';
import { expectedHarvestableUsdt, harvestFloorUsdt, revertReason, thresholdWarnings, type PricedSnapshot } from './reserve.js';
import { BPS, formatBps, formatUsdt, max } from './units.js';

export interface PlannedTransaction {
  to: Address;
  value: '0';
  data: Hex;
  /** `recapitalize(1888888888889)`, for the signer to read before the calldata. */
  call: string;
  description: string;
}

/** Plan as if the rate had moved this much against the reserve before execution, bps. */
export const DEFAULT_EXECUTION_BUFFER_BPS = 50;

const buffered = (rate: bigint, bps: number) => rate * (BPS - BigInt(bps)) / BPS;

function checkPolicyBps(name: string, v: number): void {
  if (!Number.isInteger(v) || v < 0 || v >= 10_000) throw new Error(`${name} must be an integer from 0 to 9999`);
}

function snapshotWarnings(s: PricedSnapshot, nowSeconds?: number): string[] {
  const w: string[] = [...thresholdWarnings(s.thresholds)];
  if (nowSeconds !== undefined && nowSeconds - Number(s.blockTimestamp) > 15 * 60) {
    w.push(`the snapshot is ${Math.floor((nowSeconds - Number(s.blockTimestamp)) / 60)} minutes old: re-plan against a fresh block before signing`);
  }
  return w;
}

export interface RecapPlan {
  kind: 'recapitalize';
  reserve: Address;
  usdt: Address;
  blockNumber: bigint;
  rateBrlPerUsdtE18: bigint;
  bufferedRateBrlPerUsdtE18: bigint;
  targetRatioBps: number;
  /** What reaches the target at the snapshot's rate, and at the buffered rate. */
  toTargetUsdt: bigint;
  toTargetAtBufferedRateUsdt: bigint;
  /** What restores 100% at the buffered rate. */
  toFullAtBufferedRateUsdt: bigint;
  amountUsdt: bigint;
  binding: 'target' | 'requested';
  ratio: { beforeBps: bigint; afterBps: bigint; afterAtBufferedRateBps: bigint };
  from?: Address;
  transactions: PlannedTransaction[];
  refused?: string;
  warnings: string[];
}

/**
 * USDT that brings the ratio back to `targetRatioBps` (default: the reserve's target) even after the
 * execution buffer, as approve + recapitalize from `from`. Anyone may recapitalize; the sender is
 * whoever holds the USDT - Mova's own capital, or what its hedge gains bought. It becomes principal: no harvest
 * can ever take it out again.
 */
export function planRecapitalize(snapshot: PricedSnapshot, opts: {
  amountUsdt?: bigint; targetRatioBps?: number; executionBufferBps?: number;
  from?: Address; allowance?: bigint; balance?: bigint; nowSeconds?: number;
} = {}): RecapPlan {
  const bufferBps = opts.executionBufferBps ?? DEFAULT_EXECUTION_BUFFER_BPS;
  checkPolicyBps('executionBufferBps', bufferBps);
  const target = opts.targetRatioBps ?? snapshot.thresholds.targetCollateralRatioBps;
  if (!Number.isInteger(target) || target <= 0) throw new Error('targetRatioBps must be a positive integer');
  const { totalUsdt: T, liabilitiesBrlE18: L, brlPerUsdtE18: S } = snapshot;
  const Sb = buffered(S, bufferBps);
  const toTarget = max(0n, usdtForRatio(BigInt(target), L, S) - T);
  const toTargetBuffered = max(0n, usdtForRatio(BigInt(target), L, Sb) - T);
  const toFullBuffered = max(0n, usdtForRatio(BPS, L, Sb) - T);
  const amount = opts.amountUsdt ?? toTargetBuffered;
  const warnings = snapshotWarnings(snapshot, opts.nowSeconds);
  let refused: string | undefined;
  if (snapshot.inconsistencies.length) {
    refused = `the reserve's figures do not agree with each other (${snapshot.inconsistencies.join('; ')}): find out why before moving USDT`;
  } else if (amount === 0n) {
    refused = `nothing to do: the reserve is at ${formatBps(snapshot.collateralRatioBps)}, at or above ${formatBps(target)} even at a rate ${formatBps(bufferBps)} lower`;
  }
  if (opts.amountUsdt !== undefined && opts.amountUsdt < toTargetBuffered && !refused) {
    warnings.push(`${formatUsdt(opts.amountUsdt)} does not reach ${formatBps(target)}: ${formatUsdt(toTargetBuffered)} would, at the buffered rate`);
  }
  if (opts.balance !== undefined && opts.from && opts.balance < amount) {
    warnings.push(`${opts.from} holds ${formatUsdt(opts.balance)}, less than ${formatUsdt(amount)}: the transaction would revert`);
  }
  const txs: PlannedTransaction[] = [];
  if (!refused) {
    const approve = (v: bigint, why: string): PlannedTransaction => ({
      to: snapshot.usdt, value: '0', data: encodeFunctionData({ abi: ERC20_ABI, functionName: 'approve', args: [snapshot.reserve, v] }),
      call: `approve(${snapshot.reserve}, ${v})`, description: why,
    });
    // Tether's approve refuses a non-zero to non-zero change; zero it unless it is known to be zero.
    if (opts.allowance === undefined || opts.allowance > 0n) {
      txs.push(approve(0n, 'Reset the USDT allowance to zero first (USDT refuses to change a non-zero allowance)'));
      if (opts.allowance === undefined) warnings.push('the sender\'s current allowance was not read: the plan resets it to zero first, which is harmless');
    }
    txs.push(approve(amount, `Allow the reserve to pull exactly ${formatUsdt(amount)}`));
    txs.push({
      to: snapshot.reserve, value: '0',
      data: encodeFunctionData({ abi: MOVVA_RESERVE_ABI, functionName: 'recapitalize', args: [amount] }),
      call: `recapitalize(${amount})`,
      description: `Add ${formatUsdt(amount)} to the Movva reserve without minting, as principal; ratio after ${formatBps(ratioBps(T + amount, L, S))}`,
    });
  }
  return {
    kind: 'recapitalize', reserve: snapshot.reserve, usdt: snapshot.usdt, blockNumber: snapshot.blockNumber,
    rateBrlPerUsdtE18: S, bufferedRateBrlPerUsdtE18: Sb, targetRatioBps: target,
    toTargetUsdt: toTarget, toTargetAtBufferedRateUsdt: toTargetBuffered, toFullAtBufferedRateUsdt: toFullBuffered,
    amountUsdt: refused ? 0n : amount, binding: opts.amountUsdt === undefined ? 'target' : 'requested',
    ratio: {
      beforeBps: snapshot.collateralRatioBps,
      afterBps: ratioBps(T + (refused ? 0n : amount), L, S),
      afterAtBufferedRateBps: ratioBps(T + (refused ? 0n : amount), L, Sb),
    },
    from: opts.from, transactions: txs, refused, warnings,
  };
}

/**
 * A plan's transactions in the Safe Transaction Builder's batch JSON shape (version 1.0), for a
 * multisig to import and review. No checksum is included; the Safe app computes and shows its own.
 * The shape is as the builder documents it - to confirm against the Safe version the issuer uses.
 */
export function safeTransactionBatch(txs: readonly PlannedTransaction[], opts: {
  chainId: number; safe?: Address; name: string; description: string; createdAt: number;
}) {
  return {
    version: '1.0',
    chainId: String(opts.chainId),
    createdAt: opts.createdAt,
    meta: { name: opts.name, description: opts.description, createdFromSafeAddress: opts.safe ?? '' },
    transactions: txs.map((t) => ({ to: t.to, value: t.value, data: t.data, contractMethod: null, contractInputsValues: null })),
  };
}

export interface HarvestPlan {
  kind: 'harvestYield';
  reserve: Address;
  blockNumber: bigint;
  rateBrlPerUsdtE18: bigint;
  bufferedRateBrlPerUsdtE18: bigint;
  principalUsdt: bigint;
  /** max(principal, the liabilities' USDT at the target): no harvest takes the reserve below it. */
  floorUsdt: bigint;
  /** Which leg of the floor binds. */
  binding: 'principal' | 'target';
  /** The reserve's own `harvestableYield()` at the snapshot's block, and the same from the formula. */
  harvestableUsdt: bigint;
  expectedHarvestableUsdt: bigint;
  /** What would still be harvestable after the rate moved `executionBufferBps` against the reserve. */
  harvestableAtBufferedRateUsdt: bigint;
  /** The only address the harvest can pay. */
  yieldRecipient: Address;
  ratio: { beforeBps: bigint; afterBps: bigint };
  transactions: PlannedTransaction[];
  refused?: string;
  warnings: string[];
}

/**
 * `harvestYield()`: permissionless, and it can only pay the reserve's `yieldRecipient` the USDT above the floor. The
 * reserve computes the amount when it executes - the plan reports it, checks it against the formula, and refuses to
 * plan nothing. `yieldRecipient` names the Safe the desk expects (configuration); a mismatch is a warning to resolve
 * before anyone sends it, because the recipient changes only through the governance delay.
 */
export function planHarvestYield(snapshot: PricedSnapshot, opts: {
  executionBufferBps?: number; yieldRecipient?: Address; nowSeconds?: number;
} = {}): HarvestPlan {
  const bufferBps = opts.executionBufferBps ?? DEFAULT_EXECUTION_BUFFER_BPS;
  checkPolicyBps('executionBufferBps', bufferBps);
  const y = snapshot.yield;
  if (!y) {
    throw new Error('this reserve has no principalUsdt / yieldRecipient views: it predates the principal-locked reserve (21 October 2026), '
      + 'and has no harvest');
  }
  const { totalUsdt: T, liabilitiesBrlE18: L, brlPerUsdtE18: S } = snapshot;
  const target = snapshot.thresholds.targetCollateralRatioBps;
  const Sb = buffered(S, bufferBps);
  const floor = harvestFloorUsdt(y.principalUsdt, L, S, target);
  const binding = y.principalUsdt >= floor ? 'principal' as const : 'target' as const;
  const expected = expectedHarvestableUsdt(snapshot, y.principalUsdt);
  const harvestable = y.harvestableUsdt ?? expected;
  const atBuffered = max(0n, T - harvestFloorUsdt(y.principalUsdt, L, Sb, target));
  const warnings = [...snapshotWarnings(snapshot, opts.nowSeconds)];
  if (y.harvestableUsdt === undefined) warnings.push('the reserve\'s harvestableYield() was not read: the amount is the formula\'s');
  if (opts.yieldRecipient && opts.yieldRecipient.toLowerCase() !== y.recipient.toLowerCase()) {
    warnings.push(`the reserve pays its yield to ${y.recipient}, not the expected ${opts.yieldRecipient}: do not send until that is explained `
      + '(a change of recipient waits the governance delay, and is visible on-chain)');
  }
  let refused: string | undefined;
  if (snapshot.inconsistencies.length) {
    refused = `the reserve's figures do not agree with each other (${snapshot.inconsistencies.join('; ')}): find out why before moving USDT`;
  } else if (harvestable === 0n) {
    refused = `nothing to harvest: the reserve holds ${formatUsdt(T)}, at or below its floor ${formatUsdt(floor)} `
      + (binding === 'principal' ? `(the principal)` : `(the liabilities at the ${formatBps(target)} target)`);
  }
  if (!refused && atBuffered < harvestable) {
    warnings.push(`at a rate ${formatBps(bufferBps)} lower, only ${formatUsdt(atBuffered)} would be harvestable: the reserve pays what is above `
      + 'the floor when the transaction executes, never more');
  }
  const paid = refused ? 0n : harvestable;
  return {
    kind: 'harvestYield', reserve: snapshot.reserve, blockNumber: snapshot.blockNumber,
    rateBrlPerUsdtE18: S, bufferedRateBrlPerUsdtE18: Sb,
    principalUsdt: y.principalUsdt, floorUsdt: floor, binding,
    harvestableUsdt: harvestable, expectedHarvestableUsdt: expected, harvestableAtBufferedRateUsdt: atBuffered,
    yieldRecipient: y.recipient,
    ratio: { beforeBps: snapshot.collateralRatioBps, afterBps: ratioBps(T - paid, L, S) },
    transactions: refused ? [] : [{
      to: snapshot.reserve, value: '0',
      data: encodeFunctionData({ abi: MOVVA_RESERVE_ABI, functionName: 'harvestYield', args: [] }),
      call: 'harvestYield()',
      description: `Harvest ${formatUsdt(harvestable)} of yield to the reserve's yield recipient ${y.recipient}; the principal and the `
        + `target's backing stay (ratio after ${formatBps(ratioBps(T - paid, L, S))}). Anyone may send it`,
    }],
    refused, warnings,
  };
}

/** `eth_call` the planned harvest at the plan's block, from `from` (anyone: the harvest pays only the yield recipient). */
export async function simulateHarvest(
  client: Pick<PublicClient, 'simulateContract'>, plan: HarvestPlan, from?: Address,
): Promise<{ ok: true; usdt: bigint } | { ok: false; reason: string }> {
  try {
    const r = await client.simulateContract({
      address: plan.reserve, abi: MOVVA_RESERVE_DESK_ABI, functionName: 'harvestYield', args: [],
      blockNumber: plan.blockNumber, ...(from ? { account: from } : {}),
    } as never) as { result?: bigint };
    return { ok: true, usdt: typeof r.result === 'bigint' ? r.result : plan.harvestableUsdt };
  } catch (e) {
    const reason = revertReason(e);
    if (reason === undefined) throw e;
    return { ok: false, reason };
  }
}
