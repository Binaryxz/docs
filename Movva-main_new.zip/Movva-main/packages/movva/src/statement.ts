/**
 * Signed hedge statements: the issuer's word about the off-chain half of the peg, made checkable.
 *
 * ## Why a signature, and what it does NOT prove
 *
 * The chain sees the reserve; nobody but the issuer and its broker sees the short. So the issuer
 * publishes, every day, what it holds at B3 and what its margin account looks like - and signs it.
 * The signature makes the claim ATTRIBUTABLE: a statement that turns out false is a signed false
 * statement by a named legal entity, not a number on a web page. It does not make the claim TRUE.
 * The broker's own statement is bound by its SHA-256, so an auditor holding the document can check
 * the signed figures against it, but nothing here can read a broker's books.
 *
 * ## What a statement binds
 *
 * EIP-712 typed data (`STATEMENT_TYPES`) under a domain naming the chain and the reserve, so a
 * statement cannot be replayed against another deployment:
 *
 *  - `issuer`, `sequence`, `asOf`: who, which one, when.
 *  - `reserveBlock`, `reserveBlockHash`, `reserveBrlPerUsdtE18`, `reserveLiabilitiesUsdt`: the
 *    on-chain snapshot the hedge was sized against. The figures are in the message, not only the
 *    block number, so a verifier with an archive node checks that they are what the reserve said at
 *    that block - a statement cannot claim to be fully hedged against liabilities that did not exist.
 *  - `positions` (instrument, ticker, expiry, side, contracts, contract size, average price) and
 *    `netShortUsdE6`, which must equal the positions' sum.
 *  - `marginBalanceBrlCents` (signed: a debit balance after a missed call is possible and must be
 *    reportable) and `marginRequiredBrlCents`.
 *  - `brokerStatementSha256`: the document the figures come from.
 *  - `previousStatementHash`: the EIP-712 hash of the statement before, zero for the first. The
 *    statements form a chain, so the issuer cannot quietly replace yesterday's statement after a bad
 *    day: a rewritten statement changes its hash, and every later one stops linking to it.
 *
 * ## Verifying
 *
 * `verifyStatement` needs only the issuer's address - no key, no trust in whoever served the file -
 * and checks, each separately reported: the signature and domain, the stated hash, the arithmetic,
 * the chain link (when the previous statement is supplied), freshness, and the snapshot against the
 * chain (when a reader is supplied). The monitor carries a transcription of the types and the
 * parts it needs (packages/ops/src/checks.ts); test/monitor-compat.test.ts keeps the two identical.
 */
import {
  hashTypedData, isAddressEqual, recoverTypedDataAddress, sha256, zeroHash,
  type Address, type Hex, type PublicClient,
} from 'viem';
import { MOVVA_RESERVE_ABI } from './abi.js';
import { Fields, InvalidDocument } from './json.js';
import { daysToExpiry, type Instrument, type Position } from './hedge.js';
import { revertReason, type PricedSnapshot } from './reserve.js';
import { E6 } from './units.js';

export const STATEMENT_FORMAT = 'movva-hedge-statement/v1';

export const STATEMENT_TYPES = {
  Position: [
    { name: 'instrument', type: 'string' },
    { name: 'ticker', type: 'string' },
    { name: 'expiry', type: 'string' },
    { name: 'side', type: 'string' },
    { name: 'contracts', type: 'uint256' },
    { name: 'contractSizeUsd', type: 'uint256' },
    { name: 'averagePriceBrlPerUsdE6', type: 'uint256' },
  ],
  HedgeStatement: [
    { name: 'issuer', type: 'address' },
    { name: 'sequence', type: 'uint64' },
    { name: 'asOf', type: 'uint64' },
    { name: 'reserveBlock', type: 'uint64' },
    { name: 'reserveBlockHash', type: 'bytes32' },
    { name: 'reserveBrlPerUsdtE18', type: 'uint256' },
    { name: 'reserveLiabilitiesUsdt', type: 'uint256' },
    { name: 'positions', type: 'Position[]' },
    { name: 'netShortUsdE6', type: 'int256' },
    { name: 'marginBalanceBrlCents', type: 'int256' },
    { name: 'marginRequiredBrlCents', type: 'uint256' },
    { name: 'brokerStatementSha256', type: 'bytes32' },
    { name: 'previousStatementHash', type: 'bytes32' },
  ],
} as const;

export interface StatementDomain {
  name: 'Movva Hedge Statement';
  version: '1';
  chainId: number;
  verifyingContract: Address;
}

export const statementDomain = (chainId: number, reserve: Address): StatementDomain => ({
  name: 'Movva Hedge Statement', version: '1', chainId, verifyingContract: reserve,
});

export interface StatementPosition extends Position {
  contractSizeUsd: bigint;
}

export interface HedgeStatement {
  issuer: Address;
  sequence: bigint;
  asOf: bigint;
  reserveBlock: bigint;
  reserveBlockHash: Hex;
  reserveBrlPerUsdtE18: bigint;
  reserveLiabilitiesUsdt: bigint;
  positions: StatementPosition[];
  netShortUsdE6: bigint;
  marginBalanceBrlCents: bigint;
  marginRequiredBrlCents: bigint;
  brokerStatementSha256: Hex;
  previousStatementHash: Hex;
}

export interface SignedStatement {
  format: typeof STATEMENT_FORMAT;
  domain: StatementDomain;
  message: HedgeStatement;
  /** EIP-712 hash of domain and message: what the next statement links to. */
  hash: Hex;
  signature: Hex;
}

/** The SHA-256 of the broker's statement document, as `sha256sum` prints it but 0x-prefixed. */
export const documentSha256 = (bytes: Uint8Array): Hex => sha256(bytes);

export const hashStatement = (domain: StatementDomain, message: HedgeStatement): Hex =>
  hashTypedData({ domain, types: STATEMENT_TYPES, primaryType: 'HedgeStatement', message });

/** Net dollars short from a statement's positions, using the contract sizes the statement states. */
export const statementNetShortUsdE6 = (positions: readonly StatementPosition[]): bigint =>
  positions.reduce((a, p) => a + (p.side === 'short' ? 1n : -1n) * p.contracts * p.contractSizeUsd * E6, 0n);

/**
 * Assemble the next statement. Refuses what verification would reject anyway - an unpriced or
 * inconsistent snapshot, a snapshot older than the previous statement's, an `asOf` before the
 * snapshot - so a bad statement is never signed in the first place.
 */
export function buildStatement(p: {
  issuer: Address;
  asOf: bigint;
  snapshot: PricedSnapshot;
  positions: readonly Position[];
  instruments: readonly Instrument[];
  marginBalanceBrlCents: bigint;
  marginRequiredBrlCents: bigint;
  brokerStatementSha256: Hex;
  previous?: SignedStatement;
}): HedgeStatement {
  const problems: string[] = [];
  if (p.snapshot.inconsistencies.length) problems.push(`the snapshot is inconsistent: ${p.snapshot.inconsistencies.join('; ')}`);
  if (p.asOf < p.snapshot.blockTimestamp) problems.push('asOf is before the snapshot block: a statement reconciles against a block it has seen');
  if (p.marginRequiredBrlCents < 0n) problems.push('marginRequiredBrlCents cannot be negative');
  if (!/^0x[0-9a-f]{64}$/i.test(p.brokerStatementSha256) || BigInt(p.brokerStatementSha256) === 0n) {
    problems.push('brokerStatementSha256 must be the SHA-256 of the broker document');
  }
  if (p.previous) {
    const prev = p.previous.message;
    if (!isAddressEqual(prev.issuer, p.issuer)) problems.push(`the previous statement was issued by ${prev.issuer}, not ${p.issuer}`);
    if (p.asOf <= prev.asOf) problems.push(`asOf ${p.asOf} is not after the previous statement's ${prev.asOf}`);
    if (p.snapshot.blockNumber < prev.reserveBlock) problems.push(`the snapshot block ${p.snapshot.blockNumber} is before the previous statement's ${prev.reserveBlock}`);
  }
  const positions: StatementPosition[] = p.positions.map((pos) => {
    const inst = p.instruments.find((i) => i.symbol === pos.instrument);
    if (!inst) problems.push(`${pos.ticker}: unknown instrument ${pos.instrument}`);
    if (pos.contracts <= 0n) problems.push(`${pos.ticker}: contracts must be positive (omit closed positions)`);
    if (pos.side !== 'short' && pos.side !== 'long') problems.push(`${pos.ticker}: side must be short or long`);
    try { daysToExpiry(pos.expiry, 0); } catch { problems.push(`${pos.ticker}: expiry must be YYYY-MM-DD`); }
    return { ...pos, contractSizeUsd: inst?.contractSizeUsd ?? 0n };
  });
  if (problems.length) throw new InvalidDocument('statement', problems);
  return {
    issuer: p.issuer,
    sequence: p.previous ? p.previous.message.sequence + 1n : 1n,
    asOf: p.asOf,
    reserveBlock: p.snapshot.blockNumber,
    reserveBlockHash: p.snapshot.blockHash,
    reserveBrlPerUsdtE18: p.snapshot.brlPerUsdtE18,
    reserveLiabilitiesUsdt: p.snapshot.liabilitiesUsdt,
    positions,
    netShortUsdE6: statementNetShortUsdE6(positions),
    marginBalanceBrlCents: p.marginBalanceBrlCents,
    marginRequiredBrlCents: p.marginRequiredBrlCents,
    brokerStatementSha256: p.brokerStatementSha256.toLowerCase() as Hex,
    previousStatementHash: p.previous?.hash ?? zeroHash,
  };
}

/** Anything that can sign typed data: a viem local account, or a remote signer with the same shape. */
export interface StatementSigner {
  address: Address;
  signTypedData: (args: {
    domain: StatementDomain; types: typeof STATEMENT_TYPES; primaryType: 'HedgeStatement'; message: HedgeStatement;
  }) => Promise<Hex>;
}

export async function signStatement(
  signer: StatementSigner, chainId: number, reserve: Address, message: HedgeStatement,
): Promise<SignedStatement> {
  if (!isAddressEqual(signer.address, message.issuer)) {
    throw new Error(`the statement key is ${signer.address}, but the statement names ${message.issuer} as issuer`);
  }
  const domain = statementDomain(chainId, reserve);
  const signature = await signer.signTypedData({ domain, types: STATEMENT_TYPES, primaryType: 'HedgeStatement', message });
  return { format: STATEMENT_FORMAT, domain, message, hash: hashStatement(domain, message), signature };
}

/*//////////////////////////////////////////////////////////////
                          SERIALISATION
//////////////////////////////////////////////////////////////*/

/** The published JSON: amounts as decimal strings. */
export function statementToJson(s: SignedStatement): unknown {
  const m = s.message;
  const str = (x: bigint) => x.toString();
  return {
    format: s.format,
    domain: s.domain,
    message: {
      issuer: m.issuer, sequence: str(m.sequence), asOf: str(m.asOf),
      reserveBlock: str(m.reserveBlock), reserveBlockHash: m.reserveBlockHash,
      reserveBrlPerUsdtE18: str(m.reserveBrlPerUsdtE18), reserveLiabilitiesUsdt: str(m.reserveLiabilitiesUsdt),
      positions: m.positions.map((p) => ({
        instrument: p.instrument, ticker: p.ticker, expiry: p.expiry, side: p.side, contracts: str(p.contracts),
        contractSizeUsd: str(p.contractSizeUsd), averagePriceBrlPerUsdE6: str(p.averagePriceBrlPerUsdE6),
      })),
      netShortUsdE6: str(m.netShortUsdE6),
      marginBalanceBrlCents: str(m.marginBalanceBrlCents), marginRequiredBrlCents: str(m.marginRequiredBrlCents),
      brokerStatementSha256: m.brokerStatementSha256, previousStatementHash: m.previousStatementHash,
    },
    hash: s.hash,
    signature: s.signature,
  };
}

const UINT64_MAX = (1n << 64n) - 1n;

/** Parse a published statement strictly. Parsing is not verifying: call `verifyStatement`. */
export function statementFromJson(raw: unknown): SignedStatement {
  const f = new Fields();
  const o = f.obj(raw, 'statement');
  if (o.format !== STATEMENT_FORMAT) f.problems.push(`statement.format must be "${STATEMENT_FORMAT}"`);
  const d = f.obj(o.domain, 'statement.domain');
  if (d.name !== 'Movva Hedge Statement' || d.version !== '1') f.problems.push('statement.domain is not a Movva Hedge Statement v1 domain');
  const domain = statementDomain(f.int(d, 'chainId', 'statement.domain', undefined, [1, Number.MAX_SAFE_INTEGER]), f.address(d, 'verifyingContract', 'statement.domain'));
  const m = f.obj(o.message, 'statement.message');
  const P = 'statement.message';
  const u64 = (k: string) => {
    const v = f.big(m, k, P);
    if (v > UINT64_MAX) f.problems.push(`${P}.${k} does not fit in uint64`);
    return v;
  };
  const message: HedgeStatement = {
    issuer: f.address(m, 'issuer', P),
    sequence: u64('sequence'),
    asOf: u64('asOf'),
    reserveBlock: u64('reserveBlock'),
    reserveBlockHash: f.hex32(m, 'reserveBlockHash', P),
    reserveBrlPerUsdtE18: f.big(m, 'reserveBrlPerUsdtE18', P),
    reserveLiabilitiesUsdt: f.big(m, 'reserveLiabilitiesUsdt', P),
    positions: f.arr(m.positions, `${P}.positions`).map((x, i) => {
      const pp = `${P}.positions[${i}]`;
      const po = f.obj(x, pp);
      const side = f.str(po, 'side', pp, /^(short|long)$/) as 'short' | 'long';
      return {
        instrument: f.str(po, 'instrument', pp, /^[A-Z0-9]{1,16}$/),
        ticker: f.str(po, 'ticker', pp, /^[A-Z0-9]{1,16}$/),
        expiry: f.str(po, 'expiry', pp, /^\d{4}-\d{2}-\d{2}$/),
        side,
        contracts: f.big(po, 'contracts', pp),
        contractSizeUsd: f.big(po, 'contractSizeUsd', pp),
        averagePriceBrlPerUsdE6: f.big(po, 'averagePriceBrlPerUsdE6', pp),
      };
    }),
    netShortUsdE6: f.big(m, 'netShortUsdE6', P, { signed: true }),
    marginBalanceBrlCents: f.big(m, 'marginBalanceBrlCents', P, { signed: true }),
    marginRequiredBrlCents: f.big(m, 'marginRequiredBrlCents', P),
    brokerStatementSha256: f.hex32(m, 'brokerStatementSha256', P),
    previousStatementHash: f.hex32(m, 'previousStatementHash', P),
  };
  const hash = f.hex32(o, 'hash', 'statement');
  const signature = f.bytes(o, 'signature', 'statement');
  f.done('statement');
  return { format: STATEMENT_FORMAT, domain, message, hash, signature };
}

/*//////////////////////////////////////////////////////////////
                           VERIFICATION
//////////////////////////////////////////////////////////////*/

export type CheckOutcome = 'ok' | 'failed' | 'skipped' | 'unverifiable';

/** The reserve at a block, as a statement's snapshot is checked against it. */
export type SnapshotAtBlock =
  | { blockHash: Hex; blockTimestamp: bigint; brlPerUsdtE18: bigint; liabilitiesUsdt: bigint }
  | { blockHash: Hex; blockTimestamp: bigint; refusal: string };

export interface VerifyOptions {
  /** The address statements must be signed by. The only trust input. */
  issuer: Address;
  chainId: number;
  reserve: Address;
  nowSeconds: number;
  /** A statement older than this is stale. Default 26h: daily, with two hours' grace. */
  maxAgeSeconds?: number;
  /** How far `asOf` may run ahead of the verifier's clock. Default 5 minutes. */
  maxFutureSkewSeconds?: number;
  /** How long before `asOf` the snapshot block may be. Default 6h. */
  maxSnapshotLagSeconds?: number;
  /** The statement before this one. Without it the chain link is `skipped`, never assumed. */
  previous?: Pick<SignedStatement, 'hash'> & { message: Pick<HedgeStatement, 'sequence' | 'asOf' | 'reserveBlock'> };
  /** Contract sizes the desk expects; a statement stating another size is warned about. */
  instruments?: readonly Instrument[];
  /** Reads the reserve at a block (`snapshotReader`). Without it the snapshot check is `skipped`. */
  readSnapshotAt?: (block: bigint) => Promise<SnapshotAtBlock>;
}

export interface StatementVerification {
  valid: boolean;
  hash: Hex;
  checks: {
    signature: CheckOutcome; hash: CheckOutcome; arithmetic: CheckOutcome;
    chain: CheckOutcome; freshness: CheckOutcome; snapshot: CheckOutcome;
  };
  ageSeconds: number;
  problems: string[];
  warnings: string[];
}

export const DEFAULT_STATEMENT_MAX_AGE_SECONDS = 26 * 3600;

export async function verifyStatement(doc: SignedStatement, o: VerifyOptions): Promise<StatementVerification> {
  const problems: string[] = [];
  const warnings: string[] = [];
  const m = doc.message;
  const checks: StatementVerification['checks'] = {
    signature: 'failed', hash: 'failed', arithmetic: 'failed', chain: 'skipped', freshness: 'failed', snapshot: 'skipped',
  };

  // The domain the verifier expects, not the one the document claims: a statement for another
  // chain or reserve must not verify here, whatever its signature.
  const domain = statementDomain(o.chainId, o.reserve);
  if (doc.domain.chainId !== o.chainId || !isAddressEqual(doc.domain.verifyingContract, o.reserve)) {
    problems.push(`the statement is for chain ${doc.domain.chainId} reserve ${doc.domain.verifyingContract}, not chain ${o.chainId} reserve ${o.reserve}`);
  }
  const hash = hashStatement(domain, m);
  if (doc.hash.toLowerCase() === hash) checks.hash = 'ok';
  else problems.push('the stated hash is not the hash of this statement: it was edited after hashing, or hashed for another domain');

  try {
    const signer = await recoverTypedDataAddress({ domain, types: STATEMENT_TYPES, primaryType: 'HedgeStatement', message: m, signature: doc.signature });
    if (!isAddressEqual(signer, o.issuer)) problems.push(`signed by ${signer}, not the issuer's statement key ${o.issuer}`);
    else if (!isAddressEqual(m.issuer, o.issuer)) problems.push(`the message names ${m.issuer} as issuer, not ${o.issuer}`);
    else checks.signature = 'ok';
  } catch {
    problems.push('the signature is malformed');
  }

  const arithmetic: string[] = [];
  const net = statementNetShortUsdE6(m.positions);
  if (net !== m.netShortUsdE6) arithmetic.push(`netShortUsdE6 is ${m.netShortUsdE6}, but the positions add up to ${net}`);
  for (const p of m.positions) {
    if (p.contracts <= 0n) arithmetic.push(`${p.ticker}: contracts must be positive`);
    if (p.contractSizeUsd <= 0n) arithmetic.push(`${p.ticker}: contract size must be positive`);
    const inst = o.instruments?.find((i) => i.symbol === p.instrument);
    if (o.instruments && !inst) warnings.push(`${p.ticker}: instrument ${p.instrument} is not configured on this desk`);
    if (inst && inst.contractSizeUsd !== p.contractSizeUsd) {
      warnings.push(`${p.ticker}: the statement states US$ ${p.contractSizeUsd} per contract; this desk is configured with US$ ${inst.contractSizeUsd}`);
    }
    try {
      if (daysToExpiry(p.expiry, Number(m.asOf)) < 0) warnings.push(`${p.ticker} expired on ${p.expiry}, before the statement`);
    } catch {
      arithmetic.push(`${p.ticker}: expiry must be YYYY-MM-DD`);
    }
  }
  if (m.sequence === 0n) arithmetic.push('sequence starts at 1');
  if ((m.sequence === 1n) !== (m.previousStatementHash === zeroHash)) {
    arithmetic.push('the first statement (sequence 1), and only it, has a zero previousStatementHash');
  }
  problems.push(...arithmetic);
  if (arithmetic.length === 0) checks.arithmetic = 'ok';

  if (o.previous) {
    const prev = o.previous;
    const link: string[] = [];
    if (m.previousStatementHash !== prev.hash.toLowerCase()) link.push(`it links to ${m.previousStatementHash}, not to the previous statement ${prev.hash}: the chain is broken or rewritten`);
    if (m.sequence !== prev.message.sequence + 1n) link.push(`sequence ${m.sequence} does not follow ${prev.message.sequence}`);
    if (m.asOf <= prev.message.asOf) link.push('asOf does not advance on the previous statement');
    if (m.reserveBlock < prev.message.reserveBlock) link.push('the snapshot block goes backwards');
    problems.push(...link);
    checks.chain = link.length ? 'failed' : 'ok';
  } else if (m.sequence > 1n) {
    warnings.push('chain link not checked: supply the previous statement');
  } else {
    checks.chain = 'ok';
  }

  const age = o.nowSeconds - Number(m.asOf);
  const maxAge = o.maxAgeSeconds ?? DEFAULT_STATEMENT_MAX_AGE_SECONDS;
  if (age > maxAge) problems.push(`the statement is ${Math.floor(age / 3600)}h old, past the ${Math.floor(maxAge / 3600)}h limit`);
  else if (-age > (o.maxFutureSkewSeconds ?? 300)) problems.push(`the statement is dated ${-age}s in the future`);
  else checks.freshness = 'ok';

  if (o.readSnapshotAt) {
    try {
      const at = await o.readSnapshotAt(m.reserveBlock);
      const snap: string[] = [];
      if (at.blockHash.toLowerCase() !== m.reserveBlockHash) snap.push(`block ${m.reserveBlock} has hash ${at.blockHash} on this chain, not ${m.reserveBlockHash}`);
      if ('refusal' in at) {
        snap.push(`the reserve refused to price at block ${m.reserveBlock} (${at.refusal}): no hedge could have been sized against it`);
      } else {
        if (at.brlPerUsdtE18 !== m.reserveBrlPerUsdtE18) snap.push(`the reserve's rate at block ${m.reserveBlock} was ${at.brlPerUsdtE18}, not ${m.reserveBrlPerUsdtE18}`);
        if (at.liabilitiesUsdt !== m.reserveLiabilitiesUsdt) snap.push(`liabilitiesUsdt at block ${m.reserveBlock} was ${at.liabilitiesUsdt}, not ${m.reserveLiabilitiesUsdt}`);
      }
      if (at.blockTimestamp > m.asOf) snap.push('the snapshot block is after asOf');
      else if (Number(m.asOf - at.blockTimestamp) > (o.maxSnapshotLagSeconds ?? 6 * 3600)) {
        snap.push(`the snapshot is ${Math.floor(Number(m.asOf - at.blockTimestamp) / 3600)}h older than the statement`);
      }
      problems.push(...snap);
      checks.snapshot = snap.length ? 'failed' : 'ok';
    } catch (e) {
      checks.snapshot = 'unverifiable';
      problems.push(`the snapshot at block ${m.reserveBlock} could not be read (an archive node is needed for old blocks): ${e instanceof Error ? e.message.split('\n')[0] : String(e)}`);
    }
  } else {
    warnings.push('snapshot not checked against the chain');
  }

  return { valid: problems.length === 0, hash, checks, ageSeconds: age, problems, warnings };
}

/** `readSnapshotAt` over a viem client: the block, and the two figures a statement carries, at it. */
export function snapshotReader(client: Pick<PublicClient, 'getBlock' | 'readContract'>, reserve: Address) {
  return async (blockNumber: bigint): Promise<SnapshotAtBlock> => {
    const block = await client.getBlock({ blockNumber });
    if (!block.hash) throw new Error(`block ${blockNumber} has no hash`);
    try {
      const [[rate], liabilitiesUsdt] = await Promise.all([
        client.readContract({ address: reserve, abi: MOVVA_RESERVE_ABI, functionName: 'brlPerUsdtE18', blockNumber }) as Promise<readonly [bigint, bigint]>,
        client.readContract({ address: reserve, abi: MOVVA_RESERVE_ABI, functionName: 'liabilitiesUsdt', blockNumber }) as Promise<bigint>,
      ]);
      return { blockHash: block.hash, blockTimestamp: block.timestamp, brlPerUsdtE18: rate, liabilitiesUsdt };
    } catch (e) {
      const refusal = revertReason(e);
      if (refusal === undefined) throw e;
      return { blockHash: block.hash, blockTimestamp: block.timestamp, refusal };
    }
  };
}
