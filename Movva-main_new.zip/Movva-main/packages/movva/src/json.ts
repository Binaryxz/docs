/**
 * JSON in and out, with bigints as decimal strings.
 *
 * Everything this package writes - snapshots, plans, statements, reports - is read by people and
 * by other programs, often in a language whose JSON numbers are doubles. So an amount is never a
 * JSON number: 1888888888889 USDT-units survives, but 10200000000000000000000000 reais-wei would
 * not. Strings on the way out, and on the way in a reader that accepts only a string of digits,
 * collects every problem by path and never echoes a value it rejects (a statement file could hold
 * something that should not end up in a log).
 */
import { getAddress, isAddress, type Address, type Hex } from 'viem';

export const toJson = (v: unknown, space: number | undefined = 2): string =>
  JSON.stringify(v, (_k, x) => (typeof x === 'bigint' ? x.toString() : x), space);

export class InvalidDocument extends Error {
  constructor(readonly what: string, readonly problems: string[]) {
    super(`${what} is invalid:\n  - ${problems.join('\n  - ')}`);
  }
}

/** A reader that records problems by path instead of throwing on the first one. */
export class Fields {
  readonly problems: string[] = [];

  obj(v: unknown, path: string): Record<string, unknown> {
    if (v && typeof v === 'object' && !Array.isArray(v)) return v as Record<string, unknown>;
    this.problems.push(`${path} must be an object`);
    return {};
  }

  arr(v: unknown, path: string): unknown[] {
    if (Array.isArray(v)) return v;
    this.problems.push(`${path} must be an array`);
    return [];
  }

  big(o: Record<string, unknown>, k: string, path: string, opts: { signed?: boolean; fallback?: bigint } = {}): bigint {
    const v = o[k];
    if (v === undefined && opts.fallback !== undefined) return opts.fallback;
    const re = opts.signed ? /^-?\d+$/ : /^\d+$/;
    if ((typeof v === 'string' && re.test(v)) || (typeof v === 'number' && Number.isSafeInteger(v) && (opts.signed || v >= 0))) {
      return BigInt(v);
    }
    this.problems.push(`${path}.${k} must be ${opts.signed ? 'an' : 'a non-negative'} integer, as a string of digits`);
    return 0n;
  }

  int(o: Record<string, unknown>, k: string, path: string, fallback?: number, range: [number, number] = [0, Number.MAX_SAFE_INTEGER]): number {
    const v = o[k];
    if (v === undefined && fallback !== undefined) return fallback;
    if (typeof v === 'number' && Number.isInteger(v) && v >= range[0] && v <= range[1]) return v;
    this.problems.push(`${path}.${k} must be an integer from ${range[0]} to ${range[1]}`);
    return fallback ?? 0;
  }

  str(o: Record<string, unknown>, k: string, path: string, re?: RegExp, fallback?: string): string {
    const v = o[k];
    if (v === undefined && fallback !== undefined) return fallback;
    if (typeof v === 'string' && v.length > 0 && (!re || re.test(v))) return v;
    this.problems.push(`${path}.${k} must be ${re ? `a string matching ${re}` : 'a non-empty string'}`);
    return fallback ?? '';
  }

  address(o: Record<string, unknown>, k: string, path: string): Address {
    const v = o[k];
    if (typeof v === 'string' && isAddress(v, { strict: false })) return getAddress(v);
    this.problems.push(`${path}.${k} must be an address`);
    return '0x0000000000000000000000000000000000000000';
  }

  optAddress(o: Record<string, unknown>, k: string, path: string): Address | undefined {
    return o[k] === undefined ? undefined : this.address(o, k, path);
  }

  hex32(o: Record<string, unknown>, k: string, path: string): Hex {
    const v = o[k];
    if (typeof v === 'string' && /^0x[0-9a-fA-F]{64}$/.test(v)) return v.toLowerCase() as Hex;
    this.problems.push(`${path}.${k} must be 32 bytes of 0x-prefixed hex`);
    return `0x${'00'.repeat(32)}`;
  }

  bytes(o: Record<string, unknown>, k: string, path: string): Hex {
    const v = o[k];
    if (typeof v === 'string' && /^0x([0-9a-fA-F]{2})*$/.test(v)) return v as Hex;
    this.problems.push(`${path}.${k} must be 0x-prefixed hex`);
    return '0x';
  }

  done(what: string): void {
    if (this.problems.length) throw new InvalidDocument(what, this.problems);
  }
}
