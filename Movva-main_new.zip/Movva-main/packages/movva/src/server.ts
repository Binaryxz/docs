/**
 * The desk's HTTP surface, for the issuer desk web UI (mova-frontend, beside this monorepo: ../mova-frontend).
 *
 * Every figure comes from `runDesk`, the same function the CLI runs: the server builds the
 * argument list, runs it in-process with an injected `DeskIo`, and returns what it printed. So the
 * UI and the command line cannot disagree about a ratio, a refusal or the off-hours rule, and the
 * output is redacted by the same `redact` the CLI uses.
 *
 * What it deliberately cannot do:
 *  - **Sign.** There is no route for `statement sign`, and the environment handed to `runDesk` has
 *    MOVVA_STATEMENT_KEY and MOVVA_STATEMENT_KEY_FILE removed: the statement key stays with the CLI.
 *  - **Send a transaction.** The desk holds no treasury key; plans are unsigned calldata and a Safe
 *    batch for the multisig, exactly as the CLI prints them.
 *  - **Read a path a request names.** Requests carry documents (positions, statements) as JSON
 *    bodies; they reach `runDesk` as in-memory files. The only files read from disk are the ones
 *    the operator configured: the desk policy, a saved snapshot, default positions, the statement
 *    store.
 *  - **Write.** `writeFile` throws.
 *
 * Response envelope: `{ ok, exitCode, data, notes }`. `data` is the command's JSON output, with
 * every integer a decimal string (json.ts); `notes` are its stderr lines. Exit codes keep their CLI
 * meaning: 1 did not verify (or a simulation reverted), 3 a plan was refused - both are answers,
 * so both are HTTP 200 with `ok: false`. 2 is a usage or configuration problem: HTTP 400.
 */
import { createServer, type IncomingMessage, type Server, type ServerResponse } from 'node:http';
import { createReadStream, existsSync, readFileSync, realpathSync, statSync } from 'node:fs';
import { basename, extname, join, resolve, sep } from 'node:path';
import { createPublicClient, http } from 'viem';
import { redact } from '@mova/ops/redact';

import { runDesk, type DeskClient, type DeskIo } from './bin/movva-desk.js';
import { ConfigError, deskConfigFromEnv, type DeskConfig, type Env } from './config.js';
import { toJson } from './json.js';
import { statementToJson } from './statement.js';
import { StatementStore } from './statement-store.js';
import { toDecimal } from './units.js';

export interface DeskServerOptions {
  /** The desk's environment, as the CLI reads it. The statement key variables are removed. */
  env: Env;
  /** A saved `snapshot` output: every command plans from it instead of the chain (offline mode). */
  snapshotFile?: string;
  /** Positions to plan with when a request sends none and the statement store is empty. */
  positionsFile?: string;
  /** The built UI (../mova-frontend/dist, beside the monorepo), served at `/`. */
  uiDir?: string;
  nowSeconds?: () => number;
  /** Tests inject a fake chain. */
  client?: (rpcUrl: string) => DeskClient;
}

export interface DeskRun {
  exitCode: number;
  data: unknown;
  notes: string[];
}

const KEY_VARIABLES = ['MOVVA_STATEMENT_KEY', 'MOVVA_STATEMENT_KEY_FILE'] as const;
const MAX_BODY_BYTES = 256 * 1024;
const ADDRESS = /^0x[0-9a-fA-F]{40}$/;
const USDT_AMOUNT = /^\d{1,15}(\.\d{1,6})?$/;
const SEQUENCE = /^\d{1,12}$/;

/** In-memory documents are named so no real path can be mistaken for one. */
const memPath = (name: string) => `(uploaded ${name})`;

class HttpError extends Error {
  constructor(readonly status: number, message: string) {
    super(message);
  }
}

const isInt = (x: unknown, lo: number, hi: number): x is number => typeof x === 'number' && Number.isInteger(x) && x >= lo && x <= hi;

export class DeskServer {
  private readonly env: Env;
  private readonly allowedFiles: Set<string>;
  private clientCache = new Map<string, DeskClient>();

  constructor(private readonly opts: DeskServerOptions) {
    const env = { ...opts.env };
    for (const k of KEY_VARIABLES) delete env[k];
    this.env = env;
    this.allowedFiles = new Set(
      [env.MOVVA_DESK_CONFIG, opts.snapshotFile, opts.positionsFile].filter((p): p is string => !!p).map((p) => resolve(p)),
    );
  }

  /** The policy as `runDesk` will read it, or the configuration problem. */
  config(): DeskConfig {
    return deskConfigFromEnv(this.env, (p) => this.readAllowed(p));
  }

  private secrets(): string[] {
    try {
      return this.config().secrets;
    } catch {
      return [this.env.RPC_URL].filter((s): s is string => !!s);
    }
  }

  private readAllowed(path: string): string {
    const full = resolve(path);
    if (!this.allowedFiles.has(full)) throw new Error(`${path} is not a file this server was configured to read`);
    return readFileSync(full, 'utf8');
  }

  private store(): StatementStore | undefined {
    try {
      const dir = this.config().statementDir;
      return dir ? new StatementStore(dir) : undefined;
    } catch {
      return undefined;
    }
  }

  /** Runs one desk command with documents passed in memory. */
  async run(argv: string[], documents: Record<string, string> = {}): Promise<DeskRun> {
    const files = new Map(Object.entries(documents).map(([name, text]) => [memPath(name), text]));
    const read = (p: string) => files.get(p) ?? this.readAllowed(p);
    const out: string[] = [];
    const err: string[] = [];
    const io: DeskIo = {
      env: this.env,
      readFile: read,
      readBytes: (p) => new TextEncoder().encode(read(p)),
      writeFile: () => {
        throw new Error('the desk server never writes files');
      },
      stdout: (t) => { out.push(t); },
      stderr: (t) => { err.push(t); },
      nowSeconds: this.opts.nowSeconds ?? (() => Math.floor(Date.now() / 1000)),
      client: this.opts.client ?? ((url) => {
        let c = this.clientCache.get(url);
        if (!c) {
          c = createPublicClient({ transport: http(url, { timeout: 20_000, retryCount: 2 }) }) as unknown as DeskClient;
          this.clientCache.set(url, c);
        }
        return c;
      }),
    };
    const offline = this.opts.snapshotFile ? ['--snapshot', this.opts.snapshotFile] : [];
    const exitCode = await runDesk([...argv, ...offline], io);
    const text = out.join('');
    let data: unknown = null;
    if (text.trim()) {
      try {
        data = JSON.parse(text);
      } catch {
        data = text;
      }
    }
    // A usage error is followed by the CLI's usage text; the UI only needs the reason.
    const notes = err.join('').split('\n\nusage:')[0].split('\n').map((l) => l.trim()).filter(Boolean);
    return { exitCode, data, notes };
  }

  /** `--positions` from a request body, or the configured default when the store has no statement. */
  private positionsArgs(body: Record<string, unknown>, docs: Record<string, string>): string[] {
    if (body.positions !== undefined) {
      if (typeof body.positions !== 'object' || body.positions === null) throw new HttpError(400, 'positions must be a positions document (JSON)');
      docs['positions.json'] = JSON.stringify(body.positions);
      return ['--positions', memPath('positions.json')];
    }
    const store = this.store();
    if (store && store.sequences().length > 0) return [];
    return this.opts.positionsFile ? ['--positions', this.opts.positionsFile] : [];
  }

  // ---------------------------------------------------------------- routes

  info() {
    let cfg: DeskConfig | undefined;
    let problem: string | undefined;
    try {
      cfg = this.config();
    } catch (e) {
      problem = e instanceof ConfigError ? e.message : 'the desk configuration could not be read';
    }
    const store = this.store();
    return {
      mode: this.opts.snapshotFile ? 'snapshot' : 'live',
      configProblem: problem,
      rpcConfigured: !!cfg?.rpcUrl,
      chainId: cfg?.chainId,
      reserve: cfg?.reserve,
      issuer: cfg?.issuer,
      yieldRecipient: cfg?.yieldRecipient,
      statementStore: store ? { configured: true, count: store.sequences().length } : { configured: false, count: 0 },
      defaultPositions: !!this.opts.positionsFile,
      signing: 'cli-only',
      policy: cfg && {
        instruments: cfg.instruments.map((i) => ({ symbol: i.symbol, contractSizeUsd: i.contractSizeUsd.toString() })),
        tickers: cfg.tickers,
        hedgeBandBps: cfg.hedgeBandBps,
        rollWithinDays: cfg.rollWithinDays,
        executionBufferBps: cfg.executionBufferBps,
        stressMoveBps: cfg.stressMoveBps,
        initialMarginBps: cfg.initialMarginBps,
        conversionCostBps: cfg.conversionCostBps,
        statementMaxAgeSeconds: cfg.statementMaxAgeSeconds,
      },
    };
  }

  /** The positions the desk plans with by default, as a positions document: the latest statement's, or the configured file's. */
  positions() {
    const latest = this.store()?.latest();
    if (latest) {
      return {
        source: `statement #${latest.message.sequence}`,
        positions: latest.message.positions.map((p) => ({
          instrument: p.instrument, ticker: p.ticker, expiry: p.expiry, side: p.side,
          contracts: p.contracts.toString(), averagePrice: toDecimal(p.averagePriceBrlPerUsdE6, 3),
        })),
      };
    }
    if (this.opts.positionsFile) {
      const raw = JSON.parse(this.readAllowed(this.opts.positionsFile)) as { positions?: unknown };
      return { source: `positions file ${basename(this.opts.positionsFile)}`, positions: Array.isArray(raw.positions) ? raw.positions : [] };
    }
    return { source: null, positions: [] };
  }

  async snapshot(query: URLSearchParams) {
    const block = query.get('block');
    if (block !== null && !/^\d{1,12}$/.test(block)) throw new HttpError(400, 'block must be a block number');
    return this.run(['snapshot', ...(block ? ['--block', block] : [])]);
  }

  async report() {
    return this.run(['report']);
  }

  async hedgePlan(body: Record<string, unknown>) {
    const docs: Record<string, string> = {};
    return this.run(['hedge-plan', ...this.positionsArgs(body, docs)], docs);
  }

  async shock(body: Record<string, unknown>) {
    const docs: Record<string, string> = {};
    const args = ['shock', ...this.positionsArgs(body, docs)];
    if (body.moves !== undefined) {
      if (!Array.isArray(body.moves) || body.moves.length === 0 || body.moves.length > 12 || !body.moves.every((m) => isInt(m, -9_999, 9_999))) {
        throw new HttpError(400, 'moves must be 1 to 12 integers in bps, from -9999 to 9999');
      }
      // One argument, `--move=...`: as `--move -500` the parser would read a leading minus as an option.
      args.push(`--move=${body.moves.join(',')}`);
    }
    if (body.stress !== undefined) {
      if (!isInt(body.stress, 1, 9_999)) throw new HttpError(400, 'stress must be an integer from 1 to 9999 bps');
      args.push('--stress', String(body.stress));
    }
    return this.run(args, docs);
  }

  private amountAndFrom(body: Record<string, unknown>): string[] {
    const args: string[] = [];
    if (body.amount !== undefined && body.amount !== '') {
      if (typeof body.amount !== 'string' || !USDT_AMOUNT.test(body.amount)) throw new HttpError(400, 'amount must be USDT as a decimal string, e.g. "125000.50"');
      args.push('--amount', body.amount);
    }
    if (body.from !== undefined && body.from !== '') {
      if (typeof body.from !== 'string' || !ADDRESS.test(body.from)) throw new HttpError(400, 'from must be an address');
      args.push('--from', body.from);
    }
    return args;
  }

  /** `harvestYield()`: permissionless, paying only the reserve's yield recipient. `from` only sets the simulation's sender. */
  async harvestPlan(body: Record<string, unknown>) {
    const args = ['harvest-plan', '--safe'];
    if (body.from !== undefined && body.from !== '') {
      if (typeof body.from !== 'string' || !ADDRESS.test(body.from)) throw new HttpError(400, 'from must be an address');
      args.push('--from', body.from);
    }
    return this.run(args);
  }

  async recapPlan(body: Record<string, unknown>) {
    const args = ['recap-plan', '--safe', ...this.amountAndFrom(body)];
    if (body.targetBps !== undefined) {
      if (!isInt(body.targetBps, 1, 100_000)) throw new HttpError(400, 'targetBps must be a positive integer');
      args.push('--target-bps', String(body.targetBps));
    }
    return this.run(args);
  }

  statements() {
    const store = this.store();
    if (!store) return { configured: false, statements: [] };
    const statements = store.sequences().reverse().map((seq) => {
      const s = store.get(seq);
      if (!s) return { sequence: seq.toString(), unreadable: true };
      const m = s.message;
      return {
        sequence: m.sequence.toString(), hash: s.hash, issuer: m.issuer, asOf: m.asOf.toString(),
        reserveBlock: m.reserveBlock.toString(), netShortUsdE6: m.netShortUsdE6.toString(),
        marginBalanceBrlCents: m.marginBalanceBrlCents.toString(), marginRequiredBrlCents: m.marginRequiredBrlCents.toString(),
        positions: m.positions.length,
      };
    });
    return { configured: true, statements };
  }

  statement(sequence: string) {
    const store = this.store();
    if (!store) throw new HttpError(404, 'no statement store is configured (MOVVA_STATEMENT_DIR)');
    const s = store.get(BigInt(sequence));
    if (!s) throw new HttpError(404, `no statement ${sequence}`);
    return JSON.parse(toJson(statementToJson(s)));
  }

  async verify(body: Record<string, unknown>) {
    const docs: Record<string, string> = {};
    const args = ['statement', 'verify'];
    if (body.statement !== undefined) {
      if (typeof body.statement !== 'object' || body.statement === null) throw new HttpError(400, 'statement must be a statement document (JSON)');
      docs['statement.json'] = JSON.stringify(body.statement);
      args.push(memPath('statement.json'));
      if (body.previous !== undefined) {
        if (typeof body.previous !== 'object' || body.previous === null) throw new HttpError(400, 'previous must be a statement document (JSON)');
        docs['previous.json'] = JSON.stringify(body.previous);
        args.push('--previous', memPath('previous.json'));
      }
    } else if (body.sequence !== undefined) {
      if (typeof body.sequence !== 'string' || !SEQUENCE.test(body.sequence)) throw new HttpError(400, 'sequence must be a statement number');
      const store = this.store();
      const s = store?.get(BigInt(body.sequence));
      if (!s) throw new HttpError(404, `no statement ${body.sequence} in the store`);
      docs['statement.json'] = toJson(statementToJson(s));
      args.push(memPath('statement.json'));
    }
    // Neither: the store's latest, as `statement verify` does with no file.
    return this.run(args, docs);
  }

  // ---------------------------------------------------------------- HTTP

  /** The request handler `listen` serves, for a host that mounts the desk under its own server. */
  requestListener(): (req: IncomingMessage, res: ServerResponse) => void {
    return (req, res) => {
      this.handle(req, res).catch((e: unknown) => {
        const status = e instanceof HttpError ? e.status : 500;
        const message = e instanceof Error ? e.message : String(e);
        if (status === 500) process.stderr.write(`[movva-desk-serve] ${redact(message, this.secrets())}\n`);
        if (!res.headersSent) send(res, status, { ok: false, error: redact(message, this.secrets()) });
        else res.end();
      });
    };
  }

  listen(port: number, host: string): Promise<Server> {
    const server = createServer(this.requestListener());
    return new Promise((ok, fail) => {
      server.once('error', fail);
      server.listen(port, host, () => ok(server));
    });
  }

  private async handle(req: IncomingMessage, res: ServerResponse): Promise<void> {
    const url = new URL(req.url ?? '/', 'http://desk');
    const path = url.pathname;
    const method = req.method ?? 'GET';

    if (path === '/healthz') return send(res, 200, { ok: true });

    if (path.startsWith('/api/')) {
      const route = `${method} ${path}`;
      const body = method === 'POST' ? await readBody(req) : {};
      const result = await this.route(route, path, url.searchParams, body);
      if (result === undefined) throw new HttpError(404, `no route ${route}`);
      if (isRun(result)) {
        if (result.exitCode === 2) return send(res, 400, { ok: false, exitCode: 2, error: result.notes[0] ?? 'usage or configuration problem', notes: result.notes });
        return send(res, 200, { ok: result.exitCode === 0, ...result });
      }
      return send(res, 200, result);
    }

    if (method === 'GET' || method === 'HEAD') return this.serveUi(path, res);
    throw new HttpError(405, 'method not allowed');
  }

  private async route(route: string, path: string, query: URLSearchParams, body: Record<string, unknown>): Promise<unknown> {
    switch (route) {
      case 'GET /api/info': return this.info();
      case 'GET /api/snapshot': return this.snapshot(query);
      case 'GET /api/report': return this.report();
      case 'GET /api/positions': return this.positions();
      case 'POST /api/hedge-plan': return this.hedgePlan(body);
      case 'POST /api/shock': return this.shock(body);
      case 'POST /api/harvest-plan': return this.harvestPlan(body);
      case 'POST /api/recap-plan': return this.recapPlan(body);
      case 'GET /api/statements': return this.statements();
      case 'POST /api/statements/verify': return this.verify(body);
      default: {
        const m = /^GET \/api\/statements\/(\d{1,12})$/.exec(route);
        if (m) return this.statement(m[1]);
        if (path === '/api/statements/sign') throw new HttpError(403, 'signing is CLI-only: run `movva-desk statement sign` where the statement key lives');
        return undefined;
      }
    }
  }

  private serveUi(path: string, res: ServerResponse): void {
    const dir = this.opts.uiDir;
    if (!dir || !existsSync(join(dir, 'index.html'))) {
      return send(res, 404, { ok: false, error: 'the UI is not built: run `npm run build` in mova-frontend (beside the monorepo), or set MOVVA_DESK_UI_DIR' });
    }
    const root = realpathSync(dir);
    let file = resolve(root, `.${decodeURIComponent(path)}`);
    if (file !== root && !file.startsWith(root + sep)) throw new HttpError(400, 'bad path');
    if (!existsSync(file) || statSync(file).isDirectory()) file = join(root, 'index.html');
    const real = realpathSync(file);
    if (!real.startsWith(root + sep)) throw new HttpError(400, 'bad path');
    res.writeHead(200, {
      ...SECURITY_HEADERS,
      'content-type': MIME[extname(real)] ?? 'application/octet-stream',
      'cache-control': real.includes(`${sep}assets${sep}`) ? 'public, max-age=31536000, immutable' : 'no-cache',
    });
    createReadStream(real).pipe(res);
  }
}

const isRun = (x: unknown): x is DeskRun => typeof x === 'object' && x !== null && 'exitCode' in x && 'notes' in x;

const SECURITY_HEADERS = {
  'x-content-type-options': 'nosniff',
  'referrer-policy': 'no-referrer',
  'x-frame-options': 'DENY',
  'content-security-policy': "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'",
};

const MIME: Record<string, string> = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json', '.woff2': 'font/woff2',
};

function send(res: ServerResponse, status: number, body: unknown): void {
  res.writeHead(status, { ...SECURITY_HEADERS, 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
  res.end(`${toJson(body)}\n`);
}

async function readBody(req: IncomingMessage): Promise<Record<string, unknown>> {
  const type = req.headers['content-type'] ?? '';
  const chunks: Buffer[] = [];
  let size = 0;
  for await (const chunk of req) {
    size += (chunk as Buffer).length;
    if (size > MAX_BODY_BYTES) throw new HttpError(413, 'request body too large');
    chunks.push(chunk as Buffer);
  }
  const text = Buffer.concat(chunks).toString('utf8');
  if (!text.trim()) return {};
  // JSON only: a form post from another site cannot reach a route without a preflight.
  if (!type.startsWith('application/json')) throw new HttpError(415, 'send application/json');
  let parsed: unknown;
  try {
    parsed = JSON.parse(text);
  } catch {
    throw new HttpError(400, 'the body is not JSON');
  }
  if (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed)) throw new HttpError(400, 'the body must be a JSON object');
  return parsed as Record<string, unknown>;
}
