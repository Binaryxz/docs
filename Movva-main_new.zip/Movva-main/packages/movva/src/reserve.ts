/**
 * What the reserve says about itself, read at one block.
 *
 * ## One block, or the numbers do not add up
 *
 * Every figure the desk works from - the rate, the USDT held, the Movva outstanding, the ratio - is
 * read with the same `blockNumber`. Reading them at "latest" one call after another straddles
 * blocks: a mint lands between `totalUsdt()` and `liabilitiesBrlE18()`, and the ratio computed from
 * the pair is one the reserve never had. A signed statement then reconciles against a state that
 * did not exist, and nobody can reproduce it. So the snapshot is pinned to a block, carries that
 * block's hash and timestamp, and anyone with an archive node can read the same numbers again.
 *
 * ## A stale rate is a state, not an exception
 *
 * `brlPerUsdtE18()` reverts when an oracle leg is stale, and so does everything priced from it.
 * That is the reserve working as designed - mint and redeem stop rather than use a wrong price - so
 * the reader returns an `UnpricedSnapshot` naming the refusal, with every figure that does not need
 * a price (USDT held, Movva outstanding, fees, thresholds). A read that FAILS (the RPC is down) is
 * different and throws: it says nothing about the reserve.
 *
 * ## Off-hours
 *
 * With a PythFxOracle leg the rate is Pyth's FX.USD/BRL, which trades weekdays 08:00-17:00 New York time,
 * and `brlPerUsdtE18()` refuses (`StaleRate`) every weekday night and weekend - by design: value creation
 * waits for the market. Beside such a refusal the reader also reads `bandBrlPerUsdtE18()`, which serves the
 * last close while the market is closed, into `band`. It is shown - `snapshot` prints it, and `report` prices
 * at it and says so (`atLastClose`) - and never planned from: hedge plans, shocks, harvests,
 * recapitalizations and statements price at the live rate only, and wait for the reopening with a message
 * that says why (`ReserveUnpriced`). A stale leg refuses the band too, so it never shows as a closed market.
 *
 * ## Checking the reserve's arithmetic
 *
 * The reserve reports derived figures (`reserveBrlE18`, `liabilitiesUsdt`, the ratio, the surplus)
 * alongside the inputs they derive from. The snapshot recomputes each from the inputs and records
 * any disagreement beyond rounding in `inconsistencies`. An empty list is what a correct reserve
 * produces; anything else is a units or rounding bug in the contract - or in this package - that
 * must be understood before a statement is signed against it.
 *
 * ## The principal-locked reserve (client rule, 21 October 2026)
 *
 * The reserve's USDT leaves only by redemption and, above `max(principalUsdt, liabilities at the target)`, by
 * `harvestYield` to the fixed `yieldRecipient`. There is no hedge withdrawal, treasurer or hedge treasury to read:
 * the hedge's margin is Mova's own capital. The snapshot carries the principal, the yield recipient and - when the
 * rate prices - the reserve's own `harvestableYield()`, and checks that last one against the formula.
 */
import {
  BaseError, ContractFunctionRevertedError, ContractFunctionZeroDataError, getAddress, type Address, type Hex, type PublicClient,
} from 'viem';
import { MOVVA_RESERVE_ABI } from './abi.js';
import { Fields } from './json.js';
import { BPS, E6, UINT256_MAX, abs, ceilDiv, formatRate, max } from './units.js';

export type ReserveClient = Pick<PublicClient, 'readContract' | 'getBlock'>;

export interface ReserveThresholds {
  targetCollateralRatioBps: number;
  minMintCollateralRatioBps: number;
}

/** The principal-locked reserve's yield views. */
export interface ReserveYield {
  /** The cost basis: USDT in through mint and recapitalize, less out through redeem. 6 decimals. */
  principalUsdt: bigint;
  /** Mova's Safe: the only address `harvestYield` pays. */
  recipient: Address;
  /** `harvestableYield()`, read only when the rate prices (the view refuses otherwise). 6 decimals. */
  harvestableUsdt?: bigint;
}

export interface ReserveFees {
  mintFeeBps: number;
  redeemFeeBps: number;
}

interface SnapshotBase {
  reserve: Address;
  blockNumber: bigint;
  blockHash: Hex;
  blockTimestamp: bigint;
  movva: Address;
  usdt: Address;
  /** USDT held, idle plus the yield position's conservative redemption value. 6 decimals. */
  totalUsdt: bigint;
  /** Movva in circulation, in reais. 18 decimals. */
  liabilitiesBrlE18: bigint;
  fees: ReserveFees;
  thresholds: ReserveThresholds;
  /** The principal, the yield recipient and the harvestable yield. Undefined against a reserve without these views. */
  yield?: ReserveYield;
}

export interface PricedSnapshot extends SnapshotBase {
  priced: true;
  brlPerUsdtE18: bigint;
  rateUpdatedAt: bigint;
  reserveBrlE18: bigint;
  /** The dollar amount to hedge. 6 decimals. */
  liabilitiesUsdt: bigint;
  /** `UINT256_MAX` with no supply. */
  collateralRatioBps: bigint;
  surplusBrlE18: bigint;
  /** Derived figures that disagree with their inputs beyond rounding. Empty on a correct reserve. */
  inconsistencies: string[];
}

export interface UnpricedSnapshot extends SnapshotBase {
  priced: false;
  /** The decoded revert of `brlPerUsdtE18()`, e.g. `StaleLeg(0x..., 1789...)`, or `StaleRate(1789...)` at night. */
  refusal: string;
  /**
   * `bandBrlPerUsdtE18()` beside the refusal, when it prices: the rate as the ramps' band reads it - while the
   * FX market is closed, the last close, stamped with the block's time. Display only (see "Off-hours").
   */
  band?: { brlPerUsdtE18: bigint; updatedAt: bigint };
}

export type ReserveSnapshot = PricedSnapshot | UnpricedSnapshot;

export class ReserveUnpriced extends Error {
  constructor(readonly snapshot: UnpricedSnapshot) {
    super(snapshot.band
      ? `the reserve refuses to price at block ${snapshot.blockNumber} (${snapshot.refusal}): the FX market is closed. Its band reads the last close, `
        + `${formatRate(snapshot.band.brlPerUsdtE18, 18)} per USDT, but hedges, harvests, recapitalizations and statements are sized at the live `
        + 'rate only: plan once the market reopens (08:00 New York time on a weekday). `report` works meanwhile, at the last close'
      : `the reserve refuses to price at block ${snapshot.blockNumber}: ${snapshot.refusal}. `
        + 'Nothing that depends on the rate can be planned until both oracle legs are fresh');
  }
}

/**
 * The reserve's deployment defaults (docs/movva.md, after the 14 September 2026 shock review): target 108%, mint
 * floor 100%. The desk plans from what a snapshot reads, never from these; they seed examples and models.
 */
export const DEFAULT_RESERVE_THRESHOLDS: ReserveThresholds = {
  targetCollateralRatioBps: 10_800, minMintCollateralRatioBps: 10_000,
};

/**
 * Ratios in the wrong order. The reserve refuses them (`setCollateralRatios` requires minMint <= target,
 * `RatiosOutOfOrder()`), but a hand-edited file or a model can still carry them.
 */
export function thresholdWarnings(t: ReserveThresholds): string[] {
  const pct = (bps: number) => `${(bps / 100).toFixed(2)}%`;
  return t.minMintCollateralRatioBps > t.targetCollateralRatioBps
    ? [`RATIOS OUT OF ORDER: the mint floor ${pct(t.minMintCollateralRatioBps)} is above the target ${pct(t.targetCollateralRatioBps)}: `
      + 'the reserve should enforce minMint <= target (RatiosOutOfOrder)']
    : [];
}

/**
 * USDT no harvest takes the reserve below: max(principal, the liabilities' USDT at the target ratio), the latter
 * `ceil(supply x target x 1e6 / (rate x 1e4))` exactly as MovvaReserve computes it (rounded up: the floor errs high).
 */
export function harvestFloorUsdt(principalUsdt: bigint, liabilitiesBrlE18: bigint, brlPerUsdtE18: bigint, targetBps: number): bigint {
  const atTarget = ceilDiv(liabilitiesBrlE18 * BigInt(targetBps) * E6, brlPerUsdtE18 * BPS);
  return max(principalUsdt, atTarget);
}

/** What `harvestableYield()` should answer: `totalUsdt` above the harvest floor, zero at or below it. */
export function expectedHarvestableUsdt(
  s: Pick<PricedSnapshot, 'totalUsdt' | 'liabilitiesBrlE18' | 'brlPerUsdtE18' | 'thresholds'>, principalUsdt: bigint,
): bigint {
  return max(0n, s.totalUsdt - harvestFloorUsdt(principalUsdt, s.liabilitiesBrlE18, s.brlPerUsdtE18, s.thresholds.targetCollateralRatioBps));
}

export function requirePriced(s: ReserveSnapshot): PricedSnapshot {
  if (!s.priced) throw new ReserveUnpriced(s);
  return s;
}

/**
 * The contract itself refused, as opposed to the read failing. Undefined for anything else, which
 * the caller should treat as "could not read".
 */
export function revertReason(e: unknown): string | undefined {
  if (!(e instanceof BaseError)) return undefined;
  const r = e.walk((x) => x instanceof ContractFunctionRevertedError);
  if (!(r instanceof ContractFunctionRevertedError)) return undefined;
  const d = r.data;
  return d ? `${d.errorName}(${(d.args ?? []).map(String).join(', ')})` : (r.reason ?? r.signature ?? 'no reason');
}

/** Read the reserve at `blockNumber` (default: the latest block, pinned once). */
export async function readReserveSnapshot(
  client: ReserveClient, reserveAddress: Address, opts: { blockNumber?: bigint } = {},
): Promise<ReserveSnapshot> {
  const reserve = getAddress(reserveAddress);
  const block = opts.blockNumber === undefined
    ? await client.getBlock({ blockTag: 'latest' })
    : await client.getBlock({ blockNumber: opts.blockNumber });
  if (block.number === null || block.hash === null) throw new Error('the RPC returned a pending block');
  const blockNumber = block.number;

  type Fn = typeof MOVVA_RESERVE_ABI[number] & { type: 'function' };
  const read = <T>(functionName: Fn['name']): Promise<T> =>
    client.readContract({ address: reserve, abi: MOVVA_RESERVE_ABI, functionName, blockNumber } as never) as Promise<T>;

  const [movva, usdt, totalUsdt, liabilitiesBrlE18, mintFeeBps, redeemFeeBps,
    targetCollateralRatioBps, minMintCollateralRatioBps] = await Promise.all([
    read<Address>('MOVVA'), read<Address>('USDT'), read<bigint>('totalUsdt'), read<bigint>('liabilitiesBrlE18'),
    read<number>('mintFeeBps'), read<number>('redeemFeeBps'),
    read<number>('targetCollateralRatioBps'), read<number>('minMintCollateralRatioBps'),
  ]);
  const base: SnapshotBase = {
    reserve, blockNumber, blockHash: block.hash, blockTimestamp: block.timestamp, movva, usdt, totalUsdt, liabilitiesBrlE18,
    fees: { mintFeeBps, redeemFeeBps },
    thresholds: { targetCollateralRatioBps, minMintCollateralRatioBps },
  };
  try {
    const [principalUsdt, recipient] = await Promise.all([read<bigint>('principalUsdt'), read<Address>('yieldRecipient')]);
    base.yield = { principalUsdt, recipient };
  } catch (e) {
    // A reserve that predates the principal-locked views (the hedge-withdrawal reserve of before 21 October 2026)
    // has no such function. A read that FAILED (the RPC) still throws: it says nothing about the reserve.
    if (!isMissingView(e)) throw e;
  }

  let rate: readonly [bigint, bigint];
  try {
    rate = await read<readonly [bigint, bigint]>('brlPerUsdtE18');
  } catch (e) {
    const refusal = revertReason(e);
    if (refusal === undefined) throw e;
    const band = await bandBeside(() => read<readonly [bigint, bigint]>('bandBrlPerUsdtE18'));
    return band ? { ...base, priced: false, refusal, band } : { ...base, priced: false, refusal };
  }
  const [reserveBrlE18, liabilitiesUsdt, collateralRatioBps, surplusBrlE18, harvestableUsdt] = await Promise.all([
    read<bigint>('reserveBrlE18'), read<bigint>('liabilitiesUsdt'), read<bigint>('collateralRatioBps'), read<bigint>('surplusBrlE18'),
    base.yield ? read<bigint>('harvestableYield') : Promise.resolve(undefined),
  ]);
  if (base.yield && harvestableUsdt !== undefined) base.yield = { ...base.yield, harvestableUsdt };
  const priced: PricedSnapshot = {
    ...base, priced: true, brlPerUsdtE18: rate[0], rateUpdatedAt: rate[1],
    reserveBrlE18, liabilitiesUsdt, collateralRatioBps, surplusBrlE18, inconsistencies: [],
  };
  priced.inconsistencies = inconsistencies(priced);
  return priced;
}

/**
 * The band's reading beside a refused rate, or undefined when the band refuses too (a stale leg) or the reserve
 * predates it (no such view). A read that failed throws, as any other.
 */
async function bandBeside(read: () => Promise<readonly [bigint, bigint]>): Promise<UnpricedSnapshot['band']> {
  try {
    const [brlPerUsdtE18, updatedAt] = await read();
    return { brlPerUsdtE18, updatedAt };
  } catch (e) {
    if (isMissingView(e)) return undefined;
    throw e;
  }
}

/** The contract refused or has no such function, as opposed to the read failing. */
function isMissingView(e: unknown): boolean {
  return e instanceof BaseError && !!e.walk((x) => x instanceof ContractFunctionRevertedError || x instanceof ContractFunctionZeroDataError);
}

/**
 * An unpriced snapshot priced at its band's last close, each figure computed as the reserve computes it (reais
 * and the ratio rounded down, `liabilitiesUsdt` up). For `report` while the FX market is closed, which labels
 * it - never for a plan or a statement. Throws `ReserveUnpriced` when there is no band reading to price at.
 */
export function atLastClose(s: UnpricedSnapshot): PricedSnapshot {
  if (!s.band) throw new ReserveUnpriced(s);
  const S = s.band.brlPerUsdtE18;
  const L = s.liabilitiesBrlE18;
  const reserveBrlE18 = s.totalUsdt * S / E6;
  const priced: Omit<PricedSnapshot, 'inconsistencies'> = {
    reserve: s.reserve, blockNumber: s.blockNumber, blockHash: s.blockHash, blockTimestamp: s.blockTimestamp, movva: s.movva, usdt: s.usdt,
    totalUsdt: s.totalUsdt, liabilitiesBrlE18: L, fees: s.fees, thresholds: s.thresholds,
    // The harvestable figure is the reserve's at the live rate: at the band's last close only the basis is shown.
    ...(s.yield ? { yield: { principalUsdt: s.yield.principalUsdt, recipient: s.yield.recipient } } : {}),
    priced: true, brlPerUsdtE18: S, rateUpdatedAt: s.band.updatedAt, reserveBrlE18,
    liabilitiesUsdt: ceilDiv(L * E6, S),
    collateralRatioBps: L === 0n ? UINT256_MAX : reserveBrlE18 * BPS / L,
    surplusBrlE18: max(0n, reserveBrlE18 - ceilDiv(L * BigInt(s.thresholds.targetCollateralRatioBps), BPS)),
  };
  return { ...priced, inconsistencies: inconsistencies(priced) };
}

/** What each derived figure should be, from the inputs, and how far rounding may move it. */
export function inconsistencies(s: Omit<PricedSnapshot, 'inconsistencies'>): string[] {
  const out: string[] = [];
  const S = s.brlPerUsdtE18;
  if (S === 0n) return ['the rate is zero'];
  const L = s.liabilitiesBrlE18;

  const reserve = s.totalUsdt * S / E6;
  // One micro-USDT's worth of reais, plus a wei, either way.
  if (abs(s.reserveBrlE18 - reserve) > S / E6 + 1n) {
    out.push(`reserveBrlE18 is ${s.reserveBrlE18}, but totalUsdt x rate is ${reserve}`);
  }
  const liabUsdt = L * E6 / S;
  if (abs(s.liabilitiesUsdt - liabUsdt) > 1n) {
    out.push(`liabilitiesUsdt is ${s.liabilitiesUsdt}, but liabilitiesBrlE18 / rate is ${liabUsdt}`);
  }
  const ratio = L === 0n ? UINT256_MAX : s.reserveBrlE18 * BPS / L;
  if (L === 0n ? s.collateralRatioBps !== UINT256_MAX : abs(s.collateralRatioBps - ratio) > 1n) {
    out.push(`collateralRatioBps is ${s.collateralRatioBps}, but reserve / liabilities is ${ratio}`);
  }
  const surplus = max(0n, s.reserveBrlE18 - ceilDiv(L * BigInt(s.thresholds.targetCollateralRatioBps), BPS));
  if (abs(s.surplusBrlE18 - surplus) > s.reserveBrlE18 / 1_000_000_000n + 10n ** 12n) {
    out.push(`surplusBrlE18 is ${s.surplusBrlE18}, but reserve above target is ${surplus}`);
  }
  if (s.yield?.harvestableUsdt !== undefined) {
    const h = expectedHarvestableUsdt(s, s.yield.principalUsdt);
    // The reserve computes it from the same figures; one micro-USDT either way for the vault's own rounding.
    if (abs(s.yield.harvestableUsdt - h) > 1n) {
      out.push(`harvestableYield is ${s.yield.harvestableUsdt}, but totalUsdt above max(principal, the target's liabilities) is ${h}`);
    }
    if (s.yield.harvestableUsdt > max(0n, s.totalUsdt - s.yield.principalUsdt)) {
      out.push(`harvestableYield ${s.yield.harvestableUsdt} reaches into the principal ${s.yield.principalUsdt}`);
    }
  }
  return out;
}

/** Parse a snapshot saved by `movva-desk snapshot`, for planning offline. Strict: every field. */
export function snapshotFromJson(raw: unknown): ReserveSnapshot {
  const f = new Fields();
  const o = f.obj(raw, 'snapshot');
  const fees = f.obj(o.fees, 'snapshot.fees');
  const th = f.obj(o.thresholds, 'snapshot.thresholds');
  const base: SnapshotBase = {
    reserve: f.address(o, 'reserve', 'snapshot'),
    blockNumber: f.big(o, 'blockNumber', 'snapshot'),
    blockHash: f.hex32(o, 'blockHash', 'snapshot'),
    blockTimestamp: f.big(o, 'blockTimestamp', 'snapshot'),
    movva: f.address(o, 'movva', 'snapshot'),
    usdt: f.address(o, 'usdt', 'snapshot'),
    totalUsdt: f.big(o, 'totalUsdt', 'snapshot'),
    liabilitiesBrlE18: f.big(o, 'liabilitiesBrlE18', 'snapshot'),
    fees: {
      mintFeeBps: f.int(fees, 'mintFeeBps', 'snapshot.fees', undefined, [0, 65_535]),
      redeemFeeBps: f.int(fees, 'redeemFeeBps', 'snapshot.fees', undefined, [0, 65_535]),
    },
    thresholds: {
      targetCollateralRatioBps: f.int(th, 'targetCollateralRatioBps', 'snapshot.thresholds', undefined, [0, 65_535]),
      minMintCollateralRatioBps: f.int(th, 'minMintCollateralRatioBps', 'snapshot.thresholds', undefined, [0, 65_535]),
    },
  };
  // A snapshot of the reserve before 21 October 2026 describes hedge withdrawals that no longer exist: refused by
  // name, rather than planned from as if the reserve could still pay margin.
  if (o.hedge !== undefined || th.minWithdrawCollateralRatioBps !== undefined) {
    f.problems.push('snapshot.hedge / snapshot.thresholds.minWithdrawCollateralRatioBps: a snapshot of a reserve with hedge withdrawals, '
      + 'removed with the principal-locked reserve (21 October 2026); take a new snapshot');
  }
  if (o.yield !== undefined) {
    const y = f.obj(o.yield, 'snapshot.yield');
    base.yield = {
      principalUsdt: f.big(y, 'principalUsdt', 'snapshot.yield'),
      recipient: f.address(y, 'recipient', 'snapshot.yield'),
      ...(y.harvestableUsdt === undefined ? {} : { harvestableUsdt: f.big(y, 'harvestableUsdt', 'snapshot.yield') }),
    };
  }
  if (o.priced === false) {
    const refusal = f.str(o, 'refusal', 'snapshot');
    let band: UnpricedSnapshot['band'];
    if (o.band !== undefined) {
      const b = f.obj(o.band, 'snapshot.band');
      band = { brlPerUsdtE18: f.big(b, 'brlPerUsdtE18', 'snapshot.band'), updatedAt: f.big(b, 'updatedAt', 'snapshot.band') };
    }
    f.done('snapshot');
    return band ? { ...base, priced: false, refusal, band } : { ...base, priced: false, refusal };
  }
  if (o.priced !== true) f.problems.push('snapshot.priced must be true or false');
  const priced: Omit<PricedSnapshot, 'inconsistencies'> = {
    ...base, priced: true,
    brlPerUsdtE18: f.big(o, 'brlPerUsdtE18', 'snapshot'),
    rateUpdatedAt: f.big(o, 'rateUpdatedAt', 'snapshot'),
    reserveBrlE18: f.big(o, 'reserveBrlE18', 'snapshot'),
    liabilitiesUsdt: f.big(o, 'liabilitiesUsdt', 'snapshot'),
    collateralRatioBps: f.big(o, 'collateralRatioBps', 'snapshot'),
    surplusBrlE18: f.big(o, 'surplusBrlE18', 'snapshot'),
  };
  f.done('snapshot');
  // Recomputed, never trusted from the file: a hand-edited snapshot is exactly what this catches.
  return { ...priced, inconsistencies: inconsistencies(priced) };
}

/**
 * A priced snapshot of a hypothetical reserve, computing the derived figures the way the
 * interface documents them. For the shock walk-through, examples and tests - never for a
 * statement, which must reconcile against the chain.
 */
export function modelSnapshot(p: {
  brlPerUsdtE18: bigint; totalUsdt: bigint; liabilitiesBrlE18: bigint;
  thresholds?: Partial<ReserveThresholds>; fees?: Partial<ReserveFees>;
  reserve?: Address; blockNumber?: bigint; blockTimestamp?: bigint;
  /** The principal and yield recipient; `harvestableUsdt` is computed from the formula. Omit for a reserve without them. */
  yield?: { principalUsdt: bigint; recipient?: Address };
}): PricedSnapshot {
  const thresholds: ReserveThresholds = { ...DEFAULT_RESERVE_THRESHOLDS, ...p.thresholds };
  const reserveBrlE18 = p.totalUsdt * p.brlPerUsdtE18 / E6;
  const L = p.liabilitiesBrlE18;
  const s: Omit<PricedSnapshot, 'inconsistencies'> = {
    reserve: p.reserve ?? '0x000000000000000000000000000000000000dEaD',
    blockNumber: p.blockNumber ?? 0n, blockHash: `0x${'00'.repeat(32)}`, blockTimestamp: p.blockTimestamp ?? 0n,
    movva: '0x0000000000000000000000000000000000000000', usdt: '0x0000000000000000000000000000000000000000',
    totalUsdt: p.totalUsdt, liabilitiesBrlE18: L,
    fees: { mintFeeBps: 0, redeemFeeBps: 0, ...p.fees },
    thresholds, priced: true, brlPerUsdtE18: p.brlPerUsdtE18, rateUpdatedAt: p.blockTimestamp ?? 0n,
    reserveBrlE18,
    liabilitiesUsdt: L * E6 / p.brlPerUsdtE18,
    collateralRatioBps: L === 0n ? UINT256_MAX : reserveBrlE18 * BPS / L,
    surplusBrlE18: max(0n, reserveBrlE18 - ceilDiv(L * BigInt(thresholds.targetCollateralRatioBps), BPS)),
  };
  if (p.yield) {
    s.yield = {
      principalUsdt: p.yield.principalUsdt, recipient: p.yield.recipient ?? '0x000000000000000000000000000000000000bEEF',
      harvestableUsdt: expectedHarvestableUsdt(s, p.yield.principalUsdt),
    };
  }
  return { ...s, inconsistencies: inconsistencies(s) };
}
