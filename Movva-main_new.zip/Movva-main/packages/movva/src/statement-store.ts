/**
 * The desk's statements on disk: one file per sequence number, plus `latest.json` to publish.
 *
 * ## Why files, and why exclusive creation
 *
 * A statement chain is only as good as the rule that there is ONE statement per sequence number.
 * Two signed statements with the same `sequence` and `previousStatementHash` are a fork, and a fork
 * is indistinguishable from the issuer rewriting history - which is what the chain exists to make
 * visible. So `append` creates `statement-<sequence>.json` with O_EXCL: a second desk, a retried
 * command or a person re-running yesterday's signing cannot overwrite a statement already issued,
 * and a statement that does not link to the latest on disk is refused before it is written.
 * (It is refused before it is SIGNED, too, by the CLI reading `latest()` as `previous`.)
 *
 * Each file is fsynced before the call returns. `latest.json` is written to a temporary name and
 * renamed over, so a reader - the web server publishing it, the monitor fetching it - never sees a
 * half-written statement.
 *
 * The directory holds nothing secret: every statement is meant to be published.
 */
import {
  closeSync, existsSync, fsyncSync, mkdirSync, openSync, readFileSync, readdirSync, renameSync, writeSync,
} from 'node:fs';
import { join } from 'node:path';
import { toJson } from './json.js';
import { statementFromJson, statementToJson, type SignedStatement } from './statement.js';

const NAME = /^statement-(\d{12})\.json$/;

export class StatementStore {
  constructor(readonly dir: string) {}

  private file(sequence: bigint): string {
    return join(this.dir, `statement-${sequence.toString().padStart(12, '0')}.json`);
  }

  sequences(): bigint[] {
    if (!existsSync(this.dir)) return [];
    return readdirSync(this.dir).map((f) => NAME.exec(f)?.[1]).filter((x): x is string => !!x).map(BigInt)
      .sort((a, b) => (a < b ? -1 : a > b ? 1 : 0));
  }

  get(sequence: bigint): SignedStatement | undefined {
    const f = this.file(sequence);
    return existsSync(f) ? statementFromJson(JSON.parse(readFileSync(f, 'utf8'))) : undefined;
  }

  latest(): SignedStatement | undefined {
    const seqs = this.sequences();
    return seqs.length ? this.get(seqs[seqs.length - 1]) : undefined;
  }

  /** Durably add the next statement. Refuses a gap, a fork or an overwrite. */
  append(s: SignedStatement): string {
    const latest = this.latest();
    const seq = s.message.sequence;
    if (latest) {
      if (seq !== latest.message.sequence + 1n || s.message.previousStatementHash !== latest.hash) {
        throw new Error(`statement ${seq} does not extend the latest on disk (${latest.message.sequence}, ${latest.hash}): refusing to fork the chain`);
      }
    } else if (seq !== 1n) {
      throw new Error(`the store is empty, so the next statement is sequence 1, not ${seq}`);
    }
    mkdirSync(this.dir, { recursive: true, mode: 0o755 });
    const text = `${toJson(statementToJson(s))}\n`;
    const path = this.file(seq);
    writeDurably(path, text, 'wx');
    const tmp = join(this.dir, `.latest.${process.pid}.tmp`);
    writeDurably(tmp, text, 'w');
    renameSync(tmp, join(this.dir, 'latest.json'));
    return path;
  }
}

function writeDurably(path: string, text: string, flags: 'wx' | 'w'): void {
  const fd = openSync(path, flags, 0o644);
  try {
    const buf = Buffer.from(text, 'utf8');
    let written = 0;
    while (written < buf.length) written += writeSync(fd, buf, written);
    fsyncSync(fd);
  } finally {
    closeSync(fd);
  }
}
