/**
 * The backing report: what backs a Movva right now, on-chain and - honestly labelled - off it.
 *
 * ## Three numbers, because one would mislead
 *
 *  1. **Reserve ratio** - `collateralRatioBps()` at a block. Everyone can check it; it is also the
 *     number that swings with USD/BRL, because the reserve is dollars and the liabilities are reais.
 *     On its own it overstates backing after a dollar rally and understates it after a fall.
 *  2. **Hedge ratio** - the latest VERIFIED statement's net short against today's `liabilitiesUsdt`.
 *     Signed by the issuer, bound to the broker's document by hash, reconciled against a reserve
 *     block. Still the issuer's word.
 *  3. **Backing if the hedge holds** - the reserve in reais, plus what the short has gained or lost
 *     since the statement's snapshot (its notional times the rate move since), plus the free margin
 *     the statement reports (balance above requirement; negative if the account is short of margin).
 *     It is what the reserve would be worth if every hedge gain came back through `recapitalize`
 *     and every loss had been met, at today's rate. It is conditional on the issuer doing that,
 *     which is exactly why it is published next to the first number and never instead of it.
 *
 * Without a verified statement there is no second or third number - not a number computed from an
 * unverified or stale one. The report says why, and the reserve ratio stands alone.
 *
 * ## At night
 *
 * With a PythFxOracle leg the reserve refuses to price while the FX market is closed. A report is a display,
 * not a plan, so it is still made - at the band's last close (`atLastClose` in reserve.ts), every figure
 * computed as the reserve computes it - and `snapshot.rateSource` is `band`, which the text says in words.
 *
 * What none of the numbers covers is listed in `caveats` and printed in the text summary: the
 * USDT/USD basis (B3 hedges dollars, the reserve holds USDT), futures basis against the reserve's
 * rate, conversion costs, and the broker's own solvency.
 */
import type { Address, Hex } from 'viem';
import { hedgeRatioBps, withinBand } from './hedge.js';
import type { PricedSnapshot } from './reserve.js';
import type { SignedStatement, StatementVerification } from './statement.js';
import {
  BPS, E6, UINT256_MAX, centsToBrlE18, formatBps, formatBrl, formatRate, formatUsd, formatUsdt, truncDiv,
} from './units.js';

export const REPORT_FORMAT = 'movva-backing-report/v1';

export interface BackingReport {
  format: typeof REPORT_FORMAT;
  generatedAt: number;
  chainId: number;
  reserve: Address;
  snapshot: {
    blockNumber: bigint; blockHash: Hex; blockTimestamp: bigint;
    brlPerUsdtE18: bigint; rateUpdatedAt: bigint;
    /** `rate`: the reserve's live rate. `band`: its band's last close, while the FX market is closed. */
    rateSource: 'rate' | 'band';
    totalUsdt: bigint; reserveBrlE18: bigint; liabilitiesBrlE18: bigint; liabilitiesUsdt: bigint;
    collateralRatioBps: bigint; targetCollateralRatioBps: number; surplusBrlE18: bigint;
    inconsistencies: string[];
  };
  reserveRatioBps: bigint;
  statement: {
    sequence: bigint; hash: Hex; issuer: Address; asOf: bigint; ageSeconds: number; reserveBlock: bigint;
    brokerStatementSha256: Hex; valid: boolean; problems: string[]; warnings: string[];
  } | null;
  hedge: {
    netShortUsdE6: bigint; targetUsdE6: bigint; hedgeRatioBps: bigint | null; bandBps: number; withinBand: boolean;
    unhedgedUsdE6: bigint;
  } | null;
  backingIfHedgeHolds: {
    brlE18: bigint; ratioBps: bigint;
    components: { reserveBrlE18: bigint; hedgeVariationSinceStatementBrlE18: bigint; freeMarginBrlE18: bigint };
  } | null;
  /** Why the hedge figures are absent, when they are. */
  unavailable?: string;
  caveats: string[];
}

export const REPORT_CAVEATS = [
  'Positions and margin are signed claims by the issuer, bound to the broker statement by SHA-256; nothing on-chain can read a broker account.',
  'B3 dollar futures hedge USD/BRL. The reserve holds USDT: a USDT depeg reaches the reserve ratio and is not hedged.',
  'Hedge variation is estimated from the reserve\'s own rate; futures settle against their own price, which differs by the basis.',
  'USDT/BRL conversion costs, broker fees and the time to move funds are not deducted.',
  'Free margin is the issuer\'s cash at the broker above the requirement; counting it assumes it is brought back to the reserve.',
];

export function backingReport(p: {
  chainId: number;
  snapshot: PricedSnapshot;
  statement?: SignedStatement;
  verification?: StatementVerification;
  bandBps: number;
  nowSeconds: number;
  /** Which reading `snapshot` is priced at. Default `rate`. */
  rateSource?: 'rate' | 'band';
}): BackingReport {
  const s = p.snapshot;
  const L = s.liabilitiesBrlE18;
  const report: BackingReport = {
    format: REPORT_FORMAT, generatedAt: p.nowSeconds, chainId: p.chainId, reserve: s.reserve,
    snapshot: {
      blockNumber: s.blockNumber, blockHash: s.blockHash, blockTimestamp: s.blockTimestamp,
      brlPerUsdtE18: s.brlPerUsdtE18, rateUpdatedAt: s.rateUpdatedAt, rateSource: p.rateSource ?? 'rate',
      totalUsdt: s.totalUsdt, reserveBrlE18: s.reserveBrlE18, liabilitiesBrlE18: L, liabilitiesUsdt: s.liabilitiesUsdt,
      collateralRatioBps: s.collateralRatioBps, targetCollateralRatioBps: s.thresholds.targetCollateralRatioBps,
      surplusBrlE18: s.surplusBrlE18, inconsistencies: s.inconsistencies,
    },
    reserveRatioBps: s.collateralRatioBps,
    statement: null, hedge: null, backingIfHedgeHolds: null,
    caveats: REPORT_CAVEATS,
  };

  if (!p.statement || !p.verification) {
    report.unavailable = 'no hedge statement was supplied: only the on-chain reserve ratio is reported';
    return report;
  }
  const m = p.statement.message;
  const v = p.verification;
  report.statement = {
    sequence: m.sequence, hash: v.hash, issuer: m.issuer, asOf: m.asOf, ageSeconds: v.ageSeconds, reserveBlock: m.reserveBlock,
    brokerStatementSha256: m.brokerStatementSha256, valid: v.valid, problems: v.problems, warnings: v.warnings,
  };
  if (!v.valid) {
    report.unavailable = `the latest statement did not verify (${v.problems.join('; ')}): no hedge figure is reported from it`;
    return report;
  }
  if (s.inconsistencies.length) {
    report.unavailable = `the reserve's own figures disagree (${s.inconsistencies.join('; ')}): no combined figure is reported`;
    return report;
  }

  const H = m.netShortUsdE6;
  const target = s.liabilitiesUsdt;
  report.hedge = {
    netShortUsdE6: H, targetUsdE6: target, hedgeRatioBps: hedgeRatioBps(H, target) ?? null,
    bandBps: p.bandBps, withinBand: withinBand(H, target, p.bandBps), unhedgedUsdE6: target - H,
  };
  // The short gains when the rate falls: -H x (S_now - S_statement), reais at 18 decimals.
  const variation = -truncDiv(H * (s.brlPerUsdtE18 - m.reserveBrlPerUsdtE18), E6);
  const freeMargin = centsToBrlE18(m.marginBalanceBrlCents - m.marginRequiredBrlCents);
  const brl = s.reserveBrlE18 + variation + freeMargin;
  report.backingIfHedgeHolds = {
    brlE18: brl,
    ratioBps: L === 0n ? UINT256_MAX : (brl < 0n ? 0n : brl * BPS / L),
    components: { reserveBrlE18: s.reserveBrlE18, hedgeVariationSinceStatementBrlE18: variation, freeMarginBrlE18: freeMargin },
  };
  return report;
}

const iso = (seconds: bigint | number) => new Date(Number(seconds) * 1000).toISOString().replace('.000Z', 'Z');
const hours = (s: number) => (s < 3600 ? `${Math.floor(s / 60)} min` : `${(s / 3600).toFixed(1)} h`);

/** A dozen lines for a person: the same figures as the JSON, never different ones. */
export function reportText(r: BackingReport): string {
  const s = r.snapshot;
  const lines = [
    `Movva backing report - chain ${r.chainId}, reserve ${r.reserve}`,
    `Block             ${s.blockNumber} (${iso(s.blockTimestamp)})`,
    s.rateSource === 'band'
      ? `Rate              ${formatRate(s.brlPerUsdtE18, 18)} per USDT - the LAST CLOSE, as the band reads it: the FX market is closed and the reserve prices nothing until it reopens`
      : `Rate              ${formatRate(s.brlPerUsdtE18, 18)} per USDT (oracle updated ${iso(s.rateUpdatedAt)})`,
    `Reserve           ${formatUsdt(s.totalUsdt)} = ${formatBrl(s.reserveBrlE18)}`,
    `Liabilities       ${formatBrl(s.liabilitiesBrlE18)} of Movva = ${formatUsd(s.liabilitiesUsdt)}`,
    `Reserve ratio     ${formatBps(r.reserveRatioBps)} (target ${formatBps(s.targetCollateralRatioBps)})`,
  ];
  if (s.inconsistencies.length) lines.push(`WARNING           the reserve's figures disagree: ${s.inconsistencies.join('; ')}`);
  if (r.statement) {
    lines.push(`Statement         #${r.statement.sequence}, as of ${iso(r.statement.asOf)} (${hours(r.statement.ageSeconds)} old), `
      + `${r.statement.valid ? 'verified' : 'DID NOT VERIFY'}; broker document sha256 ${r.statement.brokerStatementSha256}`);
  }
  if (r.hedge && r.backingIfHedgeHolds) {
    const b = r.backingIfHedgeHolds;
    lines.push(
      `Hedge             short ${formatUsd(r.hedge.netShortUsdE6)} against ${formatUsd(r.hedge.targetUsdE6)} to hedge`,
      `Hedge ratio       ${r.hedge.hedgeRatioBps === null ? 'n/a (nothing to hedge)' : formatBps(r.hedge.hedgeRatioBps)} `
        + `(policy ±${formatBps(r.hedge.bandBps)}: ${r.hedge.withinBand ? 'inside' : 'OUTSIDE'})`,
      `If the hedge holds ${formatBps(b.ratioBps)} = reserve ${formatBrl(b.components.reserveBrlE18)} `
        + `${sign(b.components.hedgeVariationSinceStatementBrlE18)} hedge since statement ${formatBrl(abs(b.components.hedgeVariationSinceStatementBrlE18))} `
        + `${sign(b.components.freeMarginBrlE18)} free margin ${formatBrl(abs(b.components.freeMarginBrlE18))}`,
    );
  } else {
    lines.push(`Hedge             not reported: ${r.unavailable}`);
  }
  lines.push('Not covered by these figures:', ...r.caveats.map((c) => `  - ${c}`));
  return `${lines.join('\n')}\n`;
}

const sign = (x: bigint) => (x < 0n ? '-' : '+');
const abs = (x: bigint) => (x < 0n ? -x : x);
