/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  ContractFunctionExecutionError, ContractFunctionRevertedError, encodeErrorResult, getAddress, keccak256, parseAbi, toHex,
  type Address, type Hex,
} from 'viem';
import { MOVVA_RESERVE_ABI } from '../src/abi.js';
import { BPS, E6, UINT256_MAX, ceilDiv, max } from '../src/units.js';

/**
 * A reserve that answers the interface's views from a state per block, computing the derived figures
 * the way IMovvaReserve.sol documents them. It is a model of the interface, not of the other agent's
 * implementation - which is exactly what this package codes against.
 */
export interface ReserveState {
  rate: bigint;
  updatedAt: bigint;
  totalUsdt: bigint;
  liabilitiesBrlE18: bigint;
  target?: number;
  minMint?: number;
  /** The rate reverts with this oracle error: `StaleLeg` for example. The band refuses too. */
  stale?: boolean;
  /** The FX market is closed on a PythFxOracle leg: the rate refuses `StaleRate(updatedAt)`, the band reads the close. */
  closed?: boolean;
  /** A reserve from before `bandBrlPerUsdtE18`: the view does not exist. */
  noBand?: boolean;
  /** Add this to reserveBrlE18 to simulate a units bug. */
  reserveBrlSkew?: bigint;
  /** The principal-locked views: `principalUsdt` (default: all of `totalUsdt`) and `yieldRecipient`. */
  principalUsdt?: bigint;
  yieldRecipient?: Address;
  /** A reserve from before the principal-locked reserve (21 October 2026): those views do not exist. */
  legacy?: boolean;
}

export const YIELD_SAFE: Address = getAddress('0x00000000000000000000000000000000000000f1');

export const RESERVE: Address = getAddress('0x00000000000000000000000000000000000000aa');
export const USDT: Address = getAddress('0xdac17f958d2ee523a2206206994597c13d831ec7');
export const MOVVA: Address = getAddress('0x00000000000000000000000000000000000000bb');
export const LEG: Address = getAddress('0x00000000000000000000000000000000000000cc');

export const blockHash = (n: bigint): Hex => keccak256(toHex(`block-${n}`));

/** What calling a function a contract does not have looks like: a revert with no data. */
function missingView(functionName: string) {
  const abi = parseAbi(['function missing()']);
  return new ContractFunctionExecutionError(
    new ContractFunctionRevertedError({ abi, functionName }),
    { abi, functionName, contractAddress: RESERVE },
  );
}

function staleError(updatedAt: bigint) {
  const abi = parseAbi(['error StaleLeg(address leg, uint256 updatedAt)']);
  const data = encodeErrorResult({ abi, errorName: 'StaleLeg', args: [LEG, updatedAt] });
  return new ContractFunctionExecutionError(
    new ContractFunctionRevertedError({ abi, data, functionName: 'brlPerUsdtE18' }),
    { abi, functionName: 'brlPerUsdtE18', contractAddress: RESERVE },
  );
}

function closedError(publishTime: bigint) {
  const abi = parseAbi(['error StaleRate(uint256 publishTime)']);
  const data = encodeErrorResult({ abi, errorName: 'StaleRate', args: [publishTime] });
  return new ContractFunctionExecutionError(
    new ContractFunctionRevertedError({ abi, data, functionName: 'brlPerUsdtE18' }),
    { abi, functionName: 'brlPerUsdtE18', contractAddress: RESERVE },
  );
}

export class FakeReserve {
  readonly states = new Map<bigint, ReserveState>();
  head = 0n;
  secondsPerBlock = 12n;
  genesisTime = 1_789_000_000n;
  chainId = 1;
  readonly calls: string[] = [];
  balances = new Map<string, bigint>();
  allowances = new Map<string, bigint>();
  simulateRevert?: string;
  /** What `simulateContract` was asked, for assertions. */
  readonly simulations: { functionName: string; args?: readonly unknown[]; account?: unknown; blockNumber?: bigint }[] = [];

  at(block: bigint, s: ReserveState): this {
    this.states.set(block, s);
    if (block > this.head) this.head = block;
    return this;
  }

  timestamp(n: bigint): bigint {
    return this.genesisTime + n * this.secondsPerBlock;
  }

  private stateAt(n: bigint): ReserveState {
    let best: bigint | undefined;
    for (const k of this.states.keys()) if (k <= n && (best === undefined || k > best)) best = k;
    if (best === undefined) throw new Error(`no state at block ${n}`);
    return this.states.get(best)!;
  }

  view(functionName: string, n: bigint, args: readonly unknown[] = []): unknown {
    const s = this.stateAt(n);
    const priced = () => {
      if (s.stale) throw staleError(s.updatedAt);
      if (s.closed) throw closedError(s.updatedAt);
    };
    const target = s.target ?? 10_800;
    const reserveBrl = () => s.totalUsdt * s.rate / E6 + (s.reserveBrlSkew ?? 0n);
    switch (functionName) {
      case 'MOVVA': return MOVVA;
      case 'USDT': return USDT;
      case 'brlPerUsdtE18': priced(); return [s.rate, s.updatedAt];
      case 'bandBrlPerUsdtE18':
        if (s.noBand) throw missingView(functionName);
        if (s.stale) throw staleError(s.updatedAt);
        return [s.rate, s.closed ? this.timestamp(n) : s.updatedAt];
      case 'totalUsdt': return s.totalUsdt;
      case 'reserveBrlE18': priced(); return reserveBrl();
      case 'liabilitiesBrlE18': return s.liabilitiesBrlE18;
      case 'collateralRatioBps': priced(); return s.liabilitiesBrlE18 === 0n ? UINT256_MAX : reserveBrl() * BPS / s.liabilitiesBrlE18;
      case 'surplusBrlE18': priced(); return max(0n, reserveBrl() - ceilDiv(s.liabilitiesBrlE18 * BigInt(target), BPS));
      case 'liabilitiesUsdt': priced(); return s.liabilitiesBrlE18 * E6 / s.rate;
      case 'mintFeeBps': case 'redeemFeeBps': return 0;
      case 'targetCollateralRatioBps': return target;
      case 'minMintCollateralRatioBps': return s.minMint ?? 10_000;
      case 'principalUsdt': if (s.legacy) throw missingView(functionName); return s.principalUsdt ?? s.totalUsdt;
      case 'yieldRecipient': if (s.legacy) throw missingView(functionName); return s.yieldRecipient ?? YIELD_SAFE;
      case 'harvestableYield': {
        if (s.legacy) throw missingView(functionName);
        priced();
        // MovvaReserve's own formula: totalUsdt above max(principal, ceil(supply x target x 1e6 / (rate x 1e4))).
        const atTarget = ceilDiv(s.liabilitiesBrlE18 * BigInt(target) * E6, s.rate * BPS);
        const floor = max(s.principalUsdt ?? s.totalUsdt, atTarget);
        return max(0n, s.totalUsdt - floor);
      }
      case 'balanceOf': return this.balances.get(String(args[0]).toLowerCase()) ?? 0n;
      case 'allowance': return this.allowances.get(String(args[0]).toLowerCase()) ?? 0n;
      default: throw new Error(`fake reserve: no view ${functionName}`);
    }
  }

  client(): any {
    return {
      getChainId: async () => this.chainId,
      getBlockNumber: async () => this.head,
      getBlock: async (a: { blockNumber?: bigint; blockTag?: string }) => {
        const n = a.blockNumber ?? this.head;
        if (n > this.head) throw new Error(`block ${n} not found`);
        return { number: n, hash: blockHash(n), timestamp: this.timestamp(n) };
      },
      readContract: async (a: { functionName: string; blockNumber?: bigint; args?: readonly unknown[] }) => {
        this.calls.push(`${a.functionName}@${a.blockNumber ?? 'latest'}`);
        return this.view(a.functionName, a.blockNumber ?? this.head, a.args);
      },
      getLogs: async () => [],
      simulateContract: async (a: { functionName: string; args?: readonly unknown[]; account?: unknown; blockNumber?: bigint }) => {
        this.simulations.push({ functionName: a.functionName, args: a.args, account: a.account, blockNumber: a.blockNumber });
        if (this.simulateRevert) {
          const abi = parseAbi([`error ${this.simulateRevert}()`]);
          const data = encodeErrorResult({ abi, errorName: this.simulateRevert } as never);
          throw new ContractFunctionExecutionError(
            new ContractFunctionRevertedError({ abi, data, functionName: a.functionName }),
            { abi, functionName: a.functionName, contractAddress: RESERVE },
          );
        }
        return { result: a.functionName === 'harvestYield' ? this.view('harvestableYield', a.blockNumber ?? this.head) : undefined };
      },
    };
  }
}

/** R$ 10,000,000 of Movva at R$ 5.40, at `ratioBps`. */
export const L10M = 10_000_000n * 10n ** 18n;
export const R540 = 5_400_000_000_000_000_000n;
export { MOVVA_RESERVE_ABI };
