import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import type { Server } from 'node:http';
import type { AddressInfo } from 'node:net';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { DeskServer } from '../src/server.js';
import { usdtForRatio } from '../src/hedge.js';
import { FakeReserve, L10M, R540, RESERVE } from './fake-reserve.js';

/**
 * The desk server over HTTP, offline: a saved snapshot replaces the chain, so every route runs the real `runDesk`
 * without an RPC. What matters most here is what it refuses: signing, paths named by a request, writes.
 */
const EXAMPLES = fileURLToPath(new URL('../examples/', import.meta.url));
const RPC = 'https://eth-mainnet.g.alchemy.com/v2/AbCdEfGhIjKlMnOp0123456789';

let server: Server;
let base: string;
let ui: string;
let desk: DeskServer;

const get = async (path: string) => {
  const res = await fetch(`${base}${path}`);
  return { status: res.status, headers: res.headers, body: (await res.json()) as Record<string, any> };
};
const post = async (path: string, body?: unknown, type = 'application/json') => {
  const res = await fetch(`${base}${path}`, {
    method: 'POST', headers: { 'content-type': type }, body: body === undefined ? undefined : typeof body === 'string' ? body : JSON.stringify(body),
  });
  return { status: res.status, body: (await res.json()) as Record<string, any> };
};

beforeAll(async () => {
  ui = mkdtempSync(join(tmpdir(), 'movva-desk-ui-'));
  writeFileSync(join(ui, 'index.html'), '<!doctype html><title>desk</title>');
  desk = new DeskServer({
    env: {
      MOVVA_DESK_CONFIG: join(EXAMPLES, 'desk.json'), CHAIN_ID: '11155111', RPC_URL: RPC,
      MOVVA_STATEMENT_KEY: `0x${'42'.repeat(32)}`, MOVVA_STATEMENT_KEY_FILE: '/etc/hostname',
    },
    snapshotFile: join(EXAMPLES, 'reserve-at-target.json'),
    positionsFile: join(EXAMPLES, 'positions.json'),
    uiDir: ui,
    nowSeconds: () => 1_789_010_000,
  });
  server = await desk.listen(0, '127.0.0.1');
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});

afterAll(() => {
  server?.close();
  rmSync(ui, { recursive: true, force: true });
});

describe('desk server', () => {
  it('describes itself without the RPC URL, and says signing is CLI-only', async () => {
    const { body } = await get('/api/info');
    expect(body.mode).toBe('snapshot');
    expect(body.signing).toBe('cli-only');
    expect(body.rpcConfigured).toBe(true);
    expect(JSON.stringify(body)).not.toContain('AbCdEfGh');
    expect(body.policy.hedgeBandBps).toBe(200);
    expect(body.yieldRecipient.toLowerCase()).toBe('0x00000000000000000000000000000000000000f1');
    expect(body).not.toHaveProperty('treasurer');
    expect(body.policy).not.toHaveProperty('withdrawDailyLimitBps');
  });

  it('reports the reserve ratio from the snapshot, as runDesk prints it', async () => {
    const { status, body } = await get('/api/report');
    expect(status).toBe(200);
    expect(body.ok).toBe(true);
    expect(body.data.reserveRatioBps).toBe('10800');
    expect(body.data.unavailable).toMatch(/no hedge statement/);
  });

  it('plans the hedge with the configured positions, or with positions sent in the body', async () => {
    const desk = await post('/api/hedge-plan');
    expect(desk.body.data.positionsFrom).toMatch(/positions\.json/);
    expect(desk.body.data.plan.withinBand).toBe(true);

    const whatIf = await post('/api/hedge-plan', {
      positions: { positions: [{ instrument: 'DOL', ticker: 'DOLV26', expiry: '2026-10-01', side: 'short', contracts: '20', averagePrice: '5421.000' }] },
    });
    expect(whatIf.body.ok).toBe(true);
    // US$ 1,000,000 short against a US$ 1,851,851.85 target: 17 more DOL (US$ 850,000) lands inside the band.
    expect(whatIf.body.data.plan.withinBand).toBe(false);
    expect(whatIf.body.data.plan.orders[0]).toMatchObject({ side: 'sell', instrument: 'DOL', contracts: '17' });
  });

  it('runs custom shocks and validates them', async () => {
    const ok = await post('/api/shock', { moves: [500, -500] });
    expect(ok.body.data.results.map((r: { label: string }) => r.label)).toEqual(['+5.00%', '-5.00%']);
    expect(ok.body.data.results[0].marginCall.fromReserveUsdt).toBe('0');
    expect((await post('/api/shock', { moves: [50_000] })).status).toBe(400);
    expect((await post('/api/shock', { moves: '500' })).status).toBe(400);
  });

  it('refuses a harvest with nothing above the floor (exit 3, still an answer), and has no hedge-withdrawal routes', async () => {
    const none = await post('/api/harvest-plan');
    expect(none.status).toBe(200);
    expect(none.body.ok).toBe(false);
    expect(none.body.exitCode).toBe(3);
    expect(none.body.data.plan.refused).toMatch(/nothing to harvest/);
    expect((await post('/api/harvest-plan', { from: 'nope' })).status).toBe(400);
    for (const r of ['/api/withdraw-plan', '/api/queue-plan', '/api/execute-plan']) expect((await post(r, {})).status).toBe(404);
    expect((await get('/api/hedge-queue')).status).toBe(404);
  });

  it('runs a custom shock that starts with a fall of the dollar', async () => {
    const r = await post('/api/shock', { moves: [-500, 300] });
    expect(r.status).toBe(200);
    expect(r.body.ok).toBe(true);
    expect(r.body.data.results.map((x: { moveBps: string }) => x.moveBps)).toEqual(['-500', '300']);
  });

  it('rejects malformed amounts and addresses before running anything', async () => {
    expect((await post('/api/recap-plan', { amount: '1e6' })).status).toBe(400);
    expect((await post('/api/recap-plan', { amount: '--safe' })).status).toBe(400);
    expect((await post('/api/recap-plan', { from: 'not-an-address' })).status).toBe(400);
    expect((await post('/api/recap-plan', { targetBps: 1.5 })).status).toBe(400);
  });

  it('has no signing route', async () => {
    const r = await post('/api/statements/sign', {});
    expect(r.status).toBe(403);
    expect(r.body.error).toMatch(/CLI-only/);
  });

  it('never hands the statement key to runDesk', async () => {
    const run = await desk.run(['statement', 'sign', '--positions', join(EXAMPLES, 'positions.json'), '--broker-doc', join(EXAMPLES, 'desk.json'),
      '--margin-balance', '1', '--margin-required', '1']);
    expect(run.exitCode).not.toBe(0);
    expect(run.notes.join(' ')).toMatch(/MOVVA_STATEMENT_KEY/);
  });

  it('reads only the files it was configured with: a document cannot be swapped for a path', async () => {
    const run = await desk.run(['hedge-plan', '--positions', '/etc/passwd']);
    expect(run.exitCode).not.toBe(0);
    expect(run.notes.join(' ')).toMatch(/could not be read|not a file this server was configured to read/);
    // A request's statement document is data in memory, never a path.
    const v = await post('/api/statements/verify', { statement: '/etc/passwd' });
    expect(v.status).toBe(400);
  });

  it('accepts JSON only, so a cross-site form post cannot reach a route', async () => {
    const r = await post('/api/recap-plan', 'amount=1', 'application/x-www-form-urlencoded');
    expect(r.status).toBe(415);
  });

  it('serves the UI with security headers, falling back to index.html, and refuses an escaping path', async () => {
    const res = await fetch(`${base}/some/client/route`);
    expect(res.status).toBe(200);
    expect(await res.text()).toContain('<title>desk</title>');
    expect(res.headers.get('content-security-policy')).toContain("frame-ancestors 'none'");
    expect(res.headers.get('x-content-type-options')).toBe('nosniff');
    const escape = await fetch(`${base}/..%2f..%2f..%2fetc%2fpasswd`);
    expect([400, 200]).toContain(escape.status);
    expect(await escape.text()).not.toContain('root:');
  });

  it('answers 404 for an unknown API route and for a statement store that is not configured', async () => {
    expect((await get('/api/nope')).status).toBe(404);
    expect((await get('/api/statements/1')).status).toBe(404);
    expect((await get('/api/statements')).body).toEqual({ configured: false, statements: [] });
  });
});

describe('desk server against a chain', () => {
  let live: Server;
  let url: string;

  beforeAll(async () => {
    const f = new FakeReserve().at(700n, {
      rate: R540, updatedAt: 1_789_008_000n, totalUsdt: usdtForRatio(12_000n, L10M, R540), liabilitiesBrlE18: L10M,
      principalUsdt: 2_100_000_000_000n,
    });
    const d = new DeskServer({ env: { RPC_URL: RPC, MOVVA_RESERVE: RESERVE }, client: () => f.client(), nowSeconds: () => 1_789_010_000 });
    live = await d.listen(0, '127.0.0.1');
    url = `http://127.0.0.1:${(live.address() as AddressInfo).port}`;
  });
  afterAll(() => { live?.close(); });

  it('plans and simulates a harvest over HTTP, with a Safe batch', async () => {
    const res = await fetch(`${url}/api/harvest-plan`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({}) });
    const h = await res.json() as Record<string, any>;
    expect(h.ok).toBe(true);
    expect(h.data.plan).toMatchObject({ binding: 'principal', harvestableUsdt: '122222222223' });
    expect(h.data.plan.transactions[0].call).toBe('harvestYield()');
    expect(h.data.simulation).toEqual({ ok: true, usdt: '122222222223' });
    expect(h.data.safeBatch.chainId).toBe('1');
  });
});
