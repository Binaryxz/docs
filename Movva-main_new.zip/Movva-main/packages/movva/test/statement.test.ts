import { describe, expect, it } from 'vitest';
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { privateKeyToAccount } from 'viem/accounts';
import { zeroHash, type Hex } from 'viem';
import { DEFAULT_INSTRUMENTS, usdtForRatio, type Position } from '../src/hedge.js';
import { InvalidDocument, toJson } from '../src/json.js';
import { readReserveSnapshot, requirePriced } from '../src/reserve.js';
import { backingReport, reportText } from '../src/report.js';
import {
  buildStatement, documentSha256, signStatement, snapshotReader, statementFromJson, statementToJson, verifyStatement,
  type SignedStatement,
} from '../src/statement.js';
import { StatementStore } from '../src/statement-store.js';
import { FakeReserve, L10M, R540, RESERVE } from './fake-reserve.js';

const KEY = `0x${'42'.repeat(32)}` as Hex;
const issuer = privateKeyToAccount(KEY);
const OTHER = privateKeyToAccount(`0x${'43'.repeat(32)}`);
const BROKER_DOC = documentSha256(new TextEncoder().encode('%PDF broker statement 2026-09-14'));

const POSITIONS: Position[] = [
  { instrument: 'DOL', ticker: 'DOLV26', expiry: '2026-10-01', side: 'short', contracts: 36n, averagePriceBrlPerUsdE6: 5_421_000n },
  { instrument: 'WDO', ticker: 'WDOV26', expiry: '2026-10-01', side: 'short', contracts: 5n, averagePriceBrlPerUsdE6: 5_418_500n },
];

/** A reserve at 102% at block 100, and a chain that has moved on to block 400. */
function world() {
  const f = new FakeReserve().at(100n, { rate: R540, updatedAt: 1_789_001_000n, totalUsdt: usdtForRatio(10_200n, L10M, R540), liabilitiesBrlE18: L10M });
  f.head = 400n;
  return f;
}

async function first(f = world(), asOfOffset = 60n): Promise<{ f: FakeReserve; s: SignedStatement; asOf: bigint }> {
  const snapshot = requirePriced(await readReserveSnapshot(f.client(), RESERVE, { blockNumber: 100n }));
  const asOf = snapshot.blockTimestamp + asOfOffset;
  const message = buildStatement({
    issuer: issuer.address, asOf, snapshot, positions: POSITIONS, instruments: DEFAULT_INSTRUMENTS,
    marginBalanceBrlCents: 99_900_000n, marginRequiredBrlCents: 99_900_000n, brokerStatementSha256: BROKER_DOC,
  });
  return { f, s: await signStatement(issuer, 1, RESERVE, message), asOf };
}

const opts = (f: FakeReserve, now: bigint) => ({
  issuer: issuer.address, chainId: 1, reserve: RESERVE, nowSeconds: Number(now), instruments: DEFAULT_INSTRUMENTS,
  readSnapshotAt: snapshotReader(f.client(), RESERVE),
});

describe('building and signing', () => {
  it('binds the snapshot, the positions and their sum, and starts a chain', async () => {
    const { s } = await first();
    expect(s.message).toMatchObject({
      issuer: issuer.address, sequence: 1n, reserveBlock: 100n, reserveBrlPerUsdtE18: R540,
      reserveLiabilitiesUsdt: 1_851_851_851_851n, netShortUsdE6: 1_850_000_000_000n, previousStatementHash: zeroHash,
    });
    expect(s.message.positions[0].contractSizeUsd).toBe(50_000n);
  });

  it('refuses to sign with a key that is not the named issuer', async () => {
    const { s } = await first();
    await expect(signStatement(OTHER, 1, RESERVE, s.message)).rejects.toThrow(/statement key is/);
  });

  it('refuses a statement dated before its snapshot, or with no broker document', async () => {
    const snapshot = requirePriced(await readReserveSnapshot(world().client(), RESERVE, { blockNumber: 100n }));
    const base = { issuer: issuer.address, snapshot, positions: POSITIONS, instruments: DEFAULT_INSTRUMENTS, marginBalanceBrlCents: 0n, marginRequiredBrlCents: 0n };
    expect(() => buildStatement({ ...base, asOf: snapshot.blockTimestamp - 1n, brokerStatementSha256: BROKER_DOC })).toThrow(/before the snapshot/);
    expect(() => buildStatement({ ...base, asOf: snapshot.blockTimestamp, brokerStatementSha256: zeroHash })).toThrow(/SHA-256/);
    expect(() => buildStatement({ ...base, asOf: snapshot.blockTimestamp, brokerStatementSha256: BROKER_DOC, snapshot: { ...snapshot, inconsistencies: ['x'] } })).toThrow(InvalidDocument);
  });

  it('round-trips through its published JSON', async () => {
    const { s } = await first();
    expect(statementFromJson(JSON.parse(toJson(statementToJson(s))))).toEqual(s);
    expect(() => statementFromJson({ ...(statementToJson(s) as object), format: 'v0' })).toThrow(/format/);
  });
});

describe('verifying', () => {
  it('verifies signature, hash, arithmetic, freshness and the snapshot against the chain', async () => {
    const { f, s, asOf } = await first();
    const v = await verifyStatement(s, opts(f, asOf + 3_600n));
    expect(v.problems).toEqual([]);
    expect(v.valid).toBe(true);
    expect(v.checks).toEqual({ signature: 'ok', hash: 'ok', arithmetic: 'ok', chain: 'ok', freshness: 'ok', snapshot: 'ok' });
  });

  it('rejects an edited statement, even one whose sums still add up', async () => {
    const { f, s, asOf } = await first();
    const edited: SignedStatement = {
      ...s, message: { ...s.message, positions: [{ ...s.message.positions[0], contracts: 37n }, s.message.positions[1]], netShortUsdE6: 1_900_000_000_000n },
    };
    const v = await verifyStatement(edited, opts(f, asOf));
    expect(v.valid).toBe(false);
    expect(v.checks.signature).toBe('failed');
    expect(v.checks.hash).toBe('failed');
    expect(v.checks.arithmetic).toBe('ok');
  });

  it('rejects arithmetic that does not add up, a stranger\'s signature, and another deployment\'s domain', async () => {
    const { f, s, asOf } = await first();
    const wrongSum = await signStatement(issuer, 1, RESERVE, { ...s.message, netShortUsdE6: 1n });
    expect((await verifyStatement(wrongSum, opts(f, asOf))).problems.join()).toMatch(/positions add up to 1850000000000/);
    const stranger = await verifyStatement(s, { ...opts(f, asOf), issuer: OTHER.address });
    expect(stranger.problems.join()).toMatch(/not the issuer's statement key/);
    const otherChain = await verifyStatement(s, { ...opts(f, asOf), chainId: 5 });
    expect(otherChain.valid).toBe(false);
    expect(otherChain.problems.join()).toMatch(/for chain 1/);
  });

  it('goes stale after the configured age, and refuses a statement from the future', async () => {
    const { f, s, asOf } = await first();
    const stale = await verifyStatement(s, opts(f, asOf + 27n * 3_600n));
    expect(stale.checks.freshness).toBe('failed');
    expect(stale.problems.join()).toMatch(/27h old, past the 26h limit/);
    expect((await verifyStatement(s, opts(f, asOf - 600n))).problems.join()).toMatch(/in the future/);
  });

  it('fails a statement whose snapshot is not what the reserve said at that block', async () => {
    const { f, s, asOf } = await first();
    f.at(100n, { rate: R540, updatedAt: 1_789_001_000n, totalUsdt: 1n, liabilitiesBrlE18: L10M * 2n });
    const v = await verifyStatement(s, opts(f, asOf));
    expect(v.checks.snapshot).toBe('failed');
    expect(v.problems.join()).toMatch(/liabilitiesUsdt at block 100 was 3703703703703/);
  });

  it('is not valid when the snapshot cannot be read - never assumed fine', async () => {
    const { f, s, asOf } = await first();
    const v = await verifyStatement(s, { ...opts(f, asOf), readSnapshotAt: async () => { throw new Error('missing trie node'); } });
    expect(v.checks.snapshot).toBe('unverifiable');
    expect(v.valid).toBe(false);
    expect(v.problems.join()).toMatch(/archive node/);
  });

  it('links a chain, and catches a rewritten link, a skipped sequence and a rewound snapshot', async () => {
    const { f, s: one, asOf } = await first();
    f.at(200n, { rate: R540, updatedAt: 1_789_002_000n, totalUsdt: usdtForRatio(10_200n, L10M, R540), liabilitiesBrlE18: L10M });
    const snap2 = requirePriced(await readReserveSnapshot(f.client(), RESERVE, { blockNumber: 200n }));
    const next = (previous: SignedStatement, asOf2: bigint) => signStatement(issuer, 1, RESERVE, buildStatement({
      issuer: issuer.address, asOf: asOf2, snapshot: snap2, positions: POSITIONS, instruments: DEFAULT_INSTRUMENTS,
      marginBalanceBrlCents: 0n, marginRequiredBrlCents: 0n, brokerStatementSha256: BROKER_DOC, previous,
    }));
    const two = await next(one, snap2.blockTimestamp + 10n);
    expect(two.message).toMatchObject({ sequence: 2n, previousStatementHash: one.hash });
    const ok = await verifyStatement(two, { ...opts(f, snap2.blockTimestamp + 20n), previous: one });
    expect(ok.checks.chain).toBe('ok');
    expect(ok.valid).toBe(true);

    // The issuer "fixes" statement 1 after the fact: statement 2 no longer links to it.
    const rewritten = await signStatement(issuer, 1, RESERVE, { ...one.message, marginBalanceBrlCents: 1n });
    const broken = await verifyStatement(two, { ...opts(f, snap2.blockTimestamp + 20n), previous: rewritten });
    expect(broken.checks.chain).toBe('failed');
    expect(broken.problems.join()).toMatch(/chain is broken or rewritten/);

    const unlinked = await verifyStatement(two, { ...opts(f, snap2.blockTimestamp + 20n) });
    expect(unlinked.checks.chain).toBe('skipped');
    expect(unlinked.warnings.join()).toMatch(/supply the previous statement/);
    expect(asOf).toBeLessThan(snap2.blockTimestamp);
  });
});

describe('the statement store', () => {
  it('appends the chain one sequence at a time, refusing a fork, a gap or an overwrite', async () => {
    const dir = mkdtempSync(join(tmpdir(), 'movva-statements-'));
    try {
      const store = new StatementStore(dir);
      const { s: one } = await first();
      expect(() => store.append({ ...one, message: { ...one.message, sequence: 2n } })).toThrow(/next statement is sequence 1/);
      store.append(one);
      expect(store.latest()).toEqual(one);
      expect(() => store.append(one)).toThrow(/refusing to fork/);
      const fork = await signStatement(issuer, 1, RESERVE, { ...one.message, sequence: 2n, previousStatementHash: `0x${'11'.repeat(32)}` });
      expect(() => store.append(fork)).toThrow(/refusing to fork/);
      expect(JSON.parse(readFileSync(join(dir, 'latest.json'), 'utf8')).hash).toBe(one.hash);
      // Even a writer that bypasses the check cannot overwrite an issued sequence.
      writeFileSync(join(dir, 'statement-000000000002.json'), '{}');
      const two = await signStatement(issuer, 1, RESERVE, { ...one.message, sequence: 2n, asOf: one.message.asOf + 1n, previousStatementHash: one.hash });
      expect(() => store.append(two)).toThrow();
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });
});

describe('the backing report', () => {
  /**
   * The statement reconciled at R$ 5.40 with US$ 1,850,000 short and R$ 250,000 of free margin. The
   * dollar then falls 5% to R$ 5.13. On-chain: 1,888,888.888889 x 5.13 = R$ 9,690,000.00 against
   * R$ 10,000,000: 96.90%. The short gained 1,850,000 x 0.27 = R$ 499,500. If the hedge holds:
   * 9,690,000 + 499,500 + 250,000 = R$ 10,439,500 = 104.39%. Hedge ratio against the new target
   * 10,000,000 / 5.13 = 1,949,317.74: 94.90%, outside a ±2% band.
   */
  it('reports the on-chain ratio, the hedge ratio and backing if the hedge holds, each from its source', async () => {
    const f = world();
    const snapshot = requirePriced(await readReserveSnapshot(f.client(), RESERVE, { blockNumber: 100n }));
    const statement = await signStatement(issuer, 1, RESERVE, buildStatement({
      issuer: issuer.address, asOf: snapshot.blockTimestamp + 60n, snapshot, positions: POSITIONS, instruments: DEFAULT_INSTRUMENTS,
      marginBalanceBrlCents: 124_900_000n, marginRequiredBrlCents: 99_900_000n, brokerStatementSha256: BROKER_DOC,
    }));
    f.at(300n, { rate: 5_130_000_000_000_000_000n, updatedAt: 1_789_003_000n, totalUsdt: snapshot.totalUsdt, liabilitiesBrlE18: L10M });
    const now = requirePriced(await readReserveSnapshot(f.client(), RESERVE, { blockNumber: 300n }));
    const verification = await verifyStatement(statement, opts(f, now.blockTimestamp));
    expect(verification.valid).toBe(true);
    const r = backingReport({ chainId: 1, snapshot: now, statement, verification, bandBps: 200, nowSeconds: Number(now.blockTimestamp) });
    expect(r.reserveRatioBps).toBe(9_690n);
    expect(r.hedge).toMatchObject({ netShortUsdE6: 1_850_000_000_000n, hedgeRatioBps: 9_490n, withinBand: false });
    expect(r.backingIfHedgeHolds!.components.hedgeVariationSinceStatementBrlE18).toBe(499_500n * 10n ** 18n);
    expect(r.backingIfHedgeHolds!.components.freeMarginBrlE18).toBe(250_000n * 10n ** 18n);
    expect(r.backingIfHedgeHolds!.ratioBps).toBe(10_439n);
    const text = reportText(r);
    expect(text).toMatch(/Reserve ratio     96.90%/);
    expect(text).toMatch(/If the hedge holds 104.39% = reserve R\$ 9.690.000,00 \+ hedge since statement R\$ 499.500,00 \+ free margin R\$ 250.000,00/);
    expect(text).toMatch(/OUTSIDE/);
    expect(text).toMatch(/USDT depeg/);
  });

  it('reports no hedge figure from a statement that did not verify, or without one', async () => {
    const { f, s, asOf } = await first();
    const snapshot = requirePriced(await readReserveSnapshot(f.client(), RESERVE, { blockNumber: 100n }));
    const stale = await verifyStatement(s, opts(f, asOf + 30n * 3_600n));
    const r = backingReport({ chainId: 1, snapshot, statement: s, verification: stale, bandBps: 200, nowSeconds: 0 });
    expect(r.hedge).toBeNull();
    expect(r.backingIfHedgeHolds).toBeNull();
    expect(r.unavailable).toMatch(/did not verify/);
    expect(backingReport({ chainId: 1, snapshot, bandBps: 200, nowSeconds: 0 }).unavailable).toMatch(/no hedge statement/);
    expect(reportText(r)).toMatch(/DID NOT VERIFY/);
  });
});
