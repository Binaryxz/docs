import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { decodeFunctionData, getAddress, type Address } from 'viem';
import { MOVVA_RESERVE_QUEUE_ABI } from '../src/abi.js';
import { runDesk, type DeskIo } from '../src/bin/movva-desk.js';
import { usdtForRatio } from '../src/hedge.js';
import { modelSnapshot, type HedgeRequest } from '../src/reserve.js';
import { planExecuteHedgeWithdrawal, planQueueHedgeWithdrawal } from '../src/treasury.js';
import { FakeReserve, L10M, R540, RESERVE } from './fake-reserve.js';

/**
 * The hedge-withdrawal queue: the slow lane above the 24h limit (MovvaReserve.queueHedgeWithdrawal and
 * executeHedgeWithdrawal). The planners refuse what the reserve would refuse and warn about what may not execute.
 */
const USDT = (n: number | bigint) => BigInt(n) * 1_000_000n;
const TREASURY: Address = getAddress('0x00000000000000000000000000000000000000dd');
const at108 = (hedge?: { withdrawableUsdt: bigint }) => modelSnapshot({
  brlPerUsdtE18: R540, liabilitiesBrlE18: L10M, totalUsdt: usdtForRatio(10_800n, L10M, R540), blockTimestamp: 1_789_000_000n,
  ...(hedge ? { hedge: { ...hedge, limitBps: 800, treasury: TREASURY, treasurer: getAddress('0x00000000000000000000000000000000000000ee') } } : {}),
});
const buffered = R540 * 9_950n / 10_000n;
const T108 = usdtForRatio(10_800n, L10M, R540);

const decoded = (data: `0x${string}`) => decodeFunctionData({ abi: MOVVA_RESERVE_QUEUE_ABI, data });

describe('planQueueHedgeWithdrawal', () => {
  it('defaults to the most that clears the floor at the buffered rate, after what is already pending', () => {
    const s = at108();
    const none = planQueueHedgeWithdrawal(s);
    expect(none.refused).toBeUndefined();
    expect(none.binding).toBe('floor');
    expect(none.amountUsdt).toBe(T108 - usdtForRatio(10_300n, L10M, buffered));
    expect(decoded(none.transactions[0].data)).toEqual({ functionName: 'queueHedgeWithdrawal', args: [none.amountUsdt] });
    expect(none.warnings.some((w) => w.includes('nothing can cancel'))).toBe(true);

    const pending = planQueueHedgeWithdrawal(s, { pendingUsdt: USDT(50_000) });
    expect(pending.amountUsdt).toBe(none.amountUsdt - USDT(50_000));
    expect(pending.limits.pendingUsdt).toBe(USDT(50_000));
    // The reserve's own check at queue time ignores other requests and the buffer.
    expect(pending.limits.floorMaxNowUsdt).toBe(T108 - usdtForRatio(10_300n, L10M, R540));
  });

  it('refuses what the reserve would refuse now, and warns about what may wait at execution', () => {
    const s = at108();
    const floorNow = T108 - usdtForRatio(10_300n, L10M, R540);
    const over = planQueueHedgeWithdrawal(s, { amountUsdt: floorNow + 1n });
    expect(over.refused).toMatch(/under its 103.00% withdraw floor now/);
    expect(over.amountUsdt).toBe(0n);
    expect(over.transactions).toEqual([]);

    const tight = planQueueHedgeWithdrawal(s, { amountUsdt: floorNow, pendingUsdt: USDT(10_000) });
    expect(tight.refused).toBeUndefined();
    expect(tight.warnings.some((w) => w.includes('would breach'))).toBe(true);

    expect(planQueueHedgeWithdrawal(s, { amountUsdt: 0n }).refused).toBe('the amount is zero');
  });

  it('says when the fast lane would do, and when it can be executed', () => {
    const p = planQueueHedgeWithdrawal(at108({ withdrawableUsdt: USDT(160_000) }), {
      amountUsdt: USDT(10_000), delaySeconds: 172_800n, nowSeconds: 1_789_000_100,
    });
    expect(p.warnings.some((w) => w.includes('fits today\'s 24h allowance'))).toBe(true);
    expect(p.executeAfterEstimate).toBe(1_789_000_100n + 172_800n);
    expect(p.transactions[0].description).toMatch(/executable by anyone 48.0 h after it lands; it cannot be cancelled/);
  });

  it('refuses against a reserve whose figures disagree', () => {
    const s = { ...at108(), inconsistencies: ['reserveBrlE18 disagrees'] };
    expect(planQueueHedgeWithdrawal(s).refused).toMatch(/do not agree/);
  });
});

describe('planExecuteHedgeWithdrawal', () => {
  const req = (p: Partial<HedgeRequest>): HedgeRequest => ({ id: 4n, to: TREASURY, usdt: USDT(10_000), executeAfter: 1_788_999_000n, executed: false, ...p });

  it('plans a ready request as one call anyone may send', () => {
    const p = planExecuteHedgeWithdrawal(at108(), req({}));
    expect(p.refused).toBeUndefined();
    expect(p.ready).toBe(true);
    expect(decoded(p.transactions[0].data)).toEqual({ functionName: 'executeHedgeWithdrawal', args: [4n] });
    expect(p.warnings.some((w) => w.includes('anyone may send'))).toBe(true);
  });

  it('refuses one already executed, one not yet due, and one that would breach the floor', () => {
    expect(planExecuteHedgeWithdrawal(at108(), req({ executed: true })).refused).toMatch(/already been executed/);
    const early = planExecuteHedgeWithdrawal(at108(), req({ executeAfter: 1_789_007_200n }));
    expect(early.refused).toMatch(/not executable yet: after 2026-09-1\dT\d\d:\d\d:\d\dZ \(in 2.0 h of chain time\)/);
    expect(early.ready).toBe(false);
    expect(planExecuteHedgeWithdrawal(at108(), req({ usdt: USDT(100_000) })).refused).toMatch(/under its 103.00% withdraw floor/);
  });
});

/* ------------------------------------------------------------------ the CLI, against a fake chain */

const RPC = 'https://rpc.example/v2/AbCdEfGhIjKlMnOp0123456789';
const EXAMPLES = fileURLToPath(new URL('../examples/', import.meta.url));

function io(env: Record<string, string>, fake?: FakeReserve, now = 1_789_010_000) {
  const out: string[] = [];
  const err: string[] = [];
  const d: DeskIo = {
    env, readFile: (p) => readFileSync(p, 'utf8'), readBytes: (p) => readFileSync(p),
    writeFile: () => { throw new Error('no writes in these tests'); },
    stdout: (t) => { out.push(t); }, stderr: (t) => { err.push(t); }, nowSeconds: () => now,
    client: fake ? () => fake.client() : () => { throw new Error('offline'); },
  };
  return { d, err, json: () => JSON.parse(out.join('')) as Record<string, any> }; // eslint-disable-line @typescript-eslint/no-explicit-any
}

/** Block 700 is 1,789,008,400; the clock reads 1,789,010,000. Request 0 executed, 1 due, 2 a day out. */
function chainWithQueue() {
  const f = new FakeReserve().at(700n, {
    rate: R540, updatedAt: 1_789_008_000n, totalUsdt: T108, liabilitiesBrlE18: L10M,
    hedge: { withdrawableUsdt: USDT(12_000), limitBps: 800, treasury: TREASURY },
  });
  f.queue = {
    delay: 86_400n,
    requests: [
      { to: TREASURY, executeAfter: 1_788_000_000n, executed: true, usdt: USDT(5_000) },
      { to: TREASURY, executeAfter: 1_789_000_000n, executed: false, usdt: USDT(10_000) },
      { to: TREASURY, executeAfter: 1_789_096_400n, executed: false, usdt: USDT(20_000) },
    ],
  };
  return f;
}
const env = { RPC_URL: RPC, MOVVA_RESERVE: RESERVE };

describe('movva-desk and the queue', () => {
  it('lists the queue newest first, with each request\'s status and what is still pending', async () => {
    const t = io(env, chainWithQueue());
    expect(await runDesk(['hedge-queue'], t.d)).toBe(0);
    const q = t.json();
    expect(q).toMatchObject({ delaySeconds: '86400', count: '3', pendingUsdt: '30000000000' });
    expect(q.requests.map((r: { id: string; status: string }) => [r.id, r.status])).toEqual([['2', 'waiting'], ['1', 'ready'], ['0', 'executed']]);
    // Measured from block 700's time (1,789,008,400), not the desk's clock (1,789,010,000).
    expect(q.requests[0].secondsLeft).toBe(1_789_096_400 - 1_789_008_400);
  });

  it('plans a queued withdrawal against the pending ones, simulated from the reserve\'s treasurer, with a Safe batch', async () => {
    const f = chainWithQueue();
    const t = io(env, f);
    expect(await runDesk(['queue-plan', '--amount', '50000', '--safe'], t.d)).toBe(0);
    const out = t.json();
    expect(out.plan).toMatchObject({ amountUsdt: '50000000000', binding: 'requested', delaySeconds: '86400', limits: { pendingUsdt: '30000000000' } });
    expect(out.simulation).toEqual({ ok: true });
    expect(out.safeBatch.transactions).toHaveLength(1);
    expect(f.simulations.at(-1)).toMatchObject({ functionName: 'queueHedgeWithdrawal', args: [USDT(50_000)], blockNumber: 700n });
    expect(String(f.simulations.at(-1)!.account).toLowerCase()).toBe('0x00000000000000000000000000000000000000ee');
  });

  it('plans executing a due request, and refuses one executed or not yet due', async () => {
    const f = chainWithQueue();
    const due = io(env, f);
    expect(await runDesk(['execute-plan', '--id', '1'], due.d)).toBe(0);
    expect(due.json().plan).toMatchObject({ ready: true, transactions: [{ call: 'executeHedgeWithdrawal(1)' }] });
    expect(f.simulations.at(-1)).toMatchObject({ functionName: 'executeHedgeWithdrawal', args: [1n] });

    const early = io(env, chainWithQueue());
    expect(await runDesk(['execute-plan', '--id', '2'], early.d)).toBe(3);
    expect(early.err.join('')).toMatch(/not executable yet/);
    const done = io(env, chainWithQueue());
    expect(await runDesk(['execute-plan', '--id', '0'], done.d)).toBe(3);

    const missing = io(env, chainWithQueue());
    expect(await runDesk(['execute-plan', '--id', '7'], missing.d)).toBe(2);
    expect(missing.err.join('')).toMatch(/no request 7: the reserve has 3/);
    const noId = io(env, chainWithQueue());
    expect(await runDesk(['execute-plan'], noId.d)).toBe(2);
  });

  it('points a withdrawal above the 24h limit at the queue', async () => {
    const t = io(env, chainWithQueue());
    expect(await runDesk(['withdraw-plan', '--amount', '50000'], t.d)).toBe(3);
    expect(t.err.join('')).toMatch(/queue-plan plans the slow lane/);
  });

  it('says so against a reserve without a queue, and offline', async () => {
    const f = chainWithQueue();
    f.queue = undefined;
    const none = io(env, f);
    expect(await runDesk(['hedge-queue'], none.d)).toBe(2);
    expect(none.err.join('')).toMatch(/no hedge-withdrawal queue/);

    const cfg = { MOVVA_DESK_CONFIG: join(EXAMPLES, 'desk.json'), CHAIN_ID: '1' };
    const offline = io(cfg);
    expect(await runDesk(['hedge-queue', '--snapshot', join(EXAMPLES, 'reserve-at-target.json')], offline.d)).toBe(2);
    expect(offline.err.join('')).toMatch(/drop --snapshot/);
    const plan = io(cfg);
    expect(await runDesk(['queue-plan', '--snapshot', join(EXAMPLES, 'reserve-at-target.json')], plan.d)).toBe(0);
    expect(plan.err.join('')).toMatch(/offline: the queue's delay and pending requests are unknown/);
    expect(plan.json().simulation).toBe('not run: offline');
  });
});

describe('the chain\'s clock decides what is due', () => {
  it('reads a request as ready when the chain is past it, however far behind the desk\'s clock is', async () => {
    const f = chainWithQueue();
    // A test chain whose clock was moved ahead two days: request 2, due a day after the desk's clock, is due on chain.
    f.genesisTime += 172_800n;
    const t = io(env, f, 1_789_010_000);
    expect(await runDesk(['hedge-queue'], t.d)).toBe(0);
    expect(t.json().requests.map((r: { status: string }) => r.status)).toEqual(['ready', 'ready', 'executed']);
    const e = io(env, f, 1_789_010_000);
    expect(await runDesk(['execute-plan', '--id', '2'], e.d)).toBe(0);
  });
});

describe('the fast lane and the queue together', () => {
  it('warns when a withdrawal would strand the pending queue under the floor, and says how much leaves room', async () => {
    const { planWithdrawToHedge } = await import('../src/treasury.js');
    const s = at108({ withdrawableUsdt: USDT(160_000) });
    const alone = planWithdrawToHedge(s);
    expect(alone.warnings.some((w) => w.includes('queued and not yet executed'))).toBe(false);
    const withQueue = planWithdrawToHedge(s, { pendingQueueUsdt: USDT(30_000) });
    expect(withQueue.amountUsdt).toBe(alone.amountUsdt);
    expect(withQueue.limits.pendingQueueUsdt).toBe(USDT(30_000));
    const w = withQueue.warnings.find((x) => x.includes('queued and not yet executed'));
    expect(w).toMatch(/30,000.000000 USDT is queued.*At most 53,007.630746 USDT leaves room for the queue/);
  });

  it('reads the queue for a live withdrawal plan, and says a refused plan was not simulated because it was refused', async () => {
    const f = chainWithQueue();
    const t = io(env, f);
    expect(await runDesk(['withdraw-plan', '--amount', '50000'], t.d)).toBe(3);
    expect(t.json()).toMatchObject({ plan: { limits: { pendingQueueUsdt: '30000000000' } }, simulation: 'not run: refused' });
  });
});
