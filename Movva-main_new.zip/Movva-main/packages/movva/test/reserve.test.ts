import { describe, expect, it } from 'vitest';
import { decodeFunctionData } from 'viem';
import { MOVVA_RESERVE_ABI, ERC20_ABI } from '../src/abi.js';
import { usdtForRatio, ratioBps } from '../src/hedge.js';
import { toJson } from '../src/json.js';
import {
  ReserveUnpriced, atLastClose, readReserveSnapshot, requirePriced, snapshotFromJson, type PricedSnapshot,
} from '../src/reserve.js';
import { planHarvestYield, planRecapitalize, safeTransactionBatch, simulateHarvest } from '../src/treasury.js';
import { FakeReserve, L10M, R540, RESERVE, USDT, YIELD_SAFE, blockHash } from './fake-reserve.js';

const at = (ratio: bigint, extra: Partial<Parameters<FakeReserve['at']>[1]> = {}) =>
  new FakeReserve().at(100n, { rate: R540, updatedAt: 1_789_001_000n, totalUsdt: usdtForRatio(ratio, L10M, R540), liabilitiesBrlE18: L10M, ...extra });

describe('reading the reserve', () => {
  it('reads every figure at one pinned block, and finds them consistent', async () => {
    const f = at(11_000n);
    f.at(101n, { rate: 5_500_000_000_000_000_000n, updatedAt: 1n, totalUsdt: 1n, liabilitiesBrlE18: 1n }); // a later block that must not leak in
    const s = requirePriced(await readReserveSnapshot(f.client(), RESERVE, { blockNumber: 100n }));
    expect(s).toMatchObject({
      blockNumber: 100n, blockHash: blockHash(100n), usdt: USDT, totalUsdt: 2_037_037_037_038n, liabilitiesUsdt: 1_851_851_851_851n,
      collateralRatioBps: 11_000n, thresholds: { targetCollateralRatioBps: 10_800, minMintCollateralRatioBps: 10_000 },
      // Principal-locked: all of it principal by default in the fake, so nothing is harvestable.
      yield: { principalUsdt: 2_037_037_037_038n, recipient: YIELD_SAFE, harvestableUsdt: 0n },
    });
    expect(s.inconsistencies).toEqual([]);
    expect(f.calls.every((c) => c.endsWith('@100'))).toBe(true);
  });

  it('pins "latest" to a block number before reading', async () => {
    const f = at(10_200n);
    const s = await readReserveSnapshot(f.client(), RESERVE);
    expect(s.blockNumber).toBe(100n);
    expect(f.calls.every((c) => c.endsWith('@100'))).toBe(true);
  });

  /** A stale rate is the reserve refusing, not the read failing: a state, with what can still be read. */
  it('returns an unpriced snapshot naming the refusal when the rate is stale', async () => {
    const s = await readReserveSnapshot(at(10_200n, { stale: true }).client(), RESERVE);
    expect(s.priced).toBe(false);
    if (s.priced) return;
    expect(s.refusal).toMatch(/^StaleLeg\(0x/);
    expect(s.totalUsdt).toBe(1_888_888_888_889n);
    expect(() => requirePriced(s)).toThrow(ReserveUnpriced);
  });

  /** Friday night on a PythFxOracle leg: the rate refuses, the band serves the close. Shown and reported, never planned from. */
  it('carries the band\'s last close beside a closed-market refusal, which plans refuse and a report can price at', async () => {
    const f = at(10_800n, { closed: true });
    const s = await readReserveSnapshot(f.client(), RESERVE);
    expect(s).toMatchObject({ priced: false, refusal: 'StaleRate(1789001000)', band: { brlPerUsdtE18: R540, updatedAt: f.timestamp(100n) } });
    if (s.priced) return;
    expect(() => requirePriced(s)).toThrow(ReserveUnpriced);
    expect(() => requirePriced(s)).toThrow(/the FX market is closed. Its band reads the last close, R\$ 5,4000 per USDT, but hedges, harvests, recapitalizations and statements are sized at the live rate only/);
    const close = atLastClose(s);
    expect(close).toMatchObject({ priced: true, brlPerUsdtE18: R540, rateUpdatedAt: f.timestamp(100n), collateralRatioBps: 10_800n, liabilitiesUsdt: 1_851_851_851_852n });
    expect(close.inconsistencies).toEqual([]);
    expect(snapshotFromJson(JSON.parse(toJson(s)))).toEqual(s);
    // A stale leg refuses the band too, and a reserve from before the band has none: nothing to show, nothing to price at.
    expect(await readReserveSnapshot(at(10_800n, { stale: true }).client(), RESERVE)).not.toHaveProperty('band');
    const old = await readReserveSnapshot(at(10_800n, { closed: true, noBand: true }).client(), RESERVE);
    expect(old).not.toHaveProperty('band');
    expect(() => atLastClose(old as never)).toThrow(/Nothing that depends on the rate can be planned/);
  });

  it('throws on a read that fails, rather than calling it a refusal', async () => {
    const client = { ...at(10_200n).client(), readContract: async () => { throw new Error('HTTP request failed'); } };
    await expect(readReserveSnapshot(client, RESERVE)).rejects.toThrow(/HTTP request failed/);
  });

  it('notices when the reserve\'s derived figures disagree with its inputs', async () => {
    const s = requirePriced(await readReserveSnapshot(at(10_200n, { reserveBrlSkew: 10n ** 21n }).client(), RESERVE));
    expect(s.inconsistencies.join('\n')).toMatch(/reserveBrlE18 is .* but totalUsdt x rate is/);
  });

  it('round-trips through JSON, recomputing consistency instead of trusting the file', async () => {
    const s = requirePriced(await readReserveSnapshot(at(10_200n).client(), RESERVE));
    const back = snapshotFromJson(JSON.parse(toJson(s)));
    expect(back).toEqual(s);
    const edited = JSON.parse(toJson({ ...s, liabilitiesUsdt: 1n, inconsistencies: [] }));
    expect(requirePriced(snapshotFromJson(edited)).inconsistencies.join()).toMatch(/liabilitiesUsdt is 1/);
    expect(() => snapshotFromJson({ ...edited, totalUsdt: 5 })).not.toThrow(); // small numbers are fine
    expect(() => snapshotFromJson({ ...edited, totalUsdt: '1.5' })).toThrow(/totalUsdt must be/);
  });

  /** An offline plan must use the reserve's own principal and recipient exactly as a live one would. */
  it('keeps the reserve\'s yield views through JSON, and refuses a snapshot of the hedge-withdrawal reserve', async () => {
    const s = requirePriced(await readReserveSnapshot(at(12_000n, { principalUsdt: 2_100_000_000_000n }).client(), RESERVE));
    expect(s.yield).toEqual({ principalUsdt: 2_100_000_000_000n, recipient: YIELD_SAFE, harvestableUsdt: 122_222_222_223n });
    const back = snapshotFromJson(JSON.parse(toJson(s)));
    expect(back).toEqual(s);
    expect(() => snapshotFromJson({ ...JSON.parse(toJson(s)), yield: { recipient: YIELD_SAFE } })).toThrow(/snapshot.yield.principalUsdt/);
    const old = { ...JSON.parse(toJson(s)), hedge: { withdrawableUsdt: '1', limitBps: 800 } };
    expect(() => snapshotFromJson(old)).toThrow(/removed with the principal-locked reserve/);
  });

  it('reads a reserve from before the principal-locked views without them, and still fails on a failed read', async () => {
    const s = requirePriced(await readReserveSnapshot(at(10_800n, { legacy: true }).client(), RESERVE));
    expect(s).not.toHaveProperty('yield');
    expect(s.inconsistencies).toEqual([]);
  });

  it('notices a harvestableYield that disagrees with the formula, or reaches into the principal', async () => {
    const s = requirePriced(await readReserveSnapshot(at(12_000n, { principalUsdt: 2_100_000_000_000n }).client(), RESERVE));
    const edited = JSON.parse(toJson({ ...s, yield: { ...s.yield, harvestableUsdt: 200_000_000_000n }, inconsistencies: [] }));
    const bad = requirePriced(snapshotFromJson(edited)).inconsistencies.join('\n');
    expect(bad).toMatch(/harvestableYield is 200000000000, but totalUsdt above max\(principal, the target's liabilities\) is 122222222223/);
    expect(bad).toMatch(/reaches into the principal/);
  });
});

describe('planning harvestYield', () => {
  const snap = async (ratio: bigint, principalUsdt?: bigint) =>
    requirePriced(await readReserveSnapshot(at(ratio, { principalUsdt }).client(), RESERVE));

  /**
   * At 120%: 12,000,000 / 5.40 = 2,222,222.222223 USDT. The target's liabilities: 10,800,000 / 5.40 =
   * 2,000,000 USDT. With a principal of 2,100,000 the principal binds: 122,222.222223 harvestable.
   */
  it('harvests only above the principal when the principal binds, to the yield recipient', async () => {
    const p = planHarvestYield(await snap(12_000n, 2_100_000_000_000n));
    expect(p).toMatchObject({
      binding: 'principal', floorUsdt: 2_100_000_000_000n, harvestableUsdt: 122_222_222_223n, expectedHarvestableUsdt: 122_222_222_223n,
      yieldRecipient: YIELD_SAFE, principalUsdt: 2_100_000_000_000n,
    });
    expect(decodeFunctionData({ abi: MOVVA_RESERVE_ABI, data: p.transactions[0].data })).toEqual({ functionName: 'harvestYield', args: undefined });
    expect(p.transactions[0]).toMatchObject({ to: RESERVE, call: 'harvestYield()' });
    expect(p.refused).toBeUndefined();
  });

  /**
   * With a principal of 1,900,000 the target binds: 2,222,222.222223 - 2,000,000 = 222,222.222223, leaving
   * the reserve at exactly 108.00%. A rate 0.50% lower (5.373) needs 10,800,000 / 5.373 = 2,010,050.251257:
   * 212,171.970966 would still be harvestable, and the plan says so.
   */
  it('harvests only above the target\'s liabilities when the target binds, and warns what a lower rate leaves', async () => {
    const p = planHarvestYield(await snap(12_000n, 1_900_000_000_000n));
    expect(p).toMatchObject({ binding: 'target', floorUsdt: 2_000_000_000_000n, harvestableUsdt: 222_222_222_223n });
    expect(p.ratio.afterBps).toBe(10_800n);
    expect(p.harvestableAtBufferedRateUsdt).toBe(212_171_970_966n);
    expect(p.warnings.join()).toMatch(/only 212,171.970966 USDT would be harvestable/);
  });

  it('refuses when there is nothing above the floor: under target, or all of it principal', async () => {
    expect(planHarvestYield(await snap(10_700n, 0n)).refused).toMatch(/nothing to harvest.*the liabilities at the 108.00% target/);
    const all = planHarvestYield(await snap(12_000n));
    expect(all.refused).toMatch(/nothing to harvest.*\(the principal\)/);
    expect(all.transactions).toEqual([]);
  });

  it('warns when the reserve pays someone other than the expected yield recipient', async () => {
    const p = planHarvestYield(await snap(12_000n, 1_900_000_000_000n), { yieldRecipient: '0x0000000000000000000000000000000000000001' });
    expect(p.warnings.join()).toMatch(/pays its yield to .*not the expected .*do not send/);
  });

  it('warns when the reserve\'s ratios are out of order', async () => {
    const legacy = requirePriced(await readReserveSnapshot(at(11_000n, { target: 10_200, minMint: 10_500 }).client(), RESERVE));
    expect(planHarvestYield(legacy).warnings.join()).toMatch(/RATIOS OUT OF ORDER: the mint floor 105.00% is above the target 102.00%/);
    expect(planRecapitalize(legacy).warnings.join()).toMatch(/RATIOS OUT OF ORDER/);
  });

  it('refuses to move USDT when the reserve\'s own figures disagree, and has no harvest on a legacy reserve', async () => {
    const s: PricedSnapshot = { ...(await snap(12_000n, 0n)), inconsistencies: ['x'] };
    expect(planHarvestYield(s).refused).toMatch(/do not agree/);
    const old = requirePriced(await readReserveSnapshot(at(12_000n, { legacy: true }).client(), RESERVE));
    expect(() => planHarvestYield(old)).toThrow(/predates the principal-locked reserve/);
  });

  it('simulates from anyone and reports a revert by name', async () => {
    const f = at(12_000n, { principalUsdt: 2_100_000_000_000n });
    const p = planHarvestYield(requirePriced(await readReserveSnapshot(f.client(), RESERVE)));
    expect(await simulateHarvest(f.client(), p, USDT)).toEqual({ ok: true, usdt: 122_222_222_223n });
    f.simulateRevert = 'NothingToHarvest';
    expect(await simulateHarvest(f.client(), p)).toEqual({ ok: false, reason: 'NothingToHarvest()' });
  });
});

describe('planning recapitalize', () => {
  const snap = async (ratio: bigint) => requirePriced(await readReserveSnapshot(at(ratio).client(), RESERVE));

  it('restores the target even after the buffer, zeroing a USDT allowance first, as principal', async () => {
    const s = await snap(9_690n);
    const p = planRecapitalize(s, { from: USDT, allowance: 5n, balance: 1_000_000n }); // 1 USDT held
    expect(p.binding).toBe('target');
    expect(p.ratio.afterAtBufferedRateBps).toBeGreaterThanOrEqual(10_800n);
    expect(ratioBps(s.totalUsdt + p.amountUsdt - 1n, s.liabilitiesBrlE18, p.bufferedRateBrlPerUsdtE18)).toBeLessThan(10_800n);
    expect(p.transactions.map((t) => t.call)).toEqual([
      `approve(${RESERVE}, 0)`, `approve(${RESERVE}, ${p.amountUsdt})`, `recapitalize(${p.amountUsdt})`,
    ]);
    expect(decodeFunctionData({ abi: ERC20_ABI, data: p.transactions[1].data }).args).toEqual([RESERVE, p.amountUsdt]);
    expect(p.transactions.slice(0, 2).every((t) => t.to === USDT)).toBe(true);
    expect(p.warnings.join()).toMatch(/holds .* less than/);
    expect(p.transactions[2].description).toMatch(/as principal/);
  });

  it('skips the zeroing when the allowance is known to be zero, and refuses when nothing is needed', async () => {
    expect(planRecapitalize(await snap(9_690n), { allowance: 0n }).transactions).toHaveLength(2);
    expect(planRecapitalize(await snap(11_000n)).refused).toMatch(/nothing to do/);
  });

  it('exports a Safe Transaction Builder batch', async () => {
    const p = planRecapitalize(await snap(9_690n), { allowance: 0n });
    const b = safeTransactionBatch(p.transactions, { chainId: 1, name: 'recap', description: 'd', createdAt: 1 });
    expect(b).toMatchObject({ version: '1.0', chainId: '1', meta: { name: 'recap' } });
    expect(b.transactions[1]).toEqual({ to: RESERVE, value: '0', data: p.transactions[1].data, contractMethod: null, contractInputsValues: null });
  });
});
