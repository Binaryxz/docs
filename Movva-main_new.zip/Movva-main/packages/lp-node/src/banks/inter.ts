/**
 * The LP's bank as Banco Inter: a `BankAdapter` over Inter's published corporate APIs (sources, auth,
 * limits and error format in `inter-client.ts`).
 *
 * ## Which endpoint serves which method
 *
 *  | BankAdapter          | Inter                                                                        |
 *  |----------------------|------------------------------------------------------------------------------|
 *  | `sendPix`            | `POST /banking/v2/pix` (header `x-id-idempotente`), then `GET /banking/v2/pix/{codigoSolicitacao}` |
 *  | `payBoleto`          | `GET /banking/v2/pagamento?codBarraLinhaDigitavel=` (look-up), `POST /banking/v2/pagamento`, `GET ...?codigoTransacao=` |
 *  | `getOutgoing`        | the two GETs above, found through this adapter's own record of what it sent  |
 *  | `registerBoleto`     | `GET /cobranca/v3/cobrancas?seuNumero=` (look-up), `POST /cobranca/v3/cobrancas`, `GET /cobranca/v3/cobrancas/{codigoSolicitacao}` |
 *  | `cancelBoleto`       | `GET` that, then `POST /cobranca/v3/cobrancas/{codigoSolicitacao}/cancelar`  |
 *  | `balanceCents`       | `GET /banking/v2/saldo` (`disponivel`)                                       |
 *  | `listIncoming`       | API Pix `GET /pix/v2/pix` through `ApiPixReceiver`, plus boleto credits from `GET /banking/v2/extrato/completo` |
 *  | `getIncoming`, `refundIncoming` | API Pix `GET /pix/v2/pix/{e2eId}`, `GET|PUT .../devolucao/{id}` through `ApiPixReceiver` |
 *  | `createCharge`, `getCharge`, `cancelCharge` | API Pix `PUT|GET|PATCH /pix/v2/cob/{txid}` (`cob.write`, `cob.read`) through `ApiPixReceiver`, for `onramp.pixCharge: "cob"` |
 *
 * ## Idempotency (bank.ts rule 1), per rail
 *
 * **Pix: the bank's header.** `x-id-idempotente` is documented on `POST /pix` ("Id informado para
 * garantir idempotência nos pagamentos Pix", an RFC 4122 UUID). The node's key is mapped to a UUID
 * deterministically (version 5, below), so every repeat of a key - after a crash, after a lost
 * journal, from a new process - carries the same header. The documents do NOT say what a repeated
 * POST returns nor how long Inter remembers the id: UNVERIFIED until the sandbox. So a repeat is never
 * trusted to be recognisable: a refusal (4xx) of a repeat is thrown as unknown, never reported
 * FAILED, since the first attempt may have moved the money.
 *
 * `GET /pix/{codigoSolicitacao}` cannot be searched by the idempotency id, so the adapter keeps its own
 * append-only record (`journal`, a `JsonlJournal` beside the node's in production) of each key's
 * intent, attempts and the `codigoSolicitacao` Inter returned. `getOutgoing(key)` answers from Inter by
 * that code. A key whose POST response was lost has no code: `getOutgoing` answers undefined, the
 * node repeats under the same key, and the header absorbs it.
 *
 * **Boleto: look-up before paying.** `POST /pagamento` has no idempotency header and no free-text field.
 * But `GET /pagamento` filters by barcode, and a boleto is ONE document: a live payment of the barcode
 * is this key's payment, and a second one would be a double payment whoever asked for it. So the
 * adapter looks the barcode up before every POST. The window: from Inter accepting a POST to the
 * payment appearing in `GET /pagamento` (undocumented). A repeat inside `boletoRepeatAfterMs` of an
 * attempt that may have reached the bank is refused ("wait"), and the node asks again next tick; two
 * concurrent calls could still both miss, which the node never makes (one tick at a time). Inter itself
 * refuses a boleto already paid (`406`, "Título já liquidado / baixado"), a second line of defence for
 * registered bank boletos only.
 *
 * **Registration: Inter's duplicate control, and a look-up.** "Controle de duplicidade": Cobrança
 * refuses a second charge with the same `seuNumero`, `valorNominal`, `dataVencimento` and payer
 * document for 30 minutes. `seuNumero` is the key's first 15 characters (the field's maximum), the
 * charge is looked up by it before any POST, and again after, so a lost response costs a tick.
 *
 * ## Settlement, not acceptance (rule 2)
 *
 *  | Inter status                                                                 | Node      |
 *  |------------------------------------------------------------------------------|-----------|
 *  | Pix `PAGO`, with a 32-character `endToEnd` and a parseable `dataHoraMovimento`  | `SETTLED` |
 *  | Pix `REPROVADO` `EXPIRADO` `CANCELADO` `FALHA` `CANCELADO_SEM_SALDO` `NAO_DEBITADO` `AGENDAMENTO_CANCELADO` | `FAILED` |
 *  | Pix `CRIADO` `AGUARDANDO_APROVACAO` `APROVADO` `AGENDADO` `ENVIADO` `DEBITADO` `PARCIALMENTE_*`, unknown | `PENDING` |
 *  | Boleto `REALIZADO`, with `autenticacao` and a parseable `dataPagamento`         | `SETTLED` |
 *  | Boleto `ERRO` `CANCELADO` `REPROVADO` `APROVACAO_EXPIRADA` `AGENDADO_CANCELADO` | `FAILED`  |
 *  | Boleto `EMPROCESSAMENTO` `AGUARDANDO_APROVACAO` `APROVADO` `AGENDADO` `NAO_COMPENSADO`, unknown | `PENDING` |
 *
 * `POST` answers (`tipoRetorno` `PROCESSADO`/`APROVACAO`/`AGENDADO`, `statusPagamento`) are acceptance
 * only; the outcome is always read back. "Dependendo das configurações da conta, este pagamento pode
 * exigir aprovação manual": with approvals on, every payment waits `PENDING` for a human in the
 * Internet Banking - turn them off for the integration, or approve within the sale's pay window.
 * A 4xx on a FIRST attempt (Pix 400/404/422, boleto 400/404/406) is `FAILED`; 401/403/409/429/5xx and
 * timeouts are thrown, for the node to resolve.
 *
 * ## Identifiers and times (rules 3 and 4)
 *
 * `bankTxId` is Inter's: the Pix `endToEnd`, the boleto payment's `autenticacao`, a received boleto's
 * `nossoNumero`. `bankRef` of a registered boleto is Inter's `codigoSolicitacao` (what cancellation
 * takes; `nossoNumero` may be absent while `EM_PROCESSAMENTO`). Times are read by `interTime`.
 *
 * ## What the documents leave open, and what this does about it
 *
 *  - **API Pix at Inter lists only charges.** `GET /pix` and `GET /pix/{e2eId}`: "As transações de Pix
 *    retornadas nas consultas são recebimentos que tiveram origem de um Pix Cobrança (Cob ou CobV)
 *    gerado pela API Pix ou IBPJ (Boleto com Pix) pagos via QR Code", and the webhook is for cob/cobv.
 *    A Pix to the LP's key from the node's static BR Code may never appear there. The statement shows
 *    it, but with a date and no time (`dataTransacao`, format date), which cannot prove a payment made
 *    after a lock. So an LP at Inter serves charges (`onramp.pixCharge: "cob"`), which this adapter routes to
 *    Inter's `/cob/{txid}`; a paid charge is listed by `GET /pix` with its txid. Confirm that in the sandbox.
 *  - **Collection boletos.** `POST /pagamento` requires `dataVencimento`; a collection ("arrecadação")
 *    line has no due-date field. Such a payment is `FAILED` before anything is sent, rather than
 *    sending a date the documents do not define.
 *  - **Registration needs a payer.** `pagador` (document, name, address) is required and the node does
 *    not know the taker. `boletoPayer` is configured by the LP (a compliance decision, not a default);
 *    without it `registerBoleto` is absent and the node holds boleto orders. `formasRecebimento` is
 *    `["BOLETO"]`: a Pix QR on the document would settle outside the boleto commitment.
 *  - **Received boletos** come from the statement (`tipoTransacao=BOLETO_COBRANCA`, `tipoOperacao=C`),
 *    the only documented source with a time (`detalhes.dataTransacao`), read at most once a
 *    `statementCacheMs` (the endpoint allows 10 calls a minute). Whether that time is the payer's
 *    payment or Inter's credit on compensation is not documented.
 */
import { createHash } from 'node:crypto';
import { lineToBarcode, normalizePixKey, parseBoleto } from '@mova/ramp';
import { ApiPixClient, ApiPixError, ApiPixReceiver, composeBank } from '../api-pix.js';
import type { BankAdapter, IncomingPayment, OutgoingPaymentResult, RegisteredBoleto } from '../bank.js';
import type { Journal } from '../journal.js';
import {
  InterApiError, InterClient, InterDecimal, brasiliaDay, centsOf, interTime, isUnsent, reais, type InterOpName,
} from './inter-client.js';

export * from './inter-client.js';

/** The `pagador` Cobrança requires on every charge (PagadorBase / Pagador). */
export interface InterBoletoPayer {
  cpfCnpj: string;
  tipoPessoa: 'FISICA' | 'JURIDICA';
  nome: string;
  endereco: string;
  cidade: string;
  uf: string;
  cep: string;
  bairro?: string;
  numero?: string;
  complemento?: string;
  email?: string;
  ddd?: string;
  telefone?: string;
}

/** The adapter's own durable record, by the node's idempotency key. */
export type InterIndexRecord =
  | { t: 'intent'; key: string; kind: 'PIX' | 'BOLETO'; destination: string; amountCents: bigint; at: number }
  | { t: 'attempt'; key: string; at: number }
  | { t: 'unsent'; key: string }
  | { t: 'accepted'; key: string; bankRef: string }
  | { t: 'final'; key: string; result: OutgoingPaymentResult }
  | { t: 'cobranca.intent'; key: string; at: number }
  | { t: 'cobranca'; key: string; codigoSolicitacao: string };

export interface InterBankOptions {
  client: InterClient;
  /** Durable in production (`JsonlJournal`, one process per file, like the node's). */
  journal: Journal<InterIndexRecord>;
  boletoPayer?: InterBoletoPayer;
  /** How long an attempted boleto payment must stay invisible before it is taken as never received. */
  boletoRepeatAfterMs?: number;
  /** The least time between two statement reads for boleto credits. */
  statementCacheMs?: number;
  /** GETs after issuing a charge before giving up for this tick, and the pause between them. */
  registrationPolls?: number;
  registrationPollMs?: number;
  /** Items per API Pix `/pix` page. */
  pixPageSize?: number;
  /** Items per statement and charge-list page (documented maxima 10000 and 1000). */
  listPageSize?: number;
}

/*//////////////////////////////////////////////////////////////
                   THE PIX IDEMPOTENCY HEADER
//////////////////////////////////////////////////////////////*/

function uuidV5(name: string, namespace: string): string {
  const h = createHash('sha1').update(Buffer.from(namespace.replace(/-/g, ''), 'hex')).update(name, 'utf8').digest();
  h[6] = (h[6] & 0x0f) | 0x50;
  h[8] = (h[8] & 0x3f) | 0x80;
  const x = h.subarray(0, 16).toString('hex');
  return `${x.slice(0, 8)}-${x.slice(8, 12)}-${x.slice(12, 16)}-${x.slice(16, 20)}-${x.slice(20)}`;
}

/** RFC 4122 §4.3's URL namespace; the adapter's own namespace is derived from it, once. */
const PIX_ID_NAMESPACE = uuidV5('urn:mova:lp-node:inter:x-id-idempotente:v1', '6ba7b811-9dad-11d1-80b4-00c04fd430c8');

/** The `x-id-idempotente` of a node key: a name-based UUID, the same in every process, forever. */
export const interPixIdempotencyId = (idempotencyKey: string): string => uuidV5(idempotencyKey, PIX_ID_NAMESPACE);

/*//////////////////////////////////////////////////////////////
                         STATUS MAPPING
//////////////////////////////////////////////////////////////*/

const E2E = /^[a-zA-Z0-9]{32}$/;
const PIX_FAILED = new Set(['REPROVADO', 'EXPIRADO', 'CANCELADO', 'FALHA', 'CANCELADO_SEM_SALDO', 'NAO_DEBITADO', 'AGENDAMENTO_CANCELADO']);
const BOLETO_FAILED = new Set(['ERRO', 'CANCELADO', 'REPROVADO', 'APROVACAO_EXPIRADA', 'AGENDADO_CANCELADO']);
/** A first POST refused with these moved nothing (documented validation, not-found and not-accepted answers). */
const PIX_REFUSED = new Set([400, 404, 422]);
const BOLETO_REFUSED = new Set([400, 404, 406]);
const COBRANCA_DEAD = new Set(['CANCELADO', 'EXPIRADO', 'FALHA_EMISSAO']);
const COBRANCA_CANCELLABLE = new Set(['A_RECEBER', 'ATRASADO', 'EM_PROCESSAMENTO']);

type Json = Record<string, unknown>;
const obj = (v: unknown): Json => (v && typeof v === 'object' && !Array.isArray(v) ? v as Json : {});
const str = (v: unknown): string | undefined => (typeof v === 'string' && v.trim() ? v.trim() : undefined);
const errorCode = (erros: unknown): string => {
  const c = Array.isArray(erros) ? str(obj(erros[0]).codigoErro) : undefined;
  return c && /^[\w-]{1,20}$/.test(c) ? ` ${c}` : '';
};

function barcodeOf(v: unknown): string | undefined {
  const d = typeof v === 'string' ? v.replace(/\D/g, '') : '';
  if (d.length === 44) return d;
  try {
    return d.length === 47 || d.length === 48 ? lineToBarcode(d) : undefined;
  } catch {
    return undefined;
  }
}

interface Entry {
  kind: 'PIX' | 'BOLETO';
  destination: string;
  amountCents: bigint;
  at: number;
  attempted: boolean;
  attemptAt?: number;
  bankRef?: string;
  final?: OutgoingPaymentResult;
}

/*//////////////////////////////////////////////////////////////
                          SENDING
//////////////////////////////////////////////////////////////*/

export class InterSendingAdapter {
  private readonly entries = new Map<string, Entry>();
  private readonly cobrancas = new Map<string, { at: number; codigoSolicitacao?: string }>();
  private balance?: { cents: bigint; at: number };
  private statement?: { range: string; at: number; credits: IncomingPayment[] };

  constructor(private readonly o: InterBankOptions) {
    for (const r of o.journal.load()) this.apply(r);
  }

  private get client(): InterClient {
    return this.o.client;
  }

  private apply(r: InterIndexRecord): void {
    if (r.t === 'intent') {
      this.entries.set(r.key, { kind: r.kind, destination: r.destination, amountCents: r.amountCents, at: r.at, attempted: false });
      return;
    }
    if (r.t === 'cobranca.intent') {
      this.cobrancas.set(r.key, { at: r.at });
      return;
    }
    if (r.t === 'cobranca') {
      const c = this.cobrancas.get(r.key);
      if (c) c.codigoSolicitacao = r.codigoSolicitacao;
      return;
    }
    const e = this.entries.get(r.key);
    if (!e) return;
    if (r.t === 'attempt') {
      e.attempted = true;
      e.attemptAt = r.at;
    } else if (r.t === 'unsent') {
      e.attempted = false;
    } else if (r.t === 'accepted') {
      e.bankRef = r.bankRef;
    } else {
      e.final = r.result;
    }
  }

  private record(r: InterIndexRecord): void {
    this.o.journal.append(r);
    this.apply(r);
  }

  private finish(key: string, result: OutgoingPaymentResult): OutgoingPaymentResult {
    this.record({ t: 'final', key, result });
    return { ...result };
  }

  /** The key's entry, recording its intent first; a key reused for another payment is refused. */
  private begin(key: string, kind: Entry['kind'], destination: string, amountCents: bigint): Entry {
    const e = this.entries.get(key);
    if (e) {
      if (e.kind !== kind || e.destination !== destination || e.amountCents !== amountCents) {
        throw new Error(`idempotency key ${key} was first used for a different payment; nothing sent`);
      }
      return e;
    }
    this.record({ t: 'intent', key, kind, destination, amountCents, at: this.client.now() });
    return this.entries.get(key)!;
  }

  private async post<T>(key: string, e: Entry, op: InterOpName, init: { headers?: Record<string, string>; body: unknown }, refused: Set<number>):
    Promise<{ data: T } | { failed: OutgoingPaymentResult }> {
    const repeat = e.attempted;
    this.record({ t: 'attempt', key, at: this.client.now() });
    try {
      return { data: (await this.client.request<T>(op, init)).data };
    } catch (err) {
      if (isUnsent(err)) {
        this.record({ t: 'unsent', key });
      } else if (!repeat && err instanceof InterApiError && refused.has(err.status)) {
        return { failed: this.finish(key, { idempotencyKey: key, status: 'FAILED', failureReason: `refused by Inter: ${err.message}` }) };
      }
      throw err;
    }
  }

  /*------------------------------- Pix -------------------------------*/

  async sendPix(req: { idempotencyKey: string; pixKey: string; amountCents: bigint; description?: string }): Promise<OutgoingPaymentResult> {
    const key = req.idempotencyKey;
    const chave = normalizePixKey(req.pixKey).key;
    const e = this.begin(key, 'PIX', chave, req.amountCents);
    if (e.final) return { ...e.final };
    if (e.bankRef) return this.pixOutcome(key, e);

    const sent = await this.post<Json>(key, e, 'pixPay', {
      headers: { 'x-id-idempotente': interPixIdempotencyId(key) },
      body: {
        valor: new InterDecimal(reais(req.amountCents)),
        ...(req.description ? { descricao: req.description.slice(0, 140) } : {}),
        destinatario: { tipo: 'CHAVE', chave },
      },
    }, PIX_REFUSED);
    if ('failed' in sent) return sent.failed;
    const codigo = str(obj(sent.data).codigoSolicitacao);
    if (!codigo) throw new Error('Inter accepted the Pix without a codigoSolicitacao; resolve it in the Internet Banking');
    this.record({ t: 'accepted', key, bankRef: codigo });
    try {
      return await this.pixOutcome(key, e);
    } catch {
      // Accepted, and the status read failed: pending is exactly what is known.
      return { idempotencyKey: key, status: 'PENDING', amountCents: req.amountCents, creditedKey: chave };
    }
  }

  private async pixOutcome(key: string, e: Entry): Promise<OutgoingPaymentResult> {
    const { data } = await this.client.request<Json>('pixPayGet', { params: { codigoSolicitacao: e.bankRef! } });
    const t = obj(obj(data).transacaoPix);
    const status = str(t.status) ?? '';
    const amountCents = t.valor !== undefined ? centsOf(t.valor, 'valor') : e.amountCents;
    const creditedKey = str(t.chave);
    if (status === 'PAGO') {
      const history = Array.isArray(obj(data).historico) ? obj(data).historico as unknown[] : [];
      const paidEvent = history.map(obj).filter((h) => h.status === 'PAGO').map((h) => h.dataHoraEvento).at(-1);
      const paidAt = interTime(t.dataHoraMovimento) ?? interTime(paidEvent);
      const e2e = str(t.endToEnd);
      if (e2e && E2E.test(e2e) && paidAt !== undefined) {
        return this.finish(key, { idempotencyKey: key, status: 'SETTLED', bankTxId: e2e, amountCents, paidAt, creditedKey });
      }
      // Paid, without the facts a proof needs: a human reads it at the bank.
      return { idempotencyKey: key, status: 'PENDING', amountCents, creditedKey };
    }
    if (PIX_FAILED.has(status)) {
      return this.finish(key, { idempotencyKey: key, status: 'FAILED', failureReason: `Inter ${status}${errorCode(t.erros)}` });
    }
    return { idempotencyKey: key, status: 'PENDING', amountCents, creditedKey };
  }

  /*------------------------------ boleto ------------------------------*/

  async payBoleto(req: { idempotencyKey: string; line: string; amountCents: bigint }): Promise<OutgoingPaymentResult> {
    const key = req.idempotencyKey;
    const b = parseBoleto(req.line, { reference: new Date(this.client.now()) });
    const e = this.begin(key, 'BOLETO', b.barcode, req.amountCents);
    if (e.final) return { ...e.final };
    if (b.amountCents !== undefined && b.amountCents !== 0n && b.amountCents !== req.amountCents) {
      return this.finish(key, { idempotencyKey: key, status: 'FAILED', failureReason: 'amount differs from the boleto' });
    }
    if (e.bankRef) return this.boletoOutcome(key, e);
    if (!b.dueDate) {
      return this.finish(key, {
        idempotencyKey: key, status: 'FAILED',
        failureReason: 'Inter requires dataVencimento and this line carries no due date (collection boleto); not sent',
      });
    }
    const found = e.attempted ? await this.findBoletoPayment(key, e) : await this.findBoletoPayment(key, e, { liveOnly: true });
    if (found) return found;
    if (e.attempted && e.attemptAt !== undefined && this.client.now() - e.attemptAt < (this.o.boletoRepeatAfterMs ?? 10 * 60_000)) {
      throw new Error('an earlier attempt to pay this boleto is not yet visible at Inter; not repeating it yet');
    }

    const sent = await this.post<Json>(key, e, 'boletoPay', {
      body: { codBarraLinhaDigitavel: b.barcode, valorPagar: reais(req.amountCents), dataVencimento: b.dueDate },
    }, BOLETO_REFUSED);
    if ('failed' in sent) return sent.failed;
    const codigo = str(obj(sent.data).codigoTransacao);
    if (!codigo) throw new Error('Inter accepted the boleto payment without a codigoTransacao; resolve it in the Internet Banking');
    this.record({ t: 'accepted', key, bankRef: codigo });
    try {
      return await this.boletoOutcome(key, e);
    } catch {
      return { idempotencyKey: key, status: 'PENDING', amountCents: req.amountCents };
    }
  }

  /** `dataInicio`/`dataFim` from the day before the key's intent to today, inside the documented 90 days. */
  private boletoRange(e: Entry): { dataInicio: string; dataFim: string } {
    const nowS = Math.floor(this.client.now() / 1000);
    const from = Math.max(Math.floor(e.at / 1000) - 86_400, nowS - 89 * 86_400);
    return { dataInicio: brasiliaDay(from), dataFim: brasiliaDay(nowS) };
  }

  /**
   * This key's payment among Inter's payments of the barcode: the live one, or - once this key has
   * attempted - a failed one made after its intent, so a payment a human rejected is never retried.
   */
  private async findBoletoPayment(key: string, e: Entry, o: { liveOnly?: boolean } = {}): Promise<OutgoingPaymentResult | undefined> {
    const { data } = await this.client.request<unknown[]>('boletoPayList', {
      query: { codBarraLinhaDigitavel: e.destination, ...this.boletoRange(e), filtrarDataPor: 'INCLUSAO' },
    });
    const mine = (Array.isArray(data) ? data : []).map(obj).filter((p) => barcodeOf(p.codigoBarra) === e.destination);
    const live = mine.filter((p) => !BOLETO_FAILED.has(str(p.statusPagamento) ?? ''));
    if (live.length > 1) throw new Error('Inter shows more than one live payment of this boleto; resolve it by hand');
    let pick: Json | undefined = live[0];
    if (!pick && !o.liveOnly) {
      pick = mine.find((p) => {
        const at = interTime(p.dataInclusao);
        return at !== undefined && Number(at) * 1000 >= e.at - 5 * 60_000;
      });
    }
    const codigo = pick && str(pick.codigoTransacao);
    if (!pick || !codigo) return undefined;
    this.record({ t: 'accepted', key, bankRef: codigo });
    return this.boletoResult(key, e, pick);
  }

  private async boletoOutcome(key: string, e: Entry): Promise<OutgoingPaymentResult> {
    const { data } = await this.client.request<unknown[]>('boletoPayList', {
      query: { codigoTransacao: e.bankRef, ...this.boletoRange(e), filtrarDataPor: 'INCLUSAO' },
    });
    const p = (Array.isArray(data) ? data : []).map(obj).find((x) => x.codigoTransacao === e.bankRef);
    return p ? this.boletoResult(key, e, p) : { idempotencyKey: key, status: 'PENDING', amountCents: e.amountCents };
  }

  private boletoResult(key: string, e: Entry, p: Json): OutgoingPaymentResult {
    const status = str(p.statusPagamento) ?? '';
    if (status === 'REALIZADO') {
      const auth = str(p.autenticacao);
      const paidAt = interTime(p.dataPagamento);
      if (auth && paidAt !== undefined) {
        const amountCents = p.valorPago !== undefined ? centsOf(p.valorPago, 'valorPago') : e.amountCents;
        return this.finish(key, { idempotencyKey: key, status: 'SETTLED', bankTxId: auth, amountCents, paidAt });
      }
    } else if (BOLETO_FAILED.has(status)) {
      return this.finish(key, { idempotencyKey: key, status: 'FAILED', failureReason: `Inter ${status}` });
    }
    return { idempotencyKey: key, status: 'PENDING', amountCents: e.amountCents };
  }

  /*---------------------------- outcomes ----------------------------*/

  async getOutgoing(idempotencyKey: string): Promise<OutgoingPaymentResult | undefined> {
    const e = this.entries.get(idempotencyKey);
    if (!e) return undefined;
    if (e.final) return { ...e.final };
    if (e.kind === 'PIX') return e.bankRef ? this.pixOutcome(idempotencyKey, e) : undefined;
    if (e.bankRef) return this.boletoOutcome(idempotencyKey, e);
    return e.attempted ? this.findBoletoPayment(idempotencyKey, e) : undefined;
  }

  async balanceCents(): Promise<bigint> {
    const now = this.client.now();
    // The endpoint allows 10 calls a minute; the node asks once per candidate sale.
    if (this.balance && now - this.balance.at < 10_000) return this.balance.cents;
    const { data } = await this.client.request<Json>('saldo');
    const cents = centsOf(obj(data).disponivel, 'disponivel');
    this.balance = { cents, at: now };
    return cents;
  }

  /*--------------------------- registration --------------------------*/

  async registerBoleto(req: { idempotencyKey: string; amountCents: bigint; dueDate: string; reference: string }): Promise<RegisteredBoleto> {
    const payer = this.o.boletoPayer;
    if (!payer) throw new Error('no boleto payer configured: Inter requires one on every charge');
    if (req.amountCents < 250n) throw new Error('Inter registers boletos from R$ 2,50 (valorNominal minimum)');
    const key = req.idempotencyKey;
    const seuNumero = key.slice(0, 15);
    if (!this.cobrancas.has(key)) this.record({ t: 'cobranca.intent', key, at: this.client.now() });
    let codigo = this.cobrancas.get(key)!.codigoSolicitacao ?? await this.findCobranca(seuNumero, req);
    if (!codigo) {
      const { data } = await this.client.request<Json>('cobrancaCreate', {
        body: {
          seuNumero, valorNominal: new InterDecimal(reais(req.amountCents)), dataVencimento: req.dueDate,
          // Cancelled by Inter the day it falls due: an order's boleto must not stay payable.
          numDiasAgenda: 0, pagador: payer, formasRecebimento: ['BOLETO'],
        },
      });
      codigo = str(obj(data).codigoSolicitacao);
      if (!codigo) throw new Error('Inter accepted the charge without a codigoSolicitacao');
    }
    if (this.cobrancas.get(key)!.codigoSolicitacao !== codigo) this.record({ t: 'cobranca', key, codigoSolicitacao: codigo });
    const polls = this.o.registrationPolls ?? 5;
    for (let i = 0; ; i++) {
      const { data } = await this.client.request<Json>('cobrancaGet', { params: { codigoSolicitacao: codigo } });
      const situacao = str(obj(obj(data).cobranca).situacao);
      const line = str(obj(obj(data).boleto).linhaDigitavel);
      if (situacao === 'FALHA_EMISSAO') throw new Error('Inter could not issue the boleto (FALHA_EMISSAO)');
      if (line && /^\d{47}$/.test(line)) return { bankRef: codigo, line };
      // Issuing is asynchronous: EM_PROCESSAMENTO carries no line yet.
      if (i + 1 >= polls) throw new Error('the boleto is still being issued at Inter; asking again next tick');
      await this.client.sleep(this.o.registrationPollMs ?? 1000);
    }
  }

  private async findCobranca(seuNumero: string, req: { amountCents: bigint; dueDate: string }): Promise<string | undefined> {
    for (let page = 0; ; page++) {
      const { data } = await this.client.request<Json>('cobrancaList', {
        query: {
          dataInicial: req.dueDate, dataFinal: req.dueDate, filtrarDataPor: 'VENCIMENTO', seuNumero,
          'paginacao.paginaAtual': page, 'paginacao.itensPorPagina': Math.min(this.o.listPageSize ?? 100, 1000),
        },
      });
      const list = Array.isArray(obj(data).cobrancas) ? obj(data).cobrancas as unknown[] : [];
      for (const item of list) {
        const c = obj(obj(item).cobranca);
        const codigo = str(c.codigoSolicitacao);
        let amount: bigint | undefined;
        try {
          amount = centsOf(c.valorNominal, 'valorNominal');
        } catch {
          amount = undefined;
        }
        if (codigo && c.seuNumero === seuNumero && !COBRANCA_DEAD.has(str(c.situacao) ?? '') && amount === req.amountCents) return codigo;
      }
      if (obj(data).ultimaPagina !== false || page + 1 >= Number(obj(data).totalPaginas ?? 1)) return undefined;
    }
  }

  async cancelBoleto(bankRef: string): Promise<void> {
    let data: Json;
    try {
      ({ data } = await this.client.request<Json>('cobrancaGet', { params: { codigoSolicitacao: bankRef } }));
    } catch (e) {
      if (e instanceof InterApiError && e.status === 404) return;
      throw e;
    }
    if (!COBRANCA_CANCELLABLE.has(str(obj(obj(data).cobranca).situacao) ?? '')) return;
    await this.client.request('cobrancaCancel', { params: { codigoSolicitacao: bankRef }, body: { motivoCancelamento: 'Pedido Mova nao liquidado' } });
  }

  /*------------------------- received boletos ------------------------*/

  async listBoletoCredits(q: { since: bigint; until?: bigint }): Promise<IncomingPayment[]> {
    const now = this.client.now();
    const until = q.until ?? BigInt(Math.floor(now / 1000));
    const floor = until - 89n * 86_400n;
    const range = `${brasiliaDay(q.since > floor ? q.since : floor)}/${brasiliaDay(until)}`;
    if (!this.statement || this.statement.range !== range || now - this.statement.at >= (this.o.statementCacheMs ?? 60_000)) {
      this.statement = { range, at: now, credits: await this.readBoletoCredits(range) };
    }
    return this.statement.credits.filter((c) => c.paidAt >= q.since && c.paidAt <= until).map((c) => ({ ...c }));
  }

  private async readBoletoCredits(range: string): Promise<IncomingPayment[]> {
    const [dataInicio, dataFim] = range.split('/');
    const out: IncomingPayment[] = [];
    for (let pagina = 0; ; pagina++) {
      const { data } = await this.client.request<Json>('extrato', {
        query: { dataInicio, dataFim, tipoOperacao: 'C', tipoTransacao: 'BOLETO_COBRANCA', pagina, tamanhoPagina: Math.min(this.o.listPageSize ?? 1000, 10_000) },
      });
      const list = Array.isArray(obj(data).transacoes) ? obj(data).transacoes as unknown[] : [];
      for (const raw of list) {
        const t = obj(raw);
        const d = obj(t.detalhes);
        const paidAt = interTime(d.dataTransacao);
        const barcode = barcodeOf(d.codBarras);
        const nossoNumero = str(d.nossoNumero);
        if (t.tipoOperacao !== 'C' || t.tipoTransacao !== 'BOLETO_COBRANCA' || paidAt === undefined || !barcode || !nossoNumero) continue;
        try {
          // The payer's document on a charge is the configured payer's, not whoever paid: no payerId.
          out.push({ rail: 'BOLETO', bankTxId: nossoNumero, amountCents: centsOf(t.valor, 'valor'), paidAt, boletoLine: barcode });
        } catch {
          // A record that breaks the schema cannot be matched safely; a human sees it at the bank.
        }
      }
      if (obj(data).ultimaPagina !== false || pagina + 1 >= Number(obj(data).totalPaginas ?? 1)) return out;
    }
  }
}

/*//////////////////////////////////////////////////////////////
                    RECEIVING: API PIX, INTER'S WAY
//////////////////////////////////////////////////////////////*/

/**
 * `ApiPixClient` with Inter's transport: the same paths, pages, patterns and parsing, but the token
 * request, account header and limits of `InterClient` (Inter's token endpoint takes the client
 * credentials in the form body). Only the calls `ApiPixReceiver` makes are routed.
 */
export class InterApiPixClient extends ApiPixClient {
  constructor(private readonly inter: InterClient, o: { pageSize?: number } = {}) {
    super({ baseUrl: `${inter.baseUrl}/pix/v2`, tokenUrl: `${inter.baseUrl}/oauth/v2/token`, clientId: '', clientSecret: '', pageSize: o.pageSize });
  }

  override async call<T>(method: 'GET' | 'PUT' | 'POST' | 'PATCH', path: string, o: { query?: Record<string, string>; body?: unknown } = {}): Promise<{ status: number; data: T }> {
    const dev = /^\/pix\/([a-zA-Z0-9]{32})\/devolucao\/([a-zA-Z0-9]{1,35})$/.exec(path);
    const one = /^\/pix\/([a-zA-Z0-9]{32})$/.exec(path);
    const cob = /^\/cob\/([a-zA-Z0-9]{26,35})$/.exec(path);
    const route: { op: InterOpName; params?: Record<string, string> } | undefined =
      method === 'GET' && path === '/pix' ? { op: 'pixList' }
        : method === 'GET' && one ? { op: 'pixGet', params: { e2eId: one[1] } }
          : dev && (method === 'GET' || method === 'PUT') ? { op: method === 'GET' ? 'devolucaoGet' : 'devolucaoPut', params: { e2eId: dev[1], id: dev[2] } }
            : cob && method !== 'POST' ? { op: method === 'PUT' ? 'cobPut' : method === 'GET' ? 'cobGet' : 'cobPatch', params: { txid: cob[1] } }
            : undefined;
    if (!route) throw new Error(`API Pix ${method} ${path.split('/')[1] ?? ''} is not routed for Inter`);
    try {
      return await this.inter.request<T>(route.op, { params: route.params, query: o.query, body: o.body });
    } catch (e) {
      if (e instanceof InterApiError) throw new ApiPixError(e.status, undefined, e.title);
      throw e;
    }
  }
}

/** Inter as the node's bank: API Pix for receiving and refunds, Banking and Cobrança for the rest. */
export function createInterBank(o: InterBankOptions): BankAdapter {
  const sending = new InterSendingAdapter(o);
  const receiver = new ApiPixReceiver(new InterApiPixClient(o.client, { pageSize: o.pixPageSize }), { now: () => o.client.now() });
  const bank = composeBank(receiver, {
    // POST /pagamento requires dataVencimento: the off-ramp does not claim a bill whose line has none.
    boletoNeedsDueDate: true,
    sendPix: (r) => sending.sendPix(r),
    payBoleto: (r) => sending.payBoleto(r),
    getOutgoing: (k) => sending.getOutgoing(k),
    balanceCents: () => sending.balanceCents(),
    ...(o.boletoPayer ? { registerBoleto: (r) => sending.registerBoleto(r), cancelBoleto: (ref) => sending.cancelBoleto(ref) } : {}),
  });
  if (!o.boletoPayer) return bank;
  return { ...bank, listIncoming: async (q) => [...await bank.listIncoming(q), ...await sending.listBoletoCredits(q)] };
}
