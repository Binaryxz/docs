/**
 * Banco Inter's corporate APIs ("Inter Empresas"), as one HTTP client: OAuth2, mTLS, the documented
 * rate limits, errors and money. `inter.ts` builds the `BankAdapter` on it.
 *
 * ## Why Inter
 *
 * A large traditional bank whose corporate API reference is readable without logging in, including
 * the machine-readable OpenAPI documents behind it, and which serves every operation the node needs
 * from its own treasury account: Pix payment to a key, boleto payment, boleto registration and
 * cancellation, statement, balance - plus the standard API Pix. It was the first candidate checked and
 * met the bar; Banco do Brasil's portal answered 403 to an anonymous client the same day, and Itaú,
 * Bradesco and Santander were not evaluated.
 *
 * ## Sources, read 2026-09-14
 *
 * The reference pages and the OpenAPI 3.0.3 documents they render (every `info.version` is empty;
 * the version is in the path - `/oauth/v2`, `/banking/v2`, `/cobranca/v3`, `/pix/v2`):
 *
 *  - Token:     https://developers.inter.co/references/token
 *               https://developers.inter.co/redocusaurus/swagger-token-yaml.yaml
 *  - Banking:   https://developers.inter.co/references/banking
 *               https://developers.inter.co/redocusaurus/swagger-banking-yaml.yaml
 *  - Cobrança (Boleto com Pix), v3:
 *               https://developers.inter.co/references/cobranca-bolepix
 *               https://developers.inter.co/redocusaurus/swagger-cobranca-bolepix-yaml.yaml
 *  - API Pix:   https://developers.inter.co/references/pix
 *               https://developers.inter.co/redocusaurus/swagger-api-pix-yaml.yaml
 *  - Prose:     https://developers.inter.co/docs/introducao/autenticacao-mtls,
 *               https://developers.inter.co/erros-status-code, https://developers.inter.co/duvidas-frequentes
 *
 * `test/banks/inter-openapi.json` is a scripted excerpt of those documents for the operations used
 * here; the request-schema test checks every call against it.
 *
 * ## What they say, and what this therefore does
 *
 *  - **Hosts.** Production `https://cdpj.partners.bancointer.com.br`, sandbox
 *    `https://cdpj-sandbox.partners.uatinter.co`. `baseUrl` is the host; paths carry the API and version.
 *  - **mTLS.** "é obrigatório o uso do certificado tanto na geração do token quanto nas requisições das
 *    nossas API" (erros-status-code, HTTP 400 without a message). The certificate and key are downloaded
 *    when the integration is created in the Internet Banking; `tls` carries them on every call.
 *  - **OAuth2 client credentials.** `POST /oauth/v2/token`, `application/x-www-form-urlencoded`, with
 *    `client_id`, `client_secret`, `grant_type` and `scope` all REQUIRED form fields (TokenRequest) - in
 *    the body, not HTTP Basic, which is why this does not reuse `ApiPixClient`'s token request. Scopes
 *    space-separated. The token lives 60 minutes and must be reused: the token endpoint allows 5 calls a
 *    minute, and generating one per request earns HTTP 429 (duvidas-frequentes). Renewed a minute early;
 *    a 401 renews once. When the response names the scopes granted, a call needing another is refused
 *    here, before anything is sent.
 *  - **Account header.** `x-conta-corrente` (digits with the check digit, no leading zeros), "necessário
 *    somente quando a aplicação estiver associada a mais de uma conta corrente". AMBIGUOUS: the parameter
 *    is defined as `x-conta-corrente`, but the curl samples in the same documents send
 *    `x-inter-conta-corrente`, and API Pix also defines an unused required `x-inter-conta-corrente`. This
 *    sends the defined name, and only when `account` is set.
 *  - **Rate limits.** Per endpoint, per minute, stated in each operation (`INTER_OPS`); exceeding one is
 *    HTTP 429 "sem mensagem de erro". No `Retry-After` is documented: one is honoured if present, and
 *    otherwise a call waits one slot of the endpoint's limit. The client also keeps its own sliding
 *    window per endpoint, so it waits rather than earns the 429, and refuses to wait longer than
 *    `maxWaitMs` (a node tick should not stall for a minute). A 429 is retried in the call only where a
 *    repeat cannot move money twice (reads, the Pix POST under its idempotency header, PUTs by id).
 *  - **Errors.** Banking and Cobrança answer RFC 7807-like `{ title, status, detail, timestamp,
 *    violacoes: [{ razao, propriedade, valor }] }` (some `status` values are strings in the examples);
 *    one schema is `{ erro: { mensagem, mensagemDetalhe, codigo, status } }`. `InterApiError` keeps the
 *    HTTP status, `title`, `erro.codigo` and the names of violated properties - never `detail`,
 *    `razao` or `valor`, which echo submitted keys and amounts into what would become a log line.
 *  - **Money.** Banking and Cobrança mix JSON numbers (`valor` of a Pix payment, `valorNominal`,
 *    `disponivel`) and decimal strings (`valorPagar`, `valorTotalRecebido`). A JSON number read through
 *    `JSON.parse` is a double, so responses are parsed with every number kept as its source text, and
 *    request numbers are written from centavos as exact decimal literals.
 *  - **Times.** Some fields are RFC 3339 with an offset; others are local date-times without one
 *    (`'2019-10-10 13:00:00'`, `'2022-07-06 11:12:29.810'`). The documents do not name the zone of the
 *    latter; they are read as Brasília (UTC-03:00, no daylight saving since 2019) - UNVERIFIED until a
 *    sandbox response is compared with a known wall-clock time.
 */
import { Agent as HttpsAgent, request as httpsRequest } from 'node:https';
import { request as httpRequest, type IncomingHttpHeaders } from 'node:http';

export const INTER_PRODUCTION_URL = 'https://cdpj.partners.bancointer.com.br';
export const INTER_SANDBOX_URL = 'https://cdpj-sandbox.partners.uatinter.co';

interface InterOp {
  method: 'GET' | 'POST' | 'PUT' | 'PATCH';
  path: string;
  scope?: string;
  /** Calls per minute as documented: [production, sandbox]. */
  perMinute: readonly [number, number];
  /** "Limitado a 1 chamada por segundo" on the Pix payment. */
  minIntervalMs?: number;
  /** A 429 may be retried inside the call: repeating it cannot move money twice. */
  retry429: boolean;
  /** API Pix follows the BCB spec (money as strings): plain JSON. Everything else: numbers kept exact. */
  plainJson?: boolean;
}

/** Every operation this client calls, with the scope and limits its reference page states. */
export const INTER_OPS = {
  token: { method: 'POST', path: '/oauth/v2/token', perMinute: [5, 5], retry429: true },
  pixPay: { method: 'POST', path: '/banking/v2/pix', scope: 'pagamento-pix.write', perMinute: [60, 10], minIntervalMs: 1000, retry429: true },
  pixPayGet: { method: 'GET', path: '/banking/v2/pix/{codigoSolicitacao}', scope: 'pagamento-pix.read', perMinute: [20, 10], retry429: true },
  boletoPay: { method: 'POST', path: '/banking/v2/pagamento', scope: 'pagamento-boleto.write', perMinute: [120, 10], retry429: false },
  boletoPayList: { method: 'GET', path: '/banking/v2/pagamento', scope: 'pagamento-boleto.read', perMinute: [120, 10], retry429: true },
  saldo: { method: 'GET', path: '/banking/v2/saldo', scope: 'extrato.read', perMinute: [10, 10], retry429: true },
  extrato: { method: 'GET', path: '/banking/v2/extrato/completo', scope: 'extrato.read', perMinute: [10, 10], retry429: true },
  cobrancaCreate: { method: 'POST', path: '/cobranca/v3/cobrancas', scope: 'boleto-cobranca.write', perMinute: [120, 10], retry429: false },
  cobrancaList: { method: 'GET', path: '/cobranca/v3/cobrancas', scope: 'boleto-cobranca.read', perMinute: [120, 10], retry429: true },
  cobrancaGet: { method: 'GET', path: '/cobranca/v3/cobrancas/{codigoSolicitacao}', scope: 'boleto-cobranca.read', perMinute: [120, 10], retry429: true },
  cobrancaCancel: { method: 'POST', path: '/cobranca/v3/cobrancas/{codigoSolicitacao}/cancelar', scope: 'boleto-cobranca.write', perMinute: [120, 10], retry429: true },
  pixList: { method: 'GET', path: '/pix/v2/pix', scope: 'pix.read', perMinute: [120, 10], retry429: true, plainJson: true },
  pixGet: { method: 'GET', path: '/pix/v2/pix/{e2eId}', scope: 'pix.read', perMinute: [120, 10], retry429: true, plainJson: true },
  devolucaoGet: { method: 'GET', path: '/pix/v2/pix/{e2eId}/devolucao/{id}', scope: 'pix.read', perMinute: [120, 10], retry429: true, plainJson: true },
  devolucaoPut: { method: 'PUT', path: '/pix/v2/pix/{e2eId}/devolucao/{id}', scope: 'pix.write', perMinute: [120, 10], retry429: true, plainJson: true },
  // Immediate charges, for `onramp.pixCharge: "cob"`: Inter's API Pix lists only charge-paid Pix, so an LP at Inter serves
  // charges. "Escopo requerido: cob.write" (PUT, PATCH) / "cob.read" (GET), 120 calls a minute (sandbox 10). A 429 is
  // retried: a repeated PUT for one txid is idempotent (Manual de Padrões, Annex I, footnote 85), and removal is a state.
  cobPut: { method: 'PUT', path: '/pix/v2/cob/{txid}', scope: 'cob.write', perMinute: [120, 10], retry429: true, plainJson: true },
  cobGet: { method: 'GET', path: '/pix/v2/cob/{txid}', scope: 'cob.read', perMinute: [120, 10], retry429: true, plainJson: true },
  cobPatch: { method: 'PATCH', path: '/pix/v2/cob/{txid}', scope: 'cob.write', perMinute: [120, 10], retry429: true, plainJson: true },
} as const satisfies Record<string, InterOp>;

export type InterOpName = keyof typeof INTER_OPS;

/** What the adapter needs. An integration missing one of these fails at the first call that needs it. */
export const INTER_DEFAULT_SCOPES = [
  'pagamento-pix.write', 'pagamento-pix.read', 'pagamento-boleto.write', 'pagamento-boleto.read', 'extrato.read',
  'boleto-cobranca.read', 'boleto-cobranca.write', 'pix.read', 'pix.write', 'cob.read', 'cob.write',
] as const;

export interface InterClientOptions {
  /** The host: `INTER_PRODUCTION_URL` or `INTER_SANDBOX_URL` (or a mock's). */
  baseUrl: string;
  clientId: string;
  clientSecret: string;
  scopes?: readonly string[];
  /** The certificate and key downloaded with the integration, and optionally the CA of Inter's server. */
  tls?: { cert: string | Buffer; key: string | Buffer; ca?: string | Buffer };
  /** `x-conta-corrente`, for an integration associated with more than one account. */
  account?: string;
  /** Which documented limits to keep; by default sandbox for the sandbox host, else production. */
  limits?: 'production' | 'sandbox' | 'off';
  /** The longest the client waits for a rate-limit slot or a Retry-After before giving up. */
  maxWaitMs?: number;
  timeoutMs?: number;
  /** Milliseconds. */
  now?: () => number;
  sleep?: (ms: number) => Promise<void>;
  /** Called with every access token issued, so a boundary can redact it. */
  onSecret?: (secret: string) => void;
}

export class InterApiError extends Error {
  constructor(
    readonly status: number,
    readonly title?: string,
    readonly code?: string,
    readonly properties: readonly string[] = [],
    readonly retryAfterMs?: number,
  ) {
    super(`Inter ${status}${title ? `: ${title}` : ''}${code ? ` (codigo ${code})` : ''}${properties.length ? ` [${properties.join(', ')}]` : ''}`);
  }
}

/**
 * The request did not reach the bank's application: refused connection, a local rate-limit wait
 * too long, no token, a 401 or 429. The adapter uses this to know a repeat is a first attempt.
 */
export function isUnsent(e: unknown): boolean {
  return !!e && typeof e === 'object' && (e as { interUnsent?: boolean }).interUnsent === true;
}

function unsent<E>(e: E): E {
  if (e && typeof e === 'object') (e as { interUnsent?: boolean }).interUnsent = true;
  return e;
}

/** Connection errors raised before a byte of the request can have been read by the server. */
const UNSENT_CODES = new Set([
  'ECONNREFUSED', 'ENOTFOUND', 'EAI_AGAIN', 'CERT_HAS_EXPIRED', 'UNABLE_TO_VERIFY_LEAF_SIGNATURE',
  'DEPTH_ZERO_SELF_SIGNED_CERT', 'SELF_SIGNED_CERT_IN_CHAIN', 'ERR_TLS_CERT_ALTNAME_INVALID',
]);

/*//////////////////////////////////////////////////////////////
                         MONEY AND TIME
//////////////////////////////////////////////////////////////*/

/** A JSON number written exactly as given. */
export class InterDecimal {
  constructor(readonly text: string) {
    if (!/^-?\d+(\.\d+)?$/.test(text)) throw new Error('not a decimal');
  }
}

/** Centavos as a decimal of reais: 12345n -> 123.45. */
export function reais(cents: bigint): string {
  const neg = cents < 0n;
  const a = neg ? -cents : cents;
  return `${neg ? '-' : ''}${a / 100n}.${(a % 100n).toString().padStart(2, '0')}`;
}

const NUM_MARK = '@@inter-decimal:';

/** JSON.stringify, with every `InterDecimal` written as a bare number literal. */
export function interJson(body: unknown): string {
  return JSON.stringify(body, (_k, v: unknown) => (v instanceof InterDecimal ? `${NUM_MARK}${v.text}@@` : v))
    .replace(new RegExp(`"${NUM_MARK}(-?[0-9.]+)@@"`, 'g'), '$1');
}

/** JSON.parse with every number kept as its source text, so no amount passes through a double. */
export function parseInterJson(text: string): unknown {
  let out = '';
  for (let i = 0; i < text.length;) {
    const c = text[i];
    if (c === '"') {
      let j = i + 1;
      while (j < text.length && text[j] !== '"') j += text[j] === '\\' ? 2 : 1;
      out += text.slice(i, j + 1);
      i = j + 1;
    } else if (c === '-' || (c >= '0' && c <= '9')) {
      let j = i + 1;
      while (j < text.length && /[0-9eE+\-.]/.test(text[j])) j++;
      out += `"${text.slice(i, j)}"`;
      i = j;
    } else {
      out += c;
      i++;
    }
  }
  return JSON.parse(out);
}

/** A decimal amount of reais (source text or string) to centavos; anything but up to two places is refused. */
export function centsOf(v: unknown, what: string): bigint {
  const s = typeof v === 'string' ? v.trim() : '';
  const m = /^(-?)(\d{1,15})(?:\.(\d{1,2}))?$/.exec(s);
  if (!m) throw new Error(`malformed ${what}`);
  const cents = BigInt(m[2]) * 100n + BigInt((m[3] ?? '0').padEnd(2, '0'));
  return m[1] ? -cents : cents;
}

/**
 * An Inter timestamp to unix seconds: RFC 3339 with an offset, or a local date-time without one,
 * read as Brasília (UTC-03:00; see the header). Undefined when it is neither - a date alone included,
 * because a settlement time rounded to midnight would predate the claim it settles.
 */
export function interTime(v: unknown): bigint | undefined {
  if (typeof v !== 'string') return undefined;
  const m = /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::(\d{2})(?:[.,]\d+)?)?\s*(Z|[+-]\d{2}:?\d{2})?$/.exec(v.trim());
  if (!m) return undefined;
  const [, y, mo, d, h, mi, s, zone] = m;
  let offsetMin = -180;
  if (zone === 'Z') offsetMin = 0;
  else if (zone) offsetMin = (zone[0] === '-' ? -1 : 1) * (Number(zone.slice(1, 3)) * 60 + Number(zone.slice(-2)));
  const utc = Date.UTC(Number(y), Number(mo) - 1, Number(d), Number(h), Number(mi), Number(s ?? 0)) - offsetMin * 60_000;
  return Number.isNaN(utc) ? undefined : BigInt(Math.floor(utc / 1000));
}

/** Unix seconds to the Brasília calendar day, `YYYY-MM-DD`. */
export function brasiliaDay(unixSeconds: bigint | number): string {
  return new Date(Number(unixSeconds) * 1000 - 3 * 3600_000).toISOString().slice(0, 10);
}

/*//////////////////////////////////////////////////////////////
                             CLIENT
//////////////////////////////////////////////////////////////*/

interface Response { status: number; headers: IncomingHttpHeaders; body: string }

/** `Retry-After` as milliseconds from now: delta-seconds or an HTTP-date. */
function retryAfterMs(h: string | string[] | undefined, now: number): number | undefined {
  const v = Array.isArray(h) ? h[0] : h;
  if (!v) return undefined;
  if (/^\d+$/.test(v.trim())) return Number(v.trim()) * 1000;
  const at = Date.parse(v);
  return Number.isNaN(at) ? undefined : Math.max(0, at - now);
}

function apiError(res: Response, retryAfter?: number): InterApiError {
  let title: string | undefined;
  let code: string | undefined;
  let properties: string[] = [];
  try {
    const j = JSON.parse(res.body) as { title?: unknown; erro?: { codigo?: unknown }; violacoes?: { propriedade?: unknown }[] };
    if (typeof j.title === 'string') title = j.title.slice(0, 100);
    if (j.erro && (typeof j.erro.codigo === 'number' || typeof j.erro.codigo === 'string')) code = String(j.erro.codigo).slice(0, 20);
    if (Array.isArray(j.violacoes)) {
      properties = j.violacoes.map((x) => x?.propriedade).filter((p): p is string => typeof p === 'string' && /^[\w.[\]]{1,60}$/.test(p));
    }
  } catch {
    // no body, or not JSON (the documented 400 without a certificate has no message)
  }
  return new InterApiError(res.status, title, code, properties, retryAfter);
}

export class InterClient {
  readonly baseUrl: string;
  private token?: { value: string; expiresAt: number; granted?: Set<string> };
  private readonly agent?: HttpsAgent;
  private readonly windows = new Map<string, number[]>();
  private readonly lastAt = new Map<string, number>();
  private readonly limits: 'production' | 'sandbox' | 'off';

  constructor(private readonly o: InterClientOptions) {
    this.baseUrl = o.baseUrl.replace(/\/+$/, '');
    if (o.tls) this.agent = new HttpsAgent({ cert: o.tls.cert, key: o.tls.key, ca: o.tls.ca, keepAlive: true });
    this.limits = o.limits ?? (/uatinter\.co/.test(this.baseUrl) ? 'sandbox' : 'production');
  }

  get sandbox(): boolean {
    return /uatinter\.co/.test(this.baseUrl);
  }

  now(): number {
    return this.o.now ? this.o.now() : Date.now();
  }

  sleep(ms: number): Promise<void> {
    return this.o.sleep ? this.o.sleep(ms) : new Promise((r) => setTimeout(r, ms));
  }

  private get maxWaitMs(): number {
    return this.o.maxWaitMs ?? 15_000;
  }

  private send(method: string, url: URL, headers: Record<string, string>, body?: string): Promise<Response> {
    return new Promise((resolve, reject) => {
      const https = url.protocol === 'https:';
      const req = (https ? httpsRequest : httpRequest)(url, {
        method, headers: { ...headers, ...(body !== undefined ? { 'content-length': String(Buffer.byteLength(body)) } : {}) },
        ...(https && this.agent ? { agent: this.agent } : {}),
        timeout: this.o.timeoutMs ?? 20_000,
      }, (res) => {
        const chunks: Buffer[] = [];
        res.on('data', (c: Buffer) => chunks.push(c));
        res.on('end', () => resolve({ status: res.statusCode ?? 0, headers: res.headers, body: Buffer.concat(chunks).toString('utf8') }));
        res.on('error', reject);
      });
      req.on('timeout', () => req.destroy(new Error('Inter request timed out')));
      req.on('error', (e: Error & { code?: string }) => reject(e.code && UNSENT_CODES.has(e.code) ? unsent(e) : e));
      if (body !== undefined) req.write(body);
      req.end();
    });
  }

  /** Wait for a slot in the endpoint's documented per-minute window, or refuse if it is too far. */
  private async gate(name: InterOpName): Promise<void> {
    if (this.limits === 'off') return;
    const op: InterOp = INTER_OPS[name];
    const limit = op.perMinute[this.limits === 'sandbox' ? 1 : 0];
    for (;;) {
      const now = this.now();
      const w = (this.windows.get(name) ?? []).filter((t) => t > now - 60_000);
      let wait = w.length >= limit ? w[0] + 60_000 - now : 0;
      const last = this.lastAt.get(name);
      if (op.minIntervalMs && last !== undefined) wait = Math.max(wait, last + op.minIntervalMs - now);
      if (wait <= 0) {
        w.push(now);
        this.windows.set(name, w);
        this.lastAt.set(name, now);
        return;
      }
      if (wait > this.maxWaitMs) throw unsent(new InterApiError(429, `local rate limit for ${name}`, undefined, [], wait));
      await this.sleep(wait);
    }
  }

  private defaultWait(name: InterOpName): number {
    const limit = INTER_OPS[name].perMinute[this.sandbox ? 1 : 0];
    return Math.ceil(60_000 / limit);
  }

  private async accessToken(force: boolean): Promise<{ value: string; granted?: Set<string> }> {
    if (!force && this.token && this.token.expiresAt > this.now()) return this.token;
    const scopes = this.o.scopes ?? INTER_DEFAULT_SCOPES;
    const form = new URLSearchParams({
      client_id: this.o.clientId, client_secret: this.o.clientSecret, grant_type: 'client_credentials', scope: scopes.join(' '),
    }).toString();
    for (let tries = 0; ; tries++) {
      await this.gate('token');
      const res = await this.send('POST', new URL(`${this.baseUrl}${INTER_OPS.token.path}`), {
        'content-type': 'application/x-www-form-urlencoded', accept: 'application/json',
      }, form);
      if (res.status === 429) {
        const wait = retryAfterMs(res.headers['retry-after'], this.now()) ?? this.defaultWait('token');
        if (tries < 2 && wait <= this.maxWaitMs) {
          await this.sleep(wait);
          continue;
        }
        throw new InterApiError(429, 'token rate limit', undefined, [], wait);
      }
      // Never the body: an OAuth error body can echo the client id.
      if (res.status !== 200) throw new InterApiError(res.status, 'token request refused');
      let j: { access_token?: unknown; expires_in?: unknown; scope?: unknown };
      try {
        j = JSON.parse(res.body) as typeof j;
      } catch {
        throw new InterApiError(res.status, 'token response is not JSON');
      }
      if (typeof j.access_token !== 'string' || !j.access_token) throw new InterApiError(res.status, 'token response without access_token');
      this.o.onSecret?.(j.access_token);
      const ttl = typeof j.expires_in === 'number' ? j.expires_in : Number(j.expires_in) || 3600;
      this.token = {
        value: j.access_token,
        // Renew a minute early, so a token never expires between being read and being used.
        expiresAt: this.now() + Math.max(0, ttl - 60) * 1000,
        granted: typeof j.scope === 'string' && j.scope.trim() ? new Set(j.scope.trim().split(/\s+/)) : undefined,
      };
      return this.token;
    }
  }

  /**
   * One documented operation. `params` fill the path, `query` the query string (undefined entries are
   * left out), `body` is sent as JSON. Retries once with a fresh token on 401, and on 429 where the
   * operation allows it. Throws `InterApiError` for any other non-2xx.
   */
  async request<T = unknown>(name: InterOpName, o: {
    params?: Record<string, string>; query?: Record<string, string | number | undefined>; body?: unknown; headers?: Record<string, string>;
  } = {}): Promise<{ status: number; data: T }> {
    const op: InterOp = INTER_OPS[name];
    const path = op.path.replace(/\{(\w+)\}/g, (_m, p: string) => {
      const v = o.params?.[p];
      if (!v) throw new Error(`missing path parameter ${p}`);
      return encodeURIComponent(v);
    });
    const url = new URL(`${this.baseUrl}${path}`);
    for (const [k, v] of Object.entries(o.query ?? {})) if (v !== undefined) url.searchParams.set(k, String(v));
    const body = o.body === undefined ? undefined : interJson(o.body);
    let refreshed = false;
    for (let tries429 = 0; ;) {
      let token: { value: string; granted?: Set<string> };
      try {
        token = await this.accessToken(false);
      } catch (e) {
        throw unsent(e);
      }
      if (op.scope && token.granted && !token.granted.has(op.scope)) {
        throw unsent(new InterApiError(403, `the token was not granted ${op.scope}: enable it on the integration`));
      }
      try {
        await this.gate(name);
      } catch (e) {
        throw unsent(e);
      }
      const res = await this.send(op.method, url, {
        authorization: `Bearer ${token.value}`, accept: 'application/json',
        ...(this.o.account ? { 'x-conta-corrente': this.o.account } : {}),
        ...(body !== undefined ? { 'content-type': 'application/json' } : {}),
        ...o.headers,
      }, body);
      if (res.status === 401 && !refreshed) {
        refreshed = true;
        this.token = undefined;
        continue;
      }
      if (res.status === 429) {
        const wait = retryAfterMs(res.headers['retry-after'], this.now()) ?? this.defaultWait(name);
        if (op.retry429 && tries429 < 3 && wait <= this.maxWaitMs) {
          tries429++;
          await this.sleep(wait);
          continue;
        }
        throw unsent(apiError(res, wait));
      }
      if (res.status >= 200 && res.status < 300) {
        const data = !res.body ? undefined : op.plainJson ? JSON.parse(res.body) : parseInterJson(res.body);
        return { status: res.status, data: data as T };
      }
      const err = apiError(res);
      throw res.status === 401 ? unsent(err) : err;
    }
  }
}
