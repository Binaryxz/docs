/**
 * Following the escrows' logs across restarts and reorgs.
 *
 * ## Events say what to look at; storage says what is true
 *
 * The node never acts on an event's contents. An `OrderLocked` makes it start tracking an order
 * id; whether that order is locked, released or was never mined at all is read from
 * `FiatEscrow.orders(id)` before anything happens. That is what makes reorg handling here
 * simple rather than clever: an event that is reorged away leaves an id whose storage reads
 * `NONE`, which the handlers drop, and an event re-delivered after a rewind is a no-op because
 * tracking is a set.
 *
 * ## Detecting a reorg
 *
 * The cursor stores the hash of the last block it scanned. Each poll re-reads that block; a
 * different hash (or a chain that is now shorter) means the blocks under the cursor changed, and
 * the cursor rewinds `reorgWindow` blocks and rescans. A reorg deeper than the window would be
 * missed as a reorg - but the handlers' confirmed reads (state at `head - confirmations + 1`)
 * never depended on the event scan to be safe, only to be complete; keep `reorgWindow` at least
 * `confirmations`.
 *
 * The cursor is persisted when a scan found something, and otherwise every `persistEvery`
 * blocks: a restart rescans at most that many empty blocks, and the journal does not grow by a
 * line every twelve seconds on a quiet chain.
 */
import type { BlockRef, RampChain, RampEvent } from './chain.js';
import type { Store } from './store.js';

export interface EventSyncOptions {
  /** The block the escrows were deployed in; nothing earlier is read. */
  fromBlock: bigint;
  reorgWindow: bigint;
  /** Largest getLogs range; halved on refusal, since providers cap it without saying. */
  span?: bigint;
  persistEvery?: bigint;
}

export class EventSync {
  reorgs = 0;
  private lastPersisted?: bigint;

  constructor(private readonly chain: RampChain, private readonly store: Store, private readonly o: EventSyncOptions) {}

  get indexedBlock(): bigint {
    return this.store.cursor?.block ?? this.o.fromBlock - 1n;
  }

  async poll(): Promise<{ head: BlockRef; events: RampEvent[]; reorged: boolean }> {
    const head = await this.chain.head();
    const floor = this.o.fromBlock - 1n;
    let from = this.store.cursor ? this.store.cursor.block : floor;
    let reorged = false;

    if (this.store.cursor) {
      const seen = head.number >= this.store.cursor.block ? await this.chain.block(this.store.cursor.block) : undefined;
      if (!seen || seen.hash.toLowerCase() !== this.store.cursor.hash.toLowerCase()) {
        reorged = true;
        this.reorgs++;
        const anchor = head.number < this.store.cursor.block ? head.number : this.store.cursor.block;
        from = anchor - this.o.reorgWindow > floor ? anchor - this.o.reorgWindow : floor;
      }
    }

    const events: RampEvent[] = [];
    let span = this.o.span ?? 2_000n;
    let next = from + 1n;
    while (next <= head.number) {
      const to = next + span - 1n > head.number ? head.number : next + span - 1n;
      try {
        events.push(...await this.chain.events(next, to));
        next = to + 1n;
      } catch (e) {
        if (span <= 1n) throw e;
        span /= 2n;
      }
    }

    const every = this.o.persistEvery ?? 100n;
    const moved = !this.store.cursor || this.store.cursor.block !== head.number || this.store.cursor.hash !== head.hash;
    if (moved && (reorged || events.length > 0 || this.lastPersisted === undefined
      || head.number - this.lastPersisted >= every)) {
      this.store.record({ t: 'cursor', block: head.number, hash: head.hash });
      this.lastPersisted = head.number;
    } else if (moved) {
      // Not persisted this time; keep the in-memory cursor moving so the next poll starts here.
      this.store.cursor = { block: head.number, hash: head.hash };
    }
    return { head, events, reorged };
  }
}
