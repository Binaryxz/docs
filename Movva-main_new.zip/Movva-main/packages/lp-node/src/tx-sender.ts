/**
 * Sending the LP's transactions so a stuck one does not stall the node, and a receipt is only ever ours.
 *
 * ## Why this exists
 *
 * Every transaction from the LP key queues behind the one before it. A single transaction priced under a
 * rising base fee sits in the mempool, and everything after it - claims with a 45-minute clock, releases,
 * refunds of offers - waits with it. viem's `waitForTransactionReceipt` would also, on seeing another
 * transaction mined at that nonce, hand back THAT transaction's receipt as if it were ours: a claim
 * "mined" by whatever replaced it.
 *
 * ## What it does
 *
 *  - **An explicit nonce and capped fees** on every send: the node's estimate, never above
 *    `maxFeePerGasWei` / `maxPriorityFeePerGasWei`.
 *  - **A gas limit with headroom**, never the node's bare estimate. `eth_estimateGas` finds the least gas
 *    that succeeds on the state and block it estimates at; included a block later, a transaction whose path
 *    costs a few gas more (a timestamp past a clamp, a slot another transaction wrote) runs out of gas at
 *    exactly that and pays its whole limit for nothing. The limit is the estimate plus `gasHeadroomPercent`
 *    (default 20%) plus 25,000 gas - one storage slot written from zero, which is more than 20% of a small
 *    transaction - never above the block gas limit (`withGasHeadroom`, the rule @mova/yield's keepers and
 *    the wallet's EOA executor apply too). Unused gas is not charged. A replacement keeps the limit of the
 *    transaction it replaces: it is that transaction at higher fees, nothing else.
 *  - **Why a write reverted** (`revertReason`), on the result of `sendAndWait`: `out of gas (used X of Y)`
 *    when it used its whole limit, else the error its call raises replayed on the parent block, else
 *    `unknown` with what is known.
 *  - **Its own receipt polling**, by hash. A receipt counts only for a hash this sender broadcast for that
 *    nonce. If the nonce is spent at the head and none of those hashes has a receipt, something else took
 *    it: the write fails as `ChainRevert('replaced')`, and the handler re-reads the chain next tick.
 *  - **Replacement.** A transaction not mined `replaceAfterBlocks` after it was last sent is re-sent at the
 *    same nonce with both fees raised by `bumpBps` (at least 10%, what nodes require) and at least to the
 *    current estimate - up to the cap, and never past it. At the cap it keeps waiting and says so.
 *  - **Earlier transactions first.** Before a new nonce, any pending transaction of this account below it is
 *    followed too: a timed-out write of this process, or one a previous process left behind, found in the
 *    node's pending block and adopted. One that cannot be found, and still blocks after
 *    `replaceAfterBlocks`, is cancelled by a zero-value transfer to self at that nonce. Cancelling an unknown
 *    write is safe here because every handler re-plans from chain state, and a gateway intent resolves from
 *    its nonce (gateway.ts); nonces the gateway is managing are left to it (`reserve`).
 *
 * A write that is still unmined after `waitBlocks` throws, stays tracked, and is followed (and bumped) by
 * the next write.
 */
import {
  BaseError, TransactionNotFoundError, TransactionReceiptNotFoundError, decodeErrorResult,
  type Abi, type Account, type Address, type Chain, type Hex, type PublicClient, type TransactionReceipt, type Transport, type WalletClient,
} from 'viem';
import { ChainRevert } from './chain.js';

export interface TxPolicy {
  /** Re-send an unmined transaction after this many blocks. 0 never replaces. */
  replaceAfterBlocks: number;
  /** Each replacement raises both fees by at least this much. At least 1000 (10%). */
  bumpBps: number;
  /** Never offer more per gas than this. Undefined: no cap (and no replacement beyond the estimate). */
  maxFeePerGasWei?: bigint;
  maxPriorityFeePerGasWei?: bigint;
  /** Stop waiting for a write after this many blocks; it stays tracked. */
  waitBlocks: number;
  /** Gas limit over the node's estimate, percent, plus 25,000 gas (`withGasHeadroom`). 0 to 100; default 20. */
  gasHeadroomPercent?: number;
}

export const NO_REPLACEMENT: TxPolicy = { replaceAfterBlocks: 0, bumpBps: 1_250, waitBlocks: 30 };

export type TxEvent =
  | { type: 'replaced'; nonce: number; maxFeePerGas: bigint }
  | { type: 'capped'; nonce: number; maxFeePerGas: bigint }
  | { type: 'adopted'; nonce: number }
  | { type: 'cancelled'; nonce: number };

export interface TxRequest {
  to: Address;
  data: Hex;
  value?: bigint;
  /** A limit sent as is. Without it, the node's estimate with headroom. */
  gas?: bigint;
  /** The contract's errors, to name a revert with (`revertReason`). */
  abi?: Abi;
}

/** A receipt from `sendAndWait`, with why it reverted when it did. */
export type SentReceipt = TransactionReceipt & { revertReason?: string };

interface Fees { maxFeePerGas: bigint; maxPriorityFeePerGas: bigint }

interface Tracked {
  nonce: number;
  hashes: Hex[];
  firstBlock: bigint;
  lastSentBlock: bigint;
  capped?: boolean;
  /** Seen pending at this nonce but not found: cancelled when it outstays `replaceAfterBlocks`. */
  unknown?: boolean;
}

export type ReplaceResult = { hash: Hex } | { capped: true } | { gone: true };

const BPS = 10_000n;

export const DEFAULT_GAS_HEADROOM_PERCENT = 20;
/** One storage slot written from zero, cold (22,100 gas), rounded up. */
export const GAS_HEADROOM_EXTRA = 25_000n;

/** The gas limit to send with, given the node's estimate (see the header). */
export function withGasHeadroom(estimate: bigint, blockGasLimit: bigint, percent: number = DEFAULT_GAS_HEADROOM_PERCENT): bigint {
  if (!Number.isInteger(percent) || percent < 0 || percent > 100) {
    throw new RangeError(`gas headroom must be a whole percentage from 0 to 100, not ${percent}`);
  }
  const padded = estimate + (estimate * BigInt(percent)) / 100n + GAS_HEADROOM_EXTRA;
  if (padded <= blockGasLimit) return padded;
  // A block holds no more. An estimate already over it is refused by the node either way.
  return estimate > blockGasLimit ? estimate : blockGasLimit;
}

/** A revert's error from its data anywhere in the cause chain: named by `abi`, Solidity's `Error`/`Panic`, or its selector. */
export function describeRevert(e: unknown, abi?: Abi): string | undefined {
  let cur: unknown = e;
  for (let i = 0; i < 10 && cur; i++) {
    const c = cur as { data?: unknown; raw?: unknown; cause?: unknown };
    const nested = c.data && typeof c.data === 'object' ? (c.data as { data?: unknown }).data : undefined;
    for (const hex of [c.raw, c.data, nested]) {
      if (typeof hex !== 'string' || !/^0x[0-9a-fA-F]{8,}$/.test(hex)) continue;
      try {
        const d = decodeErrorResult({ abi, data: hex as Hex });
        return `${d.errorName}(${(d.args ?? []).map(String).join(', ')})`;
      } catch {
        return `custom error ${hex.slice(0, 10)}`;
      }
    }
    cur = c.cause;
  }
  return undefined;
}

const firstLine = (e: unknown) => (e instanceof BaseError ? e.shortMessage : e instanceof Error ? e.message : String(e)).split('\n')[0];
const notFound = (e: unknown, cls: typeof TransactionNotFoundError | typeof TransactionReceiptNotFoundError) =>
  e instanceof BaseError && !!e.walk((x) => x instanceof cls);

export class TxSender {
  private readonly tracked = new Map<number, Tracked>();
  private reserved = new Set<number>();

  constructor(
    private readonly pub: PublicClient,
    private readonly wallet: WalletClient<Transport, Chain, Account>,
    readonly policy: TxPolicy = NO_REPLACEMENT,
    private readonly onEvent: (e: TxEvent) => void = () => {},
    private readonly sleep: (ms: number) => Promise<void> = (ms) => new Promise((r) => setTimeout(r, ms)),
  ) {
    if (policy.bumpBps < 1_000) throw new Error('bumpBps must be at least 1000: nodes refuse a replacement under 10%');
    const headroom = policy.gasHeadroomPercent;
    if (headroom !== undefined && !(Number.isInteger(headroom) && headroom >= 0 && headroom <= 100)) {
      throw new Error('gasHeadroomPercent must be a whole number from 0 to 100');
    }
  }

  private get account(): Address {
    return this.wallet.account.address;
  }

  /** Nonces someone else replaces and resolves (the gateway's open intents). */
  reserve(nonces: Iterable<number>): void {
    this.reserved = new Set(nonces);
  }

  /** The node's fee estimate, capped. */
  async fees(): Promise<Fees> {
    const est = await this.pub.estimateFeesPerGas();
    return this.capped({ maxFeePerGas: est.maxFeePerGas, maxPriorityFeePerGas: est.maxPriorityFeePerGas });
  }

  private capped(f: Fees): Fees {
    let { maxFeePerGas, maxPriorityFeePerGas } = f;
    if (this.policy.maxFeePerGasWei !== undefined && maxFeePerGas > this.policy.maxFeePerGasWei) maxFeePerGas = this.policy.maxFeePerGasWei;
    if (this.policy.maxPriorityFeePerGasWei !== undefined && maxPriorityFeePerGas > this.policy.maxPriorityFeePerGasWei) {
      maxPriorityFeePerGas = this.policy.maxPriorityFeePerGasWei;
    }
    if (maxPriorityFeePerGas > maxFeePerGas) maxPriorityFeePerGas = maxFeePerGas;
    return { maxFeePerGas, maxPriorityFeePerGas };
  }

  /** The limit `req` is sent with: its own, or the node's estimate with headroom, capped at the block gas limit. */
  async gasLimit(req: TxRequest): Promise<bigint> {
    if (req.gas !== undefined) return req.gas;
    const [estimate, block] = await Promise.all([
      this.pub.estimateGas({ account: this.wallet.account, to: req.to, data: req.data, value: req.value }),
      this.pub.getBlock(),
    ]);
    return withGasHeadroom(estimate, block.gasLimit, this.policy.gasHeadroomPercent);
  }

  /** One broadcast at an explicit nonce. Resolves with the hash, not the receipt. */
  async broadcast(req: TxRequest, nonce: number, fees?: Fees): Promise<Hex> {
    const f = fees ?? await this.fees();
    const gas = await this.gasLimit(req);
    return this.wallet.sendTransaction({
      account: this.wallet.account, chain: this.wallet.chain, to: req.to, data: req.data, value: req.value ?? 0n, gas, nonce, ...f,
    });
  }

  /** Send at the next nonce, follow what is pending before it, and wait for this transaction's own receipt. */
  async sendAndWait(req: TxRequest): Promise<SentReceipt> {
    const head = await this.pub.getBlockNumber();
    await this.adoptBacklog(head);
    const nonce = await this.pub.getTransactionCount({ address: this.account, blockTag: 'pending' });
    const hash = await this.broadcast(req, nonce);
    const t: Tracked = { nonce, hashes: [hash], firstBlock: head, lastSentBlock: head };
    this.tracked.set(nonce, t);
    const r = await this.waitFor(t);
    return r.status === 'success' ? r : { ...r, revertReason: await this.revertReason(r, req.abi) };
  }

  /**
   * Why a mined transaction reverted, as far as the chain can tell:
   *
   *  - `out of gas (used X of Y)` when it used its whole limit;
   *  - otherwise the error its call raises replayed on the parent block, from the same account with the same
   *    limit and value, named by `abi` or as Solidity's `Error` / `Panic`;
   *  - otherwise `unknown (...)`, with what is known.
   *
   * The transaction is read back by hash, so a hash from the journal serves as well as one just sent. The
   * replay runs on the parent's state and timestamp - nodes do not all take block overrides, anvil 0.3.0
   * refuses them - so a revert caused by an earlier transaction in the same block, or by the block's own
   * time, can replay as a success, and then says so. Never throws.
   */
  async revertReason(receipt: Pick<TransactionReceipt, 'transactionHash' | 'blockNumber' | 'gasUsed'>, abi?: Abi): Promise<string> {
    let tx: Awaited<ReturnType<PublicClient['getTransaction']>>;
    try {
      tx = await this.pub.getTransaction({ hash: receipt.transactionHash });
    } catch (e) {
      return `unknown (used ${receipt.gasUsed} gas; the transaction could not be read back: ${firstLine(e)})`;
    }
    const used = `used ${receipt.gasUsed} of ${tx.gas}`;
    if (receipt.gasUsed >= tx.gas) return `out of gas (${used})`;
    const parent = receipt.blockNumber - 1n;
    try {
      await this.pub.call({ account: tx.from, to: tx.to ?? undefined, data: tx.input, value: tx.value, gas: tx.gas, blockNumber: parent });
    } catch (e) {
      return describeRevert(e, abi) ?? `unknown (${used} gas; replayed at block ${parent}: ${firstLine(e)})`;
    }
    return `unknown (${used} gas; the call succeeds replayed at block ${parent})`;
  }

  /** Pending transactions of this account at nonces this process does not follow yet. */
  private async adoptBacklog(head: bigint): Promise<void> {
    const [latest, pending] = await Promise.all([
      this.pub.getTransactionCount({ address: this.account, blockTag: 'latest' }),
      this.pub.getTransactionCount({ address: this.account, blockTag: 'pending' }),
    ]);
    for (const n of [...this.tracked.keys()]) if (n < latest) this.tracked.delete(n);
    if (pending <= latest) return;
    let block: Awaited<ReturnType<PublicClient['getBlock']>> | undefined;
    for (let n = latest; n < pending; n++) {
      if (this.tracked.has(n) || this.reserved.has(n)) continue;
      block ??= await this.pub.getBlock({ blockTag: 'pending', includeTransactions: true }).catch(() => undefined);
      const tx = block?.transactions.find((x): x is Exclude<typeof x, string> =>
        typeof x !== 'string' && x.from.toLowerCase() === this.account.toLowerCase() && x.nonce === n);
      this.tracked.set(n, tx
        ? { nonce: n, hashes: [tx.hash], firstBlock: head, lastSentBlock: head }
        : { nonce: n, hashes: [], firstBlock: head, lastSentBlock: head, unknown: true });
      if (tx) this.onEvent({ type: 'adopted', nonce: n });
    }
  }

  /**
   * Re-send the transaction `hash` at its nonce with bumped fees. `gone` when the node no longer holds it
   * pending (mined, or dropped); `capped` when the cap leaves no valid bump.
   */
  async replace(hash: Hex): Promise<ReplaceResult> {
    let tx;
    try {
      tx = await this.pub.getTransaction({ hash });
    } catch (e) {
      if (notFound(e, TransactionNotFoundError)) return { gone: true };
      throw e;
    }
    if (tx.blockNumber !== null && tx.blockNumber !== undefined) return { gone: true };
    const prevFee = tx.maxFeePerGas ?? tx.gasPrice ?? 0n;
    const prevTip = tx.maxPriorityFeePerGas ?? tx.gasPrice ?? 0n;
    const bump = (v: bigint) => (v * (BPS + BigInt(this.policy.bumpBps)) + BPS - 1n) / BPS;
    const est = await this.pub.estimateFeesPerGas();
    const want: Fees = {
      maxFeePerGas: est.maxFeePerGas > bump(prevFee) ? est.maxFeePerGas : bump(prevFee),
      maxPriorityFeePerGas: est.maxPriorityFeePerGas > bump(prevTip) ? est.maxPriorityFeePerGas : bump(prevTip),
    };
    const next = this.capped(want);
    // A node refuses a replacement that does not raise both fees by 10%: below that, the cap has been reached.
    const min = (v: bigint) => (v * 11_000n + BPS - 1n) / BPS;
    if (next.maxFeePerGas < min(prevFee) || next.maxPriorityFeePerGas < min(prevTip)) {
      this.onEvent({ type: 'capped', nonce: tx.nonce, maxFeePerGas: prevFee });
      return { capped: true };
    }
    // The same limit as the transaction it replaces, read back from the node: only the fees change.
    const replacement = await this.wallet.sendTransaction({
      account: this.wallet.account, chain: this.wallet.chain, to: tx.to ?? undefined, data: tx.input, value: tx.value,
      gas: tx.gas, nonce: tx.nonce, ...next,
    });
    this.onEvent({ type: 'replaced', nonce: tx.nonce, maxFeePerGas: next.maxFeePerGas });
    return { hash: replacement };
  }

  /** A receipt for one of `hashes`, or undefined. Receipts are fetched by hash: a replacement's is never taken for ours. */
  private async receipt(hashes: readonly Hex[]): Promise<TransactionReceipt | undefined> {
    for (const hash of hashes) {
      try {
        const r = await this.pub.getTransactionReceipt({ hash });
        if (r.transactionHash.toLowerCase() === hash.toLowerCase()) return r;
      } catch (e) {
        if (!notFound(e, TransactionReceiptNotFoundError)) throw e;
      }
    }
    return undefined;
  }

  /** Follow one nonce to its end: our receipt, another transaction's use of the nonce, or the wait running out. */
  private async waitFor(t: Tracked): Promise<TransactionReceipt> {
    const poll = Math.max(1, this.pub.pollingInterval ?? 1_000);
    for (;;) {
      const head = await this.pub.getBlockNumber();
      const r = await this.receipt(t.hashes);
      if (r) {
        this.tracked.delete(t.nonce);
        return r;
      }
      const latest = await this.pub.getTransactionCount({ address: this.account, blockTag: 'latest' });
      if (latest > t.nonce) {
        const late = await this.receipt(t.hashes); // mined between the two reads
        this.tracked.delete(t.nonce);
        if (late) return late;
        throw new ChainRevert('replaced', `nonce ${t.nonce} was used by another transaction; this write did not happen`);
      }
      // Earlier nonces hold this one back: follow them too.
      for (const lower of this.tracked.values()) {
        if (lower.nonce < t.nonce && lower.nonce >= latest) await this.nudge(lower, head);
      }
      await this.nudge(t, head);
      if (head - t.firstBlock >= BigInt(this.policy.waitBlocks)) {
        throw new Error(`transaction at nonce ${t.nonce} not mined after ${this.policy.waitBlocks} blocks; it is still followed`);
      }
      await this.sleep(poll);
    }
  }

  /** Replace (or, unknown, cancel) a tracked transaction that has outstayed `replaceAfterBlocks`. */
  private async nudge(t: Tracked, head: bigint): Promise<void> {
    const n = this.policy.replaceAfterBlocks;
    if (n <= 0 || head - t.lastSentBlock < BigInt(n) || this.reserved.has(t.nonce)) return;
    t.lastSentBlock = head;
    if (t.unknown) {
      // Nothing to re-send: take the nonce back with a transfer to self, at the most the cap allows.
      const f = this.capped({ maxFeePerGas: this.policy.maxFeePerGasWei ?? (await this.fees()).maxFeePerGas * 2n,
        maxPriorityFeePerGas: this.policy.maxPriorityFeePerGasWei ?? (await this.fees()).maxPriorityFeePerGas * 2n });
      try {
        const hash = await this.broadcast({ to: this.account, data: '0x', value: 0n, gas: 21_000n }, t.nonce, f);
        t.hashes.push(hash);
        t.unknown = false;
        this.onEvent({ type: 'cancelled', nonce: t.nonce });
      } catch {
        // Underpriced against whatever holds the nonce: tried again after another `replaceAfterBlocks`.
      }
      return;
    }
    const latest = t.hashes[t.hashes.length - 1];
    const r = await this.replace(latest).catch(() => ({ capped: true }) as const);
    if ('hash' in r) t.hashes.push(r.hash);
    else if ('capped' in r) t.capped = true;
  }
}
