/**
 * Node-provider rewards: the LP claims its share of Mova's fees from NodeRewards. Design: docs/movva.md, "Fees"; the
 * contract: contracts/ramp/NodeRewards.sol; what bounds farming and what it leaves: SR2-36 in
 * docs/security-review-phase2.md.
 *
 * ## What earns, and what the node has to do with it
 *
 * Settled volume. The registry's rewards hook reports every order and sale that settles, on every escrow the registry
 * accepts, and NodeRewards counts it for INSTITUTIONAL and AFFILIATED LPs, at or above its minimum, while the LP is not
 * excluded. The node earns by settling, as it already does. What it adds is claiming: an epoch's rewards are claimable
 * once the epoch has ended, its review period has passed and someone has finalized it, and they are paid only to an LP
 * that claims. Nothing expires, so a node that was down for a month claims the month when it comes back.
 *
 * ## Each tick
 *
 *  1. Read NodeRewards: whether this LP's settlements count right now (the configured registry bound, the LP not
 *     excluded), its counted volume in the current epoch, how many epochs are waiting to be finalized, and what it can
 *     claim from finalized epochs in its look-back window.
 *  2. With `claim` on: finalize any epoch whose review has ended and nobody has finalized - anyone may, and the LP is
 *     the one waiting - then claim every finalized epoch with a share, once the total reaches `minClaim`.
 *  3. Publish `mova_lp_rewards_claimable` (centavos), the other `mova_lp_rewards_*` series, and `/status` `rewards`.
 *
 * ## Why claims need no journal
 *
 * A claim cannot pay twice. The contract marks each epoch claimed, and every write simulates before it sends, so an
 * epoch already claimed is refused (`AlreadyClaimed`) before any gas is spent. Writes resolve when mined and ticks never
 * overlap, so the next tick already reads a claim's effect; a claim a reorg removes is simply claimable again. Unlike a
 * mint (gateway.ts), nothing here moves the LP's own money.
 *
 * ## What it does not do
 *
 * It never claims for another LP, and it cannot contest a void or an exclusion: those are the governor's, and the node
 * reports only what it can read - volume that stops counting (`counting` false, with the reason) and the rewards it is
 * owed.
 */
import type { Address, Hex } from 'viem';
import { ChainRevert, sameAddress, type RewardsChain, type RewardsView } from './chain.js';
import { errorText, short, type NodeContext, type TickView } from './context.js';

const ZERO: Address = '0x0000000000000000000000000000000000000000';
/** NodeRewards.MAX_EPOCHS_PER_CALL: the most epochs one finalize or claim takes. */
export const REWARDS_MAX_EPOCHS_PER_CALL = 52;
/** NodeRewards.MAX_SCAN: the most epochs one `claimableIn` read scans. */
export const REWARDS_MAX_SCAN = 104;

export interface RewardsOptions {
  /** The NodeRewards contract. */
  contract: Address;
  /** The registry the node was configured with: settlements count only while NodeRewards is bound to it. */
  registry: Address;
  /** Finalize and claim. Off, the node only reports what it could claim. */
  claim: boolean;
  /** Claim only once at least this much is claimable, in reward-token base units. */
  minClaim: bigint;
  /** How many finalized epochs back to look for unclaimed shares; at most REWARDS_MAX_SCAN. */
  lookbackEpochs: number;
  /** Where rewards are paid; the LP's own account by default. */
  to?: Address;
}

/** Why this LP's settlements are not counting right now. */
export type RewardsBlock = 'unbound' | 'bound_elsewhere' | 'excluded';

export class RewardsManager {
  private view?: RewardsView;
  private readError?: string;
  private lastClaim?: { tx: Hex; paid: bigint; epochs: bigint[]; at: string };
  /** Last reason logged for not counting, so it is logged once when it starts and once when it clears. */
  private loggedBlocks = '';

  constructor(private readonly ctx: NodeContext, private readonly chain: RewardsChain, readonly o: RewardsOptions) {}

  /** After the other handlers: what they settled this tick is already counted. Throws only for a failed RPC. */
  async tick(_view: TickView): Promise<void> {
    const { metrics, log } = this.ctx;
    let v: RewardsView;
    try {
      v = await this.read();
    } catch (e) {
      this.readError = errorText(e);
      metrics.inc('mova_lp_tick_errors_total', { stage: 'rewards_read' });
      log.error(`rewards: reading ${short(this.o.contract)}: ${this.readError}`);
      return;
    }

    if (this.o.claim && v.finalizableEpochs > 0n) {
      const max = v.finalizableEpochs > BigInt(REWARDS_MAX_EPOCHS_PER_CALL) ? BigInt(REWARDS_MAX_EPOCHS_PER_CALL) : v.finalizableEpochs;
      try {
        const r = await this.chain.finalizeRewards(this.o.contract, max);
        metrics.inc('mova_lp_rewards_finalized_total', {}, Number(max));
        log.info(`rewards: finalized ${max} epoch(s) whose review had ended (${short(r.hash)})`);
        v = await this.read();
      } catch (e) {
        if (!(e instanceof ChainRevert)) throw e;
        // Someone else finalized first, most likely: the next read says so.
        log.warn(`rewards: finalize refused in simulation (${e.errorName}); nothing was sent`);
      }
    }

    if (this.o.claim && v.epochs.length > 0 && v.claimable > 0n && v.claimable >= this.o.minClaim) {
      const epochs = v.epochs.slice(0, REWARDS_MAX_EPOCHS_PER_CALL);
      try {
        const r = await this.chain.claimRewards(this.o.contract, epochs, this.o.to ?? this.chain.account);
        metrics.inc('mova_lp_rewards_claims_total', { outcome: 'mined' });
        metrics.inc('mova_lp_rewards_claimed_cents_total', {}, Number(r.paid / v.tokenPerCent));
        this.lastClaim = { tx: r.hash, paid: r.paid, epochs, at: new Date().toISOString() };
        log.info(`rewards: claimed ${r.paid} base units (${r.paid / v.tokenPerCent} centavos) for epoch(s) ${epochs.join(', ')} (${short(r.hash)})`);
        v = await this.read();
      } catch (e) {
        if (!(e instanceof ChainRevert)) throw e;
        metrics.inc('mova_lp_rewards_claims_total', { outcome: 'refused' });
        log.warn(`rewards: claim refused in simulation (${e.errorName}); nothing was sent`);
      }
    }
    this.publish(v);
  }

  private async read(): Promise<RewardsView> {
    const lookback = Math.min(Math.max(this.o.lookbackEpochs, 1), REWARDS_MAX_SCAN);
    const v = await this.chain.rewardsView(this.o.contract, lookback);
    this.view = v;
    this.readError = undefined;
    return v;
  }

  /** Every reason this LP's settlements would not count now; empty when they do (tier and minimum aside). */
  private blocks(v: RewardsView): RewardsBlock[] {
    const out: RewardsBlock[] = [];
    if (sameAddress(v.registry, ZERO)) out.push('unbound');
    else if (!sameAddress(v.registry, this.o.registry)) out.push('bound_elsewhere');
    if (v.excluded) out.push('excluded');
    return out;
  }

  private publish(v: RewardsView): void {
    const { metrics, log } = this.ctx;
    const blocks = this.blocks(v);
    metrics.set('mova_lp_rewards_claimable', Number(v.claimable / v.tokenPerCent));
    metrics.set('mova_lp_rewards_epoch_volume_cents', Number(v.currentVolumeCents));
    metrics.set('mova_lp_rewards_unclaimed_epochs', v.epochs.length);
    metrics.set('mova_lp_rewards_finalizable_epochs', Number(v.finalizableEpochs));
    metrics.set('mova_lp_rewards_counting', blocks.length === 0 ? 1 : 0);
    const key = blocks.join(',');
    if (key !== this.loggedBlocks) {
      if (key) {
        log.warn(`rewards: this LP's settlements do not count for rewards (${key}): `
          + (blocks.includes('unbound') ? 'NodeRewards has no registry bound yet; its governor binds one with admin rewards:registry. ' : '')
          + (blocks.includes('bound_elsewhere') ? `NodeRewards counts reports from ${v.registry}, not this node's registry ${this.o.registry}. ` : '')
          + (blocks.includes('excluded') ? 'the governor excluded this LP; what it already earned stays claimable.' : ''));
      } else if (this.loggedBlocks) {
        log.info('rewards: this LP\'s settlements count for rewards again');
      }
      this.loggedBlocks = key;
    }
  }

  /** On-chain facts and amounts only. Bigints serialize as strings at the boundary (server.ts). */
  status(): Record<string, unknown> {
    const v = this.view;
    return {
      contract: this.o.contract,
      claim: this.o.claim,
      minClaim: this.o.minClaim,
      counting: v ? this.blocks(v).length === 0 : null,
      notCounting: v ? this.blocks(v) : null,
      currentEpoch: v?.currentEpoch ?? null,
      currentEpochVolumeCents: v?.currentVolumeCents ?? null,
      nextToFinalize: v?.nextToFinalize ?? null,
      finalizableEpochs: v?.finalizableEpochs ?? null,
      claimable: v?.claimable ?? null,
      claimableCents: v ? v.claimable / v.tokenPerCent : null,
      unclaimedEpochs: v?.epochs ?? null,
      lastClaim: this.lastClaim ?? null,
      error: this.readError ?? null,
    };
  }
}
