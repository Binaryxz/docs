/**
 * Prices, as pure functions: what to ask for liquidity, and whether a sale is worth buying.
 *
 * ## Two prices, and why neither is trusted alone
 *
 * The escrows use their oracle as a SANITY BAND, never as the price (IPriceOracle). The LP has
 * its own reference - a desk rate, an exchange, a vendor feed - and that is what it wants to
 * quote around. Either can be wrong: the reference feed can freeze or glitch, and the oracle is
 * a quorum of publishers the LP did not choose. So every decision here looks at both, and the
 * rule is built so that a wrong REFERENCE cannot cost the LP more than a wrong oracle already
 * could:
 *
 *  - **Selling** (on-ramp offers). The ask is built on `max(reference, oracle)` and never goes
 *    below that plus `minSpreadBps`. A reference that reads low is ignored in favour of the
 *    oracle; one that reads high only makes the offer dearer, and the band caps how much.
 *  - **Buying** (off-ramp sales). A sale is valued at `min(reference, oracle)`, less
 *    `minMarginBps`. A reference that reads high is ignored; one that reads low only makes the
 *    node pickier.
 *  - **Disagreement.** When the two differ by more than `maxOracleDeviationBps`, one of them is
 *    wrong and the node cannot tell which, so it stops: offers are pulled and sales are skipped.
 *
 * What remains is both being wrong in the same direction at once. That is bounded by size, not
 * price: the liquidity configured per asset, and the LP's credit in the registry.
 *
 * ## The band, with a margin
 *
 * `FiatEscrow._requireWithinBand` re-checks the offer price at LOCK time, against the oracle as
 * it is then. An offer priced at the very edge of the band becomes unlockable on the next small
 * oracle move - liquidity that looks posted and cannot be taken. So the node quotes inside
 * `bandBps - bandMarginBps`, and reprices an offer that drifts to the edge.
 *
 * ## Staleness is judged on the escrow's clock
 *
 * The escrow refuses a price older than MAX_PRICE_AGE against `block.timestamp`, not wall time.
 * So oracle staleness here is measured against the chain head, with a margin: an offer whose
 * oracle is about to go stale is an offer that will refuse every lock in a few minutes.
 *
 * ## Movva: a price that is a definition, and a cost that is not
 *
 * Movva's reference is par (R$ 1,00, 100 centavos) and its oracle is the reserve, which reads 100
 * while fully backed. Both are right and neither says what a Movva COSTS a gateway: it buys USDT at
 * the market, pays the mint fee, and gets Movva at the reserve's rate - and a Movva it buys back is
 * worth what a redemption pays, less the redeem fee, at no more than the collateral ratio. So a Movva
 * offer also gets a cost floor and a Movva sale a value ceiling (`mintCostCentsE18`,
 * `redeemValueCentsE18`), and both are carried to 18 more decimals than a centavo: a centavo on
 * R$ 1,00 is 100 bps, coarser than any fee or spread being covered. Each is rounded against the LP.
 */
import { MAX_PRICE_AGE } from './abi.js';

export interface PricePoint {
  /** BRL centavos per whole unit (10**decimals base units). */
  price: bigint;
  /** Unix seconds. */
  updatedAt: bigint;
}

export interface OfferPricing {
  /** Where the node aims: this far above max(reference, oracle). */
  spreadBps: number;
  /** The least it will sell for: never below max(reference, oracle) plus this. */
  minSpreadBps: number;
  /** Reference and oracle disagreeing by more than this pulls the offer. */
  maxOracleDeviationBps: number;
  /** Stay this far inside the escrow's band. */
  bandMarginBps: number;
  /** Reprice once the posted price is this far from where the node would quote now. */
  refreshDriftBps: number;
  /** A reference older than this (by wall clock) is unusable. */
  maxReferenceAgeSeconds: number;
  /** Treat the oracle as stale this long before the escrow would. */
  oracleStaleMarginSeconds: number;
  /** An absolute floor, whatever the feeds say. */
  minPriceBrlCentsPerUnit?: bigint;
}

export interface SalePricing {
  /** Buy only at least this far below min(reference, oracle). */
  minMarginBps: number;
  maxOracleDeviationBps: number;
  maxReferenceAgeSeconds: number;
  oracleStaleMarginSeconds: number;
}

export type NoQuoteReason =
  | 'reference_unavailable'
  | 'reference_stale'
  | 'oracle_unavailable'
  | 'oracle_stale'
  | 'reference_deviates'
  | 'outside_band'
  | 'below_floor'
  /** A gateway asset whose cost (offer) or redemption value (sale) cannot be stated now. */
  | 'cost_unavailable'
  /** What the LP must ask to cover its cost is above what the band allows. */
  | 'cost_above_band';

export const NO_QUOTE_REASONS: readonly NoQuoteReason[] = [
  'reference_unavailable', 'reference_stale', 'oracle_unavailable', 'oracle_stale',
  'reference_deviates', 'outside_band', 'below_floor', 'cost_unavailable', 'cost_above_band',
];

/**
 * Centavos per whole unit, times 1e18: a Movva's cost to mint or value to redeem. `ok: false` is a
 * gateway that cannot say (a stale rate, a reference it cannot read), and it stops the quote.
 */
export type CostQuote = { ok: true; centsE18: bigint } | { ok: false };

export type Quote =
  | { ok: true; price: bigint; floor: bigint; ceiling: bigint; oracle: bigint; reference: bigint }
  | { ok: false; reason: NoQuoteReason };

const BPS = 10_000n;
const E18 = 10n ** 18n;
const ceilDiv = (a: bigint, b: bigint) => (a === 0n ? 0n : (a - 1n) / b + 1n);
const bps = (n: number) => BigInt(Math.trunc(n));

/** FiatEscrow._requireWithinBand, exactly. */
export function bandAccepts(price: bigint, mid: bigint, bandBps: bigint): boolean {
  if (mid === 0n) return false;
  const diff = price > mid ? price - mid : mid - price;
  return diff * BPS <= mid * bandBps;
}

/** |a - b| in basis points of b, rounded up. */
export function deviationBps(a: bigint, b: bigint): bigint {
  if (b === 0n) return BPS * BPS;
  return ceilDiv((a > b ? a - b : b - a) * BPS, b);
}

interface FeedCheck {
  reference: PricePoint | undefined;
  oracle: PricePoint | undefined;
  chainNow: bigint;
  wallNow: bigint;
  maxReferenceAgeSeconds: number;
  oracleStaleMarginSeconds: number;
  maxOracleDeviationBps: number;
}

function checkFeeds(f: FeedCheck): { ok: true; ref: bigint; mid: bigint } | { ok: false; reason: NoQuoteReason } {
  if (!f.oracle || f.oracle.price === 0n) return { ok: false, reason: 'oracle_unavailable' };
  if (f.chainNow + BigInt(f.oracleStaleMarginSeconds) > f.oracle.updatedAt + MAX_PRICE_AGE) {
    return { ok: false, reason: 'oracle_stale' };
  }
  if (!f.reference || f.reference.price === 0n) return { ok: false, reason: 'reference_unavailable' };
  if (f.wallNow > f.reference.updatedAt + BigInt(f.maxReferenceAgeSeconds)) {
    return { ok: false, reason: 'reference_stale' };
  }
  if (deviationBps(f.reference.price, f.oracle.price) > bps(f.maxOracleDeviationBps)) {
    return { ok: false, reason: 'reference_deviates' };
  }
  return { ok: true, ref: f.reference.price, mid: f.oracle.price };
}

/** What the node should ask, per whole unit, right now - or why it must not quote at all. */
export function quoteOffer(args: {
  reference: PricePoint | undefined;
  oracle: PricePoint | undefined;
  bandBps: bigint;
  chainNow: bigint;
  wallNow: bigint;
  cfg: OfferPricing;
  /** A gateway asset's cost to the LP: the floor and the aim are also built on it. */
  cost?: CostQuote;
}): Quote {
  const { cfg } = args;
  const feeds = checkFeeds({ ...args, ...cfg });
  if (!feeds.ok) return feeds;
  if (args.cost && !args.cost.ok) return { ok: false, reason: 'cost_unavailable' };
  const { ref, mid } = feeds;

  const base = ref > mid ? ref : mid;
  let floor = ceilDiv(base * (BPS + bps(cfg.minSpreadBps)), BPS);
  let desired = ceilDiv(base * (BPS + bps(cfg.spreadBps)), BPS);
  const room = args.bandBps > bps(cfg.bandMarginBps) ? args.bandBps - bps(cfg.bandMarginBps) : 0n;
  const ceiling = (mid * (BPS + room)) / BPS;
  if (floor > ceiling) return { ok: false, reason: 'outside_band' };

  if (args.cost?.ok) {
    // The spreads apply over the cost as over the prices: carried past the centavo, and rounded up to
    // one only at the end.
    const basis = args.cost.centsE18 > base * E18 ? args.cost.centsE18 : base * E18;
    const costFloor = ceilDiv(basis * (BPS + bps(cfg.minSpreadBps)), BPS * E18);
    const costAim = ceilDiv(basis * (BPS + bps(cfg.spreadBps)), BPS * E18);
    if (costFloor > floor) floor = costFloor;
    if (costAim > desired) desired = costAim;
    if (floor > ceiling) return { ok: false, reason: 'cost_above_band' };
  }
  const price = desired < ceiling ? desired : ceiling;
  if (cfg.minPriceBrlCentsPerUnit !== undefined && price < cfg.minPriceBrlCentsPerUnit) {
    return { ok: false, reason: 'below_floor' };
  }
  return { ok: true, price, floor, ceiling, oracle: mid, reference: ref };
}

export type RepriceReason = 'below_floor' | 'band_edge' | 'drift';

/** Why a posted price must be replaced, or undefined when it can stand. */
export function repriceReason(args: {
  posted: bigint;
  quote: Extract<Quote, { ok: true }>;
  bandBps: bigint;
  cfg: OfferPricing;
}): RepriceReason | undefined {
  const { posted, quote, cfg } = args;
  if (posted < quote.floor) return 'below_floor';
  const room = args.bandBps > bps(cfg.bandMarginBps) ? args.bandBps - bps(cfg.bandMarginBps) : 0n;
  if (!bandAccepts(posted, quote.oracle, room)) return 'band_edge';
  if (deviationBps(posted, quote.price) > bps(cfg.refreshDriftBps)) return 'drift';
  return undefined;
}

export type SaleVerdict =
  | { ok: true; impliedPrice: bigint; valuation: bigint }
  | { ok: false; reason: NoQuoteReason | 'price_too_high' };

/**
 * Is paying `brlCents` for `amount` base units a buy? The implied price is rounded UP, so the
 * rounding can only make the node more conservative.
 */
export function evaluateSale(args: {
  brlCents: bigint;
  amount: bigint;
  decimals: number;
  reference: PricePoint | undefined;
  oracle: PricePoint | undefined;
  chainNow: bigint;
  wallNow: bigint;
  cfg: SalePricing;
  /** A gateway asset's value to the LP once redeemed: a sale must also be a buy against it. */
  value?: CostQuote;
}): SaleVerdict {
  const feeds = checkFeeds({ ...args, ...args.cfg });
  if (!feeds.ok) return feeds;
  if (args.value && !args.value.ok) return { ok: false, reason: 'cost_unavailable' };
  if (args.amount === 0n) return { ok: false, reason: 'price_too_high' };
  const valuation = feeds.ref < feeds.mid ? feeds.ref : feeds.mid;
  const margin = BPS - bps(args.cfg.minMarginBps);
  const impliedPrice = ceilDiv(args.brlCents * 10n ** BigInt(args.decimals), args.amount);
  if (impliedPrice * BPS > valuation * margin) {
    return { ok: false, reason: 'price_too_high' };
  }
  // Exactly, without the centavo rounding: brlCents / amount <= value x (1 - margin), cross-multiplied.
  if (args.value?.ok
    && args.brlCents * 10n ** BigInt(args.decimals) * BPS * E18 > args.amount * args.value.centsE18 * margin) {
    return { ok: false, reason: 'price_too_high' };
  }
  return { ok: true, impliedPrice, valuation };
}

/**
 * What one whole Movva minted from USDT costs the LP, in centavos x 1e18: the reais it pays per USDT
 * (`payRateE18`), over the Movva one USDT mints at the reserve's rate after the mint fee. Rounded up.
 *
 *     cost = payRate / (rate x (1 - fee))       R$ 5,45 / (R$ 5,40 x 0.9995) = R$ 1,00976...
 */
export function mintCostCentsE18(a: { rateE18: bigint; payRateE18: bigint; mintFeeBps: number }): bigint {
  const net = BPS - bps(a.mintFeeBps);
  if (a.rateE18 <= 0n || net <= 0n) throw new Error('mintCostCentsE18: a rate above zero and a fee below 100%');
  return ceilDiv(a.payRateE18 * 100n * BPS * E18, a.rateE18 * net);
}

/**
 * What one whole Movva bought back is worth to the LP redeemed, in centavos x 1e18: min(1, ratio) of
 * par, less the redeem fee, paid in USDT at the reserve's rate and sold for reais at `sellRateE18`.
 * Rounded down.
 *
 *     value = min(1, ratio) x (1 - fee) x sellRate / rate
 */
export function redeemValueCentsE18(a: {
  rateE18: bigint; sellRateE18: bigint; redeemFeeBps: number; collateralRatioBps: bigint;
}): bigint {
  const net = BPS - bps(a.redeemFeeBps);
  if (a.rateE18 <= 0n || net <= 0n) throw new Error('redeemValueCentsE18: a rate above zero and a fee below 100%');
  const ratio = a.collateralRatioBps < BPS ? a.collateralRatioBps : BPS;
  return (100n * E18 * ratio * net * a.sellRateE18) / (BPS * BPS * a.rateE18);
}

/**
 * The largest amount whose exposure fits `creditCents` at `price`: the escrow reserves
 * ceil(amount * price / 10**decimals), and floor(credit * 10**decimals / price) never exceeds it.
 */
export function amountForCredit(creditCents: bigint, price: bigint, decimals: number): bigint {
  if (price === 0n) return 0n;
  return (creditCents * 10n ** BigInt(decimals)) / price;
}
