/**
 * A PSP's dynamic QR code site, in memory: for tests and the live examples, never production.
 *
 * What the Pix Security Manual (Manual de Segurança do SFN, Volume II, version 6.00, 8 June 2026, §4-5; read
 * 2026-09-14) asks of the site a receiver's PSP serves locations from, with everything generated at start-up:
 *
 *  - `MockPixCa`: a root and an intermediate CA (EC P-256), and a revocation list it answers for;
 *  - a site certificate for the host: EV (CA/Browser Forum policy 2.23.140.1.1), Server Authentication, the host in
 *    the SAN, no wildcard;
 *  - a JWS signing certificate (Digital Signature) and its key: RSA 2048 for PS256 (the manual's recommendation) or
 *    EC P-256 for ES256;
 *  - locations `{host}/qr/v2/{128 random bits}` (§4.1: at least 120) answering `application/jose`: the payload the
 *    location's owner supplies, signed, with a JOSE header of `alg`, `typ`, `kid`, `jku` and `x5t` (§4.2);
 *  - the JWK Set at `https://{host}/.well-known/pix-jwks.json` - the `/.well-known/` directory §4.3 recommends - with
 *    `kty`, `n`/`e` or `crv`/`x`/`y`, `key_ops: ["verify"]`, `kid`, `x5t` and `x5c` up to the root.
 *
 * `fetch` answers in-process, reporting the TLS chain a real server would present; `listen` serves the same over real
 * HTTPS (TLS 1.2 or later) on 127.0.0.1, for a wallet using `httpsPixLocationFetch`. Two switches make it lie the way
 * the wallet's tests need: `corruptSignatures`, and `signer` (sign with another site's key, jku and all).
 *
 * The X.509 certificates are DER built here: node:crypto parses and verifies certificates but does not issue them.
 */
import {
  X509Certificate, constants as cryptoConstants, createHash, generateKeyPairSync, randomBytes, sign as cryptoSign,
  type KeyObject,
} from 'node:crypto';
import { createServer as createHttpsServer } from 'node:https';
import type { CertificateStatus, PixLocationFetch, PixLocationResponse } from '@mova/wallet';

/*//////////////////////////////////////////////////////////////
                                 DER
//////////////////////////////////////////////////////////////*/

const len = (n: number): Buffer => {
  if (n < 0x80) return Buffer.from([n]);
  const b: number[] = [];
  for (let x = n; x > 0; x >>= 8) b.unshift(x & 0xff);
  return Buffer.from([0x80 | b.length, ...b]);
};
const tlv = (tag: number, ...parts: Buffer[]): Buffer => {
  const v = Buffer.concat(parts);
  return Buffer.concat([Buffer.from([tag]), len(v.length), v]);
};
const seq = (...p: Buffer[]) => tlv(0x30, ...p);
const set = (...p: Buffer[]) => tlv(0x31, ...p);
const bool = (v: boolean) => tlv(0x01, Buffer.from([v ? 0xff : 0x00]));
const octets = (b: Buffer) => tlv(0x04, b);
const integer = (b: Buffer) => tlv(0x02, b[0] & 0x80 ? Buffer.concat([Buffer.from([0]), b]) : b);
const oid = (s: string): Buffer => {
  const p = s.split('.').map(Number);
  const out = [40 * p[0] + p[1]];
  for (const n of p.slice(2)) {
    const stack = [n & 0x7f];
    for (let x = n >> 7; x > 0; x >>= 7) stack.unshift((x & 0x7f) | 0x80);
    out.push(...stack);
  }
  return tlv(0x06, Buffer.from(out));
};
const utf8 = (s: string) => tlv(0x0c, Buffer.from(s, 'utf8'));
const time = (d: Date): Buffer => {
  const s = `${d.toISOString().replace(/[-:T]/g, '').slice(0, 14)}Z`;
  return d.getUTCFullYear() >= 2050 ? tlv(0x18, Buffer.from(s)) : tlv(0x17, Buffer.from(s.slice(2)));
};
const name = (cn: string, org: string) => seq(set(seq(oid('2.5.4.10'), utf8(org))), set(seq(oid('2.5.4.3'), utf8(cn))));
const extension = (id: string, critical: boolean, value: Buffer) => seq(oid(id), ...(critical ? [bool(true)] : []), octets(value));

/** KeyUsage bits as a big-endian 16-bit number (digitalSignature 0x8000, keyCertSign 0x0400, cRLSign 0x0200). */
const keyUsageBits = (bits: number): Buffer => {
  let bytes = [bits >> 8, bits & 0xff];
  while (bytes.length > 1 && bytes[bytes.length - 1] === 0) bytes = bytes.slice(0, -1);
  const last = bytes[bytes.length - 1];
  let unused = 0;
  while (unused < 7 && last !== 0 && ((last >> unused) & 1) === 0) unused++;
  return tlv(0x03, Buffer.from([unused, ...bytes]));
};

export const KU = { digitalSignature: 0x8000, keyEncipherment: 0x2000, keyCertSign: 0x0400, cRLSign: 0x0200 } as const;

function issue(o: {
  subject: string; issuer: string; publicKey: KeyObject; issuerKey: KeyObject; ca: boolean; keyUsage: number;
  eku?: string[]; dns?: string[]; policies?: string[]; notBefore?: Date; notAfter?: Date;
}): X509Certificate {
  const ec = o.issuerKey.asymmetricKeyType === 'ec';
  const sigAlg = ec ? seq(oid('1.2.840.10045.4.3.2')) : seq(oid('1.2.840.113549.1.1.11'), Buffer.from([0x05, 0x00]));
  const serial = randomBytes(12);
  serial[0] = (serial[0] & 0x7f) | 0x01;
  const exts = [
    extension('2.5.29.19', true, o.ca ? seq(bool(true)) : seq()),
    extension('2.5.29.15', true, keyUsageBits(o.keyUsage)),
    ...(o.eku ? [extension('2.5.29.37', false, seq(...o.eku.map(oid)))] : []),
    ...(o.dns ? [extension('2.5.29.17', false, seq(...o.dns.map((d) => tlv(0x82, Buffer.from(d, 'ascii')))))] : []),
    ...(o.policies ? [extension('2.5.29.32', false, seq(...o.policies.map((p) => seq(oid(p)))))] : []),
  ];
  const tbs = seq(
    tlv(0xa0, integer(Buffer.from([2]))),
    integer(serial),
    sigAlg,
    name(o.issuer, 'Mova Test PSP'),
    seq(time(o.notBefore ?? new Date('2020-01-01T00:00:00Z')), time(o.notAfter ?? new Date('2099-12-31T23:59:59Z'))),
    name(o.subject, 'Mova Test PSP'),
    o.publicKey.export({ type: 'spki', format: 'der' }),
    tlv(0xa3, seq(...exts)),
  );
  const signature = cryptoSign('sha256', tbs, o.issuerKey);
  return new X509Certificate(seq(tbs, sigAlg, tlv(0x03, Buffer.from([0]), signature)));
}

/*//////////////////////////////////////////////////////////////
                                 THE CA
//////////////////////////////////////////////////////////////*/

export class MockPixCa {
  readonly root: X509Certificate;
  readonly intermediate: X509Certificate;
  private readonly intermediateKey: KeyObject;
  /** SHA-256 fingerprints (Node's colon form) of certificates this CA revoked. */
  readonly revoked = new Set<string>();

  constructor(readonly label = 'Mova Test') {
    const root = generateKeyPairSync('ec', { namedCurve: 'P-256' });
    const inter = generateKeyPairSync('ec', { namedCurve: 'P-256' });
    this.root = issue({
      subject: `${label} Root CA`, issuer: `${label} Root CA`, publicKey: root.publicKey, issuerKey: root.privateKey,
      ca: true, keyUsage: KU.keyCertSign | KU.cRLSign,
    });
    this.intermediate = issue({
      subject: `${label} Issuing CA`, issuer: `${label} Root CA`, publicKey: inter.publicKey, issuerKey: root.privateKey,
      ca: true, keyUsage: KU.keyCertSign | KU.cRLSign,
    });
    this.intermediateKey = inter.privateKey;
  }

  get rootPem(): string { return this.root.toString(); }

  /** A leaf under the intermediate. */
  issueLeaf(o: { subject: string; publicKey: KeyObject; keyUsage: number; eku?: string[]; dns?: string[]; policies?: string[]; notAfter?: Date }): X509Certificate {
    return issue({ ...o, issuer: `${this.label} Issuing CA`, issuerKey: this.intermediateKey, ca: false });
  }

  revoke(cert: X509Certificate): void { this.revoked.add(cert.fingerprint256); }

  /** A revocation source that knows exactly what this CA revoked, and nothing about anyone else's certificates. */
  readonly certificateStatus = async (cert: X509Certificate, issuer: X509Certificate): Promise<CertificateStatus> => {
    if (![this.root, this.intermediate].some((c) => c.fingerprint256 === issuer.fingerprint256)) return 'unknown';
    return this.revoked.has(cert.fingerprint256) ? 'revoked' : 'good';
  };
}

/*//////////////////////////////////////////////////////////////
                                THE SITE
//////////////////////////////////////////////////////////////*/

/** What a location answers now: the charge's payload (the site signs it), or gone. */
export type CobLocationAnswer = { status: 200; payload: Record<string, unknown> } | { status: 404 | 410 };

const JWKS_PATH = '/.well-known/pix-jwks.json';
const EV_POLICY = '2.23.140.1.1';
const SERVER_AUTH = '1.3.6.1.5.5.7.3.1';

export class MockPixQrSite {
  readonly host: string;
  readonly ca: MockPixCa;
  readonly alg: 'PS256' | 'ES256';
  readonly siteCertificate: X509Certificate;
  readonly signingCertificate: X509Certificate;
  readonly kid: string;
  private readonly siteKey: KeyObject;
  private readonly signingKey: KeyObject;
  private readonly locations = new Map<string, () => CobLocationAnswer>();
  /** Sign with this other site's key, kid, x5t and jku: a charge whose key lives on another domain. */
  signer?: MockPixQrSite;
  /** Flip a bit in every signature. */
  corruptSignatures = false;
  /** Requests answered, by path kind. */
  readonly served = { locations: 0, jwks: 0 };

  constructor(o: { host: string; ca?: MockPixCa; alg?: 'PS256' | 'ES256' }) {
    this.host = o.host.toLowerCase();
    this.ca = o.ca ?? new MockPixCa();
    this.alg = o.alg ?? 'PS256';
    const site = generateKeyPairSync('ec', { namedCurve: 'P-256' });
    this.siteKey = site.privateKey;
    this.siteCertificate = this.ca.issueLeaf({
      subject: this.host, publicKey: site.publicKey, keyUsage: KU.digitalSignature, eku: [SERVER_AUTH], dns: [this.host], policies: [EV_POLICY],
    });
    const signing = this.alg === 'PS256'
      ? generateKeyPairSync('rsa', { modulusLength: 2048 })
      : generateKeyPairSync('ec', { namedCurve: 'P-256' });
    this.signingKey = signing.privateKey;
    this.signingCertificate = this.ca.issueLeaf({ subject: `${this.host} QR code signing`, publicKey: signing.publicKey, keyUsage: KU.digitalSignature });
    this.kid = `qr-${createHash('sha256').update(this.signingCertificate.raw).digest('hex').slice(0, 16)}`;
  }

  get jku(): string { return `https://${this.host}${JWKS_PATH}`; }
  get x5t(): string { return createHash('sha1').update(this.signingCertificate.raw).digest('base64url'); }

  /** A new location for a charge: `{host}/qr/v2/{token}`, answered by `answer` from now on. */
  newLocation(answer: () => CobLocationAnswer): string {
    const token = randomBytes(16).toString('hex');
    const location = `${this.host}/qr/v2/${token}`;
    if (location.length > 77) throw new Error('the host is too long for a 77-character location');
    this.locations.set(token, answer);
    return location;
  }

  /** A compact JWS over `payload`, as this site (or its `signer`) signs charges. */
  sign(payload: Record<string, unknown>): string {
    const s = this.signer ?? this;
    const header = { alg: s.alg, typ: 'JWS', kid: s.kid, jku: s.jku, x5t: s.x5t };
    const input = `${Buffer.from(JSON.stringify(header)).toString('base64url')}.${Buffer.from(JSON.stringify(payload)).toString('base64url')}`;
    const sig = s.alg === 'PS256'
      ? cryptoSign('sha256', Buffer.from(input), { key: s.signingKey, padding: cryptoConstants.RSA_PKCS1_PSS_PADDING, saltLength: cryptoConstants.RSA_PSS_SALTLEN_DIGEST })
      : cryptoSign('sha256', Buffer.from(input), { key: s.signingKey, dsaEncoding: 'ieee-p1363' });
    if (this.corruptSignatures) sig[sig.length - 1] ^= 0x01;
    return `${input}.${sig.toString('base64url')}`;
  }

  jwks(): { keys: Record<string, unknown>[] } {
    const jwk = this.signingCertificate.publicKey.export({ format: 'jwk' }) as Record<string, unknown>;
    return {
      keys: [{
        ...jwk, kid: this.kid, key_ops: ['verify'], x5t: this.x5t,
        x5c: [this.signingCertificate, this.ca.intermediate, this.ca.root].map((c) => c.raw.toString('base64')),
      }],
    };
  }

  /** What an https GET of `url` gets from this site, TLS chain included. */
  answer(url: URL): PixLocationResponse {
    const tls = { protocol: 'TLSv1.3', certificates: [this.siteCertificate.raw, this.ca.intermediate.raw] };
    const problem = (status: number, title: string): PixLocationResponse => ({
      status, contentType: 'application/problem+json', body: JSON.stringify({ title, status }), tls,
    });
    if (url.protocol !== 'https:' || url.hostname !== this.host) return problem(421, 'Misdirected Request');
    if (url.pathname === JWKS_PATH) {
      this.served.jwks++;
      return { status: 200, contentType: 'application/jwk-set+json', body: JSON.stringify(this.jwks()), tls };
    }
    const token = /^\/qr\/v2\/([0-9a-f]{32})$/.exec(url.pathname)?.[1];
    const location = token ? this.locations.get(token) : undefined;
    if (!location) return problem(404, 'Não encontrado');
    this.served.locations++;
    const a = location();
    if (a.status !== 200) return problem(a.status, a.status === 410 ? 'Cobrança removida' : 'Não encontrado');
    return { status: 200, contentType: 'application/jose', body: this.sign(a.payload), tls };
  }

  /** In-process https GET, for `PixLocationTrust.fetch`. */
  readonly fetch: PixLocationFetch = async (url) => this.answer(url);

  /** The same over real HTTPS on 127.0.0.1, with the site certificate. */
  async listen(port = 0): Promise<{ port: number; close: () => Promise<void> }> {
    const server = createHttpsServer({
      key: this.siteKey.export({ type: 'pkcs8', format: 'pem' }),
      cert: `${this.siteCertificate.toString()}${this.ca.intermediate.toString()}`,
      minVersion: 'TLSv1.2',
    }, (rq, rs) => {
      const a = this.answer(new URL(rq.url ?? '/', `https://${this.host}`));
      rs.writeHead(a.status, { 'content-type': a.contentType ?? 'application/json' });
      rs.end(a.body);
    });
    await new Promise<void>((resolve) => server.listen(port, '127.0.0.1', () => resolve()));
    const address = server.address();
    return {
      port: typeof address === 'object' && address ? address.port : port,
      close: () => new Promise<void>((resolve) => {
        server.close(() => resolve());
        server.closeAllConnections();
      }),
    };
  }
}

/** One in-process fetch for several sites, by host; any other host does not resolve. */
export function routePixLocations(sites: readonly MockPixQrSite[]): PixLocationFetch {
  return async (url) => {
    const site = sites.find((s) => s.host === url.hostname);
    if (!site) throw Object.assign(new Error(`getaddrinfo ENOTFOUND ${url.hostname}`), { code: 'ENOTFOUND' });
    return site.answer(url);
  };
}
