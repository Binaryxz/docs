/**
 * What the LP node needs from the chain, as an interface.
 *
 * ## Why an interface, when viem is already one
 *
 * The node's safety properties are about ORDERING - never pay before a claim has N
 * confirmations, never refund before a cancellation has N confirmations, re-read state after a
 * reorg instead of trusting an event - and ordering is exactly what is hard to test against a
 * live node. Everything the handlers do goes through this surface, so the unit tests drive them
 * with an in-memory chain that can hold a transaction at zero confirmations, or reorg it away,
 * on demand (`test/fake-chain.ts`), and `ViemRampChain` is the one implementation that talks
 * to real contracts.
 *
 * ## Reads "at" a block
 *
 * Every getter takes an optional block number. The handlers use it for CONFIRMED reads: the
 * state as of `head - confirmations + 1`. That is how "the claim is on-chain with N
 * confirmations" is checked without tracking transaction receipts: if the sale reads as claimed
 * by this LP at a block N deep, a reorg shallower than N cannot undo it. Full nodes keep recent
 * state (geth: 128 blocks), which bounds `confirmations` in practice.
 *
 * ## Writes resolve when mined
 *
 * Each write simulates first - a revert surfaces as a `ChainRevert` carrying the contract's
 * error name before any gas is spent - then sends and waits for the receipt. Mined is not
 * confirmed: a handler that needs confirmation reads state at a confirmed block afterwards.
 */
import type { Address, Hex } from 'viem';
import type { OrderState, SaleState } from './abi.js';

export type Leg = 'onramp' | 'offramp';

export interface BlockRef {
  number: bigint;
  hash: Hex;
  timestamp: bigint;
}

export interface OnChainOffer {
  lp: Address;
  asset: Address;
  availableWei: bigint;
  lockedWei: bigint;
  priceBrlCentsPerEth: bigint;
  pixKeyHash: Hex;
  minOrderWei: bigint;
  maxOrderWei: bigint;
  verifier: Address;
  railMask: number;
  active: boolean;
  decimals: number;
}

export interface OnChainOrder {
  offerId: Hex;
  taker: Address;
  weiAmount: bigint;
  brlCents: bigint;
  lockedAt: bigint;
  payBy: bigint;
  state: OrderState;
  delivery: number;
  recipient: Address;
}

/**
 * When an order or sale was disputed, and the deadline after which only `expireDispute` applies. A valid proof of a
 * payment made inside the window still settles a DISPUTED order or sale before `deadline` (SRM1-3); the receipt's age
 * is taken at `disputedAt`. Zeros for one never disputed.
 */
export interface OnChainDispute {
  disputedAt: bigint;
  deadline: bigint;
}

export interface OnChainBoleto {
  /** Non-zero marks a boleto order. */
  issueBy: bigint;
  issuedAt: bigint;
  commitment: Hex;
}

export interface OnChainSale {
  seller: Address;
  asset: Address;
  weiAmount: bigint;
  brlCents: bigint;
  payeeKeyHash: Hex;
  verifier: Address;
  railMask: number;
  lp: Address;
  claimedAt: bigint;
  payBy: bigint;
  refundTo: Address;
  state: SaleState;
}

export interface AssetConfig {
  oracle: Address;
  decimals: number;
  enabled: boolean;
}

export interface OraclePrice {
  /** BRL centavos per one whole unit of the asset (10**decimals base units). */
  price: bigint;
  updatedAt: bigint;
}

export interface Credit {
  /**
   * LPRegistry.capOf: zero for NONE, SUSPENDED, or a tier whose phase is closed. On a PermissionlessLPRegistry: the
   * bond in centavos, zero while the LP is leaving, before the escrows are bound, or with no bond.
   */
  capCents: bigint;
  /** LPRegistry.availableCents: what a new reservation may take right now. */
  availableCents: bigint;
  /** LPRegistry.setupComplete; on a PermissionlessLPRegistry, `escrowsBound` (its one-shot setup). */
  setupComplete: boolean;
  /** Which registry answered. Absent from chains that only know the curated one (the in-memory test chain). */
  registry?: 'curated' | 'permissionless';
  /** PermissionlessLPRegistry: the bond, and when it becomes withdrawable while the LP is leaving (0 otherwise). */
  bond?: { amountWei: bigint; withdrawableFrom: bigint };
}

/**
 * The events the node folds in. Only the ones that introduce an id it must start tracking are
 * decoded in full; everything else that changes an order or sale arrives as `touched`, so the
 * handler re-reads storage rather than reconstructing state from logs (see indexer.ts in
 * @mova/ramp for why storage is the authority).
 */
export type RampEvent =
  | { kind: 'OfferPosted'; block: bigint; offerId: Hex; lp: Address }
  | { kind: 'OrderLocked'; block: bigint; orderId: Hex; offerId: Hex; taker: Address; brlCents: bigint }
  | { kind: 'BoletoRequested'; block: bigint; orderId: Hex; issueBy: bigint }
  | { kind: 'SaleOpened'; block: bigint; saleId: Hex }
  | { kind: 'SaleUnclaimed'; block: bigint; saleId: Hex; lp: Address }
  | { kind: 'touched'; block: bigint; leg: Leg; id: Hex };

export interface TxResult {
  hash: Hex;
  blockNumber: bigint;
}

/** A simulated or mined revert, with the contract's error name when it could be decoded. */
export class ChainRevert extends Error {
  constructor(readonly errorName: string, message?: string) {
    super(message ?? `reverted: ${errorName}`);
  }
}

export interface PostOfferArgs {
  asset: Address;
  amount: bigint;
  priceBrlCentsPerUnit: bigint;
  pixKeyHash: Hex;
  minOrder: bigint;
  maxOrder: bigint;
  verifier: Address;
  railMask: number;
}

export interface RampChain {
  readonly chainId: number;
  /** The LP: the address every write is sent from. */
  readonly account: Address;
  readonly onramp?: Address;
  readonly offramp?: Address;

  head(): Promise<BlockRef>;
  block(number: bigint): Promise<BlockRef | undefined>;
  /** Decoded events from both escrows in [from, to], in chain order. */
  events(from: bigint, to: bigint): Promise<RampEvent[]>;

  offer(id: Hex, at?: bigint): Promise<OnChainOffer>;
  order(id: Hex, at?: bigint): Promise<OnChainOrder>;
  boleto(id: Hex, at?: bigint): Promise<OnChainBoleto>;
  sale(id: Hex, at?: bigint): Promise<OnChainSale>;
  /** `disputedAt(id)` and the dispute's deadline on that leg's escrow: `disputeDeadline(id)` on an on-ramp that has it
   *  (a taker's dispute runs on TAKER_DISPUTE_TIMEOUT, H-04), otherwise `disputedAt + DISPUTE_TIMEOUT`. */
  dispute(leg: Leg, id: Hex): Promise<OnChainDispute>;
  asset(leg: Leg, asset: Address): Promise<AssetConfig>;
  /** Reverts (throws) when the oracle has no price, as IPriceOracle requires. */
  oraclePrice(oracle: Address): Promise<OraclePrice>;
  bandBps(leg: Leg): Promise<bigint>;
  verifierAllowed(leg: Leg, verifier: Address): Promise<boolean>;
  credit(): Promise<Credit>;
  /** The LP's own wallet balance of an asset (the zero address for ETH). */
  balance(asset: Address): Promise<bigint>;

  postOffer(a: PostOfferArgs): Promise<TxResult & { offerId: Hex }>;
  fundOffer(offerId: Hex, asset: Address, amount: bigint): Promise<TxResult>;
  closeOffer(offerId: Hex): Promise<TxResult>;
  issueBoleto(orderId: Hex, commitment: Hex): Promise<TxResult>;
  releaseWithProof(orderId: Hex, proof: Hex): Promise<TxResult>;
  reclaimExpired(orderId: Hex): Promise<TxResult>;
  claimSale(saleId: Hex): Promise<TxResult>;
  abandonClaim(saleId: Hex): Promise<TxResult>;
  settleWithProof(saleId: Hex, proof: Hex): Promise<TxResult>;
  raiseDispute(leg: Leg, id: Hex, reason: string): Promise<TxResult>;
}

/*//////////////////////////////////////////////////////////////
                    THE MOVVA RESERVE, FOR A GATEWAY LP
//////////////////////////////////////////////////////////////*/

export interface GatewayAddresses {
  reserve: Address;
  usdt: Address;
  movva: Address;
}

/**
 * Everything `MovvaReserve.mint` and `redeem` check, read together at one block. A read that fails
 * for any reason other than the rate reverting fails the whole view: the gateway then reports
 * `reserve_unreadable` rather than assuming any field is fine.
 */
export interface ReserveView {
  isGateway: boolean;
  setupComplete: boolean;
  mintPaused: boolean;
  /** Tether has frozen the reserve: `mint` refuses, and its idle USDT counts for nothing. */
  reserveFrozen: boolean;
  /** Tether has frozen the LP: its USDT cannot be pulled, and the reserve pays no frozen address. */
  lpFrozen: boolean;
  /** Movva totalSupply, 18 decimals. */
  supply: bigint;
  supplyCap: bigint;
  mintFeeBps: number;
  redeemFeeBps: number;
  minMintCollateralRatioBps: number;
  /** `totalUsdt()`, 6 decimals. */
  totalUsdt: bigint;
  /** USDT a redemption could be paid now: idle (none while frozen) plus the vault's `maxWithdraw`. */
  liquidUsdt: bigint;
  /** `brlPerUsdtE18()`, or the name of the error it reverted with (`StaleLeg`, `StaleRate`, `FxOutOfRange`, ...). */
  rate: { e18: bigint; updatedAt: bigint } | { error: string };
  /** `collateralRatioBps()`; absent exactly when the rate reverted. */
  collateralRatioBps?: bigint;
  /**
   * `bandBrlPerUsdtE18()`: the rate as the escrows' band reads it - while the FX market is closed, its last close,
   * stamped with the block's time - and the collateral ratio at that rate, or the error it reverted with. A band that
   * reads while the rate does not is the FX market closed: minting and redeeming wait, Movva is priced from this.
   * Absent where the reader does not know it.
   */
  band?: { e18: bigint; updatedAt: bigint; collateralRatioBps: bigint } | { error: string };
}

/** MovvaReserve._ratio: the reserve at `rateE18` over the supply, in basis points, rounded down; unbounded with no supply. */
export function reserveRatioBps(totalUsdt: bigint, rateE18: bigint, supply: bigint): bigint {
  if (supply === 0n) return 2n ** 256n - 1n;
  return (((totalUsdt * rateE18) / 1_000_000n) * 10_000n) / supply;
}

/** The FX market is closed, as the reserve shows it: its band reads a closing price while its rate is refused. */
export function marketClosed(v: ReserveView | undefined): boolean {
  return !!v && 'error' in v.rate && !!v.band && !('error' in v.band);
}

/** What became of a transaction this node broadcast. */
export type TxOutcome =
  /** `amountOut`: Movva minted or USDT paid, from the reserve's own event in THIS transaction. */
  | {
    state: 'mined'; ok: boolean; blockNumber: bigint; amountOut?: bigint;
    /** Why it reverted, when `ok` is false: out of gas, the reserve's error replayed, or unknown (tx-sender.ts). */
    why?: string;
  }
  | { state: 'pending' }
  /** The node knows no transaction by this hash: never broadcast, dropped, or replaced. */
  | { state: 'unknown' };

/**
 * The reserve calls a gateway makes. Unlike `RampChain`'s writes, `sendMint` and `sendRedeem` take
 * an explicit nonce and return at broadcast: the gateway journals the hash before it waits, and
 * reasons about a crashed send from the nonce (gateway.ts, "At most one transaction per intent").
 */
export interface GatewayChain {
  readonly account: Address;
  balance(asset: Address): Promise<bigint>;
  reserveView(g: GatewayAddresses, at?: bigint): Promise<ReserveView>;
  /** Throws `ChainRevert` while the rate is stale, as the reserve's views do. */
  previewMint(reserve: Address, usdtIn: bigint): Promise<{ movvaOut: bigint; fee: bigint }>;
  previewRedeem(reserve: Address, movvaIn: bigint): Promise<{ usdtOut: bigint; fee: bigint }>;
  allowance(token: Address, spender: Address): Promise<bigint>;
  /** Simulate, send and wait for one `approve`, with an ABI that expects no return value (USDT). */
  approve(token: Address, spender: Address, amount: bigint): Promise<TxResult>;
  /** The LP's nonce as of `confirmedBlock`, and counting what its node holds pending. */
  nonces(confirmedBlock: bigint): Promise<{ confirmed: number; pending: number }>;
  /** Simulate only; a refusal throws `ChainRevert` with the reserve's error name. */
  simulateMint(reserve: Address, usdtIn: bigint, minMovvaOut: bigint): Promise<void>;
  simulateRedeem(reserve: Address, movvaIn: bigint, minUsdtOut: bigint): Promise<void>;
  /** Broadcast with exactly this nonce; resolves with the hash once the node has it, not once mined. */
  sendMint(reserve: Address, usdtIn: bigint, minMovvaOut: bigint, nonce: number): Promise<Hex>;
  sendRedeem(reserve: Address, movvaIn: bigint, minUsdtOut: bigint, nonce: number): Promise<Hex>;
  /** With `wait`, block until mined or the implementation's timeout, then report `pending`. */
  outcome(hash: Hex, reserve: Address, wait: boolean): Promise<TxOutcome>;
  /** Blocks a gateway transaction may sit unmined before the gateway replaces it; 0 never. */
  readonly replaceAfterBlocks: number;
  /**
   * Re-send `hash` at its nonce with bumped fees, capped by the configured maximum (tx-sender.ts). `gone`:
   * the node no longer holds it pending; `capped`: the cap leaves no valid bump.
   */
  replace(hash: Hex): Promise<{ hash: Hex } | { capped: true } | { gone: true }>;
  /** The nonces of open gateway intents: the chain's own writes neither adopt nor cancel them. */
  reserveNonces(nonces: number[]): void;
}

export function isGatewayChain(c: unknown): c is GatewayChain {
  const x = c as Partial<Record<keyof GatewayChain, unknown>>;
  return typeof x.reserveView === 'function' && typeof x.sendMint === 'function' && typeof x.sendRedeem === 'function'
    && typeof x.outcome === 'function' && typeof x.nonces === 'function' && typeof x.approve === 'function'
    && typeof x.replace === 'function' && typeof x.reserveNonces === 'function';
}

/*//////////////////////////////////////////////////////////////
                  NODE-PROVIDER REWARDS (NodeRewards)
//////////////////////////////////////////////////////////////*/

/** NodeRewards as this LP sees it, read at one block (contracts/ramp/NodeRewards.sol). */
export interface RewardsView {
  /** The registry whose settlement reports count; the zero address while none is bound. */
  registry: Address;
  /** The governor excluded this LP: its new settlements do not count. */
  excluded: boolean;
  currentEpoch: bigint;
  nextToFinalize: bigint;
  /** Epochs whose review has ended and that nobody has finalized yet. */
  finalizableEpochs: bigint;
  /** Reward-token base units worth one BRL centavo. */
  tokenPerCent: bigint;
  /** This LP's counted volume in the current epoch, centavos. */
  currentVolumeCents: bigint;
  /** What claiming `epochs` would pay now, in reward-token base units. */
  claimable: bigint;
  /** Finalized, unclaimed epochs with a share for this LP, within the look-back window, oldest first. */
  epochs: bigint[];
}

/** The NodeRewards calls an LP makes. Writes simulate first and resolve when mined, as RampChain's do. */
export interface RewardsChain {
  readonly account: Address;
  rewardsView(rewards: Address, lookbackEpochs: number): Promise<RewardsView>;
  finalizeRewards(rewards: Address, maxEpochs: bigint): Promise<TxResult>;
  /** `paid`: the sum of this LP's `Claimed` events in the transaction. */
  claimRewards(rewards: Address, epochs: readonly bigint[], to: Address): Promise<TxResult & { paid: bigint }>;
}

export function isRewardsChain(c: unknown): c is RewardsChain {
  const x = c as Partial<Record<keyof RewardsChain, unknown>>;
  return typeof x.rewardsView === 'function' && typeof x.finalizeRewards === 'function' && typeof x.claimRewards === 'function';
}

export const NATIVE: Address = '0x0000000000000000000000000000000000000000';

export const sameAddress = (a: string | undefined, b: string | undefined): boolean =>
  !!a && !!b && a.toLowerCase() === b.toLowerCase();
