/**
 * The node's HTTP surface: operations endpoints, and the two things counterparties need from it.
 *
 * ## Two audiences, which is why there can be two listeners
 *
 *  - **Operations** - `/healthz`, `/readyz`, `/status`, `/metrics` - follow the monitor's
 *    convention (packages/ops/src/server.ts): `/healthz` answers only "is the process alive", so a
 *    supervisor does not restart the node exactly when the chain or the bank misbehaves; `/readyz`
 *    is 503 until a tick has completed; `/status` is redacted at the boundary.
 *  - **Counterparties** - a taker fetching where to pay, a seller disclosing where to be paid.
 *    These face the internet. Run them on their own port (`API_PORT`) behind TLS, and keep the
 *    operations port private.
 *
 * ## Why the taker must sign
 *
 * Payment instructions carry the LP's PIX key AND the salt that opens the offer's on-chain
 * commitment. Anyone holding both can tie the offer - and every order against it - to the LP's
 * bank account. The salt exists so that link is shared only with counterparties (pixKeyCommitment
 * in @mova/ramp), so instructions go only to the order's taker, proven by an EIP-712 signature
 * over the order id and a timestamp. A signature older than five minutes is refused, so a leaked
 * request is not a standing credential. By default the check is plain ECDSA; the entrypoint
 * passes the RPC client's `verifyTypedData`, which also accepts smart-account (ERC-1271) takers.
 *
 * A seller's disclosure needs no signature: only whoever knows key or barcode AND salt can open
 * the commitment, and offramp.ts refuses an opening that does not match.
 *
 * ## The PIX webhook
 *
 * `POST /v1/webhook/pix` (a PSP posts to `webhookUrl` + `/pix`) takes the end-to-end ids out of the body
 * and nothing else: the node fetches each Pix from the API itself (onramp.ts `hint`) and ticks at once
 * (`LpNode.wake`). So the most a forged webhook can do is cause bank lookups, and authentication is there
 * to bound that. Two modes, one of which must be configured or the route does not exist:
 *
 *  - `hmac`: `x-webhook-signature: sha256=<hex HMAC-SHA256 of the raw body>` under a shared secret. For a
 *    PSP, or an intermediary, that signs its callbacks.
 *  - `proxy-mtls`: API Pix's own scheme. The PSP presents its client certificate; the LP's reverse proxy
 *    terminates TLS, verifies the certificate against the PSP's CA, and forwards a header saying so
 *    (nginx: `proxy_set_header X-SSL-Client-Verify $ssl_client_verify;`). The node accepts it only from a
 *    loopback peer carrying that header value - so the API listener must be reachable only through the proxy.
 *
 * ## Browsers
 *
 * A wallet page on another origin can call the three counterparty routes only if `cors.allowedOrigins` lists it
 * (CorsPolicy in @mova/ramp: exact origins, `*` and `null` refused, none by default). Their answers - refusals
 * included, so the wallet can say why - carry the CORS headers, and `OPTIONS` on them is the preflight. The
 * operations routes and the webhook never do: nothing there is for a browser, and a PSP is not one.
 *
 * Request bodies are never logged, and error messages never repeat what was submitted.
 *
 * A refusal that a wallet should be able to act on carries a stable `code` beside its sentence
 * (`{"error": "...", "code": "cap_reached"}`). Per-payer caps are the reason this exists: a person told
 * "the limit is reached" needs their own wallet's words, and the LP tells them THAT a limit was reached
 * and never how much they have moved - that total is the LP's alone (caps.ts).
 */
import { createHmac, timingSafeEqual } from 'node:crypto';
import { createServer, type IncomingMessage, type Server, type ServerResponse } from 'node:http';
import { parseWebhookPix } from './api-pix.js';
import { isHex, verifyTypedData, type Address, type Hex } from 'viem';
import { containsSecret, redact } from '@mova/ops/redact';
import { CorsPolicy, type CorsOptions } from '@mova/ramp';
import { InstructionsError } from './onramp.js';
import { PayeeError } from './offramp.js';
import type { LpNode } from './node.js';

export const INSTRUCTIONS_TYPES = {
  PaymentInstructionsRequest: [
    { name: 'orderId', type: 'bytes32' },
    { name: 'issuedAt', type: 'uint64' },
  ],
} as const;

export const instructionsDomain = (chainId: number, escrow: Address) => ({
  name: 'Mova-LP-Node',
  version: '1',
  chainId,
  verifyingContract: escrow,
});

/** How long a signed instructions request stays usable, either side of now. */
export const INSTRUCTIONS_MAX_SKEW_SECONDS = 300;

export type TypedDataVerifier = (args: {
  address: Address;
  domain: ReturnType<typeof instructionsDomain>;
  types: typeof INSTRUCTIONS_TYPES;
  primaryType: 'PaymentInstructionsRequest';
  message: { orderId: Hex; issuedAt: bigint };
  signature: Hex;
}) => Promise<boolean>;

export interface ServeOptions {
  /** Which routes this listener serves. */
  mode: 'ops' | 'api' | 'both';
  redactValues?: readonly (string | undefined)[];
  verifyTypedData?: TypedDataVerifier;
  maxBodyBytes?: number;
  /** Unix seconds. */
  now?: () => number;
  /** Enables `POST /v1/webhook/pix` on the API routes. See the header for the two modes. */
  webhook?: WebhookAuth;
  /**
   * Browser origins allowed to call the counterparty routes. Default none: no CORS headers, every preflight 403.
   * Never applied to the operations routes or the webhook. A malformed origin throws here, at startup.
   */
  cors?: CorsOptions;
}

/** The routes a browser wallet calls, with their method: the only ones CORS applies to. */
const BROWSER_ROUTES: ReadonlyMap<string, string> = new Map([
  ['/v1/onramp/instructions', 'POST'],
  ['/v1/offramp/payee', 'POST'],
]);

export type WebhookAuth =
  | { auth: 'hmac'; secret: string }
  | { auth: 'proxy-mtls'; header: string; value: string };

/** Most end-to-end ids taken from one webhook call. */
export const WEBHOOK_MAX_IDS = 100;

const LOOPBACK = new Set(['127.0.0.1', '::1', '::ffff:127.0.0.1']);

/** `sha256=<hex>` over the raw body, as a signing PSP or proxy sends it. */
export function webhookSignature(secret: string, body: string | Buffer): string {
  return `sha256=${createHmac('sha256', secret).update(body).digest('hex')}`;
}

class HttpError extends Error {
  constructor(readonly status: number, message: string) { super(message); }
}

const json = (value: unknown) => JSON.stringify(value, (_k, v) => (typeof v === 'bigint' ? v.toString() : v), 2);

export function serveLpNode(node: LpNode, o: ServeOptions): {
  server: Server;
  listen: (port?: number, host?: string) => Promise<number>;
  close: () => Promise<void>;
} {
  const ops = o.mode !== 'api';
  const api = o.mode !== 'ops';
  const verify: TypedDataVerifier = o.verifyTypedData ?? ((args) => verifyTypedData(args));
  const now = () => (o.now ? o.now() : Math.floor(Date.now() / 1000));
  const cors = new CorsPolicy(o.cors);

  const raw = async (rq: IncomingMessage, limit = o.maxBodyBytes ?? 16 * 1024): Promise<Buffer> => {
    const chunks: Buffer[] = [];
    let size = 0;
    for await (const c of rq) {
      size += (c as Buffer).length;
      if (size > limit) throw new HttpError(413, 'request body too large');
      chunks.push(c as Buffer);
    }
    return Buffer.concat(chunks);
  };

  const webhookAuthorised = (rq: IncomingMessage, bytes: Buffer): boolean => {
    const w = o.webhook!;
    if (w.auth === 'hmac') {
      const got = Buffer.from(String(rq.headers['x-webhook-signature'] ?? ''));
      const want = Buffer.from(webhookSignature(w.secret, bytes));
      return got.length === want.length && timingSafeEqual(got, want);
    }
    const peer = rq.socket.remoteAddress ?? '';
    return LOOPBACK.has(peer) && String(rq.headers[w.header.toLowerCase()] ?? '') === w.value;
  };

  const body = async (rq: IncomingMessage): Promise<Record<string, unknown>> => {
    const bytes = await raw(rq);
    try {
      const v = JSON.parse(bytes.toString('utf8') || '{}') as unknown;
      if (!v || typeof v !== 'object' || Array.isArray(v)) throw new Error('not an object');
      return v as Record<string, unknown>;
    } catch {
      throw new HttpError(400, 'request body is not a JSON object');
    }
  };

  const handle = async (rq: IncomingMessage, rs: ServerResponse): Promise<void> => {
    const url = new URL(rq.url ?? '/', 'http://localhost');
    const origin = rq.headers.origin;
    // Only a counterparty route, and only on a listener that serves them (header: Browsers).
    const browserMethod = api ? BROWSER_ROUTES.get(url.pathname) : undefined;
    const corsHeaders = browserMethod ? cors.responseHeaders(origin) : {};
    const send = (code: number, value: unknown) => {
      rs.writeHead(code, { 'content-type': 'application/json', ...corsHeaders });
      rs.end(redact(json(value), o.redactValues));
    };
    // Payment instructions are the payload itself: a PIX key and salt, a BR Code, a boleto line, or an
    // API Pix charge URL whose path IS the charge. `redact` cuts every URL to its host, which would serve a
    // link nobody could pay. They go only to the order's
    // signature-verified taker, so they are sent verbatim; what must still never leave is a configured
    // secret, so a response carrying one is refused rather than scrubbed.
    const sendVerbatim = (value: unknown) => {
      const text = json(value);
      if (containsSecret(text, o.redactValues)) throw new HttpError(500, 'refusing to serve instructions that contain a configured secret');
      rs.writeHead(200, { 'content-type': 'application/json', ...corsHeaders });
      rs.end(text);
    };
    try {
      if (browserMethod && rq.method === 'OPTIONS') {
        const p = cors.preflight(origin, [browserMethod]);
        rs.writeHead(p.status, p.headers);
        rs.end();
        return;
      }
      if (rq.method === 'GET' && url.pathname === '/healthz') return send(200, { ok: true });
      if (rq.method === 'GET' && url.pathname === '/readyz') return send(node.ready ? 200 : 503, { ready: node.ready });

      if (ops && rq.method === 'GET' && url.pathname === '/status') return send(node.ready ? 200 : 503, node.status());
      if (ops && rq.method === 'GET' && url.pathname === '/metrics') {
        rs.writeHead(200, { 'content-type': 'text/plain; version=0.0.4; charset=utf-8' });
        rs.end(node.metrics.render());
        return;
      }

      if (api && rq.method === 'POST' && url.pathname === '/v1/onramp/instructions') {
        if (!node.onramp) throw new HttpError(404, 'this node does not run the on-ramp');
        const b = await body(rq);
        const orderId = b.orderId;
        const signature = b.signature;
        const issuedAt = b.issuedAt;
        if (typeof orderId !== 'string' || !isHex(orderId) || orderId.length !== 66) throw new HttpError(400, 'orderId must be a bytes32');
        if (typeof signature !== 'string' || !isHex(signature)) throw new HttpError(400, 'signature must be hex');
        if (typeof issuedAt !== 'number' || !Number.isInteger(issuedAt)) throw new HttpError(400, 'issuedAt must be unix seconds');
        if (Math.abs(now() - issuedAt) > INSTRUCTIONS_MAX_SKEW_SECONDS) throw new HttpError(401, 'request expired or from the future');

        const { taker, body: instructions } = await node.onramp.instructions(orderId);
        const ok = await verify({
          address: taker, domain: instructionsDomain(node.ctx.chain.chainId, node.ctx.chain.onramp!),
          types: INSTRUCTIONS_TYPES, primaryType: 'PaymentInstructionsRequest',
          message: { orderId, issuedAt: BigInt(issuedAt) }, signature,
        }).catch(() => false);
        if (!ok) throw new HttpError(401, 'not signed by the order\'s taker');
        return sendVerbatim(instructions);
      }

      if (api && o.webhook && rq.method === 'POST' && url.pathname === '/v1/webhook/pix') {
        // API Pix batches up to hundreds of records; bounded well above that.
        const bytes = await raw(rq, 512 * 1024);
        if (!webhookAuthorised(rq, bytes)) {
          node.metrics.inc('mova_lp_webhook_requests_total', { result: 'unauthorised' });
          throw new HttpError(401, 'webhook not authenticated');
        }
        let ids: string[];
        try {
          ids = parseWebhookPix(JSON.parse(bytes.toString('utf8')) as unknown).map((p) => p.bankTxId).slice(0, WEBHOOK_MAX_IDS);
        } catch {
          node.metrics.inc('mova_lp_webhook_requests_total', { result: 'malformed' });
          throw new HttpError(400, 'not an API Pix webhook body');
        }
        const added = node.onramp ? node.onramp.hint(ids) : 0;
        node.metrics.inc('mova_lp_webhook_requests_total', { result: 'accepted' });
        if (added > 0) node.wake();
        return send(202, { accepted: ids.length });
      }

      if (api && rq.method === 'POST' && url.pathname === '/v1/offramp/payee') {
        if (!node.offramp) throw new HttpError(404, 'this node does not run the off-ramp');
        const b = await body(rq);
        const saleId = b.saleId;
        if (typeof saleId !== 'string' || !isHex(saleId) || saleId.length !== 66) throw new HttpError(400, 'saleId must be a bytes32');
        await node.offramp.submitPayee(saleId, { pixKey: b.pixKey, boletoLine: b.boletoLine, salt: b.salt });
        return send(201, { accepted: true, saleId });
      }

      const routes = [
        '/healthz', '/readyz',
        ...(ops ? ['/status', '/metrics'] : []),
        ...(api ? ['POST /v1/onramp/instructions', 'POST /v1/offramp/payee', ...(o.webhook ? ['POST /v1/webhook/pix'] : [])] : []),
      ];
      return send(404, { error: 'not found', routes });
    } catch (e) {
      if (e instanceof HttpError || e instanceof InstructionsError || e instanceof PayeeError) {
        // Some refusals carry a stable code beside the sentence, so a wallet can say what happened in
        // its own words rather than showing an LP's English. See caps.ts for the cap ones.
        const code = e instanceof HttpError ? undefined : e.code;
        return send(e.status, code ? { error: e.message, code } : { error: e.message });
      }
      return send(500, { error: 'internal error' });
    }
  };

  const server = createServer((rq, rs) => void handle(rq, rs));
  return {
    server,
    listen: (port = 0, host = '127.0.0.1') => new Promise<number>((resolve) => {
      server.listen(port, host, () => {
        const a = server.address();
        resolve(typeof a === 'object' && a ? a.port : port);
      });
    }),
    close: () => new Promise<void>((resolve) => {
      server.close(() => resolve());
      // Keep-alive clients would otherwise hold shutdown open until they time out.
      server.closeIdleConnections();
    }),
  };
}

/** What a taker's wallet sends: sign, then POST `{ orderId, issuedAt, signature }`. */
export async function signInstructionsRequest(
  account: { signTypedData: (args: {
    domain: ReturnType<typeof instructionsDomain>; types: typeof INSTRUCTIONS_TYPES;
    primaryType: 'PaymentInstructionsRequest'; message: { orderId: Hex; issuedAt: bigint };
  }) => Promise<Hex> },
  args: { chainId: number; escrow: Address; orderId: Hex; issuedAt: number },
): Promise<{ orderId: Hex; issuedAt: number; signature: Hex }> {
  const signature = await account.signTypedData({
    domain: instructionsDomain(args.chainId, args.escrow), types: INSTRUCTIONS_TYPES,
    primaryType: 'PaymentInstructionsRequest', message: { orderId: args.orderId, issuedAt: BigInt(args.issuedAt) },
  });
  return { orderId: args.orderId, issuedAt: args.issuedAt, signature };
}
