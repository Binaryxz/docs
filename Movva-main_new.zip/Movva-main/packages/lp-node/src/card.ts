/**
 * The card partner's acquirer, as the node sees it: a plugin, like the bank.
 *
 * ## Who takes cards, and why the rules are shaped like this
 *
 * A card payment can be charged back months after the escrow released. So the contracts take CARD
 * only on a card-only offer of an INSTITUTIONAL LP - a licensed card partner carrying chargebacks under
 * contract - and the attestor signs only a CAPTURED charge, for the merchant account and card fee the offer
 * commits to, of exactly the order's amount plus that fee (SR2-32 in docs/security-review-phase2.md). What
 * remains for the node is the part the chain cannot see: getting the taker a checkout for exactly that
 * total, noticing the capture, and giving back any card money that did not buy anything.
 *
 * ## The contract an adapter MUST honour
 *
 * 1. **Idempotency.** Two `createCheckout` calls with one `idempotencyKey` create one checkout and return
 *    it both times. Two `reverse` calls with one key move money at most once and return the first's result.
 *    The node persists the key before calling, and after a crash asks `getReversal(key)` and repeats under
 *    the same key - never a new one.
 * 2. **A checkout charges exactly its amount, once, until it expires.** No amount the cardholder edits, no
 *    installment interest added to the captured total, no charge authorised after `expiresAt`. A checkout
 *    the node cancels takes no new charge.
 * 3. **The reference is the merchant's.** Every charge made through a checkout carries the checkout's
 *    `reference` (the order id), set by the node, never by the cardholder. It is how a capture is matched to
 *    its order, and the only way: amounts are not unique.
 * 4. **Statuses are the acquirer's.** `CAPTURED` only once the charge is captured for the merchant;
 *    `AUTHORIZED` is a hold, not money. A voided, refunded or charged-back charge says so.
 * 5. **Identifiers and times are the acquirer's.** `transactionId` is the acquirer's TID/NSU, `acquirerId`
 *    and `merchantId` exactly what it would show an attestor, and times are its clock, unix seconds.
 *
 * `MockAcquirer` is the reference implementation of these rules, with the failure modes the node must
 * survive available on demand.
 */
import { keccak256, toBytes } from 'viem';

export type ChargeStatus = 'AUTHORIZED' | 'CAPTURED' | 'VOIDED' | 'REFUNDED' | 'CHARGED_BACK';

export interface CardCharge {
  acquirerId: string;
  /** The acquirer's own id for the charge. Unique per acquirer. */
  transactionId: string;
  merchantId: string;
  /** The checkout's reference: the order id the node created it for. */
  reference: string;
  status: ChargeStatus;
  /** Authorised, or once captured the captured total, in centavos. */
  amountCents: bigint;
  authorizedAt: bigint;
  capturedAt?: bigint;
  /** The acquirer's reference to the cardholder (a customer id), for payerRef. Never a card number. */
  payerId?: string;
}

export interface CardCheckout {
  checkoutId: string;
  /** Where the taker pays. Shown only to the order's taker: it can be paid by whoever holds it. */
  url: string;
  amountCents: bigint;
  /** Unix seconds; no charge is authorised after it. */
  expiresAt: bigint;
  reference: string;
}

export interface CardReversalResult {
  idempotencyKey: string;
  transactionId: string;
  /** SETTLED: voided or refunded at the acquirer. PENDING: accepted, not final. FAILED: refused. */
  status: 'SETTLED' | 'PENDING' | 'FAILED';
  kind?: 'VOID' | 'REFUND';
  amountCents?: bigint;
  at?: bigint;
  failureReason?: string;
}

export interface CardAcquirer {
  /** Must equal `onramp.card.acquirerId`: the offer's commitment is to these two ids. */
  readonly acquirerId: string;
  readonly merchantId: string;
  createCheckout(req: { idempotencyKey: string; amountCents: bigint; expiresAt: bigint; reference: string }): Promise<CardCheckout>;
  /** Stop a checkout taking new charges. Charges already made are unaffected. */
  cancelCheckout(checkoutId: string): Promise<void>;
  /** Every charge made through checkouts carrying `reference`, in any status. */
  chargesFor(reference: string): Promise<CardCharge[]>;
  /** Void an authorisation, or refund a capture in full. Idempotent by key. */
  reverse(req: { idempotencyKey: string; transactionId: string; amountCents: bigint; reason: string }): Promise<CardReversalResult>;
  /** The outcome of an earlier `reverse` by its key; undefined if the acquirer never saw it. */
  getReversal(idempotencyKey: string): Promise<CardReversalResult | undefined>;
}

/*//////////////////////////////////////////////////////////////
                              MOCK ACQUIRER
//////////////////////////////////////////////////////////////*/

interface MockCheckout extends CardCheckout { key: string; cancelled: boolean }

/**
 * An acquirer in memory, honouring the adapter contract, with what a cardholder, a misbehaving acquirer
 * and a flaky connection can do available on demand.
 */
export class MockAcquirer implements CardAcquirer {
  readonly checkouts = new Map<string, MockCheckout>();
  readonly charges: CardCharge[] = [];
  readonly reversals = new Map<string, CardReversalResult>();
  /** Calls that reached the acquirer, duplicates included. */
  checkoutCalls = 0;
  reverseCalls = 0;
  private seq = 0;
  private faults: ('lose-checkout' | 'lose-reverse' | 'fail-reverse' | 'pending-reverse')[] = [];

  constructor(
    readonly acquirerId = '01027058000191',
    readonly merchantId = 'MOVA-PARTNER-0001',
    private readonly o: { now?: () => bigint; url?: string } = {},
  ) {}

  private now(): bigint {
    return this.o.now ? this.o.now() : BigInt(Math.floor(Date.now() / 1000));
  }

  /*------------------------- the outside world -------------------------*/

  /**
   * A cardholder pays a checkout. Refused as a real checkout refuses: cancelled, expired, or any amount but
   * its own. `capture: false` leaves an authorisation. `amountCents` other than the checkout's is only
   * accepted with `misbehave`, as a broken acquirer would.
   */
  pay(checkoutId: string, o: { capture?: boolean; amountCents?: bigint; payerId?: string; misbehave?: boolean } = {}): CardCharge {
    const c = [...this.checkouts.values()].find((x) => x.checkoutId === checkoutId);
    if (!c) throw new Error('no such checkout');
    if (c.cancelled) throw new Error('checkout cancelled');
    if (this.now() > c.expiresAt && !o.misbehave) throw new Error('checkout expired');
    const amount = o.amountCents ?? c.amountCents;
    if (amount !== c.amountCents && !o.misbehave) throw new Error('a checkout charges exactly its amount');
    return this.charge({ reference: c.reference, amountCents: amount, capture: o.capture ?? true, payerId: o.payerId });
  }

  /** A charge carrying any reference - another order's, say - as a cardholder or fraudster could make. */
  charge(o: { reference: string; amountCents: bigint; capture?: boolean; payerId?: string; merchantId?: string }): CardCharge {
    const at = this.now();
    const ch: CardCharge = {
      acquirerId: this.acquirerId, transactionId: `TID-${(++this.seq).toString().padStart(9, '0')}`,
      merchantId: o.merchantId ?? this.merchantId, reference: o.reference, status: o.capture === false ? 'AUTHORIZED' : 'CAPTURED',
      amountCents: o.amountCents, authorizedAt: at, capturedAt: o.capture === false ? undefined : at, payerId: o.payerId ?? 'CUST-0001',
    };
    this.charges.push(ch);
    return { ...ch };
  }

  /** Capture an authorisation, in full or - as a partial capture - for less. */
  capture(transactionId: string, amountCents?: bigint): void {
    const ch = this.charges.find((x) => x.transactionId === transactionId);
    if (!ch || ch.status !== 'AUTHORIZED') throw new Error('not an open authorisation');
    if (amountCents !== undefined && amountCents > ch.amountCents) throw new Error('cannot capture more than was authorised');
    ch.status = 'CAPTURED';
    ch.amountCents = amountCents ?? ch.amountCents;
    ch.capturedAt = this.now();
  }

  chargeback(transactionId: string): void {
    const ch = this.charges.find((x) => x.transactionId === transactionId);
    if (ch) ch.status = 'CHARGED_BACK';
  }

  /*--------------------------- fault injection --------------------------*/

  /** The next checkout is created, and the response is lost. */
  loseNextCheckoutResponse(): void { this.faults.push('lose-checkout'); }
  /** The next reversal moves the money, and the response is lost. */
  loseNextReverseResponse(): void { this.faults.push('lose-reverse'); }
  failNextReverse(): void { this.faults.push('fail-reverse'); }
  holdNextReverse(): void { this.faults.push('pending-reverse'); }

  settlePendingReversals(): void {
    for (const [k, r] of this.reversals) if (r.status === 'PENDING') this.finishReversal(k, r);
  }

  private take(kind: MockAcquirer['faults'][number]): boolean {
    const i = this.faults.indexOf(kind);
    if (i < 0) return false;
    this.faults.splice(i, 1);
    return true;
  }

  /** How many times card money actually went back for this key. The no-double-refund assertion. */
  moneyReversedFor(idempotencyKey: string): number {
    return this.reversals.has(idempotencyKey) && this.reversals.get(idempotencyKey)!.status !== 'FAILED' ? 1 : 0;
  }

  /*-------------------------------- adapter ------------------------------*/

  async createCheckout(req: { idempotencyKey: string; amountCents: bigint; expiresAt: bigint; reference: string }): Promise<CardCheckout> {
    this.checkoutCalls++;
    let c = this.checkouts.get(req.idempotencyKey);
    if (!c) {
      const checkoutId = `CHK-${keccak256(toBytes(req.idempotencyKey)).slice(2, 18)}`;
      c = {
        key: req.idempotencyKey, checkoutId, url: `${this.o.url ?? 'https://checkout.acquirer.example/pay'}/${checkoutId}`,
        amountCents: req.amountCents, expiresAt: req.expiresAt, reference: req.reference, cancelled: false,
      };
      this.checkouts.set(req.idempotencyKey, c);
    }
    if (this.take('lose-checkout')) throw new Error('socket hang up');
    const { key: _k, cancelled: _c, ...out } = c;
    return out;
  }

  async cancelCheckout(checkoutId: string): Promise<void> {
    for (const c of this.checkouts.values()) if (c.checkoutId === checkoutId) c.cancelled = true;
  }

  async chargesFor(reference: string): Promise<CardCharge[]> {
    return this.charges.filter((c) => c.reference === reference).map((c) => ({ ...c }));
  }

  async reverse(req: { idempotencyKey: string; transactionId: string; amountCents: bigint; reason: string }): Promise<CardReversalResult> {
    this.reverseCalls++;
    const prior = this.reversals.get(req.idempotencyKey);
    if (prior) return { ...prior };
    const ch = this.charges.find((x) => x.transactionId === req.transactionId);
    let r: CardReversalResult;
    if (!ch) {
      r = { idempotencyKey: req.idempotencyKey, transactionId: req.transactionId, status: 'FAILED', failureReason: 'no such charge' };
    } else if (this.take('fail-reverse')) {
      r = { idempotencyKey: req.idempotencyKey, transactionId: req.transactionId, status: 'FAILED', failureReason: 'refused by the acquirer' };
    } else if (ch.status !== 'AUTHORIZED' && ch.status !== 'CAPTURED') {
      r = { idempotencyKey: req.idempotencyKey, transactionId: req.transactionId, status: 'FAILED', failureReason: `the charge is ${ch.status}` };
    } else if (req.amountCents !== ch.amountCents) {
      r = { idempotencyKey: req.idempotencyKey, transactionId: req.transactionId, status: 'FAILED', failureReason: 'a reversal is for the whole charge' };
    } else {
      r = { idempotencyKey: req.idempotencyKey, transactionId: req.transactionId, status: 'PENDING', amountCents: ch.amountCents };
      this.reversals.set(req.idempotencyKey, r);
      if (!this.take('pending-reverse')) this.finishReversal(req.idempotencyKey, r);
      if (this.take('lose-reverse')) throw new Error('socket hang up');
      return { ...this.reversals.get(req.idempotencyKey)! };
    }
    this.reversals.set(req.idempotencyKey, r);
    return { ...r };
  }

  private finishReversal(key: string, r: CardReversalResult): void {
    const ch = this.charges.find((x) => x.transactionId === r.transactionId)!;
    const kind = ch.status === 'AUTHORIZED' ? 'VOID' : 'REFUND';
    ch.status = kind === 'VOID' ? 'VOIDED' : 'REFUNDED';
    this.reversals.set(key, { ...r, status: 'SETTLED', kind, at: this.now() });
  }

  async getReversal(idempotencyKey: string): Promise<CardReversalResult | undefined> {
    const r = this.reversals.get(idempotencyKey);
    return r && { ...r };
  }
}
