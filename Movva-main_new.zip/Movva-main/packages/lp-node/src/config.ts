/**
 * Configuration: secrets and addresses from the environment, strategy from a JSON file.
 *
 * ## The split, and why
 *
 * What an LP TUNES - spreads, sizes, rails, deadlines - is a document it reviews and versions, so
 * it lives in `LP_CONFIG`. What an LP must PROTECT - the wallet key, the RPC URL (which carries a
 * provider key), the payerRef secret, bank credentials - never goes in that file: keys come from
 * `*_FILE` paths (a mounted secret does not show up in `docker inspect`) or, for development, from
 * the variable itself, and are deleted from `process.env` once read so nothing later in the
 * process can print them.
 *
 * Every problem is collected before failing, as in the other entrypoints, and messages name the
 * variable or JSON path without echoing its value.
 *
 * ## Plugins: the bank and the provers
 *
 * Sending BRL is bank-specific (bank.ts), and a prover reaches the LP's bank session and the witnesses with their own
 * APIs. Neither can be configured as data, so the LP supplies a module:
 *
 *   BANK_MODULE=/app/plugins/bank.js     export function createBankAdapter(env): BankAdapter
 *   PROVER_MODULE=/app/plugins/prover.js export function createProvers(env): PaymentProver[]
 *
 * The built-in `MockBank` and local zkTLS witnesses exist for tests and the live
 * examples, and the entrypoint refuses them unless `LP_NODE_DEV=1`: a node that "pays" sellers from an
 * in-memory bank would claim real sales and never pay them, and one holding its witnesses'
 * keys would be vouching for its own payments.
 *
 *   ZKTLS_WITNESS_KEYS_FILE={ "verifier", "threshold", "keys", "urlPrefix" } a ZkTlsProver over MockBank, for PIX and boleto
 *
 * `DEV_MOCK_BANK_URL`, also only with `LP_NODE_DEV=1`, takes the MockBank from another process
 * (dev-mock-bank.ts) instead of memory - the dev stack's, when the node runs from the services image - and is refused
 * beside BANK_MODULE. The local witnesses may read that MockBank's records; never a BANK_MODULE's.
 *
 * ## Bank rails name a zkTLS verifier
 *
 * The escrows take a PIX, boleto or TED offer only on a verifier that proves the bank session
 * (`BankRailNeedsZkTls`). The entrypoint asks the chain that question of every asset's verifier
 * (`provesBankSession()`) before it starts, whatever the provers.
 *
 * ## Cards were removed
 *
 * The card rail, its acquirer module and the attestor quorum were removed on 24 September 2026 (docs/card-rail-removal.md).
 * A configuration that still names `onramp.card`, `ACQUIRER_MODULE` or `ATTESTOR_KEYS_FILE` is refused, not ignored.
 *
 * ## The gateway section
 *
 * A Movva gateway spends the LP's USDT without a human in the loop, so every limit on it - per mint,
 * per day, per redemption - must be written down: an enabled side with a cap missing is refused, not
 * defaulted. So are its costs (`usdtCostBps`, `usdtSaleBps`), which price every Movva offer and sale.
 * The fees it accepts default to zero, so a fee raised on-chain stops the node until the LP agrees to it.
 *
 * ## The rewards section
 *
 *   "rewards": { "contract": "0x…NodeRewards", "claim": true, "minClaim": "0", "lookbackEpochs": 12, "to": "0x…" }
 *
 * Node-provider rewards (rewards.ts). `contract` is required; the node claims by default, from the last 12
 * finalized epochs (at most 104), anything above zero, paid to the LP account unless `to` names another address.
 * `claim: false` keeps the metrics and `/status` without sending anything.
 *
 * ## The caps section
 *
 *   "caps": { "defaultTier": 0, "unknownPayer": "refuse",
 *             "tiers": { "0": { "dailyBrlCents": "200000", "monthlyBrlCents": "1000000" }, "4": {} },
 *             "payers": [ { "payerRef": "0x…", "tier": 3 } ] }
 *
 * Per-payer daily and monthly limits (caps.ts). There is no section by default and no default number in
 * it: a tier with no limits is unlimited, so an LP that writes `"caps": {}` gets counting and no
 * refusals. The tier numbers are the operator's to set, as the node-provider reward share is.
 *
 * `payers` names tiers for people the node already knows. Prefer `payerRef`, the hash `/status` shows -
 * it puts no personal data in a file an LP versions. A `payer` entry (a CPF, CNPJ or PIX key) is hashed
 * here and never kept, but the FILE then holds a document: treat it as personal data, or use
 * `TIER_MODULE`, which asks the LP's own KYC system and is the only source that can tier someone before
 * their first payment.
 */
import { getAddress, isAddress, type Address, type Hex } from 'viem';
import { Rail, normalizeOrigin, normalizePixKey, receiptTemplate } from '@mova/ramp';
import type { BankRail } from './bank.js';
import { isTier, type Tier, type TierLimits } from './caps.js';
import { payerRef } from './attestation.js';
import { sameAddress } from './chain.js';
import type { GatewayMintPolicy, GatewayRedeemPolicy } from './gateway.js';
import type { WebhookAuth } from './server.js';
import { DEFAULT_GAS_HEADROOM_PERCENT, type TxPolicy } from './tx-sender.js';
import type { OfferPricing, SalePricing } from './pricing.js';

export type Env = Record<string, string | undefined>;

export class ConfigError extends Error {
  constructor(readonly problems: string[]) {
    super(`refusing to start:\n  - ${problems.join('\n  - ')}`);
  }
}

/** `par`: R$ 1,00 per whole unit, for the gateway's Movva only. */
export type PriceSource = { source: 'oracle' } | { source: 'http'; url: string } | { source: 'par' };

export interface GatewaySettings {
  reserve: Address;
  usdt: Address;
  movva: Address;
  mint: GatewayMintPolicy;
  redeem: GatewayRedeemPolicy;
  maxRateDeviationBps: number;
  maxReferenceAgeSeconds: number;
  /** The LP's own USDT/BRL price, centavos per whole USDT. */
  usdtPrice?: { source: 'http'; url: string };
}

/** Node-provider rewards: rewards.ts, `RewardsOptions` less the registry, which is the node's own. */
export interface RewardsSettings {
  contract: Address;
  claim: boolean;
  minClaim: bigint;
  lookbackEpochs: number;
  to?: Address;
}

export interface OfferAssetSettings {
  asset: Address;
  symbol: string;
  liquidity: bigint;
  minOrder: bigint;
  maxOrder: bigint;
  verifier: Address;
  rails: Rail[];
  pricing: OfferPricing;
  refillBelowBps: number;
  maxOfferBrlCents?: bigint;
  gasReserveWei?: bigint;
  price: PriceSource;
}

export interface SaleAssetSettings {
  asset: Address;
  symbol: string;
  pricing: SalePricing;
  minSaleBrlCents: bigint;
  maxSaleBrlCents: bigint;
  price: PriceSource;
}

/** Per-payer caps as the strategy file states them; the numbers are the LP's, and there are none by default. */
export interface CapsSettings {
  tiers: Partial<Record<Tier, TierLimits>>;
  defaultTier: Tier;
  /** `payerRef` (lowercase) to tier. Documents in the file are hashed here and never kept. */
  payerTiers: Map<string, Tier>;
  unknownPayer: 'refuse' | 'allow';
}

/** Development zkTLS witnesses (`ZKTLS_WITNESS_KEYS_FILE`), signing receipt pages under `urlPrefix`: PIX and boleto. */
export interface DevZkTls {
  verifier: Address;
  threshold: number;
  keys: Hex[];
  urlPrefix: string;
}

export interface LpNodeConfig {
  rpcUrl: string;
  chainId?: number;
  key: Hex;
  payerRefSecret: Hex;
  stateFile: string;
  port: number;
  host: string;
  apiPort?: number;
  apiHost: string;
  /** Browser origins allowed to call the counterparty API (CORS), normalized. Empty: none. */
  apiAllowedOrigins: string[];
  dev: boolean;
  bankModule?: string;
  proverModule?: string;
  /** Exports `createTierSource(env): TierSource`: the LP's own per-payer tiers (caps.ts). Only with a `caps` section. */
  tierModule?: string;
  /** Only with `dev`, and never beside `bankModule`: the MockBank another process serves. */
  devMockBankUrl?: string;
  /** Only with `dev`, and only without `proverModule`: provers from local keys. */
  devProvers?: { zktls?: DevZkTls };
  /** Every value that must never be logged or served. */
  secrets: string[];

  registry: Address;
  fromBlock: bigint;
  confirmations: number;
  reorgWindow: bigint;
  pollMs: number;
  logSpan?: bigint;
  lpPayerId: string;
  /** Compact the journal past this many bytes. */
  compactJournalAtBytes: number;
  /** The PIX webhook's authentication; absent, the route is off. */
  webhook?: WebhookAuth;
  /** The arbitration desk service evidence commitments are filed with. */
  arbitration?: { url: string };
  onramp?: {
    escrow: Address;
    pixKey: string;
    receiver: { name: string; city: string };
    reclaimExpired: boolean;
    autoRefund: boolean;
    boletoDueDays: number;
    lateCreditGraceSeconds: number;
    /**
     * `static` (default): a PIX order is served a BR Code for `pixKey` that the node builds, and credits are matched by
     * its txid. `cob`: an API Pix immediate charge per order (`PUT /cob/{txid}`), served as the PSP's dynamic BR Code and
     * matched by its txid only. Required where the PSP's API Pix lists only Pix paid to charges - Banco Inter documents
     * `GET /pix` so - and needs a bank adapter with `createCharge` and `getCharge` (`ApiPixReceiver`).
     */
    pixCharge: 'static' | 'cob';
    /** With `cob`: a charge expires this long before the order's `payBy` (default 300). */
    cobMarginSeconds: number;
    assets: OfferAssetSettings[];
  };
  offramp?: {
    escrow: Address;
    rails: BankRail[];
    maxOpenClaims: number;
    minTimeToPaySeconds: number;
    disputeMarginSeconds: number;
    bankClockSkewSeconds: number;
    raiseDisputeWhenUnproven: boolean;
    dailyBudgetCents?: bigint;
    assets: SaleAssetSettings[];
  };
  gateway?: GatewaySettings;
  rewards?: RewardsSettings;
  /** Per-payer daily and monthly limits (caps.ts). Absent: the node keeps no cap ledger at all. */
  caps?: CapsSettings;
  /**
   * Fee cap, stuck-transaction replacement and gas headroom. Without it, fees are the node's estimate, uncapped,
   * nothing is replaced, and the gas limit is the estimate plus 20% plus 25,000.
   */
  tx?: TxPolicy;
}

const SECRET_NAME = /(KEY|SECRET|TOKEN|PASSWORD|CREDENTIAL)/i;

/** A JSON reader that records problems by path instead of throwing on the first. */
class Doc {
  constructor(readonly problems: string[]) {}

  obj(v: unknown, path: string): Record<string, unknown> | undefined {
    if (v && typeof v === 'object' && !Array.isArray(v)) return v as Record<string, unknown>;
    this.problems.push(`${path} must be an object`);
    return undefined;
  }

  address(o: Record<string, unknown>, k: string, path: string): Address {
    const v = o[k];
    if (typeof v === 'string' && isAddress(v, { strict: false })) return getAddress(v);
    this.problems.push(`${path}.${k} must be an address`);
    return '0x0000000000000000000000000000000000000000';
  }

  string(o: Record<string, unknown>, k: string, path: string, fallback?: string): string {
    const v = o[k];
    if (typeof v === 'string' && v.trim()) return v.trim();
    if (v === undefined && fallback !== undefined) return fallback;
    this.problems.push(`${path}.${k} must be a non-empty string`);
    return fallback ?? '';
  }

  big(o: Record<string, unknown>, k: string, path: string, opts: { optional?: boolean; fallback?: bigint } = {}): bigint | undefined {
    const v = o[k];
    if (v === undefined) {
      if (opts.fallback !== undefined) return opts.fallback;
      if (!opts.optional) this.problems.push(`${path}.${k} is required`);
      return undefined;
    }
    if ((typeof v === 'string' || typeof v === 'number') && /^\d+$/.test(String(v))) return BigInt(String(v));
    this.problems.push(`${path}.${k} must be a non-negative integer (as a string for large values)`);
    return undefined;
  }

  int(o: Record<string, unknown>, k: string, path: string, fallback: number | undefined, max?: number): number {
    const v = o[k];
    if (v === undefined) {
      if (fallback === undefined) this.problems.push(`${path}.${k} is required`);
      return fallback ?? 0;
    }
    if (typeof v !== 'number' || !Number.isInteger(v) || v < 0 || (max !== undefined && v > max)) {
      this.problems.push(`${path}.${k} must be an integer from 0${max !== undefined ? ` to ${max}` : ''}`);
      return fallback ?? 0;
    }
    return v;
  }

  bool(o: Record<string, unknown>, k: string, path: string, fallback: boolean): boolean {
    const v = o[k];
    if (v === undefined) return fallback;
    if (typeof v !== 'boolean') this.problems.push(`${path}.${k} must be true or false`);
    return v === true;
  }

  price(o: Record<string, unknown>, path: string): PriceSource {
    const p = this.obj(o.price, `${path}.price`);
    if (!p) return { source: 'oracle' };
    if (p.source === 'oracle') return { source: 'oracle' };
    if (p.source === 'par') return { source: 'par' };
    if (p.source === 'http' && typeof p.url === 'string' && /^https?:\/\//.test(p.url)) return { source: 'http', url: p.url };
    this.problems.push(`${path}.price must be {"source":"oracle"}, {"source":"par"} or {"source":"http","url":"https://..."}`);
    return { source: 'oracle' };
  }
}

const RAILS: Record<string, Rail> = { PIX: Rail.PIX, BOLETO: Rail.BOLETO, TED: Rail.TED };

/** A development prover file, validated by shape; its keys go on the redaction list. */
function devProverFile(
  name: 'ZKTLS_WITNESS_KEYS_FILE', path: string, readFile: (p: string) => string, problems: string[],
): DevZkTls | undefined {
  let j: Record<string, unknown>;
  try {
    const parsed = JSON.parse(readFile(path)) as unknown;
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error('not an object');
    j = parsed as Record<string, unknown>;
  } catch {
    problems.push(`${name} could not be read or is not a JSON object`);
    return undefined;
  }
  const keys = Array.isArray(j.keys) ? j.keys : [];
  const threshold = j.threshold;
  const before = problems.length;
  if (typeof j.verifier !== 'string' || !isAddress(j.verifier, { strict: false })) problems.push(`${name}.verifier must be an address`);
  if (keys.length === 0 || !keys.every((k) => typeof k === 'string' && /^0x[0-9a-fA-F]{64}$/.test(k))) {
    problems.push(`${name}.keys must be a non-empty list of 0x-prefixed 32-byte keys`);
  }
  if (typeof threshold !== 'number' || !Number.isInteger(threshold) || threshold < 1 || threshold > keys.length) {
    problems.push(`${name}.threshold must be an integer from 1 to the number of keys`);
  }
  const urlPrefix = typeof j.urlPrefix === 'string' ? j.urlPrefix : '';
  try {
    receiptTemplate(urlPrefix, 'pix-received');
  } catch {
    problems.push(`${name}.urlPrefix must be https://<lowercase host>/[path/], the prefix the verifier allowlists for its receipt templates`);
  }
  if (problems.length > before) return undefined;
  return { verifier: getAddress(j.verifier as string), threshold: threshold as number, keys: keys as Hex[], urlPrefix };
}

/**
 * The caps section. Every number is optional and none has a default: an LP that names no limit gets
 * counting without refusals, which is what "off by default" means here. Documents are hashed as they are
 * read and the raw value is never stored on the config.
 */
function capsSettings(d: Doc, value: unknown, secret: Hex, problems: string[]): CapsSettings | undefined {
  const p = 'config.caps';
  const c = d.obj(value, p);
  if (!c) return undefined;
  const out: CapsSettings = { tiers: {}, defaultTier: 0, payerTiers: new Map(), unknownPayer: 'refuse' };

  const dt = c.defaultTier;
  if (dt !== undefined) {
    if (isTier(dt)) out.defaultTier = dt;
    else problems.push(`${p}.defaultTier must be a tier 0-4`);
  }
  if (c.unknownPayer !== undefined) {
    if (c.unknownPayer === 'refuse' || c.unknownPayer === 'allow') out.unknownPayer = c.unknownPayer;
    else problems.push(`${p}.unknownPayer must be "refuse" (the default: a payment the bank attributes to nobody cannot be capped, so it is not settled) or "allow"`);
  }
  if (c.tiers !== undefined) {
    const tiers = d.obj(c.tiers, `${p}.tiers`) ?? {};
    for (const [k, v] of Object.entries(tiers)) {
      const tier = /^[0-4]$/.test(k) ? Number(k) : undefined;
      if (!isTier(tier)) {
        problems.push(`${p}.tiers has key "${k}": tiers are "0" to "4" (Rev. 2 §10.1)`);
        continue;
      }
      const o = d.obj(v, `${p}.tiers.${k}`) ?? {};
      const limits: TierLimits = {};
      for (const name of ['dailyBrlCents', 'monthlyBrlCents'] as const) {
        if (o[name] === undefined) continue;
        const cents = d.big(o, name, `${p}.tiers.${k}`, { optional: true });
        if (cents !== undefined) limits[name] = cents;
      }
      if (limits.dailyBrlCents !== undefined && limits.monthlyBrlCents !== undefined && limits.monthlyBrlCents < limits.dailyBrlCents) {
        problems.push(`${p}.tiers.${k}: monthlyBrlCents is below dailyBrlCents, so the daily limit could never be reached`);
      }
      out.tiers[tier] = limits;
    }
  }
  const payers = c.payers;
  if (payers !== undefined) {
    if (!Array.isArray(payers)) {
      problems.push(`${p}.payers must be a list of {"payerRef"|"payer", "tier"}`);
    } else {
      payers.forEach((raw, i) => {
        const o = d.obj(raw, `${p}.payers[${i}]`) ?? {};
        const tier = o.tier;
        if (!isTier(tier)) {
          problems.push(`${p}.payers[${i}].tier must be a tier 0-4`);
          return;
        }
        const ref = o.payerRef;
        const payer = o.payer;
        if (typeof ref === 'string' && /^0x[0-9a-fA-F]{64}$/.test(ref)) {
          if (payer !== undefined) problems.push(`${p}.payers[${i}]: give payerRef or payer, not both`);
          out.payerTiers.set(ref.toLowerCase(), tier);
        } else if (typeof payer === 'string' && payer.trim()) {
          // Hashed here and dropped: nothing downstream of this function ever sees the document.
          out.payerTiers.set(payerRef(payer.trim(), secret).toLowerCase(), tier);
        } else {
          problems.push(`${p}.payers[${i}] must name payerRef (32 bytes of hex, as /status shows it) or payer (a CPF, CNPJ or PIX key)`);
        }
      });
    }
  }
  // A section naming no limit at all is not a problem: it counts and refuses nothing, which is how an LP
  // turns the ledger on before it has decided its numbers.
  return out;
}

function gatewaySettings(d: Doc, value: unknown, problems: string[]): GatewaySettings | undefined {
  const p = 'config.gateway';
  const g = d.obj(value, p);
  if (!g) return undefined;
  const mint = g.mint === undefined ? {} : d.obj(g.mint, `${p}.mint`) ?? {};
  const redeem = g.redeem === undefined ? {} : d.obj(g.redeem, `${p}.redeem`) ?? {};
  const mintOn = d.bool(mint, 'enabled', `${p}.mint`, true);
  const redeemOn = d.bool(redeem, 'enabled', `${p}.redeem`, true);
  // A limit or a cost on an enabled side is stated, never inherited; on a disabled side it is moot.
  const limit = (o: Record<string, unknown>, k: string, path: string, on: boolean) => d.big(o, k, path, on ? {} : { fallback: 0n }) ?? 0n;
  const s: GatewaySettings = {
    reserve: d.address(g, 'reserve', p),
    usdt: d.address(g, 'usdt', p),
    movva: d.address(g, 'movva', p),
    mint: {
      enabled: mintOn,
      maxSlippageBps: d.int(mint, 'maxSlippageBps', `${p}.mint`, 10, 500),
      minMintUsdt: d.big(mint, 'minMintUsdt', `${p}.mint`, { fallback: 1_000_000n }) ?? 0n,
      maxMintUsdt: limit(mint, 'maxMintUsdt', `${p}.mint`, mintOn),
      maxMintUsdtPerDay: limit(mint, 'maxMintUsdtPerDay', `${p}.mint`, mintOn),
      keepUsdt: d.big(mint, 'keepUsdt', `${p}.mint`, { fallback: 0n }) ?? 0n,
      maxFeeBps: d.int(mint, 'maxFeeBps', `${p}.mint`, 0, 100),
      usdtCostBps: d.int(mint, 'usdtCostBps', `${p}.mint`, mintOn ? undefined : 0, 5_000),
    },
    redeem: {
      enabled: redeemOn,
      keepMovva: d.big(redeem, 'keepMovva', `${p}.redeem`, { fallback: 0n }) ?? 0n,
      minRedeemMovva: d.big(redeem, 'minRedeemMovva', `${p}.redeem`, { fallback: 10n ** 19n }) ?? 0n,
      maxRedeemMovva: limit(redeem, 'maxRedeemMovva', `${p}.redeem`, redeemOn),
      maxRedeemMovvaPerDay: limit(redeem, 'maxRedeemMovvaPerDay', `${p}.redeem`, redeemOn),
      maxSlippageBps: d.int(redeem, 'maxSlippageBps', `${p}.redeem`, 10, 500),
      minCollateralRatioBps: d.int(redeem, 'minCollateralRatioBps', `${p}.redeem`, 10_000, 20_000),
      maxFeeBps: d.int(redeem, 'maxFeeBps', `${p}.redeem`, 0, 100),
      usdtSaleBps: d.int(redeem, 'usdtSaleBps', `${p}.redeem`, redeemOn ? undefined : 0, 5_000),
    },
    maxRateDeviationBps: d.int(g, 'maxRateDeviationBps', p, 100, 5_000),
    maxReferenceAgeSeconds: d.int(g, 'maxReferenceAgeSeconds', p, 300),
  };
  if (g.usdtPrice !== undefined) {
    const u = d.obj(g.usdtPrice, `${p}.usdtPrice`);
    if (u && u.source === 'http' && typeof u.url === 'string' && /^https?:\/\//.test(u.url)) s.usdtPrice = { source: 'http', url: u.url };
    else if (u) problems.push(`${p}.usdtPrice must be {"source":"http","url":"https://..."} (centavos per whole USDT)`);
  }

  const addrs = [s.reserve, s.usdt, s.movva].map((a) => a.toLowerCase());
  if (new Set(addrs).size !== 3) problems.push(`${p}: reserve, usdt and movva must be three different addresses`);
  if (mintOn) {
    const m = s.mint;
    if (m.maxSlippageBps < 1) problems.push(`${p}.mint.maxSlippageBps must be at least 1: previewMint ignores the vault's rounding, so an exact minimum can revert`);
    if (m.minMintUsdt === 0n || m.maxMintUsdt < m.minMintUsdt) problems.push(`${p}.mint: need 0 < minMintUsdt <= maxMintUsdt`);
    if (m.maxMintUsdtPerDay < m.maxMintUsdt) problems.push(`${p}.mint.maxMintUsdtPerDay must be at least maxMintUsdt`);
  }
  if (redeemOn) {
    const r = s.redeem;
    if (r.maxSlippageBps < 1) problems.push(`${p}.redeem.maxSlippageBps must be at least 1`);
    if (r.minRedeemMovva === 0n || r.maxRedeemMovva < r.minRedeemMovva) problems.push(`${p}.redeem: need 0 < minRedeemMovva <= maxRedeemMovva`);
    if (r.maxRedeemMovvaPerDay < r.maxRedeemMovva) problems.push(`${p}.redeem.maxRedeemMovvaPerDay must be at least maxRedeemMovva`);
    // Below 50% is not a policy anyone should reach by typo; set it knowingly between 50% and par.
    if (r.minCollateralRatioBps < 5_000) problems.push(`${p}.redeem.minCollateralRatioBps must be from 5000 to 20000 (10000: never redeem below par)`);
  }
  return s;
}

/**
 * Read and validate everything. `readFile` is injected so tests never touch the filesystem;
 * the returned config holds secret values, and nothing in it is ever logged whole.
 */
export function lpNodeConfigFromEnv(env: Env, readFile: (path: string) => string): LpNodeConfig {
  const problems: string[] = [];
  const need = (name: string, what: string): string => {
    const v = env[name]?.trim();
    if (!v) problems.push(`${name} is required: ${what}`);
    return v ?? '';
  };
  const secret = (name: string, what: string, shape: RegExp, shapeMsg: string): string => {
    const file = env[`${name}_FILE`]?.trim();
    const direct = env[name]?.trim();
    if (file && direct) {
      problems.push(`set ${name}_FILE or ${name}, not both`);
      return '';
    }
    let v = direct ?? '';
    if (file) {
      try {
        v = readFile(file).trim();
      } catch {
        problems.push(`${name}_FILE could not be read`);
        return '';
      }
    }
    if (!v) {
      problems.push(`${name}_FILE (or ${name}) is required: ${what}`);
      return '';
    }
    if (!shape.test(v)) problems.push(`${name} ${shapeMsg}`);
    return v;
  };
  const intEnv = (name: string, fallback: number | undefined): number | undefined => {
    const v = env[name]?.trim();
    if (!v) return fallback;
    if (!/^\d+$/.test(v)) {
      problems.push(`${name} must be a non-negative integer`);
      return fallback;
    }
    return Number(v);
  };

  const rpcUrl = need('RPC_URL', 'the Ethereum JSON-RPC endpoint');
  if (rpcUrl && !/^https?:\/\//.test(rpcUrl)) problems.push('RPC_URL must be an http(s) URL');
  const key = secret('LP_KEY', "the LP's wallet key: the address admitted in LPRegistry", /^0x[0-9a-fA-F]{64}$/, 'must be a 0x-prefixed 32-byte hex key') as Hex;
  const payerRefSecret = secret('PAYER_REF_SECRET', 'a 32-byte secret keying payerRef', /^0x[0-9a-fA-F]{64}$/, 'must be 32 bytes of 0x-prefixed hex') as Hex;
  const stateFile = need('STATE_FILE', 'the journal path, on a persistent encrypted volume');
  const configPath = need('LP_CONFIG', 'the strategy file (JSON)');
  const dev = env.LP_NODE_DEV === '1';

  let raw: Record<string, unknown> = {};
  if (configPath) {
    try {
      const parsed = JSON.parse(readFile(configPath)) as unknown;
      if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) raw = parsed as Record<string, unknown>;
      else problems.push('LP_CONFIG must hold a JSON object');
    } catch {
      problems.push('LP_CONFIG could not be read or is not JSON');
    }
  }
  const d = new Doc(problems);

  const cfg: LpNodeConfig = {
    rpcUrl, key, payerRefSecret, stateFile, dev,
    chainId: intEnv('CHAIN_ID', undefined),
    port: intEnv('PORT', 9480)!,
    host: env.HOST?.trim() || '0.0.0.0',
    apiPort: intEnv('API_PORT', undefined),
    apiHost: env.API_HOST?.trim() || '0.0.0.0',
    apiAllowedOrigins: [],
    bankModule: env.BANK_MODULE?.trim() || undefined,
    proverModule: env.PROVER_MODULE?.trim() || undefined,
    tierModule: env.TIER_MODULE?.trim() || undefined,
    secrets: [],
    registry: d.address(raw, 'registry', 'config'),
    fromBlock: d.big(raw, 'fromBlock', 'config') ?? 0n,
    confirmations: d.int(raw, 'confirmations', 'config', 3, 128),
    reorgWindow: BigInt(d.int(raw, 'reorgWindow', 'config', 64, 10_000)),
    pollMs: d.int(raw, 'pollMs', 'config', 5_000),
    logSpan: d.big(raw, 'logSpan', 'config', { optional: true }),
    lpPayerId: d.string(raw, 'lpPayerId', 'config'),
    compactJournalAtBytes: d.int(raw, 'compactJournalAtBytes', 'config', 64 * 1024 * 1024),
  };
  (env.API_ALLOWED_ORIGINS ?? '').split(',').map((s) => s.trim()).filter(Boolean).forEach((s, i) => {
    try {
      cfg.apiAllowedOrigins.push(normalizeOrigin(s));
    } catch (e) {
      problems.push(`API_ALLOWED_ORIGINS entry ${i + 1} ${(e as Error).message}`);
    }
  });
  if (cfg.compactJournalAtBytes < 64 * 1024) problems.push('config.compactJournalAtBytes must be at least 65536: below that a snapshot could exceed it and compact every tick');
  if (cfg.confirmations < 1) problems.push('config.confirmations must be at least 1');
  if (cfg.reorgWindow < BigInt(cfg.confirmations)) problems.push('config.reorgWindow must be at least config.confirmations');
  if (!cfg.bankModule && !dev) problems.push('BANK_MODULE is required: the adapter that moves BRL at your bank (see bank.ts)');
  const devMockBankUrl = env.DEV_MOCK_BANK_URL?.trim();
  if (devMockBankUrl) {
    if (!dev) {
      problems.push('DEV_MOCK_BANK_URL is for LP_NODE_DEV=1 only: it names a development MockBank, which moves no money; set BANK_MODULE');
    } else if (cfg.bankModule) {
      problems.push('set BANK_MODULE or DEV_MOCK_BANK_URL, not both: the development URL serves the bank');
    } else if (!/^https?:\/\/[^\s?#]+$/.test(devMockBankUrl)) {
      problems.push('DEV_MOCK_BANK_URL must be an http(s) base URL');
    } else {
      cfg.devMockBankUrl = devMockBankUrl;
    }
  }
  for (const gone of ['ACQUIRER_MODULE', 'ATTESTOR_KEYS_FILE'] as const) {
    if (env[gone]?.trim()) problems.push(`${gone} is gone: the card rail and the attestor quorum were removed on 24 September 2026 (docs/card-rail-removal.md)`);
  }
  const zkPath = env.ZKTLS_WITNESS_KEYS_FILE?.trim();
  if (zkPath) {
    if (!dev) {
      problems.push('ZKTLS_WITNESS_KEYS_FILE is for LP_NODE_DEV=1 only: an LP holding its witnesses\' keys vouches for its own payments; use PROVER_MODULE');
    } else if (cfg.proverModule) {
      problems.push('set PROVER_MODULE or ZKTLS_WITNESS_KEYS_FILE, not both');
    } else {
      const file = devProverFile('ZKTLS_WITNESS_KEYS_FILE', zkPath, readFile, problems);
      if (file) cfg.devProvers = { zktls: file };
    }
  }

  if (raw.onramp !== undefined) {
    const on = d.obj(raw.onramp, 'config.onramp');
    if (on) {
      const pixKey = d.string(on, 'pixKey', 'config.onramp');
      try {
        if (pixKey) normalizePixKey(pixKey);
      } catch {
        problems.push('config.onramp.pixKey is not a valid PIX key');
      }
      const receiver = d.obj(on.receiver, 'config.onramp.receiver') ?? {};
      if (on.pixCharge !== undefined && on.pixCharge !== 'static' && on.pixCharge !== 'cob') {
        problems.push('config.onramp.pixCharge must be "static" or "cob" (cob: an API Pix charge per order, required where the PSP lists only charge-paid Pix)');
      }
      const assets = Array.isArray(on.assets) ? on.assets : [];
      if (on.card !== undefined) problems.push('config.onramp.card is gone: the card rail was removed on 24 September 2026 (docs/card-rail-removal.md)');
      if (assets.length === 0) problems.push('config.onramp.assets must list at least one asset');
      cfg.onramp = {
        escrow: d.address(on, 'escrow', 'config.onramp'),
        pixKey,
        receiver: { name: d.string(receiver, 'name', 'config.onramp.receiver'), city: d.string(receiver, 'city', 'config.onramp.receiver') },
        reclaimExpired: d.bool(on, 'reclaimExpired', 'config.onramp', true),
        autoRefund: d.bool(on, 'autoRefund', 'config.onramp', true),
        boletoDueDays: d.int(on, 'boletoDueDays', 'config.onramp', 3, 60),
        lateCreditGraceSeconds: d.int(on, 'lateCreditGraceSeconds', 'config.onramp', 6 * 3600),
        pixCharge: on.pixCharge === 'cob' ? 'cob' : 'static',
        // ONRAMP_PAY_WINDOW is 30 minutes: past 25 of margin a charge would hardly be payable.
        cobMarginSeconds: d.int(on, 'cobMarginSeconds', 'config.onramp', 300, 1_500),
        assets: assets.map((a, i) => {
          const p = `config.onramp.assets[${i}]`;
          const o = d.obj(a, p) ?? {};
          const rails = Array.isArray(o.rails) ? o.rails : ['PIX'];
          const parsedRails = rails.map((r) => RAILS[String(r)]).filter((r): r is Rail => r !== undefined);
          if (parsedRails.length !== rails.length || parsedRails.length === 0) problems.push(`${p}.rails must be a non-empty list of PIX, BOLETO, TED`);
          const s: OfferAssetSettings = {
            asset: d.address(o, 'asset', p),
            symbol: d.string(o, 'symbol', p),
            liquidity: d.big(o, 'liquidity', p) ?? 0n,
            minOrder: d.big(o, 'minOrder', p) ?? 0n,
            maxOrder: d.big(o, 'maxOrder', p) ?? 0n,
            verifier: d.address(o, 'verifier', p),
            rails: parsedRails,
            pricing: {
              spreadBps: d.int(o, 'spreadBps', p, undefined, 5_000),
              minSpreadBps: d.int(o, 'minSpreadBps', p, 0, 5_000),
              maxOracleDeviationBps: d.int(o, 'maxOracleDeviationBps', p, 200, 5_000),
              bandMarginBps: d.int(o, 'bandMarginBps', p, 50, 5_000),
              refreshDriftBps: d.int(o, 'refreshDriftBps', p, 50, 5_000),
              maxReferenceAgeSeconds: d.int(o, 'maxReferenceAgeSeconds', p, 300),
              oracleStaleMarginSeconds: d.int(o, 'oracleStaleMarginSeconds', p, 300),
              minPriceBrlCentsPerUnit: d.big(o, 'minPriceBrlCentsPerUnit', p, { optional: true }),
            },
            refillBelowBps: d.int(o, 'refillBelowBps', p, 5_000, 10_000),
            maxOfferBrlCents: d.big(o, 'maxOfferBrlCents', p, { optional: true }),
            gasReserveWei: d.big(o, 'gasReserveWei', p, { optional: true }),
            price: d.price(o, p),
          };
          if (s.minOrder === 0n || s.maxOrder < s.minOrder) problems.push(`${p}: need 0 < minOrder <= maxOrder`);
          if (s.pricing.minSpreadBps > s.pricing.spreadBps) problems.push(`${p}: minSpreadBps cannot exceed spreadBps`);
          return s;
        }),
      };
    }
  }

  if (raw.offramp !== undefined) {
    const off = d.obj(raw.offramp, 'config.offramp');
    if (off) {
      const rails = Array.isArray(off.rails) ? off.rails : ['PIX'];
      const bankRails = rails.filter((r): r is BankRail => r === 'PIX' || r === 'BOLETO');
      if (bankRails.length !== rails.length || bankRails.length === 0) problems.push('config.offramp.rails must be a non-empty list of PIX, BOLETO');
      const assets = Array.isArray(off.assets) ? off.assets : [];
      if (assets.length === 0) problems.push('config.offramp.assets must list at least one asset');
      cfg.offramp = {
        escrow: d.address(off, 'escrow', 'config.offramp'),
        rails: bankRails,
        maxOpenClaims: d.int(off, 'maxOpenClaims', 'config.offramp', 2),
        minTimeToPaySeconds: d.int(off, 'minTimeToPaySeconds', 'config.offramp', 20 * 60),
        disputeMarginSeconds: d.int(off, 'disputeMarginSeconds', 'config.offramp', 7 * 60),
        bankClockSkewSeconds: d.int(off, 'bankClockSkewSeconds', 'config.offramp', 5),
        raiseDisputeWhenUnproven: d.bool(off, 'raiseDisputeWhenUnproven', 'config.offramp', true),
        dailyBudgetCents: d.big(off, 'dailyBudgetCents', 'config.offramp', { optional: true }),
        assets: assets.map((a, i) => {
          const p = `config.offramp.assets[${i}]`;
          const o = d.obj(a, p) ?? {};
          return {
            asset: d.address(o, 'asset', p),
            symbol: d.string(o, 'symbol', p),
            pricing: {
              minMarginBps: d.int(o, 'minMarginBps', p, undefined, 5_000),
              maxOracleDeviationBps: d.int(o, 'maxOracleDeviationBps', p, 200, 5_000),
              maxReferenceAgeSeconds: d.int(o, 'maxReferenceAgeSeconds', p, 300),
              oracleStaleMarginSeconds: d.int(o, 'oracleStaleMarginSeconds', p, 300),
            },
            minSaleBrlCents: d.big(o, 'minSaleBrlCents', p, { fallback: 1n }) ?? 1n,
            maxSaleBrlCents: d.big(o, 'maxSaleBrlCents', p) ?? 0n,
            price: d.price(o, p),
          };
        }),
      };
      if (cfg.offramp.disputeMarginSeconds >= cfg.offramp.minTimeToPaySeconds) {
        problems.push('config.offramp.disputeMarginSeconds must be below minTimeToPaySeconds, or every payment would be disputed');
      }
    }
  }
  if (raw.arbitration !== undefined) {
    const a = d.obj(raw.arbitration, 'config.arbitration') ?? {};
    const url = d.string(a, 'url', 'config.arbitration');
    if (url && !/^https?:\/\//.test(url)) problems.push('config.arbitration.url must be an http(s) URL');
    cfg.arbitration = { url };
  }
  if (raw.webhook !== undefined) {
    const w = d.obj(raw.webhook, 'config.webhook') ?? {};
    if (w.auth === 'hmac') {
      // A secret, so from the environment or a file, never the strategy file.
      const s = secret('PIX_WEBHOOK_SECRET', 'the shared secret the PIX webhook is signed with', /^.{32,}$/s, 'must be at least 32 characters');
      cfg.webhook = { auth: 'hmac', secret: s };
    } else if (w.auth === 'proxy-mtls') {
      cfg.webhook = {
        auth: 'proxy-mtls',
        header: d.string(w, 'proxyHeader', 'config.webhook', 'x-ssl-client-verify'),
        value: d.string(w, 'proxyValue', 'config.webhook', 'SUCCESS'),
      };
    } else {
      problems.push('config.webhook.auth must be "hmac" or "proxy-mtls"');
    }
    if (!raw.onramp) problems.push('config.webhook: the PIX webhook only speeds up on-ramp matching; enable onramp or remove it');
  }
  if (raw.gateway !== undefined) cfg.gateway = gatewaySettings(d, raw.gateway, problems);
  if (raw.caps !== undefined) cfg.caps = capsSettings(d, raw.caps, payerRefSecret as Hex, problems);
  if (cfg.tierModule && !cfg.caps) problems.push('TIER_MODULE names a source of per-payer tiers, and there is no config.caps for it to tier anything in');
  if (raw.rewards !== undefined) {
    const r = d.obj(raw.rewards, 'config.rewards') ?? {};
    cfg.rewards = {
      contract: d.address(r, 'contract', 'config.rewards'),
      claim: d.bool(r, 'claim', 'config.rewards', true),
      minClaim: d.big(r, 'minClaim', 'config.rewards', { fallback: 0n }) ?? 0n,
      lookbackEpochs: d.int(r, 'lookbackEpochs', 'config.rewards', 12, 104),
    };
    if (r.to !== undefined) cfg.rewards.to = d.address(r, 'to', 'config.rewards');
    if (cfg.rewards.lookbackEpochs < 1) problems.push('config.rewards.lookbackEpochs must be from 1 to 104');
    if (sameAddress(cfg.rewards.contract, cfg.registry)) problems.push('config.rewards.contract is the registry: name the NodeRewards contract');
  }
  if (raw.tx !== undefined) {
    const t = d.obj(raw.tx, 'config.tx') ?? {};
    cfg.tx = {
      replaceAfterBlocks: d.int(t, 'replaceAfterBlocks', 'config.tx', 3, 1_000),
      bumpBps: d.int(t, 'bumpBps', 'config.tx', 1_250, 10_000),
      // A cap is the point of this section: it is stated, never defaulted.
      maxFeePerGasWei: d.big(t, 'maxFeePerGasWei', 'config.tx'),
      maxPriorityFeePerGasWei: d.big(t, 'maxPriorityFeePerGasWei', 'config.tx', { optional: true }),
      waitBlocks: d.int(t, 'waitBlocks', 'config.tx', 30, 10_000),
      gasHeadroomPercent: d.int(t, 'gasHeadroomPercent', 'config.tx', DEFAULT_GAS_HEADROOM_PERCENT, 100),
    };
    if (cfg.tx.bumpBps < 1_000) problems.push('config.tx.bumpBps must be at least 1000: nodes refuse a replacement that raises fees by less than 10%');
    if (cfg.tx.maxFeePerGasWei === 0n) problems.push('config.tx.maxFeePerGasWei must be above zero');
  }
  // `par` is a definition of Movva, not a price: on any other asset it would quote R$ 1,00 for it.
  for (const [leg, assets] of [['onramp', cfg.onramp?.assets ?? []], ['offramp', cfg.offramp?.assets ?? []]] as const) {
    assets.forEach((a, i) => {
      if (a.price.source === 'par' && !(cfg.gateway && sameAddress(a.asset, cfg.gateway.movva))) {
        problems.push(`config.${leg}.assets[${i}].price: "par" is only for the gateway's Movva (config.gateway.movva)`);
      }
    });
  }
  if (!cfg.onramp && !cfg.offramp) problems.push('config must enable onramp, offramp, or both');
  if (problems.length) throw new ConfigError(problems);

  // Everything secret-shaped in the environment is redacted, not only what this file reads: a
  // bank plugin's credentials arrive the same way.
  cfg.secrets = [
    rpcUrl, key, payerRefSecret, ...(cfg.webhook?.auth === 'hmac' ? [cfg.webhook.secret] : []),
    ...(cfg.devProvers?.zktls?.keys ?? []),
    ...Object.entries(env).filter(([k, v]) => SECRET_NAME.test(k) && !k.endsWith('_FILE') && !!v && v.length >= 8).map(([, v]) => v!),
  ];
  return cfg;
}
