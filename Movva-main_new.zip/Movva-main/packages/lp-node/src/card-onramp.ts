/**
 * The card leg of an on-ramp order: checkout, capture, proof, release - and giving card money back.
 *
 * ## What is different about a card
 *
 * A PIX credit is final when it lands; a card charge is a promise the acquirer can still unwind, and
 * the cardholder's bank can reverse months later. The contracts put that risk on the institutional card
 * partner (SR2-32), and the attestor signs only a CAPTURED charge, for the offer's merchant, for exactly
 * the order plus the card fee. What the node adds:
 *
 *  - **The card fee is a charge of its own, never part of the price.** A card offer is priced like the
 *    LP's PIX offer. The cardholder pays the order plus `cardFee(brlCents, feeBps)` (rounded up, the one
 *    rounding in @mova/ramp), and `feeBps` is inside the offer's merchant commitment: the node journals
 *    it with the offer's salt and uses THAT fee for every checkout, instruction and proof on the offer,
 *    whatever the configuration says later, because only that fee opens the commitment.
 *  - **A checkout only for a lock N blocks deep**, as for a boleto: a checkout is a document a cardholder
 *    can pay, and one created for a lock that is then reorged away charges a card for nothing. It is
 *    created under a key derived from the order id, recorded before the call, so a crash between the
 *    acquirer creating it and the journal recording it gets the SAME checkout back on restart.
 *    It is for the order's total (amount plus fee), with the order id as its reference, and it expires
 *    `checkoutMarginSeconds` before `payBy`: a charge captured at the deadline could not be proven before it.
 *  - **Matching by reference only.** A capture is this order's only if the acquirer reports this order id
 *    as its reference, this merchant, exactly the order's total, CAPTURED, after the lock, and not already
 *    used. An authorisation is waited on, never proven; a partial capture, or the order without its fee,
 *    never matches.
 *  - **Every other charge goes back.** When the order ends without releasing - cancelled, expired, or a
 *    lock a reorg erased - and that is N blocks deep, every authorisation is voided and every capture
 *    refunded. When it released, every charge but the one that proved it goes back too (a second payment
 *    of the same checkout, a stray authorisation). Each reversal's intent and key are fsynced before the
 *    acquirer is called; a restart asks `getReversal(key)` and repeats under that key, so card money goes
 *    back at most once. A reversal is always of the whole charge, fee included: the fee bought nothing either. The order is followed until `lateCreditGraceSeconds` after `payBy`, so a charge the
 *    acquirer lets through late is still found and returned.
 *  - **Per-payer caps** (caps.ts), when configured, are decided at the capture - the acquirer's payer id is
 *    the first thing that names the cardholder - and before `attestCard`. Over the cap, nothing is attested,
 *    the order expires and the whole charge goes back through the machinery above, which gives the
 *    cardholder's allowance back with it.
 */
import type { Address, Hex } from 'viem';
import { encodeAbiParameters, keccak256 } from 'viem';
import { Rail, cardCheckoutTotal, type ObservedCardCapture } from '@mova/ramp';
import { OrderState } from './abi.js';
import { payerRef } from './attestation.js';
import type { CardCharge } from './card.js';
import type { CapTrack } from './store.js';
import { ChainRevert, type OnChainOffer, type OnChainOrder } from './chain.js';
import { errorText, short, type NodeContext, type TickView } from './context.js';
import { idempotencyKey, type OrderTrack } from './store.js';

export const CARD_BIT = 1 << Rail.CARD;
export const isCardOffer = (offer: Pick<OnChainOffer, 'railMask'>): boolean => offer.railMask === CARD_BIT;

export interface CardOnrampOptions {
  /** The merchant account at its acquirer that every card offer commits to. */
  acquirerId: string;
  merchantId: string;
  /**
   * The fee charged to the cardholder on top of each order, in whole basis points (0-1000), committed in every
   * card offer posted from now on. Not the acquirer's MDR the partner pays: that is its cost, to cover with
   * this fee or its spreads. A change closes the live card offer and posts one committed to the new fee.
   */
  feeBps: number;
  /** A checkout expires this long before the order's `payBy`. */
  checkoutMarginSeconds: number;
  /** The acquirer's per-charge limit: a card offer's `maxOrder` never makes a charge, fee included, exceed it. */
  maxChargeBrlCents?: bigint;
}

/** The largest order whose checkout total, fee included, fits in one charge of `maxChargeCents`. */
export function maxOrderCentsForCharge(maxChargeCents: bigint, feeBps: number): bigint {
  let cents = (maxChargeCents * 10_000n) / (10_000n + BigInt(feeBps));
  // Exact by the arithmetic; checked against the shared rounding anyway, since a centavo over is a refused charge.
  while (cents > 0n && cardCheckoutTotal(cents, feeBps) > maxChargeCents) cents--;
  return cents;
}

/** A charge the acquirer still holds as money or a hold, and so can give back. */
const reversible = (c: CardCharge) => c.status === 'AUTHORIZED' || c.status === 'CAPTURED';

export class CardOrders {
  private readonly warned = new Set<string>();

  constructor(
    private readonly ctx: NodeContext,
    private readonly o: { escrow: Address; card?: CardOnrampOptions; lateCreditGraceSeconds: number },
  ) {}

  private get card(): CardOnrampOptions {
    if (!this.o.card) throw new Error('a card order, and no onramp.card configured');
    return this.o.card;
  }

  /*//////////////////////////////////////////////////////////////
                                 LOCKED
  //////////////////////////////////////////////////////////////*/

  async locked(t: OrderTrack, ord: OnChainOrder, offer: OnChainOffer, view: TickView): Promise<'hold' | void> {
    const { chain, store, acquirer, metrics, log } = this.ctx;
    if (!acquirer || !this.o.card) return this.hold(t, 'a card order was locked, but this node has no card acquirer configured');
    const feeBps = store.cardFeeFor(offer.pixKeyHash);
    if (feeBps === undefined) {
      // Posted before fees were committed (v1), or not by this node: no attestor opens its commitment, so a
      // checkout would charge a card for an order nobody can prove. It expires, and nothing was charged.
      return this.hold(t, 'the card offer\'s fee is not in the journal (an offer from before card fees were committed?): no checkout is created, it will expire');
    }
    const total = cardCheckoutTotal(ord.brlCents, feeBps);

    if (!t.card?.checkoutId) {
      // Nothing a cardholder can pay exists until the lock survives the reorg window.
      const confirmed = await chain.order(t.orderId, view.confirmedBlock);
      if (confirmed.state !== OrderState.LOCKED) return;
      const expiresAt = ord.payBy - BigInt(this.card.checkoutMarginSeconds);
      if (view.chainNow >= expiresAt) return; // too late to pay and prove: let it expire
      if (!t.card) {
        store.record({ t: 'order.card.intent', orderId: t.orderId, idempotencyKey: idempotencyKey('order-card', chain.chainId, this.o.escrow, t.orderId) });
      }
      const key = store.getOrder(t.orderId)!.card!.idempotencyKey;
      let checkout;
      try {
        checkout = await acquirer.createCheckout({ idempotencyKey: key, amountCents: total, expiresAt, reference: t.orderId });
      } catch (e) {
        metrics.inc('mova_lp_card_errors_total', { op: 'createCheckout' });
        throw e;
      }
      if (checkout.amountCents !== total || checkout.reference.toLowerCase() !== t.orderId.toLowerCase() || checkout.expiresAt > expiresAt) {
        await acquirer.cancelCheckout(checkout.checkoutId).catch(() => undefined);
        return this.hold(t, 'the acquirer returned a checkout for another amount, reference or expiry than the order\'s total; cancelled it');
      }
      store.record({
        t: 'order.card.checkout', orderId: t.orderId, checkoutId: checkout.checkoutId, url: checkout.url,
        expiresAt: checkout.expiresAt, amountCents: checkout.amountCents,
      });
      metrics.inc('mova_lp_card_checkouts_total');
      log.info(`on-ramp: card checkout ready for ${short(t.orderId)}`);
    }

    let track = store.getOrder(t.orderId)!;
    if (!track.card!.capture) {
      const capture = (await this.charges(t.orderId)).find((c) => this.matches(c, t.orderId, ord, total));
      if (!capture) return;
      store.record({ t: 'order.card.capture', orderId: t.orderId, charge: capture });
      metrics.inc('mova_lp_card_captures_total');
      log.info(`on-ramp: card capture of ${capture.amountCents} centavos matched to ${short(t.orderId)}`);
      track = store.getOrder(t.orderId)!;
    }
    // The cardholder is known only at the capture, and the acquirer's payer id is what names them. Refused,
    // the capture is never attested: the order expires and `ended` gives the whole charge - fee included - back.
    if (!(await this.capAllows(track, view))) return;
    if (!track.releasedTx) await this.release(store.getOrder(t.orderId)!, ord, offer, feeBps);
  }

  /** The per-payer cap for a card order, decided once at its capture and fsynced. See caps.ts. */
  private async capAllows(t: OrderTrack, view: TickView): Promise<boolean> {
    const { caps, store, log } = this.ctx;
    const charge = t.card?.capture;
    if (!caps || !charge) return true;
    const decided: CapTrack | undefined = store.getOrder(t.orderId)?.cap;
    if (decided?.refused) return false;
    if (decided?.counted) return true;
    const verdict = await caps.check({ leg: 'onramp', rail: 'CARD', payerId: charge.payerId }, charge.amountCents, view.wallNow);
    if (!verdict.ok) {
      store.record({ t: 'order.cap', orderId: t.orderId, decision: 'refused', day: verdict.day, period: verdict.period });
      log.warn(`on-ramp: card order ${short(t.orderId)} is not released: ${verdict.period === 'unknown_payer'
        ? 'the acquirer named no cardholder, and this node applies per-payer caps'
        : `the cardholder's ${verdict.period === 'day' ? 'daily' : 'monthly'} limit of ${verdict.limitCents} centavos is reached`}`
        + '; the charge is returned in full');
      return false;
    }
    if (!verdict.payer) return true; // nobody to hold it against; see caps.ts
    // The charge is the order plus its card fee: what the person actually paid is what counts.
    const day = caps.count(verdict.payer, charge.amountCents, view.wallNow, 'onramp');
    store.record({ t: 'order.cap', orderId: t.orderId, decision: 'counted', day, cents: charge.amountCents });
    return true;
  }

  /** This order's capture, and nothing else's: see the header. `total` is the order plus its card fee. */
  private matches(c: CardCharge, orderId: Hex, ord: OnChainOrder, total: bigint): boolean {
    const why = c.reference.toLowerCase() !== orderId.toLowerCase() ? undefined
      : c.acquirerId !== this.card.acquirerId || c.merchantId !== this.card.merchantId ? 'captured for another merchant account'
        : c.status === 'AUTHORIZED' ? 'authorised, not yet captured'
          : c.status !== 'CAPTURED' ? `${c.status.toLowerCase()}`
            : c.amountCents !== total ? `captured ${c.amountCents} for an order of ${ord.brlCents} whose total with the card fee is ${total}`
              : c.capturedAt === undefined || c.capturedAt < ord.lockedAt ? 'captured before the lock'
                : this.ctx.store.consumedCaptures.has(c.transactionId) ? 'already used for another order'
                  : '';
    if (why === '') return true;
    if (why) this.once(`nomatch:${orderId}:${c.transactionId}:${c.status}`, () => this.ctx.log.warn(`on-ramp: a charge for ${short(orderId)} does not prove it: ${why}`));
    return false;
  }

  private async release(t: OrderTrack, ord: OnChainOrder, offer: OnChainOffer, feeBps: number): Promise<'hold' | void> {
    const { chain, store, provers, metrics, log } = this.ctx;
    const charge = t.card!.capture!;
    const prover = provers.get(offer.verifier.toLowerCase());
    if (!prover?.proveCard || !prover.rails.includes(Rail.CARD)) {
      return this.hold(t, 'captured, but no prover for this verifier attests card payments; it will expire and be refunded');
    }
    const salt = store.saltFor(offer.pixKeyHash);
    if (!salt) return this.hold(t, 'the card offer\'s salt is not in the journal: this node did not post it');
    const seen: ObservedCardCapture = {
      acquirerId: charge.acquirerId, transactionId: charge.transactionId, merchantId: charge.merchantId, salt, feeBps,
      payerRef: payerRef(charge.payerId, this.ctx.payerRefSecret), status: 'CAPTURED',
      capturedAmountBrlCents: charge.amountCents, capturedAt: charge.capturedAt!,
    };
    let proof: Hex;
    try {
      proof = await prover.proveCard({
        orderId: t.orderId, payeeKeyHash: offer.pixKeyHash, brlCents: ord.brlCents, lockedAt: ord.lockedAt, acceptedRails: [Rail.CARD],
      }, seen);
    } catch (e) {
      metrics.inc('mova_lp_proof_failures_total', { leg: 'onramp' });
      log.warn(`on-ramp: no card proof yet for ${short(t.orderId)}: ${errorText(e)}`);
      return;
    }
    try {
      const r = await chain.releaseWithProof(t.orderId, proof);
      store.record({ t: 'order.released', orderId: t.orderId, tx: r.hash });
      metrics.inc('mova_lp_onramp_released_total');
      log.info(`on-ramp: released card order ${short(t.orderId)} in block ${r.blockNumber}`);
    } catch (e) {
      if (e instanceof ChainRevert && e.errorName === 'WrongState') return;
      throw e;
    }
  }

  /*//////////////////////////////////////////////////////////////
                         GIVING CARD MONEY BACK
  //////////////////////////////////////////////////////////////*/

  /**
   * The order ended; `released` says how. Returns true once nothing more can come back for it: every
   * charge but the proving one reversed and final, and the late-charge grace over.
   */
  async ended(t: OrderTrack, ord: OnChainOrder, released: boolean, view: TickView): Promise<boolean> {
    const { acquirer, store } = this.ctx;
    if (!acquirer || !this.o.card) {
      this.hold(t, 'a card order ended, but this node has no card acquirer configured to return charges');
      return false;
    }
    if (t.card?.checkoutId && !t.card.cancelled && !released) {
      await acquirer.cancelCheckout(t.card.checkoutId);
      store.record({ t: 'order.card.cancelled', orderId: t.orderId });
    }
    const keep = released ? t.card?.capture?.transactionId : undefined;
    let settled = true;
    for (const c of await this.charges(t.orderId)) {
      if (c.transactionId === keep) continue;
      if (c.acquirerId !== this.card.acquirerId || c.merchantId !== this.card.merchantId) continue; // not ours to reverse
      const prior = store.getOrder(t.orderId)!.card?.reversals[c.transactionId];
      if (!prior && !reversible(c)) continue; // voided, refunded or charged back already
      if (!(await this.reverse(t, c))) settled = false;
    }
    // Card money that went back did not consume anyone's allowance.
    if (settled && !released) this.uncount(t);
    return settled && view.chainNow > ord.payBy + BigInt(this.o.lateCreditGraceSeconds);
  }

  private uncount(t: OrderTrack): void {
    const { caps, store } = this.ctx;
    const cap = store.getOrder(t.orderId)?.cap;
    if (!caps || !cap?.counted || cap.uncounted) return;
    const payer = caps.identify(store.getOrder(t.orderId)?.card?.capture?.payerId);
    if (!payer) return;
    caps.uncount(payer, cap.counted.cents, cap.counted.day, 'onramp');
    store.record({ t: 'order.cap.uncounted', orderId: t.orderId });
  }

  /** One reversal per charge, under one key, intent first. True once it is final. */
  private async reverse(t: OrderTrack, c: CardCharge): Promise<boolean> {
    const { chain, store, acquirer, metrics, log } = this.ctx;
    if (!store.getOrder(t.orderId)!.card) {
      // A charge carrying this order's reference with no checkout of ours: still card money to give back.
      store.record({ t: 'order.card.intent', orderId: t.orderId, idempotencyKey: idempotencyKey('order-card', chain.chainId, this.o.escrow, t.orderId) });
    }
    let rev = store.getOrder(t.orderId)!.card!.reversals[c.transactionId];
    if (!rev) {
      const id = keccak256(encodeAbiParameters([{ type: 'bytes32' }, { type: 'string' }], [t.orderId, `${c.acquirerId}:${c.transactionId}`]));
      store.record({
        t: 'order.card.reversal.intent', orderId: t.orderId, transactionId: c.transactionId,
        idempotencyKey: idempotencyKey('card-reversal', chain.chainId, this.o.escrow, id), amountCents: c.amountCents,
      });
      rev = store.getOrder(t.orderId)!.card!.reversals[c.transactionId];
    }
    if (rev.result?.status === 'SETTLED') return true;
    if (rev.result?.status === 'FAILED') {
      this.hold(t, `the acquirer refused to return a charge on this order (${rev.result.failureReason ?? 'no reason given'}); return it by hand`);
      return false;
    }
    let result;
    try {
      result = (await acquirer!.getReversal(rev.idempotencyKey))
        ?? await acquirer!.reverse({ idempotencyKey: rev.idempotencyKey, transactionId: c.transactionId, amountCents: rev.amountCents, reason: 'Mova on-ramp order did not settle with this charge' });
    } catch (e) {
      metrics.inc('mova_lp_card_errors_total', { op: 'reverse' });
      throw e;
    }
    if (result.status === 'PENDING' && rev.result?.status === 'PENDING') return false;
    store.record({ t: 'order.card.reversal.result', orderId: t.orderId, transactionId: c.transactionId, result });
    metrics.inc('mova_lp_card_reversals_total', { status: result.status });
    if (result.status === 'SETTLED') log.info(`on-ramp: returned a ${c.status.toLowerCase()} card charge on ${short(t.orderId)} (${result.kind ?? 'reversal'})`);
    if (result.status === 'FAILED') this.hold(t, `the acquirer refused to return a charge on this order (${result.failureReason ?? 'no reason given'}); return it by hand`);
    return result.status === 'SETTLED';
  }

  private async charges(orderId: Hex): Promise<CardCharge[]> {
    try {
      return await this.ctx.acquirer!.chargesFor(orderId);
    } catch (e) {
      this.ctx.metrics.inc('mova_lp_card_errors_total', { op: 'chargesFor' });
      throw e;
    }
  }

  private hold(t: OrderTrack, reason: string): 'hold' {
    if (this.ctx.store.getOrder(t.orderId)?.hold !== reason) {
      this.ctx.store.record({ t: 'order.hold', orderId: t.orderId, reason });
      this.ctx.log.error(`on-ramp: HOLD ${short(t.orderId)}: ${reason}`);
    }
    return 'hold';
  }

  private once(key: string, fn: () => void): void {
    if (this.warned.has(key)) return;
    this.warned.add(key);
    fn();
  }
}
