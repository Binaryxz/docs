/**
 * The receiving side of the Banco Central "API Pix" (spec 2.10.0, github.com/bacen/pix-api), as
 * a partial `BankAdapter`.
 *
 * ## What is standard, and what this therefore covers
 *
 * API Pix is what every PSP must expose to a RECEIVING user: immediate charges (`/cob`), the Pix
 * received (`/pix`, `/pix/{e2eid}`), refunds of them (`/pix/{e2eid}/devolucao/{id}`) and a webhook.
 * It does not initiate payments, pay boletos or register them - those are bank-specific (bank.ts)
 * - so `ApiPixReceiver` implements `listIncoming` and `refundIncoming`, and `composeBank` joins it
 * with the LP's own sending adapter into a full `BankAdapter`.
 *
 * Transcribed from the published OpenAPI document, not from any one PSP:
 *
 *  - **Auth.** OAuth2 client credentials (`securitySchemes.OAuth2.flows.clientCredentials`), scopes
 *    `pix.read`, `pix.write`, `cob.read`, `cob.write`, `webhook.read`, `webhook.write`. The token URL
 *    is the PSP's. The client authenticates with HTTP Basic (RFC 6749 §2.3.1), the method PSPs use.
 *    Every call - token included - goes over mTLS with the certificate the PSP issued, per the
 *    BCB's security manual; `tls` carries it.
 *  - **Base URL.** The spec's server is a placeholder (`https://pix.example.com/api/`) and its paths
 *    start at `/pix`; PSPs mount them under a version prefix. `baseUrl` includes it
 *    (`https://pix.psp.example/api/v2`).
 *  - **`GET /pix`** takes `inicio`/`fim` (RFC 3339, required) and pages with
 *    `paginacao.paginaAtual` (from 0) and `paginacao.itensPorPagina` (≤ 1000), answering
 *    `{ parametros: { paginacao: { quantidadeDePaginas, ... } }, pix: [...] }`.
 *  - **`Pix`**: `endToEndId` (32 alphanumerics), `txid`, `valor` (`\d{1,10}\.\d{2}`), `chave`,
 *    `horario` (the time the PSP processed it), `infoPagador`, `devolucoes`. **There is no payer
 *    document in it** - `payerId` stays undefined and payerRef is keyed on an empty id. A PSP that
 *    offers the payer's CPF/CNPJ does so outside the standard.
 *  - **Devolução**: `PUT` with a client-chosen `id` (`[a-zA-Z0-9]{1,35}`, the node's idempotency key)
 *    and `{ valor, natureza: "ORIGINAL", descricao ≤ 140 }`; status `EM_PROCESSAMENTO`, `DEVOLVIDO`
 *    or `NAO_REALIZADO`. The spec does not say what a second PUT with the same id returns, so the
 *    adapter GETs that id first and PUTs only on 404. Two concurrent refunds of one order inside that
 *    gap could both miss; the node never runs two (one tick at a time), which is the argument.
 *  - **Webhook**: registered with `PUT /webhook/{chave}` `{ webhookUrl }`; the PSP POSTs
 *    `{ "pix": [Pix, ...] }` to `webhookUrl` + `/pix`, authenticating with ITS client certificate
 *    (mTLS - terminate and verify it at the LP's reverse proxy). It fires only for Pix that carry a
 *    txid - which every BR Code the node serves does - and polling `/pix` remains the source of truth:
 *    a webhook is an early hint, and a missed one must cost only latency.
 *  - **Cob** (immediate charge): `PUT /cob/{txid}` `{ calendario: { expiracao }, valor: { original,
 *    modalidadeAlteracao: 0 }, chave }` answers `CobGerada` (201) with `location` and `pixCopiaECola`; the Manual de
 *    Padrões para Iniciação do Pix 2.10.0 (Annex I, footnote 85) calls a repeated PUT idempotent. `GET /cob/{txid}`
 *    answers `CobCompleta` (404 when none). `PATCH /cob/{txid}` `{ status: "REMOVIDA_PELO_USUARIO_RECEBEDOR" }`
 *    (`CobRevisada`) removes a charge; one `CONCLUIDA` "não se pode alterar e nem remover" (Annex I §6.5.2). The
 *    `CobStatus` enum spells `REMOVIDA_…` while its description and the manual's prose say `REMOVIDO_…`: both are
 *    read, the enum's is sent. `txid` is `[a-zA-Z0-9]{26,35}`, never reused by a receiver (Annex I §5.3.1).
 *  - **Errors** are RFC 7807 `Problema` `{ type, title, status, detail, correlationId, violacoes }`.
 *    `ApiPixError` keeps `type`, `title`, `status` and `correlationId`, never `detail` or `violacoes`,
 *    which echo submitted values (keys, amounts) into what would become a log line.
 */
import { Agent as HttpsAgent, request as httpsRequest } from 'node:https';
import { request as httpRequest, type IncomingHttpHeaders } from 'node:http';
import type { BankAdapter, IncomingPayment, OutgoingPaymentResult, PixCharge, PixChargeStatus } from './bank.js';

export interface ApiPixOptions {
  /** Including the PSP's version prefix, e.g. `https://pix.psp.example/api/v2`. */
  baseUrl: string;
  tokenUrl: string;
  clientId: string;
  clientSecret: string;
  scopes?: readonly string[];
  /** The mTLS client certificate and key the PSP issued, and the CA that signs its server. */
  tls?: { cert: string | Buffer; key: string | Buffer; ca?: string | Buffer };
  /** Items per `/pix` page; the spec caps it at 1000. */
  pageSize?: number;
  timeoutMs?: number;
  /** Milliseconds; for token expiry. */
  now?: () => number;
}

export class ApiPixError extends Error {
  constructor(
    readonly status: number,
    readonly problemType?: string,
    readonly title?: string,
    readonly correlationId?: string,
  ) {
    super(`API Pix ${status}${problemType ? ` ${problemType.split('/').pop()}` : ''}${title ? `: ${title}` : ''}`);
  }
}

/** The spec's `Pix`, as far as the node reads it. */
export interface ApiPixPix {
  endToEndId: string;
  txid?: string;
  valor: string;
  chave?: string;
  horario: string;
  infoPagador?: string;
}

export interface ApiPixDevolucao {
  id: string;
  rtrId: string;
  valor: string;
  horario: { solicitacao?: string; liquidacao?: string };
  status: 'EM_PROCESSAMENTO' | 'DEVOLVIDO' | 'NAO_REALIZADO';
  motivo?: string;
}

export interface ApiPixCob {
  txid: string;
  revisao: number;
  /** The OpenAPI enum spells `REMOVIDA_…`, the manual's prose `REMOVIDO_…`: both are read. */
  status: 'ATIVA' | 'CONCLUIDA' | 'REMOVIDA_PELO_USUARIO_RECEBEDOR' | 'REMOVIDA_PELO_PSP' | 'REMOVIDO_PELO_USUARIO_RECEBEDOR' | 'REMOVIDO_PELO_PSP';
  calendario: { criacao: string; expiracao: number };
  valor: { original: string; modalidadeAlteracao?: number };
  chave: string;
  location?: string;
  loc?: { id: number; location: string; tipoCob: 'cob' | 'cobv'; criacao?: string };
  pixCopiaECola?: string;
  pix?: ApiPixPix[];
}

const VALOR = /^\d{1,10}\.\d{2}$/;
const E2E = /^[a-zA-Z0-9]{32}$/;
const ID = /^[a-zA-Z0-9]{1,35}$/;
const COB_TXID = /^[a-zA-Z0-9]{26,35}$/;

/** Centavos to the spec's `valor`. */
export function toValor(cents: bigint): string {
  if (cents < 0n || cents > 9_999_999_999_99n) throw new Error('amount out of range for API Pix');
  return `${cents / 100n}.${(cents % 100n).toString().padStart(2, '0')}`;
}

/** The spec's `valor` to centavos; anything else is refused, not rounded. */
export function fromValor(valor: string): bigint {
  if (!VALOR.test(valor)) throw new Error('malformed valor');
  const [int, frac] = valor.split('.');
  return BigInt(int) * 100n + BigInt(frac);
}

const seconds = (rfc3339: string): bigint => {
  const ms = Date.parse(rfc3339);
  if (Number.isNaN(ms)) throw new Error('malformed horario');
  return BigInt(Math.floor(ms / 1000));
};

/** A `Pix` as the node's `IncomingPayment`. Throws on a record that breaks the spec's patterns. */
export function pixToIncoming(p: ApiPixPix): IncomingPayment {
  if (!E2E.test(p.endToEndId)) throw new Error('malformed endToEndId');
  return {
    rail: 'PIX',
    bankTxId: p.endToEndId,
    amountCents: fromValor(p.valor),
    paidAt: seconds(p.horario),
    creditedKey: p.chave,
    txid: p.txid,
    // API Pix 2.10.0 carries no payer document; infoPagador is the payer's free text, not an id.
    payerId: undefined,
  };
}

/**
 * The body a PSP POSTs to `webhookUrl/pix`. Records that do not match the schema are dropped rather
 * than failing the batch: one malformed entry must not hide the others, and polling will see them.
 */
export function parseWebhookPix(body: unknown): IncomingPayment[] {
  if (!body || typeof body !== 'object' || !Array.isArray((body as { pix?: unknown }).pix)) {
    throw new Error('not an API Pix webhook body');
  }
  const out: IncomingPayment[] = [];
  for (const raw of (body as { pix: unknown[] }).pix) {
    try {
      out.push(pixToIncoming(raw as ApiPixPix));
    } catch {
      // dropped; see above
    }
  }
  return out;
}

interface Response { status: number; headers: IncomingHttpHeaders; body: string }

export class ApiPixClient {
  private token?: { value: string; expiresAt: number };
  private readonly agent?: HttpsAgent;

  constructor(private readonly o: ApiPixOptions) {
    if (o.tls) {
      this.agent = new HttpsAgent({ cert: o.tls.cert, key: o.tls.key, ca: o.tls.ca, keepAlive: true });
    }
  }

  private now(): number {
    return this.o.now ? this.o.now() : Date.now();
  }

  private send(method: string, url: URL, headers: Record<string, string>, body?: string): Promise<Response> {
    return new Promise((resolve, reject) => {
      const https = url.protocol === 'https:';
      const req = (https ? httpsRequest : httpRequest)(url, {
        method, headers: { ...headers, ...(body !== undefined ? { 'content-length': String(Buffer.byteLength(body)) } : {}) },
        ...(https && this.agent ? { agent: this.agent } : {}),
        timeout: this.o.timeoutMs ?? 15_000,
      }, (res) => {
        const chunks: Buffer[] = [];
        res.on('data', (c: Buffer) => chunks.push(c));
        res.on('end', () => resolve({ status: res.statusCode ?? 0, headers: res.headers, body: Buffer.concat(chunks).toString('utf8') }));
        res.on('error', reject);
      });
      req.on('timeout', () => req.destroy(new Error('API Pix request timed out')));
      req.on('error', reject);
      if (body !== undefined) req.write(body);
      req.end();
    });
  }

  private async accessToken(force = false): Promise<string> {
    if (!force && this.token && this.token.expiresAt > this.now()) return this.token.value;
    const basic = Buffer.from(`${this.o.clientId}:${this.o.clientSecret}`).toString('base64');
    const form = new URLSearchParams({ grant_type: 'client_credentials' });
    const scopes = this.o.scopes ?? ['pix.read', 'pix.write', 'cob.read', 'cob.write', 'webhook.read', 'webhook.write'];
    if (scopes.length) form.set('scope', scopes.join(' '));
    const res = await this.send('POST', new URL(this.o.tokenUrl), {
      authorization: `Basic ${basic}`, 'content-type': 'application/x-www-form-urlencoded', accept: 'application/json',
    }, form.toString());
    if (res.status !== 200) throw new ApiPixError(res.status, undefined, 'token request refused');
    const j = JSON.parse(res.body) as { access_token?: unknown; expires_in?: unknown; token_type?: unknown };
    if (typeof j.access_token !== 'string') throw new ApiPixError(res.status, undefined, 'token response without access_token');
    const ttl = typeof j.expires_in === 'number' ? j.expires_in : 300;
    // Renew a minute early, so a token never expires between being read and being used.
    this.token = { value: j.access_token, expiresAt: this.now() + Math.max(0, ttl - 60) * 1000 };
    return this.token.value;
  }

  /** One API call, retrying once with a fresh token on 401. */
  async call<T>(method: 'GET' | 'PUT' | 'POST' | 'PATCH', path: string, o: { query?: Record<string, string>; body?: unknown } = {}): Promise<{ status: number; data: T }> {
    const url = new URL(this.o.baseUrl.replace(/\/$/, '') + path);
    for (const [k, v] of Object.entries(o.query ?? {})) url.searchParams.set(k, v);
    const body = o.body === undefined ? undefined : JSON.stringify(o.body);
    for (let attempt = 0; attempt < 2; attempt++) {
      const token = await this.accessToken(attempt > 0);
      const res = await this.send(method, url, {
        authorization: `Bearer ${token}`, accept: 'application/json',
        ...(body !== undefined ? { 'content-type': 'application/json' } : {}),
      }, body);
      if (res.status === 401 && attempt === 0) continue;
      if (res.status >= 200 && res.status < 300) {
        return { status: res.status, data: (res.body ? JSON.parse(res.body) : undefined) as T };
      }
      let problem: { type?: string; title?: string; correlationId?: string } = {};
      try { problem = JSON.parse(res.body) as typeof problem; } catch { /* not a Problema */ }
      throw new ApiPixError(res.status, problem.type, problem.title, problem.correlationId);
    }
    throw new ApiPixError(401, undefined, 'unauthorised after refreshing the token');
  }

  /** Every Pix received in [inicio, fim], all pages. */
  async listPix(q: { inicio: Date; fim: Date; txid?: string }): Promise<ApiPixPix[]> {
    const out: ApiPixPix[] = [];
    const size = Math.min(Math.max(this.o.pageSize ?? 100, 1), 1000);
    for (let page = 0; ; page++) {
      const { data } = await this.call<{ parametros: { paginacao: { quantidadeDePaginas: number } }; pix?: ApiPixPix[] }>('GET', '/pix', {
        query: {
          inicio: q.inicio.toISOString(), fim: q.fim.toISOString(),
          ...(q.txid ? { txid: q.txid } : {}),
          'paginacao.paginaAtual': String(page), 'paginacao.itensPorPagina': String(size),
        },
      });
      out.push(...(data.pix ?? []));
      if (page + 1 >= (data.parametros?.paginacao?.quantidadeDePaginas ?? 0)) return out;
    }
  }

  async getPix(e2eid: string): Promise<ApiPixPix> {
    if (!E2E.test(e2eid)) throw new Error('malformed endToEndId');
    return (await this.call<ApiPixPix>('GET', `/pix/${e2eid}`)).data;
  }

  async getDevolucao(e2eid: string, id: string): Promise<ApiPixDevolucao | undefined> {
    if (!E2E.test(e2eid) || !ID.test(id)) throw new Error('malformed endToEndId or devolução id');
    try {
      return (await this.call<ApiPixDevolucao>('GET', `/pix/${e2eid}/devolucao/${id}`)).data;
    } catch (e) {
      if (e instanceof ApiPixError && e.status === 404) return undefined;
      throw e;
    }
  }

  async putDevolucao(e2eid: string, id: string, b: { valor: string; descricao?: string }): Promise<ApiPixDevolucao> {
    if (!E2E.test(e2eid) || !ID.test(id)) throw new Error('malformed endToEndId or devolução id');
    const body = { valor: b.valor, natureza: 'ORIGINAL', ...(b.descricao ? { descricao: b.descricao.slice(0, 140) } : {}) };
    return (await this.call<ApiPixDevolucao>('PUT', `/pix/${e2eid}/devolucao/${id}`, { body })).data;
  }

  /**
   * An immediate charge (`PUT /cob/{txid}`): a dynamic BR Code for exactly one amount, which the PSP
   * refuses to settle twice (status CONCLUIDA). What the node serves per order with `pixCharge: "cob"`,
   * instead of its static code. `txid` is 26-35 alphanumerics.
   */
  async putCob(txid: string, b: { amountCents: bigint; chave: string; expiracaoSeconds: number; solicitacaoPagador?: string }): Promise<ApiPixCob> {
    if (!COB_TXID.test(txid)) throw new Error('a cob txid is 26-35 letters and digits');
    const body = {
      calendario: { expiracao: b.expiracaoSeconds },
      valor: { original: toValor(b.amountCents), modalidadeAlteracao: 0 },
      chave: b.chave,
      ...(b.solicitacaoPagador ? { solicitacaoPagador: b.solicitacaoPagador.slice(0, 140) } : {}),
    };
    return (await this.call<ApiPixCob>('PUT', `/cob/${txid}`, { body })).data;
  }

  async getCob(txid: string): Promise<ApiPixCob> {
    if (!COB_TXID.test(txid)) throw new Error('a cob txid is 26-35 letters and digits');
    return (await this.call<ApiPixCob>('GET', `/cob/${txid}`)).data;
  }

  /** `PATCH /cob/{txid}` (`CobRevisada`). The only revision the node makes is removal. */
  async patchCob(txid: string, b: { status: 'REMOVIDA_PELO_USUARIO_RECEBEDOR' }): Promise<ApiPixCob> {
    if (!COB_TXID.test(txid)) throw new Error('a cob txid is 26-35 letters and digits');
    return (await this.call<ApiPixCob>('PATCH', `/cob/${txid}`, { body: { status: b.status } })).data;
  }

  /** Point the PSP's notifications for `chave` at `webhookUrl` (it will POST to `webhookUrl/pix`). */
  async putWebhook(chave: string, webhookUrl: string): Promise<void> {
    await this.call('PUT', `/webhook/${encodeURIComponent(chave)}`, { body: { webhookUrl } });
  }
}

const DEVOLUCAO_STATUS: Record<ApiPixDevolucao['status'], OutgoingPaymentResult['status']> = {
  DEVOLVIDO: 'SETTLED', EM_PROCESSAMENTO: 'PENDING', NAO_REALIZADO: 'FAILED',
};

const COB_STATUS: Record<string, PixChargeStatus> = {
  ATIVA: 'ATIVA', CONCLUIDA: 'CONCLUIDA',
  REMOVIDA_PELO_USUARIO_RECEBEDOR: 'REMOVIDA_PELO_USUARIO_RECEBEDOR', REMOVIDO_PELO_USUARIO_RECEBEDOR: 'REMOVIDA_PELO_USUARIO_RECEBEDOR',
  REMOVIDA_PELO_PSP: 'REMOVIDA_PELO_PSP', REMOVIDO_PELO_PSP: 'REMOVIDA_PELO_PSP',
};

/** A `CobGerada` or `CobCompleta` as the node's `PixCharge`. Throws on a record that breaks the schema. */
export function cobToCharge(c: ApiPixCob): PixCharge {
  const status = COB_STATUS[c.status];
  if (!status) throw new Error('unknown cob status');
  if (!COB_TXID.test(c.txid)) throw new Error('malformed cob txid');
  if (!Number.isSafeInteger(c.revisao) || c.revisao < 0) throw new Error('malformed cob revisao');
  const raw = c.calendario?.expiracao as unknown;
  // `expiracao` defaults to 86400 (CobExpiracao); an integer, though the spec's own example JWS writes it as a string.
  const expiracao = raw === undefined ? 86_400 : typeof raw === 'string' && /^\d{1,9}$/.test(raw) ? Number(raw) : raw;
  if (typeof expiracao !== 'number' || !Number.isSafeInteger(expiracao) || expiracao <= 0) throw new Error('malformed calendario.expiracao');
  const createdAt = seconds(c.calendario.criacao);
  const modalidade = c.valor?.modalidadeAlteracao;
  return {
    txid: c.txid, status, revisao: c.revisao, amountCents: fromValor(c.valor.original), amountFixed: modalidade === undefined || modalidade === 0,
    pixKey: c.chave, createdAt, expiresInSeconds: expiracao, expiresAt: createdAt + BigInt(expiracao),
    location: c.location ?? c.loc?.location, pixCopiaECola: c.pixCopiaECola,
  };
}

/** The receiving half of a `BankAdapter`, over API Pix. */
export class ApiPixReceiver implements Pick<BankAdapter, 'listIncoming' | 'refundIncoming' | 'getIncoming' | 'createCharge' | 'getCharge' | 'cancelCharge'> {
  constructor(readonly client: ApiPixClient, private readonly o: { now?: () => number } = {}) {}

  async listIncoming(q: { since: bigint; until?: bigint }): Promise<IncomingPayment[]> {
    const fim = q.until !== undefined ? new Date(Number(q.until) * 1000) : new Date(this.o.now ? this.o.now() : Date.now());
    const pix = await this.client.listPix({ inicio: new Date(Number(q.since) * 1000), fim });
    const out: IncomingPayment[] = [];
    for (const p of pix) {
      try {
        out.push(pixToIncoming(p));
      } catch {
        // A record that breaks the schema cannot be matched safely; a human sees it at the bank.
      }
    }
    return out;
  }

  /** `GET /pix/{e2eid}`: the PSP's own record of one Pix, or undefined when it has none (or the id is malformed). */
  async getIncoming(bankTxId: string): Promise<IncomingPayment | undefined> {
    if (!E2E.test(bankTxId)) return undefined;
    try {
      return pixToIncoming(await this.client.getPix(bankTxId));
    } catch (e) {
      if (e instanceof ApiPixError && e.status === 404) return undefined;
      throw e;
    }
  }

  async refundIncoming(req: { idempotencyKey: string; bankTxId: string; amountCents: bigint; reason: string }): Promise<OutgoingPaymentResult> {
    const existing = await this.client.getDevolucao(req.bankTxId, req.idempotencyKey);
    const d = existing ?? await this.client.putDevolucao(req.bankTxId, req.idempotencyKey, {
      valor: toValor(req.amountCents), descricao: req.reason,
    });
    const status = DEVOLUCAO_STATUS[d.status];
    if (!status) throw new Error('unknown devolução status');
    return {
      idempotencyKey: req.idempotencyKey,
      status,
      bankTxId: d.rtrId,
      amountCents: fromValor(d.valor),
      paidAt: d.horario?.liquidacao ? seconds(d.horario.liquidacao) : undefined,
      failureReason: status === 'FAILED' ? (d.motivo ?? 'NAO_REALIZADO') : undefined,
    };
  }

  /** `PUT /cob/{txid}`: a charge for exactly `amountCents` to `pixKey`, the amount fixed. */
  async createCharge(req: { txid: string; amountCents: bigint; pixKey: string; expiresInSeconds: number }): Promise<PixCharge> {
    return cobToCharge(await this.client.putCob(req.txid, { amountCents: req.amountCents, chave: req.pixKey, expiracaoSeconds: req.expiresInSeconds }));
  }

  /** `GET /cob/{txid}`; undefined on 404. */
  async getCharge(txid: string): Promise<PixCharge | undefined> {
    try {
      return cobToCharge(await this.client.getCob(txid));
    } catch (e) {
      if (e instanceof ApiPixError && e.status === 404) return undefined;
      throw e;
    }
  }

  /**
   * Remove an `ATIVA` charge (`PATCH` to `REMOVIDA_PELO_USUARIO_RECEBEDOR`) and return the status it ends in. Read
   * first: a paid or already removed charge cannot be revised. A PATCH refused because the charge was paid in
   * between is answered by reading it again.
   */
  async cancelCharge(txid: string): Promise<PixChargeStatus | undefined> {
    const before = await this.getCharge(txid);
    if (!before || before.status !== 'ATIVA') return before?.status;
    try {
      return cobToCharge(await this.client.patchCob(txid, { status: 'REMOVIDA_PELO_USUARIO_RECEBEDOR' })).status;
    } catch (e) {
      if (!(e instanceof ApiPixError) || e.status !== 400) throw e;
      const after = await this.getCharge(txid);
      if (!after || after.status === 'ATIVA') throw e;
      return after.status;
    }
  }
}

/** What the LP's own bank integration must add: everything API Pix does not standardise. */
export type SendingAdapter = Omit<BankAdapter, 'listIncoming' | 'refundIncoming' | 'getIncoming' | 'createCharge' | 'getCharge' | 'cancelCharge'>;

/** API Pix for receiving, refunds and charges, the LP's bank API for everything that sends. */
export function composeBank(receiving: ApiPixReceiver, sending: SendingAdapter): BankAdapter {
  return {
    listIncoming: (q) => receiving.listIncoming(q),
    getIncoming: (id) => receiving.getIncoming(id),
    refundIncoming: (r) => receiving.refundIncoming(r),
    createCharge: (r) => receiving.createCharge(r),
    getCharge: (txid) => receiving.getCharge(txid),
    cancelCharge: (txid) => receiving.cancelCharge(txid),
    sendPix: (r) => sending.sendPix(r),
    payBoleto: (r) => sending.payBoleto(r),
    getOutgoing: (k) => sending.getOutgoing(k),
    ...(sending.registerBoleto ? { registerBoleto: sending.registerBoleto.bind(sending) } : {}),
    ...(sending.cancelBoleto ? { cancelBoleto: sending.cancelBoleto.bind(sending) } : {}),
    ...(sending.balanceCents ? { balanceCents: sending.balanceCents.bind(sending) } : {}),
    ...(sending.boletoNeedsDueDate ? { boletoNeedsDueDate: true } : {}),
  };
}
