/**
 * `RampChain` over viem: the one implementation that touches real contracts.
 *
 * Deliberately thin. Every decision lives in the handlers, which are tested against an
 * in-memory chain; what lives here is decoding (positional getters into named records, logs into
 * `RampEvent`s) and the write discipline: simulate, send, wait for the receipt, and turn any
 * revert into a `ChainRevert` carrying the contract's error name.
 *
 * ## ERC-20 allowances
 *
 * `postOffer` and `fundOffer` pull tokens with `transferFrom`, so a token offer is preceded by an
 * approval for exactly the amount - never an unlimited one: this key's allowance to the escrow is
 * the most a bug in the escrow could take from the LP's wallet. A token that, like mainnet USDT,
 * refuses to change a non-zero allowance to another non-zero value is zeroed first, and the
 * approval is sent with an ABI that expects no return value, since USDT returns none.
 *
 * ## The Movva reserve
 *
 * `GatewayChain` is implemented here too. Its sends differ from the escrow writes on purpose: they take
 * the nonce the gateway journaled and return at broadcast, so the hash reaches the journal before the
 * receipt does (gateway.ts). An issuer's freeze is probed as `IssuerFreeze` probes it: a token without
 * the function is not frozen, but an RPC that fails is not an answer, and fails the read.
 */
import {
  AbiDecodingZeroDataError, BaseError, ContractFunctionRevertedError, ContractFunctionZeroDataError, TransactionNotFoundError,
  TransactionReceiptNotFoundError, encodeFunctionData, parseAbi, parseEventLogs,
  type Abi, type Account, type Address, type Chain, type Hex, type PublicClient, type TransactionReceipt, type Transport,
  type WalletClient,
} from 'viem';
import { NO_REPLACEMENT, TxSender, type TxEvent, type TxPolicy } from './tx-sender.js';
import {
  CIRCLE_FREEZE_ABI, ERC20_ABI, ERC4626_ABI, FIAT_ESCROW_ABI, OFFRAMP_ESCROW_ABI, ORACLE_ABI, PERMISSIONLESS_REGISTRY_ABI, REGISTRY_ABI,
  RESERVE_ABI, NODE_REWARDS_ABI, TETHER_FREEZE_ABI,
} from './abi.js';
import {
  ChainRevert, NATIVE, reserveRatioBps, sameAddress,
  type AssetConfig, type BlockRef, type Credit, type GatewayAddresses, type GatewayChain, type Leg, type OnChainBoleto,
  type OnChainDispute, type OnChainOffer, type OnChainOrder, type OnChainSale, type OraclePrice, type PostOfferArgs, type RampChain,
  type RampEvent, type ReserveView, type RewardsChain, type RewardsView, type TxOutcome, type TxResult,
} from './chain.js';

/** USDT-shaped approve: no return value, so a token that returns nothing still decodes. */
const APPROVE_NO_RETURN = parseAbi(['function approve(address spender, uint256 amount)']);

export interface ViemRampChainOptions {
  publicClient: PublicClient;
  walletClient: WalletClient<Transport, Chain, Account>;
  onramp?: Address;
  offramp?: Address;
  registry: Address;
  /** How long a reserve send waits for its receipt before reporting it pending (default 60 s). */
  receiptWaitMs?: number;
  /** Fee cap and stuck-transaction replacement for every write (tx-sender.ts). Default: no cap, no replacement. */
  txPolicy?: TxPolicy;
  onTxEvent?: (e: TxEvent) => void;
}

/** A contract that refused or has no such function, as opposed to an RPC that did not answer. */
const refusedByContract = (e: unknown): boolean => e instanceof BaseError && !!e.walk((x) =>
  x instanceof ContractFunctionRevertedError || x instanceof ContractFunctionZeroDataError || x instanceof AbiDecodingZeroDataError);

/** Pull the contract error name out of a viem error, or fall back to its short message. */
export function toChainRevert(e: unknown): Error {
  if (e instanceof ChainRevert) return e;
  if (e instanceof BaseError) {
    const reverted = e.walk((x) => x instanceof ContractFunctionRevertedError);
    if (reverted instanceof ContractFunctionRevertedError) {
      const name = reverted.data?.errorName ?? reverted.reason ?? 'unknown';
      return new ChainRevert(name, `reverted: ${name}`);
    }
    return new Error(e.shortMessage);
  }
  return e instanceof Error ? e : new Error(String(e));
}

export class ViemRampChain implements RampChain, GatewayChain, RewardsChain {
  readonly chainId: number;
  readonly account: Address;
  readonly onramp?: Address;
  readonly offramp?: Address;
  private readonly pub: PublicClient;
  private readonly wallet: WalletClient<Transport, Chain, Account>;
  private readonly registry: Address;
  private readonly receiptWaitMs: number;
  readonly sender: TxSender;

  constructor(o: ViemRampChainOptions) {
    this.pub = o.publicClient;
    this.wallet = o.walletClient;
    this.chainId = o.walletClient.chain.id;
    this.account = o.walletClient.account.address;
    this.onramp = o.onramp;
    this.offramp = o.offramp;
    this.registry = o.registry;
    this.receiptWaitMs = o.receiptWaitMs ?? 60_000;
    this.sender = new TxSender(o.publicClient, o.walletClient, o.txPolicy ?? NO_REPLACEMENT, o.onTxEvent);
  }

  private need(leg: Leg): Address {
    const a = leg === 'onramp' ? this.onramp : this.offramp;
    if (!a) throw new Error(`no ${leg} escrow configured`);
    return a;
  }

  async head(): Promise<BlockRef> {
    const b = await this.pub.getBlock({ blockTag: 'latest' });
    return { number: b.number, hash: b.hash, timestamp: b.timestamp };
  }

  async block(number: bigint): Promise<BlockRef | undefined> {
    try {
      const b = await this.pub.getBlock({ blockNumber: number });
      return { number: b.number, hash: b.hash, timestamp: b.timestamp };
    } catch {
      return undefined;
    }
  }

  async events(from: bigint, to: bigint): Promise<RampEvent[]> {
    const out: (RampEvent & { logIndex: number })[] = [];
    if (this.onramp) {
      const logs = await this.pub.getLogs({
        address: this.onramp, fromBlock: from, toBlock: to,
        events: FIAT_ESCROW_ABI.filter((x) => x.type === 'event'),
      });
      for (const l of parseEventLogs({ abi: FIAT_ESCROW_ABI, logs })) {
        if (l.blockNumber === null || l.logIndex === null) continue; // pending logs carry no position
        const block = l.blockNumber;
        const logIndex = l.logIndex;
        switch (l.eventName) {
          case 'OfferPosted':
            out.push({ kind: 'OfferPosted', block, logIndex, offerId: l.args.offerId, lp: l.args.lp });
            break;
          case 'OrderLocked':
            out.push({
              kind: 'OrderLocked', block, logIndex, orderId: l.args.orderId, offerId: l.args.offerId,
              taker: l.args.taker, brlCents: l.args.brlCents,
            });
            break;
          case 'BoletoRequested':
            out.push({ kind: 'BoletoRequested', block, logIndex, orderId: l.args.orderId, issueBy: l.args.issueBy });
            break;
          case 'OrderReleased': case 'OrderCancelled': case 'OrderDisputed': case 'DisputeResolved':
          case 'DisputeTimedOut': case 'BoletoIssued':
            out.push({ kind: 'touched', block, logIndex, leg: 'onramp', id: l.args.orderId });
            break;
          default:
            break; // offer funding and closing: the offer manager reads offers every tick
        }
      }
    }
    if (this.offramp) {
      const logs = await this.pub.getLogs({
        address: this.offramp, fromBlock: from, toBlock: to,
        events: OFFRAMP_ESCROW_ABI.filter((x) => x.type === 'event'),
      });
      for (const l of parseEventLogs({ abi: OFFRAMP_ESCROW_ABI, logs })) {
        if (l.blockNumber === null || l.logIndex === null) continue;
        const block = l.blockNumber;
        const logIndex = l.logIndex;
        switch (l.eventName) {
          case 'SaleOpened':
            out.push({ kind: 'SaleOpened', block, logIndex, saleId: l.args.saleId });
            break;
          case 'SaleUnclaimed':
            out.push({ kind: 'SaleUnclaimed', block, logIndex, saleId: l.args.saleId, lp: l.args.lp });
            break;
          default:
            out.push({ kind: 'touched', block, logIndex, leg: 'offramp', id: l.args.saleId });
        }
      }
    }
    // Two escrows' logs, merged back into chain order.
    out.sort((a, b) => (a.block === b.block ? a.logIndex - b.logIndex : a.block < b.block ? -1 : 1));
    return out.map(({ logIndex: _i, ...e }) => e as RampEvent);
  }

  async offer(id: Hex, at?: bigint): Promise<OnChainOffer> {
    const r = await this.pub.readContract({
      address: this.need('onramp'), abi: FIAT_ESCROW_ABI, functionName: 'offers', args: [id], blockNumber: at,
    });
    return {
      lp: r[0], asset: r[1], availableWei: r[2], lockedWei: r[3], priceBrlCentsPerEth: r[4], pixKeyHash: r[5],
      minOrderWei: r[6], maxOrderWei: r[7], verifier: r[8], railMask: r[9], active: r[10], decimals: r[11],
    };
  }

  async order(id: Hex, at?: bigint): Promise<OnChainOrder> {
    const r = await this.pub.readContract({
      address: this.need('onramp'), abi: FIAT_ESCROW_ABI, functionName: 'orders', args: [id], blockNumber: at,
    });
    return {
      offerId: r[0], taker: r[1], weiAmount: r[2], brlCents: r[3], lockedAt: r[4], payBy: r[5], state: r[6],
      delivery: r[7], recipient: r[8],
    };
  }

  async boleto(id: Hex, at?: bigint): Promise<OnChainBoleto> {
    const r = await this.pub.readContract({
      address: this.need('onramp'), abi: FIAT_ESCROW_ABI, functionName: 'boletoOf', args: [id], blockNumber: at,
    });
    return { issueBy: r[0], issuedAt: r[1], commitment: r[2] };
  }

  async sale(id: Hex, at?: bigint): Promise<OnChainSale> {
    const r = await this.pub.readContract({
      address: this.need('offramp'), abi: OFFRAMP_ESCROW_ABI, functionName: 'sales', args: [id], blockNumber: at,
    });
    return {
      seller: r[0], asset: r[1], weiAmount: r[2], brlCents: r[3], payeeKeyHash: r[4], verifier: r[5],
      railMask: r[6], lp: r[7], claimedAt: r[8], payBy: r[9], refundTo: r[10], state: r[11],
    };
  }

  async dispute(leg: Leg, id: Hex): Promise<OnChainDispute> {
    const address = this.need(leg);
    const abi = leg === 'onramp' ? FIAT_ESCROW_ABI : OFFRAMP_ESCROW_ABI;
    const [disputedAt, timeout] = await Promise.all([
      this.pub.readContract({ address, abi, functionName: 'disputedAt', args: [id] }),
      this.pub.readContract({ address, abi, functionName: 'DISPUTE_TIMEOUT' }),
    ]);
    if (disputedAt === 0n) return { disputedAt, deadline: 0n };
    // The on-ramp runs a taker's dispute on TAKER_DISPUTE_TIMEOUT (H-04) and says so in `disputeDeadline`; an
    // on-ramp from before H-04 has no such view and runs every dispute on DISPUTE_TIMEOUT.
    if (leg === 'onramp') {
      const deadline = await this.pub.readContract({
        address, abi: FIAT_ESCROW_ABI, functionName: 'disputeDeadline', args: [id],
      }).catch(() => undefined);
      if (deadline !== undefined) return { disputedAt, deadline };
    }
    return { disputedAt, deadline: disputedAt + timeout };
  }

  async asset(leg: Leg, asset: Address): Promise<AssetConfig> {
    const r = await this.pub.readContract({
      address: this.need(leg), abi: leg === 'onramp' ? FIAT_ESCROW_ABI : OFFRAMP_ESCROW_ABI,
      functionName: 'assets', args: [asset],
    });
    return { oracle: r[0], decimals: r[1], enabled: r[2] };
  }

  async oraclePrice(oracle: Address): Promise<OraclePrice> {
    const [price, updatedAt] = await this.pub.readContract({
      address: oracle, abi: ORACLE_ABI, functionName: 'brlCentsPerUnit',
    });
    return { price, updatedAt };
  }

  async bandBps(leg: Leg): Promise<bigint> {
    return this.pub.readContract({
      address: this.need(leg), abi: leg === 'onramp' ? FIAT_ESCROW_ABI : OFFRAMP_ESCROW_ABI, functionName: 'BAND_BPS',
    });
  }

  async verifierAllowed(leg: Leg, verifier: Address): Promise<boolean> {
    return this.pub.readContract({
      address: this.need(leg), abi: leg === 'onramp' ? FIAT_ESCROW_ABI : OFFRAMP_ESCROW_ABI,
      functionName: 'allowedVerifier', args: [verifier],
    });
  }

  /** The registry's kind, once a read has told: it is the bytecode's, so it is asked once. */
  private registryKind?: 'curated' | 'permissionless';

  /**
   * Which LP registry the escrows run against. Both answer `capOf` and `availableCents`, which is all the node's
   * decisions use; only the curated LPRegistry has `setupComplete`, so reading it from a PermissionlessLPRegistry
   * reverted and left the node with no credit at all. `MIN_BOND` and `escrowsBound` answer only on the permissionless
   * one, `setupComplete` only on the curated one; an answer from neither (the RPC is down) is an error, never a guess,
   * and is asked again next tick.
   */
  async registryKindOf(): Promise<'curated' | 'permissionless'> {
    if (this.registryKind) return this.registryKind;
    const [minBond, bound, setup] = await Promise.allSettled([
      this.pub.readContract({ address: this.registry, abi: PERMISSIONLESS_REGISTRY_ABI, functionName: 'MIN_BOND' }),
      this.pub.readContract({ address: this.registry, abi: PERMISSIONLESS_REGISTRY_ABI, functionName: 'escrowsBound' }),
      this.pub.readContract({ address: this.registry, abi: REGISTRY_ABI, functionName: 'setupComplete' }),
    ]);
    if (minBond.status === 'fulfilled' && bound.status === 'fulfilled') this.registryKind = 'permissionless';
    else if (setup.status === 'fulfilled') this.registryKind = 'curated';
    else throw toChainRevert(setup.reason);
    return this.registryKind;
  }

  async credit(): Promise<Credit> {
    if ((await this.registryKindOf()) === 'permissionless') {
      const [capCents, availableCents, setupComplete, bond, withdrawableFrom] = await Promise.all([
        this.pub.readContract({ address: this.registry, abi: PERMISSIONLESS_REGISTRY_ABI, functionName: 'capOf', args: [this.account] }),
        this.pub.readContract({ address: this.registry, abi: PERMISSIONLESS_REGISTRY_ABI, functionName: 'availableCents', args: [this.account] }),
        this.pub.readContract({ address: this.registry, abi: PERMISSIONLESS_REGISTRY_ABI, functionName: 'escrowsBound' }),
        this.pub.readContract({ address: this.registry, abi: PERMISSIONLESS_REGISTRY_ABI, functionName: 'bonds', args: [this.account] }),
        this.pub.readContract({ address: this.registry, abi: PERMISSIONLESS_REGISTRY_ABI, functionName: 'withdrawableFrom', args: [this.account] }),
      ]);
      return { capCents, availableCents, setupComplete, registry: 'permissionless', bond: { amountWei: bond[0], withdrawableFrom } };
    }
    const [capCents, availableCents, setupComplete] = await Promise.all([
      this.pub.readContract({ address: this.registry, abi: REGISTRY_ABI, functionName: 'capOf', args: [this.account] }),
      this.pub.readContract({ address: this.registry, abi: REGISTRY_ABI, functionName: 'availableCents', args: [this.account] }),
      this.pub.readContract({ address: this.registry, abi: REGISTRY_ABI, functionName: 'setupComplete' }),
    ]);
    return { capCents, availableCents, setupComplete, registry: 'curated' };
  }

  async balance(asset: Address): Promise<bigint> {
    if (sameAddress(asset, NATIVE)) return this.pub.getBalance({ address: this.account });
    return this.pub.readContract({ address: asset, abi: ERC20_ABI, functionName: 'balanceOf', args: [this.account] });
  }

  /*//////////////////////////////////////////////////////////////
                                 WRITES
  //////////////////////////////////////////////////////////////*/

  /**
   * Send a simulated request through the sender and wait for ITS receipt. viem's own waiter would follow
   * a replacement to the replacement's receipt; the sender fetches receipts by the hashes it broadcast only,
   * replaces a stuck transaction at its nonce, and reports a nonce taken by something else as `replaced`.
   */
  private async mined(request: { address: Address; abi: Abi | readonly unknown[]; functionName: string; args?: readonly unknown[]; value?: bigint; gas?: bigint }): Promise<TxResult & { logs: TransactionReceipt['logs'] }> {
    const data = encodeFunctionData({ abi: request.abi as Abi, functionName: request.functionName, args: request.args as unknown[] });
    const r = await this.sender.sendAndWait({ to: request.address, data, value: request.value, gas: request.gas, abi: request.abi as Abi });
    if (r.status !== 'success') throw new ChainRevert('reverted', `transaction ${r.transactionHash} reverted: ${r.revertReason ?? 'unknown'}`);
    return { hash: r.transactionHash, blockNumber: r.blockNumber, logs: r.logs };
  }

  /**
   * Leave the allowance at exactly `amount` - not at least: a leftover larger allowance (a crashed process's,
   * or an approval the escrow never pulled) is brought down too, since the allowance is the most a bug in the
   * escrow could take. USDT refuses a non-zero to non-zero change, so a non-zero allowance is zeroed first.
   */
  private async approveExactly(token: Address, spender: Address, amount: bigint): Promise<void> {
    const current = await this.pub.readContract({
      address: token, abi: ERC20_ABI, functionName: 'allowance', args: [this.account, spender],
    });
    if (current === amount) return;
    if (current > 0n) {
      const { request } = await this.pub.simulateContract({
        account: this.wallet.account, address: token, abi: APPROVE_NO_RETURN, functionName: 'approve', args: [spender, 0n],
      });
      await this.mined(request);
    }
    if (amount === 0n) return;
    const { request } = await this.pub.simulateContract({
      account: this.wallet.account, address: token, abi: APPROVE_NO_RETURN, functionName: 'approve', args: [spender, amount],
    });
    await this.mined(request);
  }

  async postOffer(a: PostOfferArgs): Promise<TxResult & { offerId: Hex }> {
    const escrow = this.need('onramp');
    try {
      const native = sameAddress(a.asset, NATIVE);
      if (!native) await this.approveExactly(a.asset, escrow, a.amount);
      const { request } = await this.pub.simulateContract({
        account: this.wallet.account, address: escrow, abi: FIAT_ESCROW_ABI, functionName: 'postOffer',
        args: [a.asset, a.amount, a.priceBrlCentsPerUnit, a.pixKeyHash, a.minOrder, a.maxOrder, a.verifier, a.railMask],
        value: native ? a.amount : 0n,
      });
      const r = await this.mined(request);
      const posted = parseEventLogs({ abi: FIAT_ESCROW_ABI, logs: r.logs, eventName: 'OfferPosted' })
        .find((l) => sameAddress(l.address, escrow) && sameAddress(l.args.lp, this.account));
      if (!posted) throw new Error(`postOffer ${r.hash} mined without an OfferPosted log`);
      return { hash: r.hash, blockNumber: r.blockNumber, offerId: posted.args.offerId };
    } catch (e) {
      throw toChainRevert(e);
    }
  }

  async fundOffer(offerId: Hex, asset: Address, amount: bigint): Promise<TxResult> {
    const escrow = this.need('onramp');
    try {
      const native = sameAddress(asset, NATIVE);
      if (!native) await this.approveExactly(asset, escrow, amount);
      const { request } = await this.pub.simulateContract({
        account: this.wallet.account, address: escrow, abi: FIAT_ESCROW_ABI, functionName: 'fundOffer',
        args: [offerId, amount], value: native ? amount : 0n,
      });
      return await this.mined(request);
    } catch (e) {
      throw toChainRevert(e);
    }
  }

  async closeOffer(offerId: Hex): Promise<TxResult> {
    return this.onrampWrite('closeOffer', [offerId]);
  }

  async issueBoleto(orderId: Hex, commitment: Hex): Promise<TxResult> {
    return this.onrampWrite('issueBoleto', [orderId, commitment]);
  }

  async releaseWithProof(orderId: Hex, proof: Hex): Promise<TxResult> {
    return this.onrampWrite('releaseWithProof', [orderId, proof]);
  }

  async reclaimExpired(orderId: Hex): Promise<TxResult> {
    return this.onrampWrite('reclaimExpired', [orderId]);
  }

  async claimSale(saleId: Hex): Promise<TxResult> {
    return this.offrampWrite('claimSale', [saleId]);
  }

  async abandonClaim(saleId: Hex): Promise<TxResult> {
    return this.offrampWrite('abandonClaim', [saleId]);
  }

  async settleWithProof(saleId: Hex, proof: Hex): Promise<TxResult> {
    return this.offrampWrite('settleWithProof', [saleId, proof]);
  }

  async raiseDispute(leg: Leg, id: Hex, reason: string): Promise<TxResult> {
    return leg === 'onramp'
      ? this.onrampWrite('raiseDispute', [id, reason])
      : this.offrampWrite('raiseDispute', [id, reason]);
  }

  private async onrampWrite(
    functionName: 'closeOffer' | 'issueBoleto' | 'releaseWithProof' | 'reclaimExpired' | 'raiseDispute',
    args: readonly [Hex] | readonly [Hex, Hex] | readonly [Hex, string],
  ): Promise<TxResult> {
    try {
      const { request } = await this.pub.simulateContract({
        account: this.wallet.account, address: this.need('onramp'), abi: FIAT_ESCROW_ABI,
        functionName, args: args as never,
      });
      const { logs: _l, ...r } = await this.mined(request);
      return r;
    } catch (e) {
      throw toChainRevert(e);
    }
  }

  private async offrampWrite(
    functionName: 'claimSale' | 'abandonClaim' | 'settleWithProof' | 'raiseDispute',
    args: readonly [Hex] | readonly [Hex, Hex] | readonly [Hex, string],
  ): Promise<TxResult> {
    try {
      const { request } = await this.pub.simulateContract({
        account: this.wallet.account, address: this.need('offramp'), abi: OFFRAMP_ESCROW_ABI,
        functionName, args: args as never,
      });
      const { logs: _l, ...r } = await this.mined(request);
      return r;
    } catch (e) {
      throw toChainRevert(e);
    }
  }

  /*//////////////////////////////////////////////////////////////
                    NODE-PROVIDER REWARDS (RewardsChain)
  //////////////////////////////////////////////////////////////*/

  /** Every read at one block, so the view never mixes an epoch's finalization with the claims before it. */
  async rewardsView(rewards: Address, lookbackEpochs: number): Promise<RewardsView> {
    const blockNumber = await this.pub.getBlockNumber();
    const c = { address: rewards, abi: NODE_REWARDS_ABI, blockNumber } as const;
    const [registry, excluded, currentEpoch, nextToFinalize, finalizableEpochs, tokenPerCent] = await Promise.all([
      this.pub.readContract({ ...c, functionName: 'registry' }),
      this.pub.readContract({ ...c, functionName: 'excluded', args: [this.account] }),
      this.pub.readContract({ ...c, functionName: 'currentEpoch' }),
      this.pub.readContract({ ...c, functionName: 'nextToFinalize' }),
      this.pub.readContract({ ...c, functionName: 'finalizableEpochs' }),
      this.pub.readContract({ ...c, functionName: 'TOKEN_PER_CENT' }),
    ]);
    const back = BigInt(lookbackEpochs);
    const from = nextToFinalize > back ? nextToFinalize - back : 0n;
    const [currentVolumeCents, [claimable, epochs]] = await Promise.all([
      this.pub.readContract({ ...c, functionName: 'volumeOf', args: [currentEpoch, this.account] }),
      this.pub.readContract({ ...c, functionName: 'claimableIn', args: [this.account, from, nextToFinalize - from] }),
    ]);
    return { registry, excluded, currentEpoch, nextToFinalize, finalizableEpochs, tokenPerCent, currentVolumeCents, claimable, epochs: [...epochs] };
  }

  async finalizeRewards(rewards: Address, maxEpochs: bigint): Promise<TxResult> {
    try {
      const { request } = await this.pub.simulateContract({
        account: this.wallet.account, address: rewards, abi: NODE_REWARDS_ABI, functionName: 'finalize', args: [maxEpochs],
      });
      const { logs: _l, ...r } = await this.mined(request);
      return r;
    } catch (e) {
      throw toChainRevert(e);
    }
  }

  async claimRewards(rewards: Address, epochs: readonly bigint[], to: Address): Promise<TxResult & { paid: bigint }> {
    try {
      const { request } = await this.pub.simulateContract({
        account: this.wallet.account, address: rewards, abi: NODE_REWARDS_ABI, functionName: 'claim', args: [[...epochs], to],
      });
      const r = await this.mined(request);
      const paid = parseEventLogs({ abi: NODE_REWARDS_ABI, logs: r.logs, eventName: 'Claimed' })
        .filter((l) => sameAddress(l.address, rewards) && sameAddress(l.args.lp, this.account))
        .reduce((sum, l) => sum + l.args.paid, 0n);
      return { hash: r.hash, blockNumber: r.blockNumber, paid };
    } catch (e) {
      throw toChainRevert(e);
    }
  }

  /*//////////////////////////////////////////////////////////////
                         THE MOVVA RESERVE (GatewayChain)
  //////////////////////////////////////////////////////////////*/

  async reserveView(g: GatewayAddresses, at?: bigint): Promise<ReserveView> {
    const reserve = { address: g.reserve, abi: RESERVE_ABI, blockNumber: at } as const;
    const [
      isGateway, setupComplete, mintPaused, reserveFrozen, supplyCap, mintFeeBps, redeemFeeBps, minMint, totalUsdt, vault,
      supply, idle, lpFrozen,
    ] = await Promise.all([
      this.pub.readContract({ ...reserve, functionName: 'isGateway', args: [this.account] }),
      this.pub.readContract({ ...reserve, functionName: 'setupComplete' }),
      this.pub.readContract({ ...reserve, functionName: 'mintPaused' }),
      this.pub.readContract({ ...reserve, functionName: 'frozenByAssetIssuer' }),
      this.pub.readContract({ ...reserve, functionName: 'supplyCap' }),
      this.pub.readContract({ ...reserve, functionName: 'mintFeeBps' }),
      this.pub.readContract({ ...reserve, functionName: 'redeemFeeBps' }),
      this.pub.readContract({ ...reserve, functionName: 'minMintCollateralRatioBps' }),
      this.pub.readContract({ ...reserve, functionName: 'totalUsdt' }),
      this.pub.readContract({ ...reserve, functionName: 'yieldVault' }),
      this.pub.readContract({ address: g.movva, abi: ERC20_ABI, functionName: 'totalSupply', blockNumber: at }),
      this.pub.readContract({ address: g.usdt, abi: ERC20_ABI, functionName: 'balanceOf', args: [g.reserve], blockNumber: at }),
      this.frozen(g.usdt, this.account, at),
    ]);
    let rate: ReserveView['rate'];
    let collateralRatioBps: bigint | undefined;
    try {
      const [e18, updatedAt] = await this.pub.readContract({ ...reserve, functionName: 'brlPerUsdtE18' });
      collateralRatioBps = await this.pub.readContract({ ...reserve, functionName: 'collateralRatioBps' });
      rate = { e18, updatedAt: BigInt(updatedAt) };
    } catch (e) {
      // A stale or refused rate is a state to report; a failed RPC is not, and fails the whole view.
      const r = toChainRevert(e);
      if (!(r instanceof ChainRevert)) throw r;
      rate = { error: r.errorName };
      collateralRatioBps = undefined;
    }
    // The band's reading: the last close while the FX market is closed. Its ratio is the contract's arithmetic,
    // at that rate: collateralRatioBps() reads the strict rate, and reverts with it.
    let band: ReserveView['band'];
    try {
      const [e18, updatedAt] = await this.pub.readContract({ ...reserve, functionName: 'bandBrlPerUsdtE18' });
      band = { e18, updatedAt: BigInt(updatedAt), collateralRatioBps: reserveRatioBps(totalUsdt, e18, supply) };
    } catch (e) {
      const r = toChainRevert(e);
      if (!(r instanceof ChainRevert)) throw r;
      band = { error: r.errorName };
    }
    const vaultLiquid = sameAddress(vault, NATIVE) ? 0n
      : await this.pub.readContract({ address: vault, abi: ERC4626_ABI, functionName: 'maxWithdraw', args: [g.reserve], blockNumber: at });
    return {
      isGateway, setupComplete, mintPaused, reserveFrozen, lpFrozen, supply, supplyCap, mintFeeBps, redeemFeeBps,
      minMintCollateralRatioBps: minMint, totalUsdt, liquidUsdt: (reserveFrozen ? 0n : idle) + vaultLiquid, rate, collateralRatioBps, band,
    };
  }

  /** IssuerFreeze.isFrozen, off-chain. */
  private async frozen(token: Address, who: Address, at?: bigint): Promise<boolean> {
    const probes = [
      () => this.pub.readContract({ address: token, abi: TETHER_FREEZE_ABI, functionName: 'isBlackListed', args: [who], blockNumber: at }),
      () => this.pub.readContract({ address: token, abi: CIRCLE_FREEZE_ABI, functionName: 'isBlacklisted', args: [who], blockNumber: at }),
    ];
    for (const probe of probes) {
      try {
        if ((await probe()) !== 0n) return true;
      } catch (e) {
        if (!refusedByContract(e)) throw e;
      }
    }
    return false;
  }

  async previewMint(reserve: Address, usdtIn: bigint): Promise<{ movvaOut: bigint; fee: bigint }> {
    try {
      const [movvaOut, fee] = await this.pub.readContract({ address: reserve, abi: RESERVE_ABI, functionName: 'previewMint', args: [usdtIn] });
      return { movvaOut, fee };
    } catch (e) {
      throw toChainRevert(e);
    }
  }

  async previewRedeem(reserve: Address, movvaIn: bigint): Promise<{ usdtOut: bigint; fee: bigint }> {
    try {
      const [usdtOut, fee] = await this.pub.readContract({ address: reserve, abi: RESERVE_ABI, functionName: 'previewRedeem', args: [movvaIn] });
      return { usdtOut, fee };
    } catch (e) {
      throw toChainRevert(e);
    }
  }

  async allowance(token: Address, spender: Address): Promise<bigint> {
    return this.pub.readContract({ address: token, abi: ERC20_ABI, functionName: 'allowance', args: [this.account, spender] });
  }

  async approve(token: Address, spender: Address, amount: bigint): Promise<TxResult> {
    try {
      const { request } = await this.pub.simulateContract({
        account: this.wallet.account, address: token, abi: APPROVE_NO_RETURN, functionName: 'approve', args: [spender, amount],
      });
      const { logs: _l, ...r } = await this.mined(request);
      return r;
    } catch (e) {
      throw toChainRevert(e);
    }
  }

  get replaceAfterBlocks(): number {
    return this.sender.policy.replaceAfterBlocks;
  }

  async replace(hash: Hex): Promise<{ hash: Hex } | { capped: true } | { gone: true }> {
    try {
      return await this.sender.replace(hash);
    } catch (e) {
      throw toChainRevert(e);
    }
  }

  reserveNonces(nonces: number[]): void {
    this.sender.reserve(nonces);
  }

  async nonces(confirmedBlock: bigint): Promise<{ confirmed: number; pending: number }> {
    const [confirmed, pending] = await Promise.all([
      this.pub.getTransactionCount({ address: this.account, blockNumber: confirmedBlock }),
      this.pub.getTransactionCount({ address: this.account, blockTag: 'pending' }),
    ]);
    return { confirmed, pending };
  }

  async simulateMint(reserve: Address, usdtIn: bigint, minMovvaOut: bigint): Promise<void> {
    try {
      await this.pub.simulateContract({
        account: this.wallet.account, address: reserve, abi: RESERVE_ABI, functionName: 'mint', args: [usdtIn, this.account, minMovvaOut],
      });
    } catch (e) {
      throw toChainRevert(e);
    }
  }

  async simulateRedeem(reserve: Address, movvaIn: bigint, minUsdtOut: bigint): Promise<void> {
    try {
      await this.pub.simulateContract({
        account: this.wallet.account, address: reserve, abi: RESERVE_ABI, functionName: 'redeem', args: [movvaIn, this.account, minUsdtOut],
      });
    } catch (e) {
      throw toChainRevert(e);
    }
  }

  async sendMint(reserve: Address, usdtIn: bigint, minMovvaOut: bigint, nonce: number): Promise<Hex> {
    try {
      const { request } = await this.pub.simulateContract({
        account: this.wallet.account, address: reserve, abi: RESERVE_ABI, functionName: 'mint', args: [usdtIn, this.account, minMovvaOut],
      });
      return await this.sender.broadcast({ to: reserve, data: encodeFunctionData({ abi: RESERVE_ABI, functionName: 'mint', args: request.args }), gas: request.gas }, nonce);
    } catch (e) {
      throw toChainRevert(e);
    }
  }

  async sendRedeem(reserve: Address, movvaIn: bigint, minUsdtOut: bigint, nonce: number): Promise<Hex> {
    try {
      const { request } = await this.pub.simulateContract({
        account: this.wallet.account, address: reserve, abi: RESERVE_ABI, functionName: 'redeem', args: [movvaIn, this.account, minUsdtOut],
      });
      return await this.sender.broadcast({ to: reserve, data: encodeFunctionData({ abi: RESERVE_ABI, functionName: 'redeem', args: request.args }), gas: request.gas }, nonce);
    } catch (e) {
      throw toChainRevert(e);
    }
  }

  async outcome(hash: Hex, reserve: Address, wait: boolean): Promise<TxOutcome> {
    // Polled by hash, never with waitForTransactionReceipt: that follows a replacement to ITS receipt.
    const deadline = Date.now() + (wait ? this.receiptWaitMs : 0);
    let receipt: TransactionReceipt | undefined;
    for (;;) {
      try {
        receipt = await this.pub.getTransactionReceipt({ hash });
        break;
      } catch (e) {
        if (!(e instanceof BaseError && e.walk((x) => x instanceof TransactionReceiptNotFoundError))) throw toChainRevert(e);
      }
      if (Date.now() >= deadline) break;
      await new Promise((r) => setTimeout(r, Math.max(1, this.pub.pollingInterval ?? 1_000)));
    }
    if (!receipt) {
      try {
        const tx = await this.pub.getTransaction({ hash });
        return tx.blockNumber === null || tx.blockNumber === undefined ? { state: 'pending' } : { state: 'unknown' };
      } catch (e2) {
        if (e2 instanceof BaseError && e2.walk((x) => x instanceof TransactionNotFoundError)) return { state: 'unknown' };
        throw toChainRevert(e2);
      }
    }
    if (receipt.transactionHash.toLowerCase() !== hash.toLowerCase()) return { state: 'unknown' };
    let amountOut: bigint | undefined;
    for (const l of parseEventLogs({ abi: RESERVE_ABI, logs: receipt.logs })) {
      if (!sameAddress(l.address, reserve) || !sameAddress(l.args.gateway, this.account)) continue;
      if (l.eventName === 'Minted') amountOut = l.args.movvaOut;
      else if (l.eventName === 'Redeemed') amountOut = l.args.usdtOut;
    }
    const ok = receipt.status === 'success';
    return { state: 'mined', ok, blockNumber: receipt.blockNumber, amountOut, ...(ok ? {} : { why: await this.sender.revertReason(receipt, RESERVE_ABI) }) };
  }

}
