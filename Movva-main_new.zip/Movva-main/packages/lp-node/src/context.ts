/**
 * What every handler is handed each tick, and the logger they all write through.
 *
 * `TickView` pins one head per tick. Every handler judges deadlines against the same
 * `chainNow` (the escrows compare against `block.timestamp`, not wall time) and makes its
 * confirmed reads at the same `confirmedBlock`, so two handlers in one tick cannot disagree
 * about whether something has happened yet.
 */
import type { Hex } from 'viem';
import { redact } from '@mova/ops/redact';
import type { BankAdapter } from './bank.js';
import type { CapLedger } from './caps.js';
import type { EvidenceSubmitter } from './evidence.js';
import type { BlockRef, RampChain } from './chain.js';
import type { PaymentProver } from './attestation.js';
import type { Metrics } from './metrics.js';
import type { Store } from './store.js';

export interface Logger {
  info(msg: string): void;
  warn(msg: string): void;
  error(msg: string): void;
}

/** Every line through `redact` with the configured secrets, timestamped. */
export function redactingLogger(
  secrets: readonly (string | undefined)[],
  sink: { log: (s: string) => void; error: (s: string) => void } = console,
): Logger {
  const stamp = () => new Date().toISOString();
  return {
    info: (m) => sink.log(`${stamp()} info  ${redact(m, secrets)}`),
    warn: (m) => sink.error(`${stamp()} warn  ${redact(m, secrets)}`),
    error: (m) => sink.error(`${stamp()} error ${redact(m, secrets)}`),
  };
}

export const silentLogger: Logger = { info: () => {}, warn: () => {}, error: () => {} };

/** The message only: a printed viem error repeats the RPC URL in its cause chain. */
export const errorText = (e: unknown): string => (e instanceof Error ? e.message : String(e));

export interface TickView {
  head: BlockRef;
  /** `head - confirmations + 1`: state read here survives any reorg shallower than N. */
  confirmedBlock: bigint;
  /** The escrows' clock: the head's timestamp. */
  chainNow: bigint;
  /** The bank's clock, approximately: wall time, unix seconds. */
  wallNow: bigint;
}

export interface NodeContext {
  chain: RampChain;
  bank: BankAdapter;
  /** Files evidence commitments for disputed orders and sales, when an arbitration desk is configured. */
  evidence?: EvidenceSubmitter;
  /**
   * Per-payer daily and monthly limits (caps.ts). Absent unless the LP configured a `caps` section, and
   * every handler reads it as `ctx.caps?`: a node without one behaves exactly as it did before they existed.
   */
  caps?: CapLedger;
  store: Store;
  /** By lowercase verifier address. */
  provers: ReadonlyMap<string, PaymentProver>;
  metrics: Metrics;
  log: Logger;
  /** Secret for payerRef derivation (attestation.ts). */
  payerRefSecret: Hex;
  /** How the LP's own account is identified to the proofs on the off-ramp, e.g. its CNPJ. */
  lpPayerId: string;
  /**
   * The bank's clock, approximately: wall time in unix seconds, the same one `TickView.wallNow` carries.
   * For the few things that happen OUTSIDE a tick - a counterparty request arriving between them - and must
   * still agree with it about what day it is.
   */
  wallClock: () => bigint;
}

/** Short form of an id for logs: enough to grep, not enough to be a whole identifier twice. */
export const short = (id: string) => `${id.slice(0, 10)}…`;
