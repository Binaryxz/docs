/**
 * Prometheus exposition for the LP node, prefix `mova_lp_`.
 *
 * Same discipline as the monitor's (packages/ops/src/server.ts): label values come only from
 * fixed vocabularies in code - an asset address from configuration, a state name, a reason from
 * an enum - and never from an error message, a PIX key or an amount. Labels are scraped, stored
 * and shown on dashboards with far less care than an alert channel, so anything that could carry
 * a secret or a payer's data stays out of them.
 *
 * Every series is declared here, with its help text, so a dashboard can rely on a metric existing
 * (at zero) before the event it counts has ever happened.
 */

type Kind = 'counter' | 'gauge';

const DEFS = {
  mova_lp_up: ['gauge', '1 while the node process is running.'],
  mova_lp_ready: ['gauge', '1 once a tick has completed against the chain and the bank.'],
  mova_lp_last_tick_timestamp_seconds: ['gauge', 'Unix time of the last completed tick.'],
  mova_lp_tick_duration_seconds: ['gauge', 'Wall time the last tick took.'],
  mova_lp_tick_errors_total: ['counter', 'Ticks, or steps within one, that threw; by stage.'],
  mova_lp_chain_head_block: ['gauge', 'Chain head at the last tick.'],
  mova_lp_indexed_block: ['gauge', 'Last block whose escrow events were folded in.'],
  mova_lp_reorgs_total: ['counter', 'Times the event cursor found its block replaced and rewound.'],
  mova_lp_credit_available_cents: ['gauge', 'LPRegistry.availableCents for this LP.'],
  mova_lp_credit_cap_cents: ['gauge', 'LPRegistry.capOf for this LP; 0 means suspended or not admitted.'],
  mova_lp_quoting: ['gauge', '1 when the asset has a live offer the node is willing to stand behind.'],
  mova_lp_offer_price_brl_cents: ['gauge', 'Price of the active offer, BRL centavos per whole unit.'],
  mova_lp_offer_available_units: ['gauge', 'Unlocked liquidity in the active offer, in base units.'],
  mova_lp_offer_locked_units: ['gauge', 'Liquidity reserved by live orders across this asset\'s offers, in base units.'],
  mova_lp_quote_pulled_total: ['counter', 'Times an offer was closed or not posted, by reason.'],
  mova_lp_offer_actions_total: ['counter', 'Offer transactions sent, by action.'],
  mova_lp_onramp_orders: ['gauge', 'Tracked on-ramp orders by on-chain state.'],
  mova_lp_onramp_released_total: ['counter', 'On-ramp orders this node proved and released.'],
  mova_lp_onramp_brl_received_cents_total: ['counter', 'BRL matched to on-ramp orders, centavos.'],
  mova_lp_onramp_reclaimed_total: ['counter', 'Expired on-ramp orders this node returned to its offer.'],
  mova_lp_boletos_issued_total: ['counter', 'Boletos registered at the bank and committed on-chain.'],
  mova_lp_refunds_total: ['counter', 'Refunds of BRL received for orders that did not release, by status.'],
  mova_lp_unreconciled_credits: ['gauge', 'Recent incoming credits that match no order: a human must look.'],
  mova_lp_webhook_requests_total: ['counter', 'PIX webhook calls, by result (accepted, unauthorised, malformed).'],
  mova_lp_offramp_sales: ['gauge', 'Tracked off-ramp sales by on-chain state (claimed = by this LP).'],
  mova_lp_offramp_claims_total: ['counter', 'Sales claimed.'],
  mova_lp_offramp_skipped_total: ['counter', 'Open sales not claimed, by reason.'],
  mova_lp_offramp_brl_paid_cents_total: ['counter', 'BRL paid to sellers, centavos.'],
  mova_lp_offramp_settled_total: ['counter', 'Sales settled with proof.'],
  mova_lp_offramp_abandoned_total: ['counter', 'Claims given back, by reason.'],
  mova_lp_payments_unresolved: ['gauge', 'Outgoing payments whose final outcome is not yet recorded.'],
  mova_lp_disputes_raised_total: ['counter', 'Disputes this node raised, by leg.'],
  mova_lp_disputes_open: ['gauge', 'Orders and sales in DISPUTED state that involve this LP.'],
  mova_lp_evidence_submitted_total: ['counter', 'Evidence commitments filed with the arbitration desk, by leg.'],
  mova_lp_evidence_errors_total: ['counter', 'Attempts to file evidence the desk did not take yet, by leg.'],
  mova_lp_held: ['gauge', 'Orders and sales the node stopped acting on and left for a human.'],
  mova_lp_bank_errors_total: ['counter', 'Bank adapter calls that threw, by operation.'],
  mova_lp_proof_failures_total: ['counter', 'Attempts to obtain a proof that failed, by leg.'],
  mova_lp_journal_records: ['gauge', 'Records in the state journal.'],
  mova_lp_journal_bytes: ['gauge', 'Bytes in the state journal.'],
  mova_lp_journal_compactions_total: ['counter', 'Times the journal was replaced by a snapshot of the live state.'],
  mova_lp_tx_replacements_total: ['counter', 'Unmined transactions re-sent at their nonce with bumped fees, by kind (write, gateway).'],
  mova_lp_tx_fee_capped_total: ['counter', 'Stuck transactions the fee cap allowed no further bump for, by kind.'],
  mova_lp_tx_adopted_total: ['counter', 'Pending transactions of this account left by an earlier process, found and followed.'],
  mova_lp_tx_cancelled_total: ['counter', 'Blocking pending transactions that could not be found, cancelled by a transfer to self at their nonce.'],
  mova_lp_gateway_blocked: ['gauge', 'Movva gateway: 1 for each check that stops a mint or redemption right now, by op and reason.'],
  mova_lp_gateway_held: ['gauge', 'Movva gateway: 1 while redemptions are held below the collateral ratio floor, minting and redeeming wait for the FX market (market_closed), or a reserve transaction needs a human, by reason.'],
  mova_lp_gateway_market_closed: ['gauge', 'Movva gateway: 1 while the reserve refuses its rate and its band reads the last close: the FX market is closed, mint and redeem wait, Movva is priced from the close.'],
  mova_lp_gateway_pending: ['gauge', 'Movva gateway: mint and redeem transactions sent whose outcome is not yet final.'],
  mova_lp_gateway_mints_total: ['counter', 'Movva gateway: mint transactions by final outcome.'],
  mova_lp_gateway_redeems_total: ['counter', 'Movva gateway: redeem transactions by final outcome.'],
  mova_lp_gateway_usdt_minted_units_total: ['counter', 'Movva gateway: USDT paid into the reserve by mints, base units (6 decimals).'],
  mova_lp_gateway_movva_minted_cents_total: ['counter', 'Movva gateway: Movva received from mints, in centavos.'],
  mova_lp_gateway_movva_redeemed_cents_total: ['counter', 'Movva gateway: Movva given to redemptions, in centavos.'],
  mova_lp_gateway_usdt_redeemed_units_total: ['counter', 'Movva gateway: USDT received from redemptions, base units.'],
  mova_lp_gateway_usdt_balance_units: ['gauge', 'Movva gateway: USDT in the LP wallet, base units.'],
  mova_lp_gateway_movva_balance_cents: ['gauge', 'Movva gateway: Movva in the LP wallet, in centavos.'],
  mova_lp_gateway_collateral_ratio_bps: ['gauge', 'Movva gateway: the reserve collateral ratio when last readable, capped at 1000000.'],
  mova_lp_gateway_rate_readable: ['gauge', 'Movva gateway: 1 when the reserve rate could be read at the last tick; 0 when stale or unreadable.'],
  mova_lp_gateway_last_mint_timestamp_seconds: ['gauge', 'Movva gateway: unix time a mint last reached its final outcome MINED.'],
  mova_lp_gateway_last_redeem_timestamp_seconds: ['gauge', 'Movva gateway: unix time a redemption last reached its final outcome MINED.'],
  mova_lp_rewards_claimable: ['gauge', 'Node rewards: what this LP can claim now from finalized epochs in its look-back window, in centavos of the reward token.'],
  mova_lp_rewards_counting: ['gauge', 'Node rewards: 1 while this LP\'s settlements count (NodeRewards bound to the configured registry, the LP not excluded).'],
  mova_lp_rewards_epoch_volume_cents: ['gauge', 'Node rewards: this LP\'s counted volume in the current epoch, centavos.'],
  mova_lp_rewards_unclaimed_epochs: ['gauge', 'Node rewards: finalized epochs with an unclaimed share for this LP.'],
  mova_lp_rewards_finalizable_epochs: ['gauge', 'Node rewards: epochs whose review has ended and that nobody has finalized.'],
  mova_lp_rewards_finalized_total: ['counter', 'Node rewards: epochs this node finalized.'],
  mova_lp_rewards_claims_total: ['counter', 'Node rewards: claims, by outcome (mined, refused).'],
  mova_lp_rewards_claimed_cents_total: ['counter', 'Node rewards: rewards claimed, in centavos of the reward token.'],
  mova_lp_caps_enabled: ['gauge', 'Per-payer caps: 1 while a caps section is configured; 0 on a node with none.'],
  mova_lp_caps_refusals_total: ['counter', 'Per-payer caps: payments refused, by leg and by the rule that refused (day, month, unknown_payer).'],
  mova_lp_caps_counted_cents_total: ['counter', 'Per-payer caps: BRL counted against a payer\'s allowance, centavos, by leg.'],
  mova_lp_caps_uncounted_cents_total: ['counter', 'Per-payer caps: BRL given back to a payer\'s allowance when the money went back, centavos, by leg.'],
  mova_lp_caps_payers_today: ['gauge', 'Per-payer caps: distinct payers with a count in the current Brasilia day.'],
  mova_lp_caps_counted_today_cents: ['gauge', 'Per-payer caps: BRL counted in the current Brasilia day, centavos, across payers.'],
  mova_lp_caps_ledger_rows: ['gauge', 'Per-payer caps: rows the cap ledger holds (payer, day, amount).'],
  mova_lp_caps_last_count_timestamp_seconds: ['gauge', 'Per-payer caps: unix time the cap ledger was last written; 0 if never.'],
  mova_lp_caps_tier_errors_total: ['counter', 'Per-payer caps: TIER_MODULE lookups that threw; the configured tier was used.'],
} as const satisfies Record<string, readonly [Kind, string]>;

export type MetricName = keyof typeof DEFS;
type Labels = Record<string, string>;

const esc = (s: string) => s.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n');
const key = (labels: Labels) =>
  Object.keys(labels).sort().map((k) => `${k}="${esc(labels[k])}"`).join(',');

export class Metrics {
  private readonly series = new Map<MetricName, Map<string, number>>();

  constructor() {
    for (const n of Object.keys(DEFS) as MetricName[]) this.series.set(n, new Map());
    this.set('mova_lp_up', 1);
  }

  inc(name: MetricName, labels: Labels = {}, by = 1): void {
    const m = this.series.get(name)!;
    const k = key(labels);
    m.set(k, (m.get(k) ?? 0) + by);
  }

  set(name: MetricName, value: number, labels: Labels = {}): void {
    this.series.get(name)!.set(key(labels), value);
  }

  /** Replace every series of a gauge at once, so a state nobody is in any more reads zero. */
  reset(name: MetricName): void {
    const m = this.series.get(name)!;
    for (const k of m.keys()) m.set(k, 0);
  }

  get(name: MetricName, labels: Labels = {}): number {
    return this.series.get(name)!.get(key(labels)) ?? 0;
  }

  render(): string {
    const lines: string[] = [];
    for (const [name, [type, help]] of Object.entries(DEFS) as [MetricName, readonly [Kind, string]][]) {
      lines.push(`# HELP ${name} ${help}`);
      lines.push(`# TYPE ${name} ${type}`);
      const m = this.series.get(name)!;
      if (m.size === 0 && type === 'counter') lines.push(`${name} 0`);
      for (const [k, v] of m) lines.push(`${name}${k ? `{${k}}` : ''} ${Number.isFinite(v) ? v : 0}`);
    }
    return `${lines.join('\n')}\n`;
  }
}
