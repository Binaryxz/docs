/**
 * The development `MockBank`, served over HTTP by the process that owns them, and the LP node's
 * clients for them. DEVELOPMENT ONLY: nothing here moves money, and the entrypoint takes it only with LP_NODE_DEV=1.
 *
 * ## Why
 *
 * The dev stack (packages/app/scripts/dev-stack.ts) plays the LP's bank from the outside - "Simular
 * pagamento" credits a PIX, the e2e tests read what the LP's bank sent - on an in-memory mock it owns. An LP node inside
 * the services image is another process, so it cannot share those objects. `serveDevMockBank` puts their ADAPTER side
 * on a loopback listener, and `MockBankClient` implements `BankAdapter` over it:
 * the node in the container talks to the same MockBank the dev API pays into.
 *
 *   DEV_MOCK_BANK_URL=http://127.0.0.1:<port> LP_NODE_DEV=1 node --import tsx packages/lp-node/src/bin/lp-node.ts
 *
 * ## What it serves, and what it never does
 *
 *   GET  /bank                         { boletoNeedsDueDate }
 *   POST /bank/<method>      { args }  -> { result }     the BankAdapter methods, and receipt() for local witnesses
 *
 * Bigints travel as `{ "$bigint": "123" }`. A method that throws answers 500 `{ error }` with its message, which the
 * client throws again - so a lost response (`MockBank.loseNextResponse`) is still a thrown send whose money moved, and
 * the node's idempotency-key recovery runs as it does in memory. Only the adapter's methods are served: never the
 * outside world's (`receivePix`, `payRegisteredBoleto`, `pay`, ...) nor fault injection, which stay with the owner.
 * It listens on loopback, holds no credential and asks for none: it is a mock.
 *
 * `receipt()` is served because the development zkTLS witnesses (`LocalWitnessSession`) sign what MockBank's records
 * show; the entrypoint lets them read a `MockBankClient` only when it came from DEV_MOCK_BANK_URL, never from a
 * BANK_MODULE (bin/lp-node.ts, `localWitnessReceipts`).
 */
import { createServer, type IncomingMessage, type Server, type ServerResponse } from 'node:http';
import type { BankAdapter, BankRail, IncomingPayment, OutgoingPaymentResult, PixCharge, PixChargeStatus, RegisteredBoleto, MockBank } from './bank.js';
import type { Leg } from './chain.js';
import type { BankReceipt, ReceiptSource } from './zktls.js';

/** The BankAdapter methods (and ReceiptSource's), and nothing else, a MockBank answers over HTTP. */
export const DEV_BANK_METHODS = [
  'listIncoming', 'getIncoming', 'sendPix', 'payBoleto', 'getOutgoing', 'registerBoleto', 'cancelBoleto',
  'createCharge', 'getCharge', 'cancelCharge', 'refundIncoming', 'balanceCents', 'receipt',
] as const;

const MAX_BODY_BYTES = 1024 * 1024;
const DEFAULT_TIMEOUT_MS = 30_000;

/** JSON that keeps bigints, both ways. */
export function devWireStringify(value: unknown): string {
  return JSON.stringify(value, (_k, v: unknown) => (typeof v === 'bigint' ? { $bigint: v.toString() } : v));
}

export function devWireParse<T = unknown>(text: string): T {
  return JSON.parse(text, (_k, v: unknown) => {
    if (v && typeof v === 'object' && !Array.isArray(v)) {
      const big = (v as { $bigint?: unknown }).$bigint;
      if (Object.keys(v).length === 1 && typeof big === 'string' && /^-?\d+$/.test(big)) return BigInt(big);
    }
    return v;
  }) as T;
}

/*//////////////////////////////////////////////////////////////
                               THE SERVER
//////////////////////////////////////////////////////////////*/

export interface DevMockBankServer {
  server: Server;
  /** Loopback by default; 0 picks a free port. Resolves with the port. */
  listen(port?: number, host?: string): Promise<number>;
  close(): Promise<void>;
}

/** Serve a MockBank to an LP node in another process. */
export function serveDevMockBank(o: { bank: MockBank; onError?: (m: string) => void }): DevMockBankServer {
  const send = (rs: ServerResponse, status: number, body: unknown) => {
    rs.writeHead(status, { 'content-type': 'application/json', 'cache-control': 'no-store' });
    rs.end(devWireStringify(body));
  };
  const readBody = async (rq: IncomingMessage): Promise<string> => {
    const chunks: Buffer[] = [];
    let size = 0;
    for await (const c of rq) {
      size += (c as Buffer).length;
      if (size > MAX_BODY_BYTES) throw new RangeError('request body too large');
      chunks.push(c as Buffer);
    }
    return Buffer.concat(chunks).toString('utf8');
  };

  const handle = async (rq: IncomingMessage, rs: ServerResponse) => {
    const path = new URL(rq.url ?? '/', 'http://localhost').pathname;
    const [, side, method, ...extra] = path.split('/');
    const target = side === 'bank' ? o.bank : undefined;
    const allowed: readonly string[] = DEV_BANK_METHODS;
    if (!target || extra.length) return send(rs, 404, { error: 'not found' });
    if (!method) {
      if (rq.method !== 'GET') return send(rs, 405, { error: 'GET only' });
      return send(rs, 200, { boletoNeedsDueDate: o.bank.boletoNeedsDueDate });
    }
    const fn = (target as unknown as Record<string, unknown>)[method];
    if (!allowed.includes(method) || typeof fn !== 'function') return send(rs, 404, { error: `${side} has no adapter method ${method}` });
    if (rq.method !== 'POST') return send(rs, 405, { error: 'POST only' });
    let args: unknown[];
    try {
      const body = devWireParse<{ args?: unknown }>((await readBody(rq)) || '{}');
      if (!Array.isArray(body.args)) throw new TypeError('no args');
      args = body.args;
    } catch {
      return send(rs, 400, { error: 'the body is { "args": [...] }' });
    }
    try {
      const result = await (fn as (...a: unknown[]) => unknown).apply(target, args);
      return send(rs, 200, { result });
    } catch (e) {
      const message = e instanceof Error ? e.message : String(e);
      return send(rs, 500, { error: message });
    }
  };

  const server = createServer((rq, rs) => {
    handle(rq, rs).catch((e: unknown) => {
      o.onError?.(e instanceof Error ? e.message : String(e));
      if (!rs.headersSent) send(rs, 500, { error: 'internal error' });
      else rs.destroy();
    });
  });
  return {
    server,
    listen: (port = 0, host = '127.0.0.1') => new Promise<number>((resolve, reject) => {
      server.once('error', reject);
      server.listen(port, host, () => {
        const a = server.address();
        resolve(typeof a === 'object' && a ? a.port : port);
      });
    }),
    close: () => new Promise<void>((resolve) => {
      server.close(() => resolve());
      server.closeAllConnections();
    }),
  };
}

/*//////////////////////////////////////////////////////////////
                               THE CLIENTS
//////////////////////////////////////////////////////////////*/

export interface DevMockClientOptions {
  /** Any `fetch`; called as a plain function. */
  fetchImpl?: (input: string, init?: RequestInit) => Promise<Response>;
  /** Per call. Default 30 s. */
  timeoutMs?: number;
}

type Caller = (method: string, args: unknown[]) => Promise<never>;

/** The base URL, checked: http(s), no query or fragment. */
export function devMockBankBase(url: string): string {
  let u: URL;
  try {
    u = new URL(url);
  } catch {
    throw new Error('DEV_MOCK_BANK_URL is not a URL');
  }
  if ((u.protocol !== 'http:' && u.protocol !== 'https:') || u.search || u.hash) throw new Error('DEV_MOCK_BANK_URL must be an http(s) base URL');
  return u.href.replace(/\/+$/, '');
}

async function request(base: string, path: string, init: RequestInit, o: DevMockClientOptions): Promise<unknown> {
  const f = o.fetchImpl ?? ((input: string, i?: RequestInit) => globalThis.fetch(input, i));
  let res: Response;
  let text: string;
  try {
    res = await f(`${base}${path}`, { ...init, signal: AbortSignal.timeout(o.timeoutMs ?? DEFAULT_TIMEOUT_MS) });
    text = await res.text();
  } catch (e) {
    throw new Error(`the development mock bank did not answer ${path}: ${e instanceof Error ? e.message : String(e)}`);
  }
  let body: { result?: unknown; error?: unknown } | undefined;
  try {
    body = text ? devWireParse(text) : undefined;
  } catch {
    body = undefined;
  }
  if (!res.ok) {
    // The mock's own message, as the in-memory mock would have thrown it.
    throw new Error(typeof body?.error === 'string' ? body.error : `the development mock bank answered HTTP ${res.status} to ${path}`);
  }
  if (!body || typeof body !== 'object') throw new Error(`the development mock bank answered ${path} with no JSON object`);
  return body;
}

function caller(base: string, side: 'bank', o: DevMockClientOptions): Caller {
  return async (method, args) => {
    const body = await request(base, `/${side}/${method}`, {
      method: 'POST', headers: { 'content-type': 'application/json' }, body: devWireStringify({ args }),
    }, o) as { result?: unknown };
    return body.result as never;
  };
}

/** `BankAdapter` over `serveDevMockBank`: the dev stack's MockBank, from another process. */
export class MockBankClient implements BankAdapter, ReceiptSource {
  private constructor(private readonly call: Caller, readonly boletoNeedsDueDate: boolean) {}

  /** Asks the server what it serves first, so an unreachable URL stops the node at startup. */
  static async connect(url: string, o: DevMockClientOptions = {}): Promise<MockBankClient> {
    const base = devMockBankBase(url);
    const info = await request(base, '/bank', { method: 'GET' }, o) as { boletoNeedsDueDate?: unknown };
    return new MockBankClient(caller(base, 'bank', o), info.boletoNeedsDueDate === true);
  }

  listIncoming(q: { since: bigint; until?: bigint }): Promise<IncomingPayment[]> { return this.call('listIncoming', [q]); }
  getIncoming(bankTxId: string): Promise<IncomingPayment | undefined> { return this.call('getIncoming', [bankTxId]); }
  sendPix(req: { idempotencyKey: string; pixKey: string; amountCents: bigint; description?: string }): Promise<OutgoingPaymentResult> { return this.call('sendPix', [req]); }
  payBoleto(req: { idempotencyKey: string; line: string; amountCents: bigint }): Promise<OutgoingPaymentResult> { return this.call('payBoleto', [req]); }
  getOutgoing(idempotencyKey: string): Promise<OutgoingPaymentResult | undefined> { return this.call('getOutgoing', [idempotencyKey]); }
  registerBoleto(req: { idempotencyKey: string; amountCents: bigint; dueDate: string; reference: string }): Promise<RegisteredBoleto> { return this.call('registerBoleto', [req]); }
  cancelBoleto(bankRef: string): Promise<void> { return this.call('cancelBoleto', [bankRef]); }
  createCharge(req: { txid: string; amountCents: bigint; pixKey: string; expiresInSeconds: number }): Promise<PixCharge> { return this.call('createCharge', [req]); }
  getCharge(txid: string): Promise<PixCharge | undefined> { return this.call('getCharge', [txid]); }
  cancelCharge(txid: string): Promise<PixChargeStatus | undefined> { return this.call('cancelCharge', [txid]); }
  refundIncoming(req: { idempotencyKey: string; bankTxId: string; amountCents: bigint; reason: string }): Promise<OutgoingPaymentResult> { return this.call('refundIncoming', [req]); }
  balanceCents(): Promise<bigint> { return this.call('balanceCents', []); }
  receipt(leg: Leg, rail: BankRail, bankTxId: string): Promise<BankReceipt | undefined> { return this.call('receipt', [leg, rail, bankTxId]); }
}
