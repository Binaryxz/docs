/**
 * Keeping on-ramp liquidity posted at a price the LP stands behind - and pulled when it cannot.
 *
 * ## What the contract allows, which shapes all of this
 *
 * `FiatEscrow` has no "update price": an offer's price is fixed at `postOffer`. Repricing is
 * therefore `closeOffer` (which returns only the UNLOCKED liquidity and releases its credit) and
 * `postOffer` again, under a new offer id and a fresh PIX-key salt. Orders already locked against
 * the old offer keep running on it, so an asset has at most one ACTIVE offer and any number of
 * closed ones still draining locked liquidity. Extra active offers - from a crash between a post
 * and its journal record, say - are closed down to the newest.
 *
 * ## When the node pulls
 *
 * An offer is closed whenever the node cannot state a safe price (pricing.ts: a feed missing or
 * stale, reference and oracle disagreeing, the LP's floor above the band's ceiling), when the
 * asset is delisted, when the offer's verifier is revoked, and when the LP has no credit (a
 * suspended LP's offers are still lockable until closed: `LPRegistry` stops NEW exposure, and
 * `_lock` does not consult the registry). On a PermissionlessLPRegistry the same holds for an LP that has asked to
 * leave (`requestExit` makes `capOf` zero at once) or whose bond a lost dispute took: its offers are pulled the
 * same tick. Closing is instant and cheap; an offer left up at a
 * price the node no longer believes is an option written for free.
 *
 * ## Exposure
 *
 * The escrow reserves ceil(liquidity * price / 10**decimals) of the LP's registry credit when it
 * posts, and refuses what would exceed it. The node sizes offers to fit what `availableCents`
 * says rather than discovering `LPNotEligible` at simulation, and additionally caps each asset
 * at its configured `liquidity` and optional `maxOfferBrlCents`: the credit limit bounds the LP
 * across the whole product, the configuration bounds this asset.
 *
 * ## Bank offers name a zkTLS verifier
 *
 * `postOffer` refuses a PIX, boleto or TED offer on a verifier that does not prove the bank session
 * (`BankRailNeedsZkTls`). The configuration and the entrypoint refuse such an asset before the node starts
 * (config.ts, bin/lp-node.ts), and should one reach here - a verifier whose prover proves no rail the asset
 * lists, or an escrow that refuses the post - the book is pulled with
 * `bank_rail_needs_zktls` instead of being retried every tick.
 */
import type { Address, Hex } from 'viem';
import type { Rail } from '@mova/ramp';
import { newPixSalt, pixKeyCommitment, railMask } from '@mova/ramp';
import { ChainRevert, NATIVE, sameAddress, type OnChainOffer } from './chain.js';
import { errorText, short, type NodeContext, type TickView } from './context.js';
import type { OfferFunding } from './gateway.js';
import type { PriceFeed } from './price-feed.js';
import { amountForCredit, quoteOffer, repriceReason, type NoQuoteReason, type OfferPricing } from './pricing.js';

export interface OfferAssetConfig {
  asset: Address;
  /** For logs and dashboards only. */
  symbol: string;
  /** Liquidity to keep posted, base units. */
  liquidity: bigint;
  minOrder: bigint;
  maxOrder: bigint;
  /** Must be allowed on the escrow; the LP's choice of whose attestations release its crypto. */
  verifier: Address;
  rails: Rail[];
  pricing: OfferPricing;
  /** Top the active offer up when its unlocked liquidity falls below this share of `liquidity`. */
  refillBelowBps: number;
  maxOfferBrlCents?: bigint;
  /** Native ETH kept back for gas. Ignored for tokens. */
  gasReserveWei?: bigint;
  feed: PriceFeed;
  /**
   * Set by the node on the gateway's Movva only: the gateway mints what the wallet lacks for a post or
   * a top-up, and states what a Movva costs, which the quote must cover (pricing.ts).
   */
  gateway?: OfferFunding;
}

export type PullReason = NoQuoteReason | 'asset_disabled' | 'not_eligible' | 'verifier_revoked'
  | 'insufficient_liquidity' | 'insufficient_credit'
  /** A bank-rail book on a verifier whose prover proves none of its rails, or that the escrow refuses for it. */
  | 'bank_rail_needs_zktls';

export interface AssetQuoteStatus {
  asset: Address;
  symbol: string;
  quoting: boolean;
  reason?: PullReason;
  activeOfferId?: Hex;
  price?: bigint;
  available?: bigint;
  locked?: bigint;
  oraclePrice?: bigint;
  referencePrice?: bigint;
}

export class OfferManager {
  readonly status = new Map<string, AssetQuoteStatus>();

  constructor(
    private readonly ctx: NodeContext,
    private readonly o: { pixKey: string; assets: readonly OfferAssetConfig[] },
  ) {}

  async tick(view: TickView): Promise<void> {
    for (const a of this.o.assets) {
      this.unfunded = 0n;
      try {
        await this.asset(a, view);
      } catch (e) {
        this.ctx.metrics.inc('mova_lp_tick_errors_total', { stage: 'offers' });
        this.ctx.log.error(`offers ${a.symbol}: ${errorText(e)}`);
      } finally {
        // Movva the offer asked for and did not post - a refused top-up, a post that threw - stays in the
        // wallet for the next tick rather than being redeemed and minted again.
        a.gateway?.holdForOffers(this.unfunded);
      }
    }
  }

  /** For a gateway asset: what this tick's post or top-up wanted and has not yet put in an offer. */
  private unfunded = 0n;

  /** Closed offers with nothing left in them; not re-read until restart. */
  private readonly drained = new Set<string>();

  /** Offers closed and empty: nothing can return to them, so a compacted journal need not follow them. */
  drainedOffers(): ReadonlySet<string> {
    return this.drained;
  }

  private async mine(asset: Address): Promise<{ id: Hex; offer: OnChainOffer }[]> {
    const out: { id: Hex; offer: OnChainOffer }[] = [];
    for (const t of this.ctx.store.offers.values()) {
      if (t.asset && !sameAddress(t.asset, asset)) continue;
      if (this.drained.has(t.offerId.toLowerCase())) continue;
      const offer = await this.ctx.chain.offer(t.offerId);
      if (!sameAddress(offer.lp, this.ctx.chain.account)) continue; // reorged away, or not ours
      if (!t.asset) this.ctx.store.record({ t: 'offer.mine', offerId: t.offerId, asset: offer.asset });
      if (!sameAddress(offer.asset, asset)) continue;
      if (!offer.active && offer.availableWei === 0n && offer.lockedWei === 0n) {
        this.drained.add(t.offerId.toLowerCase());
        continue;
      }
      out.push({ id: t.offerId, offer });
    }
    return out;
  }

  /**
   * An order that ends unpaid returns its liquidity to its offer's `availableWei` - even when the
   * offer was closed while the order ran (FiatEscrow._unlock). That liquidity is idle, and its
   * credit stays reserved, until `closeOffer` is called again; so the node sweeps it. (An order the
   * taker disputed is the exception: it left the offer at the dispute, and if it ends unpaid it is
   * paid to the LP's wallet directly - SRM1-4 - so there is nothing to sweep.)
   */
  private async sweep(a: OfferAssetConfig, offers: { id: Hex; offer: OnChainOffer }[]): Promise<void> {
    for (const x of offers) {
      if (!x.offer.active && x.offer.availableWei > 0n) await this.close(x.id, a, 'sweep');
    }
  }

  private async asset(a: OfferAssetConfig, view: TickView): Promise<void> {
    const { chain, metrics, log } = this.ctx;
    const labels = this.labels(a);
    const key = a.asset.toLowerCase();
    const offers = await this.mine(a.asset);
    await this.sweep(a, offers);
    const active = offers.filter((x) => x.offer.active);
    const locked = offers.reduce((s, x) => s + x.offer.lockedWei, 0n);
    metrics.set('mova_lp_offer_locked_units', Number(locked), labels);

    const pull = async (reason: PullReason) => {
      for (const x of active) {
        // Re-read: a reprice earlier in this tick may already have closed it.
        if ((await chain.offer(x.id)).active) await this.close(x.id, a, reason);
      }
      metrics.inc('mova_lp_quote_pulled_total', { ...labels, reason });
      metrics.set('mova_lp_quoting', 0, labels);
      metrics.set('mova_lp_offer_available_units', 0, labels);
      const prev = this.status.get(key);
      if (prev?.reason !== reason) log.warn(`${a.symbol}: not quoting (${reason})`);
      this.status.set(key, { asset: a.asset, symbol: a.symbol, quoting: false, reason, locked });
    };

    const cfg = await chain.asset('onramp', a.asset);
    if (!cfg.enabled) return pull('asset_disabled');
    const [oracle, reference, bandBps, credit, verifierOk, cost] = await Promise.all([
      chain.oraclePrice(cfg.oracle).catch(() => undefined),
      a.feed.price(),
      chain.bandBps('onramp'),
      chain.credit(),
      chain.verifierAllowed('onramp', a.verifier),
      a.gateway ? a.gateway.offerCost(view) : undefined,
    ]);
    const quote = quoteOffer({ reference, oracle, bandBps, chainNow: view.chainNow, wallNow: view.wallNow, cfg: a.pricing, cost });
    if (!quote.ok) return pull(quote.reason);
    if (!credit.setupComplete || credit.capCents === 0n) return pull('not_eligible');
    if (!verifierOk) return pull('verifier_revoked');
    const prover = this.ctx.provers.get(a.verifier.toLowerCase());
    if (prover && !a.rails.some((r) => prover.rails.includes(r))) {
      // A zkTLS verifier with no prover here is a passive book (the taker proves); one whose prover proves none of
      // this book's rails is a mistake.
      return pull('bank_rail_needs_zktls');
    }

    // Newest first; everything after the first is an extra and goes.
    const newestFirst = [...active].reverse();
    let current: { id: Hex; offer: OnChainOffer } | undefined = newestFirst[0];
    for (const extra of newestFirst.slice(1)) await this.close(extra.id, a, 'duplicate');

    if (current) {
      const why = repriceReason({ posted: current.offer.priceBrlCentsPerEth, quote, bandBps, cfg: a.pricing });
      if (why) {
        log.info(`${a.symbol}: repricing ${short(current.id)} (${why}) ${current.offer.priceBrlCentsPerEth} -> ${quote.price}`);
        await this.close(current.id, a, why);
        current = undefined;
      }
    }
    const decimals = cfg.decimals;
    if (current) {
      const refillAt = (a.liquidity * BigInt(a.refillBelowBps)) / 10_000n;
      if (current.offer.availableWei < refillAt) {
        const fresh = await chain.credit();
        let delta = a.liquidity - current.offer.availableWei;
        const byCredit = amountForCredit(fresh.availableCents, current.offer.priceBrlCentsPerEth, decimals);
        if (byCredit < delta) delta = byCredit;
        if (a.gateway && delta >= a.minOrder) {
          // The top-up before the wallet limits it is the gateway's need; it mints what the wallet lacks.
          this.unfunded = delta;
          await a.gateway.fund(delta, view);
        }
        const spendable = await this.spendable(a);
        if (spendable < delta) delta = spendable;
        if (delta >= a.minOrder) {
          try {
            await chain.fundOffer(current.id, a.asset, delta);
            this.unfunded = 0n;
            metrics.inc('mova_lp_offer_actions_total', { ...labels, action: 'fund' });
            log.info(`${a.symbol}: topped up ${short(current.id)} by ${delta}`);
            current = { id: current.id, offer: await chain.offer(current.id) };
          } catch (e) {
            log.warn(`${a.symbol}: top-up refused: ${errorText(e)}`);
          }
        }
      }
    } else {
      const posted = await this.post(a, quote.price, decimals, view);
      if (typeof posted === 'string') return pull(posted);
      current = posted;
    }

    metrics.set('mova_lp_quoting', 1, labels);
    metrics.set('mova_lp_offer_price_brl_cents', Number(current.offer.priceBrlCentsPerEth), labels);
    metrics.set('mova_lp_offer_available_units', Number(current.offer.availableWei), labels);
    this.status.set(key, {
      asset: a.asset, symbol: a.symbol, quoting: true, activeOfferId: current.id,
      price: current.offer.priceBrlCentsPerEth, available: current.offer.availableWei, locked,
      oraclePrice: quote.oracle, referencePrice: quote.reference,
    });
  }

  private labels(a: OfferAssetConfig): Record<string, string> {
    return { asset: a.asset.toLowerCase(), symbol: a.symbol };
  }

  private async spendable(a: OfferAssetConfig): Promise<bigint> {
    const bal = await this.ctx.chain.balance(a.asset);
    const reserve = sameAddress(a.asset, NATIVE) ? (a.gasReserveWei ?? 50_000_000_000_000_000n) : 0n;
    return bal > reserve ? bal - reserve : 0n;
  }

  private async post(
    a: OfferAssetConfig, price: bigint, decimals: number, view: TickView,
  ): Promise<{ id: Hex; offer: OnChainOffer } | 'insufficient_liquidity' | 'insufficient_credit' | 'bank_rail_needs_zktls'> {
    const { chain, store, metrics, log } = this.ctx;
    const credit = await chain.credit();
    if (a.gateway) {
      // What the offer would take if the wallet held enough: that, less the wallet, is what to mint.
      let want = a.liquidity;
      const byCredit = amountForCredit(credit.availableCents, price, decimals);
      if (byCredit < want) want = byCredit;
      if (a.maxOfferBrlCents !== undefined) {
        const byCap = amountForCredit(a.maxOfferBrlCents, price, decimals);
        if (byCap < want) want = byCap;
      }
      if (want > 0n && want >= a.minOrder) {
        this.unfunded = want;
        await a.gateway.fund(want, view);
      }
    }
    const spendable = await this.spendable(a);
    let amount = a.liquidity;
    if (spendable < amount) amount = spendable;
    let limitedByCredit = false;
    const byCredit = amountForCredit(credit.availableCents, price, decimals);
    if (byCredit < amount) { amount = byCredit; limitedByCredit = true; }
    if (a.maxOfferBrlCents !== undefined) {
      const byCap = amountForCredit(a.maxOfferBrlCents, price, decimals);
      if (byCap < amount) amount = byCap;
    }
    if (amount < a.minOrder || amount === 0n) return limitedByCredit ? 'insufficient_credit' : 'insufficient_liquidity';

    // The salt is durable before the offer exists: an offer whose salt died with the process
    // could never tell a taker where to pay. A fresh one per offer, so two offers' commitments
    // do not link to each other.
    const maxOrder = a.maxOrder < amount ? a.maxOrder : amount;
    const salt = newPixSalt();
    const commitment = pixKeyCommitment(this.o.pixKey, salt);
    store.record({ t: 'offer.salt', asset: a.asset, salt, commitment });
    try {
      const r = await chain.postOffer({
        asset: a.asset, amount, priceBrlCentsPerUnit: price, pixKeyHash: commitment,
        minOrder: a.minOrder, maxOrder, verifier: a.verifier, railMask: railMask(...a.rails),
      });
      store.record({ t: 'offer.mine', offerId: r.offerId, asset: a.asset, tx: r.hash });
      this.unfunded = 0n;
      metrics.inc('mova_lp_offer_actions_total', { ...this.labels(a), action: 'post' });
      log.info(`${a.symbol}: posted ${short(r.offerId)}: ${amount} base units at ${price} centavos/unit`);
      return { id: r.offerId, offer: await chain.offer(r.offerId) };
    } catch (e) {
      if (e instanceof ChainRevert && e.errorName === 'LPNotEligible') return 'insufficient_credit';
      if (e instanceof ChainRevert && e.errorName === 'BankRailNeedsZkTls') return 'bank_rail_needs_zktls';
      throw e;
    }
  }

  private async close(offerId: Hex, a: OfferAssetConfig, reason: string): Promise<void> {
    try {
      await this.ctx.chain.closeOffer(offerId);
      this.ctx.metrics.inc('mova_lp_offer_actions_total', { ...this.labels(a), action: 'close' });
      this.ctx.log.info(`${a.symbol}: closed ${short(offerId)} (${reason})`);
    } catch (e) {
      this.ctx.log.error(`${a.symbol}: could not close ${short(offerId)} (${reason}): ${errorText(e)}`);
      throw e;
    }
  }
}
