/**
 * Filing the LP's side of a dispute with the arbitration desk: commitments to evidence, never the evidence.
 *
 * ## What leaves the node, and what stays
 *
 * A disputed order or sale turns on facts only the LP's bank holds: the credit that paid it, the
 * transfer the LP made. The desk (packages/ramp/src/arbitration-service.ts) records
 * evidence as a keccak256 digest, a kind, and a party's signature over both; the material itself passes
 * between the parties and the arbitrator off-chain. So the node sends exactly that:
 *
 *  - **digest** = keccak256 of the evidence material: canonical JSON (keys sorted, bigints tagged) of
 *    `{ domain, kind, salt, facts }`, where `facts` is the record the node matched or made - the credit, the
 *    capture, the payment result - and `salt` is 32 random bytes. The salt is journaled with the digest, so
 *    the LP regenerates the exact material (`evidenceMaterial`) to hand the arbitrator; it also means a
 *    digest over guessable facts (an amount, a key) cannot be tested against guesses;
 *  - **kind** from a fixed vocabulary (`pix-credit`, `boleto-credit`, `lp-payment`, ...);
 *  - **signature**: EIP-712 `Evidence(caseId, orderId, digest, kind)` under the desk's evidence domain, by the
 *    LP key - the desk derives the submitting side from it, and refuses anyone not a party.
 *
 * Never sent: a PIX key, a salt that opens an on-chain commitment, a boleto line, a bank id, a
 * payer document, an amount, or a `uri`. The case is found by its escrow and order id
 * (`GET /cases?escrow=&orderId=`), and opened only when there is none, with a reason that says nothing
 * about the payment. A desk too old to have that lookup is reported as such, not worked around.
 *
 * ## Once, across restarts
 *
 * Each item is fixed when its `evidence.prepared` record is written, a case id when `evidence.case` is, and
 * a submission when `evidence.submitted` is. A desk that is down, or refuses for now (the dispute not yet
 * read as DISPUTED, say), is tried again next tick; one that already holds a digest answers so, and that
 * counts as submitted.
 */
import { keccak256, toBytes, type Address, type Hex } from 'viem';
import { EVIDENCE_TYPES, evidenceDomain, newPixSalt } from '@mova/ramp';
import type { Leg } from './chain.js';
import { errorText, short, type NodeContext } from './context.js';

export const EVIDENCE_MATERIAL_DOMAIN = 'mova-lp/evidence/v1';

export type EvidenceKind = 'pix-credit' | 'boleto-credit' | 'pix-refund' | 'lp-payment';

export interface EvidenceItem {
  kind: EvidenceKind;
  /** The record the node holds: hashed, never sent. */
  facts: unknown;
}

/** Keys sorted at every depth and bigints as tagged strings, so one set of facts has one encoding. */
function canonical(v: unknown): unknown {
  if (typeof v === 'bigint') return { $n: v.toString() };
  if (Array.isArray(v)) return v.map(canonical);
  if (v && typeof v === 'object') {
    return Object.fromEntries(Object.keys(v as object).sort()
      .filter((k) => (v as Record<string, unknown>)[k] !== undefined)
      .map((k) => [k, canonical((v as Record<string, unknown>)[k])]));
  }
  return v;
}

/** The material behind a commitment: what the LP hands the arbitrator, and nobody else. */
export function evidenceMaterial(kind: EvidenceKind, facts: unknown, salt: Hex): string {
  return JSON.stringify(canonical({ domain: EVIDENCE_MATERIAL_DOMAIN, kind, salt, facts }));
}

export const evidenceCommitment = (kind: EvidenceKind, facts: unknown, salt: Hex): Hex =>
  keccak256(toBytes(evidenceMaterial(kind, facts, salt)));

/** A viem LocalAccount has this shape: the LP key. */
export interface EvidenceSigner {
  readonly address: Address;
  signTypedData(args: {
    domain: ReturnType<typeof evidenceDomain>;
    types: typeof EVIDENCE_TYPES;
    primaryType: 'Evidence';
    message: { caseId: string; orderId: Hex; digest: Hex; kind: string };
  }): Promise<Hex>;
}

export class ArbitrationUnavailable extends Error {}

/** The desk answers, but predates `GET /cases?escrow=&orderId=`: it must be upgraded, not guessed around. */
export class ArbitrationDeskTooOld extends ArbitrationUnavailable {}

/** The desk service's HTTP API, as far as a party uses it. */
export class ArbitrationClient {
  constructor(
    private readonly baseUrl: string,
    private readonly fetchImpl: typeof fetch = fetch,
    private readonly timeoutMs = 10_000,
  ) {}

  private async call(path: string, body?: unknown): Promise<{ status: number; error: string; json: Record<string, unknown> }> {
    const res = await this.fetchImpl(`${this.baseUrl.replace(/\/$/, '')}${path}`, body === undefined
      ? { method: 'GET', headers: { accept: 'application/json' }, signal: AbortSignal.timeout(this.timeoutMs) }
      : { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body), signal: AbortSignal.timeout(this.timeoutMs) });
    const json = await res.json().catch(() => ({})) as Record<string, unknown>;
    return { status: res.status, error: typeof json.error === 'string' ? json.error : '', json };
  }

  /** The case for this escrow and order, or undefined when the desk has none. */
  async findCase(ref: { orderId: Hex; escrow: Address }): Promise<string | undefined> {
    const r = await this.call(`/cases?escrow=${ref.escrow}&orderId=${ref.orderId}`);
    if (r.status === 200 && typeof r.json.caseId === 'string') return r.json.caseId;
    if (r.status === 404 && r.error === 'no such case') return undefined;
    // An older desk has no such route: its unknown-route 404 lists the routes it does have.
    if (r.status === 404 || r.status === 405) {
      throw new ArbitrationDeskTooOld('the arbitration desk has no case lookup by order (GET /cases?escrow=&orderId=): upgrade it to file evidence');
    }
    throw new ArbitrationUnavailable(`the desk could not look the case up (HTTP ${r.status})`);
  }

  /**
   * The case for a disputed id: the one that exists - a counterparty may have filed first, and there is one
   * case per order - or a new one opened as the LP. Opened between the lookup and the open, it is looked up again.
   */
  async caseFor(ref: { orderId: Hex; escrow: Address; leg: Leg; chainId: number }): Promise<string> {
    const existing = await this.findCase(ref);
    if (existing) return existing;
    const r = await this.call('/cases', {
      orderId: ref.orderId, escrow: ref.escrow, leg: ref.leg, chainId: ref.chainId, raisedBy: 'lp', reason: 'evidence from the LP',
    });
    if (r.status === 201 && typeof r.json.caseId === 'string') return r.json.caseId;
    const raced = r.status === 400 && /already has a case/.test(r.error) ? await this.findCase(ref) : undefined;
    if (raced) return raced;
    throw new ArbitrationUnavailable(`the desk opened no case (HTTP ${r.status})`);
  }

  async submit(caseId: string, ev: { digest: Hex; kind: string }, signature: Hex): Promise<void> {
    const r = await this.call(`/cases/${encodeURIComponent(caseId)}/evidence`, { digest: ev.digest, kind: ev.kind, signature });
    if (r.status === 200 || /evidence already submitted/.test(r.error)) return;
    throw new ArbitrationUnavailable(`the desk refused the evidence (HTTP ${r.status})`);
  }
}

export class EvidenceSubmitter {
  private readonly warned = new Set<string>();

  constructor(private readonly ctx: NodeContext, private readonly o: { client: ArbitrationClient; signer: EvidenceSigner }) {}

  /** File every item for a disputed order or sale that is not filed yet. Never throws: the next tick retries. */
  async disputed(leg: Leg, escrow: Address, id: Hex, items: readonly EvidenceItem[]): Promise<void> {
    const { store, metrics, log, chain } = this.ctx;
    for (const it of items) {
      if (store.evidenceFor(leg, id)?.items.some((x) => x.kind === it.kind)) continue;
      const salt = newPixSalt();
      store.record({ t: 'evidence.prepared', leg, id, kind: it.kind, salt, digest: evidenceCommitment(it.kind, it.facts, salt) });
    }
    const ev = store.evidenceFor(leg, id);
    const pending = ev?.items.filter((x) => !x.submitted) ?? [];
    if (!ev || pending.length === 0) return;
    try {
      let caseId = ev.caseId;
      if (!caseId) {
        caseId = await this.o.client.caseFor({ orderId: id, escrow, leg, chainId: chain.chainId });
        store.record({ t: 'evidence.case', leg, id, caseId });
      }
      for (const x of pending) {
        const signature = await this.o.signer.signTypedData({
          domain: evidenceDomain(chain.chainId, escrow), types: EVIDENCE_TYPES, primaryType: 'Evidence',
          message: { caseId, orderId: id, digest: x.digest, kind: x.kind },
        });
        await this.o.client.submit(caseId, { digest: x.digest, kind: x.kind }, signature);
        store.record({ t: 'evidence.submitted', leg, id, digest: x.digest });
        metrics.inc('mova_lp_evidence_submitted_total', { leg });
        log.info(`${leg}: filed a ${x.kind} commitment for disputed ${short(id)}`);
      }
    } catch (e) {
      metrics.inc('mova_lp_evidence_errors_total', { leg });
      const why = e instanceof ArbitrationUnavailable ? e.message : errorText(e);
      if (e instanceof ArbitrationDeskTooOld) metrics.inc('mova_lp_evidence_errors_total', { leg, reason: 'desk_too_old' });
      if (!this.warned.has(`${leg}:${id}:${why}`)) {
        this.warned.add(`${leg}:${id}:${why}`);
        log.warn(`${leg}: could not file evidence for disputed ${short(id)} yet: ${why}`);
      }
    }
  }
}
