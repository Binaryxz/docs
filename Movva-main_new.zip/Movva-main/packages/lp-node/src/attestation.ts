/**
 * Getting from "the bank shows a settled payment" to proof bytes an escrow accepts.
 *
 * ## Who proves what, per the contracts
 *
 * Both escrows ask the offer's (or sale's) verifier `verifyPayment(id, proof)`, and settlement is
 * callable by anyone holding a valid proof - the payout destination is fixed on-chain, so the
 * submitter is a courier. What differs is which verifier a rail may name, and who can PRODUCE its proof:
 *
 *  - **zkTLS** (`ReclaimZkTlsVerifier`), for every bank payment: PIX and boleto, on both ramps. The
 *    escrows open a bank-rail offer or sale only on a verifier whose `provesBankSession()` is true
 *    (`BankRailNeedsZkTls` otherwise; Mova's decision, 14 September 2026). The proof is a TLS session
 *    with the bank, observed by witnesses who can refuse to attest but cannot invent the response. On
 *    the on-ramp the LP proves the credit it received, or the taker proves their own payment; on the
 *    off-ramp the LP proves the PIX it sent or the bill it paid. `ZkTlsProver` (zktls.ts).
 *
 * There is no other proof: the attestor quorum existed for card captures alone and was removed with the card rail
 * on 24 September 2026 (docs/card-rail-removal.md).
 *
 * A prover is registered per verifier address and declares the rails it proves (`rails`). A payment on
 * a rail its verifier's prover does not prove means: on-ramp, passive (the taker may prove); off-ramp,
 * never claim (the LP could pay and then be unable to prove it).
 *
 * ## payerRef
 *
 * `payerRef` is "opaque, stable per payer; for dispute + sanctions review". A bare hash of a CPF
 * is neither opaque nor safe - the space is small enough to enumerate (see pixKeyCommitment in
 * @mova/ramp) - so the node derives it as a keyed hash under a secret only the LP holds. The LP
 * can re-derive it for any payer it is asked about; nobody reading the chain can.
 */
import { encodeAbiParameters, keccak256, type Address, type Hex } from 'viem';
import { Rail, type ObservedPayment, type OrderTerms } from '@mova/ramp';
import type { Leg } from './chain.js';

export interface PaymentProver {
  /** The verifier contract whose proofs this produces. */
  readonly verifier: Address;
  /**
   * The rails whose payments it proves: PIX and BOLETO. The node
   * asks a prover only for these, and treats a payment on any other rail as one it cannot prove.
   */
  readonly rails: readonly Rail[];
  /** The caller hands over the disclosure with the payment: a prover resolves nothing from the node's journal. */
  provePix(terms: OrderTerms, claim: PixClaim): Promise<Hex>;
  proveBoleto(terms: OrderTerms, claim: BoletoClaim): Promise<Hex>;
}

/**
 * A PIX payment as the node's bank showed it, with the disclosure a prover needs to find and open it:
 * the institution's id, unhashed - and the key credited and the salt that
 * open the offer's or sale's commitment. The on-ramp and off-ramp take them from their journal.
 */
export interface PixClaim {
  /**
   * The id the node's bank reports (`IncomingPayment.bankTxId`, `OutgoingPaymentResult.bankTxId`).
   */
  bankTxId: string;
  /** The key credited. */
  pixKey: string;
  salt: Hex;
  payerRef: Hex;
  amountBrlCents: bigint;
  /** Settlement time, unix seconds. */
  paidAt: bigint;
  /**
   * Which side of the LP's account the payment is on: `onramp`, a credit it received; `offramp`, a payment it made.
   * A zkTLS proof is of a receipt page, and those are different pages (`ZkTlsProver` requires it).
   */
  leg?: Leg;
}

/** A boleto payment as the node's bank showed it, with its disclosure: the raw authentication code, the line paid, the salt. */
export interface BoletoClaim {
  bankTxId: string;
  line: string;
  salt: Hex;
  payerRef: Hex;
  amountBrlCents: bigint;
  paidAt: bigint;
  /** As `PixClaim.leg`: the boleto the LP registered, paid (`onramp`), or the bill it paid (`offramp`). */
  leg?: Leg;
}

export class ProofUnavailable extends Error {}

/**
 * Why a payment does not prove the order - the escrow's own checks, before a proof is built - or undefined: a payment to another payee, for less, on another rail or before the lock
 * settles nothing.
 */
export function whyPaymentDoesNotProve(terms: OrderTerms, rail: Rail, p: ObservedPayment): string | undefined {
  if (Number(p.rail) !== rail) return `a ${Rail[p.rail] ?? `rail ${p.rail}`} payment, not ${Rail[rail]}`;
  if (terms.acceptedRails && !terms.acceptedRails.includes(rail)) return `a ${Rail[rail]} payment, a rail the order does not accept`;
  if (p.payeeKeyHash.toLowerCase() !== terms.payeeKeyHash.toLowerCase()) return 'a payment to another payee than the order commits to';
  if (rail === Rail.BOLETO && p.amountBrlCents !== terms.brlCents) return `${p.amountBrlCents} centavos, where a boleto pays exactly the order's ${terms.brlCents}`;
  if (p.amountBrlCents < terms.brlCents) return `${p.amountBrlCents} centavos, less than the order's ${terms.brlCents}`;
  if (p.paidAt < terms.lockedAt) return 'a payment made before the lock or the boleto\'s issue';
  return undefined;
}

export const PAYER_REF_DOMAIN = 'mova-lp/payer-ref/v1';

/** A stable, non-enumerable reference to a payer, keyed by a secret the LP holds. */
export function payerRef(payerId: string | undefined, secret: Hex): Hex {
  return keccak256(encodeAbiParameters(
    [{ type: 'string' }, { type: 'string' }, { type: 'bytes32' }],
    [PAYER_REF_DOMAIN, payerId ?? '', secret],
  ));
}
