/**
 * The node's memory: an append-only JSON-lines file, fsynced record by record.
 *
 * ## Why this, and why it is the part everything else leans on
 *
 * The chain remembers everything on-chain; nothing remembers what the LP did off-chain. The
 * journal holds exactly the facts a restart cannot recover from the chain, and whose loss costs
 * money:
 *
 *  - **payment intents**, written before the bank is called, so a crash between "the bank
 *    accepted the transfer" and "we recorded it" is resolved by asking the bank about that
 *    idempotency key - never by sending a fresh transfer;
 *  - **salts** for PIX-key and boleto commitments, without which the node cannot tell a taker
 *    where to pay or an attestor what was paid;
 *  - **payee disclosures** from sellers, and boletos registered at the bank;
 *  - the event cursor and the orders and sales being tracked.
 *
 * ## Durability, stated precisely
 *
 * `append` returns only after `fsync`. So a record the caller saw acknowledged survives power
 * loss, and the only thing a crash can leave behind is a torn final line - which was never
 * acknowledged, so dropping it is correct. `load` cuts the file back to the last complete line,
 * as `JsonlVaultStore` in @mova/viewing-key does: otherwise the next append is glued onto the
 * fragment, losing that record on the following restart and corrupting the one after.
 *
 * A malformed line that is NOT the last is not a torn write; it is corruption or tampering, and
 * the journal refuses to load rather than start with a hole in its memory of payments made.
 *
 * The file is created 0600. It holds PIX keys sellers disclosed and the salts that unlink
 * commitments from them; it is as sensitive as the bank credentials and belongs on the same
 * encrypted volume.
 *
 * ## Compaction, and why a crash at any step leaves a readable journal
 *
 * `compact(records)` replaces the whole file with `records` (the store's snapshot):
 *
 *  1. write them to `<path>.compact`, created 0600, and fsync it;
 *  2. `rename` it over `<path>` - atomic: a reader sees the old file or the new one, never a mix;
 *  3. fsync the directory, so the rename survives power loss, and reopen for appending on the new file.
 *
 * A crash before 2 leaves the old journal whole and a `.compact` file that `load` deletes: it was never
 * the journal. A crash after 2 leaves the new journal whole - it was fsynced before it got the name. Power
 * lost after 2 and before 3 can leave either name on disk, and either file is a complete journal. Nothing
 * is appended between the snapshot being taken and the new file being opened: one writer, synchronous.
 */
import {
  closeSync, existsSync, fsyncSync, mkdirSync, openSync, readFileSync, renameSync, statSync, truncateSync, unlinkSync, writeSync,
} from 'node:fs';
import { dirname } from 'node:path';

/** bigint does not survive JSON, and every amount here is one. Tagged, so a string stays a string. */
const replacer = (_k: string, v: unknown) => (typeof v === 'bigint' ? { $n: v.toString() } : v);
const reviver = (_k: string, v: unknown) => {
  if (v && typeof v === 'object' && !Array.isArray(v)) {
    const keys = Object.keys(v);
    if (keys.length === 1 && keys[0] === '$n' && typeof (v as { $n: unknown }).$n === 'string') {
      return BigInt((v as { $n: string }).$n);
    }
  }
  return v;
};

export const encodeRecord = (rec: unknown): string => JSON.stringify(rec, replacer);
export const decodeRecord = <T>(line: string): T => JSON.parse(line, reviver) as T;

export interface Journal<T> {
  /** Every durable record, in append order. Must be called once before `append`. */
  load(): T[];
  /** Durably append one record; returns only once it is on disk. */
  append(rec: T): void;
  close(): void;
  /** Bytes the journal holds now. */
  size?(): number;
  /** Atomically replace every record with `records`. Returns only once the new journal is durable. */
  compact?(records: T[]): void;
}

export type CompactStep = 'written' | 'renamed';

export class JournalCorrupt extends Error {}

export class JsonlJournal<T> implements Journal<T> {
  private fd?: number;
  private bytes = 0;

  /** `onCompactStep` is for tests: throwing from it is a crash at that step. */
  constructor(private readonly path: string, private readonly o: { onCompactStep?: (step: CompactStep) => void } = {}) {}

  private get tmp(): string {
    return `${this.path}.compact`;
  }

  load(): T[] {
    const out: T[] = [];
    // A compaction that never reached its rename: never the journal, and not to be mistaken for one.
    if (existsSync(this.tmp)) unlinkSync(this.tmp);
    if (existsSync(this.path)) {
      const buf = readFileSync(this.path);
      const text = buf.toString('utf8');
      let offset = 0;
      while (offset < text.length) {
        const nl = text.indexOf('\n', offset);
        if (nl === -1) {
          truncateSync(this.path, Buffer.byteLength(text.slice(0, offset)));
          break;
        }
        const line = text.slice(offset, nl);
        if (line.trim() !== '') {
          try {
            out.push(decodeRecord<T>(line));
          } catch {
            throw new JournalCorrupt(`journal corrupt at byte ${Buffer.byteLength(text.slice(0, offset))}`);
          }
        }
        offset = nl + 1;
      }
    } else {
      mkdirSync(dirname(this.path), { recursive: true, mode: 0o700 });
    }
    const created = !existsSync(this.path);
    this.fd = openSync(this.path, 'a', 0o600);
    if (created) syncDir(dirname(this.path));
    this.bytes = statSync(this.path).size;
    return out;
  }

  append(rec: T): void {
    if (this.fd === undefined) throw new Error('journal not loaded: call load() before append()');
    const line = Buffer.from(`${encodeRecord(rec)}\n`, 'utf8');
    let written = 0;
    while (written < line.length) written += writeSync(this.fd, line, written);
    fsyncSync(this.fd);
    this.bytes += line.length;
  }

  size(): number {
    return this.bytes;
  }

  compact(records: T[]): void {
    if (this.fd === undefined) throw new Error('journal not loaded: call load() before compact()');
    const body = Buffer.from(records.map((r) => `${encodeRecord(r)}\n`).join(''), 'utf8');
    const fd = openSync(this.tmp, 'w', 0o600);
    try {
      let written = 0;
      while (written < body.length) written += writeSync(fd, body, written);
      fsyncSync(fd);
    } finally {
      closeSync(fd);
    }
    this.o.onCompactStep?.('written');
    renameSync(this.tmp, this.path);
    this.o.onCompactStep?.('renamed');
    syncDir(dirname(this.path));
    // The old descriptor names the replaced file: appends through it would be lost.
    closeSync(this.fd);
    this.fd = openSync(this.path, 'a', 0o600);
    this.bytes = body.length;
  }

  close(): void {
    if (this.fd !== undefined) closeSync(this.fd);
    this.fd = undefined;
  }
}

/** A new file's directory entry is only durable once the directory itself is synced. */
function syncDir(dir: string): void {
  try {
    const fd = openSync(dir, 'r');
    try { fsyncSync(fd); } finally { closeSync(fd); }
  } catch {
    // Not every platform can open a directory for sync; the record fsyncs still stand.
  }
}

/** For tests: the same contract in memory, serialising through the same encoding. */
export class MemoryJournal<T> implements Journal<T> {
  readonly lines: string[] = [];
  private loaded = false;

  load(): T[] {
    this.loaded = true;
    return this.lines.map((l) => decodeRecord<T>(l));
  }

  append(rec: T): void {
    if (!this.loaded) throw new Error('journal not loaded: call load() before append()');
    this.lines.push(encodeRecord(rec));
  }

  close(): void {
    this.loaded = false;
  }

  size(): number {
    return this.lines.reduce((n, l) => n + l.length + 1, 0);
  }

  compact(records: T[]): void {
    this.lines.splice(0, this.lines.length, ...records.map((r) => encodeRecord(r)));
  }
}
