/**
 * Reference prices: where the LP's own view of the market comes from.
 *
 * A feed returns `undefined` rather than throwing when it has nothing usable, and never a
 * last-known value it has stopped refreshing: staleness is judged by `pricing.ts` against the
 * timestamp a feed reports, so a feed that fabricates freshness defeats the check. For the same
 * reason `HttpPriceFeed` requires the source to state `updatedAt` itself instead of stamping the
 * time of the request.
 */
import type { Address } from 'viem';
import type { RampChain } from './chain.js';
import type { PricePoint } from './pricing.js';

export interface PriceFeed {
  price(): Promise<PricePoint | undefined>;
}

/** A price set in code or by a test. */
export class StaticPriceFeed implements PriceFeed {
  constructor(public point: PricePoint | undefined) {}

  async price(): Promise<PricePoint | undefined> {
    return this.point;
  }
}

/**
 * The escrow's own oracle as the reference. For an LP that has no feed of its own and accepts
 * the publisher quorum's price: the deviation check then compares the oracle with itself, which
 * is exactly the trust being accepted, and the README says so.
 */
export class OracleReferenceFeed implements PriceFeed {
  constructor(private readonly chain: RampChain, private readonly oracle: Address) {}

  async price(): Promise<PricePoint | undefined> {
    try {
      const p = await this.chain.oraclePrice(this.oracle);
      return { price: p.price, updatedAt: p.updatedAt };
    } catch {
      return undefined;
    }
  }
}

/**
 * Movva's definition as the reference: one whole Movva is R$ 1,00, so 100 centavos, always.
 *
 * It is the one feed stamped with the time it is asked, because it observes no market that could
 * stop: a definition does not go stale. What it cannot tell is whether the reserve still honours the
 * definition - that is the oracle's job (the reserve reads min(1, ratio) of par), and the deviation
 * check between the two pulls a Movva offer once the reserve is under-backed. The configuration
 * allows `par` only for the gateway's Movva, where that holds.
 */
export class ParPriceFeed implements PriceFeed {
  static readonly CENTS_PER_MOVVA = 100n;

  constructor(private readonly wallClock: () => bigint = () => BigInt(Math.floor(Date.now() / 1000))) {}

  async price(): Promise<PricePoint | undefined> {
    return { price: ParPriceFeed.CENTS_PER_MOVVA, updatedAt: this.wallClock() };
  }
}

/**
 * GET a JSON document `{ "brlCentsPerUnit": "<integer>", "updatedAt": <unix seconds> }`.
 * Any other shape is unusable, not guessed at.
 */
export class HttpPriceFeed implements PriceFeed {
  constructor(
    private readonly url: string,
    private readonly fetchImpl: typeof fetch = fetch,
    private readonly timeoutMs = 5_000,
  ) {}

  async price(): Promise<PricePoint | undefined> {
    try {
      const res = await this.fetchImpl(this.url, { signal: AbortSignal.timeout(this.timeoutMs) });
      if (!res.ok) return undefined;
      const body = await res.json() as { brlCentsPerUnit?: unknown; updatedAt?: unknown };
      const raw = body.brlCentsPerUnit;
      const at = body.updatedAt;
      if (!(typeof raw === 'string' || typeof raw === 'number') || !/^\d+$/.test(String(raw))) return undefined;
      if (typeof at !== 'number' || !Number.isInteger(at) || at <= 0) return undefined;
      return { price: BigInt(String(raw)), updatedAt: BigInt(at) };
    } catch {
      return undefined;
    }
  }
}
