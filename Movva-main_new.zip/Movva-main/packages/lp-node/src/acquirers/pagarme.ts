/**
 * A `CardAcquirer` over Stone's Pagar.me API v5: an order with a hosted checkout per Mova order, looked up by
 * the order's `code`, charges reversed with `DELETE /charges/{id}`. Load it with
 * `ACQUIRER_MODULE=packages/lp-node/src/acquirers/pagarme.ts` (the node runs under tsx).
 *
 * ## Why Pagar.me, and what was read (2026-09-14)
 *
 * The candidates were checked in the order the client gave; each of the first three fails a MUST:
 *  - Cielo (developercielo.github.io/manual/linkdepagamentos5, /manual/checkout-cielo, /manual/cielo-ecommerce;
 *    frozen since 14/08/2024, the new docs.cielo.com.br answers automated readers 403). Link de Pagamento has no
 *    idempotency header and no sandbox, and `GET /api/public/v2/merchantOrderNumber/{n}` finds orders only once a
 *    payment was attempted: a link whose creation response is lost cannot be found again, so a retry makes a
 *    second link.
 *  - Rede (developer.userede.com.br/e-rede and its manual PDFs): 403 to every automated reader; nothing verifiable.
 *  - Getnet (docs.globalgetnet.com, Payment Link API 1.0.0 and Global API 1.0.4 OpenAPI, BR supported): a payment
 *    link order (`OrderResponse`, `ReceiptResponse`) carries no `payment_id`, which the only documented cancel
 *    (`POST /dpm/payments-gwproxy/v2/payments/cancel`) needs, and nothing queries a payment by the merchant's
 *    reference. It cannot give card money back from what is documented.
 *
 * Pagar.me v5 has all five: a hosted checkout (`payments[].payment_method: "checkout"`, `checkouts[].payment_url`),
 * `GET /orders?code=`, charge statuses, `DELETE /charges/{charge_id}` (void same day, refund after), and an
 * `Idempotency-Key` header. Sources, read 2026-09-14:
 *  - docs.pagar.me (API v5): /reference/criar-pedido-2, /reference/obter-pedido, /reference/pedidos-1,
 *    /reference/fechar-um-pedido, /reference/listar-cobranças, /reference/checkout-response,
 *    /docs/o-que-%C3%A9 (Idempotência), /reference/autenticação-2, /docs/chaves-de-acesso, /reference/erros-1,
 *    /page/chargeback-novo-status-na-cobrança. **GATED for automation:** docs.pagar.me (and its llms.txt) answers
 *    403 "Hello there, human!" to curl and WebFetch, so their text was read through the search index, not
 *    transcribed. Read them in a browser before go-live.
 *  - Field names, paths and headers are transcribed from Pagar.me's own SDK, generated from its API definition:
 *    github.com/pagarme/pagarme-nodejs-sdk 7.0.1 (commit 0b206e45cdbe, 2026-08-06) `src/controllers/ordersController.ts`,
 *    `chargesController.ts`, `src/models/*` (wire names in their `'snake_case'` schema entries).
 *  - Status strings: github.com/pagarme/ecommerce-module-core `src/Kernel/ValueObjects/ChargeStatus.php` and
 *    `TransactionStatus.php` (Pagar.me's production module), matching the docs' charge statuses.
 *
 * ## Each choice
 *
 *  - **Auth.** HTTP Basic, secret key as the user and an empty password (docs, Autenticação). The key comes only
 *    from `PAGARME_SECRET_KEY_FILE`; every message this module builds goes through `@mova/ops/redact` with it.
 *  - **Hosts.** Production `https://api.pagar.me/core/v5` (SDK). AMBIGUOUS: one docs page says test calls go to the
 *    same host and the `sk_test_` key selects the simulator, another names `https://sdx-api.pagar.me/core/v5` for
 *    `sk_test_`. `PAGARME_BASE_URL` picks; a `sk_test_` key is refused unless `LP_NODE_DEV=1` (a simulated capture
 *    would release real crypto), and a live key is refused on the sandbox host.
 *  - **Reference.** `code` is at most 52 characters (docs, Pedidos), an order id is 66. The code is the first 52 hex
 *    digits of the order id (208 bits of a hash, so no two orders share one), and `metadata.mova_order_id` carries
 *    the whole id; an order whose metadata names another order is not this one's.
 *  - **Idempotent checkout.** `GET /orders?code=` first (every page), and only when nothing carries the code,
 *    `POST /orders` with `Idempotency-Key: <the node's key>`. The docs: one key creates one order even if the body
 *    differs, keys live 24 h, and a second request while the first is in flight answers 409 (thrown, retried next
 *    tick). A lost response is found by the lookup, or replayed by the key.
 *  - **Exact amount, no installments.** One item and one payment for the total; `checkout.credit_card.installments`
 *    is exactly `[{ number: 1, total }]` and `capture: true`. A checkout whose echoed options differ is closed and
 *    refused. Only `credit_card` is accepted.
 *  - **Expiry.** `expires_in` is whole minutes (docs; SDK "Time in minutes for expiration"), rounded DOWN, so the
 *    returned `expires_at` is never after the node's `expiresAt`; under a minute is refused. Whether Pagar.me stops a
 *    payment already on the page at `expires_at` is not stated, so `chargesFor` voids or refunds any authorisation
 *    or capture Pagar.me timestamps after the checkout's `expires_at` (idempotent by charge state and by a key
 *    derived from the charge id) and reports what that left.
 *  - **Cancel checkout.** `PATCH /orders/{id}/closed { status: "canceled" }` ("no more charges can be added").
 *    UNVERIFIED that it disables an open checkout page: the node returns any later charge anyway.
 *  - **Customer.** The docs' errors page shows order creation failing with "Customer not found." without a customer,
 *    and the node knows nothing about the taker, so `customer_id` is the partner's own customer record
 *    (`PAGARME_CUSTOMER_ID`) with `customer_editable: true`. UNVERIFIED: that a checkout order accepts this without a
 *    `billing_address` (the SDK marks it, `accepted_brands`, `items[].category` and `closed` required; its required
 *    flags are known to be loose). The sandbox check shows it.
 *  - **Reversal.** `GET /charges/{id}` first: canceled is SETTLED, `pending_refund` is PENDING, anything but a whole
 *    open authorisation or capture is FAILED. Otherwise `DELETE /charges/{id}` with `{ amount }` (the whole charge)
 *    and `Idempotency-Key: <the node's key>`. `operation_reference` (SDK-required, meaning undocumented) is not sent.
 *    `getReversal` answers from this process's own record of key to charge; after a restart it knows nothing and the
 *    node's repeat of `reverse` under the same key finds the charge canceled (no second DELETE), or is replayed by
 *    Pagar.me within the key's 24 h.
 *  - **Ids.** `acquirerId`/`merchantId` come from `PAGARME_ACQUIRER_ID`/`PAGARME_MERCHANT_ID` (every charge this key
 *    can read is that account's). `transactionId` is Pagar.me's charge id (`ch_...`): it is what cancels and what an
 *    attestor reads; the acquirer's own TID/NSU (`last_transaction.acquirer_tid`/`acquirer_nsu`) is optional in the
 *    schema. `payerId` is `last_transaction.card.id`, never a card number.
 *  - **Status.** `paid` (and `overpaid`/`underpaid`, at `paid_amount`) CAPTURED; `pending` with
 *    `authorized_pending_capture`/`waiting_capture` AUTHORIZED; `canceled` VOIDED (`voided`/`partial_void`, or never
 *    paid) or REFUNDED (`refunded`/`partial_refunded`, or paid); `chargedback` CHARGED_BACK. `processing`, `failed`
 *    and `pending` without an authorisation hold no money and are skipped; any other status is thrown, not guessed.
 *  - **Errors.** HTTP status only (the body's `message` can echo submitted values). 409, 429 and 5xx are retryable;
 *    no rate limit for v5 is published. Lists page with `page`/`size` and follow `paging.next`.
 */
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { request as httpRequest } from 'node:http';
import { request as httpsRequest } from 'node:https';
import { redact } from '@mova/ops/redact';
import type { CardAcquirer, CardCharge, CardCheckout, CardReversalResult, ChargeStatus } from '../card.js';

export const PAGARME_PRODUCTION_URL = 'https://api.pagar.me/core/v5';
export const PAGARME_SANDBOX_URL = 'https://sdx-api.pagar.me/core/v5';
export const PAGARME_CODE_LENGTH = 52;
export const PAGARME_METADATA_KEY = 'mova_order_id';

/*//////////////////////////////////////////////////////////////
                         THE WIRE, AS FAR AS READ
//////////////////////////////////////////////////////////////*/

export interface PagarmeInstallmentOption { number?: number; total?: number }
export interface PagarmeCheckout {
  id?: string; amount?: number; payment_url?: string; status?: string; expires_at?: string; created_at?: string;
  accepted_payment_methods?: string[]; credit_card?: { installments?: PagarmeInstallmentOption[] };
}
export interface PagarmeTransaction {
  id?: string; transaction_type?: string; status?: string; amount?: number; created_at?: string; installments?: number;
  acquirer_tid?: string; acquirer_nsu?: string; acquirer_name?: string; card?: { id?: string };
}
export interface PagarmeCharge {
  id: string; code?: string; amount?: number; paid_amount?: number; canceled_amount?: number; status?: string;
  payment_method?: string; created_at?: string; paid_at?: string; canceled_at?: string; last_transaction?: PagarmeTransaction;
}
export interface PagarmeOrder {
  id: string; code?: string; amount?: number; status?: string; closed?: boolean; created_at?: string;
  metadata?: Record<string, string> | null; charges?: PagarmeCharge[]; checkouts?: PagarmeCheckout[];
}
export interface PagarmeList<T> { data?: T[]; paging?: { total?: number; previous?: string; next?: string } }

export class PagarmeError extends Error {
  constructor(readonly status: number, readonly op: string, readonly retryable: boolean) {
    super(`Pagar.me ${op}: HTTP ${status}${retryable ? ' (retryable)' : ''}`);
  }
}

/*//////////////////////////////////////////////////////////////
                              CONVERSIONS
//////////////////////////////////////////////////////////////*/

const ORDER_ID = /^0x[0-9a-fA-F]{64}$/;

/** The order's `code`: the first 52 hex digits of the order id. */
export function pagarmeOrderCode(reference: string): string {
  if (!ORDER_ID.test(reference)) throw new Error('a Pagar.me checkout reference is an order id (0x and 64 hex digits)');
  return reference.slice(2, 2 + PAGARME_CODE_LENGTH).toLowerCase();
}

/** Centavos as a JSON number; refused rather than rounded past 2^53. */
function toWire(cents: bigint): number {
  if (cents < 0n || cents > BigInt(Number.MAX_SAFE_INTEGER)) throw new Error('amount out of range for Pagar.me');
  return Number(cents);
}

function fromWire(n: unknown, what: string): bigint {
  if (typeof n !== 'number' || !Number.isSafeInteger(n) || n < 0) throw new Error(`Pagar.me ${what} is not a whole number of centavos`);
  return BigInt(n);
}

function seconds(iso: string | undefined, what: string): bigint {
  const ms = iso === undefined ? Number.NaN : Date.parse(iso);
  if (Number.isNaN(ms)) throw new Error(`Pagar.me ${what} is not a timestamp`);
  return BigInt(Math.floor(ms / 1000));
}

const NO_MONEY = new Set(['processing', 'failed', 'pending']);

/** The charge's status as the node's; undefined for a charge that holds no money. Unknown statuses throw. */
export function pagarmeChargeStatus(c: Pick<PagarmeCharge, 'status' | 'paid_at' | 'last_transaction'>): ChargeStatus | undefined {
  const tx = c.last_transaction?.status;
  switch (c.status) {
    case 'paid': case 'overpaid': case 'underpaid': return 'CAPTURED';
    case 'chargedback': return 'CHARGED_BACK';
    case 'canceled':
      if (tx === 'voided' || tx === 'partial_void') return 'VOIDED';
      if (tx === 'refunded' || tx === 'partial_refunded') return 'REFUNDED';
      return c.paid_at ? 'REFUNDED' : 'VOIDED';
    case 'pending':
      return tx === 'authorized_pending_capture' || tx === 'waiting_capture' ? 'AUTHORIZED' : undefined;
    default:
      if (c.status !== undefined && NO_MONEY.has(c.status)) return undefined;
      throw new Error(`Pagar.me charge status "${String(c.status)}" is not one this adapter knows; resolve it by hand`);
  }
}

/*//////////////////////////////////////////////////////////////
                                ADAPTER
//////////////////////////////////////////////////////////////*/

export interface PagarmeOptions {
  /** Including `/core/v5`. Default: production. */
  baseUrl?: string;
  secretKey: string;
  acquirerId: string;
  merchantId: string;
  /** The partner's own customer record the orders are created under (see the header). */
  customerId: string;
  successUrl: string;
  statementDescriptor?: string;
  timeoutMs?: number;
  pageSize?: number;
  /** Unix seconds, for `expires_in`. */
  now?: () => bigint;
}

type Query = Record<string, string>;
const MAX_PAGES = 100;

export class PagarmeAcquirer implements CardAcquirer {
  readonly acquirerId: string;
  readonly merchantId: string;
  private readonly base: string;
  /** Reversal key to charge id, for `getReversal` in this process. */
  private readonly reversalCharges = new Map<string, string>();

  constructor(private readonly o: PagarmeOptions) {
    this.acquirerId = o.acquirerId;
    this.merchantId = o.merchantId;
    this.base = (o.baseUrl ?? PAGARME_PRODUCTION_URL).replace(/\/+$/, '');
  }

  private now(): bigint {
    return this.o.now ? this.o.now() : BigInt(Math.floor(Date.now() / 1000));
  }

  private scrub(text: string): string {
    return redact(text, [this.o.secretKey]);
  }

  /*------------------------------- HTTP -------------------------------*/

  private send(method: string, url: URL, headers: Record<string, string>, body?: string): Promise<{ status: number; body: string }> {
    return new Promise((resolve, reject) => {
      const req = (url.protocol === 'https:' ? httpsRequest : httpRequest)(url, {
        method, timeout: this.o.timeoutMs ?? 15_000,
        headers: { ...headers, ...(body !== undefined ? { 'content-length': String(Buffer.byteLength(body)) } : {}) },
      }, (res) => {
        const chunks: Buffer[] = [];
        res.on('data', (c: Buffer) => chunks.push(c));
        res.on('end', () => resolve({ status: res.statusCode ?? 0, body: Buffer.concat(chunks).toString('utf8') }));
        res.on('error', reject);
      });
      req.on('timeout', () => req.destroy(new Error('request timed out')));
      req.on('error', reject);
      if (body !== undefined) req.write(body);
      req.end();
    });
  }

  private async call<T>(method: 'GET' | 'POST' | 'PATCH' | 'DELETE', path: string, op: string,
    o: { query?: Query; body?: unknown; idempotencyKey?: string } = {}): Promise<T> {
    const url = new URL(this.base + path);
    for (const [k, v] of Object.entries(o.query ?? {})) url.searchParams.set(k, v);
    const body = o.body === undefined ? undefined : JSON.stringify(o.body);
    const headers: Record<string, string> = {
      authorization: `Basic ${Buffer.from(`${this.o.secretKey}:`).toString('base64')}`,
      accept: 'application/json',
      ...(body !== undefined ? { 'content-type': 'application/json' } : {}),
      ...(o.idempotencyKey !== undefined ? { 'idempotency-key': o.idempotencyKey } : {}),
    };
    let res;
    try {
      res = await this.send(method, url, headers, body);
    } catch (e) {
      throw new Error(this.scrub(`Pagar.me ${op}: ${e instanceof Error ? e.message : String(e)}`));
    }
    if (res.status >= 200 && res.status < 300) {
      try {
        return (res.body ? JSON.parse(res.body) : undefined) as T;
      } catch {
        throw new Error(`Pagar.me ${op}: a ${res.status} response that is not JSON`);
      }
    }
    throw new PagarmeError(res.status, op, res.status === 409 || res.status === 429 || res.status >= 500);
  }

  private async getOrder(id: string): Promise<PagarmeOrder | undefined> {
    try {
      return await this.call<PagarmeOrder>('GET', `/orders/${encodeURIComponent(id)}`, 'getOrder');
    } catch (e) {
      if (e instanceof PagarmeError && e.status === 404) return undefined;
      throw e;
    }
  }

  private async getCharge(id: string): Promise<PagarmeCharge | undefined> {
    try {
      return await this.call<PagarmeCharge>('GET', `/charges/${encodeURIComponent(id)}`, 'getCharge');
    } catch (e) {
      if (e instanceof PagarmeError && e.status === 404) return undefined;
      throw e;
    }
  }

  /** Every order carrying this reference's code (and not naming another order), read whole. */
  private async ordersFor(reference: string): Promise<PagarmeOrder[]> {
    const code = pagarmeOrderCode(reference);
    const size = Math.min(Math.max(this.o.pageSize ?? 30, 1), 100);
    const ids: string[] = [];
    for (let page = 1; ; page++) {
      if (page > MAX_PAGES) throw new Error(`Pagar.me listOrders: more than ${MAX_PAGES} pages for one code`);
      const list = await this.call<PagarmeList<PagarmeOrder>>('GET', '/orders', 'listOrders', { query: { code, page: String(page), size: String(size) } });
      for (const o of list?.data ?? []) if (o.code === code && !ids.includes(o.id)) ids.push(o.id);
      if (!list?.paging?.next || !list.data?.length) break;
    }
    const out: PagarmeOrder[] = [];
    for (const id of ids) {
      const order = await this.getOrder(id);
      const named = order?.metadata?.[PAGARME_METADATA_KEY];
      if (order && order.code === code && (named === undefined || named.toLowerCase() === reference.toLowerCase())) out.push(order);
    }
    return out.sort((a, b) => (a.created_at ?? '').localeCompare(b.created_at ?? ''));
  }

  /*----------------------------- checkout -----------------------------*/

  async createCheckout(req: { idempotencyKey: string; amountCents: bigint; expiresAt: bigint; reference: string }): Promise<CardCheckout> {
    const code = pagarmeOrderCode(req.reference);
    const existing = (await this.ordersFor(req.reference)).find((o) => o.checkouts?.length);
    if (existing) return this.toCheckout(existing, req.reference, req.amountCents);
    const minutes = (req.expiresAt - this.now()) / 60n;
    if (minutes < 1n) throw new Error('a Pagar.me checkout needs at least a whole minute before it expires');
    const total = toWire(req.amountCents);
    const order = await this.call<PagarmeOrder>('POST', '/orders', 'createOrder', {
      idempotencyKey: req.idempotencyKey,
      body: {
        code,
        customer_id: this.o.customerId,
        items: [{ amount: total, description: 'Mova on-ramp order', quantity: 1, code }],
        payments: [{
          payment_method: 'checkout',
          amount: total,
          checkout: {
            expires_in: Number(minutes),
            accepted_payment_methods: ['credit_card'],
            success_url: this.o.successUrl,
            skip_checkout_success_page: false,
            customer_editable: true,
            billing_address_editable: true,
            credit_card: {
              capture: true,
              installments: [{ number: 1, total }],
              ...(this.o.statementDescriptor ? { statement_descriptor: this.o.statementDescriptor } : {}),
            },
          },
        }],
        metadata: { [PAGARME_METADATA_KEY]: req.reference.toLowerCase() },
      },
    });
    return this.toCheckout(order, req.reference, req.amountCents);
  }

  private async toCheckout(order: PagarmeOrder, reference: string, total: bigint): Promise<CardCheckout> {
    const c = order.checkouts?.[0];
    if (!order.id || !c?.payment_url) throw new Error('Pagar.me returned an order without a checkout payment_url');
    const amount = fromWire(order.amount ?? c.amount, 'order amount');
    const options = c.credit_card?.installments;
    const oneAtTotal = options === undefined
      || (options.length === 1 && options[0].number === 1 && options[0].total !== undefined && fromWire(options[0].total, 'installment total') === total);
    if (!oneAtTotal) {
      await this.cancelCheckout(order.id).catch(() => undefined);
      throw new Error('Pagar.me created a checkout offering installments other than one at the total; closed it');
    }
    return { checkoutId: order.id, url: c.payment_url, amountCents: amount, expiresAt: seconds(c.expires_at, 'checkout expires_at'), reference };
  }

  async cancelCheckout(checkoutId: string): Promise<void> {
    const order = await this.getOrder(checkoutId);
    if (!order || order.status === 'canceled' || order.status === 'failed') return;
    try {
      await this.call('PATCH', `/orders/${encodeURIComponent(checkoutId)}/closed`, 'closeOrder', { body: { status: 'canceled' } });
    } catch (e) {
      // Refused because it is already closed (paid, say): nothing more can be charged to it either way.
      if (e instanceof PagarmeError && !e.retryable && (await this.getOrder(checkoutId))?.closed) return;
      throw e;
    }
  }

  /*------------------------------ charges ------------------------------*/

  async chargesFor(reference: string): Promise<CardCharge[]> {
    const out: CardCharge[] = [];
    for (const order of await this.ordersFor(reference)) {
      const expiries = (order.checkouts ?? []).filter((c) => c.expires_at).map((c) => seconds(c.expires_at, 'checkout expires_at'));
      const expiry = expiries.length ? expiries.reduce((a, b) => (a < b ? a : b)) : undefined;
      for (const listed of order.charges ?? []) {
        let charge = listed;
        if (charge.payment_method !== 'credit_card') {
          throw new Error(`a Pagar.me ${String(charge.payment_method)} charge carries an order's reference; this adapter takes credit cards only - return it by hand`);
        }
        let status = pagarmeChargeStatus(charge);
        if (status === undefined) continue;
        if ((status === 'AUTHORIZED' || status === 'CAPTURED') && expiry !== undefined && this.authorizedAt(charge) > expiry) {
          const held = status === 'CAPTURED' ? fromWire(charge.paid_amount ?? charge.amount, 'paid_amount') : fromWire(charge.amount, 'amount');
          await this.reverseCharge(charge.id, lateKey(charge.id), held);
          charge = (await this.getCharge(charge.id)) ?? charge;
          status = pagarmeChargeStatus(charge);
          if (status === undefined) continue;
        }
        out.push(this.toCharge(charge, status, reference));
      }
    }
    return out;
  }

  private authorizedAt(c: PagarmeCharge): bigint {
    return seconds(c.last_transaction?.created_at ?? c.created_at, 'charge created_at');
  }

  private toCharge(c: PagarmeCharge, status: ChargeStatus, reference: string): CardCharge {
    return {
      acquirerId: this.acquirerId,
      transactionId: c.id,
      merchantId: this.merchantId,
      reference,
      status,
      amountCents: status === 'CAPTURED' ? fromWire(c.paid_amount ?? c.amount, 'paid_amount') : fromWire(c.amount, 'amount'),
      authorizedAt: this.authorizedAt(c),
      capturedAt: c.paid_at && status !== 'AUTHORIZED' && status !== 'VOIDED' ? seconds(c.paid_at, 'paid_at') : undefined,
      payerId: c.last_transaction?.card?.id,
    };
  }

  /*----------------------------- reversals -----------------------------*/

  async reverse(req: { idempotencyKey: string; transactionId: string; amountCents: bigint; reason: string }): Promise<CardReversalResult> {
    this.reversalCharges.set(req.idempotencyKey, req.transactionId);
    return this.reverseCharge(req.transactionId, req.idempotencyKey, req.amountCents);
  }

  async getReversal(idempotencyKey: string): Promise<CardReversalResult | undefined> {
    const chargeId = this.reversalCharges.get(idempotencyKey);
    if (!chargeId) return undefined;
    const c = await this.getCharge(chargeId);
    return c && this.outcome(c, { idempotencyKey, transactionId: chargeId });
  }

  private outcome(c: PagarmeCharge, base: { idempotencyKey: string; transactionId: string }): CardReversalResult | undefined {
    if (c.status === 'canceled') {
      return {
        ...base, status: 'SETTLED', kind: pagarmeChargeStatus(c) === 'VOIDED' ? 'VOID' : 'REFUND',
        amountCents: fromWire(c.canceled_amount ?? c.amount, 'canceled_amount'),
        at: c.canceled_at ? seconds(c.canceled_at, 'canceled_at') : undefined,
      };
    }
    if (c.last_transaction?.status === 'pending_refund') {
      return { ...base, status: 'PENDING', amountCents: fromWire(c.paid_amount ?? c.amount, 'paid_amount') };
    }
    return undefined;
  }

  private async reverseCharge(chargeId: string, key: string, amountCents: bigint): Promise<CardReversalResult> {
    const base = { idempotencyKey: key, transactionId: chargeId };
    const c = await this.getCharge(chargeId);
    if (!c) return { ...base, status: 'FAILED', failureReason: 'no such charge at Pagar.me' };
    const settled = this.outcome(c, base);
    if (settled) return settled;
    const status = pagarmeChargeStatus(c);
    if (status !== 'AUTHORIZED' && status !== 'CAPTURED') {
      return { ...base, status: 'FAILED', failureReason: `the charge is ${status ?? String(c.status)}` };
    }
    const held = status === 'CAPTURED' ? fromWire(c.paid_amount ?? c.amount, 'paid_amount') : fromWire(c.amount, 'amount');
    if (held !== amountCents) return { ...base, status: 'FAILED', failureReason: 'a reversal is for the whole charge' };
    let after: PagarmeCharge;
    try {
      after = await this.call<PagarmeCharge>('DELETE', `/charges/${encodeURIComponent(chargeId)}`, 'cancelCharge', {
        idempotencyKey: key, body: { amount: toWire(amountCents) },
      });
    } catch (e) {
      if (e instanceof PagarmeError && !e.retryable && e.status !== 401 && e.status !== 403) {
        return { ...base, status: 'FAILED', failureReason: `Pagar.me refused the cancellation (HTTP ${e.status})` };
      }
      throw e;
    }
    return (after && this.outcome(after, base)) ?? { ...base, status: 'PENDING', amountCents };
  }
}

/** The key an expiry reversal runs under: one per charge, whoever notices it. */
function lateKey(chargeId: string): string {
  return `L${createHash('sha256').update(`mova-lp/pagarme-late/v1/${chargeId}`).digest('hex').slice(0, 32)}`;
}

/*//////////////////////////////////////////////////////////////
                              MODULE ENTRY
//////////////////////////////////////////////////////////////*/

type Env = Record<string, string | undefined>;

/**
 * `ACQUIRER_MODULE` entry. Environment:
 *  - `PAGARME_SECRET_KEY_FILE` (required; `PAGARME_SECRET_KEY` itself is refused): `sk_...`, or `sk_test_...` only with `LP_NODE_DEV=1`.
 *  - `PAGARME_ACQUIRER_ID`, `PAGARME_MERCHANT_ID` (required): exactly `onramp.card.acquirerId` / `merchantId`.
 *  - `PAGARME_CUSTOMER_ID` (required): the partner's customer record orders are created under.
 *  - `PAGARME_SUCCESS_URL` (required, https): where the checkout sends the cardholder after paying.
 *  - `PAGARME_BASE_URL` (default production), `PAGARME_STATEMENT_DESCRIPTOR`, `PAGARME_TIMEOUT_MS` (optional).
 */
export function createCardAcquirer(env: Env, readFile: (path: string) => string = (p) => readFileSync(p, 'utf8')): PagarmeAcquirer {
  const problems: string[] = [];
  const need = (name: string): string => {
    const v = env[name]?.trim();
    if (!v) problems.push(`${name} is required`);
    return v ?? '';
  };
  if (env.PAGARME_SECRET_KEY !== undefined) problems.push('set PAGARME_SECRET_KEY_FILE, never PAGARME_SECRET_KEY: a key in the environment shows in docker inspect');
  let secretKey = '';
  const file = need('PAGARME_SECRET_KEY_FILE');
  if (file) {
    try {
      secretKey = readFile(file).trim();
    } catch {
      problems.push('PAGARME_SECRET_KEY_FILE could not be read');
    }
    if (secretKey && !/^sk_[A-Za-z0-9_]+$/.test(secretKey)) problems.push('PAGARME_SECRET_KEY_FILE does not hold a Pagar.me secret key (sk_...)');
  }
  const dev = env.LP_NODE_DEV === '1';
  const testKey = secretKey.startsWith('sk_test_');
  const baseUrl = env.PAGARME_BASE_URL?.trim() || PAGARME_PRODUCTION_URL;
  let url: URL | undefined;
  try {
    url = new URL(baseUrl);
  } catch {
    problems.push('PAGARME_BASE_URL is not a URL');
  }
  if (url && url.protocol !== 'https:' && !dev) problems.push('PAGARME_BASE_URL must be https');
  if (testKey && !dev) problems.push('a sk_test_ key is refused without LP_NODE_DEV=1: a simulated capture would release real crypto');
  if (secretKey && !testKey && url?.host === new URL(PAGARME_SANDBOX_URL).host) problems.push('a live key on the sandbox host');
  const acquirerId = need('PAGARME_ACQUIRER_ID');
  const merchantId = need('PAGARME_MERCHANT_ID');
  const customerId = need('PAGARME_CUSTOMER_ID');
  const successUrl = need('PAGARME_SUCCESS_URL');
  if (successUrl && !/^https:\/\//.test(successUrl) && !dev) problems.push('PAGARME_SUCCESS_URL must be https');
  const timeout = env.PAGARME_TIMEOUT_MS?.trim();
  if (timeout && !/^\d+$/.test(timeout)) problems.push('PAGARME_TIMEOUT_MS must be a whole number');
  if (problems.length) throw new Error(redact(`Pagar.me acquirer: ${problems.join('; ')}`, [secretKey]));
  return new PagarmeAcquirer({
    baseUrl, secretKey, acquirerId, merchantId, customerId, successUrl,
    statementDescriptor: env.PAGARME_STATEMENT_DESCRIPTOR?.trim() || undefined,
    timeoutMs: timeout ? Number(timeout) : undefined,
  });
}
