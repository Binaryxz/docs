/**
 * Per-payer limits: how much BRL one person may move through THIS LP in a Brasília day and month.
 *
 * MVP Scope Rev. 2 §10.1 asks for per-user daily caps in five tiers. This is where they live, and
 * the reasoning that put them here is worth stating, because the obvious place - the escrows - is
 * the wrong one.
 *
 * ## A cap binds a person, and the only place a person exists in this rail is the fiat side
 *
 * On-chain a user is deliberately unlinkable: a fresh taker address per order, a shielded recipient,
 * nothing that ties two purchases together. An on-chain cap would therefore have to be keyed on an
 * address, which is free to create - so it would cap nothing - or on an identity registry, which
 * would undo the privacy the whole design is for.
 *
 * What the LP DOES see is the bank. A PIX credit or a paid boleto names a payer, and
 * the node already derives `payerRef` from it for attestation (attestation.ts). That is the identity a
 * cap can bind, it is the same identity a regulator means by "one person", and it lives only inside one
 * LP node. So caps are here, and only here.
 *
 * ## What the LP learns, and what it does not
 *
 * The ledger below holds rows of `(payerRef, Brasília day, centavos)` and nothing else. It carries no
 * order id, no sale id, no address, no key and no document. Two payments by one person are correlated
 * through `payerRef` - a keccak of their bank identity under `PAYER_REF_SECRET`, which is not
 * enumerable without that secret - and through nothing else. Nothing about a cap reaches the chain,
 * the wallet, the matcher or another LP: a person's tier and totals at this LP are invisible to every
 * other LP, and a counterparty is told only THAT a cap was reached, never the total behind it.
 *
 * What the LP already knew, and what caps do not change: a bank credit arrives with a payer and settles
 * one order, whose taker address is on-chain. An LP can therefore always say "this address paid from
 * this document" for an order it served. Caps add no new join of that kind - they read `payerId` from
 * the payment record the journal already holds and write only the hash - but they do not remove it
 * either. Unlinkability across orders is a property of the CHAIN, not of the LP's bank statement.
 *
 * ## Where the refusal happens, per rail, and why it cannot be earlier
 *
 * A cap can only be applied once the payer is known, and the payer is known at different moments:
 *
 *  - **on-ramp, PIX and boleto**: only when the credit lands. Nothing before that says who will pay -
 *    the taker's address is not a person, and asking it to be one would be the linkage this design
 *    refuses. So the node checks at the credit, BEFORE it proves anything: over the cap, it does not
 *    prove and does not release, the order expires, and the BRL goes back to its payer by PIX
 *    devolução on the existing cancellation path (onramp.ts). The LP's asset never moves.
 *  - **off-ramp**: at the payee disclosure and again before the claim, so a refusal costs nothing at
 *    all: the sale is simply not claimed and another LP may take it.
 *
 * One honest limit: `releaseWithProof` is permissionless, and a taker who paid can prove the payment
 * from their own bank session. A cap this node refuses is therefore a refusal by THIS LP to prove,
 * release and keep the money - not a promise that no order can ever settle. It still counts what
 * happened, so the next payment is refused too.
 *
 * ## Counting
 *
 * The ledger is in the node's journal, so a restart does not forget, and days are Brasília days
 * (`brasiliaToday`, UTC-3, no DST since 2019) because that is the day a Brazilian regulator, a bank
 * statement and a user all mean - a UTC day would reset the cap at 21:00 local.
 *
 * A payment is counted when the node commits to it (the credit it will release against, the payment
 * it is about to send) and un-counted when that money demonstrably goes back (a settled refund, a
 * payment the bank refused): a purchase that was returned did not consume
 * anyone's daily limit. The count is fsynced BEFORE the order is marked as counted, so the only thing
 * a crash between the two can cause is counting the same payment twice - which refuses more, never
 * less.
 *
 * ## Tiers
 *
 * Tiers 0-4, each with an optional daily and monthly limit in centavos; a tier with neither is
 * unlimited, and a node with no `caps` section has no ledger at all and behaves exactly as before.
 * A payer's tier comes from, in order: the `TIER_MODULE` plugin (an LP with its own KYC provider),
 * the static list in `LP_CONFIG`, then `defaultTier` (0). The numbers themselves are the operator's;
 * this ships with none.
 */
import type { Hex } from 'viem';
import { brasiliaToday, normalizePixKey, parseBoleto } from '@mova/ramp';
import { payerRef } from './attestation.js';
import type { Logger } from './context.js';
import type { Metrics } from './metrics.js';
import type { Payee, Store } from './store.js';

/** The tiers Rev. 2 §10.1 names. */
export const TIERS = [0, 1, 2, 3, 4] as const;
export type Tier = (typeof TIERS)[number];
export const isTier = (n: unknown): n is Tier => typeof n === 'number' && (TIERS as readonly number[]).includes(n);

/** A tier's limits, in BRL centavos. An absent limit is no limit. */
export interface TierLimits {
  dailyBrlCents?: bigint;
  monthlyBrlCents?: bigint;
}

/** What the node knows about the payer of one payment, as the bank reports it. */
export interface PayerFacts {
  leg: 'onramp' | 'offramp';
  rail: 'PIX' | 'BOLETO';
  /**
   * The bank's identity for the payer: a CPF/CNPJ, an account reference, or a PIX key. Never journalled, never logged, never served - only hashed into `payerRef`
   * and handed to a `TierSource`, which is the LP's own code.
   */
  payerId?: string;
}

/**
 * An LP's own source of tiers - its KYC provider, its CRM, a list it maintains. Loaded from
 * `TIER_MODULE`, which exports `createTierSource(env): TierSource`, as the bank and prover plugins are.
 * Returning undefined falls through to the configured list and then to `defaultTier`.
 *
 * It is given the raw payer identity, because that is what a KYC system is keyed on. It runs inside the
 * node, sees no order, no sale and no address, and must not block: it is awaited on the path that
 * decides whether money moves. One that throws leaves the tier to the configuration rather than promoting
 * everyone - and its error message is logged, so do not put a document in one.
 */
export interface TierSource {
  tierOf(p: PayerFacts & { payerRef: Hex }): Promise<number | undefined> | number | undefined;
}

export interface CapsOptions {
  /** Limits by tier. Tiers left out, or left empty, are unlimited. */
  tiers: Partial<Record<Tier, TierLimits>>;
  /** The tier of a payer nothing else names. */
  defaultTier: Tier;
  /** `payerRef` (lowercase hex) to tier, from `LP_CONFIG`. Documents are hashed before they get here. */
  payerTiers?: ReadonlyMap<string, Tier>;
  /** The LP's own tier lookup, from `TIER_MODULE`. Consulted first. */
  tierSource?: TierSource;
  /**
   * A payment the bank does not attribute to anyone (API Pix 2.10.0 carries no payer document, so
   * `ApiPixReceiver` reports none). `refuse` is the default: a per-person cap that an unattributable
   * payment walks past is not a cap. `allow` lets it through, uncounted, for an LP that accepts that. Either
   * way, a ledger where no tier states a limit refuses nothing: there would be nothing to walk past.
   */
  unknownPayer?: 'refuse' | 'allow';
}

/** Which rule refused, for a log line, a metric label and a counterparty's refusal code. */
export type CapPeriod = 'day' | 'month' | 'unknown_payer';

export type CapVerdict =
  /** Allowed. `payer` is absent only where there is nobody to hold it against, and then nothing is counted. */
  | { ok: true; payer?: Hex; tier: Tier; day: string }
  | { ok: false; period: CapPeriod; tier: Tier; day: string; limitCents?: bigint };

/** One row of the ledger: no order, no sale, no address, no key. */
export interface CapCount {
  payer: Hex;
  /** Brasília calendar day, `YYYY-MM-DD`. */
  day: string;
  cents: bigint;
}

export interface CapDeps {
  store: Store;
  metrics: Metrics;
  log: Logger;
  /** The same secret `payerRef` is keyed on for attestation: one identity per payer, one node. */
  payerRefSecret: Hex;
}

/** How long a day's rows are kept: two months of history, so a monthly cap is never short of its own window. */
export const CAP_RETENTION_DAYS = 62;

/** The Brasília calendar day of a unix time. */
export const capDay = (wallNow: bigint): string => brasiliaToday(new Date(Number(wallNow) * 1000));
/** The Brasília month of a day, `YYYY-MM`. */
export const capMonth = (day: string): string => day.slice(0, 7);

/** `YYYY-MM-DD` minus `days`, in the calendar - used only for retention, so UTC arithmetic on the date is exact. */
export function dayMinus(day: string, days: number): string {
  const t = Date.parse(`${day}T00:00:00Z`);
  return new Date(t - days * 86_400_000).toISOString().slice(0, 10);
}

/**
 * How a payee identifies a person on the off-ramp. A PIX key IS the bank identity: a CPF or CNPJ key
 * gives the same string the on-ramp's bank reports for that document, so one person buying and selling
 * counts once; a phone, email or random key identifies the account, which is the best the rail offers.
 *
 * A boleto identifies a BILL, not a person - nothing in a barcode names who is being paid in a way the
 * node can compare - so each bill counts under its own identity and a cap does not really bind there.
 * An LP that needs caps on the off-ramp should quote PIX (`offramp.rails`).
 */
export function payerIdForPayee(payee: Payee): string | undefined {
  try {
    if (payee.kind === 'pix') return normalizePixKey(payee.pixKey).key;
    return `boleto:${parseBoleto(payee.line).barcode}`;
  } catch {
    return undefined;
  }
}

/**
 * The ledger and the decision. One per node; absent entirely when no `caps` section is configured,
 * which is why every call site reads `ctx.caps?` and does nothing without one.
 */
export class CapLedger {
  /** Unix seconds of the last ledger write, from the journal - survives a restart. */
  lastCountAt?: number;
  /** Unix seconds the node last attributed BRL that SHOULD have been counted. In memory only. */
  lastMoneyAt?: number;
  private refused = 0;

  constructor(private readonly deps: CapDeps, readonly o: CapsOptions) {
    this.lastCountAt = deps.store.capLedgerLastAt();
    deps.metrics.set('mova_lp_caps_enabled', 1);
  }

  /** True when at least one tier actually limits something; a ledger with none only counts. */
  get limiting(): boolean {
    return Object.values(this.o.tiers).some((t) => t?.dailyBrlCents !== undefined || t?.monthlyBrlCents !== undefined);
  }

  /** The stable, non-enumerable identity of a payer. Undefined when the bank named nobody. */
  identify(payerId: string | undefined): Hex | undefined {
    const id = payerId?.trim();
    return id ? payerRef(id, this.deps.payerRefSecret) : undefined;
  }

  private async tierOf(p: PayerFacts, ref: Hex): Promise<Tier> {
    if (this.o.tierSource) {
      try {
        const t = await this.o.tierSource.tierOf({ ...p, payerRef: ref });
        if (isTier(t)) return t;
        if (t !== undefined) this.deps.log.warn(`caps: TIER_MODULE returned ${String(t)}, which is not a tier 0-4; falling through`);
      } catch (e) {
        // A KYC provider that is down must not silently promote everyone: fall through to the list and the default.
        this.deps.metrics.inc('mova_lp_caps_tier_errors_total');
        this.deps.log.warn(`caps: TIER_MODULE failed for a payer; using the configured tier instead: ${e instanceof Error ? e.message : String(e)}`);
      }
    }
    return this.o.payerTiers?.get(ref.toLowerCase()) ?? this.o.defaultTier;
  }

  limitsOf(tier: Tier): TierLimits {
    return this.o.tiers[tier] ?? {};
  }

  /** What this payer has counted in `day`'s day and month. */
  usage(payer: Hex, day: string): { dayCents: bigint; monthCents: bigint } {
    return this.deps.store.capUsage(payer, day);
  }

  /**
   * May this payer move `cents` now? Nothing is written here: the caller commits with `count` only once
   * it is about to act. `wallNow` is the bank's clock, as everywhere else BRL is judged.
   */
  async check(p: PayerFacts, cents: bigint, wallNow: bigint): Promise<CapVerdict> {
    const day = capDay(wallNow);
    const ref = this.identify(p.payerId);
    if (!ref) {
      const tier = this.o.defaultTier;
      // Nothing is limited, so there is nothing an unnamed payer could walk past.
      if (!this.limiting || (this.o.unknownPayer ?? 'refuse') === 'allow') {
        if (this.limiting) {
          this.deps.log.warn(`caps: a ${p.rail} payment on the ${p.leg} names no payer; the bank attributes it to nobody, and unknownPayer is "allow" - it is not counted`);
        }
        // No payer, so nothing to count and nothing that could later be given back.
        return { ok: true, tier, day };
      }
      this.refuse('unknown_payer', p.leg);
      return { ok: false, period: 'unknown_payer', tier, day };
    }
    const tier = await this.tierOf(p, ref);
    const limits = this.limitsOf(tier);
    const used = this.usage(ref, day);
    // Money the node is about to let through and should therefore count. The monitor compares this with
    // `lastCountAt`: a ledger that cannot be written falls behind it (packages/ops `lp_node_caps`).
    this.lastMoneyAt = Math.floor(Date.now() / 1000);
    if (limits.dailyBrlCents !== undefined && used.dayCents + cents > limits.dailyBrlCents) {
      this.refuse('day', p.leg);
      return { ok: false, period: 'day', tier, day, limitCents: limits.dailyBrlCents };
    }
    if (limits.monthlyBrlCents !== undefined && used.monthCents + cents > limits.monthlyBrlCents) {
      this.refuse('month', p.leg);
      return { ok: false, period: 'month', tier, day, limitCents: limits.monthlyBrlCents };
    }
    return { ok: true, payer: ref, tier, day };
  }

  private refuse(period: CapPeriod, leg: 'onramp' | 'offramp'): void {
    this.refused++;
    this.deps.metrics.inc('mova_lp_caps_refusals_total', { leg, reason: period });
  }

  /**
   * Commit `cents` against a payer's day. Durable before it returns (the journal fsyncs), so the caller
   * marks its order or sale as counted only afterwards: a crash between the two counts twice, which
   * refuses more, never less.
   */
  count(payer: Hex, cents: bigint, wallNow: bigint, leg: 'onramp' | 'offramp'): string {
    const day = capDay(wallNow);
    this.deps.store.record({ t: 'cap.count', payer, day, cents });
    this.lastCountAt = this.deps.store.capLedgerLastAt();
    this.deps.metrics.inc('mova_lp_caps_counted_cents_total', { leg }, Number(cents));
    return day;
  }

  /** Give a payer their allowance back: the money went back to them. */
  uncount(payer: Hex, cents: bigint, day: string, leg: 'onramp' | 'offramp'): void {
    this.deps.store.record({ t: 'cap.uncount', payer, day, cents });
    this.deps.metrics.inc('mova_lp_caps_uncounted_cents_total', { leg }, Number(cents));
  }

  /**
   * What `/status` shows the LP - and only the LP, on the private operations port. It carries payer
   * hashes and their totals, which is how an operator sets a tier for someone (`caps.payers` takes a
   * `payerRef`); it carries no document, no key, no order and no address.
   */
  status(wallNow: bigint): Record<string, unknown> {
    const day = capDay(wallNow);
    const rows = this.deps.store.capRows();
    const payers = new Map<string, { payerRef: Hex; dayCents: bigint; monthCents: bigint }>();
    for (const r of rows) {
      if (capMonth(r.day) !== capMonth(day)) continue;
      const e = payers.get(r.payer.toLowerCase()) ?? { payerRef: r.payer, dayCents: 0n, monthCents: 0n };
      if (r.day === day) e.dayCents += r.cents;
      e.monthCents += r.cents;
      payers.set(r.payer.toLowerCase(), e);
    }
    return {
      enabled: true,
      limiting: this.limiting,
      day,
      defaultTier: this.o.defaultTier,
      unknownPayer: this.o.unknownPayer ?? 'refuse',
      tiers: Object.fromEntries(TIERS.map((t) => [t, {
        dailyBrlCents: this.limitsOf(t).dailyBrlCents?.toString() ?? null,
        monthlyBrlCents: this.limitsOf(t).monthlyBrlCents?.toString() ?? null,
      }])),
      tierSource: this.o.tierSource ? 'module' : 'config',
      rows: rows.length,
      lastCountAt: this.lastCountAt ?? null,
      lastMoneyAt: this.lastMoneyAt ?? null,
      refusedSinceStart: this.refused,
      payers: [...payers.values()]
        .sort((a, b) => (b.monthCents > a.monthCents ? 1 : b.monthCents < a.monthCents ? -1 : 0))
        .map((p) => ({ payerRef: p.payerRef, dayCents: p.dayCents.toString(), monthCents: p.monthCents.toString() })),
    };
  }

  /** Gauges for the scrape; the payer hashes stay out of labels, as every other identifier does. */
  gauges(wallNow: bigint): void {
    const day = capDay(wallNow);
    const seen = new Set<string>();
    let today = 0n;
    for (const r of this.deps.store.capRows()) {
      if (r.day !== day) continue;
      seen.add(r.payer.toLowerCase());
      today += r.cents;
    }
    this.deps.metrics.set('mova_lp_caps_payers_today', seen.size);
    this.deps.metrics.set('mova_lp_caps_counted_today_cents', Number(today));
    this.deps.metrics.set('mova_lp_caps_ledger_rows', this.deps.store.capRows().length);
    this.deps.metrics.set('mova_lp_caps_last_count_timestamp_seconds', this.lastCountAt ?? 0);
  }
}

/** The refusal a counterparty is told: the rule, never the total behind it. */
export const CAP_REFUSAL_CODE = 'cap_reached';
export const UNKNOWN_PAYER_REFUSAL_CODE = 'payer_unidentified';

/** What the counterparty API says. It names the period and nothing about this payer's history. */
export function capRefusalMessage(v: Extract<CapVerdict, { ok: false }>): string {
  if (v.period === 'unknown_payer') {
    return 'this LP could not identify the payer of that payment, and applies per-payer limits: it will not settle it, and any money received is returned';
  }
  return `this LP's per-payer ${v.period === 'day' ? 'daily' : 'monthly'} limit has been reached for the payer of this payment; it will not settle it, and any money received is returned`;
}
