import { describe, expect, it } from 'vitest';
import {
  TransactionNotFoundError, TransactionReceiptNotFoundError, encodeErrorResult, keccak256, parseAbi, toHex, type Address, type Hex,
} from 'viem';
import { ChainRevert } from '../src/chain.js';
import { TxSender, type TxEvent, type TxPolicy } from '../src/tx-sender.js';

/**
 * TxSender against a scripted node that behaves as geth does where it matters: a block takes the
 * account's queue in nonce order and only transactions whose fee cap reaches the base fee; a replacement
 * at a pending nonce must raise both fees by 10%; receipts and transactions are looked up by hash, and
 * a missing one throws viem's own not-found errors. (anvil evicts an underpriced transaction instead of
 * holding it, and accepts any bump, so it cannot stand in for this.) Every `getBlockNumber` mines a block,
 * so each poll of the sender is one block of waiting. Every call is estimated at `estimate` gas; `revertNext`
 * makes the next mined transaction revert, and `replayRevert` is what a replayed call then raises.
 */

const ME: Address = '0x00000000000000000000000000000000000a11ce';
const TO: Address = '0x000000000000000000000000000000000000b0b0';
const GWEI = 1_000_000_000n;

interface PoolTx { hash: Hex; from: Address; to: Address; nonce: number; maxFeePerGas: bigint; maxPriorityFeePerGas: bigint; input: Hex; value: bigint; gas: bigint }

class ScriptedNode {
  baseFee = GWEI;
  tip = GWEI;
  block = 100n;
  minedNonce = 0;
  hidePending = false;
  readonly pool = new Map<number, PoolTx>();
  readonly mined = new Map<string, PoolTx & { blockNumber: bigint; status: 'success' | 'reverted'; gasUsed: bigint }>();
  estimate = 50_000n;
  gasLimit = 30_000_000n;
  /** The next mined transaction reverts, having used `gasUsed` (its whole limit when absent). */
  revertNext?: { gasUsed?: bigint };
  /** Revert data a replayed `eth_call` raises; it succeeds when absent. */
  replayRevert?: Hex;
  readonly calls: unknown[] = [];
  readonly sent: PoolTx[] = [];
  private seq = 0;
  pollingInterval = 1;
  /** Runs once, right after the next transaction enters the pool. */
  onSubmit?: () => void;

  mine(): void {
    this.block++;
    for (;;) {
      const tx = this.pool.get(this.minedNonce);
      if (!tx || tx.maxFeePerGas < this.baseFee) return;
      this.pool.delete(this.minedNonce);
      const r = this.revertNext;
      this.revertNext = undefined;
      this.mined.set(tx.hash, { ...tx, blockNumber: this.block, status: r ? 'reverted' : 'success', gasUsed: r ? (r.gasUsed ?? tx.gas) : 21_000n });
      this.minedNonce++;
    }
  }

  submit(args: { to?: Address; data?: Hex; value?: bigint; gas?: bigint; nonce?: number; maxFeePerGas?: bigint; maxPriorityFeePerGas?: bigint }): Hex {
    const nonce = args.nonce!;
    if (nonce < this.minedNonce) throw new Error('nonce too low');
    const prior = this.pool.get(nonce);
    if (prior && (args.maxFeePerGas! * 10n < prior.maxFeePerGas * 11n || args.maxPriorityFeePerGas! * 10n < prior.maxPriorityFeePerGas * 11n)) {
      throw new Error('replacement transaction underpriced');
    }
    const tx: PoolTx = {
      hash: keccak256(toHex(`tx:${++this.seq}`)), from: ME, to: args.to ?? TO, nonce, maxFeePerGas: args.maxFeePerGas!,
      maxPriorityFeePerGas: args.maxPriorityFeePerGas!, input: args.data ?? '0x', value: args.value ?? 0n, gas: args.gas ?? 21_000n,
    };
    this.pool.set(nonce, tx);
    this.sent.push(tx);
    const hook = this.onSubmit;
    this.onSubmit = undefined;
    hook?.();
    return tx.hash;
  }

  readonly pub = {
    pollingInterval: 1,
    getBlockNumber: async () => { this.mine(); return this.block; },
    getTransactionCount: async ({ blockTag }: { blockTag: 'latest' | 'pending' }) => {
      if (blockTag === 'latest') return this.minedNonce;
      let n = this.minedNonce;
      while (this.pool.has(n)) n++;
      return n;
    },
    getTransactionReceipt: async ({ hash }: { hash: Hex }) => {
      const m = this.mined.get(hash);
      if (!m) throw new TransactionReceiptNotFoundError({ hash });
      return { transactionHash: m.hash, status: m.status, gasUsed: m.gasUsed, blockNumber: m.blockNumber, logs: [] };
    },
    getTransaction: async ({ hash }: { hash: Hex }) => {
      const m = this.mined.get(hash) ?? [...this.pool.values()].find((x) => x.hash === hash);
      if (!m) throw new TransactionNotFoundError({ hash });
      return { ...m, blockNumber: 'blockNumber' in m ? m.blockNumber : null };
    },
    estimateFeesPerGas: async () => ({ maxFeePerGas: this.baseFee * 2n + this.tip, maxPriorityFeePerGas: this.tip }),
    estimateGas: async () => this.estimate,
    getBlock: async () => ({ gasLimit: this.gasLimit, transactions: this.hidePending ? [] : [...this.pool.values()] }),
    call: async (args: unknown) => {
      this.calls.push(args);
      if (this.replayRevert) throw Object.assign(new Error('execution reverted'), { cause: { data: this.replayRevert } });
      return { data: '0x' };
    },
  };

  readonly wallet = {
    account: { address: ME },
    chain: { id: 1 },
    sendTransaction: async (args: Parameters<ScriptedNode['submit']>[0]) => this.submit(args),
  };
}

const policy = (over: Partial<TxPolicy> = {}): TxPolicy => ({
  replaceAfterBlocks: 2, bumpBps: 5_000, maxFeePerGasWei: 50n * GWEI, maxPriorityFeePerGasWei: 20n * GWEI, waitBlocks: 40, ...over,
});

function sender(node: ScriptedNode, p: TxPolicy, events: TxEvent[] = []): TxSender {
  return new TxSender(node.pub as never, node.wallet as never, p, (e) => events.push(e), async () => {});
}

describe('TxSender: a stuck transaction is replaced, and only its own receipt counts', () => {
  it('sends at an explicit nonce with capped fees and returns its own receipt', async () => {
    const node = new ScriptedNode();
    node.baseFee = 30n * GWEI; // the estimate, 61 gwei, is above the 50 gwei cap
    const r = await sender(node, policy()).sendAndWait({ to: TO, data: '0x1234' });
    expect(r.transactionHash).toBe(node.sent[0].hash);
    expect(node.sent[0]).toMatchObject({ nonce: 0, maxFeePerGas: 50n * GWEI });
  });

  it('replaces a transaction stuck under a rising base fee at the same nonce, each bump at least 10%, and returns the replacement\'s receipt', async () => {
    const node = new ScriptedNode();
    const events: TxEvent[] = [];
    const s = sender(node, policy(), events);
    node.onSubmit = () => { node.baseFee = 8n * GWEI; }; // after the send: 3 gwei offered, 8 required
    const r = await s.sendAndWait({ to: TO, data: '0xabcd' });
    expect(node.sent[0].gas).toBe(85_000n); // 50,000 estimated, plus 20%, plus 25,000
    expect(node.sent.length).toBeGreaterThan(1);
    expect(new Set(node.sent.map((t) => t.nonce))).toEqual(new Set([0]));
    for (let i = 1; i < node.sent.length; i++) {
      expect(node.sent[i].maxFeePerGas * 10n >= node.sent[i - 1].maxFeePerGas * 11n).toBe(true);
      expect(node.sent[i]).toMatchObject({ input: '0xabcd', to: TO, gas: node.sent[0].gas });
    }
    expect(r.transactionHash).toBe(node.sent.at(-1)!.hash);
    expect(events.filter((e) => e.type === 'replaced').length).toBe(node.sent.length - 1);
  });

  it('never offers more than the cap: it stops bumping, says so, gives up waiting, and the next write keeps following it', async () => {
    const node = new ScriptedNode();
    const events: TxEvent[] = [];
    const s = sender(node, policy({ maxFeePerGasWei: 6n * GWEI, waitBlocks: 12 }), events);
    const p = s.sendAndWait({ to: TO, data: '0x01' });
    node.baseFee = 20n * GWEI;
    await expect(p).rejects.toThrow(/not mined after 12 blocks/);
    expect(Math.max(...node.sent.map((t) => Number(t.maxFeePerGas)))).toBeLessThanOrEqual(Number(6n * GWEI));
    expect(events.some((e) => e.type === 'capped')).toBe(true);

    node.baseFee = 2n * GWEI; // the market comes back under the cap
    const r = await s.sendAndWait({ to: TO, data: '0x02' });
    expect(node.minedNonce).toBe(2);
    expect(node.mined.get(r.transactionHash)).toMatchObject({ nonce: 1, input: '0x02' });
  });

  it('a transaction another client mined at the nonce is never taken for this one: the write fails as replaced', async () => {
    const node = new ScriptedNode();
    const s = sender(node, policy({ replaceAfterBlocks: 0 }));
    node.onSubmit = () => {
      node.baseFee = 8n * GWEI; // ours, at 3 gwei, is stuck...
      // ...and the same key, elsewhere, replaces it with a transfer to self at nonce 0, priced to mine.
      node.submit({ to: ME, nonce: 0, maxFeePerGas: 100n * GWEI, maxPriorityFeePerGas: 10n * GWEI });
    };
    const err = await s.sendAndWait({ to: TO, data: '0xc1a1' }).catch((e: unknown) => e);
    expect(err).toBeInstanceOf(ChainRevert);
    expect((err as ChainRevert).errorName).toBe('replaced');
  });

  it('a pending transaction left by an earlier process is found, followed and bumped before the new one', async () => {
    const node = new ScriptedNode();
    node.submit({ to: TO, data: '0x0ld0', nonce: 0, maxFeePerGas: 2n * GWEI, maxPriorityFeePerGas: GWEI });
    node.baseFee = 5n * GWEI;
    const events: TxEvent[] = [];
    const r = await sender(node, policy(), events).sendAndWait({ to: TO, data: '0x0e11' });
    expect(events.some((e) => e.type === 'adopted' && e.nonce === 0)).toBe(true);
    expect(node.minedNonce).toBe(2);
    expect(node.mined.get(r.transactionHash)).toMatchObject({ nonce: 1, input: '0x0e11' });
    expect([...node.mined.values()].find((t) => t.nonce === 0)).toMatchObject({ input: '0x0ld0' });
  });

  it('one the node will not show is cancelled by a transfer to self at its nonce, once it has blocked long enough', async () => {
    const node = new ScriptedNode();
    node.submit({ to: TO, data: '0xdead', nonce: 0, maxFeePerGas: 2n * GWEI, maxPriorityFeePerGas: GWEI });
    node.baseFee = 5n * GWEI;
    node.hidePending = true;
    const events: TxEvent[] = [];
    const r = await sender(node, policy(), events).sendAndWait({ to: TO, data: '0x0e11' });
    expect(events.some((e) => e.type === 'cancelled' && e.nonce === 0)).toBe(true);
    expect([...node.mined.values()].find((t) => t.nonce === 0)).toMatchObject({ to: ME, input: '0x', value: 0n });
    expect(node.mined.get(r.transactionHash)?.nonce).toBe(1);
  });

  it('leaves the gateway\'s reserved nonces alone: neither adopted nor cancelled', async () => {
    const node = new ScriptedNode();
    node.submit({ to: TO, data: '0x6a7e', nonce: 0, maxFeePerGas: 2n * GWEI, maxPriorityFeePerGas: GWEI });
    node.baseFee = 5n * GWEI;
    node.hidePending = true;
    const events: TxEvent[] = [];
    const s = sender(node, policy({ waitBlocks: 8 }), events);
    s.reserve([0]);
    await expect(s.sendAndWait({ to: TO, data: '0x0e11' })).rejects.toThrow(/not mined/);
    // Its own transaction, queued behind nonce 0, is bumped; nonce 0 is not touched.
    expect(events.filter((e) => e.nonce === 0)).toEqual([]);
    expect(node.pool.get(0)?.input).toBe('0x6a7e');
  });
});

describe('TxSender: a gas limit with headroom, and why a write reverted', () => {
  it('sends the estimate plus 20% plus 25,000, capped at the block gas limit, and a stated limit as it is', async () => {
    const node = new ScriptedNode();
    const s = sender(node, policy());
    await s.sendAndWait({ to: TO, data: '0x01' });
    await sender(node, policy({ gasHeadroomPercent: 0 })).sendAndWait({ to: TO, data: '0x02' });
    node.gasLimit = 60_000n;
    await s.sendAndWait({ to: TO, data: '0x03' });
    await s.sendAndWait({ to: TO, data: '0x04', gas: 21_000n });
    expect(node.sent.map((t) => t.gas)).toEqual([85_000n, 75_000n, 60_000n, 21_000n]);
    expect(() => sender(node, policy({ gasHeadroomPercent: 101 }))).toThrow(/gasHeadroomPercent/);
  });

  it('says why: out of gas at its whole limit, the contract\'s error replayed on the parent block, or unknown', async () => {
    const ERRORS = parseAbi(['error WrongState(uint8 state)']);
    const node = new ScriptedNode();
    const s = sender(node, policy());

    node.revertNext = {};
    expect(await s.sendAndWait({ to: TO, data: '0x01' })).toMatchObject({ status: 'reverted', revertReason: 'out of gas (used 85000 of 85000)' });
    expect(node.calls).toEqual([]);

    node.revertNext = { gasUsed: 40_000n };
    node.replayRevert = encodeErrorResult({ abi: ERRORS, errorName: 'WrongState', args: [2] });
    const named = await s.sendAndWait({ to: TO, data: '0x02', value: 7n, abi: ERRORS });
    expect(named.revertReason).toBe('WrongState(2)');
    // Read back by hash and replayed on the parent block: the same account, call, value and limit.
    expect(node.calls.at(-1)).toMatchObject({ account: ME, to: TO, data: '0x02', value: 7n, gas: 85_000n, blockNumber: named.blockNumber - 1n });

    node.revertNext = { gasUsed: 40_000n };
    node.replayRevert = encodeErrorResult({ abi: parseAbi(['error Error(string)']), errorName: 'Error', args: ['not now'] });
    expect((await s.sendAndWait({ to: TO, data: '0x03' })).revertReason).toBe('Error(not now)');

    node.revertNext = { gasUsed: 40_000n };
    node.replayRevert = undefined;
    const odd = await s.sendAndWait({ to: TO, data: '0x04' });
    expect(odd.revertReason).toBe(`unknown (used 40000 of 85000 gas; the call succeeds replayed at block ${odd.blockNumber - 1n})`);
    // A success carries no reason, and costs no replay.
    const calls = node.calls.length;
    expect((await s.sendAndWait({ to: TO, data: '0x05' })).revertReason).toBeUndefined();
    expect(node.calls).toHaveLength(calls);
  });
});
