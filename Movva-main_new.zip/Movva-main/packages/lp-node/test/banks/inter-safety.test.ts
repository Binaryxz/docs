import { afterEach, describe, expect, it } from 'vitest';
import { createServer, type Server } from 'node:http';
import { privateKeyToAccount } from 'viem/accounts';
import { Rail, boletoCommitment, brasiliaToday, buildBankBoleto, newBoletoSalt, newPixSalt, pixKeyCommitment, railMask } from '@mova/ramp';
import { SaleState } from '../../src/abi.js';
import { MemoryJournal } from '../../src/journal.js';
import { idempotencyKey } from '../../src/store.js';
import { InterClient, createInterBank, type InterIndexRecord } from '../../src/banks/inter.js';
import { LocalWitnessSession, ZkTlsProver, type ReceiptSource } from '../../src/zktls.js';
import { OFFRAMP } from '../fake-chain.js';
import { RECEIPT_TEMPLATES, WITNESS_KEYS, ZKTLS_ENDPOINTS, ZKTLS_VERIFIER, harness, type Harness } from '../harness.js';
import { MockInter } from './inter-mock.js';

/**
 * safety.test.ts's crash scenarios with the Inter adapter as the node's bank, against the mock of
 * Inter's documented API on the chain's clock: a lost response after Inter moved the money, a refused
 * connection, a lost journal, the same for a boleto, and a payment waiting for approval. The
 * assertion each time is the bank's own count of transfers that debited the account.
 *
 * A restart is a new node AND a new adapter (new client, no token, no caches) over the same node
 * journal and the same adapter journal - both on the LP's disk.
 */

const SELLER_KEY = '+5511987654321';
/**
 * Inter's own books, as its receipt pages would show them: what the local zkTLS witnesses sign for the node's payouts.
 * The adapter reports a Pix by its `endToEnd` and a paid bill by its `autenticacao` (banks/inter.ts), so those are the ids.
 */
const interReceipts = (inter: MockInter): ReceiptSource => ({
  async receipt(leg, rail, bankTxId) {
    if (leg !== 'offramp') return undefined;
    if (rail === 'PIX') {
      const x = [...inter.pix.values()].find((p) => p.status === 'PAGO' && p.e2e === bankTxId);
      return x && { bankTxId, amountCents: x.cents, paidAt: BigInt(Math.floor(x.paidAt! / 1000)), pixKey: x.chave };
    }
    const b = inter.boletos.find((x) => x.status === 'REALIZADO' && x.auth === bankTxId);
    return b && { bankTxId, amountCents: b.cents, paidAt: BigInt(Math.floor(b.paidAt! / 1000)), boletoLine: b.barcode };
  },
});

let servers: Server[] = [];
afterEach(async () => {
  for (const s of servers) await new Promise<void>((r) => s.close(() => r()));
  servers = [];
});

async function interNode(): Promise<{ h: Harness; inter: MockInter; journal: MemoryJournal<InterIndexRecord>; setUrl: (u: 'good' | 'refused') => void }> {
  let h: Harness | undefined;
  const clockMs = () => Number(h!.chain.time()) * 1000;
  const inter = new MockInter(clockMs);
  const server = createServer((rq, rs) => void inter.handler(rq, rs));
  servers.push(server);
  await new Promise<void>((r) => server.listen(0, '127.0.0.1', () => r()));
  const port = (server.address() as { port: number }).port;
  // A port nothing listens on: the connection is refused before a byte is sent.
  const closed = createServer();
  await new Promise<void>((r) => closed.listen(0, '127.0.0.1', () => r()));
  const refusedPort = (closed.address() as { port: number }).port;
  await new Promise<void>((r) => closed.close(() => r()));

  let url = `http://127.0.0.1:${port}`;
  const journal = new MemoryJournal<InterIndexRecord>();
  h = harness({
    onramp: false, confirmations: 1,
    tweak: (opts) => {
      opts.bank = createInterBank({
        client: new InterClient({ baseUrl: url, clientId: inter.clientId, clientSecret: inter.clientSecret, now: clockMs, sleep: async () => undefined, limits: 'off' }),
        journal,
      });
      // The witnesses read the bank the node pays from: Inter, not the harness's MockBank.
      const session = new LocalWitnessSession({ witnessKeys: WITNESS_KEYS, receipts: interReceipts(inter), templates: RECEIPT_TEMPLATES, now: () => h!.chain.time() });
      opts.provers = [new ZkTlsProver(ZKTLS_VERIFIER, session, {
        witnesses: { addresses: WITNESS_KEYS.map((k) => privateKeyToAccount(k).address), threshold: 2 }, endpoints: ZKTLS_ENDPOINTS,
      })];
    },
  });
  return {
    h, inter, journal,
    setUrl: (u) => { url = u === 'good' ? `http://127.0.0.1:${port}` : `http://127.0.0.1:${refusedPort}`; },
  };
}

async function claimedPixSale(h: Harness): Promise<{ saleId: `0x${string}`; key: string }> {
  const salt = newPixSalt();
  const saleId = h.chain.openSale({
    amount: 10n ** 17n, brlCents: 198_000n, payeeKeyHash: pixKeyCommitment(SELLER_KEY, salt), railMask: railMask(Rail.PIX),
  });
  await h.node.offramp!.submitPayee(saleId, { pixKey: SELLER_KEY, salt });
  await h.tick();
  expect((await h.chain.sale(saleId)).state).toBe(SaleState.CLAIMED);
  return { saleId, key: idempotencyKey('sale-pay', h.chain.chainId, OFFRAMP, saleId) };
}

describe('safety through the Inter adapter: no crash makes the node pay twice', () => {
  it('a lost response after Inter moved the money: the restarted node settles, and Inter moved it once', async () => {
    const { h, inter } = await interNode();
    const { saleId, key } = await claimedPixSale(h);
    inter.fault('pixPay', 'lose');
    await h.tick();
    expect(inter.pixMoves).toBe(1);
    expect(h.node.store.getSale(saleId)?.pay?.result).toBeUndefined();

    h.restart();
    await h.tick();
    await h.tick();
    expect(inter.pixMoves).toBe(1);
    expect((await h.chain.sale(saleId)).state).toBe(SaleState.SETTLED);
    const posts = inter.ofOp('pixPay');
    expect(posts).toHaveLength(2);
    expect(new Set(posts.map((p) => p.headers['x-id-idempotente'])).size).toBe(1);
    expect(h.node.store.getSale(saleId)?.pay?.idempotencyKey).toBe(key);
  });

  it('a refused connection: nothing reached Inter, and the restarted node pays under the same key, once', async () => {
    const { h, inter, setUrl } = await interNode();
    const { saleId, key } = await claimedPixSale(h);
    setUrl('refused');
    h.restart();
    await h.tick();
    expect(inter.ofOp('pixPay')).toHaveLength(0);
    expect(h.node.store.getSale(saleId)?.pay?.idempotencyKey).toBe(key);

    setUrl('good');
    h.restart();
    await h.tick();
    await h.tick();
    expect(inter.pixMoves).toBe(1);
    expect((await h.chain.sale(saleId)).state).toBe(SaleState.SETTLED);
  });

  it('with both journals lost Inter cannot be asked by key: the node gives back a claim it paid, and the header still stops a second transfer', async () => {
    // The residual risk of this adapter, shown rather than hidden: Inter has no query by x-id-idempotente, so
    // without the adapter's journal getOutgoing cannot find the Pix, and a node that also lost the payee
    // abandons the claim. Money moved once; the LP loses the sale. Keep INTER_STATE_PATH as durable as STATE_FILE.
    const { h, inter, journal } = await interNode();
    const { saleId } = await claimedPixSale(h);
    inter.fault('pixPay', 'lose');
    await h.tick();
    const payee = h.node.store.getSale(saleId)!.payee!;
    h.journal.lines.splice(0, h.journal.lines.length);
    journal.lines.splice(0, journal.lines.length);
    h.restart();
    await h.tick();
    await h.tick();
    expect(inter.pixMoves).toBe(1);
    expect(h.chain.writes).toContain('abandonClaim');
    expect((await h.chain.sale(saleId)).state).toBe(SaleState.OPEN);

    // The seller discloses again and the node claims the sale again: same sale, same key, same header.
    if (payee.kind !== 'pix') throw new Error('expected a PIX payee');
    await h.node.offramp!.submitPayee(saleId, { pixKey: payee.pixKey, salt: payee.salt });
    for (let i = 0; i < 4; i++) await h.tick();
    const posts = inter.ofOp('pixPay');
    expect(posts.length).toBeGreaterThanOrEqual(2);
    expect(new Set(posts.map((p) => p.headers['x-id-idempotente'])).size).toBe(1);
    expect(inter.pixMoves).toBe(1);
    // The payment predates the new claim, so it cannot settle it: nothing is proven that did not happen.
    expect((await h.chain.sale(saleId)).state).not.toBe(SaleState.SETTLED);
  });

  it('a boleto sale: the payment whose response was lost is found by barcode after the restart, and the bill is paid once', async () => {
    const { h, inter } = await interNode();
    const cents = 38_990n;
    const bill = buildBankBoleto({
      bankCode: '341', amountCents: cents, freeField: '1234567890123456789012345',
      dueDate: brasiliaToday(new Date(Number(h.chain.time() + 10n * 86_400n) * 1000)),
    });
    const salt = newBoletoSalt();
    const saleId = h.chain.openSale({
      amount: (cents * 10n ** 18n) / 1_970_000n, brlCents: cents, payeeKeyHash: boletoCommitment(bill, salt), railMask: railMask(Rail.BOLETO),
    });
    await h.node.offramp!.submitPayee(saleId, { boletoLine: bill.line, salt });
    await h.tick();
    expect((await h.chain.sale(saleId)).state).toBe(SaleState.CLAIMED);
    inter.fault('boletoPay', 'lose');
    await h.tick();
    expect(inter.boletoMoves).toBe(1);

    h.restart();
    await h.tick();
    await h.tick();
    expect(inter.ofOp('boletoPay')).toHaveLength(1);
    expect(inter.boletoMoves).toBe(1);
    expect((await h.chain.sale(saleId)).state).toBe(SaleState.SETTLED);
  });

  it('a Pix waiting for approval is not proven: the node settles only once Inter reports it paid', async () => {
    const { h, inter } = await interNode();
    inter.approvals = true;
    const { saleId } = await claimedPixSale(h);
    await h.tick();
    await h.tick();
    expect(h.node.store.getSale(saleId)?.pay?.result?.status).toBe('PENDING');
    expect((await h.chain.sale(saleId)).state).toBe(SaleState.CLAIMED);
    inter.settlePix();
    await h.tick();
    await h.tick();
    expect((await h.chain.sale(saleId)).state).toBe(SaleState.SETTLED);
    expect(inter.pixMoves).toBe(1);
    expect(inter.ofOp('pixPay')).toHaveLength(1);
  });
});
