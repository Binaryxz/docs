/**
 * Banco Inter as its published documents describe it (read 2026-09-14; sources in
 * src/banks/inter-client.ts), for the tests: the OAuth token, Banking v2 (Pix payment, boleto payment,
 * saldo, extrato completo), Cobrança v3, and API Pix v2's received Pix and immediate charges (cob).
 *
 * Routes, scopes and parameters come from `inter-openapi.json` (the scripted excerpt of the OpenAPI
 * documents); bodies from the documented schemas and examples - errors included, echoed values and all.
 * Where the documents are silent the mock has to do something, and says so with MOCK CHOICE: a test
 * that depends on one proves the adapter against that choice, not against Inter.
 */
import { readFileSync } from 'node:fs';
import type { IncomingMessage, ServerResponse } from 'node:http';
import type { TLSSocket } from 'node:tls';
import { buildBankBoleto, lineToBarcode } from '@mova/ramp';

export const INTER_SPEC = JSON.parse(readFileSync(new URL('./inter-openapi.json', import.meta.url), 'utf8')) as {
  retrieved: string;
  operations: Record<string, {
    method: string; path: string; scope?: string;
    parameters: { name: string; in: string; required: boolean; schema: Record<string, unknown> }[];
    requestBody?: { contentType: string; required: boolean; schema: Record<string, unknown> };
  }>;
};
const spec = INTER_SPEC;

export interface Recorded {
  op: string;
  method: string;
  path: string;
  query: URLSearchParams;
  headers: Record<string, string | undefined>;
  raw: string;
  body?: unknown;
  clientCert?: boolean;
}

interface PixRec {
  codigo: string; uuid?: string; chave: string; cents: bigint; status: string; e2e?: string; at: number; paidAt?: number; response: unknown;
}
interface BoletoRec {
  codigo: string; barcode: string; cents: bigint; status: string; auth?: string; at: number; paidAt?: number; vencimento: string;
}
interface CobRec {
  codigo: string; seuNumero: string; cents: bigint; vencimento: string; cpfCnpj: string; at: number; gets: number;
  situacao: string; line?: string; barcode?: string; nossoNumero?: string; paidAt?: number;
}
interface StatementRec { at: number; tipoOperacao: 'C' | 'D'; tipoTransacao: string; cents: bigint; detalhes: Record<string, unknown> }
export interface ReceivedPix { endToEndId: string; txid?: string; valor: string; chave?: string; horario: string }

type Fault = { op: string; kind: '429' | 'lose' | '401' | '500'; retryAfter?: string };

const DAY = 86_400_000;
/** A JSON number written exactly, e.g. 123.45 from 12345 centavos. */
const NUM = (cents: bigint) => `@@num:${cents / 100n}.${(cents % 100n).toString().padStart(2, '0')}@@`;
const stringify = (body: unknown) => JSON.stringify(body).replace(/"@@num:([0-9.]+)@@"/g, '$1');
/** Brasília wall-clock, the format of the documented examples without a zone. */
export const brt = (ms: number) => new Date(ms - 3 * 3600_000).toISOString().replace('T', ' ').slice(0, 19);
const brtDay = (ms: number) => brt(ms).slice(0, 10);
/** RFC 3339 with Inter's offset, as in EntidadeNaoProcessavel.timestamp. */
const rfc = (ms: number) => `${new Date(ms - 3 * 3600_000).toISOString().slice(0, 23)}-03:00`;
const dayMs = (d: string) => Date.parse(`${d}T00:00:00-03:00`);

export class MockInter {
  readonly requests: Recorded[] = [];
  clientId = 'inter-client-id';
  clientSecret = 'inter-client-secret-value-0123456789';
  tokenTtl = 3600;
  tokensIssued = 0;
  /** Scopes the integration has; undefined grants whatever is asked. */
  integrationScopes?: string[];
  balanceCents = 100_000_000n;
  /** Transfers that debited the account: the no-double-pay assertion. */
  pixMoves = 0;
  boletoMoves = 0;
  /** Payments wait for a human's approval in the Internet Banking. */
  approvals = false;
  pixSettle: 'immediate' | 'manual' = 'immediate';
  /** GETs a new charge answers EM_PROCESSAMENTO, without a line (issuing is asynchronous). */
  emissionGets = 1;
  /** MOCK CHOICE: how long a new boleto payment stays out of GET /pagamento (the documents do not say). */
  paymentListLagMs = 0;
  readonly pix = new Map<string, PixRec>();
  readonly boletos: BoletoRec[] = [];
  readonly cobrancas = new Map<string, CobRec>();
  readonly statement: StatementRec[] = [];
  readonly received: ReceivedPix[] = [];
  /** API Pix immediate charges by txid, as `PUT /cob/{txid}` answered them. */
  readonly charges = new Map<string, Record<string, any>>();
  /** Keys the mock's DICT does not know. */
  readonly unknownKeys = new Set<string>();
  readonly devolucoes = new Map<string, unknown>();
  private readonly byIdempotency = new Map<string, string>();
  private readonly tokens = new Map<string, { expiresAt: number; scopes: string[] }>();
  private faults: Fault[] = [];
  private seq = 0;

  constructor(readonly now: () => number = () => Date.now()) {}

  /** The next call to `op` fails this way: 429 before processing, a lost response after it, a revoked token. */
  fault(op: string, kind: Fault['kind'], o: { retryAfter?: string; times?: number } = {}): void {
    for (let i = 0; i < (o.times ?? 1); i++) this.faults.push({ op, kind, retryAfter: o.retryAfter });
  }

  ofOp(op: string): Recorded[] {
    return this.requests.filter((r) => r.op === op);
  }

  private id(): string {
    const n = (++this.seq).toString(16).padStart(12, '0');
    return `c42f0787-02cb-4b31-827e-${n}`;
  }

  private route(method: string, path: string): { op: string; params: Record<string, string>; scope?: string } | undefined {
    for (const [op, d] of Object.entries(spec.operations)) {
      if (d.method !== method) continue;
      const names: string[] = [];
      const re = new RegExp(`^${d.path.replace(/\{(\w+)\}/g, (_m, n: string) => { names.push(n); return '([^/]+)'; })}$`);
      const m = re.exec(path);
      if (m) return { op, scope: d.scope, params: Object.fromEntries(names.map((n, i) => [n, decodeURIComponent(m[i + 1])])) };
    }
    return undefined;
  }

  handler = async (rq: IncomingMessage, rs: ServerResponse): Promise<void> => {
    const url = new URL(rq.url ?? '/', 'http://inter');
    const chunks: Buffer[] = [];
    for await (const c of rq) chunks.push(c as Buffer);
    const raw = Buffer.concat(chunks).toString('utf8');
    const socket = rq.socket as TLSSocket;
    const r = this.route(rq.method ?? '', url.pathname);
    const h = rq.headers;
    const rec: Recorded = {
      op: r?.op ?? 'unknown', method: rq.method ?? '', path: url.pathname, query: url.searchParams, raw,
      headers: {
        authorization: h.authorization, 'content-type': h['content-type'], 'x-id-idempotente': h['x-id-idempotente'] as string | undefined,
        'x-conta-corrente': h['x-conta-corrente'] as string | undefined,
      },
      body: h['content-type']?.includes('json') && raw ? JSON.parse(raw) as unknown : undefined,
      clientCert: typeof socket.getPeerCertificate === 'function' ? !!socket.getPeerCertificate()?.subject : undefined,
    };
    this.requests.push(rec);
    const write = (status: number, body?: unknown, headers: Record<string, string> = {}) => {
      rs.writeHead(status, { ...(body !== undefined ? { 'content-type': 'application/json' } : {}), ...headers });
      rs.end(body === undefined ? undefined : stringify(body));
    };
    if (!r) return write(404, { title: 'Não Encontrado', status: 404, detail: 'Entidade não encontrada.' });
    const i = this.faults.findIndex((f) => f.op === r.op);
    const fault = i >= 0 ? this.faults.splice(i, 1)[0] : undefined;
    // "Código HTTP 429 - Sem mensagem de Erro"; MOCK CHOICE: a Retry-After when the test asks for one.
    if (fault?.kind === '429') return write(429, undefined, fault.retryAfter ? { 'retry-after': fault.retryAfter } : {});
    if (fault?.kind === '500') return write(500, { title: 'Erro Interno', status: 500, detail: 'Ocorreu um erro não esperado. Tente novamente mais tarde.' });

    let result: [number, unknown?];
    if (r.op === 'token') {
      result = this.token(raw);
    } else {
      const tok = /^Bearer (.+)$/.exec(h.authorization ?? '')?.[1];
      const t = tok ? this.tokens.get(tok) : undefined;
      if (fault?.kind === '401') this.tokens.clear();
      if (!t || t.expiresAt <= this.now() || fault?.kind === '401') {
        return write(401, { title: 'Acesso negado', status: '401', detail: 'Login/senha inválido.', timestamp: rfc(this.now()) });
      }
      if (r.scope && !t.scopes.includes(r.scope)) {
        return write(403, { title: 'Acesso Negado', status: '403', detail: 'Requisição de participante autenticado que viola alguma regra de autorização.' });
      }
      result = this.dispatch(r.op, r.params, url.searchParams, rec);
    }
    if (fault?.kind === 'lose') {
      socket.destroy();
      return;
    }
    write(result[0], result[1]);
  };

  private invalid(propriedade: string, valor: unknown, razao = 'Valor inválido'): [number, unknown] {
    return [400, {
      title: 'Dados inválidos.', detail: 'Verifique se os dados informados estão de acordo com a documentação disponibilizada e tente novamente.',
      timestamp: rfc(this.now()), violacoes: [{ razao, propriedade, valor: String(valor) }],
    }];
  }

  private token(raw: string): [number, unknown?] {
    const f = new URLSearchParams(raw);
    if (f.get('client_id') !== this.clientId || f.get('client_secret') !== this.clientSecret) return [401];
    if (f.get('grant_type') !== 'client_credentials' || !f.get('scope')) return [400];
    const asked = f.get('scope')!.split(/\s+/);
    const scopes = this.integrationScopes ? asked.filter((s) => this.integrationScopes!.includes(s)) : asked;
    const access = `inter-token-${++this.tokensIssued}-${'x'.repeat(24)}`;
    this.tokens.set(access, { expiresAt: this.now() + this.tokenTtl * 1000, scopes });
    return [200, { access_token: access, token_type: 'Bearer', expires_in: this.tokenTtl, scope: scopes.join(' ') }];
  }

  private dispatch(op: string, p: Record<string, string>, q: URLSearchParams, rec: Recorded): [number, unknown?] {
    const b = (rec.body ?? {}) as Record<string, any>;
    switch (op) {
      case 'pixPay': return this.pixPay(b, rec);
      case 'pixPayGet': {
        const x = this.pix.get(p.codigoSolicitacao);
        return x ? [200, this.pixView(x)] : [404, { title: 'Não Encontrado.', status: '404', detail: 'Entidade não encontrada.' }];
      }
      case 'boletoPay': return this.boletoPay(b);
      case 'boletoPayList': return this.boletoList(q);
      case 'saldo': return [200, { disponivel: NUM(this.balanceCents), bloqueadoCheque: NUM(0n), bloqueadoJudicialmente: NUM(0n), bloqueadoAdministrativo: NUM(0n), limite: NUM(0n) }];
      case 'extrato': return this.extrato(q);
      case 'cobrancaCreate': return this.cobrancaCreate(b);
      case 'cobrancaList': return this.cobrancaList(q);
      case 'cobrancaGet': {
        const c = this.cobrancas.get(p.codigoSolicitacao);
        return c ? [200, this.cobrancaView(c)] : [404, { title: 'Não Encontrado', status: 404, detail: 'Entidade não encontrada.' }];
      }
      case 'cobrancaCancel': {
        const c = this.cobrancas.get(p.codigoSolicitacao);
        if (!c) return [404, { title: 'Não Encontrado', status: 404, detail: 'Entidade não encontrada.' }];
        if (typeof b.motivoCancelamento !== 'string' || b.motivoCancelamento.length > 50) return this.invalid('motivoCancelamento', b.motivoCancelamento);
        // MOCK CHOICE: cancelling a charge that is not open is a 400.
        if (!['A_RECEBER', 'ATRASADO', 'EM_PROCESSAMENTO'].includes(c.situacao)) return [400, { title: 'Dados inválidos.', status: 400, detail: 'Cobrança não pode ser cancelada.' }];
        c.situacao = 'CANCELADO';
        return [202];
      }
      case 'pixList': return this.pixList(q);
      case 'cobPut': return this.cobPut(p.txid, b);
      case 'cobGet': {
        const c = this.charges.get(p.txid);
        return c ? [200, c] : [404, { title: 'Não Encontrado', status: 404, detail: 'Cobrança não encontrada.' }];
      }
      case 'cobPatch': return this.cobPatch(p.txid, b);
      case 'pixGet': {
        const x = this.received.find((r) => r.endToEndId === p.e2eId);
        return x ? [200, x] : [404, { title: 'Não Encontrado', status: 404, detail: 'Pix não encontrado.' }];
      }
      case 'devolucaoGet': {
        const d = this.devolucoes.get(`${p.e2eId}/${p.id}`);
        return d ? [200, d] : [404, { title: 'Não Encontrado', status: 404, detail: 'Devolução não encontrada.' }];
      }
      case 'devolucaoPut': {
        const credit = this.received.find((r) => r.endToEndId === p.e2eId);
        if (!credit) return [404, { title: 'Não Encontrado', status: 404, detail: 'Pix não encontrado.' }];
        const d = {
          id: p.id, rtrId: `D00416968${brt(this.now()).replace(/\D/g, '').slice(0, 12)}${String(++this.seq).padStart(11, '0')}`,
          valor: b.valor, horario: { solicitacao: rfc(this.now()) }, status: 'EM_PROCESSAMENTO',
        };
        this.devolucoes.set(`${p.e2eId}/${p.id}`, d);
        return [201, d];
      }
      default: return [404, { title: 'Não Encontrado', status: 404, detail: 'Entidade não encontrada.' }];
    }
  }

  /*------------------------------ Pix payment ------------------------------*/

  private pixPay(b: Record<string, any>, rec: Recorded): [number, unknown?] {
    const uuid = rec.headers['x-id-idempotente'];
    if (uuid !== undefined && !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(uuid)) return this.invalid('x-id-idempotente', uuid);
    // MOCK CHOICE: a repeated x-id-idempotente answers the first response again (the documents do not say).
    if (uuid && this.byIdempotency.has(uuid)) return [200, this.pix.get(this.byIdempotency.get(uuid)!)!.response];
    const valor = /"valor"\s*:\s*(\d+(?:\.\d{1,2})?)\s*[,}]/.exec(rec.raw)?.[1];
    if (!valor || valor === '0' || /^0(\.0+)?$/.test(valor)) return this.invalid('valor', b.valor, 'O valor não pode ser nulo');
    const d = b.destinatario ?? {};
    if (d.tipo !== 'CHAVE' || typeof d.chave !== 'string') return this.invalid('destinatario', JSON.stringify(d));
    if (typeof b.descricao === 'string' && b.descricao.length > 140) return this.invalid('descricao', b.descricao);
    if (this.unknownKeys.has(d.chave)) {
      return [422, { title: 'Chave Pix não encontrada', detail: `A chave ${d.chave} não foi encontrada.`, timestamp: rfc(this.now()) }];
    }
    const [int, frac = ''] = valor.split('.');
    const cents = BigInt(int) * 100n + BigInt(frac.padEnd(2, '0'));
    const now = this.now();
    const x: PixRec = {
      codigo: this.id(), uuid, chave: d.chave, cents, at: now, response: undefined,
      status: this.approvals ? 'AGUARDANDO_APROVACAO' : this.pixSettle === 'immediate' ? 'PAGO' : 'ENVIADO',
    };
    if (x.status === 'PAGO') this.debitPix(x);
    x.response = { tipoRetorno: this.approvals ? 'APROVACAO' : 'PROCESSADO', codigoSolicitacao: x.codigo, dataPagamento: brtDay(now), dataOperacao: brtDay(now) };
    this.pix.set(x.codigo, x);
    if (uuid) this.byIdempotency.set(uuid, x.codigo);
    return [200, x.response];
  }

  private debitPix(x: PixRec): void {
    if (x.cents > this.balanceCents) {
      x.status = 'CANCELADO_SEM_SALDO';
      return;
    }
    this.balanceCents -= x.cents;
    this.pixMoves++;
    x.status = 'PAGO';
    x.paidAt = this.now();
    const stamp = brt(x.paidAt).replace(/\D/g, '').slice(0, 12);
    x.e2e = `E00416968${stamp}${(this.seq++).toString(36).padStart(11, '0')}`;
  }

  /** The human approves (or the SPI settles) every waiting Pix. */
  settlePix(): void {
    for (const x of this.pix.values()) if (['AGUARDANDO_APROVACAO', 'APROVADO', 'ENVIADO'].includes(x.status)) this.debitPix(x);
  }

  rejectPix(codigo: string): void {
    this.pix.get(codigo)!.status = 'REPROVADO';
  }

  private pixView(x: PixRec): unknown {
    return {
      transacaoPix: {
        contaCorrente: '12345678', recebedor: { nome: 'Recebedor', cpfCnpj: '***.777.888-**' }, erros: [],
        endToEnd: x.e2e, valor: NUM(x.cents), status: x.status, dataHoraMovimento: x.paidAt ? rfc(x.paidAt) : undefined,
        dataHoraSolicitacao: rfc(x.at), chave: x.chave, codigoSolicitacao: x.codigo,
      },
      historico: [{ status: 'CRIADO', dataHoraEvento: rfc(x.at) }, ...(x.paidAt ? [{ status: 'PAGO', dataHoraEvento: rfc(x.paidAt) }] : [])],
    };
  }

  /*----------------------------- boleto payment -----------------------------*/

  private boletoPay(b: Record<string, any>): [number, unknown?] {
    const digits = typeof b.codBarraLinhaDigitavel === 'string' ? b.codBarraLinhaDigitavel : '';
    if (!/^\d{44,48}$/.test(digits)) return this.invalid('codBarraLinhaDigitavel', digits, 'O tamanho deve estar entre 44 e 48');
    if (typeof b.valorPagar !== 'string' || !/^\d+\.\d{2}$/.test(b.valorPagar)) return this.invalid('valorPagar', b.valorPagar);
    if (typeof b.dataVencimento !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(b.dataVencimento)) return this.invalid('dataVencimento', b.dataVencimento);
    const barcode = digits.length === 44 ? digits : lineToBarcode(digits);
    if (this.boletos.some((x) => x.barcode === barcode && !['ERRO', 'CANCELADO', 'REPROVADO', 'APROVACAO_EXPIRADA', 'AGENDADO_CANCELADO'].includes(x.status))) {
      return [406, { title: 'Ocorreu um erro!', detail: 'Título já liquidado / baixado.', timestamp: rfc(this.now()) }];
    }
    const cents = BigInt(b.valorPagar.replace('.', ''));
    const x: BoletoRec = { codigo: this.id(), barcode, cents, at: this.now(), vencimento: b.dataVencimento, status: this.approvals ? 'AGUARDANDO_APROVACAO' : 'EMPROCESSAMENTO' };
    if (!this.approvals) this.payBoletoNow(x);
    this.boletos.push(x);
    return [200, { quantidadeAprovadores: this.approvals ? 1 : 0, dataAgendamento: brt(x.at), statusPagamento: x.status, codigoTransacao: x.codigo }];
  }

  private payBoletoNow(x: BoletoRec): void {
    if (x.cents > this.balanceCents) {
      x.status = 'ERRO';
      return;
    }
    this.balanceCents -= x.cents;
    this.boletoMoves++;
    x.status = 'REALIZADO';
    x.paidAt = this.now();
    x.auth = `3140899${String(this.seq++).padStart(23, '0')}`;
  }

  approveBoletos(): void {
    for (const x of this.boletos) if (x.status === 'AGUARDANDO_APROVACAO') this.payBoletoNow(x);
  }

  private boletoList(q: URLSearchParams): [number, unknown?] {
    const ini = q.get('dataInicio');
    const fim = q.get('dataFim');
    if (!!ini !== !!fim) return this.invalid(ini ? 'dataFim' : 'dataInicio', '', 'Não foi possível converter o valor.');
    if (ini && fim && dayMs(fim) - dayMs(ini) > 90 * DAY) return this.invalid('dataFim', fim, 'Período máximo de 90 dias');
    const by = q.get('filtrarDataPor') ?? 'INCLUSAO';
    if (!['INCLUSAO', 'PAGAMENTO', 'VENCIMENTO'].includes(by)) return this.invalid('filtrarDataPor', by);
    const from = ini ? dayMs(ini) : this.now() - 30 * DAY;
    const to = fim ? dayMs(fim) + DAY - 1 : this.now();
    const wanted = q.get('codBarraLinhaDigitavel');
    const barcode = wanted ? (wanted.length === 44 ? wanted : lineToBarcode(wanted)) : undefined;
    const list = this.boletos.filter((x) => {
      const when = by === 'PAGAMENTO' ? x.paidAt : by === 'VENCIMENTO' ? dayMs(x.vencimento) : x.at;
      return when !== undefined && when >= from && when <= to
        && (!barcode || (x.barcode === barcode && this.now() - x.at >= this.paymentListLagMs))
        && (!q.get('codigoTransacao') || x.codigo === q.get('codigoTransacao'));
    });
    return [200, list.map((x) => ({
      codigoTransacao: x.codigo, codigoBarra: x.barcode, tipo: 'BOLETO', dataVencimentoDigitada: `${x.vencimento} 00:00:00`,
      dataVencimentoTitulo: `${x.vencimento} 00:00:00`, dataInclusao: brt(x.at), dataPagamento: x.paidAt ? brt(x.paidAt) : undefined,
      valorPago: x.paidAt ? NUM(x.cents) : undefined, valorNominal: NUM(x.cents), statusPagamento: x.status,
      aprovacoesNecessarias: this.approvals ? 1 : 0, aprovacoesRealizadas: 0, cpfCnpjBeneficiario: '12345678000195',
      nomeBeneficiario: 'Beneficiário', autenticacao: x.auth, nsu: String(1000 + this.boletos.indexOf(x)),
    }))];
  }

  /*------------------------------- statement -------------------------------*/

  private extrato(q: URLSearchParams): [number, unknown?] {
    const ini = q.get('dataInicio');
    const fim = q.get('dataFim');
    if (!ini || !fim) return this.invalid(ini ? 'dataFim' : 'dataInicio', '', 'Não foi possível converter o valor.');
    if (dayMs(fim) - dayMs(ini) > 90 * DAY) return this.invalid('dataFim', fim, 'Período máximo de 90 dias');
    const size = Number(q.get('tamanhoPagina') ?? 50);
    const page = Number(q.get('pagina') ?? 0);
    const all = this.statement.filter((s) => s.at >= dayMs(ini) && s.at < dayMs(fim) + DAY
      && (!q.get('tipoOperacao') || s.tipoOperacao === q.get('tipoOperacao'))
      && (!q.get('tipoTransacao') || s.tipoTransacao === q.get('tipoTransacao')));
    const pages = Math.max(1, Math.ceil(all.length / size));
    const slice = all.slice(page * size, (page + 1) * size);
    return [200, {
      totalPaginas: pages, totalElementos: all.length, ultimaPagina: page + 1 >= pages, primeiraPagina: page === 0, tamanhoPagina: size,
      numeroDeElementos: slice.length,
      transacoes: slice.map((s, i) => ({
        idTransacao: `tx-${page}-${i}`, dataInclusao: brtDay(s.at), dataTransacao: brtDay(s.at), tipoTransacao: s.tipoTransacao,
        tipoOperacao: s.tipoOperacao, valor: `${s.cents / 100n}.${(s.cents % 100n).toString().padStart(2, '0')}`, titulo: 'Boleto', descricao: 'Boleto recebido',
        detalhes: s.detalhes,
      })),
    }];
  }

  /*------------------------------- cobrança -------------------------------*/

  private cobrancaCreate(b: Record<string, any>): [number, unknown?] {
    if (typeof b.seuNumero !== 'string' || !b.seuNumero || b.seuNumero.length > 15) return this.invalid('seuNumero', b.seuNumero);
    if (typeof b.valorNominal !== 'number' || b.valorNominal < 2.5) return this.invalid('valorNominal', b.valorNominal);
    if (typeof b.dataVencimento !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(b.dataVencimento)) return this.invalid('dataVencimento', b.dataVencimento);
    if (typeof b.numDiasAgenda !== 'number' || b.numDiasAgenda < 0 || b.numDiasAgenda > 60) return this.invalid('numDiasAgenda', b.numDiasAgenda);
    const pg = b.pagador ?? {};
    for (const f of ['cpfCnpj', 'nome', 'tipoPessoa', 'cep', 'endereco', 'cidade', 'uf']) if (typeof pg[f] !== 'string' || !pg[f]) return this.invalid(`pagador.${f}`, pg[f]);
    const cents = BigInt(Math.round(b.valorNominal * 100));
    const now = this.now();
    // "Controle de duplicidade": the same seuNumero, valorNominal, dataVencimento and payer document within 30 minutes.
    // MOCK CHOICE: the refusal is a 400 Problema (its shape is not documented).
    const dup = [...this.cobrancas.values()].find((c) => c.seuNumero === b.seuNumero && c.cents === cents && c.vencimento === b.dataVencimento
      && c.cpfCnpj === pg.cpfCnpj && now - c.at < 30 * 60_000);
    if (dup) return [400, { title: 'Dados inválidos.', status: 400, detail: 'Cobrança duplicada.' }];
    const c: CobRec = { codigo: this.id(), seuNumero: b.seuNumero, cents, vencimento: b.dataVencimento, cpfCnpj: pg.cpfCnpj, at: now, gets: 0, situacao: 'EM_PROCESSAMENTO' };
    this.cobrancas.set(c.codigo, c);
    return [200, { codigoSolicitacao: c.codigo }];
  }

  private issue(c: CobRec): void {
    if (c.situacao !== 'EM_PROCESSAMENTO' || c.gets < this.emissionGets) return;
    c.nossoNumero = String(10_000_000 + this.cobrancas.size + this.seq++).slice(-8);
    const bol = buildBankBoleto({ bankCode: '077', amountCents: c.cents, dueDate: c.vencimento, freeField: `0001112${c.nossoNumero.padStart(18, '0')}` });
    c.line = bol.line;
    c.barcode = bol.barcode;
    c.situacao = 'A_RECEBER';
  }

  private cobrancaView(c: CobRec): unknown {
    c.gets++;
    this.issue(c);
    return {
      cobranca: {
        codigoSolicitacao: c.codigo, seuNumero: c.seuNumero, dataEmissao: brtDay(c.at), dataVencimento: c.vencimento, valorNominal: NUM(c.cents),
        tipoCobranca: 'SIMPLES', situacao: c.situacao, dataSituacao: brtDay(c.paidAt ?? c.at),
        ...(c.paidAt ? { valorTotalRecebido: `${c.cents / 100n}.${(c.cents % 100n).toString().padStart(2, '0')}`, origemRecebimento: 'BOLETO' } : {}),
        arquivada: false, pagador: { cpfCnpj: c.cpfCnpj, nome: 'Pagador' },
      },
      ...(c.line ? { boleto: { nossoNumero: c.nossoNumero, codigoBarras: c.barcode, linhaDigitavel: c.line } } : {}),
    };
  }

  private cobrancaList(q: URLSearchParams): [number, unknown?] {
    const ini = q.get('dataInicial');
    const fim = q.get('dataFinal');
    if (!ini || !fim) return this.invalid(ini ? 'dataFinal' : 'dataInicial', '', 'Não foi possível converter o valor.');
    const by = q.get('filtrarDataPor') ?? 'VENCIMENTO';
    const page = Number(q.get('paginacao.paginaAtual') ?? 0);
    const size = Number(q.get('paginacao.itensPorPagina') ?? 100);
    if (size > 1000) return this.invalid('paginacao.itensPorPagina', size);
    const all = [...this.cobrancas.values()].filter((c) => {
      const when = by === 'EMISSAO' ? brtDay(c.at) : by === 'PAGAMENTO' ? (c.paidAt ? brtDay(c.paidAt) : '') : c.vencimento;
      return when >= ini && when <= fim && (!q.get('seuNumero') || c.seuNumero === q.get('seuNumero')) && (!q.get('situacao') || c.situacao === q.get('situacao'));
    });
    const pages = Math.max(1, Math.ceil(all.length / size));
    const slice = all.slice(page * size, (page + 1) * size);
    return [200, {
      totalPaginas: pages, totalElementos: all.length, tamanhoPagina: size, primeiraPagina: page === 0, ultimaPagina: page + 1 >= pages,
      numeroDeElementos: slice.length,
      cobrancas: slice.map((c) => ({
        cobranca: {
          codigoSolicitacao: c.codigo, seuNumero: c.seuNumero, situacao: c.situacao, dataSituacao: brtDay(c.at), dataEmissao: brtDay(c.at),
          dataVencimento: c.vencimento, valorNominal: `${c.cents / 100n}.${(c.cents % 100n).toString().padStart(2, '0')}`, tipoCobranca: 'SIMPLES',
          pagador: { nome: 'Pagador', cpfCnpj: c.cpfCnpj },
        },
        ...(c.line ? { boleto: { nossoNumero: c.nossoNumero, codigoBarras: c.barcode, linhaDigitavel: c.line } } : {}),
      })),
    }];
  }

  /** Someone pays a registered boleto: the charge is RECEBIDO and the statement shows the credit. */
  payCobranca(codigo: string, at = this.now()): CobRec {
    const c = this.cobrancas.get(codigo)!;
    if (c.situacao !== 'A_RECEBER') throw new Error(`charge is ${c.situacao}`);
    c.situacao = 'RECEBIDO';
    c.paidAt = at;
    this.balanceCents += c.cents;
    this.statement.push({
      at, tipoOperacao: 'C', tipoTransacao: 'BOLETO_COBRANCA', cents: c.cents,
      detalhes: {
        dataVencimento: c.vencimento, dataTransacao: `${brt(at)}.123`, nossoNumero: c.nossoNumero, seuNumero: c.seuNumero, codBarras: c.barcode,
        juros: '0', multa: '0', nome: 'BoletoCobranca', cpfCnpj: c.cpfCnpj, dataEmissao: brtDay(c.at), tipoDetalhe: 'COMPLETE',
      },
    });
    return c;
  }

  /*-------------------------------- API Pix --------------------------------*/

  private pixList(q: URLSearchParams): [number, unknown?] {
    const inicio = Date.parse(q.get('inicio') ?? '');
    const fim = Date.parse(q.get('fim') ?? '');
    if (Number.isNaN(inicio) || Number.isNaN(fim)) return [400, { title: 'Consulta inválida', status: 400 }];
    const page = Number(q.get('paginacao.paginaAtual') ?? 0);
    const size = Number(q.get('paginacao.itensPorPagina') ?? 100);
    const all = this.received.filter((p) => Date.parse(p.horario) >= inicio && Date.parse(p.horario) <= fim);
    const pages = Math.max(1, Math.ceil(all.length / size));
    return [200, {
      parametros: { inicio: q.get('inicio'), fim: q.get('fim'), paginacao: { paginaAtual: page, itensPorPagina: size, quantidadeDePaginas: pages, quantidadeTotalDeItens: all.length } },
      pix: all.slice(page * size, (page + 1) * size),
    }];
  }

  /*------------------------------- API Pix cob -------------------------------*/

  /**
   * `PUT /cob/{txid}`, answered as `CobGerada`. MOCK CHOICE: a repeat for a txid that exists answers the existing
   * charge unchanged (the Banco Central's manual calls a repeated PUT idempotent; Inter's page does not say), and the
   * location host and `pixCopiaECola` are placeholders - Inter's documents give no example of either.
   */
  private cobPut(txid: string, b: Record<string, any>): [number, unknown?] {
    if (!/^[a-zA-Z0-9]{26,35}$/.test(txid)) return this.invalid('txid', txid);
    const existing = this.charges.get(txid);
    if (existing) return [201, existing];
    if (typeof b.chave !== 'string' || !b.chave || b.chave.length > 77) return this.invalid('chave', b.chave);
    if (typeof b.valor?.original !== 'string' || !/^\d{1,10}\.\d{2}$/.test(b.valor.original)) return this.invalid('valor.original', b.valor?.original);
    const expiracao = b.calendario?.expiracao ?? 86_400;
    if (!Number.isInteger(expiracao) || expiracao < 1) return this.invalid('calendario.expiracao', expiracao);
    const criacao = rfc(this.now());
    const id = ++this.seq;
    const location = `spi-qrcode.bancointer.example/pj/v2/cob/${id.toString(16).padStart(32, '0')}`;
    const charge: Record<string, any> = {
      calendario: { criacao, expiracao }, txid, revisao: 0, loc: { id, location, tipoCob: 'cob', criacao }, location, status: 'ATIVA',
      valor: { original: b.valor.original, modalidadeAlteracao: b.valor.modalidadeAlteracao ?? 0 }, chave: b.chave,
      ...(typeof b.solicitacaoPagador === 'string' ? { solicitacaoPagador: b.solicitacaoPagador } : {}),
      pixCopiaECola: `00020101021226${location.length + 22}0014br.gov.bcb.pix25${location.length}${location}5204000053039865802BR`,
    };
    this.charges.set(txid, charge);
    return [201, charge];
  }

  /** `PATCH /cob/{txid}` to `REMOVIDA_PELO_USUARIO_RECEBEDOR`. MOCK CHOICE: revising a charge that is not ATIVA is a 400. */
  private cobPatch(txid: string, b: Record<string, any>): [number, unknown?] {
    const c = this.charges.get(txid);
    if (!c) return [404, { title: 'Não Encontrado', status: 404, detail: 'Cobrança não encontrada.' }];
    if (b.status !== 'REMOVIDA_PELO_USUARIO_RECEBEDOR') return this.invalid('status', b.status);
    if (c.status !== 'ATIVA') return [400, { title: 'Cobrança não pode ser revisada', status: 400, detail: `A cobrança está ${c.status}.` }];
    c.status = 'REMOVIDA_PELO_USUARIO_RECEBEDOR';
    c.revisao += 1;
    return [200, c];
  }

  /** Someone pays a charge's QR code: a received Pix carrying its txid, and the charge CONCLUIDA. */
  payCob(txid: string): ReceivedPix {
    const c = this.charges.get(txid);
    if (!c || c.status !== 'ATIVA') throw new Error(`no active charge ${txid}`);
    c.status = 'CONCLUIDA';
    const credit: ReceivedPix = {
      endToEndId: `E00416968${brt(this.now()).replace(/\D/g, '').slice(0, 12)}${String(++this.seq).padStart(11, '0')}`,
      txid, valor: c.valor.original, chave: c.chave, horario: new Date(this.now()).toISOString(),
    };
    this.received.push(credit);
    return credit;
  }
}
