import { describe, expect, it } from 'vitest';
import type { Hex } from 'viem';
import { Rail, newPixSalt, pixKeyCommitment, railMask } from '@mova/ramp';
import { SaleState } from '../src/abi.js';
import { evaluateSale, mintCostCentsE18, quoteOffer, redeemValueCentsE18, type CostQuote, type OfferPricing } from '../src/pricing.js';
import { serveLpNode } from '../src/server.js';
import { MOVVA, RESERVE, USDT } from './fake-chain.js';
import { E18, MOVVA_LIQUIDITY, U, harness, type Harness } from './harness.js';

const RATE = 5_400_000_000_000_000_000n;
const SELLER = 'vendedor@pix.example';

describe('Movva pricing: cost and redemption value, carried past the centavo', () => {
  it('a minted Movva costs what the USDT cost, over the Movva it buys after the fee, rounded up', () => {
    // 5,45 / (5,40 x 0,9995) x 100 = 100.976414132992422136994...
    expect(mintCostCentsE18({ rateE18: RATE, payRateE18: 5_450_000_000_000_000_000n, mintFeeBps: 5 })).toBe(100_976_414_132_992_422_137n);
    expect(mintCostCentsE18({ rateE18: RATE, payRateE18: RATE, mintFeeBps: 0 })).toBe(100n * E18);
  });

  it('a Movva bought back is worth min(1, ratio) of par, less the fee, in USDT sold below the rate, rounded down', () => {
    const sell = (RATE * 9_970n) / 10_000n;
    expect(redeemValueCentsE18({ rateE18: RATE, sellRateE18: sell, redeemFeeBps: 0, collateralRatioBps: 10_800n })).toBe(99_700_000_000_000_000_000n);
    expect(redeemValueCentsE18({ rateE18: RATE, sellRateE18: sell, redeemFeeBps: 0, collateralRatioBps: 9_000n })).toBe(89_730_000_000_000_000_000n);
    expect(redeemValueCentsE18({ rateE18: RATE, sellRateE18: RATE, redeemFeeBps: 10, collateralRatioBps: 10_000n })).toBe(99_900_000_000_000_000_000n);
  });

  const cfg: OfferPricing = {
    spreadBps: 100, minSpreadBps: 50, maxOracleDeviationBps: 100, bandMarginBps: 100, refreshDriftBps: 50,
    maxReferenceAgeSeconds: 120, oracleStaleMarginSeconds: 300,
  };
  const par = { price: 100n, updatedAt: 1_000n };
  const quote = (cost?: CostQuote) => quoteOffer({ reference: par, oracle: par, bandBps: 500n, chainNow: 1_000n, wallNow: 1_000n, cfg, cost });

  it('a Movva offer asks the spread over its cost as well as over par, and pulls when the band cannot carry it', () => {
    expect(quote()).toMatchObject({ ok: true, price: 101n, floor: 101n, ceiling: 104n });
    // Cost R$ 1,002: floor ceil(100,2 x 1,005) = 101, aim ceil(100,2 x 1,01) = 102.
    expect(quote({ ok: true, centsE18: 100_200_000_000_000_000_000n })).toMatchObject({ ok: true, price: 102n, floor: 101n });
    // Cost R$ 1,036: the floor, 105, is above the 104 the band leaves.
    expect(quote({ ok: true, centsE18: 103_600_000_000_000_000_000n })).toEqual({ ok: false, reason: 'cost_above_band' });
    expect(quote({ ok: false })).toEqual({ ok: false, reason: 'cost_unavailable' });
  });

  it('a Movva sale must be a buy against what redeeming pays, exactly, not only against par', () => {
    const base = {
      brlCents: 99_000n, amount: 1_000n * E18, decimals: 18, reference: par, oracle: par, chainNow: 1_000n, wallNow: 1_000n,
      cfg: { minMarginBps: 50, maxOracleDeviationBps: 100, maxReferenceAgeSeconds: 120, oracleStaleMarginSeconds: 300 },
    };
    expect(evaluateSale(base).ok).toBe(true);
    expect(evaluateSale({ ...base, value: { ok: true, centsE18: 99_700_000_000_000_000_000n } }).ok).toBe(true);
    // Worth R$ 0,989 redeemed: R$ 0,99 less a 0,5% margin is not a buy, though par says it is.
    expect(evaluateSale({ ...base, value: { ok: true, centsE18: 98_900_000_000_000_000_000n } })).toEqual({ ok: false, reason: 'price_too_high' });
    expect(evaluateSale({ ...base, value: { ok: false } })).toEqual({ ok: false, reason: 'cost_unavailable' });
  });
});

async function movvaSale(h: Harness, amount: bigint, brlCents: bigint): Promise<Hex> {
  const salt = newPixSalt();
  const saleId = h.chain.openSale({ asset: MOVVA, amount, brlCents, payeeKeyHash: pixKeyCommitment(SELLER, salt), railMask: railMask(Rail.PIX) });
  await h.node.offramp!.submitPayee(saleId, { pixKey: SELLER, salt });
  return saleId;
}

describe('the Movva gateway', () => {
  it('mints exactly what the offer needs, approves exactly that, and posts at par plus the spread', async () => {
    const h = harness({ gateway: true, offramp: false, confirmations: 1 });
    await h.tick();
    expect(h.node.offers!.status.get(MOVVA)).toMatchObject({ quoting: true, price: 101n, available: MOVVA_LIQUIDITY });
    const mints = h.chain.executed('mint');
    expect(mints).toHaveLength(1);
    // ceil(10.000 Movva x 1e6 / R$ 5,40): the least USDT that covers the need.
    expect(mints[0]).toMatchObject({ amountIn: 1_851_851_852n, amountOut: 10_000_000_000_800_000_000_000n });
    expect(await h.chain.balance(MOVVA)).toBe(800_000_000_000n); // the rounding: under one USDT unit's worth of Movva
    expect(h.chain.writes.filter((w) => w === 'approve')).toHaveLength(1);
    expect(await h.chain.allowance(USDT, RESERVE)).toBe(0n);
    expect(h.chain.reserveState().supply).toBe(1_000_000n * E18 + 10_000_000_000_800_000_000_000n);

    await h.tick(); // a confirmation later, the intent is final
    const [op] = h.node.store.gatewayOps.values();
    expect(op).toMatchObject({
      op: 'mint', amountIn: 1_851_851_852n, need: MOVVA_LIQUIDITY, result: { outcome: 'MINED', amountOut: 10_000_000_000_800_000_000_000n },
    });
    expect(h.node.metrics.get('mova_lp_gateway_mints_total', { outcome: 'mined' })).toBe(1);
    expect(h.node.metrics.get('mova_lp_gateway_usdt_minted_units_total')).toBe(1_851_851_852);
  });

  it('tops the offer up by minting only what takers drained, less what the wallet already holds', async () => {
    const h = harness({ gateway: true, offramp: false, confirmations: 1 });
    await h.tick();
    const id = h.node.offers!.status.get(MOVVA)!.activeOfferId!;
    for (let i = 0; i < 2; i++) h.chain.releaseAsOther(h.chain.lockOrder(id, 3_000n * E18));
    await h.tick();
    const mints = h.chain.executed('mint');
    expect(mints).toHaveLength(2);
    // 6.000 Movva less the 0,0000008 in the wallet: ceil(5.999,9999992 x 1e6 / 5,40) USDT units.
    expect(mints[1].amountIn).toBe(1_111_111_111n);
    expect((await h.chain.offer(id)).availableWei).toBe(MOVVA_LIQUIDITY);
    for (let i = 0; i < 3; i++) await h.tick();
    expect(h.chain.executed('mint')).toHaveLength(2); // re-planning from fresh balances finds nothing to do
  });

  it('prices the mint fee and its USDT cost in, and pulls the offer when the band cannot carry them', async () => {
    const h = harness({ gateway: true, offramp: false, confirmations: 1, tweak: (o) => { o.gateway!.mint.usdtCostBps = 300; } });
    h.chain.setReserve({ mintFeeBps: 50n });
    await h.tick();
    // 1,03 / 0,995 = R$ 1,0352 a Movva: at least 105 with the 50 bps floor, over the band's 104.
    expect(h.node.offers!.status.get(MOVVA)).toMatchObject({ quoting: false, reason: 'cost_above_band' });
    expect(h.chain.attempts).toEqual([]);
    h.node.gateway!.o.mint.usdtCostBps = 0;
    await h.tick();
    // R$ 1,005 a Movva: floor ceil(100,5 x 1,005) = 102, where par alone would have asked 101.
    expect(h.node.offers!.status.get(MOVVA)).toMatchObject({ quoting: true, price: 102n });
  });

  it('buys Movva below what redeeming pays, then redeems all but the working balance, and supply falls', async () => {
    const h = harness({ gateway: true, onramp: false, confirmations: 1, tweak: (o) => { o.gateway!.redeem.keepMovva = 100n * E18; } });
    const saleId = await movvaSale(h, 1_000n * E18, 99_000n);
    const usdtBefore = await h.chain.balance(USDT);
    const supplyBefore = h.chain.reserveState().supply;
    await h.tick();
    await h.tick();
    expect((await h.chain.sale(saleId)).state).toBe(SaleState.SETTLED);
    // 900 Movva at par: floor(900 x 1e6 / 5,40) USDT units.
    expect(h.chain.executed('redeem')).toMatchObject([{ amountIn: 900n * E18, amountOut: 166_666_666n }]);
    expect(await h.chain.balance(MOVVA)).toBe(100n * E18);
    expect((await h.chain.balance(USDT)) - usdtBefore).toBe(166_666_666n);
    expect(h.chain.reserveState().supply).toBe(supplyBefore - 900n * E18);
  });

  it('does not buy a sale that par calls a buy but redeeming would not repay', async () => {
    const h = harness({ gateway: true, onramp: false, confirmations: 1, tweak: (o) => { o.gateway!.redeem.usdtSaleBps = 100; } });
    const saleId = await movvaSale(h, 1_000n * E18, 99_000n);
    await h.tick();
    expect((await h.chain.sale(saleId)).state).toBe(SaleState.OPEN);
    expect(h.node.offramp!.skipped.get(saleId.toLowerCase())).toBe('price_too_high');
  });

  it('redeems only what the reserve can pay now, and says so when it can pay nothing', async () => {
    const h = harness({ gateway: true, onramp: false, confirmations: 1 });
    h.chain.giveMovva(5_000n * E18);
    h.chain.setReserve({ liquidUsdt: 500n * U });
    await h.tick();
    const [r] = h.chain.executed('redeem');
    expect(r.amountOut! <= 500n * U && r.amountOut! > 499n * U).toBe(true);
    await h.tick();
    expect(h.chain.executed('redeem')).toHaveLength(1);
    expect(h.node.metrics.get('mova_lp_gateway_blocked', { op: 'redeem', reason: 'insufficient_liquidity' })).toBe(1);
  });

  it('shows on /status and /metrics what it can do and why not, and nothing secret', async () => {
    const h = harness({ gateway: true, offramp: false, confirmations: 1 });
    await h.tick();
    h.chain.setReserve({ mintPaused: true });
    await h.tick();
    const srv = serveLpNode(h.node, { mode: 'ops' });
    const port = await srv.listen(0);
    try {
      const body = await (await fetch(`http://127.0.0.1:${port}/status`)).text();
      const status = JSON.parse(body) as {
        gateway: {
          mint: { canMint: boolean; blocked: string[]; last: { amountIn: string } | null };
          redeem: { canRedeem: boolean; held: unknown };
          reserveState: { collateralRatioBps: string };
          pending: unknown[];
        };
      };
      expect(status.gateway.mint).toMatchObject({ canMint: false, blocked: ['mint_paused'], last: { amountIn: '1851851852' } });
      expect(status.gateway.redeem).toMatchObject({ canRedeem: true, held: null });
      expect(status.gateway.reserveState.collateralRatioBps).toMatch(/^\d+$/);
      expect(status.gateway.pending).toEqual([]);
      const metrics = await (await fetch(`http://127.0.0.1:${port}/metrics`)).text();
      expect(metrics).toMatch(/^mova_lp_gateway_blocked\{op="mint",reason="mint_paused"\} 1$/m);
      expect(metrics).toMatch(/^mova_lp_gateway_mints_total\{outcome="mined"\} 1$/m);
      expect(metrics).toMatch(/^mova_lp_gateway_pending 0$/m);
      expect(metrics).toMatch(/^mova_lp_gateway_rate_readable 1$/m);
      for (const salt of [...h.node.store.offerSalts.values()].map((x) => x.salt.slice(2))) expect(body + metrics).not.toContain(salt);
    } finally {
      await srv.close();
    }
  });
});
