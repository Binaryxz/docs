import { describe, expect, it } from 'vitest';
import { existsSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { toEventSelector, toFunctionSelector, type Abi, type AbiEvent, type AbiFunction } from 'viem';

type AbiError = Extract<Abi[number], { type: 'error' }>;
import {
  ERC4626_ABI, FIAT_ESCROW_ABI, OFFRAMP_ESCROW_ABI, ORACLE_ABI, PERMISSIONLESS_REGISTRY_ABI, PYTH_FX_ERRORS_ABI, REGISTRY_ABI, RESERVE_ABI, VERIFIER_ABI,
  ZKTLS_VERIFIER_ERRORS_ABI, NODE_REWARDS_ABI,
} from '../src/abi.js';

/**
 * The hand-transcribed ABI against the compiled contracts. Skipped when no build is present, so a
 * checkout without Foundry still runs the suite; CI builds first (see the README).
 *
 * `LP_NODE_FORGE_OUT` points at a build directory; otherwise the repository's `forge-out`.
 */
const ROOT = fileURLToPath(new URL('../../../', import.meta.url));
const OUT = process.env.LP_NODE_FORGE_OUT ?? join(ROOT, 'forge-out');

const artifact = (file: string, name: string): Abi | undefined => {
  const p = join(OUT, file, `${name}.json`);
  return existsSync(p) ? (JSON.parse(readFileSync(p, 'utf8')) as { abi: Abi }).abi : undefined;
};

const sig = (x: AbiFunction | AbiEvent) => `${x.name}(${x.inputs.map((i) => i.type).join(',')})`;

function compare(mine: Abi, compiled: Abi): void {
  for (const item of mine) {
    if (item.type === 'function') {
      const theirs = compiled.find((c): c is AbiFunction => c.type === 'function' && toFunctionSelector(c) === toFunctionSelector(item));
      expect(theirs, `function ${sig(item)} is not in the compiled contract`).toBeDefined();
      expect(theirs!.outputs.map((o) => o.type), `${item.name} outputs`).toEqual(item.outputs.map((o) => o.type));
      expect(theirs!.stateMutability, `${item.name} mutability`).toBe(item.stateMutability);
    } else if (item.type === 'event') {
      const theirs = compiled.find((c): c is AbiEvent => c.type === 'event' && toEventSelector(c) === toEventSelector(item));
      expect(theirs, `event ${sig(item)} is not in the compiled contract`).toBeDefined();
      expect(theirs!.inputs.map((i) => i.indexed ?? false), `${item.name} indexing`).toEqual(item.inputs.map((i) => i.indexed ?? false));
    }
  }
}

const errorsOf = (abi: Abi) => new Set(abi.filter((x): x is AbiError => x.type === 'error').map((e) => `${e.name}(${e.inputs.map((i: { type: string }) => i.type).join(',')})`));

describe.skipIf(!existsSync(join(OUT, 'FiatEscrow.sol', 'FiatEscrow.json')))('the ABI matches the compiled contracts', () => {
  /** Governance-only errors no LP call can raise, and SafeTransferLib's overload of TransferFailed. */
  const NOT_FOR_LP = new Set([
    'AlreadyScheduled(bytes32)', 'BadGovernanceDelay(uint256)', 'ChangeExpired(bytes32)', 'ChangeMustBeScheduled(bytes4)',
    'NotDelayable(bytes4)', 'NotGovernor()', 'NotReadyYet(bytes32,uint256)', 'NotScheduled(bytes32)', 'SetupAlreadyComplete()',
    'TransferFailed(address,address,uint256)',
  ]);
  const everyErrorDecodes = (mine: Abi, compiled: Abi) => {
    const have = errorsOf(mine);
    for (const e of errorsOf(compiled)) if (!NOT_FOR_LP.has(e)) expect(have.has(e), `${e} would not decode`).toBe(true);
  };

  it('FiatEscrow', () => {
    const compiled = artifact('FiatEscrow.sol', 'FiatEscrow')!;
    compare(FIAT_ESCROW_ABI, compiled);
    everyErrorDecodes(FIAT_ESCROW_ABI, compiled);
  });

  it('OffRampEscrow', () => {
    const compiled = artifact('OffRampEscrow.sol', 'OffRampEscrow')!;
    compare(OFFRAMP_ESCROW_ABI, compiled);
    everyErrorDecodes(OFFRAMP_ESCROW_ABI, compiled);
  });

  it('LPRegistry, and the oracles the node reads: the escrows\' asset oracles and the FX leg behind them', () => {
    compare(REGISTRY_ABI, artifact('LPRegistry.sol', 'LPRegistry')!);
    compare(PERMISSIONLESS_REGISTRY_ABI, artifact('PermissionlessLPRegistry.sol', 'PermissionlessLPRegistry')!);
    // USDT and ETH are listed against a ChainlinkSignedFxOracle, Movva against the reserve; the FX leg is a PythFxOracle.
    compare(ORACLE_ABI, artifact('ChainlinkSignedFxOracle.sol', 'ChainlinkSignedFxOracle')!);
    compare(ORACLE_ABI, artifact('MovvaReserve.sol', 'MovvaReserve')!);
    compare(ORACLE_ABI, artifact('PythFxOracle.sol', 'PythFxOracle')!);
    compare(ORACLE_ABI, artifact('ScaledFxBandOracle.sol', 'ScaledFxBandOracle')!);
  });

  it('every verifier answers provesBankSession, and every refusal a release or settlement can surface decodes', () => {
    for (const [file, name] of [['ReclaimZkTlsVerifier.sol', 'ReclaimZkTlsVerifier']] as const) {
      const compiled = artifact(file, name)!;
      compare(VERIFIER_ABI, compiled);
      // Governance and constructor refusals never reach verifyPayment.
      const notFromVerify = new Set([...NOT_FOR_LP, 'BadThreshold()', 'BadUrlPrefix()', 'NoEndpoints()', 'BadRailMask()', 'ZeroAddress()']);
      const have = new Set([...errorsOf(FIAT_ESCROW_ABI)].filter((e) => errorsOf(OFFRAMP_ESCROW_ABI).has(e)));
      for (const e of errorsOf(compiled)) if (!notFromVerify.has(e)) expect(have.has(e), `${name}: ${e} would not decode`).toBe(true);
    }
    const zk = errorsOf(artifact('ReclaimZkTlsVerifier.sol', 'ReclaimZkTlsVerifier')!);
    for (const e of errorsOf(ZKTLS_VERIFIER_ERRORS_ABI)) expect(zk.has(e), `${e} is not ReclaimZkTlsVerifier's`).toBe(true);
  });
});

describe.skipIf(!existsSync(join(OUT, 'PythFxOracle.sol', 'PythFxOracle.json')))('the FX leg\'s refusals decode where they surface', () => {
  it('PythFxOracle\'s read errors, through the reserve and through an escrow\'s band check', () => {
    const pyth = errorsOf(artifact('PythFxOracle.sol', 'PythFxOracle')!);
    const mockPyth = errorsOf(artifact('MockPyth.sol', 'MockPyth')!);
    // Every one listed is really the oracle's (or, PriceFeedNotFound, Pyth's own)...
    for (const e of errorsOf(PYTH_FX_ERRORS_ABI)) expect(pyth.has(e) || mockPyth.has(e), `${e} is not PythFxOracle's or Pyth's`).toBe(true);
    // ...and every one a read can raise decodes where the node meets it.
    const governance = new Set(['AlreadyScheduled(bytes32)', 'BadGovernanceDelay(uint256)', 'ChangeExpired(bytes32)', 'ChangeMustBeScheduled(bytes4)',
      'NotDelayable(bytes4)', 'NotGovernor()', 'NotReadyYet(bytes32,uint256)', 'NotScheduled(bytes32)', 'SetupAlreadyComplete()',
      'BadFeedId()', 'BadLimits()', 'ZeroAddress()']);
    for (const abi of [RESERVE_ABI, FIAT_ESCROW_ABI, OFFRAMP_ESCROW_ABI]) {
      const have = errorsOf(abi);
      for (const e of pyth) if (!governance.has(e)) expect(have.has(e), `${e} would not decode`).toBe(true);
      expect(have.has('PriceFeedNotFound()')).toBe(true);
    }
    const cross = errorsOf(artifact('ChainlinkSignedFxOracle.sol', 'ChainlinkSignedFxOracle')!);
    for (const e of cross) if (!governance.has(e) && e !== 'BadMaxAge()') expect(errorsOf(FIAT_ESCROW_ABI).has(e), `${e} would not decode`).toBe(true);
  });
});

describe.skipIf(!existsSync(join(OUT, 'MovvaReserve.sol', 'MovvaReserve.json')))('the gateway ABI matches MovvaReserve', () => {
  /** Errors only governance or the treasurer can raise: no mint or redeem reaches them. */
  const NOT_FOR_GATEWAY = new Set([
    'AlreadyScheduled(bytes32)', 'BadGovernanceDelay(uint256)', 'ChangeExpired(bytes32)', 'ChangeMustBeScheduled(bytes4)',
    'NotDelayable(bytes4)', 'NotGovernor()', 'NotReadyYet(bytes32,uint256)', 'NotScheduled(bytes32)', 'SetupAlreadyComplete()',
    'AssetMismatch()', 'BadBps()', 'BadMaxAge()', 'FeeTooHigh()', 'NoVault()',
    'NotGuardianOrGovernor()', 'RatiosOutOfOrder()', 'VaultNotEmpty()',
    // The principal-locked reserve (client rule, 21 October 2026): the yield recipient's setter and the
    // harvest, which no gateway call reaches.
    'BadYieldRecipient()', 'NothingToHarvest()',
  ]);

  it('MovvaReserve: every function, event and mint/redeem error', () => {
    const compiled = artifact('MovvaReserve.sol', 'MovvaReserve')!;
    compare(RESERVE_ABI, compiled);
    const have = errorsOf(RESERVE_ABI);
    for (const e of errorsOf(compiled)) if (!NOT_FOR_GATEWAY.has(e)) expect(have.has(e), `${e} would not decode`).toBe(true);
  });

  it('a halt by the reserve\'s DivergenceBreaker decodes, from the breaker\'s own compiled errors', () => {
    // The breaker is a separate contract, so its errors are not in MovvaReserve's ABI; they reach the gateway bubbled
    // through the reserve's call to it, and an undecodable one would be reported as an unknown failure, not a hold.
    const breaker = artifact('DivergenceBreaker.sol', 'DivergenceBreaker')!;
    const have = errorsOf(RESERVE_ABI);
    for (const e of ['SourcesDiverge(uint256,uint256,uint256)', 'SourceUnavailable(uint256)', 'InsufficientGas()']) {
      expect(errorsOf(breaker).has(e), `${e} is not the breaker's`).toBe(true);
      expect(have.has(e), `${e} would not decode`).toBe(true);
    }
  });

  it('the vault view the reserve liquidity is read from', () => {
    compare(ERC4626_ABI, artifact('YieldVault.sol', 'YieldVault')!);
  });
});

describe.skipIf(!existsSync(join(OUT, 'NodeRewards.sol', 'NodeRewards.json')))('NodeRewards', () => {
  it('matches the compiled contract, and every refusal a claim or finalize can raise decodes', () => {
    const compiled = artifact('NodeRewards.sol', 'NodeRewards')!;
    compare(NODE_REWARDS_ABI, compiled);
    const have = errorsOf(NODE_REWARDS_ABI);
    // What `claim`, `finalize` and the views an LP reads can revert with; governance and hook errors are not an LP's.
    for (const e of [
      'NotFinalized(uint256)', 'AlreadyClaimed(uint256)', 'NothingToClaim(uint256)', 'TooManyEpochs()', 'ZeroAddress()', 'SetupIncomplete()',
      'ReentrancyGuardReentrantCall()', 'SafeERC20FailedOperation(address)',
    ]) {
      expect(errorsOf(compiled).has(e), `${e} is not in the compiled contract`).toBe(true);
      expect(have.has(e), `${e} would not decode`).toBe(true);
    }
  });
});
