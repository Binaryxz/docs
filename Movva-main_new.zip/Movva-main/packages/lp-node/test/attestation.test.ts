import { describe, expect, it } from 'vitest';
import { decodeAbiParameters, recoverTypedDataAddress, type Hex } from 'viem';
import { privateKeyToAccount, type PrivateKeyAccount } from 'viem/accounts';
import {
  Attestor, EIP712_DOMAIN, PAYMENT_TYPES, Rail, cardCheckoutTotal, cardFee, cardMerchantCommitment, cardTransactionId, pixKeyCommitment,
  type ObservedCardCapture, type ObservedPayment, type OrderTerms,
} from '@mova/ramp';
import { OrderState } from '../src/abi.js';
import { ProofUnavailable, QuorumProver, type AttestorEndpoint, type SignedPayment } from '../src/attestation.js';
import { NATIVE } from '../src/chain.js';
import { bookKey } from '../src/offers.js';
import { CARD_FEE_BPS, CARD_MERCHANT, LP_PIX_KEY, VERIFIER, harness } from './harness.js';

/**
 * QuorumProver (attestation.ts): the card rail's prover, and which attestors' signatures become a proof. It refuses
 * PIX and boleto outright - the escrows settle bank payments only on zkTLS. The rest hands it attestors that sign
 * something other than one honest capture - under another id, for another merchant or amount, or two captures at
 * once - and checks what it refuses to build, what it says, and, through the node, what reaches the chain.
 */

const CHAIN_ID = 31337; // FakeChain's
// anvil's well-known development keys: test keys, never funded anywhere that matters.
const KEYS: Hex[] = [
  '0x47e179ec197488593b187f80a00eb0da91f1b9d0b13f8733639f19c30a34926a',
  '0x8b3a350cf5c34c9194ca85829a2df0ec3153be0318b5e2d3348e872092edffba',
  '0x92db14e403b83dfe3df233f83dfa3a0d7096f21ca9b0d6d6b8d88b2b4ec1564e',
  '0x4bbbf85ce3377467afe5d46f804f221813b2bb87f24d81f60f1fcdbf7cbf4356',
];
const SALT: Hex = `0x${'5a'.repeat(32)}`;
const PAYER_REF: Hex = `0x${'77'.repeat(32)}`;
const MERCHANT = { ...CARD_MERCHANT, feeBps: CARD_FEE_BPS };
/** One capture, under the id each source knows it by: the acquirer's own TID, and the payment gateway's NSU. */
const TID = 'TID-20260914-0001';
const NSU = 'NSU-000123456';

const terms: OrderTerms = {
  orderId: `0x${'0a'.repeat(32)}`, payeeKeyHash: cardMerchantCommitment(MERCHANT, SALT), brlCents: 10_000n, lockedAt: 1_000n, acceptedRails: [Rail.CARD],
};
/** The node's claim, as its acquirer showed the charge: under the acquirer's TID, for the order plus its card fee. */
const seen: ObservedCardCapture = {
  ...CARD_MERCHANT, transactionId: TID, salt: SALT, feeBps: CARD_FEE_BPS, payerRef: PAYER_REF, status: 'CAPTURED',
  capturedAmountBrlCents: cardCheckoutTotal(10_000n, CARD_FEE_BPS), capturedAt: 1_030n,
};

/** A capture as an attestor signs it: the acquirer-scoped id, the merchant commitment, the order's amount net of the fee. */
const observedCard = (t: OrderTerms, c: ObservedCardCapture, id = c.transactionId): ObservedPayment => ({
  bankTxId: cardTransactionId(c.acquirerId, id), payeeKeyHash: cardMerchantCommitment({ acquirerId: c.acquirerId, merchantId: c.merchantId, feeBps: c.feeBps }, c.salt),
  payerRef: c.payerRef, amountBrlCents: c.capturedAmountBrlCents - cardFee(t.brlCents, c.feeBps), paidAt: c.capturedAt, rail: Rail.CARD,
});

/** What an attestor's source shows for a capture, or undefined when it has no such charge. */
type Sees = (t: OrderTerms, c: ObservedCardCapture) => ObservedPayment | undefined;

/** A source that agrees with the node's acquirer on everything but, perhaps, the id: `idOf` maps the acquirer's id to its own. */
const source = (idOf: (transactionId: string) => string | undefined): Sees => (t, c) => {
  const id = idOf(c.transactionId);
  return id === undefined ? undefined : observedCard(t, c, id);
};
const acquirerApi = source((id) => id);
const gateway = source((id) => (id === TID ? NSU : undefined));

/** An attestor as the prover meets it: it signs what its source shows, refuses what it does not, or is down. */
class TestAttestor implements AttestorEndpoint {
  readonly address: Hex;
  up = true;
  asked = 0;
  private readonly account: PrivateKeyAccount;

  constructor(key: Hex, private readonly sees: Sees) {
    this.account = privateKeyToAccount(key);
    this.address = this.account.address;
  }

  async attestCard(t: OrderTerms, c: ObservedCardCapture): Promise<SignedPayment> {
    this.asked++;
    if (!this.up) throw new Error(`attestor ${this.address} did not answer`);
    const payment = this.sees(t, c);
    if (!payment) throw Object.assign(new Error('attestor refused (not_observed): the source has no charge with this id'), { code: 'not_observed' });
    const signature = await this.account.signTypedData({
      domain: EIP712_DOMAIN(CHAIN_ID, VERIFIER), types: PAYMENT_TYPES, primaryType: 'Payment', message: { orderId: t.orderId, ...payment },
    });
    return { payment, signature };
  }
}

const PROOF = [{ type: 'bytes32' }, { type: 'bytes32' }, { type: 'bytes32' }, { type: 'uint256' }, { type: 'uint64' }, { type: 'uint8' }, { type: 'bytes[]' }] as const;

/** The payment a proof carries, and who signed it, as AttestorQuorumVerifier recovers them. */
async function opened(proof: Hex, orderId: Hex = terms.orderId) {
  const [bankTxId, payeeKeyHash, payerRef, amountBrlCents, paidAt, rail, sigs] = decodeAbiParameters(PROOF, proof);
  const payment = { bankTxId, payeeKeyHash, payerRef, amountBrlCents, paidAt, rail };
  const signers = await Promise.all(sigs.map((signature) => recoverTypedDataAddress({
    domain: EIP712_DOMAIN(CHAIN_ID, VERIFIER), types: PAYMENT_TYPES, primaryType: 'Payment', message: { orderId, ...payment }, signature,
  })));
  return { payment, signers };
}

const ascending = (xs: { address: Hex }[]) => xs.map((x) => x.address).sort((a, b) => (BigInt(a) < BigInt(b) ? -1 : 1));

describe('QuorumProver: a quorum proves card captures, and nothing a bank settled', () => {
  it('refuses PIX and boleto outright, without asking an attestor: the escrows settle bank payments only on zkTLS', async () => {
    const quorum = [new TestAttestor(KEYS[0], acquirerApi), new TestAttestor(KEYS[1], acquirerApi)];
    const prover = new QuorumProver(VERIFIER, quorum, 2);
    expect(prover.rails).toEqual([Rail.CARD]);
    const pixTerms: OrderTerms = { ...terms, payeeKeyHash: pixKeyCommitment(LP_PIX_KEY, SALT), acceptedRails: [Rail.PIX] };
    const pix = prover.provePix(pixTerms, { bankTxId: 'E9999999920260914120000000000001', pixKey: LP_PIX_KEY, salt: SALT, payerRef: PAYER_REF, amountBrlCents: 10_000n, paidAt: 1_030n });
    await expect(pix).rejects.toBeInstanceOf(ProofUnavailable);
    await expect(pix).rejects.toThrow(/^an attestor quorum does not prove PIX: .*\(BankRailNeedsZkTls\) - prove it with ZkTlsProver/);
    await expect(prover.proveBoleto({ ...terms, acceptedRails: [Rail.BOLETO] }, {
      bankTxId: 'AUTH000000000001', line: 'the line paid', salt: SALT, payerRef: PAYER_REF, amountBrlCents: 10_000n, paidAt: 1_030n,
    })).rejects.toThrow(/^an attestor quorum does not prove BOLETO/);
    expect(quorum.map((a) => a.asked)).toEqual([0, 0]);
  });
});

describe('QuorumProver: which signatures make a proof', () => {
  it('proves the capture its attestors signed: a 2-of-2 reading the payment gateway, under its NSU', async () => {
    const quorum = [new TestAttestor(KEYS[0], gateway), new TestAttestor(KEYS[1], gateway)];
    const { payment, signers } = await opened(await new QuorumProver(VERIFIER, quorum, 2).proveCard(terms, seen));
    expect(payment).toEqual(observedCard(terms, seen, NSU));
    expect(payment.amountBrlCents).toBe(terms.brlCents);
    expect(signers).toEqual(ascending(quorum));
  });

  it('a mixed quorum - one acquirer TID, one gateway NSU - reaches no threshold, and says why', async () => {
    const attempt = new QuorumProver(VERIFIER, [new TestAttestor(KEYS[0], acquirerApi), new TestAttestor(KEYS[1], gateway)], 2).proveCard(terms, seen);
    await expect(attempt).rejects.toBeInstanceOf(ProofUnavailable);
    await expect(attempt).rejects.toThrow(
      /^attestors disagree on the payment id: they signed one CARD payment under 2 ids \(1 \+ 1 signatures, 2 needed\) - attestors whose sources name one payment by different ids never combine: a quorum reads one id scheme per rail$/,
    );
  });

  it('tells attestors that refused or are down apart from attestors that disagreed', async () => {
    const down = new TestAttestor(KEYS[1], acquirerApi);
    down.up = false;
    const prover = new QuorumProver(VERIFIER, [new TestAttestor(KEYS[0], acquirerApi), down, new TestAttestor(KEYS[2], source(() => undefined))], 2);
    await expect(prover.proveCard(terms, seen)).rejects.toThrow(
      /^1 of 2 attestations; refused: attestor 0x[0-9a-fA-F]{40} did not answer; attestor refused \(not_observed\): .*; an attestor that does not observe a payment others signed may read it under another id scheme/,
    );
  });

  it('never mixes payments: when two each have a quorum, it proves neither', async () => {
    const prover = new QuorumProver(VERIFIER, [acquirerApi, acquirerApi, gateway, gateway].map((s, i) => new TestAttestor(KEYS[i], s)), 2);
    await expect(prover.proveCard(terms, seen)).rejects.toThrow(/^2 different CARD payments each have 2 signatures, under different ids - .*: the node proves neither$/);
  });

  it('excludes a payment for another payee, amount, time or rail, even when enough attestors signed it', async () => {
    const cases: [Partial<ObservedPayment>, RegExp][] = [
      [{ payeeKeyHash: cardMerchantCommitment({ ...MERCHANT, merchantId: 'OUTRO-LOJISTA' }, SALT) }, /signed a payment to another payee than the order commits to/],
      [{ amountBrlCents: 9_999n }, /signed 9999 centavos, less than the order's 10000/],
      [{ paidAt: 999n }, /signed a payment made before the lock/],
      [{ rail: Rail.PIX }, /signed a PIX payment, not CARD/],
    ];
    for (const [change, why] of cases) {
      const wrong: Sees = (t, c) => ({ ...observedCard(t, c), ...change });
      const prover = new QuorumProver(VERIFIER, [new TestAttestor(KEYS[0], wrong), new TestAttestor(KEYS[1], wrong), new TestAttestor(KEYS[2], acquirerApi)], 2);
      const attempt = prover.proveCard(terms, seen);
      await expect(attempt).rejects.toThrow(/^1 of 2 attestations; excluded as not proving the order: 0x[0-9a-fA-F]{8}… signed .*; 0x[0-9a-fA-F]{8}… signed /);
      await expect(attempt).rejects.toThrow(why);
    }
  });

  it('counts an attestor once, however many times it is listed', async () => {
    const one = new TestAttestor(KEYS[0], acquirerApi);
    await expect(new QuorumProver(VERIFIER, [one, one], 2).proveCard(terms, seen)).rejects.toThrow(/^1 of 2 attestations$/);
  });

  it('once it has proven a payment for an order, it proves no other payment for that order', async () => {
    const [gw1, gw2, acq1, acq2] = [gateway, gateway, acquirerApi, acquirerApi].map((s, i) => new TestAttestor(KEYS[i], s));
    const prover = new QuorumProver(VERIFIER, [gw1, gw2, acq1, acq2], 2);
    acq1.up = acq2.up = false;
    const first = await prover.proveCard(terms, seen);

    gw1.up = gw2.up = false;
    acq1.up = acq2.up = true;
    await expect(prover.proveCard(terms, seen)).rejects.toThrow(/a different CARD payment than the one this node already proved for this order/);
    const other: Hex = `0x${'0b'.repeat(32)}`;
    expect((await opened(await prover.proveCard({ ...terms, orderId: other }, seen), other)).payment.bankTxId).toBe(cardTransactionId(seen.acquirerId, TID));

    gw1.up = gw2.up = true;
    acq1.up = acq2.up = false;
    expect(await prover.proveCard(terms, seen)).toBe(first);
  });

  it('the development quorum: local Attestor keys, taken as they are, sign the capture from what they are shown', async () => {
    const local = [new Attestor(KEYS[0], CHAIN_ID, VERIFIER), new Attestor(KEYS[1], CHAIN_ID, VERIFIER)];
    const { payment, signers } = await opened(await new QuorumProver(VERIFIER, local, 2).proveCard(terms, seen));
    expect(payment).toEqual(observedCard(terms, seen));
    expect(signers).toEqual(ascending(local));
  });
});

describe('the node, over a quorum that can sign one card capture under two ids', () => {
  it('never submits two payments for one order', async () => {
    // The node's acquirer shows the TID; a gateway source shows its NSU for the same capture.
    const statement = new Map<string, string>();
    const quorum = [source((id) => statement.get(id)), source((id) => statement.get(id)), acquirerApi, acquirerApi].map((s, i) => new TestAttestor(KEYS[i], s));
    const [gw1, gw2, acq1, acq2] = quorum;
    const h = harness({ card: true, offramp: false, confirmations: 1, tweak: (o) => { o.provers = [new QuorumProver(VERIFIER, quorum, 2)]; } });
    for (const a of quorum) h.chain.attestors.add(a.address.toLowerCase());
    const sent: Hex[] = [];
    const release = h.chain.releaseWithProof.bind(h.chain);
    h.chain.releaseWithProof = async (orderId, proof) => { sent.push(proof); return release(orderId, proof); };
    const lastWhy = () => h.logs.filter((l) => l.includes('no card proof yet')).at(-1);

    await h.tick();
    const orderId = h.chain.lockOrder(h.node.offers!.status.get(bookKey(NATIVE, true))!.activeOfferId!, 10n ** 17n);
    await h.tick();
    const charge = h.acquirer.pay(h.node.store.getOrder(orderId)!.card!.checkoutId!);
    statement.set(charge.transactionId, NSU);

    // All four answer: two payments, each with a quorum. Nothing is sent.
    await h.tick();
    expect(sent).toHaveLength(0);
    expect(lastWhy()).toMatch(/2 different CARD payments each have 2 signatures, under different ids/);

    // The acquirer pair is down: the gateway's payment is sent, and the transaction does not make it.
    acq1.up = acq2.up = false;
    h.chain.failNext = { fn: 'releaseWithProof', error: new Error('replacement transaction underpriced') };
    await h.tick();
    expect(sent).toHaveLength(1);
    expect((await h.chain.order(orderId)).state).toBe(OrderState.LOCKED);

    // Only the acquirer pair answers: a quorum on the other payment, which the node does not send.
    gw1.up = gw2.up = false;
    acq1.up = acq2.up = true;
    await h.tick();
    await h.tick();
    expect(sent).toHaveLength(1);
    expect(lastWhy()).toMatch(/already proved for this order; it does not submit a second/);

    // The gateway pair is back: the same payment again, and it releases.
    gw1.up = gw2.up = true;
    acq1.up = acq2.up = false;
    await h.tick();
    expect((await h.chain.order(orderId)).state).toBe(OrderState.RELEASED);
    expect(sent).toHaveLength(2);
    expect(sent[1]).toBe(sent[0]);
    expect(decodeAbiParameters([{ type: 'bytes32' }], sent[0])[0]).toBe(cardTransactionId(CARD_MERCHANT.acquirerId, NSU));
  });
});
