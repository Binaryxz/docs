import { describe, expect, it } from 'vitest';
import type { Hex } from 'viem';
import {
  Rail, boletoCommitment, brasiliaToday, buildCollectionBoleto, newBoletoSalt, newPixSalt, pixKeyCommitment, railMask,
} from '@mova/ramp';
import { SaleState } from '../src/abi.js';
import { NATIVE } from '../src/chain.js';
import { PayeeError } from '../src/offramp.js';
import { idempotencyKey } from '../src/store.js';
import { OFFRAMP, USDT } from './fake-chain.js';
import { WITNESS_KEYS, allowZkTls, harness, type Harness } from './harness.js';

const SELLER_KEY = 'vendedor@pix.example';

/** 0.1 ETH for R$ 19.800,00: 1% under the R$ 20.000 oracle, a buy at a 50 bps margin. */
function pixSale(h: Harness, o: { brlCents?: bigint; amount?: bigint; asset?: `0x${string}` } = {}) {
  const salt = newPixSalt();
  const saleId = h.chain.openSale({
    asset: o.asset ?? NATIVE, amount: o.amount ?? 10n ** 17n, brlCents: o.brlCents ?? 198_000n,
    payeeKeyHash: pixKeyCommitment(SELLER_KEY, salt), railMask: railMask(Rail.PIX),
  });
  return { saleId, salt };
}

async function disclose(h: Harness, saleId: Hex, salt: Hex) {
  await h.node.offramp!.submitPayee(saleId, { pixKey: SELLER_KEY, salt });
}

describe('off-ramp', () => {
  it('claims, waits for confirmations, pays the seller\'s key, proves and collects', async () => {
    const h = harness({ onramp: false, confirmations: 3 });
    const { saleId, salt } = pixSale(h);
    await h.tick();
    expect(h.node.offramp!.skipped.get(saleId.toLowerCase())).toBe('no_payee');

    await disclose(h, saleId, salt);
    await h.tick();
    expect((await h.chain.sale(saleId)).state).toBe(SaleState.CLAIMED);
    expect(h.bank.outgoing).toHaveLength(0);

    h.chain.mine(2);
    await h.tick();
    expect(h.bank.outgoing).toHaveLength(1);
    expect(h.bank.outgoing[0]).toMatchObject({ kind: 'PIX', destination: SELLER_KEY, amountCents: 198_000n });
    expect((await h.chain.sale(saleId)).state).toBe(SaleState.SETTLED);
    expect(h.node.metrics.get('mova_lp_offramp_settled_total')).toBe(1);
    expect(h.chain.exposure()).toBe(0n);
  });

  it('pays a USDT sale, valued in the token\'s own decimals', async () => {
    const h = harness({ onramp: false, confirmations: 1 });
    // 1000 USDT at R$5.44: 1.1% under the R$5.50 oracle.
    const { saleId, salt } = pixSale(h, { asset: USDT, amount: 1_000n * 10n ** 6n, brlCents: 544_000n });
    await disclose(h, saleId, salt);
    await h.tick();
    await h.tick();
    expect((await h.chain.sale(saleId)).state).toBe(SaleState.SETTLED);
  });

  it('pays a bill: a boleto sale settles for exactly its face value', async () => {
    const h = harness({ onramp: false, confirmations: 1 });
    const cents = 38_990n;
    const due = brasiliaToday(new Date(Number(h.chain.time() + 10n * 86_400n) * 1000)).replace(/-/g, '');
    const bill = buildCollectionBoleto({ segment: 3, valueIdentifier: 8, value: cents, rest: `0056${due}00000000987654321` });
    const salt = newBoletoSalt();
    const saleId = h.chain.openSale({
      amount: (cents * 10n ** 18n) / 1_970_000n, brlCents: cents, payeeKeyHash: boletoCommitment(bill, salt), railMask: railMask(Rail.BOLETO),
    });
    await expect(h.node.offramp!.submitPayee(saleId, { pixKey: SELLER_KEY, salt })).rejects.toMatchObject({ status: 422 });
    await h.node.offramp!.submitPayee(saleId, { boletoLine: bill.line, salt });
    await h.tick();
    await h.tick();
    expect(h.bank.outgoing[0]).toMatchObject({ kind: 'BOLETO', destination: bill.barcode, amountCents: cents });
    expect((await h.chain.sale(saleId)).state).toBe(SaleState.SETTLED);
  });

  it('refuses a payee disclosure that does not open the commitment, without repeating it', async () => {
    const h = harness({ onramp: false });
    const { saleId } = pixSale(h);
    const err = await h.node.offramp!.submitPayee(saleId, { pixKey: SELLER_KEY, salt: newPixSalt() }).catch((e: unknown) => e);
    expect(err).toBeInstanceOf(PayeeError);
    expect((err as PayeeError).status).toBe(422);
    expect((err as Error).message).not.toContain(SELLER_KEY);
    await h.tick();
    expect(h.chain.writes).not.toContain('claimSale');
  });

  it.each([
    ['price_too_high', { brlCents: 199_500n }],
  ] as const)('does not claim a sale that is not a buy (%s)', async (reason, o) => {
    const h = harness({ onramp: false });
    const { saleId, salt } = pixSale(h, o);
    await disclose(h, saleId, salt);
    await h.tick();
    expect(h.node.offramp!.skipped.get(saleId.toLowerCase())).toBe(reason);
    expect(h.chain.writes).not.toContain('claimSale');
  });

  it('does not claim beyond its credit, its open-claim cap, or for a verifier it cannot prove to', async () => {
    const h = harness({ onramp: false, tweak: (o) => { o.offramp!.maxOpenClaims = 1; } });
    const one = pixSale(h);
    const two = pixSale(h);
    // Another zkTLS verifier, with witnesses and endpoints of its own: the escrow opens the sale, and this node has no prover for it.
    allowZkTls(h.chain, '0x00000000000000000000000000000000000bad00', WITNESS_KEYS, 1);
    const alien = h.chain.openSale({
      amount: 10n ** 17n, brlCents: 198_000n, payeeKeyHash: pixKeyCommitment(SELLER_KEY, one.salt), railMask: railMask(Rail.PIX),
      verifier: '0x00000000000000000000000000000000000bad00',
    });
    for (const s of [one, two]) await disclose(h, s.saleId, s.salt);
    await h.node.offramp!.submitPayee(alien, { pixKey: SELLER_KEY, salt: one.salt });
    await h.tick();
    expect(h.chain.writes.filter((w) => w === 'claimSale')).toHaveLength(1);
    expect(h.node.offramp!.skipped.get(two.saleId.toLowerCase())).toBe('too_many_claims');
    expect(h.node.offramp!.skipped.get(alien.toLowerCase())).toBe('verifier_unsupported');

    const h2 = harness({ onramp: false });
    h2.chain.setCap(100_000n);
    const poor = pixSale(h2);
    await disclose(h2, poor.saleId, poor.salt);
    await h2.tick();
    expect(h2.node.offramp!.skipped.get(poor.saleId.toLowerCase())).toBe('insufficient_credit');
  });

  it('gives the claim back, free, when the price moves against it before the BRL goes out', async () => {
    const h = harness({ onramp: false, confirmations: 3 });
    const { saleId, salt } = pixSale(h);
    await disclose(h, saleId, salt);
    await h.tick();
    h.chain.setOracle(NATIVE, 1_950_000n); // the sale is now above market
    h.chain.mine(2);
    await h.tick();
    expect(h.bank.outgoing).toHaveLength(0);
    expect(h.chain.writes).toContain('abandonClaim');
    expect((await h.chain.sale(saleId)).state).toBe(SaleState.OPEN);
  });

  it('raises a dispute while it still holds the claim when it paid and cannot prove it in time', async () => {
    const h = harness({ onramp: false, confirmations: 1 });
    const { saleId, salt } = pixSale(h);
    await disclose(h, saleId, salt);
    await h.tick(); // claim
    const saved = h.witnesses.splice(0, 2); // the zkTLS witnesses go dark after the claim
    await h.tick(); // pays; proof fails; not near the deadline yet
    expect(h.bank.outgoing).toHaveLength(1);
    expect((await h.chain.sale(saleId)).state).toBe(SaleState.CLAIMED);
    expect(h.chain.writes).not.toContain('raiseDispute');

    h.chain.warp(40n * 60n); // inside the dispute margin of payBy
    h.chain.mine();
    await h.tick();
    expect((await h.chain.sale(saleId)).state).toBe(SaleState.DISPUTED);
    expect(h.node.metrics.get('mova_lp_disputes_raised_total', { leg: 'offramp' })).toBe(1);
    h.witnesses.push(...saved);
    await h.tick();
    expect(h.bank.outgoing).toHaveLength(1);
  });

  it('abandons and holds a sale whose payment the bank refused, and never re-pays it under a new key', async () => {
    const h = harness({ onramp: false, confirmations: 1 });
    const { saleId, salt } = pixSale(h);
    await disclose(h, saleId, salt);
    await h.tick();
    h.bank.failNextSend();
    await h.tick();
    expect(h.chain.writes).toContain('abandonClaim');
    expect(h.node.store.getSale(saleId)?.hold).toMatch(/failed/);
    for (let i = 0; i < 3; i++) await h.tick();
    expect(h.bank.outgoing).toHaveLength(1);
    expect(h.bank.outgoing[0].idempotencyKey).toBe(idempotencyKey('sale-pay', h.chain.chainId, OFFRAMP, saleId));
    expect(h.chain.writes.filter((w) => w === 'claimSale')).toHaveLength(1);
  });
});
