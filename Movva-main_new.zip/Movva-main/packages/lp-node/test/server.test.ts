import { afterEach, describe, expect, it } from 'vitest';
import type { Hex } from 'viem';
import { generatePrivateKey, privateKeyToAccount } from 'viem/accounts';
import { Rail, newPixSalt, pixKeyCommitment, railMask } from '@mova/ramp';
import { parsePixBrCode } from '@mova/wallet';
import { NATIVE } from '../src/chain.js';
import { serveLpNode, signInstructionsRequest, type ServeOptions } from '../src/server.js';
import { ONRAMP } from './fake-chain.js';
import { harness, type Harness } from './harness.js';

let closers: (() => Promise<void>)[] = [];
afterEach(async () => {
  for (const c of closers) await c();
  closers = [];
});

async function up(h: Harness, mode: 'ops' | 'api' | 'both', now?: () => number): Promise<string> {
  const s = serveLpNode(h.node, { mode, now });
  closers.push(s.close);
  return `http://127.0.0.1:${await s.listen(0)}`;
}

const post = (url: string, body: unknown) =>
  fetch(url, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });

describe('operations endpoints', () => {
  it('is alive before its first tick, and ready only after', async () => {
    const h = harness();
    const base = await up(h, 'ops');
    expect((await fetch(`${base}/healthz`)).status).toBe(200);
    expect((await fetch(`${base}/readyz`)).status).toBe(503);
    expect((await fetch(`${base}/status`)).status).toBe(503);
    await h.tick();
    expect((await fetch(`${base}/readyz`)).status).toBe(200);
    const status = await (await fetch(`${base}/status`)).json() as { ready: boolean; onramp: { assets: { symbol: string; quoting: boolean }[] } };
    expect(status.ready).toBe(true);
    expect(status.onramp.assets.map((a) => [a.symbol, a.quoting])).toEqual([['ETH', true], ['USDT', true]]);
  });

  it('exposes Prometheus metrics under mova_lp_, every series declared up front', async () => {
    const h = harness();
    await h.tick();
    const text = await (await fetch(`${await up(h, 'ops')}/metrics`)).text();
    const samples = text.split('\n').filter((l) => l && !l.startsWith('#'));
    expect(samples.length).toBeGreaterThan(20);
    for (const l of samples) expect(l).toMatch(/^mova_lp_[a-z_]+(\{[^}]*\})? -?[\d.e+]+$/);
    expect(text).toMatch(/mova_lp_quoting\{asset="0x0000000000000000000000000000000000000000",symbol="ETH"\} 1/);
    expect(text).toMatch(/# TYPE mova_lp_offramp_brl_paid_cents_total counter/);
  });

  it('keeps counterparty routes off the operations listener, and operations off the API listener', async () => {
    const h = harness();
    const ops = await up(h, 'ops');
    const api = await up(h, 'api');
    expect((await post(`${ops}/v1/offramp/payee`, {})).status).toBe(404);
    expect((await fetch(`${api}/status`)).status).toBe(404);
    expect((await fetch(`${api}/metrics`)).status).toBe(404);
  });
});

describe('payment instructions', () => {
  async function lockedOrder(h: Harness, taker: `0x${string}`): Promise<Hex> {
    await h.tick();
    return h.chain.lockOrder(h.node.offers!.status.get(NATIVE)!.activeOfferId!, 10n ** 17n, { taker });
  }

  it('serves the order\'s taker, and only them, with a fresh signature', async () => {
    const h = harness({ offramp: false });
    const taker = privateKeyToAccount(generatePrivateKey());
    const stranger = privateKeyToAccount(generatePrivateKey());
    const orderId = await lockedOrder(h, taker.address);
    const now = Math.floor(Date.now() / 1000);
    const base = await up(h, 'api', () => now);
    const url = `${base}/v1/onramp/instructions`;

    const good = await signInstructionsRequest(taker, { chainId: h.chain.chainId, escrow: ONRAMP, orderId, issuedAt: now });
    const res = await post(url, good);
    expect(res.status).toBe(200);
    const body = await res.json() as { rail: string; pixCopiaECola: string; amountCents: string; salt: Hex; pixKey: string };
    expect(body.rail).toBe('PIX');
    expect(parsePixBrCode(body.pixCopiaECola).amountCents).toBe(BigInt(body.amountCents));

    const byStranger = await signInstructionsRequest(stranger, { chainId: h.chain.chainId, escrow: ONRAMP, orderId, issuedAt: now });
    const refused = await post(url, byStranger);
    expect(refused.status).toBe(401);
    const text = await refused.text();
    expect(text).not.toContain(body.salt.slice(2));
    expect(text).not.toContain(body.pixKey);

    const stale = await signInstructionsRequest(taker, { chainId: h.chain.chainId, escrow: ONRAMP, orderId, issuedAt: now - 600 });
    expect((await post(url, stale)).status).toBe(401);
    // A signature for another escrow (domain) does not transfer.
    const elsewhere = await signInstructionsRequest(taker, { chainId: h.chain.chainId, escrow: '0x00000000000000000000000000000000000e5c99', orderId, issuedAt: now });
    expect((await post(url, elsewhere)).status).toBe(401);
    expect((await post(url, { orderId: 'nope' })).status).toBe(400);
  });

  /// The instructions are the payload: an API Pix charge's path IS the charge. Redacting them at the
  /// boundary would serve `https://<psp>/[redacted]`, which no payer could use.
  it('serves the charge URL whole, and refuses rather than scrubs a response carrying a configured secret', async () => {
    const h = harness({ offramp: false });
    const taker = privateKeyToAccount(generatePrivateKey());
    const orderId = await lockedOrder(h, taker.address);
    const now = Math.floor(Date.now() / 1000);
    const rpcUrl = 'https://eth-mainnet.g.alchemy.com/v2/sEcReTkEy0123456789';
    const location = 'https://qrcodes.psp.example/cob/ck_7f3a9c2e1b/confirm?session=abc123def456';
    let body: Record<string, unknown> = { rail: 'PIX', charge: 'cob', location };
    h.node.onramp!.instructions = async () => ({ taker: taker.address, body }) as never;
    const s = serveLpNode(h.node, { mode: 'api', now: () => now, redactValues: [rpcUrl] });
    closers.push(s.close);
    const url = `http://127.0.0.1:${await s.listen(0)}/v1/onramp/instructions`;
    const req = await signInstructionsRequest(taker, { chainId: h.chain.chainId, escrow: ONRAMP, orderId, issuedAt: now });

    const res = await post(url, req);
    expect(res.status).toBe(200);
    expect(((await res.json()) as { location: string }).location).toBe(location);

    // A body that would leak the RPC URL, or just its key, is not served at all - and the refusal does not echo it.
    for (const leak of [rpcUrl, 'sEcReTkEy0123456789']) {
      body = { rail: 'PIX', charge: 'cob', location, note: `via ${leak}` };
      const refused = await post(url, req);
      expect(refused.status).toBe(500);
      expect(await refused.text()).not.toContain('sEcReTkEy0123456789');
    }
  });
});

describe('payee intake', () => {
  it('accepts an opening of the sale\'s commitment and refuses anything else without echoing it', async () => {
    const h = harness({ onramp: false });
    const key = '529.982.247-25';
    const salt = newPixSalt();
    const saleId = h.chain.openSale({ amount: 10n ** 17n, brlCents: 198_000n, payeeKeyHash: pixKeyCommitment(key, salt), railMask: railMask(Rail.PIX) });
    const base = await up(h, 'api');
    const url = `${base}/v1/offramp/payee`;

    const wrong = await post(url, { saleId, pixKey: '11144477735', salt });
    expect(wrong.status).toBe(422);
    expect(await wrong.text()).not.toContain('11144477735');
    expect((await post(url, { saleId, pixKey: key, boletoLine: '1', salt })).status).toBe(400);
    expect((await post(url, { saleId: `0x${'00'.repeat(32)}`, pixKey: key, salt })).status).toBe(404);

    const ok = await post(url, { saleId, pixKey: key, salt });
    expect(ok.status).toBe(201);
    expect(h.node.store.getSale(saleId)?.payee).toEqual({ kind: 'pix', pixKey: '52998224725', salt });
    const big = await post(url, { saleId, pixKey: 'x'.repeat(20_000), salt });
    expect(big.status).toBe(413);
  });
});

/// A browser wallet on another origin can use the counterparty routes only if the LP lists that origin (cors.ts).
describe('CORS for browser wallets', () => {
  const WALLET = 'https://wallet.example';
  const ZERO32 = `0x${'00'.repeat(32)}` as Hex;
  const BROWSER_ROUTES = [['/v1/onramp/instructions', 'POST'], ['/v1/offramp/payee', 'POST']] as const;

  async function serve(h: Harness, o: ServeOptions): Promise<string> {
    const s = serveLpNode(h.node, o);
    closers.push(s.close);
    return `http://127.0.0.1:${await s.listen(0)}`;
  }

  /** A request as a page on `origin` makes it, the body read so the connection can close. */
  const call = async (url: string, origin: string | undefined, init: { method?: string; body?: unknown; headers?: Record<string, string> } = {}) => {
    const r = await fetch(url, {
      method: init.method ?? (init.body === undefined ? 'GET' : 'POST'),
      headers: { ...(origin ? { origin } : {}), ...(init.body === undefined ? {} : { 'content-type': 'application/json' }), ...init.headers },
      body: init.body === undefined ? undefined : JSON.stringify(init.body),
    });
    return { status: r.status, headers: r.headers, text: await r.text(), acao: r.headers.get('access-control-allow-origin'), vary: r.headers.get('vary') };
  };
  const preflight = (url: string, origin: string | undefined, method: string) =>
    call(url, origin, { method: 'OPTIONS', headers: { 'access-control-request-method': method, 'access-control-request-headers': 'content-type' } });

  /** A node with a sale open for a payee. */
  function wallet() {
    const h = harness();
    const key = '529.982.247-25';
    const salt = newPixSalt();
    const saleId = h.chain.openSale({ amount: 10n ** 17n, brlCents: 198_000n, payeeKeyHash: pixKeyCommitment(key, salt), railMask: railMask(Rail.PIX) });
    return { h, key, salt, saleId };
  }

  it('sends no CORS headers and refuses every preflight by default', async () => {
    const { h } = wallet();
    const base = await serve(h, { mode: 'api' });
    const refused = await call(`${base}/v1/onramp/instructions`, WALLET, { body: { orderId: 'nope' } });
    expect([refused.status, refused.acao, refused.vary]).toEqual([400, null, null]);
    for (const [path, method] of BROWSER_ROUTES) {
      const p = await preflight(`${base}${path}`, WALLET, method);
      expect([p.status, p.acao], path).toEqual([403, null]);
    }
  });

  it('lets a listed origin read the counterparty routes\' answers, refusals included', async () => {
    const { h, key, salt, saleId } = wallet();
    const now = Math.floor(Date.now() / 1000);
    const base = await serve(h, { mode: 'api', now: () => now, cors: { allowedOrigins: [WALLET] } });
    const seen: [string, number, string | null, string | null][] = [];
    const record = (label: string, r: Awaited<ReturnType<typeof call>>) => seen.push([label, r.status, r.acao, r.vary]);

    record('instructions, malformed', await call(`${base}/v1/onramp/instructions`, WALLET, { body: { orderId: 'nope' } }));
    record('instructions, expired', await call(`${base}/v1/onramp/instructions`, WALLET, { body: { orderId: ZERO32, signature: '0x00', issuedAt: now - 600 } }));
    h.node.onramp!.instructions = async () => { throw new Error('boom'); };
    record('instructions, internal error', await call(`${base}/v1/onramp/instructions`, WALLET, { body: { orderId: ZERO32, signature: '0x00', issuedAt: now } }));
    record('payee, unknown sale', await call(`${base}/v1/offramp/payee`, WALLET, { body: { saleId: ZERO32, pixKey: key, salt } }));
    record('payee', await call(`${base}/v1/offramp/payee`, WALLET, { body: { saleId, pixKey: key, salt } }));
    record('payee, too large', await call(`${base}/v1/offramp/payee`, WALLET, { body: { saleId, pixKey: 'x'.repeat(20_000), salt } }));
    expect(seen).toEqual([
      ['instructions, malformed', 400, WALLET, 'Origin'],
      ['instructions, expired', 401, WALLET, 'Origin'],
      ['instructions, internal error', 500, WALLET, 'Origin'],
      ['payee, unknown sale', 404, WALLET, 'Origin'],
      ['payee', 201, WALLET, 'Origin'],
      ['payee, too large', 413, WALLET, 'Origin'],
    ]);
  });

  it('answers a listed origin\'s preflight with the route\'s method, content-type and the max age', async () => {
    const base = await serve(harness(), { mode: 'api', cors: { allowedOrigins: [WALLET], maxAgeSeconds: 120 } });
    for (const [path, method] of BROWSER_ROUTES) {
      const p = await preflight(`${base}${path}`, WALLET, method);
      expect(p.status, path).toBe(204);
      expect(p.acao, path).toBe(WALLET);
      expect(p.headers.get('access-control-allow-methods'), path).toBe(method);
      expect(p.headers.get('access-control-allow-headers'), path).toBe('content-type');
      expect(p.headers.get('access-control-max-age'), path).toBe('120');
      expect(p.vary, path).toBe('Origin');
      expect(p.headers.get('access-control-allow-credentials'), path).toBeNull();
      expect(p.text, path).toBe('');
    }
  });

  it('gives an unlisted origin, or none, nothing to read', async () => {
    const { h } = wallet();
    const base = await serve(h, { mode: 'api', cors: { allowedOrigins: [WALLET] } });
    for (const origin of ['https://evil.example', 'http://wallet.example', 'https://wallet.example:8443', undefined]) {
      // Still answered: CORS decides what a page may read, it is not access control.
      const refused = await call(`${base}/v1/onramp/instructions`, origin, { body: { orderId: 'nope' } });
      expect([refused.status, refused.acao, refused.vary], origin).toEqual([400, null, 'Origin']);
      const payee = await call(`${base}/v1/offramp/payee`, origin, { body: {} });
      expect([payee.status, payee.acao], origin).toEqual([400, null]);
      for (const [path, method] of BROWSER_ROUTES) {
        const p = await preflight(`${base}${path}`, origin, method);
        expect([p.status, p.acao], `${origin} ${path}`).toEqual([403, null]);
      }
    }
  });

  it('never opens the operations routes or the PSP webhook to a browser, even for a listed origin', async () => {
    const h = harness();
    await h.tick();
    const cors = { allowedOrigins: [WALLET] };
    const both = await serve(h, { mode: 'both', cors, webhook: { auth: 'hmac', secret: 'webhook-secret-0123456789abcdef-0123456789' } });
    for (const path of ['/healthz', '/readyz', '/status', '/metrics']) {
      const r = await call(`${both}${path}`, WALLET);
      expect([r.status, r.acao, r.vary], path).toEqual([200, null, null]);
      const p = await preflight(`${both}${path}`, WALLET, 'GET');
      expect([p.status, p.acao], path).toEqual([404, null]);
    }
    const hook = await call(`${both}/v1/webhook/pix`, WALLET, { body: {} });
    expect([hook.status, hook.acao, hook.vary]).toEqual([401, null, null]);
    const hookPreflight = await preflight(`${both}/v1/webhook/pix`, WALLET, 'POST');
    expect([hookPreflight.status, hookPreflight.acao]).toEqual([404, null]);

    // The operations listener serves no counterparty route, so it answers no preflight for one either.
    const ops = await serve(h, { mode: 'ops', cors });
    const p = await preflight(`${ops}/v1/onramp/instructions`, WALLET, 'POST');
    expect([p.status, p.acao]).toEqual([404, null]);
    const r = await call(`${ops}/v1/offramp/payee`, WALLET, { body: {} });
    expect([r.status, r.acao]).toEqual([404, null]);
  });

  it('refuses a wildcard origin at startup', () => {
    for (const bad of ['*', 'null', 'https://wallet.example/app', 'ftp://wallet.example']) {
      expect(() => serveLpNode(harness().node, { mode: 'api', cors: { allowedOrigins: [bad] } }), bad).toThrow(/CORS allowed origin 1/);
    }
  });
});
