import { describe, expect, it } from 'vitest';
import { ChainRevert } from '../src/chain.js';
import { serveLpNode } from '../src/server.js';
import { REWARDS } from './fake-chain.js';
import { E18, harness, type Harness } from './harness.js';

/** An epoch as NodeRewards leaves it once finalized: this LP's volume, the epoch's, its budget and per-LP cap. */
function epoch(h: Harness, e: bigint, lpVolume: bigint, volume: bigint, budget: bigint, lpCap = 10_000n * E18): void {
  h.chain.rewards.epochs.set(e, { lpVolume, volume, budget, lpCap });
}

const writes = (h: Harness, fn: string) => h.chain.writes.filter((w) => w === fn).length;

describe('node-provider rewards', () => {
  it('claims every finalized epoch with a share in one transaction, once, capped as the contract caps it', async () => {
    const h = harness({ rewards: true, offramp: false });
    epoch(h, 0n, 3_000_000n, 4_000_000n, 40n * E18); // a 30 share
    epoch(h, 1n, 1_000_000n, 1_000_000n, 10n * E18, 5n * E18); // a 10 share, capped at 5
    epoch(h, 2n, 2_000_000n, 2_000_000n, 20n * E18); // not finalized yet
    Object.assign(h.chain.rewards, { nextToFinalize: 2n, currentEpoch: 2n });

    await h.tick();
    expect(writes(h, 'claimRewards')).toBe(1);
    expect(h.chain.rewards.claimed).toEqual(new Set([0n, 1n]));
    expect(h.chain.rewards.paid).toBe(35n * E18);
    expect(h.node.metrics.get('mova_lp_rewards_claimed_cents_total')).toBe(3_500);
    expect(h.node.metrics.get('mova_lp_rewards_claims_total', { outcome: 'mined' })).toBe(1);
    expect(h.node.metrics.get('mova_lp_rewards_claimable')).toBe(0);
    expect(h.node.metrics.get('mova_lp_rewards_epoch_volume_cents')).toBe(2_000_000);
    expect(h.node.metrics.get('mova_lp_rewards_counting')).toBe(1);

    for (let i = 0; i < 3; i++) await h.tick();
    expect(writes(h, 'claimRewards')).toBe(1); // nothing is claimed twice
  });

  it('finalizes epochs whose review has ended before claiming them', async () => {
    const h = harness({ rewards: true, offramp: false });
    epoch(h, 0n, 1_000_000n, 1_000_000n, 10n * E18);
    Object.assign(h.chain.rewards, { nextToFinalize: 0n, finalizable: 1n, currentEpoch: 1n });
    await h.tick();
    const order = h.chain.writes.filter((w) => w === 'finalizeRewards' || w === 'claimRewards');
    expect(order).toEqual(['finalizeRewards', 'claimRewards']);
    expect(h.chain.rewards.nextToFinalize).toBe(1n);
    expect(h.chain.rewards.paid).toBe(10n * E18);
    expect(h.node.metrics.get('mova_lp_rewards_finalized_total')).toBe(1);
  });

  it('waits for minClaim, and with claim off only reports', async () => {
    const h = harness({ rewards: true, offramp: false, tweak: (o) => { o.rewards!.minClaim = 50n * E18; } });
    epoch(h, 0n, 3_000_000n, 4_000_000n, 40n * E18);
    Object.assign(h.chain.rewards, { nextToFinalize: 1n, currentEpoch: 2n, finalizable: 1n });
    await h.tick();
    expect(writes(h, 'claimRewards')).toBe(0);
    expect(h.node.metrics.get('mova_lp_rewards_claimable')).toBe(3_000);
    expect(writes(h, 'finalizeRewards')).toBe(1); // finalizing does not wait for minClaim

    const off = harness({ rewards: true, offramp: false, tweak: (o) => { o.rewards!.claim = false; } });
    epoch(off, 0n, 3_000_000n, 4_000_000n, 40n * E18);
    Object.assign(off.chain.rewards, { nextToFinalize: 1n, currentEpoch: 2n, finalizable: 1n });
    await off.tick();
    expect(writes(off, 'claimRewards') + writes(off, 'finalizeRewards')).toBe(0);
    expect(off.node.metrics.get('mova_lp_rewards_claimable')).toBe(3_000);
    expect(off.node.metrics.get('mova_lp_rewards_finalizable_epochs')).toBe(1);
  });

  it('counts a refused claim and a failed read, and the tick goes on', async () => {
    const h = harness({ rewards: true, offramp: false });
    epoch(h, 0n, 1_000_000n, 1_000_000n, 10n * E18);
    Object.assign(h.chain.rewards, { nextToFinalize: 1n, currentEpoch: 1n });
    h.chain.failNext = { fn: 'claimRewards', error: new ChainRevert('AlreadyClaimed') };
    await h.tick();
    expect(h.node.metrics.get('mova_lp_rewards_claims_total', { outcome: 'refused' })).toBe(1);
    expect(h.node.ready).toBe(true);

    h.chain.failNext = { fn: 'rewardsView', error: new Error('fetch failed') };
    await h.tick();
    expect(h.node.metrics.get('mova_lp_tick_errors_total', { stage: 'rewards_read' })).toBe(1);
    expect((h.node.status().rewards as { error: string }).error).toMatch(/fetch failed/);
    await h.tick();
    expect(h.chain.rewards.paid).toBe(10n * E18); // claimed on the next good tick
  });

  it('says why its settlements do not count: no registry bound, another registry, or excluded', async () => {
    const h = harness({ rewards: true, offramp: false });
    h.chain.rewards.registry = '0x0000000000000000000000000000000000000000';
    await h.tick();
    expect(h.node.metrics.get('mova_lp_rewards_counting')).toBe(0);
    expect(h.node.status().rewards).toMatchObject({ counting: false, notCounting: ['unbound'] });
    expect(h.logs.some((l) => /do not count for rewards \(unbound\)/.test(l))).toBe(true);

    h.chain.rewards.registry = REWARDS; // any other address
    h.chain.rewards.excluded = true;
    await h.tick();
    expect(h.node.status().rewards).toMatchObject({ counting: false, notCounting: ['bound_elsewhere', 'excluded'] });
  });

  it('shows rewards on /status and /metrics, as amounts and ids only', async () => {
    const h = harness({ rewards: true, offramp: false, tweak: (o) => { o.rewards!.claim = false; } });
    epoch(h, 3n, 3_000_000n, 4_000_000n, 40n * E18);
    Object.assign(h.chain.rewards, { nextToFinalize: 4n, currentEpoch: 5n });
    await h.tick();
    const srv = serveLpNode(h.node, { mode: 'ops' });
    const port = await srv.listen(0);
    try {
      const status = await (await fetch(`http://127.0.0.1:${port}/status`)).json() as { rewards: Record<string, unknown> };
      expect(status.rewards).toMatchObject({
        contract: REWARDS, claim: false, counting: true, claimable: '30000000000000000000', claimableCents: '3000',
        unclaimedEpochs: ['3'], nextToFinalize: '4', currentEpoch: '5', lastClaim: null, error: null,
      });
      const metrics = await (await fetch(`http://127.0.0.1:${port}/metrics`)).text();
      expect(metrics).toMatch(/^mova_lp_rewards_claimable 3000$/m);
      expect(metrics).toMatch(/^mova_lp_rewards_unclaimed_epochs 1$/m);
    } finally {
      await srv.close();
    }
  });
});
