import { describe, expect, it } from 'vitest';
import type { Hex } from 'viem';
import { Rail, cardCheckoutTotal, cardFee, cardMerchantCommitment } from '@mova/ramp';
import { OrderState } from '../src/abi.js';
import { maxOrderCentsForCharge } from '../src/card-onramp.js';
import { NATIVE } from '../src/chain.js';
import { QuorumProver } from '../src/attestation.js';
import type { LpNodeOptions } from '../src/node.js';
import { bookKey } from '../src/offers.js';
import { pixTxidForOrder } from '../src/onramp.js';
import { quoteOffer } from '../src/pricing.js';
import { serveLpNode } from '../src/server.js';
import { idempotencyKey } from '../src/store.js';
import { MOVVA, ONRAMP } from './fake-chain.js';
import { CARD_FEE_BPS, CARD_MERCHANT, E18, LP_PIX_KEY, VERIFIER, harness, type Harness } from './harness.js';

/**
 * The card on-ramp, node side (card.ts, card-onramp.ts). The contracts and the attestor refuse what they
 * can see (contracts/test/CardRail.t.sol, packages/ramp/test/card.test.ts); these attack what only the
 * node decides: which charge proves which order, what a checkout charges, and which card money goes back, once.
 */

const CARD = bookKey(NATIVE, true);
const cardOffer = (h: Harness) => h.node.offers!.status.get(CARD);

/** A confirmed card order with its checkout ready. `total` is the order plus the harness's 2,5% card fee. */
async function cardOrder(h: Harness, amount = 10n ** 17n): Promise<{ orderId: Hex; brlCents: bigint; total: bigint; checkoutId: string }> {
  if (!cardOffer(h)?.activeOfferId) await h.tick();
  const offerId = cardOffer(h)!.activeOfferId!;
  const orderId = h.chain.lockOrder(offerId, amount);
  h.chain.mine(3);
  await h.tick();
  const card = h.node.store.getOrder(orderId)?.card;
  if (!card?.checkoutId) throw new Error('no checkout');
  const brlCents = (await h.chain.order(orderId)).brlCents;
  return { orderId, brlCents, total: cardCheckoutTotal(brlCents, CARD_FEE_BPS), checkoutId: card.checkoutId };
}

/** Let the order expire, be reclaimed, and its cancellation become N deep. */
async function expire(h: Harness): Promise<void> {
  h.chain.warp(31n * 60n);
  h.chain.mine();
  await h.tick(); // reclaims
  h.chain.mine(3);
  await h.tick(); // cancellation confirmed: checkouts cancelled, charges returned
}

describe('card offers', () => {
  it('posts a card-only offer beside the bank offer, committed to the merchant account and its fee, at the bank offer\'s price', async () => {
    const h = harness({ card: true, offramp: false });
    await h.tick();
    const bank = h.node.offers!.status.get(NATIVE)!;
    const card = cardOffer(h)!;
    expect(bank).toMatchObject({ quoting: true, price: 2_020_000n });
    expect(card).toMatchObject({ quoting: true, card: true });
    const offer = await h.chain.offer(card.activeOfferId!);
    expect(offer.railMask).toBe(1 << Rail.CARD);
    expect(offer.pixKeyHash).toBe(cardMerchantCommitment({ ...CARD_MERCHANT, feeBps: CARD_FEE_BPS }, h.node.store.saltFor(offer.pixKeyHash)!));
    expect(h.node.store.cardFeeFor(offer.pixKeyHash)).toBe(CARD_FEE_BPS);
    // Not grossed up by the fee: the cardholder pays it on top, at checkout. It was ceil(2.000.000 x 1,01 / 0,975) = 2.071.795.
    expect(offer.priceBrlCentsPerEth).toBe(bank.price);
    for (let i = 0; i < 3; i++) await h.tick();
    expect(h.chain.writes.filter((w) => w === 'postOffer')).toHaveLength(3); // ETH, USDT, ETH card: the books never close each other
    expect(h.chain.writes).not.toContain('closeOffer');
  });

  it('on Movva\'s 300 bps pair, a Movva card offer with a 3,5% fee is posted inside the band at the PIX price, and an order on it releases', async () => {
    const h = harness({
      gateway: true, card: true, offramp: false, confirmations: 1,
      tweak: (o) => {
        o.onramp!.card!.feeBps = 350;
        const [movva] = o.onramp!.assets;
        o.onramp!.assets = [movva, { ...movva, liquidity: 1_000n * E18, maxOrder: 500n * E18, rails: [Rail.CARD], verifier: VERIFIER }];
      },
    });
    h.chain.band_ = 300n;
    // The gateway mints for one book at a time: the card book posts once the PIX book's mint has mined.
    for (let i = 0; i < 4 && !h.node.offers!.status.get(bookKey(MOVVA, true))?.quoting; i++) {
      await h.tick();
      h.chain.mine(1);
    }
    const pix = h.node.offers!.status.get(MOVVA.toLowerCase())!;
    const card = h.node.offers!.status.get(bookKey(MOVVA, true))!;
    expect(pix).toMatchObject({ quoting: true, price: 101n });
    expect(card).toMatchObject({ quoting: true, price: 101n, oraclePrice: 100n });
    // Within 300 bps less the 100 bps margin. Grossed up, the floor alone was ceil(100 x 1,005 / 0,965) = 105: above the band.
    expect(card.price! * 10_000n <= 100n * (10_000n + 300n - 100n)).toBe(true);
    const grossedUp = (100n * 10_050n + 9_650n - 1n) / 9_650n;
    expect(grossedUp > 102n).toBe(true);

    const orderId = h.chain.lockOrder(card.activeOfferId!, 100n * E18);
    h.chain.mine(1);
    await h.tick();
    const brlCents = (await h.chain.order(orderId)).brlCents;
    expect([brlCents, cardFee(brlCents, 350)]).toEqual([10_100n, 354n]); // ceil(353,5)
    const [checkout] = h.acquirer.checkouts.values();
    expect(checkout.amountCents).toBe(10_454n);
    h.acquirer.pay(checkout.checkoutId);
    await h.tick();
    expect((await h.chain.order(orderId)).state).toBe(OrderState.RELEASED);
  });

  it('a changed card fee closes the live card offer and posts one committed to the new fee; an order on the old one is charged at its own', async () => {
    let opts!: LpNodeOptions;
    const h = harness({ card: true, offramp: false, confirmations: 1, tweak: (o) => { opts = o; } });
    await h.tick();
    const old = cardOffer(h)!.activeOfferId!;
    const orderId = h.chain.lockOrder(old, 10n ** 17n);
    opts.onramp!.card!.feeBps = 350;
    h.chain.mine(1);
    await h.tick();
    expect((await h.chain.offer(old)).active).toBe(false);
    const fresh = await h.chain.offer(cardOffer(h)!.activeOfferId!);
    expect(h.node.store.cardFeeFor(fresh.pixKeyHash)).toBe(350);
    const brlCents = (await h.chain.order(orderId)).brlCents;
    // The old offer's commitment carries 2,5%: its order is charged, served and proven at 2,5%, or nothing would open it.
    expect([...h.acquirer.checkouts.values()][0].amountCents).toBe(cardCheckoutTotal(brlCents, CARD_FEE_BPS));
    const { body } = await h.node.onramp!.instructions(orderId);
    expect(body).toMatchObject({ rail: 'CARD', feeBps: CARD_FEE_BPS });
    h.acquirer.pay([...h.acquirer.checkouts.values()][0].checkoutId);
    await h.tick();
    expect((await h.chain.order(orderId)).state).toBe(OrderState.RELEASED);
  });

  it('an offer whose fee is not in the journal (posted before fees were committed) gets no checkout, and is replaced', async () => {
    const h = harness({ card: true, offramp: false, confirmations: 1 });
    await h.tick();
    const old = cardOffer(h)!.activeOfferId!;
    const orderId = h.chain.lockOrder(old, 10n ** 17n);
    delete h.node.store.offerSalts.get((await h.chain.offer(old)).pixKeyHash.toLowerCase())!.cardFeeBps;
    h.chain.mine(1);
    await h.tick();
    expect(h.acquirer.checkouts.size).toBe(0);
    expect(h.node.store.getOrder(orderId)?.hold).toMatch(/fee is not in the journal/);
    expect((await h.chain.offer(old)).active).toBe(false);
    expect(cardOffer(h)).toMatchObject({ quoting: true });
    expect(cardOffer(h)!.activeOfferId).not.toBe(old);
  });

  it('caps a card order so that its charge, fee included, fits the acquirer\'s per-charge limit', async () => {
    const h = harness({ card: true, offramp: false, tweak: (o) => { o.onramp!.card!.maxChargeBrlCents = 102_500n; } });
    await h.tick();
    const offer = await h.chain.offer(cardOffer(h)!.activeOfferId!);
    const cents = (wei: bigint) => (wei * offer.priceBrlCentsPerEth + E18 - 1n) / E18;
    expect(cardCheckoutTotal(cents(offer.maxOrderWei), CARD_FEE_BPS) <= 102_500n).toBe(true);
    // Without the fee the cap would have let a R$ 1.025,00 order through, and a R$ 1.050,63 charge.
    expect(cents(offer.maxOrderWei) < 100_001n).toBe(true);
    for (const [max, bps] of [[102_500n, 250], [100n, 350], [1n, 1_000], [9_999_999n, 1]] as const) {
      const b = maxOrderCentsForCharge(max, bps);
      expect(cardCheckoutTotal(b, bps) <= max && cardCheckoutTotal(b + 1n, bps) > max, `${max} ${bps}`).toBe(true);
    }
  });

  it('a retail LP posts no card offer, and a downgraded partner\'s card offer is closed, while bank offers carry on', async () => {
    const h = harness({ card: true, offramp: false });
    h.chain.setInstitutional(false);
    await h.tick();
    expect(cardOffer(h)).toMatchObject({ quoting: false, reason: 'not_institutional' });
    expect(h.node.offers!.status.get(NATIVE)).toMatchObject({ quoting: true });
    expect(h.node.metrics.get('mova_lp_quote_pulled_total', { asset: NATIVE, symbol: 'ETH', book: 'card', reason: 'not_institutional' })).toBe(1);

    h.chain.setInstitutional(true);
    await h.tick();
    const offerId = cardOffer(h)!.activeOfferId!;
    h.chain.setInstitutional(false);
    await h.tick();
    expect((await h.chain.offer(offerId)).active).toBe(false);
    expect(cardOffer(h)).toMatchObject({ quoting: false, reason: 'not_institutional' });
  });

  it('posts no card offer without a prover that attests card captures', async () => {
    const h = harness({
      card: true, offramp: false,
      tweak: (o) => { o.provers = [{ verifier: VERIFIER, rails: [Rail.PIX, Rail.BOLETO], provePix: async () => '0x', proveBoleto: async () => '0x' }]; },
    });
    await h.tick();
    expect(cardOffer(h)).toMatchObject({ quoting: false, reason: 'no_card_prover' });
  });

  it('pricing has no card fee in it any more: a quote is the same whatever the card book charges', () => {
    const at = (price: bigint) => ({ price, updatedAt: 1_000n });
    const cfg = { spreadBps: 50, minSpreadBps: 20, maxOracleDeviationBps: 100, bandMarginBps: 50, refreshDriftBps: 60, maxReferenceAgeSeconds: 120, oracleStaleMarginSeconds: 300 };
    expect(quoteOffer({ reference: at(100n), oracle: at(100n), bandBps: 300n, chainNow: 1_000n, wallNow: 1_000n, cfg })).toMatchObject({ ok: true, price: 101n });
  });
});

describe('card orders: checkout, capture, release', () => {
  it('creates a checkout for a confirmed lock only, for the order plus its card fee, serves the fee to the taker, and releases on the capture', async () => {
    const h = harness({ card: true, offramp: false, confirmations: 3 });
    await h.tick();
    const offerId = cardOffer(h)!.activeOfferId!;
    const orderId = h.chain.lockOrder(offerId, 10n ** 17n);
    await h.tick();
    expect(h.acquirer.checkouts.size).toBe(0); // one block deep: nothing a card can pay yet
    await expect(h.node.onramp!.instructions(orderId)).rejects.toMatchObject({ status: 409 });

    h.chain.mine(2);
    await h.tick();
    const ord = await h.chain.order(orderId);
    // 0,1 ETH at R$ 20.200,00: R$ 2.020,00, plus 2,5% (R$ 50,50) = R$ 2.070,50.
    expect(ord.brlCents).toBe(202_000n);
    const [checkout] = h.acquirer.checkouts.values();
    expect(checkout).toMatchObject({ amountCents: 207_050n, reference: orderId, expiresAt: ord.payBy - 300n });

    const { taker, body } = await h.node.onramp!.instructions(orderId);
    if (body.rail !== 'CARD') throw new Error('expected CARD');
    expect(taker).toBe(ord.taker);
    expect(body).toMatchObject({
      checkoutUrl: checkout.url, ...CARD_MERCHANT, amountCents: '202000', amount: 'R$ 2.020,00',
      feeBps: 250, feeCents: '5050', fee: 'R$ 50,50', totalCents: '207050', total: 'R$ 2.070,50',
    });
    // The taker's check before paying: the ids, the fee and the salt open the offer's commitment.
    expect(cardMerchantCommitment({ acquirerId: body.acquirerId, merchantId: body.merchantId, feeBps: body.feeBps }, body.salt))
      .toBe((await h.chain.offer(offerId)).pixKeyHash);

    h.acquirer.pay(checkout.checkoutId);
    await h.tick();
    expect((await h.chain.order(orderId)).state).toBe(OrderState.RELEASED);
    expect(h.node.metrics.get('mova_lp_card_captures_total')).toBe(1);
    expect(h.node.metrics.get('mova_lp_onramp_released_total')).toBe(1);
  });

  it('attack: a capture of the order alone, skipping the fee, never proves it, and is refunded whole once it ends', async () => {
    const h = harness({ card: true, offramp: false, confirmations: 1 });
    const o = await cardOrder(h);
    expect(() => h.acquirer.pay(o.checkoutId, { amountCents: o.brlCents })).toThrow(/exactly its amount/); // an honest acquirer refuses it
    const short = h.acquirer.pay(o.checkoutId, { amountCents: o.brlCents, misbehave: true }); // a broken one does not
    for (let i = 0; i < 2; i++) await h.tick();
    expect(h.node.store.getOrder(o.orderId)?.card?.capture).toBeUndefined();
    expect(h.chain.writes).not.toContain('releaseWithProof');
    await expire(h);
    expect(h.acquirer.charges.find((c) => c.transactionId === short.transactionId)?.status).toBe('REFUNDED');
    expect([...h.acquirer.reversals.values()][0]).toMatchObject({ status: 'SETTLED', kind: 'REFUND', amountCents: o.brlCents });
  });

  it('attack: a capture made for another order releases that order, never this one', async () => {
    const h = harness({ card: true, offramp: false, confirmations: 1 });
    const a = await cardOrder(h);
    const b = await cardOrder(h);
    // Same amount, same merchant, captured - but the acquirer reports B's reference.
    h.acquirer.pay(b.checkoutId);
    await h.tick();
    expect((await h.chain.order(b.orderId)).state).toBe(OrderState.RELEASED);
    expect((await h.chain.order(a.orderId)).state).toBe(OrderState.LOCKED);
    // A charge naming A, for A's total, but at another merchant account, proves nothing either.
    h.acquirer.charge({ reference: a.orderId, amountCents: a.total, merchantId: 'SOMEONE-ELSE' });
    await h.tick();
    expect((await h.chain.order(a.orderId)).state).toBe(OrderState.LOCKED);
    expect(h.node.store.getOrder(a.orderId)?.card?.capture).toBeUndefined();
  });

  it('attack: an authorisation that is never captured is not proven, and is voided once the order ends', async () => {
    const h = harness({ card: true, offramp: false, confirmations: 1 });
    const o = await cardOrder(h);
    const auth = h.acquirer.pay(o.checkoutId, { capture: false });
    for (let i = 0; i < 3; i++) await h.tick();
    expect((await h.chain.order(o.orderId)).state).toBe(OrderState.LOCKED);
    expect(h.chain.writes).not.toContain('releaseWithProof');
    await expire(h);
    expect((await h.chain.order(o.orderId)).state).toBe(OrderState.CANCELLED);
    expect(h.acquirer.charges.find((c) => c.transactionId === auth.transactionId)?.status).toBe('VOIDED');
    expect([...h.acquirer.reversals.values()][0]).toMatchObject({ kind: 'VOID', amountCents: o.total });
    expect([...h.acquirer.checkouts.values()][0].cancelled).toBe(true);
  });

  it('attack: a partial capture never proves the order, and is refunded once it ends', async () => {
    const h = harness({ card: true, offramp: false, confirmations: 1 });
    const o = await cardOrder(h);
    const auth = h.acquirer.pay(o.checkoutId, { capture: false });
    h.acquirer.capture(auth.transactionId, o.total - 1n);
    await h.tick();
    expect((await h.chain.order(o.orderId)).state).toBe(OrderState.LOCKED);
    expect(h.node.store.getOrder(o.orderId)?.card?.capture).toBeUndefined();
    await expire(h);
    const ch = h.acquirer.charges.find((c) => c.transactionId === auth.transactionId)!;
    expect(ch.status).toBe('REFUNDED');
    const [rev] = h.acquirer.reversals.values();
    expect(rev).toMatchObject({ status: 'SETTLED', kind: 'REFUND', amountCents: o.total - 1n });
  });

  it('attack: a charge captured after the order was cancelled is found and refunded, not left with the LP', async () => {
    const h = harness({ card: true, offramp: false, confirmations: 1 });
    const o = await cardOrder(h);
    await expire(h);
    expect(() => h.acquirer.pay(o.checkoutId)).toThrow(/cancelled/); // an honest acquirer refuses it
    const late = h.acquirer.charge({ reference: o.orderId, amountCents: o.total }); // a broken one does not
    await h.tick();
    expect(h.acquirer.charges.find((c) => c.transactionId === late.transactionId)?.status).toBe('REFUNDED');
    expect(h.node.store.getOrder(o.orderId)?.done).toBeUndefined(); // followed until the grace is over
    h.chain.warp(3_700n);
    h.chain.mine();
    await h.tick();
    expect(h.node.store.getOrder(o.orderId)?.done).toBe(OrderState.CANCELLED);
  });

  it('a second payment of one checkout is refunded after the first releases the order, fee and all', async () => {
    const h = harness({ card: true, offramp: false, confirmations: 1 });
    const o = await cardOrder(h);
    const first = h.acquirer.pay(o.checkoutId);
    const second = h.acquirer.pay(o.checkoutId);
    await h.tick();
    expect((await h.chain.order(o.orderId)).state).toBe(OrderState.RELEASED);
    await h.tick();
    expect(h.acquirer.charges.find((c) => c.transactionId === first.transactionId)?.status).toBe('CAPTURED');
    expect(h.acquirer.charges.find((c) => c.transactionId === second.transactionId)?.status).toBe('REFUNDED');
    expect([...h.acquirer.reversals.values()]).toEqual([expect.objectContaining({ transactionId: second.transactionId, amountCents: o.total })]);
  });

  it('a capture that cannot be proven in time - attestors down - expires and is refunded: the whole total, the fee with it', async () => {
    const h = harness({ card: true, offramp: false, confirmations: 1 });
    const o = await cardOrder(h);
    const saved = h.attestors.splice(0, 2);
    const ch = h.acquirer.pay(o.checkoutId);
    await h.tick();
    expect(h.node.store.getOrder(o.orderId)?.card?.capture?.transactionId).toBe(ch.transactionId);
    await expire(h);
    h.attestors.push(...saved);
    expect(h.acquirer.charges[0]).toMatchObject({ status: 'REFUNDED', amountCents: o.total });
    expect([...h.acquirer.reversals.values()][0]).toMatchObject({ status: 'SETTLED', kind: 'REFUND', amountCents: o.total });
    expect(o.total).toBe(o.brlCents + cardFee(o.brlCents, CARD_FEE_BPS));
  });

  it('a PIX credit carrying a card order\'s txid, or its exact amount or total, is never matched to it', async () => {
    const h = harness({ card: true, offramp: false, confirmations: 1 });
    const o = await cardOrder(h);
    h.bank.receivePix({ amountCents: o.brlCents, creditedKey: LP_PIX_KEY, txid: pixTxidForOrder(o.orderId) });
    h.bank.receivePix({ amountCents: o.brlCents, creditedKey: LP_PIX_KEY });
    h.bank.receivePix({ amountCents: o.total, creditedKey: LP_PIX_KEY });
    await h.tick();
    expect(h.node.store.getOrder(o.orderId)?.payment).toBeUndefined();
    expect((await h.chain.order(o.orderId)).state).toBe(OrderState.LOCKED);
  });
});

describe('card orders: crashes', () => {
  it('a crash between the acquirer creating the checkout and the journal recording it: the restart gets the same checkout', async () => {
    const h = harness({ card: true, offramp: false, confirmations: 1 });
    await h.tick();
    const orderId = h.chain.lockOrder(cardOffer(h)!.activeOfferId!, 10n ** 17n);
    h.acquirer.loseNextCheckoutResponse();
    await h.tick();
    expect(h.acquirer.checkouts.size).toBe(1);
    expect(h.node.store.getOrder(orderId)?.card).toMatchObject({ idempotencyKey: idempotencyKey('order-card', h.chain.chainId, ONRAMP, orderId) });
    expect(h.node.store.getOrder(orderId)?.card?.checkoutId).toBeUndefined();

    h.restart();
    await h.tick();
    expect(h.acquirer.checkouts.size).toBe(1);
    expect(h.acquirer.checkoutCalls).toBe(2);
    const [checkout] = h.acquirer.checkouts.values();
    expect(h.node.store.getOrder(orderId)?.card?.checkoutId).toBe(checkout.checkoutId);
    h.acquirer.pay(checkout.checkoutId);
    await h.tick();
    expect((await h.chain.order(orderId)).state).toBe(OrderState.RELEASED);
  });

  it('a refund whose response is lost is asked about under its key after a restart, and runs once', async () => {
    const h = harness({ card: true, offramp: false, confirmations: 1 });
    const o = await cardOrder(h);
    const saved = h.attestors.splice(0, 2);
    h.acquirer.pay(o.checkoutId);
    await h.tick();
    h.chain.warp(31n * 60n);
    h.chain.mine();
    await h.tick();
    h.chain.mine(3);
    h.acquirer.loseNextReverseResponse();
    await h.tick(); // the refund goes through; the node never hears
    const [key] = h.acquirer.reversals.keys();
    expect(h.acquirer.reverseCalls).toBe(1);
    const pending = Object.values(h.node.store.getOrder(o.orderId)!.card!.reversals)[0];
    expect(pending.idempotencyKey).toBe(key);
    expect(pending.result).toBeUndefined();

    h.attestors.push(...saved);
    h.restart();
    for (let i = 0; i < 3; i++) await h.tick();
    expect(h.acquirer.moneyReversedFor(key)).toBe(1);
    expect(h.acquirer.reverseCalls).toBe(1); // resolved by getReversal, never sent again
    expect(Object.values(h.node.store.getOrder(o.orderId)!.card!.reversals)[0].result?.status).toBe('SETTLED');
    expect(h.node.store.unresolvedPayments()).toBe(0);
  });

  it('a refund the acquirer refuses is held for a human, not retried under a new key', async () => {
    const h = harness({ card: true, offramp: false, confirmations: 1 });
    const o = await cardOrder(h);
    h.attestors.splice(0, 2);
    h.acquirer.pay(o.checkoutId);
    await h.tick();
    h.acquirer.failNextReverse();
    await expire(h);
    await h.tick();
    expect(h.node.store.getOrder(o.orderId)?.hold).toMatch(/refused to return a charge/);
    expect(h.acquirer.reverseCalls).toBe(1);
    expect(h.node.metrics.get('mova_lp_held')).toBe(1);
  });
});

describe('card fee disclosure and secrets', () => {
  it('GET /v1/onramp/card-fee states a card offer\'s committed fee, and nothing that opens its commitment', async () => {
    const h = harness({ card: true, offramp: false, confirmations: 1 });
    await h.tick();
    const srv = serveLpNode(h.node, { mode: 'api' });
    const port = await srv.listen(0);
    try {
      const get = (offerId: string) => fetch(`http://127.0.0.1:${port}/v1/onramp/card-fee?offerId=${offerId}`);
      const offerId = cardOffer(h)!.activeOfferId!;
      const res = await get(offerId);
      expect(res.status).toBe(200);
      const text = await res.text();
      expect(JSON.parse(text)).toEqual({ offerId, feeBps: CARD_FEE_BPS });
      for (const secret of [CARD_MERCHANT.merchantId, h.node.store.saltFor((await h.chain.offer(offerId)).pixKeyHash)!.slice(2)]) expect(text).not.toContain(secret);
      expect((await get(h.node.offers!.status.get(NATIVE)!.activeOfferId!)).status).toBe(404); // a bank offer has no card fee
      expect((await get(`0x${'ab'.repeat(32)}`)).status).toBe(404);
      expect((await get('0x1234')).status).toBe(400);
    } finally {
      await srv.close();
    }
  });

  it('/status and /metrics carry no checkout URL, salt, merchant id or transaction id', async () => {
    const h = harness({ card: true, offramp: false, confirmations: 1 });
    const o = await cardOrder(h);
    const ch = h.acquirer.pay(o.checkoutId, { capture: false });
    await h.tick();
    const srv = serveLpNode(h.node, { mode: 'ops' });
    const port = await srv.listen(0);
    try {
      const text = await (await fetch(`http://127.0.0.1:${port}/status`)).text() + await (await fetch(`http://127.0.0.1:${port}/metrics`)).text();
      const [checkout] = h.acquirer.checkouts.values();
      const salts = [...h.node.store.offerSalts.values()].map((x) => x.salt.slice(2));
      for (const secret of [checkout.url, checkout.checkoutId, CARD_MERCHANT.merchantId, ch.transactionId, ...salts]) expect(text).not.toContain(secret);
      expect(text).toContain(o.orderId);
    } finally {
      await srv.close();
    }
  });
});

/** Keep the type-only import honest. */
export type _Unused = QuorumProver;
