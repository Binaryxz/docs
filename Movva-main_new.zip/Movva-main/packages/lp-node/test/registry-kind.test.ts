/**
 * `ViemRampChain.credit()` against either LP registry. The curated LPRegistry is read as before (capOf,
 * availableCents, setupComplete); a PermissionlessLPRegistry has no setupComplete, so its setup is `escrowsBound` and
 * the bond comes along. The anvil suite (permissionless-anvil.test.ts) runs the same path on the real bytecode.
 */
import { describe, expect, it } from 'vitest';
import { BaseError, ContractFunctionRevertedError, type Address } from 'viem';
import { ViemRampChain } from '../src/viem-chain.js';
import { harness } from './harness.js';
import { NATIVE } from '../src/chain.js';

const REGISTRY = '0x0000000000000000000000000000000000000ae9' as Address;
const LP = '0x0000000000000000000000000000000000001111' as Address;

const revert = (fn: string) => new BaseError(`${fn} reverted`, { cause: new ContractFunctionRevertedError({ abi: [], functionName: fn }) });

function client(kind: 'curated' | 'permissionless', o: { down?: number } = {}) {
  const reads: string[] = [];
  let down = o.down ?? 0;
  return {
    reads,
    readContract: async ({ functionName }: { functionName: string }) => {
      reads.push(functionName);
      if (down > 0) { down--; throw new Error('HTTP request failed: ECONNREFUSED'); }
      if (functionName === 'capOf') return 500_000n;
      if (functionName === 'availableCents') return 120_000n;
      if (kind === 'curated' && functionName === 'setupComplete') return true;
      if (kind === 'permissionless') {
        if (functionName === 'MIN_BOND') return 5_000n * 10n ** 18n;
        if (functionName === 'escrowsBound') return true;
        if (functionName === 'bonds') return [5_000n * 10n ** 18n, 380_000n, 0n, 0n, 0, 0];
        if (functionName === 'withdrawableFrom') return 0n;
      }
      throw revert(functionName);
    },
  };
}

const chainOf = (pub: ReturnType<typeof client>) => new ViemRampChain({
  publicClient: pub as never, registry: REGISTRY,
  walletClient: { chain: { id: 31_337 }, account: { address: LP } } as never,
});

describe('credit from either LP registry', () => {
  it('reads the curated registry as it always did', async () => {
    const pub = client('curated');
    expect(await chainOf(pub).credit()).toEqual({ capCents: 500_000n, availableCents: 120_000n, setupComplete: true, registry: 'curated' });
  });

  it('reads a PermissionlessLPRegistry without setupComplete: escrowsBound is its setup, and the bond comes along', async () => {
    const pub = client('permissionless');
    const c = chainOf(pub);
    expect(await c.credit()).toEqual({
      capCents: 500_000n, availableCents: 120_000n, setupComplete: true, registry: 'permissionless',
      bond: { amountWei: 5_000n * 10n ** 18n, withdrawableFrom: 0n },
    });
    const probes = pub.reads.filter((f) => f === 'MIN_BOND').length;
    await c.credit();
    expect(pub.reads.filter((f) => f === 'MIN_BOND').length).toBe(probes); // decided once
  });

  it('fails the read, and asks again next time, when the registry answers as neither', async () => {
    const pub = client('permissionless', { down: 3 });
    const c = chainOf(pub);
    await expect(c.credit()).rejects.toThrow(/ECONNREFUSED/);
    expect(await c.registryKindOf()).toBe('permissionless');
  });
});

describe('the node, when a permissionless LP asks to leave', () => {
  it('pulls its offers the tick its credit reads 0, as it does for a suspended LP', async () => {
    const h = harness({ offramp: false });
    await h.tick();
    expect(h.node.offers!.status.get(NATIVE)).toMatchObject({ quoting: true });
    // requestExit: capOf is 0 in the same block (the in-memory chain models only what the node reads).
    h.chain.credit = async () => ({ capCents: 0n, availableCents: 0n, setupComplete: true, registry: 'permissionless', bond: { amountWei: 1n, withdrawableFrom: 9n } });
    h.chain.mine();
    await h.tick();
    expect(h.node.offers!.status.get(NATIVE)).toMatchObject({ quoting: false, reason: 'not_eligible' });
    expect(h.node.status().credit).toMatchObject({ capCents: 0n, registry: 'permissionless', bond: { withdrawableFrom: 9n } });
  });
});
