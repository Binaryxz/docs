import { describe, expect, it } from 'vitest';
import { NATIVE } from '../src/chain.js';
import { bandAccepts, deviationBps, evaluateSale, quoteOffer, repriceReason, type OfferPricing } from '../src/pricing.js';
import { USDT } from './fake-chain.js';
import { harness } from './harness.js';

const cfg: OfferPricing = {
  spreadBps: 100, minSpreadBps: 30, maxOracleDeviationBps: 200, bandMarginBps: 100, refreshDriftBps: 50,
  maxReferenceAgeSeconds: 120, oracleStaleMarginSeconds: 300,
};
const at = (price: bigint, updatedAt = 10_000n) => ({ price, updatedAt });

describe('pricing', () => {
  it('asks the spread over the higher of reference and oracle, inside the band with its margin', () => {
    const q = quoteOffer({ reference: at(2_010_000n), oracle: at(2_000_000n), bandBps: 500n, chainNow: 10_000n, wallNow: 10_000n, cfg });
    expect(q).toMatchObject({ ok: true, price: 2_030_100n, floor: 2_016_030n, ceiling: 2_080_000n });
    // A reference below the oracle is ignored: the ask is built on the oracle.
    const low = quoteOffer({ reference: at(1_990_000n), oracle: at(2_000_000n), bandBps: 500n, chainNow: 10_000n, wallNow: 10_000n, cfg });
    expect(low).toMatchObject({ ok: true, price: 2_020_000n });
    // A spread wider than the band's room is clamped to the ceiling, never past it.
    const wide = quoteOffer({ reference: at(2_000_000n), oracle: at(2_000_000n), bandBps: 500n, chainNow: 10_000n, wallNow: 10_000n, cfg: { ...cfg, spreadBps: 900 } });
    expect(wide).toMatchObject({ ok: true, price: 2_080_000n });
    expect(bandAccepts(2_080_000n, 2_000_000n, 500n)).toBe(true);
  });

  it.each([
    ['oracle_unavailable', { oracle: undefined }],
    ['oracle_stale', { oracle: at(2_000_000n, 10_000n - 3_600n + 200n) }],
    ['reference_unavailable', { reference: undefined }],
    ['reference_stale', { reference: at(2_000_000n, 10_000n - 121n) }],
    ['reference_deviates', { reference: at(2_050_000n) }],
    ['outside_band', { bandBps: 120n }],
  ] as const)('refuses to quote: %s', (reason, over) => {
    const q = quoteOffer({
      reference: at(2_000_000n), oracle: at(2_000_000n), bandBps: 500n, chainNow: 10_000n, wallNow: 10_000n, cfg, ...over,
    });
    expect(q).toEqual({ ok: false, reason });
  });

  it('reprices below the floor, at the band edge, and past the drift threshold - and not otherwise', () => {
    const q = quoteOffer({ reference: at(2_000_000n), oracle: at(2_000_000n), bandBps: 500n, chainNow: 10_000n, wallNow: 10_000n, cfg });
    if (!q.ok) throw new Error('no quote');
    expect(repriceReason({ posted: 2_020_000n, quote: q, bandBps: 500n, cfg })).toBeUndefined();
    expect(repriceReason({ posted: 2_026_000n, quote: q, bandBps: 500n, cfg })).toBeUndefined(); // 30 bps
    expect(repriceReason({ posted: 2_005_000n, quote: q, bandBps: 500n, cfg })).toBe('below_floor');
    expect(repriceReason({ posted: 2_090_000n, quote: q, bandBps: 500n, cfg })).toBe('band_edge');
    expect(repriceReason({ posted: 2_040_000n, quote: q, bandBps: 500n, cfg })).toBe('drift');
    expect(deviationBps(2_040_000n, 2_020_000n)).toBe(100n);
  });

  it('values a sale at the lower of reference and oracle, rounding the cost up', () => {
    const base = { amount: 10n ** 18n, decimals: 18, chainNow: 10_000n, wallNow: 10_000n,
      cfg: { minMarginBps: 50, maxOracleDeviationBps: 200, maxReferenceAgeSeconds: 120, oracleStaleMarginSeconds: 300 } };
    expect(evaluateSale({ ...base, brlCents: 1_990_000n, reference: at(2_010_000n), oracle: at(2_000_000n) }).ok).toBe(true);
    expect(evaluateSale({ ...base, brlCents: 1_990_001n, reference: at(2_010_000n), oracle: at(2_000_000n) }))
      .toEqual({ ok: false, reason: 'price_too_high' });
    expect(evaluateSale({ ...base, brlCents: 1_980_000n, reference: at(1_980_000n), oracle: at(2_000_000n) }))
      .toEqual({ ok: false, reason: 'price_too_high' });
  });
});

describe('the offer manager', () => {
  it('posts one offer per asset at the quoted price, sized to its configured liquidity', async () => {
    const h = harness({ offramp: false });
    await h.tick();
    const eth = h.node.offers!.status.get(NATIVE)!;
    const usdt = h.node.offers!.status.get(USDT)!;
    expect(eth).toMatchObject({ quoting: true, price: 2_020_000n, available: 5n * 10n ** 18n });
    expect(usdt).toMatchObject({ quoting: true, price: 555n, available: 20_000n * 10n ** 6n });
    const offer = await h.chain.offer(eth.activeOfferId!);
    expect(offer.maxOrderWei).toBe(2n * 10n ** 18n);
    await h.tick();
    expect(h.chain.writes.filter((w) => w === 'postOffer')).toHaveLength(2); // steady state: nothing more
  });

  it('reprices by closing and posting under a fresh salt when the market drifts', async () => {
    const h = harness({ offramp: false });
    await h.tick();
    const first = h.node.offers!.status.get(NATIVE)!.activeOfferId!;
    h.chain.setOracle(NATIVE, 2_050_000n);
    await h.tick();
    const second = h.node.offers!.status.get(NATIVE)!;
    expect(second.activeOfferId).not.toBe(first);
    expect(second.price).toBe(2_070_500n);
    expect((await h.chain.offer(first)).active).toBe(false);
    const [a, b] = [await h.chain.offer(first), await h.chain.offer(second.activeOfferId!)];
    expect(a.pixKeyHash).not.toBe(b.pixKeyHash);
  });

  it('keeps orders running on a closed offer, then sweeps the liquidity they return', async () => {
    const h = harness({ offramp: false });
    await h.tick();
    const first = h.node.offers!.status.get(NATIVE)!.activeOfferId!;
    const orderId = h.chain.lockOrder(first, 10n ** 18n);
    h.chain.setOracle(NATIVE, 2_050_000n); // reprice: the old offer closes with 1 ETH locked
    await h.tick();
    expect((await h.chain.offer(first)).lockedWei).toBe(10n ** 18n);
    h.chain.cancelOrder(orderId); // the ETH returns to the CLOSED offer's available balance
    expect((await h.chain.offer(first)).availableWei).toBe(10n ** 18n);
    await h.tick();
    expect((await h.chain.offer(first)).availableWei).toBe(0n);
  });

  it('tops the active offer up once takers have drained it below the refill line', async () => {
    const h = harness({ offramp: false });
    await h.tick();
    const id = h.node.offers!.status.get(NATIVE)!.activeOfferId!;
    for (let i = 0; i < 2; i++) h.chain.releaseAsOther(h.chain.lockOrder(id, 2n * 10n ** 18n));
    expect((await h.chain.offer(id)).availableWei).toBe(10n ** 18n);
    await h.tick();
    expect((await h.chain.offer(id)).availableWei).toBe(5n * 10n ** 18n);
    expect(h.chain.writes).toContain('fundOffer');
  });

  it('pulls when the oracle is about to go stale, and comes back when it is fresh', async () => {
    const h = harness({ offramp: false });
    await h.tick();
    h.chain.warp(3_400n); // within the 300 s margin of MAX_PRICE_AGE
    h.chain.mine();
    await h.tick();
    expect(h.node.offers!.status.get(NATIVE)).toMatchObject({ quoting: false, reason: 'oracle_stale' });
    h.chain.setOracle(NATIVE, 2_000_000n);
    h.chain.setOracle(USDT, 550n);
    await h.tick();
    expect(h.node.offers!.status.get(NATIVE)?.quoting).toBe(true);
  });

  it('pulls when the escrow revokes the verifier it names', async () => {
    const h = harness({ offramp: false });
    await h.tick();
    h.chain.revokeVerifier(h.chain.verifier);
    await h.tick();
    expect(h.node.offers!.status.get(NATIVE)).toMatchObject({ quoting: false, reason: 'verifier_revoked' });
  });
});
