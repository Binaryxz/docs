import { describe, expect, it } from 'vitest';
import { appendFileSync, existsSync, mkdtempSync, readFileSync, statSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import type { Hex } from 'viem';
import { Rail, newPixSalt, pixKeyCommitment, railMask } from '@mova/ramp';
import { OrderState, SaleState } from '../src/abi.js';
import { NATIVE } from '../src/chain.js';
import { JsonlJournal, MemoryJournal, decodeRecord, encodeRecord, type CompactStep } from '../src/journal.js';
import { orderTxidOf } from './harness.js';
import { Store, idempotencyKey, type LpRecord } from '../src/store.js';
import { MOVVA, OFFRAMP, ONRAMP } from './fake-chain.js';
import { LP_PIX_KEY, harness, type Harness } from './harness.js';

/**
 * Journal compaction (journal.ts, store.ts `snapshot`): the live state survives being written as one
 * record; a crash at every step of replacing the file leaves a journal a restart reads; and a node that
 * compacted in the middle of an unresolved payment, refund or mint still resolves it exactly once.
 */

const SELLER_KEY = '+5511987654321';
const tmp = () => join(mkdtempSync(join(tmpdir(), 'lp-compact-')), 'state.jsonl');

/** Everything a restart acts on, in a form two stores can be compared by. */
function live(s: Store) {
  const sorted = <T>(m: Map<string, T>) => [...m.entries()].sort(([a], [b]) => (a < b ? -1 : 1)).map(([, v]) => v);
  return decodeRecord<unknown>(encodeRecord({
    cursor: s.cursor,
    salts: sorted(s.offerSalts),
    orders: sorted(s.orders).filter((o) => o.done === undefined),
    sales: sorted(s.sales).filter((x) => x.done === undefined),
    ops: sorted(s.gatewayOps).filter((o) => !o.result),
    credits: [...s.consumedCredits].sort(),
  }));
}

/** A node with something of everything open: a paid PIX order, a PIX order refunded past a lost response, a sale mid-payment, a disclosure. */
async function busy(o: { journal?: (path: string) => JsonlJournal<LpRecord>; path?: string; compactJournalAtBytes?: number } = {}) {
  const h = harness({
    confirmations: 1,
    tweak: (opts) => {
      if (o.journal && o.path) opts.journal = o.journal(o.path);
      opts.compactJournalAtBytes = o.compactJournalAtBytes;
    },
  });
  await h.tick();
  // A PIX order, paid and released: finished, but its credit must stay consumed.
  const pixOffer = h.node.offers!.status.get(NATIVE)!.activeOfferId!;
  const released = h.chain.lockOrder(pixOffer, 10n ** 17n);
  const credit = h.bank.receivePix({ amountCents: (await h.chain.order(released)).brlCents, creditedKey: LP_PIX_KEY, txid: orderTxidOf(h, released) });
  await h.tick();
  // A second PIX order, paid but unprovable (its witnesses are dark), expired: its refund's response lost.
  const refundOrder = h.chain.lockOrder(pixOffer, 10n ** 17n);
  h.chain.mine(2);
  await h.tick();
  const saved = h.witnesses.splice(0, 2);
  h.bank.receivePix({ amountCents: (await h.chain.order(refundOrder)).brlCents, creditedKey: LP_PIX_KEY, txid: orderTxidOf(h, refundOrder) });
  await h.tick();
  h.chain.warp(31n * 60n);
  h.chain.mine();
  await h.tick();
  h.chain.mine(2);
  h.bank.loseNextResponse();
  await h.tick();
  h.witnesses.push(...saved);
  // A sale, claimed and paid, the bank's response lost.
  const salt = newPixSalt();
  const sale = h.chain.openSale({ amount: 10n ** 17n, brlCents: 198_000n, payeeKeyHash: pixKeyCommitment(SELLER_KEY, salt), railMask: railMask(Rail.PIX) });
  await h.node.offramp!.submitPayee(sale, { pixKey: SELLER_KEY, salt });
  await h.tick();
  h.bank.loseNextResponse();
  await h.tick();
  // A second sale, disclosed and not a buy (1% above the oracle): its disclosure is state only the journal has.
  const salt2 = newPixSalt();
  const disclosed = h.chain.openSale({ amount: 10n ** 17n, brlCents: 202_000n, payeeKeyHash: pixKeyCommitment(SELLER_KEY, salt2), railMask: railMask(Rail.PIX) });
  await h.node.offramp!.submitPayee(disclosed, { pixKey: SELLER_KEY, salt: salt2 });
  return { h, released, credit, refundOrder, sale, disclosed, saleKey: idempotencyKey('sale-pay', h.chain.chainId, OFFRAMP, sale) };
}

describe('compaction: the snapshot holds the live state', () => {
  it('a store rebuilt from one snapshot record acts on exactly what the full journal would', async () => {
    const { h, released, credit, refundOrder, sale, disclosed } = await busy();
    const before = h.node.store;
    expect(before.getOrder(released)?.done).toBe(OrderState.RELEASED);
    expect(before.getSale(sale)?.pay?.result).toBeUndefined(); // an intent without a result
    expect(h.bank.moneyMovedFor(idempotencyKey('order-refund', h.chain.chainId, ONRAMP, refundOrder))).toBe(1); // refunded once, past a lost response

    const j = new MemoryJournal<LpRecord>();
    j.load();
    j.append(before.snapshot({ now: h.chain.time() }));
    const after = new Store(j);
    after.load();
    expect(live(after)).toEqual(live(before));
    expect(after.getOrder(released)).toBeUndefined(); // finished: dropped...
    expect(after.consumedCredits.has(credit.bankTxId)).toBe(true); // ...but its credit still settles nothing else
    expect(after.getSale(disclosed)?.payee).toMatchObject({ kind: 'pix', pixKey: SELLER_KEY });
    expect(after.unresolvedPayments()).toBe(before.unresolvedPayments());
  });

  it('keeps finished sales and gateway operations the 24-hour budgets count, and forgets credits no order could match', () => {
    const j = new MemoryJournal<LpRecord>();
    const s = new Store(j, () => 1);
    s.load();
    const now = 2_000_000_000n;
    const sale = `0x${'5a'.repeat(32)}` as Hex;
    s.record({ t: 'sale.seen', saleId: sale, block: 1n });
    s.record({ t: 'sale.pay.intent', saleId: sale, idempotencyKey: 'S1', rail: 'PIX', amountCents: 500n, claimedAt: now - 3_600n });
    s.record({ t: 'sale.pay.result', saleId: sale, result: { idempotencyKey: 'S1', status: 'SETTLED', paidAt: now - 3_600n } });
    s.record({ t: 'sale.done', saleId: sale, state: SaleState.SETTLED });
    const old = `0x${'0d'.repeat(32)}` as Hex;
    s.record({ t: 'order.seen', orderId: old, offerId: old, block: 1n });
    s.record({ t: 'order.payment', orderId: old, payment: { rail: 'PIX', bankTxId: 'E-OLD', amountCents: 1n, paidAt: now - 40n * 86_400n } });
    s.record({ t: 'order.done', orderId: old, state: OrderState.RELEASED });
    s.record({ t: 'gateway.intent', opId: old, op: 'mint', amountIn: 5n, minOut: 1n, need: 1n, nonce: 0, wallAt: now - 3_600n });
    s.record({ t: 'gateway.result', opId: old, outcome: 'MINED', amountOut: 1n });

    const snap = s.snapshot({ now });
    if (snap.t !== 'snapshot') throw new Error('expected a snapshot');
    expect(snap.state.sales.map((x) => x.saleId)).toEqual([sale]);
    expect(snap.state.gatewayOps.map((x) => x.opId)).toEqual([old]);
    expect(snap.state.orders).toEqual([]);
    expect(snap.state.consumedCredits).toEqual([]);
  });
});

describe('compaction: a crash at any step leaves a journal a restart reads', () => {
  it.each(['written', 'renamed'] as CompactStep[])('killed after the snapshot is %s: the restart has the same state, and keeps appending', async (step) => {
    const path = tmp();
    let armed = false;
    const { h } = await busy({ path, journal: (p) => new JsonlJournal<LpRecord>(p, { onCompactStep: (s) => { if (armed && s === step) throw new Error('killed'); } }) });
    const expected = live(h.node.store);
    const bytes = statSync(path).size;
    armed = true;
    expect(() => h.node.store.compact({ now: h.chain.time() })).toThrow('killed');
    expect(statSync(path).size < bytes).toBe(step === 'renamed');

    const restarted = new Store(new JsonlJournal<LpRecord>(path));
    restarted.load();
    expect(live(restarted)).toEqual(expected);
    expect(existsSync(`${path}.compact`)).toBe(false);
    restarted.record({ t: 'cursor', block: 999n, hash: `0x${'99'.repeat(32)}` });
    restarted.close();
    const again = new Store(new JsonlJournal<LpRecord>(path));
    again.load();
    expect(again.cursor?.block).toBe(999n);
  });

  it('a torn .compact file from a crash mid-write is never read, and is removed', async () => {
    const path = tmp();
    const { h } = await busy({ path, journal: (p) => new JsonlJournal<LpRecord>(p) });
    const expected = live(h.node.store);
    h.node.store.close();
    writeFileSync(`${path}.compact`, '{"t":"snapshot","v":1,"state":{"cursor":{"blo');
    const restarted = new Store(new JsonlJournal<LpRecord>(path));
    restarted.load();
    expect(live(restarted)).toEqual(expected);
    expect(existsSync(`${path}.compact`)).toBe(false);
  });

  it('after a compaction, a torn final append is dropped as before, and the file stays 0600', async () => {
    const path = tmp();
    const { h } = await busy({ path, journal: (p) => new JsonlJournal<LpRecord>(p) });
    h.node.store.compact({ now: h.chain.time() });
    h.node.store.record({ t: 'cursor', block: 12_345n, hash: `0x${'12'.repeat(32)}` });
    const expected = live(h.node.store);
    h.node.store.close();
    appendFileSync(path, '{"t":"cursor","block":{"$n":"123');
    const restarted = new Store(new JsonlJournal<LpRecord>(path));
    restarted.load();
    expect(live(restarted)).toEqual(expected);
    expect(readFileSync(path, 'utf8').split('\n').filter(Boolean)).toHaveLength(2);
    expect(statSync(path).mode & 0o777).toBe(0o600);
  });
});

describe('compaction: a node that compacts mid-flight still resolves everything exactly once', () => {
  it('compacting every tick, then a restart: the lost payment is adopted, the lost refund found, each moved once', async () => {
    const path = tmp();
    const { h, sale, saleKey, refundOrder } = await busy({ path, journal: (p) => new JsonlJournal<LpRecord>(p), compactJournalAtBytes: 1 });
    expect(h.node.metrics.get('mova_lp_journal_compactions_total')).toBeGreaterThan(0);
    expect(readFileSync(path, 'utf8').trim().split('\n').length).toBeLessThan(5);
    const refundKey = idempotencyKey('order-refund', h.chain.chainId, ONRAMP, refundOrder);

    h.restart();
    for (let i = 0; i < 3; i++) await h.tick();
    expect(h.bank.moneyMovedFor(saleKey)).toBe(1);
    expect((await h.chain.sale(sale)).state).toBe(SaleState.SETTLED);
    expect(h.bank.moneyMovedFor(refundKey)).toBe(1);
    expect(h.node.store.unresolvedPayments()).toBe(0);
  });

  it('compacting while a gateway mint is broadcast but unrecorded: the restart waits for it and mints once', async () => {
    const path = tmp();
    const h: Harness = harness({
      gateway: true, offramp: false, confirmations: 2,
      tweak: (o) => { o.journal = new JsonlJournal<LpRecord>(path); o.compactJournalAtBytes = 1; },
    });
    h.chain.holdSends = true;
    h.chain.loseNextSendResponse = true;
    await h.tick();
    await h.tick(); // a second tick, compacting with the intent open
    expect(h.node.metrics.get('mova_lp_journal_compactions_total')).toBeGreaterThan(0);
    h.restart();
    expect(h.node.store.openGatewayOps()).toHaveLength(1);
    await h.tick();
    h.chain.holdSends = false;
    h.chain.mine(4);
    for (let i = 0; i < 3; i++) await h.tick();
    expect(h.chain.executed('mint')).toHaveLength(1);
    expect(h.chain.attempts.filter((a) => a.phase === 'send')).toHaveLength(1);
    expect(h.node.offers!.status.get(MOVVA)).toMatchObject({ quoting: true });
  });
});
