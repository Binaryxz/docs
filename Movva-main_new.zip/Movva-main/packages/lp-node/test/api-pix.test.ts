import { afterEach, beforeAll, describe, expect, it } from 'vitest';
import { execFileSync } from 'node:child_process';
import { mkdtempSync, readFileSync } from 'node:fs';
import { createServer as createHttpServer, type IncomingMessage, type Server, type ServerResponse } from 'node:http';
import { createServer as createHttpsServer } from 'node:https';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import type { TLSSocket } from 'node:tls';
import {
  ApiPixClient, ApiPixError, ApiPixReceiver, cobToCharge, composeBank, fromValor, parseWebhookPix, toValor,
  type ApiPixCob, type ApiPixDevolucao, type ApiPixPix,
} from '../src/api-pix.js';
import { MockBank } from '../src/bank.js';

/**
 * A PSP that speaks API Pix 2.10.0 as the OpenAPI document defines it: OAuth2 client credentials
 * with HTTP Basic, `GET /pix` with RFC 3339 `inicio`/`fim` and `paginacao.*` paging, devoluções by
 * client id, RFC 7807 problems. Every request is recorded so the tests can check what was sent.
 */
class MockPsp {
  readonly requests: { method: string; path: string; query: URLSearchParams; auth?: string; body?: unknown; clientCert?: boolean }[] = [];
  readonly pix: ApiPixPix[] = [];
  readonly devolucoes = new Map<string, ApiPixDevolucao>();
  /** Immediate charges by txid: `PUT` (idempotent), `GET`, `PATCH` to `REMOVIDA_PELO_USUARIO_RECEBEDOR`. */
  readonly cobs = new Map<string, ApiPixCob>();
  tokens = 0;
  revokeTokens = false;
  private seq = 0;

  handler = async (rq: IncomingMessage, rs: ServerResponse): Promise<void> => {
    const url = new URL(rq.url ?? '/', 'http://psp');
    const chunks: Buffer[] = [];
    for await (const c of rq) chunks.push(c as Buffer);
    const raw = Buffer.concat(chunks).toString('utf8');
    const socket = rq.socket as TLSSocket;
    const rec = {
      method: rq.method ?? '', path: url.pathname, query: url.searchParams, auth: rq.headers.authorization,
      body: rq.headers['content-type']?.includes('json') && raw ? JSON.parse(raw) as unknown : raw || undefined,
      clientCert: typeof socket.getPeerCertificate === 'function' ? !!socket.getPeerCertificate()?.subject : undefined,
    };
    this.requests.push(rec);
    const json = (status: number, body: unknown) => { rs.writeHead(status, { 'content-type': 'application/json' }); rs.end(JSON.stringify(body)); };
    const problem = (status: number, type: string, title: string) => json(status, {
      type: `https://pix.bcb.gov.br/api/v2/error/${type}`, title, status, detail: 'contém valores enviados: 52998224725',
      correlationId: 'corr-1', violacoes: [{ razao: 'x', propriedade: 'chave', valor: '52998224725' }],
    });

    if (url.pathname === '/oauth/token') {
      const expected = `Basic ${Buffer.from('client-id:client-secret').toString('base64')}`;
      if (rq.headers.authorization !== expected || new URLSearchParams(raw).get('grant_type') !== 'client_credentials') {
        return json(401, { error: 'invalid_client' });
      }
      this.tokens++;
      this.revokeTokens = false;
      return json(200, { access_token: `tok-${this.tokens}`, token_type: 'Bearer', expires_in: 3600, scope: new URLSearchParams(raw).get('scope') });
    }
    if (!rq.headers.authorization?.startsWith('Bearer tok-') || this.revokeTokens) return problem(401, 'AcessoNegado', 'Acesso negado');

    const api = url.pathname.replace(/^\/api\/v2/, '');
    if (rq.method === 'GET' && api === '/pix') {
      const inicio = Date.parse(url.searchParams.get('inicio') ?? '');
      const fim = Date.parse(url.searchParams.get('fim') ?? '');
      if (Number.isNaN(inicio) || Number.isNaN(fim)) return problem(400, 'PixConsultaInvalida', 'Consulta inválida');
      const page = Number(url.searchParams.get('paginacao.paginaAtual') ?? 0);
      const size = Number(url.searchParams.get('paginacao.itensPorPagina') ?? 100);
      const all = this.pix.filter((p) => Date.parse(p.horario) >= inicio && Date.parse(p.horario) <= fim);
      const pages = Math.max(1, Math.ceil(all.length / size));
      return json(200, {
        parametros: {
          inicio: new Date(inicio).toISOString(), fim: new Date(fim).toISOString(),
          paginacao: { paginaAtual: page, itensPorPagina: size, quantidadeDePaginas: pages, quantidadeTotalDeItens: all.length },
        },
        pix: all.slice(page * size, (page + 1) * size),
      });
    }
    const dev = /^\/pix\/([a-zA-Z0-9]{32})\/devolucao\/([a-zA-Z0-9]{1,35})$/.exec(api);
    if (dev) {
      const key = `${dev[1]}/${dev[2]}`;
      if (rq.method === 'GET') {
        const d = this.devolucoes.get(key);
        return d ? json(200, d) : problem(404, 'PixDevolucaoNaoEncontrada', 'Devolução não encontrada');
      }
      const pixRec = this.pix.find((p) => p.endToEndId === dev[1]);
      if (!pixRec) return problem(404, 'PixNaoEncontrado', 'Pix não encontrado');
      const b = rec.body as { valor: string; natureza?: string };
      if (fromValor(b.valor) > fromValor(pixRec.valor)) return problem(400, 'PixDevolucaoInvalida', 'Devolução inválida');
      const d: ApiPixDevolucao = {
        id: dev[2], rtrId: `D99999999202609141200${String(++this.seq).padStart(11, '0')}`, valor: b.valor,
        horario: { solicitacao: new Date().toISOString() }, status: 'EM_PROCESSAMENTO',
      };
      this.devolucoes.set(key, d);
      return json(201, d);
    }
    const cob = /^\/cob\/([a-zA-Z0-9]{26,35})$/.exec(api);
    if (cob && rq.method === 'PUT') {
      // A repeated PUT is the same charge (Manual de Padrões 2.10.0, Annex I, footnote 85).
      const prior = this.cobs.get(cob[1]);
      if (prior) return json(200, prior);
      const b = rec.body as { calendario: { expiracao: number }; valor: { original: string; modalidadeAlteracao?: number }; chave: string };
      const c: ApiPixCob = {
        txid: cob[1], revisao: 0, status: 'ATIVA', calendario: { criacao: new Date().toISOString(), expiracao: b.calendario.expiracao },
        valor: b.valor, chave: b.chave, location: 'pix.example.com/qr/v2/abc', pixCopiaECola: '00020101021226...6304ABCD',
      };
      this.cobs.set(cob[1], c);
      return json(201, c);
    }
    if (cob && rq.method === 'GET') {
      const c = this.cobs.get(cob[1]);
      return c ? json(200, c) : problem(404, 'CobNaoEncontrado', 'Cobrança não encontrada');
    }
    if (cob && rq.method === 'PATCH') {
      const c = this.cobs.get(cob[1]);
      if (!c) return problem(404, 'CobNaoEncontrado', 'Cobrança não encontrada');
      // "Não se pode alterar e nem remover uma cobrança cujo status esteja em CONCLUÍDA."
      if (c.status !== 'ATIVA') return problem(400, 'CobOperacaoInvalida', 'Operação inválida.');
      if ((rec.body as { status?: unknown }).status !== 'REMOVIDA_PELO_USUARIO_RECEBEDOR') return problem(400, 'CobOperacaoInvalida', 'Cobrança inválida.');
      Object.assign(c, { status: 'REMOVIDA_PELO_USUARIO_RECEBEDOR', revisao: c.revisao + 1 });
      return json(200, c);
    }
    return problem(404, 'NaoEncontrado', 'Não encontrado');
  };
}

const E2E = (n: number) => `E99999999202609141200${String(n).padStart(11, '0')}`;

let servers: Server[] = [];
afterEach(async () => {
  for (const s of servers) await new Promise<void>((r) => s.close(() => r()));
  servers = [];
});

async function listen(s: Server): Promise<number> {
  servers.push(s);
  await new Promise<void>((r) => s.listen(0, '127.0.0.1', () => r()));
  const a = s.address();
  return typeof a === 'object' && a ? a.port : 0;
}

async function plainPsp(): Promise<{ psp: MockPsp; client: ApiPixClient }> {
  const psp = new MockPsp();
  const port = await listen(createHttpServer((rq, rs) => void psp.handler(rq, rs)));
  const client = new ApiPixClient({
    baseUrl: `http://127.0.0.1:${port}/api/v2`, tokenUrl: `http://127.0.0.1:${port}/oauth/token`,
    clientId: 'client-id', clientSecret: 'client-secret', pageSize: 2,
  });
  return { psp, client };
}

describe('API Pix, receiving', () => {
  it('lists received Pix across pages, as IncomingPayments in centavos and unix seconds', async () => {
    const { psp, client } = await plainPsp();
    for (let i = 1; i <= 5; i++) {
      psp.pix.push({ endToEndId: E2E(i), txid: `abc${i}`, valor: `${i}0.0${i}`, chave: 'liquidez@lp.example', horario: `2026-09-14T12:0${i}:00.358Z`, infoPagador: 'pedido' });
    }
    psp.pix.push({ endToEndId: 'not-an-e2e', valor: '1.00', horario: '2026-09-14T12:03:30Z' }); // breaks the schema
    const receiver = new ApiPixReceiver(client);
    const got = await receiver.listIncoming({ since: BigInt(Date.parse('2026-09-14T12:02:00Z') / 1000), until: BigInt(Date.parse('2026-09-14T12:10:00Z') / 1000) });
    expect(got.map((p) => p.bankTxId)).toEqual([E2E(2), E2E(3), E2E(4), E2E(5)]);
    expect(got[0]).toEqual({
      rail: 'PIX', bankTxId: E2E(2), amountCents: 2002n, paidAt: BigInt(Date.parse('2026-09-14T12:02:00Z') / 1000),
      creditedKey: 'liquidez@lp.example', txid: 'abc2', payerId: undefined,
    });
    const listCalls = psp.requests.filter((r) => r.path === '/api/v2/pix');
    expect(listCalls.map((r) => r.query.get('paginacao.paginaAtual'))).toEqual(['0', '1', '2']);
    expect(listCalls[0].query.get('paginacao.itensPorPagina')).toBe('2');
    expect(listCalls[0].query.get('inicio')).toBe('2026-09-14T12:02:00.000Z');
    // One token, obtained by client credentials with HTTP Basic, reused across pages.
    expect(psp.tokens).toBe(1);
    const tokenCall = psp.requests.find((r) => r.path === '/oauth/token')!;
    expect(new URLSearchParams(tokenCall.body as string).get('scope')).toContain('pix.read');
  });

  it('refunds by devolução under the idempotency key, looking it up before sending', async () => {
    const { psp, client } = await plainPsp();
    psp.pix.push({ endToEndId: E2E(7), valor: '150.00', horario: new Date().toISOString() });
    const receiver = new ApiPixReceiver(client);
    const first = await receiver.refundIncoming({ idempotencyKey: 'R0123456789abcdef', bankTxId: E2E(7), amountCents: 15_000n, reason: 'Mova on-ramp order did not settle' });
    expect(first).toMatchObject({ status: 'PENDING', amountCents: 15_000n, idempotencyKey: 'R0123456789abcdef' });
    const put = psp.requests.find((r) => r.method === 'PUT')!;
    expect(put.path).toBe(`/api/v2/pix/${E2E(7)}/devolucao/R0123456789abcdef`);
    expect(put.body).toEqual({ valor: '150.00', natureza: 'ORIGINAL', descricao: 'Mova on-ramp order did not settle' });

    // The PSP settles it; asking again under the same key reads it, and sends nothing new.
    const d = psp.devolucoes.get(`${E2E(7)}/R0123456789abcdef`)!;
    Object.assign(d, { status: 'DEVOLVIDO', horario: { ...d.horario, liquidacao: '2026-09-14T12:30:00Z' } });
    const again = await receiver.refundIncoming({ idempotencyKey: 'R0123456789abcdef', bankTxId: E2E(7), amountCents: 15_000n, reason: 'x' });
    expect(again).toMatchObject({ status: 'SETTLED', paidAt: BigInt(Date.parse('2026-09-14T12:30:00Z') / 1000) });
    expect(psp.requests.filter((r) => r.method === 'PUT')).toHaveLength(1);
  });

  it('turns RFC 7807 problems into errors that keep the type and drop the echoed values', async () => {
    const { psp, client } = await plainPsp();
    psp.pix.push({ endToEndId: E2E(8), valor: '10.00', horario: new Date().toISOString() });
    const err = await client.putDevolucao(E2E(8), 'Rtoomuch', { valor: '99.00' }).catch((e: unknown) => e);
    expect(err).toBeInstanceOf(ApiPixError);
    expect(err).toMatchObject({ status: 400, problemType: 'https://pix.bcb.gov.br/api/v2/error/PixDevolucaoInvalida', correlationId: 'corr-1' });
    expect((err as Error).message).not.toContain('52998224725');
  });

  it('renews a revoked token once and retries', async () => {
    const { psp, client } = await plainPsp();
    await client.listPix({ inicio: new Date(0), fim: new Date() });
    psp.revokeTokens = true;
    await client.listPix({ inicio: new Date(0), fim: new Date() });
    expect(psp.tokens).toBe(2);
  });

  it('creates an immediate charge with the spec\'s body', async () => {
    const { psp, client } = await plainPsp();
    const txid = 'movaorder0123456789abcdef01';
    const cob = await client.putCob(txid, { amountCents: 202_404n, chave: 'liquidez@lp.example', expiracaoSeconds: 1800 });
    expect(cob).toMatchObject({ txid, status: 'ATIVA', valor: { original: '2024.04' } });
    expect(psp.requests.at(-1)!.body).toEqual({ calendario: { expiracao: 1800 }, valor: { original: '2024.04', modalidadeAlteracao: 0 }, chave: 'liquidez@lp.example' });
    await expect(client.putCob('short', { amountCents: 1n, chave: 'x', expiracaoSeconds: 1 })).rejects.toThrow(/26-35/);
  });

  it('creates, reads and removes immediate charges for the node, as the spec defines them', async () => {
    const { psp, client } = await plainPsp();
    const receiver = new ApiPixReceiver(client);
    const txid = 'Q0123456789abcdef0123456789abcdef';
    expect(await receiver.getCharge(txid)).toBeUndefined(); // 404 is "none", not an error

    const created = await receiver.createCharge({ txid, amountCents: 50_000n, pixKey: 'liquidez@lp.example', expiresInSeconds: 1_500 });
    expect(created).toMatchObject({
      txid, status: 'ATIVA', revisao: 0, amountCents: 50_000n, amountFixed: true, pixKey: 'liquidez@lp.example', expiresInSeconds: 1_500,
      location: 'pix.example.com/qr/v2/abc',
    });
    expect(created.expiresAt).toBe(created.createdAt + 1_500n);
    expect(psp.requests.find((r) => r.method === 'PUT')!.body).toEqual({
      calendario: { expiracao: 1500 }, valor: { original: '500.00', modalidadeAlteracao: 0 }, chave: 'liquidez@lp.example',
    });
    expect(await receiver.createCharge({ txid, amountCents: 50_000n, pixKey: 'liquidez@lp.example', expiresInSeconds: 1_400 }))
      .toMatchObject({ txid, expiresInSeconds: 1_500 }); // a repeated PUT: the same charge
    expect(psp.cobs.size).toBe(1);

    expect(await receiver.cancelCharge(txid)).toBe('REMOVIDA_PELO_USUARIO_RECEBEDOR');
    const patch = psp.requests.find((r) => r.method === 'PATCH')!;
    expect(patch.path).toBe(`/api/v2/cob/${txid}`);
    expect(patch.body).toEqual({ status: 'REMOVIDA_PELO_USUARIO_RECEBEDOR' });
    expect(await receiver.cancelCharge(txid)).toBe('REMOVIDA_PELO_USUARIO_RECEBEDOR'); // read, not revised twice
    expect(psp.requests.filter((r) => r.method === 'PATCH')).toHaveLength(1);

    // A paid charge stays paid; a charge the PSP never had is undefined.
    const paid = 'Q1123456789abcdef0123456789abcdef';
    await receiver.createCharge({ txid: paid, amountCents: 1_000n, pixKey: 'liquidez@lp.example', expiresInSeconds: 600 });
    psp.cobs.get(paid)!.status = 'CONCLUIDA';
    expect(await receiver.cancelCharge(paid)).toBe('CONCLUIDA');
    expect(psp.requests.filter((r) => r.method === 'PATCH')).toHaveLength(1);
    expect(await receiver.cancelCharge('Q2123456789abcdef0123456789abcdef')).toBeUndefined();

    // composeBank takes charges from API Pix, whatever the sending adapter has.
    const bank = composeBank(receiver, new MockBank());
    expect(await bank.getCharge!(paid)).toMatchObject({ status: 'CONCLUIDA', amountCents: 1_000n });
  });

  it('reads a charge\'s status as the enum spells it and as the manual\'s prose does, and marks a payer-editable amount', () => {
    const base = {
      txid: 'Q0123456789abcdef0123456789abcdef', revisao: 1, calendario: { criacao: '2026-09-14T12:00:00.358Z', expiracao: 600 },
      valor: { original: '10.00' }, chave: 'x@y.example',
    };
    expect(cobToCharge({ ...base, status: 'REMOVIDO_PELO_USUARIO_RECEBEDOR' }).status).toBe('REMOVIDA_PELO_USUARIO_RECEBEDOR');
    expect(cobToCharge({ ...base, status: 'ATIVA' })).toMatchObject({ amountCents: 1_000n, amountFixed: true, createdAt: 1_789_387_200n, expiresAt: 1_789_387_800n });
    expect(cobToCharge({ ...base, status: 'ATIVA', valor: { original: '10.00', modalidadeAlteracao: 1 } }).amountFixed).toBe(false);
    expect(cobToCharge({ ...base, status: 'ATIVA', loc: { id: 7, location: 'pix.example.com/qr/v2/x', tipoCob: 'cob' } }).location).toBe('pix.example.com/qr/v2/x');
    expect(() => cobToCharge({ ...base, status: 'EXPIRADA' as never })).toThrow();
    expect(() => cobToCharge({ ...base, status: 'ATIVA', txid: 'short' })).toThrow();
  });

  it('parses a webhook notification, keeping the valid records', () => {
    const got = parseWebhookPix({
      pix: [
        { endToEndId: 'E12345678202009091221kkkkkkkkkkk', txid: 'c3e0e7a4e7f1469a9f782d3d4999343c', valor: '110.00', horario: '2020-09-09T20:15:00.358Z', infoPagador: '0123456789' },
        { endToEndId: 'E1', valor: '1', horario: 'yesterday' },
      ],
    });
    expect(got).toEqual([{
      rail: 'PIX', bankTxId: 'E12345678202009091221kkkkkkkkkkk', amountCents: 11_000n, paidAt: 1_599_682_500n,
      creditedKey: undefined, txid: 'c3e0e7a4e7f1469a9f782d3d4999343c', payerId: undefined,
    }]);
    expect(() => parseWebhookPix({ cobs: [] })).toThrow();
  });

  it('formats and parses valor exactly', () => {
    expect(toValor(1n)).toBe('0.01');
    expect(toValor(123_456n)).toBe('1234.56');
    expect(fromValor('0.10')).toBe(10n);
    expect(() => fromValor('1.5')).toThrow();
    expect(() => fromValor('1,50')).toThrow();
  });

  it('composes with a sending adapter into a full BankAdapter', async () => {
    const { psp, client } = await plainPsp();
    psp.pix.push({ endToEndId: E2E(9), valor: '5.00', horario: new Date().toISOString(), chave: 'k@lp.example' });
    const sending = new MockBank();
    const bank = composeBank(new ApiPixReceiver(client), sending);
    expect((await bank.listIncoming({ since: 0n }))[0].bankTxId).toBe(E2E(9));
    const r = await bank.sendPix({ idempotencyKey: 'S1', pixKey: 'seller@pix.example', amountCents: 100n });
    expect(r.status).toBe('SETTLED');
    expect(bank.registerBoleto).toBeDefined();
  });
});

const hasOpenssl = (() => {
  try { execFileSync('openssl', ['version'], { stdio: 'ignore' }); return true; } catch { return false; }
})();

describe.skipIf(!hasOpenssl)('API Pix over mTLS', () => {
  let pki: { ca: Buffer; serverCert: Buffer; serverKey: Buffer; clientCert: Buffer; clientKey: Buffer; strangerCert: Buffer; strangerKey: Buffer };

  beforeAll(() => {
    const dir = mkdtempSync(join(tmpdir(), 'api-pix-pki-'));
    const ossl = (...args: string[]) => execFileSync('openssl', args, { cwd: dir, stdio: 'ignore' });
    ossl('req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-keyout', 'ca.key', '-out', 'ca.pem', '-days', '2', '-subj', '/CN=Test PSP CA');
    const leaf = (name: string, ext: string, ca = 'ca') => {
      ossl('req', '-newkey', 'rsa:2048', '-nodes', '-keyout', `${name}.key`, '-out', `${name}.csr`, '-subj', `/CN=${name}`);
      execFileSync('sh', ['-c', `printf '%s' "${ext}" > ${name}.ext`], { cwd: dir });
      ossl('x509', '-req', '-in', `${name}.csr`, '-CA', `${ca}.pem`, '-CAkey', `${ca}.key`, '-CAcreateserial', '-out', `${name}.pem`, '-days', '2', '-extfile', `${name}.ext`);
    };
    leaf('server', 'subjectAltName=IP:127.0.0.1');
    leaf('client', 'extendedKeyUsage=clientAuth');
    ossl('req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-keyout', 'rogue-ca.key', '-out', 'rogue-ca.pem', '-days', '2', '-subj', '/CN=Rogue CA');
    leaf('stranger', 'extendedKeyUsage=clientAuth', 'rogue-ca');
    const f = (n: string) => readFileSync(join(dir, n));
    pki = {
      ca: f('ca.pem'), serverCert: f('server.pem'), serverKey: f('server.key'), clientCert: f('client.pem'), clientKey: f('client.key'),
      strangerCert: f('stranger.pem'), strangerKey: f('stranger.key'),
    };
  });

  async function tlsPsp(): Promise<{ psp: MockPsp; port: number }> {
    const psp = new MockPsp();
    const server = createHttpsServer({ key: pki.serverKey, cert: pki.serverCert, ca: pki.ca, requestCert: true, rejectUnauthorized: true },
      (rq, rs) => void psp.handler(rq, rs));
    return { psp, port: await listen(server) };
  }

  it('authenticates every call, the token request included, with the PSP-issued client certificate', async () => {
    const { psp, port } = await tlsPsp();
    psp.pix.push({ endToEndId: E2E(1), valor: '1.00', horario: new Date().toISOString() });
    const client = new ApiPixClient({
      baseUrl: `https://127.0.0.1:${port}/api/v2`, tokenUrl: `https://127.0.0.1:${port}/oauth/token`,
      clientId: 'client-id', clientSecret: 'client-secret', tls: { cert: pki.clientCert, key: pki.clientKey, ca: pki.ca },
    });
    const got = await new ApiPixReceiver(client).listIncoming({ since: 0n });
    expect(got).toHaveLength(1);
    expect(psp.requests.map((r) => r.clientCert)).toEqual([true, true]);
  });

  it('cannot reach the PSP without a certificate, or with one the PSP did not issue', async () => {
    const { port } = await tlsPsp();
    const base = { baseUrl: `https://127.0.0.1:${port}/api/v2`, tokenUrl: `https://127.0.0.1:${port}/oauth/token`, clientId: 'client-id', clientSecret: 'client-secret' };
    // Trusts the PSP's CA, so the only thing missing is the client's own certificate.
    const noCert = new ApiPixClient({ ...base, tls: { ca: pki.ca } as never });
    const refused = /certificate|alert|ECONNRESET|socket hang up/i;
    await expect(noCert.listPix({ inicio: new Date(0), fim: new Date() })).rejects.toThrow(refused);
    const stranger = new ApiPixClient({ ...base, tls: { cert: pki.strangerCert, key: pki.strangerKey, ca: pki.ca } });
    await expect(stranger.listPix({ inicio: new Date(0), fim: new Date() })).rejects.toThrow(refused);
    // And the same client, with the certificate the PSP issued, gets through.
    const good = new ApiPixClient({ ...base, tls: { cert: pki.clientCert, key: pki.clientKey, ca: pki.ca } });
    await expect(good.listPix({ inicio: new Date(0), fim: new Date() })).resolves.toEqual([]);
  });
});
