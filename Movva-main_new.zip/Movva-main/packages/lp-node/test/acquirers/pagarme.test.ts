import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import {
  PAGARME_METADATA_KEY, PAGARME_SANDBOX_URL, PagarmeAcquirer, PagarmeError, createCardAcquirer, pagarmeChargeStatus, pagarmeOrderCode,
  type PagarmeOrder,
} from '../../src/acquirers/pagarme.js';
import { MockPagarme, type RecordedRequest } from './pagarme-mock.js';

/**
 * The Pagar.me adapter against a mock of API v5 built from what was read (pagarme-mock.ts): the rules card.ts
 * sets for every acquirer, the crash and lost-response cases the node survives, and every request checked
 * against the documented schema (pagarme-v5-schema.json).
 */

const REF = `0x${'ab12'.repeat(16)}` as const;
const OTHER = `0x${'ab12'.repeat(13)}${'cd34'.repeat(3)}` as const; // same first 52 hex digits as REF
const T0 = Date.parse('2026-09-14T12:00:00Z');

let clock = T0;
let mock: MockPagarme;
let baseUrl: string;

beforeEach(async () => {
  clock = T0;
  mock = new MockPagarme(() => clock);
  baseUrl = await mock.listen();
});
afterEach(async () => mock.close());

const adapter = (o: Partial<ConstructorParameters<typeof PagarmeAcquirer>[0]> = {}) => new PagarmeAcquirer({
  baseUrl, secretKey: mock.secretKey, acquirerId: '18727053000174', merchantId: 'acc_mova_partner', customerId: 'cus_mova_partner',
  successUrl: 'https://lp.example/card/done', now: () => BigInt(Math.floor(clock / 1000)), ...o,
});
const nowS = () => BigInt(Math.floor(clock / 1000));
const req = (o: Partial<{ idempotencyKey: string; amountCents: bigint; expiresAt: bigint; reference: string }> = {}) => ({
  idempotencyKey: `C${'1'.repeat(32)}`, amountCents: 10_250n, expiresAt: nowS() + 25n * 60n, reference: REF, ...o,
});
const count = (method: string, path: RegExp) => mock.requests.filter((r) => r.method === method && path.test(r.path)).length;

describe('checkout: one per key, exactly its amount, until it expires', () => {
  it('a repeated createCheckout returns the same order and link, and Pagar.me holds one order', async () => {
    const a = adapter();
    const first = await a.createCheckout(req());
    const again = await a.createCheckout(req());
    expect(again).toEqual(first);
    expect(first).toMatchObject({ checkoutId: expect.stringMatching(/^or_/), amountCents: 10_250n, reference: REF });
    expect(first.url).toMatch(/^https:\/\//);
    expect(mock.ordersWithCode(pagarmeOrderCode(REF))).toHaveLength(1);
    expect(count('POST', /^\/orders$/)).toBe(1);
  });

  it('crash: Pagar.me creates the order and the response is lost; a fresh adapter under the same key gets that order, not a second', async () => {
    mock.loseNextResponse('POST /orders');
    await expect(adapter().createCheckout(req())).rejects.toThrow(/Pagar.me createOrder/);
    expect(mock.orders.size).toBe(1); // it happened
    const restarted = adapter();
    const c = await restarted.createCheckout(req());
    expect(c.checkoutId).toBe([...mock.orders.keys()][0]);
    expect(mock.orders.size).toBe(1);
    expect(count('POST', /^\/orders$/)).toBe(1); // found by code before posting
  });

  it('even without the lookup, the same Idempotency-Key replays the first order (the docs\' guarantee)', async () => {
    const a = adapter();
    const first = await a.createCheckout(req());
    mock.orders.get(first.checkoutId)!.code = 'renamed-so-the-lookup-misses';
    const again = await a.createCheckout(req());
    expect(again.checkoutId).toBe(first.checkoutId);
    expect(mock.orders.size).toBe(1);
  });

  it('a request while the first under its key is in flight is a retryable 409, and creates nothing', async () => {
    mock.markInFlight(req().idempotencyKey);
    const e = await adapter().createCheckout(req()).catch((x: unknown) => x);
    expect(e).toBeInstanceOf(PagarmeError);
    expect(e).toMatchObject({ status: 409, retryable: true });
    expect(mock.orders.size).toBe(0);
  });

  it('charges exactly the total: one item, one payment, credit card only, captured, one installment at the total', async () => {
    await adapter().createCheckout(req({ amountCents: 123_457n }));
    const body = mock.requests.find((r) => r.method === 'POST')!.body as Record<string, any>;
    expect(body.items).toEqual([{ amount: 123_457, description: 'Mova on-ramp order', quantity: 1, code: pagarmeOrderCode(REF) }]);
    expect(body.payments).toHaveLength(1);
    expect(body.payments[0]).toMatchObject({ payment_method: 'checkout', amount: 123_457 });
    expect(body.payments[0].checkout).toMatchObject({
      accepted_payment_methods: ['credit_card'], customer_editable: true,
      credit_card: { capture: true, installments: [{ number: 1, total: 123_457 }] },
    });
    // The cardholder cannot choose two installments, or pay another amount.
    const [order] = mock.orders.values();
    expect(() => mock.pay(order.id, { installments: 2 })).toThrow(/installments/);
    expect(() => mock.pay(order.id, { amount: 123_000 })).toThrow(/amount/);
  });

  it('refuses, and closes, a checkout Pagar.me echoes with installment options other than one at the total', async () => {
    const a = adapter();
    const c = await a.createCheckout(req());
    mock.orders.get(c.checkoutId)!.checkouts![0].credit_card = { installments: [{ number: 1, total: 10_250 }, { number: 3, total: 10_900 }] };
    await expect(a.createCheckout(req())).rejects.toThrow(/installments other than one/);
    expect(mock.orders.get(c.checkoutId)!.status).toBe('canceled');
  });

  it('carries the reference: code is the order id\'s first 52 hex digits, metadata the whole id', async () => {
    await adapter().createCheckout(req());
    const body = mock.requests.find((r) => r.method === 'POST')!.body as Record<string, any>;
    expect(body.code).toBe(REF.slice(2, 54));
    expect(body.code).toHaveLength(52);
    expect(body.metadata).toEqual({ [PAGARME_METADATA_KEY]: REF });
    expect(() => pagarmeOrderCode('ORDER-1')).toThrow(/order id/);
  });

  it('expiry: whole minutes rounded down, never after the requested time, and under a minute is refused', async () => {
    const a = adapter();
    const expiresAt = nowS() + 25n * 60n + 59n;
    const c = await a.createCheckout(req({ expiresAt }));
    const body = mock.requests.find((r) => r.method === 'POST')!.body as Record<string, any>;
    expect(body.payments[0].checkout.expires_in).toBe(25);
    expect(c.expiresAt).toBeLessThanOrEqual(expiresAt);
    expect(c.expiresAt).toBe(nowS() + 25n * 60n);
    await expect(adapter().createCheckout(req({ idempotencyKey: `C${'2'.repeat(32)}`, reference: `0x${'9'.repeat(64)}`, expiresAt: nowS() + 59n })))
      .rejects.toThrow(/whole minute/);
    // Pagar.me honours it here; the next test is the case where it does not.
    clock += 26 * 60_000;
    expect(() => mock.pay(c.checkoutId)).toThrow(/expired/);
  });

  it('a capture Pagar.me let through after the checkout expired is refunded by the adapter, once, and reported so', async () => {
    const a = adapter();
    const c = await a.createCheckout(req());
    clock += 26 * 60_000;
    const late = mock.pay(c.checkoutId, { misbehave: true });
    const [charge] = await a.chargesFor(REF);
    expect(charge).toMatchObject({ transactionId: late.id, status: 'REFUNDED' });
    await a.chargesFor(REF);
    await adapter().chargesFor(REF);
    expect(mock.refundsApplied.get(late.id)).toBe(1);
    expect(count('DELETE', /^\/charges\//)).toBe(1);
  });

  it('cancelCheckout closes the order, a second cancel is harmless, and the checkout takes no charge after', async () => {
    const a = adapter();
    const c = await a.createCheckout(req());
    await a.cancelCheckout(c.checkoutId);
    await a.cancelCheckout(c.checkoutId);
    await adapter().cancelCheckout('or_does_not_exist');
    expect(mock.orders.get(c.checkoutId)).toMatchObject({ closed: true, status: 'canceled' });
    expect(count('PATCH', /\/closed$/)).toBe(1);
    expect(() => mock.pay(c.checkoutId)).toThrow(/closed/);
  });
});

describe('charges: by reference, in Pagar.me\'s statuses', () => {
  it('maps paid, authorised, voided, refunded and charged back; skips what holds no money; throws on what it does not know', async () => {
    const a = adapter();
    const c = await a.createCheckout(req());
    const paid = mock.pay(c.checkoutId, { cardId: 'card_abc' });
    const held = mock.pay(c.checkoutId, { capture: false });
    const back = mock.pay(c.checkoutId);
    mock.chargeback(back.id);
    mock.addCharge(c.checkoutId, { status: 'failed', amount: 10_250, payment_method: 'credit_card', last_transaction: { status: 'not_authorized' } });
    mock.addCharge(c.checkoutId, { status: 'processing', amount: 10_250, payment_method: 'credit_card' });

    const charges = await a.chargesFor(REF);
    expect(charges).toHaveLength(3);
    expect(charges.find((x) => x.transactionId === paid.id)).toEqual({
      acquirerId: '18727053000174', transactionId: paid.id, merchantId: 'acc_mova_partner', reference: REF, status: 'CAPTURED',
      amountCents: 10_250n, authorizedAt: nowS(), capturedAt: nowS(), payerId: 'card_abc',
    });
    expect(charges.find((x) => x.transactionId === held.id)).toMatchObject({ status: 'AUTHORIZED', capturedAt: undefined });
    expect(charges.find((x) => x.transactionId === back.id)).toMatchObject({ status: 'CHARGED_BACK' });

    await a.reverse({ idempotencyKey: `V${'1'.repeat(32)}`, transactionId: held.id, amountCents: 10_250n, reason: 'r' });
    await a.reverse({ idempotencyKey: `V${'2'.repeat(32)}`, transactionId: paid.id, amountCents: 10_250n, reason: 'r' });
    const after = await a.chargesFor(REF);
    expect(after.find((x) => x.transactionId === held.id)?.status).toBe('VOIDED');
    expect(after.find((x) => x.transactionId === paid.id)?.status).toBe('REFUNDED');

    mock.addCharge(c.checkoutId, { status: 'mystery', amount: 1, payment_method: 'credit_card' });
    await expect(a.chargesFor(REF)).rejects.toThrow(/not one this adapter knows/);
  });

  it('the status table itself', () => {
    const s = (status: string, tx?: string, paid_at?: string) => pagarmeChargeStatus({ status, paid_at, last_transaction: tx ? { status: tx } : undefined });
    expect(s('paid', 'captured')).toBe('CAPTURED');
    expect(s('underpaid')).toBe('CAPTURED');
    expect(s('overpaid')).toBe('CAPTURED');
    expect(s('pending', 'authorized_pending_capture')).toBe('AUTHORIZED');
    expect(s('pending', 'waiting_capture')).toBe('AUTHORIZED');
    expect(s('pending')).toBeUndefined();
    expect(s('processing')).toBeUndefined();
    expect(s('failed', 'not_authorized')).toBeUndefined();
    expect(s('canceled', 'voided')).toBe('VOIDED');
    expect(s('canceled', 'partial_void')).toBe('VOIDED');
    expect(s('canceled', 'refunded')).toBe('REFUNDED');
    expect(s('canceled', 'partial_refunded')).toBe('REFUNDED');
    expect(s('canceled', undefined, '2026-09-14T12:00:00Z')).toBe('REFUNDED');
    expect(s('canceled')).toBe('VOIDED');
    expect(s('chargedback', 'chargedback')).toBe('CHARGED_BACK');
  });

  it('a charge of another payment method under the reference is thrown for a human, not silently kept', async () => {
    const a = adapter();
    const c = await a.createCheckout(req());
    mock.addCharge(c.checkoutId, { status: 'paid', amount: 10_250, payment_method: 'pix' });
    await expect(a.chargesFor(REF)).rejects.toThrow(/pix charge carries an order's reference/);
  });

  it('follows every page, and an order with the same code that names another order in its metadata is not this one\'s', async () => {
    mock.pageSizeCap = 2;
    const a = adapter({ pageSize: 2 });
    const mine = await a.createCheckout(req());
    mock.pay(mine.checkoutId);
    for (let i = 0; i < 4; i++) {
      const id = `or_other${i}`;
      const o: PagarmeOrder = {
        id, code: pagarmeOrderCode(REF), amount: 10_250, status: 'pending', closed: false, created_at: new Date(clock + i).toISOString(),
        metadata: { [PAGARME_METADATA_KEY]: OTHER }, charges: [], checkouts: [{ id: `chk_o${i}`, payment_url: 'https://x', expires_at: new Date(clock + 3_600_000).toISOString() }],
      };
      mock.orders.set(id, o);
      mock.pay(id, { misbehave: true });
    }
    const charges = await a.chargesFor(REF);
    expect(count('GET', /^\/orders$/)).toBeGreaterThanOrEqual(3);
    expect(charges).toHaveLength(1);
    expect(charges[0].reference).toBe(REF);
    expect(await a.chargesFor(OTHER)).toHaveLength(4);
    expect(await a.chargesFor(`0x${'0'.repeat(64)}`)).toEqual([]);
  });
});

describe('reversal: the whole charge, once', () => {
  const key = `V${'a'.repeat(32)}`;

  it('a repeated reverse under one key moves money once and returns the first result', async () => {
    const a = adapter();
    const c = await a.createCheckout(req());
    const ch = mock.pay(c.checkoutId);
    const first = await a.reverse({ idempotencyKey: key, transactionId: ch.id, amountCents: 10_250n, reason: 'order expired' });
    const second = await a.reverse({ idempotencyKey: key, transactionId: ch.id, amountCents: 10_250n, reason: 'order expired' });
    expect(first).toMatchObject({ status: 'SETTLED', kind: 'REFUND', amountCents: 10_250n, transactionId: ch.id, idempotencyKey: key });
    expect(second).toEqual(first);
    expect(await a.getReversal(key)).toEqual(first);
    expect(mock.refundsApplied.get(ch.id)).toBe(1);
    const del = mock.requests.find((r) => r.method === 'DELETE')!;
    expect(del.headers['idempotency-key']).toBe(key);
    expect(del.body).toEqual({ amount: 10_250 });
  });

  it('crash: the refund moves and its response is lost; after a restart getReversal knows nothing and the repeat sends no second DELETE', async () => {
    const c = await adapter().createCheckout(req());
    const ch = mock.pay(c.checkoutId);
    mock.loseNextResponse('DELETE /charges/{id}');
    await expect(adapter().reverse({ idempotencyKey: key, transactionId: ch.id, amountCents: 10_250n, reason: 'r' })).rejects.toThrow(/cancelCharge/);
    expect(mock.refundsApplied.get(ch.id)).toBe(1);

    const restarted = adapter();
    expect(await restarted.getReversal(key)).toBeUndefined();
    const r = await restarted.reverse({ idempotencyKey: key, transactionId: ch.id, amountCents: 10_250n, reason: 'r' });
    expect(r).toMatchObject({ status: 'SETTLED', kind: 'REFUND' });
    expect(mock.refundsApplied.get(ch.id)).toBe(1);
    expect(count('DELETE', /^\/charges\//)).toBe(1);
  });

  it('a refund Pagar.me holds as pending_refund is PENDING, is not sent again, and settles', async () => {
    const a = adapter();
    const c = await a.createCheckout(req());
    const ch = mock.pay(c.checkoutId);
    mock.holdNextRefund();
    expect(await a.reverse({ idempotencyKey: key, transactionId: ch.id, amountCents: 10_250n, reason: 'r' })).toMatchObject({ status: 'PENDING' });
    expect(await a.reverse({ idempotencyKey: key, transactionId: ch.id, amountCents: 10_250n, reason: 'r' })).toMatchObject({ status: 'PENDING' });
    expect((await a.chargesFor(REF))[0].status).toBe('CAPTURED'); // money not back yet
    mock.settleRefunds();
    expect(await a.getReversal(key)).toMatchObject({ status: 'SETTLED', kind: 'REFUND' });
    expect(mock.refundsApplied.get(ch.id)).toBe(1);
  });

  it('an authorisation is voided', async () => {
    const a = adapter();
    const c = await a.createCheckout(req());
    const ch = mock.pay(c.checkoutId, { capture: false });
    expect(await a.reverse({ idempotencyKey: key, transactionId: ch.id, amountCents: 10_250n, reason: 'r' })).toMatchObject({ status: 'SETTLED', kind: 'VOID' });
  });

  it('refuses, as FAILED and without moving money: another amount, a charged-back or failed charge, a charge that does not exist, a 422', async () => {
    const a = adapter();
    const c = await a.createCheckout(req());
    const ch = mock.pay(c.checkoutId);
    const back = mock.pay(c.checkoutId);
    mock.chargeback(back.id);
    const r = (k: string, id: string, amount = 10_250n) => a.reverse({ idempotencyKey: k, transactionId: id, amountCents: amount, reason: 'r' });
    expect(await r('V1', ch.id, 10_000n)).toMatchObject({ status: 'FAILED', failureReason: 'a reversal is for the whole charge' });
    expect(await r('V2', back.id)).toMatchObject({ status: 'FAILED', failureReason: 'the charge is CHARGED_BACK' });
    expect(await r('V3', 'ch_nope')).toMatchObject({ status: 'FAILED', failureReason: 'no such charge at Pagar.me' });
    mock.failNext(422, 'DELETE /charges/{id}');
    expect(await r('V4', ch.id)).toMatchObject({ status: 'FAILED', failureReason: 'Pagar.me refused the cancellation (HTTP 422)' });
    expect(mock.refundsApplied.size).toBe(0);
  });

  it('429, 5xx and 401 throw instead of reporting an outcome, and move nothing; the retry under the same key moves money once', async () => {
    const a = adapter();
    const c = await a.createCheckout(req());
    const ch = mock.pay(c.checkoutId);
    const rev = () => a.reverse({ idempotencyKey: key, transactionId: ch.id, amountCents: 10_250n, reason: 'r' });
    mock.rateLimitNext('DELETE /charges/{id}');
    await expect(rev()).rejects.toMatchObject({ status: 429, retryable: true });
    mock.failNext(503, 'DELETE /charges/{id}');
    await expect(rev()).rejects.toMatchObject({ status: 503, retryable: true });
    expect(mock.refundsApplied.size).toBe(0);
    const wrong = adapter({ secretKey: 'sk_test_wrongwrongwrong' });
    await expect(wrong.reverse({ idempotencyKey: key, transactionId: ch.id, amountCents: 10_250n, reason: 'r' })).rejects.toMatchObject({ status: 401, retryable: false });
    expect(await rev()).toMatchObject({ status: 'SETTLED' });
    expect(mock.refundsApplied.get(ch.id)).toBe(1);
  });
});

describe('errors, secrets and the documented schema', () => {
  it('an auth failure says so with the HTTP status only: no key, no response body', async () => {
    const e = await adapter({ secretKey: 'sk_test_leakme0123456789' }).createCheckout(req()).then(() => new Error('resolved'), (x: unknown) => x as Error);
    expect(e).toBeInstanceOf(PagarmeError);
    expect(e.message).toBe('Pagar.me listOrders: HTTP 401');
    expect(e.message).not.toMatch(/leakme|denied/);
  });

  it('a transport error is redacted of the key, and a list 429 throws before anything is created', async () => {
    const dead = adapter({ baseUrl: 'http://127.0.0.1:9/core/v5', secretKey: 'sk_test_leakme0123456789' });
    const e = await dead.chargesFor(REF).then(() => new Error('resolved'), (x: unknown) => x as Error);
    expect(e.message).toMatch(/^Pagar.me listOrders:/);
    expect(e.message).not.toContain('leakme');
    mock.rateLimitNext('GET /orders');
    await expect(adapter().createCheckout(req())).rejects.toMatchObject({ status: 429 });
    expect(mock.orders.size).toBe(0);
  });

  it('every request the adapter makes matches the documented v5 operations, headers and bodies', async () => {
    const a = adapter({ statementDescriptor: 'MOVA' });
    const c = await a.createCheckout(req());
    await a.createCheckout(req());
    const ch = mock.pay(c.checkoutId);
    await a.chargesFor(REF);
    await a.reverse({ idempotencyKey: `V${'b'.repeat(32)}`, transactionId: ch.id, amountCents: 10_250n, reason: 'r' });
    await a.getReversal(`V${'b'.repeat(32)}`);
    await a.cancelCheckout(c.checkoutId);
    const problems = mock.requests.flatMap(checkRequest);
    expect(problems).toEqual([]);
    const ops = new Set(mock.requests.map((r) => operationOf(r)?.[0]));
    expect([...ops].sort()).toEqual(['cancelCharge', 'closeOrder', 'createOrder', 'getCharge', 'getOrder', 'listOrders']);
  });

  it('the schema check catches what it should: an undocumented field, a wrong type, an over-long code, a missing key', () => {
    const base = { method: 'POST', path: '/orders', query: new URLSearchParams(), headers: { authorization: 'Basic x', 'content-type': 'application/json', 'idempotency-key': 'C1' } };
    const good = { code: 'a', customer_id: 'cus', items: [{ amount: 1, description: 'd', quantity: 1 }], payments: [{ payment_method: 'checkout' }] };
    expect(checkRequest({ ...base, body: good })).toEqual([]);
    expect(checkRequest({ ...base, body: { ...good, reference: 'x' } }).join()).toMatch(/reference is not documented/);
    expect(checkRequest({ ...base, body: { ...good, items: [{ amount: '1', description: 'd', quantity: 1 }] } }).join()).toMatch(/items\[0\].amount/);
    expect(checkRequest({ ...base, body: { ...good, code: 'x'.repeat(53) } }).join()).toMatch(/code is longer than 52/);
    expect(checkRequest({ ...base, headers: { authorization: 'Basic x', 'content-type': 'application/json' }, body: good }).join()).toMatch(/idempotency-key/);
  });
});

describe('createCardAcquirer(env): the ACQUIRER_MODULE entry', () => {
  const files: Record<string, string> = { '/run/secrets/pagarme': 'sk_live0123456789abcdef\n', '/run/secrets/pagarme_test': 'sk_test_0123456789abcdef' };
  const read = (p: string) => {
    if (!(p in files)) throw new Error('ENOENT');
    return files[p];
  };
  const env = {
    PAGARME_SECRET_KEY_FILE: '/run/secrets/pagarme', PAGARME_ACQUIRER_ID: '18727053000174', PAGARME_MERCHANT_ID: 'acc_mova_partner',
    PAGARME_CUSTOMER_ID: 'cus_mova_partner', PAGARME_SUCCESS_URL: 'https://lp.example/card/done',
  };

  it('builds from *_FILE secrets, with the ids the node checks against onramp.card', () => {
    const a = createCardAcquirer(env, read);
    expect(a).toBeInstanceOf(PagarmeAcquirer);
    expect([a.acquirerId, a.merchantId]).toEqual(['18727053000174', 'acc_mova_partner']);
  });

  it('refuses a key in the environment, a missing or unreadable file, missing ids, a test key without LP_NODE_DEV, a live key on the sandbox host, plain http; never echoing the key', () => {
    const msg = (e: Record<string, string | undefined>) => { try { createCardAcquirer(e, read); return ''; } catch (x) { return (x as Error).message; } };
    expect(msg({ ...env, PAGARME_SECRET_KEY: 'sk_live0123456789abcdef' })).toMatch(/never PAGARME_SECRET_KEY/);
    expect(msg({ ...env, PAGARME_SECRET_KEY_FILE: undefined })).toMatch(/PAGARME_SECRET_KEY_FILE is required/);
    expect(msg({ ...env, PAGARME_SECRET_KEY_FILE: '/nope' })).toMatch(/could not be read/);
    expect(msg({ ...env, PAGARME_MERCHANT_ID: undefined, PAGARME_CUSTOMER_ID: '' })).toMatch(/PAGARME_MERCHANT_ID is required; PAGARME_CUSTOMER_ID is required/);
    expect(msg({ ...env, PAGARME_SECRET_KEY_FILE: '/run/secrets/pagarme_test' })).toMatch(/sk_test_ key is refused without LP_NODE_DEV=1/);
    expect(msg({ ...env, PAGARME_SECRET_KEY_FILE: '/run/secrets/pagarme_test', LP_NODE_DEV: '1' })).toBe('');
    expect(msg({ ...env, PAGARME_BASE_URL: PAGARME_SANDBOX_URL })).toMatch(/live key on the sandbox host/);
    expect(msg({ ...env, PAGARME_BASE_URL: 'http://api.pagar.me/core/v5' })).toMatch(/must be https/);
    const all = [msg({ ...env, PAGARME_SECRET_KEY: 'sk_live0123456789abcdef' }), msg({ ...env, PAGARME_BASE_URL: PAGARME_SANDBOX_URL })].join();
    expect(all).not.toContain('0123456789abcdef');
  });

  it('loads through a dynamic import of its path, as the node loads ACQUIRER_MODULE', async () => {
    const mod = await import(new URL('../../src/acquirers/pagarme.ts', import.meta.url).href) as Record<string, unknown>;
    expect(typeof mod.createCardAcquirer).toBe('function');
    const a = (mod.createCardAcquirer as typeof createCardAcquirer)(env, read);
    expect(a.acquirerId).toBe('18727053000174');
  });
});

/*//////////////////////////////////////////////////////////////
                      THE DOCUMENTED SCHEMA, CHECKED
//////////////////////////////////////////////////////////////*/

interface Prop { type: string; items?: string; schema?: string; maxLength?: number; minimum?: number; values?: string }
interface Obj { type: 'object'; required?: string[]; properties: Record<string, Prop> }
interface Op { method: string; path: string; idempotencyKey?: boolean | 'optional'; body?: string; query?: Record<string, string> }
const SCHEMA = JSON.parse(readFileSync(new URL('./pagarme-v5-schema.json', import.meta.url), 'utf8')) as { operations: Record<string, Op>; schemas: Record<string, Obj> };

function operationOf(r: Pick<RecordedRequest, 'method' | 'path'>): [string, Op] | undefined {
  return Object.entries(SCHEMA.operations).find(([, op]) =>
    op.method === r.method && new RegExp(`^${op.path.replace(/\{[a-z_]+\}/g, '[^/]+')}$`).test(r.path));
}

function typeOk(v: unknown, t: string): boolean {
  switch (t) {
    case 'string': return typeof v === 'string';
    case 'integer': return Number.isSafeInteger(v);
    case 'boolean': return typeof v === 'boolean';
    case 'array': return Array.isArray(v);
    case 'object': return typeof v === 'object' && v !== null && !Array.isArray(v);
    default: return false;
  }
}

function checkObject(v: unknown, name: string, at: string, out: string[]): void {
  const s = SCHEMA.schemas[name];
  if (!typeOk(v, 'object')) {
    out.push(`${at} is not an object`);
    return;
  }
  const o = v as Record<string, unknown>;
  for (const r of s.required ?? []) if (o[r] === undefined) out.push(`${at}.${r} is missing`);
  for (const [k, val] of Object.entries(o)) {
    const p = s.properties[k];
    const where = `${at}.${k}`;
    if (!p) {
      out.push(`${where.replace(/^body\./, '')} is not documented in ${name}`);
      continue;
    }
    if (!typeOk(val, p.type)) {
      out.push(`${where} is not ${p.type}`);
      continue;
    }
    if (p.maxLength !== undefined && (val as string).length > p.maxLength) out.push(`${where.replace(/^body\./, '')} is longer than ${p.maxLength}`);
    if (p.minimum !== undefined && (val as number) < p.minimum) out.push(`${where} is below ${p.minimum}`);
    if (p.values) for (const [mk, mv] of Object.entries(val as object)) if (!typeOk(mv, p.values)) out.push(`${where}.${mk} is not ${p.values}`);
    if (p.schema) checkObject(val, p.schema, where, out);
    if (p.items) {
      (val as unknown[]).forEach((item, i) => {
        if (SCHEMA.schemas[p.items!]) checkObject(item, p.items!, `${where}[${i}]`, out);
        else if (!typeOk(item, p.items!)) out.push(`${where}[${i}] is not ${p.items}`);
      });
    }
  }
}

function checkRequest(r: Pick<RecordedRequest, 'method' | 'path' | 'query' | 'headers' | 'body'>): string[] {
  const out: string[] = [];
  const found = operationOf(r);
  if (!found) return [`${r.method} ${r.path} is not a documented operation`];
  const [name, op] = found;
  if (!/^Basic [A-Za-z0-9+/=]+$/.test(String(r.headers.authorization))) out.push(`${name}: authorization is not HTTP Basic`);
  if (op.idempotencyKey === true && !r.headers['idempotency-key']) out.push(`${name}: no idempotency-key header`);
  if (!op.idempotencyKey && r.headers['idempotency-key']) out.push(`${name}: an idempotency-key the operation does not take`);
  for (const [k, v] of r.query) {
    const t = op.query?.[k];
    if (!t) out.push(`${name}: query ${k} is not documented`);
    else if (t === 'integer' && !/^\d+$/.test(v)) out.push(`${name}: query ${k} is not an integer`);
  }
  if (op.body) {
    if (!String(r.headers['content-type']).startsWith('application/json')) out.push(`${name}: body is not application/json`);
    checkObject(r.body, op.body, 'body', out);
  } else if (r.body !== undefined) {
    out.push(`${name}: a body the operation does not take`);
  }
  return out.map((p) => (p.startsWith(name) ? p : `${name}: ${p}`));
}
