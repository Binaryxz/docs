/**
 * Pagar.me API v5 in memory, over HTTP, as far as it was read (see src/acquirers/pagarme.ts and
 * pagarme-v5-schema.json): Basic auth with the secret key, `POST|GET /orders`, `GET /orders/{id}`,
 * `PATCH /orders/{id}/closed`, `GET|DELETE /charges/{id}`, `Idempotency-Key` replays for 24 h and 409 while the
 * first request is in flight, `{ data, paging: { total, previous, next } }` lists, `{ "message": ... }` errors
 * (401 "Authorization has been denied for this request.", 404 "Customer not found." without a customer).
 *
 * What is not in the reading is marked in the code, and the cardholder, the issuer and a flaky network are
 * methods: `pay`, `chargeback`, `settleRefunds`, `loseNextResponse`, `rateLimitNext`, `failNext`, `holdNextRefund`.
 * Every request is recorded, headers and parsed body, for the schema test.
 */
import { createServer, type IncomingHttpHeaders, type IncomingMessage, type Server, type ServerResponse } from 'node:http';
import type { AddressInfo } from 'node:net';
import type { PagarmeCharge, PagarmeOrder } from '../../src/acquirers/pagarme.js';

export interface RecordedRequest {
  method: string; path: string; query: URLSearchParams; headers: IncomingHttpHeaders; body?: unknown;
}

const DAY_MS = 24 * 3600 * 1000;

export class MockPagarme {
  readonly requests: RecordedRequest[] = [];
  readonly orders = new Map<string, PagarmeOrder>();
  readonly charges = new Map<string, PagarmeCharge>();
  /** DELETEs that moved money: the no-double-refund assertion counts these. */
  readonly refundsApplied = new Map<string, number>();
  readonly customers = new Set(['cus_mova_partner']);
  secretKey = 'sk_test_mova0123456789';
  /** Pagar.me checks nothing about payments on an expired checkout when true (the case the adapter guards). */
  honourExpiry = true;
  pageSizeCap = 30;
  private seq = 0;
  private readonly idem = new Map<string, { at: number; status: number; body: unknown } | 'in-flight'>();
  private readonly faults: ({ kind: 'lose' | 'rate' | 'hold-refund'; route?: string } | { kind: 'fail'; status: number; route?: string })[] = [];
  private server?: Server;

  constructor(readonly now: () => number = () => Date.now()) {}

  /*---------------------------- the outside ----------------------------*/

  /** A cardholder pays an order's checkout. `capture: false` leaves an authorisation. */
  pay(orderId: string, o: { amount?: number; capture?: boolean; installments?: number; cardId?: string; misbehave?: boolean } = {}): PagarmeCharge {
    const order = this.orders.get(orderId);
    const checkout = order?.checkouts?.[0];
    if (!order || !checkout) throw new Error('no such checkout');
    if (order.status === 'canceled') throw new Error('checkout closed');
    if (this.honourExpiry && !o.misbehave && this.now() > Date.parse(checkout.expires_at!)) throw new Error('checkout expired');
    const options = checkout.credit_card?.installments ?? [];
    const installments = o.installments ?? 1;
    if (!o.misbehave && options.length && !options.some((x) => x.number === installments)) throw new Error('installments not offered');
    const amount = o.amount ?? order.amount!;
    if (amount !== order.amount && !o.misbehave) throw new Error('a checkout charges its amount');
    const at = new Date(this.now()).toISOString();
    const capture = o.capture ?? true;
    const charge: PagarmeCharge = {
      id: `ch_${(++this.seq).toString(36).padStart(16, '0')}`, code: order.code, amount, status: capture ? 'paid' : 'pending',
      payment_method: 'credit_card', created_at: at, ...(capture ? { paid_at: at, paid_amount: amount } : {}),
      last_transaction: {
        id: `tran_${this.seq}`, transaction_type: 'credit_card', status: capture ? 'captured' : 'authorized_pending_capture',
        amount, created_at: at, installments, acquirer_name: 'simulator', acquirer_tid: `${this.seq}`.padStart(12, '0'),
        acquirer_nsu: `${this.seq}`.padStart(6, '0'), card: { id: o.cardId ?? 'card_holder0001' },
      },
    };
    this.charges.set(charge.id, charge);
    order.charges = [...(order.charges ?? []), charge];
    if (capture) order.status = 'paid';
    return structuredClone(charge);
  }

  /** A charge of any payment method on an order, as a misconfigured checkout could take. */
  addCharge(orderId: string, c: Partial<PagarmeCharge>): PagarmeCharge {
    const order = this.orders.get(orderId)!;
    const charge: PagarmeCharge = { id: `ch_${(++this.seq).toString(36).padStart(16, '0')}`, code: order.code, created_at: new Date(this.now()).toISOString(), ...c };
    this.charges.set(charge.id, charge);
    order.charges = [...(order.charges ?? []), charge];
    return charge;
  }

  chargeback(chargeId: string): void {
    this.charges.get(chargeId)!.status = 'chargedback';
    this.charges.get(chargeId)!.last_transaction!.status = 'chargedback';
  }

  /** Refunds held as `pending_refund` complete. */
  settleRefunds(): void {
    for (const c of this.charges.values()) {
      if (c.last_transaction?.status === 'pending_refund') this.cancel(c, true);
    }
  }

  loseNextResponse(route?: string): void { this.faults.push({ kind: 'lose', route }); }
  rateLimitNext(route?: string): void { this.faults.push({ kind: 'rate', route }); }
  failNext(status: number, route?: string): void { this.faults.push({ kind: 'fail', status, route }); }
  /** The next cancellation is accepted but stays `pending_refund` until `settleRefunds`. */
  holdNextRefund(): void { this.faults.push({ kind: 'hold-refund' }); }

  ordersWithCode(code: string): PagarmeOrder[] {
    return [...this.orders.values()].filter((o) => o.code === code);
  }

  /*------------------------------- server -------------------------------*/

  async listen(): Promise<string> {
    this.server = createServer((rq, rs) => { void this.handle(rq, rs); });
    await new Promise<void>((r) => this.server!.listen(0, '127.0.0.1', () => r()));
    return `http://127.0.0.1:${(this.server.address() as AddressInfo).port}/core/v5`;
  }

  async close(): Promise<void> {
    if (this.server) await new Promise<void>((r) => this.server!.close(() => r()));
  }

  private take(kind: string, route: string): (typeof this.faults)[number] | undefined {
    const i = this.faults.findIndex((f) => f.kind === kind && (!f.route || f.route === route));
    return i < 0 ? undefined : this.faults.splice(i, 1)[0];
  }

  private async handle(rq: IncomingMessage, rs: ServerResponse): Promise<void> {
    const url = new URL(rq.url ?? '/', 'http://pagarme');
    const chunks: Buffer[] = [];
    for await (const c of rq) chunks.push(c as Buffer);
    const raw = Buffer.concat(chunks).toString('utf8');
    let body: unknown;
    try {
      body = raw ? JSON.parse(raw) : undefined;
    } catch {
      body = raw;
    }
    const path = url.pathname.replace(/^\/core\/v5/, '');
    this.requests.push({ method: rq.method ?? '', path, query: url.searchParams, headers: rq.headers, body });
    const route = `${rq.method} ${path.replace(/\/(or|ch)_[a-z0-9]+/g, '/{id}')}`;
    const lose = this.take('lose', route);
    const json = (status: number, b: unknown) => {
      if (lose) {
        rq.socket.destroy(); // the work is done; the response never arrives
        return;
      }
      rs.writeHead(status, { 'content-type': 'application/json' });
      rs.end(JSON.stringify(b));
    };

    if (rq.headers.authorization !== `Basic ${Buffer.from(`${this.secretKey}:`).toString('base64')}`) {
      return json(401, { message: 'Authorization has been denied for this request.' });
    }
    if (this.take('rate', route)) return json(429, { message: 'Too Many Requests' }); // v5 body not published
    const fail = this.take('fail', route) as { status: number } | undefined;
    if (fail) return json(fail.status, { message: 'Internal Server Error' });

    // Idempotency-Key: one key, one result, for 24 h; 409 while the first is still being processed.
    const key = rq.headers['idempotency-key'];
    const idemKey = typeof key === 'string' && (rq.method === 'POST' || rq.method === 'DELETE' || rq.method === 'PATCH') ? `${key}` : undefined;
    if (idemKey) {
      const prior = this.idem.get(idemKey);
      if (prior === 'in-flight') return json(409, { message: 'There is already a request in progress for this idempotency key.' });
      if (prior && this.now() - prior.at < DAY_MS) return json(prior.status, prior.body);
    }
    const reply = (status: number, b: unknown) => {
      if (idemKey && status < 500 && status !== 429) this.idem.set(idemKey, { at: this.now(), status, body: b });
      json(status, b);
    };
    if (idemKey) this.idem.set(idemKey, 'in-flight');
    try {
      this.route(rq.method ?? '', path, url.searchParams, body, reply);
    } finally {
      if (idemKey && this.idem.get(idemKey) === 'in-flight') this.idem.delete(idemKey);
    }
  }

  /** Simulate a second request arriving while the first one under `key` is still being processed. */
  markInFlight(key: string): void { this.idem.set(key, 'in-flight'); }

  private route(method: string, path: string, q: URLSearchParams, body: unknown, reply: (s: number, b: unknown) => void): void {
    let m: RegExpMatchArray | null;
    if (method === 'POST' && path === '/orders') return this.createOrder(body as Record<string, unknown>, reply);
    if (method === 'GET' && path === '/orders') {
      const page = Number(q.get('page') ?? '1');
      const size = Math.min(Number(q.get('size') ?? '10'), this.pageSizeCap);
      const all = [...this.orders.values()].filter((o) => !q.get('code') || o.code === q.get('code'));
      const data = all.slice((page - 1) * size, page * size).map((o) => ({ ...structuredClone(o), charges: undefined, checkouts: undefined }));
      const pages = Math.max(1, Math.ceil(all.length / size));
      return reply(200, {
        data,
        paging: { total: all.length, ...(page > 1 ? { previous: `page=${page - 1}` } : {}), ...(page < pages ? { next: `page=${page + 1}` } : {}) },
      });
    }
    if ((m = path.match(/^\/orders\/([^/]+)$/)) && method === 'GET') {
      const o = this.orders.get(m[1]);
      return o ? reply(200, this.view(o)) : reply(404, { message: 'Order not found.' });
    }
    if ((m = path.match(/^\/orders\/([^/]+)\/closed$/)) && method === 'PATCH') {
      const o = this.orders.get(m[1]);
      if (!o) return reply(404, { message: 'Order not found.' });
      if (o.closed) return reply(412, { message: 'Order already closed.' }); // wording unverified
      o.closed = true;
      o.status = (body as { status?: string })?.status ?? 'canceled';
      for (const c of o.checkouts ?? []) c.status = 'canceled';
      return reply(200, this.view(o));
    }
    if ((m = path.match(/^\/charges\/([^/]+)$/))) {
      const c = this.charges.get(m[1]);
      if (!c) return reply(404, { message: 'Charge not found.' });
      if (method === 'GET') return reply(200, structuredClone(c));
      if (method === 'DELETE') return this.cancelCharge(c, body as { amount?: number } | undefined, reply);
    }
    reply(404, { message: 'Not found' });
  }

  private view(o: PagarmeOrder): PagarmeOrder {
    const v = structuredClone(o);
    v.charges = (o.charges ?? []).map((c) => structuredClone(this.charges.get(c.id)!));
    return v;
  }

  private createOrder(b: Record<string, unknown>, reply: (s: number, b: unknown) => void): void {
    const errors: Record<string, string[]> = {};
    if (typeof b?.code !== 'string' || b.code.length > 52) errors['order.code'] = ['The field code must be a string with a maximum length of 52.'];
    if (!Array.isArray(b?.items) || !b.items.length) errors['order.items'] = ['The items field is required.'];
    if (!Array.isArray(b?.payments) || !b.payments.length) errors['order.payments'] = ['The payments field is required.'];
    // The validation body's `errors` shape is not in what was read; only `message` is.
    if (Object.keys(errors).length) return reply(422, { message: 'The request is invalid.', errors });
    if (!b.customer && !(typeof b.customer_id === 'string' && this.customers.has(b.customer_id))) return reply(404, { message: 'Customer not found.' });
    const payment = (b.payments as Record<string, unknown>[])[0];
    const checkout = payment.checkout as Record<string, unknown>;
    const amount = (b.items as { amount: number; quantity: number }[]).reduce((s, i) => s + i.amount * (i.quantity ?? 1), 0);
    const created = new Date(this.now()).toISOString();
    const id = `or_${(++this.seq).toString(36).padStart(16, '0')}`;
    const order: PagarmeOrder = {
      id, code: b.code as string, amount, status: 'pending', closed: false, created_at: created,
      metadata: (b.metadata as Record<string, string>) ?? null, charges: [],
      checkouts: payment.payment_method === 'checkout' ? [{
        id: `chk_${this.seq}`, amount, status: 'open', created_at: created,
        payment_url: `https://payment-link.pagar.me/pl_${this.seq.toString(36)}`,
        expires_at: new Date(this.now() + Number(checkout.expires_in ?? 60) * 60_000).toISOString(),
        accepted_payment_methods: checkout.accepted_payment_methods as string[],
        credit_card: { installments: (checkout.credit_card as { installments?: { number: number; total: number }[] })?.installments },
      }] : [],
    };
    this.orders.set(id, order);
    reply(200, this.view(order));
  }

  private cancelCharge(c: PagarmeCharge, b: { amount?: number } | undefined, reply: (s: number, b: unknown) => void): void {
    const open = c.status === 'paid' || (c.status === 'pending' && c.last_transaction?.status === 'authorized_pending_capture');
    if (!open) return reply(422, { message: 'Charge cannot be canceled.' }); // wording unverified
    const held = c.status === 'paid' ? c.paid_amount! : c.amount!;
    if (b?.amount !== undefined && b.amount !== held) return reply(422, { message: 'Partial cancellation is not supported for this charge.' });
    this.refundsApplied.set(c.id, (this.refundsApplied.get(c.id) ?? 0) + 1);
    if (this.take('hold-refund', '')) {
      c.last_transaction!.status = 'pending_refund';
    } else {
      this.cancel(c, c.status === 'paid');
    }
    reply(200, structuredClone(c));
  }

  private cancel(c: PagarmeCharge, paid: boolean): void {
    c.status = 'canceled';
    c.canceled_amount = paid ? c.paid_amount : c.amount;
    c.canceled_at = new Date(this.now()).toISOString();
    c.last_transaction!.status = paid ? 'refunded' : 'voided';
  }
}
