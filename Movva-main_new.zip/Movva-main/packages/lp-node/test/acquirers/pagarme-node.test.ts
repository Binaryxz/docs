import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import type { Hex } from 'viem';
import { cardCheckoutTotal } from '@mova/ramp';
import { OrderState } from '../../src/abi.js';
import { PagarmeAcquirer, pagarmeOrderCode } from '../../src/acquirers/pagarme.js';
import { NATIVE } from '../../src/chain.js';
import { bookKey } from '../../src/offers.js';
import { CARD_FEE_BPS, CARD_MERCHANT, harness, type Harness } from '../harness.js';
import { MockPagarme } from './pagarme-mock.js';

/**
 * The Pagar.me adapter under the real node (card-onramp.ts), against the v5 mock over HTTP: the same flows
 * test/card.test.ts runs on MockAcquirer - checkout for the order plus its fee, release on the capture, the crash
 * between Pagar.me creating the order and the journal recording it, and a refund whose response is lost. Each
 * `restart()` builds a new adapter, so nothing survives in memory that a real restart would lose.
 */

let mock: MockPagarme;
let baseUrl: string;
let chainTime: () => bigint = () => 0n;
const adapters: PagarmeAcquirer[] = [];

beforeEach(async () => {
  mock = new MockPagarme(() => Number(chainTime()) * 1000);
  baseUrl = await mock.listen();
});
afterEach(async () => mock.close());

function withPagarme(o: { confirmations?: number } = {}): Harness {
  const h = harness({
    card: true, offramp: false, confirmations: o.confirmations ?? 1,
    tweak: (opts) => {
      const a = new PagarmeAcquirer({
        baseUrl, secretKey: mock.secretKey, ...CARD_MERCHANT, customerId: 'cus_mova_partner',
        successUrl: 'https://lp.example/card/done', now: () => chainTime(),
      });
      adapters.push(a);
      opts.acquirer = a;
    },
  });
  chainTime = () => h.chain.time();
  return h;
}

const cardOfferId = (h: Harness) => h.node.offers!.status.get(bookKey(NATIVE, true))?.activeOfferId;
const posts = () => mock.requests.filter((r) => r.method === 'POST').length;
const deletes = () => mock.requests.filter((r) => r.method === 'DELETE').length;

async function lockCard(h: Harness): Promise<{ orderId: Hex; total: bigint }> {
  if (!cardOfferId(h)) await h.tick();
  const orderId = h.chain.lockOrder(cardOfferId(h)!, 10n ** 17n);
  h.chain.mine(3);
  return { orderId, total: cardCheckoutTotal((await h.chain.order(orderId)).brlCents, CARD_FEE_BPS) };
}

describe('the node on Pagar.me', () => {
  it('creates one checkout for the order plus its fee, serves its payment_url, and releases on the capture', async () => {
    const h = withPagarme();
    const { orderId, total } = await lockCard(h);
    await h.tick();
    const card = h.node.store.getOrder(orderId)!.card!;
    const order = mock.orders.get(card.checkoutId!)!;
    expect(order).toMatchObject({ code: pagarmeOrderCode(orderId), amount: Number(total) });
    expect(card).toMatchObject({ amountCents: total, url: order.checkouts![0].payment_url });
    expect(card.expiresAt).toBeLessThanOrEqual((await h.chain.order(orderId)).payBy - 300n);
    const { body } = await h.node.onramp!.instructions(orderId);
    if (body.rail !== 'CARD') throw new Error('expected CARD');
    expect(body.checkoutUrl).toBe(order.checkouts![0].payment_url);

    for (let i = 0; i < 3; i++) await h.tick();
    expect(posts()).toBe(1);

    mock.pay(order.id);
    await h.tick();
    expect((await h.chain.order(orderId)).state).toBe(OrderState.RELEASED);
    expect(h.node.store.getOrder(orderId)!.card!.capture).toMatchObject({ acquirerId: CARD_MERCHANT.acquirerId, status: 'CAPTURED', amountCents: total });
  });

  it('crash: Pagar.me creates the order, the response is lost, the node restarts: one order, the same checkout, one charge, released', async () => {
    const h = withPagarme();
    const { orderId } = await lockCard(h);
    mock.loseNextResponse('POST /orders');
    await h.tick();
    expect(mock.orders.size).toBe(1);
    expect(h.node.store.getOrder(orderId)?.card?.checkoutId).toBeUndefined();

    h.restart();
    await h.tick();
    expect(mock.orders.size).toBe(1);
    expect(posts()).toBe(1);
    const [order] = mock.orders.values();
    expect(h.node.store.getOrder(orderId)?.card?.checkoutId).toBe(order.id);
    mock.pay(order.id);
    await h.tick();
    expect((await h.chain.order(orderId)).state).toBe(OrderState.RELEASED);
    expect(order.charges).toHaveLength(1);
  });

  it('crash: a refund moves at Pagar.me and its response is lost; after a restart it is found, never sent again', async () => {
    const h = withPagarme();
    const { orderId } = await lockCard(h);
    await h.tick();
    const saved = h.attestors.splice(0, 2); // nobody proves it: the order expires with the card charged
    const orderAt = h.node.store.getOrder(orderId)!.card!.checkoutId!;
    const charge = mock.pay(orderAt);
    await h.tick();
    h.chain.warp(31n * 60n);
    h.chain.mine();
    await h.tick();
    h.chain.mine(3);
    mock.loseNextResponse('DELETE /charges/{id}');
    await h.tick();
    expect(mock.refundsApplied.get(charge.id)).toBe(1);
    const pending = Object.values(h.node.store.getOrder(orderId)!.card!.reversals)[0];
    expect(pending.result).toBeUndefined();

    h.attestors.push(...saved);
    h.restart();
    for (let i = 0; i < 3; i++) await h.tick();
    expect(mock.refundsApplied.get(charge.id)).toBe(1);
    expect(deletes()).toBe(1);
    expect(Object.values(h.node.store.getOrder(orderId)!.card!.reversals)[0].result).toMatchObject({ status: 'SETTLED', kind: 'REFUND' });
    expect(mock.orders.get(orderAt)).toMatchObject({ closed: true });
    expect(h.node.store.unresolvedPayments()).toBe(0);
  });

  it('a capture Pagar.me lets through after the checkout expired never proves the order; it is refunded once', async () => {
    const h = withPagarme();
    mock.honourExpiry = false;
    const { orderId } = await lockCard(h);
    await h.tick();
    const card = h.node.store.getOrder(orderId)!.card!;
    h.chain.warp(card.expiresAt! - h.chain.time() + 60n); // past the checkout's expiry, before payBy
    h.chain.mine();
    const late = mock.pay(card.checkoutId!);
    for (let i = 0; i < 2; i++) await h.tick();
    expect((await h.chain.order(orderId)).state).toBe(OrderState.LOCKED);
    expect(h.node.store.getOrder(orderId)!.card!.capture).toBeUndefined();
    expect(mock.charges.get(late.id)!.status).toBe('canceled');
    expect(mock.refundsApplied.get(late.id)).toBe(1);
  });
});
