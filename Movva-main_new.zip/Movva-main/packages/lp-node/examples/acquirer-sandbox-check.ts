/**
 * Check the Pagar.me adapter against Pagar.me itself, with sandbox credentials. Never run in CI.
 *
 *   PAGARME_SECRET_KEY_FILE=/run/secrets/pagarme_sk_test PAGARME_CUSTOMER_ID=cus_... \
 *   PAGARME_SUCCESS_URL=https://lp.example/card/done PAGARME_ACQUIRER_ID=... PAGARME_MERCHANT_ID=acc_... \
 *   [PAGARME_BASE_URL=https://sdx-api.pagar.me/core/v5] \
 *   npx tsx packages/lp-node/examples/acquirer-sandbox-check.ts [--allow-production]
 *
 * It creates a R$ 1,00 checkout under a random order id, creates it again under the same key (it must be the same
 * order), finds it by its reference, lists its charges (none), and cancels it twice. It prints ids and statuses;
 * every error goes through `@mova/ops/redact` with the key.
 *
 * It refuses production - a live `sk_` key, on any host - unless `--allow-production` is given, which creates
 * and cancels a real, unpaid R$ 1,00 order. With a `sk_test_` key both `api.pagar.me` and `sdx-api.pagar.me`
 * are accepted: Pagar.me's docs name either as the test host.
 *
 * What this settles that the mock cannot: that an order under `customer_id` with `customer_editable: true` and no
 * `billing_address` is accepted, that `GET /orders?code=` finds it, that `expires_in` is minutes, and that
 * `PATCH /orders/{id}/closed` cancels the checkout.
 */
import { randomBytes } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { redactError } from '@mova/ops/redact';
import { PAGARME_PRODUCTION_URL, createCardAcquirer } from '../src/acquirers/pagarme.js';

let secretKey: string | undefined;

const brl = (cents: bigint) => `R$ ${cents / 100n},${(cents % 100n).toString().padStart(2, '0')}`;

async function main(): Promise<void> {
  const allowProduction = process.argv.includes('--allow-production');
  const keyFile = process.env.PAGARME_SECRET_KEY_FILE?.trim();
  if (!keyFile) throw new Error('PAGARME_SECRET_KEY_FILE is required');
  secretKey = readFileSync(keyFile, 'utf8').trim();
  const test = secretKey.startsWith('sk_test_');
  if (!test && !allowProduction) {
    throw new Error('refusing production: this is a live key. Pass --allow-production to create and cancel a real, unpaid R$ 1,00 order');
  }
  const base = new URL(process.env.PAGARME_BASE_URL?.trim() || PAGARME_PRODUCTION_URL);
  // The adapter refuses a test key outside development; this script is development.
  const acquirer = createCardAcquirer({ ...process.env, ...(test ? { LP_NODE_DEV: '1' } : {}) });

  const reference = `0x${randomBytes(32).toString('hex')}`;
  const idempotencyKey = `C${randomBytes(16).toString('hex')}`;
  const expiresAt = BigInt(Math.floor(Date.now() / 1000)) + 30n * 60n;
  console.log(`${test ? 'sandbox' : 'PRODUCTION'} ${base.origin}, reference ${reference}`);
  const failures: string[] = [];

  const checkout = await acquirer.createCheckout({ idempotencyKey, amountCents: 100n, expiresAt, reference });
  console.log(`created ${checkout.checkoutId}: ${brl(checkout.amountCents)}, expires ${new Date(Number(checkout.expiresAt) * 1000).toISOString()}, pay at ${checkout.url}`);
  if (checkout.amountCents !== 100n) failures.push(`amount ${checkout.amountCents}, not 100`);
  if (checkout.expiresAt > expiresAt) failures.push('expires after the requested time');

  const again = await acquirer.createCheckout({ idempotencyKey, amountCents: 100n, expiresAt, reference });
  if (again.checkoutId !== checkout.checkoutId) failures.push(`a repeated create returned ${again.checkoutId}: a second order`);
  else console.log('a repeated create returned the same order');

  const charges = await acquirer.chargesFor(reference);
  console.log(`found by reference: ${charges.length} charge(s)`);
  if (charges.length !== 0) failures.push('an unpaid checkout has charges');

  await acquirer.cancelCheckout(checkout.checkoutId);
  await acquirer.cancelCheckout(checkout.checkoutId);
  console.log('cancelled, twice');

  for (const f of failures) console.error(`FAIL ${f}`);
  if (failures.length) process.exitCode = 1;
  else console.log('OK');
}

main().catch((e: unknown) => {
  console.error(`FAIL ${redactError(e, [secretKey])}`);
  process.exitCode = 1;
});
