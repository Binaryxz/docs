/**
 * The Inter bank adapter against Inter's SANDBOX, with an integration's real credentials. A manual
 * check before an LP trusts the adapter with money; never run in CI (the suite collects only
 * `test/**\/*.test.ts`, and this needs credentials CI does not have).
 *
 *   INTER_API_URL=https://cdpj-sandbox.partners.uatinter.co \
 *   INTER_CLIENT_ID=<client id> INTER_CLIENT_SECRET_FILE=./secrets/inter_client_secret \
 *   INTER_CERT_FILE=./secrets/inter.crt INTER_CERT_KEY_FILE=./secrets/inter.key \
 *   [INTER_ACCOUNT=12345678] [INTER_STATE_PATH=./inter-sandbox.jsonl] \
 *   npx tsx packages/lp-node/examples/bank-sandbox-check.ts \
 *     [--hours 24] [--key <idempotency key>] [--send-one-centavo-to <pix key>] [--allow-production]
 *
 * In order, each step reported and none stopping the next:
 *
 *  1. lists the Pix received in the last `--hours` through API Pix - which at Inter lists only
 *     cob/cobv charges paid by QR code, so an empty list after paying the LP's key from a static code
 *     is itself the finding (see src/banks/inter.ts);
 *  2. reads the balance;
 *  3. with `--key`, asks the adapter for the outcome of that idempotency key (it answers from
 *     `INTER_STATE_PATH`, so point it at the file of the run that sent it);
 *  4. ONLY with `--send-one-centavo-to <pix key>`: sends R$ 0,01 under a fresh key, prints the key, and
 *     reads the outcome back for up to a minute - the check that PENDING becomes SETTLED with an
 *     end-to-end id and a time, and that approvals are off for the integration.
 *
 * It refuses a host other than the sandbox unless `--allow-production` is given: a production check
 * moves real money and reads a real statement. Credentials come only from `*_FILE` variables, as in
 * the node, and every line printed passes through `@mova/ops/redact`.
 */
import { randomBytes } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { redact, redactError } from '@mova/ops/redact';
import { normalizePixKey } from '@mova/ramp';
import { INTER_SANDBOX_URL } from '../src/banks/inter.js';
import { createBankAdapter } from '../src/banks/inter-module.js';

const argv = process.argv.slice(2);
const flag = (name: string) => argv.includes(name);
const value = (name: string): string | undefined => {
  const i = argv.indexOf(name);
  return i >= 0 ? argv[i + 1] : undefined;
};

const env = { ...process.env };
const secrets: string[] = [];
for (const name of ['INTER_CLIENT_SECRET_FILE', 'INTER_CERT_KEY_FILE']) {
  try {
    if (env[name]) secrets.push(readFileSync(env[name]!, 'utf8').trim());
  } catch {
    // the module reports an unreadable file
  }
}
for (const [k, v] of Object.entries(env)) if (/(KEY|SECRET|TOKEN|PASSWORD|CREDENTIAL)/i.test(k) && !k.endsWith('_FILE') && v && v.length >= 8) secrets.push(v);
const say = (line: string) => console.log(redact(line, secrets));
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

async function step(name: string, fn: () => Promise<void>): Promise<boolean> {
  try {
    await fn();
    return true;
  } catch (e) {
    say(`  ${name} failed: ${redactError(e, secrets)}`);
    return false;
  }
}

async function main(): Promise<number> {
  let host: string;
  try {
    host = new URL(env.INTER_API_URL ?? '').host;
  } catch {
    say('INTER_API_URL is required (the sandbox is https://cdpj-sandbox.partners.uatinter.co)');
    return 2;
  }
  if (host !== new URL(INTER_SANDBOX_URL).host && !flag('--allow-production')) {
    say(`refusing: ${host} is not Inter's sandbox. Pass --allow-production to check a production integration (real money).`);
    return 2;
  }
  if (!env.INTER_STATE_PATH) {
    env.INTER_STATE_PATH = join(tmpdir(), `inter-sandbox-${Date.now()}.jsonl`);
    say(`INTER_STATE_PATH not set: using ${env.INTER_STATE_PATH} (--key finds only what that file recorded)`);
  }
  let bank;
  try {
    bank = createBankAdapter(env);
  } catch (e) {
    say(redactError(e, secrets));
    return 2;
  }

  const hours = Number(value('--hours') ?? 24);
  let ok = true;
  say(`Inter at ${host}`);

  say(`1. Pix received in the last ${hours} h (API Pix /pix)`);
  ok = await step('listIncoming', async () => {
    const since = BigInt(Math.floor(Date.now() / 1000) - hours * 3600);
    const credits = (await bank.listIncoming({ since })).filter((c) => c.rail === 'PIX');
    say(`  ${credits.length} credit(s)`);
    for (const c of credits.slice(0, 20)) {
      say(`  ${c.amountCents} centavos at ${new Date(Number(c.paidAt) * 1000).toISOString()} e2e ${c.bankTxId.slice(0, 9)}... txid ${c.txid ? 'yes' : 'no'}`);
    }
  }) && ok;

  say('2. Balance (/banking/v2/saldo)');
  ok = await step('balanceCents', async () => {
    say(`  ${await bank.balanceCents!()} centavos available`);
  }) && ok;

  const key = value('--key');
  if (key) {
    say(`3. Outcome of ${key}`);
    ok = await step('getOutgoing', async () => {
      const r = await bank.getOutgoing(key);
      say(`  ${r ? JSON.stringify(r, (_k, v: unknown) => (typeof v === 'bigint' ? v.toString() : v)) : 'unknown to this state file'}`);
    }) && ok;
  }

  const to = value('--send-one-centavo-to');
  if (to) {
    say('4. Sending R$ 0,01');
    ok = await step('sendPix', async () => {
      const pixKey = normalizePixKey(to).key;
      const fresh = `S${randomBytes(16).toString('hex')}`;
      say(`  idempotency key ${fresh} (query it later with --key and the same INTER_STATE_PATH)`);
      let r = await bank.sendPix({ idempotencyKey: fresh, pixKey, amountCents: 1n, description: 'Mova sandbox check' });
      say(`  accepted: ${r.status}`);
      for (let i = 0; i < 12 && r.status === 'PENDING'; i++) {
        await sleep(5000);
        r = (await bank.getOutgoing(fresh)) ?? r;
      }
      say(`  outcome: ${r.status}${r.bankTxId ? ` e2e ${r.bankTxId}` : ''}${r.paidAt ? ` at ${new Date(Number(r.paidAt) * 1000).toISOString()}` : ''}${r.failureReason ? ` (${r.failureReason})` : ''}`);
      if (r.status === 'PENDING') say('  still PENDING after a minute: are manual approvals on for this integration?');
    }) && ok;
  } else {
    say('4. Skipped the R$ 0,01 send (pass --send-one-centavo-to <pix key>)');
  }
  return ok ? 0 : 1;
}

main().then((code) => process.exit(code), (e: unknown) => {
  console.error(redactError(e, secrets));
  process.exit(1);
});
