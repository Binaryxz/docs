/**
 * The LP node against the real contracts, end to end, on a local anvil.
 *
 * Deploys the ramp from forge artifacts as DeployRamp wires it - FiatEscrow, OffRampEscrow, LPRegistry, the FX leg
 * from Pyth (MockPyth's FX.USD/BRL read by PythFxOracle, re-expressed in centavos by ScaledFxBandOracle and crossed
 * with each asset's Chainlink USD feed by a ChainlinkSignedFxOracle), a ReclaimZkTlsVerifier whose witnesses are
 * local keys and whose endpoints are the four receipt pages (the boleto pages widened to BOLETO), and a 6-decimal MockUSD - admits an institutional LP, closes setup, and
 * then lets the NODE do the LP's job while scripted takers and sellers do theirs:
 *
 *   1. offers: the node posts ETH and USDT offers at reference + spread, inside the band, on the zkTLS verifier;
 *   2. on-ramp by PIX, ETH and USDT: a taker locks, fetches instructions from the node's API with a
 *      signature, checks the key opens the commitment, pays the BR Code; the node matches the credit,
 *      proves its received-payment page by zkTLS and releases;
 *   2b. on-ramp by PIX against an API Pix charge: the node restarts with `pixCharge: "cob"`, creates one charge
 *      per confirmed lock at the PSP (MockBank, whose QR code site MockPixQrSite serves signed payloads over real
 *      HTTPS), the taker verifies the PSP's JWS as a wallet does (@mova/wallet `verifyPixCharge`) and refuses a
 *      location holding another receiver's charge, pays the charge; the node matches it by txid and releases;
 *   3. on-ramp by boleto: the node registers a boleto, commits to it on-chain, the taker checks and
 *      pays it, the node proves the paid boleto by zkTLS and releases;
 *   4. off-ramp by PIX, ETH and USDT: a seller opens a sale and discloses its payee to the API; the
 *      node claims, waits for confirmations, pays, proves the PIX it sent by zkTLS and collects;
 *   4b. off-ramp by boleto: the node pays the seller's bill and proves it from its paid-bill page;
 *   5. a crash mid-payment: the bank moves the money and the response is lost; a NEW node process
 *      over the same journal file settles the sale without paying twice;
 *   5b. per-payer caps: the node restarts with tier 0 limited to R$ 600,00 a Brasília day; one person buys
 *      twice to two unrelated addresses and both count once against ONE payer reference, and a third
 *      purchase that crosses the cap is refused - the order stays LOCKED, nothing leaves the escrow, and the
 *      counterparty API answers 409 `cap_reached` without naming the total;
 *   6. the service entrypoint itself (src/bin/lp-node.ts) starts against the deployment as a second
 *      LP on local witness keys, reports ready, quotes, and shuts down cleanly on SIGTERM - and refuses to
 *      start at all with a PIX asset on an address that is no zkTLS verifier, having asked it on-chain.
 *
 * The bank is MockBank (its QR code site's CA generated at start), Pyth is
 * MockPyth, and the zkTLS witnesses are local keys: those are the things that are mocked.
 * Everything on-chain is the real bytecode.
 *
 *   FOUNDRY_OUT=<build dir> npx tsx packages/lp-node/examples/lp-node-live.ts [rpc]
 *
 * Without an rpc argument it starts its own anvil on port 8745 with one-second blocks (so
 * confirmations accrue as they would on a chain), and stops it at the end.
 */
import { spawn, type ChildProcess } from 'node:child_process';
import { mkdtempSync, readFileSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  createPublicClient, createWalletClient, defineChain, encodeAbiParameters, formatEther, formatUnits, http, parseEther,
  type Abi, type Account, type Address, type Chain, type Hex, type PublicClient, type Transport, type WalletClient,
} from 'viem';
import { generatePrivateKey, privateKeyToAccount } from 'viem/accounts';
import {
  RECEIPT_KINDS, Rail, boletoCommitment, brasiliaToday, buildBankBoleto, hashProviderParams, newBoletoSalt, newPixSalt,
  parseBoleto, pixKeyCommitment, prepareSettlement, railMask, receiptRail, receiptRailMask, receiptRequiresOrderTxid, receiptTemplates,
  verifyBoletoCommitment,
} from '@mova/ramp';
import {
  PixChargeRefused, httpsPixLocationFetch, parseDynamicPixBrCode, parsePixBrCode, pixCobTxidForOrder, verifyPixCharge,
} from '@mova/wallet';
import {
  JsonlJournal, LocalWitnessSession, LpNode, MockBank, MockPixQrSite, OrderState, SaleState,
  ViemRampChain, ZkTlsProver, idempotencyKey, serveLpNode, signInstructionsRequest, type CapsOptions, type LpNodeOptions,
  type LpRecord, type PriceFeed,
} from '../src/index.js';

const ROOT = fileURLToPath(new URL('../../../', import.meta.url));
const OUT = process.env.LP_NODE_FORGE_OUT ?? process.env.FOUNDRY_OUT ?? join(ROOT, 'forge-out');
const PORT = 8745;
const RPC = process.argv[2] ?? `http://127.0.0.1:${PORT}`;
const ANVIL = join(ROOT, '.foundry-pinned/v0.3.0/anvil');

const started = Date.now();
const step = (s: string) => console.log(`\n\x1b[1m${s}\x1b[0m  (+${Math.round((Date.now() - started) / 1000)}s)`);
const ok = (s: string) => console.log(`  \x1b[32mOK\x1b[0m    ${s}`);
const info = (k: string, v: unknown) => console.log(`        ${k.padEnd(28)} ${v}`);
class Failed extends Error {}
const check = (cond: unknown, what: string): void => {
  if (!cond) {
    console.log(`  \x1b[31mFAIL\x1b[0m  ${what}`);
    throw new Failed(what);
  }
  ok(what);
};
const brl = (c: bigint) => `R$ ${(Number(c) / 100).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`;
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

const art = (name: string, file = `${name}.sol`): { abi: Abi; bytecode: Hex } => {
  const j = JSON.parse(readFileSync(join(OUT, file, `${name}.json`), 'utf8')) as { abi: Abi; bytecode: { object: Hex } };
  return { abi: j.abi, bytecode: j.bytecode.object };
};

const GOVERNANCE_DELAY = 24n * 3600n;
const DISPUTE_TIMEOUT = 30n * 24n * 3600n;
/** FiatEscrow's TAKER_DISPUTE_TIMEOUT (H-04) and MAX_VETTING_FEE_BPS (H-02): the deploy scripts' defaults. */
const TAKER_DISPUTE_TIMEOUT = 5n * 24n * 3600n;
const MAX_VETTING_FEE_BPS = 10n;
const TIER_INSTITUTIONAL = 3;
const NATIVE: Address = '0x0000000000000000000000000000000000000000';
const ETH_PRICE = 2_000_000n; // R$ 20.000,00 per ETH, in centavos
/** Pyth's FX.USD/BRL id (DeployRamp's PYTH_FX_USD_BRL), and R$ 5,50 per dollar at Pyth's exponent -8. */
const FX_USD_BRL_ID: Hex = '0xd2db4dbf1aea74e0f666b0e8f73b9580d407f5e5cf931940b06dc633d7a95906';
const FX_E8 = 550_000_000n;
/** ETH/USD at Chainlink's 8 decimals: US$ 3.636,36363636, which at R$ 5,50 crosses to the R$ 20.000,00 above. */
const ETH_USD_E8 = 363_636_363_636n;
/** Where the LP's bank serves its receipt pages; the zkTLS verifier allowlists the templates under it. */
const BANK_URL_PREFIX = 'https://api.banco-lp.example/';
const USD_PRICE = 550n; // R$ 5,50 per whole token
const LP_PIX = 'liquidez@lp.example';
const SELLER_PIX = '+5511987654321';
const FUNDER_KEY: Hex = '0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80';

type Wallet = WalletClient<Transport, Chain, Account>;

async function startAnvil(): Promise<ChildProcess | undefined> {
  if (process.argv[2]) return undefined;
  const child = spawn(ANVIL, ['--port', String(PORT), '--block-time', '1', '--silent'], { stdio: 'ignore' });
  for (let i = 0; i < 50; i++) {
    try {
      const r = await fetch(RPC, { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{"jsonrpc":"2.0","id":1,"method":"eth_chainId","params":[]}' });
      if (r.ok) return child;
    } catch {
      // not up yet
    }
    await sleep(200);
  }
  child.kill();
  throw new Error(`anvil did not start on ${RPC}`);
}

async function main(): Promise<void> {
  const probe = createPublicClient({ transport: http(RPC) });
  const chainId = await probe.getChainId();
  const chain = defineChain({ id: chainId, name: 'anvil', nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 }, rpcUrls: { default: { http: [RPC] } } });
  const pub = createPublicClient({ chain, transport: http(RPC), pollingInterval: 250 }) as PublicClient;
  const wallet = (key: Hex): Wallet => createWalletClient({ account: privateKeyToAccount(key), chain, transport: http(RPC), pollingInterval: 250 });
  const funder = wallet(FUNDER_KEY);

  const send = async (w: Wallet, address: Address, abi: Abi, functionName: string, args: unknown[], value = 0n) => {
    const hash = await w.writeContract({ address, abi, functionName, args, value } as never);
    const r = await pub.waitForTransactionReceipt({ hash });
    if (r.status !== 'success') throw new Error(`${functionName} reverted`);
    return r;
  };
  const deploy = async (name: string, args: unknown[], file?: string): Promise<Address> => {
    const a = art(name, file);
    const hash = await funder.deployContract({ abi: a.abi, bytecode: a.bytecode, args } as never);
    const r = await pub.waitForTransactionReceipt({ hash });
    if (!r.contractAddress) throw new Error(`${name} did not deploy`);
    return r.contractAddress;
  };
  const fund = async (to: Address, value: bigint) => {
    await pub.waitForTransactionReceipt({ hash: await funder.sendTransaction({ to, value }) });
  };

  step('1. Deploy the ramp from forge artifacts');
  info('artifacts', OUT);
  const gov = wallet(generatePrivateKey());
  const lpKey = generatePrivateKey();
  const lp = wallet(lpKey);
  const lp2Key = generatePrivateKey();
  // Kept as a key: a local account signs typed data, which a wallet client's generic `Account` need not.
  const takerKey = generatePrivateKey();
  const taker = wallet(takerKey);
  const seller = wallet(generatePrivateKey());
  for (const w of [gov, lp, taker, seller]) await fund(w.account.address, parseEther('20'));
  await fund(privateKeyToAccount(lp2Key).address, parseEther('20'));

  const GOV = art('DelayedGovernance').abi;
  // The FX leg, as DeployRamp wires it: Pyth's FX.USD/BRL, read in millionths of a real by PythFxOracle, in centavos
  // by ScaledFxBandOracle (as a band: the last close while the market is closed), crossed with each Chainlink feed.
  const pyth = await deploy('MockPyth', [1n]);
  const update = encodeAbiParameters(
    [{ type: 'bytes32' }, { type: 'int64' }, { type: 'uint64' }, { type: 'int32' }, { type: 'uint256' }],
    [FX_USD_BRL_ID, FX_E8, 0n, -8, (await pub.getBlock()).timestamp],
  );
  await send(funder, pyth, art('MockPyth').abi, 'updatePriceFeeds', [[update]], 1n); // what the Pyth keeper posts
  const pythFx = await deploy('PythFxOracle', [pyth, FX_USD_BRL_ID, 3_600n, 4n * 86_400n, 100, gov.account.address, GOVERNANCE_DELAY]);
  const fxBand = await deploy('ScaledFxBandOracle', [pythFx]);
  const ethUsd = await deploy('MockFeed', [ETH_USD_E8, 8], 'RampIntegration.t.sol');
  const usdtUsd = await deploy('MockFeed', [100_000_000n, 8], 'RampIntegration.t.sol');
  const oracleEth = await deploy('ChainlinkSignedFxOracle', [ethUsd, fxBand, 25n * 3_600n, 3_600n, gov.account.address, GOVERNANCE_DELAY]);
  const oracleUsd = await deploy('ChainlinkSignedFxOracle', [usdtUsd, fxBand, 25n * 3_600n, 3_600n, gov.account.address, GOVERNANCE_DELAY]);
  for (const c of [pythFx, oracleEth, oracleUsd]) await send(gov, c, GOV, 'completeSetup', []);
  const ORACLE = art('ChainlinkSignedFxOracle').abi;
  const [ethMid] = await pub.readContract({ address: oracleEth, abi: ORACLE, functionName: 'brlCentsPerUnit' }) as [bigint, bigint];
  const [usdMid] = await pub.readContract({ address: oracleUsd, abi: ORACLE, functionName: 'brlCentsPerUnit' }) as [bigint, bigint];
  if (ethMid !== ETH_PRICE || usdMid !== USD_PRICE) throw new Error(`the crosses read ${ethMid} and ${usdMid}, not ${ETH_PRICE} and ${USD_PRICE}`);

  // Bank rails settle on zkTLS: witnesses (local keys) to sessions with the LP's bank's four receipt pages.
  const witnessKeys = [generatePrivateKey(), generatePrivateKey()];
  const templates = receiptTemplates(BANK_URL_PREFIX);
  const registry = await deploy('LPRegistry', [gov.account.address, GOVERNANCE_DELAY]);
  const zktls = await deploy('ReclaimZkTlsVerifier', [
    gov.account.address, GOVERNANCE_DELAY, witnessKeys.map((k) => privateKeyToAccount(k).address), 2n,
    RECEIPT_KINDS.map((k) => hashProviderParams(templates[k])), RECEIPT_KINDS.map(() => BANK_URL_PREFIX),
  ]);
  // Allowed endpoints attest PIX until the governor widens them: the boleto pages to BOLETO alone, during setup.
  for (const k of RECEIPT_KINDS) {
    if (receiptRail(k) === Rail.BOLETO) await send(gov, zktls, art('ReclaimZkTlsVerifier').abi, 'setEndpointRails', [hashProviderParams(templates[k]), receiptRailMask(k)]);
    // M-03: a PIX credit proven from the received-payment page settles only the order its BR Code's txid names.
    if (receiptRequiresOrderTxid(k)) await send(gov, zktls, art('ReclaimZkTlsVerifier').abi, 'setEndpointOrderTxid', [hashProviderParams(templates[k]), true]);
  }
  const poolStub = await deploy('PoolStub', [], 'RampIntegration.t.sol');
  const fiat = await deploy('FiatEscrow', [oracleEth, registry, poolStub, poolStub, 500n, gov.account.address, GOVERNANCE_DELAY, DISPUTE_TIMEOUT, TAKER_DISPUTE_TIMEOUT, MAX_VETTING_FEE_BPS]);
  const offramp = await deploy('OffRampEscrow', [oracleEth, registry, 500n, gov.account.address, GOVERNANCE_DELAY, DISPUTE_TIMEOUT]);
  const usdt = await deploy('MockUSD', [], 'RampErc20.t.sol');
  const deployBlock = await pub.getBlockNumber();

  const REG = art('LPRegistry').abi;
  const FIAT = art('FiatEscrow').abi;
  const OFF = art('OffRampEscrow').abi;
  const USD = art('MockUSD', 'RampErc20.t.sol').abi;
  await send(gov, registry, REG, 'setEscrow', [fiat, true]);
  await send(gov, registry, REG, 'setEscrow', [offramp, true]);
  await send(gov, registry, REG, 'setTier', [lp.account.address, TIER_INSTITUTIONAL, 100_000_000n]);
  await send(gov, registry, REG, 'setTier', [privateKeyToAccount(lp2Key).address, TIER_INSTITUTIONAL, 10_000_000n]);
  for (const e of [fiat, offramp]) {
    await send(gov, e, FIAT, 'setVerifier', [zktls, true]);
    await send(gov, e, FIAT, 'setAsset', [usdt, oracleUsd, 6, true]);
  }
  for (const c of [registry, zktls, fiat, offramp]) await send(gov, c, GOV, 'completeSetup', []);
  await send(funder, usdt, USD, 'mint', [lp.account.address, 100_000n * 10n ** 6n]);
  await send(funder, usdt, USD, 'mint', [seller.account.address, 10_000n * 10n ** 6n]);
  await send(funder, usdt, USD, 'mint', [privateKeyToAccount(lp2Key).address, 1_000n * 10n ** 6n]);
  ok('FiatEscrow, OffRampEscrow, LPRegistry, MockUSD (6 dp); setup closed');
  ok(`FX from Pyth: MockPyth -> PythFxOracle -> ScaledFxBandOracle, crossed with Chainlink: ETH ${brl(ethMid)}, USDT ${brl(usdMid)}`);
  ok('ReclaimZkTlsVerifier: 2-of-2 local witnesses, four receipt pages (PIX pages for PIX, boleto pages for BOLETO; the received-payment page bound to the order by its txid, M-03)');
  info('FiatEscrow', fiat);
  info('OffRampEscrow', offramp);

  step('2. Start the LP node: MockBank, local zkTLS witnesses for PIX and boleto, a journal file');
  // The bank's clock and the node's wall clock are wall time, as in production. anvil stamps blocks
  // with wall time too, so a payment made after a lock or an issue post-dates it on-chain as well.
  const wall = () => BigInt(Math.floor(Date.now() / 1000));
  // The PSP's dynamic QR code site, for step 4b's charges: a CA, an EV site certificate and a JWS signing key, generated.
  const qrSite = new MockPixQrSite({ host: 'qrcodes.psp.example' });
  const bank = new MockBank({ now: wall, qrSite, receiver: { name: 'LP Liquidez Ltda', city: 'Sao Paulo' } });
  const dir = mkdtempSync(join(tmpdir(), 'lp-node-live-'));
  const journalPath = join(dir, 'lp-node.jsonl');
  const feed = (price: bigint): PriceFeed => ({ price: async () => ({ price: price + price / 500n, updatedAt: wall() }) });
  const rampChain = new ViemRampChain({ publicClient: pub, walletClient: lp, registry, onramp: fiat, offramp });
  // The witnesses sign claims about the bank's receipt pages from MockBank's own records; the prover checks each claim
  // against the verifier's witnesses and endpoints, and against the verifier on-chain, before it is submitted.
  const session = new LocalWitnessSession({ witnessKeys, receipts: bank, templates, now: wall });
  const zkProver = new ZkTlsProver(zktls, session, {
    witnesses: { addresses: witnessKeys.map((k) => privateKeyToAccount(k).address), threshold: 2 },
    endpoints: RECEIPT_KINDS.map((k) => ({
      providerHash: hashProviderParams(templates[k]), urlPrefix: BANK_URL_PREFIX, rails: [receiptRail(k)], requiresOrderTxid: receiptRequiresOrderTxid(k),
    })),
    escrows: { chainId, onramp: fiat, offramp },
    preflight: async (proof, { leg }) => { await prepareSettlement(pub, zktls, proof, { chainId, address: leg === 'onramp' ? fiat : offramp }); },
  });
  const logs: string[] = [];
  /** Static BR Codes until step 4b restarts the node with API Pix charges. */
  let pixCharge: 'static' | 'cob' = 'static';
  /** No per-payer caps until step 7b turns them on. */
  let caps: CapsOptions | undefined;
  const options = (): LpNodeOptions => ({
    chain: rampChain, bank, journal: new JsonlJournal<LpRecord>(journalPath), caps,
    provers: [zkProver],
    confirmations: 2, fromBlock: deployBlock, reorgWindow: 16n, payerRefSecret: `0x${'5a'.repeat(32)}`, lpPayerId: '12345678000195',
    wallClock: wall, pollMs: 500,
    log: { info: (m) => logs.push(m), warn: (m) => logs.push(m), error: (m) => { logs.push(m); console.log(`        node error: ${m}`); } },
    onramp: {
      escrow: fiat, pixKey: LP_PIX, receiver: { name: 'LP Liquidez Ltda', city: 'Sao Paulo' }, reclaimExpired: true, autoRefund: true,
      boletoDueDays: 3, reorgWindow: 16n, lateCreditGraceSeconds: 600, pixCharge,
      assets: [
        { asset: NATIVE, symbol: 'ETH', liquidity: parseEther('2'), minOrder: parseEther('0.01'), maxOrder: parseEther('1'), verifier: zktls,
          rails: [Rail.PIX, Rail.BOLETO], refillBelowBps: 2_000, feed: feed(ETH_PRICE), gasReserveWei: parseEther('1'),
          pricing: { spreadBps: 100, minSpreadBps: 30, maxOracleDeviationBps: 200, bandMarginBps: 100, refreshDriftBps: 60, maxReferenceAgeSeconds: 120, oracleStaleMarginSeconds: 300 } },
        { asset: usdt, symbol: 'USDT', liquidity: 5_000n * 10n ** 6n, minOrder: 10n * 10n ** 6n, maxOrder: 2_000n * 10n ** 6n, verifier: zktls,
          rails: [Rail.PIX], refillBelowBps: 2_000, feed: feed(USD_PRICE),
          pricing: { spreadBps: 80, minSpreadBps: 20, maxOracleDeviationBps: 200, bandMarginBps: 100, refreshDriftBps: 60, maxReferenceAgeSeconds: 120, oracleStaleMarginSeconds: 300 } },
      ],
    },
    offramp: {
      escrow: offramp, rails: ['PIX', 'BOLETO'], maxOpenClaims: 3, minTimeToPaySeconds: 20 * 60, disputeMarginSeconds: 7 * 60,
      bankClockSkewSeconds: 1, raiseDisputeWhenUnproven: true, reorgWindow: 16n,
      assets: [
        { asset: NATIVE, symbol: 'ETH', minSaleBrlCents: 100n, maxSaleBrlCents: 10_000_000n, feed: feed(ETH_PRICE),
          pricing: { minMarginBps: 50, maxOracleDeviationBps: 200, maxReferenceAgeSeconds: 120, oracleStaleMarginSeconds: 300 } },
        { asset: usdt, symbol: 'USDT', minSaleBrlCents: 100n, maxSaleBrlCents: 10_000_000n, feed: feed(USD_PRICE),
          pricing: { minMarginBps: 50, maxOracleDeviationBps: 200, maxReferenceAgeSeconds: 120, oracleStaleMarginSeconds: 300 } },
      ],
    },
  });
  let node = new LpNode(options());
  let api = serveLpNode(node, { mode: 'both' });
  let apiUrl = `http://127.0.0.1:${await api.listen(0)}`;
  const tick = () => node.tick();
  const until = async (what: string, cond: () => Promise<boolean>, maxTicks = 40) => {
    for (let i = 0; i < maxTicks; i++) {
      await tick();
      if (await cond()) return;
      await sleep(400);
    }
    throw new Failed(`timed out waiting for: ${what}`);
  };
  const post = async (path: string, body: unknown) => {
    const r = await fetch(`${apiUrl}${path}`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body, (_k, v) => (typeof v === 'bigint' ? v.toString() : v)) });
    return { status: r.status, body: await r.json() as Record<string, unknown> };
  };

  step('3. The node posts offers, per asset, inside the band');
  await until('offers for ETH and USDT', async () => !!node.offers!.status.get(NATIVE)?.quoting && !!node.offers!.status.get(usdt.toLowerCase())?.quoting);
  const ethStatus = node.offers!.status.get(NATIVE)!;
  const usdStatus = node.offers!.status.get(usdt.toLowerCase())!;
  const ethOffer = await rampChain.offer(ethStatus.activeOfferId!);
  const usdOffer = await rampChain.offer(usdStatus.activeOfferId!);
  info('ETH offer', `${formatEther(ethOffer.availableWei)} ETH at ${brl(ethOffer.priceBrlCentsPerEth)} per ETH`);
  info('USDT offer', `${formatUnits(usdOffer.availableWei, 6)} USDT at ${brl(usdOffer.priceBrlCentsPerEth)} per USDT`);
  check(ethOffer.priceBrlCentsPerEth > ETH_PRICE && ethOffer.priceBrlCentsPerEth <= (ETH_PRICE * 10_400n) / 10_000n, 'ETH priced above the oracle, inside the band less its margin');
  check(usdOffer.decimals === 6 && usdOffer.priceBrlCentsPerEth > USD_PRICE && usdOffer.priceBrlCentsPerEth <= (USD_PRICE * 10_400n) / 10_000n,
    'USDT priced per whole token (the escrow pinned 6 decimals), above the oracle, inside the band');
  check([ethOffer.verifier, usdOffer.verifier].every((v) => v.toLowerCase() === zktls.toLowerCase()), 'both bank offers name the ReclaimZkTlsVerifier');
  const takerOrder = async (offerId: Hex, amount: bigint, boleto = false): Promise<Hex> => {
    const fn = boleto ? 'lockOrderByBoleto' : 'lockOrder';
    const rc = await send(taker, fiat, FIAT, fn, [offerId, amount, 0, taker.account.address, 0n]);
    const logsLocked = await pub.getContractEvents({ address: fiat, abi: FIAT, eventName: 'OrderLocked', blockHash: rc.blockHash });
    return (logsLocked[0] as unknown as { args: { orderId: Hex } }).args.orderId;
  };
  const instructions = async (orderId: Hex) => {
    const req = await signInstructionsRequest(privateKeyToAccount(takerKey), { chainId, escrow: fiat, orderId, issuedAt: Number(wall()) });
    return post('/v1/onramp/instructions', req);
  };

  step('4. On-ramp by PIX: ETH, then USDT');
  for (const [symbol, offerId, amount] of [['ETH', ethStatus.activeOfferId!, parseEther('0.1')], ['USDT', usdStatus.activeOfferId!, 100n * 10n ** 6n]] as const) {
    const orderId = await takerOrder(offerId, amount);
    const before = symbol === 'ETH'
      ? await pub.getBalance({ address: taker.account.address })
      : await pub.readContract({ address: usdt, abi: USD, functionName: 'balanceOf', args: [taker.account.address] }) as bigint;
    await until(`${symbol} order tracked`, async () => !!node.store.getOrder(orderId));
    const res = await instructions(orderId);
    check(res.status === 200 && res.body.rail === 'PIX', `${symbol}: the taker fetched signed-for payment instructions from the node`);
    const offer = await rampChain.offer(offerId);
    check(pixKeyCommitment(res.body.pixKey as string, res.body.salt as Hex) === offer.pixKeyHash, `${symbol}: the key and salt open the offer's on-chain commitment`);
    const code = parsePixBrCode(res.body.pixCopiaECola as string);
    const ord = await rampChain.order(orderId);
    check(code.amountCents === ord.brlCents, `${symbol}: the BR Code charges exactly the order's ${brl(ord.brlCents)}`);
    bank.receivePix({ amountCents: code.amountCents!, creditedKey: code.key, txid: code.txid });
    await until(`${symbol} release`, async () => (await rampChain.order(orderId)).state === OrderState.RELEASED);
    const after = symbol === 'ETH'
      ? await pub.getBalance({ address: taker.account.address })
      : await pub.readContract({ address: usdt, abi: USD, functionName: 'balanceOf', args: [taker.account.address] }) as bigint;
    check(after - before === amount, `${symbol}: the node matched the credit, proved its received-payment page by zkTLS, the escrow released ${symbol === 'ETH' ? formatEther(amount) : formatUnits(amount, 6)} ${symbol} to the taker`);
  }

  step('4b. On-ramp by PIX against an API Pix charge: the node restarts with pixCharge "cob"');
  {
    await node.stop();
    await api.close();
    pixCharge = 'cob';
    node = new LpNode(options());
    api = serveLpNode(node, { mode: 'both' });
    apiUrl = `http://127.0.0.1:${await api.listen(0)}`;
    const qr = await qrSite.listen();
    // What a wallet brings: the PSP's QR code host on its allowlist, a revocation source, the root, and https to the site.
    const trust = {
      certificateStatus: qrSite.ca.certificateStatus, trustedRoots: [qrSite.ca.rootPem],
      fetch: httpsPixLocationFetch({ ca: [qrSite.ca.rootPem], connect: () => ({ host: '127.0.0.1', port: qr.port }) }),
    };
    const amount = parseEther('0.02');
    const orderId = await takerOrder(ethStatus.activeOfferId!, amount);
    const before = await pub.getBalance({ address: taker.account.address });
    await until('the charge', async () => (await instructions(orderId)).status === 200);
    const res = await instructions(orderId);
    const ord = await rampChain.order(orderId);
    const txid = pixCobTxidForOrder(chainId, fiat, orderId);
    check(res.body.charge === 'cob' && res.body.txid === txid && bank.chargeCalls.create === 1,
      `the node created one API Pix charge for the confirmed lock (txid ${txid}) and served the PSP's dynamic code`);
    check(pixKeyCommitment(res.body.pixKey as string, res.body.salt as Hex) === (await rampChain.offer(ethStatus.activeOfferId!)).pixKeyHash,
      'beside it, the key and salt that open the offer\'s commitment');
    info('location host', parseDynamicPixBrCode(res.body.pixCopiaECola as string).location.split('/')[0]);
    const expected = { pixKey: res.body.pixKey as string, amountCents: ord.brlCents, txid, payBy: Number(ord.payBy) };
    const verified = await verifyPixCharge({
      pixCopiaECola: res.body.pixCopiaECola as string, location: res.body.location as string, expected, hosts: [qrSite.host], trust, now: new Date(),
    });
    const alg = (JSON.parse(Buffer.from(verified.jws.split('.')[0], 'base64url').toString('utf8')) as { alg: string }).alg;
    check(verified.amountCents === ord.brlCents && verified.expiresAt <= Number(ord.payBy),
      `over HTTPS, a ${alg} JWS from the PSP's key (jku on the same host, x5c to the root) signs an ATIVA charge for the key, ${brl(ord.brlCents)} and the txid, expiring before payBy`);
    // A lying location: the same PSP's charge for another receiver - this txid, this amount, another key.
    const decoy = await new MockBank({ now: wall, qrSite, receiver: { name: 'Golpe Ltda', city: 'Sao Paulo' } })
      .createCharge({ txid, amountCents: ord.brlCents, pixKey: 'golpe@example.com', expiresInSeconds: 600 });
    const lied = await verifyPixCharge({ pixCopiaECola: decoy.pixCopiaECola!, location: decoy.location, expected, hosts: [qrSite.host], trust, now: new Date() })
      .then(() => undefined, (e: unknown) => e);
    check(lied instanceof PixChargeRefused && lied.code === 'charge_key_mismatch',
      `a code whose location holds a charge for another key is refused before anything is paid: ${lied instanceof PixChargeRefused ? lied.code : String(lied)}`);
    bank.payCharge(txid);
    await until('cob release', async () => (await rampChain.order(orderId)).state === OrderState.RELEASED);
    check((await pub.getBalance({ address: taker.account.address })) - before === amount && bank.charges.get(txid)!.status === 'CONCLUIDA' && bank.chargeCalls.create === 1,
      `paid by the charge: the node matched the credit by its txid, proved it by zkTLS, the escrow released ${formatEther(amount)} ETH - one charge, now CONCLUIDA`);
    await qr.close();
  }

  step('5. On-ramp by boleto: the node registers one and commits to it');
  {
    const orderId = await takerOrder(ethStatus.activeOfferId!, parseEther('0.05'), true);
    await until('boleto issued on-chain', async () => (await rampChain.boleto(orderId)).issuedAt !== 0n);
    const res = await instructions(orderId);
    check(res.status === 200 && res.body.rail === 'BOLETO', 'the taker fetched the boleto line and salt');
    const bol = await rampChain.boleto(orderId);
    const ord = await rampChain.order(orderId);
    verifyBoletoCommitment({ line: res.body.line as string, salt: res.body.salt as Hex, commitment: bol.commitment, brlCents: ord.brlCents });
    ok(`the line opens the on-chain commitment, for ${brl(parseBoleto(res.body.line as string).amountCents!)}, not overdue`);
    bank.payRegisteredBoleto(res.body.line as string);
    await until('boleto order release', async () => (await rampChain.order(orderId)).state === OrderState.RELEASED);
    ok('paid at the bank; the witnesses signed the received-boleto page, which the verifier allowlists for BOLETO; released');
  }

  step('6. Off-ramp by PIX: ETH, then USDT');
  const openSale = async (asset: Address, amount: bigint, brlCents: bigint) => {
    const salt = newPixSalt();
    if (asset !== NATIVE) await send(seller, asset, USD, 'approve', [offramp, amount]);
    const rc = await send(seller, offramp, OFF, 'openSale',
      [asset, amount, brlCents, pixKeyCommitment(SELLER_PIX, salt), zktls, railMask(Rail.PIX), seller.account.address], asset === NATIVE ? amount : 0n);
    const ev = await pub.getContractEvents({ address: offramp, abi: OFF, eventName: 'SaleOpened', blockHash: rc.blockHash });
    return { saleId: (ev[0] as unknown as { args: { saleId: Hex } }).args.saleId, salt };
  };
  const lpBalance = async (asset: Address) => asset === NATIVE
    ? pub.getBalance({ address: lp.account.address })
    : pub.readContract({ address: asset, abi: USD, functionName: 'balanceOf', args: [lp.account.address] }) as Promise<bigint>;

  for (const [symbol, asset, amount, cents] of [
    ['ETH', NATIVE, parseEther('0.05'), 99_000n], // 1% under the oracle
    ['USDT', usdt, 200n * 10n ** 6n, 108_900n], // R$ 5,445 per token: 1% under
  ] as const) {
    const { saleId, salt } = await openSale(asset, amount, cents);
    const disclosed = await post('/v1/offramp/payee', { saleId, pixKey: SELLER_PIX, salt });
    check(disclosed.status === 201, `${symbol}: the seller disclosed the payee; the node checked it opens the commitment`);
    const paidBefore = bank.outgoing.length;
    const tokenBefore = asset === NATIVE ? 0n : await lpBalance(asset);
    const escrowEthBefore = await pub.getBalance({ address: offramp });
    await until(`${symbol} claim`, async () => (await rampChain.sale(saleId)).state === SaleState.CLAIMED);
    check(bank.outgoing.length === paidBefore, `${symbol}: claimed - and nothing paid while the claim is unconfirmed`);
    await until(`${symbol} settlement`, async () => (await rampChain.sale(saleId)).state === SaleState.SETTLED);
    const paid = bank.outgoing[bank.outgoing.length - 1];
    check(paid.destination === SELLER_PIX && paid.amountCents === cents, `${symbol}: ${brl(cents)} sent by PIX to the seller's key, proven from the node's sent-payment page`);
    const settled = await pub.getContractEvents({ address: offramp, abi: OFF, eventName: 'SaleSettled', fromBlock: deployBlock });
    const mine = settled.map((l) => (l as unknown as { args: { saleId: Hex; lp: Address } }).args).find((a) => a.saleId === saleId);
    check(mine?.lp === lp.account.address, `${symbol}: SaleSettled names this LP as the payee of the escrowed crypto`);
    if (asset !== NATIVE) check((await lpBalance(asset)) - tokenBefore === amount, `${symbol}: the LP's wallet received ${formatUnits(amount, 6)} USDT`);
    else check(escrowEthBefore - (await pub.getBalance({ address: offramp })) === amount, `${symbol}: ${formatEther(amount)} ETH left the escrow for the LP`);
  }

  step('6b. Off-ramp by boleto: the node pays the seller\'s bill and proves it from its paid-bill page');
  {
    const cents = 49_500n; // 0.025 ETH, 1% under the oracle
    const amount = parseEther('0.025');
    const bill = buildBankBoleto({
      bankCode: '341', amountCents: cents, freeField: '1234567890123456789012345', dueDate: brasiliaToday(new Date(Date.now() + 10 * 86_400_000)),
    });
    const salt = newBoletoSalt();
    const rc = await send(seller, offramp, OFF, 'openSale',
      [NATIVE, amount, cents, boletoCommitment(bill, salt), zktls, railMask(Rail.BOLETO), seller.account.address], amount);
    const saleId = ((await pub.getContractEvents({ address: offramp, abi: OFF, eventName: 'SaleOpened', blockHash: rc.blockHash }))[0] as unknown as { args: { saleId: Hex } }).args.saleId;
    const disclosed = await post('/v1/offramp/payee', { saleId, boletoLine: bill.line, salt });
    check(disclosed.status === 201, 'the seller disclosed the bill; the node checked the line and salt open the sale\'s commitment, for its amount, not overdue');
    await until('boleto sale settlement', async () => (await rampChain.sale(saleId)).state === SaleState.SETTLED);
    const paid = bank.outgoing[bank.outgoing.length - 1];
    check(paid.kind === 'BOLETO' && paid.destination === bill.barcode && paid.amountCents === cents, `${brl(cents)} paid on the seller's bill at the bank`);
    const settled = (await pub.getContractEvents({ address: offramp, abi: OFF, eventName: 'SaleSettled', fromBlock: deployBlock }))
      .map((l) => (l as unknown as { args: { saleId: Hex; lp: Address; rail: number } }).args).find((a) => a.saleId === saleId);
    check(settled?.lp === lp.account.address && settled.rail === Rail.BOLETO,
      'SaleSettled on rail BOLETO: ReclaimZkTlsVerifier took the witnesses\' claim about the paid-bill page, allowlisted for BOLETO, bound to the sale');
  }

  step('7. A crash mid-payment, and a new process over the same journal');
  {
    const { saleId, salt } = await openSale(NATIVE, parseEther('0.02'), 39_600n);
    await post('/v1/offramp/payee', { saleId, pixKey: SELLER_PIX, salt });
    const key = idempotencyKey('sale-pay', chainId, offramp, saleId);
    await until('claim', async () => (await rampChain.sale(saleId)).state === SaleState.CLAIMED);
    info('fault injected', 'the bank will move the next transfer and drop the response');
    bank.loseNextResponse();
    await until('the transfer to go out', async () => bank.moneyMovedFor(key) === 1);
    check(node.store.getSale(saleId)?.pay?.result === undefined, 'the bank moved the money and the response was lost: the journal has the intent, not the result');
    await node.stop();
    await api.close();

    node = new LpNode(options()); // a new process: state only from the file
    api = serveLpNode(node, { mode: 'both' });
    apiUrl = `http://127.0.0.1:${await api.listen(0)}`;
    await until('settlement after restart', async () => (await rampChain.sale(saleId)).state === SaleState.SETTLED);
    check(bank.moneyMovedFor(key) === 1 && bank.outgoing.filter((o) => o.idempotencyKey === key).length === 1,
      'the restarted node asked the bank about the key, adopted the payment, settled - and paid exactly once');
  }

  step('7b. A per-payer daily cap: the same person, twice, and once too far');
  {
    // The node restarts with tier 0 limited to R$ 600,00 a day. Nothing else changes: caps live in the node,
    // never on-chain, and are keyed on the payer the BANK names - never on an address.
    await node.stop();
    await api.close();
    pixCharge = 'static';
    caps = { tiers: { 0: { dailyBrlCents: 60_000n } }, defaultTier: 0 };
    node = new LpNode(options());
    api = serveLpNode(node, { mode: 'both' });
    apiUrl = `http://127.0.0.1:${await api.listen(0)}`;
    // One person, paying from one CPF, buying to two different addresses: only the bank ties them together.
    const ANA = '52998224725';
    const buy = async (amount: bigint, recipient: Address): Promise<{ orderId: Hex; cents: bigint }> => {
      const rc = await send(taker, fiat, FIAT, 'lockOrder', [ethStatus.activeOfferId!, amount, 0, recipient, 0n]);
      const orderId = ((await pub.getContractEvents({ address: fiat, abi: FIAT, eventName: 'OrderLocked', blockHash: rc.blockHash }))[0] as unknown as { args: { orderId: Hex } }).args.orderId;
      await until('the order to be tracked', async () => !!node.store.getOrder(orderId));
      const res = await instructions(orderId);
      if (res.status !== 200) throw new Failed(`instructions: ${res.status} ${String(res.body.error)}`);
      const code = parsePixBrCode(res.body.pixCopiaECola as string);
      bank.receivePix({ amountCents: code.amountCents!, creditedKey: code.key, txid: code.txid, payerId: ANA });
      return { orderId, cents: code.amountCents! };
    };
    const capsOf = async () => ((await (await fetch(`${apiUrl}/status`)).json()) as { caps: { payers: { payerRef: Hex; dayCents: string }[]; day: string; rows: number } }).caps;

    // Two purchases inside the cap, to two unrelated addresses.
    const first = privateKeyToAccount(generatePrivateKey()).address;
    const second = privateKeyToAccount(generatePrivateKey()).address;
    const a = await buy(parseEther('0.01'), first);
    await until('the first purchase to release', async () => (await rampChain.order(a.orderId)).state === OrderState.RELEASED);
    const b = await buy(parseEther('0.01'), second);
    await until('the second purchase to release', async () => (await rampChain.order(b.orderId)).state === OrderState.RELEASED);
    check(await pub.getBalance({ address: first }) === parseEther('0.01') && await pub.getBalance({ address: second }) === parseEther('0.01'),
      `two purchases of ${brl(a.cents)} and ${brl(b.cents)} delivered to two unrelated addresses`);

    const counted = await capsOf();
    info('cap ledger', `${counted.rows} row(s), Brasília day ${counted.day}`);
    check(counted.payers.length === 1 && BigInt(counted.payers[0].dayCents) === a.cents + b.cents,
      `both orders counted once, against ONE payer reference (${counted.payers[0].payerRef.slice(0, 10)}…) - the CPF, hashed under PAYER_REF_SECRET, and nothing that names an address`);

    // A third that crosses R$ 600,00. It is paid; the node refuses to prove it, and nothing leaves the escrow.
    const third = privateKeyToAccount(generatePrivateKey()).address;
    const releasedBefore = Number(/^mova_lp_onramp_released_total (\d+)/m.exec(await (await fetch(`${apiUrl}/metrics`)).text())?.[1] ?? '0');
    const c = await buy(parseEther('0.02'), third);
    check(a.cents + b.cents + c.cents > 60_000n, `the third purchase of ${brl(c.cents)} would take the day past the R$ 600,00 cap`);
    await until('the node to refuse it', async () => !!node.store.getOrder(c.orderId)?.cap?.refused);
    for (let i = 0; i < 4; i++) await tick();

    const ord = await rampChain.order(c.orderId);
    const metricsNow = await (await fetch(`${apiUrl}/metrics`)).text();
    const releasedAfter = Number(/^mova_lp_onramp_released_total (\d+)/m.exec(metricsNow)?.[1] ?? '0');
    check(ord.state === OrderState.LOCKED && (await pub.getBalance({ address: third })) === 0n && releasedAfter === releasedBefore,
      'refused: the order is still LOCKED, not one wei left the escrow, and the node released nothing');
    check(/^mova_lp_caps_refusals_total\{leg="onramp",reason="day"\} 1$/m.test(metricsNow), 'the refusal is counted as mova_lp_caps_refusals_total{reason="day"}');

    const refusal = await instructions(c.orderId);
    check(refusal.status === 409 && refusal.body.code === 'cap_reached'
      && !String(refusal.body.error).includes(String(a.cents + b.cents)) && !String(refusal.body.error).includes('60000'),
      `the counterparty API tells the taker the cap was reached (409 ${String(refusal.body.code)}) - and neither the total nor the limit: "${String(refusal.body.error).slice(0, 72)}…"`);

    const after = await capsOf();
    check(after.payers.length === 1 && BigInt(after.payers[0].dayCents) === a.cents + b.cents,
      'the refused payment is not counted against her either: only what the LP actually settled is');
    check(!JSON.stringify(after).includes(ANA) && !readFileSync(journalPath, 'utf8').split('\n').filter((l) => l.includes('cap.count')).some((l) => l.includes(ANA) || l.includes('orderId')),
      'neither /status nor the cap ledger in the journal holds her CPF, or any order or address beside it');
  }

  step('8. Metrics');
  const metrics = await (await fetch(`${apiUrl}/metrics`)).text();
  const val = (name: string) => Number(new RegExp(`^${name} (\\d+)`, 'm').exec(metrics)?.[1] ?? 'NaN');
  info('released (this process)', val('mova_lp_onramp_released_total'));
  info('settled (this process)', val('mova_lp_offramp_settled_total'));
  check(/^mova_lp_ready 1$/m.test(metrics) && val('mova_lp_payments_unresolved') === 0, '/metrics: ready, no unresolved payments');
  await node.stop();
  await api.close();
  const journalLines = readFileSync(journalPath, 'utf8').trim().split('\n').length;
  info('journal records', journalLines);

  step('9. The service entrypoint, as a second LP');
  {
    const cfgPath = join(dir, 'lp2.json');
    const witnessesPath = join(dir, 'witnesses.json');
    const keyPath = join(dir, 'lp2.key');
    writeFileSync(keyPath, lp2Key, { mode: 0o600 });
    writeFileSync(witnessesPath, JSON.stringify({ verifier: zktls, threshold: 2, keys: witnessKeys, urlPrefix: BANK_URL_PREFIX }), { mode: 0o600 });
    const lp2Config = (verifier: Address) => JSON.stringify({
      registry, fromBlock: deployBlock.toString(), confirmations: 2, reorgWindow: 16, pollMs: 500, lpPayerId: '98765432000110',
      onramp: {
        escrow: fiat, pixKey: 'lp2@lp.example', receiver: { name: 'Segundo LP', city: 'Recife' },
        assets: [{ asset: usdt, symbol: 'USDT', liquidity: '500000000', minOrder: '10000000', maxOrder: '100000000', verifier, rails: ['PIX'], spreadBps: 120, minSpreadBps: 20, price: { source: 'oracle' } }],
      },
    });
    const binEnv = (extra: Record<string, string>) => ({
      ...process.env, RPC_URL: RPC, LP_KEY_FILE: keyPath, PAYER_REF_SECRET: `0x${'6b'.repeat(32)}`, LP_CONFIG: cfgPath,
      STATE_FILE: join(dir, 'lp2.jsonl'), HOST: '127.0.0.1', LP_NODE_DEV: '1', CHAIN_ID: String(chainId), ...extra,
    });
    const bin = join(ROOT, 'packages/lp-node/src/bin/lp-node.ts');

    // First as it must not start: a PIX asset on a contract that is no zkTLS verifier (the MockUSD token), so it is the chain that says no.
    writeFileSync(cfgPath, lp2Config(usdt));
    const refused = spawn(process.execPath, ['--import', 'tsx', bin], { cwd: ROOT, stdio: ['ignore', 'pipe', 'pipe'], env: binEnv({ PORT: String(18_000 + Math.floor(Math.random() * 1000)) }) });
    let refusal = '';
    refused.stdout!.on('data', (d: Buffer) => { refusal += d.toString(); });
    refused.stderr!.on('data', (d: Buffer) => { refusal += d.toString(); });
    const refusedCode = await new Promise<number | null>((r) => refused.on('exit', (code) => r(code)));
    check(refusedCode === 2 && /does not prove the bank session: the escrow refuses it \(BankRailNeedsZkTls\)/.test(refusal),
      'lp-node.ts with a PIX asset on an address that is no zkTLS verifier asked it provesBankSession() on-chain, and refused to start (exit 2)');

    writeFileSync(cfgPath, lp2Config(zktls));
    const opsPort = 18_000 + Math.floor(Math.random() * 1000);
    const child = spawn(process.execPath, ['--import', 'tsx', bin], {
      cwd: ROOT, stdio: ['ignore', 'pipe', 'pipe'],
      env: binEnv({ PORT: String(opsPort), ZKTLS_WITNESS_KEYS_FILE: witnessesPath }),
    });
    let output = '';
    child.stdout!.on('data', (d: Buffer) => { output += d.toString(); });
    child.stderr!.on('data', (d: Buffer) => { output += d.toString(); });
    let ready = false;
    for (let i = 0; i < 60 && !ready; i++) {
      await sleep(500);
      ready = await fetch(`http://127.0.0.1:${opsPort}/readyz`).then((r) => r.status === 200).catch(() => false);
    }
    check(ready, 'lp-node.ts started with local zkTLS witnesses (LP_NODE_DEV), verified the contracts and the verifier, and reports /readyz 200');
    type Status = { onramp: { assets: { quoting: boolean; reason?: string; activeOfferId?: Hex }[] } };
    let status = await (await fetch(`http://127.0.0.1:${opsPort}/status`)).json() as Status;
    for (let i = 0; i < 20 && !status.onramp.assets[0].quoting; i++) {
      await sleep(500);
      status = await (await fetch(`http://127.0.0.1:${opsPort}/status`)).json() as Status;
    }
    const lp2Offer = status.onramp.assets[0].activeOfferId ? await rampChain.offer(status.onramp.assets[0].activeOfferId) : undefined;
    check(lp2Offer?.lp === privateKeyToAccount(lp2Key).address && lp2Offer.availableWei === 500n * 10n ** 6n,
      'as LP2 it posted a 500 USDT offer from its own key, read from LP_KEY_FILE');
    const exited = new Promise<number | null>((r) => child.on('exit', (code) => r(code)));
    child.kill('SIGTERM');
    const code = await exited;
    check(code === 0, 'SIGTERM: it finished its tick, closed the journal and exited 0');
    check(!output.includes(lp2Key.slice(2)) && !witnessKeys.some((k) => output.includes(k.slice(2))), 'its logs never contained its key, or its witnesses\'');
  }

  console.log('\n  \x1b[1mThe LP node quoted on Pyth\'s rate, proved every PIX and boleto by zkTLS, on the real contracts - and a crash did not pay twice.\x1b[0m\n');
}

let anvil: ChildProcess | undefined;
startAnvil()
  .then((a) => { anvil = a; return main(); })
  .catch((e: unknown) => {
    if (!(e instanceof Failed)) console.error('\nfailed:', e instanceof Error ? e.message : e);
    process.exitCode = 1;
  })
  .finally(() => {
    anvil?.kill();
    process.exit(process.exitCode ?? 0);
  });

