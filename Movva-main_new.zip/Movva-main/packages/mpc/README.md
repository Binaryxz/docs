# @mova/mpc — threshold signing (task 1.2, MPC)

2-of-2 (and t-of-n) **FROST** threshold Schnorr over secp256k1, per
[RFC 9591](https://www.rfc-editor.org/rfc/rfc9591.html), ciphersuite
`FROST(secp256k1, SHA-256)`, with keys from a **distributed key generation** (Pedersen DKG
with proofs of possession, the FROST paper's Figure 1) - there is no trusted dealer - and a
**transport** for that DKG, so the two halves can be a browser and a server rather than two
objects in one process.

```bash
npm test -w @mova/mpc                                  # 92 tests, no chain, no network
npx tsx packages/mpc/examples/two-party-sign.ts      # DKG + signing, printed step by step
npx tsx packages/mpc/examples/two-of-three.ts        # any one of three holders can vanish
```

How the device's share is protected by the passkey, and what happens when the server dies, is
in [docs/wallet-custody.md](../../docs/wallet-custody.md).

## Read this before using it

**This is not audited.** It is an implementation of a specification by one author, and it
has not been reviewed by anyone who breaks these schemes for a living. It is listed in
`docs/audit-scope.md` as the highest-priority item for external review. Do not put funds
behind it until that has happened.

That warning is not boilerplate. Everything else in this repo either is audited upstream
code or is ordinary application logic where a bug costs correctness; this is the one place
where a subtle mistake costs the key.

## Why FROST and not threshold ECDSA

The requirement is that no single party can move funds. Both schemes deliver that. They do
not cost the same to implement.

| | Threshold ECDSA (GG18, CGGMP, DKLs) | FROST (threshold Schnorr) |
|---|---|---|
| Why it is hard | ECDSA inverts a nonce, so shares cannot simply add. Needs Paillier or oblivious transfer plus a stack of zero-knowledge proofs. | Schnorr is **linear**. Partial signatures add. |
| Rounds | Several, with abort identification | Two |
| Implementation risk | Very high — this is where "looks correct, loses funds" lives | Moderate, and the spec is precise |
| On-chain verification | `ecrecover`, free | Needs a verifier contract (see below) |

Threshold ECDSA was rejected as a from-scratch implementation, and the maintained options
were not usable: `@toruslabs/tss-lib` is a WASM binding whose `precompute` expects
Web3Auth's TSS network and transport, which is neither self-contained nor easy to test.
FROST is tractable *because of a property of the mathematics*, not because a corner was cut.

## What the protocol actually does

```
key generation (DKG, src/dkg.ts)
  round 1   each party: random polynomial f_i of degree t-1; broadcasts commitments to its
            coefficients and a proof of possession of f_i(0), bound to (id, session)
  round 2   each party: verifies every proof, then sends f_i(j) privately to each party j
  finalize  each party: checks every f_i(j) against i's commitments; share s_j = sum_i f_i(j)
            group key Y = sum of the constant-term commitments - a sum of POINTS; the secret
            behind it is a sum of scalars that no machine ever performs

transport (src/dkg-transport.ts)
  `DkgSession` wraps the three calls above in signed, JSON-safe messages: round 1 broadcast,
  round 2 sealed to the recipient's X25519 key from round 1, round 3 a signed confirmation of
  the group key. Transport-agnostic - packages/cosigner carries it over HTTP.

signing (src/frost.ts)
round one   each party: two secret nonces, sends two curve points
round two   each party: one scalar  z_i = d_i + e_i*rho_i + lambda_i*s_i*c
aggregate   z = sum(z_i),  signature = (R, z)
verify      z*G == R + c*PK        ordinary Schnorr
```

A party sends two points and one scalar per signature. Nothing else. Its share is masked by
two secret nonces, so `z_i` reveals nothing about it.

## The part that is easy to get wrong

The dangerous piece of multi-party Schnorr is the nonce. In a naive one-round protocol, the
party who commits *second* can choose its nonce after seeing the first, and steer the group
nonce — which breaks the scheme (Drijvers; ROS more generally).

RFC 9591 defends against this with **two nonces per party** and a **binding factor** hashed
over the entire commitment list *and* the message. So every party's factor depends on every
other party's commitment: nobody can influence the aggregate after seeing anyone else's
contribution.

`bindingFactors()` is that defence. It is not an optimisation and it is not a detail —
remove it and the scheme is forgeable. There is a test asserting that tweaking one party's
commitment changes the *other* party's factor, and the demo prints it.

## Trust assumptions, stated plainly

- **Key generation is distributed; the dealer is gone from `src/`.** `trustedDealerKeygen`
  used to be the only keygen, so whoever ran it knew every group secret. `src/dkg.ts` replaces
  it, and the dealer survives only as a test fixture (`test/dealer.ts`) that the package does
  not export. `test/dkg.test.ts` asserts that no export can produce or return a group secret,
  and that no scalar in any participant's transcript is the secret or maps to the group key.
- **The DKG verifies everything and names who cheated.** Every proof of possession and every
  share is checked; a failure throws `DkgError` with `faults` (participant, reason) and
  `culprits`. The tests perform each attack: a tampered share, a tampered or rogue-key proof,
  a genuine proof replayed under another session or copied under another identifier, a zero
  secret, duplicate or missing packages, and **equivocation** - a party showing different
  commitments to different peers, which would otherwise leave two honest parties with
  different group keys. That last one is caught by a transcript hash carried in every round-2
  message; blame there is necessarily ambiguous, and the run aborts.
- **DKG state is single-use, and consumed even on failure.** Round state is an opaque handle;
  a copy, a deserialised object or a second call is refused. A failed run is abandoned rather
  than retried with the same polynomial, since round 2 against a different peer set would hand
  its evaluations to whoever those peers are.
- **The channel is `src/dkg-transport.ts`, and it is not optional.** `src/dkg.ts` on its own
  assumes an authenticated broadcast for round 1 and authenticated, encrypted point-to-point
  delivery for round 2 (`DkgShareMessage.share` is a secret); a man in the middle on an
  unauthenticated channel is simply a participant. `DkgSession` provides both - see the next
  section. Using `dkgRound1`/`dkgRound2`/`dkgFinalize` directly across a network without it is
  a mistake. The session `context` must be fresh per run (at least 16 bytes; `dkgContext` adds
  32 random ones), and threshold 1 is refused because every share would then *be* the group
  secret.
- **Nonces are single-use, and enforced.** Reusing a Schnorr nonce across two signatures
  reveals the share by algebra. `commit()` returns an opaque handle; `sign()` consumes it,
  so a second `sign()` with the same handle throws, and a copied, serialised or restored
  handle is refused. `sign()` also checks that its own commitment appears exactly once in
  the coordinator's list and is the one it made.
- **Nonce generation is hedged, not deterministic.** Each nonce is RFC 9591 §4.1's
  `H3(random_bytes(32) || share)`: a predictable RNG does not reveal a nonce without the
  share, but a *repeating* RNG repeats nonces. There is no deterministic fallback.
- **Hashing is this library's own, not the RFC's exact encoding.** The domain-separated
  hash-to-scalar and the message hashing in the binding factor and challenge differ from RFC
  9591's `hash_to_field` construction, and `contracts/SchnorrVerifier.sol` matches this
  library, not the RFC. Signatures verify as ordinary Schnorr; they will not interoperate with
  another RFC 9591 implementation's test vectors.
- **The coordinator is untrusted** and learns nothing it did not already have. A dishonest
  one can produce an invalid signature, which `verify` rejects, but cannot produce a valid
  signature over a different message.

## The transport: `DkgSession`

```ts
const session = DkgSession.open({ party: 1, params, identities, auth });   // identities: every
const r1 = await session.broadcast();                                      // party's long-term key
const mine = await session.round2([theirRound1]);                          // one per other party
const { result, confirmation } = await session.finish([theirRound2]);
await session.confirm([theirConfirmation]);                                // same key, same transcript
```

**What is signed.** Every message, by its sender's long-term key, over
`SHA256(DST || version || round || sessionId || from || to || transcript || SHA256(payload))`.
The scheme is the caller's (`DkgAuth`): `secp256k1Auth` is the default, and packages/cosigner
signs with the co-signer's own ECDSA key on one side and a per-run key a passkey authorised on
the other. This layer decides only *what* is signed, and refuses anything that does not verify
under the key it was **given** for that party - never a key a message names.

**What the transcript binds,** and why each part is in it:

| bound | why |
|---|---|
| the session id (context, threshold, participant set) | a message cannot be replayed into a run with other parameters |
| every party's long-term public key | a run is bound to *who* is in it, so a recorded message cannot be replayed into a later run with one identity swapped |
| every party's whole round-1 payload: commitments, proof of possession, X25519 key | a party showing different commitments to different peers - equivocation - gives them different transcripts, and round 2 aborts naming it; and no peer can be steered onto an encryption key the others never saw |

Round 2 and round 3 carry that hash and sign it, so neither side can be shown a different
transcript than the other without one of them stopping. The DKG's own transcript travels
*inside* the sealed payload and is checked by `dkgFinalize`: two independent equivocation
checks, one of them the protocol's own.

**What is encrypted.** Only round 2, the only secret. A fresh X25519 ephemeral to the
recipient's round-1 key, HKDF-SHA256 to a one-message key (salt: the session id; info: the
domain, both party ids, the transcript and both public keys), XChaCha20-Poly1305 with the
envelope repeated as associated data. So the server never sees the device's share and the
device never sees the server's, and a relay carries bytes it cannot read. The signature is over
the **ciphertext**, so a tampered one is refused before any key is derived.

**What is refused,** always by aborting and naming the party: `session-reused`, `replayed`,
`duplicate`, `missing`, `wrong-round`, `wrong-session`, `misrouted`, `unexpected-sender`,
`unauthenticated`, `malformed`, `inconsistent-transcript`, `undecryptable`, `protocol`. A failed
session is dead - every further call throws - which is `dkg.ts`'s "a failed DKG is abandoned"
rule carried into the transport. `test/dkg-transport.test.ts` has one test per refusal, plus
full 2-of-2 and 2-of-3 runs, and `test/dkg-onchain.test.ts` runs a key made over the transport
through `FrostSigner` on an EVM.

## On-chain

`contracts/SchnorrVerifier.sol` verifies these signatures on-chain, and `FrostSigner`
exposes that through ERC-1271 so a Safe can have a threshold group as an owner.

Ethereum has no secp256k1 point-multiplication precompile, and doing it in Solidity costs
hundreds of thousands of gas. The verifier instead coerces `ecrecover` into computing the
combination: `ecrecover(h, v, r, s)` evaluates `r⁻¹(s·R′ − h·G)`, so choosing `R′ = PK`,
`s = −c·PKx` and `h = −z·PKx` yields exactly `z·G − c·PK`. One precompile call.

```bash
npx tsx packages/smart-account/examples/mpc-owner.ts [<ppEntrypoint> <ppPool>]
```

That runs a Safe whose **single owner** is the FROST group — so the chain sees one signature
and cannot distinguish threshold signing from a plain key, which is the property multisig
cannot offer. The group comes from a DKG between device and server, and the device's share is
stored only sealed under the passkey's PRF (`packages/smart-account/src/sealed-share.ts`), so
every signing session starts with a passkey assertion. Observed on a mainnet fork: another
passkey and the pool-seed PRF output both refused by the seal, each party alone rejected by the
verifier, a signature over another digest rejected, and the UserOperation executed (438k gas
for a transfer, including the Safe deployment).

**It is not the shipping default.** Safe 2-of-2 with the passkey and the server as two on-chain
owners (`examples/passkey-owner.ts`) is the recommended production configuration until this
package and `SchnorrVerifier.sol` have been externally audited; FROST is the single-signature
option for when one indistinguishable signature is a product requirement.

Two things a reviewer should weigh, both documented in the contract:

- `ecrecover` returns an **address**, so the comparison is 160 bits rather than the full
  x-coordinate. Forging needs a `z` landing on a fixed address — 2^160, not a 2^80
  birthday, and the challenge depends on `R` so `R` cannot be chosen after `z`. It is the
  same trade widely deployed Schnorr verifiers make, but it is a trade.
- The challenge is recomputed **in Solidity** and must match the TypeScript byte for byte.
  A differential test in `contracts/test/SchnorrVerifier.t.sol` runs vectors generated by
  `scripts/gen-vectors.ts` for exactly this reason; regenerate them after touching either
  side. The vectors are signed by DKG keys (three 2-of-2 groups, two 2-of-3 groups signed by
  different pairs), and `test/dkg-onchain.test.ts` additionally runs FRESH DKG keys through
  `FrostSigner` on an EVM on every `vitest` run.

One bug worth recording, because a unit test would not have caught it: Safe 1.4.1 calls the
**legacy** `isValidSignature(bytes,bytes)` overload for contract owners and compares against
`0x20c13b0b`, not EIP-1271's `0x1626ba7e`. Returning the wrong constant fails with an opaque
`AA24` from the EntryPoint. Found by running a real UserOperation, and now pinned by a test.
