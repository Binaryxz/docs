/**
 * A 2-of-2 FROST signing session, printed step by step.
 *
 *   npx tsx packages/mpc/examples/two-party-sign.ts
 *
 * Two parties - the user's device and the server co-signer - produce one signature under a
 * key that neither of them holds and that is never assembled anywhere. The point of running
 * it is to watch what each party actually sends: two curve points in round one, one scalar
 * in round two, and nothing else.
 */
import {
  commit, sign, aggregate, verify, verifyShare,
  bindingFactors, groupCommitment, challenge, Point,
} from '../src/frost.js';
import { dkgRound1, dkgRound2, dkgFinalize, dkgContext } from '../src/dkg.js';

const step = (n: string) => console.log(`\n\x1b[1m${n}\x1b[0m`);
const ok = (s: string) => console.log(`  \x1b[32mOK\x1b[0m    ${s}`);
const bad = (s: string) => { console.log(`  \x1b[31mFAIL\x1b[0m  ${s}`); process.exitCode = 1; };
const info = (k: string, v: unknown) => console.log(`        ${String(k).padEnd(22)} ${v}`);
const short = (s: string) => `${s.slice(0, 20)}...`;

const message = new TextEncoder().encode(
  process.argv[2] ?? 'withdraw R$ 250,00 to PIX key ***@***.br',
);

step('1. Key generation (distributed - no dealer)');
// Each party runs its own rounds on its own machine; they share a process here only so the demo
// is self-contained. The server proposes the context; the device checks the label and joins.
const params = { context: dkgContext('two-party demo'), threshold: 2, participants: [1, 2] };
const dev1 = dkgRound1(1, params);
const srv1 = dkgRound1(2, params);
info('device broadcasts', `2 commitments + proof of possession (${short(dev1.broadcast.commitments[0]!.toHex(true))})`);
info('server broadcasts', `2 commitments + proof of possession (${short(srv1.broadcast.commitments[0]!.toHex(true))})`);
const dev2 = dkgRound2(dev1.state, [srv1.broadcast]);
const srv2 = dkgRound2(srv1.state, [dev1.broadcast]);
ok("each verified the other's proof of possession before sending anything secret");
info('device -> server', 'f_device(2), one scalar, over an encrypted channel');
info('server -> device', 'f_server(1), one scalar, over an encrypted channel');
const devOut = dkgFinalize(dev2.state, srv2.messages);
const srvOut = dkgFinalize(srv2.state, dev2.messages);
ok("each checked the share it received against the sender's commitments");
if (devOut.publicKeys.transcript !== srvOut.publicKeys.transcript
  || !devOut.publicKeys.groupPublicKey.equals(srvOut.publicKeys.groupPublicKey)) {
  bad('the two parties finished different runs');
}
const device = devOut.keyShare;
const server = srvOut.keyShare;
const groupPublicKey = devOut.publicKeys.groupPublicKey;
const verificationShare = (id: number) => devOut.publicKeys.verificationShares.get(id)!;
info('group public key', short(groupPublicKey.toHex(true)));
info('device holds', `share #${device.id} (a scalar, not the key)`);
info('server holds', `share #${server.id}`);
if (verificationShare(1).equals(groupPublicKey)) {
  bad('a single share equals the group key - the split did nothing');
} else {
  ok('neither share is the group key, and no machine ever computed the group secret');
}
console.log('        \x1b[2m(the group key is the sum of the two public commitments; the secret');
console.log('         behind it is a sum nobody performed)\x1b[0m');

step('2. Round one — each party commits to nonces');
const d = commit(device);
const s = commit(server);
const commitments = [d.commitment, s.commitment];
info('device sends', `${short(d.commitment.hiding.toHex(true))} + binding point`);
info('server sends', `${short(s.commitment.hiding.toHex(true))} + binding point`);
ok('two curve points each; no secret leaves either machine');

step('3. Binding factors — why the second party cannot cheat');
const factors = bindingFactors(commitments, message, groupPublicKey);
const R = groupCommitment(commitments, factors);
info('rho(device)', short(factors.get(1)!.toString(16)));
info('rho(server)', short(factors.get(2)!.toString(16)));
info('group nonce R', short(R.toHex(true)));
// Whoever commits second cannot steer R: tweaking one commitment changes BOTH factors.
const tweaked = [commitments[0]!, {
  ...commitments[1]!, binding: commitments[1]!.binding.add(Point.BASE),
}];
const after = bindingFactors(tweaked, message, groupPublicKey);
if (after.get(1) === factors.get(1)) {
  bad("the other party's binding factor did not change - nonce grinding is possible");
} else {
  ok('changing one commitment changes every binding factor — no nonce grinding');
}

step('4. Round two — partial signatures');
const zd = sign(device, d.nonces, commitments, message);
const zs = sign(server, s.nonces, commitments, message);
info('device sends', short(zd.z.toString(16)));
info('server sends', short(zs.z.toString(16)));
ok('one scalar each, masked by two secret nonces');

if (!verifyShare(zd, commitments, message, groupPublicKey, verificationShare(1))
 || !verifyShare(zs, commitments, message, groupPublicKey, verificationShare(2))) {
  bad('a partial signature failed its own check');
} else {
  ok('each partial verifies on its own, so a bad party can be named');
}

step('5. Aggregate');
const signature = aggregate(commitments, [zd, zs], message, groupPublicKey);
info('challenge c', short(challenge(signature.R, groupPublicKey, message).toString(16)));
info('signature z', short(signature.z.toString(16)));
if (!verify(signature, message, groupPublicKey)) bad('aggregate signature is invalid');
else ok('valid Schnorr signature under a key neither party ever held');

step('6. What one party alone can do');
try {
  aggregate(commitments, [zd], message, groupPublicKey);
  bad('aggregation accepted a single share');
} catch {
  ok('aggregation refuses a single share');
}
// The device's round-two nonces were spent in step 4, and signing again with them is exactly
// the reuse that leaks a share - `sign` refuses it. So the solo attempt commits afresh.
try {
  sign(device, d.nonces, [d.commitment], message);
  bad('the device signed twice with one nonce pair');
} catch {
  ok('spent nonces are refused: no second signature from the same nonce pair');
}
const fresh = commit(device);
const soloCommit = [fresh.commitment];
const solo = aggregate(
  soloCommit, [sign(device, fresh.nonces, soloCommit, message)], message, groupPublicKey,
);
if (verify(solo, message, groupPublicKey)) bad('the device signed alone');
else ok('signing alone produces a signature that does not verify under the group key');

step('7. Wrong message');
if (verify(signature, new TextEncoder().encode('withdraw R$ 25.000,00'), groupPublicKey)) {
  bad('the signature verified against a different amount');
} else {
  ok('the signature is bound to this message only');
}

console.log('\n  2-of-2 FROST: one signature, two parties, key never assembled.');
console.log('  \x1b[2mNot audited. See packages/mpc/README.md before putting funds behind it.\x1b[0m');
