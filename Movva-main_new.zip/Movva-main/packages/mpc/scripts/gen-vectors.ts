/**
 * Emit Solidity test vectors from the TypeScript FROST implementation.
 *
 * The point of the differential test these feed is that the on-chain challenge computation
 * has to match the library byte for byte. If it diverges, nothing verifies - so regenerating
 * these after touching either side is how the divergence stays loud instead of silent.
 *
 * Keys come from the DKG (`src/dkg.ts`), the only key generation the package ships: three
 * 2-of-2 groups and two 2-of-3 groups signed by different pairs, so the on-chain test covers
 * Lagrange coefficients other than the 2-of-2 case.
 *
 *   npx tsx packages/mpc/scripts/gen-vectors.ts
 */
import { commit, sign, aggregate, verify, type KeyShare } from '../src/frost.js';
import { dkgRound1, dkgRound2, dkgFinalize, dkgContext, type DkgParams } from '../src/dkg.js';
import { randomBytes } from '@noble/hashes/utils';

const hex = (v: bigint) => `0x${v.toString(16).padStart(64, '0')}`;
const out: string[] = [];

function dkg(p: DkgParams): Map<number, KeyShare> {
  const r1 = new Map(p.participants.map((id) => [id, dkgRound1(id, p)]));
  const all = [...r1.values()].map((r) => r.broadcast);
  const r2 = new Map(p.participants.map((id) => [id, dkgRound2(r1.get(id)!.state, all.filter((b) => b.from !== id))]));
  const msgs = [...r2.values()].flatMap((r) => r.messages);
  return new Map(p.participants.map((id) => [id, dkgFinalize(r2.get(id)!.state, msgs.filter((m) => m.to === id)).keyShare]));
}

const cases: { label: string; participants: number[]; signers: number[] }[] = [
  { label: '2-of-2 DKG', participants: [1, 2], signers: [1, 2] },
  { label: '2-of-2 DKG', participants: [1, 2], signers: [1, 2] },
  { label: '2-of-2 DKG', participants: [1, 2], signers: [1, 2] },
  { label: '2-of-3 DKG, signed by 1 and 3', participants: [1, 2, 3], signers: [1, 3] },
  { label: '2-of-3 DKG, signed by 2 and 3', participants: [1, 2, 3], signers: [2, 3] },
];

cases.forEach((c, i) => {
  const digest = randomBytes(32);                 // what a Safe would pass to ERC-1271
  const keys = dkg({ context: dkgContext(`gen-vectors-${i}`), threshold: 2, participants: c.participants });
  const signers = c.signers.map((id) => keys.get(id)!);
  const groupPublicKey = signers[0]!.groupPublicKey;
  const rounds = signers.map((s) => ({ share: s, ...commit(s) }));
  const commitments = rounds.map((r) => r.commitment);
  const sigShares = rounds.map((r) => sign(r.share, r.nonces, commitments, digest));
  const sig = aggregate(commitments, sigShares, digest, groupPublicKey);
  if (!verify(sig, digest, groupPublicKey)) throw new Error('TS verify failed');

  const pk = groupPublicKey.toAffine();
  const R = sig.R.toAffine();
  out.push([
    `        // vector ${i}: ${c.label}`,
    `        _vectors.push(Vector({`,
    `            groupX: ${hex(pk.x)},`,
    `            groupY: ${hex(pk.y)},`,
    `            rx: ${hex(R.x)},`,
    `            ry: ${hex(R.y)},`,
    `            z: ${hex(sig.z)},`,
    `            digest: 0x${Buffer.from(digest).toString('hex')}`,
    `        }));`,
  ].join('\n'));
});
console.log(out.join('\n'));
