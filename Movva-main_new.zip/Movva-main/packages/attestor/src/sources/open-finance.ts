/**
 * An LP's account at another institution, read by this PSP under the LP's Open Finance Brasil consent.
 *
 * ## No longer read by the attestor
 *
 * The attestor service signed PIX credits from this source until PIX left the attestor quorum: PIX, boleto
 * and TED now settle only on a zkTLS proof of the bank session (`IAttestorVerifier.provesBankSession`; the
 * escrows revert `BankRailNeedsZkTls` for a bank-rail offer or sale through a quorum), so the service refuses
 * every PIX request and its entrypoint refuses a sources file naming `open-finance`. This module is kept as a
 * `BankFactSource`: a working Open Finance Brasil account-data client (FAPI `private_key_jwt`, consent checks,
 * the operational call budget) that reads what a bank shows about credits to an account, which an LP still
 * needs before asking for a zkTLS session over a payment, or to reconcile. Where the text below speaks of "the
 * service" and "an attestation", it describes what the reader could vouch for when it fed the attestor; the
 * three consequences of the schema hold for any caller.
 *
 * ## The specifications this was written from (read 2026-09-14)
 *
 *  - **API Accounts 2.4.2** - github.com/OpenBanking-Brasil/openapi, `swagger-apis/accounts/2.4.2.yml`
 *    (https://raw.githubusercontent.com/OpenBanking-Brasil/openapi/main/swagger-apis/accounts/2.4.2.yml).
 *    Server `.../open-banking/accounts/v2`. 2.5.0-beta.2 was checked for the fields below and adds
 *    `codeISPB` and `typeAdditionalInfo`, nothing else this module uses.
 *  - **API Consents 3.3.1** - `swagger-apis/consents/3.3.1.yml` in the same repository. Server
 *    `.../open-banking/consents/v3`.
 *  - **Open Finance Brasil FAPI Security Profile 1.0, Implementers Draft 3** -
 *    github.com/OpenBanking-Brasil/specs-seguranca `open-banking-brasil-financial-api-1_ID3.md`, and its
 *    Confluence page (openfinancebrasil.atlassian.net/wiki/spaces/OF/pages/240649123, updated 22/03/2024).
 *  - **Open Finance Brasil DCR 1.0, Implementers Draft 3** - specs-seguranca
 *    `open-banking-brasil-dynamic-client-registration-1_ID3.md`.
 *  - **Limites operacionais** - openfinancebrasil.atlassian.net/wiki/spaces/OF/pages/17924220 (updated
 *    13/06/2025).
 *
 * ## The data calls
 *
 *  - `GET /consents/{consentId}` (Consents 3.3.1), OAuth2 client credentials, scope `consents`. `data.status`
 *    is `AWAITING_AUTHORISATION | AUTHORISED | REJECTED`; data may be read only under `AUTHORISED`.
 *    `data.permissions` must still hold `ACCOUNTS_READ` and `ACCOUNTS_TRANSACTIONS_READ` (a transmitter may
 *    return a subset of what was asked), and `data.expirationDateTime`, when present, must be in the future.
 *    Consent calls are outside the operational limits, so the check runs before every lookup (cached briefly).
 *  - `GET /accounts/{accountId}` (permission `ACCOUNTS_READ`): the account's `compeCode`, `branchCode`,
 *    `number`, `checkDigit`, compared once with the account the PSP onboarded - the consent is to THAT account.
 *  - `GET /accounts/{accountId}/transactions-current` (permission `ACCOUNTS_TRANSACTIONS_READ`), query
 *    `fromBookingDateMaxLimited` / `toBookingDateMaxLimited` (dates; at most 7 days in the past),
 *    `creditDebitIndicator=CREDITO`, `page-size` (max 1000), following `links.next`. Headers:
 *    `Authorization: Bearer`, `x-fapi-interaction-id` (UUID, mandatory; FAPI-BR 5.2.3: "shall send header
 *    x-fapi-interaction-id on FAPI endpoints"). `x-fapi-auth-date` and `x-fapi-customer-ip-address` are for
 *    customer-present calls and are not sent. Errors are `{ errors: [{ code, title, detail }] }` - never
 *    passed on, since `detail` may echo what was sent.
 *
 * ## Which fields identify a PIX credit - and which do not exist
 *
 * A transaction (`AccountTransactionsData`) is a settled PIX credit when `type = PIX`,
 * `creditDebitType = CREDITO` and `completedAuthorisedPaymentType = TRANSACAO_EFETIVADA` (not
 * `LANCAMENTO_FUTURO`, not `TRANSACAO_PROCESSANDO`). Its amount is `transactionAmount.amount`
 * (`^\d{1,15}\.\d{2,4}$`, `currency` `BRL`), its time `transactionDateTime`, its counterpart
 * `partieCnpjCpf`, `partiePersonType`, `partieCompeCode`, `partieBranchCode`, `partieNumber`,
 * `partieCheckDigit`, and its id `transactionId` - "código ou identificador único prestado pela
 * instituição", pattern `^[a-zA-Z0-9][a-zA-Z0-9-]{0,99}$`.
 *
 * **There is no end-to-end id and no credited PIX key in the schema** (2.4.2, nor 2.5.0-beta.2), and a
 * refund (devolução) is a separate DEBITO entry not linked to the credit. Three consequences, each enforced:
 *
 *  1. The id this source reports - and so the `bankTxId` an attestation made from it carries - is the
 *     transmitter's `transactionId`, not the e2eid IAttestorVerifier names for PIX. It is assigned by the
 *     institution, never by the payer, so replay protection holds; but an attestation from this source and
 *     one from API Pix for the SAME credit carry different bankTxIds and cannot be combined in one quorum
 *     proof - and must never both exist, which is why an LP has one source (source.ts).
 *  2. The payee is the ACCOUNT credited. The PIX keys bound to it are established by the PSP at onboarding
 *     (a DICT lookup, which only an SPI participant can make) and configured here; the service accepts a
 *     disclosed key only if it is one of them.
 *  3. `returnedCents` is always 0: this source cannot see a refund of a particular credit.
 *
 * Boletos: a `type = BOLETO` credit has an amount and a time but no line, barcode or authentication code,
 * so it cannot show WHICH boleto was paid. This source does not offer `boletoPayment`. Off-ramp payments
 * (a DEBITO to the seller) show the counterpart's account, never the key, so they cannot open a seller's
 * key commitment either; the service refuses them as a payee it cannot see.
 *
 * ## Operational limits, which shape the caching
 *
 * Transmitters must serve at least 240 successful calls a month per endpoint, per client (CPF/CNPJ), per
 * resource for high-frequency endpoints; paginated follow-ups do not count; beyond the limit they answer
 * HTTP 423. That is about eight lookups a day. So a transaction list is cached per booking-date window and
 * re-read at most every `minRefreshMs`; a lookup that misses the cache inside that interval is refused as
 * rate-limited rather than spending the month, and a 423 is reported as such.
 *
 * ## FAPI: what is implemented, and what stays behind `FapiSession`
 *
 * FAPI-BR (5.2.3) requires of a confidential client: mTLS with an ICP-Brasil (BRCAC) transport
 * certificate and certificate-bound tokens (RFC 8705), PAR, PS256 request objects, JARM, refresh tokens
 * without rotation, and the parameterised scope `consent:<consentId>`. DCR (ID3) requires a software
 * statement assertion issued by the Directory of Participants (PS256, `iat` at most 5 minutes old), with
 * `token_endpoint_auth_method` `private_key_jwt` or `tls_client_auth`, and the DADOS role for `accounts`
 * and `consents` scopes.
 *
 * Implemented here (`PrivateKeyJwtSession`): the two token grants a running attestor makes - client
 * credentials for `consents`, and refresh-token for the consent-bound `accounts` token - authenticated with
 * a PS256 `private_key_jwt` assertion over the mTLS agent. Not implemented, because none of it can be
 * exercised without being a registered participant: Directory enrolment and the SSA, DCR at each
 * transmitter, and the consent authorisation itself (POST /consents, then PAR + redirect + JARM +
 * code exchange, with the LP's representative authenticating at their bank). Whatever performs those hands
 * this module a refresh token and a client id; a different `FapiSession` can replace the whole thing.
 */
import { constants, createPrivateKey, randomUUID, sign, type KeyObject } from 'node:crypto';
import { request as httpRequest } from 'node:http';
import { Agent as HttpsAgent, request as httpsRequest } from 'node:https';
import {
  SourceError, type AccountRef, type BankFactSource, type PaymentQuery, type PixCredit, type SourceHealth,
} from '../source.js';

export type FapiScope = 'accounts' | 'consents';

export interface FapiSession {
  /** mTLS with the transport certificate registered at DCR. Access tokens are bound to it (RFC 8705). */
  readonly agent?: HttpsAgent;
  /** `consents`: a client-credentials token. `accounts`: the token for `consent:<consentId>`. */
  accessToken(scope: FapiScope): Promise<string>;
  /** A resource server refused the token: forget it. */
  invalidate(scope: FapiScope): void;
}

interface HttpResponse { status: number; body: string }

function send(url: URL, o: { method: string; headers: Record<string, string>; body?: string; agent?: HttpsAgent; timeoutMs: number }): Promise<HttpResponse> {
  return new Promise((resolve, reject) => {
    const https = url.protocol === 'https:';
    const req = (https ? httpsRequest : httpRequest)(url, {
      method: o.method,
      headers: { ...o.headers, ...(o.body !== undefined ? { 'content-length': String(Buffer.byteLength(o.body)) } : {}) },
      ...(https && o.agent ? { agent: o.agent } : {}),
      timeout: o.timeoutMs,
    }, (res) => {
      const chunks: Buffer[] = [];
      res.on('data', (c: Buffer) => chunks.push(c));
      res.on('end', () => resolve({ status: res.statusCode ?? 0, body: Buffer.concat(chunks).toString('utf8') }));
      res.on('error', reject);
    });
    req.on('timeout', () => req.destroy(new Error('request timed out')));
    req.on('error', reject);
    if (o.body !== undefined) req.write(o.body);
    req.end();
  });
}

const b64url = (b: Buffer | string) => Buffer.from(b).toString('base64url');

export interface PrivateKeyJwtOptions {
  /** The transmitter's token endpoint, from its OpenID discovery document. */
  tokenUrl: string;
  /** The client id DCR issued at this transmitter. */
  clientId: string;
  /** The RSA private key whose public half is in the client's registered JWKS. */
  signingKey: KeyObject | string;
  kid: string;
  /** From the consent's authorisation (PAR + JARM + code exchange), done outside this module. Not rotated (FAPI-BR 5.2.3). */
  refreshToken: string;
  tls?: { cert: string | Buffer; key: string | Buffer; ca?: string | Buffer };
  timeoutMs?: number;
  /** Milliseconds. */
  now?: () => number;
}

/** Client credentials and refresh-token grants, authenticated by a PS256 `private_key_jwt` assertion (RFC 7523). */
export class PrivateKeyJwtSession implements FapiSession {
  readonly agent?: HttpsAgent;
  private readonly key: KeyObject;
  private readonly tokens = new Map<FapiScope, { value: string; expiresAt: number }>();

  constructor(private readonly o: PrivateKeyJwtOptions) {
    this.key = typeof o.signingKey === 'string' ? createPrivateKey(o.signingKey) : o.signingKey;
    if (o.tls) this.agent = new HttpsAgent({ cert: o.tls.cert, key: o.tls.key, ca: o.tls.ca, keepAlive: true });
  }

  private now(): number {
    return this.o.now ? this.o.now() : Date.now();
  }

  /** The client assertion: iss = sub = client id, aud = the token endpoint, a unique jti, one minute of life. */
  clientAssertion(): string {
    const iat = Math.floor(this.now() / 1000);
    const header = b64url(JSON.stringify({ alg: 'PS256', kid: this.o.kid, typ: 'JWT' }));
    const payload = b64url(JSON.stringify({ iss: this.o.clientId, sub: this.o.clientId, aud: this.o.tokenUrl, jti: randomUUID(), iat, exp: iat + 60 }));
    const signature = sign('sha256', Buffer.from(`${header}.${payload}`), {
      key: this.key, padding: constants.RSA_PKCS1_PSS_PADDING, saltLength: constants.RSA_PSS_SALTLEN_DIGEST,
    });
    return `${header}.${payload}.${b64url(signature)}`;
  }

  async accessToken(scope: FapiScope): Promise<string> {
    const cached = this.tokens.get(scope);
    if (cached && cached.expiresAt > this.now()) return cached.value;
    const form = new URLSearchParams(scope === 'consents'
      ? { grant_type: 'client_credentials', scope: 'consents' }
      : { grant_type: 'refresh_token', refresh_token: this.o.refreshToken });
    form.set('client_id', this.o.clientId);
    form.set('client_assertion_type', 'urn:ietf:params:oauth:client-assertion-type:jwt-bearer');
    form.set('client_assertion', this.clientAssertion());
    let res: HttpResponse;
    try {
      res = await send(new URL(this.o.tokenUrl), {
        method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded', accept: 'application/json' },
        body: form.toString(), agent: this.agent, timeoutMs: this.o.timeoutMs ?? 15_000,
      });
    } catch {
      throw new SourceError('unavailable', 'the token endpoint could not be reached');
    }
    if (res.status !== 200) {
      // invalid_grant on a refresh token means the consent is gone or was never authorised.
      throw new SourceError(scope === 'accounts' && res.status === 400 ? 'consent' : 'unavailable', `the token endpoint answered ${res.status}`);
    }
    let j: { access_token?: unknown; expires_in?: unknown };
    try { j = JSON.parse(res.body) as typeof j; } catch { throw new SourceError('malformed', 'the token response is not JSON'); }
    if (typeof j.access_token !== 'string') throw new SourceError('malformed', 'the token response has no access_token');
    const ttl = typeof j.expires_in === 'number' ? j.expires_in : 300;
    this.tokens.set(scope, { value: j.access_token, expiresAt: this.now() + Math.max(0, ttl - 30) * 1000 });
    return j.access_token;
  }

  invalidate(scope: FapiScope): void {
    this.tokens.delete(scope);
  }
}

export interface OpenFinanceSourceOptions {
  /** Including the version: `https://api.bank.example/open-banking/accounts/v2`. */
  accountsBaseUrl: string;
  /** `https://api.bank.example/open-banking/consents/v3`. */
  consentsBaseUrl: string;
  consentId: string;
  accountId: string;
  /** The account the PSP onboarded. The consented account must be this one. */
  account: AccountRef;
  /** The PIX keys the PSP verified belong to `account` (DICT), at onboarding. */
  pixKeys: readonly string[];
  session: FapiSession;
  /** Re-read a transaction list at most this often. Default 60 s. */
  minRefreshMs?: number;
  /** Re-check the consent at most this often. Default 30 s. */
  consentCacheMs?: number;
  timeoutMs?: number;
  /** Milliseconds. */
  now?: () => number;
}

/** Consents 3.3.1: permissions this source needs to hold. */
export const REQUIRED_PERMISSIONS = ['ACCOUNTS_READ', 'ACCOUNTS_TRANSACTIONS_READ'] as const;

const CONSENT_ID = /^urn:[a-zA-Z0-9][a-zA-Z0-9-]{0,31}:[a-zA-Z0-9()+,\-.:=@;$_!*'%/?#]+$/;
const TRANSACTION_ID = /^[a-zA-Z0-9][a-zA-Z0-9-]{0,99}$/;
const AMOUNT = /^(\d{1,15})\.(\d{2})(\d{0,2})$/;
const DAY = 86_400_000;
/** `transactions-current` reaches 7 days back; one day of margin for the transmitter's own clock. */
const MAX_DAYS_BACK = 6;
const MAX_PAGES = 50;

interface OfTransaction {
  transactionId?: unknown;
  completedAuthorisedPaymentType?: unknown;
  creditDebitType?: unknown;
  type?: unknown;
  transactionAmount?: { amount?: unknown; currency?: unknown };
  transactionDateTime?: unknown;
}

/** A Brasília calendar date (UTC-3, no daylight saving since 2019), which is what booking dates are. */
const brasiliaDate = (ms: number) => new Date(ms - 3 * 3_600_000).toISOString().slice(0, 10);

export class OpenFinanceSource implements BankFactSource {
  readonly kind = 'open-finance';
  private consentCheck?: { at: number; error?: SourceError };
  private identity?: AccountRef;
  private readonly lists = new Map<string, { at: number; txs: Map<string, OfTransaction> }>();

  constructor(private readonly o: OpenFinanceSourceOptions) {
    if (!CONSENT_ID.test(o.consentId)) throw new Error('consentId is not a Consents API URN');
    if (!TRANSACTION_ID.test(o.accountId)) throw new Error('accountId does not match the Accounts API pattern');
    if (o.pixKeys.length === 0) throw new Error('an Open Finance source needs the PIX keys bound to its account at onboarding');
  }

  private now(): number {
    return this.o.now ? this.o.now() : Date.now();
  }

  private async get(scope: FapiScope, url: URL): Promise<unknown> {
    for (let attempt = 0; attempt < 2; attempt++) {
      const token = await this.o.session.accessToken(scope);
      let res: HttpResponse;
      try {
        res = await send(url, {
          method: 'GET', agent: this.o.session.agent, timeoutMs: this.o.timeoutMs ?? 15_000,
          headers: { authorization: `Bearer ${token}`, accept: 'application/json', 'x-fapi-interaction-id': randomUUID() },
        });
      } catch {
        throw new SourceError('unavailable', `the ${scope} API could not be reached`);
      }
      if (res.status === 401 && attempt === 0) {
        this.o.session.invalidate(scope);
        continue;
      }
      if (res.status === 423 || res.status === 429 || res.status === 529) throw new SourceError('rate_limited', `the ${scope} API answered ${res.status}`);
      if (res.status === 401 || res.status === 403) throw new SourceError('consent', `the ${scope} API answered ${res.status}`);
      if (res.status === 404) return undefined;
      if (res.status < 200 || res.status >= 300) throw new SourceError('unavailable', `the ${scope} API answered ${res.status}`);
      try {
        return JSON.parse(res.body) as unknown;
      } catch {
        throw new SourceError('malformed', `the ${scope} API answered with something other than JSON`);
      }
    }
    throw new SourceError('consent', `the ${scope} API refused a fresh token`);
  }

  /** Consents 3.3.1 `GET /consents/{consentId}`: AUTHORISED, holding the permissions, not expired. */
  async checkConsent(): Promise<void> {
    const cache = this.o.consentCacheMs ?? 30_000;
    if (this.consentCheck && this.now() - this.consentCheck.at < cache) {
      if (this.consentCheck.error) throw this.consentCheck.error;
      return;
    }
    let error: SourceError | undefined;
    try {
      const url = new URL(`${this.o.consentsBaseUrl.replace(/\/$/, '')}/consents/${encodeURIComponent(this.o.consentId)}`);
      const j = await this.get('consents', url) as { data?: { status?: unknown; permissions?: unknown; expirationDateTime?: unknown } } | undefined;
      const d = j?.data;
      if (!d) error = new SourceError('consent', 'the transmitter has no such consent');
      else if (d.status !== 'AUTHORISED') error = new SourceError('consent', 'the consent is not AUTHORISED');
      else if (!Array.isArray(d.permissions) || !REQUIRED_PERMISSIONS.every((p) => (d.permissions as unknown[]).includes(p))) {
        error = new SourceError('consent', 'the consent does not hold ACCOUNTS_READ and ACCOUNTS_TRANSACTIONS_READ');
      } else if (typeof d.expirationDateTime === 'string' && !(Date.parse(d.expirationDateTime) > this.now())) {
        error = new SourceError('consent', 'the consent has expired');
      }
    } catch (e) {
      // A rate limit or an outage is not a verdict on the consent: do not cache it as one.
      if (e instanceof SourceError && e.code !== 'consent') throw e;
      error = e instanceof SourceError ? e : new SourceError('unavailable', 'the consent could not be read');
    }
    this.consentCheck = { at: this.now(), error };
    if (error) throw error;
  }

  /** `GET /accounts/{accountId}`, once: the consented account must be the one onboarded. */
  private async account(): Promise<AccountRef> {
    if (this.identity) return this.identity;
    const url = new URL(`${this.o.accountsBaseUrl.replace(/\/$/, '')}/accounts/${this.o.accountId}`);
    const j = await this.get('accounts', url) as { data?: Record<string, unknown> } | undefined;
    const d = j?.data;
    if (!d) throw new SourceError('consent', 'the consented account is not visible');
    const got: AccountRef = {
      compeCode: typeof d.compeCode === 'string' ? d.compeCode : undefined,
      branchCode: typeof d.branchCode === 'string' ? d.branchCode : undefined,
      number: typeof d.number === 'string' ? d.number : '',
      checkDigit: typeof d.checkDigit === 'string' ? d.checkDigit : undefined,
    };
    const want = this.o.account;
    if (got.number !== want.number || (want.compeCode && got.compeCode !== want.compeCode)
      || (want.branchCode && got.branchCode !== want.branchCode) || (want.checkDigit && got.checkDigit !== want.checkDigit)) {
      throw new SourceError('consent', 'the consented account is not the account onboarded for this LP');
    }
    this.identity = got;
    return got;
  }

  /** Every CREDITO in the window, all pages, served from cache inside `minRefreshMs`. */
  private async credits(from: string, to: string, want: string): Promise<Map<string, OfTransaction>> {
    const key = `${from}/${to}`;
    const cached = this.lists.get(key);
    if (cached?.txs.has(want)) return cached.txs;
    if (cached && this.now() - cached.at < (this.o.minRefreshMs ?? 60_000)) {
      throw new SourceError('rate_limited', 'the transaction list was read moments ago; retry after the refresh interval');
    }
    const base = new URL(`${this.o.accountsBaseUrl.replace(/\/$/, '')}/accounts/${this.o.accountId}/transactions-current`);
    base.searchParams.set('fromBookingDateMaxLimited', from);
    base.searchParams.set('toBookingDateMaxLimited', to);
    base.searchParams.set('creditDebitIndicator', 'CREDITO');
    base.searchParams.set('page-size', '1000');
    const txs = new Map<string, OfTransaction>();
    let url: URL | undefined = base;
    for (let page = 0; url && page < MAX_PAGES; page++) {
      const j = await this.get('accounts', url) as { data?: unknown; links?: { next?: unknown } } | undefined;
      if (!j || !Array.isArray(j.data)) throw new SourceError('malformed', 'the transactions response has no data array');
      for (const t of j.data as OfTransaction[]) {
        if (typeof t?.transactionId === 'string') txs.set(t.transactionId, t);
      }
      const next = j.links?.next;
      url = undefined;
      if (typeof next === 'string' && next) {
        const n = new URL(next, base);
        // A `next` elsewhere would carry the bearer token to a host nobody configured.
        if (n.origin !== base.origin) throw new SourceError('malformed', 'the transactions response links to another origin');
        url = n;
      }
    }
    this.lists.set(key, { at: this.now(), txs });
    return txs;
  }

  async pixCredit(q: PaymentQuery): Promise<PixCredit | undefined> {
    if (!TRANSACTION_ID.test(q.bankTxId)) return undefined;
    await this.checkConsent();
    const account = await this.account();
    const now = this.now();
    const fromMs = Math.max(Number(q.since) * 1000 - DAY, now - MAX_DAYS_BACK * DAY);
    const toMs = Math.max(Number(q.until) * 1000, now) + DAY;
    const t = (await this.credits(brasiliaDate(fromMs), brasiliaDate(toMs), q.bankTxId)).get(q.bankTxId);
    if (!t) return undefined;
    // Only a settled PIX credit is a payment; a scheduled or processing entry is a promise of one.
    if (t.creditDebitType !== 'CREDITO' || t.type !== 'PIX' || t.completedAuthorisedPaymentType !== 'TRANSACAO_EFETIVADA') return undefined;
    if (t.transactionAmount?.currency !== 'BRL') throw new SourceError('malformed', 'the credit is not in BRL');
    const m = typeof t.transactionAmount.amount === 'string' ? AMOUNT.exec(t.transactionAmount.amount) : null;
    if (!m) throw new SourceError('malformed', 'the credit\'s amount is outside the spec\'s pattern');
    // Up to four decimals are allowed by the schema; a fraction of a centavo is refused, never rounded.
    if (m[3] && /[1-9]/.test(m[3])) throw new SourceError('malformed', 'the credit\'s amount has a fraction of a centavo');
    const ms = typeof t.transactionDateTime === 'string' ? Date.parse(t.transactionDateTime) : NaN;
    if (Number.isNaN(ms)) throw new SourceError('malformed', 'the credit has no valid transactionDateTime');
    return {
      bankTxId: q.bankTxId,
      amountCents: BigInt(m[1]) * 100n + BigInt(m[2]),
      settledAt: BigInt(Math.floor(ms / 1000)),
      payee: { kind: 'account', account, keys: this.o.pixKeys },
      returnedCents: 0n,
    };
  }

  async probe(): Promise<SourceHealth> {
    try {
      this.consentCheck = undefined;
      await this.checkConsent();
      return { ok: true, detail: 'consent AUTHORISED' };
    } catch (e) {
      return { ok: false, detail: e instanceof SourceError && e.code === 'consent' ? 'consent not usable' : 'consents API did not answer' };
    }
  }
}
