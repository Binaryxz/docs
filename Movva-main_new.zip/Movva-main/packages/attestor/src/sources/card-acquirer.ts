/**
 * A card partner's charges, read at its acquirer through lp-node's `CardAcquirer` interface.
 *
 * ## Reads only
 *
 * The interface also creates checkouts and voids or refunds charges; an attestor has no business doing
 * either, so this source accepts only `acquirerId`, `merchantId` and `chargesFor` (`CardReader`), and the
 * credential the card partner arranges for the PSP at its acquirer should be read-only for the same reason.
 * Any adapter implementing the interface slots in: `MockAcquirer` today, and a real acquirer's adapter
 * (packages/lp-node/src/acquirers/) when it lands.
 *
 * ## What it can see
 *
 *  - Each charge the acquirer recorded against a checkout reference - the order id the LP node created the
 *    checkout with - with its TID/NSU, merchant id, status, authorised or captured total, and capture time.
 *    `CardAcquirer` reads charges only by reference, so a capture is looked for among the charges of the
 *    order the request names: a TID paid through another order's checkout is not found there.
 *
 * ## What it cannot see
 *
 *  - The card fee the LP committed to. The acquirer knows a captured total; the fee comes from the request
 *    and is checked by the commitment (only the committed fee opens it) and by the total being exactly the
 *    order plus that fee (`attestCard`).
 *  - A chargeback after release. That is the card partner's to carry, under contract (SR2-32); the escrow
 *    takes cards only from an institutional LP for that reason.
 *  - Anything about a charge made outside a checkout the node created: without the order's reference it
 *    belongs to no order, and is not found.
 */
import type { CardAcquirer, CardCharge } from '@mova/lp-node';
import { SourceError, type CardCapture, type CardQuery, type PaymentSource, type SourceHealth } from '../source.js';

export type CardReader = Pick<CardAcquirer, 'acquirerId' | 'merchantId' | 'chargesFor'>;

const STATUSES = new Set(['AUTHORIZED', 'CAPTURED', 'VOIDED', 'REFUNDED', 'CHARGED_BACK']);

export class AcquirerCardSource implements PaymentSource {
  readonly kind = 'card-acquirer';

  constructor(private readonly acquirer: CardReader) {}

  async cardCapture(q: CardQuery): Promise<CardCapture | undefined> {
    // A transaction id another acquirer assigned is nothing this acquirer can speak for.
    if (q.acquirerId !== this.acquirer.acquirerId) return undefined;
    let charges: CardCharge[];
    try {
      charges = await this.acquirer.chargesFor(q.reference);
    } catch {
      throw new SourceError('unavailable', 'the acquirer could not be read');
    }
    if (!Array.isArray(charges)) throw new SourceError('malformed', 'the acquirer returned something other than a list of charges');
    const c = charges.find((x) => x?.transactionId === q.transactionId);
    if (!c) return undefined;
    if (typeof c.amountCents !== 'bigint' || c.amountCents < 0n || !STATUSES.has(c.status)
      || (c.capturedAt !== undefined && typeof c.capturedAt !== 'bigint') || typeof c.merchantId !== 'string' || typeof c.reference !== 'string') {
      throw new SourceError('malformed', 'the acquirer returned a charge outside the adapter contract');
    }
    return {
      acquirerId: c.acquirerId, transactionId: c.transactionId, merchantId: c.merchantId, reference: c.reference,
      status: c.status, amountCents: c.amountCents, capturedAt: c.capturedAt,
    };
  }

  /** A read for a reference no checkout carries: it costs nothing and proves the credential works. */
  async probe(): Promise<SourceHealth> {
    try {
      await this.acquirer.chargesFor(`0x${'00'.repeat(32)}`);
      return { ok: true, detail: 'acquirer answered' };
    } catch {
      return { ok: false, detail: 'acquirer did not answer' };
    }
  }
}
