/**
 * The PSP's own records of a Pix, through the Banco Central's standard API Pix: for an LP whose receiving
 * account this PSP holds or services.
 *
 * ## No longer read by the attestor
 *
 * The attestor service signed PIX credits from this source until PIX left the attestor quorum: PIX, boleto
 * and TED now settle only on a zkTLS proof of the bank session (`IAttestorVerifier.provesBankSession`; the
 * escrows revert `BankRailNeedsZkTls` for a bank-rail offer or sale through a quorum), so the service refuses
 * every PIX request and its entrypoint refuses a sources file naming `api-pix`. This module is kept as a
 * `BankFactSource`, a reader of what the LP's own PSP shows about a Pix it received - the end-to-end id, key,
 * amount, time and refunds, straight from the institution that settled it - which an LP still needs before it
 * asks for a zkTLS session over a payment, or to reconcile. What follows describes the reader, and what it
 * could vouch for when it fed the attestor.
 *
 * ## Why this is the strongest source
 *
 * `GET /pix/{e2eid}` (API Pix 2.10.0, github.com/bacen/pix-api) returns the PSP's record of a Pix its user
 * RECEIVED: the SPI's `endToEndId`, the `chave` credited, the `valor` and the `horario` the PSP processed
 * it, and any `devolucoes` made from it. Every field the attestor signs comes from the institution that
 * settled the credit, looked up by the id the SPI assigned - so guarantees 1 to 4 of IAttestorVerifier hold
 * without trusting the LP for any of them. The credentials are the ones the PSP issues for the LP's
 * account, so a record returned is a credit to that account and no other.
 *
 * The client is lp-node's `ApiPixClient` (OAuth2 client credentials, mTLS), reused as it is.
 *
 * ## What it can and cannot see
 *
 *  - PIX credits into the serviced account: yes, all of the above.
 *  - A Pix paid by account details rather than to a key: the record has no `chave`, so it opens no key
 *    commitment. Reported as `unknown` payee.
 *  - Refunds: `devolucoes` with status DEVOLVIDO or EM_PROCESSAMENTO are reported as `returnedCents`, and
 *    a caller must treat such a credit as money not held. A MED claw-back that the PSP has not yet executed is not visible.
 *  - Pix SENT from the account (the off-ramp's payment to a seller): no - API Pix standardises receiving
 *    only. An off-ramp sale is attestable here only when the SELLER's account is the one this PSP services.
 *  - Boletos: API Pix has none. A PSP that registered or collected the boleto confirms it from its own
 *    collection system through `BoletoLedger` (line, amount, authentication code); without one this source
 *    does not offer `boletoPayment`.
 *  - Cards: no.
 */
import { ApiPixError, fromValor, type ApiPixClient, type ApiPixPix } from '@mova/lp-node';
import {
  SourceError, type BankFactSource, type BoletoLedger, type BoletoPaid, type PaymentQuery, type PixCredit, type SourceHealth,
} from '../source.js';

const E2E = /^[a-zA-Z0-9]{32}$/;

/** The spec's `Pix` with the refunds the node's type leaves out. */
interface PixRecord extends ApiPixPix {
  devolucoes?: { valor?: string; status?: string }[];
}

export class ApiPixSource implements BankFactSource {
  readonly kind = 'api-pix';
  readonly boletoPayment?: (q: PaymentQuery) => Promise<BoletoPaid | undefined>;

  constructor(private readonly client: ApiPixClient, o: { boletos?: BoletoLedger; now?: () => number } = {}) {
    const ledger = o.boletos;
    if (ledger) {
      this.boletoPayment = async (q) => {
        try {
          return await ledger.paidBoleto(q.bankTxId);
        } catch (e) {
          throw e instanceof SourceError ? e : new SourceError('unavailable', 'the boleto ledger could not be read');
        }
      };
    }
    this.now = o.now ?? Date.now;
  }

  private readonly now: () => number;

  async pixCredit(q: PaymentQuery): Promise<PixCredit | undefined> {
    // Not an end-to-end id, so not something the SPI assigned: there is nothing to look up.
    if (!E2E.test(q.bankTxId)) return undefined;
    let p: PixRecord;
    try {
      p = (await this.client.getPix(q.bankTxId)) as PixRecord;
    } catch (e) {
      if (e instanceof ApiPixError && e.status === 404) return undefined;
      if (e instanceof ApiPixError && e.status === 429) throw new SourceError('rate_limited', 'API Pix answered 429');
      // ApiPixError keeps no `detail` and the transport error's text may carry the PSP's URL: neither is passed on.
      throw new SourceError('unavailable', e instanceof ApiPixError ? `API Pix answered ${e.status}` : 'API Pix could not be reached');
    }
    if (!p || typeof p !== 'object' || typeof p.endToEndId !== 'string' || !E2E.test(p.endToEndId)) {
      throw new SourceError('malformed', 'the PSP returned a Pix without a valid endToEndId');
    }
    let amountCents: bigint;
    let returnedCents = 0n;
    try {
      amountCents = fromValor(p.valor);
      for (const d of p.devolucoes ?? []) {
        // NAO_REALIZADO moved nothing; anything else is money leaving, or gone.
        if (d.status === 'DEVOLVIDO' || d.status === 'EM_PROCESSAMENTO') returnedCents += fromValor(String(d.valor));
      }
    } catch {
      throw new SourceError('malformed', 'the PSP returned a valor outside the spec\'s pattern');
    }
    const ms = Date.parse(p.horario);
    if (Number.isNaN(ms)) throw new SourceError('malformed', 'the PSP returned a Pix without a valid horario');
    return {
      bankTxId: p.endToEndId,
      amountCents,
      // Floored as lp-node's `pixToIncoming` does, so the LP's bank and this source agree to the second.
      settledAt: BigInt(Math.floor(ms / 1000)),
      payee: typeof p.chave === 'string' && p.chave.length > 0 ? { kind: 'key', key: p.chave } : { kind: 'unknown' },
      returnedCents,
    };
  }

  /** One cheap authenticated read: a one-item page of the last minute's Pix. */
  async probe(): Promise<SourceHealth> {
    const fim = new Date(this.now());
    try {
      await this.client.call('GET', '/pix', {
        query: { inicio: new Date(fim.getTime() - 60_000).toISOString(), fim: fim.toISOString(), 'paginacao.itensPorPagina': '1' },
      });
      return { ok: true, detail: 'API Pix answered' };
    } catch {
      return { ok: false, detail: 'API Pix did not answer an authenticated read' };
    }
  }
}
