/**
 * A PSP's API Pix in memory, over HTTP: the token endpoint (client credentials, HTTP Basic) and the two
 * reads `ApiPixSource` makes, `GET /pix/{e2eid}` and `GET /pix`. For the retained bank-fact reader's tests, as
 * MockBank is for the LP node; the attestor service no longer reads API Pix (sources/api-pix.ts). Its records are
 * set by the test - which is how a PSP that shows a different amount, key or time is staged.
 */
import { createServer, type Server } from 'node:http';
import type { ApiPixPix } from '@mova/lp-node';

export type MockPix = ApiPixPix & { devolucoes?: { id: string; valor: string; status: string }[] };

export class MockApiPixPsp {
  readonly pix = new Map<string, MockPix>();
  /** Authenticated reads that reached the API. */
  reads = 0;
  private server?: Server;
  private port = 0;

  constructor(readonly clientId: string, readonly clientSecret: string) {}

  get tokenUrl(): string {
    return `http://127.0.0.1:${this.port}/oauth/token`;
  }

  get baseUrl(): string {
    return `http://127.0.0.1:${this.port}/api/v2`;
  }

  record(p: MockPix): void {
    this.pix.set(p.endToEndId, { ...p });
  }

  async listen(): Promise<void> {
    this.server = createServer(async (rq, rs) => {
      const url = new URL(rq.url ?? '/', 'http://psp');
      const chunks: Buffer[] = [];
      for await (const c of rq) chunks.push(c as Buffer);
      const raw = Buffer.concat(chunks).toString('utf8');
      const send = (status: number, body: unknown) => { rs.writeHead(status, { 'content-type': 'application/json' }); rs.end(JSON.stringify(body)); };
      const problem = (status: number, title: string) => send(status, { type: `https://pix.bcb.gov.br/api/v2/error/${title}`, title, status });

      if (url.pathname === '/oauth/token') {
        const basic = `Basic ${Buffer.from(`${this.clientId}:${this.clientSecret}`).toString('base64')}`;
        if (rq.headers.authorization !== basic || new URLSearchParams(raw).get('grant_type') !== 'client_credentials') return send(401, { error: 'invalid_client' });
        return send(200, { access_token: `tok-${this.clientId}`, token_type: 'Bearer', expires_in: 3600 });
      }
      if (rq.headers.authorization !== `Bearer tok-${this.clientId}`) return problem(401, 'AcessoNegado');
      this.reads++;
      const path = url.pathname.replace(/^\/api\/v2/, '');
      const one = /^\/pix\/([a-zA-Z0-9]{32})$/.exec(path);
      if (rq.method === 'GET' && one) {
        const p = this.pix.get(one[1]);
        return p ? send(200, p) : problem(404, 'PixNaoEncontrado');
      }
      if (rq.method === 'GET' && path === '/pix') {
        const inicio = Date.parse(url.searchParams.get('inicio') ?? '');
        const fim = Date.parse(url.searchParams.get('fim') ?? '');
        if (Number.isNaN(inicio) || Number.isNaN(fim)) return problem(400, 'PixConsultaInvalida');
        const all = [...this.pix.values()].filter((p) => Date.parse(p.horario) >= inicio && Date.parse(p.horario) <= fim);
        return send(200, { parametros: { paginacao: { paginaAtual: 0, itensPorPagina: all.length, quantidadeDePaginas: 1, quantidadeTotalDeItens: all.length } }, pix: all });
      }
      return problem(404, 'NaoEncontrado');
    });
    await new Promise<void>((r) => this.server!.listen(0, '127.0.0.1', () => r()));
    const a = this.server.address();
    this.port = typeof a === 'object' && a ? a.port : 0;
  }

  async close(): Promise<void> {
    if (this.server) await new Promise<void>((r) => { this.server!.close(() => r()); this.server!.closeAllConnections(); });
  }
}
