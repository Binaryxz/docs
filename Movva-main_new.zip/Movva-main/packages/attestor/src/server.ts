/**
 * The attestor's HTTP surface.
 *
 * Two audiences, which is why there can be two listeners, as for the LP node:
 *
 *  - **Operations** - `/healthz` (the process is alive; never the source's or the chain's health, so a
 *    supervisor does not restart the attestor exactly when a bank misbehaves), `/readyz` (503 until the
 *    entrypoint has checked the chain, the verifier and the journal), `/status`, `/metrics`. Keep this port
 *    private: `/status` lists which LPs this PSP attests for.
 *  - **LPs** - `POST /v1/attest`. Put it behind TLS. Every request authenticates itself (request.ts), so
 *    the port may face the internet; the rate limit is per admitted LP.
 *
 * Every response is redacted against the configured secrets at this boundary, and a request body is never
 * logged: it carries the opening of a payee commitment - a merchant account, a card fee and a salt.
 */
import { createServer, type IncomingMessage, type Server, type ServerResponse } from 'node:http';
import { redact } from '@mova/ops/redact';
import { Refusal } from './refusal.js';
import { parseAttestationRequest } from './request.js';
import type { PaymentAttestor } from './service.js';

export interface ServeAttestorOptions {
  mode: 'ops' | 'api' | 'both';
  redactValues?: readonly (string | undefined)[];
  maxBodyBytes?: number;
}

const json = (value: unknown) => JSON.stringify(value, (_k, v) => (typeof v === 'bigint' ? v.toString() : v), 2);

export function serveAttestor(attestor: PaymentAttestor, o: ServeAttestorOptions): {
  server: Server;
  listen: (port?: number, host?: string) => Promise<number>;
  close: () => Promise<void>;
} {
  const ops = o.mode !== 'api';
  const api = o.mode !== 'ops';

  const handle = async (rq: IncomingMessage, rs: ServerResponse): Promise<void> => {
    const url = new URL(rq.url ?? '/', 'http://localhost');
    const send = (code: number, value: unknown) => {
      rs.writeHead(code, { 'content-type': 'application/json' });
      rs.end(redact(json(value), o.redactValues));
    };
    try {
      if (rq.method === 'GET' && url.pathname === '/healthz') return send(200, { ok: true });
      if (rq.method === 'GET' && url.pathname === '/readyz') return send(attestor.ready ? 200 : 503, { ready: attestor.ready });
      if (ops && rq.method === 'GET' && url.pathname === '/status') return send(attestor.ready ? 200 : 503, attestor.status());
      if (ops && rq.method === 'GET' && url.pathname === '/metrics') {
        rs.writeHead(200, { 'content-type': 'text/plain; version=0.0.4; charset=utf-8' });
        rs.end(attestor.metrics.render());
        return;
      }

      if (api && rq.method === 'POST' && url.pathname === '/v1/attest') {
        if (!attestor.ready) return send(503, { error: 'not_ready', message: 'the attestor has not finished its startup checks' });
        const chunks: Buffer[] = [];
        let size = 0;
        for await (const c of rq) {
          size += (c as Buffer).length;
          if (size > (o.maxBodyBytes ?? 16 * 1024)) throw new Refusal('malformed', 'request body too large');
          chunks.push(c as Buffer);
        }
        let body: unknown;
        try {
          body = JSON.parse(Buffer.concat(chunks).toString('utf8'));
        } catch {
          throw new Refusal('malformed', 'the request body is not JSON');
        }
        const r = await attestor.handle(parseAttestationRequest(body));
        return send(200, r);
      }

      const routes = ['/healthz', '/readyz', ...(ops ? ['/status', '/metrics'] : []), ...(api ? ['POST /v1/attest'] : [])];
      return send(404, { error: 'not_found', routes });
    } catch (e) {
      if (e instanceof Refusal) {
        // A malformed request never reached `handle`, so it is counted here.
        if (e.code === 'malformed') {
          attestor.metrics.inc('mova_attestor_requests_total', { result: 'refused' });
          attestor.metrics.inc('mova_attestor_refusals_total', { reason: 'malformed' });
        }
        return send(e.status, { error: e.code, message: e.message });
      }
      try {
        send(500, { error: 'internal', message: 'internal error' });
      } catch {
        rs.destroy();
      }
    }
  };

  const server = createServer((rq, rs) => void handle(rq, rs));
  return {
    server,
    listen: (port = 0, host = '127.0.0.1') => new Promise<number>((resolve) => {
      server.listen(port, host, () => {
        const a = server.address();
        resolve(typeof a === 'object' && a ? a.port : port);
      });
    }),
    close: () => new Promise<void>((resolve) => {
      server.close(() => resolve());
      server.closeIdleConnections();
    }),
  };
}
