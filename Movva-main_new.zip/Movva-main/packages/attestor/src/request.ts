/**
 * The attestation request: what an LP signs to ask one PSP's attestor for a signature.
 *
 * Since bank rails left the attestor quorum, the only request the service signs is for a CARD capture on an
 * institutional LP's card-only offer. The format still carries a `rail`, and a PIX, boleto or TED request
 * still parses - so it can be refused by name (`bank_rail_needs_zktls`) rather than as malformed: those rails
 * settle only on a zkTLS proof of the bank session, and no signature from this service could settle one.
 *
 * ## What is in it, and what the service does with each part
 *
 * The service's value is that it does not take the LP's word for anything, so it would be natural to
 * ask why the request carries anything beyond "order Y, payment X". Each field is either an
 * identifier the service cannot find on its own, or a claim it compares and then ignores:
 *
 *  - **`orderId`** - the on-ramp order or off-ramp sale. Its terms (payee commitment, amount, lock time,
 *    rails) are read from the escrow.
 *  - **`rail` and `bankTxId`** - which payment, by the institution's own id: for a card, the charge's
 *    TID/NSU at the acquirer. (The PIX end-to-end id, a boleto's authentication code, or a bank's own
 *    `transactionId` are still accepted by the parser, for the refusal above.) The service looks it up at its source; the source's record, never this string,
 *    is what gets signed.
 *  - **`payee` and `salt`** - the opening of the payee commitment: for a card `acquirerId|merchantId|feeBps`
 *    (`cardPayee`), and the salt. A commitment cannot be checked
 *    without them, and the service holds no salts. It recomputes the commitment from what the SOURCE shows
 *    - the merchant account captured for - so an opening that does not match what happened proves nothing. A card's fee is the one part no source shows: only the committed fee opens the
 *    commitment, and the captured total must be exactly the order plus it.
 *  - **`payeeKeyHash`, `orderBrlCents`, `lockedAt`** - the terms as the LP believes them. Compared with
 *    the chain; a mismatch is refused (`terms_disagree`), because an LP whose view of an order is wrong
 *    is about to build a proof that will not verify - or is probing.
 *  - **`amountBrlCents`, `paidAt`** - the payment as the LP's acquirer showed it: the captured total (fee
 *    included) and the capture time. Compared with the
 *    source; any difference is refused (`source_disagrees`). The quorum prover combines only signatures over
 *    one identical payment, so an attestor that signed what it saw while the others signed what they saw
 *    would not count towards the quorum - and an attestor that signed a higher amount than the LP claimed
 *    would hide the discrepancy instead of reporting it.
 *  - **`payerRef`** - the one field signed as given. It is a keyed hash only the LP can compute
 *    (`payerRef` in @mova/lp-node), no source shows it, and no contract checks it: it exists for the LP's
 *    own dispute and sanctions review.
 *  - **`issuedAt`, `nonce`** - freshness and replay. A request older or newer than
 *    `REQUEST_MAX_SKEW_SECONDS` is refused, and a nonce is accepted once per LP.
 *
 * ## The domain
 *
 * `verifyingContract` is the AttestorQuorumVerifier this service signs for, and `chainId` its chain, so
 * a request made for one verifier or chain cannot be replayed at an attestor serving another. The name
 * differs from the attestation's own domain, so no request signature is ever a Payment signature.
 */
import { getAddress, isAddress, isHex, verifyTypedData, type Address, type Hex } from 'viem';
import { Rail } from '@mova/ramp';
import { Refusal } from './refusal.js';

export const REQUEST_TYPES = {
  AttestationRequest: [
    { name: 'lp', type: 'address' },
    { name: 'orderId', type: 'bytes32' },
    // The terms, as the LP believes them: compared with the chain, never used.
    { name: 'payeeKeyHash', type: 'bytes32' },
    { name: 'orderBrlCents', type: 'uint256' },
    { name: 'lockedAt', type: 'uint64' },
    // The payment, as the LP's bank or acquirer showed it: compared with the source, never signed from.
    { name: 'rail', type: 'uint8' },
    { name: 'bankTxId', type: 'string' },
    { name: 'amountBrlCents', type: 'uint256' },
    { name: 'paidAt', type: 'uint64' },
    { name: 'payerRef', type: 'bytes32' },
    // The opening of the payee commitment.
    { name: 'payee', type: 'string' },
    { name: 'salt', type: 'bytes32' },
    { name: 'issuedAt', type: 'uint64' },
    { name: 'nonce', type: 'bytes32' },
  ],
} as const;

export const requestDomain = (chainId: number, verifier: Address) => ({
  name: 'Mova-Attestor-Request',
  version: '1',
  chainId,
  verifyingContract: verifier,
});

/** How far `issuedAt` may be from the service's clock, either side. */
export const REQUEST_MAX_SKEW_SECONDS = 300;

export interface AttestationRequest {
  lp: Address;
  orderId: Hex;
  payeeKeyHash: Hex;
  orderBrlCents: bigint;
  lockedAt: bigint;
  rail: Rail;
  bankTxId: string;
  amountBrlCents: bigint;
  paidAt: bigint;
  payerRef: Hex;
  payee: string;
  salt: Hex;
  issuedAt: bigint;
  nonce: Hex;
}

export interface SignedAttestationRequest extends AttestationRequest {
  signature: Hex;
}

export type RequestVerifier = (args: {
  address: Address;
  domain: ReturnType<typeof requestDomain>;
  types: typeof REQUEST_TYPES;
  primaryType: 'AttestationRequest';
  message: ReturnType<typeof requestMessage>;
  signature: Hex;
}) => Promise<boolean>;

/** Plain ECDSA. The entrypoint passes the RPC client's `verifyTypedData`, which also accepts ERC-1271 LPs. */
export const ecdsaRequestVerifier: RequestVerifier = (args) => verifyTypedData(args);

export function requestMessage(r: AttestationRequest) {
  return {
    lp: r.lp, orderId: r.orderId, payeeKeyHash: r.payeeKeyHash, orderBrlCents: r.orderBrlCents, lockedAt: r.lockedAt,
    rail: Number(r.rail), bankTxId: r.bankTxId, amountBrlCents: r.amountBrlCents, paidAt: r.paidAt, payerRef: r.payerRef,
    payee: r.payee, salt: r.salt, issuedAt: r.issuedAt, nonce: r.nonce,
  };
}

/**
 * A card offer's payee, as disclosed: `acquirerId|merchantId|feeBps`. `|` is outside the character set of
 * both ids (`cardMerchantCommitment` in @mova/ramp), so the encoding is unambiguous.
 */
export const cardPayee = (m: { acquirerId: string; merchantId: string; feeBps: number }): string => `${m.acquirerId}|${m.merchantId}|${m.feeBps}`;

export function parseCardPayee(payee: string): { acquirerId: string; merchantId: string; feeBps: number } | undefined {
  const parts = payee.split('|');
  if (parts.length !== 3 || !parts[0] || !parts[1] || !/^\d{1,4}$/.test(parts[2])) return undefined;
  return { acquirerId: parts[0], merchantId: parts[1], feeBps: Number(parts[2]) };
}

/** A fresh 32-byte nonce. */
export function newRequestNonce(): Hex {
  return `0x${Buffer.from(crypto.getRandomValues(new Uint8Array(32))).toString('hex')}`;
}

export async function signAttestationRequest(
  account: {
    signTypedData: (args: {
      domain: ReturnType<typeof requestDomain>; types: typeof REQUEST_TYPES; primaryType: 'AttestationRequest';
      message: ReturnType<typeof requestMessage>;
    }) => Promise<Hex>;
  },
  args: { chainId: number; verifier: Address },
  r: AttestationRequest,
): Promise<SignedAttestationRequest> {
  const signature = await account.signTypedData({
    domain: requestDomain(args.chainId, args.verifier), types: REQUEST_TYPES, primaryType: 'AttestationRequest',
    message: requestMessage(r),
  });
  return { ...r, signature };
}

/** The wire form: integers as decimal strings, so no amount passes through a float. */
export function requestToJson(r: SignedAttestationRequest): Record<string, string | number> {
  return {
    lp: r.lp, orderId: r.orderId, payeeKeyHash: r.payeeKeyHash, orderBrlCents: r.orderBrlCents.toString(),
    lockedAt: r.lockedAt.toString(), rail: Number(r.rail), bankTxId: r.bankTxId, amountBrlCents: r.amountBrlCents.toString(),
    paidAt: r.paidAt.toString(), payerRef: r.payerRef, payee: r.payee, salt: r.salt, issuedAt: r.issuedAt.toString(),
    nonce: r.nonce, signature: r.signature,
  };
}

const UINT64_MAX = (1n << 64n) - 1n;
const UINT256_MAX = (1n << 256n) - 1n;
/**
 * Institution ids across the sources: an e2eid (32 alphanumerics), an authentication code, an Open Finance
 * transactionId (<= 100, letters, digits, hyphens), a card TID/NSU (as `cardTransactionId` accepts).
 */
const BANK_TX_ID = /^[A-Za-z0-9][A-Za-z0-9._:/-]{0,99}$/;

/**
 * Parse the wire form. Every error names the field and never repeats its value: the fields include a salt and
 * a payee's opening (a merchant account; on a refused request, a PIX key or a boleto line), and a parse error is
 * exactly the kind of text that ends up in a log.
 */
export function parseAttestationRequest(body: unknown): SignedAttestationRequest {
  if (!body || typeof body !== 'object' || Array.isArray(body)) throw new Refusal('malformed', 'the request is not a JSON object');
  const b = body as Record<string, unknown>;
  const bad = (field: string, what: string): never => { throw new Refusal('malformed', `${field} must be ${what}`); };
  const bytes32 = (f: string): Hex => {
    const v = b[f];
    return typeof v === 'string' && isHex(v) && v.length === 66 ? (v.toLowerCase() as Hex) : bad(f, 'a 0x-prefixed bytes32');
  };
  const uint = (f: string, max: bigint): bigint => {
    const v = b[f];
    if (typeof v !== 'string' || !/^\d{1,78}$/.test(v)) return bad(f, 'a decimal string');
    const n = BigInt(v as string);
    return n <= max ? n : bad(f, 'within range');
  };
  const lp = typeof b.lp === 'string' && isAddress(b.lp, { strict: false }) ? getAddress(b.lp) : bad('lp', 'an address');
  const rail = typeof b.rail === 'number' && Number.isInteger(b.rail) && b.rail >= 0 && b.rail <= 255 ? (b.rail as Rail) : bad('rail', 'a uint8');
  const bankTxId = typeof b.bankTxId === 'string' && BANK_TX_ID.test(b.bankTxId) ? b.bankTxId : bad('bankTxId', 'an institution id of 1-100 letters, digits or . _ : / -');
  const payee = typeof b.payee === 'string' && b.payee.length > 0 && b.payee.length <= 256 ? b.payee : bad('payee', 'a PIX key, boleto line or card merchant of at most 256 characters');
  const signature = typeof b.signature === 'string' && isHex(b.signature) && b.signature.length >= 132 ? (b.signature as Hex) : bad('signature', 'hex');
  return {
    lp, orderId: bytes32('orderId'), payeeKeyHash: bytes32('payeeKeyHash'), orderBrlCents: uint('orderBrlCents', UINT256_MAX),
    lockedAt: uint('lockedAt', UINT64_MAX), rail, bankTxId, amountBrlCents: uint('amountBrlCents', UINT256_MAX),
    paidAt: uint('paidAt', UINT64_MAX), payerRef: bytes32('payerRef'), payee, salt: bytes32('salt'),
    issuedAt: uint('issuedAt', UINT64_MAX), nonce: bytes32('nonce'), signature,
  };
}
