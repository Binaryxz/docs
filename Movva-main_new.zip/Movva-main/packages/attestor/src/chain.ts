/**
 * What the attestor reads from the chain: an order's or a sale's terms, and whether the requester is an
 * admitted LP.
 *
 * ## Why the terms come from here and not from the request
 *
 * An attestation is a statement "this payment settles order Y". The payee it must have reached, the
 * amount it must cover, the earliest time it may have happened and the rails the counterparty accepts are
 * all properties of Y, and Y lives on-chain. A requester who supplies them can supply wrong ones - the key
 * of an earlier offer, a lock time from before the payment - so they are read from the escrow's storage and
 * the request's copy is only compared (request.ts).
 *
 * The derivation is the escrow's own, field for field (FiatEscrow.releaseWithProof,
 * OffRampEscrow.settleWithProof) and the LP node's (onramp.ts `release`, offramp.ts `settle`). All three
 * cases are derived, so an id is refused for what it is; but the service signs only the first case's card
 * orders. The escrows refuse a bank-rail offer or sale through an attestor quorum (`BankRailNeedsZkTls`), so
 * an order whose offer names this attestor's verifier takes CARD alone, and no sale can name it:
 *
 *  - on-ramp order: payee = the offer's `pixKeyHash` (for a card offer, its merchant commitment),
 *    earliest = `lockedAt`, rails = the offer's mask without BOLETO;
 *  - on-ramp boleto order (`boletoOf(id).issueBy != 0`): payee = the issued boleto's commitment, earliest =
 *    its `issuedAt`, rails = BOLETO only; not attestable until issued;
 *  - off-ramp sale: payee = `payeeKeyHash`, earliest = `claimedAt` (a transfer from before the CLAIM could be
 *    one the LP made for an earlier sale by the same seller), rails = the sale's mask.
 *
 * The ABIs are lp-node's transcriptions, which `test/abi.test.ts` there pins to the compiled contracts; the
 * one this package adds (`lps`) is pinned in this package's tests.
 */
import { getAddress, parseAbi, type Address, type Hex, type PublicClient } from 'viem';
import {
  FIAT_ESCROW_ABI, OFFRAMP_ESCROW_ABI, OrderState, SaleState,
  type OnChainBoleto, type OnChainOffer, type OnChainOrder, type OnChainSale,
} from '@mova/lp-node';
import { Rail, railsFromMask, type OrderTerms } from '@mova/ramp';
import { Refusal } from './refusal.js';

export const ATTESTOR_REGISTRY_ABI = parseAbi([
  'function lps(address) view returns (uint8 tier, uint256 settledCents, uint32 settlements, uint32 disputesLost, uint256 manualCapCents, address sponsor, uint256 exposureCents)',
]);

export const VERIFIER_ABI = parseAbi([
  'function isAttestor(address) view returns (bool)',
  'function threshold() view returns (uint256)',
  'function attestorKind() view returns (string)',
]);

export const ESCROW_REGISTRY_ABI = parseAbi(['function REGISTRY() view returns (address)']);

/** LPRegistry.Tier. The numeric order is the contract's. */
export enum Tier { NONE = 0, RETAIL = 1, AFFILIATED = 2, INSTITUTIONAL = 3, SUSPENDED = 4 }

export type Leg = 'onramp' | 'offramp';

export interface ChainReader {
  readonly chainId: number;
  /** The latest block's timestamp: the escrow's clock, which is what `payBy` is measured on. */
  now(): Promise<bigint>;
  tier(lp: Address): Promise<Tier>;
  order(escrow: Address, id: Hex): Promise<OnChainOrder>;
  offer(escrow: Address, id: Hex): Promise<OnChainOffer>;
  boleto(escrow: Address, id: Hex): Promise<OnChainBoleto>;
  sale(escrow: Address, id: Hex): Promise<OnChainSale>;
  verifierAllowed(escrow: Address, verifier: Address): Promise<boolean>;
}

export class ViemChainReader implements ChainReader {
  constructor(private readonly pub: PublicClient, readonly chainId: number, private readonly registry: Address) {}

  async now(): Promise<bigint> {
    return (await this.pub.getBlock({ blockTag: 'latest' })).timestamp;
  }

  async tier(lp: Address): Promise<Tier> {
    const r = await this.pub.readContract({ address: this.registry, abi: ATTESTOR_REGISTRY_ABI, functionName: 'lps', args: [lp] });
    return r[0] as Tier;
  }

  async order(escrow: Address, id: Hex): Promise<OnChainOrder> {
    const r = await this.pub.readContract({ address: escrow, abi: FIAT_ESCROW_ABI, functionName: 'orders', args: [id] });
    return {
      offerId: r[0], taker: r[1], weiAmount: r[2], brlCents: r[3], lockedAt: r[4], payBy: r[5], state: r[6],
      delivery: r[7], recipient: r[8],
    };
  }

  async offer(escrow: Address, id: Hex): Promise<OnChainOffer> {
    const r = await this.pub.readContract({ address: escrow, abi: FIAT_ESCROW_ABI, functionName: 'offers', args: [id] });
    return {
      lp: r[0], asset: r[1], availableWei: r[2], lockedWei: r[3], priceBrlCentsPerEth: r[4], pixKeyHash: r[5],
      minOrderWei: r[6], maxOrderWei: r[7], verifier: r[8], railMask: r[9], active: r[10], decimals: r[11],
    };
  }

  async boleto(escrow: Address, id: Hex): Promise<OnChainBoleto> {
    const r = await this.pub.readContract({ address: escrow, abi: FIAT_ESCROW_ABI, functionName: 'boletoOf', args: [id] });
    return { issueBy: r[0], issuedAt: r[1], commitment: r[2] };
  }

  async sale(escrow: Address, id: Hex): Promise<OnChainSale> {
    const r = await this.pub.readContract({ address: escrow, abi: OFFRAMP_ESCROW_ABI, functionName: 'sales', args: [id] });
    return {
      seller: r[0], asset: r[1], weiAmount: r[2], brlCents: r[3], payeeKeyHash: r[4], verifier: r[5],
      railMask: r[6], lp: r[7], claimedAt: r[8], payBy: r[9], refundTo: r[10], state: r[11],
    };
  }

  async verifierAllowed(escrow: Address, verifier: Address): Promise<boolean> {
    return this.pub.readContract({ address: escrow, abi: FIAT_ESCROW_ABI, functionName: 'allowedVerifier', args: [verifier] });
  }
}

export interface ChainTerms {
  leg: Leg;
  escrow: Address;
  /** The LP whose account the payment is observed in: the offer's LP, or the sale's claimant. */
  lp: Address;
  verifier: Address;
  payBy: bigint;
  terms: OrderTerms & { acceptedRails: Rail[] };
}

const ZERO = '0x0000000000000000000000000000000000000000';

/**
 * Find `id` on the configured escrows and derive its terms. An order id and a sale id are hashes of
 * different preimages, so an id live on both escrows means a configuration pointing two names at one
 * contract - refused rather than guessed.
 */
export async function readTerms(chain: ChainReader, escrows: { onramp?: Address; offramp?: Address }, id: Hex): Promise<ChainTerms> {
  const [ord, sale] = await Promise.all([
    escrows.onramp ? chain.order(escrows.onramp, id) : undefined,
    escrows.offramp ? chain.sale(escrows.offramp, id) : undefined,
  ]);
  const isOrder = !!ord && ord.state !== OrderState.NONE;
  const isSale = !!sale && sale.state !== SaleState.NONE;
  if (isOrder && isSale) throw new Refusal('ambiguous_order', 'this id is live on both escrows');

  if (isOrder) {
    const escrow = escrows.onramp!;
    if (ord!.state !== OrderState.LOCKED) throw new Refusal('wrong_state', `the order is ${OrderState[ord!.state]}, not LOCKED`);
    const [offer, bol] = await Promise.all([chain.offer(escrow, ord!.offerId), chain.boleto(escrow, id)]);
    const boleto = bol.issueBy !== 0n;
    if (boleto && bol.issuedAt === 0n) throw new Refusal('boleto_not_issued', 'the LP has not committed to a boleto for this order yet');
    return {
      leg: 'onramp', escrow, lp: getAddress(offer.lp), verifier: getAddress(offer.verifier), payBy: ord!.payBy,
      terms: {
        orderId: id,
        payeeKeyHash: (boleto ? bol.commitment : offer.pixKeyHash).toLowerCase() as Hex,
        brlCents: ord!.brlCents,
        lockedAt: boleto ? bol.issuedAt : ord!.lockedAt,
        acceptedRails: boleto ? [Rail.BOLETO] : railsFromMask(offer.railMask).filter((r) => r !== Rail.BOLETO),
      },
    };
  }

  if (isSale) {
    const s = sale!;
    if (s.state !== SaleState.CLAIMED || s.lp === ZERO) throw new Refusal('wrong_state', `the sale is ${SaleState[s.state]}, not CLAIMED`);
    return {
      leg: 'offramp', escrow: escrows.offramp!, lp: getAddress(s.lp), verifier: getAddress(s.verifier), payBy: s.payBy,
      terms: {
        orderId: id, payeeKeyHash: s.payeeKeyHash.toLowerCase() as Hex, brlCents: s.brlCents, lockedAt: s.claimedAt,
        acceptedRails: railsFromMask(s.railMask),
      },
    };
  }

  throw new Refusal('unknown_order', 'no order or sale with this id on the escrows this attestor serves');
}
