/**
 * Where the attestor sees a payment: a `PaymentSource` - since bank rails left the quorum, a card
 * acquirer - per LP whose settlements it attests; and, kept beside it as a library, `BankFactSource`,
 * what a bank's own records show about a Pix or a boleto.
 *
 * ## The contract a source MUST honour
 *
 * A source reports what an acquirer's, a PSP's or a bank's own records show, and nothing it was told.
 * The attestor signs a source's record - its id, amount, time and payee - so each property below is one
 * of the guarantees IAttestorVerifier asks of a verifier, delegated:
 *
 *  1. **The id is the institution's own identifier** for the settled payment, looked up by that id: the
 *     acquirer's TID/NSU, an end-to-end id, a bank's `transactionId`, an authentication code. A source
 *     never "finds" a payment by amount or time: amounts are not unique, and a payment matched by amount is
 *     how one taker's payment settles another taker's order.
 *  2. **The payee is what was credited**, from the institution's records: the merchant account captured
 *     for (an acquirer), the PIX key (API Pix shows it), the account plus the keys bound to it at
 *     onboarding (Open Finance shows the account, never the key), the document paid (a collection ledger).
 *     A source that cannot show it returns nothing rather than guess.
 *  3. **Amounts are settled centavos**, parsed exactly. A value with fractions of a centavo is refused,
 *     not rounded - rounding is in somebody's favour.
 *  4. **Times are settlement or capture times** from the institution's clock, unix seconds.
 *  5. **Only settled payments.** Scheduled, processing or future-dated entries are not payments; a card
 *     authorisation is reported as what it is and refused by `attestCard`.
 *  6. **Money returned is reported**: a charge voided, refunded or charged back is reported with that
 *     status, and a Pix already refunded to its payer with its `returnedCents`.
 *
 * ## Which rails the service reads, and why only one
 *
 *  - **CARD** - `PaymentSource.cardCapture`: the acquirer's record of a charge, found under the order's
 *    checkout reference (`sources/card-acquirer.ts`, over lp-node's `CardAcquirer` read methods). The only
 *    rail the attestor signs.
 *  - **PIX, BOLETO, TED** - never read by the service. They settle only on a zkTLS proof of the bank
 *    session (`IAttestorVerifier.provesBankSession`; the escrows revert `BankRailNeedsZkTls` for a bank-rail
 *    offer or sale through an attestor quorum), so the service refuses them by name before reading anything
 *    (refusal.ts, service.ts). The readers written for them implement `BankFactSource` instead, which the
 *    service does not accept:
 *      - PIX - `pixCredit`: API Pix (`sources/api-pix.ts`), Open Finance account data
 *        (`sources/open-finance.ts`).
 *      - BOLETO - `boletoPayment`: the line paid, its amount and authentication code. No published standard
 *        carries all three: API Pix has no boletos, and an Open Finance BOLETO transaction has the amount and
 *        time but no line and no authentication code. So only a PSP that registered or collected a boleto
 *        knows it, through its own collection system behind `BoletoLedger`.
 *    They are kept because an LP still needs what they read - whether a Pix or a boleto payment arrived, under
 *    which institution id, before asking for a zkTLS session over it, or to reconcile its account - and
 *    because their handling of the specifications (FAPI, consents, operational call limits) was not cheap to
 *    get right.
 *
 * One card source per LP. The journal that stops one payment settling two orders keys on the id the source
 * reports; an LP has one merchant account at one acquirer, which is what its card offer commits to, so a
 * second acquirer source for the same LP would find no order that names it.
 */
import type { Hex } from 'viem';

/** An account, as an institution identifies it. */
export interface AccountRef {
  /** COMPE code of the institution (3 digits), when it has one. */
  compeCode?: string;
  /** ISPB of the institution (8 characters), when the source shows it. */
  ispb?: string;
  branchCode?: string;
  number: string;
  checkDigit?: string;
}

export type CreditedPayee =
  /** The PIX key credited, exactly as the institution records it. */
  | { kind: 'key'; key: string }
  /**
   * The account credited, and the PIX keys the PSP bound to that account when it onboarded the LP. The
   * binding is a fact the PSP established itself (a DICT lookup is only available to SPI participants),
   * not something this request or this source asserts.
   */
  | { kind: 'account'; account: AccountRef; keys: readonly string[] }
  /** The institution shows no key: a Pix sent to account details, which opens no key commitment. */
  | { kind: 'unknown' };

export interface PixCredit {
  /** The institution's id for this credit: the end-to-end id at API Pix, the `transactionId` at Open Finance. */
  bankTxId: string;
  amountCents: bigint;
  /** Settlement time, unix seconds. */
  settledAt: bigint;
  payee: CreditedPayee;
  /** Centavos returned, or being returned, to the payer. */
  returnedCents: bigint;
}

export interface BoletoPaid {
  /** The payment's authentication code. */
  authenticationCode: string;
  /** The line or barcode of the document paid, as the collecting institution recorded it. */
  line: string;
  amountCents: bigint;
  paidAt: bigint;
}

/**
 * A charge, as the acquirer's records show it. The card fee the LP committed to is not here: the acquirer sees
 * only the total it captured, so the fee comes from the requester and is checked by opening the offer's
 * commitment (only the committed fee opens it) and by the total being exactly the order plus that fee.
 */
export interface CardCapture {
  acquirerId: string;
  /** The acquirer's TID/NSU. */
  transactionId: string;
  merchantId: string;
  /** The reference the checkout carried: the order id the LP created it for. */
  reference: string;
  status: 'AUTHORIZED' | 'CAPTURED' | 'VOIDED' | 'REFUNDED' | 'CHARGED_BACK';
  /** Authorised, or once captured the captured total, in centavos. */
  amountCents: bigint;
  capturedAt?: bigint;
}

export interface PaymentQuery {
  /** The institution's id, as the requester names it. */
  bankTxId: string;
  /** From the chain: no payment before this can settle the order, so no source needs to look earlier. */
  since: bigint;
  /** The chain's current time. */
  until: bigint;
}

export interface CardQuery extends Omit<PaymentQuery, 'bankTxId'> {
  acquirerId: string;
  transactionId: string;
  /** The order id: an acquirer lists charges by the reference of the checkout they were made through. */
  reference: string;
}

export interface SourceHealth {
  ok: boolean;
  /** A short fixed phrase, never an error message: it is served on `/status`. */
  detail: string;
}

/** What the attestor service reads: one LP's card acquirer. */
export interface PaymentSource {
  /** e.g. `card-acquirer`. A metric label: from code, never from configuration. */
  readonly kind: string;
  cardCapture(q: CardQuery): Promise<CardCapture | undefined>;
  /** Can the source answer right now: credentials valid. */
  probe?(): Promise<SourceHealth>;
}

/**
 * What a bank's own records show about a Pix or a boleto. Not read by the attestor service - bank rails settle
 * only on zkTLS proofs, see the header - and deliberately not a `PaymentSource`: the service refuses a source
 * without `cardCapture` at construction.
 */
export interface BankFactSource {
  /** e.g. `api-pix`, `open-finance`. A metric label: from code, never from configuration. */
  readonly kind: string;
  pixCredit?(q: PaymentQuery): Promise<PixCredit | undefined>;
  boletoPayment?(q: PaymentQuery): Promise<BoletoPaid | undefined>;
  /** Can the source answer right now: credentials valid, consent authorised. */
  probe?(): Promise<SourceHealth>;
}

/** Why a source could not answer. Distinct from "no such payment", which is `undefined`. */
export class SourceError extends Error {
  constructor(readonly code: 'unavailable' | 'rate_limited' | 'consent' | 'malformed', message: string) {
    super(message);
  }
}

/**
 * A PSP's own collection system, for boletos it registered or collected. Every bank's is different, so
 * this is the interface a PSP implements; the attestor asks it only by authentication code.
 */
export interface BoletoLedger {
  paidBoleto(authenticationCode: string): Promise<BoletoPaid | undefined>;
}

/** For tests: a ledger in memory. */
export class MemoryBoletoLedger implements BoletoLedger {
  readonly paid = new Map<string, BoletoPaid>();

  record(p: BoletoPaid): void {
    this.paid.set(p.authenticationCode, p);
  }

  async paidBoleto(authenticationCode: string): Promise<BoletoPaid | undefined> {
    const p = this.paid.get(authenticationCode);
    return p && { ...p };
  }
}

/** A salt is 32 bytes; kept here so the sources and their callers agree on the one check. */
export const isSalt = (v: string): v is Hex => /^0x[0-9a-fA-F]{64}$/.test(v);
