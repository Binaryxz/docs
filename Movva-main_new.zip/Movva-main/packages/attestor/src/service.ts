/**
 * The attestor a licensed PSP runs: one key registered in AttestorQuorumVerifier, and the rules for when it
 * signs.
 *
 * ## What it is for, since bank rails left the quorum
 *
 * An attestation quorum is "a multisig over reality" (the verifier's own header): M licensed PSPs each say
 * a payment settled, and the escrow releases. What M signatures cannot do is rule out M colluding PSPs
 * signing a payment that never happened. For a bank payment that is avoidable - a zkTLS proof of the bank
 * session lets witnesses refuse to attest but not invent a payment - so PIX, boleto and TED now settle ONLY
 * on such a proof: the escrows refuse a bank-rail offer or sale whose verifier's `provesBankSession()` is
 * false (`BankRailNeedsZkTls`), and AttestorQuorumVerifier's is false. What is left to the quorum is CARD:
 * an institutional LP's card-only offer, paid through a checkout at the card partner's acquirer, where the
 * fact is the acquirer's record of a captured charge and there is no bank session to prove.
 *
 * So this service signs card captures and nothing else. A PIX, boleto or TED request is refused first, by
 * name (`bank_rail_needs_zktls`, refusal.ts), before it costs a signature check, a chain read, a bucket, a
 * nonce or a source call: no answer this service could give it would settle anything, whoever asked.
 *
 * The quorum is only worth its licences if each member checks reality independently - an attestor that
 * signs what an LP forwards turns M-of-N into 1-of-1, with the LP as the one. So for a card request this
 * service takes nothing from the requester that it can find out itself:
 *
 *  - **who is asking**: an EIP-712 request signed by an address LPRegistry has admitted, which must be the
 *    offer's LP - the card partner whose merchant account the charge was captured for. The source reads
 *    that merchant account under the credential the card partner arranged for this PSP; spending it for
 *    anyone else would be using that arrangement on someone else's behalf. Each LP has a token bucket.
 *  - **what the payment must be**: the order's terms, from the escrow (chain.ts).
 *  - **what the payment was**: the acquirer's record (sources/card-acquirer.ts), found under the order's
 *    checkout reference and looked up by the acquirer's own transaction id.
 *
 * and then applies exactly `Attestor.attestCard`'s refusals from @mova/ramp - a charge not CAPTURED, a total
 * other than the order plus its committed fee, a fee other than the committed one, a capture older than the
 * order - before signing.
 *
 * ## Refusals this service adds
 *
 *  - a PIX, boleto or TED request (`bank_rail_needs_zktls`), and any rail it does not know
 *    (`rail_unsupported`);
 *  - a request whose view of the terms, or of the charge, differs from the chain's or the acquirer's
 *    (`terms_disagree`, `source_disagrees`): the requester is confused or probing, and a signature over the
 *    acquirer's version would not verify against the requester's proof anyway;
 *  - a charge for another merchant account, or made through another order's checkout (`source_disagrees`) -
 *    the acquirer must SHOW where the money went;
 *  - one transaction id for two orders (`bank_tx_reused`), from the journal, which is written before a
 *    signature leaves the process;
 *  - a replayed request (`replayed`), from the same journal.
 *
 * A second request for an order it has already signed, with the same payment, is answered with the same
 * signature (`reused`): an LP whose first response was lost must be able to ask again.
 *
 * ## What was removed, and what was kept
 *
 * Until 14 September 2026 this service also signed PIX credits (from API Pix or an LP's Open Finance
 * consent) and boleto payments (from a PSP's collection ledger). Those signing paths are gone rather than
 * switched off: a key that can release escrowed crypto should have no code path that signs a payment the
 * chain no longer accepts, and a PSP attesting cards needs no read access to anyone's bank account. The
 * bank-fact READERS (sources/api-pix.ts, sources/open-finance.ts, the boleto ledger in source.ts) are kept
 * as a library, unwired here: they read what a bank's own records show about a Pix or a boleto, which an LP
 * still needs - to know a payment arrived before asking for a zkTLS session over it, or to reconcile - and
 * their FAPI, consent and call-budget handling was written from the published specifications.
 *
 * ## What a colluding or compromised attestor can still do
 *
 * Sign any card payment: this process is the check, not a constraint on its own key. Refusing is what an
 * HONEST attestor does to avoid being used; the bound on a dishonest quorum is the verifier's (named
 * attestors, public signatures, the governance delay on the signer set), the card offer's restriction to an
 * institutional LP that carries chargebacks under contract, and docs/security-review-phase2.md's. It cannot
 * settle a bank payment with any signature: the escrows refuse the offer before an order exists.
 */
import { getAddress, keccak256, toBytes, type Address, type Hex } from 'viem';
import {
  Attestor, RefusedToAttest, Rail, cardFee, cardMerchantCommitment, cardTransactionId,
  type ObservedCardCapture, type ObservedPayment,
} from '@mova/ramp';
import { redact } from '@mova/ops/redact';
import { readTerms, Tier, type ChainReader, type ChainTerms } from './chain.js';
import type { AttestationJournal } from './journal.js';
import { AttestorMetrics } from './metrics.js';
import type { RateLimiter } from './rate-limit.js';
import { BANK_RAIL_NEEDS_ZKTLS, Refusal } from './refusal.js';
import {
  ecdsaRequestVerifier, parseCardPayee, requestDomain, requestMessage, REQUEST_MAX_SKEW_SECONDS, REQUEST_TYPES,
  type RequestVerifier, type SignedAttestationRequest,
} from './request.js';
import { SourceError, type CardQuery, type PaymentSource, type SourceHealth } from './source.js';

export interface Logger {
  info(message: string): void;
  warn(message: string): void;
  error(message: string): void;
}

const silent: Logger = { info: () => {}, warn: () => {}, error: () => {} };

export interface PaymentAttestorOptions {
  attestor: Attestor;
  chain: ChainReader;
  /**
   * The escrows whose orders this attestor serves. Only the on-ramp can hold an order this service will
   * sign: an off-ramp sale takes no card rail (nobody is paid out by card) and no quorum verifier
   * (`openSale` reverts `BankRailNeedsZkTls`). `offramp` is still read, so a sale id is refused by name
   * rather than as unknown; the entrypoint no longer configures one.
   */
  escrows: { onramp?: Address; offramp?: Address };
  /** Each LP's card acquirer source, keyed by the LP's address. A source that cannot read captures is refused at construction. */
  sources: ReadonlyMap<string, PaymentSource> | Record<string, PaymentSource>;
  journal: AttestationJournal;
  limiter?: RateLimiter;
  verify?: RequestVerifier;
  metrics?: AttestorMetrics;
  log?: Logger;
  /** Values that must never be logged or served: the RPC URL, source credentials. */
  redactValues?: readonly (string | undefined)[];
  /** Wall clock, unix seconds: judges a request's freshness. */
  now?: () => bigint;
  maxSkewSeconds?: number;
}

export interface AttestationResult {
  signer: Address;
  orderId: Hex;
  payment: ObservedPayment;
  signature: Hex;
  /** Served from the journal: the same statement this attestor already made for this order. */
  reused: boolean;
}

/**
 * The on-chain `bankTxId` of a PIX or boleto payment: the institution's id, hashed - as lp-node's `bankTxIdHash`.
 * Kept for the bank-fact readers and for reading journals written before bank rails left the quorum; a card
 * payment's id is `cardTransactionId`, hashed under its own domain.
 */
export const bankTxIdHash = (id: string): Hex => keccak256(toBytes(id));

/** The rails that are bank payments, which settle only on a zkTLS proof of the bank session. */
export const BANK_RAILS: ReadonlySet<Rail> = new Set([Rail.PIX, Rail.BOLETO, Rail.TED]);

const short = (h: string) => `${h.slice(0, 10)}…`;

export const samePayment = (a: ObservedPayment, b: ObservedPayment): boolean =>
  a.bankTxId.toLowerCase() === b.bankTxId.toLowerCase() && a.payeeKeyHash.toLowerCase() === b.payeeKeyHash.toLowerCase()
  && a.payerRef.toLowerCase() === b.payerRef.toLowerCase() && a.amountBrlCents === b.amountBrlCents
  && a.paidAt === b.paidAt && Number(a.rail) === Number(b.rail);

export class PaymentAttestor {
  readonly metrics: AttestorMetrics;
  readonly address: Address;
  ready = false;
  private readonly sources: Map<string, PaymentSource>;
  private readonly health = new Map<string, SourceHealth & { at: string }>();
  private readonly log: Logger;
  private queue: Promise<unknown> = Promise.resolve();

  constructor(private readonly o: PaymentAttestorOptions) {
    this.metrics = o.metrics ?? new AttestorMetrics();
    this.address = getAddress(o.attestor.address);
    this.log = o.log ?? silent;
    const entries = o.sources instanceof Map ? [...o.sources] : Object.entries(o.sources);
    this.sources = new Map(entries.map(([lp, s]) => [lp.toLowerCase(), s]));
    for (const [lp, s] of this.sources) {
      // A bank-fact reader (API Pix, Open Finance) handed in here would answer no request this service
      // serves: refused now, rather than discovered as a refusal on the first card order.
      if (typeof (s as Partial<PaymentSource>).cardCapture !== 'function') {
        throw new Error(`the ${s.kind} source for ${lp} cannot read card captures, the only payments this attestor signs`);
      }
    }
    const kinds = new Map<string, number>();
    for (const s of this.sources.values()) kinds.set(s.kind, (kinds.get(s.kind) ?? 0) + 1);
    for (const [kind, n] of kinds) this.metrics.set('mova_attestor_sources', n, { source: kind });
    this.syncJournalMetrics();
  }

  private now(): bigint {
    return this.o.now ? this.o.now() : BigInt(Math.floor(Date.now() / 1000));
  }

  /** Handle one request: a signature, or a `Refusal`. Anything else thrown is this service's fault. */
  async handle(req: SignedAttestationRequest): Promise<AttestationResult> {
    try {
      const r = await this.attest(req);
      this.metrics.inc('mova_attestor_requests_total', { result: r.reused ? 'reused' : 'signed' });
      this.log.info(`attested ${short(req.orderId)} on ${Rail[r.payment.rail]}${r.reused ? ' (again, from the journal)' : ''}`);
      return r;
    } catch (e) {
      this.metrics.inc('mova_attestor_requests_total', { result: 'refused' });
      if (e instanceof Refusal) {
        this.metrics.inc('mova_attestor_refusals_total', { reason: e.code });
        // The code only: a refusal message can name amounts, and the log is not the requester.
        this.log.warn(`refused ${short(req.orderId)}: ${e.code}`);
        throw e;
      }
      this.log.error(`internal error on ${short(req.orderId)}: ${redact(e instanceof Error ? e.message : String(e), this.o.redactValues)}`);
      throw e;
    }
  }

  private async attest(req: SignedAttestationRequest): Promise<AttestationResult> {
    const { chain, journal, attestor } = this.o;
    // First, and whoever sent it: the refusal depends on nothing but the rail, and the chain has already
    // decided it (see the header). Nothing is spent on a request no signature could make useful.
    if (BANK_RAILS.has(req.rail)) throw new Refusal('bank_rail_needs_zktls', BANK_RAIL_NEEDS_ZKTLS);
    if (req.rail !== Rail.CARD) throw new Refusal('rail_unsupported', `this attestor does not attest ${Rail[req.rail] ?? 'that rail'}`);

    const skew = BigInt(this.o.maxSkewSeconds ?? REQUEST_MAX_SKEW_SECONDS);
    const now = this.now();
    if (req.issuedAt + skew < now || req.issuedAt > now + skew) throw new Refusal('expired', 'the request is expired or from the future');

    const signed = await (this.o.verify ?? ecdsaRequestVerifier)({
      address: req.lp, domain: requestDomain(attestor.chainId, attestor.verifier), types: REQUEST_TYPES,
      primaryType: 'AttestationRequest', message: requestMessage(req), signature: req.signature,
    }).catch(() => false);
    if (!signed) throw new Refusal('bad_signature', 'the request is not signed by the LP it names');

    // Before the rate limit, so the set of buckets is bounded by the registry, not by a stranger's addresses.
    if ((await chain.tier(req.lp)) === Tier.NONE) throw new Refusal('not_admitted', 'the signer is not an LP admitted in LPRegistry');
    if (this.o.limiter && !this.o.limiter.take(req.lp.toLowerCase())) throw new Refusal('rate_limited', 'too many requests from this LP; retry later');
    if (journal.nonceUsed(req.lp, req.nonce)) throw new Refusal('replayed', 'this request has already been received');
    // Burned now, whatever follows: a request is one-shot, refused or not.
    journal.burnNonce(req.lp, req.nonce, req.issuedAt);
    this.syncJournalMetrics();

    const facts = await readTerms(chain, this.o.escrows, req.orderId);
    if (facts.verifier !== getAddress(attestor.verifier)) {
      throw new Refusal('wrong_verifier', 'the order names a different verifier than the one this attestor signs for');
    }
    // A registry tier is not enough: the charge is read at one LP's merchant account, under that LP's arrangement.
    if (facts.lp !== req.lp) {
      throw new Refusal('not_the_lp', facts.leg === 'onramp' ? 'only the offer\'s LP may ask about its orders' : 'only the sale\'s claimant may ask about it');
    }
    const [allowed, chainNow] = await Promise.all([chain.verifierAllowed(facts.escrow, facts.verifier), chain.now()]);
    if (!allowed) throw new Refusal('verifier_not_allowed', 'the escrow no longer accepts this verifier: no proof can settle');
    if (chainNow > facts.payBy) throw new Refusal('window_closed', 'the order\'s pay window has closed on-chain');

    const t = facts.terms;
    const differ = [
      req.payeeKeyHash.toLowerCase() !== t.payeeKeyHash.toLowerCase() && 'payeeKeyHash',
      req.orderBrlCents !== t.brlCents && 'orderBrlCents',
      req.lockedAt !== t.lockedAt && 'lockedAt',
    ].filter((x): x is string => typeof x === 'string');
    if (differ.length) throw new Refusal('terms_disagree', `the chain's ${differ.join(', ')} differ from the request's`);

    // Checked before the source is asked, so a request that cannot settle does not spend the LP's source calls.
    if (!t.acceptedRails.includes(req.rail)) throw new Refusal('rail_not_accepted', `the ${facts.leg === 'onramp' ? 'order' : 'sale'} does not accept ${Rail[req.rail]}`);
    const source = this.sources.get(req.lp.toLowerCase());
    if (!source) throw new Refusal('no_source', 'this attestor has no card acquirer source for this LP');

    return this.card(req, facts, source, { since: t.lockedAt, until: chainNow });
  }

  /**
   * A card charge, from the acquirer. The acquirer shows the charge's merchant, reference, status, captured
   * total and capture time; the request supplies the committed fee and the salt, which must open the offer's
   * commitment together with the merchant the acquirer shows. `attestCard` then refuses anything not CAPTURED,
   * a total other than the order plus that fee, and a capture from before the lock, and signs the ORDER's
   * amount under the acquirer-scoped transaction id.
   */
  private async card(
    req: SignedAttestationRequest, facts: ChainTerms, source: PaymentSource, window: Pick<CardQuery, 'since' | 'until'>,
  ): Promise<AttestationResult> {
    const merchant = parseCardPayee(req.payee);
    if (!merchant) throw new Refusal('payee_unopened', 'a card payee is acquirerId|merchantId|feeBps');
    let payeeKeyHash: Hex;
    let fee: bigint;
    let bankTxId: Hex;
    try {
      payeeKeyHash = cardMerchantCommitment(merchant, req.salt);
      fee = cardFee(facts.terms.brlCents, merchant.feeBps);
      bankTxId = cardTransactionId(merchant.acquirerId, req.bankTxId);
    } catch {
      throw new Refusal('payee_unopened', 'the disclosed acquirer, merchant, fee and salt do not form a commitment');
    }
    const capture = await this.ask(source, req, () => source.cardCapture({
      acquirerId: merchant.acquirerId, transactionId: req.bankTxId, reference: req.orderId, since: window.since, until: window.until,
    }));
    if (!capture) throw new Refusal('not_observed', 'the acquirer has no charge with this transaction id through this order\'s checkout');
    if (capture.transactionId !== req.bankTxId || capture.acquirerId !== merchant.acquirerId) {
      throw new Refusal('source_disagrees', 'the acquirer\'s record carries a different transaction or acquirer id');
    }
    // How a charge belongs to an order: the reference its checkout carried. A capture through another order's checkout paid for that order.
    if (capture.reference.toLowerCase() !== req.orderId.toLowerCase()) throw new Refusal('source_disagrees', 'the charge was made through another order\'s checkout');
    if (capture.merchantId !== merchant.merchantId) throw new Refusal('source_disagrees', 'the acquirer shows a different merchant account than the one disclosed');
    if (capture.status === 'CAPTURED') {
      if (capture.capturedAt === undefined) throw new Refusal('source_disagrees', 'the acquirer reports a capture without a capture time');
      this.sameAmountAndTime(capture.amountCents, capture.capturedAt, req);
    }
    // Anything but CAPTURED goes on to attestCard, which refuses it by name; there is no capture time to compare.
    const seen: ObservedCardCapture = {
      acquirerId: capture.acquirerId, transactionId: capture.transactionId, merchantId: capture.merchantId, salt: req.salt,
      feeBps: merchant.feeBps, payerRef: req.payerRef, status: capture.status, capturedAmountBrlCents: capture.amountCents,
      capturedAt: capture.capturedAt ?? 0n,
    };
    const payment: ObservedPayment = {
      bankTxId, payeeKeyHash, payerRef: req.payerRef, amountBrlCents: capture.amountCents - fee, paidAt: seen.capturedAt, rail: Rail.CARD,
    };
    return this.sign(req, facts, source, payment, async () => {
      const r = await this.o.attestor.attestCard(facts.terms, seen);
      if (!samePayment(r.payment, payment)) throw new Error('attestCard signed a payment other than the one derived here');
      return r.signature;
    });
  }

  private sameAmountAndTime(amountCents: bigint, at: bigint, req: SignedAttestationRequest): void {
    if (amountCents !== req.amountBrlCents) {
      throw new Refusal('source_disagrees', `the source shows ${amountCents} centavos, the request claims ${req.amountBrlCents}`);
    }
    if (at !== req.paidAt) throw new Refusal('source_disagrees', `the source shows settlement at ${at}, the request claims ${req.paidAt}`);
  }

  /** A source call, with its failure mapped to a fixed refusal: a source's own error text is never passed on. */
  private async ask<T>(source: PaymentSource, req: SignedAttestationRequest, call: () => Promise<T>): Promise<T> {
    try {
      return await call();
    } catch (e) {
      const code = e instanceof SourceError ? e.code : 'unavailable';
      this.metrics.inc('mova_attestor_source_errors_total', { source: source.kind, code });
      this.log.warn(`source ${source.kind} failed on ${short(req.orderId)}: ${code}`);
      if (code === 'rate_limited') throw new Refusal('source_rate_limited', 'the source is rate-limited; retry later');
      if (code === 'consent') throw new Refusal('consent_invalid', 'the LP\'s credentials for this source are not usable');
      throw new Refusal('source_unavailable', 'the source could not be read');
    }
  }

  /**
   * The journal check, the signature and the journal record, one request at a time: two concurrent requests
   * presenting one payment for two orders must not both pass the check before either is recorded.
   */
  private sign(
    req: SignedAttestationRequest, facts: ChainTerms, source: PaymentSource, payment: ObservedPayment, produce: () => Promise<Hex>,
  ): Promise<AttestationResult> {
    const run = this.queue.then(async (): Promise<AttestationResult> => {
      const prior = this.o.journal.signedFor(payment.bankTxId);
      if (prior) {
        if (prior.orderId.toLowerCase() !== req.orderId.toLowerCase()) {
          throw new Refusal('bank_tx_reused', 'this payment has already been attested for another order');
        }
        if (!samePayment(prior.payment, payment)) {
          throw new Refusal('bank_tx_reused', 'this payment was attested for this order with different details');
        }
        return { signer: this.address, orderId: req.orderId, payment: prior.payment, signature: prior.signature, reused: true };
      }
      let signature: Hex;
      try {
        signature = await produce();
      } catch (e) {
        if (e instanceof RefusedToAttest) throw new Refusal('refused', e.message);
        throw e;
      }
      // Durable before the signature leaves: see journal.ts.
      this.o.journal.recordSigned({
        bankTxId: payment.bankTxId, orderId: req.orderId, leg: facts.leg, escrow: facts.escrow, lp: facts.lp,
        source: source.kind, payment, signature, at: this.now(),
      });
      this.metrics.inc('mova_attestor_signed_brl_cents_total', { rail: Rail[payment.rail] }, Number(payment.amountBrlCents));
      this.syncJournalMetrics();
      return { signer: this.address, orderId: req.orderId, payment, signature, reused: false };
    });
    this.queue = run.catch(() => undefined);
    return run;
  }

  private syncJournalMetrics(): void {
    this.metrics.set('mova_attestor_journal_records', this.o.journal.size);
    this.metrics.set('mova_attestor_signatures', this.o.journal.signatures);
  }

  /** Probe every source. Health is kept as fixed phrases: it is served on `/status`. */
  async probeSources(): Promise<void> {
    const ok = new Map<string, number>();
    for (const [lp, s] of this.sources) {
      let h: SourceHealth;
      try {
        h = s.probe ? await s.probe() : { ok: true, detail: 'no probe' };
      } catch {
        h = { ok: false, detail: 'probe failed' };
      }
      this.health.set(lp, { ...h, at: new Date().toISOString() });
      ok.set(s.kind, (ok.get(s.kind) ?? 0) + (h.ok ? 1 : 0));
    }
    for (const [kind, n] of ok) this.metrics.set('mova_attestor_source_ok', n, { source: kind });
  }

  /** The operator's view. No key, credential, salt or error text: counts, addresses and fixed phrases. */
  status() {
    const a = this.o.attestor;
    return {
      ready: this.ready,
      attestor: this.address,
      chainId: a.chainId,
      verifier: getAddress(a.verifier),
      escrows: this.o.escrows,
      /** What this attestor signs: one rail. Bank rails settle only on zkTLS proofs (see the header). */
      rails: [Rail[Rail.CARD]],
      journal: { records: this.o.journal.size, signatures: this.o.journal.signatures },
      requests: {
        signed: this.metrics.get('mova_attestor_requests_total', { result: 'signed' }),
        reused: this.metrics.get('mova_attestor_requests_total', { result: 'reused' }),
        refused: this.metrics.get('mova_attestor_requests_total', { result: 'refused' }),
      },
      sources: [...this.sources].map(([lp, s]) => ({ lp: getAddress(lp), kind: s.kind, health: this.health.get(lp) ?? null })),
    };
  }
}
