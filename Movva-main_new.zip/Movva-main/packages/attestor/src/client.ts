/**
 * An attestor service, as the LP node's `QuorumProver` calls it: `RemoteAttestor` implements lp-node's
 * `AttestorEndpoint`. It asks for card captures only.
 *
 * ## PIX and boletos are refused here, before anything is sent
 *
 * `AttestorEndpoint` still declares `attest` (PIX) and `attestBoleto`. lp-node's `QuorumProver` no longer calls them - it
 * refuses PIX and boleto proofs itself - but whoever does call them gets `AttestorRefused` with the service's own code,
 * `bank_rail_needs_zktls`, and its own message, without a request: PIX, boleto and TED settle only on a zkTLS proof of the
 * bank session (the escrows revert `BankRailNeedsZkTls` for a bank-rail offer or sale through an attestor quorum), so the
 * service would refuse them, and there is nothing to gain by spending a nonce and a round trip to hear it.
 *
 * ## What it sends for a card
 *
 * The capture as the node's acquirer showed it (`ObservedCardCapture`), with what a service that looks the charge
 * up itself needs: the acquirer's transaction id to ask for, and the merchant, committed fee and salt to open the
 * offer's commitment from what the acquirer shows. A merchant, fee and salt that do not open the order's
 * commitment are refused before anything is sent, so a node bug surfaces here and not as a refusal at every PSP.
 *
 * ## What it checks in the answer, and what it returns
 *
 *  - the signature recovers to THIS attestor's registered address, over the payment and order - never the address
 *    the response claims;
 *  - the payment signed is on the rail asked about.
 *
 * It returns the payment as the service signed it, not as the node claimed it: the service signs its source's
 * record - the ORDER's amount, under the acquirer-scoped transaction id. Which signatures combine into a proof, and
 * whether their payment proves the order, is the prover's decision (lp-node's attestation.ts): only identical
 * payments, only one that proves the order, and never two for one order.
 */
import { recoverTypedDataAddress, type Address, type Hex } from 'viem';
import {
  EIP712_DOMAIN, PAYMENT_TYPES, Rail, cardMerchantCommitment,
  type ObservedCardCapture, type ObservedPayment, type OrderTerms,
} from '@mova/ramp';
import type { AttestorEndpoint, BoletoClaim, PixClaim, SignedPayment } from '@mova/lp-node';
import { BANK_RAIL_NEEDS_ZKTLS, REFUSAL_STATUS } from './refusal.js';
import {
  cardPayee, newRequestNonce, requestToJson, signAttestationRequest,
  type AttestationRequest, type REQUEST_TYPES, type requestDomain, type requestMessage,
} from './request.js';

export class AttestorRefused extends Error {
  constructor(readonly status: number, readonly code: string, message: string) {
    super(`attestor refused (${code}): ${message}`);
  }
}

export interface RequestSigner {
  readonly address: Address;
  signTypedData(args: {
    domain: ReturnType<typeof requestDomain>; types: typeof REQUEST_TYPES; primaryType: 'AttestationRequest';
    message: ReturnType<typeof requestMessage>;
  }): Promise<Hex>;
}

export interface RemoteAttestorOptions {
  /** The service's API base, e.g. `https://attestor.psp.example`. */
  url: string;
  /** The attestor's address as registered in the verifier. */
  address: Address;
  chainId: number;
  verifier: Address;
  /** The LP's key. */
  signer: RequestSigner;
  timeoutMs?: number;
  /** Unix seconds. */
  now?: () => number;
}

interface WirePayment { bankTxId: Hex; payeeKeyHash: Hex; payerRef: Hex; amountBrlCents: string; paidAt: string; rail: number }

type Claim = Pick<AttestationRequest, 'rail' | 'bankTxId' | 'payee' | 'salt' | 'amountBrlCents' | 'paidAt' | 'payerRef'>;

/** Whether an opening forms the order's commitment; one that forms no commitment at all does not. */
const opens = (commit: () => Hex, expected: Hex): boolean => {
  try {
    return commit().toLowerCase() === expected.toLowerCase();
  } catch {
    return false;
  }
};

/** The service's refusal of a bank rail, as `request` would have raised it from the service's answer. */
const bankRailRefusal = () => new AttestorRefused(REFUSAL_STATUS.bank_rail_needs_zktls, 'bank_rail_needs_zktls', BANK_RAIL_NEEDS_ZKTLS);

export class RemoteAttestor implements AttestorEndpoint {
  readonly address: Address;

  constructor(private readonly o: RemoteAttestorOptions) {
    this.address = o.address;
  }

  /** PIX: refused without a request. See the header. */
  async attest(_terms: OrderTerms, _claim: PixClaim): Promise<SignedPayment> {
    throw bankRailRefusal();
  }

  /** Boleto: refused without a request. See the header. */
  async attestBoleto(_terms: OrderTerms, _claim: BoletoClaim): Promise<SignedPayment> {
    throw bankRailRefusal();
  }

  /** The captured total (order plus committed fee) is what is claimed; the order's amount is what is signed. */
  async attestCard(terms: OrderTerms, seen: ObservedCardCapture): Promise<SignedPayment> {
    const merchant = { acquirerId: seen.acquirerId, merchantId: seen.merchantId, feeBps: seen.feeBps };
    if (!opens(() => cardMerchantCommitment(merchant, seen.salt), terms.payeeKeyHash)) {
      throw new Error('the capture\'s merchant, fee and salt do not open the offer\'s commitment');
    }
    return this.request(terms, {
      rail: Rail.CARD, bankTxId: seen.transactionId, payee: cardPayee(merchant), salt: seen.salt,
      amountBrlCents: seen.capturedAmountBrlCents, paidAt: seen.capturedAt, payerRef: seen.payerRef,
    });
  }

  private async request(terms: OrderTerms, claim: Claim): Promise<SignedPayment> {
    const issuedAt = BigInt(this.o.now ? this.o.now() : Math.floor(Date.now() / 1000));
    const req = await signAttestationRequest(this.o.signer, { chainId: this.o.chainId, verifier: this.o.verifier }, {
      lp: this.o.signer.address, orderId: terms.orderId, payeeKeyHash: terms.payeeKeyHash, orderBrlCents: terms.brlCents,
      lockedAt: terms.lockedAt, ...claim, issuedAt, nonce: newRequestNonce(),
    });
    const res = await fetch(`${this.o.url.replace(/\/$/, '')}/v1/attest`, {
      method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(requestToJson(req)),
      signal: AbortSignal.timeout(this.o.timeoutMs ?? 20_000),
    });
    const body = await res.json().catch(() => ({})) as { error?: string; message?: string; payment?: WirePayment; signature?: Hex };
    if (res.status !== 200) throw new AttestorRefused(res.status, body.error ?? 'unknown', body.message ?? `HTTP ${res.status}`);
    const w = body.payment;
    if (!w || typeof body.signature !== 'string') throw new Error('the attestor answered 200 without a payment and signature');
    let payment: ObservedPayment;
    let signer: Address;
    try {
      payment = {
        bankTxId: w.bankTxId, payeeKeyHash: w.payeeKeyHash, payerRef: w.payerRef, amountBrlCents: BigInt(w.amountBrlCents), paidAt: BigInt(w.paidAt), rail: w.rail as Rail,
      };
      signer = await recoverTypedDataAddress({
        domain: EIP712_DOMAIN(this.o.chainId, this.o.verifier), types: PAYMENT_TYPES, primaryType: 'Payment',
        message: { orderId: terms.orderId, ...payment }, signature: body.signature,
      });
    } catch {
      throw new Error('the attestor answered with a payment or signature that does not decode');
    }
    if (signer.toLowerCase() !== this.address.toLowerCase()) throw new Error(`the signature is not from attestor ${this.address}`);
    if (Number(payment.rail) !== Number(claim.rail)) {
      throw new Error(`the attestor signed a ${Rail[payment.rail] ?? 'different'} payment for a ${Rail[claim.rail]} request`);
    }
    return { payment, signature: body.signature };
  }
}
