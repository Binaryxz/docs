/**
 * An LP's bank as an Open Finance Brasil transmitter, in memory, over HTTP: a token endpoint taking PS256
 * `private_key_jwt` assertions (client credentials for `consents`, refresh token for `accounts`), Consents 3.3.1
 * `GET /consents/{consentId}`, and Accounts 2.4.2 `GET /accounts/{accountId}` and `.../transactions-current`, as
 * sources/open-finance.ts reads them. For the retained bank-fact reader's tests, as `MockApiPixPsp` is for API Pix;
 * the attestor service no longer reads Open Finance (sources/open-finance.ts).
 *
 * Each PSP reading the account under the LP's consent is a client with its own registered key and refresh token, and
 * gets its own tokens. Its records are set by the test - which is how a consent that lapsed, a consented account
 * that is not the one onboarded, or an entry still processing is staged.
 */
import { constants, verify, type KeyObject } from 'node:crypto';
import { createServer, type IncomingHttpHeaders, type Server } from 'node:http';

/** A settled PIX credit, as Accounts 2.4.2 lists it; `overrides` replace any field. */
export function openFinancePixCredit(c: { transactionId: string; amount: string; at: string }, overrides: Record<string, unknown> = {}) {
  return {
    transactionId: c.transactionId, completedAuthorisedPaymentType: 'TRANSACAO_EFETIVADA', creditDebitType: 'CREDITO', transactionName: 'PIX RECEBIDO',
    type: 'PIX', transactionAmount: { amount: c.amount, currency: 'BRL' }, transactionDateTime: c.at,
    partieCnpjCpf: '52998224725', partiePersonType: 'PESSOA_NATURAL', partieCompeCode: '341', partieBranchCode: '1234',
    partieNumber: '00012345', partieCheckDigit: '6', ...overrides,
  };
}

export class MockOpenFinanceTransmitter {
  consent: Record<string, unknown>;
  identity: Record<string, unknown> = {
    compeCode: '001', branchCode: '0001', number: '12345678', checkDigit: '9', type: 'CONTA_DEPOSITO_A_VISTA', subtype: 'INDIVIDUAL', currency: 'BRL',
  };
  /** `transactions-current`, page by page. */
  pages: unknown[][] = [[]];
  transactionsStatus = 200;
  transactionCalls = 0;
  /** Makes `links.next` point at another origin. */
  nextOrigin?: string;
  readonly calls: { path: string; query: URLSearchParams; headers: IncomingHttpHeaders }[] = [];
  /** Every client assertion presented at the token endpoint. */
  readonly assertions: string[] = [];
  origin = '';
  private readonly clients = new Map<string, { publicKey: KeyObject; refreshToken: string }>();
  private readonly now: () => number;
  private server?: Server;

  constructor(readonly consentId: string, readonly accountId: string, o: { now?: () => number } = {}) {
    this.now = o.now ?? Date.now;
    const at = this.now();
    this.consent = {
      consentId, creationDateTime: new Date(at - 14 * 86_400_000).toISOString(), status: 'AUTHORISED',
      statusUpdateDateTime: new Date(at - 14 * 86_400_000 + 60_000).toISOString(),
      permissions: ['ACCOUNTS_READ', 'ACCOUNTS_TRANSACTIONS_READ', 'RESOURCES_READ'], expirationDateTime: new Date(at + 365 * 86_400_000).toISOString(),
    };
  }

  get tokenUrl(): string { return `${this.origin}/token`; }
  get accountsBaseUrl(): string { return `${this.origin}/open-banking/accounts/v2`; }
  get consentsBaseUrl(): string { return `${this.origin}/open-banking/consents/v3`; }

  /** A PSP's client: registered at DCR with `publicKey`, holding `refreshToken` from the LP's consent. */
  register(clientId: string, publicKey: KeyObject, refreshToken: string): void {
    this.clients.set(clientId, { publicKey, refreshToken });
  }

  /** A settled PIX credit to the account, on the last page. */
  pixCredit(c: { transactionId: string; amount: string; at: string }): void {
    this.pages[this.pages.length - 1].push(openFinancePixCredit(c));
  }

  async listen(): Promise<void> {
    this.server = createServer(async (rq, rs) => {
      const url = new URL(rq.url ?? '/', 'http://x');
      const chunks: Buffer[] = [];
      for await (const c of rq) chunks.push(c as Buffer);
      const meta = { requestDateTime: new Date(this.now()).toISOString() };
      const send = (s: number, b: unknown) => { rs.writeHead(s, { 'content-type': 'application/json' }); rs.end(JSON.stringify(b)); };
      const error = (s: number) => send(s, { errors: [{ code: String(s), title: 'erro', detail: 'echoes 52998224725' }], meta });
      this.calls.push({ path: url.pathname, query: url.searchParams, headers: rq.headers });

      if (url.pathname === '/token') {
        const form = new URLSearchParams(Buffer.concat(chunks).toString('utf8'));
        const assertion = form.get('client_assertion') ?? '';
        this.assertions.push(assertion);
        const [h, p, s] = assertion.split('.');
        let claims: { iss?: string; sub?: string; aud?: string } | undefined;
        try {
          claims = JSON.parse(Buffer.from(p ?? '', 'base64url').toString()) as typeof claims;
        } catch {
          claims = undefined;
        }
        const client = claims?.iss ? this.clients.get(claims.iss) : undefined;
        const okSig = !!client && !!s && verify('sha256', Buffer.from(`${h}.${p}`), {
          key: client.publicKey, padding: constants.RSA_PKCS1_PSS_PADDING, saltLength: constants.RSA_PSS_SALTLEN_DIGEST,
        }, Buffer.from(s, 'base64url'));
        if (!client || !okSig || claims?.sub !== claims?.iss || claims?.aud !== this.tokenUrl) return send(401, { error: 'invalid_client' });
        const id = claims!.iss!;
        if (form.get('grant_type') === 'client_credentials' && form.get('scope') === 'consents') return send(200, { access_token: `cc-${id}`, expires_in: 300 });
        if (form.get('grant_type') === 'refresh_token' && form.get('refresh_token') === client.refreshToken) return send(200, { access_token: `acc-${id}`, expires_in: 300 });
        return send(400, { error: 'invalid_grant' });
      }
      const bearer = (prefix: string) => [...this.clients.keys()].some((id) => rq.headers.authorization === `Bearer ${prefix}-${id}`);
      if (url.pathname === `/open-banking/consents/v3/consents/${encodeURIComponent(this.consentId)}`) {
        if (!bearer('cc')) return error(401);
        return send(200, { data: this.consent, links: { self: url.href }, meta });
      }
      if (!bearer('acc')) return error(401);
      if (url.pathname === `/open-banking/accounts/v2/accounts/${this.accountId}`) return send(200, { data: this.identity, links: {}, meta: {} });
      if (url.pathname === `/open-banking/accounts/v2/accounts/${this.accountId}/transactions-current`) {
        this.transactionCalls++;
        if (this.transactionsStatus !== 200) return error(this.transactionsStatus);
        const page = Number(url.searchParams.get('page') ?? '1');
        const next = new URL(url.href.replace('http://x', this.nextOrigin ?? this.origin));
        next.searchParams.set('page', String(page + 1));
        return send(200, {
          data: this.pages[page - 1] ?? [],
          links: { self: url.href, ...(page < this.pages.length ? { next: next.href } : {}) },
          meta,
        });
      }
      return error(404);
    });
    await new Promise<void>((r) => this.server!.listen(0, '127.0.0.1', () => r()));
    const a = this.server.address();
    this.origin = `http://127.0.0.1:${typeof a === 'object' && a ? a.port : 0}`;
  }

  close(): Promise<void> {
    return new Promise((r) => { this.server?.close(() => r()); this.server?.closeAllConnections(); });
  }
}
