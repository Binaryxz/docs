/**
 * Prometheus exposition for the attestor, prefix `mova_attestor_`.
 *
 * The discipline is the monitor's and the LP node's: label values come only from fixed vocabularies in
 * code - a refusal code, a rail name, a source kind - never from a request, an error message, a PIX key or
 * an amount. An LP address is not a label either: which LPs a PSP attests for is its customer list.
 */
import { REFUSAL_CODES } from './refusal.js';

type Kind = 'counter' | 'gauge';

const DEFS = {
  mova_attestor_up: ['gauge', '1 while the attestor process is running.'],
  mova_attestor_ready: ['gauge', '1 once the chain, the verifier and the journal have been checked.'],
  mova_attestor_requests_total: ['counter', 'Attestation requests, by result (signed, reused, refused).'],
  mova_attestor_refusals_total: ['counter', 'Requests refused, by reason code.'],
  mova_attestor_signed_brl_cents_total: ['counter', 'Centavos in payments newly attested, by rail.'],
  mova_attestor_source_errors_total: ['counter', 'Source calls that failed, by source kind and error code.'],
  mova_attestor_source_ok: ['gauge', 'Sources whose last probe succeeded, by source kind.'],
  mova_attestor_sources: ['gauge', 'Configured sources, by source kind.'],
  mova_attestor_journal_records: ['gauge', 'Records in the attestation journal.'],
  mova_attestor_signatures: ['gauge', 'Distinct payments this attestor has signed for.'],
} as const satisfies Record<string, readonly [Kind, string]>;

export type AttestorMetricName = keyof typeof DEFS;
type Labels = Record<string, string>;

const esc = (s: string) => s.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n');
const key = (labels: Labels) => Object.keys(labels).sort().map((k) => `${k}="${esc(labels[k])}"`).join(',');

export class AttestorMetrics {
  private readonly series = new Map<AttestorMetricName, Map<string, number>>();

  constructor() {
    for (const n of Object.keys(DEFS) as AttestorMetricName[]) this.series.set(n, new Map());
    this.set('mova_attestor_up', 1);
    this.set('mova_attestor_ready', 0);
    // Declared at zero, so an alert on a refusal reason exists before the first refusal does.
    for (const reason of REFUSAL_CODES) this.series.get('mova_attestor_refusals_total')!.set(key({ reason }), 0);
  }

  inc(name: AttestorMetricName, labels: Labels = {}, by = 1): void {
    const m = this.series.get(name)!;
    const k = key(labels);
    m.set(k, (m.get(k) ?? 0) + by);
  }

  set(name: AttestorMetricName, value: number, labels: Labels = {}): void {
    this.series.get(name)!.set(key(labels), value);
  }

  get(name: AttestorMetricName, labels: Labels = {}): number {
    return this.series.get(name)!.get(key(labels)) ?? 0;
  }

  render(): string {
    const lines: string[] = [];
    for (const [name, [type, help]] of Object.entries(DEFS) as [AttestorMetricName, readonly [Kind, string]][]) {
      lines.push(`# HELP ${name} ${help}`);
      lines.push(`# TYPE ${name} ${type}`);
      const m = this.series.get(name)!;
      if (m.size === 0 && type === 'counter') lines.push(`${name} 0`);
      for (const [k, v] of m) lines.push(`${name}${k ? `{${k}}` : ''} ${Number.isFinite(v) ? v : 0}`);
    }
    return `${lines.join('\n')}\n`;
  }
}
