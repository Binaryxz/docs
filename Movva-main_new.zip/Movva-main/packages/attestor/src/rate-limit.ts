/**
 * A token bucket per LP.
 *
 * Two things make a per-LP limit necessary rather than tidy. Every attestation costs the PSP a call to
 * its source, and Open Finance meters those calls per client per month (240 successful
 * `transactions-current` calls is the published minimum; beyond what the transmitter allows it answers
 * 423) - so one LP retrying a stuck order every few seconds could spend another LP's month. And the
 * service is reachable by anyone, so the limit is applied only AFTER the signature and registry
 * admission checks: an unauthenticated flood cannot empty an LP's bucket, and the set of buckets is
 * bounded by the registry rather than by whatever addresses a stranger invents.
 */
export class RateLimiter {
  private readonly buckets = new Map<string, { tokens: number; at: number }>();

  constructor(private readonly o: { burst: number; perMinute: number; now?: () => number }) {
    if (o.burst < 1 || o.perMinute <= 0) throw new Error('a rate limit needs a burst of at least 1 and a positive rate');
  }

  /** Take one token for `key`; false when none is left. */
  take(key: string): boolean {
    const now = this.o.now ? this.o.now() : Date.now();
    const b = this.buckets.get(key) ?? { tokens: this.o.burst, at: now };
    b.tokens = Math.min(this.o.burst, b.tokens + ((now - b.at) / 60_000) * this.o.perMinute);
    b.at = now;
    const ok = b.tokens >= 1;
    if (ok) b.tokens -= 1;
    this.buckets.set(key, b);
    return ok;
  }
}
