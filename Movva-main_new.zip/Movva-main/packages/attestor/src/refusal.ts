/**
 * Why the service did not sign, as a fixed vocabulary.
 *
 * Every refusal carries a code from this list and an HTTP status. The code is what metrics and logs
 * record; the message goes only to the authenticated requester, and only after redaction. That split is
 * deliberate: a refusal message may name amounts or say which field disagreed, which the LP needs to fix
 * its request, but a metric label or a log line is read by people who have no business seeing either -
 * and a message built from a bank's response is text this service does not control.
 *
 * ## `bank_rail_needs_zktls`
 *
 * PIX, boleto and TED requests are refused by this code, whoever asks and whatever the payment. Those
 * rails settle only on a zkTLS proof of the bank session (`IAttestorVerifier.provesBankSession`):
 * `FiatEscrow.postOffer` reverts `BankRailNeedsZkTls()` for any offer taking a bank rail through a
 * verifier that cannot prove one, and `OffRampEscrow.openSale` reverts it for every sale, since every
 * payout is a bank payment. An AttestorQuorumVerifier cannot (it counts signatures, and a quorum that
 * colludes can sign a payment that never happened), so no order or sale this attestor's quorum serves
 * can take a bank rail, and a signature over a PIX or boleto payment could never settle anything. The
 * quorum serves one rail: CARD, on an institutional LP's card-only offer, where the acquirer's record
 * of a captured charge is the fact and no bank session exists to prove.
 */
export const REFUSAL_STATUS = {
  // The request itself.
  malformed: 400,
  expired: 401,
  bad_signature: 401,
  not_admitted: 403,
  not_the_lp: 403,
  replayed: 409,
  rate_limited: 429,
  // The chain.
  unknown_order: 404,
  ambiguous_order: 409,
  wrong_state: 422,
  wrong_verifier: 422,
  verifier_not_allowed: 422,
  window_closed: 422,
  boleto_not_issued: 422,
  terms_disagree: 409,
  rail_unsupported: 422,
  /** PIX, boleto or TED: see the header. 422, as for any request this service will never sign. */
  bank_rail_needs_zktls: 422,
  rail_not_accepted: 422,
  // The bank.
  no_source: 422,
  not_observed: 422,
  source_disagrees: 422,
  returned: 422,
  payee_unopened: 422,
  refused: 422,
  bank_tx_reused: 409,
  source_unavailable: 502,
  source_rate_limited: 503,
  consent_invalid: 503,
} as const;

export type RefusalCode = keyof typeof REFUSAL_STATUS;

export const REFUSAL_CODES = Object.keys(REFUSAL_STATUS) as RefusalCode[];

/**
 * The refusal's message, shared by the service and `RemoteAttestor` so an LP operator reads the same
 * sentence whichever side refused.
 */
export const BANK_RAIL_NEEDS_ZKTLS = 'PIX, boleto and TED settle only on a zkTLS proof of the bank session: the escrows refuse any '
  + 'bank-rail offer or sale whose verifier is an attestor quorum (BankRailNeedsZkTls), so an attestation of this payment '
  + 'could never settle anything. This attestor signs card captures only.';

export class Refusal extends Error {
  readonly status: number;

  constructor(readonly code: RefusalCode, message: string) {
    super(message);
    this.status = REFUSAL_STATUS[code];
  }
}
