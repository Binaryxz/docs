/**
 * The attestor's memory: every signature it has given, and every request nonce still inside its window.
 *
 * ## Why a signature is journaled before it is returned
 *
 * The escrow burns a `bankTxId` when a proof settles, but only on that escrow, and only once a proof
 * reaches it. Between signing and settlement - or across two escrows, or two verifiers - nothing on-chain
 * stops one payment being presented for a second order. The attestor is the one party that sees every
 * statement it makes, so it refuses one bankTxId for two orders (`bank_tx_reused`), and that refusal is
 * only as good as its memory. So `recordSigned` returns only after fsync, and the service writes the
 * record BEFORE the signature leaves the process: a crash after signing and before journaling loses a
 * signature nobody received, never one somebody holds.
 *
 * Nonces are journaled too. A request is one-shot; a nonce forgotten on restart would let a request seen
 * seconds before the crash be replayed after it. Only nonces still inside `maxSkewSeconds` matter - an
 * older request is refused as expired anyway - so they are dropped from memory as they age and from disk at
 * compaction.
 *
 * The file format, fsync discipline, torn-line recovery and atomic compaction are lp-node's
 * `JsonlJournal`, reused rather than rewritten. The file holds no key and no salt, but it does link orders
 * to payments: keep it 0600 on the attestor's own encrypted volume.
 */
import type { Address, Hex } from 'viem';
import type { Journal } from '@mova/lp-node';
import type { ObservedPayment } from '@mova/ramp';

export interface SignedRecord {
  t: 'signed';
  /** keccak256 of the institution's id: the key refusals are made on. */
  bankTxId: Hex;
  orderId: Hex;
  leg: 'onramp' | 'offramp';
  escrow: Address;
  lp: Address;
  source: string;
  payment: ObservedPayment;
  signature: Hex;
  /** Unix seconds. */
  at: bigint;
}

export interface NonceRecord {
  t: 'nonce';
  lp: Address;
  nonce: Hex;
  issuedAt: bigint;
}

export type AttestorRecord = SignedRecord | NonceRecord;

export class AttestationJournal {
  private readonly signed = new Map<string, SignedRecord>();
  private readonly nonces = new Map<string, bigint>();
  private records = 0;

  constructor(
    private readonly journal: Journal<AttestorRecord>,
    private readonly o: { maxSkewSeconds: number; now: () => bigint; compactAtBytes?: number },
  ) {}

  load(): void {
    for (const r of this.journal.load()) {
      this.records++;
      if (r.t === 'signed') {
        // The first statement stands. A second for the same id could only exist if the file were edited.
        if (!this.signed.has(r.bankTxId.toLowerCase())) this.signed.set(r.bankTxId.toLowerCase(), r);
      } else if (r.t === 'nonce') {
        this.nonces.set(nonceKey(r.lp, r.nonce), r.issuedAt);
      }
    }
    this.prune();
  }

  signedFor(bankTxId: Hex): SignedRecord | undefined {
    return this.signed.get(bankTxId.toLowerCase());
  }

  get signatures(): number {
    return this.signed.size;
  }

  get size(): number {
    return this.records;
  }

  nonceUsed(lp: Address, nonce: Hex): boolean {
    this.prune();
    return this.nonces.has(nonceKey(lp, nonce));
  }

  burnNonce(lp: Address, nonce: Hex, issuedAt: bigint): void {
    this.journal.append({ t: 'nonce', lp, nonce, issuedAt });
    this.records++;
    this.nonces.set(nonceKey(lp, nonce), issuedAt);
    this.maybeCompact();
  }

  recordSigned(r: Omit<SignedRecord, 't'>): void {
    const rec: SignedRecord = { t: 'signed', ...r };
    this.journal.append(rec);
    this.records++;
    this.signed.set(rec.bankTxId.toLowerCase(), rec);
    this.maybeCompact();
  }

  close(): void {
    this.journal.close();
  }

  private prune(): void {
    const oldest = this.o.now() - BigInt(this.o.maxSkewSeconds);
    for (const [k, issuedAt] of this.nonces) if (issuedAt < oldest) this.nonces.delete(k);
  }

  /** Every signature, and only the nonces that can still be replayed. */
  private maybeCompact(): void {
    const { compactAtBytes } = this.o;
    if (!compactAtBytes || !this.journal.compact || !this.journal.size || this.journal.size() < compactAtBytes) return;
    this.prune();
    const snapshot: AttestorRecord[] = [
      ...this.signed.values(),
      ...[...this.nonces].map(([k, issuedAt]): NonceRecord => {
        const [lp, nonce] = k.split(':') as [Address, Hex];
        return { t: 'nonce', lp, nonce, issuedAt };
      }),
    ];
    this.journal.compact(snapshot);
    this.records = snapshot.length;
  }
}

const nonceKey = (lp: Address, nonce: Hex) => `${lp.toLowerCase()}:${nonce.toLowerCase()}`;
