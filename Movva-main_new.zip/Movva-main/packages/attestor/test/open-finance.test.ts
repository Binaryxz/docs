import { afterEach, beforeAll, describe, expect, it } from 'vitest';
import { generateKeyPairSync, type KeyObject } from 'node:crypto';
import { ApiPixClient } from '@mova/lp-node';
import { MockApiPixPsp } from '../src/mock-psp.js';
import { MockOpenFinanceTransmitter, openFinancePixCredit } from '../src/mock-transmitter.js';
import { MemoryBoletoLedger, SourceError, type PaymentSource } from '../src/source.js';
import { ApiPixSource } from '../src/sources/api-pix.js';
import { OpenFinanceSource, PrivateKeyJwtSession } from '../src/sources/open-finance.js';
import { E2E, LP, PIX_KEY, World, post, startService } from './harness.js';

/**
 * The bank-fact readers kept beside the attestor, which no longer signs from them: a transmitter speaking the
 * published Open Finance Brasil APIs as this package reads them - Consents 3.3.1, Accounts 2.4.2, a token
 * endpoint taking PS256 `private_key_jwt` - and API Pix at a PSP, each with its source against it. PIX and
 * boleto settle only on zkTLS proofs of the bank session; the last group shows the attestor refusing both the
 * sources and the requests they used to answer.
 */

const CONSENT = 'urn:bancoex:C1DD33123';
const ACCOUNT_ID = '92792126019929279212650822221989319252576';
const NOW = Date.parse('2026-09-14T12:05:00Z');
const SETTLED = '2026-09-14T12:00:30.000Z';
const LOCKED = BigInt(Date.parse('2026-09-14T12:00:00Z') / 1000);

const REFRESH_TOKEN = 'refresh-token-0123456789';

const tx = (id: string, o: Record<string, unknown> = {}) => openFinancePixCredit({ transactionId: id, amount: '100.00', at: SETTLED }, o);

let keys: { publicKey: KeyObject; privateKey: KeyObject };
beforeAll(() => {
  keys = generateKeyPairSync('rsa', { modulusLength: 2048 });
});

const cleanup: (() => Promise<void>)[] = [];
afterEach(async () => { for (const c of cleanup.splice(0)) await c(); });

async function startTransmitter(): Promise<MockOpenFinanceTransmitter> {
  const t = new MockOpenFinanceTransmitter(CONSENT, ACCOUNT_ID, { now: () => NOW });
  t.register('client-1', keys.publicKey, REFRESH_TOKEN);
  t.pages = [[tx('TX-OTHER')], [tx('TX0001')]];
  await t.listen();
  cleanup.push(() => t.close());
  return t;
}

async function transmitter(o: { clock?: () => number } = {}) {
  const t = await startTransmitter();
  let now = NOW;
  const session = new PrivateKeyJwtSession({ tokenUrl: `${t.origin}/token`, clientId: 'client-1', signingKey: keys.privateKey, kid: 'kid-1', refreshToken: REFRESH_TOKEN, now: () => now });
  const source = new OpenFinanceSource({
    accountsBaseUrl: `${t.origin}/open-banking/accounts/v2`, consentsBaseUrl: `${t.origin}/open-banking/consents/v3`,
    consentId: CONSENT, accountId: ACCOUNT_ID, account: { compeCode: '001', branchCode: '0001', number: '12345678', checkDigit: '9' },
    pixKeys: [PIX_KEY], session, now: o.clock ?? (() => now),
  });
  return { t, source, session, advance: (ms: number) => { now += ms; } };
}

const query = (bankTxId: string) => ({ bankTxId, since: LOCKED, until: BigInt(NOW / 1000) });

describe('Open Finance account data', () => {
  it('reads a settled PIX credit across pages, with FAPI headers and the booking-date window', async () => {
    const { t, source } = await transmitter();
    const credit = await source.pixCredit(query('TX0001'));
    expect(credit).toEqual({
      bankTxId: 'TX0001', amountCents: 10_000n, settledAt: BigInt(Date.parse(SETTLED) / 1000),
      payee: { kind: 'account', account: { compeCode: '001', branchCode: '0001', number: '12345678', checkDigit: '9' }, keys: [PIX_KEY] },
      returnedCents: 0n,
    });
    const txCalls = t.calls.filter((c) => c.path.endsWith('/transactions-current'));
    expect(txCalls).toHaveLength(2);
    expect(txCalls[0].query.get('fromBookingDateMaxLimited')).toBe('2026-09-13');
    expect(txCalls[0].query.get('toBookingDateMaxLimited')).toBe('2026-09-15');
    expect(txCalls[0].query.get('creditDebitIndicator')).toBe('CREDITO');
    for (const c of t.calls.filter((x) => x.path !== '/token')) {
      expect(c.headers['x-fapi-interaction-id']).toMatch(/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/);
    }
  });

  it('authenticates to the token endpoint with a PS256 private_key_jwt the transmitter can verify', async () => {
    const { t, session } = await transmitter();
    expect(await session.accessToken('consents')).toBe('cc-client-1');
    const [h, p] = t.assertions[0].split('.');
    expect(JSON.parse(Buffer.from(h, 'base64url').toString())).toEqual({ alg: 'PS256', kid: 'kid-1', typ: 'JWT' });
    const claims = JSON.parse(Buffer.from(p, 'base64url').toString()) as { exp: number; iat: number; jti: string };
    expect(claims.exp - claims.iat).toBe(60);
    expect(claims.jti).toMatch(/^[0-9a-f-]{36}$/);
  });

  it('refuses a consent that is not AUTHORISED, lacks the transactions permission, or has expired', async () => {
    for (const change of [{ status: 'AWAITING_AUTHORISATION' }, { status: 'REJECTED' }, { permissions: ['ACCOUNTS_READ', 'RESOURCES_READ'] }, { expirationDateTime: '2026-09-14T12:04:59Z' }]) {
      const { t, source } = await transmitter();
      Object.assign(t.consent, change);
      await expect(source.pixCredit(query('TX0001'))).rejects.toMatchObject({ code: 'consent' });
      expect(t.transactionCalls, JSON.stringify(change)).toBe(0);
    }
  });

  it('refuses a consented account that is not the account onboarded', async () => {
    const { t, source } = await transmitter();
    t.identity.number = '87654321';
    await expect(source.pixCredit(query('TX0001'))).rejects.toMatchObject({ code: 'consent' });
  });

  it('does not treat a future entry, a processing one, a TED or a debit as a PIX credit', async () => {
    for (const o of [{ completedAuthorisedPaymentType: 'LANCAMENTO_FUTURO' }, { completedAuthorisedPaymentType: 'TRANSACAO_PROCESSANDO' }, { type: 'TED' }, { creditDebitType: 'DEBITO' }]) {
      const { t, source } = await transmitter();
      t.pages = [[tx('TX0001', o)]];
      expect(await source.pixCredit(query('TX0001')), JSON.stringify(o)).toBeUndefined();
    }
  });

  it('refuses a fraction of a centavo rather than rounding, and accepts four zero decimals', async () => {
    const { t, source } = await transmitter();
    t.pages = [[tx('TX0001', { transactionAmount: { amount: '100.0050', currency: 'BRL' } }), tx('TX0002', { transactionAmount: { amount: '100.0000', currency: 'BRL' } })]];
    await expect(source.pixCredit(query('TX0001'))).rejects.toMatchObject({ code: 'malformed' });
    expect((await source.pixCredit(query('TX0002')))?.amountCents).toBe(10_000n);
  });

  it('spends the monthly call budget sparingly: a cache, a refresh interval, and 423 reported as a rate limit', async () => {
    const { t, source, advance } = await transmitter();
    t.pages = [[tx('TX0001'), tx('TX0002')]];
    await source.pixCredit(query('TX0001'));
    await source.pixCredit(query('TX0002'));
    expect(t.transactionCalls).toBe(1);
    await expect(source.pixCredit(query('TX0404'))).rejects.toMatchObject({ code: 'rate_limited' });
    expect(t.transactionCalls).toBe(1);
    advance(61_000);
    t.transactionsStatus = 423;
    await expect(source.pixCredit(query('TX0404'))).rejects.toBeInstanceOf(SourceError);
    await expect(source.pixCredit(query('TX0404'))).rejects.toMatchObject({ code: 'rate_limited' });
  });

  it('refuses a next link to another origin, which would carry the token elsewhere', async () => {
    const { t, source } = await transmitter();
    t.nextOrigin = 'http://127.0.0.2:1';
    await expect(source.pixCredit(query('TX0001'))).rejects.toMatchObject({ code: 'malformed' });
  });

  it('a refresh token the transmitter no longer honours is a consent problem', async () => {
    const t = await startTransmitter();
    const session = new PrivateKeyJwtSession({ tokenUrl: `${t.origin}/token`, clientId: 'client-1', signingKey: keys.privateKey, kid: 'k', refreshToken: 'revoked' });
    await expect(session.accessToken('accounts')).rejects.toMatchObject({ code: 'consent' });
  });
});

describe('API Pix, as a bank-fact reader', () => {
  async function apiPix(o: { boletos?: MemoryBoletoLedger } = {}) {
    const psp = new MockApiPixPsp('client-id', 'client-secret-0123456789');
    await psp.listen();
    cleanup.push(() => psp.close());
    const client = new ApiPixClient({ baseUrl: psp.baseUrl, tokenUrl: psp.tokenUrl, clientId: psp.clientId, clientSecret: psp.clientSecret, scopes: ['pix.read'] });
    return { psp, client, source: new ApiPixSource(client, { boletos: o.boletos }) };
  }

  it('reads the credited key, the amount, the settlement time and what was returned, by end-to-end id', async () => {
    const { psp, source } = await apiPix();
    psp.record({
      endToEndId: E2E(1), txid: 'order1', valor: '100.00', chave: PIX_KEY, horario: SETTLED,
      devolucoes: [{ id: 'd1', valor: '30.00', status: 'EM_PROCESSAMENTO' }, { id: 'd2', valor: '5.00', status: 'NAO_REALIZADO' }],
    });
    expect(await source.pixCredit(query(E2E(1)))).toEqual({
      bankTxId: E2E(1), amountCents: 10_000n, settledAt: BigInt(Date.parse(SETTLED) / 1000), payee: { kind: 'key', key: PIX_KEY }, returnedCents: 3_000n,
    });
  });

  it('finds nothing the PSP does not have, and does not ask about an id that is not an end-to-end id', async () => {
    const { psp, source } = await apiPix();
    expect(await source.pixCredit(query(E2E(2)))).toBeUndefined();
    const reads = psp.reads;
    expect(await source.pixCredit(query('TX0001'))).toBeUndefined();
    expect(psp.reads).toBe(reads);
  });

  it('reports a Pix paid to account details as an unknown payee, and a boleto only through a collection ledger', async () => {
    const ledger = new MemoryBoletoLedger();
    const paid = { authenticationCode: 'AUTH000000000001', line: '34191090000123452345678901230000000000000000', amountCents: 25_000n, paidAt: 1_800_000_000n };
    ledger.record(paid);
    const { psp, client, source } = await apiPix({ boletos: ledger });
    psp.record({ endToEndId: E2E(3), valor: '10.00', chave: '', horario: SETTLED });
    expect((await source.pixCredit(query(E2E(3))))?.payee).toEqual({ kind: 'unknown' });
    expect(await source.boletoPayment!(query(paid.authenticationCode))).toEqual(paid);
    expect(new ApiPixSource(client).boletoPayment).toBeUndefined();
  });
});

describe('the attestor no longer signs from a bank source', () => {
  it('refuses an Open Finance or API Pix source at construction: neither reads card captures', async () => {
    const { source } = await transmitter();
    await expect(startService(new World(LOCKED + 300n), { sources: { [LP]: source as unknown as PaymentSource } }))
      .rejects.toThrow(/the open-finance source for .* cannot read card captures/);
    const psp = new MockApiPixPsp('client-id', 'client-secret-0123456789');
    const apiPixSource = new ApiPixSource(new ApiPixClient({ baseUrl: 'http://127.0.0.1:1/api/v2', tokenUrl: 'http://127.0.0.1:1/oauth/token', clientId: psp.clientId, clientSecret: psp.clientSecret }));
    await expect(startService(new World(LOCKED + 300n), { sources: { [LP]: apiPixSource as unknown as PaymentSource } }))
      .rejects.toThrow(/the api-pix source for .* cannot read card captures/);
  });

  it('refuses a PIX request for a credit the transmitter shows as bank_rail_needs_zktls, without calling the transmitter', async () => {
    const world = new World(LOCKED + 300n);
    const { t } = await transmitter();
    const svc = await startService(world);
    cleanup.push(() => svc.close());
    const orderId = world.lock(1, { lockedAt: LOCKED, offerId: world.pixOfferId });
    const r = await post(svc.url, await world.pixRequest(orderId, { bankTxId: 'TX0001', lockedAt: LOCKED, paidAt: BigInt(Date.parse(SETTLED) / 1000) }));
    expect(r).toMatchObject({ status: 422, body: { error: 'bank_rail_needs_zktls' } });
    expect(t.calls).toHaveLength(0);
  });
});
