import { afterEach, describe, expect, it } from 'vitest';
import type { Hex } from 'viem';
import type { MockAcquirer } from '@mova/lp-node';
import { Rail, cardCheckoutTotal, cardMerchantCommitment, cardTransactionId } from '@mova/ramp';
import { cardPayee, type AttestationRequest } from '../src/request.js';
import type { CardQuery, PaymentSource } from '../src/source.js';
import { AcquirerCardSource } from '../src/sources/card-acquirer.js';
import { ACQUIRER_ID, LP, MERCHANT, OTHER_LP, SALT, World, lyingSource, post, startService } from './harness.js';

/**
 * Card captures, observed at the acquirer through lp-node's `CardAcquirer` read methods, attested with
 * `attestCard` - the one rail the attestor still signs: each test attempts to have a charge that is not this
 * order's payment signed as one.
 */

const cleanup: (() => Promise<void>)[] = [];
afterEach(async () => { for (const c of cleanup.splice(0)) await c(); });

async function setup(o: { source?: (acquirer: MockAcquirer) => PaymentSource; captureAt?: bigint } = {}) {
  const world = new World(undefined, { captureAt: o.captureAt });
  const svc = await startService(world, o.source ? { sources: { [LP]: o.source(world.acquirer) } } : {});
  cleanup.push(() => svc.close());
  const ask = async (orderId: Hex, overrides: Partial<AttestationRequest> = {}) => post(svc.url, await world.request(orderId, overrides));
  return { world, acquirer: world.acquirer, svc, ask };
}

describe('a card capture', () => {
  it('is attested from the acquirer\'s record, at the order\'s amount, under the acquirer-scoped transaction id', async () => {
    const { world, ask } = await setup();
    const orderId = world.lock(1);
    const paid = await world.pay(orderId);
    expect(paid.amountCents).toBe(10_350n);
    const r = await ask(orderId);
    expect(r.status).toBe(200);
    expect(r.body.payment).toMatchObject({
      bankTxId: cardTransactionId(ACQUIRER_ID, paid.transactionId), payeeKeyHash: cardMerchantCommitment(MERCHANT, SALT),
      amountBrlCents: '10000', paidAt: paid.capturedAt!.toString(), rail: Rail.CARD,
    });
    expect(world.reader.reads).toBe(1);
  });

  it('refuses an authorisation never captured, and a charge charged back', async () => {
    const { world, acquirer, ask } = await setup();
    const a = world.lock(1);
    await world.pay(a, { capture: false });
    const r = await ask(a);
    expect(r).toMatchObject({ status: 422, body: { error: 'refused' } });
    expect(r.body.message).toMatch(/AUTHORIZED, not CAPTURED/);

    const b = world.lock(2);
    const paid = await world.pay(b);
    acquirer.chargeback(paid.transactionId);
    expect((await ask(b)).body.message).toMatch(/CHARGED_BACK, not CAPTURED/);
  });

  it('refuses a total other than the order plus its committed fee: the order alone, and a partial capture', async () => {
    const { world, acquirer, ask } = await setup();
    const a = world.lock(1);
    await world.pay(a, { amountCents: 10_000n });
    const r = await ask(a);
    expect(r).toMatchObject({ status: 422, body: { error: 'refused' } });
    expect(r.body.message).toMatch(/exactly 10350/);

    const b = world.lock(2);
    const auth = await world.pay(b, { capture: false });
    acquirer.capture(auth.transactionId, 10_300n);
    expect((await ask(b)).body.message).toMatch(/exactly 10350/);
  });

  it('refuses a fee other than the one the offer committed to, even with a total that matches it', async () => {
    const { world, ask } = await setup();
    const orderId = world.lock(1);
    await world.pay(orderId, { amountCents: cardCheckoutTotal(10_000n, 500) });
    const r = await ask(orderId, { payee: cardPayee({ ...MERCHANT, feeBps: 500 }) });
    expect(r).toMatchObject({ status: 422, body: { error: 'refused' } });
    expect(r.body.message).toMatch(/different card fee/);
  });

  it('refuses a capture from before the lock', async () => {
    const { world, ask } = await setup({ captureAt: 1_800_000_000n - 121n });
    const orderId = world.lock(1);
    await world.pay(orderId);
    const r = await ask(orderId);
    expect(r).toMatchObject({ status: 422, body: { error: 'refused' } });
    expect(r.body.message).toMatch(/predates the order/);
  });

  it('refuses a charge for another merchant account, whichever merchant is disclosed', async () => {
    const { world, acquirer, ask } = await setup();
    const orderId = world.lock(1);
    acquirer.charge({ reference: orderId, amountCents: 10_350n, merchantId: 'SOMEONE-ELSE-01' });
    expect((await ask(orderId)).body.error).toBe('source_disagrees');
    const r = await ask(orderId, { payee: cardPayee({ ...MERCHANT, merchantId: 'SOMEONE-ELSE-01' }) });
    expect(r).toMatchObject({ status: 422, body: { error: 'refused' } });
  });

  it('refuses a claim that disagrees with the acquirer\'s total or capture time', async () => {
    const { world, ask } = await setup();
    const orderId = world.lock(1);
    const paid = await world.pay(orderId);
    expect((await ask(orderId, { amountBrlCents: 10_000n })).body.error).toBe('source_disagrees');
    expect((await ask(orderId, { paidAt: paid.capturedAt! + 1n })).body.error).toBe('source_disagrees');
  });
});

describe('one transaction id for two orders', () => {
  it('is not found under another order: an acquirer lists charges by the checkout\'s reference', async () => {
    const { world, ask } = await setup();
    const first = world.lock(1);
    const second = world.lock(2);
    const paid = await world.pay(first);
    expect((await ask(first)).status).toBe(200);
    const r = await ask(second, { bankTxId: paid.transactionId, amountBrlCents: paid.amountCents, paidAt: paid.capturedAt! });
    expect(r).toMatchObject({ status: 422, body: { error: 'not_observed' } });
  });

  it('is caught by the reference when a source ignores it, and by the journal when a source lies about it', async () => {
    const ignoring = (acq: MockAcquirer): PaymentSource => ({
      kind: 'card-acquirer',
      cardCapture: async (q: CardQuery) => {
        const c = acq.charges.find((x) => x.transactionId === q.transactionId);
        return c && { ...c };
      },
    });
    const a = await setup({ source: ignoring });
    const first = a.world.lock(1);
    const paid = await a.world.pay(first);
    const reuse = { bankTxId: paid.transactionId, amountBrlCents: paid.amountCents, paidAt: paid.capturedAt! };
    expect((await a.ask(first)).status).toBe(200);
    const r = await a.ask(a.world.lock(2), reuse);
    expect(r).toMatchObject({ status: 422, body: { error: 'source_disagrees' } });
    expect(r.body.message).toMatch(/another order's checkout/);

    const b = await setup({ source: lyingSource });
    const one = b.world.lock(1);
    const charge = await b.world.pay(one);
    expect((await b.ask(one)).status).toBe(200);
    expect(await b.ask(b.world.lock(2), { bankTxId: charge.transactionId, amountBrlCents: charge.amountCents, paidAt: charge.capturedAt! }))
      .toMatchObject({ status: 409, body: { error: 'bank_tx_reused' } });
  });
});

describe('card sources', () => {
  it('a bank-fact reader is refused at construction: it reads no card captures, the only payments the attestor signs', async () => {
    const world = new World();
    const bank = { kind: 'api-pix', pixCredit: async () => undefined };
    await expect(startService(world, { sources: { [LP]: bank as unknown as PaymentSource } }))
      .rejects.toThrow(/the api-pix source for .* cannot read card captures/);
  });

  it('an acquirer source speaks only for its own acquirer, and an LP without one gets no_source', async () => {
    const world = new World();
    const card = new AcquirerCardSource(world.reader);
    expect(await card.cardCapture({ acquirerId: 'ANOTHER-ACQUIRER', transactionId: 'TID-1', reference: '0x', since: 0n, until: 0n })).toBeUndefined();
    expect(world.reader.reads).toBe(0);

    const svc = await startService(world, { sources: { [OTHER_LP]: card } });
    cleanup.push(() => svc.close());
    const orderId = world.lock(1);
    await world.pay(orderId);
    expect(await post(svc.url, await world.request(orderId))).toMatchObject({ status: 422, body: { error: 'no_source' } });
  });
});
