/**
 * A world to attack the attestor in: an in-memory chain (orders, offers, boletos, sales, registry tiers), the
 * card partner's acquirer (lp-node's MockAcquirer) behind a reader that counts every read, and the real service
 * over HTTP in front of them.
 *
 * The attestor signs card captures only - PIX, boleto and TED settle only on zkTLS proofs of the bank session -
 * so the world's honest orders are card orders. It still holds a PIX offer and can lock a boleto order on one,
 * as an escrow written before that rule could have: that is how the tests show a bank-rail request refused
 * however real the order behind it.
 */
import { getAddress, keccak256, toBytes, type Address, type Hex } from 'viem';
import { privateKeyToAccount } from 'viem/accounts';
import {
  JsonlJournal, MemoryJournal, MockAcquirer, OrderState, SaleState,
  type CardCharge, type OnChainBoleto, type OnChainOffer, type OnChainOrder, type OnChainSale,
} from '@mova/lp-node';
import { Attestor, Rail, boletoCommitment, cardCheckoutTotal, cardMerchantCommitment, pixKeyCommitment, railMask } from '@mova/ramp';
import { readTerms, Tier, type ChainReader } from '../src/chain.js';
import { AttestationJournal, type AttestorRecord } from '../src/journal.js';
import type { RateLimiter } from '../src/rate-limit.js';
import {
  cardPayee, newRequestNonce, requestToJson, signAttestationRequest, type AttestationRequest, type SignedAttestationRequest,
} from '../src/request.js';
import { serveAttestor } from '../src/server.js';
import { PaymentAttestor } from '../src/service.js';
import type { CardQuery, PaymentSource } from '../src/source.js';
import { AcquirerCardSource, type CardReader } from '../src/sources/card-acquirer.js';

// anvil's well-known development keys: test keys, never funded anywhere that matters.
export const LP_KEY: Hex = '0x59c6995e998f97a5a0044966f0945389dc9e86dae88c7a8412f4603b6b78690d';
export const STRANGER_KEY: Hex = '0x5de4111afa1a4b94908f83103eb1f1706367c2e68ca870fc3fb9a804cdab365a';
export const OTHER_LP_KEY: Hex = '0x7c852118294e51e653712a81e05800f419141751be58f605c371e15141b007a6';
export const ATTESTOR_KEYS: [Hex, Hex] = [
  '0x47e179ec197488593b187f80a00eb0da91f1b9d0b13f8733639f19c30a34926a',
  '0x8b3a350cf5c34c9194ca85829a2df0ec3153be0318b5e2d3348e872092edffba',
];
export const LP = privateKeyToAccount(LP_KEY).address;
export const OTHER_LP = privateKeyToAccount(OTHER_LP_KEY).address;
export const CHAIN_ID = 31337;
export const VERIFIER: Address = getAddress(`0x${'5e'.repeat(20)}`);
export const ONRAMP: Address = getAddress(`0x${'e1'.repeat(20)}`);
export const OFFRAMP: Address = getAddress(`0x${'e2'.repeat(20)}`);
export const ESCROWS = { onramp: ONRAMP, offramp: OFFRAMP };
export const PIX_KEY = 'liquidez@lp.example';
export const SALT: Hex = `0x${'ab'.repeat(32)}`;
export const PAYER_REF: Hex = `0x${'77'.repeat(32)}`;
export const E2E = (n: number) => `E99999999202609141200${String(n).padStart(11, '0')}`;
export const ACQUIRER_ID = '01027058000191';
export const MERCHANT_ID = 'MOVA-PARTNER-0001';
export const CARD_FEE_BPS = 350;
export const MERCHANT = { acquirerId: ACQUIRER_ID, merchantId: MERCHANT_ID, feeBps: CARD_FEE_BPS };
export const iso = (sec: bigint) => new Date(Number(sec) * 1000).toISOString();

const ZERO: Address = '0x0000000000000000000000000000000000000000';
const ZERO32: Hex = `0x${'00'.repeat(32)}`;

export class FakeChain implements ChainReader {
  readonly chainId = CHAIN_ID;
  time: bigint;
  readonly tiers = new Map<string, Tier>();
  readonly orders = new Map<string, OnChainOrder>();
  readonly offers = new Map<string, OnChainOffer>();
  readonly boletos = new Map<string, OnChainBoleto>();
  readonly sales = new Map<string, OnChainSale>();
  allowed = true;
  failWith?: Error;
  /** Every read made, of any kind. */
  reads = 0;

  constructor(t0: bigint) {
    this.time = t0;
  }

  private read(): void {
    this.reads++;
    if (this.failWith) throw this.failWith;
  }

  async now() { this.read(); return this.time; }
  async tier(lp: Address) { this.read(); return this.tiers.get(lp.toLowerCase()) ?? Tier.NONE; }
  async verifierAllowed() { this.read(); return this.allowed; }

  async order(_e: Address, id: Hex): Promise<OnChainOrder> {
    this.read();
    return this.orders.get(id.toLowerCase()) ?? {
      offerId: ZERO32, taker: ZERO, weiAmount: 0n, brlCents: 0n, lockedAt: 0n, payBy: 0n, state: OrderState.NONE, delivery: 0, recipient: ZERO,
    };
  }

  async offer(_e: Address, id: Hex): Promise<OnChainOffer> {
    this.read();
    const o = this.offers.get(id.toLowerCase());
    if (!o) throw new Error('no such offer in the fake chain');
    return o;
  }

  async boleto(_e: Address, id: Hex): Promise<OnChainBoleto> {
    this.read();
    return this.boletos.get(id.toLowerCase()) ?? { issueBy: 0n, issuedAt: 0n, commitment: ZERO32 };
  }

  async sale(_e: Address, id: Hex): Promise<OnChainSale> {
    this.read();
    return this.sales.get(id.toLowerCase()) ?? {
      seller: ZERO, asset: ZERO, weiAmount: 0n, brlCents: 0n, payeeKeyHash: ZERO32, verifier: ZERO, railMask: 0, lp: ZERO,
      claimedAt: 0n, payBy: 0n, refundTo: ZERO, state: SaleState.NONE,
    };
  }
}

/** The acquirer's read methods, counting every call: how a test shows a request refused before it cost a source read. */
export class CountingReader implements CardReader {
  reads = 0;
  readonly acquirerId: string;
  readonly merchantId: string;

  constructor(private readonly acquirer: MockAcquirer, private readonly view: (c: CardCharge) => CardCharge = (c) => c) {
    this.acquirerId = acquirer.acquirerId;
    this.merchantId = acquirer.merchantId;
  }

  async chargesFor(reference: string): Promise<CardCharge[]> {
    this.reads++;
    return (await this.acquirer.chargesFor(reference)).map(this.view);
  }
}

/**
 * A source that finds a charge by its transaction id alone and reports it under whatever order is asked about -
 * as a broken or lying adapter would. The service's reference check catches the first; only the journal catches
 * a source that also rewrites the reference.
 */
export const lyingSource = (acquirer: MockAcquirer): PaymentSource => ({
  kind: 'card-acquirer',
  cardCapture: async (q: CardQuery) => {
    const c = acquirer.charges.find((x) => x.transactionId === q.transactionId);
    return c && { ...c, reference: q.reference };
  },
});

export class World {
  readonly chain: FakeChain;
  readonly acquirer: MockAcquirer;
  readonly reader: CountingReader;
  /** A card-only offer, committed to the partner's merchant account at a 3,5% card fee: the only kind this attestor serves. */
  readonly cardOfferId = keccak256(toBytes('offer-card'));
  /** A PIX offer naming this verifier - which `postOffer` now refuses (BankRailNeedsZkTls) - as an older escrow could hold one. */
  readonly pixOfferId = keccak256(toBytes('offer-pix'));
  /** The same, accepting boletos too. */
  readonly boletoOfferId = keccak256(toBytes('offer-boleto'));

  constructor(readonly t0 = 1_800_000_000n, o: { captureAt?: bigint } = {}) {
    this.chain = new FakeChain(t0);
    this.chain.tiers.set(LP.toLowerCase(), Tier.INSTITUTIONAL);
    this.chain.tiers.set(OTHER_LP.toLowerCase(), Tier.INSTITUTIONAL);
    this.acquirer = new MockAcquirer(ACQUIRER_ID, MERCHANT_ID, { now: () => o.captureAt ?? t0 - 30n });
    this.reader = new CountingReader(this.acquirer);
    const offer = (railMaskValue: number, pixKeyHash: Hex): OnChainOffer => ({
      lp: LP, asset: ZERO, availableWei: 10n ** 18n, lockedWei: 0n, priceBrlCentsPerEth: 2_000_000n,
      pixKeyHash, minOrderWei: 1n, maxOrderWei: 10n ** 18n, verifier: VERIFIER,
      railMask: railMaskValue, active: true, decimals: 18,
    });
    this.chain.offers.set(this.cardOfferId.toLowerCase(), offer(railMask(Rail.CARD), cardMerchantCommitment(MERCHANT, SALT)));
    this.chain.offers.set(this.pixOfferId.toLowerCase(), offer(railMask(Rail.PIX), pixKeyCommitment(PIX_KEY, SALT)));
    this.chain.offers.set(this.boletoOfferId.toLowerCase(), offer(railMask(Rail.PIX, Rail.BOLETO), pixKeyCommitment(PIX_KEY, SALT)));
  }

  wall = (): bigint => this.t0;

  /** An order on the card offer (or `offerId`), locked two minutes ago. */
  lock(n: number, o: { brlCents?: bigint; lockedAt?: bigint; offerId?: Hex } = {}): Hex {
    const id = keccak256(toBytes(`order-${n}`));
    this.chain.orders.set(id, {
      offerId: o.offerId ?? this.cardOfferId, taker: LP, weiAmount: 5n * 10n ** 15n, brlCents: o.brlCents ?? 10_000n,
      lockedAt: o.lockedAt ?? this.t0 - 120n, payBy: this.t0 + 1_800n, state: OrderState.LOCKED, delivery: 0, recipient: LP,
    });
    return id;
  }

  /** A boleto order on the legacy PIX+boleto offer, whose boleto `line` was issued a minute ago. */
  lockBoleto(n: number, line: string, brlCents: bigint): Hex {
    const id = this.lock(n, { brlCents, offerId: this.boletoOfferId });
    this.chain.boletos.set(id, { issueBy: this.t0 + 3_600n, issuedAt: this.t0 - 60n, commitment: boletoCommitment(line, SALT) });
    return id;
  }

  /** The node's checkout for an order: the order plus the committed fee, under the order's reference. */
  async checkout(orderId: Hex, amountCents?: bigint) {
    const brl = this.chain.orders.get(orderId.toLowerCase())?.brlCents ?? 10_000n;
    return this.acquirer.createCheckout({
      idempotencyKey: `checkout:${orderId}:${amountCents ?? ''}`, amountCents: amountCents ?? cardCheckoutTotal(brl, CARD_FEE_BPS),
      expiresAt: this.t0 + 3_600n, reference: orderId,
    });
  }

  /** The cardholder pays the order's checkout, captured. */
  async pay(orderId: Hex, o: { capture?: boolean; amountCents?: bigint } = {}): Promise<CardCharge> {
    return this.acquirer.pay((await this.checkout(orderId, o.amountCents)).checkoutId, { capture: o.capture });
  }

  /**
   * A request exactly as an honest LP node would make it for this order: terms from the chain, and the order's
   * latest charge as the acquirer recorded it (or a charge that does not exist yet, when none was made).
   */
  async request(orderId: Hex, overrides: Partial<AttestationRequest> = {}, key: Hex = LP_KEY): Promise<SignedAttestationRequest> {
    const { terms } = await readTerms(this.chain, ESCROWS, orderId);
    const charge = this.acquirer.charges.filter((c) => c.reference.toLowerCase() === orderId.toLowerCase()).at(-1);
    const base: AttestationRequest = {
      lp: LP, orderId, payeeKeyHash: terms.payeeKeyHash, orderBrlCents: terms.brlCents, lockedAt: terms.lockedAt,
      rail: Rail.CARD, bankTxId: charge?.transactionId ?? 'TID-000000001',
      amountBrlCents: charge?.amountCents ?? cardCheckoutTotal(terms.brlCents, CARD_FEE_BPS),
      paidAt: charge?.capturedAt ?? this.t0 - 30n, payerRef: PAYER_REF, payee: cardPayee(MERCHANT), salt: SALT,
      issuedAt: this.wall(), nonce: newRequestNonce(),
    };
    return signAttestationRequest(privateKeyToAccount(key), { chainId: CHAIN_ID, verifier: VERIFIER }, { ...base, ...overrides });
  }

  /** A PIX request as a node would have made it for a Pix credited to its key: the kind the service now refuses. */
  pixRequest(orderId: Hex, overrides: Partial<AttestationRequest> = {}, key: Hex = LP_KEY): Promise<SignedAttestationRequest> {
    return signAttestationRequest(privateKeyToAccount(key), { chainId: CHAIN_ID, verifier: VERIFIER }, {
      lp: LP, orderId, payeeKeyHash: pixKeyCommitment(PIX_KEY, SALT), orderBrlCents: 10_000n, lockedAt: this.t0 - 120n,
      rail: Rail.PIX, bankTxId: E2E(1), amountBrlCents: 10_000n, paidAt: this.t0 - 90n, payerRef: PAYER_REF,
      payee: PIX_KEY, salt: SALT, issuedAt: this.wall(), nonce: newRequestNonce(), ...overrides,
    });
  }
}

export interface Running {
  service: PaymentAttestor;
  journal: AttestationJournal;
  url: string;
  logs: string[];
  /** Closes the listener only: the journal is left open, as a crash leaves it. */
  crash: () => Promise<void>;
  close: () => Promise<void>;
}

export async function startService(world: World, o: {
  journalPath?: string;
  attestorKey?: Hex;
  limiter?: RateLimiter;
  sources?: Record<string, PaymentSource>;
  redactValues?: string[];
} = {}): Promise<Running> {
  const attestor = new Attestor(o.attestorKey ?? ATTESTOR_KEYS[0], CHAIN_ID, VERIFIER);
  const journal = new AttestationJournal(
    o.journalPath ? new JsonlJournal<AttestorRecord>(o.journalPath) : new MemoryJournal<AttestorRecord>(),
    { maxSkewSeconds: 300, now: world.wall },
  );
  journal.load();
  const logs: string[] = [];
  const service = new PaymentAttestor({
    attestor, chain: world.chain, escrows: ESCROWS, journal, limiter: o.limiter, now: world.wall, redactValues: o.redactValues,
    sources: o.sources ?? { [LP]: new AcquirerCardSource(world.reader) },
    log: { info: (m) => logs.push(m), warn: (m) => logs.push(m), error: (m) => logs.push(m) },
  });
  service.ready = true;
  const http = serveAttestor(service, { mode: 'both', redactValues: o.redactValues });
  const port = await http.listen(0);
  return {
    service, journal, logs, url: `http://127.0.0.1:${port}`,
    crash: () => http.close(),
    close: async () => { await http.close(); journal.close(); },
  };
}

export async function post(url: string, req: SignedAttestationRequest | Record<string, unknown>): Promise<{ status: number; body: Record<string, any> }> {
  const body = 'signature' in req && typeof req.signature === 'string' && typeof (req as SignedAttestationRequest).orderBrlCents === 'bigint'
    ? requestToJson(req as SignedAttestationRequest) : req;
  const r = await fetch(`${url}/v1/attest`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
  return { status: r.status, body: await r.json() as Record<string, any> };
}
