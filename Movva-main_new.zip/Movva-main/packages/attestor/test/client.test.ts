import { afterEach, describe, expect, it } from 'vitest';
import { decodeAbiParameters, recoverTypedDataAddress, type Hex } from 'viem';
import { privateKeyToAccount } from 'viem/accounts';
import { ProofUnavailable, QuorumProver, type BoletoClaim, type CardCharge, type PixClaim } from '@mova/lp-node';
import { EIP712_DOMAIN, PAYMENT_TYPES, Rail, buildBankBoleto, cardTransactionId, type ObservedCardCapture } from '@mova/ramp';
import { readTerms } from '../src/chain.js';
import { AttestorRefused, RemoteAttestor } from '../src/client.js';
import { AcquirerCardSource } from '../src/sources/card-acquirer.js';
import {
  ACQUIRER_ID, ATTESTOR_KEYS, CARD_FEE_BPS, CHAIN_ID, CountingReader, E2E, ESCROWS, LP, LP_KEY, PAYER_REF, PIX_KEY, SALT, VERIFIER,
  World, startService,
} from './harness.js';

/** An LP node's QuorumProver, pointed at two PSPs' attestor services through `RemoteAttestor`. */

const cleanup: (() => Promise<void>)[] = [];
afterEach(async () => { for (const c of cleanup.splice(0)) await c(); });

const PROOF = [{ type: 'bytes32' }, { type: 'bytes32' }, { type: 'bytes32' }, { type: 'uint256' }, { type: 'uint64' }, { type: 'uint8' }, { type: 'bytes[]' }] as const;
const BOTH = ATTESTOR_KEYS.map((k) => privateKeyToAccount(k).address).sort((x, y) => (BigInt(x) < BigInt(y) ? -1 : 1));

/** The payment a proof carries, and who signed it, as AttestorQuorumVerifier recovers them. */
async function opened(orderId: Hex, proof: Hex) {
  const [bankTxId, payeeKeyHash, payerRef, amountBrlCents, paidAt, rail, sigs] = decodeAbiParameters(PROOF, proof);
  const payment = { bankTxId, payeeKeyHash, payerRef, amountBrlCents, paidAt, rail };
  const signers = await Promise.all(sigs.map((signature) => recoverTypedDataAddress({
    domain: EIP712_DOMAIN(CHAIN_ID, VERIFIER), types: PAYMENT_TYPES, primaryType: 'Payment', message: { orderId, ...payment }, signature,
  })));
  return { payment, signers };
}

const remote = (world: World, url: string, key: Hex) => new RemoteAttestor({
  url, address: privateKeyToAccount(key).address, chainId: CHAIN_ID, verifier: VERIFIER, signer: privateKeyToAccount(LP_KEY),
  now: () => Number(world.t0),
});

/**
 * Two PSPs' services reading the same acquirer, each with its own credential. `viewB` changes what PSP B's read
 * shows - how an acquirer answering one PSP differently is staged.
 */
async function twoPsps(o: { viewB?: (c: CardCharge) => CardCharge } = {}) {
  const world = new World();
  const a = await startService(world, { attestorKey: ATTESTOR_KEYS[0] });
  const readerB = new CountingReader(world.acquirer, o.viewB);
  const b = await startService(world, { attestorKey: ATTESTOR_KEYS[1], sources: { [LP]: new AcquirerCardSource(readerB) } });
  cleanup.push(() => a.close(), () => b.close());
  const prover = new QuorumProver(VERIFIER, [remote(world, a.url, ATTESTOR_KEYS[0]), remote(world, b.url, ATTESTOR_KEYS[1])], 2);
  /** A card order paid through its checkout, and the capture exactly as card-onramp.ts builds it. */
  const paidCardOrder = async (n: number) => {
    const orderId = world.lock(n);
    const paid = await world.pay(orderId);
    const { terms } = await readTerms(world.chain, ESCROWS, orderId);
    const seen: ObservedCardCapture = {
      acquirerId: paid.acquirerId, transactionId: paid.transactionId, merchantId: paid.merchantId, salt: SALT, feeBps: CARD_FEE_BPS,
      payerRef: PAYER_REF, status: 'CAPTURED', capturedAmountBrlCents: paid.amountCents, capturedAt: paid.capturedAt!,
    };
    return { orderId, paid, terms, seen };
  };
  return { world, a, b, readerB, prover, paidCardOrder };
}

describe('QuorumProver.proveCard over two attestor services', () => {
  it('collects a 2-of-2 over the order\'s amount, from the capture each PSP read at the acquirer, in ascending signer order', async () => {
    const { world, readerB, prover, paidCardOrder } = await twoPsps();
    const { orderId, paid, terms, seen } = await paidCardOrder(1);
    const { payment, signers } = await opened(orderId, await prover.proveCard(terms, seen));
    expect(payment).toEqual({
      bankTxId: cardTransactionId(ACQUIRER_ID, paid.transactionId), payeeKeyHash: terms.payeeKeyHash, payerRef: PAYER_REF,
      amountBrlCents: 10_000n, paidAt: paid.capturedAt!, rail: Rail.CARD,
    });
    expect(signers).toEqual(BOTH);
    expect([world.reader.reads, readerB.reads]).toEqual([1, 1]);
  });

  it('gets no proof when one PSP\'s read shows a different total: that PSP refuses', async () => {
    const { a, b, prover, paidCardOrder } = await twoPsps({ viewB: (c) => ({ ...c, amountCents: c.amountCents - 100n }) });
    const { terms, seen } = await paidCardOrder(2);
    await expect(prover.proveCard(terms, seen)).rejects.toBeInstanceOf(ProofUnavailable);
    await expect(prover.proveCard(terms, seen)).rejects.toThrow(/source_disagrees/);
    expect(a.service.metrics.get('mova_attestor_requests_total', { result: 'signed' })).toBe(1);
    expect(b.service.metrics.get('mova_attestor_refusals_total', { reason: 'source_disagrees' })).toBe(2);
  });

  it('does not accept a signature from a key other than the attestor\'s registered address', async () => {
    const { world, b, paidCardOrder } = await twoPsps();
    const { terms, seen } = await paidCardOrder(3);
    await expect(remote(world, b.url, ATTESTOR_KEYS[0]).attestCard(terms, seen)).rejects.toThrow(/not from attestor/);
  });

  it('refuses a merchant, fee and salt that do not open the order\'s commitment before sending anything', async () => {
    const { world, a, paidCardOrder } = await twoPsps();
    const { terms, seen } = await paidCardOrder(4);
    const endpoint = remote(world, a.url, ATTESTOR_KEYS[0]);
    for (const wrong of [{ salt: `0x${'01'.repeat(32)}` as Hex }, { feeBps: 500 }, { merchantId: 'SOMEONE-ELSE-01' }, { salt: `0x${'00'.repeat(32)}` as Hex }]) {
      await expect(endpoint.attestCard(terms, { ...seen, ...wrong }), JSON.stringify(wrong)).rejects.toThrow(/do not open/);
    }
    expect(a.service.metrics.get('mova_attestor_requests_total', { result: 'refused' })).toBe(0);
  });
});

/**
 * PIX and boletos settle only on zkTLS proofs of the bank session. lp-node's QuorumProver refuses them itself, and a
 * `RemoteAttestor` asked directly refuses them too, with the service's own code - so no request is ever spent on one.
 */
describe('PIX and boletos', () => {
  it('are refused by RemoteAttestor as bank_rail_needs_zktls, and by the prover, without a request reaching either service', async () => {
    const { world, a, b, readerB, prover } = await twoPsps();
    const pixOrder = world.lock(5, { offerId: world.pixOfferId });
    const pix = await readTerms(world.chain, ESCROWS, pixOrder);
    const pixClaim: PixClaim = {
      bankTxId: E2E(5), pixKey: PIX_KEY, salt: SALT, payerRef: PAYER_REF, amountBrlCents: pix.terms.brlCents, paidAt: pix.terms.lockedAt + 30n,
    };
    const due = new Date(Date.now() + 5 * 86_400_000).toISOString().slice(0, 10);
    const line = buildBankBoleto({ bankCode: '341', amountCents: 25_000n, dueDate: due, freeField: '1234567890123456789012345' }).line;
    const boletoOrder = world.lockBoleto(6, line, 25_000n);
    const boleto = await readTerms(world.chain, ESCROWS, boletoOrder);
    const boletoClaim: BoletoClaim = {
      bankTxId: 'AUTH000000000006', line, salt: SALT, payerRef: PAYER_REF, amountBrlCents: 25_000n, paidAt: boleto.terms.lockedAt + 10n,
    };

    const endpoint = remote(world, a.url, ATTESTOR_KEYS[0]);
    for (const attempt of [() => endpoint.attest(pix.terms, pixClaim), () => endpoint.attestBoleto(boleto.terms, boletoClaim)]) {
      const e = await attempt().then(() => undefined, (x: unknown) => x);
      expect(e).toBeInstanceOf(AttestorRefused);
      expect(e).toMatchObject({ status: 422, code: 'bank_rail_needs_zktls' });
      expect((e as Error).message).toMatch(/settle only on a zkTLS proof of the bank session/);
    }
    // The prover's own wording is lp-node's; what matters here is that it names the chain's refusal and asks no one.
    for (const attempt of [() => prover.provePix(pix.terms, pixClaim), () => prover.proveBoleto(boleto.terms, boletoClaim)]) {
      const e = await attempt().then(() => undefined, (x: unknown) => x);
      expect(e).toBeInstanceOf(ProofUnavailable);
      expect((e as Error).message).toMatch(/BankRailNeedsZkTls/);
    }
    for (const s of [a, b]) expect(s.service.metrics.get('mova_attestor_requests_total', { result: 'refused' })).toBe(0);
    expect([world.reader.reads, readerB.reads]).toEqual([0, 0]);
  });
});
