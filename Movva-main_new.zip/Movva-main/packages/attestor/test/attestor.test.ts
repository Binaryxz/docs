import { afterEach, describe, expect, it } from 'vitest';
import { appendFileSync, mkdtempSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { keccak256, toBytes } from 'viem';
import { privateKeyToAccount } from 'viem/accounts';
import { OrderState, SaleState } from '@mova/lp-node';
import {
  Rail, boletoCommitment, buildBankBoleto, cardMerchantCommitment, cardTransactionId, pixKeyCommitment, railMask,
} from '@mova/ramp';
import { RateLimiter } from '../src/rate-limit.js';
import { cardPayee, newRequestNonce, requestToJson, signAttestationRequest } from '../src/request.js';
import { SourceError, type PaymentSource } from '../src/source.js';
import {
  ACQUIRER_ID, ATTESTOR_KEYS, CHAIN_ID, LP, LP_KEY, MERCHANT, OTHER_LP_KEY, PAYER_REF, PIX_KEY, SALT, STRANGER_KEY, VERIFIER,
  World, lyingSource, post, startService,
} from './harness.js';

/**
 * Each test attempts an attack on a PSP's attestor, or on what it remembers, and checks that it refuses -
 * with the refusal it should give, before it spends anything it should not spend.
 *
 * The attestor signs card captures only. PIX, boleto and TED settle only on a zkTLS proof of the bank session
 * (the escrows revert BankRailNeedsZkTls for a bank-rail offer or sale through an attestor quorum), so the first
 * group shows those refused by name, before anything is read; the rest attack the card rail it still serves.
 */

const cleanup: (() => Promise<void>)[] = [];
afterEach(async () => {
  for (const c of cleanup.splice(0)) await c();
});

async function setup(o: { journalPath?: string; limiter?: RateLimiter; sources?: Record<string, PaymentSource>; redactValues?: string[] } = {}) {
  const world = new World();
  const svc = await startService(world, o);
  cleanup.push(() => svc.close());
  const orderId = world.lock(1);
  const paid = await world.pay(orderId);
  return { world, svc, orderId, paid };
}

describe('an honest request', () => {
  it('is signed from the acquirer\'s record, and asking again returns the same signature', async () => {
    const { world, svc, orderId, paid } = await setup();
    const r = await post(svc.url, await world.request(orderId));
    expect(r.status).toBe(200);
    expect(r.body.payment).toEqual({
      bankTxId: cardTransactionId(ACQUIRER_ID, paid.transactionId), payeeKeyHash: cardMerchantCommitment(MERCHANT, SALT), payerRef: PAYER_REF,
      amountBrlCents: '10000', paidAt: paid.capturedAt!.toString(), rail: Rail.CARD,
    });
    expect(r.body.reused).toBe(false);
    const again = await post(svc.url, await world.request(orderId));
    expect(again.status).toBe(200);
    expect(again.body).toMatchObject({ reused: true, signature: r.body.signature });
  });
});

describe('bank rails settle only on zkTLS proofs', () => {
  it('refuses a PIX request by name, whoever signed it and for whatever order, before a chain read, a nonce or an acquirer read', async () => {
    const { world, svc } = await setup();
    const chainReads = world.chain.reads;
    // Signed by a stranger, for an id no escrow has: the refusal depends on the rail alone.
    const r = await post(svc.url, await world.pixRequest(keccak256(toBytes('no-such-order')), {}, STRANGER_KEY));
    expect(r).toMatchObject({ status: 422, body: { error: 'bank_rail_needs_zktls' } });
    expect(r.body.message).toMatch(/settle only on a zkTLS proof of the bank session/);
    expect(r.body.message).toMatch(/signs card captures only/);
    expect(world.chain.reads).toBe(chainReads);
    expect(world.reader.reads).toBe(0);
    expect(svc.journal.size).toBe(0);
    expect(svc.service.metrics.get('mova_attestor_refusals_total', { reason: 'bank_rail_needs_zktls' })).toBe(1);
  });

  it('refuses PIX, boleto and TED however real the order: on offers an escrow from before the rule could hold', async () => {
    const { world, svc } = await setup();
    const pixOrder = world.lock(2, { offerId: world.pixOfferId });
    const due = new Date(Date.now() + 5 * 86_400_000).toISOString().slice(0, 10);
    const boleto = buildBankBoleto({ bankCode: '341', amountCents: 25_000n, dueDate: due, freeField: '1234567890123456789012345' });
    const boletoOrder = world.lockBoleto(3, boleto.line, 25_000n);

    expect(await post(svc.url, await world.pixRequest(pixOrder))).toMatchObject({ status: 422, body: { error: 'bank_rail_needs_zktls' } });
    expect(await post(svc.url, await world.pixRequest(boletoOrder, {
      rail: Rail.BOLETO, bankTxId: 'AUTH000000000001', payee: boleto.line, payeeKeyHash: boletoCommitment(boleto.line, SALT),
      orderBrlCents: 25_000n, amountBrlCents: 25_000n, lockedAt: world.t0 - 60n,
    }))).toMatchObject({ status: 422, body: { error: 'bank_rail_needs_zktls' } });
    expect(await post(svc.url, await world.pixRequest(pixOrder, { rail: Rail.TED }))).toMatchObject({ status: 422, body: { error: 'bank_rail_needs_zktls' } });
    // Nor is a card payment accepted for the PIX offer's order: that order was never a card order.
    expect(await post(svc.url, await world.request(pixOrder))).toMatchObject({ status: 422, body: { error: 'rail_not_accepted' } });
    expect(world.reader.reads).toBe(0);
    expect(svc.service.metrics.get('mova_attestor_requests_total', { result: 'signed' })).toBe(0);
  });

  it('refuses a rail it does not know as unsupported', async () => {
    const { world, svc, orderId } = await setup();
    for (const rail of [Rail.UNSPECIFIED, 9 as Rail]) {
      expect(await post(svc.url, await world.request(orderId, { rail }))).toMatchObject({ status: 422, body: { error: 'rail_unsupported' } });
    }
    expect(world.reader.reads).toBe(0);
  });

  it('never attests an off-ramp sale: its payout is a bank payment, and no sale takes a card', async () => {
    const { world, svc } = await setup();
    const saleId = keccak256(toBytes('sale-1'));
    world.chain.sales.set(saleId, {
      seller: LP, asset: '0x0000000000000000000000000000000000000000', weiAmount: 1n, brlCents: 5_000n,
      payeeKeyHash: pixKeyCommitment('+5511987654321', SALT), verifier: VERIFIER, railMask: railMask(Rail.PIX), lp: LP,
      claimedAt: world.t0 - 60n, payBy: world.t0 + 2_000n, refundTo: LP, state: SaleState.CLAIMED,
    });
    expect(await post(svc.url, await world.pixRequest(saleId, { payee: '+5511987654321', orderBrlCents: 5_000n, amountBrlCents: 5_000n })))
      .toMatchObject({ status: 422, body: { error: 'bank_rail_needs_zktls' } });
    expect(await post(svc.url, await world.request(saleId))).toMatchObject({ status: 422, body: { error: 'rail_not_accepted' } });
    expect(world.reader.reads).toBe(0);
  });
});

describe('who is asking', () => {
  it('refuses a request signed by a key other than the LP it names, and one altered after signing', async () => {
    const { world, svc, orderId } = await setup();
    const forged = await post(svc.url, await world.request(orderId, {}, STRANGER_KEY));
    expect(forged).toMatchObject({ status: 401, body: { error: 'bad_signature' } });

    const honest = requestToJson(await world.request(orderId));
    const altered = await post(svc.url, { ...honest, amountBrlCents: '20000' });
    expect(altered).toMatchObject({ status: 401, body: { error: 'bad_signature' } });
    expect(world.reader.reads).toBe(0);
  });

  it('refuses an address LPRegistry never admitted, before it costs a bucket, a nonce or a source call', async () => {
    const { world, svc, orderId } = await setup();
    const stranger = privateKeyToAccount(STRANGER_KEY).address;
    const r = await post(svc.url, await world.request(orderId, { lp: stranger }, STRANGER_KEY));
    expect(r).toMatchObject({ status: 403, body: { error: 'not_admitted' } });
    expect(world.reader.reads).toBe(0);
    expect(svc.journal.size).toBe(0);
  });

  it('refuses an admitted LP asking about another LP\'s order: the merchant account read is not theirs', async () => {
    const { world, svc, orderId } = await setup();
    const r = await post(svc.url, await world.request(orderId, { lp: privateKeyToAccount(OTHER_LP_KEY).address }, OTHER_LP_KEY));
    expect(r).toMatchObject({ status: 403, body: { error: 'not_the_lp' } });
    expect(world.reader.reads).toBe(0);
  });

  it('refuses a replayed request, and a stale one', async () => {
    const { world, svc, orderId } = await setup();
    const req = await world.request(orderId);
    expect((await post(svc.url, req)).status).toBe(200);
    expect(await post(svc.url, req)).toMatchObject({ status: 409, body: { error: 'replayed' } });
    // A refused request is burned too: replaying a refusal must not retry it later.
    const refused = await world.request(orderId, { amountBrlCents: 1n });
    expect((await post(svc.url, refused)).body.error).toBe('source_disagrees');
    expect((await post(svc.url, refused)).body.error).toBe('replayed');

    const stale = await world.request(orderId, { issuedAt: world.t0 - 301n });
    expect(await post(svc.url, stale)).toMatchObject({ status: 401, body: { error: 'expired' } });
  });

  it('rate-limits each LP after authentication', async () => {
    const { world, svc, orderId } = await setup({ limiter: new RateLimiter({ burst: 2, perMinute: 1, now: () => 0 }) });
    expect((await post(svc.url, await world.request(orderId))).status).toBe(200);
    expect((await post(svc.url, await world.request(orderId))).status).toBe(200);
    expect(await post(svc.url, await world.request(orderId))).toMatchObject({ status: 429, body: { error: 'rate_limited' } });
    // A forged request does not spend the LP's bucket: it is refused before the limiter.
    expect((await post(svc.url, await world.request(orderId, {}, STRANGER_KEY))).body.error).toBe('bad_signature');
  });
});

describe('terms come from the chain', () => {
  it('refuses a request whose payee, amount or lock time disagree with the escrow, without asking the acquirer', async () => {
    const { world, svc, orderId } = await setup();
    const lockedAt = world.t0 - 120n;
    const otherSalt = `0x${'cd'.repeat(32)}` as const;
    for (const [overrides, field] of [
      [{ payeeKeyHash: cardMerchantCommitment(MERCHANT, otherSalt) }, 'payeeKeyHash'],
      [{ orderBrlCents: 9_000n, amountBrlCents: 9_000n }, 'orderBrlCents'],
      [{ lockedAt: lockedAt - 3_600n }, 'lockedAt'],
    ] as const) {
      const r = await post(svc.url, await world.request(orderId, overrides));
      expect(r.status, field).toBe(409);
      expect(r.body.error).toBe('terms_disagree');
      expect(r.body.message).toContain(field);
    }
    expect(world.reader.reads).toBe(0);
  });

  it('refuses an order that is not LOCKED, whose window closed, or that names another verifier', async () => {
    const { world, svc, orderId } = await setup();
    const order = world.chain.orders.get(orderId)!;
    // Each request is signed against the order as it stood; the chain then moves on.
    const released = await world.request(orderId);
    world.chain.orders.set(orderId, { ...order, state: OrderState.RELEASED });
    expect(await post(svc.url, released)).toMatchObject({ status: 422, body: { error: 'wrong_state' } });

    world.chain.orders.set(orderId, order);
    const late = await world.request(orderId);
    world.chain.orders.set(orderId, { ...order, payBy: world.t0 - 1n });
    expect((await post(svc.url, late)).body.error).toBe('window_closed');

    world.chain.orders.set(orderId, order);
    world.chain.allowed = false;
    expect((await post(svc.url, await world.request(orderId))).body.error).toBe('verifier_not_allowed');
    world.chain.allowed = true;
    // An id no escrow has: signed properly, and still nothing to attest.
    const honest = await world.request(orderId);
    const ghost = await signAttestationRequest(privateKeyToAccount(LP_KEY), { chainId: CHAIN_ID, verifier: VERIFIER },
      { ...honest, orderId: keccak256(toBytes('no-such-order')), nonce: newRequestNonce() });
    expect(await post(svc.url, ghost)).toMatchObject({ status: 404, body: { error: 'unknown_order' } });
    expect(world.reader.reads).toBe(0);
    const offer = world.chain.offers.get(world.cardOfferId.toLowerCase())!;
    world.chain.offers.set(world.cardOfferId.toLowerCase(), { ...offer, verifier: `0x${'99'.repeat(20)}` });
    expect((await post(svc.url, await world.request(orderId))).body.error).toBe('wrong_verifier');
  });
});

describe('one charge, one order', () => {
  it('refuses one transaction id for two orders even when both requests arrive at once, from a source that reports it under either', async () => {
    const world = new World();
    const svc = await startService(world, { sources: { [LP]: lyingSource(world.acquirer) } });
    cleanup.push(() => svc.close());
    const a = world.lock(3);
    const b = world.lock(4);
    const paid = await world.pay(a);
    const results = await Promise.all([
      post(svc.url, await world.request(a)),
      post(svc.url, await world.request(b, { bankTxId: paid.transactionId, amountBrlCents: paid.amountCents, paidAt: paid.capturedAt! })),
    ]);
    expect(results.map((r) => r.status).sort()).toEqual([200, 409]);
    expect(results.find((r) => r.status === 409)!.body.error).toBe('bank_tx_reused');
  });
});

describe('the journal', () => {
  it('survives a crash: a new process refuses the charge for another order, and the replay, and re-serves the signature', async () => {
    const dir = mkdtempSync(join(tmpdir(), 'attestor-journal-'));
    const path = join(dir, 'attestor.jsonl');
    const world = new World();
    // A source that would report the charge under any order: only the journal stands between it and a second release.
    const sources = { [LP]: lyingSource(world.acquirer) };
    const first = world.lock(1);
    const second = world.lock(2);
    const paid = await world.pay(first);

    const a = await startService(world, { journalPath: path, sources });
    const req = await world.request(first);
    const signed = await post(a.url, req);
    expect(signed.status).toBe(200);
    await a.crash();
    // Power lost mid-append: a torn line that was never acknowledged.
    appendFileSync(path, '{"t":"signed","bankTxId":"0x12');

    const b = await startService(world, { journalPath: path, sources });
    cleanup.push(() => b.close());
    expect(readFileSync(path, 'utf8').endsWith('\n')).toBe(true);
    const reuse = await world.request(second, { bankTxId: paid.transactionId, amountBrlCents: paid.amountCents, paidAt: paid.capturedAt! });
    expect(await post(b.url, reuse)).toMatchObject({ status: 409, body: { error: 'bank_tx_reused' } });
    expect(await post(b.url, req)).toMatchObject({ status: 409, body: { error: 'replayed' } });
    expect(await post(b.url, await world.request(first))).toMatchObject({ status: 200, body: { reused: true, signature: signed.body.signature } });
  });
});

describe('secrets', () => {
  it('never appear in /status, /metrics, logs or responses - nor does a salt, or the PIX key of a refused request', async () => {
    const rpc = 'https://eth-mainnet.g.alchemy.com/v2/SeCrEtRpCkEy0123456789';
    const credential = 'acquirer-token-0123456789';
    const leaky: PaymentSource = {
      kind: 'card-acquirer',
      cardCapture: async () => { throw new SourceError('unavailable', `token refused for ${credential} at ${rpc}`); },
      probe: async () => { throw new Error(`probe failed with ${credential}`); },
    };
    const redactValues = [rpc, credential, ATTESTOR_KEYS[0]];
    const { world, svc, orderId } = await setup({ sources: { [LP]: leaky }, redactValues });
    await svc.service.probeSources();

    const responses: string[] = [];
    const r1 = await post(svc.url, await world.request(orderId));
    expect(r1.body.error).toBe('source_unavailable');
    responses.push(JSON.stringify(r1.body));
    // An RPC failure: viem puts the URL in its message, which reaches the internal-error path.
    const next = await world.request(orderId);
    world.chain.failWith = new Error(`HTTP request failed.\n\nURL: ${rpc}\nRequest body: {"method":"eth_call"}`);
    const r2 = await post(svc.url, next);
    expect(r2.status).toBe(500);
    responses.push(JSON.stringify(r2.body));
    world.chain.failWith = undefined;
    const r3 = await post(svc.url, { garbage: true, payee: cardPayee(MERCHANT), salt: SALT });
    responses.push(JSON.stringify(r3.body));
    const r4 = await post(svc.url, await world.pixRequest(orderId));
    expect(r4.body.error).toBe('bank_rail_needs_zktls');
    responses.push(JSON.stringify(r4.body));

    const status = await (await fetch(`${svc.url}/status`)).text();
    const metrics = await (await fetch(`${svc.url}/metrics`)).text();
    const everything = [status, metrics, ...svc.logs, ...responses].join('\n');
    for (const secret of [rpc, 'SeCrEtRpCkEy0123456789', credential, ATTESTOR_KEYS[0], ATTESTOR_KEYS[0].slice(2), PIX_KEY, SALT, SALT.slice(2)]) {
      expect(everything, secret).not.toContain(secret);
    }
    expect(metrics).toMatch(/mova_attestor_source_errors_total\{code="unavailable",source="card-acquirer"\} 1/);
    expect(JSON.parse(status)).toMatchObject({ rails: ['CARD'], sources: [{ kind: 'card-acquirer', health: { ok: false, detail: 'probe failed' } }] });
  });
});

describe('the wire', () => {
  it('rejects a malformed body naming the field, not its value', async () => {
    const { world, svc, orderId } = await setup();
    const honest = requestToJson(await world.request(orderId));
    const r = await post(svc.url, { ...honest, salt: 'not-a-salt-but-a-secret' });
    expect(r).toMatchObject({ status: 400, body: { error: 'malformed' } });
    expect(r.body.message).toContain('salt');
    expect(r.body.message).not.toContain('not-a-salt-but-a-secret');
  });

  it('answers 503 on /v1/attest until the startup checks are done', async () => {
    const { world, svc, orderId } = await setup();
    svc.service.ready = false;
    expect((await post(svc.url, await world.request(orderId))).status).toBe(503);
    expect((await fetch(`${svc.url}/healthz`)).status).toBe(200);
    expect((await fetch(`${svc.url}/readyz`)).status).toBe(503);
  });
});
