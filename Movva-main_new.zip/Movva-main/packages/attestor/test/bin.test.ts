import { describe, expect, it } from 'vitest';
import { existsSync, mkdtempSync, readFileSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { getAddress, toFunctionSelector, type Abi, type AbiFunction } from 'viem';
import { ConfigError } from '@mova/ramp/src/bin/config.js';
import { EIP712_DOMAIN, PAYMENT_TYPES } from '@mova/ramp';
import { attestorConfigFromEnv, buildSources } from '../src/bin/attestor.js';
import { ATTESTOR_REGISTRY_ABI, ESCROW_REGISTRY_ABI, VERIFIER_ABI } from '../src/chain.js';
import { requestDomain, REQUEST_TYPES } from '../src/request.js';
import { ACQUIRER_ID, ATTESTOR_KEYS, LP, MERCHANT_ID, OTHER_LP, VERIFIER } from './harness.js';

const REGISTRY = '0x00000000000000000000000000000000000000Aa';
const ESCROW = '0x00000000000000000000000000000000000000bB';
const RPC = 'https://eth-mainnet.g.alchemy.com/v2/rpcKey0123456789';

const card = (o: Record<string, unknown> = {}) => ({
  module: '/plugins/acquirer.js', acquirerId: ACQUIRER_ID, merchantId: MERCHANT_ID, credentialsFile: '/secrets/acquirer',
  settings: { baseUrl: 'https://api.acquirer.example' }, ...o,
});
const entry = (o: Record<string, unknown> = {}) => ({ lp: LP, card: card(), ...o });

/** The bank sources this entrypoint used to build, as a sources file written before bank rails left the quorum names them. */
const API_PIX = {
  source: 'api-pix', baseUrl: 'https://pix.psp.example/api/v2', tokenUrl: 'https://pix.psp.example/oauth/token', clientId: 'client',
  clientSecretFile: '/secrets/pix', boletoModule: '/plugins/boletos.js',
};
const OPEN_FINANCE = {
  source: 'open-finance', accountsBaseUrl: 'https://api.bank.example/open-banking/accounts/v2',
  consentsBaseUrl: 'https://api.bank.example/open-banking/consents/v3', consentId: 'urn:bank:C1', accountId: 'A1',
  account: { number: '12345678' }, pixKeys: ['12345678000195'], tokenUrl: 'https://auth.bank.example/token', clientId: 'client', kid: 'kid',
  signingKeyFile: '/secrets/of.pem', refreshTokenFile: '/secrets/of.refresh',
};
const BANK_SECRET_FILES = ['/secrets/pix', '/secrets/of.pem', '/secrets/of.refresh'];

function load(env: Record<string, string | undefined>, files: Record<string, string>, reads: string[] = []) {
  return attestorConfigFromEnv(env, (p) => {
    reads.push(p);
    if (!(p in files)) throw new Error(`ENOENT ${p}`);
    return files[p];
  });
}

const baseEnv = {
  RPC_URL: RPC, VERIFIER, REGISTRY, ESCROW, ATTESTOR_KEY_FILE: '/secrets/key', JOURNAL_FILE: '/data/j.jsonl', SOURCES_FILE: '/config/sources.json',
};
const baseFiles = (lps: unknown[]) => ({
  '/secrets/key': `${ATTESTOR_KEYS[0]}\n`, '/secrets/acquirer': 'acquirer-token-0123456789',
  '/secrets/pix': 'pix-client-secret-0123456789', '/secrets/of.pem': 'not-a-real-pem', '/secrets/of.refresh': 'refresh-token-0123456789',
  '/config/sources.json': JSON.stringify({ lps }),
});

const problems = (f: () => unknown): string => {
  try {
    f();
  } catch (e) {
    expect(e).toBeInstanceOf(ConfigError);
    return (e as Error).message;
  }
  throw new Error('expected a ConfigError');
};

describe('the attestor entrypoint\'s configuration', () => {
  it('reads the key and the acquirer credential from files and remembers every secret for redaction', () => {
    const cfg = load(baseEnv, baseFiles([entry()]));
    expect(cfg.attestorKey).toBe(ATTESTOR_KEYS[0]);
    expect(cfg.sources).toEqual([{
      lp: LP,
      card: { module: '/plugins/acquirer.js', acquirerId: ACQUIRER_ID, merchantId: MERCHANT_ID, credentials: 'acquirer-token-0123456789', settings: { baseUrl: 'https://api.acquirer.example' } },
    }]);
    expect(cfg.secrets).toEqual(expect.arrayContaining([RPC, ATTESTOR_KEYS[0], 'acquirer-token-0123456789']));
    expect(cfg).toMatchObject({ port: 9490, apiPort: 8490, host: '127.0.0.1', escrows: { onramp: getAddress(ESCROW) } });
  });

  it('names everything missing in one error', () => {
    const msg = problems(() => load({}, {}));
    for (const name of ['RPC_URL', 'VERIFIER', 'REGISTRY', 'ESCROW is required', 'ATTESTOR_KEY_FILE', 'JOURNAL_FILE', 'SOURCES_FILE']) {
      expect(msg).toContain(name);
    }
  });

  it('refuses a sources entry written for the bank rails - API Pix, Open Finance, a boleto ledger - saying why, without reading its credentials', () => {
    for (const bank of [API_PIX, OPEN_FINANCE, { boletoModule: '/plugins/boletos.js' }]) {
      const reads: string[] = [];
      const msg = problems(() => load(baseEnv, baseFiles([{ ...entry(), ...bank }]), reads));
      expect(msg).toMatch(/lps\[0\] configures a bank source \(/);
      expect(msg).toMatch(/PIX and boleto settle only on a zkTLS proof of the bank session/);
      expect(msg).toMatch(/signs card captures only/);
      for (const field of Object.keys(bank)) expect(msg).toContain(field);
      expect(msg).not.toMatch(/https:\/\/|urn:bank/);
      for (const f of BANK_SECRET_FILES) expect(reads, f).not.toContain(f);
    }
    // A bank source with no card beside it: both said at once.
    const msg = problems(() => load(baseEnv, baseFiles([{ lp: LP, ...API_PIX }])));
    expect(msg).toMatch(/configures a bank source/);
    expect(msg).toMatch(/lps\[0\]\.card is required: this attestor signs card captures only/);
  });

  it('refuses OFFRAMP_ESCROW - no sale can be attested here - and takes the empty value a compose file leaves', () => {
    const msg = problems(() => load({ ...baseEnv, OFFRAMP_ESCROW: '0x00000000000000000000000000000000000000cC' }, baseFiles([entry()])));
    expect(msg).toMatch(/OFFRAMP_ESCROW is refused: an off-ramp sale takes no card rail and no attestor quorum/);
    expect(msg).toMatch(/BankRailNeedsZkTls/);
    expect(load({ ...baseEnv, OFFRAMP_ESCROW: '' }, baseFiles([entry()])).escrows).toEqual({ onramp: getAddress(ESCROW) });
  });

  it('requires a card acquirer in every entry', () => {
    expect(problems(() => load(baseEnv, baseFiles([{ lp: LP }])))).toMatch(/lps\[0\]\.card is required/);
  });

  it('refuses an inline credential, and does not repeat it', () => {
    const msg = problems(() => load(baseEnv, baseFiles([entry({ card: card({ credentials: 'inline-token-value-42' }) })])));
    expect(msg).toMatch(/card\.credentials must not be inline/);
    expect(msg).not.toContain('inline-token-value-42');
  });

  it('refuses two entries for one LP', () => {
    expect(problems(() => load(baseEnv, baseFiles([entry(), entry()])))).toMatch(/appears twice/);
    expect(load(baseEnv, baseFiles([entry(), entry({ lp: OTHER_LP })])).sources).toHaveLength(2);
  });

  it('refuses a malformed key without printing any of it', () => {
    const bad = `0x${'f'.repeat(64)}`; // above the curve order
    const msg = problems(() => load({ ...baseEnv, ATTESTOR_KEY_FILE: undefined, ATTESTOR_KEY: bad }, baseFiles([entry()])));
    expect(msg).toMatch(/not a valid 0x-prefixed 32-byte secp256k1 private key/);
    expect(msg).not.toContain('ffff');
  });

  it('refuses an acquirer or merchant id outside the id format', () => {
    expect(problems(() => load(baseEnv, baseFiles([entry({ card: card({ merchantId: 'has space' }) })])))).toMatch(/card\.merchantId is not a valid merchant id/);
    expect(problems(() => load(baseEnv, baseFiles([entry({ card: card({ acquirerId: '' }) })])))).toMatch(/card\.acquirerId is required/);
  });

  it('builds a card source from a plugin that implements CardAcquirer\'s reads, and refuses one for another merchant', async () => {
    const dir = mkdtempSync(join(tmpdir(), 'attestor-plugin-'));
    const plugin = join(dir, 'acquirer.mjs');
    writeFileSync(plugin, `export async function createCardAcquirer(c) {
      return { acquirerId: c.acquirerId, merchantId: c.settings.reportMerchant ?? c.merchantId, async chargesFor() { return []; } };
    }`);
    const ok = await buildSources(load(baseEnv, baseFiles([entry({ card: card({ module: plugin, settings: {} }) })])));
    const s = ok.get(LP.toLowerCase())!;
    expect(s.kind).toBe('card-acquirer');
    await expect(s.cardCapture({ acquirerId: ACQUIRER_ID, transactionId: 'TID-1', reference: '0x01', since: 0n, until: 0n })).resolves.toBeUndefined();
    await expect(buildSources(load(baseEnv, baseFiles([entry({ card: card({ module: plugin, settings: { reportMerchant: 'OTHER' } }) })]))))
      .rejects.toThrow(/different acquirer or merchant/);
  });
});

describe('the request cannot be confused with an attestation', () => {
  it('uses its own EIP-712 domain name and type, so no request signature is a Payment signature', () => {
    expect(requestDomain(1, VERIFIER).name).not.toBe(EIP712_DOMAIN(1, VERIFIER).name);
    expect(Object.keys(REQUEST_TYPES)).not.toContain(Object.keys(PAYMENT_TYPES)[0]);
  });
});

const ROOT = fileURLToPath(new URL('../../../', import.meta.url));
const OUT = process.env.LP_NODE_FORGE_OUT ?? join(ROOT, 'forge-out');
const artifact = (file: string, name: string) => JSON.parse(readFileSync(join(OUT, file, `${name}.json`), 'utf8')) as { abi: Abi };

describe.skipIf(!existsSync(join(OUT, 'LPRegistry.sol', 'LPRegistry.json')))('the ABIs this package adds match the compiled contracts', () => {
  const same = (mine: Abi, compiled: Abi) => {
    for (const f of mine.filter((x): x is AbiFunction => x.type === 'function')) {
      const theirs = compiled.find((c): c is AbiFunction => c.type === 'function' && toFunctionSelector(c) === toFunctionSelector(f));
      expect(theirs, f.name).toBeDefined();
      expect(theirs!.outputs.map((o) => o.type), `${f.name} outputs`).toEqual(f.outputs.map((o) => o.type));
    }
  };
  it('LPRegistry.lps, whose first output is the tier', () => {
    const compiled = artifact('LPRegistry.sol', 'LPRegistry').abi;
    same(ATTESTOR_REGISTRY_ABI, compiled);
    const lps = compiled.find((c): c is AbiFunction => c.type === 'function' && c.name === 'lps')!;
    expect(lps.outputs[0].name).toBe('tier');
  });
  it('AttestorQuorumVerifier and the escrows\' REGISTRY', () => {
    same(VERIFIER_ABI, artifact('AttestorQuorumVerifier.sol', 'AttestorQuorumVerifier').abi);
    same(ESCROW_REGISTRY_ABI, artifact('FiatEscrow.sol', 'FiatEscrow').abi);
    same(ESCROW_REGISTRY_ABI, artifact('OffRampEscrow.sol', 'OffRampEscrow').abi);
  });
});
