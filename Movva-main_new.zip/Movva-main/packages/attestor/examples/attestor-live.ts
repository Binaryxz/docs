/**
 * PSPs' attestor services against the real contracts, end to end, on a local anvil - for card captures, the one rail an
 * attestor quorum still settles.
 *
 * PIX, boleto and TED settle only on a zkTLS proof of the bank session: FiatEscrow refuses a bank-rail offer whose verifier
 * cannot prove one (`BankRailNeedsZkTls`), and AttestorQuorumVerifier cannot. So this deploys the on-ramp from forge
 * artifacts - FiatEscrow, LPRegistry, a 2-of-2 AttestorQuorumVerifier, and the band's price as Mova prices it: USD/BRL from
 * Pyth (MockPyth standing in for Pyth's contract, read by PythFxOracle and scaled to centavos by ScaledFxBandOracle) crossed
 * with an ETH/USD feed by ChainlinkSignedFxOracle - admits an institutional LP, closes setup on every governed contract, and:
 *
 *   1. deploys, and reads the band's price through the cross;
 *   2. serves the card partner's acquirer (MockAcquirer) charge reads over HTTP, with a separate credential per PSP;
 *   3. shows the production entrypoint (src/bin/attestor.ts) refusing to start on a sources file written for the bank rails
 *      - an API Pix source with a boleto ledger, and OFFRAMP_ESCROW - naming why; then starts two attestor services from it,
 *      A and B, each with its own key file, acquirer credential file, sources file and journal, which report ready;
 *   4. bank rails through the quorum: `postOffer` reverts BankRailNeedsZkTls for a PIX, a PIX+boleto and a TED offer naming
 *      it, and each service refuses a signed PIX request by name, before it reads or remembers anything;
 *   5. runs an LP node with a QuorumProver pointed at both services through `RemoteAttestor`, which posts a card-only offer
 *      through the same quorum;
 *   6. card: a taker locks, pays the node's checkout (order plus 3,5% fee); each service reads the capture at the acquirer,
 *      checks the merchant and committed fee open the offer's commitment, both sign the order's amount, and FiatEscrow
 *      releases;
 *   7. a second card order is paid, and the acquirer answers PSP B with a different total: B refuses, the node gets no
 *      proof, and the order stays LOCKED - A's signature alone does not verify on-chain;
 *   8. both services shut down cleanly on SIGTERM, and their logs and journals never contained a key or a credential.
 *
 *   FOUNDRY_OUT=<build dir> npx tsx packages/attestor/examples/attestor-live.ts [rpc]
 *
 * Without an rpc argument it starts its own anvil on port 8751 with one-second blocks.
 */
import { spawn, type ChildProcess } from 'node:child_process';
import { existsSync, mkdtempSync, readFileSync, writeFileSync } from 'node:fs';
import { createServer } from 'node:http';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  BaseError, ContractFunctionRevertedError, createPublicClient, createWalletClient, defineChain, formatEther, getAddress, http, keccak256,
  parseEther, toBytes,
  type Abi, type Account, type Address, type Chain, type Hex, type PublicClient, type Transport, type WalletClient,
} from 'viem';
import { generatePrivateKey, privateKeyToAccount } from 'viem/accounts';
import {
  Rail, cardCheckoutTotal, cardMerchantCommitment, cardTransactionId, encodeQuorumProof, newPixSalt, pixKeyCommitment, railMask,
  type ObservedCardCapture,
} from '@mova/ramp';
import {
  JsonlJournal, LpNode, MockAcquirer, MockBank, OrderState, QuorumProver, ViemRampChain, payerRef,
  type LpNodeOptions, type LpRecord, type PriceFeed,
} from '@mova/lp-node';
import { RemoteAttestor, newRequestNonce, requestToJson, signAttestationRequest } from '../src/index.js';

const ROOT = fileURLToPath(new URL('../../../', import.meta.url));
const OUT = process.env.FOUNDRY_OUT ?? join(ROOT, 'forge-out');
const PORT = 8751;
const RPC = process.argv[2] ?? `http://127.0.0.1:${PORT}`;
const ANVIL = join(ROOT, '.foundry-pinned/v0.3.0/anvil');

const started = Date.now();
const step = (s: string) => console.log(`\n\x1b[1m${s}\x1b[0m  (+${Math.round((Date.now() - started) / 1000)}s)`);
const ok = (s: string) => console.log(`  \x1b[32mOK\x1b[0m    ${s}`);
const info = (k: string, v: unknown) => console.log(`        ${k.padEnd(28)} ${v}`);
class Failed extends Error {}
const check = (cond: unknown, what: string): void => {
  if (!cond) {
    console.log(`  \x1b[31mFAIL\x1b[0m  ${what}`);
    throw new Failed(what);
  }
  ok(what);
};
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const brl = (c: bigint) => `R$ ${(Number(c) / 100).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`;

const art = (name: string, file = `${name}.sol`): { abi: Abi; bytecode: Hex } => {
  const j = JSON.parse(readFileSync(join(OUT, file, `${name}.json`), 'utf8')) as { abi: Abi; bytecode: { object: Hex } };
  return { abi: j.abi, bytecode: j.bytecode.object };
};

/** The custom error a call reverted with, decoded against the ABI it was made with. */
const revertName = (e: unknown): string | undefined => {
  if (!(e instanceof BaseError)) return undefined;
  const r = e.walk((x) => x instanceof ContractFunctionRevertedError);
  return r instanceof ContractFunctionRevertedError ? r.data?.errorName : undefined;
};

const GOVERNANCE_DELAY = 24n * 3600n;
const DISPUTE_TIMEOUT = 30n * 24n * 3600n;
const TIER_INSTITUTIONAL = 3;
const NATIVE: Address = '0x0000000000000000000000000000000000000000';
/** R$ 20.000,00 per ETH: US$ 4.000 at R$ 5,00. */
const ETH_PRICE = 2_000_000n;
const ETH_USD_8DP = 4_000n * 10n ** 8n;
/** Pyth's FX.USD/BRL price id (reais per US dollar), as DeployRamp.s.sol's default. */
const PYTH_USD_BRL: Hex = '0xd2db4dbf1aea74e0f666b0e8f73b9580d407f5e5cf931940b06dc633d7a95906';
const LP_PIX = 'liquidez@lp.example';
const ACQUIRER_ID = '01027058000191';
const MERCHANT_ID = 'MOVA-PARTNER-0001';
const CARD_FEE_BPS = 350;
const FUNDER_KEY: Hex = '0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80';

type Wallet = WalletClient<Transport, Chain, Account>;

/**
 * The card partner's acquirer adapter, as an operator would install it: a module exporting
 * `createCardAcquirer`, returning lp-node's `CardAcquirer` read methods. Plain JavaScript, loaded by the
 * entrypoint from the sources file.
 */
const ACQUIRER_PLUGIN = `
export async function createCardAcquirer(c) {
  const big = (v) => (v === undefined || v === null ? undefined : BigInt(v));
  return {
    acquirerId: c.acquirerId,
    merchantId: c.merchantId,
    async chargesFor(reference) {
      const r = await fetch(c.settings.url + '/charges?reference=' + encodeURIComponent(reference), { headers: { authorization: 'Bearer ' + c.credentials } });
      if (r.status !== 200) throw new Error('the acquirer answered ' + r.status);
      const j = await r.json();
      return j.charges.map((x) => ({ ...x, amountCents: BigInt(x.amountCents), authorizedAt: BigInt(x.authorizedAt), capturedAt: big(x.capturedAt) }));
    },
  };
}
`;

async function startAnvil(): Promise<ChildProcess | undefined> {
  if (process.argv[2]) return undefined;
  const child = spawn(ANVIL, ['--port', String(PORT), '--block-time', '1', '--silent'], { stdio: 'ignore' });
  for (let i = 0; i < 50; i++) {
    try {
      const r = await fetch(RPC, { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{"jsonrpc":"2.0","id":1,"method":"eth_chainId","params":[]}' });
      if (r.ok) return child;
    } catch {
      // not up yet
    }
    await sleep(200);
  }
  child.kill();
  throw new Error(`anvil did not start on ${RPC}`);
}

interface ServiceProcess {
  name: string; child: ChildProcess; output: () => string; opsUrl: string; apiUrl: string; key: Hex; secrets: string[];
}

const children: ChildProcess[] = [];

/** Run the production entrypoint with `env`, collecting everything it prints. */
function entrypoint(env: Record<string, string>): { child: ChildProcess; output: () => string } {
  const child = spawn(process.execPath, ['--import', 'tsx', join(ROOT, 'packages/attestor/src/bin/attestor.ts')], {
    cwd: ROOT, stdio: ['ignore', 'pipe', 'pipe'], env: { ...process.env, ...env },
  });
  children.push(child);
  let output = '';
  child.stdout!.on('data', (d: Buffer) => { output += d.toString(); });
  child.stderr!.on('data', (d: Buffer) => { output += d.toString(); });
  return { child, output: () => output };
}

async function main(): Promise<void> {
  const probe = createPublicClient({ transport: http(RPC) });
  const chainId = await probe.getChainId();
  const chain = defineChain({ id: chainId, name: 'anvil', nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 }, rpcUrls: { default: { http: [RPC] } } });
  const pub = createPublicClient({ chain, transport: http(RPC), pollingInterval: 250 }) as PublicClient;
  const wallet = (key: Hex): Wallet => createWalletClient({ account: privateKeyToAccount(key), chain, transport: http(RPC), pollingInterval: 250 });
  const funder = wallet(FUNDER_KEY);
  const send = async (w: Wallet, address: Address, abi: Abi, functionName: string, args: unknown[], value = 0n) => {
    const hash = await w.writeContract({ address, abi, functionName, args, value } as never);
    const r = await pub.waitForTransactionReceipt({ hash });
    if (r.status !== 'success') throw new Error(`${functionName} reverted`);
    return r;
  };
  const deploy = async (name: string, args: unknown[], file?: string): Promise<Address> => {
    const a = art(name, file);
    const hash = await funder.deployContract({ abi: a.abi, bytecode: a.bytecode, args } as never);
    const r = await pub.waitForTransactionReceipt({ hash });
    if (!r.contractAddress) throw new Error(`${name} did not deploy`);
    // Checksummed, as every contract read and the services' /status report addresses.
    return getAddress(r.contractAddress);
  };
  const fund = async (to: Address, value: bigint) => {
    await pub.waitForTransactionReceipt({ hash: await funder.sendTransaction({ to, value }) });
  };
  const ascending = (xs: Address[]) => [...xs].sort((x, y) => (BigInt(x) < BigInt(y) ? -1 : 1));

  step('1. Deploy the on-ramp: FiatEscrow, LPRegistry, a 2-of-2 AttestorQuorumVerifier, and the USD/BRL band from Pyth');
  info('artifacts', OUT);
  const gov = wallet(generatePrivateKey());
  const lpKey = generatePrivateKey();
  const lp = wallet(lpKey);
  const taker = wallet(generatePrivateKey());
  for (const w of [gov, lp, taker]) await fund(w.account.address, parseEther('20'));

  // Pyth's contract, holding a USD/BRL price as a keeper would have posted it: R$ 5,00000 per dollar, a 0,01% interval.
  const pyth = await deploy('MockPyth', [1n]);
  const at = (await pub.getBlock()).timestamp;
  await send(funder, pyth, art('MockPyth').abi, 'set', [PYTH_USD_BRL, 500_000n, 50n, -5, at]);
  const pythFx = await deploy('PythFxOracle', [pyth, PYTH_USD_BRL, 3600n, 4n * 24n * 3600n, 100, gov.account.address, GOVERNANCE_DELAY]);
  const fxCents = await deploy('ScaledFxBandOracle', [pythFx]);
  const ethUsd = await deploy('MockFeed', [ETH_USD_8DP, 8], 'RampIntegration.t.sol');
  const oracle = await deploy('ChainlinkSignedFxOracle', [ethUsd, fxCents, 3600n, 3600n, gov.account.address, GOVERNANCE_DELAY]);

  const attestorKeys: Hex[] = [generatePrivateKey(), generatePrivateKey()];
  const attestorAddrs = attestorKeys.map((k) => privateKeyToAccount(k).address);
  const registry = await deploy('LPRegistry', [gov.account.address, GOVERNANCE_DELAY]);
  const verifier = await deploy('AttestorQuorumVerifier', [gov.account.address, GOVERNANCE_DELAY, ascending(attestorAddrs), 2n]);
  const poolStub = await deploy('PoolStub', [], 'RampIntegration.t.sol');
  const fiat = await deploy('FiatEscrow', [oracle, registry, poolStub, poolStub, 500n, gov.account.address, GOVERNANCE_DELAY, DISPUTE_TIMEOUT]);
  const deployBlock = await pub.getBlockNumber();
  const FIAT = art('FiatEscrow').abi;
  const VER = art('AttestorQuorumVerifier').abi;
  await send(gov, registry, art('LPRegistry').abi, 'setEscrow', [fiat, true]);
  await send(gov, registry, art('LPRegistry').abi, 'setTier', [lp.account.address, TIER_INSTITUTIONAL, 100_000_000n]);
  await send(gov, fiat, FIAT, 'setVerifier', [verifier, true]);
  for (const c of [pythFx, oracle, registry, verifier, fiat]) await send(gov, c, art('DelayedGovernance').abi, 'completeSetup', []);
  ok('deployed from artifacts; the LP admitted INSTITUTIONAL; setup closed on the Pyth oracle, the cross, the registry, the verifier and the escrow');
  info('FiatEscrow', fiat);
  info('AttestorQuorumVerifier', `${verifier} (2 of ${ascending(attestorAddrs).join(', ')})`);
  const [mid] = await pub.readContract({ address: oracle, abi: art('ChainlinkSignedFxOracle').abi, functionName: 'brlCentsPerUnit' }) as [bigint, bigint];
  check(mid === ETH_PRICE, `the band's price is ${brl(mid)} per ETH: US$ 4.000 from the ETH/USD feed, times Pyth's R$ 5,00 per dollar in centavos`);

  step('2. The card partner\'s acquirer answers charge reads, with a credential per PSP');
  const wall = () => BigInt(Math.floor(Date.now() / 1000));
  const acquirer = new MockAcquirer(ACQUIRER_ID, MERCHANT_ID, { now: wall });
  const secretTail = () => generatePrivateKey().slice(2, 26);
  const acquirerTokens = [`acq-a-${secretTail()}`, `acq-b-${secretTail()}`];
  /** Orders whose captured total the acquirer reports to PSP B 100 centavos short: how step 7's disagreement is staged. */
  const shortToB = new Set<string>();
  const acquirerApi = createServer(async (rq, rs) => {
    const url = new URL(rq.url ?? '/', 'http://acquirer');
    const who = acquirerTokens.findIndex((t) => rq.headers.authorization === `Bearer ${t}`);
    if (who < 0) { rs.writeHead(401); rs.end(); return; }
    if (rq.method === 'GET' && url.pathname === '/charges') {
      const reference = url.searchParams.get('reference') ?? '';
      const charges = (await acquirer.chargesFor(reference))
        .map((c) => (who === 1 && shortToB.has(reference.toLowerCase()) ? { ...c, amountCents: c.amountCents - 100n } : c));
      rs.writeHead(200, { 'content-type': 'application/json' });
      rs.end(JSON.stringify({ charges }, (_k, v) => (typeof v === 'bigint' ? v.toString() : v)));
      return;
    }
    rs.writeHead(404);
    rs.end();
  });
  await new Promise<void>((r) => acquirerApi.listen(0, '127.0.0.1', () => r()));
  const acquirerAddr = acquirerApi.address();
  const acquirerUrl = `http://127.0.0.1:${typeof acquirerAddr === 'object' && acquirerAddr ? acquirerAddr.port : 0}`;
  ok(`the acquirer's charge reads at ${acquirerUrl}`);

  step('3. The production entrypoint: a bank-rail sources file is refused; two card attestor services start');
  const dir = mkdtempSync(join(tmpdir(), 'attestor-live-'));
  const pluginPath = join(dir, 'acquirer-plugin.mjs');
  writeFileSync(pluginPath, ACQUIRER_PLUGIN);
  const cardEntry = (i: number) => {
    const credentialsFile = join(dir, `acquirer-${i}.secret`);
    writeFileSync(credentialsFile, acquirerTokens[i], { mode: 0o600 });
    return { module: pluginPath, acquirerId: ACQUIRER_ID, merchantId: MERCHANT_ID, credentialsFile, settings: { url: acquirerUrl } };
  };
  const baseEnv = (name: string, key: Hex, sources: unknown) => {
    const keyFile = join(dir, `attestor-${name}.key`);
    const sourcesFile = join(dir, `sources-${name}.json`);
    writeFileSync(keyFile, key, { mode: 0o600 });
    writeFileSync(sourcesFile, JSON.stringify({ lps: [sources] }));
    return {
      RPC_URL: RPC, CHAIN_ID: String(chainId), VERIFIER: verifier, REGISTRY: registry, ESCROW: fiat,
      ATTESTOR_KEY_FILE: keyFile, SOURCES_FILE: sourcesFile, JOURNAL_FILE: join(dir, `attestor-${name}.jsonl`),
      PORT: '0', API_PORT: '0', HOST: '127.0.0.1',
    };
  };
  {
    // A sources file as a PSP wrote it when the quorum also attested PIX and boletos: API Pix with a boleto ledger beside the card.
    const pixSecret = `psp-legacy-secret-${secretTail()}`;
    const pixSecretFile = join(dir, 'psp-legacy.secret');
    writeFileSync(pixSecretFile, pixSecret, { mode: 0o600 });
    const legacy = {
      lp: lp.account.address, source: 'api-pix', baseUrl: 'https://pix.psp.example/api/v2', tokenUrl: 'https://pix.psp.example/oauth/token',
      clientId: 'psp-legacy-client', clientSecretFile: pixSecretFile, boletoModule: join(dir, 'boletos.mjs'), card: cardEntry(0),
    };
    const env = { ...baseEnv('legacy', generatePrivateKey(), legacy), OFFRAMP_ESCROW: fiat };
    const { child, output } = entrypoint(env);
    const code = await new Promise<number | null>((r) => child.on('exit', (c) => r(c)));
    const out = output();
    if (code !== 2) console.log(out);
    check(code === 2 && /lps\[0\] configures a bank source \(source, boletoModule, baseUrl, tokenUrl, clientId, clientSecretFile\)/.test(out)
      && /settle only on a zkTLS proof of the bank session/.test(out),
      'the entrypoint refused to start on an API Pix source with a boleto ledger, naming the fields and why: bank rails settle only on zkTLS proofs');
    check(/OFFRAMP_ESCROW is refused/.test(out), 'and on OFFRAMP_ESCROW: no sale takes a card, and none can name a quorum');
    check(!existsSync(env.JOURNAL_FILE) && !out.includes(pixSecret), 'before opening a journal, and without printing the API Pix credential');
  }

  const services: ServiceProcess[] = [];
  for (const [i, name] of (['A', 'B'] as const).entries()) {
    const key = attestorKeys[i];
    const address = privateKeyToAccount(key).address;
    const { child, output } = entrypoint(baseEnv(name, key, { lp: lp.account.address, card: cardEntry(i) }));
    let ports: RegExpExecArray | null = null;
    for (let t = 0; t < 120 && !ports; t++) {
      await sleep(250);
      ports = /ops :(\d+), api :(\d+)/.exec(output());
      if (child.exitCode !== null) break;
    }
    if (!ports) {
      console.log(output());
      throw new Failed(`attestor ${name} did not start`);
    }
    const svc: ServiceProcess = {
      name, child, output, opsUrl: `http://127.0.0.1:${ports[1]}`, apiUrl: `http://127.0.0.1:${ports[2]}`, key, secrets: [acquirerTokens[i]],
    };
    services.push(svc);
    const ready = await fetch(`${svc.opsUrl}/readyz`).then((r) => r.status === 200).catch(() => false);
    const status = await (await fetch(`${svc.opsUrl}/status`)).json() as {
      attestor: Address; verifier: Address; rails: string[]; sources: { kind: string; health: { ok: boolean } }[];
    };
    if (!ready || status.attestor !== address || status.verifier !== verifier) info('status', JSON.stringify(status));
    check(ready && status.attestor === address && status.verifier === verifier && status.rails.join() === 'CARD',
      `attestor ${name} (${status.attestor}) verified the chain, the verifier and its journal, and reports ready for CARD only`);
    check(status.sources[0]?.kind === 'card-acquirer' && status.sources[0].health.ok, `attestor ${name}'s acquirer source answered through the plugin`);
  }
  const metric = async (s: ServiceProcess, series: string) => {
    const text = await (await fetch(`${s.opsUrl}/metrics`)).text();
    const m = new RegExp(`^${series.replace(/[{}"]/g, (c) => `\\${c}`)} (\\d+)`, 'm').exec(text);
    return Number(m?.[1] ?? 'NaN');
  };

  step('4. Bank rails through the quorum: the escrow refuses the offer, and the services refuse the Pix');
  {
    check(await pub.readContract({ address: verifier, abi: VER, functionName: 'provesBankSession' }) === false,
      'the quorum says it cannot prove a bank session (provesBankSession() is false)');
    const pixKeyHash = pixKeyCommitment(LP_PIX, newPixSalt());
    for (const [label, mask] of [['PIX', railMask(Rail.PIX)], ['PIX and boleto', railMask(Rail.PIX, Rail.BOLETO)], ['TED', railMask(Rail.TED)]] as const) {
      const reverted = await pub.simulateContract({
        account: lp.account, address: fiat, abi: FIAT, functionName: 'postOffer', value: parseEther('1'),
        args: [NATIVE, parseEther('1'), ETH_PRICE, pixKeyHash, parseEther('0.01'), parseEther('0.5'), verifier, mask],
      } as never).then(() => 'nothing', revertName);
      check(reverted === 'BankRailNeedsZkTls', `a ${label} offer naming the quorum reverts ${reverted}`);
    }

    // A PIX request, signed by the admitted LP as a node would have made it: nothing about it is wrong but its rail.
    const orderId = keccak256(toBytes(`pix-order-${Date.now()}`));
    const req = await signAttestationRequest(privateKeyToAccount(lpKey), { chainId, verifier }, {
      lp: lp.account.address, orderId, payeeKeyHash: pixKeyHash, orderBrlCents: 10_000n, lockedAt: wall() - 60n, rail: Rail.PIX,
      bankTxId: `E99999999${Date.now()}PIX`.slice(0, 32).padEnd(32, '0'), amountBrlCents: 10_000n, paidAt: wall() - 30n,
      payerRef: `0x${'77'.repeat(32)}`, payee: LP_PIX, salt: `0x${'ab'.repeat(32)}`, issuedAt: wall(), nonce: newRequestNonce(),
    });
    for (const s of services) {
      const res = await fetch(`${s.apiUrl}/v1/attest`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(requestToJson(req)) });
      const body = await res.json() as { error?: string; message?: string };
      check(res.status === 422 && body.error === 'bank_rail_needs_zktls' && /zkTLS proof of the bank session/.test(body.message ?? ''),
        `attestor ${s.name} refused the PIX request: 422 bank_rail_needs_zktls`);
      check(await metric(s, 'mova_attestor_refusals_total{reason="bank_rail_needs_zktls"}') === 1
        && await metric(s, 'mova_attestor_journal_records') === 0,
        `attestor ${s.name}: counted the refusal, and burned no nonce for it`);
    }
  }

  step('5. The LP node, its QuorumProver pointed at both services, posts a card-only offer through the quorum');
  const feed: PriceFeed = { price: async () => ({ price: ETH_PRICE + ETH_PRICE / 500n, updatedAt: wall() }) };
  const pricing = { spreadBps: 100, minSpreadBps: 30, maxOracleDeviationBps: 200, bandMarginBps: 100, refreshDriftBps: 60, maxReferenceAgeSeconds: 120, oracleStaleMarginSeconds: 300 };
  const bank = new MockBank({ now: wall });
  const rampChain = new ViemRampChain({ publicClient: pub, walletClient: lp, registry, onramp: fiat });
  const remotes = services.map((s, i) => new RemoteAttestor({
    url: s.apiUrl, address: attestorAddrs[i], chainId, verifier, signer: privateKeyToAccount(lpKey),
  }));
  const options: LpNodeOptions = {
    chain: rampChain, bank, acquirer, journal: new JsonlJournal<LpRecord>(join(dir, 'lp-node.jsonl')),
    provers: [new QuorumProver(verifier, remotes, 2)],
    confirmations: 2, fromBlock: deployBlock, reorgWindow: 16n, payerRefSecret: `0x${'5a'.repeat(32)}`, lpPayerId: '12345678000195',
    wallClock: wall, pollMs: 500, log: { info: () => {}, warn: () => {}, error: (m: string) => console.log(`        node error: ${m}`) },
    onramp: {
      escrow: fiat, pixKey: LP_PIX, receiver: { name: 'LP Liquidez Ltda', city: 'Sao Paulo' }, reclaimExpired: false, autoRefund: false,
      boletoDueDays: 3, reorgWindow: 16n, lateCreditGraceSeconds: 600,
      card: { acquirerId: ACQUIRER_ID, merchantId: MERCHANT_ID, feeBps: CARD_FEE_BPS, checkoutMarginSeconds: 300 },
      assets: [
        { asset: NATIVE, symbol: 'ETH', liquidity: parseEther('1'), minOrder: parseEther('0.01'), maxOrder: parseEther('0.5'), verifier,
          rails: [Rail.CARD], refillBelowBps: 2_000, feed, gasReserveWei: parseEther('1'), pricing },
      ],
    },
  };
  const node = new LpNode(options);
  const until = async (what: string, cond: () => Promise<boolean>, maxTicks = 40) => {
    for (let i = 0; i < maxTicks; i++) {
      await node.tick();
      if (await cond()) return;
      await sleep(400);
    }
    throw new Failed(`timed out waiting for: ${what}`);
  };
  await until('the card offer', async () => !!node.offers!.status.get(`${NATIVE}#card`)?.quoting);
  const cardOfferId = node.offers!.status.get(`${NATIVE}#card`)!.activeOfferId!;
  const cardOffer = await rampChain.offer(cardOfferId);
  const cardSalt = node.store.saltFor(cardOffer.pixKeyHash)!;
  check(cardOffer.verifier === verifier && cardOffer.railMask === 1 << Rail.CARD
    && cardOffer.pixKeyHash === cardMerchantCommitment({ acquirerId: ACQUIRER_ID, merchantId: MERCHANT_ID, feeBps: CARD_FEE_BPS }, cardSalt),
    'a card-only offer through the quorum, committed to the partner\'s merchant account at a 3,5% card fee');

  const lockCard = async (amount: bigint, recipient: Address) => {
    const rc = await send(taker, fiat, FIAT, 'lockOrder', [cardOfferId, amount, 0, recipient, 0n]);
    const orderId = ((await pub.getContractEvents({ address: fiat, abi: FIAT, eventName: 'OrderLocked', blockHash: rc.blockHash }))[0] as unknown as { args: { orderId: Hex } }).args.orderId;
    await until('the checkout, once the lock is confirmed', async () => !!node.store.getOrder(orderId)?.card?.checkoutId);
    const ord = await rampChain.order(orderId);
    const checkout = [...acquirer.checkouts.values()].find((c) => c.checkoutId === node.store.getOrder(orderId)!.card!.checkoutId)!;
    return { orderId, ord, checkout };
  };
  const burned = (id: Hex) => pub.readContract({ address: fiat, abi: FIAT, functionName: 'usedBankTxId', args: [id] });

  step('6. A card order releases on the two PSPs\' 2-of-2, from the capture each service read at the acquirer');
  {
    // Delivered to a fresh address, so what it holds is exactly what the escrow released - the taker pays gas.
    const recipient = privateKeyToAccount(generatePrivateKey()).address;
    const amount = parseEther('0.02');
    const { orderId, ord, checkout } = await lockCard(amount, recipient);
    const total = cardCheckoutTotal(ord.brlCents, CARD_FEE_BPS);
    check(checkout.amountCents === total && checkout.reference === orderId,
      `the node's checkout charges the order's ${brl(ord.brlCents)} plus the committed fee, ${brl(total)}, under the order's reference`);
    await sleep(1_100); // a capture in a later second than the lock, as a real one is
    const paid = acquirer.pay(checkout.checkoutId);
    info('capture', `${paid.transactionId} for ${brl(paid.amountCents)}`);
    await until('card release', async () => (await rampChain.order(orderId)).state === OrderState.RELEASED);
    check((await pub.getBalance({ address: recipient })) === amount,
      `each service found the capture under the order's reference, opened the commitment with the merchant it saw and the committed fee, and FiatEscrow released ${formatEther(amount)} ETH`);
    check(await burned(cardTransactionId(paid.acquirerId, paid.transactionId)) === true, 'the escrow burned the acquirer-scoped transaction id');
    for (const s of services) {
      check(await metric(s, 'mova_attestor_requests_total{result="signed"}') === 1
        && await metric(s, 'mova_attestor_signed_brl_cents_total{rail="CARD"}') === Number(ord.brlCents),
        `attestor ${s.name}: one signature, journaled, for the order's ${brl(ord.brlCents)} - not the ${brl(total)} the cardholder paid`);
    }
  }

  step('7. The acquirer answers PSP B with a different total: B refuses, and the order does not release');
  {
    const amount = parseEther('0.03');
    const { orderId, ord, checkout } = await lockCard(amount, taker.account.address);
    shortToB.add(orderId.toLowerCase());
    await sleep(1_100);
    const paid = acquirer.pay(checkout.checkoutId);
    info('order', `${orderId.slice(0, 18)}… for ${brl(ord.brlCents)}; captured ${brl(paid.amountCents)}, shown to PSP B as ${brl(paid.amountCents - 100n)}`);
    for (let i = 0; i < 12; i++) {
      await node.tick();
      await sleep(400);
    }
    check((await rampChain.order(orderId)).state === OrderState.LOCKED, 'after twelve ticks the order is still LOCKED');
    check(await metric(services[1], 'mova_attestor_refusals_total{reason="source_disagrees"}') >= 1, 'attestor B refused: its read shows a different total than the LP claims');
    check(await metric(services[0], 'mova_attestor_requests_total{result="signed"}') === 2, 'attestor A signed: its read agrees');
    check(node.metrics.get('mova_lp_proof_failures_total', { leg: 'onramp' }) >= 1, 'the node recorded that no proof could be had');

    // A's signature, as the node would present it, alone.
    const terms = { orderId, payeeKeyHash: cardOffer.pixKeyHash, brlCents: ord.brlCents, lockedAt: ord.lockedAt, acceptedRails: [Rail.CARD] };
    const seen: ObservedCardCapture = {
      acquirerId: paid.acquirerId, transactionId: paid.transactionId, merchantId: paid.merchantId, salt: cardSalt, feeBps: CARD_FEE_BPS,
      payerRef: payerRef(paid.payerId, options.payerRefSecret), status: 'CAPTURED', capturedAmountBrlCents: paid.amountCents, capturedAt: paid.capturedAt!,
    };
    const signed = await remotes[0].attestCard(terms, seen);
    const lone = encodeQuorumProof(signed.payment, [{ signer: attestorAddrs[0], signature: signed.signature }]);
    const refused = await pub.readContract({ address: verifier, abi: VER, functionName: 'verifyPayment', args: [orderId, lone] })
      .then(() => 'nothing', revertName);
    check(refused === 'NotEnoughSignatures', `A's signature alone is refused by the verifier: ${refused}`);
  }

  step('8. Shutdown, and what the services never printed or wrote');
  await node.stop();
  for (const s of services) {
    const exited = new Promise<number | null>((r) => s.child.on('exit', (code) => r(code)));
    s.child.kill('SIGTERM');
    check((await exited) === 0, `attestor ${s.name}: SIGTERM closed its listeners and journal, exit 0`);
    const out = s.output();
    check(!out.includes(s.key.slice(2)) && s.secrets.every((x) => !out.includes(x)), `attestor ${s.name}: its logs never contained its key or its acquirer credential`);
    const journal = readFileSync(join(dir, `attestor-${s.name}.jsonl`), 'utf8');
    check(!journal.includes(s.key.slice(2)) && s.secrets.every((x) => !journal.includes(x)) && !journal.includes(cardSalt.slice(2)),
      `attestor ${s.name}: its journal holds no key, no credential and no salt`);
  }
  await new Promise<void>((r) => { acquirerApi.close(() => r()); acquirerApi.closeAllConnections(); });

  console.log('\n  \x1b[1mTwo PSPs attested a card capture each read for itself; when one read a different total, nothing released.'
    + ' A PIX offer through their quorum never existed: the escrow refused it, and both services refused to sign a Pix.\x1b[0m\n');
}

let anvil: ChildProcess | undefined;
startAnvil()
  .then((a) => { anvil = a; return main(); })
  .catch((e: unknown) => {
    if (!(e instanceof Failed)) console.error('\nfailed:', e instanceof Error ? e.message : e);
    process.exitCode = 1;
  })
  .finally(() => {
    for (const c of children) if (c.exitCode === null) c.kill('SIGKILL');
    anvil?.kill();
    process.exit(process.exitCode ?? 0);
  });
