# @mova/attestor

The service a licensed PSP runs to hold one key in `AttestorQuorumVerifier` and sign **card captures**: an
institutional LP's card-only offer, paid through a checkout at the card partner's acquirer. It reads the order's terms
from the chain and the charge from the acquirer, and signs only what both show (SR2-33 in
`docs/security-review-phase2.md`).

## Card only, and why

PIX, boleto and TED settle **only on a zkTLS proof of the bank session** (`ReclaimZkTlsVerifier`). Every verifier says
whether it can prove one (`IAttestorVerifier.provesBankSession()`); an attestor quorum cannot - M signatures cannot rule
out M colluding PSPs signing a payment that never happened, while zkTLS witnesses can refuse to attest but cannot invent a
bank session. So the escrows refuse bank rails through a quorum before any order exists:

- `FiatEscrow.postOffer` reverts `BankRailNeedsZkTls()` for any offer taking a rail other than CARD through a verifier
  whose `provesBankSession()` is false;
- `OffRampEscrow.openSale` reverts it for every such sale - every payout is a bank payment, and nobody is paid out by card.

A signature from this service over a PIX or boleto payment could therefore never settle anything, and the service does not
pretend otherwise:

| Request | Answer |
|---|---|
| `rail` PIX (1), BOLETO (2) or TED (3) | **422 `bank_rail_needs_zktls`**, first, whoever signed it and for whatever order: no signature check, chain read, rate-limit bucket, nonce or source call is spent on it |
| an unknown rail | 422 `rail_unsupported` |
| CARD, on an order whose offer is card-only and names this verifier | checked against the chain and the acquirer, then signed or refused (`src/refusal.ts` lists every code) |

`RemoteAttestor` (`src/client.ts`, the LP node's `AttestorEndpoint`) raises the same `bank_rail_needs_zktls` refusal for
`attest` (PIX) and `attestBoleto` locally, without a request. lp-node's `QuorumProver` refuses PIX and boleto proofs itself
and never asks; an LP proves those with a zkTLS prover against `ReclaimZkTlsVerifier`.

## Running it

`src/bin/attestor.ts` - the environment variables and the sources file are documented in its header. In short:

```bash
RPC_URL=... VERIFIER=0x<quorum> REGISTRY=0x... ESCROW=0x<FiatEscrow> \
ATTESTOR_KEY_FILE=/run/secrets/attestor_key SOURCES_FILE=/app/config/sources.json JOURNAL_FILE=/app/data/attestor.jsonl \
node --import tsx packages/attestor/src/bin/attestor.ts
```

```json
{ "lps": [
  { "lp": "0x...",
    "card": { "module": "/app/plugins/acquirer.js", "acquirerId": "01027058000191", "merchantId": "MOVA-PARTNER-0001",
              "credentialsFile": "/run/secrets/lp1_acquirer", "settings": { "baseUrl": "https://api.acquirer.example" } } }
] }
```

It **refuses to start** on configuration written for the bank rails, rather than accept it and attest nothing:

- a sources entry with `"source": "api-pix"` or `"open-finance"`, a `boletoModule`, or any field of those sources - the
  error names the fields and the reason, and the credential files the entry names are never read;
- `OFFRAMP_ESCROW` set to anything but empty - no sale can name a quorum, and none takes a card;
- an entry without `card`.

If an existing deployment's `sources.json` has bank sources, delete them and keep each LP's `card` block; unset
`OFFRAMP_ESCROW`. The journal needs no migration: its records of PIX or boleto signatures stay, and still refuse a reused id.

## What was kept, unwired

The bank-fact readers the service used to sign from are kept as a library, and are not used by the service:

- `src/sources/api-pix.ts` - `ApiPixSource`: a Pix the LP's PSP received, by end-to-end id (key, amount, time, refunds),
  over lp-node's `ApiPixClient`; with a `BoletoLedger` (`src/source.ts`), a boleto the PSP collected.
- `src/sources/open-finance.ts` - `OpenFinanceSource` and `PrivateKeyJwtSession`: an account's credits under the LP's Open
  Finance Brasil consent (Accounts 2.4.2, Consents 3.3.1, FAPI `private_key_jwt`, the operational call budget).
- `src/mock-psp.ts`, `src/mock-transmitter.ts` - their test doubles.

They implement `BankFactSource`, not `PaymentSource`, and `PaymentAttestor` refuses a source without `cardCapture` at
construction. They are kept because an LP still needs what they read - that a payment arrived, under which institution id,
before asking for a zkTLS session over it, or to reconcile - and because getting the specifications right was not cheap.
The signing paths for PIX and boletos were removed from `src/service.ts`, not switched off: a key that releases escrowed
crypto should have no code that signs a payment the chain no longer accepts.

## Tests

```bash
npx vitest run packages/attestor
FOUNDRY_OUT=forge-out npx tsx packages/attestor/examples/attestor-live.ts [rpc]   # its own anvil on :8751 without [rpc]
```

- `test/attestor.test.ts` - attacks on the service: bank rails refused first and by name, who is asking, terms from the
  chain, one charge for two orders, the journal across a crash, secrets, the wire.
- `test/card.test.ts` - charges that are not the order's payment: not captured, wrong total or fee, before the lock, another
  merchant, another order's checkout; sources that are not card sources.
- `test/client.test.ts` - `QuorumProver` over two services through `RemoteAttestor`: a card 2-of-2, one PSP disagreeing,
  a wrong signer, an opening that does not open; PIX and boleto refused by `RemoteAttestor` and the prover without a request.
- `test/open-finance.test.ts` - the kept bank-fact readers against their mocks, and the service refusing them.
- `test/bin.test.ts` - the entrypoint's configuration, including every refusal above.
- `examples/attestor-live.ts` - two PSPs' services from the production entrypoint against the real contracts on anvil: a
  card order released on their 2-of-2, one PSP's acquirer read disagreeing and nothing releasing, a PIX offer through the
  quorum reverting `BankRailNeedsZkTls`, a PIX request refused by both services, and an entrypoint refusing a PIX sources file.
