import { describe, expect, it } from 'vitest';
import { encodeFunctionData, hexToBytes, recoverAddress, type Hex } from 'viem';
import { MemoryJournal } from '@mova/lp-node/src/journal.js';
import {
  KERNEL_ABI, PasskeyAuthenticator, decodeKernelUserOpSignature, decodePasskeyCoSignerSignature, encodeSafeSignatures, encodeVeto,
  encodeWebAuthnSignature,
} from '@mova/smart-account';
import { INSTRUCTIONS_TYPES, instructionsDomain } from '@mova/wallet';
import { policyOf, type AuditRecord, type DecisionRecord } from '../src/index.js';
import {
  CHAIN_ID, DEFAULT_TEST_POLICY, ESCROW, OTHER, SAFE_ADMIN_ABI, SERVER, SERVER_KEY, STRANGER, TOKEN, VAULT, approve, deposit,
  enrolmentProof, expectRefusal, fakeSafeAddress, fakeSignerAddress, kernelAccount, kernelOp, safeAccount, safeFirstInitCode, safeOp, sig,
  world,
} from './harness.js';

const k = (a: string) => a.toLowerCase();
const decisions = (journal: MemoryJournal<AuditRecord>) => journal.load().filter((r): r is DecisionRecord => r.t === 'decision');

describe('enrolment binds an account to the passkey the chain names', () => {
  it('binds a counterfactual Safe through the CREATE2 commitment, with a passkey proof', async () => {
    const w = world();
    const a = await safeAccount(w);
    expect(a.enrolment).toMatchObject({ kind: 'safe-passkey', account: a.account, passkeySigner: a.passkeySigner, coSigner: SERVER, counterfactual: true });
    expect(a.enrolment.passkey.x).toBe(w.pk.x);
    expect(w.journal.load().filter((r) => r.t === 'enrol')).toHaveLength(1);
    const again = await w.service.enrol({ chainId: CHAIN_ID, account: a.account, type: 'safe', passkey: w.pk, safe: { owners: a.owners, threshold: 2, saltNonce: a.saltNonce }, ...enrolmentProof(w, a.account) }, w.caller);
    expect(again.created).toBe(false);
  });

  it('refuses a proof signed by another passkey', async () => {
    const w = world();
    const signer = w.chain.deploySigner(w.pk);
    const owners = [signer, SERVER];
    const account = fakeSafeAddress(owners, 2, 1n);
    const thief = PasskeyAuthenticator.create('wallet.brl.example');
    const proof = enrolmentProof({ ...w, passkey: thief }, account);
    await expectRefusal(w.service.enrol({ chainId: CHAIN_ID, account, type: 'safe', safe: { owners, threshold: 2, saltNonce: 1n }, ...proof }, w.caller), 'bad_passkey_signature');
    await expectRefusal(w.service.enrol({ chainId: CHAIN_ID, account, type: 'safe', safe: { owners, threshold: 2, saltNonce: 1n }, issuedAt: proof.issuedAt, passkeySignature: '0x' }, w.caller), 'passkey_required');
  });

  it('never takes the passkey from the request: a claimed key must be the one the owner address commits to', async () => {
    const w = world();
    const owners = [fakeSignerAddress(w.pk), SERVER];
    const account = fakeSafeAddress(owners, 2, 1n);
    const other = PasskeyAuthenticator.create('x').publicKey();
    await expectRefusal(w.service.enrol({ chainId: CHAIN_ID, account, type: 'safe', passkey: { ...other, verifiers: w.pk.verifiers }, safe: { owners, threshold: 2, saltNonce: 1n }, ...enrolmentProof(w, account) }, w.caller), 'deployment_mismatch');
    // A deployed Kernel account: the request's key is ignored, the validator's storage is read.
    const kernel = await kernelAccount(w, { deployed: true });
    expect(kernel.enrolment.passkey.x).toBe(w.pk.x);
  });

  it('refuses an account this service is not a signer of, a wrong deployment, and a stale proof', async () => {
    const w = world();
    const signer = w.chain.deploySigner(w.pk);
    const notOurs = fakeSafeAddress([signer, OTHER], 2, 1n);
    await expectRefusal(w.service.enrol({ chainId: CHAIN_ID, account: notOurs, type: 'safe', safe: { owners: [signer, OTHER], threshold: 2, saltNonce: 1n }, ...enrolmentProof(w, notOurs) }, w.caller), 'not_a_cosigner');
    const ours = fakeSafeAddress([signer, SERVER], 2, 1n);
    await expectRefusal(w.service.enrol({ chainId: CHAIN_ID, account: ours, type: 'safe', safe: { owners: [signer, SERVER], threshold: 2, saltNonce: 2n }, ...enrolmentProof(w, ours) }, w.caller), 'deployment_mismatch');
    await expectRefusal(w.service.enrol({ chainId: CHAIN_ID, account: ours, type: 'safe', safe: { owners: [signer, SERVER], threshold: 2, saltNonce: 1n }, ...enrolmentProof(w, ours, Number(w.clock.now) - 3600) }, w.caller), 'enrolment_expired');
    await expectRefusal(w.service.enrol({ chainId: 1, account: ours, type: 'safe', ...enrolmentProof(w, ours) }, w.caller), 'wrong_chain');
  });
});

describe('co-signing: never without the passkey over the exact same operation', () => {
  it('co-signs a Safe operation, in the layout the Safe checks', async () => {
    const w = world();
    const a = await safeAccount(w);
    const { userOp, window, digest } = safeOp(w, a.account, [approve(VAULT, 400n), deposit(400n)], { initCode: safeFirstInitCode(a.owners, a.saltNonce) });
    const passkeySignature = sig(w, digest);
    const r = await w.service.cosign({ chainId: CHAIN_ID, account: a.account, kind: 'safe-operation', userOp, window, passkeySignature }, w.caller);
    expect(r.reused).toBe(false);
    expect(await recoverAddress({ hash: digest, signature: r.coSignature })).toBe(SERVER);
    expect(r.signature).toBe(encodeSafeSignatures(window.validAfter, window.validUntil, [
      { owner: a.passkeySigner, kind: 'contract', signature: passkeySignature }, { owner: SERVER, kind: 'eoa', signature: r.coSignature },
    ]));
  });

  it('refuses a forged passkey signature, a missing one, and a genuine one over a different operation', async () => {
    const w = world();
    const a = await safeAccount(w, { deployed: true });
    const op = safeOp(w, a.account, [deposit(1n)]);
    const forger = PasskeyAuthenticator.create('wallet.brl.example');
    await expectRefusal(w.service.cosign({ chainId: CHAIN_ID, account: a.account, kind: 'safe-operation', ...op, passkeySignature: encodeWebAuthnSignature(forger.sign(hexToBytes(op.digest))) }, w.caller), 'bad_passkey_signature');
    await expectRefusal(w.service.cosign({ chainId: CHAIN_ID, account: a.account, kind: 'safe-operation', ...op, passkeySignature: '0x' }, w.caller), 'passkey_required');
    const approved = safeOp(w, a.account, [deposit(1n)]);
    const swapped = safeOp(w, a.account, [deposit(1000n)]);
    await expectRefusal(w.service.cosign({ chainId: CHAIN_ID, account: a.account, kind: 'safe-operation', ...swapped, passkeySignature: sig(w, approved.digest) }, w.caller), 'bad_passkey_signature');
    // The same calls with a longer window is a different operation too.
    const longer = safeOp(w, a.account, [deposit(1n)], { validUntil: approved.window.validUntil + 1 });
    await expectRefusal(w.service.cosign({ chainId: CHAIN_ID, account: a.account, kind: 'safe-operation', ...longer, passkeySignature: sig(w, approved.digest) }, w.caller), 'bad_passkey_signature');
  });

  it('refuses an expired, an unbounded and a long validity window', async () => {
    const w = world();
    const a = await safeAccount(w, { deployed: true });
    const now = Number(w.chain.time);
    for (const [validUntil, code] of [[now - 1, 'expired'], [0, 'window_unbounded'], [now + 1801, 'window_too_long']] as const) {
      const op = safeOp(w, a.account, [deposit(1n)], { validUntil });
      await expectRefusal(w.service.cosign({ chainId: CHAIN_ID, account: a.account, kind: 'safe-operation', ...op, passkeySignature: sig(w, op.digest) }, w.caller), code);
    }
  });

  it('refuses a disallowed target and an authority change, with the passkey\'s genuine signature', async () => {
    const w = world();
    const a = await safeAccount(w, { deployed: true });
    const toStranger = safeOp(w, a.account, [{ to: STRANGER, data: '0x12345678' }]);
    await expectRefusal(w.service.cosign({ chainId: CHAIN_ID, account: a.account, kind: 'safe-operation', ...toStranger, passkeySignature: sig(w, toStranger.digest) }, w.caller), 'target_not_allowed');
    const addOwner = safeOp(w, a.account, [{ to: a.account, data: encodeFunctionData({ abi: SAFE_ADMIN_ABI, functionName: 'addOwnerWithThreshold', args: [STRANGER, 1n] }) }]);
    await expectRefusal(w.service.cosign({ chainId: CHAIN_ID, account: a.account, kind: 'safe-operation', ...addOwner, passkeySignature: sig(w, addOwner.digest) }, w.caller), 'authority_change');
    const kernel = await kernelAccount(w, { deployed: true });
    const install = kernelOp(w, kernel.account, [{ to: kernel.account, data: encodeFunctionData({ abi: KERNEL_ABI, functionName: 'installModule', args: [1n, STRANGER, '0x'] }) }]);
    await expectRefusal(w.service.cosign({ chainId: CHAIN_ID, account: kernel.account, kind: 'kernel-operation', ...install, passkeySignature: sig(w, install.digest) }, w.caller), 'authority_change');
    const refusals = decisions(w.journal).filter((d) => d.decision === 'refused').map((d) => d.code);
    expect(refusals).toEqual(['target_not_allowed', 'authority_change', 'authority_change']);
  });

  it('refuses a replay of an executed operation, and answers an identical request again without counting it twice', async () => {
    const w = world({ policy: policyOf({ ...DEFAULT_TEST_POLICY(), tokens: [{ address: TOKEN, label: 'tBRL', transfer: false, dailyLimit: 500n }] }) });
    const a = await safeAccount(w, { deployed: true });
    const op = safeOp(w, a.account, [approve(VAULT, 400n), deposit(400n)]);
    const req = { chainId: CHAIN_ID, account: a.account, kind: 'safe-operation' as const, ...op, passkeySignature: sig(w, op.digest) };
    const first = await w.service.cosign(req, w.caller);
    const second = await w.service.cosign({ ...req, passkeySignature: sig(w, op.digest) }, w.caller);
    expect(second.reused).toBe(true);
    expect(second.coSignature).toBe(first.coSignature);
    // Counted once: another 100 still fits under 500.
    const more = safeOp(w, a.account, [approve(VAULT, 100n)], { nonce: 1n });
    await w.service.cosign({ chainId: CHAIN_ID, account: a.account, kind: 'safe-operation', ...more, passkeySignature: sig(w, more.digest) }, w.caller);
    // The EntryPoint consumed nonce 0: the approved operation is now a replay.
    w.chain.nonces.set(k(a.account), 1n);
    await expectRefusal(w.service.cosign(req, w.caller), 'replayed');
    // A deployed account's operation carrying initCode again is a replay of its first operation.
    const redeploy = safeOp(w, a.account, [deposit(1n)], { nonce: 1n, initCode: safeFirstInitCode(a.owners, a.saltNonce) });
    await expectRefusal(w.service.cosign({ chainId: CHAIN_ID, account: a.account, kind: 'safe-operation', ...redeploy, passkeySignature: sig(w, redeploy.digest) }, w.caller), 'replayed');
  });

  it('rate-limits per account, after the passkey verified', async () => {
    const w = world({ policy: policyOf({ ...DEFAULT_TEST_POLICY(), rateLimit: { burst: 3, perMinute: 1 } }) });
    const a = await safeAccount(w, { deployed: true }); // enrolment takes one token
    const send = (nonce: bigint) => {
      const op = safeOp(w, a.account, [deposit(1n)], { nonce });
      return w.service.cosign({ chainId: CHAIN_ID, account: a.account, kind: 'safe-operation', ...op, passkeySignature: sig(w, op.digest) }, w.caller);
    };
    // A stranger's forged requests do not spend the user's tokens.
    const forged = safeOp(w, a.account, [deposit(1n)], { nonce: 9n });
    for (let i = 0; i < 5; i++) {
      await expectRefusal(w.service.cosign({ chainId: CHAIN_ID, account: a.account, kind: 'safe-operation', ...forged, passkeySignature: sig({ passkey: PasskeyAuthenticator.create('x') }, forged.digest) }, w.caller), 'bad_passkey_signature');
    }
    await send(0n);
    await send(1n);
    await expectRefusal(send(2n), 'rate_limited');
  });

  it('refuses past the daily value limit, and remembers the day across a restart', async () => {
    const journal = new MemoryJournal<AuditRecord>();
    const w = world({ journal });
    const a = await safeAccount(w, { deployed: true });
    const op = (nonce: bigint, amount: bigint) => {
      const o = safeOp(w, a.account, [approve(ESCROW, amount)], { nonce });
      return { chainId: CHAIN_ID, account: a.account, kind: 'safe-operation' as const, ...o, passkeySignature: sig(w, o.digest) };
    };
    await w.service.cosign(op(0n, 600n * 10n ** 18n), w.caller);
    await expectRefusal(w.service.cosign(op(1n, 600n * 10n ** 18n), w.caller), 'daily_limit_exceeded');
    const restarted = world({ journal, chain: w.chain, clock: w.clock, passkey: w.passkey });
    await expectRefusal(restarted.service.cosign(op(1n, 500n * 10n ** 18n), w.caller), 'daily_limit_exceeded');
    w.clock.now += 24n * 3600n + 1n;
    w.chain.time += 24n * 3600n + 1n;
    await restarted.service.cosign(op(1n, 500n * 10n ** 18n), w.caller);
  });

  it('refuses once the account\'s on-chain signers stop matching the enrolment', async () => {
    const w = world();
    const a = await safeAccount(w, { deployed: true });
    w.chain.safes.set(k(a.account), { owners: [a.passkeySigner, OTHER], threshold: 2n, modules: [] });
    const op = safeOp(w, a.account, [deposit(1n)]);
    await expectRefusal(w.service.cosign({ chainId: CHAIN_ID, account: a.account, kind: 'safe-operation', ...op, passkeySignature: sig(w, op.digest) }, w.caller), 'enrolment_stale');
  });

  it('refuses an unknown account, the wrong chain, and an undeployed account\'s operation that does not deploy it', async () => {
    const w = world();
    const a = await safeAccount(w);
    const op = safeOp(w, a.account, [deposit(1n)]);
    const req = { chainId: CHAIN_ID, account: a.account, kind: 'safe-operation' as const, ...op, passkeySignature: sig(w, op.digest) };
    await expectRefusal(w.service.cosign(req, w.caller), 'not_deployed');
    await expectRefusal(w.service.cosign({ ...req, chainId: 1 }, w.caller), 'wrong_chain');
    await expectRefusal(w.service.cosign({ ...req, account: STRANGER, userOp: { ...op.userOp, sender: STRANGER } }, w.caller), 'not_enrolled');
    await expectRefusal(w.service.cosign({ ...req, kind: 'kernel-operation' }, w.caller), 'wrong_account_kind');
  });

  it('co-signs a Kernel UserOpChallenge for PasskeyCoSignerValidator', async () => {
    const w = world();
    const a = await kernelAccount(w);
    const op = kernelOp(w, a.account, [approve(VAULT, 1n), deposit(1n)], { initCode: '0x1234' });
    const passkeySignature = sig(w, op.digest);
    const r = await w.service.cosign({ chainId: CHAIN_ID, account: a.account, kind: 'kernel-operation', ...op, passkeySignature }, w.caller);
    const { validUntil, body } = decodeKernelUserOpSignature(r.signature);
    expect(validUntil).toBe(op.window.validUntil);
    const parts = decodePasskeyCoSignerSignature(body);
    expect(parts.passkeySignature).toBe(passkeySignature);
    expect(await recoverAddress({ hash: op.digest, signature: parts.coSignerSignature })).toBe(SERVER);
  });

  it('co-signs ERC-1271 typed data for a listed contract, and refuses a permit', async () => {
    const w = world();
    const a = await safeAccount(w, { deployed: true });
    const typedData = { domain: instructionsDomain(CHAIN_ID, ESCROW), types: INSTRUCTIONS_TYPES, primaryType: 'PaymentInstructionsRequest', message: { orderId: `0x${'01'.repeat(32)}` as Hex, issuedAt: 5n } };
    const { safeMessageHash } = await import('@mova/wallet/src/executor.js');
    const { hashTypedData } = await import('viem');
    const digest = safeMessageHash(a.account, CHAIN_ID, hashTypedData(typedData as never));
    const r = await w.service.cosign({ chainId: CHAIN_ID, account: a.account, kind: 'safe-message', typedData, passkeySignature: sig(w, digest) }, w.caller);
    expect(await recoverAddress({ hash: digest, signature: r.coSignature })).toBe(SERVER);
    const permit = { domain: { name: 'USDT', chainId: CHAIN_ID, verifyingContract: VAULT }, types: { Permit: [{ name: 'value', type: 'uint256' }] }, primaryType: 'Permit', message: { value: 1n } };
    const permitDigest = safeMessageHash(a.account, CHAIN_ID, hashTypedData(permit as never));
    await expectRefusal(w.service.cosign({ chainId: CHAIN_ID, account: a.account, kind: 'safe-message', typedData: permit, passkeySignature: sig(w, permitDigest) }, w.caller), 'message_not_allowed');
  });
});

describe('the recovery veto: the user vetoes, the server never vetoes alone', () => {
  async function queued() {
    const w = world();
    const a = await safeAccount(w, { deployed: true });
    const delay = w.chain.installDelay(a.account, a.passkeySigner);
    const nonce = w.chain.queue(delay, { to: TOKEN, value: 0n, data: encodeFunctionData({ abi: SAFE_ADMIN_ABI, functionName: 'changeThreshold', args: [1n] }) });
    return { w, a, delay, nonce };
  }

  it('exposes the queue, and co-signs setTxNonce over it with a fresh passkey signature', async () => {
    const { w, a, delay } = await queued();
    const q = await w.service.queue({ chainId: CHAIN_ID, account: a.account }, w.caller);
    expect(q).toMatchObject({ delay, txNonce: 0n, queueNonce: 1n, vetoNonce: 1n });
    expect(q.pending).toHaveLength(1);
    const op = safeOp(w, a.account, [{ to: delay, data: encodeVeto(q.vetoNonce!) }]);
    const r = await w.service.veto({ chainId: CHAIN_ID, account: a.account, kind: 'safe-operation', ...op, passkeySignature: sig(w, op.digest) }, w.caller);
    expect(await recoverAddress({ hash: op.digest, signature: r.coSignature })).toBe(SERVER);
    expect(decisions(w.journal).at(-1)).toMatchObject({ route: 'veto', decision: 'signed', flow: 'veto' });
  });

  it('refuses a veto with no passkey signature: there is no way for the server to veto alone', async () => {
    const { w, a, delay } = await queued();
    const op = safeOp(w, a.account, [{ to: delay, data: encodeVeto(1n) }]);
    await expectRefusal(w.service.veto({ chainId: CHAIN_ID, account: a.account, kind: 'safe-operation', ...op, passkeySignature: '0x' }, w.caller), 'passkey_required');
  });

  it('refuses a veto carrying the passkey\'s signature from another operation (an old approval replayed)', async () => {
    const { w, a, delay } = await queued();
    const old = safeOp(w, a.account, [deposit(1n)]);
    const oldSignature = sig(w, old.digest);
    const op = safeOp(w, a.account, [{ to: delay, data: encodeVeto(1n) }]);
    await expectRefusal(w.service.veto({ chainId: CHAIN_ID, account: a.account, kind: 'safe-operation', ...op, passkeySignature: oldSignature }, w.caller), 'bad_passkey_signature');
  });

  it('refuses setTxNonce on the co-sign route, a long veto window, and vetoes with nothing to skip', async () => {
    const { w, a, delay } = await queued();
    const onCosign = safeOp(w, a.account, [{ to: delay, data: encodeVeto(1n) }]);
    await expectRefusal(w.service.cosign({ chainId: CHAIN_ID, account: a.account, kind: 'safe-operation', ...onCosign, passkeySignature: sig(w, onCosign.digest) }, w.caller), 'use_veto_route');
    const long = safeOp(w, a.account, [{ to: delay, data: encodeVeto(1n) }], { validUntil: Number(w.chain.time) + 1000 });
    await expectRefusal(w.service.veto({ chainId: CHAIN_ID, account: a.account, kind: 'safe-operation', ...long, passkeySignature: sig(w, long.digest) }, w.caller), 'window_too_long');
    const beyond = safeOp(w, a.account, [{ to: delay, data: encodeVeto(2n) }], { nonce: 0n });
    await expectRefusal(w.service.veto({ chainId: CHAIN_ID, account: a.account, kind: 'safe-operation', ...beyond, passkeySignature: sig(w, beyond.digest) }, w.caller), 'veto_out_of_range');
    const spend = safeOp(w, a.account, [deposit(1n)]);
    await expectRefusal(w.service.veto({ chainId: CHAIN_ID, account: a.account, kind: 'safe-operation', ...spend, passkeySignature: sig(w, spend.digest) }, w.caller), 'not_a_veto');
    w.chain.delays.get(k(delay))!.txNonce = 1n;
    const empty = safeOp(w, a.account, [{ to: delay, data: encodeVeto(1n) }]);
    await expectRefusal(w.service.veto({ chainId: CHAIN_ID, account: a.account, kind: 'safe-operation', ...empty, passkeySignature: sig(w, empty.digest) }, w.caller), 'nothing_to_veto');
  });
});

describe('the audit log', () => {
  it('records who, what hash and the decision - never a passkey signature or key material - and a restart remembers', async () => {
    const journal = new MemoryJournal<AuditRecord>();
    const w = world({ journal });
    const a = await safeAccount(w, { deployed: true });
    const op = safeOp(w, a.account, [deposit(1n)]);
    const passkeySignature = sig(w, op.digest);
    const first = await w.service.cosign({ chainId: CHAIN_ID, account: a.account, kind: 'safe-operation', ...op, passkeySignature, requestId: 'r-1' }, w.caller);
    const stranger = safeOp(w, a.account, [{ to: STRANGER, data: '0x' }], { nonce: 1n });
    await expectRefusal(w.service.cosign({ chainId: CHAIN_ID, account: a.account, kind: 'safe-operation', ...stranger, passkeySignature: sig(w, stranger.digest) }, w.caller), 'target_not_allowed');
    const lines = journal.lines.join('\n');
    expect(lines).not.toContain(passkeySignature.slice(2));
    expect(lines).not.toContain(SERVER_KEY.slice(2));
    expect(lines).not.toContain(first.coSignature.slice(2));
    expect(decisions(journal).map((d) => [d.decision, d.code ?? null, d.client, d.digest])).toEqual([
      ['signed', null, 'test', op.digest], ['refused', 'target_not_allowed', 'test', stranger.digest],
    ]);
    const restarted = world({ journal, chain: w.chain, clock: w.clock, passkey: w.passkey });
    expect(restarted.audit.enrolment(CHAIN_ID, a.account)?.passkeySigner).toBe(a.passkeySigner);
    const again = await restarted.service.cosign({ chainId: CHAIN_ID, account: a.account, kind: 'safe-operation', ...op, passkeySignature: sig(w, op.digest) }, w.caller);
    expect(again).toMatchObject({ reused: true, coSignature: first.coSignature });
  });
});
