import { afterEach, describe, expect, it } from 'vitest';
import { decodeAbiParameters, hexToBytes, recoverAddress, slice, type Address, type Hex } from 'viem';
import { privateKeyToAccount } from 'viem/accounts';
import {
  PASSKEY, decodeKernelUserOpSignature, decodePasskeyCoSignerSignature, encodeSafeSignatures, encodeVeto, passkeyCoSignerSigner,
  type PackedUserOperation,
} from '@mova/smart-account';
import { INSTRUCTIONS_TYPES, KernelExecutor, SafeExecutor, instructionsDomain, localSafeOwner, passkeySafeOwner } from '@mova/wallet';
import { Point, verify } from '@mova/mpc';
import {
  CoSignerRefused, RemoteCoSigner, kernelOperationDigest, safeOperationDigest, serveCoSigner, verifyWebAuthnSignature,
} from '../src/index.js';
import {
  CHAIN_ID, ESCROW, OTHER, PASSKEY_VALIDATOR, SERVER, SERVER_KEY, STRANGER, VAULT, approve, deposit, dkg, enrolmentProof, kernelAccount,
  safeAccount, world, type World,
} from './harness.js';

const TOKEN = 'wallet-client-token-0123456789abcdefghij';
const closers: (() => Promise<void>)[] = [];
afterEach(async () => { while (closers.length) await closers.pop()!(); });

class Captured extends Error {
  constructor(readonly op: PackedUserOperation) { super('captured'); }
}
const capture = { submit: async (op: PackedUserOperation): Promise<never> => { throw new Captured(op); } };
async function submitted(p: Promise<unknown>): Promise<PackedUserOperation> {
  try {
    await p;
  } catch (e) {
    if (e instanceof Captured) return e.op;
    throw e;
  }
  throw new Error('nothing was submitted');
}

async function serve(w: World) {
  const s = serveCoSigner(w.service, { mode: 'api', apiKeys: [{ name: 'wallet', token: TOKEN }] });
  const port = await s.listen(0);
  closers.push(s.close);
  return new RemoteCoSigner({ url: `http://127.0.0.1:${port}`, chainId: CHAIN_ID, apiKey: TOKEN });
}

const publicClient = (w: World) => ({
  readContract: async () => 0n,
  getBlock: async () => ({ timestamp: w.chain.time, baseFeePerGas: 1_000_000_000n, number: w.chain.block }),
  // The executors ask the node for the priority fee (wallet fees.ts, SRM1-5).
  request: async ({ method }: { method: string }) => {
    if (method === 'eth_maxPriorityFeePerGas') return '0xf4240';
    throw new Error(`${method} is not available`);
  },
  getCode: async ({ address }: { address: Address }) => (w.chain.code.has(address.toLowerCase()) ? '0x01' as Hex : undefined),
}) as never;

const unsigned = ({ signature: _s, ...op }: PackedUserOperation) => op;

describe('RemoteCoSigner in place of the local server key', () => {
  it('Safe: the submitted signature is what a local server key would have produced', async () => {
    const w = world();
    const a = await safeAccount(w, { deployed: true });
    const remote = await serve(w);
    const info = await remote.info();
    expect(info.coSigner).toBe(SERVER);
    const cs = remote.safe({ safe: a.account, passkeySigner: a.passkeySigner, coSigner: info.coSigner });
    const executor = cs.wrap(new SafeExecutor({
      safe: a.account, chainId: CHAIN_ID, publicClient: publicClient(w), submitter: cs.submitter(capture),
      owners: [passkeySafeOwner(a.passkeySigner, (c) => w.passkey.sign(c)), cs.owner],
    }));
    const op = await submitted(executor.execute([approve(VAULT, 10n), deposit(10n)]));
    const validUntil = Number(BigInt(slice(op.signature, 6, 12)));
    const digest = safeOperationDigest(unsigned(op), { validAfter: 0, validUntil }, CHAIN_ID);
    const { splitSafeSignature } = await import('../src/operation.js');
    const passkeyHalf = splitSafeSignature(op.signature).entries.find((e) => e.kind === 'contract')!.signature;
    const local = await localSafeOwner(privateKeyToAccount(SERVER_KEY)).signHash(digest);
    expect(op.signature).toBe(encodeSafeSignatures(0, validUntil, [
      { owner: a.passkeySigner, kind: 'contract', signature: passkeyHalf }, { owner: SERVER, kind: 'eoa', signature: local },
    ]));
    expect(verifyWebAuthnSignature(digest, passkeyHalf, w.pk).ok).toBe(true);

    // ERC-1271 through the wrapped executor.
    const typedData = { domain: instructionsDomain(CHAIN_ID, ESCROW), types: INSTRUCTIONS_TYPES, primaryType: 'PaymentInstructionsRequest' as const, message: { orderId: `0x${'02'.repeat(32)}` as Hex, issuedAt: 7n } };
    const signature = await executor.signTypedData(typedData);
    const { safeMessageHash } = await import('@mova/wallet');
    const { hashTypedData } = await import('viem');
    const messageDigest = safeMessageHash(a.account, CHAIN_ID, hashTypedData(typedData));
    const entries = splitSafeSignature(signature, 0).entries;
    expect(await recoverAddress({ hash: messageDigest, signature: entries.find((e) => e.kind === 'eoa')!.signature })).toBe(SERVER);
  });

  it('Kernel: the co-signer callback and the submitter, including an ERC-6492 signature before deployment', async () => {
    const w = world();
    const a = await kernelAccount(w);
    const remote = await serve(w);
    const cs = remote.kernel({ account: a.account, validator: PASSKEY_VALIDATOR, coSigner: SERVER });
    const executor = cs.wrap(new KernelExecutor({
      account: a.account, chainId: CHAIN_ID, publicClient: publicClient(w), submitter: cs.submitter(capture),
      deploy: { initData: a.initData, salt: a.salt }, signer: passkeyCoSignerSigner({ validator: PASSKEY_VALIDATOR, passkey: (c) => w.passkey.sign(c), coSigner: cs.coSign }),
    }));
    const op = await submitted(executor.execute([approve(VAULT, 1n), deposit(1n)]));
    const { validUntil, body } = decodeKernelUserOpSignature(op.signature);
    const challenge = kernelOperationDigest(unsigned(op), { validAfter: 0, validUntil }, CHAIN_ID, PASSKEY_VALIDATOR);
    const parts = decodePasskeyCoSignerSignature(body);
    expect(await recoverAddress({ hash: challenge, signature: parts.coSignerSignature })).toBe(SERVER);

    const typedData = { domain: instructionsDomain(CHAIN_ID, ESCROW), types: INSTRUCTIONS_TYPES, primaryType: 'PaymentInstructionsRequest' as const, message: { orderId: `0x${'03'.repeat(32)}` as Hex, issuedAt: 9n } };
    const signature = await executor.signTypedData(typedData);
    const { isErc6492Signature, parseErc6492Signature, hashTypedData } = await import('viem');
    expect(isErc6492Signature(signature)).toBe(true);
    const inner = parseErc6492Signature(signature).signature;
    const { kernelWrappedHash } = await import('@mova/smart-account');
    const { coSignerSignature } = decodePasskeyCoSignerSignature(slice(inner, 1));
    expect(await recoverAddress({ hash: kernelWrappedHash(a.account, CHAIN_ID, hashTypedData(typedData)), signature: coSignerSignature })).toBe(SERVER);
  });

  it('routes an operation that is exactly one setTxNonce to the veto route, and surfaces refusals by code', async () => {
    const w = world();
    const a = await safeAccount(w, { deployed: true });
    const delay = w.chain.installDelay(a.account, a.passkeySigner);
    w.chain.queue(delay, { to: STRANGER, value: 0n, data: '0x' });
    const remote = await serve(w);
    const queue = await remote.queue(a.account);
    expect(queue.vetoNonce).toBe(1n);
    const cs = remote.safe({ safe: a.account, passkeySigner: a.passkeySigner, coSigner: SERVER });
    const executor = new SafeExecutor({
      safe: a.account, chainId: CHAIN_ID, publicClient: publicClient(w), submitter: cs.submitter(capture),
      owners: [passkeySafeOwner(a.passkeySigner, (c) => w.passkey.sign(c)), cs.owner],
    });
    await submitted(executor.execute([{ to: delay, data: encodeVeto(queue.vetoNonce!) }]));
    const last = w.journal.load().at(-1);
    expect(last).toMatchObject({ t: 'decision', route: 'veto', decision: 'signed' });
    const err = await executor.execute([{ to: STRANGER, data: '0x' }]).catch((e) => e);
    expect(err).toBeInstanceOf(CoSignerRefused);
    expect(err).toMatchObject({ code: 'target_not_allowed', status: 403 });
  });

  it('refuses an answer that is not the pinned co-signer\'s, and a client without a key', async () => {
    const w = world();
    const a = await safeAccount(w, { deployed: true });
    const remote = await serve(w);
    const wrong = remote.safe({ safe: a.account, passkeySigner: a.passkeySigner, coSigner: OTHER });
    const executor = new SafeExecutor({
      safe: a.account, chainId: CHAIN_ID, publicClient: publicClient(w), submitter: wrong.submitter(capture),
      owners: [passkeySafeOwner(a.passkeySigner, (c) => w.passkey.sign(c)), wrong.owner],
    });
    await expect(executor.execute([deposit(1n)])).rejects.toThrow(/not from/);
    const anonymous = new RemoteCoSigner({ url: (remote as unknown as { o: { url: string } }).o.url, chainId: CHAIN_ID });
    await expect(anonymous.info()).rejects.toMatchObject({ code: 'unauthorized' });
  });

  it('FROST Safe: the device runs its half of the session at submit time and the aggregate verifies', async () => {
    const [device, server] = dkg('client frost');
    const w = world({ frostShares: [server] });
    const account = `0x${'5f'.repeat(20)}` as Address;
    const frostSigner = `0x${'f5'.repeat(20)}` as Address;
    const g = device.groupPublicKey.toAffine();
    w.chain.code.add(account.toLowerCase());
    w.chain.code.add(frostSigner.toLowerCase());
    w.chain.safes.set(account.toLowerCase(), { owners: [frostSigner], threshold: 1n, modules: [] });
    w.chain.frostSigners.set(frostSigner.toLowerCase(), { x: g.x, y: g.y });
    const delay = w.chain.installDelay(account, w.chain.deploySigner(w.pk));
    await w.service.enrol({ chainId: CHAIN_ID, account, type: 'safe', ...enrolmentProof(w, account) }, w.caller);
    const remote = await serve(w);
    let prompts = 0;
    const fs = remote.frostSafe({ safe: account, frostSigner, device, passkey: (c) => { prompts++; return w.passkey.sign(c); } });
    const executor = new SafeExecutor({ safe: account, chainId: CHAIN_ID, publicClient: publicClient(w), submitter: fs.submitter(capture), owners: [fs.owner] });
    const { splitSafeSignature } = await import('../src/operation.js');
    const verifies = (op: PackedUserOperation) => {
      const validUntil = Number(BigInt(slice(op.signature, 6, 12)));
      const digest = safeOperationDigest(unsigned(op), { validAfter: 0, validUntil }, CHAIN_ID);
      const frostBytes = splitSafeSignature(op.signature).entries[0]!.signature;
      const [rx, ry, z] = decodeAbiParameters([{ type: 'uint256' }, { type: 'uint256' }, { type: 'uint256' }], frostBytes);
      return verify({ R: Point.fromAffine({ x: rx, y: ry }), z }, hexToBytes(digest), device.groupPublicKey);
    };
    expect(verifies(await submitted(executor.execute([deposit(1n)])))).toBe(true);
    // One user verification covers both rounds: the commit carries the same assertion as the sign.
    expect(prompts).toBe(1);

    // The veto runs the same way, on the veto route, into the account's reserved slot.
    w.chain.queue(delay, { to: STRANGER, value: 0n, data: '0x' });
    expect(verifies(await submitted(executor.execute([{ to: delay, data: encodeVeto(1n) }])))).toBe(true);
    expect(prompts).toBe(2);

    // Round one without an operation and an assertion is refused before any session exists.
    const url = (remote as unknown as { o: { url: string } }).o.url;
    const bare = await fetch(`${url}/v1/frost/commit`, {
      method: 'POST', headers: { authorization: `Bearer ${TOKEN}`, 'content-type': 'application/json' }, body: JSON.stringify({ chainId: CHAIN_ID, account }),
    });
    expect(bare.status).toBe(400);
    expect(w.service.status().frostSessionsOpen).toBe(0);
    void PASSKEY;
  });
});
