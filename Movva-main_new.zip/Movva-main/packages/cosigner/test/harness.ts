/**
 * A world to attack the co-signer in: an in-memory chain standing in for the accounts' on-chain state (Safe
 * owners, passkey signers, Kernel validators, the recovery Delay and its queue, EntryPoint nonces), a real
 * software passkey (P-256 over the real WebAuthn payload), the real service over an in-memory audit log, and
 * helpers that build operations exactly as the wallet's executors do.
 */
import {
  encodeAbiParameters, encodeFunctionData, getAddress, hexToBytes, keccak256, pad, parseAbi, toHex,
  type Address, type Hex,
} from 'viem';
import { privateKeyToAccount } from 'viem/accounts';
import { MemoryJournal } from '@mova/lp-node/src/journal.js';
import {
  DEFAULT_RECOVERY, PASSKEY, PasskeyAuthenticator, encodeKernelExecute, encodeWebAuthnSignature, kernelInitData,
  packTwo, passkeyCoSignerInstallData, predictDelayAddress, predictKernelAddress, safeInitCode,
} from '@mova/smart-account';
import { SafeExecutor, type Call } from '@mova/wallet/src/executor.js';
import { dkgContext, dkgFinalize, dkgRound1, dkgRound2, type KeyShare } from '@mova/mpc';
import {
  AuditLog, CoSignerMetrics, CoSignerService, enrolmentChallenge, kernelOperationDigest, localKey, memoryFrostShares, policyOf,
  safeOperationDigest, type CoSignerServiceOptions,
  type AccountReader, type AuditRecord, type DelayQueue, type DelayView, type GroupKey, type PasskeyConfig, type Policy,
  type QueuedTransaction, type UnsignedUserOp, type ValidityWindow,
} from '../src/index.js';

// anvil's well-known development keys: never funded anywhere that matters.
export const SERVER_KEY: Hex = '0x7c852118294e51e653712a81e05800f419141751be58f605c371e15141b007a6';
export const OTHER_KEY: Hex = '0x47e179ec197488593b187f80a00eb0da91f1b9d0b13f8733639f19c30a34926a';
export const SERVER = privateKeyToAccount(SERVER_KEY).address;
export const OTHER = privateKeyToAccount(OTHER_KEY).address;
export const CHAIN_ID = 31337;
export const T0 = 1_800_000_000n;

const fixed = (b: string) => getAddress(`0x${b.repeat(20)}`);
export const VAULT = fixed('a1');
export const ESCROW = fixed('e5');
export const TOKEN = fixed('70');
export const STRANGER = fixed('5a');
export const PASSKEY_VALIDATOR = fixed('c0');
export const FROST_VALIDATOR = fixed('f0');
export const ADAPTER = fixed('ad');
export const FCL_VERIFIERS = BigInt(PASSKEY.verifierFCL);

export const TOKEN_ABI = parseAbi([
  'function approve(address spender, uint256 amount)', 'function transfer(address to, uint256 amount)',
  'function transferOwnership(address newOwner)',
]);
export const VAULT_ABI = parseAbi(['function deposit(address token, uint256 amount)', 'function exit(address token)']);
export const SAFE_ADMIN_ABI = parseAbi([
  'function addOwnerWithThreshold(address owner, uint256 threshold)', 'function enableModule(address module)',
  'function swapOwner(address prevOwner, address oldOwner, address newOwner)', 'function changeThreshold(uint256 threshold)',
  'function setFallbackHandler(address handler)',
]);

export const approve = (spender: Address, amount: bigint): Call => ({ to: TOKEN, data: encodeFunctionData({ abi: TOKEN_ABI, functionName: 'approve', args: [spender, amount] }) });
export const deposit = (amount: bigint): Call => ({ to: VAULT, data: encodeFunctionData({ abi: VAULT_ABI, functionName: 'deposit', args: [TOKEN, amount] }) });

export const fakeSignerAddress = (pk: PasskeyConfig): Address =>
  getAddress(`0x${keccak256(encodeAbiParameters([{ type: 'uint256' }, { type: 'uint256' }, { type: 'uint176' }], [pk.x, pk.y, pk.verifiers])).slice(-40)}`);
export const fakeSafeAddress = (owners: readonly Address[], threshold: number, saltNonce: bigint): Address =>
  getAddress(`0x${keccak256(encodeAbiParameters([{ type: 'address[]' }, { type: 'uint256' }, { type: 'uint256' }], [owners.map((o) => getAddress(o)), BigInt(threshold), saltNonce])).slice(-40)}`);

const k = (a: string) => a.toLowerCase();

export class FakeChain implements AccountReader {
  time = T0;
  block = 1000n;
  readonly code = new Set<string>();
  readonly safes = new Map<string, { owners: Address[]; threshold: bigint; modules: Address[] }>();
  readonly signers = new Map<string, PasskeyConfig>();
  readonly frostSigners = new Map<string, GroupKey>();
  readonly kernelRoots = new Map<string, Address>();
  readonly passkeyConfigs = new Map<string, PasskeyConfig & { coSigner: Address }>();
  readonly frostKeys = new Map<string, GroupKey>();
  readonly adapterDelays = new Map<string, Address>();
  readonly nonces = new Map<string, bigint>();
  readonly delays = new Map<string, DelayView>();
  readonly queued = new Map<string, QueuedTransaction[]>();

  async head() { return { number: this.block, timestamp: this.time }; }
  async hasCode(a: Address) { return this.code.has(k(a)); }
  async safeOwners(safe: Address) {
    const s = this.safes.get(k(safe));
    if (!s) throw new Error('not a Safe');
    return { owners: s.owners, threshold: s.threshold };
  }
  async safeModules(safe: Address) { return this.safes.get(k(safe))?.modules ?? []; }
  async webAuthnSignerConfig(signer: Address) { return this.signers.get(k(signer)); }
  async webAuthnSignerAddress(pk: PasskeyConfig) { return fakeSignerAddress(pk); }
  async frostSignerKey(signer: Address) { return this.frostSigners.get(k(signer)); }
  async kernelRootValidator(account: Address) { return this.kernelRoots.get(k(account)); }
  async passkeyCoSignerConfig(validator: Address, account: Address) { return this.passkeyConfigs.get(`${k(validator)}:${k(account)}`); }
  async frostValidatorKey(validator: Address, account: Address) { return this.frostKeys.get(`${k(validator)}:${k(account)}`); }
  async kernelAdapterDelay(adapter: Address, account: Address) { return this.adapterDelays.get(`${k(adapter)}:${k(account)}`); }
  async entryPointNonce(account: Address) { return this.nonces.get(k(account)) ?? 0n; }
  async delay(address: Address) { return this.delays.get(k(address)); }
  async delayQueue(delay: Address, _fromBlock: bigint): Promise<DelayQueue> {
    const v = this.delays.get(k(delay));
    if (!v) throw new Error('no delay');
    return { delay, txNonce: v.txNonce, queueNonce: v.queueNonce, cooldown: v.cooldown, expiration: v.expiration, pending: this.queued.get(k(delay)) ?? [] };
  }
  async predictSafe(owners: Address[], threshold: number, saltNonce: bigint) { return fakeSafeAddress(owners, threshold, saltNonce); }

  deploySigner(pk: PasskeyConfig): Address {
    const a = fakeSignerAddress(pk);
    this.code.add(k(a));
    this.signers.set(k(a), pk);
    return a;
  }

  /** Recovery installed: a Delay owned by the account whose only module is the passkey signer. */
  installDelay(account: Address, passkeySigner: Address): Address {
    const delay = predictDelayAddress(account, DEFAULT_RECOVERY);
    this.code.add(k(delay));
    this.delays.set(k(delay), {
      address: delay, owner: account, avatar: account, txNonce: 0n, queueNonce: 0n, cooldown: BigInt(DEFAULT_RECOVERY.cooldownSeconds),
      expiration: BigInt(DEFAULT_RECOVERY.expirationSeconds), modules: [passkeySigner],
    });
    return delay;
  }

  /** A stolen passkey queued something. */
  queue(delay: Address, call: { to: Address; value: bigint; data: Hex }): bigint {
    const v = this.delays.get(k(delay))!;
    const nonce = v.queueNonce;
    v.queueNonce += 1n;
    const list = this.queued.get(k(delay)) ?? [];
    list.push({ nonce, txHash: keccak256(call.data), createdAt: this.time, executableAt: this.time + v.cooldown, expiresAt: this.time + v.cooldown + v.expiration, call: { ...call, operation: 0 } });
    this.queued.set(k(delay), list);
    return nonce;
  }
}

export interface Clock { now: bigint; ms: number }

export interface World {
  chain: FakeChain;
  journal: MemoryJournal<AuditRecord>;
  audit: AuditLog;
  service: CoSignerService;
  clock: Clock;
  passkey: PasskeyAuthenticator;
  pk: PasskeyConfig;
  policy: Policy;
  caller: { client: string };
  metrics: CoSignerMetrics;
}

/** What `world`'s `extra` gets to build optional modules (sponsorship, alerts) on the same chain, log and clock. */
export interface WorldParts {
  chain: FakeChain;
  audit: AuditLog;
  clock: Clock;
  metrics: CoSignerMetrics;
  policy: Policy;
}

export const DEFAULT_TEST_POLICY = (): Policy => policyOf({
  targets: [{ address: VAULT, label: 'TestVault' }, { address: ESCROW, label: 'FiatEscrow' }],
  tokens: [{ address: TOKEN, label: 'tBRL', transfer: false, dailyLimit: 1000n * 10n ** 18n }],
  rotationCoSigners: [OTHER],
  rateLimit: { burst: 50, perMinute: 60 },
});

export function world(o: {
  policy?: Policy; frostShares?: KeyShare[]; journal?: MemoryJournal<AuditRecord>; chain?: FakeChain; clock?: Clock; passkey?: PasskeyAuthenticator;
  extra?: (parts: WorldParts) => Partial<CoSignerServiceOptions>;
} = {}): World {
  const chain = o.chain ?? new FakeChain();
  const clock = o.clock ?? { now: T0, ms: Number(T0) * 1000 };
  const journal = o.journal ?? new MemoryJournal<AuditRecord>();
  const audit = new AuditLog(journal, { now: () => clock.now });
  audit.load();
  const policy = o.policy ?? DEFAULT_TEST_POLICY();
  const metrics = new CoSignerMetrics();
  const service = new CoSignerService({
    chainId: CHAIN_ID, key: localKey(SERVER_KEY), chain, policy, audit,
    deployment: { entryPoint: '0x0000000071727De22E5E9d8BAf0edAc6f37da032', passkeyValidator: PASSKEY_VALIDATOR, frostValidator: FROST_VALIDATOR, kernelAdapter: ADAPTER },
    frostShares: o.frostShares ? memoryFrostShares(o.frostShares) : undefined,
    now: () => clock.now, nowMs: () => clock.ms, bindingCacheMs: 0, metrics,
    ...o.extra?.({ chain, audit, clock, metrics, policy }),
  });
  service.ready = true;
  const passkey = o.passkey ?? PasskeyAuthenticator.create('wallet.brl.example');
  const pub = passkey.publicKey();
  return { chain, journal, audit, service, clock, passkey, pk: { x: pub.x, y: pub.y, verifiers: FCL_VERIFIERS }, policy, caller: { client: 'test' }, metrics };
}

export const sig = (w: Pick<World, 'passkey'>, digest: Hex): Hex => encodeWebAuthnSignature(w.passkey.sign(hexToBytes(digest)));

export function enrolmentProof(w: World, account: Address, issuedAt = Number(w.clock.now)) {
  return { issuedAt, passkeySignature: sig(w, enrolmentChallenge(CHAIN_ID, account, SERVER, issuedAt)) };
}

/** A 2-of-2 Safe (passkey signer + SERVER), counterfactual unless deployed. Enrolled. */
export async function safeAccount(w: World, o: { deployed?: boolean; saltNonce?: bigint } = {}) {
  const passkeySigner = w.chain.deploySigner(w.pk);
  const owners = [passkeySigner, SERVER];
  const saltNonce = o.saltNonce ?? 7n;
  const account = fakeSafeAddress(owners, 2, saltNonce);
  if (o.deployed) {
    w.chain.code.add(k(account));
    w.chain.safes.set(k(account), { owners, threshold: 2n, modules: [] });
  }
  const r = await w.service.enrol({ chainId: CHAIN_ID, account, type: 'safe', passkey: w.pk, safe: { owners, threshold: 2, saltNonce }, ...enrolmentProof(w, account) }, w.caller);
  return { account, passkeySigner, owners, saltNonce, enrolment: r.enrolment, delay: r.enrolment.delay };
}

/** A Kernel account with PasskeyCoSignerValidator (passkey + SERVER), counterfactual unless deployed. Enrolled. */
export async function kernelAccount(w: World, o: { deployed?: boolean; salt?: bigint } = {}) {
  const initData = kernelInitData({ rootValidator: PASSKEY_VALIDATOR, validatorData: passkeyCoSignerInstallData({ passkey: w.pk, coSigner: SERVER }) });
  const salt = pad(toHex(o.salt ?? 1n), { size: 32 });
  const account = predictKernelAddress({ initData, salt });
  if (o.deployed) {
    w.chain.code.add(k(account));
    w.chain.kernelRoots.set(k(account), PASSKEY_VALIDATOR);
    w.chain.passkeyConfigs.set(`${k(PASSKEY_VALIDATOR)}:${k(account)}`, { ...w.pk, coSigner: SERVER });
  }
  const r = await w.service.enrol({ chainId: CHAIN_ID, account, type: 'kernel', kernel: { initData, salt }, ...enrolmentProof(w, account) }, w.caller);
  return { account, initData, salt, enrolment: r.enrolment, delay: r.enrolment.delay, sponsorship: r.sponsorship };
}

const GAS = { accountGasLimits: packTwo(600_000n, 1_500_000n), preVerificationGas: 120_000n, gasFees: packTwo(1_000_000_000n, 3_000_000_000n), paymasterAndData: '0x' as Hex };

export function safeOp(w: World, account: Address, calls: readonly Call[], o: { nonce?: bigint; initCode?: Hex; validAfter?: number; validUntil?: number } = {}) {
  const userOp: UnsignedUserOp = { sender: account, nonce: o.nonce ?? 0n, initCode: o.initCode ?? '0x', callData: SafeExecutor.callData(calls), ...GAS };
  const window: ValidityWindow = { validAfter: o.validAfter ?? 0, validUntil: o.validUntil ?? Number(w.chain.time) + 900 };
  return { userOp, window, digest: safeOperationDigest(userOp, window, CHAIN_ID) };
}

export function kernelOp(w: World, account: Address, calls: readonly Call[], o: { nonce?: bigint; initCode?: Hex; validUntil?: number; validator?: Address } = {}) {
  const userOp: UnsignedUserOp = { sender: account, nonce: o.nonce ?? 0n, initCode: o.initCode ?? '0x', callData: encodeKernelExecute(calls), ...GAS };
  const window: ValidityWindow = { validAfter: 0, validUntil: o.validUntil ?? Number(w.chain.time) + 900 };
  return { userOp, window, digest: kernelOperationDigest(userOp, window, CHAIN_ID, o.validator ?? PASSKEY_VALIDATOR) };
}

/** A counterfactual Safe's first operation deploys it: a stand-in initCode (the service only needs it non-empty). */
export const safeFirstInitCode = (owners: Address[], saltNonce: bigint) => safeInitCode(owners, 2, saltNonce);

export function dkg(label: string): [KeyShare, KeyShare] {
  const params = { context: dkgContext(label), threshold: 2, participants: [1, 2] };
  const r1 = new Map(params.participants.map((id) => [id, dkgRound1(id, params)]));
  const broadcasts = [...r1.values()].map((r) => r.broadcast);
  const r2 = new Map(params.participants.map((id) => [id, dkgRound2(r1.get(id)!.state, broadcasts.filter((b) => b.from !== id))]));
  const messages = [...r2.values()].flatMap((r) => r.messages);
  const shares = params.participants.map((id) => dkgFinalize(r2.get(id)!.state, messages.filter((m) => m.to === id)).keyShare);
  return [shares[0]!, shares[1]!];
}

export async function expectRefusal(p: Promise<unknown>, code: string): Promise<void> {
  try {
    await p;
  } catch (e) {
    const got = (e as { code?: string }).code;
    if (got !== code) throw new Error(`expected refusal ${code}, got ${got ?? 'no code'}: ${(e as Error).message}`);
    return;
  }
  throw new Error(`expected refusal ${code}, but the request was accepted`);
}
