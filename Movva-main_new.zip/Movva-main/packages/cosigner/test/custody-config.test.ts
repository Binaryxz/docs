import { describe, expect, it } from 'vitest';
import { inspect } from 'node:util';
import { secp256k1 } from '@noble/curves/secp256k1';
import { hexToBytes, keccak256, recoverAddress, toHex, type Hex } from 'viem';
import { privateKeyToAccount } from 'viem/accounts';
import { publicShareOf } from '@mova/mpc';
import { KeyCustodyError, cosignerConfigFromEnv, fileFrostShares, fileKey, kmsKey, localKey } from '../src/index.js';
import { OTHER_KEY, SERVER, SERVER_KEY, VAULT, dkg } from './harness.js';

const digest = keccak256(toHex('digest'));
const N = secp256k1.Point.Fn.ORDER;

describe('key custody', () => {
  it('a file key refuses production mode unless explicitly allowed, and a file others can read', () => {
    const readFile = () => SERVER_KEY;
    expect(() => fileKey({ path: '/k', production: true, readFile, fileMode: () => 0o600 })).toThrow(KeyCustodyError);
    expect(() => fileKey({ path: '/k', production: false, readFile, fileMode: () => 0o644 })).toThrow(/group or others/);
    expect(fileKey({ path: '/k', production: true, allowInProduction: true, readFile, fileMode: () => 0o600 }).address).toBe(SERVER);
    expect(fileKey({ path: '/k', production: false, readFile: () => `${SERVER_KEY.slice(2)}\n`, fileMode: () => 0o400 }).address).toBe(SERVER);
  });

  it('never shows the key: not in JSON, not in inspect, not in an error about a bad key', () => {
    const key = localKey(SERVER_KEY);
    expect(JSON.stringify(key)).not.toContain(SERVER_KEY.slice(2));
    expect(inspect(key, { showHidden: true, depth: 5 })).not.toContain(SERVER_KEY.slice(2));
    const bad = `0x${'ff'.repeat(32)}`;
    try {
      fileKey({ path: '/k', production: false, readFile: () => bad, fileMode: () => 0o600 });
      expect.unreachable();
    } catch (e) {
      expect((e as Error).message).not.toContain('ff'.repeat(8));
    }
  });

  it('a KMS backend: DER or compact, high s normalised, v recovered, and a wrong signature refused', async () => {
    const priv = hexToBytes(OTHER_KEY);
    const pub = secp256k1.getPublicKey(priv, false);
    const spki = new Uint8Array([0x30, 0x56, 0x30, 0x10, 0x06, 0x07, 0x2a, 0x86, 0x48, 0xce, 0x3d, 0x02, 0x01, 0x06, 0x05, 0x2b, 0x81, 0x04, 0x00, 0x0a, 0x03, 0x42, 0x00, ...pub]);
    const high = (d: Uint8Array) => { const s = secp256k1.sign(d, priv, { prehash: false }); return new secp256k1.Signature(s.r, N - s.s); };
    const der = await kmsKey({ custody: 'kms:test', publicKey: async () => spki, sign: async (d) => high(d).toBytes('der') });
    expect(der.address).toBe(privateKeyToAccount(OTHER_KEY).address);
    const signature = await der.signDigest(digest);
    expect(BigInt(`0x${signature.slice(66, 130)}`) <= N / 2n).toBe(true);
    expect(await recoverAddress({ hash: digest, signature })).toBe(der.address);
    const compact = await kmsKey({ custody: 'kms:test', publicKey: async () => pub, sign: async (d) => secp256k1.sign(d, priv, { prehash: false }).toBytes('compact') });
    expect(await recoverAddress({ hash: digest, signature: await compact.signDigest(digest) })).toBe(compact.address);
    const lying = await kmsKey({ custody: 'kms:test', publicKey: async () => pub, sign: async (d) => secp256k1.sign(d, hexToBytes(SERVER_KEY), { prehash: false }).toBytes('compact') });
    await expect(lying.signDigest(digest)).rejects.toThrow(/does not verify/);
    await expect(compact.signDigest('0x1234')).rejects.toThrow(/32-byte/);
  });

  it('a FROST share file: refused in production, checked against its verification share', () => {
    const [, server] = dkg('share file');
    const entry = { id: server.id, share: toHex(server.share, { size: 32 }), groupPublicKey: toHex(server.groupPublicKey.toBytes(true)), verificationShare: toHex(publicShareOf(server).toBytes(true)) };
    const readFile = (e: object) => () => JSON.stringify([e]);
    expect(() => fileFrostShares({ path: '/s', production: true, readFile: readFile(entry), fileMode: () => 0o600 })).toThrow(KeyCustodyError);
    expect(fileFrostShares({ path: '/s', production: false, readFile: readFile(entry), fileMode: () => 0o600 }).shareFor(server.groupPublicKey)?.id).toBe(server.id);
    const wrong = { ...entry, share: toHex(server.share + 1n, { size: 32 }) };
    expect(() => fileFrostShares({ path: '/s', production: false, readFile: readFile(wrong), fileMode: () => 0o600 })).toThrow(/verification share/);
  });
});

describe('configuration', () => {
  const policy = JSON.stringify({ chainId: 31337, targets: [{ address: VAULT, label: 'TestVault' }], tokens: [], window: { maxSeconds: 900 } });
  const files: Record<string, string> = { '/policy.json': policy, '/keys': 'movva-web:abcdefghijklmnopqrstuvwxyz0123456789\n' };
  const readFile = (p: string) => { if (!(p in files)) throw new Error('ENOENT'); return files[p]!; };
  const base = { RPC_URL: 'http://127.0.0.1:8930', CHAIN_ID: '31337', COSIGNER_POLICY_FILE: '/policy.json', COSIGNER_AUDIT_LOG: '/data/audit.jsonl', COSIGNER_API_KEYS_FILE: '/keys' };

  it('parses a development configuration', () => {
    const cfg = cosignerConfigFromEnv({ ...base, COSIGNER_KEY_FILE: '/key' }, readFile);
    expect(cfg).toMatchObject({ production: false, key: { kind: 'file', path: '/key' }, port: 8495, opsPort: 9495, host: '127.0.0.1' });
    expect(cfg.policy.maxValiditySeconds).toBe(900);
    expect(cfg.apiKeys).toEqual([{ name: 'movva-web', token: 'abcdefghijklmnopqrstuvwxyz0123456789' }]);
    expect(cfg.secrets).toContain('abcdefghijklmnopqrstuvwxyz0123456789');
  });

  it('refuses a file key in production without the explicit flag, an inline key, and no API keys', () => {
    expect(() => cosignerConfigFromEnv({ ...base, NODE_ENV: 'production', COSIGNER_KEY_FILE: '/key' }, readFile)).toThrow(/production mode refuses it/);
    expect(cosignerConfigFromEnv({ ...base, NODE_ENV: 'production', COSIGNER_KEY_FILE: '/key', COSIGNER_ALLOW_FILE_KEY_IN_PRODUCTION: '1' }, readFile).production).toBe(true);
    expect(() => cosignerConfigFromEnv({ ...base, COSIGNER_KEY: SERVER_KEY, COSIGNER_KEY_FILE: '/key' }, readFile)).toThrow(/never put the co-signer key in the environment/);
    const { COSIGNER_API_KEYS_FILE: _k, ...noKeys } = base;
    expect(() => cosignerConfigFromEnv({ ...noKeys, COSIGNER_KEY_FILE: '/key' }, readFile)).toThrow(/COSIGNER_API_KEYS_FILE is required/);
    expect(cosignerConfigFromEnv({ ...noKeys, COSIGNER_KEY_FILE: '/key', COSIGNER_PUBLIC_API: '1' }, readFile).publicApi).toBe(true);
  });

  it('refuses a policy that is not short, not an allowlist, or for another chain - naming no values', () => {
    files['/long.json'] = JSON.stringify({ targets: [{ address: VAULT, label: 'v' }], window: { maxSeconds: 86_400 } });
    files['/empty.json'] = JSON.stringify({ targets: [] });
    files['/chain.json'] = JSON.stringify({ chainId: 1, targets: [{ address: VAULT, label: 'v' }] });
    expect(() => cosignerConfigFromEnv({ ...base, COSIGNER_KEY_FILE: '/key', COSIGNER_POLICY_FILE: '/long.json' }, readFile)).toThrow(/window.maxSeconds/);
    expect(() => cosignerConfigFromEnv({ ...base, COSIGNER_KEY_FILE: '/key', COSIGNER_POLICY_FILE: '/empty.json' }, readFile)).toThrow(/co-signs nothing/);
    expect(() => cosignerConfigFromEnv({ ...base, COSIGNER_KEY_FILE: '/key', COSIGNER_POLICY_FILE: '/chain.json' }, readFile)).toThrow(/does not match CHAIN_ID/);
    try {
      cosignerConfigFromEnv({ ...base, RPC_URL: 'ftp://secret-host/key', COSIGNER_KEY_FILE: '/key' }, readFile);
    } catch (e) {
      expect((e as Error).message).not.toContain('secret-host');
    }
  });
});
