import { afterEach, describe, expect, it } from 'vitest';
import { createECDH } from 'node:crypto';
import { keccak256, toHex, type Address } from 'viem';
import { MemoryJournal } from '@mova/lp-node/src/journal.js';
import {
  AlertStore, RecoveryAlerts, RecoveryWatcher, RemoteCoSigner, alertsSubscribeChallenge, alertsUnsubscribeChallenge, decryptPushPayload, dueAlert,
  generateVapidKeys, handleRecoveryNotificationClick, handleRecoveryPush, serveCoSigner, subscribeRecoveryAlerts, unsubscribeRecoveryAlerts,
  type AlertRecord, type AlertStateRecord, type AuditRecord, type DelayLogSource, type DelayState, type PushOutcome, type PushTarget,
  type QueuedRecoveryItem, type TransactionAddedLog,
} from '../src/index.js';
import { CHAIN_ID, SERVER, T0, TOKEN, expectRefusal, safeAccount, sig, world, type World } from './harness.js';

const DAY = 86_400n;
const HOUR = 3_600n;
const VAPID = generateVapidKeys();
const closers: (() => Promise<void>)[] = [];
afterEach(async () => { while (closers.length) await closers.pop()!(); });

/** A browser's push subscription, with what it needs to decrypt. */
function device(endpoint = `https://fcm.googleapis.com/fcm/send/${Math.random().toString(36).slice(2)}`) {
  const ecdh = createECDH('prime256v1');
  ecdh.generateKeys();
  const auth = crypto.getRandomValues(new Uint8Array(16));
  return { endpoint, keys: { p256dh: ecdh.getPublicKey('base64url'), auth: Buffer.from(auth).toString('base64url') }, privateKey: ecdh.getPrivateKey(), auth };
}
type Device = ReturnType<typeof device>;

interface AlertsWorld {
  w: World;
  store: AlertStore;
  state: MemoryJournal<AlertStateRecord>;
  alerts: RecoveryAlerts;
  sent: { target: PushTarget; payload: string }[];
}

function alertsWorld(o: { base?: World; state?: MemoryJournal<AlertStateRecord>; outcome?: (t: PushTarget) => PushOutcome; maxPerAccount?: number } = {}): AlertsWorld {
  const state = o.state ?? new MemoryJournal<AlertStateRecord>();
  const store = new AlertStore(state, { maxPerAccount: o.maxPerAccount });
  store.load();
  const sent: AlertsWorld['sent'] = [];
  let alerts!: RecoveryAlerts;
  const w = world({
    ...(o.base ? { journal: o.base.journal, chain: o.base.chain, clock: o.base.clock, passkey: o.base.passkey } : {}),
    extra: ({ chain, audit, clock, metrics, policy }) => {
      alerts = new RecoveryAlerts({
        chainId: CHAIN_ID, coSigner: SERVER, audit, store, chain, webauthn: policy.webauthn, vapid: VAPID, subject: 'mailto:ops@movva.app',
        now: () => clock.now, nowMs: () => clock.ms, metrics, rateLimit: { burst: 50, perMinute: 60 },
        send: async (target, payload) => { sent.push({ target, payload }); return o.outcome?.(target) ?? { ok: true, status: 201 }; },
      });
      return { alerts };
    },
  });
  return { w, store, state, alerts, sent };
}

function subscribeRequest(w: World, account: Address, d: Device, o: { issuedAt?: number; signedFor?: Device } = {}) {
  const issuedAt = o.issuedAt ?? Number(w.clock.now);
  const subscription = { endpoint: d.endpoint, keys: d.keys };
  const signed = o.signedFor ? { endpoint: o.signedFor.endpoint, keys: o.signedFor.keys } : subscription;
  return { chainId: CHAIN_ID, account, subscription, issuedAt, passkeySignature: sig(w, alertsSubscribeChallenge(CHAIN_ID, account, SERVER, issuedAt, signed)) };
}

function unsubscribeRequest(w: World, account: Address, endpoint: string) {
  const issuedAt = Number(w.clock.now);
  return { chainId: CHAIN_ID, account, endpoint, issuedAt, passkeySignature: sig(w, alertsUnsubscribeChallenge(CHAIN_ID, account, SERVER, issuedAt, endpoint)) };
}

const alertRecords = (w: World) => w.journal.load().filter((r): r is AlertRecord => r.t === 'alert');

describe('subscribing to recovery alerts', () => {
  it('needs a fresh, unused passkey assertion over exactly this subscription, for an enrolled account on a known push service', async () => {
    const x = alertsWorld();
    const a = await safeAccount(x.w, { deployed: true });
    const d = device();
    expect(await x.w.service.subscribeAlerts(subscribeRequest(x.w, a.account, d), x.w.caller)).toEqual({ subscribed: true, created: true, pending: 0 });
    expect(x.store.subscriptions(CHAIN_ID, a.account)).toHaveLength(1);

    const other = device();
    await expectRefusal(x.w.service.subscribeAlerts(subscribeRequest(x.w, a.account, other, { signedFor: device() }), x.w.caller), 'bad_passkey_signature');
    await expectRefusal(x.w.service.subscribeAlerts({ ...subscribeRequest(x.w, a.account, other), passkeySignature: '0x' }, x.w.caller), 'passkey_required');
    await expectRefusal(x.w.service.subscribeAlerts(subscribeRequest(x.w, a.account, other, { issuedAt: Number(x.w.clock.now) - 3600 }), x.w.caller), 'proof_expired');
    const once = subscribeRequest(x.w, a.account, other);
    await x.w.service.subscribeAlerts(once, x.w.caller);
    await expectRefusal(x.w.service.subscribeAlerts(once, x.w.caller), 'replayed');
    await expectRefusal(x.w.service.subscribeAlerts(subscribeRequest(x.w, a.account, device('https://169.254.169.254/latest/meta-data')), x.w.caller), 'push_endpoint_refused');
    await expectRefusal(x.w.service.subscribeAlerts(subscribeRequest(x.w, TOKEN, device()), x.w.caller), 'not_enrolled');
    await expectRefusal(x.w.service.subscribeAlerts({ ...subscribeRequest(x.w, a.account, device()), chainId: 1 }, x.w.caller), 'wrong_chain');

    // The audit log names the push service, never the endpoint or its keys.
    const lines = x.w.journal.lines.join('\n');
    expect(lines).not.toContain(d.endpoint);
    expect(lines).not.toContain(d.keys.p256dh);
    expect(alertRecords(x.w).map((r) => [r.event, r.code ?? r.service])).toEqual([
      ['subscribed', 'fcm.googleapis.com'], ['refused', 'bad_passkey_signature'], ['refused', 'passkey_required'], ['refused', 'proof_expired'],
      ['subscribed', 'fcm.googleapis.com'], ['refused', 'replayed'], ['refused', 'push_endpoint_refused'],
    ]);
  });

  it('caps subscriptions per account, and re-subscribing a device updates it', async () => {
    const x = alertsWorld({ maxPerAccount: 2 });
    const a = await safeAccount(x.w, { deployed: true });
    const d = device();
    await x.w.service.subscribeAlerts(subscribeRequest(x.w, a.account, d), x.w.caller);
    await x.w.service.subscribeAlerts(subscribeRequest(x.w, a.account, device()), x.w.caller);
    await expectRefusal(x.w.service.subscribeAlerts(subscribeRequest(x.w, a.account, device()), x.w.caller), 'too_many_subscriptions');
    x.w.clock.now += 1n;
    const rotated = { ...device(d.endpoint) };
    expect((await x.w.service.subscribeAlerts(subscribeRequest(x.w, a.account, rotated), x.w.caller)).created).toBe(false);
    expect(x.store.subscription(CHAIN_ID, a.account, d.endpoint)?.p256dh).toBe(rotated.keys.p256dh);
  });

  it('refuses to unsubscribe while a recovery is queued, then unsubscribes with the same proof and tells the device', async () => {
    const x = alertsWorld();
    const a = await safeAccount(x.w, { deployed: true });
    const d = device();
    await x.w.service.subscribeAlerts(subscribeRequest(x.w, a.account, d), x.w.caller);
    const delay = x.w.chain.installDelay(a.account, a.passkeySigner);
    x.w.chain.queue(delay, { to: TOKEN, value: 0n, data: '0x' });
    await expectRefusal(x.w.service.unsubscribeAlerts(unsubscribeRequest(x.w, a.account, d.endpoint), x.w.caller), 'recovery_pending');
    x.w.chain.delays.get(delay.toLowerCase())!.txNonce = 1n; // vetoed
    x.w.clock.now += 1n;
    expect(await x.w.service.unsubscribeAlerts(unsubscribeRequest(x.w, a.account, d.endpoint), x.w.caller)).toEqual({ unsubscribed: true });
    expect(x.store.subscriptions(CHAIN_ID, a.account)).toEqual([]);
    expect(JSON.parse(x.sent.at(-1)!.payload)).toMatchObject({ type: 'mova.alerts-off', body: 'Os alertas de recuperação da sua conta Movva foram desativados neste dispositivo' });
    x.w.clock.now += 1n;
    await expectRefusal(x.w.service.unsubscribeAlerts(unsubscribeRequest(x.w, a.account, d.endpoint), x.w.caller), 'subscription_unknown');
  });

  it('says when the service sends no alerts', async () => {
    const w = world();
    const a = await safeAccount(w, { deployed: true });
    await expectRefusal(w.service.subscribeAlerts(subscribeRequest(w, a.account, device()), w.caller), 'alerts_disabled');
  });
});

/** An RPC that answers what the test says: Delay states, TransactionAdded logs, a head that moves when told. */
class FakeDelaySource implements DelayLogSource {
  number = 1000n;
  timestamp = T0;
  readonly logs: TransactionAddedLog[] = [];
  readonly states = new Map<string, DelayState & { createdAt: bigint[] }>();
  readonly ranges: [bigint, bigint][] = [];

  async head() { return { number: this.number, timestamp: this.timestamp }; }
  async transactionAdded(from: bigint, to: bigint) {
    this.ranges.push([from, to]);
    return this.logs.filter((l) => l.blockNumber >= from && l.blockNumber <= to);
  }
  async delayState(delay: Address) {
    const s = this.states.get(delay.toLowerCase());
    return s ? { txNonce: s.txNonce, queueNonce: s.queueNonce, cooldown: s.cooldown, expiration: s.expiration } : undefined;
  }
  async txCreatedAt(delay: Address, nonce: bigint) { return this.states.get(delay.toLowerCase())!.createdAt[Number(nonce)] ?? 0n; }

  install(delay: Address) {
    this.states.set(delay.toLowerCase(), { txNonce: 0n, queueNonce: 0n, cooldown: 7n * DAY, expiration: 7n * DAY, createdAt: [] });
  }
  /** A stolen passkey queues a transaction, mined in the next block. */
  queue(delay: Address): bigint {
    const s = this.states.get(delay.toLowerCase())!;
    const nonce = s.queueNonce;
    s.queueNonce += 1n;
    this.number += 1n;
    s.createdAt.push(this.timestamp);
    this.logs.push({ delay, queueNonce: nonce, txHash: keccak256(toHex(`queued ${nonce}`)), blockNumber: this.number });
    return nonce;
  }
  veto(delay: Address) {
    const s = this.states.get(delay.toLowerCase())!;
    s.txNonce = s.queueNonce;
    this.number += 1n;
  }
  mine(blocks = 1n, secondsEach = 12n) {
    this.number += blocks;
    this.timestamp += secondsEach * blocks;
  }
}

const watcherFor = (x: AlertsWorld, source: FakeDelaySource, o: Partial<ConstructorParameters<typeof RecoveryWatcher>[0]> = {}) => new RecoveryWatcher({
  chainId: CHAIN_ID, audit: x.w.audit, store: x.store, source, alerts: x.alerts, confirmations: 2, sleep: async () => {}, now: () => x.w.clock.now, ...o,
});

async function queuedAccount(x: AlertsWorld, subscribers = 1) {
  const a = await safeAccount(x.w, { deployed: true });
  const devices = Array.from({ length: subscribers }, () => device());
  for (const d of devices) await x.w.service.subscribeAlerts(subscribeRequest(x.w, a.account, d), x.w.caller);
  const source = new FakeDelaySource();
  source.install(a.delay);
  return { a, devices, source };
}

describe('the recovery watcher', () => {
  it('alerts every subscribed device once a queued transaction has its confirmations, with no amount or address, and a restart resumes from the cursor', async () => {
    const x = alertsWorld();
    const { a, source } = await queuedAccount(x, 2);
    const watcher = watcherFor(x, source);
    expect(await watcher.tick()).toMatchObject({ queued: 0, alerts: 0 });
    source.queue(a.delay);
    source.mine();
    expect(await watcher.tick()).toMatchObject({ queued: 0, alerts: 0 }); // one block on top: not yet
    source.mine();
    expect(await watcher.tick()).toMatchObject({ queued: 1, alerts: 1 });
    expect(x.sent).toHaveLength(2);
    const payload = JSON.parse(x.sent[0]!.payload);
    expect(payload).toEqual({
      v: 1, type: 'mova.recovery-requested', title: 'Movva', body: 'Uma recuperação foi solicitada na sua conta Movva', kind: 'queued',
      executableAt: Number(T0 + 7n * DAY), tag: 'mova-recovery',
    });
    for (const s of x.sent) {
      expect(s.payload.toLowerCase()).not.toContain(a.account.slice(2).toLowerCase());
      expect(s.payload.toLowerCase()).not.toContain(a.delay.slice(2).toLowerCase());
    }
    expect(alertRecords(x.w).at(-1)).toMatchObject({ event: 'sent', alert: 'queued', delivered: 2, failed: 0, queueNonce: 0n });

    // Restart: the store and its cursor come back from the journal; nothing is sent twice.
    const store = new AlertStore(x.state);
    store.load();
    const restarted = watcherFor({ ...x, store }, source);
    source.mine();
    expect(await restarted.tick()).toMatchObject({ queued: 0, alerts: 0 });
    // The last tick persisted the cursor at 1001 (head 1003, two confirmations): the restart reads from 1002.
    expect(source.ranges.at(-1)).toEqual([1002n, 1002n]);
    expect(x.sent).toHaveLength(2);
  });

  it('re-alerts daily and within a day of the cooldown\'s end, until the owners veto', async () => {
    const x = alertsWorld();
    const { a, source } = await queuedAccount(x);
    const watcher = watcherFor(x, source);
    source.queue(a.delay);
    source.mine(2n, 0n);
    await watcher.tick();
    const executableAt = T0 + 7n * DAY;
    source.mine(1n, DAY);
    expect((await watcher.tick()).alerts).toBe(1);
    source.mine(1n, 12n * HOUR);
    expect((await watcher.tick()).alerts).toBe(0);
    source.timestamp = executableAt - 23n * HOUR;
    source.mine(1n, 0n);
    expect((await watcher.tick()).alerts).toBe(1);
    source.mine(1n, HOUR);
    expect((await watcher.tick()).alerts).toBe(0);
    expect(x.sent.map((s) => JSON.parse(s.payload).kind)).toEqual(['queued', 'daily', 'final']);

    source.veto(a.delay);
    source.mine(2n);
    expect(await watcher.tick()).toMatchObject({ closed: 1, alerts: 0 });
    expect(alertRecords(x.w).at(-1)).toMatchObject({ event: 'closed', outcome: 'vetoed-or-executed', queueNonce: 0n });
    source.mine(1n, 3n * DAY);
    expect((await watcher.tick()).alerts).toBe(0);
    expect(x.sent).toHaveLength(3);
    expect(x.store.open(CHAIN_ID)).toEqual([]);
  });

  it('removes a subscription the push service says is gone (404/410), retries 429/5xx, and tries an undelivered alert again later', async () => {
    const script = new Map<string, PushOutcome[]>();
    const x = alertsWorld({ outcome: (t) => script.get(t.endpoint)?.shift() ?? { ok: true, status: 201 } });
    const { a, devices: [gone, flaky], source } = await queuedAccount(x, 2);
    script.set(gone!.endpoint, [{ ok: false, status: 410, gone: true, retry: false, reason: 'gone' }]);
    script.set(flaky!.endpoint, [{ ok: false, status: 503, gone: false, retry: true, reason: '503' }, { ok: false, status: 429, gone: false, retry: true, retryAfterSeconds: 2, reason: '429' }]);
    const watcher = watcherFor(x, source);
    source.queue(a.delay);
    source.mine(2n);
    expect((await watcher.tick()).alerts).toBe(1);
    expect(x.sent.filter((s) => s.target.endpoint === flaky!.endpoint)).toHaveLength(3);
    expect(x.store.subscriptions(CHAIN_ID, a.account).map((s) => s.endpoint)).toEqual([flaky!.endpoint]);
    expect(alertRecords(x.w).filter((r) => r.event !== 'subscribed')).toEqual([
      expect.objectContaining({ event: 'subscription-removed', service: 'fcm.googleapis.com', code: '410' }),
      expect.objectContaining({ event: 'sent', delivered: 1, failed: 1 }),
    ]);

    // Every attempt failing: nothing counts as delivered, and the alert is tried again after the retry interval.
    script.set(flaky!.endpoint, Array.from({ length: 6 }, () => ({ ok: false, status: 500, gone: false, retry: true, reason: '500' } as PushOutcome)));
    const second = await safeAccount(x.w, { deployed: true, saltNonce: 99n });
    await x.w.service.subscribeAlerts(subscribeRequest(x.w, second.account, flaky!), x.w.caller);
    source.install(second.delay);
    source.queue(second.delay);
    source.mine(2n, 0n);
    const before = x.sent.length;
    await watcher.tick();
    expect(x.sent.length - before).toBe(3);
    source.mine(1n, 60n);
    await watcher.tick();
    expect(x.sent.length - before).toBe(3);
    source.mine(1n, 900n);
    await watcher.tick();
    expect(x.sent.length - before).toBe(6);
  });

  it('catches up a queue from state the first time it sees an account, alerts a device that subscribes later at once, and stops at expiry', async () => {
    const x = alertsWorld();
    const a = await safeAccount(x.w, { deployed: true });
    const source = new FakeDelaySource();
    source.install(a.delay);
    source.queue(a.delay); // before the watcher's start block: no log will be read
    source.number = 5_000n;
    const watcher = watcherFor(x, source, { startBlock: 4_990n });
    expect(await watcher.tick()).toMatchObject({ queued: 1, alerts: 0 }); // nobody subscribed yet
    expect(source.ranges[0]![0]).toBe(4_990n);
    const d = device();
    await x.w.service.subscribeAlerts(subscribeRequest(x.w, a.account, d), x.w.caller);
    source.mine();
    expect((await watcher.tick()).alerts).toBe(1);
    source.timestamp = T0 + 14n * DAY + 1n;
    source.mine(1n, 0n);
    expect(await watcher.tick()).toMatchObject({ closed: 1, alerts: 0 });
    expect(alertRecords(x.w).at(-1)).toMatchObject({ event: 'closed', outcome: 'expired' });
  });

  it('schedules: first alert, retry after a failed attempt, daily, and the final notice once', () => {
    const item: QueuedRecoveryItem = { chainId: CHAIN_ID, account: TOKEN, delay: TOKEN, queueNonce: 0n, createdAt: 0n, executableAt: 7n * DAY, expiresAt: 14n * DAY, alertsSent: 0 };
    expect(dueAlert(item, 10n, 0)).toBeUndefined();
    expect(dueAlert(item, 10n, 1)).toBe('queued');
    expect(dueAlert({ ...item, lastAttemptAt: 10n, lastAttemptDelivered: 0, lastAttemptSubscribers: 1 }, 100n, 1)).toBeUndefined();
    expect(dueAlert({ ...item, lastAttemptAt: 10n, lastAttemptDelivered: 0, lastAttemptSubscribers: 1 }, 910n, 1)).toBe('queued');
    const delivered = { ...item, lastAttemptAt: 10n, lastAttemptDelivered: 1, lastAttemptSubscribers: 1, lastDeliveredAt: 10n, alertsSent: 1 };
    expect(dueAlert(delivered, 10n + DAY - 1n, 1)).toBeUndefined();
    expect(dueAlert(delivered, 10n + DAY, 1)).toBe('daily');
    expect(dueAlert(delivered, 6n * DAY, 1)).toBe('final');
    expect(dueAlert({ ...delivered, lastDeliveredAt: 6n * DAY, finalDelivered: true }, 6n * DAY + HOUR, 1)).toBeUndefined();
    expect(dueAlert({ ...item }, 6n * DAY + 1n, 1)).toBe('final');
  });
});

describe('delivery through the real encryption', () => {
  it('sends an aes128gcm message with VAPID that the subscribed device decrypts to the alert', async () => {
    const d = device('https://updates.push.services.mozilla.com/wpush/v2/abc');
    let body: Buffer | undefined;
    let authorization = '';
    const x = alertsWorld();
    const alerts = new RecoveryAlerts({
      ...x.alerts.o, send: undefined,
      fetch: (async (_url: string, init: RequestInit) => {
        body = init.body as Buffer;
        authorization = (init.headers as Record<string, string>).authorization!;
        return new Response(null, { status: 201 });
      }) as unknown as typeof fetch,
    });
    const r = await alerts.send({ endpoint: d.endpoint, keys: d.keys }, JSON.stringify({ v: 1, hello: 'alert' }));
    expect(r.ok).toBe(true);
    expect(authorization).toContain(`k=${VAPID.publicKey}`);
    expect(JSON.parse(decryptPushPayload({ body: body!, privateKey: d.privateKey, auth: d.auth }).toString())).toEqual({ v: 1, hello: 'alert' });
  });
});

describe('the browser helpers', () => {
  function registration(existing?: { key: Uint8Array; d: Device }) {
    const d = device();
    const calls: { subscribe: Uint8Array[]; unsubscribed: number } = { subscribe: [], unsubscribed: 0 };
    const make = (dev: Device, key: Uint8Array) => ({
      endpoint: dev.endpoint, options: { applicationServerKey: key.buffer.slice(key.byteOffset, key.byteOffset + key.byteLength) as ArrayBuffer },
      toJSON: () => ({ endpoint: dev.endpoint, keys: { p256dh: dev.keys.p256dh, auth: dev.keys.auth } }),
      unsubscribe: async () => { calls.unsubscribed++; current = null; return true; },
    });
    let current: ReturnType<typeof make> | null = existing ? make(existing.d, existing.key) : null;
    return {
      d, calls,
      reg: {
        pushManager: {
          getSubscription: async () => current,
          subscribe: async (o: { userVisibleOnly: boolean; applicationServerKey: Uint8Array }) => {
            expect(o.userVisibleOnly).toBe(true);
            calls.subscribe.push(o.applicationServerKey);
            current = make(d, o.applicationServerKey);
            return current;
          },
        },
      },
    };
  }

  it('subscribeRecoveryAlerts subscribes the push manager with the co-signer\'s VAPID key and registers it with a passkey assertion', async () => {
    const x = alertsWorld();
    const a = await safeAccount(x.w, { deployed: true });
    const s = serveCoSigner(x.w.service, { mode: 'api', apiKeys: [{ name: 'app', token: 'app-client-token-0123456789abcdefghij' }] });
    const port = await s.listen(0);
    closers.push(s.close);
    const cosigner = new RemoteCoSigner({ url: `http://127.0.0.1:${port}`, chainId: CHAIN_ID, apiKey: 'app-client-token-0123456789abcdefghij' });
    // The service's clock is the harness's; the browser signs at that time.
    const sign = (c: Uint8Array) => x.w.passkey.sign(c);
    const stale = registration({ key: new Uint8Array(65).fill(4), d: device() });
    // The browser signs at the wall clock's time: move the service's clock there.
    x.w.clock.now = BigInt(Math.floor(Date.now() / 1000));
    x.w.clock.ms = Date.now();
    const r = await subscribeRecoveryAlerts(stale.reg, { cosigner, account: a.account, coSigner: SERVER, sign });
    expect(stale.calls.unsubscribed).toBe(1); // subscribed for another key: replaced
    expect(Buffer.from(stale.calls.subscribe[0]!).toString('base64url')).toBe(VAPID.publicKey);
    expect(r).toMatchObject({ endpoint: stale.d.endpoint, created: true, pending: 0 });
    expect(x.store.subscription(CHAIN_ID, a.account, stale.d.endpoint)?.p256dh).toBe(stale.d.keys.p256dh);
    expect(await unsubscribeRecoveryAlerts(stale.reg, { cosigner, account: a.account, coSigner: SERVER, sign })).toBe(true);
    expect(x.store.subscriptions(CHAIN_ID, a.account)).toEqual([]);
    const malformed = await fetch(`http://127.0.0.1:${port}/v1/alerts/subscribe`, {
      method: 'POST', headers: { authorization: 'Bearer app-client-token-0123456789abcdefghij', 'content-type': 'application/json' },
      body: JSON.stringify({ chainId: CHAIN_ID, account: a.account, issuedAt: 1, subscription: { endpoint: 'https://fcm.googleapis.com/x', keys: { p256dh: 'AAAA', auth: 'AAAA' } } }),
    });
    expect(malformed.status).toBe(400);
  });

  it('handleRecoveryPush shows the alert with its deadline and leaves other messages alone; a click focuses or opens the app', async () => {
    const shown: { title: string; options: Record<string, unknown> }[] = [];
    const waited: Promise<unknown>[] = [];
    const registration = { showNotification: async (title: string, options?: Record<string, unknown>) => { shown.push({ title, options: options ?? {} }); } };
    const event = (data: unknown) => ({ data: { json: () => { if (data instanceof Error) throw data; return data; } }, waitUntil: (p: Promise<unknown>) => { waited.push(p); } });
    const alert = { v: 1, type: 'mova.recovery-requested', title: 'Movva', body: 'Uma recuperação foi solicitada na sua conta Movva', kind: 'queued', executableAt: 1_800_604_800, tag: 'mova-recovery' };
    expect(handleRecoveryPush(event(alert), { registration, url: '/recuperacao', timeZone: 'America/Sao_Paulo' })).toBe(true);
    await Promise.all(waited);
    expect(shown[0]!.title).toBe('Movva');
    expect(shown[0]!.options).toMatchObject({ tag: 'mova-recovery', requireInteraction: true, renotify: true, data: { url: '/recuperacao', kind: 'queued' } });
    expect(String(shown[0]!.options.body)).toMatch(/^Uma recuperação foi solicitada na sua conta Movva\. Se não foi você, abra o app e vete antes de \d{2}\/\d{2}\/\d{4}/);
    expect(handleRecoveryPush(event({ v: 1, type: 'chat', title: 'x', body: 'y', tag: 'z' }), { registration })).toBe(false);
    expect(handleRecoveryPush(event(new Error('not json')), { registration })).toBe(false);

    const opened: string[] = [];
    let focused = 0;
    const click = (clientsOpen: { url: string; focus?: () => Promise<unknown> }[]) => {
      const done: Promise<unknown>[] = [];
      const handled = handleRecoveryNotificationClick(
        { notification: { data: shown[0]!.options.data, close: () => {} }, waitUntil: (p) => { done.push(p); } },
        { clients: { matchAll: async () => clientsOpen, openWindow: async (u) => { opened.push(u); } } },
      );
      return Promise.all(done).then(() => handled);
    };
    expect(await click([])).toBe(true);
    expect(opened).toEqual(['/recuperacao']);
    expect(await click([{ url: 'https://movva.app/', focus: async () => { focused++; } }])).toBe(true);
    expect(focused).toBe(1);
  });
});

void (null as unknown as AuditRecord);
