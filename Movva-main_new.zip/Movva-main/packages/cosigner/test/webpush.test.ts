import { describe, expect, it } from 'vitest';
import { createECDH, createPublicKey, verify } from 'node:crypto';
import {
  DEFAULT_PUSH_HOSTS, WebPushError, b64urlDecode, checkPushEndpoint, decryptPushPayload, encryptPushPayload, generateVapidKeys, sendWebPush,
  vapidAuthorization, vapidKeysFromPrivate,
} from '../src/index.js';

/** RFC 8291 Appendix A, every value as the RFC prints it. */
const RFC8291 = {
  plaintext: 'V2hlbiBJIGdyb3cgdXAsIEkgd2FudCB0byBiZSBhIHdhdGVybWVsb24',
  asPublic: 'BP4z9KsN6nGRTbVYI_c7VJSPQTBtkgcy27mlmlMoZIIgDll6e3vCYLocInmYWAmS6TlzAC8wEqKK6PBru3jl7A8',
  asPrivate: 'yfWPiYE-n46HLnH0KqZOF1fJJU3MYrct3AELtAQ-oRw',
  uaPublic: 'BCVxsr7N_eNgVRqvHtD0zTZsEc6-VV-JvLexhqUzORcxaOzi6-AYWXvTBHm4bjyPjs7Vd8pZGH6SRpkNtoIAiw4',
  uaPrivate: 'q1dXpw3UpT5VOmu_cf_v6ih07Aems3njxI-JWgLcM94',
  salt: 'DGv6ra1nlYgDCS1FRnbzlw',
  auth: 'BTBZMqHH6r4Tts7J_aSIgg',
  message: 'DGv6ra1nlYgDCS1FRnbzlwAAEABBBP4z9KsN6nGRTbVYI_c7VJSPQTBtkgcy27mlmlMoZIIgDll6e3vCYLocInmYWAmS6TlzAC8wEqKK6PBru3jl7A_yl95bQpu6cVPTpK4Mqgkf1CXztLVBSt2Ks3oZwbuwXPXLWyouBWLVWGNWQexSgSxsj_Qulcy4a-fN',
};

/** A browser's subscription keys, and what it needs to decrypt. */
function userAgent() {
  const ecdh = createECDH('prime256v1');
  ecdh.generateKeys();
  const auth = crypto.getRandomValues(new Uint8Array(16));
  return {
    keys: { p256dh: ecdh.getPublicKey('base64url'), auth: Buffer.from(auth).toString('base64url') },
    privateKey: ecdh.getPrivateKey(),
    auth,
  };
}

describe('aes128gcm message encryption (RFC 8291)', () => {
  it('reproduces the RFC 8291 Appendix A test vector byte for byte, and decrypts it', () => {
    const body = encryptPushPayload({
      keys: { p256dh: RFC8291.uaPublic, auth: RFC8291.auth }, plaintext: b64urlDecode(RFC8291.plaintext),
      salt: b64urlDecode(RFC8291.salt), senderPrivateKey: b64urlDecode(RFC8291.asPrivate),
    });
    expect(body.toString('base64url')).toBe(RFC8291.message);
    // The header: salt, rs = 4096, idlen = 65, the application server's public key.
    expect(body.subarray(0, 16).toString('base64url')).toBe(RFC8291.salt);
    expect(body.readUInt32BE(16)).toBe(4096);
    expect(body.subarray(21, 86).toString('base64url')).toBe(RFC8291.asPublic);
    const plain = decryptPushPayload({ body: b64urlDecode(RFC8291.message), privateKey: b64urlDecode(RFC8291.uaPrivate), auth: RFC8291.auth });
    expect(plain.toString('utf8')).toBe('When I grow up, I want to be a watermelon');
  });

  it('round-trips with a fresh key and salt per message, and hides the length with padding', () => {
    const ua = userAgent();
    const a = encryptPushPayload({ keys: ua.keys, plaintext: '{"v":1}' });
    const b = encryptPushPayload({ keys: ua.keys, plaintext: '{"v":1}' });
    expect(a.equals(b)).toBe(false);
    expect(decryptPushPayload({ body: a, privateKey: ua.privateKey, auth: ua.auth }).toString()).toBe('{"v":1}');
    const padded = encryptPushPayload({ keys: ua.keys, plaintext: 'x', padding: 100 });
    expect(padded.length).toBe(86 + 1 + 1 + 100 + 16);
    expect(decryptPushPayload({ body: padded, privateKey: ua.privateKey, auth: ua.auth }).toString()).toBe('x');
  });

  it('refuses a tampered message, the wrong auth secret, bad keys and a payload over the push size limit', () => {
    const ua = userAgent();
    const body = encryptPushPayload({ keys: ua.keys, plaintext: 'hello' });
    const tampered = Buffer.from(body);
    tampered[tampered.length - 20] ^= 1;
    expect(() => decryptPushPayload({ body: tampered, privateKey: ua.privateKey, auth: ua.auth })).toThrow(WebPushError);
    expect(() => decryptPushPayload({ body, privateKey: ua.privateKey, auth: new Uint8Array(16) })).toThrow(/does not decrypt/);
    expect(() => encryptPushPayload({ keys: { ...ua.keys, auth: 'AAAA' }, plaintext: 'x' })).toThrow(/16 bytes/);
    expect(() => encryptPushPayload({ keys: { ...ua.keys, p256dh: Buffer.alloc(65, 4).toString('base64url') }, plaintext: 'x' })).toThrow(/point/);
    expect(() => encryptPushPayload({ keys: ua.keys, plaintext: 'x'.repeat(3994) })).toThrow(/at most 3993 bytes/);
    expect(encryptPushPayload({ keys: ua.keys, plaintext: 'x'.repeat(3993) }).length).toBe(4096);
  });

  it('decodes base64url strictly', () => {
    expect(() => b64urlDecode('ab+/')).toThrow(/base64url/);
    expect(() => b64urlDecode('abc=')).toThrow(/base64url/);
    expect(b64urlDecode('AQID').equals(Buffer.from([1, 2, 3]))).toBe(true);
  });
});

describe('VAPID (RFC 8292)', () => {
  const endpoint = 'https://fcm.googleapis.com/fcm/send/abc:def';

  it('signs an ES256 JWT for the push service origin, at most 24 hours ahead, that verifies under the advertised key', () => {
    const keys = generateVapidKeys();
    const header = vapidAuthorization({ endpoint, subject: 'mailto:ops@movva.app', keys, now: 1_800_000_000 });
    const m = /^vapid t=([\w-]+)\.([\w-]+)\.([\w-]+), k=([\w-]+)$/.exec(header)!;
    expect(m).not.toBeNull();
    expect(m[4]).toBe(keys.publicKey);
    expect(JSON.parse(Buffer.from(m[1]!, 'base64url').toString())).toEqual({ typ: 'JWT', alg: 'ES256' });
    expect(JSON.parse(Buffer.from(m[2]!, 'base64url').toString())).toEqual({ aud: 'https://fcm.googleapis.com', exp: 1_800_000_000 + 12 * 3600, sub: 'mailto:ops@movva.app' });
    const pub = b64urlDecode(keys.publicKey);
    const key = createPublicKey({ format: 'jwk', key: { kty: 'EC', crv: 'P-256', x: pub.subarray(1, 33).toString('base64url'), y: pub.subarray(33).toString('base64url') } });
    const signature = b64urlDecode(m[3]!);
    expect(signature.length).toBe(64);
    expect(verify('sha256', Buffer.from(`${m[1]}.${m[2]}`), { key, dsaEncoding: 'ieee-p1363' }, signature)).toBe(true);
  });

  it('refuses an expiry past 24 hours, a subject that is not a contact, and a public key that is not the private key\'s', () => {
    const keys = generateVapidKeys();
    expect(() => vapidAuthorization({ endpoint, subject: 'mailto:ops@movva.app', keys, expiresInSeconds: 24 * 3600 + 1 })).toThrow(/24|86400/);
    expect(() => vapidAuthorization({ endpoint, subject: 'ops@movva.app', keys })).toThrow(/mailto/);
    expect(vapidKeysFromPrivate(keys.privateKey)).toEqual(keys);
    expect(() => vapidKeysFromPrivate(keys.privateKey, generateVapidKeys().publicKey)).toThrow(/does not belong/);
  });
});

describe('push endpoints and delivery', () => {
  it('accepts only https endpoints on known push services', () => {
    expect(checkPushEndpoint('https://fcm.googleapis.com/fcm/send/x').host).toBe('fcm.googleapis.com');
    expect(checkPushEndpoint('https://wns2-par02p.notify.windows.com/w/?token=x').hostname).toBe('wns2-par02p.notify.windows.com');
    for (const bad of ['http://fcm.googleapis.com/x', 'https://169.254.169.254/latest', 'https://localhost/x', 'https://evil.example/x', 'https://notify.windows.com.evil.example/x',
      'https://user:pw@fcm.googleapis.com/x', 'https://fcm.googleapis.com:8443/x', 'not a url']) {
      expect(() => checkPushEndpoint(bad), bad).toThrow(WebPushError);
    }
    expect(checkPushEndpoint('http://127.0.0.1:8934/push', { allowInsecure: true }).port).toBe('8934');
    expect(DEFAULT_PUSH_HOSTS).toContain('web.push.apple.com');
  });

  it('POSTs one encrypted message with VAPID, TTL, urgency and topic, refusing redirects; the device decrypts it', async () => {
    const ua = userAgent();
    const vapid = generateVapidKeys();
    let seen: { url: string; init: RequestInit } | undefined;
    const fetch = (async (url: string, init: RequestInit) => { seen = { url, init }; return new Response(null, { status: 201 }); }) as unknown as typeof globalThis.fetch;
    const r = await sendWebPush({ endpoint: 'https://updates.push.services.mozilla.com/wpush/v2/abc', keys: ua.keys }, '{"hello":1}', { vapid, subject: 'mailto:ops@movva.app', topic: 'mova-recovery', fetch });
    expect(r).toEqual({ ok: true, status: 201 });
    const h = seen!.init.headers as Record<string, string>;
    expect(h).toMatchObject({ 'content-encoding': 'aes128gcm', 'content-type': 'application/octet-stream', ttl: '86400', urgency: 'high', topic: 'mova-recovery' });
    expect(h.authorization).toMatch(new RegExp(`^vapid t=.+, k=${vapid.publicKey}$`));
    expect(seen!.init.redirect).toBe('error');
    expect(decryptPushPayload({ body: seen!.init.body as Buffer, privateKey: ua.privateKey, auth: ua.auth }).toString()).toBe('{"hello":1}');
  });

  it('classifies answers: 404/410 gone, 429/5xx/network retried (with Retry-After), 400/403/413 not', async () => {
    const ua = userAgent();
    const vapid = generateVapidKeys();
    const send = (status: number | 'network', headers: Record<string, string> = {}) => sendWebPush({ endpoint: 'https://fcm.googleapis.com/x', keys: ua.keys }, 'x', {
      vapid, subject: 'mailto:ops@movva.app',
      fetch: (async () => { if (status === 'network') throw new TypeError('fetch failed'); return new Response('no', { status, headers }); }) as unknown as typeof globalThis.fetch,
    });
    expect(await send(410)).toMatchObject({ ok: false, gone: true, retry: false });
    expect(await send(404)).toMatchObject({ ok: false, gone: true, retry: false });
    expect(await send(429, { 'retry-after': '30' })).toMatchObject({ ok: false, gone: false, retry: true, retryAfterSeconds: 30 });
    expect(await send(503)).toMatchObject({ ok: false, retry: true });
    expect(await send('network')).toMatchObject({ ok: false, retry: true });
    for (const status of [400, 403, 413]) expect(await send(status)).toMatchObject({ ok: false, gone: false, retry: false, status });
  });
});
