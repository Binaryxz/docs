import { afterEach, describe, expect, it } from 'vitest';
import { request } from 'node:http';
import { hexToBytes } from 'viem';
import { encodeWebAuthnSignature } from '@mova/smart-account';
import { enrolmentChallenge, serveCoSigner, userOpToWire } from '../src/index.js';
import { CHAIN_ID, SERVER, SERVER_KEY, STRANGER, deposit, safeAccount, safeOp, sig, world } from './harness.js';

const TOKEN = 'app-client-token-0123456789abcdefghij';
const RPC = 'https://eth-mainnet.g.alchemy.com/v2/SECRETKEY0123456789';
const closers: (() => Promise<void>)[] = [];
afterEach(async () => { while (closers.length) await closers.pop()!(); });

async function up(o: Partial<Parameters<typeof serveCoSigner>[1]> = {}) {
  const w = world();
  const s = serveCoSigner(w.service, { mode: 'both', apiKeys: [{ name: 'movva-web', token: TOKEN }], redactValues: [RPC, TOKEN, SERVER_KEY], maxBodyBytes: 4096, ...o });
  const port = await s.listen(0);
  closers.push(s.close);
  const base = `http://127.0.0.1:${port}`;
  const texts: string[] = [];
  const call = async (path: string, init: RequestInit & { json?: unknown; auth?: string | null } = {}) => {
    const headers: Record<string, string> = { ...(init.headers as Record<string, string> ?? {}) };
    if (init.auth !== null) headers.authorization = `Bearer ${init.auth ?? TOKEN}`;
    if (init.json !== undefined) headers['content-type'] = 'application/json';
    const res = await fetch(`${base}${path}`, { ...init, headers, body: init.json !== undefined ? JSON.stringify(init.json, (_k, v) => (typeof v === 'bigint' ? v.toString() : v)) : init.body });
    const text = await res.text();
    texts.push(text);
    return { status: res.status, text, json: (() => { try { return JSON.parse(text); } catch { return undefined; } })(), headers: res.headers };
  };
  return { w, base, port, call, texts };
}

describe('the HTTP API', () => {
  it('requires an API key on every /v1 route, compared exactly', async () => {
    const { call } = await up();
    expect((await call('/v1/info', { auth: null })).json).toMatchObject({ error: 'unauthorized' });
    expect((await call('/v1/info', { auth: 'app-client-token-0123456789abcdefghiX' })).status).toBe(401);
    expect((await call('/v1/cosign', { method: 'POST', json: {}, auth: null })).status).toBe(401);
    const info = await call('/v1/info');
    expect(info.status).toBe(200);
    expect(info.json).toMatchObject({ coSigner: SERVER, chainId: CHAIN_ID, custody: 'memory' });
  });

  it('serves anonymous clients only when the API is explicitly public, and still refuses a wrong key', async () => {
    const { call } = await up({ apiKeys: [], publicApi: true });
    expect((await call('/v1/info', { auth: null })).status).toBe(200);
    expect((await call('/v1/info', { auth: 'not-a-configured-key-at-all' })).status).toBe(401);
  });

  it('refuses bodies over the limit, bodies that are not JSON, and requests without a JSON content type', async () => {
    const { port, call } = await up();
    const big = await new Promise<number>((resolve, reject) => {
      const rq = request({ host: '127.0.0.1', port, path: '/v1/cosign', method: 'POST', headers: { authorization: `Bearer ${TOKEN}`, 'content-type': 'application/json', 'content-length': 100_000 } }, (rs) => { rs.resume(); resolve(rs.statusCode!); });
      rq.on('error', reject);
      rq.write('{"x":"');
    });
    expect(big).toBe(413);
    expect((await call('/v1/cosign', { method: 'POST', body: '{nope', headers: { 'content-type': 'application/json' } })).json).toMatchObject({ error: 'malformed' });
    expect((await call('/v1/cosign', { method: 'POST', body: '{}', headers: { 'content-type': 'text/plain' } })).status).toBe(415);
    expect((await call('/v1/cosign', { method: 'POST', json: { chainId: CHAIN_ID } })).json).toMatchObject({ error: 'malformed' });
  });

  it('enrols, co-signs and refuses with a code over HTTP', async () => {
    const { w, call } = await up();
    const signer = w.chain.deploySigner(w.pk);
    const owners = [signer, SERVER];
    const { fakeSafeAddress } = await import('./harness.js');
    const account = fakeSafeAddress(owners, 2, 3n);
    const issuedAt = Number(w.clock.now);
    const enrol = await call('/v1/enrol', { method: 'POST', json: {
      chainId: CHAIN_ID, account, type: 'safe', issuedAt, safe: { owners, threshold: 2, saltNonce: '3' }, passkey: { x: w.pk.x, y: w.pk.y },
      passkeySignature: encodeWebAuthnSignature(w.passkey.sign(hexToBytes(enrolmentChallenge(CHAIN_ID, account, SERVER, issuedAt)))),
    } });
    expect(enrol.status, enrol.text).toBe(200);
    w.chain.code.add(account.toLowerCase());
    w.chain.safes.set(account.toLowerCase(), { owners, threshold: 2n, modules: [] });
    const op = safeOp(w, account, [deposit(1n)]);
    const ok = await call('/v1/cosign', { method: 'POST', json: { chainId: CHAIN_ID, account, kind: 'safe-operation', userOp: userOpToWire(op.userOp), ...op.window, passkeySignature: sig(w, op.digest) } });
    expect(ok.status, ok.text).toBe(200);
    expect(ok.json.digest).toBe(op.digest);
    const bad = safeOp(w, account, [{ to: STRANGER, data: '0x' }]);
    const refused = await call('/v1/cosign', { method: 'POST', json: { chainId: CHAIN_ID, account, kind: 'safe-operation', userOp: userOpToWire(bad.userOp), ...bad.window, passkeySignature: sig(w, bad.digest) } });
    expect(refused.status).toBe(403);
    expect(refused.json).toMatchObject({ error: 'target_not_allowed' });
    const noPasskey = await call('/v1/veto', { method: 'POST', json: { chainId: CHAIN_ID, account, kind: 'safe-operation', userOp: userOpToWire(op.userOp), ...op.window } });
    expect(noPasskey.json).toMatchObject({ error: 'passkey_required' });
    const queue = await call(`/v1/queue?chainId=${CHAIN_ID}&account=${account}`);
    expect(queue.json).toMatchObject({ error: 'no_recovery_module' });
  });

  it('exposes readiness, status and Prometheus metrics with refusal codes as labels and nothing else', async () => {
    const { w, call } = await up();
    await call('/v1/info', { auth: null });
    const metrics = await call('/metrics', { auth: null });
    expect(metrics.text).toMatch(/mova_cosigner_refusals_total\{code="unauthorized"\} 1/);
    expect(metrics.text).toMatch(/mova_cosigner_up 1/);
    expect((await call('/readyz', { auth: null })).status).toBe(200);
    w.service.ready = false;
    expect((await call('/readyz', { auth: null })).status).toBe(503);
    expect((await call('/v1/info')).status).toBe(200);
    expect((await call('/v1/queue?chainId=31337&account=0x0000000000000000000000000000000000000001')).json).toMatchObject({ error: 'not_ready' });
  });

  it('answers CORS only for configured origins', async () => {
    const { call } = await up({ corsOrigins: ['https://movva.app'] });
    const allowed = await call('/v1/info', { headers: { origin: 'https://movva.app' } });
    expect(allowed.headers.get('access-control-allow-origin')).toBe('https://movva.app');
    const other = await call('/v1/info', { headers: { origin: 'https://evil.example' } });
    expect(other.headers.get('access-control-allow-origin')).toBeNull();
  });

  it('never returns a secret: not the key, not an API key, not the RPC URL', async () => {
    const { w, call, texts } = await up();
    const a = await safeAccount(w, { deployed: true });
    const op = safeOp(w, a.account, [deposit(1n)]);
    await call('/v1/cosign', { method: 'POST', json: { chainId: CHAIN_ID, account: a.account, kind: 'safe-operation', userOp: userOpToWire(op.userOp), ...op.window, passkeySignature: sig(w, op.digest) } });
    await call('/v1/info');
    await call('/status', { auth: null });
    await call('/metrics', { auth: null });
    await call('/nowhere', { auth: null });
    await call(`/v1/queue?chainId=${CHAIN_ID}&account=${a.account}`);
    const all = texts.join('\n');
    expect(all).not.toContain(SERVER_KEY.slice(2));
    expect(all).not.toContain(TOKEN);
    expect(all).not.toContain('SECRETKEY0123456789');
  });
});
