import { describe, expect, it } from 'vitest';
import { p256 } from '@noble/curves/nist';
import { sha256 } from '@noble/hashes/sha2';
import { encodeAbiParameters, hexToBytes, keccak256, toHex, type Hex } from 'viem';
import { PasskeyAuthenticator, encodeWebAuthnSignature, type WebAuthnAssertion } from '@mova/smart-account';
import { decodeWebAuthnSignature, verifyWebAuthnSignature } from '../src/webauthn.js';

const passkey = PasskeyAuthenticator.create('wallet.brl.example');
const key = passkey.publicKey();
const digest = keccak256(toHex('an operation'));
const other = keccak256(toHex('another operation'));
const N = p256.Point.Fn.ORDER;

/** Re-sign an assertion with changed authenticator data or client data, as a real (or cloned) authenticator could. */
function resign(a: WebAuthnAssertion, change: { flags?: number; clientDataJSON?: string }): WebAuthnAssertion {
  const { privateKey } = passkey.export();
  const authenticatorData = a.authenticatorData.slice();
  if (change.flags !== undefined) authenticatorData[32] = change.flags;
  const clientDataJSON = change.clientDataJSON ? new TextEncoder().encode(change.clientDataJSON) : a.clientDataJSON;
  const payload = new Uint8Array(authenticatorData.length + 32);
  payload.set(authenticatorData, 0);
  payload.set(sha256(clientDataJSON), authenticatorData.length);
  const s = p256.sign(sha256(payload), privateKey, { prehash: false });
  return { authenticatorData, clientDataJSON, r: s.r, s: s.s > N / 2n ? N - s.s : s.s };
}

describe('verifyWebAuthnSignature - the passkey half, checked as the chain checks it', () => {
  it('accepts a user-verified assertion over exactly this digest', () => {
    const v = verifyWebAuthnSignature(digest, encodeWebAuthnSignature(passkey.sign(hexToBytes(digest))), key);
    expect(v.ok).toBe(true);
  });

  it('refuses an assertion over a different operation', () => {
    const v = verifyWebAuthnSignature(digest, encodeWebAuthnSignature(passkey.sign(hexToBytes(other))), key);
    expect(v).toMatchObject({ ok: false });
  });

  it('refuses a forged assertion: another authenticator\'s signature', () => {
    const forger = PasskeyAuthenticator.create('wallet.brl.example');
    expect(verifyWebAuthnSignature(digest, encodeWebAuthnSignature(forger.sign(hexToBytes(digest))), key).ok).toBe(false);
  });

  it('refuses a signature whose r or s was altered', () => {
    const a = passkey.sign(hexToBytes(digest));
    expect(verifyWebAuthnSignature(digest, encodeWebAuthnSignature({ ...a, r: a.r ^ 1n }), key).ok).toBe(false);
    expect(verifyWebAuthnSignature(digest, encodeWebAuthnSignature({ ...a, s: 0n }), key).ok).toBe(false);
    expect(verifyWebAuthnSignature(digest, encodeWebAuthnSignature({ ...a, r: N }), key).ok).toBe(false);
  });

  it('accepts the malleable high-s form, as Safe\'s WebAuthn library does (a browser produces either)', () => {
    const a = passkey.sign(hexToBytes(digest));
    expect(verifyWebAuthnSignature(digest, encodeWebAuthnSignature({ ...a, s: N - a.s }), key).ok).toBe(true);
  });

  it('refuses an assertion without user verification, and one without user presence', () => {
    const a = passkey.sign(hexToBytes(digest));
    expect(verifyWebAuthnSignature(digest, encodeWebAuthnSignature(resign(a, { flags: 0x01 })), key)).toMatchObject({ ok: false, reason: expect.stringMatching(/user-verified/) });
    expect(verifyWebAuthnSignature(digest, encodeWebAuthnSignature(resign(a, { flags: 0x04 })), key)).toMatchObject({ ok: false, reason: expect.stringMatching(/presence/) });
  });

  it('refuses client data that smuggles a second challenge, even when genuinely signed', () => {
    const a = passkey.sign(hexToBytes(digest));
    const b64 = Buffer.from(hexToBytes(digest)).toString('base64url');
    const b64other = Buffer.from(hexToBytes(other)).toString('base64url');
    const smuggled = `{"type":"webauthn.get","challenge":"${b64}","challenge":"${b64other}","origin":"https://wallet.brl.example"}`;
    const v = verifyWebAuthnSignature(digest, encodeWebAuthnSignature(resign(a, { clientDataJSON: smuggled })), key);
    expect(v).toMatchObject({ ok: false, reason: expect.stringMatching(/exactly this challenge/) });
  });

  it('pins relying party ids and origins when configured', () => {
    const s = encodeWebAuthnSignature(passkey.sign(hexToBytes(digest)));
    expect(verifyWebAuthnSignature(digest, s, key, { rpIds: ['wallet.brl.example'], origins: ['https://wallet.brl.example'] }).ok).toBe(true);
    expect(verifyWebAuthnSignature(digest, s, key, { rpIds: ['evil.example'] }).ok).toBe(false);
    expect(verifyWebAuthnSignature(digest, s, key, { origins: ['https://evil.example'] }).ok).toBe(false);
  });

  it('refuses bytes that are not the canonical Safe encoding', () => {
    const s = encodeWebAuthnSignature(passkey.sign(hexToBytes(digest)));
    expect(verifyWebAuthnSignature(digest, `${s}00` as Hex, key).ok).toBe(false);
    expect(verifyWebAuthnSignature(digest, '0x1234', key).ok).toBe(false);
    const short = encodeAbiParameters([{ type: 'bytes' }, { type: 'string' }, { type: 'uint256' }, { type: 'uint256' }], ['0x0102', '"origin":"x"', 1n, 1n]);
    expect(verifyWebAuthnSignature(digest, short, key).ok).toBe(false);
    expect(decodeWebAuthnSignature(s).clientDataFields).toMatch(/^"origin":/);
  });

  it('refuses a key that is not on P-256', () => {
    const s = encodeWebAuthnSignature(passkey.sign(hexToBytes(digest)));
    expect(verifyWebAuthnSignature(digest, s, { x: key.x, y: key.y + 1n }).ok).toBe(false);
  });
});
