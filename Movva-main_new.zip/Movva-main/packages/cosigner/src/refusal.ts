/**
 * Why the co-signer did not sign, as a fixed vocabulary.
 *
 * Every refusal carries a code from this list and an HTTP status. The code is what the audit log, the
 * metrics and a wallet's UI key on; the message is for the requester and never carries a secret, a key or
 * a value the request did not already contain. A refusal is the only thing a co-signer can do against the
 * user (docs/wallet-custody.md §3), so each one is named rather than folded into a generic 403.
 */
export const REFUSAL_STATUS = {
  // The request itself.
  malformed: 400,
  body_too_large: 413,
  unsupported_media_type: 415,
  unauthorized: 401,
  wrong_chain: 422,
  rate_limited: 429,
  not_ready: 503,

  // Enrolment.
  not_enrolled: 404,
  enrolment_stale: 409,
  deployment_mismatch: 422,
  not_a_cosigner: 422,
  no_passkey_on_chain: 422,
  enrolment_expired: 401,
  wrong_account_kind: 422,
  no_share: 422,

  // The passkey half.
  passkey_required: 401,
  bad_passkey_signature: 401,

  // The operation.
  expired: 422,
  window_unbounded: 422,
  window_too_long: 422,
  not_deployed: 422,
  replayed: 409,
  unsupported_call: 422,
  unsupported_validator: 422,
  delegatecall_refused: 422,

  // Policy.
  target_not_allowed: 403,
  spender_not_allowed: 403,
  token_transfer_refused: 403,
  token_call_refused: 403,
  authority_change: 403,
  use_veto_route: 403,
  recovery_setup_required: 403,
  daily_limit_exceeded: 403,
  message_not_allowed: 403,

  // The veto.
  not_a_veto: 422,
  no_recovery_module: 422,
  nothing_to_veto: 422,
  veto_out_of_range: 422,

  // FROST.
  session_unknown: 409,
  frost_invalid: 422,
  // Distributed key generation (dkg.ts).
  dkg_disabled: 404,
  dkg_exists: 409,
  dkg_invalid: 422,

  // Sponsorship and recovery alerts.
  sponsorship_disabled: 404,
  alerts_disabled: 404,
  proof_expired: 401,
  push_endpoint_refused: 422,
  recovery_pending: 409,
  subscription_unknown: 404,
  too_many_subscriptions: 429,

  internal: 500,
} as const;

export type RefusalCode = keyof typeof REFUSAL_STATUS;

export const REFUSAL_CODES = Object.keys(REFUSAL_STATUS) as RefusalCode[];

export class Refusal extends Error {
  override readonly name = 'Refusal';
  readonly status: number;

  constructor(readonly code: RefusalCode, message: string) {
    super(message);
    this.status = REFUSAL_STATUS[code];
  }
}

export const isRefusalCode = (s: unknown): s is RefusalCode => typeof s === 'string' && s in REFUSAL_STATUS;
