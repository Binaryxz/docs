/**
 * Web Push from node:crypto, with no dependency: VAPID (RFC 8292) and aes128gcm message encryption (RFC 8291 over
 * RFC 8188).
 *
 *   VAPID       an ES256 JWT - { aud: the push service's origin, exp: at most 24 h ahead, sub: a contact } - signed
 *               with the application server's P-256 key, sent as `Authorization: vapid t=<jwt>, k=<public key>`.
 *               The push service accepts messages only from the key the subscription was created with.
 *   aes128gcm   an ephemeral P-256 key per message; ECDH with the subscription's `p256dh`; HKDF-SHA-256 keyed by
 *               its 16-byte `auth` secret; one record of `plaintext || 0x02` sealed with AES-128-GCM behind the
 *               header salt(16) || rs(4) || idlen(1) || the ephemeral public key(65). The push service sees only
 *               ciphertext; it learns the endpoint, the time and the size.
 *
 * `test/webpush.test.ts` checks the encryption against RFC 8291's Appendix A test vector byte for byte.
 */
import {
  createCipheriv, createDecipheriv, createECDH, createPrivateKey, hkdfSync, sign as cryptoSign, type KeyObject,
} from 'node:crypto';

/* ------------------------------------------------------------------ encoding */

const B64URL = /^[A-Za-z0-9_-]*$/;

export function b64urlEncode(bytes: Uint8Array): string {
  return Buffer.from(bytes).toString('base64url');
}

/** Strict base64url (no padding, no other alphabet): Buffer's decoder skips what it does not know. */
export function b64urlDecode(s: string, what = 'value'): Buffer {
  if (typeof s !== 'string' || !B64URL.test(s) || s.length % 4 === 1) throw new WebPushError(`${what} is not base64url`);
  const out = Buffer.from(s, 'base64url');
  if (out.toString('base64url') !== s) throw new WebPushError(`${what} is not canonical base64url`);
  return out;
}

export class WebPushError extends Error {
  override readonly name = 'WebPushError';
}

/* ------------------------------------------------------------------ VAPID */

export interface VapidKeys {
  /** Uncompressed P-256 public key, 65 bytes, base64url: the `applicationServerKey` a browser subscribes with. */
  publicKey: string;
  /** The private scalar, 32 bytes, base64url. */
  privateKey: string;
}

const pad32 = (b: Buffer) => (b.length === 32 ? b : Buffer.concat([Buffer.alloc(32 - b.length), b]));

export function generateVapidKeys(): VapidKeys {
  const ecdh = createECDH('prime256v1');
  ecdh.generateKeys();
  return { publicKey: b64urlEncode(ecdh.getPublicKey()), privateKey: b64urlEncode(pad32(ecdh.getPrivateKey())) };
}

/** The public key for a private key, and a check that a stated public key belongs to it. */
export function vapidKeysFromPrivate(privateKey: string, statedPublicKey?: string): VapidKeys {
  const d = b64urlDecode(privateKey, 'the VAPID private key');
  if (d.length !== 32) throw new WebPushError('the VAPID private key must be 32 bytes');
  const ecdh = createECDH('prime256v1');
  try {
    ecdh.setPrivateKey(d);
  } catch {
    throw new WebPushError('the VAPID private key is not a P-256 scalar');
  }
  const publicKey = b64urlEncode(ecdh.getPublicKey());
  if (statedPublicKey !== undefined && statedPublicKey !== publicKey) throw new WebPushError('the VAPID public key does not belong to its private key');
  return { publicKey, privateKey };
}

function signingKey(keys: VapidKeys): KeyObject {
  const pub = b64urlDecode(keys.publicKey, 'the VAPID public key');
  if (pub.length !== 65 || pub[0] !== 0x04) throw new WebPushError('the VAPID public key must be an uncompressed P-256 point');
  return createPrivateKey({
    format: 'jwk',
    key: { kty: 'EC', crv: 'P-256', x: b64urlEncode(pub.subarray(1, 33)), y: b64urlEncode(pub.subarray(33, 65)), d: keys.privateKey },
  });
}

/** RFC 8292 §2: the longest a VAPID JWT may be valid. */
export const VAPID_MAX_EXPIRY_SECONDS = 24 * 3600;

export interface VapidOptions {
  /** The push subscription's endpoint; the JWT's `aud` is its origin. */
  endpoint: string;
  /** `mailto:` or `https:` contact for the push service operator (RFC 8292 §2.1). */
  subject: string;
  keys: VapidKeys;
  /** Seconds the token is valid, at most 24 h. Default 12 h. */
  expiresInSeconds?: number;
  /** Unix seconds. */
  now?: number;
}

export function vapidAuthorization(o: VapidOptions): string {
  if (!/^(mailto:[^\s]+|https:\/\/[^\s]+)$/.test(o.subject)) throw new WebPushError('the VAPID subject must be a mailto: or https: URL');
  const expiresIn = o.expiresInSeconds ?? 12 * 3600;
  if (!Number.isInteger(expiresIn) || expiresIn < 60 || expiresIn > VAPID_MAX_EXPIRY_SECONDS) {
    throw new WebPushError(`a VAPID token is valid for 60 s to ${VAPID_MAX_EXPIRY_SECONDS} s`);
  }
  let aud: string;
  try {
    aud = new URL(o.endpoint).origin;
  } catch {
    throw new WebPushError('the push endpoint is not a URL');
  }
  const now = o.now ?? Math.floor(Date.now() / 1000);
  const header = b64urlEncode(Buffer.from(JSON.stringify({ typ: 'JWT', alg: 'ES256' })));
  const claims = b64urlEncode(Buffer.from(JSON.stringify({ aud, exp: now + expiresIn, sub: o.subject })));
  const input = `${header}.${claims}`;
  // JWS ES256 is r || s, 32 bytes each (RFC 7518 §3.4), not DER.
  const signature = cryptoSign('sha256', Buffer.from(input), { key: signingKey(o.keys), dsaEncoding: 'ieee-p1363' });
  return `vapid t=${input}.${b64urlEncode(signature)}, k=${o.keys.publicKey}`;
}

/* ------------------------------------------------------------------ aes128gcm */

export interface PushKeys {
  /** The user agent's uncompressed P-256 public key, base64url. */
  p256dh: string;
  /** The 16-byte authentication secret, base64url. */
  auth: string;
}

export const DEFAULT_RECORD_SIZE = 4096;
/** RFC 8030 §7.2: push services must accept at least 4096 bytes of body, and need not accept more. */
export const MAX_PUSH_BODY_BYTES = 4096;
const HEADER_BYTES = 16 + 4 + 1 + 65;

const utf8 = (s: string) => Buffer.from(s, 'utf8');
const hkdf = (salt: Uint8Array, ikm: Uint8Array, info: Uint8Array, length: number) => Buffer.from(hkdfSync('sha256', ikm, salt, info, length));

function uaKeys(keys: PushKeys): { uaPublic: Buffer; authSecret: Buffer } {
  const uaPublic = b64urlDecode(keys.p256dh, 'keys.p256dh');
  if (uaPublic.length !== 65 || uaPublic[0] !== 0x04) throw new WebPushError('keys.p256dh must be an uncompressed P-256 point');
  const authSecret = b64urlDecode(keys.auth, 'keys.auth');
  if (authSecret.length !== 16) throw new WebPushError('keys.auth must be 16 bytes');
  return { uaPublic, authSecret };
}

/** RFC 8291 §3.4: the content encryption key and nonce for one message. */
function derive(ecdhSecret: Buffer, authSecret: Buffer, uaPublic: Buffer, asPublic: Buffer, salt: Buffer): { cek: Buffer; nonce: Buffer } {
  const keyInfo = Buffer.concat([utf8('WebPush: info\0'), uaPublic, asPublic]);
  const ikm = hkdf(authSecret, ecdhSecret, keyInfo, 32);
  return {
    cek: hkdf(salt, ikm, utf8('Content-Encoding: aes128gcm\0'), 16),
    nonce: hkdf(salt, ikm, utf8('Content-Encoding: nonce\0'), 12),
  };
}

export interface EncryptOptions {
  keys: PushKeys;
  plaintext: Uint8Array | string;
  /** Test vectors only: a fixed 16-byte salt. Default random. */
  salt?: Uint8Array;
  /** Test vectors only: a fixed application-server ECDH private key. Default a fresh key per message. */
  senderPrivateKey?: Uint8Array;
  /** Zero bytes of padding after the delimiter, to hide the length. Default 0. */
  padding?: number;
}

/** One aes128gcm message: the whole HTTP body to POST to the endpoint. */
export function encryptPushPayload(o: EncryptOptions): Buffer {
  const { uaPublic, authSecret } = uaKeys(o.keys);
  const plaintext = typeof o.plaintext === 'string' ? utf8(o.plaintext) : Buffer.from(o.plaintext);
  const padding = o.padding ?? 0;
  if (!Number.isInteger(padding) || padding < 0) throw new WebPushError('padding must be a non-negative integer');
  const recordBytes = plaintext.length + 1 + padding + 16;
  if (recordBytes > DEFAULT_RECORD_SIZE || HEADER_BYTES + recordBytes > MAX_PUSH_BODY_BYTES) {
    throw new WebPushError(`a push message holds at most ${MAX_PUSH_BODY_BYTES - HEADER_BYTES - 17} bytes of payload`);
  }
  const salt = o.salt ? Buffer.from(o.salt) : Buffer.from(crypto.getRandomValues(new Uint8Array(16)));
  if (salt.length !== 16) throw new WebPushError('the salt must be 16 bytes');
  const ecdh = createECDH('prime256v1');
  if (o.senderPrivateKey) ecdh.setPrivateKey(Buffer.from(o.senderPrivateKey));
  else ecdh.generateKeys();
  const asPublic = ecdh.getPublicKey();
  let secret: Buffer;
  try {
    secret = ecdh.computeSecret(uaPublic);
  } catch {
    throw new WebPushError('keys.p256dh is not a point on P-256');
  }
  const { cek, nonce } = derive(secret, authSecret, uaPublic, asPublic, salt);
  const cipher = createCipheriv('aes-128-gcm', cek, nonce);
  const sealed = Buffer.concat([cipher.update(Buffer.concat([plaintext, Buffer.from([0x02]), Buffer.alloc(padding)])), cipher.final(), cipher.getAuthTag()]);
  const header = Buffer.alloc(HEADER_BYTES - 65);
  salt.copy(header, 0);
  header.writeUInt32BE(DEFAULT_RECORD_SIZE, 16);
  header.writeUInt8(65, 20);
  return Buffer.concat([header, asPublic, sealed]);
}

export interface DecryptOptions {
  body: Uint8Array;
  /** The user agent's ECDH private key, 32 bytes. */
  privateKey: Uint8Array;
  /** The subscription's auth secret (base64url or bytes). */
  auth: string | Uint8Array;
}

/**
 * The receiving side, as a browser runs it: for tests and the live example, which play the user agent. One record
 * only, which is all `encryptPushPayload` sends.
 */
export function decryptPushPayload(o: DecryptOptions): Buffer {
  const body = Buffer.from(o.body);
  if (body.length < 21) throw new WebPushError('the message is shorter than its header');
  const salt = body.subarray(0, 16);
  const rs = body.readUInt32BE(16);
  const idlen = body.readUInt8(20);
  if (idlen !== 65 || body.length < 21 + idlen + 17) throw new WebPushError('the key id is not a P-256 public key');
  const asPublic = body.subarray(21, 21 + idlen);
  const record = body.subarray(21 + idlen);
  if (rs < 18 || record.length > rs) throw new WebPushError('only single-record messages are supported');
  const authSecret = typeof o.auth === 'string' ? b64urlDecode(o.auth, 'auth') : Buffer.from(o.auth);
  const ecdh = createECDH('prime256v1');
  ecdh.setPrivateKey(Buffer.from(o.privateKey));
  const uaPublic = ecdh.getPublicKey();
  const { cek, nonce } = derive(ecdh.computeSecret(asPublic), authSecret, uaPublic, asPublic, salt);
  const decipher = createDecipheriv('aes-128-gcm', cek, nonce);
  decipher.setAuthTag(record.subarray(record.length - 16));
  let padded: Buffer;
  try {
    padded = Buffer.concat([decipher.update(record.subarray(0, record.length - 16)), decipher.final()]);
  } catch {
    throw new WebPushError('the message does not decrypt with these keys');
  }
  let end = padded.length - 1;
  while (end >= 0 && padded[end] === 0) end--;
  if (end < 0 || padded[end] !== 0x02) throw new WebPushError('the last record has no 0x02 delimiter');
  return padded.subarray(0, end);
}

/* ------------------------------------------------------------------ delivery */

export interface PushTarget {
  endpoint: string;
  keys: PushKeys;
}

export type PushOutcome =
  | { ok: true; status: number }
  | { ok: false; status?: number; gone: boolean; retry: boolean; retryAfterSeconds?: number; reason: string };

export interface SendPushOptions {
  vapid: VapidKeys;
  subject: string;
  /** Seconds the push service keeps an undelivered message. Default one day. */
  ttlSeconds?: number;
  urgency?: 'very-low' | 'low' | 'normal' | 'high';
  /** Replaces an undelivered message with the same topic (RFC 8030 §5.4): at most 32 base64url characters. */
  topic?: string;
  fetch?: typeof fetch;
  timeoutMs?: number;
  now?: () => number;
}

/**
 * POST one encrypted message. 201/200/202 delivered; 404 and 410 mean the subscription is gone and must be removed
 * (RFC 8030 §7.3); 429, 5xx and network failures may be retried; anything else (400, 401, 403, 413) will not succeed
 * by retrying. Redirects are refused: the endpoint was checked, a redirect's target was not.
 */
export async function sendWebPush(target: PushTarget, payload: string | Uint8Array, o: SendPushOptions): Promise<PushOutcome> {
  if (o.topic !== undefined && !/^[A-Za-z0-9_-]{1,32}$/.test(o.topic)) throw new WebPushError('a topic is 1-32 base64url characters');
  const body = encryptPushPayload({ keys: target.keys, plaintext: payload });
  const headers: Record<string, string> = {
    authorization: vapidAuthorization({ endpoint: target.endpoint, subject: o.subject, keys: o.vapid, now: o.now?.() }),
    'content-encoding': 'aes128gcm',
    'content-type': 'application/octet-stream',
    ttl: String(o.ttlSeconds ?? 86_400),
    urgency: o.urgency ?? 'high',
  };
  if (o.topic) headers.topic = o.topic;
  let res: Response;
  try {
    res = await (o.fetch ?? fetch)(target.endpoint, {
      method: 'POST', headers, body: body as unknown as BodyInit, redirect: 'error', signal: AbortSignal.timeout(o.timeoutMs ?? 10_000),
    });
  } catch (e) {
    return { ok: false, gone: false, retry: true, reason: `the push service did not answer (${e instanceof Error ? e.name : 'error'})` };
  }
  await res.arrayBuffer().catch(() => undefined);
  if (res.status === 200 || res.status === 201 || res.status === 202) return { ok: true, status: res.status };
  if (res.status === 404 || res.status === 410) return { ok: false, status: res.status, gone: true, retry: false, reason: 'the subscription has expired or was removed' };
  const retryAfter = Number(res.headers.get('retry-after'));
  const retry = res.status === 429 || res.status >= 500;
  return {
    ok: false, status: res.status, gone: false, retry, reason: `the push service answered HTTP ${res.status}`,
    ...(retry && Number.isFinite(retryAfter) && retryAfter > 0 ? { retryAfterSeconds: Math.min(retryAfter, 3600) } : {}),
  };
}

/* ------------------------------------------------------------------ endpoints */

/**
 * The push services browsers use today. The co-signer POSTs to whatever endpoint a subscription names, so an
 * endpoint is accepted only on one of these hosts (a leading dot matches subdomains): otherwise a subscription is
 * a way to make the service send requests into its own network.
 */
export const DEFAULT_PUSH_HOSTS: readonly string[] = [
  'fcm.googleapis.com', 'android.googleapis.com', 'updates.push.services.mozilla.com', 'web.push.apple.com', '.notify.windows.com',
];

export function checkPushEndpoint(endpoint: string, o: { allowedHosts?: readonly string[]; allowInsecure?: boolean } = {}): URL {
  if (typeof endpoint !== 'string' || endpoint.length > 1024) throw new WebPushError('the endpoint must be a URL of at most 1024 characters');
  let url: URL;
  try {
    url = new URL(endpoint);
  } catch {
    throw new WebPushError('the endpoint is not a URL');
  }
  if (url.username || url.password || url.hash) throw new WebPushError('the endpoint must not carry credentials or a fragment');
  if (o.allowInsecure) {
    if (url.protocol !== 'https:' && url.protocol !== 'http:') throw new WebPushError('the endpoint must be http(s)');
    return url;
  }
  if (url.protocol !== 'https:' || (url.port && url.port !== '443')) throw new WebPushError('the endpoint must be https on the default port');
  const host = url.hostname.toLowerCase();
  const hosts = o.allowedHosts ?? DEFAULT_PUSH_HOSTS;
  if (!hosts.some((h) => (h.startsWith('.') ? host.endsWith(h.toLowerCase()) && host.length > h.length : host === h.toLowerCase()))) {
    throw new WebPushError('the endpoint is not on a push service this co-signer sends to');
  }
  return url;
}
