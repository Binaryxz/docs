/**
 * Token buckets, keyed by account (after the passkey signature verified, so a stranger cannot empty a
 * user's bucket) or by client address (before anything is parsed, so a flood cannot spend the server's CPU
 * on P-256 verifications). The number of buckets is bounded: the oldest is evicted past `maxKeys`.
 */
export class RateLimiter {
  private readonly buckets = new Map<string, { tokens: number; at: number }>();

  constructor(private readonly o: { burst: number; perMinute: number; now?: () => number; maxKeys?: number }) {
    if (!(o.burst >= 1) || !(o.perMinute > 0)) throw new Error('a rate limit needs a burst of at least 1 and a positive rate');
  }

  /** Take one token for `key`; false when none is left. */
  take(key: string): boolean {
    const now = this.o.now ? this.o.now() : Date.now();
    const b = this.buckets.get(key) ?? { tokens: this.o.burst, at: now };
    b.tokens = Math.min(this.o.burst, b.tokens + ((now - b.at) / 60_000) * this.o.perMinute);
    b.at = now;
    const ok = b.tokens >= 1;
    if (ok) b.tokens -= 1;
    this.buckets.delete(key);
    this.buckets.set(key, b);
    const max = this.o.maxKeys ?? 50_000;
    while (this.buckets.size > max) this.buckets.delete(this.buckets.keys().next().value as string);
    return ok;
  }
}
