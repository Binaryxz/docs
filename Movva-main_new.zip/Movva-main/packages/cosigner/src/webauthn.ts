/**
 * The passkey half of a co-signing request, checked in TypeScript the way the chain checks it.
 *
 * The account trusts a P-256 key through Safe's WebAuthn stack (SafeWebAuthnSigner 0.2.1 as a Safe owner,
 * or the same code reached through `SafeWebAuthnSignerFactory.isValidSignatureForSigner` from
 * PasskeyCoSignerValidator). The signature bytes are `encodeWebAuthnSignature(assertion)`:
 *
 *   abi.encode(bytes authenticatorData, string clientDataFields, uint256 r, uint256 s)
 *
 * and the verifier REBUILDS what the authenticator signed from the challenge it expects:
 *
 *   clientDataJSON = '{"type":"webauthn.get","challenge":"' + base64url(challenge) + '",' + fields + '}'
 *   message        = sha256(authenticatorData || sha256(clientDataJSON))
 *   valid          = flags & UV  &&  P256.verify(message, r, s, x, y)      (malleable s accepted)
 *
 * The co-signer computes `challenge` itself from the operation - never from the request - so a genuine
 * assertion over any other operation, or a forged one, fails here exactly as it would fail on-chain.
 * Where this is STRICTER than the chain it says so: user presence is required too, the rebuilt JSON must
 * parse with this type and this challenge (a duplicate "challenge" key is refused), and the RP ids and
 * origins may be pinned. Stricter only ever means a refusal; the chain remains the authority.
 *
 * `examples/cosigner-live.ts` checks this function against the deployed factory's own verdict.
 */
import { p256 } from '@noble/curves/nist';
import { sha256 } from '@noble/hashes/sha2';
import { decodeAbiParameters, encodeAbiParameters, hexToBytes, size, toHex, type Hex } from 'viem';

export const AUTH_FLAG_UP = 0x01;
export const AUTH_FLAG_UV = 0x04;

export interface PasskeyKey {
  readonly x: bigint;
  readonly y: bigint;
}

export interface DecodedWebAuthnSignature {
  readonly authenticatorData: Uint8Array;
  readonly clientDataFields: string;
  readonly r: bigint;
  readonly s: bigint;
}

export interface WebAuthnPolicy {
  /** RP ids the assertion's rpIdHash may name. Empty or absent: any (the chain does not check it). */
  readonly rpIds?: readonly string[];
  /** Origins clientDataJSON may carry. Empty or absent: any. */
  readonly origins?: readonly string[];
}

export type WebAuthnVerdict =
  | { ok: true; signCount: number; rpIdHash: Hex }
  | { ok: false; reason: string };

const PARAMS = [{ type: 'bytes' }, { type: 'string' }, { type: 'uint256' }, { type: 'uint256' }] as const;
const N = p256.Point.Fn.ORDER;

/** Decode the Safe WebAuthn encoding. Throws on anything viem would not re-encode byte for byte. */
export function decodeWebAuthnSignature(signature: Hex): DecodedWebAuthnSignature {
  const [authenticatorData, clientDataFields, r, s] = decodeAbiParameters(PARAMS, signature);
  // A lax decoder accepts trailing bytes and non-canonical offsets; the bytes checked must be the bytes sent.
  if (encodeAbiParameters(PARAMS, [authenticatorData, clientDataFields, r, s]).toLowerCase() !== signature.toLowerCase()) {
    throw new Error('the WebAuthn signature is not canonically encoded');
  }
  return { authenticatorData: hexToBytes(authenticatorData), clientDataFields, r, s };
}

/** base64url without padding, as Safe's Base64Url library encodes a bytes32. */
export function base64UrlOfChallenge(challenge: Hex): string {
  if (size(challenge) !== 32) throw new Error('a WebAuthn challenge here is 32 bytes');
  return Buffer.from(hexToBytes(challenge)).toString('base64url');
}

export function clientDataJson(challenge: Hex, clientDataFields: string): string {
  return `{"type":"webauthn.get","challenge":"${base64UrlOfChallenge(challenge)}",${clientDataFields}}`;
}

function compact(r: bigint, s: bigint): Uint8Array {
  const out = new Uint8Array(64);
  const put = (v: bigint, at: number) => { for (let i = 31; i >= 0; i--) { out[at + i] = Number(v & 0xffn); v >>= 8n; } };
  put(r, 0);
  put(s, 32);
  return out;
}

/**
 * Verify `signature` (Safe WebAuthn encoding) over `challenge` for `key`. Never throws: every failure is a
 * reason, because the caller turns every one of them into the same refusal.
 */
export function verifyWebAuthnSignature(challenge: Hex, signature: Hex, key: PasskeyKey, policy: WebAuthnPolicy = {}): WebAuthnVerdict {
  let sig: DecodedWebAuthnSignature;
  try {
    sig = decodeWebAuthnSignature(signature);
  } catch {
    return { ok: false, reason: 'the passkey signature does not decode' };
  }
  const ad = sig.authenticatorData;
  if (ad.length < 37) return { ok: false, reason: 'authenticatorData is shorter than rpIdHash, flags and counter' };
  const flags = ad[32]!;
  if ((flags & AUTH_FLAG_UV) === 0) return { ok: false, reason: 'the assertion is not user-verified' };
  if ((flags & AUTH_FLAG_UP) === 0) return { ok: false, reason: 'the assertion carries no user presence' };
  const rpIdHash = toHex(ad.slice(0, 32));
  if (policy.rpIds?.length && !policy.rpIds.some((id) => toHex(sha256(new TextEncoder().encode(id))) === rpIdHash)) {
    return { ok: false, reason: 'the assertion is for another relying party' };
  }

  let json: string;
  try {
    json = clientDataJson(challenge, sig.clientDataFields);
  } catch {
    return { ok: false, reason: 'the challenge is not 32 bytes' };
  }
  let parsed: { type?: unknown; challenge?: unknown; origin?: unknown };
  try {
    parsed = JSON.parse(json) as typeof parsed;
  } catch {
    return { ok: false, reason: 'clientDataJSON does not parse' };
  }
  // JSON.parse keeps the LAST duplicate key: fields smuggling a second challenge or type fail here.
  if (parsed.type !== 'webauthn.get' || parsed.challenge !== base64UrlOfChallenge(challenge)) {
    return { ok: false, reason: 'clientDataJSON does not carry exactly this challenge' };
  }
  if (policy.origins?.length && !policy.origins.includes(String(parsed.origin))) {
    return { ok: false, reason: 'the assertion comes from an origin this co-signer does not serve' };
  }

  if (sig.r <= 0n || sig.r >= N || sig.s <= 0n || sig.s >= N) return { ok: false, reason: 'r or s is out of range' };
  let pub: Uint8Array;
  try {
    const point = p256.Point.fromAffine({ x: key.x, y: key.y });
    point.assertValidity();
    pub = point.toBytes(false);
  } catch {
    return { ok: false, reason: 'the enrolled passkey is not a P-256 point' };
  }
  const message = new Uint8Array(ad.length + 32);
  message.set(ad, 0);
  message.set(sha256(new TextEncoder().encode(json)), ad.length);
  let valid = false;
  try {
    valid = p256.verify(compact(sig.r, sig.s), sha256(message), pub, { prehash: false, lowS: false, format: 'compact' });
  } catch {
    valid = false;
  }
  if (!valid) return { ok: false, reason: 'the P-256 signature does not verify for this passkey and this operation' };
  const signCount = ((ad[33]! << 24) >>> 0) + (ad[34]! << 16) + (ad[35]! << 8) + ad[36]!;
  return { ok: true, signCount, rpIdHash };
}
