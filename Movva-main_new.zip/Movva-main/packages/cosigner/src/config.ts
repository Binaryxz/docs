/**
 * The co-signer's configuration, from the environment and two files. Every problem is collected before the
 * process refuses to start, and no message repeats a value (they are the lines pasted into tickets).
 *
 *   RPC_URL                             the chain the accounts live on (carries an API key: redacted everywhere)
 *   CHAIN_ID                            must match the RPC and the policy file
 *   COSIGNER_MODE                       production | development (default: production when NODE_ENV=production)
 *   COSIGNER_KMS_MODULE                 production key custody: a module exporting createKmsBackend(settings) -> KmsBackend
 *   COSIGNER_KMS_SETTINGS_FILE          optional JSON handed to createKmsBackend
 *   COSIGNER_KEY_FILE                   development key custody: a 0600 file holding the key; refused in production unless
 *   COSIGNER_ALLOW_FILE_KEY_IN_PRODUCTION=1   (the co-signer key only; it says nothing about FROST shares)
 *
 * FROST shares (optional; frost-shares.ts). Setting COSIGNER_FROST_SHARES_FILE turns the FROST routes on:
 *   COSIGNER_FROST_SHARES_FILE          the server's FROST shares, one sealed entry per share (the file need not exist yet)
 *   COSIGNER_FROST_KMS_MODULE           production: envelope encryption under a KMS key, a module exporting
 *                                       createShareKeyWrapper(settings) -> ShareKeyWrapper
 *   COSIGNER_FROST_KMS_SETTINGS_FILE    optional JSON handed to createShareKeyWrapper
 *   COSIGNER_FROST_WRAPPING_KEY_FILE    development: envelope encryption under a local 0600 key file (32 bytes of hex)
 *   neither                             the shares are stored in PLAINTEXT (development, with a warning)
 *   COSIGNER_ALLOW_FROST_SHARE_FILE_IN_PRODUCTION=1   production accepts shares recoverable from this disk alone - the
 *                                       plaintext store, a local wrapping key, or migrating a plaintext file - explicitly
 *   COSIGNER_POLICY_FILE                the deployment's policy (see README)
 *   COSIGNER_AUDIT_LOG                  the append-only audit log, on a persistent volume
 *   COSIGNER_API_KEYS_FILE              lines `name:token` (token >= 32 chars); required in production unless
 *   COSIGNER_PUBLIC_API=1               the API is open to any client (the passkey signature is still required)
 *   HOST, PORT, OPS_PORT                listeners (127.0.0.1, 8495, 9495)
 *   MAX_BODY_BYTES                      default 65536
 *   CORS_ORIGINS                        comma-separated origins a browser wallet calls from
 *   TRUST_PROXY=1                       client address from X-Forwarded-For (behind your proxy only)
 *   CLIENT_RATE_BURST, CLIENT_RATE_PER_MINUTE   per client address (60, 600)
 *
 * Sponsorship (optional; sponsorship.ts). Setting COSIGNER_SPONSOR_GATE or COSIGNER_SPONSOR_OWNERLESS_PAYMASTER turns it on:
 *   COSIGNER_SPONSOR_GATE               the SponsorGate that owns the SponsorPaymaster: accounts are allowlisted through it
 *   COSIGNER_SPONSOR_OWNERLESS_PAYMASTER  or, with no gate, the OwnerlessPaymaster the accounts use: nothing is allowlisted,
 *                                       and the operator key only creates what a first operation needs (a Safe's passkey
 *                                       signer, a Kernel account). One of the two, not both.
 *   COSIGNER_SPONSOR_KMS_MODULE         the operator's transaction key in a KMS: a module exporting createKmsBackend(settings)
 *   COSIGNER_SPONSOR_KMS_SETTINGS_FILE  optional JSON handed to it
 *   COSIGNER_SPONSOR_KEY_FILE           development: a 0600 key file; refused in production unless
 *   COSIGNER_ALLOW_SPONSOR_FILE_KEY_IN_PRODUCTION=1
 *   COSIGNER_SPONSOR_DAILY_CAP          accounts in any 24 h (100); with a gate, must stay below its maxSponsorsPerWindow
 *   COSIGNER_SPONSOR_RATE_BURST, COSIGNER_SPONSOR_RATE_PER_MINUTE                 across clients (5, 10)
 *   COSIGNER_SPONSOR_CLIENT_RATE_BURST, COSIGNER_SPONSOR_CLIENT_RATE_PER_MINUTE   per API client (3, 5)
 *   COSIGNER_SPONSOR_MIN_BALANCE_WEI    refuse below this operator balance (10000000000000000)
 *   COSIGNER_SPONSOR_MAX_FEE_GWEI, COSIGNER_SPONSOR_MAX_PRIORITY_FEE_GWEI         fee caps (300, 5)
 *   COSIGNER_SPONSOR_REPLACE_AFTER_BLOCKS, COSIGNER_SPONSOR_WAIT_BLOCKS          stuck-transaction handling (3, 30)
 *
 * Recovery alerts (optional; recovery-alerts.ts). Setting COSIGNER_ALERTS_VAPID_KEY_FILE turns them on:
 *   COSIGNER_ALERTS_VAPID_KEY_FILE      0600 JSON { "publicKey", "privateKey" } (base64url), or the private key alone
 *   COSIGNER_ALERTS_SUBJECT             mailto: or https: contact given to push services
 *   COSIGNER_ALERTS_STATE               the alert state journal (subscriptions, cursor), on a persistent volume
 *   COSIGNER_ALERTS_CONFIRMATIONS       blocks before a queued transaction counts (3)
 *   COSIGNER_ALERTS_POLL_MS             watcher interval (15000)
 *   COSIGNER_ALERTS_REALERT_SECONDS, COSIGNER_ALERTS_FINAL_NOTICE_SECONDS, COSIGNER_ALERTS_RETRY_SECONDS (86400, 86400, 900)
 *   COSIGNER_ALERTS_START_BLOCK         where the watcher starts without a cursor (the earliest enrolment)
 *   COSIGNER_ALERTS_MAX_BLOCK_RANGE     largest getLogs range (2000)
 *   COSIGNER_PUSH_ALLOWED_HOSTS         push service hosts endpoints may name (a leading dot allows subdomains)
 *   COSIGNER_PUSH_ALLOW_INSECURE=1      any http(s) endpoint: development only, refused in production
 */
import { readFileSync } from 'node:fs';
import { getAddress, isAddress, type Address } from 'viem';
import { DEFAULT_PUSH_HOSTS } from './webpush.js';
import { MAINNET } from '@mova/smart-account';
import { EnvReader, type Env } from '@mova/ramp/src/bin/config.js';
import type { DeploymentAddresses } from './enrolment.js';
import { DEFAULT_MAX_VALIDITY_SECONDS, DEFAULT_RATE_LIMIT, DEFAULT_VETO_MAX_VALIDITY_SECONDS, type Policy } from './policy.js';
import { DEFAULT_MAX_BODY_BYTES, MIN_API_KEY_LENGTH, type ApiKey } from './server.js';

export interface CoSignerConfig {
  rpcUrl: string;
  chainId: number;
  production: boolean;
  key: { kind: 'file'; path: string; allowInProduction: boolean } | { kind: 'kms'; module: string; settings: Record<string, unknown> };
  frostShares?: FrostSharesConfig;
  policy: Policy;
  deployment: DeploymentAddresses;
  auditLogFile: string;
  apiKeys: ApiKey[];
  publicApi: boolean;
  host: string;
  port: number;
  opsPort: number;
  maxBodyBytes: number;
  corsOrigins: string[];
  trustProxy: boolean;
  clientRateLimit: { burst: number; perMinute: number };
  sponsorship?: SponsorshipConfig;
  alerts?: AlertsConfig;
  /** Every secret value read, for redaction. */
  secrets: string[];
}

export type KeySource = { kind: 'file'; path: string; allowInProduction: boolean } | { kind: 'kms'; module: string; settings: Record<string, unknown> };

/** How the FROST share file protects the shares in it (frost-shares.ts). */
export type FrostShareProtection =
  | { kind: 'kms'; module: string; settings: Record<string, unknown> }
  | { kind: 'wrapping-key-file'; path: string }
  | { kind: 'plaintext' };

export interface FrostSharesConfig {
  file: string;
  protection: FrostShareProtection;
  /** COSIGNER_ALLOW_FROST_SHARE_FILE_IN_PRODUCTION=1: shares recoverable from this disk alone, accepted knowingly. */
  allowFileInProduction: boolean;
}

export interface SponsorshipConfig {
  /** The SponsorGate; or undefined, with `ownerlessPaymaster` set. */
  gate?: Address;
  ownerlessPaymaster?: Address;
  key: KeySource;
  dailyCap: number;
  rateLimit: { burst: number; perMinute: number };
  clientRateLimit: { burst: number; perMinute: number };
  minOperatorBalanceWei: bigint;
  maxFeePerGasWei: bigint;
  maxPriorityFeePerGasWei: bigint;
  replaceAfterBlocks: number;
  waitBlocks: number;
}

export interface AlertsConfig {
  vapidKeyFile: string;
  subject: string;
  stateFile: string;
  confirmations: number;
  pollMs: number;
  realertSeconds: number;
  finalNoticeSeconds: number;
  retrySeconds: number;
  startBlock?: bigint;
  maxBlockRange: number;
  allowedHosts: string[];
  allowInsecureEndpoints: boolean;
}

/** The longest validity window any deployment may configure: "short" is not a setting to turn off. */
export const MAX_CONFIGURABLE_WINDOW_SECONDS = 3600;

const flag = (v: string | undefined) => v !== undefined && /^(1|true|yes)$/i.test(v.trim());

export function cosignerConfigFromEnv(env: Env, readFile: (path: string) => string = (p) => readFileSync(p, 'utf8')): CoSignerConfig {
  const r = new EnvReader(env);
  const secrets: string[] = [];
  const rpcUrl = r.url('RPC_URL', 'the JSON-RPC endpoint of the chain the accounts live on');
  if (rpcUrl) secrets.push(rpcUrl);
  const chainId = r.int('CHAIN_ID', undefined, 'the chain id this co-signer serves');

  const mode = env.COSIGNER_MODE?.trim();
  if (mode && mode !== 'production' && mode !== 'development') r.problem('COSIGNER_MODE must be production or development');
  const production = mode ? mode === 'production' : env.NODE_ENV === 'production';

  if (r.has('COSIGNER_KEY')) r.problem('COSIGNER_KEY is refused: never put the co-signer key in the environment; use COSIGNER_KMS_MODULE, or COSIGNER_KEY_FILE in development');
  let key: CoSignerConfig['key'] = { kind: 'file', path: '', allowInProduction: false };
  if (r.has('COSIGNER_KMS_MODULE') && r.has('COSIGNER_KEY_FILE')) {
    r.problem('set COSIGNER_KMS_MODULE or COSIGNER_KEY_FILE, not both');
  } else if (r.has('COSIGNER_KMS_MODULE')) {
    let settings: Record<string, unknown> = {};
    if (r.has('COSIGNER_KMS_SETTINGS_FILE')) {
      try {
        const raw = JSON.parse(readFile(env.COSIGNER_KMS_SETTINGS_FILE!.trim())) as unknown;
        if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw new Error('not an object');
        settings = raw as Record<string, unknown>;
      } catch {
        r.problem('COSIGNER_KMS_SETTINGS_FILE could not be read as a JSON object');
      }
    }
    key = { kind: 'kms', module: env.COSIGNER_KMS_MODULE!.trim(), settings };
  } else if (r.has('COSIGNER_KEY_FILE')) {
    const allowInProduction = flag(env.COSIGNER_ALLOW_FILE_KEY_IN_PRODUCTION);
    if (production && !allowInProduction) {
      r.problem('COSIGNER_KEY_FILE is a development key custody and production mode refuses it: use COSIGNER_KMS_MODULE, '
        + 'or set COSIGNER_ALLOW_FILE_KEY_IN_PRODUCTION=1 to accept a key on disk explicitly');
    }
    key = { kind: 'file', path: env.COSIGNER_KEY_FILE!.trim(), allowInProduction };
  } else {
    r.problem('COSIGNER_KMS_MODULE (production) or COSIGNER_KEY_FILE (development) is required: the co-signer\'s key');
  }

  // FROST shares: their own custody and their own production flag. COSIGNER_ALLOW_FILE_KEY_IN_PRODUCTION accepts a
  // signing key on disk; it does not also accept every FROST share on disk.
  let frostShares: FrostSharesConfig | undefined;
  const sharesFile = env.COSIGNER_FROST_SHARES_FILE?.trim();
  const allowShareFile = flag(env.COSIGNER_ALLOW_FROST_SHARE_FILE_IN_PRODUCTION);
  if (sharesFile) {
    let protection: FrostShareProtection = { kind: 'plaintext' };
    if (r.has('COSIGNER_FROST_KMS_MODULE') && r.has('COSIGNER_FROST_WRAPPING_KEY_FILE')) {
      r.problem('set COSIGNER_FROST_KMS_MODULE or COSIGNER_FROST_WRAPPING_KEY_FILE, not both');
    } else if (r.has('COSIGNER_FROST_KMS_MODULE')) {
      let settings: Record<string, unknown> = {};
      if (r.has('COSIGNER_FROST_KMS_SETTINGS_FILE')) {
        try {
          const raw = JSON.parse(readFile(env.COSIGNER_FROST_KMS_SETTINGS_FILE!.trim())) as unknown;
          if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw new Error('not an object');
          settings = raw as Record<string, unknown>;
        } catch {
          r.problem('COSIGNER_FROST_KMS_SETTINGS_FILE could not be read as a JSON object');
        }
      }
      protection = { kind: 'kms', module: env.COSIGNER_FROST_KMS_MODULE!.trim(), settings };
    } else if (r.has('COSIGNER_FROST_WRAPPING_KEY_FILE')) {
      protection = { kind: 'wrapping-key-file', path: env.COSIGNER_FROST_WRAPPING_KEY_FILE!.trim() };
    }
    if (production && protection.kind !== 'kms' && !allowShareFile) {
      const hint = flag(env.COSIGNER_ALLOW_FILE_KEY_IN_PRODUCTION) ? ' (COSIGNER_ALLOW_FILE_KEY_IN_PRODUCTION covers the co-signer key only)' : '';
      r.problem(protection.kind === 'plaintext'
        ? 'COSIGNER_FROST_SHARES_FILE without COSIGNER_FROST_KMS_MODULE stores FROST shares in plaintext and production mode refuses it: '
          + `use COSIGNER_FROST_KMS_MODULE, or set COSIGNER_ALLOW_FROST_SHARE_FILE_IN_PRODUCTION=1 to accept shares on disk explicitly${hint}`
        : 'COSIGNER_FROST_WRAPPING_KEY_FILE keeps the wrapping key on the same disk as the shares and production mode refuses it: '
          + `use COSIGNER_FROST_KMS_MODULE, or set COSIGNER_ALLOW_FROST_SHARE_FILE_IN_PRODUCTION=1 to accept it explicitly${hint}`);
    }
    frostShares = { file: sharesFile, protection, allowFileInProduction: allowShareFile };
  } else if (r.has('COSIGNER_FROST_KMS_MODULE') || r.has('COSIGNER_FROST_WRAPPING_KEY_FILE') || r.has('COSIGNER_FROST_KMS_SETTINGS_FILE')) {
    r.problem('COSIGNER_FROST_KMS_MODULE, COSIGNER_FROST_KMS_SETTINGS_FILE and COSIGNER_FROST_WRAPPING_KEY_FILE need COSIGNER_FROST_SHARES_FILE');
  }

  const policyFile = r.string('COSIGNER_POLICY_FILE', 'the deployment\'s co-signing policy (JSON)');
  let parsed: { policy: Policy; deployment: DeploymentAddresses } | undefined;
  if (policyFile) {
    let raw: unknown;
    try {
      raw = JSON.parse(readFile(policyFile));
    } catch {
      r.problem('COSIGNER_POLICY_FILE could not be read as JSON');
    }
    if (raw !== undefined) parsed = parsePolicy(raw, (m) => r.problem(`COSIGNER_POLICY_FILE: ${m}`), chainId);
  }

  const apiKeys: ApiKey[] = [];
  if (r.has('COSIGNER_API_KEYS_FILE')) {
    let text = '';
    try {
      text = readFile(env.COSIGNER_API_KEYS_FILE!.trim());
    } catch {
      r.problem('COSIGNER_API_KEYS_FILE could not be read');
    }
    text.split(/\r?\n/).forEach((line, i) => {
      const l = line.trim();
      if (!l || l.startsWith('#')) return;
      const at = l.indexOf(':');
      const name = at > 0 ? l.slice(0, at).trim() : '';
      const token = at > 0 ? l.slice(at + 1).trim() : '';
      if (!/^[a-z0-9][a-z0-9._-]{0,31}$/i.test(name)) return r.problem(`COSIGNER_API_KEYS_FILE line ${i + 1}: the client name must be 1-32 characters of [A-Za-z0-9._-]`);
      if (token.length < MIN_API_KEY_LENGTH || !/^[\x21-\x7e]+$/.test(token)) return r.problem(`COSIGNER_API_KEYS_FILE line ${i + 1}: the token must be at least ${MIN_API_KEY_LENGTH} printable characters`);
      if (apiKeys.some((k) => k.name === name)) return r.problem(`COSIGNER_API_KEYS_FILE line ${i + 1}: client ${name} appears twice`);
      apiKeys.push({ name, token });
      secrets.push(token);
    });
  }
  const publicApi = flag(env.COSIGNER_PUBLIC_API);
  if (apiKeys.length === 0 && !publicApi) {
    r.problem('COSIGNER_API_KEYS_FILE is required (or COSIGNER_PUBLIC_API=1 to serve any client; the passkey signature is still required)');
  }

  const clientRateLimit = { burst: r.int('CLIENT_RATE_BURST', 60, 'requests a client address may make at once'), perMinute: r.int('CLIENT_RATE_PER_MINUTE', 600, 'requests per minute per client address') };

  const gwei = (name: string, fallback: bigint): bigint => {
    const v = env[name]?.trim();
    if (!v) return fallback;
    const m = /^(\d{1,9})(?:\.(\d{1,9}))?$/.exec(v);
    if (!m) { r.problem(`${name} must be an amount of gwei, like 30 or 1.5`); return fallback; }
    return BigInt(m[1]!) * 10n ** 9n + BigInt((m[2] ?? '').padEnd(9, '0'));
  };
  const optionalWei = (name: string, fallback: bigint): bigint => (r.has(name) ? r.bigint(name, '') : fallback);

  let sponsorship: SponsorshipConfig | undefined;
  if (r.has('COSIGNER_SPONSOR_KEY')) r.problem('COSIGNER_SPONSOR_KEY is refused: never put the sponsorship operator key in the environment; use COSIGNER_SPONSOR_KMS_MODULE, or COSIGNER_SPONSOR_KEY_FILE in development');
  const gated = r.has('COSIGNER_SPONSOR_GATE');
  const ownerless = r.has('COSIGNER_SPONSOR_OWNERLESS_PAYMASTER');
  if (gated && ownerless) {
    r.problem('set COSIGNER_SPONSOR_GATE (SponsorPaymaster through SponsorGate) or COSIGNER_SPONSOR_OWNERLESS_PAYMASTER (OwnerlessPaymaster, no gate), not both');
  } else if (gated || ownerless) {
    const gate = gated ? r.address('COSIGNER_SPONSOR_GATE', 'the SponsorGate that owns the paymaster') : undefined;
    const ownerlessPaymaster = ownerless ? r.address('COSIGNER_SPONSOR_OWNERLESS_PAYMASTER', 'the OwnerlessPaymaster the accounts use') : undefined;
    const turnedOnBy = gated ? 'COSIGNER_SPONSOR_GATE' : 'COSIGNER_SPONSOR_OWNERLESS_PAYMASTER';
    let sponsorKey: KeySource | undefined;
    if (r.has('COSIGNER_SPONSOR_KMS_MODULE') && r.has('COSIGNER_SPONSOR_KEY_FILE')) {
      r.problem('set COSIGNER_SPONSOR_KMS_MODULE or COSIGNER_SPONSOR_KEY_FILE, not both');
    } else if (r.has('COSIGNER_SPONSOR_KMS_MODULE')) {
      let settings: Record<string, unknown> = {};
      if (r.has('COSIGNER_SPONSOR_KMS_SETTINGS_FILE')) {
        try {
          const raw = JSON.parse(readFile(env.COSIGNER_SPONSOR_KMS_SETTINGS_FILE!.trim())) as unknown;
          if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw new Error('not an object');
          settings = raw as Record<string, unknown>;
        } catch {
          r.problem('COSIGNER_SPONSOR_KMS_SETTINGS_FILE could not be read as a JSON object');
        }
      }
      sponsorKey = { kind: 'kms', module: env.COSIGNER_SPONSOR_KMS_MODULE!.trim(), settings };
    } else if (r.has('COSIGNER_SPONSOR_KEY_FILE')) {
      const allowInProduction = flag(env.COSIGNER_ALLOW_SPONSOR_FILE_KEY_IN_PRODUCTION);
      if (production && !allowInProduction) {
        r.problem('COSIGNER_SPONSOR_KEY_FILE is a development key custody and production mode refuses it: use COSIGNER_SPONSOR_KMS_MODULE, '
          + 'or set COSIGNER_ALLOW_SPONSOR_FILE_KEY_IN_PRODUCTION=1 to accept a key on disk explicitly');
      }
      sponsorKey = { kind: 'file', path: env.COSIGNER_SPONSOR_KEY_FILE!.trim(), allowInProduction };
    } else {
      r.problem(`${turnedOnBy} needs the operator's transaction key: COSIGNER_SPONSOR_KMS_MODULE (production) or COSIGNER_SPONSOR_KEY_FILE (development)`);
    }
    const sponsorRate = (prefix: string, burst: number, perMinute: number) => {
      const out = { burst: r.int(`${prefix}_BURST`, burst, 'sponsorships at once'), perMinute: r.int(`${prefix}_PER_MINUTE`, perMinute, 'sponsorships per minute') };
      if (out.burst < 1 || out.perMinute < 1) r.problem(`${prefix}_BURST and ${prefix}_PER_MINUTE must be at least 1`);
      return out;
    };
    sponsorship = {
      ...(gate ? { gate } : {}), ...(ownerlessPaymaster ? { ownerlessPaymaster } : {}),
      key: sponsorKey ?? { kind: 'file', path: '', allowInProduction: false },
      dailyCap: r.int('COSIGNER_SPONSOR_DAILY_CAP', 100, 'accounts sponsored in any 24 hours'),
      rateLimit: sponsorRate('COSIGNER_SPONSOR_RATE', 5, 10),
      clientRateLimit: sponsorRate('COSIGNER_SPONSOR_CLIENT_RATE', 3, 5),
      minOperatorBalanceWei: optionalWei('COSIGNER_SPONSOR_MIN_BALANCE_WEI', 10n ** 16n),
      maxFeePerGasWei: gwei('COSIGNER_SPONSOR_MAX_FEE_GWEI', 300n * 10n ** 9n),
      maxPriorityFeePerGasWei: gwei('COSIGNER_SPONSOR_MAX_PRIORITY_FEE_GWEI', 5n * 10n ** 9n),
      replaceAfterBlocks: r.int('COSIGNER_SPONSOR_REPLACE_AFTER_BLOCKS', 3, 'blocks before a stuck sponsorship transaction is re-sent'),
      waitBlocks: r.int('COSIGNER_SPONSOR_WAIT_BLOCKS', 30, 'blocks to wait for a sponsorship transaction'),
    };
    if (sponsorship.dailyCap < 1) r.problem('COSIGNER_SPONSOR_DAILY_CAP must be at least 1');
  } else if (Object.keys(env).some((k) => k.startsWith('COSIGNER_SPONSOR_') && env[k]?.trim())) {
    r.problem('COSIGNER_SPONSOR_* settings need COSIGNER_SPONSOR_GATE or COSIGNER_SPONSOR_OWNERLESS_PAYMASTER, which turns sponsorship on');
  }

  let alerts: AlertsConfig | undefined;
  if (r.has('COSIGNER_ALERTS_VAPID_KEY_FILE')) {
    const subject = r.string('COSIGNER_ALERTS_SUBJECT', 'a mailto: or https: contact for push services');
    if (subject && !/^(mailto:[^\s]+|https:\/\/[^\s]+)$/.test(subject)) r.problem('COSIGNER_ALERTS_SUBJECT must be a mailto: or https: URL');
    const allowInsecureEndpoints = flag(env.COSIGNER_PUSH_ALLOW_INSECURE);
    if (allowInsecureEndpoints && production) r.problem('COSIGNER_PUSH_ALLOW_INSECURE is refused in production mode: it lets a subscription point the service at any host');
    const hosts = (env.COSIGNER_PUSH_ALLOWED_HOSTS ?? '').split(',').map((h) => h.trim().toLowerCase()).filter(Boolean);
    for (const h of hosts) if (!/^\.?[a-z0-9-]+(\.[a-z0-9-]+)+$/.test(h)) r.problem('COSIGNER_PUSH_ALLOWED_HOSTS entries must be host names, like fcm.googleapis.com or .notify.windows.com');
    const startBlock = r.has('COSIGNER_ALERTS_START_BLOCK') ? r.bigint('COSIGNER_ALERTS_START_BLOCK', '') : undefined;
    alerts = {
      vapidKeyFile: env.COSIGNER_ALERTS_VAPID_KEY_FILE!.trim(), subject,
      stateFile: r.string('COSIGNER_ALERTS_STATE', 'a file path for the alert state journal, on a persistent volume'),
      confirmations: r.int('COSIGNER_ALERTS_CONFIRMATIONS', 3, 'blocks on top of a queued transaction before it counts'),
      pollMs: r.int('COSIGNER_ALERTS_POLL_MS', 15_000, 'the watcher interval'),
      realertSeconds: r.int('COSIGNER_ALERTS_REALERT_SECONDS', 86_400, 'seconds between reminders'),
      finalNoticeSeconds: r.int('COSIGNER_ALERTS_FINAL_NOTICE_SECONDS', 86_400, 'seconds before the cooldown ends for the last notice'),
      retrySeconds: r.int('COSIGNER_ALERTS_RETRY_SECONDS', 900, 'seconds before an undelivered alert is tried again'),
      ...(startBlock !== undefined ? { startBlock } : {}),
      maxBlockRange: r.int('COSIGNER_ALERTS_MAX_BLOCK_RANGE', 2_000, 'the largest getLogs range'),
      allowedHosts: hosts.length ? hosts : [...DEFAULT_PUSH_HOSTS], allowInsecureEndpoints,
    };
    if (alerts.pollMs < 250) r.problem('COSIGNER_ALERTS_POLL_MS must be at least 250');
    if (alerts.realertSeconds < 60 || alerts.retrySeconds < 10) r.problem('COSIGNER_ALERTS_REALERT_SECONDS must be at least 60 and COSIGNER_ALERTS_RETRY_SECONDS at least 10');
    if (alerts.maxBlockRange < 1) r.problem('COSIGNER_ALERTS_MAX_BLOCK_RANGE must be at least 1');
  } else if (Object.keys(env).some((k) => (k.startsWith('COSIGNER_ALERTS_') || k.startsWith('COSIGNER_PUSH_')) && env[k]?.trim())) {
    r.problem('COSIGNER_ALERTS_* and COSIGNER_PUSH_* settings need COSIGNER_ALERTS_VAPID_KEY_FILE, which turns recovery alerts on');
  }
  if (clientRateLimit.burst < 1 || clientRateLimit.perMinute < 1) r.problem('CLIENT_RATE_BURST and CLIENT_RATE_PER_MINUTE must be at least 1');
  const cfg: CoSignerConfig = {
    rpcUrl, chainId, production, key,
    ...(frostShares ? { frostShares } : {}),
    policy: parsed?.policy as Policy, deployment: parsed?.deployment as DeploymentAddresses,
    auditLogFile: r.string('COSIGNER_AUDIT_LOG', 'a file path for the append-only audit log, on a persistent volume'),
    apiKeys, publicApi,
    host: env.HOST?.trim() || '127.0.0.1',
    port: r.int('PORT', 8495, 'the API port'),
    opsPort: r.int('OPS_PORT', 9495, 'the operations port'),
    maxBodyBytes: r.int('MAX_BODY_BYTES', DEFAULT_MAX_BODY_BYTES, 'the request body limit in bytes'),
    corsOrigins: (env.CORS_ORIGINS ?? '').split(',').map((s) => s.trim()).filter(Boolean),
    trustProxy: flag(env.TRUST_PROXY),
    clientRateLimit,
    ...(sponsorship ? { sponsorship } : {}),
    ...(alerts ? { alerts } : {}),
    secrets,
  };
  if (cfg.maxBodyBytes < 4096 || cfg.maxBodyBytes > 1024 * 1024) r.problem('MAX_BODY_BYTES must be between 4096 and 1048576');
  for (const o of cfg.corsOrigins) if (!/^https?:\/\/[^/\s]+$/.test(o)) r.problem('CORS_ORIGINS entries must be origins like https://app.example');
  r.done();
  return cfg;
}

/**
 * The policy file:
 *
 *   { "chainId": 11155111,
 *     "deployment": { "entryPoint": "0x...", "passkeyCoSignerValidator": "0x...", "frostValidator": "0x...", "kernelAvatarAdapter": "0x..." },
 *     "targets": [ { "address": "0x...", "label": "FiatEscrow" }, ... ],
 *     "tokens":  [ { "address": "0x...", "label": "USDT", "transfer": false, "dailyLimit": "5000000000" } ],
 *     "nativeDailyLimit": "0",
 *     "rotation": { "coSigners": [] },
 *     "window": { "maxSeconds": 1800, "vetoMaxSeconds": 900 },
 *     "rateLimit": { "burst": 10, "perMinute": 30 },
 *     "webauthn": { "rpIds": ["movva.app"], "origins": ["https://movva.app"] } }
 */
export function parsePolicy(raw: unknown, problem: (m: string) => void, chainId?: number): { policy: Policy; deployment: DeploymentAddresses } {
  const o = (raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {}) as Record<string, unknown>;
  if (o.chainId !== undefined && chainId !== undefined && o.chainId !== chainId) problem('chainId does not match CHAIN_ID');
  const addr = (v: unknown, where: string, optional = false): Address | undefined => {
    if (v === undefined && optional) return undefined;
    if (typeof v !== 'string' || !isAddress(v, { strict: false })) { problem(`${where} must be an address`); return undefined; }
    return getAddress(v);
  };
  const amount = (v: unknown, where: string): bigint | undefined => {
    if (v === undefined) return undefined;
    if (typeof v !== 'string' || !/^\d{1,78}$/.test(v)) { problem(`${where} must be a decimal string of base units`); return undefined; }
    return BigInt(v);
  };
  const list = (v: unknown, where: string): unknown[] => {
    if (v === undefined) return [];
    if (!Array.isArray(v)) { problem(`${where} must be an array`); return []; }
    return v;
  };
  const d = (o.deployment ?? {}) as Record<string, unknown>;
  const deployment: DeploymentAddresses = {
    entryPoint: addr(d.entryPoint, 'deployment.entryPoint', true) ?? MAINNET.entryPoint,
    passkeyValidator: addr(d.passkeyCoSignerValidator, 'deployment.passkeyCoSignerValidator', true),
    frostValidator: addr(d.frostValidator, 'deployment.frostValidator', true),
    kernelAdapter: addr(d.kernelAvatarAdapter, 'deployment.kernelAvatarAdapter', true),
  };
  const label = (v: unknown, where: string) => {
    if (typeof v !== 'string' || !/^[\w .:/()-]{1,64}$/.test(v)) { problem(`${where} must be a short label`); return ''; }
    return v;
  };
  const targets = list(o.targets, 'targets').map((t, i) => {
    const x = (t ?? {}) as Record<string, unknown>;
    return { address: addr(x.address, `targets[${i}].address`)!, label: label(x.label, `targets[${i}].label`) };
  }).filter((t) => t.address);
  if (targets.length === 0) problem('targets must name at least one contract: an empty allowlist co-signs nothing');
  const tokens = list(o.tokens, 'tokens').map((t, i) => {
    const x = (t ?? {}) as Record<string, unknown>;
    if (x.transfer !== undefined && typeof x.transfer !== 'boolean') problem(`tokens[${i}].transfer must be a boolean`);
    return { address: addr(x.address, `tokens[${i}].address`)!, label: label(x.label, `tokens[${i}].label`), transfer: x.transfer === true, dailyLimit: amount(x.dailyLimit, `tokens[${i}].dailyLimit`) };
  }).filter((t) => t.address);
  const rotation = (o.rotation ?? {}) as Record<string, unknown>;
  const rotationCoSigners = list(rotation.coSigners, 'rotation.coSigners').map((a, i) => addr(a, `rotation.coSigners[${i}]`)!).filter(Boolean);
  const w = (o.window ?? {}) as Record<string, unknown>;
  const seconds = (v: unknown, where: string, fallback: number) => {
    if (v === undefined) return fallback;
    if (!Number.isSafeInteger(v) || (v as number) < 60 || (v as number) > MAX_CONFIGURABLE_WINDOW_SECONDS) {
      problem(`${where} must be between 60 and ${MAX_CONFIGURABLE_WINDOW_SECONDS} seconds`);
      return fallback;
    }
    return v as number;
  };
  const rl = (o.rateLimit ?? {}) as Record<string, unknown>;
  const rateLimit = {
    burst: Number.isSafeInteger(rl.burst) && (rl.burst as number) >= 1 ? rl.burst as number : (rl.burst === undefined ? DEFAULT_RATE_LIMIT.burst : (problem('rateLimit.burst must be a positive integer'), DEFAULT_RATE_LIMIT.burst)),
    perMinute: typeof rl.perMinute === 'number' && rl.perMinute > 0 ? rl.perMinute : (rl.perMinute === undefined ? DEFAULT_RATE_LIMIT.perMinute : (problem('rateLimit.perMinute must be positive'), DEFAULT_RATE_LIMIT.perMinute)),
  };
  const wa = (o.webauthn ?? {}) as Record<string, unknown>;
  const strings = (v: unknown, where: string) => list(v, where).filter((s, i) => (typeof s === 'string' && s.length > 0) || (problem(`${where}[${i}] must be a string`), false)) as string[];
  const policy: Policy = {
    targets, tokens, nativeDailyLimit: amount(o.nativeDailyLimit, 'nativeDailyLimit'), rotationCoSigners,
    maxValiditySeconds: seconds(w.maxSeconds, 'window.maxSeconds', DEFAULT_MAX_VALIDITY_SECONDS),
    vetoMaxValiditySeconds: seconds(w.vetoMaxSeconds, 'window.vetoMaxSeconds', DEFAULT_VETO_MAX_VALIDITY_SECONDS),
    rateLimit, webauthn: { rpIds: strings(wa.rpIds, 'webauthn.rpIds'), origins: strings(wa.origins, 'webauthn.origins') },
  };
  return { policy, deployment };
}
