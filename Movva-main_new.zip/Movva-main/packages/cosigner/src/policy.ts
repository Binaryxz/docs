/**
 * What the co-signer agrees to co-sign, once the passkey has signed the exact operation.
 *
 * The passkey check (webauthn.ts) makes the server unable to act without the user. The policy is the other
 * half of the 2-of-2: it is what a stolen passkey still cannot do quickly, because the server refuses. It is
 * deliberately an allowlist - everything not named is refused, with a code:
 *
 *   targets        the deployment's contracts: Mova's escrows, the Privacy Pools entrypoint and pools, the yield
 *                  router, the audit grant registry. Any call, any value.
 *   tokens         `approve` / `increaseAllowance` to an allowlisted target only (the approvals those contracts
 *                  need); `transfer` only where the deployment enables it; nothing else on a token.
 *   authority      refused on ANY target, whatever the allowlist says: Safe addOwnerWithThreshold / removeOwner /
 *                  swapOwner / changeThreshold / enableModule / disableModule / setFallbackHandler / setGuard;
 *                  Kernel installModule / uninstallModule / changeRootValidator / upgradeTo / installValidations;
 *                  the Delay's setTxNonce / setTxCooldown / setTxExpiration / setAvatar / setTarget /
 *                  transferOwnership; the validators' rotateCoSigner / rotateGroupKey; and every call the account
 *                  makes to itself. Except the documented flows:
 *     recovery setup   exactly `recoverySetupCalls` (Safe) or `kernelRecoverySetupCalls` (Kernel) for this account
 *                      and its enrolled passkey, with the default cooldown and expiration, at the start of the
 *                      operation (docs/wallet-custody.md §4: installed by the first operation). A FROST account
 *                      must start with it for as long as its recovery Delay does not exist
 *     rotation         `swapOwner(prev, thisCoSigner, new)` / `rotateCoSigner(new)`, alone in the operation, to a
 *                      co-signer the deployment lists in `rotation.coSigners`
 *     veto             `setTxNonce` on the account's own Delay, alone, through the veto route only (service.ts)
 *   window         a signed validity window is required, and short: validUntil - now <= maxValiditySeconds (1800
 *                  by default; 900 for a veto). validUntil = 0 (no expiry) is refused.
 *   limits         a per-account token bucket (10 burst, 30 per minute by default), and an optional rolling
 *                  24-hour value limit per token (approvals and transfers count) and for native value.
 *   messages       ERC-1271 typed data only for an allowlisted verifying contract on this chain, and never a
 *                  permit of any kind (a signed Permit is an approval the call policy would never see).
 */
import { decodeFunctionData, getAddress, parseAbi, toFunctionSelector, type Address, type Hex } from 'viem';
import { DEFAULT_RECOVERY, kernelRecoverySetupCalls, recoverySetupCalls } from '@mova/smart-account';
import type { DecodedCall, ValidityWindow } from './operation.js';
import { selectorOf } from './operation.js';
import { Refusal } from './refusal.js';
import type { WebAuthnPolicy } from './webauthn.js';

export interface TargetRule {
  address: Address;
  label: string;
}

export interface TokenRule {
  address: Address;
  label: string;
  /** Plain `transfer` to any recipient. Off by default: value leaves through the allowlisted contracts. */
  transfer: boolean;
  /** Rolling 24 h cap on approvals + transfers, in base units. */
  dailyLimit?: bigint;
}

export interface Policy {
  targets: readonly TargetRule[];
  tokens: readonly TokenRule[];
  nativeDailyLimit?: bigint;
  /** New co-signers a documented rotation may install. Empty: rotation is refused. */
  rotationCoSigners: readonly Address[];
  maxValiditySeconds: number;
  vetoMaxValiditySeconds: number;
  rateLimit: { burst: number; perMinute: number };
  webauthn: WebAuthnPolicy;
}

export const DEFAULT_MAX_VALIDITY_SECONDS = 1800;
export const DEFAULT_VETO_MAX_VALIDITY_SECONDS = 900;
export const DEFAULT_RATE_LIMIT = Object.freeze({ burst: 10, perMinute: 30 });

export function policyOf(p: Partial<Policy> & Pick<Policy, 'targets'>): Policy {
  return {
    targets: p.targets.map((t) => ({ ...t, address: getAddress(t.address) })),
    tokens: (p.tokens ?? []).map((t) => ({ ...t, address: getAddress(t.address) })),
    nativeDailyLimit: p.nativeDailyLimit,
    rotationCoSigners: (p.rotationCoSigners ?? []).map((a) => getAddress(a)),
    maxValiditySeconds: p.maxValiditySeconds ?? DEFAULT_MAX_VALIDITY_SECONDS,
    vetoMaxValiditySeconds: p.vetoMaxValiditySeconds ?? DEFAULT_VETO_MAX_VALIDITY_SECONDS,
    rateLimit: p.rateLimit ?? DEFAULT_RATE_LIMIT,
    webauthn: p.webauthn ?? {},
  };
}

export type AccountKind = 'safe-passkey' | 'safe-frost' | 'kernel-passkey' | 'kernel-frost';

/** What the policy needs to know about the account an operation is for. */
export interface PolicyAccount {
  account: Address;
  kind: AccountKind;
  coSigner: Address;
  passkey: { x: bigint; y: bigint; verifiers: bigint };
  passkeySigner: Address;
  delay: Address;
  validator?: Address;
  kernelAdapter?: Address;
  /**
   * The account's recovery Delay exists. Until it does, a FROST account's passkey is only the one it enrolled with, so its
   * next operation must install recovery for that passkey - whether or not the account itself exists yet (the
   * sponsorship module creates a Kernel account before its first operation).
   */
  recoveryInstalled: boolean;
}

export interface Spend {
  asset: Address | 'native';
  amount: bigint;
}

export interface CallSummary {
  to: Address;
  selector: Hex | null;
  value: bigint;
}

export interface PolicyVerdict {
  flow: 'calls' | 'recovery-setup' | 'rotation';
  spend: Spend[];
  calls: CallSummary[];
}

const sel = (signature: string) => toFunctionSelector(signature).toLowerCase() as Hex;

/** Selectors that change who controls an account, refused on any target outside the documented flows. */
export const AUTHORITY_SELECTORS: ReadonlyMap<Hex, string> = new Map([
  // Safe 1.4.1 OwnerManager / ModuleManager / FallbackManager / GuardManager, and module execution.
  'addOwnerWithThreshold(address,uint256)', 'removeOwner(address,address,uint256)', 'swapOwner(address,address,address)',
  'changeThreshold(uint256)', 'enableModule(address)', 'disableModule(address,address)', 'setFallbackHandler(address)',
  'setGuard(address)', 'setModuleGuard(address)', 'execTransactionFromModule(address,uint256,bytes,uint8)',
  'execTransactionFromModuleReturnData(address,uint256,bytes,uint8)', 'approveHash(bytes32)',
  // Kernel v3.1.
  'installModule(uint256,address,bytes)', 'uninstallModule(uint256,address,bytes)', 'changeRootValidator(bytes21,address,bytes,bytes)',
  'upgradeTo(address)', 'upgradeToAndCall(address,bytes)', 'installValidations(bytes21[],(uint32,address)[],bytes[],bytes[])',
  'uninstallValidation(bytes21,bytes,bytes)', 'invalidateNonce(uint32)', 'grantAccess(bytes21,bytes4,bool)',
  // Zodiac Delay 1.1.1 (enableModule / disableModule as above).
  'setTxNonce(uint256)', 'setTxCooldown(uint256)', 'setTxExpiration(uint256)', 'setAvatar(address)', 'setTarget(address)',
  'transferOwnership(address)', 'renounceOwnership()', 'setUp(bytes)',
  // Our validators.
  'rotateCoSigner(address)', 'rotateGroupKey(uint256,uint256)',
].map((s) => [sel(s), s.slice(0, s.indexOf('('))]));

export const SET_TX_NONCE = sel('setTxNonce(uint256)');
const SWAP_OWNER = sel('swapOwner(address,address,address)');
const ROTATE_CO_SIGNER = sel('rotateCoSigner(address)');

const TOKEN_ABI = parseAbi([
  'function approve(address spender, uint256 amount)',
  'function increaseAllowance(address spender, uint256 amount)',
  'function transfer(address to, uint256 amount)',
]);
const APPROVE = sel('approve(address,uint256)');
const INCREASE_ALLOWANCE = sel('increaseAllowance(address,uint256)');
const TRANSFER = sel('transfer(address,uint256)');
const ADMIN_ABI = parseAbi([
  'function swapOwner(address prevOwner, address oldOwner, address newOwner)',
  'function rotateCoSigner(address newCoSigner)',
  'function setTxNonce(uint256 nonce)',
]);

const same = (a: Address | undefined, b: Address | undefined) => !!a && !!b && a.toLowerCase() === b.toLowerCase();

export function summarise(calls: readonly DecodedCall[]): CallSummary[] {
  return calls.map((c) => ({ to: c.to, selector: selectorOf(c.data) ?? null, value: c.value }));
}

/** The recovery installation calls the documented flow allows for this account, or undefined. */
export function recoverySetupFor(a: PolicyAccount): readonly { to: Address; value: bigint; data: Hex }[] | undefined {
  if (a.kind.startsWith('safe')) {
    return recoverySetupCalls(a.account, a.passkeySigner, DEFAULT_RECOVERY).calls.map((c) => ({ to: c.to, value: c.value, data: c.data }));
  }
  if (!a.kernelAdapter) return undefined;
  const verifier = getAddress(`0x${(a.passkey.verifiers & ((1n << 160n) - 1n)).toString(16).padStart(40, '0')}`);
  return kernelRecoverySetupCalls({
    account: a.account, passkey: { x: a.passkey.x, y: a.passkey.y }, passkeySigner: a.passkeySigner, adapter: a.kernelAdapter, verifier,
  }).calls.map((c) => ({ to: c.to, value: c.value ?? 0n, data: c.data }));
}

function setupPrefixLength(a: PolicyAccount, calls: readonly DecodedCall[]): number {
  const setup = recoverySetupFor(a);
  if (!setup || calls.length < setup.length) return 0;
  const matches = setup.every((s, i) => same(calls[i]!.to, s.to) && calls[i]!.value === s.value && calls[i]!.data.toLowerCase() === s.data.toLowerCase());
  return matches ? setup.length : 0;
}

/** Operation calls, on the co-sign route. Throws a Refusal naming the first call refused. */
export function evaluateCalls(policy: Policy, a: PolicyAccount, calls: readonly DecodedCall[]): PolicyVerdict {
  if (calls.length === 0) throw new Refusal('unsupported_call', 'an operation with no calls');
  for (const c of calls) if (c.operation !== 0) throw new Refusal('delegatecall_refused', 'only CALLs are co-signed');

  const setupLength = setupPrefixLength(a, calls);
  if (!a.recoveryInstalled && a.kind.endsWith('frost') && setupLength === 0) {
    throw new Refusal('recovery_setup_required', 'a FROST account\'s first operation must install recovery for its enrolled passkey, '
      + 'which is what binds that passkey on-chain');
  }

  // Rotation: alone in its operation, to a co-signer the deployment lists.
  if (calls.length === 1) {
    const c = calls[0]!;
    const selector = selectorOf(c.data);
    if (selector === SWAP_OWNER && same(c.to, a.account) && a.kind === 'safe-passkey') {
      const [, oldOwner, newOwner] = decodeFunctionData({ abi: ADMIN_ABI, data: c.data }).args as readonly [Address, Address, Address];
      if (same(oldOwner, a.coSigner) && policy.rotationCoSigners.some((r) => same(r, newOwner)) && c.value === 0n) {
        return { flow: 'rotation', spend: [], calls: summarise(calls) };
      }
    }
    if (selector === ROTATE_CO_SIGNER && same(c.to, a.validator) && a.kind === 'kernel-passkey') {
      const [newCoSigner] = decodeFunctionData({ abi: ADMIN_ABI, data: c.data }).args as readonly [Address];
      if (policy.rotationCoSigners.some((r) => same(r, newCoSigner)) && c.value === 0n) {
        return { flow: 'rotation', spend: [], calls: summarise(calls) };
      }
    }
  }

  const spend: Spend[] = [];
  const add = (asset: Address | 'native', amount: bigint) => {
    if (amount === 0n) return;
    const existing = spend.find((s) => s.asset === asset);
    if (existing) existing.amount += amount;
    else spend.push({ asset, amount });
  };

  calls.forEach((c, i) => {
    if (i < setupLength) return;
    const where = calls.length > 1 ? `call ${i + 1} of ${calls.length}` : 'the call';
    const selector = selectorOf(c.data);
    if (same(c.to, a.delay) && selector === SET_TX_NONCE) {
      throw new Refusal('use_veto_route', `${where} is a recovery veto: it is co-signed only through the veto route, alone`);
    }
    if (same(c.to, a.account)) {
      throw new Refusal('authority_change', `${where} is the account calling itself${selector && AUTHORITY_SELECTORS.has(selector) ? ` (${AUTHORITY_SELECTORS.get(selector)})` : ''}`);
    }
    if (selector && AUTHORITY_SELECTORS.has(selector)) {
      throw new Refusal('authority_change', `${where} is ${AUTHORITY_SELECTORS.get(selector)}, which changes who controls an account`);
    }
    if (same(c.to, a.delay) || same(c.to, a.validator) || same(c.to, a.passkeySigner)) {
      throw new Refusal('authority_change', `${where} reaches the account's own recovery or validation contract`);
    }
    const token = policy.tokens.find((t) => same(t.address, c.to));
    const target = policy.targets.find((t) => same(t.address, c.to));
    if (token && (selector === APPROVE || selector === INCREASE_ALLOWANCE || selector === TRANSFER)) {
      if (c.value !== 0n) throw new Refusal('token_call_refused', `${where} sends native value to a token`);
      let args: readonly [Address, bigint];
      try {
        args = decodeFunctionData({ abi: TOKEN_ABI, data: c.data }).args as readonly [Address, bigint];
      } catch {
        throw new Refusal('token_call_refused', `${where} does not decode as ${selector === TRANSFER ? 'transfer' : 'an approval'}`);
      }
      if (selector === TRANSFER) {
        if (!token.transfer) throw new Refusal('token_transfer_refused', `${where} transfers ${token.label} directly, which this deployment does not co-sign`);
      } else if (!policy.targets.some((t) => same(t.address, args[0]))) {
        throw new Refusal('spender_not_allowed', `${where} approves ${token.label} to a spender that is not one of this deployment's contracts`);
      }
      add(token.address, args[1]);
      return;
    }
    if (!target) {
      throw new Refusal(token ? 'token_call_refused' : 'target_not_allowed',
        token ? `${where} calls ${token.label} with something other than an approval or transfer` : `${where} is to a contract this deployment does not co-sign for`);
    }
    add('native', c.value);
  });

  return { flow: setupLength > 0 ? 'recovery-setup' : 'calls', spend, calls: summarise(calls) };
}

/** The veto route: exactly one `setTxNonce(n)` on the account's own Delay, skipping transactions that are queued. */
export function evaluateVeto(a: PolicyAccount, calls: readonly DecodedCall[], queue: { txNonce: bigint; queueNonce: bigint }): { nonce: bigint } {
  if (calls.length !== 1) throw new Refusal('not_a_veto', 'a veto operation is exactly one call');
  const c = calls[0]!;
  if (!same(c.to, a.delay) || selectorOf(c.data) !== SET_TX_NONCE || c.value !== 0n || c.operation !== 0) {
    throw new Refusal('not_a_veto', 'a veto is setTxNonce on this account\'s own recovery Delay, with no value');
  }
  let nonce: bigint;
  try {
    [nonce] = decodeFunctionData({ abi: ADMIN_ABI, data: c.data }).args as readonly [bigint];
  } catch {
    throw new Refusal('not_a_veto', 'the setTxNonce call does not decode');
  }
  if (queue.queueNonce <= queue.txNonce) throw new Refusal('nothing_to_veto', 'the recovery queue is empty');
  if (nonce <= queue.txNonce || nonce > queue.queueNonce) {
    throw new Refusal('veto_out_of_range', `setTxNonce must skip queued transactions: between ${queue.txNonce + 1n} and ${queue.queueNonce}`);
  }
  return { nonce };
}

export function checkWindow(w: ValidityWindow, now: bigint, maxSeconds: number): void {
  if (w.validUntil === 0) throw new Refusal('window_unbounded', 'validUntil 0 means valid forever; sign a short window');
  if (w.validAfter >= w.validUntil) throw new Refusal('malformed', 'validAfter must be before validUntil');
  if (BigInt(w.validUntil) <= now) throw new Refusal('expired', 'the operation\'s window has already closed');
  if (BigInt(w.validUntil) - now > BigInt(maxSeconds)) {
    throw new Refusal('window_too_long', `the operation stays valid for more than ${maxSeconds} seconds`);
  }
}

export interface TypedDataInput {
  domain: { name?: string; version?: string; chainId?: number | bigint | string; verifyingContract?: Address; salt?: Hex };
  types: Record<string, readonly { name: string; type: string }[]>;
  primaryType: string;
  message: Record<string, unknown>;
}

/** ERC-1271 over typed data: an allowlisted verifying contract on this chain, and no permit of any kind. */
export function evaluateMessage(policy: Policy, chainId: number, a: PolicyAccount, td: TypedDataInput): void {
  const vc = td.domain.verifyingContract;
  if (!vc || !policy.targets.some((t) => same(t.address, vc))) {
    throw new Refusal('message_not_allowed', 'the message is not for one of this deployment\'s contracts');
  }
  if (td.domain.chainId === undefined || BigInt(td.domain.chainId) !== BigInt(chainId)) {
    throw new Refusal('message_not_allowed', 'the message\'s domain must name this chain');
  }
  if (same(vc, a.account)) throw new Refusal('message_not_allowed', 'the message is addressed to the account itself');
  const typeNames = [td.primaryType, ...Object.keys(td.types)];
  if (typeNames.some((n) => /permit|approv|allowance|delegat/i.test(n))) {
    throw new Refusal('message_not_allowed', 'permits, approvals and delegations are never co-signed as messages');
  }
}
