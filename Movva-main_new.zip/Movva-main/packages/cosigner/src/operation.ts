/**
 * The operation as the co-signer sees it: its wire form, the digest the signers sign (recomputed here,
 * never taken from a request), the calls it makes, and the signature layouts the server's half goes into.
 *
 *   Safe     SafeOp EIP-712 digest (Safe4337Module 0.3.0), window inside the struct; callData is
 *            `executeUserOp(to, value, data, 0)` or a DELEGATECALL to the canonical MultiSendCallOnly
 *   Kernel   UserOpChallenge(userOpHash, validAfter, validUntil, validator); callData is ERC-7579
 *            `execute(mode, calldata)`, SINGLE or BATCH, revert-on-failure only
 */
import {
  concat, decodeAbiParameters, decodeFunctionData, getAddress, hexToBigInt, isAddress, isHex, keccak256, pad, parseAbi, size, slice,
  toHex, type Address, type Hex,
} from 'viem';
import {
  MAINNET, MULTISEND_CALL_ONLY, kernelUserOpChallenge, safeOpHash, userOperationHashV07,
  type PackedUserOperation,
} from '@mova/smart-account';
import { Refusal } from './refusal.js';

export type UnsignedUserOp = Omit<PackedUserOperation, 'signature'>;

/** A v0.7 packed UserOperation without its signature, JSON-safe: integers as decimal strings. */
export interface WireUserOp {
  sender: Address;
  nonce: string;
  initCode: Hex;
  callData: Hex;
  accountGasLimits: Hex;
  preVerificationGas: string;
  gasFees: Hex;
  paymasterAndData: Hex;
}

export interface ValidityWindow {
  validAfter: number;
  validUntil: number;
}

export interface DecodedCall {
  to: Address;
  value: bigint;
  data: Hex;
  /** 0 CALL. A DELEGATECALL only ever appears at the top of a Safe operation, to MultiSendCallOnly. */
  operation: 0 | 1;
}

export function userOpToWire(op: UnsignedUserOp): WireUserOp {
  return {
    sender: getAddress(op.sender), nonce: op.nonce.toString(), initCode: op.initCode, callData: op.callData,
    accountGasLimits: op.accountGasLimits, preVerificationGas: op.preVerificationGas.toString(), gasFees: op.gasFees,
    paymasterAndData: op.paymasterAndData,
  };
}

const MAX_OP_HEX_BYTES = 48 * 1024;

export function userOpFromWire(w: unknown): UnsignedUserOp {
  const o = (w && typeof w === 'object' ? w : undefined) as Record<string, unknown> | undefined;
  if (!o) throw new Refusal('malformed', 'userOp must be an object');
  const hex = (k: string, bytes?: number): Hex => {
    const v = o[k];
    if (typeof v !== 'string' || !isHex(v, { strict: true }) || v.length % 2 !== 0) throw new Refusal('malformed', `userOp.${k} must be even-length 0x hex`);
    if (bytes !== undefined && size(v) !== bytes) throw new Refusal('malformed', `userOp.${k} must be ${bytes} bytes`);
    if (size(v) > MAX_OP_HEX_BYTES) throw new Refusal('malformed', `userOp.${k} is too long`);
    return v.toLowerCase() as Hex;
  };
  const uint = (k: string, max: bigint): bigint => {
    const v = o[k];
    if (typeof v !== 'string' || !/^(0|[1-9]\d{0,77})$/.test(v)) throw new Refusal('malformed', `userOp.${k} must be a decimal integer string`);
    const n = BigInt(v);
    if (n > max) throw new Refusal('malformed', `userOp.${k} is out of range`);
    return n;
  };
  const sender = o.sender;
  if (typeof sender !== 'string' || !isAddress(sender, { strict: false })) throw new Refusal('malformed', 'userOp.sender must be an address');
  return {
    sender: getAddress(sender), nonce: uint('nonce', (1n << 256n) - 1n), initCode: hex('initCode'), callData: hex('callData'),
    accountGasLimits: hex('accountGasLimits', 32), preVerificationGas: uint('preVerificationGas', (1n << 256n) - 1n),
    gasFees: hex('gasFees', 32), paymasterAndData: hex('paymasterAndData'),
  };
}

export function windowFromWire(o: { validAfter?: unknown; validUntil?: unknown }): ValidityWindow {
  const n = (k: 'validAfter' | 'validUntil') => {
    const v = o[k];
    if (!Number.isSafeInteger(v) || (v as number) < 0 || (v as number) > 2 ** 48 - 1) throw new Refusal('malformed', `${k} must be a uint48`);
    return v as number;
  };
  return { validAfter: n('validAfter'), validUntil: n('validUntil') };
}

export const unpackTwo = (word: Hex): [bigint, bigint] => [hexToBigInt(slice(word, 0, 16)), hexToBigInt(slice(word, 16, 32))];

/** The SafeOp digest both Safe owners sign. */
export function safeOperationDigest(op: UnsignedUserOp, w: ValidityWindow, chainId: number): Hex {
  const [verificationGasLimit, callGasLimit] = unpackTwo(op.accountGasLimits);
  const [maxPriorityFeePerGas, maxFeePerGas] = unpackTwo(op.gasFees);
  return safeOpHash({
    safe: op.sender, nonce: op.nonce, initCode: op.initCode, callData: op.callData, verificationGasLimit, callGasLimit,
    preVerificationGas: op.preVerificationGas, maxPriorityFeePerGas, maxFeePerGas, paymasterAndData: op.paymasterAndData,
    validAfter: w.validAfter, validUntil: w.validUntil, chainId: BigInt(chainId),
  });
}

/** The UserOpChallenge both signers of a Kernel validator sign. */
export function kernelOperationDigest(op: UnsignedUserOp, w: ValidityWindow, chainId: number, validator: Address, entryPoint: Address = MAINNET.entryPoint): Hex {
  return kernelUserOpChallenge(userOperationHashV07(op, chainId, entryPoint), w.validAfter, w.validUntil, validator);
}

/* ------------------------------------------------------------------ calls */

const SAFE_MODULE_EXEC_ABI = parseAbi([
  'function executeUserOp(address to, uint256 value, bytes data, uint8 operation)',
  'function executeUserOpWithErrorString(address to, uint256 value, bytes data, uint8 operation)',
]);
const MULTISEND_ABI = parseAbi(['function multiSend(bytes transactions)']);
const KERNEL_EXECUTE_ABI = parseAbi(['function execute(bytes32 execMode, bytes executionCalldata)']);

export const selectorOf = (data: Hex): Hex | undefined => (size(data) >= 4 ? slice(data, 0, 4).toLowerCase() as Hex : undefined);

/** MultiSendCallOnly's packed format: operation(1) to(20) value(32) length(32) data. */
export function decodeMultiSend(transactions: Hex): DecodedCall[] {
  const bytes = size(transactions);
  const out: DecodedCall[] = [];
  let at = 0;
  while (at < bytes) {
    if (at + 85 > bytes) throw new Refusal('unsupported_call', 'a MultiSend entry is truncated');
    const operation = Number(hexToBigInt(slice(transactions, at, at + 1)));
    const to = getAddress(slice(transactions, at + 1, at + 21));
    const value = hexToBigInt(slice(transactions, at + 21, at + 53));
    const length = hexToBigInt(slice(transactions, at + 53, at + 85));
    if (BigInt(at + 85) + length > BigInt(bytes)) throw new Refusal('unsupported_call', 'a MultiSend entry overruns the batch');
    const data = length === 0n ? '0x' : slice(transactions, at + 85, at + 85 + Number(length));
    if (operation !== 0) throw new Refusal('delegatecall_refused', 'a batched call may only be a CALL');
    out.push({ to, value, data: data.toLowerCase() as Hex, operation: 0 });
    at += 85 + Number(length);
  }
  if (out.length === 0) throw new Refusal('unsupported_call', 'an empty batch');
  return out;
}

/**
 * The calls a Safe operation makes: one `executeUserOp` CALL, or a DELEGATECALL to the canonical
 * MultiSendCallOnly carrying CALLs. Anything else - another delegate target, a Safe function as the
 * operation's own callData - is refused.
 */
export function decodeSafeCallData(callData: Hex): DecodedCall[] {
  let args: readonly [Address, bigint, Hex, number];
  try {
    args = decodeFunctionData({ abi: SAFE_MODULE_EXEC_ABI, data: callData }).args as typeof args;
  } catch {
    throw new Refusal('unsupported_call', 'a Safe operation must call executeUserOp on the 4337 module');
  }
  const [to, value, data, operation] = args;
  if (operation === 0) return [{ to: getAddress(to), value, data: data.toLowerCase() as Hex, operation: 0 }];
  if (operation !== 1 || getAddress(to) !== MULTISEND_CALL_ONLY || value !== 0n) {
    throw new Refusal('delegatecall_refused', 'the only DELEGATECALL co-signed is a batch through the canonical MultiSendCallOnly');
  }
  let transactions: Hex;
  try {
    transactions = decodeFunctionData({ abi: MULTISEND_ABI, data }).args[0];
  } catch {
    throw new Refusal('unsupported_call', 'the MultiSendCallOnly call does not decode');
  }
  return decodeMultiSend(transactions);
}

/**
 * The calls a Kernel operation makes: ERC-7579 `execute`, callType SINGLE (0x00) or BATCH (0x01), execType
 * revert-on-failure (0x00), the rest of the mode zero. DELEGATECALL (0xff), STATIC and try-mode are
 * refused, as is any other function as the operation's callData (installModule, upgradeTo, ... are
 * reachable from the EntryPoint directly).
 */
export function decodeKernelCallData(callData: Hex): DecodedCall[] {
  let mode: Hex;
  let execution: Hex;
  try {
    [mode, execution] = decodeFunctionData({ abi: KERNEL_EXECUTE_ABI, data: callData }).args;
  } catch {
    const selector = selectorOf(callData);
    throw new Refusal(selector && KERNEL_AUTHORITY_SELECTORS.has(selector) ? 'authority_change' : 'unsupported_call',
      'a Kernel operation must call execute(mode, calldata)');
  }
  const callType = mode.slice(2, 4);
  if (mode.slice(4) !== '0'.repeat(62)) throw new Refusal('unsupported_call', 'only revert-on-failure SINGLE and BATCH execution modes are co-signed');
  if (callType === '00') {
    if (size(execution) < 52) throw new Refusal('unsupported_call', 'a SINGLE execution is target ++ value ++ data');
    return [{ to: getAddress(slice(execution, 0, 20)), value: hexToBigInt(slice(execution, 20, 52)), data: (size(execution) > 52 ? slice(execution, 52) : '0x').toLowerCase() as Hex, operation: 0 }];
  }
  if (callType === '01') {
    let calls: readonly { target: Address; value: bigint; callData: Hex }[];
    try {
      [calls] = decodeAbiParameters([{ type: 'tuple[]', components: [{ name: 'target', type: 'address' }, { name: 'value', type: 'uint256' }, { name: 'callData', type: 'bytes' }] }], execution);
    } catch {
      throw new Refusal('unsupported_call', 'the BATCH execution does not decode');
    }
    if (calls.length === 0) throw new Refusal('unsupported_call', 'an empty batch');
    return calls.map((c) => ({ to: getAddress(c.target), value: c.value, data: c.callData.toLowerCase() as Hex, operation: 0 as const }));
  }
  throw new Refusal('delegatecall_refused', 'only SINGLE and BATCH calls are co-signed (no DELEGATECALL or STATICCALL mode)');
}

/** Kernel functions the EntryPoint may call directly that change who controls the account. */
export const KERNEL_AUTHORITY_SELECTORS: ReadonlySet<Hex> = new Set([
  'function installModule(uint256,address,bytes)', 'function uninstallModule(uint256,address,bytes)',
  'function changeRootValidator(bytes21,address,bytes,bytes)', 'function upgradeTo(address)',
  'function installValidations(bytes21[],(uint32,address)[],bytes[],bytes[])', 'function uninstallValidation(bytes21,bytes,bytes)',
  'function invalidateNonce(uint32)', 'function grantAccess(bytes21,bytes4,bool)', 'function executeUserOp((address,uint256,bytes,bytes,bytes32,uint256,bytes32,bytes,bytes),bytes32)',
].map((sig) => toSelector(sig)));

function toSelector(signature: string): Hex {
  const inner = signature.replace(/^function\s+/, '');
  return slice(keccak256(toHex(inner)), 0, 4);
}

/* ------------------------------------------------------------------ signature layouts */

export interface SafeSignatureEntry {
  kind: 'eoa' | 'contract';
  /** The owner a contract entry names; undefined for an EOA entry (its owner is whoever recovers). */
  owner?: Address;
  /** 65 bytes for an EOA entry; the contract's signature bytes for a contract entry. */
  signature: Hex;
  /** Byte offset of this entry's 65-byte static part in the blob. */
  staticAt: number;
}

/**
 * Split a Safe signature blob (optionally after a 12-byte validity header) into its entries. The statics
 * end where the first contract entry's dynamic data begins; with no contract entry, at the end.
 */
export function splitSafeSignature(signature: Hex, headerBytes: 0 | 12 = 12): { validAfter: number; validUntil: number; entries: SafeSignatureEntry[] } {
  const total = size(signature);
  if (total < headerBytes + 65) throw new Error('the Safe signature is shorter than one owner entry');
  const validAfter = headerBytes ? Number(hexToBigInt(slice(signature, 0, 6))) : 0;
  const validUntil = headerBytes ? Number(hexToBigInt(slice(signature, 6, 12))) : 0;
  const entries: SafeSignatureEntry[] = [];
  let staticsEnd = total;
  for (let at = headerBytes; at + 65 <= staticsEnd; at += 65) {
    const r = slice(signature, at, at + 32);
    const s = hexToBigInt(slice(signature, at + 32, at + 64));
    const v = Number(hexToBigInt(slice(signature, at + 64, at + 65)));
    if (v === 0) {
      const dataAt = headerBytes + Number(s);
      if (s > BigInt(total) || dataAt + 32 > total) throw new Error('a contract signature points outside the blob');
      const length = Number(hexToBigInt(slice(signature, dataAt, dataAt + 32)));
      if (dataAt + 32 + length > total) throw new Error('a contract signature overruns the blob');
      staticsEnd = Math.min(staticsEnd, dataAt);
      entries.push({ kind: 'contract', owner: getAddress(slice(r, 12, 32)), signature: length ? slice(signature, dataAt + 32, dataAt + 32 + length) : '0x', staticAt: at });
    } else {
      entries.push({ kind: 'eoa', signature: slice(signature, at, at + 65), staticAt: at });
    }
  }
  return { validAfter, validUntil, entries };
}

/**
 * What a remote co-signer's local stand-in signs with: bytes derived from the digest, of the length the
 * real signature will have, so every offset in the blob is already right when the real one replaces it.
 * Never valid on-chain (65 bytes of hash output with v = 0 is not a signature) and never submitted.
 */
export function placeholderSignature(digest: Hex, length = 65): Hex {
  const parts: Hex[] = [];
  for (let i = 0; size(parts.length ? concat(parts) : '0x') < length; i++) {
    parts.push(keccak256(concat([toHex('mova-cosigner/placeholder/v1'), digest, pad(toHex(i), { size: 4 })])));
  }
  const body = slice(concat(parts), 0, length);
  // v = 2: not a contract entry (0), an approved hash (1), ecrecover (27/28) or eth_sign (31/32) to Safe, so
  // a blob holding the placeholder still splits into its entries - and nothing on-chain accepts it.
  return length === 65 ? concat([slice(body, 0, 64), '0x02']) : body;
}

/** Replace the one occurrence of `placeholder` in `blob`; throws unless there is exactly one. */
export function spliceSignature(blob: Hex, placeholder: Hex, real: Hex): Hex {
  if (size(placeholder) !== size(real)) throw new Error('the real signature must have the placeholder\'s length');
  const hay = blob.toLowerCase();
  const needle = placeholder.slice(2).toLowerCase();
  const first = hay.indexOf(needle, 2);
  if (first === -1) throw new Error('the signature carries no co-signer placeholder');
  // Hex nibbles: a match must start on a byte boundary.
  if ((first - 2) % 2 !== 0 || hay.indexOf(needle, first + 1) !== -1) throw new Error('the co-signer placeholder is ambiguous');
  // The rest of the blob keeps its own spelling (checksummed owners stay checksummed).
  return `${blob.slice(0, first)}${real.slice(2)}${blob.slice(first + needle.length)}` as Hex;
}

export const containsPlaceholder = (blob: Hex, placeholder: Hex): boolean => blob.toLowerCase().includes(placeholder.slice(2).toLowerCase());
