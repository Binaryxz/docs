/**
 * Where the co-signer's own key lives, behind one interface.
 *
 * The key is a Safe owner of every 2-of-2 Safe and the `coSigner` of every PasskeyCoSignerValidator account
 * this service serves. It cannot spend alone (docs/wallet-custody.md §3), but together with ONE stolen
 * passkey it spends immediately, so it belongs in a KMS or an HSM: the signing happens there, the process
 * holds a handle, and a compromised host signs only while it is compromised - it cannot take the key away.
 *
 *   CoSignerKey    what the service needs: an address and `signDigest`, a raw 65-byte ECDSA signature over a
 *                  32-byte digest as-is (Safe's v = 27/28 branch, OpenZeppelin `tryRecover`; never eth_sign)
 *   kmsKey         any secp256k1 KMS/HSM (AWS KMS ECC_SECG_P256K1, GCP KMS EC_SIGN_SECP256K1_SHA256, a
 *                  PKCS#11 HSM) through `KmsBackend`: a public key and a signature over a digest, DER or raw.
 *                  The KMS gives no recovery id and may return high s; this normalises s, finds v by
 *                  recovery, and checks every signature against the key before returning it
 *   fileKey        a key file, for development. REFUSES production mode unless explicitly allowed, and
 *                  refuses a file other users can read
 *   localKey       a key in memory, for tests
 *
 * No implementation exposes the key: no property holds it, `JSON.stringify` and `util.inspect` show only
 * the address and the custody label, and no error message includes it.
 */
import { statSync, readFileSync } from 'node:fs';
import { secp256k1 } from '@noble/curves/secp256k1';
import { getAddress, hexToBytes, isHex, keccak256, recoverAddress, size, type Address, type Hex } from 'viem';
import { privateKeyToAccount } from 'viem/accounts';

export interface CoSignerKey {
  readonly address: Address;
  /** A label for status pages and the audit log: 'file', 'memory', 'kms:aws', ... Never key material. */
  readonly custody: string;
  /** 65 bytes r || s || v, v in {27, 28}, low s, over `digest` exactly as given. */
  signDigest(digest: Hex): Promise<Hex>;
}

export class KeyCustodyError extends Error {
  override readonly name = 'KeyCustodyError';
}

const INSPECT = Symbol.for('nodejs.util.inspect.custom');

function sealed(address: Address, custody: string, signDigest: (digest: Hex) => Promise<Hex>): CoSignerKey {
  const key: CoSignerKey = {
    address, custody,
    signDigest: async (digest) => {
      if (!isHex(digest) || size(digest) !== 32) throw new KeyCustodyError('the co-signer signs 32-byte digests only');
      return signDigest(digest);
    },
  };
  Object.defineProperty(key, 'toJSON', { value: () => ({ address, custody }), enumerable: false });
  Object.defineProperty(key, INSPECT, { value: () => `CoSignerKey(${custody}, ${address})`, enumerable: false });
  return Object.freeze(key);
}

function parsePrivateKey(raw: string): Hex {
  const v = raw.trim();
  const hex = (v.startsWith('0x') ? v : `0x${v}`) as Hex;
  let ok = isHex(hex) && hex.length === 66;
  try {
    if (ok) privateKeyToAccount(hex);
  } catch {
    // The curve library prints an out-of-range key as a number in its message; that message is dropped.
    ok = false;
  }
  if (!ok) throw new KeyCustodyError('the co-signer key is not a 32-byte secp256k1 private key');
  return hex;
}

/** A key held in this process. Tests and examples only. */
export function localKey(privateKey: Hex, custody = 'memory'): CoSignerKey {
  const account = privateKeyToAccount(parsePrivateKey(privateKey));
  return sealed(account.address, custody, (digest) => account.sign({ hash: digest }));
}

export interface FileKeyOptions {
  path: string;
  /** The service runs in production mode (COSIGNER_MODE=production, or NODE_ENV=production). */
  production: boolean;
  /** COSIGNER_ALLOW_FILE_KEY_IN_PRODUCTION=1: the operator accepts a file key in production, knowingly. */
  allowInProduction?: boolean;
  readFile?: (path: string) => string;
  /** The file's permission bits; default from stat. */
  fileMode?: (path: string) => number;
}

/**
 * A key file (hex, with or without 0x). For development: in production mode it refuses to load unless
 * `allowInProduction`, and in any mode it refuses a file readable by group or others.
 */
export function fileKey(o: FileKeyOptions): CoSignerKey {
  if (o.production && !o.allowInProduction) {
    throw new KeyCustodyError('a file key refuses to start in production mode: use a KMS/HSM backend (COSIGNER_KMS_MODULE), '
      + 'or set COSIGNER_ALLOW_FILE_KEY_IN_PRODUCTION=1 to accept a key on disk explicitly');
  }
  let mode: number;
  try {
    mode = (o.fileMode ?? ((p) => statSync(p).mode))(o.path);
  } catch {
    throw new KeyCustodyError('the co-signer key file could not be read');
  }
  if ((mode & 0o077) !== 0) {
    throw new KeyCustodyError('the co-signer key file is readable by group or others: chmod 600 (or 400) it');
  }
  let raw: string;
  try {
    raw = (o.readFile ?? ((p) => readFileSync(p, 'utf8')))(o.path);
  } catch {
    throw new KeyCustodyError('the co-signer key file could not be read');
  }
  const account = privateKeyToAccount(parsePrivateKey(raw));
  return sealed(account.address, 'file', (digest) => account.sign({ hash: digest }));
}

/**
 * A secp256k1 key in a KMS or HSM. Map a provider onto this:
 *   AWS KMS   publicKey = GetPublicKey (DER SubjectPublicKeyInfo); sign = Sign(MessageType DIGEST, ECDSA_SHA_256) (DER)
 *   GCP KMS   getPublicKey (PEM -> DER); asymmetricSign({ digest: { sha256: digest } }) (DER)
 *   PKCS#11   CKM_ECDSA over the digest (raw r || s)
 * The digest handed over is the final 32-byte value; a backend must not hash it again.
 */
export interface KmsBackend {
  /** e.g. 'kms:aws', 'hsm:pkcs11'. Shown in /v1/info and the audit log. */
  readonly custody: string;
  /** Uncompressed SEC1 (65 bytes, 0x04 ...) or a DER SubjectPublicKeyInfo ending in one. */
  publicKey(): Promise<Uint8Array>;
  /** DER or compact (64 bytes) ECDSA over `digest`. */
  sign(digest: Uint8Array): Promise<Uint8Array>;
}

const N = secp256k1.Point.Fn.ORDER;

function uncompressedKey(bytes: Uint8Array): Uint8Array {
  const raw = bytes.length === 65 ? bytes : bytes[0] === 0x30 && bytes.length > 65 ? bytes.slice(bytes.length - 65) : undefined;
  if (!raw || raw[0] !== 0x04) throw new KeyCustodyError('the KMS public key is not an uncompressed secp256k1 key');
  try {
    secp256k1.Point.fromBytes(raw).assertValidity();
  } catch {
    throw new KeyCustodyError('the KMS public key is not on secp256k1');
  }
  return raw;
}

export async function kmsKey(backend: KmsBackend): Promise<CoSignerKey> {
  const pub = uncompressedKey(await backend.publicKey());
  const address = getAddress(`0x${keccak256(pub.slice(1)).slice(-40)}`);
  return sealed(address, backend.custody, async (digest) => {
    const out = await backend.sign(hexToBytes(digest));
    let sig: InstanceType<typeof secp256k1.Signature>;
    try {
      sig = out.length === 64 ? secp256k1.Signature.fromBytes(out, 'compact') : secp256k1.Signature.fromBytes(out, 'der');
    } catch {
      throw new KeyCustodyError('the KMS returned a signature that does not decode');
    }
    const s = sig.s > N / 2n ? N - sig.s : sig.s;
    const r32 = sig.r.toString(16).padStart(64, '0');
    const s32 = s.toString(16).padStart(64, '0');
    for (const v of [27, 28]) {
      const candidate = `0x${r32}${s32}${v.toString(16)}` as Hex;
      try {
        if (getAddress(await recoverAddress({ hash: digest, signature: candidate })) === address) return candidate;
      } catch {
        // try the other recovery id
      }
    }
    throw new KeyCustodyError('the KMS signature does not verify for the KMS public key');
  });
}
