/**
 * Recovery alerts that reach a user whose app is closed.
 *
 * The threat (docs/wallet-custody.md §4, §6): a stolen passkey queues a drain on the account's recovery Delay. It
 * becomes executable after the 7-day cooldown unless the owners veto it, and the wallet shows the queue only while
 * it is open. A user who does not open the app for a week loses the funds. So the service watches every enrolled
 * account's Delay and pushes an alert to the devices the user subscribed, until the transaction is vetoed, executed
 * or expired.
 *
 *   subscribe      POST /v1/alerts/subscribe: a push subscription (endpoint + p256dh + auth) and a fresh
 *                  user-verified passkey assertion over `alertsSubscribeChallenge`, for the passkey the account
 *                  trusts. The endpoint must be on a known push service (the service POSTs to it).
 *   unsubscribe    POST /v1/alerts/unsubscribe: the same proof over `alertsUnsubscribeChallenge`. Refused while the
 *                  account has anything queued (recovery_pending): whoever holds the passkey could otherwise silence
 *                  the alerts about their own drain. The device gets a last notice that its alerts were turned off.
 *   watch          `RecoveryWatcher`: `TransactionAdded` logs of every enrolled account's Delay, read up to
 *                  `head - confirmations`, the cursor persisted after each range; a one-time read of each account's
 *                  queue from state catches anything queued before the watcher knew the account.
 *   alert          at once ('queued'); again every `realertSeconds` ('daily'); and within `finalNoticeSeconds` of the
 *                  cooldown's end ('final'); until the Delay's txNonce passes the transaction (vetoed or executed) or
 *                  it expires. An attempt nobody received is retried after `retrySeconds`. Delivery retries 429/5xx a
 *                  few times; 404/410 removes the subscription. Times are the chain's, like the cooldown.
 *
 * The payload is "Uma recuperação foi solicitada na sua conta Movva", its kind, and when the transaction becomes
 * executable - no amount, no address, nothing the push service could learn from if it could read it, which it
 * cannot (aes128gcm, webpush.ts). The state (subscriptions, cursor, open items) is its own journal; the audit log
 * records subscriptions and deliveries without endpoints or keys.
 */
import { ECDH } from 'node:crypto';
import { getAbiItem, getAddress, isAddress, isHex, size, type Address, type Hex, type PublicClient } from 'viem';
import { DELAY_ABI } from '@mova/smart-account';
import type { Journal } from '@mova/lp-node/src/journal.js';
import { redact } from '@mova/ops/redact';
import {
  ALERTS_SUBSCRIBE_TYPEHASH, ALERTS_UNSUBSCRIBE_TYPEHASH, RECOVERY_ALERT_TEXT, alertsSubscribeChallenge, alertsUnsubscribeChallenge, canonicalB64url,
  type RecoveryAlertPayload,
} from './alerts-proof.js';
import type { AuditLog, AlertRecord, Enrolment } from './audit.js';
import type { AccountReader } from './chain.js';
import type { CoSignerMetrics } from './metrics.js';
import { RateLimiter } from './rate-limit.js';
import { Refusal } from './refusal.js';
import type { Caller, Logger } from './service.js';
import { verifyWebAuthnSignature, type WebAuthnPolicy } from './webauthn.js';
import { WebPushError, b64urlDecode, checkPushEndpoint, sendWebPush, type PushOutcome, type PushTarget, type VapidKeys } from './webpush.js';

export type AlertKind = 'queued' | 'daily' | 'final';

export interface StoredSubscription {
  chainId: number;
  account: Address;
  endpoint: string;
  p256dh: string;
  auth: string;
  at: bigint;
  client: string;
}

export interface QueuedRecoveryItem {
  chainId: number;
  account: Address;
  delay: Address;
  queueNonce: bigint;
  txHash?: Hex;
  /** Chain time. */
  createdAt: bigint;
  executableAt: bigint;
  /** 0 when the Delay has no expiration. */
  expiresAt: bigint;
  lastDeliveredAt?: bigint;
  finalDelivered?: boolean;
  lastAttemptAt?: bigint;
  lastAttemptDelivered?: number;
  lastAttemptSubscribers?: number;
  alertsSent: number;
}

export type AlertStateRecord =
  | ({ t: 'subscribe' } & StoredSubscription)
  | { t: 'unsubscribe'; at: bigint; chainId: number; account: Address; endpoint: string; reason: 'user' | 'gone' }
  | { t: 'cursor'; chainId: number; block: bigint }
  | ({ t: 'item' } & QueuedRecoveryItem)
  | { t: 'attempt'; chainId: number; delay: Address; queueNonce: bigint; at: bigint; kind: AlertKind; delivered: number; subscribers: number }
  | { t: 'closed'; chainId: number; delay: Address; queueNonce: bigint; at: bigint; outcome: 'vetoed-or-executed' | 'expired' | 'reorged' };

const subKey = (chainId: number, account: Address, endpoint: string) => `${chainId}:${account.toLowerCase()}:${endpoint}`;
const itemKey = (chainId: number, delay: Address, nonce: bigint) => `${chainId}:${delay.toLowerCase()}:${nonce}`;
const same = (a: Address, b: Address) => a.toLowerCase() === b.toLowerCase();

/* ------------------------------------------------------------------ the store */

export const DEFAULT_MAX_SUBSCRIPTIONS_PER_ACCOUNT = 10;
export const DEFAULT_MAX_SUBSCRIPTIONS = 200_000;

export class AlertStore {
  private readonly subs = new Map<string, StoredSubscription>();
  private readonly items = new Map<string, QueuedRecoveryItem>();
  private readonly closedKeys = new Set<string>();
  private readonly cursors = new Map<number, bigint>();
  private loaded = false;

  constructor(private readonly journal: Journal<AlertStateRecord>, private readonly o: { maxPerAccount?: number; maxTotal?: number } = {}) {}

  load(): void {
    const records = this.journal.load();
    for (const r of records) this.apply(r);
    this.loaded = true;
    const live = this.snapshot();
    if (this.journal.compact && records.length > 1_000 && records.length > 4 * live.length) this.journal.compact(live);
  }

  close(): void {
    this.journal.close();
  }

  private append(r: AlertStateRecord): void {
    if (!this.loaded) throw new Error('alert store not loaded');
    this.journal.append(r);
    this.apply(r);
  }

  private apply(r: AlertStateRecord): void {
    switch (r.t) {
      case 'subscribe': {
        const { t: _t, ...s } = r;
        this.subs.set(subKey(s.chainId, s.account, s.endpoint), s);
        return;
      }
      case 'unsubscribe':
        this.subs.delete(subKey(r.chainId, r.account, r.endpoint));
        return;
      case 'cursor':
        this.cursors.set(r.chainId, r.block);
        return;
      case 'item': {
        const { t: _t, ...item } = r;
        this.items.set(itemKey(item.chainId, item.delay, item.queueNonce), item);
        return;
      }
      case 'attempt': {
        const item = this.items.get(itemKey(r.chainId, r.delay, r.queueNonce));
        if (!item) return;
        item.lastAttemptAt = r.at;
        item.lastAttemptDelivered = r.delivered;
        item.lastAttemptSubscribers = r.subscribers;
        if (r.delivered > 0) {
          item.lastDeliveredAt = r.at;
          item.alertsSent += 1;
          if (r.kind === 'final') item.finalDelivered = true;
        }
        return;
      }
      case 'closed': {
        const k = itemKey(r.chainId, r.delay, r.queueNonce);
        this.items.delete(k);
        this.closedKeys.add(k);
      }
    }
  }

  /** The current state as records: what a compaction keeps. */
  snapshot(): AlertStateRecord[] {
    return [
      ...[...this.cursors].map(([chainId, block]) => ({ t: 'cursor' as const, chainId, block })),
      ...[...this.subs.values()].map((s) => ({ t: 'subscribe' as const, ...s })),
      ...[...this.items.values()].map((i) => ({ t: 'item' as const, ...i })),
    ];
  }

  subscriptions(chainId: number, account: Address): StoredSubscription[] {
    const prefix = `${chainId}:${account.toLowerCase()}:`;
    return [...this.subs.entries()].filter(([k]) => k.startsWith(prefix)).map(([, s]) => s);
  }

  subscription(chainId: number, account: Address, endpoint: string): StoredSubscription | undefined {
    return this.subs.get(subKey(chainId, account, endpoint));
  }

  get subscriptionCount(): number {
    return this.subs.size;
  }

  subscribe(s: StoredSubscription): { created: boolean } {
    const existing = this.subs.get(subKey(s.chainId, s.account, s.endpoint));
    if (!existing) {
      if (this.subscriptions(s.chainId, s.account).length >= (this.o.maxPerAccount ?? DEFAULT_MAX_SUBSCRIPTIONS_PER_ACCOUNT)) {
        throw new Refusal('too_many_subscriptions', 'this account has as many alert subscriptions as it may; unsubscribe a device first');
      }
      if (this.subs.size >= (this.o.maxTotal ?? DEFAULT_MAX_SUBSCRIPTIONS)) throw new Refusal('too_many_subscriptions', 'this service holds as many alert subscriptions as it may');
    }
    this.append({ t: 'subscribe', ...s });
    return { created: !existing };
  }

  unsubscribe(chainId: number, account: Address, endpoint: string, reason: 'user' | 'gone', at: bigint): boolean {
    if (!this.subs.has(subKey(chainId, account, endpoint))) return false;
    this.append({ t: 'unsubscribe', at, chainId, account, endpoint, reason });
    return true;
  }

  cursor(chainId: number): bigint | undefined {
    return this.cursors.get(chainId);
  }

  setCursor(chainId: number, block: bigint): void {
    if (this.cursors.get(chainId) === block) return;
    this.append({ t: 'cursor', chainId, block });
  }

  has(chainId: number, delay: Address, nonce: bigint): boolean {
    const k = itemKey(chainId, delay, nonce);
    return this.items.has(k) || this.closedKeys.has(k);
  }

  open(chainId: number): QueuedRecoveryItem[] {
    return [...this.items.values()].filter((i) => i.chainId === chainId);
  }

  openFor(chainId: number, account: Address): QueuedRecoveryItem[] {
    return this.open(chainId).filter((i) => same(i.account, account));
  }

  addItem(item: Omit<QueuedRecoveryItem, 'alertsSent'>): void {
    this.append({ t: 'item', ...item, alertsSent: 0 });
  }

  recordAttempt(item: QueuedRecoveryItem, at: bigint, kind: AlertKind, delivered: number, subscribers: number): void {
    this.append({ t: 'attempt', chainId: item.chainId, delay: item.delay, queueNonce: item.queueNonce, at, kind, delivered, subscribers });
  }

  closeItem(item: QueuedRecoveryItem, at: bigint, outcome: 'vetoed-or-executed' | 'expired' | 'reorged'): void {
    this.append({ t: 'closed', chainId: item.chainId, delay: item.delay, queueNonce: item.queueNonce, at, outcome });
  }
}

/* ------------------------------------------------------------------ when to alert */

export interface AlertSchedule {
  realertSeconds: number;
  finalNoticeSeconds: number;
  retrySeconds: number;
}

export const DEFAULT_ALERT_SCHEDULE: AlertSchedule = Object.freeze({ realertSeconds: 86_400, finalNoticeSeconds: 86_400, retrySeconds: 900 });

/**
 * The alert due for an open item at chain time `now`, or undefined. Nothing is due without a subscriber; an attempt
 * that reached nobody is retried after `retrySeconds`, and a first subscriber gets the alert at once.
 */
export function dueAlert(item: QueuedRecoveryItem, now: bigint, subscribers: number, s: AlertSchedule = DEFAULT_ALERT_SCHEDULE): AlertKind | undefined {
  if (subscribers === 0) return undefined;
  const failedAttempt = item.lastAttemptAt !== undefined && item.lastAttemptDelivered === 0 && (item.lastAttemptSubscribers ?? 0) > 0;
  if (failedAttempt && now < item.lastAttemptAt! + BigInt(s.retrySeconds)) return undefined;
  const inFinalWindow = now + BigInt(s.finalNoticeSeconds) >= item.executableAt;
  if (item.lastDeliveredAt === undefined) return inFinalWindow ? 'final' : 'queued';
  if (inFinalWindow && !item.finalDelivered) return 'final';
  if (now >= item.lastDeliveredAt + BigInt(s.realertSeconds)) return 'daily';
  return undefined;
}

export function recoveryAlertPayload(kind: AlertKind, executableAt: bigint): RecoveryAlertPayload {
  return { v: 1, type: 'mova.recovery-requested', title: RECOVERY_ALERT_TEXT.title, body: RECOVERY_ALERT_TEXT.body, kind, executableAt: Number(executableAt), tag: 'mova-recovery' };
}

/* ------------------------------------------------------------------ the routes */

export interface AlertSubscribeRequest {
  chainId: number;
  account: Address;
  subscription: { endpoint: string; keys: { p256dh: string; auth: string } };
  issuedAt: number;
  passkeySignature: Hex;
}

export interface AlertUnsubscribeRequest {
  chainId: number;
  account: Address;
  endpoint: string;
  issuedAt: number;
  passkeySignature: Hex;
}

export interface RecoveryAlertsOptions {
  chainId: number;
  coSigner: Address;
  audit: AuditLog;
  store: AlertStore;
  chain: Pick<AccountReader, 'delay'>;
  webauthn: WebAuthnPolicy;
  vapid: VapidKeys;
  /** `mailto:` or `https:` contact given to push services. */
  subject: string;
  allowedHosts?: readonly string[];
  /** Development only: any http(s) endpoint. The entrypoint refuses it in production. */
  allowInsecureEndpoints?: boolean;
  /** Replaces the network send (tests). */
  send?: (target: PushTarget, payload: string) => Promise<PushOutcome>;
  fetch?: typeof fetch;
  /** Unix seconds, wall clock: proof freshness and audit records. */
  now?: () => bigint;
  nowMs?: () => number;
  proofMaxSkewSeconds?: number;
  rateLimit?: { burst: number; perMinute: number };
  metrics?: CoSignerMetrics;
  log?: Logger;
}

const silent: Logger = { info: () => {}, warn: () => {}, error: () => {} };

export class RecoveryAlerts {
  private readonly used = new Map<string, bigint>();
  private readonly limiter: RateLimiter;
  private readonly log: Logger;

  constructor(readonly o: RecoveryAlertsOptions) {
    this.limiter = new RateLimiter({ ...(o.rateLimit ?? { burst: 5, perMinute: 10 }), now: o.nowMs });
    this.log = o.log ?? silent;
    o.metrics?.set('mova_cosigner_push_subscriptions', o.store.subscriptionCount);
  }

  private now(): bigint {
    return this.o.now ? this.o.now() : BigInt(Math.floor(Date.now() / 1000));
  }

  info() {
    return {
      vapidPublicKey: this.o.vapid.publicKey, subscribeTypehash: ALERTS_SUBSCRIBE_TYPEHASH, unsubscribeTypehash: ALERTS_UNSUBSCRIBE_TYPEHASH,
      maxProofAgeSeconds: this.o.proofMaxSkewSeconds ?? 300,
    };
  }

  /** One encrypted message to one device. */
  send(target: PushTarget, payload: string): Promise<PushOutcome> {
    if (this.o.send) return this.o.send(target, payload);
    return sendWebPush(target, payload, { vapid: this.o.vapid, subject: this.o.subject, topic: 'mova-recovery', urgency: 'high', ttlSeconds: 86_400, fetch: this.o.fetch });
  }

  async subscribe(req: AlertSubscribeRequest, e: Enrolment, caller: Caller): Promise<{ subscribed: true; created: boolean; pending: number }> {
    try {
      let host: string;
      try {
        host = checkPushEndpoint(req.subscription.endpoint, { allowedHosts: this.o.allowedHosts, allowInsecure: this.o.allowInsecureEndpoints }).host;
      } catch (err) {
        throw new Refusal('push_endpoint_refused', err instanceof WebPushError ? err.message : 'the endpoint is refused');
      }
      const challenge = alertsSubscribeChallenge(req.chainId, e.account, this.o.coSigner, req.issuedAt, req.subscription);
      this.proof(e, challenge, req.issuedAt, req.passkeySignature);
      const { created } = this.o.store.subscribe({
        chainId: req.chainId, account: e.account, endpoint: req.subscription.endpoint, p256dh: req.subscription.keys.p256dh,
        auth: req.subscription.keys.auth, at: this.now(), client: caller.client,
      });
      this.audit({ chainId: req.chainId, account: e.account, client: caller.client, event: 'subscribed', service: host });
      this.o.metrics?.set('mova_cosigner_push_subscriptions', this.o.store.subscriptionCount);
      return { subscribed: true, created, pending: this.o.store.openFor(req.chainId, e.account).length };
    } catch (err) {
      throw this.refused(err, e, caller);
    }
  }

  async unsubscribe(req: AlertUnsubscribeRequest, e: Enrolment, caller: Caller): Promise<{ unsubscribed: true }> {
    try {
      const challenge = alertsUnsubscribeChallenge(req.chainId, e.account, this.o.coSigner, req.issuedAt, req.endpoint);
      this.proof(e, challenge, req.issuedAt, req.passkeySignature);
      const sub = this.o.store.subscription(req.chainId, e.account, req.endpoint);
      if (!sub) throw new Refusal('subscription_unknown', 'that device is not subscribed to this account\'s alerts');
      const delay = await this.o.chain.delay(e.delay);
      const queued = (delay && same(delay.owner, e.account) && delay.queueNonce > delay.txNonce) || this.o.store.openFor(req.chainId, e.account).length > 0;
      if (queued) {
        throw new Refusal('recovery_pending', 'the account has a queued recovery transaction: veto it (or let it resolve) before turning its alerts off');
      }
      this.o.store.unsubscribe(req.chainId, e.account, req.endpoint, 'user', this.now());
      this.audit({ chainId: req.chainId, account: e.account, client: caller.client, event: 'unsubscribed', service: hostOf(req.endpoint) });
      this.o.metrics?.set('mova_cosigner_push_subscriptions', this.o.store.subscriptionCount);
      // A last notice to the device, so turning alerts off is never silent to whoever holds it.
      const off: RecoveryAlertPayload = { v: 1, type: 'mova.alerts-off', title: RECOVERY_ALERT_TEXT.title, body: RECOVERY_ALERT_TEXT.alertsOff, tag: 'mova-recovery' };
      await this.send({ endpoint: sub.endpoint, keys: { p256dh: sub.p256dh, auth: sub.auth } }, JSON.stringify(off)).catch(() => undefined);
      return { unsubscribed: true };
    } catch (err) {
      throw this.refused(err, e, caller);
    }
  }

  /** A fresh, unused, user-verified assertion by the account's passkey over `challenge`. */
  private proof(e: Enrolment, challenge: Hex, issuedAt: number, signature: Hex): void {
    const now = this.now();
    const skew = BigInt(this.o.proofMaxSkewSeconds ?? 300);
    if (BigInt(issuedAt) > now + skew || BigInt(issuedAt) < now - skew) {
      throw new Refusal('proof_expired', `the passkey assertion must be issued within ${skew} seconds of now`);
    }
    if (!signature || signature === '0x') throw new Refusal('passkey_required', 'alert subscriptions need a fresh assertion by the account\'s passkey');
    const verdict = verifyWebAuthnSignature(challenge, signature, e.passkey, this.o.webauthn);
    if (!verdict.ok) throw new Refusal('bad_passkey_signature', verdict.reason);
    for (const [k, exp] of this.used) if (exp < now) this.used.delete(k);
    if (this.used.has(challenge)) throw new Refusal('replayed', 'this passkey assertion was already used');
    if (!this.limiter.take(`${e.chainId}:${e.account.toLowerCase()}`)) throw new Refusal('rate_limited', 'too many alert requests for this account');
    this.used.set(challenge, BigInt(issuedAt) + skew + 1n);
  }

  private audit(r: Omit<AlertRecord, 't' | 'at'>): void {
    const rec: AlertRecord = { t: 'alert', at: this.now(), ...r };
    for (const k of Object.keys(rec) as (keyof AlertRecord)[]) if (rec[k] === undefined) delete rec[k];
    this.o.audit.append(rec);
    this.o.metrics?.set('mova_cosigner_audit_records', this.o.audit.records);
  }

  private refused(err: unknown, e: Enrolment, caller: Caller): unknown {
    if (err instanceof Refusal && err.code !== 'rate_limited' && err.code !== 'malformed') {
      try {
        this.audit({ chainId: e.chainId, account: e.account, client: caller.client, event: 'refused', code: err.code });
      } catch (auditErr) {
        this.log.error(`audit log append failed for an alert refusal: ${auditErr instanceof Error ? auditErr.message : String(auditErr)}`);
      }
    }
    return err;
  }
}

const hostOf = (endpoint: string): string | undefined => {
  try {
    return new URL(endpoint).host;
  } catch {
    return undefined;
  }
};

/* ------------------------------------------------------------------ wire parsing */

function obj(v: unknown, what: string): Record<string, unknown> {
  if (!v || typeof v !== 'object' || Array.isArray(v)) throw new Refusal('malformed', `${what} must be a JSON object`);
  return v as Record<string, unknown>;
}

function common(o: Record<string, unknown>): { chainId: number; account: Address; issuedAt: number; passkeySignature: Hex } {
  if (!Number.isSafeInteger(o.chainId)) throw new Refusal('malformed', 'chainId must be an integer');
  if (typeof o.account !== 'string' || !isAddress(o.account, { strict: false })) throw new Refusal('malformed', 'account must be an address');
  if (!Number.isSafeInteger(o.issuedAt)) throw new Refusal('malformed', 'issuedAt must be unix seconds');
  const passkeySignature = o.passkeySignature ?? '0x';
  if (typeof passkeySignature !== 'string' || !isHex(passkeySignature) || size(passkeySignature) > 8 * 1024) throw new Refusal('malformed', 'passkeySignature must be hex');
  return { chainId: o.chainId as number, account: getAddress(o.account), issuedAt: o.issuedAt as number, passkeySignature: passkeySignature as Hex };
}

function endpointOf(v: unknown): string {
  if (typeof v !== 'string' || v.length === 0 || v.length > 1024) throw new Refusal('malformed', 'endpoint must be a URL of at most 1024 characters');
  return v;
}

export function parseAlertSubscribeRequest(body: unknown): AlertSubscribeRequest {
  const o = obj(body, 'the request');
  const s = obj(o.subscription, 'subscription');
  const keys = obj(s.keys, 'subscription.keys');
  if (typeof keys.p256dh !== 'string' || typeof keys.auth !== 'string') throw new Refusal('malformed', 'subscription.keys carries p256dh and auth');
  const p256dh = canonicalB64url(keys.p256dh);
  const auth = canonicalB64url(keys.auth);
  try {
    const point = b64urlDecode(p256dh, 'p256dh');
    if (point.length !== 65 || point[0] !== 0x04) throw new Error('length');
    ECDH.convertKey(point, 'prime256v1', undefined, undefined, 'uncompressed');
    if (b64urlDecode(auth, 'auth').length !== 16) throw new Error('auth');
  } catch {
    throw new Refusal('malformed', 'subscription.keys must be a P-256 public key (65 bytes) and a 16-byte auth secret, base64url');
  }
  return { ...common(o), subscription: { endpoint: endpointOf(s.endpoint), keys: { p256dh, auth } } };
}

export function parseAlertUnsubscribeRequest(body: unknown): AlertUnsubscribeRequest {
  const o = obj(body, 'the request');
  return { ...common(o), endpoint: endpointOf(o.endpoint) };
}

/* ------------------------------------------------------------------ the watcher */

export interface DelayState {
  txNonce: bigint;
  queueNonce: bigint;
  cooldown: bigint;
  expiration: bigint;
}

export interface TransactionAddedLog {
  delay: Address;
  queueNonce: bigint;
  txHash: Hex;
  blockNumber: bigint;
}

/** What the watcher reads. `ViemDelayLogSource` is the RPC implementation. */
export interface DelayLogSource {
  head(): Promise<{ number: bigint; timestamp: bigint }>;
  /** Every Delay's `TransactionAdded` in [fromBlock, toBlock]; the watcher keeps its own accounts'. */
  transactionAdded(fromBlock: bigint, toBlock: bigint): Promise<TransactionAddedLog[]>;
  /** The Delay's state at `blockNumber`; undefined where it has no code. */
  delayState(delay: Address, blockNumber: bigint): Promise<DelayState | undefined>;
  txCreatedAt(delay: Address, nonce: bigint, blockNumber: bigint): Promise<bigint>;
}

const TRANSACTION_ADDED_EVENT = getAbiItem({ abi: DELAY_ABI, name: 'TransactionAdded' });

export class ViemDelayLogSource implements DelayLogSource {
  constructor(private readonly client: Pick<PublicClient, 'getBlock' | 'getLogs' | 'readContract' | 'getCode'>) {}

  async head() {
    const b = await this.client.getBlock({ blockTag: 'latest' });
    return { number: b.number, timestamp: b.timestamp };
  }

  async transactionAdded(fromBlock: bigint, toBlock: bigint): Promise<TransactionAddedLog[]> {
    const logs = await this.client.getLogs({ event: TRANSACTION_ADDED_EVENT as never, fromBlock, toBlock, strict: true });
    return (logs as unknown as { address: Address; blockNumber: bigint; args: { queueNonce: bigint; txHash: Hex } }[])
      .map((l) => ({ delay: getAddress(l.address), queueNonce: l.args.queueNonce, txHash: l.args.txHash, blockNumber: l.blockNumber }));
  }

  async delayState(delay: Address, blockNumber: bigint): Promise<DelayState | undefined> {
    const code = await this.client.getCode({ address: delay, blockNumber });
    if (!code || code === '0x') return undefined;
    const read = (functionName: 'txNonce' | 'queueNonce' | 'txCooldown' | 'txExpiration') =>
      this.client.readContract({ address: delay, abi: DELAY_ABI, functionName, blockNumber }) as Promise<bigint>;
    const [txNonce, queueNonce, cooldown, expiration] = await Promise.all([read('txNonce'), read('queueNonce'), read('txCooldown'), read('txExpiration')]);
    return { txNonce, queueNonce, cooldown, expiration };
  }

  txCreatedAt(delay: Address, nonce: bigint, blockNumber: bigint): Promise<bigint> {
    return this.client.readContract({ address: delay, abi: DELAY_ABI, functionName: 'txCreatedAt', args: [nonce], blockNumber }) as Promise<bigint>;
  }
}

export interface RecoveryWatcherOptions {
  chainId: number;
  audit: AuditLog;
  store: AlertStore;
  source: DelayLogSource;
  alerts: Pick<RecoveryAlerts, 'send'>;
  /** Blocks on top of a log before it counts. Default 3. */
  confirmations?: number;
  /** Largest getLogs range. Default 2000. */
  maxBlockRange?: number;
  /** Where to start without a persisted cursor; default the earliest enrolment's block. */
  startBlock?: bigint;
  schedule?: Partial<AlertSchedule>;
  /** Tries per delivery for 429/5xx/network failures. Default 3. */
  deliveryAttempts?: number;
  retryDelayMs?: (attempt: number) => number;
  sleep?: (ms: number) => Promise<void>;
  /** Accounts whose queue is read from state per tick, the first time the watcher sees them. Default 200. */
  catchUpPerTick?: number;
  now?: () => bigint;
  metrics?: CoSignerMetrics;
  log?: Logger;
  redactValues?: readonly string[];
}

export interface WatchTick {
  block: bigint;
  queued: number;
  alerts: number;
  closed: number;
}

export class RecoveryWatcher {
  private readonly caughtUp = new Set<string>();
  private readonly schedule: AlertSchedule;
  private readonly log: Logger;
  private timer?: NodeJS.Timeout;
  private current?: Promise<unknown>;
  private stopped = false;

  constructor(private readonly o: RecoveryWatcherOptions) {
    this.schedule = { ...DEFAULT_ALERT_SCHEDULE, ...o.schedule };
    this.log = o.log ?? silent;
  }

  private now(): bigint {
    return this.o.now ? this.o.now() : BigInt(Math.floor(Date.now() / 1000));
  }

  /** Poll every `intervalMs`, one tick at a time. */
  start(intervalMs: number): void {
    this.stopped = false;
    const run = async () => {
      this.current = this.tick().catch((e) => this.log.warn(`recovery watcher: ${redact(e instanceof Error ? e.message.split('\n')[0]! : String(e), this.o.redactValues)}`));
      await this.current;
      if (!this.stopped) this.timer = setTimeout(() => void run(), intervalMs);
    };
    void run();
  }

  async stop(): Promise<void> {
    this.stopped = true;
    if (this.timer) clearTimeout(this.timer);
    await this.current;
  }

  async tick(): Promise<WatchTick> {
    const { chainId, store, source } = this.o;
    const head = await source.head();
    const confirmations = BigInt(this.o.confirmations ?? 3);
    const out: WatchTick = { block: store.cursor(chainId) ?? 0n, queued: 0, alerts: 0, closed: 0 };
    if (head.number < confirmations) return out;
    const safe = head.number - confirmations;
    const enrolments = this.o.audit.allEnrolments().filter((e) => e.chainId === chainId);
    const byDelay = new Map(enrolments.map((e) => [e.delay.toLowerCase(), e] as const));

    // 1. An account seen for the first time: whatever its queue already holds.
    let budget = this.o.catchUpPerTick ?? 200;
    for (const e of enrolments) {
      const k = e.delay.toLowerCase();
      if (this.caughtUp.has(k)) continue;
      if (budget-- <= 0) break;
      const st = await source.delayState(e.delay, safe);
      if (st) {
        for (let n = st.txNonce; n < st.queueNonce; n++) {
          if (store.has(chainId, e.delay, n)) continue;
          await this.add(e, n, undefined, st, safe);
          out.queued++;
        }
      }
      this.caughtUp.add(k);
    }

    // 2. New `TransactionAdded` logs, confirmed, from the cursor on.
    const stored = store.cursor(chainId);
    let cursor: bigint;
    if (stored !== undefined) {
      cursor = stored;
    } else {
      const earliest = enrolments.reduce<bigint | undefined>((m, e) => (m === undefined || e.fromBlock < m ? e.fromBlock : m), undefined);
      cursor = (this.o.startBlock ?? earliest ?? safe + 1n) - 1n;
      if (cursor > safe) cursor = safe;
      if (cursor < -1n) cursor = -1n;
    }
    const range = BigInt(Math.max(1, this.o.maxBlockRange ?? 2_000));
    while (cursor < safe) {
      const to: bigint = cursor + range < safe ? cursor + range : safe;
      for (const log of await source.transactionAdded(cursor + 1n, to)) {
        const e = byDelay.get(log.delay.toLowerCase());
        if (!e || store.has(chainId, log.delay, log.queueNonce)) continue;
        const st = await source.delayState(log.delay, safe);
        if (!st || st.queueNonce <= log.queueNonce) continue;
        await this.add(e, log.queueNonce, log.txHash, st, safe);
        out.queued++;
      }
      store.setCursor(chainId, to);
      cursor = to;
    }
    if (cursor >= 0n) store.setCursor(chainId, cursor);
    out.block = cursor < 0n ? 0n : cursor;
    this.o.metrics?.set('mova_cosigner_recovery_watch_block', Number(out.block));

    // 3. Alerts, and closing what is resolved.
    const states = new Map<string, DelayState | undefined>();
    for (const item of store.open(chainId)) {
      const k = item.delay.toLowerCase();
      if (!states.has(k)) states.set(k, await source.delayState(item.delay, safe));
      const st = states.get(k);
      if (!st) continue;
      if (st.txNonce > item.queueNonce) {
        this.close(item, head.timestamp, 'vetoed-or-executed');
        out.closed++;
        continue;
      }
      if (st.queueNonce <= item.queueNonce) {
        store.closeItem(item, head.timestamp, 'reorged');
        continue;
      }
      if (item.expiresAt !== 0n && head.timestamp > item.expiresAt) {
        this.close(item, head.timestamp, 'expired');
        out.closed++;
        continue;
      }
      const subs = store.subscriptions(chainId, item.account);
      const kind = dueAlert(item, head.timestamp, subs.length, this.schedule);
      if (!kind) continue;
      const payload = JSON.stringify(recoveryAlertPayload(kind, item.executableAt));
      let delivered = 0;
      let failed = 0;
      for (const s of subs) {
        const r = await this.deliver({ endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } }, payload);
        if (r.ok) {
          delivered++;
          this.o.metrics?.inc('mova_cosigner_push_total', { result: 'delivered' });
          continue;
        }
        failed++;
        if (r.gone) {
          store.unsubscribe(chainId, item.account, s.endpoint, 'gone', this.now());
          this.audit({ chainId, account: item.account, event: 'subscription-removed', service: hostOf(s.endpoint), code: r.status === undefined ? undefined : String(r.status) });
          this.o.metrics?.inc('mova_cosigner_push_total', { result: 'gone' });
        } else {
          this.o.metrics?.inc('mova_cosigner_push_total', { result: 'failed' });
          this.log.warn(`recovery alert to ${hostOf(s.endpoint)} for ${item.account} failed: ${r.reason}`);
        }
      }
      store.recordAttempt(item, head.timestamp, kind, delivered, subs.length);
      this.audit({ chainId, account: item.account, event: 'sent', alert: kind, delivered, failed, queueNonce: item.queueNonce });
      out.alerts++;
    }
    this.o.metrics?.set('mova_cosigner_recovery_pending', store.open(chainId).length);
    this.o.metrics?.set('mova_cosigner_push_subscriptions', store.subscriptionCount);
    return out;
  }

  private async add(e: Enrolment, nonce: bigint, txHash: Hex | undefined, st: DelayState, block: bigint): Promise<void> {
    const createdAt = await this.o.source.txCreatedAt(e.delay, nonce, block);
    const executableAt = createdAt + st.cooldown;
    this.o.store.addItem({
      chainId: e.chainId, account: e.account, delay: e.delay, queueNonce: nonce, ...(txHash ? { txHash } : {}),
      createdAt, executableAt, expiresAt: st.expiration === 0n ? 0n : executableAt + st.expiration,
    });
    this.log.warn(`recovery transaction ${nonce} queued on the Delay of ${e.account}: executable at ${executableAt}; alerting its subscribers`);
  }

  private close(item: QueuedRecoveryItem, at: bigint, outcome: 'vetoed-or-executed' | 'expired'): void {
    this.o.store.closeItem(item, at, outcome);
    this.audit({ chainId: item.chainId, account: item.account, event: 'closed', queueNonce: item.queueNonce, outcome });
  }

  private audit(r: Omit<AlertRecord, 't' | 'at'>): void {
    const rec: AlertRecord = { t: 'alert', at: this.now(), ...r };
    for (const k of Object.keys(rec) as (keyof AlertRecord)[]) if (rec[k] === undefined) delete rec[k];
    this.o.audit.append(rec);
  }

  private async deliver(target: PushTarget, payload: string): Promise<PushOutcome> {
    const attempts = Math.max(1, this.o.deliveryAttempts ?? 3);
    let last: PushOutcome = { ok: false, gone: false, retry: false, reason: 'not sent' };
    for (let i = 0; i < attempts; i++) {
      try {
        last = await this.o.alerts.send(target, payload);
      } catch (e) {
        return { ok: false, gone: false, retry: false, reason: e instanceof WebPushError ? e.message : 'the message could not be sent' };
      }
      if (last.ok || !last.retry || i + 1 === attempts) return last;
      const wait = last.retryAfterSeconds !== undefined ? last.retryAfterSeconds * 1000 : (this.o.retryDelayMs ?? ((n) => 1000 * 4 ** n))(i);
      await (this.o.sleep ?? ((ms) => new Promise((r) => setTimeout(r, ms))))(Math.min(wait, 30_000));
    }
    return last;
  }
}
