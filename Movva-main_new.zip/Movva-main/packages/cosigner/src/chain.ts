/**
 * What the co-signer reads from the chain: the account's own record of who its signers are, the EntryPoint
 * nonce, and the recovery Delay. The service never takes a passkey key from a request - it reads the one the
 * account trusts (a Safe owner's SafeWebAuthnSigner configuration, PasskeyCoSignerValidator storage, or the
 * passkey module of the account's Delay) or, for an account not deployed yet, checks a claimed key against the
 * CREATE2 address that commits to it.
 *
 * `AccountReader` is the seam the unit tests replace; `ViemAccountReader` is the RPC implementation.
 */
import {
  getAbiItem, getAddress, parseAbi, type Address, type Hex, type PublicClient,
} from 'viem';
import {
  DELAY_ABI, ENTRYPOINT_ABI, FROST_VALIDATOR_ABI, KERNEL_ABI, KERNEL_AVATAR_ADAPTER_ABI, MAINNET, PASSKEY,
  PASSKEY_COSIGNER_VALIDATOR_ABI, SIGNER_FACTORY_ABI, predictSafeAddress, readRecoveryQueue,
} from '@mova/smart-account';

export interface PasskeyConfig {
  x: bigint;
  y: bigint;
  /** P256.Verifiers (uint176): precompile (high 16 bits) and fallback verifier (low 160). */
  verifiers: bigint;
}

export interface GroupKey {
  x: bigint;
  y: bigint;
}

export interface DelayView {
  address: Address;
  owner: Address;
  avatar: Address;
  txNonce: bigint;
  queueNonce: bigint;
  cooldown: bigint;
  expiration: bigint;
  modules: Address[];
}

export interface QueuedTransaction {
  nonce: bigint;
  txHash: Hex;
  createdAt: bigint;
  executableAt: bigint;
  /** 0 when the Delay has no expiration. */
  expiresAt: bigint;
  /** From the TransactionAdded log, when the RPC served it. */
  call?: { to: Address; value: bigint; data: Hex; operation: number };
}

export interface DelayQueue {
  delay: Address;
  txNonce: bigint;
  queueNonce: bigint;
  cooldown: bigint;
  expiration: bigint;
  pending: QueuedTransaction[];
}

export interface AccountReader {
  head(): Promise<{ number: bigint; timestamp: bigint }>;
  hasCode(address: Address): Promise<boolean>;
  safeOwners(safe: Address): Promise<{ owners: Address[]; threshold: bigint }>;
  safeModules(safe: Address): Promise<Address[]>;
  /** `getConfiguration()` of a deployed SafeWebAuthnSigner proxy; undefined for anything else. */
  webAuthnSignerConfig(signer: Address): Promise<PasskeyConfig | undefined>;
  /** `SafeWebAuthnSignerFactory.getSigner(x, y, verifiers)`: the CREATE2 address that commits to the key. */
  webAuthnSignerAddress(pk: PasskeyConfig): Promise<Address>;
  /** `groupKey()` of a deployed FrostSigner; undefined for anything else. */
  frostSignerKey(signer: Address): Promise<GroupKey | undefined>;
  /** The root validator's address, or undefined when the root is not a plain validator. */
  kernelRootValidator(account: Address): Promise<Address | undefined>;
  passkeyCoSignerConfig(validator: Address, account: Address): Promise<(PasskeyConfig & { coSigner: Address }) | undefined>;
  frostValidatorKey(validator: Address, account: Address): Promise<GroupKey | undefined>;
  kernelAdapterDelay(adapter: Address, account: Address): Promise<Address | undefined>;
  entryPointNonce(account: Address, key: bigint): Promise<bigint>;
  delay(address: Address): Promise<DelayView | undefined>;
  delayQueue(delay: Address, fromBlock: bigint): Promise<DelayQueue>;
  predictSafe(owners: Address[], threshold: number, saltNonce: bigint): Promise<Address>;
}

export const SENTINEL: Address = '0x0000000000000000000000000000000000000001';
const ZERO: Address = '0x0000000000000000000000000000000000000000';

export const SAFE_READ_ABI = parseAbi([
  'function getOwners() view returns (address[])',
  'function getThreshold() view returns (uint256)',
  'function isModuleEnabled(address module) view returns (bool)',
  'function getModulesPaginated(address start, uint256 pageSize) view returns (address[] array, address next)',
]);
export const WEBAUTHN_SIGNER_ABI = parseAbi(['function getConfiguration() view returns (uint256 x, uint256 y, uint176 verifiers)']);
export const FROST_SIGNER_ABI = parseAbi(['function groupKey() view returns ((uint256 x, uint256 y))']);
export const WEBAUTHN_FACTORY_VERIFY_ABI = parseAbi([
  'function isValidSignatureForSigner(bytes32 message, bytes signature, uint256 x, uint256 y, uint176 verifiers) view returns (bytes4)',
]);

type Client = Pick<PublicClient, 'readContract' | 'getCode' | 'getBlock' | 'getLogs'>;

export class ViemAccountReader implements AccountReader {
  constructor(private readonly client: Client, private readonly o: { entryPoint?: Address; modulesPageSize?: number } = {}) {}

  async head() {
    const b = await this.client.getBlock({ blockTag: 'latest' });
    return { number: b.number, timestamp: b.timestamp };
  }

  async hasCode(address: Address) {
    const code = await this.client.getCode({ address });
    return !!code && code !== '0x';
  }

  async safeOwners(safe: Address) {
    const [owners, threshold] = await Promise.all([
      this.client.readContract({ address: safe, abi: SAFE_READ_ABI, functionName: 'getOwners' }),
      this.client.readContract({ address: safe, abi: SAFE_READ_ABI, functionName: 'getThreshold' }),
    ]);
    return { owners: owners.map((a) => getAddress(a)), threshold };
  }

  async safeModules(safe: Address) {
    return this.modules(safe);
  }

  private async modules(address: Address): Promise<Address[]> {
    const [array] = await this.client.readContract({
      address, abi: SAFE_READ_ABI, functionName: 'getModulesPaginated', args: [SENTINEL, BigInt(this.o.modulesPageSize ?? 16)],
    });
    return array.map((a) => getAddress(a));
  }

  async webAuthnSignerConfig(signer: Address) {
    if (!(await this.hasCode(signer))) return undefined;
    try {
      const [x, y, verifiers] = await this.client.readContract({ address: signer, abi: WEBAUTHN_SIGNER_ABI, functionName: 'getConfiguration' });
      return { x, y, verifiers };
    } catch {
      return undefined;
    }
  }

  async webAuthnSignerAddress(pk: PasskeyConfig) {
    return getAddress(await this.client.readContract({
      address: PASSKEY.signerFactory, abi: SIGNER_FACTORY_ABI, functionName: 'getSigner', args: [pk.x, pk.y, pk.verifiers],
    }) as Address);
  }

  async frostSignerKey(signer: Address) {
    if (!(await this.hasCode(signer))) return undefined;
    try {
      const k = await this.client.readContract({ address: signer, abi: FROST_SIGNER_ABI, functionName: 'groupKey' });
      return { x: k.x, y: k.y };
    } catch {
      return undefined;
    }
  }

  async kernelRootValidator(account: Address) {
    try {
      const root = await this.client.readContract({ address: account, abi: KERNEL_ABI, functionName: 'rootValidator' }) as Hex;
      // bytes21: 0x01 ++ validator. 0x02 (permission) or anything else is not a validator this service knows.
      if (root.length !== 44 || !root.toLowerCase().startsWith('0x01')) return undefined;
      return getAddress(`0x${root.slice(4)}`);
    } catch {
      return undefined;
    }
  }

  async passkeyCoSignerConfig(validator: Address, account: Address) {
    try {
      const c = await this.client.readContract({ address: validator, abi: PASSKEY_COSIGNER_VALIDATOR_ABI, functionName: 'configOf', args: [account] });
      if (getAddress(c.coSigner) === ZERO) return undefined;
      return { x: c.x, y: c.y, verifiers: c.verifiers, coSigner: getAddress(c.coSigner) };
    } catch {
      return undefined;
    }
  }

  async frostValidatorKey(validator: Address, account: Address) {
    try {
      const k = await this.client.readContract({ address: validator, abi: FROST_VALIDATOR_ABI, functionName: 'groupKeyOf', args: [account] });
      if (k.x === 0n && k.y === 0n) return undefined;
      return { x: k.x, y: k.y };
    } catch {
      return undefined;
    }
  }

  async kernelAdapterDelay(adapter: Address, account: Address) {
    try {
      const d = getAddress(await this.client.readContract({ address: adapter, abi: KERNEL_AVATAR_ADAPTER_ABI, functionName: 'delayOf', args: [account] }) as Address);
      return d === ZERO ? undefined : d;
    } catch {
      return undefined;
    }
  }

  async entryPointNonce(account: Address, key: bigint) {
    return this.client.readContract({
      address: this.o.entryPoint ?? MAINNET.entryPoint, abi: ENTRYPOINT_ABI, functionName: 'getNonce', args: [account, key],
    }) as Promise<bigint>;
  }

  async delay(address: Address): Promise<DelayView | undefined> {
    if (!(await this.hasCode(address))) return undefined;
    try {
      const read = <T>(functionName: string) => this.client.readContract({ address, abi: DELAY_ABI, functionName: functionName as never }) as Promise<T>;
      const [owner, avatar, txNonce, queueNonce, cooldown, expiration, modules] = await Promise.all([
        read<Address>('owner'), read<Address>('avatar'), read<bigint>('txNonce'), read<bigint>('queueNonce'),
        read<bigint>('txCooldown'), read<bigint>('txExpiration'), this.modules(address),
      ]);
      return { address, owner: getAddress(owner), avatar: getAddress(avatar), txNonce, queueNonce, cooldown, expiration, modules };
    } catch {
      return undefined;
    }
  }

  async delayQueue(delay: Address, fromBlock: bigint): Promise<DelayQueue> {
    const q = await readRecoveryQueue(this.client as unknown as PublicClient, delay);
    const pending = q.pending.map((p) => ({ ...p })) as QueuedTransaction[];
    if (pending.length > 0) {
      try {
        const logs = await this.client.getLogs({
          address: delay, event: getAbiItem({ abi: DELAY_ABI, name: 'TransactionAdded' }), fromBlock, toBlock: 'latest',
        });
        for (const log of logs) {
          const a = log.args as { queueNonce?: bigint; txHash?: Hex; to?: Address; value?: bigint; data?: Hex; operation?: number };
          const p = pending.find((x) => x.nonce === a.queueNonce && x.txHash.toLowerCase() === a.txHash?.toLowerCase());
          if (p && a.to && a.value !== undefined && a.data !== undefined) p.call = { to: getAddress(a.to), value: a.value, data: a.data, operation: Number(a.operation ?? 0) };
        }
      } catch {
        // The queue itself came from state; what each entry does is a best-effort read of the logs.
      }
    }
    return { delay, txNonce: q.txNonce, queueNonce: q.queueNonce, cooldown: q.cooldown, expiration: q.expiration, pending };
  }

  predictSafe(owners: Address[], threshold: number, saltNonce: bigint) {
    return predictSafeAddress(this.client as unknown as PublicClient, owners, threshold, saltNonce);
  }
}
