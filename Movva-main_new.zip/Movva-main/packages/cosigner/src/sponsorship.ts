/**
 * Gasless onboarding without a hot paymaster owner: after a passkey-verified enrolment, the co-signer gets the account
 * ready for its first sponsored operation, from its own operator key. Two modes, by what pays the gas:
 *
 *  - **SponsorGate** (`gate` set): SponsorPaymaster sponsors allowlisted accounts only, so the module allowlists the
 *    account through SponsorGate (contracts/SponsorGate.sol), and creates what the first operation needs.
 *  - **OwnerlessPaymaster** (no gate): the paymaster admits any account its factories created, by CREATE2 address, so
 *    there is nothing to allowlist and no gate to ask. The module only creates what the first operation needs: a Safe's
 *    passkey signer and a Kernel account. Both are permissionless calls on canonical factories, but a user who holds
 *    no ETH cannot send them, and neither can ride in the first operation: a Safe validates that operation through the
 *    signer, so the signer must exist before validation runs, and ERC-7562 allows one CREATE2 in a deployment, the
 *    sender's (OP-031); a Kernel account's initCode through KernelFactory writes the validator's storage during
 *    deployment, which needs a staked factory (STO-022, docs/wallet-custody.md §10.3). docs/ownerless-paymaster.md
 *    weighs this against the other ways.
 *
 * WHAT IT DOES, per enrolment (`request`, called by the enrol route once the enrolment has been verified):
 *
 *   1. idempotency       an account this module is already working on, or has sponsored and is still sponsored:
 *                        the same answer, no transaction
 *   2. never re-add      an account this module sponsored before whose sponsorship is gone on-chain was removed
 *                        by the governor or an operator on purpose: refused (sponsorship_revoked)
 *   3. rate limits       a global token bucket and one per API client (rate_limited), before any chain read
 *   4. the gate          (gate mode) this operator still an operator, the paymaster owned by the gate and bounding
 *                        each account, budget left in the gate's window (operator_revoked, paymaster_not_gated,
 *                        paymaster_unbounded, gate_budget_exhausted)
 *   5. its own cap       at most `dailyCap` accounts in any 24 hours - allowlisted (gate mode, below the gate's
 *                        per-window budget) or, without a gate, every account it sends a transaction for - counted
 *                        from the audit log so a restart remembers (daily_cap)
 *   6. the float         the operator key holds at least `minOperatorBalanceWei` (operator_unfunded)
 *   7. then, serially    for a Kernel account that does not exist yet, `KernelFactory.createAccount` (no operation
 *                        may then carry initCode: a public bundler refuses a Kernel first operation created through
 *                        Kernel's meta factory - docs/wallet-custody.md §10.3); for a Safe whose SafeWebAuthnSigner is
 *                        not deployed yet, `createSigner` through the canonical factory (the Safe validates its first
 *                        operation through it); then, in gate mode, `SponsorGate.sponsor(account)`. One transaction at
 *                        a time from the operator key, through lp-node's TxSender: capped fees, replacement of a stuck
 *                        transaction, its own receipts.
 *
 * WHAT IT NEVER SENDS: factory calldata a request handed it. The only deployment it will send is the one the enrolment
 * itself verified - `initData` and `salt` kept on the enrolment record - rebuilt here into a `createAccount` call on the
 * canonical KernelFactory, and only after recomputing the CREATE2 address from it and finding the enrolled account
 * (`deployment_mismatch` otherwise). An account that already has code is never deployed again: the code is re-read
 * immediately before the send, so a second enrolment, another replica or the user's own deployment all stop it.
 *
 * Every decision but a rate-limit refusal is an audit record (`t: 'sponsor'`), with the transaction hashes.
 *
 * WHAT IT NEEDS FROM THE USER: nothing the protocol does not already carry. The enrolment is the account, its
 * deployment and a passkey assertion; sponsorship adds no identifier, and its limits are keyed by API client and
 * globally - never by passkey, user or device - so a sale account enrolled from a fresh key is not tied to the
 * user's account by anything this module stores. What remains is timing: see docs/wallet-custody.md §11.
 */
import { encodeFunctionData, getAddress, parseAbi, type Address, type Hex, type PublicClient } from 'viem';
import { KERNEL_FACTORY_ABI, KERNEL_V3_1, PASSKEY, SIGNER_FACTORY_ABI, predictKernelAddress } from '@mova/smart-account';
import type { SentReceipt, TxRequest } from '@mova/lp-node/src/tx-sender.js';
import { redact } from '@mova/ops/redact';
import type { AuditLog, Enrolment, SponsorRecord } from './audit.js';
import type { CoSignerMetrics } from './metrics.js';
import { RateLimiter } from './rate-limit.js';
import type { Caller, Logger } from './service.js';

export const SPONSOR_GATE_ABI = parseAbi([
  'function sponsor(address account)',
  'function sponsorBatch(address[] accounts)',
  'function unsponsor(address account)',
  'function isOperator(address operator) view returns (bool)',
  'function remainingSponsorships() view returns (uint256)',
  'function maxSponsorsPerWindow() view returns (uint32)',
  'function windowEndsAt() view returns (uint256)',
  'function governor() view returns (address)',
  'function guardian() view returns (address)',
  'function PAYMASTER() view returns (address)',
  'function withdrawTo(address to, uint256 amount)',
  'error NotGovernor()',
  'error NotOperator()',
  'error ZeroAddress()',
  'error SponsorBudgetExhausted(uint256 wanted, uint256 remaining)',
  'error BatchTooLarge(uint256 length, uint256 max)',
  'error PaymasterUnbounded()',
]);

export const PAYMASTER_READ_ABI = parseAbi([
  'function owner() view returns (address)',
  'function sponsored(address account) view returns (bool)',
  'function maxCostAllowed() view returns (uint256)',
  'function budgetWindow() view returns (uint256)',
  'function defaultBudget() view returns (uint256)',
]);

export interface GateReading {
  isOperator: boolean;
  remaining: bigint;
  maxPerWindow: bigint;
  paymaster: Address;
  paymasterOwner: Address;
  /** The paymaster enforces a per-operation cost limit and a per-account budget; the gate refuses operators otherwise. */
  bounded: boolean;
}

/** What the module reads and sends. `ViemSponsorChain` is the RPC implementation; tests replace it. */
export interface SponsorChain {
  /** The SponsorGate. Undefined with an OwnerlessPaymaster: nothing is allowlisted, and the gate calls are never made. */
  readonly gate?: Address;
  readonly operator: Address;
  readGate(): Promise<GateReading>;
  isSponsored(account: Address): Promise<boolean>;
  hasCode(address: Address): Promise<boolean>;
  operatorBalance(): Promise<bigint>;
  /** `SafeWebAuthnSignerFactory.createSigner`, mined. Returns the transaction hash. */
  createSigner(passkey: { x: bigint; y: bigint; verifiers: bigint }): Promise<Hex>;
  /** `KernelFactory.createAccount(initData, salt)`, mined: the deployment the caller has already re-checked. */
  createKernelAccount(deployment: EnrolledKernelDeployment): Promise<Hex>;
  /** `SponsorGate.sponsor`, mined. Returns the transaction hash. */
  sponsor(account: Address): Promise<Hex>;
}

/** The two fields an enrolment keeps of a counterfactual Kernel account's deployment; its address commits to both. */
export type EnrolledKernelDeployment = NonNullable<Enrolment['kernelDeployment']>;

export class SponsorTransactionFailed extends Error {
  override readonly name = 'SponsorTransactionFailed';
  constructor(readonly hash: Hex | undefined, readonly reason: string) {
    super(`the transaction ${hash ?? ''} failed: ${reason}`);
  }
}

type Reader = Pick<PublicClient, 'readContract' | 'getBalance' | 'getCode'>;

export class ViemSponsorChain implements SponsorChain {
  private paymaster?: Address;

  constructor(private readonly o: {
    client: Reader;
    /** lp-node's TxSender over the operator account. */
    sender: { sendAndWait(req: TxRequest): Promise<SentReceipt> };
    /** The SponsorGate; omitted with an OwnerlessPaymaster, which allowlists nothing. */
    gate?: Address;
    operator: Address;
    signerFactory?: Address;
    /** Kernel v3.1's KernelFactory by default; the address `predictKernelAddress` assumes. */
    kernelFactory?: Address;
  }) {}

  get gate(): Address | undefined {
    return this.o.gate === undefined ? undefined : getAddress(this.o.gate);
  }

  get operator(): Address {
    return getAddress(this.o.operator);
  }

  private requireGate(): Address {
    const gate = this.gate;
    if (!gate) throw new Error('no SponsorGate is configured: this deployment allowlists nothing');
    return gate;
  }

  /** The gate's paymaster is immutable: read once. */
  private async paymasterAddress(): Promise<Address> {
    this.paymaster ??= getAddress(await this.o.client.readContract({ address: this.requireGate(), abi: SPONSOR_GATE_ABI, functionName: 'PAYMASTER' }));
    return this.paymaster;
  }

  async readGate(): Promise<GateReading> {
    const gate = this.requireGate();
    const paymaster = await this.paymasterAddress();
    const c = this.o.client;
    const [isOperator, remaining, maxPerWindow, owner, maxCost, window, budget] = await Promise.all([
      c.readContract({ address: gate, abi: SPONSOR_GATE_ABI, functionName: 'isOperator', args: [this.operator] }),
      c.readContract({ address: gate, abi: SPONSOR_GATE_ABI, functionName: 'remainingSponsorships' }),
      c.readContract({ address: gate, abi: SPONSOR_GATE_ABI, functionName: 'maxSponsorsPerWindow' }),
      c.readContract({ address: paymaster, abi: PAYMASTER_READ_ABI, functionName: 'owner' }),
      c.readContract({ address: paymaster, abi: PAYMASTER_READ_ABI, functionName: 'maxCostAllowed' }),
      c.readContract({ address: paymaster, abi: PAYMASTER_READ_ABI, functionName: 'budgetWindow' }),
      c.readContract({ address: paymaster, abi: PAYMASTER_READ_ABI, functionName: 'defaultBudget' }),
    ]);
    return {
      isOperator, remaining, maxPerWindow: BigInt(maxPerWindow), paymaster, paymasterOwner: getAddress(owner),
      bounded: maxCost !== 0n && window !== 0n && budget !== 0n,
    };
  }

  async isSponsored(account: Address): Promise<boolean> {
    return this.o.client.readContract({ address: await this.paymasterAddress(), abi: PAYMASTER_READ_ABI, functionName: 'sponsored', args: [account] });
  }

  async hasCode(address: Address): Promise<boolean> {
    const code = await this.o.client.getCode({ address });
    return !!code && code !== '0x';
  }

  operatorBalance(): Promise<bigint> {
    return this.o.client.getBalance({ address: this.operator });
  }

  createSigner(pk: { x: bigint; y: bigint; verifiers: bigint }): Promise<Hex> {
    return this.mined({
      to: this.o.signerFactory ?? PASSKEY.signerFactory,
      data: encodeFunctionData({ abi: SIGNER_FACTORY_ABI, functionName: 'createSigner', args: [pk.x, pk.y, pk.verifiers] }),
    });
  }

  createKernelAccount(d: EnrolledKernelDeployment): Promise<Hex> {
    return this.mined({
      to: this.o.kernelFactory ?? KERNEL_V3_1.factory,
      data: encodeFunctionData({ abi: KERNEL_FACTORY_ABI, functionName: 'createAccount', args: [d.initData, d.salt] }),
    });
  }

  sponsor(account: Address): Promise<Hex> {
    return this.mined({ to: this.requireGate(), data: encodeFunctionData({ abi: SPONSOR_GATE_ABI, functionName: 'sponsor', args: [account] }), abi: SPONSOR_GATE_ABI });
  }

  private async mined(req: TxRequest): Promise<Hex> {
    const r = await this.o.sender.sendAndWait(req);
    if (r.status !== 'success') throw new SponsorTransactionFailed(r.transactionHash, r.revertReason ?? 'reverted');
    return r.transactionHash;
  }
}

export type SponsorshipCode =
  | 'sponsorship_revoked' | 'rate_limited' | 'operator_revoked' | 'paymaster_not_gated' | 'paymaster_unbounded'
  | 'gate_budget_exhausted' | 'daily_cap' | 'operator_unfunded' | 'transaction_failed' | 'chain_unavailable'
  | 'deployment_mismatch';

export interface SponsorshipView {
  chainId: number;
  account: Address;
  /**
   * pending: queued or being sent; sponsored: everything the account's first operation needs exists - a Safe's passkey
   * signer, a Kernel account's own code - and, in gate mode, the account is allowlisted. Without a gate the
   * OwnerlessPaymaster admits the account by its address; the status keeps its name, so clients need no second path.
   */
  status: 'pending' | 'sponsored' | 'refused' | 'failed' | 'none';
  code?: SponsorshipCode;
  message?: string;
  /** Whether enrolling again later may succeed. */
  retryable?: boolean;
  signerTx?: Hex;
  /** The Kernel account's creation, when this service sent it; absent when it already had code. */
  accountTx?: Hex;
  /** The allowlisting through SponsorGate; never present without a gate. */
  sponsorTx?: Hex;
}

export interface SponsorshipOptions {
  chainId: number;
  chain: SponsorChain;
  audit: AuditLog;
  /**
   * The OwnerlessPaymaster the deployment's accounts use, when the chain has no gate: reported on /v1/info, never called.
   * Refused beside a gate (a deployment has one paymaster).
   */
  ownerlessPaymaster?: Address;
  /**
   * At most this many accounts in any 24 hours: allowlisted (keep it below the gate's `maxSponsorsPerWindow`) or, without
   * a gate, every account this module sends a transaction for. Without a gate it is what bounds the operator key's spend:
   * at most `dailyCap` passkey signers or Kernel accounts created a day.
   */
  dailyCap: number;
  /** Across all clients. Default 5 at once, 10 a minute. */
  rateLimit?: { burst: number; perMinute: number };
  /** Per API client. Default 3 at once, 5 a minute. */
  clientRateLimit?: { burst: number; perMinute: number };
  /** Refuse below this operator balance. Default 0.01 ETH. */
  minOperatorBalanceWei?: bigint;
  /** Unix seconds (audit records, the daily cap). */
  now?: () => bigint;
  nowMs?: () => number;
  metrics?: CoSignerMetrics;
  log?: Logger;
  /** Values never to write into an audit reason or a log line (the RPC URL). */
  redactValues?: readonly string[];
}

export const DEFAULT_SPONSOR_RATE_LIMIT = Object.freeze({ burst: 5, perMinute: 10 });
export const DEFAULT_SPONSOR_CLIENT_RATE_LIMIT = Object.freeze({ burst: 3, perMinute: 5 });
export const DEFAULT_MIN_OPERATOR_BALANCE_WEI = 10n ** 16n;

const DAY = 86_400n;
const keyOf = (chainId: number, account: Address) => `${chainId}:${account.toLowerCase()}`;
const same = (a: Address, b: Address) => a.toLowerCase() === b.toLowerCase();
const silent: Logger = { info: () => {}, warn: () => {}, error: () => {} };

interface Work {
  /** Create the Safe's SafeWebAuthnSigner. */
  signer: boolean;
  /** Create the Kernel account itself, from the deployment the enrolment verified. */
  account?: EnrolledKernelDeployment;
  sponsor: boolean;
  /** Counted against the daily cap, and reserved while in flight. */
  counted: boolean;
}

/**
 * The deployment this module may send for `e`, or undefined when there is nothing to send: not a Kernel account, or one
 * enrolled when it already had code, so no deployment was ever verified for it.
 *
 * Throws when the kept deployment does not create the enrolled account. Nothing a request carries reaches the factory:
 * this is the enrolment's own `initData` and `salt`, checked again here against the address they must produce, so a
 * tampered or truncated audit line cannot turn into a factory call for someone else's address.
 */
function verifiedKernelDeployment(e: Enrolment): EnrolledKernelDeployment | undefined {
  if (e.kind !== 'kernel-passkey' && e.kind !== 'kernel-frost') return undefined;
  const d = e.kernelDeployment;
  if (!d) return undefined;
  if (predictKernelAddress({ initData: d.initData, salt: d.salt }).toLowerCase() !== e.account.toLowerCase()) {
    throw new DeploymentMismatch(e.account);
  }
  return d;
}

class DeploymentMismatch extends Error {
  override readonly name = 'DeploymentMismatch';
  constructor(readonly account: Address) {
    super(`the enrolled deployment does not create ${account}`);
  }
}

export class SponsorshipModule {
  private readonly views = new Map<string, SponsorshipView>();
  private readonly inFlight = new Set<string>();
  private reserved = 0;
  private tail: Promise<void> = Promise.resolve();
  private readonly global: RateLimiter;
  private readonly perClient: RateLimiter;
  private readonly log: Logger;

  constructor(private readonly o: SponsorshipOptions) {
    if (!Number.isSafeInteger(o.dailyCap) || o.dailyCap < 0) throw new Error('the sponsorship daily cap must be a non-negative integer');
    if (o.ownerlessPaymaster && o.chain.gate) throw new Error('a SponsorGate and an OwnerlessPaymaster: a deployment sponsors through one of them');
    this.global = new RateLimiter({ ...(o.rateLimit ?? DEFAULT_SPONSOR_RATE_LIMIT), now: o.nowMs });
    this.perClient = new RateLimiter({ ...(o.clientRateLimit ?? DEFAULT_SPONSOR_CLIENT_RATE_LIMIT), now: o.nowMs, maxKeys: 1_000 });
    this.log = o.log ?? silent;
  }

  get gate(): Address | undefined {
    return this.o.chain.gate;
  }

  get ownerlessPaymaster(): Address | undefined {
    return this.o.ownerlessPaymaster === undefined ? undefined : getAddress(this.o.ownerlessPaymaster);
  }

  /** Whether accounts are allowlisted through a SponsorGate, or (no gate: an OwnerlessPaymaster) only prepared. */
  get gated(): boolean {
    return this.o.chain.gate !== undefined;
  }

  get operator(): Address {
    return this.o.chain.operator;
  }

  get dailyCap(): number {
    return this.o.dailyCap;
  }

  private now(): bigint {
    return this.o.now ? this.o.now() : BigInt(Math.floor(Date.now() / 1000));
  }

  /** Resolves once every admitted sponsorship has finished (tests, shutdown). */
  idle(): Promise<void> {
    return this.tail;
  }

  /** What is known about an account's sponsorship: this process's view, else the audit log's. */
  view(chainId: number, account: Address): SponsorshipView {
    const v = this.views.get(keyOf(chainId, account));
    if (v) return v;
    if (this.o.audit.sponsoredByService(chainId, account) !== undefined || this.o.audit.preparedByService(chainId, account) !== undefined) {
      return { chainId, account: getAddress(account), status: 'sponsored' };
    }
    return { chainId, account: getAddress(account), status: 'none' };
  }

  /** Sponsor an enrolled account, if the limits allow. Returns at once; the transactions run in the background. */
  async request(e: Enrolment, caller: Caller): Promise<SponsorshipView> {
    const key = keyOf(e.chainId, e.account);
    const current = this.views.get(key);
    if (this.inFlight.has(key) && current) return current;
    const base = { chainId: e.chainId, account: e.account };
    let deployment: EnrolledKernelDeployment | undefined;
    try {
      deployment = verifiedKernelDeployment(e);
    } catch {
      this.log.error(`sponsorship of ${e.account}: the enrolled Kernel deployment does not create that address; nothing sent`);
      return this.settle(e, caller, {
        ...base, status: 'refused', code: 'deployment_mismatch', retryable: false,
        message: 'the deployment recorded for this account does not create its address, so this service will not send it',
      });
    }
    try {
      const before = this.o.audit.sponsoredByService(e.chainId, e.account);
      if (!this.global.take('all') || !this.perClient.take(caller.client)) {
        return this.settle(e, caller, { ...base, status: 'refused', code: 'rate_limited', retryable: true, message: 'too many sponsorship requests: enrol again shortly' }, false);
      }
      const gated = this.gated;
      const [sponsored, signerDeployed, accountDeployed] = await Promise.all([
        // Without a gate nothing is allowlisted: the OwnerlessPaymaster admits the account by its CREATE2 address.
        gated ? this.o.chain.isSponsored(e.account) : Promise.resolve(true),
        e.kind === 'safe-passkey' ? this.o.chain.hasCode(e.passkeySigner) : Promise.resolve(true),
        deployment ? this.o.chain.hasCode(e.account) : Promise.resolve(true),
      ]);
      if (sponsored && signerDeployed && accountDeployed) {
        const view: SponsorshipView = { ...base, status: 'sponsored' };
        // Recorded once per process: an identical enrolment repeated is not a new decision.
        if (current?.status !== 'sponsored') this.record(e, caller, { outcome: 'already' });
        this.views.set(key, view);
        return view;
      }
      if (!sponsored && before !== undefined) {
        return this.settle(e, caller, {
          ...base, status: 'refused', code: 'sponsorship_revoked', retryable: false,
          message: 'this service sponsored the account before and its sponsorship was removed on-chain; only the paymaster\'s governor restores it',
        });
      }
      // What the daily cap counts: an allowlisting, or without a gate any account this module sends a transaction for.
      const counted = gated ? !sponsored : !signerDeployed || !accountDeployed;
      if (!sponsored) {
        const g = await this.o.chain.readGate();
        this.o.metrics?.set('mova_cosigner_sponsor_gate_remaining', Number(g.remaining));
        if (!g.isOperator) return this.settle(e, caller, { ...base, status: 'refused', code: 'operator_revoked', retryable: true, message: 'this service\'s operator key is not an operator of the SponsorGate' });
        if (!same(g.paymasterOwner, this.o.chain.gate!)) return this.settle(e, caller, { ...base, status: 'refused', code: 'paymaster_not_gated', retryable: true, message: 'the paymaster is not owned by the SponsorGate' });
        if (!g.bounded) return this.settle(e, caller, { ...base, status: 'refused', code: 'paymaster_unbounded', retryable: true, message: 'the paymaster enforces no per-account gas budget, so the gate refuses operators' });
        if (g.remaining === 0n) return this.settle(e, caller, { ...base, status: 'refused', code: 'gate_budget_exhausted', retryable: true, message: 'the SponsorGate\'s budget for this window is spent' });
      }
      if (counted) {
        const recent = this.o.audit.sponsorshipsSince(this.now() - DAY) + this.reserved;
        if (recent >= this.o.dailyCap) {
          return this.settle(e, caller, { ...base, status: 'refused', code: 'daily_cap', retryable: true, message: `this service sponsors at most ${this.o.dailyCap} accounts in 24 hours` });
        }
      }
      const balance = await this.o.chain.operatorBalance();
      this.o.metrics?.set('mova_cosigner_sponsor_operator_balance_eth', Number(balance) / 1e18);
      if (balance < (this.o.minOperatorBalanceWei ?? DEFAULT_MIN_OPERATOR_BALANCE_WEI)) {
        return this.settle(e, caller, { ...base, status: 'refused', code: 'operator_unfunded', retryable: true, message: 'the sponsorship operator key needs ETH for gas' });
      }

      const work: Work = { signer: !signerDeployed, sponsor: !sponsored, counted, ...(accountDeployed ? {} : { account: deployment }) };
      if (work.counted) this.reserved++;
      this.inFlight.add(key);
      const view: SponsorshipView = { ...base, status: 'pending' };
      this.views.set(key, view);
      this.tail = this.tail.then(() => this.run(e, caller, work));
      return view;
    } catch (err) {
      this.log.warn(`sponsorship of ${e.account}: ${this.scrub(err)}`);
      return this.settle(e, caller, { ...base, status: 'failed', code: 'chain_unavailable', retryable: true, message: 'the chain could not be read' }, false);
    }
  }

  private async run(e: Enrolment, caller: Caller, work: Work): Promise<void> {
    const key = keyOf(e.chainId, e.account);
    let signerTx: Hex | undefined;
    let accountTx: Hex | undefined;
    let sponsorTx: Hex | undefined;
    try {
      // Re-read before each send: another replica, the governor, or the account's own owners may have done it meanwhile.
      if (work.account && !(await this.o.chain.hasCode(e.account))) accountTx = await this.o.chain.createKernelAccount(work.account);
      if (work.signer && !(await this.o.chain.hasCode(e.passkeySigner))) signerTx = await this.o.chain.createSigner(e.passkey);
      if (work.sponsor && !(await this.o.chain.isSponsored(e.account))) sponsorTx = await this.o.chain.sponsor(e.account);
      const outcome = sponsorTx ? 'sponsored' : !this.gated && (signerTx || accountTx) ? 'prepared' : 'already';
      this.record(e, caller, { outcome, signerTx, accountTx, sponsorTx, operator: this.operator });
      this.views.set(key, { chainId: e.chainId, account: e.account, status: 'sponsored', signerTx, accountTx, sponsorTx });
      const how = !this.gated ? ' (no gate: the ownerless paymaster admits it by its address)' : sponsorTx ? ` (${sponsorTx})` : ' (already allowlisted)';
      this.log.info(`${this.gated ? 'sponsored' : 'prepared'} ${e.kind} ${e.account}${how}`
        + `${accountTx ? `, account deployed so its first operation carries no initCode (${accountTx})` : ''}`
        + `${signerTx ? `, passkey signer created (${signerTx})` : ''}`);
    } catch (err) {
      const reason = this.scrub(err).slice(0, 300);
      try {
        this.record(e, caller, { outcome: 'failed', code: 'transaction_failed', reason, signerTx, accountTx, operator: this.operator });
      } catch (auditErr) {
        this.log.error(`audit log append failed for a sponsorship failure: ${this.scrub(auditErr)}`);
      }
      this.views.set(key, { chainId: e.chainId, account: e.account, status: 'failed', code: 'transaction_failed', retryable: true, message: 'the sponsorship transaction failed: enrol again to retry', signerTx, accountTx });
      this.log.warn(`sponsorship of ${e.account} failed: ${reason}`);
    } finally {
      if (work.counted) this.reserved--;
      this.inFlight.delete(key);
    }
  }

  private settle(e: Enrolment, caller: Caller, view: SponsorshipView, audited = true): SponsorshipView {
    this.views.set(keyOf(e.chainId, e.account), view);
    if (audited) this.record(e, caller, { outcome: view.status === 'failed' ? 'failed' : 'refused', code: view.code });
    else this.o.metrics?.inc('mova_cosigner_sponsorships_total', { result: view.status });
    return view;
  }

  private record(e: Enrolment, caller: Caller, r: Pick<SponsorRecord, 'outcome' | 'code' | 'signerTx' | 'accountTx' | 'sponsorTx' | 'operator' | 'reason'>): void {
    const rec: SponsorRecord = { t: 'sponsor', at: this.now(), client: caller.client, chainId: e.chainId, account: e.account, kind: e.kind, ...r };
    for (const k of Object.keys(rec) as (keyof SponsorRecord)[]) if (rec[k] === undefined) delete rec[k];
    this.o.audit.append(rec);
    this.o.metrics?.inc('mova_cosigner_sponsorships_total', { result: r.outcome });
    this.o.metrics?.set('mova_cosigner_audit_records', this.o.audit.records);
  }

  private scrub(e: unknown): string {
    const text = e instanceof SponsorTransactionFailed ? e.reason : e instanceof Error ? e.message.split('\n')[0]! : String(e);
    return redact(text, this.o.redactValues);
  }
}
