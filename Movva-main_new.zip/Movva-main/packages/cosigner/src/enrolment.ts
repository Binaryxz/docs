/**
 * Enrolment: binding an account to the passkey the account itself trusts.
 *
 * The request may carry a passkey key and, for an account that does not exist yet, its deployment. Neither is
 * believed. What is believed is the chain:
 *
 *   Safe 2-of-2, deployed      getOwners / getThreshold: exactly two owners, threshold 2, this service one of
 *                              them; the other is a canonical SafeWebAuthnSigner - its `getConfiguration()` is
 *                              the key, and `factory.getSigner(key)` must give back its own address
 *   Safe 2-of-2, not deployed  the Safe's CREATE2 address commits to its owners: `predictSafeAddress(owners,
 *                              threshold, salt)` must be the account, and the claimed key must be what the
 *                              factory's CREATE2 turns into the passkey owner's address
 *   Kernel passkey, deployed   rootValidator() is the deployment's PasskeyCoSignerValidator and its configOf(account)
 *                              names this service; the key is read from that storage
 *   Kernel, not deployed       `predictKernelAddress(initData, salt)` must be the account; initData names the root
 *                              validator and its configuration (no hook, no extra init calls). Those two fields stay
 *                              on the enrolment: they are the only factory call the sponsorship module may send, and
 *                              it recomputes the address from them before sending it
 *   FROST (Safe or Kernel)     the group key is read from the FrostSigner owner / FrostValidator and this service
 *                              must hold a share of it; the passkey is the account's recovery Delay module (the
 *                              only on-chain place a FROST account names its passkey). Until that Delay exists -
 *                              before the account does, or after the sponsorship module created it - the claimed
 *                              key is accepted only on condition - enforced by policy - that the next operation
 *                              installs recovery with exactly that passkey
 *
 * Then the enroller proves it holds that passkey: a user-verified assertion over
 * `MovaCoSignerEnrolment(chainId, account, coSigner, issuedAt)`, issued within five minutes.
 */
import {
  decodeAbiParameters, decodeFunctionData, encodeAbiParameters, getAddress, hexToBytes, isAddress, isHex, keccak256, size, toHex,
  type Address, type Hex,
} from 'viem';
import { DEFAULT_RECOVERY, KERNEL_ABI, PASSKEY, predictDelayAddress, predictKernelAddress } from '@mova/smart-account';
import { Point } from '@mova/mpc';
import type { AccountReader, GroupKey, PasskeyConfig } from './chain.js';
import type { Enrolment } from './audit.js';
import type { FrostShareStore } from './frost-shares.js';
import type { AccountKind } from './policy.js';
import { Refusal } from './refusal.js';

export interface DeploymentAddresses {
  entryPoint: Address;
  passkeyValidator?: Address;
  frostValidator?: Address;
  kernelAdapter?: Address;
}

export type Binding = Omit<Enrolment, 'fromBlock' | 'enrolledAt'>;

export interface EnrolRequest {
  chainId: number;
  account: Address;
  type: 'safe' | 'kernel';
  passkey?: PasskeyConfig;
  safe?: { owners: Address[]; threshold: number; saltNonce: bigint };
  kernel?: { initData: Hex; salt: Hex };
  issuedAt: number;
  passkeySignature: Hex;
}

export const ENROLMENT_TYPEHASH = keccak256(toHex('MovaCoSignerEnrolment(uint256 chainId,address account,address coSigner,uint64 issuedAt)'));

/** What the passkey signs to enrol. A 32-byte type hash leads the preimage, so it never collides with an EIP-712 digest. */
export function enrolmentChallenge(chainId: number, account: Address, coSigner: Address, issuedAt: number): Hex {
  return keccak256(encodeAbiParameters(
    [{ type: 'bytes32' }, { type: 'uint256' }, { type: 'address' }, { type: 'address' }, { type: 'uint64' }],
    [ENROLMENT_TYPEHASH, BigInt(chainId), getAddress(account), getAddress(coSigner), BigInt(issuedAt)],
  ));
}

/** The P-256 verifiers accepted by default: the canonical FCL verifier, alone or behind the RIP-7212 precompile. */
export const DEFAULT_ALLOWED_VERIFIERS: readonly bigint[] = [BigInt(PASSKEY.verifierFCL), (0x100n << 160n) | BigInt(PASSKEY.verifierFCL)];

export interface BindingContext {
  chain: AccountReader;
  coSigner: Address;
  deployment: DeploymentAddresses;
  frostShares?: FrostShareStore;
  allowedVerifiers?: readonly bigint[];
}

const same = (a: Address | undefined, b: Address | undefined) => !!a && !!b && a.toLowerCase() === b.toLowerCase();

const compressed = (g: GroupKey): Hex => {
  try {
    return toHex(Point.fromAffine({ x: g.x, y: g.y }).toBytes(true));
  } catch {
    throw new Refusal('not_a_cosigner', 'the account\'s FROST group key is not a secp256k1 point');
  }
};

function requireShare(ctx: BindingContext, groupKey: Hex): void {
  if (!ctx.frostShares?.shareFor(Point.fromBytes(hexToBytes(groupKey)))) {
    throw new Refusal('no_share', 'this service holds no FROST share of the account\'s group key');
  }
}

function checkVerifier(ctx: BindingContext, pk: PasskeyConfig): void {
  if (!(ctx.allowedVerifiers ?? DEFAULT_ALLOWED_VERIFIERS).includes(pk.verifiers)) {
    throw new Refusal('not_a_cosigner', 'the account\'s passkey uses a P-256 verifier this service does not accept');
  }
}

/** A deployed canonical SafeWebAuthnSigner's key, or a claimed key the factory's CREATE2 commits to that address. */
async function passkeyOfSigner(ctx: BindingContext, signer: Address, claimed: PasskeyConfig | undefined): Promise<PasskeyConfig> {
  const onChain = await ctx.chain.webAuthnSignerConfig(signer);
  const candidate = onChain ?? claimed;
  if (!candidate) throw new Refusal('no_passkey_on_chain', 'the passkey owner is not deployed yet: enrol with its key, which is checked against its address');
  if (!same(await ctx.chain.webAuthnSignerAddress(candidate), signer)) {
    throw new Refusal(onChain ? 'not_a_cosigner' : 'deployment_mismatch', onChain
      ? 'the other owner is not a canonical SafeWebAuthnSigner'
      : 'the claimed passkey is not the key the passkey owner\'s address commits to');
  }
  checkVerifier(ctx, candidate);
  return candidate;
}

/**
 * A FROST account's passkey: the only module of its recovery Delay. Until that Delay exists, the claimed key - before the
 * account exists, and also once it exists without one: a Kernel account the sponsorship module created at enrolment has
 * no Delay until its own first operation installs it. Either way the claim stands on the condition the policy enforces
 * while the Delay is absent (`PolicyAccount.recoveryInstalled`): the next operation installs recovery for exactly that key.
 * Code at the Delay's address that does not read as this account's Delay is never passed over.
 */
async function passkeyOfDelay(ctx: BindingContext, account: Address, delay: Address, deployed: boolean, claimed: PasskeyConfig | undefined): Promise<{ passkey: PasskeyConfig; passkeySigner: Address }> {
  const view = await ctx.chain.delay(delay);
  if (view && same(view.owner, account) && same(view.avatar, account)) {
    if (view.modules.length !== 1) throw new Refusal('no_passkey_on_chain', 'the recovery Delay must have exactly one module, the passkey signer');
    const passkeySigner = view.modules[0]!;
    return { passkey: await passkeyOfSigner(ctx, passkeySigner, undefined), passkeySigner };
  }
  if (!claimed) {
    throw new Refusal('no_passkey_on_chain', 'a FROST account names its passkey only as its recovery Delay\'s module, and this account has none yet: enrol with its key');
  }
  if (deployed && await ctx.chain.hasCode(delay)) {
    throw new Refusal('no_passkey_on_chain', 'the account\'s recovery Delay address holds a contract that is not this account\'s Delay');
  }
  checkVerifier(ctx, claimed);
  return { passkey: claimed, passkeySigner: await ctx.chain.webAuthnSignerAddress(claimed) };
}

/** Resolve who signs for `account`, from the chain (or a CREATE2 commitment the chain will honour). */
export async function resolveBinding(ctx: BindingContext, req: Pick<EnrolRequest, 'chainId' | 'account' | 'type' | 'passkey' | 'safe' | 'kernel'>): Promise<Binding> {
  const account = getAddress(req.account);
  const deployed = await ctx.chain.hasCode(account);
  const delay = predictDelayAddress(account, DEFAULT_RECOVERY);
  const base = { chainId: req.chainId, account, coSigner: getAddress(ctx.coSigner), delay, counterfactual: !deployed };

  if (req.type === 'safe') {
    let owners: Address[];
    let threshold: bigint;
    if (deployed) {
      ({ owners, threshold } = await ctx.chain.safeOwners(account));
    } else {
      if (!req.safe) throw new Refusal('deployment_mismatch', 'the account has no code: enrol it with its deployment (owners, threshold, saltNonce)');
      const predicted = await ctx.chain.predictSafe(req.safe.owners, req.safe.threshold, req.safe.saltNonce);
      if (!same(predicted, account)) throw new Refusal('deployment_mismatch', 'those owners, threshold and salt do not create this Safe');
      owners = req.safe.owners.map((o) => getAddress(o));
      threshold = BigInt(req.safe.threshold);
    }
    if (owners.length === 2 && threshold === 2n && owners.some((o) => same(o, ctx.coSigner))) {
      const passkeySigner = owners.find((o) => !same(o, ctx.coSigner))!;
      const passkey = await passkeyOfSigner(ctx, passkeySigner, req.passkey);
      return { ...base, kind: 'safe-passkey' satisfies AccountKind, passkey, passkeySigner };
    }
    if (owners.length === 1 && threshold === 1n) {
      const group = await ctx.chain.frostSignerKey(owners[0]!);
      if (group) {
        const groupKey = compressed(group);
        requireShare(ctx, groupKey);
        const { passkey, passkeySigner } = await passkeyOfDelay(ctx, account, delay, deployed, req.passkey);
        return { ...base, kind: 'safe-frost', passkey, passkeySigner, frostSigner: owners[0]!, groupKey };
      }
    }
    throw new Refusal('not_a_cosigner', 'this service is not a signer of that Safe: expected 2-of-2 with this co-signer, or a FrostSigner group it holds a share of');
  }

  let validator: Address | undefined;
  let validatorData: Hex | undefined;
  // Kept on the enrolment only once the CREATE2 check below has passed: it is the only factory call the sponsorship
  // module may send, so the account exists before any operation would have to carry initCode.
  let kernelDeployment: { initData: Hex; salt: Hex } | undefined;
  if (deployed) {
    validator = await ctx.chain.kernelRootValidator(account);
  } else {
    if (!req.kernel) throw new Refusal('deployment_mismatch', 'the account has no code: enrol it with its deployment (initData, salt)');
    if (!same(predictKernelAddress({ initData: req.kernel.initData, salt: req.kernel.salt }), account)) {
      throw new Refusal('deployment_mismatch', 'that initData and salt do not create this Kernel account');
    }
    kernelDeployment = { initData: req.kernel.initData, salt: req.kernel.salt };
    let args: readonly unknown[];
    try {
      const decoded = decodeFunctionData({ abi: KERNEL_ABI, data: req.kernel.initData });
      if (decoded.functionName !== 'initialize') throw new Error('not initialize');
      args = decoded.args as readonly unknown[];
    } catch {
      throw new Refusal('deployment_mismatch', 'initData is not Kernel initialize(...)');
    }
    const [root, hook, data, hookData, initConfig] = args as [Hex, Address, Hex, Hex, readonly Hex[]];
    if (BigInt(hook) !== 0n || hookData !== '0x' || initConfig.length !== 0) {
      throw new Refusal('not_a_cosigner', 'the account is created with a hook or extra initial calls, which could add authority this service cannot see');
    }
    if (root.length !== 44 || !root.toLowerCase().startsWith('0x01')) throw new Refusal('not_a_cosigner', 'the account\'s root is not a validator');
    validator = getAddress(`0x${root.slice(4)}`);
    validatorData = data;
  }

  if (validator && same(validator, ctx.deployment.passkeyValidator)) {
    let cfg: (PasskeyConfig & { coSigner: Address }) | undefined;
    if (deployed) {
      cfg = await ctx.chain.passkeyCoSignerConfig(validator, account);
    } else {
      try {
        const [x, y, verifiers, coSigner] = decodeAbiParameters([{ type: 'uint256' }, { type: 'uint256' }, { type: 'uint176' }, { type: 'address' }], validatorData!);
        cfg = { x, y, verifiers, coSigner: getAddress(coSigner) };
      } catch {
        throw new Refusal('deployment_mismatch', 'the validator configuration in initData does not decode');
      }
    }
    if (!cfg || !same(cfg.coSigner, ctx.coSigner)) throw new Refusal('not_a_cosigner', 'the account\'s PasskeyCoSignerValidator names another co-signer');
    checkVerifier(ctx, cfg);
    const passkey = { x: cfg.x, y: cfg.y, verifiers: cfg.verifiers };
    return { ...base, kind: 'kernel-passkey', passkey, passkeySigner: await ctx.chain.webAuthnSignerAddress(passkey), validator, ...(kernelDeployment ? { kernelDeployment } : {}) };
  }
  if (validator && same(validator, ctx.deployment.frostValidator)) {
    let group: GroupKey | undefined;
    if (deployed) {
      group = await ctx.chain.frostValidatorKey(validator, account);
    } else {
      try {
        const [x, y] = decodeAbiParameters([{ type: 'uint256' }, { type: 'uint256' }], validatorData!);
        group = { x, y };
      } catch {
        throw new Refusal('deployment_mismatch', 'the FrostValidator configuration in initData does not decode');
      }
    }
    if (!group) throw new Refusal('not_a_cosigner', 'the account\'s FrostValidator holds no group key');
    const groupKey = compressed(group);
    requireShare(ctx, groupKey);
    if (deployed && ctx.deployment.kernelAdapter) {
      const onChainDelay = await ctx.chain.kernelAdapterDelay(ctx.deployment.kernelAdapter, account);
      if (onChainDelay && !same(onChainDelay, delay)) throw new Refusal('no_passkey_on_chain', 'the account\'s recovery Delay is not the default one');
    }
    const { passkey, passkeySigner } = await passkeyOfDelay(ctx, account, delay, deployed, req.passkey);
    return { ...base, kind: 'kernel-frost', passkey, passkeySigner, validator, groupKey, ...(kernelDeployment ? { kernelDeployment } : {}) };
  }
  throw new Refusal('not_a_cosigner', 'the account\'s root validator is not this deployment\'s PasskeyCoSignerValidator or FrostValidator');
}

export function sameBinding(a: Binding, b: Binding): boolean {
  return a.kind === b.kind && same(a.account, b.account) && a.chainId === b.chainId
    && a.passkey.x === b.passkey.x && a.passkey.y === b.passkey.y && a.passkey.verifiers === b.passkey.verifiers
    && same(a.passkeySigner, b.passkeySigner) && same(a.coSigner, b.coSigner) && same(a.delay, b.delay)
    && (a.validator ?? '').toLowerCase() === (b.validator ?? '').toLowerCase()
    && (a.frostSigner ?? '').toLowerCase() === (b.frostSigner ?? '').toLowerCase()
    && (a.groupKey ?? '').toLowerCase() === (b.groupKey ?? '').toLowerCase();
}

/* ------------------------------------------------------------------ wire */

const bigintOf = (v: unknown, what: string): bigint => {
  if (typeof v === 'string' && /^(0|[1-9]\d{0,77})$/.test(v)) return BigInt(v);
  if (typeof v === 'string' && isHex(v) && v.length <= 66) return BigInt(v);
  throw new Refusal('malformed', `${what} must be an integer string`);
};

export function parseEnrolRequest(body: unknown): EnrolRequest {
  const o = (body && typeof body === 'object' ? body : undefined) as Record<string, unknown> | undefined;
  if (!o) throw new Refusal('malformed', 'the request must be a JSON object');
  if (!Number.isSafeInteger(o.chainId)) throw new Refusal('malformed', 'chainId must be an integer');
  if (typeof o.account !== 'string' || !isAddress(o.account, { strict: false })) throw new Refusal('malformed', 'account must be an address');
  if (o.type !== 'safe' && o.type !== 'kernel') throw new Refusal('malformed', 'type must be "safe" or "kernel"');
  if (!Number.isSafeInteger(o.issuedAt)) throw new Refusal('malformed', 'issuedAt must be unix seconds');
  const passkeySignature = o.passkeySignature === undefined ? '0x' : o.passkeySignature;
  if (typeof passkeySignature !== 'string' || !isHex(passkeySignature)) throw new Refusal('malformed', 'passkeySignature must be hex');
  const req: EnrolRequest = {
    chainId: o.chainId as number, account: getAddress(o.account), type: o.type, issuedAt: o.issuedAt as number, passkeySignature: passkeySignature as Hex,
  };
  if (o.passkey !== undefined) {
    const p = (o.passkey ?? {}) as Record<string, unknown>;
    req.passkey = { x: bigintOf(p.x, 'passkey.x'), y: bigintOf(p.y, 'passkey.y'), verifiers: p.verifiers === undefined ? BigInt(PASSKEY.verifierFCL) : bigintOf(p.verifiers, 'passkey.verifiers') };
  }
  if (o.safe !== undefined) {
    const s = (o.safe ?? {}) as Record<string, unknown>;
    if (!Array.isArray(s.owners) || s.owners.length === 0 || s.owners.length > 16 || !s.owners.every((a) => typeof a === 'string' && isAddress(a, { strict: false }))) {
      throw new Refusal('malformed', 'safe.owners must be addresses');
    }
    if (!Number.isSafeInteger(s.threshold) || (s.threshold as number) < 1) throw new Refusal('malformed', 'safe.threshold must be a positive integer');
    req.safe = { owners: (s.owners as string[]).map((a) => getAddress(a)), threshold: s.threshold as number, saltNonce: bigintOf(s.saltNonce, 'safe.saltNonce') };
  }
  if (o.kernel !== undefined) {
    const k = (o.kernel ?? {}) as Record<string, unknown>;
    if (typeof k.initData !== 'string' || !isHex(k.initData) || size(k.initData) > 16 * 1024) throw new Refusal('malformed', 'kernel.initData must be hex');
    const salt = typeof k.salt === 'string' && isHex(k.salt) && size(k.salt) === 32 ? k.salt as Hex : undefined;
    if (!salt) throw new Refusal('malformed', 'kernel.salt must be 32 bytes of hex');
    req.kernel = { initData: k.initData as Hex, salt };
  }
  return req;
}
