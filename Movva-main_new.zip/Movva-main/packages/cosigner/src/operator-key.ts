/**
 * The sponsorship operator's key: the key that sends `SponsorGate.sponsor` and the passkey signer's creation, and
 * nothing else. It is never the co-signer's key.
 *
 * Why a second key. The co-signer key is an owner of every user's account; it signs digests only after a passkey
 * has signed the same digest, and it never sends a transaction. The operator key pays gas and holds a float of ETH,
 * so it has to sign transactions the service builds itself - exactly what the co-signer key must never do. A leaked
 * operator key costs at most the gate's budget (N accounts per day, each within the paymaster's per-account gas
 * budget) and the ETH float, and is revoked on the gate in one transaction; see contracts/SponsorGate.sol.
 *
 * Custody mirrors the co-signer key's (key.ts): a KMS/HSM backend in production, a 0600 key file in development
 * that production mode refuses unless COSIGNER_ALLOW_SPONSOR_FILE_KEY_IN_PRODUCTION=1, and a key in memory for
 * tests. `operatorAccount` turns any of them into a viem account that signs transactions by digest, so the key
 * itself never enters the process when it lives in a KMS.
 */
import { readFileSync, statSync } from 'node:fs';
import {
  hashMessage, hashTypedData, keccak256, parseSignature, serializeTransaction,
  type Address, type Hex, type LocalAccount, type TransactionSerializable,
} from 'viem';
import { toAccount } from 'viem/accounts';
import { KeyCustodyError, kmsKey, localKey, type CoSignerKey, type KmsBackend } from './key.js';

/** Same shape as `CoSignerKey`: an address, a custody label, and a signature over a 32-byte digest. */
export type OperatorKey = CoSignerKey;

export interface FileOperatorKeyOptions {
  path: string;
  production: boolean;
  /** COSIGNER_ALLOW_SPONSOR_FILE_KEY_IN_PRODUCTION=1. */
  allowInProduction?: boolean;
  readFile?: (path: string) => string;
  fileMode?: (path: string) => number;
}

export function fileOperatorKey(o: FileOperatorKeyOptions): OperatorKey {
  if (o.production && !o.allowInProduction) {
    throw new KeyCustodyError('a sponsorship operator key file refuses to start in production mode: use a KMS/HSM backend '
      + '(COSIGNER_SPONSOR_KMS_MODULE), or set COSIGNER_ALLOW_SPONSOR_FILE_KEY_IN_PRODUCTION=1 to accept a key on disk explicitly');
  }
  let mode: number;
  let raw: string;
  try {
    mode = (o.fileMode ?? ((p) => statSync(p).mode))(o.path);
    raw = (o.readFile ?? ((p) => readFileSync(p, 'utf8')))(o.path);
  } catch {
    throw new KeyCustodyError('the sponsorship operator key file could not be read');
  }
  if ((mode & 0o077) !== 0) throw new KeyCustodyError('the sponsorship operator key file is readable by group or others: chmod 600 (or 400) it');
  try {
    return localKey(raw.trim() as Hex, 'file');
  } catch {
    throw new KeyCustodyError('the sponsorship operator key is not a 32-byte secp256k1 private key');
  }
}

export const kmsOperatorKey = (backend: KmsBackend): Promise<OperatorKey> => kmsKey(backend);

/** A viem account over the key: transactions, messages and typed data are all signed by digest. */
export function operatorAccount(key: OperatorKey): LocalAccount {
  const account = toAccount({
    address: key.address,
    signMessage: async ({ message }) => key.signDigest(hashMessage(message)),
    signTypedData: async (typedData) => key.signDigest(hashTypedData(typedData as never)),
    signTransaction: async (transaction, options) => {
      const serializer = (options?.serializer ?? serializeTransaction) as (tx: TransactionSerializable, signature?: ReturnType<typeof parseSignature>) => Hex;
      const signature = parseSignature(await key.signDigest(keccak256(serializer(transaction as TransactionSerializable))));
      return serializer(transaction as TransactionSerializable, signature);
    },
  });
  return { ...account, source: key.custody } as LocalAccount;
}

export const sameAddress = (a: Address, b: Address) => a.toLowerCase() === b.toLowerCase();
