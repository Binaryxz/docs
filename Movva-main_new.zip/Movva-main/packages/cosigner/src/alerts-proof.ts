/**
 * What a passkey signs to subscribe a device to recovery alerts for an account, or to unsubscribe it. Browser-safe
 * (viem only): the wallet computes the same challenge it asks the authenticator to sign.
 *
 *   subscribe     keccak256(abi.encode(SUBSCRIBE_TYPEHASH, chainId, account, coSigner, issuedAt,
 *                                      keccak256(endpoint), keccak256(abi.encode(keccak256(p256dh), keccak256(auth)))))
 *   unsubscribe   keccak256(abi.encode(UNSUBSCRIBE_TYPEHASH, chainId, account, coSigner, issuedAt, keccak256(endpoint)))
 *
 * Each 32-byte type hash leads its preimage, so a challenge never collides with an operation digest, an EIP-712
 * digest or the enrolment challenge. The keys are hashed as their canonical base64url text (no padding), which is
 * what `PushSubscription.toJSON()` gives and what the service stores.
 */
import { encodeAbiParameters, getAddress, keccak256, toHex, type Address, type Hex } from 'viem';

export const ALERTS_SUBSCRIBE_TYPEHASH = keccak256(toHex(
  'MovaRecoveryAlertsSubscribe(uint256 chainId,address account,address coSigner,uint64 issuedAt,bytes32 endpoint,bytes32 keys)',
));
export const ALERTS_UNSUBSCRIBE_TYPEHASH = keccak256(toHex(
  'MovaRecoveryAlertsUnsubscribe(uint256 chainId,address account,address coSigner,uint64 issuedAt,bytes32 endpoint)',
));

export interface AlertSubscriptionJson {
  endpoint: string;
  keys: { p256dh: string; auth: string };
}

/** base64 or base64url, padded or not, as the canonical unpadded base64url the challenge and the service use. */
export const canonicalB64url = (s: string): string => s.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');

export function alertsSubscribeChallenge(chainId: number, account: Address, coSigner: Address, issuedAt: number, sub: AlertSubscriptionJson): Hex {
  const keys = keccak256(encodeAbiParameters([{ type: 'bytes32' }, { type: 'bytes32' }], [
    keccak256(toHex(canonicalB64url(sub.keys.p256dh))), keccak256(toHex(canonicalB64url(sub.keys.auth))),
  ]));
  return keccak256(encodeAbiParameters(
    [{ type: 'bytes32' }, { type: 'uint256' }, { type: 'address' }, { type: 'address' }, { type: 'uint64' }, { type: 'bytes32' }, { type: 'bytes32' }],
    [ALERTS_SUBSCRIBE_TYPEHASH, BigInt(chainId), getAddress(account), getAddress(coSigner), BigInt(issuedAt), keccak256(toHex(sub.endpoint)), keys],
  ));
}

export function alertsUnsubscribeChallenge(chainId: number, account: Address, coSigner: Address, issuedAt: number, endpoint: string): Hex {
  return keccak256(encodeAbiParameters(
    [{ type: 'bytes32' }, { type: 'uint256' }, { type: 'address' }, { type: 'address' }, { type: 'uint64' }, { type: 'bytes32' }],
    [ALERTS_UNSUBSCRIBE_TYPEHASH, BigInt(chainId), getAddress(account), getAddress(coSigner), BigInt(issuedAt), keccak256(toHex(endpoint))],
  ));
}

/** The notification a recovery alert carries. No amount, no address: what happened, and until when a veto is certain to work. */
export interface RecoveryAlertPayload {
  v: 1;
  type: 'mova.recovery-requested' | 'mova.alerts-off';
  title: string;
  body: string;
  /** 'queued' on first sight, 'daily' reminders, 'final' within a day of the cooldown's end. */
  kind?: 'queued' | 'daily' | 'final';
  /** Unix seconds when the queued transaction becomes executable (absent for alerts-off). */
  executableAt?: number;
  tag: string;
}

export const RECOVERY_ALERT_TEXT = {
  title: 'Movva',
  body: 'Uma recuperação foi solicitada na sua conta Movva',
  alertsOff: 'Os alertas de recuperação da sua conta Movva foram desativados neste dispositivo',
} as const;
